# Carlyle Unified Investor Performance Reporting
## Snowflake Cortex — Technical Requirements

**Project:** Unified Investor Performance Reporting — Pilot MVP  
**Client:** The Carlyle Group  
**Prepared by:** Deloitte  
**Date:** April 2026  
**Scope:** 3–5 Target LP Investors | 24-Week Engagement

---

## 1. Platform Overview

Build a centralized Snowflake data platform that ingests, transforms, and governs private markets investor performance data across three business segments: **Private Equity (PE)**, **Private Credit**, and **AlpInvest**. The platform serves as the single source of truth feeding downstream Palantir Foundry AI/agentic reporting workflows.

---

## 2. Data Source Inventory

| # | Source System | Type | Data Elements |
|---|--------------|------|---------------|
| 1 | Investran | Fund Accounting | Capital calls, distributions, NAVs, fee schedules |
| 2 | eFront | Fund Accounting | Capital calls, distributions, NAVs, fee schedules |
| 3 | Allvue | Fund Accounting | Capital calls, distributions, NAVs, fee schedules |
| 4 | Chronograph | Portfolio Monitoring | Portfolio company data, valuations |
| 5 | Bloomberg | Market Data | Benchmark indices, FX rates |
| 6 | MSCI | Market Data | Benchmark indices, performance benchmarks |
| 7 | Salesforce | CRM/Ops | Investor relationships, LP contact data |
| 8 | Document Repositories | Unstructured | Capital call notices, K-1s |
| 9 | Manual / Excel Uploads | Semi-structured | Ad hoc investor data, overrides |

- **Total estimated sources:** 15–20
- **Data mix:** ~75% structured, ~25% semi-structured
- **Refresh cadence:** Monthly (no significant real-time/streaming requirement in MVP)
- **Upstream data remediation:** Out of scope

---

## 3. Snowflake Architecture Requirements

### 3.1 Zone Design

#### Raw Zone (Landing / Staging)
- Ingest all source data using **Snowpipe** (streaming) or **batch COPY INTO** patterns
- No transformations applied at this layer
- Maintain source-level traceability, auditability, and load control metadata
- Support parallel delivery so Palantir can begin ontology build while curated layer is in progress
- Data elements to land: capital calls, distributions, NAVs, valuations, fee schedules, FX rates, benchmark indices

#### Curated / Conformed Zone (Transformation Layer)
- Use **Snowpark (Python)** and/or **SQL transformations** for all curation logic
- Build using a **dimensional modeling approach** (star schema) for core entities — dimension tables for funds, investors, portfolio companies; fact tables for cash flows, NAV snapshots, and fee/carry transactions
- Apply data quality (DQ) checks and reconciliation at this layer
- Produce conformed dimension and fact tables:
  - `dim_fund` — fund dimension with vintage year, strategy, segment
  - `dim_investor` — investor/LP dimension with commitment details
  - `dim_portfolio_company` — portfolio company dimension with sector, geography
  - `dim_date` — shared date dimension for period-based reporting
  - `fact_cash_flow` — capital calls, distributions, recallable amounts
  - `fact_nav_snapshot` — periodic NAV by fund and investor
  - `fact_investor_account` — capital account balances and ownership percentages
  - `fact_fee_carry` — management fees, carried interest, offsets
  - `ref_fx_rates` — FX rate reference table
  - `ref_benchmark_indices` — benchmark index reference table
- Standardize common business definitions, surrogate keys, and relationships across lines of business and source systems

#### Apache Iceberg Tables (Open Table Format)
- Store curated and conformed datasets as **Apache Iceberg tables**
- Use **Parquet-backed, time-travel enabled** table format
- Key datasets:
  - Fund performance datasets
  - Cash flow histories
  - Valuation snapshots
- Support **bi-directional zero-copy interoperability** with Palantir Foundry via Iceberg native connectors (REST / JDBC / S3-compatible)

### 3.2 Transformation Framework — DBT

- Implement **DBT models** to manage all curated-zone transformations
- Requirements:
  - Define dependency logic and DAG structure across all models
  - Build reusable, modular data pipelines for future expansion
  - Include inline testing (not-null, unique, referential integrity)
  - Maintain documentation and data lineage within DBT
  - Integrate DBT execution with ingestion workflows to automate refresh cycles

### 3.3 Core Data Entities (Ontology-Aligned)

The following entities must be modeled and available as curated Snowflake objects to feed the Palantir ontology layer:

| Entity | Key Attributes |
|--------|---------------|
| **Funds** | Fund ID, fund name, vintage year, strategy, segment (PE/Credit/AlpInvest) |
| **Portfolio Companies** | Company ID, fund association, sector, geography, entry/exit dates |
| **Investors (LPs)** | Investor ID, investor name, commitment amount, fund associations |
| **Cash Flows** | Transaction date, type (call/distribution/recallable), fund ID, investor ID, amount, currency |
| **Investor Accounts** | Account ID, investor ID, fund ID, capital account balance, ownership % |
| **Benchmark Indices** | Index name, date, value, source (Bloomberg/MSCI) |
| **FX Rates** | Currency pair, date, rate, source |
| **NAV Snapshots** | Fund ID, date, NAV, methodology |

**Key Relationships to model:**
- Fund ↔ Portfolio Company
- LP ↔ Fund Commitment
- Cash Flow ↔ Fund
- Cash Flow ↔ Investor
- Fund ↔ Benchmark Index

---

## 4. Metric Calculation Requirements

The following **20–25 core metrics** must be calculable from the Snowflake curated layer. Edge cases are excluded from MVP scope.

### 4.1 Performance Metrics

| Metric | Description |
|--------|-------------|
| **IRR** (Internal Rate of Return) | Time-weighted return based on cash flow timing and NAV |
| **TVPI** (Total Value to Paid-In) | (Distributions + Residual Value) / Paid-In Capital |
| **DPI** (Distributions to Paid-In) | Cumulative Distributions / Paid-In Capital |
| **RVPI** (Residual Value to Paid-In) | Residual Value / Paid-In Capital |
| **Gross IRR** | Pre-fee, pre-carry IRR |
| **Net IRR** | Post-fee, post-carry IRR |

### 4.2 Fee & Carry Calculations

| Metric | Description |
|--------|-------------|
| **Management Fees** | Fee amounts by period, investor, and fund per fee schedule |
| **Carried Interest** | Carry allocations per waterfall logic |
| **Fee Offsets** | Applicable fee reduction credits |

### 4.3 Valuation & NAV Adjustments

| Metric | Description |
|--------|-------------|
| **NAV per LP** | Investor-level net asset value |
| **FX-Adjusted NAV** | NAV converted to reporting currency using period-end FX rates |
| **Unrealized Gain/Loss** | Current NAV vs. cost basis |
| **Realized Gain/Loss** | Distributions vs. cost basis for exited positions |

### 4.4 Benchmarking Metrics

| Metric | Description |
|--------|-------------|
| **PME** (Public Market Equivalent) | Direct alpha vs. public benchmark |
| **KS-PME** (Kaplan-Schoar PME) | LP cash flows discounted at public market returns |
| **Benchmark Delta** | Fund IRR minus benchmark return over equivalent period |

### 4.5 Attribution Analysis

| Metric | Description |
|--------|-------------|
| **Capital Called (by period)** | Contributions by fund, investor, and date |
| **Distributions (by period)** | Distributions by fund, investor, and date |
| **Recallable Distributions** | Distributions subject to recall per LPA terms |
| **Net Cash Flow** | Net of calls and distributions per period |

---

## 5. Data Governance & Access Control Requirements

### 5.1 Role-Based Access Control (RBAC)

| Role | Access Level |
|------|-------------|
| **Carlyle Admin** | Full access to all funds, investors, and underlying data |
| **LP Investor (per investor)** | Row-level access restricted to their own fund commitments and account data only |
| **Internal Executive** | Cross-fund aggregated views, no LP-level PII |
| **Investor Relations Analyst** | Fund-level and investor-level operational data |

- Implement **Row-Level Security (RLS)** to ensure each of the 5 LP investors sees only their own data
- Implement **Dynamic Data Masking** for sensitive investor PII fields
- All access controls must be auditable

### 5.2 Data Quality Framework

- DQ checks must be applied at the curated zone before data is served downstream
- Minimum required checks:
  - Null checks on key fields (investor ID, fund ID, cash flow amounts, dates)
  - Referential integrity (cash flows must reference valid fund and investor records)
  - Duplicate detection on transaction records
  - Cash flow sign convention validation (calls negative, distributions positive)
  - NAV reconciliation checks against source system totals
- Publish **data quality reports** as Snowflake tables/views for operational monitoring

### 5.3 Data Lineage

- Maintain full lineage from source system → raw zone → curated zone → metric output
- Leverage DBT lineage documentation
- Support audit trail requirements for calculation overrides

---

## 6. Snowflake Object Inventory (To Be Built)

### 6.1 Databases & Schemas

```
CARLYLE_UIPR_DB
├── RAW_SCHEMA
│   ├── raw_fund_accounting         -- Investran, eFront, Allvue
│   ├── raw_portfolio_monitoring    -- Chronograph
│   ├── raw_market_data             -- Bloomberg, MSCI
│   ├── raw_crm                     -- Salesforce
│   └── raw_manual_uploads          -- Excel/manual
├── CURATED_SCHEMA
│   ├── fund_master
│   ├── investor_master
│   ├── portfolio_company_master
│   ├── cash_flow_normalized
│   ├── investor_accounts
│   ├── nav_snapshots
│   ├── fx_rates
│   └── benchmark_indices
├── METRICS_SCHEMA
│   ├── fund_performance_metrics
│   ├── investor_performance_metrics
│   ├── fee_carry_calculations
│   └── benchmarking_metrics
└── GOVERNANCE_SCHEMA
    ├── dq_results
    ├── audit_log
    └── lineage_metadata
```

### 6.2 Iceberg Tables
- All curated and metrics schema tables should be implemented as Iceberg tables
- Enable time-travel for point-in-time reporting
- Configure S3-compatible external volume for Palantir zero-copy interoperability

### 6.3 Key Views
- `vw_investor_performance_summary` — LP-level TVPI, DPI, RVPI, IRR by fund
- `vw_fund_cash_flows` — Normalized cash flow history by fund and period
- `vw_nav_by_investor` — Current NAV per LP with FX adjustment
- `vw_benchmark_comparison` — Fund returns vs PME/KS-PME
- `vw_fee_carry_summary` — Fee and carry allocations by investor and fund

---

## 7. Ingestion Pipeline Requirements

### 7.1 Ingestion Patterns

| Source Type | Ingestion Method | Target Zone |
|-------------|-----------------|-------------|
| Fund accounting systems | Batch COPY INTO / JDBC connector | Raw Zone |
| Market data (Bloomberg/MSCI) | Snowflake Marketplace or API batch | Raw Zone |
| Salesforce | Scheduled batch pull | Raw Zone |
| Manual/Excel uploads | Snowpipe or staged file load | Raw Zone |
| Document repositories | Semi-structured (VARIANT) staging | Raw Zone |

### 7.2 Ingestion Controls
- Track load timestamps, source file names, and record counts per batch
- Implement idempotent loads (handle re-runs without duplicate data)
- Log all ingestion activity to `GOVERNANCE_SCHEMA.audit_log`

---

## 8. Integration Requirements (Palantir Foundry)

- Expose curated Iceberg tables to Palantir via **bi-directional zero-copy interoperability**
- Support native connectors: REST, JDBC, S3-compatible
- Palantir will consume the following Snowflake outputs:
  - All curated entity tables (funds, investors, cash flows, NAV, FX)
  - All metrics schema outputs
  - Benchmark indices
- Snowflake schemas must be defined in coordination with the Palantir ontology team to ensure alignment of keys and relationships

---

## 9. Non-Functional Requirements

| Requirement | Specification |
|-------------|--------------|
| **Refresh Cadence** | Monthly batch; no real-time re-architecture in MVP scope |
| **Data Volume** | Low-to-medium; no multi-terabyte performance tuning required in MVP |
| **Auditability** | Full audit trail for all transformations, metric calculations, and overrides |
| **Time-Travel** | Required — Iceberg tables must support point-in-time queries |
| **Latency** | Reporting data available within agreed SLA post monthly refresh |
| **Scalability** | Architecture must support extension to all Carlyle LP investors post-MVP without re-platforming |
| **Security** | Row-level security, dynamic data masking, RBAC — all enforced at Snowflake layer |
| **Environment Separation** | Separate DEV, UAT, and PROD environments required |

---

## 10. MVP Acceptance Criteria

The Snowflake data platform MVP is considered complete when the following are met:

- [ ] All priority source datasets successfully ingested into raw zone
- [ ] Curated data models built and validated for core entities (funds, investors, cash flows, NAV, FX, benchmarks)
- [ ] DBT models deployed with full lineage and test coverage
- [ ] All 20–25 priority metrics calculable and validated against source data
- [ ] Row-level security enforced — each of 5 LP investors can only access their own data
- [ ] Iceberg tables exposed and accessible by Palantir Foundry team
- [ ] Data quality reports operational and reviewed
- [ ] DEV, UAT, and PROD environments established
- [ ] End-to-end data validation completed with business sign-off
- [ ] All defects from SIT/UAT resolved or formally deferred

---

## 11. Out of Scope (MVP)

- Upstream data remediation in source systems
- Real-time / streaming data ingestion
- Full migration of all existing calculation logic (only 20–25 priority metrics)
- Edge case handling in metric calculations
- Performance re-architecture for large-scale data volumes
- Integration with LP portal or investor-facing UI (handled by Palantir layer)

---

## 12. Key Assumptions

1. Carlyle will provide timely access to source system SMEs, documentation, and data samples
2. Monthly refresh cadence applies; no intra-month refresh required for MVP
3. Data environment is ~75% structured / ~25% semi-structured; no unstructured OCR/NLP processing in scope for Snowflake layer
4. Carlyle will facilitate access to Investran, eFront, Allvue, and Chronograph APIs or exports
5. Palantir and Snowflake teams will coordinate on Iceberg interoperability configuration
6. Business rules and calculation logic will be validated by Carlyle domain SMEs before engineering build
7. A 60-day discovery overlap is assumed at engagement start

---

*Document prepared based on Deloitte's Proposal for Carlyle Unified Investor Performance Reporting — Pilot Engineering, April 2026.*
