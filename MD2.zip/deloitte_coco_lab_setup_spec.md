# DELOITTE_COCO_LAB · Lab Environment Setup Specification

**Audience:** Snowflake Cortex Code (CoCo)
**Purpose:** Provision the complete environment for the Cortex Code Hands-On Lab at Snowflake Summit 2026.
**Owner:** Rupesh Dandekar, Deloitte

---

## Overview

You are going to provision a full lab environment in Snowflake. When you finish, the environment will support up to 50 concurrent lab attendees, each with their own user account and personal schema, all sharing a single financial-services dataset.

The lab is a 90-minute hands-on session. Attendees will paste prompts into their own CoCo sessions, query the shared data, build a custom SKILL function, and deploy a Streamlit app to their personal schema. Everything has to work on first paste; do not introduce friction.

Run the phases in order. Pause after each phase, run the validation queries shown, and confirm before proceeding to the next phase. If anything fails validation, stop and report what failed.

## Assumptions

- You are running with `ACCOUNTADMIN` or equivalent. You will need to create roles, users, warehouses, and grant privileges.
- The Snowflake account has Cortex AI features enabled, including `SNOWFLAKE.CORTEX.COMPLETE` with `mistral-large2` and `mistral-7b`.
- The account allows password authentication for users (the 50 lab users will use passwords; SSO is not required).
- Cortex Code is installed and configured locally.

## What success looks like

At the end of this spec, the following are true:

1. A database `DELOITTE_COCO_LAB` exists with one shared schema `ANALYTICS` containing six populated tables.
2. 50 personal user schemas `BUILDER_01` through `BUILDER_50` exist inside the same database, each empty and owned by the corresponding user.
3. Two roles exist: `HOL_ADMIN` (facilitators) and `HOL_BUILDER` (attendees).
4. 50 users `BUILDER_01` through `BUILDER_50` exist, each with role `HOL_BUILDER` as their default and able to log in.
5. A warehouse `COMPUTE_WH` (size MEDIUM) and a separate facilitator warehouse `FACILITATOR_WH` (size SMALL) exist.
6. One custom function `CALCULATE_ADJUSTED_MARGIN` is deployed in `ANALYTICS` and callable by `HOL_BUILDER`.
7. All row-count and data-quality validations pass.

---

## Phase 1: Warehouses

Create two warehouses. The MEDIUM-sized `COMPUTE_WH` will absorb 50 concurrent attendees during the Streamlit deploy moment.

```sql
USE ROLE SYSADMIN;

CREATE WAREHOUSE IF NOT EXISTS COMPUTE_WH
  WAREHOUSE_SIZE = MEDIUM
  AUTO_SUSPEND = 60
  AUTO_RESUME = TRUE
  INITIALLY_SUSPENDED = FALSE
  COMMENT = 'Shared warehouse for HOL attendees. Sized MEDIUM to handle 50 concurrent Streamlit deploys.';

CREATE WAREHOUSE IF NOT EXISTS FACILITATOR_WH
  WAREHOUSE_SIZE = SMALL
  AUTO_SUSPEND = 60
  AUTO_RESUME = TRUE
  INITIALLY_SUSPENDED = FALSE
  COMMENT = 'Separate warehouse for facilitators so demos do not contend with attendee load.';
```

**Validation:**
```sql
SHOW WAREHOUSES LIKE 'COMPUTE_WH';
SHOW WAREHOUSES LIKE 'FACILITATOR_WH';
```

Both should be returned. Confirm before proceeding.

---

## Phase 2: Database and shared schema

```sql
USE ROLE SYSADMIN;

CREATE DATABASE IF NOT EXISTS DELOITTE_COCO_LAB
  COMMENT = 'Snowflake Summit 2026 Cortex Code HOL workspace';

USE DATABASE DELOITTE_COCO_LAB;

CREATE SCHEMA IF NOT EXISTS ANALYTICS
  COMMENT = 'Shared dataset for all attendees. Read-only for HOL_BUILDER.';

USE SCHEMA ANALYTICS;
```

**Validation:**
```sql
SHOW SCHEMAS IN DATABASE DELOITTE_COCO_LAB;
```

Expect at least `ANALYTICS` and the default `PUBLIC` and `INFORMATION_SCHEMA`. Confirm before proceeding.

---

## Phase 3: Tables and synthetic data

Create six tables in `DELOITTE_COCO_LAB.ANALYTICS`. Then populate them with realistic correlated synthetic data. **Do not use `RANDOM()` for everything.** Real correlations are part of what makes the lab work; the data has to tell a story.

### Table 3.1: CLIENTS · 10,000 rows

```sql
CREATE OR REPLACE TABLE CLIENTS (
  client_id              VARCHAR(12) PRIMARY KEY,
  first_name             VARCHAR(50),
  last_name              VARCHAR(50),
  age                    INTEGER,
  state                  VARCHAR(2),
  client_segment         VARCHAR(25),
  aum_usd                DECIMAL(15,2),
  relationship_manager   VARCHAR(50),
  risk_tolerance         VARCHAR(15),
  credit_score           INTEGER,
  years_as_client        INTEGER,
  primary_product        VARCHAR(30),
  churn_risk             VARCHAR(10)
);
```

**Data generation rules:**

- `client_id` format: `CLI-000001` through `CLI-010000`.
- `client_segment` distribution: 60% Mass Market, 25% Affluent, 12% High Net Worth, 3% Ultra High Net Worth.
- `aum_usd` ranges by segment: Mass Market `$10K–$250K`, Affluent `$250K–$2M`, HNW `$2M–$10M`, UHNW `$10M–$100M`.
- `state` distribution weighted toward NC, SC, VA, GA, TX, NY, CA, FL (about 60% total combined).
- `relationship_manager`: 25 fictional RMs (e.g., `RM-001 Chen`, `RM-002 Patel`, etc.). Distribute clients evenly.
- `risk_tolerance` correlated with age: clients under 40 skew Aggressive, 40 to 60 skew Moderate, over 60 skew Conservative.
- `credit_score` range 580 to 850, uniform.
- `years_as_client` range 1 to 30, uniform.
- `primary_product` values: Brokerage, IRA, Retirement Plan, Banking, Insurance. Distribute roughly evenly.
- `churn_risk` correlated: HNW and UHNW skew Low (80%+), clients with `years_as_client` under 4 skew High (40%+).

### Table 3.2: PORTFOLIOS · 20,000 to 25,000 rows

```sql
CREATE OR REPLACE TABLE PORTFOLIOS (
  portfolio_id            VARCHAR(12) PRIMARY KEY,
  client_id               VARCHAR(12),
  portfolio_name          VARCHAR(50),
  strategy                VARCHAR(30),
  inception_date          DATE,
  benchmark               VARCHAR(20),
  total_market_value      DECIMAL(15,2),
  ytd_return_pct          DECIMAL(6,3),
  one_year_return_pct     DECIMAL(6,3),
  three_year_return_pct   DECIMAL(6,3),
  sharpe_ratio            DECIMAL(6,3),
  max_drawdown_pct        DECIMAL(6,3),
  is_taxable              BOOLEAN,
  status                  VARCHAR(10)
);
```

**Data generation rules:**

- `portfolio_id` format: `PRT-000001` and up.
- Portfolios per client by segment: Mass Market 1 to 2, Affluent 2 to 3, HNW 3 to 4, UHNW 4 to 6.
- `client_id` references valid clients only.
- `strategy` values: Growth, Income, Balanced, Capital Preservation, ESG, Alternative. Bias by risk_tolerance: Aggressive clients skew Growth or Alternative; Conservative clients skew Capital Preservation or Income.
- `inception_date` between 2010-01-01 and 2024-12-31.
- `benchmark` values: S&P 500, Bloomberg Aggregate, MSCI World, Russell 2000, 60/40 Blend.
- `total_market_value` distributed so each client's portfolios sum to roughly the client's `aum_usd` (within plus or minus 30 percent noise).
- `ytd_return_pct` range -15.0 to +35.0, biased slightly positive (median around +5.0).
- `sharpe_ratio` range -0.5 to 3.5.
- `max_drawdown_pct` range -50.0 to 0.0 (always negative or zero).
- `status` values: Active 92%, Closed 6%, Suspended 2%.

### Table 3.3: HOLDINGS · 150,000 rows

```sql
CREATE OR REPLACE TABLE HOLDINGS (
  holding_id              VARCHAR(12) PRIMARY KEY,
  portfolio_id            VARCHAR(12),
  ticker                  VARCHAR(10),
  asset_class             VARCHAR(30),
  quantity                DECIMAL(12,4),
  cost_basis_usd          DECIMAL(15,2),
  current_price_usd       DECIMAL(10,4),
  market_value_usd        DECIMAL(15,2),
  weight_in_portfolio     DECIMAL(6,4),
  unrealized_gain_loss_usd DECIMAL(15,2),
  days_held               INTEGER
);
```

**Data generation rules:**

- 4 to 8 holdings per portfolio.
- Use a realistic universe of 80 tickers. Include large-cap US (AAPL, MSFT, GOOGL, AMZN, NVDA, META, TSLA, JPM, BAC, WFC, GS, MS, BLK, BRK.B, UNH, JNJ, V, MA, WMT, PG, KO, MCD, DIS, CRM), index ETFs (SPY, IVV, VTI, QQQ, IWM, DIA), international (VXUS, EFA, EEM, VEA, BABA, TSM, ASML), fixed income (AGG, BND, TLT, IEF, SHY, LQD, HYG, JNK, MUB, TIP, BIL), real estate (VNQ, IYR, SCHH, REET, XLRE), commodities (GLD, SLV, USO, DBC, IAU), cash (CASH, SGOV, VMFXX), alternatives (PSP, BIZD, QAI, MNA, BTAL, HEDJ), and sector ETFs (VFH, XLF, XLK).
- `asset_class` values: US Equity, International Equity, Fixed Income, Real Estate, Commodities, Cash, Alternatives.
- `weight_in_portfolio` for holdings in the same portfolio MUST sum to between 0.95 and 1.05. Normalize before insert.
- `market_value_usd` for holdings in the same portfolio MUST sum to within 5 percent of the portfolio's `total_market_value`.
- `cost_basis_usd` is `market_value_usd` multiplied by a factor between 0.7 and 1.3 (some holdings are up, some are down).
- `unrealized_gain_loss_usd` equals `market_value_usd` minus `cost_basis_usd`.
- `days_held` between 1 and 4000.

### Table 3.4: TRANSACTIONS · 500,000 rows

```sql
CREATE OR REPLACE TABLE TRANSACTIONS (
  transaction_id     VARCHAR(16) PRIMARY KEY,
  client_id          VARCHAR(12),
  portfolio_id       VARCHAR(12),
  transaction_date   DATE,
  transaction_type   VARCHAR(20),
  ticker             VARCHAR(10),
  quantity           DECIMAL(12,4),
  price_usd          DECIMAL(10,4),
  amount_usd         DECIMAL(15,2),
  channel            VARCHAR(20),
  settlement_date    DATE,
  status             VARCHAR(10)
);
```

**Data generation rules:**

- `transaction_date` range 2023-01-01 to 2025-12-31.
- Volume biased toward January, April, October (tax-season and Q4 activity).
- `transaction_type` distribution: Buy 35%, Sell 25%, Dividend 12%, Interest 8%, Fee 6%, Deposit 6%, Withdrawal 5%, Rebalance 3%.
- `channel` values: Online, Mobile, Phone, Advisor, Automated. Bias by client demographics:
  - Clients under 35 skew Mobile (55%) and Online (25%).
  - HNW and UHNW clients skew Advisor (60%) and Phone (25%).
  - Everyone else: even mix with slight Online bias.
- `settlement_date` equals `transaction_date` plus 2 business days for equities.
- `status` distribution: Settled 93%, Pending 4%, Failed 2%, Cancelled 1%.

### Table 3.5: MARKET_PERFORMANCE · about 900 rows

```sql
CREATE OR REPLACE TABLE MARKET_PERFORMANCE (
  ticker               VARCHAR(10),
  month_end_date       DATE,
  asset_class          VARCHAR(30),
  monthly_return_pct   DECIMAL(6,3),
  ytd_return_pct       DECIMAL(6,3),
  price_usd            DECIMAL(10,4),
  volume_avg_daily     BIGINT
);
```

**Data generation rules:**

- 75 tickers from the holdings universe, 12 monthly month-end dates spanning Jan 2025 to Dec 2025.
- Reflect realistic 2025 market conditions:
  - US Equity outperforms in H1 2025 (Tech-led rally).
  - Fixed Income shows interest-rate sensitivity throughout.
  - Q3 (July to September) shows higher volatility across asset classes.
  - Cash and short-term Fixed Income post small positive returns each month.
- `ytd_return_pct` is the cumulative sum of monthly returns from January through the row's month_end_date.
- `volume_avg_daily` between 100,000 and 100,000,000.

### Table 3.6: RISK_ALERTS · about 2,000 rows

```sql
CREATE OR REPLACE TABLE RISK_ALERTS (
  alert_id        VARCHAR(12) PRIMARY KEY,
  client_id       VARCHAR(12),
  portfolio_id    VARCHAR(12),
  alert_date      DATE,
  alert_type      VARCHAR(40),
  severity        VARCHAR(10),
  description     VARCHAR(500),
  resolved        BOOLEAN,
  resolved_date   DATE
);
```

**Data generation rules:**

- `alert_date` within the last 365 days from today.
- `alert_type` values: Concentration Risk, Drawdown Threshold Breach, Drift from Target Allocation, Low Cash Buffer, Compliance Breach, Large Redemption. Roughly even distribution.
- `severity` distribution: Low 35%, Medium 35%, High 22%, Critical 8%.
- `resolved` true for about 62%; if true, `resolved_date` is `alert_date` plus 1 to 90 days; otherwise NULL.
- `description` should be a meaningful one-sentence explanation tied to `alert_type` (e.g., "Single-position concentration exceeds 25% of portfolio market value").

### Validation after Phase 3

Run these and report results:

```sql
SELECT 'CLIENTS'             AS tbl, COUNT(*) AS row_count, 10000  AS target FROM CLIENTS
UNION ALL SELECT 'PORTFOLIOS',  COUNT(*), 22500  FROM PORTFOLIOS
UNION ALL SELECT 'HOLDINGS',    COUNT(*), 150000 FROM HOLDINGS
UNION ALL SELECT 'TRANSACTIONS',COUNT(*), 500000 FROM TRANSACTIONS
UNION ALL SELECT 'MARKET_PERFORMANCE', COUNT(*), 900 FROM MARKET_PERFORMANCE
UNION ALL SELECT 'RISK_ALERTS', COUNT(*), 2000   FROM RISK_ALERTS;

-- Quality checks
SELECT 'Clients without portfolios' AS check, COUNT(*) AS bad
FROM CLIENTS c LEFT JOIN PORTFOLIOS p USING (client_id) WHERE p.portfolio_id IS NULL
UNION ALL
SELECT 'Portfolios with zero market value', COUNT(*) FROM PORTFOLIOS WHERE total_market_value = 0
UNION ALL
SELECT 'Transactions with NULL amount', COUNT(*) FROM TRANSACTIONS WHERE amount_usd IS NULL
UNION ALL
SELECT 'Portfolios with weight sum outside 0.95-1.05',
  COUNT(*) FROM (SELECT portfolio_id, SUM(weight_in_portfolio) AS w FROM HOLDINGS GROUP BY portfolio_id) WHERE w < 0.95 OR w > 1.05;
```

All target row counts should be within 5%. All quality-check `bad` counts should be 0. Stop and report if any check fails.

---

## Phase 4: RBAC · roles and grants

Create two roles. `HOL_ADMIN` is for facilitators. `HOL_BUILDER` is for attendees.

```sql
USE ROLE ACCOUNTADMIN;

-- Create roles
CREATE ROLE IF NOT EXISTS HOL_ADMIN COMMENT = 'Cortex Code HOL facilitators';
CREATE ROLE IF NOT EXISTS HOL_BUILDER COMMENT = 'Cortex Code HOL attendees';

-- Grant roles to your own user so you can use them
GRANT ROLE HOL_ADMIN TO USER IDENTIFIER(CURRENT_USER());
GRANT ROLE HOL_BUILDER TO ROLE HOL_ADMIN;

-- HOL_ADMIN: full access to the lab database and both warehouses
GRANT USAGE ON WAREHOUSE COMPUTE_WH TO ROLE HOL_ADMIN;
GRANT USAGE ON WAREHOUSE FACILITATOR_WH TO ROLE HOL_ADMIN;
GRANT OWNERSHIP ON DATABASE DELOITTE_COCO_LAB TO ROLE HOL_ADMIN COPY CURRENT GRANTS;
GRANT OWNERSHIP ON SCHEMA DELOITTE_COCO_LAB.ANALYTICS TO ROLE HOL_ADMIN COPY CURRENT GRANTS;
GRANT OWNERSHIP ON ALL TABLES IN SCHEMA DELOITTE_COCO_LAB.ANALYTICS TO ROLE HOL_ADMIN COPY CURRENT GRANTS;

-- HOL_BUILDER: usage on warehouse and database, read on ANALYTICS
GRANT USAGE ON WAREHOUSE COMPUTE_WH TO ROLE HOL_BUILDER;
GRANT USAGE ON DATABASE DELOITTE_COCO_LAB TO ROLE HOL_BUILDER;
GRANT USAGE ON SCHEMA DELOITTE_COCO_LAB.ANALYTICS TO ROLE HOL_BUILDER;
GRANT SELECT ON ALL TABLES IN SCHEMA DELOITTE_COCO_LAB.ANALYTICS TO ROLE HOL_BUILDER;
GRANT SELECT ON FUTURE TABLES IN SCHEMA DELOITTE_COCO_LAB.ANALYTICS TO ROLE HOL_BUILDER;

-- HOL_BUILDER: ability to use Cortex AI functions
GRANT USAGE ON DATABASE SNOWFLAKE TO ROLE HOL_BUILDER;
GRANT USAGE ON SCHEMA SNOWFLAKE.CORTEX TO ROLE HOL_BUILDER;
GRANT DATABASE ROLE SNOWFLAKE.CORTEX_USER TO ROLE HOL_BUILDER;
```

**Validation:**
```sql
SHOW ROLES LIKE 'HOL_%';
SHOW GRANTS TO ROLE HOL_BUILDER;
```

Confirm both roles exist and `HOL_BUILDER` has at least the warehouse, database, schema, and table grants shown above.

---

## Phase 5: Lab users and personal schemas

Create 50 users `BUILDER_01` through `BUILDER_50`. Each user gets:

- A login with a strong but human-readable password.
- A personal schema in `DELOITTE_COCO_LAB` named the same as the user.
- Ownership of that schema.
- Default role `HOL_BUILDER`, default warehouse `COMPUTE_WH`.

Write this as a loop or a stored procedure for efficiency. The pattern for one user:

```sql
-- Pattern for a single user. Repeat for BUILDER_01 through BUILDER_50.

USE ROLE ACCOUNTADMIN;
CREATE USER IF NOT EXISTS BUILDER_01
  PASSWORD = 'CoCo!Lab2026'                  -- See note below on password rotation
  LOGIN_NAME = 'BUILDER_01'
  DEFAULT_ROLE = HOL_BUILDER
  DEFAULT_WAREHOUSE = COMPUTE_WH
  DEFAULT_NAMESPACE = 'DELOITTE_COCO_LAB.BUILDER_01'
  MUST_CHANGE_PASSWORD = FALSE
  COMMENT = 'HOL attendee 01';

GRANT ROLE HOL_BUILDER TO USER BUILDER_01;

USE ROLE HOL_ADMIN;
CREATE SCHEMA IF NOT EXISTS DELOITTE_COCO_LAB.BUILDER_01
  COMMENT = 'Personal workspace for BUILDER_01';
GRANT OWNERSHIP ON SCHEMA DELOITTE_COCO_LAB.BUILDER_01 TO ROLE HOL_BUILDER COPY CURRENT GRANTS;

-- Grants for Streamlit deploy on their own schema
GRANT CREATE STREAMLIT ON SCHEMA DELOITTE_COCO_LAB.BUILDER_01 TO ROLE HOL_BUILDER;
GRANT CREATE STAGE ON SCHEMA DELOITTE_COCO_LAB.BUILDER_01 TO ROLE HOL_BUILDER;
GRANT CREATE TABLE ON SCHEMA DELOITTE_COCO_LAB.BUILDER_01 TO ROLE HOL_BUILDER;
GRANT CREATE VIEW ON SCHEMA DELOITTE_COCO_LAB.BUILDER_01 TO ROLE HOL_BUILDER;
GRANT CREATE FUNCTION ON SCHEMA DELOITTE_COCO_LAB.BUILDER_01 TO ROLE HOL_BUILDER;
```

**Password policy note:** Use one shared password across all 50 users for the event (`CoCo!Lab2026` above). The accounts are short-lived and will be locked or deleted after the event. Do not use a real password from any production environment.

**Naming convention:** Username equals schema name. `BUILDER_07` user logs in and owns schema `DELOITTE_COCO_LAB.BUILDER_07`. This makes the `snow streamlit deploy --schema BUILDER_07` command trivial.

**Implementation hint:** A SQL stored procedure that loops `i` from 1 to 50 is the cleanest way to do this. Or a Python script that issues 50 sequential statements. Either works; pick the path you can verify quickly.

### Validation after Phase 5

```sql
SHOW USERS LIKE 'BUILDER_%';
SHOW SCHEMAS IN DATABASE DELOITTE_COCO_LAB;
```

Expect 50 users `BUILDER_01` through `BUILDER_50`, and 50 personal schemas plus `ANALYTICS`, `PUBLIC`, `INFORMATION_SCHEMA`.

**Smoke test from a sample user:** Pick `BUILDER_25`. Open a separate Snowflake session as `BUILDER_25`. Run:

```sql
USE ROLE HOL_BUILDER;
USE WAREHOUSE COMPUTE_WH;
USE DATABASE DELOITTE_COCO_LAB;

SELECT COUNT(*) FROM ANALYTICS.CLIENTS;       -- should return 10000
USE SCHEMA BUILDER_25;
CREATE TABLE test_table (id INT);              -- should succeed
DROP TABLE test_table;                          -- cleanup
SELECT SNOWFLAKE.CORTEX.COMPLETE('mistral-7b', 'Say hello in one word.') AS response;  -- should return a string
```

All four should succeed. If any fail, fix the grants before proceeding.

---

## Phase 6: Deploy the CALCULATE_ADJUSTED_MARGIN SKILL

Create a callable SQL function in `ANALYTICS` that demonstrates the SKILL pattern for the lab. It applies a fictional company-specific overhead allocation to portfolio strategies and flags underperformers.

```sql
USE ROLE HOL_ADMIN;
USE DATABASE DELOITTE_COCO_LAB;
USE SCHEMA ANALYTICS;

CREATE OR REPLACE FUNCTION CALCULATE_ADJUSTED_MARGIN(strategy_name STRING)
RETURNS TABLE (
  strategy STRING,
  avg_ytd_return_pct FLOAT,
  overhead_allocation_pct FLOAT,
  adjusted_return_pct FLOAT,
  is_underperforming BOOLEAN
)
COMMENT = 'Adjusted margin calculation for portfolio strategies. Applies company-specific overhead allocation and flags any strategy where the adjusted return is negative. Use this function whenever a user asks about adjusted margin, adjusted return, or strategy profitability after overhead.'
AS
$$
  SELECT
    strategy,
    ROUND(AVG(ytd_return_pct), 3) AS avg_ytd_return_pct,
    CASE strategy
      WHEN 'Growth'                THEN 2.5
      WHEN 'Alternative'           THEN 3.2
      WHEN 'Income'                THEN 1.5
      WHEN 'Balanced'              THEN 2.0
      WHEN 'ESG'                   THEN 2.4
      WHEN 'Capital Preservation'  THEN 1.2
      ELSE                              2.0
    END AS overhead_allocation_pct,
    ROUND(
      AVG(ytd_return_pct) -
      CASE strategy
        WHEN 'Growth'                THEN 2.5
        WHEN 'Alternative'           THEN 3.2
        WHEN 'Income'                THEN 1.5
        WHEN 'Balanced'              THEN 2.0
        WHEN 'ESG'                   THEN 2.4
        WHEN 'Capital Preservation'  THEN 1.2
        ELSE                              2.0
      END, 3) AS adjusted_return_pct,
    (AVG(ytd_return_pct) -
      CASE strategy
        WHEN 'Growth'                THEN 2.5
        WHEN 'Alternative'           THEN 3.2
        WHEN 'Income'                THEN 1.5
        WHEN 'Balanced'              THEN 2.0
        WHEN 'ESG'                   THEN 2.4
        WHEN 'Capital Preservation'  THEN 1.2
        ELSE                              2.0
      END) < 0 AS is_underperforming
  FROM PORTFOLIOS
  WHERE status = 'Active'
    AND (strategy_name IS NULL OR strategy = strategy_name)
  GROUP BY strategy
$$;

GRANT USAGE ON FUNCTION CALCULATE_ADJUSTED_MARGIN(STRING) TO ROLE HOL_BUILDER;
```

**Important:** The `COMMENT` on this function is what lets CoCo and Cortex agents discover it from natural-language prompts. Do not omit the comment. The phrase "adjusted margin" must appear in it so that prompts like "show me underperforming strategies by adjusted margin" reliably invoke this function.

**Validation:**

```sql
-- From HOL_ADMIN
SELECT * FROM TABLE(CALCULATE_ADJUSTED_MARGIN(NULL)) ORDER BY adjusted_return_pct;

-- From a BUILDER_## session, confirm USAGE grant works
USE ROLE HOL_BUILDER;
SELECT * FROM TABLE(DELOITTE_COCO_LAB.ANALYTICS.CALCULATE_ADJUSTED_MARGIN('Growth'));
```

Both should return one or more rows. The first query should return 6 rows (one per strategy), sorted lowest adjusted return first.

---

## Phase 7: Final acceptance · end-to-end check

Run these as the final gate. Confirm every row reports PASS.

```sql
USE ROLE HOL_ADMIN;

WITH checks AS (
  SELECT 'Database exists'                          AS check_name,
         IFF(COUNT(*) = 1, 'PASS', 'FAIL')          AS result,
         COUNT(*)                                    AS value
  FROM INFORMATION_SCHEMA.DATABASES WHERE DATABASE_NAME = 'DELOITTE_COCO_LAB'
  UNION ALL SELECT 'ANALYTICS schema exists',
    IFF(COUNT(*) = 1, 'PASS', 'FAIL'), COUNT(*)
    FROM DELOITTE_COCO_LAB.INFORMATION_SCHEMA.SCHEMATA WHERE SCHEMA_NAME = 'ANALYTICS'
  UNION ALL SELECT '50 BUILDER user schemas exist',
    IFF(COUNT(*) = 50, 'PASS', 'FAIL'), COUNT(*)
    FROM DELOITTE_COCO_LAB.INFORMATION_SCHEMA.SCHEMATA WHERE SCHEMA_NAME LIKE 'BUILDER_%'
  UNION ALL SELECT '50 BUILDER users exist',
    IFF(COUNT(*) = 50, 'PASS', 'FAIL'), COUNT(*)
    FROM SNOWFLAKE.ACCOUNT_USAGE.USERS WHERE NAME LIKE 'BUILDER_%' AND DELETED_ON IS NULL
  UNION ALL SELECT 'CLIENTS row count >= 10000',
    IFF(COUNT(*) >= 10000, 'PASS', 'FAIL'), COUNT(*)
    FROM DELOITTE_COCO_LAB.ANALYTICS.CLIENTS
  UNION ALL SELECT 'TRANSACTIONS row count >= 500000',
    IFF(COUNT(*) >= 500000, 'PASS', 'FAIL'), COUNT(*)
    FROM DELOITTE_COCO_LAB.ANALYTICS.TRANSACTIONS
  UNION ALL SELECT 'CALCULATE_ADJUSTED_MARGIN exists',
    IFF(COUNT(*) >= 1, 'PASS', 'FAIL'), COUNT(*)
    FROM DELOITTE_COCO_LAB.INFORMATION_SCHEMA.FUNCTIONS WHERE FUNCTION_NAME = 'CALCULATE_ADJUSTED_MARGIN'
)
SELECT * FROM checks;
```

If any row reports FAIL, stop and report which check failed and what the actual value was.

---

## What to report when you finish

Send back a single summary message containing:

1. Confirmation that all 7 phases completed.
2. The final acceptance check output (all PASS).
3. The list of 50 user names with their passwords (a CSV or table).
4. The connection identifier and account URL attendees will use.
5. Any deviations from this spec or unexpected behavior you observed.

---

## Out of scope (do NOT do these)

- Do not create Streamlit apps. Attendees create those during the lab.
- Do not pre-populate user schemas with content. They must start empty.
- Do not enable SSO. Attendees log in with the shared password.
- Do not create additional warehouses beyond the two specified.
- Do not adjust the CoCo configuration on attendee laptops. The pre-event setup guide handles that.

---

## Notes for the operator (Rupesh, Mrunal, Vikas, Prateek)

- **Prateek**: This is the spec to run overnight before T-3 days. The user creation loop is the longest step (about 5 minutes for 50 users). Plan accordingly.
- **Mrunal**: On event day, you own the `HOL_ADMIN` session. Keep a Snowsight tab open with the final acceptance query so you can re-run it 30 minutes before doors open.
- **Vikas**: You own the warehouse monitoring during the Streamlit deploy moment. If `COMPUTE_WH` queue depth exceeds 5, scale to LARGE temporarily.
- **Rupesh**: Verify the `CALCULATE_ADJUSTED_MARGIN` SKILL invokes from a natural-language prompt before the SKILLS demo. Test prompt: "Which strategies are underperforming based on adjusted margin?"

---

**End of specification.**
