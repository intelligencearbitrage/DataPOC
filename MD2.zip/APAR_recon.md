# AP/AR Reconciliation Prototype — Full Specification

**Version:** 1.0  
**Author:** Rupesh Dandekar  
**Date:** May 2026  
**Status:** Draft — Pre-Build  

---

## Table of Contents

1. [Prototype Objectives](#1-prototype-objectives)
2. [Scope and Boundaries](#2-scope-and-boundaries)
3. [Synthetic Dataset Specification](#3-synthetic-dataset-specification)
4. [Data Structures](#4-data-structures)
5. [Matching Engine Rules](#5-matching-engine-rules)
6. [Root Cause Classification Rules](#6-root-cause-classification-rules)
7. [AI Rationale Generation Rules](#7-ai-rationale-generation-rules)
8. [UI Page Specifications](#8-ui-page-specifications)
9. [Technology Stack](#9-technology-stack)
10. [Build Sequence](#10-build-sequence)
11. [Out of Scope — Phase 2](#11-out-of-scope--phase-2)

---

## 1. Prototype Objectives

### 1.1 The Single Demo Moment

The prototype must prove one thing: an AI system can take a bank statement line with a truncated memo, a partial payment, and a timing gap — and correctly link it to the right invoice with a plain-English explanation of why. Every build decision flows from that proof point.

### 1.2 Target Audience

| Role | What They Need to See |
|---|---|
| AP/AR Analyst | An exception queue that explains *why* something broke, not just *that* it broke |
| Controller / Finance Manager | Auto-match rate improvement and an auditable approval trail |
| Internal Auditor | Confidence score breakdown and match rationale for every automated decision |
| CFO / CTO (sponsor) | Trend intelligence showing the system learns and prevents future breaks |

### 1.3 Success Criteria

- Auto-match rate on engineered synthetic data: **≥ 85%**
- Exception root cause correctly classified: **≥ 90%** on test scenarios
- Every automated match has a machine-generated plain-English rationale
- The demo runs end-to-end in under 8 minutes without live data dependency

---

## 2. Scope and Boundaries

### 2.1 In Scope — v1 Prototype

- AP/AR reconciliation: GL invoice extract vs bank statement
- Single entity, single currency (USD)
- Five exception scenario types (detailed in Section 3)
- Four UI pages (Dashboard, Match Workbench, Exception Workbench, Analytics)
- Synthetic dataset generation and loading
- Python matching engine with confidence scoring
- Streamlit-based UI
- AI rationale generation (rule-based in v1, LLM-enhanced in v2)

### 2.2 Hard Exclusions — v1

The following are **Phase 2 talking points during the demo only**. Do not build them.

- User authentication or role-based access
- ERP write-back or journal entry creation
- ISO 20022 / camt.053 XML parsing
- Multi-entity or intercompany flows
- Multi-currency reconciliation
- Live bank feed integration
- Agentic AI orchestration
- Mobile-responsive layout

---

## 3. Synthetic Dataset Specification

### 3.1 Dataset Overview

| Parameter | Value |
|---|---|
| Total GL Invoice records | 500 |
| Total Bank Statement records | 512 |
| Target auto-match rate | ~85% (425 clean matches) |
| Engineered fuzzy/exception scenarios | ~15% (75 records) |
| Duplicate bank records (suppressed) | 12 |
| Bank records with no GL match | 8 (genuine timing gaps) |
| Time window | Rolling 30-day period |
| Currency | USD only |
| Vendors | 25 distinct vendors |

The 12 additional bank records (512 vs 500) represent duplicates and bank-side entries (fees, reversals) that have no GL counterpart. This tests the system's ability to detect and suppress duplicates and handle bank-initiated transactions.

---

### 3.2 GL Invoice Dataset Schema

**File:** `gl_invoices.csv`

| Field Name | Data Type | Format | Description | Example |
|---|---|---|---|---|
| `invoice_id` | String | `INV-NNNN` | Unique invoice identifier | `INV-0042` |
| `vendor_id` | String | `VND-NN` | Vendor reference | `VND-07` |
| `vendor_name` | String | Free text | Full legal vendor name | `Amazon Web Services LLC` |
| `invoice_date` | Date | `YYYY-MM-DD` | Date invoice was raised | `2026-04-15` |
| `due_date` | Date | `YYYY-MM-DD` | Payment due date | `2026-04-30` |
| `amount` | Decimal | `NNNNNN.NN` | Invoice amount in USD | `10000.00` |
| `gl_account` | String | `NNNN` | General ledger account code | `5100` |
| `cost_center` | String | `CC-NNN` | Business unit cost center | `CC-042` |
| `description` | String | Free text | Invoice line description | `Cloud infrastructure services - April 2026` |
| `status` | Enum | `OPEN / PAID / PARTIAL` | Payment status | `OPEN` |
| `po_number` | String | `PO-NNNN` (nullable) | Purchase order reference | `PO-1188` |
| `entity` | String | Fixed | Legal entity | `BANK_NA` |

---

### 3.3 Bank Statement Dataset Schema

**File:** `bank_statement.csv`

| Field Name | Data Type | Format | Description | Example |
|---|---|---|---|---|
| `bank_ref` | String | `TXN-NNNNNN` | Bank-assigned transaction ID | `TXN-884521` |
| `value_date` | Date | `YYYY-MM-DD` | Date funds settled at bank | `2026-04-17` |
| `posting_date` | Date | `YYYY-MM-DD` | Date posted to statement | `2026-04-17` |
| `debit_amount` | Decimal | `NNNNNN.NN` (nullable) | Outgoing amount | `null` |
| `credit_amount` | Decimal | `NNNNNN.NN` (nullable) | Incoming amount | `10000.00` |
| `net_amount` | Decimal | Signed | Signed net value | `10000.00` |
| `description` | String | Free text, often truncated | Bank memo field (max 35 chars) | `AMZN WEB SVCS INV0042` |
| `counterparty_name` | String | Free text (nullable) | Counterparty as reported | `AMAZON WEB SVC` |
| `payment_method` | Enum | `ACH / WIRE / CHECK / CARD` | Settlement method | `ACH` |
| `currency` | String | ISO 4217 | Transaction currency | `USD` |
| `bank_account` | String | `ACCT-NNNN` | Bank account number (masked) | `ACCT-4421` |
| `is_duplicate` | Boolean | `true/false` | Engineered duplicate flag | `false` |

---

### 3.4 Scenario Engineering

The 75 exception/fuzzy records are distributed across five scenario types. Each scenario is pre-engineered with a known ground truth to validate root cause classification accuracy.

---

#### Scenario A: Timing Difference (20 records)

**Description:** GL invoice exists. Bank payment exists. Amounts match exactly. Settlement arrived 2–5 days after the invoice date, crossing a period boundary.

**Engineering rules:**
- `gl_invoices.invoice_date` = Day N
- `bank_statement.value_date` = Day N+2 to Day N+5
- Amounts identical: `gl_invoices.amount` == `bank_statement.credit_amount`
- `bank_statement.description` contains a recognizable (but not exact) reference to `invoice_id`

**Example pair:**

```
GL:   INV-0088 | VND-03 | Cisco Systems Inc | 2026-04-28 | $45,200.00
Bank: TXN-991022 | 2026-05-02 | CISCO SYS PMT APR | $45,200.00
```

**Expected root cause label:** `Timing Difference`  
**Expected AI confidence:** 82–91%

---

#### Scenario B: Fee Variance (18 records)

**Description:** GL invoice and bank payment exist. Bank amount is slightly less than the invoice amount due to wire processing or ACH fees deducted in transit.

**Engineering rules:**
- `bank_statement.credit_amount` = `gl_invoices.amount` − fee
- Fee range: $8.00 to $45.00 (drawn from a fixed fee schedule per payment method)
- Fee schedule: ACH = $8–$15, WIRE domestic = $20–$35, WIRE international = $35–$45
- `description` on bank side is truncated and doesn't contain full invoice ID

**Fee schedule table (for matching rule engine):**

| Payment Method | Fee Min | Fee Max | Tolerance Applied |
|---|---|---|---|
| ACH | $8.00 | $15.00 | $0–$20 |
| WIRE (domestic) | $20.00 | $35.00 | $0–$40 |
| WIRE (international) | $35.00 | $45.00 | $0–$50 |
| CHECK | $0.00 | $0.00 | $0–$1 |
| CARD | $0.00 | $5.00 | $0–$10 |

**Example pair:**

```
GL:   INV-0211 | VND-12 | SWIFT Global Payments | $28,000.00
Bank: TXN-774312 | SWFT GLBL PAY | $27,968.00 | (Difference: $32.00 — WIRE domestic fee)
```

**Expected root cause label:** `Fee Variance`  
**Expected AI confidence:** 88–95%

---

#### Scenario C: Truncated / Corrupted Reference (17 records)

**Description:** The bank memo field is limited to 35 characters. Invoice IDs and vendor names are cut off, transposed, or abbreviated in ways that prevent exact matching.

**Engineering rules:**
- Apply one of four truncation patterns per record:
  - **Type C1:** Remove hyphens — `INV-0042` becomes `INV0042`
  - **Type C2:** Truncate suffix — `INV-0042-FINAL` becomes `INV-0042`
  - **Type C3:** Abbreviate vendor — `Amazon Web Services LLC` becomes `AMZN WEB SVC`
  - **Type C4:** Transposed digits — `INV-0042` becomes `INV-0024`
- Amounts match exactly
- Dates match exactly or within 1 day

**Reference corruption map (for ground truth validation):**

| GL Invoice ID | Bank Description (corrupted) | Corruption Type |
|---|---|---|
| `INV-0042` | `INV0042` | C1 — Hyphen removal |
| `INV-0155-FINAL` | `INV-0155` | C2 — Suffix truncation |
| `Amazon Web Services LLC` | `AMZN WEB SVC` | C3 — Abbreviation |
| `INV-0301` | `INV-0310` | C4 — Digit transposition |

**Expected root cause label:** `Truncated Reference`  
**Expected AI confidence:** 74–88% (lower confidence reflects genuine ambiguity)

---

#### Scenario D: Partial Payment (12 records)

**Description:** A single GL invoice is partially paid. The bank credit is 40–95% of the invoice amount. The invoice status must be updated to `PARTIAL`.

**Engineering rules:**
- `bank_statement.credit_amount` = `gl_invoices.amount` × payment_ratio
- `payment_ratio` range: 0.40 to 0.95 (drawn uniformly)
- A second bank record (the remaining balance) may or may not exist within the dataset window — 6 of 12 will have a second payment, 6 will not
- `gl_invoices.status` set to `PARTIAL`
- Memo on bank side references invoice ID clearly

**Example pair:**

```
GL:   INV-0390 | VND-19 | Oracle Corporation | $120,000.00 | OPEN
Bank: TXN-662891 | ORACLE CORP INV-0390 PART1 | $72,000.00 | (60% of invoice)
```

**Expected root cause label:** `Partial Payment`  
**Expected AI confidence:** 91–97% (amount ratio and description alignment are strong signals)

---

#### Scenario E: Genuine Exception / Unknown (8 records)

**Description:** Bank credits with no GL counterpart within the dataset window. These are intentionally unresolvable and should surface as `Unknown` root cause requiring human investigation.

**Engineering rules:**
- No matching GL invoice exists in the dataset
- Amounts are plausible (within vendor typical range) but references are non-matching
- 4 records represent payments received early (pre-invoice — genuine timing gap)
- 4 records represent unidentified credits requiring manual investigation

**Expected root cause label:** `Unknown`  
**Expected action:** Flag for human assignment, do not auto-match

---

### 3.5 Vendor Reference Table

All 25 vendors with their canonical names, common abbreviations, and typical payment patterns. This table is used by the matching engine's vendor normalization layer.

| Vendor ID | Canonical Name | Common Abbreviations | Typical Settlement (days) | Payment Method | Avg Invoice Size |
|---|---|---|---|---|---|
| VND-01 | Amazon Web Services LLC | AMZN WEB SVC, AWS | 2 | ACH | $8,500 |
| VND-02 | Microsoft Corporation | MSFT, MICROSOFT CORP | 1 | ACH | $12,000 |
| VND-03 | Cisco Systems Inc | CISCO SYS, CISCO | 3 | WIRE | $45,000 |
| VND-04 | Oracle Corporation | ORACLE CORP, ORC | 2 | WIRE | $95,000 |
| VND-05 | Salesforce Inc | SFDC, SALESFORCE | 1 | ACH | $7,200 |
| VND-06 | IBM Corporation | IBM CORP | 5 | WIRE | $38,000 |
| VND-07 | SAP America Inc | SAP AMER | 3 | WIRE | $55,000 |
| VND-08 | Deloitte & Touche LLP | DELOITTE, D&T LLP | 30 | CHECK | $125,000 |
| VND-09 | SWIFT Global Payments | SWFT GLBL PAY | 2 | WIRE | $28,000 |
| VND-10 | FIS Global | FIS GLOBAL, FIS | 2 | ACH | $15,500 |
| VND-11 | Fiserv Inc | FISERV, FSV | 3 | ACH | $11,200 |
| VND-12 | Jack Henry Associates | JACK HENRY, JHA | 4 | ACH | $9,800 |
| VND-13 | Temenos AG | TEMENOS | 5 | WIRE | $72,000 |
| VND-14 | nCino Inc | NCINO | 2 | ACH | $18,000 |
| VND-15 | Broadridge Financial | BROADRIDGE, BRD | 3 | WIRE | $34,000 |
| VND-16 | S&P Global Inc | S&P GLOBAL, SPGI | 2 | ACH | $6,400 |
| VND-17 | Moody's Analytics | MOODYS ANALY | 2 | ACH | $5,900 |
| VND-18 | Bloomberg Finance LP | BLOOMBERG FIN | 1 | ACH | $22,000 |
| VND-19 | Refinitiv (LSEG) | REFINITIV, LSEG | 2 | ACH | $19,500 |
| VND-20 | Workday Inc | WORKDAY | 1 | ACH | $14,200 |
| VND-21 | ServiceNow Inc | SERVICENOW, SNOW | 1 | ACH | $8,900 |
| VND-22 | Verint Systems | VERINT SYS | 4 | WIRE | $31,000 |
| VND-23 | NICE Systems Ltd | NICE SYS | 5 | WIRE | $27,500 |
| VND-24 | Pegasystems Inc | PEGA, PEGASYS | 3 | WIRE | $41,000 |
| VND-25 | Wolters Kluwer NV | WOLTERS KLW | 3 | WIRE | $16,800 |

---

### 3.6 Synthetic Data Generation Script (Python)

**File:** `generate_synthetic_data.py`

```python
"""
Synthetic Data Generator — AP/AR Reconciliation Prototype
Generates gl_invoices.csv and bank_statement.csv with engineered scenarios.
"""

import pandas as pd
import numpy as np
import random
from datetime import datetime, timedelta
import uuid

# ── Configuration ────────────────────────────────────────────────────────────
SEED = 42
NUM_CLEAN = 425           # exact / near-exact matches
NUM_SCENARIO_A = 20       # timing difference
NUM_SCENARIO_B = 18       # fee variance
NUM_SCENARIO_C = 17       # truncated reference
NUM_SCENARIO_D = 12       # partial payment
NUM_SCENARIO_E = 8        # genuine exception
NUM_DUPLICATES = 12       # duplicate bank entries
BASE_DATE = datetime(2026, 4, 1)
WINDOW_DAYS = 30

random.seed(SEED)
np.random.seed(SEED)

# ── Vendor table ─────────────────────────────────────────────────────────────
VENDORS = [
    {"id": "VND-01", "name": "Amazon Web Services LLC",
     "abbr": ["AMZN WEB SVC", "AWS"], "method": "ACH",  "settle": 2,  "avg": 8500},
    {"id": "VND-02", "name": "Microsoft Corporation",
     "abbr": ["MSFT", "MICROSOFT CORP"],  "method": "ACH",  "settle": 1,  "avg": 12000},
    {"id": "VND-03", "name": "Cisco Systems Inc",
     "abbr": ["CISCO SYS", "CISCO"],      "method": "WIRE", "settle": 3,  "avg": 45000},
    {"id": "VND-04", "name": "Oracle Corporation",
     "abbr": ["ORACLE CORP", "ORC"],      "method": "WIRE", "settle": 2,  "avg": 95000},
    {"id": "VND-05", "name": "Salesforce Inc",
     "abbr": ["SFDC", "SALESFORCE"],      "method": "ACH",  "settle": 1,  "avg": 7200},
    # ... remaining 20 vendors follow same pattern
]

FEE_SCHEDULE = {
    "ACH":  (8.0, 15.0),
    "WIRE": (20.0, 35.0),
    "CHECK":(0.0,  0.0),
    "CARD": (0.0,  5.0),
}

def random_date(base, window=30):
    return base + timedelta(days=random.randint(0, window))

def make_invoice_id(n):
    return f"INV-{n:04d}"

def make_bank_ref():
    return f"TXN-{random.randint(100000, 999999)}"

def truncate_description(name, inv_id, corruption_type):
    """Apply corruption pattern for Scenario C."""
    if corruption_type == "C1":
        return inv_id.replace("-", "")[:35]
    elif corruption_type == "C2":
        return inv_id.split("-FINAL")[0][:35]
    elif corruption_type == "C3":
        # Use vendor abbreviation
        vendor = next((v for v in VENDORS if v["name"] == name), None)
        return random.choice(vendor["abbr"])[:35] if vendor else name[:35]
    elif corruption_type == "C4":
        # Transpose last two digits
        parts = inv_id.split("-")
        if len(parts[-1]) >= 2:
            digits = list(parts[-1])
            digits[-1], digits[-2] = digits[-2], digits[-1]
            parts[-1] = "".join(digits)
        return "-".join(parts)[:35]
    return f"{name[:15]} {inv_id}"[:35]

# ── Main generation logic ─────────────────────────────────────────────────────
gl_records = []
bank_records = []
invoice_counter = 1

def add_pair(scenario, vendor, amount, gl_date, bank_date, gl_desc, bank_desc,
             gl_status="OPEN", bank_amount=None, is_dup=False):
    global invoice_counter
    inv_id = make_invoice_id(invoice_counter)
    invoice_counter += 1
    bank_amount = bank_amount if bank_amount is not None else amount
    po = f"PO-{random.randint(1000, 9999)}" if random.random() > 0.3 else None

    gl_records.append({
        "invoice_id": inv_id, "vendor_id": vendor["id"],
        "vendor_name": vendor["name"], "invoice_date": gl_date.strftime("%Y-%m-%d"),
        "due_date": (gl_date + timedelta(days=30)).strftime("%Y-%m-%d"),
        "amount": round(amount, 2), "gl_account": random.choice(["5100","5200","6100","6210"]),
        "cost_center": f"CC-{random.randint(1,99):03d}",
        "description": gl_desc, "status": gl_status,
        "po_number": po, "entity": "BANK_NA", "scenario": scenario
    })
    bank_records.append({
        "bank_ref": make_bank_ref(), "value_date": bank_date.strftime("%Y-%m-%d"),
        "posting_date": bank_date.strftime("%Y-%m-%d"),
        "debit_amount": None, "credit_amount": round(bank_amount, 2),
        "net_amount": round(bank_amount, 2),
        "description": bank_desc[:35], "counterparty_name": vendor["name"][:30],
        "payment_method": vendor["method"], "currency": "USD",
        "bank_account": "ACCT-4421", "is_duplicate": is_dup,
        "scenario": scenario, "matched_invoice": inv_id
    })

# Generate clean records (Scenario 0)
for _ in range(NUM_CLEAN):
    v = random.choice(VENDORS)
    amt = round(v["avg"] * random.uniform(0.5, 2.0), 2)
    d = random_date(BASE_DATE)
    add_pair("CLEAN", v, amt, d, d + timedelta(days=v["settle"]),
             f"{v['name']} services",
             f"{v['name'][:15]} {make_invoice_id(invoice_counter)}")

# ... Scenario A–E generation follows same pattern with rules applied

# ── Output ────────────────────────────────────────────────────────────────────
gl_df = pd.DataFrame(gl_records).drop(columns=["scenario"])
bank_df = pd.DataFrame(bank_records).drop(columns=["scenario", "matched_invoice"])

gl_df.to_csv("gl_invoices.csv", index=False)
bank_df.to_csv("bank_statement.csv", index=False)

# Save ground truth separately for validation only
ground_truth = pd.DataFrame([
    {"invoice_id": g["invoice_id"], "bank_ref": b["bank_ref"],
     "scenario": g["scenario"], "expected_root_cause": g["scenario"]}
    for g, b in zip(gl_records, bank_records)
])
ground_truth.to_csv("ground_truth.csv", index=False)

print(f"Generated {len(gl_df)} GL records and {len(bank_df)} bank records.")
```

---

## 4. Data Structures

### 4.1 MatchResult Object

The core output of the matching engine. One record per candidate match pair.

```python
@dataclass
class MatchResult:
    match_id: str                    # UUID generated at match time
    invoice_id: str                  # GL invoice reference
    bank_ref: str                    # Bank transaction reference
    
    # Score components (each 0.0 to 1.0)
    amount_score: float              # Exact=1.0, within tolerance=0.7-0.99, outside=0.0
    date_score: float                # Same day=1.0, decays by 0.05 per day gap, floor=0.5
    reference_score: float           # Levenshtein/Jaro-Winkler similarity
    vendor_score: float              # Vendor name match using abbreviation table
    
    # Derived fields
    confidence_score: float          # Weighted composite (see Section 5.4)
    match_type: str                  # EXACT | FUZZY | AI_ASSISTED
    match_status: str                # AUTO_APPROVED | PENDING_REVIEW | EXCEPTION
    
    # Amount delta
    amount_delta: float              # bank_amount - gl_amount (signed)
    date_delta_days: int             # bank_date - gl_date (signed integer)
    
    # Root cause (populated only for exceptions)
    root_cause: str                  # See Section 6 enum
    root_cause_confidence: float     # Confidence in root cause classification
    
    # Explanation
    rationale: str                   # Plain-English match explanation
    suggested_action: str            # Recommended resolution
    
    # Audit
    created_at: datetime
    reviewed_by: str                 # NULL if auto-approved
    reviewed_at: datetime            # NULL if auto-approved
    review_decision: str             # APPROVED | REJECTED | ESCALATED
```

---

### 4.2 Exception Object

```python
@dataclass
class Exception:
    exception_id: str                # UUID
    source: str                      # GL | BANK (which side has no match)
    source_ref: str                  # invoice_id or bank_ref
    amount: float
    transaction_date: date
    description: str
    
    root_cause: str                  # See Section 6
    root_cause_confidence: float
    root_cause_evidence: str         # Plain-English evidence string
    
    candidate_match_id: str          # Best candidate match (nullable)
    candidate_confidence: float      # Confidence of candidate (nullable)
    
    suggested_resolution: str
    suggested_gl_account: str        # For fee write-offs
    
    age_days: int                    # Days since transaction date
    assigned_to: str                 # NULL if unassigned
    status: str                      # OPEN | IN_REVIEW | RESOLVED | WRITTEN_OFF
    priority: str                    # HIGH | MEDIUM | LOW (based on amount + age)
    
    created_at: datetime
    resolved_at: datetime
    resolution_notes: str
```

---

### 4.3 ReconciliationRun Object

```python
@dataclass
class ReconciliationRun:
    run_id: str                      # UUID
    run_date: datetime
    gl_file: str                     # Source filename
    bank_file: str                   # Source filename
    
    total_gl_records: int
    total_bank_records: int
    
    exact_matches: int
    fuzzy_matches: int
    ai_assisted_matches: int
    auto_approved: int
    pending_review: int
    exceptions: int
    duplicates_suppressed: int
    
    auto_match_rate: float           # (exact + fuzzy + ai_assisted) / total_gl_records
    total_variance: float            # Sum of |amount_delta| across all matches
    
    processing_time_seconds: float
    status: str                      # RUNNING | COMPLETE | FAILED
```

---

### 4.4 DashboardMetrics Object

```python
@dataclass
class DashboardMetrics:
    run_id: str
    auto_match_rate: float
    total_transactions: int
    matched_count: int
    pending_review_count: int
    exception_count: int
    outstanding_variance: float
    
    # Match type breakdown (for chart)
    exact_match_count: int
    fuzzy_match_count: int
    ai_assisted_count: int
    
    # Exception breakdown by root cause (for heat map)
    timing_difference_count: int
    fee_variance_count: int
    truncated_reference_count: int
    partial_payment_count: int
    unknown_count: int
    
    # Recent activity (last 10 system events)
    activity_feed: list[str]
```

---

## 5. Matching Engine Rules

### 5.1 Pass 1 — Exact Match

**Criteria:** All three conditions must be true simultaneously.

| Field | Match Condition | Tolerance |
|---|---|---|
| `amount` | Exact numeric equality | ±$0.00 |
| `invoice_id` / `description` | Exact string match after normalization | None |
| `date` | GL date within bank value_date ± 0 days | 0 days |

**Normalization applied before exact match:**
- Strip leading/trailing whitespace
- Uppercase all strings
- Remove hyphens, dots, and slashes from reference fields
- Strip currency symbols

**Outcome:** Matched pairs are marked `EXACT`, confidence = `1.0`, status = `AUTO_APPROVED`.

---

### 5.2 Pass 2 — Fuzzy Match

Applied to all records not resolved in Pass 1.

#### 5.2.1 Vendor Name Normalization

Before any string comparison, apply vendor abbreviation lookup:

```python
def normalize_vendor(name: str, vendor_table: list) -> str:
    name_upper = name.upper().strip()
    for vendor in vendor_table:
        if name_upper == vendor["name"].upper():
            return vendor["id"]
        for abbr in vendor["abbr"]:
            if abbr.upper() in name_upper or name_upper in abbr.upper():
                return vendor["id"]
    return name_upper  # return normalized if no table match
```

#### 5.2.2 Reference ID Matching

Apply in order; use the highest score returned:

| Algorithm | Implementation | Threshold to Consider |
|---|---|---|
| Exact (post-normalization) | `str_a == str_b` | Score = 1.0 |
| Levenshtein Distance | `Levenshtein.ratio(str_a, str_b)` | Score > 0.70 |
| Jaro-Winkler | `jellyfish.jaro_winkler(str_a, str_b)` | Score > 0.75 |
| Token Set Ratio | `fuzz.token_set_ratio(str_a, str_b) / 100` | Score > 0.65 |

```python
def reference_score(ref_a: str, ref_b: str) -> float:
    ref_a = normalize_ref(ref_a)
    ref_b = normalize_ref(ref_b)
    scores = [
        1.0 if ref_a == ref_b else 0.0,
        Levenshtein.ratio(ref_a, ref_b),
        jellyfish.jaro_winkler_similarity(ref_a, ref_b),
        fuzz.token_set_ratio(ref_a, ref_b) / 100
    ]
    return max(scores)
```

#### 5.2.3 Date Proximity Score

```python
def date_score(gl_date: date, bank_date: date) -> float:
    delta = abs((bank_date - gl_date).days)
    if delta == 0:
        return 1.0
    elif delta <= 2:
        return 0.90
    elif delta <= 5:
        return 0.75
    elif delta <= 10:
        return 0.60
    else:
        return 0.40   # still a candidate but penalized heavily
```

#### 5.2.4 Amount Tolerance Score

```python
def amount_score(gl_amount: float, bank_amount: float,
                 payment_method: str, fee_schedule: dict) -> float:
    delta = abs(gl_amount - bank_amount)
    if delta == 0.0:
        return 1.0
    fee_min, fee_max = fee_schedule.get(payment_method, (0, 0))
    tolerance = fee_max * 1.2   # 20% buffer above max fee
    if delta <= 1.0:
        return 0.97              # rounding difference
    elif delta <= tolerance:
        ratio = 1.0 - (delta / (tolerance * 2))
        return max(0.60, ratio)
    elif gl_amount > 0 and (delta / gl_amount) <= 0.10:
        return 0.50              # within 10% — partial payment candidate
    else:
        return 0.0               # outside tolerance, exclude
```

---

### 5.3 Pass 3 — Candidate Ranking

After computing individual field scores, rank candidate matches per GL invoice:

```python
def rank_candidates(gl_record, bank_candidates, weights):
    scored = []
    for bank in bank_candidates:
        vs = vendor_score(gl_record, bank)
        rs = reference_score(gl_record["invoice_id"], bank["description"])
        ds = date_score(gl_record["invoice_date"], bank["value_date"])
        ams = amount_score(gl_record["amount"], bank["credit_amount"],
                           bank["payment_method"], FEE_SCHEDULE)
        composite = (
            weights["amount"]    * ams +
            weights["date"]      * ds  +
            weights["reference"] * rs  +
            weights["vendor"]    * vs
        )
        scored.append((bank, composite, vs, rs, ds, ams))
    return sorted(scored, key=lambda x: x[1], reverse=True)
```

---

### 5.4 Confidence Score Weights

| Component | Weight | Rationale |
|---|---|---|
| Amount match | 0.40 | Financial accuracy is non-negotiable |
| Date proximity | 0.25 | Settlement timing is the second most reliable signal |
| Reference match | 0.20 | Often corrupted, so down-weighted relative to amount |
| Vendor match | 0.15 | Usually reliable but least specific in isolation |
| **Total** | **1.00** | |

---

### 5.5 Auto-Approval and Routing Thresholds

| Confidence Score | Match Type Assigned | Status | Action |
|---|---|---|---|
| ≥ 0.97 | `EXACT` | `AUTO_APPROVED` | No human review required |
| 0.90 – 0.96 | `FUZZY` | `AUTO_APPROVED` | Logged for audit, no review needed |
| 0.80 – 0.89 | `AI_ASSISTED` | `PENDING_REVIEW` | Routed to analyst queue |
| 0.60 – 0.79 | `AI_ASSISTED` | `PENDING_REVIEW` | Routed to analyst queue with flag |
| < 0.60 | N/A | `EXCEPTION` | No match assigned, root cause triggered |

**Hard rules overriding thresholds:**

- Any match where `amount_delta > $5,000` is forced to `PENDING_REVIEW` regardless of overall confidence score
- Any match where `date_delta_days > 10` is forced to `PENDING_REVIEW`
- Any record matching a known duplicate pattern is suppressed before scoring and logged separately

---

## 6. Root Cause Classification Rules

Applied to all records with `status = EXCEPTION` (confidence < 0.60 with no accepted candidate).

### 6.1 Root Cause Decision Tree

```
START
│
├─ Does a candidate match exist with confidence 0.40–0.59?
│   ├─ YES → Run root cause sub-classifier (below)
│   └─ NO  → Root cause = UNKNOWN, confidence = N/A
│
└─ Root cause sub-classifier:
    │
    ├─ Is amount_delta within payment method fee tolerance?
    │   └─ YES → Root cause = FEE_VARIANCE
    │
    ├─ Is amount_delta 5–60% of GL amount?
    │   └─ YES → Root cause = PARTIAL_PAYMENT
    │
    ├─ Is reference_score < 0.65 but vendor_score > 0.80 and amount_score = 1.0?
    │   └─ YES → Root cause = TRUNCATED_REFERENCE
    │
    ├─ Is vendor_score > 0.70 and amount_score = 1.0 and date_delta_days 2–10?
    │   └─ YES → Root cause = TIMING_DIFFERENCE
    │
    └─ None of the above → Root cause = UNKNOWN
```

### 6.2 Root Cause Enum and Suggested Actions

| Root Cause Label | Evidence Pattern | Suggested Resolution | Suggested GL Account |
|---|---|---|---|
| `TIMING_DIFFERENCE` | Exact amount, vendor match, date gap 2–10 days | Re-run reconciliation next period; no action needed if within settlement window | N/A |
| `FEE_VARIANCE` | Amount short by $8–$45, matches fee schedule for payment method | Approve match with fee write-off | 6210 – Bank Charges |
| `TRUNCATED_REFERENCE` | Amount and vendor match; reference string similarity 0.60–0.85 | Approve match; update bank instruction template | N/A |
| `PARTIAL_PAYMENT` | Bank amount is 40–95% of GL invoice amount | Match to invoice; flag remaining balance as open | N/A |
| `DUPLICATE_RISK` | Two bank records with same amount, vendor, and date ±1 day | Suppress second record; alert treasury | N/A |
| `UNKNOWN` | No candidate match; no pattern matches above rules | Assign to analyst; request remittance advice | TBD |

---

## 7. AI Rationale Generation Rules

For each match or exception, the system generates a plain-English rationale string. In v1, this is template-driven. In v2, an LLM generates this dynamically.

### 7.1 Rationale Templates by Match Type

**EXACT match:**
> "Amount ($`{amount}`), reference ID (`{ref_match}`), and date (`{date}`) match exactly across GL and bank records. Auto-approved."

**FUZZY match — fee variance:**
> "GL Invoice `{invoice_id}` (`{vendor_name}`) was for `${gl_amount}`. Bank credit is `${bank_amount}` — a difference of `${delta}`, consistent with the `{payment_method}` processing fee range of `${fee_min}`–`${fee_max}` observed for this vendor corridor. Vendor name match: `{vendor_score_pct}`%. Reference score: `{ref_score_pct}`%. Recommended action: approve with fee write-off to account 6210."

**FUZZY match — timing difference:**
> "Amount matches exactly (`${amount}`). Vendor match confirmed (`{vendor_name}` → `{bank_counterparty}`, `{vendor_score_pct}`% similarity). Bank value date is `{date_delta}` days after invoice date — within the observed `{settle_days}`-day settlement window for `{vendor_name}`. Reference match: `{ref_score_pct}`%."

**FUZZY match — truncated reference:**
> "Amount and vendor match with high confidence. GL reference `{gl_ref}` appears in bank memo as `{bank_desc}` — a `{corruption_type}` pattern (`{ref_score_pct}`% similarity via Levenshtein). Date matches exactly. Recommended action: approve match; consider standardizing remittance template with this vendor."

**EXCEPTION — partial payment:**
> "Bank credit of `${bank_amount}` represents `{pct}`% of GL invoice `{invoice_id}` (`${gl_amount}`). Vendor match: `{vendor_score_pct}`%. This appears to be a partial payment. Remaining balance of `${balance}` is still outstanding. Invoice status updated to PARTIAL."

**EXCEPTION — unknown:**
> "No match candidate found for `{source_ref}` (`${amount}`, `{date}`). No GL invoice within the current dataset window matches on amount, vendor, or reference. Recommended action: request remittance advice from `{vendor_name}` or check for pre-invoice payment."

---

## 8. UI Page Specifications

### 8.1 Page 1 — Reconciliation Dashboard

**Route:** `/`  
**Primary user:** Controller, Finance Manager  
**Purpose:** Operational status of the current reconciliation run at a glance.

---

#### Layout

```
┌─────────────────────────────────────────────────────────────────┐
│  HEADER: "AP/AR Reconciliation — BANK_NA | Run: 2026-05-12"     │
│  Last Run: 14 minutes ago | GL File: gl_invoices.csv            │
│  Bank File: bank_statement.csv          [▶ Start New Run]       │
├──────────┬──────────┬──────────┬──────────┬────────────────────┤
│  AUTO-   │  TOTAL   │ PENDING  │EXCEPTIONS│  OUTSTANDING       │
│  MATCH   │  TXN     │ REVIEW   │          │  VARIANCE          │
│  RATE    │          │          │          │                     │
│  87.4%   │  500     │  31      │  44      │  $128,450          │
│  ▲ 2.1%  │  ✓ 425   │          │          │                     │
├──────────┴──────────┴──────────┴──────────┴────────────────────┤
│  LEFT: Match Type Breakdown (Donut)                             │
│         Exact: 310 | Fuzzy: 82 | AI-Assisted: 33 | Unmatched: 75│
│                                                                 │
│  RIGHT: Exception Root Cause (Horizontal Bar)                   │
│         Timing Difference   ████████████  20                   │
│         Fee Variance        ███████████   18                   │
│         Truncated Reference ████████      17                   │
│         Partial Payment     ██████        12                   │
│         Unknown             ████           8                   │
├─────────────────────────────────────────────────────────────────┤
│  ACTIVITY FEED (last 10 events)                                 │
│  14 min ago  Auto-matched 392 items at 96.8% avg confidence     │
│  14 min ago  Suppressed 12 duplicate bank records               │
│  14 min ago  Routed 31 items to Pending Review queue            │
│  14 min ago  Classified 44 exceptions with root cause labels    │
│  15 min ago  Ingested gl_invoices.csv — 500 records validated   │
│  15 min ago  Ingested bank_statement.csv — 512 records validated│
└─────────────────────────────────────────────────────────────────┘
```

---

#### Component Specifications

**KPI Bar**

| Metric | Display | Color Logic |
|---|---|---|
| Auto-Match Rate | Large number + trend arrow vs prior run | Green ≥ 85%, Amber 70–84%, Red < 70% |
| Total Transactions | Count with sub-breakdown | Neutral |
| Pending Review | Count with link to Page 2 | Amber if > 30 |
| Exceptions | Count with link to Page 3 | Red if > 20 |
| Outstanding Variance | Sum of `amount_delta` for unresolved items | Red if > $50,000 |

**Match Breakdown Donut**
- Four segments: Exact / Fuzzy / AI-Assisted / Unmatched
- Click on any segment filters Page 2 to that match type
- Legend below chart with counts and percentages

**Root Cause Horizontal Bar**
- Five bars, one per root cause category
- Bars are clickable — routes to Page 3 filtered by that root cause
- Color code: Timing = Blue, Fee = Orange, Truncated = Yellow, Partial = Purple, Unknown = Red

**Activity Feed**
- Reverse chronological, last 10 system events
- Event types: Ingestion, Match Run, Escalation, Manual Review, Exception Classification

**Header Actions**
- `Start New Run` — opens file upload modal; accepts CSV only in v1
- File upload modal fields: GL Invoice File (CSV), Bank Statement File (CSV), Reconciliation Period (date range picker)

---

### 8.2 Page 2 — Match Results Workbench

**Route:** `/matches`  
**Primary user:** AP/AR Analyst  
**Purpose:** Review and approve matched pairs, with confidence reasoning visible inline.

---

#### Layout

```
┌─────────────────────────────────────────────────────────────────┐
│  FILTER BAR                                                     │
│  Status: [All ▼]  Date: [Apr 1–30 ▼]  Vendor: [All ▼]         │
│  Confidence: [0%────────────────100%]  Match Type: [All ▼]     │
│  [Clear Filters]  Showing 456 of 500 matches                    │
├───────────────────────────────────────┬─────────────────────────┤
│  TRANSACTION LIST (left, scrollable)  │  MATCH DETAIL PANEL     │
│                                       │  (right, sticky)        │
│  Status | Invoice | Bank | Score | Δ  │                         │
│  ────────────────────────────────     │  [Select a row to view] │
│  ✓ AUTO  INV-0001  TXN-884521  100%   │                         │
│  ✓ AUTO  INV-0002  TXN-884522   94%   │                         │
│  ⚠ PEND  INV-0088  TXN-991022   87%  │                         │
│  ⚠ PEND  INV-0211  TXN-774312   83%  │                         │
│  ✗ EXCEP INV-0390  —            —     │                         │
│  ...                                  │                         │
│                                       │                         │
│  [← Prev]  Page 1 of 19  [Next →]    │                         │
└───────────────────────────────────────┴─────────────────────────┘
```

---

#### Transaction List — Column Definitions

| Column | Content | Sort |
|---|---|---|
| Status Badge | `✓ AUTO` (green) / `⚠ REVIEW` (amber) / `✗ EXCEPTION` (red) | Yes |
| GL Invoice | `invoice_id` + `vendor_name` (truncated to 20 chars) | Yes |
| Amount (GL) | `gl_invoices.amount` formatted as USD | Yes |
| Bank Ref | `bank_ref` + `description` (truncated) | No |
| Amount (Bank) | `bank_statement.credit_amount` formatted as USD | Yes |
| Δ | `amount_delta` signed; green if 0, amber if < $50, red if > $50 | Yes |
| Confidence | Colored pill badge: green ≥ 90%, amber 75–89%, red < 75% | Yes |
| Match Type | `EXACT / FUZZY / AI` text label | Yes |
| Date Δ | Days between GL date and bank value date | Yes |

---

#### Match Detail Panel — Specifications

Opens when any row is selected. Stays visible while scrolling list.

**Section 1 — Side-by-Side Comparison Cards**

Left card (GL Record) and Right card (Bank Record), each showing:
- Reference ID
- Vendor Name
- Amount
- Date
- Description/Memo
- Payment Method (bank side only)

Field-level color coding:
- Green background = exact match on that field
- Amber background = fuzzy match (score 0.70–0.99)
- Red background = mismatch or missing

**Section 2 — Confidence Score Breakdown**

```
Confidence Score Breakdown                  Overall: 87%
──────────────────────────────────────────────────────
Amount Match       ████████████████████ 100%  × 0.40 = 0.400
Date Proximity     █████████████████    87%   × 0.25 = 0.218
Reference Match    ███████████████      78%   × 0.20 = 0.156
Vendor Match       ████████████████████ 91%   × 0.15 = 0.137
──────────────────────────────────────────────────────
Composite Score                                = 0.871 (87%)
Status: PENDING REVIEW (threshold: 90% for auto-approval)
```

**Section 3 — AI Rationale**

Plain-English explanation box. Example:
> *"Amount ($45,200.00) and vendor (Cisco Systems) match with high confidence. Bank reference 'CISCO SYS PMT APR' has a token set ratio of 78% against invoice reference 'INV-0088' — likely a formatted payment description without the invoice ID. Date gap of 4 days is within the observed 3-day settlement window for this vendor. Recommend approval."*

**Section 4 — Action Buttons**

| Button | Action | Condition |
|---|---|---|
| `✓ Approve Match` | Sets status to APPROVED, closes item | Available for PENDING_REVIEW |
| `✗ Reject & Reclassify` | Removes candidate, routes to Exception queue | Available for PENDING_REVIEW |
| `↑ Escalate to Controller` | Sets status ESCALATED, sends notification | Available always |
| `← Previous` / `Next →` | Navigate list without returning to list pane | Always |

---

### 8.3 Page 3 — Exception Workbench

**Route:** `/exceptions`  
**Primary user:** AP/AR Analyst, Controller  
**Purpose:** Triage unmatched items with AI root cause intelligence. This is the highest-value page in the prototype.

---

#### Layout

```
┌─────────────────────────────────────────────────────────────────┐
│  EXCEPTION SUMMARY BAR                                          │
│  44 Open  |  $128,450 Total  |  Avg Age: 3.2 days  |  6 Overdue│
├─────────────────────────────────────────────────────────────────┤
│  FILTER: Root Cause [All ▼]  Priority [All ▼]  Age [All ▼]     │
│  Assigned To [All ▼]         [Export Exception Report]          │
├─────────────────────────────────────────────────────────────────┤
│  EXCEPTION LIST                                                 │
│  ID | Source | Amount | Date | Root Cause | Confidence | Age    │
│  ──────────────────────────────────────────────────────────     │
│  EX-001  GL  $28,000  Apr 28  Fee Variance      91%   1 day    │
│  EX-002  GL  $45,200  Apr 28  Timing Diff       85%   4 days   │
│  EX-003  GL  $120,000 Apr 15  Partial Payment   94%   8 days ⚠ │
│  EX-004  BANK $4,820  May 02  Unknown           —     2 days   │
│  ...                                                            │
├─────────────────────────────────────────────────────────────────┤
│  AI INVESTIGATION PANEL (expands on row click)                  │
│                                                                 │
│  EX-001 — Fee Variance | $28,000 | SWIFT Global Payments        │
│  ──────────────────────────────────────────────────────────     │
│  ROOT CAUSE ANALYSIS                                            │
│  Predicted: Fee Variance (91% confidence)                       │
│                                                                 │
│  Evidence:                                                      │
│  GL Invoice INV-0211: $28,000.00                                │
│  Bank Credit TXN-774312: $27,968.00                             │
│  Difference: $32.00 — within WIRE domestic fee range ($20–$35)  │
│  12 prior transactions from this vendor via WIRE show avg       │
│  fee of $28.40                                                  │
│                                                                 │
│  CANDIDATE MATCH                                                │
│  TXN-774312 | $27,968.00 | Apr 30 | SWFT GLBL PAY              │
│  Confidence: 88% | Amount: 100% | Date: 87% | Ref: 74%         │
│                                                                 │
│  SUGGESTED RESOLUTION                                           │
│  Approve match with $32.00 fee write-off → GL Account 6210      │
│                                                                 │
│  [✓ Approve with Adjustment]  [Create Journal Entry]           │
│  [✗ Write Off]  [📋 Request Remittance]  [↑ Escalate]          │
└─────────────────────────────────────────────────────────────────┘
```

---

#### Exception List — Column Definitions

| Column | Content |
|---|---|
| Exception ID | `EX-NNN` sequential |
| Source | `GL` (GL has no bank match) or `BANK` (bank credit has no GL match) |
| Amount | Transaction amount |
| Date | Transaction date |
| Root Cause Label | Color-coded badge per root cause enum |
| Root Cause Confidence | Percentage; blank for UNKNOWN |
| Age | Days since transaction date; red + ⚠ if > 5 days |
| Priority | HIGH / MED / LOW based on amount × age composite |
| Assigned To | User name or blank |

---

#### AI Investigation Panel — Full Specification

Triggered by clicking any exception row.

**Block 1 — Header**
- Exception ID, Root Cause Label, Amount, Vendor Name

**Block 2 — Root Cause Analysis Card**
- Predicted root cause with confidence percentage
- Evidence paragraph (from rationale template — see Section 7.1)
- Supporting data table showing the specific field values that drove the classification

**Block 3 — Candidate Match Card** (shown only if candidate exists)
- Bank record details
- Confidence breakdown bar chart (same format as Page 2 Section 2)
- Delta summary: amount delta, date delta, reference similarity score

**Block 4 — Suggested Resolution**
- One sentence action recommendation
- Suggested GL account (for write-offs)
- Estimated resolution time (from historical data: fee variances average 2 minutes to resolve)

**Block 5 — Action Buttons**

| Button | Action | Available For |
|---|---|---|
| `✓ Approve with Adjustment` | Accepts candidate match, books delta to suggested GL account | FEE_VARIANCE, PARTIAL |
| `Create Journal Entry` | Placeholder — routes to ERP in Phase 2 | FEE_VARIANCE |
| `✗ Write Off` | Marks as written off with GL account entry | UNKNOWN, small amounts |
| `📋 Request Remittance` | Drafts email to vendor requesting remittance advice | UNKNOWN, PARTIAL |
| `↑ Escalate to Controller` | Escalates with context pre-populated | All types |
| `👤 Assign To` | Assigns to named analyst | All types |

---

### 8.4 Page 4 — Analytics and Trend Intelligence

**Route:** `/analytics`  
**Primary user:** Controller, CFO  
**Purpose:** Shows the system learns and improves over time. Positions Phase 2 capabilities during the demo.

---

#### Layout

```
┌──────────────────────────────┬──────────────────────────────────┐
│  CHART 1                     │  CHART 2                         │
│  Auto-Match Rate Trend       │  Exception Root Cause by Week    │
│  (Line, 8-week rolling)      │  (Stacked Bar)                   │
│                              │                                  │
│  ████ 87%                    │  Week 1: ████████████            │
│  ██████ 89%                  │  Week 2: ██████████              │
│  ████████ 91%                │  Week 3: ████████                │
│  [Rule update applied →]     │  [Fee rule updated →]            │
├──────────────────────────────┼──────────────────────────────────┤
│  CHART 3                     │  CHART 4                         │
│  Exception Aging (Bar)       │  Vendor Risk Heatmap (Table)     │
│                              │                                  │
│  <1 day: ████████████        │  Vendor          Excep  AvgDays  │
│  1-3 day: ███████            │  Oracle Corp       8      5.2    │
│  3-7 day: ████               │  Cisco Systems     6      3.8    │
│  >7 day:  ██ ⚠               │  IBM Corporation   5      4.1    │
├──────────────────────────────┴──────────────────────────────────┤
│  AI INSIGHTS PANEL                                              │
│                                                                 │
│  💡 Adding a $0–$35 tolerance rule for WIRE payments would      │
│     increase your auto-match rate from 87% to ~93%,            │
│     eliminating 18 manual reviews per month.                    │
│                                                                 │
│  💡 Oracle Corporation has a consistent 2-day settlement lag.   │
│     Adjusting the date tolerance for this vendor to ±3 days     │
│     removes 8 exceptions per cycle.                             │
│                                                                 │
│  ⚠  Duplicate risk: TXN-44821 and TXN-44822 share the same     │
│     amount, vendor, and date ±6 minutes. Likely a processor     │
│     retry. A suppression rule would prevent recurrence.         │
└─────────────────────────────────────────────────────────────────┘
```

---

#### Chart Specifications

**Chart 1 — Auto-Match Rate Trend**
- Type: Line chart
- X-axis: Week labels (Week 1 through Week 8)
- Y-axis: Percentage 70–100%
- Data: Simulated weekly rates showing gradual improvement
- Annotations: Vertical dotted lines where "rule updates" were applied
- Purpose: Shows the system improves over time

**Chart 2 — Exception Root Cause by Week**
- Type: Stacked bar chart
- X-axis: Week labels
- Y-axis: Count of exceptions
- Segments: One color per root cause category
- Purpose: Shows Fee Variance declining after a rule change — the key learning story

**Chart 3 — Exception Aging**
- Type: Grouped bar chart
- X-axis: Age buckets (<1 day, 1–3 days, 3–7 days, >7 days)
- Y-axis: Count
- Color: Green to red as age increases
- Warning icon on >7 day bucket if count > 3

**Chart 4 — Vendor Risk Heatmap**
- Type: Sortable table
- Columns: Vendor Name, Exception Count, Avg Resolution Days, Most Common Root Cause, Trend (↑↓→)
- Sort default: Exception count descending
- Clickable rows: Routes to Page 3 filtered by that vendor

**AI Insights Panel**
- 3 insight bullets, generated from analytics data
- Template types: Rule optimization suggestion, vendor pattern, duplicate risk warning
- Each insight has a `[Apply Rule]` button (placeholder in v1, active in v2)

---

## 9. Technology Stack

### 9.1 Core Dependencies

| Layer | Library | Version | Purpose |
|---|---|---|---|
| Data manipulation | `pandas` | ≥ 2.0 | Core data structures and matching joins |
| Numeric operations | `numpy` | ≥ 1.24 | Amount tolerance calculations |
| Fuzzy string matching | `fuzzywuzzy` | ≥ 0.18 | token_set_ratio for description matching |
| Levenshtein distance | `python-Levenshtein` | ≥ 0.21 | Reference ID character edit distance |
| Jaro-Winkler | `jellyfish` | ≥ 0.9 | Name similarity |
| UI framework | `streamlit` | ≥ 1.30 | Web application and dashboard |
| Charts | `plotly` | ≥ 5.18 | All charts (line, bar, donut) |
| Data validation | `pydantic` | ≥ 2.0 | MatchResult and Exception data models |
| Synthetic data | `faker` | ≥ 20.0 | Name and reference generation |
| Testing | `pytest` | ≥ 7.0 | Scenario validation against ground truth |

### 9.2 Installation

```bash
pip install pandas numpy fuzzywuzzy python-Levenshtein jellyfish \
    streamlit plotly pydantic faker pytest
```

### 9.3 File Structure

```
apar_reconciliation/
├── data/
│   ├── gl_invoices.csv
│   ├── bank_statement.csv
│   └── ground_truth.csv          # For validation only, not shown in demo
├── engine/
│   ├── __init__.py
│   ├── normalizer.py              # Vendor normalization, field cleaning
│   ├── matcher.py                 # Passes 1, 2, 3 + confidence scoring
│   ├── root_cause.py              # Root cause decision tree
│   └── rationale.py              # Template-based rationale generator
├── models/
│   ├── __init__.py
│   ├── match_result.py            # MatchResult dataclass
│   ├── exception.py               # Exception dataclass
│   └── run.py                     # ReconciliationRun dataclass
├── pages/
│   ├── dashboard.py               # Page 1
│   ├── match_workbench.py         # Page 2
│   ├── exception_workbench.py     # Page 3
│   └── analytics.py               # Page 4
├── tests/
│   ├── test_matching.py           # Unit tests for matching engine
│   ├── test_root_cause.py         # Root cause classification accuracy
│   └── test_synthetic_data.py     # Data generation validation
├── generate_synthetic_data.py     # Data generation script
├── app.py                         # Streamlit entry point
└── requirements.txt
```

---

## 10. Build Sequence

Build in this exact order. Do not skip ahead.

| Phase | Deliverable | Acceptance Criteria | Kill Switch |
|---|---|---|---|
| **1. Data** | `generate_synthetic_data.py` runs and produces 500 GL + 512 bank records | All 5 scenario types present; ground truth file validates counts | If scenarios can't be generated cleanly, redesign vendor table first |
| **2. Normalizer** | `normalizer.py` — vendor lookup + field cleaning | All 25 vendor abbreviations resolve correctly; no errors on CSV ingest | If >5 vendors fail normalization, expand abbreviation table before proceeding |
| **3. Matcher** | `matcher.py` — Pass 1, 2, 3 + confidence scoring | Auto-match rate ≥ 85% on synthetic data; no false positives on Scenario E (unknowns) | If auto-match rate < 75% after weight tuning, revisit amount tolerance thresholds |
| **4. Root Cause** | `root_cause.py` — decision tree | ≥ 90% classification accuracy on 75 engineered scenario records | If accuracy < 80% on Scenario B (fee variance), recalibrate fee tolerance ranges |
| **5. Rationale** | `rationale.py` — all 6 templates | Every exception has a non-empty rationale string; no template errors | If templates produce confusing output, review with a non-technical reader before proceeding |
| **6. UI — Page 3** | Exception Workbench | All 44 exceptions visible; root cause panel populates on click; all action buttons render | If Streamlit layout breaks on exception panel, simplify to tabbed layout |
| **7. UI — Page 2** | Match Workbench | All 456 matches visible; confidence breakdown renders; approve action works | — |
| **8. UI — Page 1** | Dashboard | KPI bar shows correct counts; both charts render; activity feed populates | — |
| **9. UI — Page 4** | Analytics | All 4 charts render; insights panel shows 3 bullets | — |
| **10. End-to-end test** | Full demo run | Demo runs start to finish in ≤ 8 minutes without errors | If any page crashes during demo rehearsal, fix before showing to client |

---

## 11. Out of Scope — Phase 2

These are demo talking points only. Do not reference them as "coming soon" without a defined timeline.

| Capability | Phase 2 Notes |
|---|---|
| ERP write-back (SAP/Oracle journal entry) | Requires ERP API credentials; add after core prototype validated |
| ISO 20022 / camt.053 XML ingestion | Add `PyISO20022` parser as a second ingestion path alongside CSV |
| LLM-generated rationale | Replace template strings with `claude-sonnet` API call; pass match object as context |
| Multi-entity / intercompany | Add `entity` filter and intercompany elimination logic |
| Multi-currency | Add FX rate table and normalization to USD before matching |
| Agentic AI orchestration | Replace rule-based root cause engine with an agent that queries GL system directly |
| Role-based access and approvals | Add user auth and segregation of duties enforcement |
| Live bank feed integration | Replace CSV upload with API or SFTP polling |
| Mobile-responsive layout | Streamlit mobile support or migrate to React |

---

*End of Specification — Version 1.0*
