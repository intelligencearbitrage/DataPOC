# Agile Capacity No-Show Pilot — Demo Talk Track

## Opening

"This is the Agile Capacity pilot for Urology. The system uses our existing No-Show Risk Prediction model to identify appointment slots where patients are likely to not show up, and recommends which slots could be double-booked to recover lost capacity."

---

## What You're Looking At

**The Slot Recommendations tab** shows flagged appointment sessions for the next few business days. Each row is a single appointment slot — at 20 or 30-minute intervals — where the risk model has identified elevated no-show probability.

### Key Columns
- **Slot Time** — actual appointment time (e.g., 08:00, 08:20, 08:30, 09:00) matching Epic's scheduling template
- **Location** — campus/clinic (Medical Center, West Campus, Woodlands Campus, North Austin Campus, HC - Main)
- **Block Type** — the specific URO visit type (e.g., URO EST GENERAL, URO APP POST OP)
- **Max Risk Score** — highest individual patient no-show probability in that slot (0–100%)
- **Flag Reason** — why this slot was flagged:
  - **BOTH** (red) = 50%+ of patients are high-risk AND average session risk is above 40%
  - **COMBINED_ELEVATED** (orange) = average session risk above 40%
  - **HIGH_DOMINANT** (yellow) = 50%+ of patients are individually high-risk

### Filters
- Service Line (Urology for this pilot)
- Provider
- Category (Follow-up, Post-Op)
- Block Type (multi-select from 13 pilot types)
- Slot Time (multi-select)
- Min Risk Score (slider — adjust threshold)
- Date Range

---

## What's Included in the Pilot

| Included | Details |
|----------|---------|
| Specialty | Urology only |
| Mode | In-Person only |
| Patient Type | Return patients — Follow-up and Post-Op visits |
| Block Types | 13 specific URO types (see below) |
| Risk Model | Existing PA No-Show Risk Prediction (scores 0–100%) |
| Slot Granularity | 20/30-minute intervals from actual AppointmentDTS |
| Locations | Medical Center, West Campus, Woodlands, North Austin, HC-Main |
| Capacity Management | Override slots from capacity 1 → 2 with audit trail |

**13 Pilot Block Types:**
1. URO APP POST OP
2. URO APP POST OP VIDEO (excluded by In-Person filter)
3. URO EST APP SKIN VIDEO (excluded by In-Person filter)
4. URO EST GENERAL
5. URO EST GENERAL VIDEO (excluded by In-Person filter)
6. URO EST INCONTINENCE
7. URO EST INCONTINENCE VIDEO (excluded by In-Person filter)
8. URO EST SKIN
9. URO EST SKIN VIDEO (excluded by In-Person filter)
10. URO NEW SKIN (excluded by category filter — "New")
11. URO NEW SKIN VIDEO (excluded by both filters)
12. URO POST OP
13. URO POST OP VIDEO (excluded by In-Person filter)

**Effectively showing:** URO EST GENERAL, URO EST INCONTINENCE, URO EST SKIN, URO APP POST OP, URO POST OP (In-Person + Return patients only)

---

## What's Excluded

| Excluded | Reason |
|----------|--------|
| New patients | Only return/established patients targeted for overbooking — new patients need full onboarding time |
| Telemedicine/Video visits | Overbooking concept applies to physical exam rooms and in-person chair time |
| Other specialties | Pilot is Urology-specific; expansion planned post-validation |
| Complex visit types | URO Complex, URO Circ Clinic, Procedures excluded from pilot |
| Non-pilot block types | A Plus, MYC OPEN URO, TCP Priority Visit, etc. |

---

## What's Missing / Not Yet Available

| Gap | Status | Impact |
|-----|--------|--------|
| **Provider Location/Room** | We show Campus (department-level) but not specific clinic room | Users must cross-reference Epic for room assignment |
| **Block Type from Epic template** | We mapped VisitTypeDSC as block type; actual Epic block/template data not yet integrated | Current mapping works but should be validated against Epic's scheduling template names |
| **Outcomes/Effectiveness data** | No post-intervention data yet (Tab D is placeholder) | Cannot measure impact until pilot goes live and Epic outcomes flow back |
| **Cortex Agent (NL Analytics)** | Deployed & Tested ✅ — `NOSHOW_ANALYTICS_AGENT` | Fully functional via `SNOWFLAKE.CORTEX.DATA_AGENT_RUN`; Streamlit Tab C (Analytics) provides chat interface. Overall no-show rate: **16.6%** (228K no-shows / 1.37M appointments). Users can ask natural language questions like "What is the no-show rate by specialty?" |
| **Patient-level detail** | View aggregates to slot level; individual patient encounter drill-down not shown | Users can't see which specific patient is flagged in a slot |
| **Historical no-show rate by block type** | Available in EDA data but not yet surfaced in recommendations | Would help contextualize "is 60% unusual for this block type?" |

---

## Demo Flow (Suggested)

1. **Open Slot Recommendations tab** — show the 20+ flagged sessions for May 26
2. **Point out a BOTH flag** — "This 12:00 slot at Woodlands Campus has an 88% risk score. The model is highly confident this patient won't show."
3. **Filter by provider** — select one provider, show their specific flagged slots
4. **Adjust risk slider** — drag to 70% to show only highest-risk slots
5. **Switch to Calendar tab** — show the daily grid view of all flagged slots
6. **Show Capacity Management** — "When we decide to double-book, the scheduler would set capacity to 2 here, with a note explaining why"
7. **Show Analytics tab** — "This is our AI agent. You can ask natural language questions like 'What is the no-show rate by payor?' and it generates SQL against our 1.37M appointment dataset and returns the answer. It's powered by Snowflake Cortex Agent with a semantic model. We've validated 15 test questions against ground truth — for example, appointment confirmation is the strongest predictor: confirmed appointments have a 7% no-show rate vs 32% for unconfirmed."
8. **Show Effectiveness tab** — "Once live, this is where we'll track whether double-booking actually recovered capacity"

---

## Questions to Anticipate

**Q: How accurate is the risk score?**
A: The model scores range from 0.6% to 99.5% (mean ~51%). For flagged slots, we're seeing scores of 44%–88%. The model was trained on 1.37M historical appointments.

**Q: What happens if both patients show up?**
A: That's the "false positive" scenario. The effectiveness tab will track this. Initial guardrail: only target slots where risk is very high (configurable threshold, currently 40%+).

**Q: Why only return patients?**
A: New patients have different no-show patterns and require more onboarding time. Return patients are better candidates because: their appointments are shorter, the provider already knows them, and their historical no-show patterns are more predictable.

**Q: How far ahead do we look?**
A: Configurable via date range. The recommendation is 3–5 business days out — enough time for the scheduler to act, but close enough that the risk score is still accurate.

**Q: Who makes the final decision?**
A: The scheduler. This tool recommends; humans decide. Every capacity change is logged with who made it and why (audit trail).

---

## Next Steps After Demo

1. Get provider name reference data into the system
2. Validate block type mapping against Epic templates
3. Define go-live date and baseline measurement period
4. Set up Epic → Snowflake outcome data pipeline
5. Deploy Cortex Agent for NL analytics
6. UAT with scheduling team (threshold tuning)
