# TCH Use Case 2: SG2 / Market & Referral Analytics Pilot
## Scope & KPI Definition Document

**Version:** 1.1
**Date:** April 22, 2026
**Status:** Draft — Pending Client Review

---

## Revision History

| Version | Date | Author | Changes |
|---------|------|--------|---------|
| 1.0 | April 22, 2026 | Delivery Team | Initial draft |
| 1.1 | April 22, 2026 | Delivery Team | Added scope recommendation, KPI measurement methodology, role definitions, Snowflake requirements, baseline measurement step, risk register |

---

## Stakeholder Roles

| Role | Responsibility |
|------|---------------|
| **Delivery Lead** | Overall pilot delivery accountability; scope and timeline decisions |
| **Strategy Lead** | KPI target alignment, business case validation, market analytics domain expertise |
| **Client Champion** | Internal advocate at Client organization; pilot user recruitment and feedback coordination |
| **Client Data Team** | Data access provisioning, source system documentation, governance compliance |
| **Delivery Team** | Snowflake development, testing, deployment, and iteration during pilot |

---

## 1. Purpose

This document defines the pilot scope, success criteria, and key performance indicators (KPIs) for the TCH SG2 Market & Referral Analytics Pilot. It is intended to align internal delivery teams and the Client on measurable outcomes prior to development kickoff within Snowflake.

---

## 2. Pilot Scope

The pilot will focus on **one or more** of the following capability candidates, to be finalized in consultation with the Client:

### Scope Recommendation

**Recommended for Pilot Phase:** 2a (Conversational Analytics Agent) + 2b (On-Demand Output Generation)

**Rationale:** 2a and 2b are complementary — the conversational agent surfaces insights, and the output generator formats them for stakeholder consumption. Together they deliver a complete "ask a question, get a deliverable" experience within the 8–12 week window. Both rely on existing data in Snowflake and do not require model training or validation cycles.

**2c (Predictive Model) recommended for Phase 2.** Predictive referral modeling requires significantly more data preparation (feature engineering, training/test splits, baseline model benchmarking), model validation, and iterative tuning. Including 2c alongside 2a and 2b in an 8–12 week pilot introduces timeline risk. Deferring 2c allows Phase 1 pilot data and user feedback to inform the predictive model design.

### 2a. Conversational Analytics Agent
A natural language interface enabling users to query market share, referral patterns, and provider performance without requiring SQL or BI tool expertise.

**Target Users:** Physician liaisons, service line leaders, strategy and planning teams
**Data Sources:** Referral data, market share data, provider performance metrics (all within Snowflake)

**Expected Data Entities:**
- Referral records (referring provider NPI, receiving provider NPI, specialty, referral date, volume, facility)
- Market share data (service line, geography/ZIP/county, time period, volume, share percentage)
- Provider registry (NPI, name, specialty, affiliated facility, active status)

**Key Capabilities:**
- Query referral volumes by provider, specialty, and geography
- Surface market share trends over configurable time periods
- Identify top referring and leaking providers on demand

### 2b. On-Demand Output Generation
A system that accepts natural language inputs and generates audience-specific charts, graphs, and formatted outputs automatically.

**Target Users:** Strategy teams, executives, physician liaison managers
**Key Capabilities:**
- Dynamic chart and graph generation based on plain-language requests
- Audience-specific output formatting (e.g., executive summary vs. operational detail)
- Export-ready visuals for presentations and reports

### 2c. Predictive Referral & Market Intelligence Model
A predictive analytics model that anticipates referral trend shifts, market share movement, and physician behavioral changes to enable proactive outreach.

**Target Users:** Physician liaison teams, market strategy teams
**Key Capabilities:**
- Forecasting referral volume changes by provider or geography
- Early detection of physician migration or loyalty decline
- Prioritized outreach recommendations before volume is lost

**Note:** See Scope Recommendation above. This capability is recommended for Phase 2 due to complexity and data maturity requirements.

---

## 3. Success KPIs

### 3.1 Technical Performance KPIs

| KPI | Description | Target | Measurement Methodology |
|-----|-------------|--------|------------------------|
| Query Accuracy | % of natural language queries returning correct, relevant results | ≥ 90% | Measured against a curated evaluation set of 50+ representative queries, each with an expected answer reviewed and validated by subject matter experts. Accuracy scored as exact match or semantically equivalent. |
| Response Latency | Average time to return a result or visualization | ≤ 5 seconds | Measured as p50 and p95 latency across all user queries during pilot period, captured via application telemetry. |
| Data Freshness | Lag between source data update and availability in pilot system | ≤ 24 hours | Measured by comparing source system last-modified timestamps against Snowflake table refresh timestamps. |
| System Uptime | Availability during pilot period | ≥ 99% | Measured as total available minutes / total pilot period minutes, excluding scheduled maintenance windows communicated in advance. |
| Prediction Accuracy (2c only) | Accuracy of referral trend forecasts vs. actuals | ≥ 80% | Measured using Mean Absolute Percentage Error (MAPE) for volume forecasts and directional accuracy (% of periods where predicted trend direction matches actual) over a 30-day holdout period. |

### 3.2 User Adoption & Experience KPIs

| KPI | Description | Target | Measurement Methodology |
|-----|-------------|--------|------------------------|
| Active User Rate | % of invited pilot users engaging with the system at least weekly | ≥ 70% | Measured via application login and query telemetry. Given small sample size (10–20 users), absolute engagement counts will also be reported alongside percentages. |
| Task Completion Rate | % of user queries or tasks completed without escalation to IT/analyst | ≥ 85% | Measured by tracking query sessions that result in a delivered answer vs. sessions abandoned or escalated. Escalation tracked via support channel. |
| User Satisfaction Score | Average score from end-of-pilot survey (1–5 scale) | ≥ 4.0 | End-of-pilot survey administered to all pilot users. Survey instrument to be finalized during Week 1. |
| Time-to-Insight Reduction | Reduction in time to access referral/market insights vs. current state | ≥ 40% | Requires current-state baseline (see Section 6, Step 3). Baseline captured via structured interviews and task-timing exercises with pilot users during Week 1. Post-pilot measurement via same methodology. |

### 3.3 Business Impact KPIs

| KPI | Description | Target | Measurement Methodology |
|-----|-------------|--------|------------------------|
| Referral Leakage Identified | # of at-risk provider relationships surfaced during pilot | ≥ 10 actionable findings | Counted as distinct provider relationships flagged by the system and confirmed as actionable by a physician liaison or strategy team member. |
| Proactive Outreach Triggered (2c only) | # of liaison outreach actions initiated based on predictive alerts | ≥ 5 during pilot period | Counted as outreach actions logged by liaison teams that cite a system-generated alert as the trigger. |
| Market Share Insights Generated | # of unique market share insights surfaced and reviewed by strategy team | ≥ 15 during pilot period | Counted as distinct insights (deduplicated) that are reviewed and acknowledged by at least one strategy team member. |
| Analyst Time Saved | Estimated hours saved per week vs. manual reporting baseline | ≥ 10 hrs/week | Requires current-state baseline (see Section 6, Step 3). Baseline captured via analyst time-tracking over 2 weeks pre-pilot. Post-pilot estimate via same tracking method and user self-report. |

---

## 4. Pilot Parameters

| Parameter | Detail |
|-----------|--------|
| **Duration** | 8–12 weeks (to be confirmed with Client) |
| **Environment** | Snowflake — must be resolved before kickoff (see Snowflake Requirements below) |
| **Pilot Users** | 10–20 users across target personas |
| **Data Requirements** | Historical referral data (minimum 24 months), market share data, provider registry. See Section 2a for expected entity-level detail. |
| **Integration Scope** | Snowflake only; no EHR or external API integrations in Phase 1 |
| **Governance** | PHI/PII handling per Client data governance policy; de-identified data preferred for pilot |

### Snowflake Environment Requirements

The following must be validated before pilot development begins:

| Requirement | Detail |
|-------------|--------|
| **Environment Decision** | Client-provisioned account vs. Deloitte sandbox — must be finalized in Next Steps. Affects data access, networking, governance, and cost allocation. |
| **Snowflake Edition** | Enterprise or Business Critical required if Cortex AI functions (COMPLETE, EXTRACT, etc.) or Cortex Agents are used for 2a. |
| **Region & Cortex Availability** | Cortex AI features are region-dependent. Confirm the target Snowflake account region supports required Cortex functions. |
| **Semantic Views** | If the conversational agent uses Cortex Analyst with Semantic Views, confirm Semantic View support in the target account. |
| **Estimated Data Volume** | Client Data Team to provide approximate row counts for referral data, market share data, and provider registry to inform warehouse sizing and cost estimates. |
| **Warehouse Sizing** | To be determined after data volume estimates are provided. Recommend starting with MEDIUM warehouse and scaling based on query performance during pilot. |

---

## 5. Out of Scope (Pilot Phase)

- EHR or EMR system integration
- Real-time streaming data pipelines
- Payer or claims data integration
- Production deployment or enterprise rollout
- Custom CRM or liaison workflow automation

---

## 6. Next Steps

| # | Action | Owner | Due |
|---|--------|-------|-----|
| 1 | Confirm pilot scope selection (2a, 2b, 2c, or combination) | Client + Delivery Lead | TBD |
| 2 | Resolve Snowflake environment decision (Client-provisioned vs. Deloitte sandbox) | Delivery Lead + Client Data Team | TBD |
| 3 | Capture current-state baselines for Time-to-Insight and Analyst Time Saved KPIs | Strategy Lead + Pilot Users | TBD |
| 4 | Validate data availability, access, and volume estimates in Snowflake | Client Data Team | TBD |
| 5 | Confirm Snowflake edition, region, and Cortex feature availability | Delivery Team + Client Data Team | TBD |
| 6 | Finalize KPI targets with Client stakeholders | Strategy Lead | TBD |
| 7 | Establish pilot user group and personas | Client Champion | TBD |
| 8 | Kick off Pilot Development (Snowflake build) | Delivery Team | TBD |

**Note:** Dates to be populated following the initial Client review meeting. Steps 2–5 are recommended as prerequisites to Step 8 (kickoff).

---

## 7. Risk Register

| # | Risk | Likelihood | Impact | Mitigation |
|---|------|-----------|--------|------------|
| R1 | **Data availability** — Required referral or market share data is incomplete, poorly structured, or inaccessible in Snowflake | Medium | High | Early data discovery sprint (Step 4); define minimum viable dataset; prepare synthetic fallback data for demo purposes if needed |
| R2 | **Timeline compression** — Including all three capabilities (2a + 2b + 2c) in an 8–12 week pilot exceeds delivery capacity | Medium | High | Recommend 2a + 2b for Phase 1; defer 2c to Phase 2 (see Scope Recommendation) |
| R3 | **User adoption** — Pilot users do not engage consistently due to competing priorities or change resistance | Medium | Medium | Identify a Client Champion early; schedule structured onboarding; provide weekly usage nudges; keep the pilot group small and motivated |
| R4 | **Snowflake feature gaps** — Required Cortex AI features not available in the Client's Snowflake region or edition | Low | High | Validate Snowflake environment requirements before kickoff (Step 5); identify fallback approaches if specific Cortex features are unavailable |
| R5 | **Baseline measurement gap** — Current-state baselines for Time-to-Insight and Analyst Time Saved are not captured before pilot begins, making KPIs unmeasurable | Medium | Medium | Schedule baseline capture as a prerequisite to kickoff (Step 3); use structured interviews and time-tracking exercises |
| R6 | **Data governance / PHI concerns** — Client governance review delays data access or restricts usable data | Low | High | Prefer de-identified data for pilot; engage Client data governance team early; document data handling procedures in Week 1 |

---

*This document is a working draft and subject to revision based on Client input and discovery findings.*
