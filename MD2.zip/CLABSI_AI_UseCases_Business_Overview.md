# CLABSI AI Use Case Library — Business Overview

**Engagement:** Healthcare AI — Hospital-Acquired Infection Prevention
**Platform:** Snowflake Cortex AI
**Source Systems:** UKG Pro · Epic/Cerner · NHSN (CDC)
**Practice:** Deloitte Consulting LLP

---

## Executive Summary

Central Line-Associated Bloodstream Infections (CLABSI) are among the most preventable hospital-acquired infections — yet they persist because the conditions that cause them (staffing gaps, lapsed competencies, documentation failures, knowledge deficits) are invisible in real time. This use case library deploys Snowflake Cortex AI to make those conditions visible, predictable, and actionable — before an infection occurs.

Seven use cases are organized across two phases. **Phase 1 (Pilot, Weeks 1–14)** delivers an integrated shift-level risk detection and alerting system. **Phase 2 (Expand, Weeks 15+)** deepens the picture to the patient level, closes compliance monitoring gaps, and addresses the knowledge deficit that drives agency staff risk.

| ID | Use Case | Phase | Primary User |
|---|---|---|---|
| UC-01 | Workforce-Integrated Shift Risk Scoring | 1 — Pilot | Charge Nurse |
| UC-02 | Proactive Shift Risk Alerts | 1 — Pilot | Charge Nurse, Nurse Manager |
| UC-03 | AI-Generated Risk Explanations | 1 — Pilot | Charge Nurse |
| UC-04 | Patient-Level CLABSI Risk Scoring | 2 — Expand | Bedside Nurse, Infection Control |
| UC-05 | Bundle Compliance Audit | 2 — Expand | Infection Control |
| UC-06 | Maintenance Practice Anomaly Detection | 2 — Expand | Infection Control |
| UC-07 | Protocol Knowledge Chatbot | 2 — Expand | Agency / Float Staff |

---

## Phase 1 — Pilot

### UC-01: Workforce-Integrated Shift Risk Scoring

#### Summary
Score every upcoming nursing shift on every high-acuity unit for CLABSI risk — using workforce patterns from UKG Pro as the primary signal — before the shift begins.

#### Problem Statement
CLABSI prevention protocols are well understood. What is less understood is the effect of *who is working* on whether those protocols are actually followed. Shifts with high agency staff ratios, lapsed competency certifications, understaffing gaps, and fatigued charge nurses produce measurably higher rates of bundle non-compliance — and downstream infection events.

This information exists in UKG Pro today. It has never been used predictively. Infection control teams learn about workforce risk factors only retrospectively, during root cause analyses after an event has already occurred. UC-01 inverts that timeline: every shift is scored *before it starts*, using the same workforce patterns that historical data shows preceded CLABSI events.

#### Outputs / Deliverables
- **Unit-Shift-Day Feature Store** — A structured Snowflake table (`CLABSI_FEATURES.UNIT_SHIFT_DAY_FEATURES`) combining 14 workforce and census features at the unit × shift × date grain, refreshed every 4 hours from UKG Pro and Epic/Cerner feeds.
- **Trained ML Classification Model** — A `SNOWFLAKE.ML.CLASSIFY` model trained on 18–24 months of historical workforce features labeled against NHSN-confirmed CLABSI outcomes, with evaluation metrics (precision, recall, AUC) reviewed and validated before deployment.
- **Scored Shift Table** — A live Dynamic Table (`CLABSI_SCORED.SHIFT_RISK_LIVE`) providing a risk tier (HIGH / MEDIUM / LOW) and probability score for every shift in the next 48-hour window, refreshed on a 4-hour cadence.
- **Charge Nurse Dashboard** — A Streamlit in Snowflake interface showing upcoming shift risk scores, top contributing features, and trend views by unit — accessible to charge nurses and nurse managers.

---

### UC-02: Proactive Shift Risk Alerts

#### Summary
Automatically notify the right clinical staff when an upcoming shift scores HIGH risk — with enough lead time to act — without generating noise that trains staff to ignore the system.

#### Problem Statement
A risk score sitting in a database helps no one. The UC-01 scored shift table only creates value if it reaches the person who can act on it, before the window for action has closed. Two failure modes must be avoided: alerting *too late* (after the shift starts, when staffing changes are impossible) and alerting *too often* (on every Medium or Low risk shift, desensitizing staff to notifications). UC-02 addresses both by firing alerts exclusively for HIGH-risk shifts in a 12–36 hour actionable window — enough lead time for a charge nurse or manager to contact the float pool, verify staff competencies, or request infection control rounding support.

#### Outputs / Deliverables
- **Alert Trigger Pipeline** — A Snowflake Task running every 4 hours that queries the UC-01 scored shift table, identifies HIGH-risk shifts in the 12–36 hour actionable window, and writes candidates to a pending alerts table with full deduplication logic.
- **Push Notification Delivery** — Automated notifications via email (Snowflake Notification Integration) or Microsoft Teams webhook, sent to the charge nurse and unit manager for each qualifying shift — including the AI-generated explanation text produced by UC-03.
- **Alert Log** — A persistent `CLABSI_ALERTS.ALERT_LOG` table recording every alert sent (unit, shift, timestamp, recipients) for retrospective analysis, deduplication, and compliance reporting.
- **Escalation Logic** — Configurable rules for escalating repeated HIGH-risk events on the same unit to infection control leadership.

---

### UC-03: AI-Generated Shift Risk Explanations

#### Summary
For every HIGH or MEDIUM risk shift, generate a plain-English explanation of exactly which workforce factors are driving the elevated risk — and precisely what the charge nurse should do about it.

#### Problem Statement
A risk score without context is noise. If a charge nurse receives an alert stating "MICU Night — HIGH RISK" with no further information, two predictable outcomes follow: she doesn't know what to fix, so she can't act; and after receiving unexplained alerts repeatedly, she stops reading them. The explainability layer is not optional decoration on top of the model — it is the primary mechanism by which the AI system earns clinical trust and drives behavior change. Without UC-03, UC-02 alerts will be ignored.

#### Outputs / Deliverables
- **AI-Generated Narrative Explanations** — For each HIGH or MEDIUM risk shift, a structured three-paragraph plain-English narrative generated by `SNOWFLAKE.CORTEX.COMPLETE` (claude-3-5-haiku), identifying the top workforce risk factors by name and quantified value (e.g., "Agency staff represent 38% of scheduled nursing hours — nearly double the 20% threshold").
- **Structured Recommended Actions** — Three specific, actionable bullet points extracted from each explanation as a parsed JSON array (e.g., "Contact float pool to replace one agency RN with a unit-familiar float nurse"), suitable for display in alert notifications and the Streamlit dashboard.
- **Explanation Persistence Table** — Explanations are generated once per scored shift and stored in `CLABSI_SCORED.SHIFT_EXPLANATIONS`, ensuring the alert and dashboard always display a consistent narrative without incurring repeated LLM costs.
- **Prompt Registry** — A governed prompt registry (`CLABSI_GOVERNANCE`) tracking the prompt template version used for each explanation, supporting auditability and prompt iteration management.

---

## Phase 2 — Expand

### UC-04: Patient-Level CLABSI Risk Scoring

#### Summary
Score every patient with an active central line daily for their individual CLABSI risk, using clinical features from Epic/Cerner — telling bedside nurses which specific patient needs the most careful bundle attention today.

#### Problem Statement
UC-01 tells a charge nurse that tonight's MICU shift is HIGH risk overall. UC-04 tells a bedside nurse that the patient in Room 412 is the specific patient who most needs careful central line attention today. The two models are complementary, not redundant: UC-01 operates at the unit-shift grain and serves staffing decisions; UC-04 operates at the patient-day grain and serves care prioritization decisions. A hospital that builds only UC-01 can intervene on staffing. A hospital that builds both can also direct heightened bundle attention to the individual patients most at risk — on any given day, regardless of overall shift risk.

#### Outputs / Deliverables
- **Patient-Day Feature Store** — A Snowflake table (`CLABSI_FEATURES.PATIENT_DAY_FEATURES`) with 17 clinical features per patient per day — including line age, line type and site, lab markers (WBC, CRP), vital signs, immunocompromised and TPN flags, nursing flowsheet compliance signals, and ICU length of stay — sourced entirely from Epic/Cerner.
- **Trained Patient Risk Model** — A `SNOWFLAKE.ML.CLASSIFY` model trained on patient-day features labeled against NHSN-confirmed CLABSI outcomes, with feature importance output validated against clinical expectations (e.g., line age, TPN, and immunosuppression should rank as top predictors).
- **Daily Patient Risk Scores** — A scored table (`CLABSI_SCORED.PATIENT_RISK_SCORES`) providing a risk tier and probability for every patient with an active central line, refreshed each morning for the day's care planning.
- **Bedside Nurse Dashboard** — A unit-level patient risk view in Streamlit showing the current day's highest-risk patients with their top contributing clinical factors, accessible to bedside nurses and infection preventionists during rounds.

---

### UC-05: AI-Powered Bundle Compliance Audit

#### Summary
Automatically audit clinical notes and nursing documentation to determine whether each element of the central line maintenance bundle was performed and documented — replacing manual chart review with near-real-time AI-powered compliance monitoring across the full patient population.

#### Problem Statement
The central line maintenance bundle requires five elements to be documented every day for every patient with an active central line: CHG bathing, dressing change or integrity assessment, hub scrub protocol, line necessity review, and dressing integrity documentation. In most hospitals, compliance is tracked either through structured flowsheet checkboxes (fast to query, but incomplete) or manual chart audits (accurate, but performed on only 10–20% of patient-days, weeks after the fact). Neither approach provides the real-time, complete-population compliance visibility needed to intervene before an infection occurs. `CORTEX.EXTRACT_ANSWER` bridges this gap by reading nursing note free text and answering targeted Yes/No questions about each bundle element — at scale, daily, automatically.

#### Outputs / Deliverables
- **Note-Level Compliance Signal Table** — For each nursing note covering a patient with an active central line, AI extraction results for all five bundle elements (`CLABSI_FEATURES.NOTE_COMPLIANCE_SIGNALS`), produced by `SNOWFLAKE.CORTEX.EXTRACT_ANSWER` targeted questions applied to note free text.
- **Patient-Day Compliance Record** — A daily aggregated compliance record per patient (`CLABSI_FEATURES.PATIENT_DAY_COMPLIANCE`) indicating which bundle elements are documented, which are missing, and whether full bundle compliance is achieved — serving as the input for UC-06 anomaly detection.
- **Unit-Level Compliance Dashboard** — A Streamlit view showing daily bundle compliance rates by unit and bundle element, with drill-down to individual patients and missing documentation flags — enabling infection control staff to target follow-up without manual chart review.
- **Compliance Rate Feed for UC-06** — Daily unit-level aggregated compliance rates exported to the UC-06 time-series input, closing the monitoring loop between documentation-level compliance and anomaly detection.

---

### UC-06: Maintenance Practice Anomaly Detection

#### Summary
Monitor bundle compliance rates over time and automatically flag when a unit's care practices deviate significantly from their own historical baseline — catching the slow drift before it becomes an infection cluster.

#### Problem Statement
Not all CLABSI risk concentrates in a single high-risk shift. Some infection clusters build over weeks through gradual, invisible drift: a new nurse manager joins and rounding frequency quietly declines; a supply chain disruption reduces CHG kit availability for 10 days; an EMR upgrade changes documentation workflow and hub scrub compliance drops 25%; summer travel nurse season arrives and dressing change compliance slowly erodes. None of these patterns trigger a UC-01 shift-level alert — individual shift scores may remain in the Medium range throughout. But the cumulative compliance drift is the real leading indicator. `ML.ANOMALY_DETECTION` monitors unit-level compliance time-series and surfaces these patterns when they deviate statistically from the unit's own established norm — not against a fixed benchmark, but against each unit's specific historical baseline, accounting for known seasonal patterns (weekday vs. weekend staffing cycles).

#### Outputs / Deliverables
- **Per-Unit Anomaly Detection Models** — One `SNOWFLAKE.ML.ANOMALY_DETECTION` model trained per unit per compliance metric (e.g., CHG compliance %, dressing compliance %, full bundle compliance %), learning each unit's historical baseline and weekly seasonality from a minimum of 90 days of UC-05 output data.
- **Daily Anomaly Flags Table** — A consolidated daily table (`CLABSI_ANOMALIES.DAILY_FLAGS`) identifying which units are exhibiting statistically significant compliance declines, including the actual vs. forecast compliance rate, deviation magnitude (anomaly score), and anomaly direction (DECLINE vs. SPIKE).
- **Multi-Day Pattern Detection** — Logic to surface only actionable signals: compliance drops exceeding 15 percentage points below the prediction lower bound, the same metric flagging anomalous for three or more consecutive days on the same unit, or full bundle compliance falling below an absolute 70% floor.
- **Infection Control Alerts** — Automated notifications to infection control leadership when sustained compliance anomalies are detected, reusing the UC-02 notification infrastructure with an appropriate lead-time framing for this slower-moving signal type.
- **Compliance Trend Dashboard** — A time-series visualization in Streamlit showing each unit's compliance metrics against their predicted range, with anomaly flags highlighted — enabling infection control managers to see the shape of drift, not just the point-in-time score.

---

### UC-07: Protocol Knowledge Chatbot for Agency and Float Staff

#### Summary
A Q&A chatbot that agency and float staff can query about CLABSI prevention protocols — answering from the hospital's own approved policy documents, available at any hour, on any device, without requiring a permanent staff nurse to stop and answer questions.

#### Problem Statement
Agency and travel nurses are consistently the highest-risk group in the UC-01 prediction model. This is not a reflection of clinical capability — it is a knowledge access problem. Agency staff don't know this hospital's specific protocols: which CHG bathing kit is used on this unit, whether the hub scrub duration is 15 or 30 seconds here, which dressing type this hospital stocks, how to document line necessity review in this specific Epic build, or who to notify when they find a compromised dressing at shift start. These answers exist — in policy documents, procedure manuals, and onboarding materials. But those documents are filed in a SharePoint no one can navigate at 2 AM, printed in a binder that may be outdated, or locked behind a hospital intranet that agency staff cannot access. UC-07 makes accurate, sourced protocol answers available to any nurse, on any device, at any hour — directly reducing the primary risk factor that UC-01 flags most heavily.

#### Outputs / Deliverables
- **Curated Knowledge Base** — Hospital policy documents, procedure manuals, CDC guidelines, and approved training materials loaded into Snowflake as structured document chunks (`CLABSI_KB.DOCUMENT_CHUNKS`), with a document registry tracking source, effective date, expiry date, and active/inactive status.
- **Cortex Search Index** — A `SNOWFLAKE.CORTEX.SEARCH` service automatically embedding and indexing all document chunks, with new documents indexed within a 1-hour target lag — requiring no manual vector pipeline management.
- **RAG-Powered Chatbot Interface** — A Streamlit in Snowflake application that accepts a nurse's natural-language question, retrieves the top-5 most relevant document chunks via Cortex Search, generates a grounded answer using `CORTEX.COMPLETE`, and displays the response with source citations (document title, document type) so nurses can verify the answer's origin.
- **Query Log and Training Gap Analytics** — Every chatbot query is logged to `CLABSI_KB.QUERY_LOG` with the question text, retrieved documents, and timestamp. Aggregated query volume by topic provides a measurable signal of knowledge gaps — feeding directly into competency training prioritization for agency staff orientation.
- **Measurable Impact on UC-01 Risk Factor** — As chatbot adoption grows, the agency staff knowledge gap that UC-01 flags as a top risk contributor is expected to narrow — creating a feedback loop between protocol access, compliance improvement, and model risk score reduction that can be tracked and reported.

---

## Cross-Cutting Notes

### Phase Dependency
The Phase 1 use cases are tightly integrated and must be built in order: UC-01 produces the scored shift table that UC-02 monitors, and UC-02 triggers UC-03 to generate the explanation text included in each alert. Phase 2 use cases can be built in parallel once Phase 1 is operational, with UC-05 as the recommended first Phase 2 build since its compliance output feeds both UC-04 features and UC-06 anomaly detection inputs.

### Reuse Potential
The architecture established by this library is directly portable to other hospital-acquired infection programs — CAUTI, VAP, SSI, and C. diff — reusing the unit-shift-day feature store design, the ML.CLASSIFY training pipeline, the CORTEX.COMPLETE explanation prompt pattern, and the Streamlit dashboard template with minimal modification.

### Pilot Recommendation
Begin Phase 1 in the MICU (or the unit with the highest central line device-days). Run for four weeks with charge nurse feedback before scaling to additional units.
