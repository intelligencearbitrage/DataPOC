# Skill: SDD feature spec

**Trigger:** Use this skill when the human says "plan feature", "start a feature", "new feature spec", or asks to begin work on a roadmap item.

---

## What this skill does

Guides the human through creating a complete feature spec — `plan.md`, `requirements.md`, and `validation.md` — before any code is written. Works conversationally, surfaces decisions, and writes the files to `/specs/features/<feature-name>/`.

---

## Pre-flight checklist

Before starting, verify:
- [ ] `specs/mission.md` exists and has been read
- [ ] `specs/tech-stack.md` exists and has been read
- [ ] `specs/roadmap.md` exists — identify the next unchecked item
- [ ] A feature branch has been created: `git checkout -b feature/<name>`
- [ ] Agent context is fresh (session started clean or `/clear` was run)

If any of these are missing, stop and tell the human what's needed before proceeding.

---

## Interview protocol

Ask the human the following questions **one group at a time**. Wait for answers before moving to the next group. Do not ask all questions at once.

### Group 1 — Scope
1. Which roadmap item are we working on? (Paste or describe it.)
2. Is the scope of this feature exactly as written on the roadmap, or do you want to adjust it?
3. Should this feature be implemented in one phase, or broken into sub-steps?

### Group 2 — Requirements
4. Are there specific technical constraints for this feature not already in `tech-stack.md`? (e.g. pin a library version, enforce a pattern, use a specific algorithm)
5. Are there user-facing requirements that need spelling out? (flows, edge cases, error states)
6. Are there any non-functional requirements? (performance thresholds, accessibility, security)

### Group 3 — Validation
7. How will we know this feature is done? What does success look like?
8. Should validation include automated tests, manual smoke tests, or both?
9. Are there specific scenarios or edge cases that must be tested?

### Group 4 — Decisions (present options, don't ask open questions)
For any architectural or design question raised during the interview, present **2–3 specific options with trade-offs** and ask the human to pick. Example format:

> For the data persistence approach, I see three options:
> 1. Store in SQLite via Prisma — consistent with existing stack, easy migrations
> 2. In-memory only — simpler, but data lost on restart
> 3. File-based JSON — portable, but no query capability
>
> Which would you prefer?

---

## Writing the spec files

Once the interview is complete, write three files:

### `/specs/features/<name>/plan.md`

```markdown
# Feature plan: <name>

## Overview
<1–2 sentence summary of what this feature does and why>

## Task groups

### Group 1 — <name>
- [ ] Task 1
- [ ] Task 2

### Group 2 — <name>
- [ ] Task 1
- [ ] Task 2

(continue as needed — keep groups small and independently commitable)
```

### `/specs/features/<name>/requirements.md`

```markdown
# Requirements: <name>

## Functional requirements
- FR-1: <requirement>
- FR-2: <requirement>

## Technical requirements
- TR-1: <requirement> (e.g. "Use Hono v4.x, pinned in package.json")
- TR-2: <requirement>

## Constraints
- <Any explicit limits from tech-stack.md or the interview>

## Out of scope
- <What this feature explicitly does NOT include>
```

### `/specs/features/<name>/validation.md`

```markdown
# Validation: <name>

## Automated tests
- [ ] Test: <description of what to test and expected outcome>
- [ ] Test: <description>

## Manual smoke tests
- [ ] Step: <action> → expected result
- [ ] Step: <action> → expected result

## Acceptance criteria
The feature is complete when:
- <criterion 1>
- <criterion 2>
```

---

## After writing

1. Show the human a summary of the three files.
2. Ask: "Is there anything in these specs you'd like to change before we commit?"
3. Apply any corrections via conversation — do not let the human edit files by hand while spec files are inconsistent with each other.
4. Commit the feature spec: `git add specs/features/<name>/ && git commit -m "spec: <name> feature plan, requirements, validation"`
5. Tell the human: "Spec committed. When you're ready to implement, start a fresh session, load the constitution and this feature spec, and use the implementation prompt."

---

## Implementation prompt (give this to the human to use in the next session)

```
Read specs/mission.md, specs/tech-stack.md, and specs/features/<name>/plan.md, requirements.md, validation.md.

Implement all task groups from the feature plan in order. After each task group, pause and summarise what was done. Commit after each group with a message referencing the task group name.

Do not make any architectural decisions not already in the spec. If you encounter ambiguity, stop and ask.
```

---

## Skill: SDD constitution (bonus — for new projects)

**Trigger:** Use when the human says "new project", "start a project", "create constitution", or when `/specs` does not exist.

### Interview for constitution

Ask these questions conversationally, one topic at a time:

**Mission**
- What is the core idea of this project in one sentence?
- Who are the primary users or audiences?
- What problem does it solve that existing tools don't?
- What is explicitly out of scope for this project?
- What tone should the mission document take? (professional / playful / technical / etc.)

**Tech stack**
- What language(s) and runtime? Any version pins?
- What framework(s)? Front end and back end?
- What database? Any ORM preference?
- What are the deployment constraints? (local only, cloud, containerised, etc.)
- Are there any packages, patterns, or architectural styles that are required or forbidden?
- What testing framework should be used?

**Roadmap**
- What are the first 3–5 features or milestones, in rough priority order?
- Should the roadmap be granular (many small steps) or high-level (few big phases)?

### Write the constitution files

`specs/mission.md` — vision, audiences, scope, out-of-scope, tone

`specs/tech-stack.md` — full stack decisions, database schema if known, architectural patterns, pipeline details, smoke tests

`specs/roadmap.md` — phased list of features with checkboxes, each phase named and described in 1–2 sentences

After writing, follow the same review-and-commit process as the feature spec skill.
