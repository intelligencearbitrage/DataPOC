# Snowflake Summit — Cortex Code Hands-On Lab
## Opening Briefing + Talking Points (v2, 10-15 min)

*Working draft. Use freely, edit hard. The talking points are the only part the audience hears.*

---

## Part 1 — Briefing Document (For your prep, not for delivery)

### The audience you are opening for

Most people who signed up for a Cortex Code hands-on lab at Summit are builders, not executives. They are some mix of the following.

Data engineers and analytics engineers who already write SQL in Snowflake and are curious whether agents can help. AI/ML engineers who have tried Claude Code, Cursor, or Copilot and want to know if Cortex Code is different enough to switch. Architects looking for a governance-native alternative to letting their teams paste code into ChatGPT. And a smaller group of skeptics who think this is all overhyped and came to see for themselves.

They did not come for a keynote. They came to do the work. Every minute you spend on framing has to earn its place by making the doing better.

### Core message (one sentence)

> Vibe coding gives you a result. Structured vibe coding gives you something your team can build on. Cortex Code is where that distinction matters most, because governance is not something you add later.

That is the seed. Everything else in the opening serves it.

### The three patterns you teach (this is the new spine of the talk)

This is the framework that holds your examples together. The patterns are useful to the audience even if they forget every specific project you mention.

**Pattern 1 — Migration becomes product.** When you write the Constitution before the migration, the second migration is faster than the first, and the third one is a SKILL. The work moves from delivery to spec maintenance.

**Pattern 2 — Governance lives in the SKILL.** When the agent runs inside Snowflake, the SKILL can reach into the platform's existing controls (RBAC, tag-based policies, masking) instead of reinventing them. The Constitution does not have to invent governance. It invokes what is already enforced.

**Pattern 3 — The spec captures the judgment, the code is disposable.** The hard part of any non-trivial agent is not the code. It is the judgment about when to do what. That judgment cannot live in a prompt because prompts evaporate. It has to live in the spec.

### Your 11 examples mapped to these patterns

This is your cheat sheet. Three go on stage. The rest are for Q&A. Hold them in your back pocket and deploy them when someone asks.

| Example | Pattern | Stage or Q&A |
|---|---|---|
| Sybase migration to Snowflake | Migration as product | **Stage** |
| Sensitive Data Governance SKILL | Governance lives in the SKILL | **Stage** |
| Natural language PowerPoint Agent | Spec captures judgment | **Stage** |
| Informatica to DBT SKILL | Migration as product | Q&A (DBT crowd) |
| Legacy SQL to Snowflake migration | Migration as product | Q&A |
| DBT optimizer SKILL | Migration as product (narrower) | Q&A (DBT crowd) |
| Snowflake environment auto-provisioning Agent | Governance / infrastructure | Q&A |
| Agile Capacity / No-Show Recommendation Agent | Domain agent (healthcare) | Q&A only if healthcare comes up |
| Inpatient / Outpatient Data Analysis Agent | Domain agent (healthcare) | Q&A only if healthcare comes up |
| Intercompany Reconciliation Application | Domain agent (FSI / finance) | Q&A if FSI comes up |
| USNWR Analytics | (Flag for me, see end of doc) | Q&A |

### Why three examples and not five

Five examples on stage starts to sound like a list of credentials. Three illustrating three different patterns sounds like a practitioner sharing what they have learned. The voice difference matters more than the example count.

If you want a fourth, the natural add is Snowflake environment auto-provisioning, because it lands inside the same beat as the Sensitive Data Governance SKILL. But it is a beat, not a separate story.

### Why this lands at Summit specifically

The Summit crowd has been hearing for two years that AI is going to change everything. Many of them have built a POC. Fewer have shipped to production. The ones who are stuck are stuck on the same things: governance, repeatability, and trust in the output.

You are not selling them on AI. They are sold. You are giving them a mental model for the part that has been missing.

### The Cortex Code tie-in (what makes this specific to Snowflake)

This is the part you can lean into harder than anyone else on the schedule.

Cortex Code runs where the data already is. No copying out. No new data perimeter to govern. Skills can encode Snowflake-native patterns, such as a Skill for AISQL extraction, a Skill for governance review, or a Skill for a model migration check. This is the productized IP layer. And the Constitution maps to Snowflake's existing controls, including RBAC, tag-based policies, masking policies, and dynamic data masking. The agent reads them as constraints, not afterthoughts.

This is the line you have earned the right to draw: **other agentic coding tools have to bolt on governance. Cortex Code has it native, and Spec-Driven Development is how you operationalize it.**

---

## Part 2 — Talking Points (the actual open, ~12 minutes)

*Bracketed lines are stage cues, not for delivery. Read out loud once before you go on. Total length is roughly 1,100 words, which lands around 11-12 minutes with pauses. If you want 15, the brownfield beat in Part 3 expands cleanly. If you only get 10, cut the third example.*

---

Good morning. Thank you for being here.

[Pause. Look at the room.]

In the next twelve minutes, before you touch the lab, I want to give you the one idea I would like you to leave this room with, even if everything else falls out of your head by Friday.

Most of you have tried agentic coding. Some of you walked in here from another session where someone showed you a working app built in thirty minutes from a single prompt. That is real. That is not a trick. That is what we now call vibe coding.

And vibe coding is fine. I do it. For a prototype, for a one-off exploration, for "let me see what this looks like before I commit to it," it is a real productivity unlock.

But here is what I noticed the first time I tried to build something serious with Cortex Code.

[Personal beat. Slow down.]

I typed in what I wanted. I got something back. It looked like an agent. It ran in Cortex. It even did the thing I asked for. And then I tried to hand it to a colleague, and we could not figure out which decisions the agent made on its own and which decisions came from me. I could not tell what was a feature and what was a hallucination. The code was real. The intent was not captured anywhere.

So I threw it away and started over.

The second time, I spent ten minutes before I typed any prompt. I wrote down what I was trying to build, the constraints I cared about, the data I had access to, and the governance my client required. Then I gave that to the agent and asked it to build to that spec.

What came back was different. Not in the demo. The demo looked the same. The difference was that I could hand the spec to a teammate, version it, change one line, and watch hundreds of lines of code change downstream in a way that made sense.

That is what we are doing today.

[Orient.]

The community has started calling this Spec-Driven Development, or structured vibe coding. The idea is simple. The agent is the muscle. The spec is the brain. You stop writing code. You start writing the context the agent does not already have.

Three things change when you do this.

You control large code changes with small changes to the spec. One sentence in a spec might produce three hundred lines of code. Change that sentence, the three hundred lines change with it.

You stop losing context between sessions. The spec persists. Your colleague picks up the work tomorrow and reads the same brain you wrote yesterday.

And the agent makes fewer mistakes, because you forced yourself to define what success looks like before generation started.

[Bridge into the patterns. This is the new beat.]

I have been using this approach for about a year now, across Cortex Code and Claude Code, on real client work. Not pitched projects. Things I built, broke, and rebuilt. I want to share three patterns that have come out of that work, because the patterns travel better than the projects.

[Pattern 1. ~75 seconds.]

The first pattern is about migration work. If your team does any modernization, such as Informatica to DBT, Sybase to Snowflake, or legacy SQL to Snowflake, you already know that the first one is bespoke. By the third one, you start noticing that you are solving the same problem in slightly different shapes.

I wrote a Constitution for a Sybase to Snowflake migration. It captured the patterns. How we map data types. How we handle stored procedures. How we validate the cutover. The first migration took the time it normally takes. The second one was meaningfully faster. The third one became a SKILL the team invokes instead of writing the migration from scratch.

The shift was not that the agent got better. The shift was that the spec became the productized version of the work. The code generated from it was almost incidental.

[Pattern 2. ~75 seconds.]

The second pattern is about governance. Every enterprise data conversation gets stuck here. Where does sensitive data live? Who can see it? What happens when a new column appears?

I built a Sensitive Data Governance SKILL that the agent invokes whenever it creates or modifies a table. The SKILL knows the client's classification rules. It checks. It applies tags. It flags exceptions for human review.

The reason this works inside Snowflake, and not as well outside, is that the SKILL is reaching into the platform's existing controls. Masking policies, RBAC, tag-based policies. The spec does not have to invent governance. It invokes what the platform already enforces.

This is what people mean when they say governance is native, not bolted on. The SKILL is one layer above the platform, not two.

[Pattern 3. ~75 seconds.]

The third pattern is the one I find most useful for skeptics. We built a natural language agent to generate PowerPoint presentations. Sounds simple. It is not.

The hard part of generating a presentation is not the code that places boxes on the slide. The hard part is the judgment. Which template fits this audience. When to use a table versus a chart. When a slide is too dense. When to break a thought across two slides. That judgment is what makes the difference between a slide your colleagues respect and a slide they ignore.

We tried to put that judgment in prompts. It did not survive context changes. We moved it into a spec. The spec captures the judgment. The code is mostly disposable.

That is the line I want you to take home. **In Spec-Driven Development, the spec captures the judgment. The code is what falls out of it.**

[The Snowflake-specific turn.]

You can do this with any agent. Claude Code, Cursor, Codex, Gemini CLI. The patterns travel. But here is what I want you to notice while you are in the lab today.

Cortex Code runs inside Snowflake. That sounds like a deployment detail. It is not. It changes what your spec has to do.

When your agent runs outside the platform, the spec has to describe the governance, the access controls, the lineage, the model approvals, all the things that sit between intent and production. When your agent runs inside Snowflake, most of that is already there. The Constitution you write today inherits the controls Snowflake already enforces. The spec becomes the contract between you, your agent, and a platform that has been doing governance for ten years.

That is the thing I want you to test for yourselves today. Build something using the spec-driven approach. Then look at what your spec did not have to say, because the platform was already saying it.

[The honest beat — when not to do this. This is the credibility move.]

One last thing before I hand it over.

Spec-Driven Development is not free. Writing a spec takes thinking, and thinking is the expensive part. If you are exploring an idea you might throw away in an hour, vibe code. If you are building something a colleague will read in three months, specify. If you are building something a client will run in production, specify carefully.

The decision is not "always specify." The decision is knowing which mode you are in.

[Transition into demos and case study.]

Here is what is going to happen in the next ninety minutes.

Before you touch the lab yourself, I am going to show you two things we have built using this approach. Then I am going to walk you through one client engagement, anonymized, where this method compressed a Teradata migration that would normally take many more months. Then you do the work.

In the lab itself, you will get a chance to vibe-code something first. Then we will ask you to slow down and write a small Constitution for the same problem. You will see the difference.

We are not here to make you write specifications for the rest of your career. We are here to help you decide, when you go back to your team next week, when to vibe and when to specify.

Let me show you what we have built.

[End of open. Transition into Demo 1.]

---

## Part 3 — What I Would Add

### 1. A single visual you sketch or show

You do not need a slide deck for an opening this length. Two options.

**Option A (whiteboard):** Draw two columns.

| Vibe Coding | Structured Vibe Coding (SDD) |
|---|---|
| Prompt → result → hope | Spec → plan → implement → validate |
| Code is the artifact | Spec is the artifact |
| One-off demos | Things your team can extend |
| Re-prompt when wrong | Re-spec when wrong |

You draw this live in ninety seconds. The act of drawing it earns more attention than any slide.

**Option B (single slide):** The same table, no extra words. One Snowflake mark in the corner. Resist the urge to add more.

If you want a second visual, a single slide showing the three patterns as three rows is useful as a memory aid. But more than two visuals in twelve minutes is too many.

### 2. A one-page handout for attendees

Most attendees will leave the lab and forget the framing within a week. Give them something to take. One side, one page.

Contents to include:

- The two-column comparison above
- The three patterns, named, with one line of explanation each
- A four-line minimal Constitution template (below)
- Three Snowflake-specific Skill ideas to try at home, such as an AISQL extraction Skill, a governance review Skill, and a Cortex Agent template Skill
- One link to a deeper reference, such as the DeepLearning.AI / JetBrains course

This is the take-home artifact. It is also IP for the practice if you put a Deloitte FDE practice line at the bottom.

### 3. A four-line minimal Constitution template

```markdown
# Project Constitution

## Mission
[What we are building. Who it is for. Why it matters.]

## Tech stack
[Languages, frameworks, data layer, models, governance constraints.]

## Roadmap
[Phase 1, Phase 2, Phase 3. Small enough that each phase is one or two features.]
```

Four headers. That is enough to start. The agent will ask you the right questions to fill it in.

### 4. Anticipated Q&A (expanded for the longer format)

The longer format means more time at the end for questions. Pre-loading answers helps.

**Q: This feels heavyweight for small projects.**
A: It is. The decision point is whether you are throwing the code away after the demo. If yes, vibe. If you or anyone else will read this code in three months, specify.

**Q: How is this different from writing requirements documents?**
A: A requirements document tells humans what to build. A spec tells an agent what to build, in a form the agent can execute and you can version. Same discipline, different artifact, different consumer.

**Q: Will the agent just hallucinate around a bad spec?**
A: It will hallucinate around any spec. The difference is that a written spec gives you a place to put the correction, instead of correcting the agent and losing the correction the next time you clear context. The fix lives in the spec, not in the chat.

**Q: Does this work on our legacy Snowflake estate, not just greenfield?**
A: Yes, with caveats. The community calls this brownfield SDD. You reverse-engineer a Constitution from what is already in the warehouse and use it as the baseline for new work. It is messier than greenfield. It is also where the real money is.

**Q: How does this work with my existing dbt or Coalesce stack?**
A: The spec sits above the tool layer. (Deploy DBT optimizer SKILL or Informatica-to-DBT SKILL example if useful.) The spec says what should be true about the data and the transformations. The tools still do what they do.

**Q: Have you done this for healthcare / FSI / [domain]?**
A: This is where you deploy your domain examples from the deep bench. For healthcare, the capacity / no-show recommendation work or the inpatient / outpatient analytics work. For FSI, the intercompany reconciliation. The pattern is the same, the spec captures the domain rules.

**Q: Is this an Anthropic thing, a GitHub thing, or a Snowflake thing?**
A: None of them. It is a practitioner pattern. GitHub's Spec Kit, OpenSpec, BMad, and others are all converging on the same loop. The good news is that the spec travels between tools.

**Q: What about model lock-in? If I write the spec for Claude, does it work with other models?**
A: Mostly yes. The spec is markdown. It travels. The Skills standard is open. Some specific instructions might need tuning for a different model, but the Constitution and feature specs are portable.

### 5. What not to promise

Two things to keep off the stage, even if asked directly.

Do not promise time savings as a specific percentage. The honest answer is "we have seen the work shift from coding to thinking, which feels slower at first and pays off in the second feature, not the first." A specific percentage will haunt you in the hallway. If you reference your Sybase migration getting faster, say "meaningfully faster" not a number.

Do not promise this replaces your engineering reviews. It changes what is reviewed. The spec gets more attention, the code gets less line-by-line. It does not remove the review.

### 6. If you are running long or short

**If you are running long (audience is engaged, you have 15 minutes):** add a brownfield beat after Pattern 3 and before the Snowflake-specific turn. Something like:

> "One thing I want to be honest about. Most of what I just described works best on greenfield. On legacy estates, where the rules were never written down and the business logic is buried in stored procedures from 2008, SDD is harder. You spend the first cycle reverse-engineering the Constitution. The good news is that the second cycle is much easier. The work is real. It is also where the most value is."

That adds two minutes and earns serious credibility.

**If you are running short (10 minutes, energy is low):** cut the PowerPoint pattern. Keep the migration and governance patterns. The migration story carries the most weight for a Snowflake audience.

### 7. A 60-second pre-stage checklist

Read this once before you go on:

1. Water on stage? Yes / No
2. Co-host name confirmed? Yes / No
3. Whiteboard or slide ready for the two-column visual? Yes / No
4. First sentence rehearsed? ("Good morning. Thank you for being here.")
5. The "I threw it away and started over" line — say it once out loud now
6. Phone on silent

### 8. A closing moment, if you get one at the end of the lab

If the lab format gives you a one-minute wrap-up after the doing, this is the line.

> The agent will get faster. The models will get better. What you take home from this room is not a tool. It is a way of working that survives the next three model releases. Write things down. Make the agent serve the writing.

That is the thing they will remember on the plane home.

---

## Things I am not sure about — flag for you

USNWR Analytics — I do not know enough about this one to place it confidently. Is it US News & World Report rankings analytics? Hospital quality reporting? Higher-ed analytics? Let me know and I will fit it into the right pattern bucket.

The two healthcare examples (capacity / no-show, inpatient / outpatient analytics) — I assumed standard interpretations. If the audience trends healthcare-light, these stay in reserve. If you spot any healthcare practitioners in the front rows, the no-show recommendation agent is a strong Q&A deploy because the value is immediate and concrete.

The Snowflake-specific product language — I have used "Constitution," "spec," "SKILL," and "Cortex Code" throughout. If the Snowflake team uses different nouns in their session materials (for example, "agent definition" instead of "spec"), adopt their nouns where they conflict. The concepts will still hold.

The co-host coordination — same flag as before. Worth a ten-minute call with whoever is running the actual lab exercises so the open does not contradict what they will demonstrate.

---

## Final note

The single most important thing about this open is that it does not feel like a lecture. The audience is already converted to the idea that agentic coding matters. They are stuck on the part you have actually solved in practice. Tell them how you got unstuck, name the three patterns, then get out of their way and let them try it.

Eleven projects taught you three patterns. Three patterns will teach this audience a way of working. That is the right compression.
