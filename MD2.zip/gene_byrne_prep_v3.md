# Interview Preparation: Gene Byrne
## Managing Partner & Chief Business Transformation Officer, IBM Consulting
### Role: Partner — Data Practice (Snowflake & Databricks)
**Tuesday Interview | Confidential**

---

# SECTION 1: WHO GENE BYRNE IS

## The Portrait

Gene Byrne is a finance-trained operator who has spent 25+ years building, scaling, and turning around IBM's most complex global service businesses. He is not a technologist. He is a P&L leader and transformation practitioner who uses technology as a means to a business end — never as the end itself.

**His core identity in one sentence:** A finance-trained builder who created IBM's BPO practice from zero, turned around four major portfolios, led global delivery across six continents, and now owns IBM Consulting's performance and transformation engine for the Americas.

---

## Career Arc

| Period | Role | What He Built |
|---|---|---|
| 1991–2001 | Controller, IBM Americas Sales & Distribution | Financial plans and controls for US, Canada, Latin America. Finance DNA formed here. |
| 2001–2003 | CFO, IBM Business Consulting Services EMEA | P&L ownership across Europe, Middle East & Africa. |
| 2001–2003 | VP Distribution & Channels, IBM Corporate Marketing | Designed Route to Market process implemented across all IBM brands. |
| 2006–2008 | VP Business Operations, IBM Global BPO | Acquisitions, solution investments, realignment of the BPO business. |
| 2008–2013 | GM, F&A and Procurement, North America | His deepest domain: finance outsourcing and supply chain at scale. |
| 2013–2015 | Global Account Management, Fortune 100 | F&A outsourcing rollout across Russia, China, US, India, Western Europe. |
| 2017–2023 | Cognitive Process Services Global Delivery Leader | AI, automation, robotics applied to BPO delivery. |
| 2022–2025 | Managing Partner, Global Quality Leader | Practice quality across IBM Consulting globally. |
| Apr 2025–Present | Managing Partner & Chief Business Transformation Officer | Operational excellence, performance, and the resource/talent engine for IBM Consulting Americas. |

---

## Education

| Degree | Institution |
|---|---|
| BS, Finance (1978–1982) | NYU Stern School of Business — serious finance pedigree. Finance person first. |
| MBA, Finance (1985–1988) | Pace University – Lubin School of Business — earned while working at IBM. Practical, not prestige-driven. |

---

## What His Background Tells You

- **Finance undergraduate and MBA** means he thinks in P&L, working capital, margin, and financial outcomes first. Every conversation needs a financial punchline within one sentence.
- **Built IBM's BPO practice from scratch** — deep respect for builders. Zero tolerance for people who only optimize what already exists.
- **Four portfolio turnarounds** — high pattern recognition for what's broken and what fixes it. He will probe whether you find the problem before it kills the project.
- **Record employee satisfaction across six continents during COVID** — he leads with people before process before technology. That sequencing is deliberate and consistent.
- **Pace Lubin MBA while working** — practicality over prestige. He respects people who built something real regardless of where they went to school.
- **OWS21 conference talk on BPO resilience:** his framing was always people → process → technology. Mirror this sequencing when discussing transformation.

---

## His Published Worldview — The Manifesto

Gene recorded a personal video manifesto and co-authored an IBM thought leadership article on strategic agility. These are chosen words, not talking points.

> **"Business as usual is dead."** Absolutist about urgency. Incremental thinking has no place in his worldview.

> **"Technology is the how. Humans are the why."** His central belief. The differentiator in the AI era is human — creativity, judgment, intuition, ethics. He is a humanist who uses technology, not a technologist.

> **"Embrace technology, but don't become it."** His warning against practitioners who become the tool they sell. He wants people who transcend the technology.

> **"The future doesn't just happen — the future gets happened."** He believes in agency, intentionality, leaders who make futures rather than react to them.

**From his Strategic Agility article:** He believes in inverting the organizational pyramid — giving control to workers closest to operations. He uses 10-person agile squads with end-to-end ownership. His persuasion style is outcome-chain reasoning: agile → engaged employees → lower attrition → lower training costs → faster invoice processing → early payment discounts → P&L impact. That is a finance person's causal chain. Mirror it.

**The alignment with your work:** His agile squad model is structurally identical to the Intelligence Arbitrage POD — small, self-contained, direct stakeholder engagement, end-to-end ownership. Don't name the parallel explicitly. Let him feel it.

---

# SECTION 2: THE ROLE — WHAT IBM IS ACTUALLY HIRING FOR

## Strategic Context: The Hakkoda Acquisition

IBM acquired Hakkoda in February 2025. Hakkoda was a pure-play Snowflake services firm — boutique, technically elite, founder-led culture. The former Hakkoda CEO now runs the US Data Practice inside IBM Consulting. The integration is less than 14 months old and almost certainly still finding its footing.

| What Hakkoda Brought IBM | What IBM Still Needs |
|---|---|
| World-class Snowflake engineering talent | Market-making muscle at C-suite level |
| Client base that trusts them technically | Enterprise transformation conversation with CFOs/CAIOs |
| Deep Snowflake delivery methodology | Platform-agnostic judgment across Snowflake AND Databricks |
| Boutique speed and technical credibility | Practice IP that scales beyond individual practitioners |
| Founder-led culture and identity | Someone who bridges Hakkoda DNA with IBM scale |

---

## What This Role Actually Is

This is a **market-making role**. IBM needs someone who can do what most senior sellers cannot (have a credible architecture conversation) and what most senior technologists cannot (open and close at the C-suite level).

**The four things Gene needs to believe you can do:**

1. **Get in the room.** Executive presence and network to secure time with CDOs, CFOs, and CAIOs.
2. **Earn the room.** Ask the questions that make senior leaders feel understood rather than sold to. Frame their problem better than they have.
3. **Shape the vision.** Help a client see a future state they haven't fully articulated — the art of the possible.
4. **Credential and close.** Connect that vision to IBM's capability in a way that makes the client want to buy from IBM specifically. Every engagement becoming the credential for the next pursuit.

---

# SECTION 3: WHO YOU ARE — FULL CONTEXT

## Career Arc

| Period | Role | What You Built |
|---|---|---|
| 1990–1992 | Analyst/Programmer, Godrej & Boyce | Early career foundation in India. |
| 1993–1995 | Systems Analyst, Tata Consultancy Services | Tech lead for National Stock Exchange — first computerized exchange in India. |
| 1995–1996 | Consultant, Mastech | Early US consulting experience. |
| 1996–2001 | Application Architect, First Data Corporation | Built enterprise data warehouses for credit and debit card businesses — financial services data infrastructure at scale from the ground up. |
| 2001–2012 | Director, Business Intelligence, Georgia-Pacific | Led 3-year BI strategy roadmap; migrated legacy Oracle DW to SAP BW; founded BI CoE and Information Governance program. Nine years inside Koch's Market Based Management philosophy after the 2005 acquisition. |
| 2012–2014 | Big Data Evangelist & Architect, Georgia-Pacific | Directed Big Data research, strategy, enterprise adoption using Hadoop. |
| 2014–2020 | Senior Manager, Strategy & Analytics, Deloitte | Scaled Big Data & Analytics practice to $200M+; launched Cloud Modernization practice, grew to $350M+ in three years across AWS, Azure, GCP. |
| 2020–Present | Snowflake Practice CTO / Technology Fellow, Deloitte | Forged Snowflake alliance generating $100M+ in Year 1; delivery oversight for 550+ programs across 325+ clients; advising C-suite on GenAI adoption and intelligence arbitrage. |

**Education:**
- BE, Production Engineering, University of Bombay (Industrial Engineering equivalent in US context)
- Post Graduate Diploma in Software Technology, National Centre for Software Technology, India
- MBA (Management with MIS), Bellevue University, USA

---

## The Koch / MBM Connection — A Strategic Depth Charge

You spent nine years at Georgia-Pacific inside Koch Industries' Market Based Management philosophy after the 2005 acquisition. This is rare, authentic common ground with Gene's worldview — not manufactured.

**The MBM-to-Gene alignment:**

| MBM Principle | Gene's Equivalent |
|---|---|
| Decision rights to those closest to value creation | Invert the organizational pyramid — control to workers closest to operations |
| Discovery over grand plans; treat ventures as experiments | Agile squads, two-week sprints, continuous improvement |
| Competitive advantage by rate of learning | "The future gets happened" — agency over reaction |
| Challenge process / creative destruction | "Business as usual is dead" |
| Subjective value / customer-first design | Persona-based design in his Agile Accelerate program |

**When to use it:** Don't lead with it. Surface it when the conversation goes to leadership philosophy, transformation culture, or empowerment:

> "That philosophy resonates deeply with me — I spent nine years at Georgia-Pacific after the Koch acquisition, which meant nine years inside Market Based Management. The core idea — that decision rights belong to the people closest to the value creation, not to the hierarchy above them — is the same instinct you're describing with your agile squad model. The mechanism is different but the belief underneath it is identical: you can't bureaucratically manage your way to transformation."

**The deeper connection:** MBM's "competitive advantage by rate of learning" is the intellectual ancestor of Intelligence Arbitrage. You can make this explicit if the conversation goes deep enough:

> "Koch's framing was that in a free market, the fastest learner wins. What I've been building toward with intelligence arbitrage is the same idea applied to AI: the competitive advantage migrates to whoever designs systems that learn and compound faster than the competition can replicate."

---

## Your Intellectual Framework — Original Published Concepts

These are not borrowed vocabulary. These are concepts you coined, published, and built client work around. Deliver them with the confidence of someone who has thought about this longer than anyone in the room.

**Intelligence Arbitrage** *(published January 2026)*
The shift from labor arbitrage (competing on execution cost) to intelligence arbitrage (competing on system design and judgment quality). Your signature concept. The labor arbitrage model that powered the SI industry for thirty years is breaking — 40–60% productivity compression from AI makes the T&M model structurally obsolete.

**Applied Intelligence Practitioner** *(published April 2026)*
The role that replaces the traditional consulting model. Not a generalist consultant with AI access — a practitioner who demonstrates rather than recommends, builds working pilots on actual client data in days, and bridges business and technical registers simultaneously. 30% technical syntax / 40% domain knowledge / 30% AI orchestration as the new skill split.

**Intelligence Arbitrage POD** *(published April 2026)*
The delivery unit that scales the Applied Intelligence Practitioner model. Three to five practitioners operating directly inside the client environment. No BA layer, no offshore handoff queue, no telephone game. The institutional model that makes high-judgment AI-accelerated consulting repeatable — a named delivery unit with defined operating rhythm, clear cost profile, and replicable engagement pattern.

**Semantic Arbitrage / Neurosymbolic AI**
The next evolution beyond intelligence arbitrage. The competitive advantage coming from domain-specific semantic understanding baked into data infrastructure via ontologies and knowledge graphs. The platform that layers semantic intelligence on top of existing data without requiring replatforming wins the AI agent war — not through better search (RAG), but through genuine reasoning.

**The Pyramid-to-Diamond workforce shift**
Junior talent base shrinks 40–60% as GenAI absorbs boilerplate work; the Applied Intelligence Practitioner layer expands. The FDE/AIP replaces the telephone game (Client → BA → PM → Offshore Dev) with a direct loop: Client → Practitioner → Solution.

**The Productivity Mirage** *(published February 2026)*
Organizations deploy AI tools without redesigning operating models. Result: efficiency gains are real, transformation isn't. "We handed people a better engine and forgot to tell them where to drive." Adoption is a primary deliverable, not an afterthought.

---

## Your Domain Depth — Structural, Not Borrowed

This matters for Gene specifically. Your F&A and supply chain credibility predates client work:

- **First Data (1996–2001):** Built financial services data warehouses for credit and debit card businesses. You have been in financial data infrastructure since before most competitors entered the industry.
- **Georgia-Pacific (2001–2014):** 13 years as Director of BI then Big Data Evangelist in a Fortune 500 CPG/manufacturing company. You understand finance, supply chain, and operations data complexity from the inside.
- **Deloitte (2014–Present):** 550+ programs across 325+ clients. Breadth no boutique can match.

When you talk to Gene about F&A transformation, you are not drawing on one or two client engagements. You are drawing on 35 years of structural exposure to financial data problems.

---

# SECTION 4: YOUR CORE POSITIONING

## The One-Paragraph Statement — Internalize This

> "I operate at the intersection of executive problem framing and technical architecture. I go into a room with a CFO or CAIO, understand what's keeping them up at night around data and AI, help them see what's actually possible — not what the vendor brochure says — and connect that to a working pilot in 90 days. I've been doing that as a solo practitioner at Deloitte. The constraint has been brand and scale. IBM solves both of those."

---

## How Your Background Maps to What Gene Needs

| Your Experience | What It Signals to Gene |
|---|---|
| Built $200M analytics + $350M cloud modernization practices | You are a practice builder — you've done at scale exactly what he's asking you to do at IBM |
| $100M Snowflake alliance Year 1 | You can forge and commercialize strategic relationships, not just deliver inside them |
| 550+ programs, 325+ clients | Pattern recognition breadth no boutique firm can match |
| Finance Data Hub → Emerson pursuit credential | Your delivery creates the next sales asset — the flywheel he needs to build |
| Published trilogy: Intelligence Arbitrage, AIP, IA POD | You shape thinking in this space; you don't follow it |
| Neurosymbolic AI / ontology / knowledge graph work | Differentiated technical depth beyond what Hakkoda brings |
| First Data + Georgia-Pacific domain depth | Structural F&A and supply chain credibility — not borrowed from client work |
| Koch / MBM: nine years inside market-based management | You have lived the empowerment philosophy he has built his career around |
| Cortex Code FDE compression: 2-week → 2-day build | Demonstrable productivity multiplier with published proof |
| INFA2DBT CAIO-level competitive close | You close at executive level against alternatives |

---

## Bridging to the Hakkoda Team

You are not competing with Hakkoda practitioners on Snowflake depth. You complement them on dimensions they structurally lack:

> "The Hakkoda acquisition brought IBM world-class Snowflake engineering talent and a client base that trusts them technically. What that profile typically doesn't have — and what I bring — is the enterprise transformation conversation at CFO and CAIO level, the platform-agnostic architecture judgment across Snowflake and Databricks, and the practice-building discipline to turn tribal knowledge into scalable IP. I've built two $200M+ practices at Deloitte. I know what it takes to go from boutique excellence to institutional scale. Those capabilities are complementary to what Hakkoda built, not overlapping."

---

## The Databricks Gap — Turn It Into a Differentiator

> "My production depth is primarily Snowflake and Cortex — that's where my current client work lives. On Databricks I understand the architecture deeply and have advised clients on environments where both platforms coexist. The platform-agnostic positioning is a strategic asset at partner level — clients don't want a Snowflake salesperson or a Databricks salesperson, they want someone who can tell them the truth about which workload belongs where and why Apache Iceberg matters as the open layer that avoids regrettable lock-in. That's a partner-level conversation. That's where I operate."

---

# SECTION 5: YOUR OPENING NARRATIVE

**Use Version 1** if the interview opens as a structured "tell me about yourself."
**Use Version 2** if the conversation has already touched on AI strategy or market positioning.

---

## Version 1 — Leads with Arc, Earns the Concept

> "I'm an industrial engineer by training — the discipline that asks whether any process that happens twice should be redesigned or eliminated. That instinct has been the through-line across 35 years: from building data warehouses for credit card businesses at First Data in the late nineties, through thirteen years at Georgia-Pacific building BI and Big Data capability from the inside, through scaling Deloitte's analytics practice to $200 million and the cloud modernization business to $350 million, to forging the Snowflake alliance that generated $100 million in its first year.
>
> What I've watched across all of that is a single structural shift: the constraint in every business used to be execution capacity. That constraint is dissolving. What I call intelligence arbitrage is what comes next — competitive advantage migrating from who executes fastest to who has designed the smarter system. My work now is helping C-suite leaders architect that transition: moving their F&A, supply chain, and operations functions from labor arbitrage to intelligence arbitrage, using Snowflake and Databricks as the platform foundation and agentic AI as the delivery mechanism.
>
> IBM with the Hakkoda capability is exactly where that work belongs at scale. The engineering depth is there. What you're building now is the market-making layer on top of it — and that's what I do."

---

## Version 2 — Leads with Concept, Backs into Credibility

> "The framing I keep coming back to is intelligence arbitrage — the idea that competitive advantage is migrating from who executes tasks faster to who has designed the systems that make better decisions. I published on this in January and the response told me it named something most organizations feel but haven't articulated: the labor arbitrage model that powered the systems integration industry for thirty years is breaking, and what replaces it requires a fundamentally different kind of practitioner.
>
> I've been building toward that practitioner model for 35 years — industrial engineering by training, financial services data warehousing at First Data, thirteen years at Georgia-Pacific building BI and Big Data from the inside, then Deloitte where I scaled the analytics practice to $200 million, built the cloud modernization business to $350 million, and forged the Snowflake alliance that generated $100 million in its first year.
>
> The reason IBM makes sense is specific: Hakkoda brought the platform depth. IBM brings the enterprise relationships. The gap is the Applied Intelligence Practitioner — someone who can walk into a CFO conversation, frame the intelligence arbitrage opportunity in their specific business context, and connect that to a working pilot in 90 days. That's the role I'm here to fill."

---

# SECTION 6: YOUR FOUR FLAGSHIP ENGAGEMENT STORIES

## Story 1: Finance Data Hub (Industrial Manufacturer → Emerson Pursuit)
**Lead with this. It is squarely on Gene's home turf — his entire GM career was in exactly this domain.**

**The business problem:**
> "A large industrial manufacturer running SAP ECC, SAP S/4, Oracle R12, and Oracle EDMCS simultaneously — the classic multi-ERP nightmare where nobody trusts the numbers. The CFO's problem wasn't a technology problem — it was a trust problem. Finance leaders couldn't make a capital allocation decision with confidence because they had no single version of actuals, plan, and forecast with consistent dimensions across entities."

**What you built:**
- Medallion architecture on Snowflake (Bronze → Silver → Gold) with finance-specific data products at the Gold layer
- Gold layer data products: Product Line P&L, Site/Ledger Actuals, Customer Profitability, Plan vs. Forecast vs. Actuals with consistent dimensions
- Finance KPIs that speak Gene's language directly: Sales, Standard Profit, Orders, Backlog, Book to Bill, Price/Volume/Mix (PVM), FX Variance, Constant Currency
- Close and Consolidations: FCCS and ARCS on a trusted Gold layer — reconciliation compressed from days to hours
- Planning & Budgeting: EPBCS. Profitability & Cost Allocations: EPCM
- Consumption into tools finance personas already use: Oracle Narrative Reporting, Workiva, SmartView, Power BI — no forced migration
- AI layer: multi-agent systems, Gen AI for NLQ and anomaly detection, ML forecasting — built on a trusted foundation, not before it
- Wave 2: persona-based design — built the data model from the CFO's questions backward, not forward from the technology

**The Gene-specific angles:**
- The PVM, FX Variance, Constant Currency metrics are exactly what he managed as GM of F&A. Use those terms specifically.
- The close and consolidation workload (FCCS/ARCS) is his career domain. Name it directly.
- The persona-based design principle mirrors his agile inversion philosophy — empowering the workers closest to the operations.

**The market-making punchline:**
> "The work became the reference architecture we used to credential the firm with Emerson Electric in the same space. My delivery became the sales asset for the next pursuit. That flywheel — every engagement creating the credential for the next one — is exactly what I want to build at IBM."

**Lessons earned — use as practitioner wisdom:**
- "Fully define the future architecture before jumping into technology acquisition. The most expensive mistake is buying the platform before defining the operating model of the future state."
- "Link finance transformation with the enterprise data lake from day one — parallel programs with separate sponsors conflict at the worst possible moment."
- "Change management is not an afterthought. I treat adoption as a primary deliverable — the technology going live is not success. Finance leaders using it to make decisions is success."
- "Front-load data quality validation. Data quality issues discovered after go-live in a finance transformation are catastrophic."

---

## Story 2: Evident Scientific — Intercompany Reconciliation + AI

**Evident Scientific:** Bain Capital-backed global scientific imaging company spun out of Olympus, operating across 14+ legal entities on SAP and NetSuite feeding into Snowflake.

> "The intercompany reconciliation problem looked like a data problem. It was actually a trust problem — entities didn't trust each other's numbers. The technology made the reconciliation auditable. That's when the operating model changed."

- AI-enabled intercompany reconciliation engine on Snowflake Cortex
- KG_NODE / KG_EDGE knowledge graph layer to model entity relationships — neurosymbolic architecture in practice
- Goal: compress the intercompany close from days to hours — direct working capital implications across 14 legal entities
- CFO-level deliverable: trust in the numbers at close, not a dashboard

---

## Story 3: INFA2DBT — Closing at CAIO Level Against Competition

**Why this story matters for a market-making role:** A competing approach was on the table at the CAIO level. Your seven-agent architecture won. This is your commercial close story.

- Seven-agent architecture: Orchestrator, Job Analyst, S2T Mapping, Java Interpreter, SQL Translator, Complexity Classifier, Validation
- Complexity-tiered effort estimation showing 95–98% effort reduction over manual approaches
- Scope risk management: identified SOW language conflating dbt's auto-generated lineage graph with explicitly authored orchestration DAGs — reanchored before it became a delivery failure

> "In complex transformation engagements, the most valuable thing you can do in the first 30 days is find the assumption that will kill the project if left unexamined."

---

## Story 4: Cortex Code / Applied Intelligence Compression — Use When AI Depth Comes Up

From your published article, February 2026:

> "Cortex Code compresses what would have been a two-week effort into a two-day build. The key is the Skills architecture — codified instruction sets stored as SKILL.md files that transform the agent's general reasoning into specialized expertise. Every engagement adds to a reusable IP base rather than starting from zero. That compression isn't incremental improvement — it's a category change in how consulting engagements deliver value."

This story demonstrates that you are an active practitioner stress-testing tools against real enterprise workloads and publishing what you find — not an executive who talks about AI.

---

# SECTION 7: EXPECTED QUESTIONS & ANSWER FRAMEWORKS

## The Opening

**"Tell me about yourself / Walk me through your background."**

Use Opening Narrative Version 1 or 2 from Section 5. End on: *"The technology is never the hard part. The operating model change always is."* He will lean in.

---

## Transformation Questions

**"What does enterprise transformation actually mean to you?"**

> "Transformation means the client operates differently after you leave than before you arrived — not just faster, but fundamentally differently. If I've automated what they were already doing, that's optimization. Transformation is when the mental model of the work changes. The CFO stops asking 'can I trust these numbers' and starts asking 'what should I do about what these numbers are telling me.' That's the line. The Finance Data Hub work was about getting a CFO across that line — from a trust problem to a decision-making platform."

**"What separates a real transformation from a failed one?"**

> "Sponsorship and speed. Most transformations die in the middle — the sponsor moves on, or the pace slows to the point where the business stops believing. I design engagements so something visibly works within 90 days on the client's actual data. Not a proof of concept in a sandbox — something a CFO can point to in a business review. The other failure mode — and I've written about this — is confusing access to AI tools with actual adoption. Deploying tools without redesigning the operating model is how you get productive laziness: the efficiency gains are real, the transformation isn't."

**"What's your view on where AI transformation is failing right now?"**

> "The delivery model is broken. Organizations built their AI approach for a world where proof was expensive and slow. That world is gone. The pattern I keep seeing: discovery phase, use case register, prioritization workshop, six months later a roadmap exists, the business sponsor has moved on, the pilot that could have run in week two is still a box on a slide. The model I've developed — demonstrate, don't recommend — is the antidote. Start with a working pilot on the client's actual data against the actual problem on day one. The feasibility debate ends when a business leader watches their own problem resolve itself through something that didn't exist three days ago."

---

## AI & Technology Questions

**"How are you actually applying AI in client work — not theoretically?"**

> "Three active areas. For a large industrial manufacturer, we built a Finance Data Hub on Snowflake — the AI layer sits on a trusted Gold layer and delivers forecasting, anomaly detection, and natural language queries into tools the CFO's team already uses. For Evident Scientific, we're building an AI-enabled intercompany reconciliation engine — compressing a multi-entity close from days to hours with direct working capital implications. And I've been building Cortex Code Skills — codified instruction sets that compress what used to be a two-week build into two days and leave reusable IP behind. That compression isn't theoretical — I published on it in February."

**"What makes your approach different from what every other firm is pitching?"**

> "Most firms are selling AI as a product layer on top of existing processes. I start from the operating model and work backward to the technology. The question I ask clients first isn't 'what data do you have' — it's 'what decision are you making today that you wish you could make better, faster, or with more confidence?' That reframe changes everything about what you build. I call it intelligence arbitrage: the competitive advantage coming from who designed the smarter system, not who executed fastest. That's a concept I've developed and published — it's not borrowed vocabulary."

**"Where do you see the frontier of AI in enterprise data?"**

> "The next frontier is what I call semantic intelligence — and it goes beyond what most firms are talking about. RAG and better retrieval are fighting the last war. They get very good at finding documents that match a query. But when an AI agent needs to answer 'which high-value customers increased spending on products we're discontinuing,' search alone isn't enough. You need agents that understand Customer, Purchase, and Product Status are connected entities with specific business logic. That's where ontologies and knowledge graphs come in — not the academic kind, but the practical, business-logic-encoding kind. The platform that layers semantic intelligence on top of existing data infrastructure without requiring replatforming wins the AI agent war. That's the architecture I'm actively building toward."

**"Why data platforms specifically — why is this the right practice right now?"**

> "Every transformation you've led — F&A, procurement, supply chain, BPO — is sitting on top of a data problem nobody has fully solved. The data is fragmented across SAP, NetSuite, Ariba, legacy warehouses. The AI that could actually change how those functions operate can't work until the data foundation is right. Snowflake and Databricks are the platforms where that foundation gets built. The data practice isn't adjacent to enterprise transformation — it's the infrastructure layer underneath everything IBM Consulting sells. Getting this practice right makes every other practice more credible."

---

## Commercial & Market-Making Questions

**"What's your current book of business? What revenue have you originated personally?"**

Be specific. Reference the Snowflake alliance ($100M Year 1), active engagement pipeline, and practice revenue influenced as CTO ($350M cloud modernization, $200M analytics). Frame as practice building, not just delivery.

**"How do you develop an opportunity from first conversation to signed SOW?"**

> "It starts with an executive visioning session — not a product demo. I ask the CFO or CAIO what they would change about how their function operates if data weren't the constraint. That question surfaces the real problem, which is almost never the problem they called me about. From there I work with them to identify two or three use cases where the ROI is clear and the data is accessible — those become the pilot. Built on their actual data in their actual environment, not a sandbox. The pilot is designed from day one for handoff to a delivery team. The SOW captures the pilot plus the roadmap to scale."

**"Walk me through how you've turned a delivery into a sales asset."**

> "The Finance Data Hub work is the clearest example. We designed the architecture, documented the patterns, packaged the lessons learned, and walked into the Emerson Electric pursuit with a working reference architecture. We could say: we've done this before — here's exactly what we built for a client with your technology stack and your finance complexity, here's what we learned, here's how it maps to your situation. That credentialing cut the sales cycle significantly. Every engagement should build the credential for the next one. That's the flywheel model — and it's what I want to build at IBM."

---

## Build & Scale Questions

**"How do you go from pilot to scale?"**

> "Most pilots fail to scale because they were designed to prove the technology, not the operating model. If the pilot requires the engagement partner in the room for it to work, it won't scale. I design pilots around replicable patterns — documented accelerators, parameterized workflows, codified Skills — so the handoff to a hardening team is a knowledge transfer, not a reinvention. The Intelligence Arbitrage POD model I've been developing takes this further: a small, self-contained delivery unit operating directly in the client environment, using AI agents to compress execution, delivering working solutions in sprint cycles. The institutional model — named unit, defined operating rhythm, clear cost profile — is what makes it something IBM can offer as a discrete line item, not just a staffing configuration."

**"How do you operate inside a large organization like IBM?"**

> "I treat the internal organization the same way I treat a client — find the people who want to win, align to their goals, build things they can point to. I don't build things that only I can run. The Cortex Code Skills architecture is a good example: every piece of IP I build is designed to be handed off to a team that can harden and scale it. That's what makes the front-end market-making work valuable — it's designed for institutional leverage from day one."

---

## Leadership Questions

**"Tell me about a time you led through significant difficulty."**

> "I walked into an engagement mid-stream where the SOW language had conflated two completely different things — dbt's auto-generated lineage graph and explicitly authored orchestration DAGs. The client's team and our team were about to spend six months building to different definitions of done. I identified the misalignment early, reframed the conversation at the CAIO level, and restructured the scope before it became a delivery failure. The lesson: in complex transformation engagements, the most valuable thing you can do in the first 30 days is find the assumption that will kill the project if left unexamined."

**"How do you build and motivate teams under pressure?"**

> "People perform best when they understand how their work connects to an outcome that matters — not a project milestone, but a business result someone cares about. I spend disproportionate time on that translation: here's the CFO's problem, here's how our sprint connects to solving it, here's what winning looks like. Psychological safety under pressure is operational, not soft. Teams that surface bad news early fix problems. Teams that hide bad news fail late. I published on this recently — the AI productivity mirage: we deploy tools without telling people where to drive. Same principle applies to teams under any transformation pressure."

---

## Fit & Why IBM Questions

**"Why IBM specifically? Why now?"**

> "IBM Consulting is in a genuinely interesting position — you have global delivery scale, deep domain expertise in F&A and supply chain, the Hakkoda acquisition bringing serious Snowflake platform capability, and a mandate to embed AI into operating models at enterprise scale. That's exactly the problem set I've been living in. The question that interests me is: how do you combine boutique platform engineering excellence with IBM's transformation heritage and enterprise relationships to build something neither could do alone? I've built practices at scale before. I know what the flywheel looks like when it's working. I want to build it here."

**"What would you bring that IBM doesn't already have?"**

> "A practitioner who has built $200M+ practices from scratch, forged strategic alliances that generated $100M in first-year revenue, and is currently operating at the front edge of AI-native delivery — publishing on intelligence arbitrage, the Applied Intelligence Practitioner model, and the Intelligence Arbitrage POD as the delivery unit that scales it. I can walk into a CFO conversation and have the finance transformation conversation, the architecture conversation, and the AI strategy conversation in the same room on the same day. And I build reusable IP along the way so every engagement makes the next one faster. That compound effect on practice value is what IBM needs from this hire."

---

## The Curveball

**"Where have you failed? What did you learn?"**

> "Early in my career I confused technical elegance with business value. I built things that were architecturally beautiful and nobody used. The lesson was that adoption is the product — not the solution. I published on this recently as the productivity mirage: you can hand people a better engine and forget to tell them where to drive, and the efficiency gains are real while the transformation isn't. I now treat adoption as a primary deliverable and design for the person who has to use it on Monday morning, not for the architecture review board."

---

# SECTION 8: QUESTIONS TO ASK GENE

Don't ask all of these. Pick four or five that feel natural. The best interviews feel like two practitioners talking about a shared problem — not a candidate working through a prepared list.

---

## To Open the Conversation

> "You've described your mandate as connecting strategy to execution at scale. Where is the biggest gap between those two right now — and what's making it hard to close?"

*Why it works: Invites him to talk about his actual problem. Positions you immediately as someone who thinks in execution gaps, not org charts.*

---

## On the Role & Integration

> "The Hakkoda integration is still relatively fresh — 14 months in. How are you thinking about preserving what made Hakkoda excellent while scaling it inside IBM's delivery model?"

*His answer tells you whether the integration is healthy or fractured. Essential intelligence before you accept anything.*

> "The former Hakkoda CEO is now leading the US Data Practice. How do you see the Partner role I'd be stepping into relating to that leadership — and what does the first 90 days look like?"

*You need to understand the org and the ramp before day one.*

> "How does IBM currently source senior data and AI conversations — primarily through existing account relationships, or are you building a net new logo motion?"

*You need to know whether you're hunting or farming. The skills and infrastructure required are completely different.*

> "What does success look like in year one — is it pipeline generated, revenue closed, practice IP built, or some combination?"

*You need the scorecard before you agree to play the game.*

---

## On AI and the Market

> "How are you thinking about the Snowflake/Databricks coexistence story with clients — competitive or complementary? And has that stance shifted as Databricks has moved up the stack?"

*Shows you're thinking at practice strategy level, not engagement level.*

> "Your clients are being pitched AI by everyone right now. What separates the engagements that actually deliver durable value from the ones that become expensive pilots that never scale?"

*His answer will align closely with your published work on the productivity mirage. If it does, that convergence is worth naming.*

---

## On His Worldview — The Deeper Conversation

> "You've written about humans representing the 'why' of transformation while technology is the 'how.' In practice, how do you keep that balance when clients are mostly asking for the technology?"

*References his manifesto without quoting it. Will create genuine chemistry.*

> "You've turned around four major portfolios. Looking back, what was the leading indicator — the thing that told you early whether a turnaround was going to work or not?"

*Nobody asks turnaround operators this question. His answer will be remarkable. Signals you respect his operational track record, not just his title.*

---

## To Close the Conversation

> "Based on everything we've talked about — is there anything about my background or experience where you see a gap I should address?"

*Direct, confident. Gives him an opening to surface hesitation while you're still in the room to respond.*

> "What are the two or three things that would need to be true twelve months from now for you to feel like this hire was exactly the right one?"

*Reframes from evaluation to partnership. Gives you concrete criteria for any follow-up conversation.*

---

# SECTION 9: LANGUAGE ALIGNMENT & WATCH-OUTS

## His Language — Mirror These Terms

| Use This | Not This |
|---|---|
| AI-enabled operating models | AI solutions / Cortex implementation |
| Durable enterprise value | POC / accelerator / pilot |
| Strategic clarity with disciplined execution | Agile / iterative / sprint |
| Performance at scale | Scalable solution / enterprise-grade |
| The why of transformation | The technology / the platform |
| Finance transformation / close cycle | Data pipeline / ETL / ingestion |
| PVM, FX Variance, Constant Currency, Book to Bill | KPIs / metrics / dashboards |
| Working capital / early payment discounts | Efficiency gains / cost savings |

---

## Your Language — Use These Confidently

These are your original published concepts. Don't soften them or attribute them elsewhere:

- **Intelligence Arbitrage** — your signature frame; introduce it early and let him engage
- **Applied Intelligence Practitioner** — your role definition; use when describing what IBM is hiring for
- **Intelligence Arbitrage POD** — your delivery model; use when discussing how the practice scales
- **Semantic Arbitrage / Neurosymbolic AI** — your differentiated technical frontier; use if AI depth comes up
- **The Productivity Mirage** — your diagnosis of why AI adoption fails; use when transformation failure comes up
- **The Pyramid-to-Diamond shift** — your workforce model; use if practice building or talent comes up
- **Demonstrate, don't recommend** — your operating principle; use when discussing engagement model

---

## Financial Outcomes — Always Land Here

Gene is a finance MBA. Every technical point needs a financial punchline within one sentence:

- Don't stop at "we automated the reconciliation" → land on "which compressed the intercompany close from days to hours, with direct working capital implications across 14 legal entities"
- Don't stop at "unified data model" → land on "which gave the CFO a single version of actuals, plan, and forecast — the foundation for any AI that actually changes how decisions get made"
- Don't stop at "95–98% effort reduction" → land on "which changes the economics of every migration engagement in the practice pipeline"
- Don't stop at "Finance Data Hub" → land on "which became the reference architecture that opened the Emerson pursuit — my delivery became the sales asset"

---

## His People-First Sequencing

From his OWS21 conference talk during COVID, his framing was always: **people → process → technology.** Mirror it:

> "The change management question always comes first — who are the people whose workflow changes, and what do they need to trust the new system? The process design follows. The technology is last, because it's in service of the first two."

---

## The Pyramid Inversion — His Signature Belief

Gene's agile article explicitly argues for giving control to workers closest to operations. Your Intelligence Arbitrage POD model is structurally identical. If the moment presents itself:

> "This isn't just a structural change — it's an inversion of where judgment lives. The pyramid concentrates decision-making at the top and execution at the base. The POD puts both in the same hands, at the point of contact with the problem."

Don't name the parallel to his model. Let him make the connection.

---

## Watch-Outs

- **Don't drift into technology-first territory.** Every technical point needs a business punchline. No exceptions with this audience.
- **Don't undersell your scale.** You built $200M+ practices. Gene built IBM's BPO practice from scratch. He respects builders who quantify what they built. Own your numbers explicitly.
- **Don't speak your published concepts as if you're trying them out.** You coined them, published them, and built client work around them. Deliver them with that authority.
- **Don't quote his manifesto video back to him directly.** Speak his language as if it were your own — because it genuinely is. He'll feel the alignment without you naming it.
- **Don't ask about compensation, title, or team size** in this conversation. Stay in the transformation leader register throughout.
- **Don't assume he knows Snowflake or Databricks technically.** He may be looking to you for platform conviction. Be ready to educate as a trusted advisor would.
- **Don't over-rotate on FDE language.** You are a practice builder and thought leader currently operating in forward-deployed mode — not someone who defines themselves by a delivery format.

---

## The Optional Closing Line

If you get an opportunity for a final statement and the moment feels genuinely right:

> "I've always believed the future gets happened, not waited for. That's why I build things rather than advise on them."

He will recognize his own worldview. Use it only if it lands naturally — never as a scripted close.

---

## The Meta-Preparation

**Sunday night:** Re-read his manifesto transcript. Not to quote it — to inhabit his worldview before you walk in. He believes the future gets happened, humans are the why, and good enough is dead. Walk in already living inside those beliefs.

**The genuine alignment:** His agile squad model, your Intelligence Arbitrage POD. His empowerment philosophy, your MBM experience. His "humans are the why," your "intelligence arbitrage." His "business as usual is dead," your "the labor arbitrage model is breaking." None of this is manufactured. The alignment is real. Let it show without announcing it.

---

*You have 35 years of preparation for this conversation. Walk in and let Gene see that clearly.*

---
*Confidential — Prepared for Interview Preparation Purposes Only | Version 3*
