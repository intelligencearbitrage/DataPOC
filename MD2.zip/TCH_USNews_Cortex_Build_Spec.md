# Build Specification: Texas Children's Hospital
## US News Performance Intelligence — Snowflake Cortex Analyst Layer
### Pilot Scope: Endocrinology

**Version:** 0.1 (Draft for Review)
**Status:** Awaiting Epic table schema confirmation from TCH data team
**Last Updated:** May 2026

---

## 1. Purpose and Scope

This specification defines the build requirements for a Snowflake Cortex Analyst-powered performance intelligence layer for Texas Children's Hospital. The pilot focuses exclusively on the Endocrinology service line and its US News Health System Rankings metrics.

The system enables two distinct user personas to query performance data in natural language without writing SQL:

- **Service line leaders** — querying ranking metrics, gap status, and improvement scenarios at a population and specialty level
- **Care coordinators** — querying patient-level care gaps, follow-up status, and outreach priorities

This spec covers the Cortex Analyst semantic model, data layer design, user interface requirements, and integration architecture. It does not cover Epic flowsheet write-back or thyroid registry automation. Those are addressed in a separate design document.

---

## 2. Architecture Overview

```
Epic EDW (SQL Server)
        |
        | [TCH replication — one-time for pilot]
        v
Snowflake Raw Layer (replicated Epic tables)
        |
        | [dbt or Snowflake Tasks — transformation]
        v
Snowflake Semantic Layer (curated views + Cortex Analyst YAML model)
        |
        | [Cortex Analyst API]
        v
Natural Language Query Interface (Streamlit in Snowflake or lightweight web UI)
        |
        |-- Service Line Leader view (metrics, gaps, scenario modeling)
        |-- Care Coordinator view (patient-level tasks, outreach queue)
```

**Core Snowflake Cortex capabilities in scope:**

| Capability | Use |
|---|---|
| Cortex Analyst | Natural language queries over the semantic model for both personas |
| Cortex Complete | Gap narrative summarization and care action descriptions |
| Cortex Search | Patient name / MRN lookup within coordinator workflow (if patient population exceeds 500 records) |

---

## 3. Data Layer

### 3.1 Source Tables Required from TCH EDW

The following Epic tables are required for replication into Snowflake. TCH data team to confirm availability and column mappings against this list.

**Patient and Encounter Tables**

| Table | Purpose |
|---|---|
| `PATIENT` | Demographics, MRN, age, active status |
| `ENCOUNTER` | Encounter dates, types, department, provider |
| `DIAGNOSIS` | ICD-10 codes linked to encounters |
| `PROBLEM_LIST` | Active chronic conditions per patient |

**Clinical / Registry Tables**

| Table | Purpose |
|---|---|
| `FLOWSHEET_DATA` | Thyroid registry fields (TSH, T4, medication, dosage) |
| `LAB_RESULT` | Lab values with result dates and reference ranges |
| `MEDICATION_ORDER` | Active thyroid medication prescriptions |
| `REFERRAL` | Referral in/out records for Endocrinology |

**US News Metric Tables**

| Table | Purpose |
|---|---|
| `USNEWS_HDI_METRICS` | Existing SQL-computed US News metric values (TCH-owned) |
| `USNEWS_SUBMISSION_LOG` | Prior year submission records and benchmarks |
| `CARE_GAP_REGISTRY` | Existing care gap definitions and closure status |

> **Open item:** TCH data team to confirm exact table and column names. The names above are illustrative. Schema confirmation is a prerequisite before semantic model development begins.

### 3.2 Snowflake Layer Design

Three-layer structure within Snowflake:

```
DATABASE: TCH_USNEWS_PILOT
├── SCHEMA: RAW          — replicated Epic tables, no transformation
├── SCHEMA: CURATED      — cleaned, joined, metric-ready views
└── SCHEMA: SEMANTIC     — Cortex Analyst YAML model + serving views
```

**Key curated views to build:**

| View | Description |
|---|---|
| `v_endo_patient_population` | Active Endocrinology patients with demographics and diagnosis flags |
| `v_thyroid_care_gaps` | Per-patient gap status: overdue labs, missed follow-ups, no recent encounter |
| `v_usnews_endo_metrics` | Current metric values for Endo-relevant US News measures |
| `v_coordinator_task_queue` | Prioritized outreach list with gap type, days overdue, last contact |
| `v_performance_trend` | Monthly metric trend for Endocrinology over rolling 12 months |

---

## 4. Cortex Analyst Semantic Model

The semantic model is defined as a YAML file registered in Snowflake. It is the translation layer between natural language questions and the curated SQL views.

### 4.1 Model Structure

```yaml
name: tch_usnews_endo_performance
description: >
  Performance intelligence model for Texas Children's Endocrinology
  service line. Covers US News ranking metrics, thyroid care gaps,
  and coordinator outreach priorities.

tables:
  - name: endo_patient_population
    base_table: TCH_USNEWS_PILOT.CURATED.v_endo_patient_population
    description: Active Endocrinology patients with diagnosis and demographic context
    dimensions:
      - name: patient_mrn
        column: MRN
        description: Unique patient identifier
      - name: patient_age_group
        column: AGE_GROUP
        description: Pediatric age band (e.g., 0-2, 3-12, 13-17)
      - name: primary_diagnosis
        column: PRIMARY_ICD10
        description: Primary thyroid-related ICD-10 code
      - name: active_status
        column: IS_ACTIVE
        description: Whether the patient is currently active in the registry
    metrics:
      - name: total_patients
        description: Total active Endocrinology patient count
        expr: COUNT(DISTINCT MRN)

  - name: thyroid_care_gaps
    base_table: TCH_USNEWS_PILOT.CURATED.v_thyroid_care_gaps
    description: Per-patient care gap status for thyroid population
    dimensions:
      - name: gap_type
        column: GAP_TYPE
        description: Type of care gap (e.g., overdue_lab, missed_followup, no_encounter_12m)
      - name: days_overdue
        column: DAYS_OVERDUE
        description: Number of days past the expected care action date
      - name: outreach_status
        column: OUTREACH_STATUS
        description: Current outreach status (not_started, attempted, completed)
    metrics:
      - name: open_care_gaps
        description: Total number of unresolved care gaps
        expr: COUNT(*) FILTER (WHERE CLOSED_DATE IS NULL)
      - name: avg_days_overdue
        description: Average days overdue across open gaps
        expr: AVG(DAYS_OVERDUE)

  - name: usnews_endo_metrics
    base_table: TCH_USNEWS_PILOT.CURATED.v_usnews_endo_metrics
    description: US News ranking metric values for Endocrinology
    dimensions:
      - name: metric_name
        column: METRIC_NAME
        description: US News metric identifier
      - name: metric_category
        column: METRIC_CATEGORY
        description: Clinical domain of the metric
      - name: measurement_period
        column: MEASUREMENT_PERIOD
        description: Time period for the metric calculation
    metrics:
      - name: current_metric_value
        description: Current computed value for the metric
        expr: AVG(METRIC_VALUE)
      - name: peer_benchmark_value
        description: Benchmark value from comparable pediatric hospitals
        expr: AVG(PEER_BENCHMARK)
      - name: gap_to_benchmark
        description: Difference between current performance and peer benchmark
        expr: AVG(METRIC_VALUE - PEER_BENCHMARK)
```

### 4.2 Sample Natural Language Queries the Model Must Support

**Service line leader persona:**

- "Which Endocrinology US News metrics are below peer benchmark right now?"
- "Show me our metric performance trend for the last 12 months"
- "If we close the 50 most overdue thyroid care gaps, which metrics move and by how much?"
- "How many Endo patients are lost to follow-up?"
- "What is our current registry completeness rate?"

**Care coordinator persona:**

- "Show me patients with overdue TSH labs sorted by days overdue"
- "Which patients haven't had an Endo encounter in the last 12 months?"
- "Give me today's outreach priority list"
- "How many patients did I contact last week and what were the outcomes?"
- "Show me all patients with hypothyroidism who are missing a recent medication review"

---

## 5. User Interface

### 5.1 Platform Recommendation

**Streamlit in Snowflake** for the pilot. This keeps all data within the Snowflake environment, avoids external hosting, and allows rapid iteration without a separate deployment pipeline.

If TCH requires integration with an existing portal, the Cortex Analyst API can be exposed as a backend service. This is a post-pilot consideration.

### 5.2 Interface Design — Two-Persona Layout

The application presents two distinct views accessible via a role-based login or a simple tab toggle for the pilot.

**Service Line Leader View**

- KPI tile row: current metric values vs. peer benchmark for top 5 Endo US News metrics
- Trend chart: 12-month rolling performance on selected metrics
- Natural language query box: free-text query with Cortex Analyst response rendered as table or chart
- Scenario modeling panel: input a gap closure count, see projected metric impact
- Submission readiness indicator: traffic light status per metric vs. submission threshold

**Care Coordinator View**

- Priority outreach queue: patient list sorted by days overdue, gap type, and last contact date
- Natural language query box: patient-level queries with Cortex Analyst response
- Per-patient gap summary: on row click, expand to show all open gaps, last encounter, lab history
- Outreach action log: mark outreach attempted / completed directly in the interface (written back to Snowflake, not to Epic in the pilot)

### 5.3 Out of Scope for Pilot UI

- Epic write-back or flowsheet update from the interface
- Automated outreach (SMS, email) — coordinator logs actions manually
- Multi-specialty views — Endocrinology only

---

## 6. Build Phases

### Phase 1: Data Foundation (Days 1-5)
- TCH replicates required Epic tables to Snowflake
- Confirm schema and column mappings against Section 3.1
- Build `RAW` schema with replicated tables
- Validate row counts and date ranges against known EDW values

### Phase 2: Curated Layer (Days 6-12)
- Build five curated views listed in Section 3.2
- Define care gap logic with TCH clinical team (what counts as overdue, what thresholds trigger a gap)
- Validate curated views against existing EDW reports for accuracy
- Build `v_usnews_endo_metrics` using existing TCH SQL logic as the base

### Phase 3: Semantic Model (Days 13-18)
- Finalize Cortex Analyst YAML model based on confirmed curated views
- Register semantic model in Snowflake
- Test against the 10 sample queries listed in Section 4.2
- Iterate on model based on query accuracy — target: 8 of 10 sample queries return correct results without SQL correction

### Phase 4: Interface (Days 19-28)
- Build Streamlit in Snowflake application with two-persona layout
- Connect Cortex Analyst API to query box in both views
- Integrate Cortex Complete for gap narrative generation in coordinator view
- User acceptance testing with one service line leader and one care coordinator from TCH

### Phase 5: Pilot Validation (Days 29-45)
- Two-week live use period with designated TCH users
- Track: query accuracy rate, time saved vs. prior manual process, care gaps identified proactively vs. reactively
- Collect feedback for post-pilot roadmap

---

## 7. Open Items — Must Resolve Before Build Starts

| # | Item | Owner | Required By |
|---|---|---|---|
| 1 | Confirm exact Epic table names and columns available for replication | TCH Data Team | Before Phase 1 |
| 2 | Confirm care gap definitions — what clinical thresholds trigger each gap type | TCH Clinical / Endo Team | Before Phase 2 |
| 3 | Provide existing SQL logic for US News Endo metrics | TCH Data Team | Before Phase 2 |
| 4 | Confirm Snowflake environment access and permissions for build team | TCH IT | Before Phase 1 |
| 5 | Identify pilot users — one service line leader, one care coordinator | TCH Project Lead | Before Phase 4 |

---

## 8. Out of Scope for This Pilot

- Epic flowsheet pre-population or write-back
- Thyroid registry automation (covered in separate design document)
- Multi-specialty rollout beyond Endocrinology
- Automated patient outreach (SMS/email)
- Integration with US News submission portal
- Production-grade role-based access control (basic user toggle sufficient for pilot)

---

## 9. Success Criteria

The pilot is considered successful if:

1. Cortex Analyst correctly resolves at least 80% of queries from the sample set in Section 4.2 without manual SQL correction
2. At least one previously unidentified care gap cohort is surfaced through the coordinator view within the two-week live period
3. Service line leader can identify metric performance vs. peer benchmark without opening a spreadsheet or submitting a data request
4. TCH team confirms the curated metric values match existing EDW report outputs within acceptable tolerance (to be defined with TCH)

---

## 10. Registry Automation Design Document

The thyroid registry automation workstream — including Epic flowsheet pre-population, AI-assisted data extraction from clinical notes, and inpatient thyroid case identification — will be documented separately as a **design and feasibility document**, not a build spec.

That document will cover: the technical path using Epic FHIR APIs or Interconnect, the PHI governance requirements, the physician validation workflow, and a realistic assessment of pilot feasibility vs. future-phase implementation.

---

*This document is a living specification. Sections marked with open items will be updated as TCH team confirms details. Do not begin Phase 2 development until all Phase 1 open items are resolved.*
