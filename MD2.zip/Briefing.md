# IBM Interview Briefing
## AI & Data Practice — Snowflake / Databricks Practice Leadership Role
**Interviewer:** Jeff Tennenbaum, Executive Architect, IBM Consulting Federal Practice
**Date:** Today

---

## 1. The Role in Plain Language

IBM acquired Hakkoda (Snowflake services boutique) ~1 year ago and is scaling its commercial AI & Data practice across Snowflake and Databricks. The model is:

- A lead client services partner **brings you and your team into deals**
- You **envision solutions** to client signature issues
- You **engage senior stakeholders** — CDOs, CDAOs, Finance, Supply Chain leaders
- You **credential the team** as best suited to deliver
- You manage a delivery org: seasoned delivery leaders + supporting architects
- Primary platform focus: **Snowflake and Databricks**
- **Urgent gap: Databricks** — Hakkoda was Snowflake-native; exponential Databricks growth is outpacing current capability

> **Key market reality:** 60%+ of clients now have **both** Snowflake and Databricks. The question is no longer "which platform" — it's **co-existence strategy**. This is the highest-value, least-served advisory position in the market today.

---

## 2. Your Positioning: The Core Narrative

### The Through-Line
Your career is a sequence of platform wave bets — each one made early, each one validated by practice built from scratch.

| Year | Platform Wave | Your Move |
|------|--------------|-----------|
| 1996 | Data Warehousing | Specialized: Oracle, Informatica, Ab Initio, SAP BW |
| 2012 | Hadoop / Big Data | Stepped down to IC to go hands-on; built Deloitte Big Data practice from scratch |
| 2015 | Cloud / Legacy Modernization | Built legacy migration practice (Oracle, Teradata, Hadoop → MPP/Synapse) |
| 2018 | Snowflake | Discovered early; built practice; became Practice Lead + CTO |
| 2023+ | Agentic AI / Cortex | Building Forward Deployed Engineering practice |

**The pattern is the proof.** Five times. Five platforms. Always early. Always built — never inherited.

### The Opening Statement (if asked "Tell me about yourself")
> *"My career is essentially a series of bets on platform waves — and I've been early on most of them. The throughline isn't any particular technology. It's the ability to see where the gravity is shifting, get close to it fast, and build the practice before the market catches up."*

---

## 3. The Databricks Narrative — Fully Neutralized

### Why It's Not a Gap

1. **Databricks is commercial Spark.** Spark was the core compute engine of the Hadoop ecosystem you were hands-on with from 2012. The engine is not new to you — the productized platform is.

2. **Competitive fluency.** As Snowflake Practice Lead and CTO, tracking Databricks was professional due diligence — you've followed the platform roadmap, feature evolution, and win/loss patterns closely.

3. **Platform-agnostic track record.** You have recommended Databricks over Snowflake to clients when it was the right answer. This is rare, verifiable, and signals that your judgment is trustworthy — not vendor-captured.

### Platform History (Talking Points for Jeff)

| Then | Now |
|------|-----|
| Databricks: Open-source Spark, ML/AI only, required hard-to-find Spark programmers, complex to tune, poor for DW workloads | Feature-comparable platform; expanding into data warehouse territory; Unity Catalog; commercial accessibility improved dramatically |
| Snowflake: Cloud data warehouse; AI practically nonexistent | Cortex, Snowpark, agentic AI; expanding into ML/AI territory |

**Bottom line:** Both platforms converged toward each other. Platform selection today is less about capability and more about **organizational skills, existing investments, and governance maturity.**

### The Semiconductor CDO Story (Use This)
> *"A CDO at a large semiconductor company pressed me to tell him which platform he should choose. I remember joking with him — I said, 'Toss a coin.' The point wasn't flippancy. The point was that both platforms were functionally comparable for his use case. The decision came down to his team's skills and what they already had in place."*

This story signals: honest advisor, platform-agnostic judgment, CDO-level credibility.

### The Databricks Question — Prepared Answer
> *"Let me tell you what I did in 2012. I was leading all of AI and Data. When Hadoop emerged, I voluntarily stepped down to Individual Contributor to learn it hands-on — because I knew that was the only way to build on it credibly. Then Deloitte hired me to build the practice from scratch.*
>
> *Databricks is Spark commercialized. I've used the engine. I've tracked the platform competitively for years as Snowflake Practice Lead. I've recommended it to clients when it was the right answer. My production depth today is Snowflake Cortex — but I'd ask you: what's the evidence I can't do what I've done five times before?"*

---

## 4. The Co-Existence Thesis — Your Differentiating Position

**The market insight most practitioners miss:**

Most Snowflake practitioners are Snowflake advocates. Most Databricks practitioners are Databricks advocates. Neither can credibly advise a client who has both — which is now the majority of enterprise clients.

You are one of fewer than 10 people in a major consulting firm who can hold the co-existence conversation with a CDO without a platform bias.

### Co-Existence Framework (Talking Points)

- **Databricks wins on:** ML engineering, data science workloads, open formats (Delta Lake, Iceberg), MLflow, Unity Catalog, Python-native teams, lakehouse architecture
- **Snowflake wins on:** SQL-first analytics, governed data warehousing, Cortex AI, Snowpark, structured data products, ease of governance
- **Both are needed when:** Data science and analytics personas coexist (almost always in enterprise), different data domains have different latency/format requirements, or clients have already invested in both

**The advisory value:** Help clients define which workloads belong on which platform, how governance spans both, and how agentic AI workflows consume from both without creating a data quality split-brain.

### The Iceberg Layer — Multi-Compute Engine Strategy

The most sophisticated co-existence advisory position is recommending **Apache Iceberg as the open storage layer** underneath both platforms.

> *"I advise clients to store their data in Iceberg — an open table format — as a multi-compute engine strategy. Both Snowflake and Databricks support Iceberg natively and well. The client's data assets sit in open format on their cloud storage; the compute engine becomes a choice, not a commitment. That's how you avoid vendor lock-in while still getting the best of both platforms."*

**Why this matters architecturally:**
- Data stored in Iceberg is readable by Snowflake, Databricks, Spark, Flink, Trino, and others
- Compute engine decisions become reversible — clients aren't hostage to either vendor's pricing or roadmap changes
- It future-proofs the architecture against the next platform wave (which will come)
- It's a genuinely vendor-neutral recommendation — and clients recognize it as such

**This is your strongest differentiator in the co-existence conversation.** Most practitioners advise on platform selection. You advise on storage architecture that makes platform selection a runtime decision rather than a permanent commitment. That's a different and higher-value conversation.

---

## 5. Alignment with Jeff Tennenbaum's Worldview

Jeff's article reveals his mental model precisely. These are your natural points of intellectual alignment — use them naturally, not as recitation.

| Jeff's Position | Your Equivalent |
|----------------|-----------------|
| Governance must be **embedded in architecture**, not documented in policy | Governed data products as pre-execution certification layer before agentic workflows run |
| **Fail-closed quality gates** before agents execute | Snowflake Cortex Skill validation pattern: completeness, freshness, schema contract checks |
| **Semantic tagging + business meaning** as the interpretive layer | KG_NODE/KG_EDGE knowledge graph layer for Evident Scientific |
| **Bounded agentic autonomy** with logged decision pathways | Perceive→Plan→Act→Reflect loop with explicit HITL control gates |
| Legacy architectures **amplify** AI risk rather than resolving it | Legacy modernization practice: Informatica/Talend/Teradata → Snowflake-native |

**One line to use if the architectural conversation opens up:**
> *"The pattern I keep seeing with clients is exactly what you described — governance that's implied rather than enforced. The moment you put an agent on top of that, the implied part breaks visibly and at scale."*

---

## 6. Anticipated Questions & Prepared Answers

### Q: "How do you think about the Snowflake vs. Databricks architectural boundary?"
> *"For most of my career the question was binary. Today it's not. 60%+ of enterprise clients have both. The real question is co-existence architecture — which workloads belong on which platform, how governance spans both, and how you stop the data quality problem from splitting across two platforms. I'd argue that's the highest-value advisory conversation in the market right now, and most practitioners can't have it without a platform bias. I can."*

### Q: "What's your read on where Databricks is winning deals Snowflake isn't?"
> *"ML engineering workloads with Python-native teams, open format requirements, and MLflow-anchored model lifecycle management. Unity Catalog has closed the governance gap significantly. Where Databricks is winning is where the data science persona drives the platform decision, not the analytics or BI persona. Snowflake still wins on SQL-first, governed data products, and structured analytics — and Cortex has closed the AI gap faster than most people expected."*

### Q: "Walk me through a senior stakeholder engagement where you reframed what a client thought they needed."
Use the semiconductor CDO story. Frame it:
> *"The client came to me wanting a platform recommendation — a 'tell me which one to pick' decision. The reframe was: this isn't primarily a platform decision, it's an organizational capability decision. Once he accepted that frame, we built a structured assessment around his team skills, existing investment, and data domain fit. That's the conversation a CDO actually needs."*

### Q: "How do you credential a team you're bringing into a deal?"
> *"Three things. First, I tell the client what we've built and where — specific architectures, specific outcomes, not logos. Second, I bring in the right subject matter depth for their specific signature issue — not a generalist team. Third, I'm honest about what we don't know and how we'll close it. CDOs and CDAOs can tell the difference between a team that's done it and a team that's pitching it. The credentialing happens in the first 30 minutes of the discovery conversation."*

### Q: "IBM has engineering depth. What's missing and how would you close it?"
> *"IBM has extraordinary engineering execution. What a practice like this needs alongside that is the market-facing motion — the ability to walk into a CDO conversation, translate their business problem into an architectural solution, and frame why IBM is the right team to deliver it. That's not an engineering skill. It's 35 years of pattern recognition across industries, platforms, and stakeholder types. That's the gap I'm being brought in to fill."*

### Q: "Why IBM over Deloitte?"
> *"Deloitte is a services firm. IBM is becoming a products-and-services firm — the Hakkoda acquisition signals that intent clearly. I want to build IP that scales beyond headcount. IBM has the engineering depth and the pipeline; what it needs is the market-facing practice leadership to convert that pipeline into delivered outcomes. That's exactly the gap I'm being asked to fill."*

---

## 7. Questions to Ask Jeff

### On the Practice
- *"IBM has strong Snowflake capability from Hakkoda. In your view, is the Databricks gap primarily a talent problem, a go-to-market problem, or both?"*
- *"How does the Federal AI practice think about overlap with commercial AI & Data — are there reusable assets and IP, or are they genuinely separate tracks?"*

### On the Operating Model
- *"The model as I understand it is that a lead partner brings in the practice team for solutioning and credentialing. How much runway does practice leadership realistically have to build reusable IP versus being pulled into live delivery from day one?"*
- *"What does the first 90 days look like — and what does success versus failure look like at the 6-month mark?"*

### On IBM's Evolution
- *"IBM has a well-earned reputation for engineering excellence. In your experience, where does the market-facing capability — the ability to frame and sell the solution before it's built — sit today, and where does it need to go?"*

---

## 8. Your LinkedIn Corpus — Verifiable Proof of Positioning

You are active on LinkedIn. Jeff is not — but IBM will look you up before and after this interview.

Your published articles and commentary constitute a **public, timestamped record** of:
- Platform-agnostic advisory positions (including recommending Databricks over Snowflake)
- Intellectual depth across topics Jeff covers — and beyond
- Thought leadership trajectory over time — not retroactive positioning

**Topics your LinkedIn corpus covers that align with or extend Jeff's worldview:**

| Topic | Jeff's Coverage | Your Extension |
|-------|----------------|----------------|
| Data governance & architecture | Core thesis of his Feb 2026 article | Covered earlier; applied to commercial enterprise, not just Federal |
| Knowledge graphs & ontologies | Referenced implicitly via semantic tagging | Explicit, hands-on: KG_NODE/KG_EDGE architecture, Protégé, FIBO |
| Agentic AI governance | Addressed in Federal context | FDE practice model, Perceive→Plan→Act→Reflect, HITL framework |
| Neurosymbolic AI | Not addressed | Your explicit intellectual territory — combining formal ontologies with LLMs |
| Intelligence arbitrage | Not addressed | Your concept: identifying where AI creates asymmetric leverage |
| 20X–30X productivity model | Not addressed | Trauma surgeon analogy — AI as force multiplier for expert practitioners |
| Forward Deployed Engineering | Not addressed | Your practice model: architects embedded in delivery, not advising from distance |

**How to reference this in the interview (if asked about thought leadership):**
> *"You can look up my LinkedIn articles — I've been publishing on these topics for a few years now. Platform agnosticism, knowledge graphs, agentic AI governance. Some of it tracks closely with what you've written on the Federal side. You were ahead of me on some of it by a few years — but I've pushed into territory you haven't covered yet, like neurosymbolic AI and the FDE delivery model."*

That last line is the right register: intellectually honest, confident, and genuinely curious — not competitive.

---

### 🗞️ Your Most Recent Article (March 17, 2026) — Use This Deliberately

**"10X Is the Floor. Here's Why Most FDE Practices Will Never Reach It."**

This article is your most important credential for this interview. Published three days ago. It does four things simultaneously:

**1. It challenges the prevailing FDE market narrative — publicly.**
The market is racing to build pit crew FDE pods (Salesforce's model, IBM's model, everyone's model). Your article argues this is the wrong archetype. Intelligence arbitrage needs a *trauma surgeon* — a single integrating intelligence with depth, decisiveness, and AI amplification — not a headcount-scaled pod. That's a critique of the model IBM is building. Walking in with a published critique and a better model is a power position, not a risk.

**2. It names four specific gaps — which are your value proposition.**

| Gap | What IBM's Practice Likely Has | What You Bring |
|-----|-------------------------------|----------------|
| Business AND technical depth | Engineering depth (Hakkoda); market depth underdeveloped | Both — 35 years across platforms, industries, and C-suite |
| Direct execution model (no telephone game) | Traditional consulting delivery chain | FDE model: direct engagement, architecture in the room, tangible output in days |
| Full communication range (engineer → CDO) | Strong technical delivery | Demonstrated CDO/CDAO advisory track record |
| Compounding effect of all three | Partial — missing the integrating intelligence | The trauma surgeon model: you are the integrating intelligence |

**3. It explains exactly why IBM is capturing 2X–3X when 20X–30X is possible** — and positions you as the practitioner who has diagnosed the gap and built the model to close it.

**4. It proves your voice matches your resume.** Direct, willing to name what's broken, zero hedging. Jeff will respect this register.

**How to use it in the interview:**
If asked about your FDE thinking or your approach to the practice build:
> *"I published something on this three days ago — I'd encourage you to look it up. The short version: the market is building pit crews, but intelligence arbitrage needs a trauma surgeon. Most FDE practices are capturing 2X–3X because they're scaling the wrong archetype. I've seen this pattern consistently enough that I wrote it down."*

Then let him ask the follow-up. He will.

---

## 9. Your Personal Connection Point

The CEO of Hakkoda — the acquired company — was a former colleague who personally asked you about joining IBM to help scale the practice. This is not a cold interview. You were recruited into this conversation by someone who knows your work. Lead with confidence, not deference.

---

## 10. Meta-Guidance for the Interview

**Jeff's register:** 36+ years at IBM. He has seen every platform wave, every consulting trend, every AI hype cycle. He will not be impressed by buzzwords or enthusiasm. What will land:

- **Specificity** over generality
- **Intellectual honesty** over polish
- **Positions you're willing to defend** over safe consensus
- **Pattern recognition** across decades over point-in-time expertise

Match his register. Be direct. Take positions. If you disagree with something — say so and explain why. That is the level of peer engagement he respects.

---

*Prepared for interview with Jeff Tennenbaum, IBM Consulting Federal Practice*
