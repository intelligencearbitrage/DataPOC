# Project instructions — Spec-Driven Development

This project uses **Spec-Driven Development (SDD)**. Read this file at the start of every session.

---

## What SDD means for you (the agent)

You are the **execution muscle**. The human is the **architect**. Your job is to implement what the specs say, ask clarifying questions when something is ambiguous, and never fill gaps with arbitrary choices. When context is missing, surface the decision to the human rather than guessing.

The spec is the brain. Code is a downstream artifact of the spec. If code and spec disagree, the spec wins — flag the discrepancy and ask which to update.

---

## Spec file structure

Every project has a `/specs` directory with:

```
/specs
  mission.md       — why this project exists, audiences, scope, vision
  tech-stack.md    — architecture decisions, frameworks, DB schema, constraints
  roadmap.md       — phased feature list; the living backlog
  /features
    <feature-name>/
      plan.md        — task groups and sequence
      requirements.md — functional + technical requirements
      validation.md   — how to verify the feature is done
```

---

## Your behaviour rules

**Reading specs**
- At the start of every session, read `specs/mission.md`, `specs/tech-stack.md`, and `specs/roadmap.md`.
- Before working on a feature, read its full `/specs/features/<name>/` folder.
- Never rely on conversation memory across sessions — the specs are the source of truth.

**Making changes**
- All significant decisions must be reflected in the specs. If you make a choice that isn't in the spec, ask the human whether to add it.
- When the human asks you to change something, update **both** the spec and the code. Never let them drift.
- Work in small, reviewable steps. Prefer frequent commits over large all-at-once changes.

**Asking questions**
- If a spec is ambiguous or has a gap, ask before proceeding. Present options with trade-offs, not open-ended questions.
- Flag contradictions between spec files explicitly. Don't silently pick one.

**Validation**
- After implementing a feature, run the validation steps in `validation.md`.
- Write tests aligned to the requirements in `requirements.md`, not to the implementation details.

**What NOT to do**
- Do not make architectural decisions (database choice, auth approach, API design) without explicit human approval and a corresponding spec update.
- Do not rename files, move components, or refactor across features without updating any specs or READMEs that reference them.
- Do not merge a feature branch until the human has reviewed and approved.

---

## Workflow phases

### Phase 0 — Constitution (once per project)
Run the constitution skill or follow the constitution prompt to produce `mission.md`, `tech-stack.md`, and `roadmap.md`. Work conversationally with the human to make all key decisions before writing any code.

### Phase 1 — Feature planning (per feature)
1. Create a feature branch: `git checkout -b feature/<name>`
2. Run the feature-spec skill or follow the feature spec prompt.
3. Write `plan.md`, `requirements.md`, `validation.md` in `/specs/features/<name>/`.
4. Commit the spec. Get human approval before proceeding.

### Phase 2 — Implementation (per feature)
1. Clear context (`/clear` or start a new session).
2. Load: mission, tech-stack, roadmap, and the feature spec.
3. Implement task groups from `plan.md` in order.
4. Commit after each task group or logical unit of work.

### Phase 3 — Validation (per feature)
1. Run validation steps from `validation.md`.
2. Write or update tests. Run them.
3. Do a deep review: check for spec drift, incomplete requirements, and broken assumptions.
4. Ask the human to review the diff before merging.

### Phase 4 — Replanning (between features)
1. Update `roadmap.md` to mark completed features.
2. Review whether the next roadmap item is still correct.
3. Apply any cross-cutting changes to the constitution (new tech decisions, policy changes, etc.) on a separate branch if the change is significant.
4. Update the changelog if a changelog skill is installed.

---

## Brownfield / legacy projects

If this project has existing code but no `/specs` folder, generate the constitution by:
1. Reading the codebase, `README.md`, any `TODO` or issue files.
2. Reverse-engineering `mission.md`, `tech-stack.md`, and a `roadmap.md` from what exists.
3. Asking the human to review and correct before committing.

The same feature loop then applies going forward.

---

## Key principles (always apply)

- **Spec before code.** Planning time is never wasted. Three minutes of clear spec writing is worth twenty minutes of corrective implementation.
- **Small steps.** If a feature feels too big to implement in one pass, break it into sub-phases on the roadmap.
- **Human in the loop.** The human reviews diffs, approves merges, and makes all architectural calls. Speed up by making reviews easy, not by skipping them.
- **No context drift.** Clear your context window between features. Don't carry assumptions from one feature into the next.
- **Specs are versioned.** Commit spec changes alongside or before the code that implements them.
