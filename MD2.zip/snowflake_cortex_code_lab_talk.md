# Snowflake Cortex Code — Hands-On Lab Opening Remarks

**Speaker:** Rupesh Dandekar, Technology Fellow, Deloitte
**Length:** ~15 minutes (target ~1,900 words at conversational pace)
**Audience:** Snowflake Cortex Code hands-on lab attendees
**Goal:** Set the context for the lab with real client patterns, then get out of the way.

---

## 1. Opening — meet the room (~1 min)

Thank you. Before I start, a quick orientation. You came here for a hands-on lab, so I am going to keep the talking part short. Fifteen minutes. Then you go into the product.

I lead the Forward Deployed Engineering practice at Deloitte. We are partnering with Snowflake on the kinds of engagements you are about to get a feel for in the lab. What I want to do in this time is not show you a marketing version of what we are doing with Snowflake AI and Cortex Code. I want to show you the working version — the things we have built, the things we got wrong before they worked, and the patterns we keep seeing across clients.

We will cover four things. DBT optimization. Talk to My Data agents. Snowflake Intelligence. And the Skills we are building on top of all of it. Each one is something we are doing in real engagements right now, not a slide.

---

## 2. The disarm — what is actually different here (~1.5 min)

I want to acknowledge something before we go further. Right now, every vendor in this space is showing AI demos. Most of them work beautifully in the demo and break the moment they hit real enterprise data. You have probably sat through a few. So have I.

The reason we are leaning into Snowflake Cortex Code in our delivery is not because the AI is more impressive. The AI is comparable across the major platforms. The reason is that in Cortex, the AI sits inside a governed data platform. The compute does not leave Snowflake. The masking policies are already enforced. The role-based access is already there. The semantic layer is right next to the data.

That sounds like plumbing. It is plumbing. But our experience tells us that the difference between an AI use case that ships to production and one that stays a demo is almost always plumbing. So that is the lens for the next twelve minutes. Not the model. The platform around the model.

Let me show you what that actually looks like.

---

## 3. Use case one — DBT optimization (~3 min)

The first one is the most boring and the most useful. We do a lot of migrations. Teradata to Snowflake. SAP HANA to Snowflake. Legacy on-premise platforms to Snowflake. The pattern is always the same. The client has thousands of SQL scripts, stored procedures, and transformation logic that nobody fully remembers anymore. The people who wrote it are gone or busy. The documentation is incomplete. The business cannot tell you what is critical and what is dead.

On our first migration of this kind, we did not have an accelerator. We spent an inordinate amount of time in the source platform's studio going through graphical models, reading SQL line by line, and pulling SMEs into rooms to explain what their old code did. It was slow, it was expensive for the client, and it was genuinely demoralizing for the team.

So we built a tool. SQL-to-DBT conversion, running on Cortex. It reads the legacy SQL, understands the transformations, and produces DBT models on the Snowflake side. It does not get everything right on the first pass. The work it actually replaces is not the writing — it is the reading. And once it has produced a candidate model, it documents what it produced and tests it against the source so the engineer is reviewing a working artifact rather than translating from scratch.

Our migration approach is based on the hypothesis that if you keep the data structures the same, ingest the same data, and apply the same transformations, then you should get the same results in your target consumption layer. The tool exists to make that hypothesis testable at scale. You translate the transformation, you run both sides, and you compare. The transformation layer of these migrations now lands forty to seventy percent faster.

Why am I starting here? Because if you are about to spend the next hour in Cortex Code, the most immediate thing it can do for your team is exactly this kind of work — reading code, understanding intent, producing equivalent code in a target dialect, debugging what does not match, and writing the documentation that the original codebase never had. That is what foundation models are good at, and that is the thing your migration backlog is full of.

---

## 4. Use case two — Talk to My Data agents (~3 min)

The second one is the one every CFO and every CDO has been asking for since 2005. Talk to my data. Let me ask a question in English and get the right number back.

Every BI tool has promised this. None of them have delivered. There is a reason for that. The reason is not the language model. The reason is that the model has nothing to ground its answer in. It does not know which "revenue" you mean. It does not know whether your fiscal year ends in June or December. It does not know that the Asia-Pacific reporting unit was reorganized in Q3.

So what we are doing in our Talk to My Data engagements on Snowflake is the unglamorous part. We are building the semantic layer underneath the agent. Cortex Analyst with semantic models. The model name, the column name, the join logic, the business definition — all of it expressed in a place the agent can read.

When the user asks the question, the agent does not invent a number. It generates SQL against the semantic model, runs that SQL on the actual data, and returns the answer with the SQL it ran. You can read the SQL, challenge it, and ask the agent to refine it.

We have done this for finance close use cases — variance analysis, account-level walks, why is this number what it is. We have done it for clinical operations — patient cohort questions, throughput, length of stay. The pattern is the same. The agent is the easy part. The semantic model is the work. And the way you actually verify that the semantic model is right is by generating synthetic questions against it — questions you know the answer to — and watching whether the agent gets them right. That synthetic test set is the thing that tells you whether you can put a real CFO or a real clinician in front of it. The reason this can run inside Snowflake is that the semantic model lives next to the data, the data is already governed, and the role-based access controls are already in place. The agent inherits all of that. It does not bypass it.

If you take one thing from this section into the lab — when you build something that lets a human ask a question of your data, spend ninety percent of the time on the semantic layer and ten percent on the agent. Most teams do the opposite. That is why their demo works and their pilot does not.

---

## 5. Use case three — Snowflake Intelligence (~3 min)

The third one is the agentic layer, and this is where I want to slow down a little.

In the regulated industries we work in — healthcare, life sciences, financial services — getting agents to work on real enterprise data hits two walls. The first wall is governance. You cannot let an agent loose on data it should not see. PHI, PII, customer financials, material non-public information — there are rules and there are auditors and there are consequences. The second wall is grounding. The agent has to give an answer the business can act on, which means it has to be wrong less often than the human it is helping.

Snowflake Intelligence is the layer where this gets interesting. The agent runs inside the platform. It has access to the governed data, the semantic models, the masking policies, the row-access policies. The agent does not see what the user is not allowed to see, because the platform enforces that before the agent gets the rows.

Let me give you an anonymized example. We are working with a large healthcare provider. Before any pipeline could run, we had to classify what was PHI and PII across roughly two thousand source tables. We used Cortex's classification function to do that work. Masking policies were deployed before any data landed in the analytics zone. By the time an agent is built on top of that zone, the agent has no path to the unmasked data. It does not need to be trusted. The platform is what is trusted.

That is the pattern we keep seeing in regulated environments. Bolting an agent onto a data platform from the outside does not work. The agent ends up needing copies of data, copies of credentials, copies of policies, and the audit story falls apart on contact with a regulator. The pattern that works is the opposite. Bring the agent to the data. Let the platform's governance be the agent's governance.

When you are in Cortex Code in a few minutes, you will see this directly. The agent you build is calling functions inside Snowflake. It is reading from tables you have access to. It cannot read what you cannot read. That is not a feature. In regulated industries, that is the only way this is going to ship.

---

## 6. Skills — the part that compounds (~2.5 min)

The last thing I want to talk about is Skills, because this is where the work starts to compound across engagements, and it is the part that most consulting models are not prepared for.

A Skill, the way we are using the term, is a reusable, governed capability. It is not a prompt. A prompt lives in a notebook somewhere and gets lost. A Skill is a piece of behavior you write once, version, test, and call from anywhere your agents run. It has inputs, outputs, and a defined contract.

The origin story here is honest. We kept rebuilding the same patterns on every project — entity extraction, document classification, schema matching, code conversion, PHI classification, variance analysis. Different code, same job, every time. So we started building Skills.

The SQL-to-DBT conversion I described earlier is now a Skill. PHI classification is a Skill. Semantic-model-grounded question answering is a Skill. They are called by agents. They are reused across clients. They are improved by the team that uses them most, and the improvements flow back. And what you are going to see in Cortex Code shortly is that creating one of these is not a six-month engineering effort. It is something a working engineer can do in a development session, from the development environment or from the CLI, and ship to the rest of the team the same day.

The reason this matters for you, and this is the slightly uncomfortable part: in a traditional services model, the temptation is to rebuild things every time, because rebuilding is billable. Skills make rebuilding stop being economic. The accelerator does the work, and the team spends its time on the part that only humans can do — the integration, the change management, the governance design, the conversation with the business about what actually has to be true.

That is, in our experience, where the value is. Not in the lines of code the agent generates. In the work the team can now stop doing.

---

## 7. Close — what to look for in the lab (~1 min)

I will stop there because the lab matters more than my voice.

In the next hour, you are going to do all of this hands-on. You are going to write code in Cortex Code and watch it generate, debug, and self-correct. You are going to generate synthetic data to test what you build. You are going to document what you write so the next person on your team can pick it up. And you are going to package what you have built as a Skill that someone else can call tomorrow. You can do all of this from the development environment or from the CLI, depending on which side of that line you live on.

Two things to take with you when you walk in. The first is to look for the seams — where the agent meets the data, where the Skill gets called, where the governance is enforced. The model you can swap. The seams are what decide whether what you build leaves the demo and reaches production.

The second is that the work you are about to do, with one engineer in one development session, used to be the work of a small team across a sprint. That is the change. It is not the AI. The change is what one practitioner can now finish before lunch.

That is enough from me. Over to the lab.

---

## Calibration notes (for your eyes only — delete before delivery)

- **Move 1 (Enter from their world):** Open acknowledges they are here for a hands-on lab and that talk-time is short.
- **Move 2 (Disarm):** Section 2 names the obvious — every vendor is showing demos — before pivoting.
- **Move 3 (Origin stories):** DBT section opens with "we did not have an accelerator." Skills section opens with "we kept rebuilding the same patterns." Both earn the claim before stating it.
- **Move 4 (Hypotheses, not conclusions):** "Our migration approach is based on the hypothesis that…" preserved verbatim. "Our experience tells us…" used twice. "The pattern we keep seeing…" used in Section 5.
- **Move 5 (Orient constantly):** Section 1 lays the map. Section 6 closes with "I will stop there because the lab matters more than my voice." Section 7 gives "two things to take with you" — explicit map for the lab.
- **Numbers land quietly:** 40–70% migration acceleration is now stated flatly with no buildup ("The transformation layer of these migrations now lands forty to seventy percent faster.").
- **Sentences develop, not fragment:** Removed three-fragment sequences in §3 ("It was slow. It was expensive..."), §3 ("Reading code. Understanding intent..."), §4 ("It generates SQL... It runs... It returns..."), §4 ("You can read the SQL. You can challenge it..."), §6 ("It has inputs. It has outputs..."), and §6 ("Entity extraction. Document classification..."). All now flow as comma-joined clauses or full sentences with connectors.
- **Edge:** "Most of them work beautifully in the demo and break the moment they hit real enterprise data." "Skills make rebuilding stop being economic." "It is not the AI. The change is what one practitioner can now finish before lunch." Kept, not sanded down.
- **Close ends on a provocation, not performed warmth:** Replaced "Have fun in the lab" with "Over to the lab," preceded by the quietly provocative "what one practitioner can now finish before lunch."
- **Cortex Code capabilities woven in throughout:** Code generation, debugging, and documentation in §3 (DBT). Synthetic data generation in §4 (Talk to My Data). Creating Skills and CLI in §6 (Skills). Full enumeration in §7 (Close), where the audience needs it for the lab.
- **No client names, no confidential numbers** from either source deck.

---

## Open questions for you

1. **Pacing.** With the close now mentioning specific Cortex Code capabilities (generation, debug, self-correct, synthetic data, documentation, Skills, CLI), §7 is denser. If that feels rushed at the podium, I can pull synthetic-data generation up into §4 and leave §7 lighter.
2. **The "before lunch" line.** That is the close's edge, and it is a bet. If it lands, the room will smile. If your audience is more senior-buyer than practitioner, it might read as glib. Tell me which room you're in and I'll either keep it or replace it with something more measured.
3. **The CLI mention.** I positioned CLI as "for the side of the line you live on" — assumes a mixed audience. If it's mostly practitioners who will absolutely use the CLI, I should give it more weight. If it's mostly buyers, I should drop it.
4. **PHI specificity.** Still using "two thousand source tables" and "large healthcare provider." Pull on this if you want it more abstract.
