# Evident MIS Intercompany Reconciliation — Snowflake + Streamlit Implementation Specification

**Companion document to:** `matching_process_documentation.md`
**Purpose:** Provide the technical implementation — DDL, stored procedures, Cortex configuration, and Streamlit application code — for the four-phase matching pipeline.
**Platform:** Snowflake (with Cortex AI), Streamlit-in-Snowflake (SiS), Snowflake Tasks for orchestration.
**Target deployment:** Evident's Snowflake account (provisioning pending — Joe + Lloyd).

---

# Section 1 — Architecture Overview

```
┌─────────────────────────────────────────────────────────────────────────┐
│                         INGESTION LAYER                                  │
│  Excel uploads (xlsx) ──→ Snowflake Stage (S3-backed) ──→ Python UDF    │
│                                                       (ingestion adapters)│
└──────────────────────────────────────┬──────────────────────────────────┘
                                       ↓
┌─────────────────────────────────────────────────────────────────────────┐
│                         DATA LAYERS                                      │
│  REF        — reference master data (entities, GL accounts, forex)      │
│  RAW        — raw Excel snapshots (one row per file/tab/cell)           │
│  STAGING    — IC_LINES (unified invoice-level)                          │
│  RESULTS    — phase outputs (PHASE1_BALANCE_RECON ... PHASE4_*)         │
│  HITL       — three approval queues                                     │
│  REGRESSION — validation targets (from MISvsMIS, Compilation)           │
│  TRAINING   — few-shot examples (from Entry Summary)                    │
└──────────────────────────────────────┬──────────────────────────────────┘
                                       ↓
┌─────────────────────────────────────────────────────────────────────────┐
│                         PROCESSING LAYER                                 │
│  SP_RAW_TO_STAGING       — adapters parse RAW → STAGING.IC_LINES        │
│  SP_RUN_PHASE1           — GL-balance reconciliation                    │
│  SP_RUN_PHASE2_TRADE     — 10-step deterministic Trade match            │
│  SP_RUN_PHASE2_NONTRADE  — 7-step deterministic Non-Trade match         │
│  SP_RUN_PHASE3           — Cortex embedding + similarity match          │
│  SP_RUN_PHASE4           — Cortex Complete classification + JE proposal │
│  SP_VALIDATE_REGRESSION  — compare pipeline output vs MISvsMIS targets  │
└──────────────────────────────────────┬──────────────────────────────────┘
                                       ↓
┌─────────────────────────────────────────────────────────────────────────┐
│                         STREAMLIT-IN-SNOWFLAKE APP                       │
│  app.py  — multi-page navigation                                        │
│  ├── pages/0_Dashboard.py                                               │
│  ├── pages/1_GL_Level_Matching.py                                       │
│  ├── pages/2_Invoice_Level_Matching.py                                  │
│  ├── pages/3_Review_Queue.py                                            │
│  ├── pages/4_Fuzzy_Approval_Queue.py                                    │
│  └── pages/5_Classification_Approval_Queue.py                           │
└─────────────────────────────────────────────────────────────────────────┘
```

**Cortex AI components:**
- `snowflake-arctic-embed-l-v2.0` — text embeddings (1024-dim) for Phase 3 fuzzy matching
- `claude-3-5-sonnet` — Cortex Complete for Phase 4 classification + JE proposals

**Orchestration:** Snowflake Tasks chain end-to-end for monthly close runs. Streamlit app provides on-demand re-runs and HITL workflow.

---

# Section 2 — Snowflake Database & Schema Setup

## 2.1 Database initialization

```sql
-- Database
CREATE DATABASE IF NOT EXISTS EVIDENT_INTERCO_RECON;
USE DATABASE EVIDENT_INTERCO_RECON;

-- Schemas
CREATE SCHEMA IF NOT EXISTS REF;          -- master/reference data
CREATE SCHEMA IF NOT EXISTS RAW;          -- raw Excel snapshots
CREATE SCHEMA IF NOT EXISTS STAGING;      -- IC_LINES unified
CREATE SCHEMA IF NOT EXISTS RESULTS;      -- pipeline phase outputs
CREATE SCHEMA IF NOT EXISTS HITL;         -- approval queues
CREATE SCHEMA IF NOT EXISTS REGRESSION;   -- validation targets
CREATE SCHEMA IF NOT EXISTS TRAINING;     -- few-shot examples

-- Warehouse (for AI workloads, larger; for batch ingest, smaller)
CREATE WAREHOUSE IF NOT EXISTS RECON_AI_WH
  WITH WAREHOUSE_SIZE = 'MEDIUM'
       AUTO_SUSPEND = 60
       AUTO_RESUME = TRUE;

CREATE WAREHOUSE IF NOT EXISTS RECON_BATCH_WH
  WITH WAREHOUSE_SIZE = 'SMALL'
       AUTO_SUSPEND = 60
       AUTO_RESUME = TRUE;

-- Roles
CREATE ROLE IF NOT EXISTS RECON_ENGINEER;       -- builds pipeline
CREATE ROLE IF NOT EXISTS RECON_CONTROLLER;     -- HITL operations
CREATE ROLE IF NOT EXISTS RECON_VIEWER;         -- read-only

GRANT USAGE ON DATABASE EVIDENT_INTERCO_RECON TO ROLE RECON_ENGINEER;
GRANT USAGE ON ALL SCHEMAS IN DATABASE EVIDENT_INTERCO_RECON TO ROLE RECON_ENGINEER;
GRANT USAGE ON WAREHOUSE RECON_AI_WH TO ROLE RECON_ENGINEER;
GRANT USAGE ON WAREHOUSE RECON_BATCH_WH TO ROLE RECON_ENGINEER;
-- (similar for CONTROLLER and VIEWER, with SELECT/INSERT scoped)
```

## 2.2 REF schema

```sql
USE SCHEMA EVIDENT_INTERCO_RECON.REF;

CREATE OR REPLACE TABLE REF_ENTITIES (
    ENTITY_SAP_CODE         VARCHAR(10) PRIMARY KEY,
    ENTITY_CODE             VARCHAR(10) UNIQUE,
    ENTITY_FULL_NAME        VARCHAR(200),
    REGION                  VARCHAR(20),
    SEGMENT                 VARCHAR(20),
    CURRENCY_FUNCTIONAL     VARCHAR(3),
    LOAD_DATE               TIMESTAMP_NTZ DEFAULT CURRENT_TIMESTAMP()
);

CREATE OR REPLACE TABLE REF_ENTITY_GL_ACCOUNTS (
    ENTITY_SAP_CODE         VARCHAR(10),
    ENTITY_CODE             VARCHAR(10),
    SAP_GL_ACCOUNT          VARCHAR(20),
    SAP_ACCOUNT_DESCRIPTION VARCHAR(200),
    ONESTREAM_ACCOUNT       VARCHAR(20),
    ONESTREAM_DESCRIPTION   VARCHAR(200),
    PLUG_ACCOUNT            VARCHAR(20),
    PLUG_DESCRIPTION        VARCHAR(200),
    CATEGORY                VARCHAR(50),
    REMARKS                 VARCHAR(500),
    LOAD_DATE               TIMESTAMP_NTZ DEFAULT CURRENT_TIMESTAMP(),
    LOAD_FILE_HASH          VARCHAR(64),
    PRIMARY KEY (ENTITY_CODE, SAP_GL_ACCOUNT)
);

CREATE OR REPLACE TABLE REF_FOREX_RATES (
    PERIOD                  DATE,
    FROM_CURRENCY           VARCHAR(3),
    TO_CURRENCY             VARCHAR(3),
    RATE                    NUMBER(20,8),
    RATE_TYPE               VARCHAR(20),
    LOAD_DATE               TIMESTAMP_NTZ DEFAULT CURRENT_TIMESTAMP(),
    PRIMARY KEY (PERIOD, FROM_CURRENCY, TO_CURRENCY, RATE_TYPE)
);

CREATE OR REPLACE TABLE REF_KNOWN_ISSUES (
    ISSUE_ID                VARCHAR(50) PRIMARY KEY,
    PAIR_ID                 VARCHAR(50),
    OS_ACCOUNT              VARCHAR(20),
    CATEGORY                VARCHAR(50),
    ROOT_CAUSE_CATEGORY     VARCHAR(50),
    PATTERN_DESCRIPTION     VARCHAR(1000),
    TYPICAL_RESOLUTION      VARCHAR(1000),
    OCCURRENCE_COUNT        NUMBER,
    LAST_OBSERVED_PERIOD    DATE,
    LOAD_DATE               TIMESTAMP_NTZ DEFAULT CURRENT_TIMESTAMP()
);

CREATE OR REPLACE TABLE REF_BILATERAL_PAIRS (
    PAIR_ID                 VARCHAR(50) PRIMARY KEY,
    ENTITY_A_CODE           VARCHAR(10),
    ENTITY_B_CODE           VARCHAR(10),
    SEGMENT                 VARCHAR(20),
    ACTIVE                  BOOLEAN DEFAULT TRUE,
    EXPECTED_VOLUMES_NOTE   VARCHAR(500)
);
```

## 2.3 RAW schema

```sql
USE SCHEMA EVIDENT_INTERCO_RECON.RAW;

-- Stage: where raw Excel files land
CREATE OR REPLACE STAGE RECON_FILE_STAGE
  ENCRYPTION = (TYPE = 'SNOWFLAKE_FULL');

CREATE OR REPLACE TABLE RAW_FILE_REGISTRY (
    FILE_ID                 VARCHAR(50) PRIMARY KEY,         -- generated UUID
    FILE_NAME               VARCHAR(500),
    FILE_HASH               VARCHAR(64),                     -- SHA-256 of file content
    FILE_TYPE               VARCHAR(20),                     -- "INTERCO_TEMPLATE" | "BILATERAL_PAIR" | "PROCESS_SPEC" | "CONSOLIDATED_WORKBOOK"
    SOURCE_ENTITY           VARCHAR(10),                     -- entity that contributed it
    SOURCE_HUB              VARCHAR(50),                     -- "EJP" | "EU" | "ROOT"
    PERIOD                  DATE,
    UPLOADED_AT             TIMESTAMP_NTZ DEFAULT CURRENT_TIMESTAMP(),
    UPLOADED_BY             VARCHAR(100),
    PROCESSED_AT            TIMESTAMP_NTZ,
    PROCESS_STATUS          VARCHAR(20)                      -- "PENDING" | "IN_PROGRESS" | "DONE" | "ERROR"
);

CREATE OR REPLACE TABLE RAW_TAB_REGISTRY (
    TAB_ID                  VARCHAR(50) PRIMARY KEY,
    FILE_ID                 VARCHAR(50),
    TAB_NAME                VARCHAR(200),
    TAB_TYPE                VARCHAR(50),                     -- "BALANCE_SHEET" | "AR_DETAIL" | "AP_DETAIL" | "MASTER_TRADE" | etc.
    ADAPTER_NAME            VARCHAR(50),                     -- which adapter handles it
    ROW_COUNT               NUMBER,
    EXTRACT_STATUS          VARCHAR(20),
    FOREIGN KEY (FILE_ID) REFERENCES RAW_FILE_REGISTRY(FILE_ID)
);

-- Raw cell-level snapshot (only used for adapter dev/debugging; final pipeline uses STAGING.IC_LINES)
CREATE OR REPLACE TABLE RAW_CELLS (
    TAB_ID                  VARCHAR(50),
    ROW_NUM                 NUMBER,
    COL_NUM                 NUMBER,
    CELL_VALUE_TEXT         VARCHAR,
    CELL_VALUE_NUMBER       NUMBER(20,4),
    CELL_VALUE_DATE         DATE,
    CELL_VALUE_TYPE         VARCHAR(10),
    LOAD_DATE               TIMESTAMP_NTZ DEFAULT CURRENT_TIMESTAMP()
);
```

## 2.4 STAGING schema

```sql
USE SCHEMA EVIDENT_INTERCO_RECON.STAGING;

CREATE OR REPLACE TABLE IC_LINES (
    LINE_ID                 VARCHAR(50) PRIMARY KEY,
    SOURCE_FILE             VARCHAR(500),
    SOURCE_TAB              VARCHAR(200),
    SOURCE_ROW              NUMBER,
    LOAD_DATE               TIMESTAMP_NTZ DEFAULT CURRENT_TIMESTAMP(),
    PERIOD                  DATE,

    -- Bilateral pair
    ENTITY_CODE             VARCHAR(10),
    COUNTERPARTY_CODE       VARCHAR(10),
    PAIR_ID                 VARCHAR(50),
    SEGMENT                 VARCHAR(20),

    -- GL classification
    SAP_GL_ACCOUNT          VARCHAR(20),
    SAP_ACCOUNT_DESCRIPTION VARCHAR(200),
    ONESTREAM_ACCOUNT       VARCHAR(20),
    CATEGORY                VARCHAR(50),
    NATURE                  VARCHAR(50),
    AR_OR_AP                VARCHAR(2),
    BS_OR_PL                VARCHAR(2),
    ASSET_OR_LIAB           VARCHAR(10),

    -- Document detail
    DOC_NUMBER              VARCHAR(100),
    DOC_DATE                DATE,
    POSTING_MONTH           VARCHAR(7),
    DOC_CURRENCY            VARCHAR(3),
    DOC_AMOUNT              NUMBER(20,2),
    LC_CURRENCY             VARCHAR(3),
    LC_AMOUNT               NUMBER(20,2),
    REPORTING_AMOUNT_JPY    NUMBER(20,2),
    FOREX_RATE              NUMBER(20,8),

    -- Free text
    FREE_TEXT               VARCHAR(1000),
    PROFIT_CENTER           VARCHAR(20),
    BUSINESS_UNIT           VARCHAR(20),

    -- Pipeline state
    PHASE1_STATUS           VARCHAR(20),
    PHASE2_MATCH_ID         VARCHAR(50),
    PHASE3_MATCH_ID         VARCHAR(50),
    PHASE4_CLASSIFICATION_ID VARCHAR(50),
    LINE_STATUS             VARCHAR(20),

    -- Cortex embedding (populated lazily during Phase 3)
    EMBEDDING_TEXT          VARCHAR(2000),
    EMBEDDING_VECTOR        VECTOR(FLOAT, 1024)
);

-- Indexes for common JOIN paths
CREATE OR REPLACE TABLE IC_LINES_PAIR_IDX AS SELECT * FROM IC_LINES;  -- placeholder; in practice use clustering
ALTER TABLE IC_LINES CLUSTER BY (PERIOD, PAIR_ID, ONESTREAM_ACCOUNT);
```

## 2.5 RESULTS schema

```sql
USE SCHEMA EVIDENT_INTERCO_RECON.RESULTS;

CREATE OR REPLACE TABLE PHASE1_BALANCE_RECON (
    RECON_ID                VARCHAR(50) PRIMARY KEY,
    PERIOD                  DATE,
    PAIR_ID                 VARCHAR(50),
    OS_ACCOUNT              VARCHAR(20),
    OS_DESCRIPTION          VARCHAR(200),
    CATEGORY                VARCHAR(50),
    DOC_CURRENCY            VARCHAR(3),
    SIDE_A_ENTITY           VARCHAR(10),
    SIDE_A_BALANCE          NUMBER(20,2),
    SIDE_A_LINE_COUNT       NUMBER,
    SIDE_B_ENTITY           VARCHAR(10),
    SIDE_B_BALANCE          NUMBER(20,2),
    SIDE_B_LINE_COUNT       NUMBER,
    VARIANCE                NUMBER(20,2),
    VARIANCE_PCT            NUMBER(8,6),
    VARIANCE_JPY            NUMBER(20,2),
    RECON_STATUS            VARCHAR(20),                    -- "RECONCILED" | "VARIANCE"
    PHASE1_CONFIDENCE       NUMBER(5,4),
    COMPUTED_AT             TIMESTAMP_NTZ DEFAULT CURRENT_TIMESTAMP()
);

CREATE OR REPLACE TABLE PHASE2_LINE_MATCHES (
    MATCH_ID                VARCHAR(50) PRIMARY KEY,
    PERIOD                  DATE,
    PAIR_ID                 VARCHAR(50),
    OS_ACCOUNT              VARCHAR(20),
    LINE_A_ID               VARCHAR(50),
    LINE_B_ID               VARCHAR(50),
    -- Confidence components
    ICP_MATCH               NUMBER(1),
    INVOICE_MATCH           NUMBER(1),
    DOC_CURR_MATCH          NUMBER(1),
    AMOUNT_MATCH            NUMBER(1),
    DOC_DATE_MATCH          NUMBER(1),
    POSTING_MONTH_MATCH     NUMBER(1),
    -- Composite
    CONFIDENCE              NUMBER(5,4),
    CRITERIA_FAILED         VARCHAR(500),
    MATCH_STATUS            VARCHAR(20),                    -- "PERFECT" | "REVIEW" | "PHASE3" | "RESIDUAL"
    MATCH_TYPE              VARCHAR(20),                    -- "TRADE" | "NON_TRADE"
    COMPUTED_AT             TIMESTAMP_NTZ DEFAULT CURRENT_TIMESTAMP()
);

CREATE OR REPLACE TABLE PHASE3_FUZZY_MATCHES (
    FUZZY_MATCH_ID          VARCHAR(50) PRIMARY KEY,
    PERIOD                  DATE,
    PAIR_ID                 VARCHAR(50),
    LINE_A_ID               VARCHAR(50),
    LINE_B_ID               VARCHAR(50),
    COSINE_SIMILARITY       NUMBER(5,4),
    AMOUNT_PROXIMITY        NUMBER(5,4),
    DATE_PROXIMITY          NUMBER(5,4),
    AI_CONFIDENCE           NUMBER(5,4),
    AI_REASONING            VARCHAR(2000),
    EMBEDDING_MODEL         VARCHAR(50) DEFAULT 'snowflake-arctic-embed-l-v2.0',
    COMPUTED_AT             TIMESTAMP_NTZ DEFAULT CURRENT_TIMESTAMP()
);

CREATE OR REPLACE TABLE PHASE4_AI_CLASSIFICATIONS (
    CLASSIFICATION_ID       VARCHAR(50) PRIMARY KEY,
    PERIOD                  DATE,
    PAIR_ID                 VARCHAR(50),
    OS_ACCOUNT              VARCHAR(20),
    CATEGORY                VARCHAR(50),
    DOC_CURRENCY            VARCHAR(3),
    VARIANCE_AMOUNT         NUMBER(20,2),
    VARIANCE_AMOUNT_JPY     NUMBER(20,2),
    UNMATCHED_LINE_IDS_A    ARRAY,
    UNMATCHED_LINE_IDS_B    ARRAY,
    ROOT_CAUSE_CATEGORY     VARCHAR(50),
    AI_CONFIDENCE           NUMBER(5,4),
    AI_REASONING            VARCHAR(5000),
    SUGGESTED_ACTION        VARCHAR(20),
    PROPOSED_JOURNAL        VARIANT,
    SIMILAR_ISSUE_IDS       ARRAY,
    LLM_MODEL               VARCHAR(100) DEFAULT 'claude-3-5-sonnet',
    LLM_PROMPT_VERSION      VARCHAR(20),
    COMPUTED_AT             TIMESTAMP_NTZ DEFAULT CURRENT_TIMESTAMP()
);

-- Convenience views for the Streamlit app
CREATE OR REPLACE VIEW V_PHASE1_OS_BALANCE_RECON AS
SELECT p.*,
       rt.JPY_RESIDUAL AS REGRESSION_TARGET_JPY,
       CASE WHEN ABS(p.VARIANCE_JPY) <= ABS(rt.JPY_RESIDUAL) * 1.05
              AND ABS(p.VARIANCE_JPY) >= ABS(rt.JPY_RESIDUAL) * 0.95
            THEN 'WITHIN_TARGET'
            ELSE 'OUT_OF_TARGET' END AS REGRESSION_STATUS
FROM PHASE1_BALANCE_RECON p
LEFT JOIN REGRESSION.PAIR_RESIDUAL_TARGETS rt
       ON p.PAIR_ID = rt.PAIR_ID AND p.PERIOD = rt.PERIOD;

CREATE OR REPLACE VIEW V_PHASE2_LINE_MATCHES_DETAIL AS
SELECT m.MATCH_ID, m.PAIR_ID, m.PERIOD, m.OS_ACCOUNT,
       a.ENTITY_CODE AS ENTITY_A, a.DOC_NUMBER AS DOC_A, a.DOC_AMOUNT AS AMT_A, a.DOC_DATE AS DT_A,
       b.ENTITY_CODE AS ENTITY_B, b.DOC_NUMBER AS DOC_B, b.DOC_AMOUNT AS AMT_B, b.DOC_DATE AS DT_B,
       m.CONFIDENCE, m.CRITERIA_FAILED, m.MATCH_STATUS, m.MATCH_TYPE
FROM PHASE2_LINE_MATCHES m
JOIN STAGING.IC_LINES a ON m.LINE_A_ID = a.LINE_ID
LEFT JOIN STAGING.IC_LINES b ON m.LINE_B_ID = b.LINE_ID;
```

## 2.6 HITL schema

```sql
USE SCHEMA EVIDENT_INTERCO_RECON.HITL;

CREATE OR REPLACE TABLE REVIEW_QUEUE (
    QUEUE_ID                VARCHAR(50) PRIMARY KEY,
    PAIR_ID                 VARCHAR(50),
    PERIOD                  DATE,
    LINE_A_ID               VARCHAR(50),
    LINE_B_ID               VARCHAR(50),
    PHASE                   VARCHAR(10),
    CONFIDENCE              NUMBER(5,4),
    FAILED_CRITERIA         VARCHAR(500),
    AI_REASONING            VARCHAR(2000),
    QUEUE_STATUS            VARCHAR(20) DEFAULT 'PENDING',
    QUEUED_AT               TIMESTAMP_NTZ DEFAULT CURRENT_TIMESTAMP(),
    REVIEWER                VARCHAR(100),
    REVIEWED_AT             TIMESTAMP_NTZ,
    REVIEWER_DECISION       VARCHAR(20),
    REVIEWER_NOTES          VARCHAR(1000)
);

CREATE OR REPLACE TABLE FUZZY_APPROVAL_QUEUE (
    QUEUE_ID                VARCHAR(50) PRIMARY KEY,
    PAIR_ID                 VARCHAR(50),
    PERIOD                  DATE,
    LINE_A_ID               VARCHAR(50),
    LINE_B_ID               VARCHAR(50),
    COSINE_SIMILARITY       NUMBER(5,4),
    AMOUNT_PROXIMITY        NUMBER(5,4),
    DATE_PROXIMITY          NUMBER(5,4),
    AI_CONFIDENCE           NUMBER(5,4),
    AI_REASONING            VARCHAR(2000),
    EMBEDDING_MODEL         VARCHAR(50),
    QUEUE_STATUS            VARCHAR(20) DEFAULT 'PENDING',
    QUEUED_AT               TIMESTAMP_NTZ DEFAULT CURRENT_TIMESTAMP(),
    REVIEWER                VARCHAR(100),
    REVIEWED_AT             TIMESTAMP_NTZ,
    REVIEWER_DECISION       VARCHAR(20),
    REVIEWER_NOTES          VARCHAR(1000)
);

CREATE OR REPLACE TABLE CLASSIFICATION_APPROVAL_QUEUE (
    QUEUE_ID                VARCHAR(50) PRIMARY KEY,
    PAIR_ID                 VARCHAR(50),
    PERIOD                  DATE,
    OS_ACCOUNT              VARCHAR(20),
    CATEGORY                VARCHAR(50),
    DOC_CURRENCY            VARCHAR(3),
    VARIANCE_AMOUNT         NUMBER(20,2),
    VARIANCE_AMOUNT_JPY     NUMBER(20,2),
    UNMATCHED_LINE_IDS_A    ARRAY,
    UNMATCHED_LINE_IDS_B    ARRAY,
    ROOT_CAUSE_CATEGORY     VARCHAR(50),
    AI_CONFIDENCE           NUMBER(5,4),
    AI_REASONING            VARCHAR(5000),
    SUGGESTED_ACTION        VARCHAR(20),
    PROPOSED_JOURNAL        VARIANT,
    SIMILAR_ISSUE_IDS       ARRAY,
    LLM_MODEL               VARCHAR(100),
    LLM_PROMPT_VERSION      VARCHAR(20),
    QUEUE_STATUS            VARCHAR(20) DEFAULT 'PENDING',
    QUEUED_AT               TIMESTAMP_NTZ DEFAULT CURRENT_TIMESTAMP(),
    REVIEWER                VARCHAR(100),
    REVIEWED_AT             TIMESTAMP_NTZ,
    REVIEWER_DECISION       VARCHAR(20),
    REVIEWER_EDITED_JOURNAL VARIANT,
    REVIEWER_NOTES          VARCHAR(2000),
    EXPORTED_TO_ERP         BOOLEAN DEFAULT FALSE,
    ERP_REFERENCE           VARCHAR(100)
);

CREATE OR REPLACE TABLE ESCALATION_QUEUE (
    QUEUE_ID                VARCHAR(50) PRIMARY KEY,
    PAIR_ID                 VARCHAR(50),
    PERIOD                  DATE,
    SOURCE_QUEUE            VARCHAR(20),                    -- "REVIEW" | "FUZZY" | "CLASSIFICATION"
    SOURCE_QUEUE_ID         VARCHAR(50),
    ESCALATION_REASON       VARCHAR(1000),
    ESCALATED_BY            VARCHAR(100),
    ESCALATED_AT            TIMESTAMP_NTZ DEFAULT CURRENT_TIMESTAMP(),
    ESCALATION_STATUS       VARCHAR(20) DEFAULT 'PENDING',
    RESOLVED_BY             VARCHAR(100),
    RESOLVED_AT             TIMESTAMP_NTZ,
    RESOLUTION              VARCHAR(2000)
);
```

## 2.7 REGRESSION schema

```sql
USE SCHEMA EVIDENT_INTERCO_RECON.REGRESSION;

CREATE OR REPLACE TABLE PAIR_RESIDUAL_TARGETS (
    PAIR_ID                 VARCHAR(50),
    PERIOD                  DATE,
    JPY_GROSS_VARIANCE      NUMBER(20,2),
    JPY_ADJUSTMENTS         NUMBER(20,2),
    JPY_RESIDUAL            NUMBER(20,2),
    USD_GROSS_VARIANCE      NUMBER(20,2),
    USD_ADJUSTMENTS         NUMBER(20,2),
    USD_RESIDUAL            NUMBER(20,2),
    REMARKS                 VARCHAR(500),
    LOAD_DATE               TIMESTAMP_NTZ DEFAULT CURRENT_TIMESTAMP(),
    PRIMARY KEY (PAIR_ID, PERIOD)
);

CREATE OR REPLACE TABLE COMPILATION_TARGETS (
    PAIR_ID                 VARCHAR(50),
    PERIOD                  DATE,
    OS_ACCOUNT              VARCHAR(20),
    CATEGORY                VARCHAR(50),
    DOC_CURRENCY            VARCHAR(3),
    SIDE_A_BALANCE          NUMBER(20,2),
    SIDE_B_BALANCE          NUMBER(20,2),
    EXPECTED_VARIANCE       NUMBER(20,2),
    LOAD_DATE               TIMESTAMP_NTZ DEFAULT CURRENT_TIMESTAMP(),
    PRIMARY KEY (PAIR_ID, PERIOD, OS_ACCOUNT, DOC_CURRENCY)
);

CREATE OR REPLACE TABLE REGRESSION_RUNS (
    RUN_ID                  VARCHAR(50) PRIMARY KEY,
    PERIOD                  DATE,
    RUN_AT                  TIMESTAMP_NTZ DEFAULT CURRENT_TIMESTAMP(),
    PIPELINE_VERSION        VARCHAR(20),
    PAIRS_TESTED            NUMBER,
    PAIRS_WITHIN_TARGET     NUMBER,
    PAIRS_OUT_OF_TARGET     NUMBER,
    DETAIL                  VARIANT
);
```

## 2.8 TRAINING schema

```sql
USE SCHEMA EVIDENT_INTERCO_RECON.TRAINING;

CREATE OR REPLACE TABLE PHASE4_FEW_SHOT_EXAMPLES (
    EXAMPLE_ID              VARCHAR(50) PRIMARY KEY,
    PAIR_ID                 VARCHAR(50),
    PERIOD                  DATE,
    VARIANCE_DESCRIPTION    VARCHAR(500),
    ROOT_CAUSE_CATEGORY     VARCHAR(50),
    PROPOSED_JOURNAL_JSON   VARIANT,
    REMARK                  VARCHAR(500),
    EMBEDDING_TEXT          VARCHAR(2000),
    EMBEDDING_VECTOR        VECTOR(FLOAT, 1024),
    LOAD_DATE               TIMESTAMP_NTZ DEFAULT CURRENT_TIMESTAMP()
);
```

---

# Section 3 — Stored Procedures (Python on Snowflake)

The pipeline is implemented as five Python stored procedures plus a Master orchestrator. All run inside Snowflake (no external compute).

## 3.1 SP_RAW_TO_STAGING — adapter dispatch

```sql
CREATE OR REPLACE PROCEDURE STAGING.SP_RAW_TO_STAGING(P_FILE_ID VARCHAR)
RETURNS VARIANT
LANGUAGE PYTHON
RUNTIME_VERSION = '3.10'
PACKAGES = ('snowflake-snowpark-python', 'openpyxl', 'pandas')
HANDLER = 'run'
AS
$$
def run(session, p_file_id):
    """
    Dispatch a file to the appropriate adapter based on its FILE_TYPE
    and SOURCE_ENTITY, parse it, and insert rows into STAGING.IC_LINES.
    """
    # Get file metadata
    meta = session.sql(f"""
        SELECT FILE_NAME, FILE_TYPE, SOURCE_ENTITY, PERIOD
        FROM RAW.RAW_FILE_REGISTRY WHERE FILE_ID = '{p_file_id}'
    """).collect()[0]
    
    file_name, file_type, source_entity, period = meta
    
    # Read file from stage
    file_content = session.file.get_stream(f'@RAW.RECON_FILE_STAGE/{file_name}')
    
    # Adapter dispatch table
    adapter_map = {
        ('BILATERAL_PAIR', 'EJP'): adapt_ejp_bilateral,
        ('BILATERAL_PAIR', 'ECN'): adapt_ecn_bilateral,
        ('BILATERAL_PAIR', 'EAS'): adapt_eas_bilateral,
        ('BILATERAL_PAIR', 'EKR'): adapt_ekr_bilateral,
        ('BILATERAL_PAIR', 'EEU'): adapt_eeu_bilateral,
        ('BILATERAL_PAIR', 'ETCE'): adapt_etce_bilateral,
        # ... etc per entity
        ('INTERCO_TEMPLATE', 'EJP'): adapt_ejp_template,
        # ... etc
    }
    
    adapter = adapter_map.get((file_type, source_entity))
    if not adapter:
        return {'status': 'ERROR', 'reason': f'No adapter for {file_type}/{source_entity}'}
    
    rows = adapter(file_content, period)
    
    # Bulk insert
    if rows:
        df = session.create_dataframe(rows)
        df.write.mode('append').save_as_table('STAGING.IC_LINES')
    
    # Update registry
    session.sql(f"""
        UPDATE RAW.RAW_FILE_REGISTRY
        SET PROCESSED_AT = CURRENT_TIMESTAMP(), PROCESS_STATUS = 'DONE'
        WHERE FILE_ID = '{p_file_id}'
    """).collect()
    
    return {'status': 'DONE', 'file_id': p_file_id, 'rows_inserted': len(rows)}


def adapt_ejp_bilateral(file_bytes, period):
    """Parse EJP bilateral file: extract EJP AR-T(MIS), AR-O(MIS), AP-T(MIS), AP-O(MIS) tabs."""
    import openpyxl
    import io
    wb = openpyxl.load_workbook(io.BytesIO(file_bytes), data_only=True)
    rows = []
    
    for tab_name, ar_or_ap, nature in [
        ('EJP AR-T(MIS)', 'AR', 'Trade'),
        ('EJP AR-O(MIS)', 'AR', 'Non-trade'),
        ('EJP AP-T(MIS)', 'AP', 'Trade'),
        ('EJP AP-O(MIS)', 'AP', 'Non-trade'),
    ]:
        if tab_name not in wb.sheetnames:
            continue
        ws = wb[tab_name]
        # EJP standard 12-col layout: A=sort_key, B=ICP, C=GL, D=desc, E=DocNo, F=DocDate,
        #                              G=Curr, H=DocAmt, I=LCAmt, J=PostMonth, K=PC, L=Remark
        for row_idx, row in enumerate(ws.iter_rows(min_row=2, values_only=True), start=2):
            if not row or row[0] is None:
                continue
            line_id = f"EJP-{tab_name}-{period}-{row_idx}"
            rows.append({
                'LINE_ID': line_id,
                'SOURCE_TAB': tab_name,
                'SOURCE_ROW': row_idx,
                'PERIOD': period,
                'ENTITY_CODE': 'EJP',
                'COUNTERPARTY_CODE': str(row[1]) if row[1] else None,
                'PAIR_ID': make_pair_id('EJP', str(row[1]) if row[1] else None),
                'SEGMENT': 'MIS',
                'SAP_GL_ACCOUNT': str(row[2]) if row[2] else None,
                'SAP_ACCOUNT_DESCRIPTION': str(row[3]) if row[3] else None,
                'NATURE': nature,
                'AR_OR_AP': ar_or_ap,
                'DOC_NUMBER': str(row[4]) if row[4] else None,
                'DOC_DATE': row[5],
                'POSTING_MONTH': str(row[9]) if len(row) > 9 and row[9] else None,
                'DOC_CURRENCY': str(row[6]) if row[6] else 'JPY',
                'DOC_AMOUNT': float(row[7]) if row[7] is not None else 0,
                'LC_CURRENCY': 'JPY',
                'LC_AMOUNT': float(row[8]) if row[8] is not None else 0,
                'PROFIT_CENTER': str(row[10]) if len(row) > 10 and row[10] else None,
                'FREE_TEXT': str(row[11]) if len(row) > 11 and row[11] else None,
            })
    
    return rows


def adapt_ecn_bilateral(file_bytes, period):
    """Parse ECN-side bilateral file: extract Master (Trade), Master (Non-Trade) tabs."""
    # ECN's 'Master (Trade)' tab is the source of ECN's own AR/AP detail
    # 18-col layout — see prior session notes
    # Implementation analogous to adapt_ejp_bilateral
    ...

# More adapters: adapt_eas_bilateral, adapt_ekr_bilateral, adapt_eeu_bilateral, etc.

def make_pair_id(entity_a, entity_b):
    """Canonicalize pair ID: alphabetical."""
    if not entity_a or not entity_b:
        return None
    return '-'.join(sorted([entity_a, entity_b]))
$$;
```

## 3.2 SP_RUN_PHASE1 — GL Balance Reconciliation (pure SQL)

```sql
CREATE OR REPLACE PROCEDURE RESULTS.SP_RUN_PHASE1(P_PERIOD DATE)
RETURNS VARIANT
LANGUAGE SQL
AS
$$
DECLARE
    v_count NUMBER;
BEGIN
    -- Clear prior runs for this period
    DELETE FROM RESULTS.PHASE1_BALANCE_RECON WHERE PERIOD = :P_PERIOD;
    
    -- Compute Phase 1 balances per pair × OS account × currency
    INSERT INTO RESULTS.PHASE1_BALANCE_RECON
        (RECON_ID, PERIOD, PAIR_ID, OS_ACCOUNT, OS_DESCRIPTION, CATEGORY, DOC_CURRENCY,
         SIDE_A_ENTITY, SIDE_A_BALANCE, SIDE_A_LINE_COUNT,
         SIDE_B_ENTITY, SIDE_B_BALANCE, SIDE_B_LINE_COUNT,
         VARIANCE, VARIANCE_PCT, VARIANCE_JPY, RECON_STATUS, PHASE1_CONFIDENCE)
    WITH enriched AS (
        SELECT l.*,
               g.ONESTREAM_ACCOUNT,
               g.ONESTREAM_DESCRIPTION,
               g.CATEGORY AS GL_CATEGORY
        FROM STAGING.IC_LINES l
        LEFT JOIN REF.REF_ENTITY_GL_ACCOUNTS g
               ON l.ENTITY_CODE = g.ENTITY_CODE
              AND l.SAP_GL_ACCOUNT = g.SAP_GL_ACCOUNT
        WHERE l.PERIOD = :P_PERIOD
    ),
    aggregated AS (
        SELECT
            PAIR_ID,
            ONESTREAM_ACCOUNT AS OS_ACCOUNT,
            ANY_VALUE(ONESTREAM_DESCRIPTION) AS OS_DESCRIPTION,
            GL_CATEGORY AS CATEGORY,
            DOC_CURRENCY,
            -- Determine canonical "Side A" alphabetically
            MIN(ENTITY_CODE) AS SIDE_A_ENTITY,
            SUM(CASE WHEN ENTITY_CODE = MIN(ENTITY_CODE) OVER (PARTITION BY PAIR_ID, ONESTREAM_ACCOUNT, DOC_CURRENCY)
                     THEN DOC_AMOUNT ELSE 0 END) AS SIDE_A_BALANCE,
            COUNT(CASE WHEN ENTITY_CODE = MIN(ENTITY_CODE) OVER (PARTITION BY PAIR_ID, ONESTREAM_ACCOUNT, DOC_CURRENCY)
                       THEN 1 END) AS SIDE_A_LINE_COUNT,
            MAX(ENTITY_CODE) AS SIDE_B_ENTITY,
            SUM(CASE WHEN ENTITY_CODE = MAX(ENTITY_CODE) OVER (PARTITION BY PAIR_ID, ONESTREAM_ACCOUNT, DOC_CURRENCY)
                     THEN DOC_AMOUNT ELSE 0 END) AS SIDE_B_BALANCE,
            COUNT(CASE WHEN ENTITY_CODE = MAX(ENTITY_CODE) OVER (PARTITION BY PAIR_ID, ONESTREAM_ACCOUNT, DOC_CURRENCY)
                       THEN 1 END) AS SIDE_B_LINE_COUNT,
            SUM(REPORTING_AMOUNT_JPY) AS NET_JPY
        FROM enriched
        WHERE PAIR_ID IS NOT NULL
          AND ONESTREAM_ACCOUNT IS NOT NULL
        GROUP BY PAIR_ID, ONESTREAM_ACCOUNT, GL_CATEGORY, DOC_CURRENCY
    )
    SELECT
        UUID_STRING() AS RECON_ID,
        :P_PERIOD AS PERIOD,
        PAIR_ID,
        OS_ACCOUNT,
        OS_DESCRIPTION,
        CATEGORY,
        DOC_CURRENCY,
        SIDE_A_ENTITY,
        SIDE_A_BALANCE,
        SIDE_A_LINE_COUNT,
        SIDE_B_ENTITY,
        SIDE_B_BALANCE,
        SIDE_B_LINE_COUNT,
        SIDE_A_BALANCE + SIDE_B_BALANCE AS VARIANCE,
        ABS(SIDE_A_BALANCE + SIDE_B_BALANCE) / GREATEST(ABS(SIDE_A_BALANCE), ABS(SIDE_B_BALANCE), 1) AS VARIANCE_PCT,
        NET_JPY AS VARIANCE_JPY,
        CASE
            WHEN ABS(SIDE_A_BALANCE + SIDE_B_BALANCE) < 1.00 THEN 'RECONCILED'
            WHEN ABS(SIDE_A_BALANCE + SIDE_B_BALANCE) / GREATEST(ABS(SIDE_A_BALANCE), ABS(SIDE_B_BALANCE), 1) < 0.001 THEN 'RECONCILED'
            ELSE 'VARIANCE'
        END AS RECON_STATUS,
        CASE
            WHEN ABS(SIDE_A_BALANCE + SIDE_B_BALANCE) < 1.00 THEN 1.0
            ELSE 0.0
        END AS PHASE1_CONFIDENCE
    FROM aggregated;
    
    SELECT COUNT(*) INTO :v_count FROM RESULTS.PHASE1_BALANCE_RECON WHERE PERIOD = :P_PERIOD;
    
    RETURN OBJECT_CONSTRUCT('rows_inserted', :v_count, 'period', :P_PERIOD);
END;
$$;
```

## 3.3 SP_RUN_PHASE2_TRADE — 10-step deterministic Trade matching

```sql
CREATE OR REPLACE PROCEDURE RESULTS.SP_RUN_PHASE2_TRADE(P_PERIOD DATE, P_PAIR_ID VARCHAR, P_OS_ACCOUNT VARCHAR)
RETURNS VARIANT
LANGUAGE SQL
AS
$$
BEGIN
    -- Insert deterministic line matches for one (pair, OS account) combination
    -- with confidence scoring per the formula
    INSERT INTO RESULTS.PHASE2_LINE_MATCHES
        (MATCH_ID, PERIOD, PAIR_ID, OS_ACCOUNT,
         LINE_A_ID, LINE_B_ID,
         ICP_MATCH, INVOICE_MATCH, DOC_CURR_MATCH, AMOUNT_MATCH, DOC_DATE_MATCH, POSTING_MONTH_MATCH,
         CONFIDENCE, CRITERIA_FAILED, MATCH_STATUS, MATCH_TYPE)
    WITH side_a AS (
        SELECT *
        FROM STAGING.IC_LINES
        WHERE PERIOD = :P_PERIOD AND PAIR_ID = :P_PAIR_ID
          AND ONESTREAM_ACCOUNT = :P_OS_ACCOUNT
          AND CATEGORY = 'Trade'
          AND ENTITY_CODE = (SELECT MIN(ENTITY_CODE) FROM STAGING.IC_LINES
                              WHERE PAIR_ID = :P_PAIR_ID AND PERIOD = :P_PERIOD)
    ),
    side_b AS (
        SELECT *
        FROM STAGING.IC_LINES
        WHERE PERIOD = :P_PERIOD AND PAIR_ID = :P_PAIR_ID
          AND ONESTREAM_ACCOUNT = :P_OS_ACCOUNT
          AND CATEGORY = 'Trade'
          AND ENTITY_CODE = (SELECT MAX(ENTITY_CODE) FROM STAGING.IC_LINES
                              WHERE PAIR_ID = :P_PAIR_ID AND PERIOD = :P_PERIOD)
    ),
    candidates AS (
        SELECT
            a.LINE_ID AS LINE_A_ID,
            b.LINE_ID AS LINE_B_ID,
            -- Component scores
            CASE WHEN a.COUNTERPARTY_CODE = b.ENTITY_CODE
                  AND b.COUNTERPARTY_CODE = a.ENTITY_CODE THEN 1 ELSE 0 END AS ICP_MATCH,
            CASE WHEN a.DOC_NUMBER = b.DOC_NUMBER THEN 1 ELSE 0 END AS INVOICE_MATCH,
            CASE WHEN a.DOC_CURRENCY = b.DOC_CURRENCY THEN 1 ELSE 0 END AS DOC_CURR_MATCH,
            CASE WHEN ABS(ABS(a.DOC_AMOUNT) - ABS(b.DOC_AMOUNT)) < 0.01 THEN 1 ELSE 0 END AS AMOUNT_MATCH,
            CASE WHEN ABS(DATEDIFF('day', a.DOC_DATE, b.DOC_DATE)) <= 5 THEN 1 ELSE 0 END AS DOC_DATE_MATCH,
            CASE WHEN a.POSTING_MONTH = b.POSTING_MONTH THEN 1 ELSE 0 END AS POSTING_MONTH_MATCH
        FROM side_a a
        JOIN side_b b
          ON ( a.DOC_NUMBER = b.DOC_NUMBER                                          -- Step 1: invoice
            OR ( a.DOC_CURRENCY = b.DOC_CURRENCY                                    -- Step 2: amt+curr+date
                 AND ABS(ABS(a.DOC_AMOUNT) - ABS(b.DOC_AMOUNT)) < 0.01
                 AND ABS(DATEDIFF('day', a.DOC_DATE, b.DOC_DATE)) <= 30 ))
    ),
    scored AS (
        SELECT
            LINE_A_ID, LINE_B_ID,
            ICP_MATCH, INVOICE_MATCH, DOC_CURR_MATCH, AMOUNT_MATCH, DOC_DATE_MATCH, POSTING_MONTH_MATCH,
            (0.30*ICP_MATCH + 0.20*INVOICE_MATCH + 0.20*DOC_CURR_MATCH
            + 0.20*AMOUNT_MATCH + 0.05*DOC_DATE_MATCH + 0.05*POSTING_MONTH_MATCH) AS CONFIDENCE,
            ROW_NUMBER() OVER (PARTITION BY LINE_A_ID
                                ORDER BY (0.30*ICP_MATCH + 0.20*INVOICE_MATCH + 0.20*DOC_CURR_MATCH
                                        + 0.20*AMOUNT_MATCH + 0.05*DOC_DATE_MATCH + 0.05*POSTING_MONTH_MATCH) DESC) AS RN
        FROM candidates
    ),
    best_match AS (
        SELECT * FROM scored WHERE RN = 1
    )
    SELECT
        UUID_STRING() AS MATCH_ID,
        :P_PERIOD,
        :P_PAIR_ID,
        :P_OS_ACCOUNT,
        LINE_A_ID,
        LINE_B_ID,
        ICP_MATCH, INVOICE_MATCH, DOC_CURR_MATCH, AMOUNT_MATCH, DOC_DATE_MATCH, POSTING_MONTH_MATCH,
        CONFIDENCE,
        ARRAY_TO_STRING(ARRAY_COMPACT(ARRAY_CONSTRUCT(
            CASE WHEN ICP_MATCH = 0 THEN 'ICP_match' END,
            CASE WHEN INVOICE_MATCH = 0 THEN 'invoice_match' END,
            CASE WHEN DOC_CURR_MATCH = 0 THEN 'doc_curr_match' END,
            CASE WHEN AMOUNT_MATCH = 0 THEN 'amount_match' END,
            CASE WHEN DOC_DATE_MATCH = 0 THEN 'doc_date_match' END,
            CASE WHEN POSTING_MONTH_MATCH = 0 THEN 'posting_month_match' END
        )), ', ') AS CRITERIA_FAILED,
        CASE
            WHEN CONFIDENCE = 1.0 THEN 'PERFECT'
            WHEN CONFIDENCE >= 0.5 THEN 'REVIEW'
            ELSE 'PHASE3'
        END AS MATCH_STATUS,
        'TRADE' AS MATCH_TYPE
    FROM best_match;
    
    -- Populate REVIEW_QUEUE for partial matches (0.5 ≤ confidence < 1.0)
    INSERT INTO HITL.REVIEW_QUEUE
        (QUEUE_ID, PAIR_ID, PERIOD, LINE_A_ID, LINE_B_ID, PHASE, CONFIDENCE, FAILED_CRITERIA, AI_REASONING, QUEUE_STATUS)
    SELECT
        UUID_STRING(),
        PAIR_ID, PERIOD, LINE_A_ID, LINE_B_ID, 'PHASE2', CONFIDENCE, CRITERIA_FAILED,
        'Phase 2 partial match: ' || CRITERIA_FAILED, 'PENDING'
    FROM RESULTS.PHASE2_LINE_MATCHES
    WHERE PERIOD = :P_PERIOD AND PAIR_ID = :P_PAIR_ID
      AND OS_ACCOUNT = :P_OS_ACCOUNT
      AND MATCH_STATUS = 'REVIEW';
    
    RETURN OBJECT_CONSTRUCT('status', 'DONE', 'pair_id', :P_PAIR_ID);
END;
$$;
```

## 3.4 SP_RUN_PHASE3 — Cortex Fuzzy Matching

```sql
CREATE OR REPLACE PROCEDURE RESULTS.SP_RUN_PHASE3(P_PERIOD DATE, P_PAIR_ID VARCHAR)
RETURNS VARIANT
LANGUAGE SQL
AS
$$
BEGIN
    -- Step 1: ensure embeddings are computed for unmatched lines
    UPDATE STAGING.IC_LINES
    SET EMBEDDING_TEXT = COALESCE(COUNTERPARTY_CODE, '') || ' | '
                       || COALESCE(DOC_NUMBER, '') || ' | '
                       || COALESCE(DOC_CURRENCY, '') || ' | '
                       || ROUND(ABS(DOC_AMOUNT), 0) || ' | '
                       || COALESCE(POSTING_MONTH, '') || ' | '
                       || COALESCE(SAP_ACCOUNT_DESCRIPTION, '') || ' | '
                       || COALESCE(LEFT(FREE_TEXT, 200), '')
    WHERE PERIOD = :P_PERIOD
      AND PAIR_ID = :P_PAIR_ID
      AND PHASE2_MATCH_ID IS NULL
      AND EMBEDDING_TEXT IS NULL;

    UPDATE STAGING.IC_LINES
    SET EMBEDDING_VECTOR = SNOWFLAKE.CORTEX.EMBED_TEXT_1024('snowflake-arctic-embed-l-v2.0', EMBEDDING_TEXT)
    WHERE PERIOD = :P_PERIOD
      AND PAIR_ID = :P_PAIR_ID
      AND PHASE2_MATCH_ID IS NULL
      AND EMBEDDING_VECTOR IS NULL
      AND EMBEDDING_TEXT IS NOT NULL;

    -- Step 2: find K=5 nearest Side B candidates for each unmatched Side A line
    INSERT INTO RESULTS.PHASE3_FUZZY_MATCHES
        (FUZZY_MATCH_ID, PERIOD, PAIR_ID, LINE_A_ID, LINE_B_ID,
         COSINE_SIMILARITY, AMOUNT_PROXIMITY, DATE_PROXIMITY,
         AI_CONFIDENCE, AI_REASONING)
    WITH unmatched AS (
        SELECT *
        FROM STAGING.IC_LINES
        WHERE PERIOD = :P_PERIOD
          AND PAIR_ID = :P_PAIR_ID
          AND PHASE2_MATCH_ID IS NULL
          AND EMBEDDING_VECTOR IS NOT NULL
    ),
    side_a AS (SELECT * FROM unmatched WHERE ENTITY_CODE = SPLIT_PART(:P_PAIR_ID, '-', 1)),
    side_b AS (SELECT * FROM unmatched WHERE ENTITY_CODE = SPLIT_PART(:P_PAIR_ID, '-', 2)),
    candidates AS (
        SELECT
            a.LINE_ID AS LINE_A_ID,
            b.LINE_ID AS LINE_B_ID,
            VECTOR_COSINE_SIMILARITY(a.EMBEDDING_VECTOR, b.EMBEDDING_VECTOR) AS COSINE_SIM,
            1 - LEAST(1, ABS(ABS(a.DOC_AMOUNT) - ABS(b.DOC_AMOUNT)) / GREATEST(ABS(a.DOC_AMOUNT), ABS(b.DOC_AMOUNT), 1)) AS AMT_PROX,
            1 - LEAST(1, ABS(DATEDIFF('day', a.DOC_DATE, b.DOC_DATE)) / 30.0) AS DT_PROX,
            ROW_NUMBER() OVER (PARTITION BY a.LINE_ID
                                ORDER BY VECTOR_COSINE_SIMILARITY(a.EMBEDDING_VECTOR, b.EMBEDDING_VECTOR) DESC) AS RN
        FROM side_a a CROSS JOIN side_b b
    ),
    top_matches AS (
        SELECT * FROM candidates WHERE RN <= 5
    )
    SELECT
        UUID_STRING(),
        :P_PERIOD,
        :P_PAIR_ID,
        LINE_A_ID,
        LINE_B_ID,
        COSINE_SIM,
        AMT_PROX,
        DT_PROX,
        (0.50 * COSINE_SIM + 0.30 * AMT_PROX + 0.20 * DT_PROX) AS AI_CONFIDENCE,
        'Cosine sim ' || ROUND(COSINE_SIM, 3) ||
        ', amount proximity ' || ROUND(AMT_PROX, 3) ||
        ', date proximity ' || ROUND(DT_PROX, 3) AS AI_REASONING
    FROM top_matches
    WHERE RN = 1;  -- only the best candidate per Side A line

    -- Route to FUZZY_APPROVAL_QUEUE (≥ 0.80) or REVIEW_QUEUE (0.60-0.80)
    INSERT INTO HITL.FUZZY_APPROVAL_QUEUE
        (QUEUE_ID, PAIR_ID, PERIOD, LINE_A_ID, LINE_B_ID,
         COSINE_SIMILARITY, AMOUNT_PROXIMITY, DATE_PROXIMITY,
         AI_CONFIDENCE, AI_REASONING, EMBEDDING_MODEL, QUEUE_STATUS)
    SELECT
        UUID_STRING(),
        PAIR_ID, PERIOD, LINE_A_ID, LINE_B_ID,
        COSINE_SIMILARITY, AMOUNT_PROXIMITY, DATE_PROXIMITY,
        AI_CONFIDENCE, AI_REASONING,
        'snowflake-arctic-embed-l-v2.0', 'PENDING'
    FROM RESULTS.PHASE3_FUZZY_MATCHES
    WHERE PERIOD = :P_PERIOD AND PAIR_ID = :P_PAIR_ID AND AI_CONFIDENCE >= 0.80;

    INSERT INTO HITL.REVIEW_QUEUE
        (QUEUE_ID, PAIR_ID, PERIOD, LINE_A_ID, LINE_B_ID, PHASE, CONFIDENCE, AI_REASONING, QUEUE_STATUS)
    SELECT
        UUID_STRING(),
        PAIR_ID, PERIOD, LINE_A_ID, LINE_B_ID, 'PHASE3',
        AI_CONFIDENCE,
        'Cortex fuzzy match below approval threshold: ' || AI_REASONING,
        'PENDING'
    FROM RESULTS.PHASE3_FUZZY_MATCHES
    WHERE PERIOD = :P_PERIOD AND PAIR_ID = :P_PAIR_ID
      AND AI_CONFIDENCE >= 0.60 AND AI_CONFIDENCE < 0.80;

    RETURN OBJECT_CONSTRUCT('status', 'DONE', 'pair_id', :P_PAIR_ID);
END;
$$;
```

## 3.5 SP_RUN_PHASE4 — AI-Assisted Classification with claude-3-5-sonnet

```sql
CREATE OR REPLACE PROCEDURE RESULTS.SP_RUN_PHASE4(P_PERIOD DATE, P_PAIR_ID VARCHAR, P_OS_ACCOUNT VARCHAR)
RETURNS VARIANT
LANGUAGE PYTHON
RUNTIME_VERSION = '3.10'
PACKAGES = ('snowflake-snowpark-python')
HANDLER = 'run'
AS
$$
import json

PROMPT_VERSION = 'v1.0'

PROMPT_TEMPLATE = """You are a senior intercompany controller for Evident. You receive an unreconciled intercompany variance.

VARIANCE DETAILS:
  Pair:                    {entity_a} ↔ {entity_b}
  OS Account:              {os_account} ({os_description})
  Category:                {category}
  Currency:                {doc_currency}
  Side A booked amount:    {side_a_amount}
  Side B booked amount:    {side_b_amount}
  Net variance:            {variance_amount}
  Number of unmatched A:   {unmatched_count_a}
  Number of unmatched B:   {unmatched_count_b}

LINES ON SIDE A (unmatched):
{lines_a}

LINES ON SIDE B (unmatched):
{lines_b}

KNOWN RECURRING ISSUES (most similar):
{known_issues}

HISTORICAL SIMILAR RESOLUTIONS (few-shot examples):
{few_shot_examples}

PLUG ACCOUNTS:
  {entity_a} plug:         {plug_account_a}
  {entity_b} plug:         {plug_account_b}

Classify the root cause and propose a journal entry to clear the variance.
Respond in JSON only with this exact schema:
{{
  "root_cause_category": "MISSING_BOOKING|FOREX_DIFFERENCE|TIMING_DIFFERENCE|RECLASSIFICATION|DATA_ENTRY_ERROR|OTHER",
  "confidence": 0.0,
  "reasoning": "...",
  "suggested_action": "PROPOSE_JE|INVESTIGATE|IGNORE|ESCALATE",
  "proposed_journal": {{
    "booking_entity": "...",
    "lines": [{{ "dr_or_cr": "DR|CR", "sap_account": "...", "description": "...", "amount": 0, "currency": "..." }}],
    "narrative": "..."
  }},
  "similar_issue_id": null
}}"""

def run(session, p_period, p_pair_id, p_os_account):
    # 1. Fetch the variance details from PHASE1_BALANCE_RECON
    variance_row = session.sql(f"""
        SELECT * FROM RESULTS.PHASE1_BALANCE_RECON
        WHERE PERIOD = '{p_period}' AND PAIR_ID = '{p_pair_id}'
          AND OS_ACCOUNT = '{p_os_account}' AND RECON_STATUS = 'VARIANCE'
    """).collect()

    if not variance_row:
        return {'status': 'NO_VARIANCE', 'pair_id': p_pair_id}
    v = variance_row[0]

    # 2. Fetch unmatched lines
    unmatched_a = session.sql(f"""
        SELECT LINE_ID, DOC_NUMBER, DOC_AMOUNT, DOC_CURRENCY, DOC_DATE, FREE_TEXT
        FROM STAGING.IC_LINES
        WHERE PERIOD = '{p_period}' AND PAIR_ID = '{p_pair_id}'
          AND ONESTREAM_ACCOUNT = '{p_os_account}'
          AND ENTITY_CODE = '{v['SIDE_A_ENTITY']}'
          AND PHASE2_MATCH_ID IS NULL
          AND PHASE3_MATCH_ID IS NULL
        LIMIT 30
    """).collect()
    unmatched_b = session.sql(f"""
        SELECT LINE_ID, DOC_NUMBER, DOC_AMOUNT, DOC_CURRENCY, DOC_DATE, FREE_TEXT
        FROM STAGING.IC_LINES
        WHERE PERIOD = '{p_period}' AND PAIR_ID = '{p_pair_id}'
          AND ONESTREAM_ACCOUNT = '{p_os_account}'
          AND ENTITY_CODE = '{v['SIDE_B_ENTITY']}'
          AND PHASE2_MATCH_ID IS NULL
          AND PHASE3_MATCH_ID IS NULL
        LIMIT 30
    """).collect()

    # 3. Fetch known issues for this pair-account
    known_issues = session.sql(f"""
        SELECT PATTERN_DESCRIPTION, TYPICAL_RESOLUTION
        FROM REF.REF_KNOWN_ISSUES
        WHERE PAIR_ID = '{p_pair_id}' AND OS_ACCOUNT = '{p_os_account}'
        LIMIT 5
    """).collect()

    # 4. Fetch top-3 most similar few-shot examples
    few_shot = session.sql(f"""
        SELECT VARIANCE_DESCRIPTION, ROOT_CAUSE_CATEGORY, PROPOSED_JOURNAL_JSON, REMARK
        FROM TRAINING.PHASE4_FEW_SHOT_EXAMPLES
        WHERE PAIR_ID = '{p_pair_id}' OR ROOT_CAUSE_CATEGORY IN
          (SELECT DISTINCT ROOT_CAUSE_CATEGORY FROM TRAINING.PHASE4_FEW_SHOT_EXAMPLES
           WHERE PAIR_ID = '{p_pair_id}')
        LIMIT 3
    """).collect()

    # 5. Fetch plug accounts
    plug_a = session.sql(f"""
        SELECT DISTINCT PLUG_ACCOUNT FROM REF.REF_ENTITY_GL_ACCOUNTS
        WHERE ENTITY_CODE = '{v['SIDE_A_ENTITY']}' AND ONESTREAM_ACCOUNT = '{p_os_account}'
    """).collect()
    plug_b = session.sql(f"""
        SELECT DISTINCT PLUG_ACCOUNT FROM REF.REF_ENTITY_GL_ACCOUNTS
        WHERE ENTITY_CODE = '{v['SIDE_B_ENTITY']}' AND ONESTREAM_ACCOUNT = '{p_os_account}'
    """).collect()

    # 6. Build prompt
    prompt = PROMPT_TEMPLATE.format(
        entity_a = v['SIDE_A_ENTITY'],
        entity_b = v['SIDE_B_ENTITY'],
        os_account = v['OS_ACCOUNT'],
        os_description = v['OS_DESCRIPTION'],
        category = v['CATEGORY'],
        doc_currency = v['DOC_CURRENCY'],
        side_a_amount = v['SIDE_A_BALANCE'],
        side_b_amount = v['SIDE_B_BALANCE'],
        variance_amount = v['VARIANCE'],
        unmatched_count_a = len(unmatched_a),
        unmatched_count_b = len(unmatched_b),
        lines_a = '\n'.join([f"  - {r['DOC_NUMBER']} {r['DOC_CURRENCY']} {r['DOC_AMOUNT']} {r['DOC_DATE']}: {(r['FREE_TEXT'] or '')[:100]}" for r in unmatched_a[:10]]),
        lines_b = '\n'.join([f"  - {r['DOC_NUMBER']} {r['DOC_CURRENCY']} {r['DOC_AMOUNT']} {r['DOC_DATE']}: {(r['FREE_TEXT'] or '')[:100]}" for r in unmatched_b[:10]]),
        known_issues = '\n'.join([f"  - {k['PATTERN_DESCRIPTION']}: {k['TYPICAL_RESOLUTION']}" for k in known_issues]) or '  (none)',
        few_shot_examples = '\n'.join([f"  - {f['VARIANCE_DESCRIPTION']} → {f['ROOT_CAUSE_CATEGORY']}: {json.dumps(f['PROPOSED_JOURNAL_JSON'])[:300]}" for f in few_shot]) or '  (none)',
        plug_account_a = plug_a[0]['PLUG_ACCOUNT'] if plug_a else 'N/A',
        plug_account_b = plug_b[0]['PLUG_ACCOUNT'] if plug_b else 'N/A',
    )

    # 7. Call Cortex Complete with claude-3-5-sonnet
    cortex_result = session.sql(f"""
        SELECT SNOWFLAKE.CORTEX.COMPLETE('claude-3-5-sonnet', $${prompt}$$) AS RESULT
    """).collect()
    response_text = cortex_result[0]['RESULT']

    # 8. Parse JSON response
    try:
        ai_output = json.loads(response_text.strip())
    except json.JSONDecodeError:
        # Strip any code-fence markers and retry
        text = response_text.strip().strip('`').strip()
        if text.startswith('json'):
            text = text[4:].strip()
        ai_output = json.loads(text)

    # 9. Persist to PHASE4_AI_CLASSIFICATIONS and CLASSIFICATION_APPROVAL_QUEUE
    classification_id = session.sql(f"SELECT UUID_STRING() AS U").collect()[0]['U']

    session.sql(f"""
        INSERT INTO RESULTS.PHASE4_AI_CLASSIFICATIONS
        (CLASSIFICATION_ID, PERIOD, PAIR_ID, OS_ACCOUNT, CATEGORY, DOC_CURRENCY,
         VARIANCE_AMOUNT, VARIANCE_AMOUNT_JPY,
         UNMATCHED_LINE_IDS_A, UNMATCHED_LINE_IDS_B,
         ROOT_CAUSE_CATEGORY, AI_CONFIDENCE, AI_REASONING, SUGGESTED_ACTION,
         PROPOSED_JOURNAL, LLM_MODEL, LLM_PROMPT_VERSION)
        SELECT '{classification_id}', '{p_period}', '{p_pair_id}', '{p_os_account}',
               '{v['CATEGORY']}', '{v['DOC_CURRENCY']}',
               {v['VARIANCE']}, {v['VARIANCE_JPY']},
               {[r['LINE_ID'] for r in unmatched_a]},
               {[r['LINE_ID'] for r in unmatched_b]},
               '{ai_output['root_cause_category']}',
               {ai_output['confidence']},
               $${ai_output['reasoning']}$$,
               '{ai_output['suggested_action']}',
               PARSE_JSON($${json.dumps(ai_output['proposed_journal'])}$$),
               'claude-3-5-sonnet', '{PROMPT_VERSION}'
    """).collect()

    session.sql(f"""
        INSERT INTO HITL.CLASSIFICATION_APPROVAL_QUEUE
        (QUEUE_ID, PAIR_ID, PERIOD, OS_ACCOUNT, CATEGORY, DOC_CURRENCY,
         VARIANCE_AMOUNT, VARIANCE_AMOUNT_JPY,
         UNMATCHED_LINE_IDS_A, UNMATCHED_LINE_IDS_B,
         ROOT_CAUSE_CATEGORY, AI_CONFIDENCE, AI_REASONING, SUGGESTED_ACTION,
         PROPOSED_JOURNAL, LLM_MODEL, LLM_PROMPT_VERSION)
        SELECT UUID_STRING(), '{p_pair_id}', '{p_period}', '{p_os_account}',
               '{v['CATEGORY']}', '{v['DOC_CURRENCY']}',
               {v['VARIANCE']}, {v['VARIANCE_JPY']},
               {[r['LINE_ID'] for r in unmatched_a]},
               {[r['LINE_ID'] for r in unmatched_b]},
               '{ai_output['root_cause_category']}',
               {ai_output['confidence']},
               $${ai_output['reasoning']}$$,
               '{ai_output['suggested_action']}',
               PARSE_JSON($${json.dumps(ai_output['proposed_journal'])}$$),
               'claude-3-5-sonnet', '{PROMPT_VERSION}'
    """).collect()

    return {'status': 'DONE', 'classification_id': classification_id, 'root_cause': ai_output['root_cause_category']}
$$;
```

## 3.6 SP_VALIDATE_REGRESSION — compare pipeline output vs MISvsMIS targets

```sql
CREATE OR REPLACE PROCEDURE REGRESSION.SP_VALIDATE_REGRESSION(P_PERIOD DATE)
RETURNS VARIANT
LANGUAGE SQL
AS
$$
DECLARE
    v_run_id VARCHAR DEFAULT UUID_STRING();
    v_pairs_tested NUMBER;
    v_pairs_within NUMBER;
    v_pairs_out NUMBER;
BEGIN
    INSERT INTO REGRESSION.REGRESSION_RUNS (RUN_ID, PERIOD, PIPELINE_VERSION, DETAIL)
    WITH pipeline_residuals AS (
        SELECT PAIR_ID, SUM(VARIANCE_JPY) AS PIPELINE_VARIANCE_JPY
        FROM RESULTS.PHASE1_BALANCE_RECON
        WHERE PERIOD = :P_PERIOD AND RECON_STATUS = 'VARIANCE'
        GROUP BY PAIR_ID
    ),
    comparison AS (
        SELECT
            t.PAIR_ID,
            t.JPY_RESIDUAL AS TARGET_JPY,
            COALESCE(p.PIPELINE_VARIANCE_JPY, 0) AS PIPELINE_JPY,
            ABS(COALESCE(p.PIPELINE_VARIANCE_JPY, 0) - t.JPY_RESIDUAL) AS GAP_JPY,
            CASE WHEN ABS(COALESCE(p.PIPELINE_VARIANCE_JPY, 0)) BETWEEN ABS(t.JPY_RESIDUAL)*0.95 AND ABS(t.JPY_RESIDUAL)*1.05
                 THEN 1 ELSE 0 END AS WITHIN_TARGET
        FROM REGRESSION.PAIR_RESIDUAL_TARGETS t
        LEFT JOIN pipeline_residuals p ON t.PAIR_ID = p.PAIR_ID
        WHERE t.PERIOD = :P_PERIOD
    )
    SELECT :v_run_id, :P_PERIOD, 'v1.0',
           OBJECT_CONSTRUCT(
               'pairs', ARRAY_AGG(OBJECT_CONSTRUCT(
                   'pair_id', PAIR_ID,
                   'target_jpy', TARGET_JPY,
                   'pipeline_jpy', PIPELINE_JPY,
                   'gap_jpy', GAP_JPY,
                   'within_target', WITHIN_TARGET = 1
               )),
               'summary', OBJECT_CONSTRUCT(
                   'pairs_tested', COUNT(*),
                   'pairs_within', SUM(WITHIN_TARGET),
                   'pairs_out', COUNT(*) - SUM(WITHIN_TARGET)
               )
           )
    FROM comparison;

    SELECT
        DETAIL:summary.pairs_tested::NUMBER,
        DETAIL:summary.pairs_within::NUMBER,
        DETAIL:summary.pairs_out::NUMBER
      INTO :v_pairs_tested, :v_pairs_within, :v_pairs_out
    FROM REGRESSION.REGRESSION_RUNS WHERE RUN_ID = :v_run_id;

    UPDATE REGRESSION.REGRESSION_RUNS
    SET PAIRS_TESTED = :v_pairs_tested,
        PAIRS_WITHIN_TARGET = :v_pairs_within,
        PAIRS_OUT_OF_TARGET = :v_pairs_out
    WHERE RUN_ID = :v_run_id;

    RETURN OBJECT_CONSTRUCT(
        'run_id', :v_run_id,
        'pairs_tested', :v_pairs_tested,
        'pairs_within_target', :v_pairs_within,
        'pairs_out_of_target', :v_pairs_out
    );
END;
$$;
```

## 3.7 SP_RUN_PIPELINE_END_TO_END — master orchestrator

```sql
CREATE OR REPLACE PROCEDURE PUBLIC.SP_RUN_PIPELINE_END_TO_END(P_PERIOD DATE)
RETURNS VARIANT
LANGUAGE SQL
AS
$$
DECLARE
    v_pair_cursor CURSOR FOR
        SELECT DISTINCT PAIR_ID FROM STAGING.IC_LINES WHERE PERIOD = :P_PERIOD;
    v_recon_cursor CURSOR FOR
        SELECT PAIR_ID, OS_ACCOUNT FROM RESULTS.PHASE1_BALANCE_RECON
        WHERE PERIOD = :P_PERIOD AND RECON_STATUS = 'VARIANCE';
BEGIN
    -- Phase 1: GL Balance Reconciliation (one shot, all pairs)
    CALL RESULTS.SP_RUN_PHASE1(:P_PERIOD);

    -- Phase 2 + Phase 3 + Phase 4: per (pair, OS account) with variance
    FOR p IN v_recon_cursor DO
        CALL RESULTS.SP_RUN_PHASE2_TRADE(:P_PERIOD, p.PAIR_ID, p.OS_ACCOUNT);
        CALL RESULTS.SP_RUN_PHASE2_NONTRADE(:P_PERIOD, p.PAIR_ID, p.OS_ACCOUNT);
        CALL RESULTS.SP_RUN_PHASE3(:P_PERIOD, p.PAIR_ID);
        CALL RESULTS.SP_RUN_PHASE4(:P_PERIOD, p.PAIR_ID, p.OS_ACCOUNT);
    END FOR;

    -- Validation
    CALL REGRESSION.SP_VALIDATE_REGRESSION(:P_PERIOD);

    RETURN OBJECT_CONSTRUCT('status', 'COMPLETE', 'period', :P_PERIOD);
END;
$$;
```

## 3.8 Snowflake Task — monthly orchestration

```sql
CREATE OR REPLACE TASK MONTHLY_RECON_TASK
    WAREHOUSE = RECON_AI_WH
    SCHEDULE = 'USING CRON 0 2 6 * * UTC'  -- 2 AM UTC on the 6th of each month
    COMMENT = 'Run end-to-end reconciliation pipeline'
AS
    CALL PUBLIC.SP_RUN_PIPELINE_END_TO_END(DATE_TRUNC('MONTH', CURRENT_DATE() - 1));
```

---

# Section 4 — Cortex AI Configuration

## 4.1 Models in use

| Model | Purpose | Function |
|-------|---------|----------|
| `snowflake-arctic-embed-l-v2.0` | Phase 3: text embeddings for fuzzy match | `SNOWFLAKE.CORTEX.EMBED_TEXT_1024(model, text)` |
| `claude-3-5-sonnet` | Phase 4: classification + journal proposal | `SNOWFLAKE.CORTEX.COMPLETE(model, prompt)` |

## 4.2 Embedding cost & throughput estimate

For a typical month with ~3,500 unmatched lines requiring embedding (Phase 3):
- Cost per embedding: ~$0.0001
- Total: ~$0.35 per period
- Latency: ~1-2 minutes for the entire batch

## 4.3 Cortex Complete cost & throughput estimate

For a typical month with ~50 residuals requiring Phase 4 classification:
- Cost per call: ~$0.01 (depends on prompt size)
- Total: ~$0.50 per period
- Latency: ~5-10 minutes for batch

**Total monthly Cortex cost: ~$1 per period.** Negligible vs the value created.

## 4.4 Prompt versioning strategy

Each Phase 4 prompt template carries a version (`v1.0`, `v1.1`, etc.). Versions are tracked in `PHASE4_AI_CLASSIFICATIONS.LLM_PROMPT_VERSION` so that we can A/B compare proposal quality across prompt iterations and roll back if needed.

## 4.5 Cortex Search Service (optional enhancement)

For more sophisticated few-shot retrieval in Phase 4, deploy Cortex Search over `TRAINING.PHASE4_FEW_SHOT_EXAMPLES`:

```sql
CREATE OR REPLACE CORTEX SEARCH SERVICE FEW_SHOT_SEARCH
ON EMBEDDING_TEXT
ATTRIBUTES PAIR_ID, ROOT_CAUSE_CATEGORY, PROPOSED_JOURNAL_JSON, REMARK
WAREHOUSE = RECON_AI_WH
TARGET_LAG = '1 day'
AS (
    SELECT EMBEDDING_TEXT, PAIR_ID, ROOT_CAUSE_CATEGORY, PROPOSED_JOURNAL_JSON, REMARK
    FROM TRAINING.PHASE4_FEW_SHOT_EXAMPLES
);
```

Then in `SP_RUN_PHASE4`, replace the static SQL `SELECT` of few-shot examples with a Cortex Search call that retrieves the most semantically similar examples.

---

# Section 5 — Streamlit-in-Snowflake Application

## 5.1 App scaffold and navigation

```
/streamlit_app/
├── app.py                                        # Entry point, sidebar, routing
├── pages/
│   ├── 0_📊_Dashboard.py
│   ├── 1_📈_GL_Level_Matching.py
│   ├── 2_🧾_Invoice_Level_Matching.py
│   ├── 3_⚠️_Review_Queue.py
│   ├── 4_🤝_Fuzzy_Approval_Queue.py
│   └── 5_🤖_Classification_Approval_Queue.py
├── utils/
│   ├── __init__.py
│   ├── snowpark_client.py                        # session getter, caching helpers
│   ├── styling.py                                # color-coding, threshold logic
│   ├── period_picker.py                          # period dropdown widget
│   └── audit.py                                  # decision-logging helpers
└── environment.yml                               # Conda env: streamlit, snowflake-snowpark-python, plotly, pandas
```

## 5.2 `app.py` — entry point and global styling

```python
import streamlit as st
from utils.snowpark_client import get_session
from utils.period_picker import render_period_picker

st.set_page_config(
    page_title="Evident Intercompany Reconciliation",
    page_icon="📊",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Custom CSS for Deloitte-branded look
st.markdown("""
<style>
.stApp { background-color: #FAFAFA; }
.metric-card { padding: 1rem; border-radius: 8px; background: white; box-shadow: 0 2px 8px rgba(0,0,0,0.08); }
.green { color: #46A35E; }
.amber { color: #F2A900; }
.red   { color: #DA291C; }
</style>
""", unsafe_allow_html=True)

# Sidebar — global period selection
with st.sidebar:
    st.title("🔍 Evident Reconciliation")
    period = render_period_picker()
    st.session_state['active_period'] = period
    st.divider()
    st.caption("Pipeline status")
    session = get_session()
    last_run = session.sql(f"""
        SELECT MAX(COMPUTED_AT) AS LAST_RUN
        FROM RESULTS.PHASE1_BALANCE_RECON
        WHERE PERIOD = '{period}'
    """).collect()
    st.info(f"Last run: {last_run[0]['LAST_RUN'] or 'Not run yet'}")
    if st.button("🔄 Run pipeline now"):
        session.sql(f"CALL PUBLIC.SP_RUN_PIPELINE_END_TO_END('{period}')").collect()
        st.success("Pipeline started")
        st.rerun()
```

## 5.3 Page 0 — Dashboard

```python
# pages/0_📊_Dashboard.py
import streamlit as st
import pandas as pd
import plotly.express as px
from utils.snowpark_client import get_session

st.title("📊 Period Dashboard")
period = st.session_state.get('active_period')
session = get_session()

# KPI tiles
col1, col2, col3, col4 = st.columns(4)
kpis = session.sql(f"""
    SELECT
        COUNT(DISTINCT PAIR_ID) AS TOTAL_PAIRS,
        COUNT(DISTINCT CASE WHEN RECON_STATUS = 'RECONCILED' THEN PAIR_ID END) AS PAIRS_GREEN,
        COUNT(DISTINCT CASE WHEN RECON_STATUS = 'VARIANCE' THEN PAIR_ID END) AS PAIRS_VARIANCE,
        SUM(ABS(VARIANCE_JPY)) AS TOTAL_VARIANCE_JPY
    FROM RESULTS.PHASE1_BALANCE_RECON
    WHERE PERIOD = '{period}'
""").to_pandas()
col1.metric("Total Pairs", int(kpis['TOTAL_PAIRS'][0] or 0))
col2.metric("Reconciled", int(kpis['PAIRS_GREEN'][0] or 0))
col3.metric("With Variance", int(kpis['PAIRS_VARIANCE'][0] or 0))
col4.metric("Variance JPY", f"¥{kpis['TOTAL_VARIANCE_JPY'][0]:,.0f}" if kpis['TOTAL_VARIANCE_JPY'][0] else "¥0")

# HITL queue depth
st.subheader("HITL Queues")
q1, q2, q3 = st.columns(3)
review_count = session.sql(f"SELECT COUNT(*) AS C FROM HITL.REVIEW_QUEUE WHERE PERIOD = '{period}' AND QUEUE_STATUS = 'PENDING'").collect()[0]['C']
fuzzy_count = session.sql(f"SELECT COUNT(*) AS C FROM HITL.FUZZY_APPROVAL_QUEUE WHERE PERIOD = '{period}' AND QUEUE_STATUS = 'PENDING'").collect()[0]['C']
class_count = session.sql(f"SELECT COUNT(*) AS C FROM HITL.CLASSIFICATION_APPROVAL_QUEUE WHERE PERIOD = '{period}' AND QUEUE_STATUS = 'PENDING'").collect()[0]['C']
q1.metric("Review Queue", review_count)
q2.metric("Fuzzy Approval Queue", fuzzy_count)
q3.metric("AI Classification Queue", class_count)

# Top variances
st.subheader("Top Variances by Pair")
top_var = session.sql(f"""
    SELECT PAIR_ID, OS_ACCOUNT, DOC_CURRENCY, VARIANCE, VARIANCE_JPY
    FROM RESULTS.PHASE1_BALANCE_RECON
    WHERE PERIOD = '{period}' AND RECON_STATUS = 'VARIANCE'
    ORDER BY ABS(VARIANCE_JPY) DESC
    LIMIT 10
""").to_pandas()
st.dataframe(top_var, use_container_width=True, hide_index=True)

# Regression validation
st.subheader("Regression Test vs MISvsMIS Targets")
regression = session.sql(f"""
    SELECT *
    FROM REGRESSION.REGRESSION_RUNS
    WHERE PERIOD = '{period}'
    ORDER BY RUN_AT DESC LIMIT 1
""").to_pandas()
if len(regression):
    st.success(f"Latest run: {regression['PAIRS_WITHIN_TARGET'][0]} of {regression['PAIRS_TESTED'][0]} pairs within ±5% of MISvsMIS target")
```

## 5.4 Page 1 — GL-Level Matching

```python
# pages/1_📈_GL_Level_Matching.py
import streamlit as st
import pandas as pd
from utils.snowpark_client import get_session

st.title("📈 GL Account Level Matching (Phase 1)")
period = st.session_state.get('active_period')
session = get_session()

view_mode = st.radio("View by", ["Overall", "By Entity"], horizontal=True)

if view_mode == "Overall":
    df = session.sql(f"""
        SELECT
            PAIR_ID,
            COUNT(*) AS OS_ACCOUNTS,
            COUNT(CASE WHEN RECON_STATUS = 'RECONCILED' THEN 1 END) AS OS_OK,
            COUNT(CASE WHEN RECON_STATUS = 'VARIANCE' THEN 1 END) AS OS_VAR,
            SUM(ABS(VARIANCE_JPY)) AS GROSS_VAR_JPY,
            CASE WHEN COUNT(CASE WHEN RECON_STATUS = 'VARIANCE' THEN 1 END) = 0 THEN '🟢 GREEN'
                 WHEN SUM(ABS(VARIANCE_JPY)) < 100000 THEN '🟡 AMBER'
                 ELSE '🔴 RED' END AS STATUS
        FROM RESULTS.PHASE1_BALANCE_RECON
        WHERE PERIOD = '{period}'
        GROUP BY PAIR_ID
        ORDER BY GROSS_VAR_JPY DESC NULLS LAST
    """).to_pandas()
    st.dataframe(df, use_container_width=True, hide_index=True)

    # Drill-down: select a pair to expand
    selected_pair = st.selectbox("Drill into pair:", df['PAIR_ID'].tolist() if len(df) else [])
    if selected_pair:
        detail = session.sql(f"""
            SELECT OS_ACCOUNT, OS_DESCRIPTION, CATEGORY, DOC_CURRENCY,
                   SIDE_A_BALANCE, SIDE_B_BALANCE, VARIANCE, VARIANCE_PCT, RECON_STATUS
            FROM RESULTS.PHASE1_BALANCE_RECON
            WHERE PERIOD = '{period}' AND PAIR_ID = '{selected_pair}'
            ORDER BY ABS(VARIANCE) DESC
        """).to_pandas()
        st.dataframe(detail, use_container_width=True, hide_index=True)

else:  # By Entity
    df = session.sql(f"""
        WITH split AS (
            SELECT PAIR_ID, SPLIT_PART(PAIR_ID, '-', 1) AS E1, SPLIT_PART(PAIR_ID, '-', 2) AS E2,
                   RECON_STATUS, ABS(VARIANCE_JPY) AS VAR_JPY
            FROM RESULTS.PHASE1_BALANCE_RECON
            WHERE PERIOD = '{period}'
        ),
        unioned AS (
            SELECT E1 AS ENTITY, RECON_STATUS, VAR_JPY FROM split
            UNION ALL
            SELECT E2 AS ENTITY, RECON_STATUS, VAR_JPY FROM split
        )
        SELECT ENTITY,
               COUNT(*) AS PAIR_LINES,
               COUNT(CASE WHEN RECON_STATUS = 'RECONCILED' THEN 1 END) AS OK,
               COUNT(CASE WHEN RECON_STATUS = 'VARIANCE' THEN 1 END) AS WITH_VAR,
               SUM(VAR_JPY) AS TOT_VAR_JPY
        FROM unioned
        GROUP BY ENTITY
        ORDER BY TOT_VAR_JPY DESC NULLS LAST
    """).to_pandas()
    st.dataframe(df, use_container_width=True, hide_index=True)
```

## 5.5 Page 2 — Invoice-Level Matching

```python
# pages/2_🧾_Invoice_Level_Matching.py
import streamlit as st
from utils.snowpark_client import get_session

st.title("🧾 Invoice Level Matching (Phase 2)")
period = st.session_state.get('active_period')
session = get_session()

view_mode = st.radio("View", ["Overall", "By Entity", "Detail"], horizontal=True)

if view_mode == "Overall":
    df = session.sql(f"""
        SELECT
            m.PAIR_ID,
            COUNT(*) AS LINES_TOTAL,
            COUNT(CASE WHEN MATCH_STATUS = 'PERFECT' THEN 1 END) AS LINES_MATCHED,
            COUNT(CASE WHEN MATCH_STATUS = 'REVIEW' THEN 1 END) AS LINES_REVIEW,
            COUNT(CASE WHEN MATCH_STATUS = 'PHASE3' THEN 1 END) AS LINES_TO_FUZZY,
            ROUND(AVG(CONFIDENCE), 3) AS AVG_CONF
        FROM RESULTS.PHASE2_LINE_MATCHES m
        WHERE PERIOD = '{period}'
        GROUP BY PAIR_ID
        ORDER BY LINES_TOTAL DESC
    """).to_pandas()
    st.dataframe(df, use_container_width=True, hide_index=True)

elif view_mode == "Detail":
    pair_id = st.selectbox("Pair", session.sql(f"SELECT DISTINCT PAIR_ID FROM RESULTS.PHASE2_LINE_MATCHES WHERE PERIOD = '{period}'").to_pandas()['PAIR_ID'].tolist())
    if pair_id:
        df = session.sql(f"""
            SELECT MATCH_ID, ENTITY_A, DOC_A, AMT_A, DT_A,
                   ENTITY_B, DOC_B, AMT_B, DT_B,
                   CONFIDENCE, MATCH_STATUS, CRITERIA_FAILED
            FROM RESULTS.V_PHASE2_LINE_MATCHES_DETAIL
            WHERE PERIOD = '{period}' AND PAIR_ID = '{pair_id}'
            ORDER BY CONFIDENCE DESC
            LIMIT 500
        """).to_pandas()
        st.dataframe(df, use_container_width=True, hide_index=True)
```

## 5.6 Page 3 — Review Queue

```python
# pages/3_⚠️_Review_Queue.py
import streamlit as st
import pandas as pd
from utils.snowpark_client import get_session
from utils.audit import log_decision

st.title("⚠️ Review Queue (Phase 2 / Phase 3 partial matches)")
period = st.session_state.get('active_period')
session = get_session()

queue = session.sql(f"""
    SELECT q.QUEUE_ID, q.PAIR_ID, q.PHASE, q.CONFIDENCE, q.FAILED_CRITERIA, q.AI_REASONING,
           a.DOC_NUMBER AS DOC_A, a.DOC_CURRENCY AS CCY_A, a.DOC_AMOUNT AS AMT_A, a.DOC_DATE AS DT_A, LEFT(a.FREE_TEXT, 60) AS FT_A,
           b.DOC_NUMBER AS DOC_B, b.DOC_AMOUNT AS AMT_B, b.DOC_DATE AS DT_B, LEFT(b.FREE_TEXT, 60) AS FT_B,
           q.QUEUED_AT
    FROM HITL.REVIEW_QUEUE q
    LEFT JOIN STAGING.IC_LINES a ON q.LINE_A_ID = a.LINE_ID
    LEFT JOIN STAGING.IC_LINES b ON q.LINE_B_ID = b.LINE_ID
    WHERE q.PERIOD = '{period}' AND q.QUEUE_STATUS = 'PENDING'
    ORDER BY q.CONFIDENCE DESC, q.QUEUED_AT
""").to_pandas()

st.metric("Pending review", len(queue))
filter_pair = st.selectbox("Filter by pair", ['(All)'] + sorted(queue['PAIR_ID'].unique().tolist()))
filtered = queue if filter_pair == '(All)' else queue[queue['PAIR_ID'] == filter_pair]

for idx, row in filtered.iterrows():
    with st.expander(f"{row['PAIR_ID']} | {row['PHASE']} | Conf {row['CONFIDENCE']:.2f} | {row['FAILED_CRITERIA']}"):
        col1, col2 = st.columns(2)
        with col1:
            st.markdown("**Side A:**")
            st.write(f"Doc: {row['DOC_A']}\nCcy: {row['CCY_A']}\nAmount: {row['AMT_A']}\nDate: {row['DT_A']}\nText: {row['FT_A']}")
        with col2:
            st.markdown("**Side B:**")
            st.write(f"Doc: {row['DOC_B']}\nAmount: {row['AMT_B']}\nDate: {row['DT_B']}\nText: {row['FT_B']}")
        if row['AI_REASONING']:
            st.info(row['AI_REASONING'])

        notes = st.text_area("Notes", key=f"notes-{row['QUEUE_ID']}")
        c1, c2, c3 = st.columns(3)
        if c1.button("✅ Approve as Match", key=f"app-{row['QUEUE_ID']}"):
            log_decision(session, row['QUEUE_ID'], 'REVIEW_QUEUE', 'APPROVED', notes)
            st.success("Approved")
            st.rerun()
        if c2.button("❌ Reject", key=f"rej-{row['QUEUE_ID']}"):
            log_decision(session, row['QUEUE_ID'], 'REVIEW_QUEUE', 'REJECTED', notes)
            st.warning("Rejected — will move to next phase")
            st.rerun()
        if c3.button("⬆️ Escalate", key=f"esc-{row['QUEUE_ID']}"):
            log_decision(session, row['QUEUE_ID'], 'REVIEW_QUEUE', 'ESCALATED', notes)
            st.info("Escalated")
            st.rerun()
```

## 5.7 Page 4 — Fuzzy Approval Queue

```python
# pages/4_🤝_Fuzzy_Approval_Queue.py
import streamlit as st
from utils.snowpark_client import get_session
from utils.audit import log_decision

st.title("🤝 Fuzzy Match Approval Queue (Phase 3)")
period = st.session_state.get('active_period')
session = get_session()

queue = session.sql(f"""
    SELECT q.QUEUE_ID, q.PAIR_ID, q.AI_CONFIDENCE, q.COSINE_SIMILARITY, q.AMOUNT_PROXIMITY,
           q.DATE_PROXIMITY, q.AI_REASONING,
           a.DOC_NUMBER AS DOC_A, a.DOC_AMOUNT AS AMT_A, a.DOC_DATE AS DT_A, LEFT(a.FREE_TEXT, 80) AS FT_A,
           b.DOC_NUMBER AS DOC_B, b.DOC_AMOUNT AS AMT_B, b.DOC_DATE AS DT_B, LEFT(b.FREE_TEXT, 80) AS FT_B,
           q.QUEUED_AT
    FROM HITL.FUZZY_APPROVAL_QUEUE q
    LEFT JOIN STAGING.IC_LINES a ON q.LINE_A_ID = a.LINE_ID
    LEFT JOIN STAGING.IC_LINES b ON q.LINE_B_ID = b.LINE_ID
    WHERE q.PERIOD = '{period}' AND q.QUEUE_STATUS = 'PENDING'
    ORDER BY q.AI_CONFIDENCE DESC
""").to_pandas()

st.metric("Pending fuzzy approvals", len(queue))

for idx, row in queue.iterrows():
    with st.expander(f"{row['PAIR_ID']} | AI Conf {row['AI_CONFIDENCE']:.2f} | {row['DOC_A']} ↔ {row['DOC_B']}"):
        st.metric("AI Confidence", f"{row['AI_CONFIDENCE']:.2f}")
        c1, c2, c3 = st.columns(3)
        c1.metric("Cosine Sim", f"{row['COSINE_SIMILARITY']:.2f}")
        c2.metric("Amount Prox", f"{row['AMOUNT_PROXIMITY']:.2f}")
        c3.metric("Date Prox", f"{row['DATE_PROXIMITY']:.2f}")

        st.markdown("**AI reasoning:**")
        st.info(row['AI_REASONING'])

        col1, col2 = st.columns(2)
        with col1:
            st.markdown("**Side A:**")
            st.write(f"Doc: {row['DOC_A']}\nAmount: {row['AMT_A']}\nDate: {row['DT_A']}\nText: {row['FT_A']}")
        with col2:
            st.markdown("**Side B:**")
            st.write(f"Doc: {row['DOC_B']}\nAmount: {row['AMT_B']}\nDate: {row['DT_B']}\nText: {row['FT_B']}")

        notes = st.text_area("Notes", key=f"fnotes-{row['QUEUE_ID']}")
        c1, c2, c3 = st.columns(3)
        if c1.button("✅ Approve Match", key=f"fapp-{row['QUEUE_ID']}"):
            log_decision(session, row['QUEUE_ID'], 'FUZZY_APPROVAL_QUEUE', 'APPROVED', notes)
            st.success("Approved"); st.rerun()
        if c2.button("⬇️ Send to Review", key=f"fsr-{row['QUEUE_ID']}"):
            log_decision(session, row['QUEUE_ID'], 'FUZZY_APPROVAL_QUEUE', 'SENT_TO_REVIEW', notes)
            st.warning("Moved to review"); st.rerun()
        if c3.button("❌ Reject — Treat as Residual", key=f"frej-{row['QUEUE_ID']}"):
            log_decision(session, row['QUEUE_ID'], 'FUZZY_APPROVAL_QUEUE', 'REJECTED', notes)
            st.warning("Rejected"); st.rerun()
```

## 5.8 Page 5 — AI Classification Approval Queue

```python
# pages/5_🤖_Classification_Approval_Queue.py
import streamlit as st
import pandas as pd
import json
from utils.snowpark_client import get_session
from utils.audit import log_decision

st.title("🤖 AI Classification Approval Queue (Phase 4)")
period = st.session_state.get('active_period')
session = get_session()

queue = session.sql(f"""
    SELECT QUEUE_ID, PAIR_ID, OS_ACCOUNT, CATEGORY, DOC_CURRENCY,
           VARIANCE_AMOUNT, VARIANCE_AMOUNT_JPY,
           ROOT_CAUSE_CATEGORY, AI_CONFIDENCE, AI_REASONING,
           SUGGESTED_ACTION, PROPOSED_JOURNAL, LLM_MODEL, QUEUED_AT
    FROM HITL.CLASSIFICATION_APPROVAL_QUEUE
    WHERE PERIOD = '{period}' AND QUEUE_STATUS = 'PENDING'
    ORDER BY ABS(VARIANCE_AMOUNT_JPY) DESC
""").to_pandas()

st.metric("Pending classifications", len(queue))

for idx, row in queue.iterrows():
    var_label = f"{row['DOC_CURRENCY']} {row['VARIANCE_AMOUNT']:,.2f}"
    with st.expander(f"{row['PAIR_ID']} | {row['OS_ACCOUNT']} | {row['ROOT_CAUSE_CATEGORY']} | {var_label} | Conf {row['AI_CONFIDENCE']:.2f}"):

        # Variance summary
        c1, c2, c3 = st.columns(3)
        c1.metric("Variance", var_label)
        c2.metric("Root Cause", row['ROOT_CAUSE_CATEGORY'])
        c3.metric("AI Confidence", f"{row['AI_CONFIDENCE']:.2f}")

        st.markdown("**AI reasoning:**")
        st.info(row['AI_REASONING'])

        # Proposed journal entry
        st.markdown("**Proposed Journal Entry:**")
        je = row['PROPOSED_JOURNAL'] if isinstance(row['PROPOSED_JOURNAL'], dict) else json.loads(row['PROPOSED_JOURNAL'])
        st.write(f"Booking entity: **{je['booking_entity']}**")
        st.write(f"Narrative: _{je['narrative']}_")
        je_df = pd.DataFrame(je['lines'])
        st.dataframe(je_df, use_container_width=True, hide_index=True)

        # Edit JE option
        edit_mode = st.checkbox("Edit JE before approving", key=f"edit-{row['QUEUE_ID']}")
        edited_je = je
        if edit_mode:
            st.warning("Editing not yet wired — for v1 use the Snowflake SQL UI to override PROPOSED_JOURNAL.")

        notes = st.text_area("Notes", key=f"cnotes-{row['QUEUE_ID']}")

        c1, c2, c3 = st.columns(3)
        if c1.button("✅ Approve & Export", key=f"capp-{row['QUEUE_ID']}"):
            log_decision(session, row['QUEUE_ID'], 'CLASSIFICATION_APPROVAL_QUEUE', 'APPROVED', notes, edited_je=edited_je)
            session.sql(f"""
                UPDATE HITL.CLASSIFICATION_APPROVAL_QUEUE
                SET EXPORTED_TO_ERP = TRUE
                WHERE QUEUE_ID = '{row['QUEUE_ID']}'
            """).collect()
            st.success("Approved — JE export queued"); st.rerun()
        if c2.button("✏️ Edit & Approve", key=f"cedit-{row['QUEUE_ID']}"):
            log_decision(session, row['QUEUE_ID'], 'CLASSIFICATION_APPROVAL_QUEUE', 'EDITED_AND_APPROVED', notes, edited_je=edited_je)
            st.success("Edited and approved"); st.rerun()
        if c3.button("❌ Reject", key=f"crej-{row['QUEUE_ID']}"):
            log_decision(session, row['QUEUE_ID'], 'CLASSIFICATION_APPROVAL_QUEUE', 'REJECTED', notes)
            st.warning("Rejected — investigate manually"); st.rerun()
```

## 5.9 Utility — `utils/snowpark_client.py`

```python
import streamlit as st
from snowflake.snowpark.context import get_active_session

@st.cache_resource
def get_session():
    """In Streamlit-in-Snowflake, retrieve the active session."""
    return get_active_session()
```

## 5.10 Utility — `utils/audit.py`

```python
import json
from datetime import datetime

def log_decision(session, queue_id, queue_table, decision, notes, edited_je=None):
    """Update the queue row with the reviewer's decision."""
    extra_set = ''
    if edited_je is not None:
        extra_set = f", REVIEWER_EDITED_JOURNAL = PARSE_JSON($${json.dumps(edited_je)}$$)"
    session.sql(f"""
        UPDATE HITL.{queue_table}
        SET QUEUE_STATUS = '{decision}',
            REVIEWED_AT = CURRENT_TIMESTAMP(),
            REVIEWER = CURRENT_USER(),
            REVIEWER_DECISION = '{decision}',
            REVIEWER_NOTES = $${notes or ''}$${extra_set}
        WHERE QUEUE_ID = '{queue_id}'
    """).collect()
```

## 5.11 Utility — `utils/period_picker.py`

```python
import streamlit as st
import pandas as pd
from utils.snowpark_client import get_session

def render_period_picker():
    session = get_session()
    df = session.sql("""
        SELECT DISTINCT PERIOD FROM STAGING.IC_LINES ORDER BY PERIOD DESC
    """).to_pandas()
    if not len(df):
        return st.date_input("Period", value=pd.Timestamp.now().normalize().replace(day=1) - pd.Timedelta(days=1))
    options = df['PERIOD'].dt.strftime('%Y-%m').tolist()
    selected = st.selectbox("Period", options)
    return pd.to_datetime(selected + '-28').to_pydatetime().date().replace(day=28)  # period-end-ish
```

## 5.12 Streamlit-in-Snowflake deployment

```sql
-- Create the Streamlit app
CREATE OR REPLACE STREAMLIT EVIDENT_INTERCO_RECON.PUBLIC.RECON_APP
    ROOT_LOCATION = '@EVIDENT_INTERCO_RECON.PUBLIC.STREAMLIT_STAGE/recon_app'
    MAIN_FILE = 'app.py'
    QUERY_WAREHOUSE = RECON_AI_WH
    TITLE = 'Evident Intercompany Reconciliation';

-- Grant access
GRANT USAGE ON STREAMLIT RECON_APP TO ROLE RECON_CONTROLLER;
GRANT USAGE ON STREAMLIT RECON_APP TO ROLE RECON_VIEWER;
```

Upload code via Snowsight UI or SnowSQL `PUT @STREAMLIT_STAGE/recon_app file://./streamlit_app/*`.

---

# Section 6 — Pipeline Orchestration

## 6.1 Monthly schedule

```
Day 1 of new month — local PICs upload entity-level data
Day 2-3            — file ingestion (SP_RAW_TO_STAGING) per file
Day 4              — Phase 1 + Phase 2 batch run (SP_RUN_PIPELINE_END_TO_END)
Day 5              — Phase 3 + Phase 4 (Cortex)
Day 5-7            — HITL review/approval cycle
Day 8              — Final reconciliation, journal exports to ERP
Day 9              — MISvsMIS regression report
```

Snowflake Tasks chain steps:

```sql
CREATE OR REPLACE TASK INGEST_FILES
    WAREHOUSE = RECON_BATCH_WH
    SCHEDULE = 'USING CRON 0 */2 * * * UTC'
AS
    -- Process any files in stage that are not yet PROCESSED
    DECLARE c CURSOR FOR SELECT FILE_ID FROM RAW.RAW_FILE_REGISTRY WHERE PROCESS_STATUS = 'PENDING';
    FOR f IN c DO CALL STAGING.SP_RAW_TO_STAGING(f.FILE_ID); END FOR;

CREATE OR REPLACE TASK MONTHLY_PIPELINE
    WAREHOUSE = RECON_AI_WH
    AFTER INGEST_FILES
    WHEN SYSTEM$STREAM_HAS_DATA('IC_LINES_NEW_DATA_STREAM')
AS
    CALL PUBLIC.SP_RUN_PIPELINE_END_TO_END(DATE_TRUNC('MONTH', CURRENT_DATE() - 1));

ALTER TASK MONTHLY_PIPELINE RESUME;
ALTER TASK INGEST_FILES RESUME;
```

## 6.2 Re-run on demand

The Streamlit sidebar exposes a "🔄 Run pipeline now" button (see §5.2) that calls `PUBLIC.SP_RUN_PIPELINE_END_TO_END`. Useful for ad-hoc re-runs after data corrections.

---

# Section 7 — Validation Gates

The pipeline must pass these validation gates before going live:

| Gate | Test | Pass criterion |
|------|------|----------------|
| G1: GL mapping completeness | `REF.REF_ENTITY_GL_ACCOUNTS` row count | Exactly 98 rows (matches `Mar'26 accounts` tab) |
| G2: Phase 1 reconciliation | EJP-ECN USD Trade balance | Variance < 1.00 USD |
| G3: Phase 2 line matching | EJP-ECN reconciled-line count | ≥ 428 lines (= 163 USD + 246 CNY perfect + 19 CNY review) |
| G4: Phase 3 fuzzy on EJP-ETCE | JPY 477k variance | Routes to FUZZY_APPROVAL_QUEUE with reasoning indicating forex |
| G5: Phase 4 on EEU-SPIND | USD 99,550 variance | AI proposes journal matching `Entry Summary` example |
| G6: MISvsMIS regression | All 11 pair targets | ≥ 80% of pairs within ±5% of target residual |
| G7: HITL queues populated | All three queues | Each queue contains expected count of items per the test data |
| G8: Streamlit pages render | All 6 pages | Open in browser without errors, queries return < 5s |
| G9: Audit trail | Decisions logged | `REVIEWER`, `REVIEWED_AT`, `REVIEWER_DECISION` populated for any approved item |
| G10: ERP export format | Approved JE export | Format matches SAP/NetSuite import schema (TBD with Lloyd) |

## 7.1 Validation procedure

```sql
CREATE OR REPLACE PROCEDURE PUBLIC.SP_RUN_VALIDATION_SUITE(P_PERIOD DATE)
RETURNS TABLE(GATE VARCHAR, PASSED BOOLEAN, DETAIL VARCHAR)
LANGUAGE SQL
AS
$$
DECLARE
    res RESULTSET DEFAULT (
        SELECT 'G1', COUNT(*) = 98, 'GL accounts loaded: ' || COUNT(*)
        FROM REF.REF_ENTITY_GL_ACCOUNTS
        UNION ALL
        SELECT 'G2',
               (SELECT ABS(VARIANCE) < 1
                FROM RESULTS.PHASE1_BALANCE_RECON
                WHERE PERIOD = :P_PERIOD AND PAIR_ID = 'ECN-EJP'
                  AND ONESTREAM_ACCOUNT = '1122100100' AND DOC_CURRENCY = 'USD'),
               'EJP-ECN USD Trade'
        UNION ALL
        SELECT 'G3',
               (SELECT COUNT(*) >= 428
                FROM RESULTS.PHASE2_LINE_MATCHES
                WHERE PERIOD = :P_PERIOD AND PAIR_ID = 'ECN-EJP'
                  AND MATCH_STATUS IN ('PERFECT','REVIEW')),
               'EJP-ECN matched line count'
        UNION ALL
        SELECT 'G6',
               (SELECT PAIRS_WITHIN_TARGET / NULLIFZERO(PAIRS_TESTED::FLOAT) >= 0.80
                FROM REGRESSION.REGRESSION_RUNS
                WHERE PERIOD = :P_PERIOD ORDER BY RUN_AT DESC LIMIT 1),
               'MISvsMIS regression coverage'
    );
BEGIN
    RETURN TABLE(res);
END;
$$;
```

---

# Section 8 — Implementation Roadmap

## 8.1 12-Week phased rollout

| Week | Phase | Activities | Deliverables |
|------|-------|------------|--------------|
| 1 | Foundation | Snowflake account provisioning. Database, schema, role setup. Stage configuration. | DDL committed to source control. RAW stage operational. |
| 2 | Reference | Load `Mar'26 accounts` to `REF_ENTITY_GL_ACCOUNTS`. Load entities, forex. Validate G1. | All REF tables loaded. G1 passes. |
| 3 | EJP + ECN adapters | Build/deploy `SP_RAW_TO_STAGING` for EJP and ECN bilateral files. | EJP-ECN bilateral file ingests cleanly. |
| 4 | Phase 1 + EJP-ECN E2E | Build `SP_RUN_PHASE1`. Validate G2 (USD Trade reconciles). | Phase 1 stored procedure operational. |
| 5 | Phase 2 Trade | Build `SP_RUN_PHASE2_TRADE`. Validate G3 (≥428 lines reconciled). | Phase 2 SP operational. |
| 6 | Phase 2 Non-Trade | Build `SP_RUN_PHASE2_NONTRADE`. | Non-trade procedure operational. |
| 7 | Phase 3 (Cortex) | Build `SP_RUN_PHASE3` with embeddings + similarity. Test on EJP-ETCE forex case (G4). | Phase 3 operational. |
| 8 | Phase 4 (LLM) | Build `SP_RUN_PHASE4` with claude-3-5-sonnet. Load few-shot examples. Test on EEU-SPIND (G5). | Phase 4 operational. |
| 9 | Streamlit app v1 | Pages 0 (Dashboard), 1 (GL-Level), 2 (Invoice-Level). | App deployed to dev. |
| 10 | Streamlit app v2 | Pages 3, 4, 5 (HITL queues). Full E2E user testing. | App deployed to staging. |
| 11 | Adapter expansion | Build remaining entity adapters (EAS, EKR, EEU, ETCE, ENF, ESG, EIND, EGZ, ECDN, EUSA NetSuite, EMEX, SPIND, Pramana). | All entities ingestable. |
| 12 | UAT + parallel-run | Full April 2026 parallel run vs manual MISvsMIS. Validate G6-G10. | UAT signoff. Production cutover. |

## 8.2 Resource estimate

| Role | Effort |
|------|--------|
| Solution Architect (Joe + Rupesh) | 2 days/week × 12 weeks = 4.8 person-weeks |
| Snowflake Engineer (Hock Ming) | 4 days/week × 12 weeks = 9.6 person-weeks |
| AI Engineer (Cortex prompting + embeddings) | 2 days/week × 6 weeks = 2.4 person-weeks |
| Streamlit Developer | 4 days/week × 4 weeks = 3.2 person-weeks |
| Adapter Developer (entity-specific) | 4 days/week × 6 weeks = 4.8 person-weeks |
| **Total** | **~25 person-weeks** |

Plus Evident-side: Lloyd (process owner, 1 day/week × 12 weeks = 2.4 weeks), Samantha (validation oracle, 0.5 day/week × 12 weeks = 1.2 weeks).

## 8.3 Open questions to resolve with Lloyd

1. ERP export format for approved Phase 4 journals (SAP IDoc? NetSuite SuiteScript? Manual file template?)
2. Authentication model for Streamlit users — Okta/SSO via Snowflake?
3. Period close cutoff — by what date does Day-9 final reconciliation need to be done?
4. Recurring issues table — should the system auto-populate `REF_KNOWN_ISSUES` from approved Phase 4 outcomes?
5. Mexico (EMEX) and Spectral Insights data quality — do they need a different format conversion?
6. Acceptance criteria for production cutover — what's the minimum HITL approval rate before manual fallback can be retired?

---

# Section 9 — Risks & Mitigations

| Risk | Severity | Mitigation |
|------|----------|------------|
| Adapter coverage gaps for non-validated entities | HIGH | Phased rollout — start with EJP/ECN/EAS/ETCE (60% volume), add others incrementally |
| Cortex Complete output not parsing as JSON | MEDIUM | Strict response schema in prompt, retry with stricter wording, fallback to PROPOSE_JE = INVESTIGATE |
| Embedding similarity false positives | MEDIUM | Confidence threshold (≥ 0.80) + HITL approval gate prevents auto-clearing |
| MISvsMIS targets drift over time | MEDIUM | Re-run regression each period; alert if pass rate drops below 80% |
| Excel file format changes from local PICs | HIGH | Validation step in `SP_RAW_TO_STAGING` checks expected schema; fails loudly on schema deviation |
| Forex rate timing differences | MEDIUM | Capture rate at line-level; allow Phase 3 fuzzy match to accept forex-driven amount differences |
| HITL bottleneck during close | MEDIUM | Pre-rank queues by JPY-magnitude; controllers tackle highest-impact items first |
| Cortex region availability | LOW | Verify claude-3-5-sonnet is in the chosen region before commitment; can fall back to mistral-large or llama3.1-405b |

---

# Appendix A — Sample data flows

## A.1 EEU-SPIND USD 99,550 — full pipeline trace

```
1. Bilateral file landed in stage:
   @RAW.RECON_FILE_STAGE/SPIND_EEU_03_2026.xlsx

2. SP_RAW_TO_STAGING dispatches to adapt_spind_bilateral
   → Inserts 1 row into STAGING.IC_LINES:
   {LINE_ID: "SPIND-Master-202603-15", ENTITY_CODE: "SPIND", COUNTERPARTY_CODE: "EEU",
    PAIR_ID: "EEU-SPIND", DOC_NUMBER: "INV-99550", DOC_AMOUNT: 99550, DOC_CURRENCY: "USD"}
   (And no EEU-side row.)

3. SP_RUN_PHASE1:
   → PHASE1_BALANCE_RECON gets:
     {PAIR_ID: "EEU-SPIND", OS_ACCOUNT: "2112100100", DOC_CURRENCY: "USD",
      SIDE_A_BALANCE: 99550, SIDE_B_BALANCE: 0, VARIANCE: 99550, RECON_STATUS: "VARIANCE"}

4. SP_RUN_PHASE2_TRADE:
   → No EEU-side line to match against; no PHASE2 row produced for this case.

5. SP_RUN_PHASE3:
   → No EEU-side line to match against; no PHASE3 row produced.

6. SP_RUN_PHASE4:
   → claude-3-5-sonnet receives prompt with:
     - Variance: USD 99,550
     - Side A (SPIND): 1 line, INV-99550, USD 99,550
     - Side B (EEU): empty
     - Few-shot: similar MISSING_BOOKING examples from Entry Summary
     - Plug accounts: SPIND plug 2177000100, EEU plug 105400
   → Returns JSON: ROOT_CAUSE = MISSING_BOOKING, conf 0.95, propose JE booking on EEU side
   → Inserts into PHASE4_AI_CLASSIFICATIONS and CLASSIFICATION_APPROVAL_QUEUE

7. Controller logs into Streamlit:
   → Page 5 shows the EEU-SPIND classification with the proposed JE
   → Reviews, approves
   → audit.log_decision updates queue status, marks EXPORTED_TO_ERP = TRUE
   → JE export file generated for SAP IDoc (out of scope — wired in Phase 12)

8. Next month:
   → REF_KNOWN_ISSUES updated automatically from this approved case
   → EEU-SPIND USD 99,550 (or similar) becomes a few-shot example for next AI call
```

---

This implementation specification, combined with `matching_process_documentation.md`, provides the complete technical blueprint for the Evident MIS intercompany reconciliation automation. Both documents should be kept in version control alongside the codebase.
