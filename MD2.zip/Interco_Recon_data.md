# Interco Recon — Data Structures and Data Files

**Source:** `Interco_reconciliation_Feb_26__sent_12Mar_.xlsx` + `Interco_reconciliation_Mar_26__sent_14Apr_.xlsx`
**Output:** 16 Snowflake-loadable CSVs in `interco_recon_data/`
**Extractor:** `extract_interco_recon.py` (re-runnable against new periods)
**Purpose:** Loadable data files and DDL guidance for building the Full Interco Recon prototype

---

## Quick Reference — All Files

| File | Snowflake Target | Rows | Key Columns |
|------|------------------|------|-------------|
| `ref_entities.csv` | `REF.REF_ENTITIES` | 19 | ICP_CODE, ENTITY_CODE, TNM_ACTIVE, MIS_ACTIVE, BOOK_CURRENCY, ERP_SOURCE |
| `ref_nature_taxonomy.csv` | `REF.REF_NATURE_TAXONOMY` | 6 | NATURE_CODE |
| `ref_business_units.csv` | `REF.REF_BUSINESS_UNITS` | 2 | BUSINESS_UNIT_CODE |
| `ref_classes.csv` | `REF.REF_CLASSES` | 2 | CLASS_CODE |
| `ref_currencies.csv` | `REF.REF_CURRENCIES` | 16 | CURRENCY_CODE |
| `ref_entity_segment_mapping.csv` | `REF.REF_ENTITY_SEGMENT_MAPPING` | 18 | ICP_CODE, SEGMENT_PRIMARY, SEGMENT_SECONDARY |
| `ref_forex_rates.csv` | `REF.REF_FOREX_RATES` | 64 | PERIOD, CURRENCY_CODE, RATE_TYPE, RATE_TO_JPY |
| `staging_entity_submission_status.csv` | `STAGING.ENTITY_SUBMISSION_STATUS` | 32 | PERIOD, ENTITY_NAME, PIC, STATUS, ADDED_TO_COMPILATION |
| `staging_gl_balances.csv` | `STAGING.GL_BALANCES` | 609 | PERIOD, SAP_GL_ACCOUNT, ICP_CODE, ENTITY_CODE, NATURE, BUSINESS_UNIT, DOC_CURRENCY, LC_AMOUNT, JPY_AMOUNT, PIVOT_ICP |
| `staging_entity_bs_submission.csv` | `STAGING.ENTITY_BS_SUBMISSION` | 114 | PERIOD, ENTITY_NAME, ENTITY_CODE, SAP_GL_ACCOUNT, ICP_CODE |
| `regression_historical_baseline.csv` | `REGRESSION.HISTORICAL_BASELINE` | 249 | (same columns as staging_gl_balances; PERIOD = 2025-10-31) |
| `regression_manual_entry_summary.csv` | `REGRESSION.MANUAL_ENTRY_SUMMARY` | 80 | PERIOD, ENTRY_NO, PAIR_SECTION, SAP_CODE, LC_AMOUNT, JPY_AMOUNT, ENTITY, ICP_NAME, SEGMENT, REMARK, CLASS_TAG |
| `regression_pair_journal_adjustments.csv` | `REGRESSION.PAIR_JOURNAL_ADJUSTMENTS` | 142 | PERIOD, PAIR_TAB, ENTITY, ACCOUNT, LC_AMOUNT, JPY_AMOUNT, ICP_CODE, BUSINESS_UNIT, BS_OR_PL, REMARK |
| `results_manual_aggregate_variance.csv` | `RESULTS.MANUAL_AGGREGATE_VARIANCE` | 119 | PERIOD, SEGMENT, PAIR, JPY_MAIN, JPY_ADJUSTMENT, JPY_RESIDUAL, USD_*, REMARKS |
| `results_manual_currency_pivot.csv` | `RESULTS.MANUAL_CURRENCY_PIVOT` | 86 | PERIOD, PAIR, DOC_CURRENCY, MIS_AMOUNT, TNM_AMOUNT, GRAND_TOTAL |
| `_extraction_log.csv` | (audit only) | 23 | Per-tab extraction stats |

**Period coverage:** Both Feb'26 (2026-02-28) and Mar'26 (2026-03-31) are loaded into a single set of files. Filter by `PERIOD` column to select one month.

---

## Section 1 — Reference Tables (REF)

These tables describe the entity universe, nature taxonomy, currencies, and FX rates. They change rarely and should be loaded once and updated only when the entity list or rate table changes.

### 1.1 `ref_entities.csv` → `REF.REF_ENTITIES` (19 rows)

The canonical entity master. Source: `List of intercompany` tab.

```sql
CREATE TABLE REF.REF_ENTITIES (
    ICP_CODE        VARCHAR(10) PRIMARY KEY,
    ENTITY_CODE     VARCHAR(20) UNIQUE NOT NULL,
    TNM_ACTIVE      BOOLEAN NOT NULL,
    MIS_ACTIVE      BOOLEAN NOT NULL,
    BOOK_CURRENCY   VARCHAR(3) NOT NULL,
    ERP_SOURCE      VARCHAR(20) NOT NULL,        -- SAP / NETSUITE / VISUAL
    REMARKS         VARCHAR(500)
);
```

**Population — 19 entities:**

| ICP_CODE | ENTITY_CODE | TNM | MIS | Book Curr | ERP |
|----------|-------------|-----|-----|-----------|-----|
| 1096 | EJP | ✓ | ✓ | JPY | SAP |
| 1097 | ENF | ✓ | ✓ | JPY | SAP |
| 4048 | ETCE | — | ✓ | EUR | SAP |
| 4001 | EEU | ✓ | ✓ | EUR | SAP |
| 4121 | ESCE | ✓ | ✓ | CZK | SAP |
| 2017 | ECND | ✓ | — | CAD | NETSUITE |
| 2018 | EUSA | ✓ | — | USD | NETSUITE |
| 2017A | MIS-CND | — | ✓ | CAD | SAP |
| 2018A | MIS-USA | — | ✓ | USD | SAP |
| 5044 | ESG | ✓ | ✓ | SGD | SAP |
| 5045 | EKR | ✓ | ✓ | KRW | SAP |
| 5046 | EIND | ✓ | ✓ | INR | SAP |
| 6009 | EAS | ✓ | ✓ | AUD | SAP |
| 5043 | ECN | ✓ | ✓ | CNY | SAP |
| 5020 | EGZ | — | ✓ | CNY | SAP |
| 2017P | PCND | — | ✓ | CAD | NETSUITE (Pramana) |
| 2018P | PUSA | — | ✓ | USD | NETSUITE (Pramana) |
| 5030P | SPIND | — | ✓ | INR | NETSUITE (Pramana) |
| 2062A | EMEX | — | ✓ | MXN | VISUAL |

**Note:** `ERP_SOURCE` is derived heuristically from the ICP code pattern. Codes ending in `P` are Pramana entities (NetSuite). `2017`/`2018` are non-P NetSuite. `2062A` is EMEX which uses Visual. All others are SAP. Verify this with Lloyd before relying on it for routing decisions.

### 1.2 `ref_nature_taxonomy.csv` → `REF.REF_NATURE_TAXONOMY` (6 rows)

The six nature categories used to classify intercompany transactions.

```sql
CREATE TABLE REF.REF_NATURE_TAXONOMY (
    NATURE_CODE     VARCHAR(50) PRIMARY KEY
);
```

**Values:**
- Accrued interest
- Loan (ICL)
- Non-trade
- TP adjustment
- Trade- non EDI
- Trade-EDI

**Note:** The space in "Trade- non EDI" (after the hyphen) is preserved exactly as it appears in the source data. Snowflake JOIN keys must match this whitespace. Consider normalizing on load.

### 1.3 `ref_business_units.csv` → `REF.REF_BUSINESS_UNITS` (2 rows)

```sql
CREATE TABLE REF.REF_BUSINESS_UNITS (
    BUSINESS_UNIT_CODE  VARCHAR(10) PRIMARY KEY
);
```

**Values:** MIS, TNM

### 1.4 `ref_classes.csv` → `REF.REF_CLASSES` (2 rows)

```sql
CREATE TABLE REF.REF_CLASSES (
    CLASS_CODE  VARCHAR(20) PRIMARY KEY
);
```

**Values:** Asset, Liabilities

**Note:** In `Compilation` data, some rows use "Assets" (plural) instead of "Asset" — both refer to the same class. Normalize on load.

### 1.5 `ref_currencies.csv` → `REF.REF_CURRENCIES` (16 rows)

```sql
CREATE TABLE REF.REF_CURRENCIES (
    CURRENCY_CODE  VARCHAR(3) PRIMARY KEY
);
```

**Values:** AUD, CAD, CHF, CNY, CZK, DKK, EUR, GBP, INR, JPY, KRW, MXN, NZD, PLN, SGD, USD

### 1.6 `ref_entity_segment_mapping.csv` → `REF.REF_ENTITY_SEGMENT_MAPPING` (18 rows)

The Lookup tab has a sub-table at the bottom (rows 21-23) that maps each entity's SAP code to its primary and secondary segment participation. This is denormalized from `REF_ENTITIES.TNM_ACTIVE`/`MIS_ACTIVE` but useful for legacy lookups.

```sql
CREATE TABLE REF.REF_ENTITY_SEGMENT_MAPPING (
    ICP_CODE            VARCHAR(10) PRIMARY KEY,
    SEGMENT_PRIMARY     VARCHAR(10),   -- TNM or MIS
    SEGMENT_SECONDARY   VARCHAR(10)    -- second segment, if entity participates in both
);
```

**Source data quirk:** The original spreadsheet has "TMN" (transposed) instead of "TNM" in this section. The extractor normalizes it.

### 1.7 `ref_forex_rates.csv` → `REF.REF_FOREX_RATES` (64 rows)

```sql
CREATE TABLE REF.REF_FOREX_RATES (
    PERIOD          DATE NOT NULL,
    CURRENCY_CODE   VARCHAR(3) NOT NULL,
    RATE_TYPE       VARCHAR(10) NOT NULL,     -- AVERAGE / CLOSING
    RATE_TO_JPY     NUMBER(20, 8) NOT NULL,
    PRIMARY KEY (PERIOD, CURRENCY_CODE, RATE_TYPE)
);
```

Each period contributes 32 rows (16 currencies × 2 rate types). Both Feb'26 and Mar'26 are loaded.

**Rate usage rule (from the Compilation tab logic):**
- Use `CLOSING` rate for Balance Sheet items (Class = Asset or Liabilities)
- Use `AVERAGE` rate for P&L items (none in current data; future support)

JPY's own rate is always 1.0 for both types since JPY is the reporting currency.

---

## Section 2 — Operational Staging Tables (STAGING)

These are populated each period from the reconciliation workbook submitted by entities.

### 2.1 `staging_entity_submission_status.csv` → `STAGING.ENTITY_SUBMISSION_STATUS` (32 rows)

Tracks who submitted what, when. Source: `Status` tab.

```sql
CREATE TABLE STAGING.ENTITY_SUBMISSION_STATUS (
    PERIOD                  DATE NOT NULL,
    ENTITY_NAME             VARCHAR(50) NOT NULL,
    PIC                     VARCHAR(200),       -- Person in charge (often two names)
    STATUS                  VARCHAR(20),        -- "Submitted" in current data
    REMARKS                 VARCHAR(500),
    ADDED_TO_COMPILATION    BOOLEAN,
    PRIMARY KEY (PERIOD, ENTITY_NAME)
);
```

**Coverage:** 16 entities per period (some entities like ESCE and the smaller ones aren't tracked in the Status tab — only the 16 most active).

**Dashboard use:** Show "16 of 19 entities submitted" tile on the home page.

### 2.2 `staging_gl_balances.csv` → `STAGING.GL_BALANCES` (609 rows — THE primary input table)

The master GL balance ledger. Source: `Compilation` tab. Each row is one (entity, ICP, GL account, currency, segment, nature, class) combination.

```sql
CREATE TABLE STAGING.GL_BALANCES (
    PERIOD                      DATE NOT NULL,
    SOURCE_ROW                  NUMBER,         -- traceability back to Compilation row
    SAP_GL_ACCOUNT              VARCHAR(50) NOT NULL,
    SAP_ACCOUNT_DESCRIPTION     VARCHAR(500),
    ICP_CODE                    VARCHAR(10) NOT NULL,
    ICP_NAME                    VARCHAR(20),
    NATURE                      VARCHAR(50),
    BUSINESS_UNIT               VARCHAR(10),    -- MIS / TNM
    CLASS                       VARCHAR(20),    -- Asset / Liabilities
    DOC_CURRENCY                VARCHAR(3),
    DOC_CURR_AMOUNT             NUMBER(20, 2),
    LC_AMOUNT                   NUMBER(20, 2),  -- in entity's local/book currency
    ENTITY_CODE                 VARCHAR(10) NOT NULL,
    ENTITY_NAME                 VARCHAR(20),
    LOCAL_CURRENCY              VARCHAR(3),
    FX_RATE_TO_JPY              NUMBER(20, 8),
    JPY_AMOUNT                  NUMBER(20, 2),
    USD_AMOUNT                  NUMBER(20, 2),
    PIVOT_ICP                   VARCHAR(50),    -- e.g., "EJP vs EIND" — the pair label
    PRIMARY KEY (PERIOD, SOURCE_ROW)
);

-- Clustering for query performance
ALTER TABLE STAGING.GL_BALANCES CLUSTER BY (PERIOD, PIVOT_ICP, BUSINESS_UNIT);
```

**Per-period coverage:**
- Feb'26: 288 rows
- Mar'26: 321 rows

**Segment distribution (Mar'26):**
- MIS Asset: 89 / MIS Liabilities: 112
- TNM Asset: 55 / TNM Liabilities: 69

**Why `PIVOT_ICP` matters:** The Compilation tab pre-computes the pair label in this column (e.g., "EJP vs EIND"). This is the natural pair key for grouping and matches the per-pair tab names like `MIS - EJP vs ETCE`. Use this column directly for pair-level aggregation rather than constructing it from `ENTITY_CODE` + `ICP_NAME`.

**Sample row:**

```
PERIOD: 2026-03-31
SAP_GL_ACCOUNT: 2610300
SAP_ACCOUNT_DESCRIPTION: Creditors Intercompany
ICP_CODE: 1096 (EJP)
NATURE: Trade- non EDI
BUSINESS_UNIT: MIS
CLASS: Liabilities
DOC_CURRENCY: INR
DOC_CURR_AMOUNT: -287442053.78
ENTITY_CODE: 5046 (EIND)
ENTITY_NAME: EIND
JPY_AMOUNT: -491525912
USD_AMOUNT: -3074342.71
PIVOT_ICP: EJP vs EIND
```

This says: EIND's books show ¥-491,525,912 (or INR -287,442,053.78) of trade non-EDI payables to EJP. The matching EJP side would be a Receivable from EIND in EJP's books.

### 2.3 `staging_entity_bs_submission.csv` → `STAGING.ENTITY_BS_SUBMISSION` (114 rows)

Per-entity Balance Sheet template (one tab per entity submission). Only present in Feb'26 workbook (the Mar'26 file consolidates everything into Compilation directly).

```sql
CREATE TABLE STAGING.ENTITY_BS_SUBMISSION (
    PERIOD              DATE NOT NULL,
    SOURCE_ROW          NUMBER,
    ENTITY_NAME         VARCHAR(20),
    ENTITY_CODE         VARCHAR(10),
    SAP_GL_ACCOUNT      VARCHAR(50),
    SAP_DESCRIPTION     VARCHAR(500),
    ICP_CODE            VARCHAR(10),
    ICP_NAME            VARCHAR(20),
    NATURE              VARCHAR(50),
    BUSINESS_UNIT       VARCHAR(10),
    CLASS               VARCHAR(20),
    DOC_CURRENCY        VARCHAR(3),
    DOC_CURR_AMOUNT     NUMBER(20, 2),
    LC_AMOUNT           NUMBER(20, 2)
);
```

**Caveat:** The Feb'26 workbook's Balance sheet tab is mostly placeholder rows for EEU (the one entity whose template was populated). Most rows have `NULL` amounts. This file is included for completeness but doesn't carry transaction signal. The Compilation tab is the authoritative GL balance source.

---

## Section 3 — Regression / Ground Truth Tables (REGRESSION)

These tables hold the manual reconciliation outputs that controllers produced for prior periods. They serve two purposes: (a) regression baselines for validating the pipeline; (b) few-shot examples for the LLM in Phase 4.

### 3.1 `regression_historical_baseline.csv` → `REGRESSION.HISTORICAL_BASELINE` (249 rows)

A historical snapshot from October 2025 (`Compilation Oct'25` tab). Same schema as `STAGING.GL_BALANCES` but represents Oct'25 state.

```sql
CREATE TABLE REGRESSION.HISTORICAL_BASELINE (
    -- Identical schema to STAGING.GL_BALANCES
    PERIOD                      DATE NOT NULL,    -- always 2025-10-31
    SOURCE_ROW                  NUMBER,
    SAP_GL_ACCOUNT              VARCHAR(50),
    SAP_ACCOUNT_DESCRIPTION     VARCHAR(500),
    ICP_CODE                    VARCHAR(10),
    ICP_NAME                    VARCHAR(20),
    NATURE                      VARCHAR(50),
    BUSINESS_UNIT               VARCHAR(10),
    CLASS                       VARCHAR(20),
    DOC_CURRENCY                VARCHAR(3),
    DOC_CURR_AMOUNT             NUMBER(20, 2),
    LC_AMOUNT                   NUMBER(20, 2),
    ENTITY_CODE                 VARCHAR(10),
    ENTITY_NAME                 VARCHAR(20),
    LOCAL_CURRENCY              VARCHAR(3),
    FX_RATE_TO_JPY              NUMBER(20, 8),    -- mostly NULL (Oct'25 rates not preserved)
    JPY_AMOUNT                  NUMBER(20, 2),    -- mostly NULL
    USD_AMOUNT                  NUMBER(20, 2),    -- mostly NULL
    PIVOT_ICP                   VARCHAR(50)
);
```

**Use:** Show "3-period trend" on the Period Comparison page (Oct'25 → Feb'26 → Mar'26). Variance evolution over 6 months tells a more compelling story than a 2-period snapshot.

### 3.2 `regression_manual_entry_summary.csv` → `REGRESSION.MANUAL_ENTRY_SUMMARY` (80 rows)

**The most important file for the AI demo.** Source: `Entry Summary` tab.

Contains the proposed journal entries that controllers actually wrote for each period, grouped by pair section. This is the **gold standard for Phase 4 AI output** — the AI's proposed journals must match the structure and content of these rows.

```sql
CREATE TABLE REGRESSION.MANUAL_ENTRY_SUMMARY (
    PERIOD              DATE NOT NULL,
    ENTRY_NO            NUMBER,             -- 1-based within period
    PAIR_SECTION        VARCHAR(100),       -- e.g., "MIS-EJPvsETCE", "TNM-EUSAvsEEU"
    SOURCE_ROW          NUMBER,
    SAP_CODE            VARCHAR(50),
    SAP_DESCRIPTION     VARCHAR(500),
    HFM_CODE            VARCHAR(50),        -- OneStream consolidation code (often NULL)
    HFM_DESCRIPTION     VARCHAR(500),
    LOCAL_CURRENCY      VARCHAR(3),
    LC_AMOUNT           NUMBER(20, 2),      -- signed; matched DR/CR pairs sum to 0
    JPY_AMOUNT          NUMBER(20, 2),
    ENTITY              VARCHAR(50),        -- booking entity
    ICP_NAME            VARCHAR(50),        -- counterparty name
    ICP_CODE            VARCHAR(20),
    SEGMENT             VARCHAR(10),        -- MIS / TNM (some lines blank or both)
    REMARK              VARCHAR(500),       -- natural-language root cause
    CLASS_TAG           VARCHAR(50)         -- "BS ICP MIS" / "BS ICP TNM" (or NULL for PL lines)
);
```

**Coverage:**
- Feb'26: 45 lines across 13 pair sections
- Mar'26: 35 lines across 11 pair sections

**REMARK column — natural-language root causes (used for LLM training):**

Sample remarks observed:
- "1 invoice not taken from SPIND" → maps to `MISSING_BOOKING`
- "4 invoices not taken" → maps to `MISSING_BOOKING`
- "Due to forex issue" → maps to `FOREX_DIFFERENCE`
- "Forex differences ETCE recorded TP using avg rate, EEU using closing" → maps to `FOREX_DIFFERENCE` (TP-specific)
- "Reverse invoice that..." → maps to `TIMING_DIFFERENCE` or `DATA_ENTRY_ERROR`
- "Eliminating the TP" → maps to `TP_ELIMINATION` (new category)
- "MIS USA has undertaken..." → maps to `RECLASSIFICATION`
- "Reclass between TN..." → maps to `RECLASSIFICATION`
- "Invoices that EUSA AR to ECN" → maps to `MISSING_BOOKING`

**Use these as few-shot examples** in the Phase 4 prompt:
```sql
SELECT PAIR_SECTION, REMARK, SAP_CODE, ENTITY, ICP_NAME, SEGMENT,
       LC_AMOUNT, LOCAL_CURRENCY, JPY_AMOUNT, CLASS_TAG
FROM REGRESSION.MANUAL_ENTRY_SUMMARY
WHERE PERIOD < :p_period
  AND PAIR_SECTION ILIKE :pair_pattern
ORDER BY PERIOD DESC
LIMIT 3;
```

**CLASS_TAG column** is critical for validation: every journal entry's lines should sum to zero per `CLASS_TAG` group. The Entry Summary tab includes a check at the bottom verifying this.

### 3.3 `regression_pair_journal_adjustments.csv` → `REGRESSION.PAIR_JOURNAL_ADJUSTMENTS` (142 rows)

Source: the **Journal Adjustment** sub-section at the top of each per-pair tab (`MIS - EJP vs ETCE`, `TNM-EUSAvsEEU`, etc.).

Contains the same kind of proposed JE lines as `MANUAL_ENTRY_SUMMARY` but extracted from the per-pair worksheets rather than the consolidated Entry Summary tab. This provides cross-validation: the same JE should appear in both places.

```sql
CREATE TABLE REGRESSION.PAIR_JOURNAL_ADJUSTMENTS (
    PERIOD                  DATE NOT NULL,
    PAIR_TAB                VARCHAR(100),   -- the tab name (e.g., "MIS - EJP vs ETCE")
    LINE_NO                 NUMBER,
    SOURCE_ROW              NUMBER,
    ENTITY                  VARCHAR(50),
    ACCOUNT                 VARCHAR(50),    -- SAP or NetSuite account number
    ACCOUNT_DESCRIPTION     VARCHAR(500),
    LOCAL_CURRENCY          VARCHAR(3),
    LC_AMOUNT               NUMBER(20, 2),
    JPY_AMOUNT              NUMBER(20, 2),
    ICP_CODE                VARCHAR(20),
    BUSINESS_UNIT           VARCHAR(10),
    BS_OR_PL                VARCHAR(10),    -- BS or PL
    REMARK                  VARCHAR(500)
);
```

**Coverage:**
- Feb'26: 78 lines across multiple pair tabs
- Mar'26: 64 lines across multiple pair tabs

**Why two tables for similar data?** The Entry Summary tab is the consolidated view used by accounting; the per-pair tabs are the working papers used by controllers. Both should be in sync, but sometimes drift. The prototype can detect drift and flag it.

---

## Section 4 — Aggregate Results Tables (RESULTS)

These tables hold the pre-aggregated views that controllers reference today.

### 4.1 `results_manual_aggregate_variance.csv` → `RESULTS.MANUAL_AGGREGATE_VARIANCE` (119 rows)

Source: `MISvsMIS` and `TNMvsTNM` tabs combined. Each row is one (period, segment, pair) showing main amount, adjustments, and residual.

```sql
CREATE TABLE RESULTS.MANUAL_AGGREGATE_VARIANCE (
    PERIOD              DATE NOT NULL,
    SEGMENT             VARCHAR(10) NOT NULL,    -- MIS / TNM
    PAIR                VARCHAR(50) NOT NULL,    -- e.g., "EEU vs SPIND", "GRAND_TOTAL"
    JPY_MAIN_AMOUNT     NUMBER(20, 2),
    JPY_ADJUSTMENT      NUMBER(20, 2),
    JPY_RESIDUAL        NUMBER(20, 2),
    USD_MAIN_AMOUNT     NUMBER(20, 2),
    USD_ADJUSTMENT      NUMBER(20, 2),
    USD_RESIDUAL        NUMBER(20, 2),
    REMARKS             VARCHAR(500),
    PRIMARY KEY (PERIOD, SEGMENT, PAIR)
);
```

**Semantics:**
- `JPY_MAIN_AMOUNT` — the raw GL-level variance for this pair × segment (from Compilation)
- `JPY_ADJUSTMENT` — pre-approved adjustments that resolve part of the variance
- `JPY_RESIDUAL` — what's left after adjustments (= MAIN + ADJUSTMENT; signs vary)
- Same three columns in USD

**Demo use:** The Dashboard's variance tiles read directly from this table. Pre-aggregated → instant load. The MISvsMIS aggregate page is a paginated grid of these rows filtered to `SEGMENT = 'MIS'`.

**Coverage:**
- Feb'26: 59 rows (28 MIS pairs + 28 TNM pairs + 3 grand totals)
- Mar'26: 60 rows (similar split)

### 4.2 `results_manual_currency_pivot.csv` → `RESULTS.MANUAL_CURRENCY_PIVOT` (86 rows)

Source: `Pivot doc currency` tab (Feb'26 only — Mar'26 doesn't have this view).

Shows pair variance broken down by document currency and segment.

```sql
CREATE TABLE RESULTS.MANUAL_CURRENCY_PIVOT (
    PERIOD          DATE NOT NULL,
    PAIR            VARCHAR(50) NOT NULL,
    DOC_CURRENCY    VARCHAR(20) NOT NULL,   -- can be currency code OR "Liabilities" subtotal
    MIS_AMOUNT      NUMBER(20, 2),
    TNM_AMOUNT      NUMBER(20, 2),
    GRAND_TOTAL     NUMBER(20, 2),
    PRIMARY KEY (PERIOD, PAIR, DOC_CURRENCY)
);
```

**Note:** The source tab is a pivot table. The `DOC_CURRENCY` column sometimes contains "Liabilities" or other subtotal labels — these are roll-up rows. Filter them out for cross-currency analysis, or use them for class-level subtotals.

---

## Section 5 — Loading into Snowflake

### 5.1 One-time setup

```sql
CREATE DATABASE INTERCO_RECON_FULL;
USE DATABASE INTERCO_RECON_FULL;

CREATE SCHEMA REF;
CREATE SCHEMA STAGING;
CREATE SCHEMA RESULTS;
CREATE SCHEMA REGRESSION;
CREATE SCHEMA HITL;
CREATE SCHEMA TRAINING;

-- Run the CREATE TABLE statements above for each schema
```

### 5.2 File format and stage

```sql
CREATE OR REPLACE FILE FORMAT REF.CSV_STANDARD
    TYPE = CSV
    FIELD_OPTIONALLY_ENCLOSED_BY = '"'
    SKIP_HEADER = 1
    EMPTY_FIELD_AS_NULL = TRUE
    NULL_IF = ('', 'NULL', 'null', 'NaN');

CREATE OR REPLACE STAGE REF.INTERCO_RECON_STAGE
    FILE_FORMAT = REF.CSV_STANDARD;
```

### 5.3 Upload CSVs

```bash
# From the directory containing the CSVs:
snowsql -q "PUT file://interco_recon_data/*.csv @REF.INTERCO_RECON_STAGE/ AUTO_COMPRESS=TRUE OVERWRITE=TRUE"
```

### 5.4 COPY INTO each table

```sql
-- Reference tables (load order matters: entities before things that FK to entities)
COPY INTO REF.REF_ENTITIES FROM @REF.INTERCO_RECON_STAGE/ref_entities.csv.gz;
COPY INTO REF.REF_NATURE_TAXONOMY FROM @REF.INTERCO_RECON_STAGE/ref_nature_taxonomy.csv.gz;
COPY INTO REF.REF_BUSINESS_UNITS FROM @REF.INTERCO_RECON_STAGE/ref_business_units.csv.gz;
COPY INTO REF.REF_CLASSES FROM @REF.INTERCO_RECON_STAGE/ref_classes.csv.gz;
COPY INTO REF.REF_CURRENCIES FROM @REF.INTERCO_RECON_STAGE/ref_currencies.csv.gz;
COPY INTO REF.REF_ENTITY_SEGMENT_MAPPING FROM @REF.INTERCO_RECON_STAGE/ref_entity_segment_mapping.csv.gz;
COPY INTO REF.REF_FOREX_RATES FROM @REF.INTERCO_RECON_STAGE/ref_forex_rates.csv.gz;

-- Operational data
COPY INTO STAGING.ENTITY_SUBMISSION_STATUS FROM @REF.INTERCO_RECON_STAGE/staging_entity_submission_status.csv.gz;
COPY INTO STAGING.GL_BALANCES FROM @REF.INTERCO_RECON_STAGE/staging_gl_balances.csv.gz;
COPY INTO STAGING.ENTITY_BS_SUBMISSION FROM @REF.INTERCO_RECON_STAGE/staging_entity_bs_submission.csv.gz;

-- Regression and aggregates
COPY INTO REGRESSION.HISTORICAL_BASELINE FROM @REF.INTERCO_RECON_STAGE/regression_historical_baseline.csv.gz;
COPY INTO REGRESSION.MANUAL_ENTRY_SUMMARY FROM @REF.INTERCO_RECON_STAGE/regression_manual_entry_summary.csv.gz;
COPY INTO REGRESSION.PAIR_JOURNAL_ADJUSTMENTS FROM @REF.INTERCO_RECON_STAGE/regression_pair_journal_adjustments.csv.gz;
COPY INTO RESULTS.MANUAL_AGGREGATE_VARIANCE FROM @REF.INTERCO_RECON_STAGE/results_manual_aggregate_variance.csv.gz;
COPY INTO RESULTS.MANUAL_CURRENCY_PIVOT FROM @REF.INTERCO_RECON_STAGE/results_manual_currency_pivot.csv.gz;
```

### 5.5 Post-load validation queries

```sql
-- Sanity check: row counts
SELECT 'REF_ENTITIES' AS t, COUNT(*) FROM REF.REF_ENTITIES UNION ALL
SELECT 'GL_BALANCES (Mar)', COUNT(*) FROM STAGING.GL_BALANCES WHERE PERIOD='2026-03-31' UNION ALL
SELECT 'GL_BALANCES (Feb)', COUNT(*) FROM STAGING.GL_BALANCES WHERE PERIOD='2026-02-28' UNION ALL
SELECT 'ENTRY_SUMMARY (Mar)', COUNT(*) FROM REGRESSION.MANUAL_ENTRY_SUMMARY WHERE PERIOD='2026-03-31' UNION ALL
SELECT 'ENTRY_SUMMARY (Feb)', COUNT(*) FROM REGRESSION.MANUAL_ENTRY_SUMMARY WHERE PERIOD='2026-02-28';

-- Expected:
-- REF_ENTITIES         19
-- GL_BALANCES (Mar)   321
-- GL_BALANCES (Feb)   288
-- ENTRY_SUMMARY (Mar)  35
-- ENTRY_SUMMARY (Feb)  45

-- Sanity check: Entry Summary should balance to zero per CLASS_TAG group
SELECT PERIOD, CLASS_TAG, SUM(JPY_AMOUNT) AS net
FROM REGRESSION.MANUAL_ENTRY_SUMMARY
WHERE CLASS_TAG IS NOT NULL
GROUP BY PERIOD, CLASS_TAG
HAVING ABS(SUM(JPY_AMOUNT)) > 1
ORDER BY PERIOD, CLASS_TAG;
-- Expected: 0 rows (all JE pairs net to zero)
```

---

## Section 6 — Data Quality Notes & Caveats

Caveats found during extraction that the implementation team needs to handle:

### 6.1 Source data quirks

| Quirk | Where | Handling |
|-------|-------|----------|
| "Trade- non EDI" has a stray space after the hyphen | All natures | Preserved exactly; consider normalizing on load |
| "Asset" vs "Assets" mixed | Class column | Both refer to same class; normalize to "Asset" |
| "TMN" appears in entity segment mapping (typo for TNM) | `Lookup` rows 22-23 | Extractor normalizes to "TNM" |
| "MIS USA" / "MIS-USA" / "MISUSA" used inconsistently | Entity column in Entry Summary | Map all to "MIS-USA" |
| Empty `HFM_CODE` for most Entry Summary rows | `Entry Summary` | OK — HFM/OneStream codes not always assigned |
| Some pair sections in Entry Summary lack a SEGMENT value | e.g., row with `ENTITY = EUSA, ICP = NULL` | Inherit segment from preceding row in same section |
| `ECDN` vs `ECND` — both appear in different files | Various | Canonical form is `ECND` (per `List of intercompany`) |
| Compilation total rows include subtotals/blanks | `Compilation` (974 row span but only ~321 data) | Extractor filters rows missing entity or icp_code |

### 6.2 What's NOT in this extraction

The reconciliation workbook does NOT contain invoice-level transaction detail. That lives in the 53 bilateral entity files (`mar26_files.zip`, processed separately into `IC_LINES_unified.csv` — 7,234 rows). The full prototype combines:
- GL-level data: from this extraction (Compilation tab) → `STAGING.GL_BALANCES`
- Invoice-level data: from bilateral files → `STAGING.IC_LINES`

Both feed the 4-phase pipeline. GL_BALANCES is the Phase 1 source. IC_LINES is the Phase 2 source.

### 6.3 Pair tab sub-sections not extracted

Each per-pair tab (`MIS - EJP vs ETCE`, etc.) has multiple sub-sections:
1. **Journal Adjustment** — ✓ extracted to `regression_pair_journal_adjustments.csv`
2. **Variance Detail** (the GL lines for this pair) — NOT extracted (duplicates Compilation data filtered to this pair)
3. **TP comparison side-by-side** (TNM pairs only) — NOT extracted (one-off reconciliation worksheets)
4. **NetSuite vs SAP detail** (EUSA pairs) — NOT extracted

If the prototype needs these for richer demo content, build dedicated extractors for each pair tab template.

### 6.4 Mar'26 vs Feb'26 differences

Tabs unique to Feb'26 (not in Mar'26):
- `Balance sheet` (per-entity BS submission template)
- `Pivot doc currency` (currency-level variance pivot)
- 5 additional pair tabs (TNM-ECNDvsEEU, TNM-EUSAvsESG, MIS-EJP vs SPIND, MIS-EJPvsMISUSA, MIS-EJP vs EEU)

Tabs unique to Mar'26 (not in Feb'26):
- `MISvsMIS-sam to delete` (cleanup/dev tab — ignored)
- `TNM&MIS-ESGvsEJP (ss)` (snapshot variant)

**Implication:** The set of active pair tabs drifts month-to-month. Don't hardcode the list — discover it from the workbook each period.

### 6.5 Periods

Both files cover the same fiscal year (FY2026) but different months:
- `2026-02-28` — Feb'26 close
- `2026-03-31` — Mar'26 close
- `2025-10-31` — Historical baseline (Oct'25, from `Compilation Oct'25` tab in both files)

---

## Section 7 — Extraction Reproducibility

To re-run the extraction against new period workbooks:

1. Drop new XLSX files in a directory
2. Update the `FILES` dict in `extract_interco_recon.py`:
   ```python
   FILES = {
       '2026-04-30': '/path/to/Interco_reconciliation_Apr_26.xlsx',
       '2026-05-31': '/path/to/Interco_reconciliation_May_26.xlsx',
   }
   ```
3. Run: `python3 extract_interco_recon.py`
4. Output goes to `interco_recon_data/`

The extractor is idempotent — running it twice on the same input produces identical output. Re-running on additional periods produces a single combined CSV with all periods present (one row per period per record).

---

## Section 8 — Cross-Reference to Other Specs

| Document | Purpose | Relationship to this file |
|----------|---------|---------------------------|
| `Evident_Intercompany_Reconciliation.md` | MIS-only deployed system spec | Source data subset of what's loaded here |
| `Full_Interco_Recon.md` | Full-scope prototype spec | Consumes the data files defined here as primary input |
| `transaction_data_catalog.md` | Invoice-level data catalog (mar26_files.zip) | Complements this file; this is GL-level, that is invoice-level |
| `matching_process_documentation.md` | Phase 1-4 logic | Consumes `STAGING.GL_BALANCES` (Phase 1) and `REGRESSION.MANUAL_ENTRY_SUMMARY` (Phase 4 few-shot) |
| `snowflake_streamlit_implementation_spec.md` | Detailed implementation | DDL aligns with what's specified here, but applies to MIS-only |

---

## Appendix A — Sample Queries for the Prototype

### A.1 Top 10 pair variances by absolute JPY (Mar'26)

```sql
SELECT PIVOT_ICP, BUSINESS_UNIT,
       SUM(JPY_AMOUNT) AS net_jpy
FROM STAGING.GL_BALANCES
WHERE PERIOD = '2026-03-31'
GROUP BY PIVOT_ICP, BUSINESS_UNIT
ORDER BY ABS(net_jpy) DESC
LIMIT 10;
```

### A.2 Phase 4 few-shot examples for a specific pair

```sql
SELECT PERIOD, REMARK, SAP_CODE, ENTITY, ICP_NAME, SEGMENT,
       LC_AMOUNT, LOCAL_CURRENCY, JPY_AMOUNT, CLASS_TAG
FROM REGRESSION.MANUAL_ENTRY_SUMMARY
WHERE PAIR_SECTION ILIKE '%EJPvsETCE%'
ORDER BY PERIOD DESC, ENTRY_NO, SOURCE_ROW;
```

### A.3 Entry Summary balance check

```sql
SELECT PERIOD, CLASS_TAG, SUM(JPY_AMOUNT) AS net
FROM REGRESSION.MANUAL_ENTRY_SUMMARY
GROUP BY PERIOD, CLASS_TAG
ORDER BY PERIOD, CLASS_TAG;
-- Each (PERIOD, CLASS_TAG) group should sum to ≈ 0
```

### A.4 Multi-period trend for a hero pair

```sql
SELECT PERIOD, SEGMENT,
       JPY_MAIN_AMOUNT, JPY_ADJUSTMENT, JPY_RESIDUAL, REMARKS
FROM RESULTS.MANUAL_AGGREGATE_VARIANCE
WHERE PAIR = 'EEU vs SPIND'
ORDER BY PERIOD;
```

### A.5 Entity submission status dashboard tile

```sql
SELECT
    COUNT(*) AS total_entities,
    COUNT(CASE WHEN ADDED_TO_COMPILATION THEN 1 END) AS submitted,
    COUNT(*) - COUNT(CASE WHEN ADDED_TO_COMPILATION THEN 1 END) AS pending
FROM STAGING.ENTITY_SUBMISSION_STATUS
WHERE PERIOD = '2026-03-31';
```

---

## Appendix B — Field-Level Mapping (Workbook → CSV)

For implementers tracing data from source to load file:

| Workbook Tab | Workbook Column | CSV File | CSV Column |
|--------------|-----------------|----------|------------|
| Compilation | SAP GL account | staging_gl_balances.csv | SAP_GL_ACCOUNT |
| Compilation | SAP Account Description | staging_gl_balances.csv | SAP_ACCOUNT_DESCRIPTION |
| Compilation | ICP Code | staging_gl_balances.csv | ICP_CODE |
| Compilation | ICP Name | staging_gl_balances.csv | ICP_NAME |
| Compilation | Nature | staging_gl_balances.csv | NATURE |
| Compilation | Business unit | staging_gl_balances.csv | BUSINESS_UNIT |
| Compilation | Class | staging_gl_balances.csv | CLASS |
| Compilation | Doc Curr | staging_gl_balances.csv | DOC_CURRENCY |
| Compilation | Doc Curr Amount | staging_gl_balances.csv | DOC_CURR_AMOUNT |
| Compilation | LC Amount | staging_gl_balances.csv | LC_AMOUNT |
| Compilation | Entity code | staging_gl_balances.csv | ENTITY_CODE |
| Compilation | Entity | staging_gl_balances.csv | ENTITY_NAME |
| Compilation | Local Currency | staging_gl_balances.csv | LOCAL_CURRENCY |
| Compilation | Rate | staging_gl_balances.csv | FX_RATE_TO_JPY |
| Compilation | JPY amount | staging_gl_balances.csv | JPY_AMOUNT |
| Compilation | USD amount | staging_gl_balances.csv | USD_AMOUNT |
| Compilation | Pivot ICP | staging_gl_balances.csv | PIVOT_ICP |
| Entry Summary | Pair section header (e.g., "MIS-EEUvsSPIND") | regression_manual_entry_summary.csv | PAIR_SECTION |
| Entry Summary | SAP Code | regression_manual_entry_summary.csv | SAP_CODE |
| Entry Summary | Description (SAP) | regression_manual_entry_summary.csv | SAP_DESCRIPTION |
| Entry Summary | HFM Code (if any) | regression_manual_entry_summary.csv | HFM_CODE |
| Entry Summary | Description (HFM) | regression_manual_entry_summary.csv | HFM_DESCRIPTION |
| Entry Summary | LC | regression_manual_entry_summary.csv | LOCAL_CURRENCY |
| Entry Summary | LC amount | regression_manual_entry_summary.csv | LC_AMOUNT |
| Entry Summary | JPY amount | regression_manual_entry_summary.csv | JPY_AMOUNT |
| Entry Summary | Entity | regression_manual_entry_summary.csv | ENTITY |
| Entry Summary | ICP | regression_manual_entry_summary.csv | ICP_NAME |
| Entry Summary | ICP Code | regression_manual_entry_summary.csv | ICP_CODE |
| Entry Summary | Segment | regression_manual_entry_summary.csv | SEGMENT |
| Entry Summary | Remark | regression_manual_entry_summary.csv | REMARK |
| Entry Summary | (unnamed col 14) | regression_manual_entry_summary.csv | CLASS_TAG |
| List of intercompany | ICP Code | ref_entities.csv | ICP_CODE |
| List of intercompany | Name | ref_entities.csv | ENTITY_CODE |
| List of intercompany | TNM | ref_entities.csv | TNM_ACTIVE |
| List of intercompany | MIS | ref_entities.csv | MIS_ACTIVE |
| List of intercompany | Book Currency | ref_entities.csv | BOOK_CURRENCY |
| Lookup | Nature | ref_nature_taxonomy.csv | NATURE_CODE |
| Lookup | Business unit | ref_business_units.csv | BUSINESS_UNIT_CODE |
| Lookup | Class | ref_classes.csv | CLASS_CODE |
| Lookup | Denomination | ref_currencies.csv | CURRENCY_CODE |
| Forex | (currency, col 2) | ref_forex_rates.csv | CURRENCY_CODE |
| Forex | AverageRate, ClosingRate | ref_forex_rates.csv | RATE_TO_JPY (one row per rate type) |
| Status | Entity | staging_entity_submission_status.csv | ENTITY_NAME |
| Status | PIC | staging_entity_submission_status.csv | PIC |
| Status | Status | staging_entity_submission_status.csv | STATUS |
| Status | Added into compilation | staging_entity_submission_status.csv | ADDED_TO_COMPILATION |
| MISvsMIS / TNMvsTNM | Row Labels | results_manual_aggregate_variance.csv | PAIR |
| MISvsMIS / TNMvsTNM | MIS/TNM (col 2) | results_manual_aggregate_variance.csv | JPY_MAIN_AMOUNT |
| MISvsMIS / TNMvsTNM | Adjustments (col 3) | results_manual_aggregate_variance.csv | JPY_ADJUSTMENT |
| MISvsMIS / TNMvsTNM | Total (col 4) | results_manual_aggregate_variance.csv | JPY_RESIDUAL |
| MISvsMIS / TNMvsTNM | (parallel USD block) | results_manual_aggregate_variance.csv | USD_MAIN_AMOUNT, USD_ADJUSTMENT, USD_RESIDUAL |
| MISvsMIS / TNMvsTNM | Remarks | results_manual_aggregate_variance.csv | REMARKS |

---

*Document version 1.0 — 2026-05-18*
*Generated from extraction run against Feb'26 + Mar'26 reconciliation workbooks*
