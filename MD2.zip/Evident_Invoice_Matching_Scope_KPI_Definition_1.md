# Evident Use Case: Invoice Matching Pilot
## Scope & KPI Definition Document

**Version:** 1.0
**Date:** April 23, 2026
**Status:** Draft — Pending Client Review

---

## 1. Purpose

This document defines the pilot scope, success criteria, and key performance indicators (KPIs) for the Evident Invoice Matching Pilot. It is intended to align internal delivery teams and the Client on measurable outcomes prior to development kickoff. The pilot will produce a Snowflake-native AI agent layer that automates invoice matching between Singapore and APAC (SAP) corridors, combining deterministic SQL matching, Cortex LLM fuzzy matching, and an agentic reasoning layer — with a human-in-the-loop Streamlit dashboard for exception review.

---

## 2. Pilot Scope

### 2.1 Overview

The POC will be built as a Snowflake-native AI agent layer consisting of three core engines working in sequence: (1) a Deterministic Engine using Snowpark SQL for 1:1 matches on key fields; (2) a Fuzzy Match Engine leveraging Snowflake Cortex LLMs to resolve naming inconsistencies, formatting differences, and partial matches; and (3) an Agentic Reasoning Layer that applies business logic (materiality thresholds, FX rate tolerances, invoice statement reconciliation) and generates a structured Reasoning Trace for every transaction. All components will be developed and run exclusively within Evident's secure non-production Snowflake environment.

### 2.2 In-Scope Capabilities

**Deterministic Matching Engine**
A SQL-based matching engine that resolves exact and near-exact invoice matches on key fields.

- 1:1 matching logic on invoice number, vendor ID, PO number, amount, currency, and date fields
- Compound key matching across multiple field combinations to maximize straight-through match rates
- Configurable match rules defined in collaboration with Evident SMEs during the Diagnostic phase

**Fuzzy Match Engine (Cortex LLM)**
An AI-powered matching layer that resolves inconsistencies the deterministic engine cannot handle.

- Leverage Snowflake Cortex LLM functions to resolve vendor name variations, abbreviations, and formatting differences
- Handle partial matches where key fields are present but inconsistently formatted across Singapore and SAP systems
- Score fuzzy matches with confidence levels to support human review prioritization

**Agentic Reasoning Layer**
A business logic and decision layer that applies domain-specific rules and produces auditable reasoning traces.

- Apply materiality thresholds to determine whether amount differences are within acceptable tolerance
- Integrate FX rate logic to reconcile invoices denominated in different currencies across APAC corridors
- Generate invoice statement reconciliation outputs
- Produce a structured Reasoning Trace for every transaction — documenting the match decision, rules applied, confidence score, and any exceptions flagged

**Human-in-the-Loop Exception Dashboard**
A Streamlit-based review interface for finance team members to review flagged exceptions and AI-suggested matches.

- Surface unmatched and low-confidence matches for human review
- Display AI-suggested matches with reasoning traces for each flagged transaction
- Enable approve / reject / override workflows with audit logging
- Provide summary statistics on match rates, exception volumes, and processing status

### 2.3 Data Sources

| Source | Description | Access Method |
|--------|-------------|---------------|
| Singapore Invoice Data | Invoice records from the Singapore finance system for the defined entity/domain/period | Pre-loaded into Evident's non-production Snowflake environment (Client responsibility) |
| APAC SAP Invoice Data | Corresponding invoice and PO records from the SAP system | Pre-loaded into Evident's non-production Snowflake environment (Client responsibility) |
| FX Rate Reference Data | Foreign exchange rates for currency conversion across APAC corridors | FX protocol designed during Diagnostic phase; reference data loaded into Snowflake |

### 2.4 Use Case Focus

**Pilot Corridor:** Invoice matching between Singapore and APAC (SAP).
Scope will be limited to a defined set of invoices or a specific entity/domain or invoices within a specific period (to be finalized during the Diagnostic phase). Future phases may extend to additional corridors (EMEA, Japan, Americas) pending pilot outcomes.

---

## 3. Success KPIs

### 3.1 Technical Performance KPIs

| KPI | Description | Target |
|-----|-------------|--------|
| Deterministic Match Rate | % of total invoices resolved by the SQL-based deterministic engine without LLM or human intervention | ≥ 70% |
| Fuzzy Match Rate | % of remaining unmatched invoices resolved by the Cortex LLM fuzzy match engine | ≥ 50% of deterministic residuals |
| Overall Straight-Through Match Rate | Combined % of invoices matched automatically (deterministic + fuzzy) without human intervention | ≥ 85% |
| Match Accuracy (Precision) | % of AI-suggested matches confirmed as correct upon human review | ≥ 95% |
| FX Rate Reconciliation Accuracy | % of cross-currency matches where FX conversion produces an amount within agreed tolerance | ≥ 98% |
| Reasoning Trace Completeness | % of processed transactions with a complete, structured Reasoning Trace | 100% |
| Processing Throughput | Time to process the full pilot invoice set through all three engines | TBD (establish baseline during POC) |

### 3.2 User Adoption & Experience KPIs

| KPI | Description | Target |
|-----|-------------|--------|
| Exception Review Completion Rate | % of flagged exceptions reviewed and actioned by the Singapore finance team within the pilot window | ≥ 90% |
| Task Completion Rate | % of exception review tasks completed without IT/analyst escalation | ≥ 80% |
| User Satisfaction Score | Average score from end-of-pilot survey (1–5 scale) | ≥ 4.0 |
| Time-to-Resolution Reduction | Reduction in average time to resolve a flagged invoice exception vs. current manual process | ≥ 40% |

### 3.3 Business Impact KPIs

| KPI | Description | Target |
|-----|-------------|--------|
| Manual Matching Effort Reduction | Estimated reduction in FTE hours spent on manual invoice matching for the pilot corridor | ≥ 50% |
| Exception Volume Reduction | Reduction in the number of invoices requiring manual intervention vs. current state | ≥ 60% |
| False Match Rate | % of auto-matched invoices later identified as incorrect | < 1% |
| ROI Estimation | Projected annualized cost savings from automated matching at pilot corridor scale | Quantified during Phase 4 Handoff |
| Global Scale Framework Readiness | Documented high-level framework for extending the solution to additional corridors | Delivered as Phase 4 artifact |

---

## 4. Pilot Parameters

| Parameter | Detail |
|-----------|--------|
| **Duration** | 7 weeks across 4 phases: Diagnostic (Week 1), POC Build (Weeks 2–5), Agentic Layer (Weeks 4–6), Handoff & Planning (Weeks 6–7) |
| **Use Case Focus** | Invoice matching between Singapore and APAC (SAP); limited to a defined invoice set, entity/domain, or time period finalized during Diagnostic |
| **Environment** | Evident's secure non-production Snowflake environment (Client-provisioned) |
| **Technology Stack** | Snowpark SQL (deterministic engine), Snowflake Cortex LLMs (fuzzy matching), Agentic Reasoning Layer (business logic + trace generation), Streamlit in Snowflake (exception dashboard) |
| **Pilot Users** | Singapore finance team members responsible for invoice reconciliation and exception review |
| **Data Requirements** | Singapore invoice data and APAC SAP invoice/PO data pre-loaded into Snowflake; FX rate reference data; schema documentation for both source systems |
| **Governance** | No access to PII/PHI data; all development within Evident's non-production Snowflake environment; no production deployment in scope |

---

## 5. Out of Scope (Pilot Phase)

- Deployment of the LLM model into a production environment or operationalization of the agent
- Global rollout to other corridors (e.g., EMEA, Japan, Americas)
- Building or maintaining data ingestion pipelines from source ERPs (SAP) into Snowflake
- Source data quality remediation, cleansing, or validation
- Procurement or setup of POC environment (Snowflake, GitHub, or other enterprise technology infrastructure)
- Management of role-based access control (RBAC) or any other internal control in the Snowflake environment
- Design or development of customer-facing applications of AI, GenAI, and/or Agentic prototype/POCs
- LLM model tuning and maintenance of the LLM
- POC data validation and testing of LLM model outcome and accuracy
- Creation of approved POC technical or end-user documentation
- Access to Personal Identifiable Information (PII) / Personal Health Information (PHI) data

---

## 6. Key Assumptions & Risks

| # | Assumption / Risk | Mitigation |
|---|-------------------|------------|
| 1 | Singapore and APAC SAP invoice data is pre-loaded into Evident's non-production Snowflake environment before POC Build begins | Client to confirm data availability and loading during Diagnostic phase (Week 1) |
| 2 | Schema documentation for both Singapore and SAP invoice systems is available for mapping during Diagnostic | Client SMEs engaged during Week 1 for schema mapping and rule definition |
| 3 | FX rate reference data is available or can be sourced for the currencies and time periods in scope | FX protocol designed during Diagnostic phase; reference data format and source confirmed |
| 4 | Evident SMEs are available during Diagnostic (Week 1) to define match rules, materiality thresholds, and FX tolerance criteria | Dedicated SME availability confirmed before kickoff |
| 5 | The pilot invoice set is representative of the broader matching challenge (volume, complexity, exception types) | Scope finalized during Diagnostic to ensure representativeness |
| 6 | Snowflake Cortex LLM functions are available and performant in Evident's Snowflake environment for fuzzy matching | Validate Cortex LLM availability in the non-production account during Diagnostic |
| 7 | Singapore finance team members are available for exception dashboard validation and feedback during Weeks 6–7 | Client to confirm participant availability before Agentic Layer phase begins |
| 8 | Source data quality is sufficient for matching — no remediation of upstream data quality issues is in scope | Explicitly communicated as out of scope; data quality findings documented for Client action |

---

## 7. Next Steps

| # | Action | Owner | Due |
|---|--------|-------|-----|
| 1 | Confirm pilot invoice scope (entity/domain/period) with Evident stakeholders | Client + Delivery Lead | TBD |
| 2 | Validate data availability in Snowflake non-production environment | Client Data Team | TBD |
| 3 | Conduct Diagnostic phase: schema mapping, match rule definition, FX protocol design (Week 1) | Deloitte + Evident SMEs | TBD |
| 4 | Confirm Snowflake Cortex LLM availability in pilot environment | Deloitte | TBD |
| 5 | Finalize KPI targets with Client stakeholders | Strategy Lead | TBD |
| 6 | Identify Singapore finance team participants for exception dashboard validation | Client Champion | TBD |
| 7 | Kick off POC Build (Week 2) | Delivery Team | TBD |

---

*This document is a working draft and subject to revision based on Client input and discovery findings.*
