# Full Intercompany Reconciliation Prototype — Development Runbook

**Audience:** Newly onboarded engineering team (4-5 people)
**Goal:** Build the "art of the possible" demo prototype described in `Full_Interco_Recon.md`
**Timeline:** 4-5 weeks
**Target environment:** A separate Snowflake database (`INTERCO_RECON_FULL`), NOT the client's production MIS system

---

## Section 0 — Orientation (Day 1)

### 0.1 What you're inheriting

You're inheriting a conversational build process that has produced these artifacts. Treat them in different ways:

| Artifact | Treat as | Action |
|----------|----------|--------|
| `Evident_Intercompany_Reconciliation.md` | **Reference** — the as-built MIS system in the client's Snowflake | Study to understand the pattern; DO NOT copy directly |
| `Full_Interco_Recon.md` | **Spec** — your build target | This is what you're building |
| `Interco_Recon_data.md` | **Source-of-truth for data structures** | DDL, field mappings, sample queries all come from here |
| `matching_process_documentation.md` | **Reference** — Phase 1-4 matching logic | Read for understanding; some of it is MIS-specific |
| `snowflake_streamlit_implementation_spec.md` | **Reference** — Streamlit/Snowflake patterns | Code snippets are useful; scope is MIS-only |
| `transaction_data_catalog.md` | **Reference** — invoice-level data sources | Used for the per-entity bilateral file extraction |
| `interco_recon_data/*.csv` (16 files) | **Foundation** — extracted GL-level data | Load these into Snowflake as-is |
| `load_ready/*.csv` (10 files) | **Foundation** — extracted invoice-level data | Load these into Snowflake as `STAGING.IC_LINES` |
| `extract_interco_recon.py` | **Foundation** — workbook extractor | Re-runnable when new periods arrive |
| `extract_load_ready.py` | **Foundation** — bilateral file extractor | Re-runnable when new periods arrive |

### 0.2 What does NOT exist yet (your scope)

- Snowflake database, schemas, tables in `INTERCO_RECON_FULL`
- Stored procedures for all four phases
- Cortex AI prompts (Phase 3 embedding text, Phase 4 nature-specific prompts)
- Orchestrator (`SP_RUN_PIPELINE_END_TO_END`)
- Streamlit UI (13 pages)
- Side-by-side comparison feature (the demo's centerpiece)
- Validation suite (20 gates)

### 0.3 Reading order (Day 1)

Each team member reads in this order, before writing any code:

1. `Full_Interco_Recon.md` Sections 1-2 (the thesis and scope)
2. `Interco_Recon_data.md` Sections 1-4 (what data you have, what schemas you'll build)
3. `Evident_Intercompany_Reconciliation.md` — the entire doc (the reference implementation)
4. `Full_Interco_Recon.md` Sections 5-7 (pipeline phases and demo path)

### 0.4 Team roles (assumed for sequencing)

| Role | Acronym used below | Primary ownership |
|------|----------------------|------------------|
| Data Engineer 1 | DE1 | Extraction, schema, loading |
| Data Engineer 2 | DE2 | Pipeline procedures (Phase 1, Phase 2) |
| ML Engineer | MLE | Cortex AI components (Phase 3, Phase 4) |
| Backend Developer | BE | Orchestration, validation, performance |
| Frontend Developer | FE | Streamlit UI (13 pages) |

Adjust to your actual team. If you have fewer people, sequence the work; if more, parallelize within each section.

### 0.5 Critical environment separation

**The MIS pilot lives in the client's Snowflake account at `INTERCO_RECON` database.** Do not touch it.

This prototype lives in a separate Snowflake account (Deloitte's or Anthropic's, NOT the client's), in database `INTERCO_RECON_FULL`. The client's data is loaded by file upload — there is no live connection to the client's Snowflake from this prototype.

---

## Section 1 — Environment Setup (Day 1-2)

### Step 1.1 — Snowflake access (BE)

**Input:** Snowflake account credentials
**Output:** ACCOUNTADMIN role can create databases

```sql
USE ROLE ACCOUNTADMIN;
CREATE DATABASE INTERCO_RECON_FULL;
USE DATABASE INTERCO_RECON_FULL;

-- Warehouse for compute (right-size after pipeline runs)
CREATE WAREHOUSE IF NOT EXISTS INTERCO_WH
    WAREHOUSE_SIZE = 'MEDIUM'
    AUTO_SUSPEND = 60
    AUTO_RESUME = TRUE
    INITIALLY_SUSPENDED = TRUE;

-- Role for the team
CREATE ROLE IF NOT EXISTS INTERCO_DEV;
GRANT USAGE ON DATABASE INTERCO_RECON_FULL TO ROLE INTERCO_DEV;
GRANT USAGE ON WAREHOUSE INTERCO_WH TO ROLE INTERCO_DEV;
GRANT ROLE INTERCO_DEV TO USER <each_team_member>;
```

**Done when:** Every team member can `USE DATABASE INTERCO_RECON_FULL` and run a `SELECT 1`.

### Step 1.2 — Python environment (DE1, MLE)

**Input:** Python 3.10+ on each dev machine
**Output:** A shared `requirements.txt` and venv

```
# requirements.txt
snowflake-snowpark-python==1.18.0
snowflake-connector-python==3.10.0
streamlit==1.32.0
openpyxl==3.1.2
pandas==2.2.0
numpy==1.26.0
plotly==5.19.0
python-dateutil==2.9.0
```

Install:
```bash
python3 -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
```

**Done when:** Every dev can `python -c "import snowflake.snowpark; import streamlit; import openpyxl"` without error.

### Step 1.3 — Git repo (BE)

**Output:** A single repo with the structure below

```
interco-recon-full/
├── README.md
├── requirements.txt
├── data/                           # gitignored; source XLSX files
├── extracted/                      # gitignored; CSVs output by extractors
├── extractors/
│   ├── extract_interco_recon.py    # copy from prior work
│   └── extract_load_ready.py       # copy from prior work
├── ddl/
│   ├── 00_database.sql
│   ├── 01_ref_schema.sql
│   ├── 02_staging_schema.sql
│   ├── 03_results_schema.sql
│   ├── 04_hitl_schema.sql
│   ├── 05_regression_schema.sql
│   └── 06_views.sql
├── load/
│   ├── stage.sql                   # CREATE STAGE
│   └── copy_into.sql               # COPY INTO statements
├── procedures/
│   ├── sp_run_phase1.sql
│   ├── sp_run_phase2.py            # Snowpark Python proc
│   ├── sp_run_phase3.py
│   ├── sp_run_phase4.py
│   ├── sp_run_pipeline_end_to_end.sql
│   └── sp_run_validation_suite.sql
├── prompts/
│   ├── phase4_trade_edi.txt
│   ├── phase4_trade_non_edi.txt
│   ├── phase4_non_trade.txt
│   ├── phase4_tp_adjustment.txt
│   ├── phase4_loan_icl.txt
│   └── phase4_accrued_interest.txt
├── streamlit_app/
│   ├── app.py
│   ├── pages/
│   └── utils/
└── tests/
    ├── test_phase1.py
    ├── test_phase2.py
    ├── test_validation_gates.py
    └── fixtures/
```

**Done when:** Repo is initialized with this structure (empty placeholders are fine) and pushed to remote.

### Step 1.4 — Source data placement (DE1)

Place these files in `data/` (gitignored):

- `Interco_reconciliation_Feb_26__sent_12Mar_.xlsx`
- `Interco_reconciliation_Mar_26__sent_14Apr_.xlsx`
- `mar26_files.zip` (unzipped to `data/mar26_files/`)

**Done when:** Files are present and the extractors can find them at the paths configured in the scripts.

---

## Section 2 — Data Extraction (Day 2-3)

### Step 2.1 — Extract reconciliation workbooks (DE1)

**Input:** The two XLSX files in `data/`
**Output:** 16 CSVs in `extracted/interco_recon_data/`

```bash
cd extractors
python3 extract_interco_recon.py
# Output to /home/claude/interco_recon_data/ by default — change OUT_DIR if needed
```

**Validation:**
- `staging_gl_balances.csv`: 609 rows
- `regression_manual_entry_summary.csv`: 80 rows
- `regression_pair_journal_adjustments.csv`: 142 rows
- `results_manual_aggregate_variance.csv`: 119 rows
- `ref_entities.csv`: 19 rows
- `ref_forex_rates.csv`: 64 rows
- See `_extraction_log.csv` for full per-tab breakdown

**Done when:** All 16 CSVs exist with the expected row counts (±5%; minor variation is fine if the source files were re-saved).

### Step 2.2 — Extract bilateral files for invoice-level data (DE1)

**Input:** `data/mar26_files/` (unzipped bilateral entity files)
**Output:** Per-entity CSVs in `extracted/load_ready/`, plus `IC_LINES_unified.csv`

```bash
cd extractors
python3 extract_load_ready.py
```

**Validation:**
- `IC_LINES_unified.csv`: ~7,200 rows
- `EJP_lines.csv`: ~2,884 rows
- `ECN_lines.csv`: ~500 rows
- Other entity CSVs as listed in `transaction_data_catalog.md` Section 3

**Done when:** EJP and ECN row counts match prior validated extraction.

### Step 2.3 — Sanity-check the matching reproduces 428 (DE1)

This is the validation that the extraction is correct. Phase 2 matching on EJP-ECN should produce 428 matched lines.

```python
import pandas as pd
ejp = pd.read_csv('extracted/load_ready/EJP_lines.csv')
ecn = pd.read_csv('extracted/load_ready/ECN_lines.csv')

ejp['DOC_CURRENCY'] = ejp['DOC_CURRENCY'].replace('RMB', 'CNY')

ejp_ecn = ejp[(ejp['COUNTERPARTY_CODE'] == 'ECN') & (ejp['NATURE'] == 'Trade')]
ecn_ejp = ecn[(ecn['COUNTERPARTY_CODE'] == 'EJP') & (ecn['NATURE'] == 'Trade')]

ejp_ecn['key'] = ejp_ecn['REFERENCE'].astype(str).str.lstrip('0')
ecn_ejp['key'] = ecn_ejp['DOC_NUMBER'].astype(str).str.lstrip('0')

matched = pd.merge(ejp_ecn, ecn_ejp, on='key', suffixes=('_ejp','_ecn'))
print(f"Matched: {len(matched)} (target: 428)")
```

**Done when:** Output is `Matched: 428`. If different, the extractors have drifted and you need to debug before proceeding.

### Step 2.4 — Known data quality issues to be aware of (DE1)

These are documented in `Interco_Recon_data.md` Section 6.1 and need handling later in load scripts:

- `"Trade- non EDI"` (stray space) — preserve exactly
- `Asset` vs `Assets` mixed — normalize to `Asset`
- `TMN` typo for `TNM` — already handled in extractor
- `RMB` vs `CNY` — same currency, normalize to `CNY` at load
- `ECND` vs `ECDN` — canonical is `ECND`
- `MIS USA` / `MIS-USA` / `MISUSA` — normalize to `MIS-USA`

Add a `data_quality_transforms.sql` script that runs these normalizations on load.

---

## Section 3 — Schema & DDL (Day 3-4)

### Step 3.1 — Create schemas (BE)

`ddl/00_database.sql`:

```sql
USE DATABASE INTERCO_RECON_FULL;
CREATE SCHEMA IF NOT EXISTS REF;
CREATE SCHEMA IF NOT EXISTS STAGING;
CREATE SCHEMA IF NOT EXISTS RESULTS;
CREATE SCHEMA IF NOT EXISTS HITL;
CREATE SCHEMA IF NOT EXISTS REGRESSION;
CREATE SCHEMA IF NOT EXISTS TRAINING;
```

### Step 3.2 — REF schema DDL (DE1)

`ddl/01_ref_schema.sql`:

Copy the DDL from `Interco_Recon_data.md` Section 1 for:
- `REF.REF_ENTITIES`
- `REF.REF_NATURE_TAXONOMY`
- `REF.REF_BUSINESS_UNITS`
- `REF.REF_CLASSES`
- `REF.REF_CURRENCIES`
- `REF.REF_ENTITY_SEGMENT_MAPPING`
- `REF.REF_FOREX_RATES`

Plus a new one (not in prior docs) that you'll populate by hand based on `Full_Interco_Recon.md` Section 2.4:

```sql
CREATE TABLE REF.REF_NATURE_MATCHING_STRATEGY (
    NATURE_CODE                     VARCHAR(50) PRIMARY KEY,
    MATCHING_APPROACH               VARCHAR(50),  -- DETERMINISTIC_INVOICE / AMOUNT_DRIVEN / RULE_BASED
    EXPECTED_MATCH_RATE             NUMBER(5,4),  -- 0.95 etc.
    PHASE4_TRIGGER                  BOOLEAN,      -- True if AI always runs (TP adjustment)
    PHASE2_AMOUNT_WEIGHT            NUMBER(5,4),  -- 0.20 default, 0.40 for non-trade
    PHASE2_INVOICE_WEIGHT           NUMBER(5,4)   -- 0.20 default, 0.00 for non-trade
);

INSERT INTO REF.REF_NATURE_MATCHING_STRATEGY VALUES
    ('Trade-EDI',          'DETERMINISTIC_INVOICE', 0.95, FALSE, 0.20, 0.20),
    ('Trade- non EDI',     'DETERMINISTIC_INVOICE', 0.80, FALSE, 0.20, 0.20),
    ('Non-trade',          'AMOUNT_DRIVEN',         0.60, FALSE, 0.40, 0.00),
    ('TP adjustment',      'RULE_BASED',            0.00, TRUE,  0.00, 0.00),
    ('Loan (ICL)',         'AMOUNT_DRIVEN',         0.90, FALSE, 0.40, 0.00),
    ('Accrued interest',   'AMOUNT_DRIVEN',         0.75, FALSE, 0.30, 0.00);
```

### Step 3.3 — STAGING schema DDL (DE1)

`ddl/02_staging_schema.sql`:

Tables from `Interco_Recon_data.md` Section 2:
- `STAGING.ENTITY_SUBMISSION_STATUS`
- `STAGING.GL_BALANCES`
- `STAGING.ENTITY_BS_SUBMISSION`

Plus `STAGING.IC_LINES` for the invoice-level data. The schema for this table is in `Full_Interco_Recon.md` Section 4.2 (extended) and the column-by-column mapping is in `transaction_data_catalog.md` Section 1.

### Step 3.4 — RESULTS schema DDL (DE1, BE)

`ddl/03_results_schema.sql`:

Tables to create:

```sql
-- Phase 1 output: GL balance check per pair × OS account × currency × segment × nature
CREATE TABLE RESULTS.PHASE1_BALANCE_RECON (
    PERIOD              DATE NOT NULL,
    PAIR_ID             VARCHAR(50) NOT NULL,
    OS_ACCOUNT          VARCHAR(50),
    DOC_CURRENCY        VARCHAR(3),
    SEGMENT             VARCHAR(10),
    NATURE              VARCHAR(50),
    SIDE_A_ENTITY       VARCHAR(10),
    SIDE_B_ENTITY       VARCHAR(10),
    SIDE_A_BALANCE      NUMBER(20,2),
    SIDE_B_BALANCE      NUMBER(20,2),
    VARIANCE            NUMBER(20,2),
    VARIANCE_JPY        NUMBER(20,2),
    RECON_STATUS        VARCHAR(20),  -- GL_BALANCED / GL_NEAR_BALANCED / GL_VARIANCE
    PIPELINE_RUN_AT     TIMESTAMP
);

-- Phase 2 output: deterministic line-level matches
CREATE TABLE RESULTS.PHASE2_LINE_MATCHES (
    MATCH_ID            VARCHAR(50) PRIMARY KEY,
    PERIOD              DATE NOT NULL,
    PAIR_ID             VARCHAR(50) NOT NULL,
    OS_ACCOUNT          VARCHAR(50),
    NATURE              VARCHAR(50),
    LINE_A_ID           VARCHAR(50),
    LINE_B_ID           VARCHAR(50),
    CONFIDENCE          NUMBER(5,4),
    CRITERIA_FAILED     ARRAY,
    MATCH_STATUS        VARCHAR(20),  -- PERFECT / REVIEW / PHASE3
    MATCH_TYPE          VARCHAR(20),  -- ONE_TO_ONE / ONE_TO_MANY / MANY_TO_ONE
    PIPELINE_RUN_AT     TIMESTAMP
);

-- Phase 3 output: Cortex fuzzy matches
CREATE TABLE RESULTS.PHASE3_FUZZY_MATCHES (
    MATCH_ID            VARCHAR(50) PRIMARY KEY,
    PERIOD              DATE NOT NULL,
    PAIR_ID             VARCHAR(50) NOT NULL,
    LINE_A_ID           VARCHAR(50),
    LINE_B_ID           VARCHAR(50),
    COSINE_SIMILARITY   NUMBER(5,4),
    AMOUNT_PROXIMITY    NUMBER(5,4),
    DATE_PROXIMITY      NUMBER(5,4),
    AI_CONFIDENCE       NUMBER(5,4),
    AI_REASONING        VARCHAR(2000),
    MATCH_STATUS        VARCHAR(20),  -- FUZZY_APPROVED / REVIEW / PHASE4
    PIPELINE_RUN_AT     TIMESTAMP
);

-- Phase 4 output: AI classifications + proposed journal entries
CREATE TABLE RESULTS.PHASE4_AI_CLASSIFICATIONS (
    CLASSIFICATION_ID       VARCHAR(50) PRIMARY KEY,
    PERIOD                  DATE NOT NULL,
    PAIR_ID                 VARCHAR(50) NOT NULL,
    OS_ACCOUNT              VARCHAR(50),
    SEGMENT                 VARCHAR(10),
    NATURE                  VARCHAR(50),
    VARIANCE_AMOUNT         NUMBER(20,2),
    VARIANCE_AMOUNT_JPY     NUMBER(20,2),
    DOC_CURRENCY            VARCHAR(3),
    ROOT_CAUSE_CATEGORY     VARCHAR(50),  -- MISSING_BOOKING / FOREX_DIFFERENCE / TIMING_DIFFERENCE
                                          -- / RECLASSIFICATION / DATA_ENTRY_ERROR / TP_ELIMINATION / OTHER
    AI_CONFIDENCE           NUMBER(5,4),
    AI_REASONING            VARCHAR(2000),
    SUGGESTED_ACTION        VARCHAR(20),  -- PROPOSE_JE / INVESTIGATE / IGNORE / ESCALATE
    PROPOSED_JOURNAL        VARIANT,      -- JSON: full proposed JE
    MATCHES_MANUAL_ENTRY    BOOLEAN,      -- Did this match a row in MANUAL_ENTRY_SUMMARY?
    MANUAL_ENTRY_REFERENCE  VARCHAR(200), -- Pointer to the manual ground truth row
    LLM_MODEL               VARCHAR(50),  -- claude-3-5-sonnet
    LLM_PROMPT_VERSION      VARCHAR(20),  -- v1.0 etc.
    PIPELINE_RUN_AT         TIMESTAMP
);
```

### Step 3.5 — HITL schema DDL (DE1)

`ddl/04_hitl_schema.sql`:

```sql
-- Review queue for Phase 2 partial matches and Phase 3 medium-confidence
CREATE TABLE HITL.REVIEW_QUEUE (
    QUEUE_ID            VARCHAR(50) PRIMARY KEY,
    PERIOD              DATE NOT NULL,
    PAIR_ID             VARCHAR(50),
    MATCH_ID            VARCHAR(50),       -- FK to PHASE2_LINE_MATCHES or PHASE3_FUZZY_MATCHES
    SOURCE_PHASE        VARCHAR(10),       -- PHASE2 / PHASE3
    QUEUE_STATUS        VARCHAR(20),       -- PENDING / APPROVED / REJECTED / EDITED
    REVIEWER            VARCHAR(100),
    REVIEWED_AT         TIMESTAMP,
    REVIEWER_DECISION   VARCHAR(500),
    CREATED_AT          TIMESTAMP DEFAULT CURRENT_TIMESTAMP()
);

CREATE TABLE HITL.FUZZY_APPROVAL_QUEUE (
    -- same columns as REVIEW_QUEUE but only Phase 3 high-confidence
    QUEUE_ID            VARCHAR(50) PRIMARY KEY,
    PERIOD              DATE NOT NULL,
    PAIR_ID             VARCHAR(50),
    MATCH_ID            VARCHAR(50),
    QUEUE_STATUS        VARCHAR(20),
    REVIEWER            VARCHAR(100),
    REVIEWED_AT         TIMESTAMP,
    CREATED_AT          TIMESTAMP DEFAULT CURRENT_TIMESTAMP()
);

CREATE TABLE HITL.CLASSIFICATION_APPROVAL_QUEUE (
    QUEUE_ID                    VARCHAR(50) PRIMARY KEY,
    PERIOD                      DATE NOT NULL,
    PAIR_ID                     VARCHAR(50),
    CLASSIFICATION_ID           VARCHAR(50),  -- FK to PHASE4_AI_CLASSIFICATIONS
    ROOT_CAUSE_CATEGORY         VARCHAR(50),
    VARIANCE_AMOUNT             NUMBER(20,2),
    VARIANCE_AMOUNT_JPY         NUMBER(20,2),
    DOC_CURRENCY                VARCHAR(3),
    AI_CONFIDENCE               NUMBER(5,4),
    AI_REASONING                VARCHAR(2000),
    PROPOSED_JOURNAL            VARIANT,
    REVIEWER_EDITED_JOURNAL     VARIANT,      -- if reviewer edited the JE
    QUEUE_STATUS                VARCHAR(30),  -- PENDING / APPROVED / EDITED_AND_APPROVED / REJECTED
    REVIEWER                    VARCHAR(100),
    REVIEWED_AT                 TIMESTAMP,
    CREATED_AT                  TIMESTAMP DEFAULT CURRENT_TIMESTAMP()
);
```

### Step 3.6 — REGRESSION schema DDL (DE1)

`ddl/05_regression_schema.sql`:

Tables from `Interco_Recon_data.md` Section 3:
- `REGRESSION.HISTORICAL_BASELINE`
- `REGRESSION.MANUAL_ENTRY_SUMMARY`
- `REGRESSION.PAIR_JOURNAL_ADJUSTMENTS`

Plus `RESULTS.MANUAL_AGGREGATE_VARIANCE` and `RESULTS.MANUAL_CURRENCY_PIVOT` from Section 4 of the same doc.

### Step 3.7 — Views DDL (BE)

`ddl/06_views.sql`:

```sql
-- Mirrors per-pair tabs in the manual workbook
CREATE OR REPLACE VIEW RESULTS.V_PAIR_RECONCILIATION AS
-- (see snowflake_streamlit_implementation_spec.md for the full WITH-CTE definition)
SELECT ...;

-- Mirrors Entry Summary tab
CREATE OR REPLACE VIEW RESULTS.V_ENTRY_SUMMARY AS
-- Flattens the JE lines from CLASSIFICATION_APPROVAL_QUEUE.PROPOSED_JOURNAL JSON
SELECT ...;

-- Side-by-side view for the demo: AI proposal vs manual entry
CREATE OR REPLACE VIEW RESULTS.V_AI_VS_MANUAL AS
SELECT
    c.PERIOD,
    c.PAIR_ID,
    c.ROOT_CAUSE_CATEGORY      AS AI_ROOT_CAUSE,
    c.PROPOSED_JOURNAL          AS AI_JOURNAL,
    c.AI_CONFIDENCE,
    m.PAIR_SECTION              AS MANUAL_PAIR_SECTION,
    ARRAY_AGG(OBJECT_CONSTRUCT(
        'sap_code', m.SAP_CODE,
        'description', m.SAP_DESCRIPTION,
        'amount', m.LC_AMOUNT,
        'currency', m.LOCAL_CURRENCY,
        'entity', m.ENTITY,
        'remark', m.REMARK
    )) AS MANUAL_JOURNAL
FROM RESULTS.PHASE4_AI_CLASSIFICATIONS c
LEFT JOIN REGRESSION.MANUAL_ENTRY_SUMMARY m
    ON c.PERIOD = m.PERIOD
   AND REPLACE(c.PAIR_ID, '-', '') = REPLACE(m.PAIR_SECTION, '-', '')
GROUP BY 1,2,3,4,5,6;
```

**Done when:** All DDL runs without error in `INTERCO_RECON_FULL`. Verify with `SHOW TABLES IN SCHEMA REF;` etc.

---

## Section 4 — Data Loading (Day 4-5)

### Step 4.1 — Create stage and file format (BE)

`load/stage.sql`:

```sql
CREATE OR REPLACE FILE FORMAT REF.CSV_STANDARD
    TYPE = CSV
    FIELD_OPTIONALLY_ENCLOSED_BY = '"'
    SKIP_HEADER = 1
    EMPTY_FIELD_AS_NULL = TRUE
    NULL_IF = ('', 'NULL', 'null', 'NaN');

CREATE OR REPLACE STAGE REF.INTERCO_STAGE
    FILE_FORMAT = REF.CSV_STANDARD;
```

### Step 4.2 — Upload CSVs (DE1)

```bash
# From the directory containing extracted/interco_recon_data/ and extracted/load_ready/
snowsql -q "PUT file://extracted/interco_recon_data/*.csv @REF.INTERCO_STAGE/recon/ AUTO_COMPRESS=TRUE OVERWRITE=TRUE"
snowsql -q "PUT file://extracted/load_ready/*.csv @REF.INTERCO_STAGE/lines/ AUTO_COMPRESS=TRUE OVERWRITE=TRUE"
```

**Done when:** `LIST @REF.INTERCO_STAGE;` shows all uploaded files.

### Step 4.3 — COPY INTO reference tables (DE1)

`load/copy_into.sql` — see `Interco_Recon_data.md` Section 5.4 for the exact COPY INTO statements.

Order matters: load `REF.REF_ENTITIES` first, since other tables reference entity codes.

### Step 4.4 — COPY INTO staging tables (DE1)

For `STAGING.IC_LINES`, load all per-entity CSVs into the same table:

```sql
COPY INTO STAGING.IC_LINES
FROM @REF.INTERCO_STAGE/lines/IC_LINES_unified.csv.gz
FILE_FORMAT = (FORMAT_NAME = REF.CSV_STANDARD)
ON_ERROR = 'CONTINUE';
```

### Step 4.5 — Currency normalization on load (DE1)

After loading IC_LINES, normalize RMB → CNY:

```sql
UPDATE STAGING.IC_LINES SET DOC_CURRENCY = 'CNY' WHERE DOC_CURRENCY = 'RMB';
UPDATE STAGING.IC_LINES SET LC_CURRENCY = 'CNY' WHERE LC_CURRENCY = 'RMB';
```

Same for GL_BALANCES if needed.

### Step 4.6 — Validation queries (DE1)

Run the validation queries from `Interco_Recon_data.md` Section 5.5. Expected row counts:

- `REF.REF_ENTITIES`: 19
- `STAGING.GL_BALANCES` (Mar): 321
- `STAGING.GL_BALANCES` (Feb): 288
- `STAGING.IC_LINES`: ~7,200
- `REGRESSION.MANUAL_ENTRY_SUMMARY` (Mar): 35
- `REGRESSION.MANUAL_ENTRY_SUMMARY` (Feb): 45

**Done when:** All row counts within ±5% of expected.

---

## Section 5 — Phase 1 Pipeline (Day 5-6)

### Step 5.1 — Implement `SP_RUN_PHASE1` (DE2)

`procedures/sp_run_phase1.sql`. The logic from `Full_Interco_Recon.md` Section 5.1:

```sql
CREATE OR REPLACE PROCEDURE RESULTS.SP_RUN_PHASE1(P_PERIOD DATE)
RETURNS VARIANT
LANGUAGE SQL
AS
$$
DECLARE
    v_run_at TIMESTAMP := CURRENT_TIMESTAMP();
BEGIN
    -- Clear prior run for this period
    DELETE FROM RESULTS.PHASE1_BALANCE_RECON WHERE PERIOD = :P_PERIOD;

    -- Insert new Phase 1 results from Compilation-driven GL_BALANCES
    INSERT INTO RESULTS.PHASE1_BALANCE_RECON
    WITH paired AS (
        SELECT
            g.PERIOD,
            g.PIVOT_ICP                                    AS PAIR_ID,
            g.SAP_GL_ACCOUNT                               AS OS_ACCOUNT,
            g.DOC_CURRENCY,
            g.BUSINESS_UNIT                                AS SEGMENT,
            g.NATURE,
            g.ENTITY_CODE,
            g.LC_AMOUNT,
            g.JPY_AMOUNT
        FROM STAGING.GL_BALANCES g
        WHERE g.PERIOD = :P_PERIOD
    ),
    aggregated AS (
        SELECT
            PERIOD, PAIR_ID, OS_ACCOUNT, DOC_CURRENCY, SEGMENT, NATURE,
            -- For each pair, sum amounts per side (side A vs side B determined by ENTITY_CODE)
            MIN(ENTITY_CODE) AS SIDE_A_ENTITY,
            MAX(ENTITY_CODE) AS SIDE_B_ENTITY,
            SUM(CASE WHEN ENTITY_CODE = MIN(ENTITY_CODE) OVER (PARTITION BY PAIR_ID) THEN LC_AMOUNT ELSE 0 END) AS SIDE_A_BALANCE,
            SUM(CASE WHEN ENTITY_CODE = MAX(ENTITY_CODE) OVER (PARTITION BY PAIR_ID) THEN LC_AMOUNT ELSE 0 END) AS SIDE_B_BALANCE,
            SUM(JPY_AMOUNT) AS COMBINED_JPY
        FROM paired
        GROUP BY 1,2,3,4,5,6
    )
    SELECT
        PERIOD, PAIR_ID, OS_ACCOUNT, DOC_CURRENCY, SEGMENT, NATURE,
        SIDE_A_ENTITY, SIDE_B_ENTITY,
        SIDE_A_BALANCE, SIDE_B_BALANCE,
        SIDE_A_BALANCE + SIDE_B_BALANCE  AS VARIANCE,
        COMBINED_JPY                     AS VARIANCE_JPY,
        CASE
            WHEN ABS(COMBINED_JPY) < 1                                                          THEN 'GL_BALANCED'
            WHEN ABS(COMBINED_JPY) / GREATEST(ABS(SIDE_A_BALANCE), ABS(SIDE_B_BALANCE), 1) < 0.001 THEN 'GL_NEAR_BALANCED'
            ELSE 'GL_VARIANCE'
        END                              AS RECON_STATUS,
        :v_run_at                        AS PIPELINE_RUN_AT
    FROM aggregated;

    RETURN OBJECT_CONSTRUCT(
        'status', 'OK',
        'period', :P_PERIOD,
        'rows_written', (SELECT COUNT(*) FROM RESULTS.PHASE1_BALANCE_RECON WHERE PERIOD = :P_PERIOD)
    );
END;
$$;
```

**Note:** the side-A / side-B logic above is illustrative; you'll need to refine based on actual `PIVOT_ICP` parsing. The `Pivot ICP` column in `STAGING.GL_BALANCES` already gives you the pair label (e.g., "EJP vs EIND") — use that as the join key.

### Step 5.2 — Run Phase 1 (DE2)

```sql
CALL RESULTS.SP_RUN_PHASE1('2026-03-31');
CALL RESULTS.SP_RUN_PHASE1('2026-02-28');
```

### Step 5.3 — Validation (DE2)

```sql
-- Should produce ~35 rows per period
SELECT PERIOD, RECON_STATUS, COUNT(*)
FROM RESULTS.PHASE1_BALANCE_RECON
GROUP BY PERIOD, RECON_STATUS
ORDER BY PERIOD, RECON_STATUS;

-- EJP-ECN should produce: USD balanced (variance ≈ 0), CNY variance
SELECT * FROM RESULTS.PHASE1_BALANCE_RECON
WHERE PERIOD = '2026-03-31'
  AND PAIR_ID ILIKE '%EJP%ECN%'
ORDER BY DOC_CURRENCY;
```

**Done when:** Phase 1 produces results for both periods; EJP-ECN USD is GL_BALANCED.

---

## Section 6 — Phase 2 Pipeline (Day 6-9)

### Step 6.1 — Implement nature-aware Phase 2 (DE2)

This is the centerpiece of the matching pipeline. Reference: `Full_Interco_Recon.md` Section 5.2.

`procedures/sp_run_phase2.py` (Snowpark Python procedure — clearer than SQL for this logic):

The procedure signature:
```python
def run_phase2(session, p_period: str, p_pair_id: str, p_nature: str) -> dict:
    """
    Run Phase 2 deterministic matching for one (pair × nature) combination.
    Looks up matching strategy from REF.REF_NATURE_MATCHING_STRATEGY.
    Writes results to RESULTS.PHASE2_LINE_MATCHES.
    Items with confidence < 0.50 get marked MATCH_STATUS='PHASE3' for the next phase.
    """
```

Implementation outline:

1. Look up the matching strategy from `REF.REF_NATURE_MATCHING_STRATEGY` for this nature
2. Pull both sides of the pair from `STAGING.IC_LINES` filtered to this nature
3. For Trade-EDI / Trade-non EDI: invoice-key-based join with the confidence formula
4. For Non-trade / Loan / Accrued interest: amount-driven join with adjusted weights
5. For TP adjustment: skip Phase 2 entirely; route everything to Phase 4
6. Compute confidence per the formula: `0.30*ICP + 0.20*Invoice + 0.20*Currency + 0.20*Amount + 0.05*Date + 0.05*PostingMonth` (with nature-specific weight overrides)
7. Route by confidence: ≥1.0 = PERFECT, 0.5-1.0 = REVIEW, <0.5 = PHASE3
8. INSERT into `RESULTS.PHASE2_LINE_MATCHES`

**Pseudocode:**

```python
def run_phase2(session, p_period, p_pair_id, p_nature):
    # Get strategy
    strat = session.sql(f"""
        SELECT * FROM REF.REF_NATURE_MATCHING_STRATEGY WHERE NATURE_CODE = '{p_nature}'
    """).collect()[0]

    if strat['MATCHING_APPROACH'] == 'RULE_BASED':
        # TP adjustment: route to Phase 4, don't match
        return {'status': 'SKIPPED', 'reason': 'TP - Phase 4 always'}

    # Pull both sides
    sides = session.sql(f"""
        SELECT * FROM STAGING.IC_LINES
        WHERE PERIOD = '{p_period}'
          AND PAIR_ID = '{p_pair_id}'
          AND NATURE = '{p_nature}'
    """).to_pandas()

    # Split by entity (Side A = first entity in pair, Side B = second)
    entity_a, entity_b = p_pair_id.split('-')
    side_a = sides[sides['ENTITY_CODE'] == entity_a]
    side_b = sides[sides['ENTITY_CODE'] == entity_b]

    # Match logic varies by approach
    if strat['MATCHING_APPROACH'] == 'DETERMINISTIC_INVOICE':
        # Trade-EDI / Trade-non EDI: match on invoice key (REFERENCE or DOC_NUMBER)
        side_a['key'] = side_a['REFERENCE'].astype(str).str.lstrip('0')
        side_b['key'] = side_b['DOC_NUMBER'].astype(str).str.lstrip('0')
        merged = side_a.merge(side_b, on='key', how='outer', suffixes=('_a','_b'), indicator=True)
    elif strat['MATCHING_APPROACH'] == 'AMOUNT_DRIVEN':
        # Non-trade / Loan / Accrued: match on amount + GL account + posting month
        side_a['key'] = side_a.apply(lambda r:
            f"{r['SAP_GL_ACCOUNT']}|{r['POSTING_MONTH']}|{abs(round(r['DOC_AMOUNT'], 0))}", axis=1)
        side_b['key'] = side_b.apply(lambda r:
            f"{r['SAP_GL_ACCOUNT']}|{r['POSTING_MONTH']}|{abs(round(r['DOC_AMOUNT'], 0))}", axis=1)
        merged = side_a.merge(side_b, on='key', how='outer', suffixes=('_a','_b'), indicator=True)

    # Score confidence per the formula (with nature-specific weights)
    inv_w = strat['PHASE2_INVOICE_WEIGHT']
    amt_w = strat['PHASE2_AMOUNT_WEIGHT']
    matched = merged[merged['_merge'] == 'both'].copy()
    matched['confidence'] = (
        0.30 +                                                                     # ICP (both sides exist)
        inv_w * (matched['key_a'] == matched['key_b']) +                          # Invoice match
        0.20 * (matched['DOC_CURRENCY_a'] == matched['DOC_CURRENCY_b']) +         # Currency
        amt_w * (abs(matched['DOC_AMOUNT_a'].abs() - matched['DOC_AMOUNT_b'].abs()) < 0.01) +  # Amount
        0.05 * (matched['DOC_DATE_a'] == matched['DOC_DATE_b']) +                 # Doc date
        0.05 * (matched['POSTING_MONTH_a'] == matched['POSTING_MONTH_b'])         # Posting month
    )

    # Route
    matched['match_status'] = matched['confidence'].apply(
        lambda c: 'PERFECT' if c >= 1.0 else ('REVIEW' if c >= 0.5 else 'PHASE3')
    )

    # Write to PHASE2_LINE_MATCHES
    matched.to_sql(...)
    return {'status': 'OK', 'matched': len(matched)}
```

This is one of the longer pieces of work — budget 2-3 days.

### Step 6.2 — Phase 2 dispatcher (DE2)

`procedures/sp_run_phase2_all_pairs.sql`:

```sql
CREATE OR REPLACE PROCEDURE RESULTS.SP_RUN_PHASE2_ALL_PAIRS(P_PERIOD DATE)
RETURNS VARIANT
LANGUAGE SQL
AS
$$
DECLARE
    v_cursor CURSOR FOR
        SELECT DISTINCT PAIR_ID, NATURE
        FROM RESULTS.PHASE1_BALANCE_RECON
        WHERE PERIOD = :P_PERIOD;
    v_total NUMBER := 0;
BEGIN
    FOR p IN v_cursor DO
        CALL RESULTS.SP_RUN_PHASE2(:P_PERIOD, p.PAIR_ID, p.NATURE);
    END FOR;
    SELECT COUNT(*) INTO :v_total FROM RESULTS.PHASE2_LINE_MATCHES WHERE PERIOD = :P_PERIOD;
    RETURN OBJECT_CONSTRUCT('status', 'OK', 'total_matches', :v_total);
END;
$$;
```

### Step 6.3 — Critical validation: 428 reproduction (DE2)

```sql
-- Phase 2 must reproduce the validated EJP-ECN match (428 lines, 406 PERFECT + 22 REVIEW)
SELECT MATCH_STATUS, COUNT(*)
FROM RESULTS.PHASE2_LINE_MATCHES
WHERE PERIOD = '2026-03-31'
  AND PAIR_ID = 'ECN-EJP'
GROUP BY MATCH_STATUS;
```

Expected:
- PERFECT: 406
- REVIEW: 22
- Total: 428

**Done when:** EJP-ECN reproduces 428. If it doesn't, do not proceed to Phase 3 — debug Phase 2 first.

### Step 6.4 — Phase 2 across all pairs (DE2)

```sql
CALL RESULTS.SP_RUN_PHASE2_ALL_PAIRS('2026-03-31');
SELECT MATCH_STATUS, COUNT(*) FROM RESULTS.PHASE2_LINE_MATCHES
WHERE PERIOD = '2026-03-31' GROUP BY MATCH_STATUS;
```

**Target:** >1,000 total matches across all pairs (validation gate G4 in `Full_Interco_Recon.md`).

---

## Section 7 — Phase 3 Pipeline (Day 9-11)

### Step 7.1 — Set up Cortex embedding (MLE)

Cortex Arctic Embed L v2.0 is available natively in Snowflake. No setup required, just verify:

```sql
SELECT SNOWFLAKE.CORTEX.EMBED_TEXT_1024(
    'snowflake-arctic-embed-l-v2.0',
    'sample invoice text for embedding'
);
```

### Step 7.2 — Embedding text construction (MLE)

For each unmatched line, build a text representation that captures all matching-relevant fields:

```python
def build_embedding_text(line):
    return (
        f"Entity {line['ENTITY_CODE']} pair {line['PAIR_ID']} "
        f"nature {line['NATURE']} account {line['SAP_GL_ACCOUNT']} "
        f"amount {line['DOC_AMOUNT']:.2f} {line['DOC_CURRENCY']} "
        f"date {line['DOC_DATE']} posting {line['POSTING_MONTH']} "
        f"text: {line.get('FREE_TEXT', '')[:200]}"
    )
```

Store embeddings in a new column on `STAGING.IC_LINES`:

```sql
ALTER TABLE STAGING.IC_LINES ADD COLUMN EMBEDDING_VECTOR VECTOR(FLOAT, 1024);

UPDATE STAGING.IC_LINES SET EMBEDDING_VECTOR = SNOWFLAKE.CORTEX.EMBED_TEXT_1024(
    'snowflake-arctic-embed-l-v2.0',
    -- the embedding text constructed above
    CONCAT('Entity ', ENTITY_CODE, ' pair ', PAIR_ID, ' nature ', NATURE,
           ' account ', SAP_GL_ACCOUNT, ' amount ', DOC_AMOUNT::VARCHAR, ' ', DOC_CURRENCY,
           ' date ', DOC_DATE::VARCHAR, ' text: ', LEFT(COALESCE(FREE_TEXT, ''), 200))
) WHERE EMBEDDING_VECTOR IS NULL;
```

### Step 7.3 — Phase 3 procedure (MLE)

For each unmatched line, find the nearest neighbor on the other side of the pair using `VECTOR_COSINE_SIMILARITY`. Combine with amount and date proximity to compute AI confidence.

Reference: `matching_process_documentation.md` Phase 3 section for the scoring formula.

### Step 7.4 — Demo target (MLE)

Phase 3 must produce **≥20 fuzzy matches with AI confidence ≥0.80** across all pairs (validation gate G7).

If Phase 3 produces near-zero matches, the embedding text needs more signal. Try adding `BUSINESS_UNIT`, `REFERENCE`, or `LC_AMOUNT`. Iterate until G7 passes.

---

## Section 8 — Phase 4 Pipeline (Day 11-15) — THE DEMO CENTERPIECE

This is the most important phase. Treat it accordingly.

### Step 8.1 — Nature-specific prompts (MLE)

Six prompts, one per nature. Templates in `prompts/`. Reference: `Full_Interco_Recon.md` Section 5.4.

Example `prompts/phase4_missing_booking.txt`:

```
You are a senior intercompany accountant at Evident. A variance has been identified
that could not be matched at the invoice level.

Variance details:
- Pair: {pair_id}
- Period: {period}
- OS Account: {os_account} ({os_description})
- Segment: {segment}
- Nature: {nature}
- Variance amount: {variance_amount} {doc_currency} ({variance_amount_jpy} JPY)
- Side A entity: {side_a_entity} (balance: {side_a_balance})
- Side B entity: {side_b_entity} (balance: {side_b_balance})

Unmatched lines on each side (top 10 by absolute amount):
{unmatched_lines}

Historical examples of similar variances and their resolutions:
{few_shot_examples}

Your task:
1. Classify the root cause: MISSING_BOOKING, FOREX_DIFFERENCE, TIMING_DIFFERENCE,
   RECLASSIFICATION, DATA_ENTRY_ERROR, TP_ELIMINATION, or OTHER
2. Provide confidence (0.0 to 1.0)
3. Explain reasoning in 2-3 sentences
4. Propose a journal entry to clear the variance, with DR/CR lines

Output STRICT JSON only:
{
  "root_cause_category": "...",
  "confidence": 0.0,
  "reasoning": "...",
  "suggested_action": "PROPOSE_JE",
  "proposed_journal": {
    "booking_entity": "...",
    "icp_code": "...",
    "icp_name": "...",
    "segment": "...",
    "lines": [
      { "dr_or_cr": "DR", "sap_account": "...", "hfm_code": "...",
        "description": "...", "lc_amount": 0.0, "jpy_amount": 0.0,
        "currency": "...", "class_tag": "..." }
    ],
    "narrative": "..."
  }
}
```

### Step 8.2 — Few-shot retriever (MLE)

For each Phase 4 call, retrieve 2-3 similar past examples from `REGRESSION.MANUAL_ENTRY_SUMMARY`:

```sql
SELECT PERIOD, PAIR_SECTION, REMARK,
       OBJECT_AGG(SAP_CODE, OBJECT_CONSTRUCT(
           'description', SAP_DESCRIPTION,
           'lc_amount', LC_AMOUNT,
           'currency', LOCAL_CURRENCY,
           'jpy_amount', JPY_AMOUNT,
           'class_tag', CLASS_TAG
       )) AS journal_lines
FROM REGRESSION.MANUAL_ENTRY_SUMMARY
WHERE PERIOD < :p_period
  AND PAIR_SECTION ILIKE :pair_pattern
GROUP BY PERIOD, PAIR_SECTION, REMARK
ORDER BY PERIOD DESC
LIMIT 3;
```

Pass this as the `{few_shot_examples}` placeholder in the prompt.

### Step 8.3 — Phase 4 procedure (MLE)

`procedures/sp_run_phase4.py`. Logic:

1. For each `GL_VARIANCE` pair × OS_account × nature with unmatched residuals after Phase 2 and Phase 3:
   - Load the appropriate prompt template based on nature
   - Retrieve few-shot examples
   - Call `SNOWFLAKE.CORTEX.COMPLETE('claude-3-5-sonnet', prompt)`
   - Parse the JSON response
   - Compute `MATCHES_MANUAL_ENTRY` by checking if `MANUAL_ENTRY_SUMMARY` has a matching row for this pair/period
   - INSERT into `RESULTS.PHASE4_AI_CLASSIFICATIONS`
   - Queue the result in `HITL.CLASSIFICATION_APPROVAL_QUEUE`

### Step 8.4 — Hero case validation (MLE)

Three hero cases that must produce credible AI output:

**Hero 1: EEU-SPIND missing booking**
```sql
-- Run Phase 4 on the EEU-SPIND USD 99,550 variance
-- Expected: ROOT_CAUSE_CATEGORY = 'MISSING_BOOKING', confidence > 0.85
-- Expected JE: DR Man Inv Adj Merch USD 99,550 / CR Trade A/P OG USD -99,550

SELECT ROOT_CAUSE_CATEGORY, AI_CONFIDENCE, AI_REASONING,
       PROPOSED_JOURNAL:lines AS lines
FROM RESULTS.PHASE4_AI_CLASSIFICATIONS
WHERE PERIOD = '2026-03-31' AND PAIR_ID ILIKE '%EEU%SPIND%';
```

**Hero 2: EJP-ETCE forex difference**
```sql
-- Expected: ROOT_CAUSE_CATEGORY = 'FOREX_DIFFERENCE', confidence > 0.85
-- Expected JE: DR Exchange Loss / CR Total Oth Curr Lia
```

**Hero 3: EUSA-EEU TP elimination**
```sql
-- Expected: ROOT_CAUSE_CATEGORY = 'TP_ELIMINATION', confidence > 0.80
-- Expected JE: DR Interco A/R OEKG USD / CR (Gain)/Loss on Exc USD
```

**Done when:** All three hero cases produce JEs that structurally match the manual `Entry Summary` rows for the same pairs in the same period.

### Step 8.5 — Critical demo validation (MLE + BE)

Run this query — it's the demo's credibility test:

```sql
SELECT
    PAIR_ID,
    ROOT_CAUSE_CATEGORY,
    AI_CONFIDENCE,
    MATCHES_MANUAL_ENTRY,
    MANUAL_ENTRY_REFERENCE
FROM RESULTS.PHASE4_AI_CLASSIFICATIONS
WHERE PERIOD = '2026-03-31'
ORDER BY MATCHES_MANUAL_ENTRY DESC, AI_CONFIDENCE DESC;
```

**Target:** ≥70% of Phase 4 classifications have `MATCHES_MANUAL_ENTRY = TRUE`.

**If the rate is below 50%, stop and fix the prompts before building anything else.** The side-by-side comparison in the demo will destroy the prototype's credibility if the AI is wrong more often than right.

---

## Section 9 — Orchestration (Day 15-16)

### Step 9.1 — End-to-end orchestrator (BE)

`procedures/sp_run_pipeline_end_to_end.sql`. See `snowflake_streamlit_implementation_spec.md` for the MIS version — adapt for multi-segment, multi-nature.

```sql
CREATE OR REPLACE PROCEDURE PUBLIC.SP_RUN_PIPELINE_END_TO_END(P_PERIOD DATE)
RETURNS VARIANT
LANGUAGE SQL
AS
$$
BEGIN
    CALL RESULTS.SP_RUN_PHASE1(:P_PERIOD);
    CALL RESULTS.SP_RUN_PHASE2_ALL_PAIRS(:P_PERIOD);
    CALL RESULTS.SP_RUN_PHASE3_ALL_PAIRS(:P_PERIOD);
    CALL RESULTS.SP_RUN_PHASE4_ALL_RESIDUALS(:P_PERIOD);
    CALL REGRESSION.SP_VALIDATE_REGRESSION(:P_PERIOD);
    RETURN OBJECT_CONSTRUCT('status', 'COMPLETE', 'period', :P_PERIOD);
END;
$$;
```

### Step 9.2 — Validation suite (BE)

`procedures/sp_run_validation_suite.sql`. Implement all 20 gates from `Full_Interco_Recon.md` Section 8.

### Step 9.3 — End-to-end test (BE)

```sql
CALL PUBLIC.SP_RUN_PIPELINE_END_TO_END('2026-03-31');
CALL PUBLIC.SP_RUN_VALIDATION_SUITE('2026-03-31');
```

**Done when:** Pipeline runs without errors and all 20 validation gates pass.

---

## Section 10 — Streamlit UI (Day 16-22)

### Step 10.1 — App scaffold (FE)

See `Full_Interco_Recon.md` Section 7 for the page list. Adapt the structure from `snowflake_streamlit_implementation_spec.md` Section 5.1.

**13 pages to build.** Don't try to build them all at once — prioritize the demo path.

### Step 10.2 — Demo path pages first (FE)

In the order needed for the 12-minute demo (Section 6.2 of `Full_Interco_Recon.md`):

1. Dashboard (0)
2. GL Level Matching (1)
3. Invoice Level Matching (2)
4. Classification Approval Queue (5) — **with side-by-side comparison**
5. Period Comparison (11)
6. Demo Walkthrough (12)

Other pages (Review Queue, Fuzzy Approval, Entry Summary, Pair Reconciliation, Aggregate Variance, Currency Pivot, Entity Submission) can be functional but minimal.

### Step 10.3 — Side-by-side comparison (FE) — the most important UI feature

This is the demo's wow moment. Reference: `Full_Interco_Recon.md` Section 7.1.

```python
# pages/5_Classification_Approval_Queue.py
import streamlit as st

# ... load AI proposal and manual entry from RESULTS.V_AI_VS_MANUAL ...

col1, col2 = st.columns(2)
with col1:
    st.subheader("AI Proposed Journal")
    for line in ai_journal['lines']:
        st.write(f"**{line['sap_account']}** — {line['description']}")
        st.write(f"  {line['dr_or_cr']} {line['lc_amount']:,.2f} {line['currency']}")

with col2:
    st.subheader("Manual Entry Summary (controller's actual JE)")
    for line in manual_journal:
        st.write(f"**{line['sap_code']}** — {line['description']}")
        st.write(f"  {line['lc_amount']:,.2f} {line['local_currency']}")

# Visual diff
diff = compute_diff(ai_journal, manual_journal)
st.write(f"Account match: {'✓' if diff['accounts_match'] else '✗'}")
st.write(f"Amount match: {'✓' if diff['amounts_match'] else '✗'}")
st.write(f"Class tag match: {'✓' if diff['class_tags_match'] else '✗'}")
```

### Step 10.4 — Demo path pre-caching (FE + BE)

Performance constraint: every demo path click must respond in <500ms.

For each page used in the demo path, create a materialized view or pre-aggregated table that the page reads from. Don't compute on click.

---

## Section 11 — Demo Polish (Day 22-25)

### Step 11.1 — Internal dry run (whole team)

Walk the 12-minute demo script from `Full_Interco_Recon.md` Section 6.2 in front of:
- Day 22: Whole engineering team
- Day 23: Engagement partner / senior leadership
- Day 24: Internal Deloitte sales reviewers (if applicable)

Fix what breaks.

### Step 11.2 — Pre-canned demo path (BE)

Ensure these specific records are pre-populated in `RESULTS.PHASE4_AI_CLASSIFICATIONS`:

```sql
-- Must exist for the demo:
SELECT * FROM RESULTS.PHASE4_AI_CLASSIFICATIONS
WHERE PERIOD = '2026-03-31'
  AND (
    PAIR_ID ILIKE '%EEU%SPIND%' OR
    PAIR_ID ILIKE '%EJP%ETCE%' OR
    PAIR_ID ILIKE '%EUSA%EEU%'
  );
-- All three rows should exist with MATCHES_MANUAL_ENTRY = TRUE
```

### Step 11.3 — Smoke test (BE)

Click every link/button on every page. Anything that shows "0 rows" or an error or stack trace must be fixed or hidden.

### Step 11.4 — Demo backup (whole team)

If the live demo breaks:
- Have a recorded video of the demo path on hand
- Have screenshots of each page in a slide deck
- Have the SQL queries that produce each page's data, runnable in the Snowflake worksheet

---

## Section 12 — What This Runbook Does NOT Cover

Be honest with yourselves about gaps:

| Topic | Status | Action |
|-------|--------|--------|
| ERP integration (writing JEs back to SAP/NetSuite) | Out of scope | Phase 4 output is JSON for human review only |
| Real-time data ingestion | Out of scope | Monthly batch from XLSX files |
| User authentication / SSO | Out of scope | Shared demo account |
| Audit log retention | Out of scope | Reset weekly |
| Mobile UI | Out of scope | Desktop only |
| Period close workflow / locking | Out of scope | No period semantics |
| Approver hierarchy | Out of scope | Flat reviewer model |
| Cost & token tracking for Cortex Complete | Important — DO add it | Track per call; reject calls >$0.10 |
| Prompt versioning | Important — DO add it | LLM_PROMPT_VERSION column already in DDL |
| Drift detection between Entry Summary and Pair Journal Adjustments | Nice-to-have | Add as Phase 5 if time permits |
| Handling new entities (EGZ, ENF, ECDN extractor gaps) | Open | See `transaction_data_catalog.md` Section 5 |
| Currency normalization beyond RMB→CNY | Open | Verify EUR/USD/JPY consistency at load |

### What you'll discover that's not in any doc

These will surface during the build. Don't be surprised:

- The `Pivot ICP` column in `STAGING.GL_BALANCES` will have entries like "MIS USA" and "MISUSA" mixed — normalize on load
- Some pair IDs in Compilation don't match any pair tab name — there are pairs without per-pair worksheets
- The `Class_tag` column in Entry Summary is `NULL` for ~30% of rows — handle gracefully
- NetSuite document numbers have a leading prefix ("DEB-", "CRED-", etc.) — strip for matching
- Phase 1 may produce duplicate rows for some pair × nature combinations if the same pair appears in both MIS and TNM. Either dedupe or treat segment as a partition column.

---

## Section 13 — Done Definition

The prototype is "demo-ready" when ALL of the following are true:

1. ✅ All 20 validation gates pass (run `CALL PUBLIC.SP_RUN_VALIDATION_SUITE('2026-03-31')`)
2. ✅ Phase 2 produces ≥1,000 matches across all pairs
3. ✅ Phase 3 produces ≥20 fuzzy matches with AI confidence ≥0.80
4. ✅ Phase 4 produces ≥50 classifications
5. ✅ ≥70% of Phase 4 classifications have `MATCHES_MANUAL_ENTRY = TRUE`
6. ✅ Three hero cases (EEU-SPIND, EJP-ETCE, EUSA-EEU) produce credible AI output
7. ✅ All 13 Streamlit pages load without errors
8. ✅ Side-by-side comparison renders correctly on Page 5
9. ✅ Demo path queries each respond in <500ms
10. ✅ Internal dry run passes without manual intervention

**Anything less is not demo-ready.** Don't show it to a client.

---

## Section 14 — Sequencing & Parallelization

If you have 4-5 engineers, run these tracks in parallel after Week 1:

```
Week 1: Foundation
  [DE1] Extraction + Schema + Loading           ━━━━━━━━━━
  [DE2] Studies MIS pilot, plans Phase 1+2      ━━━
  [MLE] Studies Phase 3+4 docs, plans prompts   ━━━
  [BE]  Studies orchestrator pattern            ━━━
  [FE]  Sets up Streamlit env, studies pages    ━━━

Week 2: Pipeline
  [DE1] Schema refinements, data quality        ━━━
  [DE2] Phase 1 + Phase 2 procedures            ━━━━━━━━━━
  [MLE] Phase 3 embedding + procedure           ━━━━━━━
  [BE]  Orchestrator scaffold                   ━━━━━
  [FE]  Dashboard + GL page                     ━━━━━━━━━━

Week 3: AI + UI
  [DE1] Validation queries                      ━━━
  [DE2] Phase 2 across all pairs                ━━━
  [MLE] Phase 4 prompts + hero validation       ━━━━━━━━━━
  [BE]  Validation suite                        ━━━━━━━━━━
  [FE]  Invoice + Approval Queue + side-by-side ━━━━━━━━━━

Week 4: Polish
  [All] Integration testing, demo dry runs      ━━━━━━━━━━

Week 5 (buffer): Refinement & dry runs          ━━━━━━━━━━
```

---

## Appendix A — Daily Standup Template

Use this to keep the team aligned:

```
Yesterday:
  - What I shipped
  - Validation results (row counts, test outcomes)

Today:
  - What I'm building
  - What I need from others

Blockers:
  - Anything blocking progress

Risks:
  - Discoveries that could affect the demo path or timeline
```

---

## Appendix B — When to Stop and Escalate

Stop work and escalate to engagement leadership if any of these are true at the end of any week:

- Phase 2 isn't reproducing 428 on EJP-ECN (Week 2)
- Phase 3 produces zero fuzzy matches with embedding text construction tuned (Week 3)
- Phase 4 hero cases produce JEs that don't match `MANUAL_ENTRY_SUMMARY` after 3+ prompt iterations (Week 3)
- The 70% `MATCHES_MANUAL_ENTRY` rate hasn't been reached by end of Week 4

These are demo-killers. Don't keep building UI on top of a broken pipeline.

---

*Document version 1.0 — 2026-05-18*
*Owners: [PM Name] (overall), [Team lead names] (per section)*
