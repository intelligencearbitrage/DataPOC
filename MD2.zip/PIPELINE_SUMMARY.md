# Sybase-to-Snowflake Converter — Pipeline Summary

## Overview

The Sybase-to-Snowflake converter is an 11-step pipeline that converts Sybase ASE/IQ SQL scripts to Snowflake-native SQL. It handles DDL, DML, stored procedures, and ETL orchestration logic. The pipeline is designed to run mostly on a local machine, with Snowflake access required only for late-stage validation.

## Pipeline Steps

| Step | Description | Execution Environment | HITL Checkpoint |
|------|-------------|----------------------|-----------------|
| 1 | **Parse source SQL files** — Read .sql files, split on GO batch separators, classify each block (DDL/DML/procedural), detect Sybase-specific constructs | Local | — |
| 2 | **Build dependency graph** — Extract object references, build directed dependency graph (staging → dims → facts → aggs → views), flag circular deps | Local | — |
| 3 | **Approve inventory and dependencies** — Present object inventory, dependency graph, and proposed conversion order for review | Local | 🟡 MEDIUM |
| 4 | **Classify conversion complexity** — Score each object across 7 dimensions, assign tier (Simple / Medium / Complex) | Local | — |
| 5 | **Generate Snowflake SQL** — Convert each object using documented type mappings, annotate every non-trivial conversion inline, insert TODO blocks for unsupported constructs | Local | — |
| 6 | **Review converted SQL** — Present converted SQL by complexity tier: bulk approval for Simple, detailed review for Medium/Complex with side-by-side comparison | Local | 🔴 HIGH |
| 7 | **Score conversion fidelity** — Generate synthetic seed data, execute converted + reference SQL against Snowflake, compare on 5 weighted dimensions (row count, columns, NULLs, aggregates, spot check) | **Snowflake** | — |
| 8 | **Approve fidelity results** — Present pass/retry/quarantine counts, average fidelity scores, quarantine inventory | Local | 🟡 MEDIUM |
| 9 | **Generate test harness** — Create seed data, DDL tests, DML tests, and reconciliation queries. Optionally execute against Snowflake | Local (generate) / **Snowflake** (execute) | — |
| 10 | **Approve and execute test plan** — Present test plan for review; on approval, execute test suite against Snowflake | Local (review) / **Snowflake** (execute) | 🟡 MEDIUM |
| 11 | **Generate conversion report and finalize** — Produce executive summary, object inventory, conversion decisions log, quarantine inventory, test results, known limitations | Local | — |

## Execution Environment Summary

- **Steps 1–6, 8, 11** run entirely on the local machine (file parsing, text transformation, user review)
- **Step 7** requires a Snowflake connection (executes SQL against a warehouse to validate fidelity)
- **Steps 9–10** generate artifacts locally but require Snowflake for test execution
- Approximately **80% of the pipeline** can complete without a Snowflake connection

## Fidelity Scoring Model (Step 7)

| Component | Weight | Pass Criteria |
|-----------|--------|---------------|
| Row count match | 30% | Exact match |
| Column match | 15% | All columns present (case-insensitive) |
| NULL profile | 15% | NULL rates within ±2% per column |
| Aggregate match | 25% | SUM/COUNT/MAX/MIN exact match |
| Spot check | 15% | 10 sampled rows match exactly |

Objects scoring below the fidelity threshold (default 0.85) are retried up to 2 times with structured diagnosis before being quarantined for manual review.

## Key Artifacts Produced

| Artifact | Format | Purpose |
|----------|--------|---------|
| Converted SQL files (ddl_*, dml_*, proc_*) | SQL | Snowflake-native SQL, one file per object |
| run_all.sql | SQL | Master execution script in dependency order |
| Test suite (seed, DDL, DML, reconciliation) | SQL | Validation harness with synthetic data |
| conversion_report.md | Markdown | Executive summary with full audit trail |
| run_log.json | JSON | Pipeline state for resume-from-failure |

## Reference Materials

| Reference | Content |
|-----------|---------|
| sybase-to-snowflake-type-map.md | Data type mappings, function translations, pattern conversions |
| complexity-scoring-rubric.md | 7-dimension scoring model with tier thresholds |
| conversion-standards.md | Handoff JSON schemas, TODO block templates, audit log formats |
