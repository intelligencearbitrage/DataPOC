# Agile Capacity Pilot — Discovery & Scoping Workshop
**Date:** April 9, 2026 | **Duration:** 3 Hours | **Facilitator:** Deloitte
**Confidential — For Discussion Purposes Only**

---

## Workshop Objectives

By the end of this session, we will have:

1. Confirmed and bounded the pilot scope
2. Answered the critical open questions needed to begin Phase 1
3. Defined success criteria and pilot audience
4. Identified all stakeholders needed during the pilot phases
5. Agreed on Week 0 pre-kick-off requirements and owners

---

## Agenda

| Time | Block | Owner |
|------|-------|-------|
| 0:00–0:15 | Welcome, introductions, objectives | Deloitte |
| 0:15–0:45 | Block 1: Scope Confirmation | All |
| 0:45–1:15 | Block 2: No-Show Model & Epic Clarity Data | IS / Analytics |
| 1:15–1:45 | Block 3: Operations & Capacity Management Workflow | Capacity Mgmt |
| 1:45–2:10 | Block 4: Governance, PHI & Clinical Oversight | IS / Clinical |
| 2:10–2:40 | Block 5: Success Criteria & Pilot Design | All |
| 2:40–3:00 | Block 6: Week 0 Checklist & Next Steps | All |

---

## Block 1: Scope Confirmation (30 min)

### Purpose
Ensure everyone in the room has a shared understanding of what we are — and are not — building across the 8 weeks.

### Framing Statement *(Read Aloud)*
> *"This engagement has four phases. Phase 1 (Weeks 1–2) is Discovery & Design — we lock scope, document requirements, and define architecture. Phase 2 (Weeks 3–5) is Build & Integration — we replicate the required Epic Clarity tables into Snowflake and build the no-show scoring and recommendation layer. Phase 3 (Weeks 6–7) is Pilot Deployment — a small group of Capacity Management users work with real recommendations and we track outcomes. Phase 4 (Week 8) is Iterate & Scale Planning — we incorporate feedback, produce a runbook, and define the scaling roadmap. Epic Clarity replication runs concurrently across the full engagement. The Capacity Management team will review recommendations and make slot adjustments manually in Epic during the pilot — the system does not write back to Epic."*

### Discussion Questions

**1.1** Does everyone in the room agree with this framing? Are there any expectations that need to be reset before we proceed?

**1.2** Confirm pilot scope: **ambulatory pediatric medicine and surgery, starting with surgical return visits.** Is this agreed by all stakeholders present?

**1.3** Confirm: the pilot covers **return patient slots only** (not new patient slots). Is that agreed by operations?

**1.4** Are there any blackout periods, organizational events, or resource constraints across the 8-week window that could affect delivery or stakeholder availability?

**1.5** What is the anticipated start date for Week 1?

---

## Block 2: No-Show Model & Epic Clarity Data (30 min)

### Purpose
Understand the existing no-show model and confirm Epic Clarity data availability. These answers directly determine the Phase 2 build approach.

### No-Show Model Questions

**2.1** Where does the no-show probability model currently live?
- ☐ Built into Epic (Epic's native predictive model — score is a column in Clarity)
- ☐ Separate platform (Azure ML, Python/R, other)
- ☐ SQL / rules-based logic in an existing data warehouse
- ☐ Other: _______________

> *This is the most critical answer of the day. The Phase 2 build path changes materially depending on the answer. Per meeting minutes, the model is built in Microsoft Azure and feeds Epic with encounter-level scores (1–100) and risk tiers — confirm this is current.*

**2.2** What does the model output?
- ☐ Probability score (0–1 or 1–100)
- ☐ Risk tier only (High / Medium / Low)
- ☐ Both score and tier
- ☐ Other: _______________

**2.3** Is the model currently running in production and feeding Epic today?

**2.4** Who owns the model — and who can provide access, documentation, and technical details before Phase 1 ends? *(Name + contact)*

**2.5** Per the agreed approach, Snowflake will consume model outputs — not retrain or rebuild the model. Is this confirmed by all stakeholders?

**2.6** What features does the model use? *(Confirm all that apply)*
- ☐ Prior no-show history
- ☐ Lead time (days between booking and appointment)
- ☐ Day of week / time of day
- ☐ Specialty / department
- ☐ Insurance / payer
- ☐ Distance to clinic
- ☐ Demographics (age, etc.)
- ☐ Other: _______________

**2.7** Has model accuracy been formally validated? Is there a known AUC, precision, or recall at the current risk thresholds?

### Epic Clarity Data Questions

**2.8** Is the data scope **Clarity** (reporting layer), **Caboodle** (data warehouse), or both? Has this been confirmed with the Epic team?

**2.9** How many years of appointment history are available in Clarity? *(Minimum 12 months required; 24 months preferred for seasonal patterns)*

**2.10** Is no-show status reliably recorded in Clarity? What statuses exist — No Show, Cancelled, Left Without Being Seen? Are cancellations clearly distinguished from no-shows?

**2.11** Is new vs. return visit type a reliable, consistently populated field in Clarity?

**2.12** Who is the Clarity DBA or reporting analyst who can confirm table availability and column population rates before Phase 1 ends? *(Name + contact)*

**2.13** Confirm availability of the following Epic Clarity tables: *(IS / Clarity DBA to validate)*

| # | Table | Purpose | Available? | Notes |
|---|-------|---------|------------|-------|
| 1 | PAT_ENC | Core appointment record — patient, provider, department, date, appointment type | ☐ | |
| 2 | PAT_ENC_2 | Extended appointment attributes — slot duration, visit type flags | ☐ | |
| 3 | ZC_APPT_STATUS | Status code lookup — no-show, completed, cancelled, left without seen | ☐ | |
| 4 | CLARITY_DEP | Department / specialty lookup | ☐ | |
| 5 | CLARITY_SER | Provider lookup | ☐ | |
| 6 | SCHED_APPT | Scheduled slot details — capacity, overbooking flags | ☐ | |
| 7 | PATIENT | Demographics — age, distance proxy (model features) | ☐ | |
| 8 | PAT_ADDRESS | Patient address for distance-to-clinic features | ☐ | |
| 9 | COVERAGE | Insurance / payer — no-show predictor | ☐ | |
| 10 | PAT_ENC_HSP | Inpatient encounters — historical risk features if needed | ☐ | |

> **PHI note:** PATIENT, PAT_ADDRESS, and COVERAGE contain Zone 0 PHI. Masking policies must be deployed before replication runs. Session-level scoring outputs written to Zone 1 must use masked patient identifiers.

---

## Block 3: Operations & Capacity Management Workflow (30 min)

### Purpose
Understand how the Capacity Management team works today so the pilot dashboard and recommendation logic are designed around their actual workflow.

**3.1** Walk us through the current process: when a session is identified as likely to have no-shows, what happens today? Who does what, in what system, using what information?

**3.2** Who specifically on the Capacity Management team will be the pilot users? *(2–3 named individuals required before Phase 1 ends — these are the people the Streamlit dashboard is built for)*

| Name | Role | Available for Pilot (Weeks 6–7)? |
|------|------|----------------------------------|
| | | ☐ |
| | | ☐ |
| | | ☐ |

**3.3** Confirm pilot specialties. *(Starting candidates per meeting minutes: ambulatory pediatric medicine and surgery, beginning with surgical return visits)*

| Specialty | Approx. No-Show Rate | Operationally Stable? | Engaged Lead? | In Scope? |
|-----------|----------------------|-----------------------|---------------|-----------|
| Peds Medicine | | ☐ | ☐ | ☐ |
| Surgery (return visits) | | ☐ | ☐ | ☐ |
| Other: _______ | | ☐ | ☐ | ☐ |

**3.4** What is the agreed **lead time window** for recommendations? How far in advance should the system flag sessions?
- ☐ 48 hours
- ☐ 72 hours
- ☐ 1 week
- ☐ Other: _______________

**3.5** What is the **maximum number of sessions per day** the Capacity Management team can realistically review and action? *(This sets the throughput ceiling — recommendations will not exceed this)*

**3.6** What threshold defines a "high-risk session" warranting a recommendation? Is there a threshold already in operational use, or does the pilot need to define one?

**3.7** How should the system handle **same-day cancellations** in an already-adjusted slot? Existing protocol or gap to define?

**3.8** What operational thresholds would trigger a **reversion or pause** of an adjusted slot? *(e.g., wait time > X minutes, both patients arrive simultaneously)*

---

## Block 4: Governance, PHI & Clinical Oversight (25 min)

### Purpose
Confirm PHI requirements and clinical governance dependencies before Phase 1 begins. These are gate items — data replication does not begin until they are resolved.

**4.1** Does the Capacity Management team need to see **patient names or MRNs** in the pilot dashboard, or can they work with masked identifiers and session-level data only?
*(Answer determines PHI architecture — masked Zone 1 vs. named patient view with Zone 0 access implications)*

**4.2** Is there a **clinical governance or ethics committee** that must review the use of a predictive model in scheduling decisions before the pilot goes live? If yes — who leads it, what does the review require, and what is the realistic turnaround time?

**4.3** Are there **patient populations or appointment types to explicitly exclude** from the model?
- ☐ Mental health / behavioral health
- ☐ Recent inpatient discharge follow-ups
- ☐ Other: _______________

**4.4** Who is the **clinical sponsor** for this use case? Is there a CCIO, CMO, or VP of Access who needs to give formal sign-off before pilot go-live?

**4.5** Are there **model fairness concerns** to address — e.g., ensuring the model does not disproportionately flag patients of certain demographics, insurance types, or zip codes?

**4.6** Confirm: the Snowflake tenant is within the Texas Children's environment and the Snowflake BAA is in place. Any outstanding items?

**4.7** What AI ethics guidelines or organizational standards must the use case be aligned to before deployment? Who owns that review?

---

## Block 5: Success Criteria & Pilot Design (30 min)

### Purpose
Define what "success" looks like in concrete, measurable terms so the Phase 4 scaling decision has an objective basis.

### KPI & Success Metrics

Review and agree on targets for each metric:

| Metric | Description | Proposed Target | Agreed Target |
|--------|-------------|-----------------|---------------|
| Recommendation action rate | % of surfaced recommendations approved by Capacity Management | ≥50% | |
| Adjusted sessions | Total sessions with a slot adjustment made during the pilot | ≥15–20 | |
| Slot fill rate | % of adjusted slots where a second patient was booked | TBD | |
| Dual-arrival rate | % of adjusted sessions where both patients arrived simultaneously | Define threshold | |
| Wait time threshold breaches | Sessions exceeding the agreed operational wait time limit | 0 | |
| User adoption | % of pilot users actively using the dashboard by end of Phase 3 | ≥80% | |
| Override rate | % of recommendations overridden with a documented reason | <50% | |
| Provider / operational feedback | Qualitative feedback from pilot specialties | Net positive | |
| No-show rate delta | Change in no-show rate pre vs. post pilot for adjusted sessions | Measurable reduction | |

**5.1** Are there additional success metrics the client sponsor will use to evaluate the pilot?

**5.2** What would a **"do not scale"** outcome look like? What result would definitively indicate the use case should not be expanded?

**5.3** Is there a **baseline no-show rate** available for the pilot specialties today? Who owns that data and can provide it for Phase 1?

### Pilot Audience & Access

**5.4** Beyond the named Capacity Management users, who else needs access to pilot outputs?

| Role | Name | Access Level | Purpose |
|------|------|-------------|---------|
| Clinical sponsor | | Read-only | Steering oversight |
| IS / Data architect | | Full | Technical validation |
| Operations lead | | Read-only | Feedback & sign-off |
| Other | | | |

---

## Block 6: Week 0 Checklist & Next Steps (20 min)

### Purpose
Define everything that must be in place before Week 1 begins. Assign an owner and due date to each item before leaving the room.

### Week 0 — Pre-Kick-Off Checklist

#### Snowflake & Technical Environment

| Item | Owner | Due Date | Done? |
|------|-------|----------|-------|
| Snowflake environment provisioned (two-zone PHI architecture) | IS | | ☐ |
| RBAC and access controls configured | IS | | ☐ |
| Snowflake BAA confirmed and signed | IS / Legal | | ☐ |
| IDMC connector configured and connectivity tested | IS + Deloitte | | ☐ |
| Snowflake environment access granted to Deloitte team | IS | | ☐ |

#### Epic Clarity & Data

| Item | Owner | Due Date | Done? |
|------|-------|----------|-------|
| Clarity DBA / reporting analyst identified and engaged | IS | | ☐ |
| Clarity table availability confirmed (table list from Block 2) | IS / Clarity DBA | | ☐ |
| No-show model owner identified; documentation shared with Deloitte | Analytics / IS | | ☐ |
| Model output format confirmed (score, tier, or both) | Analytics | | ☐ |
| PHI/PII classification sprint scheduled | Deloitte + IS | | ☐ |
| Masking policies drafted for Zone 1 | Deloitte + IS | | ☐ |

#### Stakeholders & Governance

| Item | Owner | Due Date | Done? |
|------|-------|----------|-------|
| Clinical sponsor formally identified and briefed | Operations / CCIO | | ☐ |
| Clinical governance / AI ethics review process confirmed | IS / Clinical | | ☐ |
| Capacity Management pilot users named (2–3 individuals) | Grace / Natalie | | ☐ |
| Pilot specialties confirmed | Operations | | ☐ |
| Patient population exclusion list agreed | Clinical / Operations | | ☐ |

#### Planning & Meeting Cadence

| Item | Owner | Due Date | Done? |
|------|-------|----------|-------|
| Phase 1 kick-off meeting scheduled | PM | | ☐ |
| Weekly steering meeting cadence agreed (day / time / attendees) | PM | | ☐ |
| End of Phase 2 internal demo scheduled | PM | | ☐ |
| End of Phase 3 pilot review / survey scheduled | PM | | ☐ |
| Phase 4 steering / scaling decision presentation scheduled | PM | | ☐ |
| Deloitte detailed question list distributed to IS and Operations | Deloitte | EOD today | ☐ |

---

## Stakeholder Map — Pilot Engagement

| Phase | Stakeholder | Role | Engagement Type |
|-------|-------------|------|-----------------|
| All phases | Ashok Kurian (VP, IS) | Executive sponsor, IS | Steering meetings |
| All phases | Paige Schultz (VP, System Access) | Executive sponsor, Operations | Steering meetings |
| All phases | Dr. Robert Ball (CCIO) | Clinical oversight & governance sign-off | Governance gate; steering |
| Ph. 1–2 | Sridhar Sunku (Data Architect, IS) | Technical architecture, Epic/Snowflake | Weekly working sessions |
| Ph. 1–2 | Clarity DBA *(to be named)* | Epic Clarity table access & validation | Phase 1 data confirmation |
| Ph. 1–2 | Rupesh Dandekar (Deloitte, AI Lead) | Build lead | Daily |
| Ph. 3–4 | Grace Fangman (Dir., Strategic Access Ops) | Operational lead, Capacity Mgmt owner | Weekly + pilot daily |
| Ph. 3–4 | Natalie Chipinski (PM, Strategic Access Ops) | Pilot coordination, feedback collection | Daily during Phase 3 |
| Ph. 3 | Capacity Mgmt users *(to be named — Block 3)* | Dashboard users, recommendation reviewers | Daily during Phase 3 |
| Ph. 3 | Pilot specialty leads *(surgical + peds medicine)* | Clinical feedback, wait time monitoring | Weekly check-in |
| Ph. 4 | All steering members | Scaling decision | Phase 4 steering |

---

## Decisions Log

*Record explicit decisions agreed in the session:*

| # | Decision | Agreed By |
|---|----------|-----------|
| 1 | Pilot specialties confirmed | |
| 2 | Lead time window for recommendations | |
| 3 | Max sessions per day (throughput ceiling) | |
| 4 | Masked vs. named patient view in pilot dashboard | |
| 5 | Clinical governance review: required / not required before go-live | |
| 6 | Capacity Management pilot users confirmed | |
| 7 | No-show model form and ownership confirmed | |
| 8 | Baseline no-show data source confirmed | |
| 9 | KPI targets agreed | |

---

## Open Items Log

*Capture items raised during the session requiring follow-up:*

| # | Open Item | Owner | Due Date |
|---|-----------|-------|----------|
| 1 | | | |
| 2 | | | |
| 3 | | | |
| 4 | | | |
| 5 | | | |

---

*Prepared by Deloitte | Confidential — For Discussion Purposes Only | April 2026*
