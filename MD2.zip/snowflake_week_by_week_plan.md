# Snowflake Data Platform — Week-by-Week Plan by Resource
**POD B · 24 weeks · Revised team reflecting Snowflake Cortex Code acceleration**

---

## Revised Team

> Snowflake Cortex Code (AI coding agent) reduces manual pipeline and transformation development effort, allowing a leaner engineering team. Cortex Code handles boilerplate SQL generation, DBT model scaffolding, and routine transformation logic, freeing engineers to focus on architecture decisions, data quality, and business rule validation.

| Role | Location |
|---|---|
| Snowflake Architecture Lead | US |
| Senior Data Engineer | US |
| Senior Data Engineer | India |
| Junior Data Engineer | India |

---

## Phase 1 — Kickoff & Scoping (Weeks 0–1)

| Week | US Architecture Lead | US Senior Data Engineer | India Senior Data Engineer | India Junior Data Engineer |
|---|---|---|---|---|
| Week 0 | Engagement kickoff; architecture alignment with Carlyle and Palantir; governance setup | Tooling setup; Snowflake environment provisioning (dev/UAT/prod) | Source system inventory and documentation review | Project onboarding; tooling and access setup |
| Week 1 | Finalize architecture design; Data Vault approach confirmed; raw zone design signed off | Environment configuration; access controls and RBAC framework | Source connectivity assessment across all priority sources | Cortex Code environment configured; DBT project scaffolding initiated |

**✓ Milestone: Snowflake environments ready; architecture approach agreed**

---

## Phase 2 — Source Onboarding & Raw Data Foundation (Weeks 2–9)

| Week | US Architecture Lead | US Senior Data Engineer | India Senior Data Engineer | India Junior Data Engineer |
|---|---|---|---|---|
| Week 2 | Raw zone design review; ingestion pattern sign-off; parallel feed design for Palantir | Source-to-target mapping for PE sources (Investran, eFront, Allvue) | Build Snowpipe ingestion for Investran | Cortex Code-assisted DBT raw layer scaffolding for Investran |
| Week 3 | Architecture review; resolve blockers | Investran ingestion testing and validation; eFront ingestion build | eFront and Allvue ingestion build | DBT raw layer models for eFront and Allvue — Cortex Code assisted |
| Week 4 | Palantir parallel feed design review; audit trail design | Allvue ingestion testing and validation; Chronograph ingestion build | Salesforce and market data ingestion build | DBT raw layer models for Chronograph and Salesforce |
| Week 5 | Governance and access control design review | Chronograph and Salesforce ingestion testing and validation | Market data ingestion testing; load controls and error handling | Pipeline scheduling, monitoring, and alerting setup |
| Week 6 | Raw zone QA review; sign-off on raw data availability to Palantir | End-to-end raw zone validation across all sources | Data reconciliation checks; source-level traceability audit | Automated DQ checks for raw zone using Cortex Code templates |
| Week 7 | Stakeholder review: raw data status with Carlyle and Palantir teams | Resolve ingestion issues and edge cases from QA | Finalize load controls across all sources | Documentation of raw zone schemas and lineage |
| Week 8 | Architecture review for curated layer; Data Vault design sessions | Begin curated layer design; core entity model (funds, deals, investors) | Begin source-to-curated mapping for PE entities | Cortex Code-assisted scaffolding of initial curated DBT models |
| Week 9 | Curated layer design sign-off | Cash flow and valuation entity model design | Source-to-curated mapping for Credit and AlpInvest entities | DBT model scaffolding for Credit and AlpInvest curated layer |

**✓ Milestone: Raw data available to Palantir for ontology build**

---

## Phase 3 — Curated Data Model & DBT Framework (Weeks 10–17)

| Week | US Architecture Lead | US Senior Data Engineer | India Senior Data Engineer | India Junior Data Engineer |
|---|---|---|---|---|
| Week 10 | Data Vault curated layer architecture sign-off | Core entity DBT models: funds and deals | Core entity DBT models: investors and investor accounts | DBT model scaffolding and Cortex Code-assisted transformation logic |
| Week 11 | Business definition alignment workshops with Carlyle domain SMEs | Cash flow and NAV DBT model build | Fee schedule and carry calculation data structures | DBT testing framework setup; initial unit tests |
| Week 12 | Cross-workstream alignment: curated schema shared with Palantir for ontology refinement | Standardize business keys and relationships across PE, Credit, and AlpInvest | AlpInvest-specific entity mapping and normalization | DBT model documentation and lineage configuration |
| Week 13 | Iceberg table design review | Apache Iceberg tables: fund performance datasets | Apache Iceberg tables: cash flow histories and valuation snapshots | Automated DQ reporting using Cortex Code templates |
| Week 14 | RBAC and data governance framework sign-off | Row-level security and data masking policies implementation | Data quality rules and DQ checks across curated layer | DQ check automation and defect logging |
| Week 15 | Palantir interoperability review: bi-directional zero-copy via Iceberg | DBT dependency logic, refresh cycles, and orchestration integration | Curated layer reconciliation testing against raw zone | DBT documentation and data lineage finalization |
| Week 16 | Snowflake-to-Palantir integration testing oversight | Integration testing: curated tables consumed by Palantir | Performance tuning and query optimization | Defect logging and resolution tracking |
| Week 17 | Stakeholder review: fully developed Snowflake platform demo to Carlyle | End-to-end platform validation across all sources and entities | Final data reconciliation checks | Test case documentation and sign-off pack preparation |

**✓ Milestone: Fully developed Snowflake data platform; curated tables available to Palantir**

---

## Phase 4 — Post-MVP Stabilization (Weeks 18–24)

| Week | US Architecture Lead | US Senior Data Engineer | India Senior Data Engineer | India Junior Data Engineer |
|---|---|---|---|---|
| Week 18 | MVP deployment support; defect triage oversight | Resolve data defects and reconciliation breaks from MVP | Pipeline performance issue resolution | Defect tracking and regression testing |
| Week 19 | Operational readiness review | Curated data model fine-tuning based on MVP feedback | Refresh schedule optimization and DQ control tuning | Automated monitoring and alerting refinement |
| Week 20 | Lineage and audit trail review; compliance check | Lineage documentation finalization | Operational support process design for steady-state | Runbook and operational documentation |
| Week 21 | Handoff planning: curated tables replace Palantir raw feeds | Confirmed Palantir handoff — curated table integration validated | Final data quality sign-off across all entities | End-user data validation support |
| Week 22 | Scalability review: architecture blueprint for enterprise rollout | Reusable ingestion pattern documentation for future sources | DBT model reuse framework documentation | Knowledge transfer sessions with Carlyle team |
| Week 23 | Implementation roadmap contribution: Snowflake perspective for scaled rollout | Handover documentation and transition support | Support Carlyle team onboarding to steady-state operations | Final QA and defect closure |
| Week 24 | Final engagement review; lessons learned; scaled rollout recommendations | Engagement close-out and final deliverable handover | Final sign-off on all Snowflake deliverables | Final documentation submission |

**✓ Milestone: Steady-state operations ready; handoff to Palantir confirmed**

---

## Key Deliverables Summary

| Deliverable | Owner | Target Week |
|---|---|---|
| Snowflake environments provisioned | US Senior Data Engineer | Week 1 |
| Raw zone ingestion — all priority sources | India Senior Data Engineer | Week 7 |
| Parallel feed to Palantir enabled | US Architecture Lead | Week 9 |
| Curated Data Vault model | US + India Senior Data Engineers | Week 13 |
| Apache Iceberg tables | India Senior Data Engineer | Week 13 |
| DBT framework with lineage and testing | US Senior Data Engineer | Week 15 |
| RBAC and data governance policies | US Architecture Lead | Week 14 |
| Snowflake–Palantir integration validated | US Senior Data Engineer | Week 16 |
| Fully stabilized platform | All | Week 21 |
| Scaled rollout architecture blueprint | US Architecture Lead | Week 22 |

---

## Key Assumptions

- Snowflake Cortex Code handles boilerplate SQL, DBT scaffolding, and routine transformation logic — reducing development effort by an estimated 30–40% vs. a fully manual approach
- Leaner team of 4 (vs. 7 in the original proposal) is viable due to Cortex Code acceleration
- Up to 15–20 data sources assumed; 75% structured / 25% semi-structured
- Monthly refresh cadence; no significant performance re-architecture in this phase
- Carlyle SMEs available for business rule validation, especially during Weeks 11–12
- Upstream data remediation is out of scope
- Palantir team begins ontology build in parallel from Week 9 onwards using raw data feed
