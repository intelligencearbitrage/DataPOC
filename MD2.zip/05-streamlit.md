# Agile Capacity - Streamlit Application

## Overview

This document defines the design and behavior of the Agile Capacity Streamlit application, the operational interface for the Capacity Management team to review no-show risk recommendations, explore historical trends, analyze patient/appointment features that drive no-shows, monitor session flow, and measure pilot outcomes.

The application supports **both read and write operations** — capacity managers can apply, skip, or revert adjustments directly from the app via structured dropdowns or natural language commands. All actions are logged to `CAPACITY_ADJUSTMENT_LOG` for full audit trail. The app also includes an AI-powered chatbot (via Snowflake Cortex) for natural language Q&A about patterns and correlations.

---

## 1. Application Summary

| Attribute | Value |
|-----------|-------|
| **App Name** | AGILE_CAPACITY_APP |
| **Database** | AGILE_CAPACITY_DEMO |
| **Schema** | NOSHOW |
| **Warehouse** | SF_SANDBOX_WH |
| **Primary Users** | Capacity Management Team |
| **Access Role** | CAPACITY_MGMT_ROLE |
| **Entry Point** | `streamlit_app.py` |
| **Lookahead Window** | 3 days (hardcoded `LOOKAHEAD_DAYS = 3`) |
| **History Depth** | ~180 days (Oct 2025 - Apr 2026) |

---

## 2. Application Structure

The app is a single-file Streamlit application (`streamlit_app.py`) using a tab-based layout with global sidebar filters. There are no sub-pages, utility modules, or separate config files.

```
agile_capacity_app/
├── streamlit_app.py     # Single-file app (all 9 tabs, queries, DML, AI chatbot)
├── snowflake.yml        # Snowflake deployment manifest
└── DEMO_SCRIPT.md       # Demo walkthrough script
```

### Tab Layout

```
┌───────────────────────────────────────────────────────────────────────────────────┐
│                  AGILE CAPACITY — DAILY RECOMMENDATIONS                            │
│                  {Selected Date} | Next 3 days                                     │
├────────────────────────────────────────────────────────────────────────────────────┤
│  KPI Row: Flagged Sessions | Capacity Recovered | Additional Patients | Alerts     │
├──────────┬──────────┬──────────┬──────────┬──────────┬──────────┬─────────────────┬──────────┬──────────┤
│ Recommend│ No-Show  │ Feature  │ Session  │ Adjust-  │ Oper.    │ Pilot Analytics │ Adjust.  │ AI       │
│ -ations  │ Trends   │ Analysis │ Risk     │ ment Log │ Monitor- │ & Impact        │ Effect-  │ Assist-  │
│          │          │          │ Explorer │          │ ing      │                 │ iveness  │ ant      │
└──────────┴──────────┴──────────┴──────────┴──────────┴──────────┴─────────────────┴──────────┴──────────┘

┌───────────────┐
│ SIDEBAR       │
│ ─────────     │
│ Date Picker   │
│ Specialty []  │
│ Location  []  │
│ ─────────     │
│ Operator ID   │
└───────────────┘
```

| Tab | Purpose | Key Content |
|-----|---------|-------------|
| **Recommendations** | View recommendations, apply/skip adjustments via dropdown or natural language | 14-day calendar grid, recommendations table, NL action parser, Apply/Skip buttons |
| **No-Show Trends** | Historical no-show pattern analysis | Weekly trend, by specialty, by location, by day of week, risk prediction accuracy |
| **Feature Analysis** | Understand which patient/appointment features correlate with no-shows | Feature impact summary, drill-down, cross-tab heatmap, candidate profile |
| **Session Risk Explorer** | Drill into session-level risk profiles for upcoming sessions | Risk overview table, session detail with tier breakdown |
| **Adjustment Log** | Audit trail of all historical actions | Filterable log with provider resolution, actions by day chart |
| **Operational Monitoring** | Monitor arrival patterns, wait times, alerts; revert adjustments | KPIs, active alerts, revert workflow, session flow metrics, wait time trends |
| **Pilot Analytics & Impact** | Compare adjusted vs non-adjusted session outcomes | Impact analysis, monthly trend, net impact summary, scorecard |
| **Adjustment Effectiveness** | Statistical analysis of which features make adjustments most effective | Correlation model, feature effectiveness breakdown, AI causality narrative, candidate profile |
| **AI Assistant** | Natural language Q&A about patterns, correlations, recommendations | Chatbot powered by Snowflake Cortex (mistral-large2), pre-computed data context |

---

## 3. Global Sidebar Filters

All tabs respect the global sidebar filters. Filter data is loaded once from `DIM_PROVIDER`.

| Filter | Type | Default | Scope |
|--------|------|---------|-------|
| **Recommendation Date** | Date input | Today | Tabs 1, 4 (date-parameterized queries) |
| **Specialty** | Multi-select | All specialties | All tabs (SQL WHERE on `p.SPECIALTY`) |
| **Location** | Multi-select | All locations | All tabs (SQL WHERE on `p.LOCATION_NAME`) |
| **Operator ID** | Text input | Empty | Required for Apply/Skip/Revert actions (Tabs 1, 6) |

The specialty and location filters are translated into SQL `IN (...)` clauses that are injected into all tab queries via `spec_filter` and `loc_filter` variables.

---

## 4. Top-Level KPI Row

Four metrics displayed above all tabs, computed on every page load:

| Metric | Source | Derivation |
|--------|--------|------------|
| **Flagged Sessions** | Inline V_FLAGGED_SESSIONS (date-parameterized) | Count of sessions matching thresholds for selected date |
| **Capacity Recovered** | `V_PILOT_ANALYTICS` | Count of rows where `ADJUSTMENT_STATUS = 'ADJUSTED'` |
| **Additional Patients Seen** | `V_PILOT_ANALYTICS` | `COMPLETED_APPOINTMENTS.sum() - count(adjusted_sessions)` |
| **Operational Alerts** | `V_OPERATIONAL_ALERTS` | `len(alerts_df)` — shows "Action Required" delta when > 0 |

---

## 5. Tab Details

### 5.1 Recommendations

**Purpose:** Primary operational interface. View slot recommendations, apply or skip adjustments via structured dropdown or natural language commands.

#### 14-Day Calendar Grid

A visual calendar grid at the top of the tab showing the next 14 days. Each day displays the count of flagged sessions. Clicking a day highlights it; the sidebar date picker remains the source of truth for data queries.

- Layout: `st.columns(7)` for Mon-Sun with `st.button()` per day
- Selected date shown with primary (blue) button styling
- Flagged count shown in parentheses (e.g., "15 (10)")
- Tooltip shows total sessions and flagged count

#### Recommendations Table

Displays columns from an inline version of `V_SLOT_RECOMMENDATIONS` parameterized by the selected date:

| Column | Display Name | Format |
|--------|-------------|--------|
| `SESSION_DATE` | Session Date | Date |
| `PROVIDER_NAME` | Provider | Text |
| `SPECIALTY` | Specialty | Text |
| `SLOT_START_TIME` | Slot Time | Time |
| `HIGH_PCT` | High % | Percentage (e.g. "42.5%") |
| `COMBINED_PCT` | Combined % | Percentage (e.g. "68.3%") |
| `FLAG_REASON` | Flag Reason | Color-coded cell |

**Flag Reason color coding:**

| Value | Background | Text |
|-------|-----------|------|
| `BOTH` | Dark red (#8B0000) | White |
| `HIGH_DOMINANT` | Crimson (#DC143C) | White |
| `COMBINED_ELEVATED` | Orange (#FFA500) | Black |

#### Flagged Sessions Summary

Bar chart showing count of flagged sessions by `FLAG_REASON` category.

#### Natural Language Actions

Text input where operators describe their intent in plain English (e.g., "Apply adjustment for Dr. Patel's 10am slot on April 17"). The system uses `SNOWFLAKE.CORTEX.COMPLETE('mistral-large2')` to parse the intent and extract: action (APPLIED/SKIPPED), provider, date, slot time. A confirmation card shows the parsed match before executing DML.

#### Apply / Skip Adjustment (Structured)

Dropdown to select a recommendation by APPT_ID, with Apply and Skip buttons. Requires Operator ID from the sidebar.

- **Apply:** `UPDATE FACT_APPOINTMENT SET SLOT_CAPACITY = 2` + `INSERT INTO CAPACITY_ADJUSTMENT_LOG` with `ACTION = 'APPLIED'`
- **Skip:** `INSERT INTO CAPACITY_ADJUSTMENT_LOG` with `ACTION = 'SKIPPED'`

### 5.2 No-Show Trends

**Purpose:** Historical no-show pattern analysis with specialty, location, and date range filtering.

#### Tab-Level Filters

| Filter | Type | Default |
|--------|------|---------|
| Date Range | Date input (pair) | Last 90 days |
| Provider | Multi-select | None (shows all) |

#### Content

1. **KPI Row:** Overall no-show rate (with trend delta vs prior period), total appointments, total no-shows
2. **No-Show Rate Over Time:** Weekly line chart
3. **No-Show Rate by Specialty:** Horizontal bar chart
4. **No-Show Rate by Location:** Horizontal bar chart
5. **No-Show Rate by Day of Week:** Bar chart (Mon-Fri, ordered)
6. **Risk Prediction Accuracy:** Bar chart + table showing actual no-show rate by predicted risk tier (HIGH/MEDIUM/LOW)

Data sources: `FACT_ARRIVAL` + `FACT_SESSION` + `DIM_PROVIDER` + `FACT_NOSHOWRISK`

### 5.3 Feature Analysis

**Purpose:** Understand which patient and appointment features correlate with no-shows to improve double-booking candidate selection.

Data source: `FACT_APPOINTMENT` + `DIM_PATIENT` + `FACT_ARRIVAL` + `FACT_SESSION` + `DIM_PROVIDER` (completed sessions only)

#### Features Analyzed

| Feature | Source | Bucketing |
|---------|--------|-----------|
| Distance | `DIM_PATIENT.DISTANCE_MILES` | 0-5mi, 5-10mi, 10-20mi, 20-40mi, 40+mi |
| Has Vehicle | `DIM_PATIENT.HAS_VEHICLE` | Yes / No |
| Prior No-Shows | `FACT_APPOINTMENT.PRIOR_NOSHOW_COUNT` | 0, 1, 2, 3+ |
| Time of Day | `FACT_APPOINTMENT.TIME_OF_DAY_CATEGORY` | MORNING, MIDDAY, AFTERNOON |
| Insurance Type | `DIM_PATIENT.INSURANCE_TYPE` | Commercial, Medicare, Medicaid, VA/Tricare, Uninsured |
| Age Group | `DIM_PATIENT.AGE_GROUP` | 0-17, 18-25, 26-35, 36-50, 51-65, 65+ |
| School Break | `FACT_APPOINTMENT.IS_SCHOOL_BREAK` | Yes / No |
| Same-Day Appt | `FACT_APPOINTMENT.HAS_SAME_DAY_APPT` | Yes / No |
| Days Since Scheduling | `FACT_APPOINTMENT.DAYS_SINCE_SCHEDULING` | 0-7d, 8-14d, 15-30d, 31-60d, 60+d |

#### Content

1. **Feature Impact Summary:** Horizontal bar chart showing "spread" (max - min no-show rate) for each feature. Baseline rate displayed.
2. **Feature Drill-Down:** Select a feature via dropdown. Bar chart of no-show rate by category + data table with volume.
3. **Multi-Feature Cross-Tab:** Select two features. Heatmap/pivot table of no-show rates per combination, styled with `YlOrRd` gradient.
4. **Ideal Double-Booking Candidate Profile:** Table showing the highest-risk value for each feature (min 20 sample size). Summary of top 3 risk factors.

### 5.4 Session Risk Explorer

**Purpose:** Drill into session-level risk profiles for upcoming sessions (next 14 days).

#### Tab-Level Filters

| Filter | Type | Default |
|--------|------|---------|
| Session Date Range | Date input (pair) | Today → Today + 14 days |
| Show Flagged Only | Checkbox | Off |

#### Content

- **Session Risk Overview Table:** Session Date, High Risk %, Status (Flagged/Normal), Provider, Location
- **Session Detail:** Select a session to see provider name, specialty, location, total patients, flagged status, and risk tier breakdown bar chart (HIGH/MEDIUM/LOW)

Data source: `V_SESSION_RISK_PROFILE` + `FACT_SESSION` + `DIM_PROVIDER` + `V_FLAGGED_SESSIONS`

### 5.5 Adjustment Log

**Purpose:** Audit trail of all Apply/Skip/Revert actions. Adjustments are typically made 5-10 days before the session date.

#### Filters

| Filter | Type | Default |
|--------|------|---------|
| Date Range | Date input (pair) | Last 90 days |
| Action Type | Multi-select | All: APPLIED, SKIPPED, REVERTED |
| Provider | Multi-select | None (shows all) |

#### Displayed Columns

`LOG_ID`, `SESSION_ID`, `APPT_ID`, `ACTION`, `ACTION_TS`, `OPERATOR_ID`, `NOTES`, `PROVIDER_NAME`, `LOCATION_NAME`

Provider and location are resolved via JOIN through `FACT_SESSION` -> `DIM_PROVIDER`.

#### Actions by Day Chart

Bar chart of action counts by day (last 90 days), pivoted by `ACTION` type.

### 5.6 Operational Monitoring

**Purpose:** Monitor arrival patterns, wait times, and double-book conflicts for recent sessions (last 30 days). Also provides the Revert workflow for undoing applied adjustments.

#### Top Metrics (from `V_SESSION_FLOW_METRICS`)

| Metric | Derivation | Target |
|--------|------------|--------|
| Avg Wait Time | Mean of `AVG_WAIT_TIME_MIN` | < 15 min |
| Avg No-Show Rate | Mean of `NO_SHOW_PCT` | -- |
| Double-Book Conflicts | Sum of `BOTH_SHOWED_COUNT` | 0 |

#### Active Alerts (from `V_OPERATIONAL_ALERTS`)

Alert types and their severity display:

| Alert Type | Display |
|------------|---------|
| `DOUBLE_BOOK_CONFLICT` | `st.error` (red) |
| `MAX_WAIT_EXCEEDED` | `st.warning` (amber) |
| `AVG_WAIT_EXCEEDED` | `st.warning` (amber) |
| Other | `st.info` (blue) |

Alert detail table columns: Date, Provider, Alert Type, Recommended Action, Avg Wait, Max Wait, Conflicts.

#### Session Flow Metrics Table

Top 50 recent sessions. Columns: Date, Provider, Scheduled, No-Shows, No-Show %, Late, Avg Wait, Max Wait, Double-Booked, Both Showed.

#### Wait Time Trends

Line chart showing `Avg Wait (min)` and `Max Wait (min)` aggregated by date.

#### Revert Adjustment Workflow

Dropdown of applied adjustments that have not been reverted (queries `CAPACITY_ADJUSTMENT_LOG` for `ACTION = 'APPLIED'` where `SLOT_CAPACITY = 2` and no subsequent REVERTED record). Includes a reason dropdown (Provider request, Patient rescheduled, Conflict detected, Schedule change, Other). Requires Operator ID.

- **Revert:** `UPDATE FACT_APPOINTMENT SET SLOT_CAPACITY = 1` + `INSERT INTO CAPACITY_ADJUSTMENT_LOG` with `ACTION = 'REVERTED'`

### 5.7 Pilot Analytics & Impact

**Purpose:** Compare outcomes between adjusted and non-adjusted sessions to measure pilot success.

Data source: `V_PILOT_ANALYTICS` with `ADJUSTMENT_STATUS` = `ADJUSTED` or `NOT_ADJUSTED`.

#### Top Comparison Metrics

| Metric | Adjusted | Baseline (Non-Adjusted) | Delta Display |
|--------|----------|------------------------|---------------|
| Session Count | Count of ADJUSTED | Count of NOT_ADJUSTED | -- |
| No-Show Rate | Mean `NO_SHOW_RATE` | Mean `NO_SHOW_RATE` | vs baseline, inverse color |
| Completion Rate | Mean `COMPLETION_RATE` | Mean `COMPLETION_RATE` | vs baseline |
| Avg Wait Time | Mean `AVG_WAIT_MIN` | Mean `AVG_WAIT_MIN` | vs baseline, inverse color |

#### Impact Analysis: Adjusted vs Non-Adjusted

Includes an explanatory note: adjusted sessions are intentionally selected from high-risk slots, so their no-show rate is expected to be higher than non-adjusted sessions. The value is that double-booking recovers capacity that would otherwise be lost.

- **Side-by-Side Comparison Table:** No-Show Rate %, Completion Rate %, Avg Wait (min) for Adjusted vs Non-Adjusted
- **No-Show Rate Comparison Bar Chart**

#### Monthly Impact Trend

Line chart of no-show rate by month, split by ADJUSTED vs NOT_ADJUSTED status.

#### Net Impact Summary

| Metric | Derivation |
|--------|------------|
| Total Adjusted Throughput | Sum of `COMPLETED_APPOINTMENTS` for adjusted sessions |
| No-Shows Offset | `adj_count * (non_adj_no_show_rate - adj_no_show_rate) / 100` |
| Double-Book Conflicts | Sum of `DOUBLE_BOOK_CONFLICTS` for adjusted sessions |
| Conflict Rate | `double_book_conflicts / adj_count * 100` |

#### Detailed Session Outcomes

Filterable table with status filter (ADJUSTED / NOT_ADJUSTED). Columns: Date, Provider, Specialty, Status, Scheduled, No-Shows, No-Show %, Completion %, Avg Wait, Conflicts.

#### Pilot Success Scorecard

| Measure | Target | Status Logic |
|---------|--------|-------------|
| Capacity recovered | > 200 sessions | Green if > 200 |
| Avg wait time (adjusted) | < 15 min | Green if < 15 |
| Double-book conflict rate | < 5% of adjusted | Green if < 5% |
| Throughput (adjusted) | > 1,000 patients | Green if > 1,000 |

### 5.8 Adjustment Effectiveness

**Purpose:** Statistical analysis of which patient/appointment features make double-booking adjustments most effective (i.e., the patient actually no-showed and capacity was recovered vs. both patients showed causing a conflict).

Data source: `FACT_APPOINTMENT` + `DIM_PATIENT` + `FACT_NOSHOWRISK` + `FACT_ARRIVAL` + `FACT_SESSION` + `DIM_PROVIDER` (completed sessions only)

#### Content

1. **Effectiveness Overview KPIs:** Adjusted appointment count, effectiveness rate (% where patient no-showed), conflict rate (% where both showed), net recovery rate
2. **Feature Correlation Chart:** Bar chart showing correlation strength (spread) per feature for predicting no-shows — higher spread = more predictive
3. **Feature Effectiveness Breakdown:** Select a feature to see adjusted vs baseline no-show rates by category, with net effectiveness comparison
4. **AI Causality Narrative:** Uses `SNOWFLAKE.CORTEX.COMPLETE('mistral-large2')` to generate a 3-paragraph plain-English explanation of which features predict adjustment success, why, and practical implications
5. **Ideal Adjustment Candidate Profile:** Table showing feature values with highest no-show rates among adjusted appointments, summarizing the ideal candidate

### 5.9 AI Assistant

**Purpose:** Natural language chatbot interface for Q&A about no-show patterns, correlations, feature impacts, and adjustment recommendations.

#### Technology

- Uses `SNOWFLAKE.CORTEX.COMPLETE('mistral-large2')` via `session.sql()`
- Conversation history maintained in `st.session_state`
- Pre-computed data context (cached for 5 minutes) includes: overall no-show rate, rates by risk tier, by location, by specialty, double-booking effectiveness stats, and vehicle x time-of-day cross-tab
- System prompt includes schema descriptions and instructions to answer from data context without generating SQL

#### Content

1. **Example Questions:** Six clickable buttons with starter questions (e.g., "Which features most strongly predict no-shows?")
2. **Chat Interface:** `st.chat_message` / `st.chat_input` with persistent history
3. **Clear Chat:** Button to reset conversation history

---

## 6. Data Model Summary

### Dimension Tables

| Table | Rows | Key Columns | Purpose |
|-------|------|-------------|---------|
| **DIM_PATIENT** | 1,000 | `PATIENT_ID`, `PATIENT_MRN`, `APPT_TYPE_PREFERENCE`, `DISTANCE_MILES`, `HAS_VEHICLE`, `AGE_GROUP`, `INSURANCE_TYPE`, `PRIMARY_LANGUAGE` | Patient master with demographic and access features |
| **DIM_PROVIDER** | 20 | `PROVIDER_ID`, `PROVIDER_NAME`, `SPECIALTY`, `LOCATION_NAME`, `LOCATION_CITY`, `LOCATION_TYPE` | Providers across 5 specialties at 5 locations |

### Fact Tables

| Table | Rows | Key Columns | Purpose |
|-------|------|-------------|---------|
| **FACT_SESSION** | ~1,660 | `SESSION_ID`, `PROVIDER_ID`, `SESSION_DATE`, `SESSION_STATUS` | Clinic sessions (180 days history + 14 days forward) |
| **FACT_APPOINTMENT** | ~9,950 | `APPT_ID`, `SESSION_ID`, `PATIENT_ID`, `APPT_TYPE`, `SLOT_START_TIME`, `SLOT_CAPACITY`, `IS_SCHOOL_BREAK`, `TIME_OF_DAY_CATEGORY`, `HAS_SAME_DAY_APPT`, `DAYS_SINCE_SCHEDULING`, `PRIOR_NOSHOW_COUNT` | Individual appointment slots with feature columns |
| **FACT_NOSHOWRISK** | ~9,950 | `APPT_ID`, `PATIENT_ID`, `RISK_SCORE`, `RISK_TIER`, `SCORE_DATE` | Pre-computed ML scores (~25% HIGH, ~48% MEDIUM, ~27% LOW) |
| **FACT_ARRIVAL** | ~9,180 | `APPT_ID`, `SESSION_ID`, `SCHEDULED_TIME`, `ARRIVAL_TIME`, `CHECK_IN_TIME`, `ARRIVAL_STATUS`, `WAS_DOUBLE_BOOKED`, `BOTH_PATIENTS_SHOWED` | Actual patient arrivals for completed sessions |
| **CAPACITY_ADJUSTMENT_LOG** | ~508 | `SESSION_ID`, `APPT_ID`, `ACTION`, `ACTION_TS`, `OPERATOR_ID`, `NOTES` | Audit trail (~61% APPLIED, ~24% SKIPPED, ~15% REVERTED) |

### Locations

| DEPT_ID | Location Name | City | Type |
|---------|--------------|------|------|
| DEPT-01 | Riverside Medical Center | Riverside | Hospital |
| DEPT-02 | Lakewood Specialty Clinic | Lakewood | Clinic |
| DEPT-03 | Summit Health Pavilion | Summit | Medical Center |
| DEPT-04 | Bayshore Outpatient Center | Bayshore | Clinic |
| DEPT-05 | Greenfield Community Hospital | Greenfield | Hospital |

### Views (Business Logic)

| View | Purpose |
|------|---------|
| **V_SESSION_RISK_PROFILE** | Aggregates patient-level risk to session level (HIGH_COUNT, MEDIUM_COUNT, LOW_COUNT, HIGH_PCT, COMBINED_PCT) |
| **V_FLAGGED_SESSIONS** | Filters to sessions meeting threshold criteria (HIGH_PCT >= 40% OR COMBINED_PCT >= 65%) within 3-day lookahead |
| **V_SLOT_RECOMMENDATIONS** | For each flagged session, identifies exactly ONE eligible RETURN slot to recommend (middle slot selection) |
| **V_SESSION_FLOW_METRICS** | Aggregates arrival data: on-time %, no-show %, late %, avg/max wait times, double-book conflicts |
| **V_OPERATIONAL_ALERTS** | Flags sessions exceeding thresholds (avg wait > 20 min, max wait > 35 min, both patients showed) |
| **V_PILOT_ANALYTICS** | Compares outcomes between ADJUSTED vs NOT_ADJUSTED sessions |

---

## 7. Guardrails Enforced

| Guardrail | Implementation | Where |
|-----------|----------------|-------|
| Return slots only | `V_SLOT_RECOMMENDATIONS` filters `APPT_TYPE='RETURN'` | Recommendations tab |
| Max 1 slot per session | View picks middle slot | Recommendations tab |
| Max capacity = 2 | `RECOMMENDED_NEW_CAPACITY = 2` | Recommendations tab |
| Lookahead window | `LOOKAHEAD_DAYS = 3` | Recommendations tab |
| Threshold visibility | `HIGH_PCT` and `COMBINED_PCT` displayed with color coding | Recommendations tab |
| Operator ID required | All DML actions require Operator ID from sidebar | Recommendations & Monitoring tabs |
| NL confirmation | Natural language actions require explicit confirmation before DML | Recommendations tab |
| Advance planning | Adjustments applied 5-10 days before session date | Adjustment Log |
| Closed-loop monitoring | `V_OPERATIONAL_ALERTS` flags threshold breaches | Operational Monitoring tab |
| Full audit trail | All actions logged to `CAPACITY_ADJUSTMENT_LOG` | Adjustment Log tab |
| Revert capability | Applied adjustments can be reverted with reason tracking | Operational Monitoring tab |

---

## 8. Technical Details

### Libraries

```python
import streamlit as st
import pandas as pd
import json
from snowflake.snowpark.context import get_active_session
from datetime import datetime, timedelta
```

Uses `json` for parsing LLM responses in the NL action interface. Uses `SNOWFLAKE.CORTEX.COMPLETE` for AI features (chatbot, NL parsing, causality narrative). All charts use native Streamlit (`st.bar_chart`, `st.line_chart`, `st.dataframe` with styling, `st.chat_message`/`st.chat_input`).

### Session Management

```python
from snowflake.snowpark.context import get_active_session
session = get_active_session()
```

All queries execute via `session.sql(sql).to_pandas()`.

### Deployment

Deployed to Snowflake via stage upload:

```sql
PUT 'file:///path/to/streamlit_app.py' @AGILE_CAPACITY_DEMO.NOSHOW.STREAMLIT_STAGE/
  AUTO_COMPRESS=FALSE OVERWRITE=TRUE;

CREATE OR REPLACE STREAMLIT AGILE_CAPACITY_DEMO.NOSHOW.AGILE_CAPACITY_APP
  ROOT_LOCATION = '@AGILE_CAPACITY_DEMO.NOSHOW.STREAMLIT_STAGE'
  MAIN_FILE = 'streamlit_app.py'
  QUERY_WAREHOUSE = SF_SANDBOX_WH
  TITLE = 'Agile Capacity - Daily Recommendations';
```

Also deployable via `snowflake.yml`:

```yaml
definition_version: 2
entities:
  agile_capacity_app:
    type: streamlit
    identifier:
      name: AGILE_CAPACITY_APP
      database: AGILE_CAPACITY_DEMO
      schema: NOSHOW
    query_warehouse: SF_SANDBOX_WH
    main_file: streamlit_app.py
    artifacts:
      - streamlit_app.py
```

---

## 9. Changes from Previous Version

| Area | Previous | Current |
|------|----------|---------|
| **DML** | Removed entirely; app was read-only | Restored: Apply/Skip in Recommendations, Revert in Monitoring, NL actions via Cortex |
| **Tabs** | 7 tabs | 9 tabs (added Adjustment Effectiveness, AI Assistant) |
| **Calendar** | Single date picker in sidebar | 14-day visual calendar grid + sidebar date picker |
| **NL Interface** | None | Natural language action parser using Cortex COMPLETE |
| **AI Chatbot** | None | AI Assistant tab with conversational Q&A powered by mistral-large2 |
| **Correlation Model** | Raw feature data in Feature Analysis | Statistical effectiveness analysis with AI-generated causality narrative |
| **Operator ID** | Not present | Required sidebar field for all DML actions |
| **Revert Workflow** | Not present | Operational Monitoring tab includes revert with reason tracking |
| **Libraries** | streamlit, pandas | Added json; uses SNOWFLAKE.CORTEX.COMPLETE for AI features |

---

## Related Documents

- [01-architecture.md](./01-architecture.md) — System Architecture
- [03-data-model.md](./03-data-model.md) — Data Model
- [06-ml-model.md](./06-ml-model.md) — No-Show Prediction Model
- [DEMO_SCRIPT.md](../agile_capacity_app/DEMO_SCRIPT.md) — Demo Walkthrough Script
