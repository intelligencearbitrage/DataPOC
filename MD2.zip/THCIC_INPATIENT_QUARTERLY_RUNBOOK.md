# THCIC PUDF — Quarterly Data Pipeline Runbook

**Source:** Texas Department of State Health Services (DSHS) — Texas Health Care Information Collection (THCIC)  
**Data:** Texas Hospital Inpatient Discharge Public Use Data File (PUDF)  
**Frequency:** Quarterly — DSHS releases each quarter approximately 60–90 days after the close of the quarter  
**Schema:** `THCIC` (Snowflake)  
**Maintainer:** *(your name / team)*  
**Last updated:** 2025Q1

---

## Table of Contents

1. [Architecture Overview](#1-architecture-overview)
2. [File Inventory](#2-file-inventory)
3. [Table Naming Conventions](#3-table-naming-conventions)
4. [One-Time Setup (First Run Only)](#4-one-time-setup-first-run-only)
5. [Quarterly Execution Steps](#5-quarterly-execution-steps)
6. [Validation Checks](#6-validation-checks)
7. [Promotion: STG_LKP → LKP](#7-promotion-stg_lkp--lkp)
8. [Troubleshooting](#8-troubleshooting)
9. [YEAR_QUARTER Reference](#9-year_quarter-reference)
10. [File Naming Convention](#10-file-naming-convention)
11. [Change Log](#11-change-log)

---

## 1. Architecture Overview

The pipeline uses a **two-layer staging pattern**:

```
DSHS PUDF Download
        │
        ▼
  ┌─────────────────────────────────────────────────────┐
  │  LAYER 1 — STAGING (transient, per-quarter load)    │
  │                                                     │
  │  STG_IP_BASE1       ← Base Data #1 file      │
  │  STG_IP_BASE2       ← Base Data #2 file      │
  │  STG_IP_CHARGES     ← Charges file           │
  │  STG_IP_FACILITY_TYPE ← Facility file        │
  │  STG_IP_GROUPER     ← Grouper file           │
  │                                                     │
  │  STG_LKP_<NAME>            ← Coding scheme staging  │
  └─────────────────────────────────────────────────────┘
        │
        │  Validate → Promote
        ▼
  ┌─────────────────────────────────────────────────────┐
  │  LAYER 2 — MASTER LOOKUP (stable, version-tracked)  │
  │                                                     │
  │  LKP_<NAME>                ← Promoted coding schemes│
  └─────────────────────────────────────────────────────┘
```

**Key design decisions:**

- Every table in both layers carries a `YEAR_QUARTER` column (e.g. `2025Q1`). This is your partition key, your audit trail, and your rollback handle.
- `STG_*` tables are truncated-and-reloaded each quarter. They hold only one quarter at a time.
- `LKP_*` tables are cumulative. New codes are inserted; changed descriptions are updated; retired codes are flagged with `EFFECTIVE_TO`.
- The Inpatient main tables (`STG_IP_BASE1` etc.) are **not** promoted to a permanent table in this design — that is a downstream decision you control. Staging tables accumulate quarter-over-quarter if you choose not to truncate.

---

## 2. File Inventory

### SQL Files (run in order)

| File | Run When | Purpose |
|------|----------|---------|
| `01_inpatient_stg_ddl.sql` | One-time setup | Creates all `STG_IP_*` staging tables |
| `02_lookup_ddl.sql` | One-time setup | Creates all `STG_LKP_*` and `LKP_*` lookup tables |
| `03_copy_into_stg_lkp.sql` | Every quarter | Loads coding scheme CSVs into `STG_LKP_*` tables |
| `04_promote_stg_to_lkp.sql` | Every quarter (post-validation) | Merges `STG_LKP_*` into master `LKP_*` tables |
| `05_quarterly_validation.sql` | Every quarter | Validation queries — run before promoting |
| `06_outpatient_stg_stubs.sql` | When outpatient added | Stub DDL for outpatient staging tables |

### CSV Files (`csv/` directory)

One file per coding scheme, named `stg_lkp_<name>.csv`. Three columns: `CODE`, `DESCRIPTION`, `YEAR_QUARTER`.

These CSVs represent the **initial seed data** from the 2025 PUDF User Manual (DSHS Document E25-14163). They do not change unless DSHS changes the coding scheme. Compare against the new User Manual PDF each quarter to detect changes.

### PUDF Data Files (downloaded from DSHS each quarter)

| PUDF File | Target Table | Format | ~Size per Quarter |
|-----------|-------------|--------|------------------|
| Base Data #1 | `STG_IP_BASE1` | CSV (comma-delimited) | ~314 MB |
| Base Data #2 | `STG_IP_BASE2` | CSV (comma-delimited) | ~220 MB |
| Charges | `STG_IP_CHARGES` | CSV (comma-delimited) | ~793 MB |
| Facility Type | `STG_IP_FACILITY_TYPE` | CSV (comma-delimited) | ~42 KB |
| Grouper | `STG_IP_GROUPER` | CSV (comma-delimited) | ~69 MB |

> **Use the CSV (comma-delimited) format.** This is consistent with all other files in this pipeline. If DSHS provides only fixed-width or tab-delimited, convert to CSV before staging.

---

## 3. Table Naming Conventions

| Prefix | Layer | Description |
|--------|-------|-------------|
| `STG_IP_*` | Staging | Raw inpatient PUDF data loaded for validation. Truncated each quarter by default. |
| `STG_LKP_*` | Staging (lookup) | Coding scheme rows for the current quarter. Truncated before each load. Validated before promotion. |
| `LKP_*` | Master | Cumulative coding scheme master. Contains `EFFECTIVE_FROM` / `EFFECTIVE_TO` for code lifecycle tracking. |
| `STG_OP_*` | Staging | Raw outpatient PUDF data (same pattern). Populated when outpatient PUDF is added. |

All staging and lookup tables share the `THCIC` schema.

---

## 4. One-Time Setup (First Run Only)

Complete these steps once when setting up the pipeline for the first time.

### Step 4.1 — Create the Snowflake schema

```sql
CREATE SCHEMA IF NOT EXISTS THCIC;
USE SCHEMA THCIC;
```

### Step 4.2 — Create staging and lookup tables

Run these two scripts in order:

```bash
# In Snowflake UI or SnowSQL
01_inpatient_stg_ddl.sql
02_lookup_ddl.sql
```

### Step 4.3 — Create the internal stage

```sql
CREATE OR REPLACE STAGE THCIC.THCIC_CSV_STAGE
  FILE_FORMAT = (TYPE = CSV SKIP_HEADER = 1 FIELD_OPTIONALLY_ENCLOSED_BY = '"');
```

### Step 4.4 — Upload the seed CSVs and load initial lookup data

Upload all `csv/stg_lkp_*.csv` files to the stage, then run:

```bash
03_copy_into_stg_lkp.sql   -- loads STG_LKP_* tables
```

After validating (section 6), run:

```bash
04_promote_stg_to_lkp.sql  -- populates LKP_* tables for the first time
```

### Step 4.5 — Load the first quarter of PUDF data

Follow the quarterly steps in Section 5 below.

---

## 5. Quarterly Execution Steps

Perform these steps every quarter when DSHS releases a new PUDF.

> Replace `2025Q1` with the actual quarter in every script and command before running.

---

### Step 5.1 — Identify the quarter

Determine the `YEAR_QUARTER` value from the downloaded file names or the DSHS website.

| Quarter | Months | YEAR_QUARTER Value |
|---------|--------|--------------------|
| Q1 | January – March | `2025Q1` |
| Q2 | April – June | `2025Q2` |
| Q3 | July – September | `2025Q3` |
| Q4 | October – December | `2025Q4` |

> **Note:** Late submissions from the prior quarter can appear in the current quarter's file. Always check the `DISCHARGE` column distribution after loading.

---

### Step 5.2 — Check for User Manual updates

1. Go to [https://www.dshs.texas.gov/THCIC](https://www.dshs.texas.gov/THCIC)
2. Download the current PUDF User Manual PDF
3. Compare the "Last Updated" date on the cover page against the prior quarter
4. If the manual changed, review the Data Dictionary section for:
   - New fields added to any file
   - Fields moved between files (this has happened before — e.g., Grouper File was added in 2022)
   - New or retired coding scheme values
5. Update the relevant `stg_lkp_<name>.csv` files if coding schemes changed
6. If table structure changed, update `01_inpatient_stg_ddl.sql` and `ALTER TABLE` in Snowflake

---

### Step 5.3 — Download PUDF files from DSHS

1. Submit a data request at [https://www.dshs.texas.gov/THCIC](https://www.dshs.texas.gov/THCIC) if you do not have an active license
2. Download the **CSV (comma-delimited)** versions of all 5 files for the target quarter
3. Confirm file sizes are plausible against the expected ranges in Section 2
4. Name files consistently — see Section 10 for the naming convention

---

### Step 5.4 — Update YEAR_QUARTER in all scripts

Before running any SQL, do a find-and-replace across these files:

| File | String to replace |
|------|------------------|
| `03_copy_into_stg_lkp.sql` | `2025Q1` → new quarter |
| `04_promote_stg_to_lkp.sql` | `2025Q1` → new quarter |
| `05_quarterly_validation.sql` | `2025Q1` → new quarter |

> **Important:** These scripts contain hardcoded quarter values by design — they must be explicit so you can re-run them safely without accidentally overwriting a different quarter's data.

---

### Step 5.5 — Upload files to Snowflake stage

```sql
-- Upload PUDF data files
PUT file://path/to/base1_2025Q1.csv @THCIC.THCIC_CSV_STAGE;
PUT file://path/to/base2_2025Q1.csv @THCIC.THCIC_CSV_STAGE;
PUT file://path/to/charges_2025Q1.csv @THCIC.THCIC_CSV_STAGE;
PUT file://path/to/facility_2025Q1.csv @THCIC.THCIC_CSV_STAGE;
PUT file://path/to/grouper_2025Q1.csv @THCIC.THCIC_CSV_STAGE;

-- Upload coding scheme CSVs (only needed if CSVs changed this quarter)
PUT file://path/to/csv/stg_lkp_*.csv @THCIC.THCIC_CSV_STAGE;
```

---

### Step 5.6 — Load coding scheme staging tables

```bash
03_copy_into_stg_lkp.sql
```

This truncates all `STG_LKP_*` tables and reloads them from the current quarter's CSVs.

---

### Step 5.7 — Load PUDF data into staging tables

Use `COPY INTO` with your file format spec. Example for CSV Base Data #1:

```sql
COPY INTO THCIC.STG_IP_BASE1
  FROM (
    SELECT $1, $2, $3, $4, $5,   -- ... all columns in order ...
           '2025Q1'               -- YEAR_QUARTER injected at load time
    FROM @THCIC.THCIC_CSV_STAGE/base1_2025Q1.csv
  )
  FILE_FORMAT = (
    TYPE = CSV
    FIELD_DELIMITER = ','
    SKIP_HEADER = 0
    NULL_IF = ('')
  )
  ON_ERROR = 'CONTINUE';         -- log errors, don't halt; review COPY history
```

> The `YEAR_QUARTER` column is not present in the PUDF files. It must be injected as a literal in the `SELECT` clause of the `COPY INTO` statement, as shown above.

Repeat for BASE2, CHARGES, FACILITY_TYPE, and GROUPER.

---

### Step 5.8 — Run validation

```bash
05_quarterly_validation.sql
```

Review each result set. See Section 6 for what to look for and what to do.

---

### Step 5.9 — Promote lookup tables

Only after validation passes:

```bash
04_promote_stg_to_lkp.sql
```

---

### Step 5.10 — Archive and document

1. Note the row counts from validation in your team's log or this table:

| Quarter | BASE1 Rows | CHARGES Rows | Hospitals | Notes |
|---------|-----------|-------------|-----------|-------|
| 2025Q1 | 843,945 | 16,667,768 | 712 | Initial load |
| 2025Q2 | *(fill in)* | *(fill in)* | *(fill in)* | |

2. Move loaded stage files to an archive prefix or delete them from the stage
3. Update the `YEAR_QUARTER` values in scripts back to a placeholder (optional) to prevent accidental reruns

---

## 6. Validation Checks

All validation queries are in `05_quarterly_validation.sql`. Here is what each check means and what action to take.

### Check 1 — Row counts on coding scheme staging

**What it checks:** Each `STG_LKP_*` table has at least 1 row for the new quarter.

**Pass:** All tables show > 0 rows.

**Fail:** If any table shows 0 rows, the CSV was not loaded. Re-upload the CSV and rerun `03_copy_into_stg_lkp.sql`.

---

### Check 2 — New codes not in master LKP

**What it checks:** Codes present in `STG_LKP_*` for this quarter that do not exist in the corresponding `LKP_*` table.

**Pass:** Empty result set (no new codes).

**If rows returned:** Review the new codes. Determine if they represent:
- A legitimate DSHS coding scheme change (e.g., new patient status code effective 10-1-2024)
- A data error in the CSV

If legitimate: update the CSV file to include the new code for future runs, then proceed with promotion — the MERGE will insert the new code automatically.

If error: correct the CSV, re-truncate the staging table, reload, and re-validate.

---

### Check 3 — Retired codes (in LKP but not in new STG)

**What it checks:** Codes that exist in the master `LKP_*` but are absent from the current quarter's staging load.

**Pass:** Empty result set.

**If rows returned:** This is not necessarily an error. Review each code:
- If DSHS retired the code, update `EFFECTIVE_TO` in the master `LKP_*` table manually after promotion
- If the code should still be active and is missing from the CSV, investigate and correct

Do not let this block promotion unless you determine the CSV is missing valid active codes.

---

### Check 4 — Description changes

**What it checks:** Codes where the DESCRIPTION in staging differs from the master LKP.

**Pass:** Empty result set.

**If rows returned:** Review each. DSHS occasionally clarifies wording. If intentional, the MERGE in Step 5.9 will update the description automatically. Document the change in your log.

---

### Check 5 — Main staging table row counts

**What it checks:** BASE1 and CHARGES row counts grouped by YEAR_QUARTER.

**Pass:** Single row per query showing the newly loaded quarter with a plausible count (BASE1 ≈ 840K–870K; CHARGES ≈ 16–17M).

**Fail indicators:**
- Count is 0 → load did not complete
- Two YEAR_QUARTER values returned → staging table was not truncated before load, or late submissions from prior quarter are present (check the `DISCHARGE` column for prior-quarter dates — this is expected and documented in the PUDF User Manual)
- Count is implausibly low (< 500K for BASE1) → check `COPY INTO` error logs

---

### Check 6 — Orphan charge records

**What it checks:** Rows in `STG_IP_CHARGES` with no matching `RECORD_ID` in `STG_IP_BASE1` for the same `YEAR_QUARTER`.

**Pass:** 0 orphan records.

**If non-zero:** Investigate whether BASE1 and CHARGES were loaded from the same quarter's files. A mismatch in file selection is the most common cause.

---

### Check 7 — YEAR_QUARTER consistency

**What it checks:** Verifies that `STG_IP_BASE1` contains only the expected quarter.

**Pass:** Single row showing the new quarter.

**If multiple quarters appear:** A prior quarter's data was not truncated. Decide whether you want to retain multi-quarter history in staging or truncate to the current quarter before proceeding.

---

## 7. Promotion: STG_LKP → LKP

The promotion script (`04_promote_stg_to_lkp.sql`) uses a `MERGE` statement for each coding scheme table. The merge logic:

| Scenario | Action |
|----------|--------|
| Code exists in LKP, description unchanged | No action |
| Code exists in LKP, description changed | Updates `DESCRIPTION`, sets `EFFECTIVE_TO = NULL` (marks as current) |
| Code in STG but not in LKP | Inserts new row with `EFFECTIVE_FROM = current quarter`, `EFFECTIVE_TO = NULL` |
| Code in LKP but not in STG | No automatic action — review Check 3 output and manually set `EFFECTIVE_TO` if the code was retired |

After promotion, verify with:

```sql
SELECT COUNT(*) FROM THCIC.LKP_PAT_STATUS;
SELECT * FROM THCIC.LKP_PAT_STATUS WHERE EFFECTIVE_TO IS NOT NULL;  -- retired codes
```

---

## 8. Troubleshooting

### COPY INTO fails with "Number of columns in file does not match table"

The PUDF fixed-width format has changed or you are using the wrong file format. Confirm you are using the **CSV (comma-delimited)** version and that the column count matches the DDL. Check the PUDF User Manual for structural changes (see Step 5.2).

### COPY INTO error: "YEAR_QUARTER column missing"

The `YEAR_QUARTER` column is not in the PUDF files. You must inject it as a literal in the `SELECT` clause of the `COPY INTO` statement. See the example in Step 5.7.

### Row count in BASE1 is lower than expected

Check `COPY_HISTORY` in Snowflake:
```sql
SELECT * FROM TABLE(INFORMATION_SCHEMA.COPY_HISTORY(
  TABLE_NAME => 'STG_IP_BASE1',
  START_TIME => DATEADD(HOURS, -2, CURRENT_TIMESTAMP())
));
```
Look at `ROWS_LOADED` vs `ROWS_PARSED` and the `ERROR_COUNT` column.

### Charges orphan check returns thousands of mismatches

The most common cause is loading BASE1 and CHARGES from different quarters. Verify the file names and re-load from the correct pair.

### DSHS released a correction to a prior quarter

DSHS occasionally rereleases a quarter with corrections. When this happens:
1. Download the corrected files
2. Truncate the affected `STG_IP_*` tables (filter by `YEAR_QUARTER` if you retain history)
3. Reload using the corrected files
4. Re-run validation
5. Note the correction in your quarterly log

### New field added to PUDF in mid-year

DSHS documents new fields in the User Manual with an "Added YYYY" note. When a new field appears:
1. `ALTER TABLE THCIC.STG_IP_BASE1 ADD COLUMN <field> <type> COMMENT '...'`
2. Update the `01_inpatient_stg_ddl.sql` script so the next full recreation picks it up
3. Add the field to the `COPY INTO` `SELECT` list

---

## 9. YEAR_QUARTER Reference

| Value | Covers | DSHS Release Window |
|-------|--------|---------------------|
| `2025Q1` | Jan 1 – Mar 31, 2025 | ~May–June 2025 |
| `2025Q2` | Apr 1 – Jun 30, 2025 | ~Aug–Sep 2025 |
| `2025Q3` | Jul 1 – Sep 30, 2025 | ~Nov–Dec 2025 |
| `2025Q4` | Oct 1 – Dec 31, 2025 | ~Feb–Mar 2026 |
| `2026Q1` | Jan 1 – Mar 31, 2026 | ~May–June 2026 |

> DSHS requires hospitals to submit data no later than 60 days after the close of a calendar quarter. Late submissions from the prior quarter can appear in the current release. This is expected behavior documented in the PUDF User Manual.

---

## 10. File Naming Convention

Use a consistent naming pattern for the raw PUDF files you download and stage:

```
thcic_ip_base1_<YEAR>_<Q>.csv
thcic_ip_base2_<YEAR>_<Q>.csv
thcic_ip_charges_<YEAR>_<Q>.csv
thcic_ip_facility_<YEAR>_<Q>.csv
thcic_ip_grouper_<YEAR>_<Q>.csv
```

Examples for 2025 Q1:
```
thcic_ip_base1_2025_q1.csv
thcic_ip_charges_2025_q1.csv
```

Store downloaded files in a local or cloud archive before staging:
```
/archive/thcic/inpatient/2025/q1/
```

---

## 11. Change Log

| Quarter | Changed By | Notes |
|---------|-----------|-------|
| 2025Q1 | *(your name)* | Initial pipeline setup. Tables created from DSHS Document E25-14163 (March 2026). |
| | | |

---

*End of runbook. Questions or corrections → update this document and the Change Log above.*
