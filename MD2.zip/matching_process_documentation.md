# Evident MIS Intercompany Reconciliation — Matching Process Documentation

**Engagement:** Evident MIS (Medical Imaging Systems) Intercompany Reconciliation Automation
**Period:** March 2026 (FY2026)
**Scope:** 17 entities, 35+ bilateral pairs
**Source files referenced throughout:**
- `interco_recon_process_automation.xlsx` (process spec)
- `Interco_recon_mis_mar26.xlsx` (consolidated workbook / "answer book")
- `mar26_files.zip` (69 supporting files: 16 Interco Templates + 53 bilateral pair files)

---

# Part 1 — Overall Matching Process

The reconciliation runs as a four-phase pipeline. The first phase reconciles balances at the GL account level. If the two sides agree, work stops. If they disagree, the variance triggers progressively more sophisticated invoice-level matching: deterministic first, then fuzzy, then AI-assisted classification. Each phase's output produces either a clean reconciliation, an item routed to a HITL queue, or an item escalated to the next phase.

```
┌──────────────────────────────────────────────────────────────────────┐
│   Phase 1: GL BALANCE RECONCILIATION                                 │
│   For each (entity_pair, OS_account, currency): sum signed amounts   │
│   ── if variance ≈ 0 ──→  RECONCILED  (no further work)              │
│   ── if variance > tolerance ──→  trigger Phase 2                    │
└──────────────────────────────────────────────────────────────────────┘
                                    ↓
┌──────────────────────────────────────────────────────────────────────┐
│   Phase 2: DETERMINISTIC LINE-LEVEL MATCHING                         │
│   Invoice-level match using rules: ICP code, invoice/doc number,     │
│   amount, currency, date, posting month                              │
│   ── confidence = 1.00 ──→  CONFIRMATION QUEUE                       │
│   ── 0.50 ≤ confidence < 1.00 ──→  REVIEW QUEUE  (HITL)              │
│   ── confidence < 0.50 ──→  trigger Phase 3                          │
└──────────────────────────────────────────────────────────────────────┘
                                    ↓
┌──────────────────────────────────────────────────────────────────────┐
│   Phase 3: CORTEX FUZZY MATCHING                                     │
│   Embed unmatched lines, find nearest neighbours by cosine sim       │
│   Combine semantic similarity + amount proximity + date proximity    │
│   ── AI confidence ≥ 0.80 ──→  FUZZY APPROVAL QUEUE  (HITL)          │
│   ── 0.60 ≤ AI confidence < 0.80 ──→  REVIEW QUEUE  (HITL)           │
│   ── AI confidence < 0.60 ──→  trigger Phase 4                       │
└──────────────────────────────────────────────────────────────────────┘
                                    ↓
┌──────────────────────────────────────────────────────────────────────┐
│   Phase 4: AI-ASSISTED CLASSIFICATION                                │
│   For each residual variance, Cortex Complete classifies root cause  │
│   and proposes a journal entry to clear it                           │
│   ── Output: root_cause + reasoning + proposed JE                    │
│   ── All output ──→  CLASSIFICATION APPROVAL QUEUE  (HITL)           │
└──────────────────────────────────────────────────────────────────────┘
```

The progression is a deliberate "spend computation only when needed" design. Phase 1 is cheap SQL aggregation. Phase 2 is rule-based SQL JOINs. Phase 3 invokes vector embeddings (~$0.0001 per line). Phase 4 invokes Cortex Complete (~$0.01 per residual). For a typical month with most pairs balancing at Phase 1, the AI cost is tiny.

---

## 1.1 Phase 1: GL Balance Reconciliation

**Purpose:** Determine whether the two sides of a bilateral pair agree at the GL balance level, broken down by OneStream account and currency. This is the "do the totals match" check.

**Inputs:**
- All invoice/balance lines for both entities of the pair, for the period
- The reference mapping `REF_ENTITY_GL_ACCOUNTS` (from `Mar'26 accounts` tab — 98 rows mapping each entity's local SAP GL account to a OneStream consolidation account and a category)

**Grouping dimensions:**
1. `pair_id` — e.g., EJP-ECN
2. `os_account` — the OneStream consolidation account (e.g., `1122100100` Trade Accounts Receivables Intercompany)
3. `category` — Trade / Non-Trade / Loan / Accrued Interest / Transfer Pricing
4. `doc_currency` — the document currency (USD, CNY, EUR, JPY, etc.)

**Computation:**

For each (pair, os_account, category, currency):
```
side_A_sum = SUM(doc_amount) where entity = pair.entity_A AND counterparty = pair.entity_B
side_B_sum = SUM(doc_amount) where entity = pair.entity_B AND counterparty = pair.entity_A

variance_doc_curr = side_A_sum + side_B_sum    -- expect ≈ 0 (one side debit, one side credit)
variance_pct      = ABS(variance_doc_curr) / GREATEST(ABS(side_A_sum), ABS(side_B_sum))
```

**Decision rule:**

| Condition | Outcome |
|-----------|---------|
| `ABS(variance_doc_curr) < 1.00` (i.e., rounding) | RECONCILED — confidence 1.00 |
| `variance_pct < 0.001` (0.1% tolerance) | RECONCILED — confidence 1.00 |
| Otherwise | TRIGGER PHASE 2 — variance flagged for line-level drill-down |

**Output table:** `RESULTS.PHASE1_BALANCE_RECON` (one row per pair × os_account × currency × period)

**Worked example — EJP-ECN, March 2026:**

| OS Account | OS Description | Currency | Side A (EJP) | Side B (ECN) | Variance | Verdict |
|------------|----------------|----------|--------------|--------------|----------|---------|
| 1122100100 | Trade A/R Intercompany | USD | 4,217,832.50 | -4,217,832.50 | 0.00 | RECONCILED |
| 1122100100 | Trade A/R Intercompany | CNY | 8,945,221.30 | -3,517,112.80 | -5,428,108.50 | TRIGGER PHASE 2 |
| 1124100100 | Other Receivable Intercompany | USD | 12,500.00 | -12,500.00 | 0.00 | RECONCILED |

The USD trade balances reconcile cleanly. The CNY trade variance of -5,428,108.50 (ECN booked CNY 5.4M of invoices that EJP hasn't recorded yet) triggers Phase 2 drill-down.

---

## 1.2 Phase 2: Deterministic Line-Level Matching

Triggered when Phase 1 detects a variance for a (pair, OS account, currency) tuple. Drills into the individual invoices and tries to match them using deterministic rules.

There are two matching procedures depending on the category. **Trade** uses a 10-step procedure driven by invoice number; **Non-Trade** uses a 7-step procedure driven by amount and posting month (Non-Trade items often have no invoice number).

### 1.2.1 Trade matching — 10-step procedure with confidence formula

For each line on Side A, find a candidate line on Side B and score it on six criteria. The total confidence is the weighted sum:

```
confidence = 0.30 × ICP_match + 0.20 × invoice_match + 0.20 × doc_curr_match
           + 0.20 × amount_match + 0.05 × doc_date_match + 0.05 × posting_month_match
```

Each criterion returns 0 or 1.

| Criterion | Weight | Rule |
|-----------|--------|------|
| `ICP_match` | 0.30 | counterparty entity code on Side A == entity code on Side B |
| `invoice_match` | 0.20 | invoice number / document number matches between sides |
| `doc_curr_match` | 0.20 | document currency matches |
| `amount_match` | 0.20 | absolute amounts agree (within 0.01 tolerance) |
| `doc_date_match` | 0.05 | document dates agree (or within 5-day window) |
| `posting_month_match` | 0.05 | posting month agrees (0/1; can be ±1 month for cross-period) |

Total possible: 1.00.

The 10 "steps" in the Process tab decompose this into specific invoice-discovery passes (e.g., "step 1: try invoice number lookup; step 2: try by amount + currency"). They produce candidate pairs that get scored.

**Routing by confidence:**

| Confidence | Route |
|------------|-------|
| `= 1.00` | CONFIRMATION QUEUE — display as matched |
| `≥ 0.80` and `< 1.00` | REVIEW QUEUE — HITL eyeballs and approves (e.g., one-day date drift, slight amount difference from forex) |
| `≥ 0.50` and `< 0.80` | REVIEW QUEUE — HITL with explicit warning |
| `< 0.50` | Forward to Phase 3 (fuzzy matching) |

**Worked example — EJP-ECN CNY Trade variance, March 2026:**

After Phase 2 deterministic matching:

| Outcome | Count | Notes |
|---------|-------|-------|
| Confidence = 1.00 (perfect match) | 246 lines | Both ICP, invoice, currency, amount, date, posting month all agree |
| Confidence 0.80-0.95 (review queue) | 19 lines | Mostly: invoice numbers agree but date drift > 5 days |
| Confidence < 0.50 (one-sided) | 72 lines | ECN-side only — no EJP counterpart found; classic "EJP hasn't booked yet" pattern |

**Total reconciled in Phase 1+2: 163 (USD) + 246 (CNY perfect) + 19 (CNY review) = 428 EJP lines** — this is the validation number we already reproduced from the manual reconciliation.

The 72 unmatched ECN lines totalling CNY 5,428,108.50 forward to Phase 3.

### 1.2.2 Non-Trade matching — 7-step procedure with confidence formula

Non-trade items (loans, accrued interest, transfer pricing fees, royalties, other receivables/payables) typically don't have an invoice number to match on. The matching uses amount + currency + posting month + ICP as the key signals.

```
confidence = 0.30 × ICP_match + 0.05 × Date_1_match + 0.10 × DocCurr_match
           + 0.50 × Amount_match + 0.05 × Date_2_match
```

Note the heavy weight on amount (0.50) — this is the dominant signal when invoice numbers don't exist. Date_1 and Date_2 are typically posting date and document date (or a 1-month look-ahead variant for accruals).

| Criterion | Weight | Rule |
|-----------|--------|------|
| `ICP_match` | 0.30 | counterparty entity code matches |
| `Date_1_match` | 0.05 | first date dimension (usually posting month) |
| `DocCurr_match` | 0.10 | document currency matches |
| `Amount_match` | 0.50 | absolute amounts agree (within 0.01 tolerance) |
| `Date_2_match` | 0.05 | second date dimension (or look-ahead month) |

Total possible: 1.00. Routing thresholds same as Trade.

---

## 1.3 Phase 3: Cortex Fuzzy Matching (Logic)

Triggered for lines that Phase 2 couldn't deterministically match. Two common reasons a line falls through:
1. The counterparty's bilateral key differs (e.g., Side A used the original PO number, Side B used a remit number)
2. The amounts diverge slightly due to forex revaluation between the two sides

**Approach:** Embed each unmatched line's text descriptor using `snowflake-arctic-embed-l-v2.0`, then for each Side A unmatched line, find the K=5 nearest Side B unmatched lines by cosine similarity. Combine semantic similarity with deterministic numeric proximity into a single AI confidence score.

**Embedding input — concatenated descriptor:**

```
"{ICP_code} | {invoice_no} | {doc_currency} | {abs(amount) rounded} | 
 {posting_month} | {sap_account_description} | {free_text_remarks}"
```

This produces a 1024-dim embedding per line.

**Composite AI confidence formula:**

```
ai_confidence = 0.50 × cosine_similarity
              + 0.30 × amount_proximity
              + 0.20 × date_proximity

where:
  amount_proximity = 1 - MIN(1, ABS(amount_A - amount_B) / GREATEST(ABS(amount_A), ABS(amount_B)))
  date_proximity   = 1 - MIN(1, ABS(date_A - date_B) / 30 days)
```

**Routing by AI confidence:**

| AI Confidence | Route |
|---------------|-------|
| `≥ 0.80` | FUZZY APPROVAL QUEUE — HITL approves the match |
| `0.60 - 0.80` | REVIEW QUEUE — explicit warning, HITL inspects both sides |
| `< 0.60` | Forward to Phase 4 (AI-assisted classification — treat as residual) |

**Practical reasoning seen in the data:**

For the EJP-ETCE pair, the consolidated workbook (`MISvsMIS` tab) shows residual variance JPY 476,720 attributed to "forex issue." The pattern is:
- Both sides have the same invoice (same vendor, same PO)
- Side A booked at one forex rate, Side B at another, leaving a small JPY difference
- Cosine similarity between line descriptors is ~0.92 (same vendor, same description)
- Amount proximity is ~0.5 (small JPY gap, but proportionally ~5%)
- Date proximity is 1.0 (same day)
- Combined AI confidence ≈ 0.86 → routes to FUZZY APPROVAL QUEUE with note "Likely forex revaluation difference"

The HITL controller sees the side-by-side, agrees, and approves — the pair is reconciled, the residual JPY gap is recorded as a forex difference (not a true booking mismatch).

---

## 1.4 Phase 4: AI-Assisted Classification (Logic)

Triggered for residuals that even fuzzy matching couldn't pair. These are typically genuine mismatches — one side has booked something the other hasn't, or an accrual has been classified differently. Phase 4 uses Cortex Complete (claude-3-5-sonnet) to classify the root cause and propose a journal entry.

**Inputs to the LLM:**
1. The orphan line(s) on each side (or the pair-level residual amount)
2. The recent history of similar pairs (3-5 nearest matches from `REF_KNOWN_ISSUES`)
3. Few-shot examples from `Entry Summary` historical data
4. The relevant plug account (from `REF_ENTITY_GL_ACCOUNTS.PLUG_ACCOUNT`)

**Prompt template (abbreviated):**

```
You are a senior intercompany controller for Evident. You receive an unreconciled
intercompany variance between {entity_A} and {entity_B} for {period}.

VARIANCE DETAILS:
  Pair:                    {entity_A} ↔ {entity_B}
  OS Account:              {os_account} ({os_description})
  Category:                {category}
  Currency:                {doc_currency}
  Side A booked amount:    {side_A_amount}
  Side B booked amount:    {side_B_amount}
  Net variance:            {variance_amount}
  Number of unmatched A:   {unmatched_count_A}
  Number of unmatched B:   {unmatched_count_B}

LINES ON SIDE A (unmatched):
  {line_details_A}

LINES ON SIDE B (unmatched):
  {line_details_B}

KNOWN RECURRING ISSUES (most similar):
  {known_issues}

HISTORICAL SIMILAR RESOLUTIONS (few-shot):
  {entry_summary_examples}

PLUG ACCOUNTS:
  {entity_A} plug:         {plug_account_A}
  {entity_B} plug:         {plug_account_B}

Classify the root cause and propose a journal entry to clear the variance.
Respond in JSON only.
```

**Expected output schema:**

```json
{
  "root_cause_category": "MISSING_BOOKING | FOREX_DIFFERENCE | TIMING_DIFFERENCE | RECLASSIFICATION | DATA_ENTRY_ERROR | OTHER",
  "confidence": 0.0,
  "reasoning": "Free-text explanation of the analysis",
  "suggested_action": "PROPOSE_JE | INVESTIGATE | IGNORE | ESCALATE",
  "proposed_journal": {
    "booking_entity": "EEU",
    "lines": [
      { "dr_or_cr": "DR", "sap_account": "0000010015", "description": "Man Inv Adj Merch", "amount": 99550.00, "currency": "USD" },
      { "dr_or_cr": "CR", "sap_account": "105400",     "description": "Trade A/P OG",       "amount": 99550.00, "currency": "USD" }
    ],
    "narrative": "Booking SPIND invoice 99,550 not yet recorded by EEU"
  },
  "similar_issue_id": null
}
```

**Worked example — EEU vs SPIND USD 99,550 variance (from Entry Summary tab):**

Input: pair EEU-SPIND, OS account 2112100100 (Trade A/P), USD, residual 99,550. SPIND has one AR line of USD 99,550 with no EEU counterpart.

Output (matching the manual journal in Entry Summary):
```json
{
  "root_cause_category": "MISSING_BOOKING",
  "confidence": 0.95,
  "reasoning": "SPIND has booked the AR but EEU has no offsetting AP. Single invoice, exact amount match, classic 'one side hasn't booked yet' pattern. The Phase 2 drill-down found no EEU line for this invoice number.",
  "suggested_action": "PROPOSE_JE",
  "proposed_journal": {
    "booking_entity": "EEU",
    "lines": [
      { "dr_or_cr": "DR", "sap_account": "0000010015", "description": "Man Inv Adj Merch", "amount": 99550.00, "currency": "USD" },
      { "dr_or_cr": "CR", "sap_account": "105400",     "description": "Trade A/P OG",       "amount": 99550.00, "currency": "USD" }
    ],
    "narrative": "Booking SPIND invoice 99,550 not yet recorded by EEU"
  },
  "similar_issue_id": null
}
```

This is identical to what the manual process produced in `Entry Summary` row 6-7. Each Entry Summary case becomes a few-shot example for the prompt.

**Routing:**
All Phase 4 outputs route to the `CLASSIFICATION APPROVAL QUEUE` (HITL). Controllers review the AI's reasoning, accept the proposed journal as-is, edit it, or reject it. Approved journals export to a journal-import file for SAP/NetSuite.

---

## 1.5 Pipeline Output Per Pair

For a single bilateral pair, the four phases produce a layered set of outputs:

```
                                Status                           Where it goes
─────────────────────────────────────────────────────────────────────────────────────
Phase 1 Reconciled balances    "DONE — totals agree"            Dashboard (green)
Phase 2 Confirmation matches   conf = 1.00                       Dashboard / archive
Phase 2 Review queue           0.50 ≤ conf < 1.00                HITL Review Queue
Phase 3 Fuzzy approvals        AI conf ≥ 0.80                    HITL Fuzzy Queue
Phase 3 Review queue           0.60 ≤ AI conf < 0.80             HITL Review Queue
Phase 4 AI proposals           any                               HITL Classification Queue
Residual after all approvals   variance still > 0                Dashboard (amber/red)
                                                                  → next month carry-forward
```

The dashboard shows the layered count and total monetary value of each bucket per pair. The HITL queues drive the controllers' work each month-end.

---

# Part 2 — By File

## 2.1 `interco_recon_process_automation.xlsx` (Process Specification)

**File purpose:** This is the master rulebook. It defines the matching procedure, the entity codes, the GL-account-to-category mappings, and the OneStream chart of accounts mapping. **Read once. Load reference data into Snowflake. Treat as read-only thereafter.**

**Tab inventory:**

| Tab | Rows × Cols | Purpose | Relevance | Action |
|-----|-------------|---------|-----------|--------|
| Process | ~30 × 8 | The 10-step Trade and 7-step Non-Trade matching procedures, with the confidence-scoring formulas | **HIGH** — encodes the matching algorithm | Read; implement as logic in Phase 2 stored procedure |
| Sheet3 | (utility) | Working notes | NONE | Ignore |
| Entity accounts (Table) | 94 × 8 | Per-entity SAP GL accounts with category labels (Trade/Non-Trade/etc.) | **MEDIUM** — superseded by `Mar'26 accounts` (which has 98 rows + OneStream + plug) | Skip; use `Mar'26 accounts` instead |
| Entity accounts | (raw form) | Earlier draft of above | NONE | Skip |
| Sheet8 | (utility) | Working notes | NONE | Ignore |
| Sheet7 | (utility) | Working notes | NONE | Ignore |
| **Mar'26 accounts** | **98 × 12** | **Canonical mapping: Entity / SAP GL / OneStream account / Plug account / "Category for AI project"** | **CRITICAL** — primary reference data source | **EXTRACT** → load to `REF.REF_ENTITY_GL_ACCOUNTS` |
| OS accounts | (long list) | OneStream chart of accounts master | NONE for matching | Skip per user's note |
| Sheet6 / Sheet2 | (utility) | Working notes | NONE | Ignore |
| flowchart | (image) | Process flowchart | NONE for ETL | Reference only |

**Data to extract for Snowflake — only the `Mar'26 accounts` tab:**

```sql
CREATE TABLE REF.REF_ENTITY_GL_ACCOUNTS (
    ENTITY_SAP_CODE         VARCHAR(10),       -- e.g. "1096"
    ENTITY_CODE             VARCHAR(10),       -- e.g. "EJP"
    SAP_GL_ACCOUNT          VARCHAR(20),       -- e.g. "23203012"
    SAP_ACCOUNT_DESCRIPTION VARCHAR(200),
    ONESTREAM_ACCOUNT       VARCHAR(20),       -- e.g. "1122100100" — Phase 1 grouping key
    ONESTREAM_DESCRIPTION   VARCHAR(200),
    PLUG_ACCOUNT            VARCHAR(20),       -- e.g. "2177000100" — Phase 4 JE offset
    PLUG_DESCRIPTION        VARCHAR(200),
    CATEGORY                VARCHAR(50),       -- "Trade" | "Non-trade" | "Loan" | "Transfer pricing" | "Accrued interest income and expenses"
    REMARKS                 VARCHAR(500),
    LOAD_DATE               TIMESTAMP_NTZ,
    LOAD_FILE_HASH          VARCHAR(64),
    PRIMARY KEY (ENTITY_CODE, SAP_GL_ACCOUNT)
);
```

Loader: parse rows 2 through 99 from the `Mar'26 accounts` tab. 98 rows expected.

---

## 2.2 `Interco_recon_mis_mar26.xlsx` (Consolidated Workbook / "Answer Book")

**File purpose:** This is the manually-prepared monthly reconciliation deliverable. The accounting team produces it by working through every pair and resolving residuals manually. For automation purposes, it serves three roles: **regression test target** (per-pair residuals from `MISvsMIS`), **few-shot training data** (`Entry Summary` worked journal proposals), and **per-pair detail reference** (the per-pair tabs).

**Tab inventory:**

| Tab | Rows × Cols | Purpose | Relevance | Action |
|-----|-------------|---------|-----------|--------|
| Lookup | ~30 × 5 | Generic lookup tables | NONE | Skip |
| Compilation Oct'25 | (historical) | Prior period workings | NONE for current | Skip |
| **Entry Summary** | 50 × 15 | Worked journal proposals per pair-residual: SAP code, description, amount, ICP, segment, remark | **HIGH** — Phase 4 few-shot training corpus | **EXTRACT** → `TRAINING.PHASE4_FEW_SHOT_EXAMPLES` |
| Forex | ~50 × 5 | Period exchange rates (USD/JPY, EUR/JPY, etc.) | **HIGH** — needed for currency translation | **EXTRACT** → `REF.REF_FOREX_RATES` |
| List of intercompany | ~20 × 4 | All entity codes and names | **MEDIUM** — confirms entity master | **EXTRACT** → `REF.REF_ENTITIES` |
| Compilation | ~200 × 15 | Master pivot of all pair-account-currency combinations | **HIGH** — Phase 1 expected output structure (regression target) | **EXTRACT** → `REGRESSION.COMPILATION_TARGETS` |
| **MISvsMIS** | 44 × 11 | Per-pair residual summary in JPY and USD with manual adjustment column and remarks | **CRITICAL** — primary regression test target per pair | **EXTRACT** → `REGRESSION.PAIR_RESIDUAL_TARGETS` |
| MIS - EEU vs SPIND | ~30 × 17 | Detailed breakdown for that pair | **HIGH** — per-pair regression detail | EXTRACT → `REGRESSION.PAIR_DETAIL_TARGETS` |
| MIS - ETCE vs ECN | ~30 × 17 | Same pattern | HIGH | Same |
| MIS - EJP vs ETCE | ~30 × 17 | Same pattern | HIGH | Same |
| MIS - ETCE vs ESG | ~30 × 17 | Same pattern | HIGH | Same |
| MIS - ETCE vs MIS-USA | ~30 × 17 | Same pattern | HIGH | Same |
| MIS-EJPvsENF | ~30 × 17 | Same pattern | HIGH | Same |
| MIS-EJPvsEUSAMISUSA | ~30 × 17 | Same pattern | HIGH | Same |
| MIS-EUSAvsETCE | ~30 × 17 | Same pattern | HIGH | Same |
| Status | ~10 × 5 | Status by pair (open / closed / under review) | LOW | Skip |
| TNM&MIS-ESGvsEJP (ss) | ~30 × 17 | Mixed segment | HIGH | Same |
| MIS_ENFvsEGZ | ~30 × 17 | Same pattern | HIGH | Same |
| MIS-ECNvsETCE | ~30 × 17 | Same pattern | HIGH | Same |
| EJPbefore11Dec for ref | (historical) | Reference workings | NONE | Skip |

**Data to extract — five tables:**

### `REF.REF_ENTITIES` (from `List of intercompany` tab)

```sql
CREATE TABLE REF.REF_ENTITIES (
    ENTITY_SAP_CODE         VARCHAR(10) PRIMARY KEY,    -- e.g. "1096", "5043", "2017A"
    ENTITY_CODE             VARCHAR(10),                -- e.g. "EJP", "ECN", "MIS-CND"
    ENTITY_FULL_NAME        VARCHAR(200),               -- e.g. "Evident Japan Corporation"
    REGION                  VARCHAR(20),                -- e.g. "APAC", "EMEA", "AMERICAS"
    SEGMENT                 VARCHAR(20),                -- e.g. "MIS", "TNM", "Both"
    CURRENCY_FUNCTIONAL     VARCHAR(3),                 -- e.g. "JPY", "USD", "EUR"
    LOAD_DATE               TIMESTAMP_NTZ
);
```

### `REF.REF_FOREX_RATES` (from `Forex` tab)

```sql
CREATE TABLE REF.REF_FOREX_RATES (
    PERIOD                  DATE,                       -- e.g. 2026-03-31
    FROM_CURRENCY           VARCHAR(3),                 -- e.g. "USD"
    TO_CURRENCY             VARCHAR(3),                 -- e.g. "JPY"
    RATE                    NUMBER(20,8),
    RATE_TYPE               VARCHAR(20),                -- "MONTH_END" | "AVG"
    LOAD_DATE               TIMESTAMP_NTZ,
    PRIMARY KEY (PERIOD, FROM_CURRENCY, TO_CURRENCY, RATE_TYPE)
);
```

### `TRAINING.PHASE4_FEW_SHOT_EXAMPLES` (from `Entry Summary` tab)

```sql
CREATE TABLE TRAINING.PHASE4_FEW_SHOT_EXAMPLES (
    EXAMPLE_ID              VARCHAR(50) PRIMARY KEY,    -- e.g. "MIS-EEUvsSPIND-202603-01"
    PAIR_ID                 VARCHAR(50),                -- e.g. "EEU-SPIND"
    PERIOD                  DATE,
    VARIANCE_DESCRIPTION    VARCHAR(500),               -- e.g. "EEU has SPIND-related variance of USD 99,550 — single invoice not booked"
    ROOT_CAUSE_CATEGORY     VARCHAR(50),                -- "MISSING_BOOKING" | "FOREX_DIFFERENCE" | etc.
    PROPOSED_JOURNAL_JSON   VARIANT,                    -- JSON of the journal entry
    REMARK                  VARCHAR(500),
    LOAD_DATE               TIMESTAMP_NTZ
);
```

### `REGRESSION.PAIR_RESIDUAL_TARGETS` (from `MISvsMIS` tab)

```sql
CREATE TABLE REGRESSION.PAIR_RESIDUAL_TARGETS (
    PAIR_ID                 VARCHAR(50),                -- e.g. "EJP-ETCE"
    PERIOD                  DATE,                       -- e.g. 2026-03-31
    JPY_GROSS_VARIANCE      NUMBER(20,2),               -- pre-adjustments
    JPY_ADJUSTMENTS         NUMBER(20,2),               -- manual JE column
    JPY_RESIDUAL            NUMBER(20,2),               -- target: pipeline should match
    USD_GROSS_VARIANCE      NUMBER(20,2),
    USD_ADJUSTMENTS         NUMBER(20,2),
    USD_RESIDUAL            NUMBER(20,2),
    REMARKS                 VARCHAR(500),
    PRIMARY KEY (PAIR_ID, PERIOD)
);
```

### `REGRESSION.COMPILATION_TARGETS` (from `Compilation` tab)

```sql
CREATE TABLE REGRESSION.COMPILATION_TARGETS (
    PAIR_ID                 VARCHAR(50),
    PERIOD                  DATE,
    OS_ACCOUNT              VARCHAR(20),
    CATEGORY                VARCHAR(50),
    DOC_CURRENCY            VARCHAR(3),
    SIDE_A_BALANCE          NUMBER(20,2),
    SIDE_B_BALANCE          NUMBER(20,2),
    EXPECTED_VARIANCE       NUMBER(20,2),
    PRIMARY KEY (PAIR_ID, PERIOD, OS_ACCOUNT, DOC_CURRENCY)
);
```

The 11 per-pair MIS tabs follow a uniform structure (Journal Adjustment header + GL-level pivot detail). They become the per-pair regression-detail target — useful for granular debugging but not required for the v1 pipeline.

---

## 2.3 Per-Entity Interco Template Files (16 files in `mar26_files.zip` root)

**File purpose:** Each entity (or closely-related entity group) submits ONE template each month containing their own view of all bilateral relationships. These are the entity-side deliverables collected from local PICs. Schemas vary: some organize by counterparty, some by GL account, some by category.

**File inventory and schema patterns:**

| File | Tabs | Schema pattern | Adapter complexity |
|------|------|----------------|---------------------|
| `EJP_Interco template Mar'26(0407).xlsx` | 9 | TB Doc Currency, Balance sheet, TB Local Currency, EJP List | MEDIUM (multi-currency TB, Japanese tab names) |
| `Copy of EAS Interco template Mar-26.xlsx` | 10 | Balance sheet + per-counterparty tabs (EJP, EUSA, ETCE, ESG, EKR) + TP Adj + ICPs | LOW |
| `ENF_Interco template Mar'26 - 6 April.xlsx` | 27 | Balance sheet + per-(counterparty, GL-account) tabs (EGZ_50201994, EGZ_23203014, etc.) — most granular | HIGH (schema explosion, Japanese names) |
| `ESG Interco template Mar'26.xlsx` | 11 | Balance sheet + per-account tabs (2520300-Debtors, 2610300-Creditor, etc.) | MEDIUM (account-organized) |
| `EKR_Interco template Mar'26 - 20260410.xlsx` | 10 | Balance sheet + per-category tabs (Trade receivable, Other Receivable, Short-term Loan, Accrued Interest, Trade-Payable, Trade-Payable YEA, Non-trade) | LOW |
| `EIND Interco Template Mar'26 - 6 April.xlsx` | 7 | Balance sheet + per-counterparty tabs (EJP, ESG, ETCE, EUSA) | LOW |
| `ECN Interco template Mar'26 1.xlsx` | 8 | Balance sheet + per-counterparty tabs (EUSA, ECND, ETCE, EJP, EGZ) | LOW |
| `EUSA Interco template March 2026.xlsx` | 36 | Per-pair tabs (EUSA VS EEU, EUSA VS EGZ, EUSA VS ECN, ...) — most pair-level granular | MEDIUM-HIGH |
| `EUSA MIS Interco template Mar'26 v2.xlsx` | 13 | Per-(counterparty, transaction-type) tabs (EJP(Trade AP), EJP(nontradeAP), EJP(nontradeAR), ...) | MEDIUM |
| `ECDN MIS Interco template Mar'26 v2.xlsx` | 6 | Per-(counterparty, type) tabs | LOW |
| `Interco template Mar'26 #Uff08EGZ) - 7 April.xlsx` | 9 | Balance sheet + per-(direction, ICP) tabs (AP-1096, AP-1097, AP-ECN, AP-ETCE, AR-1097, AR-ECN) | LOW-MEDIUM |
| `Interco template - Spectral Insights.xlsx` | 2 | PL + List of intercompany only — minimal data | LOW (sparse data) |
| `Interco template Evident Scientific Mexico March 26.xlsx` | 3 | Balance sheet + List of intercompany + Lookup | LOW (sparse) |
| `Interco template Mar'25 EMEA V3.xlsx` | 5 | Balance sheets for EEU, ESCE, ETCE | LOW |
| `Interco template March 26_Pramana Inc(v3).xlsx` | 10 | Balance sheet + per-GL-account tabs (TB, GL1751, GL1760, GL2450, GL2451, GL2630, GL2631) | MEDIUM (NetSuite-style account codes) |
| `Interco template March 26_Pramana Canada.xlsx` | 6 | Balance sheet + Trial Balance + per-account tabs | LOW |

**Common pattern:** Every template file has these three structural elements:
1. **`Balance sheet` tab** — one row per (GL account, counterparty), with LC and reporting-currency amounts. This is the entity's GL-balance view.
2. **`List of intercompany` tab** — list of valid counterparty entity codes (always present, near-identical content across files).
3. **Detail tabs** — variable; either by counterparty, by GL account, by category, or by pair.

**Relevance to matching:**

The `Balance sheet` tab in each template file is the entity's **submitted GL-balance view** for the period. This feeds Phase 1 reconciliation directly. The detail tabs feed Phase 2 invoice-level matching but require entity-specific adapters.

**Tabs to extract per template file:**

For Phase 1 (GL-level reconciliation), extract:
- `Balance sheet` tab from every template — this is the source of truth for that entity's submitted balances per (GL account, counterparty)

For Phase 2 (invoice-level), extract entity-specific detail tabs depending on the entity:

| Entity | Tabs to extract for Phase 2 |
|--------|------------------------------|
| EAS | EJP, EUSA, ETCE, ESG, EKR (per-counterparty tabs) |
| EJP | EJP List + TB Doc Currency tab (line-level detail) |
| ENF | All EGZ_*, ETCE_*, EJP_* tabs (27 tabs — line-level by GL+counterparty) |
| ESG | 2520300, 2520310, 2610300, 2610310, 2610600, 2620100, 2650300 (per-GL-account) |
| EKR | Trade receivable, Other Receivable, Short-term Loan, Accrued Interest, Trade-Payable, Non-trade |
| EIND | EJP, ESG, ETCE, EUSA |
| ECN | EUSA, ECND, ETCE, EJP, EGZ |
| EUSA | All "VS" tabs (28 pair tabs) |
| EUSA MIS | EJP/EEU/ETCE/ECDN/EMEX/Pramana per-trade-type tabs |
| ECDN MIS | EUSA/EJP per-type tabs |
| EGZ | AP-1096, AP-1097, AP-ECN, AP-ETCE, AR-1097, AR-ECN |
| Pramana Inc | GL1751, GL1760, GL2450, GL2451, GL2630, GL2631 |
| Pramana Canada | GL1760, GL1751, Trial Balance |

The other elements (Lookup, List of intercompany, Status, working sheets) are not extracted.

**Snowflake target table — unified IC line items:**

```sql
CREATE TABLE STAGING.IC_LINES (
    -- Identification
    LINE_ID                 VARCHAR(50) PRIMARY KEY,    -- generated: hash of (file_id + tab + row_num)
    SOURCE_FILE             VARCHAR(500),               -- path to the source xlsx
    SOURCE_TAB              VARCHAR(200),               -- e.g. "EJP AR-T(MIS)"
    SOURCE_ROW              NUMBER,                     -- row number within the tab
    LOAD_DATE               TIMESTAMP_NTZ,
    PERIOD                  DATE,                       -- e.g. 2026-03-31

    -- Bilateral pair identification
    ENTITY_CODE             VARCHAR(10),                -- the entity that produced this line (e.g. "EJP")
    COUNTERPARTY_CODE       VARCHAR(10),                -- e.g. "ECN"
    PAIR_ID                 VARCHAR(50),                -- canonicalized: alphabetical pair (e.g. "ECN-EJP")
    SEGMENT                 VARCHAR(20),                -- "MIS" | "TNM" | "Both"

    -- GL classification
    SAP_GL_ACCOUNT          VARCHAR(20),                -- e.g. "23203012"
    SAP_ACCOUNT_DESCRIPTION VARCHAR(200),
    ONESTREAM_ACCOUNT       VARCHAR(20),                -- joined from REF_ENTITY_GL_ACCOUNTS
    CATEGORY                VARCHAR(50),                -- joined: "Trade" | "Non-trade" | etc.
    NATURE                  VARCHAR(50),                -- "Trade-EDI" | "Trade- non EDI" | "Trade - cannot split" | "Non-trade"
    AR_OR_AP                VARCHAR(2),                 -- "AR" | "AP" — direction
    BS_OR_PL                VARCHAR(2),                 -- "BS" | "PL"
    ASSET_OR_LIAB           VARCHAR(10),                -- "Asset" | "Liability"

    -- Document detail
    DOC_NUMBER              VARCHAR(100),               -- invoice no / document no
    DOC_DATE                DATE,
    POSTING_MONTH           VARCHAR(7),                 -- e.g. "2026-03"
    DOC_CURRENCY            VARCHAR(3),                 -- e.g. "USD"
    DOC_AMOUNT              NUMBER(20,2),               -- signed amount in document currency
    LC_CURRENCY             VARCHAR(3),                 -- entity's local/functional currency
    LC_AMOUNT               NUMBER(20,2),               -- signed amount in local currency
    REPORTING_AMOUNT_JPY    NUMBER(20,2),               -- signed amount in JPY (for consolidation)
    FOREX_RATE              NUMBER(20,8),

    -- Free text and metadata
    FREE_TEXT               VARCHAR(1000),              -- description, vendor, narrative
    PROFIT_CENTER           VARCHAR(20),                -- for MIS scope filtering
    BUSINESS_UNIT           VARCHAR(20),

    -- Pipeline state (filled later)
    PHASE1_STATUS           VARCHAR(20),                -- "RECONCILED" | "VARIANCE" | NULL
    PHASE2_MATCH_ID         VARCHAR(50),                -- FK to PHASE2_LINE_MATCHES
    PHASE3_MATCH_ID         VARCHAR(50),                -- FK to PHASE3_FUZZY_MATCHES
    PHASE4_CLASSIFICATION_ID VARCHAR(50),               -- FK to PHASE4_AI_CLASSIFICATIONS
    LINE_STATUS             VARCHAR(20)                 -- "MATCHED" | "REVIEW" | "FUZZY" | "AI" | "RESIDUAL"
);
```

This is the unified target — every entity adapter produces rows in this one schema regardless of the source-tab format.

---

## 2.4 Bilateral Pair Files (53 files in `mar26_files.zip` subfolders)

**File purpose:** Each pair-period reconciliation has one or more supporting workbooks contributed by the involved entities. These contain the actual invoice-level detail used to drill down into a variance. Naming convention: `{ICP}_{ENTITY}_{period}_{version}.xlsx` or `({entity})_({counterparty})_{period}.xlsx`.

**Distribution by hub:**

| Hub | File count | Pairs covered |
|-----|------------|---------------|
| `EJP information/` | 28 | EJP ↔ {EAS, ECDN, ECN, EEU, EGZ, EIND, EKR, ENF, ESCE, ESG, ETCE, EUSA, MIS-CND, PCDN, PIND, PUSA} |
| `EEU-ETCE-ESCE information/` | 25 | {EEU, ETCE, ESCE} ↔ {EJP, ECDN, EUSA, ECN, EAS, EIND, EGZ, ENF} |

**Common file structure pattern (the canonical bilateral file):**

A bilateral pair file typically has these tab types:

| Tab type | Example name | Content | Relevance |
|----------|--------------|---------|-----------|
| Summary tab | `Summary Reconciliation`, `Pair Summary` | One-page totals showing pair totals, variance, signoff | LOW — derivable from detail |
| Side A AR detail | `EJP AR-T(MIS)`, `Master (Trade)`, `0331 D3` | Invoice-level AR aging from Side A | **HIGH — extract** |
| Side A AP detail | `EJP AP-O(MIS)`, `EJP account balance(AP)` | Invoice-level AP from Side A | **HIGH — extract** |
| Side B AR detail | (entity-specific name) | Invoice-level AR from Side B | **HIGH — extract** |
| Side B AP detail | (entity-specific name) | Invoice-level AP from Side B | **HIGH — extract** |
| Master invoice list | `Master (Trade)`, `Master (Non-Trade)` | All open invoices from one side | **HIGH — extract** |
| GL-account snapshot | `1126`, `1127`, `5410` | Per-GL-account balance snapshots | MEDIUM — extract for cross-check |
| Period snapshots | `0326`, `0331`, `0407` | Same data at different cut dates | LOW — pick one (period-end) |
| Dropdown / Lookup | `Dropdown` | Validation lookups | NONE |

**Worked example — `(EJP)_(ECN)03_2026 D1(0401)_Final.xlsx`:**

This is the canonical EJP-ECN bilateral file. Tabs (verified in prior session):
- `Summary Reconciliation` — pair summary; skip
- `EJP AR-T(MIS)` — 432 EJP AR rows for ECN, MIS segment; **EXTRACT**
- `EJP AR-O(MIS)` — EJP non-trade AR for ECN; **EXTRACT**
- `EJP AP-T(MIS)` — EJP AP-Trade for ECN; **EXTRACT**
- `EJP AP-O(MIS)` — EJP AP-Other for ECN; **EXTRACT**
- `Master (Trade)` — ECN-side master list of 500 trade invoices; **EXTRACT**
- `Master (Non-Trade)` — ECN non-trade master; **EXTRACT**
- `0326`, `0331`, `0331 D3` — period snapshots; pick `0331 D3` (period-end)
- `Dropdown` — skip

The match key is `EJP.sort_key (col A) = ECN.Document Number (col F)`. After extracting, the unified `IC_LINES` table contains both sides; Phase 1 aggregates them, and Phase 2 joins them on the match key.

**Tabs to extract — concrete list per representative bilateral file (apply pattern to others):**

| File | Tabs to extract |
|------|-----------------|
| `(EJP)_(ECN)03_2026 D1(0401)_Final.xlsx` | EJP AR-T(MIS), EJP AR-O(MIS), EJP AP-T(MIS), EJP AP-O(MIS), Master (Trade), Master (Non-Trade), 0331 D3 |
| `ETCE_EJP_03_31 D3_rev.xlsx` | EJP account balance(AP), EJP AP-O(MIS), Master (Trade), Master (Non-Trade), 0331 D3 |
| `(EJP)_(EAS)3_2026 D 1(0401)Final.xlsx` | EJP AR-T(MIS), EJP AR-O(MIS), EAS-side native aging tabs |
| `(EJP)_(ETCE) 03_2026 D1(0401)_Final.xlsx` | EJP AR-T(MIS), EJP AP-O(MIS), ETCE side tabs |
| `EEU_EJP_03_31_2026(0406_rev).xlsx` | EJP-side tabs, EEU-side cash pool / native SAP tabs |

**Snowflake target:** All extracted invoice-level data lands in the same `STAGING.IC_LINES` table (defined in §2.3). Each entity adapter handles its own column mapping into the unified schema.

**Adapter inventory (entity-side):**

| Adapter | Source-side schema | Status |
|---------|---------------------|--------|
| `EJP_AR_MIS` | `EJP AR-T(MIS)` standard 12-col layout | ✅ Built |
| `EJP_AR_OTHER_MIS` | `EJP AR-O(MIS)` 12-col | ✅ Built |
| `EJP_AP_MIS` | `EJP AP-T(MIS)` 12-col | 🟡 Partial (column-shift edge case) |
| `EJP_AP_OTHER_MIS` | `EJP AP-O(MIS)` 12-col | 🟡 Partial |
| `ECN_MASTER_TRADE` | `Master (Trade)` (ECN xxxx) — 18-col | ✅ Built |
| `ECN_MASTER_NON_TRADE` | `Master (Non-Trade)` 18-col | ✅ Built |
| `EAS_NATIVE_AGING` | EAS-format aging | 🟡 Partial |
| `EKR_AGGREGATE` | EKR per-category tabs | 🟡 Partial (aggregate only, not invoice-level) |
| `EEU_SAP_NATIVE` | EEU multi-tab (Cash Pool, 0331 D2) | ❌ TBD |
| `ETCE_SAP_NATIVE` | ETCE multi-tab | ❌ TBD |
| `ENF_JAPANESE_NATIVE` | ENF 27-tab Japanese (照合, 未払金*, CMS) | ❌ TBD (most complex) |
| `ESG_FBL1N` | ESG SAP FBL1N format | ❌ TBD |
| `EIND_NATIVE` | EIND per-counterparty | ❌ TBD |
| `EGZ_NATIVE` | EGZ AP/AR per ICP | ❌ TBD |
| `ECDN_MIS_NATIVE` | ECDN MIS 6-tab | ❌ TBD |
| `EUSA_NETSUITE` | EUSA 36-tab pair-level | ❌ TBD |
| `EMEX_NATIVE` | EMEX template 3-tab (sparse) | ❌ TBD |
| `SPIND_NATIVE` | Spectral Insights 2-tab | ❌ TBD |
| `PRAMANA_INC_NETSUITE` | Pramana NetSuite GL-coded | ❌ TBD |
| `PRAMANA_CANADA_NETSUITE` | Pramana Canada NetSuite | ❌ TBD |

Total adapter build estimate: ~17-22 person-days for full MIS coverage (validated entities cover ~60% of variance volume already).

---

# Part 3 — Outputs to Showcase

The pipeline must surface its results in five distinct views, organized by audience and decision type:

## 3.1 Output 1: GL-Account Level Matching

**Audience:** Senior controllers, segment leads, finance leadership.
**Question answered:** "Did the totals reconcile across the bilateral pair?"
**Granularity:** One row per (pair × OS account × category × currency).

### 3.1.1 Overall view (all pairs)

A single dashboard table showing every active pair-period:

```
PAIR_ID    PERIOD      RECONCILED_PCT   GROSS_VARIANCE   OS_ACCOUNTS_OK   OS_ACCOUNTS_VAR   STATUS
─────────────────────────────────────────────────────────────────────────────────────────────────
EJP-ECN    2026-03-31  98.5%            JPY 148,536       6                1                 AMBER
EJP-ETCE   2026-03-31  99.2%            JPY 476,720       8                1                 AMBER
EEU-SPIND  2026-03-31  0.0%             JPY 15,916,054    0                1                 RED
ETCE-ECN   2026-03-31  99.6%            JPY 35,485        7                1                 GREEN
... (one row per active pair)
```

KPIs: count of pairs reconciled, total monetary value reconciled, pairs requiring HITL action, residual sum.

### 3.1.2 By Entity view

For each entity, sum its bilateral positions to confirm consolidation-readiness:

```
ENTITY  TOTAL_PAIRS  PAIRS_GREEN  PAIRS_AMBER  PAIRS_RED   TOTAL_RESIDUAL_JPY
──────────────────────────────────────────────────────────────────────────────
EJP     12           8            3             1           1,400,000
ETCE    8            5            2             1           2,000,000
EEU     6            3            2             1           18,000,000
ECN     7            5            1             1           250,000
... (one row per entity)
```

Drill-down: clicking an entity reveals its bilateral pairs.

### 3.1.3 Source data structure

```sql
CREATE OR REPLACE VIEW RESULTS.V_PHASE1_OS_BALANCE_RECON AS
SELECT
    p.PAIR_ID,
    p.PERIOD,
    p.OS_ACCOUNT,
    p.OS_DESCRIPTION,
    p.CATEGORY,
    p.DOC_CURRENCY,
    p.SIDE_A_BALANCE,
    p.SIDE_B_BALANCE,
    p.VARIANCE,
    p.VARIANCE_PCT,
    p.RECON_STATUS,        -- "RECONCILED" | "VARIANCE"
    p.PHASE1_CONFIDENCE,
    rt.JPY_RESIDUAL AS REGRESSION_TARGET_JPY,
    CASE WHEN p.VARIANCE_JPY <= rt.JPY_RESIDUAL * 1.05
         AND p.VARIANCE_JPY >= rt.JPY_RESIDUAL * 0.95
         THEN 'WITHIN_TARGET' ELSE 'OUT_OF_TARGET' END AS REGRESSION_STATUS
FROM RESULTS.PHASE1_BALANCE_RECON p
LEFT JOIN REGRESSION.PAIR_RESIDUAL_TARGETS rt
       ON p.PAIR_ID = rt.PAIR_ID AND p.PERIOD = rt.PERIOD;
```

The view validates pipeline output against MISvsMIS regression targets in real-time.

---

## 3.2 Output 2: Invoice-Level Matching

**Audience:** Mid-level controllers, AP/AR specialists, junior accountants doing reconciliation.
**Question answered:** "For pairs with variance, which specific invoices match and which don't?"
**Granularity:** One row per matched invoice pair, or one row per orphan invoice.

### 3.2.1 Overall view

```
PAIR_ID    PERIOD      LINES_TOTAL   LINES_MATCHED   LINES_REVIEW   LINES_FUZZY   LINES_AI
──────────────────────────────────────────────────────────────────────────────────────────
EJP-ECN    2026-03-31  500           428             19              4              49
EJP-ETCE   2026-03-31  150           135             10              3              2
EEU-SPIND  2026-03-31  1             0               0               0              1
... (one row per pair)
```

### 3.2.2 By Entity view

```
ENTITY    LINES_PRODUCED   LINES_MATCHED_OK   LINES_NEEDING_REVIEW   AVG_CONFIDENCE
─────────────────────────────────────────────────────────────────────────────────────
EJP       1,200             1,140               60                       0.97
ECN       650               595                 55                       0.94
ETCE      400               385                 15                       0.96
... (one row per entity)
```

### 3.2.3 Source data structure

```sql
CREATE OR REPLACE VIEW RESULTS.V_PHASE2_LINE_MATCHES AS
SELECT
    m.MATCH_ID,
    m.PAIR_ID,
    m.PERIOD,
    a.LINE_ID AS LINE_A_ID,
    a.ENTITY_CODE AS ENTITY_A,
    a.DOC_NUMBER AS DOC_A,
    a.DOC_AMOUNT AS AMOUNT_A,
    a.DOC_DATE AS DATE_A,
    b.LINE_ID AS LINE_B_ID,
    b.ENTITY_CODE AS ENTITY_B,
    b.DOC_NUMBER AS DOC_B,
    b.DOC_AMOUNT AS AMOUNT_B,
    b.DOC_DATE AS DATE_B,
    m.CONFIDENCE,
    m.CRITERIA_FAILED,    -- e.g. "doc_date_match (off by 7 days)"
    m.MATCH_STATUS        -- "PERFECT" | "REVIEW" | "PHASE3" | "RESIDUAL"
FROM RESULTS.PHASE2_LINE_MATCHES m
JOIN STAGING.IC_LINES a ON m.LINE_A_ID = a.LINE_ID
LEFT JOIN STAGING.IC_LINES b ON m.LINE_B_ID = b.LINE_ID;
```

---

## 3.3 Output 3: HITL Review Queue (Phase 2 partial matches)

**Audience:** Reconciliation specialists doing daily/weekly close work.
**Trigger:** Confidence between 0.50 and 1.00 (excluding 1.00).
**Action expected:** Approve as match (despite minor discrepancy) or reject (force into Phase 3 / residual).

**Display columns:**

```
QUEUE_ID         AGE   PAIR        SIDE_A_LINE_PREVIEW                   SIDE_B_LINE_PREVIEW                   CONFIDENCE   FAILED_CRITERIA
──────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────
RVW-2026-001     2d    EJP-ECN     INV2026-001 USD 12,500 2026-03-15     INV2026-001 USD 12,500 2026-03-22     0.95          doc_date_match: off 7 days
RVW-2026-002     2d    EJP-ETCE    PO-X-7821 EUR 3,452.00 2026-03-10     PO-X-7821 EUR 3,452.50 2026-03-10     0.95          amount_match: 0.50 EUR off
RVW-2026-003     1d    EJP-EAS     N/A — orphan ECN line                  N/A                                  0.65          ICP+amount only
... (one row per pending review)
```

**Action buttons:** [Approve as Match] [Reject — Send to Phase 3] [Escalate]

### 3.3.1 Source data structure

```sql
CREATE TABLE HITL.REVIEW_QUEUE (
    QUEUE_ID                VARCHAR(50) PRIMARY KEY,
    PAIR_ID                 VARCHAR(50),
    PERIOD                  DATE,
    LINE_A_ID               VARCHAR(50),
    LINE_B_ID               VARCHAR(50),
    PHASE                   VARCHAR(10),     -- "PHASE2" | "PHASE3"
    CONFIDENCE              NUMBER(5,4),
    FAILED_CRITERIA         VARCHAR(500),    -- comma-separated list
    AI_REASONING            VARCHAR(2000),
    QUEUE_STATUS            VARCHAR(20),     -- "PENDING" | "APPROVED" | "REJECTED" | "ESCALATED"
    QUEUED_AT               TIMESTAMP_NTZ,
    REVIEWER                VARCHAR(100),
    REVIEWED_AT             TIMESTAMP_NTZ,
    REVIEWER_DECISION       VARCHAR(20),
    REVIEWER_NOTES          VARCHAR(1000)
);
```

---

## 3.4 Output 4: HITL Approval Queue — Fuzzy Matching (Phase 3)

**Audience:** Senior reconciliation specialists.
**Trigger:** Phase 3 produced an AI confidence ≥ 0.80 match.
**Action expected:** Approve the AI's proposed match, or send back to deep review.

**Display columns:**

```
QUEUE_ID         AGE   PAIR        SIDE_A_LINE                            SIDE_B_LINE                            AI_CONFIDENCE   AI_REASONING
─────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────
FUZ-2026-001     1d    EJP-ETCE    PO-X-7821 EUR 3,452.50 2026-03-10      PO-X-7821 EUR 3,452.00 2026-03-10      0.92            "Likely forex revaluation: same vendor, same PO, 0.50 EUR difference proportional to ~0.0001 forex shift"
FUZ-2026-002     1d    ETCE-ECN    GR-9921 CNY 95,000 2026-03-25          INV-9921 CNY 95,000 2026-03-25         0.89            "Different document numbers but same amount, vendor, date — likely Goods Receipt vs Invoice on same transaction"
... (one row per fuzzy approval pending)
```

**Action buttons:** [Approve Match] [Send to Review] [Reject — Treat as Residual]

### 3.4.1 Source data structure

```sql
CREATE TABLE HITL.FUZZY_APPROVAL_QUEUE (
    QUEUE_ID                VARCHAR(50) PRIMARY KEY,
    PAIR_ID                 VARCHAR(50),
    PERIOD                  DATE,
    LINE_A_ID               VARCHAR(50),
    LINE_B_ID               VARCHAR(50),
    COSINE_SIMILARITY       NUMBER(5,4),
    AMOUNT_PROXIMITY        NUMBER(5,4),
    DATE_PROXIMITY          NUMBER(5,4),
    AI_CONFIDENCE           NUMBER(5,4),
    AI_REASONING            VARCHAR(2000),
    EMBEDDING_MODEL         VARCHAR(50),     -- "snowflake-arctic-embed-l-v2.0"
    QUEUE_STATUS            VARCHAR(20),
    QUEUED_AT               TIMESTAMP_NTZ,
    REVIEWER                VARCHAR(100),
    REVIEWED_AT             TIMESTAMP_NTZ,
    REVIEWER_DECISION       VARCHAR(20),
    REVIEWER_NOTES          VARCHAR(1000)
);
```

---

## 3.5 Output 5: HITL Approval Queue — AI-Assisted Classification (Phase 4)

**Audience:** Senior controllers / segment leads (highest authority — proposes journal entries).
**Trigger:** Phase 4 produced a classification + journal proposal.
**Action expected:** Approve the JE (auto-export to SAP/NetSuite), edit and approve, or reject (return to manual handling).

**Display columns:**

```
QUEUE_ID    AGE    PAIR        VARIANCE         ROOT_CAUSE         AI_CONF   PROPOSED_JE_PREVIEW                                     ACTION
────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────
CLS-001     1d     EEU-SPIND   USD 99,550        MISSING_BOOKING    0.95      DR Man Inv Adj USD 99,550 / CR Trade A/P USD 99,550   [Approve][Edit][Reject]
CLS-002     1d     EJP-ETCE    JPY 476,720       FOREX_DIFFERENCE   0.86      DR Forex Loss / CR Other Liability                     [Approve][Edit][Reject]
CLS-003     2d     ETCE-ECN    CNY 434,136       MISSING_BOOKING    0.91      DR Inventory Adj / CR Trade A/P (4 invoices)            [Approve][Edit][Reject]
... (one row per AI proposal pending)
```

**Detail view (when expanded):**
- Full AI reasoning text
- Side-by-side variance breakdown
- The 3-5 most similar historical resolutions (from `Entry Summary` few-shot)
- The full proposed journal entry with all lines
- An "Edit Journal" interface to override the AI's proposed amounts/accounts before approving

### 3.5.1 Source data structure

```sql
CREATE TABLE HITL.CLASSIFICATION_APPROVAL_QUEUE (
    QUEUE_ID                VARCHAR(50) PRIMARY KEY,
    PAIR_ID                 VARCHAR(50),
    PERIOD                  DATE,
    OS_ACCOUNT              VARCHAR(20),
    CATEGORY                VARCHAR(50),
    DOC_CURRENCY            VARCHAR(3),
    VARIANCE_AMOUNT         NUMBER(20,2),
    VARIANCE_AMOUNT_JPY     NUMBER(20,2),
    UNMATCHED_LINE_IDS_A    ARRAY,                -- lines on Side A that the variance covers
    UNMATCHED_LINE_IDS_B    ARRAY,
    ROOT_CAUSE_CATEGORY     VARCHAR(50),          -- AI output
    AI_CONFIDENCE           NUMBER(5,4),
    AI_REASONING            VARCHAR(5000),
    SUGGESTED_ACTION        VARCHAR(20),          -- "PROPOSE_JE" | "INVESTIGATE" | "ESCALATE"
    PROPOSED_JOURNAL        VARIANT,              -- full JSON of journal entry (multiple lines)
    SIMILAR_ISSUE_IDS       ARRAY,                -- references to TRAINING.PHASE4_FEW_SHOT_EXAMPLES
    LLM_MODEL               VARCHAR(100),         -- e.g. "claude-3-5-sonnet"
    LLM_PROMPT_VERSION      VARCHAR(20),          -- for tracking prompt iterations
    QUEUE_STATUS            VARCHAR(20),
    QUEUED_AT               TIMESTAMP_NTZ,
    REVIEWER                VARCHAR(100),
    REVIEWED_AT             TIMESTAMP_NTZ,
    REVIEWER_DECISION       VARCHAR(20),          -- "APPROVED" | "EDITED_AND_APPROVED" | "REJECTED" | "ESCALATED"
    REVIEWER_EDITED_JOURNAL VARIANT,              -- if edited
    REVIEWER_NOTES          VARCHAR(2000),
    EXPORTED_TO_ERP         BOOLEAN,
    ERP_REFERENCE           VARCHAR(100)          -- post-approval ERP reference
);
```

---

## 3.6 Period Dashboard (Top-Level)

The single-page view a controller sees first when opening the system:

```
┌─────────────────────────────────────────────────────────────────────────────┐
│  Evident MIS Intercompany Reconciliation — March 2026                       │
│  Run timestamp: 2026-04-15 10:42 SGT                                        │
├─────────────────────────────────────────────────────────────────────────────┤
│  PIPELINE HEALTH                                                            │
│                                                                              │
│  Pairs reconciled (Phase 1):    24 / 35  (68.5%)                            │
│  Lines matched (Phase 2):       2,847 / 3,445  (82.6%)                      │
│  Fuzzy approvals pending:       127  ($23,420 in variance to approve)       │
│  AI classifications pending:    18   ($91,500 in JEs to approve)            │
│  Residuals (after all phases):  $147,200  (vs target $145,000 — +1.5%)      │
│                                                                              │
│  ─────────────────────── Top variances by pair ──────────────────────────   │
│  EEU-SPIND   USD 99,550   (1 line orphan)         [View detail →]            │
│  EJP-ETCE    JPY 476,720  (forex residual)        [View detail →]            │
│  MIS-USA-EMEX JPY 1,317,125 (no remark in history) [View detail →]           │
└─────────────────────────────────────────────────────────────────────────────┘
```

KPIs to feature: pipeline coverage, variance closing rate, HITL queue depth, processing-time savings vs manual baseline, regression-test pass rate.

---

# Part 4 — Cross-Reference: Phases ↔ Files ↔ Outputs

| Phase | Source files | Source tabs | Snowflake target | HITL queue | UI page |
|-------|--------------|-------------|------------------|-----------|---------|
| Phase 1 | All Interco Templates + Bilateral pair files | `Balance sheet` + detail tabs | `RESULTS.PHASE1_BALANCE_RECON` | (none — automatic) | GL-Level page |
| Phase 2 | Bilateral pair files | AR/AP detail + Master tabs | `RESULTS.PHASE2_LINE_MATCHES` | `HITL.REVIEW_QUEUE` (partial matches) | Invoice-Level page + Review Queue |
| Phase 3 | Phase 2 unmatched outputs | (computed) | `RESULTS.PHASE3_FUZZY_MATCHES` | `HITL.FUZZY_APPROVAL_QUEUE` | Fuzzy Approval Queue |
| Phase 4 | Phase 3 unmatched outputs + `Entry Summary` few-shot | (computed) | `RESULTS.PHASE4_AI_CLASSIFICATIONS` | `HITL.CLASSIFICATION_APPROVAL_QUEUE` | AI Approval Queue |
| Validation | `Interco_recon_mis_mar26.xlsx` | `MISvsMIS`, `Compilation`, per-pair tabs | `REGRESSION.PAIR_RESIDUAL_TARGETS` | (none — auto-compared) | Dashboard regression panel |
| Reference | `interco_recon_process_automation.xlsx` | `Mar'26 accounts` | `REF.REF_ENTITY_GL_ACCOUNTS` | (none — read-only) | (admin only) |

This is the index. The companion implementation spec (`snowflake_streamlit_implementation_spec.md`) provides the DDL, stored procedures, Cortex configuration, and Streamlit application code for each row of this table.
