# Use Case Prototype: The Executive Command Center

- **AI Approach:** GenAI-Powered Reporting
- **Target Persona:** Hospital Executive (COO, CFO, Service Line Leader)
- **Objective:** Provide immediate, synthesized answers to complex operational questions, bypassing the need for static dashboards and analyst report cycles.

---

### The Problem

A hospital executive needs to understand the drivers of performance for their service line. Today, they must either navigate multiple, complex dashboards (each with its own filters and limitations) or submit a request to an analytics team, which can take days or weeks. By the time they get the answer, the situation may have already changed.

### The Solution: A Natural Language Interface

A simple, powerful interface where the executive can ask questions in plain English and get immediate answers, complete with context and data visualizations.

---

### Demo / Prototype Concept

The user interface is minimalist: a text box for questions and a display area for the response.

**UI Mockup:**

```
------------------------------------------------------------------
|                                                                |
|  TEXAS CHILDREN'S HOSPITAL - EXECUTIVE COMMAND CENTER          |
|                                                                |
------------------------------------------------------------------
|                                                                |
| > **Your Question:**                                            |
|   Summarize the key drivers of increased length-of-stay in      |
|   the pediatric ICU for Q3, compared to the previous quarter.   |
|                                                                |
------------------------------------------------------------------
|                                                                |
|   **Gemini Enterprise says:**                                   |
|                                                                |
|   In Q3, the average length-of-stay (ALOS) in the PICU          |
|   increased by 1.2 days compared to Q2. The primary drivers     |
|   were:                                                         |
|                                                                 |
|   1. A **15% increase** in complex respiratory cases requiring   |
|      prolonged ventilation.                                     |
|   2. An increase in acuity, with the average patient risk       |
|      score rising by 8%.                                        |
|                                                                 |
|   [ CHART: Bar chart showing ALOS for Q2 vs Q3, broken down    ] |
|   [ by major diagnosis category. The respiratory category      ] |
|   [ shows the largest increase.                               ] |
|                                                                |
------------------------------------------------------------------
```

---

### How It Works (The "AI Architect" Vision)

1.  **Natural Language Understanding:** An LLM parses the executive's question to understand the core intent, entities (PICU), metrics (length-of-stay), timeframes (Q3 vs Q2), and comparisons.
2.  **SQL Generation:** Based on this understanding and its knowledge of the underlying `dbt` models, the AI generates an optimized SQL query to run on Snowflake.
3.  **Data Retrieval & Synthesis:** The query is executed. The LLM receives the structured data results.
4.  **Narrative & Visualization:** The LLM synthesizes the data into a concise, plain-English summary, identifies the key insights, and generates a relevant data visualization to support the narrative.

### Required Data (from Replicated Consumption Layer)

-   **Operational SAMs:** Patient volumes, bed occupancy, admission/discharge/transfer (ADT) data, length-of-stay metrics.
-   **Financial SAMs:** High-level cost and revenue data by department/service line.
-   **Clinical SAMs:** Patient risk scores, primary diagnosis codes.
-   **Value Sets:** Definitions for service lines, diagnosis groups, etc.

### Value Proposition

This delivers an immediate, high-visibility win to TCH leadership. It demonstrates the power and speed of the new stack and builds crucial momentum for the entire AI program.
