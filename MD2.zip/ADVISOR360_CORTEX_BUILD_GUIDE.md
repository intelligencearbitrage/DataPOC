# ADVISOR360 — Snowflake Cortex Code Build Guide

**Target:** Snowflake Cortex Code CLI  
**Stack:** Snowflake (data + Cortex AI) + Streamlit in Snowflake (SiS)  
**Advisor:** James Rivera | Insurance Financial Advisor  
**Version:** 1.0 | Build from Scratch

---

## 1. PROJECT OVERVIEW

Advisor360 is a single-advisor agentic workspace for insurance/financial advisors. It surfaces AI-prioritized tasks, client intelligence, AI-drafted communications, and policy risk monitoring — all from a Streamlit in Snowflake app backed by Snowflake Cortex AI.

### Core Modules
| Module | Description |
|---|---|
| Dashboard | Daily briefing, KPIs, worklist summary, priority client list |
| Clients & Leads | Full client roster with Cortex-generated AI scores |
| Smart Worklist | AI-prioritized task list with human completion controls |
| Communications | AI-drafted outreach awaiting advisor review/approval |
| Policies | Tabular policy view with status, risk flags, action triggers |
| Analytics | Bar + donut charts for premium and policy mix |
| Prep Tools | Meeting prep — talking points + post-meeting automation checklist |
| Agent Panel | Transparency view of background AI agents and their activity logs |
| AI Preferences | Toggles for automation level and review requirements |
| Agent Output Panel | Slide-in detail panel (modal) — multi-tab AI output with HITL actions |

---

## 2. SNOWFLAKE DATABASE SETUP

### 2.1 Database, Schema, Warehouse

```sql
-- Run once in Snowsight or via Cortex Code CLI
CREATE DATABASE IF NOT EXISTS ADVISOR360_DB;
CREATE SCHEMA IF NOT EXISTS ADVISOR360_DB.APP;
CREATE SCHEMA IF NOT EXISTS ADVISOR360_DB.AGENTS;

CREATE WAREHOUSE IF NOT EXISTS ADVISOR360_WH
  WAREHOUSE_SIZE = 'XSMALL'
  AUTO_SUSPEND = 60
  AUTO_RESUME = TRUE;

USE DATABASE ADVISOR360_DB;
USE SCHEMA APP;
USE WAREHOUSE ADVISOR360_WH;
```

### 2.2 Table DDL

```sql
-- ADVISORS
CREATE OR REPLACE TABLE ADVISORS (
    ADVISOR_ID       VARCHAR(20) PRIMARY KEY,
    FIRST_NAME       VARCHAR(50),
    LAST_NAME        VARCHAR(50),
    EMAIL            VARCHAR(100),
    ROLE             VARCHAR(50),
    REGION           VARCHAR(50),
    CREATED_AT       TIMESTAMP_NTZ DEFAULT CURRENT_TIMESTAMP()
);

-- CLIENTS
CREATE OR REPLACE TABLE CLIENTS (
    CLIENT_ID           VARCHAR(20) PRIMARY KEY,
    ADVISOR_ID          VARCHAR(20) REFERENCES ADVISORS(ADVISOR_ID),
    FIRST_NAME          VARCHAR(50),
    LAST_NAME           VARCHAR(50),
    EMAIL               VARCHAR(100),
    PHONE               VARCHAR(20),
    LEAD_SOURCE         VARCHAR(50),  -- 'Referral','Direct','Digital','Employer'
    LEAD_DATE           DATE,
    CLIENT_SINCE_DATE   DATE,
    LIFE_STAGE          VARCHAR(50),  -- 'Pre-retirement','Young Family','Mid-career'
    ESTIMATED_ASSETS    NUMBER(15,2),
    SENTIMENT_SCORE     NUMBER(5,2),  -- 0-100
    DAYS_SINCE_CONTACT  INT,
    EXTERNAL_DATA       VARIANT,      -- JSON enrichment blob
    CREATED_AT          TIMESTAMP_NTZ DEFAULT CURRENT_TIMESTAMP()
);

-- POLICIES
CREATE OR REPLACE TABLE POLICIES (
    POLICY_ID               VARCHAR(20) PRIMARY KEY,
    CLIENT_ID               VARCHAR(20) REFERENCES CLIENTS(CLIENT_ID),
    POLICY_TYPE             VARCHAR(30),  -- 'Term Life','Whole Life','Universal Life','Group','LTC Rider'
    POLICY_NUMBER           VARCHAR(30),
    ANNUAL_PREMIUM          NUMBER(12,2),
    COVERAGE_AMOUNT         NUMBER(15,2),
    EFFECTIVE_DATE          DATE,
    RENEWAL_DATE            DATE,
    STATUS                  VARCHAR(20),  -- 'Active','Renewing','Review','At Risk','Overdue'
    ILLUSTRATED_GROWTH_RATE NUMBER(5,4),
    ACTUAL_GROWTH_RATE      NUMBER(5,4),
    CASH_VALUE_ACTUAL       NUMBER(15,2),
    CASH_VALUE_PROJECTED    NUMBER(15,2),
    DAYS_TO_RENEWAL         INT,
    CREATED_AT              TIMESTAMP_NTZ DEFAULT CURRENT_TIMESTAMP()
);

-- AI SCORES
CREATE OR REPLACE TABLE AI_SCORES (
    SCORE_ID        VARCHAR(36) DEFAULT UUID_STRING() PRIMARY KEY,
    CLIENT_ID       VARCHAR(20) REFERENCES CLIENTS(CLIENT_ID),
    SCORE_TIMESTAMP TIMESTAMP_NTZ DEFAULT CURRENT_TIMESTAMP(),
    SCORE_TYPE      VARCHAR(50),  -- 'WL_PROPENSITY','CONVERSION_LIKELIHOOD','LTC_PROPENSITY','LAPSE_RISK','SENTIMENT'
    SCORE_VALUE     NUMBER(5,2),  -- 0-100
    MODEL_VERSION   VARCHAR(20),
    NARRATIVE       TEXT          -- Cortex-generated explanation
);

-- WORKLIST ITEMS
CREATE OR REPLACE TABLE WORKLIST_ITEMS (
    ITEM_ID          VARCHAR(36) DEFAULT UUID_STRING() PRIMARY KEY,
    ADVISOR_ID       VARCHAR(20) REFERENCES ADVISORS(ADVISOR_ID),
    CLIENT_ID        VARCHAR(20) REFERENCES CLIENTS(CLIENT_ID),
    TASK_DESCRIPTION TEXT,
    DUE_DATETIME     TIMESTAMP_NTZ,
    PRIORITY         VARCHAR(10),  -- 'High','Medium','Low'
    STATUS           VARCHAR(20),  -- 'Pending','Done','Snoozed'
    AI_NOTE          TEXT,
    IS_AI_GENERATED  BOOLEAN DEFAULT FALSE,
    CATEGORY         VARCHAR(30),  -- 'Renewal','Outreach','Risk','Onboarding','Admin'
    CREATED_AT       TIMESTAMP_NTZ DEFAULT CURRENT_TIMESTAMP()
);

-- COMMUNICATIONS
CREATE OR REPLACE TABLE COMMUNICATIONS (
    COMM_ID           VARCHAR(36) DEFAULT UUID_STRING() PRIMARY KEY,
    CLIENT_ID         VARCHAR(20) REFERENCES CLIENTS(CLIENT_ID),
    ADVISOR_ID        VARCHAR(20) REFERENCES ADVISORS(ADVISOR_ID),
    COMM_TYPE         VARCHAR(20),  -- 'Email','Call Script'
    STATUS            VARCHAR(20),  -- 'Draft','Reviewed','Approved','Sent','Rejected'
    SUBJECT           TEXT,
    BODY_CONTENT      TEXT,
    TRIGGER_TYPE      VARCHAR(50),  -- 'Renewal','Risk','Milestone','Onboarding','Cross-sell'
    TONE              VARCHAR(20),  -- 'Professional','Warm','Urgent'
    REVIEWER_NOTE     TEXT,
    APPROVED_AT       TIMESTAMP_NTZ,
    CREATED_AT        TIMESTAMP_NTZ DEFAULT CURRENT_TIMESTAMP()
);

-- KPI SNAPSHOTS
CREATE OR REPLACE TABLE KPI_SNAPSHOTS (
    SNAPSHOT_ID             VARCHAR(36) DEFAULT UUID_STRING() PRIMARY KEY,
    ADVISOR_ID              VARCHAR(20) REFERENCES ADVISORS(ADVISOR_ID),
    SNAPSHOT_DATE           DATE DEFAULT CURRENT_DATE(),
    RETENTION_RATE          NUMBER(5,2),
    PIPELINE_VALUE          NUMBER(15,2),
    AVG_RESPONSE_TIME_HRS   NUMBER(5,2),
    POLICIES_AT_RISK_COUNT  INT,
    YTD_REVENUE             NUMBER(15,2),
    POLICIES_WRITTEN_YTD    INT,
    AVG_POLICY_SIZE         NUMBER(12,2),
    CLIENT_NPS              NUMBER(5,1)
);

-- AGENT ACTIVITY LOG
CREATE OR REPLACE TABLE AGENTS.AGENT_ACTIVITY_LOG (
    LOG_ID        VARCHAR(36) DEFAULT UUID_STRING() PRIMARY KEY,
    AGENT_NAME    VARCHAR(50),
    AGENT_PHASE   VARCHAR(50),
    STATUS        VARCHAR(20),  -- 'Running','Idle','Queued','Error'
    LOG_TIMESTAMP TIMESTAMP_NTZ DEFAULT CURRENT_TIMESTAMP(),
    LOG_MESSAGE   TEXT,
    RECORDS_AFFECTED INT
);

-- PREMIUM ANALYTICS (for bar chart)
CREATE OR REPLACE TABLE PREMIUM_MONTHLY (
    MONTH_LABEL   VARCHAR(10),
    MONTH_ORDER   INT,
    PRODUCT_TYPE  VARCHAR(30),
    PREMIUM_PCT   NUMBER(5,2)  -- relative bar height 0-100
);
```

---

## 3. SYNTHETIC DATA SEED

```sql
-- ── ADVISOR ──────────────────────────────────────────────────
INSERT INTO ADVISORS VALUES
('ADV001','James','Rivera','james.rivera@advisor360.com','Senior Financial Advisor','Southeast',CURRENT_TIMESTAMP());

-- ── CLIENTS ──────────────────────────────────────────────────
INSERT INTO CLIENTS (CLIENT_ID,ADVISOR_ID,FIRST_NAME,LAST_NAME,EMAIL,PHONE,LEAD_SOURCE,
    LEAD_DATE,CLIENT_SINCE_DATE,LIFE_STAGE,ESTIMATED_ASSETS,SENTIMENT_SCORE,DAYS_SINCE_CONTACT) VALUES
('CLT001','ADV001','Sarah','Chen','sarah.chen@email.com','404-555-0101','Referral',
    '2004-03-15','2004-03-15','Mid-career',850000,88,1),
('CLT002','ADV001','Marcus','Johnson','marcus.johnson@email.com','404-555-0202','Digital',
    '2025-02-14','2025-02-14','Young Family',120000,92,0),
('CLT003','ADV001','Robert','Park','robert.park@email.com','404-555-0303','Referral',
    '2015-01-10','2015-01-10','Pre-retirement',2050000,85,14),
('CLT004','ADV001','Linda','Morales','linda.morales@email.com','404-555-0404','Referral',
    '2017-06-20','2017-06-20','Mid-career',380000,64,47),
('CLT005','ADV001','Diana','Park','diana.park@email.com','404-555-0305','Referral',
    '2015-01-10','2015-01-10','Pre-retirement',2050000,85,14),
('CLT006','ADV001','Smith','Family','smith.family@email.com','404-555-0505','Employer',
    '2019-04-01','2019-04-01','Mid-career',450000,72,14),
('CLT007','ADV001','Apex','Manufacturing','apex.corp@email.com','404-555-0606','Employer',
    '2020-05-01','2020-05-01','Corporate',5000000,80,30),
('CLT008','ADV001','Thompson','Family','thompson@email.com','404-555-0707','Referral',
    '2014-08-20','2014-08-20','Pre-retirement',1200000,90,10),
('CLT009','ADV001','Garcia','Family','garcia@email.com','404-555-0808','Referral',
    '2021-11-15','2021-11-15','Young Family',200000,87,5),
('CLT010','ADV001','Chen-Williams','Estate','estate@email.com','404-555-0909','Referral',
    '2010-06-01','2010-06-01','High Net Worth',8500000,95,7);

-- ── POLICIES ──────────────────────────────────────────────────
INSERT INTO POLICIES (POLICY_ID,CLIENT_ID,POLICY_TYPE,POLICY_NUMBER,ANNUAL_PREMIUM,
    COVERAGE_AMOUNT,EFFECTIVE_DATE,RENEWAL_DATE,STATUS,ILLUSTRATED_GROWTH_RATE,
    ACTUAL_GROWTH_RATE,CASH_VALUE_ACTUAL,CASH_VALUE_PROJECTED,DAYS_TO_RENEWAL) VALUES
('POL001','CLT001','Term Life','TL-2019-0442',8400,1000000,'2019-02-18','2025-02-18','Renewing',NULL,NULL,NULL,NULL,3),
('POL002','CLT002','Term Life','TL-2025-0991',1920,500000,'2025-02-14','2026-02-14','Active',NULL,NULL,NULL,NULL,365),
('POL003','CLT003','Whole Life','WL-2015-0118',12400,2000000,'2015-01-15','2026-01-15','Active',NULL,NULL,NULL,NULL,335),
('POL004','CLT004','Universal Life','UL-2017-0887',5000,750000,'2017-06-20','2026-06-20','Review',0.038,0.021,42100,45800,490),
('POL005','CLT005','Whole Life','WL-2015-0119',3200,500000,'2015-01-15','2026-01-15','Active',NULL,NULL,NULL,NULL,335),
('POL006','CLT006','Whole Life','WL-2019-0234',3200,400000,'2019-04-01','2025-03-15','At Risk',NULL,NULL,NULL,NULL,47),
('POL007','CLT007','Group','GR-2020-0055',48000,NULL,'2020-05-01','2025-04-01','Renewing',NULL,NULL,NULL,NULL,47),
('POL008','CLT008','Whole Life','WL-2014-0234',5600,800000,'2014-08-20','2026-08-20','Active',NULL,NULL,NULL,NULL,185),
('POL009','CLT009','Term Life','TL-2021-0771',2400,300000,'2021-11-15','2026-11-15','Active',NULL,NULL,NULL,NULL,275),
('POL010','CLT010','Whole Life','WL-2010-0099',28800,5000000,'2010-06-01','2026-06-01','Active',NULL,NULL,NULL,NULL,107);

-- ── AI SCORES ──────────────────────────────────────────────────
INSERT INTO AI_SCORES (CLIENT_ID,SCORE_TYPE,SCORE_VALUE,MODEL_VERSION,NARRATIVE) VALUES
('CLT001','WL_PROPENSITY',72,'v2.1','High interest in cash value products given life stage'),
('CLT001','LAPSE_RISK',12,'v2.1','Low lapse risk — long tenure advisor relationship'),
('CLT001','CONVERSION_LIKELIHOOD',88,'v2.1','Renewal window open — high conversion probability'),
('CLT002','CONVERSION_LIKELIHOOD',87,'v2.1','New lead, submitted application — warm intent signal'),
('CLT002','WL_PROPENSITY',45,'v2.1','Young family stage — term first, WL opportunity in 3-5 years'),
('CLT003','LTC_PROPENSITY',91,'v2.1','Age 59 milestone — LTC pricing threshold imminent'),
('CLT003','WL_PROPENSITY',65,'v2.1','Existing WL holder — upsell potential for enhanced riders'),
('CLT004','LAPSE_RISK',68,'v2.1','Declining sentiment + underperformance = elevated lapse risk'),
('CLT004','WL_PROPENSITY',22,'v2.1','Current UL issues make WL cross-sell unlikely near-term'),
('CLT008','LTC_PROPENSITY',78,'v2.1','Pre-retirement stage, assets indicate LTC affordability');

-- ── WORKLIST ITEMS ──────────────────────────────────────────────
INSERT INTO WORKLIST_ITEMS (ADVISOR_ID,CLIENT_ID,TASK_DESCRIPTION,DUE_DATETIME,PRIORITY,
    STATUS,AI_NOTE,IS_AI_GENERATED,CATEGORY) VALUES
('ADV001','CLT001','Call Sarah Chen — Term Life renewal due Feb 18. Present WL upgrade option.',
    DATEADD('day',0,CURRENT_DATE()),'High','Pending',
    'Renewal window closes in 3 days. AI score 88% conversion likelihood. Call before 10am — most responsive window.', TRUE,'Renewal'),
('ADV001','CLT002','Welcome call — Marcus Johnson new application submitted Feb 14.',
    DATEADD('day',0,CURRENT_DATE()),'High','Pending',
    'New lead submitted application yesterday. Strike while warm — 87% conversion likelihood.',TRUE,'Onboarding'),
('ADV001','CLT004','Linda Morales UL policy review — underperformance flag raised.',
    DATEADD('day',0,CURRENT_DATE()),'High','Pending',
    'Cash value 45% below illustration. Client sentiment declining. Proactive contact protects retention.',TRUE,'Risk'),
('ADV001','CLT006','Follow up Smith Family — premium overdue 14 days.',
    DATEADD('day',1,CURRENT_DATE()),'Medium','Pending',
    'Grace period expires in 16 days. Gentle reminder call recommended.',TRUE,'Risk'),
('ADV001','CLT003','Schedule Robert Park — LTC rider opportunity before May birthday.',
    DATEADD('day',2,CURRENT_DATE()),'Medium','Pending',
    '91% LTC propensity. Rate lock window closes at age 60. 87 days remaining.',TRUE,'Outreach'),
('ADV001',NULL,'Review 3 pending AI-drafted communications in Communications tab.',
    DATEADD('day',0,CURRENT_DATE()),'Medium','Pending',
    'Communications drafted by Outreach Agent are awaiting your approval before send.',TRUE,'Admin'),
('ADV001',NULL,'Monthly analytics review — Feb performance report available.',
    DATEADD('day',3,CURRENT_DATE()),'Low','Pending',NULL,FALSE,'Admin');

-- ── COMMUNICATIONS ──────────────────────────────────────────────
INSERT INTO COMMUNICATIONS (CLIENT_ID,ADVISOR_ID,COMM_TYPE,STATUS,SUBJECT,BODY_CONTENT,TRIGGER_TYPE,TONE) VALUES
('CLT001','ADV001','Email','Draft',
    'Your $1M Coverage — Renewal Due Feb 18',
    'Hi Sarah,

Your Term Life policy is renewing on February 18th. I have reviewed your coverage and have a great Whole Life option that costs less than $40/month more with permanent protection and cash value growth.

Can we connect for 10 minutes this morning?

Best,
James Rivera',
    'Renewal','Warm'),
('CLT002','ADV001','Email','Draft',
    'Your Application — Next Steps',
    'Hi Marcus,

Thanks for your application last night. I have reviewed it and am excited to help you get the right coverage in place. I will call you at 9:30 AM to walk through next steps — should take about 10 minutes.

Looking forward to connecting.

Best,
James Rivera',
    'Onboarding','Warm'),
('CLT003','ADV001','Email','Draft',
    'Important: LTC Coverage Opportunity Before Your May Birthday',
    'Hi Robert,

I hope you and Diana are well. I wanted to reach out with something timely — as you approach your May birthday, there is an important window to add Long-Term Care coverage to your existing Whole Life policy at your current age-59 rate.

After age 60, LTC premiums increase by an average of 15-22%. By acting now, I estimate we could save you $800-$1,200 per year in perpetuity, while giving you and Diana real peace of mind about future care costs.

I have put together a proposal and would love to walk you through it. Would Feb 17th at 2pm work?

Best,
James Rivera',
    'Milestone','Professional'),
('CLT004','ADV001','Call Script','Draft',
    'Linda Morales — UL Performance Review Call',
    'CALL SCRIPT — Universal Life Review

Opening: "Hi Linda, this is James. Thanks for making time today. I have been actively monitoring your policy and wanted to connect proactively — this is not an alarm call, just a conversation I think will be valuable for us to have."

Key points:
1. Acknowledge the interest rate environment has shifted since 2017 — not a product failure
2. Present the cash value gap transparently: $42,100 actual vs $45,800 projected
3. Offer two options: (a) +$400/yr premium adjustment, (b) move 40% to fixed account at 4.5% guaranteed
4. Close: agree on action plan, schedule 90-day follow-up

What NOT to say: Do not minimize the gap. Do not present more than 2 options.',
    'Risk','Professional');

-- ── KPI SNAPSHOT ──────────────────────────────────────────────────
INSERT INTO KPI_SNAPSHOTS VALUES
(UUID_STRING(),'ADV001',CURRENT_DATE(),94.2,284000,1.8,3,186400,23,8100,4.7);

-- ── PREMIUM MONTHLY ──────────────────────────────────────────────
INSERT INTO PREMIUM_MONTHLY VALUES
('Sep',1,'Term Life',65),('Sep',1,'Whole Life',40),
('Oct',2,'Term Life',72),('Oct',2,'Whole Life',48),
('Nov',3,'Term Life',58),('Nov',3,'Whole Life',35),
('Dec',4,'Term Life',80),('Dec',4,'Whole Life',55),
('Jan',5,'Term Life',90),('Jan',5,'Whole Life',62),
('Feb',6,'Term Life',75),('Feb',6,'Whole Life',70);

-- ── AGENT ACTIVITY LOG ──────────────────────────────────────────
INSERT INTO AGENTS.AGENT_ACTIVITY_LOG (AGENT_NAME,AGENT_PHASE,STATUS,LOG_TIMESTAMP,LOG_MESSAGE,RECORDS_AFFECTED) VALUES
('Data Capture','Phase 1: Data Enrichment','Idle',DATEADD('minute',-11,CURRENT_TIMESTAMP()),'CRM sync complete — 42 records',42),
('Data Capture','Phase 1: Data Enrichment','Idle',DATEADD('minute',-10,CURRENT_TIMESTAMP()),'External enrichment complete',12),
('Systems Monitoring','Phase 1: Data Enrichment','Idle',DATEADD('minute',-9,CURRENT_TIMESTAMP()),'38 policies scanned',38),
('Systems Monitoring','Phase 1: Data Enrichment','Idle',DATEADD('minute',-8,CURRENT_TIMESTAMP()),'3 flags raised — 1 High, 2 Medium',3),
('Analysis & Insights','Phase 2: Insight Synthesis','Running',DATEADD('minute',-3,CURRENT_TIMESTAMP()),'Scoring CLT001 — WL propensity 72%',1),
('Analysis & Insights','Phase 2: Insight Synthesis','Running',DATEADD('minute',-2,CURRENT_TIMESTAMP()),'Scoring CLT003 — LTC propensity 91%',1),
('Meeting Prep','Phase 2: Insight Synthesis','Running',DATEADD('minute',-1,CURRENT_TIMESTAMP()),'Generating meeting pack for Sarah Chen',1),
('Outreach Agent','Phase 3: Personalized Enablement','Queued',CURRENT_TIMESTAMP(),'Awaiting insights — queued for Robert Park LTC email',0);
```

---

## 4. CORTEX AI INTEGRATION — KEY FUNCTIONS

Use Snowflake Cortex functions for all AI inference. Do not call external APIs.

### 4.1 Propensity Score Narrative
```sql
-- Called in agent_insight_synthesis() — wrap in a Stored Procedure
SELECT SNOWFLAKE.CORTEX.COMPLETE(
    'mistral-large2',
    ARRAY_CONSTRUCT(
        OBJECT_CONSTRUCT('role','system','content',
            'You are an insurance advisor AI. Given client data, generate a 2-sentence insight explaining a propensity score. Be specific, data-driven, and actionable. No preamble.'),
        OBJECT_CONSTRUCT('role','user','content',
            'Client: ' || FIRST_NAME || ' ' || LAST_NAME ||
            '. Life stage: ' || LIFE_STAGE ||
            '. Sentiment: ' || SENTIMENT_SCORE ||
            '. Score type: WL_PROPENSITY. Score: 72. Generate insight.')
    )
) AS NARRATIVE
FROM CLIENTS WHERE CLIENT_ID = 'CLT001';
```

### 4.2 Email Draft Generation
```sql
SELECT SNOWFLAKE.CORTEX.COMPLETE(
    'mistral-large2',
    ARRAY_CONSTRUCT(
        OBJECT_CONSTRUCT('role','system','content',
            'You are an insurance advisor AI drafting outreach emails for advisor James Rivera. Write in a warm, professional tone. 3-4 short paragraphs. Sign off as James Rivera. No preamble.'),
        OBJECT_CONSTRUCT('role','user','content',
            'Draft a renewal email for client Sarah Chen. Policy: Term Life $1M, renewal due Feb 18. Objective: secure renewal and present Whole Life upgrade at <$40/month additional premium.')
    )
) AS EMAIL_DRAFT;
```

### 4.3 Revision via Advisor Note
```sql
-- When advisor clicks "Revise" and provides a note
SELECT SNOWFLAKE.CORTEX.COMPLETE(
    'mistral-large2',
    ARRAY_CONSTRUCT(
        OBJECT_CONSTRUCT('role','system','content','You are an insurance advisor AI. Revise the provided email draft based on the advisor instruction. Return only the revised email, no commentary.'),
        OBJECT_CONSTRUCT('role','user','content',
            'Original draft: ' || :original_draft ||
            '\n\nAdvisor instruction: ' || :advisor_note ||
            '\n\nReturn the revised email only.')
    )
) AS REVISED_DRAFT;
```

### 4.4 Meeting Talking Points
```sql
SELECT SNOWFLAKE.CORTEX.COMPLETE(
    'mistral-large2',
    ARRAY_CONSTRUCT(
        OBJECT_CONSTRUCT('role','system','content',
            'You are a meeting prep AI for insurance advisor James Rivera. Generate 4 numbered talking points for an upcoming client meeting. Each point should be a specific, actionable sentence the advisor can speak verbatim. Return only the 4 points, no preamble.'),
        OBJECT_CONSTRUCT('role','user','content',
            'Client: Sarah Chen. Meeting objective: Term Life renewal + Whole Life upgrade pitch. Client profile: 20-year tenure, youngest going to college, policy $1M coverage, renewal in 3 days.')
    )
) AS TALKING_POINTS;
```

---

## 5. STREAMLIT APP ARCHITECTURE

### 5.1 File Structure (Snowflake Stage)
```
advisor360_app/
├── streamlit_app.py          # Main app entry point — navigation + session state
├── pages/
│   ├── 01_dashboard.py
│   ├── 02_clients_leads.py
│   ├── 03_worklist.py
│   ├── 04_communications.py
│   ├── 05_policies.py
│   ├── 06_analytics.py
│   ├── 07_prep_tools.py
│   ├── 08_agent_panel.py
│   └── 09_ai_preferences.py
├── components/
│   ├── agent_output_panel.py  # Shared modal/panel component
│   ├── kpi_cards.py
│   └── styles.py              # CSS injection
└── utils/
    ├── db.py                  # Snowflake connection + query helpers
    └── cortex.py              # Cortex AI call wrappers
```

### 5.2 Color Tokens (inject via st.markdown CSS)
```python
# components/styles.py
CSS_VARS = """
<style>
:root {
  --purple: #7B2FBE;
  --purple-d: #5A1E8C;
  --purple-l: #9B4FDE;
  --purple-pale: #F3EAFD;
  --teal: #0F7EA6;
  --teal-l: #1DA5D8;
  --navy: #1A2340;
  --navy-m: #2C3A5A;
  --slate: #4A5568;
  --gray: #718096;
  --gray-l: #A0AEC0;
  --border: #E2E8F0;
  --bg: #F7F8FC;
  --green: #10B981;
  --green-pale: #ECFDF5;
  --amber: #F59E0B;
  --red: #EF4444;
  --red-pale: #FEF2F2;
  --blue: #2563EB;
}
body { font-family: 'DM Sans', sans-serif !important; }
[data-testid="stSidebar"] { background-color: #1A2340 !important; }
[data-testid="stSidebar"] * { color: rgba(255,255,255,0.85) !important; }
.stMetric { background: white; border: 1px solid #E2E8F0; border-radius: 9px; padding: 14px; }
</style>
"""
```

---

## 6. PAGE-BY-PAGE BUILD SPECIFICATION

### 6.1 streamlit_app.py — Entry Point

```python
import streamlit as st
from components.styles import CSS_VARS

st.set_page_config(
    page_title="Advisor360",
    page_icon="🧠",
    layout="wide",
    initial_sidebar_state="expanded"
)

st.markdown(CSS_VARS, unsafe_allow_html=True)

# Session state initialization
if 'panel_open' not in st.session_state:
    st.session_state.panel_open = False
if 'panel_context' not in st.session_state:
    st.session_state.panel_context = None  # dict: {type, client_id, policy_id, comm_id}
if 'ai_preferences' not in st.session_state:
    st.session_state.ai_preferences = {
        'auto_draft_emails': True,
        'auto_crm_update': True,
        'require_review': True,
        'flag_policy_changes': True
    }
if 'approved_actions' not in st.session_state:
    st.session_state.approved_actions = set()

# Sidebar
with st.sidebar:
    # Logo
    st.markdown("""
    <div style="padding:16px 18px 12px; border-bottom:1px solid rgba(255,255,255,.08)">
      <div style="display:flex;align-items:center;gap:9px">
        <div style="width:30px;height:30px;background:linear-gradient(135deg,#9B4FDE,#1DA5D8);
             border-radius:7px;display:flex;align-items:center;justify-content:center;
             font-weight:700;color:#fff;font-size:12px">A3</div>
        <div>
          <div style="color:#fff;font-weight:700;font-size:14px">Advisor360</div>
          <div style="color:rgba(255,255,255,.35);font-size:10px">Agentic Workspace</div>
        </div>
      </div>
    </div>
    """, unsafe_allow_html=True)
    
    # Advisor profile
    st.markdown("""
    <div style="padding:12px 18px;border-bottom:1px solid rgba(255,255,255,.06)">
      <div style="display:flex;align-items:center;gap:9px">
        <div style="width:30px;height:30px;border-radius:50%;background:linear-gradient(135deg,#7B2FBE,#0F7EA6);
             display:flex;align-items:center;justify-content:center;color:#fff;font-weight:700;font-size:11px">JR</div>
        <div>
          <div style="color:#fff;font-weight:600;font-size:12px">James Rivera</div>
          <div style="color:rgba(255,255,255,.38);font-size:10px">Senior Financial Advisor</div>
        </div>
      </div>
    </div>
    """, unsafe_allow_html=True)
    
    st.page_link("streamlit_app.py", label="🏠 Dashboard", use_container_width=True)
    st.page_link("pages/02_clients_leads.py", label="👥 Clients & Leads", use_container_width=True)
    st.page_link("pages/03_worklist.py", label="✅ Smart Worklist", use_container_width=True)
    st.page_link("pages/04_communications.py", label="📧 Communications", use_container_width=True)
    st.page_link("pages/05_policies.py", label="📋 Policies", use_container_width=True)
    st.page_link("pages/06_analytics.py", label="📊 Analytics", use_container_width=True)
    st.page_link("pages/07_prep_tools.py", label="🎯 Prep Tools", use_container_width=True)
    st.page_link("pages/08_agent_panel.py", label="🤖 Agent Panel", use_container_width=True)
    st.page_link("pages/09_ai_preferences.py", label="⚙️ AI Preferences", use_container_width=True)
    
    # AI Status
    st.markdown("""
    <div style="margin-top:auto;padding:12px 18px;border-top:1px solid rgba(255,255,255,.07)">
      <div style="color:rgba(255,255,255,.35);font-size:9px;font-weight:700;text-transform:uppercase;
           letter-spacing:.06em;margin-bottom:6px;display:flex;align-items:center;gap:5px">
        <span style="width:5px;height:5px;border-radius:50%;background:#10B981;display:inline-block"></span>
        Snowflake Cortex AI
      </div>
      <div style="background:rgba(255,255,255,.1);border-radius:2px;height:3px;margin-bottom:3px">
        <div style="background:linear-gradient(90deg,#9B4FDE,#1DA5D8);border-radius:2px;height:3px;width:78%"></div>
      </div>
      <div style="color:rgba(255,255,255,.38);font-size:9.5px">Confidence: 78% · 3 agents active</div>
    </div>
    """, unsafe_allow_html=True)
```

---

### 6.2 pages/01_dashboard.py

```python
import streamlit as st
import pandas as pd
from utils.db import run_query
from components.agent_output_panel import render_panel

st.header("Good morning, James 👋")
st.caption("Thursday, February 15, 2025 · 3 tasks require your attention today")

# AI Daily Briefing card
st.markdown("""
<div style="background:linear-gradient(135deg,#1A1A2E,#16213E,#0F3460);
     border-radius:10px;padding:14px 18px;margin-bottom:18px">
  <div style="display:flex;align-items:center;gap:7px;margin-bottom:10px">
    <div style="width:26px;height:26px;border-radius:6px;
         background:linear-gradient(135deg,#9B4FDE,#1DA5D8);
         display:flex;align-items:center;justify-content:center;font-size:12px">🧠</div>
    <div>
      <div style="color:#fff;font-weight:700;font-size:12px">AI Daily Briefing</div>
      <div style="color:rgba(255,255,255,.4);font-size:10px">Agents ran at 8:49 AM · 3 priorities identified</div>
    </div>
  </div>
  <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:8px">
    <div style="background:rgba(255,255,255,.07);border:1px solid rgba(255,255,255,.1);
         border-radius:7px;padding:10px">
      <div style="color:#F59E0B;font-size:8.5px;font-weight:700;text-transform:uppercase;
           margin-bottom:5px">🎯 PRIORITY TASK</div>
      <div style="color:#fff;font-weight:600;font-size:11.5px;margin-bottom:3px">
           Sarah Chen — Renewal Due in 3 Days</div>
      <div style="color:rgba(255,255,255,.5);font-size:10.5px">
           $1M Term Life renewal. WL upgrade opportunity at &lt;$40/mo more.</div>
    </div>
    <div style="background:rgba(255,255,255,.07);border:1px solid rgba(255,255,255,.1);
         border-radius:7px;padding:10px">
      <div style="color:#10B981;font-size:8.5px;font-weight:700;text-transform:uppercase;
           margin-bottom:5px">💰 REVENUE OPPORTUNITY</div>
      <div style="color:#fff;font-weight:600;font-size:11.5px;margin-bottom:3px">
           Robert Park — LTC Rider $3,200/yr</div>
      <div style="color:rgba(255,255,255,.5);font-size:10.5px">
           Age 59 rate lock window. 91% LTC propensity. 87 days to threshold.</div>
    </div>
    <div style="background:rgba(255,255,255,.07);border:1px solid rgba(255,255,255,.1);
         border-radius:7px;padding:10px">
      <div style="color:#EF4444;font-size:8.5px;font-weight:700;text-transform:uppercase;
           margin-bottom:5px">⚠️ RISK ALERT</div>
      <div style="color:#fff;font-weight:600;font-size:11.5px;margin-bottom:3px">
           Linda Morales — UL Underperformance</div>
      <div style="color:rgba(255,255,255,.5);font-size:10.5px">
           Cash value -1.7% vs illustration. Sentiment 64%. Proactive review needed.</div>
    </div>
  </div>
</div>
""", unsafe_allow_html=True)

# KPIs
kpi_data = run_query("""
    SELECT RETENTION_RATE, PIPELINE_VALUE, AVG_RESPONSE_TIME_HRS,
           POLICIES_AT_RISK_COUNT
    FROM ADVISOR360_DB.APP.KPI_SNAPSHOTS
    WHERE ADVISOR_ID = 'ADV001'
    ORDER BY SNAPSHOT_DATE DESC LIMIT 1
""")

if not kpi_data.empty:
    col1, col2, col3, col4 = st.columns(4)
    with col1:
        st.metric("Retention Rate", f"{kpi_data['RETENTION_RATE'].iloc[0]:.1f}%", "+2.1%")
    with col2:
        st.metric("Pipeline Value", f"${kpi_data['PIPELINE_VALUE'].iloc[0]/1000:.0f}K", "+$12K")
    with col3:
        st.metric("Avg Response Time", f"{kpi_data['AVG_RESPONSE_TIME_HRS'].iloc[0]:.1f}h", "-0.3h")
    with col4:
        st.metric("Policies At Risk", int(kpi_data['POLICIES_AT_RISK_COUNT'].iloc[0]), "+1",
                  delta_color="inverse")

# Two-column layout: Worklist + Priority Clients
col_left, col_right = st.columns([1, 1])

with col_left:
    st.subheader("Smart Worklist")
    worklist = run_query("""
        SELECT W.ITEM_ID, C.FIRST_NAME || ' ' || C.LAST_NAME AS CLIENT_NAME,
               W.TASK_DESCRIPTION, W.PRIORITY, W.DUE_DATETIME, W.AI_NOTE, W.IS_AI_GENERATED
        FROM ADVISOR360_DB.APP.WORKLIST_ITEMS W
        LEFT JOIN ADVISOR360_DB.APP.CLIENTS C ON W.CLIENT_ID = C.CLIENT_ID
        WHERE W.ADVISOR_ID = 'ADV001' AND W.STATUS = 'Pending'
        ORDER BY FIELD(W.PRIORITY,'High','Medium','Low'), W.DUE_DATETIME
        LIMIT 5
    """)
    # NOTE: Snowflake does not support FIELD(); use CASE for ordering:
    # ORDER BY CASE W.PRIORITY WHEN 'High' THEN 1 WHEN 'Medium' THEN 2 ELSE 3 END
    
    for _, row in worklist.iterrows():
        priority_color = {'High': '#EF4444', 'Medium': '#F59E0B', 'Low': '#10B981'}.get(row['PRIORITY'], '#718096')
        with st.container():
            col_chk, col_body = st.columns([0.05, 0.95])
            with col_chk:
                done = st.checkbox("", key=f"wl_{row['ITEM_ID']}")
            with col_body:
                task_text = f"~~{row['TASK_DESCRIPTION']}~~" if done else row['TASK_DESCRIPTION']
                st.markdown(f"**{task_text}**")
                if row['AI_NOTE']:
                    st.caption(f"🤖 {row['AI_NOTE']}")
            st.divider()

with col_right:
    st.subheader("Priority Clients")
    filter_col = st.columns(5)
    # Filter tabs — use radio buttons styled as tabs
    priority_filter = st.radio("Filter", ["All", "Renewal", "New Lead", "Cross-sell", "Policy Review"],
                                horizontal=True, label_visibility="collapsed")
    
    clients = run_query("""
        SELECT C.CLIENT_ID, C.FIRST_NAME || ' ' || C.LAST_NAME AS CLIENT_NAME,
               P.POLICY_TYPE, P.STATUS, P.DAYS_TO_RENEWAL,
               MAX(CASE WHEN S.SCORE_TYPE = 'WL_PROPENSITY' THEN S.SCORE_VALUE END) AS WL_SCORE,
               MAX(CASE WHEN S.SCORE_TYPE = 'CONVERSION_LIKELIHOOD' THEN S.SCORE_VALUE END) AS CONV_SCORE
        FROM ADVISOR360_DB.APP.CLIENTS C
        JOIN ADVISOR360_DB.APP.POLICIES P ON C.CLIENT_ID = P.CLIENT_ID
        LEFT JOIN ADVISOR360_DB.APP.AI_SCORES S ON C.CLIENT_ID = S.CLIENT_ID
        WHERE C.ADVISOR_ID = 'ADV001'
        GROUP BY 1,2,3,4,5
        ORDER BY P.DAYS_TO_RENEWAL ASC NULLS LAST
        LIMIT 8
    """)
    
    for _, row in clients.iterrows():
        with st.expander(f"**{row['CLIENT_NAME']}** — {row['POLICY_TYPE']}"):
            col_a, col_b = st.columns([2, 1])
            with col_a:
                st.caption(f"Status: {row['STATUS']}")
                if row['DAYS_TO_RENEWAL']:
                    st.caption(f"Renewal in {int(row['DAYS_TO_RENEWAL'])} days")
            with col_b:
                if row['WL_SCORE']:
                    st.caption(f"WL: {row['WL_SCORE']:.0f}%")
                if row['CONV_SCORE']:
                    st.caption(f"Conv: {row['CONV_SCORE']:.0f}%")
            if st.button("Open Agent Panel →", key=f"dash_panel_{row['CLIENT_ID']}"):
                st.session_state.panel_open = True
                st.session_state.panel_context = {
                    'type': 'renewal',
                    'client_id': row['CLIENT_ID'],
                    'client_name': row['CLIENT_NAME']
                }
                st.rerun()

# Render panel if open
if st.session_state.panel_open:
    render_panel(st.session_state.panel_context)
```

---

### 6.3 pages/04_communications.py

```python
import streamlit as st
import pandas as pd
from utils.db import run_query, run_update
from utils.cortex import revise_email
from components.agent_output_panel import render_panel

st.header("Communications")
st.caption("AI-drafted outreach awaiting your review before sending")

comms = run_query("""
    SELECT COMM.COMM_ID, C.FIRST_NAME || ' ' || C.LAST_NAME AS CLIENT_NAME,
           COMM.COMM_TYPE, COMM.STATUS, COMM.SUBJECT, COMM.BODY_CONTENT,
           COMM.TRIGGER_TYPE, COMM.CREATED_AT
    FROM ADVISOR360_DB.APP.COMMUNICATIONS COMM
    JOIN ADVISOR360_DB.APP.CLIENTS C ON COMM.CLIENT_ID = C.CLIENT_ID
    WHERE COMM.ADVISOR_ID = 'ADV001'
    ORDER BY COMM.CREATED_AT DESC
""")

status_colors = {
    'Draft': ('#F3EAFD', '#7B2FBE'),
    'Approved': ('#ECFDF5', '#059669'),
    'Sent': ('#EFF6FF', '#2563EB'),
    'Rejected': ('#FEF2F2', '#DC2626')
}

for _, row in comms.iterrows():
    bg, color = status_colors.get(row['STATUS'], ('#F7F8FC', '#718096'))
    
    with st.container():
        col1, col2 = st.columns([0.85, 0.15])
        with col1:
            icon = "📧" if row['COMM_TYPE'] == 'Email' else "📞"
            st.markdown(f"""
            <div style="padding:12px 14px;border:1px solid #E2E8F0;border-radius:9px;
                 margin-bottom:8px;background:white;cursor:pointer">
              <div style="display:flex;align-items:center;gap:10px">
                <div style="font-size:20px">{icon}</div>
                <div style="flex:1">
                  <div style="font-weight:600;font-size:12px">{row['CLIENT_NAME']}</div>
                  <div style="font-size:10.5px;color:#718096;margin-top:2px">{row['SUBJECT']}</div>
                  <div style="font-size:9px;font-weight:700;padding:2px 6px;border-radius:3px;
                       display:inline-block;background:{bg};color:{color};margin-top:4px">
                       {row['STATUS']} · {row['COMM_TYPE']}</div>
                </div>
              </div>
            </div>
            """, unsafe_allow_html=True)
        with col2:
            if st.button("Review →", key=f"comm_{row['COMM_ID']}"):
                st.session_state.panel_open = True
                st.session_state.panel_context = {
                    'type': 'outreach',
                    'comm_id': row['COMM_ID'],
                    'client_name': row['CLIENT_NAME'],
                    'comm_type': row['COMM_TYPE'],
                    'subject': row['SUBJECT'],
                    'body': row['BODY_CONTENT']
                }
                st.rerun()

if st.session_state.panel_open:
    render_panel(st.session_state.panel_context)
```

---

### 6.4 components/agent_output_panel.py — The HITL Panel

This is the most critical component. It renders as a wide sidebar-style panel using `st.sidebar` alternative or a full-width expander overlay. In Streamlit in Snowflake, implement as a full-page overlay rendered conditionally.

```python
import streamlit as st
from utils.db import run_query, run_update
from utils.cortex import revise_email, generate_talking_points

def render_panel(context: dict):
    """Renders the Agent Output Panel as an overlay when panel_open = True."""
    
    if not st.session_state.get('panel_open'):
        return
    
    panel_type = context.get('type', 'renewal')
    
    # Panel header
    st.markdown("---")
    
    # Title bar with close button
    title_col, close_col = st.columns([0.9, 0.1])
    with title_col:
        titles = {
            'renewal': f"Sarah Chen — Term Life Renewal",
            'outreach': f"{context.get('client_name','Client')} — {context.get('comm_type','Communication')}",
            'ltc': f"Robert Park — LTC Rider Opportunity",
            'risk': f"Linda Morales — UL Performance Review",
            'meeting_prep': f"Meeting Pack — Sarah Chen",
            'insights': f"Analysis & Insights Report",
        }
        subtitles = {
            'renewal': "Data Enrichment → Insight Synthesis → Meeting Pack → Outreach Draft",
            'outreach': "AI-drafted outreach awaiting advisor review before sending",
            'ltc': "Milestone Detection → Propensity Analysis → Proposal → Outreach",
            'risk': "Risk Detection → Policy Analysis → Review Report → Outreach",
            'meeting_prep': "AI-generated pack ready for advisor review before the 9:00 AM call",
            'insights': "AI-generated portfolio-level insights for James Rivera",
        }
        st.markdown(f"### {titles.get(panel_type, 'Agent Output')}")
        st.caption(subtitles.get(panel_type, ''))
    with close_col:
        if st.button("✕ Close"):
            st.session_state.panel_open = False
            st.session_state.panel_context = None
            st.rerun()
    
    # Step tabs
    tab_configs = {
        'renewal': ['Data Enrichment', 'Insight Synthesis', 'Meeting Pack', 'Outreach Draft'],
        'outreach': ['Email Preview', 'Edit & Revise', 'Send Options'],
        'ltc': ['Milestone Alert', 'Analysis', 'LTC Proposal', 'Outreach Draft'],
        'risk': ['Risk Detection', 'Policy Analysis', 'Review Report', 'Outreach Draft'],
        'meeting_prep': ['Client Brief', 'Talking Points', 'Leave-Behind', 'Post-Meeting'],
        'insights': ['Portfolio Summary', 'Top Opportunities', 'Risk Flags', 'Next Actions'],
    }
    
    tabs = tab_configs.get(panel_type, ['Overview'])
    tab_objects = st.tabs(tabs)
    
    # ── RENEWAL PANEL ─────────────────────────────────────────────
    if panel_type == 'renewal':
        with tab_objects[0]:  # Data Enrichment
            _render_client_data_card('CLT001')
        
        with tab_objects[1]:  # Insight Synthesis
            _render_scores({
                'WL Propensity': (72, 'purple'),
                'Renewal Likelihood': (88, 'green'),
                'Lapse Risk': (12, 'green'),
            })
            st.markdown("""
            **Key Insights**
            - Renewal window closes in **3 days** — highest conversion urgency
            - WL upgrade opportunity: &lt;$40/mo delta, cash value benefit applies
            - Client tenure 20 years — strong relationship foundation
            """)
        
        with tab_objects[2]:  # Meeting Pack
            st.markdown("**Recommended Agenda**")
            st.markdown("""
            1. Open with coverage continuity — "Your $1M has protected your family for 20 years."
            2. Bridge to Whole Life — "With your youngest heading to college, permanent coverage makes sense now."
            3. Handle premium question — "The difference is less than $40/month. I have a side-by-side."
            4. Close — "I can have the paperwork ready today."
            """)
        
        with tab_objects[3]:  # Outreach Draft
            _render_email_panel('CLT001', 'renewal')
    
    # ── OUTREACH PANEL ─────────────────────────────────────────────
    elif panel_type == 'outreach':
        comm_body = context.get('body', '')
        
        with tab_objects[0]:  # Email Preview
            st.markdown(f"""
            <div style="border:1px solid #E2E8F0;border-radius:9px;overflow:hidden;background:white">
              <div style="padding:12px 16px;border-bottom:1px solid #E2E8F0;background:#F7F8FC">
                <div style="font-size:11px;color:#718096"><strong>To:</strong> {context.get('client_name','')}</div>
                <div style="font-size:11px;color:#718096;margin-top:4px"><strong>Subject:</strong> {context.get('subject','')}</div>
                <div style="font-size:9px;color:#7B2FBE;margin-top:4px;font-weight:600">
                🤖 Outreach Agent · Awaiting advisor review</div>
              </div>
              <div style="padding:16px;font-size:12px;line-height:1.7;color:#2D3748;
                   white-space:pre-wrap">{comm_body}</div>
            </div>
            """, unsafe_allow_html=True)
        
        with tab_objects[1]:  # Edit & Revise
            st.markdown("**Revise Instructions**")
            revision_note = st.text_area(
                "Tell the agent how to modify this draft:",
                placeholder="e.g. 'Adjust tone to be more casual', 'Change the call time to 2pm', 'Lead with the savings figure'",
                height=100,
                label_visibility="collapsed"
            )
            if st.button("✏️ Revise with Cortex AI"):
                if revision_note.strip():
                    with st.spinner("Agent regenerating..."):
                        revised = revise_email(comm_body, revision_note)
                    st.session_state.panel_context['body'] = revised
                    st.success("Draft revised. Switch to Email Preview to review.")
                    st.rerun()
                else:
                    st.warning("Please add a revision note first.")
        
        with tab_objects[2]:  # Send Options
            _render_hitl_footer('outreach', context.get('comm_id'))
    
    # ── RISK PANEL ─────────────────────────────────────────────────
    elif panel_type == 'risk':
        with tab_objects[0]:
            _render_risk_detection_card()
        with tab_objects[1]:
            _render_policy_metrics()
        with tab_objects[2]:
            _render_review_report()
        with tab_objects[3]:
            _render_email_panel('CLT004', 'risk')
    
    # ── MEETING PREP PANEL ─────────────────────────────────────────
    elif panel_type == 'meeting_prep':
        with tab_objects[0]:
            _render_client_data_card('CLT001')
        with tab_objects[1]:
            if st.button("🤖 Regenerate Talking Points via Cortex"):
                with st.spinner("Generating..."):
                    points = generate_talking_points('CLT001', 'renewal')
                st.session_state['talking_points'] = points
            
            default_points = st.session_state.get('talking_points', [
                'Lead with coverage continuity — "Your $1M coverage has protected your family for 20 years."',
                'Bridge to Whole Life — "With your youngest heading to college, permanent coverage builds cash value."',
                'Handle the premium question — "The difference is less than $40/month. I have a comparison ready."',
                'Close — "I can have the paperwork ready today. Want me to send the WL application while we are on the phone?"'
            ])
            for i, point in enumerate(default_points, 1):
                st.markdown(f"""
                <div style="display:flex;gap:8px;padding:9px;background:#F7F8FC;
                     border-radius:6px;border-left:3px solid #7B2FBE;margin-bottom:6px">
                  <span style="color:#7B2FBE;font-weight:700;font-size:11.5px;flex-shrink:0">{i}</span>
                  <span style="font-size:11.5px;color:#4A5568;line-height:1.5">{point}</span>
                </div>
                """, unsafe_allow_html=True)
        
        with tab_objects[2]:
            st.info("Leave-behind PDF auto-generated. Contents: policy summary, premium comparison, cash value projection (10/20/30yr), estate planning overview, next steps with QR code for e-signature.")
        
        with tab_objects[3]:
            _render_post_meeting_checklist()
    
    # HITL footer for relevant panel types
    if panel_type in ['renewal', 'ltc', 'risk']:
        st.markdown("---")
        _render_hitl_footer(panel_type, context.get('comm_id'))


def _render_client_data_card(client_id: str):
    """Renders a unified client data card."""
    data = run_query(f"""
        SELECT C.FIRST_NAME || ' ' || C.LAST_NAME AS CLIENT_NAME,
               C.EMAIL, C.LIFE_STAGE, C.DAYS_SINCE_CONTACT, C.SENTIMENT_SCORE,
               P.POLICY_TYPE, P.POLICY_NUMBER, P.ANNUAL_PREMIUM,
               P.COVERAGE_AMOUNT, P.RENEWAL_DATE, P.STATUS, P.DAYS_TO_RENEWAL
        FROM ADVISOR360_DB.APP.CLIENTS C
        JOIN ADVISOR360_DB.APP.POLICIES P ON C.CLIENT_ID = P.CLIENT_ID
        WHERE C.CLIENT_ID = '{client_id}'
        LIMIT 1
    """)
    if data.empty:
        return
    row = data.iloc[0]
    st.markdown(f"**{row['CLIENT_NAME']}** · {row['POLICY_TYPE']} · {row['POLICY_NUMBER']}")
    col1, col2 = st.columns(2)
    with col1:
        st.caption(f"📧 {row['EMAIL']}")
        st.caption(f"💼 {row['LIFE_STAGE']}")
        st.caption(f"📋 Premium: ${row['ANNUAL_PREMIUM']:,.0f}/yr")
    with col2:
        st.caption(f"🛡 Coverage: ${row['COVERAGE_AMOUNT']/1000000:.1f}M")
        st.caption(f"📅 Renewal: {row['RENEWAL_DATE']} ({int(row['DAYS_TO_RENEWAL'])} days)")
        st.caption(f"💬 Sentiment: {row['SENTIMENT_SCORE']:.0f}%")


def _render_scores(scores: dict):
    """Renders animated-style propensity score bars."""
    for label, (value, color) in scores.items():
        color_map = {'purple': '#7B2FBE', 'green': '#10B981', 'red': '#EF4444', 'teal': '#0F7EA6'}
        hex_color = color_map.get(color, '#7B2FBE')
        st.markdown(f"""
        <div style="display:flex;align-items:center;gap:12px;margin-bottom:10px">
          <div style="flex:0 0 160px;font-size:11px;color:#4A5568">{label}</div>
          <div style="flex:1;background:#E2E8F0;border-radius:2px;height:8px">
            <div style="background:{hex_color};border-radius:2px;height:8px;width:{value}%"></div>
          </div>
          <div style="flex:0 0 40px;font-size:12px;font-weight:700;color:{hex_color};
               text-align:right">{value}%</div>
        </div>
        """, unsafe_allow_html=True)


def _render_hitl_footer(footer_type: str, comm_id: str = None):
    """Renders the Human-in-the-Loop action footer."""
    
    panel_key = footer_type + (comm_id or '')
    
    if panel_key in st.session_state.get('approved_actions', set()):
        st.success("✅ Action approved and queued — agents will execute.")
        return
    
    if footer_type == 'outreach':
        st.warning("👁 Human-in-the-Loop Review Required — Review the AI output above before approving any outreach.")
        col1, col2, col3, col4 = st.columns(4)
        with col1:
            if st.button("✅ Approve & Send", key=f"approve_{panel_key}", type="primary"):
                if comm_id:
                    run_update(f"UPDATE ADVISOR360_DB.APP.COMMUNICATIONS SET STATUS='Approved' WHERE COMM_ID='{comm_id}'")
                st.session_state.setdefault('approved_actions', set()).add(panel_key)
                st.success("Email approved and sending via Outlook.")
                st.rerun()
        with col2:
            if st.button("📅 Approve & Schedule", key=f"sched_{panel_key}"):
                st.info("Email scheduled for optimal send time.")
        with col3:
            if st.button("✏️ Revise", key=f"revise_{panel_key}"):
                st.info("Switch to 'Edit & Revise' tab to provide instructions.")
        with col4:
            if st.button("✗ Reject", key=f"reject_{panel_key}"):
                if comm_id:
                    run_update(f"UPDATE ADVISOR360_DB.APP.COMMUNICATIONS SET STATUS='Rejected' WHERE COMM_ID='{comm_id}'")
                st.warning("Action rejected — agent notified.")
    
    elif footer_type == 'review':
        st.warning("⚠️ Risk Alert — Review the policy analysis before scheduling client outreach.")
        col1, col2, col3, col4 = st.columns(4)
        with col1:
            if st.button("📞 Schedule Review Call", key=f"call_{panel_key}", type="primary"):
                st.session_state.setdefault('approved_actions', set()).add(panel_key)
                st.success("Review call scheduled — calendar invite sent.")
                st.rerun()
        with col2:
            if st.button("✉ Approve & Send Email", key=f"email_{panel_key}"):
                st.success("Risk review email approved and sending.")
        with col3:
            if st.button("✏️ Revise Output", key=f"revise_{panel_key}"):
                st.info("Use revision note in the Outreach Draft tab.")
        with col4:
            if st.button("✗ Dismiss Alert", key=f"dismiss_{panel_key}"):
                st.warning("Alert dismissed — logged for record.")
    
    elif footer_type == 'renewal':
        st.info("📋 Meeting Pack Ready — Review before your call and confirm you're ready to proceed.")
        col1, col2 = st.columns(2)
        with col1:
            if st.button("✅ Confirm Pack — I'm Ready", key=f"confirm_{panel_key}", type="primary"):
                st.session_state.setdefault('approved_actions', set()).add(panel_key)
                st.success("Meeting pack confirmed — good luck!")
                st.rerun()
        with col2:
            if st.button("🔄 Regenerate Pack", key=f"regen_{panel_key}"):
                st.info("Pack regenerating via Cortex...")


def _render_risk_detection_card():
    st.markdown("**Risk Alert — Systems Monitoring Agent**")
    metrics = {
        'Policy': 'Universal Life · #UL-2017-0887',
        'Annual Premium': '$5,000 / yr',
        'Actual Cash Value Growth': '2.1% YTD ⚠️',
        'Illustrated Growth Rate': '3.8% YTD (as sold)',
        'Variance': '-1.7% — 45% below illustration',
        'Client Sentiment': '64% — Declining engagement',
        'Risk Level': 'HIGH — Proactive review required',
        'Days Since Last Contact': '47 days',
    }
    col1, col2 = st.columns(2)
    items = list(metrics.items())
    for i, (k, v) in enumerate(items):
        col = col1 if i % 2 == 0 else col2
        with col:
            st.caption(f"**{k}:** {v}")


def _render_policy_metrics():
    metrics = [
        ('Cash Value Actual vs Projection', '$42,100 vs $45,800 projected', 'bad'),
        ('Monthly Cost of Insurance (COI)', 'Increasing — age band change in 8 months', 'warn'),
        ('Current Interest Crediting Rate', '4.2% (was 5.1% at issue)', 'bad'),
        ('Policy Lapse Risk (5-yr)', 'Moderate — if premium unchanged', 'warn'),
        ('Recommended Premium Adjustment', '+$400/yr to stay on track', 'ok'),
    ]
    for label, value, severity in metrics:
        color = {'bad': '#EF4444', 'warn': '#F59E0B', 'ok': '#10B981'}.get(severity, '#718096')
        st.markdown(f"""
        <div style="display:flex;justify-content:space-between;padding:8px 12px;
             border-bottom:1px solid #E2E8F0;font-size:11.5px">
          <span style="color:#4A5568">{label}</span>
          <span style="font-weight:600;color:{color}">{value}</span>
        </div>
        """, unsafe_allow_html=True)


def _render_review_report():
    st.markdown("**Meeting Agenda**")
    agenda = [
        "Open: Acknowledge you have been actively monitoring her policy — this is a proactive call",
        "Present: Performance vs. illustration chart — be transparent about the gap",
        "Explain: Interest rate environment changes since 2017 — not a product failure",
        "Options: (1) Premium increase $400/yr (2) Fixed account reallocation (3) Policy review",
        "Close: Agree on an action plan, schedule 90-day follow-up",
    ]
    for item in agenda:
        st.markdown(f"• {item}")
    
    st.markdown("**What NOT to Say**")
    dont_say = [
        "Do not minimize the gap — she may already know",
        "Do not present more than 2 options — keep it simple",
        "Do not push a product replacement without exploring existing options first",
    ]
    for item in dont_say:
        st.markdown(f"⚠️ {item}")


def _render_post_meeting_checklist():
    actions = [
        ("📝 Transcribe call notes → CRM update", "Auto"),
        ("✉ Send leave-behind PDF within 15 min of call end", "Auto"),
        ("📋 Pre-fill WL application from existing CRM data", "Auto"),
        ("📅 Set 7-day follow-up reminder", "Auto"),
        ("📊 Update propensity scores post-outcome", "Auto"),
        ("👁 Advisor reviews CRM notes before finalization", "Review"),
    ]
    for action, tag in actions:
        tag_color = '#7B2FBE' if tag == 'Auto' else '#2563EB'
        tag_bg = '#F3EAFD' if tag == 'Auto' else '#EFF6FF'
        st.markdown(f"""
        <div style="display:flex;align-items:center;gap:7px;padding:8px 10px;
             border-radius:6px;border:1px solid #E2E8F0;margin-bottom:5px;font-size:11.5px">
          {action}
          <span style="margin-left:auto;font-size:9.5px;font-weight:600;padding:2px 6px;
               border-radius:3px;background:{tag_bg};color:{tag_color}">{tag}</span>
        </div>
        """, unsafe_allow_html=True)


def _render_email_panel(client_id: str, trigger_type: str):
    comm = run_query(f"""
        SELECT SUBJECT, BODY_CONTENT, COMM_TYPE
        FROM ADVISOR360_DB.APP.COMMUNICATIONS
        WHERE CLIENT_ID = '{client_id}' AND TRIGGER_TYPE = '{trigger_type}'
        ORDER BY CREATED_AT DESC LIMIT 1
    """)
    if comm.empty:
        st.info("No draft found. Generate via Outreach Agent.")
        return
    row = comm.iloc[0]
    st.markdown(f"**{row['COMM_TYPE']} Draft**")
    st.markdown(f"> **Subject:** {row['SUBJECT']}")
    st.markdown(row['BODY_CONTENT'].replace('\n', '  \n'))
```

---

### 6.5 utils/db.py

```python
import streamlit as st
import pandas as pd
from snowflake.snowpark.context import get_active_session

@st.cache_resource
def get_session():
    """Returns active Snowpark session (works inside Streamlit in Snowflake)."""
    return get_active_session()

def run_query(sql: str) -> pd.DataFrame:
    """Executes a SQL query and returns a Pandas DataFrame."""
    session = get_session()
    try:
        return session.sql(sql).to_pandas()
    except Exception as e:
        st.error(f"Query error: {e}")
        return pd.DataFrame()

def run_update(sql: str) -> bool:
    """Executes a DML statement (INSERT/UPDATE/DELETE)."""
    session = get_session()
    try:
        session.sql(sql).collect()
        return True
    except Exception as e:
        st.error(f"Update error: {e}")
        return False
```

### 6.6 utils/cortex.py

```python
import streamlit as st
from utils.db import run_query

def revise_email(original_draft: str, advisor_note: str) -> str:
    """Calls Snowflake Cortex to revise an email draft per advisor instruction."""
    # Escape single quotes for safe SQL embedding
    safe_draft = original_draft.replace("'", "''")
    safe_note = advisor_note.replace("'", "''")
    
    sql = f"""
    SELECT SNOWFLAKE.CORTEX.COMPLETE(
        'mistral-large2',
        ARRAY_CONSTRUCT(
            OBJECT_CONSTRUCT('role','system','content',
                'You are an insurance advisor AI. Revise the email draft per the advisor instruction. Return only the revised email, no commentary.'),
            OBJECT_CONSTRUCT('role','user','content',
                'Original draft: {safe_draft}

Advisor instruction: {safe_note}

Return the revised email only.')
        )
    ) AS REVISED
    """
    result = run_query(sql)
    if result.empty:
        return original_draft
    return result['REVISED'].iloc[0]


def generate_talking_points(client_id: str, meeting_type: str) -> list:
    """Generates 4 meeting talking points via Cortex."""
    client_data = run_query(f"""
        SELECT FIRST_NAME || ' ' || LAST_NAME AS NAME, LIFE_STAGE, SENTIMENT_SCORE
        FROM ADVISOR360_DB.APP.CLIENTS WHERE CLIENT_ID = '{client_id}'
    """)
    if client_data.empty:
        return []
    
    client_name = client_data['NAME'].iloc[0]
    life_stage = client_data['LIFE_STAGE'].iloc[0]
    
    sql = f"""
    SELECT SNOWFLAKE.CORTEX.COMPLETE(
        'mistral-large2',
        ARRAY_CONSTRUCT(
            OBJECT_CONSTRUCT('role','system','content',
                'You are a meeting prep AI for insurance advisor James Rivera. Generate exactly 4 numbered talking points for the upcoming meeting. Each must be a specific sentence the advisor can speak. Return as JSON array of strings only, no commentary.'),
            OBJECT_CONSTRUCT('role','user','content',
                'Client: {client_name}. Life stage: {life_stage}. Meeting type: {meeting_type}.')
        )
    ) AS POINTS
    """
    result = run_query(sql)
    if result.empty:
        return []
    try:
        import json
        raw = result['POINTS'].iloc[0]
        # Strip any markdown fences
        raw = raw.strip().replace('```json','').replace('```','').strip()
        return json.loads(raw)
    except Exception:
        return [result['POINTS'].iloc[0]]


def generate_portfolio_insights(advisor_id: str) -> dict:
    """Generates portfolio-level AI insights for the Analytics page."""
    kpi_data = run_query(f"""
        SELECT RETENTION_RATE, PIPELINE_VALUE, POLICIES_AT_RISK_COUNT
        FROM ADVISOR360_DB.APP.KPI_SNAPSHOTS
        WHERE ADVISOR_ID = '{advisor_id}'
        ORDER BY SNAPSHOT_DATE DESC LIMIT 1
    """)
    if kpi_data.empty:
        return {}
    
    row = kpi_data.iloc[0]
    sql = f"""
    SELECT SNOWFLAKE.CORTEX.COMPLETE(
        'mistral-large2',
        ARRAY_CONSTRUCT(
            OBJECT_CONSTRUCT('role','system','content',
                'You are an insurance portfolio analytics AI. Given KPIs, generate a 2-sentence executive summary insight. Be specific and actionable. No preamble.'),
            OBJECT_CONSTRUCT('role','user','content',
                'Retention rate: {row["RETENTION_RATE"]}%. Pipeline: ${row["PIPELINE_VALUE"]:,.0f}. At-risk policies: {row["POLICIES_AT_RISK_COUNT"]}.')
        )
    ) AS INSIGHT
    """
    result = run_query(sql)
    return {'summary': result['INSIGHT'].iloc[0] if not result.empty else ''}
```

---

## 7. REMAINING PAGE SPECS

### 7.1 pages/05_policies.py
- Query `POLICIES JOIN CLIENTS` ordered by `DAYS_TO_RENEWAL ASC`
- Display as `st.dataframe` with columns: Client, Policy Type, Premium, Coverage, Status
- Status badges via conditional formatting: `Renewing` = amber, `At Risk`/`Review` = red, `Active` = green
- Action button per row opens Agent Output Panel with `type='risk'` or `type='renewal'` based on status

### 7.2 pages/06_analytics.py
- **KPI row:** YTD Revenue, Policies Written, Avg Policy Size, Client NPS from `KPI_SNAPSHOTS`
- **Bar chart:** Use `st.bar_chart` or Altair chart on `PREMIUM_MONTHLY` table grouped by month
- **Donut chart:** Use Altair arc mark on policy type distribution from `POLICIES` table
- **Cortex insight:** Call `generate_portfolio_insights()` and display as an info card beneath KPIs

### 7.3 pages/08_agent_panel.py
- Query `AGENTS.AGENT_ACTIVITY_LOG` grouped by `AGENT_NAME, AGENT_PHASE`
- Group agents into Phase 1 / Phase 2 / Phase 3 sections using `st.expander`
- Per agent: show name, status badge (Running=green, Idle=gray, Queued=amber), and last 3 log messages
- Clicking an agent card opens the Agent Output Panel with matching `panel_type`

### 7.4 pages/09_ai_preferences.py
- Read toggles from `st.session_state.ai_preferences`
- Render four `st.toggle` controls:
  - Auto-draft outreach emails
  - Auto-update CRM after meetings
  - Require review for all outreach
  - Flag policy changes for review
- On change: update session state (optionally persist to a `USER_PREFERENCES` table)

---

## 8. DEPLOYMENT CHECKLIST

```bash
# Step 1: Create stage
CREATE STAGE ADVISOR360_DB.APP.ADVISOR360_STAGE;

# Step 2: Upload all Python files to stage
PUT file://advisor360_app/*.py @ADVISOR360_STAGE/;
PUT file://advisor360_app/pages/*.py @ADVISOR360_STAGE/pages/;
PUT file://advisor360_app/components/*.py @ADVISOR360_STAGE/components/;
PUT file://advisor360_app/utils/*.py @ADVISOR360_STAGE/utils/;

# Step 3: Create Streamlit in Snowflake app
CREATE STREAMLIT ADVISOR360_DB.APP.ADVISOR360_APP
    ROOT_LOCATION = '@ADVISOR360_DB.APP.ADVISOR360_STAGE'
    MAIN_FILE = 'streamlit_app.py'
    QUERY_WAREHOUSE = 'ADVISOR360_WH';

# Step 4: Grant access
GRANT USAGE ON STREAMLIT ADVISOR360_DB.APP.ADVISOR360_APP TO ROLE SYSADMIN;
```

---

## 9. KNOWN CONSTRAINTS & NOTES

| Constraint | Mitigation |
|---|---|
| SiS does not support `st.dialog` natively in older Streamlit versions | Implement Agent Output Panel as a conditional full-width section below main content, toggled by `session_state.panel_open` |
| Snowflake SQL uses CASE not FIELD() for ordering | Replace all `ORDER BY FIELD(col, ...)` with `ORDER BY CASE col WHEN 'High' THEN 1 ...` |
| Cortex COMPLETE may be slow for real-time calls | Cache generated content in `COMMUNICATIONS` and `AI_SCORES` tables; call Cortex in background agents, not on page load |
| DM Sans font not available in SiS | Fall back to system sans-serif; inject via `@import` in CSS if internet access available |
| Streamlit multipage apps in SiS use file-based routing | All files in `/pages/` are auto-detected as pages; prefix with numbers for sort order |
| `get_active_session()` only works inside SiS | For local dev, use `snowflake.connector` with credentials instead |

---

*Generated for Snowflake Cortex Code CLI — Advisor360 v1.0*
