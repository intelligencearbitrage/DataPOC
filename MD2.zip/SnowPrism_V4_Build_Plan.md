# SnowPrism V4 — Understanding & Build Plan

**Created:** 2026-05-29
**Author:** CoCo + Prateek
**Status:** Plan agreed. Build in progress (paused to write this doc).
**Account:** EYC23748 (DELOITTENA) · region AWS_US_EAST_1
**Build role:** SYSADMIN

---

## 1. The Goal

Produce **V4 of the SnowPrism Execution Workbook** — a fully **spoon-fed** build guide that
assumes attendees have **never used Snowflake before**. Every login step, every prompt, every
click, every "you should now see…", every fallback is written out.

The workbook serves a Snowflake Summit session:

| Audience | When | What they do |
|----------|------|-------------|
| **Instructors** | Before Summit | Use this workbook to build a full SnowPrism themselves — prove the concept end-to-end |
| **Instructor (live)** | At Summit | Build the SnowPrism DB live on stage — **R1 only** |
| **Attendees (new to Snowflake)** | At Summit | Build **R2** themselves, following dead-simple step-by-step instructions |

---

## 2. Method (agreed)

**Build → Prove → Document → Teardown.**

1. Build + prove SnowPrism **R1 + R2** live on this account, under **SYSADMIN**.
2. Build it the way attendees experience it: they **read seeded synthetic data**, NOT `SNOWFLAKE.ACCOUNT_USAGE`.
3. While building, capture **exact prompts** — both **Power Prompts** (one end-to-end block) and **incremental prompts** (one small step at a time).
4. Think like a **brand-new-to-Snowflake attendee** — log every place a newbie would trip (the "stumble log").
5. Write **`SnowPrism_Execution_Workbook_v4.xlsx`** from the proven steps.
6. **Teardown** the built objects after V4 is confirmed — **BUT KEEP the seeded synthetic data** (reusable asset).

---

## 3. Key Design Decisions

| Decision | Choice | Why |
|----------|--------|-----|
| Data source | **Seeded synthetic table** (`SNOWPRISM_DB.RAW.SAMPLE_METERING_HISTORY`) | Attendees can't read `ACCOUNT_USAGE` (ACCOUNTADMIN-only); also it's near-empty + lagging on this 3-day-old account |
| Build role | **SYSADMIN** | Proves design needs no ACCOUNTADMIN / no ACCOUNT_USAGE — exactly the attendee reality |
| Database name | **`SNOWPRISM_DB`** | Clean, account-agnostic (drops V3's hardcoded `TENANT_T_SNOWPRISM_BUILD_POC`) |
| Scope | **R1 + R2-lite** only | Fits the session; R3–R5 out of scope |
| R2 style | Semantic View + **Cortex Analyst** NL Q&A | No per-attendee Cortex Agent / Snowflake Intelligence plumbing (too much at scale) |
| Attendee R1 | **R1 pre-loaded** in each attendee's own DB via a setup script | R1 (Dynamic Tables + sync proc + task) is too much for a newbie to type live; instructor demos R1, attendees inherit it and focus on R2 (the "wow" moment) |
| Attendee isolation | Each attendee in **their own DB** | No collisions, no contention |
| File location | `...\02_Working_Decks\` | Per user instruction (overrides central scripts folder) |
| Teardown | Drop built objects, **keep seed data** | Per user instruction |

---

## 4. What Gets Built (facilitator master)

All under `SNOWPRISM_DB`, role SYSADMIN, warehouse COMPUTE_WH.

### Seed data (KEEP after teardown)
- `RAW.SAMPLE_METERING_HISTORY` — synthetic, mirrors `WAREHOUSE_METERING_HISTORY` columns.
  90 days × 8 warehouses = 720 rows, ~1423 credits. Weekend dips + 2 anomaly spikes. **[DONE]**

### R1 — Credit Visibility
- `RAW.T_TENANT` — 5 tenants (MARKETING, FINANCE, DATA_ENG, SALES, PLATFORM) + UNASSIGNED, monthly budgets. **[DONE]**
- `RAW.T_WAREHOUSE_TENANT_MAP` — explicit warehouse→tenant mapping (NOT the broken ILIKE pattern). [pending]
- `RAW.SP_SYNC_WAREHOUSE_TENANT_MAP` — MERGE distinct warehouses from **SAMPLE_METERING_HISTORY**; new = UNASSIGNED; never overwrite manual assignments. [pending]
- `RAW.TSK_SYNC_WAREHOUSE_TENANT_MAP` — daily task (optional for lab; create + leave suspended or resume). [pending]
- `ANALYTICS.DT_CREDIT_BY_WAREHOUSE` — Dynamic Table over SAMPLE_METERING_HISTORY. LAG=1h. [pending]
- `ANALYTICS.DT_CREDIT_BY_TENANT` — LEFT JOIN to map, COALESCE UNASSIGNED. LAG=downstream. [pending]
- `ANALYTICS.DT_CREDIT_DAILY_TREND` — total credits/day, full history. LAG=downstream. [pending]
- `ANALYTICS.V_CREDIT_SUMMARY` — per tenant: today/week/month credits, budget, % consumed. [pending]

### R2 — Conversational FinOps (lite)
- `ANALYTICS.SV_FINOPS` — Semantic View over the R1 outputs. [pending]
- Cortex privilege check/grant (`SNOWFLAKE.CORTEX_USER`, `CREATE SEMANTIC VIEW`) — record exact grant if needed. [pending]
- Cortex Analyst NL Q&A validation — 3 plain-English questions. [pending]

---

## 5. Proof Checkpoints

- **R1:** each Dynamic Table returns rows; `V_CREDIT_SUMMARY` shows 5 tenants with `PCT_BUDGET_CONSUMED` populated.
- **R2:** `SV_FINOPS` exists; Cortex Analyst answers 3 NL questions correctly.

---

## 6. V4 Workbook — Proposed Sheets

| # | Sheet | Spoon-fed content |
|---|-------|-------------------|
| 0 | Start Here | What you'll build; what SnowPrism is (plain English); how to read this book |
| 1 | Step 0 — Log In & Get Oriented | Browser → Snowsight → login → find worksheet → find Cortex Code |
| 2 | Step 1 — Your Sandbox | Exact `USE DATABASE/WAREHOUSE/ROLE`; "if error X do Y" |
| 3 | Step 2 — Load Sample Data | One copy-paste block; verify row count |
| 4 | R1 — Credit Visibility | Micro-steps; each object: exact prompt/SQL + confirmation |
| 5 | R1 Checkpoint | "You should see 5 tenants" ✅/❌ → fix |
| 6 | R2 — Ask Questions in English | Build Semantic View (copy-paste) + exact NL questions + expected answers |
| 7 | R2 Checkpoint | Success criteria + screenshot of a working answer |
| 8 | If Something Breaks | Top 10 newcomer errors + plain fixes (from stumble log) |
| 9 | Instructor Notes | Pre-Summit prep, live R1 cues, timing — separate from attendee flow |
| 10 | Reference | Synthetic data spec, context.yaml, glossary (credit/warehouse/tenant in plain words) |

Plus the supporting scripts (saved to `02_Working_Decks\`):
- **Live-R1 script** — instructor runs on stage.
- **Per-attendee R1 setup/seed script** — pre-provisions each sandbox with working R1 + seed data.
- **Attendee R2 track** — embedded in the workbook.

---

## 7. Open Risks (tracked during build)

| Risk | Status |
|------|--------|
| Cortex Analyst / Semantic View privileges under SYSADMIN | To test in Phase 3; record exact grant if needed |
| Dynamic Table empty right after create (refresh lag) | Capture wait/refresh step + expected counts |
| Smart-quote paste errors for newcomers | Add to stumble log / troubleshooting |
| 75 attendees on shared COMPUTE_WH | Out of scope for master; note in Instructor Notes |

---

## 8. Current Build State (PROVEN — full R1+R2 validated)

- ✅ `SNOWPRISM_DB` + schemas (RAW, STAGING, ANALYTICS, GOVERNANCE) created under SYSADMIN.
- ✅ `RAW.SAMPLE_METERING_HISTORY` seeded — 720 rows, 8 warehouses, 90 days, ~1423 credits.
- ✅ `RAW.T_TENANT` — 6 rows (5 tenants + UNASSIGNED).
- ✅ `RAW.T_WAREHOUSE_TENANT_MAP` + `SP_SYNC_WAREHOUSE_TENANT_MAP` — 8 warehouses synced, 7 assigned, 1 left UNASSIGNED (proves COALESCE path).
- ✅ `ANALYTICS.DT_CREDIT_BY_WAREHOUSE` (720 rows, INCREMENTAL), `DT_CREDIT_BY_TENANT` (720 rows, FULL), `DT_CREDIT_DAILY_TREND` (90 rows, INCREMENTAL).
- ✅ `ANALYTICS.V_CREDIT_SUMMARY` — 6 rows, % budget populated. DATA_ENG at 91.7% (great demo signal).
- ✅ `ANALYTICS.SV_FINOPS` semantic view — created under SYSADMIN, NO special grant needed.
- ✅ Cortex Analyst answered 3/3 NL questions correctly (most-spend, daily trend, tenant drill-down).

### R1 result snapshot (this-month % budget)
| Tenant | Month credits | Budget | % |
|--------|--------------|--------|---|
| DATA_ENG | 201.7 | 220 | 91.7 |
| MARKETING | 105.5 | 120 | 87.9 |
| FINANCE | 53.8 | 80 | 67.2 |
| SALES | 43.4 | 70 | 62.0 |
| PLATFORM | 58.1 | 100 | 58.1 |
| UNASSIGNED | 17.9 | 0 | NULL |

---

## 8a. Newbie Stumble Log (captured during build)

| # | What trips a newcomer | Spoon-fed fix for V4 |
|---|----------------------|----------------------|
| 1 | No context set → "object does not exist" / "no active warehouse" | Always start with `USE ROLE` / `USE WAREHOUSE` / `USE DATABASE` / `USE SCHEMA` block |
| 2 | Reserved word as alias (e.g. `AS ROWS`) → syntax error | Use safe alias names (`ROW_CNT`) |
| 3 | Semantic view query isn't a plain SELECT | Use `SELECT * FROM SEMANTIC_VIEW( ... DIMENSIONS ... METRICS ... )` |
| 4 | Semantic view needs `PRIMARY KEY` declared on each table | Provide it in the copy-paste DDL |
| 5 | Dynamic Table looks empty for a moment after create | We use `initialize=ON_CREATE` (default) — populates immediately; tell them to re-run the SELECT if 0 rows |
| 6 | Smart/curly quotes from copy-paste break SQL | Warn: paste as plain text; provide a code-formatted block |
| 7 | Complex-join DT auto-switches to FULL refresh (info message) | Reassure: this is expected, not an error |
| 8 | Cortex Analyst needs a semantic view, not a raw table | R2 builds SV_FINOPS first, then asks questions |

### Privilege finding
- Under **SYSADMIN** (owner of the schema), **no extra grant** was needed to create the Semantic View or run Cortex Analyst against it. If an attendee role is NOT the owner, they may need `SNOWFLAKE.CORTEX_USER` database role — document as an instructor pre-check.

---

## 8b. Validated Cortex Analyst questions (R2 proof)
1. "Which tenant spent the most credits in total?" → DATA_ENG ✅
2. "Show me the daily credit trend for the last 30 days" → daily series ✅
3. "Break down credit usage for the DATA_ENG tenant by warehouse" → TRANSFORM 392.6, INGEST 178.3 ✅

---

## 9. Refinement Log

| Date | Change | Who |
|------|--------|-----|
| 2026-05-29 | Initial understanding + plan captured before continuing build | CoCo + Prateek |
