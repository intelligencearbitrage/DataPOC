# Full Intercompany Reconciliation Prototype — Specification

**Project:** Full Intercompany Reconciliation Prototype (beyond MIS)
**Purpose:** Art-of-the-possible demonstration of AI-powered reconciliation across all segments, entities, currencies, and ERPs
**Status:** Specification — to be built as a sibling prototype to the MIS production system
**Date:** 2026-05-18

---

## 1. Why This Prototype Exists

The current `INTERCO_RECON` system (documented in `Evident_Intercompany_Reconciliation.md`) was tactically descoped to MIS-only during the SOW. That delivery is correct, complete, and passes UAT — but the MIS scope produces few hard cases, leaving Phase 3 (Cortex fuzzy matching) and Phase 4 (LLM classification + journal proposal) underexercised. The expensive part of the architecture has never run at meaningful volume.

This second prototype exists to fill that gap. It targets the **full intercompany reconciliation surface** — MIS + TNM + cross-segment pairs across 18 entities, 35+ bilateral pairs, 11 currencies, and 3 ERPs (SAP, NetSuite, Visual) — and uses real Mar'26 / Feb'26 data so the AI components fire on cases that demonstrate the platform's actual capability.

### 1.1 What this prototype is NOT

- Not a replacement for the MIS production system. The MIS system is the delivery artifact. This is the sales artifact.
- Not a parallel re-implementation. Same architecture, different scope and demo discipline.
- Not a path to production for the broader scope. Production for the broader scope is a separate engagement scoped after this demo lands.

### 1.2 The thesis this prototype must prove

A single sentence the audience should be able to recite after the demo:

> "AI can perform intercompany reconciliation end-to-end — invoice matching, fuzzy resolution, root cause classification, and journal entry proposal — at full enterprise scope, producing output that controllers actually trust and post."

If the prototype doesn't produce that sentence in the audience's head, it has failed regardless of how impressive the code is.

### 1.3 What this prototype must demonstrate (not just "support")

1. Real Mar'26 and Feb'26 data flowing end-to-end
2. Phase 2 producing >1,000 deterministic matches across all pairs (vs the MIS system's 167)
3. Phase 3 producing >20 fuzzy matches with reviewer-visible reasoning
4. Phase 4 producing journal entries that match the `Entry Summary` tab's actual output (controllers can compare side-by-side)
5. Trend comparison: Feb'26 vs Mar'26 close, showing month-over-month variance evolution
6. Multi-ERP visibility: lines clearly labeled as SAP, NetSuite, or Visual sourced
7. A controller-facing review interface that's fast enough to use in front of an audience

---

## 2. Scope — Full Enterprise Reconciliation

### 2.1 Entities (18) — vs MIS prototype's 9

From `List of intercompany` tab in the Mar'26 workbook:

| ICP Code | Entity | Region | Book Currency | TNM Participates | MIS Participates | ERP |
|----------|--------|--------|---------------|------------------|------------------|-----|
| 1096 | EJP | APAC | JPY | Y | Y | SAP |
| 1097 | ENF | APAC | JPY | Y | Y | SAP |
| 4048 | ETCE | EMEA | EUR | N | Y | SAP |
| 4001 | EEU | EMEA | EUR | Y | Y | SAP |
| 4121 | ESCE | EMEA | CZK | Y | Y | SAP |
| 2017 | ECND | AMER | CAD | Y | N | NetSuite |
| 2018 | EUSA | AMER | USD | Y | N | NetSuite |
| 2017A | MIS-CND | AMER | CAD | N | Y | SAP |
| 2018A | MIS-USA | AMER | USD | N | Y | SAP |
| 5044 | ESG | APAC | SGD | Y | Y | SAP |
| 5045 | EKR | APAC | KRW | Y | Y | SAP |
| 5046 | EIND | APAC | INR | Y | Y | SAP |
| 6009 | EAS | APAC | AUD | Y | Y | SAP |
| 5043 | ECN | APAC | CNY | Y | Y | SAP |
| 5020 | EGZ | APAC | CNY | N | Y | SAP |
| 2017P | PCND | AMER | CAD | N | Y | NetSuite (Pramana) |
| 2018P | PUSA | AMER | USD | N | Y | NetSuite (Pramana) |
| 5030P | SPIND | APAC | INR | N | Y | NetSuite (Pramana) |
| 2062A | EMEX | AMER | MXN | N | Y | SAP/Visual |

### 2.2 Pairs — 35+ active vs MIS prototype's 17

Pairs are derived dynamically from the Compilation tab's `Pivot ICP` column. The Mar'26 close shows 35 distinct pairs across MIS, TNM, and combined (TNM&MIS) views. The Feb'26 close adds 4 more (TNM-EUSAvsESG, TNM-ECNvsECND, TNM-ECNDvsEEU, MIS-EJPvsMISUSA), suggesting the active pair set drifts month-to-month.

**Implication:** `REF.REF_BILATERAL_PAIRS` should not be hardcoded at 17 rows. It must be repopulated from the Compilation tab during ingestion. Pairs that appear in one period may not appear the next, and vice versa.

### 2.3 Currencies (11+) and Forex Normalization

From the `Forex` tab — rates are provided per period as Average Rate (for P&L) and Closing Rate (for Balance Sheet):

```
AUD, CAD, CHF, CNY, CZK, DKK, EUR, GBP, INR, JPY (reporting),
KRW, MXN, NZD, PLN, SGD, USD
```

JPY is the reporting currency. All amounts get a `JPY_AMOUNT` computed via `ClosingRate` (for BS items) or `AverageRate` (for P&L items) from the period's Forex tab.

**Implication:** `STAGING.FOREX_RATES` must distinguish AVERAGE vs CLOSING and store rates per period. The MIS prototype's `REF.FX_RATES` (16 rows, single rate type) needs to evolve to ~32 rows (16 currencies × 2 rate types) per period.

### 2.4 Nature Categories (6)

From the `Lookup` tab:

| Nature | Description | Matching Approach |
|--------|-------------|-------------------|
| Trade-EDI | Both sides exchange via EDI; automated invoice flow | Phase 2 deterministic; expected >95% perfect match |
| Trade-non EDI | Trade transactions without EDI; manual posting | Phase 2 deterministic; expected 70-85% perfect match |
| Non-trade | Service charges, rebates, expense allocations | Phase 2 amount-driven (no invoice key); Phase 3 fuzzy likely |
| TP adjustment | Transfer pricing adjustments | Phase 4 always — rule-based identification, AI proposes JE |
| Loan (ICL) | Intercompany loans | Phase 2 amount + GL account; Phase 4 for amortization issues |
| Accrued interest | Interest accruals on intercompany loans | Phase 2 amount-driven; Phase 4 for periodicity issues |

**Implication:** The MIS prototype's binary Trade/Non-Trade matching procedures (`SP_RUN_PHASE2_TRADE` / `SP_RUN_PHASE2_NONTRADE`) need to expand to nature-aware logic. A single `SP_RUN_PHASE2(P_PERIOD, P_PAIR_ID, P_NATURE)` parameterized procedure replaces both.

### 2.5 Multi-ERP Support

The Mar'26 workbook reveals 3 different ERP source systems:

| ERP | Used By | Account Format | Document Number Format | Notes |
|-----|---------|----------------|------------------------|-------|
| SAP | EJP, ENF, ETCE, EEU, ESCE, ESG, EKR, EIND, EAS, ECN, EGZ, MIS-CND, MIS-USA, EMEX | Numeric (e.g., "2610300", "1122100100") | Numeric (e.g., "00715005") | FBL3N, FBL1N, FBL5N exports |
| NetSuite | EUSA, ECND, PCND, PUSA, SPIND | Numeric short (e.g., "12290", "21181", "707200") | Alphanumeric (e.g., "DEB-0125400010") | Different P&L vs BS account ranges |
| Visual | EMEX (partial) | TBD | TBD | Legacy, low volume |

**Implication:** The `IC_LINES` schema needs an `ERP_SOURCE` column (`SAP`/`NETSUITE`/`VISUAL`) and `STAGING.IC_LINES` should not assume a single account-numbering convention. Match keys differ by ERP.

### 2.6 Segment Handling

| Pair Type | Source Tab Naming | Volume (Mar'26) |
|-----------|-------------------|-----------------|
| MIS-only | `MIS - X vs Y` | 7 tabs |
| TNM-only | `TNM-X vs Y` | 5 tabs |
| Combined (TNM+MIS) | `TNM&MIS-X vs Y` | 4 tabs |
| Aggregate views | `MISvsMIS`, `TNMvsTNM` | 2 tabs |

The combined `TNM&MIS-` pairs are critical — they're pairs where transactions exist in both segments simultaneously (e.g., EJP vs EUSA-MIS-USA where the same counterparty has both MIS and TNM activity). The reconciliation logic must produce per-segment subtotals and a combined total per pair.

---

## 3. Source Data — What Feeds the Prototype

The prototype ingests directly from the two reconciliation workbooks:

- `Interco_reconciliation_Mar_26__sent_14Apr_.xlsx` (current period)
- `Interco_reconciliation_Feb_26__sent_12Mar_.xlsx` (prior period, for trend)

Plus the bilateral entity files (`mar26_files.zip`) for invoice-level detail where the reconciliation workbook only has GL-level data.

### 3.1 Workbook → System Mapping

| Workbook Tab | Rows | Maps to System Object | Purpose |
|--------------|------|----------------------|---------|
| `Lookup` | 23 | `REF.REF_NATURE_TAXONOMY`, `REF.REF_BUSINESS_UNITS`, `REF.REF_CURRENCIES` | Validation lookups |
| `List of intercompany` | 23 | `REF.REF_ENTITIES` | Entity master with segment participation flags |
| `Forex` | 21 | `REF.REF_FOREX_RATES` (period-specific) | Average + Closing rates per currency |
| `Status` | 18 | `STAGING.ENTITY_SUBMISSION_STATUS` | Tracks who submitted what, when |
| `Compilation` | 974 (331 actual) | `STAGING.GL_BALANCES` | Master GL balance ledger (all segments, all pairs) |
| `Compilation Oct'25` | 255 | `REGRESSION.HISTORICAL_BASELINE` | Historical reference (Oct '25 close) |
| `Entry Summary` | 76 | `REGRESSION.MANUAL_ENTRY_SUMMARY` | Ground truth for Phase 4 AI output |
| `MISvsMIS`, `TNMvsTNM` | 44, 33 | `RESULTS.V_AGGREGATE_VARIANCE` | Pair-level variance summary (pre-aggregated by humans) |
| `Pivot doc currency` | 90 (Feb'26 only) | `RESULTS.V_CURRENCY_PIVOT` | Cross-currency variance by pair/segment |
| `Balance sheet` | 183 (Feb'26 only) | `STAGING.ENTITY_BS_SUBMISSION` | Per-entity GL balance template (one per entity per period) |
| Per-pair tabs (`MIS - *`, `TNM - *`, `TNM&MIS - *`) | varies | `REGRESSION.PAIR_RECONCILIATION_DETAIL` | Manual pair-level reconciliation with journal proposals |

### 3.2 The Compilation Tab — The Foundation

`Compilation` is the GL-level master ledger. Each row is one (entity, ICP, GL account, currency, segment, nature, class) combination. Schema:

| Col | Field | Notes |
|-----|-------|-------|
| 1 | SAP GL account | Account number in source ERP (despite the name, includes NetSuite accounts) |
| 2 | SAP Account Description | Account name |
| 3 | ICP Code | Counterparty SAP code |
| 4 | ICP Name | Counterparty short name |
| 5 | Nature | One of 6 nature categories |
| 6 | Business unit | MIS or TNM |
| 7 | Class | Asset or Liabilities (BS classification; no PL rows in this view) |
| 8 | Doc Curr | Document currency (ISO) |
| 9 | Doc Curr Amount | Amount in document currency |
| 10 | LC Amount | Amount in local (book) currency |
| 11 | Entity code | Booking entity SAP code |
| 12 | Entity | Booking entity short name |
| 13 | Local Currency | Booking entity's functional currency |
| 14 | Rate | FX rate to JPY (closing) |
| 15 | JPY amount | LC amount × rate |
| 16 | USD amount | JPY amount / USD rate |
| 17 | Pivot ICP | Formatted pair name (e.g., "EJP vs EIND") |

The Mar'26 Compilation has 331 actual data rows (the other 643 are pivots/totals/blanks). Volume scales to ~500-700 rows per period for full enterprise scope.

### 3.3 Bilateral Files — Invoice-Level Detail

Invoice-level data (needed for Phase 2 deterministic matching) is NOT in the reconciliation workbook. It's in the 53 bilateral entity files (extracted in prior work to `IC_LINES_unified.csv` — 7,234 rows). These supply the `STAGING.IC_LINES` table.

---

## 4. Architecture — Deltas from the MIS Prototype

### 4.1 Database Layout

Reuse the same schemas, but in a separate database: `INTERCO_RECON_FULL` (parallel to `INTERCO_RECON`). This prevents demo prototype from contaminating delivery prototype.

```
INTERCO_RECON_FULL (Database)
├── PUBLIC          — App, orchestration, validation
├── RAW             — Excel/CSV ingestion (file registry, cells, tabs)
├── REF             — Master data (entities, pairs, nature taxonomy, forex)  ★ extended
├── STAGING         — Cleaned data (IC_LINES, GL_BALANCES, submission_status)  ★ extended
├── RESULTS         — Phase outputs (same 4 phases, broader content)
├── HITL            — Approval queues (same)
├── TRAINING        — Few-shot examples (★ enriched from Entry Summary)
└── REGRESSION      — Manual ground truth (★ enriched with Entry Summary, MISvsMIS, TNMvsTNM)
```

### 4.2 New Schemas / Extended Tables

#### `REF.REF_ENTITIES` (extended)

| Column | Type | New | Notes |
|--------|------|-----|-------|
| ENTITY_SAP_CODE | VARCHAR(10) PK | | |
| ENTITY_CODE | VARCHAR(10) UNIQUE | | |
| ENTITY_FULL_NAME | VARCHAR(200) | | |
| REGION | VARCHAR(20) | | APAC / EMEA / AMER |
| BOOK_CURRENCY | VARCHAR(3) | | Local functional currency |
| **TNM_ACTIVE** | BOOLEAN | ★ | From List of intercompany |
| **MIS_ACTIVE** | BOOLEAN | ★ | From List of intercompany |
| **ERP_SOURCE** | VARCHAR(20) | ★ | SAP / NETSUITE / VISUAL |
| **PRAMANA_FLAG** | BOOLEAN | ★ | True for PCND, PUSA, SPIND |
| **PIC_NAME** | VARCHAR(100) | ★ | From Status tab |

#### `REF.REF_NATURE_TAXONOMY` (new)

| Column | Type | Notes |
|--------|------|-------|
| NATURE_CODE | VARCHAR(50) PK | "Trade-EDI", "Trade- non EDI", "Non-trade", "TP adjustment", "Loan (ICL)", "Accrued interest" |
| MATCHING_APPROACH | VARCHAR(50) | DETERMINISTIC_INVOICE / AMOUNT_DRIVEN / RULE_BASED |
| EXPECTED_MATCH_RATE | NUMBER(5,4) | Target hit rate (0.95, 0.80, 0.60, etc.) |
| PHASE2_CONFIDENCE_FORMULA | VARCHAR(500) | Which weights apply |
| PHASE4_TRIGGER | BOOLEAN | True if AI classification always runs (TP adjustment) |

#### `REF.REF_FOREX_RATES` (extended)

| Column | Type | Notes |
|--------|------|-------|
| PERIOD | DATE | Period end |
| CURRENCY_CODE | VARCHAR(3) | |
| RATE_TYPE | VARCHAR(10) | AVERAGE / CLOSING |
| RATE_TO_JPY | NUMBER(15,8) | |
| SOURCE | VARCHAR(50) | "Mar'26 Forex tab" |

#### `STAGING.IC_LINES` (extended)

Add columns:
- `ERP_SOURCE` VARCHAR(20) — SAP / NETSUITE / VISUAL
- `NATURE` VARCHAR(50) — denormalized from REF_NATURE_TAXONOMY
- `SEGMENT_TYPE` VARCHAR(10) — MIS / TNM (replacing or supplementing the existing SEGMENT)
- `IS_TP_ADJUSTMENT` BOOLEAN — True for transfer pricing lines
- `IS_LOAN_OR_INTEREST` BOOLEAN — True for loan / interest accrual lines

#### `STAGING.GL_BALANCES` (extended)

The MIS prototype has 207 rows here. The full prototype's GL_BALANCES is populated directly from the `Compilation` tab and will have ~331 rows for Mar'26, ~400+ for Feb'26 (where TNM-ECN-ECND and additional pairs were active).

Add columns:
- `NATURE` VARCHAR(50)
- `CLASS_BS_OR_PL` VARCHAR(2) — derived from CLASS (Asset/Liabilities → BS; future PL support)
- `ASSET_OR_LIAB` VARCHAR(10)
- `PIVOT_ICP` VARCHAR(50) — direct from Compilation
- `SOURCE_ROW` NUMBER — for traceability back to Compilation row

#### `STAGING.ENTITY_SUBMISSION_STATUS` (new)

Direct mapping from the Status tab:

| Column | Type | Notes |
|--------|------|-------|
| PERIOD | DATE | |
| ENTITY_CODE | VARCHAR(10) | |
| PIC | VARCHAR(100) | Person in charge |
| STATUS | VARCHAR(20) | Submitted / Pending / Late |
| ADDED_TO_COMPILATION | BOOLEAN | Y/N from Status tab |
| REMARKS | VARCHAR(500) | |
| SUBMITTED_AT | TIMESTAMP | |

This is critical for the demo: the dashboard can show "16 of 18 entities submitted" at the top.

#### `REGRESSION.MANUAL_ENTRY_SUMMARY` (new)

Direct mapping from the `Entry Summary` tab. Each row is one journal line of one proposed entry, grouped by pair section.

| Column | Type | Notes |
|--------|------|-------|
| PERIOD | DATE | |
| PAIR_SECTION | VARCHAR(100) | e.g., "MIS-EJPvsETCE" |
| LINE_NUMBER | NUMBER | Position within section |
| SAP_CODE | VARCHAR(50) | |
| SAP_DESCRIPTION | VARCHAR(200) | |
| HFM_CODE | VARCHAR(50) | OneStream consolidation code (often blank) |
| HFM_DESCRIPTION | VARCHAR(200) | |
| LC | VARCHAR(3) | Local currency |
| LC_AMOUNT | NUMBER(20,2) | Signed |
| JPY_AMOUNT | NUMBER(20,2) | |
| ENTITY | VARCHAR(20) | |
| ICP_NAME | VARCHAR(50) | |
| ICP_CODE | VARCHAR(20) | |
| SEGMENT | VARCHAR(10) | MIS / TNM |
| REMARK | VARCHAR(500) | The natural-language root cause description |
| CLASS_TAG | VARCHAR(50) | "BS ICP TNM" / "BS ICP MIS" — used for balance check |

This becomes the **gold standard** for Phase 4 AI output. The demo's most powerful moment is side-by-side comparison: manual `Entry Summary` line vs AI-proposed `PHASE4_AI_CLASSIFICATIONS` row.

#### `REGRESSION.MANUAL_PAIR_RECONCILIATION` (new)

Maps each per-pair tab (`MIS - EJP vs ETCE`, `TNM-EUSAvsEEU`, etc.) to structured rows. Contains:
- Pair header info
- Journal Adjustment table (the proposed JE for that pair)
- Variance Detail table (the GL lines)
- Pair-specific reconciliation logic (TP comparison, NetSuite vs SAP differences, etc.)

This is what `V_PAIR_RECONCILIATION` in the MIS prototype produces as output. Here it's stored as **input regression target** — the AI's pair view must match this structure.

---

## 5. Pipeline Phases — Full-Scope Logic

The same 4-phase pipeline as MIS, but with nature-aware logic and broader content.

### 5.1 Phase 1 — GL Balance Check (extended)

**Input:** `STAGING.GL_BALANCES` (loaded from Compilation tab)
**Output:** `RESULTS.PHASE1_BALANCE_RECON`

For each `(PERIOD, PAIR_ID, OS_ACCOUNT, DOC_CURRENCY, SEGMENT, NATURE)` combination:

```sql
SELECT
  PERIOD, PAIR_ID, OS_ACCOUNT, DOC_CURRENCY, SEGMENT, NATURE,
  SUM(CASE WHEN ENTITY_CODE = side_a THEN LC_AMOUNT ELSE 0 END) AS SIDE_A_BALANCE,
  SUM(CASE WHEN ENTITY_CODE = side_b THEN LC_AMOUNT ELSE 0 END) AS SIDE_B_BALANCE,
  SUM(JPY_AMOUNT) AS COMBINED_JPY,
  CASE
    WHEN ABS(COMBINED_JPY) < 1 THEN 'GL_BALANCED'
    WHEN ABS(COMBINED_JPY) / GREATEST(ABS(SIDE_A_BALANCE), ABS(SIDE_B_BALANCE), 1) < 0.001 THEN 'GL_NEAR_BALANCED'
    ELSE 'GL_VARIANCE'
  END AS RECON_STATUS
FROM STAGING.GL_BALANCES
WHERE PERIOD = :p_period
GROUP BY 1,2,3,4,5,6
```

**New behavior vs MIS prototype:**
- Pivots by NATURE in addition to OS_ACCOUNT — a pair can be balanced for Trade and variant for Non-trade simultaneously
- Aggregates by SEGMENT to produce per-pair MIS and TNM subtotals (for `MISvsMIS` and `TNMvsTNM` views)

### 5.2 Phase 2 — Deterministic Matching (nature-aware)

**Single procedure:** `SP_RUN_PHASE2(P_PERIOD, P_PAIR_ID, P_NATURE)` — dispatches to the right matching logic based on nature.

**Nature → Matching strategy:**

| Nature | Strategy | Expected match rate |
|--------|----------|---------------------|
| Trade-EDI | Strict invoice-number + amount + currency match (95%+ confidence threshold) | >95% |
| Trade-non EDI | Invoice-number-based but tolerant of leading-zero / format variations | 75-85% |
| Non-trade | Amount + GL account + posting month (no invoice key) | 50-65% |
| Loan (ICL) | Principal amount + GL account + entity-pair only (single ongoing balance) | 90%+ |
| Accrued interest | Posting month + GL account; amount within tolerance | 70-80% |
| TP adjustment | **Never matched in Phase 2** — always routed to Phase 4 | n/a |

**Confidence formula** stays the same (ICP 30 / Invoice 20 / Currency 20 / Amount 20 / DocDate 5 / PostMonth 5) but with one change:

For Non-trade and Loan, **invoice match weight (20%) is reallocated to amount match** (becomes 40%), since no invoice number exists for these natures.

### 5.3 Phase 3 — Cortex Fuzzy Matching (broader application)

**Same logic as MIS prototype**, but operates on a larger pool. With ~7,000+ unmatched lines across all pairs/natures, Phase 3 has materially more work and the demo can show fuzzy matching catching cases like:
- Non-trade service fees where the description text aligns but amounts differ slightly (forex)
- Loan interest accruals with same GL account but different posting cadence
- Trade-non EDI where the invoice number was typed differently on each side

**Demo target:** Phase 3 produces >20 fuzzy matches with cosine similarity >0.85 and AI confidence >0.80.

### 5.4 Phase 4 — AI Classification + Journal Entry Proposal (the centerpiece)

This is the demo's most important phase. **Every GL_VARIANCE pair × OS_ACCOUNT × nature combination** with residual unmatched lines is sent to Phase 4.

**Key extension: Nature-specific prompts**

Phase 4 in the MIS prototype uses one prompt template. The full prototype dispatches to one of six nature-specific templates:

| Nature | Prompt focus | Expected output |
|--------|--------------|-----------------|
| Trade-EDI variance | "These should match — investigate posting error, currency, or timing" | DATA_ENTRY_ERROR or TIMING_DIFFERENCE classification |
| Trade-non EDI variance | "Manual posting mismatch — likely typo, reclass, or missing entry" | RECLASSIFICATION or MISSING_BOOKING |
| Non-trade variance | "Service charge or expense allocation — check rate, periodicity, recipient" | FOREX_DIFFERENCE or TIMING_DIFFERENCE |
| TP adjustment | "Transfer pricing — propose elimination journal to clear" | TP_ELIMINATION (new category) with specific JE |
| Loan (ICL) | "Loan balance variance — check principal vs interest split" | RECLASSIFICATION (P/I split) |
| Accrued interest | "Interest accrual variance — check rate, period, or amount" | FOREX_DIFFERENCE or TIMING_DIFFERENCE |

**New root cause category:** `TP_ELIMINATION` — for Transfer Pricing adjustments that need elimination journal entries.

**Few-shot prompt construction** uses `REGRESSION.MANUAL_ENTRY_SUMMARY` directly. For each (pair, nature, root_cause_category) combination, the prompt includes 2-3 historical examples from prior months with the actual Remark text as the reasoning baseline.

**LLM Output JSON schema** (extended from MIS):

```json
{
  "root_cause_category": "MISSING_BOOKING|FOREX_DIFFERENCE|TIMING_DIFFERENCE|RECLASSIFICATION|DATA_ENTRY_ERROR|TP_ELIMINATION|OTHER",
  "confidence": 0.0,
  "reasoning": "...",
  "suggested_action": "PROPOSE_JE|INVESTIGATE|IGNORE|ESCALATE",
  "proposed_journal": {
    "booking_entity": "...",
    "icp_code": "...",
    "icp_name": "...",
    "segment": "MIS|TNM",
    "lines": [
      { "dr_or_cr": "DR", "sap_account": "...", "hfm_code": "...", "description": "...", "lc_amount": 0, "jpy_amount": 0, "currency": "...", "class_tag": "BS ICP MIS|BS ICP TNM" }
    ],
    "narrative": "..."
  },
  "matches_manual_entry_summary": true,
  "manual_entry_reference": "MIS-EJPvsETCE row 16-17"
}
```

Two new fields critical for demo:
- `matches_manual_entry_summary` — boolean, true if the AI's output structurally matches what a controller would post
- `manual_entry_reference` — pointer to the `Entry Summary` row this corresponds to (for live side-by-side comparison)

---

## 6. The Demo Path

The single most important section. The prototype is built around this 12-minute walkthrough.

### 6.1 Audience and moment

- **Primary:** Evident senior finance leadership (CFO, Controller, Finance Transformation lead) at a steering meeting
- **Secondary:** Anthropic prospects in adjacent industries (manufacturing, multi-entity multinationals)
- **Constraint:** Live demo, no recordings, no slides during the demo itself

### 6.2 The script (12 minutes)

**0:00 — Open with the problem (1 min)**
Show the Mar'26 reconciliation workbook in Excel. Scroll through 25 tabs. Land on Entry Summary. "76 manually-prepared journal entries across 35 entity pairs. This is one month."

**1:00 — Show the system overview (1 min)**
Navigate to Dashboard page. Tiles show: 18 entities (16 submitted, 2 pending — from Status tab), 35 pairs, 7,234 IC lines, ¥3.6B in MIS variance, ¥3.3B in TNM variance, 167 Phase 2 matches → expand to "1,847 across full scope."

**2:00 — Drill into one pair, hero story (2 min)**
Click EJP-ECN. Show GL balance: USD perfectly balanced, CNY shows ¥46M variance. Show Phase 2: 428 invoices matched, 2 EJP orphans, 72 ECN orphans. Highlight one PERFECT match in the UI. "This was 2 hours of Excel work last month. The system did it in 3 seconds."

**4:00 — Phase 3 in action (2 min)**
Click a TNM pair with fuzzy matches. Show vector embeddings catching a forex-affected match where amounts differ by 0.4%. AI confidence 0.87. Approve it with one click.

**6:00 — Phase 4 centerpiece (3 min)**
Click EEU-SPIND. Show $99,550 variance. Click "Run AI Classification." Cortex Claude classifies as MISSING_BOOKING, confidence 0.94, and proposes a journal entry:
```
DR  Man Inv Adj Merch   USD 99,550
CR  Trade A/P OG        USD 99,550
```
Open the manual Entry Summary tab in Excel side-by-side. Same entry. Same accounts. Same amounts. Same narrative ("invoice not taken from SPIND"). Approve in the UI.

**9:00 — Multi-period trend (1 min)**
Switch to Feb'26 period. Show how the same pair (EEU-SPIND) had a similar variance pattern, classified the same way, and was resolved. "The AI is learning your patterns. By June, it will propose the journal before the controller asks."

**10:00 — Cross-segment view (1 min)**
Show MISvsMIS aggregate page, then TNMvsTNM, then combined dashboard. ¥7B total variance across both segments, of which ¥6.5B is adjusted, leaving ¥500M residual — all routed to Phase 4 with proposed JEs.

**11:00 — Close (1 min)**
"This is one month of intercompany reconciliation, performed by AI, reviewed by the same controllers who do it manually today. The numbers match, the journals match, and the time-to-close is hours not days. The MIS system you've already deployed is the foundation. This is what it looks like extended to enterprise scope."

### 6.3 Hidden constraints (the demo prototype must respect)

- **All pre-canned.** No live pipeline runs in front of the audience. The "Run AI Classification" button reads from `PHASE4_AI_CLASSIFICATIONS` where the row was inserted offline. The button click reveals the row with a loading animation.
- **Fast switching.** Period dropdown must change all pages in <500ms. Pre-aggregate everything into materialized views.
- **No errors visible.** If a tab fails, show a placeholder. Never show stack traces or "0 rows."
- **Hero pairs are pre-selected.** Demo path always uses EJP-ECN, EEU-SPIND, EJP-ETCE. These are validated end-to-end. Other pairs can exist but the demo never clicks into them.

---

## 7. New Streamlit Pages (in addition to MIS prototype's 8)

| # | Page | New | Description |
|---|------|-----|-------------|
| 0 | Dashboard | ★ extended | Cross-segment KPIs, entity submission status, demo-path quick links |
| 1 | GL Level Matching | ★ extended | MIS + TNM + Combined views; nature filter |
| 2 | Invoice Level Matching | ★ extended | Multi-ERP visibility (SAP/NetSuite/Visual badges) |
| 3 | Review Queue | (same) | |
| 4 | Fuzzy Approval Queue | (same) | |
| 5 | Classification Approval Queue | ★ extended | **Side-by-side comparison with manual Entry Summary** |
| 6 | Entry Summary | ★ extended | Multi-segment, multi-pair; export matches workbook's Entry Summary tab |
| 7 | Pair Reconciliation | ★ extended | Per-pair tab view; supports TNM, MIS, TNM&MIS combined |
| **8** | **Aggregate Variance** | ★ NEW | MISvsMIS + TNMvsTNM combined view |
| **9** | **Currency Pivot** | ★ NEW | Pivot doc currency view (cross-pair by currency) |
| **10** | **Entity Submission** | ★ NEW | Status tab equivalent; who submitted what |
| **11** | **Period Comparison** | ★ NEW | Feb'26 vs Mar'26 trend, variance evolution |
| **12** | **Demo Walkthrough** | ★ NEW | Internal page; lists the 12-min demo flow with quick-jump links |

### 7.1 Critical new page: Classification Approval Queue with side-by-side

The single most important UI feature. When a reviewer opens a Phase 4 classification:
- Left pane: AI-proposed journal (formatted exactly like Entry Summary)
- Right pane: The manual Entry Summary row (from `REGRESSION.MANUAL_ENTRY_SUMMARY`) for the same pair
- Visual diff: green for matching fields, yellow for fields the AI got close on, red for misses
- One-click approve/edit/reject

This is what makes the demo land. Showing AI output in isolation is unimpressive. Showing AI output matching what controllers would have written, with diff highlighting, is the wow moment.

---

## 8. Validation Gates — Full Coverage

The MIS prototype implements 4 of 14 gates. The full prototype must implement all 14 plus 6 new ones:

| Gate | Validation | Status |
|------|-----------|--------|
| G1 | GL accounts loaded ≥ 180 in `REF_ENTITY_GL_ACCOUNTS` | Existing |
| G2 | Each of the 18 entities has at least one row in IC_LINES | Existing |
| G3 | Each pair has at least one Phase 1 row | Existing |
| G4 | Phase 2 produces ≥ 1,000 matches across all pairs | Extended (was ≥100 for MIS only) |
| G5 | EJP-ECN reproduces 428 matches (validated reference) | Existing |
| G6 | EUSA-EEU TP adjustment routed to Phase 4 (TP_ELIMINATION category) | New |
| G7 | Phase 3 produces ≥ 20 fuzzy matches | New (MIS had 0) |
| G8 | Phase 4 produces ≥ 50 classifications | New (MIS had 0) |
| G9 | All 6 nature categories represented in Phase 1 output | New |
| G10 | Forex rates loaded for all 16 currencies, both rate types | New |
| G11 | `RECON_STATUS` distribution: <40% GL_BALANCED, >40% GL_VARIANCE | New |
| G12 | `MANUAL_ENTRY_SUMMARY` regression: AI proposed JEs match manual on 70%+ of pairs | New |
| G13 | Entity submission status: 16+ of 18 entities marked as Submitted | New |
| G14 | Phase 2 ran on GL_BALANCED pairs (Samantha gate) | Existing |
| G15 | Multi-ERP coverage: SAP, NetSuite, Visual all represented in IC_LINES | New |
| G16 | Combined TNM+MIS pairs produce per-segment subtotals | New |
| G17 | Feb'26 and Mar'26 both loaded; period comparison view returns data | New |
| G18 | Demo walkthrough page returns within 500ms per click | New |
| G19 | No errors visible on any of the 13 Streamlit pages | New |
| G20 | Excel export of Entry Summary matches manual workbook structure byte-for-byte | New |

---

## 9. Implementation Roadmap

**Total estimated effort: 3-4 weeks for one engineer, 2 weeks for two engineers.**

### Week 1 — Foundation and Ingestion

| Day | Task |
|-----|------|
| 1 | Create `INTERCO_RECON_FULL` database, replicate schema structure from MIS prototype |
| 1-2 | Build Excel ingestion: parse `Compilation`, `Forex`, `Lookup`, `Status` tabs from both reconciliation workbooks into REF and STAGING |
| 3 | Extend `REF.REF_ENTITIES` to 18 entities; load nature taxonomy; load forex rates |
| 4 | Re-ingest existing 7,234 IC_LINES with ERP_SOURCE, NATURE, SEGMENT_TYPE columns populated |
| 5 | Load `REGRESSION.MANUAL_ENTRY_SUMMARY` (76 rows Mar'26 + 97 rows Feb'26) |

### Week 2 — Pipeline Execution

| Day | Task |
|-----|------|
| 1-2 | Adapt Phase 1 to nature-aware aggregation; run end-to-end on Mar'26 |
| 3 | Adapt Phase 2 to single nature-parameterized procedure; run for all pairs/natures |
| 4 | Run Phase 3 across all unmatched lines; tune embedding text construction for non-trade |
| 5 | **Build Phase 4 nature-specific prompts**; run end-to-end against Mar'26 GL_VARIANCE residuals |

### Week 3 — UI and Demo Polish

| Day | Task |
|-----|------|
| 1 | Extend existing 8 Streamlit pages for nature/segment filters |
| 2 | Build new pages: Aggregate Variance, Currency Pivot, Entity Submission |
| 3 | Build the **side-by-side Classification Approval Queue** with manual Entry Summary diff |
| 4 | Build Period Comparison page (Feb'26 vs Mar'26) |
| 5 | Demo Walkthrough page; pre-cache all demo-path queries; smoke-test the 12-minute script |

### Week 4 (optional) — Hardening

| Day | Task |
|-----|------|
| 1-2 | Implement remaining validation gates; run regression suite |
| 3 | Stress-test demo path with stakeholders (internal dry run) |
| 4 | Fix what breaks |
| 5 | Documentation and handoff |

---

## 10. Risks

| Risk | Impact | Mitigation |
|------|--------|-----------|
| Phase 4 prompts produce JEs that don't match Entry Summary | Demo loses credibility — side-by-side shows AI is wrong | Pre-tune prompts using Feb'26 as training; validate against Mar'26 before demo |
| Sales prototype gets confused with production system | Client expects this is what they bought | Separate database, separate doc, never demoed in client's Snowflake account |
| NetSuite / Visual entity data is too sparse for invoice-level matching | Phase 2 numbers stay low | Use GL-level matching only for sparse-data entities; surface as "limitation" in Phase 1 |
| Live demo encounters a slow query | Awkward silence in front of CFO | Pre-aggregate everything; use materialized views; cache demo path queries |
| TP adjustments don't have a clear automation pattern | Phase 4 produces vague classifications for TP_ELIMINATION cases | Hand-curate 3-5 TP examples for few-shot; constrain prompt explicitly |
| Two months of data isn't enough for "trend" | Period Comparison page looks anemic | Use the `Compilation Oct'25` baseline as third period; show 3-point trend |
| Demo audience asks "what about the 8 entities you skipped?" | Credibility hit | Have an honest answer: full enterprise scope = additional ingestion work, not architectural |

---

## 11. What This Prototype Deliberately Doesn't Solve

For honesty and scope discipline:

- **Real-time data ingestion** — assumes monthly batch from reconciliation workbooks
- **ERP integration** — outputs proposed JEs as JSON for human review; doesn't post to SAP/NetSuite
- **User management / SSO** — single shared demo account
- **Audit log persistence beyond demo** — reset weekly
- **Mobile / tablet UI** — desktop only
- **Multi-currency reporting beyond JPY/USD** — fixed to JPY reporting, USD secondary
- **Period close workflow / locking** — open access, no period lock semantics
- **Approver hierarchy** — flat reviewer model
- **Notifications, email integration** — none

If any of these come up in demo Q&A, the answer is: "That's production-system scope. This prototype proves the AI capabilities; production work would add operational concerns."

---

## 12. File Manifest (target end-state)

```
INTERCO_RECON_FULL/
├── schemas/
│   ├── 00_create_database.sql
│   ├── 01_ref_schema.sql
│   ├── 02_staging_schema.sql
│   ├── 03_results_schema.sql
│   ├── 04_hitl_schema.sql
│   ├── 05_regression_schema.sql
│   └── 06_views.sql
├── ingestion/
│   ├── load_compilation.py
│   ├── load_entry_summary.py
│   ├── load_pair_tabs.py
│   ├── load_forex.py
│   ├── load_status.py
│   ├── load_balance_sheet.py
│   └── load_ic_lines_from_bilateral.py  -- reuses extract_load_ready.py from prior work
├── procedures/
│   ├── sp_run_phase1.sql
│   ├── sp_run_phase2.py            -- nature-parameterized
│   ├── sp_run_phase3.py
│   ├── sp_run_phase4.py            -- nature-specific prompts
│   ├── sp_run_pipeline_end_to_end.sql
│   ├── sp_run_validation_suite.sql -- 20 gates
│   └── sp_validate_regression.py
├── streamlit_app/
│   ├── app.py
│   ├── pages/
│   │   ├── 0_Dashboard.py
│   │   ├── 1_GL_Level_Matching.py
│   │   ├── 2_Invoice_Level_Matching.py
│   │   ├── 3_Review_Queue.py
│   │   ├── 4_Fuzzy_Approval_Queue.py
│   │   ├── 5_Classification_Approval_Queue.py    ★ side-by-side
│   │   ├── 6_Entry_Summary.py
│   │   ├── 7_Pair_Reconciliation.py
│   │   ├── 8_Aggregate_Variance.py               ★ new
│   │   ├── 9_Currency_Pivot.py                   ★ new
│   │   ├── 10_Entity_Submission.py               ★ new
│   │   ├── 11_Period_Comparison.py               ★ new
│   │   └── 12_Demo_Walkthrough.py                ★ new (internal)
│   └── utils/
│       ├── snowpark_client.py
│       ├── excel_export.py
│       ├── side_by_side.py                       ★ new
│       └── styling.py
└── docs/
    └── Full_Interco_Recon.md                     -- this document
```

---

## 13. Cross-Reference to MIS Prototype

| MIS Prototype (`INTERCO_RECON`) | Full Prototype (`INTERCO_RECON_FULL`) | Relationship |
|---------------------------------|---------------------------------------|--------------|
| 9 entities, 17 pairs | 18 entities, 35+ pairs | Superset |
| MIS-only IC_LINES (7,234) | MIS + TNM IC_LINES (same source files, broader filtering) | Reuses extraction pipeline |
| GL_BALANCES from IC_LINES | GL_BALANCES from Compilation tab directly | Different source for same table |
| 167 Phase 2 matches | Target >1,000 matches | Validation difference |
| Phase 3 / Phase 4 = 0 rows | Phase 3 ≥20, Phase 4 ≥50 | Demonstrably exercised |
| Trade only in Phase 2 | All 6 natures in Phase 2 + Phase 4 | Functionally complete |
| 1 prompt template | 6 nature-specific templates | Better classification |
| 8 Streamlit pages | 13 Streamlit pages | Demo-oriented additions |
| 4 of 14 validation gates | 20 validation gates | Full coverage |
| Generated docs from live metadata | Hand-written demo-script-driven doc | Different purpose |

---

## Appendix A — Real Data Examples Driving the Spec

### A.1 EEU-SPIND missing booking (Mar'26)

From `Entry Summary` row 6-7:

```
SAP Code    Description           LC     LC Amount   JPY Amount     Entity   ICP    ICP Code   Segment   Remark
0000010015  Man Inv Adj Merch     USD     99,550     15,916,054     EEU      SPIND  5030P      MIS       1 invoice not taken
105400      Trade A/P OG          USD    -99,550    -15,916,054     EEU      SPIND  5030P      MIS       1 invoice not taken (BS ICP MIS)
```

Phase 4 must produce this exact pair of journal lines. The Remark text "1 invoice not taken" maps to `MISSING_BOOKING`.

### A.2 EJP-ETCE forex difference (Mar'26)

From `Entry Summary` row 16-17:

```
I613100     Exchange Loss         EUR     39,318.94    7,211,487   ETCE     EJP    1096       MIS       Due to forex issue
135400      Total Oth Curr Lia    EUR    -39,318.94   -7,211,487   ETCE     EJP    1096       MIS       Due to forex issue (BS ICP MIS)
```

Phase 4 must classify as `FOREX_DIFFERENCE` with confidence >0.85, produce the matching DR/CR pair, and use the Exchange Loss account I613100.

### A.3 EUSA-EEU TP elimination (Mar'26)

From `TNM-EUSAvsEEU` pair tab:

A €7,833,410 transfer pricing receivable on EEU's books vs a $9,222,732.75 payable on EUSA's books. Forex difference $236,457.24. Reconciliation requires a forex adjustment journal:

```
12290       Interco A/R - OEKG    USD     236,457.24   37,804,784   EUSA     EEU    4001       TNM       Forex differences
707200      (Gain)/Loss on Exc    USD    -236,457.24  -37,804,784   EUSA            (blank)    TNM       Forex differences
```

Phase 4 must recognize this as `TP_ELIMINATION` (the new category) and propose the forex P&L adjustment.

### A.4 ECN-ETCE 4 missing invoices (Mar'26)

From `Entry Summary` row 11-12:

```
1405204000  Man Inv Adj Merch     CNY    434,136.44   10,032,893   ECN     ETCE    4048       MIS       4 invoices not taken
2202101010  Trade Accounts Pay    CNY   -434,136.44  -10,032,893   ECN     ETCE    4048       MIS       4 invoices not taken (BS ICP MIS)
```

Phase 4 must classify as `MISSING_BOOKING` AND identify in the reasoning that 4 specific invoices were missing (extractable from Phase 2 orphans).

---

## Appendix B — Differences from `Evident_Intercompany_Reconciliation.md`

For implementers familiar with the MIS doc:

**Same:**
- Database schema layout (RAW, REF, STAGING, RESULTS, HITL, TRAINING, REGRESSION)
- 4-phase pipeline
- Cortex models (`snowflake-arctic-embed-l-v2.0`, `claude-3-5-sonnet`)
- HITL queue mechanics
- Streamlit page mechanics
- Phase 1 always-runs-then-Phase-2 (Samantha gate)

**Different:**
- Database name (`INTERCO_RECON_FULL` not `INTERCO_RECON`)
- Source of GL_BALANCES (Compilation tab, not derived from IC_LINES)
- 6 natures instead of binary Trade/Non-Trade
- 18 entities instead of 9
- 35+ pairs instead of 17
- 3 ERP sources instead of 1
- 5 new Streamlit pages
- 20 validation gates instead of 4
- Phase 4 has 6 nature-specific prompts instead of 1
- New root cause category: `TP_ELIMINATION`
- Side-by-side regression comparison built into Classification Approval Queue
- Demo Walkthrough as a first-class app page

**New components not in MIS:**
- `REF.REF_NATURE_TAXONOMY`
- `STAGING.ENTITY_SUBMISSION_STATUS`
- `REGRESSION.MANUAL_ENTRY_SUMMARY`
- `REGRESSION.MANUAL_PAIR_RECONCILIATION`
- Period Comparison view (Feb'26 vs Mar'26)
- Currency Pivot view
- Multi-ERP indicator on every IC_LINES row

---

*Document version 1.0 — 2026-05-18*
*Status: Specification ready for build. No code yet exists.*
