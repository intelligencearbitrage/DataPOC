# Physician Affiliation Automation
## Scheduled Insurance / Network Validation with Mixed Input Identifiers

**Version:** 1.0  
**Refresh Cadence:** Weekly or Monthly  
**Primary Use Case:** Insurance / In-Network Validation  
**Input Types:** NPI number, Name + State/Specialty, or both  

---

## 1. Overview

This document describes the end-to-end approach for automating physician affiliation lookups and insurance network validation. The process accepts mixed physician identifiers, resolves all records to canonical NPI numbers, enriches them with current affiliation and provider data from authoritative public sources, and validates network status against payer files — producing a refreshed provider master, a change alert report, and an exception report on each scheduled run.

The automation replaces manual lookup across CMS Physician Compare, insurance portals, and NPI registries — sources that are individually reliable but impractical to query at scale by hand.

---

## 2. Architecture

### 2.1 Pipeline Stages

```
Input Layer
  ├── NPI List (pre-known)
  ├── Name + State / Specialty
  └── Scheduler (cron / Snowflake Task)
         │
         ▼
Stage 1 — NPI Resolution
  └── NPPES API → canonical NPI for all records
         │
         ▼
Stage 2 — Parallel Enrichment
  ├── CMS Care Compare API → hospital/facility affiliations
  └── NPPES enrichment → specialty, address, active status
         │
         ▼
Stage 3 — Network Validation
  └── Cross-reference affiliation vs. payer network files
         │
         ▼
Output Layer
  ├── Provider Master Table (upserted)
  ├── Change Alert Report (delta)
  └── Exception Report (unresolved / no affiliation)
```

### 2.2 Data Sources

| Source | Purpose | Access | Refresh Frequency |
|---|---|---|---|
| NPPES NPI Registry | NPI resolution, provider demographics | Free REST API | Daily |
| CMS Care Compare | Hospital affiliation (Medicare claims-derived) | Free REST API | Monthly |
| No Surprises Act MRF | Payer in-network provider files | Public URLs (per insurer) | Monthly |
| State Medical Boards | License status verification (optional) | Varies by state | Varies |

---

## 3. Detailed Steps

### Step 1 — Input Ingestion

**Accept two input types in a single unified schema:**

```
physician_input {
  record_id       : string        # internal tracking ID
  npi             : string | null # 10-digit NPI if known
  first_name      : string | null # required if NPI not provided
  last_name       : string | null # required if NPI not provided
  state           : string | null # 2-letter code, strongly recommended
  specialty       : string | null # taxonomy code or plain text
  source_system   : string        # "EHR", "CRM", "manual", etc.
  last_verified   : date | null   # date of last successful lookup
}
```

Records with a valid NPI pass directly to Stage 2. Records without one enter the resolution sub-pipeline.

---

### Step 2 — NPI Resolution (Name + State → NPI)

Call the NPPES API for each unresolved record:

```
GET https://npiregistry.cms.hhs.gov/api/
  ?version=2.1
  &first_name={first_name}
  &last_name={last_name}
  &state={state}
  &taxonomy_description={specialty}
  &limit=5
```

**Resolution logic:**

1. If exactly one result is returned → accept NPI automatically
2. If multiple results are returned → apply fuzzy name match + specialty filter; accept if top match score ≥ 0.90
3. If zero results or score < 0.90 → route to exception queue for human review
4. If NPI is deactivated in NPPES response → flag as inactive; do not enrich further

**Output:** Every resolved record carries a canonical NPI and a `resolution_confidence` score (1.0 for direct NPI input, 0.0–1.0 for name-resolved).

---

### Step 3 — Affiliation Enrichment (Parallel)

Run two enrichment calls per NPI simultaneously:

#### 3a. CMS Care Compare — Hospital Affiliations

```
GET https://data.cms.gov/provider-data/api/1/datastore/sql
  ?query=[SELECT * FROM facility_affiliations WHERE npi='{npi}']
```

Returns list of affiliated hospitals/facilities with:
- Facility name and CCN (CMS Certification Number)
- Facility type (hospital, SNF, hospice, etc.)
- State and address
- Affiliation type (admitting privileges, employment, etc.)

#### 3b. NPPES — Provider Demographics and Status

```
GET https://npiregistry.cms.hhs.gov/api/?version=2.1&number={npi}
```

Returns:
- Provider name, credential suffix
- Primary practice address
- Taxonomy codes (specialty)
- Enumeration date and last update date
- Active / deactivated status

**Merge both payloads into a single enriched provider record per NPI.**

---

### Step 4 — Network Validation

Compare the enriched affiliation data against payer network files:

1. **Load payer MRF (machine-readable files):** Under the No Surprises Act, all US health insurers must publish in-network provider files as JSON. Load the relevant plan file(s) for your use case.

2. **Match logic (three-tier, in order):**
   - **Tier 1 — NPI exact match:** Physician's NPI appears directly in the payer's in-network provider list → `IN_NETWORK`
   - **Tier 2 — Group/facility match:** Physician is not listed individually but their affiliated hospital/group NPI is in-network → `IN_NETWORK_VIA_FACILITY` (flag for human review)
   - **Tier 3 — No match:** Neither physician NPI nor affiliated facility NPI found in payer file → `OUT_OF_NETWORK`

3. **Multi-payer support:** Run validation against each relevant payer file and store a result per payer. A physician may be in-network for one plan and out-of-network for another.

---

### Step 5 — Output Generation

#### 5a. Provider Master Table (upsert)

```sql
provider_master {
  npi                   : varchar(10)   PK
  full_name             : varchar
  primary_specialty     : varchar
  primary_address       : varchar
  state                 : varchar(2)
  active_status         : boolean
  affiliated_hospitals  : array<json>   -- list of facility records
  network_status        : json          -- keyed by payer_id
  resolution_confidence : decimal(3,2)
  last_verified_date    : date
  last_changed_date     : date
  source_record_ids     : array<string>
}
```

Each run performs an **upsert** (insert new, update changed records). A `last_changed_date` is stamped only when affiliation or network status actually changes.

#### 5b. Change Alert Report

Delta between current run and prior run, filtered to records where any of the following changed:

- Affiliated hospital added or removed
- Network status changed (in → out, or out → in) for any payer
- Provider deactivated in NPPES
- Primary address changed (potential practice relocation)

Delivered as CSV or email digest, keyed by record_id for downstream workflow routing.

#### 5c. Exception Report

Records that require human intervention:

| Exception Type | Description | Recommended Action |
|---|---|---|
| `NPI_NOT_RESOLVED` | Name search returned 0 results | Verify spelling, check state |
| `LOW_CONFIDENCE_MATCH` | Name match score < 0.90 | Manual NPI lookup |
| `MULTIPLE_NPI_CANDIDATES` | >1 NPI returned, none clearly dominant | Manual disambiguation |
| `NPI_DEACTIVATED` | Provider NPI is inactive in NPPES | Confirm retirement / relocation |
| `NO_AFFILIATION_DATA` | NPI resolved but CMS returned no affiliations | May be newer provider; retry next cycle |
| `PAYER_FILE_STALE` | Payer MRF file not updated in >45 days | Flag payer file for manual check |

---

## 4. Guardrails

### 4.1 Data Quality Guardrails

- **NPI format validation:** All NPIs must be exactly 10 digits and pass the Luhn check algorithm before any API call is made. Malformed NPIs go directly to the exception queue.
- **Resolution confidence threshold:** Only NPI matches with confidence ≥ 0.90 are auto-accepted. Below this, a human must confirm before the record enters the provider master.
- **Stale record detection:** Any provider record not re-verified within 60 days (for monthly runs) or 14 days (for weekly runs) is flagged as potentially stale and re-queued for lookup even if no explicit change is detected.
- **Deduplication:** Before upserting, check for duplicate NPIs within the same input batch. Merge source_record_ids; do not create duplicate master records.

### 4.2 API Reliability Guardrails

- **Retry logic:** All API calls implement exponential backoff with 3 retries (delays: 2s, 4s, 8s) before marking a record as failed for that run.
- **Rate limiting:** NPPES API is rate-limited; throttle to no more than 5 concurrent requests. CMS Care Compare has no published limit but apply a 200ms delay between calls as a courtesy.
- **Partial run recovery:** Log the last successfully processed NPI after each batch of 100 records. On failure, resume from that checkpoint rather than restarting the full run.
- **Payer file freshness check:** Before loading a payer MRF file, compare the file's `last_updated_on` field against the previous run. If unchanged, skip re-loading and use the cached network index.

### 4.3 Compliance and Privacy Guardrails

- **PII minimization:** Store only the minimum physician identifiers needed (NPI, name, address). Do not store patient data at any stage.
- **Audit trail:** Maintain a run log with: run timestamp, records processed, records changed, records excepted, API call counts, and any errors. Retain for 12 months minimum.
- **Source attribution:** Every affiliation record in the provider master must carry a `data_source` tag (e.g., `cms_care_compare`, `nppes`) and a `source_as_of_date` so downstream consumers know the provenance and age of the data.
- **No Surprises Act alignment:** When using payer MRF files, record the file URL and publication date alongside any network status determination. This creates a defensible audit record for network status claims.

### 4.4 Operational Guardrails

- **Exception rate monitoring:** If more than 10% of records in a single run land in the exception queue, halt the run and send an alert. This likely indicates an upstream API change or input data quality problem — not a normal exception volume.
- **Change spike detection:** If more than 15% of active provider records show an affiliation change in a single run, treat it as a suspect run (possible payer file refresh artifact) and hold the change alert report for human review before distribution.
- **Idempotency:** Each run is identified by a `run_id`. Re-running the same scheduled job twice (e.g., after a failure) must produce identical results and must not create duplicate change alert records.

---

## 5. Implementation Stack

### Recommended (Snowflake-native)

| Component | Technology |
|---|---|
| Orchestration | Snowflake Tasks (cron schedule) |
| API calls | Python UDFs or External Functions |
| NPI resolution | Python (requests) calling NPPES REST API |
| Affiliation lookup | Python calling CMS Care Compare API |
| Payer file ingestion | Snowflake COPY INTO from staged MRF JSON |
| Provider master | Snowflake table with MERGE (upsert) |
| Change detection | Snowflake Streams on provider master table |
| Exception routing | Snowflake table + email alert via notification integration |
| Observability | Snowflake query history + custom run_log table |

### Alternative (Standalone Python)

| Component | Technology |
|---|---|
| Orchestration | Apache Airflow or cron |
| Data processing | Python + pandas |
| Storage | PostgreSQL or Snowflake |
| Alerting | Email (SMTP) or Slack webhook |

---

## 6. Suggested Snowflake Table Schema

```sql
-- Provider master
CREATE OR REPLACE TABLE provider_master (
  npi                   VARCHAR(10)     NOT NULL PRIMARY KEY,
  full_name             VARCHAR(200),
  first_name            VARCHAR(100),
  last_name             VARCHAR(100),
  credential            VARCHAR(50),
  primary_specialty     VARCHAR(200),
  primary_address       VARCHAR(500),
  city                  VARCHAR(100),
  state                 VARCHAR(2),
  zip                   VARCHAR(10),
  active_status         BOOLEAN,
  affiliated_hospitals  VARIANT,        -- JSON array
  network_status        VARIANT,        -- JSON keyed by payer_id
  resolution_confidence DECIMAL(3,2),
  data_sources          VARIANT,        -- JSON array of {source, as_of_date}
  source_record_ids     VARIANT,        -- JSON array
  last_verified_date    DATE,
  last_changed_date     DATE,
  created_at            TIMESTAMP_NTZ   DEFAULT CURRENT_TIMESTAMP,
  updated_at            TIMESTAMP_NTZ   DEFAULT CURRENT_TIMESTAMP
);

-- Run log
CREATE OR REPLACE TABLE affiliation_run_log (
  run_id                VARCHAR(50)     NOT NULL PRIMARY KEY,
  run_timestamp         TIMESTAMP_NTZ,
  records_input         INTEGER,
  records_resolved      INTEGER,
  records_enriched      INTEGER,
  records_changed       INTEGER,
  records_excepted      INTEGER,
  api_calls_nppes       INTEGER,
  api_calls_cms         INTEGER,
  exception_rate        DECIMAL(5,4),
  run_status            VARCHAR(20),    -- COMPLETE, PARTIAL, FAILED, HALTED
  notes                 VARCHAR(2000)
);

-- Exception queue
CREATE OR REPLACE TABLE affiliation_exceptions (
  exception_id          VARCHAR(50)     NOT NULL PRIMARY KEY,
  run_id                VARCHAR(50),
  record_id             VARCHAR(100),
  npi_attempted         VARCHAR(10),
  input_name            VARCHAR(200),
  input_state           VARCHAR(2),
  exception_type        VARCHAR(50),
  exception_detail      VARCHAR(1000),
  resolved              BOOLEAN         DEFAULT FALSE,
  resolved_by           VARCHAR(100),
  resolved_at           TIMESTAMP_NTZ,
  created_at            TIMESTAMP_NTZ   DEFAULT CURRENT_TIMESTAMP
);
```

---

## 7. Open Items and Future Enhancements

| Item | Description | Priority |
|---|---|---|
| State medical board integration | Add license status and disciplinary action checks per state | Medium |
| Multi-payer MRF indexing | Pre-index all payer MRF files into a queryable Snowflake table rather than loading per run | High |
| Cortex-assisted exception resolution | Use Snowflake Cortex to suggest likely NPI matches for low-confidence exceptions | Medium |
| Telehealth network flags | Some payers maintain separate telehealth network files; extend validation to cover these | Low |
| CAQH integration | For credentialing-grade validation, integrate CAQH ProView as a supplementary source | Future |
| Real-time API mode | Extend architecture to support on-demand single-record lookups alongside the scheduled batch | Future |

---

*Document generated: April 2026*  
*Maintained by: FDE Practice — Financial Data & Engineering, Deloitte*
