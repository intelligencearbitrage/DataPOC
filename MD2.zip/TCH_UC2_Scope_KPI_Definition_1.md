# TCH Use Case 2: THCIC / Market & Referral Analytics Pilot
## Scope & KPI Definition Document

**Version:** 1.0
**Date:** April 22, 2026
**Status:** Draft — Pending Client Review

---

## 1. Purpose

This document defines the pilot scope, success criteria, and key performance indicators (KPIs) for the TCH SG2 Market & Referral Analytics Pilot. It is intended to align internal delivery teams and the Client on measurable outcomes prior to development kickoff within Snowflake.

---

## 2. Pilot Scope

The pilot will focus on **one or more** of the following capability candidates, to be finalized in consultation with the Client:

### 2a. Conversational Analytics Agent
A natural language interface enabling users to query market share, referral patterns, and provider performance without requiring SQL or BI tool expertise.

**Target Users:** Physician liaisons, service line leaders, strategy and planning teams
**Data Sources:** Referral data, market share data, provider performance metrics (all within Snowflake)
**Key Capabilities:**
- Query referral volumes by provider, specialty, and geography
- Surface market share trends over configurable time periods
- Identify top referring and leaking providers on demand

### 2b. On-Demand Output Generation
A system that accepts natural language inputs and generates audience-specific charts, graphs, and formatted outputs automatically.

**Target Users:** Strategy teams, executives, physician liaison managers
**Key Capabilities:**
- Dynamic chart and graph generation based on plain-language requests
- Audience-specific output formatting (e.g., executive summary vs. operational detail)
- Export-ready visuals for presentations and reports

### 2c. Predictive Referral & Market Intelligence Model
A predictive analytics model that anticipates referral trend shifts, market share movement, and physician behavioral changes to enable proactive outreach.

**Target Users:** Physician liaison teams, market strategy teams
**Key Capabilities:**
- Forecasting referral volume changes by provider or geography
- Early detection of physician migration or loyalty decline
- Prioritized outreach recommendations before volume is lost

---

## 3. Success KPIs

### 3.1 Technical Performance KPIs

| KPI | Description | Target |
|-----|-------------|--------|
| Query Accuracy | % of natural language queries returning correct, relevant results | ≥ 90% |
| Response Latency | Average time to return a result or visualization | ≤ 5 seconds |
| Data Freshness | Lag between source data update and availability in pilot system | ≤ 24 hours |
| System Uptime | Availability during pilot period | ≥ 99% |
| Prediction Accuracy (2c only) | Accuracy of referral trend forecasts vs. actuals | ≥ 80% |

### 3.2 User Adoption & Experience KPIs

| KPI | Description | Target |
|-----|-------------|--------|
| Active User Rate | % of invited pilot users engaging with the system at least weekly | ≥ 70% |
| Task Completion Rate | % of user queries or tasks completed without escalation to IT/analyst | ≥ 85% |
| User Satisfaction Score | Average score from end-of-pilot survey (1–5 scale) | ≥ 4.0 |
| Time-to-Insight Reduction | Reduction in time to access referral/market insights vs. current state | ≥ 40% |

### 3.3 Business Impact KPIs

| KPI | Description | Target |
|-----|-------------|--------|
| Referral Leakage Identified | # of at-risk provider relationships surfaced during pilot | ≥ 10 actionable findings |
| Proactive Outreach Triggered (2c only) | # of liaison outreach actions initiated based on predictive alerts | ≥ 5 during pilot period |
| Market Share Insights Generated | # of unique market share insights surfaced and reviewed by strategy team | ≥ 15 during pilot period |
| Analyst Time Saved | Estimated hours saved per week vs. manual reporting baseline | ≥ 10 hrs/week |

---

## 4. Pilot Parameters

| Parameter | Detail |
|-----------|--------|
| **Duration** | 8–12 weeks (to be confirmed with Client) |
| **Environment** | Snowflake (Client-provisioned or Deloitte sandbox) |
| **Pilot Users** | 10–20 users across target personas |
| **Data Requirements** | Historical referral data (minimum 24 months), market share data, provider registry |
| **Integration Scope** | Snowflake only; no EHR or external API integrations in Phase 1 |
| **Governance** | PHI/PII handling per Client data governance policy; de-identified data preferred for pilot |

---

## 5. Out of Scope (Pilot Phase)

- EHR or EMR system integration
- Real-time streaming data pipelines
- Payer or claims data integration
- Production deployment or enterprise rollout
- Custom CRM or liaison workflow automation

---

## 6. Next Steps

| # | Action | Owner | Due |
|---|--------|-------|-----|
| 1 | Confirm pilot scope selection (2a, 2b, 2c, or combination) | Client + Delivery Lead | TBD |
| 2 | Validate data availability and access in Snowflake | Client Data Team | TBD |
| 3 | Finalize KPI targets with Client stakeholders | Strategy Lead | TBD |
| 4 | Establish pilot user group and personas | Client Champion | TBD |
| 5 | Kick off Pilot Development (Snowflake build) | Delivery Team | TBD |

---

*This document is a working draft and subject to revision based on Client input and discovery findings.*
