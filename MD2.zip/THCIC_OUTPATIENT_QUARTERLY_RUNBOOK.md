# THCIC Outpatient PUDF — Quarterly Data Pipeline Runbook

**Source:** Texas Department of State Health Services (DSHS) — Texas Health Care Information Collection (THCIC)  
**Data:** Texas Hospital Outpatient Public Use Data File (PUDF)  
**Frequency:** Quarterly — released approximately 60–90 days after the close of the quarter  
**Schema:** `THCIC` (Snowflake)  
**Maintainer:** *(your name / team)*  
**Last updated:** 2025Q1

> **Read this alongside the Inpatient Runbook.** The outpatient pipeline uses the same architecture and the same `LKP_*` coding scheme tables. Only the staging table names and source files differ. If you have not set up the inpatient pipeline yet, do that first — steps 4.1 through 4.4 in the Inpatient Runbook create the schema, stage, and all shared `LKP_*` tables that outpatient depends on.

---

## Table of Contents

1. [How Outpatient Differs from Inpatient](#1-how-outpatient-differs-from-inpatient)
2. [File Inventory](#2-file-inventory)
3. [Table Naming Conventions](#3-table-naming-conventions)
4. [One-Time Setup (First Run Only)](#4-one-time-setup-first-run-only)
5. [Quarterly Execution Steps](#5-quarterly-execution-steps)
6. [Validation Checks](#6-validation-checks)
7. [Troubleshooting](#7-troubleshooting)
8. [YEAR_QUARTER Reference](#8-year_quarter-reference)
9. [File Naming Convention](#9-file-naming-convention)
10. [Known Outpatient Data Limitations](#10-known-outpatient-data-limitations)
11. [Change Log](#11-change-log)

---

## 1. How Outpatient Differs from Inpatient

Understanding these differences prevents the most common loading mistakes.

| Dimension | Inpatient (`STG_IP_*`) | Outpatient (`STG_OP_*`) |
|-----------|----------------------|------------------------|
| Base data files | Two files: BASE1 + BASE2 | **One file: BASE** |
| Grouper file | Yes — MS-DRG and APR-DRG | **No grouper file** |
| Length of stay | `LENGTH_OF_STAY` field | **No LOS field** — use `FROM_DATE_SEQ` and `THROUGH_DATE_SEQ` |
| Procedure codes | ICD-10-PCS | ICD-10-PCS **and** CPT-4 (more common in outpatient) |
| HCPCS codes | Sparsely populated | **More heavily populated** — core to outpatient analysis |
| Place of service | Not present | `PLACE_OF_SERVICE` field present |
| DRG assignment | Frozen + dynamic MS-DRG and APR-DRG | Not applicable |
| Record volume | ~840K–870K per quarter | Significantly higher — typically 3–5M+ per quarter |
| Charges file volume | ~16–17M rows per quarter | Higher — outpatient has more line items per encounter |
| Coding schemes | Shared `LKP_*` tables | **Same shared `LKP_*` tables** — no separate lookup tables needed |
| Facility type file | Includes all licensed hospitals | Same provider universe |

**The `LKP_*` tables you created during inpatient setup are fully reused for outpatient.** You do not create new lookup tables. PAT_STATUS, REVENUE_CODE, PAYMENT_SOURCE, and every other coding scheme is identical between the two datasets.

---

## 2. File Inventory

### SQL Files

| File | Run When | Purpose |
|------|----------|---------|
| `07_outpatient_stg_ddl.sql` | One-time setup | Creates `STG_OP_BASE`, `STG_OP_CHARGES`, `STG_OP_FACILITY_TYPE` |
| `03_copy_into_stg_lkp.sql` | Every quarter (shared) | Loads coding scheme CSVs — already handles both datasets |
| `05_quarterly_validation.sql` | Every quarter (shared) | Add outpatient-specific checks — see Section 6 |

> The inpatient files `04_promote_stg_to_lkp.sql` and `02_lookup_ddl.sql` do not need separate outpatient versions. They are shared.

### PUDF Data Files (downloaded from DSHS each quarter)

| PUDF File | Target Table | Format | Approx. Size per Quarter |
|-----------|-------------|--------|--------------------------|
| Base Data | `STG_OP_BASE` | CSV (comma-delimited) | ~500–800 MB |
| Charges | `STG_OP_CHARGES` | CSV (comma-delimited) | ~1–3 GB |
| Facility Type | `STG_OP_FACILITY_TYPE` | CSV (comma-delimited) | ~42 KB |

> Outpatient volumes vary more than inpatient depending on the scope of facilities reporting in a given quarter. Charges file is the largest file in the entire pipeline.

### Important: Verify the Outpatient User Manual

The `07_outpatient_stg_ddl.sql` file was constructed from the known THCIC Outpatient PUDF structure. Before your first production load, download the current **Outpatient PUDF User Manual** from [https://www.dshs.texas.gov/THCIC](https://www.dshs.texas.gov/THCIC) and verify:

- The field list and positions in the Base Data file
- Any fields not present in outpatient that are present in inpatient (and vice versa)
- The `PLACE_OF_SERVICE` coding scheme (not currently in a `LKP_*` table — add one if needed)
- Whether DSHS has split the outpatient base file in recent years (they have not historically, but check)

Fields marked with a note in the DDL comments should be verified before go-live.

---

## 3. Table Naming Conventions

| Prefix | Layer | Description |
|--------|-------|-------------|
| `STG_OP_BASE` | Staging | Raw outpatient encounter data. One row per encounter. |
| `STG_OP_CHARGES` | Staging | Raw outpatient line-item charges. One-to-many with `STG_OP_BASE`. |
| `STG_OP_FACILITY_TYPE` | Staging | Outpatient facility indicators. One row per provider per quarter. |
| `STG_LKP_*` | Staging (lookup) | Shared with inpatient — not duplicated for outpatient. |
| `LKP_*` | Master | Shared with inpatient — not duplicated for outpatient. |

All tables carry a `YEAR_QUARTER` column (e.g. `2025Q1`). This is your partition key, audit trail, and rollback handle — same as inpatient.

---

## 4. One-Time Setup (First Run Only)

> **Prerequisite:** Complete the inpatient one-time setup first (steps 4.1–4.4 in the Inpatient Runbook). The schema, stage, and all `LKP_*` tables must exist before proceeding.

### Step 4.1 — Create the outpatient staging tables

```sql
USE SCHEMA THCIC;
```

Then run:

```bash
07_outpatient_stg_ddl.sql
```

### Step 4.2 — Verify the User Manual

Before loading any data, open the THCIC Outpatient PUDF User Manual and confirm the field list in `07_outpatient_stg_ddl.sql` matches the current specification. Pay particular attention to:

- The Base Data file column count (fixed-width positions or tab count)
- Whether `PLACE_OF_SERVICE` is present and what values are valid
- Whether there are any outpatient-specific fields not in the inpatient DDL

If fields need to be added or removed, update `07_outpatient_stg_ddl.sql` and re-run it before loading data.

### Step 4.3 — Add outpatient checks to the validation script

Copy the outpatient-specific validation queries from Section 6 of this runbook into `05_quarterly_validation.sql`. You only need to do this once.

---

## 5. Quarterly Execution Steps

Perform these steps every quarter. Run them **in addition to** the inpatient quarterly steps — they share the coding scheme steps (Steps 5.3 and 5.6 below).

> Replace `2025Q1` with the actual quarter in every script before running.

---

### Step 5.1 — Identify the quarter

Same as inpatient. Determine `YEAR_QUARTER` from the downloaded file names.

| Quarter | Months | YEAR_QUARTER Value |
|---------|--------|--------------------|
| Q1 | January – March | `2025Q1` |
| Q2 | April – June | `2025Q2` |
| Q3 | July – September | `2025Q3` |
| Q4 | October – December | `2025Q4` |

---

### Step 5.2 — Check the Outpatient User Manual for changes

Same process as inpatient Step 5.2. Compare the "Last Updated" date on the outpatient manual against the prior quarter. Key things that change in outpatient:

- HCPCS code set updates (CMS releases annually in October)
- CPT-4 procedure code changes
- `PLACE_OF_SERVICE` code additions or retirements
- Any structural changes to the base file

---

### Step 5.3 — Download PUDF files from DSHS

1. Download the **CSV (comma-delimited)** versions of the 3 outpatient files for the target quarter
2. Confirm file sizes are within the expected ranges in Section 2
3. Verify the file contains header row or no header row (the PUDF files typically have no header — confirm this in the User Manual)
4. Name files using the convention in Section 9

---

### Step 5.4 — Update YEAR_QUARTER in scripts

In `05_quarterly_validation.sql`, replace `2025Q1` with the actual quarter for any outpatient-specific queries you added.

The inpatient scripts (`03_copy_into_stg_lkp.sql`, `04_promote_stg_to_lkp.sql`) also need to be updated if running both datasets in the same quarter — this is shared work.

---

### Step 5.5 — Upload files to Snowflake stage

```sql
-- Upload outpatient PUDF data files
PUT file://path/to/thcic_op_base_2025_q1.csv       @THCIC.THCIC_CSV_STAGE;
PUT file://path/to/thcic_op_charges_2025_q1.csv    @THCIC.THCIC_CSV_STAGE;
PUT file://path/to/thcic_op_facility_2025_q1.csv   @THCIC.THCIC_CSV_STAGE;
```

> The Charges file is large. If uploading via SnowSQL, allow extra time. Consider compressing with gzip before staging (`PUT` supports `.gz` files automatically).

---

### Step 5.6 — Load coding scheme staging tables (shared step)

If running outpatient in the same quarter as inpatient, this step is already done. If running outpatient alone:

```bash
03_copy_into_stg_lkp.sql
```

---

### Step 5.7 — Load PUDF data into outpatient staging tables

Use `COPY INTO` with CSV format. Example for the Base file:

```sql
-- Truncate staging before load (keeps only current quarter)
TRUNCATE TABLE THCIC.STG_OP_BASE;
TRUNCATE TABLE THCIC.STG_OP_CHARGES;
TRUNCATE TABLE THCIC.STG_OP_FACILITY_TYPE;

-- Load Base Data
COPY INTO THCIC.STG_OP_BASE
  FROM (
    SELECT $1, $2, $3, $4, $5,   -- ... all columns in source order ...
           '2025Q1'               -- YEAR_QUARTER injected as literal
    FROM @THCIC.THCIC_CSV_STAGE/thcic_op_base_2025_q1.csv
  )
  FILE_FORMAT = (
    TYPE                        = CSV
    FIELD_DELIMITER             = ','
    FIELD_OPTIONALLY_ENCLOSED_BY = '"'
    SKIP_HEADER                 = 0
    NULL_IF                     = ('')
  )
  ON_ERROR = 'CONTINUE';

-- Load Charges (large file — use parallel loading if available)
COPY INTO THCIC.STG_OP_CHARGES
  FROM (
    SELECT $1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13,
           '2025Q1'
    FROM @THCIC.THCIC_CSV_STAGE/thcic_op_charges_2025_q1.csv
  )
  FILE_FORMAT = (
    TYPE                        = CSV
    FIELD_DELIMITER             = ','
    FIELD_OPTIONALLY_ENCLOSED_BY = '"'
    SKIP_HEADER                 = 0
    NULL_IF                     = ('')
  )
  ON_ERROR = 'CONTINUE';

-- Load Facility Type
COPY INTO THCIC.STG_OP_FACILITY_TYPE
  FROM (
    SELECT $1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13,
           '2025Q1'
    FROM @THCIC.THCIC_CSV_STAGE/thcic_op_facility_2025_q1.csv
  )
  FILE_FORMAT = (
    TYPE                        = CSV
    FIELD_DELIMITER             = ','
    FIELD_OPTIONALLY_ENCLOSED_BY = '"'
    SKIP_HEADER                 = 0
    NULL_IF                     = ('')
  )
  ON_ERROR = 'CONTINUE';
```

> `YEAR_QUARTER` is not in the source files. It must be injected as a literal in the `SELECT` clause, as shown above.

---

### Step 5.8 — Run validation

Run the outpatient-specific checks you added to `05_quarterly_validation.sql`. See Section 6.

---

### Step 5.9 — Promote lookup tables (shared step)

If running outpatient in the same quarter as inpatient, this is already done. If running outpatient alone:

```bash
04_promote_stg_to_lkp.sql
```

---

### Step 5.10 — Archive and document

Record row counts in the quarterly log:

| Quarter | OP_BASE Rows | OP_CHARGES Rows | Providers | Notes |
|---------|-------------|----------------|-----------|-------|
| 2025Q1 | *(fill in)* | *(fill in)* | *(fill in)* | Initial outpatient load |
| 2025Q2 | | | | |

---

## 6. Validation Checks

Add these queries to `05_quarterly_validation.sql` after the inpatient checks. Replace `2025Q1` with the actual quarter each time you run.

### Check OP-1 — Row counts on outpatient staging tables

```sql
SELECT 'STG_OP_BASE' AS tbl, YEAR_QUARTER, COUNT(*) AS rows
  FROM THCIC.STG_OP_BASE GROUP BY YEAR_QUARTER;

SELECT 'STG_OP_CHARGES' AS tbl, YEAR_QUARTER, COUNT(*) AS rows
  FROM THCIC.STG_OP_CHARGES GROUP BY YEAR_QUARTER;

SELECT 'STG_OP_FACILITY_TYPE' AS tbl, YEAR_QUARTER, COUNT(*) AS rows
  FROM THCIC.STG_OP_FACILITY_TYPE GROUP BY YEAR_QUARTER;
```

**Pass:** Each table shows one row with the current quarter and a non-zero, plausible count.

**Fail indicators:**
- 0 rows → load did not complete; check `COPY INTO` error log
- Implausibly low count → check `ON_ERROR = 'CONTINUE'` errors via `COPY_HISTORY`

---

### Check OP-2 — Orphan charge records

```sql
SELECT COUNT(*) AS orphan_op_charge_records
  FROM THCIC.STG_OP_CHARGES c
  LEFT JOIN THCIC.STG_OP_BASE b
    ON c.RECORD_ID = b.RECORD_ID AND c.YEAR_QUARTER = b.YEAR_QUARTER
 WHERE b.RECORD_ID IS NULL
   AND c.YEAR_QUARTER = '2025Q1';
```

**Pass:** 0 orphan records.

**If non-zero:** BASE and CHARGES files are likely from different quarters. Verify file names and re-load from the correct matching pair.

---

### Check OP-3 — YEAR_QUARTER consistency

```sql
SELECT YEAR_QUARTER, COUNT(*) AS rows
  FROM THCIC.STG_OP_BASE
 GROUP BY YEAR_QUARTER;
```

**Pass:** Single row showing only the current quarter.

**If multiple quarters:** Prior quarter data was not truncated. Decide whether to retain multi-quarter history or truncate.

---

### Check OP-4 — HCPCS code coverage

```sql
-- Outpatient should have a significantly higher HCPCS population than inpatient
SELECT
    COUNT(*)                                           AS total_charge_lines,
    COUNT(CASE WHEN HCPCS_PROCEDURE_CODE IS NOT NULL
               AND HCPCS_PROCEDURE_CODE <> ''
               THEN 1 END)                             AS lines_with_hcpcs,
    ROUND(COUNT(CASE WHEN HCPCS_PROCEDURE_CODE IS NOT NULL
                     AND HCPCS_PROCEDURE_CODE <> ''
                     THEN 1 END) * 100.0 / COUNT(*), 1) AS pct_with_hcpcs
  FROM THCIC.STG_OP_CHARGES
 WHERE YEAR_QUARTER = '2025Q1';
```

**Pass:** HCPCS population rate is meaningfully higher than what you would see in the inpatient charges table. A very low rate (under 20%) may indicate a file format or column alignment problem.

---

### Check OP-5 — PLACE_OF_SERVICE distribution

```sql
SELECT PLACE_OF_SERVICE, COUNT(*) AS encounter_count
  FROM THCIC.STG_OP_BASE
 WHERE YEAR_QUARTER = '2025Q1'
 GROUP BY PLACE_OF_SERVICE
 ORDER BY encounter_count DESC
 LIMIT 20;
```

**Pass:** Distribution looks reasonable. Common values include hospital outpatient department, urgent care, office, etc.

**If all values are NULL or blank:** The `PLACE_OF_SERVICE` field may not be in the outpatient file for your specific data period or the column position in the `COPY INTO` is misaligned. Check against the User Manual.

---

### Check OP-6 — TYPE_OF_BILL pattern check

```sql
-- Outpatient claims should have TYPE_OF_BILL where the 2nd digit is '3' (outpatient)
-- or other non-inpatient care types
SELECT
    SUBSTRING(TYPE_OF_BILL, 2, 1)  AS care_type_digit,
    COUNT(*)                        AS record_count
  FROM THCIC.STG_OP_BASE
 WHERE YEAR_QUARTER = '2025Q1'
 GROUP BY care_type_digit
 ORDER BY record_count DESC;
```

**Pass:** Predominantly care type `3` (outpatient) with some `4`, `5`, `6`, `7` values depending on facility mix.

**Flag:** If you see `1` or `2` (inpatient care types) dominating the results, you may have loaded the inpatient file into the outpatient table by mistake.

---

### Check OP-7 — Cross-dataset provider overlap

```sql
-- Providers in outpatient that also appear in inpatient (expected — most hospitals submit both)
SELECT COUNT(DISTINCT o.THCIC_ID) AS op_providers,
       COUNT(DISTINCT i.THCIC_ID) AS also_in_ip
  FROM (SELECT DISTINCT THCIC_ID FROM THCIC.STG_OP_BASE
         WHERE YEAR_QUARTER = '2025Q1') o
  LEFT JOIN (SELECT DISTINCT THCIC_ID FROM THCIC.STG_IP_BASE1
              WHERE YEAR_QUARTER = '2025Q1') i
    ON o.THCIC_ID = i.THCIC_ID;
```

**Pass:** Most outpatient providers also appear in the inpatient dataset. A very low overlap (< 50%) may indicate a data quality issue or that the two files are from different quarters.

---

## 7. Troubleshooting

### COPY INTO column count mismatch

The outpatient Base file column count may differ from the inpatient Base files. Count the columns in your CSV against the `CREATE TABLE` statement in `07_outpatient_stg_ddl.sql`. If there is a mismatch, update the DDL and re-run before loading.

### Charges file times out during upload

The outpatient Charges file is the largest in the pipeline. Options:
- Split the file into multiple parts before upload: `split -l 5000000 thcic_op_charges_2025_q1.csv chunk_`
- Use gzip compression: Snowflake stage accepts `.csv.gz` and will decompress automatically
- Use an external stage (S3 or Azure Blob) rather than Snowflake internal stage for large files

### PLACE_OF_SERVICE is blank for all records

DSHS may suppress this field for certain provider or patient categories. Review the outpatient User Manual for suppression rules. If the field is simply absent from the file format in older data, note the first available quarter in the Change Log.

### Check OP-6 shows inpatient TYPE_OF_BILL codes

You have either loaded the wrong file or the files for inpatient and outpatient are in the same stage path with ambiguous names. Rename your files using the convention in Section 9 (`thcic_op_` prefix) and re-load.

### Row count is lower than expected

Outpatient facilities have different exemption rules than inpatient. Some facilities that submit inpatient data may not be required to submit outpatient data, or may report under different THCIC IDs. Refer to the DSHS Facility Reporting Status document included with the PUDF for provider-level submission status.

### COPY_HISTORY check for errors

```sql
SELECT * FROM TABLE(INFORMATION_SCHEMA.COPY_HISTORY(
  TABLE_NAME => 'STG_OP_BASE',
  START_TIME => DATEADD(HOURS, -4, CURRENT_TIMESTAMP())
));
```

Review `ROWS_LOADED`, `ROWS_PARSED`, and `ERROR_COUNT`. If errors exist, check the `FIRST_ERROR` column.

---

## 8. YEAR_QUARTER Reference

| Value | Covers | DSHS Release Window |
|-------|--------|---------------------|
| `2025Q1` | Jan 1 – Mar 31, 2025 | ~May–June 2025 |
| `2025Q2` | Apr 1 – Jun 30, 2025 | ~Aug–Sep 2025 |
| `2025Q3` | Jul 1 – Sep 30, 2025 | ~Nov–Dec 2025 |
| `2025Q4` | Oct 1 – Dec 31, 2025 | ~Feb–Mar 2026 |
| `2026Q1` | Jan 1 – Mar 31, 2026 | ~May–June 2026 |

Inpatient and outpatient data for the same quarter are typically released together. Confirm both files carry the same discharge quarter distribution before cross-dataset analysis.

---

## 9. File Naming Convention

Use this naming pattern for downloaded outpatient PUDF files:

```
thcic_op_base_<YEAR>_<Q>.csv
thcic_op_charges_<YEAR>_<Q>.csv
thcic_op_facility_<YEAR>_<Q>.csv
```

Examples for 2025 Q1:
```
thcic_op_base_2025_q1.csv
thcic_op_charges_2025_q1.csv
thcic_op_facility_2025_q1.csv
```

Store downloads in a consistent archive before staging:
```
/archive/thcic/outpatient/2025/q1/
```

**Keep inpatient and outpatient in separate archive directories.** Using `ip` and `op` as prefixes in file names prevents the single most common mistake in this pipeline — loading the wrong file into the wrong table.

---

## 10. Known Outpatient Data Limitations

These are documented by DSHS and should be factored into any analysis.

- **No length of stay.** Outpatient services are billed differently. Use `THROUGH_DATE_SEQ - FROM_DATE_SEQ` as a proxy for visit duration where needed.
- **No DRG.** Outpatient encounters are not grouped by DRG. Procedure-based analysis should use HCPCS codes and Revenue Codes instead.
- **HCPCS codes are billable claims data, not clinical data.** The same caveats that apply to ICD-10 codes in inpatient apply to HCPCS in outpatient — they reflect what was billed, not necessarily the complete clinical picture.
- **Multiple revenue code lines per visit.** A single outpatient encounter in `STG_OP_BASE` will typically have many more charge lines in `STG_OP_CHARGES` than an inpatient encounter. Aggregating charges requires joining on `RECORD_ID + YEAR_QUARTER`.
- **Suppression rules are the same as inpatient.** Patient ZIP, county, race, ethnicity, and provider identity suppression applies identically.
- **Outpatient exempt facilities.** Some facilities exempt from inpatient reporting may also be exempt from outpatient reporting. Others may report outpatient only. Check the DSHS Facility Reporting Status document.
- **Statement dates are offset, not actual dates.** `FROM_DATE_SEQ` and `THROUGH_DATE_SEQ` are relative offsets from a reference date, not actual calendar dates. Actual dates are excluded from the PUDF for confidentiality.

---

## 11. Change Log

| Quarter | Changed By | Notes |
|---------|-----------|-------|
| 2025Q1 | *(your name)* | Initial outpatient pipeline setup. Tables constructed from THCIC Outpatient PUDF structure. Verify against current User Manual before first production load. |
| | | |

---

*End of outpatient runbook. For coding scheme lookup questions, refer to the shared `LKP_*` tables and the Inpatient Runbook Sections 6–7 which cover the promotion logic.*
