# Cortex Code Hands-On Lab — Facilitator Q&A

A reference for fielding attendee questions during the SnowPrism lab. Answers reflect Cortex Code (CoCo) as of mid-2026. Items marked **[verify]** change fast or depend on your account — confirm against current Snowflake docs or your environment before stating them as fact in the room.

---

## 1. Setup and prerequisites

**Q: What do I need before the lab?**
A Snowflake account, the Cortex Code CLI installed, and a terminal. Your user needs the `SNOWFLAKE.CORTEX_USER` database role, which is granted to `PUBLIC` by default — so most users already have it. If your org uses custom roles that revoke `PUBLIC` grants, ask an admin to grant it. **[verify per account]**

**Q: Anything account-level that can silently block me?**
Two things catch people out. First, Cortex Code requires **cross-region inference enabled** at the account level — your metadata may be processed in a different region than your account is hosted, which matters for data-residency rules (GDPR, localization). Second, availability is limited to **Commercial, FedRAMP (Moderate/High), and KSA sovereign** accounts. If you are on a deployment outside those, it will not run. **[verify per account]**

**Q: How do I connect the CLI?**
Run `cortex` the first time and a setup wizard walks you through it, reusing connections from your `~/.snowflake/connections.toml` if you have the Snowflake CLI already configured.

---

## 2. The interfaces: Snowsight, CLI, VS Code

**Q: What are the ways to run Cortex Code?**
- **Cortex Code in Snowsight** — the in-browser agent inside Workspaces/worksheets. Zero setup, proposes changes in a diff view. Best for ad-hoc SQL, exploration, admin, FinOps. **GA soon** as of this writing.
- **Cortex Code CLI** — an agentic shell that bridges your local machine and Snowflake. **Generally available.** This is what the lab uses, because it can read and write local files (dbt projects, Streamlit apps) and run git/bash.
- **VS Code extension** (private preview), plus an **MCP server** and **Claude Code plugin** (preview), and **ACP** support for 30+ editors (Zed, JetBrains, Neovim, and more). **[verify — previews move]**

**Q: What's ACP and why does it matter?**
The Agent Client Protocol is an open standard — think of it like the Language Server Protocol, but for agents. It lets any compatible editor embed Cortex Code as a local backend: the editor drives the session, CoCo streams responses, tool calls, and file diffs back. Practical upshot: you are not locked to one IDE.

---

## 3. Cost and credits

**Q: Is it a subscription? How much?**
No flat subscription. The CLI is billed by **token consumption** — credits per million input/output tokens, like other Cortex AI functions. **Snowsight** was free during preview; current Snowflake docs indicate it is billed by token for customers with an existing account, so don't promise "free." **[verify — billing status is actively changing]**

**Q: What actually drives the bill?**
Two layers, and people forget the second:
1. **AI tokens** — the agent's "thinking," metered per million tokens.
2. **Normal Snowflake compute** — every `DESCRIBE`, every query against `ACCOUNT_USAGE`, every `dbt build` runs on your warehouse and bills standard compute/cloud-services credits, separately.

**Q: Biggest lever on token cost?**
**Model choice.** A light model costs a fraction of a credit per million tokens; a premium model (e.g., a top-tier Claude model) can run roughly an order of magnitude higher. Pick the model to fit the task instead of defaulting to the heaviest. There is no pre-execution cost estimate — you see cost *after* a run, which is why model discipline matters.

**Q: How do we cap spend?**
Admins set daily estimated credit limits per user per surface:
```sql
ALTER ACCOUNT SET CORTEX_CODE_CLI_DAILY_EST_CREDIT_LIMIT_PER_USER = 20;
ALTER USER power_user SET CORTEX_CODE_CLI_DAILY_EST_CREDIT_LIMIT_PER_USER = 50;
```
(That `20` is a *daily credit ceiling* example, not a price.) Track actual usage in `SNOWFLAKE.ACCOUNT_USAGE.CORTEX_CODE_CLI_USAGE_HISTORY` and `CORTEX_CODE_SNOWSIGHT_USAGE_HISTORY` — both expose `TOKENS`, `TOKEN_CREDITS`, and per-model breakdowns.

---

## 4. Governance, security, and "you judge"

**Q: Can it touch data I'm not allowed to see?**
No. Cortex Code operates **inside your RBAC** — it can only read or act on objects your role permits. Governance is not bypassed by the agent.

**Q: What stops it doing something destructive?**
It runs with OS-level sandboxing and a **three-tier approval system** with automatic risk assessment — riskier actions require your sign-off before they execute. Use `/plan` before a complex prompt to see the agent's intended steps and approve or deny them first. This is the practical core of "the agent drafts, you decide": review is the job, not an afterthought.

---

## 5. Skills and AGENTS.md (encode once)

**Q: What's the difference between AGENTS.md and a Skill?**
- **AGENTS.md** — the project's constitution. Drop it in a project directory and the agent reads it automatically every session: naming conventions, materialization rules, doc formats. Always-on, project-scoped.
- **SKILL.md** — a reusable, on-demand capability (a folder with a `SKILL.md`: metadata plus instructions, optionally `scripts/`, `references/`, `assets/`). Loaded only when a task matches its description ("progressive disclosure"), so it doesn't bloat context.

One-liner: **AGENTS.md sets the rules of the road; Skills are tools you reach for.**

**Q: Are Skills locked to Cortex Code?**
No. `SKILL.md` follows the open Agent Skills standard (agentskills.io, released Dec 18, 2025). The same skill format is adopted across coding tools — Microsoft (VS Code, GitHub), OpenAI, Cursor, and others — so a skill you write for CoCo travels to other agents. That is the whole point of "encode once."

**Q: Will we build a custom Skill in the lab?**
Not today — custom Skill authoring is a deeper topic. The lab uses AGENTS.md for project rules and a semantic view for meaning. Custom Skills are the natural next step afterward.

---

## 6. How is this different from Copilot / Claude Code / Databricks?

**Q: Isn't this just Copilot for SQL?**
No. GitHub Copilot is a general-purpose code-completion assistant — strong across languages, but blind to your data platform. Cortex Code is **Snowflake-aware**: it reads your schemas, RBAC, query history, and metadata, so it suggests real object names and dialect-correct SQL instead of hallucinating tables. Different category: completion vs. a governed agent that acts in your environment.

**Q: Is Cortex Code built on Claude?**
Yes — it's built on Anthropic's Claude, extended with Snowflake-native tools (SQL execution, catalog awareness, governance). So the four principles in the preamble are not Snowflake-specific trivia; they transfer to any Claude-based agent.

**Q: How does it compare to Databricks' assistant?**
Both are context-aware platform agents. Databricks' assistant is deeply tied to Unity Catalog metadata and lives in notebooks/SQL editor; Cortex Code is tied to the Snowflake catalog and RBAC and spans Snowsight, CLI, and IDEs. The method we're teaching — give context, encode once, you judge, know the edges — applies to either. **[verify exact Databricks feature names before quoting them]**

---

## 7. Debugging and common issues

**Q: The agent did something I didn't expect.**
Use `/plan` to preview steps before execution. Rephrase the prompt to be more specific. If your `AGENTS.md` is sprawling, trim it — too many rules dilute compliance.

**Q: I get a model-access error.**
The underlying models may not be enabled for your account. An admin may need to adjust the account's model allowlist. **[verify the exact parameter/command for your account]**

**Q: It's behaving oddly mid-session.**
Remember there's **no memory between sessions** — context resets when you close it. Re-establish what matters at the start of each session. Skills inject static context; they don't restore continuity. Run `cortex update` to rule out a stale version, and use `!` for shell and `/sql` to run SQL directly when isolating a problem.

---

## 8. Scope and limits

**Q: What can we realistically finish in 60 minutes of lab?**
Build a credit-visibility layer over seeded usage data (R1 — give the agent context), then a semantic view that maps your words to the model and answer plain-English questions (R2 — encode meaning). That's principles 1 and 2, made concrete. Principles 3 and 4 — you judge, know the edges — you'll *live* the moment you start reviewing what CoCo generates.

**Q: What are the honest limits to call out?**
No cross-session memory. No pre-run cost estimate. It's reactive — it does not monitor your environment for you. Large schemas can exceed context limits, so scope prompts to the relevant objects. Always validate performance suggestions before trusting them. None of this is a reason not to use it; all of it is a reason to set it up deliberately.

---

## 9. The method (why we spent 10 minutes before the keyboard)

**Q: Why the preamble — can't we just start prompting?**
You can, and that's the trap. An agent will generate a thousand lines from a vague prompt, and it looks finished. The cost shows up later, as code you didn't design, didn't write, and can't maintain. The four principles — context, encode once, you judge, know the edges — are what separate using the agent from being used by it. Over 50% of Snowflake customers already use Cortex Code; the differentiator now is not access to the tool, it's method.

---

*Sources: Snowflake Cortex Code documentation (docs.snowflake.com), Snowflake product announcements (April 2026), and the Agent Skills open standard (agentskills.io, Dec 2025). Verify version-specific and account-specific details against current docs before presenting.*
