# Agile Capacity Pilot — Discovery & Scoping Workshop
**Date:** April 9, 2026 | **Duration:** 3 Hours | **Facilitator:** Deloitte
**Confidential — For Discussion Purposes Only**

---

## Workshop Objectives

By the end of this session, we will have:

1. Confirmed and bounded the pilot scope
2. Answered the critical open questions needed to begin Phase 1
3. Defined success criteria, KPIs, and effectiveness tracking approach
4. Identified all stakeholders needed during the pilot phases
5. Agreed on Week 0 pre-kick-off requirements and owners

---

## Agenda

| Time | Block | Owner |
|------|-------|-------|
| 0:00–0:15 | Welcome, introductions, objectives | Deloitte |
| 0:15–0:45 | Block 1: Scope Confirmation | All |
| 0:45–1:15 | Block 2: No-Show Model & Epic Clarity Data | IS / Analytics |
| 1:15–1:45 | Block 3: Operations & Capacity Management Workflow | Capacity Mgmt |
| 1:45–2:10 | Block 4: Governance, PHI & Clinical Oversight | IS / Clinical |
| 2:10–2:40 | Block 5: Success Criteria, KPIs & Effectiveness Tracking | All |
| 2:40–3:00 | Block 6: Week 0 Checklist & Next Steps | All |

---

## Block 1: Scope Confirmation (30 min)

### Purpose
Ensure everyone in the room has a shared understanding of what we are — and are not — building across the 8 weeks.

### Framing Statement *(Read Aloud)*
> *"This engagement has four phases. Phase 1 (Weeks 1–2) is Discovery & Design — we lock scope, document requirements, and define architecture. Phase 2 (Weeks 3–5) is Build & Integration — we replicate the required Epic Clarity tables into Snowflake and build the no-show scoring and recommendation layer. Phase 3 (Weeks 6–7) is Pilot Deployment — a small group of Capacity Management users work with real recommendations and we track outcomes. Phase 4 (Week 8) is Iterate & Scale Planning — we incorporate feedback, produce a runbook, and define the scaling roadmap. Epic Clarity replication runs concurrently across the full engagement. The Capacity Management team will review recommendations and make slot adjustments manually in Epic during the pilot — the system does not write back to Epic."*

### Discussion Questions

**1.1** Does everyone in the room agree with this framing? Are there any expectations that need to be reset before we proceed?

**1.2** The pilot scope has been proposed as **ambulatory pediatric medicine and surgery, starting with surgical return visits.** Is this confirmed by all stakeholders? Are there additional specialties that should be considered from the outset?

**1.3** Confirm: the pilot covers **return patient slots only** (not new patient slots). Is that agreed by operations?

**1.4** Are there any blackout periods, organizational events, or resource constraints across the 8-week window that could affect delivery or stakeholder availability?

**1.5** What is the anticipated start date for Week 1?

---

## Block 2: No-Show Model & Epic Clarity Data (30 min)

### Purpose
Understand the existing no-show model and confirm Epic Clarity data availability. These answers directly determine the Phase 2 build approach.

### No-Show Model Questions

**2.1** Where does the no-show probability model currently live?
- ☐ Built into Epic (Epic's native predictive model — score is a column in Clarity)
- ☐ Separate platform (e.g. Azure ML, Python/R, other)
- ☐ SQL / rules-based logic in an existing data warehouse
- ☐ Other: _______________

> *This is the most critical answer of the day. The Phase 2 build path changes materially depending on the answer. Per prior discussions, the model is understood to be built in Microsoft Azure and feeds Epic with encounter-level scores and risk tiers — please confirm this is current and accurate.*

**2.2** What does the model output?
- ☐ Probability score (0–1 or 1–100)
- ☐ Risk tier only (High / Medium / Low)
- ☐ Both score and tier
- ☐ Other: _______________

**2.3** Is the model currently running in production and feeding Epic today?

**2.4** Who owns the model — and who can provide access, documentation, and technical details before Phase 1 ends? *(Name + contact)*

**2.5** The agreed approach is for Snowflake to **consume model outputs only** — no retraining or rebuilding of the model. Is this confirmed by all stakeholders?

**2.6** How do the model output scores flow from the model into Epic today? And how will those outputs be made available to Snowflake?
- ☐ Scores are written back to Epic Clarity — IDMC replicates them as part of the Clarity data pull
- ☐ Direct connection from the model platform (e.g. Azure ML) to Snowflake
- ☐ Scores staged to an intermediate file/storage location and loaded into Snowflake
- ☐ Other / unknown — needs investigation: _______________

**2.7** What features does the model use? *(Confirm all that apply)*
- ☐ Prior no-show history
- ☐ Lead time (days between booking and appointment)
- ☐ Day of week / time of day
- ☐ Specialty / department
- ☐ Insurance / payer
- ☐ Distance to clinic
- ☐ Demographics (age, etc.)
- ☐ Other: _______________

**2.8** Has model accuracy been formally validated? Is there a known AUC, precision, or recall at the current risk thresholds?

### Epic Clarity Data Questions

**2.9** Is the data scope **Clarity** (reporting layer), **Caboodle** (data warehouse), or both? Has this been confirmed with the Epic team?

**2.10** How many years of appointment history are available in Clarity? *(Minimum 12 months required; 24 months preferred for seasonal patterns)*

**2.11** Is no-show status reliably recorded in Clarity? What statuses exist — No Show, Cancelled, Left Without Being Seen? Are cancellations clearly distinguished from no-shows?

**2.12** Is new vs. return visit type a reliable, consistently populated field in Clarity?

**2.13** Who is the Clarity DBA or reporting analyst who can confirm table availability and column population rates before Phase 1 ends? *(Name + contact required)*

**2.14** The following tables have been identified as a **starting point** for the data model. The actual required table list needs to be confirmed and validated by IS and the Clarity DBA during Phase 1. Please review and indicate availability, flag any tables that are not applicable, and identify any additional tables that should be included.

| # | Table | Purpose | Available? | Notes / Additional Tables |
|---|-------|---------|------------|--------------------------|
| 1 | PAT_ENC | Core appointment record — patient, provider, department, date, type | ☐ | |
| 2 | PAT_ENC_2 | Extended appointment attributes — slot duration, visit type flags | ☐ | |
| 3 | ZC_APPT_STATUS | Status code lookup — no-show, completed, cancelled, LWBS | ☐ | |
| 4 | CLARITY_DEP | Department / specialty lookup | ☐ | |
| 5 | CLARITY_SER | Provider lookup | ☐ | |
| 6 | SCHED_APPT | Scheduled slot details — capacity, overbooking flags | ☐ | |
| 7 | PATIENT | Demographics — age, distance proxy (model features) | ☐ | |
| 8 | PAT_ADDRESS | Patient address — distance-to-clinic features | ☐ | |
| 9 | COVERAGE | Insurance / payer — no-show predictor | ☐ | |
| 10 | PAT_ENC_HSP | Inpatient encounters — historical risk features | ☐ | |
| | *Additional tables identified by IS / Clarity DBA:* | | | |
| | | | ☐ | |
| | | | ☐ | |
| | | | ☐ | |

> **Action item:** IS and the Clarity DBA to provide the confirmed, validated table list before the end of Phase 1. This list gates the IDMC replication configuration and the Phase 2 data pipeline build.

---

## Block 3: Operations & Capacity Management Workflow (30 min)

### Purpose
Understand how the Capacity Management team works today so the pilot dashboard, overbooking guardrails, and recommendation logic are designed around their actual workflow.

**3.1** Walk us through the current process: when a session is identified as likely to have no-shows, what happens today? Who does what, in what system, using what information?

**3.2** Who specifically on the Capacity Management team will be the pilot users? *(2–3 named individuals required before Phase 1 ends — these are the people the Streamlit dashboard is built for)*

| Name | Role | Available for Pilot (Phase 3, Weeks 6–7)? |
|------|------|------------------------------------------|
| | | ☐ |
| | | ☐ |
| | | ☐ |

**3.3** Which specialties should be in scope for the pilot? *(Surgical return visits and ambulatory pediatric medicine have been proposed as starting points — please confirm and identify any additional specialties to include. The list may be longer than two.)*

| Specialty | Approx. No-Show Rate | Operationally Stable? | Engaged Lead? | In Scope? |
|-----------|----------------------|-----------------------|---------------|-----------|
| | | ☐ | ☐ | ☐ |
| | | ☐ | ☐ | ☐ |
| | | ☐ | ☐ | ☐ |
| | | ☐ | ☐ | ☐ |

**3.4** What is the agreed **lead time window** for recommendations? How far in advance should the system flag sessions for potential capacity adjustment?
*(Note: longer lead times may be appropriate depending on specialty scheduling patterns and the team's workflow — please define what works operationally)*

Lead time window: _______________

Rationale / constraints: _______________

**3.5** What is the **maximum number of sessions per day** the Capacity Management team can realistically review and action? *(This sets the throughput ceiling — recommendations will not exceed this number)*

Max sessions per day: _______________

**3.6** What threshold defines a "high-risk session" warranting a recommendation? Is there a threshold already in operational use, or does the pilot need to define one? *(e.g., more than X% of appointments in the session are classified as High risk)*

**3.7** What are the **overbooking guardrails**? Please confirm or define each:

| Guardrail | Proposed Default | Agreed Value |
|-----------|-----------------|--------------|
| Maximum slots overbooked per session | 1 slot (capacity adjusted from 1 → 2) | |
| Maximum sessions overbooked per day | TBD | |
| Maximum sessions overbooked per specialty per day | TBD | |
| Slot types eligible for overbooking | Return patient slots only | |
| Provider or department opt-out | TBD — which providers or departments should be excluded? | |
| Who has authority to override guardrails | TBD | |
| Conditions triggering automatic reversion or pause | TBD (e.g. wait time > X min, both patients arrive) | |

**3.8** How should the system handle **same-day cancellations** in an already-adjusted slot? Is there an existing protocol, or is this a gap to define during the pilot?

**3.9** What operational thresholds would trigger a **reversion or pause** of an adjusted slot?
*(e.g., wait time exceeds X minutes, dual patient arrival rate exceeds Y% of sessions)*

---

## Block 4: Governance, PHI & Clinical Oversight (25 min)

### Purpose
Confirm PHI requirements and clinical governance dependencies before Phase 1 begins. These are gate items — data replication does not begin until they are resolved.

**4.1** Does the Capacity Management team need to see **patient names or MRNs** in the pilot dashboard, or can they work with masked identifiers and session-level data only?

> *This is a gate decision that determines the PHI architecture. If masked identifiers are sufficient, the dashboard operates entirely on Zone 1 data with no raw PHI exposure. If named patient view is required, a controlled, audited access path to patient name and MRN must be architected — which increases PHI exposure and may require additional governance review.*

- ☐ Masked identifiers and session-level data only *(recommended default)*
- ☐ Named patient view required — patient name and/or MRN needed for slot adjustment workflow

**4.2** Is there a **clinical governance or ethics committee** that must review the use of a predictive model in scheduling decisions before the pilot goes live? If yes — who leads it, what does the review require, and what is the realistic turnaround time?

**4.3** Are there **patient populations or appointment types to explicitly exclude** from the model?
- ☐ Mental health / behavioral health
- ☐ Recent inpatient discharge follow-ups
- ☐ Other: _______________

**4.4** Who is the **clinical sponsor** for this use case? Is there a CCIO, CMO, or VP of Access who needs to give formal sign-off before pilot go-live?

**4.5** Are there **model fairness concerns** to address — e.g., ensuring the model does not disproportionately flag patients of certain demographics, insurance types, or zip codes? If yes, who owns that review and what does it require?

**4.6** What **AI ethics guidelines or organizational standards** must the use case be aligned to before deployment? Who owns that review and what is the sign-off process?

**4.7** Confirm: the Snowflake tenant is within the Texas Children's organizational environment. Are there any outstanding items related to environment ownership or data residency?

---

## Block 5: Success Criteria, KPIs & Effectiveness Tracking (30 min)

### Purpose
Define what success looks like in concrete, measurable terms — and establish how we will track the effectiveness of double-booking recommendations over time so parameters can be tuned and financial impact can be quantified.

### Pilot-Level KPIs

Review and agree on targets for each metric:

| Metric | Description | Proposed Target | Agreed Target |
|--------|-------------|-----------------|---------------|
| Recommendation action rate | % of surfaced recommendations approved by Capacity Management | ≥50% | |
| Adjusted sessions | Total sessions with a slot adjustment made during the pilot | ≥15–20 | |
| Slot fill rate | % of adjusted slots where a second patient was successfully booked | TBD | |
| Dual-arrival rate | % of adjusted sessions where both patients arrived simultaneously | Define threshold | |
| Wait time threshold breaches | Sessions exceeding the agreed operational wait time limit | 0 | |
| User adoption | % of pilot users actively using the dashboard by end of Phase 3 | ≥80% | |
| Override rate | % of recommendations overridden with a documented reason | <50% | |
| Provider / operational feedback | Qualitative feedback from pilot specialties | Net positive | |

**5.1** Are there additional KPIs the client sponsor will use to evaluate the pilot outcome?

**5.2** What would a **"do not scale"** outcome look like? What result would definitively indicate the use case should not be expanded?

### No-Show Rate Impact Tracking

**5.3** Is there a **baseline no-show rate** available for the pilot specialties today? Who owns that data and can provide it for Phase 1 comparison?

**5.4** How should no-show rate impact be measured?
- Pre-pilot baseline no-show rate per specialty / session type
- Post-adjustment no-show rate for adjusted sessions vs. non-adjusted sessions (control comparison)
- No-show rate trend over the pilot period

**5.5** What is the minimum detectable improvement in no-show rate that would be considered operationally meaningful?

### Double-Booking Effectiveness Tracking & Parameter Tuning

**5.6** For every adjusted slot, we will track the following outcomes. Please confirm these are the right data points and add any missing:

| Outcome Data Point | Description | Confirmed? |
|--------------------|-------------|------------|
| Was the adjusted slot filled? | Did a second patient get booked into the overbooked slot? | ☐ |
| Did the no-show occur? | Did the originally flagged patient actually no-show? | ☐ |
| Did both patients arrive? | Were both patients present simultaneously? | ☐ |
| Wait time impact | Was there a measurable wait time change in the adjusted session? | ☐ |
| Was the slot reverted? | Was the capacity adjustment reversed before or during the session? | ☐ |
| Override reason | Why did Capacity Management override or defer the recommendation? | ☐ |
| Risk tier at time of recommendation | What was the session risk classification when the recommendation was made? | ☐ |

**5.7** How will override reasons and outcomes be used to **tune recommendation parameters** over time? Who owns that recalibration process — Deloitte during the pilot, or IS/Analytics post-pilot?

**5.8** What parameters should be tunable based on pilot feedback?
- ☐ Risk score threshold for session flagging
- ☐ Lead time window
- ☐ Maximum slots per session
- ☐ Specialty-level thresholds (different settings per specialty)
- ☐ Other: _______________

### Financial Impact Tracking

**5.9** What is the **average net revenue per completed visit** for the pilot specialties? *(Needed to calculate the financial value of converted no-show slots)*

| Specialty | Avg. Net Revenue per Completed Visit | Source / Owner |
|-----------|--------------------------------------|----------------|
| | | |
| | | |

**5.10** How should financial impact be calculated and reported?

- Incremental completed visits = adjusted slots that filled AND the original patient no-showed
- Financial value = incremental completed visits × average net revenue per visit
- Avoided lost revenue = no-show slots that would have gone unfilled without the intervention

**5.11** Who owns financial impact reporting — Operations, Finance, or IS? Who needs to receive it and at what cadence?

**5.12** Should financial impact tracking be included in the Phase 3 pilot dashboard, or reported separately to leadership?
- ☐ Include in pilot dashboard (visible to Capacity Management and steering)
- ☐ Separate leadership report only
- ☐ Both

### Pilot Audience & Access

**5.13** Beyond the named Capacity Management users, who else needs access to pilot outputs?

| Role | Name | Access Level | Purpose |
|------|------|-------------|---------|
| Clinical sponsor | | Read-only | Steering oversight |
| IS / Data architect | | Full | Technical validation |
| Operations lead | | Read-only | Feedback & sign-off |
| Finance *(if tracking financial impact)* | | Read-only | Financial reporting |
| Other | | | |

---

## Block 6: Week 0 Checklist & Next Steps (20 min)

### Purpose
Define everything that must be in place before Week 1 begins. Assign an owner and due date to each item before leaving the room.

### Week 0 — Pre-Kick-Off Checklist

#### Snowflake Environment & Access

| Item | Owner | Due Date | Done? |
|------|-------|----------|-------|
| Snowflake environment provisioned (two-zone PHI architecture: Zone 0 raw PHI + Zone 1 masked analytics) | IS | | ☐ |
| Databases and schemas created (CAPACITY_PILOT_RAW and CAPACITY_PILOT) | IS / PILOT_ADMIN | | ☐ |
| RBAC roles created and grants configured (PILOT_ADMIN, PILOT_DATA_ENGINEER, IDMC_SERVICE_ROLE, PILOT_ANALYST, PILOT_DASHBOARD_USER, PILOT_READONLY) | IS / PILOT_ADMIN | | ☐ |
| Warehouses created with resource monitors (PILOT_ETL_WH — Medium; PILOT_ANALYST_WH — Small) | IS / PILOT_ADMIN | | ☐ |
| Deloitte team Snowflake user accounts provisioned with PILOT_DATA_ENGINEER role | IS | | ☐ |
| Snowflake Cortex enabled in the environment | IS | | ☐ |
| IDMC service account created and connector configured | IS + Deloitte | | ☐ |
| IDMC connectivity tested — end-to-end test write to staging schema confirmed | IS + Deloitte | | ☐ |

#### Initial Data Load

| Item | Owner | Due Date | Done? |
|------|-------|----------|-------|
| One-time initial load of Epic Clarity data completed into Zone 0 (EPIC_STAGING → EPIC_CLARITY) to support Phase 2 build | IS + Deloitte | | ☐ |
| Initial load validated — row counts, date ranges, and key fields spot-checked | IS / Clarity DBA | | ☐ |
| Incremental replication cadence defined and scheduled (concurrent across Weeks 1–8) | IS + Deloitte | | ☐ |

#### PHI & Data Governance

| Item | Owner | Due Date | Done? |
|------|-------|----------|-------|
| PHI/PII classification sprint completed (Cortex SYSTEM$CLASSIFY run against Epic Clarity sample) | Deloitte + IS | | ☐ |
| Masking policies drafted for all Zone 0 PHI columns | Deloitte + IS | | ☐ |
| Masking policies deployed and validated before any replication runs *(hard gate — replication does not begin until complete)* | Deloitte + IS | | ☐ |
| Named vs. masked patient view decision confirmed (Block 4, Q4.1) | Operations / IS | | ☐ |

#### Epic Clarity & No-Show Model

| Item | Owner | Due Date | Done? |
|------|-------|----------|-------|
| Clarity DBA / reporting analyst identified and engaged | IS | | ☐ |
| Confirmed Epic Clarity table list provided by IS / Clarity DBA (starting point table list reviewed and validated) | IS / Clarity DBA | | ☐ |
| No-show model owner identified; model documentation and output specifications shared with Deloitte | Analytics / IS | | ☐ |
| Model output ingestion path into Snowflake confirmed (Clarity replication, direct connection, or staged load) | Analytics / IS + Deloitte | | ☐ |

#### Stakeholders & Governance

| Item | Owner | Due Date | Done? |
|------|-------|----------|-------|
| Clinical sponsor formally identified and briefed | Operations / CCIO | | ☐ |
| Clinical governance / AI ethics review process confirmed — required or not required, and timeline if required | IS / Clinical | | ☐ |
| Capacity Management pilot users named (2–3 individuals) — Block 3, Q3.2 | Grace / Natalie | | ☐ |
| Pilot specialties confirmed and specialty leads identified | Operations | | ☐ |
| Patient population exclusion list agreed — Block 4, Q4.3 | Clinical / Operations | | ☐ |
| Baseline no-show rate data sourced for pilot specialties | IS / Analytics | | ☐ |
| Average net revenue per visit confirmed for pilot specialties (for financial impact tracking) | Finance / Operations | | ☐ |

#### Meeting Cadence & Planning

| Item | Owner | Due Date | Done? |
|------|-------|----------|-------|
| Phase 1 kick-off meeting scheduled | PM | | ☐ |
| Weekly steering meeting cadence agreed (day / time / attendees) | PM | | ☐ |
| End of Phase 2 internal demo scheduled | PM | | ☐ |
| End of Phase 3 pilot review and survey scheduled | PM | | ☐ |
| Phase 4 steering / scaling decision presentation scheduled | PM | | ☐ |
| Deloitte detailed question list distributed to IS and Operations | Deloitte | EOD today | ☐ |

---

## Stakeholder Map — Pilot Engagement

| Phase | Stakeholder | Role | Engagement Type |
|-------|-------------|------|-----------------|
| All phases | Ashok Kurian (VP, IS) | Executive sponsor, IS | Steering meetings |
| All phases | Paige Schultz (VP, System Access) | Executive sponsor, Operations | Steering meetings |
| All phases | Dr. Robert Ball (CCIO) | Clinical oversight & governance sign-off | Governance gate; steering |
| Ph. 1–2 | Sridhar Sunku (Data Architect, IS) | Technical architecture, Epic/Snowflake | Weekly working sessions |
| Ph. 1–2 | Clarity DBA *(to be named)* | Epic Clarity table access & validation | Phase 1 data confirmation |
| Ph. 1–2 | Rupesh Dandekar (Deloitte, AI Lead) | Build lead | Daily |
| Ph. 3–4 | Grace Fangman (Dir., Strategic Access Ops) | Operational lead, Capacity Mgmt owner | Weekly + pilot daily |
| Ph. 3–4 | Natalie Chipinski (PM, Strategic Access Ops) | Pilot coordination, feedback collection | Daily during Phase 3 |
| Ph. 3 | Capacity Mgmt users *(to be named — Block 3, Q3.2)* | Dashboard users, recommendation reviewers | Daily during Phase 3 |
| Ph. 3 | Pilot specialty leads *(per confirmed specialty list)* | Clinical feedback, wait time monitoring | Weekly check-in |
| Ph. 3–4 | Finance representative *(to be named)* | Financial impact tracking and reporting | Phase 3 reporting cadence |
| Ph. 4 | All steering members | Scaling decision | Phase 4 steering |

---

## Decisions Log

*Record explicit decisions agreed in the session:*

| # | Decision | Agreed By |
|---|----------|-----------|
| 1 | Pilot specialties confirmed | |
| 2 | Lead time window for recommendations | |
| 3 | Max sessions per day (throughput ceiling) | |
| 4 | Overbooking guardrails confirmed (slots per session, sessions per day, opt-outs) | |
| 5 | Masked vs. named patient view in pilot dashboard | |
| 6 | Clinical governance review: required / not required before go-live | |
| 7 | AI ethics review: required / not required, and owner | |
| 8 | Capacity Management pilot users confirmed | |
| 9 | No-show model form, output format, and ownership confirmed | |
| 10 | Model output ingestion path into Snowflake confirmed | |
| 11 | Confirmed Epic Clarity table list — owner and due date agreed | |
| 12 | Baseline no-show data source confirmed | |
| 13 | KPI targets agreed | |
| 14 | Financial impact tracking approach and ownership confirmed | |

---

## Open Items Log

*Capture items raised during the session requiring follow-up:*

| # | Open Item | Owner | Due Date |
|---|-----------|-------|----------|
| 1 | | | |
| 2 | | | |
| 3 | | | |
| 4 | | | |
| 5 | | | |

---

*Prepared by Deloitte | Confidential — For Discussion Purposes Only | April 2026*
