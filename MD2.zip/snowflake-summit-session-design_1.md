# Snowflake Summit — Cortex Code Hands-On Lab
## Full Session Design (v2)

*Companion to the Opening Briefing. This document covers everything that happens after the open, plus the lab design built specifically against the engagement problem you have observed.*

**Updated:** Cisco / Teradata case study now uses anonymized real engagement details. CLI vs Snowsight UI, custom SKILLs, and Claude Code transferability are woven into the demos, case study, and wrap rather than treated as separate beats.

---

## Section 1 — Session Architecture

### Total length

I am designing for **90 minutes** because that is the typical Snowflake Summit hands-on lab slot. If the actual slot is 60 minutes or 120 minutes, the lab portion compresses or expands. **Flag for me** if the actual length is different and I will reshape.

### The five-act structure

| Act | What happens | Length | Energy |
|---|---|---|---|
| 1. Opening | The "vibe vs structured" frame | 12 min | Set the tone |
| 2. Demos | Two demos of real artifacts | 14 min | Curiosity |
| 3. Case study | Cisco / Teradata anonymized story + DDA 3.0 framing | 9 min | Credibility |
| 4. Hands-on lab | The engagement-heavy exercise | 46 min | Doing |
| 5. Wrap | Claude Code transferability + closing + Q&A + DDA 3.0 take-home + handout | 9 min | Synthesis |

### Why this order

The previous version went: opening → straight to lab. That works for a short slot but skips the credibility-building that earns the audience's commitment to a long lab. The demos and case study buy you the lab. They are not filler. They are the part that makes participants commit to the doing.

The structure also gives natural energy management. Acts 1 and 3 are talking-heavy. Acts 2 and 4 are doing-heavy. Act 5 is reflection. The rhythm matters more than the content for sustained attention.

### How the three new threads run through the session

You wanted to cover Cortex Code CLI vs Snowsight UI, custom SKILLs, and Claude Code transferability. Plus you want Deloitte Data Assist 3.0 visible as the framework underneath everything. These do not get their own beats. They get woven through the existing structure.

| Thread | Where it lands |
|---|---|
| Cortex Code CLI is more powerful than Snowsight UI | Briefly in Demo 1 intro; reinforced in case study |
| Custom SKILLs (CLI-only) are the productized IP layer | Demo 2 intro names it; case study makes it the headline (dbt Model Optimizer) |
| What transfers from Claude Code to Cortex Code | Wrap-up, dedicated 60-90 second beat before closing line |
| Deloitte Data Assist 3.0 as the framework underneath | Light tag in Demo 1; full naming at the start of the case study; one-line take-home in wrap; reference on the handout |

Woven works better than separated because the Cisco case study is the proof of all of these. Forcing them into their own slots makes you sound like a product brief. Letting them ride the case study makes you sound like a practitioner.

---

## Section 2 — Time Budget (Minute-by-Minute)

| Minute | Beat | Notes |
|---|---|---|
| 0-12 | Opening (talking points from briefing) | End with bridge to demos |
| 12-19 | Demo 1: Snowflake env auto-provisioning agent | 7 min, includes 30-sec CLI context + DDA 3.0 tag |
| 19-26 | Demo 2: Natural language PowerPoint agent | 7 min, includes 30-sec SKILL context |
| 26-35 | Case study: Cisco / Teradata migration | 9 min — 1 min DDA 3.0 framing + 8 min story |
| 35-39 | Lab setup: explain exercise, pair up | 4 min |
| 39-44 | Lab Round 1: Vibe coding attempt | 5 min, individual |
| 44-47 | Pause and reflect: what went wrong | 3 min, room discussion |
| 47-54 | Constitution writing: no coding allowed | 7 min, individual then pair check |
| 54-67 | Lab Round 2: Spec-driven attempt | 13 min, pair work |
| 67-72 | The "change one line" reveal | 5 min, facilitator-driven |
| 72-79 | Compare and share: 2-3 outputs to the room | 7 min |
| 79-81 | Claude Code transferability beat | 2 min |
| 81-86 | Q&A | 5 min |
| 86-90 | Closing + DDA 3.0 take-home + handout | 4 min |

Total: 90 minutes.

**Where the budget gets tight:** Lab Round 2 (14 min) is the section most likely to overrun. If you see pairs still working at minute 65, give a one-minute warning. If at minute 67 they are still going, sacrifice the Q&A, not the reveal. The reveal is where the lesson lands.

---

## Section 3 — The Demos

### Demo discipline (read this twice)

Two principles that override everything else.

**Each demo is 6-7 minutes. Not 10. Not 12.** A demo that runs long kills lab energy. Pre-rehearse with a stopwatch. Pre-stage the artifacts you need so nothing depends on a live load.

**Show the artifact, not the agent typing.** Participants do not need to watch Cortex Code work. They have seen agents work. Show them the spec that produced the agent. Show the SKILL. Show the resulting behavior. The agent's typing is the boring part.

### Demo 1: Snowflake Environment Auto-Provisioning Agent

**Why this demo first:** Most Snowflake-flavored example you have. The audience is invested in Snowflake operations. This earns trust quickly.

**Open with a 30-second context-setter (this is the CLI moment):**

> "Quick context before I show you this. What you are about to see runs on the Cortex Code CLI, not the Snowsight UI version. The CLI is more capable. Most importantly, the CLI is where custom SKILLs work. The Snowsight version is a great starting point. The CLI is where the productive work happens. The rest of what I show you today, including the client engagement after this, all runs in the CLI."

> "One more piece of context. The agents I am about to show you, and the migration factory I will walk you through in the case study, all sit under Deloitte Data Assist 3.0, our agentic AI framework. I will say more about DDA 3.0 when we get there. For now, just know it is the umbrella for everything you are about to see."

Then proceed with the demo.

**What to show, in order:**

1. The Constitution (~30 seconds). Show the markdown file that defines the agent's mission, the environment standards it enforces, the governance rules baked in.
2. A single feature spec (~30 seconds). For example, "provision a development environment with PII masking applied by default."
3. The agent running (~2 minutes). Actually invoke it, show it asking for a confirmation, show it creating the environment.
4. The resulting Snowflake account (~1.5 minutes). Show RBAC, tags, masking policies all in place from a single invocation.
5. The take-home (~30 seconds). "This Constitution travels. Same approach, different environment definitions, same SKILL."

**What to say:** "What you are seeing is not the agent's intelligence. It is the Constitution's clarity. If the Constitution is good, the agent is reliable. If the Constitution is sloppy, the agent is creative in ways you do not want."

**What NOT to do:** Do not narrate every step of the agent's work. Talk over the agent. The agent's work is background, the spec is foreground.

### Demo 2: Natural Language PowerPoint Agent

**Why this demo second:** It is the "wait, you can do that?" demo. Different domain than data engineering, which broadens audience trust. It lands the Pattern 3 message from the open ("spec captures judgment, code is disposable").

**Open with a 30-second context-setter (this is the SKILL moment):**

> "This demo is driven by a custom SKILL. SKILLs are how you encode the patterns and judgment we have been talking about into something the agent can invoke. A SKILL is a folder. It has a short description telling the agent when to use it, and a set of instructions, references, and code the agent reaches for when invoked. SKILLs are how Spec-Driven Development moves from a discipline to a library. They are also, importantly, only available in the CLI version of Cortex Code."

Then proceed with the demo.

**What to show, in order:**

1. The judgment in the SKILL (~1 minute). Show the SKILL file where you encoded which slide templates to use when, what makes a slide "too dense," how to break a thought across slides. This is the meat.
2. A prompt to the agent (~30 seconds). Something like "Generate a 5-slide deck explaining the Q3 financial results, for an executive audience."
3. The output (~2 minutes). Flip through the resulting slides. They will be visibly competent. Expect an audible reaction.
4. Now change the audience (~1.5 minutes). Change "executive audience" to "technical team." Same prompt otherwise. Show the different deck. Same data, different judgment applied.
5. The take-home (~30 seconds). "The SKILL encoded the judgment. The agent applied it. If we had put this judgment in prompts, we would be re-prompting forever. The SKILL is the durable artifact."

**Watch for:** This is your high-engagement demo. People will ask "can it do X?" Stay disciplined on time. "Let's hold that for Q&A" is your friend.

### What you should NOT demo

A complex agent (for example, the Sensitive Data Governance SKILL) that requires too much context to appreciate. Save it for Q&A. Demos should be obvious in their value within thirty seconds.

---

## Section 4 — The Cisco / Teradata Case Study (Anonymized)

### Why this story belongs in the session

It is the only beat that shows multi-tool agentic workflow at real client scale. Migrations are a hot Snowflake topic. Teradata customers are the audience the Snowflake field team most wants to convert. This story does triple duty: credibility, Snowflake relevance, and proof that SDD scales to industrial migrations.

It is also the story where your "spec captures judgment" claim becomes irrefutable. The dbt Model Optimizer SKILL you built encodes years of dbt-on-Snowflake judgment, classifies every change by risk, and operates at scale. That is the entire SDD thesis lived.

### What this case study really shows

Three things, in this order.

1. **An AI-powered migration factory is possible.** Not theoretical, not roadmap. Done. Production-ready dbt code, delivered.
2. **The leverage came from a custom SKILL, not the agent's raw intelligence.** The dbt Model Optimizer SKILL was the engine.
3. **The trust came from classified outputs, not blind acceptance.** SAFE / REVIEW / REQUIRES APPROVAL kept humans in the loop where humans need to be.

### The 9-minute story arc (8 minutes of story + 1 minute of DDA 3.0 framing)

(Practice with a stopwatch. First-time tellings of detailed migration stories always overrun.)

**Minute 0 (the framing moment, 60 seconds) — What DDA 3.0 actually is.**

Before the story, name the framework underneath. This is the prominent DDA 3.0 moment in the session.

> "Before I tell you the engagement story, let me name the framework underneath. Deloitte Data Assist 3.0 is our agentic AI framework. Underneath it sits a multi-agent architecture purpose-built for enterprise data modernization."

[If you have the Solution Backbone slide on screen, gesture to it here.]

> "A Reverse Engineering Agent decodes legacy codebases. A Consolidation Agent modernizes the code. A Data Model Mapping Agent maps to the target data model. Snowflake's SnowConvert AI handles the final code generation. And running across all of them, a Documentation Agent captures the evidence trail in markdown."

> "On top of this architecture, we build custom SKILLs that codify the specific patterns each client cares about. The dbt Model Optimizer SKILL you are about to hear about is one of those. Everything I am about to walk you through is DDA 3.0 in production."

Then proceed with the story. The audience now knows DDA 3.0 is real, specific, and architectural — not a marketing label. They do not need it repeated.

**Minute 1 — The situation.**

> "A large enterprise technology company. Mission-critical Teradata estate. Years of Informatica ETL on top. Aggressive timeline pressure from their Chief AI Officer. Traditional estimate for this work was nine months. The deadline was tighter than that, with a Teradata contract renewal in December that was the real driver. The gap was real and expensive."

Do not name Cisco. Even if the audience guesses, do not confirm. "A large enterprise technology company" is the phrasing.

**Minute 2 — Why traditional migration would not work.**

> "The traditional approach is a large team, deep SME interviews, manual code review, slow handoffs. Even with strong code-generation tooling, generation alone is not enough. The output needs to be production-ready, idiomatic, and ownable by the client's team after we leave. That requires more than just generation."

> "It requires reverse engineering of the legacy estate, consolidation of the modernized code, model mapping against the new target, optimization for the platform, and a complete audit trail. That is the gap the Data Assist plus SnowConvert architecture closes."

**Minutes 3-4 — The architecture in action.**

> "What made this engagement different was not throwing an agent at the migration. It was applying the full Data Assist plus SnowConvert architecture I just showed you."

[If using the Solution Backbone slide, walk through each agent as you name it.]

> "The Reverse Engineering Agent decoded the legacy Informatica mappings and the SQL Server estate behind them. Pulled the structure. Generated a current-state analysis. Produced a source-to-target mapping the rest of the pipeline could consume."

> "The Consolidation Agent took that current state and modernized the code through three sub-stages: analyze, plan, consolidate. The output was a cleaner intermediate form that was ready for mapping."

> "The Data Model Mapping Agent mapped the consolidated code against the target Snowflake data model. Suggested old-versus-new mappings. Rewrote the code to fit the new model."

> "SnowConvert AI handled the final code generation into the client's Snowflake environment."

> "And running across all of this, the Documentation Agent captured the evidence trail. Every decision, every recommendation, every change — in markdown."

> "On top of that architecture, we built a custom SKILL specifically for this engagement: the dbt Model Optimizer. The SKILL polished every model the pipeline produced across six dimensions."

[Pause. List them deliberately.]

> "Dialect cleanup. Code quality. Snowflake-native pattern adoption, things like QUALIFY and FLATTEN that the Teradata source did not have. Testing coverage. SQL performance. And cost optimization."

> "Six dimensions, applied systematically to every model. That SKILL is what produced production-ready dbt code, not just transpiled SQL."

**Minute 5 — The governance mechanism (this is the bit they remember).**

> "The SKILL did not just make changes. It classified them."

> "SAFE meant the change was deterministic and reviewable in batch. REVIEW meant it needed a human eye but was likely fine. REQUIRES APPROVAL meant a human had to make the call before the change shipped."

> "This is the bit I want you to remember from this whole session. The trust did not come from believing the agent was right. The trust came from the agent being explicit about its own confidence and letting humans grade the work where it mattered. If you are an enterprise architect worried about agentic risk, that classification pattern is the answer. Adopt it tomorrow."

**Minute 6 — The result.**

> "The traditional nine-month timeline compressed to three months. February to May 2026. Sixty-seven percent compression. Eight figures in cost avoidance, primarily by completing ahead of the renewal window."

> "More importantly, what the client received was production-quality dbt code their team could own and evolve. Not transpiled output that would have to be rewritten in two years. The migration was the deliverable. The dbt codebase was the asset."

The specific numbers here are documented in client-approved materials. They are stage-safe. Use them.

**Minute 7 — The Snowflake-specific lesson.**

> "Two things mattered for Snowflake specifically."

> "First, Cortex Code CLI ran inside the client's Snowflake account. The governance the agent had to respect was the client's Snowflake governance, already enforced. The spec did not have to invent any of that. RBAC, masking policies, tag-based controls — all of it inherited."

> "Second, the dbt Model Optimizer SKILL knew how to use Snowflake-native patterns the source platform did not have. QUALIFY instead of nested subqueries. FLATTEN instead of UDF gymnastics. The agent did not just translate. It modernized."

**Minute 8 — The take-home.**

> "Three things from this story."

> "First, the spec was the brain. The dbt Model Optimizer SKILL captured judgment we have built over many engagements. The agent applied it. The leverage was in the SKILL, not in the agent's general capability."

> "Second, classified outputs are what made it shippable at this scale. SAFE / REVIEW / REQUIRES APPROVAL is a pattern you can adopt in your own work next week. You do not need our SKILL to use the classification idea."

> "Third, this approach works because Cortex Code CLI runs in the platform. The agent inherited the governance. The platform did real work. That is the difference between agentic coding everywhere else and agentic coding in Snowflake."

[Pause. The bonus observation.]

> "And one more thing worth noticing. Look at the Documentation Agent in the architecture. What did it produce? Markdown files. Every decision, every recommendation, every change captured in markdown. That is the same discipline I have been teaching you all morning. The agentic architecture and the spec-driven discipline are not two things. They are the same thing at different scales. When we say spec-driven development scales, this is what scaling looks like in production."

### Visual aid (use your Solution Backbone slide)

Use the Solution Backbone slide you already have. It is the right visual for this beat and far clearer than any ASCII version. The slide shows the four agents in sequence (Reverse Engineering → Consolidation → Data Model Mapping → SnowConvert AI) with the Documentation Agent running across the bottom and producing markdown.

Walk the audience through it left to right as you tell Minutes 3-4. Point to each agent as you name it. Then, when you get to the dbt Model Optimizer SKILL, indicate it as a layer ON TOP of the architecture (you can sketch this in or just say "and the SKILL wraps this for the optimization work").

Two things to call out explicitly when you point to the slide:

1. **SnowConvert AI is part of the architecture, not an alternative to it.** This positions DDA + SnowConvert as the combined Deloitte-plus-Snowflake solution, which is the right tone at Summit.

2. **The Documentation Agent produces markdown.** Foreshadow this in Minutes 3-4 so the bonus observation in Minute 8 lands clean.

If you only have the slide and not the time to walk through every agent, the minimum is: name the four sequential agents, name the Documentation Agent, name the dbt Model Optimizer SKILL on top.

### What not to say

Do not name the client. Even if the audience guesses (and some will), do not confirm.

Naming Deloitte Data Assist 3.0 once at the top is enough. Do not turn the engagement story into a product pitch. The substance of the dbt Model Optimizer SKILL, the six dimensions, and the SAFE / REVIEW / REQUIRES APPROVAL classification carries the credibility for DDA 3.0 more than any branded mention could. Let the work do the work.

Do not give specific dollar amounts beyond "eight figures." The 67% timeline compression is documented and safe. The full dollar figure is more identifying than helpful.

---

## Section 5 — The Hands-On Lab (The Engagement Heart of the Session)

### What you observed at prior Snowflake labs

You said the labs you have seen had participants copy-pasting prompts and watching Cortex Code work. Low engagement. People lost interest.

That observation is exactly right and it is the structural problem this lab has to solve. Watching an agent work is not engaging once the novelty wears off, which takes about three minutes. The cure is not better demos. The cure is making participants think before the agent works.

### The pedagogical principle (one sentence)

**In a Spec-Driven Development lab, the thinking is the lab. The agent's typing is the punctuation.**

Everything else flows from this. If participants are typing prompts, they are not learning. If they are writing specs and arguing with their partner about a choice, they are learning.

### The exercise

**Problem statement (read this verbatim or close to it):**

> "You are a data engineer at a mid-sized company. The marketing team has just dropped a CSV in your shared drive with 1,000 customer records. It contains a mix of names, emails, phone numbers, ages, regions, last purchase dates, and lifetime value. They want it in Snowflake by end of day so they can run a campaign analysis. Your job: build an agent that ingests this CSV into Snowflake with the right types, the right governance, and a validation report. You have twenty minutes of agent work to do it twice. Once the easy way. Once the right way."

**Why this problem:**

Universal. Every data person has done this. Non-trivial governance implications (PII, masking). Multiple right answers (which forces decisions). Multiple wrong answers (which makes failures visible). Time-bound and demoable.

### The seven beats of the lab (47 minutes)

**Beat 1 — Setup (4 min)**

Pair people up. Whoever is in seat A on each row writes; whoever is in seat B reviews. Swap after seven minutes of the spec-driven round. Read the problem out loud. Confirm everyone has the CSV in their lab environment, and confirm they are in the CLI version of Cortex Code, not Snowsight.

**Beat 2 — Vibe Round (5 min)**

> "First attempt, no spec. Just prompt Cortex Code to do it. Type what you want. See what you get. Five minutes. Go."

Walk the room. Do not help. Note who is finishing, who is stuck, who is producing something interesting.

**Beat 3 — Pause and Observe (3 min)**

> "Stop typing. Look at what you got. Three questions for your pair: First, did the agent ask you about PII? Second, did it ask you about data types or just guess? Third, would you ship this?"

Take 2-3 hands. Listen. Do not lecture. Let them surface the problems.

**Beat 4 — Constitution Writing (7 min)**

> "Now we slow down. Close your laptop, or open a markdown file. Do not write code. Do not prompt the agent. For seven minutes, write a Constitution for this work. Mission. Tech stack. Roadmap. Be specific. If you are not sure what goes in each section, look at the handout."

This is the critical beat. Walk the room. If you see someone typing in Cortex Code, gently redirect: "Not yet. Write the Constitution first."

**Beat 5 — Spec-Driven Round (14 min)**

> "Now, with your Constitution in hand, go back to Cortex Code. Give it the Constitution. Then prompt for the same thing as before. See what changes."

The pair dynamic kicks in here. Person A writes, person B reviews against the Constitution. After seven minutes, swap roles.

Walk the room. Identify 2-3 pairs producing notably good results. You will reveal these later.

**Beat 6 — The Change-One-Line Reveal (5 min)**

This is the lightbulb moment. You drive it from the front.

> "Everyone, look at your Constitution. Find one line. Maybe the line that says 'mask PII before insert' or 'use VARCHAR(255) for text fields' or 'fail on duplicate keys.' Change that ONE line. Now ask Cortex Code to re-implement against the new Constitution. Watch what happens."

What happens: small spec change, large code change. This is the moment the abstract claim ("change the spec, change the code") becomes a felt experience.

**Beat 7 — Reveal and Compare (7 min)**

Bring 2-3 of the strong outputs to the front (using the lab environment's screen share or a projector). Show them side by side. Ask the authors: "What was in your Constitution that made this work?"

The authors will articulate their reasoning. That articulation is the most valuable learning moment in the session, because it is participants teaching participants.

If time allows, also show one weak output (anonymously). Ask the room: "What was missing from the Constitution that produced this?"

### Engagement principles for the facilitator (you)

These are the patterns to enforce throughout the lab.

**Less talking, more walking.** Once the lab starts, you are in the room, not at the front. Watch pairs. Stop at the stuck ones. Ask one diagnostic question and move on.

**Ask, do not tell.** When a pair is confused, do not give them the answer. Ask "what does your Constitution say about this?" If their Constitution does not say anything about it, that is the lesson.

**Force the pair dynamic.** If you see solo work, gently restart the pair conversation. "What is your partner seeing? Are you both happy with that choice?"

**Time discipline matters.** Announce time at the two-minute warning of each beat. Do not let beats blur into each other.

**Reveal selectively.** When you bring outputs to the front, pick ones that teach different lessons. Two near-identical examples teach nothing. Two different examples teach contrast.

### Anti-patterns to actively avoid

These are what sank the prior Snowflake labs. Naming them so they stay top of mind.

- **Copy-paste prompts on a slide.** Do not show participants the prompts to use. Give them a problem; let them write their own prompts.
- **Step-by-step instructions.** This is a "figure it out" lab, not a "follow along" lab. Participants need to feel the productive struggle.
- **Solo work.** Pair work is non-negotiable. Verbalizing forces thinking.
- **Watching the agent.** The agent's output is the artifact, not the spectacle. Move on quickly from each agent invocation.
- **Long facilitator monologues.** Once the lab starts, your job is to facilitate, not to lecture.
- **No comparison.** Without the reveal, participants do not see what they could have done.

---

## Section 6 — Wrap-Up (9 min)

### Beat 1: Claude Code transferability (2 min, before Q&A)

This is the third of your three new threads. It belongs here because the lab has just shown them spec-driven work in Cortex Code, and the natural question for many of them is "how does this relate to what I am already doing in Claude Code?"

**Suggested wording:**

> "Before we go to questions, one thing for those of you who already use Claude Code or a similar agent."

> "What you have learned about spec-driven work in Claude Code transfers. The Constitution is the same shape. SKILLs use the same format. The patterns travel. You are not starting from zero with Cortex Code."

> "What is different in Cortex Code is the platform. You get governance for free that you have to build everywhere else. You get Snowflake-native execution. You get the data perimeter without negotiating it. The 80% you already know carries over. The 20% that is specific to Cortex Code is how to use AISQL, how to invoke Snowflake-native functions in your SKILLs, and how to lean on Snowflake's governance model instead of reimplementing it."

> "The dbt Model Optimizer SKILL I told you about earlier was originally adapted from a SKILL we built for Claude Code work. The patterns traveled. Yours will too."

This beat does three things at once: validates their existing investment, gives them confidence that Cortex Code is reachable, and ties the case study back to a transferable lesson.

### Beat 2: Q&A (5 min)

Expect questions on brownfield, dbt integration, model portability, time savings, replacing engineering reviews, and the SAFE/REVIEW/REQUIRES APPROVAL classification (this one almost always comes up after the case study). All of those have prepared answers in the briefing. The classification question is worth a longer answer because it is one of the most actionable patterns for the audience.

### Beat 3: DDA 3.0 take-home and closing line (4 min)

This is the moment to give the DDA 3.0 mention its second life. Brief, helpful, not pushy.

> "One last thing for those of you who want to dig deeper. Everything I showed you today, the SDD patterns, the SKILLs, the classification approaches, the migration factory, all sits under Deloitte Data Assist 3.0. That is the framework name. If you want to learn more about how we operationalize this at scale, that is the thing to ask about. Find me after this session, or talk to your Deloitte contact. I am happy to keep the conversation going."

Then the closing line.

> "The agent will go faster. The models will get better. What you take home from this room is not a tool. It is a way of working that survives the next three model releases. Write things down. Make the agent serve the writing."

Pause after this. Let it land. Then thank them and gesture to the handout.

### The handout

If the handout has not been distributed yet, this is the moment. Each handout should have the two-column comparison (vibe vs structured), the three patterns (migration as product, governance lives in the SKILL, spec captures judgment), the four-line Constitution template, the SAFE / REVIEW / REQUIRES APPROVAL classification pattern as a callout box, three Snowflake-specific SKILL ideas to try at home, a note that SKILLs require the CLI version, and a Deloitte Data Assist 3.0 reference (logo, one-line description, contact path) along the bottom or as a sidebar.

The handout is the take-home artifact. People will refer back to it on the plane home and on Monday morning when they sit down to try this themselves. The DDA 3.0 reference is what gives them somewhere to go from there.

---

## Section 7 — Facilitator Survival Notes

### What to bring on stage

The talking points from the briefing, printed, in your back pocket. This session design on your phone for the runsheet. A stopwatch or timer. Water. A printed copy of the handout in case some participants do not get one through the official channels.

### Co-facilitator coordination

If there is a co-facilitator from Snowflake or Deloitte, agree on these in advance.

Who introduces whom. Who runs the demos (if not you). Who walks the room during the lab. Who calls time. Who manages Q&A overflow.

If you are alone on stage, the lab beats require you to be highly mobile. Plan to walk continuously between beat 4 and beat 7.

### If the room is going low energy

The most common culprit at minute 40 is too much instructor voice. Cut your transitions. Let participants start the next beat sixty seconds early. Movement helps. Have them stand up briefly between beats.

If by minute 60 the lab is dragging, skip the change-one-line beat and go straight to the reveal. The reveal is the highest-value beat. Protect it.

### If something breaks

Cortex Code in a lab environment will occasionally have issues. If a participant's environment is broken, pair them with someone working. Never let a broken environment stop a pair from learning.

If the demo breaks during demo 1 or 2, fall back to the artifact. "Let me show you the SKILL while we wait for the environment." The SKILL is more important than the live demo anyway.

### If a participant is dominating their pair

You will see this. One person leans in, types fast, makes all the calls. The other person disengages.

Walk over. Say to the dominant participant: "I want to hear your partner's read on the Constitution. What did you write for governance?" Address the question to the quieter one. This rebalances the pair without embarrassing anyone.

### If someone asks about the client during the case study

Common at this level of detail. The response is the same regardless of who asks or how directly.

> "I can talk about the patterns and the approach. I cannot confirm or deny which client this was. The metrics are documented in materials we are allowed to share. The client is not."

Move on. Do not let the conversation drift into who-is-the-client guessing.

---

## Section 8 — Open Questions for You

Resolve these before Summit.

**Session length.** I designed for 90 minutes. If the actual slot is different, tell me and I will reshape.

**Co-facilitator identity and role.** Who is on stage with you, and what do they own?

**Lab environment.** Does each participant get their own Snowflake trial / Cortex Code CLI instance? If they are sharing or if the lab is a shared sandbox, the pair dynamics need adjustment. Critical: confirm they are working in the CLI version, not Snowsight, since SKILLs are CLI-only.

**The handout.** Want me to draft it as a standalone artifact next? It is the highest-leverage remaining deliverable, especially with the new SAFE / REVIEW / REQUIRES APPROVAL pattern to add.

**DDA 3.0 logo and one-line description for the handout.** Confirm what assets I should use for the handout reference. If there's an approved one-liner ("Deloitte Data Assist 3.0: our agentic AI framework, tools, and accelerators for enterprise data modernization"), send it.

**Sample CSV for the lab.** Do you have a customer CSV ready, or should one be generated? If you need one generated, I can produce a 1,000-row sample with believable PII characteristics.

---

## Final Note

The single biggest design decision in this session is what happens during the lab. The opening, the demos, and the case study all serve the lab. If the lab works, the session works. If the lab is passive copy-paste like the prior Snowflake labs you described, the session fails regardless of how good the open was.

The Cisco case study is now doing significantly more work than my earlier draft. It carries the CLI-vs-UI message, the custom SKILLs message, and the proof that this approach scales to industrial migrations. It is the credibility anchor for everything that comes after. The classification pattern in particular is the one practitioner takeaway most likely to end up in someone's Monday morning meeting.

Run the lab the way it is designed and you will see what those other Snowflake labs were missing: participants leaving with something they made, not something they watched made.
