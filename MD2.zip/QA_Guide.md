# IBM Interview — Q&A Preparation Guide
## AI & Data Practice — Snowflake / Databricks Practice Leadership Role
**Interviewer:** Jeff Tennenbaum, Executive Architect, IBM Consulting Federal Practice

---

> **How to use this guide:**
> These are not scripts. They are *anchors* — the core idea you want to land for each question.
> Speak naturally from the anchor. The exact words will come. What matters is that you hit the
> substance. Answers marked 🔴 are the ones most likely to come up. Have those cold.

---

## SECTION 1: About You & Your Career

---

### 🔴 Q1: "Tell me about yourself."

**What Jeff is really asking:** Can you synthesize 35 years into a coherent narrative with a point? Or will I get a chronological recitation?

**Anchor answer:**
> *"My career is a sequence of platform wave bets — and I've been early on most of them. Data warehousing in 1996. Hadoop in 2012 — I actually stepped down from a leadership role to go hands-on and learn it, then built Deloitte's Big Data practice from scratch. Legacy modernization to the cloud. Snowflake in 2018 — built that practice, became Practice Lead and CTO. Now agentic AI and forward deployed engineering.*
>
> *The throughline isn't any specific technology. It's the ability to see where the gravity is shifting, get close to it fast, and build the practice before the market catches up. That's what I've done five times. It's what you're asking me to do with Databricks and the AI & Data practice here."*

**Why it works:** Ends by connecting directly to IBM's need. No throat-clearing. The pattern sells itself.

---

### 🔴 Q2: "Walk me through your Hadoop decision — why step down from a leadership role?"

**What Jeff is really asking:** Is this person willing to do what it takes, or do they protect their title?

**Anchor answer:**
> *"I was leading all of AI & Data. When Hadoop emerged, I realized I couldn't credibly build on something I hadn't touched. So I made a deliberate choice — stepped down to Individual Contributor, went hands-on, learned it properly. Then Deloitte hired me to build their Big Data practice from that foundation.*
>
> *People thought it was a strange move at the time. In hindsight it was the only move that made sense. You can't build a practice on a technology you've only read about."*

**Why it works:** Shows intellectual honesty and willingness to take personal risk for conviction. Rare in someone at this level.

---

### Q3: "How did you discover Snowflake and why did you bet on it early?"

**Anchor answer:**
> *"I came across it in 2018 during the legacy modernization work — we were moving clients off Oracle and Teradata to cloud platforms, and Snowflake kept showing up as the answer that actually worked at scale. The architecture was genuinely different — separation of compute and storage wasn't incremental, it was structural. I started recommending it to clients, saw the results, built the practice around it. By 2020 it was my primary focus.*
>
> *The Snowflake bet wasn't about features — it was about the economic model underneath the architecture. That same logic is what I apply to every platform evaluation."*

---

### Q4: "What does your current work at Deloitte look like day-to-day?"

**Anchor answer:**
> *"I run a Forward Deployed Engineering practice focused on Snowflake Cortex and agentic AI. The model is direct engagement — I'm in client environments, hands on architecture, building things, not advising from a distance. Current engagements include an intercompany reconciliation system with a knowledge graph layer, and a Procure-to-Pay workflow for Cisco. Simultaneously I'm building reusable practice IP — Skills, governance frameworks, delivery methodology — so the work compounds rather than resets with each engagement.*
>
> *I also write. My most recent LinkedIn article — published three days ago — makes the case for why most FDE practices are capturing 2X-3X when 20X-30X is possible, and what the gap actually is."*

---

## SECTION 2: Platform & Technical Depth

---

### 🔴 Q5: "Your background is heavily Snowflake. How do you think about Databricks?"

**What Jeff is really asking:** Are you a Snowflake advocate who will struggle to serve clients with Databricks? Or do you have genuine platform-agnostic judgment?

**Anchor answer:**
> *"Let me give you three things. First, Databricks is commercial Spark — and Spark was central to the Hadoop work I was doing from 2012. The engine isn't new to me; the productized platform is.*
>
> *Second, as Snowflake Practice Lead and CTO, tracking Databricks wasn't optional — it was competitive due diligence. I've followed the roadmap closely.*
>
> *Third — and this is the one that matters most — I've recommended Databricks over Snowflake to clients when it was the right answer. You can look at my LinkedIn to verify that position. I work for the client, not for a platform.*
>
> *The real question in the market right now isn't Snowflake versus Databricks. It's co-existence — 60% of enterprise clients have both. That's the conversation most practitioners can't have without a platform bias. I can."*

---

### 🔴 Q6: "Where does Databricks win deals that Snowflake doesn't? And vice versa?"

**What Jeff is really asking:** Do you have genuine market fluency, or practiced talking points?

**Anchor answer:**
> *"Databricks wins where the data science and ML engineering persona drives the platform decision — Python-native teams, MLflow for model lifecycle, open format requirements, heavy feature engineering workloads. Unity Catalog has closed the governance gap significantly in the last two years. Lakehouse architecture with Delta Lake is a genuinely strong answer for organizations that need ML and analytics on the same data.*
>
> *Snowflake wins on SQL-first analytics, governed data products, structured BI workloads, and ease of governance. Cortex has closed the AI gap faster than most people expected — it's a serious platform for agentic AI now, not just a data warehouse with an AI label.*
>
> *Where it gets interesting: most enterprise clients now have both, and neither platform is going away. The advisory question has shifted from selection to co-existence architecture — and that's where I spend most of my time."*

---

### 🔴 Q7: "What's your co-existence strategy for clients running both platforms?"

**What Jeff is really asking:** Do you have a framework, or just a platitude?

**Anchor answer:**
> *"Three layers. First, define workload ownership — ML engineering and data science on Databricks, governed analytics and structured data products on Snowflake, as a starting point, then adjust based on the client's actual team skill profile.*
>
> *Second — and this is the architectural move most advisors aren't making yet — recommend Apache Iceberg as the open storage layer underneath both. Both platforms support Iceberg natively and well. If the client's data sits in open format on their own cloud storage, the compute engine becomes a runtime choice, not a long-term commitment. You're not locked to either vendor's pricing or roadmap.*
>
> *Third, governance spans both. You need a unified lineage and data quality framework that doesn't live inside either platform — otherwise you end up with two governance models that contradict each other at the seam.*
>
> *That's the conversation a CDO actually needs, and it's one very few practitioners can have without a platform bias."*

---

### Q8: "How do you think about the future of the data platform landscape — where does it go from here?"

**Anchor answer:**
> *"Open formats win. Iceberg, Delta Lake, and the lakehouse model are converging toward a world where the storage layer is decoupled from the compute layer permanently. The platform competition shifts from 'who owns your data' to 'who delivers the best compute, governance, and AI capabilities on data you already own.'*
>
> *For agentic AI, the next inflection is semantic — the ability for agents to understand what data means, not just where it lives. That's where knowledge graphs, ontologies, and neurosymbolic architectures become load-bearing. The platforms that invest in the semantic layer will be the ones agents actually trust. That's a 3-5 year arc, but the foundations are being laid now."*

---

### Q9: "How do you think about agentic AI in an enterprise data context?"

**Anchor answer:**
> *"Agentic AI changes the data quality risk profile fundamentally. A human analyst queries data occasionally and applies judgment. An agent queries continuously, at scale, and acts on the output — potentially triggering workflows, payments, eligibility decisions. The gap between implied governance and enforced governance becomes catastrophic at that scale.*
>
> *My architecture answer is governed data products with quality gates that fail closed. Before any agentic workflow touches a data source, it validates freshness, completeness, schema contract, and lineage. If any gate fails, the workflow routes to human review — not silently proceeds on bad data. Governance has to be embedded in the architecture, not documented in a policy.*
>
> *Jeff, you made this argument very clearly in your February article on the Federal side. The pattern holds exactly in commercial enterprise — the legacy architectures most clients are running were designed for static reporting, not dynamic AI-driven workflows."*

**Note:** This line acknowledges his article directly and on-topic. Use it only if the conversation warrants it — don't force it.

---

## SECTION 3: Practice Building & Client Delivery

---

### 🔴 Q10: "How do you credential a team you're bringing into a client engagement?"

**What Jeff is really asking:** Can you actually win in a room with a CDO who doesn't know you?

**Anchor answer:**
> *"Three things. First, specificity — I tell the client what we've built and where. Not logos, not case study language. Actual architectures, actual outcomes, the decisions we made and why. CDOs can tell the difference between a team that's done something and a team that's pitching it.*
>
> *Second, I bring subject matter depth matched to their specific problem. Not a generalist team that covers everything at 60%. If it's a Procure-to-Pay workflow, I bring someone who has built that. That match signals that I've understood what their signature issue actually is.*
>
> *Third — and this is the one most teams skip — I'm honest about what we don't know and how we'll close it. Senior stakeholders don't expect omniscience. They expect honesty. Overconfidence from a team they just met is a red flag, not a reassurance.*
>
> *The credentialing happens in the first 30 minutes of the discovery conversation, not in the proposal."*

---

### 🔴 Q11: "What's your model for engaging CDOs and senior business leaders?"

**Anchor answer:**
> *"Communication range — the ability to operate across the full spectrum in the same engagement. Deep with the data architect on schema trade-offs. Frank with the CDO on what's possible and what it costs to wait. Specific enough with the CFO or supply chain leader that they act, not nod and move to the next agenda item.*
>
> *The 'so what' for a senior leader is not a presentation skill. It's a strategic synthesis skill — translating a technically sound solution into a business decision. Most technically strong practitioners can explain what they built. Very few can articulate the cost of inaction in terms a CFO uses to make decisions.*
>
> *I wrote about this recently. The communication range gap is one of four reasons most FDE practices are leaving 20X on the table. The organizations that close this gap don't just deliver better — they win the next engagement in the same conversation."*

---

### Q12: "How do you build a practice while also delivering on live client engagements?"

**Anchor answer:**
> *"You have to design for compounding from the start. Every engagement produces reusable IP — a Skill package, a governance framework, a delivery pattern, a client-facing asset. If you're rebuilding from scratch for each engagement, you're scaling linearly. If every engagement compounds the practice library, you're scaling geometrically.*
>
> *The discipline is forcing the extraction. When you're heads-down on delivery, the natural instinct is to ship and move on. The practice builder's instinct is to ask: what did we just learn, what can be reused, and how do we package it so the next team doesn't start from zero? That's the difference between a practice and a project portfolio."*

---

### Q13: "Walk me through a complex client engagement — the problem, your approach, the outcome."

**Use one of these two stories:**

**Option A — Evident Scientific (Intercompany Reconciliation):**
> *"A client was running intercompany reconciliation manually — extracts, Excel, shared drives. Ownership was implied, lineage was reconstructed after the fact, and audit readiness required weeks of manual work. We rebuilt it as a governed data architecture on Snowflake with a knowledge graph layer — KG_NODE and KG_EDGE structures — to capture entity relationships and enable semantic matching. Quality gates with freshness and completeness thresholds were enforced before any agentic reconciliation logic ran. Fail-closed. Exceptions routed to a Streamlit hub for human review. The audit trail went from manually reconstructed to automatically generated. Governance went from aspirational to enforced."*

**Option B — Cisco Procure-to-Pay:**
> *"Cisco needed to address invoice exception resolution and contract leakage in their Procure-to-Pay workflow. The problem wasn't finding exceptions — it was that the exceptions were drowning the team and the resolution cycle was too slow. We designed an agentic workflow with Cortex that triaged exceptions by type and confidence, surfaced contract leakage patterns against structured spend data, and routed only the genuinely ambiguous cases to human review. The personas — AP analyst, procurement manager, CFO — each had their own Cortex Analyst prompt tuned to their decision context. The outcome was resolution cycle compression and a significantly smaller human review queue."*

---

### Q14: "How do you think about building a team for this practice — hire, partner, or train?"

**Anchor answer:**
> *"All three, sequenced deliberately. You start with a small core of practitioners who have the depth and the communication range — the trauma surgeon profile I wrote about recently. That core sets the standard and produces the reusable IP. You can't build that by training generalists fast.*
>
> *Then you layer in delivery capacity — seasoned execution leads who can run engagements against the methodology the core established. This is where training and upskilling works, because the standard already exists.*
>
> *Partnerships fill the gaps — ecosystem, tooling, specialized domain depth. But a partnership can't substitute for the integrating intelligence at the core. That's the piece most practices try to scale too early, and it's why they plateau at 3X."*

---

## SECTION 4: IBM-Specific Questions

---

### 🔴 Q15: "Why IBM? Why now?"

**Anchor answer:**
> *"Two things. First, the Hakkoda acquisition signals that IBM is making a genuine bet on being a products-and-services firm, not just a services firm. The engineering depth is already there — what's needed now is the market-facing practice leadership to convert that pipeline into delivered outcomes. That's the gap I'm being asked to fill, and it's a gap I've closed before.*
>
> *Second, the timing matters. The AI & Data market is at an inflection point — not the AI hype inflection, the delivery inflection. Clients are moving from experimentation to execution. The organizations that build the right practice model now will own the market for the next decade. I'd rather build that practice than watch someone else do it."*

---

### Q16: "IBM has a reputation for engineering excellence but perhaps less for market-facing agility. How do you see that?"

**Anchor answer:**
> *"Honestly — I'd say it's accurate as a general observation, and it's also the reason this role exists. Engineering excellence produces great solutions. Market-facing agility produces clients who buy them, stay, and expand. IBM has the first. Building the second is the job.*
>
> *The good news is that engineering credibility is the harder thing to fake. A firm that can deliver and needs to improve its solution framing is a much better position than a firm that can sell and struggles to deliver. I've seen both. I know which problem I'd rather solve."*

---

### Q17: "How do you see the relationship between IBM's Federal AI practice and the commercial AI & Data practice?"

**Anchor answer:**
> *"There's a significant overlap in architecture — governed data products, agentic AI governance, semantic layers, fail-closed quality controls. The Federal context adds compliance, auditability, and policy constraints, but the underlying engineering patterns are largely the same.*
>
> *Where I'd look for leverage is IP reuse — governance frameworks, quality gate patterns, agentic workflow controls developed on the Federal side that translate directly to regulated commercial industries: financial services, healthcare, energy. The delivery methodology may differ; the architecture patterns rarely do.*
>
> *That's actually a question I have for you — how much cross-pollination happens today between the two practices, and where do you see the opportunity?"*

**Note:** This answer ends with a question back to Jeff — it's a natural transition into your question list.

---

### Q18: "What does success look like for you in this role in the first 90 days?"

**Anchor answer:**
> *"Three things. First, I've mapped the existing Snowflake delivery capability from Hakkoda — what's strong, what's reusable, where the gaps are. I can't build on what I don't understand.*
>
> *Second, I'm in at least two active client engagements — not observing, contributing. The credibility I need to build the practice comes from delivery, not from planning.*
>
> *Third, I've produced one reusable practice artifact — a co-existence framework, a governance pattern, something — that the broader team can use. The compounding starts on day one or it doesn't start."*

---

## SECTION 5: Thought Leadership & Intellectual Depth

---

### Q19: "You've been publishing on LinkedIn. What are the themes you're most focused on?"

**Anchor answer:**
> *"Three overlapping areas. First, the FDE delivery model — specifically why the market is building the wrong archetype. My most recent article makes the case that intelligence arbitrage needs a trauma surgeon, not a pit crew. The organizations capturing 20X-30X have figured this out; most haven't.*
>
> *Second, the semantic layer in enterprise AI — knowledge graphs, ontologies, neurosymbolic architectures. The platforms give you data access; the semantic layer gives agents the ability to understand what the data means. That's the architectural frontier most enterprises haven't reached yet.*
>
> *Third, platform co-existence — specifically the Iceberg-anchored multi-compute strategy. I've been making the case for open formats as a vendor-lock mitigation strategy for a couple of years now. The market is catching up to that position.*
>
> *You covered a lot of the governance and agentic AI ground in your February article — I'd say you were a few years ahead of me on some of that. I've been pushing further into the neurosymbolic territory that you haven't addressed yet."*

---

### Q20: "What's neurosymbolic AI and why does it matter for enterprise?"

**Anchor answer:**
> *"It's the combination of formal symbolic reasoning — ontologies, knowledge graphs, logic — with statistical learning from LLMs. Each compensates for the other's weakness. LLMs are brilliant at pattern recognition and language but unreliable on structured reasoning and verifiability. Formal ontologies are precise and auditable but brittle and hard to scale.*
>
> *For enterprise AI, the reason it matters is determinism and auditability. An agent that reasons over a governed knowledge graph produces traceable, explainable outputs — you can follow the reasoning path. That's what regulated industries and high-stakes decisions require. Pure LLM reasoning gives you fluency; neurosymbolic gives you trustworthiness.*
>
> *I've been building knowledge graph layers — what I call KG_NODE and KG_EDGE architectures — on top of Snowflake as the foundation for this. It's early, but clients who've seen it immediately understand why it's different from a standard vector search approach."*

---

### Q21: "What's intelligence arbitrage? How do you define it?"

**Anchor answer:**
> *"It's the asymmetric value that a practitioner captures when they apply AI amplification to deep domain expertise. The arbitrage comes from the gap — AI alone produces average outputs at speed. Deep expertise alone produces excellent outputs slowly. The combination produces expert-quality outputs at machine speed, across multiple simultaneous engagements.*
>
> *The arbitrage is temporary by definition — as AI capability rises and expertise becomes more commoditized, the gap closes. But right now, the practitioners who have both the depth and the ability to direct AI are operating in a window of extraordinary leverage. That's the 20X-30X I wrote about — not a theoretical multiplier, a pattern I'm seeing in the field."*

---

## SECTION 6: Questions You Ask Jeff

*Ask these at the natural close of the interview. Prioritize based on conversational flow — you won't get through all of them.*

---

**On the Practice Gap:**
> *"IBM has strong Snowflake delivery capability from Hakkoda. In your view, is the Databricks gap primarily a talent problem, a go-to-market problem, or both?"*

**On the Operating Model:**
> *"The model as I understand it has a lead partner bringing the practice team in for solutioning. How much runway does practice leadership realistically have to build reusable IP versus being pulled full-time into live delivery?"*

**On Cross-Practice Leverage:**
> *"Your Federal practice has built significant depth in governed data products and agentic AI governance. How much of that architecture thinking translates to the commercial practice — and is there a formal mechanism for that exchange today?"*

**On Success Metrics:**
> *"What does success look like for whoever takes this role at the 6-month mark — and what does failure look like?"*

**On IBM's Evolution:**
> *"IBM has extraordinary engineering depth. Where does the market-facing capability — the ability to frame and win the solution before it's built — sit today, and where does it need to go?"*

**The sharp closer (use if the conversation has gone well):**
> *"Based on this conversation, is there anything about my background or approach that gives you pause? I'd rather address it directly than leave it on the table."*

---

## SECTION 7: Curveballs & Difficult Questions

---

### "You've been at Deloitte a long time. Why would IBM be different?"

> *"Deloitte is where I built the capability. IBM is where I'd deploy it at a different scale and with a different model. Deloitte is a services firm — the IP walks out the door with every engagement. IBM, with Hakkoda integrated, is moving toward a products-and-services model where the IP compounds. That's the transition I want to be part of building, not watching from the outside."*

---

### "You publish a lot publicly. Some of what you've written challenges the FDE pod model that IBM is building. How do you square that?"

> *"I'd say it's an asset, not a liability. The article makes the case that the pit crew model captures 2-3X. IBM wants 10X or more from this practice. If the honest answer is that the current model won't get there, I'd rather surface that now and build the right model than validate the current one and deliver predictably disappointing results. IBM hired me to build the practice. Not to agree with the current state of it."*

---

### "This role requires building Databricks capability fast. What's your 90-day plan for that specifically?"

> *"Three moves. First, assess the existing Databricks capability in the team — what's there, what's usable, where the real gaps are. Don't assume the gap is as big as it looks from the outside.*
>
> *Second, target two or three active client engagements where Databricks is in scope and get hands-on fast — either directly or alongside someone with deep Databricks execution depth.*
>
> *Third, map the co-existence architecture I've been advising on commercially to a repeatable IBM offering. The Iceberg-anchored multi-compute framework — that's a differentiated market position that IBM doesn't currently have. That's not a 90-day build. It's a 30-day positioning document and a 60-day first client delivery."*

---

### "What's the one thing that could make you fail in this role?"

> *"Being pulled entirely into delivery without the space to build the practice IP. The two reinforce each other when done right — delivery generates the patterns, IP packaging makes them reusable. But if every hour goes to billable delivery, the compounding never starts. I'd want to align with leadership early on what the right balance looks like and protect it deliberately."*

---

*IBM Interview Q&A Guide — Prepared for Rupesh Dandekar*
*Interviewer: Jeff Tennenbaum, IBM Consulting Federal Practice*
