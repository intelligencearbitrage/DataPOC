# Project OASIS — Snowflake Cortex Code Build Specification
**Oncology Account Marketing Strategic Insights Solution**
*Pfizer Oncology | Cortex Code Prompt Spec | April 2026 | Confidential – Working Draft*

---

## HOW TO USE THIS DOCUMENT

This document is structured as a direct instruction set for **Snowflake Cortex Code** to generate a production-ready Streamlit in Snowflake application. Each section is written as a precise directive. Sections are ordered to match the sequence Cortex Code should follow: environment setup → data layer → shared components → page-by-page module build → AI layer → deployment.

Where values are marked `[ASSUMPTION]`, the build should use the stated default and flag it in an inline code comment for human review before production deployment.

---

## SECTION 1 — APPLICATION IDENTITY & ENVIRONMENT

**Application Name:** `OASIS`
**Display Title:** `Project OASIS — Oncology Portfolio Intelligence`
**Snowflake Database:** `PFIZER_ONCOLOGY_DB`
**Snowflake Schema:** `OASIS_MART`
**Streamlit App Name (SiS):** `OASIS_APP`
**Warehouse:** `OASIS_WH` (size: Medium, auto-suspend: 5 min)
**Snowflake Region:** `[ASSUMPTION]` `us-east-1`

### 1.1 Python Dependencies

```toml
# environment.yml / packages list for Streamlit in Snowflake
streamlit>=1.32.0
snowflake-snowpark-python>=1.14.0
plotly>=5.20.0
pandas>=2.0.0
numpy>=1.26.0
altair>=5.2.0
pyyaml>=6.0
```

### 1.2 Snowflake Session Bootstrap

```python
# config/snowflake_connection.py
from snowflake.snowpark.context import get_active_session
import streamlit as st

@st.cache_resource
def get_session():
    """
    When running inside Streamlit in Snowflake, the session is injected
    automatically. No credentials needed.
    """
    return get_active_session()
```

### 1.3 App Configuration Constants

```python
# config/app_config.py

APP_TITLE        = "Project OASIS"
APP_SUBTITLE     = "Oncology Account Marketing Strategic Insights Solution"
DB               = "PFIZER_ONCOLOGY_DB"
SCHEMA           = "OASIS_MART"
WAREHOUSE        = "OASIS_WH"
DATA_REFRESH_MSG = "Refreshed weekly — last refresh shown in top bar"

# [ASSUMPTION] Starter brand set — confirm with brand leads before production
BRANDS = ["LORBRENA", "BRAFTOVI", "MEKTOVI"]

# [ASSUMPTION] Full brand set for WALK phase
BRANDS_FULL = ["LORBRENA", "BRAFTOVI", "MEKTOVI", "IBRANCE", "XTANDI"]

REGIONS    = ["Northeast", "Southeast", "Midwest", "West", "Southwest"]
SEGMENTS   = ["IDN", "Academic", "Community", "GPO"]
TIERS      = ["Tier 1", "Tier 2", "Tier 3"]
PERIODS    = {"3M": 3, "6M": 6, "12M": 12, "24M": 24}

# Brand color palette — Pfizer brand-aligned
BRAND_COLORS = {
    "LORBRENA":  "#0039a6",
    "BRAFTOVI":  "#009fdf",
    "MEKTOVI":   "#00b5a5",
    "IBRANCE":   "#6b48ff",
    "XTANDI":    "#ff7043",
    "COMP_A":    "#ef4444",
    "COMP_B":    "#f59e0b",
    "COMP_C":    "#00b5a5",
}

OASIS_COLORS = {
    "pfizer_blue":   "#0039a6",
    "pfizer_mid":    "#0057d9",
    "pfizer_light":  "#009fdf",
    "teal":          "#00b5a5",
    "green":         "#22c55e",
    "red":           "#ef4444",
    "amber":         "#f59e0b",
    "bg":            "#f0f4fa",
    "surface":       "#ffffff",
    "border":        "#dde3ef",
    "text_primary":  "#0d1b3e",
    "text_muted":    "#8896b3",
}
```

---

## SECTION 2 — DATA MODEL

### 2.1 Table Definitions

Create the following tables in `PFIZER_ONCOLOGY_DB.OASIS_MART`. All tables use `account_id` as the join key.

```sql
-- ── TABLE 1: Account Master & Hierarchy ──────────────────────────────────────
CREATE OR REPLACE TABLE OASIS_MART.ACCOUNT_HIERARCHY (
    account_id          VARCHAR(50)     NOT NULL,
    account_name        VARCHAR(200)    NOT NULL,
    account_type        VARCHAR(50),                -- IDN | GPO | Academic | Community | Satellite
    parent_account_id   VARCHAR(50),                -- NULL for top-level systems
    system_name         VARCHAR(200),               -- top-level health system name
    territory_id        VARCHAR(20),
    territory_name      VARCHAR(100),
    region              VARCHAR(50),                -- Northeast | Southeast | Midwest | West | Southwest
    state               VARCHAR(2),
    msa                 VARCHAR(100),               -- Metro Statistical Area
    account_tier        VARCHAR(20),                -- Tier 1 | Tier 2 | Tier 3
    segment             VARCHAR(50),                -- Integrated | Community | Academic | GPO
    is_340b             BOOLEAN         DEFAULT FALSE,
    is_active           BOOLEAN         DEFAULT TRUE,
    created_at          TIMESTAMP_NTZ,
    updated_at          TIMESTAMP_NTZ,
    PRIMARY KEY (account_id)
);

-- ── TABLE 2: Brand Sales at Account Level ─────────────────────────────────────
CREATE OR REPLACE TABLE OASIS_MART.BRAND_SALES_ACCOUNT (
    account_id          VARCHAR(50)     NOT NULL,
    brand_name          VARCHAR(50)     NOT NULL,   -- LORBRENA | BRAFTOVI | MEKTOVI | etc.
    indication          VARCHAR(50),                -- NSCLC_1L | NSCLC_2L | CRC | MELANOMA
    period_key          DATE            NOT NULL,   -- first day of month, monthly grain
    trx_volume          NUMBER(12,2),               -- total prescriptions (all fills)
    nrx_volume          NUMBER(12,2),               -- new-to-brand prescriptions (first fills only)
    net_sales_usd       NUMBER(18,2),               -- net revenue after rebates and returns
    gross_sales_usd     NUMBER(18,2),
    units               NUMBER(12,2),
    days_of_therapy     NUMBER(12,2),
    FOREIGN KEY (account_id) REFERENCES OASIS_MART.ACCOUNT_HIERARCHY(account_id)
);

-- ── TABLE 3: Market Share ─────────────────────────────────────────────────────
CREATE OR REPLACE TABLE OASIS_MART.MARKET_SHARE_ACCOUNT (
    account_id          VARCHAR(50)     NOT NULL,
    brand_name          VARCHAR(50)     NOT NULL,
    indication          VARCHAR(50),
    period_key          DATE            NOT NULL,
    pfizer_share_pct    FLOAT,                      -- 0.0 to 1.0
    competitor_1_share  FLOAT,                      -- [ASSUMPTION] Comp A
    competitor_2_share  FLOAT,                      -- [ASSUMPTION] Comp B
    competitor_3_share  FLOAT,                      -- [ASSUMPTION] Comp C
    competitor_1_name   VARCHAR(50),
    competitor_2_name   VARCHAR(50),
    competitor_3_name   VARCHAR(50),
    total_market_trx    NUMBER(12,2),
    FOREIGN KEY (account_id) REFERENCES OASIS_MART.ACCOUNT_HIERARCHY(account_id)
);

-- ── TABLE 4: Portfolio Summary (pre-aggregated) ───────────────────────────────
CREATE OR REPLACE TABLE OASIS_MART.PORTFOLIO_SUMMARY_MONTHLY (
    period_key                  DATE        NOT NULL,
    account_id                  VARCHAR(50) NOT NULL,
    total_portfolio_netsales    NUMBER(18,2),
    portfolio_trx_total         NUMBER(12,2),
    brand_count_active          NUMBER(4),          -- # PFE brands with TRx > 0
    portfolio_concentration_pct FLOAT,              -- account revenue / national total
    is_at_risk                  BOOLEAN,            -- revenue decline >10% YoY OR share loss >5pp in 3M
    FOREIGN KEY (account_id) REFERENCES OASIS_MART.ACCOUNT_HIERARCHY(account_id)
);

-- ── TABLE 5: Account Targets ──────────────────────────────────────────────────
CREATE OR REPLACE TABLE OASIS_MART.ACCOUNT_TARGETS (
    account_id          VARCHAR(50)     NOT NULL,
    brand_name          VARCHAR(50)     NOT NULL,
    period_key          DATE            NOT NULL,
    trx_target          NUMBER(12,2),
    netsales_target     NUMBER(18,2),
    target_tier         VARCHAR(20),
    priority_flag       BOOLEAN         DEFAULT FALSE,
    FOREIGN KEY (account_id) REFERENCES OASIS_MART.ACCOUNT_HIERARCHY(account_id)
);

-- ── TABLE 6: Data Refresh Log ─────────────────────────────────────────────────
CREATE OR REPLACE TABLE OASIS_MART.DATA_REFRESH_LOG (
    refresh_id          NUMBER AUTOINCREMENT,
    refresh_timestamp   TIMESTAMP_NTZ   DEFAULT CURRENT_TIMESTAMP,
    source_system       VARCHAR(100),
    records_loaded      NUMBER,
    status              VARCHAR(20),
    notes               VARCHAR(500)
);
```

### 2.2 Key Business Logic — Computed Columns and Views

```sql
-- ── VIEW: At-Risk Accounts (used by Module 6) ─────────────────────────────────
CREATE OR REPLACE VIEW OASIS_MART.V_AT_RISK_ACCOUNTS AS
WITH revenue_yoy AS (
    SELECT
        account_id,
        SUM(CASE WHEN period_key >= DATEADD('month', -12, CURRENT_DATE)
                 THEN net_sales_usd ELSE 0 END)  AS rev_12m,
        SUM(CASE WHEN period_key >= DATEADD('month', -24, CURRENT_DATE)
                 AND period_key <  DATEADD('month', -12, CURRENT_DATE)
                 THEN net_sales_usd ELSE 0 END)  AS rev_prior_12m
    FROM OASIS_MART.BRAND_SALES_ACCOUNT
    GROUP BY 1
),
share_trend AS (
    SELECT
        account_id,
        brand_name,
        AVG(CASE WHEN period_key >= DATEADD('month', -3, CURRENT_DATE)
                 THEN pfizer_share_pct END)       AS share_3m,
        AVG(CASE WHEN period_key >= DATEADD('month', -6, CURRENT_DATE)
                 AND period_key <  DATEADD('month', -3, CURRENT_DATE)
                 THEN pfizer_share_pct END)       AS share_prior_3m
    FROM OASIS_MART.MARKET_SHARE_ACCOUNT
    GROUP BY 1, 2
)
SELECT
    r.account_id,
    ah.account_name,
    ah.account_tier,
    ah.segment,
    r.rev_12m,
    r.rev_prior_12m,
    CASE WHEN r.rev_prior_12m > 0
         THEN (r.rev_12m - r.rev_prior_12m) / r.rev_prior_12m
         ELSE NULL END                            AS revenue_yoy_pct,
    MIN(s.share_3m - s.share_prior_3m)           AS worst_share_change_pp,
    -- [ASSUMPTION] At-risk = >10% revenue decline OR >5pp share loss in 3M
    CASE WHEN (r.rev_12m - r.rev_prior_12m) / NULLIF(r.rev_prior_12m, 0) < -0.10
              OR MIN(s.share_3m - s.share_prior_3m) < -0.05
         THEN TRUE ELSE FALSE END                 AS is_at_risk
FROM revenue_yoy r
JOIN OASIS_MART.ACCOUNT_HIERARCHY ah ON r.account_id = ah.account_id
LEFT JOIN share_trend s ON r.account_id = s.account_id
GROUP BY 1, 2, 3, 4, 5, 6, 7;

-- ── VIEW: Portfolio Pareto (used by Module 6) ─────────────────────────────────
CREATE OR REPLACE VIEW OASIS_MART.V_PORTFOLIO_PARETO AS
WITH ranked AS (
    SELECT
        account_id,
        SUM(net_sales_usd)                          AS account_revenue,
        SUM(SUM(net_sales_usd)) OVER ()             AS total_revenue,
        RANK() OVER (ORDER BY SUM(net_sales_usd) DESC) AS revenue_rank
    FROM OASIS_MART.BRAND_SALES_ACCOUNT
    WHERE period_key >= DATEADD('month', -12, CURRENT_DATE)
    GROUP BY 1
)
SELECT
    account_id,
    account_revenue,
    total_revenue,
    revenue_rank,
    account_revenue / total_revenue                 AS revenue_share_pct,
    SUM(account_revenue / total_revenue)
        OVER (ORDER BY revenue_rank
              ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW) AS cumulative_share_pct,
    revenue_rank::FLOAT / COUNT(*) OVER ()          AS cumulative_account_pct
FROM ranked;

-- ── VIEW: Account New/Lost by Quarter ─────────────────────────────────────────
CREATE OR REPLACE VIEW OASIS_MART.V_ACCOUNT_NEW_LOST AS
WITH quarterly_active AS (
    SELECT
        account_id,
        DATE_TRUNC('quarter', period_key)  AS quarter_key,
        SUM(trx_volume)                    AS quarterly_trx
    FROM OASIS_MART.BRAND_SALES_ACCOUNT
    GROUP BY 1, 2
),
account_status AS (
    SELECT
        cur.account_id,
        cur.quarter_key,
        cur.quarterly_trx                  AS current_trx,
        prev.quarterly_trx                 AS prev_trx,
        CASE WHEN prev.quarterly_trx IS NULL AND cur.quarterly_trx > 0 THEN 'NEW'
             WHEN cur.quarterly_trx IS NULL AND prev.quarterly_trx > 0 THEN 'LOST'
             ELSE 'RETAINED' END           AS account_status
    FROM quarterly_active cur
    FULL OUTER JOIN quarterly_active prev
        ON cur.account_id = prev.account_id
        AND cur.quarter_key = DATEADD('quarter', 1, prev.quarter_key)
)
SELECT
    quarter_key,
    account_status,
    COUNT(account_id)  AS account_count
FROM account_status
WHERE account_status IN ('NEW', 'LOST')
GROUP BY 1, 2;
```

---

## SECTION 3 — FILE STRUCTURE

Generate the following file and folder structure exactly:

```
oasis_app/
│
├── streamlit_app.py                    # Main entry point — navigation shell
├── environment.yml                     # Snowflake SiS package list
│
├── config/
│   ├── __init__.py
│   ├── app_config.py                   # Constants, colors, brand list
│   └── snowflake_connection.py         # Session management
│
├── pages/
│   ├── __init__.py
│   ├── 01_portfolio_command.py         # Module 1 — CRAWL
│   ├── 02_account_universe.py          # Module 2 — CRAWL
│   ├── 03_account_deep_dive.py         # Module 3 — CRAWL
│   ├── 04_brand_performance.py         # Module 4 — CRAWL
│   ├── 05_geographic_view.py           # Module 5 — WALK
│   ├── 06_concentration_risk.py        # Module 6 — WALK
│   ├── 07_competitive_intel.py         # Module 7 — WALK
│   └── 08_ai_query.py                  # Module 8 — WALK
│
├── components/
│   ├── __init__.py
│   ├── global_filters.py               # Shared filter bar (period, brand, region, segment, tier, 340B)
│   ├── kpi_tiles.py                    # Reusable metric card renderer
│   ├── account_table.py                # Sortable/searchable account data table
│   ├── chart_helpers.py                # Plotly wrappers with OASIS styling applied
│   └── cortex_panel.py                 # Snowflake Cortex NL query UI component
│
├── queries/
│   ├── __init__.py
│   ├── portfolio_queries.py            # SQL for Module 1
│   ├── account_queries.py              # SQL for Modules 2 & 3
│   ├── brand_queries.py                # SQL for Module 4
│   ├── geo_queries.py                  # SQL for Module 5
│   ├── risk_queries.py                 # SQL for Module 6
│   ├── competitive_queries.py          # SQL for Module 7
│   └── cortex_queries.py              # Cortex Analyst + COMPLETE() wrappers
│
├── semantic_model/
│   └── oasis_semantic_model.yaml       # Cortex Analyst semantic model
│
└── assets/
    └── styles.css                      # Custom CSS injected via st.markdown
```

---

## SECTION 4 — MAIN ENTRY POINT

```python
# streamlit_app.py
import streamlit as st
from config.snowflake_connection import get_session
from config.app_config import APP_TITLE, APP_SUBTITLE, OASIS_COLORS
from components.global_filters import render_global_filters

st.set_page_config(
    page_title=APP_TITLE,
    page_icon="🔵",
    layout="wide",
    initial_sidebar_state="expanded",
)

# Inject custom CSS
with open("assets/styles.css") as f:
    st.markdown(f"<style>{f.read()}</style>", unsafe_allow_html=True)

session = get_session()

# Store session and filters in st.session_state for cross-page access
if "session" not in st.session_state:
    st.session_state["session"] = session

# Sidebar navigation
with st.sidebar:
    st.image("assets/pfizer_logo.png", width=120)
    st.markdown(f"### {APP_TITLE}")
    st.caption(APP_SUBTITLE)
    st.divider()

    st.markdown("**Core Views** *(CRAWL)*")
    page = st.radio(
        label="Navigate",
        options=[
            "🏠  Portfolio Command",
            "🔍  Account Universe",
            "🏥  Account Deep Dive",
            "💊  Brand Performance",
            "🗺️  Geographic View",
            "⚠️  Concentration & Risk",
            "🏆  Competitive Intel",
            "✦   AI Query (Cortex)",
        ],
        label_visibility="collapsed",
    )

    st.divider()
    st.caption("🟢 CRAWL = S2 2026 MVP")
    st.caption("🟡 WALK = S1 2027")
    st.caption("🟣 RUN  = S2 2027+")

# Global filters — rendered above all pages
filters = render_global_filters()
st.session_state["filters"] = filters

# Route to selected page module
if "Portfolio Command"    in page: from pages import p01_portfolio_command  as pg
elif "Account Universe"   in page: from pages import p02_account_universe   as pg
elif "Account Deep Dive"  in page: from pages import p03_account_deep_dive  as pg
elif "Brand Performance"  in page: from pages import p04_brand_performance  as pg
elif "Geographic View"    in page: from pages import p05_geographic_view    as pg
elif "Concentration"      in page: from pages import p06_concentration_risk as pg
elif "Competitive"        in page: from pages import p07_competitive_intel  as pg
elif "AI Query"           in page: from pages import p08_ai_query           as pg

pg.render(session, filters)
```

---

## SECTION 5 — SHARED COMPONENTS

### 5.1 Global Filters

```python
# components/global_filters.py
import streamlit as st
from config.app_config import BRANDS, REGIONS, SEGMENTS, TIERS, PERIODS

def render_global_filters() -> dict:
    """
    Renders a persistent horizontal filter bar above all pages.
    Returns a dict of active filter values consumed by every query function.
    """
    col1, col2, col3, col4, col5, col6, col7 = st.columns([2, 2, 2, 2, 2, 2, 1])

    with col1:
        period = st.selectbox(
            "Time Period",
            options=list(PERIODS.keys()),
            index=2,                        # default: 12M
            key="filter_period",
        )
    with col2:
        brand = st.multiselect(
            "Brand",
            options=["All Portfolio"] + BRANDS,
            default=["All Portfolio"],
            key="filter_brand",
        )
    with col3:
        region = st.selectbox(
            "Region",
            options=["All"] + REGIONS,
            key="filter_region",
        )
    with col4:
        segment = st.multiselect(
            "Segment",
            options=["All"] + SEGMENTS,
            default=["All"],
            key="filter_segment",
        )
    with col5:
        tier = st.multiselect(
            "Account Tier",
            options=["All"] + TIERS,
            default=["All"],
            key="filter_tier",
        )
    with col6:
        is_340b = st.selectbox(
            "340B",
            options=["All", "340B Only", "Exclude 340B"],
            key="filter_340b",
        )
    with col7:
        if st.button("Reset", type="secondary"):
            for key in ["filter_period","filter_brand","filter_region",
                        "filter_segment","filter_tier","filter_340b"]:
                if key in st.session_state:
                    del st.session_state[key]
            st.rerun()

    return {
        "period_months": PERIODS[period],
        "period_label":  period,
        "brand":         brand,
        "region":        region,
        "segment":       segment,
        "tier":          tier,
        "is_340b":       is_340b,
    }
```

### 5.2 Filter SQL Builder

```python
# components/global_filters.py (continued)

def build_filter_sql(filters: dict, table_alias: str = "ah") -> str:
    """
    Converts the filters dict into a SQL WHERE clause fragment.
    table_alias should reference the ACCOUNT_HIERARCHY table alias in the query.
    """
    clauses = []

    # Time period — always applied to bsa.period_key, not account table
    clauses.append(
        f"bsa.period_key >= DATEADD('month', -{filters['period_months']}, CURRENT_DATE)"
    )

    # Brand filter
    if "All Portfolio" not in filters["brand"] and filters["brand"]:
        brands_str = ", ".join([f"'{b}'" for b in filters["brand"]])
        clauses.append(f"bsa.brand_name IN ({brands_str})")

    # Region filter
    if filters["region"] != "All":
        clauses.append(f"{table_alias}.region = '{filters['region']}'")

    # Segment filter
    if "All" not in filters["segment"] and filters["segment"]:
        segs_str = ", ".join([f"'{s}'" for s in filters["segment"]])
        clauses.append(f"{table_alias}.segment IN ({segs_str})")

    # Tier filter
    if "All" not in filters["tier"] and filters["tier"]:
        tiers_str = ", ".join([f"'{t}'" for t in filters["tier"]])
        clauses.append(f"{table_alias}.account_tier IN ({tiers_str})")

    # 340B filter
    if filters["is_340b"] == "340B Only":
        clauses.append(f"{table_alias}.is_340b = TRUE")
    elif filters["is_340b"] == "Exclude 340B":
        clauses.append(f"{table_alias}.is_340b = FALSE")

    return " AND ".join(clauses)
```

### 5.3 KPI Tile Renderer

```python
# components/kpi_tiles.py
import streamlit as st

def render_kpi_tile(label: str, value: str, delta: str,
                    delta_direction: str = "neutral",
                    color_accent: str = "blue") -> None:
    """
    Renders a single KPI tile using st.metric with custom CSS class injection.

    delta_direction: "up" | "down" | "neutral"
    color_accent:    "blue" | "green" | "amber" | "red" | "teal"
    """
    delta_prefix = {"up": "▲ ", "down": "▼ ", "neutral": "→ "}.get(delta_direction, "")
    st.metric(
        label=label,
        value=value,
        delta=f"{delta_prefix}{delta}",
        delta_color="normal" if delta_direction == "up"
                    else "inverse" if delta_direction == "down"
                    else "off",
    )


def render_kpi_row(metrics: list[dict]) -> None:
    """
    Renders a full row of KPI tiles.

    metrics: list of dicts, each with keys:
        label, value, delta, delta_direction, color_accent
    """
    cols = st.columns(len(metrics))
    for col, m in zip(cols, metrics):
        with col:
            render_kpi_tile(
                label=m["label"],
                value=m["value"],
                delta=m["delta"],
                delta_direction=m.get("delta_direction", "neutral"),
                color_accent=m.get("color_accent", "blue"),
            )
```

### 5.4 Chart Style Helper

```python
# components/chart_helpers.py
import plotly.graph_objects as go
import plotly.express as px
from config.app_config import OASIS_COLORS, BRAND_COLORS

FONT_FAMILY = "IBM Plex Sans, Helvetica Neue, Arial, sans-serif"
MONO_FONT   = "IBM Plex Mono, Courier New, monospace"

def apply_oasis_theme(fig: go.Figure, title: str = "", subtitle: str = "") -> go.Figure:
    """Applies Pfizer OASIS brand styling to any Plotly figure."""
    fig.update_layout(
        title=dict(
            text=f"<b>{title}</b><br><sup>{subtitle}</sup>" if subtitle else f"<b>{title}</b>",
            font=dict(family=FONT_FAMILY, size=13, color=OASIS_COLORS["text_primary"]),
            x=0,
            xanchor="left",
        ),
        font=dict(family=FONT_FAMILY, size=11, color=OASIS_COLORS["text_primary"]),
        paper_bgcolor="rgba(0,0,0,0)",
        plot_bgcolor="rgba(0,0,0,0)",
        legend=dict(
            font=dict(size=10),
            bgcolor="rgba(0,0,0,0)",
            bordercolor=OASIS_COLORS["border"],
            borderwidth=1,
        ),
        margin=dict(l=8, r=8, t=48, b=8),
        hoverlabel=dict(
            bgcolor=OASIS_COLORS["text_primary"],
            font_size=11,
            font_family=FONT_FAMILY,
        ),
    )
    fig.update_xaxes(
        gridcolor=OASIS_COLORS["border"],
        linecolor=OASIS_COLORS["border"],
        tickfont=dict(size=10, color=OASIS_COLORS["text_muted"]),
        showgrid=True,
    )
    fig.update_yaxes(
        gridcolor=OASIS_COLORS["border"],
        linecolor=OASIS_COLORS["border"],
        tickfont=dict(size=10, color=OASIS_COLORS["text_muted"]),
        showgrid=True,
    )
    return fig


def brand_color_sequence(brands: list[str]) -> list[str]:
    """Returns ordered hex color list for a given list of brand names."""
    return [BRAND_COLORS.get(b, OASIS_COLORS["pfizer_light"]) for b in brands]
```

---

## SECTION 6 — QUERY LAYER

### 6.1 Query Conventions

All query functions must follow these rules:
1. Accept `_session` (Snowpark session) and `filters` (dict) as arguments
2. Use `@st.cache_data(ttl=3600)` decorator for all read queries
3. Return a `pandas.DataFrame`
4. Use parameterized SQL via f-strings with the `build_filter_sql()` helper
5. Never use `SELECT *` — always name columns explicitly
6. All monetary values returned in USD millions (`/ 1e6`) for display
7. All share values returned as floats 0.0–1.0 and multiplied by 100 for display

### 6.2 Portfolio Query Functions (Module 1)

```python
# queries/portfolio_queries.py
import streamlit as st
import pandas as pd
from components.global_filters import build_filter_sql

@st.cache_data(ttl=3600)
def get_portfolio_revenue_trend(_session, filters: dict) -> pd.DataFrame:
    """
    Returns monthly net sales by brand for the selected period.
    Used by: Chart 1.1 — Portfolio Revenue Trend by Brand
    """
    where = build_filter_sql(filters)
    sql = f"""
        SELECT
            DATE_TRUNC('month', bsa.period_key)     AS month,
            bsa.brand_name,
            SUM(bsa.net_sales_usd) / 1e6            AS net_sales_m
        FROM OASIS_MART.BRAND_SALES_ACCOUNT bsa
        JOIN OASIS_MART.ACCOUNT_HIERARCHY    ah  ON bsa.account_id = ah.account_id
        WHERE {where}
        GROUP BY 1, 2
        ORDER BY 1, 2
    """
    return _session.sql(sql).to_pandas()


@st.cache_data(ttl=3600)
def get_account_concentration(_session, filters: dict, top_n: int = 50) -> pd.DataFrame:
    """
    Returns top N accounts by portfolio revenue share.
    Used by: Chart 1.2 — Account Concentration Top 50
    """
    where = build_filter_sql(filters)
    sql = f"""
        WITH national_total AS (
            SELECT SUM(bsa.net_sales_usd) AS total_rev
            FROM OASIS_MART.BRAND_SALES_ACCOUNT bsa
            JOIN OASIS_MART.ACCOUNT_HIERARCHY   ah ON bsa.account_id = ah.account_id
            WHERE {where}
        )
        SELECT
            ah.account_name,
            ah.account_tier,
            ah.segment,
            SUM(bsa.net_sales_usd) / 1e6                            AS account_rev_m,
            SUM(bsa.net_sales_usd) / nt.total_rev                   AS portfolio_pct
        FROM OASIS_MART.BRAND_SALES_ACCOUNT bsa
        JOIN OASIS_MART.ACCOUNT_HIERARCHY   ah ON bsa.account_id = ah.account_id
        CROSS JOIN national_total nt
        WHERE {where}
        GROUP BY 1, 2, 3, nt.total_rev
        ORDER BY account_rev_m DESC
        LIMIT {top_n}
    """
    return _session.sql(sql).to_pandas()


@st.cache_data(ttl=3600)
def get_portfolio_mix(_session, filters: dict) -> pd.DataFrame:
    """
    Returns monthly revenue % share per brand.
    Used by: Chart 1.3 — Portfolio Mix by Brand (donut)
    """
    where = build_filter_sql(filters)
    sql = f"""
        WITH period_total AS (
            SELECT SUM(bsa.net_sales_usd) AS total_rev
            FROM OASIS_MART.BRAND_SALES_ACCOUNT bsa
            JOIN OASIS_MART.ACCOUNT_HIERARCHY   ah ON bsa.account_id = ah.account_id
            WHERE {where}
        )
        SELECT
            bsa.brand_name,
            SUM(bsa.net_sales_usd) / 1e6                AS rev_m,
            SUM(bsa.net_sales_usd) / pt.total_rev       AS brand_share_pct
        FROM OASIS_MART.BRAND_SALES_ACCOUNT bsa
        JOIN OASIS_MART.ACCOUNT_HIERARCHY   ah ON bsa.account_id = ah.account_id
        CROSS JOIN period_total pt
        WHERE {where}
        GROUP BY 1, pt.total_rev
        ORDER BY rev_m DESC
    """
    return _session.sql(sql).to_pandas()


@st.cache_data(ttl=3600)
def get_geo_revenue(_session, filters: dict) -> pd.DataFrame:
    """
    Returns portfolio revenue by state for choropleth.
    Used by: Chart 1.4 — Geographic Revenue Heatmap
    """
    where = build_filter_sql(filters)
    sql = f"""
        SELECT
            ah.state,
            ah.region,
            SUM(bsa.net_sales_usd) / 1e6    AS net_sales_m,
            COUNT(DISTINCT bsa.account_id)  AS account_count
        FROM OASIS_MART.BRAND_SALES_ACCOUNT bsa
        JOIN OASIS_MART.ACCOUNT_HIERARCHY   ah ON bsa.account_id = ah.account_id
        WHERE {where}
        GROUP BY 1, 2
        ORDER BY net_sales_m DESC
    """
    return _session.sql(sql).to_pandas()


@st.cache_data(ttl=3600)
def get_portfolio_kpis(_session, filters: dict) -> dict:
    """
    Returns scalar KPI values for the scorecard tiles.
    Used by: Chart 1.5 — Portfolio Health Scorecard
    """
    where = build_filter_sql(filters)
    # Prior period uses same window shifted back by period_months
    p = filters["period_months"]
    sql = f"""
        WITH current_period AS (
            SELECT
                SUM(bsa.net_sales_usd) / 1e6    AS net_sales_m,
                SUM(bsa.trx_volume)             AS trx_total,
                COUNT(DISTINCT bsa.account_id)  AS active_accounts
            FROM OASIS_MART.BRAND_SALES_ACCOUNT bsa
            JOIN OASIS_MART.ACCOUNT_HIERARCHY   ah ON bsa.account_id = ah.account_id
            WHERE {where}
        ),
        prior_period AS (
            SELECT
                SUM(bsa.net_sales_usd) / 1e6    AS net_sales_m_prior,
                SUM(bsa.trx_volume)             AS trx_prior
            FROM OASIS_MART.BRAND_SALES_ACCOUNT bsa
            JOIN OASIS_MART.ACCOUNT_HIERARCHY   ah ON bsa.account_id = ah.account_id
            WHERE bsa.period_key >= DATEADD('month', -{p*2}, CURRENT_DATE)
              AND bsa.period_key <  DATEADD('month', -{p},   CURRENT_DATE)
        ),
        at_risk AS (
            SELECT COUNT(*) AS at_risk_count
            FROM OASIS_MART.V_AT_RISK_ACCOUNTS
            WHERE is_at_risk = TRUE
        )
        SELECT
            cp.net_sales_m,
            cp.trx_total,
            cp.active_accounts,
            pp.net_sales_m_prior,
            pp.trx_prior,
            ar.at_risk_count
        FROM current_period cp
        CROSS JOIN prior_period pp
        CROSS JOIN at_risk ar
    """
    row = _session.sql(sql).collect()[0]
    return {
        "net_sales_m":       round(row["NET_SALES_M"], 1),
        "trx_total":         int(row["TRX_TOTAL"]),
        "active_accounts":   int(row["ACTIVE_ACCOUNTS"]),
        "at_risk_count":     int(row["AT_RISK_COUNT"]),
        "net_sales_delta":   round((row["NET_SALES_M"] - row["NET_SALES_M_PRIOR"]) /
                                    max(row["NET_SALES_M_PRIOR"], 0.01) * 100, 1),
        "trx_delta":         round((row["TRX_TOTAL"] - row["TRX_PRIOR"]) /
                                    max(row["TRX_PRIOR"], 1) * 100, 1),
    }
```

### 6.3 Account Query Functions (Modules 2 & 3)

```python
# queries/account_queries.py
import streamlit as st
import pandas as pd
from components.global_filters import build_filter_sql

@st.cache_data(ttl=3600)
def get_account_ranking(_session, filters: dict) -> pd.DataFrame:
    """
    Full ranked account table with portfolio metrics.
    Used by: Chart 2.1 — Account Ranking Table
    """
    where = build_filter_sql(filters)
    sql = f"""
        WITH national_total AS (
            SELECT SUM(net_sales_usd) AS total_rev
            FROM OASIS_MART.BRAND_SALES_ACCOUNT bsa
            JOIN OASIS_MART.ACCOUNT_HIERARCHY   ah ON bsa.account_id = ah.account_id
            WHERE {where}
        ),
        prior_rev AS (
            SELECT
                bsa.account_id,
                SUM(bsa.net_sales_usd) AS prior_rev
            FROM OASIS_MART.BRAND_SALES_ACCOUNT bsa
            WHERE bsa.period_key >= DATEADD('month', -{filters['period_months']*2}, CURRENT_DATE)
              AND bsa.period_key <  DATEADD('month', -{filters['period_months']},   CURRENT_DATE)
            GROUP BY 1
        )
        SELECT
            ROW_NUMBER() OVER (ORDER BY SUM(bsa.net_sales_usd) DESC) AS rank,
            ah.account_name,
            ah.system_name,
            ah.segment,
            ah.account_tier,
            SUM(bsa.net_sales_usd) / 1e6                            AS portfolio_rev_m,
            SUM(bsa.trx_volume)                                     AS trx_total,
            SUM(bsa.net_sales_usd) / nt.total_rev                   AS portfolio_pct,
            (SUM(bsa.net_sales_usd) - pr.prior_rev) /
                NULLIF(pr.prior_rev, 0)                             AS yoy_delta,
            AVG(ms.pfizer_share_pct)                                AS avg_share,
            var.is_at_risk,
            ah.is_340b,
            ah.account_id
        FROM OASIS_MART.BRAND_SALES_ACCOUNT bsa
        JOIN OASIS_MART.ACCOUNT_HIERARCHY   ah  ON bsa.account_id  = ah.account_id
        CROSS JOIN national_total nt
        LEFT JOIN prior_rev pr                  ON bsa.account_id  = pr.account_id
        LEFT JOIN OASIS_MART.MARKET_SHARE_ACCOUNT ms
            ON bsa.account_id = ms.account_id
           AND bsa.brand_name = ms.brand_name
           AND bsa.period_key = ms.period_key
        LEFT JOIN OASIS_MART.V_AT_RISK_ACCOUNTS var ON bsa.account_id = var.account_id
        WHERE {where}
        GROUP BY ah.account_name, ah.system_name, ah.segment, ah.account_tier,
                 nt.total_rev, pr.prior_rev, var.is_at_risk, ah.is_340b, ah.account_id
        ORDER BY portfolio_rev_m DESC
    """
    return _session.sql(sql).to_pandas()


@st.cache_data(ttl=3600)
def get_account_segment_treemap(_session, filters: dict) -> pd.DataFrame:
    """Used by: Chart 2.2 — Account Segment Distribution Treemap"""
    where = build_filter_sql(filters)
    sql = f"""
        SELECT
            ah.segment,
            SUM(bsa.net_sales_usd) / 1e6    AS rev_m,
            COUNT(DISTINCT bsa.account_id)  AS account_count
        FROM OASIS_MART.BRAND_SALES_ACCOUNT bsa
        JOIN OASIS_MART.ACCOUNT_HIERARCHY   ah ON bsa.account_id = ah.account_id
        WHERE {where}
        GROUP BY 1
        ORDER BY rev_m DESC
    """
    return _session.sql(sql).to_pandas()


@st.cache_data(ttl=3600)
def get_tier_waterfall(_session, filters: dict) -> pd.DataFrame:
    """Used by: Chart 2.3 — Account Tier Revenue Waterfall"""
    where = build_filter_sql(filters)
    sql = f"""
        SELECT
            COALESCE(ah.account_tier, 'Untiered')   AS tier,
            SUM(bsa.net_sales_usd) / 1e6            AS rev_m,
            COUNT(DISTINCT bsa.account_id)          AS account_count
        FROM OASIS_MART.BRAND_SALES_ACCOUNT bsa
        JOIN OASIS_MART.ACCOUNT_HIERARCHY   ah ON bsa.account_id = ah.account_id
        WHERE {where}
        GROUP BY 1
        ORDER BY rev_m DESC
    """
    return _session.sql(sql).to_pandas()


@st.cache_data(ttl=3600)
def get_new_lost_accounts(_session) -> pd.DataFrame:
    """Used by: Chart 2.4 — New vs. Lost Accounts by Quarter"""
    sql = """
        SELECT quarter_key, account_status, account_count
        FROM OASIS_MART.V_ACCOUNT_NEW_LOST
        WHERE quarter_key >= DATEADD('quarter', -6, CURRENT_DATE)
        ORDER BY quarter_key, account_status
    """
    return _session.sql(sql).to_pandas()


@st.cache_data(ttl=3600)
def get_340b_split(_session, filters: dict) -> pd.DataFrame:
    """Used by: Chart 2.5 — 340B Account Share"""
    where = build_filter_sql(filters)
    sql = f"""
        SELECT
            ah.is_340b,
            ah.account_name,
            SUM(bsa.net_sales_usd) / 1e6    AS rev_m
        FROM OASIS_MART.BRAND_SALES_ACCOUNT bsa
        JOIN OASIS_MART.ACCOUNT_HIERARCHY   ah ON bsa.account_id = ah.account_id
        WHERE {where}
        GROUP BY 1, 2
        ORDER BY is_340b DESC, rev_m DESC
    """
    return _session.sql(sql).to_pandas()


@st.cache_data(ttl=3600)
def get_account_profile(_session, account_id: str) -> dict:
    """
    Returns header metadata for a single account.
    Used by: Chart 3.1 — Account Header Card
    """
    sql = f"""
        SELECT
            ah.account_id,
            ah.account_name,
            ah.system_name,
            ah.account_tier,
            ah.segment,
            ah.account_type,
            ah.is_340b,
            ah.territory_name,
            ah.region,
            ah.state
        FROM OASIS_MART.ACCOUNT_HIERARCHY ah
        WHERE ah.account_id = '{account_id}'
    """
    row = _session.sql(sql).collect()[0]
    return dict(row.as_dict())


@st.cache_data(ttl=3600)
def get_account_brand_portfolio(_session, account_id: str, filters: dict) -> pd.DataFrame:
    """
    Returns brand-level TRx for current and prior period at one account.
    Used by: Chart 3.2 — Brand Portfolio at Account
    """
    p = filters["period_months"]
    sql = f"""
        SELECT
            brand_name,
            SUM(CASE WHEN period_key >= DATEADD('month', -{p}, CURRENT_DATE)
                     THEN trx_volume ELSE 0 END)    AS current_trx,
            SUM(CASE WHEN period_key >= DATEADD('month', -{p*2}, CURRENT_DATE)
                     AND period_key <  DATEADD('month', -{p},    CURRENT_DATE)
                     THEN trx_volume ELSE 0 END)    AS prior_trx
        FROM OASIS_MART.BRAND_SALES_ACCOUNT
        WHERE account_id = '{account_id}'
        GROUP BY 1
        ORDER BY current_trx DESC
    """
    return _session.sql(sql).to_pandas()


@st.cache_data(ttl=3600)
def get_account_share_trend(_session, account_id: str) -> pd.DataFrame:
    """
    Returns 24-month share trend per brand for one account.
    Used by: Chart 3.3 — Share Trend by Brand
    """
    sql = f"""
        SELECT
            DATE_TRUNC('month', period_key) AS month,
            brand_name,
            pfizer_share_pct * 100          AS share_pct
        FROM OASIS_MART.MARKET_SHARE_ACCOUNT
        WHERE account_id = '{account_id}'
          AND period_key >= DATEADD('month', -24, CURRENT_DATE)
        ORDER BY 1, 2
    """
    return _session.sql(sql).to_pandas()


@st.cache_data(ttl=3600)
def get_account_vs_national_benchmark(_session, account_id: str, filters: dict) -> pd.DataFrame:
    """
    Returns per-brand share for one account vs. national average.
    Used by: Chart 3.4 — Account vs. National Benchmark (radar)
    """
    where = build_filter_sql(filters)
    sql = f"""
        SELECT
            ms.brand_name,
            AVG(CASE WHEN ms.account_id = '{account_id}'
                     THEN ms.pfizer_share_pct * 100 END)    AS account_share,
            AVG(ms.pfizer_share_pct * 100)                  AS national_avg_share
        FROM OASIS_MART.MARKET_SHARE_ACCOUNT ms
        JOIN OASIS_MART.BRAND_SALES_ACCOUNT  bsa
            ON ms.account_id = bsa.account_id
           AND ms.brand_name  = bsa.brand_name
           AND ms.period_key  = bsa.period_key
        JOIN OASIS_MART.ACCOUNT_HIERARCHY ah ON ms.account_id = ah.account_id
        WHERE {where}
        GROUP BY 1
    """
    return _session.sql(sql).to_pandas()


@st.cache_data(ttl=3600)
def get_account_site_hierarchy(_session, account_id: str) -> pd.DataFrame:
    """
    Returns parent system + all child accounts with revenue.
    Used by: Chart 3.5 — Site Hierarchy View
    """
    sql = f"""
        WITH target_account AS (
            SELECT parent_account_id, system_name
            FROM OASIS_MART.ACCOUNT_HIERARCHY
            WHERE account_id = '{account_id}'
        ),
        siblings AS (
            SELECT ah.account_id, ah.account_name, ah.account_tier,
                   ah.account_type, ah.is_340b, ah.state
            FROM OASIS_MART.ACCOUNT_HIERARCHY ah
            JOIN target_account ta
              ON ah.parent_account_id = ta.parent_account_id
              OR ah.account_id        = ta.parent_account_id
        )
        SELECT
            s.account_id,
            s.account_name,
            s.account_tier,
            s.account_type,
            s.is_340b,
            s.state,
            SUM(bsa.net_sales_usd) / 1e6    AS rev_m,
            SUM(bsa.trx_volume)             AS trx_total
        FROM siblings s
        LEFT JOIN OASIS_MART.BRAND_SALES_ACCOUNT bsa
            ON s.account_id = bsa.account_id
           AND bsa.period_key >= DATEADD('month', -12, CURRENT_DATE)
        GROUP BY 1, 2, 3, 4, 5, 6
        ORDER BY rev_m DESC NULLS LAST
    """
    return _session.sql(sql).to_pandas()
```

### 6.4 Brand Query Functions (Module 4)

```python
# queries/brand_queries.py
import streamlit as st
import pandas as pd
from components.global_filters import build_filter_sql

@st.cache_data(ttl=3600)
def get_brand_trx_vs_target(_session, filters: dict) -> pd.DataFrame:
    """Used by: Chart 4.1 — Brand TRx Trend vs. Target"""
    where = build_filter_sql(filters)
    sql = f"""
        SELECT
            DATE_TRUNC('month', bsa.period_key) AS month,
            SUM(bsa.trx_volume)                 AS actual_trx,
            SUM(t.trx_target)                   AS target_trx
        FROM OASIS_MART.BRAND_SALES_ACCOUNT bsa
        JOIN OASIS_MART.ACCOUNT_HIERARCHY   ah  ON bsa.account_id = ah.account_id
        LEFT JOIN OASIS_MART.ACCOUNT_TARGETS t
            ON bsa.account_id = t.account_id
           AND bsa.brand_name  = t.brand_name
           AND DATE_TRUNC('month', bsa.period_key) = DATE_TRUNC('month', t.period_key)
        WHERE {where}
        GROUP BY 1
        ORDER BY 1
    """
    return _session.sql(sql).to_pandas()


@st.cache_data(ttl=3600)
def get_brand_share_by_segment(_session, filters: dict) -> pd.DataFrame:
    """Used by: Chart 4.2 — Share of Voice by Account Segment"""
    where = build_filter_sql(filters)
    sql = f"""
        SELECT
            ah.segment,
            AVG(ms.pfizer_share_pct)        * 100 AS pfizer_share,
            AVG(ms.competitor_1_share)      * 100 AS comp_a_share,
            AVG(ms.competitor_2_share)      * 100 AS comp_b_share
        FROM OASIS_MART.MARKET_SHARE_ACCOUNT ms
        JOIN OASIS_MART.BRAND_SALES_ACCOUNT  bsa
            ON ms.account_id = bsa.account_id
           AND ms.brand_name  = bsa.brand_name
           AND ms.period_key  = bsa.period_key
        JOIN OASIS_MART.ACCOUNT_HIERARCHY ah ON ms.account_id = ah.account_id
        WHERE {where}
        GROUP BY 1
        ORDER BY pfizer_share DESC
    """
    return _session.sql(sql).to_pandas()


@st.cache_data(ttl=3600)
def get_top_accounts_for_brand(_session, filters: dict, top_n: int = 25) -> pd.DataFrame:
    """Used by: Chart 4.3 — Top Accounts for Brand"""
    where = build_filter_sql(filters)
    sql = f"""
        SELECT
            ah.account_name,
            ah.account_tier,
            SUM(bsa.trx_volume)             AS trx_total,
            SUM(bsa.net_sales_usd) / 1e6    AS rev_m
        FROM OASIS_MART.BRAND_SALES_ACCOUNT bsa
        JOIN OASIS_MART.ACCOUNT_HIERARCHY   ah ON bsa.account_id = ah.account_id
        WHERE {where}
        GROUP BY 1, 2
        ORDER BY trx_total DESC
        LIMIT {top_n}
    """
    return _session.sql(sql).to_pandas()


@st.cache_data(ttl=3600)
def get_brand_competitive_share_trend(_session, filters: dict) -> pd.DataFrame:
    """Used by: Chart 4.4 — Brand Market Share vs. Competitors"""
    where = build_filter_sql(filters)
    sql = f"""
        SELECT
            DATE_TRUNC('month', ms.period_key)  AS month,
            AVG(ms.pfizer_share_pct)   * 100    AS pfizer_share,
            AVG(ms.competitor_1_share) * 100    AS comp_a_share,
            AVG(ms.competitor_2_share) * 100    AS comp_b_share,
            AVG(ms.competitor_3_share) * 100    AS comp_c_share
        FROM OASIS_MART.MARKET_SHARE_ACCOUNT ms
        JOIN OASIS_MART.BRAND_SALES_ACCOUNT  bsa
            ON ms.account_id = bsa.account_id
           AND ms.brand_name  = bsa.brand_name
           AND ms.period_key  = bsa.period_key
        JOIN OASIS_MART.ACCOUNT_HIERARCHY ah ON ms.account_id = ah.account_id
        WHERE {where}
        GROUP BY 1
        ORDER BY 1
    """
    return _session.sql(sql).to_pandas()


@st.cache_data(ttl=3600)
def get_new_patient_starts_by_segment(_session, filters: dict) -> pd.DataFrame:
    """Used by: Chart 4.5 — New Patient Starts by Account Segment"""
    where = build_filter_sql(filters)
    sql = f"""
        SELECT
            DATE_TRUNC('month', bsa.period_key) AS month,
            ah.segment,
            SUM(bsa.nrx_volume)                 AS nrx_total
        FROM OASIS_MART.BRAND_SALES_ACCOUNT bsa
        JOIN OASIS_MART.ACCOUNT_HIERARCHY   ah ON bsa.account_id = ah.account_id
        WHERE {where}
        GROUP BY 1, 2
        ORDER BY 1, 2
    """
    return _session.sql(sql).to_pandas()
```

### 6.5 Risk Query Functions (Module 6)

```python
# queries/risk_queries.py
import streamlit as st
import pandas as pd
from components.global_filters import build_filter_sql

@st.cache_data(ttl=3600)
def get_pareto_data(_session, filters: dict) -> pd.DataFrame:
    """Used by: Chart 6.1 — Pareto Concentration Curve"""
    sql = """
        SELECT
            cumulative_account_pct  * 100 AS pct_accounts,
            cumulative_share_pct    * 100 AS pct_revenue
        FROM OASIS_MART.V_PORTFOLIO_PARETO
        ORDER BY cumulative_account_pct
    """
    return _session.sql(sql).to_pandas()


@st.cache_data(ttl=3600)
def get_at_risk_heatmap(_session, filters: dict) -> pd.DataFrame:
    """Used by: Chart 6.2 — At-Risk Account Heatmap"""
    where = build_filter_sql(filters)
    sql = f"""
        SELECT
            ah.account_name,
            ms.brand_name,
            AVG(ms.pfizer_share_pct) * 100    AS share_current,
            AVG(ms_prior.pfizer_share_pct) * 100 AS share_prior,
            (AVG(ms.pfizer_share_pct) - AVG(ms_prior.pfizer_share_pct)) * 100 AS share_delta_pp
        FROM OASIS_MART.MARKET_SHARE_ACCOUNT ms
        JOIN OASIS_MART.ACCOUNT_HIERARCHY ah ON ms.account_id = ah.account_id
        LEFT JOIN OASIS_MART.MARKET_SHARE_ACCOUNT ms_prior
            ON ms.account_id = ms_prior.account_id
           AND ms.brand_name  = ms_prior.brand_name
           AND ms_prior.period_key >= DATEADD('month', -6, CURRENT_DATE)
           AND ms_prior.period_key <  DATEADD('month', -3, CURRENT_DATE)
        JOIN OASIS_MART.BRAND_SALES_ACCOUNT bsa
            ON ms.account_id = bsa.account_id
           AND ms.brand_name  = bsa.brand_name
           AND ms.period_key  = bsa.period_key
        JOIN OASIS_MART.V_AT_RISK_ACCOUNTS var ON ms.account_id = var.account_id
        WHERE var.is_at_risk = TRUE
          AND {where}
          AND ms.period_key >= DATEADD('month', -3, CURRENT_DATE)
        GROUP BY 1, 2
        ORDER BY share_delta_pp ASC
    """
    return _session.sql(sql).to_pandas()


@st.cache_data(ttl=3600)
def get_system_exposure(_session, filters: dict) -> pd.DataFrame:
    """Used by: Chart 6.4 — System-Level Exposure"""
    where = build_filter_sql(filters)
    sql = f"""
        SELECT
            ah.system_name,
            bsa.brand_name,
            SUM(bsa.net_sales_usd) / 1e6    AS rev_m
        FROM OASIS_MART.BRAND_SALES_ACCOUNT bsa
        JOIN OASIS_MART.ACCOUNT_HIERARCHY   ah ON bsa.account_id = ah.account_id
        WHERE {where}
        GROUP BY 1, 2
        QUALIFY RANK() OVER (ORDER BY SUM(rev_m) DESC) <= 10
        ORDER BY 1, 2
    """
    return _session.sql(sql).to_pandas()
```

---

## SECTION 7 — MODULE PAGE SPECIFICATIONS

Each `pages/` file must export a single `render(session, filters)` function.
The function renders the complete page including phase banner, page header, KPI tiles, and all charts.
Use `st.columns()` for side-by-side chart layouts. Use `st.expander()` for secondary detail views.

### 7.1 Module 1 — Portfolio Command Center

```
File: pages/01_portfolio_command.py
Phase: CRAWL

Layout:
  1. Phase banner: st.badge("🟢 CRAWL — Module 1 of 8", color="green")
  2. Page title + subtitle
  3. KPI row (5 tiles): Net Sales | TRx | Active Accounts | Top-50 Concentration | At-Risk Accounts
     → data: get_portfolio_kpis()
     → compare current vs. prior period; show delta direction
  4. Two-column row (2:1 ratio):
     LEFT  — Chart 1.1: Multi-line chart, one line per brand, x=month, y=net_sales_m
             → plotly.express.line(), apply_oasis_theme()
             → color_discrete_map = brand_color_sequence()
     RIGHT — Chart 1.3: Donut chart, brand revenue share
             → plotly.graph_objects.Pie(hole=0.55)
             → center annotation: top brand name + %
  5. Two-column row (1:1 ratio):
     LEFT  — Chart 1.2: Horizontal bar, top 50 accounts
             → plotly.express.bar(orientation='h'), sorted descending
             → color = portfolio_pct value (sequential blue scale)
             → clicking a bar sets st.session_state["selected_account_id"]
               and navigates to Module 3
     RIGHT — Chart 1.4: US state choropleth
             → plotly.express.choropleth(locationmode='USA-states')
             → color = net_sales_m, color_scale = 'Blues'
             → scope = 'usa'
```

### 7.2 Module 2 — Account Universe Explorer

```
File: pages/02_account_universe.py
Phase: CRAWL

Layout:
  1. Phase banner + page header
  2. Tab bar: st.tabs(["All Accounts","Tier 1","Tier 2","Tier 3","⚠️ At Risk","340B"])
     → Each tab filters the ranking table (Chart 2.1) below
  3. Two-column row:
     LEFT  — Chart 2.2: Treemap
             → plotly.express.treemap(path=['segment'], values='rev_m')
             → color = segment, color_discrete_map aligned to brand palette
     RIGHT — Chart 2.3: Waterfall chart
             → plotly.graph_objects.Waterfall()
             → bars: Tier 1 → Tier 2 → Tier 3 → Untiered → Total
             → connector lines between bars
  4. Two-column row:
     LEFT  — Chart 2.4: Grouped bar — new vs. lost accounts by quarter
             → plotly.express.bar(barmode='group')
             → "New" = positive green bars, "Lost" = negative red bars
             → x = quarter_key, y = account_count, color = account_status
     RIGHT — Chart 2.5: Pie chart (340B split) + top 340B accounts table
             → plotly.graph_objects.Pie(hole=0.5)
             → below pie: st.dataframe() filtered to is_340b=True, top 10 by rev
  5. Full-width — Chart 2.1: Account ranking table
     → st.dataframe() with column config:
         rank:             st.column_config.NumberColumn
         account_name:     st.column_config.TextColumn (clickable → Module 3)
         portfolio_rev_m:  st.column_config.NumberColumn(format="$%.1fM")
         portfolio_pct:    st.column_config.ProgressColumn(format="%.1f%%", max=0.1)
         yoy_delta:        st.column_config.NumberColumn(format="%.1f%%")
         avg_share:        st.column_config.ProgressColumn(format="%.0f%%", max=1.0)
         is_at_risk:       st.column_config.CheckboxColumn("⚠️ At Risk")
     → on_select callback: set session_state["selected_account_id"] → navigate to p3
```

### 7.3 Module 3 — Account Deep Dive

```
File: pages/03_account_deep_dive.py
Phase: CRAWL

Entry:
  → Check st.session_state["selected_account_id"]
  → If not set: render account search box st.selectbox() populated from ACCOUNT_HIERARCHY
  → Breadcrumb: "Account Universe → {account_name}"

Layout:
  1. Chart 3.1: Account header card
     → st.container() with blue gradient background (inject via st.markdown HTML)
     → Display: account_name, system_name, tier badge, segment badge,
                340B badge (if true), territory, region
     → KPI sub-row: Portfolio Rev | TRx | Portfolio % | Active Brands | Avg Share | YoY Rev
  2. Two-column row:
     LEFT  — Chart 3.2: Grouped bar, TRx by brand, current vs. prior
             → plotly.express.bar(barmode='group')
             → current period = solid, prior period = 40% opacity (use opacity parameter)
             → color per brand
     RIGHT — Chart 3.3: Multi-line share trend, 24 months
             → plotly.express.line()
             → x = month, y = share_pct, color = brand_name
             → y-axis format: "{}%"
  3. Two-column row:
     LEFT  — Chart 3.4: Radar / spider chart
             → plotly.graph_objects.Scatterpolar()
             → Two traces: "This Account" (solid), "National Avg" (dashed)
             → r values = share_pct per brand, theta = brand names
     RIGHT — Chart 3.5: Site hierarchy tree table
             → st.dataframe() with indentation logic:
               parent row: bold, blue background
               child rows: indented, normal weight
             → Columns: account_name, account_type, tier, rev_m, yoy_delta
```

### 7.4 Module 4 — Brand Performance

```
File: pages/04_brand_performance.py
Phase: CRAWL

Entry:
  → Brand selector: st.radio(horizontal=True) with BRANDS list
  → All charts on page filtered to selected brand

Layout:
  1. KPI row (5 tiles): TRx | Net Sales | Market Share | Active Accounts | Target Attainment
     → Target Attainment = SUM(actual_trx) / SUM(target_trx) for period
  2. Two-column row:
     LEFT  — Chart 4.1: Line chart with target overlay
             → Actual TRx: plotly line, solid blue
             → Target: dashed amber line at constant or trended target level
             → Fill between actual and target: rgba(34,197,94,0.1) if above target
               else rgba(239,68,68,0.1)
     RIGHT — Chart 4.2: Grouped bar — share of voice by segment
             → Three groups (IDN, Academic, Community)
             → Three bars each (Pfizer, Comp A, Comp B)
             → y-axis: "{}%"
  3. Two-column row:
     LEFT  — Chart 4.3: Horizontal bar — top 25 accounts by TRx
             → color = account_tier (T1=blue, T2=teal, T3=green)
             → clicking a bar navigates to Account Deep Dive for that account
     RIGHT — Chart 4.5: Multi-line NRx by segment
             → x = month, y = nrx_total, color = segment
             → IDN = solid, Academic = solid, Community = dashed
  4. Full-width — Chart 4.4: Competitive market share trend, 24M
     → Multi-line: Pfizer (thick solid blue) + Comp A/B/C (thinner, colored)
     → Final point annotation for each line showing current share %
```

### 7.5 Module 5 — Geographic View *(WALK)*

```
File: pages/05_geographic_view.py
Phase: WALK

Layout:
  1. Full-width — Chart 5.1: US choropleth map
     → plotly.express.choropleth(locationmode='USA-states')
     → color_continuous_scale='Blues', scope='usa'
     → hover_data: state, region, net_sales_m, account_count
     → On click: filter Chart 5.2 table to that region (use plotly callback or
       st.session_state with plotly_events library if available)
  2. Three-column row:
     COL 1 — Chart 5.2: Horizontal bar — territory ranking
             → top 20 territories by portfolio revenue
             → color gradient: high=dark blue, low=light blue
     COL 2 — Chart 5.3: Sparklines table — territory trends
             → For each region: region name | inline SVG sparkline | current rev | YoY delta
             → Implement sparklines as plotly subplots or as HTML sparkline via st.markdown
     COL 3 — Chart 5.5: Diverging bar — region vs. national index
             → Bars extend right (green) if index > 100 (over-performing)
             → Bars extend left (red) if index < 100 (under-performing)
             → Reference vertical line at x=100
  3. Full-width — Chart 5.4: Bubble map
     → plotly.express.scatter_geo() or scatter_mapbox() with MSA lat/long
     → size = portfolio_rev_m, color = region
     → hover: account_count, rev_m, YoY delta
     → [ASSUMPTION] MSA lat/long lookup table must be provided or geocoded
```

### 7.6 Module 6 — Concentration & Risk *(WALK)*

```
File: pages/06_concentration_risk.py
Phase: WALK

Layout:
  1. Two-column row:
     LEFT  — Chart 6.1: Pareto curve
             → plotly.graph_objects.Scatter(mode='lines', fill='tozeroy')
             → Dashed reference lines at x=20 (% accounts) and y=80 (% revenue)
             → Diagonal "perfect equality" line for reference
     RIGHT — Chart 6.2: At-risk heatmap
             → plotly.express.imshow() on pivot table: accounts × brands
             → zmin=-15, zmax=5 (pp change scale), colorscale='RdYlGn'
             → annot=True to show pp values in cells
  2. Two-column row:
     LEFT  — Chart 6.3: Scatter — YoY share change
             → x = prior_share, y = current_share, size = rev_m
             → color: green if above diagonal, red if below
             → diagonal reference line: y=x
             → hover: account_name, share_delta_pp, revenue_impact
     RIGHT — Chart 6.4: Stacked horizontal bar — system exposure
             → plotly.express.bar(orientation='h', barmode='stack')
             → one bar per health system, stacked by brand
             → At-risk systems: bar outline in red
  3. Full-width — Chart 6.5: System/GPO treemap
     → plotly.express.treemap(path=['segment','system_name'], values='rev_m')
     → color = rev_m, colorscale sequential blues
     → On click: drill to system → opens filtered account table
```

### 7.7 Module 7 — Competitive Intelligence *(WALK)*

```
File: pages/07_competitive_intel.py
Phase: WALK

Layout:
  1. Two-column row:
     LEFT  — Chart 7.1: Multi-line competitive share trend, 24M
             → Pfizer: thick solid blue | Comp A: red | Comp B: amber | Comp C: teal
             → Final point annotations with current % values
     RIGHT — Chart 7.2: Grouped bar — share by account segment
             → x = segment, groups = Pfizer + Comp A + Comp B
             → y = share %
  2. Two-column row:
     LEFT  — Chart 7.3: Waterfall — share change by brand
             → Gaining brands = green bars above zero
             → Losing brands = red bars below zero
             → Flat brands = grey bars
     RIGHT — Chart 7.4: Competitive intensity heatmap
             → plotly.express.imshow(), accounts × competitors
             → z = competitor presence strength (0=Low to 4=Very High)
             → Custom discrete colorscale: green→yellow→orange→red
  3. Full-width — Chart 7.5: NRx share vs. TRx share dual-line
     → Two lines per brand: NRx share (solid) and TRx share (dashed)
     → Gap between NRx and TRx filled with rgba shading
     → Annotation explaining gap = pull-through opportunity
     → y-axis: "{}%", x-axis: month
```

### 7.8 Module 8 — AI Query Interface *(WALK)*

```
File: pages/08_ai_query.py
Phase: WALK

Layout:
  1. Component 8.1: NL query input panel
     → st.text_input() for query
     → "Ask →" button: st.button()
     → On submit: call run_cortex_analyst() (see Section 8)
  2. Component 8.3: Suggested question chips
     → Render as st.button() in horizontal st.columns()
     → On click: pre-populate query input and auto-run
  3. Component 8.4: Query history
     → Store last 10 queries + results in st.session_state["query_history"]
     → Display as clickable st.expander() rows
  4. Component 8.2: Auto-generated chart (conditional — shown after query)
     → Parse returned DataFrame → detect chart type:
         2 columns (categorical + numeric) → bar chart
         date column + numeric → line chart
         3+ columns → table
     → Always show raw results in st.dataframe() below chart
  5. Component 8.5: Export buttons
     → "Export to PowerPoint": use python-pptx to create single-slide snapshot
       [ASSUMPTION] PPT export is a WALK phase feature — stub the button in CRAWL
     → "Export to PDF":   st.download_button() with dataframe as CSV fallback
     → "Copy to Clipboard": st.code() block with CSV text
  6. OASIS Insight card
     → After query returns, make a second Cortex COMPLETE() call:
       prompt = f"In 2-3 sentences, provide a business insight from this data:
                  {result_df.to_string()} Context: Pfizer oncology commercial data."
     → Render insight in styled st.info() box with "✦ OASIS Insight" header
```

---

## SECTION 8 — CORTEX ANALYST INTEGRATION

### 8.1 Cortex Analyst API Call

```python
# queries/cortex_queries.py
import streamlit as st
import requests
import pandas as pd
from config.snowflake_connection import get_session

SEMANTIC_MODEL_STAGE = "@PFIZER_ONCOLOGY_DB.OASIS_MART.OASIS_STAGE/oasis_semantic_model.yaml"

def run_cortex_analyst(natural_language_question: str) -> dict:
    """
    Calls Snowflake Cortex Analyst REST API to convert NL question to SQL,
    executes the SQL, and returns both the SQL and the result DataFrame.

    Returns:
        {
            "sql":       str,
            "df":        pd.DataFrame,
            "error":     str | None,
        }
    """
    session = get_session()

    # Build REST request to Cortex Analyst endpoint
    # [ASSUMPTION] Snowflake account URL and token injected via SiS environment
    host    = st.context.headers.get("Host", "")
    token   = session.get_current_session_token()

    payload = {
        "messages": [
            {"role": "user", "content": [{"type": "text", "text": natural_language_question}]}
        ],
        "semantic_model_file": SEMANTIC_MODEL_STAGE,
    }

    try:
        response = requests.post(
            url=f"https://{host}/api/v2/cortex/analyst/message",
            json=payload,
            headers={
                "Authorization": f"Snowflake Token=\"{token}\"",
                "Content-Type":  "application/json",
            },
            timeout=30,
        )
        response.raise_for_status()
        result = response.json()

        # Extract generated SQL from response
        generated_sql = None
        for item in result.get("message", {}).get("content", []):
            if item.get("type") == "sql":
                generated_sql = item["statement"]
                break

        if not generated_sql:
            return {"sql": None, "df": pd.DataFrame(), "error": "No SQL generated"}

        # Execute the SQL
        df = session.sql(generated_sql).to_pandas()
        return {"sql": generated_sql, "df": df, "error": None}

    except Exception as e:
        return {"sql": None, "df": pd.DataFrame(), "error": str(e)}


def get_oasis_insight(result_df: pd.DataFrame, question: str) -> str:
    """
    Generates a 2-3 sentence business insight from query results using Cortex COMPLETE().
    Used by: Component 8 — OASIS Insight card
    """
    session = get_session()
    if result_df.empty:
        return "No results returned — try refining your question."

    sample = result_df.head(10).to_string(index=False)
    prompt = f"""You are a Pfizer oncology commercial analyst.
The user asked: "{question}"
The data returned was:
{sample}
In 2-3 concise sentences, provide a business insight from this data
that would help a commercial leader take action.
Focus on what is unusual, at risk, or represents an opportunity.
Do not describe the data — interpret it."""

    sql = f"""
        SELECT SNOWFLAKE.CORTEX.COMPLETE(
            'mistral-large2',
            '{prompt.replace("'", "''")}'
        ) AS insight
    """
    try:
        row = session.sql(sql).collect()[0]
        return row["INSIGHT"]
    except Exception as e:
        return f"Insight generation unavailable: {str(e)}"
```

### 8.2 Semantic Model YAML

```yaml
# semantic_model/oasis_semantic_model.yaml
# Register to Snowflake stage: PUT file://oasis_semantic_model.yaml @OASIS_STAGE;

name: OASIS Portfolio Intelligence
description: >
  Pfizer Oncology commercial intelligence data mart. Contains brand-level
  prescription, revenue, and market share data at the oncology account level,
  with account hierarchy, segmentation, and targeting metadata.

tables:

  - name: BRAND_SALES_ACCOUNT
    base_table:
      database: PFIZER_ONCOLOGY_DB
      schema:   OASIS_MART
      table:    BRAND_SALES_ACCOUNT
    description: >
      Monthly brand-level sales and prescription volume at the individual
      oncology account level for all Pfizer oncology brands.
    columns:
      - name: account_id
        description: Unique identifier for the oncology account
      - name: brand_name
        description: Pfizer oncology brand name
        synonyms: [drug, product, medicine, brand, therapy]
        sample_values: [LORBRENA, BRAFTOVI, MEKTOVI, IBRANCE, XTANDI]
      - name: indication
        description: Oncology indication the brand is prescribed for
        synonyms: [indication, tumor type, cancer type, disease]
        sample_values: [NSCLC_1L, NSCLC_2L, CRC, MELANOMA]
      - name: period_key
        description: First day of the calendar month (monthly grain)
        synonyms: [month, date, period, time]
      - name: trx_volume
        description: Total prescriptions including all refills
        synonyms: [TRx, scripts, prescriptions, total scripts, all fills]
      - name: nrx_volume
        description: New-to-brand prescriptions (first fills only, new patients)
        synonyms: [NRx, new scripts, new starts, new patients, initiation]
      - name: net_sales_usd
        description: Net revenue in USD after rebates and returns
        synonyms: [revenue, sales, net sales, net revenue, dollars]
      - name: gross_sales_usd
        description: Gross revenue before rebates and returns
      - name: units
        description: Number of dispensed drug units
      - name: days_of_therapy
        description: Days of therapy dispensed

  - name: ACCOUNT_HIERARCHY
    base_table:
      database: PFIZER_ONCOLOGY_DB
      schema:   OASIS_MART
      table:    ACCOUNT_HIERARCHY
    description: >
      Oncology account master table. Contains account metadata, segmentation,
      tier assignment, geographic hierarchy, and 340B participation status.
    columns:
      - name: account_id
        description: Unique identifier for the oncology account
      - name: account_name
        description: Full name of the oncology account or site
        synonyms: [account, site, hospital, clinic, center, institution]
      - name: account_type
        description: Type of oncology account
        synonyms: [type, facility type, site type]
        sample_values: [IDN, GPO, Academic, Community, Satellite]
      - name: parent_account_id
        description: ID of the parent health system this account belongs to
      - name: system_name
        description: Name of the parent health system
        synonyms: [health system, IDN, hospital system, parent system, network]
      - name: territory_id
        description: Sales territory identifier
      - name: territory_name
        description: Human-readable territory name
        synonyms: [territory, sales territory, rep territory]
      - name: region
        description: US geographic region
        synonyms: [region, area, geography]
        sample_values: [Northeast, Southeast, Midwest, West, Southwest]
      - name: state
        description: US state abbreviation
      - name: account_tier
        description: Priority tier based on portfolio value. Tier 1 is highest value.
        synonyms: [tier, priority, level, rank]
        sample_values: [Tier 1, Tier 2, Tier 3]
      - name: segment
        description: Account segment classification
        synonyms: [segment, channel, account class]
        sample_values: [Integrated, Community, Academic, GPO]
      - name: is_340b
        description: >
          TRUE if the account participates in the federal 340B Drug Pricing Program,
          which entitles them to discounted drug pricing.
        synonyms: [340B, 340-B, federal pricing, safety net, discounted]

  - name: MARKET_SHARE_ACCOUNT
    base_table:
      database: PFIZER_ONCOLOGY_DB
      schema:   OASIS_MART
      table:    MARKET_SHARE_ACCOUNT
    description: >
      Monthly market share data at the account and brand level. Contains
      Pfizer share and top 3 competitor shares within each indication at each account.
    columns:
      - name: pfizer_share_pct
        description: Pfizer brand share as a decimal (0.0 to 1.0). Multiply by 100 for %.
        synonyms: [share, market share, Pfizer share, our share, brand share]
      - name: competitor_1_share
        description: Market share of competitor A (decimal)
        synonyms: [Comp A share, competitor share, competitor 1]
      - name: competitor_2_share
        description: Market share of competitor B (decimal)
      - name: competitor_3_share
        description: Market share of competitor C (decimal)
      - name: total_market_trx
        description: Total market TRx across all competitors at this account/indication
        synonyms: [total market, market size, total TRx, addressable market]

metrics:
  - name: portfolio_revenue
    description: Total net sales across all Pfizer oncology brands at an account
    synonyms: [portfolio revenue, portfolio sales, total revenue, combined revenue]
    expr: SUM(net_sales_usd)
    table: BRAND_SALES_ACCOUNT

  - name: portfolio_concentration
    description: >
      Percentage of total Pfizer oncology BU revenue generated by a specific
      account or group of accounts
    synonyms: [concentration, portfolio share, contribution, % of business]
    expr: SUM(net_sales_usd) / SUM(SUM(net_sales_usd)) OVER ()
    table: BRAND_SALES_ACCOUNT

  - name: target_attainment
    description: Actual TRx as a percentage of TRx target for the period
    synonyms: [attainment, performance to target, % to goal, goal attainment]
    expr: SUM(trx_volume) / NULLIF(SUM(trx_target), 0)
    table: BRAND_SALES_ACCOUNT
```

---

## SECTION 9 — ROLE-BASED ACCESS CONTROL

### 9.1 Snowflake Role Definitions

```sql
-- Create OASIS application roles
CREATE ROLE IF NOT EXISTS OASIS_EXEC;
CREATE ROLE IF NOT EXISTS OASIS_BRAND_LEAD;
CREATE ROLE IF NOT EXISTS OASIS_REGIONAL_DIR;
CREATE ROLE IF NOT EXISTS OASIS_FIELD;
CREATE ROLE IF NOT EXISTS OASIS_ANALYTICS;

-- Grant table access by role
GRANT SELECT ON ALL TABLES IN SCHEMA OASIS_MART TO ROLE OASIS_EXEC;
GRANT SELECT ON ALL TABLES IN SCHEMA OASIS_MART TO ROLE OASIS_ANALYTICS;

GRANT SELECT ON TABLE OASIS_MART.ACCOUNT_HIERARCHY     TO ROLE OASIS_BRAND_LEAD;
GRANT SELECT ON TABLE OASIS_MART.BRAND_SALES_ACCOUNT   TO ROLE OASIS_BRAND_LEAD;
GRANT SELECT ON TABLE OASIS_MART.MARKET_SHARE_ACCOUNT  TO ROLE OASIS_BRAND_LEAD;
GRANT SELECT ON TABLE OASIS_MART.ACCOUNT_TARGETS       TO ROLE OASIS_BRAND_LEAD;

GRANT SELECT ON TABLE OASIS_MART.ACCOUNT_HIERARCHY     TO ROLE OASIS_REGIONAL_DIR;
GRANT SELECT ON TABLE OASIS_MART.BRAND_SALES_ACCOUNT   TO ROLE OASIS_REGIONAL_DIR;
GRANT SELECT ON TABLE OASIS_MART.PORTFOLIO_SUMMARY_MONTHLY TO ROLE OASIS_REGIONAL_DIR;

GRANT SELECT ON TABLE OASIS_MART.ACCOUNT_HIERARCHY     TO ROLE OASIS_FIELD;
GRANT SELECT ON TABLE OASIS_MART.BRAND_SALES_ACCOUNT   TO ROLE OASIS_FIELD;
GRANT SELECT ON TABLE OASIS_MART.MARKET_SHARE_ACCOUNT  TO ROLE OASIS_FIELD;
```

### 9.2 Row-Level Security Policies

```sql
-- ── Policy 1: Brand-level data restriction for OASIS_BRAND_LEAD ──────────────
CREATE OR REPLACE ROW ACCESS POLICY OASIS_MART.BRAND_ACCESS_POLICY
AS (brand_name VARCHAR) RETURNS BOOLEAN ->
    CASE
        WHEN CURRENT_ROLE() IN ('OASIS_EXEC', 'OASIS_ANALYTICS') THEN TRUE
        WHEN CURRENT_ROLE() = 'OASIS_BRAND_LEAD'
            -- [ASSUMPTION] Brand-to-role mapping stored in OASIS_MART.USER_BRAND_MAP
            THEN EXISTS (
                SELECT 1 FROM OASIS_MART.USER_BRAND_MAP
                WHERE snowflake_user = CURRENT_USER()
                  AND brand = brand_name
            )
        ELSE TRUE
    END;

ALTER TABLE OASIS_MART.BRAND_SALES_ACCOUNT
    ADD ROW ACCESS POLICY OASIS_MART.BRAND_ACCESS_POLICY ON (brand_name);

ALTER TABLE OASIS_MART.MARKET_SHARE_ACCOUNT
    ADD ROW ACCESS POLICY OASIS_MART.BRAND_ACCESS_POLICY ON (brand_name);

-- ── Policy 2: Territory restriction for OASIS_FIELD ──────────────────────────
CREATE OR REPLACE ROW ACCESS POLICY OASIS_MART.TERRITORY_ACCESS_POLICY
AS (account_id VARCHAR) RETURNS BOOLEAN ->
    CASE
        WHEN CURRENT_ROLE() IN ('OASIS_EXEC', 'OASIS_ANALYTICS',
                                 'OASIS_BRAND_LEAD', 'OASIS_REGIONAL_DIR') THEN TRUE
        WHEN CURRENT_ROLE() = 'OASIS_FIELD'
            THEN EXISTS (
                SELECT 1
                FROM OASIS_MART.ACCOUNT_HIERARCHY ah
                JOIN OASIS_MART.USER_TERRITORY_MAP utm
                  ON ah.territory_id = utm.territory_id
                WHERE ah.account_id      = account_id
                  AND utm.snowflake_user = CURRENT_USER()
            )
        ELSE FALSE
    END;

ALTER TABLE OASIS_MART.ACCOUNT_HIERARCHY
    ADD ROW ACCESS POLICY OASIS_MART.TERRITORY_ACCESS_POLICY ON (account_id);
```

### 9.3 Supporting RBAC Tables

```sql
-- User → brand mapping (for OASIS_BRAND_LEAD role)
CREATE OR REPLACE TABLE OASIS_MART.USER_BRAND_MAP (
    snowflake_user  VARCHAR(100),
    brand           VARCHAR(50),
    created_at      TIMESTAMP_NTZ DEFAULT CURRENT_TIMESTAMP
);

-- User → territory mapping (for OASIS_FIELD role)
CREATE OR REPLACE TABLE OASIS_MART.USER_TERRITORY_MAP (
    snowflake_user  VARCHAR(100),
    territory_id    VARCHAR(20),
    created_at      TIMESTAMP_NTZ DEFAULT CURRENT_TIMESTAMP
);
```

---

## SECTION 10 — CUSTOM CSS

```css
/* assets/styles.css */
/* Inject via: st.markdown(f"<style>{css}</style>", unsafe_allow_html=True) */

/* ── Typography ─────────────────────────────────────────── */
@import url('https://fonts.googleapis.com/css2?family=IBM+Plex+Sans:wght@300;400;500;600;700&family=IBM+Plex+Mono:wght@400;500&display=swap');

html, body, [class*="css"] {
    font-family: 'IBM Plex Sans', 'Helvetica Neue', Arial, sans-serif !important;
}

/* ── Sidebar ─────────────────────────────────────────────── */
[data-testid="stSidebar"] {
    background-color: #ffffff;
    border-right: 1px solid #dde3ef;
}
[data-testid="stSidebar"] [data-testid="stRadio"] label {
    font-size: 13px;
    color: #4a5568;
    padding: 6px 0;
    cursor: pointer;
}
[data-testid="stSidebar"] [data-testid="stRadio"] label:hover {
    color: #0039a6;
}

/* ── KPI metric cards ────────────────────────────────────── */
[data-testid="metric-container"] {
    background: #ffffff;
    border: 1px solid #dde3ef;
    border-radius: 9px;
    padding: 14px 16px;
    box-shadow: 0 1px 3px rgba(0,57,166,.08);
    border-top: 3px solid #0039a6;
}
[data-testid="metric-container"] [data-testid="stMetricLabel"] {
    font-size: 11px !important;
    font-weight: 500 !important;
    text-transform: uppercase;
    letter-spacing: .8px;
    color: #8896b3 !important;
}
[data-testid="metric-container"] [data-testid="stMetricValue"] {
    font-family: 'IBM Plex Mono', monospace !important;
    font-size: 24px !important;
    font-weight: 700 !important;
    color: #0d1b3e !important;
}

/* ── Chart containers ────────────────────────────────────── */
[data-testid="stPlotlyChart"] {
    border: 1px solid #dde3ef;
    border-radius: 9px;
    padding: 4px;
    background: #ffffff;
    box-shadow: 0 1px 3px rgba(0,57,166,.08);
}

/* ── Dataframe ───────────────────────────────────────────── */
[data-testid="stDataFrame"] {
    border: 1px solid #dde3ef;
    border-radius: 9px;
    overflow: hidden;
}

/* ── Tab bar ─────────────────────────────────────────────── */
[data-testid="stTabs"] [data-testid="stTabBar"] button {
    font-size: 13px;
    font-weight: 500;
    color: #8896b3;
}
[data-testid="stTabs"] [data-testid="stTabBar"] button[aria-selected="true"] {
    color: #0039a6;
    font-weight: 600;
    border-bottom-color: #0039a6;
}

/* ── Phase banner ────────────────────────────────────────── */
.oasis-phase-crawl {
    display: inline-flex; align-items: center; gap: 5px;
    background: #dcfce7; color: #15803d; border: 1px solid #86efac;
    border-radius: 20px; padding: 3px 12px; font-size: 11px; font-weight: 600;
    margin-bottom: 10px;
}
.oasis-phase-walk {
    display: inline-flex; align-items: center; gap: 5px;
    background: #fef3c7; color: #92400e; border: 1px solid #fcd34d;
    border-radius: 20px; padding: 3px 12px; font-size: 11px; font-weight: 600;
    margin-bottom: 10px;
}

/* ── Cortex insight card ─────────────────────────────────── */
.oasis-insight {
    background: linear-gradient(135deg, #f8faff, #f0faf9);
    border: 1px solid #c7d7ff; border-radius: 9px; padding: 14px;
    margin-top: 12px;
}
.oasis-insight-title {
    font-size: 13px; font-weight: 600; color: #0039a6; margin-bottom: 4px;
}
.oasis-insight-body {
    font-size: 13px; color: #4a5568; line-height: 1.55;
}

/* ── Account header card ─────────────────────────────────── */
.oasis-account-card {
    background: linear-gradient(135deg, #eef3ff, #f0faf9);
    border: 1px solid #c7d7ff; border-radius: 11px; padding: 16px;
    margin-bottom: 14px;
}
```

---

## SECTION 11 — DATA REFRESH PIPELINE

### 11.1 Snowflake Task for Weekly Refresh

```sql
-- Creates a scheduled task to refresh PORTFOLIO_SUMMARY_MONTHLY weekly
CREATE OR REPLACE TASK OASIS_MART.REFRESH_PORTFOLIO_SUMMARY
    WAREHOUSE   = OASIS_WH
    SCHEDULE    = 'USING CRON 0 6 * * 1 America/New_York'   -- Every Monday 6am ET
AS
INSERT OVERWRITE INTO OASIS_MART.PORTFOLIO_SUMMARY_MONTHLY
WITH national_total AS (
    SELECT
        DATE_TRUNC('month', period_key)     AS period_key,
        SUM(net_sales_usd)                  AS total_national_rev
    FROM OASIS_MART.BRAND_SALES_ACCOUNT
    GROUP BY 1
),
account_monthly AS (
    SELECT
        bsa.period_key,
        bsa.account_id,
        SUM(bsa.net_sales_usd)              AS total_portfolio_netsales,
        SUM(bsa.trx_volume)                 AS portfolio_trx_total,
        COUNT(DISTINCT CASE WHEN bsa.trx_volume > 0 THEN bsa.brand_name END) AS brand_count_active
    FROM OASIS_MART.BRAND_SALES_ACCOUNT bsa
    GROUP BY 1, 2
)
SELECT
    am.period_key,
    am.account_id,
    am.total_portfolio_netsales,
    am.portfolio_trx_total,
    am.brand_count_active,
    am.total_portfolio_netsales / NULLIF(nt.total_national_rev, 0) AS portfolio_concentration_pct,
    v.is_at_risk
FROM account_monthly am
JOIN national_total nt ON am.period_key = nt.period_key
LEFT JOIN OASIS_MART.V_AT_RISK_ACCOUNTS v ON am.account_id = v.account_id;

-- Enable the task
ALTER TASK OASIS_MART.REFRESH_PORTFOLIO_SUMMARY RESUME;
```

### 11.2 Refresh Log Insert (add to task)

```sql
-- Append to task body:
INSERT INTO OASIS_MART.DATA_REFRESH_LOG
    (source_system, records_loaded, status, notes)
SELECT
    'PORTFOLIO_SUMMARY_MONTHLY',
    COUNT(*),
    'SUCCESS',
    'Weekly refresh completed'
FROM OASIS_MART.PORTFOLIO_SUMMARY_MONTHLY
WHERE period_key = DATE_TRUNC('month', CURRENT_DATE);
```

---

## SECTION 12 — DEPLOYMENT CHECKLIST

Before submitting to Snowflake Cortex Code, confirm these prerequisites:

| # | Item | Owner | Status |
|---|---|---|---|
| 1 | Snowflake database `PFIZER_ONCOLOGY_DB` provisioned | Data Engineering | ☐ |
| 2 | Schema `OASIS_MART` created | Data Engineering | ☐ |
| 3 | Warehouse `OASIS_WH` created (Medium) | Data Engineering | ☐ |
| 4 | Source data (IQVIA/Symphony) flowing into `BRAND_SALES_ACCOUNT` | Data Engineering | ☐ |
| 5 | Account hierarchy loaded into `ACCOUNT_HIERARCHY` | Sales Ops | ☐ |
| 6 | Territory alignment loaded into `USER_TERRITORY_MAP` | Sales Ops | ☐ |
| 7 | Brand-to-user mapping loaded into `USER_BRAND_MAP` | OAG Admin | ☐ |
| 8 | Snowflake roles created and granted to users | IT Security | ☐ |
| 9 | Cortex Analyst feature enabled in Snowflake account | Snowflake Admin | ☐ |
| 10 | Semantic model YAML uploaded to `@OASIS_STAGE` | Data Engineering | ☐ |
| 11 | `OASIS_APP` Streamlit in Snowflake app registered | Data Engineering | ☐ |
| 12 | IBM Plex Sans font confirmed accessible (Google Fonts or local) | Dev | ☐ |
| 13 | Starter brands confirmed (Lorbrena + Braftovi/Mektovi) | Brand Leads | ☐ |
| 14 | At-risk flag thresholds confirmed (10% rev / 5pp share) | Analytics SME | ☐ |
| 15 | Data refresh cadence confirmed (weekly CRAWL / daily WALK) | OAG Leadership | ☐ |

---

## SECTION 13 — OPEN ASSUMPTIONS REQUIRING CONFIRMATION

All items below are marked `[ASSUMPTION]` in the code. Confirm before production:

| Assumption | Default Used | Confirm With |
|---|---|---|
| Starter brands | Lorbrena, Braftovi, Mektovi | Brand leads + OAG VP |
| At-risk threshold: revenue | YoY decline > 10% | Analytics SME |
| At-risk threshold: share | Loss > 5pp in trailing 3M | Analytics SME |
| Competitor names (Comp A/B/C) | Unnamed placeholders | Brand teams |
| 340B net sales basis | 340B-adjusted net sales | Finance / Market Access |
| Snowflake region | us-east-1 | Snowflake Admin |
| MSA lat/long source | Requires geocoding table | Data Engineering |
| Cortex model | mistral-large2 | Snowflake Admin (check availability) |
| PPT export library | python-pptx (WALK phase) | Dev lead |
| Data source system | IQVIA / Symphony Health | Data Engineering |

---

*End of Cortex Code Build Specification | Project OASIS | Pfizer Oncology | Confidential – Not for Distribution*
