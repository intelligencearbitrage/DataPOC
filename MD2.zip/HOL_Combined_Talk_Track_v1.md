# Cortex Code + SnowPrism HOL · Talk Track · Snowflake Summit 2026

**Talk Track**

Cortex Code + SnowPrism Hands-On Labs · Snowflake Summit 2026

*Speaker notes, minute by minute, for Rupesh.*

---

# How to Use This Document

This is a stage reference. Read it before the dry-run. Mark it up. Bring the marked-up version on stage.

## How each section is structured

- **Goal:** one line, what this block does for the room.
- **Say this:** a verbatim line or two for the opening of the block. This is the part to read or commit to memory.
- **Beats:** the talking points to hit between the opener and the transition. Cover them in order; do not read them.
- **Transition:** the verbatim line that hands off to the next block.
- **If something fails:** the backup move if the live moment does not work.

## A note on the voice

Lines are written in conversational style: short sentences, plain connectors, no jargon. Where a line is verbatim, it has been written for spoken delivery, not for reading aloud. If a line feels stiff in your voice, change it. The structure is what matters; the words are a starting point.

## Timing discipline

Every section has a clock time at the top. The hands-on modules (Module 3 and Module 5 in the Cortex Code session, and Modules 9 and 10 in the SnowPrism session) are the only ones with slack. Everything else is hard contract. Watch the clock or have Helper 2 hold up time signals.

---

---

# PART ONE — CORTEX CODE HOL

---

# Module 1 · Vibe Coding Intro · 0:00 to 0:05

*Goal: set the mental model before any tools open.*

### Open

| **Say this** Before we open a single tool, I want to start with what is changing about how we build data applications. Because the stack has flipped. |
| --- |

### Beats

- For decades, we have written data code by climbing from syntax up to intent. SQL first, business meaning later. That has been the job.

- What is changing is this. We are not writing the SQL anymore. We are describing the intent. The AI climbs down to the syntax for us.

- And here is the second thing that matters for the next 90 minutes. Data has gravity. Your schema, your security roles, your metadata, all of it lives in Snowflake. Most AI coding tools make you drag that context out. Cortex Code brings the AI to where the data already is. Same room.

- One last frame before we open anything. Cortex Code is not replacing GitHub Copilot. Copilot is your utility knife for general code. Cortex Code is a filet knife for data-intensive work inside Snowflake. Both belong in the drawer. Different jobs.

### Transition

| **Transition to next section** We have five minutes to talk about the room. Then we open CoCo and watch it read your data. Let us go. |
| --- |

### If something fails

| **If projection lags or slides do not advance** You do not need the slides for this section. Step away from the laptop. Deliver the four beats from the floor. The audience does not know what was supposed to be on screen. |
| --- |

---

# Module 2 · Foundation · 0:05 to 0:10

---

# Module 3 · ★ The CFO's Friday Email · 0:10 to 0:35

---

# Module 4 · Agentic Demo + SKILLS · 0:35 to 0:50

*Goal: show the four-step agentic chain, then set up SKILLS as the take-home pattern.*

### Open · 0:35 to 0:36

| **Say this** What you are about to watch looks like a lot of other agent demos. So I want to tell you what is different about this one before we play it. There are a lot of demos of agents working through a problem this week at Summit. Most of them are running against a fake dataset, a sandbox, a generic catalog. This one is running against the same DELOITTE_COCO_LAB you just used. Same six tables. Same data. |
| --- |

### During the video · 0:36 to 0:45

*Stage direction: Helper #2 plays the video. You narrate over it. Confirm audio level with the back of the room in the first 10 seconds.*

Four moments to call out as they happen:

### Orient phase

| **Say this** Right here. CoCo is reading your data catalog. Not a generic one. The same snowflake_object_search you saw it use in Module 2. |
| --- |

### Profile phase

| **Say this** Now watch this. It just surfaced a data gap from October. A human would have caught that after the dashboard was already wrong. CoCo caught it before the SQL got written. |
| --- |

### Build phase

| **Say this** And here is the part most agents do not do. It remembered the October gap and added a WHERE clause to skip those dates. With a comment explaining why. The previous step informed the next step. |
| --- |

### Ship phase

| **Say this** And it ended in a Streamlit app. Same chain. One Slack message in. One deployed app out. |
| --- |

### After the video · 0:45 to 0:46

| **Say this** Plan, execute, observe, adapt. Four steps, one goal. That is what people mean when they say agent and not co-pilot. |
| --- |

## SKILLS demo · 0:46 to 0:50

### Setup

| **Say this** There is one more thing I want to show you before you go build your own version of what is on screen. It is called SKILLS. Every team in this room has a calculation they argue about. Adjusted EBITDA. Active user. Churn. Net new ARR. The argument is real and the inconsistency is expensive. SKILLS lets you codify that calculation once. After that, whenever anyone asks CoCo a question that involves that calculation, it reaches for the function. No one writes the SQL again. |
| --- |

*Stage direction: open CoCo. Paste the SKILL invocation prompt. Run live.*

### Narration during the response

| **Say this** I did not tell it to use that function. I asked the business question. It understood the intent and reached for the right tool. That is the move. |
| --- |

### Call to action

| **Say this** The first SKILL you build this week, when you get back to your desk, should be whatever your team argues about most. Codify it once. Everyone gets the same answer to the same question from then on. |
| --- |

### Transition

| **Transition to next section** Now you do the part where you build something. Thirty minutes. Streamlit app. Yours to keep. |
| --- |

### If something fails

| **If video audio does not carry** Pause the video. Say: 'Let me narrate over a muted version.' Helper #2 mutes the video and replays from the start. You do the narration verbatim. The visuals carry the rest. |
| --- |
| **If the live SKILL invocation does not pick up the function** Do not panic on stage. Say: 'Sometimes the agent reaches for the function on the second pass. Let me try the prompt with one tiny adjustment.' Rerun with the SKILL name explicitly mentioned. Acknowledge the gap honestly. The audience trusts honesty more than seamless demos. |

---

# Module 5 · ★ Streamlit Build and Deploy · 0:50 to 1:20

*Goal: every attendee deploys a real branded Streamlit app to Snowsight. The bar-quote moment.*

### Open · 0:50 to 0:53

| **Say this** This is the part you came for. We have 30 minutes. By the end of it, every one of you has a deployed Streamlit dashboard running in Snowsight. Your account, your data, branded with your company name. You keep it. |
| --- |

### Setup beats · 0:50 to 0:53

- Flip to page 8 of your participant guide. The master prompt is there.

- Find the placeholder that says YOUR_COMPANY. Replace it with something. Truist. TIAA. Your real firm. Or just type Sample Wealth. Whatever you want on the header bar.

- One thing for our Track B friends, the ones using the shared account. You are deploying to your personal schema, not the shared ANALYTICS schema. Your helper at the door wrote your schema name on your wristband sticker. Use that schema in the deploy command.

- Then paste. The terminal might look like nothing is happening for a few seconds. It is. CoCo is generating about 200 lines of Streamlit code.

### During the deploy · 0:53 to 1:10

*Stage direction: walk every aisle. Eyes on screens, not on phones. Do not narrate continuously. Step in when someone is stuck. Have a helper carry the unedited master prompt on a flash card in case anyone needs to paste it again.*

Things to say while walking, sparingly:

- "The terminal is generating Streamlit code right now. About 200 lines. Hang tight."

- "When it says 'deployed', open the URL it gives you. Open it in your browser."

- "If anyone is seeing a permissions error, your helper has the fix."

### After deploy · 1:10 to 1:17

| **Say this** URLs are showing up. Open yours. Walk through all four pages. On the AI Q&A page, try a real business question. Something you might ask if you were the CRO from Module 3. |
| --- |

### Screen share moment · 1:17 to 1:20

*Stage direction: while attendees are clicking around, identify 2 to 3 whose apps look especially good. Tap them on the shoulder, ask if they would share their screen for 30 seconds. Helper #2 has the dongle ready.*

| **Say this** I want to show two people's apps before we close. Same prompt, different company names, different choices CoCo made. Here is what came out. |
| --- |

### Transition

| **Transition to next section** What you just built is one version of what is possible with CoCo in 30 minutes. I want to show you what 8 weeks of this looks like in production. We built it for a client. The app is called Advisor360. |
| --- |

### If something fails

| **If multiple Track B users get permission errors deploying to their schema** Vikas at the back has the grant fix on a script. Say: 'A few of you are hitting permission issues on the shared account. Vikas is pushing a fix now, give it 30 seconds and rerun the deploy.' Continue narrating for Track A while Vikas handles Track B. |
| --- |
| **If the room is running slow and most apps are not deployed by 1:15** Skip the screen-share moment. Acknowledge honestly: 'We are at time on the build. Some of you are still mid-deploy and that is fine. The deploy is going to finish in the background while we close. Your URL will show up.' |
| **If conference WiFi crashes mid-deploy** Stay calm. Say: 'The conference WiFi is hitting a wall. Let me give it 60 seconds.' Mrunal pings the venue. If it does not recover, switch to Advisor360 walk-through early and come back to Streamlit if WiFi returns. Do not skip Streamlit silently. Acknowledge the situation and pivot openly. |

---

# Module 6 · Advisor360 Closer · 1:20 to 1:28

*Goal: the Deloitte-knows-how payoff. Show a production agentic app running in Snowflake.*

### Open · 1:20 to 1:21

| **Say this** You just built a 25-minute Streamlit app. So you might fairly ask. What does the production version look like. And I want to be honest about something before I show you. There are a lot of agentic AI demos at this conference this week. Most of them are demos. This one is in production at a real client. |
| --- |

*Stage direction: switch the projector to the Advisor360 browser tab. Confirm it is loaded. If it is cold, use the architecture beat first to give the SPCS container time to wake up.*

### Dashboard page · 1:21 to 1:22

| **Say this** Look at this worklist. These tasks were prioritized by an agent that ran at 6 am, before the advisor logged in this morning. Not on demand. Scheduled. That is operational AI, not demo AI. |
| --- |

### Communications page · 1:22 to 1:24

*Stage direction: click on a communication. Click the 'Revise' button. Watch the response come back live.*

| **Say this** Now watch this. I am going to click revise on this email draft. (Click.) CoCo just rewrote it in the tone we trained for this firm. The same Cortex Complete primitive you wired into your AI Q&A page. Productionized. |
| --- |

### Smart Worklist / Agent Activity · 1:24 to 1:25

| **Say this** There is an agent activity log on this page. You can see what agents have run today and what they did. This is what observability looks like for agents. Audit trail. |
| --- |

### Agent Panel · 1:25 to 1:27

| **Say this** And the side panel here shows what an agent is doing in real time. Plan, execute, observe, adapt. Same loop you watched on video in Module 4. Running now in production. |
| --- |

### Architecture beat · 1:27 to 1:28

| **Say this** Here is the thing that matters to your CISO. React front end. FastAPI back end. Inside a Snowpark Container Services container. Connected to Snowflake by an OAuth token that the platform provides automatically. No external LLM. No data leaves your account. Cortex Complete with mistral-large2 doing the AI work. Same primitives you used today. |
| --- |

### Transition

| **Transition to next section** If you want a version of this for your firm, the four of us in this room know how. Stay with me for 90 more seconds and I will tell you what you take home. |
| --- |

### If something fails

| **If the Advisor360 app is cold and takes >10 seconds to load** Open with the architecture beat first. Say: 'Before we click around, let me tell you what is under the hood, because the architecture is part of why this works at all.' Buy 30 seconds. Switch back to the live app once it loads. |
| --- |
| **If the 'Revise' button does not return a Cortex response** Acknowledge it. Say: 'Sometimes Cortex throttles in real time. Let me show you what the response looked like the last time I ran this.' Switch to a screenshot in your presenter notes. Move on. |

---

# Module 7 · Send-off · 1:28 to 1:30

*Goal: three artifacts, one call to action, one closing line.*

### Open

| **Say this** Three things you take home with you today. |
| --- |

### Beats

*Stage direction: closing slide has three QR codes.*

- "The prompt cheat sheet. Five patterns, the Three Questions framework. It is the PDF behind the first QR code."

- "The GitHub repo. Every prompt from this lab, the SKILL template, the Streamlit app scaffold. Second QR code."

- "And the one thing you do this week. The first SKILL you build is whatever calculation your team argues about most. Codify it once."

### Closing line

| **Say this** If you want to deploy something like Advisor360 at your firm, the four of us at the door know how. Come find us. Thank you for spending 90 minutes with us today. |
| --- |

*Stage direction: walk to the door immediately after the closing line. Helpers move to door positions. The conversations start here.*

---

---

# PART TWO — SNOWPRISM HOL

---

# Module 8 · SnowPrism Orientation · [TIME TBD] to [TIME TBD]

*Goal: establish what SnowPrism is, why it was built this way, and what attendees will build. No SQL yet.*

### Open

| **Say this** Before we open a worksheet, I want to explain a design decision we made — because it is the same decision you will face on every client engagement that involves Snowflake usage analytics. |
| --- |

### Beats

- Snowflake has a built-in schema called ACCOUNT_USAGE. It tracks everything: which warehouse ran, how many credits it burned, when, for how long. It is the source of truth for understanding what your account is doing and what it costs.

- The problem is access. ACCOUNT_USAGE requires ACCOUNTADMIN — one of the most privileged roles in a Snowflake account. In a real client environment, you are not handing that role to a team of analysts. And in a lab with 75 attendees, granting ACCOUNTADMIN to every participant is not just impractical. It is the kind of thing that ends careers.

- So SnowPrism answers a specific design question: how do you build a full account usage analytics layer, with natural language querying, on top of data that any role can read?

- **[YOUR STORY HERE — one sentence from a real engagement where a client needed spend visibility but access politics blocked it for months. This is the moment to make the problem land before the solution appears.]**

- The answer is a synthetic table that mirrors ACCOUNT_USAGE exactly — same columns, same patterns — but lives in a database anyone can read. Everything you build on top of it works identically to what you would build on the real thing. When you are ready to point it at live data, you change one line. The architecture does not move.

- Here is the stack, top to bottom. The instructor builds the top half live. You build the bottom half yourselves.

*Stage direction: draw or display the flow diagram.*

```
SAMPLE_METERING_HISTORY  (synthetic — mirrors ACCOUNT_USAGE.WAREHOUSE_METERING_HISTORY)
         ↓
T_WAREHOUSE_TENANT_MAP   (which warehouse belongs to which team)
         ↓
DT_CREDIT_BY_WAREHOUSE   (credits per warehouse per day — self-refreshing)
         ↓
DT_CREDIT_BY_TENANT      (credits per team per day — self-refreshing)
         ↓
V_CREDIT_SUMMARY         (today / this week / this month / % of budget)
         ↓
SV_FINOPS                (semantic layer — maps business language to the data model)
         ↓
Cortex Analyst           (you ask in English. It answers.)
```

- The part you build — SV_FINOPS and Cortex Analyst — is the part that changes how a business user interacts with data. That is not an accident. That is the point of the session.

### Transition

| **Transition to next section** Let us set context and confirm the foundation is there. Then I will build R1 in front of you and show you what it produces. |
| --- |

### If something fails

| **If the flow diagram does not display** Sketch it verbally. Say: 'Five layers. Raw data at the top. Natural language at the bottom. Each layer feeds the next. The instructor builds the top three. You build the bottom two.' That is enough to orient the room. |
| --- |

---

# Module 9 · ★ R1 Build (Instructor live) · [TIME TBD]

*Goal: build the credit visibility layer live on stage. Attendees watch and orient to the data model.*

### Open

| **Say this** Four lines before anything else. Every Snowflake session needs to know who you are, which engine to use, and where to put things. Skip this and you will see 'object does not exist' within 30 seconds. |
| --- |

### Set context · always first

*Stage direction: paste and run. Each line should return: Statement executed successfully.*

```sql
USE ROLE SYSADMIN;
USE WAREHOUSE COMPUTE_WH;
USE DATABASE SNOWPRISM_DB;
USE SCHEMA ANALYTICS;
```

### Beat: confirm the data

| **Say this** The synthetic table is already seeded. Let me show you what is in it. |
| --- |

```sql
SELECT COUNT(*) AS ROW_CNT,
       COUNT(DISTINCT WAREHOUSE_NAME) AS WAREHOUSES
FROM SNOWPRISM_DB.RAW.SAMPLE_METERING_HISTORY;
```

- Expected: ROW_CNT = 720, WAREHOUSES = 8. That is 90 days across 8 warehouses.

- Weekend volumes dip to about 35% of weekday — the same pattern you would see in a real account.

- Two anomalies are baked in: WH_DATAENG_TRANSFORM spiked six times its normal volume 14 days ago. WH_FINANCE_CLOSE spiked five times three days ago. Both will surface naturally when we query the data.

- **[YOUR STORY HERE — "When you point this at a real account, the anomalies will not be seeded. They will be real. And the pattern for finding them is identical."]**

### Beat: the tenant table

| **Say this** This is the org chart. Six rows. Five real teams. One catch-all for anything we have not attributed yet. |
| --- |

```sql
SELECT * FROM SNOWPRISM_DB.RAW.T_TENANT;
```

- UNASSIGNED has a budget of zero on purpose. Any warehouse not explicitly mapped falls here. That makes invisible spend visible instead of hiding it.

### Beat: the warehouse-to-tenant map

| **Say this** This is the translation layer. It says WH_DATAENG_TRANSFORM belongs to DATA_ENG. The sync procedure keeps it current — any new warehouse lands as UNASSIGNED automatically. |
| --- |

```sql
SELECT WAREHOUSE_NAME, TENANT_NAME
FROM SNOWPRISM_DB.RAW.T_WAREHOUSE_TENANT_MAP
ORDER BY TENANT_NAME;
```

- Expected: 8 rows. WH_ADHOC_SANDBOX is UNASSIGNED on purpose — it proves the COALESCE path works downstream.

- **[YOUR STORY HERE — "In real engagements, this map is where the politics live. Who owns the sandbox warehouse? Who approved that new ETL job? The map makes the conversation concrete."]**

### Beat: Dynamic Tables

| **Say this** Here is where Snowflake earns its keep. These three tables refresh themselves. No Airflow. No cron job. No stored procedure you have to remember to call. |
| --- |

```sql
SELECT 'DT_CREDIT_BY_WAREHOUSE' AS tbl, COUNT(*) AS rows
  FROM SNOWPRISM_DB.ANALYTICS.DT_CREDIT_BY_WAREHOUSE
UNION ALL
SELECT 'DT_CREDIT_BY_TENANT', COUNT(*)
  FROM SNOWPRISM_DB.ANALYTICS.DT_CREDIT_BY_TENANT
UNION ALL
SELECT 'DT_CREDIT_DAILY_TREND', COUNT(*)
  FROM SNOWPRISM_DB.ANALYTICS.DT_CREDIT_DAILY_TREND;
```

- Expected: 720 / 720 / 90.

- DT_CREDIT_BY_TENANT uses a JOIN, so Snowflake switches it to FULL refresh mode automatically. You will see that in the build log. That is not an error. That is Snowflake being honest about what a JOIN requires.

- **[YOUR STORY HERE — "If you are coming from a world of scheduled stored procedures, sit with this for a second. The table maintains itself. When the source data changes, it propagates. That is the architecture shift."]**

### Beat: the summary view

| **Say this** This is the object your FinOps team looks at every morning. |
| --- |

```sql
SELECT * FROM SNOWPRISM_DB.ANALYTICS.V_CREDIT_SUMMARY;
```

- Expected: 6 rows. DATA_ENG highest at roughly 91.7% of budget. UNASSIGNED shows NULL for percent — no budget to divide against.

- Your numbers will vary because the sample data has random noise. The shape is what matters.

- **[YOUR STORY HERE — "DATA_ENG at 91.7% with five business days left in the month. What conversation does that start? The data is not the insight. The conversation the data enables — that is the insight."]**

### R1 Check — run with the room

*Stage direction: attendees run these three checks to confirm their pre-loaded R1 is intact before building R2.*

| **Say this** Before we move to the part you build, let us confirm R1 is clean in your sandbox. Three checks. Run them in order. |
| --- |

**Check 1 — Row count**
```sql
SELECT COUNT(*) FROM SNOWPRISM_DB.ANALYTICS.DT_CREDIT_BY_WAREHOUSE;
```
Expected: 720. If you see 0, wait 10 seconds and re-run. If still 0:
```sql
ALTER DYNAMIC TABLE SNOWPRISM_DB.ANALYTICS.DT_CREDIT_BY_WAREHOUSE REFRESH;
```

**Check 2 — All tenants present**
```sql
SELECT DISTINCT TENANT_NAME
FROM SNOWPRISM_DB.ANALYTICS.DT_CREDIT_BY_TENANT
ORDER BY 1;
```
Expected: 6 names including UNASSIGNED.

**Check 3 — Summary view populated**
```sql
SELECT * FROM SNOWPRISM_DB.ANALYTICS.V_CREDIT_SUMMARY;
```
Expected: 6 rows, PCT_BUDGET_CONSUMED filled in for 5 tenants, NULL for UNASSIGNED.

*Stage direction: pause. Scan the room. Anyone not seeing 6 rows on Check 3 — walk over. It is almost always a missing USE statement. Have them re-run the four context lines.*

### Transition

| **Transition to next section** All three green? Good. R1 is done. That is the foundation. Now we build the part that makes a business user want to use it. |
| --- |

### If something fails

| **If a Dynamic Table shows 0 rows** Run the REFRESH command on stage. Say: 'Sometimes a Dynamic Table takes a moment on first access. This forces it.' Wait 10 seconds, re-run the SELECT. If it still shows 0, confirm the four USE lines are set correctly. |
| --- |
| **If V_CREDIT_SUMMARY shows fewer than 6 rows** Almost always a context issue — the wrong database is active. Have the attendee re-run USE DATABASE SNOWPRISM_DB and re-run the query. |
| **If attendees are still on Check 1 when you need to move** Call it: 'If you are on Check 1, a helper will come to you. The rest of us are moving to R2. You will catch up — R2 is one object and about 10 lines of SQL.' |

---

# Module 10 · ★ R2 Build (Attendees) · [TIME TBD]

*Goal: every attendee builds a semantic view and asks their first question in plain English. The wow moment.*

### Open

| **Say this** R1 built the pipes. R2 teaches Snowflake your business language. One object. That is all you are building. But it is the object that changes who can use the data. |
| --- |

### Beat: what a semantic view actually is

- A semantic view is not a view in the traditional sense. It does not return rows. It maps business language to the data model. TENANT_NAME becomes "team." SUM(TENANT_CREDITS) becomes "credits." Cortex Analyst uses that map to turn an English question into the right SQL — and the right answer.

- The reason we build it first and ask questions second is that the AI needs the map before it can navigate. Without SV_FINOPS, Cortex Analyst would be guessing at what "team" means. With it, there is no guessing.

### Step 1: Build the semantic view

| **Say this** Two ways to do this. If you want to use Cortex Code, paste the prompt. If you want the SQL directly, it is in your workbook. Either way gets you the same object. |
| --- |

**Option A — Cortex Code prompt:**

> Create a semantic view SNOWPRISM_DB.ANALYTICS.SV_FINOPS over the table DT_CREDIT_BY_TENANT. Dimensions: TENANT_NAME (the team), WAREHOUSE_NAME, CREDIT_DATE. Metric: TOTAL_CREDITS as the SUM of TENANT_CREDITS. Give it a primary key of (TENANT_NAME, CREDIT_DATE, WAREHOUSE_NAME). Show the SQL, then run it.

**Option B — direct SQL:**

```sql
CREATE OR REPLACE SEMANTIC VIEW SNOWPRISM_DB.ANALYTICS.SV_FINOPS
  TABLES (
    credits AS SNOWPRISM_DB.ANALYTICS.DT_CREDIT_BY_TENANT
    PRIMARY KEY (TENANT_NAME, CREDIT_DATE, WAREHOUSE_NAME)
  )
  DIMENSIONS (
    credits.TENANT_NAME    AS TENANT_NAME,
    credits.WAREHOUSE_NAME AS WAREHOUSE_NAME,
    credits.CREDIT_DATE    AS CREDIT_DATE
  )
  METRICS (
    credits.TOTAL_CREDITS  AS SUM(credits.TENANT_CREDITS)
  );
```

Expected: Statement executed successfully.

Confirm it exists:
```sql
SHOW SEMANTIC VIEWS IN SCHEMA SNOWPRISM_DB.ANALYTICS;
```
Expected: one row — SV_FINOPS.

*Stage direction: wait for the room to catch up before moving to Step 2. Watch for raised hands.*

### Step 2: Ask questions in plain English

| **Say this** Open Cortex Analyst. Left menu, AI and ML, then Cortex Analyst. Pick SV_FINOPS from the dropdown. These three questions are proven to work. |
| --- |

**Question 1:** Which tenant spent the most credits in total?

Expected: DATA_ENG.

**Question 2:** Show me the daily credit trend for the last 30 days.

Expected: a time series of daily totals.

**Question 3:** Break down credit usage for the DATA_ENG tenant by warehouse.

Expected: two warehouses. WH_DATAENG_TRANSFORM is the larger one — roughly double WH_DATAENG_INGEST — because the anomaly spike is in the transform layer.

### Beat: free exploration

| **Say this** Now ask your own. Here are a few to get started. But the point is to ask whatever question you actually care about. |
| --- |

- "How many credits did MARKETING use this month?"
- "Which warehouse is most expensive?"
- "Show me FINANCE credit usage for the last two weeks."
- "Which team is closest to their budget?"

*Stage direction: walk the room. Same energy as Streamlit deploy time. Watch for the first person who asks a question that surprises them. That is the screen to share.*

**[YOUR STORY HERE — "The first time a business analyst asks a question and gets a real answer without filing a ticket — that is the moment. That is what we are building toward."]**

### Transition

| **Transition to next section** Let us confirm everyone is across the line. Three done-when conditions. |
| --- |

### If something fails

| **If Cortex Analyst cannot find the semantic view** Make sure the attendee is selecting SV_FINOPS from the dropdown — not a raw table. The semantic view must be selected, not just present. |
| --- |
| **If CREATE SEMANTIC VIEW returns an insufficient privileges error** Ask the instructor to run: GRANT DATABASE ROLE SNOWFLAKE.CORTEX_USER TO ROLE <attendee_role>; This is a one-time grant per role. Once granted, the CREATE runs cleanly. |
| **If Cortex Analyst returns an unexpected answer to Question 1** The answer should be DATA_ENG. If it is not, confirm the semantic view was created against DT_CREDIT_BY_TENANT, not the raw table. Drop and recreate using Option B (direct SQL) if needed. |
| **If the room is behind on Step 1 when you need to move** Call it: 'If you are still on the CREATE, paste Option B — the direct SQL — and run it. That gets you to the same place in about 10 seconds.' Then move the room to Step 2 together. |

---

# Module 11 · R2 Check + Close · [TIME TBD]

*Goal: confirm every attendee has a working FinOps assistant. Land the so-what.*

### Open

| **Say this** Three done-when conditions. You are finished when all three are true. |
| --- |

### Checks

**Done 1 — Semantic view exists**
```sql
SHOW SEMANTIC VIEWS IN SCHEMA SNOWPRISM_DB.ANALYTICS;
```
Returns SV_FINOPS.

**Done 2 — Cortex Analyst answers the first question**

Ask: "Which tenant spent the most credits in total?"

Returns: DATA_ENG.

**Done 3 — Cortex Analyst answers your own question**

Ask anything. Get a sensible number back.

### Close

| **Say this** If all three are green, you just built a working FinOps assistant. It reads 720 rows of credit history. It knows which team owns which warehouse. It maintains itself. And it answers questions in plain English. |
| --- |

### Beats

- What you built today is R1 and R2. The pattern has three more releases in it. R3 adds query health — which queries are expensive, which are redundant. R4 adds anomaly detection and forecasting — it tells you when a team is trending toward budget before they hit it. R5 is a Streamlit dashboard that surfaces all of it in one screen.

- The foundation you built today does not change when those layers are added. That is what a good architecture does. It absorbs what comes next without breaking what is already there.

- **[YOUR STORY HERE — close with a line about what a client could do with this pattern in production. Not a pitch. Just an observation about what becomes possible when FinOps conversations are grounded in real data rather than spreadsheets and gut feel.]**

### Transition

| **Say this** Thank you. If you want to take this further — R3 through R5, or pointing it at a real account — come find us at the door. |
| --- |

*Stage direction: move to the door. The conversations start here.*

### If something fails

| **If several attendees cannot get Cortex Analyst to return DATA_ENG** Do not troubleshoot individually on stage. Say: 'If your answer does not match, the shape of the data is what matters — not the exact number. We can dig into any mismatch at the door.' Keep the close clean. |
| --- |

---

---

# Appendix · Quick Reference — Both Sessions

*Tape this to the back of your laptop. Glance during transitions.*

## Cortex Code HOL

| **Time** | **Module** | **Length** |
| --- | --- | --- |
| 0:00 | Vibe Coding. Set the mental model. | 5 min |
| 0:05 | Foundation. Open CoCo. Read the schema live. | 5 min |
| 0:10 | **★ CFO Friday Email. Three levels of prompting.** | 25 min |
| 0:35 | Agentic demo (video) + SKILLS (live). | 15 min |
| 0:50 | **★ Streamlit build and deploy. Yours to keep.** | 30 min |
| 1:20 | Advisor360 closer. Deloitte knows how. | 8 min |
| 1:28 | Send-off. Three takeaways. Call to action. | 2 min |

## SnowPrism HOL

| **Time** | **Module** | **Length** |
| --- | --- | --- |
| TBD | Orientation. What SnowPrism is and why. | ~5 min |
| TBD | **★ R1 Build (instructor live). Credit visibility layer.** | ~20 min |
| TBD | R1 Check. Confirm foundation before R2. | ~5 min |
| TBD | **★ R2 Build (attendees). Semantic view + NL querying.** | ~20 min |
| TBD | R2 Check + Close. Confirm and land the so-what. | ~5 min |

---

## Three lines to never skip — Cortex Code

- "What do I want. Compared to what. What will I do with it." (Module 3 debrief.)
- "Plan, execute, observe, adapt. That is what people mean when they say agent." (Module 4 close.)
- "If you want a version of this for your firm, the four of us at the door know how." (Module 6 transition.)

## Three lines to never skip — SnowPrism

- "When you are ready to point it at live data, you change one line. The architecture does not move." (Module 8 orientation.)
- "The data is not the insight. The conversation the data enables — that is the insight." (Module 9, V_CREDIT_SUMMARY beat.)
- "R1 built the pipes. R2 teaches Snowflake your business language." (Module 10 open.)
