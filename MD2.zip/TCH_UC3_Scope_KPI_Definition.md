# TCH Use Case 3: U.S. News & World Report (USNWR) Analytics Pilot
## Scope & KPI Definition Document

**Version:** 1.0
**Date:** April 22, 2026
**Status:** Draft — Pending Client Review

---

## 1. Purpose

This document defines the pilot scope, success criteria, and key performance indicators (KPIs) for the TCH USNWR Analytics Pilot. It is intended to align internal delivery teams and the Client on measurable outcomes prior to development kickoff. The pilot will produce a predictive model that projects real-time USNWR ranking trajectories for the diabetes service line, leveraging internal clinical and operational data currently fed into QlikSense alongside prior-year USNWR survey results.

---

## 2. Pilot Scope

### 2.1 Overview

The pilot will develop a predictive analytics model that synthesizes TCH's internal performance data with historical USNWR survey inputs to forecast ranking outcomes for the diabetes service line. The model will enable leadership to identify performance gaps, simulate the impact of operational improvements, and take proactive action before survey submission windows close.

### 2.2 In-Scope Capabilities

**Ranking Trajectory Projection**
A continuously updated model that ingests current internal data and projects expected USNWR ranking scores and overall rank position for the diabetes service line in real or near-real time.

- Map internal QlikSense metrics to corresponding USNWR survey dimensions (e.g., patient outcomes, volume, care quality indicators)
- Leverage existing custom-built QlikSense survey applications as the primary metric source — these apps are already structured around USNWR survey dimensions
- Score current performance against prior-year USNWR benchmarks and peer hospital data
- Project composite ranking trajectory on a rolling basis as new data is available

**Negative Outcome Pattern Analysis**
An analytical layer that identifies common factors across negative patient outcomes to surface systemic improvement opportunities.

- Analyze negative outcomes across the diabetes patient population to identify shared characteristics (demographics, comorbidities, care pathways, timing)
- Surface patient population insights — cohort segmentation by acuity, age, payer mix, and how these correlate with outcome scores
- Provide root-cause pattern visualization to help clinical leadership target interventions

**Gap Analysis & Sensitivity Modeling**
An analytical layer that surfaces the highest-impact levers for ranking improvement.

- Identify which USNWR dimensions carry the greatest weight and where TCH is underperforming relative to peers
- Run "what-if" simulations: model the ranking impact of specific operational or clinical improvements
- Prioritize improvement opportunities by projected ranking lift per unit of effort
- Account for physician-certified dimensions (Expert Opinion) as influence levers vs. directly controllable operational dimensions

**USNWR Code & Submission Explorer**
A reference layer that helps users navigate the complexity of USNWR survey coding and prior submission data.

- Map USNWR codes to their multiple descriptions, enabling users to understand which metrics feed each survey question
- Provide access to parsed prior-year submission CSVs (~300 files per submission cycle) for historical comparison
- Track submission-to-score mapping to identify which submitted data points had the highest impact on final scores

**Leadership Dashboard**
A visual reporting layer providing executives and service line leaders with an at-a-glance view of ranking readiness.

- Current vs. projected ranking score by USNWR dimension
- Trend lines showing trajectory over the pilot period
- Alert indicators when projected scores fall below target thresholds

### 2.3 Data Sources

| Source | Description | Access Method |
|--------|-------------|---------------|
| QlikSense Survey Applications | Custom-built QlikSense apps already structured around USNWR survey dimensions; primary metric source for clinical outcomes, volume, quality, and patient experience | Direct export / API from QlikSense |
| Audited Registry Data | The authoritative clinical data source for USNWR submissions — audited registry data (not raw EPIC/EHR data). USNWR rankings are certified based on registry submissions. | Client-provided registry exports |
| Prior-Year USNWR Survey Submissions | Historical survey submissions and scored results from TCH, including downloadable CSV files (~300 per submission cycle) | Client-provided |
| USNWR Methodology & Code Mapping | Publicly available weighting and scoring methodology; USNWR codes with their multiple descriptions per survey dimension | Public / Deloitte research |
| Peer Benchmarking Data | Publicly available USNWR scores and rankings for comparable institutions | Public |

> **Important Data Distinction:** USNWR rankings are certified by physicians and based on audited registry data — not raw EPIC/EHR data. The model must source from registry-quality data to ensure alignment with what is actually submitted. For reference, other service lines (e.g., Heart) use external registries such as STS (Society of Thoracic Surgeons); the Diabetes pilot should identify the equivalent audited data source (e.g., T1D Exchange, SWEET registry, or internal diabetes registry).

### 2.4 Service Line Focus

**Pilot Service Line:** Diabetes
Future phases may extend the model to additional ranked service lines pending pilot outcomes.

---

## 3. Success KPIs

### 3.1 Technical Performance KPIs

| KPI | Description | Target |
|-----|-------------|--------|
| Model Predictive Accuracy | Correlation between model-projected ranking score and actual USNWR score (validated against prior-year holdout data) | ≥ 85% |
| Data Refresh Frequency | How frequently the model ingests updated QlikSense data and recalculates projections | ≤ 24-hour lag |
| Metric Coverage | % of USNWR-scored dimensions for diabetes successfully mapped to internal data sources | ≥ 80% |
| Dashboard Availability | System uptime during pilot period | ≥ 99% |
| Simulation Response Time | Time to return a what-if scenario result after user input | ≤ 10 seconds |

### 3.2 User Adoption & Experience KPIs

| KPI | Description | Target |
|-----|-------------|--------|
| Active User Rate | % of invited pilot users engaging with the dashboard or model at least bi-weekly | ≥ 70% |
| Task Completion Rate | % of user queries or simulation tasks completed without analyst escalation | ≥ 80% |
| User Satisfaction Score | Average score from end-of-pilot survey (1–5 scale) | ≥ 4.0 |
| Time-to-Insight Reduction | Reduction in time to assess USNWR ranking readiness vs. current manual process | ≥ 50% |

### 3.3 Business Impact KPIs

| KPI | Description | Target |
|-----|-------------|--------|
| Performance Gaps Identified | # of USNWR dimension gaps surfaced and validated by clinical/strategy leadership | ≥ 5 actionable findings |
| Improvement Simulations Run | # of what-if scenarios modeled by leadership or strategy teams during pilot | ≥ 10 during pilot period |
| Ranking Score Projection Confidence | Leadership agreement that projected scores are credible and actionable (survey) | ≥ 80% of respondents |
| Proactive Actions Initiated | # of clinical or operational changes initiated based on model recommendations during pilot | ≥ 3 during pilot period |

---

## 4. Pilot Parameters

| Parameter | Detail |
|-----------|--------|
| **Duration** | 8–12 weeks (to be confirmed with Client) |
| **Service Line** | Diabetes (pilot); expandable to additional lines in future phases |
| **Environment** | QlikSense data extract + modeling environment (TBD: Snowflake, Python, or hosted ML platform) |
| **Pilot Users** | 10–15 users: diabetes service line leaders, strategy and planning, quality/outcomes team |
| **Data Requirements** | Minimum 3 years of QlikSense data aligned to USNWR dimensions; prior-year USNWR submissions and scored results |
| **USNWR Methodology Dependency** | Model logic will be built on the most recently published USNWR ranking methodology; updates to methodology may require model recalibration |
| **Governance** | PHI/PII handling per Client data governance policy; de-identified or aggregated data used where possible |

---

## 5. Out of Scope (Pilot Phase)

- Service lines other than Diabetes
- Submission automation or direct integration with USNWR survey portal
- Benchmarking data beyond publicly available USNWR peer scores
- Real-time EHR data feeds (QlikSense extract used as the data source of record)
- Production deployment or enterprise rollout
- Nursing Magnet or other non-USNWR ranking frameworks

---

## 6. Key Assumptions & Risks

| # | Assumption / Risk | Mitigation |
|---|-------------------|------------|
| 1 | QlikSense survey apps are sufficiently structured and documented to map to USNWR dimensions | Data discovery sprint in Week 1–2 to validate coverage; existing custom-built Qlik survey apps reduce mapping risk |
| 2 | Prior-year USNWR survey submissions (including ~300 CSV files per cycle) are available and shareable with the delivery team | Client to confirm data availability before kickoff |
| 3 | USNWR methodology for diabetes rankings is stable year-over-year | Model architecture designed to accommodate annual methodology updates |
| 4 | Audited registry data (not raw EPIC data) is accessible and of sufficient quality for predictive modeling | Confirm which registry (T1D Exchange, internal diabetes registry, or other) serves as the source of truth; validate data quality in discovery phase |
| 5 | Actual USNWR survey cycle may not fall within the pilot window, limiting live validation | Use prior-year holdout data for validation; flag for post-pilot confirmation |
| 6 | USNWR codes map to multiple descriptions, creating complexity in metric-to-dimension mapping | Build a code-to-description reference table during discovery; validate mappings with clinical SMEs |
| 7 | Expert Opinion / Reputation dimension is physician-certified and not directly controllable through operational changes | Model will distinguish between directly controllable dimensions (outcomes, volume, safety) and influence-based dimensions (reputation); sensitivity analysis will reflect this distinction |
| 8 | Each service line may rely on different external registries (e.g., Heart uses STS); Diabetes registry source must be confirmed | Identify and confirm the authoritative Diabetes registry data source during kickoff |

---

## 7. Next Steps

| # | Action | Owner | Due |
|---|--------|-------|-----|
| 1 | Confirm pilot scope and service line focus with Client | Client + Delivery Lead | TBD |
| 2 | Obtain access to QlikSense data exports and prior-year USNWR results | Client Data Team | TBD |
| 3 | Conduct USNWR methodology mapping workshop | Strategy + Delivery Team | TBD |
| 4 | Finalize KPI targets with Client stakeholders | Strategy Lead | TBD |
| 5 | Establish pilot user group and feedback cadence | Client Champion | TBD |
| 6 | Kick off Pilot Development (model build + dashboard) | Delivery Team | TBD |

---

*This document is a working draft and subject to revision based on Client input and discovery findings.*
