# MIS Intercompany Invoice Matching — Snowflake Cortex AI Pilot Plan

**Version:** 2.0 (invoice-level scope) | **Period:** Mar 2026 reference data | **Scope:** MIS business unit only

**Status:** Working draft — for Evident review, then handoff to Cortex Code for build

---

## How to read this document

This document serves three audiences. Skip what you don't need:

- **Evident process owners** — read sections 1–3 and section 9 (the walkthrough script). These confirm what we understand about the current process and how we'd demo it back to you.
- **Snowflake Cortex Code implementers** — read sections 4–8. These have the table definitions, matching SQL, Cortex prompts, and stored procedures.
- **Project leads** — read everything, but section 10 (open questions) is where you'll want to focus discussions.

---

## Table of Contents

1. [Executive Summary](#1-executive-summary)
2. [Current Process — What We Understand](#2-current-process--what-we-understand)
3. [Source Data Map — Where the Invoices Are](#3-source-data-map--where-the-invoices-are)
4. [Snowflake Data Model](#4-snowflake-data-model)
5. [Entity Adapters — Parsing Different Formats](#5-entity-adapters--parsing-different-formats)
6. [Matching Logic](#6-matching-logic)
7. [End-to-End Process Flow](#7-end-to-end-process-flow)
8. [Validation & Reporting](#8-validation--reporting)
9. [Walkthrough Script for Evident Demo](#9-walkthrough-script-for-evident-demo)
10. [Open Questions for Evident](#10-open-questions-for-evident)
11. [Appendix: Code Templates](#11-appendix-code-templates)

---

## 1. Executive Summary

### 1.1 Goal

Automate the matching of intercompany invoices between Evident entities for the MIS business unit, using a three-tier engine:

1. **Tier 1 — Deterministic invoice matching** on document number / reference number / sort key when both sides agree
2. **Tier 2 — Fuzzy matching** using amount + date + counterparty + GL account when the document number link is broken
3. **Tier 3 — AI-assisted human-in-the-loop (HITL) review** for items the first two tiers cannot resolve, with Cortex classifying root cause and proposing journal entries

### 1.2 Key insight from data review

**Invoice-level data exists in the bilateral pair files** that the consolidation team uses for Business Day 1–4 reconciliation between entity pairs. These are NOT the same as the consolidated MIS workbook (`Interco_reconciliation_Mar_26 MIS-only.xlsx`) — that workbook only carries aggregated GL-account balances.

Validated example: `(EJP)_(ECN)03_2026 D1(0401)-Signed_Final.xlsx` contains 434 invoice rows on the EJP receivable side and 500 on the ECN payable side. Matching on the document/reference number yields **428 exact matches (98.6% of EJP rows)**, all with currency agreement and zero amount difference. The 72 unmatched ECN rows correspond exactly to the "invoices not taken up" residual the consolidator flags in the consolidated workbook.

### 1.3 Why this is harder than it looks

Each entity uses its own ERP and own template tab structure within the bilateral files. We have observed:
- **EJP (SAP, Japan)** — uses tabs `EJP AR-T(MIS)`, `EJP AR-O(MIS)`, etc. with Japanese column headers (`ソートキー`, `伝票番号`)
- **ECN (SAP, China)** — uses the universal `Master (Trade)` template with English headers
- **EEU (SAP, Europe)** — does NOT populate the universal template; instead exports raw SAP transaction lists with English column headers in tabs like `EEU 0331 D2`
- **EUSA (NetSuite, US)** — exports completely different schema (A/R aging report) with `IN-Ixxxxxx` invoice format and `RA-Ixxxx` reference numbers
- **Multiple file versions** — some pairs have 2–3 file iterations (`D1`, `D2`, `D3`, `D4` reflecting business-day deadlines, sometimes with revision suffixes like `_rev`, `_Final`)

**Implication:** The pilot needs an entity-by-entity adapter library, not one universal parser.

### 1.4 Expected outcomes

| Metric | Current (manual) | Pilot target |
|--------|------------------|--------------|
| Invoice-level match rate (where source data permits) | ~95% (manual matching on bilateral files) | 90%+ deterministic |
| Pairs reconciled per close | 35 MIS pairs | All 35 |
| Cycle time (data submitted → journals drafted) | 4–8 business days | <1 day for clean pairs |
| Items requiring HITL review per close | All non-clean items (estimated 50–100) | Estimated 20–40 |

### 1.5 Out of scope for this pilot

- TNM business unit (separate scope)
- Direct posting of journals to SAP/HFM (we produce drafts only; humans book)
- Real-time reconciliation (we run on a monthly close cadence, mirroring current process)
- Replacing the bilateral PIC sign-off process (we automate matching; PICs still review and approve)

---

## 2. Current Process — What We Understand

### 2.1 The three-layer document architecture

The MIS reconciliation process is organized in three layers of files. Understanding this hierarchy is essential because each layer plays a different role and the invoice-level data lives in only one of them.

```
LAYER 1 — Per-entity templates (16 files)
├── ENTITY_Interco template Mar'26.xlsx (one per entity)
└── Purpose: Reference data — entity's own trial balance, GL account list,
            SAP↔HFM↔OneStream mapping, IC entity master.
            NOT used for matching. NOT a transaction file.

LAYER 2 — Bilateral pair files (37 files)  ← INVOICES LIVE HERE
├── EJP information/EJP receivables/(EJP)_(XXX)... (12 files where EJP is creditor)
├── EJP information/EJP payables/XXX_EJP_... (17 files where EJP is debtor)
└── EEU-ETCE-ESCE information/... (8 files for the European hub)
    Purpose: Invoice-by-invoice reconciliation between two named entities.
             Both PICs sign off bilaterally on Business Day 1, 2, 3 or 4.
             Each pair gets one file with both sides' detail in separate tabs.

LAYER 3 — Consolidated reconciliation workbook (1 file)
└── Interco_reconciliation_Mar_26 MIS-only.xlsx
    Purpose: After all 35 pair files are signed off, the central coordinator
             pulls aggregated balances into one master workbook for journal
             posting and consolidation reporting.
             Compilation tab carries GL-level aggregates (NO invoices).
             MISvsMIS tab is the pair-level scorecard.
             Per-pair tabs document residuals and journal proposals.
             Entry Summary tab is the final journal pack.
```

### 2.2 The monthly process timeline

```
BD-2 to BD-1:  Each entity's PIC runs ERP extracts to populate their side
               of each bilateral pair file.

BD 1:          "D1" pairs (e.g. EJP-ECN) are due — both sides exchange data.
               PICs reconcile invoice-by-invoice, sign off on residual balance.

BD 2:          "D2" pairs reconciled and signed.

BD 3-4:        "D3" and "D4" pairs reconciled and signed (longer cycle for
               more complex pairs like EJP-EEU which has cash pool, ICL,
               and trade balances).

BD 4-5:        Central coordinator pulls signed-off balances from all 35
               pairs into the consolidated workbook (Layer 3).

BD 5-7:        Coordinator drafts correcting journals for residuals,
               populates Entry Summary, gets controller sign-off.

BD 8+:         Each entity's accountant books the relevant journal lines
               in their local SAP/HFM. Consolidation reporting picks up
               the corrected balances.
```

### 2.3 What problem the AI pilot solves

The bilateral PIC reconciliation in BD 1–4 is the labor-intensive step. Two PICs sit on a video call comparing their invoice lists side by side, finding matches manually, identifying gaps, and agreeing on what's a forex difference vs a real reconciling item. Each pair takes 30–90 minutes depending on volume. With 35 MIS pairs, that's 20–50 person-hours per close.

The AI pilot replaces the manual bilateral matching with automated three-tier matching, producing:
- A pre-matched invoice list for each pair (Tier 1 + 2 results)
- A residuals list with AI-suggested root cause and journal proposals (Tier 3)

PICs still review and approve, but their work shifts from "find matches by eye" to "approve the AI's matches and decide on the residuals." Estimated time-savings: 60–70% of the bilateral reconciliation effort.

---

## 3. Source Data Map — Where the Invoices Are

### 3.1 Files in scope (Mar 2026 sample)

The 37 bilateral pair files, structured as follows:

#### Group A: EJP-side files (29 files in EJP information folder)

**EJP receivables** (12 files — EJP is the creditor):
- `(EJP)_(EAS)3_2026 D 1(0401)Final.xlsx`
- `(EJP)_(ECDN and MIS CANADA)03_2026 D2(0402)_Final.xlsx`
- `(EJP)_(ECN)03_2026 D1(0401) -Signed_Final.xlsx` ← **VALIDATED**
- `(EJP)_(EEU)03_2026 D4(0406)_Fianl_Rev.xlsx`
- `(EJP)_(EIND)3_2026 D-1(0331)Final.xlsx`
- `(EJP)_(EKR)3_2026 D 4(0406)Final.xlsx`
- `(EJP)_(ENF)03_2026 D3(0403)_Final (1).xlsm`
- `(EJP)_(ESCE)03_2026 D-1(0331)_Fianl.xlsx`
- `(EJP)_(ESG)3_2026 D 1(0401)Final.xlsx`
- `(EJP)_(ETCE) 03_2026 D1(0401)_Final.xlsx`
- `EGZ-EJP 2026-03 (Final).xlsx`

**EJP payables** (17 files — EJP is the debtor):
- `EAS_EJP_3_0312.xlsx`
- `ECDN - EJP - MARCH 31_rev.xlsx`
- `ECN_EJP_03_31_2026 -Signed.xlsx`
- `EEU_EJP_03_31_2026(0406_rev).xlsx`
- `EGZ_EJP_03_25_2026.xlsx`
- `EIND_EJP_3_0325.xlsx`
- `EKR_EJP_3_0331.xlsx`
- `ENF_EJP_03.2026(Final)0403.xlsx`
- `ESCE _EJP_03_20260331.xlsx`
- `ESG_EJP_3_2026_0410.xlsx`
- `ETCE_EJP_03_31 D3_rev.XLSX`
- `EUSA - EJP - 03.31.2026.xlsx` (NetSuite format)
- `EUSA-EJP_03_2026(0401)-(20250410).xlsx` (multiple revisions)
- `PCDN _EJP_03_2026(0403).xlsx`
- `PIND  _EJP_03_2026(0403).xlsx`
- `PUSA _EJP_03_2026(0403).xlsx`

#### Group B: EEU-ETCE-ESCE hub files (8 files)

These cover intercompany within the European hub and between EU entities and other regions where EJP is not involved:
- `EEU-ETCE-ESCE payables/EEU/ECDN - EEU - MARCH 31.xlsx`
- `EEU-ETCE-ESCE payables/EEU/EUSA - EEU - 03.31.2026.xls`
- `EEU-ETCE-ESCE payables/ESCE/EUSA - ESCE - 03.31.2026.xlsx`
- `EEU-ETCE-ESCE payables/ETCE/(ENF)_(ETCE) 03.2026(0331).xlsx`
- `EEU-ETCE-ESCE payables/ETCE/EGZ-ETCE AP   2026-03 (Final).xlsx`
- `EEU-ETCE-ESCE receivables/ETCE_EAS_03_31 D3.XLSX`
- `EEU-ETCE-ESCE receivables/ETCE_ECN_03_31 D3.XLSX`
- `EEU-ETCE-ESCE receivables/ETCE_EUSA MIS_03_31 D3.XLSX`
- (plus several more)

#### File naming convention

```
(RECEIVABLE_PARTY)_(PAYABLE_PARTY)_PERIOD_DEADLINE(DATE)_STATUS.xlsx

Examples:
  (EJP)_(ECN)03_2026 D1(0401) -Signed_Final.xlsx
   └─ EJP is creditor, ECN is debtor, March 2026, Business Day 1 deadline (Apr 1), signed and final

  EEU_EJP_03_31_2026(0406_rev).xlsx
   └─ EEU is creditor, EJP is debtor, March 31 2026, file dated April 6, revised version
```

The `D1`/`D2`/`D3`/`D4` suffix is the Business Day deadline. The `_Final`, `_Signed`, `_rev` suffixes indicate revision status. **For automated ingestion, the pipeline must select the latest version for each pair** based on the file modification date or revision suffix priority.

### 3.2 Tab patterns by entity (where in each file the data lives)

Different entities populate different tabs within the bilateral file. The pipeline needs entity-specific extraction logic.

#### Pattern A: EJP (SAP Japan) — tabs in pair files where EJP is involved

| Tab name | Content | Status |
|----------|---------|--------|
| `EJP AR-T(MIS)` | EJP MIS trade receivables — invoice-level | **PRIMARY DATA** |
| `EJP AR-T(TNM)` | EJP TNM trade receivables — invoice-level | Out of MIS scope |
| `EJP AR-O(MIS)` | EJP MIS other receivables (non-trade) — invoice-level | **PRIMARY DATA** |
| `EJP AR-O(TNM)` | EJP TNM other receivables — invoice-level | Out of MIS scope |
| `EJP AP-Trade(MIS)` | EJP MIS trade payables (when EJP is debtor) | **PRIMARY DATA** |
| `EJP AP-Other(MIS)` | EJP MIS other payables — invoice-level | **PRIMARY DATA** |
| `EJP account balance(AR)` / `(AP)` | Aggregated GL balances — reference only | Validation oracle |
| `Summary Reconciliation` | Cross-side aggregate comparison | Validation oracle |

EJP column headers are mixed Japanese/English. Key fields:
- Column A: `Reference` / `ソートキー` (sort key) — **the bilateral document number**
- Column B: `Text` / `テキスト` — invoice description
- Column F: `Document Number` / `伝票番号` — EJP's local SAP doc number (10 digits)
- Column I: `Document Date` / `転記日付`
- Column J: `Document currency` / `伝票通貨` (note: "RMB" used for "CNY")
- Column K: `Amount in doc. curr.` / `伝票通貨額`
- Column L: `Amount in local currency` / `金額 (国内通貨)`
- Column M: `Net due date` / `支払期日`
- Column N: `Trading partner` / `取引先コード`
- Column O: `Profit Center` / `利益センタ`

Data starts at row 3 (rows 1–2 are headers).

#### Pattern B: SAP-counterparty using "Master (Trade)" universal template

Used by ECN and some other SAP-based entities. Tab named `Master (Trade) (XXX 0203)` where XXX is the entity code, OR sometimes just `Master (Trade)`. English column headers from a documented template specification.

| Column | Field | Notes |
|--------|-------|-------|
| A | Fiscal Year | e.g. 2026 |
| B | Period | e.g. 3 |
| C | Company Code | SAP company code |
| D | Trading Partner | ICP code of counterparty |
| E | G/L Account | Local SAP GL |
| F | **Document Number** | **The match key — equals EJP's sort_key** |
| G | Reference Number (PO) | Often null |
| H | Posting Date | DD/MM/YYYY |
| I | Document Date | Invoice date |
| J | BU / Segment | LS, IE, RVI, NDT, ANI |
| K | Amount in doc. curr. | Sign opposite to creditor side |
| L | Document currency | 3-char ISO |
| M | Amount in local currency | |
| N | Local Currency | |

Data starts at row 31 (rows 1–30 are file format spec and template headers).

#### Pattern C: SAP-counterparty using native ERP extracts

Used by EEU, ETCE in some files. Instead of populating `Master (Trade)`, they paste in raw SAP transaction reports. Multiple tabs per file with names like:
- `EEU 0331 D2`
- `EJP AP-Other(MIS) 0331`
- `EJP AP-Other(MIS) 0402(D1)`
- `EEU Cash Pool 1126` (for ICL and treasury balances)

These have English column headers but with different naming conventions:
- Column F: `Document Number` (different format than Master template — 10-digit numeric)
- Column G/H: `Reference` / `Assignment` — **this is where the match key lives for these entities**
- Column I: `Document Type` (SA, DA, KR, etc.)

The pipeline must detect which tab has the relevant data by looking at the tab name pattern, and then map columns appropriately for that entity.

#### Pattern D: NetSuite-counterparty (EUSA, MIS-USA, possibly others)

Used by EUSA when it's the creditor or debtor. Tab is typically a single tab named `ROW` or similar, containing a NetSuite "Custom A/R Aging With GL Account" or "A/P Aging" report.

Schema is completely different:
- `Customer:Job` / `Vendor:Job` — counterparty
- `Transaction Type` (Invoice, Credit Memo, Bill, etc.)
- `Date` — transaction date
- `Document Number` — NetSuite invoice number, format `IN-Ixxxxxx` or `CM-Ixxxxx`
- `P.O. No.` — purchase order, format like `5511552314 - RA-I5683`
- `Due Date`
- `Age` (days outstanding)
- `Open Balance` — amount
- `Amount Due (Foreign Currency)`
- `Account: Name (GL-style)` — GL account formatted as "12099 - Interco A/Rs:12141 - Interco A/R - Evident Corporation"

**Match key for NetSuite ↔ SAP pairs:** typically the P.O. number (the `RA-Ixxxx` portion or the leading SAP-style document number) connects to the SAP counterparty's `Document Number` or `Reference`. This is the most fragile pairing in the pilot — needs case-by-case validation.

### 3.3 Universal match key logic

After parsing each entity's native format, every invoice line gets normalized into a common shape with three potential match keys (in priority order):

| Key | Purpose | Example | Coverage |
|-----|---------|---------|----------|
| `BILATERAL_DOC_NUMBER` | The shared SAP-to-SAP document number (EJP sort_key = counterparty Document Number) | `00715005` | High for SAP-to-SAP pairs |
| `LOCAL_DOC_NUMBER` | Each entity's own SAP/ERP doc number | `2100010726` (EJP) or `IN-I274393` (NetSuite) | Always populated, but rarely matches across entities |
| `REFERENCE_NUMBER` | Free-text or PO reference | `RA-I5683` or `INTEREST APR,MAY` | Variable — used for fuzzy fallback |

For SAP-to-SAP pairs, deterministic matching uses `BILATERAL_DOC_NUMBER` and achieves ~98% match.

For SAP-to-NetSuite pairs (anything involving EUSA, MIS-USA, PUSA), deterministic matching tries `BILATERAL_DOC_NUMBER` → `REFERENCE_NUMBER` → fuzzy on amount+date+counterparty. Expected match rate is lower, perhaps 60–80%.

### 3.4 Confirmed match validation — EJP vs ECN

To establish a baseline, we ran the deterministic match logic against the EJP-vs-ECN bilateral file:

```
Source: (EJP)_(ECN)03_2026 D1(0401) -Signed_Final.xlsx

Side A — EJP AR-T(MIS) tab (EJP creditor side, MIS only):
  434 invoice rows
  Match key field: column A (Reference / ソートキー)
  Sample values: 00715005, 00715006, 00715007, ...

Side B — Master (Trade) (ECN 0203) tab (ECN debtor side):
  500 invoice rows
  Match key field: column F (Document Number)
  Sample values: 00715005, 00715006, 00715007, ...

Match logic:
  EJP.sort_key = ECN.document_number
  AND currencies agree (after RMB→CNY normalization)
  AND amounts oppose (EJP +amount = -1 × ECN amount)

Results:
  ✓ 428 matches (98.6% of EJP rows)
  ✓ 0 amount discrepancies (all 428 net to exactly zero in document currency)
  ✓ 0 currency discrepancies
  ✗ 6 EJP rows unmatched — all are footer/header artifacts (Japanese text rows, not real data)
  ✗ 72 ECN rows unmatched — these are the "invoices not taken up by EJP" residual
                              that appears in the consolidated MISvsMIS tab as CNY 434k

Conclusion: With proper invoice-level data, deterministic matching is highly effective.
            The pipeline correctness is validated. Now we need to scale to all 35 pairs
            with their varying source formats.
```

---

## 4. Snowflake Data Model

### 4.1 Schema overview

```
INTERCO_MIS_PILOT/
├── RAW/                 # Raw extracts from source files (pre-normalization)
│   ├── RAW_EJP_INVOICES
│   ├── RAW_SAP_TEMPLATE_INVOICES
│   ├── RAW_SAP_NATIVE_INVOICES
│   └── RAW_NETSUITE_INVOICES
├── REF/                 # Reference data
│   ├── REF_ENTITIES
│   ├── REF_FOREX
│   ├── REF_GL_ACCOUNTS
│   ├── REF_ENTITY_ADAPTERS
│   └── REF_KNOWN_ISSUES
├── STAGING/             # Normalized invoice data
│   └── STG_INVOICE_LINES
├── RESULTS/             # Match outputs
│   ├── MATCHED_INVOICES
│   ├── FUZZY_CANDIDATES
│   └── UNMATCHED_INVOICES
├── HITL/                # Human-in-the-loop review
│   ├── REVIEW_QUEUE
│   ├── PROPOSED_JOURNALS
│   └── AUDIT_LOG
└── REPORTS/             # Dynamic tables for reporting
```

### 4.2 Core normalized invoice table

This is the key table — every parsed invoice line ends up here in a common shape regardless of source format.

```sql
CREATE OR REPLACE TABLE INTERCO_MIS_PILOT.STAGING.STG_INVOICE_LINES (
    -- Identity
    INVOICE_LINE_ID         VARCHAR(50) NOT NULL,            -- UUID, generated on load
    SOURCE_FILE             VARCHAR(500) NOT NULL,           -- absolute path of source file
    SOURCE_TAB              VARCHAR(100) NOT NULL,           -- tab name within source file
    SOURCE_ROW              INTEGER NOT NULL,                -- row number in source tab
    LOAD_TIMESTAMP          TIMESTAMP_NTZ DEFAULT CURRENT_TIMESTAMP(),
    PERIOD_KEY              VARCHAR(7) NOT NULL,             -- YYYY-MM, e.g. '2026-03'

    -- Entity context
    REPORTING_ENTITY        VARCHAR(10) NOT NULL,            -- e.g. 'EJP', 'ECN' — whose books this row is from
    COUNTERPARTY_ENTITY     VARCHAR(10) NOT NULL,            -- e.g. 'ECN', 'EJP' — the other side
    CANONICAL_PAIR          VARCHAR(30) NOT NULL,            -- alphabetical pair key, e.g. 'ECN_vs_EJP'
    BUSINESS_UNIT           VARCHAR(10) NOT NULL,            -- 'MIS' (this pilot is MIS-only)
    CLASS                   VARCHAR(15) NOT NULL,            -- 'AR' or 'AP'
    NATURE                  VARCHAR(50),                     -- Trade-EDI, Trade-non-EDI, Non-trade, Loan (ICL), etc.

    -- Match keys (priority order)
    BILATERAL_DOC_NUMBER    VARCHAR(50),                     -- The shared SAP-to-SAP key (EJP sort_key, counterparty Document Number)
    LOCAL_DOC_NUMBER        VARCHAR(50),                     -- Each entity's own SAP/ERP doc ID
    REFERENCE_NUMBER        VARCHAR(100),                    -- PO number, free-text reference, etc.

    -- GL context
    GL_ACCOUNT              VARCHAR(30),
    GL_ACCOUNT_DESC         VARCHAR(200),

    -- Amounts and currency
    DOC_CURRENCY            VARCHAR(5) NOT NULL,             -- 3-char ISO (after normalization, e.g. RMB→CNY)
    DOC_AMOUNT              NUMBER(20,4) NOT NULL,           -- signed: + for creditor, − for debtor
    LOCAL_CURRENCY          VARCHAR(5),                      -- entity's reporting currency
    LOCAL_AMOUNT            NUMBER(20,4),
    JPY_AMOUNT              NUMBER(20,4),                    -- translated using REF_FOREX closing rate
    USD_AMOUNT              NUMBER(20,4),                    -- translated using REF_FOREX closing rate

    -- Dates
    POSTING_DATE            DATE,
    DOCUMENT_DATE           DATE,
    DUE_DATE                DATE,

    -- Other
    DESCRIPTION_TEXT        VARCHAR(500),                    -- free-text description, used for embeddings
    PROFIT_CENTER           VARCHAR(20),
    SEGMENT                 VARCHAR(10),                     -- e.g. LS, IE, RVI

    -- Quality flags
    IS_VALID                BOOLEAN DEFAULT TRUE,            -- false if row failed validation rules
    VALIDATION_NOTES        VARCHAR(500)                     -- why a row is flagged invalid
);

CREATE INDEX idx_stg_pair ON STG_INVOICE_LINES (CANONICAL_PAIR, PERIOD_KEY);
CREATE INDEX idx_stg_doc  ON STG_INVOICE_LINES (BILATERAL_DOC_NUMBER, PERIOD_KEY);
```

### 4.3 Match results tables

```sql
CREATE OR REPLACE TABLE INTERCO_MIS_PILOT.RESULTS.MATCHED_INVOICES (
    MATCH_ID            VARCHAR(50) NOT NULL,                -- MD5 hash of (line_id_a + line_id_b)
    MATCH_TYPE          VARCHAR(30) NOT NULL,                -- 'TIER1A_DOC', 'TIER1B_REF', 'TIER1C_BALANCE', 'TIER2_FUZZY'
    MATCH_CONFIDENCE    NUMBER(5,2) NOT NULL,                -- 100.00 for Tier 1A, lower for Tier 2

    -- Pair context
    CANONICAL_PAIR      VARCHAR(30) NOT NULL,
    BUSINESS_UNIT       VARCHAR(10) NOT NULL,
    NATURE              VARCHAR(50),
    PERIOD_KEY          VARCHAR(7) NOT NULL,

    -- Side A (typically the creditor / Asset / AR)
    LINE_ID_A           VARCHAR(50) NOT NULL,
    ENTITY_A            VARCHAR(10) NOT NULL,
    DOC_NUMBER_A        VARCHAR(50),
    JPY_AMOUNT_A        NUMBER(20,4),
    POSTING_DATE_A      DATE,

    -- Side B (typically the debtor / Liability / AP)
    LINE_ID_B           VARCHAR(50) NOT NULL,
    ENTITY_B            VARCHAR(10) NOT NULL,
    DOC_NUMBER_B        VARCHAR(50),
    JPY_AMOUNT_B        NUMBER(20,4),
    POSTING_DATE_B      DATE,

    -- Difference
    JPY_DIFFERENCE      NUMBER(20,4),                        -- Should be ~0 for clean matches
    USD_DIFFERENCE      NUMBER(20,4),
    DIFFERENCE_PCT      NUMBER(8,4),
    DATE_GAP_DAYS       INTEGER,
    MATCH_STATUS        VARCHAR(20),                         -- 'CLEAN', 'FOREX_DIFF', 'AMOUNT_DIFF', 'DATE_DIFF'

    CREATED_AT          TIMESTAMP_NTZ DEFAULT CURRENT_TIMESTAMP()
);

CREATE OR REPLACE TABLE INTERCO_MIS_PILOT.RESULTS.UNMATCHED_INVOICES (
    LINE_ID             VARCHAR(50) NOT NULL,
    REPORTING_ENTITY    VARCHAR(10) NOT NULL,
    COUNTERPARTY_ENTITY VARCHAR(10) NOT NULL,
    CANONICAL_PAIR      VARCHAR(30) NOT NULL,
    CLASS               VARCHAR(15),
    NATURE              VARCHAR(50),
    BILATERAL_DOC_NUMBER VARCHAR(50),
    LOCAL_DOC_NUMBER    VARCHAR(50),
    DOC_AMOUNT          NUMBER(20,4),
    DOC_CURRENCY        VARCHAR(5),
    JPY_AMOUNT          NUMBER(20,4),
    POSTING_DATE        DATE,
    UNMATCHED_REASON    VARCHAR(200),                        -- 'No bilateral match', 'Counterparty has no record', etc.
    PERIOD_KEY          VARCHAR(7) NOT NULL
);

CREATE OR REPLACE TABLE INTERCO_MIS_PILOT.RESULTS.FUZZY_CANDIDATES (
    CANDIDATE_ID        VARCHAR(50) NOT NULL,
    CANONICAL_PAIR      VARCHAR(30) NOT NULL,
    LINE_ID_A           VARCHAR(50) NOT NULL,
    LINE_ID_B           VARCHAR(50) NOT NULL,

    -- Match strength signals
    COSINE_SIMILARITY   NUMBER(8,6),                          -- from Cortex EMBED comparison
    AMOUNT_DIFF_PCT     NUMBER(8,4),
    DATE_GAP_DAYS       INTEGER,

    -- Cortex outputs
    CORTEX_ROOT_CAUSE   VARCHAR(500),                         -- JSON from Cortex Complete
    CORTEX_CONFIDENCE   VARCHAR(20),                          -- 'HIGH', 'MEDIUM', 'LOW'
    JOURNAL_RECOMMENDED VARCHAR(5),                           -- 'yes' or 'no'

    PERIOD_KEY          VARCHAR(7) NOT NULL,
    CREATED_AT          TIMESTAMP_NTZ DEFAULT CURRENT_TIMESTAMP()
);
```

### 4.4 Entity adapter configuration

```sql
CREATE OR REPLACE TABLE INTERCO_MIS_PILOT.REF.REF_ENTITY_ADAPTERS (
    ADAPTER_ID          VARCHAR(50) DEFAULT UUID_STRING(),
    ENTITY_CODE         VARCHAR(10) NOT NULL,
    ERP_SYSTEM          VARCHAR(20),                          -- 'SAP_JP', 'SAP_EU', 'SAP_CN', 'NETSUITE_US', etc.
    FILE_NAME_PATTERN   VARCHAR(200),                         -- regex matching file names where this entity's data lives
    TAB_NAME_PATTERN    VARCHAR(200),                         -- regex for relevant tabs
    DATA_START_ROW      INTEGER NOT NULL,                     -- which row data begins (after headers)

    -- Column mapping (1-indexed Excel column numbers or letter codes)
    COL_BILATERAL_DOC   VARCHAR(5),                           -- Excel column letter for bilateral doc number
    COL_LOCAL_DOC       VARCHAR(5),
    COL_REFERENCE       VARCHAR(5),
    COL_DOC_AMOUNT      VARCHAR(5),
    COL_DOC_CURRENCY    VARCHAR(5),
    COL_LOCAL_AMOUNT    VARCHAR(5),
    COL_LOCAL_CURRENCY  VARCHAR(5),
    COL_GL_ACCOUNT      VARCHAR(5),
    COL_POSTING_DATE    VARCHAR(5),
    COL_DOCUMENT_DATE   VARCHAR(5),
    COL_DESCRIPTION     VARCHAR(5),
    COL_PROFIT_CENTER   VARCHAR(5),
    COL_BU_SEGMENT      VARCHAR(5),
    COL_TRADING_PARTNER VARCHAR(5),

    -- Special handling rules
    CURRENCY_NORMALIZE  VARIANT,                              -- e.g. {"RMB": "CNY"} as JSON
    AMOUNT_SIGN_RULE    VARCHAR(20),                          -- 'AS_IS', 'NEGATE_AP', 'NEGATE_AR'
    SKIP_ROWS_PATTERN   VARCHAR(200),                         -- regex of rows to skip (e.g. footer total rows)

    EFFECTIVE_FROM      DATE,
    EFFECTIVE_TO        DATE,
    NOTES               VARCHAR(500),
    CREATED_AT          TIMESTAMP_NTZ DEFAULT CURRENT_TIMESTAMP()
);
```

### 4.5 HITL tables (review queue and journals)

Same structure as in the v1.1 plan. Key elements:

```sql
CREATE OR REPLACE TABLE INTERCO_MIS_PILOT.HITL.REVIEW_QUEUE (
    QUEUE_ID            VARCHAR(50) NOT NULL,
    QUEUE_TYPE          VARCHAR(30),                          -- 'FUZZY_REVIEW', 'UNMATCHED_ESCALATION', 'KNOWN_ISSUE_FAST_TRACK'
    CANONICAL_PAIR      VARCHAR(30),
    BUSINESS_UNIT       VARCHAR(10),
    LINE_ID_A           VARCHAR(50),
    LINE_ID_B           VARCHAR(50),                          -- NULL for fully unmatched
    JPY_AMOUNT_DELTA    NUMBER(20,4),
    AI_ROOT_CAUSE       VARCHAR(500),
    AI_CONFIDENCE       VARCHAR(20),
    REVIEW_STATUS       VARCHAR(20) DEFAULT 'PENDING',        -- PENDING, APPROVED, REJECTED, ESCALATED
    REVIEWER_NAME       VARCHAR(100),
    REVIEWER_DECISION   VARCHAR(50),                          -- 'ACCEPT_MATCH', 'POST_JOURNAL', 'NO_ACTION', 'ESCALATE'
    REVIEWER_NOTES      VARCHAR(1000),
    REVIEW_TIMESTAMP    TIMESTAMP_NTZ,
    PERIOD_KEY          VARCHAR(7),
    CREATED_AT          TIMESTAMP_NTZ DEFAULT CURRENT_TIMESTAMP()
);

CREATE OR REPLACE TABLE INTERCO_MIS_PILOT.HITL.PROPOSED_JOURNALS (
    JOURNAL_LINE_ID     VARCHAR(50) DEFAULT UUID_STRING(),
    JOURNAL_GROUP_ID    VARCHAR(50) NOT NULL,                 -- Groups multi-line journals
    LINE_SEQUENCE       INTEGER NOT NULL,
    QUEUE_ID            VARCHAR(50),
    CANONICAL_PAIR      VARCHAR(30),
    ENTITY_CODE         VARCHAR(10),
    ICP_CODE            VARCHAR(10),
    GL_ACCOUNT          VARCHAR(30),
    DESCRIPTION         VARCHAR(500),
    DOC_CURRENCY        VARCHAR(5),
    LC_AMOUNT           NUMBER(20,4),
    JPY_AMOUNT          NUMBER(20,4),
    BUSINESS_UNIT       VARCHAR(10),
    ENTRY_TAG           VARCHAR(20),                          -- 'BS_ICP_MIS' or 'BS_ICP_TNM'
    JOURNAL_TYPE        VARCHAR(30),
    STATUS              VARCHAR(20) DEFAULT 'DRAFT',          -- DRAFT, APPROVED, REJECTED, POSTED
    APPROVED_BY         VARCHAR(100),
    APPROVED_AT         TIMESTAMP_NTZ,
    PERIOD_KEY          VARCHAR(7),
    CREATED_AT          TIMESTAMP_NTZ DEFAULT CURRENT_TIMESTAMP()
);

-- Validation view: every journal group must net to zero
CREATE OR REPLACE VIEW V_JOURNAL_GROUP_BALANCE AS
SELECT JOURNAL_GROUP_ID, PERIOD_KEY,
    COUNT(*) AS LINE_COUNT,
    SUM(JPY_AMOUNT) AS GROUP_NET_JPY,
    CASE WHEN ABS(SUM(JPY_AMOUNT)) < 1 THEN 'BALANCED' ELSE 'UNBALANCED' END AS STATUS
FROM PROPOSED_JOURNALS
GROUP BY 1, 2;
```

---

## 5. Entity Adapters — Parsing Different Formats

### 5.1 Why adapters exist

A single SQL parser cannot handle the heterogeneity we observed. Each entity's data lives in different tabs, with different column positions, different header languages, and different row offsets. The adapter pattern handles this with **configuration-driven parsing**: each entity has one or more adapter configurations in `REF_ENTITY_ADAPTERS`, and the ingestion pipeline applies the matching adapter to each file.

### 5.2 Initial adapter inventory (from validated examples)

Based on the Mar 2026 entity-level data we reviewed, the initial adapter set is:

| Adapter ID | Entity | Pattern | Tab(s) | Source file pattern |
|-----------|--------|---------|--------|---------------------|
| `EJP_AR_MIS` | EJP | EJP-side AR for MIS | `EJP AR-T(MIS)`, `EJP AR-O(MIS)` | `(EJP)_(*)*.xlsx` (EJP receivable files) |
| `EJP_AP_MIS` | EJP | EJP-side AP for MIS | `EJP AP-Trade(MIS)`, `EJP AP-Other(MIS)`, with date suffix variants | `*_EJP_*.xlsx` (EJP payable files) |
| `SAP_TEMPLATE_TRADE` | ECN, EAS, others | "Master (Trade)" universal template | `Master (Trade) (* ####)`, `Master (Trade)` | Any pair file |
| `SAP_TEMPLATE_NONTRADE` | ECN, EAS, others | "Master (Non-Trade)" universal template | `Master (Non-Trade) (* ####)`, `Master (Non-Trade)` | Any pair file |
| `SAP_NATIVE_EU` | EEU, ETCE, ESCE | SAP raw extract format | `EEU 0331 D2`, `ETCE 0331`, etc. (entity code + date) | Any pair file involving EU entities |
| `SAP_NATIVE_CASHPOOL` | EEU, EJP | Cash pool / ICL transactions | `EEU Cash Pool *`, `EEU_EJP Cash Pool *` | Files with cash pool tabs |
| `NETSUITE_AR_AGING` | EUSA, MIS-USA | NetSuite A/R aging report | `ROW` (single tab) | `EUSA - * - *.xlsx` and similar |
| `NETSUITE_AP_AGING` | EUSA, MIS-USA | NetSuite A/P aging report | `ROW` (single tab) | EUSA-side payable files |

### 5.3 Example adapter configuration — SAP Template Trade

```sql
INSERT INTO INTERCO_MIS_PILOT.REF.REF_ENTITY_ADAPTERS (
    ENTITY_CODE, ERP_SYSTEM, FILE_NAME_PATTERN, TAB_NAME_PATTERN, DATA_START_ROW,
    COL_BILATERAL_DOC, COL_REFERENCE, COL_DOC_AMOUNT, COL_DOC_CURRENCY,
    COL_LOCAL_AMOUNT, COL_LOCAL_CURRENCY, COL_GL_ACCOUNT, COL_POSTING_DATE,
    COL_DOCUMENT_DATE, COL_BU_SEGMENT, COL_TRADING_PARTNER,
    AMOUNT_SIGN_RULE, NOTES
) VALUES (
    'ECN', 'SAP_CN',
    '\\(.+\\)_\\(ECN\\).*\\.xlsx$',
    '^Master \\(Trade\\)( \\(ECN \\d{4}\\))?$',
    31,
    'F', 'G', 'K', 'L', 'M', 'N', 'E', 'H', 'I', 'J', 'D',
    'AS_IS', 'ECN uses universal Master Trade template; AP rows have negative DOC_AMOUNT'
);
```

### 5.4 Example adapter configuration — EJP AR MIS

```sql
INSERT INTO INTERCO_MIS_PILOT.REF.REF_ENTITY_ADAPTERS (
    ENTITY_CODE, ERP_SYSTEM, FILE_NAME_PATTERN, TAB_NAME_PATTERN, DATA_START_ROW,
    COL_BILATERAL_DOC, COL_LOCAL_DOC, COL_DOC_AMOUNT, COL_DOC_CURRENCY,
    COL_LOCAL_AMOUNT, COL_GL_ACCOUNT, COL_DOCUMENT_DATE, COL_DESCRIPTION,
    COL_TRADING_PARTNER, COL_PROFIT_CENTER,
    CURRENCY_NORMALIZE, AMOUNT_SIGN_RULE, NOTES
) VALUES (
    'EJP', 'SAP_JP',
    '\\(EJP\\)_\\(.+\\).*\\.(xlsx|xlsm)$',
    '^EJP AR-[TO]\\(MIS\\)\\s*$',
    3,
    'A', 'F', 'K', 'J', 'L', 'E', 'I', 'B', 'N', 'O',
    PARSE_JSON('{"RMB": "CNY"}'),
    'AS_IS', 'EJP creditor side for MIS — AR data only'
);
```

### 5.5 Adapter execution model

The adapter is consumed by an ingestion stored procedure that loops over all uploaded files, applies pattern matching to identify the right adapter for each (file, tab) combination, and emits rows into `RAW_*` tables. Then a normalization step transforms `RAW_*` → `STG_INVOICE_LINES` applying the column mapping and any currency/sign rules.

A reasonable approach for the pilot is to use a Python UDF or an external Python script that:
1. Reads each Excel file using openpyxl
2. For each tab, finds the matching adapter by regex
3. Extracts cells per the column mapping
4. Writes JSON rows to a staging table
5. Snowflake then transforms the JSON into typed columns

Alternatively, the files can be pre-parsed in Python outside Snowflake and the resulting CSVs loaded via COPY INTO. This is simpler for the pilot.

### 5.6 Identifying rows to skip

Validated example: in EJP's `EJP AR-T(MIS)` tab, rows after the actual data contain Japanese footer text ("消込済/未消込明細シンボル", "勘定コード"). The adapter's `SKIP_ROWS_PATTERN` field carries a regex that matches these. The same pattern handles totals/subtotals in NetSuite reports ("Total Customer:Job Evident...", etc.).

---

## 6. Matching Logic

The pilot uses three tiers in sequence. Each tier takes the unmatched output of the previous one as input.

### 6.1 Tier 1A — Deterministic on bilateral document number

This is the strongest match. Both sides agree on a shared bilateral identifier (typically the SAP document number that travels between SAP systems on intercompany postings).

**Match conditions (all required):**
- Same `CANONICAL_PAIR`
- Same `BUSINESS_UNIT` (always 'MIS' for this pilot)
- `BILATERAL_DOC_NUMBER` is non-null on both sides AND equal
- One side is `CLASS = 'AR'`, the other `CLASS = 'AP'`
- `DOC_CURRENCY` agrees (after normalization, e.g. RMB→CNY)
- `DOC_AMOUNT` magnitudes equal within JPY 100 tolerance
- Signs oppose (AR side positive, AP side negative)

**SQL (skeleton):**
```sql
-- Tier 1A: bilateral document number match
INSERT INTO MATCHED_INVOICES (...)
SELECT
    MD5(a.INVOICE_LINE_ID || '|' || b.INVOICE_LINE_ID)  AS MATCH_ID,
    'TIER1A_DOC'                                          AS MATCH_TYPE,
    100.00                                                AS MATCH_CONFIDENCE,
    a.CANONICAL_PAIR, a.BUSINESS_UNIT, a.NATURE,
    a.PERIOD_KEY,
    a.INVOICE_LINE_ID, a.REPORTING_ENTITY, a.BILATERAL_DOC_NUMBER, a.JPY_AMOUNT, a.POSTING_DATE,
    b.INVOICE_LINE_ID, b.REPORTING_ENTITY, b.BILATERAL_DOC_NUMBER, b.JPY_AMOUNT, b.POSTING_DATE,
    a.JPY_AMOUNT + b.JPY_AMOUNT                           AS JPY_DIFFERENCE,
    a.USD_AMOUNT + b.USD_AMOUNT                           AS USD_DIFFERENCE,
    ABS((a.JPY_AMOUNT + b.JPY_AMOUNT) / NULLIF(b.JPY_AMOUNT,0)) * 100 AS DIFFERENCE_PCT,
    DATEDIFF('day', b.POSTING_DATE, a.POSTING_DATE)       AS DATE_GAP_DAYS,
    CASE
        WHEN ABS(a.JPY_AMOUNT + b.JPY_AMOUNT) < 100 THEN 'CLEAN'
        ELSE 'FOREX_DIFF'
    END                                                    AS MATCH_STATUS
FROM STAGING.STG_INVOICE_LINES a
JOIN STAGING.STG_INVOICE_LINES b
    ON  a.CANONICAL_PAIR        = b.CANONICAL_PAIR
    AND a.BUSINESS_UNIT         = b.BUSINESS_UNIT
    AND a.PERIOD_KEY            = b.PERIOD_KEY
    AND a.BILATERAL_DOC_NUMBER  = b.BILATERAL_DOC_NUMBER
    AND a.BILATERAL_DOC_NUMBER  IS NOT NULL
    AND a.CLASS                 = 'AR'
    AND b.CLASS                 = 'AP'
    AND a.DOC_CURRENCY          = b.DOC_CURRENCY
    AND ABS(ABS(a.DOC_AMOUNT) - ABS(b.DOC_AMOUNT)) < ABS(a.DOC_AMOUNT) * 0.001  -- 0.1% tolerance
    AND a.REPORTING_ENTITY     <> b.REPORTING_ENTITY
WHERE a.PERIOD_KEY = '2026-03'
QUALIFY ROW_NUMBER() OVER (PARTITION BY a.INVOICE_LINE_ID ORDER BY ABS(a.JPY_AMOUNT + b.JPY_AMOUNT)) = 1
   AND ROW_NUMBER() OVER (PARTITION BY b.INVOICE_LINE_ID ORDER BY ABS(a.JPY_AMOUNT + b.JPY_AMOUNT)) = 1;
```

**Expected coverage:** 70–85% of trade-flow invoices for SAP-to-SAP pairs. Lower for SAP-to-NetSuite pairs.

### 6.2 Tier 1B — Deterministic on reference / PO number

For NetSuite-to-SAP pairs (anything involving EUSA), the bilateral document number doesn't always exist. The fallback key is the PO/reference field — NetSuite stores the SAP-style reference in `P.O. No.` and SAP stores it in the `Reference` or `Assignment` field.

**Match conditions:**
- Same `CANONICAL_PAIR`, `BUSINESS_UNIT`, `PERIOD_KEY`
- Tier 1A did NOT match either side
- `REFERENCE_NUMBER` is non-null on both sides AND equal (after string normalization — strip whitespace, uppercase, etc.)
- `DOC_CURRENCY` agrees
- Amount and sign conditions same as Tier 1A

**Expected coverage:** Additional 5–15% on top of Tier 1A.

### 6.3 Tier 1C — Deterministic on running balances (loans, accrued interest)

Loan and accrued interest balances are not transactional. There's no invoice number. They're running balances that should agree between counterparties at period end. Match by counterparty-balance only.

**Match conditions:**
- Same `CANONICAL_PAIR`, `BUSINESS_UNIT`, `PERIOD_KEY`
- `NATURE` IN ('Loan (ICL)', 'Accrued interest')
- Both sides not yet matched
- Same `DOC_CURRENCY`
- Amount magnitudes within reasonable tolerance (5%) — for FX revaluation differences
- Signs oppose

**Expected coverage:** Captures the ~12% of MIS lines that are non-transactional balances.

### 6.4 Tier 2 — Fuzzy matching with Cortex embeddings

For everything Tier 1 can't match, generate vector embeddings from a text fingerprint and find nearest neighbors on the opposite side of the pair.

**Step 1 — Generate embeddings:**

```sql
ALTER TABLE STG_INVOICE_LINES ADD COLUMN IF NOT EXISTS LINE_EMBEDDING VECTOR(FLOAT, 768);

UPDATE STG_INVOICE_LINES s
SET LINE_EMBEDDING = SNOWFLAKE.CORTEX.EMBED_TEXT_768(
    'snowflake-arctic-embed-m',
    CONCAT_WS(' | ',
        s.CANONICAL_PAIR,
        s.NATURE,
        s.CLASS,
        s.DOC_CURRENCY,
        TO_VARCHAR(ROUND(ABS(s.JPY_AMOUNT) / 1000) * 1000),  -- bucketed to nearest 1000 JPY
        TO_VARCHAR(YEAR(s.POSTING_DATE)) || '-' || TO_VARCHAR(MONTH(s.POSTING_DATE)),
        COALESCE(s.GL_ACCOUNT, 'NA'),
        COALESCE(s.GL_ACCOUNT_DESC, 'NA'),
        COALESCE(s.DESCRIPTION_TEXT, 'NA')
    )
)
WHERE s.PERIOD_KEY = '2026-03'
  AND s.LINE_EMBEDDING IS NULL
  AND s.INVOICE_LINE_ID NOT IN (
    SELECT LINE_ID_A FROM RESULTS.MATCHED_INVOICES WHERE PERIOD_KEY = '2026-03'
    UNION ALL
    SELECT LINE_ID_B FROM RESULTS.MATCHED_INVOICES WHERE PERIOD_KEY = '2026-03'
  );
```

**Step 2 — Find nearest-neighbor candidates:**

```sql
INSERT INTO RESULTS.FUZZY_CANDIDATES
WITH ar_side AS (
    SELECT * FROM STG_INVOICE_LINES
    WHERE PERIOD_KEY = '2026-03' AND CLASS = 'AR'
      AND INVOICE_LINE_ID NOT IN (SELECT LINE_ID_A FROM RESULTS.MATCHED_INVOICES WHERE PERIOD_KEY = '2026-03')
),
ap_side AS (
    SELECT * FROM STG_INVOICE_LINES
    WHERE PERIOD_KEY = '2026-03' AND CLASS = 'AP'
      AND INVOICE_LINE_ID NOT IN (SELECT LINE_ID_B FROM RESULTS.MATCHED_INVOICES WHERE PERIOD_KEY = '2026-03')
)
SELECT
    MD5(a.INVOICE_LINE_ID || '|' || b.INVOICE_LINE_ID)    AS CANDIDATE_ID,
    a.CANONICAL_PAIR,
    a.INVOICE_LINE_ID, b.INVOICE_LINE_ID,
    1 - (VECTOR_L2_DISTANCE(a.LINE_EMBEDDING, b.LINE_EMBEDDING)
         / (SQRT(VECTOR_INNER_PRODUCT(a.LINE_EMBEDDING, a.LINE_EMBEDDING))
            * SQRT(VECTOR_INNER_PRODUCT(b.LINE_EMBEDDING, b.LINE_EMBEDDING)) + 1e-9))  AS COSINE_SIMILARITY,
    ABS((a.JPY_AMOUNT + b.JPY_AMOUNT) / NULLIF(b.JPY_AMOUNT, 0)) * 100  AS AMOUNT_DIFF_PCT,
    DATEDIFF('day', b.POSTING_DATE, a.POSTING_DATE)        AS DATE_GAP_DAYS,
    NULL  AS CORTEX_ROOT_CAUSE,
    NULL  AS CORTEX_CONFIDENCE,
    NULL  AS JOURNAL_RECOMMENDED,
    '2026-03'
FROM ar_side a
JOIN ap_side b
    ON a.CANONICAL_PAIR = b.CANONICAL_PAIR
WHERE 1 - (VECTOR_L2_DISTANCE(a.LINE_EMBEDDING, b.LINE_EMBEDDING) / ...) > 0.75   -- similarity threshold
  AND ABS(DATEDIFF('day', b.POSTING_DATE, a.POSTING_DATE)) <= 60                  -- 60-day window
QUALIFY ROW_NUMBER() OVER (PARTITION BY a.INVOICE_LINE_ID ORDER BY 4 DESC) <= 3;  -- top 3 candidates per AR row
```

**Step 3 — Cortex Complete classification of the difference:**

```sql
UPDATE RESULTS.FUZZY_CANDIDATES fc
SET CORTEX_ROOT_CAUSE = SNOWFLAKE.CORTEX.COMPLETE(
    'mistral-7b',
    CONCAT(
        'You are an MIS intercompany reconciliation specialist for Evident. ',
        'Two invoice lines from opposite sides of an intercompany pair appear to relate ',
        'but did not match deterministically. Classify the most likely root cause from: ',
        'FOREX_ROUNDING, FOREX_REVAL_MISSED, TP_ADJUSTMENT_MISMATCH, ',
        'TNM_MIS_RECLASS, SEGMENT_RECLASS, ENTITY_RECLASS, UNDERACCRUAL, ',
        'PARTIAL_PAYMENT, WRONG_INVOICE_REF, MISSING_COUNTERPARTY, ',
        'UNBILLED_REVENUE, LOAN_BALANCE_DIFF, ACCRUED_INTEREST_DIFF, OTHER. ',
        'Also indicate journal_needed (yes/no), journal_type (SIMPLE_ADJUSTMENT, ',
        'FX_RECLASS, MULTI_LINE_RECLASS, NO_JOURNAL), confidence (high/medium/low), ',
        'note (under 25 words). Return ONLY valid JSON. Data: ',
        '{"pair":"', fc.CANONICAL_PAIR, '"',
        ',"jpy_a":', (SELECT JPY_AMOUNT FROM STG_INVOICE_LINES WHERE INVOICE_LINE_ID = fc.LINE_ID_A)::VARCHAR,
        ',"jpy_b":', (SELECT JPY_AMOUNT FROM STG_INVOICE_LINES WHERE INVOICE_LINE_ID = fc.LINE_ID_B)::VARCHAR,
        ',"amount_diff_pct":', fc.AMOUNT_DIFF_PCT::VARCHAR,
        ',"date_gap_days":', fc.DATE_GAP_DAYS::VARCHAR,
        ',"cosine":', fc.COSINE_SIMILARITY::VARCHAR,
        '}'
    )
)
WHERE PERIOD_KEY = '2026-03' AND CORTEX_ROOT_CAUSE IS NULL;
```

### 6.5 Tier 3 — AI-assisted HITL review

Items that pass Tier 2 with high confidence go to a fast-track review (operator just confirms). Items with low confidence, large amount differences, or no fuzzy candidate at all go to full review.

The HITL Streamlit app shows:
- Both sides of the candidate pair (line A and line B), or just side A if fully unmatched
- The Cortex root cause classification
- A pre-filled journal proposal based on the root cause
- Buttons: Accept Match, Post Journal, No Action, Escalate

For the three known recurring patterns (EJP-vs-ENF reclass, ETCE-vs-MIS-USA segment reclass, ETCE-vs-ESG forex revaluation), the system pre-loads journal templates from `REF_KNOWN_ISSUES` so the operator just confirms the amount.

---

## 7. End-to-End Process Flow

```
┌─────────────────────────────────────────────────────────────────────────┐
│ 1. SOURCE LANDING                                                        │
│    37 bilateral pair files dropped into Snowflake Stage on BD-1 to BD-4  │
│    File pattern: (RECEIVABLE)_(PAYABLE)_PERIOD_DEADLINE.xlsx             │
│    Latest version per pair selected by file modified date / suffix       │
└────────────────────────────┬─────────────────────────────────────────────┘
                             ▼
┌─────────────────────────────────────────────────────────────────────────┐
│ 2. ENTITY ADAPTER PARSING                                                │
│    Python script (or Snowpark UDF) iterates over files                   │
│    For each (file, tab) combination, finds matching adapter in REF       │
│    Extracts rows per column mapping → JSON staging                       │
│    Output: RAW_* tables (one per adapter type)                           │
└────────────────────────────┬─────────────────────────────────────────────┘
                             ▼
┌─────────────────────────────────────────────────────────────────────────┐
│ 3. NORMALIZATION                                                          │
│    SQL transforms RAW_* into common STG_INVOICE_LINES                    │
│    Apply currency normalization (RMB→CNY)                                │
│    Apply amount sign rules                                                │
│    Translate to JPY and USD using REF_FOREX                              │
│    Compute CANONICAL_PAIR (alphabetical entity ordering)                 │
│    Drop quarantine rows (footers, totals, malformed)                     │
└────────────────────────────┬─────────────────────────────────────────────┘
                             ▼
┌─────────────────────────────────────────────────────────────────────────┐
│ 4. TIER 1A — BILATERAL DOC NUMBER MATCH                                  │
│    SQL join on equal BILATERAL_DOC_NUMBER + amount + currency + signs    │
│    Matches written to RESULTS.MATCHED_INVOICES with match_type='TIER1A'  │
│    Expected: 70-85% of trade lines for SAP-to-SAP pairs                  │
└────────────────────────────┬─────────────────────────────────────────────┘
                             ▼
┌─────────────────────────────────────────────────────────────────────────┐
│ 5. TIER 1B — REFERENCE / PO NUMBER MATCH                                 │
│    SQL join on REFERENCE_NUMBER for items not matched in 1A              │
│    Expected: +5-15% (mainly NetSuite ↔ SAP pairs)                        │
└────────────────────────────┬─────────────────────────────────────────────┘
                             ▼
┌─────────────────────────────────────────────────────────────────────────┐
│ 6. TIER 1C — RUNNING BALANCE MATCH (ICL, ACCRUED INTEREST)               │
│    Match on counterparty + nature + currency for non-transactional items │
│    Expected: handles the ~12% of MIS that are loan/interest balances     │
└────────────────────────────┬─────────────────────────────────────────────┘
                             ▼
┌─────────────────────────────────────────────────────────────────────────┐
│ 7. TIER 2 — FUZZY MATCH WITH CORTEX                                      │
│    Generate embeddings on remaining unmatched items                      │
│    Find top-3 nearest neighbors per AR line on the AP side               │
│    Cortex Complete classifies root cause and journal type                │
│    Output: FUZZY_CANDIDATES                                               │
│    Expected: +5-15% additional matches at lower confidence               │
└────────────────────────────┬─────────────────────────────────────────────┘
                             ▼
┌─────────────────────────────────────────────────────────────────────────┐
│ 8. POPULATE HITL REVIEW QUEUE                                            │
│    All Tier 2 candidates (fast-track if Cortex confidence=HIGH)          │
│    All fully unmatched items                                              │
│    Pre-fill journal proposals using REF_KNOWN_ISSUES templates           │
└────────────────────────────┬─────────────────────────────────────────────┘
                             ▼
┌─────────────────────────────────────────────────────────────────────────┐
│ 9. STREAMLIT REVIEW APP                                                  │
│    Operators (PICs and central coordinator) review the queue             │
│    Each decision logged to AUDIT_LOG                                      │
│    Approved journals flow to PROPOSED_JOURNALS                           │
│    Net-zero validation enforced on every JOURNAL_GROUP_ID                │
└────────────────────────────┬─────────────────────────────────────────────┘
                             ▼
┌─────────────────────────────────────────────────────────────────────────┐
│ 10. JOURNAL EXPORT                                                        │
│    Approved journals exported in Entry Summary format                    │
│    Distributed to entity accountants for booking in SAP/HFM              │
│    Downstream consolidation reporting picks up the corrected balances    │
└─────────────────────────────────────────────────────────────────────────┘
```

---

## 8. Validation & Reporting

### 8.1 Pilot success criteria

| Criterion | Target | Measurement |
|-----------|--------|-------------|
| Tier 1A match rate (SAP-to-SAP pairs) | ≥ 90% of invoice rows | Count matched / total in pair |
| Tier 1A match rate (SAP-to-NetSuite pairs) | ≥ 70% of invoice rows | Same |
| Combined Tier 1+2 match rate | ≥ 85% across all 35 pairs | Sum matched / sum lines |
| Pair-level reconciliation to consolidated workbook | Within JPY 100 of MISvsMIS row | Compare pair net residuals |
| Three known recurring issues identified | 3 of 3 | EJP-ENF, ETCE-MIS-USA, ETCE-ESG |
| Journal group net-to-zero compliance | 100% | V_JOURNAL_GROUP_BALANCE check |
| HITL review time per item | ≤ 5 min average | Audit log timestamps |

### 8.2 Reconciliation oracle — comparing to the consolidated workbook

The consolidated `Interco_reconciliation_Mar_26 MIS-only.xlsx` workbook serves as the validation oracle. After running the pipeline against the bilateral files for March 2026, the pair-level totals from the pipeline should reconcile (within FX-rounding tolerance) to the corresponding rows in the MISvsMIS tab of the consolidated workbook.

Validation query:
```sql
-- Pair-level reconciliation: pipeline vs consolidated workbook
SELECT
    pipeline.CANONICAL_PAIR,
    pipeline.PIPELINE_NET_JPY,
    consolidated.CONSOLIDATED_NET_JPY,
    pipeline.PIPELINE_NET_JPY - consolidated.CONSOLIDATED_NET_JPY AS DIFFERENCE,
    CASE WHEN ABS(pipeline.PIPELINE_NET_JPY - consolidated.CONSOLIDATED_NET_JPY) < 100
         THEN 'RECONCILED'
         ELSE 'INVESTIGATE'
    END AS STATUS
FROM (
    SELECT CANONICAL_PAIR, SUM(JPY_AMOUNT) AS PIPELINE_NET_JPY
    FROM STAGING.STG_INVOICE_LINES
    WHERE PERIOD_KEY = '2026-03'
    GROUP BY 1
) pipeline
FULL OUTER JOIN REF.MISVSMIS_BASELINE_2026_03 consolidated
    ON pipeline.CANONICAL_PAIR = consolidated.CANONICAL_PAIR;
```

### 8.3 Standard reports

```sql
-- Match rate summary (dynamic table, refreshes hourly)
CREATE OR REPLACE DYNAMIC TABLE REPORTS.RPT_MATCH_SUMMARY
    TARGET_LAG = '1 hour' WAREHOUSE = INTERCO_MIS_REPORT_WH AS
WITH stats AS (
    SELECT
        COUNT(*) AS total_lines,
        COUNT(CASE WHEN MATCH_TYPE = 'TIER1A_DOC' THEN 1 END) * 2 AS tier1a_lines,
        COUNT(CASE WHEN MATCH_TYPE = 'TIER1B_REF' THEN 1 END) * 2 AS tier1b_lines,
        COUNT(CASE WHEN MATCH_TYPE = 'TIER1C_BALANCE' THEN 1 END) * 2 AS tier1c_lines,
        COUNT(CASE WHEN MATCH_TYPE = 'TIER2_FUZZY' THEN 1 END) * 2 AS tier2_lines
    FROM RESULTS.MATCHED_INVOICES WHERE PERIOD_KEY = '2026-03'
),
total AS (
    SELECT COUNT(*) AS n FROM STAGING.STG_INVOICE_LINES WHERE PERIOD_KEY = '2026-03'
)
SELECT
    '2026-03' AS PERIOD_KEY,
    total.n AS TOTAL_INVOICE_LINES,
    stats.tier1a_lines, stats.tier1b_lines, stats.tier1c_lines, stats.tier2_lines,
    (stats.tier1a_lines + stats.tier1b_lines + stats.tier1c_lines) AS TOTAL_DETERMINISTIC,
    ROUND((stats.tier1a_lines + stats.tier1b_lines + stats.tier1c_lines)::FLOAT / total.n * 100, 1) AS DETERMINISTIC_PCT,
    ROUND((stats.tier1a_lines + stats.tier1b_lines + stats.tier1c_lines + stats.tier2_lines)::FLOAT / total.n * 100, 1) AS COMBINED_MATCH_PCT
FROM stats, total;
```

---

## 9. Walkthrough Script for Evident Demo

This section is the script for walking Evident through the Excel files to demonstrate our understanding of their process and how the pilot will work. Estimated duration: 30 minutes.

### 9.1 Demo flow

#### Part 1: Confirm we understand the current process (10 min)

**Step 1.** Open the consolidated workbook — `Interco_reconciliation_Mar_26 MIS-only.xlsx`. Go to the **`Status`** tab.
> "We understand that 16 PICs across your entities each submit data on a Business Day cycle — D1 through D4. The Status tab is your tracker for who has submitted. Is this still how it works?"

**Step 2.** Switch to the **`Compilation`** tab. Filter on `Business unit = MIS`. Scroll through.
> "After all PICs submit, the data lands here at GL-account level — about 200 rows for MIS in March. Notice there's no invoice number field — the invoice-level work has already happened by the time data lands here. Is that right?"

**Step 3.** Switch to **`MISvsMIS`** tab. Point at the 35 pairs.
> "This is your scorecard. Each row is one entity pair. The columns show the JPY net difference, any adjustment journals already booked, and the residual. Pairs netting to zero are clean. Pairs with non-zero residuals are what your team investigates."

**Step 4.** Click into the **`MIS-EJPvsENF`** tab.
> "This is one of your three big recurring issues — the JPY 468M reclass between TNM and MIS. We understand this is a systemic ERP configuration issue at EJP, not a period-end error. Confirmed?"

#### Part 2: Show where the invoices actually live (10 min)

**Step 5.** Open the bilateral file `(EJP)_(ECN)03_2026 D1(0401) -Signed_Final.xlsx`. Switch to the **`Summary Reconciliation`** tab.
> "This is where the real reconciliation happens. The two columns at the left are EJP's books, the two columns at the right are ECN's books. The bilateral PICs use this tab to align."

**Step 6.** Switch to the **`EJP AR-T(MIS)`** tab. Point at column A (`Reference` / `ソートキー`).
> "EJP's MIS trade receivables — 434 invoice rows. Column A is the SAP sort key — these values like `00715005`, `00715006` are the bilateral document numbers. Each row is one invoice EJP issued."

**Step 7.** Switch to the **`Master (Trade) (ECN 0203)`** tab. Point at column F (`Document Number`).
> "ECN's MIS trade payables — 500 invoice rows starting at row 31. Column F is the document number — same `00715005`, `00715006` pattern. **These are the same invoices as on EJP's side.**"

**Step 8.** Side-by-side, show that row 1 of EJP AR-T(MIS) has sort_key `00715005` with CNY +34,285, and row 31 of Master (Trade) (ECN 0203) has Document Number `00715005` with CNY −34,285.
> "Match is exact. We tested this across all 434 EJP rows and 500 ECN rows — 428 match exactly with zero amount difference. The 72 ECN rows that don't match are the 'invoices not taken up by EJP' that show up as residual in the consolidated workbook."

#### Part 3: How the AI will work (10 min)

**Step 9.** Show the matching tier diagram (section 7 of this doc) — point at Tier 1A.
> "When we ingest the bilateral files into Snowflake, Tier 1A of our matcher does what we just did manually — joins on the bilateral document number. We expect 70-85% of trade flows to match here."

**Step 10.** Open the **`MIS - EEU vs SPIND`** tab in the consolidated workbook.
> "Here's a residual: USD 99,550 for one invoice not taken up by EEU. Currently, when this happens, your team identifies it manually and drafts a 2-line journal. With the pilot, that line shows up automatically in our HITL queue with the AI's analysis."

**Step 11.** Open the **`MIS-EJPvsEUSAMISUSA`** tab. Point at the 6-line reclass journal at the top.
> "And here's a complex one — EUSA reclass to MIS-USA, 6 lines crossing 2 entities and 2 segments. We've documented this as a 'known recurring issue' so when our matcher sees this pattern in the data, it pre-fills the journal template and your team just confirms the amount."

**Step 12.** Open the **`Entry Summary`** tab.
> "Final output of our pilot will be in this exact format — one section per pair, all the columns you have today, all journals net to zero by BS_ICP_MIS tag. Drop-in compatible with how you book today."

### 9.2 Demo prep checklist

Before the meeting:
- [ ] Have all three files open in tabs: consolidated workbook, EJP-ECN bilateral file, this markdown doc
- [ ] Pre-print or screen-share the process flow diagram (section 7)
- [ ] Bring the 98.6% match validation result as a one-slide summary
- [ ] Have the open questions list (section 10) ready for the discussion

### 9.3 Anticipated questions and how to answer

**"How do you handle the case where one PIC hasn't submitted yet?"**
> The pipeline only matches data that's been received. If EEU hasn't submitted by BD3, the EJP-EEU pair will show up in the HITL queue as 'one-sided' — meaning EJP's data is in but EEU's isn't. The PICs see this and know to follow up. Same as today, just visible to all stakeholders in real-time.

**"What if our PICs disagree with the AI's matches?"**
> Every match has a confidence score and is reviewable. The Streamlit app lets PICs reject any match and either reassign it manually or send it back to the queue. The audit log captures every decision so we can tune the matcher over time.

**"Can the AI book journals directly to SAP?"**
> Not in this pilot. We produce journal proposals in the same format as your Entry Summary tab, your team reviews them, your accountants book them in SAP. Direct posting is a future phase that needs SAP integration and additional controls.

**"How do you handle revisions and resubmissions?"**
> The file naming convention has D1/D2/D3/D4 suffixes plus _rev suffixes. Our ingestion pipeline takes the latest version of each pair file by modified timestamp. Earlier versions are kept in the audit trail.

**"What about TNM?"**
> Out of scope for this pilot — we're focused on MIS first to get the pipeline right at smaller scale. The same architecture extends to TNM cleanly once we've validated MIS.

---

## 10. Open Questions for Evident

These are the questions we need answered before / during build to fully scope the pilot. Listing here for visibility, not blockers.

### 10.1 Source data questions

1. **File delivery mechanism.** How will the 37 bilateral pair files reach Snowflake? Options: (a) shared drive → manual upload to Snowflake stage, (b) sFTP push, (c) direct API. Recommend (a) for pilot, (c) for production.

2. **Versioning rules.** When multiple revisions of a pair file exist (`_rev`, `_Final`, `(D1)`, `(D2)`), which is the source of truth? The latest by modified date, or always the file marked `_Signed`? We need a definitive rule for the ingestion pipeline.

3. **Tab naming consistency.** EJP's tabs are sometimes `EJP AR-T(MIS) ` (with trailing space) and sometimes `EJP AR-T(MIS)`. Is there a standard, or is this PIC-by-PIC variation? Affects adapter regex precision.

4. **Cash pool and ICL files.** EEU has separate `Cash Pool` tabs, sometimes split across multiple periods. We need to confirm: are these in scope for MIS (yes for ICL nature), and how should they be aggregated?

5. **Multi-entity files.** Some files cover multiple entity pairs (the `EEU-ETCE-ESCE` hub files). Do we treat each pair separately, or load the whole file and split internally? Affects file-to-pair mapping logic.

### 10.2 Matching logic questions

6. **NetSuite ↔ SAP matching key.** For EUSA-EJP and EUSA-EEU pairs, what's the conventional matching field? We've seen the P.O. Number format (`5511552314 - RA-I5683`) but it's not consistent across all NetSuite documents. Need PIC input on which transactions reliably carry the cross-system reference.

7. **Currency normalization rules.** We've identified `RMB → CNY` mapping. Are there other currency code variations across systems we should handle? (e.g. `RMB` vs `CNY`, `JPY` vs `¥`, etc.)

8. **Sign convention.** EJP records AR as positive and AP as negative. Do all entities follow this convention? NetSuite reports we've seen show "Open Balance" as positive on both AR and AP — sign needs to be derived from transaction type.

9. **Tolerance thresholds.** What's the materiality threshold for "clean" vs "FX rounding" vs "investigate"? Currently we're using 100 JPY for clean, 0.5% for FX. Confirm or adjust.

### 10.3 HITL workflow questions

10. **Reviewer roles.** Who is in the HITL queue? PICs (one per entity), the central coordinator, or both? Affects access control and notification routing.

11. **Approval thresholds.** Should the central coordinator approve all journals, or should small ones (under JPY 100k) be auto-approved if AI confidence is HIGH?

12. **Escalation path.** What happens when a reviewer says "Escalate"? Where does the item go — controller? CFO? We need a clear next step.

13. **Streamlit access.** Will Evident's PICs have direct access to Snowflake/Streamlit, or do we need a middleware UI?

### 10.4 Process / scope questions

14. **Pilot period.** Are we running the pilot against historical March 2026 data (back-test), or live for May 2026 close (parallel run), or both?

15. **Production cutover.** Once pilot is validated, what's the cutover plan? Hard switch, or parallel for N months?

16. **Three known recurring issues.** Should the pilot attempt to flag and propose fixes for these systemic issues (EJP comingled GL, ETCE TP classification, ETCE-ESG forex), or just process them as recurring exceptions?

17. **TNM integration timeline.** When does TNM get added to the same pipeline? The architecture is ready; just a question of when Evident wants to expand scope.

---

## 11. Appendix: Code Templates

### 11.1 Stored procedure — orchestration

```sql
CREATE OR REPLACE PROCEDURE INTERCO_MIS_PILOT.RESULTS.SP_RUN_FULL_PIPELINE(PERIOD VARCHAR)
RETURNS VARCHAR
LANGUAGE SQL
AS
$$
BEGIN
    -- Tier 1A
    CALL SP_MATCH_TIER1A(:PERIOD);
    -- Tier 1B
    CALL SP_MATCH_TIER1B(:PERIOD);
    -- Tier 1C
    CALL SP_MATCH_TIER1C(:PERIOD);
    -- Embeddings
    CALL SP_GENERATE_EMBEDDINGS(:PERIOD);
    -- Tier 2 fuzzy
    CALL SP_MATCH_TIER2_FUZZY(:PERIOD);
    -- Cortex classification
    CALL SP_CORTEX_CLASSIFY(:PERIOD);
    -- Populate HITL queue
    CALL SP_POPULATE_REVIEW_QUEUE(:PERIOD);

    RETURN 'Full pipeline complete for ' || :PERIOD;
END;
$$;
```

### 11.2 Streamlit review app — skeleton

```python
# streamlit_mis_recon.py — Streamlit in Snowflake HITL review app

import streamlit as st
import pandas as pd
from snowflake.snowpark.context import get_active_session

session = get_active_session()
st.title("MIS Intercompany Reconciliation — Review Queue")

# Sidebar filters
period = st.sidebar.selectbox("Period", ["2026-03", "2026-02"])
queue_type = st.sidebar.selectbox("Queue type",
    ["ALL", "FUZZY_REVIEW", "UNMATCHED_ESCALATION", "KNOWN_ISSUE_FAST_TRACK"])
confidence = st.sidebar.selectbox("AI confidence", ["ALL", "HIGH", "MEDIUM", "LOW"])

# Load queue
df = session.sql(f"""
    SELECT q.QUEUE_ID, q.QUEUE_TYPE, q.CANONICAL_PAIR,
           q.JPY_AMOUNT_DELTA, q.AI_ROOT_CAUSE, q.AI_CONFIDENCE,
           a.REPORTING_ENTITY AS ENTITY_A, a.BILATERAL_DOC_NUMBER AS DOC_A,
           a.JPY_AMOUNT AS JPY_A, a.POSTING_DATE AS DATE_A,
           b.REPORTING_ENTITY AS ENTITY_B, b.BILATERAL_DOC_NUMBER AS DOC_B,
           b.JPY_AMOUNT AS JPY_B, b.POSTING_DATE AS DATE_B
    FROM HITL.REVIEW_QUEUE q
    LEFT JOIN STAGING.STG_INVOICE_LINES a ON q.LINE_ID_A = a.INVOICE_LINE_ID
    LEFT JOIN STAGING.STG_INVOICE_LINES b ON q.LINE_ID_B = b.INVOICE_LINE_ID
    WHERE q.PERIOD_KEY = '{period}' AND q.REVIEW_STATUS = 'PENDING'
    ORDER BY ABS(q.JPY_AMOUNT_DELTA) DESC
""").to_pandas()

st.metric("Pending review", len(df))

reviewer = st.sidebar.text_input("Your name")

for _, row in df.iterrows():
    with st.expander(f"{row['CANONICAL_PAIR']} | {row['QUEUE_TYPE']} | "
                     f"JPY {row['JPY_AMOUNT_DELTA']:,.0f} | "
                     f"AI: {row['AI_CONFIDENCE']}"):
        c1, c2, c3 = st.columns(3)
        with c1:
            st.write("**Side A (AR)**")
            st.write(f"Entity: {row['ENTITY_A']}")
            st.write(f"Doc: {row['DOC_A']}")
            st.write(f"JPY: {row['JPY_A']:,.0f}")
            st.write(f"Date: {row['DATE_A']}")
        with c2:
            st.write("**Side B (AP)**")
            st.write(f"Entity: {row['ENTITY_B']}")
            st.write(f"Doc: {row['DOC_B']}")
            st.write(f"JPY: {row['JPY_B']:,.0f}")
            st.write(f"Date: {row['DATE_B']}")
        with c3:
            st.write("**AI analysis**")
            st.json(row['AI_ROOT_CAUSE'])

        decision = st.radio("Decision",
            ["", "ACCEPT_MATCH", "POST_JOURNAL", "NO_ACTION", "ESCALATE"],
            key=f"d_{row['QUEUE_ID']}", horizontal=True)
        notes = st.text_area("Notes", key=f"n_{row['QUEUE_ID']}")

        if st.button("Submit", key=f"s_{row['QUEUE_ID']}"):
            if not reviewer or not decision:
                st.error("Need name and decision.")
            else:
                session.sql(f"""
                    UPDATE HITL.REVIEW_QUEUE
                    SET REVIEW_STATUS = 'APPROVED',
                        REVIEWER_DECISION = '{decision}',
                        REVIEWER_NAME = '{reviewer}',
                        REVIEWER_NOTES = $1,
                        REVIEW_TIMESTAMP = CURRENT_TIMESTAMP()
                    WHERE QUEUE_ID = '{row['QUEUE_ID']}'
                """, params=[notes]).collect()
                st.success("Submitted.")
                st.rerun()
```

### 11.3 Validation query — match rate by pair

```sql
-- Match rate by canonical pair
SELECT
    CANONICAL_PAIR,
    COUNT(DISTINCT INVOICE_LINE_ID) AS total_lines,
    COUNT(DISTINCT CASE WHEN matched.LINE_ID_A = stg.INVOICE_LINE_ID
                          OR matched.LINE_ID_B = stg.INVOICE_LINE_ID
                        THEN stg.INVOICE_LINE_ID END) AS matched_lines,
    ROUND(COUNT(DISTINCT CASE WHEN matched.LINE_ID_A = stg.INVOICE_LINE_ID
                                OR matched.LINE_ID_B = stg.INVOICE_LINE_ID
                              THEN stg.INVOICE_LINE_ID END)::FLOAT
          / COUNT(DISTINCT INVOICE_LINE_ID) * 100, 1) AS match_rate_pct
FROM STAGING.STG_INVOICE_LINES stg
LEFT JOIN RESULTS.MATCHED_INVOICES matched
    ON stg.INVOICE_LINE_ID IN (matched.LINE_ID_A, matched.LINE_ID_B)
   AND matched.PERIOD_KEY = stg.PERIOD_KEY
WHERE stg.PERIOD_KEY = '2026-03'
GROUP BY CANONICAL_PAIR
ORDER BY match_rate_pct DESC;
```

---

*End of MIS Intercompany Invoice Matching Plan v2.0 — for Evident review and Cortex Code build*
