# TCH Use Case: Agile Capacity / No-Show Optimization Pilot
## Scope & KPI Definition Document

**Version:** 1.0
**Date:** April 23, 2026
**Status:** Draft — Pending Client Review

---

## 1. Purpose

This document defines the pilot scope, success criteria, and key performance indicators (KPIs) for the TCH Agile Capacity / No-Show Optimization Pilot. It is intended to align internal delivery teams and the Client on measurable outcomes prior to development kickoff. The pilot will produce a data-driven capacity management system that consumes no-show risk model outputs to surface actionable slot-level recommendations, enabling Capacity Management teams to selectively double-book high-risk sessions and recover otherwise lost appointment capacity.

---

## 2. Pilot Scope

### 2.1 Overview

The pilot will build a Snowflake-native analytics and decision-support layer that ingests patient-level no-show risk scores (from the existing Azure ML model feeding EPIC), aggregates risk to the session level, identifies sessions exceeding configurable risk thresholds, and recommends exactly one return-patient slot per flagged session for capacity adjustment. A Streamlit-in-Snowflake dashboard will provide the operational interface for reviewing, applying, skipping, and reverting adjustments — with a full audit trail and closed-loop outcome monitoring.

### 2.2 In-Scope Capabilities

**No-Show Risk Aggregation & Session Flagging**
A scoring and aggregation layer that transforms patient-level risk predictions into session-level actionable recommendations.

- Ingest encounter-level no-show probability scores (1–100 scale with risk tiers) from the existing Azure ML model via EPIC Clarity
- Aggregate patient-level risk to session level using configurable thresholds (HIGH_PCT ≥ 40% or COMBINED_PCT ≥ 65%)
- Flag sessions meeting intervention criteria within a configurable lookahead window (default: 3 days)

**Slot-Level Capacity Recommendations**
A recommendation engine that identifies the optimal slot for double-booking within each flagged session.

- For each flagged session, identify exactly one eligible RETURN patient slot for capacity adjustment (capacity 1 → 2)
- Enforce guardrails: return patients only, one slot per session, middle-of-session slot selection to minimize back-to-back arrival risk
- Support both structured (dropdown) and natural language (Cortex AI-powered) action workflows for applying, skipping, and reverting recommendations

**Operational Monitoring & Closed-Loop Tracking**
A monitoring layer that tracks actual patient arrivals and surfaces alerts when operational thresholds are breached.

- Track arrival outcomes for adjusted sessions: on-time arrivals, no-shows, cancellations, double-book conflicts
- Surface real-time alerts for threshold breaches (wait time exceeded, both patients arrived, average wait exceeded)
- Provide revert capability with reason tracking when adjustments need to be undone

**Pilot Analytics & Impact Dashboard**
A measurement layer providing executives and operational leaders with evidence of pilot effectiveness.

- Compare outcomes between adjusted vs. non-adjusted sessions (throughput, no-show rate, conflict rate)
- Monthly trend analysis of no-show rates and capacity recovery
- Pilot success scorecard with green/amber/red status against agreed KPI targets
- Feature-level effectiveness analysis with AI-generated causality narratives (Cortex AI)

**AI-Powered Analytics**
Conversational and analytical AI capabilities powered by Snowflake Cortex.

- AI Assistant (chatbot) for ad-hoc natural language Q&A about no-show patterns, feature impacts, and recommendations
- Natural language action parsing for operational commands (e.g., "Apply adjustment for Dr. Smith's 2pm slot")
- AI-generated causality narratives explaining which patient/appointment features make double-booking most effective

### 2.3 Data Sources

| Source | Description | Access Method |
|--------|-------------|---------------|
| EPIC Clarity (Oracle) | Core appointment, patient, provider, scheduling, and status data (PAT_ENC, PATIENT, SCHED_APPT, ZC_APPT_STATUS, CLARITY_DEP, CLARITY_SER, PAT_ADDRESS, COVERAGE) | Informatica IDMC — Mass Ingestion (full load + CDC via Oracle LogMiner, 5-minute refresh) |
| Azure ML No-Show Model | Encounter-level no-show probability scores (1–100) and risk tiers fed into EPIC | Extracted from EPIC Clarity as a column on PAT_ENC (or separate scoring table) |
| EPIC Clarity — Historical Outcomes | Historical appointment statuses (Completed, No Show, Cancelled, Left Without Being Seen) for model validation and outcome tracking | Informatica IDMC — same pipeline |

### 2.4 Service Line Focus

**Pilot Service Lines:** Ambulatory pediatric medicine and surgery, starting with surgical return visits.
Future phases may extend to additional specialties pending pilot outcomes and clinical governance review.

---

## 3. Success KPIs

### 3.1 Technical Performance KPIs

| KPI | Description | Target |
|-----|-------------|--------|
| Risk Score Data Freshness | Lag between EPIC Clarity update and availability in Snowflake scoring layer | ≤ 24 hours |
| Recommendation Generation | System produces slot-level recommendations daily before operational review window | By 6:00 AM ET daily |
| Model Tier Separation | Actual no-show rates differ meaningfully across HIGH / MEDIUM / LOW risk tiers | HIGH ≥ 25%, MEDIUM 15–25%, LOW ≤ 15% |
| Dashboard Availability | Streamlit app uptime during pilot period | ≥ 99% |
| NL Action Parse Accuracy | % of natural language action commands correctly parsed and matched to a recommendation | ≥ 85% |
| Simulation / Query Response Time | Time to return AI Assistant or NL action result | ≤ 10 seconds |

### 3.2 User Adoption & Experience KPIs

| KPI | Description | Target |
|-----|-------------|--------|
| Active User Rate | % of invited Capacity Management pilot users engaging with the dashboard at least weekly | ≥ 80% |
| Task Completion Rate | % of recommendation review actions (apply/skip) completed without IT/analyst escalation | ≥ 85% |
| User Satisfaction Score | Average score from end-of-pilot survey (1–5 scale) | ≥ 4.0 |
| Time-to-Decision Reduction | Reduction in time to review and action daily recommendations vs. current manual/spreadsheet process | ≥ 50% |

### 3.3 Business Impact KPIs

| KPI | Description | Target |
|-----|-------------|--------|
| Recommendation Action Rate | % of surfaced recommendations approved (applied) by Capacity Management | ≥ 50% |
| Adjusted Sessions | Total sessions with a slot adjustment applied during pilot | ≥ 15–20 during pilot period |
| Slot Fill Rate | % of adjusted slots where a second patient was successfully booked | TBD (establish baseline during pilot) |
| Double-Book Conflict Rate | % of adjusted sessions where both patients arrived simultaneously | < 5% |
| Wait Time Threshold Breaches | Sessions exceeding the agreed operational wait time limit (e.g., > 35 min max) | 0 during pilot period |
| No-Show Rate Delta | Change in no-show rate for adjusted sessions vs. comparable non-adjusted sessions | Measurable positive capacity recovery |
| Revenue Recovery Potential | Estimated revenue recovered per successfully absorbed no-show (at $200–$500/slot) | Quantified during Phase 4 assessment |

---

## 4. Pilot Parameters

| Parameter | Detail |
|-----------|--------|
| **Duration** | 8 weeks across 4 phases: Foundation (Weeks 1–2), Crawl / Build (Weeks 3–4), Walk / Pilot Deployment (Weeks 5–7), Run / Iterate & Scale Planning (Week 8) |
| **Service Lines** | Ambulatory pediatric medicine and surgery — starting with surgical return visits |
| **Environment** | Snowflake (Client account PN56976 — DELOITTENA_COCO), two-zone PHI architecture (Zone 0: RAW_EPIC_CLARITY for PHI; Zone 1: AGILE_CAPACITY_DEMO for de-identified analytics) |
| **Integration** | Informatica IDMC for EPIC Clarity replication (Mass Ingestion + CDI mappings with ELT pushdown) |
| **ML Model** | Existing Azure ML no-show prediction model feeding EPIC; Snowflake consumes model outputs — does not retrain or rebuild |
| **Application** | Streamlit in Snowflake (AGILE_CAPACITY_APP) — 9-tab operational dashboard with AI Assistant |
| **Pilot Users** | 2–3 Capacity Management team members (to be named); plus read-only access for clinical sponsor, IS/data architect, operations lead |
| **Data Requirements** | Minimum 12 months of EPIC Clarity appointment history (24 months preferred for seasonal patterns); current no-show model scores; EPIC status codes reliably distinguishing No Show vs. Cancelled |
| **Governance** | Two-zone PHI architecture with 6 dynamic masking policies; Zone 0 US-only access; Zone 1 allows global (including India) access with masked identifiers; 6-role RBAC hierarchy; Snowflake BAA in place |

---

## 5. Out of Scope (Pilot Phase)

- Retraining, rebuilding, or modifying the existing Azure ML no-show prediction model
- Service lines beyond ambulatory pediatric medicine and surgery (return visits)
- Write-back to EPIC — all slot adjustments are manual in EPIC during the pilot; the system surfaces recommendations only
- Real-time streaming data pipelines (batch refresh via IDMC at ≤ 5-minute intervals)
- New patient appointment slots (return visits only per clinical guardrails)
- Production deployment or enterprise rollout
- Building or maintaining data ingestion pipelines beyond the IDMC scope defined above
- Patient-facing communications or automated reminder systems
- CRM or scheduling system integration beyond EPIC Clarity read access

---

## 6. Key Assumptions & Risks

| # | Assumption / Risk | Mitigation |
|---|-------------------|------------|
| 1 | The existing Azure ML no-show model is currently running in production and feeding EPIC with encounter-level scores | Confirm model status, output format, and owner during Phase 1 Discovery |
| 2 | EPIC Clarity tables (PAT_ENC, PATIENT, SCHED_APPT, etc.) are available and sufficiently populated for the pilot specialties | Clarity DBA to validate table availability and column population rates before Phase 1 ends |
| 3 | No-show status is reliably recorded in Clarity and clearly distinguished from cancellations | Data quality assessment included in Phase 1; status codes validated against ZC_APPT_STATUS |
| 4 | The Capacity Management team can review and action ≤ N sessions per day (throughput ceiling to be agreed) | Threshold tuning in Phase 1 to ensure recommendation volume is operationally manageable |
| 5 | Clinical governance / AI ethics review (if required) can be completed before pilot go-live in Week 6 | Identify governance gate requirements and timeline in Phase 1 Discovery workshop |
| 6 | IDMC Secure Agent connectivity to EPIC Clarity (Oracle) can be established within Weeks 1–2 | Network/firewall requirements documented; IS team engaged for on-prem agent provisioning |
| 7 | The pilot operates in a manual-action paradigm — the system does not write back to EPIC | Explicitly communicated to all stakeholders; Streamlit app surfaces recommendations; operators act in EPIC separately |
| 8 | Model fairness — the model does not disproportionately flag patients of certain demographics, insurance types, or zip codes | Feature analysis tab provides transparency; fairness review included in Phase 1 governance discussion |

---

## 7. Next Steps

| # | Action | Owner | Due |
|---|--------|-------|-----|
| 1 | Confirm pilot scope and service line focus with Client stakeholders | Client + Delivery Lead | TBD |
| 2 | Conduct Discovery & Scoping Workshop (Block 1–6 agenda) | Deloitte + Client | TBD |
| 3 | Confirm no-show model status, owner, output format, and documentation | Analytics / IS | TBD |
| 4 | Validate EPIC Clarity table availability with Clarity DBA | IS / Clarity DBA | TBD |
| 5 | Provision Snowflake two-zone environment and RBAC roles | IS + Deloitte | TBD |
| 6 | Configure IDMC Secure Agent and test EPIC Clarity connectivity | IS + Deloitte | TBD |
| 7 | Confirm clinical governance / AI ethics review requirements and timeline | IS / Clinical | TBD |
| 8 | Name Capacity Management pilot users (2–3 individuals) | Operations Lead | TBD |
| 9 | Finalize KPI targets with Client stakeholders | Strategy Lead | TBD |
| 10 | Kick off Phase 1 — Foundation & Discovery | Delivery Team | TBD |

---

*This document is a working draft and subject to revision based on Client input and discovery findings.*
