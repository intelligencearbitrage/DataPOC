# Six-Phase Conversion and Optimization Approach

Phases 1–2 produce a stable system. Phases 3–6 optimize it. These must run sequentially — never in parallel.

---

| Phase | Name | Key Activities | Output | Gate |
|-------|------|---------------|--------|------|
| **1** | **Convert & Decompose** | • XML → DBT models, one per target table<br>• Build workflow-to-model mapping table<br>• Assign scheduling tags<br>• Run dbt compile → manifest.json | DBT project, manifest.json, mapping table, all models tagged and compile-clean | 0 & 1 |
| **2** | **Lift and Shift** | • Wire all job schedule tags into orchestrator<br>• Preserve all inter-schedule dependencies<br>• Unit testing, data parity testing and SIT to confirm migration success | Stable production system functionally equivalent to Informatica baseline | 2 |
| **3** | **Score Subgraphs** | • Parse manifest.json<br>• Build DAGs<br>• Group models by logical target<br>• Score each target on 4 dimensions<br>• Assign tiers | Ranked target priority list, tier assignments (Tier 1 / 2 / 3) | 3 |
| **4** | **Configuration Optimizations** | • Warehouse routing by subgraph weight<br>• Apply cluster_by on common filter columns<br>• Materialization audit — downgrade infrequently-queried tables to views. Applies to ALL targets. | Updated dbt_project.yml, cluster configs, credit delta validated in dev | 4 |
| **5** | **Targeted Rewrites** | • Pattern A: Shared staging models<br>• Pattern B: Shared intermediate models<br>• Pattern C: Consolidate full-load + incremental into is_incremental(). Tier 1 & 2 only. | Shared staging and intermediate models, consolidated incremental models | 5 |
| **6** | **Validate & Govern** | • Re-run subgraph scoring to confirm gains<br>• Capture Snowflake credit baselines<br>• Document consolidated models in schema.yml<br>• Schedule quarterly DAG health review | Credit delta report, updated schema.yml, quarterly review cadence | 6 |

---

*Copyright © 2026 Deloitte Development LLC. All rights reserved.*
