# Snowflake Summit — Cortex Code Hands-On Lab
## Full Session Design

*Companion to the Opening Briefing. This document covers everything that happens after the open, plus the lab design built specifically against the engagement problem you have observed.*

---

## Section 1 — Session Architecture

### Total length

I am designing for **90 minutes** because that is the typical Snowflake Summit hands-on lab slot. If the actual slot is 60 minutes or 120 minutes, the lab portion compresses or expands. **Flag for me** if the actual length is different and I will reshape.

### The five-act structure

| Act | What happens | Length | Energy |
|---|---|---|---|
| 1. Opening | The "vibe vs structured" frame | 12 min | Set the tone |
| 2. Demos | Two demos of real artifacts | 14 min | Curiosity |
| 3. Case study | Cisco / Teradata anonymized story | 7 min | Credibility |
| 4. Hands-on lab | The engagement-heavy exercise | 47 min | Doing |
| 5. Wrap | Closing + Q&A + handout | 10 min | Synthesis |

### Why this order

The previous version went: opening → straight to lab. That works for a short slot but skips the credibility-building that earns the audience's commitment to a long lab. The demos and case study buy you the lab. They are not filler. They are the part that makes participants commit to the doing.

The structure also gives natural energy management. Acts 1 and 3 are talking-heavy. Acts 2 and 4 are doing-heavy. Act 5 is reflection. The rhythm matters more than the content for sustained attention.

---

## Section 2 — Time Budget (Minute-by-Minute)

| Minute | Beat | Notes |
|---|---|---|
| 0-12 | Opening (talking points from briefing) | End with bridge to demos |
| 12-19 | Demo 1: Snowflake env auto-provisioning agent | 7 min |
| 19-26 | Demo 2: Natural language PowerPoint agent | 7 min |
| 26-33 | Case study: Cisco / Teradata migration | 7 min |
| 33-38 | Lab setup: explain exercise, pair up | 5 min |
| 38-43 | Lab Round 1: Vibe coding attempt | 5 min, individual |
| 43-46 | Pause and reflect: what went wrong | 3 min, room discussion |
| 46-53 | Constitution writing: no coding allowed | 7 min, individual then pair check |
| 53-68 | Lab Round 2: Spec-driven attempt | 15 min, pair work |
| 68-73 | The "change one line" reveal | 5 min, facilitator-driven |
| 73-80 | Compare and share: 2-3 outputs to the room | 7 min |
| 80-87 | Q&A | 7 min |
| 87-90 | Closing line and handout | 3 min |

Total: 90 minutes.

**Where the budget gets tight:** Lab Round 2 (15 min) is the section most likely to overrun. If you see pairs still working at minute 65, give a one-minute warning. If at minute 68 they are still going, sacrifice the Q&A, not the reveal. The reveal is where the lesson lands.

---

## Section 3 — The Demos

### Demo discipline (read this twice)

Two principles that override everything else.

**Each demo is 6-7 minutes. Not 10. Not 12.** A demo that runs long kills lab energy. Pre-rehearse with a stopwatch. Pre-stage the artifacts you need so nothing depends on a live load.

**Show the artifact, not the agent typing.** Participants do not need to watch Cortex Code work. They have seen agents work. Show them the spec that produced the agent. Show the SKILL. Show the resulting behavior. The agent's typing is the boring part.

### Demo 1: Snowflake Environment Auto-Provisioning Agent

**Why this demo first:** Most Snowflake-flavored example you have. The audience is invested in Snowflake operations. This earns trust quickly.

**What to show, in order:**

1. The Constitution (~30 seconds). Show the markdown file that defines the agent's mission, the environment standards it enforces, the governance rules baked in.
2. A single feature spec (~30 seconds). For example, "provision a development environment with PII masking applied by default."
3. The agent running (~2 minutes). Actually invoke it, show it asking for a confirmation, show it creating the environment.
4. The resulting Snowflake account (~2 minutes). Show RBAC, tags, masking policies all in place from a single invocation.
5. The take-home (~1 minute). "This Constitution travels. Same approach, different environment definitions, same SKILL."

**What to say:** "What you are seeing is not the agent's intelligence. It is the Constitution's clarity. If the Constitution is good, the agent is reliable. If the Constitution is sloppy, the agent is creative in ways you do not want."

**What NOT to do:** Do not narrate every step of the agent's work. Talk over the agent. The agent's work is background, the spec is foreground.

### Demo 2: Natural Language PowerPoint Agent

**Why this demo second:** It is the "wait, you can do that?" demo. Different domain than data engineering, which broadens audience trust. It lands the Pattern 3 message from the open ("spec captures judgment, code is disposable").

**What to show, in order:**

1. The judgment in the spec (~1 minute). Show the spec section where you encoded which slide templates to use when, what makes a slide "too dense," how to break a thought across slides. This is the meat.
2. A prompt to the agent (~30 seconds). Something like "Generate a 5-slide deck explaining the Q3 financial results, for an executive audience."
3. The output (~2 minutes). Flip through the resulting slides. They will be visibly competent. Expect an audible reaction.
4. Now change the audience (~2 minutes). Change "executive audience" to "technical team." Same prompt otherwise. Show the different deck. Same data, different judgment applied.
5. The take-home (~30 seconds). "The spec encoded the judgment. The agent applied it. If we had put this judgment in prompts, we would be re-prompting forever."

**Watch for:** This is your high-engagement demo. People will ask "can it do X?" Stay disciplined on time. "Let's hold that for Q&A" is your friend.

### What you should NOT demo

A complex agent (for example, the Sensitive Data Governance SKILL) that requires too much context to appreciate. Save it for Q&A. Demos should be obvious in their value within thirty seconds.

---

## Section 4 — The Cisco / Teradata Case Study (Anonymized)

### Why this story belongs in the session

It is the only beat that shows multi-tool agentic workflow at real client scale. Migrations are a hot Snowflake topic. Teradata customers are the audience the Snowflake field team most wants to convert. This story does triple duty: credibility, Snowflake relevance, multi-tool maturity.

### The 7-minute story arc

(Practice this with a stopwatch. The first time you tell a 7-minute story it lands at 11.)

**Minute 1 — The situation.**

> "A large enterprise client, anonymized, had a Teradata environment they needed to move to Snowflake. Hundreds of objects. Years of stored procedures. The traditional estimate for this work was many months. The deadline was tighter than that. The gap was real."

Do not name Cisco. Even if the audience guesses, do not confirm. "A large enterprise client" or "a Fortune 100 client" is the phrasing.

**Minute 2 — The traditional approach and why it would not work.**

> "Normally you would put a large team on this. Lots of SMEs in a room. Lots of slow handoffs. Lots of code being read and rewritten by humans. The traditional path was real, but it was too slow for the timeline."

**Minutes 3-4 — The agentic approach.**

> "We combined three things. Deloitte Data Assist for the migration intelligence layer. Claude Code for the spec-driven workflow. Snowflake Cortex Code for the in-platform execution. The spec traveled across all three. The spec was the brain. The tools were the muscle."

> "What we did differently was not throw the agent at the migration. We built a Constitution that captured the migration patterns the client cared about. Their data type conventions, their governance rules, their cutover validation requirements. The spec became the contract. The tools executed against it."

**Minute 5 — The result.**

> "The migration accelerated significantly. I am going to be careful about specific percentages because every migration is different, but it was the difference between hitting the deadline and missing it."

The intentional vagueness matters here. Specific percentages are stage liabilities. "The difference between hitting the deadline and missing it" is a more useful and defensible claim than any number.

**Minute 6 — The Snowflake-specific lesson.**

> "Here is what mattered for Snowflake. Cortex Code ran in the client's Snowflake account. The governance the agent had to respect was the client's governance, already enforced by the platform. The spec did not have to re-describe what RBAC said. The agent inherited it."

**Minute 7 — The take-home.**

> "Two things from this. First, the spec travels. The same Constitution that worked in Claude Code worked in Cortex Code with minimal changes. Second, the platform was doing real work. The agent did not have to invent governance. It invoked what was already there."

### What not to say

Do not name the client. Do not give specific percentages. Do not name dollar amounts. Do not mention specific Deloitte Data Assist features that are not yet public. Do not let the story drift into a Deloitte sales pitch. The audience came for SDD insight, not for a consultancy advertisement.

### What to bring

If you have a single slide or whiteboard sketch showing "Spec → [Deloitte Data Assist | Claude Code | Cortex Code]" with arrows, that is useful. Otherwise the story works as pure narrative.

---

## Section 5 — The Hands-On Lab (The Engagement Heart of the Session)

### What you observed at prior Snowflake labs

You said the labs you have seen had participants copy-pasting prompts and watching Cortex Code work. Low engagement. People lost interest.

That observation is exactly right and it is the structural problem this lab has to solve. Watching an agent work is not engaging once the novelty wears off, which takes about three minutes. The cure is not better demos. The cure is making participants think before the agent works.

### The pedagogical principle (one sentence)

**In a Spec-Driven Development lab, the thinking is the lab. The agent's typing is the punctuation.**

Everything else flows from this. If participants are typing prompts, they are not learning. If they are writing specs and arguing with their partner about a choice, they are learning.

### The exercise

**Problem statement (read this verbatim or close to it):**

> "You are a data engineer at a mid-sized company. The marketing team has just dropped a CSV in your shared drive with 1,000 customer records. It contains a mix of names, emails, phone numbers, ages, regions, last purchase dates, and lifetime value. They want it in Snowflake by end of day so they can run a campaign analysis. Your job: build an agent that ingests this CSV into Snowflake with the right types, the right governance, and a validation report. You have twenty minutes of agent work to do it twice. Once the easy way. Once the right way."

**Why this problem:**

Universal. Every data person has done this. Non-trivial governance implications (PII, masking). Multiple right answers (which forces decisions). Multiple wrong answers (which makes failures visible). Time-bound and demoable.

### The seven beats of the lab (47 minutes)

**Beat 1 — Setup (5 min)**

Pair people up. Whoever is in seat A on each row writes; whoever is in seat B reviews. Swap after ten minutes. Read the problem out loud. Confirm everyone has the CSV in their lab environment.

**Beat 2 — Vibe Round (5 min)**

> "First attempt, no spec. Just prompt Cortex Code to do it. Type what you want. See what you get. Five minutes. Go."

Walk the room. Do not help. Note who is finishing, who is stuck, who is producing something interesting.

**Beat 3 — Pause and Observe (3 min)**

> "Stop typing. Look at what you got. Three questions for your pair: First, did the agent ask you about PII? Second, did it ask you about data types or just guess? Third, would you ship this?"

Take 2-3 hands. Listen. Do not lecture. Let them surface the problems.

**Beat 4 — Constitution Writing (7 min)**

> "Now we slow down. Close your laptop, or open a markdown file. Do not write code. Do not prompt the agent. For seven minutes, write a Constitution for this work. Mission. Tech stack. Roadmap. Be specific. If you are not sure what goes in each section, look at the handout."

This is the critical beat. Walk the room. If you see someone typing in Cortex Code, gently redirect: "Not yet. Write the Constitution first."

**Beat 5 — Spec-Driven Round (15 min)**

> "Now, with your Constitution in hand, go back to Cortex Code. Give it the Constitution. Then prompt for the same thing as before. See what changes."

The pair dynamic kicks in here. Person A writes, person B reviews against the Constitution. After seven minutes, swap roles.

Walk the room. Identify 2-3 pairs producing notably good results. You will reveal these later.

**Beat 6 — The Change-One-Line Reveal (5 min)**

This is the lightbulb moment. You drive it from the front.

> "Everyone, look at your Constitution. Find one line. Maybe the line that says 'mask PII before insert' or 'use VARCHAR(255) for text fields' or 'fail on duplicate keys.' Change that ONE line. Now ask Cortex Code to re-implement against the new Constitution. Watch what happens."

What happens: small spec change, large code change. This is the moment the abstract claim ("change the spec, change the code") becomes a felt experience.

**Beat 7 — Reveal and Compare (7 min)**

Bring 2-3 of the strong outputs to the front (using the lab environment's screen share or a projector). Show them side by side. Ask the authors: "What was in your Constitution that made this work?"

The authors will articulate their reasoning. That articulation is the most valuable learning moment in the session, because it is participants teaching participants.

If time allows, also show one weak output (anonymously). Ask the room: "What was missing from the Constitution that produced this?"

### Engagement principles for the facilitator (you)

These are the patterns to enforce throughout the lab.

**Less talking, more walking.** Once the lab starts, you are in the room, not at the front. Watch pairs. Stop at the stuck ones. Ask one diagnostic question and move on.

**Ask, do not tell.** When a pair is confused, do not give them the answer. Ask "what does your Constitution say about this?" If their Constitution does not say anything about it, that is the lesson.

**Force the pair dynamic.** If you see solo work, gently restart the pair conversation. "What is your partner seeing? Are you both happy with that choice?"

**Time discipline matters.** Announce time at the two-minute warning of each beat. Do not let beats blur into each other.

**Reveal selectively.** When you bring outputs to the front, pick ones that teach different lessons. Two near-identical examples teach nothing. Two different examples teach contrast.

### Anti-patterns to actively avoid

These are what sank the prior Snowflake labs. Naming them so they stay top of mind.

- **Copy-paste prompts on a slide.** Do not show participants the prompts to use. Give them a problem; let them write their own prompts.
- **Step-by-step instructions.** This is a "figure it out" lab, not a "follow along" lab. Participants need to feel the productive struggle.
- **Solo work.** Pair work is non-negotiable. Verbalizing forces thinking.
- **Watching the agent.** The agent's output is the artifact, not the spectacle. Move on quickly from each agent invocation.
- **Long facilitator monologues.** Once the lab starts, your job is to facilitate, not to lecture.
- **No comparison.** Without the reveal, participants do not see what they could have done.

---

## Section 6 — Wrap-Up (10 min)

### Q&A first

The Q&A after the reveals is usually rich because participants have just done the work and have specific questions. Use the prepared Q&A in the briefing document. Expect questions about brownfield, dbt integration, model portability, time savings, and replacing engineering reviews. All of those have prepared answers in the briefing.

### The closing line

The line from the briefing is still the right closer.

> "The agent will get faster. The models will get better. What you take home from this room is not a tool. It is a way of working that survives the next three model releases. Write things down. Make the agent serve the writing."

Pause after this. Let it land. Then thank them and gesture to the handout.

### The handout

If the handout has not been distributed yet, this is the moment. Each handout should have the two-column comparison (vibe vs structured), the three patterns (migration as product, governance lives in the SKILL, spec captures judgment), the four-line Constitution template, three Snowflake-specific SKILL ideas to try at home, and a link to a deeper reference.

The handout is the take-home artifact. People will refer back to it on the plane home and on Monday morning when they sit down to try this themselves.

---

## Section 7 — Facilitator Survival Notes

### What to bring on stage

The talking points from the briefing, printed, in your back pocket. This session design on your phone for the runsheet. A stopwatch or timer (your phone is fine). Water. A printed copy of the handout in case some participants do not get one through the official channels.

### Co-facilitator coordination

If there is a co-facilitator from Snowflake or Deloitte, agree on these in advance.

Who introduces whom. Who runs the demos (if not you). Who walks the room during the lab. Who calls time. Who manages Q&A overflow.

If you are alone on stage, the lab beats require you to be highly mobile. Plan to walk continuously between beat 4 and beat 7.

### If the room is going low energy

The most common culprit at minute 40 is too much instructor voice. Cut your transitions. Let participants start the next beat sixty seconds early. Movement helps. Have them stand up briefly between beats.

If by minute 60 the lab is dragging, skip the change-one-line beat and go straight to the reveal. The reveal is the highest-value beat. Protect it.

### If something breaks

Cortex Code in a lab environment will occasionally have issues. If a participant's environment is broken, pair them with someone working. Never let a broken environment stop a pair from learning.

If the demo breaks during demo 1 or 2, fall back to the artifact. "Let me show you the spec while we wait for the environment." The spec is more important than the live demo anyway.

### If a participant is dominating their pair

You will see this. One person leans in, types fast, makes all the calls. The other person disengages.

Walk over. Say to the dominant participant: "I want to hear your partner's read on the Constitution. What did you write for governance?" Address the question to the quieter one. This rebalances the pair without embarrassing anyone.

---

## Section 8 — Open Questions for You

Resolve these before Summit.

**Session length.** I designed for 90 minutes. If the actual slot is different, tell me and I will reshape.

**Co-facilitator identity and role.** Who is on stage with you, and what do they own?

**Lab environment.** Does each participant get their own Snowflake trial / Cortex Code instance? If they are sharing or if the lab is a shared sandbox, the pair dynamics need adjustment.

**The handout.** Do you want me to draft it as a standalone artifact next? I have held off because the session design comes first.

**The Cisco/Teradata story.** I drafted the arc with assumed specifics ("hundreds of objects," "compressed the timeline"). If you have different framing in mind, send me the broad strokes and I will refine.

**USNWR Analytics.** Still flagging from earlier. What is it? Worth placing if it comes up.

**Sample CSV for the lab.** Do you have a customer CSV ready, or should one be generated? If you need one generated, I can produce a 1,000-row sample with believable PII characteristics.

---

## Final Note

The single biggest design decision in this session is what happens during the lab. The opening, the demos, and the case study all serve the lab. If the lab works, the session works. If the lab is passive copy-paste like the prior Snowflake labs you described, the session fails regardless of how good the open was.

The design above is engineered to make passive participation difficult. There is no copy-paste prompt. There is forced thinking. There is pair accountability. There is reveal pressure. There is the change-one-line moment that lands the lesson in a way no speaker can.

Run the lab the way it is designed and you will see what those other Snowflake labs were missing: participants leaving with something they made, not something they watched made.
