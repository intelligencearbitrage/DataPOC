# Use Case Prototype: Semantic Intelligence for Clinical Trial Matching

- **AI Approach:** Knowledge Graph & Advanced AI
- **Target Persona:** Clinical Research Coordinator / Principal Investigator
- **Objective:** Dramatically accelerate clinical trial recruitment by using a Knowledge Graph to find eligible patients—especially non-obvious candidates—that manual screening and simple SQL queries miss.

---

### The Problem

Clinical trial recruitment is a major bottleneck in medical research. It's a slow, labor-intensive process that relies on screeners manually reviewing patient charts against complex inclusion/exclusion criteria. This process is prone to error and often fails to identify eligible patients whose qualifying attributes are mentioned in unstructured notes rather than discrete, coded fields.

### The Solution: An AI That Understands Clinical Relationships

An intelligent search application that allows research coordinators to find eligible patients by querying a rich **Knowledge Graph** that represents the complex relationships between patients, diagnoses, procedures, medications, and clinical concepts.

---

### Demo / Prototype Concept

A specialized search interface where a user can select a clinical trial and see a list of potential candidates, along with the AI's "reasoning" for the match.

**UI Mockup:**

```
------------------------------------------------------------------------------------
| CLINICAL TRIAL MATCHING - TCH-ONC-2026-05 (Neuroblastoma)                        |
------------------------------------------------------------------------------------
|                                                                                  |
|  **Top Matched Patients:**                                                       |
|                                                                                  |
|  **1. Patient ID: 8675309**  (Match Score: 95%)                                  |
|     [+] **Inclusion Criteria Match:**                                            |
|         - Diagnosis: C74.9 (Malignant neoplasm of adrenal gland)                 |
|         - Age: 5 years (within 1-10 year range)                                  |
|         - Value Set: Member of "Prior Chemotherapy Regimen A"                    |
|     [-] **Reasoning Path:**                                                      |
|         Patient -> has_diagnosis -> 'C74.9' -> is_a -> 'Neuroblastoma'           |
|                                                                                  |
|  **2. Patient ID: 1234567** (Match Score: 88%) - *Non-Obvious Candidate*         |
|     [+] **Inclusion Criteria Match:**                                            |
|         - Lab Value: Elevated HVA/VMA ratio (within spec)                        |
|         - Age: 4 years                                                           |
|     [-] **Reasoning Path:**                                                      |
|         Patient -> has_observation_in_note -> "Adrenal mass" -> is_synonym_of -> |
|         'Neuroblastoma'. Patient also -> has_lab -> 'Elevated HVA/VMA'.          |
|                                                                                  |
------------------------------------------------------------------------------------
```

---

### How It Works (The "AI Architect" Vision)

This is a deeply strategic capability built by our Forward Deployed Engineers:

1.  **Knowledge Graph Creation:**
    *   We ingest structured data from clinical **SAMs** (Diagnoses, Labs, Meds).
    *   We ingest and process standard terminologies (SNOMED, ICD-10) and your custom, versioned **Value Sets** (from `dbt snapshots`).
    *   We use Natural Language Processing (NLP) to extract key clinical entities and relationships from unstructured text (e.g., clinician notes).
    *   All of this is loaded into a graph database (or modeled in Snowflake) to create a network linking `Patients` to `Diagnoses`, `Concepts`, `Value Sets`, and `Trials`.
2.  **Intelligent Querying:** When a user selects a trial, the AI agent translates its inclusion/exclusion criteria into a complex query that traverses the Knowledge Graph, finding all possible paths that lead to a patient match.
3.  **Explainable Results:** The system returns not just a list of patients, but the specific evidence and reasoning path that qualified them, allowing for rapid validation by the research coordinator.

### Required Data (from Replicated Consumption Layer)

-   **Clinical SAMs:** Diagnoses, procedures, medications, lab results.
-   **Unstructured Data:** Access to a feed of (de-identified) clinical notes.
-   **Terminology & Value Sets:** Extracted and versioned Value Sets, ICD-10, SNOMED CT.

### Value Proposition

This positions us as true "AI Architects." It demonstrates an ability to solve one of the most complex and valuable problems in academic medicine, accelerating TCH's core research mission and creating a significant competitive advantage.
