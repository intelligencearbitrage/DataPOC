# Use Case 1 — Agile Capacity: No-Show Prediction & Slot Management

**Engagement:** Healthcare Payer + Provider Platform Migration  
**Workstream:** WS2 — FDE AI Sprint (Phase 1)  
**Sprint duration:** 8 weeks  
**Status:** Pre-SOW — scoping in progress  
**Last updated:** March 2026

---

## 1. Purpose

To pilot an "Agile Capacity" workflow that dynamically adds limited appointment capacity to outpatient specialty sessions with a high predicted risk of no-shows, improving access for patients while protecting clinic flow and provider experience.

---

## 2. Background

Missed appointments represent lost clinical capacity, delayed care, and avoidable access constraints. Historic data on no-show rates suggests that carefully governed, data-driven capacity adjustments can offset no-shows without creating operational disruption. The hospital's existing no-show probability model enables a more precise and operationally grounded approach than has previously been possible.

---

## 3. Proposed Pilot Design

### 3.1 Core Workflow

1. **Session identification** — At an agreed lead time prior to clinic date, Snowflake identifies outpatient specialty sessions with a high complement of patients classified as High, Medium, or Low no-show risk.
2. **Targeted capacity adjustment** — For selected sessions, a single return appointment slot is adjusted from a capacity of 1 to 2 patients, minimizing the likelihood of two patients arriving simultaneously.
3. **Centralized execution** — All capacity adjustments are executed by the Capacity Management team, ensuring consistency, oversight, and relief of burden from clinic teams.

> **Important:** The system *recommends* — it does not execute. The Capacity Management team makes the slot adjustment manually in EPIC. There is no automated slot modification in this sprint. Direct EPIC write-back is scoped as a Phase 2 production item.

### 3.2 Guardrails

- Limited to a small number of slots per session
- Focus on return patient slots only — new patient slots are excluded (longer duration risk)
- Continuous monitoring of arrival patterns, wait times, and session flow
- Capacity reverted or paused if operational thresholds are exceeded

---

## 4. Crawl-Walk-Run Delivery Plan

### Phase overview

| Phase | Weeks | Goal | Primary users |
|---|---|---|---|
| Foundation | 1–2 | Environment, PHI governance, data connectivity | Deloitte + Client IT |
| Crawl | 3–4 | Working model, internal validation | Deloitte + client data team |
| Walk | 5–6 | Pilot with real users, outcomes tracking | Capacity Management team |
| Run | 7–8 | Decision, gap list, Phase 2 scope | Client sponsor + Deloitte |

---

### Phase 1 — Foundation Sprint (Weeks 1–2)

**Goal:** All prerequisites in place before a single row of data moves.

#### Deliverables
- Snowflake environment provisioned (two-zone PHI architecture)
- RBAC and India team access controls configured
- Snowflake BAA signed and confirmed
- PHI/PII classification sprint run against EPIC Clarity sample
- Masking policies deployed to Zone 1
- Fivetran (and/or IDMC) connector configured and connectivity tested
- AI use case finalized with client SMEs — **must happen in Week 1**

#### Data ingestion approach
- **Confirmed tooling:** IDMC (Informatica Data Management Cloud) — already available in the client environment
- ~~Fivetran~~ — descoped for this use case; IDMC confirmed as the ingestion tool
- No S3 staging — direct-to-Snowflake ingestion
- **Synthetic / sample data fallback:** If PHI governance gate is not cleared in time, a manually extracted or synthetically generated dataset may be used for Crawl phase development. This decouples model building from the compliance timeline.

#### Hard gate
No pipelines execute and no data moves until the Foundation Sprint is complete. Any slip here cascades across the entire sprint.

---

### Phase 2 — Crawl (Weeks 3–4): Prototype

**Goal:** A running daily recommendation engine. No UI. No operational action. Internal validation only.

#### What gets built

**Layer 1 — Historical no-show dataset**

Pull 12–24 months of completed appointments from EPIC Clarity (or synthetic equivalent). For each appointment record, capture:

- Appointment type (new vs. return)
- Specialty / department
- Lead time (days between booking date and appointment date)
- Time of day, day of week
- Historical no-show flag (from `ZC_APPT_STATUS`)
- Patient-level no-show rate — rolling 12 months, masked patient ID
- Insurance / coverage type
- Slot duration

**Layer 2 — No-show scoring model**

Approach depends on the form of the existing model (confirmed in Week 1 scoping):

| Existing model form | Crawl approach |
|---|---|
| Score already in EPIC Clarity | Extract score column, validate against historical outcomes |
| Python / R model in another system | Call via API or replicate logic in Snowflake Cortex ML |
| SQL / rules-based score in existing DWH | Replicate logic in Snowflake SQL |
| Not operationalized / in a spreadsheet | Build from scratch using Snowflake Cortex ML `CLASSIFICATION` |

Output: a `no_show_probability` score (0–1) per upcoming appointment, bucketed into Low / Medium / High risk tiers.

**Layer 3 — Session risk profile**

Aggregate patient scores to session level:
- Count of High / Medium / Low risk appointments per session
- Session risk classification (e.g. >30% High-risk = "elevated session")
- Sessions flagged where trigger criteria are met (lead time window, return slots available, guardrail cap not exceeded)
- Recommended action: *Adjust one return slot 1→2* or *Hold*

Output table: `AGILE_CAPACITY_DAILY_RECOMMENDATIONS` — one row per session, with risk profile and recommended action.

#### Crawl success criteria
- Model produces a score for ≥95% of upcoming appointments
- Session risk classification aligns with Capacity Management team's intuitive view of problematic sessions (gut-check validation at Week 4 demo)
- Recommendation logic matches guardrails as written — return slots only, ≤1 slot adjusted per session, correct lead time window

#### Note on synthetic / sample data
If real Clarity data is not available by Week 3, Crawl proceeds on:
- A manually extracted sample (de-identified, approved by client compliance), or
- A synthetic dataset generated to match the Clarity schema and approximate historical distributions

The model built on synthetic data will be rebuilt or recalibrated once real data flows in Week 5. The crawl phase output is still valid as a structural and logic proof — it de-risks the model design before production data is involved.

---

### Phase 3 — Walk (Weeks 5–6): Pilot

**Goal:** Capacity Management team reviews real recommendations, makes real slot adjustments in EPIC, and outcomes are tracked.

#### What gets built

**Streamlit in Snowflake dashboard**

An action queue for the Capacity Management team — not a reporting dashboard:
- Daily view of sessions flagged for adjustment within the recommendation horizon
- Per session: specialty, provider, date/time, appointment count, risk tier breakdown, recommended action
- Manual override: Approved / Overridden / Deferred — with free-text reason for overrides
- Masked patient identifiers only — Capacity Management works from session-level data, not named patient lists

**Feedback capture table**

Every recommendation actioned or overridden is written back to Snowflake:

```
recommendation_id | session_id | recommendation | action_taken | 
override_reason   | actioned_by | actioned_timestamp
```

**Outcomes tracking**

For every session where a slot was adjusted:
- Did the adjusted slot fill? (second patient booked)
- Did both patients arrive? (core operational risk)
- Were any wait time threshold breaches flagged?
- Was capacity reverted mid-session?

Data returns from EPIC Clarity via IDMC with a 24–48 hour lag.

#### Pilot parameters to confirm in Week 4
- Which 2–3 specialties are in scope
- Lead time window (48h / 72h / 1 week)
- Risk threshold for session flagging (% High-risk patients that triggers a recommendation)
- Maximum sessions per day the Capacity Management team can action

#### Walk success criteria
- Capacity Management team reviews the queue daily for 2 weeks
- At least 15–20 sessions adjusted (sufficient for preliminary outcome signals)
- Override rate <50% (higher suggests model thresholds or guardrails need recalibration)
- Zero clinic throughput threshold breaches triggered by adjusted slots
- Provider and Capacity Management qualitative feedback collected (structured survey, end of Week 6)

---

### Phase 4 — Run (Weeks 7–8): Productionalize Path

**Goal:** Go/Refine/Retire decision per use case, and a defined path to production.

#### Pilot outcomes assessment

Structured summary across four dimensions:
1. **Model performance** — score accuracy, tier calibration, override patterns, feature importance
2. **Operational performance** — slot fill rate, dual-arrival rate, wait time impact, reversion events
3. **Capacity Management experience** — time spent, confidence in recommendations, friction points
4. **Clinic/provider experience** — feedback from the 2–3 pilot specialties

#### Production readiness gap list

| Gap | Description | Estimated effort |
|---|---|---|
| Model refresh cadence | Daily retrain vs. weekly vs. static — depends on data drift | Low |
| EPIC write-back | Direct EPIC API integration to execute slot changes — removes manual step | High |
| Push notification | Email/Teams alert to Capacity Management — replaces dashboard polling | Medium |
| Expanded specialty coverage | Pilot covers 2–3 specialties; production scales to all outpatient | Medium |
| Model explainability | Show *why* a session was flagged — supports provider trust | Medium |
| Monitoring and drift detection | Automated alerting when model performance degrades | Medium |
| PHI handling in UI | Production may require named patient view (Zone 0 access implications) | Medium |
| Clinical governance sign-off | Formal review of model logic and guardrails before scale | External |

#### Go / Refine / Retire decision criteria

| Decision | Trigger |
|---|---|
| **Go** | Outcomes positive, override rate reasonable, provider feedback neutral or positive, no throughput breaches |
| **Refine** | Model thresholds need recalibration, guardrails too tight or too loose, specific specialties excluded |
| **Retire** | Operational disruption, provider resistance, data quality insufficient for reliable scoring |

---

## 5. EPIC Clarity Tables Required

| Table | Purpose |
|---|---|
| `PAT_ENC` | Core appointment record — patient, provider, department, date, appointment type |
| `PAT_ENC_2` | Extended appointment attributes — slot duration, visit type flags |
| `ZC_APPT_STATUS` | Status code lookup — No Show, Completed, Cancelled, Left Without Seen |
| `CLARITY_DEP` | Department / specialty lookup |
| `CLARITY_SER` | Provider lookup |
| `SCHED_APPT` | Scheduled slot details — capacity, overbooking flags |
| `PATIENT` | Demographics — age, distance proxy (Zone 0 PHI — masking required) |
| `PAT_ADDRESS` | Patient address for distance-to-clinic features (Zone 0 PHI — masking required) |
| `COVERAGE` | Insurance / payer — often a no-show predictor |

> **PHI note:** `PATIENT`, `PAT_ADDRESS`, and `COVERAGE` contain Zone 0 PHI. Masking policies must be deployed before IDMC replication runs. The session-level scoring output written to Zone 1 must use masked patient identifiers.

---

## 6. Anticipated Benefits

- Improves access for patients waiting for specialty care without adding provider hours
- Converts predicted unused capacity into real completed visits
- Applies analytics in a tightly governed, reversible way
- Delivers a concrete, high-value Snowflake AI use case aligned to access and throughput metrics
- Provides immediate ROI signal ahead of full HC migration completion

---

## 7. Pilot Success Measures

- Improved completed appointments per session
- No-show rate pre and post-implementation
- Patient wait time and clinic flow indicators
- Provider and operational team feedback (qualitative, structured survey)
- Override rate as a proxy for recommendation quality
- Zero forced reversion events (operational safety indicator)

---

## 8. Open Questions & Blockers

### Must resolve before Week 1 ends

| # | Question | Owner | Status |
|---|---|---|---|
| 1 | Where does the existing no-show model live, and in what form? | Client analytics / informatics | Open |
| 2 | Is the model running in production or is it a prototype? | Client analytics | Open |
| 3 | Who owns the model and can provide access or documentation? | Client analytics | Open |
| 4 | EPIC layer confirmed — Clarity, Caboodle, or both? | Client / EPIC team | Open |
| 5 | How many years of appointment history are in Clarity? | Clarity DBA | Open |
| 6 | Has the Snowflake BAA been initiated? Named owner and target date? | Client legal / compliance | Open |
| 7 | Does Capacity Management need named patient data in the pilot UI? | Client compliance | Open |

### Resolve by Week 4 (before Walk phase begins)

| # | Question | Owner |
|---|---|---|
| 8 | Which 2–3 specialties are in scope for the pilot? | Client operations |
| 9 | Named Capacity Management pilot users (2–3 individuals) | Client operations |
| 10 | Lead time window for recommendations (48h / 72h / 1 week) | Client / Capacity Mgmt |
| 11 | Session risk threshold — what % High-risk triggers a recommendation? | Client / Deloitte |
| 12 | Maximum sessions per day the team can action | Client / Capacity Mgmt |
| 13 | Operational reversion threshold (wait time, patient overlap) | Client clinical / ops |

### Async — send to technical contacts

| Question | Send to |
|---|---|
| Is no-show status reliably recorded? Are cancellations distinguished from no-shows? | Clarity DBA |
| Is new vs. return visit type a reliably populated field? | Clarity DBA |
| Is insurance/coverage type available at appointment level? | Clarity DBA |
| Is rolling patient no-show rate available as a column or must it be computed? | Clarity DBA |
| What features does the model use? | Model owner |
| Has the model been validated — AUC, precision/recall at current thresholds? | Model owner |
| Is there a clinical governance review required before pilot go-live? | Clinical sponsor |
| Are any patient populations explicitly excluded — mental health, minors, recent discharge? | Clinical sponsor |

---

## 9. Key Risks & Mitigations

| Risk | Likelihood | Impact | Mitigation |
|---|---|---|---|
| Existing model not in a reusable form | Medium | High | Rebuild in Snowflake Cortex ML — 1–2 days; treat as contingency in crawl plan |
| Clarity data quality insufficient for reliable scoring | Medium | High | Run data quality assessment in Week 3 before model build begins; document gaps |
| BAA not signed before Foundation Sprint ends | Low–Medium | High | Initiate with client legal immediately; use synthetic data in Crawl if delayed |
| Capacity Management team unable to action recommendations daily | Low | High | Confirm bandwidth and named users before Walk phase begins |
| Override rate >50% — model thresholds wrong | Medium | Medium | Build override reason capture from day one; recalibrate thresholds after Week 5 |
| Provider resistance to adjusted slots | Low | High | Limit to return slots; engage clinical sponsor for provider communications pre-launch |
| IDMC connector configuration delays Foundation Sprint | Low | Medium | Confirm IDMC connector config and EPIC Clarity connectivity in Week 1; flag any IPU or licensing constraints early |

---

## 10. Assumptions

1. The existing no-show probability model is accessible and documentable within Week 1.
2. EPIC Clarity appointment data covers at least 12 months of history.
3. If real Clarity data is unavailable at Crawl start, a synthetic or de-identified sample is approved and available by Week 3.
4. The Capacity Management team has bandwidth to review recommendations daily during the Walk phase (Weeks 5–6).
5. The pilot covers return patient slots only — new patient slots are excluded per the guardrails.
6. Capacity Management executes slot adjustments manually in EPIC — no automated EPIC write-back in this sprint.
7. IDMC is confirmed as the ingestion tool for this use case and is already available in the client environment.
8. Snowflake Cortex is the preferred AI/ML runtime — no external model serving infrastructure required.

---

## 11. Stakeholders

| Role | Responsibility | Named individual |
|---|---|---|
| Client clinical sponsor | Pilot go/no-go authority, provider communications | TBD |
| Capacity Management lead | Pilot user, daily recommendation review | TBD |
| Capacity Management pilot users (×2–3) | Walk phase participants | TBD |
| Client analytics / no-show model owner | Model access, documentation, validation data | TBD |
| Client Clarity DBA / EPIC analyst | Table access, field population confirmation | TBD |
| Client legal / compliance | Snowflake BAA sign-off | TBD |
| Deloitte FDE lead | Sprint delivery, model build, dashboard | TBD |
| Deloitte US architect | Zone 0 PHI governance, Snowflake architecture | TBD (named, costed role) |

---

## 12. Recommended Next Steps

1. **Monday working session** — confirm model form (blocker), agree pilot specialties, name BAA owner
2. **By end of Week 1** — send async questions to Clarity DBA and model owner; get written confirmation on data availability
3. **If BAA is delayed** — initiate synthetic data generation or de-identified sample extraction immediately; do not let it hold the Crawl build
4. **Week 4** — confirm Walk phase parameters (specialties, lead time, threshold, team bandwidth) before building the Streamlit dashboard
5. **Week 8 steering** — present Go/Refine/Retire decision with Phase 2 commercial terms ready for sign

---

*Document maintained by Deloitte FDE team. All open items to be updated following Monday working session.*
