# Advisor360 — React + FastAPI on SPCS

Advisor360 is a single-advisor agentic workspace for insurance/financial advisors. It surfaces AI-prioritized tasks, client intelligence, AI-drafted communications, and policy risk monitoring — all backed by Snowflake Cortex AI.

This is the containerized React + FastAPI implementation, deployed on Snowpark Container Services (SPCS).

---

## Architecture

```
┌─────────────────────────────────────────────────────────────────────┐
│                       SPCS Container (port 80)                       │
│                                                                     │
│  ┌─────────────────────────────────────────────────────────────┐   │
│  │                     supervisord                               │   │
│  │                                                               │   │
│  │  ┌────────────────────┐     ┌──────────────────────────┐    │   │
│  │  │    nginx (:80)      │     │  uvicorn (:8000)          │    │   │
│  │  │                    │     │                            │    │   │
│  │  │  /       → React   │     │  FastAPI backend           │    │   │
│  │  │  /api/* → proxy ───┼────▶│  • Snowflake queries       │    │   │
│  │  │          to :8000   │     │  • Cortex AI (mistral-     │    │   │
│  │  │                    │     │    large2)                  │    │   │
│  │  └────────────────────┘     └──────────┬───────────────┘    │   │
│  │                                         │                     │   │
│  └─────────────────────────────────────────┼─────────────────────┘   │
│                                            │                         │
│                    /snowflake/session/token │ (OAuth)                 │
└────────────────────────────────────────────┼─────────────────────────┘
                                             │
                                             ▼
                              ┌──────────────────────────┐
                              │      Snowflake            │
                              │  ADVISOR360_DB.APP        │
                              │  ADVISOR360_DB.AGENTS     │
                              │  SNOWFLAKE.CORTEX         │
                              └──────────────────────────┘
```

**Request flow:**
1. Browser hits the SPCS public endpoint (nginx on port 80)
2. Static React assets served directly for all non-API routes
3. `/api/*` requests proxied to FastAPI (uvicorn on port 8000)
4. FastAPI authenticates to Snowflake using the SPCS OAuth token mounted at `/snowflake/session/token`
5. AI features call `SNOWFLAKE.CORTEX.COMPLETE` with `mistral-large2`

---

## Tech Stack

| Layer | Technology | Version |
|-------|-----------|---------|
| Frontend | React + TypeScript | 18.3 |
| Build tool | Vite | 5.3 |
| Routing | react-router-dom | 6.23 |
| HTTP client | axios | 1.7 |
| Backend | FastAPI | 0.111 |
| ASGI server | Uvicorn | 0.30 |
| Snowflake SDK | snowflake-connector-python | 3.10 |
| Validation | Pydantic | 2.7 |
| Web server | nginx | (system) |
| Process manager | supervisord | (system) |
| Container | Docker (multi-stage) | — |
| AI model | Cortex `mistral-large2` | — |

---

## Project Structure

```
advisor360-react/
├── Dockerfile                 # Multi-stage: Node build → Python runtime
├── snowflake.yml              # Snowflake CLI service definition
├── spec.yaml                  # SPCS container spec (resources, endpoints)
├── nginx.conf                 # Reverse proxy: / → React, /api → uvicorn
├── supervisord.conf           # Runs nginx + uvicorn in single container
│
├── frontend/
│   ├── package.json
│   ├── tsconfig.json
│   ├── vite.config.ts
│   └── src/
│       ├── main.tsx           # React entry point
│       ├── App.tsx            # Router + layout (9 routes)
│       ├── pages/
│       │   ├── Dashboard.tsx
│       │   ├── ClientsLeads.tsx
│       │   ├── SmartWorklist.tsx
│       │   ├── Communications.tsx
│       │   ├── Policies.tsx
│       │   ├── Analytics.tsx
│       │   ├── PrepTools.tsx
│       │   ├── AgentPanel.tsx
│       │   └── AIPreferences.tsx
│       ├── components/
│       │   ├── Header/
│       │   ├── Sidebar/
│       │   ├── Toast/
│       │   └── AgentPanel/    # Agent output slide-in panel
│       ├── hooks/
│       │   └── usePanelContext.tsx
│       └── styles/
│           ├── variables.css
│           ├── global.css
│           └── shared.css
│
└── backend/
    ├── requirements.txt
    └── app/
        ├── __init__.py
        ├── main.py            # FastAPI app + middleware + exception handler
        ├── models/
        │   └── schemas.py     # Pydantic request/response models
        ├── routes/
        │   ├── dashboard.py   # GET /api/dashboard
        │   ├── clients.py     # GET /api/clients
        │   ├── worklist.py    # GET/POST /api/worklist
        │   ├── communications.py  # GET/POST /api/communications
        │   ├── policies.py    # GET /api/policies
        │   ├── analytics.py   # GET /api/analytics
        │   ├── agents.py      # GET /api/agents
        │   ├── panel.py       # GET /api/panel
        │   └── cortex_routes.py   # POST /api/cortex/*
        └── services/
            ├── snowflake.py   # Connection management (OAuth in SPCS)
            └── cortex.py      # Cortex COMPLETE wrappers
```

---

## Prerequisites

- **Snowflake account** with `ADVISOR360_DB` database (schemas: `APP`, `AGENTS`)
- **SPCS access** — `SPCS_ON_DEMAND` role with grants on `SPCS_ON_DEMAND_CPU_POOL`
- **Image repository** — `ADVISOR360_DB.APP.ADVISOR360_REPO`
- **Node.js 20+** (for local frontend dev)
- **Python 3.11+** (for local backend dev)
- **Docker** (for building the container image)

See [docs/DEPLOYMENT.md](docs/DEPLOYMENT.md) for full environment setup instructions.

---

## Local Development

### Frontend

```bash
cd frontend
npm install
npm run dev
# → Runs on http://localhost:5173
```

The Vite dev server proxies `/api/*` requests. Configure `vite.config.ts` proxy target to point at the local backend.

### Backend

```bash
cd backend
pip install -r requirements.txt

# Set environment variables for local Snowflake connection
export SNOWFLAKE_ACCOUNT="your_account"
export SNOWFLAKE_USER="your_user"
export SNOWFLAKE_PASSWORD="your_password"

uvicorn app.main:app --host 0.0.0.0 --port 8000 --reload
# → Runs on http://localhost:8000
```

In SPCS, the backend authenticates automatically via the OAuth token at `/snowflake/session/token`. For local dev, it falls back to username/password from environment variables.

---

## API Reference

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/health` | Health check — returns `{"status": "healthy"}` |
| GET | `/api/dashboard` | KPIs, top renewal, revenue opportunity, risk alert |
| GET | `/api/clients` | Client roster with AI scores |
| GET | `/api/worklist` | AI-prioritized task list |
| POST | `/api/worklist` | Update worklist item status |
| GET | `/api/communications` | AI-drafted emails and call scripts |
| POST | `/api/communications` | Approve/reject/revise communications |
| GET | `/api/policies` | Policy table with status and risk flags |
| GET | `/api/analytics` | Premium and policy mix chart data |
| GET | `/api/agents` | Background AI agent activity log |
| GET | `/api/panel` | Agent output panel detail data |
| POST | `/api/cortex/revise` | Revise an email draft via Cortex AI |
| POST | `/api/cortex/talking-points` | Generate meeting talking points via Cortex AI |

---

## Database Schema

**Database:** `ADVISOR360_DB`

### Schema: `APP`

| Table | Purpose |
|-------|---------|
| `ADVISORS` | Advisor profile (James Rivera) |
| `CLIENTS` | Client roster with lifecycle data, sentiment scores |
| `POLICIES` | Policy details — type, premium, renewal dates, cash values |
| `AI_SCORES` | Cortex-generated propensity/risk scores per client |
| `WORKLIST_ITEMS` | AI-prioritized + manual tasks for the advisor |
| `COMMUNICATIONS` | AI-drafted emails and call scripts with approval workflow |
| `KPI_SNAPSHOTS` | Daily advisor performance metrics |
| `PREMIUM_MONTHLY` | Monthly premium data for analytics charts |

### Schema: `AGENTS`

| Table | Purpose |
|-------|---------|
| `AGENT_ACTIVITY_LOG` | Background AI agent execution log (phases, status, messages) |

---

## Cortex AI Integration

The app uses **Snowflake Cortex** for AI features — no external LLM APIs.

| Feature | Model | Function |
|---------|-------|----------|
| Email revision | `mistral-large2` | `SNOWFLAKE.CORTEX.COMPLETE` with system + user messages |
| Talking points | `mistral-large2` | `SNOWFLAKE.CORTEX.COMPLETE` with client context |
| AI scores/narratives | `mistral-large2` | Pre-computed and stored in `AI_SCORES` table |

All Cortex calls are routed through `backend/app/services/cortex.py`, which constructs the `ARRAY_CONSTRUCT(OBJECT_CONSTRUCT(...))` message format and executes via the Snowflake connector.

---

## Environment Variables

| Variable | Required | Context | Description |
|----------|----------|---------|-------------|
| `SNOWFLAKE_ACCOUNT` | Yes (SPCS + local) | Both | Snowflake account identifier |
| `SNOWFLAKE_HOST` | Yes (SPCS) | SPCS only | Snowflake host URL |
| `SNOWFLAKE_USER` | Yes (local) | Local dev only | Username for password auth |
| `SNOWFLAKE_PASSWORD` | Yes (local) | Local dev only | Password for local auth |

In SPCS, authentication uses the auto-mounted OAuth token at `/snowflake/session/token`. No credentials are needed in the container environment.

---

## Related Resources

- [Deployment Guide](docs/DEPLOYMENT.md) — build, push, deploy, monitor, teardown
- [Build Specification](../advisor360.md) — full 1300+ line original spec (schemas, data, Cortex queries, page specs)
- [SPCS Role Setup](../work/spcs_on_demand_setup.md) — compute pool, role, and cost guardrails setup
