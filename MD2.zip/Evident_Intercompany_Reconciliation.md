# Evident Intercompany Reconciliation — Technical Documentation

**Application:** Streamlit in Snowflake (`INTERCO_RECON.PUBLIC.RECON_APP`)  
**Title:** Evident Intercompany Reconciliation  
**Database:** `INTERCO_RECON`  
**Warehouse:** `INTERCO_RECON_WH`  
**Last Updated:** 2026-05-18  

---

## Table of Contents

1. [Overview](#overview)
2. [Architecture](#architecture)
3. [Entity & Pair Configuration](#entity--pair-configuration)
4. [Database Schema Reference](#database-schema-reference)
5. [Pipeline Phases](#pipeline-phases)
6. [Human-in-the-Loop (HITL) Queues](#human-in-the-loop-hitl-queues)
7. [Views](#views)
8. [Validation & Regression](#validation--regression)
9. [Streamlit Application Pages](#streamlit-application-pages)
10. [Data Flow Diagram](#data-flow-diagram)
11. [AI/ML Components](#aiml-components)
12. [Data Volumes](#data-volumes)

---

## Overview

The Evident Intercompany Reconciliation system automates the reconciliation of intercompany transactions across Evident's global legal entities. It processes GL balance data and transaction-level line items through a progressive 4-phase pipeline:

1. **Phase 1** — GL-level balance comparison (deterministic)
2. **Phase 2** — Invoice/line-level deterministic matching (weighted scoring)
3. **Phase 3** — AI-powered fuzzy matching using vector embeddings (Snowflake Cortex)
4. **Phase 4** — LLM-based root cause classification and journal entry proposal (Snowflake Cortex)

At each stage, items requiring human judgment are routed to approval queues surfaced in the Streamlit UI. The system supports full audit trail, regression testing against known baselines, and ERP export of approved journal entries.

---

## Architecture

### Schema Layout

```
INTERCO_RECON (Database)
├── PUBLIC          — Streamlit app, orchestration procedures, validation suite
├── RAW             — Raw file ingestion (file registry, cells, tabs)
├── REF             — Reference/master data (entities, pairs, GL accounts, FX, known issues)
├── STAGING         — Cleaned transactional data (IC_LINES, GL_BALANCES, adjustments)
├── RESULTS         — Phase outputs (balance recon, line matches, fuzzy matches, AI classifications)
├── HITL            — Human-in-the-loop approval queues
├── TRAINING        — Few-shot examples for the LLM
└── REGRESSION      — Regression targets and validation run history
```

### Processing Flow

```
Raw Files → SP_RAW_TO_STAGING → STAGING.IC_LINES / GL_BALANCES
                                         │
                              SP_RUN_PIPELINE_END_TO_END
                                         │
                    ┌────────────────────┬┴──────────────────────┐
                    ▼                    ▼                        ▼
              SP_RUN_PHASE1      SP_RUN_PHASE2_TRADE      SP_RUN_PHASE3
              (GL Balance)       (Deterministic Match)    (Fuzzy/Embedding)
                    │                    │                        │
                    ▼                    ▼                        ▼
          PHASE1_BALANCE_RECON  PHASE2_LINE_MATCHES     PHASE3_FUZZY_MATCHES
                    │                    │                        │
                    │              ┌─────┴─────┐           ┌─────┴─────┐
                    │              ▼           ▼           ▼           ▼
                    │          PERFECT     REVIEW      ≥0.80       0.60-0.80
                    │          (done)     QUEUE       FUZZY_QUEUE  REVIEW_QUEUE
                    │
                    ▼
           GL_VARIANCE pairs with unmatched lines
                    │
                    ▼
              SP_RUN_PHASE4 (LLM Classification)
                    │
                    ▼
          CLASSIFICATION_APPROVAL_QUEUE → Reviewer → ERP Export
```

---

## Entity & Pair Configuration

### Entities (9)

| Entity Code | Full Name | Region | Functional Currency |
|-------------|-----------|--------|---------------------|
| EAS | Evident Asia (Singapore) | APAC | SGD |
| ECN | Evident China | APAC | CNY |
| EEU | Evident Europe | EMEA | EUR |
| EIND | Evident India | APAC | INR |
| EJP | Evident Japan | APAC | JPY |
| EKR | Evident Korea | APAC | KRW |
| ESCE | Evident Scientific Europe | EMEA | EUR |
| ETCE | Evident Technology Center Europe | EMEA | EUR |
| EUSA | Evident USA | AMER | USD |

### Bilateral Pairs (17 active)

| Pair ID | Entity A | Entity B |
|---------|----------|----------|
| EAS-EJP | EAS | EJP |
| ECN-EJP | ECN | EJP |
| ECN-ETCE | ECN | ETCE |
| EEU-EJP | EEU | EJP |
| EEU-EUSA | EEU | EUSA |
| EIND-EJP | EIND | EJP |
| EIND-ESG | EIND | ESG |
| EIND-ETCE | EIND | ETCE |
| EIND-EUSA | EIND | EUSA |
| EJP-EKR | EJP | EKR |
| EJP-ESCE | EJP | ESCE |
| EJP-ESG | EJP | ESG |
| EJP-ETCE | EJP | ETCE |
| EJP-EUSA | EJP | EUSA |
| EJP-MIS-CND | EJP | MIS |
| ETCE-EUSA | ETCE | EUSA |
| EUSA-MIS-CND | EUSA | MIS |

All pairs are in the **MIS** segment. Pairs are defined in `REF.REF_BILATERAL_PAIRS`.

---

## Database Schema Reference

### RAW Schema — File Ingestion

#### `RAW.RAW_FILE_REGISTRY`
Tracks uploaded Excel/CSV files for processing.

#### `RAW.RAW_TAB_REGISTRY`
Tracks individual tabs/sheets within uploaded files.

#### `RAW.RAW_CELLS`
Raw cell-level data extracted from Excel files before transformation.

---

### REF Schema — Reference Data

#### `REF.REF_ENTITIES`
| Column | Type | Description |
|--------|------|-------------|
| ENTITY_SAP_CODE | VARCHAR(10) PK | SAP system code |
| ENTITY_CODE | VARCHAR(10) UNIQUE | Short code used throughout |
| ENTITY_FULL_NAME | VARCHAR(200) | Legal entity name |
| REGION | VARCHAR(20) | APAC / EMEA / AMER |
| SEGMENT | VARCHAR(20) | Business segment |
| CURRENCY_FUNCTIONAL | VARCHAR(3) | Functional currency (ISO) |

#### `REF.REF_BILATERAL_PAIRS`
| Column | Type | Description |
|--------|------|-------------|
| PAIR_ID | VARCHAR(50) PK | e.g., "ECN-EJP" |
| ENTITY_A_CODE | VARCHAR(10) | First entity in the pair |
| ENTITY_B_CODE | VARCHAR(10) | Second entity in the pair |
| SEGMENT | VARCHAR(20) | Business segment |
| ACTIVE | BOOLEAN | Whether pair is active for reconciliation |
| EXPECTED_VOLUMES_NOTE | VARCHAR(500) | Notes on expected transaction volumes |

#### `REF.REF_ENTITY_GL_ACCOUNTS`
Maps each entity to its OneStream accounts and plug accounts (180 mappings). Used in Phase 4 to determine where journal entries should be posted.

#### `REF.REF_FOREX_RATES` / `REF.FX_RATES`
Foreign exchange rates for currency conversion. Used to normalize amounts to JPY reporting currency.

#### `REF.REF_KNOWN_ISSUES`
Known recurring reconciliation patterns that the LLM references in Phase 4 for more accurate classification.

| Key Columns | Description |
|-------------|-------------|
| PAIR_ID | Affected pair |
| OS_ACCOUNT | OneStream account |
| PATTERN_DESCRIPTION | What the issue looks like |
| TYPICAL_RESOLUTION | How it's normally resolved |

#### `REF.PAIR_ADJUSTMENTS`
Pre-approved adjustments applied at the pair level. Contains JPY and USD adjustment amounts with remarks.

---

### STAGING Schema — Cleaned Transactional Data

#### `STAGING.IC_LINES` (Primary transaction table — 7,234 rows)
Clustered by: `(PERIOD, PAIR_ID, ONESTREAM_ACCOUNT)`

| Column | Type | Description |
|--------|------|-------------|
| LINE_ID | VARCHAR(50) PK | Unique line identifier |
| SOURCE_FILE | VARCHAR(500) | Origin file |
| SOURCE_TAB | VARCHAR(200) | Origin tab/sheet |
| SOURCE_ROW | NUMBER | Row number in source |
| LOAD_DATE | TIMESTAMP | When loaded |
| PERIOD | DATE | Accounting period |
| ENTITY_CODE | VARCHAR(10) | Booking entity |
| COUNTERPARTY_CODE | VARCHAR(10) | Intercompany counterparty |
| PAIR_ID | VARCHAR(50) | Bilateral pair |
| SEGMENT | VARCHAR(20) | Business segment |
| SAP_GL_ACCOUNT | VARCHAR(20) | SAP GL account number |
| SAP_ACCOUNT_DESCRIPTION | VARCHAR(200) | Account description |
| ONESTREAM_ACCOUNT | VARCHAR(20) | OneStream consolidation account |
| CATEGORY | VARCHAR(50) | Transaction category |
| NATURE | VARCHAR(50) | Nature of transaction |
| AR_OR_AP | VARCHAR(2) | Receivable or Payable |
| BS_OR_PL | VARCHAR(2) | Balance Sheet or P&L |
| ASSET_OR_LIAB | VARCHAR(10) | Asset or Liability |
| DOC_NUMBER | VARCHAR(100) | Invoice/document number |
| DOC_DATE | DATE | Document date |
| POSTING_MONTH | VARCHAR(7) | Posting period (YYYY-MM) |
| DOC_CURRENCY | VARCHAR(3) | Transaction currency |
| DOC_AMOUNT | NUMBER(20,2) | Amount in document currency |
| LC_CURRENCY | VARCHAR(3) | Local currency code |
| LC_AMOUNT | NUMBER(20,2) | Amount in local currency |
| REPORTING_AMOUNT_JPY | NUMBER(20,2) | JPY equivalent |
| FOREX_RATE | NUMBER(20,8) | Exchange rate applied |
| FREE_TEXT | VARCHAR(1000) | Free text / description |
| PROFIT_CENTER | VARCHAR(20) | Profit center |
| BUSINESS_UNIT | VARCHAR(20) | Business unit |
| PHASE1_STATUS | VARCHAR(20) | Phase 1 status |
| PHASE2_MATCH_ID | VARCHAR(50) | FK to PHASE2_LINE_MATCHES |
| PHASE3_MATCH_ID | VARCHAR(50) | FK to PHASE3_FUZZY_MATCHES |
| PHASE4_CLASSIFICATION_ID | VARCHAR(50) | FK to PHASE4_AI_CLASSIFICATIONS |
| LINE_STATUS | VARCHAR(20) | Overall line status |
| EMBEDDING_TEXT | VARCHAR(2000) | Concatenated text for embedding |
| EMBEDDING_VECTOR | VECTOR(FLOAT, 1024) | Cortex embedding vector |

#### `STAGING.GL_BALANCES` (207 rows)
| Column | Type | Description |
|--------|------|-------------|
| PERIOD | DATE | Accounting period |
| SAP_GL_ACCOUNT | VARCHAR(20) | SAP GL account |
| SAP_ACCOUNT_DESCRIPTION | VARCHAR(200) | Description |
| ICP_CODE | VARCHAR(20) | Intercompany partner code |
| ICP_NAME | VARCHAR(50) | Intercompany partner name |
| NATURE | VARCHAR(50) | Nature |
| BUSINESS_UNIT | VARCHAR(10) | BU code |
| CLASS | VARCHAR(50) | Classification |
| DOC_CURRENCY | VARCHAR(10) | Document currency |
| DOC_CURR_AMOUNT | NUMBER(20,2) | Amount in doc currency |
| LC_AMOUNT | NUMBER(20,2) | Amount in local currency |
| ENTITY_CODE | VARCHAR(10) | Entity code |
| ENTITY_NAME | VARCHAR(20) | Entity name |
| LOCAL_CURRENCY | VARCHAR(10) | Local currency |
| FX_RATE | NUMBER(10,4) | Exchange rate |
| JPY_AMOUNT | NUMBER(30,10) | JPY equivalent |
| USD_AMOUNT | NUMBER(30,10) | USD equivalent |
| PAIR_ID | VARCHAR(50) | Bilateral pair |

#### `STAGING.JOURNAL_ADJUSTMENTS` (30 rows)
Pre-approved journal adjustment entries.

#### `STAGING.ENTRY_SUMMARY` (19 rows)
Aggregated entry summary with SAP/HFM code mapping.

| Column | Type | Description |
|--------|------|-------------|
| PERIOD | DATE | Period |
| PAIR_GROUP | VARCHAR(50) | Pair grouping |
| SAP_CODE | VARCHAR(20) | SAP account code |
| DESCRIPTION_SAP | VARCHAR(200) | SAP description |
| HFM_CODE | VARCHAR(20) | HFM/OneStream code |
| DESCRIPTION_HFM | VARCHAR(200) | HFM description |
| LC | VARCHAR(10) | Local currency |
| LC_AMOUNT | NUMBER(30,10) | Local currency amount |
| JPY_AMOUNT | NUMBER(30,10) | JPY amount |
| ENTITY | VARCHAR(20) | Entity |
| ICP / ICP_CODE | VARCHAR(20) | Intercompany partner |
| SEGMENT | VARCHAR(10) | Segment |
| REMARK | VARCHAR(500) | Remarks |
| CLASS_TAG | VARCHAR(20) | Classification tag |

---

### RESULTS Schema — Phase Outputs

#### `RESULTS.PHASE1_BALANCE_RECON` (35 rows)
| Column | Type | Description |
|--------|------|-------------|
| RECON_ID | VARCHAR(50) PK | UUID |
| PERIOD | DATE | Accounting period |
| PAIR_ID | VARCHAR(50) | Bilateral pair |
| OS_ACCOUNT | VARCHAR(20) | OneStream account |
| OS_DESCRIPTION | VARCHAR(200) | Account description |
| CATEGORY | VARCHAR(50) | Category |
| DOC_CURRENCY | VARCHAR(3) | Currency |
| SIDE_A_ENTITY | VARCHAR(10) | Entity A |
| SIDE_A_BALANCE | NUMBER(20,2) | Side A total balance |
| SIDE_A_LINE_COUNT | NUMBER | Line count on Side A |
| SIDE_B_ENTITY | VARCHAR(10) | Entity B |
| SIDE_B_BALANCE | NUMBER(20,2) | Side B total balance |
| SIDE_B_LINE_COUNT | NUMBER | Line count on Side B |
| VARIANCE | NUMBER(20,2) | Net variance (A + B) |
| VARIANCE_PCT | NUMBER(8,6) | Variance as % of larger side |
| VARIANCE_JPY | NUMBER(20,2) | Variance in JPY |
| RECON_STATUS | VARCHAR(20) | `GL_BALANCED` / `GL_NEAR_BALANCED` / `GL_VARIANCE` |
| PHASE1_CONFIDENCE | NUMBER(5,4) | Confidence score (1.0 / 0.9 / 0.0) |
| COMPUTED_AT | TIMESTAMP | When computed |

#### `RESULTS.PHASE2_LINE_MATCHES` (167 rows)
| Column | Type | Description |
|--------|------|-------------|
| MATCH_ID | VARCHAR(50) PK | UUID |
| PERIOD | DATE | Period |
| PAIR_ID | VARCHAR(50) | Pair |
| OS_ACCOUNT | VARCHAR(20) | OneStream account (nullable) |
| LINE_A_ID | VARCHAR(50) | FK to IC_LINES (Side A) |
| LINE_B_ID | VARCHAR(50) | FK to IC_LINES (Side B) |
| ICP_MATCH | NUMBER(1,0) | 1 if counterparties match |
| INVOICE_MATCH | NUMBER(1,0) | 1 if document numbers match |
| DOC_CURR_MATCH | NUMBER(1,0) | 1 if currencies match |
| AMOUNT_MATCH | NUMBER(1,0) | 1 if amounts match (±¥0.01) |
| DOC_DATE_MATCH | NUMBER(1,0) | 1 if dates within 5 days |
| POSTING_MONTH_MATCH | NUMBER(1,0) | 1 if same posting month |
| CONFIDENCE | NUMBER(5,4) | Weighted score (0.0–1.0) |
| CRITERIA_FAILED | VARCHAR(500) | Comma-separated failed criteria |
| MATCH_STATUS | VARCHAR(20) | `PERFECT` / `REVIEW` / `PHASE3` |
| MATCH_TYPE | VARCHAR(20) | `TRADE` |
| COMPUTED_AT | TIMESTAMP | When computed |

#### `RESULTS.PHASE3_FUZZY_MATCHES`
| Column | Type | Description |
|--------|------|-------------|
| FUZZY_MATCH_ID | VARCHAR(50) PK | UUID |
| PERIOD | DATE | Period |
| PAIR_ID | VARCHAR(50) | Pair |
| LINE_A_ID | VARCHAR(50) | FK to IC_LINES (Side A) |
| LINE_B_ID | VARCHAR(50) | FK to IC_LINES (Side B) |
| COSINE_SIMILARITY | NUMBER(5,4) | Vector similarity score |
| AMOUNT_PROXIMITY | NUMBER(5,4) | 1 - (amount difference / max amount) |
| DATE_PROXIMITY | NUMBER(5,4) | 1 - (day difference / 30) |
| AI_CONFIDENCE | NUMBER(5,4) | Weighted: 50% cosine + 30% amount + 20% date |
| AI_REASONING | VARCHAR(2000) | Score breakdown text |
| EMBEDDING_MODEL | VARCHAR(50) | `snowflake-arctic-embed-l-v2.0` |
| COMPUTED_AT | TIMESTAMP | When computed |

#### `RESULTS.PHASE4_AI_CLASSIFICATIONS`
| Column | Type | Description |
|--------|------|-------------|
| CLASSIFICATION_ID | VARCHAR(50) PK | UUID |
| PERIOD | DATE | Period |
| PAIR_ID | VARCHAR(50) | Pair |
| OS_ACCOUNT | VARCHAR(20) | OneStream account |
| CATEGORY | VARCHAR(50) | Category |
| DOC_CURRENCY | VARCHAR(3) | Currency |
| VARIANCE_AMOUNT | NUMBER(20,2) | Variance in doc currency |
| VARIANCE_AMOUNT_JPY | NUMBER(20,2) | Variance in JPY |
| UNMATCHED_LINE_IDS_A | ARRAY | Line IDs on Side A |
| UNMATCHED_LINE_IDS_B | ARRAY | Line IDs on Side B |
| ROOT_CAUSE_CATEGORY | VARCHAR(50) | AI classification (see below) |
| AI_CONFIDENCE | NUMBER(5,4) | LLM confidence |
| AI_REASONING | VARCHAR(5000) | LLM explanation |
| SUGGESTED_ACTION | VARCHAR(20) | `PROPOSE_JE` / `INVESTIGATE` / `IGNORE` / `ESCALATE` |
| PROPOSED_JOURNAL | VARIANT | Full journal entry (JSON) |
| SIMILAR_ISSUE_IDS | ARRAY | References to known issues |
| LLM_MODEL | VARCHAR(100) | `claude-3-5-sonnet` |
| LLM_PROMPT_VERSION | VARCHAR(20) | `v1.0` |
| COMPUTED_AT | TIMESTAMP | When computed |

**Root Cause Categories:**
- `MISSING_BOOKING` — One side hasn't recorded the transaction
- `FOREX_DIFFERENCE` — Exchange rate variance
- `TIMING_DIFFERENCE` — Cut-off / period mismatch
- `RECLASSIFICATION` — Booked to different account
- `DATA_ENTRY_ERROR` — Typo or wrong amount
- `OTHER` — Doesn't fit standard categories

---

### HITL Schema — Approval Queues

#### `HITL.REVIEW_QUEUE` (167 rows)
For partial matches from Phase 2 and medium-confidence matches from Phase 3.

| Column | Type | Description |
|--------|------|-------------|
| QUEUE_ID | VARCHAR(50) PK | UUID |
| PAIR_ID | VARCHAR(50) | Pair |
| PERIOD | DATE | Period |
| LINE_A_ID | VARCHAR(50) | Side A line |
| LINE_B_ID | VARCHAR(50) | Side B line |
| PHASE | VARCHAR(10) | `PHASE2` or `PHASE3` |
| CONFIDENCE | NUMBER(5,4) | Match confidence |
| FAILED_CRITERIA | VARCHAR(500) | What didn't match (Phase 2) |
| AI_REASONING | VARCHAR(2000) | Why it needs review |
| QUEUE_STATUS | VARCHAR(20) | `PENDING` / `APPROVED` / `REJECTED` |
| QUEUED_AT | TIMESTAMP | When queued |
| REVIEWER | VARCHAR(100) | Who reviewed |
| REVIEWED_AT | TIMESTAMP | When reviewed |
| REVIEWER_DECISION | VARCHAR(20) | Decision |
| REVIEWER_NOTES | VARCHAR(1000) | Notes |

#### `HITL.FUZZY_APPROVAL_QUEUE`
For high-confidence fuzzy matches (≥0.80) that need human sign-off.

| Column | Type | Description |
|--------|------|-------------|
| QUEUE_ID | VARCHAR(50) PK | UUID |
| PAIR_ID | VARCHAR(50) | Pair |
| PERIOD | DATE | Period |
| LINE_A_ID / LINE_B_ID | VARCHAR(50) | Matched lines |
| COSINE_SIMILARITY | NUMBER(5,4) | Embedding similarity |
| AMOUNT_PROXIMITY | NUMBER(5,4) | Amount closeness |
| DATE_PROXIMITY | NUMBER(5,4) | Date closeness |
| AI_CONFIDENCE | NUMBER(5,4) | Overall score |
| AI_REASONING | VARCHAR(2000) | Score explanation |
| EMBEDDING_MODEL | VARCHAR(50) | Model used |
| QUEUE_STATUS | VARCHAR(20) | `PENDING` / `APPROVED` / `REJECTED` |
| REVIEWER / REVIEWED_AT / REVIEWER_DECISION / REVIEWER_NOTES | — | Audit fields |

#### `HITL.CLASSIFICATION_APPROVAL_QUEUE`
For AI-generated root cause classifications and proposed journal entries.

| Column | Type | Description |
|--------|------|-------------|
| QUEUE_ID | VARCHAR(50) PK | UUID |
| PAIR_ID | VARCHAR(50) | Pair |
| PERIOD | DATE | Period |
| OS_ACCOUNT | VARCHAR(20) | OneStream account |
| CATEGORY | VARCHAR(50) | Category |
| DOC_CURRENCY | VARCHAR(3) | Currency |
| VARIANCE_AMOUNT | NUMBER(20,2) | Variance |
| VARIANCE_AMOUNT_JPY | NUMBER(20,2) | Variance in JPY |
| ROOT_CAUSE_CATEGORY | VARCHAR(50) | AI classification |
| AI_CONFIDENCE | NUMBER(5,4) | Confidence |
| AI_REASONING | VARCHAR(5000) | Explanation |
| SUGGESTED_ACTION | VARCHAR(20) | Proposed action |
| PROPOSED_JOURNAL | VARIANT | AI-generated JE (JSON) |
| LLM_MODEL | VARCHAR(100) | Model used |
| QUEUE_STATUS | VARCHAR(20) | `PENDING` / `APPROVED` / `REJECTED` |
| REVIEWER | VARCHAR(100) | Who reviewed |
| REVIEWER_DECISION | VARCHAR(20) | Decision |
| REVIEWER_EDITED_JOURNAL | VARIANT | Manually corrected JE (if edited) |
| REVIEWER_NOTES | VARCHAR(2000) | Notes |
| EXPORTED_TO_ERP | BOOLEAN | Whether posted to SAP |
| ERP_REFERENCE | VARCHAR(100) | SAP document reference |

#### `HITL.ESCALATION_QUEUE`
For items requiring senior controller attention (manual routing or AI-suggested escalation).

---

### TRAINING Schema

#### `TRAINING.PHASE4_FEW_SHOT_EXAMPLES`
Few-shot examples provided to the LLM in Phase 4 to improve classification accuracy. Contains historical variance descriptions, root cause categories, proposed journal JSON, and remarks — filtered by pair.

---

### REGRESSION Schema

#### `REGRESSION.PAIR_RESIDUAL_TARGETS`
Expected residual variance per pair/period. Used to validate that the pipeline is performing within acceptable bounds (±5% of target).

#### `REGRESSION.COMPILATION_TARGETS`
Compilation-level expected outputs for regression testing.

#### `REGRESSION.REGRESSION_RUNS`
History of regression validation runs with detailed comparison results (JSON in DETAIL column).

---

## Pipeline Phases

### Phase 1 — GL Balance Reconciliation

**Procedure:** `RESULTS.SP_RUN_PHASE1(P_PERIOD DATE)`  
**Input:** `STAGING.GL_BALANCES`  
**Output:** `RESULTS.PHASE1_BALANCE_RECON`

**Logic:**
1. For each bilateral pair in `GL_BALANCES` for the given period:
   - Sum JPY amounts for Side A (entity matching first part of PAIR_ID)
   - Sum JPY amounts for Side B (entity matching second part of PAIR_ID)
2. Compute net variance = Side A + Side B
3. Classify:
   - `GL_BALANCED` — |variance| < ¥1 (confidence: 1.0)
   - `GL_NEAR_BALANCED` — |variance| / max(|A|, |B|) < 0.001 (confidence: 0.9)
   - `GL_VARIANCE` — all others (confidence: 0.0)

**Note:** Phase 1 is informational only — it does not block subsequent phases. Phase 2 runs on ALL pairs regardless of Phase 1 status.

---

### Phase 2 — Deterministic Line-Level Matching

**Procedure:** `RESULTS.SP_RUN_PHASE2_TRADE(P_PERIOD DATE, P_PAIR_ID VARCHAR, P_OS_ACCOUNT VARCHAR)`  
**Input:** `STAGING.IC_LINES` (unmatched lines)  
**Output:** `RESULTS.PHASE2_LINE_MATCHES`, updates `IC_LINES.PHASE2_MATCH_ID`

**Matching Logic:**

Lines from Side A are joined to Side B using an OR condition:
- Same document number (leading zeros stripped), OR
- Same currency AND amount match (±¥0.01) AND date within 30 days

**Scoring Weights:**

| Criterion | Weight | Condition |
|-----------|--------|-----------|
| ICP Match | 30% | Counterparty codes cross-reference |
| Invoice Match | 20% | `DOC_NUMBER` equality (stripped leading zeros) |
| Currency Match | 20% | Same `DOC_CURRENCY` |
| Amount Match | 20% | |abs(A) - abs(B)| < 0.01 |
| Doc Date Match | 5% | Within 5 calendar days |
| Posting Month Match | 5% | Same YYYY-MM |

**Deduplication:** Each Side A line is matched to its single best Side B candidate (highest confidence, using ROW_NUMBER).

**Status Assignment:**
- `PERFECT` (confidence = 1.0) — fully matched, no further action
- `REVIEW` (confidence ≥ 0.5) — routed to `HITL.REVIEW_QUEUE`
- `PHASE3` (confidence < 0.5) — passed to Phase 3

---

### Phase 3 — Cortex Fuzzy Matching (Vector Embeddings)

**Procedure:** `RESULTS.SP_RUN_PHASE3(P_PERIOD DATE, P_PAIR_ID VARCHAR)`  
**Input:** Unmatched lines (PHASE2_MATCH_ID IS NULL)  
**Output:** `RESULTS.PHASE3_FUZZY_MATCHES`

**Steps:**

1. **Build embedding text** for each unmatched line:
   ```
   COUNTERPARTY_CODE | DOC_NUMBER | DOC_CURRENCY | ROUND(ABS(DOC_AMOUNT)) | POSTING_MONTH | SAP_ACCOUNT_DESCRIPTION | FREE_TEXT[0:200]
   ```

2. **Generate embeddings** using Snowflake Cortex:
   ```sql
   SNOWFLAKE.CORTEX.EMBED_TEXT_1024('snowflake-arctic-embed-l-v2.0', EMBEDDING_TEXT)
   ```
   Stored as `VECTOR(FLOAT, 1024)` on `IC_LINES.EMBEDDING_VECTOR`.

3. **Cross-join** Side A vectors against Side B vectors and compute:
   - `COSINE_SIMILARITY` = `VECTOR_COSINE_SIMILARITY(a.EMBEDDING_VECTOR, b.EMBEDDING_VECTOR)`
   - `AMOUNT_PROXIMITY` = 1 - min(1, |abs(A) - abs(B)| / max(|A|, |B|, 1))
   - `DATE_PROXIMITY` = 1 - min(1, |DATEDIFF(day, A, B)| / 30)

4. **Rank** by cosine similarity, take best match per Side A line.

5. **Final confidence** = 50% cosine + 30% amount proximity + 20% date proximity

**Routing:**
- Confidence ≥ 0.80 → `HITL.FUZZY_APPROVAL_QUEUE` (high confidence, needs sign-off)
- 0.60 ≤ confidence < 0.80 → `HITL.REVIEW_QUEUE` (needs investigation)
- < 0.60 → remains unmatched, proceeds to Phase 4

---

### Phase 4 — AI Root Cause Classification & Journal Proposal

**Procedure:** `RESULTS.SP_RUN_PHASE4(P_PERIOD DATE, P_PAIR_ID VARCHAR, P_OS_ACCOUNT VARCHAR)`  
**Language:** Python (Snowpark)  
**Input:** Pairs with `GL_VARIANCE` status AND remaining unmatched lines  
**Output:** `RESULTS.PHASE4_AI_CLASSIFICATIONS`, `HITL.CLASSIFICATION_APPROVAL_QUEUE`

**Steps:**

1. Fetch variance details from `PHASE1_BALANCE_RECON`
2. Fetch up to 30 unmatched lines from each side
3. Retrieve known recurring issues from `REF.REF_KNOWN_ISSUES`
4. Retrieve few-shot examples from `TRAINING.PHASE4_FEW_SHOT_EXAMPLES`
5. Look up plug accounts from `REF.REF_ENTITY_GL_ACCOUNTS`
6. Construct structured prompt with all context
7. Call `SNOWFLAKE.CORTEX.COMPLETE('claude-3-5-sonnet', prompt)`
8. Parse JSON response
9. Persist classification to `PHASE4_AI_CLASSIFICATIONS`
10. Queue for human approval in `CLASSIFICATION_APPROVAL_QUEUE`

**LLM Output Schema:**
```json
{
  "root_cause_category": "MISSING_BOOKING|FOREX_DIFFERENCE|TIMING_DIFFERENCE|RECLASSIFICATION|DATA_ENTRY_ERROR|OTHER",
  "confidence": 0.0,
  "reasoning": "...",
  "suggested_action": "PROPOSE_JE|INVESTIGATE|IGNORE|ESCALATE",
  "proposed_journal": {
    "booking_entity": "...",
    "lines": [{ "dr_or_cr": "DR|CR", "sap_account": "...", "description": "...", "amount": 0, "currency": "..." }],
    "narrative": "..."
  },
  "similar_issue_id": null
}
```

---

## Human-in-the-Loop (HITL) Queues

### Queue Workflow

```
PENDING → [Reviewer opens in Streamlit UI] → APPROVED / REJECTED
                                                    │
                                             (if approved)
                                                    ▼
                                          EXPORTED_TO_ERP = TRUE
                                          ERP_REFERENCE = "SAP Doc #"
```

### Queue Summary

| Queue | Source | Criteria | Reviewer Action |
|-------|--------|----------|-----------------|
| Review Queue | Phase 2 partial matches, Phase 3 medium confidence | 0.50–0.99 confidence (Phase 2) or 0.60–0.80 (Phase 3) | Accept/reject proposed line match |
| Fuzzy Approval Queue | Phase 3 high confidence | ≥ 0.80 AI confidence | Approve/reject AI fuzzy match |
| Classification Approval Queue | Phase 4 | All AI classifications | Approve classification, edit journal entry, export to ERP |
| Escalation Queue | Manual / Phase 4 | `ESCALATE` action | Senior controller investigation |

### Audit Trail Fields (all queues)
- `QUEUED_AT` — when item entered queue
- `REVIEWER` — who handled it
- `REVIEWED_AT` — when decision was made
- `REVIEWER_DECISION` — `APPROVED` / `REJECTED`
- `REVIEWER_NOTES` — free text

---

## Views

### `RESULTS.V_PAIR_RECONCILIATION`
**Comprehensive per-pair reconciliation summary.** Joins Phase 1, Phase 2, unmatched lines, and Phase 4 journal proposals into a single row per pair/period.

Key columns: GL detail (array of account-level results), line match counts (perfect/review/phase3), unmatched detail (array), proposed journal entries (array with confidence, reasoning, amounts).

### `RESULTS.V_PHASE1_OS_BALANCE_RECON`
Phase 1 results enriched with regression targets. Adds `REGRESSION_TARGET_JPY` and `REGRESSION_STATUS` (`WITHIN_TARGET` / `OUT_OF_TARGET`) based on ±5% tolerance.

### `RESULTS.V_PHASE2_LINE_MATCHES_DETAIL`
Phase 2 matches joined back to `IC_LINES` to show entity codes, document numbers, amounts, and dates for both sides of each match.

### `RESULTS.V_MIS_VS_MIS`
GL variance by pair with adjustments applied. Shows raw MIS variance (from `GL_BALANCES`), known adjustments (from `REF.PAIR_ADJUSTMENTS`), and net total. Ordered by absolute variance descending.

### `RESULTS.V_ENTRY_SUMMARY`
Direct passthrough of `STAGING.ENTRY_SUMMARY` ordered by pair group and SAP code. Shows the SAP-to-HFM mapping with amounts in local currency and JPY.

---

## Validation & Regression

### `PUBLIC.SP_RUN_VALIDATION_SUITE(P_PERIOD DATE)`
Returns a table of quality gates. Current gates:

| Gate | Validation |
|------|-----------|
| G1 | GL accounts loaded ≥ 98 in `REF_ENTITY_GL_ACCOUNTS` |
| G2 | ECN-EJP USD Trade pair is `GL_BALANCED` for account `1122100100` |
| G3 | ECN-EJP has ≥ 100 matched lines in Phase 2 |
| G14 | Phase 2 ran on `GL_BALANCED` pairs (Samantha gate) |

### `REGRESSION.SP_VALIDATE_REGRESSION(P_PERIOD DATE)`
Compares pipeline output against `PAIR_RESIDUAL_TARGETS`:
- For each pair with a target, checks if the pipeline's residual variance is within ±5% of the target
- Records results in `REGRESSION_RUNS` with full JSON detail (per-pair comparison)

---

## Streamlit Application Pages

### App Entry Point (`app.py`)
Main navigation and session initialization. Establishes Snowpark connection.

### Pages

| # | Page | Description |
|---|------|-------------|
| 0 | **Dashboard** | High-level reconciliation status overview — pair counts, variance totals, phase progress |
| 1 | **GL Level Matching** | Phase 1 balance reconciliation results; shows variance by pair and OneStream account |
| 2 | **Invoice Level Matching** | Phase 2 deterministic match results; confidence scores, failed criteria |
| 3 | **Review Queue** | HITL interface for reviewing partial/medium-confidence matches |
| 4 | **Fuzzy Approval Queue** | HITL interface for approving/rejecting Phase 3 fuzzy matches |
| 5 | **Classification Approval Queue** | HITL interface for AI root-cause classifications; edit journal entries before ERP export |
| 6 | **Entry Summary** | Aggregated entry-level summary with SAP/HFM code mapping |
| 7 | **Pair Reconciliation** | Comprehensive per-pair view (uses `V_PAIR_RECONCILIATION`) |

### Utilities

| Module | Purpose |
|--------|---------|
| `utils/snowpark_client.py` | Snowpark session management |
| `utils/period_picker.py` | Period selection widget |
| `utils/audit.py` | Audit trail logging |
| `utils/excel_export.py` | Excel file export for download |
| `utils/styling.py` | Evident branding / CSS |

### Dependencies (`environment.yml`)
- `snowflake-snowpark-python`
- `openpyxl` (Excel export)
- `pandas` (data manipulation)

---

## Data Flow Diagram

```
┌──────────────────────────────────────────────────────────────────────┐
│                        DATA INGESTION                                 │
│                                                                       │
│   Excel/CSV Files → SP_RAW_TO_STAGING → STAGING.IC_LINES            │
│                                        → STAGING.GL_BALANCES          │
└──────────────────────────────────────┬───────────────────────────────┘
                                       │
                                       ▼
┌──────────────────────────────────────────────────────────────────────┐
│                   SP_RUN_PIPELINE_END_TO_END(PERIOD)                  │
│                                                                       │
│  ┌────────────────────────────────────────────────────────────────┐  │
│  │ PHASE 1: GL Balance Check                                      │  │
│  │   Input:  GL_BALANCES                                          │  │
│  │   Output: PHASE1_BALANCE_RECON                                 │  │
│  │   Status: GL_BALANCED | GL_NEAR_BALANCED | GL_VARIANCE         │  │
│  └────────────────────────────────────────────────────────────────┘  │
│                              │                                        │
│                              ▼                                        │
│  ┌────────────────────────────────────────────────────────────────┐  │
│  │ PHASE 2: Deterministic Line Matching (per pair)                │  │
│  │   Input:  IC_LINES (all unmatched)                             │  │
│  │   Logic:  Weighted score (ICP 30%, Invoice 20%, Currency 20%,  │  │
│  │           Amount 20%, Date 5%, Month 5%)                       │  │
│  │   Output: PHASE2_LINE_MATCHES                                  │  │
│  │   Status: PERFECT | REVIEW → HITL | PHASE3                    │  │
│  └────────────────────────────────────────────────────────────────┘  │
│                              │                                        │
│                              ▼                                        │
│  ┌────────────────────────────────────────────────────────────────┐  │
│  │ PHASE 3: Cortex Fuzzy Matching (per pair with unmatched)       │  │
│  │   Input:  IC_LINES where PHASE2_MATCH_ID IS NULL               │  │
│  │   AI:     snowflake-arctic-embed-l-v2.0 (1024-dim vectors)     │  │
│  │   Score:  50% cosine + 30% amount proximity + 20% date prox   │  │
│  │   Output: PHASE3_FUZZY_MATCHES                                 │  │
│  │   Route:  ≥0.80 → FUZZY_QUEUE | 0.60-0.80 → REVIEW_QUEUE     │  │
│  └────────────────────────────────────────────────────────────────┘  │
│                              │                                        │
│                              ▼                                        │
│  ┌────────────────────────────────────────────────────────────────┐  │
│  │ PHASE 4: AI Classification (residuals only)                    │  │
│  │   Input:  GL_VARIANCE pairs + remaining unmatched lines        │  │
│  │   AI:     claude-3-5-sonnet (via CORTEX.COMPLETE)              │  │
│  │   Context: known issues, few-shot examples, plug accounts      │  │
│  │   Output: PHASE4_AI_CLASSIFICATIONS                            │  │
│  │   Route:  → CLASSIFICATION_APPROVAL_QUEUE                      │  │
│  └────────────────────────────────────────────────────────────────┘  │
│                              │                                        │
│                              ▼                                        │
│  ┌────────────────────────────────────────────────────────────────┐  │
│  │ VALIDATION: SP_VALIDATE_REGRESSION                             │  │
│  │   Compares results against PAIR_RESIDUAL_TARGETS (±5%)         │  │
│  └────────────────────────────────────────────────────────────────┘  │
└──────────────────────────────────────────────────────────────────────┘
                                       │
                                       ▼
┌──────────────────────────────────────────────────────────────────────┐
│                     HUMAN REVIEW (Streamlit UI)                       │
│                                                                       │
│   Review Queue ─────────────→ Approve/Reject matches                 │
│   Fuzzy Approval Queue ─────→ Approve/Reject AI matches              │
│   Classification Queue ─────→ Approve/Edit journal → ERP Export      │
│   Escalation Queue ─────────→ Senior controller investigation        │
└──────────────────────────────────────────────────────────────────────┘
```

---

## AI/ML Components

| Component | Model | Purpose | Location |
|-----------|-------|---------|----------|
| Vector Embeddings | `snowflake-arctic-embed-l-v2.0` | Semantic similarity for fuzzy matching | Phase 3 |
| LLM Classification | `claude-3-5-sonnet` | Root cause analysis + journal entry proposal | Phase 4 |
| Vector Search | `VECTOR_COSINE_SIMILARITY` | Find most similar line between sides | Phase 3 |

### Embedding Strategy (Phase 3)
- Concatenates structured fields into a single text representation
- Generates 1024-dimensional float vectors
- Stored directly on `IC_LINES.EMBEDDING_VECTOR` for reuse
- Only computed once (skips if already populated)

### LLM Prompt Design (Phase 4)
- **Persona:** Senior intercompany controller
- **Context provided:** Variance details, up to 10 unmatched lines per side, known issues, few-shot examples, plug accounts
- **Output:** Structured JSON with root cause, confidence, reasoning, suggested action, and proposed journal entry
- **Fallback:** If JSON parsing fails, defaults to `OTHER` / `INVESTIGATE` with low confidence
- **Version tracked:** `LLM_PROMPT_VERSION` field for reproducibility

---

## Data Volumes

| Object | Row Count | Notes |
|--------|-----------|-------|
| `STAGING.IC_LINES` | 7,234 | Clustered by (PERIOD, PAIR_ID, ONESTREAM_ACCOUNT) |
| `STAGING.GL_BALANCES` | 207 | Aggregated GL balances per entity/pair/account |
| `STAGING.JOURNAL_ADJUSTMENTS` | 30 | Pre-approved adjustments |
| `STAGING.ENTRY_SUMMARY` | 19 | Summary entries |
| `RESULTS.PHASE1_BALANCE_RECON` | 35 | One row per pair-account combination |
| `RESULTS.PHASE2_LINE_MATCHES` | 167 | Deterministic matches |
| `RESULTS.PHASE3_FUZZY_MATCHES` | 0 | (awaiting pipeline run) |
| `RESULTS.PHASE4_AI_CLASSIFICATIONS` | 0 | (awaiting pipeline run) |
| `HITL.REVIEW_QUEUE` | 167 | Pending review |
| `HITL.FUZZY_APPROVAL_QUEUE` | 0 | (awaiting pipeline run) |
| `HITL.CLASSIFICATION_APPROVAL_QUEUE` | 0 | (awaiting pipeline run) |
| `REF.REF_ENTITIES` | 9 | Legal entities |
| `REF.REF_BILATERAL_PAIRS` | 17 | Active pairs |
| `REF.REF_ENTITY_GL_ACCOUNTS` | 180 | Account mappings |
| `REF.FX_RATES` | 16 | Exchange rates |
| `REF.PAIR_ADJUSTMENTS` | 35 | Known adjustments |

---

## Running the Pipeline

### Full End-to-End
```sql
CALL INTERCO_RECON.PUBLIC.SP_RUN_PIPELINE_END_TO_END('2025-03-31'::DATE);
```

### Individual Phases
```sql
-- Phase 1 only
CALL INTERCO_RECON.RESULTS.SP_RUN_PHASE1('2025-03-31'::DATE);

-- Phase 2 for a specific pair
CALL INTERCO_RECON.RESULTS.SP_RUN_PHASE2_TRADE('2025-03-31'::DATE, 'ECN-EJP', NULL);

-- Phase 3 for a specific pair
CALL INTERCO_RECON.RESULTS.SP_RUN_PHASE3('2025-03-31'::DATE, 'ECN-EJP');

-- Phase 4 for a specific pair/account
CALL INTERCO_RECON.RESULTS.SP_RUN_PHASE4('2025-03-31'::DATE, 'ECN-EJP', '1122100100');
```

### Validation
```sql
-- Quality gates
CALL INTERCO_RECON.PUBLIC.SP_RUN_VALIDATION_SUITE('2025-03-31'::DATE);

-- Regression check
CALL INTERCO_RECON.REGRESSION.SP_VALIDATE_REGRESSION('2025-03-31'::DATE);
```

### File Ingestion
```sql
CALL INTERCO_RECON.STAGING.SP_RAW_TO_STAGING('<file_id>');
```

---

*Document generated from live system metadata on 2026-05-18.*
