# Evident MIS Intercompany Reconciliation
## Snowflake Cortex AI — Engineering Specification

**Version:** 2.1 (consolidated specification)
**Pilot scope:** MIS business unit, March 2026 close, expanding to all MIS reconciliations
**Target platform:** Snowflake with Cortex AI (Cortex Complete, Cortex Embed, Vector Search), Streamlit-in-Snowflake for HITL UI
**Validation oracle:** EJP-ECN Trade pair must reproduce 428 reconciled invoices (163 USD balance match + 246 CNY perfect + 19 CNY review) with CNY 5.4M variance correctly identified

---

## Table of Contents

1. Executive Summary
2. Business Logic Foundation
3. Solution Architecture
4. Database, Schema, and Role Layout
5. Reference Data Tables
6. Master Data Tables
7. Source Data Extraction (Entity Adapter Layer)
8. Landing and Staging Tables
9. Ingestion Pipeline
10. Phase 1 — GL Balance Reconciliation
11. Phase 2 — Deterministic Line-Level Drill-Down
12. Phase 3 — Cortex Fuzzy Matching
13. Phase 4 — Cortex AI-Assisted Classification
14. HITL Workflow (Three-Queue Model)
15. Output Reports
16. Validation, Testing, and Acceptance Criteria
17. Operational Considerations
18. Open Questions Pending Lloyd's Input
19. Implementation Roadmap

---

## 1. Executive Summary

### 1.1 Goal

Replace the manual monthly intercompany reconciliation process for Evident's MIS business unit with an automated Snowflake-based pipeline that:

- Ingests intercompany line-item data from each entity's ERP extract (heterogeneous formats: SAP-Japan, SAP-China, SAP-Europe, NetSuite-USA, native country SAPs)
- Categorizes every line by GL account into Trade / Non-Trade / Accrued Interest / Loan / Transfer Pricing
- Reconciles balances bilaterally per pair-category-currency (Phase 1 — primary process per Evident's documented 7-step Non-Trade and 10-step Trade procedures)
- Drills into invoice-level matching only when balances don't reconcile (Phase 2)
- Uses Cortex AI (embeddings + LLM) only for items the rule-based engine can't resolve (Phase 3 — fuzzy matching for cross-system identifier mismatches; Phase 4 — root-cause classification for residuals)
- Routes outputs to a three-queue HITL workflow (Confirmation, Review, Escalation) in a Streamlit-in-Snowflake UI

### 1.2 Why This Architecture

The documented matching processes (from Evident's Process tab) are explicit gating logic: Step 2 says "if total balance by document currency agrees, no further action required." Most reconciliations resolve at the balance level. AI/fuzzy matching only earns its keep on the residual — the items the deterministic engine can't reconcile. This minimizes Cortex compute spend, maximizes auditability (rule-based confidence is a closed-form arithmetic, not a black-box score), and produces outputs in the exact shape Evident's controllers already expect.

### 1.3 Validation Target (must reproduce on every regression run)

```
Pair: EJP ↔ ECN, Trade, March 2026
Phase 1 Balance Reconciliation:
  USD: variance = 0 → balance match (163 lines covered)
  CNY: variance = -CNY 5,428,108.50 → drill-down triggered
Phase 2 Drill-down (CNY only):
  Invoices matched at confidence 1.00:        246
  Invoices matched at confidence 0.80-0.95:    19
  ECN one-sided invoices (residual):           72  → CNY 5.4M variance
EJP-side lines deterministically reconciled: 428  (163 USD + 246 CNY + 19 CNY)
```

If a code change causes any of these numbers to drift, the test gate fails.

---

## 2. Business Logic Foundation

### 2.1 The Two-Phase Matching Process

Per the documented Process tab in `Interco_Process_Automation`, intercompany matching follows this sequence:

```
For each (entity_A, entity_B, GL category, document currency) combination:

  PHASE 1 — Balance reconciliation (steps 1-2 of documented process):
    1. Verify ICP code on both sides references the correct counterparty
    2. Sum doc-currency amounts on each side (with sign convention preserved)
    3. Check |sum_A + sum_B| < tolerance
    
    If matched → CONFIRMATION QUEUE (confidence 1.00, reviewer signs off in bulk)
    If variance → proceed to Phase 2

  PHASE 2 — Line-level drill-down (steps 3-10 of documented process):
    3. Locate GL lines with OPEN status
    4. Verify sum of OPEN lines = total entity balance (sanity check)
    5+. Apply Trade or Non-Trade matching procedure (see 2.2 and 2.3)
    
    Each candidate match scored on documented confidence formula
    confidence = 1.00 → CONFIRMATION QUEUE
    confidence 0.50-0.99 → REVIEW QUEUE
    confidence < 0.50 or no candidate → PHASE 3 (fuzzy matching)

  PHASE 3 — Cortex fuzzy matching:
    Embed each unmatched line (description + reference + amount + currency)
    Vector similarity search against opposite side's unmatched pool
    Top-K candidates with similarity > 0.80 → REVIEW QUEUE with AI confidence score
    Below threshold → proceed to Phase 4

  PHASE 4 — Cortex AI-assisted classification:
    For each remaining unmatched line, run Cortex Complete prompt:
      "Given this orphan IC entry and the variance pattern,
       classify the root cause and propose a journal entry."
    Output → ESCALATION QUEUE with proposed journal
```

### 2.2 Trade Matching — 10-Step Process (documented)

Triggered when a line's GL account category = `Trade`. Steps 1-4 are the Phase 1 gate; steps 5-10 are Phase 2 drill-down.

| Step | Action | Pipeline phase |
|------|--------|----------------|
| 1 | Match ICP account code | Phase 1 |
| 2 | Match total balance by document currency (if matched, done) | Phase 1 |
| 3 | Locate GL lines with OPEN status | Phase 2 |
| 4 | Verify sum of OPEN lines = total entity balance | Phase 2 |
| 5 | Match invoice number | Phase 2 |
| 6 | Match document currency | Phase 2 |
| 7 | Match document currency amount | Phase 2 |
| 8 | Output: unmatched invoices | Phase 2 |
| 9 | Output: invoice match but currency/amount mismatch | Phase 2 |
| 10 | Output: matched invoices, bucketed by posting date alignment | Phase 2 |

**Confidence formula (closed-form, sums to 1.00):**

```
trade_confidence =
    icp_match × 0.30                    // Step 1
  + invoice_number_match × 0.20         // Step 5
  + doc_currency_match × 0.20           // Step 6
  + doc_currency_amount_match × 0.20    // Step 7
  + doc_date_match × 0.05
  + posting_month_match × 0.05
```

### 2.3 Non-Trade Matching — 7-Step Process (documented)

Triggered when a line's GL account category is `Non-trade`, `Accrued interest`, `Loan`, or `Transfer pricing` (TP routing TBC with Lloyd).

| Step | Action | Pipeline phase |
|------|--------|----------------|
| 1 | Match ICP account code | Phase 1 |
| 2 | Match total balance by document currency (if matched, done) | Phase 1 |
| 3 | Locate GL lines with OPEN status | Phase 2 |
| 4 | Verify sum of OPEN lines = total entity balance | Phase 2 |
| 5 | Match OPEN lines on (same posting month + amount + currency) | Phase 2 |
| 6 | For unmatched, search 1 month forward (look-ahead) | Phase 2 |
| 7 | Output: unmatched lines | Phase 2 |

**Confidence formula (closed-form, sums to 1.00):**

```
non_trade_confidence =
    icp_match × 0.30                    // Step 1
  + same_month_match × 0.05             // Step 5 criterion 1
  + doc_currency_match × 0.10           // Step 5 criterion 2
  + doc_amount_match × 0.50             // Step 5 criterion 3 ← dominant
  + within_2_month_match × 0.05         // Step 6
```

The amount weight (0.50) is dominant for Non-Trade because there are no invoice numbers to anchor on (loans, accruals, interest don't have invoices). Currency match has lower weight (0.10) than for Trade because the dominant non-trade flows are typically denominated in the parent's currency anyway.

### 2.4 Confidence Threshold & HITL Routing

Per the documented truth table:

| Confidence | Action |
|------------|--------|
| Exactly 1.00 | Confirmation Queue (one-click bulk confirm) |
| 0.80 ≤ x < 1.00 | Review Queue (full HITL review) |
| 0.50 ≤ x < 0.80 | Review Queue, explicit reviewer attention |
| < 0.50 | Escalation Queue (Cortex proposes journal action) |

### 2.5 GL Account Categorization

Each entity has a list of relevant SAP GL accounts per category, sourced from the Entity Accounts table. **Categorization happens at ingestion** — every line is tagged with its category based on `(entity_code, gl_account)` lookup. Lines whose GL accounts aren't in the reference table are tagged `UNMAPPED` and routed to a data-quality review queue.

### 2.6 MIS Scope Filtering

Each entity's data includes both TNM and MIS rows. MIS filtering happens **at ingestion** based on the Profit Center field. Each entity has a defined list of MIS-tagged profit centers (TBC with Lloyd per entity). Non-MIS lines are dropped before matching.

### 2.7 OPEN Status (TBC with Lloyd)

The Process tab references "OPEN status" GL lines (Step 3). This is currently treated as a TRUE flag for all extracted lines (period-end opens). Two interpretations need clarification:

- **Interpretation A:** Source ERP open-item flag (SAP `BSEG.AUGBL` empty or NetSuite "Open Balance" > 0). Pipeline reads this flag from the raw extract.
- **Interpretation B:** PIC determines OPEN status during reconciliation. Pipeline computes it as "any line not yet cleared this period."

The schema supports both — `IS_OPEN` is a column in the staging table, populated either from the source system (Interpretation A) or computed (Interpretation B).

### 2.8 Currency Normalization

Document currency codes are normalized at ingestion:
- `RMB` → `CNY`
- `WON` → `KRW`
- All others kept as ISO 4217

### 2.9 Sign Convention

Document amounts are signed:
- Receivable (creditor side, AR) → positive
- Payable (debtor side, AP) → negative

Phase 1 balance match: `|sum_A + sum_B| < tolerance` (the two sides should sum to zero if they reconcile). Phase 2 invoice match: `(amount_A > 0) ≠ (amount_B > 0)` (signs must oppose).

---

## 3. Solution Architecture

### 3.1 High-Level Dataflow

```
┌─────────────────────────────────────────────────────────────────────────┐
│                                                                         │
│  ┌────────────┐   ┌────────────┐   ┌────────────┐   ┌────────────┐     │
│  │  EJP SAP   │   │  ECN SAP   │   │ EUSA NetS. │   │  ENF/EEU   │     │
│  │  extract   │   │  extract   │   │  aging rpt │   │  multi-tab │     │
│  └─────┬──────┘   └─────┬──────┘   └─────┬──────┘   └─────┬──────┘     │
│        │                │                │                │            │
│  ┌─────┴────────────────┴────────────────┴────────────────┴──────┐     │
│  │  ENTITY ADAPTER LAYER (Python — runs upstream of Snowflake)  │     │
│  │  Per-entity parsers convert heterogeneous Excel inputs to     │     │
│  │  standardized parquet/CSV files in the unified schema.        │     │
│  └─────────────────────────┬─────────────────────────────────────┘     │
│                            │                                            │
│  ╔═════════════════════════▼═══════════════════════════════════════╗   │
│  ║                    SNOWFLAKE                                    ║   │
│  ║                                                                 ║   │
│  ║  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐         ║   │
│  ║  │   LANDING    │→ │   STAGING    │→ │   PHASE 1    │         ║   │
│  ║  │ raw lines    │  │ standardized │  │ balance recon│         ║   │
│  ║  └──────────────┘  └──────────────┘  └──────┬───────┘         ║   │
│  ║         ▲                  ▲                 │                  ║   │
│  ║         │                  │           ┌─────┴─────────┐        ║   │
│  ║  ┌──────┴──────────────────┴─┐         │   variances?  │        ║   │
│  ║  │      REFERENCE DATA       │      ┌──┴───────┐  ┌────┴───┐   ║   │
│  ║  │ • REF_ENTITIES            │      │ matched  │  │drilldn │   ║   │
│  ║  │ • REF_ENTITY_GL_ACCOUNTS  │      │ Phase 1  │  │ Phase 2│   ║   │
│  ║  │ • REF_ENTITY_ADAPTERS     │      └────┬─────┘  └────┬───┘   ║   │
│  ║  │ • REF_MIS_PROFIT_CENTERS  │           │              │       ║   │
│  ║  │ • REF_FX_RATES            │           │       ┌──────┴─────┐ ║   │
│  ║  │ • REF_CONFIDENCE_WEIGHTS  │           │       │  PHASE 3   │ ║   │
│  ║  │ • REF_KNOWN_ISSUES        │           │       │  Cortex    │ ║   │
│  ║  │ • REF_CURRENCY_MAPPING    │           │       │  fuzzy     │ ║   │
│  ║  └───────────────────────────┘           │       └─────┬──────┘ ║   │
│  ║                                          │             │         ║   │
│  ║                                          │       ┌─────┴──────┐ ║   │
│  ║                                          │       │  PHASE 4   │ ║   │
│  ║                                          │       │  Cortex    │ ║   │
│  ║                                          │       │  classify  │ ║   │
│  ║                                          │       └─────┬──────┘ ║   │
│  ║                                          │             │         ║   │
│  ║                              ┌───────────┴───────────────┴─────┐ ║   │
│  ║                              │      HITL OUTPUT TABLES         │ ║   │
│  ║                              │ • RESULTS_CONFIRMATION_QUEUE    │ ║   │
│  ║                              │ • RESULTS_REVIEW_QUEUE          │ ║   │
│  ║                              │ • RESULTS_ESCALATION_QUEUE      │ ║   │
│  ║                              └───────────────┬─────────────────┘ ║   │
│  ╚════════════════════════════════════════════════╪═══════════════════╝   │
│                                                   │                       │
│                              ┌────────────────────▼─────────────────┐   │
│                              │ STREAMLIT-IN-SNOWFLAKE HITL UI       │   │
│                              │ • Confirmation tab (perfect matches) │   │
│                              │ • Review tab (low-conf, AI-assisted) │   │
│                              │ • Escalation tab (proposed journals) │   │
│                              │ • Audit trail + status board         │   │
│                              └──────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────────────────────┘
```

### 3.2 Cortex AI Footprint

| Phase | Cortex function | Purpose | Estimated volume per close |
|-------|-----------------|---------|----------------------------|
| 3 | `SNOWFLAKE.CORTEX.EMBED_TEXT_1024(model, text)` | Generate embedding vector for unmatched line description | ~500-2,000 rows |
| 3 | `VECTOR_COSINE_SIMILARITY(emb_a, emb_b)` | Find candidate matches across embedding pool | Pairwise on residual |
| 4 | `SNOWFLAKE.CORTEX.COMPLETE(model, prompt, params)` | Classify root cause, propose journal entry | ~50-200 rows |
| 4 | `SNOWFLAKE.CORTEX.CLASSIFY_TEXT(text, [...categories])` | Quick categorization of variance type | ~50-200 rows |

**Models specified:**
- Embeddings: `snowflake-arctic-embed-l-v2.0` (1024-dim, multilingual; handles Japanese/Chinese/Korean text natively)
- Completion: `claude-3-5-sonnet` for narrative reasoning (or Snowflake's hosted equivalent), with `mistral-large2` as fallback
- Classification: `mistral-large2` for structured output

### 3.3 Cortex Code Usage

Snowflake Cortex Code (the AI-assisted SQL/Python development environment) will be used during build:

- **Schema generation:** Cortex Code generates initial DDL from natural-language description, then engineer refines
- **Cortex prompt iteration:** Cortex Code helps tune Cortex Complete prompts against sample data
- **Streamlit UI scaffolding:** Cortex Code generates initial Streamlit-in-Snowflake page templates from sketches
- **Test case generation:** Cortex Code generates synthetic test data and validation assertions

This is a build-time accelerator, not a runtime component.

---

## 4. Database, Schema, and Role Layout

### 4.1 Database

```sql
CREATE DATABASE IF NOT EXISTS INTERCO_RECON
  COMMENT = 'Evident MIS Intercompany Reconciliation — Phase 1 Pilot';
USE DATABASE INTERCO_RECON;
```

### 4.2 Schemas

```sql
CREATE SCHEMA IF NOT EXISTS RAW       COMMENT = 'Landing zone for entity-extracted line items';
CREATE SCHEMA IF NOT EXISTS STAGING   COMMENT = 'Standardized + categorized line items';
CREATE SCHEMA IF NOT EXISTS REF       COMMENT = 'Reference & master data';
CREATE SCHEMA IF NOT EXISTS RESULTS   COMMENT = 'Phase 1-4 matching outputs';
CREATE SCHEMA IF NOT EXISTS HITL      COMMENT = 'HITL queues and reviewer actions';
CREATE SCHEMA IF NOT EXISTS REPORTS   COMMENT = 'Aggregated reports and views';
CREATE SCHEMA IF NOT EXISTS AUDIT     COMMENT = 'Lineage and audit log';
```

### 4.3 Roles

```sql
-- Service role (pipeline executes as this)
CREATE ROLE IF NOT EXISTS INTERCO_PIPELINE_SVC;
GRANT USAGE ON DATABASE INTERCO_RECON TO ROLE INTERCO_PIPELINE_SVC;
GRANT USAGE, CREATE TABLE, CREATE VIEW ON ALL SCHEMAS IN DATABASE INTERCO_RECON
  TO ROLE INTERCO_PIPELINE_SVC;
GRANT USAGE ON CORTEX TO ROLE INTERCO_PIPELINE_SVC;

-- HITL reviewer role (controllers/PICs)
CREATE ROLE IF NOT EXISTS INTERCO_REVIEWER;
GRANT USAGE ON DATABASE INTERCO_RECON TO ROLE INTERCO_REVIEWER;
GRANT USAGE ON SCHEMA RESULTS, HITL, REPORTS TO ROLE INTERCO_REVIEWER;
GRANT SELECT ON ALL TABLES IN SCHEMA RESULTS, REPORTS TO ROLE INTERCO_REVIEWER;
GRANT SELECT, INSERT, UPDATE ON ALL TABLES IN SCHEMA HITL TO ROLE INTERCO_REVIEWER;

-- Reader role (auditors, finance leadership)
CREATE ROLE IF NOT EXISTS INTERCO_READER;
GRANT USAGE ON DATABASE INTERCO_RECON TO ROLE INTERCO_READER;
GRANT USAGE ON SCHEMA RESULTS, REPORTS, AUDIT TO ROLE INTERCO_READER;
GRANT SELECT ON ALL TABLES IN SCHEMAS RESULTS, REPORTS, AUDIT TO ROLE INTERCO_READER;
```

### 4.4 Warehouses

```sql
CREATE WAREHOUSE IF NOT EXISTS INTERCO_INGEST_WH
  WAREHOUSE_SIZE = 'SMALL'
  AUTO_SUSPEND = 60
  COMMENT = 'Ingestion + Phase 1/2 deterministic SQL';

CREATE WAREHOUSE IF NOT EXISTS INTERCO_CORTEX_WH
  WAREHOUSE_SIZE = 'MEDIUM'
  AUTO_SUSPEND = 60
  COMMENT = 'Cortex AI workloads (Phase 3/4)';
```

---

## 5. Reference Data Tables

### 5.1 `REF.REF_ENTITIES` — Entity master

Catalog of all 17 MIS entities and their identifiers.

```sql
CREATE OR REPLACE TABLE REF.REF_ENTITIES (
    ENTITY_CODE         VARCHAR(15)  NOT NULL PRIMARY KEY,  -- 'EJP', 'ECN', 'EAS', etc.
    ENTITY_SAP_CODE     VARCHAR(10)  NOT NULL,              -- '1096', '5043', '6009', etc.
    ENTITY_NAME         VARCHAR(100) NOT NULL,              -- 'Evident Japan'
    ERP_SYSTEM          VARCHAR(20)  NOT NULL,              -- 'SAP', 'NetSuite', 'Other'
    LOCAL_CURRENCY      VARCHAR(3)   NOT NULL,              -- 'JPY', 'CNY', 'AUD', etc.
    REGION              VARCHAR(20),                        -- 'APAC', 'EMEA', 'AMERICAS'
    PARENT_ENTITY_CODE  VARCHAR(15),                        -- self-FK for hierarchy
    BUSINESS_UNITS      ARRAY,                              -- ['MIS', 'TNM']
    ACTIVE              BOOLEAN      NOT NULL DEFAULT TRUE,
    NOTES               VARCHAR(500),
    CREATED_AT          TIMESTAMP_NTZ DEFAULT CURRENT_TIMESTAMP,
    UPDATED_AT          TIMESTAMP_NTZ DEFAULT CURRENT_TIMESTAMP
);

-- Initial seed
INSERT INTO REF.REF_ENTITIES VALUES
  ('EJP',     '1096', 'Evident Japan',                'SAP',      'JPY', 'APAC',     NULL,  ARRAY_CONSTRUCT('MIS','TNM'), TRUE,  'Group HQ; data in Japanese-headed SAP extracts', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),
  ('ENF',     '1097', 'Evident NF',                   'SAP',      'JPY', 'APAC',     'EJP', ARRAY_CONSTRUCT('MIS','TNM'), TRUE,  'Most heterogeneous tab structure; 8+ custom Japanese-named tabs', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),
  ('EEU',     '4001', 'Evident Europe',               'SAP',      'EUR', 'EMEA',     'EJP', ARRAY_CONSTRUCT('MIS','TNM'), TRUE,  'European hub; treasury/cash-pool heavy', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),
  ('ETCE',    '4048', 'Evident Czech',                'SAP',      'EUR', 'EMEA',     'EEU', ARRAY_CONSTRUCT('MIS','TNM'), TRUE,  'Multi-tab native SAP exports', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),
  ('ESCE',    '4121', 'Evident SCE',                  'SAP',      'EUR', 'EMEA',     'EEU', ARRAY_CONSTRUCT('MIS'),       TRUE,  'Low MIS volume', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),
  ('EGZ',     '5020', 'Evident Guangzhou',            'SAP',      'CNY', 'APAC',     'EJP', ARRAY_CONSTRUCT('MIS','TNM'), TRUE,  '1027 rows in single AP tab', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),
  ('ECN',     '5043', 'Evident China',                'SAP',      'CNY', 'APAC',     'EJP', ARRAY_CONSTRUCT('MIS','TNM'), TRUE,  'Only entity using universal Master Trade template', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),
  ('ESG',     '5044', 'Evident Singapore',            'SAP',      'SGD', 'APAC',     'EJP', ARRAY_CONSTRUCT('MIS','TNM'), TRUE,  'FBL1N + ESG05/26/37 sub-account tabs', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),
  ('EKR',     '5045', 'Evident Korea',                'SAP',      'KRW', 'APAC',     'EJP', ARRAY_CONSTRUCT('MIS','TNM'), TRUE,  'Provides aggregated balances only (49 rows vs 446 invoices)', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),
  ('EIND',    '5046', 'Evident India',                'SAP',      'INR', 'APAC',     'EJP', ARRAY_CONSTRUCT('MIS','TNM'), TRUE,  'Sparse data', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),
  ('EAS',     '6009', 'Evident Australia',            'SAP',      'AUD', 'APAC',     'EJP', ARRAY_CONSTRUCT('MIS','TNM'), TRUE,  'Native SAP aging report', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),
  ('MIS-CND', '2017A','MIS Canada',                   'NetSuite', 'CAD', 'AMERICAS', 'MIS-USA', ARRAY_CONSTRUCT('MIS'), TRUE,  'Bundled with ECDN file', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),
  ('PCND',    '2017P','Pramana Canada',               'NetSuite', 'CAD', 'AMERICAS', NULL,  ARRAY_CONSTRUCT('MIS'),       TRUE,  'Low volume', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),
  ('MIS-USA', '2018A','MIS USA',                      'NetSuite', 'USD', 'AMERICAS', NULL,  ARRAY_CONSTRUCT('MIS'),       TRUE,  'Bundled with EUSA file', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),
  ('PUSA',    '2018P','Pramana USA',                  'NetSuite', 'USD', 'AMERICAS', NULL,  ARRAY_CONSTRUCT('MIS'),       TRUE,  '', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),
  ('EMEX',    '2062A','Evident Mexico',               'SAP',      'MXN', 'AMERICAS', NULL,  ARRAY_CONSTRUCT('MIS'),       TRUE,  '', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),
  ('SPIND',   '5030P','Pramana India',                'SAP',      'INR', 'APAC',     NULL,  ARRAY_CONSTRUCT('MIS'),       TRUE,  '', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP);
```

### 5.2 `REF.REF_ENTITY_GL_ACCOUNTS` — GL → Category mapping

The canonical mapping from each entity's SAP GL account to its intercompany category. Sourced from the Entity Accounts table in `Interco_Process_Automation`. **Currently 94 mappings; needs Lloyd to enrich.**

```sql
CREATE OR REPLACE TABLE REF.REF_ENTITY_GL_ACCOUNTS (
    ENTITY_CODE         VARCHAR(15) NOT NULL,
    GL_ACCOUNT          VARCHAR(50) NOT NULL,
    CATEGORY            VARCHAR(50) NOT NULL,    -- 'Trade', 'Non-trade', 'Accrued interest income and expenses', 'Loan', 'Transfer pricing'
    MATCHING_PROCESS    VARCHAR(15) NOT NULL,    -- 'TRADE' or 'NON_TRADE'
    SIDE                VARCHAR(2),              -- 'AR' or 'AP' (optional, derived from account number ranges)
    SOURCE_REF          VARCHAR(100),            -- e.g. 'Process Tab Entity Accounts row 3'
    EFFECTIVE_FROM      DATE NOT NULL,
    EFFECTIVE_TO        DATE,
    CREATED_AT          TIMESTAMP_NTZ DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (ENTITY_CODE, GL_ACCOUNT, EFFECTIVE_FROM)
);

-- Loaded from /mnt/user-data/outputs/ref_entity_gl_accounts.csv (94 rows)
COPY INTO REF.REF_ENTITY_GL_ACCOUNTS (ENTITY_CODE, ENTITY_SAP_CODE_OMIT, GL_ACCOUNT, CATEGORY, MATCHING_PROCESS, SOURCE_REF)
FROM @stage/ref/ref_entity_gl_accounts.csv
FILE_FORMAT = (TYPE = CSV SKIP_HEADER = 1 FIELD_OPTIONALLY_ENCLOSED_BY = '"');

-- After load, set EFFECTIVE_FROM = '2026-01-01' and SIDE based on account ranges
```

### 5.3 `REF.REF_ENTITY_ADAPTERS` — Per-entity parser configuration

Drives the entity adapter library. Each entity has one or more adapter configurations that tell the parser which file pattern, which tab pattern, and which column layout applies.

```sql
CREATE OR REPLACE TABLE REF.REF_ENTITY_ADAPTERS (
    ADAPTER_ID                  VARCHAR(50)  NOT NULL PRIMARY KEY,
    ENTITY_CODE                 VARCHAR(15)  NOT NULL,
    ADAPTER_VERSION             VARCHAR(10)  NOT NULL,
    FILE_PATTERN                VARCHAR(200) NOT NULL,    -- Regex match on filename
    TAB_PATTERN                 VARCHAR(200) NOT NULL,    -- Regex match on tab name
    DATA_START_ROW              INT          NOT NULL,
    HEADER_ROW                  INT,                       -- Row containing column headers
    SECONDARY_HEADER_ROW        INT,                       -- For tabs with bilingual headers (EJP)
    
    -- Column position (1-indexed) for each unified field. NULL = field not in this format.
    COL_REFERENCE               INT,                       -- Bilateral document number (sort_key)
    COL_DOC_NUMBER              INT,                       -- Local SAP/NetSuite doc number
    COL_TEXT                    INT,
    COL_GL_ACCOUNT              INT,
    COL_DOC_TYPE                INT,
    COL_DOC_DATE                INT,
    COL_POSTING_DATE            INT,
    COL_DOC_CURRENCY            INT,
    COL_DOC_AMOUNT              INT,
    COL_LC_AMOUNT               INT,
    COL_LC_CURRENCY             INT,
    COL_DUE_DATE                INT,
    COL_TRADING_PARTNER         INT,
    COL_PROFIT_CENTER           INT,
    COL_BU_SEGMENT              INT,
    COL_OPEN_STATUS             INT,                       -- If source ERP has explicit open flag
    
    -- Filtering
    MIS_PROFIT_CENTERS          ARRAY,                     -- Profit centers tagged as MIS
    EXCLUDE_TEXT_PATTERNS       ARRAY,                     -- Regex patterns to skip footer rows (Japanese text, etc.)
    
    -- Default values applied at extraction
    DEFAULT_DOC_CURRENCY        VARCHAR(3),                -- For tabs missing currency col
    DEFAULT_LC_CURRENCY         VARCHAR(3),
    DEFAULT_IS_OPEN             BOOLEAN,                   -- Default for tabs without status flag
    
    -- Metadata
    DESCRIPTION                 VARCHAR(500),
    ACTIVE                      BOOLEAN      NOT NULL DEFAULT TRUE,
    CREATED_AT                  TIMESTAMP_NTZ DEFAULT CURRENT_TIMESTAMP,
    UPDATED_AT                  TIMESTAMP_NTZ DEFAULT CURRENT_TIMESTAMP
);

-- Seed adapters (validated)
INSERT INTO REF.REF_ENTITY_ADAPTERS VALUES
  ('EJP_AR_MIS_v1',
   'EJP', '1.0',
   '.*\\(EJP\\)_\\(.+\\).*\\.xlsx?$',         -- File: any (EJP)_(XXX) bilateral file
   '^EJP AR-T\\(MIS\\)$',                      -- Tab: EJP AR-T(MIS)
   3, 1, 2,                                    -- Data starts row 3; header rows 1 and 2
   1, 6, 2, 5, 8, 9, 9, 10, 11, 12, NULL, 13, 14, 15, NULL, NULL,
   ARRAY_CONSTRUCT('1041','1042','1045'),     -- Placeholder MIS profit centers
   ARRAY_CONSTRUCT('消込','勘定','合計','計'),  -- Footer markers
   NULL, 'JPY', TRUE,
   'EJP MIS Trade AR — Japanese-headed SAP extract', TRUE, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),

  ('EJP_AR_OTHER_MIS_v1',
   'EJP', '1.0',
   '.*\\(EJP\\)_\\(.+\\).*\\.xlsx?$',
   '^EJP AR-O(\\(MIS\\)|.MIS.ICL)$',
   3, 1, 2,
   1, 6, 2, 5, 8, 9, 9, 10, 11, 12, NULL, 13, 14, 15, NULL, NULL,
   ARRAY_CONSTRUCT('1041','1042','1045'),
   ARRAY_CONSTRUCT('消込','勘定','合計','計'),
   NULL, 'JPY', TRUE,
   'EJP MIS Non-Trade AR (Other Receivables)', TRUE, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),

  ('ECN_MASTER_TRADE_v1',
   'ECN', '1.0',
   '.*\\(EJP\\)_\\(ECN\\).*\\.xlsx?$',
   '^Master \\(Trade\\) \\(ECN .+\\)$',
   31, 29, 30,                                  -- Data row 31; headers 29 + 30
   7, 6, NULL, 5, NULL, 9, 8, 12, 11, 13, 14, NULL, 4, NULL, 10, NULL,
   ARRAY_CONSTRUCT(),                            -- ECN Master template doesn't have profit center
   ARRAY_CONSTRUCT(),
   NULL, 'CNY', TRUE,
   'ECN Universal Master Trade Template', TRUE, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),

  ('ECN_MASTER_NON_TRADE_v1',
   'ECN', '1.0',
   '.*\\(EJP\\)_\\(ECN\\).*\\.xlsx?$',
   '^Master \\(Non-Trade\\) \\(ECN .+\\)$',
   31, 29, 30,
   7, 6, NULL, 5, NULL, 9, 8, 12, 11, 13, 14, NULL, 4, NULL, 10, NULL,
   ARRAY_CONSTRUCT(),
   ARRAY_CONSTRUCT(),
   NULL, 'CNY', TRUE,
   'ECN Universal Master Non-Trade Template', TRUE, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),

  ('EAS_NATIVE_AGING_v1',
   'EAS', '1.0',
   '.*\\(EJP\\)_\\(EAS\\).*\\.xlsx?$',
   '^EAS$',
   2, 1, NULL,
   4, 2, 15, 1, 5, 7, 8, 9, 10, 13, 12, 6, 30, NULL, NULL, NULL,
   ARRAY_CONSTRUCT(),
   ARRAY_CONSTRUCT(),
   'AUD', 'AUD', TRUE,
   'EAS native SAP aging report (English headers)', TRUE, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),

  ('EKR_AGGREGATE_v1',
   'EKR', '1.0',
   '.*\\(EJP\\)_\\(EKR\\).*\\.xlsx?$',
   '^EKR\\(MIS\\)$',
   2, 1, NULL,
   NULL, 1, 4, NULL, NULL, NULL, NULL, 3, 2, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
   ARRAY_CONSTRUCT(),
   ARRAY_CONSTRUCT(),
   'KRW', 'KRW', TRUE,
   'EKR aggregated 4-column AP balances (data is aggregated, not raw invoices)', TRUE, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP);

-- Adapters TODO: EEU multi-tab, ENF multi-tab, ESG FBL1N, ETCE multi-tab,
-- EIND, EGZ, ECDN+MIS-CND, EUSA NetSuite, PCND/PIND/PUSA, EMEX, SPIND
```

### 5.4 `REF.REF_MIS_PROFIT_CENTERS` — Per-entity MIS profit center inventory

Required because MIS scope is determined by Profit Center, with mapping per entity. **Pending Lloyd's confirmation** of the complete list per entity.

```sql
CREATE OR REPLACE TABLE REF.REF_MIS_PROFIT_CENTERS (
    ENTITY_CODE         VARCHAR(15) NOT NULL,
    PROFIT_CENTER       VARCHAR(20) NOT NULL,
    PROFIT_CENTER_NAME  VARCHAR(100),
    BUSINESS_UNIT       VARCHAR(10) NOT NULL,    -- 'MIS' or 'TNM'
    ACTIVE              BOOLEAN     NOT NULL DEFAULT TRUE,
    EFFECTIVE_FROM      DATE        NOT NULL,
    EFFECTIVE_TO        DATE,
    PRIMARY KEY (ENTITY_CODE, PROFIT_CENTER, EFFECTIVE_FROM)
);

-- Placeholder seeds for EJP (observed in data); needs Lloyd
INSERT INTO REF.REF_MIS_PROFIT_CENTERS VALUES
  ('EJP', '1041', 'MIS PC 1041', 'MIS', TRUE, '2026-01-01', NULL),
  ('EJP', '1042', 'MIS PC 1042', 'MIS', TRUE, '2026-01-01', NULL),
  ('EJP', '1045', 'MIS PC 1045', 'MIS', TRUE, '2026-01-01', NULL);
```

### 5.5 `REF.REF_FX_RATES` — Forex rates for tolerance and reporting

```sql
CREATE OR REPLACE TABLE REF.REF_FX_RATES (
    RATE_DATE       DATE        NOT NULL,
    FROM_CURRENCY   VARCHAR(3)  NOT NULL,
    TO_CURRENCY     VARCHAR(3)  NOT NULL,
    RATE            NUMBER(15,8) NOT NULL,
    RATE_TYPE       VARCHAR(10) NOT NULL,        -- 'AVG', 'CLOSE', 'OPEN'
    SOURCE          VARCHAR(50),                  -- e.g. 'Olympus monthly TTM'
    PRIMARY KEY (RATE_DATE, FROM_CURRENCY, TO_CURRENCY, RATE_TYPE)
);
```

### 5.6 `REF.REF_CONFIDENCE_WEIGHTS` — Weights from Process tab

Versioned so we can change weights without redeploying code.

```sql
CREATE OR REPLACE TABLE REF.REF_CONFIDENCE_WEIGHTS (
    PROCESS_TYPE        VARCHAR(15)  NOT NULL,    -- 'TRADE' or 'NON_TRADE'
    CRITERION           VARCHAR(50)  NOT NULL,    -- 'icp_match', 'invoice_match', etc.
    WEIGHT              NUMBER(5,2)  NOT NULL,
    EFFECTIVE_FROM      DATE         NOT NULL,
    EFFECTIVE_TO        DATE,
    SOURCE_REF          VARCHAR(200),
    PRIMARY KEY (PROCESS_TYPE, CRITERION, EFFECTIVE_FROM)
);

INSERT INTO REF.REF_CONFIDENCE_WEIGHTS VALUES
  ('TRADE',     'icp_match',          0.30, '2026-01-01', NULL, 'Process Tab Trade column 15-22 row 46'),
  ('TRADE',     'invoice_match',      0.20, '2026-01-01', NULL, 'Process Tab Trade Step 5'),
  ('TRADE',     'doc_curr_match',     0.20, '2026-01-01', NULL, 'Process Tab Trade Step 6'),
  ('TRADE',     'amount_match',       0.20, '2026-01-01', NULL, 'Process Tab Trade Step 7'),
  ('TRADE',     'doc_date_match',     0.05, '2026-01-01', NULL, 'Process Tab Trade additional date criterion'),
  ('TRADE',     'posting_month_match',0.05, '2026-01-01', NULL, 'Process Tab Trade additional date criterion'),
  ('NON_TRADE', 'icp_match',          0.30, '2026-01-01', NULL, 'Process Tab Non-Trade column 1-7 row 46'),
  ('NON_TRADE', 'same_month_match',   0.05, '2026-01-01', NULL, 'Process Tab Non-Trade Step 5 Criterion 1'),
  ('NON_TRADE', 'doc_curr_match',     0.10, '2026-01-01', NULL, 'Process Tab Non-Trade Step 5 Criterion 2'),
  ('NON_TRADE', 'amount_match',       0.50, '2026-01-01', NULL, 'Process Tab Non-Trade Step 5 Criterion 3 (DOMINANT)'),
  ('NON_TRADE', 'within_2_month_match',0.05,'2026-01-01', NULL, 'Process Tab Non-Trade Step 6');
```

### 5.7 `REF.REF_CURRENCY_MAPPING` — Currency code aliases

```sql
CREATE OR REPLACE TABLE REF.REF_CURRENCY_MAPPING (
    SOURCE_CODE     VARCHAR(10) NOT NULL PRIMARY KEY,
    NORMALIZED_CODE VARCHAR(3)  NOT NULL
);

INSERT INTO REF.REF_CURRENCY_MAPPING VALUES
  ('RMB','CNY'), ('CNY','CNY'), ('WON','KRW'), ('KRW','KRW'),
  ('USD','USD'), ('JPY','JPY'), ('EUR','EUR'), ('AUD','AUD'),
  ('SGD','SGD'), ('INR','INR'), ('CAD','CAD'), ('MXN','MXN');
```

### 5.8 `REF.REF_KNOWN_ISSUES` — Recurring reconciliation patterns

Pre-classified to short-circuit Cortex Phase 4 for known patterns.

```sql
CREATE OR REPLACE TABLE REF.REF_KNOWN_ISSUES (
    ISSUE_ID            VARCHAR(50)  NOT NULL PRIMARY KEY,
    ENTITY_A            VARCHAR(15)  NOT NULL,
    ENTITY_B            VARCHAR(15)  NOT NULL,
    CATEGORY            VARCHAR(50),
    CURRENCY            VARCHAR(3),
    PATTERN_DESCRIPTION VARCHAR(500),
    ROOT_CAUSE          VARCHAR(500),
    PROPOSED_JOURNAL    VARCHAR(2000),
    AUTOMATED_ACTION    VARCHAR(50),                -- 'AUTO_PROPOSE_JE', 'FLAG_ONLY', 'IGNORE'
    OBSERVED_FREQUENCY  VARCHAR(20),                -- 'MONTHLY', 'QUARTERLY', 'ONE-OFF'
    LAST_SEEN           DATE,
    NOTES               VARCHAR(1000)
);

INSERT INTO REF.REF_KNOWN_ISSUES VALUES
  ('ISSUE_EJP_ENF_RECLASS_JPY_468M',
   'EJP', 'ENF', 'Trade', 'JPY',
   'Recurring monthly comingled-GL reclass between EJP and ENF',
   'GL accounts comingled at source; needs reclass entry in ENF books',
   'DR ENF Trade Receivable 468,000,000 / CR ENF Trade Payable Comingled 468,000,000',
   'AUTO_PROPOSE_JE', 'MONTHLY', '2026-03-31',
   'Documented in consolidated workbook Compilation tab; same value most months'),

  ('ISSUE_ETCE_MIS_USA_RECLASS_USD_350K',
   'ETCE', 'MIS-USA', 'Trade', 'USD',
   'Recurring USD 350k segment reclass between ETCE and MIS-USA',
   'Segment-level booking difference (LS vs IE)',
   'Segment reclass entry in ETCE books',
   'AUTO_PROPOSE_JE', 'MONTHLY', '2026-03-31', ''),

  ('ISSUE_ETCE_ESG_FOREX_REVAL_JPY_2_6M',
   'ETCE', 'ESG', 'Trade', 'JPY',
   'JPY 2.6M forex revaluation difference',
   'Forex revaluation timing — different rate dates used by ETCE vs ESG',
   'Forex true-up entry',
   'AUTO_PROPOSE_JE', 'MONTHLY', '2026-03-31', '');
```

---

## 6. Master Data Tables

### 6.1 `REF.REF_PERIODS` — Reconciliation period control

```sql
CREATE OR REPLACE TABLE REF.REF_PERIODS (
    PERIOD_ID           VARCHAR(15)  NOT NULL PRIMARY KEY,    -- '2026-03'
    PERIOD_START_DATE   DATE NOT NULL,
    PERIOD_END_DATE     DATE NOT NULL,
    FISCAL_YEAR         INT NOT NULL,
    FISCAL_QUARTER      INT NOT NULL,
    STATUS              VARCHAR(20) NOT NULL,    -- 'OPEN', 'PROCESSING', 'CLOSED'
    CLOSED_AT           TIMESTAMP_NTZ,
    CLOSED_BY           VARCHAR(100)
);
```

### 6.2 `REF.REF_RECON_PAIRS` — Catalog of bilateral pairs

```sql
CREATE OR REPLACE TABLE REF.REF_RECON_PAIRS (
    PAIR_ID             VARCHAR(50)  NOT NULL PRIMARY KEY,    -- 'EJP_ECN'
    ENTITY_A            VARCHAR(15)  NOT NULL,
    ENTITY_B            VARCHAR(15)  NOT NULL,
    PAIR_NAME           VARCHAR(100),
    BUSINESS_UNIT_SCOPE VARCHAR(20)  NOT NULL,    -- 'MIS' (pilot scope)
    EXPECTED_CURRENCIES ARRAY,                     -- e.g. ['CNY','USD'] for EJP-ECN
    EXPECTED_CATEGORIES ARRAY,                     -- e.g. ['Trade','Non-trade','Loan']
    PRIORITY            INT,                       -- 1 = run first (validation pair)
    ACTIVE              BOOLEAN NOT NULL DEFAULT TRUE
);

-- Seed key MIS pairs
INSERT INTO REF.REF_RECON_PAIRS VALUES
  ('EJP_ECN', 'EJP','ECN','EJP-Evident China','MIS', ARRAY_CONSTRUCT('CNY','USD'), ARRAY_CONSTRUCT('Trade','Non-trade','Loan','Accrued interest income and expenses'), 1, TRUE),
  ('EJP_EAS', 'EJP','EAS','EJP-Evident Australia','MIS', ARRAY_CONSTRUCT('AUD','JPY'), ARRAY_CONSTRUCT('Trade','Transfer pricing'), 2, TRUE),
  ('EJP_EEU', 'EJP','EEU','EJP-Evident Europe','MIS', ARRAY_CONSTRUCT('EUR','JPY'), ARRAY_CONSTRUCT('Trade','Non-trade','Loan'), 2, TRUE),
  ('EJP_EKR', 'EJP','EKR','EJP-Evident Korea','MIS', ARRAY_CONSTRUCT('KRW'), ARRAY_CONSTRUCT('Trade'), 3, TRUE),
  ('EJP_ESG', 'EJP','ESG','EJP-Evident Singapore','MIS', ARRAY_CONSTRUCT('SGD'), ARRAY_CONSTRUCT('Trade','Loan'), 2, TRUE),
  ('EJP_ETCE','EJP','ETCE','EJP-Evident Czech','MIS', ARRAY_CONSTRUCT('EUR','JPY','USD'), ARRAY_CONSTRUCT('Trade','Non-trade'), 2, TRUE),
  ('EJP_EIND','EJP','EIND','EJP-Evident India','MIS', ARRAY_CONSTRUCT('INR','JPY','USD'), ARRAY_CONSTRUCT('Trade','Non-trade'), 3, TRUE),
  ('EJP_ENF', 'EJP','ENF','EJP-Evident NF','MIS', ARRAY_CONSTRUCT('JPY'), ARRAY_CONSTRUCT('Trade','Non-trade'), 2, TRUE),
  ('EJP_EGZ', 'EJP','EGZ','EJP-Evident Guangzhou','MIS', ARRAY_CONSTRUCT('CNY','JPY'), ARRAY_CONSTRUCT('Trade','Non-trade'), 3, TRUE),
  -- ... continue for all 35 MIS pairs
  ('ETCE_MIS_USA','ETCE','MIS-USA','ETCE-MIS USA','MIS', ARRAY_CONSTRUCT('USD'), ARRAY_CONSTRUCT('Trade'), 2, TRUE),
  ('ETCE_ESG','ETCE','ESG','ETCE-Evident Singapore','MIS', ARRAY_CONSTRUCT('JPY','SGD'), ARRAY_CONSTRUCT('Trade'), 2, TRUE);
```

### 6.3 `REF.REF_TOLERANCES` — Match tolerances

```sql
CREATE OR REPLACE TABLE REF.REF_TOLERANCES (
    SCOPE               VARCHAR(50) NOT NULL,    -- 'PHASE1_BALANCE', 'PHASE2_AMOUNT'
    CURRENCY            VARCHAR(3),               -- NULL = applies to all
    TOLERANCE_VALUE     NUMBER(20,4) NOT NULL,
    TOLERANCE_TYPE      VARCHAR(20) NOT NULL,    -- 'ABSOLUTE' or 'PERCENTAGE'
    EFFECTIVE_FROM      DATE NOT NULL,
    NOTES               VARCHAR(500)
);

INSERT INTO REF.REF_TOLERANCES VALUES
  ('PHASE1_BALANCE',  NULL, 1.00, 'ABSOLUTE', '2026-01-01', 'Phase 1 balance match: variance must be within 1.00 unit of doc currency'),
  ('PHASE2_AMOUNT',   NULL, 0.01, 'ABSOLUTE', '2026-01-01', 'Phase 2 amount match: difference must be within 0.01'),
  ('FOREX_ROUNDING',  NULL, 0.001,'PERCENTAGE','2026-01-01','Forex rounding tolerance applied during fuzzy match (0.1%)');
```

---

## 7. Source Data Extraction (Entity Adapter Layer)

### 7.1 Architecture

The adapter layer runs **outside Snowflake**, in a Python container or Snowflake Python Worksheet, and converts heterogeneous Excel inputs into standardized Parquet files staged in Snowflake. This separates the messy parsing from the well-structured matching pipeline.

```
Input:  /path/to/bilateral_files/*.xlsx
        (53 files for March 2026 MIS)
        ↓
Adapter Selection: For each file, identify entity pair from filename → look up adapters in REF_ENTITY_ADAPTERS
        ↓
Tab Discovery: For each tab in the file, match against TAB_PATTERN regex → assign adapter
        ↓
Row Extraction: Per the column position config, extract rows from data start row
        ↓
Footer Filtering: Drop rows matching EXCLUDE_TEXT_PATTERNS (Japanese 消込, totals, etc.)
        ↓
Profit Center Filtering: Keep only rows where Profit Center ∈ entity's MIS_PROFIT_CENTERS
        ↓
Currency Normalization: Map RMB→CNY, WON→KRW
        ↓
Type Coercion: Parse dates, signed numerics with safe_float()
        ↓
Output: Standardized Parquet files in @stage/raw/
```

### 7.2 Adapter Function Signature (Python)

```python
def adapter_run(
    file_path: str,
    adapter_config: dict,        # Row from REF_ENTITY_ADAPTERS
    period_id: str,              # '2026-03'
    mis_profit_centers: list,    # From REF_MIS_PROFIT_CENTERS
) -> pd.DataFrame:
    """
    Returns DataFrame matching IC_LINES_RAW schema (see §8.1).
    
    Each row:
      - Has standardized column names regardless of source format
      - Has currency normalized
      - Has profit center filter applied (MIS only)
      - Has UNMAPPED rows preserved (with category=UNMAPPED) for later review
      - Includes source_file, source_tab, source_row_num for traceability
    """
```

### 7.3 Adapter Inventory (build priority)

| # | Adapter ID | Status | Entities Covered | EJP-side rows |  Counterparty rows | Effort |
|---|------------|--------|------------------|---------------|--------------------|--------|
| 1 | EJP_AR_MIS_v1 | ✅ Built | EJP | 1,770 | — | Done |
| 2 | EJP_AR_OTHER_MIS_v1 | ✅ Built | EJP | 150 | — | Done |
| 3 | EJP_AP_MIS_v1 | 🟡 Partial | EJP | 539 | — | 0.5 day |
| 4 | EJP_AP_OTHER_MIS_v1 | 🟡 Partial | EJP | (864 UNMAPPED) | — | 1 day (column structure differs) |
| 5 | ECN_MASTER_TRADE_v1 | ✅ Built | ECN | — | 500 | Done |
| 6 | ECN_MASTER_NON_TRADE_v1 | ✅ Built | ECN | — | 10 | Done |
| 7 | EAS_NATIVE_AGING_v1 | 🟡 Partial | EAS | — | ~131 | 0.5 day to finish |
| 8 | EKR_AGGREGATE_v1 | ✅ Built | EKR | — | 49 | Done (limited by data) |
| 9 | EEU_NATIVE_SAP_v1 | ❌ TBD | EEU | — | ~1,000+ | 2 days (multi-tab) |
| 10 | EEU_CASH_POOL_v1 | ❌ TBD | EEU | — | ~3,000 | 2 days (treasury format) |
| 11 | ETCE_NATIVE_SAP_v1 | ❌ TBD | ETCE | — | ~500 | 2 days (similar to EEU) |
| 12 | ENF_MULTI_TAB_v1 | ❌ TBD | ENF | — | ~1,500 | 3-4 days (most complex) |
| 13 | ESG_FBL1N_v1 | ❌ TBD | ESG | — | ~384 | 1.5 days |
| 14 | EIND_v1 | ❌ TBD | EIND | — | ~14 (sparse) | 0.5 day |
| 15 | EGZ_v1 | ❌ TBD | EGZ | — | ~1,027 | 1 day |
| 16 | ECDN_MIS_CND_v1 | ❌ TBD | ECDN, MIS-CND | — | ~30 | 1 day (bundled file) |
| 17 | EUSA_NETSUITE_v1 | ❌ TBD | EUSA, MIS-USA | — | ~varies | 2 days (NetSuite schema) |
| 18 | PCND_PIND_PUSA_v1 | ❌ TBD | PCND, PIND, PUSA | — | small | 1 day |
| 19 | EMEX_v1 | ❌ TBD | EMEX | — | TBD | 0.5-1 day |
| 20 | SPIND_v1 | ❌ TBD | SPIND | — | TBD | 0.5-1 day |

**Total adapter build estimate: ~17-22 person-days for full MIS coverage.**

### 7.4 Adapter Output (Parquet Schema)

Each adapter emits a Parquet file with this schema:

```
ic_lines_raw_<entity>_<period>_<extract_ts>.parquet:
  source_file:           string
  source_tab:            string
  source_row_num:        int
  adapter_id:            string
  adapter_version:       string
  period_id:             string                     -- '2026-03'
  extract_ts:            timestamp
  entity_code:           string
  entity_sap_code:       string
  counterparty_code:     string                     -- inferred from filename or trading_partner field
  reference:             string                     -- bilateral document number (sort_key)
  doc_number:            string                     -- local SAP/NetSuite doc number
  text:                  string
  gl_account:            string
  doc_type:              string
  doc_date:              date
  posting_date:          date
  doc_currency:          string                     -- normalized
  doc_amount:            decimal(20,4)
  lc_amount:             decimal(20,4)
  lc_currency:           string
  due_date:              date
  trading_partner:       string
  profit_center:         string
  bu_segment:            string
  is_open:               boolean
  raw_row_json:          string                     -- full original row as JSON for audit
```

### 7.5 Staging Files in Snowflake

```sql
CREATE STAGE IF NOT EXISTS RAW.STG_BILATERAL_EXTRACTS
  FILE_FORMAT = (TYPE = PARQUET)
  COMMENT = 'Per-entity Parquet outputs from adapter layer';

-- Adapters write here via PUT or programmatic API
-- File naming: ic_lines_raw_<entity>_<period>_<adapter>_<extract_ts>.parquet
```

---

## 8. Landing and Staging Tables

### 8.1 `RAW.IC_LINES_RAW` — Raw landing table

```sql
CREATE OR REPLACE TABLE RAW.IC_LINES_RAW (
    LINE_ID                 NUMBER AUTOINCREMENT PRIMARY KEY,
    SOURCE_FILE             VARCHAR(500) NOT NULL,
    SOURCE_TAB              VARCHAR(200),
    SOURCE_ROW_NUM          INT,
    ADAPTER_ID              VARCHAR(50),
    ADAPTER_VERSION         VARCHAR(10),
    PERIOD_ID               VARCHAR(15) NOT NULL,
    EXTRACT_TS              TIMESTAMP_NTZ NOT NULL,
    
    ENTITY_CODE             VARCHAR(15) NOT NULL,
    ENTITY_SAP_CODE         VARCHAR(10),
    COUNTERPARTY_CODE       VARCHAR(15),
    
    REFERENCE               VARCHAR(100),     -- bilateral document number
    DOC_NUMBER              VARCHAR(100),     -- local SAP/NetSuite doc number
    TEXT                    VARCHAR(500),
    GL_ACCOUNT              VARCHAR(50),
    DOC_TYPE                VARCHAR(20),
    DOC_DATE                DATE,
    POSTING_DATE            DATE,
    DOC_CURRENCY            VARCHAR(3),
    DOC_AMOUNT              NUMBER(20,4),
    LC_AMOUNT               NUMBER(20,4),
    LC_CURRENCY             VARCHAR(3),
    DUE_DATE                DATE,
    TRADING_PARTNER         VARCHAR(50),
    PROFIT_CENTER           VARCHAR(20),
    BU_SEGMENT              VARCHAR(20),
    IS_OPEN                 BOOLEAN,
    
    RAW_ROW_JSON            VARIANT,           -- full original row for audit
    LOAD_TS                 TIMESTAMP_NTZ DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IDX_RAW_LINES_PERIOD ON RAW.IC_LINES_RAW (PERIOD_ID);
CREATE INDEX IDX_RAW_LINES_ENTITY ON RAW.IC_LINES_RAW (ENTITY_CODE, COUNTERPARTY_CODE);
```

### 8.2 `STAGING.IC_LINES` — Standardized + categorized line items

This is the canonical line-level table the matching engine operates on.

```sql
CREATE OR REPLACE TABLE STAGING.IC_LINES (
    LINE_ID                 NUMBER NOT NULL PRIMARY KEY,
    PERIOD_ID               VARCHAR(15) NOT NULL,
    
    -- Provenance
    SOURCE_FILE             VARCHAR(500) NOT NULL,
    SOURCE_TAB              VARCHAR(200),
    SOURCE_ROW_NUM          INT,
    ADAPTER_ID              VARCHAR(50),
    
    -- Entity context
    ENTITY_CODE             VARCHAR(15) NOT NULL,
    ENTITY_SAP_CODE         VARCHAR(10),
    COUNTERPARTY_CODE       VARCHAR(15),
    
    -- Categorization (from REF_ENTITY_GL_ACCOUNTS lookup)
    GL_ACCOUNT              VARCHAR(50),
    CATEGORY                VARCHAR(50) NOT NULL,    -- Trade / Non-trade / Loan / Accrued interest / Transfer pricing / UNMAPPED
    MATCHING_PROCESS        VARCHAR(15) NOT NULL,    -- TRADE / NON_TRADE / UNKNOWN
    SIDE                    VARCHAR(2),              -- AR / AP (from sign of doc_amount)
    
    -- Document identifiers
    REFERENCE               VARCHAR(100),            -- bilateral key
    DOC_NUMBER              VARCHAR(100),            -- local SAP key
    DOC_TYPE                VARCHAR(20),
    
    -- Dates
    DOC_DATE                DATE,
    POSTING_DATE            DATE,
    DUE_DATE                DATE,
    POSTING_MONTH           VARCHAR(7),              -- 'YYYY-MM' for matching
    
    -- Amounts (always store both doc and LC)
    DOC_CURRENCY            VARCHAR(3) NOT NULL,
    DOC_AMOUNT              NUMBER(20,4) NOT NULL,
    LC_AMOUNT               NUMBER(20,4),
    LC_CURRENCY             VARCHAR(3),
    
    -- Filtering attributes
    PROFIT_CENTER           VARCHAR(20),
    BU_SEGMENT              VARCHAR(20),
    IS_OPEN                 BOOLEAN NOT NULL DEFAULT TRUE,
    IS_MIS                  BOOLEAN NOT NULL,        -- Result of profit center filter
    
    -- Searchable text concatenation for embedding
    DESCRIPTION_TEXT        VARCHAR(1000),
    
    -- Raw text (passthrough)
    SOURCE_TEXT             VARCHAR(500),
    
    -- Metadata
    LOAD_TS                 TIMESTAMP_NTZ DEFAULT CURRENT_TIMESTAMP,
    
    -- Computed derived fields
    DOC_AMOUNT_ABS          AS (ABS(DOC_AMOUNT)),
    DOC_AMOUNT_SIGN         AS (SIGN(DOC_AMOUNT))
);

CREATE INDEX IDX_IC_LINES_PERIOD ON STAGING.IC_LINES (PERIOD_ID, ENTITY_CODE, COUNTERPARTY_CODE);
CREATE INDEX IDX_IC_LINES_CATEGORY ON STAGING.IC_LINES (CATEGORY, MATCHING_PROCESS);
CREATE INDEX IDX_IC_LINES_REFERENCE ON STAGING.IC_LINES (REFERENCE);
CREATE INDEX IDX_IC_LINES_DOC_NUMBER ON STAGING.IC_LINES (DOC_NUMBER);
```

### 8.3 `STAGING.IC_LINES_DATA_QUALITY` — DQ metrics

```sql
CREATE OR REPLACE TABLE STAGING.IC_LINES_DATA_QUALITY (
    PERIOD_ID                       VARCHAR(15),
    ENTITY_CODE                     VARCHAR(15),
    SOURCE_FILE                     VARCHAR(500),
    TOTAL_RAW_ROWS                  INT,
    ROWS_AFTER_FOOTER_FILTER        INT,
    ROWS_AFTER_MIS_FILTER           INT,
    ROWS_WITH_GL_ACCOUNT            INT,
    ROWS_CATEGORIZED                INT,
    ROWS_UNMAPPED                   INT,
    ROWS_MISSING_AMOUNT             INT,
    ROWS_MISSING_CURRENCY           INT,
    ROWS_MISSING_REFERENCE          INT,
    ROWS_MISSING_DOC_NUMBER         INT,
    UNIQUE_GL_ACCOUNTS              INT,
    UNIQUE_CURRENCIES               INT,
    LOAD_TS                         TIMESTAMP_NTZ DEFAULT CURRENT_TIMESTAMP
);
```

---

## 9. Ingestion Pipeline

### 9.1 Stored Procedure — `RAW_TO_STAGING`

```sql
CREATE OR REPLACE PROCEDURE STAGING.SP_RAW_TO_STAGING(P_PERIOD_ID VARCHAR)
RETURNS VARIANT
LANGUAGE SQL
AS
$$
DECLARE
    rows_loaded INT;
    rows_unmapped INT;
    result VARIANT;
BEGIN
    -- 1. Truncate staging for this period (idempotent reload)
    DELETE FROM STAGING.IC_LINES WHERE PERIOD_ID = :P_PERIOD_ID;
    
    -- 2. Load from raw with categorization, MIS filtering, and standardization
    INSERT INTO STAGING.IC_LINES (
        LINE_ID, PERIOD_ID,
        SOURCE_FILE, SOURCE_TAB, SOURCE_ROW_NUM, ADAPTER_ID,
        ENTITY_CODE, ENTITY_SAP_CODE, COUNTERPARTY_CODE,
        GL_ACCOUNT, CATEGORY, MATCHING_PROCESS, SIDE,
        REFERENCE, DOC_NUMBER, DOC_TYPE,
        DOC_DATE, POSTING_DATE, DUE_DATE, POSTING_MONTH,
        DOC_CURRENCY, DOC_AMOUNT, LC_AMOUNT, LC_CURRENCY,
        PROFIT_CENTER, BU_SEGMENT, IS_OPEN, IS_MIS,
        DESCRIPTION_TEXT, SOURCE_TEXT
    )
    SELECT
        r.LINE_ID,
        r.PERIOD_ID,
        r.SOURCE_FILE, r.SOURCE_TAB, r.SOURCE_ROW_NUM, r.ADAPTER_ID,
        r.ENTITY_CODE, r.ENTITY_SAP_CODE, r.COUNTERPARTY_CODE,
        r.GL_ACCOUNT,
        COALESCE(g.CATEGORY, 'UNMAPPED') AS CATEGORY,
        COALESCE(g.MATCHING_PROCESS, 'UNKNOWN') AS MATCHING_PROCESS,
        CASE WHEN r.DOC_AMOUNT > 0 THEN 'AR' WHEN r.DOC_AMOUNT < 0 THEN 'AP' ELSE NULL END AS SIDE,
        r.REFERENCE, r.DOC_NUMBER, r.DOC_TYPE,
        r.DOC_DATE, r.POSTING_DATE, r.DUE_DATE,
        TO_CHAR(COALESCE(r.POSTING_DATE, r.DOC_DATE), 'YYYY-MM') AS POSTING_MONTH,
        COALESCE(cm.NORMALIZED_CODE, r.DOC_CURRENCY) AS DOC_CURRENCY,
        r.DOC_AMOUNT,
        r.LC_AMOUNT,
        COALESCE(cm2.NORMALIZED_CODE, r.LC_CURRENCY) AS LC_CURRENCY,
        r.PROFIT_CENTER, r.BU_SEGMENT,
        COALESCE(r.IS_OPEN, TRUE) AS IS_OPEN,
        -- MIS filter
        CASE WHEN r.PROFIT_CENTER IS NULL THEN TRUE  -- entities without PC default to in-scope
             WHEN EXISTS (SELECT 1 FROM REF.REF_MIS_PROFIT_CENTERS m
                          WHERE m.ENTITY_CODE = r.ENTITY_CODE
                            AND m.PROFIT_CENTER = r.PROFIT_CENTER
                            AND m.BUSINESS_UNIT = 'MIS'
                            AND m.ACTIVE = TRUE)
             THEN TRUE ELSE FALSE END AS IS_MIS,
        -- Composite description for embedding
        CONCAT_WS(' | ',
                  r.ENTITY_CODE, r.COUNTERPARTY_CODE, r.GL_ACCOUNT,
                  COALESCE(r.REFERENCE, ''), COALESCE(r.DOC_NUMBER, ''),
                  COALESCE(r.TEXT, ''),
                  TO_VARCHAR(r.DOC_AMOUNT), r.DOC_CURRENCY) AS DESCRIPTION_TEXT,
        r.TEXT AS SOURCE_TEXT
    FROM RAW.IC_LINES_RAW r
    LEFT JOIN REF.REF_ENTITY_GL_ACCOUNTS g
        ON g.ENTITY_CODE = r.ENTITY_CODE 
        AND g.GL_ACCOUNT = r.GL_ACCOUNT
        AND CURRENT_DATE() BETWEEN g.EFFECTIVE_FROM AND COALESCE(g.EFFECTIVE_TO, DATE '9999-12-31')
    LEFT JOIN REF.REF_CURRENCY_MAPPING cm  ON cm.SOURCE_CODE = r.DOC_CURRENCY
    LEFT JOIN REF.REF_CURRENCY_MAPPING cm2 ON cm2.SOURCE_CODE = r.LC_CURRENCY
    WHERE r.PERIOD_ID = :P_PERIOD_ID;
    
    rows_loaded := SQLROWCOUNT;
    
    -- 3. DQ metrics
    INSERT INTO STAGING.IC_LINES_DATA_QUALITY (
        PERIOD_ID, ENTITY_CODE, SOURCE_FILE,
        TOTAL_RAW_ROWS, ROWS_AFTER_MIS_FILTER, ROWS_CATEGORIZED, ROWS_UNMAPPED,
        ROWS_MISSING_AMOUNT, ROWS_MISSING_CURRENCY, UNIQUE_GL_ACCOUNTS, UNIQUE_CURRENCIES
    )
    SELECT
        PERIOD_ID, ENTITY_CODE, SOURCE_FILE,
        COUNT(*),
        COUNT_IF(IS_MIS),
        COUNT_IF(CATEGORY != 'UNMAPPED'),
        COUNT_IF(CATEGORY = 'UNMAPPED'),
        COUNT_IF(DOC_AMOUNT IS NULL),
        COUNT_IF(DOC_CURRENCY IS NULL),
        COUNT(DISTINCT GL_ACCOUNT),
        COUNT(DISTINCT DOC_CURRENCY)
    FROM STAGING.IC_LINES
    WHERE PERIOD_ID = :P_PERIOD_ID
    GROUP BY PERIOD_ID, ENTITY_CODE, SOURCE_FILE;
    
    SELECT OBJECT_CONSTRUCT('rows_loaded', rows_loaded,
                            'period_id', :P_PERIOD_ID,
                            'completed_at', CURRENT_TIMESTAMP) INTO :result;
    RETURN result;
END;
$$;
```

---

## 10. Phase 1 — GL Balance Reconciliation

### 10.1 Output table

```sql
CREATE OR REPLACE TABLE RESULTS.PHASE1_BALANCE_RECON (
    RECON_ID                NUMBER AUTOINCREMENT PRIMARY KEY,
    PERIOD_ID               VARCHAR(15) NOT NULL,
    PAIR_ID                 VARCHAR(50) NOT NULL,
    ENTITY_A                VARCHAR(15) NOT NULL,
    ENTITY_B                VARCHAR(15) NOT NULL,
    CATEGORY                VARCHAR(50) NOT NULL,
    DOC_CURRENCY            VARCHAR(3) NOT NULL,
    
    SUM_A                   NUMBER(20,4) NOT NULL,
    COUNT_A                 INT NOT NULL,
    SUM_B                   NUMBER(20,4) NOT NULL,
    COUNT_B                 INT NOT NULL,
    NET_VARIANCE            NUMBER(20,4) NOT NULL,
    
    BALANCE_MATCH           BOOLEAN NOT NULL,
    PHASE2_REQUIRED         BOOLEAN NOT NULL,
    
    -- LC translated for reporting
    NET_VARIANCE_REPORTING  NUMBER(20,4),
    REPORTING_CURRENCY      VARCHAR(3),
    
    KNOWN_ISSUE_ID          VARCHAR(50),  -- match against REF_KNOWN_ISSUES
    
    RUN_TS                  TIMESTAMP_NTZ DEFAULT CURRENT_TIMESTAMP
);
```

### 10.2 Phase 1 procedure

```sql
CREATE OR REPLACE PROCEDURE RESULTS.SP_RUN_PHASE1(P_PERIOD_ID VARCHAR)
RETURNS VARIANT
LANGUAGE SQL
AS
$$
DECLARE
    tolerance NUMBER(20,4);
    pairs_run INT;
    matches_clean INT;
    variances INT;
    result VARIANT;
BEGIN
    SELECT TOLERANCE_VALUE INTO :tolerance
    FROM REF.REF_TOLERANCES
    WHERE SCOPE = 'PHASE1_BALANCE'
      AND CURRENT_DATE() >= EFFECTIVE_FROM
    QUALIFY ROW_NUMBER() OVER (ORDER BY EFFECTIVE_FROM DESC) = 1;
    
    DELETE FROM RESULTS.PHASE1_BALANCE_RECON WHERE PERIOD_ID = :P_PERIOD_ID;
    
    INSERT INTO RESULTS.PHASE1_BALANCE_RECON (
        PERIOD_ID, PAIR_ID, ENTITY_A, ENTITY_B, CATEGORY, DOC_CURRENCY,
        SUM_A, COUNT_A, SUM_B, COUNT_B, NET_VARIANCE,
        BALANCE_MATCH, PHASE2_REQUIRED, KNOWN_ISSUE_ID
    )
    WITH agg AS (
        -- Aggregate per (entity, counterparty, category, currency)
        SELECT
            PERIOD_ID, ENTITY_CODE, COUNTERPARTY_CODE, CATEGORY, DOC_CURRENCY,
            SUM(DOC_AMOUNT) AS SUM_AMT,
            COUNT(*) AS LINE_COUNT
        FROM STAGING.IC_LINES
        WHERE PERIOD_ID = :P_PERIOD_ID
          AND IS_MIS = TRUE
          AND IS_OPEN = TRUE
          AND CATEGORY != 'UNMAPPED'
          AND DOC_AMOUNT IS NOT NULL
          AND DOC_CURRENCY IS NOT NULL
          AND COUNTERPARTY_CODE IS NOT NULL
        GROUP BY PERIOD_ID, ENTITY_CODE, COUNTERPARTY_CODE, CATEGORY, DOC_CURRENCY
    ),
    paired AS (
        SELECT
            a.PERIOD_ID,
            CASE WHEN a.ENTITY_CODE < a.COUNTERPARTY_CODE
                 THEN CONCAT(a.ENTITY_CODE, '_', a.COUNTERPARTY_CODE)
                 ELSE CONCAT(a.COUNTERPARTY_CODE, '_', a.ENTITY_CODE) END AS PAIR_ID,
            a.ENTITY_CODE AS ENTITY_A,
            a.COUNTERPARTY_CODE AS ENTITY_B,
            a.CATEGORY,
            a.DOC_CURRENCY,
            a.SUM_AMT AS SUM_A,
            a.LINE_COUNT AS COUNT_A,
            COALESCE(b.SUM_AMT, 0) AS SUM_B,
            COALESCE(b.LINE_COUNT, 0) AS COUNT_B
        FROM agg a
        LEFT JOIN agg b
            ON b.PERIOD_ID = a.PERIOD_ID
           AND b.ENTITY_CODE = a.COUNTERPARTY_CODE
           AND b.COUNTERPARTY_CODE = a.ENTITY_CODE
           AND b.CATEGORY = a.CATEGORY
           AND b.DOC_CURRENCY = a.DOC_CURRENCY
        QUALIFY ROW_NUMBER() OVER (
            PARTITION BY a.PERIOD_ID,
                LEAST(a.ENTITY_CODE, a.COUNTERPARTY_CODE),
                GREATEST(a.ENTITY_CODE, a.COUNTERPARTY_CODE),
                a.CATEGORY, a.DOC_CURRENCY
            ORDER BY a.ENTITY_CODE
        ) = 1
    )
    SELECT
        p.PERIOD_ID,
        p.PAIR_ID,
        p.ENTITY_A,
        p.ENTITY_B,
        p.CATEGORY,
        p.DOC_CURRENCY,
        p.SUM_A, p.COUNT_A, p.SUM_B, p.COUNT_B,
        (p.SUM_A + p.SUM_B) AS NET_VARIANCE,
        ABS(p.SUM_A + p.SUM_B) < :tolerance AS BALANCE_MATCH,
        ABS(p.SUM_A + p.SUM_B) >= :tolerance AND p.COUNT_B > 0 AS PHASE2_REQUIRED,
        ki.ISSUE_ID AS KNOWN_ISSUE_ID
    FROM paired p
    LEFT JOIN REF.REF_KNOWN_ISSUES ki
        ON ki.ENTITY_A IN (p.ENTITY_A, p.ENTITY_B)
       AND ki.ENTITY_B IN (p.ENTITY_A, p.ENTITY_B)
       AND ki.CATEGORY = p.CATEGORY
       AND ki.CURRENCY = p.DOC_CURRENCY;
    
    SELECT
        COUNT(*),
        COUNT_IF(BALANCE_MATCH),
        COUNT_IF(PHASE2_REQUIRED)
    INTO :pairs_run, :matches_clean, :variances
    FROM RESULTS.PHASE1_BALANCE_RECON
    WHERE PERIOD_ID = :P_PERIOD_ID;
    
    SELECT OBJECT_CONSTRUCT(
        'period_id', :P_PERIOD_ID,
        'pairs_run', :pairs_run,
        'balance_matched', :matches_clean,
        'variances_requiring_drilldown', :variances
    ) INTO :result;
    
    RETURN result;
END;
$$;
```

### 10.3 Confirmation Queue load (Phase 1 winners)

```sql
INSERT INTO HITL.CONFIRMATION_QUEUE (
    QUEUE_ITEM_ID, PERIOD_ID, ITEM_TYPE, PAIR_ID, ENTITY_A, ENTITY_B,
    CATEGORY, DOC_CURRENCY, SUM_A, SUM_B, NET_VARIANCE,
    LINE_COUNT_A, LINE_COUNT_B, RULE_BASED_CONFIDENCE, AI_CONFIDENCE, STATUS, CREATED_AT
)
SELECT
    UUID_STRING(),
    PERIOD_ID,
    'PHASE1_BALANCE_MATCH',
    PAIR_ID, ENTITY_A, ENTITY_B,
    CATEGORY, DOC_CURRENCY, SUM_A, SUM_B, NET_VARIANCE,
    COUNT_A, COUNT_B, 1.00, NULL,    -- AI confidence not applicable to balance match
    'PENDING_CONFIRMATION',
    CURRENT_TIMESTAMP
FROM RESULTS.PHASE1_BALANCE_RECON
WHERE PERIOD_ID = :P_PERIOD_ID AND BALANCE_MATCH = TRUE;
```

---

## 11. Phase 2 — Deterministic Line-Level Drill-Down

### 11.1 Output tables

```sql
CREATE OR REPLACE TABLE RESULTS.PHASE2_LINE_MATCHES (
    MATCH_ID                NUMBER AUTOINCREMENT PRIMARY KEY,
    PERIOD_ID               VARCHAR(15) NOT NULL,
    PAIR_ID                 VARCHAR(50) NOT NULL,
    CATEGORY                VARCHAR(50) NOT NULL,
    DOC_CURRENCY            VARCHAR(3) NOT NULL,
    
    LINE_ID_A               NUMBER NOT NULL REFERENCES STAGING.IC_LINES(LINE_ID),
    LINE_ID_B               NUMBER NOT NULL REFERENCES STAGING.IC_LINES(LINE_ID),
    
    -- Criterion-by-criterion results
    ICP_MATCH               BOOLEAN,
    INVOICE_MATCH           BOOLEAN,
    AMOUNT_MATCH            BOOLEAN,
    CURRENCY_MATCH          BOOLEAN,
    DOC_DATE_MATCH          BOOLEAN,
    POSTING_MONTH_MATCH     BOOLEAN,
    SAME_MONTH_MATCH        BOOLEAN,        -- For Non-Trade
    WITHIN_2_MONTH_MATCH    BOOLEAN,        -- For Non-Trade
    
    RULE_BASED_CONFIDENCE   NUMBER(4,3) NOT NULL,
    AI_CONFIDENCE           NUMBER(4,3),    -- Populated by Phase 3 if applicable
    
    MATCH_KEY_USED          VARCHAR(50),    -- 'reference=doc_number', 'amount+currency+month', etc.
    PROCESS_TYPE            VARCHAR(15),    -- TRADE / NON_TRADE
    REVIEW_REQUIRED         BOOLEAN NOT NULL,
    
    RUN_TS                  TIMESTAMP_NTZ DEFAULT CURRENT_TIMESTAMP
);

CREATE OR REPLACE TABLE RESULTS.PHASE2_UNMATCHED (
    UNMATCHED_ID            NUMBER AUTOINCREMENT PRIMARY KEY,
    PERIOD_ID               VARCHAR(15) NOT NULL,
    PAIR_ID                 VARCHAR(50) NOT NULL,
    CATEGORY                VARCHAR(50) NOT NULL,
    DOC_CURRENCY            VARCHAR(3) NOT NULL,
    LINE_ID                 NUMBER NOT NULL REFERENCES STAGING.IC_LINES(LINE_ID),
    SIDE                    VARCHAR(2),     -- 'A' or 'B' indicating which side has the orphan
    UNMATCHED_REASON        VARCHAR(50),    -- 'NO_INVOICE_MATCH', 'NO_AMOUNT_MATCH', 'BELOW_THRESHOLD'
    PROBABILITY_OF_MATCH    NUMBER(4,3),    -- AI estimate from Phase 3 if any candidates exist
    PHASE3_REQUIRED         BOOLEAN NOT NULL,
    RUN_TS                  TIMESTAMP_NTZ DEFAULT CURRENT_TIMESTAMP
);
```

### 11.2 Phase 2 Trade matching (SQL pattern)

```sql
CREATE OR REPLACE PROCEDURE RESULTS.SP_RUN_PHASE2_TRADE(P_PERIOD_ID VARCHAR)
RETURNS VARIANT
LANGUAGE SQL
AS
$$
BEGIN
    -- For each Trade variance from Phase 1, run drill-down matching
    -- Match key: A.reference = B.doc_number OR A.doc_number = B.reference
    
    INSERT INTO RESULTS.PHASE2_LINE_MATCHES (
        PERIOD_ID, PAIR_ID, CATEGORY, DOC_CURRENCY,
        LINE_ID_A, LINE_ID_B,
        ICP_MATCH, INVOICE_MATCH, CURRENCY_MATCH, AMOUNT_MATCH,
        DOC_DATE_MATCH, POSTING_MONTH_MATCH,
        RULE_BASED_CONFIDENCE, MATCH_KEY_USED, PROCESS_TYPE, REVIEW_REQUIRED
    )
    WITH variances AS (
        SELECT * FROM RESULTS.PHASE1_BALANCE_RECON
        WHERE PERIOD_ID = :P_PERIOD_ID
          AND PHASE2_REQUIRED = TRUE
          AND CATEGORY = 'Trade'
    ),
    a_lines AS (
        SELECT i.* FROM STAGING.IC_LINES i
        JOIN variances v
          ON i.ENTITY_CODE = v.ENTITY_A
         AND i.COUNTERPARTY_CODE = v.ENTITY_B
         AND i.CATEGORY = v.CATEGORY
         AND i.DOC_CURRENCY = v.DOC_CURRENCY
         AND i.PERIOD_ID = v.PERIOD_ID
        WHERE i.IS_MIS = TRUE AND i.IS_OPEN = TRUE
    ),
    b_lines AS (
        SELECT i.* FROM STAGING.IC_LINES i
        JOIN variances v
          ON i.ENTITY_CODE = v.ENTITY_B
         AND i.COUNTERPARTY_CODE = v.ENTITY_A
         AND i.CATEGORY = v.CATEGORY
         AND i.DOC_CURRENCY = v.DOC_CURRENCY
         AND i.PERIOD_ID = v.PERIOD_ID
        WHERE i.IS_MIS = TRUE AND i.IS_OPEN = TRUE
    ),
    -- Match where A.reference = B.doc_number (the EJP-ECN bilateral key pattern)
    matches_ref_doc AS (
        SELECT
            a.PERIOD_ID,
            CONCAT(LEAST(a.ENTITY_CODE, b.ENTITY_CODE),'_',
                   GREATEST(a.ENTITY_CODE, b.ENTITY_CODE)) AS PAIR_ID,
            a.CATEGORY, a.DOC_CURRENCY,
            a.LINE_ID AS LINE_ID_A,
            b.LINE_ID AS LINE_ID_B,
            TRUE AS ICP_MATCH,
            TRUE AS INVOICE_MATCH,
            (a.DOC_CURRENCY = b.DOC_CURRENCY) AS CURRENCY_MATCH,
            (ABS(ABS(a.DOC_AMOUNT) - ABS(b.DOC_AMOUNT)) < 0.01
             AND SIGN(a.DOC_AMOUNT) != SIGN(b.DOC_AMOUNT)) AS AMOUNT_MATCH,
            (COALESCE(a.DOC_DATE, a.POSTING_DATE) = COALESCE(b.DOC_DATE, b.POSTING_DATE)) AS DOC_DATE_MATCH,
            (a.POSTING_MONTH = b.POSTING_MONTH) AS POSTING_MONTH_MATCH,
            'a.reference=b.doc_number' AS MATCH_KEY_USED
        FROM a_lines a
        JOIN b_lines b
          ON a.REFERENCE IS NOT NULL
         AND b.DOC_NUMBER IS NOT NULL
         AND a.REFERENCE = b.DOC_NUMBER
    ),
    -- Match where A.doc_number = B.reference (reverse direction)
    matches_doc_ref AS (
        SELECT
            a.PERIOD_ID,
            CONCAT(LEAST(a.ENTITY_CODE, b.ENTITY_CODE),'_',
                   GREATEST(a.ENTITY_CODE, b.ENTITY_CODE)) AS PAIR_ID,
            a.CATEGORY, a.DOC_CURRENCY,
            a.LINE_ID AS LINE_ID_A,
            b.LINE_ID AS LINE_ID_B,
            TRUE AS ICP_MATCH,
            TRUE AS INVOICE_MATCH,
            (a.DOC_CURRENCY = b.DOC_CURRENCY),
            (ABS(ABS(a.DOC_AMOUNT) - ABS(b.DOC_AMOUNT)) < 0.01
             AND SIGN(a.DOC_AMOUNT) != SIGN(b.DOC_AMOUNT)),
            (COALESCE(a.DOC_DATE, a.POSTING_DATE) = COALESCE(b.DOC_DATE, b.POSTING_DATE)),
            (a.POSTING_MONTH = b.POSTING_MONTH),
            'a.doc_number=b.reference'
        FROM a_lines a
        JOIN b_lines b
          ON a.DOC_NUMBER IS NOT NULL
         AND b.REFERENCE IS NOT NULL
         AND a.DOC_NUMBER = b.REFERENCE
         AND NOT EXISTS (SELECT 1 FROM matches_ref_doc m
                         WHERE m.LINE_ID_A = a.LINE_ID AND m.LINE_ID_B = b.LINE_ID)
    ),
    all_matches AS (
        SELECT * FROM matches_ref_doc
        UNION ALL
        SELECT * FROM matches_doc_ref
    ),
    -- Compute confidence using REF_CONFIDENCE_WEIGHTS
    weighted AS (
        SELECT
            m.*,
            (
                (CASE WHEN ICP_MATCH THEN 1 ELSE 0 END) * 0.30
              + (CASE WHEN INVOICE_MATCH THEN 1 ELSE 0 END) * 0.20
              + (CASE WHEN CURRENCY_MATCH THEN 1 ELSE 0 END) * 0.20
              + (CASE WHEN AMOUNT_MATCH THEN 1 ELSE 0 END) * 0.20
              + (CASE WHEN DOC_DATE_MATCH THEN 1 ELSE 0 END) * 0.05
              + (CASE WHEN POSTING_MONTH_MATCH THEN 1 ELSE 0 END) * 0.05
            ) AS CONF
        FROM all_matches m
    )
    SELECT
        PERIOD_ID, PAIR_ID, CATEGORY, DOC_CURRENCY,
        LINE_ID_A, LINE_ID_B,
        ICP_MATCH, INVOICE_MATCH, CURRENCY_MATCH, AMOUNT_MATCH,
        DOC_DATE_MATCH, POSTING_MONTH_MATCH,
        CONF, MATCH_KEY_USED, 'TRADE',
        CONF < 0.9999 AS REVIEW_REQUIRED
    FROM weighted
    -- Resolve duplicates: keep highest-confidence match per LINE_ID_A
    QUALIFY ROW_NUMBER() OVER (
        PARTITION BY LINE_ID_A ORDER BY CONF DESC, LINE_ID_B
    ) = 1;
    
    -- Identify unmatched A-side (lines without any match)
    INSERT INTO RESULTS.PHASE2_UNMATCHED (
        PERIOD_ID, PAIR_ID, CATEGORY, DOC_CURRENCY,
        LINE_ID, SIDE, UNMATCHED_REASON, PHASE3_REQUIRED
    )
    SELECT
        i.PERIOD_ID,
        CONCAT(LEAST(i.ENTITY_CODE, i.COUNTERPARTY_CODE),'_',
               GREATEST(i.ENTITY_CODE, i.COUNTERPARTY_CODE)),
        i.CATEGORY,
        i.DOC_CURRENCY,
        i.LINE_ID,
        'A',
        'NO_INVOICE_MATCH',
        TRUE
    FROM STAGING.IC_LINES i
    JOIN RESULTS.PHASE1_BALANCE_RECON p
      ON p.PERIOD_ID = i.PERIOD_ID
     AND p.ENTITY_A = i.ENTITY_CODE
     AND p.ENTITY_B = i.COUNTERPARTY_CODE
     AND p.CATEGORY = i.CATEGORY
     AND p.DOC_CURRENCY = i.DOC_CURRENCY
     AND p.PHASE2_REQUIRED = TRUE
    WHERE i.PERIOD_ID = :P_PERIOD_ID
      AND i.CATEGORY = 'Trade'
      AND i.IS_MIS = TRUE
      AND i.IS_OPEN = TRUE
      AND NOT EXISTS (SELECT 1 FROM RESULTS.PHASE2_LINE_MATCHES m WHERE m.LINE_ID_A = i.LINE_ID);
    
    -- Identify unmatched B-side (lines on the other side without any match)
    INSERT INTO RESULTS.PHASE2_UNMATCHED (
        PERIOD_ID, PAIR_ID, CATEGORY, DOC_CURRENCY,
        LINE_ID, SIDE, UNMATCHED_REASON, PHASE3_REQUIRED
    )
    SELECT
        i.PERIOD_ID,
        CONCAT(LEAST(i.ENTITY_CODE, i.COUNTERPARTY_CODE),'_',
               GREATEST(i.ENTITY_CODE, i.COUNTERPARTY_CODE)),
        i.CATEGORY, i.DOC_CURRENCY,
        i.LINE_ID, 'B',
        'NO_INVOICE_MATCH', TRUE
    FROM STAGING.IC_LINES i
    JOIN RESULTS.PHASE1_BALANCE_RECON p
      ON p.PERIOD_ID = i.PERIOD_ID
     AND p.ENTITY_B = i.ENTITY_CODE
     AND p.ENTITY_A = i.COUNTERPARTY_CODE
     AND p.CATEGORY = i.CATEGORY
     AND p.DOC_CURRENCY = i.DOC_CURRENCY
     AND p.PHASE2_REQUIRED = TRUE
    WHERE i.PERIOD_ID = :P_PERIOD_ID
      AND i.CATEGORY = 'Trade'
      AND i.IS_MIS = TRUE
      AND i.IS_OPEN = TRUE
      AND NOT EXISTS (SELECT 1 FROM RESULTS.PHASE2_LINE_MATCHES m WHERE m.LINE_ID_B = i.LINE_ID);
END;
$$;
```

### 11.3 Phase 2 Non-Trade matching (SQL pattern)

```sql
-- Similar to Phase 2 Trade but match key is amount+currency+posting_month
-- Steps 5-7 of the Non-Trade process
CREATE OR REPLACE PROCEDURE RESULTS.SP_RUN_PHASE2_NON_TRADE(P_PERIOD_ID VARCHAR)
RETURNS VARIANT
LANGUAGE SQL
AS
$$
BEGIN
    INSERT INTO RESULTS.PHASE2_LINE_MATCHES (
        PERIOD_ID, PAIR_ID, CATEGORY, DOC_CURRENCY,
        LINE_ID_A, LINE_ID_B,
        ICP_MATCH, AMOUNT_MATCH, CURRENCY_MATCH,
        SAME_MONTH_MATCH, WITHIN_2_MONTH_MATCH,
        RULE_BASED_CONFIDENCE, MATCH_KEY_USED, PROCESS_TYPE, REVIEW_REQUIRED
    )
    WITH variances AS (
        SELECT * FROM RESULTS.PHASE1_BALANCE_RECON
        WHERE PERIOD_ID = :P_PERIOD_ID
          AND PHASE2_REQUIRED = TRUE
          AND CATEGORY IN ('Non-trade', 'Loan', 'Accrued interest income and expenses', 'Transfer pricing')
    ),
    candidate_pairs AS (
        SELECT
            a.LINE_ID AS LINE_ID_A,
            b.LINE_ID AS LINE_ID_B,
            a.PERIOD_ID, a.CATEGORY, a.DOC_CURRENCY,
            a.ENTITY_CODE AS ENTITY_A, b.ENTITY_CODE AS ENTITY_B,
            -- Criteria
            TRUE AS ICP_MATCH,
            (ABS(ABS(a.DOC_AMOUNT) - ABS(b.DOC_AMOUNT)) < 0.01
             AND SIGN(a.DOC_AMOUNT) != SIGN(b.DOC_AMOUNT)) AS AMOUNT_MATCH,
            (a.DOC_CURRENCY = b.DOC_CURRENCY) AS CURRENCY_MATCH,
            (a.POSTING_MONTH = b.POSTING_MONTH) AS SAME_MONTH_MATCH,
            (DATEDIFF(MONTH,
                      TRY_TO_DATE(a.POSTING_MONTH || '-01', 'YYYY-MM-DD'),
                      TRY_TO_DATE(b.POSTING_MONTH || '-01', 'YYYY-MM-DD')) BETWEEN -2 AND 2) AS WITHIN_2_MONTH_MATCH
        FROM STAGING.IC_LINES a
        JOIN STAGING.IC_LINES b
          ON b.PERIOD_ID = a.PERIOD_ID
         AND b.ENTITY_CODE = a.COUNTERPARTY_CODE
         AND b.COUNTERPARTY_CODE = a.ENTITY_CODE
         AND b.CATEGORY = a.CATEGORY
         AND b.DOC_CURRENCY = a.DOC_CURRENCY
         AND ABS(ABS(a.DOC_AMOUNT) - ABS(b.DOC_AMOUNT)) < 0.01
         AND SIGN(a.DOC_AMOUNT) != SIGN(b.DOC_AMOUNT)
        JOIN variances v
          ON v.PERIOD_ID = a.PERIOD_ID
         AND v.ENTITY_A = a.ENTITY_CODE
         AND v.ENTITY_B = a.COUNTERPARTY_CODE
         AND v.CATEGORY = a.CATEGORY
         AND v.DOC_CURRENCY = a.DOC_CURRENCY
        WHERE a.PERIOD_ID = :P_PERIOD_ID
          AND a.IS_MIS AND a.IS_OPEN AND b.IS_MIS AND b.IS_OPEN
    ),
    weighted AS (
        SELECT *,
            (
                (CASE WHEN ICP_MATCH THEN 1 ELSE 0 END) * 0.30
              + (CASE WHEN SAME_MONTH_MATCH THEN 1 ELSE 0 END) * 0.05
              + (CASE WHEN CURRENCY_MATCH THEN 1 ELSE 0 END) * 0.10
              + (CASE WHEN AMOUNT_MATCH THEN 1 ELSE 0 END) * 0.50
              + (CASE WHEN WITHIN_2_MONTH_MATCH AND NOT SAME_MONTH_MATCH THEN 1 ELSE 0 END) * 0.05
            ) AS CONF
        FROM candidate_pairs
    )
    SELECT
        PERIOD_ID,
        CONCAT(LEAST(ENTITY_A, ENTITY_B), '_', GREATEST(ENTITY_A, ENTITY_B)),
        CATEGORY, DOC_CURRENCY,
        LINE_ID_A, LINE_ID_B,
        ICP_MATCH, AMOUNT_MATCH, CURRENCY_MATCH,
        SAME_MONTH_MATCH, WITHIN_2_MONTH_MATCH,
        CONF, 'amount+currency+month', 'NON_TRADE',
        CONF < 0.9999
    FROM weighted
    -- Greedy 1:1 assignment, highest confidence first
    QUALIFY ROW_NUMBER() OVER (
        PARTITION BY LINE_ID_A ORDER BY CONF DESC
    ) = 1
       AND ROW_NUMBER() OVER (
        PARTITION BY LINE_ID_B ORDER BY CONF DESC
    ) = 1;
END;
$$;
```

---

## 12. Phase 3 — Cortex Fuzzy Matching

### 12.1 Purpose

For lines that fail Phase 2 deterministic matching, generate vector embeddings and find nearest-neighbor candidates on the opposite side. This handles cases like:
- Cross-system identifier mismatches (EAS uses different doc-number format than EJP)
- Approximate amount matches (forex rounding)
- Description-similar items where the exact key differs

### 12.2 Embedding table

```sql
CREATE OR REPLACE TABLE STAGING.IC_LINES_EMBEDDINGS (
    LINE_ID                 NUMBER NOT NULL PRIMARY KEY REFERENCES STAGING.IC_LINES(LINE_ID),
    PERIOD_ID               VARCHAR(15) NOT NULL,
    EMBEDDING_MODEL         VARCHAR(50) NOT NULL,
    EMBEDDING               VECTOR(FLOAT, 1024),     -- Snowflake VECTOR datatype
    EMBEDDING_TS            TIMESTAMP_NTZ DEFAULT CURRENT_TIMESTAMP
);
```

### 12.3 Generate embeddings (only for unmatched + Phase3-required lines)

```sql
CREATE OR REPLACE PROCEDURE RESULTS.SP_GENERATE_EMBEDDINGS(P_PERIOD_ID VARCHAR)
RETURNS VARIANT
LANGUAGE SQL
AS
$$
BEGIN
    -- Embed only the unmatched lines (cost optimization — don't embed perfect matches)
    INSERT INTO STAGING.IC_LINES_EMBEDDINGS (LINE_ID, PERIOD_ID, EMBEDDING_MODEL, EMBEDDING)
    SELECT
        i.LINE_ID,
        i.PERIOD_ID,
        'snowflake-arctic-embed-l-v2.0',
        SNOWFLAKE.CORTEX.EMBED_TEXT_1024(
            'snowflake-arctic-embed-l-v2.0',
            i.DESCRIPTION_TEXT
        ) AS EMBEDDING
    FROM STAGING.IC_LINES i
    JOIN RESULTS.PHASE2_UNMATCHED u ON u.LINE_ID = i.LINE_ID
    WHERE i.PERIOD_ID = :P_PERIOD_ID
      AND u.PHASE3_REQUIRED = TRUE
      AND NOT EXISTS (SELECT 1 FROM STAGING.IC_LINES_EMBEDDINGS e
                      WHERE e.LINE_ID = i.LINE_ID);
    
    RETURN OBJECT_CONSTRUCT('embedded_lines', SQLROWCOUNT, 'period_id', :P_PERIOD_ID);
END;
$$;
```

### 12.4 Phase 3 fuzzy matching results

```sql
CREATE OR REPLACE TABLE RESULTS.PHASE3_FUZZY_MATCHES (
    FUZZY_MATCH_ID          NUMBER AUTOINCREMENT PRIMARY KEY,
    PERIOD_ID               VARCHAR(15) NOT NULL,
    PAIR_ID                 VARCHAR(50) NOT NULL,
    CATEGORY                VARCHAR(50) NOT NULL,
    DOC_CURRENCY            VARCHAR(3) NOT NULL,
    
    LINE_ID_A               NUMBER NOT NULL,
    LINE_ID_B               NUMBER NOT NULL,
    
    AMOUNT_DIFF             NUMBER(20,4),       -- abs(|a| - |b|)
    AMOUNT_DIFF_PCT         NUMBER(8,4),
    DATE_DIFF_DAYS          INT,
    COSINE_SIMILARITY       NUMBER(5,4),
    
    AI_CONFIDENCE           NUMBER(4,3),        -- Computed combined score
    RULE_BASED_CONFIDENCE   NUMBER(4,3),        -- Same as Phase 2 (for items that have any rule-based score > 0)
    
    REASONING               VARCHAR(2000),       -- From Cortex Complete (optional, see Phase 4)
    
    CANDIDATE_RANK          INT,                 -- 1 = top candidate
    
    RUN_TS                  TIMESTAMP_NTZ DEFAULT CURRENT_TIMESTAMP
);
```

### 12.5 Fuzzy matching procedure

```sql
CREATE OR REPLACE PROCEDURE RESULTS.SP_RUN_PHASE3_FUZZY(P_PERIOD_ID VARCHAR)
RETURNS VARIANT
LANGUAGE SQL
AS
$$
BEGIN
    INSERT INTO RESULTS.PHASE3_FUZZY_MATCHES (
        PERIOD_ID, PAIR_ID, CATEGORY, DOC_CURRENCY,
        LINE_ID_A, LINE_ID_B,
        AMOUNT_DIFF, AMOUNT_DIFF_PCT, DATE_DIFF_DAYS, COSINE_SIMILARITY,
        AI_CONFIDENCE, CANDIDATE_RANK
    )
    WITH unmatched_a AS (
        SELECT u.*, i.*, e.EMBEDDING
        FROM RESULTS.PHASE2_UNMATCHED u
        JOIN STAGING.IC_LINES i ON i.LINE_ID = u.LINE_ID
        JOIN STAGING.IC_LINES_EMBEDDINGS e ON e.LINE_ID = u.LINE_ID
        WHERE u.PERIOD_ID = :P_PERIOD_ID AND u.SIDE = 'A'
    ),
    unmatched_b AS (
        SELECT u.*, i.*, e.EMBEDDING
        FROM RESULTS.PHASE2_UNMATCHED u
        JOIN STAGING.IC_LINES i ON i.LINE_ID = u.LINE_ID
        JOIN STAGING.IC_LINES_EMBEDDINGS e ON e.LINE_ID = u.LINE_ID
        WHERE u.PERIOD_ID = :P_PERIOD_ID AND u.SIDE = 'B'
    ),
    candidates AS (
        SELECT
            a.PAIR_ID,
            a.CATEGORY,
            a.DOC_CURRENCY,
            a.LINE_ID AS LINE_ID_A,
            b.LINE_ID AS LINE_ID_B,
            ABS(ABS(a.DOC_AMOUNT) - ABS(b.DOC_AMOUNT)) AS AMOUNT_DIFF,
            ABS(ABS(a.DOC_AMOUNT) - ABS(b.DOC_AMOUNT)) / NULLIF(ABS(a.DOC_AMOUNT), 0) * 100 AS AMOUNT_DIFF_PCT,
            DATEDIFF(DAY, COALESCE(a.DOC_DATE, a.POSTING_DATE),
                          COALESCE(b.DOC_DATE, b.POSTING_DATE)) AS DATE_DIFF_DAYS,
            VECTOR_COSINE_SIMILARITY(a.EMBEDDING, b.EMBEDDING) AS COSINE_SIMILARITY,
            -- AI confidence: weighted combination of cosine + amount + date
            LEAST(
                0.5 * VECTOR_COSINE_SIMILARITY(a.EMBEDDING, b.EMBEDDING) +
                0.3 * (CASE
                       WHEN ABS(ABS(a.DOC_AMOUNT) - ABS(b.DOC_AMOUNT)) / NULLIF(ABS(a.DOC_AMOUNT), 0) < 0.01 THEN 1.0
                       WHEN ABS(ABS(a.DOC_AMOUNT) - ABS(b.DOC_AMOUNT)) / NULLIF(ABS(a.DOC_AMOUNT), 0) < 0.10 THEN 0.5
                       ELSE 0
                     END) +
                0.2 * (CASE
                       WHEN ABS(DATEDIFF(DAY, COALESCE(a.DOC_DATE, a.POSTING_DATE),
                                              COALESCE(b.DOC_DATE, b.POSTING_DATE))) < 30 THEN 1.0
                       WHEN ABS(DATEDIFF(DAY, COALESCE(a.DOC_DATE, a.POSTING_DATE),
                                              COALESCE(b.DOC_DATE, b.POSTING_DATE))) < 90 THEN 0.5
                       ELSE 0
                     END),
                1.0
            ) AS AI_CONFIDENCE
        FROM unmatched_a a
        JOIN unmatched_b b
          ON a.PAIR_ID = b.PAIR_ID
         AND a.CATEGORY = b.CATEGORY
         AND a.DOC_CURRENCY = b.DOC_CURRENCY
         AND SIGN(a.DOC_AMOUNT) != SIGN(b.DOC_AMOUNT)  -- Signs must oppose
        WHERE VECTOR_COSINE_SIMILARITY(a.EMBEDDING, b.EMBEDDING) > 0.70  -- Similarity threshold
    )
    SELECT
        :P_PERIOD_ID,
        c.PAIR_ID, c.CATEGORY, c.DOC_CURRENCY,
        c.LINE_ID_A, c.LINE_ID_B,
        c.AMOUNT_DIFF, c.AMOUNT_DIFF_PCT, c.DATE_DIFF_DAYS, c.COSINE_SIMILARITY,
        c.AI_CONFIDENCE,
        ROW_NUMBER() OVER (PARTITION BY c.LINE_ID_A ORDER BY c.AI_CONFIDENCE DESC) AS CANDIDATE_RANK
    FROM candidates c
    QUALIFY CANDIDATE_RANK <= 5;  -- Top 5 candidates per orphan line
    
    -- Update PROBABILITY_OF_MATCH on the orphans table
    MERGE INTO RESULTS.PHASE2_UNMATCHED u
    USING (
        SELECT LINE_ID_A AS LINE_ID, MAX(AI_CONFIDENCE) AS PROB
        FROM RESULTS.PHASE3_FUZZY_MATCHES
        WHERE PERIOD_ID = :P_PERIOD_ID AND CANDIDATE_RANK = 1
        GROUP BY LINE_ID_A
    ) c ON u.LINE_ID = c.LINE_ID
    WHEN MATCHED THEN UPDATE SET PROBABILITY_OF_MATCH = c.PROB;
    
    RETURN OBJECT_CONSTRUCT('phase3_candidates_generated', SQLROWCOUNT);
END;
$$;
```

### 12.6 Routing thresholds

| AI confidence | Action |
|---------------|--------|
| ≥ 0.80 | Send to Review Queue with both candidates' details |
| 0.60-0.80 | Send to Review Queue, flagged as low-confidence fuzzy match |
| < 0.60 | Don't auto-match, leave on Escalation Queue (Phase 4 takes over) |

---

## 13. Phase 4 — Cortex AI-Assisted Classification

### 13.1 Purpose

For lines that even fuzzy matching can't pair, ask Cortex Complete to classify the root cause and propose a journal entry. This handles structural issues like:
- One side hasn't booked the invoice yet (timing)
- Forex revaluation differences
- Comingled GL accounts (the EJP-ENF JPY 468M pattern)
- True one-sided items (non-existent on the counterparty side)

### 13.2 Output table

```sql
CREATE OR REPLACE TABLE RESULTS.PHASE4_CLASSIFICATIONS (
    CLASSIFICATION_ID       NUMBER AUTOINCREMENT PRIMARY KEY,
    PERIOD_ID               VARCHAR(15) NOT NULL,
    LINE_ID                 NUMBER NOT NULL,
    PAIR_ID                 VARCHAR(50),
    CATEGORY                VARCHAR(50),
    
    -- Classification
    ROOT_CAUSE_CATEGORY     VARCHAR(50),     -- 'TIMING_DIFFERENCE', 'FX_REVAL', 'COMINGLED_GL', 'MISSING_BOOKING', 'UNKNOWN'
    CONFIDENCE_IN_CLASSIFICATION NUMBER(4,3),
    
    -- Proposed action
    SUGGESTED_ACTION        VARCHAR(50),     -- 'PROPOSE_JE', 'FLAG_AND_HOLD', 'ESCALATE_TO_FINANCE'
    PROPOSED_JOURNAL        VARCHAR(2000),
    
    -- Reasoning
    REASONING               VARCHAR(2000),
    SIMILAR_ISSUE_ID        VARCHAR(50),     -- If matches a known recurring pattern
    
    -- Metadata
    MODEL_USED              VARCHAR(50),
    TOKENS_USED             INT,
    RUN_TS                  TIMESTAMP_NTZ DEFAULT CURRENT_TIMESTAMP
);
```

### 13.3 Cortex Complete prompt

The classification prompt is parameterized and templated. Stored in a procedure for centralized control.

```sql
CREATE OR REPLACE PROCEDURE RESULTS.SP_RUN_PHASE4_CLASSIFY(P_PERIOD_ID VARCHAR)
RETURNS VARIANT
LANGUAGE SQL
AS
$$
DECLARE
    classification_prompt VARCHAR := 
$$You are an intercompany reconciliation analyst. Given the following orphan line item that could not be matched against any counterparty entry, classify its root cause and propose a journal entry.

LINE DETAILS:
{LINE_JSON}

CONTEXT:
- Period: {PERIOD_ID}
- Pair: {PAIR_ID}
- Category: {CATEGORY}
- Currency: {CURRENCY}
- Phase 1 variance for this pair-category-currency: {VARIANCE}

KNOWN RECURRING PATTERNS for this pair (if any):
{KNOWN_ISSUES_JSON}

OUTPUT FORMAT (strict JSON):
{
  "root_cause_category": one of ["TIMING_DIFFERENCE", "FX_REVAL", "COMINGLED_GL", "MISSING_BOOKING", "OFFSET_OTHER_PERIOD", "UNKNOWN"],
  "confidence": 0.0 to 1.0,
  "reasoning": "explanation in 1-2 sentences",
  "suggested_action": one of ["PROPOSE_JE", "FLAG_AND_HOLD", "ESCALATE_TO_FINANCE"],
  "proposed_journal": "DR/CR entries with amounts and accounts" or null,
  "similar_issue_id": ID from REF_KNOWN_ISSUES if pattern matches, else null
}$$;
BEGIN
    INSERT INTO RESULTS.PHASE4_CLASSIFICATIONS (
        PERIOD_ID, LINE_ID, PAIR_ID, CATEGORY,
        ROOT_CAUSE_CATEGORY, CONFIDENCE_IN_CLASSIFICATION,
        SUGGESTED_ACTION, PROPOSED_JOURNAL, REASONING, SIMILAR_ISSUE_ID,
        MODEL_USED
    )
    WITH orphans AS (
        SELECT u.*, i.*,
               p.NET_VARIANCE,
               (SELECT ARRAY_AGG(OBJECT_CONSTRUCT('issue_id', ki.ISSUE_ID,
                                                  'description', ki.PATTERN_DESCRIPTION,
                                                  'root_cause', ki.ROOT_CAUSE,
                                                  'proposed_journal', ki.PROPOSED_JOURNAL))
                FROM REF.REF_KNOWN_ISSUES ki
                WHERE ki.ENTITY_A IN (i.ENTITY_CODE, i.COUNTERPARTY_CODE)
                  AND ki.ENTITY_B IN (i.ENTITY_CODE, i.COUNTERPARTY_CODE)
                  AND ki.CATEGORY = i.CATEGORY
                  AND ki.CURRENCY = i.DOC_CURRENCY) AS KNOWN_ISSUES
        FROM RESULTS.PHASE2_UNMATCHED u
        JOIN STAGING.IC_LINES i ON i.LINE_ID = u.LINE_ID
        JOIN RESULTS.PHASE1_BALANCE_RECON p
          ON p.PERIOD_ID = u.PERIOD_ID AND p.PAIR_ID = u.PAIR_ID
         AND p.CATEGORY = u.CATEGORY AND p.DOC_CURRENCY = u.DOC_CURRENCY
        WHERE u.PERIOD_ID = :P_PERIOD_ID
          AND u.PHASE3_REQUIRED = TRUE
          AND COALESCE(u.PROBABILITY_OF_MATCH, 0) < 0.60   -- Only items Phase 3 couldn't match
    ),
    classified AS (
        SELECT
            o.LINE_ID, o.PERIOD_ID, o.PAIR_ID, o.CATEGORY,
            SNOWFLAKE.CORTEX.COMPLETE(
                'claude-3-5-sonnet',
                ARRAY_CONSTRUCT(OBJECT_CONSTRUCT(
                    'role', 'user',
                    'content', REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(
                        :classification_prompt,
                        '{LINE_JSON}', TO_JSON(OBJECT_CONSTRUCT(
                            'entity', o.ENTITY_CODE,
                            'counterparty', o.COUNTERPARTY_CODE,
                            'gl_account', o.GL_ACCOUNT,
                            'reference', o.REFERENCE,
                            'doc_number', o.DOC_NUMBER,
                            'doc_date', o.DOC_DATE,
                            'posting_date', o.POSTING_DATE,
                            'doc_amount', o.DOC_AMOUNT,
                            'doc_currency', o.DOC_CURRENCY,
                            'text', o.SOURCE_TEXT
                        ))),
                        '{PERIOD_ID}', o.PERIOD_ID),
                        '{PAIR_ID}', o.PAIR_ID),
                        '{CATEGORY}', o.CATEGORY),
                        '{CURRENCY}', o.DOC_CURRENCY),
                        '{VARIANCE}', TO_VARCHAR(o.NET_VARIANCE)),
                        '{KNOWN_ISSUES_JSON}', COALESCE(TO_JSON(o.KNOWN_ISSUES), '[]')
                )),
                OBJECT_CONSTRUCT('temperature', 0.0, 'response_format', OBJECT_CONSTRUCT('type', 'json'))
            ) AS RESPONSE_JSON
        FROM orphans o
    )
    SELECT
        c.PERIOD_ID, c.LINE_ID, c.PAIR_ID, c.CATEGORY,
        c.RESPONSE_JSON:choices[0]:messages::VARCHAR AS RESPONSE_TEXT,
        TRY_PARSE_JSON(c.RESPONSE_JSON:choices[0]:messages::VARCHAR):root_cause_category::VARCHAR,
        TRY_PARSE_JSON(c.RESPONSE_JSON:choices[0]:messages::VARCHAR):confidence::FLOAT,
        TRY_PARSE_JSON(c.RESPONSE_JSON:choices[0]:messages::VARCHAR):suggested_action::VARCHAR,
        TRY_PARSE_JSON(c.RESPONSE_JSON:choices[0]:messages::VARCHAR):proposed_journal::VARCHAR,
        TRY_PARSE_JSON(c.RESPONSE_JSON:choices[0]:messages::VARCHAR):reasoning::VARCHAR,
        TRY_PARSE_JSON(c.RESPONSE_JSON:choices[0]:messages::VARCHAR):similar_issue_id::VARCHAR,
        'claude-3-5-sonnet'
    FROM classified c;
    
    RETURN OBJECT_CONSTRUCT('classifications_generated', SQLROWCOUNT, 'period_id', :P_PERIOD_ID);
END;
$$;
```

---

## 14. HITL Workflow (Three-Queue Model)

### 14.1 Queue tables

```sql
CREATE OR REPLACE TABLE HITL.CONFIRMATION_QUEUE (
    QUEUE_ITEM_ID           VARCHAR(36)  NOT NULL PRIMARY KEY,    -- UUID
    PERIOD_ID               VARCHAR(15)  NOT NULL,
    ITEM_TYPE               VARCHAR(30)  NOT NULL,                -- 'PHASE1_BALANCE_MATCH', 'PHASE2_PERFECT_MATCH'
    PAIR_ID                 VARCHAR(50)  NOT NULL,
    ENTITY_A                VARCHAR(15)  NOT NULL,
    ENTITY_B                VARCHAR(15)  NOT NULL,
    CATEGORY                VARCHAR(50)  NOT NULL,
    DOC_CURRENCY            VARCHAR(3)   NOT NULL,
    
    -- Phase 1 fields
    SUM_A                   NUMBER(20,4),
    SUM_B                   NUMBER(20,4),
    NET_VARIANCE            NUMBER(20,4),
    LINE_COUNT_A            INT,
    LINE_COUNT_B            INT,
    
    -- Phase 2 fields
    MATCH_ID                NUMBER,                                -- For Phase 2 perfect matches
    LINE_ID_A               NUMBER,
    LINE_ID_B               NUMBER,
    
    -- Confidence
    RULE_BASED_CONFIDENCE   NUMBER(4,3),
    AI_CONFIDENCE           NUMBER(4,3),
    
    -- Status & action
    STATUS                  VARCHAR(20)  NOT NULL DEFAULT 'PENDING_CONFIRMATION',  -- PENDING_CONFIRMATION, CONFIRMED, FLAGGED_FOR_INVESTIGATION
    ACTIONED_BY             VARCHAR(100),
    ACTIONED_AT             TIMESTAMP_NTZ,
    NOTES                   VARCHAR(1000),
    
    CREATED_AT              TIMESTAMP_NTZ DEFAULT CURRENT_TIMESTAMP
);

CREATE OR REPLACE TABLE HITL.REVIEW_QUEUE (
    QUEUE_ITEM_ID           VARCHAR(36) NOT NULL PRIMARY KEY,
    PERIOD_ID               VARCHAR(15) NOT NULL,
    ITEM_TYPE               VARCHAR(30) NOT NULL,                  -- 'PHASE2_BELOW_THRESHOLD', 'PHASE3_FUZZY_MATCH'
    PAIR_ID                 VARCHAR(50) NOT NULL,
    CATEGORY                VARCHAR(50),
    DOC_CURRENCY            VARCHAR(3),
    
    LINE_ID_A               NUMBER,
    LINE_ID_B               NUMBER,
    
    RULE_BASED_CONFIDENCE   NUMBER(4,3),
    AI_CONFIDENCE           NUMBER(4,3),
    
    -- Failed criteria (for context)
    FAILED_CRITERIA         ARRAY,                                  -- ['doc_date', 'posting_month']
    REASONING               VARCHAR(2000),                          -- AI explanation if available
    
    STATUS                  VARCHAR(30) NOT NULL DEFAULT 'PENDING_REVIEW',  -- PENDING_REVIEW, ACCEPT_MATCH, POST_JOURNAL, NO_ACTION, ESCALATE
    PRIORITY                INT NOT NULL DEFAULT 5,                  -- 1 (high) to 10
    ASSIGNED_TO             VARCHAR(100),
    ACTIONED_BY             VARCHAR(100),
    ACTIONED_AT             TIMESTAMP_NTZ,
    DECISION_NOTES          VARCHAR(2000),
    
    CREATED_AT              TIMESTAMP_NTZ DEFAULT CURRENT_TIMESTAMP
);

CREATE OR REPLACE TABLE HITL.ESCALATION_QUEUE (
    QUEUE_ITEM_ID           VARCHAR(36) NOT NULL PRIMARY KEY,
    PERIOD_ID               VARCHAR(15) NOT NULL,
    LINE_ID                 NUMBER NOT NULL,
    PAIR_ID                 VARCHAR(50),
    CATEGORY                VARCHAR(50),
    DOC_CURRENCY            VARCHAR(3),
    
    -- Phase 4 classification
    ROOT_CAUSE_CATEGORY     VARCHAR(50),
    CONFIDENCE_IN_CLASSIFICATION NUMBER(4,3),
    SUGGESTED_ACTION        VARCHAR(50),
    PROPOSED_JOURNAL        VARCHAR(2000),
    REASONING               VARCHAR(2000),
    SIMILAR_ISSUE_ID        VARCHAR(50),
    
    -- Reviewer action
    STATUS                  VARCHAR(30) NOT NULL DEFAULT 'PENDING_DECISION',
    DECISION                VARCHAR(50),                            -- 'POST_JOURNAL', 'CARRY_FORWARD', 'WRITE_OFF', 'INVESTIGATE_FURTHER'
    JOURNAL_ENTRY           VARCHAR(2000),
    ACTIONED_BY             VARCHAR(100),
    ACTIONED_AT             TIMESTAMP_NTZ,
    
    CREATED_AT              TIMESTAMP_NTZ DEFAULT CURRENT_TIMESTAMP
);
```

### 14.2 HITL action tracking — audit table

```sql
CREATE OR REPLACE TABLE AUDIT.HITL_ACTIONS (
    ACTION_ID               NUMBER AUTOINCREMENT PRIMARY KEY,
    PERIOD_ID               VARCHAR(15) NOT NULL,
    QUEUE_TYPE              VARCHAR(30) NOT NULL,                   -- 'CONFIRMATION', 'REVIEW', 'ESCALATION'
    QUEUE_ITEM_ID           VARCHAR(36) NOT NULL,
    USER_ID                 VARCHAR(100) NOT NULL,
    ACTION_TYPE             VARCHAR(50) NOT NULL,                   -- 'CONFIRM', 'FLAG', 'POST_JE', 'NO_ACTION', etc.
    ACTION_DETAILS          VARIANT,                                -- Full payload of what changed
    ACTION_TS               TIMESTAMP_NTZ DEFAULT CURRENT_TIMESTAMP
);
```

### 14.3 Streamlit-in-Snowflake UI structure

```python
# /apps/interco_recon/main.py
# Streamlit-in-Snowflake app

import streamlit as st
import pandas as pd
from snowflake.snowpark.context import get_active_session

st.set_page_config(page_title="Evident MIS Intercompany Reconciliation", layout="wide")
session = get_active_session()

# Sidebar — period selection + queue navigation
with st.sidebar:
    period = st.selectbox("Period", session.sql("SELECT PERIOD_ID FROM REF.REF_PERIODS WHERE STATUS != 'CLOSED' ORDER BY PERIOD_END_DATE DESC").to_pandas()['PERIOD_ID'])
    queue = st.radio("Queue", ["Dashboard", "Confirmation", "Review", "Escalation", "Reports"])

if queue == "Dashboard":
    st.title(f"Reconciliation Dashboard — {period}")
    # KPI tiles
    kpi_query = f"""
    SELECT
      (SELECT COUNT(*) FROM HITL.CONFIRMATION_QUEUE WHERE PERIOD_ID='{period}' AND STATUS='PENDING_CONFIRMATION') AS pending_confirm,
      (SELECT COUNT(*) FROM HITL.REVIEW_QUEUE WHERE PERIOD_ID='{period}' AND STATUS='PENDING_REVIEW') AS pending_review,
      (SELECT COUNT(*) FROM HITL.ESCALATION_QUEUE WHERE PERIOD_ID='{period}' AND STATUS='PENDING_DECISION') AS pending_escalate
    """
    # Display KPIs

elif queue == "Confirmation":
    st.title("Confirmation Queue — Phase 1 Balance Matches and Phase 2 Perfect Matches")
    df = session.sql(f"""
        SELECT * FROM HITL.CONFIRMATION_QUEUE
        WHERE PERIOD_ID='{period}' AND STATUS='PENDING_CONFIRMATION'
        ORDER BY ITEM_TYPE, ENTITY_A, ENTITY_B
    """).to_pandas()
    
    st.write(f"{len(df)} items pending confirmation")
    
    # Bulk action
    if st.button("Confirm all selected"):
        # Update status, log actions
        pass
    
    # Display with checkboxes for bulk operations
    for idx, row in df.iterrows():
        with st.expander(f"{row['ENTITY_A']} ↔ {row['ENTITY_B']} {row['CATEGORY']} {row['DOC_CURRENCY']}"):
            col1, col2 = st.columns(2)
            with col1:
                st.metric(f"{row['ENTITY_A']} Total", f"{row['SUM_A']:,.2f} {row['DOC_CURRENCY']}", f"{row['LINE_COUNT_A']} lines")
            with col2:
                st.metric(f"{row['ENTITY_B']} Total", f"{row['SUM_B']:,.2f} {row['DOC_CURRENCY']}", f"{row['LINE_COUNT_B']} lines")
            st.metric("Variance", f"{row['NET_VARIANCE']:,.2f}", delta=None)
            
            confirm_col, flag_col = st.columns(2)
            if confirm_col.button("Confirm", key=f"c_{row['QUEUE_ITEM_ID']}"):
                pass  # Update status
            if flag_col.button("Flag for investigation", key=f"f_{row['QUEUE_ITEM_ID']}"):
                pass

elif queue == "Review":
    st.title("Review Queue — Sub-1.00 Confidence Matches")
    df = session.sql(f"""
        SELECT q.*, 
               la.REFERENCE AS REF_A, la.DOC_NUMBER AS DOC_A, la.DOC_DATE AS DATE_A,
               la.DOC_AMOUNT AS AMT_A, la.DOC_CURRENCY AS CCY_A, la.SOURCE_TEXT AS TXT_A,
               lb.REFERENCE AS REF_B, lb.DOC_NUMBER AS DOC_B, lb.DOC_DATE AS DATE_B,
               lb.DOC_AMOUNT AS AMT_B, lb.DOC_CURRENCY AS CCY_B, lb.SOURCE_TEXT AS TXT_B
        FROM HITL.REVIEW_QUEUE q
        LEFT JOIN STAGING.IC_LINES la ON la.LINE_ID = q.LINE_ID_A
        LEFT JOIN STAGING.IC_LINES lb ON lb.LINE_ID = q.LINE_ID_B
        WHERE q.PERIOD_ID='{period}' AND q.STATUS='PENDING_REVIEW'
        ORDER BY q.PRIORITY ASC, q.RULE_BASED_CONFIDENCE DESC
    """).to_pandas()
    
    for idx, row in df.iterrows():
        with st.expander(f"Match conf={row['RULE_BASED_CONFIDENCE']:.2f}, AI={row.get('AI_CONFIDENCE',0):.2f} | {row['PAIR_ID']}"):
            col1, col2 = st.columns(2)
            with col1:
                st.write(f"**Side A**: {row['REF_A']} | {row['DOC_A']}")
                st.write(f"Date: {row['DATE_A']}, Amount: {row['AMT_A']:,.2f} {row['CCY_A']}")
                st.caption(row['TXT_A'])
            with col2:
                st.write(f"**Side B**: {row['REF_B']} | {row['DOC_B']}")
                st.write(f"Date: {row['DATE_B']}, Amount: {row['AMT_B']:,.2f} {row['CCY_B']}")
                st.caption(row['TXT_B'])
            
            st.write("**Failed criteria:**", row['FAILED_CRITERIA'])
            if row.get('REASONING'):
                st.info(f"AI reasoning: {row['REASONING']}")
            
            decision = st.radio(f"Decision_{row['QUEUE_ITEM_ID']}", 
                                ["Accept Match", "Post Journal", "No Action", "Escalate"])
            notes = st.text_area(f"Notes_{row['QUEUE_ITEM_ID']}")
            if st.button(f"Submit_{row['QUEUE_ITEM_ID']}"):
                pass  # Apply decision

elif queue == "Escalation":
    st.title("Escalation Queue — AI-Classified Orphans")
    # Similar pattern for Phase 4 outputs

elif queue == "Reports":
    st.title("Reports")
    # Period summary, comparison to prior period, audit log
```

---

## 15. Output Reports

### 15.1 `REPORTS.VW_PERIOD_SUMMARY` — Headline metrics

```sql
CREATE OR REPLACE VIEW REPORTS.VW_PERIOD_SUMMARY AS
SELECT
    p.PERIOD_ID,
    -- Phase 1
    COUNT(DISTINCT p.PAIR_ID) AS PAIRS_PROCESSED,
    COUNT_IF(p.BALANCE_MATCH) AS PHASE1_MATCHES,
    COUNT_IF(p.PHASE2_REQUIRED) AS PHASE1_VARIANCES,
    SUM(ABS(p.NET_VARIANCE)) FILTER (WHERE p.PHASE2_REQUIRED) AS TOTAL_VARIANCE_DOC_CURR,
    
    -- Phase 2
    (SELECT COUNT(*) FROM RESULTS.PHASE2_LINE_MATCHES m
     WHERE m.PERIOD_ID = p.PERIOD_ID AND m.RULE_BASED_CONFIDENCE >= 0.9999) AS PHASE2_PERFECT_MATCHES,
    (SELECT COUNT(*) FROM RESULTS.PHASE2_LINE_MATCHES m
     WHERE m.PERIOD_ID = p.PERIOD_ID AND m.RULE_BASED_CONFIDENCE < 0.9999 
       AND m.RULE_BASED_CONFIDENCE >= 0.50) AS PHASE2_REVIEW_MATCHES,
    
    -- Phase 3
    (SELECT COUNT(DISTINCT LINE_ID_A) FROM RESULTS.PHASE3_FUZZY_MATCHES f
     WHERE f.PERIOD_ID = p.PERIOD_ID AND f.AI_CONFIDENCE >= 0.80) AS PHASE3_FUZZY_MATCHES,
    
    -- Phase 4
    (SELECT COUNT(*) FROM RESULTS.PHASE4_CLASSIFICATIONS c
     WHERE c.PERIOD_ID = p.PERIOD_ID) AS PHASE4_CLASSIFICATIONS,
    
    -- HITL
    (SELECT COUNT(*) FROM HITL.CONFIRMATION_QUEUE WHERE PERIOD_ID = p.PERIOD_ID) AS CONFIRMATION_QUEUE_TOTAL,
    (SELECT COUNT(*) FROM HITL.CONFIRMATION_QUEUE WHERE PERIOD_ID = p.PERIOD_ID AND STATUS = 'CONFIRMED') AS CONFIRMED,
    (SELECT COUNT(*) FROM HITL.REVIEW_QUEUE WHERE PERIOD_ID = p.PERIOD_ID) AS REVIEW_QUEUE_TOTAL,
    (SELECT COUNT(*) FROM HITL.ESCALATION_QUEUE WHERE PERIOD_ID = p.PERIOD_ID) AS ESCALATION_QUEUE_TOTAL
FROM RESULTS.PHASE1_BALANCE_RECON p
GROUP BY p.PERIOD_ID;
```

### 15.2 `REPORTS.VW_MATCHED_DETAIL` — Match-level report

```sql
CREATE OR REPLACE VIEW REPORTS.VW_MATCHED_DETAIL AS
SELECT
    m.PERIOD_ID, m.PAIR_ID, m.CATEGORY, m.DOC_CURRENCY,
    a.ENTITY_CODE       AS ENTITY_A,
    a.REFERENCE         AS REF_A,
    a.DOC_NUMBER        AS DOC_A,
    a.DOC_DATE          AS DATE_A,
    a.DOC_AMOUNT        AS AMOUNT_A,
    b.ENTITY_CODE       AS ENTITY_B,
    b.REFERENCE         AS REF_B,
    b.DOC_NUMBER        AS DOC_B,
    b.DOC_DATE          AS DATE_B,
    b.DOC_AMOUNT        AS AMOUNT_B,
    m.RULE_BASED_CONFIDENCE,
    m.AI_CONFIDENCE,
    m.PROCESS_TYPE,
    m.MATCH_KEY_USED,
    CASE
        WHEN m.RULE_BASED_CONFIDENCE >= 0.9999 THEN 'PERFECT'
        WHEN m.RULE_BASED_CONFIDENCE >= 0.80 THEN 'HIGH'
        WHEN m.RULE_BASED_CONFIDENCE >= 0.50 THEN 'MEDIUM'
        ELSE 'LOW'
    END AS CONFIDENCE_BAND
FROM RESULTS.PHASE2_LINE_MATCHES m
JOIN STAGING.IC_LINES a ON a.LINE_ID = m.LINE_ID_A
JOIN STAGING.IC_LINES b ON b.LINE_ID = m.LINE_ID_B;
```

### 15.3 `REPORTS.VW_UNMATCHED_DETAIL` — Unmatched report with probability

```sql
CREATE OR REPLACE VIEW REPORTS.VW_UNMATCHED_DETAIL AS
SELECT
    u.PERIOD_ID, u.PAIR_ID, u.CATEGORY, u.DOC_CURRENCY,
    i.ENTITY_CODE, i.COUNTERPARTY_CODE,
    i.REFERENCE, i.DOC_NUMBER, i.DOC_DATE,
    i.DOC_AMOUNT, i.SOURCE_TEXT,
    u.SIDE,
    u.UNMATCHED_REASON,
    u.PROBABILITY_OF_MATCH,
    -- Top fuzzy candidate (if any)
    f.LINE_ID_B AS BEST_FUZZY_CANDIDATE_ID,
    f.AI_CONFIDENCE AS BEST_FUZZY_CONFIDENCE,
    f.COSINE_SIMILARITY,
    f.AMOUNT_DIFF,
    f.DATE_DIFF_DAYS,
    -- Phase 4 classification
    c.ROOT_CAUSE_CATEGORY,
    c.SUGGESTED_ACTION,
    c.PROPOSED_JOURNAL,
    c.SIMILAR_ISSUE_ID
FROM RESULTS.PHASE2_UNMATCHED u
JOIN STAGING.IC_LINES i ON i.LINE_ID = u.LINE_ID
LEFT JOIN RESULTS.PHASE3_FUZZY_MATCHES f
    ON f.LINE_ID_A = u.LINE_ID AND f.CANDIDATE_RANK = 1
LEFT JOIN RESULTS.PHASE4_CLASSIFICATIONS c
    ON c.LINE_ID = u.LINE_ID
ORDER BY u.PERIOD_ID, u.PAIR_ID, u.CATEGORY, ABS(i.DOC_AMOUNT) DESC;
```

### 15.4 `REPORTS.VW_PHASE1_DETAIL` — Balance reconciliation detail

```sql
CREATE OR REPLACE VIEW REPORTS.VW_PHASE1_DETAIL AS
SELECT
    p.*,
    CASE
        WHEN p.BALANCE_MATCH THEN '✓ Balance reconciles'
        WHEN p.KNOWN_ISSUE_ID IS NOT NULL THEN '⚠ Variance — known recurring issue'
        ELSE '✗ Variance — drill-down required'
    END AS RECON_STATUS,
    -- LC translated for top-line reporting
    p.NET_VARIANCE * COALESCE(
        (SELECT RATE FROM REF.REF_FX_RATES r
         WHERE r.RATE_DATE = (SELECT PERIOD_END_DATE FROM REF.REF_PERIODS WHERE PERIOD_ID = p.PERIOD_ID)
           AND r.FROM_CURRENCY = p.DOC_CURRENCY
           AND r.TO_CURRENCY = 'JPY'
           AND r.RATE_TYPE = 'CLOSE'),
        1
    ) AS NET_VARIANCE_JPY
FROM RESULTS.PHASE1_BALANCE_RECON p;
```

### 15.5 EJP-ECN Validation Report (regression test view)

```sql
CREATE OR REPLACE VIEW REPORTS.VW_EJP_ECN_VALIDATION AS
SELECT
    'Phase 1 USD balance match' AS METRIC,
    (SELECT BALANCE_MATCH FROM RESULTS.PHASE1_BALANCE_RECON
     WHERE PAIR_ID = 'EJP_ECN' AND CATEGORY = 'Trade' AND DOC_CURRENCY = 'USD'
     ORDER BY RUN_TS DESC LIMIT 1) AS RESULT,
    'TRUE' AS EXPECTED
UNION ALL
SELECT
    'Phase 1 CNY variance triggers drill-down',
    (SELECT PHASE2_REQUIRED::VARCHAR FROM RESULTS.PHASE1_BALANCE_RECON
     WHERE PAIR_ID = 'EJP_ECN' AND CATEGORY = 'Trade' AND DOC_CURRENCY = 'CNY'
     ORDER BY RUN_TS DESC LIMIT 1),
    'TRUE'
UNION ALL
SELECT
    'CNY variance amount',
    (SELECT TO_VARCHAR(NET_VARIANCE) FROM RESULTS.PHASE1_BALANCE_RECON
     WHERE PAIR_ID = 'EJP_ECN' AND CATEGORY = 'Trade' AND DOC_CURRENCY = 'CNY'
     ORDER BY RUN_TS DESC LIMIT 1),
    '-5428108.50'
UNION ALL
SELECT
    'Phase 2 perfect matches (CNY)',
    (SELECT COUNT(*)::VARCHAR FROM RESULTS.PHASE2_LINE_MATCHES
     WHERE PAIR_ID = 'EJP_ECN' AND CATEGORY = 'Trade' AND DOC_CURRENCY = 'CNY'
       AND RULE_BASED_CONFIDENCE >= 0.9999),
    '246'
UNION ALL
SELECT
    'Phase 2 review matches (CNY)',
    (SELECT COUNT(*)::VARCHAR FROM RESULTS.PHASE2_LINE_MATCHES
     WHERE PAIR_ID = 'EJP_ECN' AND CATEGORY = 'Trade' AND DOC_CURRENCY = 'CNY'
       AND RULE_BASED_CONFIDENCE < 0.9999 AND RULE_BASED_CONFIDENCE >= 0.50),
    '19'
UNION ALL
SELECT
    'Phase 2 unmatched ECN (residual)',
    (SELECT COUNT(*)::VARCHAR FROM RESULTS.PHASE2_UNMATCHED
     WHERE PAIR_ID = 'EJP_ECN' AND CATEGORY = 'Trade' AND DOC_CURRENCY = 'CNY' AND SIDE = 'B'),
    '72'
UNION ALL
SELECT
    'Total EJP-side reconciled (USD balance + CNY perfect + CNY review)',
    (SELECT TO_VARCHAR(
        163 +  -- USD covered by balance match (constant for now; should query)
        (SELECT COUNT(*) FROM RESULTS.PHASE2_LINE_MATCHES
         WHERE PAIR_ID = 'EJP_ECN' AND CATEGORY = 'Trade' AND DOC_CURRENCY = 'CNY'
           AND RULE_BASED_CONFIDENCE >= 0.50)
    )),
    '428';
```

---

## 16. Validation, Testing, and Acceptance Criteria

### 16.1 Pilot Acceptance Criteria

| ID | Test | Pass Threshold | Validation Method |
|----|------|----------------|-------------------|
| AT-1 | EJP-ECN Trade reconciles to 428 lines | Match exact | `REPORTS.VW_EJP_ECN_VALIDATION` returns RESULT = EXPECTED for all rows |
| AT-2 | Phase 1 runs in <30s for full MIS scope | t < 30s | Snowflake query history |
| AT-3 | Phase 2 runs in <2min for all variances | t < 120s | Snowflake query history |
| AT-4 | Phase 3 runs in <10min for residual | t < 600s | Snowflake query history |
| AT-5 | Phase 4 runs in <5min for orphans | t < 300s | Snowflake query history |
| AT-6 | All 17 entities have at least one adapter | 17 adapters present | `REF_ENTITY_ADAPTERS` row count |
| AT-7 | Data quality: <5% UNMAPPED rows | UNMAPPED < 5% | `STAGING.IC_LINES_DATA_QUALITY` |
| AT-8 | Phase 1 balance match rate ≥ 60% of pair-cat-curr combinations | balance_match / total ≥ 0.6 | `REPORTS.VW_PERIOD_SUMMARY` |
| AT-9 | HITL UI loads in <2 seconds | t < 2s | Streamlit performance |
| AT-10 | Audit trail captures every queue action | 100% coverage | `AUDIT.HITL_ACTIONS` row count vs queue mutations |

### 16.2 Regression Test Suite

```sql
-- Run after every code change
CREATE OR REPLACE PROCEDURE TESTING.SP_RUN_REGRESSION(P_PERIOD_ID VARCHAR)
RETURNS TABLE (test_name VARCHAR, expected VARCHAR, actual VARCHAR, passed BOOLEAN)
LANGUAGE SQL
AS
$$
DECLARE
    res RESULTSET;
BEGIN
    res := (
        SELECT
            METRIC AS TEST_NAME,
            EXPECTED,
            RESULT AS ACTUAL,
            EXPECTED = RESULT AS PASSED
        FROM REPORTS.VW_EJP_ECN_VALIDATION
    );
    RETURN TABLE(res);
END;
$$;
```

### 16.3 Synthetic Data Test Set

A controlled synthetic dataset with known matches/mismatches stored in `TESTING.SYNTHETIC_*` schemas to validate engine logic in isolation from real-data heterogeneity. Generated via `generate_synthetic_data.py` (already produced in earlier session).

---

## 17. Operational Considerations

### 17.1 Idempotency

Every stored procedure (RAW_TO_STAGING, SP_RUN_PHASE1, etc.) starts with `DELETE WHERE PERIOD_ID = :P_PERIOD_ID`. Re-running is safe.

### 17.2 Cost Management

- Cortex Embed: only generate embeddings for unmatched lines (typically 200-2000 per period). At ~$0.0001 per call, < $1/period.
- Cortex Complete: only run on Phase 4 orphans (typically < 200 per period). At ~$0.005 per call, < $1/period.
- Total Cortex cost per close: < $5/period.

### 17.3 Lineage and Audit

- `AUDIT.HITL_ACTIONS` captures every reviewer action
- `RAW.IC_LINES_RAW.RAW_ROW_JSON` preserves the original row from each Excel for any future investigation
- All matching results carry `RUN_TS` and `MATCH_KEY_USED` fields for forensic analysis

### 17.4 Error Handling

- Stored procedures wrap all writes in transactions
- Failed Cortex calls (rate limits, model errors) are retried with exponential backoff
- Adapter failures emit a row to `AUDIT.ADAPTER_ERRORS` and continue processing other files

### 17.5 Security

- PII: no PII in line item data (entity-level financial data only)
- Currency amounts and trading partner codes are confidential — restricted to `INTERCO_REVIEWER` role and above
- Cortex calls go through Snowflake's data-secure boundary (no data leaves Snowflake's perimeter)

### 17.6 Scheduling

```sql
-- Cron task: run after all bilateral files are loaded
CREATE OR REPLACE TASK INTERCO_RUN_PIPELINE
WAREHOUSE = INTERCO_INGEST_WH
SCHEDULE = 'USING CRON 0 18 6 * * UTC'   -- 6th of each month, 18:00 UTC
AS
BEGIN
    CALL STAGING.SP_RAW_TO_STAGING((SELECT MAX(PERIOD_ID) FROM REF.REF_PERIODS WHERE STATUS = 'OPEN'));
    CALL RESULTS.SP_RUN_PHASE1((SELECT MAX(PERIOD_ID) FROM REF.REF_PERIODS WHERE STATUS = 'OPEN'));
    CALL RESULTS.SP_RUN_PHASE2_TRADE((SELECT MAX(PERIOD_ID) FROM REF.REF_PERIODS WHERE STATUS = 'OPEN'));
    CALL RESULTS.SP_RUN_PHASE2_NON_TRADE((SELECT MAX(PERIOD_ID) FROM REF.REF_PERIODS WHERE STATUS = 'OPEN'));
    CALL RESULTS.SP_GENERATE_EMBEDDINGS((SELECT MAX(PERIOD_ID) FROM REF.REF_PERIODS WHERE STATUS = 'OPEN'));
    CALL RESULTS.SP_RUN_PHASE3_FUZZY((SELECT MAX(PERIOD_ID) FROM REF.REF_PERIODS WHERE STATUS = 'OPEN'));
    CALL RESULTS.SP_RUN_PHASE4_CLASSIFY((SELECT MAX(PERIOD_ID) FROM REF.REF_PERIODS WHERE STATUS = 'OPEN'));
END;
ALTER TASK INTERCO_RUN_PIPELINE RESUME;
```

---

## 18. Open Questions Pending Lloyd's Input

These need answers before v2.2; the spec includes placeholders for each so the build isn't blocked.

| # | Question | Impact if Default Wrong |
|---|----------|------------------------|
| 1 | OPEN status — source ERP flag, or PIC-set during recon? | Determines whether `IS_OPEN` is read from raw extract or computed |
| 2 | 1-month look-ahead for Non-Trade — do we need next month's GL? | Constrains close-cadence; if YES, recon can't run until day N+1 |
| 3 | Transfer Pricing — which matching process applies? | Currently routed to NON_TRADE; might need TRADE for some sub-cases |
| 4 | Confirmation Queue threshold — only 1.00 or also ≥ 0.95? | Volume of queue items; controller workload balance |
| 5 | Complete MIS Profit Center inventory per entity | Blocks accurate MIS filtering for non-EJP entities |
| 6 | EAS / ESG / EIND — does bilateral document number flow through their ERPs? | Determines Phase 2 match rate; if NO, falls back to Phase 3 fuzzy |
| 7 | EKR — can they provide raw invoice-level data? | Aggregated data caps EJP-EKR at balance-level matching only |
| 8 | Process variations for 3 known recurring issues (EJP-ENF, ETCE-MIS-USA, ETCE-ESG) | Whether to short-circuit to AUTO_PROPOSE_JE or not |
| 9 | GL Account mapping enrichment — incomplete in source for several entities | Determines categorization coverage; UNMAPPED rows skip matching |
| 10 | Reviewer roles, approval thresholds, escalation paths | Org workflow design for HITL UI |

---

## 19. Implementation Roadmap

### Phase A: Foundations (Week 1-2)

- [ ] Provision Snowflake account, database, schemas, roles, warehouses
- [ ] Load reference tables (Entities, GL Accounts, Currency mapping, Confidence weights, Tolerances)
- [ ] Build EJP and ECN adapters (validated)
- [ ] Implement `RAW_TO_STAGING` and Phase 1 procedures
- [ ] Run end-to-end on EJP-ECN; reproduce 428 validation
- [ ] Set up regression test gate

### Phase B: Adapter expansion (Week 3-5)

- [ ] EAS, EEU, EIND, ESG, ETCE adapters (highest-volume pairs)
- [ ] EJP AP-Other refinement (resolve 864 UNMAPPED rows)
- [ ] EJP-Cn pair MIS Profit Center inventory
- [ ] Run Phase 1 across all paired pairs; verify expansion of balance-match coverage

### Phase C: AI integration (Week 6-7)

- [ ] Phase 3 embeddings + fuzzy matching
- [ ] Phase 4 Cortex Complete classification
- [ ] Tune prompts against sample data using Cortex Code

### Phase D: HITL UI (Week 8-9)

- [ ] Streamlit-in-Snowflake confirmation tab
- [ ] Review tab with side-by-side comparison + criteria highlighting
- [ ] Escalation tab with proposed journal display + approval workflow
- [ ] Audit log views

### Phase E: Pilot run (Week 10)

- [ ] April 2026 close — run pipeline in parallel with manual process
- [ ] Reviewers compare outputs; pipeline is informational not authoritative
- [ ] Tune thresholds, refine prompts, fix bugs

### Phase F: Production (Week 11-12)

- [ ] May 2026 close — pipeline outputs are primary; manual is verification
- [ ] Build remaining adapters (ENF, EUSA NetSuite, EGZ, etc.)
- [ ] Roll out to all 35 MIS pairs

### Phase G: Expansion (Beyond)

- [ ] Add TNM business unit (after MIS stable)
- [ ] Tune known-issue auto-proposal for the 3 documented recurring patterns
- [ ] Quarterly model fine-tuning based on reviewer accept/reject signal

---

## Appendix A: Cortex Code Build Acceleration

During implementation, Cortex Code (Snowflake's AI-assisted developer environment) will be used to:

1. **Generate initial DDL skeletons** — pass natural-language schema description to Cortex Code, get first-draft DDL, then refine
2. **Iterate on Cortex Complete prompts** — test classification prompts against synthetic and real residual cases, refine system prompt
3. **Streamlit page templates** — generate first-draft Python from sketches/wireframes
4. **Test data generation** — generate synthetic IC line scenarios to test edge cases (cross-currency, multi-line journals, forex revaluation)
5. **Adapter scaffolding** — for each new entity, pass a sample tab to Cortex Code → get a draft adapter function

This is build-time only; runtime uses standard Cortex SQL functions.

---

## Appendix B: File Format Specification — Adapter Output Parquet

Schema (matching `RAW.IC_LINES_RAW`):

```
Field                Type        Required  Notes
source_file          STRING      Y         Original Excel file basename
source_tab           STRING      Y         Tab name within file
source_row_num       INT         Y         Row number for traceability
adapter_id           STRING      Y         REF_ENTITY_ADAPTERS.ADAPTER_ID
adapter_version      STRING      Y         For schema-change tracking
period_id            STRING      Y         '2026-03'
extract_ts           TIMESTAMP   Y         When adapter ran
entity_code          STRING      Y         REF_ENTITIES.ENTITY_CODE
entity_sap_code      STRING      N         e.g. '1096'
counterparty_code    STRING      Y         The other side of the pair
reference            STRING      N         Bilateral document number
doc_number           STRING      N         Local SAP/NetSuite doc number
text                 STRING      N         Description (truncate to 500)
gl_account           STRING      N         For categorization
doc_type             STRING      N
doc_date             DATE        N
posting_date         DATE        N
doc_currency         STRING      Y         Normalized (CNY not RMB)
doc_amount           DECIMAL     Y         Signed
lc_amount            DECIMAL     N
lc_currency          STRING      N
due_date             DATE        N
trading_partner      STRING      N
profit_center        STRING      N
bu_segment           STRING      N
is_open              BOOLEAN     Y         Default TRUE if source has no flag
raw_row_json         STRING      N         Full original row JSON for audit
```

File naming convention: `ic_lines_raw_<entity>_<period>_<adapter_id>_<extract_ts_iso8601>.parquet`

Example: `ic_lines_raw_EJP_2026-03_EJP_AR_MIS_v1_20260406T120000Z.parquet`

---

## Appendix C: Validation Checkpoints (Run After Every Code Change)

```sql
-- 1. Entity Accounts mapping count
SELECT COUNT(*) FROM REF.REF_ENTITY_GL_ACCOUNTS;
-- Expected: 94 baseline (will grow as Lloyd enriches)

-- 2. Adapters registered
SELECT COUNT(*) FROM REF.REF_ENTITY_ADAPTERS WHERE ACTIVE;
-- Expected: 6 baseline → 20+ at full coverage

-- 3. Confidence weights complete
SELECT PROCESS_TYPE, SUM(WEIGHT) FROM REF.REF_CONFIDENCE_WEIGHTS
WHERE EFFECTIVE_TO IS NULL GROUP BY PROCESS_TYPE;
-- Expected: TRADE=1.00, NON_TRADE=1.00

-- 4. Phase 1 EJP-ECN regression
SELECT * FROM REPORTS.VW_EJP_ECN_VALIDATION;
-- Expected: all PASSED = TRUE

-- 5. End-to-end smoke test
CALL TESTING.SP_RUN_REGRESSION('2026-03');
-- Expected: all assertions pass
```

---

*End of Specification — Version 2.1*
*Maintained by: Deloitte Engagement Team (Rupesh, Joe, Hock Ming)*
*Approved by: Lloyd (Evident) — pending sign-off on open questions in §18*
*Validation oracle: Samantha Tan (Evident)*
