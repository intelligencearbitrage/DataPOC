# MIS Intercompany Invoice Matching — Per-Entity Analysis and Consolidated Report

**Period:** March 2026  
**Scope:** MIS business unit only  
**Source:** 53 bilateral pair files in `Mar'26 entity level data.zip`  
**Status:** Pre-build analysis — to be incorporated into Snowflake Cortex AI Pilot Plan v2.1

---

## 1. Executive Summary

This document applies the documented Trade and Non-Trade matching processes (from the Process tab in `Interco_Process_Automation`) to the 53 bilateral pair files received from Evident, on a per-entity basis, for March 2026 MIS data.

**Headline numbers:**

| Metric | Value | Notes |
|--------|-------|-------|
| Bilateral pair files in scope | 53 | EJP information (28) + EEU/ETCE/ESCE information (25) |
| EJP-side MIS Trade rows (creditor side) | **1,775** | Across 11 EJP receivable files |
| EJP-side MIS Non-Trade rows (creditor side) | **174** | Across same 11 files |
| EJP-side MIS Other Payables (debtor side) | **539** | EEU file dominates (536 of 539) |
| Counterparty data formats observed | **5 distinct patterns** | EJP-Japanese, ECN-Master-Template, EAS-style, EKR-aggregate, ENF-multi-tab |
| **Validated deterministic matches (EJP-ECN Trade)** | **428** invoice-number matches | 406 at confidence 1.00 + 22 below 1.00 |
| Other pairs — deterministic matches achievable today | **0** without adapter work | Counterparty data is in entity-specific formats; needs parsers |

**The 428 figure is the EJP-ECN MIS Trade pair match count.** It is the only pair where both sides currently use compatible data structures (EJP's `sort_key` field equals ECN's `Document Number` field). All other pairs require entity-specific parser development before matching can run end-to-end.

---

## 2. The Matching Process — Recap

For every MIS reconciliation pair, the pipeline applies one of two documented processes depending on the GL account category. The category is determined by the GL account's classification per the Entity Accounts table.

### 2.1 The 10-step Trade matching process

Applied to GL accounts classified as **Trade** (the matching engine looks up the GL account in `REF_ENTITY_GL_ACCOUNTS` and routes to this process).

```
Steps 1-4 (gating logic — same as Non-Trade):
 1. Match ICP account code (counterparty pairing)
 2. Match the total balance by each Document Currency
    → If totals agree, no further action required
 3. If totals don't agree, locate GL lines with "OPEN" status
 4. Check sum of OPEN status lines = total entity balance

Steps 5-10 (Trade-specific, invoice-driven):
 5. Match the invoice number               (weight 0.20)
 6. Match the Document currency            (weight 0.20)
 7. Match the Document currency amount     (weight 0.20)
 8. Display unmatched invoices             (output bucket A)
 9. Display invoice match but currency/amount mismatch (output bucket B)
10. For matched invoices, categorize by posting date bucket
```

**Confidence formula:**
```
confidence = (icp_match × 0.30)
           + (invoice_match × 0.20)
           + (doc_curr_match × 0.20)
           + (amount_match × 0.20)
           + (doc_date_match × 0.05)
           + (posting_month_match × 0.05)
```
Confidence = 1.00 → confirmation only. Anything below 1.00 → review required.

### 2.2 The 7-step Non-Trade matching process

Applied to GL accounts classified as **Non-trade**, **Accrued interest**, **Loan**, or **Transfer pricing** (TBC for TP).

```
Steps 1-4 (gating logic — same as Trade):
 1-4: ICP code, currency totals, OPEN status, sum check

Steps 5-7 (Non-Trade-specific, amount-driven):
 5. Match OPEN lines on three criteria:
    Criterion 1: Same posting month        (weight 0.05)
    Criterion 2: Match doc currency amount  (weight 0.50) ← dominant
    Criterion 3: Match document currency    (weight 0.10)
 6. For unmatched, search subsequent 1 month  (weight 0.05)
 7. Display all unmatched lines
```

**Confidence formula:**
```
confidence = (icp_match × 0.30)
           + (range_date_same_month × 0.05)
           + (doc_curr_match × 0.10)
           + (amount_match × 0.50)
           + (range_date_2_month × 0.05)
```

### 2.3 Routing summary

```
For each GL line in raw extract:
  └─ Look up GL account in REF_ENTITY_GL_ACCOUNTS by (entity, account)
     └─ If category = Trade        → apply 10-step Trade process
     └─ If category = Non-trade    → apply 7-step Non-Trade process
     └─ If category = Loan         → apply 7-step Non-Trade process
     └─ If category = Accrued Int. → apply 7-step Non-Trade process
     └─ If category = TP           → TBD (needs Lloyd confirmation)
     └─ Else                       → ignore (not in MIS scope)
```

---

## 3. Per-Entity File and Tab Inventory

For each of the 17 MIS entities, this section identifies which file(s) contain that entity's MIS data and which tab(s) hold the actual invoice-level rows.

### 3.1 EJP (Evident Japan, parent) — Standard Pattern A

EJP appears as one side of nearly every MIS pair. Its data structure is highly consistent across all bilateral files.

**Tabs in any bilateral file involving EJP:**

| Tab name | Direction | Contents | Schema |
|----------|-----------|----------|--------|
| `EJP AR-T(MIS)` | EJP creditor | MIS Trade receivables to counterparty | 17 cols, Japanese+English headers, data from row 3 |
| `EJP AR-O(MIS)` | EJP creditor | MIS Other (Non-Trade) receivables | Same schema |
| `EJP AP-T(MIS)` | EJP debtor | MIS Trade payables (less common — only in some files) | Same schema |
| `EJP AP-O(MIS)` or `EJP AP-Other(MIS)` | EJP debtor | MIS Other payables | Same schema |
| `EJP AP-Other(MIS) 0331` etc. | EJP debtor | Date-suffixed AP-Other variants | Same schema |

**Column mapping (1-indexed):**

| Col | Field | Source field name (EN) | Source field name (JP) |
|-----|-------|------------------------|------------------------|
| A (1) | Bilateral document number | Reference | ソートキー (sort key) |
| B (2) | Internal text/inv ref | Text | テキスト |
| E (5) | GL Account | Account | G/L 勘定 |
| F (6) | EJP local SAP doc number | Document Number | 伝票番号 |
| H (8) | Document type | Document Type | 伝票タイプ |
| I (9) | Posting date | Document Date | 転記日付 (lit. "posting date") |
| J (10) | Document currency | Document currency | 伝票通貨 |
| K (11) | Doc amount | Amount in doc. curr. | 伝票通貨額 |
| L (12) | LC amount (JPY) | Amount in local currency | 金額 (国内通貨) |
| M (13) | Due date | Net due date | 支払期日 |
| N (14) | Trading partner code | Trading partner | 取引先コード |
| O (15) | Profit center | Profit Center | 利益センタ |

**Critical:** Filter rows by Profit Center to keep only MIS-tagged profit centers (per Samantha's note in meeting).

### 3.2 ECN (Evident China) — Standard Pattern B (Master Template)

ECN is the only counterparty in the dataset that fully populates the universal `Master (Trade)` and `Master (Non-Trade)` templates.

**Source:** `(EJP)_(ECN)03_2026 D1(0401) -Signed_Final.xlsx`

| Tab name | Contents | Schema |
|----------|----------|--------|
| `Master (Trade) (ECN 0203)` | MIS Trade payables to EJP | 14 cols per spec, data from row 31 |
| `Master (Non-Trade) (ECN 0203)` | MIS Non-Trade payables to EJP | Same schema |

**Column mapping:**

| Col | Field |
|-----|-------|
| C (3) | Company Code (7001 = ECN's local SAP code) |
| D (4) | Trading Partner code |
| E (5) | G/L Account (e.g. 2202101010 = ECN's Trade Payable account) |
| **F (6)** | **Document Number — equals EJP's `sort_key` field** |
| G (7) | Reference Number (PO) — usually null |
| H (8) | Posting Date |
| I (9) | Document Date |
| J (10) | BU / Segment (LS, IE, RVI, NDT, ANI) |
| K (11) | Amount in doc. curr. (signed: negative for AP) |
| L (12) | Document currency (note: "RMB" in some rows = "CNY") |
| M (13) | Amount in local currency |
| N (14) | Local currency code |

### 3.3 EAS (Evident Australia) — Pattern C (Native SAP Aging)

**Source (EJP receivable side):** `(EJP)_(EAS)3_2026 D 1(0401)Final.xlsx`

| Tab name | Contents | Schema |
|----------|----------|--------|
| `EAS` | EAS native AR aging report | 17 cols, English headers |
| `EAS(2)` | EJP-extracted historical view | EJP-style schema (Japanese + English) |

EAS uses 17 columns including: Account, Document Number, Account Description, Reference, Document Type, Net due date, Document Date, Posting Date, Document currency, Amount in doc. curr., Payment Block, Local Currency, Amount in local currency, Tax Code, Text, Clearing date, Clearing Document.

**Match key:** EAS's `Reference` column (col D) appears to be in similar 6-digit format as EJP's `sort_key`, but the value ranges don't overlap in the March 2026 data (EJP: 714xxx-717xxx; EAS: 702xxx-703xxx). This suggests EAS is showing older open items that EJP has since cleared, while EJP is showing newer March-period invoices that EAS hasn't yet booked. The Reference field is the right key candidate but matches will only appear once both sides have the same time period of activity.

### 3.4 EEU (Evident Europe HQ) — Pattern D (Multi-tab Native SAP)

**Source (EJP receivable side):** `(EJP)_(EEU)03_2026 D4(0406)_Fianl_Rev.xlsx` — but EEU's side is empty in the universal Master Trade tab.  
**Source (EJP payable side):** `EEU_EJP_03_31_2026(0406_rev).xlsx`

EEU's data lives in multiple custom tabs in the EJP payables file:

| Tab name | Row count | Contents |
|----------|-----------|----------|
| `EJP AP-Other(MIS) 0331` | 261 | EJP's view of Mar 31 cutoff |
| `EJP AP-Other(MIS) 0402(D1)` | 275 | EJP's view of Apr 2 cutoff |
| `EEU 0331 D2` | (varies) | EEU native SAP extract |
| `EEU Cash Pool 1126/1127/1128/1130` | 614-618 each | Treasury cash pool transactions |
| `EEU_EJP Cash Pool 1225` | 637 | Year-end cash pool |

EEU's transactions are largely treasury/cash-pool driven — these are intercompany loans and accrued interest, which fall under the **Non-Trade matching process** (no invoice numbers).

### 3.5 EKR (Evident Korea) — Pattern E (Aggregated)

**Source:** `(EJP)_(EKR)3_2026 D 4(0406)Final.xlsx`

| Tab name | Row count | Contents |
|----------|-----------|----------|
| `EKR(MIS)` | 49 (50 incl. header) | MIS-tagged AP balances — **aggregated, not invoice-level** |
| `EKR(TNM)` | 43 | TNM-tagged (out of scope) |

**EKR's tab has only 4 columns: Invoice, Amount, Currency, Text.** No date, no GL account, no posting date.

The Invoice numbers in EKR(MIS) are 9-digit (e.g. 100203281, 100203282) and **do NOT match EJP's 8-digit sort_keys** (e.g. 00714978, 00714979). These are different identifier systems. EKR's data appears to be aggregated by some logic (49 rows vs EJP's 447 invoices) — possibly grouped by EKR's internal document number per shipment lot rather than per invoice.

**Implication:** EJP-EKR matching cannot use the Trade process directly. Only amount-based fuzzy matching will work, and ambiguity is high (multiple EJP invoices may map to one EKR aggregate).

### 3.6 EUSA (Evident USA) — Pattern F (NetSuite Aging Report)

**Source (EJP payable side):** `EUSA - EJP - 03.31.2026.xlsx` — single tab `ROW`

EUSA uses NetSuite, completely different from SAP. The data is a "Custom A/R Aging With GL Account" report:

| Field | Format |
|-------|--------|
| Customer:Job | Vendor name |
| Transaction Type | Invoice / Credit Memo / Bill / etc. |
| Date | Transaction date |
| Document Number | NetSuite invoice format `IN-Ixxxxxx` or `CM-Ixxxxx` |
| **P.O. No.** | **Format `5511552314 - RA-I5683` (this is the cross-system match key)** |
| Due Date | |
| Age | Days outstanding |
| Open Balance | |
| Amount Due (Foreign Currency) | |
| Account: Name | GL account formatted as composite string |

EUSA also has multiple revision files (`EUSA-EJP_03_2026...20250402` and `EUSA-EJP_03_2026...20250410`) — pipeline must select the latest by suffix date.

**Match key for EUSA-SAP pairs:** The P.O. No. field carries an SAP-style reference. Specifically, `RA-Ixxxx` portion may match SAP's Reference field, or the leading numeric portion may match SAP's Document Number. Needs verification.

### 3.7 ETCE (Evident Czech Republic) — Pattern D (similar to EEU)

**Source (EJP receivable):** `(EJP)_(ETCE) 03_2026 D1(0401)_Final.xlsx` — counterparty side empty in this file  
**Source (EJP payable):** `ETCE_EJP_03_31 D3_rev.XLSX` — needs inspection  
**Source (EU hub):** `EJP - ETCE Summary.xlsx`, `ETCE_EJP_03_31 D3_rev.XLSX`, several `ETCE_*` files in EU hub receivables

ETCE follows EEU's multi-tab native SAP pattern. Its transactions span Trade, Non-Trade, Loan, and Transfer Pricing categories. The recurring `ETCE-vs-MIS-USA` USD 350k segment reclass and `ETCE-vs-ESG` JPY 2.6M forex revaluation patterns flagged in the consolidated workbook originate from ETCE's data.

### 3.8 ESG (Evident Singapore) — Pattern D variant (multi-tab SAP)

**Source:** `(EJP)_(ESG)3_2026 D 1(0401)Final.xlsx`

| Tab name | Row count | Contents |
|----------|-----------|----------|
| `Recon` | 38 | Reconciliation summary |
| `ESGFBL1N` | 192 | SAP transaction code FBL1N output (line items) |
| `ESG05`, `ESG26`, `ESG37` | 57 / 44 / 91 | Sub-account or period extracts |

ESG's `ESGFBL1N` tab is the most likely candidate for invoice-level data per Samantha's mention in the meeting that "you'll see the reference numbers are here. And then they probably can be matched back against the EJP file." Match key candidate: SAP `Reference` field if it carries EJP's bilateral document number.

### 3.9 EIND (Evident India) — Pattern unclear

**Source:** `(EJP)_(EIND)3_2026 D-1(0331)Final.xlsx` — counterparty data tabs not detected in scan  
**Source:** `EIND_EJP_3_0325.xlsx` — has small custom tabs (`EIND-AR` 8 rows, `EJP-AP` 6 rows)

EIND data volume is low. EJP's side has 211 trade rows but EIND's responses are sparse — suggesting EIND has fewer ICs with EJP at MIS scope or hasn't fully populated their template.

### 3.10 ENF (Evident NF) — Pattern G (very heterogeneous)

**Source (EJP receivable):** `(EJP)_(ENF)03_2026 D3(0403)_Final (1).xlsm`  
**Source (EJP payable):** `ENF_EJP_03.2026(Final)0403.xlsx`

ENF is the most complex entity. The bilateral file has 8+ custom data tabs:

| Tab name | Row count | Contents |
|----------|-----------|----------|
| `照合` (matching/verification) | 49 | Manual reconciliation worksheet |
| `ENF_未払金_利益センタ` (AP by profit center) | 103 | AP grouped by profit center |
| `ENF_未払金` (AP) | 118 | AP detail |
| `ENF_未払金 (3)` | 205 | Another AP variant |
| `ENF_CMS` | 914 | CMS (Cash Management System) extract |

Plus the recurring **EJP-vs-ENF JPY 468M reclass** issue documented in the consolidated workbook stems from ENF data. ENF will need its own dedicated adapter.

### 3.11 Other entities (ESCE, EGZ, ECDN, MIS-CND, PCND, MIS-USA, PUSA, EMEX, SPIND)

| Entity | File source | Inventoried row counts | Notes |
|--------|-------------|------------------------|-------|
| ESCE | `(EJP)_(ESCE)`, `ESCE _EJP_03_20260331.xlsx` | 0 in the receivable file; needs check on ESCE submission | Low MIS volume |
| EGZ | `EGZ-EJP 2026-03 (Final).xlsx`, `EGZ_EJP_03_25_2026.xlsx` | EGZ-EJP AP tab: 1,027 rows | Format unknown — needs adapter |
| ECDN | `(EJP)_(ECDN and MIS CANADA)`, `ECDN - EJP - MARCH 31_rev.xlsx` | 21 rows in `ECDN MIS (non-trade AP)` | Combines ECDN + MIS-CANADA |
| MIS-CND | bundled in ECDN file | as above | Two entities in one file |
| PCND, PIND, PUSA | dedicated files (`PCDN _EJP_...`, `PIND  _EJP_...`, `PUSA _EJP_...`) | Empty MIS AP tabs | These are Pramana entities, may have low MIS activity |
| MIS-USA | bundled with EUSA in MIS Canada files | NetSuite format | Treat similar to EUSA |
| EMEX | `Interco template Evident Scientific Mexico March 26.xlsx` | needs inspection | Mexico subsidiary |
| SPIND | not yet examined | TBD | Potentially small volume |

---

## 4. Per-Entity MIS Row Counts (March 2026)

This table summarizes MIS Trade and Non-Trade row counts on each entity's side, drawn from the bilateral pair files where data is populated.

### 4.1 EJP-side rows (creditor — receivables to counterparty)

From the 11 EJP receivable bilateral files. Source tab: `EJP AR-T(MIS)` and `EJP AR-O(MIS)`.

| Counterparty | EJP AR-T(MIS) | EJP AR-O(MIS) | Total EJP creditor side |
|--------------|---------------|---------------|------------------------|
| EAS | 95 | 0 | 95 |
| ECDN+MIS-Canada | 0 | 3 | 3 |
| **ECN** | **432** | **8** | **440** |
| EEU | 301 | 71 | 372 |
| EIND | 211 | 16 | 227 |
| EKR | 447 | 0 | 447 |
| ENF | 0 | 0 | 0 |
| ESCE | 0 | 0 | 0 |
| ESG | 150 | 44 | 194 |
| ETCE | 137 | 8 | 145 |
| EGZ | 0 | 0 | 0 |
| **TOTAL** | **1,773** | **150** | **1,923** |

### 4.2 EJP-side rows (debtor — payables to counterparty)

From the 17 EJP payable bilateral files. Source tab: `EJP AP-T(MIS)`, `EJP AP-O(MIS)`, or date-suffixed variants.

| Counterparty | EJP AP-T(MIS) | EJP AP-O(MIS) | Total EJP debtor side |
|--------------|---------------|---------------|----------------------|
| ECN | 0 | 3 | 3 |
| EEU | 0 | 536 | 536 |
| All others | 0 | 0 | 0 |
| **TOTAL** | **0** | **539** | **539** |

### 4.3 Counterparty-side row counts (where data is populated)

| Counterparty | Tab(s) used | Row count | Comment |
|--------------|-------------|-----------|---------|
| ECN | `Master (Trade) (ECN 0203)` + `Master (Non-Trade) (ECN 0203)` | 500 + 10 = 510 | Universal template |
| EAS | `EAS` + `EAS(2)` | 59 + 72 = 131 | Different time slices |
| EKR | `EKR(MIS)` | 49 | Aggregated, not invoice-level |
| EEU | Multiple custom tabs | ~3,000+ across cash pool tabs | Treasury-heavy |
| ENF | Multiple custom tabs | ~1,500+ across ENF_* tabs | Most complex entity |
| ESG | `ESGFBL1N`, `ESG05/26/37` | 192 + 57 + 44 + 91 = 384 | Multi-extract |
| EUSA | `ROW` (NetSuite) | varies | Single tab, NetSuite format |
| Others | (data not yet inventoried) | TBD | |

---

## 5. Match Testing Results — Per-Pair Application

### 5.1 EJP ↔ ECN (Trade) — VALIDATED

Applied the 10-step Trade process with full 6-criterion confidence scoring. This is the only pair where end-to-end matching runs successfully on the data as-received.

```
Source: (EJP)_(ECN)03_2026 D1(0401) -Signed_Final.xlsx
Side A: EJP AR-T(MIS) tab — 432 rows (after filtering Japanese footer artifacts)
Side B: Master (Trade) (ECN 0203) tab — 500 rows
Match key: EJP.sort_key (column A) = ECN.Document Number (column F)
```

**Step-by-step results:**

| Step | Description | Result |
|------|-------------|--------|
| 1 | ICP code match | All 428 candidate matches: ICP correctly references counterparty |
| 2 | Total balance per currency | NOT agreed — proceed to line-level matching |
| 3-4 | Locate OPEN status, verify sum | All rows treated as OPEN (period-end open items) |
| 5 | Match invoice number | 428 of 432 EJP rows find an ECN counterpart |
| 6 | Match doc currency | 428/428 currencies match (after RMB→CNY normalization) |
| 7 | Match doc amount | 428/428 amounts match (signs opposite, magnitudes equal within 0.01) |

**Confidence distribution of 428 matches:**

| Confidence | Count | Failed criteria | Action |
|------------|-------|-----------------|--------|
| **1.00 (perfect)** | **406** | None | **Confirmation tab only** |
| 0.95 | 11 | doc_date | Review — same posting month, different doc dates |
| 0.90 | 11 | doc_date AND posting_month | Review — cross-period booking timing |

**Final outputs per Trade process:**

- Step 8 (unmatched invoices): **4 EJP rows** (footer artifacts) + **72 ECN rows** (CNY 434k of "invoices not yet booked by EJP" — matches the consolidated workbook's residual)
- Step 9 (invoice match but currency/amount mismatch): **0**
- Step 10 (matched, posting date bucketing): 22 items in cross-period bucket

### 5.2 EJP ↔ ECN (Non-Trade) — Total balance reconciles

```
Source: (EJP)_(ECN)03_2026 D1(0401) -Signed_Final.xlsx
Side A: EJP AR-O(MIS) tab — 8 rows (4 transactional + 4 footer)
Side B: Master (Non-Trade) (ECN 0203) tab — 10 rows
```

Step 2 of the Non-Trade process requires checking if total balance per currency agrees.

```
EJP Non-Trade JPY total:  +4,457,854 (one-time payroll, expat costs)
ECN Non-Trade JPY total:  -4,457,854 (6 monthly accruals + bonuses + insurance refund)
```

**Result: Step 2 succeeds — totals agree. Per the documented process, "no further action required."** The 4 EJP lines and 9 ECN lines reconcile at the aggregate level even though they don't align line-for-line. This is a single confidence-1.00 balance match for the pair-currency combination, not 4 separate invoice matches.

### 5.3 EJP ↔ EAS (Trade) — Invoice key candidate exists, no current overlap

```
Source: (EJP)_(EAS)3_2026 D 1(0401)Final.xlsx
Side A: EJP AR-T(MIS) — 95 rows
Side B: EAS tab — 59 rows + EAS(2) tab — 72 rows
Match key candidate: EJP.sort_key vs EAS.Reference (column D)
```

**Result:** Both sides have a Reference field in the right format (6-digit numeric). EJP March 2026 sort_keys range 714xxx-717xxx; EAS open-items references range 702xxx-703xxx. **Zero overlap** — this means EAS is showing older open items not yet cleared while EJP is showing newer March-period invoices. The data is temporally misaligned. Once both sides catch up to the same period, matching should work.

For the pilot, this needs confirmation: is the temporal misalignment expected (EAS slower to book) or is there a data issue?

### 5.4 EJP ↔ EKR (Trade) — Different ID systems, amount-only fallback

```
Source: (EJP)_(EKR)3_2026 D 4(0406)Final.xlsx
Side A: EJP AR-T(MIS) — 447 rows
Side B: EKR(MIS) tab — 49 rows (only 4 columns: Invoice, Amount, Currency, Text)
```

**Result:**
- Invoice number match: **0** (EJP 8-digit sort_keys don't align with EKR's 9-digit invoice numbers)
- Amount-based match (Non-Trade approach as fallback): **5 unique matches** out of 447 EJP rows

EKR is providing **aggregated balances**, not raw invoice-level data. The 49 EKR rows likely represent grouped totals (by shipment, by week, etc.). True invoice-level matching is impossible until EKR provides raw extract.

**Implication:** EJP-EKR cannot be reconciled at invoice level with the data as-submitted. Either EKR needs to change their extraction format or matching has to be balance-level only (which is fine for the documented process — Step 2 covers this case).

### 5.5 Other pairs — Inventoried but not matched

| Pair | EJP-side rows | Counterparty data location | Match status |
|------|---------------|---------------------------|--------------|
| EJP ↔ EEU | 372 EJP receivable | EEU side empty in receivable file; 536 in EEU_EJP payable file | Adapter needed for EEU multi-tab format |
| EJP ↔ EIND | 227 EJP receivable | EIND side: 8 rows EIND-AR + 6 rows EJP-AP | Sparse data; format unclear |
| EJP ↔ ESG | 194 EJP receivable | ESG side: 384 rows across 4 tabs | Adapter needed for ESGFBL1N format |
| EJP ↔ ETCE | 145 EJP receivable | ETCE side empty in receivable file | Need to check ETCE_EJP and EU hub files |
| EJP ↔ ENF | 0 EJP receivable | ENF side: 1,500+ rows across 8+ tabs | ENF dominates; complex adapter |
| EJP ↔ EGZ | 0 EJP receivable | EGZ-EJP AP tab: 1,027 rows | Adapter needed |
| EJP ↔ EUSA | (in EJP payable file) | NetSuite ROW tab | NetSuite-specific adapter |
| ETCE ↔ ECN, EAS, EIND, EKR, ENF, ESG, EUSA, MIS-USA | (in EU hub) | Various EU hub files | Out of EJP-direct scope; phase 2 |

---

## 6. Consolidated Match Report (March 2026 MIS)

### 6.1 Summary by match outcome

| Outcome | Trade matches | Non-Trade matches | Total | Notes |
|---------|---------------|-------------------|-------|-------|
| **Confidence 1.00 (perfect, confirmation only)** | **406** | **1 balance match** | **407 events** | EJP-ECN Trade + EJP-ECN Non-Trade aggregate |
| Confidence 0.90-0.95 (review required) | 22 | 0 | 22 | EJP-ECN Trade — date timing |
| Sub-total — successfully matched | 428 | 1 | **429** | |
| Unmatched EJP-side (one-sided) | 4 footer artifacts | 0 | 4 | Pipeline filter handles |
| Unmatched counterparty-side (one-sided) | 72 ECN rows | 0 | 72 | "Invoices not yet booked by EJP" residual |
| **EJP-ECN pair fully accounted for** | 432 EJP + 500 ECN | 8 EJP + 10 ECN | **950 line items** | 428 + 72 + 4 = 504 (Trade); + Non-Trade aggregate balance |
| Other pairs — pending adapter development | 1,341 EJP receivable + 539 EJP payable | 142 EJP receivable | **2,022 EJP-side line items** | Cannot match until parsers built |
| Counterparty rows not yet parsed | ~5,000+ across other entities | (varies) | TBD | Adapter scope |

### 6.2 Headline number — what "deterministic matches" totals

**For the EJP-ECN MIS Trade pair: 428 invoice-number matches, 406 of which reach confidence 1.00 strictly.**

The 428 figure is *exclusively* the EJP-ECN Trade match count. It is NOT a sum across all MIS pairs because:

1. **Only EJP-ECN currently uses compatible data formats.** ECN populated the universal Master Trade template and ECN's `Document Number` field carries EJP's bilateral sort key. No other counterparty does this in the data we have.
2. **Other pairs have data, but in entity-specific formats requiring custom parsers (entity adapters).** Until those adapters are built and deployed, the matching engine cannot run end-to-end on those pairs.
3. **Some pairs have aggregated rather than invoice-level counterparty data** (EKR), which means even with an adapter, only balance-level matching is possible.

**Once entity adapters are built, the addressable Trade matching opportunity is approximately 1,773 EJP creditor-side invoice rows and an estimated 5,000+ counterparty rows.** With matching efficiency similar to EJP-ECN (98% of invoice rows finding counterparts), the achievable Trade match count across all MIS pairs would be in the range of **1,400-1,700 deterministic matches**, plus ~500 cross-period or one-sided items requiring HITL review.

### 6.3 Where each match outcome routes in the pipeline

```
DETERMINISTIC (confidence 1.00) — 406 EJP-ECN Trade + 1 EJP-ECN Non-Trade balance
  └─ HITL Confirmation Queue
     - Display matched pair side-by-side
     - Default action: Confirm (one-click)
     - Operator can flag for investigation if anomaly suspected

REVIEW REQUIRED (confidence 0.50-0.95) — 22 EJP-ECN Trade
  └─ HITL Review Queue
     - Show both sides + which criteria failed
     - Show AI-derived fuzzy confidence alongside rule-based confidence
     - Cortex Complete root-cause classification
     - Operator decides: Accept Match / Post Journal / No Action / Escalate

LOW CONFIDENCE / NO CANDIDATE (<0.50 or no match) — 72 ECN one-sided + 4 EJP footer
  └─ HITL Escalation Queue
     - Cortex Complete proposes journal type and root cause
     - For known recurring patterns (EJP-ENF reclass, ETCE-MIS-USA, etc.),
       pre-fill journal template from REF_KNOWN_ISSUES
     - Operator decides journal action

ALL OTHER PAIRS — pending adapter build
  └─ Held in raw landing tables until parser exists
     - Status report: "Adapter for entity X not yet implemented"
     - Out of scope until adapter library expanded
```

---

## 7. Implications for Snowflake Cortex AI Pilot Plan v2.1

### 7.1 Adapter library scope (the critical path)

Based on this analysis, the entity-adapter library needs **8 distinct parsers** to cover the MIS scope:

| Adapter | Coverage | Effort | Priority |
|---------|----------|--------|----------|
| EJP_AR_MIS | All EJP-as-creditor MIS files | Low (consistent format across files) | P0 |
| EJP_AP_MIS | All EJP-as-debtor MIS files | Low (similar to AR adapter) | P0 |
| ECN_Master_Template | EJP-ECN file specifically | Low (well-documented spec) | P0 — already validated |
| EAS_Native_Aging | EAS payable side | Medium (17-col schema) | P1 |
| EEU_Multi_Tab_SAP | EEU's Cash Pool + native SAP exports | High (multi-tab, large volume) | P1 |
| ENF_Multi_Tab_SAP | ENF's 8+ custom tabs | Very high (most complex entity) | P2 |
| ESG_FBL1N | ESG SAP transaction extracts | Medium | P1 |
| NetSuite_AR_AP_Aging | EUSA, MIS-USA | Medium-High (NetSuite schema) | P1 |
| EKR_Aggregate (fallback) | EKR aggregated balances | Low (only 4 cols) but matching is balance-only | P2 |
| ETCE_Native_SAP | ETCE multi-tab | Medium (similar to EEU) | P1 |
| Generic_TBD | EIND, EGZ, ECDN, PCDN, PIND, PUSA, EMEX, SPIND, ESCE | Per-entity inspection needed | P2-3 |

P0 = needed for MVP (EJP-ECN reproduction). P1 = needed for meaningful coverage (60-70% of MIS volume). P2 = full coverage. P3 = edge cases.

### 7.2 Profit Center filter requirement

Per Samantha's note in the meeting: every entity's data includes both TNM and MIS rows. The MIS filter is by Profit Center. The adapter config table needs a new column `MIS_PROFIT_CENTERS` (array) per entity. Inventory of which profit centers map to MIS for each entity is a follow-up data ask from Evident.

For EJP we have observed Profit Centers `1041`, `1042`, `1045`, etc. on MIS rows. Need to confirm the complete MIS profit center list per entity.

### 7.3 The EJP ↔ ECN model is the validation gold standard

Once the adapter library is built and the pipeline runs, the **EJP-ECN Trade pair must reproduce the 428 match count (406 perfect + 22 review)** as a regression test. Any divergence indicates an adapter or matching logic regression. This becomes the canonical test case in the CI/CD pipeline.

### 7.4 Dual confidence scoring architecture

Per the meeting agreement: every match candidate carries TWO confidence scores:

1. **Rule-based confidence** (from the documented truth-table formula in Process tab) — discrete values (1.00 / 0.95 / 0.90 / 0.85 / 0.80 / 0.60 / <0.50)
2. **AI fuzzy confidence** (from Cortex embeddings + similarity calculation) — continuous 0.00-1.00

Both display in the HITL queue. Divergences between them are themselves informative (e.g., rule-based says 0.80 but AI says 0.95 → likely a date format issue, not a real mismatch).

### 7.5 The 428 figure in the pilot plan

The plan should be explicit:

> **Validation target:** For the EJP-ECN MIS Trade pair in March 2026, the pipeline produces exactly 428 invoice-number matches, of which 406 reach rule-based confidence 1.00, 22 fall between 0.80-0.95, and 0 invoices are unmatched aside from 4 EJP footer artifacts and 72 one-sided ECN items (the "invoices not yet booked by EJP" residual that ties to the consolidated workbook's CNY 434k MIS-ECN Trade gap).

That sentence is the precise, defensible articulation of what we've validated. It can be quoted directly to Lloyd, Samantha, and the rest of Evident's team.

---

## 8. Open Questions Carried Forward to v2.1

(Unchanged from prior list — answers from Lloyd will refine v2.1 → v2.2.)

1. OPEN status — source ERP flag or PIC-added?
2. 1-month look-ahead for Non-Trade — does it require next month's GL data?
3. Transfer Pricing — Trade or Non-Trade matching process?
4. Confirmation queue threshold — only at 1.00, or also at ≥ 0.95?
5. MIS Profit Center inventory per entity — needed for adapter config
6. Whether bilateral document number flows for EAS, ESG (besides ECN)
7. EKR aggregated data — is invoice-level extract possible from their ERP?
8. Process variations for the three known recurring issues (EJP-ENF, ETCE-MIS-USA, ETCE-ESG)

---

*End of MIS Matching Analysis Report — to be incorporated into Snowflake Cortex AI Pilot Plan v2.1*
