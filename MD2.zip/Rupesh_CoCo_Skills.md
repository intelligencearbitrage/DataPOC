# Rupesh's Custom Cortex Code Skills

**Repository:** `~/.snowflake/cortex/skills/` (https://github.com/rudandekar/cortex-skills)  
**Author:** Deloitte FDE Practice  
**Platform:** Snowflake + Cortex Code

---

## Skills Inventory

| # | Skill Name | Category | Version | Status | Description |
|---|-----------|----------|---------|--------|-------------|
| 1 | [infa2dbt-accelerator](#1-infa2dbt-accelerator) | SQL Migration | 2.2.0 | Active | Informatica PowerCenter to dbt on Snowflake |
| 2 | [infa-xml-parser](#2-infa-xml-parser-agent-1) | SQL Migration (Agent) | 2.2.0 | Active | Parse PowerCenter XML into handoff objects |
| 3 | [infa-to-dbt-converter](#3-infa-to-dbt-converter-agent-2) | SQL Migration (Agent) | 2.2.0 | Active | RAG-enhanced dbt SQL generation |
| 4 | [conversion-fidelity-scorer](#4-conversion-fidelity-scorer-agent-3) | SQL Migration (Agent) | 1.0.0 | Active | Semantic equivalence validation & quarantine routing |
| 5 | [dbt-validation-critique](#5-dbt-validation-critique-agent-4) | SQL Migration (Agent) | 1.0.0 | Active | Compile, config, and coding guideline compliance |
| 6 | [phase1-handoff](#6-phase1-handoff-agent-5) | SQL Migration (Agent) | 1.0.0 | Active | Checkpoints and Gate 1 sign-off packages |
| 7 | [roi-subgraph-scorer](#7-roi-subgraph-scorer-agent-6) | SQL Migration (Agent) | 1.0.0 | Active | ROI tier classification for optimization priority |
| 8 | [dbt-sql-optimizer](#8-dbt-sql-optimizer-agent-7) | SQL Migration (Agent) | 1.0.0 | Active | Config and SQL optimization (Phase 4 & 5) |
| 9 | [informatica-source-target](#9-informatica-source-target) | SQL Migration (Agent) | 1.0.0 | Active | Source/target CSV extraction from PowerCenter XML |
| 10 | [sybase-to-snowflake](#10-sybase-to-snowflake) | SQL Migration | 0.3.0 | Active | Sybase ASE/IQ to Snowflake native SQL |
| 11 | [ConvertLegacySQL](#11-convertlegacysql) | SQL Migration | — | Active | End-to-end legacy SQL to dbt orchestrator |
| 12 | [AnalyzeLegacySQL](#12-analyzelegacysql) | SQL Migration (Sub-skill) | — | Active | Deconstruct legacy SQL into logic maps |
| 13 | [GenerateDbtModel](#13-generatedbtmodel) | SQL Migration (Sub-skill) | — | Active | Scaffold dbt models from logic maps |
| 14 | [ReconcileTables](#14-reconciletables) | SQL Migration (Sub-skill) | — | Active | Deep table comparison and data reconciliation |
| 15 | [OptimizeDbtModel](#15-optimizedbtmodel) | SQL Migration (Sub-skill) | — | Active | Query Profile guided performance optimization |
| 16 | [SnowConvertLegacySQL](#16-snowconvertlegacysql) | SQL Migration | — | Active | Legacy SQL Server/Oracle/Teradata to Snowflake SQL |
| 17 | [dbt-compile](#17-dbt-compile) | SQL Migration | — | Active | dbt compile, Jinja resolution, lineage extraction |
| 18 | [dbt-model-optimizer](#18-dbt-model-optimizer) | SQL Migration | 0.2.0 | Draft | Single-model 6-dimension optimization |
| 19 | [cortex-ml-classification](#19-cortex-ml-classification) | Generic | — | Active | Snowflake Cortex ML classification models |
| 20 | [operational-action-queue](#20-operational-action-queue) | Generic | — | Active | Streamlit HITL dashboards with action queues |
| 21 | [sensitive-data-governance](#21-sensitive-data-governance) | Generic | — | Active | Two-zone architecture, masking, RBAC, access controls |
| 22 | [hipaa-phi-governance](#22-hipaa-phi-governance) | Healthcare | — | Active | HIPAA PHI governance with Safe Harbor de-identification |
| 23 | [healthcare-analytics-accelerator](#23-healthcare-analytics-accelerator) | Healthcare | — | Active | End-to-end healthcare analytics orchestrator |

---

## Category Breakdown

### SQL Migration — 18 skills

The largest category, centered around the **INFA2DBT Accelerator** (8-agent pipeline) and supporting tools for legacy SQL conversion, dbt compilation, and Sybase migration.

### Generic — 3 skills

Cross-industry utilities for ML classification, operational dashboards, and data governance.

### Healthcare — 2 skills

HIPAA-compliant PHI governance and a crawl-walk-run healthcare analytics orchestrator.

---

## Skill Details

### 1. infa2dbt-accelerator

**Version:** 2.2.0 | **Category:** SQL Migration | **Location:** `agents/` + `sql-migration/INFA2DBT/`

Orchestrates the full Informatica PowerCenter to dbt conversion pipeline. Coordinates 8 specialized agents across 5 phases with 6 human-in-the-loop checkpoints.

**Pipeline Phases:**
| Phase | Description | Gate |
|-------|-------------|------|
| Pre-flight | Corpus coverage + scheduling audit | Gate 0 |
| Phase 1: Conversion | RAG-enhanced XML-to-dbt (Agents 1-5) | Gate 1 |
| Phase 2: Stabilization | Lift-and-shift to production (2+ business cycles) | Gate 2 |
| Phase 3: ROI Analysis | Query frequency, credit consumption, centrality (Agent 6) | Gate 3 |
| Phase 4: Config Optimization | Clustering, materialization (Agent 7A) | Gate 4 |
| Phase 5: SQL Optimization | CTE rewrites, predicate pushdown (Agent 7B) | Gate 5 |

**Key Features (v2.0+):**
- RAG-enhanced conversion via Cortex Search corpus
- Persistent state in Snowflake (PIPELINE_STATE, MODEL_REGISTRY, FIDELITY_SCORES)
- Collision-free model naming: `{xml_filename}_{seq}_{stg|int|mart}_{target}`
- Offline mode (`INFA2DBT_NO_STATE=1`) for disconnected operation
- Resume-from-failure with Snowflake-backed state

**Triggers:** `informatica to dbt`, `powermart conversion`, `workflow migration`, `INFA2DBT`

---

### 2. infa-xml-parser (Agent 1)

**Version:** 2.2.0 | **Category:** SQL Migration Agent

Parses Informatica PowerCenter XML exports and decomposes them into per-target-table handoff JSON objects. One workflow produces N handoff objects (one per target table).

**Key Capabilities:**
- Topological sort of sessions (Kahn's BFS on WORKFLOWLINK DAG)
- CONNECTOR-based target-to-mapping association
- Execution sequence and session name in handoffs
- Instance-to-target name resolution (v2.4 fix: +69% model yield)

**Output:** `{model}_handoff.json` with dbt model name, materialization, schema strategy, tags, and `ref()` dependencies.

**Triggers:** `Informatica workflow`, `PowerCenter XML`, `INFA export`, `parse INFA`

---

### 3. infa-to-dbt-converter (Agent 2)

**Version:** 2.2.0 | **Category:** SQL Migration Agent

Converts a single Informatica target table's transformation chain into a production-ready dbt model. The only agent that generates SQL code.

**Key Capabilities:**
- RAG-enhanced: queries Cortex Search corpus for conversion patterns before generating SQL
- Supports Expression, Filter, Aggregator, Lookup, Joiner, Source Qualifier transformations
- Registers models to Snowflake MODEL_REGISTRY
- Offline/no-state mode for disconnected environments

**Triggers:** `convert to dbt`, `informatica to snowflake`, `mapping conversion`, `generate dbt model`

---

### 4. conversion-fidelity-scorer (Agent 3)

**Version:** 1.0.0 | **Category:** SQL Migration Agent

Validates semantic equivalence between generated dbt models and original Informatica mapping logic. The only agent that can route models to quarantine.

**Scoring Dimensions (6):**
- Transformation Coverage (25%), Sequence Preservation (15%), Column Coverage (20%)
- Expression Translation (15%), Source Coverage (10%), Logic Validation (15%)

**Routing:** PASS (>=85%) | REVIEW (70-85%) | FAIL (<70%)

**Triggers:** `fidelity score`, `conversion accuracy`, `semantic equivalence`, `quarantine`

---

### 5. dbt-validation-critique (Agent 4)

**Version:** 1.0.0 | **Category:** SQL Migration Agent

Quality and compliance gate. Validates compile success, config compliance, SQL quality, schema documentation, and unit test coverage against coding guidelines.

**Key Role:** Produces structured critiques for Agent 2's retry cycle. Also the entry point for human-corrected quarantined models (bypasses Agents 1-3).

**Triggers:** `validate dbt model`, `compile check`, `config compliance`, `coding guidelines`

---

### 6. phase1-handoff (Agent 5)

**Version:** 1.0.0 | **Category:** SQL Migration Agent

Manages pipeline state across workflows. Runs three checkpoint types and produces Gate 1 sign-off packages. Never touches SQL directly.

**Checkpoints:**
- **A:** Per-workflow compile gate
- **B:** Every N workflows batch gate
- **C:** Full Phase 1 completion with Gate 1 sign-off package

**Triggers:** `checkpoint`, `Gate 1`, `sign-off package`, `batch checkpoint`

---

### 7. roi-subgraph-scorer (Agent 6)

**Version:** 1.0.0 | **Category:** SQL Migration Agent

Answers "which models should we optimize first?" by analyzing DAG subgraphs using production query patterns after 2+ business cycles.

**ROI Weights:**
- Query Frequency (30%), Bytes Scanned (25%), Credit Consumption (25%), Graph Centrality (20%)

**Tier Classification:** Tier 1 (>=0.70) | Tier 2 (>=0.40) | Tier 3 (<0.40)

**Triggers:** `ROI scoring`, `optimization priority`, `tier classification`, `Phase 3 analysis`

---

### 8. dbt-sql-optimizer (Agent 7)

**Version:** 1.0.0 | **Category:** SQL Migration Agent

Two sub-agents for dbt model optimization based on ROI tier prioritization:

| Sub-Agent | Phase | Scope | HITL |
|-----------|-------|-------|------|
| 7A (Config) | Phase 4 | Clustering, materialization | Autonomous |
| 7B (SQL) | Phase 5 | CTE rewrites, predicate pushdown | Per Pattern C |

**Triggers:** `optimize dbt`, `clustering`, `CTE rewrite`, `performance tuning`, `Phase 4`, `Phase 5`

---

### 9. informatica-source-target

**Version:** 1.0.0 | **Category:** SQL Migration Agent

Extracts source and target table mappings from PowerCenter XML into a flat CSV for impact analysis, lineage audits, and migration planning.

**Output:** CSV with columns `workflow_name, type (SOURCE/TARGET), table_name`

**Triggers:** `source target extract`, `lineage CSV`, `table mapping`, `impact analysis`

---

### 10. sybase-to-snowflake

**Version:** 0.3.0 | **Category:** SQL Migration

Converts Sybase ASE and IQ SQL scripts to Snowflake native SQL (DDL, DML, stored procedures, tasks, streams). Handles full migration lifecycle.

**Triggers:** `Sybase migration`, `ASE conversion`, `IQ migration`, `GETDATE`, `RAISERROR`, `GO batch separator`

---

### 11. ConvertLegacySQL

**Category:** SQL Migration (Orchestrator)

Orchestrates end-to-end conversion of legacy multi-target SQL scripts into optimized, target-specific dbt models. Calls four sub-skills in sequence.

**Sub-skill Chain:**
1. `AnalyzeLegacySQL` — Deconstruct and produce logic map
2. `GenerateDbtModel` — Scaffold dbt files from logic map
3. `ReconcileTables` — Data correctness verification
4. `OptimizeDbtModel` — Performance tuning

---

### 12. AnalyzeLegacySQL

**Category:** SQL Migration (Sub-skill of ConvertLegacySQL)

Deconstructs legacy SQL scripts into a structured `logic_map.json`. Uses Cortex AI SUMMARIZE for scripts over 1000 lines. Handles dynamic SQL by pausing for manual input.

---

### 13. GenerateDbtModel

**Category:** SQL Migration (Sub-skill of ConvertLegacySQL)

Generates staging (`stg_*.sql`) and marts model files from a `logic_map.json`. Automatically configures incremental materialization for UPDATE/MERGE patterns and adds `ref()` dependencies.

---

### 14. ReconcileTables

**Category:** SQL Migration (Sub-skill of ConvertLegacySQL)

Multi-stage data reconciliation: schema inspection (with FLOAT precision warnings), row count validation, and full data hash comparison with row-level diffs for debugging.

---

### 15. OptimizeDbtModel

**Category:** SQL Migration (Sub-skill of ConvertLegacySQL)

Guided Query Profile analysis for dbt models. Diagnoses spilling-to-disk and partition pruning issues, recommends warehouse sizing and clustering keys.

**Prerequisite:** Model reconciliation must pass before optimization.

---

### 16. SnowConvertLegacySQL

**Category:** SQL Migration

Step 1 of the legacy SQL migration pipeline. Converts SQL Server, Oracle, and Teradata syntax to Snowflake-native SQL, then chains to ConvertLegacySQL for dbt transformation.

**Source Detection:** Brackets/GETDATE (SQL Server), NVL/SYSDATE/ROWNUM (Oracle), QUALIFY/SEL (Teradata)

---

### 17. dbt-compile

**Category:** SQL Migration

Four capabilities for dbt compilation and validation:
1. **Basic compile** — Resolve Jinja, validate ref/source, report errors
2. **Snowflake validation** — EXPLAIN compiled SQL against live warehouse
3. **Compiled SQL diff** — Compare current vs previous compiled output
4. **Lineage extraction** — Build dependency graph from compiled SQL

---

### 18. dbt-model-optimizer

**Version:** 0.2.0 | **Category:** SQL Migration | **Status:** Draft

Single-model optimization across six dimensions using two sub-agents:

| Sub-Agent | Dimensions | Connection |
|-----------|-----------|------------|
| A: Static Analyzer | D1 (dialect cleanup), D2 (code quality), D3 (Snowflake-native), D4 (testing/docs) | None |
| B: Live Profiler | D5 (SQL performance), D6 (cost optimization) | Snowflake required |

---

### 19. cortex-ml-classification

**Category:** Generic

Build, train, evaluate, and deploy classification models using Snowflake Cortex ML CLASSIFICATION. Supports binary and multi-class prediction (no-show, churn, fraud, propensity).

**Workflow:** Use Case Discovery -> Data Discovery -> Feature Engineering -> Model Training -> Evaluation -> Deployment

**Triggers:** `classification`, `predict`, `no-show`, `churn`, `fraud`, `propensity`, `Cortex ML`

---

### 20. operational-action-queue

**Category:** Generic

Builds Streamlit dashboards with human-in-the-loop action queues for operational decision-making. Supports approve/override/defer workflows with audit trails.

**Triggers:** `action queue`, `approve`, `override`, `HITL`, `operational dashboard`, `review queue`

---

### 21. sensitive-data-governance

**Category:** Generic

Implements two-zone data architecture with automatic classification, masking policies, RBAC, and geographic access controls. Supports HIPAA, PCI-DSS, GDPR, SOX, and custom frameworks.

**Triggers:** `data governance`, `masking`, `two-zone`, `offshore access`, `PII`, `data classification`

---

### 22. hipaa-phi-governance

**Category:** Healthcare

Healthcare-specific extension of `sensitive-data-governance` with 18 HIPAA identifiers pre-configured, Safe Harbor compliant masking (ZIP -> first 3 digits, DOB -> year only), PHI-specific roles, and healthcare system patterns (EPIC, Cerner, Meditech).

**Triggers:** `HIPAA`, `PHI`, `healthcare governance`, `Safe Harbor`, `EPIC`, `Cerner`

---

### 23. healthcare-analytics-accelerator

**Category:** Healthcare

Orchestrates end-to-end healthcare analytics projects using a crawl-walk-run methodology. Coordinates three sub-skills:

| Phase | Sub-skill | Purpose |
|-------|-----------|---------|
| Foundation | `hipaa-phi-governance` | HIPAA compliance, PHI masking |
| Crawl | `cortex-ml-classification` | Predictive models |
| Walk | `operational-action-queue` | HITL operational dashboard |

**Use Cases:** No-Show prediction, Readmission, Revenue Cycle, Population Health, Capacity Planning

**Triggers:** `healthcare project`, `EPIC`, `Cerner`, `crawl walk run`, `clinical analytics`

---

## Supporting Files

| File | Description |
|------|-------------|
| `CLAUDE.md` | Engineering principles and agent persona (65K) |
| `SKILL-GUIDELINES.md` | Skill authoring standards and conventions |
| `DOCUMENTATION.md` | INFA2DBT technical architecture |
| `MIGRATION.md` | Snowflake infrastructure setup for INFA2DBT |
| `USAGE.md` | End-to-end INFA2DBT usage guide |
| `ROLES_AND_PRIVILEGES.md` | RBAC and security setup |
| `GAPS.md` | Known gaps and future work |
| `CHANGELOG.md` | Full version history (v2.0 through v2.4) |
| `config.yml` | Pipeline configuration template |

## Test Results (Wave 2 — Latest)

The INFA2DBT pipeline has been validated against a production-scale batch:

- **8,180 dbt models** generated across 6 directories
- **8,174 PASS** / 7 REVIEW / 0 FAIL
- **85.7% average fidelity** score
- All 6 scoring dimensions at **100% average**
