# Cisco Telemetry Pitch — Working Brief

**For:** Anand call (Cisco CETO Data and AI lead, IT owner; will bring in Vas Gambhir on IACV and CX leadership as needed)
**Track:** 1 of 2 (Telemetry / NPI). Track 2 (Renewal References / CRM) led by Balram and Subrata.
**Status:** Draft v0.1 — for alignment with Ankur before the Anand call.

---

## 1. Working Hypothesis

### The real problem

The way the brief reads, this is not a telemetry collection problem. It is an install base intelligence problem.

The data already exists in three places: BU-level Snowflake feeds with flat-file handoffs to the CX team led by Lavanya and Bhaskar, Varun's AWS S3 pipeline for telemetry processing, and whatever the CETO group is building under Anand. The gap is that none of this is being operationalized into commercial signal. The product BUs see telemetry as a service obligation, the CX team sees it at renewal time, and the sales and partner teams cannot reliably answer the one question that matters: is the installed hardware actually being used, by which customer, at what depth.

### Why this matters now

Three commercial outcomes ride on the answer to that question.

The $45bn refresh thesis over three to five years is unprovable at the customer level today. Cisco can size the eligible base from shipment data, but cannot validate which portion is live, which is shelfware, and which has already migrated to a competitor without anyone noticing.

The services and software renewal book is exposed because adoption decay surfaces too late. By the time a renewal conversation happens, the customer has either already disengaged or is using the renewal as leverage. Telemetry-driven early warning would change the timing of that conversation.

The AI INFRA product line is in the most adoption-sensitive moment of its life cycle. Without standardized NPI telemetry, the product team is optimizing roadmap decisions on incomplete signal exactly when competitors have far better visibility into customer behavior.

### Approach hypothesis

Our experience tells us the answer is an install base intelligence layer with three components.

First, NPI telemetry standardization. Every new product, starting with AI INFRA, ships with a telemetry standard enforced at the NPI gate. The product team does not get to ship without it. This is forward-looking discipline.

Second, install base unification. The existing fragmented signals from BU Snowflake feeds, CX flat files, and Varun's S3 pipeline get joined onto a single install base view with resolved customer identity. This is the unglamorous integration work that nobody owns today.

Third, three downstream operational motions on top of that view. NPI and product teams get feature adoption telemetry as roadmap input. CX teams get adoption decay as a renewal risk early warning, not a renewal-time discovery. Sales and partner teams get a live install base view that turns the $45bn refresh number from a thesis into a customer-by-customer pipeline.

### Testable outcomes

These are the metrics we would propose tracking, not promises.

Coverage: percentage of AI INFRA products with standardized telemetry at NPI gate, baseline today versus six months from now.

Lead time: average days between adoption decay signal and CX team intervention, today versus target.

Validation: dollar value of refresh opportunity validated by active telemetry signal versus shipment-based estimate.

Linkage: percentage of commerce quotes linked to opportunities, today versus target. This is where Track 1 and Track 2 converge on customer identity resolution.

---

## 2. Outside-In Benchmarks

Four reference points to bring into the Anand call. Sized half a page each so any one can become a slide later.

### NVIDIA — AI INFRA utilization as commercial signal

NVIDIA's enterprise AI products instrument GPU utilization deeply through Base Command and Mission Control. Utilization telemetry is not a service feature, it is the primary input to renewal motions on enterprise AI subscriptions and to upsell motions on capacity expansion. NVIDIA has turned "is the customer using what they bought" into a quantified commercial question rather than a qualitative customer success conversation.

The lesson for Cisco AI INFRA: NVIDIA-grade utilization telemetry is now table stakes for any product positioned in the AI infrastructure stack. A customer evaluating Cisco against NVIDIA partners will ask the utilization question directly. If the Cisco product cannot answer it, the product loses on a non-technical attribute.

### HPE GreenLake — consumption telemetry as architectural pattern

HPE's GreenLake consumption model forces telemetry by design. You cannot bill for what you cannot measure. The architectural pattern that emerged is one telemetry pipe feeding many consumers: a unified customer dashboard visible to CX, sales, product, and the customer themselves. Signal latency is days, not quarters.

The lesson for Cisco: even for products that are not sold as a service, the GreenLake instrumentation pattern is the architectural reference. One pipe, many consumers, near-real-time. The current Cisco pattern of BU-local Snowflake feeding flat files to CX is the architectural opposite of this and is the structural reason why install base intelligence does not exist today.

### Arista CloudVision — telemetry tied to renewal economics

Arista bundles CloudVision telemetry into the support contract. Customers who turn on CloudVision telemetry have measurably higher renewal rates, a correlation Arista has cited in investor materials. The mechanism is simple: telemetry feeds proactive support, proactive support builds renewal stickiness, renewal stickiness funds further telemetry investment.

The lesson for Cisco: telemetry is not a cost center. The investor case for an install base intelligence layer is not "we will collect more data," it is "telemetry coverage correlates with renewal rate, and we have the before-and-after numbers to prove it." That correlation is the business case, and Arista's public disclosures provide the precedent for stating it.

### Splunk — the inward question Cisco should expect

Cisco closed the Splunk acquisition in March 2024. Splunk is the leading observability platform in the market, and its post-acquisition customer data platform is built for exactly the kind of multi-source telemetry unification this initiative requires.

The question Anand should expect, from his own leadership if not from the Deloitte side, is: are we using what we already own to instrument our own install base? The cleanest framing for the pitch may be that Cisco does not have a tooling problem. It has an integration and discipline problem. The tools exist inside the company. The standards do not.

This is the benchmark to handle most carefully. It can land as insight or critique depending on internal political dynamics around the Splunk integration. Worth probing Anand on this before leading with it.

---

## 3. Discovery Questions for the Anand Call

Organized by hypothesis. Each question tests something specific. Anand is the IT owner, so the questions are calibrated to his vantage point. He will bring in Vas, Lavanya and Bhaskar, and the BU leaders as the conversation surfaces them.

### Hypothesis 1: The problem is fragmentation, not collection.

What percentage of Cisco products have telemetry instrumented today, and what percentage of that flows to a unified install base view rather than staying in BU-local Snowflake instances?

Where does telemetry data land end-to-end today: from device, through BU Snowflake, through flat files, into the CX team's hands, and on to anyone else?

Where does Varun's AWS S3 pipeline fit in this picture? Is it the unifier, a parallel system, or one BU's solution that we should generalize?

### Hypothesis 2: The CETO group is the natural builder, but the business outcome owners need to pull, not be pushed.

When you imagine this working in eighteen months, who is the primary user of the unified install base view? The CX team led by Lavanya and Bhaskar, Vas Gambhir's IACV team, the BU general managers, or someone else?

Are those teams pulling for this today, or is this a CETO-driven program that you are trying to seed demand for?

What is the funding model: central CETO investment or business-unit cost-share?

### Hypothesis 3: NPI standardization is forward leverage, the legacy base is near-term dollars.

For AI INFRA products specifically: is there a telemetry standard at the NPI gate today? Is it enforced or recommended?

For the existing $45bn refresh-eligible base: what percentage is on a hardware generation new enough to telemeter at all without retrofit?

What is the cost and feasibility of retrofitting telemetry on legacy hardware that customers are not motivated to update?

### Hypothesis 4: Track 1 and Track 2 are the same install base problem from two sides.

How is the install base resolved today across commerce data, opportunity data in the seller CRM, and telemetry data? Is there a single customer identifier, or is the join happening on company name and best-guess?

What does the IACV team's view of install base look like compared to the CX team's view and the BU's view? Are they reconcilable?

How would you want our two threads, the telemetry track and the renewal references track, to converge?

### Hypothesis 5: Splunk is in the room whether we name it or not.

How does the CETO group think about the relationship between this initiative and Splunk's observability platform?

Are there parts of this you would want to build on Splunk and parts you would want to keep separate?

### Hypothesis 6: There is history here we should know before we propose.

What has been tried before to solve install base intelligence at Cisco? What worked, what stalled, and why?

Are there political constraints we should know about? For example, BUs that prefer their telemetry not be visible to the CX team or to sales?

### Open questions

What does success look like for you personally on this in the next two quarters?

Where should Deloitte not be? What scope would you prefer to keep internal to Cisco?

---

## 4. Open Items to Clarify With Ankur Before the Call

Three things that would change the angle materially.

**Scope.** AI INFRA products only or full Cisco portfolio? The NPI framing in the brief suggests narrower; the install base validation framing suggests broader. The pitch lands very differently in each case.

**Outcome owner.** Ankur's note assumes Anand will work with Vas and others. Does Ankur have a view on which business outcome owner the engagement should serve first: CX, IACV, or product/NPI? This determines what success looks like and how we measure value at stake.

**History.** Has Cisco run a prior install-base intelligence program that stalled? If yes, that is the most important context for the call, and Ankur likely knows or can find out quickly.
