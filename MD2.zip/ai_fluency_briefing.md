# AI Fluency Bootcamp
## Briefing & Discussion Guide
**Prepared by:** Rupesh Dandekar | **Date:** March 2026  
**For:** Oracle DBA (Brother) & Electronics Engineering Student (Nephew)

---

## How to Use This Document

This is your facilitation guide for today's session. Each section has:
- **The briefing content** — what you want them to understand
- **Discussion prompts** — questions to spark conversation
- **Watch-for signals** — things that will tell you where they are mentally

Work through it in order. The first section (Five Core Concepts) is shared — do it together before splitting into the two curricula.

---

## Part 1 — The Fundamental Shift
### For Both Participants Together (~20 minutes)

> **Facilitator note:** Start here. These five concepts are the shared foundation. Every other topic in both curricula builds on at least one of them. If either person is fuzzy on any of these, don't move on — work through it with an analogy from their domain.

---

### The Big Picture (Open With This)

AI is not a tool you consume. It is infrastructure you compose.

The practitioners who win in the next five years are not the ones who use AI the most — they are the ones who understand how to *wire it into systems that produce real work*. Both of you have the technical depth to do exactly that, and faster than most people starting from scratch.

**What separates the two groups:**
- Group A (most people): uses ChatGPT or Claude as a better search engine, copy-paste outputs, occasional wow moment
- Group B (the builders): understands the architecture, writes prompts with intent, connects AI to real systems, builds agents that run unsupervised

Today is about getting you both firmly into Group B — with a concrete path to get there.

---

### Concept 1 — LLMs as Reasoning Engines, Not Search Engines

**The core idea:** A large language model does not retrieve information from a database. It generates tokens based on patterns learned during training. Every output is probabilistic — the same prompt can produce different outputs on different runs.

**Why this matters in practice:**
- You cannot trust outputs blindly. You need a calibration process (run it on problems you already know the answer to, observe where it fails, build mental error bars).
- Prompts are not queries. A database query either finds the row or it doesn't. A prompt shapes a reasoning process — precision matters differently.
- Hallucination is not a bug to be fixed — it is an intrinsic property of the architecture. The mitigation is design: retrieval, grounding, verification steps.

**For the DBA:** Think of it less like `SELECT * FROM knowledge WHERE topic = 'X'` and more like hiring a very well-read consultant who answers from memory. You would verify what a consultant tells you. Do the same here.

**For the EE student:** Think of it as a system that generates output signals based on a learned transfer function. The input (prompt) shapes the output, but there is noise in the channel and the function is not fully deterministic.

> **Discussion prompt:** *Have you ever gotten a confidently wrong answer from Claude or ChatGPT? What did you do with it? That instinct — to verify — is exactly right. Let's talk about how to build that verification into workflows.*

---

### Concept 2 — Context Window as Working Memory

**The core idea:** Every conversation with an LLM starts fresh. The model has no memory of previous conversations unless you explicitly include that context in the current prompt. The "context window" is the total amount of text the model can hold in its working memory at once — currently somewhere between 100,000 and 200,000 tokens for frontier models (roughly 75,000–150,000 words).

**Why this matters in practice:**
- Everything you want the model to know must be in the prompt. Background, constraints, examples, format requirements — it all lives in the context.
- Long conversations degrade. As the context fills up, earlier content gets less weight or is dropped entirely. This is why structured context management (like the CLAUDE.md pattern) matters.
- Prompt engineering is fundamentally memory management. A well-designed system prompt is like a well-designed SGA — it puts the right information in the right place.

**The implication for production AI:** Most teams underestimate how much context design matters. The difference between an AI that gives useful outputs and one that gives generic outputs is almost always the quality of what's in the context window.

> **Discussion prompt:** *If the model can only see what's in the current conversation, how would you design a persistent "DBA persona" that knows your environment every time you start a new chat? What would you put in it? This is exactly what Claude Projects solves — let's look at one.*

---

### Concept 3 — Tool Use / Function Calling

**The core idea:** An LLM on its own can only generate text. Tool use is the mechanism that lets the model take actions in the real world — run a SQL query, call an API, read a file, search the web. You define a function (tool), describe what it does in natural language, and include it in the model's context. The model then decides when to call it and what parameters to pass. The result comes back to the model, which incorporates it into its response.

**Why this matters in practice:**
- This is the bridge between "AI that talks about doing things" and "AI that does things."
- The model's reasoning about *when* to call a tool is itself a form of intelligence — it's deciding whether its own knowledge is sufficient or whether it needs to look something up.
- Tool definitions are prompts. How you describe a tool (name, description, parameters) directly affects whether the model uses it correctly.

**A concrete example for the DBA:**
```python
# You define this function
def get_explain_plan(sql: str, connection_string: str) -> str:
    """
    Returns the execution plan for a given SQL statement.
    Use this when the user asks why a query is slow or how Oracle is executing it.
    """
    # your actual Oracle connection + EXPLAIN PLAN logic
    ...

# You tell Claude this tool exists
# Claude decides: "User asked why their query is slow → I should call get_explain_plan"
# Claude calls it with the right SQL
# Claude gets the plan back and explains it in English
```

> **Discussion prompt:** *What are the five most repetitive, well-defined tasks in your current DBA work that follow a consistent pattern? Those are your first five tool candidates. For you (nephew) — what external data sources would make an AI assistant genuinely useful for your coursework?*

---

### Concept 4 — Agents = LLM + Tools + Loop

**The core idea:** An agent is simply an LLM that can take actions, observe the results, and decide what to do next — running in a loop until a goal is achieved. There is no magic. The architecture is:

```
PERCEIVE  →  PLAN  →  ACT  →  OBSERVE  →  REFLECT  →  (repeat or stop)
```

The model receives a goal, breaks it into steps, executes a step using a tool, observes the result, updates its plan, and continues. This is identical to how a skilled human approaches a multi-step task.

**Why this matters in practice:**
- Most valuable work is multi-step. Single-turn Q&A is a small fraction of what AI can do.
- Failure modes in agents come from: poor tool definitions, insufficient error handling, missing stopping conditions, and lack of human-in-the-loop checkpoints. These are engineering problems, not AI problems.
- You don't need a framework to build an agent. A while loop in Python + Claude API + a few functions is an agent. Start there before reaching for LangChain or LangGraph.

**For the DBA:** A scheduled job that checks alert logs, queries V$SESSION, and pages you when something is wrong is already structurally an agent. The AI layer adds: natural language interpretation of what's wrong, reasoning about likely causes, and draft remediation — not just detection.

**For the EE student:** The agentic loop is identical to a microcontroller's sense-decide-actuate cycle. The LLM is the decision layer. You already understand every other part of this system.

> **Discussion prompt:** *Describe a multi-step task you do regularly at work (or in your coursework) that has a reasonably consistent structure. Let's sketch what an agent that handles that task would look like — what tools it would need, where it would need human approval, what success looks like.*

---

### Concept 5 — MCP: USB-C for AI

**The core idea:** Model Context Protocol (MCP) is an open standard published by Anthropic that defines a uniform way for AI models to connect to external systems — databases, APIs, file systems, services. Instead of writing custom integration code for every tool, you build (or use) an MCP server that exposes your system's capabilities as a standardized interface. The AI connects to it like a peripheral.

**Why this matters in practice:**
- Without MCP: every AI integration is bespoke. You write glue code for each tool, each model, each workflow. Doesn't scale.
- With MCP: write the server once, use it from Claude Code, Claude.ai (with connectors), or any MCP-compatible client. The server describes its own capabilities — the AI discovers what it can do.
- The ecosystem is growing fast. In 2026 there are already MCP servers for Salesforce, GitHub, Postgres, Slack, Google Drive, and dozens more. This is the integration layer that makes enterprise AI actually viable.

**The analogy that makes it click:**
- USB-C is a standard that lets a laptop talk to a monitor, a keyboard, a hard drive, a camera — without custom drivers for each device. The device advertises its capabilities; the OS handles the rest.
- MCP is the same idea. The AI is the laptop. Your database, your API, your file system — those are the peripherals. MCP is the port standard.

> **Discussion prompt:** *If you could give Claude access to any three systems in your current work environment, what would they be? What would you want it to be able to do with each? That's your MCP backlog.*

---

## Part 2 — Curriculum 1: Oracle Exadata DBA
### Individual Deep-Dive (~30 minutes)

> **Facilitator note:** Your nephew can stay for this — some of it is directly applicable. But the emotional weight of this section should land for your brother. Thirty-five years of expertise is not being replaced; it is being amplified. Make sure that framing is felt, not just stated.

---

### The Entry Angle

Your brother already has everything that takes most AI students years to develop:
- **Systems thinking** — he already reasons about complex multi-component systems under load
- **Data architecture intuition** — he knows what a schema means, what a query costs, what integrity requires
- **Enterprise reliability mindset** — he has never shipped something that can fail silently at 2am
- **Stakeholder communication** — he has been translating between technical reality and business requirements for decades

The only gap is vocabulary and familiarity with the new tools. That closes fast for someone with his foundation.

**The market opportunity is real:** Oracle-to-Snowflake/PostgreSQL migration is a multi-hundred-million-dollar market. AI that can analyze schemas, identify Oracle-isms, generate migration scripts, and flag edge cases is not a nice-to-have — it is a billable differentiator. He can build toward that immediately.

---

### Concept Mapping: DBA ↔ AI

| DBA Concept | AI Equivalent | Why the mapping works |
|---|---|---|
| Query execution plan | Prompt reasoning trace / Chain-of-Thought | Both show the "path" taken to produce an output |
| SGA / shared pool | Context window | Both are working memory that must be managed actively |
| JDBC / ODBC | MCP protocol | Both are standardized connection interfaces |
| External procedure | Tool use / function call | Both allow the engine to invoke external logic |
| AWR / ASH | LLM token usage & latency tracing | Both are performance instrumentation |
| Index design | Retrieval-Augmented Generation (RAG) | Both pre-structure information for fast, relevant access |
| PL/SQL stored procedure | Agentic workflow with tool calls | Both are multi-step logic executed in response to a trigger |
| DB link | MCP server to external system | Both connect a local compute context to a remote resource |
| Enterprise reliability / HITL | Human-in-the-Loop (HITL) framework | Both require checkpoints before irreversible actions |

---

### Phase-by-Phase Roadmap

#### Phase 1 — AI Fluency (Weeks 1–3)

**Goal:** Build the mental model. Start using Claude daily. Calibrate trust.

**Week 1 — Foundation:**
- Watch Andrej Karpathy's "Intro to LLMs" on YouTube (1 hour). This is non-negotiable and must happen first. It is the clearest explanation of how these systems actually work, written by one of the people who helped build them.
- Read Anthropic's prompt engineering overview at docs.claude.com. It is short, well-written, and directly applicable.
- Set up Claude.ai Pro. Use it for three DBA tasks this week instead of Google or Stack Overflow.

**Week 2 — Daily Practice:**
- Every time you would have Googled a DBA question, ask Claude instead. Keep notes on where it was right, where it was wrong, and what prompting adjustments helped.
- Practice writing system prompts: start a conversation with a detailed description of your environment (Oracle version, Exadata config, your naming conventions) and see how it changes the quality of answers.
- Try: "You are an Oracle Exadata DBA advisor. I am running Oracle 19c on X9M Exadata. My storage cells use Smart Scan for analytics queries. When I ask you about query performance, always ask for the execution plan before advising."

**Week 3 — Prompt Engineering:**
- Few-shot prompting: give Claude two or three examples of a task before asking it to do a new one
- Chain-of-thought: ask Claude to "think step by step" before answering performance questions — the reasoning often catches errors the final answer misses
- Experiment with negative constraints: "Do not suggest adding hints. Do not assume I can add indexes. Only suggest optimizer statistics changes."

**Week 3 Milestone:** You can reliably get useful answers from Claude on DBA problems you already know the answer to. You have a calibrated sense of where it's strong (explanation, code generation, migration analysis) and where it needs verification (very version-specific behavior, Exadata-specific internals).

---

#### Phase 2 — Claude as Co-Pilot (Weeks 4–5)

**Goal:** Claude knows your environment. Every new chat starts informed.

**Set up a Claude Project:**
A Claude Project is a persistent context that every conversation inherits. Build one called "Oracle DBA Workspace" with a system prompt that includes:
- Your Oracle and Exadata versions
- Your company's naming conventions (table prefixes, schema names)
- Your preferred SQL dialect quirks
- Your constraints (can't modify production directly, need DBA approval for index changes, etc.)
- Your communication style preference ("be direct, give me the SQL first, explain after")

This is the AI equivalent of a well-configured IDE — you stop re-explaining yourself every session.

**High-value use cases to explore now:**
1. **AWR report narration:** Paste an AWR summary. Ask Claude to explain the top 5 performance findings in plain English, flag anything unusual, and suggest what to investigate first.
2. **Query optimization:** Paste a slow query + its execution plan. Ask Claude to explain what the optimizer is doing and why, then suggest alternatives without hints.
3. **Migration planning:** Describe an Oracle stored procedure. Ask Claude to: identify Oracle-specific features used, assess migration complexity to PostgreSQL or Snowflake, and draft an equivalent.
4. **Documentation generation:** Paste a schema DDL. Ask Claude to write developer-facing documentation for each table, including business context based on naming patterns it can infer.
5. **Incident report drafting:** Describe a production incident. Ask Claude to draft the post-mortem in standard format (timeline, root cause, impact, remediation, prevention).

**Phase 2 Milestone:** You have a working Claude Project configured for your environment. You have used it on at least five real tasks and can articulate where it adds 10x value vs. where it still needs hand-holding.

---

#### Phase 3 — Claude Code (Weeks 6–9)

**Goal:** Build things. Stop using AI as a Q&A tool and start using it as a builder.

**What Claude Code is:** Claude Code is an agentic coding environment that runs in your terminal. You give it a task in natural language; it reads your codebase, writes code, runs it, observes the output, and iterates. It is not an IDE plugin — it is an autonomous coding agent that treats your terminal as its workshop.

**Installation:** `npm install -g @anthropic-ai/claude-code` then `claude` in any project directory.

**The CLAUDE.md pattern:** Create a file called `CLAUDE.md` in your project root. This is the persistent context file — it tells Claude Code about the project conventions, what tools are available, what patterns to follow, and what to avoid. Think of it as the README that the AI reads before touching anything. Example structure:

```markdown
# Oracle DBA Automation Project

## Environment
- Oracle 19c on Exadata X9M
- Python 3.11, cx_Oracle 8.3
- Connection strings in environment variables (never hardcode)

## Conventions
- All scripts must handle connection pooling via cx_Oracle.SessionPool
- Log to structured JSON, never print() in production code
- Every script must have a --dry-run flag before destructive operations

## What this project does
Automates routine DBA monitoring, reporting, and analysis tasks.
```

**Projects to build in Phase 3:**

**Project A — Schema Documentation Generator**
Takes a list of schema names as input, connects to Oracle, extracts table/column/constraint metadata, and generates markdown documentation for each table. Add a Claude call to generate natural-language descriptions for tables and columns based on naming patterns.

**Project B — SQL Migration Linter**
Takes Oracle SQL as input, identifies Oracle-specific constructs (`CONNECT BY`, `ROWNUM`, `NVL`, `DECODE`, Oracle hints, etc.) and for each one: explains what it does, rates migration complexity, and suggests the PostgreSQL/Snowflake equivalent.

**Project C — AWR Summary Extractor**
Parses AWR HTML reports (or text outputs), extracts key metrics (top SQL by elapsed time, wait events, segment statistics), and generates a structured JSON summary that can be fed to Claude for narrative analysis.

**Phase 3 Milestone:** At least one working script that uses Claude Code to build something you would actually use in your job. The CLAUDE.md pattern is in place. You have experienced at least one full plan → execute → observe → iterate cycle with Claude Code.

---

#### Phase 4 — MCP & Agents (Weeks 10–16)

**Goal:** Build the "DBA Copilot" — an agent that can query live Oracle data and reason about it.

**Step 1 — Build your first MCP server (Week 10–11)**

```python
# Install: pip install mcp
# This exposes three tools to any MCP-compatible AI client

from mcp.server import Server
from mcp.server.stdio import stdio_server
import cx_Oracle

server = Server("oracle-dba-tools")

@server.tool()
async def run_query(sql: str, max_rows: int = 100) -> str:
    """Execute a read-only SQL query against the Oracle database and return results."""
    # connection logic here
    ...

@server.tool()
async def get_schema_info(schema_name: str) -> str:
    """Return table names, column definitions, and indexes for a given schema."""
    ...

@server.tool()
async def get_explain_plan(sql: str) -> str:
    """Return the execution plan for a given SQL statement."""
    ...

@server.tool()
async def get_session_activity() -> str:
    """Return current active sessions from V$SESSION with wait events."""
    ...

if __name__ == "__main__":
    stdio_server(server)
```

**Step 2 — Connect to Claude Code (Week 12)**

Add the server to Claude Code's config:
```json
{
  "mcpServers": {
    "oracle-dba": {
      "command": "python",
      "args": ["/path/to/oracle_mcp_server.py"]
    }
  }
}
```

Now when you ask Claude Code "why is this query slow?" it can actually pull the explain plan and session data — not just theorize about it.

**Step 3 — Build the DBA Copilot agent (Weeks 13–16)**

The DBA Copilot is a Python script that:
1. Takes a question in natural language ("Is there unusual wait event activity right now?")
2. Calls the Claude API with your MCP tools available
3. Claude autonomously decides which tools to call
4. Gathers data from live Oracle system views
5. Returns a structured analysis in English

**The "aha" moment you are building toward:**
Ask: *"Why is my query slow?"*
Watch the agent:
- Call `get_explain_plan` with the SQL
- Call `run_query` against `V$SQL` to get runtime stats
- Call `get_schema_info` to check for missing indexes
- Draft a structured analysis: what the optimizer is doing, why it might be suboptimal, what the recommended remediation is

This is not a demo. This is a tool you will use on Monday morning.

**Stretch goal:** Add an alerting layer. The agent polls `get_session_activity` every 5 minutes. If it detects a blocking chain or an unusual wait pattern, it calls Claude to draft an incident notification and posts it to Slack via another MCP tool.

---

### Recommended Resources

| Resource | Format | Why |
|---|---|---|
| Andrej Karpathy — "Intro to LLMs" | YouTube, 1hr | **Do this first.** Best conceptual foundation anywhere. |
| docs.claude.com — Prompt Engineering Guide | Web | Official, updated, unusually well-written |
| Anthropic Cookbook (github.com/anthropics/anthropic-cookbook) | Code | Tool use, agents, RAG — copy-paste starting points |
| Simon Willison's blog (simonwillison.net) | Blog | Best practitioner commentary, no hype, weekly |
| MCP specification (modelcontextprotocol.io) | Web | Read when starting Phase 4 |

---

### Discussion Prompts for the DBA

1. *What are the three Oracle tasks you do most often that follow a consistent pattern? Let's sketch what automating them with an agent would look like.*
2. *Where in your current workflow do you spend time on tasks that are fundamentally "collect data, interpret data, write a report"? That's the highest-value AI target.*
3. *If you had a DBA Copilot that could query any Oracle system view and reason about the results, what question would you ask it first thing Monday morning?*
4. *The Oracle-to-Snowflake migration market is enormous right now. How would an AI tool that does the analysis and complexity scoring change your consulting capacity?*
5. *What's your biggest concern about relying on AI for DBA work? (Let's discuss it directly — the concern is probably valid, and the mitigation is probably also within reach.)*

---

## Part 3 — Curriculum 2: Electronics Engineering Student
### Individual Deep-Dive (~30 minutes)

> **Facilitator note:** Your nephew is likely the most naturally capable person in the room for the build-heavy parts of this curriculum. The goal is to channel that energy into a clear progression rather than letting him scatter across interesting things. The EE angle is genuinely rare — keep reinforcing it.

---

### The Entry Angle

Your nephew has a combination of skills that almost no AI builders in 2026 have simultaneously:
- **EE intuition for systems** — he thinks in signals, noise, feedback loops, and transfer functions. These are the right mental models for AI.
- **Programming ability** — he can write Python and Java well. This means he can move from concept to working code fast.
- **Hardware proximity** — he will be able to deploy AI at the edge (MCUs, FPGAs, embedded systems) while most AI engineers have never touched hardware. This is a real differentiator.
- **Student status** — he has a ready-made project sandbox in his coursework. Every concept he learns can be immediately applied to something real and relevant.

**The honest pitch:** Most people learning AI right now are software people learning to call an API. Your nephew is a hardware-aware engineer with programming skills who will learn to call an API and then build things with it that software-only people cannot. Get him moving fast and don't let theory slow him down.

---

### EE ↔ AI Concept Map

| EE Concept | AI Equivalent | Why the mapping works |
|---|---|---|
| Attention / learned weighting | Transformer attention mechanism | Literally the same mathematical concept — weighted sum |
| Vector space / signal space | Embedding space | Both represent information as coordinates in high-dimensional space |
| Signal-to-noise ratio | Output quality / temperature | Temperature controls randomness, analogous to noise in the channel |
| Frequency domain / FFT | Latent space decomposition | Both decompose complex signals into component representations |
| Feedback control loop | Agentic perceive-plan-act-reflect loop | Both are closed-loop systems that adjust based on observed output |
| Interrupt handler / peripheral call | Tool use / function calling | Both are mechanisms for the main process to invoke external logic |
| Hardware abstraction layer (HAL) | MCP protocol layer | Both decouple the application from the specifics of the hardware/service |
| MCU firmware | TinyML / Edge AI models | Both are software running on constrained compute close to the physical world |
| UART / SPI / I2C protocols | API / SDK interfaces | Both are standardized communication protocols between components |
| Oscilloscope / logic analyser | Token streaming / API response inspection | Both are instruments for observing the internals of a running system |

---

### Phase-by-Phase Roadmap

#### Phase 1 — LLM Foundations + First API Call (Week 1)

**Goal:** Understand the architecture. Make something work. Do not spend more than one week on theory.

**Day 1–2 — Conceptual foundation:**
- Watch Andrej Karpathy's "Intro to LLMs" (YouTube, 1 hour). His "Neural Networks: Zero to Hero" series is worth bookmarking for later. As an EE student, the transformer attention mechanism will click for you in a way it doesn't for most people — it is a learned weighted sum over a sequence, which is structurally similar to things you already work with in signal processing.
- Key things to understand: tokens (not words — sub-word units), embeddings (vectors representing meaning in high-dimensional space), attention (the mechanism that lets the model weigh which parts of the input matter most), temperature (controls output randomness — analogous to noise).

**Day 3 — First API call:**

Get an Anthropic API key (console.anthropic.com). Then:

```python
import anthropic

client = anthropic.Anthropic()  # reads ANTHROPIC_API_KEY from env

message = client.messages.create(
    model="claude-sonnet-4-6",
    max_tokens=1024,
    messages=[
        {"role": "user", "content": "Explain how a first-order RC low-pass filter works."}
    ]
)

print(message.content[0].text)
```

That's it. You are now using the API.

**Day 4–7 — Build the CLI chatbot:**

Build a chatbot that maintains conversation history. This is your first lesson in context window management — every message in the history list is consuming context.

```python
import anthropic

client = anthropic.Anthropic()
conversation_history = []

def chat(user_message: str) -> str:
    conversation_history.append({"role": "user", "content": user_message})
    
    response = client.messages.create(
        model="claude-sonnet-4-6",
        max_tokens=1024,
        system="You are an electronics engineering tutor specialising in circuit analysis and signal processing.",
        messages=conversation_history
    )
    
    assistant_message = response.content[0].text
    conversation_history.append({"role": "assistant", "content": assistant_message})
    return assistant_message

while True:
    user_input = input("You: ")
    if user_input.lower() == "quit":
        break
    print(f"Claude: {chat(user_input)}")
```

**Week 1 Milestone:** Working CLI chatbot. You have called the API, managed conversation history, and used a system prompt to set a persona. You understand that the model has no memory between separate script runs.

---

#### Phase 2 — Prompt Engineering + Structured Outputs (Weeks 2–3)

**Goal:** Learn to shape outputs for downstream use. Build something useful for your coursework right now.

**Core prompt engineering techniques:**

**System prompts** set the model's persona, constraints, and output format before the conversation begins. They are the most important prompt you write.

**Few-shot prompting** — show the model examples of what you want before asking for it:
```python
system = """You are a circuit analysis assistant. When asked about a circuit, 
always respond in this format:
- Component values
- Transfer function
- -3dB frequency  
- Practical considerations

Example:
User: RC low-pass filter, R=10kΩ, C=100nF
Assistant:
- Component values: R=10kΩ, C=100nF
- Transfer function: H(s) = 1/(1 + sRC)
- -3dB frequency: f = 1/(2πRC) = 159.15 Hz
- Practical considerations: At signal frequencies well above 159Hz, output is strongly attenuated..."""
```

**Structured outputs (JSON)** — essential for building applications on top of AI:
```python
system = """You are a circuit analyser. Respond ONLY with valid JSON in this format:
{
  "component_values": {},
  "transfer_function": "",
  "cutoff_frequency_hz": 0,
  "filter_type": "",
  "practical_notes": []
}
No preamble, no explanation, just the JSON object."""
```

**Tool use / function calling** — the bridge to agents:
```python
tools = [
    {
        "name": "calculate_rc_frequency",
        "description": "Calculate the -3dB cutoff frequency of an RC filter given resistance and capacitance values.",
        "input_schema": {
            "type": "object",
            "properties": {
                "resistance_ohms": {"type": "number", "description": "Resistance in ohms"},
                "capacitance_farads": {"type": "number", "description": "Capacitance in farads"}
            },
            "required": ["resistance_ohms", "capacitance_farads"]
        }
    }
]

# Claude will call this tool when appropriate
# You handle the tool call, compute the result, return it to Claude
```

**Build in Phase 2 — Study Assistant:**
Takes your EE lecture slides or notes (PDF or text), ingests them, and generates:
1. A 10-question practice quiz with answers
2. A list of key formulas with plain-English explanations
3. Three likely exam questions based on the content

This is immediately useful and teaches you document-grounded AI at the same time.

**Week 3 Milestone:** Working study assistant. You can reliably get structured JSON outputs. You have implemented at least one tool call from scratch and handled the tool result in code.

---

#### Phase 3 — Claude Code (Weeks 4–6)

**Goal:** Use an AI agent to accelerate your actual coursework. Build the habit of working with AI in the terminal, not just in chat.

**Installation:** `npm install -g @anthropic-ai/claude-code` then `claude` in any project directory.

**The agentic loop in action:** When you run Claude Code on a task, it:
1. Reads relevant files in your project
2. Plans what steps are needed
3. Writes code and executes it
4. Reads the output
5. Decides whether to iterate or declare success

This is the same perceive → plan → act → reflect loop that underpins every agent architecture. Experiencing it firsthand in a tool you use daily builds the intuition faster than any tutorial.

**CLAUDE.md for your coursework project:**
```markdown
# EE Coursework Assistant

## Environment
- Python 3.11 with scipy, numpy, matplotlib, sympy installed
- Jupyter notebooks for visualisation
- Spice files in /circuits/ directory

## Conventions
- All frequency calculations should include both rad/s and Hz
- Plots should be saved to /plots/ with descriptive filenames
- Circuit simulations use PySpice or custom scipy implementations

## Project structure
- /circuits/ — SPICE netlists and circuit descriptions
- /analysis/ — Python analysis scripts
- /plots/ — Generated frequency response and time domain plots
- /notes/ — Lecture summaries and formula sheets
```

**Projects to build in Phase 3:**

**Project A — Circuit Analysis Accelerator**
Give Claude Code a circuit description. It writes a Python script using scipy to:
- Compute the transfer function symbolically using sympy
- Plot the Bode plot (magnitude and phase)
- Annotate the -3dB frequency, poles, and zeros
- Save the plot with a descriptive filename

This is something you would spend 30–45 minutes doing by hand. Claude Code does it in 2 minutes. The time you save goes into understanding why the result looks the way it does.

**Project B — MATLAB to Python Converter**
Many EE courses still use MATLAB. Claude Code can convert MATLAB scripts to equivalent Python (numpy/scipy/matplotlib) with high accuracy. Build a small wrapper that: takes a .m file path, passes the content to Claude Code with conversion instructions, and writes the equivalent .py file.

**Project C — Formula Sheet Generator**
Takes a directory of lecture note PDFs, extracts all equations, organises them by topic, and generates a formatted formula reference sheet in Markdown or LaTeX.

**Phase 3 Milestone:** At least one working project that you would actually use for your coursework. You have experienced the full agentic loop with Claude Code. CLAUDE.md is configured.

---

#### Phase 4 — MCP + Building Integrations (Weeks 7–10)

**Goal:** Build your first MCP server. Give Claude access to something real.

**Understanding the MCP architecture:**

```
Claude (MCP client)
    ↕  [MCP protocol over stdio or HTTP]
Your MCP Server
    ↕  [your code]
Real System (database, API, hardware, file system)
```

The MCP server is just a Python (or any language) program that:
1. Listens for requests from the AI client
2. Exposes "tools" the AI can call
3. Returns results in a standardised format

**Your first MCP server — EE Component Lookup:**

```python
from mcp.server import Server
from mcp.server.stdio import stdio_server
import json

server = Server("ee-tools")

# A simple in-memory component database (replace with real API call later)
COMPONENT_DB = {
    "100nF ceramic capacitor": {"tolerance": "±10%", "voltage_rating": "50V", "package": "0805", "part_number": "GRM21BR71H104KA01L"},
    "10kΩ resistor": {"tolerance": "±1%", "power_rating": "0.125W", "package": "0805", "part_number": "RC0805FR-0710KL"},
}

@server.tool()
async def lookup_component(description: str) -> str:
    """Look up an electronic component by description and return specifications and part numbers.
    Use this when the user asks about component selection or specifications."""
    results = {k: v for k, v in COMPONENT_DB.items() if any(word in k for word in description.lower().split())}
    return json.dumps(results if results else {"message": "No matching components found"})

@server.tool()
async def calculate_filter_cutoff(resistance_ohms: float, capacitance_farads: float) -> str:
    """Calculate the -3dB cutoff frequency of a first-order RC filter."""
    import math
    freq_hz = 1 / (2 * math.pi * resistance_ohms * capacitance_farads)
    freq_rad = 1 / (resistance_ohms * capacitance_farads)
    return json.dumps({"cutoff_hz": round(freq_hz, 4), "cutoff_rad_s": round(freq_rad, 4)})

@server.tool()  
async def run_python_calculation(code: str) -> str:
    """Execute a Python calculation (numpy/scipy available) and return the result.
    Use for circuit analysis, signal processing, or any numerical computation."""
    import io, contextlib
    output = io.StringIO()
    try:
        exec_globals = {"__builtins__": __builtins__, "import": __import__}
        with contextlib.redirect_stdout(output):
            exec(code, exec_globals)
        return output.getvalue() or "Executed successfully (no output)"
    except Exception as e:
        return f"Error: {str(e)}"

if __name__ == "__main__":
    import asyncio
    asyncio.run(stdio_server(server))
```

Connect it to Claude Code:
```json
{
  "mcpServers": {
    "ee-tools": {
      "command": "python",
      "args": ["/path/to/ee_mcp_server.py"]
    }
  }
}
```

Now ask Claude: *"What capacitor should I use for a 10kHz low-pass filter with a 1kΩ source impedance?"*

Watch it: call `calculate_filter_cutoff` with the right values → `lookup_component` for matching parts → return a specific recommendation with part numbers.

**Phase 4 Milestone:** Working MCP server with at least two tools. Confirmed that Claude Code can call your tools and return useful results. You have seen the tool call chain happen in practice.

---

#### Phase 5 — Agents + Edge AI (Weeks 11–18, your differentiator)

**Goal:** Build a multi-step agent. Explore TinyML. Own the edge AI space.

**Building your first proper agent from scratch:**

Don't reach for LangChain yet. Build it raw first — you learn more and the code is simpler:

```python
import anthropic
import json

client = anthropic.Anthropic()

def run_agent(goal: str, tools: list, tool_handlers: dict, max_iterations: int = 10) -> str:
    """A minimal agent loop. LangChain is just a fancier version of this."""
    messages = [{"role": "user", "content": goal}]
    
    for iteration in range(max_iterations):
        response = client.messages.create(
            model="claude-sonnet-4-6",
            max_tokens=4096,
            tools=tools,
            messages=messages
        )
        
        # If no tool calls — we're done
        if response.stop_reason == "end_turn":
            return response.content[0].text
        
        # Handle tool calls
        tool_results = []
        for block in response.content:
            if block.type == "tool_use":
                handler = tool_handlers.get(block.name)
                if handler:
                    result = handler(**block.input)
                    tool_results.append({
                        "type": "tool_result",
                        "tool_use_id": block.id,
                        "content": str(result)
                    })
        
        # Add the assistant's response and tool results to history
        messages.append({"role": "assistant", "content": response.content})
        messages.append({"role": "user", "content": tool_results})
    
    return "Agent reached max iterations without completing the task"
```

**The "aha" moment agent:** Build an agent that takes a circuit description in natural language and:
1. Extracts component values
2. Calculates the transfer function
3. Runs a scipy simulation via your MCP tool
4. Generates and saves a Bode plot
5. Returns a written analysis of the frequency response

**The edge AI angle — your genuine differentiator:**

Edge AI means running AI models directly on microcontrollers and embedded processors — not in the cloud. This is where your EE background gives you access to a space most AI engineers cannot reach.

**Getting started with TinyML:**
- Framework: TensorFlow Lite Micro (for MCUs) or ONNX Runtime (for Pi/more capable boards)
- Hardware: Start with Raspberry Pi 4, then move to Arduino Nano 33 BLE Sense or STM32 boards
- First project: A keyword spotting model (wake word detection) running on an MCU — classify audio with no cloud connection
- Second project: Anomaly detection on sensor data (vibration, current draw) using a small LSTM or autoencoder running on-device

**Why this matters now:** As AI moves from cloud to edge, the people who understand both the ML stack and the hardware constraints are extraordinarily rare. Your coursework in electronics gives you the hardware layer. This curriculum gives you the ML layer. Very few people have both.

**Resources for Phase 5:**
- TinyML Foundation (tinyml.org) — courses, papers, community
- Pete Warden's "TinyML" book (O'Reilly) — the practical reference
- Edge Impulse (edgeimpulse.com) — tools for deploying ML on MCUs
- Fast.ai "Practical Deep Learning" — excellent broader ML foundation

**Phase 5 Milestone:** Working multi-step agent built from scratch (no framework). At least one experiment running a small model on non-cloud hardware (Raspberry Pi minimum). A clear idea of what you want to build at the intersection of EE and edge AI.

---

### Discussion Prompts for the EE Student

1. *You are going to make your first API call today before you leave this room. What question would you ask Claude first — something related to your current coursework?*
2. *What's the most tedious, repetitive part of your EE coursework right now? Let's sketch the AI tool that removes it.*
3. *If you could instrument one physical system with AI — sense its state, reason about it, and take action — what would it be?*
4. *The edge AI space is early and your combination of EE + AI is rare. What kind of problems do you want to work on in 5 years? Let's make sure the curriculum points there.*
5. *What stops you from starting today? Let's remove that obstacle right now.*

---

## Part 4 — The Shared Exercise
### For Both Together (~20 minutes)

This is the exercise you both do independently over the next week and then compare notes on.

---

### The Task

**Build a simple routing agent** that:
1. Takes a question as input
2. Decides whether it can answer from its own knowledge OR needs to call a "search" tool
3. If it calls the tool, uses the result to answer
4. Returns the answer with its reasoning shown

**The search tool is mocked** — it doesn't need to actually search the web. A Python function that returns a hardcoded result (or a simple file lookup) is sufficient. The point is the routing logic, not the tool itself.

**Why this exercise:**

| Practitioner | Their mental model for routing | What they'll discover |
|---|---|---|
| Oracle DBA | Query routing: when to hit the buffer cache vs index vs full scan vs external procedure | AI routing is the same decision logic he has been making for 35 years. The model's `stop_reason` of `tool_use` vs `end_turn` is the AI equivalent of the access path in an execution plan |
| EE Student | Signal routing: which processing path to take based on frequency content or signal type | The agent loop is a closed-loop control system he already understands. The tool call is the interrupt handler. The model's reasoning is the control logic |

---

### Starter Code (for the nephew to share with his uncle)

```python
import anthropic
import json

client = anthropic.Anthropic()

# Define the search tool
search_tool = {
    "name": "search_knowledge_base",
    "description": "Search an external knowledge base for current or specific factual information. Use this when you are not confident in your own knowledge or when the question requires up-to-date information.",
    "input_schema": {
        "type": "object", 
        "properties": {
            "query": {
                "type": "string",
                "description": "The search query"
            }
        },
        "required": ["query"]
    }
}

def mock_search(query: str) -> str:
    """Mock search tool - replace with real search logic later"""
    return f"Search results for '{query}': [This is where real search results would appear]"

def routing_agent(question: str) -> dict:
    """A minimal routing agent that shows its reasoning."""
    messages = [{"role": "user", "content": question}]
    
    response = client.messages.create(
        model="claude-sonnet-4-6",
        max_tokens=1024,
        tools=[search_tool],
        messages=messages,
        system="You are a helpful assistant. When answering questions, think carefully about whether you have reliable knowledge or whether you should search for more current/specific information. Always explain your reasoning."
    )
    
    result = {"question": question, "routing_decision": None, "answer": None}
    
    if response.stop_reason == "end_turn":
        # Model decided to answer from its own knowledge
        result["routing_decision"] = "answered_from_knowledge"
        result["answer"] = response.content[0].text
        
    elif response.stop_reason == "tool_use":
        # Model decided to use the search tool
        tool_call = next(b for b in response.content if b.type == "tool_use")
        result["routing_decision"] = f"called_search_tool(query='{tool_call.input['query']}')"
        
        # Execute the mock search
        search_result = mock_search(tool_call.input["query"])
        
        # Give the result back to the model
        messages.append({"role": "assistant", "content": response.content})
        messages.append({"role": "user", "content": [
            {"type": "tool_result", "tool_use_id": tool_call.id, "content": search_result}
        ]})
        
        # Get the final answer
        final_response = client.messages.create(
            model="claude-sonnet-4-6", max_tokens=1024, tools=[search_tool], messages=messages,
            system="You are a helpful assistant."
        )
        result["answer"] = final_response.content[0].text
    
    return result

# Test it
test_questions = [
    "What is Ohm's Law?",  # Should answer from knowledge
    "What is the current price of copper wire per meter?",  # Should search
    "How does a transformer work?",  # Should answer from knowledge
    "What new Oracle 23ai features were released last month?",  # Should search
]

for q in test_questions:
    result = routing_agent(q)
    print(f"\nQuestion: {result['question']}")
    print(f"Routing: {result['routing_decision']}")
    print(f"Answer: {result['answer'][:200]}...")
    print("-" * 60)
```

---

### Discussion After Running It

Ask each other:
- Which questions triggered the search tool? Does that match your intuition?
- Change the system prompt — add "You prefer to answer from your own knowledge unless absolutely necessary." Does the routing change?
- The `stop_reason == "tool_use"` decision is the AI's equivalent of a query optimizer choosing an access path. Can you describe what the optimizer "saw" in the question that made it choose to search?

---

## Quick Reference: What to Do This Week

| Person | Action | Timeline |
|---|---|---|
| Both | Watch Karpathy "Intro to LLMs" on YouTube | This week |
| Brother | Set up Claude.ai Pro, spend 1 hour using it on real DBA problems | This week |
| Nephew | Get API key, run first API call (3 lines of Python) | Today |
| Both | Build the routing agent from the starter code above | Before next meeting |
| All | Set a 30-day check-in date | Before leaving today |

---

## Appendix: Tool and Platform Setup

### Getting Started with Claude.ai

1. Go to claude.ai
2. Sign up for Claude Pro ($20/month) — worth it for extended context and priority access
3. Create a Project for DBA work (for brother) or coursework (for nephew)
4. Write a system prompt that describes you, your environment, and what you want from the AI

### Getting an Anthropic API Key

1. Go to console.anthropic.com
2. Create an account
3. Navigate to API Keys → Create Key
4. Set `ANTHROPIC_API_KEY` as an environment variable
5. Install the SDK: `pip install anthropic`

### Installing Claude Code

```bash
npm install -g @anthropic-ai/claude-code
claude  # run in any project directory
```

Claude Code reads `ANTHROPIC_API_KEY` from your environment.

### Installing the MCP SDK

```bash
pip install mcp
```

The MCP documentation is at modelcontextprotocol.io.

---

*This document was prepared by Rupesh Dandekar, Technology Fellow, Deloitte. March 2026.*
