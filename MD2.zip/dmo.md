# `dbt-model-optimizer-cisco` — Production Hardening Brief

**Source skill:** `dbt-model-optimizer` v0.2.0 (status: draft)
**Target:** `dbt-model-optimizer-cisco` v1.0.0 (status: active)
**Audience:** Snowflake Cortex Code (agentic execution)

This brief converts a code review into a sequenced set of changes. Tasks are
listed in execution order. Each task has a rationale (so you can make good
judgment calls if the spec is ambiguous), a file list, and a Definition of Done
(DoD) you must satisfy before moving on.

Do not skip a task because it "looks done already." Verify against the DoD.

---

## Pre-flight

**Decision already made (do not revisit):** the skill is being renamed to
`dbt-model-optimizer-cisco` because Cisco-specific conventions (EDWSF_*, table
prefix rules, `edw_convert_to_pst()` macro, source/ref prefix mapping) are
baked into the rule set and parameterizing them is out of scope for this
release. Own the niche.

**Out of scope for this release:**

- A generic, non-Cisco version of the skill (future work).
- A real sub-agent runtime (we are removing the framing, not building one).
- Verifying D5/D6 against a live Snowflake instance (we are marking it
  experimental, not validating it end-to-end).
- Performance optimization of the rules engine itself.

**Working agreement:**

- Make every change in a single commit per task. Commit message format:
  `T<n>: <short description>`.
- Run a markdown linter on every edited `.md` file.
- After every task, re-read the file you just changed end-to-end. Do not assume
  your edits landed as intended.

---

## T1 — Rename the skill package

**Why:** Foundational. Every downstream task references the new name.

**Scope:**

1. Rename the top-level directory: `dbt-model-optimizer/` → `dbt-model-optimizer-cisco/`.
2. Update `name:` in `SKILL.md` frontmatter from `dbt-model-optimizer` to
   `dbt-model-optimizer-cisco`.
3. Update the skill description's first sentence to make Cisco scope explicit.
   Replace:
   ```
   Optimizes a single dbt model SQL file across six dimensions...
   ```
   With:
   ```
   Optimizes a single dbt model SQL file on Cisco's Snowflake EDW platform
   across six dimensions...
   ```
4. Add this paragraph to the description block (before the "Do NOT use"
   sentence):
   ```
   This skill assumes Cisco audit-column conventions (EDWSF_* prefix), table
   prefix-to-layer mapping (N_/MT_/R_ for sources; W_/WI_/ST_/EX_/EL_/SM_/GL_/FA_
   for refs), and the `edw_convert_to_pst()` macro. Do NOT use on non-Cisco
   dbt projects — many auto-fix rules will misclassify and corrupt valid code.
   ```
5. Update every internal reference to the old name:
   - `CHANGELOG.md` heading
   - `evals.json` `"skill_name"` field
   - `docs/dbt-target-optimizer-spec.md` (any reference to the old name in the
     "Relationship to Existing Skills" table)
   - Example READMEs
   - Sub-agent `SKILL.md` files: "Sub-agent for dbt-model-optimizer" →
     "Sub-procedure for dbt-model-optimizer-cisco" (the "sub-procedure" wording
     is required for T2)
6. Remove `cisco_conventions.enabled` from `config.yml`. Cisco conventions are
   no longer optional — they are the skill's identity. Keep the other keys
   under `cisco_conventions:` but rename the block to `conventions:` since
   there is now only one set.

**DoD:**

- `grep -r 'dbt-model-optimizer[^-]' .` returns zero matches (no bare old name).
- `grep -r 'cisco_conventions' .` returns zero matches.
- The description, read cold, makes it obvious this is Cisco-specific within
  the first 50 words.

---

## T2 — Kill the sub-agent framing

**Why:** The orchestrator says "delegate to the live-profiler sub-agent. Load
`agents/live-profiler/SKILL.md`." There is no sub-agent runtime — Claude reads
that file into the same context and continues. The current framing implies
isolation and return values that don't exist, which will confuse anyone
debugging the skill cold. We keep the procedural decomposition (it's useful);
we drop the misleading vocabulary.

**Scope:**

1. Rename the folder `agents/` → `procedures/`.
2. Update the two inner SKILL.md files:
   - Title: "Static Analyzer (Sub-Agent A)" → "D1-D4 Static Analysis Procedure"
   - Title: "Live Profiler (Sub-Agent B)" → "D5-D6 Live Profiling Procedure"
   - Replace the phrase "Sub-agent for ..." in the description with
     "Procedure file for dbt-model-optimizer-cisco. Loaded by the main
     orchestrator at the indicated step. Not invoked independently."
   - Remove `tier:` and any "agent" terminology in the body.
3. In `SKILL.md` and elsewhere, replace every instance of:
   - "sub-agent" → "procedure"
   - "Delegate ... to the static-analyzer sub-agent. Load `agents/...`" →
     "Load `procedures/static-analysis.md` and follow it in-context."
   - The "Sub-Agents" table near the bottom of `SKILL.md` → rename to
     "Procedure Files" and update the language accordingly.
4. Optional but recommended: collapse `procedures/static-analyzer/SKILL.md`
   and `procedures/live-profiler/SKILL.md` to flat files
   (`procedures/static-analysis.md` and `procedures/live-profiling.md`) since
   they are no longer skills, just reference procedures. If you do this, also
   remove their frontmatter `name:`, `version:`, `tier:`, `status:` fields and
   keep only a small `# Title` heading.

**DoD:**

- `grep -ri 'sub-agent\|sub_agent\|subagent' .` returns zero matches.
- The main `SKILL.md` reads coherently end-to-end without implying any
  delegation or isolation mechanism.

---

## T3 — Re-classify SAFE rules

**Why:** SAFE means "auto-apply with no human review." Several current SAFE
rules require information the skill doesn't have, which means the auto-fix can
silently corrupt the model. Tighten the bar.

**Rule for what stays SAFE:** the auto-fix needs *no information beyond what
is in the model file itself or in this skill's reference data*. If the fix
needs to know the right source name, the right var name, the right macro
binding, the upstream schema, or anything else the skill cannot determine —
it is REVIEW, not SAFE.

**Specific reclassifications:**

| Rule ID | Current | New | Reason |
|---------|---------|-----|--------|
| D2-DEP-001 | SAFE | REVIEW | Generating `source('schema','table')` requires the source name from `_sources.yml`, which the skill never verifies. Compile may fail. |
| D2-CFG-002 | SAFE | REVIEW | "Infer materialized from model" is underspecified. Choosing wrong (table vs incremental) silently changes runtime behavior. |
| D1-INF-001 | SAFE | REVIEW | `$$STGDB → var('stg_database')` assumes a var that may not exist. Example 1 absorbs it into a `source()` macro, which is example-specific, not general. |
| D1-INF-002 | SAFE | REVIEW | Same reason as D1-INF-001. |
| D1-INF-003 | SAFE | REVIEW | Same reason as D1-INF-001. |
| D4-TEST-001 | SAFE | REVIEW | Heuristic-driven (COALESCE absence, JOIN usage). Will produce false positives. Step 9 explicitly does not roll back on test failure, so user is left with failing tests. |
| D4-TEST-002 | SAFE | REVIEW | Same reason as D4-TEST-001. PK inference from MERGE/DISTINCT is heuristic. |
| D2-AUDIT-003 | SAFE | **REQUIRES_APPROVAL** | If the legacy DTM expression was a PST-converted timestamp (common on Cisco), replacing with `CURRENT_TIMESTAMP(0)` changes the timezone of audit data. That is a semantic change. |
| D2-AUDIT-005 | SAFE | **REQUIRES_APPROVAL** | Same timezone reasoning — replacing `edw_convert_to_pst()` with `CURRENT_TIMESTAMP(0)` in a SELECT changes the timezone semantics. |

**Stays SAFE (verified — no change needed):**

- All Oracle/Teradata/SQL Server function replacements that don't change
  semantics (`NVL → COALESCE`, `ISNULL → COALESCE`, `SYSDATE → CURRENT_DATE()`,
  `LEN → LENGTH`, `STRTOK → SPLIT_PART`, etc.).
- Dialect syntax removals (`BT;`, `ET;`, `COLLECT STATS`, `SET NOCOUNT`,
  `FROM DUAL`).
- `EDW_* → EDWSF_*` renaming (deterministic rename, no timezone change).
- Adding `query_tag`, `EDWSF_BATCH_ID` (additive only).
- Unused CTE removal (D2-CTE-001 — definitionally no downstream impact).

**Scope:**

1. Update `references/optimization-rules.md` — every reclassified rule's
   Safety column.
2. Update `references/dialect-patterns.md` — D1-INF-001/002/003 safety column.
3. Update `procedures/static-analysis.md` (formerly `agents/static-analyzer/SKILL.md`)
   — the Step A.3/A.5 rule mappings.
4. Update the main `SKILL.md` Step 3 audit-column section to flag
   D2-AUDIT-003 and D2-AUDIT-005 as REQUIRES_APPROVAL and add a sentence
   explaining the timezone risk.
5. Update Example 1 (`example-01-dialect-cleanup`):
   - The input model triggers D2-AUDIT-003 (DTM columns without
     `CURRENT_TIMESTAMP(0)`). Under the new classification this should NOT be
     auto-applied. Move it from "SAFE Changes (Applied)" to "REQUIRES APPROVAL
     Items (Not Applied)" in `optimization_report.md` and update the
     `model_optimized.sql` accordingly (keep the original EDW_CREATE_DTM
     reference but renamed to EDWSF_CREATE_DTM — the rename is SAFE, the
     expression change is not).
6. Update the `optimization_report.md` summary table counts to match.

**DoD:**

- The Safety column for every reclassified rule matches the table above in
  every file it appears in.
- Example 1's report's summary counts add up correctly after reclassification.
- No SAFE-flagged rule remains where the auto-fix requires external schema
  knowledge, var bindings, or timezone-semantic decisions.

---

## T4 — Reorder the workflow: analyze fully before HITL

**Why:** Step 6 currently asks the user to approve SAFE changes before D5/D6
analysis has run. A user can't intelligently approve dialect cleanup without
knowing whether the model is even worth optimizing (e.g., D6 might say "this
runs 3 times a day, downgrade to view" — different decision context). One
checkpoint, full information.

**Scope:**

1. In `SKILL.md`, reorder the steps to:
   - Step 1: Input validation and environment detection (unchanged)
   - Step 2: Static analysis D1 (unchanged)
   - Step 3: Static analysis D2 (unchanged)
   - Step 4: Static analysis D3 (unchanged)
   - Step 5: Static analysis D4 (unchanged)
   - Step 6: Live profiling D5/D6 (was Step 8 — moves earlier)
   - Step 7: Generate categorized optimization report (was Step 6 — moves later)
   - **Step 8: HITL CHECKPOINT** — single approval point for SAFE auto-apply
   - Step 9: Apply approved SAFE changes (was Step 7)
   - Step 10: Full validation (was Step 9)
   - Step 11: Final summary (was Step 10)
2. Update the "HITL Checkpoints Summary" table at the bottom of `SKILL.md` —
   there is now only one MEDIUM checkpoint (the approval gate). The "HIGH"
   D5/D6 checkpoint at Step 8 collapses into the same gate because D5/D6
   recommendations are still REQUIRES_APPROVAL and need explicit per-item
   user action — note this in the checkpoint description.
3. Remove the "On silence: wait — do not proceed" instruction. Skills don't
   have a wait primitive. Replace with: "If the user response is ambiguous
   (not a clear yes or specific exclusion), ask once for clarification, then
   stop. Do not auto-apply on ambiguity."
4. Update the report template so that the HITL checkpoint presents:
   - Summary table (counts by dimension × safety)
   - The full list of SAFE changes (line numbers + before/after)
   - The count of REVIEW and REQUIRES_APPROVAL items (not the full list — the
     full list goes in the post-checkpoint report)
   - The question: "Apply all N SAFE changes? Reply 'yes', 'no', or list the
     rule IDs to exclude (e.g., 'yes except D2-AUDIT-001, D4-DOC-002')."

**DoD:**

- There is exactly one HITL checkpoint in the main flow.
- D5/D6 results are visible to the user before they approve SAFE changes.
- No instruction in the skill assumes a wait/poll primitive.

---

## T5 — De-duplicate sources of truth

**Why:** Dialect detection patterns currently live in three places
(Step 1 of `SKILL.md`, `config.yml`, `references/dialect-patterns.md`). Audit
column rules live in four. The author will edit one and forget the others.
Drift is guaranteed.

**Scope:**

1. **Dialect detection patterns.** The canonical source is
   `config.yml > dialect_detection`. Update Step 1 of `SKILL.md` to read:
   ```
   5. Detect source dialect by scanning the model for indicators defined in
      `config.yml > dialect_detection`. The first dialect whose indicator
      count exceeds zero is selected; ties are broken in the order
      teradata → oracle → sqlserver → clean_snowflake.
   ```
   Remove the inline indicator lists from Step 1.
2. **Dialect conversion rules.** The canonical source is
   `references/dialect-patterns.md`. The procedure files and `SKILL.md` should
   reference rule IDs and reference paths, not restate the patterns.
3. **Audit column rules.** The canonical source is `references/dbt-conventions.md`
   ("Audit Column Rules" section). The `references/optimization-rules.md`
   table is a *summary* — keep it as a summary (one-line description + safety
   + auto-fix), not a restatement of the full rules. The main `SKILL.md`
   Step 3 should list rule IDs by name and reference the conventions doc, not
   restate them. Same for the procedure file.
4. **CTE rules, dependency rules, hook rules** — same treatment. Canonical
   in `references/dbt-conventions.md`. Summarized in `references/optimization-rules.md`.
   Referenced (not restated) in `SKILL.md` and procedure files.

After this task, the main `SKILL.md` should drop from ~291 lines to roughly
180-200 lines. If it doesn't, you didn't actually de-duplicate — go back.

**DoD:**

- Each rule body appears in exactly one file (the canonical reference).
- Each rule's Safety classification appears in exactly two files at most:
  the canonical reference and the summary table in `optimization-rules.md`.
- `SKILL.md` and procedure files reference rules by ID and link, not
  restatement.
- `SKILL.md` length drops to roughly 180-200 lines.

---

## T6 — Mark D5/D6 as experimental in this release

**Why:** D5/D6 looks complete on paper but the live profiler has several
hand-waved pieces: EXPLAIN output parsing (Snowflake returns either JSON or a
text grid — neither is trivial), query-history matching by `query_tag`
(weak when `query_tag` is missing, which is "RECOMMENDED" not required),
warehouse-sizing recommendations that don't specify where to make the change,
and `BYTES_SCANNED` comparisons that reference a table size the skill never
fetches. Until verified against a live instance, ship it as experimental, not
as a v1.0 feature.

**Scope:**

1. Add a `D5/D6 Status` section near the top of `SKILL.md`, immediately after
   the opening paragraph:
   ```
   ## D5/D6 Live Profiling — Experimental

   D5 (performance) and D6 (cost) analysis depend on live Snowflake query
   history and EXPLAIN plan parsing. This release ships them as experimental.
   Findings are emitted as REQUIRES_APPROVAL and the report includes a banner
   noting the experimental status. The skill has been verified end-to-end on
   D1-D4 only.

   To disable D5/D6 entirely, set `skip_live_profiling: true` in `config.yml`
   or pass `skip_live_profiling=true` at invocation.
   ```
2. In `procedures/live-profiling.md`, add a top-of-file banner:
   ```
   > **Experimental.** This procedure has not been verified end-to-end against
   > a live Snowflake instance. EXPLAIN plan parsing, query-history matching,
   > and warehouse-sizing logic require empirical validation before promotion
   > to stable. Findings should be treated as advisory.
   ```
3. In the report template (Step 7 of `SKILL.md`), add an experimental banner
   to the D5/D6 section of the report when D5/D6 ran:
   ```
   > ⚠️ D5/D6 findings are experimental in this release. Treat all
   > recommendations as advisory until verified against your Snowflake
   > workload.
   ```
4. In `config.yml`, change the default `dimensions.performance` and
   `dimensions.cost_optimization` to `false`. Document the change in the
   inline comment: `# false by default — D5/D6 are experimental in v1.0`.

**DoD:**

- The "experimental" banner appears in three places: top of `SKILL.md`, top of
  `procedures/live-profiling.md`, and inside the report template's D5/D6
  section.
- `config.yml` defaults D5/D6 to off.
- Nowhere in the skill does the language imply D5/D6 is production-ready.

---

## T7 — Frontmatter and metadata cleanup

**Why:** A handful of small issues that block a clean v1.0 stamp.

**Scope:**

1. **Tool declarations.** The current frontmatter lists
   `tools: [bash_tool, read_file, edit_file, write_file, snowflake_query]`.
   `read_file`, `edit_file`, `write_file` are not the canonical Claude
   runtime tool names. `snowflake_query` is not a standard tool. Replace with
   the actual tool names the skill uses:
   ```yaml
   compatibility:
     tools: [bash_tool, view, str_replace, create_file]
   ```
   If a Snowflake MCP connector is required, document it separately:
   ```yaml
     mcp_connectors:
       - name: snowflake
         required_for: [D5, D6]
   ```
2. **Broken context reference.** Remove
   `context: [SKILL-GUIDELINES.md]` from frontmatter unless the file is being
   added to the package. (It is not in the current zip.)
3. **Remove or define `tier`.** The `tier: project` field is not defined
   anywhere in the skill itself. Remove it from the main and procedure
   frontmatter, or add a one-paragraph definition to the README. Default
   choice: remove.
4. **Version bump.** Update `SKILL.md` frontmatter:
   - `version: 1.0.0`
   - `status: active`
   - `last_updated:` set to today's date
5. **Eval version sync.** Update `evals/evals.json`:
   - `"skill_name": "dbt-model-optimizer-cisco"`
   - `"version": "1.0.0"`

**DoD:**

- Frontmatter validates against a known schema (if you have one — otherwise
  visual inspection).
- No frontmatter field references a file that doesn't exist in the package.
- Versions match between `SKILL.md` and `evals.json`.

---

## T8 — Report template: make validation-skipped state loud

**Why:** Example 1's report says "13 SAFE changes applied" alongside "dbt
compile: Unavailable." A user reading that assumes validation happened. We
need to make it obvious when changes were applied without compile validation.

**Scope:**

1. In `SKILL.md` Step 11 (final summary), add this rule to the report
   template:
   ```
   If `dbt compile` was unavailable (no project root, or compile failed),
   the report's "Changes Applied" section MUST be prefixed with this banner:

   > ⚠️ **Changes applied without compile validation.** The skill could not
   > verify that the edited model still compiles. Run `dbt compile` against
   > this model before merging.
   ```
2. Add a separate rule: if more than 5 SAFE changes were applied and compile
   was unavailable, the skill must explicitly prompt the user at the HITL
   checkpoint:
   ```
   ⚠️ N SAFE changes will be applied without compile validation (no dbt project
   root found). Proceed anyway? (yes/no)
   ```
   This is a second-stage gate that only fires in the no-validation path.
3. Update Example 1's `optimization_report.md` to include the banner (since
   that example runs without a project root).

**DoD:**

- Report template includes the no-validation banner rule.
- The no-validation HITL gate is documented in Step 8.
- Example 1's report shows the banner.

---

## T9 — Expand the eval set

**Why:** 5 behavior evals + 1 trigger eval for a skill with 69 rules is thin.
Several rule paths and failure modes are entirely untested. Before dropping
the draft stamp, the eval set should cover the major branches.

**Scope:** Add the following evals to `evals/evals.json`. Each eval needs an
`id`, `name`, `prompt`, `input_files` or `input_inline`, `expected_output`,
and `assertions`.

| New eval | What it tests |
|----------|---------------|
| `eval-7-hook-generation` | A model with extracted pre-SQL but no `pre_hook` in config — assert D2-HOOK-001 fires, generates a `pre_hook` array, and the macro name is `edw_convert_to_pst`. |
| `eval-8-incremental-config` | A model with `materialized='incremental'` missing `on_schema_change` and `incremental_strategy` — assert D2-CFG-006 and D2-CFG-007 both fire as SAFE. |
| `eval-9-qualify-applied` | The Example 2 input but with `auto_apply_safe=true` and D3-QUAL-001 promoted to SAFE via `safety_overrides` — assert the QUALIFY rewrite is actually applied, not just flagged. |
| `eval-10-rollback-on-compile-fail` | Inject a malformed config block (e.g., unclosed quote) into a model in a dbt project that compiles cleanly otherwise — apply a SAFE change that doesn't fix the malformed block — assert the skill detects compile failure in Step 10 and rolls back to the original file content. |
| `eval-11-cisco-prefix-mapping` | A model named `WI_CUSTOMER_DIM.sql` that uses `source('raw', 'W_ORDER')` — assert D2-DEP-002 fires (W_ should be `ref()`, not `source()`). |
| `eval-12-timezone-safety` | A MT_ model with `EDW_CREATE_DTM = edw_convert_to_pst()` in the SELECT — assert D2-AUDIT-005 fires as REQUIRES_APPROVAL (not SAFE) per T3's reclassification. |
| `eval-13-no-validation-banner` | Run against a model file with no dbt project root, with at least one SAFE finding — assert the report contains the "Changes applied without compile validation" banner from T8. |
| `eval-14-d5-d6-disabled-by-default` | Run against a model with a live Snowflake connection available — assert that without explicitly enabling D5/D6 in config, no D5/D6 findings are emitted (per T6). |

**Trigger eval expansion:** Add to `eval-6-trigger-phrases`:

- `should_trigger`: "optimize this Cisco dbt model", "review my Cisco EDW
  model", "clean up this dbt model — it's on the Cisco platform"
- `should_not_trigger`: "optimize this dbt model for a non-Cisco project",
  "review my Databricks dbt model", "optimize this Snowflake model" (too
  generic — must explicitly mention dbt + Cisco or dbt + EDW)

**DoD:**

- `evals.json` contains at least 14 behavior evals (one trigger eval).
- Every newly reclassified rule from T3 has at least one eval covering its
  new classification.
- The trigger-eval positive list explicitly mentions Cisco; the negative list
  explicitly excludes generic dbt requests.

---

## T10 — Final pass: drop the draft stamp

**Why:** This is the gate. Only after all prior tasks are complete.

**Scope:**

1. Walk the entire package end-to-end. For each file:
   - Read it cold (pretend you've never seen it).
   - Note anything that contradicts another file. Fix.
   - Note anything that references a path that doesn't exist. Fix.
   - Note any rule ID mentioned in one file but not in `optimization-rules.md`.
     Add to the catalog or remove.
2. Run the eval set (or document how to). If you cannot run them, add a
   `evals/README.md` that documents the runner expectations.
3. Update `CHANGELOG.md`:
   ```
   ## [1.0.0] - <today>

   ### Changed
   - Renamed from `dbt-model-optimizer` to `dbt-model-optimizer-cisco` to make
     Cisco-specific conventions explicit in the skill identity.
   - Removed sub-agent framing; procedures are now loaded in-context, not
     delegated.
   - Reordered workflow so live profiling (D5/D6) runs before the HITL gate.
     Users now approve SAFE changes with full information.
   - Tightened SAFE classification. Rules that require external schema, var
     bindings, or timezone-semantic decisions moved to REVIEW or
     REQUIRES_APPROVAL.
   - D5/D6 (live profiling) shipped as experimental; defaulted to off.

   ### Added
   - Compile-validation banner in report when dbt project root unavailable.
   - Secondary HITL gate when >5 SAFE changes apply without compile validation.
   - 8 new behavior evals covering hook generation, incremental config,
     rollback, Cisco prefix mapping, timezone safety, and the no-validation
     path.

   ### Removed
   - `cisco_conventions.enabled` toggle (Cisco conventions are no longer
     optional in this skill — see new sibling skill for generic version,
     future work).
   - Sub-agent vocabulary throughout the skill.
   - Inline duplications of dialect detection, audit column rules, and CTE
     rules. References now have a single canonical source.
   ```
4. Flip `status: draft` → `status: active` in `SKILL.md`. Confirm
   `version: 1.0.0`.

**DoD — the final exit checklist:**

- [ ] Skill renamed (T1).
- [ ] No sub-agent vocabulary anywhere (T2).
- [ ] SAFE bar tightened; reclassified rules updated in every file (T3).
- [ ] One HITL gate, after full analysis (T4).
- [ ] One canonical source per rule family (T5).
- [ ] D5/D6 marked experimental in three places and off by default (T6).
- [ ] Frontmatter clean; no broken file references; version 1.0.0 (T7).
- [ ] No-validation banner present in report template and Example 1 (T8).
- [ ] At least 13 behavior evals + 1 expanded trigger eval (T9).
- [ ] CHANGELOG entry for 1.0.0 written.
- [ ] `status: active`.

---

## A note for the executing agent

If during execution you find a problem this brief doesn't anticipate — for
example, a rule whose Safety can't cleanly be classified under T3's bar, or a
file path that no longer makes sense after T5's de-duplication — **do not
silently invent a fix**. Stop, document the ambiguity in a top-level
`OPEN_QUESTIONS.md` file in the package root, and continue with the tasks
that don't depend on the resolution. The author will resolve the open
questions in a follow-up pass.

Better an honest open question than a silent guess that ships as v1.0.
