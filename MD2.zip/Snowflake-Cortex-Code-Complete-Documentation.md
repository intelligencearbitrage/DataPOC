# Snowflake Cortex Code — Complete Documentation

*Consolidated reference compiled from the Snowflake Documentation. Source tree rooted at* `https://docs.snowflake.com/en/user-guide/cortex-code/cortex-code`. *Compiled May 2026 (reflects CLI builds through 1.0.77). §16 (Cortex Code Desktop) is compiled from a user-supplied private-preview guide, not from the public docs — see the provenance note in that section.*

---

## Table of contents

1. [Overview](#1-overview)
2. [Core experiences at a glance](#2-core-experiences-at-a-glance)
3. [Cortex Code in Snowsight](#3-cortex-code-in-snowsight)
4. [Skills and Plugins in Snowsight](#4-skills-and-plugins-in-snowsight)
5. [Cortex Code CLI — getting started](#5-cortex-code-cli--getting-started)
6. [CLI reference](#6-cli-reference)
7. [CLI settings](#7-cli-settings)
8. [Managed settings (organization policy)](#8-managed-settings-organization-policy)
9. [Security best practices](#9-security-best-practices)
10. [Sandbox](#10-sandbox)
11. [Extensibility — Skills, Subagents, Hooks, MCP](#11-extensibility--skills-subagents-hooks-mcp)
12. [Bundled skills catalog](#12-bundled-skills-catalog)
13. [Model Context Protocol (MCP) support](#13-model-context-protocol-mcp-support)
14. [Agent Client Protocol (ACP) support](#14-agent-client-protocol-acp-support)
15. [Plugins](#15-plugins)
16. [Cortex Code Desktop (CoCo)](#16-cortex-code-desktop-coco)
17. [Cortex Code Agent SDK](#17-cortex-code-agent-sdk)
18. [Workflow examples](#18-workflow-examples)
19. [Cost, billing, and credit limits](#19-cost-billing-and-credit-limits)
20. [Changelog](#20-changelog)
21. [Legal notices](#21-legal-notices)
22. [Source map](#22-source-map)

---

## 1. Overview

Cortex Code is an AI-driven agent built into the Snowflake platform, aimed at data engineering, analytics, machine learning, and agent-building work. It runs on an autonomous agent framework that interacts directly with your Snowflake environment and is designed with awareness of Snowflake Role-Based Access Control (RBAC), schemas, and platform best practices. It supports data analysis, ML, and data engineering workflows through a consistent, context-aware interface.

Cortex Code is delivered through three end-user surfaces plus a programmatic SDK:

- **Cortex Code in Snowsight** — the persistent web-based entry point, embedded in Workspaces and Snowsight Admin pages. *Generally Available.*
- **Cortex Code CLI** — an agentic shell for power users and developers that bridges the local development environment (for example, VS Code or Cursor) and a Snowflake account. *Generally Available.*
- **Cortex Code Desktop (CoCo)** — a standalone, VS Code–style AI-powered IDE for Windows, macOS, and Linux; the most feature-rich surface, combining a conversational agent with file editing, terminal access, version control, notebooks, and browser automation. *Limited Access / Private Preview.*
- **Cortex Code Agent SDK** — Python and TypeScript libraries for building agentic applications on the same tools and agent loop. *Preview.*

Two open protocols and a plugin system extend the CLI:

- **Model Context Protocol (MCP)** — connect the agent to external tools/data (GitHub, Jira, internal APIs, databases). *Preview.*
- **Agent Client Protocol (ACP)** — embed Cortex Code as a local agent backend inside editors (Zed, JetBrains, VS Code, Neovim). *Preview.*
- **Plugins** — self-contained packages bundling skills, subagents, slash commands, hooks, and MCP servers. *Preview.*

### Availability

| Surface | Status | Accounts |
|---|---|---|
| Cortex Code in Snowsight | GA | Commercial (non-Gov), FedRAMP (Moderate/High), and KSA sovereign accounts, with cross-region inference enabled |
| Cortex Code CLI | GA | Commercial (non-Gov, VPS, Sovereign) accounts, with cross-region inference enabled |
| Cortex Code Desktop | Limited Access / Private Preview | Download-gated; metered separately via `CORTEX_CODE_DESKTOP_DAILY_EST_CREDIT_LIMIT_PER_USER`. Use governed by Snowflake's Preview Terms |
| Agent SDK / MCP / ACP / Plugins | Preview | — |

---

## 2. Core experiences at a glance

| Capability | Snowsight | CLI | Desktop (CoCo) |
|---|---|---|---|
| SQL & Python notebook authoring | ✔ | ✔ | ✔ |
| Account administration (credits, query perf, governance, permissions) | ✔ | ✔ | ✔ |
| Context awareness of the active file/notebook | ✔ | ✔ (via `@` file refs and working dir) | ✔ (rich `@`/`#`/`$`/`%` input syntax) |
| Visual diff / change review | ✔ | ✔ (`/diff`, `/review`) | ✔ (`/diff`, unified or side-by-side) |
| Local file read/write | ✖ | ✔ | ✔ |
| Tool orchestration (bash, git, SQL) | Limited | ✔ | ✔ |
| `AGENTS.md` / instruction files | ✔ (AGENTS.md; Agent Skills coming) | ✔ | ✔ (`CLAUDE.md` hierarchy) |
| RBAC + sandbox + tiered approvals | RBAC | Full | RBAC + two-mode permissions |
| Built-in Snowflake skills | ✔ | ✔ | ✔ |
| Custom tools, skills, subagents, hooks, profiles | Limited | ✔ | ✔ |
| Session persistence, git worktrees, themes | — | ✔ | ✔ |
| Graphical IDE (editor, notebooks, browser automation, table viewer) | ✖ | ✖ | ✔ |
| Jupyter notebook integration | — | — | ✔ |
| Browser automation | ✖ | ✖ | ✔ |
| Team/swarm parallel agents, scheduling/cron | — | Partial | ✔ |
| Persistent cross-session memory | — | ✔ (opt-in) | ✔ (opt-in) |

The CLI key differentiators versus Snowsight: direct connection using existing auth methods, execution of SQL/`git`/`bash`, validation of Cortex Analyst semantic models, management of multiple connections, local repository access (ideal for `dbt` projects or Streamlit apps), OS-level sandboxing, and a three-tier approval system with automatic risk assessment.

**Desktop (CoCo)** is positioned as the most feature-rich surface — effectively the CLI's agent and tools wrapped in a VS Code–style graphical IDE, adding an editor, interactive table viewer, inline data visualizations, Jupyter integration, browser automation, team/swarm orchestration, scheduling, and graphical managers for connections, skills, plugins, MCP, and hooks. See §16 for full detail.

---

## 3. Cortex Code in Snowsight

*Feature — Generally Available.*

Cortex Code provides an agentic experience across Snowsight: SQL development, data exploration, and account management. It uses intelligent orchestration to plan and execute multi-step tasks, selecting internal tools and pulling relevant context from your environment. It interprets intent, builds a plan, and executes steps while keeping context across the session, applying Snowflake best practices when generating or modifying code.

To open it: select the **Cortex Code** icon in the lower-right corner of Snowsight; the panel opens on the right. Type a question and submit. If the response contains SQL, you can execute it or copy it.

### Access control requirements

A role used to access Cortex Code must be granted:

| Database role | Notes |
|---|---|
| `SNOWFLAKE.COPILOT_USER` | Required for all users to access Cortex Code. |
| `SNOWFLAKE.CORTEX_USER` **or** `SNOWFLAKE.CORTEX_AGENT_USER` | At least one required. `CORTEX_AGENT_USER` adds agentic-workflow capabilities. |

Grant via `GRANT DATABASE ROLE`. Note: if your account previously opted out of (disabled) the legacy Snowflake Copilot, Cortex Code is also disabled — contact your account team to re-enable.

### Functional areas

**Agentic coding in Workspaces** — conversational coding assistant supporting:
- Code generation/development (SQL queries, new files, pipeline/analytics logic).
- Code modification/optimization (refine SQL, find logic/syntax errors, suggest performance/readability/cost improvements).
- Change review via a diff view (insertions/deletions highlighted before applying).
- Code explanation, follow-up questions.
- Inline catalog context — type `@` for a real-time search of catalog objects to add as prompt context.
- Quick actions on highlighted SQL: **Quick Edit**, **Format**, **Add to Chat**, **Explain**.
- **Fix** button in the results grid to repair failed SQL.
- AI-powered inline code suggestions *(Preview)*.

**AI code suggestions** *(Preview, open to all accounts)* — context-aware inline SQL suggestions shown as gray text at the cursor. Uses query history, current workspace content, table schemas, and recent executed queries. Triggered after a brief pause or right after accepting a suggestion.
- Accept: `Shift` + `Enter`.
- Dismiss: `Esc`, `Delete`, `Backspace`, or keep typing.
- With catalog suggestions present: `Shift` + `Enter` accepts the inline suggestion; down arrow + `Enter` selects a catalog option.
- Disable via: **Projects » Workspaces** → open a SQL file → **Settings** (upper right) → **User preferences** → toggle off **AI code suggestions** → **Close**.

**Intelligent product/documentation discovery** — uses Snowflake Horizon Catalog and official docs:
- Natural-language schema search; integrated Q&A on features/SQL/best practices.
- Snowflake Marketplace discovery (third-party data products, Native Apps, AI services).
- Internal Marketplace discovery (organizational listings shared privately within an org).
- Responses can include tags, masking policies, and lineage to validate assets.

**Simplified account administration** — governance/security info (user & role access, data ownership, PII tables) and cost management (usage/credit consumption, high-cost warehouses/queries).

### Supported models and regions (Snowsight)

Models (account must have access): **Claude Opus 4.6 (`claude-opus-4-6`, recommended)**, Claude Opus 4.5 (`claude-opus-4-5`), Claude Sonnet 4.5 (`claude-sonnet-4-5`), OpenAI GPT 5.4 (`openai-gpt-5.4`), OpenAI GPT 5.2 (`openai-gpt-5.2`).

Cross-region inference lets you use Cortex Code in any cloud/region even where a model is not locally available. An `ACCOUNTADMIN` enables it:

```sql
ALTER ACCOUNT SET CORTEX_ENABLED_CROSS_REGION = 'AWS_GLOBAL';
```

Valid identifiers: `AWS_GLOBAL`, `AWS_US`, `AWS_EU`, `AWS_APJ`, `AWS_AU`, `AZURE_GLOBAL`, `AZURE_US`, `ANY_REGION`. Guidance: choose the broadest setting that meets residency requirements; `AWS_GLOBAL`/`AZURE_GLOBAL` before regional values; `ANY_REGION` only for multi-cloud routing. `AWS_US` gives the highest quality for Claude Opus 4.6; `AZURE_US`/`AZURE_GLOBAL` for OpenAI GPT models. Model access may also be restricted at the org level.

### Web search

An `ACCOUNTADMIN` can let Cortex Code search the web and use results in responses/planning: go to **AI/ML > Agents** → **Settings** → toggle **Web search** on. Inputs are processed per the Snowflake Privacy Notice (§2). Web search may not be used to redistribute or build a competing web search service.

### Example prompts (Snowsight)

| Category | Example |
|---|---|
| Access discovery | "What databases do I have access to?" |
| Security auditing | "Find all tables that have PII in them." |
| Tag discovery | "List every table tagged PII = TRUE in ANALYTICS_DB." |
| Lineage | "Show the lineage from RAW_DB.ORDERS to downstream dashboards." |
| Metadata search | "Where can I find tables related to customer churn and subscription status?" |
| Marketplace discovery | "Find listings on Snowflake Marketplace that provide weather data for North America." |
| Internal Marketplace | "Show me organizational listings from the Internal Marketplace that contain customer sales data." |
| Logic explanation | "What does this SQL script do?" |
| Generation | "Write a query for top 10 customers by revenue and a 7-day moving average." |
| Refinement | "Update the top performers query to show the top 100." |
| Optimization | "Explain why this query is slow and optimize it." |
| Synthetic data | "Generate synthetic data for 30 days of sales… in the SAMPLESDATA.SALES table." |
| Cost | "Which 5 service types are using the most credits? Show me a visualization and how to reduce costs." |
| Notebooks / ML | "Build me a notebook for a customer churn prediction use case (pandas, matplotlib/seaborn, scikit-learn)…" |
| Deep learning | "Create a new notebook and build a CNN for the MNIST dataset." |
| Pipelines | "Create a dbt project to transform raw sales data." |
| Cortex Analyst | "Use the @models/revenue.yaml semantic model to answer 'What was revenue last month?'" |
| Model debugging | "Identify errors in my semantic model at @models/revenue.yaml" |

### Security and access (Snowsight)

Operates within existing authentication and RBAC. It does not store or modify credentials and only performs actions permitted by the active role. **It always starts a session using your default role**, regardless of the role selected in worksheets/workspaces/the role selector. You can ask it to switch roles mid-session (e.g., "switch to the SYSADMIN role"). For permissions errors, verify the default role's privileges, change the default role with `ALTER USER`, or ask Cortex Code to use a specific role for the session.

### Cortex Code in Workspaces

1. Sign in to Snowsight → **Projects » Workspaces**.
2. Open a workspace with the relevant file (e.g., a SQL file).
3. Select the **Cortex Code** icon (bottom-right).
4. Enter a natural-language prompt; type `@` to add catalog objects as inline context.
5. Review the output (answer, suggested code, or modified query).
6. For coding tasks, review the diff (insertions/deletions) and apply directly.
7. Refine with follow-ups, convert files to other object types (notebook, semantic view), or integrate functions like AI SQL.

**Customizing with AGENTS.md and Agent Skills** — `AGENTS.md` is an open format for guiding coding agents. Place an `AGENTS.md` in the workspace root for persistent instructions automatically included in every conversation. Support for Agent Skills is coming.

### Cortex Code in Notebooks

Within Notebooks in Workspaces, Cortex Code can:
- Create and manage notebooks in the Workspaces directory.
- Add, remove, and reorder SQL, Python, and Markdown cells.
- Edit code using pre-installed packages and proper notebook syntax (e.g., cell referencing).
- Generate visualization code (matplotlib, seaborn, plotly, altair).
- Run an entire notebook or specific cells.

### Cortex Code agent for dbt Projects on Snowflake

Supports the full dbt lifecycle: explore raw sources and infer relationships; scaffold staging/intermediate models; build multi-model DAGs and metrics; add data-quality tests and incremental logic; run dbt commands; generate/maintain docs; inspect deployed dbt project objects.

| Use case | Example prompt |
|---|---|
| Explore sources | "List all source tables in the bronze layer and summarize key columns, data types, and likely primary keys. Propose staging models for each source." |
| Prototyping | "Create models to compute daily profitability by truck and location. Generate the DAG and propose dependencies." |
| Data quality | "Add not_null and accepted_values tests to key dimensions. Suggest uniqueness tests for IDs based on inferred keys." |
| Incremental logic | "Convert the main fact model to an incremental model partitioned by order_date, with merge behavior for late-arriving data." |
| Documentation | "Generate docs for the project and draft descriptions for new models and key columns based on source context." |

### Cortex Code vs. Snowflake Intelligence vs. legacy Copilot

| Feature | Cortex Code | Snowflake Intelligence | Snowflake Copilot (legacy) |
|---|---|---|---|
| Use case | Development & operational workflows (SQL authoring, data exploration, admin) | Natural-language interface for complex data questions and analysis | Previous iteration for docs help and basic SQL |
| Primary integration | Snowsight + Workspaces, context-aware | Snowflake Intelligence UI + Cortex Agents API | Separate SQL/UI copilot |
| Scope | SQL authoring, exploration, doc search, admin | Q&A, insights, analysis | Limited SQL/UI assistance |
| Key capabilities | Generate/modify SQL, diff review, explain code | Analyze data, summaries, NL interaction | Contextual SQL suggestions, limited help |
| Design focus | Unified AI across coding/docs/admin | Conversational insights & query assistance | Deprecated in favor of Cortex Code |

---

## 4. Skills and Plugins in Snowsight

Skills extend Cortex Code with specialized capabilities invoked by typing `/` in the message box.

- **Built-in skills** — available from any Snowsight page; the list grows as teams add skills. Type `/` to see and select.
- **Personal skills** — created in a workspace to tailor Cortex Code to your workflows. Add via **Upload Skill File(s)**, **Upload Skill Folder(s)**, or **+ Create Skill**. Stored in the workspace's `.snowflake/cortex/skills` directory; invoke with `/`. Personal skills are scoped to the workspace where created — not available in other workspaces or outside a workspace.
- **Skills in Horizon Catalog** — skills can be shared/discovered through the Horizon Catalog. The `+` menu and `/` command show Local, Built-in, and Skill Catalog skills. Use the `share-skill` skill to get a share link; paste a skill link into the message box to install. The `find-skill` skill aids discovery/invocation.

**Catalog management (ACCOUNTADMIN):** **Catalog » Skills** to browse/search; select a skill to view details; actions include change access (role/user), change owner, delete.

---

## 5. Cortex Code CLI — getting started

*Feature — Generally Available.* The CLI is an agentic shell that connects your local environment to a Snowflake account. If you don't have a Snowflake account, you can sign up for a free CLI trial at `signup.snowflake.com/cortex-code`.

### Installation

**macOS / Linux / WSL:**
```bash
curl -LsS https://ai.snowflake.com/static/cc-scripts/install.sh | sh
```
Installs the latest version; the `cortex` executable goes to `~/.local/bin` by default, and the installer adds it to your PATH via your shell profile.

**Windows native (PowerShell):**
```powershell
irm https://ai.snowflake.com/static/cc-scripts/install.ps1 | iex
```
The executable goes to `%LOCALAPPDATA%\cortex` by default and is added to PATH. Invoke from Run (Win+R), `cmd.exe`, or PowerShell.

### Connect to Snowflake

Run `cortex`. A setup wizard prompts you to choose an existing connection from `~/.snowflake/connections.toml` or create a new one (choose **More options** to enter account details). The `connections.toml` file is shared with the Snowflake CLI (`snow`), so existing Snowflake CLI connections work.

### First requests

Try `What can I do with Cortex Code?` Cortex Code orchestrates Snowflake-native skills and any configured MCP tools, displaying its reasoning steps and actions in the terminal. In plan mode it confirms each action.

Example requests:
- *Discover catalog:* "What databases do I have access to?" · "List every table tagged PII = TRUE in ANALYTICS_DB" · "Show the lineage from RAW_DB.ORDERS to downstream dashboards"
- *Generate/run SQL:* "Write a query for top 10 customers by revenue" · "Add a 7-day moving average and show me the results" · "Explain why this query is slow and optimize it"
- *Build apps:* "Build a Streamlit dashboard on SALES_MART.REVENUE with filters for date and region" · "Create a dbt project to transform raw sales data"
- *Cortex Analyst:* "Use the @models/revenue.yaml semantic model to answer 'What was revenue last month?'" · "Debug my semantic model at @models/revenue.yaml"

### Prerequisites

- A Snowflake user with the permissions needed for your data/operations, plus the `SNOWFLAKE.CORTEX_USER` database role (granted to all users via PUBLIC by default, unless your org revoked it).
- Network access to your Snowflake server.
- Snowflake CLI installed on the workstation.
- A supported platform (see below).
- Local terminal access to `bash`, `zsh`, or `fish`.

### Supported platforms

| Platform | Architecture |
|---|---|
| macOS | arm64, x64 (Apple Silicon or Intel) |
| Linux | x64, arm64 (Intel or ARM) |
| Windows | WSL on x64/amd64 (Intel); Native on x64 |

### Supported models (CLI)

At least one model must be available to your account (e.g., via `CORTEX_MODELS_ALLOWLIST`). Snowflake recommends `auto`, which selects the highest-quality available model and follows new models as they ship. Switch with `/model` inside a session.

| Model | Identifier |
|---|---|
| Auto | `auto` |
| Claude Opus 4.6 | `claude-opus-4-6` |
| Claude Sonnet 4.6 | `claude-sonnet-4-6` |
| Claude Opus 4.5 | `claude-opus-4-5` |
| Claude Sonnet 4.5 | `claude-sonnet-4-5` |
| Claude Sonnet 4.0 | `claude-4-sonnet` |
| OpenAI GPT 5.2 | `openai-gpt-5.2` |

*(The changelog notes GPT 5.5 support added in 1.0.77.)*

### Cloud regions / cross-region inference (CLI)

If a model isn't available in your region, use cross-region inference. An `ACCOUNTADMIN` sets `CORTEX_ENABLED_CROSS_REGION`:

```sql
ALTER ACCOUNT SET CORTEX_ENABLED_CROSS_REGION = 'AWS_US';
```

Model availability by setting (per CLI docs):

| Model | Cross-cloud (Any region) | AWS US | AWS EU | AWS APJ | Azure US | Azure EU |
|---|---|---|---|---|---|---|
| `claude-opus-4-6` | ✔ | ✔ | ✔ | | | |
| `claude-sonnet-4-6` | ✔ | ✔ | ✔ | | | |
| `claude-opus-4-5` | ✔ | ✔ | ✔ | | | |
| `claude-sonnet-4-5` | ✔ | ✔ | ✔ | | | |
| `claude-4-sonnet` | ✔ | ✔ | ✔ | ✔ | | |
| `openai-gpt-5.2` | ✔ | | | | ✔ | |

Recommended settings: **AWS_US** (best for Claude Opus 4.x), **AWS_EU**, **AWS_APJ** (may be limited to Claude Sonnet 4.0), **ANY_REGION** (all models, best-effort global routing), **AZURE_US** (OpenAI GPT 5.2).

---

## 6. CLI reference

### Starting Cortex Code

| Command | Description |
|---|---|
| `cortex` | Start in current directory |
| `cortex -c production` | Start with a specific connection |
| `cortex -w /path/to/project` | Start in a specific directory |
| `cortex -w /new/project -c myconn` | Combine workdir and connection |
| `cortex --continue` | Continue last session |
| `cortex --resume <session_id>` | Resume a specific session |

### CLI options

| Option | Description |
|---|---|
| `-c, --connection <name>` | Use a specific Snowflake connection |
| `-w, --workdir <path>` | Set working directory for file operations |
| `-m, --model <model_name>` | Specify the AI model |
| `--plan` | Plan mode: require approval before all actions |
| `--bypass` | Auto-approve all planned actions |
| `--dangerously-allow-all-tool-calls` | Disable tool-call permission prompts (caution) |
| `--continue` | Resume most recent conversation |
| `-r, --resume <session_id>` | Resume a session by ID, or `last` |
| `-p, --print "<prompt>"` | Run prompt, print response, exit |
| `-f, --file <file>` | Read prompt from a file, run, exit |
| `--output-format stream-json` | JSON output (for scripting) |
| `-V, --version` | Show installed version |
| `--help` | Show CLI help |

Connections live in `~/.snowflake/connections.toml`. Session IDs appear at startup and exit, and are stored under `~/.snowflake/cortex/conversations/`.

Examples:
```bash
cortex -w /path/to/project
cortex --continue -c production
cortex -p "List all Python files" --output-format stream-json
```

### Top-level commands

| Command | Description |
|---|---|
| `cortex update` | Update to latest version (`cortex update <version>` for a specific build) |
| `cortex --version` | Verify after update |
| `cortex mcp list` | List configured MCP servers |
| `cortex mcp add` | Add a new MCP server (interactive) |
| `cortex mcp remove <server_name>` | Remove an MCP server |

### Interactive mode — keyboard shortcuts

| Shortcut | Action |
|---|---|
| `Ctrl+C` | Cancel current operation |
| `Ctrl+C Ctrl+C` | Exit the CLI |
| `Ctrl+L` | Clear terminal screen (keeps conversation) |
| `Up/Down arrows` | Navigate command history |
| `Tab` | Command completion |

### Slash commands

**Session management:** `/help`, `/plan`, `/plan_off`, `/clear` (`/cls`), `/new`, `/rename <title>`, `/exit` (`/quit`), `/resume` (`/r`, `/sessions`), `/rewind` (go back *n* steps or pick interactively), `/skill list`, `/mcp-status`, `/fork`.

**Model and mode:** `/model`, `/plan`, `/plan-off`, `/bypass`, `/bypass-off`, `/status`.

**Snowflake and data:** `/sql <query>`, `/sql <query> --limit <n>`, `/table [<file>]` (`/csv`), `/connections` (`/conn`).

**Development tools:** `/sh` (`! <command>`), `/diff` (`/changes`, `/review`), `/worktree`, `/dbt`, `/lineage`.

**Configuration:** `/settings`, `/theme`, `/sandbox`, `/add-dir <path>`.

**Extensibility:** `/skill` (`/skills`), `/mcp`, `/hooks`, `/commands` (`/cmds`), `/agents`.

**Utilities:** `/tasks`, `/feedback` (saved locally as a `.tgz`), `/update`.

### Session storage

| Path | Description |
|---|---|
| `~/.snowflake/cortex/conversations/` | Session files |
| `~/.snowflake/cortex/settings.json` | General settings |
| `~/.snowflake/cortex/permissions.json` | Permission preferences |

### Command details

`/sql` examples:
```text
/sql SELECT * FROM users
/sql SELECT * FROM large_table --limit 1000
```
Multi-line: use `Ctrl+J` for newlines. Results open in the table viewer (`Ctrl+T`).

`/worktree` (git worktrees): `create feature-branch`, `list`, `switch feature-branch`, `delete feature-branch`.

`/sandbox`: `/sandbox` (selector), `on`/`off` (container sandbox), `status`, `runtime on`/`runtime off` (OS sandbox), `mode auto`/`mode regular`.

`/mcp`: `/mcp` (status viewer), `list`, `start <server>`, `get <server>`, `remove <server>`.

### Batch mode

```bash
cortex -p "<prompt>"
cortex -f request.txt
cortex --output-format stream-json -p "<prompt>"
cortex -c prod --workdir /app -p "..."
```

### Exit codes

| Code | Meaning |
|---|---|
| 0 | Success |
| 1 | General error |
| 2 | Configuration error |
| 3 | Connection error |
| 4 | Permission denied |
| 130 | Interrupted by user (Ctrl+C) |

### Configuration & setup

- **Updates:** Self-updates when available; manual via `cortex update` (or `cortex update <version>`). Disable auto-update by adding `"autoUpdate": false` to `~/.snowflake/cortex/settings.json`.
- **Manually adding a connection:** create `~/.snowflake/connections.toml` (`chmod 600`), then add a block:
  ```toml
  [myaccount]
  account       = "<ACCOUNT>"
  user          = "<USERNAME>"
  authenticator = "externalbrowser" # browser-based SSO; omit for PAT
  password      = "<PAT>"           # PAT auth; omit for SSO
  warehouse     = "<WAREHOUSE>"
  role          = "<ROLE>"
  database      = "<DATABASE>"
  schema        = "<SCHEMA>"
  ```
  Use either `authenticator` (SSO) or `password` (PAT), not both. Get a PAT from Snowsight.
- **Shell completions:**
  - bash: `cortex completion bash > ~/.bash_completion.d/cortex`
  - zsh: `cortex completion zsh > ~/.zsh/completions/_cortex`
  - fish: `cortex completion fish > ~/.config/fish/completions/cortex.fish`
  - Then `exec $SHELL`. (`echo $(basename $SHELL)` tells you your default shell.)

### Directory structure (created on install)

```text
~/.snowflake/cortex/
   ├── settings.json    # Main configuration
   ├── mcp.json         # MCP server configs
   ├── conversations/   # Session history
   ├── skills/          # Global skills
   ├── commands/        # Custom commands
   ├── hooks/           # Hook scripts
   ├── profiles/        # Team profiles
   └── cache/           # Temporary cache
```

### Troubleshooting

- **Command not found:** ensure `~/.local/bin` is on `PATH` (`export PATH="~/.local/bin:$PATH"`, then persist in `~/.bashrc`).
- **Permission denied:** `chmod +x ~/.local/bin/cortex`.
- **Connection errors:** confirm `~/.snowflake/connections.toml` exists and is valid (`cat` it); try `cortex -c myaccount`.

---

## 7. CLI settings

Settings are controlled via managed policy (if any), configuration files, environment variables, and command-line arguments.

### Configuration files

| File | Purpose |
|---|---|
| `<admin-managed path>/managed-settings.json` | Org-managed policy (optional) |
| `~/.snowflake/cortex/settings.json` | Main CLI settings |
| `~/.snowflake/cortex/permissions.json` | Permission preferences |
| `~/.snowflake/cortex/mcp.json` | MCP server config |
| `~/.snowflake/config.toml` | Snowflake connections (shared with Snowflake CLI) |

Full config-directory layout:
```text
~/.snowflake/cortex/
├── settings.json        # Main settings
├── mcp.json             # MCP server configs
├── permissions.json     # Saved permissions
├── hooks.json           # Global hooks
├── history              # Command history
├── conversations/       # Session files
├── cache/               # Temporary cache
│   ├── table_cache.json # SQL result metadata
│   └── sql_result_cache/# Parquet files
├── logs/                # Log files
├── memory/              # Persistent memory
├── agents/              # Custom agents
├── skills/              # Global skills
├── commands/            # Custom commands
├── hooks/               # Hook scripts
└── remote_cache/        # Cloned repos
```

### Settings precedence (highest → lowest)

1. Managed-settings restrictions (`settings.*` in `managed-settings.json`) — cannot be overridden.
2. Profile overrides (`settingsOverrides` from the active profile).
3. Project settings (`.cortex/settings.json` or `.claude/settings.json` in the working dir).
4. Managed-settings defaults (`defaults.*`) — users may override in their own `settings.json`.
5. Global user settings (`~/.snowflake/cortex/settings.json`).
6. Built-in defaults.

Permissions follow a separate evaluation order (see §8).

### `settings.json`

```json
{ "compactMode": true, "autoUpdate": true, "theme": "dark" }
```
- `compactMode` — compact output formatting.
- `autoUpdate` — automatic updates.
- `theme` — `light` or `dark`.

### `permissions.json`

```json
{ "onlyAllow": ["read_file", "execute_sql"], "defaultMode": "ask", "dangerouslyAllowAll": false }
```
- `onlyAllow` — allowed tool patterns.
- `defaultMode` — `ask`, `allow`, or `deny`.
- `dangerouslyAllowAll` — allow all tools without prompts (unsafe).

### Environment variables

| Variable | Description |
|---|---|
| `SNOWFLAKE_HOME` | Override the default `~/.snowflake` directory |
| `CORTEX_AGENT_MODEL` | Override model selection |
| `CORTEX_ENABLE_MEMORY` | Enable the memory tool (`true`/`1`) |
| `COCO_DANGEROUS_MODE_REQUIRE_SQL_WRITE_PERMISSION` | Require confirmation for SQL writes in bypass mode |

### Command-line overrides

`cortex -c production`, `cortex --workdir /path`, `cortex --continue`, `cortex --resume <session_id>`, `cortex --plan`, `cortex --dangerously-allow-all-tool-calls`.

---

## 8. Managed settings (organization policy)

IT administrators can enforce CLI behavior org-wide via a system-owned `managed-settings.json` that users can't modify; it takes precedence over all user-level config. When present, the CLI shows a managed-mode banner at startup. Typically deployed via MDM (Jamf, Intune, SCCM) or configuration management (Ansible, Chef, Puppet).

### File locations

| Platform | Path |
|---|---|
| macOS | `/Library/Application Support/Cortex/managed-settings.json` |
| Linux/WSL | `/etc/cortex/managed-settings.json` |
| Windows | `%ProgramData%\Cortex\managed-settings.json` |

If absent, the CLI runs unmanaged. If present but invalid JSON / failing schema validation, the CLI applies a restrictive fallback ("Enforcement config error - restricted mode") so a malformed file can't silently grant access.

### Schema

```json
{ "version": "1.0", "permissions": {}, "settings": {}, "required": {}, "defaults": {}, "files": {}, "ui": {} }
```
`version` must be `"1.0"`. All top-level sections are optional.

**`permissions`**
```json
{ "permissions": {
    "onlyAllow": ["read","write","bash(git:*)","skill(bundled:*)"],
    "deny": ["bash(rm:*)","skill(remote:*)"],
    "defaultMode": "allow",
    "dangerouslyAllowAll": false } }
```
- `onlyAllow` — allowlist; unmatched items blocked unless `defaultMode` is `allow`.
- `deny` — denylist; always wins over allow.
- `defaultMode` — `allow` (default) or `deny`.
- `dangerouslyAllowAll` — whether users can use `--dangerously-allow-all-tool-calls` (default `false` in managed mode).

**`settings`** (forced runtime behaviors)
- `forceNoHistoryMode` (default `false`) — disable all conversation history persistence.
- `forceSandboxEnabled` (default `false`) — force the sandbox on.
- `forceSandboxMode` — `"regular"` (prompt per new path) or `"autoAllow"` (silently permit paths within the sandbox boundary).

**`required`** — `minimumVersion` (semver, e.g. `"0.26.0"`); older versions are blocked until updated.

**`defaults`** (overridable suggestions) — `connectionName`, `profileName`, `theme` (`dark`/`light`/`pro`).

**`files`** — `connectionsFile`, `mcpFile` (absolute paths to admin-provided configs).

**`ui`** — `showManagedBanner` (default `false`), `bannerText` (default "This device is managed by your organization"), `hideDangerousOptions` (default `false`).

### Permission patterns

Two forms: simple name (`"bash"`, `"read"`) and filtered name `type(filter)` (`"bash(git:*)"`, `"account(myorg-prod)"`). Both support `*` and `?` globs; matching is case-insensitive.

| Pattern | Controls |
|---|---|
| `read` / `write` / `edit` | File read/write/edit tools |
| `bash` | All bash invocations |
| `bash(git:*)` / `bash(dbt:*)` / `bash(ls:*)` / `bash(rm:*)` | Bash limited to a command |
| `snowflake_sql_execute` | SQL execution against Snowflake |
| `mcp(*)` / `mcp(https://*.company.com/*)` | All MCP servers / by URL glob |
| `skill(bundled:*)` / `skill(profile:*)` / `skill(profile:my-profile)` / `skill(user:*)` / `skill(project:*)` / `skill(remote:*)` | Skills by source |
| `plugin(*)` / `plugin(bundled:*)` | All / built-in plugins |
| `account(myorg)` / `account(myorg-*)` | Snowflake account by name/glob |

`bash(command:*)` matches the first token of the shell command. If plain `"bash"` appears in `onlyAllow`, any bash command is allowed; if only `"bash(git:*)"` appears, only `git` commands run.

### Permission evaluation order

1. Managed `deny` match → block (cannot be overridden).
2. Profile `deny` match → block.
3. Managed `onlyAllow` set and no match → block.
4. Profile `onlyAllow` set for that type and no match → block (profile `onlyAllow` is type-scoped).
5. `defaultMode` decides (`deny` blocks, `allow` permits).

Guarantees: a profile can't grant what managed settings deny, can't expand the managed allowlist, and can only further restrict within the managed boundary.

### Example: high-security deployment

```json
{
  "version": "1.0",
  "permissions": {
    "onlyAllow": ["read","write","edit","bash","snowflake_sql_execute",
      "skill(bundled:*)","skill(profile:*)",
      "mcp(https://*.mycompany.com/*)","account(mycompany-*)"],
    "deny": ["bash(rm:*)","bash(curl:*)","skill(remote:*)"],
    "defaultMode": "allow", "dangerouslyAllowAll": false },
  "settings": { "forceNoHistoryMode": true, "forceSandboxEnabled": true, "forceSandboxMode": "regular" },
  "required": { "minimumVersion": "0.26.0" },
  "files": { "connectionsFile": "/etc/cortex/connections.toml", "mcpFile": "/etc/cortex/mcp.json" },
  "ui": { "showManagedBanner": true, "bannerText": "Managed by IT Security", "hideDangerousOptions": true }
}
```

---

## 9. Security best practices

Core practices: secure authentication, protected config files, appropriate roles/access, secure conversation history, verified MCP servers, and production-safety protocols. In managed environments, an org policy file may restrict tools, accounts, or disable bypass.

### Credentials
- Prefer browser-based auth (`authenticator = "externalbrowser"`).
- Use PATs to scope access to a role; set expiration ≤ 90 days, descriptive names, rotate regularly.
- Protect files: `chmod 600 ~/.snowflake/connections.toml` and `chmod 700 ~/.snowflake/cortex`.
- Never commit credentials (`echo "~/.snowflake/connections.toml" >> ~/.gitignore`).
- Store credentials/tokens in environment variables and reference with `${VARIABLE_NAME}`.

### Roles & access
- Use environment-appropriate roles (e.g., read-only role in prod, broader in dev).
- Never use `ACCOUNTADMIN` for routine work; grant least privilege.

### Conversation history
- Stored in `~/.snowflake/cortex/conversations/`. Use `cortex --private` to disable session saving for sensitive work, or `/clear` before exit. `chmod 700` the conversations directory.

### MCP security
- Only install trusted MCP servers (`cortex mcp list`, `cortex mcp remove <server>`).
- Never hardcode MCP credentials — use env vars (`export GITHUB_TOKEN=…`, then `${GITHUB_TOKEN}` in config).

### Production safety
- Enable plan mode (`/plan`) to review actions before execution.

### If a PAT is compromised
- Revoke it in Snowsight immediately, generate a new one, and store it in env vars (not config files).
- Review query history: `INFORMATION_SCHEMA.QUERY_HISTORY_BY_USER` (real-time, your own history, no special privileges). Admins can use `SNOWFLAKE.ACCOUNT_USAGE.QUERY_HISTORY` (up to ~45 min latency).

### Operational modes (three-tier)

| Mode | Indicator | Commands | Behavior |
|---|---|---|---|
| Confirm actions | Blue ⏵⏵ | default | Prompts before potentially dangerous actions |
| Plan | Orange ⏸ | `/plan`, `/plan-off` | Presents a plan before acting |
| Bypass | Red >> | `/bypass`, `/bypass-off` | All tool calls auto-approved (trusted environments only) |

Press `Shift-Tab` to cycle modes.

### Permission types

`EXECUTE_COMMAND` (bash/shell), `FILE_READ`, `FILE_WRITE`, `FILE_EDIT`, `WEB_ACCESS`.

### Trust model (experimental)

| Level | Examples | Behavior |
|---|---|---|
| SAFE | `ls`, `cat`, `echo`, `grep` | Auto-approved |
| LOW | create new files (`touch`) | Usually auto-approved |
| MEDIUM | edit files (`nano`), moderate bash | Prompts in Confirm mode |
| HIGH | `rm`, `curl`, `wget`, `sudo` | Always prompts |
| CRITICAL | `rm -rf`, destructive ops | Extra confirmation |

SQL categories: `READ_ONLY` (SELECT/SHOW/DESCRIBE → auto-approved); `WRITE` (INSERT/UPDATE/DELETE/CREATE → prompts); `USE_ROLE` (USE ROLE/WAREHOUSE → prompts).

### Hook-based permission policy
A `PreToolUse` hook can auto-approve commands, returning JSON such as `{"hookSpecificOutput": {"hookEventName":"PreToolUse","permissionDecision":"allow","permissionDecisionReason":"Approved by policy"}}`.

### Permission prompts & caching
On a prompt you can approve/deny and remember the choice: "Always allow (this session)" or "Always allow (persist)". Persistent permissions live in `~/.snowflake/cortex/permissions.json`, scoped by project dir/tool type/command pattern. Delete the file to reset all; remove an entry to reset one project; use `/new` (or restart) to reset the session cache.

Permission env vars: `CORTEX_PERMISSION_CACHE_TTL_SECONDS`, `COCO_DANGEROUS_MODE_REQUIRE_SQL_WRITE_PERMISSION` (prompt for SQL writes even in bypass).

### Security checklist
PATs ≤ 90-day expiration · file permissions 600/700 · never commit credentials · least-privilege roles · no ACCOUNTADMIN for routine work · plan mode for prod, bypass only in trusted environments · trusted MCP servers only · credentials in env vars · hooks for automated policy checks · periodic permission audits.

---

## 10. Sandbox

*Experimental.* The CLI can run shell commands inside a sandbox to restrict filesystem, network, and process capabilities.

### Platform support

| Platform | Implementation | Dependencies |
|---|---|---|
| macOS | `sandbox-exec` (built-in) | `ripgrep` |
| Linux | `bubblewrap` | `bubblewrap`, `socat`, `ripgrep` |
| Windows | Native restricted tokens | None |

Install deps — macOS: `brew install ripgrep`; Debian/Ubuntu: `sudo apt-get install bubblewrap socat ripgrep`; Fedora/RHEL: `sudo dnf install bubblewrap socat ripgrep`.

### Enabling

Slash commands: `/sandbox` (selector), `/sandbox runtime on|off|status`, `/sandbox status`. Or in settings:
```json
{ "sandbox": { "enabled": true } }
```
Default permission mode is `"regular"`; set `"mode": "autoAllow"` explicitly to auto-run sandboxable commands.

### Permission modes
- **Auto-allow** (`autoAllow`) — sandboxable commands run without prompting; non-sandboxable ones (e.g., network to non-allowed domains) fall back to normal permission flow.
- **Regular** (`regular`) — all commands prompt, even inside the sandbox.

Set with `/sandbox mode auto` / `/sandbox mode regular`.

### Filesystem restrictions
- Always allowed: working directory (read+write); skills directory (`~/.snowflake/cortex/skills`); context directory (`~/.snowflake/cortex/.ctx`) when `ctxAvailable`.
- Always denied for write (regardless of config): shell config files (`~/.bashrc`, `~/.bash_profile`, `~/.zshrc`, `~/.zprofile`, `~/.profile`, `~/.bash_login`, `~/.bash_logout`); git hooks (`~/.git/hooks`, `.git/hooks`); SSH config (`~/.ssh/authorized_keys`, `~/.ssh/config`); managed-settings dirs/files.
- Custom rules: `allowRead` (empty = all), `denyRead` (wins), `allowWrite` (empty = working dir only), `denyWrite` (wins). Deny always beats allow.

### Network restrictions
`allowedDomains` (empty = all; supports `*.example.com`), `deniedDomains` (wins), `allowLocalBinding` (default `false`).

### Unsandboxed command fallback
`allowUnsandboxedCommands` — `true` (default): the agent can request host execution (you approve). `false`: commands must run sandboxed or appear in `excludedCommands`, else they fail. `excludedCommands` (e.g., `["docker","kubectl"]`) always run on the host via the normal permission flow.

### Full settings object
```json
{ "sandbox": {
    "enabled": false, "mode": "regular",
    "allowUnsandboxedCommands": true, "excludedCommands": [],
    "permissions": { "allow": [], "deny": [] },
    "network": { "allowedDomains": [], "deniedDomains": [], "allowLocalBinding": false },
    "filesystem": { "allowRead": [], "denyRead": [], "allowWrite": [], "denyWrite": [] },
    "ctxAvailable": true } }
```
`permissions.allow`/`deny` support patterns like `WebFetch(domain:example.com)`, `Edit(path)`, `Read(path)`, `Bash(command)`.

### Scopes
Project-level (`.snowflake/cortex/settings.json`) > user-level (`~/.snowflake/cortex/settings.json`) > managed/enforced (via managed settings).

---

## 11. Extensibility — Skills, Subagents, Hooks, MCP

The CLI has four extensibility mechanisms: **Skills**, **Subagents**, **Hooks**, and **MCP**.

### Skills

Skills are markdown files that inject domain-specific instructions and (optionally) enable tools. They contain instructions/best practices, when-to-use guidance, example workflows, and optional tool configs. Invoking a skill injects its instructions into the conversation. Run `/skill list`; invoke by name.

**Skill locations (highest → lowest priority):** Project (`.cortex/skills/` or `.claude/skills/`) · User (`~/.snowflake/cortex/skills/` or `~/.claude/skills/`) · Global (`~/.snowflake/cortex/skills/`) · Session (temporary) · Remote (cloned from git, cached) · Bundled (built-in).

**Creating a skill:** a directory with a `SKILL.md` (plus optional examples/templates). Locations: project `.cortex/skills/` or `.claude/skills/`; global `~/.snowflake/cortex/skills/`; user `~/.claude/skills/`.
```bash
mkdir -p .cortex/skills/my-skill
```
`SKILL.md` uses YAML frontmatter:
```yaml
---
name: database-admin
description: Database administration tasks
tools:
- snowflake_sql_execute
- snowflake_object_search
---
```
Verify with `$$`; invoke with `$my-skill …`.

**Best practices:** be specific; provide examples; include edge cases; keep focused (one skill = one domain).

**Managing skills:** `/skill` (interactive), `/skill list`, `/skill sync <name>` (sync to global), `/skill add <path>` (local path, Git repo, tarball, or Snowflake stage). Conflicts (same skill in multiple locations with differing content) show a conflict indicator; resolve with `/skill sync`.

**Composing:** `> $code-review Review @src/auth.py following $security-guidelines`.

**Sharing (recommended via Git or Snowflake stage):**
```bash
/skill add https://github.com/org/my-skills.git
cortex skill publish ./my-skills --to-stage @MY_DB.MY_SCHEMA.MY_STAGE/skills/
cortex skill add @MY_DB.MY_SCHEMA.MY_STAGE/skills/
cortex profile publish data-analyst --skill-stage @MY_DB.MY_SCHEMA.MY_STAGE/skills/
# Snowflake Git repo mirror:
cortex skill publish --from-git https://github.com/org/my-skills.git --to-repo MY_DB.MY_SCHEMA.MY_SKILLS_REPO
cortex skill add @MY_DB.MY_SCHEMA.MY_SKILLS_REPO/branches/main/
```
For internal stages: grant `READ` to loaders and `WRITE` to publishers (grant `READ` first).

**CLI skill commands:** `cortex skill list | add <path> | update <source> | publish [path] --to-stage <stage> | publish --from-git <url> --to-repo <repo> | remove <path>`.

### Subagents

Autonomous, specialized agents that run independently with their own context and tool access, in foreground or background, enabling parallel execution and complex multi-step workflows.

**Built-in types:**
- `general-purpose` — all tools; complex research, multi-step changes, multi-tool tasks.
- `explore` — fast codebase exploration (find files, search code, understand structure). Thoroughness: `"quick"`, `"medium"`, `"very thorough"`.
- `plan` — design implementation plans, identify critical files, evaluate trade-offs.
- `feedback` — structured feedback collection.

**Running:** Cortex Code delegates automatically (e.g., "Find all files that import the authentication module"), or you request explicitly ("Use an Explore agent…", "Launch a Plan agent…"), in parallel ("In parallel, search for all test files and all config files"), or in the background ("Run a background agent to refactor all the test files"). Background agents return an ID; retrieve output ("Get the output from agent abc1234"); monitor via `/agents` or `Ctrl-B`; stop ("kill agent abc1234"); resume killed agents (context retained indefinitely).

**Agent types:** Autonomous (no interaction, never blocks), Non-Autonomous (may ask clarifying questions / request permissions), Custom (user-defined via markdown).

**Creating custom subagents** — markdown with YAML frontmatter (name, description, tools, model) + system prompt body. Locations: project `.cortex/agents/` or `.claude/agents/`; global `~/.snowflake/cortex/agents/`; user `~/.claude/agents/`.
```yaml
---
name: test-runner
description: Runs tests and reports results
tools:
- Bash
- Read
- Grep
---
# Test Runner Agent
...
```
Tool access: `"*"` (all) or specific tools. Model: `model: claude-sonnet-4-5` (overrides session default) or `model: auto`.

**Worktree isolation:** run agents in isolated git worktrees/branches (`agent/<agentId>`) for parallel, conflict-free experimentation ("Run a background agent with worktree isolation to implement feature X").

**Swarm pattern:** launch multiple agents in parallel for code analysis, refactoring, testing, or documentation; results aggregate on completion.

**Limits:** max 50 concurrent background agents; agents inherit session permissions; background agents can't spawn other background agents.

### Hooks

Scripts/prompts that intercept and customize behavior at lifecycle points: before/after tool use, on user input, on session events.

**Events (and whether they can block):** `PreToolUse` (Yes), `PostToolUse` (No), `PermissionRequest` (Yes), `UserPromptSubmit` (No), `SessionStart` (No), `SessionEnd` (No), `PreCompact` (No), `Stop` (No), `SubagentStop` (No), `Notification` (No), `Setup` (No).

**Config locations (highest → lowest):** Local (`.claude/settings.local.json` or `.cortex/settings.local.json`) · Project (`.claude/settings.json` or `.cortex/settings.json`) · User (`~/.claude/settings.json`) · Global (`~/.snowflake/cortex/hooks.json`).

```json
{ "hooks": { "PreToolUse": [ { "matcher": "Bash",
  "hooks": [ { "type": "command", "command": "bash .claude/hooks/validate-bash.sh", "timeout": 60 } ] } ] } }
```

**Hook types:** command (`{"type":"command","command":"bash /path/to/script.sh","timeout":60,"enabled":true}`) and prompt (`{"type":"prompt","prompt":"Is this command safe? $ARGUMENTS","timeout":30}`).

**Matchers:** `*` (all), `Bash`, `Edit|Write`, `mcp__.*` (all MCP tools), `Notebook.*` (NotebookEdit, NotebookExecute); regex supported.

**Hook I/O:** JSON over stdin/stdout. Sample input includes `session_id`, `transcript_path`, `cwd`, `permission_mode`, `hook_event_name`, `tool_name`, `tool_input`. Output can `allow`/`deny`, add `systemMessage`, or pass `updatedInput`. Return code 0 = don't block, 2 = block (or `{"decision":"block","reason":"…"}`).

**Hook env vars:** `CORTEX_PROJECT_DIR`, `CORTEX_CODE_REMOTE` (`"true"` if web context), `CORTEX_ENV_FILE`.

**Remote hooks:** reference git scripts via `{"type":"command","command":"bash","source":{"source":"github:org/hooks-repo/scripts/validate.sh","ref":"main"}}`.

**Best practices:** keep hooks fast (60s default timeout); exit 0 if uncertain; log to files; target specific tools with matchers; test with the hooks manager.

### MCP (in the extensibility page)

Connect to external tools/data via MCP. Three transports: `stdio` (local tools/CLI wrappers; subprocess over stdin/stdout), `http` (web services/APIs), `sse` (real-time, Server-Sent Events). OAuth supported for HTTP servers (token stored in `~/.snowflake/cortex/mcp_oauth/`, auto-refreshed). Tool namespacing: `mcp__{server-name}__{tool-name}`. *(Full details in §13.)*

---

## 12. Bundled skills catalog

The CLI ships built-in skills available in every session — no setup required. Describe what you want and Cortex Code loads the right skill, or invoke by name via `/skill`. Categories below.

**Getting started**
- `cortex-code-guide` — complete CLI reference: commands, sessions, MCP integration, shortcuts, configuration.

**Development & applications**
- `developing-with-streamlit` — create/edit/debug/style Streamlit in Snowflake apps (CSS theming, custom & packaged components).
- `snowflake-notebooks` — create/edit Workspace notebooks (.ipynb): Snowpark Python & SQL cells, analysis, debugging.
- `snowflake-apps` — scaffold/build/test/deploy Snowflake App Runtime (Next.js) apps; local preview and `snow app deploy`.

**Warehouse & compute**
- `warehouse` — manage warehouses: Gen2 conversion, credit rates, cost analysis, sizing, performance.
- `workload-performance-analysis` — analyze query performance via ACCOUNT_USAGE: spilling, pruning, cache hits, clustering keys, SOS/QAS eligibility.
- `deploy-to-spcs` — deploy containerized apps to Snowpark Container Services: push images, create services, networking/access.

**Data engineering & pipelines**
- `openflow` — NiFi-based data integration: deploy/configure connectors, diagnose flows, build ingestion pipelines.
- `dynamic-tables` — create incremental pipelines, optimize target lag, monitor refresh health, troubleshoot.
- `dbt-projects-on-snowflake` — manage dbt projects as native Snowflake objects via `snow dbt` (deploy/execute/schedule/document).
- `dcm` — Database Change Management: create/audit/debug DCM projects (infra-as-code schema & role mgmt).
- `iceberg` — Apache Iceberg tables: catalog integrations (Glue, Unity, Polaris), external volumes, auto-refresh, writes.
- `snowflake-postgres` — manage Snowflake Postgres instances: create/suspend/resume, reset creds, network policies, health checks.
- `integrations` — create/manage all integration types (API, catalog, external access, notification, security, storage).

**Analytics & dashboards**
- `semantic-view` — build/manage semantic views for Cortex Analyst: VQR suggestions, verified queries, metrics, dimensions, filters.
- `dashboard` — create/modify interactive dashboards: charts, KPI widgets, tables, markdown.
- `search-optimization` — create/configure Cortex Search Services from documents on a stage.
- `ai-readiness-score` — score account AI readiness (CR table coverage, semantic view coverage/quality, demand coverage) with an HTML report.

**Snowpark development**
- `snowpark-python` — deploy Snowpark Python: UDFs, UDAFs, UDTFs, stored procedures via `snow snowpark`.
- `snowpark-connect` — migrate/validate PySpark to run natively on Snowflake via Snowpark Connect.

**AI & machine learning**
- `cortex-agent` — create/manage/edit/debug/delete/chat with Cortex Agents (incl. multi-tool: Search + Analyst).
- `cortex-ai-functions` — text/document processing (classification, entity extraction, sentiment, translation, embedding, OCR, parsing).
- `machine-learning` — end-to-end ML: training, Model Registry, feature engineering, forecasting, anomaly detection, GPU jobs.

**Data quality & observability**
- `data-quality` — monitor with Data Metric Functions: table comparisons, popularity tracking, SLA alerting, dashboards.
- `lineage` — downstream impact, upstream tracing, column-level lineage, root-cause debugging.
- `error-tables-ops` — assess/enable/monitor/manage Error Tables (DML error logging), storage, cleanup.

**Data governance & security**
- `data-governance` — dynamic masking, row access policies, automated PII classification, GDPR/CCPA tagging, access auditing.
- `network-security` — recommend/evaluate/migrate network policies (SaaS-managed rules, hybrid, access-history-based).
- `trust-center` — review findings, manage scanners, CIS benchmarks, Threat Intelligence, remediations.
- `key-and-secret-management` — Tri-Secret Secure, CMK/BYOK, key rotation, periodic data rekeying.

**Data sharing & marketplace**
- `data-sharing` — secure data sharing & listings from tables/views or external storage (S3/Azure/GCS, open table formats).
- `data-cleanrooms` — set up collaborations, audience overlap analysis, activate matched segments without exposing PII.
- `declarative-sharing` — declaratively share data products via application packages with versioning (Internal Marketplace, cross-account).
- `native-app-consumer` — install/configure Native Apps as a consumer: grant privileges, approve specs, configure references.
- `native-app-provider` — build Native Apps: packages, manifests, setup scripts, versioning, release channels, publish.

**Platform & cost management**
- `cost-intelligence` — analyze costs end-to-end: credits, budgets, warehouse/serverless costs, anomalies, breakdowns by team.
- `organization-management` — manage an org: accounts, org users, spending analysis, security posture, MFA readiness, ORGANIZATION_USAGE.

**Migration & assessment**
- `snowconvert-assessment` — analyze SQL Server (and other) → Snowflake migrations via SnowConvert reports: waves, exclusions, dynamic SQL.

**Skill development**
- `skill-development` — create/document/audit skills: define triggers, multi-step workflows, sub-skills, test behavior.

**Airflow plugin skills** *(separate install; active only when the plugin is enabled).* Domains and skills:
- *Environment setup:* `setting-up-astro-project`, `managing-astro-local-env`, `init` (schema discovery → `.astro/warehouse.md`).
- *DAG authoring & testing:* `airflow` (manage deployments), `authoring-dags`, `testing-dags`, `debugging-dags`, `migrating-airflow-2-to-3`.
- *Data operations:* `cosmos-dbt-core`, `cosmos-dbt-fusion`, `checking-freshness`, `analyzing-data`, `profiling-tables`.
- *Lineage & observability:* `annotating-task-lineage`, `creating-openlineage-extractors`, `tracing-upstream-lineage`, `tracing-downstream-lineage`.

---

## 13. Model Context Protocol (MCP) support

Cortex Code CLI implements MCP (an open standard) to connect the agent to external tools/data (GitHub, Jira, internal APIs, databases). Add a server once and its tools become available automatically.

### Transports
- `stdio` — local tools, CLI wrappers, language-specific servers (subprocess over stdin/stdout).
- `http` — web services/hosted APIs (streamable HTTP).
- `sse` — real-time streaming (Server-Sent Events over HTTPS).

### Managing servers (`cortex mcp` / `/mcp`)

| Command | Description |
|---|---|
| `cortex mcp add <name> <commandOrUrl> [args...]` | Register a new server |
| `cortex mcp list` | List servers (masked credentials) |
| `cortex mcp get <name>` | Show config for one server (incl. OAuth fields) |
| `cortex mcp remove <name>` | Remove server + delete stored credentials |
| `cortex mcp start` | Connect all servers, report connected/failed (waits up to 300s) |

`/mcp` opens an interactive viewer: server name/transport/state (`connecting`, `connected`, `reconnecting`, `failed`, `not_started`), tool count, last error, enable/disable toggles.

**Add flags:** `-t, --transport` (alias `--type`; `stdio`/`http`/`sse`, default `stdio`), `-e, --env KEY=value` (stdio, repeatable), `-H, --header "Header: value"` (http/sse, repeatable), `--timeout <ms>`. Sensitive `-e`/`-H` values migrate into the OS keychain on first connection.

Examples:
```bash
cortex mcp add git-server uvx mcp-server-git
cortex mcp add api-server https://api.example.com --type http
cortex mcp add my-server npx my-mcp-server -e API_KEY=secret
cortex mcp add my-api https://api.example.com -H "Authorization: Bearer token"
```

### Configuration file (`~/.snowflake/cortex/mcp.json`)

Top-level key `mcpServers`, keyed by server name:
```json
{ "mcpServers": { "server-name": { "type": "stdio", "command": "command-to-run", "args": ["arg1","arg2"] } } }
```

**Server fields:** `type` (required), `command`, `args`, `cwd`, `url`, `env`, `headers`, `timeout` (default 60,000 ms; global override `COCO_MCP_TOOL_TIMEOUT_MS`), `oauth`.

**Env var expansion:** `${VAR}` (literal preserved if unset), `${VAR:-default}`, `$VAR`. Never hardcode secrets; export from shell profile.

**Configuration precedence (later wins on name collision, except plugins):** (1) Administrator-enforced servers; (2) Connection-profile servers; (3) User servers (only if admin allows user MCP); (4) Plugin servers (skipped when user MCP disabled; never overwrite higher-level servers); (5) Administrator URL allowlist removes disallowed `url`s after merge.

### Tool names & permissions
Namespaced as `mcp__<server-name>__<tool-name>` (e.g., `mcp__github__search`). Names ≤ 64 chars, alphanumeric/underscore/hyphen only. Configure default decisions in `permissions.json`:
```json
{ "allow": ["mcp__github__read_file","mcp__github__list_repos"], "deny": ["mcp__github__delete_repo"], "ask": ["mcp__*"] }
```

### Credential storage
On first connection, `env`/`headers`/OAuth secrets migrate from `mcp.json` to the OS keychain (entry `mcp_oauth_<server-name>`). `list`/`get` show key names but never secrets. `remove` deletes config + keychain entry. If no keychain (headless container), storage degrades gracefully — no secrets written to disk.

### OAuth (HTTP servers)
```json
{ "mcpServers": { "my-api": { "type": "http", "url": "https://api.example.com/mcp",
  "oauth": { "client_id": "pre-registered-client-id", "client_name": "Cortex Code",
             "redirect_port": 8585, "scope": "openid mcp read write",
             "authorization_server_url": "https://auth.example.com" } } } }
```
First connection opens the system browser; tokens stored in the keychain and refreshed automatically. Omit `client_id` to attempt Dynamic Client Registration. Reset: `cortex mcp remove <server>` then re-add and `cortex mcp start`.

### Disabling servers
From `/mcp`, toggle off; persisted in `~/.snowflake/cortex/mcp-disabled.json`. Disabled servers aren't connected, expose no tools, and aren't auto-reconnected.

### Using MCP tools
Available automatically; invoke via natural language ("Show me recent GitHub pull requests", "Create a Jira ticket for this bug"). Tool results capped at 50 KB (truncated with a notice beyond that).

### Administrator controls
- **Disable user MCP servers** (`areUserMcpServersAllowed: false`) — ignores `~/.snowflake/cortex/mcp.json` and plugin MCP servers; only admin/profile servers load.
- **URL allowlist** — disallowed-URL servers silently removed after merge.
- **Enforced servers** — admin ships a base `mcp.json` users can't remove/modify.

### Troubleshooting
- *Not connecting:* `/mcp` status, `cortex mcp start`, check `~/.snowflake/cortex/logs/`, confirm env vars.
- *Tools missing:* `cortex mcp list`; valid names (alnum/underscore/hyphen, < 64 chars); not in `mcp-disabled.json`.
- *OAuth:* clear creds (`cortex mcp remove` + re-add); confirm `redirect_port` (default 8585) free; use Dynamic Client Registration.
- *Env vars not expanding:* prefer `${VAR}`; verify exported; remember expansion uses the launching process environment.
- *Output truncated:* 50 KB cap — have the server return a summary/reference/file pointer.

### Best practices
Descriptive server names; secure credentials (env/OAuth); appropriate timeouts (60s default); test with `cortex mcp start`; scope permissions narrowly.

### MCP **Server mode** — run Cortex Code *as* an MCP server

Cortex Code can also act as an MCP server so MCP clients (Cursor, Claude Desktop, other agents) can delegate to it. Start with:
```bash
cortex mcp serve [options]
```
Communicates over stdio (JSON-RPC); alive until stdin closes or SIGINT/SIGTERM.

**Options:** `-c, --connection <name>`; `--bypass` (recommended — client manages its own confirmations); `-m, --model <model>`; `-w, --workdir <path>`.

**Configure a client** (example for Cursor `.cursor/mcp.json` / Claude Desktop `claude_desktop_config.json`):
```json
{ "mcpServers": { "cortex-code": { "command": "cortex", "args": ["mcp","serve","-c","my_connection","--bypass"] } } }
```

**Exposed resources:** `cortex://status` (connection/workdir/model/bypass), `cortex://tools` (internal tools list).

**Exposed tools:** `cortex_code_agent` (primary — full agent loop; params: `prompt`, `workdir`, `model`, `connection`, `profile`, `allowed_tools`, `disallowed_tools`, `bypass`), `cortex_search_docs`, `cortex_search_objects`, `cortex_analyst_query`, `cortex_agents_list`, `cortex_agents_describe`, `cortex_agents_search`.

**`cortex_code_agent` behavior:** stateless per call — history cleared, per-call overrides applied, full agent loop runs autonomously, returns final text + `activity_summary` (tools used, files changed, SQL run). Supports MCP progress notifications and cancellation.

**Limitations:** stateless (no memory between calls); stdio only (no network transports yet); single Snowflake connection per server lifetime (restart to switch).

---

## 14. Agent Client Protocol (ACP) support

Cortex Code CLI implements ACP (open standard) so editors/IDEs embed it as a local subprocess: the editor drives the session; Cortex Code streams responses, tool calls, and file diffs over stdin/stdout (newline-delimited JSON).

### Supported ACP clients
Zed, JetBrains IDEs, Visual Studio Code, Neovim, Goose, SnowWork. (Refer to each editor's docs for external-agent setup.)

### Prerequisites
- CLI installed and on `PATH` (`cortex --version`).
- At least one Snowflake connection (`cortex auth login` or `connections.toml`).
- Client supports external agents over stdio (ndjson).
- ACP mode does **not** prompt for auth; it uses the connection passed via `-c` (or the `cortexAgentConnectionName` setting). Authenticate before launching the editor.

### Starting (editor runs this for you)
```bash
cortex acp serve -c <connection_name> [--bypass] [-m <model>] [-w <workdir>]
```
**Options:** `-c, --connection` (defaults to `cortexAgentConnectionName`), `--bypass` (gated by admin policy), `-m, --model`, `-w, --workdir`.

> **Important:** Cortex Code speaks ACP over stdin/stdout. Don't write to stdout from wrapper scripts, shell init files, or pre-run hooks — any extra stdout output corrupts the protocol. Log to stderr or a file.

### Configuring an ACP client
```json
{ "command": "cortex", "args": ["acp","serve","-c","my_connection","-m","claude-sonnet-4-6","-w","/Users/me/projects/my-repo"] }
```
The subprocess inherits the client's environment, so you can pass `SNOWFLAKE_ACCOUNT`, `SNOWFLAKE_USER`, etc.

### Sessions & history
Stored alongside CLI sessions: `~/.snowflake/cortex/conversations/<sessionId>.json` (full snapshot) and `<sessionId>.history.jsonl` (append-only chat log). You can `/resume` from the CLI or another ACP client. On `loadSession`, Cortex Code replays history as ACP `SessionUpdate` notifications. `/wipe-session` removes the full trace.

### Session configuration options (rendered as editor dropdowns)
| Option | Values | Description |
|---|---|---|
| `mode` | `standard`, `plan`, `bypass` | Tool-approval behavior |
| `model` | Any supported model | Underlying model (defaults to `auto`) |

`bypass` is available only if the admin allows dangerous mode (otherwise selecting it errors and keeps the prior mode).

### Editor tools (`_meta.clientTools`)
Clients can expose their own tools via `newSession`/`loadSession`. Each definition: `name` (required; avoid the reserved `mcp__` prefix), `description` (optional), `inputSchema` (optional). Registered per-session, removed on session end/connection close. Permissions follow the session mode.

### Streaming updates (`SessionUpdate`)
`agent_message_chunk` (response text), `agent_thought_chunk` (reasoning, for thinking models), `tool_call` (id/title/kind/input), `tool_call_update` (progress/complete/fail; file edits include a `diff` block), `plan` (plan steps), `user_message_chunk` (replayed on `loadSession`). File-edit tools (`edit`, `str_replace_editor`, `write`) emit diff updates for inline rendering.

### Canceling
A `cancel` notification aborts running tool calls, stops streaming, returns a `cancelled` stop reason; the session stays open for the next prompt.

### Limitations
`listSessions` is exposed as `unstable_listSessions` (may change); slash commands aren't first-class in ACP (type them in a prompt, e.g. `/skill list`); no separate auth flow.

### Troubleshooting
- *Agent exits immediately:* run `cortex acp serve -c <conn>` in a terminal; fix any auth/connection error (Cortex Code exits before speaking ACP if it can't connect).
- *Hangs / garbled output:* ensure no shell startup file or wrapper writes to stdout; redirect diagnostics to stderr/file.
- *No tool approvals:* check `mode` — `bypass` auto-approves; switch to `standard`/`plan`.
- *Empty model dropdown:* invalid connection or no models enabled — verify `cortex auth status`.

---

## 15. Plugins

A plugin is a self-contained package bundling skills, subagents, slash commands, hooks, and MCP servers under one manifest. Share via Git, install from the official marketplace, or develop locally in a project.

### What a plugin contributes
Skills · Subagents · Slash commands · Hooks · MCP servers. Inactive plugins contribute nothing; an `activation.md` file generates a stub skill so users can discover/re-enable the plugin from a session.

### Layout
```text
my-plugin/
├── .cortex-plugin/        # or .claude-plugin/
│   ├── plugin.json        # manifest (required)
│   └── activation.md      # optional
├── skills/my-skill/SKILL.md
├── commands/my-command.md
├── agents/my-agent.md
├── hooks/hooks.json       # optional; can be inline in plugin.json
└── .mcp.json              # optional; can be inline in plugin.json
```
Manifest accepted at `.cortex-plugin/plugin.json` or `.claude-plugin/plugin.json` (`.cortex-plugin` wins if both). Omitted `commands`/`skills`/`agents`/`hooks`/`mcpServers` fields auto-discover the standard subdirectories/files.

### Manifest fields
`name` (required, lowercase kebab-case), `description`, `version` (semver), `author` (`{name,url}`), `commands` (dir(s), default `./commands`), `skills` (default `./skills`), `agents` (default `./agents`), `hooks` (inline HooksConfig / path(s)), `mcpServers` (inline map / path(s); default `./.mcp.json`), `requiresSandbox` (boolean).

Sample:
```json
{ "name": "data-engineering", "description": "Skills, hooks, and MCP for Snowflake data engineering",
  "version": "1.0.0", "author": { "name": "Data Platform Team" },
  "skills": ["./skills"], "agents": ["./agents"],
  "hooks": { "PreToolUse": [ { "matcher": "Bash",
    "hooks": [ { "type": "command", "command": "bash hooks/validate-bash.sh" } ] } ] },
  "mcpServers": { "internal-api": { "type": "http", "url": "https://internal.example.com/mcp" } } }
```

### Discovery order (first source wins, dedup by `name`)
1. CLI argument (`--plugin-dir`).
2. Connection profile.
3. User settings (`plugins` array in `~/.snowflake/cortex/settings.json`).
4. Managed registry (`~/.snowflake/cortex/plugins/`, tracked in `registry.json` — where `cortex plugin install` puts them).
5. Project plugins (`.cortex/plugins/`, `.claude/plugins/`).
6. Bundled plugins (active by default; some feature-flag-gated).
7. Bundled external plugins (synced from the skills repo, inactive by default; enable with `cortex plugin enable <name>`).

Running sessions don't auto-pick-up CLI changes — run `/plugin reload` or restart. Origin shows in `cortex plugin list` and `/plugin info <name>`.

### Managing plugins

| Command | Description |
|---|---|
| `cortex plugin install <source>` | Install (marketplace, `owner/repo`, or Git URL); `--inactive` to leave disabled. Alias `add` |
| `cortex plugin uninstall <name>` | Remove (aliases `remove`, `delete`, `rm`) |
| `cortex plugin enable <name>` | Enable (alias `activate`) |
| `cortex plugin disable <name>` | Disable without uninstalling (alias `deactivate`) |
| `cortex plugin list` | List all discovered plugins (origin, components, active state) |
| `cortex plugin validate [target]` | Validate manifest/components (name or dir; defaults to cwd) |
| `cortex plugin update [name]` | Pull latest from registered source (omit name = all) |

Interactive `/plugin` (alias `/plugins`): `list`, `info <name>`, `install [--inactive] <source>`, `uninstall <name>`, `enable <name>`, `disable <name>`, `update [name]`, `validate`, `reload`.

### Install sources
- Marketplace name: `cortex plugin install python-repl`.
- GitHub shorthand: `cortex plugin install owner/repo` or `github:owner/repo@branch`.
- Git URL: `cortex plugin install https://github.com/owner/repo.git` (also `git@`, `ssh://`, `file://`).

Cloned into the managed plugins dir, manifest validated, registered in `~/.snowflake/cortex/plugins/registry.json` (records source, install/update timestamps, active state, `lastUpdateError`). Registry is locked during writes.

### Composition with the runtime
On session start (or `/plugin reload`): skills join the registry (tagged by origin); subagents join the search path; slash commands register; hooks merge with fixed source priority (global < user < project < local project < plugin < connection profile, highest wins); MCP servers join the connection manager (lower priority than user/profile; skipped when admin disables user MCP). If any active plugin sets `requiresSandbox: true`, the sandbox runtime starts when available.

### Authoring
1. `mkdir -p my-plugin/.cortex-plugin`
2. Create `plugin.json` (at minimum `name` + `description`).
3. Add components in standard dirs (auto-discovered).
4. `cortex plugin validate ./my-plugin`.
5. Use locally with `cortex --plugin-dir ./my-plugin` (or drop into `.cortex/plugins/`).
6. Share via a Git repo; others install with `cortex plugin install your-org/your-plugin-repo`.

### Administrator controls
Ship plugins via a Snowflake connection profile for a consistent baseline (origin `profile`). User-MCP enforcement (`areUserMcpServersAllowed: false`) also skips plugin MCP servers.

### Best practices
Pin a `version`; validate before shipping; keep MCP credentials out of the manifest (env/OAuth); prefer convention over configuration (default dirs); provide an `activation.md`.

---

## 16. Cortex Code Desktop (CoCo)

> **Provenance note.** This section is compiled from the *Cortex Code Desktop — Comprehensive Reference Guide* (v1.0, dated May 31, 2026) supplied by the user, **not** from docs.snowflake.com. At time of writing, Snowflake has not published a public documentation topic for Desktop; it is a Limited Access / Private Preview product. The only Desktop reference on the public site is the billing parameter `CORTEX_CODE_DESKTOP_DAILY_EST_CREDIT_LIMIT_PER_USER` (see §19). Treat command names, settings keys, and defaults below as point-in-time and verify against the in-app `/help` and `/docs` on your installed build. Where Desktop mirrors CLI behavior, cross-references point to the relevant public-docs sections elsewhere in this document.

### 16.1 Overview

Cortex Code Desktop (internally "CoCo") is Snowflake's agentic, AI-powered IDE for data engineering, analytics, and software development. It pairs a conversational agent (advanced models with deep Snowflake integration) with a full development environment: file editing, terminal access, version control, Jupyter notebooks, and browser automation. Capabilities span writing/executing/debugging SQL against Snowflake; exploring and modifying codebases with AI assistance; building data pipelines, ETL, and dbt projects; creating and managing Semantic Views and Cortex Agents; orchestrating multi-agent workflows; scheduling recurring automation; and searching Snowflake documentation and the marketplace.

Functionally it is the CLI's agent and toolset wrapped in a graphical IDE, with several Desktop-only additions (interactive table viewer, inline charts, Jupyter integration, browser automation, team/swarm mission control, and graphical managers for connections, skills, plugins, MCP, and hooks).

### 16.2 Installation & setup

**Download** (Limited Access / Private Preview) from the Snowflake download portal:
- macOS — Apple Silicon (`Cortex-Code-darwin-arm64.dmg`) or Intel (`Cortex-Code-darwin-x64.dmg`).
- Windows — Intel/AMD (`Cortex-Code-win32-x64-user-setup.exe`) or ARM (`Cortex-Code-win32-arm64-user-setup.exe`).
- Builds are served from `sfc-repo.snowflakecomputing.com/coco-desktop/`. (The guide also lists Linux/Ubuntu 20.04+ as supported.)

**System requirements (per the guide):** Windows 10+, macOS 12+, or Linux (Ubuntu 20.04+); an active Snowflake account with appropriate permissions; internet connectivity to Snowflake services.

**Initial setup:** install and launch → configure your first connection via `/connections` → verify with `/doctor` → start working by typing natural-language requests or SQL.

**Configuration directories**

| Platform | Path |
|---|---|
| Windows | `C:\Users\<username>\.snowflake\cortex\` |
| macOS / Linux | `~/.snowflake/cortex/` |

Key files/directories:
```text
~/.snowflake/cortex/
├── CLAUDE.md              # Global instruction file (always loaded)
├── skills/                # Custom skills
├── plugins/               # Custom plugins
├── mcp.json               # MCP server configuration
├── memories/              # Persistent memory storage
└── playground/workspace/  # Default working directory
```
*(Note: Desktop uses `CLAUDE.md` as the global instruction file and `memories/` for persistent memory — naming differs from the CLI's `AGENTS.md` and `memory/`.)*

### 16.3 Connections & authentication

- `/connections` (`/conn`) opens a fullscreen connection manager: add/edit/switch connections and set default warehouse, database, schema, and role.
- `/doctor` (`/diag`) diagnoses connectivity: network reachability, authentication validity, role/warehouse accessibility, and permission levels.
- **Switch at runtime:** say "switch to connection X" or run the command; CoCo asks whether to switch for the current session only or persist to config.
- **Connection settings:** `cortexAgentConnectionName` (connection used for AI/LLM inference) and `sqlConnectionName` (default SQL connection; falls back to the active connection if unset).

### 16.4 Interface & navigation

**View modes** — cycle with `Ctrl+O`: `compact` (condensed, default), `expanded` (full detail), `transcript` (full conversation).

**Session management**

| Action | Command |
|---|---|
| New session | `/new` or `/new <name>` |
| Resume | `/resume` or `/r` |
| Fork | `/fork` or `/fork <session-id>` |
| Rename | `/rename` or `/name` |
| Clear screen | `/clear` or `/cls` |
| Compact context | `/compact [instructions]` |
| Rewind messages | `/rewind` |
| Quick side question | `/qq` or `/quick` |
| Exit | `/quit` or `/q` |

**Context management:** `/context` (view context-window breakdown), `/compact` (clear history but keep a summary to reduce tokens), `/rewind` (undo recent exchanges).

### 16.5 Special input syntax

These trigger characters activate special input modes — a Desktop differentiator versus the CLI's `@`-only references:

| Trigger | Name | Behavior | Example |
|---|---|---|---|
| `/` | Slash command | Invoke a command | `/sql SELECT 1` |
| `!` | Bash terminal | Run a shell command | `!git status` |
| `@` | File reference | Reference a file by path | `@src/main.py` |
| `@{` | File injection | Inject file contents inline | `@{config.yaml}` |
| `#` | Table trigger | Reference a Snowflake table (auto-discovers schema) | `#MY_DB.SCHEMA.TABLE` |
| `$` | Skill trigger | Invoke a skill | `$semantic-view` |
| `%` | Agent trigger | Mention a Cortex Agent | `%my_agent` |

### 16.6 Slash commands reference

**SQL & data:** `/sql` (`--limit N` for more rows), `/sql-readonly` (toggle read-only vs write), `/table` (`/csv`, interactive table viewer), `/copy-table` (`/cpt`), `/connections` (`/conn`), `/doctor` (`/diag`), `/workspace` (browse/switch mounted Snowflake workspace).

**Agent & execution modes:** `/plan`, `/plan-off`, `/auto-accept-plan`, `/auto-accept-plan-off`, `/bypass`, `/bypass-off`, `/team`, `/team-off`, `/swarm` (`/mission-control`), `/background-agent` (`/bg`), `/agents`, `/sh`.

**Skills, rules & plugins:** `/skill` (`/skills`), `/rules`, `/plugin` (`/plugins`), `/reload-plugins`, `/hooks`, `/curator` (skill lifecycle), `/mcp`.

**dbt:** `/fdbt` (fast dbt analysis), `/lineage` (fullscreen DAG).

**Scheduling:** `/loop` (`/cron`), `/automation` (`/automations`).

**Utilities:** `/help` (`/h`, `/?`), `/docs`, `/feedback`, `/update`, `/copy` (`/cp`; `--md`, `--text`), `/diff` (`/changes`, `/review`; `--staged`), `/share` (Snowsight link), `/add-dir`, `/clear-cache`, `/worktree`, `/secrets` (`/secret`), `/tgrep`, `/index` (`--rebuild`), `/setup-jupyter`, `/ssh` (`/remote`), `/settings` (`/preferences`, `/prefs`), `/model`, `/theme` (`/themes`), `/status`, `/profile`, `/permissions`.

### 16.7 Keyboard shortcuts

**Global:** `Ctrl+P` (toggle Plan mode), `Ctrl+G` (toggle Team mode), `Ctrl+C` (interrupt/cancel), `Ctrl+Z` (suspend), `Ctrl+O` (cycle view mode), `Ctrl+S` (subagent picker), `Shift+Tab` (cycle permission level), `Escape` (dismiss overlays), `Alt+T` (fullscreen task viewer).

**Text input & editing:** `Ctrl+J` (newline), `Ctrl+A`/`Ctrl+E` (line start/end), `Ctrl+B`/`Ctrl+F` (cursor left/right), `Alt+B`/`Alt+F` (word left/right), `Home`/`End`, `Up`/`Down` (history), `Ctrl+W` (delete word left), `Ctrl+K` (delete to end of line), `Alt+D` / `Ctrl+Del` (delete word right).

### 16.8 Tools reference

CoCo uses specialized internal tools; knowing them helps you phrase requests.

- **File & code:** `read` (text, images, PDFs, notebooks, Excel, PowerPoint), `write`, `edit` (search-and-replace), `glob`, `grep`, `tgrep` (AI-powered semantic code search).
- **Shell & execution:** `bash`, `bash_output` (retrieve output from background shells).
- **Snowflake & data:** `sql_execute`, `snowflake_object_search`, `snowflake_table_lookup`, `snowflake_product_docs`, `semantic_view_search`, `cortex_agent_search`, `reflect_semantic_model` (validate semantic model YAML), `data_diff` (compare two tables).
- **Agent & orchestration:** `task` (launch subagents), `team_create`, `enter_plan_mode`, `programmatic_tool_calling` (batch/loop tool calls).
- **Web & memory:** `web_search`, `web_fetch`, `memory` (cross-session storage).

### 16.9 SQL execution & data exploration

- **Direct:** `/sql SELECT * FROM my_table LIMIT 10`. **Natural language:** "Show me the top 10 customers by revenue last quarter." **Read-only:** `/sql-readonly` toggles write protection.
- **Timeout:** `sqlDefaultTimeoutSeconds` (default 180); ask CoCo to set a longer per-query timeout.
- **Table exploration:** reference tables with `#TABLE_NAME` (CoCo auto-discovers schema/columns and searches for matching tables); results show in an interactive table (`/table` to reopen, `/copy-table` to copy).
- **Inline visualizations:** line, bar, stacked bar, area, scatter, and pie charts, plus metric/KPI cards.

### 16.10 Semantic Views & Cortex Analyst

Semantic Views define business-level models (curated metrics, dimensions, relationships) over Snowflake tables, enabling natural-language querying via Cortex Analyst. Discover with `$semantic-view` or by asking ("Are there any semantic views for sales data?"). When a relevant view exists, CoCo grounds SQL generation against it and labels output `[Grounded: VIEW_NAME]`. The `$semantic-view` skill creates views from tables; imports from Tableau (`.twb`/`.twbx`) or Power BI (`.pbit`/`.pbix`); adds verified queries (VQRs); debugs/optimizes; and suggests metrics/filters. Validate with `reflect_semantic_model @path/to/model.yaml` before deploying.

### 16.11 Cortex Agents

Discover with `%agent_name` or by asking. **Agent mention modes** (set via `agentMentionMode`): `cortex_code` (injects the agent spec into CoCo's prompt) or `snowflake_intelligence` (calls the Agent API directly, supporting MCP). The `$cortex-agent` skill handles the full lifecycle: create, edit, version, deploy, chat, debug, and manage versions/aliases.

### 16.12 Skills system

Modular instruction packages that extend CoCo for specific domains. Invoke via `$skill-name`, the `/skill` command (browse/manage; `/skill catalog` to browse the catalog), or natural language. **Locations:** Bundled (ship with CoCo), User (`~/.snowflake/cortex/skills/`), Project (`.cortex/skills/`), Catalog (remote, installable on demand).

Key bundled skills (per the guide): `semantic-view`, `cortex-agent`, `machine-learning`, `dynamic-tables`, `data-governance`, `sql-author`, `cost-intelligence`, `snowpark-python`, `migration-guide`, `build-app`, `data-quality`, `iceberg`. Create custom skills with `$skill-development` (stored as `SKILL.md` files). *(See §11–§12 for the broader, CLI-documented skills model and full bundled catalog.)*

### 16.13 Subagents & task orchestration

Subagent types: `general-purpose` (full tool access; complex research/implementation), `Explore` (fast codebase exploration), `Plan` (read-only architecture planning), `dbt-verify` (validate dbt changes), `sql-verify` (catch silent SQL errors), `feedback` (post-task review), `curator` (skill-quality maintenance). Launch inline/blocking ("Use an explore agent to find all API endpoints") or background/non-blocking (`/bg Analyze the codebase structure…`). Define custom agents as `.md` files in `~/.snowflake/cortex/agents/` or `.cortex/agents/`.

### 16.14 Plan mode & team mode

- **Plan mode** forces research-and-present before changes. Enable `/plan` or `Ctrl+P`; disable `/plan-off`; auto-accept `/auto-accept-plan`. Use for complex multi-file changes, architectural decisions, risky/irreversible operations.
- **Team mode** enables parallel multi-agent execution. Enable `/team` or `Ctrl+G`; disable `/team-off`. Features: parallel subtask agents, git-worktree isolation, a shared task queue, and `/swarm` mission control for monitoring.

### 16.15 Memory & persistent state

Enable with `enableMemory=true` (setting) or `CORTEX_ENABLE_MEMORY=1`. Memory persists in `/memories/` across sessions ("Remember that our production database is PROD_DB" / "What do you remember about our project?"). Memory operations: `view`, `create`, `str_replace`, `insert`, `delete`, `rename`.

### 16.16 MCP (Model Context Protocol)

Config at `~/.snowflake/cortex/mcp.json`. Transports: `http`, `sse`, `stdio`. Manage with `/mcp` (in-session) or `cortex mcp add | list | remove | start`. MCP tools appear as `mcp__<server>__<tool>`. Set `mcpWait=true` to require servers to connect before task execution. *(See §13 for the full, CLI-documented MCP schema, OAuth, credential storage, and server mode.)*

### 16.17 Hooks & automation

Shell commands triggered by lifecycle events: `PreToolUse`, `PostToolUse`, `PermissionRequest`, `UserPromptSubmit`, `Stop`, `SubagentStop`, `Notification`, `SessionStart`, `SessionEnd`, `PreCompact`, `Setup`. View/test with `/hooks`. *(Hook I/O and matchers mirror the CLI model in §11.)*

### 16.18 Scheduling & cron

Create with `/loop` using natural language ("`/loop every day at 9am: Check for stale dynamic tables`") or 5-field cron ("`/loop 0 9 * * *: Run morning data check`"). Tools: `cron_create`, `cron_list`, `cron_delete`. Constraints: max 50 tasks per session; tasks auto-expire after 3 days; local timezone; standard 5-field cron. Disable globally with `disableCron=true` or `COCO_DISABLE_CRON=1`.

### 16.19 Jupyter notebooks

Set up with `/setup-jupyter`. Full notebook support via `notebook_actions`: `setup`, `execute_cell`, `insert_cell`, `edit_cell`, `delete_cell`, `read_cell`, `read_notebook`, `execute_all`, `restart_kernel`. Kernel state persists across cell executions; `notebook_execute` supports papermill-style batch runs; cell timeout via `jupyterExecuteTimeoutMs` (default 600000 ms).

### 16.20 dbt integration

**Fast dbt (fdbt)** — use first; the guide cites it as 10–50× faster than Python dbt commands: `/fdbt info`, `/fdbt list`, `/fdbt lineage <model>`, `/fdbt impact <model>`, `/fdbt tests coverage`, `/fdbt compile <model>`. Command categories: Models (`list`, `lineage`, `impact`, `compile`), Tests (`coverage`, `list`, `missing`, `dependencies`, `stats`), Sources (`list`, `usage`, `locate`), Columns (`trace`, `impact`), Schema (`check`, `locate`), Macros (`list`, `usage`, `locate`). Run `dbt-verify` after changes ("Verify my dbt changes"); visualize with `/lineage` (fullscreen DAG).

### 16.21 Browser automation

Settings: `browserHeadless` (default `false`) and `browserProfilePath` (custom profile dir). Use cases: navigating pages, filling forms, taking screenshots, extracting content, debugging web apps, inspecting network/console output. Force headless with `CORTEX_BROWSER_HEADLESS=1`.

### 16.22 Secrets management

Store via `/secrets` or `cortex secret store <key> --from-file <path>`. Secrets are injected into command environments via the `secret_env` parameter on bash commands (e.g., `{"PGPASSWORD": "pg_password"}`) and never appear in session transcripts; they are scoped to specific tool calls.

### 16.23 Instruction files & customization

Hierarchy: Global `~/.snowflake/cortex/CLAUDE.md` (all sessions) → Project `CLAUDE.md` (project root) → Directory `.cortex/CLAUDE.md` (directory-specific) → custom patterns via `enabledInstructionPatterns`. Manage with `/rules` (view/edit/create). Use `/profile` to manage reusable profiles (different system prompts + settings configurations).

### 16.24 Settings reference

**Connections:** `cortexAgentConnectionName` (AI/LLM inference), `sqlConnectionName` (default SQL).

**Agent behavior:** `agentMode` (`standard`/`code`, default `standard`), `agentMentionMode` (default `cortex_code`), `autoAcceptPlans` (default `false`), `cortexAgentEagerMode` (default `false`; proactively search for agents), `cortexAgentIndexService` (agent index Cortex Search service FQN).

**Display & UI:** `diffDisplayMode` (`unified`/`side_by_side`, default `unified`), `defaultViewMode` (default `compact`), `transcriptTruncationLimit` (default 50), `alwaysShowContextUsage` (default `false`), `showModelInFooter` (default `false`), `titleLocation` (default `inputBar`), `funThinkingWords` (default `penguins`).

**Timeouts & performance:** `bashDefaultTimeoutMs` (180000), `bashMaxTimeoutMs` (cap), `jupyterExecuteTimeoutMs` (600000), `sqlDefaultTimeoutSeconds` (180).

**Cache & cleanup:** `tableCache.maxCacheSizeBytes` (1 GB), `tableCache.ttlDays` (7), `tableCache.inlineMaxBytes` (50000), `sessionCleanup.enabled`, `sessionCleanup.maxAgeDays`.

**Features:** `enableMemory` (false), `disableCron` (false), `tgrepEnabled` (true), `mcpWait` (false).

**Platform:** `windowsShell` (`powershell`/`cmd`/`bash`, default `powershell`), `autoUpdate` (true), `enableDesktopNotifications` (false).

**Permission modes:** `confirm_actions` (prompts before tool calls, default) and `bypass_safeguards` (auto-approves all). Cycle with `Shift+Tab`; toggle plan mode with `Ctrl+P`. *(Note: Desktop exposes a two-mode permission model per the guide, versus the CLI's three-tier Confirm/Plan/Bypass in §9.)*

**Environment variables:** `CORTEX_ENABLE_MEMORY` (`1` to enable memory), `COCO_DISABLE_CRON` (`1` to disable scheduling), `CORTEX_BROWSER_HEADLESS` (`1` for headless browser), `SNOWFLAKE_DEFAULT_CONNECTION_NAME` (override default connection), `ENABLE_CORTEX_WEBSEARCH` (account-level web-search flag).

### 16.25 Best practices (from the guide)

- **Prompting:** be specific; reference objects directly (`#TABLE`, `@file`); use `$skill` for specialized workflows; use `/plan` before multi-file/architectural changes; ground queries in semantic views for more reliable SQL.
- **SQL:** check for semantic views first; use `/sql-readonly` for exploration; set appropriate timeouts; validate with `sql-verify` (join fanout, NULL handling); reference tables with `#`.
- **Data engineering:** run `dbt-verify` after changes; use `fdbt` for exploration; use `$dynamic-tables`; validate with `reflect_semantic_model`; use `data_diff` after transformations.
- **Security:** never paste secrets in chat (use `/secrets`); use read-only mode on production; enable plan mode for production-modifying ops; review tool calls; enforce policy via instruction files.
- **Performance:** `/compact` when context grows; background agents (`/bg`) for long tasks; configure table cache; use `tgrep` over brute-force grep; set `bashMaxTimeoutMs`.
- **Collaboration:** `/share` for Snowsight links; `CLAUDE.md` for team standards; `/profile` per project; enable memory to persist decisions; `/loop` for recurring team tasks.

### 16.26 Troubleshooting (from the guide)

- **Connection:** can't connect → `/doctor`; wrong db/schema → check `/connections`; permission denied → verify role grants; timeout → raise `sqlDefaultTimeoutSeconds`.
- **Performance:** slow responses → `/compact`; SQL timeout → raise timeout / optimize; large file reads → use `offset`/`limit`; cache issues → `/clear-cache`.
- **Agents:** stuck → `Ctrl+C`; wrong tool → be more specific; subagent failure → `/agents`; hook blocking → `/hooks`.
- **Common errors:** "Invalid identifier" → use `#table` to auto-discover schema; "Object does not exist" → fully qualify names; "Insufficient privileges" → `$access-troubleshooter`; "Query timeout" → raise timeout or add LIMIT.
- **Getting help:** `/help`, `/docs`, `/feedback` (support bundle), `/doctor`.

### 16.27 Desktop ↔ CLI/Snowsight terminology notes

A few naming/behavior differences worth flagging when cross-referencing the public-docs sections:

| Concept | Desktop (CoCo) guide | CLI public docs |
|---|---|---|
| Global instruction file | `CLAUDE.md` | `AGENTS.md` |
| Persistent memory dir | `~/.snowflake/cortex/memories/` | `~/.snowflake/cortex/memory/` |
| Permission model | Two modes (`confirm_actions`, `bypass_safeguards`) | Three tiers (Confirm, Plan, Bypass) — see §9 |
| Default working dir | `playground/workspace/` | working directory / `-w` flag |
| Web-search env flag | `ENABLE_CORTEX_WEBSEARCH` | enabled via Snowsight admin toggle |

These reflect the supplied guide as written; reconcile against your installed build where they diverge.

---

## 17. Cortex Code Agent SDK

*Feature — Preview.* Build agentic apps in Python and TypeScript using the same tools and agent loop that power Cortex Code (read files, run commands, search codebases, execute SQL, edit code). Built-in tools mean no need to implement tool execution.

### Prerequisites
| Requirement | Details |
|---|---|
| Cortex Code CLI | `curl -LsS https://ai.snowflake.com/static/cc-scripts/install.sh \| sh` |
| Snowflake connection | Via Snowflake CLI settings (`~/.snowflake/connections.toml` or `config.toml`); pass `connection` or set `default_connection_name` |
| Node.js (TS) | ≥ 18.0.0 |
| Python | ≥ 3.10 |

### Install
```bash
npm install cortex-code-agent-sdk     # TypeScript
pip install cortex-code-agent-sdk     # Python
```
If the CLI isn't on `PATH`, set `CORTEX_CODE_CLI_PATH=/path/to/cortex` or pass `cliPath` (TS) / `cli_path` (Python).

### Minimal example
**TypeScript:**
```ts
import { query } from "cortex-code-agent-sdk";
for await (const message of query({
  prompt: "What does this codebase do? Give me a one-paragraph summary.",
  options: { cwd: process.cwd() },
})) {
  if (message.type === "assistant") {
    for (const block of message.content) {
      if (block.type === "text") process.stdout.write(block.text);
    }
  }
  if (message.type === "result") console.log("\nDone:", message.subtype);
}
```
**Python:**
```python
import asyncio
from cortex_code_agent_sdk import query, AssistantMessage, ResultMessage, CortexCodeAgentOptions

async def main():
    async for message in query(
        prompt="What does this codebase do? Give me a one-paragraph summary.",
        options=CortexCodeAgentOptions(cwd="."),
    ):
        if isinstance(message, AssistantMessage):
            for block in message.content:
                if hasattr(block, "text"):
                    print(block.text, end="")
        elif isinstance(message, ResultMessage):
            print(f"\nDone: {message.subtype}")

asyncio.run(main())
```

### Built-in tools
**Read** (read any file in the working dir), **Write** (create files), **Edit** (precise edits), **Bash** (terminal/scripts/git), **Glob** (find by pattern), **Grep** (regex content search), **SQL** (execute against Snowflake). Availability can vary by environment/runtime.

### Multi-turn sessions
Use `createCortexCodeSession` (TS) / `CortexCodeSDKClient` (Python) to retain context across exchanges. Continue the most recent conversation (`continue: true` / `continue_conversation=True`) or fork a resumed session (`resume: "id", forkSession: true` / `resume="id", fork_session=True`).

### MCP servers
```python
options = CortexCodeAgentOptions(
    mcp_servers={ "my-tools": { "command": "node", "args": ["my-mcp-server.js"] } } )
```

### Hooks
Custom code at lifecycle points (`PreToolUse`, `PostToolUse`, `Stop`, `UserPromptSubmit`, etc.), supported in both SDKs.

### Structured output
Force a JSON-Schema-conforming response via `outputFormat: { type: "json_schema", schema: {…} }`.

### Session control options
`maxTurns`/`max_turns`, `effort` (`minimal`/`low`/`medium`/`high`/`max`), `abortController`/`abort_event`, `env`, `additionalDirectories`/`add_dirs`, `plugins`, `systemPrompt`/`system_prompt`, `settingSources`/`setting_sources` (`user`/`project`/`local`).

### Supported models (SDK)
Set via the `model` option (recommend `auto`): `auto`, `claude-opus-4-6`, `claude-sonnet-4-6`, `claude-opus-4-5`, `claude-sonnet-4-5`, `claude-4-sonnet`, `openai-gpt-5.2`. Cross-region inference: `ALTER ACCOUNT SET CORTEX_ENABLED_CROSS_REGION = 'AWS_US';`.

### SDK reference pages (further reading)
Quickstart (find/fix bugs) · TypeScript SDK reference · Python SDK reference · Multi-turn sessions & streaming input · MCP servers / custom tools · System prompts · Handle approvals & user input · Structured output · Streaming output · Hooks. *(See §21 for URLs.)*

---

## 18. Workflow examples

### Data discovery, synthetic data, and dashboards

1. **Connect:** `cortex -c <your-demo-account>` (or interactively: `> connect to <my demo account>`).
2. **Explore:** `> Find all tables related to customers that I have write access to`.
3. **Check role/permissions:** `> What privileges does my role have on this database?` · `> Why am I getting a permissions error?`
4. **Generate synthetic data** (examples): fraud transactions (~0.5% fraudulent with suspicious location/amount), clinical-trial data (100 patients, dosage groups, BP over 4 weeks), telecom churn (100,000 customers with demographics, usage, churn flag, unique `customer_id`).
5. **Query:** `> Calculate the Churn Rate grouped by state and contract length…` · `> I want to identify the heaviest data users who are also churning.`
6. **Build a Streamlit dashboard:** paste an example dashboard image (Ctrl+V) as a design reference; `> Build an interactive Streamlit dashboard on this data with state filters…`; then `> Ensure that the Streamlit app will work with Snowflake and upload it… Give me a link…`.

### Building Cortex Agents (deploy to Snowflake Intelligence)

1. **Semantic View for Cortex Analyst:** `> Write a Semantic View named DEMO_TELECOM_CHURN_ANALYTICS for Cortex Analyst based on this data. Use the semantic-view optimization skill.`
2. **Cortex Search service:** generate `customer_call_logs` (50 transcripts as PDFs), use `AI_PARSE_DOCUMENT` into `TRANSCRIPT_TEXT`, chunk for search; then `> Create a Cortex Search Service named CALL_LOGS_SEARCH that indexes these transcripts… filter by CUSTOMER_ID.`
3. **Cortex Agent:** build a multi-tool agent (`cortex_analyst` for SQL metrics; `cortex_search` for sentiment/reasons) with a system prompt defining persona ("Senior Retention Specialist"), routing logic, output format (verify customer ID; recommend retention offer if risk high), and a constraint (never reveal raw `CHURN_RISK_SCORE`; map to Low/Medium/High).
4. **Deploy:** `> Let's deploy this agent to Snowflake Intelligence.` Then ask it questions like "What are customers complaining about in their calls?" or "Show me high-risk customers with monthly charges over $100".

---

## 19. Cost, billing, and credit limits

Cortex Code is billed on token consumption; pricing is in the Snowflake Service Consumption Table. Compute/storage consumed separately (warehouses, storage) is billed at standard on-demand rates.

**CLI billing models:**
- **Subscription** — individual developers who sign up at `signup.snowflake.com/cortex-code` get a 30-day free trial (fixed CLI usage). After the trial it converts to a paid subscription unless cancelled; the subscription includes a fixed monthly amount; exceeding it makes the CLI unavailable until the next billing period.
- **Pay-as-you-go** — companies with an existing Snowflake account (on-demand or capacity) are billed on token consumption.

**Snowsight billing:** token consumption for customers with an existing Snowflake account.

### Cost controls — daily estimated credit limits (per user)

Account admins can set daily estimated credit limits per user, per surface, over a rolling 24-hour window. When usage reaches the limit for a surface, access to that surface is blocked until usage drops below it; other surfaces are unaffected.

| Parameter | Controls |
|---|---|
| `CORTEX_CODE_CLI_DAILY_EST_CREDIT_LIMIT_PER_USER` | CLI usage |
| `CORTEX_CODE_DESKTOP_DAILY_EST_CREDIT_LIMIT_PER_USER` | Desktop usage |
| `CORTEX_CODE_SNOWSIGHT_DAILY_EST_CREDIT_LIMIT_PER_USER` | Snowsight usage |

| Value | Behavior |
|---|---|
| `-1` (default) | No limit (unlimited) |
| `0` | Access blocked entirely |
| Positive number | Blocked when 24-hour estimated usage exceeds this value |

Set at account level (all users) or user level (overrides account for that user). Requires `ACCOUNTADMIN` (or a role able to modify the account/user object).

```sql
-- Account-level CLI limit, then remove it
ALTER ACCOUNT SET CORTEX_CODE_CLI_DAILY_EST_CREDIT_LIMIT_PER_USER = 20;
ALTER ACCOUNT UNSET CORTEX_CODE_CLI_DAILY_EST_CREDIT_LIMIT_PER_USER;

-- User-level override, then remove it
ALTER USER jsmith SET CORTEX_CODE_CLI_DAILY_EST_CREDIT_LIMIT_PER_USER = 10;
ALTER USER jsmith UNSET CORTEX_CODE_CLI_DAILY_EST_CREDIT_LIMIT_PER_USER;
```

Org example:
```sql
ALTER ACCOUNT SET CORTEX_CODE_CLI_DAILY_EST_CREDIT_LIMIT_PER_USER = 20;
ALTER ACCOUNT SET CORTEX_CODE_DESKTOP_DAILY_EST_CREDIT_LIMIT_PER_USER = 20;
ALTER ACCOUNT SET CORTEX_CODE_SNOWSIGHT_DAILY_EST_CREDIT_LIMIT_PER_USER = 20;
ALTER USER power_user SET CORTEX_CODE_CLI_DAILY_EST_CREDIT_LIMIT_PER_USER = 50;
ALTER USER restricted_user SET CORTEX_CODE_SNOWSIGHT_DAILY_EST_CREDIT_LIMIT_PER_USER = 0;
```

A SQL stored-procedure script (`EXECUTE IMMEDIATE`) is provided in the docs to list all users with a per-user CLI override (iterates `SHOW USERS`, checks `SHOW PARAMETERS LIKE 'CORTEX_CODE_CLI_DAILY_EST_CREDIT_LIMIT_PER_USER' IN USER …`, returns a table). Swap the parameter name to audit the Snowsight/Desktop parameters.

---

## 20. Changelog

Notable changes (most recent first).

**1.0.77**
- *Added:* `/changelog` command; `/mcp` manager overhaul (split-pane, search/filter, add/edit/delete, source badges, OAuth state, invalid-tool diagnostics, correct disable semantics); SQL read-only mode (`--sql-read-only`, `/sql-writes on|off|status`); project skill discovery via `.agents/skills`; `ESC+C` clipboard shortcut; fast in-repo `/index` (FTS5 trigram); ACP session identity via `_meta.sessionId`; GPT 5.5 model support; Mac workspace acceleration (`ws create --hv=vz`, Apple Virtualization, ~1s boots); rule management (session-scoped suppression, inline edits); Agent SDK custom MCP tool definitions and hook callbacks.
- *Fixed:* `USE ROLE` no longer causes 403s on later agent API calls; large bash output preserved (30K–50K inline, >50K offloaded to a file) instead of silently truncated; plan mode disabled immediately after approval; memory search resilient to malformed embed responses; Snowflake OAuth retry no longer purges credentials; `data_diff` fixed (bundled PBS Python runtime); snowmem embed parsed as 1024-dim vectors.
- *Changed:* `tgrep` and `cron_create` now prompt for approval instead of auto-approving.

**1.0.65** — Managed plugins & marketplace installs (registry-backed install/update/enable/disable/validate/uninstall, fullscreen plugin manager); runtime plugin refresh (in-process reloads). Disabled plugins use explicit activation metadata so they stay discoverable without loading full contents.

**1.0.59** — Postgres connections & SQL workflows (Snowflake Postgres token auth, dialect-aware `/sql`); ACP editor integration (`cortex acp serve`, streaming sessions, native permission routing, clarifying-question prompts, diff previews). Hardened Postgres permission analysis and credential handling.

**1.0.28+… (2026-03-02)** — Faster guardrails; `cortex browser` + improved recovery; expanded swarm/background-agent collaboration; broader sandbox coverage; richer profiles and tool allow/deny controls.

**1.0.17+… (2026-02-19)** — Broader Windows support; improved background-agent reconnect/resume/navigation; configurable permission rules; auth/credential resilience; stronger shell safeguards.

**1.0.11+… (2026-02-12)** — Versioned skill updates and GitHub-hosted plugins; agent-to-agent messaging / multi-agent coordination; better model discovery/routing; improved resume & sandbox controls.

**1.0.10+… (2026-02-11)** — Bundled the Airflow plugin; tarball-based skill installs; faster startup and better large-output handling; more robust notebook execution; expanded agent coordination.

**1.0.9+… (2026-02-09)** — Instruction settings & visibility into loaded instruction files; more reliable `/fork` and `/rewind`; expanded custom slash command naming/collisions; live MCP config updates; rendering polish.

**1.0.7+… (2026-02-06)** — Background-agent launch flows & stronger plan handling; tabbed/fullscreen settings; session search and `/docs` shortcut; expanded `/model` options; improved semantic/dbt helpers.

**1.0.6+… (2026-02-04)** — Improved Snowflake home/config resolution & safer connection setup; `cortex secret` and better local-connection support; expanded worktree creation & remote sourcing; improved notebook permissions/reliability; better interrupt handling, screen clearing, and table rendering.

---

## 21. Legal notices

Where a configuration uses a model provided under the Model and Service Pass-Through Terms, your use of that model is further subject to those terms.

Data classification of inputs/outputs:

| Input data classification | Output data classification | Designation |
|---|---|---|
| Usage Data | Customer Data | Covered AI Features |

("Covered AI Features" is the defined term in the AI Terms and Acceptable Use Policy.) For more, see Snowflake AI and ML.

---

## 22. Source map

All pages crawled from the Snowflake Documentation (English), rooted at the page provided.

**Core / overview**
- Cortex Code (overview): `/en/user-guide/cortex-code/cortex-code`

**Snowsight**
- Cortex Code in Snowsight: `/en/user-guide/cortex-code/cortex-code-snowsight`
- Skills and Plugins (Snowsight): `/en/user-guide/cortex-code/cortex-code-snowsight/skills-and-plugins`

**CLI core**
- Cortex Code CLI (getting started): `/en/user-guide/cortex-code/cortex-code-cli`
- CLI reference: `/en/user-guide/cortex-code/cli-reference`
- Settings: `/en/user-guide/cortex-code/settings`
- Managed settings: `/en/user-guide/cortex-code/managed-settings`
- Security: `/en/user-guide/cortex-code/security`
- Sandbox: `/en/user-guide/cortex-code/sandbox`
- Extensibility (Skills/Subagents/Hooks/MCP): `/en/user-guide/cortex-code/extensibility`
- Bundled skills: `/en/user-guide/cortex-code/bundled-skills`
- Workflow examples: `/en/user-guide/cortex-code/workflows`

**Protocols & plugins**
- MCP support: `/en/user-guide/cortex-code/cortex-code-mcp`
- ACP support: `/en/user-guide/cortex-code/cortex-code-acp`
- Plugins: `/en/user-guide/cortex-code/cortex-code-plugins`

**Agent SDK** (overview crawled; sub-references listed)
- Agent SDK overview: `/en/user-guide/cortex-code-agent-sdk/cortex-code-agent-sdk`
- Quickstart: `/en/user-guide/cortex-code-agent-sdk/quickstart`
- TypeScript SDK reference: `/en/user-guide/cortex-code-agent-sdk/typescript-reference`
- Python SDK reference: `/en/user-guide/cortex-code-agent-sdk/python-reference`
- Multi-turn sessions / streaming input: `/en/user-guide/cortex-code-agent-sdk/streaming-input`
- MCP servers / custom tools: `/en/user-guide/cortex-code-agent-sdk/mcp-custom-tools`
- System prompts: `/en/user-guide/cortex-code-agent-sdk/system-prompts`
- Approvals & user input: `/en/user-guide/cortex-code-agent-sdk/user-input`
- Structured output: `/en/user-guide/cortex-code-agent-sdk/structured-output`
- Streaming output: `/en/user-guide/cortex-code-agent-sdk/streaming-output`
- Hooks: `/en/user-guide/cortex-code-agent-sdk/hooks`

**Cost / lifecycle**
- Changelog: `/en/user-guide/cortex-code/changelog`
- Cost controls / credit usage limits: `/en/user-guide/cortex-code/credit-usage-limit`

**Cortex Code Desktop (Private Preview)**
- Download portal: `https://www.snowflake.com/en/product/limited-access/cortex-code/`
- Build repo: `https://sfc-repo.snowflakecomputing.com/coco-desktop/downloads/latest/` (macOS `arm64`/`x64` `.dmg`; Windows `x64`/`arm64` `-user-setup.exe`)
- Detailed §16 content sourced from the user-supplied *Cortex Code Desktop — Comprehensive Reference Guide* (v1.0, May 31, 2026) — **not** published on docs.snowflake.com. The only Desktop reference in the public docs is the `CORTEX_CODE_DESKTOP_DAILY_EST_CREDIT_LIMIT_PER_USER` parameter on the cost-controls page above.

*(Prefix docs paths with `https://docs.snowflake.com`.)*

**Key external references cited in the docs:** Cross-region inference; Control model access (AISQL privileges & access); Cortex Analyst; Snowflake CLI (configuring connections); Programmatic access tokens; Snowflake Service Consumption Table (pricing PDF); Model & Service Pass-Through Terms.

---

*End of document.*
