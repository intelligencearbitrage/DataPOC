# SnowPrism — CoCo Build Instructions (R1 + R2)

**Give this file to Cortex Code (CoCo) and say: "Follow this file to build SnowPrism."**
Proven on Snowflake account EYC23748 under SYSADMIN, 2026-05-29. Self-contained — builds its own
synthetic data, does **not** use `SNOWFLAKE.ACCOUNT_USAGE`.

---

## 0. Make It Yours (CoCo: confirm these with the user before running)

| Placeholder | Default | Change to |
|-------------|---------|-----------|
| Role | `SYSADMIN` | a role that can `CREATE DATABASE` |
| Warehouse | `COMPUTE_WH` | a warehouse the user can run on |
| Database | `SNOWPRISM_DB` | (optional) the user's preferred name |

**Requirements:** Cortex must be enabled in the account/region (for R2). If the building role does
not own the schema, also run: `GRANT DATABASE ROLE SNOWFLAKE.CORTEX_USER TO ROLE <role>;`

**CoCo behaviour:** Present DDL for review before executing. Never auto-run destructive statements.

---

## 1. Setup

Create database `SNOWPRISM_DB` with schemas `RAW`, `STAGING`, `ANALYTICS`, `GOVERNANCE`.
Set context: `USE ROLE SYSADMIN; USE WAREHOUSE COMPUTE_WH;`.

## 2. Seed synthetic metering data

Create `SNOWPRISM_DB.RAW.SAMPLE_METERING_HISTORY` mirroring `WAREHOUSE_METERING_HISTORY`
(`WAREHOUSE_NAME, START_TIME, END_TIME, CREDITS_USED, CREDITS_USED_COMPUTE, CREDITS_USED_CLOUD_SERVICES`).
Fill 450 days of daily rows for 8 warehouses — `WH_MARKETING_ETL, WH_MARKETING_BI, WH_FINANCE_CLOSE,
WH_DATAENG_TRANSFORM, WH_DATAENG_INGEST, WH_SALES_ANALYTICS, WH_PLATFORM_OPS, WH_ADHOC_SANDBOX` —
with per-warehouse base credits, weekend dips (~35% of weekday), daily random noise, and two anomaly
spikes (WH_DATAENG_TRANSFORM 14 days ago ×6, WH_FINANCE_CLOSE 3 days ago ×5).
**Expect ~3600 rows, 8 warehouses.** (Exact SQL: see `snowprism_build.sql`.)

## 3. R1 — Credit Visibility

1. `RAW.T_TENANT` (TENANT_ID, TENANT_NAME, MONTHLY_BUDGET_CREDITS): MARKETING 120, FINANCE 80,
   DATA_ENG 220, SALES 70, PLATFORM 100, UNASSIGNED 0.
2. `RAW.T_WAREHOUSE_TENANT_MAP` — unique `WAREHOUSE_NAME`, `TENANT_NAME` default `UNASSIGNED`,
   plus credit total + audit columns. **Do not use ILIKE name matching.**
3. `RAW.SP_SYNC_WAREHOUSE_TENANT_MAP` — MERGE distinct warehouses from the seed table; new ones =
   UNASSIGNED; never overwrite manual assignments. Call it.
4. Assign tenants (UPDATEs): WH_MARKETING_* → MARKETING, WH_FINANCE_* → FINANCE,
   WH_DATAENG_* → DATA_ENG, WH_SALES_* → SALES, WH_PLATFORM_* → PLATFORM. Leave WH_ADHOC_SANDBOX
   UNASSIGNED (to prove the COALESCE path).
5. Dynamic Tables on `COMPUTE_WH`:
   - `ANALYTICS.DT_CREDIT_BY_WAREHOUSE` — sum credits by warehouse + date. `TARGET_LAG='1 hour'`.
   - `ANALYTICS.DT_CREDIT_BY_TENANT` — LEFT JOIN to the map, `COALESCE(TENANT_NAME,'UNASSIGNED')`.
     `TARGET_LAG=DOWNSTREAM`.
   - `ANALYTICS.DT_CREDIT_DAILY_TREND` — total credits per day. `TARGET_LAG=DOWNSTREAM`.
6. `ANALYTICS.V_CREDIT_SUMMARY` — per tenant: credits today / this week / this month, monthly budget,
   `PCT_BUDGET_CONSUMED`.

**R1 checkpoints:** `DT_CREDIT_BY_WAREHOUSE` = 720 rows; `V_CREDIT_SUMMARY` = 6 rows with % filled
(DATA_ENG highest, ~90%).

## 4. R2 — Conversational FinOps (lite)

1. `ANALYTICS.SV_FINOPS` semantic view over `DT_CREDIT_BY_TENANT`:
   - PRIMARY KEY (TENANT_NAME, CREDIT_DATE, WAREHOUSE_NAME)
   - Dimensions: TENANT_NAME, WAREHOUSE_NAME, CREDIT_DATE
   - Metric: TOTAL_CREDITS = SUM(TENANT_CREDITS)
2. Validate with Cortex Analyst (these are proven to work):
   - "Which tenant spent the most credits in total?" → **DATA_ENG**
   - "Show me the daily credit trend for the last 30 days" → dated totals
   - "Break down credit usage for the DATA_ENG tenant by warehouse" → 2 warehouses (TRANSFORM, INGEST)

**R2 checkpoints:** `SHOW SEMANTIC VIEWS` returns `SV_FINOPS`; Cortex Analyst answers the 3 questions.

---

## Notes / gotchas (from a real build)

- Dynamic Tables populate on create (`initialize=ON_CREATE`); a complex-join DT auto-uses FULL refresh — that's fine.
- Query a semantic view via `SELECT * FROM SEMANTIC_VIEW(<name> DIMENSIONS ... METRICS ...)`, not a plain SELECT.
- Under an owning role (e.g. SYSADMIN) no extra grant was needed for the semantic view or Cortex Analyst.
- Numbers vary run-to-run (random noise); the *shape* (DATA_ENG highest) is what matters.

**Out of scope:** R3 (query health), R4 (anomaly/forecast/alerts), R5 (Streamlit dashboard).
