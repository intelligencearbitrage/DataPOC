# Snowflake Summit — Cortex Code Hands-On Lab
## Detailed Talk Track (90 minutes)

*This is the speaker's runsheet. Spoken content in normal prose. Stage cues in italics inside square brackets. Time markers at every transition. Print it, scan it backstage, hold it in your back pocket during the lab.*

---

## How to use this document

**The talk track is densest in the first 35 minutes and the last 11 minutes.** The 47 minutes of lab in between is mostly facilitation, not speaking — I have given you the exact prompts to use at each beat transition, but between beats your job is to walk the room, not to talk.

**Full phrasing is given for the critical beats.** The opening hook, the case study story, the take-home, and the closing line. Use these as written or adapt to your own voice in the moment, but the structure has been engineered.

**Stage cues in italics.** When you see *[Pause. Look at the room.]* — actually pause. The pauses are where the lesson lands.

**Pacing rule.** If you ever feel you are racing, you are. Slow down by two notches. The most common failure mode at minute 50 of any conference talk is the speaker compressing because they sense time pressure. Do not.

**If you forget where you are.** The time markers are your friend. Glance at your watch, find the nearest marker, pick up from there. No one will know.

---

# ACT 1 — OPENING (0:00 — 12:00)

**[00:00] — Begin**

*[Walk to the front. Look at the room. Pause. Begin.]*

Good morning. Thank you for being here.

*[Pause again. Set the tone.]*

In the next twelve minutes, before you touch the lab, I want to give you the one idea I would like you to leave this room with, even if everything else falls out of your head by Friday.

Most of you have tried agentic coding. Some of you walked in here from another session where someone showed you a working app built in thirty minutes from a single prompt. That is real. That is not a trick. That is what we now call vibe coding.

And vibe coding is fine. I do it. For a prototype, for a one-off exploration, for "let me see what this looks like before I commit to it," it is a real productivity unlock.

But here is what I noticed the first time I tried to build something serious with Cortex Code.

**[02:00] — Personal beat**

*[Slow down. This is your origin story. The pace shift signals "this is the real talk."]*

I typed in what I wanted. I got something back. It looked like an agent. It ran in Cortex. It even did the thing I asked for. And then I tried to hand it to a colleague, and we could not figure out which decisions the agent made on its own and which decisions came from me. I could not tell what was a feature and what was a hallucination. The code was real. The intent was not captured anywhere.

So I threw it away and started over.

The second time, I spent ten minutes before I typed any prompt. I wrote down what I was trying to build, the constraints I cared about, the data I had access to, and the governance my client required. Then I gave that to the agent and asked it to build to that spec.

What came back was different. Not in the demo. The demo looked the same. The difference was that I could hand the spec to a teammate, version it, change one line, and watch hundreds of lines of code change downstream in a way that made sense.

That is what we are doing today.

**[04:30] — Orient**

The community has started calling this Spec-Driven Development, or structured vibe coding. The idea is simple. The agent is the muscle. The spec is the brain. You stop writing code. You start writing the context the agent does not already have.

Three things change when you do this.

You control large code changes with small changes to the spec. One sentence in a spec might produce three hundred lines of code. Change that sentence, the three hundred lines change with it.

You stop losing context between sessions. The spec persists. Your colleague picks up the work tomorrow and reads the same brain you wrote yesterday.

And the agent makes fewer mistakes, because you forced yourself to define what success looks like before generation started.

**[06:00] — Bridge into the three patterns**

I have been using this approach for about a year now, across Cortex Code and Claude Code, on real client work. Not pitched projects. Things I built, broke, and rebuilt. I want to share three patterns that have come out of that work, because the patterns travel better than the projects.

**[06:30] — Pattern 1: Migration becomes product**

The first pattern is about migration work. If your team does any modernization, such as Informatica to DBT, Sybase to Snowflake, or legacy SQL to Snowflake, you already know that the first one is bespoke. By the third one, you start noticing that you are solving the same problem in slightly different shapes.

I wrote a Constitution for a Sybase to Snowflake migration. It captured the patterns. How we map data types. How we handle stored procedures. How we validate the cutover. The first migration took the time it normally takes. The second one was meaningfully faster. The third one became a SKILL the team invokes instead of writing the migration from scratch.

The shift was not that the agent got better. The shift was that the spec became the productized version of the work. The code generated from it was almost incidental.

I will come back to this pattern at industrial scale in a few minutes, with a client engagement where the same approach compressed nine months of work into three.

**[08:00] — Pattern 2: Governance lives in the SKILL**

The second pattern is about governance. Every enterprise data conversation gets stuck here. Where does sensitive data live? Who can see it? What happens when a new column appears?

I built a Sensitive Data Governance SKILL that the agent invokes whenever it creates or modifies a table. The SKILL knows the client's classification rules. It checks. It applies tags. It flags exceptions for human review.

The reason this works inside Snowflake, and not as well outside, is that the SKILL is reaching into the platform's existing controls. Masking policies, RBAC, tag-based policies. The spec does not have to invent governance. It invokes what the platform already enforces.

This is what people mean when they say governance is native, not bolted on. The SKILL is one layer above the platform, not two.

**[09:15] — Pattern 3: Spec captures judgment**

The third pattern is the one I find most useful for skeptics. We built a natural language agent to generate PowerPoint presentations. Sounds simple. It is not.

The hard part of generating a presentation is not the code that places boxes on the slide. The hard part is the judgment. Which template fits this audience. When to use a table versus a chart. When a slide is too dense. When to break a thought across two slides. That judgment is what makes the difference between a slide your colleagues respect and a slide they ignore.

We tried to put that judgment in prompts. It did not survive context changes. We moved it into a spec. The spec captures the judgment. The code is mostly disposable.

*[Slow down. This is the headline.]*

That is the line I want you to take home. **In Spec-Driven Development, the spec captures the judgment. The code is what falls out of it.**

**[10:30] — The Snowflake-specific turn**

You can do this with any agent. Claude Code, Cursor, Codex, Gemini CLI. The patterns travel. But here is what I want you to notice while you are in the lab today.

Cortex Code runs inside Snowflake. That sounds like a deployment detail. It is not. It changes what your spec has to do.

When your agent runs outside the platform, the spec has to describe the governance, the access controls, the lineage, the model approvals, all the things that sit between intent and production. When your agent runs inside Snowflake, most of that is already there. The Constitution you write today inherits the controls Snowflake already enforces. The spec becomes the contract between you, your agent, and a platform that has been doing governance for ten years.

**[11:30] — The honest beat**

One last thing before I hand it over.

Spec-Driven Development is not free. Writing a spec takes thinking, and thinking is the expensive part. If you are exploring an idea you might throw away in an hour, vibe code. If you are building something a colleague will read in three months, specify. If you are building something a client will run in production, specify carefully.

The decision is not "always specify." The decision is knowing which mode you are in.

**[12:00] — Transition into demos**

Here is what is going to happen in the next ninety minutes.

Before you touch the lab yourself, I am going to show you two things we have built using this approach. Then I am going to walk you through one client engagement, anonymized, where this method compressed a Teradata migration that would normally take months. Then you do the work.

Let me show you what we have built.

---

# ACT 2A — DEMO 1: Snowflake Environment Auto-Provisioning (12:00 — 19:00)

**[12:00] — CLI and DDA 3.0 context**

*[Move to the demo screen. Do not just dive into the agent. Set the context first.]*

Quick context before I show you this. What you are about to see runs on the Cortex Code CLI, not the Snowsight UI version. The CLI is more capable. Most importantly, the CLI is where custom SKILLs work. The Snowsight version is a great starting point. The CLI is where the productive work happens. The rest of what I show you today, including the client engagement after this, all runs in the CLI.

One more piece of context. The agents I am about to show you, and the migration factory I will walk you through in the case study, all sit under Deloitte Data Assist 3.0, our agentic AI framework. I will say more about DDA 3.0 when we get there. For now, just know it is the umbrella for everything you are about to see.

**[13:00] — The Constitution**

*[Open the Constitution markdown file. Show it on screen for 30 seconds.]*

This is the Constitution for our environment auto-provisioning agent. Mission. Tech stack. The environment standards we enforce. The governance rules baked in. Everything the agent needs to know about how we do this work is in this one markdown file.

**[13:30] — The feature spec**

*[Switch to the feature spec.]*

This is one feature spec under that Constitution. "Provision a development environment with PII masking applied by default." Eight lines. Notice what is NOT in here. There is no code. No SQL. No procedure. Just the intent and the constraints.

**[14:00] — Run the agent**

*[Invoke the agent. Don't narrate every step. Talk over it.]*

What you are about to see is not the agent's intelligence. It is the Constitution's clarity. If the Constitution is good, the agent is reliable. If the Constitution is sloppy, the agent is creative in ways you do not want.

*[While the agent runs, fill the time:]*

The agent is reading the Constitution. It is parsing the feature spec. It is asking itself "what is the safest way to do this given the rules I just read." That is the part that matters. The actual provisioning is just SQL.

**[16:00] — The result**

*[Open the resulting Snowflake account.]*

Here is what came out. RBAC configured. Tag-based policies in place. Masking policies applied. All from a single invocation against that eight-line feature spec.

**[17:00] — The take-home**

This Constitution travels. Same approach, different environment definitions, same SKILL. We use this for client environments, internal environments, demo environments. The Constitution is the durable artifact. The code is the byproduct.

**[18:00] — Transition into Demo 2**

That is the auto-provisioning agent. Same SDD discipline, very different domain — let me show you the second example.

---

# ACT 2B — DEMO 2: Natural Language PowerPoint Agent (19:00 — 26:00)

**[19:00] — The SKILL context**

This demo is driven by a custom SKILL. SKILLs are how you encode the patterns and judgment we have been talking about into something the agent can invoke. A SKILL is a folder. It has a short description telling the agent when to use it, and a set of instructions, references, and code the agent reaches for when invoked. SKILLs are how Spec-Driven Development moves from a discipline to a library. They are also, importantly, only available in the CLI version of Cortex Code.

**[20:00] — The judgment in the SKILL**

*[Open the SKILL file. Show the section that captures judgment.]*

This is where the work lives. Not the code that places boxes on slides. The judgment about which template to use for which audience. What makes a slide too dense. When to break a thought across two slides. The judgment is what makes the difference between a slide your colleagues respect and a slide they ignore. That judgment is in this file.

**[21:00] — Run the agent**

*[Invoke with first prompt.]*

Watch what happens when I prompt this. "Generate a five-slide deck explaining the Q3 financial results, for an executive audience."

*[Agent runs. Brief commentary while it works.]*

The agent is reading the SKILL. It is looking up which templates the SKILL says to use for executive audiences. It is making the judgment calls the SKILL told it to make.

**[22:30] — The result**

*[Flip through the slides.]*

Here is what came out. Notice the structure. The hierarchy. The choices about what is on each slide.

**[23:30] — Change the audience**

Now watch this. Same prompt. Different audience. "Generate a five-slide deck explaining the Q3 financial results, for a technical team."

*[Agent runs. Show the different deck.]*

Same data. Different judgment applied. The SKILL knew what to do because the judgment was already encoded.

**[25:00] — The take-home**

The SKILL encoded the judgment. The agent applied it. If we had put this judgment in prompts, we would be re-prompting forever, and we would lose the judgment every time someone new touched the work. The SKILL is the durable artifact.

**[26:00] — Transition into the case study**

Those are two examples of what this approach looks like in our practice. Smaller ones. Things we built, that work, that we use every day.

What I want to show you next is what happens when you take this same approach to industrial scale. One client engagement. The full Data Assist plus SnowConvert architecture. And what it produced.

---

# ACT 3 — CASE STUDY: Cisco / Teradata Migration (26:00 — 35:00)

**[26:00] — Minute 0: DDA 3.0 framing**

*[Stand still. Don't pace. This is your most detailed beat. Visual aid on screen if available.]*

Before I tell you the engagement story, let me name the framework underneath. Deloitte Data Assist 3.0 is our agentic AI framework. Underneath it sits a multi-agent architecture purpose-built for enterprise data modernization.

*[Gesture to the Solution Backbone slide if on screen.]*

A Reverse Engineering Agent decodes legacy codebases. A Consolidation Agent modernizes the code. A Data Model Mapping Agent maps to the target data model. Snowflake's SnowConvert AI handles the final code generation. And running across all of them, a Documentation Agent captures the evidence trail in markdown.

On top of this architecture, we build custom SKILLs that codify the specific patterns each client cares about. The dbt Model Optimizer SKILL you are about to hear about is one of those. Everything I am about to walk you through is DDA 3.0 in production.

**[27:00] — Minute 1: The situation**

A large enterprise technology company. Mission-critical Teradata estate. Years of Informatica ETL on top. Aggressive timeline pressure from their Chief AI Officer. Traditional estimate for this work was nine months. The deadline was tighter than that, with a Teradata contract renewal in December that was the real driver. The gap was real and expensive.

**[28:00] — Minute 2: Why traditional migration would not work**

The traditional approach is a large team, deep SME interviews, manual code review, slow handoffs. Even with strong code-generation tooling, generation alone is not enough. The output needs to be production-ready, idiomatic, and ownable by the client's team after we leave. That requires more than just generation.

It requires reverse engineering of the legacy estate, consolidation of the modernized code, model mapping against the new target, optimization for the platform, and a complete audit trail. That is the gap the Data Assist plus SnowConvert architecture closes.

**[29:00] — Minutes 3-4: The architecture in action**

What made this engagement different was not throwing an agent at the migration. It was applying the full Data Assist plus SnowConvert architecture I just showed you.

*[Walk through each agent on the slide as you name it.]*

The Reverse Engineering Agent decoded the legacy Informatica mappings and the SQL Server estate behind them. Pulled the structure. Generated a current-state analysis. Produced a source-to-target mapping the rest of the pipeline could consume.

The Consolidation Agent took that current state and modernized the code through three sub-stages: analyze, plan, consolidate. The output was a cleaner intermediate form that was ready for mapping.

The Data Model Mapping Agent mapped the consolidated code against the target Snowflake data model. Suggested old-versus-new mappings. Rewrote the code to fit the new model.

SnowConvert AI handled the final code generation into the client's Snowflake environment.

And running across all of this, the Documentation Agent captured the evidence trail. Every decision, every recommendation, every change, in markdown.

On top of that architecture, we built a custom SKILL specifically for this engagement: the dbt Model Optimizer. The SKILL polished every model the pipeline produced across six dimensions.

*[Pause. List the dimensions deliberately. Slow down here.]*

Dialect cleanup. Code quality. Snowflake-native pattern adoption, things like QUALIFY and FLATTEN that the Teradata source did not have. Testing coverage. SQL performance. And cost optimization.

Six dimensions, applied systematically to every model. That SKILL is what produced production-ready dbt code, not just transpiled SQL.

**[31:00] — Minute 5: The governance mechanism**

The SKILL did not just make changes. It classified them.

*[Slow down. This is the bit that lands hardest.]*

SAFE meant the change was deterministic and reviewable in batch. REVIEW meant it needed a human eye but was likely fine. REQUIRES APPROVAL meant a human had to make the call before the change shipped.

This is the bit I want you to remember from this whole session. The trust did not come from believing the agent was right. The trust came from the agent being explicit about its own confidence and letting humans grade the work where it mattered. If you are an enterprise architect worried about agentic risk, that classification pattern is the answer. Adopt it tomorrow.

**[32:00] — Minute 6: The result**

The traditional nine-month timeline compressed to three months. February to May 2026. Sixty-seven percent compression. Eight figures in cost avoidance, primarily by completing ahead of the renewal window.

More importantly, what the client received was production-quality dbt code their team could own and evolve. Not transpiled output that would have to be rewritten in two years. The migration was the deliverable. The dbt codebase was the asset.

**[33:00] — Minute 7: The Snowflake-specific lesson**

Two things mattered for Snowflake specifically.

First, Cortex Code CLI ran inside the client's Snowflake account. The governance the agent had to respect was the client's Snowflake governance, already enforced. The spec did not have to invent any of that. RBAC, masking policies, tag-based controls, all of it inherited.

Second, the dbt Model Optimizer SKILL knew how to use Snowflake-native patterns the source platform did not have. QUALIFY instead of nested subqueries. FLATTEN instead of UDF gymnastics. The agent did not just translate. It modernized.

**[34:00] — Minute 8: The take-home**

Three things from this story.

First, the spec was the brain. The dbt Model Optimizer SKILL captured judgment we have built over many engagements. The agent applied it. The leverage was in the SKILL, not in the agent's general capability.

Second, classified outputs are what made it shippable at this scale. SAFE / REVIEW / REQUIRES APPROVAL is a pattern you can adopt in your own work next week. You do not need our SKILL to use the classification idea.

Third, this approach works because Cortex Code CLI runs in the platform. The agent inherited the governance. The platform did real work. That is the difference between agentic coding everywhere else and agentic coding in Snowflake.

*[Pause. The bonus observation.]*

And one more thing worth noticing. Look at the Documentation Agent in the architecture. What did it produce? Markdown files. Every decision, every recommendation, every change captured in markdown. That is the same discipline I have been teaching you all morning. The agentic architecture and the spec-driven discipline are not two things. They are the same thing at different scales. When we say spec-driven development scales, this is what scaling looks like in production.

---

# TRANSITION TO LAB (35:00 — 35:30)

*[Energy shift. From standing still to walking. From telling to facilitating.]*

OK. That is what the work looks like in production. Now it is your turn.

---

# ACT 4 — HANDS-ON LAB (35:30 — 79:00)

## Lab Setup (35:30 — 39:00)

*[Walk to the middle of the room. Speak to everyone, not just the front.]*

Here is what we are going to do for the next forty minutes.

You are going to build an agent that ingests a customer CSV into Snowflake. It contains a thousand records: names, emails, phone numbers, ages, regions, last purchase dates, lifetime value. The marketing team needs it in by end of day so they can run a campaign analysis. Your job is to build an agent that ingests this with the right types, the right governance, and a validation report.

You are going to do this twice. Once the easy way. Once the right way.

*[Pause. Pair them up.]*

Pair up with the person next to you. Whoever is in seat A on each row writes. Whoever is in seat B reviews. We will swap halfway through. Confirm with your partner that you are paired.

Also confirm one thing: you are working in the Cortex Code CLI, not Snowsight. SKILLs are a CLI feature. If you are in Snowsight, switch now.

---

## Beat 1: Vibe Round (39:00 — 44:00)

*[Start the timer where they can see it.]*

**[39:00]** First attempt. No spec. Just prompt Cortex Code to do it. Type what you want. See what you get. Five minutes. Go.

*[Walk the room. Do NOT help. Note who is finishing, who is stuck, who is producing something interesting. Mental notes for the reveal later.]*

**[43:00]** *[Announce two-minute warning silently with hand gesture if possible. Don't break their focus.]*

**[44:00]** Stop.

---

## Beat 2: Pause and Observe (44:00 — 47:00)

*[Stand at the front. Let the room settle.]*

Stop typing. Look at what you got. Three questions for your pair.

First. Did the agent ask you about PII? Or did it just guess?

Second. Did it ask you about data types? Or did it just guess?

Third. Would you ship this?

*[Take two or three hands. Listen. Do NOT lecture. Let them surface the problems.]*

*[After three or so responses, move on.]*

---

## Beat 3: Constitution Writing (47:00 — 54:00)

*[Energy shift. From talking to writing. The room should go quiet.]*

Now we slow down.

Close your laptop, or open a markdown file. Do not write code. Do not prompt the agent. For seven minutes, write a Constitution for this work.

Three sections. Mission. Tech stack. Roadmap. Be specific. If you are not sure what goes in each section, look at the handout.

*[Walk the room. If you see someone typing in Cortex Code, gently redirect: "Not yet. Write the Constitution first." This will happen. Be patient.]*

**[53:00]** *[Two-minute warning, silently.]*

**[54:00]** OK, time.

---

## Beat 4: Spec-Driven Round (54:00 — 67:00)

Now, with your Constitution in hand, go back to Cortex Code. Give it the Constitution. Then prompt for the same thing as before. See what changes. Thirteen minutes.

Person A writes for the first seven. Person B reviews against the Constitution. At minute seven I will call swap.

*[Walk the room. Identify 2-3 pairs producing notably good results. You will reveal these at minute 72.]*

**[61:00]** *[Walk to the front.]* Swap. Person B writes. Person A reviews.

*[Continue walking the room.]*

**[66:00]** *[Two-minute warning, silently.]*

**[67:00]** Stop.

---

## Beat 5: The Change-One-Line Reveal (67:00 — 72:00)

*[This is the lightbulb moment. Walk to the front. Get everyone's attention.]*

Everyone, look at your Constitution. Find ONE line. Maybe the line that says "mask PII before insert." Or "use VARCHAR(255) for text fields." Or "fail on duplicate keys." Any line.

Change that one line. Just one. Now ask Cortex Code to re-implement against the new Constitution.

Watch what happens.

*[Give them three minutes. Walk the room. Look at faces. You should see at least a few "oh" moments. Those are your reveal candidates if you didn't already have them.]*

**[71:00]** Stop. Look at what changed. One line in your Constitution. How many lines of code shifted with it?

*[Take one or two responses. Don't lecture. Move on.]*

---

## Beat 6: Reveal and Compare (72:00 — 79:00)

*[This is where participants teach participants. Your job is to facilitate, not to summarize.]*

I want to share a few of the outputs I saw in the room.

*[Bring 2-3 strong outputs to the front via projector or screen share. Ask the authors to come up if they're comfortable.]*

This pair built this. Walk us through it. What was in your Constitution that made this work?

*[Let the author talk. Do NOT fill the silence. Their articulation is the lesson. After they finish, ask one follow-up:]*

What did you almost put in the Constitution but didn't? Or what did you have to add after the first attempt failed?

*[Repeat for the second and third example.]*

*[If time allows and you have a weak example, anonymize it and put it on screen:]*

Here is one I saw that did not work as well. What is missing from this Constitution?

*[Take one or two hands. The diagnostic is the lesson.]*

---

# ACT 5 — WRAP (79:00 — 90:00)

## Claude Code Transferability (79:00 — 81:00)

*[Walk back to the front. Address the room.]*

Before we go to questions, one thing for those of you who already use Claude Code or a similar agent.

What you have learned about spec-driven work in Claude Code transfers. The Constitution is the same shape. SKILLs use the same format. The patterns travel. You are not starting from zero with Cortex Code.

What is different in Cortex Code is the platform. You get governance for free that you have to build everywhere else. You get Snowflake-native execution. You get the data perimeter without negotiating it. The 80% you already know carries over. The 20% that is specific to Cortex Code is how to use AISQL, how to invoke Snowflake-native functions in your SKILLs, and how to lean on Snowflake's governance model instead of reimplementing it.

The dbt Model Optimizer SKILL I told you about earlier was originally adapted from a SKILL we built for Claude Code work. The patterns traveled. Yours will too.

---

## Q&A (81:00 — 86:00)

*[Open the floor. Take five or six questions if they come.]*

Questions?

*[Listen for: brownfield estates, dbt or Coalesce integration, model portability, time savings, the SAFE / REVIEW / REQUIRES APPROVAL classification, healthcare or FSI applications, what about my legacy estate. All have prepared answers in the briefing.]*

*[If a question comes about a specific industry, deploy one of your back-pocket examples. Healthcare: no-show recommendation, inpatient/outpatient analytics, or US News & World Report hospital rankings. FSI: intercompany reconciliation.]*

*[If someone asks about the client in the case study, the response is the same regardless of who asks:]*

I can talk about the patterns and the approach. I cannot confirm or deny which client this was. The metrics are documented in materials we are allowed to share. The client is not.

*[Move on. Do not let the conversation drift into client guessing.]*

**[85:00]** *[Wind down. Take one last question if there is one.]*

---

## DDA 3.0 Take-Home (86:00 — 88:00)

*[Walk to the center of the room.]*

One last thing for those of you who want to dig deeper.

Everything I showed you today — the SDD patterns, the SKILLs, the classification approaches, the migration factory — all sits under Deloitte Data Assist 3.0. That is the framework name. If you want to learn more about how we operationalize this at scale, that is the thing to ask about. Find me after this session, or talk to your Deloitte contact. I am happy to keep the conversation going.

---

## Closing Line (88:00 — 90:00)

*[Pause. Look at the room. Slow down. This is the line they take home.]*

The agent will get faster. The models will get better. What you take home from this room is not a tool. It is a way of working that survives the next three model releases.

Write things down. Make the agent serve the writing.

*[Pause. Let it land. Do NOT keep talking.]*

Thank you for being here today. The handout is at the back of the room. Safe travels.

*[Done. Walk off-stage or to the side. Be available for the hallway conversations.]*

---

# Speaker Notes — Recovery Patterns

**If you forget where you are:** Glance at the time. Find the nearest marker. Pick up from there. The audience will not know.

**If you are running long at minute 30:** Cut the third example in the case study and go straight from the architecture description to the result. Save 90 seconds.

**If you are running short at minute 30:** Add 60 seconds to the case study by lingering on the classification pattern. It is the bit most likely to generate Q&A.

**If a demo breaks:** Fall back to the SKILL file. "Let me show you the SKILL while we wait for the environment." The SKILL is more important than the live demo anyway.

**If the room energy drops at minute 50:** You are talking too much. Cut whatever you are saying. Start the next beat 60 seconds early.

**If Q&A is dead at minute 81:** Skip it. Go straight to the DDA 3.0 take-home and the closing line. Better to end strong than to chase questions that are not coming.

**If a participant gets emotional or hostile:** Acknowledge. Do not engage. "That is a fair concern. Let's talk after." Move on. Do not let one person derail the room.

---

# Final Reminders

The lab is where the learning happens, not the open. If you have to choose between a tight open and a tight lab, protect the lab.

The change-one-line beat is the lightbulb. Protect it.

The reveal is where participants teach participants. Their voices are more powerful than yours in that moment.

The closing line is what they remember on the plane home. Slow down.

You have done this kind of work many times. Trust the design. Walk the room. Talk less than you think you should.
