# Snowflake Data Platform — Week-by-Week Plan by Resource
**POD B · 24 weeks · Revised team reflecting Snowflake Cortex Code acceleration**

---

## Revised Team

> Snowflake Cortex Code acts as a force multiplier, replacing the need for junior and mid-level engineering headcount by automating boilerplate SQL generation, DBT model scaffolding, routine transformation logic, and automated DQ checks. This reduces the core team to 2 people, with a US Senior Data Engineer brought in part-time during critical integration phases only.

| Role | Location | Engagement |
|---|---|---|
| Snowflake Architecture Lead | US | Full 24 weeks |
| Senior Data Engineer | India | Full 24 weeks |
| Senior Data Engineer | US | Part-time — Weeks 8–16 only (integration & curated layer) |
| Snowflake Cortex Code | — | Continuous (replaces junior/mid engineering effort) |

---

## Phase 1 — Kickoff & Scoping (Weeks 0–1)

| Week | US Architecture Lead | India Senior Data Engineer | Cortex Code |
|---|---|---|---|
| Week 0 | Engagement kickoff; architecture alignment with Carlyle and Palantir; governance setup | Source system inventory and documentation review; tooling and access setup | Snowflake environment provisioning scripts; RBAC and access control templates generated |
| Week 1 | Finalize architecture design; Data Vault approach confirmed; raw zone design signed off | Source connectivity assessment across all priority sources | DBT project scaffolding and standards configuration generated |

**✓ Milestone: Snowflake environments ready; architecture approach agreed**

---

## Phase 2 — Source Onboarding & Raw Data Foundation (Weeks 2–9)

| Week | US Architecture Lead | India Senior Data Engineer | Cortex Code |
|---|---|---|---|
| Week 2 | Raw zone design review; ingestion pattern sign-off; parallel feed design for Palantir | Source-to-target mapping for PE sources (Investran, eFront, Allvue) | Snowpipe ingestion scripts for Investran generated and reviewed |
| Week 3 | Architecture review; resolve blockers | Investran ingestion testing and validation; eFront ingestion build | eFront and Allvue ingestion scripts generated |
| Week 4 | Parallel feed design review; audit trail design | Allvue and Chronograph ingestion build | Salesforce and market data ingestion scripts generated |
| Week 5 | Governance and access control design review | Ingestion testing and validation across all sources | Pipeline scheduling, monitoring, and alerting templates generated |
| Week 6 | Raw zone QA review; sign-off on raw data availability to Palantir | End-to-end raw zone validation; source-level traceability audit | Automated DQ check scripts for raw zone generated |
| Week 7 | Stakeholder review: raw data status with Carlyle and Palantir teams | Resolve ingestion issues; finalize load controls; raw zone schema documentation | Raw zone lineage documentation auto-generated |
| Week 8 | Curated layer architecture and Data Vault design sessions | Begin source-to-curated mapping for PE entities | Initial curated DBT model scaffolding generated |
| Week 9 | Curated layer design sign-off | Source-to-curated mapping for Credit and AlpInvest entities | DBT model scaffolding for Credit and AlpInvest curated layer generated |

**✓ Milestone: Raw data available to Palantir for ontology build**

---

## Phase 3 — Curated Data Model & DBT Framework (Weeks 10–17)

> US Senior Data Engineer joins part-time from Week 8 to support integration complexity during this phase.

| Week | US Architecture Lead | India Senior Data Engineer | US Senior Data Engineer (part-time) | Cortex Code |
|---|---|---|---|---|
| Week 10 | Data Vault curated layer architecture sign-off | Core entity DBT models: funds, deals, investors, investor accounts | Integration design: Snowflake-to-Palantir via Iceberg | DBT transformation logic for core entities generated |
| Week 11 | Business definition alignment workshops with Carlyle SMEs | Cash flow, NAV, and fee schedule DBT model build | Iceberg table design and interoperability review | DBT testing framework and unit test templates generated |
| Week 12 | Cross-workstream alignment: curated schema shared with Palantir | Standardize business keys and relationships across PE, Credit, and AlpInvest | AlpInvest-specific entity mapping review | DBT model documentation and lineage auto-generated |
| Week 13 | Iceberg table design review | Apache Iceberg tables: fund performance, cash flow histories, valuation snapshots | Palantir zero-copy interoperability testing | Automated DQ reporting scripts generated |
| Week 14 | RBAC and data governance framework sign-off | Data quality rules and DQ checks across curated layer | Row-level security and data masking implementation | RBAC and masking policy templates generated |
| Week 15 | Palantir interoperability review | DBT dependency logic, refresh cycles, and orchestration integration | Curated layer reconciliation testing against raw zone | DBT orchestration and refresh cycle scripts generated |
| Week 16 | Snowflake-to-Palantir integration testing oversight | Performance tuning and query optimization | End-to-end integration testing: curated tables consumed by Palantir | Defect logging and resolution tracking templates |
| Week 17 | Stakeholder review: fully developed Snowflake platform demo to Carlyle | Final data reconciliation checks; test case documentation | Sign-off pack preparation | Final platform validation report auto-generated |

**✓ Milestone: Fully developed Snowflake data platform; curated tables available to Palantir**

---

## Phase 4 — Post-MVP Stabilization (Weeks 18–24)

> US Senior Data Engineer rolls off after Week 17. Core 2-person team resumes.

| Week | US Architecture Lead | India Senior Data Engineer | Cortex Code |
|---|---|---|---|
| Week 18 | MVP deployment support; defect triage oversight | Resolve data defects and reconciliation breaks from MVP | Regression test scripts and defect tracking templates generated |
| Week 19 | Operational readiness review | Curated data model fine-tuning; refresh schedule optimization | Automated monitoring and alerting refinement scripts generated |
| Week 20 | Lineage and audit trail review; compliance check | Operational support process design for steady-state | Runbook and operational documentation auto-generated |
| Week 21 | Handoff planning: curated tables replace Palantir raw feeds | Confirmed Palantir handoff — curated table integration validated | Final data quality sign-off report generated |
| Week 22 | Scalability review: architecture blueprint for enterprise rollout | Reusable ingestion pattern and DBT model reuse framework documentation | Knowledge transfer materials auto-generated |
| Week 23 | Implementation roadmap contribution: Snowflake perspective for scaled rollout | Support Carlyle team onboarding to steady-state operations | Final QA and defect closure scripts generated |
| Week 24 | Final engagement review; lessons learned; scaled rollout recommendations | Final sign-off on all Snowflake deliverables; engagement close-out | Final documentation package auto-generated |

**✓ Milestone: Steady-state operations ready; handoff to Palantir confirmed**

---

## Key Deliverables Summary

| Deliverable | Owner | Target Week |
|---|---|---|
| Snowflake environments provisioned | Cortex Code + India Senior | Week 1 |
| Raw zone ingestion — all priority sources | India Senior Data Engineer | Week 7 |
| Parallel feed to Palantir enabled | US Architecture Lead | Week 9 |
| Curated Data Vault model | India Senior + US Senior (part-time) | Week 13 |
| Apache Iceberg tables | India Senior Data Engineer | Week 13 |
| DBT framework with lineage and testing | India Senior + Cortex Code | Week 15 |
| RBAC and data governance policies | US Architecture Lead | Week 14 |
| Snowflake–Palantir integration validated | US Senior Data Engineer (part-time) | Week 16 |
| Fully stabilized platform | US Architecture Lead + India Senior | Week 21 |
| Scaled rollout architecture blueprint | US Architecture Lead | Week 22 |

---

## Key Assumptions

- Snowflake Cortex Code replaces junior and mid-level engineering effort throughout, handling boilerplate SQL, DBT scaffolding, transformation logic, DQ automation, and documentation generation
- Core team of 2 (US Architecture Lead + India Senior Data Engineer) is sufficient for the full 24 weeks
- US Senior Data Engineer engaged part-time during Weeks 8–17 only to manage integration complexity between Snowflake curated layer and Palantir
- Up to 15–20 data sources assumed; 75% structured / 25% semi-structured
- Monthly refresh cadence; no significant performance re-architecture in this phase
- Carlyle SMEs available for business rule validation during Weeks 11–12
- Upstream data remediation is out of scope
- Palantir team begins ontology build in parallel from Week 9 using raw data feed
