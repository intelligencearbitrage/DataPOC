"""
STTM Validator - Validates the generated STTM Excel output.

Checks:
  1. Output file exists and is a valid Excel workbook
  2. All required tabs are present
  3. STTM mapping tab has expected structure (header rows, column headers, data rows)
  4. Lookup_Definitions tab has entries
  5. Index, Version History, Dependency Details tabs have headers
  6. No empty target columns in mapping rows

Usage:
    python scripts/validator.py
    python scripts/validator.py --file output/mtsXtrcWrkTB_sttm.xlsx
"""

import argparse
import sys
from pathlib import Path
from typing import Any, Dict, List

import openpyxl

from base_validator import BaseValidator
from utils import get_project_root, setup_logging


# Expected tabs in the STTM workbook
REQUIRED_TABS = [
    "Index",
    "Version History",
    "Common Rules",
    "Dependency Details",
    "Lookup_Definitions",
]

# Expected column headers in the STTM mapping tab (row 6)
EXPECTED_MAPPING_HEADERS = [
    "Subject Area",
    "Target Table",
    "Target Column Name",
    "Business Definition",
    "Target Data Type",
    "Target Nullability",
    "Source Table Name",
    "Source Column Name",
    "Source Column Type",
    "Source Transformational Rule/Logic",
]

# Header-only tabs: these should have headers in row 1 but can be blank otherwise
HEADER_ONLY_TABS = ["Index", "Version History", "Dependency Details"]

# Headers expected per tab
TAB_HEADERS = {
    "Index": ["#", "Index", "Table Load Type"],
    "Version History": ["Sno", "Version"],
    "Dependency Details": ["Sno", "Table name", "Target Schema Name"],
    "Lookup_Definitions": ["#", "Lookup Name"],
}


class STTMValidator(BaseValidator):
    """Validates a generated STTM Excel workbook."""

    def __init__(self, sttm_path: str, target_dir: str = "output"):
        super().__init__(target_dir=target_dir)
        self.sttm_path = Path(sttm_path)

    def validate(self) -> List[Dict[str, str]]:
        issues: List[Dict[str, str]] = []

        # 1. Check file exists
        issues.extend(self._check_file_exists())
        if any(i["severity"] == "ERROR" for i in issues):
            return issues  # can't continue if file missing

        # 2. Load workbook
        try:
            wb = openpyxl.load_workbook(str(self.sttm_path), data_only=True)
        except Exception as e:
            issues.append({
                "severity": "ERROR",
                "file": str(self.sttm_path),
                "message": f"Cannot open Excel file: {e}",
                "suggestion": "Ensure the file is a valid .xlsx workbook",
            })
            return issues

        sheet_names = wb.sheetnames
        self.logger.info(f"Tabs found: {sheet_names}")

        # 3. Check required tabs
        issues.extend(self._check_required_tabs(sheet_names))

        # 4. Check header-only tabs
        issues.extend(self._check_header_tabs(wb, sheet_names))

        # 5. Check Lookup_Definitions tab
        issues.extend(self._check_lookup_tab(wb, sheet_names))

        # 6. Find and check the STTM mapping tab (last tab, or the one not in REQUIRED_TABS)
        sttm_tab_name = self._find_sttm_tab(sheet_names)
        if sttm_tab_name:
            issues.extend(self._check_sttm_tab(wb[sttm_tab_name], sttm_tab_name))
        else:
            issues.append({
                "severity": "ERROR",
                "file": str(self.sttm_path),
                "message": "No STTM mapping tab found (expected a tab beyond the standard tabs)",
                "suggestion": "Ensure the generator creates a mapping tab named after the target table",
            })

        # 7. Check summary file exists
        issues.extend(self._check_summary_file())

        wb.close()
        return issues

    def _check_file_exists(self) -> List[Dict[str, str]]:
        return self.check_files_exist([str(self.sttm_path)])

    def _check_required_tabs(self, sheet_names: List[str]) -> List[Dict[str, str]]:
        issues = []
        for tab in REQUIRED_TABS:
            if tab not in sheet_names:
                issues.append({
                    "severity": "ERROR",
                    "file": str(self.sttm_path),
                    "message": f"Missing required tab: '{tab}'",
                    "suggestion": f"Add the '{tab}' tab to the workbook",
                })
            else:
                issues.append({
                    "severity": "INFO",
                    "file": str(self.sttm_path),
                    "message": f"Tab present: '{tab}'",
                    "suggestion": "",
                })
        return issues

    def _check_header_tabs(self, wb, sheet_names: List[str]) -> List[Dict[str, str]]:
        issues = []
        for tab_name in HEADER_ONLY_TABS:
            if tab_name not in sheet_names:
                continue
            ws = wb[tab_name]
            expected = TAB_HEADERS.get(tab_name, [])
            for col_idx, expected_header in enumerate(expected, 1):
                actual = ws.cell(row=1, column=col_idx).value
                if actual is None or expected_header.lower() not in str(actual).lower():
                    issues.append({
                        "severity": "WARNING",
                        "file": str(self.sttm_path),
                        "message": f"Tab '{tab_name}' col {col_idx}: expected header containing '{expected_header}', got '{actual}'",
                        "suggestion": f"Check header row in '{tab_name}' tab",
                    })
        return issues

    def _check_lookup_tab(self, wb, sheet_names: List[str]) -> List[Dict[str, str]]:
        issues = []
        if "Lookup_Definitions" not in sheet_names:
            return issues
        ws = wb["Lookup_Definitions"]
        # Check headers exist
        expected = TAB_HEADERS.get("Lookup_Definitions", [])
        for col_idx, expected_header in enumerate(expected, 1):
            actual = ws.cell(row=1, column=col_idx).value
            if actual is None or expected_header.lower() not in str(actual).lower():
                issues.append({
                    "severity": "WARNING",
                    "file": str(self.sttm_path),
                    "message": f"Lookup_Definitions header col {col_idx}: expected '{expected_header}', got '{actual}'",
                    "suggestion": "Check Lookup_Definitions header row",
                })

        # Check at least one data row
        row2_val = ws.cell(row=2, column=2).value
        if row2_val is None:
            issues.append({
                "severity": "WARNING",
                "file": str(self.sttm_path),
                "message": "Lookup_Definitions tab has no data rows",
                "suggestion": "Ensure lookup definitions are populated if lookups exist in the job",
            })
        else:
            # Count rows
            data_rows = 0
            for row in range(2, ws.max_row + 1):
                if ws.cell(row=row, column=2).value is not None:
                    data_rows += 1
            issues.append({
                "severity": "INFO",
                "file": str(self.sttm_path),
                "message": f"Lookup_Definitions tab has {data_rows} lookup(s) defined",
                "suggestion": "",
            })
        return issues

    def _find_sttm_tab(self, sheet_names: List[str]) -> str:
        """Find the STTM mapping tab (the one that isn't a standard tab)."""
        standard = set(REQUIRED_TABS + ["Common Rules"])
        for name in sheet_names:
            if name not in standard:
                return name
        return ""

    def _check_sttm_tab(self, ws, tab_name: str) -> List[Dict[str, str]]:
        issues = []

        # Check Row 2: Target Table Name label
        a2 = ws.cell(row=2, column=1).value
        if a2 is None or "target table" not in str(a2).lower():
            issues.append({
                "severity": "WARNING",
                "file": str(self.sttm_path),
                "message": f"STTM tab '{tab_name}' row 2 col A: expected 'Target Table Name', got '{a2}'",
                "suggestion": "Check metadata header in STTM tab",
            })

        # Check Row 2: Target Schema Name
        c2 = ws.cell(row=2, column=3).value
        if c2 is None or "schema" not in str(c2).lower():
            issues.append({
                "severity": "WARNING",
                "file": str(self.sttm_path),
                "message": f"STTM tab '{tab_name}' row 2 col C: expected 'Target Schema Name', got '{c2}'",
                "suggestion": "Check metadata header in STTM tab",
            })

        # Check Row 2 col D: schema value should not be empty
        d2 = ws.cell(row=2, column=4).value
        if d2 is not None:
            issues.append({
                "severity": "INFO",
                "file": str(self.sttm_path),
                "message": f"Target Schema Name: '{d2}'",
                "suggestion": "",
            })

        # Check Row 6: mapping column headers
        for col_idx, expected in enumerate(EXPECTED_MAPPING_HEADERS, 1):
            actual = ws.cell(row=6, column=col_idx).value
            if actual is None or expected.lower() not in str(actual).lower():
                issues.append({
                    "severity": "ERROR",
                    "file": str(self.sttm_path),
                    "message": f"STTM tab header row 6 col {col_idx}: expected '{expected}', got '{actual}'",
                    "suggestion": "Ensure mapping column headers match reference format",
                })

        # Count data rows (row 7+)
        data_rows = 0
        empty_target_cols = []
        for row in range(7, ws.max_row + 1):
            target_col = ws.cell(row=row, column=3).value
            if target_col is not None:
                data_rows += 1
            target_table = ws.cell(row=row, column=2).value
            if target_table is not None and target_col is None:
                empty_target_cols.append(row)

        if data_rows == 0:
            issues.append({
                "severity": "ERROR",
                "file": str(self.sttm_path),
                "message": f"STTM tab '{tab_name}' has no data rows",
                "suggestion": "Ensure the generator produces mapping rows",
            })
        else:
            issues.append({
                "severity": "INFO",
                "file": str(self.sttm_path),
                "message": f"STTM tab '{tab_name}' has {data_rows} mapping row(s) (including SK)",
                "suggestion": "",
            })

        if empty_target_cols:
            issues.append({
                "severity": "WARNING",
                "file": str(self.sttm_path),
                "message": f"Empty 'Target Column Name' in rows: {empty_target_cols}",
                "suggestion": "All mapping rows should have a target column name",
            })

        # Check transformation rules are not empty
        empty_rules = []
        for row in range(7, ws.max_row + 1):
            target_col = ws.cell(row=row, column=3).value
            rule = ws.cell(row=row, column=10).value
            if target_col is not None and (rule is None or str(rule).strip() == ""):
                empty_rules.append(f"Row {row}: {target_col}")

        if empty_rules:
            issues.append({
                "severity": "WARNING",
                "file": str(self.sttm_path),
                "message": f"Empty transformation rules for: {', '.join(empty_rules[:5])}",
                "suggestion": "All columns should have a transformation rule or 'Direct Move'",
            })

        # Check that source table name column uses table_name only (not schema.table)
        schema_in_mapping = []
        for row in range(7, ws.max_row + 1):
            src_table = ws.cell(row=row, column=7).value
            if src_table and "." in str(src_table) and "Lookup" not in str(src_table):
                schema_in_mapping.append(f"Row {row}: {src_table}")

        if schema_in_mapping:
            issues.append({
                "severity": "WARNING",
                "file": str(self.sttm_path),
                "message": f"Source table has schema prefix in mapping rows: {', '.join(schema_in_mapping[:3])}",
                "suggestion": "Per requirements, use only table_name in mappings, schema goes in header",
            })

        return issues

    def _check_summary_file(self) -> List[Dict[str, str]]:
        issues = []
        summary_files = list(Path(self.target_dir).glob("*_summary.md"))
        if summary_files:
            issues.append({
                "severity": "INFO",
                "file": str(summary_files[0]),
                "message": f"Summary file found: {summary_files[0].name}",
                "suggestion": "",
            })
        else:
            issues.append({
                "severity": "WARNING",
                "file": str(self.target_dir),
                "message": "No summary file (*_summary.md) found in output directory",
                "suggestion": "Generate summary file alongside STTM",
            })
        return issues


def find_sttm_file(output_dir: Path) -> Path:
    """Find the STTM Excel file in the output directory."""
    xlsx_files = list(output_dir.glob("*_sttm.xlsx"))
    if xlsx_files:
        return xlsx_files[0]
    # Fallback: any xlsx
    xlsx_files = list(output_dir.glob("*.xlsx"))
    if xlsx_files:
        return xlsx_files[0]
    return output_dir / "mtsXtrcWrkTB_sttm.xlsx"


def main() -> None:
    arg_parser = argparse.ArgumentParser(description="Validate STTM Excel output")
    arg_parser.add_argument("--file", help="Path to STTM Excel file to validate")
    arg_parser.add_argument("--output", default="output", help="Output directory (default: output)")
    args = arg_parser.parse_args()

    root = get_project_root()
    output_dir = root / args.output

    if args.file:
        _file_parts = args.file.replace('\\', '/').split('/')
        if '..' in _file_parts:
            print(f"ERROR: Path traversal sequence detected in file path: {args.file}")
            sys.exit(1)
        sttm_path = Path(args.file).resolve()
        allowed_dir = output_dir.resolve()
        if not str(sttm_path).startswith(str(allowed_dir) + "/"):
            print(f"ERROR: Path traversal blocked: file must be under output/, got {args.file}")
            sys.exit(1)
    else:
        sttm_path = find_sttm_file(output_dir)

    logger = setup_logging("STTMValidator")
    logger.info(f"Validating: {sttm_path}")

    validator = STTMValidator(
        sttm_path=str(sttm_path),
        target_dir=str(output_dir),
    )
    issues = validator.validate()
    report = validator.report(issues)

    # Print summary
    summary = report["validation_report"]["summary"]
    print()
    print("=" * 60)
    print(f"  VALIDATION {'PASSED' if summary['passed'] else 'FAILED'}")
    print(f"  Errors: {summary['errors']}  |  Warnings: {summary['warnings']}  |  Info: {summary['info']}")
    print("=" * 60)

    if not summary["passed"]:
        print("\nErrors:")
        for issue in issues:
            if issue["severity"] == "ERROR":
                print(f"  [ERROR] {issue['message']}")
                if issue.get("suggestion"):
                    print(f"          -> {issue['suggestion']}")

    if summary["warnings"] > 0:
        print("\nWarnings:")
        for issue in issues:
            if issue["severity"] == "WARNING":
                print(f"  [WARN]  {issue['message']}")

    print()
    sys.exit(0 if summary["passed"] else 1)


if __name__ == "__main__":
    main()
