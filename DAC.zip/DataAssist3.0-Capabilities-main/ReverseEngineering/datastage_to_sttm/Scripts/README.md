# STTM Generator -- DataStage XML to Source-to-Target Mapping

## What It Does

This tool reverse engineers IBM DataStage job export XML files into Source-to-Target Mapping (STTM) Excel workbooks. It solves the problem of manually documenting complex ETL pipelines by automatically extracting column-level mappings, transformation rules, lookup definitions, job flow, and job variables from DataStage XML exports and producing production-ready STTM `.xlsx` files.

### Problem It Solves

Manually creating STTM documentation for DataStage jobs is time-consuming and error-prone. Each job can contain dozens of stages, hundreds of columns, and complex transformation logic buried in XML. This tool automates the entire process: parse the XML, trace data lineage through the full stage chain (Source -> PxJoin -> PxLookup -> Transformer -> Target), and produce a formatted Excel workbook that matches your organization's STTM standard.

### Generated STTM Structure

Each output workbook contains these tabs:

| Tab | Description |
|-----|-------------|
| **Index** | Table index with load type |
| **Version History** | Change tracking |
| **\<TABLE_NAME\>** | Full column-level STTM mappings with transformation rules |
| **Job_Flow** | Ordered data flow from sources through lookups to target |
| **Lookup_Definitions** | All PxLookup, PxJoin, CTE, and source stage lookups |
| **Job_Variables** | DataStage job parameters and connection sub-parameters |
| **Dependency Details** | Table dependencies |
| **Common Rules** | Standard ETL null-handling rules |

---

## Setup and Installation

### Prerequisites

- **Python 3.8+**
- **pip** (Python package manager)

### Step 1: Install Dependencies

```bash
pip install -r requirements.txt
```

### Step 2: Place Your Input Files

Put your DataStage XML export files in the `input/` directory:

```
input/
  DwhToLimraPartyIns.xml
  DwhToLimraCoverageIns.xml
  ...
```

### Step 3: Place Reference Files (Optional)

If you have a reference STTM format workbook, place it in `knowledgebase/`:

```
knowledgebase/
  cdsaisf_awf_sttm_v1.0.xlsx
```

---

## Usage

All commands are run via the `cli.py` entry point:

```bash
python cli.py <command> [options]
```

### Available Commands

#### Generate STTM from XML

```bash
# Process all XML files in input/
python cli.py generate

# Process a specific XML file
python cli.py generate --xml input/DwhToLimraPartyIns.xml
```

#### Validate a Generated STTM

```bash
# Auto-detect STTM file in output/
python cli.py validate

# Validate a specific file
python cli.py validate --file output/DwhToLimraPartyIns_sttm.xlsx
```

#### Run Accuracy Report

Compare generated STTMs against source XML for completeness:

```bash
python cli.py accuracy
```

This checks column coverage, lookup coverage, transformation quality, job flow, and job variables.

#### Build All

Discover and run all `generate_*.py` scripts:

```bash
python cli.py build
```

#### Refine Output

Run the automated refinement loop to patch STTM output based on validation errors:

```bash
# Basic refinement (max 3 iterations)
python cli.py refine

# With human feedback and custom iteration limit
python cli.py refine --feedback feedback.txt --max-iterations 5
```

---

## Folder Structure

```
Scripts/sttm-generator/
  cli.py                 # Single entry point for all commands
  generate_sttm.py       # Core STTM generator (DataStage XML parser + Excel writer)
  accuracy_report.py     # Compares STTM output against source XML
  validator.py           # Validates STTM structure and content
  refiner.py             # Patches output based on validation errors
  build_all.py           # Discovers and runs all generators
  base_parser.py         # Abstract base class for parsers
  base_generator.py      # Abstract base class for generators
  base_validator.py      # Abstract base class for validators
  utils.py               # Shared utilities (logging, YAML I/O, path helpers)
  prompts.py             # Centralized prompts for agentic validation layer
  __init__.py            # Package init
  requirements.txt       # Python dependencies
  README.md              # This file
  input/                 # DataStage XML export files (your source data)
  output/                # Generated STTM Excel workbooks
  knowledgebase/         # Reference STTM format and standards
  plans/                 # Build plans (YAML)
```

---

## Assumptions and Limitations

### Assumptions

- Input files are valid IBM DataStage DSExport XML files
- XML files contain a single `<Job>` element with `Record`, `Collection`, and `Property` elements following the DataStage export schema
- Target columns are derived by tracing the stage chain from Transformer output (or the last stage before Target) to the Target stage input pins
- The reference STTM format in `knowledgebase/cdsaisf_awf_sttm_v1.0.xlsx` defines the expected tab structure, column headers, and styling

### Known Limitations

- **Single job per XML**: Each XML file is expected to contain one DataStage job. Multi-job exports are not supported.
- **Transformation rule decomposition**: Complex SQL expressions in Transformer stage derivations are extracted as-is. Deeply nested CASE statements or multi-level function calls may not be fully decomposed into per-column rules.
- **Refiner patches are flagged for review**: The refiner identifies issues and logs them, but automated Excel cell patching requires exact cell coordinates. Issues are flagged for human review rather than auto-applied.
- **No interactive mode**: All commands are non-interactive. Human feedback for the refiner must be provided via a text file.

### Environment Requirements

- **OS**: Linux, macOS, or Windows
- **Python**: 3.8 or higher
- **Disk**: Sufficient space for output Excel files (typically a few MB per job)
- **No network access required**: All processing is local
