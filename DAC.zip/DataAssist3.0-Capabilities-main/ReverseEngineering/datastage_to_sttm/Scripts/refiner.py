"""
STTM Refiner - Patches output STTM Excel files based on validation errors.

Implements the Layer 2 agentic refinement loop:
1. Read validation report (from validator.py or accuracy_report.py)
2. Optionally read human feedback
3. Validate feedback before accepting
4. Apply targeted patches to output/ files ONLY
5. Re-run validation after patching
6. Loop up to max iterations (default: 3)

Guardrails enforced (from GUARDRAILS.yaml):
- Output-only writes: never writes outside output/
- No script modification: never modifies scripts/
- No input/knowledge mutation: never writes to inputs/ or knowledgebase/
- Scope limit: only changes content related to the specific issue
- Diff size cap: flags fixes > 50 lines for human review
- Max iterations: default 3, configurable
- Accuracy regression check: stops on regression
- Stale loop detection: skips issues that fail twice in a row

Usage:
    python scripts/refiner.py
    python scripts/refiner.py --report output/accuracy_report.txt
    python scripts/refiner.py --feedback feedback.txt --max-iterations 5
"""

import argparse
import re
import sys
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import openpyxl
import yaml

from prompts import (
    FEEDBACK_VALIDATION_PROMPT,
    REFINER_PATCH_PROMPT,
    REFINER_SYSTEM_PROMPT,
)
from utils import get_project_root, get_timestamp, save_yaml, setup_logging

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------
MAX_LINES_PER_FIX = 50
DEFAULT_MAX_ITERATIONS = 3
OUTPUT_DIR_NAME = "output"
LOG_DIR_NAME = "thoughts/logs/agentic"

# Directories that MUST NOT be written to
IMMUTABLE_DIRS = {"inputs", "input", "knowledgebase", "scripts", "plans", "research"}


class STTMRefiner:
    """Refines STTM output files based on validation issues."""

    def __init__(
        self,
        root: Path,
        max_iterations: int = DEFAULT_MAX_ITERATIONS,
        feedback_path: Optional[Path] = None,
    ) -> None:
        self.root = Path(root)
        self.output_dir = self.root / OUTPUT_DIR_NAME
        self.log_dir = self.root / LOG_DIR_NAME
        self.log_dir.mkdir(parents=True, exist_ok=True)
        self.max_iterations = max_iterations
        self.feedback_path = feedback_path
        self.logger = setup_logging("STTMRefiner", log_dir=self.log_dir)
        self.iteration_history: List[Dict[str, Any]] = []

    # ------------------------------------------------------------------
    # Guardrail: ensure we only write to output/
    # ------------------------------------------------------------------
    def _assert_output_path(self, path: Path) -> None:
        """Raise if path is not inside output/ directory."""
        resolved = Path(path).resolve()
        output_resolved = self.output_dir.resolve()
        if not str(resolved).startswith(str(output_resolved)):
            raise PermissionError(
                f"GUARDRAIL VIOLATION: Attempted write outside output/: {path}"
            )

    # ------------------------------------------------------------------
    # Parse validation report
    # ------------------------------------------------------------------
    def parse_accuracy_report(self, report_path: Path) -> Dict[str, Any]:
        """Parse the accuracy_report.txt produced by accuracy_report.py."""
        report: Dict[str, Any] = {
            "overall_accuracy": 0.0,
            "jobs": {},
            "issues": [],
            "passed_checks": [],
        }
        if not report_path.exists():
            self.logger.error(f"Report not found: {report_path}")
            return report

        text = report_path.read_text(encoding="utf-8")
        current_job = ""
        issue_id = 0

        for line in text.splitlines():
            line = line.strip()
            # Parse job header
            job_match = re.match(r"Job:\s+(\S+)", line)
            if job_match:
                current_job = job_match.group(1)
                report["jobs"][current_job] = {"checks": [], "issues": []}
                continue

            # Parse check results (format: "[PASS] Check Name     Description text")
            pass_match = re.match(r"\[PASS\]\s+(.+?)\s{2,}(.*)", line)
            if pass_match and current_job:
                check = {"job": current_job, "check": pass_match.group(1).strip(), "detail": pass_match.group(2).strip()}
                report["passed_checks"].append(check)
                report["jobs"][current_job]["checks"].append({"status": "PASS", **check})
                continue

            warn_match = re.match(r"\[WARN\]\s+(.+?)\s{2,}(.*)", line)
            if warn_match and current_job:
                issue_id += 1
                issue = {
                    "id": f"V-{issue_id:03d}",
                    "job": current_job,
                    "severity": "medium",
                    "category": warn_match.group(1).strip(),
                    "description": warn_match.group(2).strip(),
                    "source_file": f"inputs/{current_job}.xml",
                    "output_file": f"output/{current_job}_sttm.xlsx",
                    "status": "open",
                    "attempts": 0,
                }
                report["issues"].append(issue)
                report["jobs"][current_job]["issues"].append(issue)
                continue

            fail_match = re.match(r"\[FAIL\]\s+(.+?)\s{2,}(.*)", line)
            if fail_match and current_job:
                issue_id += 1
                issue = {
                    "id": f"V-{issue_id:03d}",
                    "job": current_job,
                    "severity": "high",
                    "category": fail_match.group(1).strip(),
                    "description": fail_match.group(2).strip(),
                    "source_file": f"inputs/{current_job}.xml",
                    "output_file": f"output/{current_job}_sttm.xlsx",
                    "status": "open",
                    "attempts": 0,
                }
                report["issues"].append(issue)
                report["jobs"][current_job]["issues"].append(issue)
                continue

            # Parse overall accuracy (format: "OVERALL: 100.0% accuracy ..." or "Accuracy score: 100.0%")
            acc_match = re.search(r"([\d.]+)%\s*accuracy", line) or re.match(r"Accuracy score:\s+([\d.]+)%", line)
            if acc_match:
                report["overall_accuracy"] = float(acc_match.group(1))

        return report

    # ------------------------------------------------------------------
    # Feedback validation
    # ------------------------------------------------------------------
    def validate_feedback(self, feedback_text: str, report: Dict[str, Any]) -> Dict[str, Any]:
        """Validate human feedback against guardrails."""
        result: Dict[str, Any] = {
            "timestamp": get_timestamp(),
            "feedback_raw": feedback_text,
            "checks": [],
            "accepted": [],
            "rejected": [],
        }

        # Split feedback into individual items (one per line)
        items = [line.strip() for line in feedback_text.splitlines() if line.strip()]

        for item in items:
            checks: Dict[str, Any] = {"item": item, "relevance": "PASS", "actionability": "PASS", "consistency": "PASS"}

            # Relevance check: does it reference known issues or output files?
            issue_ids = [iss["id"] for iss in report.get("issues", [])]
            output_files = [f.name for f in self.output_dir.glob("*.xlsx")]
            is_relevant = (
                any(iid in item for iid in issue_ids)
                or any(of in item for of in output_files)
                or any(kw in item.lower() for kw in ["column", "mapping", "lookup", "transformation", "source table", "job flow", "job variable"])
            )
            if not is_relevant:
                checks["relevance"] = "FAIL"
                checks["relevance_reason"] = "Feedback does not reference known issues or output files"

            # Actionability check: can it be applied as an output patch?
            non_actionable_keywords = ["refactor script", "change architecture", "modify generate_sttm", "update scripts/"]
            if any(kw in item.lower() for kw in non_actionable_keywords):
                checks["actionability"] = "FAIL"
                checks["actionability_reason"] = "Feedback requires script changes, not output patches"

            # Source consistency check: does it contradict source data?
            contradiction_keywords = ["ignore source", "override xml", "remove from source"]
            if any(kw in item.lower() for kw in contradiction_keywords):
                checks["consistency"] = "FAIL"
                checks["consistency_reason"] = "Feedback contradicts source data"

            result["checks"].append(checks)

            if all(checks[k] == "PASS" for k in ["relevance", "actionability", "consistency"]):
                result["accepted"].append(item)
            else:
                result["rejected"].append({
                    "item": item,
                    "reasons": {k: checks.get(f"{k}_reason", "") for k in ["relevance", "actionability", "consistency"] if checks[k] == "FAIL"},
                })

        return result

    # ------------------------------------------------------------------
    # Apply patches (rule-based for STTM issues)
    # ------------------------------------------------------------------
    def apply_patches(
        self,
        issues: List[Dict[str, Any]],
        feedback_items: List[str],
    ) -> List[Dict[str, Any]]:
        """Apply patches for identified issues. Returns list of patch results."""
        patch_results: List[Dict[str, Any]] = []

        for issue in issues:
            if issue.get("status") == "resolved":
                continue
            if issue.get("attempts", 0) >= 2 and issue.get("last_result") == "no_improvement":
                # Stale loop detection: skip issues that failed twice
                issue["status"] = "unresolved_stale"
                self.logger.warning(f"Skipping stale issue {issue['id']}: no improvement in 2 attempts")
                patch_results.append({
                    "issue_id": issue["id"],
                    "action": "skipped_stale",
                    "description": "Issue failed to improve in 2 consecutive iterations",
                })
                continue

            output_path = self.root / issue.get("output_file", "")
            if not output_path.exists():
                patch_results.append({
                    "issue_id": issue["id"],
                    "action": "skipped",
                    "description": f"Output file not found: {output_path}",
                })
                continue

            # Guardrail: ensure output-only write
            try:
                self._assert_output_path(output_path)
            except PermissionError as e:
                patch_results.append({
                    "issue_id": issue["id"],
                    "action": "blocked",
                    "description": str(e),
                })
                continue

            # For this STTM use case, patches are rule-based corrections
            # to the Excel output. The current implementation logs issues
            # for human review since automated Excel cell patching requires
            # knowing the exact cell coordinates.
            issue["attempts"] = issue.get("attempts", 0) + 1
            patch_results.append({
                "issue_id": issue["id"],
                "action": "flagged_for_review",
                "output_file": str(output_path),
                "description": issue.get("description", ""),
                "source_reference": issue.get("source_file", ""),
                "suggestion": f"Review {issue.get('category', '')} in {output_path.name}",
            })

        return patch_results

    # ------------------------------------------------------------------
    # Run one iteration
    # ------------------------------------------------------------------
    def run_iteration(
        self,
        iteration: int,
        report: Dict[str, Any],
        feedback_items: List[str],
    ) -> Dict[str, Any]:
        """Run a single refinement iteration."""
        self.logger.info(f"--- Iteration {iteration} ---")

        open_issues = [i for i in report["issues"] if i.get("status") == "open"]
        if not open_issues:
            self.logger.info("No open issues to fix.")
            return {
                "iteration": iteration,
                "timestamp": get_timestamp(),
                "issues_attempted": 0,
                "patches": [],
                "accuracy_before": report.get("overall_accuracy", 0.0),
                "accuracy_after": report.get("overall_accuracy", 0.0),
            }

        # Apply patches
        patches = self.apply_patches(open_issues, feedback_items)

        # Re-run accuracy check (import accuracy_report module)
        accuracy_after = report.get("overall_accuracy", 0.0)
        try:
            from accuracy_report import main as run_accuracy
            # Re-run accuracy report to get updated score
            run_accuracy()
            new_report_path = self.output_dir / "accuracy_report.txt"
            if new_report_path.exists():
                new_report = self.parse_accuracy_report(new_report_path)
                accuracy_after = new_report.get("overall_accuracy", accuracy_after)
        except Exception as e:
            self.logger.warning(f"Could not re-run accuracy report: {e}")

        iteration_result = {
            "iteration": iteration,
            "timestamp": get_timestamp(),
            "issues_attempted": len(open_issues),
            "patches": patches,
            "accuracy_before": report.get("overall_accuracy", 0.0),
            "accuracy_after": accuracy_after,
            "feedback_applied": feedback_items if feedback_items else [],
        }

        # Save iteration log
        log_file = self.log_dir / f"iteration_{iteration}_refiner.yaml"
        save_yaml(iteration_result, log_file)
        self.logger.info(f"Iteration {iteration} log saved to {log_file}")

        return iteration_result

    # ------------------------------------------------------------------
    # Main refinement loop
    # ------------------------------------------------------------------
    def run(self) -> Dict[str, Any]:
        """Run the full refinement loop."""
        self.logger.info("=" * 60)
        self.logger.info("STTM Refiner - Starting")
        self.logger.info(f"Max iterations: {self.max_iterations}")
        self.logger.info("=" * 60)

        # Step 1: Parse validation report
        report_path = self.output_dir / "accuracy_report.txt"
        if not report_path.exists():
            self.logger.error(f"No accuracy report found at {report_path}")
            self.logger.info("Run: python scripts/accuracy_report.py first")
            return {"status": "error", "message": "No accuracy report found"}

        report = self.parse_accuracy_report(report_path)
        initial_accuracy = report.get("overall_accuracy", 0.0)
        self.logger.info(f"Initial accuracy: {initial_accuracy}%")
        self.logger.info(f"Open issues: {len(report.get('issues', []))}")

        # Step 2: Load and validate human feedback (if provided)
        feedback_items: List[str] = []
        if self.feedback_path and self.feedback_path.exists():
            feedback_text = self.feedback_path.read_text(encoding="utf-8")
            self.logger.info(f"Human feedback loaded from {self.feedback_path}")

            fb_validation = self.validate_feedback(feedback_text, report)
            feedback_items = fb_validation.get("accepted", [])

            # Save feedback validation log
            fb_log = self.log_dir / "feedback_validation.yaml"
            save_yaml(fb_validation, fb_log)

            if fb_validation.get("rejected"):
                self.logger.warning(
                    f"Rejected {len(fb_validation['rejected'])} feedback items "
                    f"(see {fb_log} for details)"
                )
            self.logger.info(f"Accepted feedback items: {len(feedback_items)}")

        # Step 3: Check if there's anything to fix
        if not report.get("issues") and not feedback_items:
            self.logger.info("No issues to fix and no feedback provided. Output is clean.")
            return {
                "status": "clean",
                "initial_accuracy": initial_accuracy,
                "final_accuracy": initial_accuracy,
                "iterations_run": 0,
                "message": "No issues found — output accepted as-is",
            }

        # Step 4: Refinement loop
        previous_accuracy = initial_accuracy
        for iteration in range(1, self.max_iterations + 1):
            result = self.run_iteration(iteration, report, feedback_items)
            self.iteration_history.append(result)

            current_accuracy = result.get("accuracy_after", previous_accuracy)

            # Exit condition: accuracy regression
            if current_accuracy < previous_accuracy:
                self.logger.warning(
                    f"Accuracy regression detected: {previous_accuracy}% -> {current_accuracy}%. "
                    "Stopping loop."
                )
                break

            # Exit condition: all issues resolved
            open_issues = [i for i in report["issues"] if i.get("status") == "open"]
            if not open_issues:
                self.logger.info("All issues resolved.")
                break

            # Exit condition: no improvement (stale)
            if current_accuracy == previous_accuracy and iteration > 1:
                stale_count = sum(
                    1 for i in report["issues"]
                    if i.get("status") == "unresolved_stale"
                )
                if stale_count == len([i for i in report["issues"] if i.get("status") != "resolved"]):
                    self.logger.warning("All remaining issues are stale. Stopping loop.")
                    break

            previous_accuracy = current_accuracy

        # Step 5: Save progression report
        final_accuracy = self.iteration_history[-1].get("accuracy_after", initial_accuracy) if self.iteration_history else initial_accuracy
        progression = {
            "run_id": f"run_{datetime.now().strftime('%Y%m%d_%H%M%S')}",
            "initial_accuracy": initial_accuracy,
            "final_accuracy": final_accuracy,
            "iterations_run": len(self.iteration_history),
            "max_iterations": self.max_iterations,
            "progression": [
                {
                    "iteration": h["iteration"],
                    "accuracy": h.get("accuracy_after", 0.0),
                    "issues_attempted": h.get("issues_attempted", 0),
                }
                for h in self.iteration_history
            ],
            "trend": (
                "improving" if final_accuracy > initial_accuracy
                else "stable" if final_accuracy == initial_accuracy
                else "regressing"
            ),
        }
        save_yaml(progression, self.log_dir / "accuracy_progression.yaml")

        # Step 6: Save run summary
        summary = {
            "status": "complete",
            "initial_accuracy": initial_accuracy,
            "final_accuracy": final_accuracy,
            "iterations_run": len(self.iteration_history),
            "issues_total": len(report.get("issues", [])),
            "issues_resolved": sum(1 for i in report.get("issues", []) if i.get("status") == "resolved"),
            "issues_stale": sum(1 for i in report.get("issues", []) if i.get("status") == "unresolved_stale"),
            "issues_open": sum(1 for i in report.get("issues", []) if i.get("status") == "open"),
            "feedback_accepted": len(feedback_items),
            "message": "Refinement loop complete. Review results in thoughts/logs/agentic/",
        }
        save_yaml(summary, self.log_dir / "run_summary.yaml")

        # Print summary
        print()
        print("=" * 60)
        print(f"  REFINEMENT COMPLETE")
        print(f"  Initial accuracy: {initial_accuracy}%")
        print(f"  Final accuracy:   {final_accuracy}%")
        print(f"  Iterations run:   {len(self.iteration_history)}")
        print(f"  Issues total:     {summary['issues_total']}")
        print(f"  Issues resolved:  {summary['issues_resolved']}")
        print(f"  Issues remaining: {summary['issues_open'] + summary['issues_stale']}")
        print("=" * 60)
        print()

        return summary


# ============================================================================
# CLI Entry Point
# ============================================================================
def main() -> None:
    """Run the STTM refinement loop."""
    arg_parser = argparse.ArgumentParser(description="STTM Refiner - patch output based on validation")
    arg_parser.add_argument("--report", help="Path to accuracy report (default: output/accuracy_report.txt)")
    arg_parser.add_argument("--feedback", help="Path to human feedback file")
    arg_parser.add_argument("--max-iterations", type=int, default=DEFAULT_MAX_ITERATIONS,
                            help=f"Max refinement iterations (default: {DEFAULT_MAX_ITERATIONS})")
    args = arg_parser.parse_args()

    root = get_project_root()

    feedback_path = None
    if args.feedback:
        feedback_path = (root / args.feedback).resolve()
        if not feedback_path.is_relative_to(root.resolve()):
            print(f"ERROR: Path traversal blocked: feedback file must be under project root, got {args.feedback}")
            sys.exit(1)

    refiner = STTMRefiner(
        root=root,
        max_iterations=args.max_iterations,
        feedback_path=feedback_path,
    )
    result = refiner.run()

    if result.get("status") == "error":
        sys.exit(1)


if __name__ == "__main__":
    main()
