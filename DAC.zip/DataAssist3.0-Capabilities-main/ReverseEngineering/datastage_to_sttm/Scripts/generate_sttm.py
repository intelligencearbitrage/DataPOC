"""
STTM Generator - Generates Source-to-Target Mapping Excel from DataStage XML.

Parses a DataStage job export XML, extracts stages, columns, derivations,
and produces an STTM workbook matching the reference format from
knowledgebase/cdsaisf_awf_sttm_v1.0.xlsx.

Usage:
    python scripts/generate_sttm.py
    python scripts/generate_sttm.py --xml knowledgebase/my_job.xml
"""

import argparse
import re
import defusedxml.ElementTree as ET
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import openpyxl
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter

from base_generator import BaseGenerator
from utils import get_project_root, load_yaml, save_yaml, setup_logging


# ---------------------------------------------------------------------------
# DataStage SqlType code -> human-readable type name
# ---------------------------------------------------------------------------
SQL_TYPE_MAP: Dict[int, str] = {
    1: "CHAR",
    2: "NUMERIC",
    3: "DECIMAL",
    4: "INTEGER",
    5: "SMALLINT",
    8: "FLOAT",
    9: "DATE",
    11: "TIMESTAMP",
    12: "VARCHAR",
    -1: "LONGVARCHAR",
    -5: "BIGINT",
    91: "DATE",
    93: "TIMESTAMP",
}


# ---------------------------------------------------------------------------
# Style constants matching reference STTM (cdsaisf_awf_sttm_v1.0.xlsx)
# ---------------------------------------------------------------------------
HEADER_FILL = PatternFill(start_color="B4C6E7", end_color="B4C6E7", fill_type="solid")
META_FILL = PatternFill(start_color="FFE699", end_color="FFE699", fill_type="solid")
WHITE_FILL = PatternFill(start_color="FFFFFF", end_color="FFFFFF", fill_type="solid")
NK_FILL = PatternFill(start_color="F2F2F2", end_color="F2F2F2", fill_type="solid")

BOLD_FONT = Font(name="Calibri", size=9, bold=True)
NORMAL_FONT = Font(name="Calibri", size=9)
LINK_FONT = Font(name="Calibri", size=9, bold=True, color="0563C1")
RED_FONT = Font(name="Calibri", size=9, bold=True, color="FF0000")
BLUE_FONT = Font(name="Calibri", size=9, bold=True, color="0066FF")

THIN_BORDER = Border(
    left=Side(style="thin"),
    right=Side(style="thin"),
    top=Side(style="thin"),
    bottom=Side(style="thin"),
)
LEFT_WRAP = Alignment(horizontal="left", vertical="top", wrap_text=True)
CENTER_WRAP = Alignment(horizontal="center", vertical="center", wrap_text=True)


# ============================================================================
# DataStage XML Parser
# ============================================================================
class DataStageParser:
    """Parses a DataStage DSExport XML file and extracts job metadata."""

    def __init__(self, xml_path: Path) -> None:
        _root = get_project_root()
        _candidate = (_root / str(xml_path)).resolve()
        if not _candidate.is_relative_to(_root.resolve()):
            raise ValueError(f"Path traversal blocked in xml_path: '{xml_path}'")
        self.xml_path = _candidate
        self.tree = ET.parse(self.xml_path)
        self.root = self.tree.getroot()

    # ------------------------------------------------------------------
    def get_job_metadata(self) -> Dict[str, str]:
        header = self.root.find("Header")
        job = self.root.find("Job")
        root_record = job.find("Record[@Type='JobDefn']") if job else None

        meta: Dict[str, str] = {}
        if header is not None:
            meta["server_name"] = header.get("ServerName", "")
            meta["tool_instance_id"] = header.get("ToolInstanceID", "")
            meta["export_date"] = header.get("Date", "")
        if job is not None:
            meta["job_name"] = job.get("Identifier", "")
            meta["date_modified"] = job.get("DateModified", "")
        if root_record is not None:
            for prop in root_record.findall("Property"):
                name = prop.get("Name", "")
                if name == "Category":
                    meta["category"] = prop.text or ""
                elif name == "JobVersion":
                    meta["job_version"] = prop.text or ""
        return meta

    # ------------------------------------------------------------------
    def get_job_parameters(self) -> List[Dict[str, str]]:
        """Extract job parameters with full details."""
        PARAM_TYPE_MAP = {
            "0": "String", "1": "Encrypted", "2": "Integer", "3": "Float",
            "4": "Pathname", "5": "List", "6": "Date", "7": "Time",
            "13": "Connection Parameter Set",
        }
        params: List[Dict[str, str]] = []
        job = self.root.find("Job")
        if job is None:
            return params
        root_record = job.find("Record[@Type='JobDefn']")
        if root_record is None:
            return params
        params_coll = root_record.find("Collection[@Name='Parameters']")
        if params_coll is None:
            return params
        for sub in params_coll.findall("SubRecord"):
            p: Dict[str, str] = {}
            for prop in sub.findall("Property"):
                name = prop.get("Name", "")
                text = prop.text or ""
                if name == "Name":
                    p["name"] = text
                elif name == "Default":
                    p["default"] = text
                elif name == "Prompt":
                    p["prompt"] = text
                elif name == "HelpTxt":
                    p["help"] = text
                elif name == "ParamType":
                    p["type"] = PARAM_TYPE_MAP.get(text, f"Type({text})")
            if "name" in p:
                params.append(p)
        return params

    def get_parameterized_variables(self) -> List[Dict[str, str]]:
        """Extract connection parameter sub-variables and job params used in SQL/expressions."""
        import defusedxml.ElementTree as ET
        variables: List[Dict[str, str]] = []
        seen: set = set()
        content = ET.tostring(self.root, encoding="unicode")

        for m in re.finditer(r"#(\w+)\.\$(\w+)#", content):
            conn_set, var_name = m.group(1), m.group(2)
            key = f"{conn_set}.{var_name}"
            if key not in seen:
                seen.add(key)
                variables.append({
                    "name": f"$${var_name}",
                    "parent": conn_set,
                    "type": "Connection Sub-Parameter",
                    "default": "",
                    "description": f"Sub-parameter of {conn_set} connection parameter set",
                })

        for m in re.finditer(r"#((?:jp|p[A-Z])\w+)#", content):
            param_name = m.group(1)
            if param_name not in seen:
                seen.add(param_name)
                job_params = self.get_job_parameters()
                default_val = ""
                for jp in job_params:
                    if jp.get("name") == param_name:
                        default_val = jp.get("default", "")
                        break
                variables.append({
                    "name": f"##{param_name}##",
                    "parent": "Job Parameter",
                    "type": "Job Parameter",
                    "default": default_val,
                    "description": f"DataStage job parameter",
                })

        hardcoded_schemas: set = set()
        for m in re.finditer(r"(?:FROM|JOIN)\s+(\w+)\.(\w+)", content, re.IGNORECASE):
            schema = m.group(1)
            if not schema.startswith("$") and schema.upper() not in ("PROPERTY",):
                hardcoded_schemas.add(schema)

        for v in variables:
            if "DB_SCHEMA" in v["name"]:
                if hardcoded_schemas:
                    v["possible_values"] = ", ".join(sorted(hardcoded_schemas))

        return variables

    # ------------------------------------------------------------------
    def get_stages(self) -> List[Dict[str, Any]]:
        stages: List[Dict[str, Any]] = []
        job = self.root.find("Job")
        if job is None:
            return stages
        for record in job.findall("Record"):
            rec_type = record.get("Type", "")
            if rec_type in (
                "CustomStage", "TransformerStage",
                "SeqFileStage", "HashedFileStage",
            ):
                stage: Dict[str, Any] = {
                    "id": record.get("Identifier", ""),
                    "type": rec_type,
                }
                for prop in record.findall("Property"):
                    name = prop.get("Name", "")
                    if name == "Name":
                        stage["name"] = prop.text or ""
                    elif name == "StageType":
                        stage["stage_type"] = prop.text or ""
                    elif name == "Directory":
                        stage["directory"] = prop.text or ""
                stages.append(stage)
        return stages

    # ------------------------------------------------------------------
    @staticmethod
    def _extract_cdata_from_xml_props(xml_props_str: str, tag_name: str) -> str:
        """Extract CDATA or text content from a tag in an embedded XML properties string."""
        safe_tag = re.escape(tag_name)
        # Try CDATA pattern first
        pattern = rf"<{safe_tag}[^>]*>\s*<!\[CDATA\[(.*?)\]\]>"
        match = re.search(pattern, xml_props_str, re.DOTALL)
        if match:
            return match.group(1).strip()
        # Try simple tag content
        pattern = rf"<{safe_tag}[^>]*>(.*?)</{safe_tag}>"
        match = re.search(pattern, xml_props_str, re.DOTALL)
        if match:
            return match.group(1).strip()
        return ""

    # ------------------------------------------------------------------
    def _get_custom_stage_xml_properties(self, context: str) -> str:
        """Get the XMLProperties value from a CustomStage with a given Context (source/target)."""
        job = self.root.find("Job")
        if job is None:
            return ""
        for record in job.findall("Record"):
            if record.get("Type") != "CustomStage":
                continue
            props_coll = record.find("Collection[@Type='CustomProperty']")
            if props_coll is None:
                continue
            stage_context = ""
            xml_props_val = ""
            for sub in props_coll.findall("SubRecord"):
                name_prop = sub.find("Property[@Name='Name']")
                val_prop = sub.find("Property[@Name='Value']")
                if name_prop is not None and name_prop.text == "Context":
                    stage_context = (val_prop.text or "") if val_prop is not None else ""
                elif name_prop is not None and name_prop.text == "XMLProperties":
                    xml_props_val = (val_prop.text or "") if val_prop is not None else ""
            if stage_context == context and xml_props_val:
                return xml_props_val
        return ""

    # ------------------------------------------------------------------
    def get_source_sql(self) -> str:
        job = self.root.find("Job")
        if job is None:
            return ""
        # Method 1: Server jobs - USERSQL in CustomOutput
        for record in job.findall("Record"):
            if record.get("Type") == "CustomOutput":
                props_coll = record.find("Collection[@Type='CustomProperty']")
                if props_coll is not None:
                    for sub in props_coll.findall("SubRecord"):
                        name_prop = sub.find("Property[@Name='Name']")
                        val_prop = sub.find("Property[@Name='Value']")
                        if (
                            name_prop is not None
                            and name_prop.text == "USERSQL"
                            and val_prop is not None
                            and val_prop.text
                        ):
                            return val_prop.text
        # Method 2: Parallel jobs - SelectStatement in source CustomStage XMLProperties
        # Collect SQL from ALL source stages (multi-source parallel jobs)
        all_sqls: List[str] = []
        job2 = self.root.find("Job")
        if job2 is not None:
            for record in job2.findall("Record"):
                if record.get("Type") != "CustomStage":
                    continue
                props_coll = record.find("Collection[@Type='CustomProperty']")
                if props_coll is None:
                    continue
                is_source = False
                xml_props_val = ""
                stage_name = ""
                for prop in record.findall("Property"):
                    if prop.get("Name") == "Name":
                        stage_name = prop.text or ""
                for sub in props_coll.findall("SubRecord"):
                    name_prop = sub.find("Property[@Name='Name']")
                    val_prop = sub.find("Property[@Name='Value']")
                    if name_prop is not None and name_prop.text == "Context":
                        is_source = (val_prop.text or "") == "source" if val_prop is not None else False
                    elif name_prop is not None and name_prop.text == "XMLProperties":
                        xml_props_val = (val_prop.text or "") if val_prop is not None else ""
                if is_source and xml_props_val:
                    sql = self._extract_cdata_from_xml_props(xml_props_val, "SelectStatement")
                    if sql:
                        if len(all_sqls) > 0:
                            all_sqls.append(f"\n-- Source: {stage_name}\n{sql}")
                        else:
                            all_sqls.append(sql)
                    else:
                        # Check for TableName in GenerateSQL mode
                        tbl = self._extract_cdata_from_xml_props(xml_props_val, "TableName")
                        if tbl:
                            cleaned = re.sub(r"#[^#]+#", "", tbl).strip(".")
                            all_sqls.append(f"SELECT * FROM {cleaned}")
        if all_sqls:
            return "\n".join(all_sqls)
        return ""

    # ------------------------------------------------------------------
    def get_source_sql_per_stage(self) -> Dict[str, str]:
        """Extract SQL per source stage, keyed by output link name.

        Returns dict mapping output_link_name -> SQL string.
        For single-source jobs, the key is the CustomOutput link name.
        For multi-source jobs, returns one entry per source stage.
        """
        result: Dict[str, str] = {}
        job = self.root.find("Job")
        if job is None:
            return result

        # Method 1: Server jobs - USERSQL in CustomOutput
        for record in job.findall("Record"):
            if record.get("Type") == "CustomOutput":
                link_name = ""
                sql_val = ""
                for prop in record.findall("Property"):
                    if prop.get("Name") == "Name":
                        link_name = prop.text or ""
                props_coll = record.find("Collection[@Type='CustomProperty']")
                if props_coll is not None:
                    for sub in props_coll.findall("SubRecord"):
                        name_prop = sub.find("Property[@Name='Name']")
                        val_prop = sub.find("Property[@Name='Value']")
                        if (name_prop is not None and name_prop.text == "USERSQL"
                                and val_prop is not None and val_prop.text):
                            sql_val = val_prop.text
                if link_name and sql_val:
                    result[link_name] = sql_val

        if result:
            return result

        # Method 2: Parallel jobs - SelectStatement in source CustomStage XMLProperties
        for record in job.findall("Record"):
            if record.get("Type") != "CustomStage":
                continue
            props_coll = record.find("Collection[@Type='CustomProperty']")
            if props_coll is None:
                continue
            is_source = False
            xml_props_val = ""
            stage_name = ""
            for prop in record.findall("Property"):
                if prop.get("Name") == "Name":
                    stage_name = prop.text or ""
            for sub in props_coll.findall("SubRecord"):
                name_prop = sub.find("Property[@Name='Name']")
                val_prop = sub.find("Property[@Name='Value']")
                if name_prop is not None and name_prop.text == "Context":
                    is_source = (val_prop.text or "") == "source" if val_prop is not None else False
                elif name_prop is not None and name_prop.text == "XMLProperties":
                    xml_props_val = (val_prop.text or "") if val_prop is not None else ""
            if is_source and xml_props_val:
                sql = self._extract_cdata_from_xml_props(xml_props_val, "SelectStatement")
                if not sql:
                    tbl = self._extract_cdata_from_xml_props(xml_props_val, "TableName")
                    if tbl:
                        cleaned = re.sub(r"#[^#]+#", "", tbl).strip(".")
                        sql = f"SELECT * FROM {cleaned}"
                # Find the output link name for this source stage
                output_link_name = stage_name
                output_pin_ids = []
                for prop in record.findall("Property"):
                    if prop.get("Name") == "OutputPins" and prop.text:
                        output_pin_ids = [p.strip() for p in prop.text.split("|")]
                for pin_id in output_pin_ids:
                    for rec2 in job.findall("Record"):
                        if rec2.get("Identifier") == pin_id and rec2.get("Type") == "CustomOutput":
                            for p2 in rec2.findall("Property"):
                                if p2.get("Name") == "Name" and p2.text:
                                    output_link_name = p2.text
                                    break
                            break
                if sql:
                    result[output_link_name] = sql

        return result

    # ------------------------------------------------------------------
    def get_source_table(self) -> str:
        job = self.root.find("Job")
        if job is None:
            return ""
        # Method 1: Server jobs - TABLE property in CustomOutput
        for record in job.findall("Record"):
            if record.get("Type") == "CustomOutput":
                props_coll = record.find("Collection[@Type='CustomProperty']")
                if props_coll is not None:
                    for sub in props_coll.findall("SubRecord"):
                        name_prop = sub.find("Property[@Name='Name']")
                        val_prop = sub.find("Property[@Name='Value']")
                        if (
                            name_prop is not None
                            and name_prop.text == "TABLE"
                            and val_prop is not None
                            and val_prop.text
                        ):
                            return val_prop.text

        # Method 2: Parallel jobs - extract table names from source SQL
        source_sql = self.get_source_sql()
        if source_sql:
            tables = self._extract_tables_from_sql(source_sql)
            if tables:
                return ", ".join(tables)

        # Method 3: Parallel jobs - collect all source CustomStage names
        source_names: List[str] = []
        for record in job.findall("Record"):
            if record.get("Type") != "CustomStage":
                continue
            props_coll = record.find("Collection[@Type='CustomProperty']")
            if props_coll is None:
                continue
            is_source = False
            for sub in props_coll.findall("SubRecord"):
                name_prop = sub.find("Property[@Name='Name']")
                val_prop = sub.find("Property[@Name='Value']")
                if (name_prop is not None and name_prop.text == "Context"
                        and val_prop is not None and val_prop.text == "source"):
                    is_source = True
                    break
            if is_source:
                for prop in record.findall("Property"):
                    if prop.get("Name") == "Name" and prop.text:
                        source_names.append(prop.text)
                        break
        if source_names:
            return ", ".join(source_names)
        return ""

    # ------------------------------------------------------------------
    def get_source_stages_info(self) -> Dict[str, Dict[str, Any]]:
        """Extract info for each source stage: output link name, SQL, physical tables.
        Returns: {output_link_name: {stage_name, sql, tables, stage_type}}"""
        result: Dict[str, Dict[str, Any]] = {}
        job = self.root.find("Job")
        if job is None:
            return result

        # First pass: identify all source stages and their record IDs
        source_stages: List[Tuple[str, str, str]] = []  # (record_id, stage_name, stage_type)
        for record in job.findall("Record"):
            if record.get("Type") != "CustomStage":
                continue
            stage_name = ""
            stage_type = ""
            for prop in record.findall("Property"):
                if prop.get("Name") == "Name":
                    stage_name = prop.text or ""
                elif prop.get("Name") == "StageType":
                    stage_type = prop.text or ""
            props_coll = record.find("Collection[@Type='CustomProperty']")
            if props_coll is None:
                continue
            is_source = False
            xml_props = ""
            for sub in props_coll.findall("SubRecord"):
                name_prop = sub.find("Property[@Name='Name']")
                val_prop = sub.find("Property[@Name='Value']")
                if name_prop is not None and name_prop.text == "Context":
                    is_source = (val_prop.text or "") == "source" if val_prop is not None else False
                elif name_prop is not None and name_prop.text == "XMLProperties":
                    xml_props = (val_prop.text or "") if val_prop is not None else ""
            if is_source:
                sql = self._extract_cdata_from_xml_props(xml_props, "SelectStatement") if xml_props else ""
                source_stages.append((record.get("Identifier", ""), stage_name, stage_type, sql))

        # Second pass: find output link names for each source stage
        # CustomOutput records belonging to a stage have IDs starting with the stage's ID
        for rec_id, stage_name, stage_type, sql in source_stages:
            for record in job.findall("Record"):
                if record.get("Type") == "CustomOutput":
                    output_id = record.get("Identifier", "")
                    link_name = ""
                    for prop in record.findall("Property"):
                        if prop.get("Name") == "Name":
                            link_name = prop.text or ""
                    if output_id.startswith(rec_id + "P") or output_id == rec_id:
                        # Extract physical tables from SQL
                        tables = self._extract_tables_from_sql(sql) if sql else []
                        # Also extract table names without schema (from parameterized refs)
                        if sql:
                            for t in self._extract_tables_from_sql_extended(sql):
                                if t not in tables:
                                    tables.append(t)
                        result[link_name] = {
                            "stage_name": stage_name,
                            "sql": sql,
                            "tables": tables,
                            "stage_type": stage_type,
                        }
                        break

        return result

    # ------------------------------------------------------------------
    def build_extended_link_map(
        self, source_link_table_map: Dict[str, str],
    ) -> Dict[str, str]:
        """Extend source_link_table_map with intermediate pipeline links.

        Traces through PxLookup, PxJoin, PxFunnel, PxRemDup, and transformer
        stages to map their output link names to physical source tables.
        """
        extended_map = dict(source_link_table_map)
        job = self.root.find("Job")
        if job is None:
            return extended_map

        # Step 1: Build stage info: stage_id -> {name, type, input_pins, output_pins}
        stage_info: Dict[str, Dict] = {}
        for record in job.findall("Record"):
            rec_type = record.get("Type", "")
            rec_id = record.get("Identifier", "")
            if rec_type in ("CustomStage", "TransformerStage", "CTransformerStage"):
                info: Dict[str, Any] = {
                    "id": rec_id, "name": "", "type": "",
                    "input_pins": [], "output_pins": [],
                }
                for prop in record.findall("Property"):
                    n = prop.get("Name", "")
                    if n == "Name":
                        info["name"] = prop.text or ""
                    elif n == "StageType":
                        info["type"] = prop.text or ""
                    elif n == "InputPins" and prop.text:
                        info["input_pins"] = [
                            p.strip() for p in prop.text.split("|") if p.strip()
                        ]
                    elif n == "OutputPins" and prop.text:
                        info["output_pins"] = [
                            p.strip() for p in prop.text.split("|") if p.strip()
                        ]
                if rec_type in ("TransformerStage", "CTransformerStage"):
                    info["type"] = rec_type
                stage_info[rec_id] = info

        # Step 2: Map pin IDs to link names and metadata
        output_pin_info: Dict[str, Dict] = {}
        input_pin_info: Dict[str, Dict] = {}
        for record in job.findall("Record"):
            rec_type = record.get("Type", "")
            rec_id = record.get("Identifier", "")
            if rec_type in ("CustomOutput", "TrxOutput"):
                link_name = ""
                for prop in record.findall("Property"):
                    if prop.get("Name") == "Name":
                        link_name = prop.text or ""
                parent_stage_id = ""
                for sid, sinfo in stage_info.items():
                    if rec_id in sinfo.get("output_pins", []):
                        parent_stage_id = sid
                        break
                output_pin_info[rec_id] = {
                    "link_name": link_name,
                    "parent_stage_id": parent_stage_id,
                }
            elif rec_type in ("CustomInput", "TrxInput"):
                link_name = ""
                link_type_val = ""
                for prop in record.findall("Property"):
                    if prop.get("Name") == "Name":
                        link_name = prop.text or ""
                    elif prop.get("Name") == "LinkType":
                        link_type_val = prop.text or ""
                parent_stage_id = ""
                for sid, sinfo in stage_info.items():
                    if rec_id in sinfo.get("input_pins", []):
                        parent_stage_id = sid
                        break
                input_pin_info[rec_id] = {
                    "link_name": link_name,
                    "parent_stage_id": parent_stage_id,
                    "link_type": link_type_val,
                }

        # Step 3: Iteratively resolve intermediate links.
        # For each stage, if its output link names aren't in the map,
        # check if any of its input links are resolved and propagate.
        max_iterations = 10
        for _ in range(max_iterations):
            new_mappings: Dict[str, str] = {}
            for sid, sinfo in stage_info.items():
                # Get this stage's output link names
                output_link_names = []
                for opin_id in sinfo.get("output_pins", []):
                    if opin_id in output_pin_info:
                        oln = output_pin_info[opin_id]["link_name"]
                        if oln:
                            output_link_names.append(oln)

                # Skip if all output links are already resolved
                unresolved = [
                    n for n in output_link_names
                    if n not in extended_map and n not in new_mappings
                ]
                if not unresolved:
                    continue

                # Find this stage's input links and check if they're resolved
                # For PxLookup, prefer the main (non-reference) input
                main_input_table = ""
                any_input_table = ""
                for ipin_id in sinfo.get("input_pins", []):
                    if ipin_id not in input_pin_info:
                        continue
                    ipin = input_pin_info[ipin_id]
                    ilink = ipin["link_name"]
                    if ilink in extended_map:
                        if ipin.get("link_type") != "2":  # Not reference input
                            main_input_table = extended_map[ilink]
                        if not any_input_table:
                            any_input_table = extended_map[ilink]

                resolved_table = main_input_table or any_input_table
                if resolved_table:
                    for oln in unresolved:
                        new_mappings[oln] = resolved_table

            if not new_mappings:
                break
            extended_map.update(new_mappings)

        return extended_map

    # ------------------------------------------------------------------
    def build_column_link_map(
        self, source_link_table_map: Dict[str, str],
    ) -> Dict[str, Dict[str, str]]:
        """Build per-column physical table resolution for intermediate links.

        For links that carry columns from multiple source tables (e.g. after
        a PxJoin merges two sources), this traces each column individually
        back to its originating physical table.

        Returns: {link_name: {col_name: physical_table_with_schema}}
        """
        job = self.root.find("Job")
        if job is None:
            return {}

        # Step 1: Build stage info
        stage_info: Dict[str, Dict] = {}
        for record in job.findall("Record"):
            rec_type = record.get("Type", "")
            rec_id = record.get("Identifier", "")
            if rec_type in ("CustomStage", "TransformerStage", "CTransformerStage"):
                info: Dict[str, Any] = {
                    "name": "", "type": "",
                    "input_pins": [], "output_pins": [],
                }
                for prop in record.findall("Property"):
                    n = prop.get("Name", "")
                    if n == "Name":
                        info["name"] = prop.text or ""
                    elif n == "StageType":
                        info["type"] = prop.text or ""
                    elif n == "InputPins" and prop.text:
                        info["input_pins"] = [
                            p.strip() for p in prop.text.split("|") if p.strip()
                        ]
                    elif n == "OutputPins" and prop.text:
                        info["output_pins"] = [
                            p.strip() for p in prop.text.split("|") if p.strip()
                        ]
                if rec_type in ("TransformerStage", "CTransformerStage"):
                    info["type"] = rec_type
                stage_info[rec_id] = info

        # Step 2: Build pin info
        output_pins: Dict[str, Dict] = {}
        input_pins: Dict[str, Dict] = {}
        for record in job.findall("Record"):
            rec_type = record.get("Type", "")
            rec_id = record.get("Identifier", "")
            if rec_type in ("CustomOutput", "TrxOutput"):
                link_name = ""
                for prop in record.findall("Property"):
                    if prop.get("Name") == "Name":
                        link_name = prop.text or ""
                parent_stage_id = ""
                for sid, sinfo in stage_info.items():
                    if rec_id in sinfo.get("output_pins", []):
                        parent_stage_id = sid
                        break
                columns: Dict[str, str] = {}
                all_col_names: List[str] = []
                cols_coll = record.find("Collection[@Type='OutputColumn']")
                if cols_coll is not None:
                    for sub in cols_coll.findall("SubRecord"):
                        col_name = ""
                        derivation = ""
                        for prop in sub.findall("Property"):
                            n = prop.get("Name", "")
                            if n == "Name":
                                col_name = prop.text or ""
                            elif n == "Derivation":
                                derivation = prop.text or ""
                        if col_name:
                            all_col_names.append(col_name)
                            columns[col_name] = derivation
                output_pins[rec_id] = {
                    "link_name": link_name,
                    "parent_stage_id": parent_stage_id,
                    "columns": columns,
                    "all_columns": all_col_names,
                }
            elif rec_type in ("CustomInput", "TrxInput"):
                link_name = ""
                link_type_val = ""
                for prop in record.findall("Property"):
                    if prop.get("Name") == "Name":
                        link_name = prop.text or ""
                    elif prop.get("Name") == "LinkType":
                        link_type_val = prop.text or ""
                parent_stage_id = ""
                for sid, sinfo in stage_info.items():
                    if rec_id in sinfo.get("input_pins", []):
                        parent_stage_id = sid
                        break
                input_pins[rec_id] = {
                    "link_name": link_name,
                    "parent_stage_id": parent_stage_id,
                    "link_type": link_type_val,
                }

        # Step 3: Build link_name -> output_pin_id
        link_to_opin: Dict[str, str] = {}
        for pin_id, pinfo in output_pins.items():
            if pinfo["link_name"]:
                link_to_opin[pinfo["link_name"]] = pin_id

        # Step 4: For each stage, identify main and reference input links
        stage_main_input: Dict[str, str] = {}
        stage_ref_input: Dict[str, str] = {}
        stage_ref_col_names: Dict[str, set] = {}
        for sid, sinfo in stage_info.items():
            main_link = ""
            ref_link = ""
            for ipin_id in sinfo.get("input_pins", []):
                if ipin_id not in input_pins:
                    continue
                ipin = input_pins[ipin_id]
                if ipin["link_type"] == "2":
                    ref_link = ipin["link_name"]
                elif not main_link:
                    main_link = ipin["link_name"]
            if main_link:
                stage_main_input[sid] = main_link
            if ref_link:
                stage_ref_input[sid] = ref_link
                ref_opin_id = link_to_opin.get(ref_link)
                if ref_opin_id and ref_opin_id in output_pins:
                    stage_ref_col_names[sid] = set(
                        output_pins[ref_opin_id].get("all_columns", [])
                    )

        # Step 5: Recursive column resolver
        resolve_cache: Dict[Tuple[str, str], str] = {}

        def resolve_column(link_name: str, col_name: str, depth: int = 0) -> str:
            cache_key = (link_name, col_name)
            if cache_key in resolve_cache:
                return resolve_cache[cache_key]
            if depth > 15:
                result = source_link_table_map.get(link_name, "")
                resolve_cache[cache_key] = result
                return result

            if link_name in source_link_table_map:
                result = source_link_table_map[link_name]
                resolve_cache[cache_key] = result
                return result

            opin_id = link_to_opin.get(link_name)
            if not opin_id or opin_id not in output_pins:
                resolve_cache[cache_key] = ""
                return ""

            opin = output_pins[opin_id]
            parent_sid = opin["parent_stage_id"]
            col_deriv = opin.get("columns", {}).get(col_name, "")

            if col_deriv:
                col_deriv = re.sub(r"\\?\(\d+(?:,\d+)?\)", "", col_deriv).strip()

            if col_deriv and "." in col_deriv and " " not in col_deriv:
                parts = col_deriv.split(".", 1)
                next_link, next_col = parts[0], parts[1]
                result = resolve_column(next_link, next_col, depth + 1)
                resolve_cache[cache_key] = result
                return result

            if parent_sid in stage_info:
                stype = stage_info[parent_sid].get("type", "")
                if stype == "PxLookup":
                    ref_cols = stage_ref_col_names.get(parent_sid, set())
                    main_link = stage_main_input.get(parent_sid, "")
                    ref_link = stage_ref_input.get(parent_sid, "")
                    if col_name in ref_cols and ref_link:
                        main_opin_id = link_to_opin.get(main_link)
                        main_cols = set()
                        if main_opin_id and main_opin_id in output_pins:
                            main_cols = set(
                                output_pins[main_opin_id].get("all_columns", [])
                            )
                        if col_name not in main_cols:
                            result = resolve_column(ref_link, col_name, depth + 1)
                            resolve_cache[cache_key] = result
                            return result
                    if main_link:
                        result = resolve_column(main_link, col_name, depth + 1)
                        resolve_cache[cache_key] = result
                        return result
                else:
                    main_link = stage_main_input.get(parent_sid, "")
                    if main_link:
                        result = resolve_column(main_link, col_name, depth + 1)
                        resolve_cache[cache_key] = result
                        return result

            resolve_cache[cache_key] = ""
            return ""

        # Step 6: Discover all column names referenced via each intermediate link
        # (needed because DataStage output pins may not list implicit passthrough columns)
        referenced_cols: Dict[str, set] = {}
        for pin_id, pinfo in output_pins.items():
            for col_name_iter, deriv_iter in pinfo.get("columns", {}).items():
                if deriv_iter and "." in deriv_iter and " " not in deriv_iter:
                    d_clean = re.sub(r"\\?\(\d+(?:,\d+)?\)", "", deriv_iter).strip()
                    if "." in d_clean:
                        ref_link = d_clean.split(".")[0]
                        ref_col = d_clean.split(".", 1)[1]
                        if ref_link not in source_link_table_map:
                            referenced_cols.setdefault(ref_link, set()).add(ref_col)

        # Step 7: Build the column-level map for all non-source links
        col_link_map: Dict[str, Dict[str, str]] = {}
        for link_name, opin_id in link_to_opin.items():
            if link_name in source_link_table_map:
                continue
            opin = output_pins.get(opin_id, {})
            # Combine explicitly defined columns with columns referenced in
            # downstream derivations (implicit passthroughs)
            all_cols_to_resolve = set(opin.get("all_columns", []))
            if link_name in referenced_cols:
                all_cols_to_resolve.update(referenced_cols[link_name])
            col_map_entry: Dict[str, str] = {}
            for col_name in all_cols_to_resolve:
                resolved = resolve_column(link_name, col_name)
                if resolved:
                    col_map_entry[col_name] = resolved
            if col_map_entry:
                col_link_map[link_name] = col_map_entry

        return col_link_map

    # ------------------------------------------------------------------
    @staticmethod
    def _extract_tables_from_sql_extended(sql: str) -> List[str]:
        """Extract table references from SQL, handling parameterized schemas.
        Returns schema.table where available, or just table_name for parameterized refs."""
        tables: List[str] = []
        # Clean up parameterized schema references: #...#.TABLE -> TABLE
        cleaned_sql = re.sub(r"#[^#]+#\.", "", sql)
        # Match FROM/JOIN followed by schema.table or just table_name
        for match in re.finditer(r"(?:FROM|JOIN)\s+(\w+\.\w+)", cleaned_sql, re.IGNORECASE):
            table = match.group(1)
            if table not in tables:
                tables.append(table)
        # Plain table_name pattern (no schema, for parameterized refs)
        for match in re.finditer(r"(?:FROM|JOIN)\s+(\w+)(?:\s|$|,)", cleaned_sql, re.IGNORECASE):
            table = match.group(1).upper()
            if table in ("SELECT", "WHERE", "AND", "OR", "ON", "AS", "IN", "NOT",
                         "NULL", "CASE", "WHEN", "THEN", "ELSE", "END", "GROUP",
                         "ORDER", "BY", "HAVING", "UNION", "ALL", "DISTINCT"):
                continue
            already_found = any(t.endswith("." + table) or t == table for t in tables)
            if not already_found and table not in tables:
                tables.append(table)
        return tables

    # ------------------------------------------------------------------
    @staticmethod
    def _extract_tables_from_sql(sql: str) -> List[str]:
        """Extract schema.table references from SQL (FROM / JOIN clauses)."""
        tables: List[str] = []
        # Match schema.table_name patterns (uppercase identifiers with underscores)
        pattern = r"(?:FROM|JOIN)\s+(\w+\.\w+)"
        for match in re.finditer(pattern, sql, re.IGNORECASE):
            table = match.group(1)
            if table not in tables:
                tables.append(table)
        return tables

    # ------------------------------------------------------------------
    def _get_target_linked_trx_output_id(self) -> str:
        """Find the TrxOutput record ID that feeds into the target stage's CustomInput."""
        job = self.root.find("Job")
        if job is None:
            return ""
        # Step 1: Find target CustomStage (Context=target) and its InputPins
        target_stage_id = ""
        target_input_pin_ids: List[str] = []
        for record in job.findall("Record"):
            if record.get("Type") != "CustomStage":
                continue
            props_coll = record.find("Collection[@Type='CustomProperty']")
            if props_coll is None:
                continue
            is_target = False
            for sub in props_coll.findall("SubRecord"):
                name_prop = sub.find("Property[@Name='Name']")
                val_prop = sub.find("Property[@Name='Value']")
                if (name_prop is not None and name_prop.text == "Context"
                        and val_prop is not None and val_prop.text == "target"):
                    is_target = True
                    break
            if is_target:
                target_stage_id = record.get("Identifier", "")
                for prop in record.findall("Property"):
                    if prop.get("Name") == "InputPins" and prop.text:
                        target_input_pin_ids = [p.strip() for p in prop.text.split(",")]
                break

        if not target_input_pin_ids:
            return ""

        # Step 2: Find the CustomInput record and its Partner (which TrxOutput feeds it)
        for pin_id in target_input_pin_ids:
            for record in job.findall("Record"):
                if (record.get("Identifier") == pin_id
                        and record.get("Type") == "CustomInput"):
                    for prop in record.findall("Property"):
                        if prop.get("Name") == "Partner" and prop.text:
                            # Partner format: "V0S429|V0S429P2"
                            # The second part is the TrxOutput ID
                            parts = prop.text.split("|")
                            if len(parts) >= 2:
                                return parts[1].strip()
                            return parts[0].strip()
        return ""

    # ------------------------------------------------------------------
    def _build_all_output_derivations(self) -> Dict[str, Dict[str, str]]:
        """Build a map of link_name -> {col_name: derivation} for ALL output records
        (TrxOutput and CustomOutput). This allows tracing derivations through the
        full pipeline including PxLookup and PxJoin stages."""
        result: Dict[str, Dict[str, str]] = {}
        job = self.root.find("Job")
        if job is None:
            return result
        for record in job.findall("Record"):
            if record.get("Type") not in ("TrxOutput", "CustomOutput"):
                continue
            link_name = ""
            for prop in record.findall("Property"):
                if prop.get("Name") == "Name":
                    link_name = prop.text or ""
                    break
            if not link_name:
                continue
            cols_map: Dict[str, str] = {}
            cols_coll = record.find("Collection[@Type='OutputColumn']")
            if cols_coll is not None:
                for sub in cols_coll.findall("SubRecord"):
                    col_name = ""
                    derivation = ""
                    for prop in sub.findall("Property"):
                        n = prop.get("Name", "")
                        if n == "Name":
                            col_name = prop.text or ""
                        elif n == "Derivation":
                            derivation = prop.text or ""
                    if col_name:
                        cols_map[col_name] = derivation
            result[link_name] = cols_map
        return result

    # ------------------------------------------------------------------
    def _resolve_derivation(
        self, derivation: str, all_derivations: Dict[str, Dict[str, str]],
        depth: int = 0,
    ) -> str:
        """Resolve a passthrough derivation (e.g. fromTrfCalc.COL) back to the
        original transformation by looking up upstream output derivations.
        Traces up to 10 levels deep to handle long lookup/join chains."""
        if depth > 10 or not derivation:
            return derivation
        d = derivation.strip()
        # Only resolve simple passthrough patterns: linkName.COLUMN
        if "." not in d or "(" in d or " " in d or "[" in d:
            return derivation
        parts = d.split(".", 1)
        if len(parts) != 2:
            return derivation
        link_name, col_name = parts
        # Look up in upstream TrxOutput
        upstream = all_derivations.get(link_name, {})
        upstream_deriv = upstream.get(col_name, "")
        if upstream_deriv and upstream_deriv != d:
            # Recursively resolve
            return self._resolve_derivation(upstream_deriv, all_derivations, depth + 1)
        return derivation

    def _resolve_derivation_with_trace(
        self, derivation: str, all_derivations: Dict[str, Dict[str, str]],
        depth: int = 0,
    ) -> Tuple[str, List[str]]:
        """Resolve derivation and return (resolved_derivation, list_of_link_names_visited).
        The trace allows callers to find which source stage a column originated from."""
        if depth > 10 or not derivation:
            return derivation, []
        d = derivation.strip()
        if "." not in d or "(" in d or " " in d or "[" in d:
            return derivation, []
        parts = d.split(".", 1)
        if len(parts) != 2:
            return derivation, []
        link_name, col_name = parts
        upstream = all_derivations.get(link_name, {})
        upstream_deriv = upstream.get(col_name, "")
        if upstream_deriv and upstream_deriv != d:
            resolved, child_trace = self._resolve_derivation_with_trace(
                upstream_deriv, all_derivations, depth + 1,
            )
            return resolved, [link_name] + child_trace
        return derivation, [link_name]

    # ------------------------------------------------------------------
    def _extract_columns_from_output_record(
        self, record, all_derivations: Dict[str, Dict[str, str]],
    ) -> List[Dict[str, Any]]:
        """Extract column definitions from a TrxOutput or CustomOutput record."""
        columns: List[Dict[str, Any]] = []
        cols_coll = record.find("Collection[@Type='OutputColumn']")
        if cols_coll is None:
            return columns
        for sub in cols_coll.findall("SubRecord"):
            col: Dict[str, Any] = {}
            for prop in sub.findall("Property"):
                name = prop.get("Name", "")
                text = prop.text or ""
                if name == "Name":
                    col["name"] = text
                elif name == "SqlType":
                    col["sql_type"] = int(text) if text else 0
                elif name == "Precision":
                    col["precision"] = int(text) if text else 0
                elif name == "Scale":
                    col["scale"] = int(text) if text else 0
                elif name == "Nullable":
                    col["nullable"] = text == "1"
                elif name == "KeyPosition":
                    col["key_position"] = int(text) if text else 0
                elif name == "Derivation":
                    col["derivation"] = text
                elif name == "SourceColumn":
                    col["source_column"] = text
                elif name == "TableDef":
                    col["table_def"] = text
            if "name" in col:
                # Resolve passthrough derivations through the pipeline
                raw_deriv = col.get("derivation", "")
                resolved, trace = self._resolve_derivation_with_trace(
                    raw_deriv, all_derivations,
                )
                if resolved != raw_deriv:
                    col["derivation"] = resolved
                # Store the link trace for source table resolution
                col["derivation_trace"] = trace
                columns.append(col)
        return columns

    # ------------------------------------------------------------------
    def get_transformer_output_columns(self) -> List[Dict[str, Any]]:
        columns: List[Dict[str, Any]] = []
        job = self.root.find("Job")
        if job is None:
            return columns

        # For multi-transformer pipelines, find the specific TrxOutput
        # that feeds the target stage
        target_trx_id = self._get_target_linked_trx_output_id()

        # Build full derivation map for trace-back
        all_derivations = self._build_all_output_derivations()

        # First, try to find the target output as a TrxOutput
        for record in job.findall("Record"):
            if record.get("Type") != "TrxOutput":
                continue

            # If we identified a specific TrxOutput, skip others
            if target_trx_id and record.get("Identifier") != target_trx_id:
                continue

            columns = self._extract_columns_from_output_record(record, all_derivations)
            if columns:
                return columns
            # If we found the target TrxOutput, stop (don't read more TrxOutputs)
            if target_trx_id:
                break

        # If no TrxOutput found (e.g. target is fed via an intermediary
        # CustomStage like PxRemDup, PxFunnel, etc.), check CustomOutput
        if not columns and target_trx_id:
            for record in job.findall("Record"):
                if record.get("Type") != "CustomOutput":
                    continue
                if record.get("Identifier") != target_trx_id:
                    continue
                columns = self._extract_columns_from_output_record(record, all_derivations)
                break

        return columns

    # ------------------------------------------------------------------
    def get_lookup_stages(self) -> List[Dict[str, Any]]:
        """Extract full lookup stage info (Hashed File and PxLookup stages)."""
        lookups: List[Dict[str, Any]] = []
        job = self.root.find("Job")
        if job is None:
            return lookups

        # ---- Hashed File Lookups (Server jobs) ----
        stage_info: Dict[str, Dict] = {}
        for record in job.findall("Record"):
            if record.get("Type") == "HashedFileStage":
                sid = record.get("Identifier", "")
                info: Dict[str, Any] = {"id": sid}
                for prop in record.findall("Property"):
                    n = prop.get("Name", "")
                    if n == "Name":
                        info["stage_name"] = prop.text or ""
                    elif n == "StageType":
                        info["stage_type"] = prop.text or ""
                stage_info[sid] = info

        for record in job.findall("Record"):
            if record.get("Type") != "HashedOutput":
                continue
            lookup: Dict[str, Any] = {"link_type": "Hashed File Lookup"}
            link_name = ""
            file_name = ""
            directory = ""
            for prop in record.findall("Property"):
                n = prop.get("Name", "")
                t = prop.text or ""
                if n == "Name":
                    link_name = t
                    lookup["link_name"] = t
                elif n == "FileName":
                    file_name = t
                    lookup["file_name"] = t
                elif n == "Directory":
                    directory = t
                    lookup["directory"] = t

            cols: List[Dict[str, Any]] = []
            cols_coll = record.find("Collection[@Type='OutputColumn']")
            if cols_coll is not None:
                for sub in cols_coll.findall("SubRecord"):
                    col: Dict[str, Any] = {}
                    for prop in sub.findall("Property"):
                        n = prop.get("Name", "")
                        t = prop.text or ""
                        if n == "Name":
                            col["name"] = t
                        elif n == "SqlType":
                            col["sql_type"] = int(t) if t else 0
                        elif n == "Precision":
                            col["precision"] = int(t) if t else 0
                        elif n == "Scale":
                            col["scale"] = int(t) if t else 0
                        elif n == "Nullable":
                            col["nullable"] = t == "1"
                        elif n == "KeyPosition":
                            col["key_position"] = int(t) if t else 0
                        elif n == "KeyExpression":
                            col["key_expression"] = t
                    if "name" in col:
                        cols.append(col)

            lookup["columns"] = cols
            lookup["lookup_name"] = file_name or link_name
            for sid, sinfo in stage_info.items():
                if sinfo.get("stage_name", "") in (link_name, ""):
                    lookup["stage_name"] = sinfo.get("stage_name", link_name)
                    break
            lookups.append(lookup)

        # ---- PxLookup and PxJoin stages (Parallel jobs) ----
        for record in job.findall("Record"):
            if record.get("Type") != "CustomStage":
                continue
            stage_type = ""
            stage_name = ""
            join_operator = ""
            join_key_names: List[str] = []
            input_pin_ids_raw: List[str] = []
            output_pin_ids: List[str] = []
            for prop in record.findall("Property"):
                if prop.get("Name") == "StageType":
                    stage_type = prop.text or ""
                elif prop.get("Name") == "Name":
                    stage_name = prop.text or ""
                elif prop.get("Name") == "InputPins" and prop.text:
                    input_pin_ids_raw = [p.strip() for p in prop.text.split("|")]
                elif prop.get("Name") == "OutputPins" and prop.text:
                    output_pin_ids = [p.strip() for p in prop.text.split("|")]
            if stage_type not in ("PxLookup", "PxJoin"):
                continue

            # For PxJoin: extract join operator and key names from CustomProperty
            if stage_type == "PxJoin":
                props_coll = record.find("Collection[@Type='CustomProperty']")
                if props_coll is not None:
                    for sub in props_coll.findall("SubRecord"):
                        name_prop = sub.find("Property[@Name='Name']")
                        val_prop = sub.find("Property[@Name='Value']")
                        if name_prop is not None and val_prop is not None:
                            if name_prop.text == "operator":
                                join_operator = val_prop.text or ""
                            elif name_prop.text == "key" and val_prop.text:
                                for m in re.finditer(r"key\\?\(2\)(\w+)", val_prop.text):
                                    join_key_names.append(m.group(1))

            # Trace input links back to their source stages,
            # also detect LinkType (1=stream/main, 2=reference) for PxLookup
            input_sources: List[Dict[str, str]] = []
            ref_input_link_name = ""
            ref_source_output_pin_id = ""
            for pin_id in input_pin_ids_raw:
                for rec2 in job.findall("Record"):
                    if rec2.get("Identifier") == pin_id:
                        input_link_name = ""
                        partner = ""
                        link_type_val = ""
                        for prop in rec2.findall("Property"):
                            if prop.get("Name") == "Name":
                                input_link_name = prop.text or ""
                            elif prop.get("Name") == "Partner" and prop.text:
                                partner = prop.text
                            elif prop.get("Name") == "LinkType":
                                link_type_val = prop.text or ""
                        if partner:
                            parts = partner.split("|")
                            partner_stage_id = parts[0].strip()
                            partner_pin_id = parts[1].strip() if len(parts) >= 2 else ""
                            partner_stage_name = ""
                            for rec3 in job.findall("Record"):
                                if rec3.get("Identifier") == partner_stage_id:
                                    for p3 in rec3.findall("Property"):
                                        if p3.get("Name") == "Name":
                                            partner_stage_name = p3.text or ""
                                            break
                                    break
                            input_sources.append({
                                "link_name": input_link_name,
                                "stage_name": partner_stage_name,
                                "link_type": link_type_val,
                                "partner_pin_id": partner_pin_id,
                            })
                            if link_type_val == "2":
                                ref_input_link_name = input_link_name
                                ref_source_output_pin_id = partner_pin_id

            # For PxLookup: extract key columns and returned columns
            # from the reference source's output pin (where keys have KeyPosition > 0)
            key_cols: List[str] = []
            key_exprs: List[str] = []
            returned_cols: List[str] = []
            if stage_type == "PxLookup" and ref_source_output_pin_id:
                for rec2 in job.findall("Record"):
                    if rec2.get("Identifier") == ref_source_output_pin_id:
                        cols_coll = rec2.find("Collection[@Type='OutputColumn']")
                        if cols_coll is not None:
                            for sub in cols_coll.findall("SubRecord"):
                                col_name = ""
                                key_pos = 0
                                key_expr = ""
                                for prop in sub.findall("Property"):
                                    n = prop.get("Name", "")
                                    if n == "Name":
                                        col_name = prop.text or ""
                                    elif n == "KeyPosition":
                                        key_pos = int(prop.text or "0")
                                    elif n == "KeyExpression":
                                        key_expr = prop.text or ""
                                if col_name:
                                    if key_pos > 0:
                                        key_cols.append(col_name)
                                        if key_expr:
                                            key_exprs.append(key_expr)
                                    else:
                                        returned_cols.append(col_name)
                        break

            # For PxJoin: use the parsed key names from CustomProperty
            if stage_type == "PxJoin" and join_key_names:
                key_cols = join_key_names

            # Extract output columns from the lookup/join output pin (for column details)
            output_cols: List[Dict[str, Any]] = []
            for out_pin_id in output_pin_ids:
                for rec2 in job.findall("Record"):
                    if rec2.get("Identifier") == out_pin_id:
                        cols_coll = rec2.find("Collection[@Type='OutputColumn']")
                        if cols_coll is not None:
                            for sub in cols_coll.findall("SubRecord"):
                                col_name = ""
                                col_derivation = ""
                                for prop in sub.findall("Property"):
                                    n = prop.get("Name", "")
                                    if n == "Name":
                                        col_name = prop.text or ""
                                    elif n == "Derivation":
                                        col_derivation = prop.text or ""
                                if col_name:
                                    output_cols.append({
                                        "name": col_name,
                                        "derivation": col_derivation,
                                    })
                        break

            # For PxJoin: infer returned columns (from second/right input)
            if stage_type == "PxJoin" and not returned_cols and len(input_sources) >= 2:
                right_link = input_sources[-1]["link_name"]
                for oc in output_cols:
                    deriv = oc.get("derivation", "")
                    if deriv.startswith(right_link + "."):
                        col_n = oc["name"]
                        if col_n not in key_cols:
                            returned_cols.append(col_n)

            # For PxLookup: if returned_cols still empty, infer from output derivations
            if stage_type == "PxLookup" and not returned_cols and ref_input_link_name:
                for oc in output_cols:
                    deriv = oc.get("derivation", "")
                    if deriv.startswith(ref_input_link_name + "."):
                        returned_cols.append(oc["name"])

            # Determine the lookup reference source
            lookup_ref_source = ""
            main_input_source = ""
            if stage_type == "PxLookup":
                for inp in input_sources:
                    if inp.get("link_type") == "2":
                        lookup_ref_source = inp["stage_name"]
                    else:
                        main_input_source = inp["stage_name"]
            elif stage_type == "PxJoin":
                if len(input_sources) >= 2:
                    main_input_source = input_sources[0]["stage_name"]
                    lookup_ref_source = input_sources[-1]["stage_name"]
                elif len(input_sources) == 1:
                    lookup_ref_source = input_sources[0]["stage_name"]

            link_type_str = "PxJoin (Parallel Join)" if stage_type == "PxJoin" else "PxLookup (Parallel Lookup)"
            if stage_type == "PxJoin" and join_operator:
                op_label = join_operator.replace("join", " Join").replace("outer", "Outer ").replace("inner", "Inner ").replace("left", "Left ").replace("right", "Right ").strip()
                link_type_str = f"PxJoin ({op_label})"

            lookup_entry: Dict[str, Any] = {
                "link_type": link_type_str,
                "lookup_name": stage_name,
                "link_name": stage_name,
                "stage_name": stage_name,
                "file_name": lookup_ref_source or stage_name,
                "directory": "",
                "columns": output_cols,
                "key_columns": key_cols,
                "key_expressions": key_exprs,
                "returned_columns": returned_cols,
                "input_sources": input_sources,
                "main_input": main_input_source,
                "ref_input": lookup_ref_source,
            }
            lookups.append(lookup_entry)

        return lookups

    # ------------------------------------------------------------------
    def get_lookup_columns(self, record_type: str = "HashedOutput") -> Dict[str, List[Dict[str, Any]]]:
        lookups: Dict[str, List[Dict[str, Any]]] = {}
        job = self.root.find("Job")
        if job is None:
            return lookups
        for record in job.findall("Record"):
            if record.get("Type") != record_type:
                continue
            link_name = ""
            file_name = ""
            for prop in record.findall("Property"):
                if prop.get("Name") == "Name":
                    link_name = prop.text or ""
                elif prop.get("Name") == "FileName":
                    file_name = prop.text or ""
            cols: List[Dict[str, Any]] = []
            cols_coll = record.find("Collection[@Type='OutputColumn']")
            if cols_coll is not None:
                for sub in cols_coll.findall("SubRecord"):
                    col: Dict[str, Any] = {}
                    for prop in sub.findall("Property"):
                        n = prop.get("Name", "")
                        t = prop.text or ""
                        if n == "Name":
                            col["name"] = t
                        elif n == "SqlType":
                            col["sql_type"] = int(t) if t else 0
                        elif n == "Precision":
                            col["precision"] = int(t) if t else 0
                        elif n == "Scale":
                            col["scale"] = int(t) if t else 0
                        elif n == "Nullable":
                            col["nullable"] = t == "1"
                        elif n == "KeyExpression":
                            col["key_expression"] = t
                    if "name" in col:
                        cols.append(col)
            key = file_name or link_name
            if key:
                lookups[key] = cols
        return lookups

    # ------------------------------------------------------------------
    def get_target_table_name(self) -> str:
        # Method 1: Parallel jobs - TableName in target CustomStage XMLProperties
        xml_props = self._get_custom_stage_xml_properties("target")
        if xml_props:
            table_ref = self._extract_cdata_from_xml_props(xml_props, "TableName")
            if table_ref:
                # Extract schema from parameterized references like
                # #TargetDWConnectionString.$TARGET_DW_DB_SCHEMA#.FMIS_LIMRA_EXTRACT
                schema_match = re.search(r"#[^#]*?\.\$([^#]+)#", table_ref)
                if schema_match:
                    schema_var = f"$${schema_match.group(1)}"
                    table_name = re.sub(r"#[^#]+#\.", "", table_ref).strip()
                    return f"{schema_var}.{table_name}"
                # Non-parameterized: clean up and return
                cleaned = re.sub(r"#[^#]+#", "", table_ref).strip(".")
                return cleaned if cleaned else table_ref

        # Method 2: Server jobs - TableDef from TrxOutput columns
        columns = self.get_transformer_output_columns()
        for col in columns:
            table_def = col.get("table_def", "")
            if table_def:
                parts = table_def.split("\\")
                return parts[-1] if parts else table_def
        return ""

    # ------------------------------------------------------------------
    def get_links(self) -> List[Dict[str, str]]:
        """Extract link definitions showing data flow between stages."""
        links: List[Dict[str, str]] = []
        job = self.root.find("Job")
        if job is None:
            return links
        for record in job.findall("Record"):
            rec_type = record.get("Type", "")
            if rec_type in ("CustomStage", "TransformerStage",
                            "SeqFileStage", "HashedFileStage"):
                input_pins = record.find("Collection[@Name='InputPins']")
                output_pins = record.find("Collection[@Name='OutputPins']")
                stage_name = ""
                for prop in record.findall("Property"):
                    if prop.get("Name") == "Name":
                        stage_name = prop.text or ""
                        break
                if output_pins:
                    for sub in output_pins.findall("SubRecord"):
                        for prop in sub.findall("Property"):
                            if prop.get("Name") == "Name":
                                links.append({
                                    "link_name": prop.text or "",
                                    "from_stage": stage_name,
                                })
        return links

    # ------------------------------------------------------------------
    def get_job_flow(self) -> List[Dict[str, Any]]:
        """Build an ordered job flow showing data movement from sources through
        lookups/stages to the target.

        Returns a list of dicts in execution order, each with:
            step, stage_name, stage_type, role (Source/Lookup/Transform/Join/Target/...),
            input_links (list of link names feeding in),
            output_links (list of link names going out),
            link_to_next (the link name connecting to the next step),
            details (physical table, SQL summary, etc.)
        """
        job = self.root.find("Job")
        if job is None:
            return []

        # --- Step 1: Collect all stages with their pins -----------------
        stages: Dict[str, Dict[str, Any]] = {}  # keyed by record Identifier
        for record in job.findall("Record"):
            rec_type = record.get("Type", "")
            rec_id = record.get("Identifier", "")
            if rec_type in ("CustomStage", "TransformerStage",
                            "CTransformerStage", "SeqFileStage",
                            "HashedFileStage"):
                info: Dict[str, Any] = {
                    "id": rec_id, "name": "", "stage_type": "",
                    "rec_type": rec_type,
                    "input_pin_ids": [], "output_pin_ids": [],
                    "context": "",  # source / target / ""
                }
                for prop in record.findall("Property"):
                    n = prop.get("Name", "")
                    if n == "Name":
                        info["name"] = prop.text or ""
                    elif n == "StageType":
                        info["stage_type"] = prop.text or ""
                    elif n == "InputPins" and prop.text:
                        info["input_pin_ids"] = [
                            p.strip() for p in prop.text.split("|") if p.strip()
                        ]
                    elif n == "OutputPins" and prop.text:
                        info["output_pin_ids"] = [
                            p.strip() for p in prop.text.split("|") if p.strip()
                        ]
                if rec_type in ("TransformerStage", "CTransformerStage"):
                    info["stage_type"] = "CTransformerStage"
                # Detect context (source/target) for CustomStages
                if rec_type == "CustomStage":
                    props_coll = record.find("Collection[@Type='CustomProperty']")
                    if props_coll is not None:
                        for sub in props_coll.findall("SubRecord"):
                            name_prop = sub.find("Property[@Name='Name']")
                            val_prop = sub.find("Property[@Name='Value']")
                            if (name_prop is not None
                                    and name_prop.text == "Context"
                                    and val_prop is not None):
                                info["context"] = (val_prop.text or "").strip()
                stages[rec_id] = info

        # --- Step 2: Collect pin info (name, partner, link type) --------
        pin_info: Dict[str, Dict[str, str]] = {}  # pin_id -> {name, partner, link_type, rec_type}
        for record in job.findall("Record"):
            rec_type = record.get("Type", "")
            rec_id = record.get("Identifier", "")
            if rec_type in ("CustomOutput", "CustomInput",
                            "TrxOutput", "TrxInput"):
                pinfo: Dict[str, str] = {"rec_type": rec_type, "name": "", "partner": "", "link_type": ""}
                for prop in record.findall("Property"):
                    n = prop.get("Name", "")
                    if n == "Name":
                        pinfo["name"] = prop.text or ""
                    elif n == "Partner":
                        pinfo["partner"] = prop.text or ""
                    elif n == "LinkType":
                        pinfo["link_type"] = prop.text or ""
                pin_info[rec_id] = pinfo

        # --- Step 3: Build adjacency (stage_id -> list of downstream stage_ids) ---
        # An output pin on stage A has a Partner pointing to an input pin on stage B.
        # Partner format: "V25S0|V25S0P2"  => stage_id | pin_id
        pin_to_stage: Dict[str, str] = {}
        for sid, sinfo in stages.items():
            for pid in sinfo["input_pin_ids"] + sinfo["output_pin_ids"]:
                pin_to_stage[pid] = sid

        # edges: list of (from_stage_id, to_stage_id, link_name, link_type)
        edges: List[tuple] = []
        for sid, sinfo in stages.items():
            for opin_id in sinfo["output_pin_ids"]:
                opin = pin_info.get(opin_id, {})
                partner = opin.get("partner", "")
                link_name = opin.get("name", "")
                if partner:
                    # Partner target: "target_stage_id|target_pin_id"
                    parts = partner.split("|")
                    target_stage_id = parts[0]
                    target_pin_id = parts[1] if len(parts) > 1 else ""
                    # Get the link type from the target input pin
                    target_pin = pin_info.get(target_pin_id, {})
                    lt = target_pin.get("link_type", "")
                    if target_stage_id in stages:
                        edges.append((sid, target_stage_id, link_name, lt))

        # --- Step 4: Topological sort for execution order ---------------
        from collections import deque
        adj: Dict[str, List[str]] = {sid: [] for sid in stages}
        in_degree: Dict[str, int] = {sid: 0 for sid in stages}
        for (src, dst, _, _) in edges:
            adj[src].append(dst)
            in_degree[dst] += 1

        queue: deque = deque()
        for sid in stages:
            if in_degree[sid] == 0:
                queue.append(sid)
        topo_order: List[str] = []
        while queue:
            node = queue.popleft()
            topo_order.append(node)
            for nb in adj[node]:
                in_degree[nb] -= 1
                if in_degree[nb] == 0:
                    queue.append(nb)
        # Append any stages not reached (shouldn't happen in valid jobs)
        for sid in stages:
            if sid not in topo_order:
                topo_order.append(sid)

        # --- Step 5: Build per-stage input/output link lists ------------
        stage_input_links: Dict[str, List[str]] = {sid: [] for sid in stages}
        stage_output_links: Dict[str, List[str]] = {sid: [] for sid in stages}
        stage_input_link_types: Dict[str, Dict[str, str]] = {sid: {} for sid in stages}
        for (src, dst, link_name, lt) in edges:
            stage_output_links[src].append(link_name)
            stage_input_links[dst].append(link_name)
            stage_input_link_types[dst][link_name] = lt

        # --- Step 6: Determine role and details -------------------------
        def _classify_role(sinfo: Dict[str, Any], sid: str) -> str:
            ctx = sinfo.get("context", "")
            stype = sinfo.get("stage_type", "")
            rtype = sinfo.get("rec_type", "")
            if ctx == "source":
                return "Source"
            if ctx == "target":
                return "Target"
            if stype == "PxLookup":
                return "Lookup"
            if stype == "PxJoin":
                return "Join"
            if stype in ("PxFunnel",):
                return "Funnel"
            if stype in ("PxRemDup",):
                return "Remove Duplicates"
            if stype in ("PxFilter",):
                return "Filter"
            if stype in ("PxSort",):
                return "Sort"
            if stype in ("PxDataSet",):
                return "DataSet"
            if rtype in ("TransformerStage", "CTransformerStage") or stype == "CTransformerStage":
                return "Transformer"
            if rtype in ("SeqFileStage",):
                return "Sequential File"
            if rtype in ("HashedFileStage",):
                return "Hashed File"
            # Connector stages without context - check if they have only outputs (source-like)
            if not sinfo["input_pin_ids"] and sinfo["output_pin_ids"]:
                return "Source"
            if sinfo["input_pin_ids"] and not sinfo["output_pin_ids"]:
                return "Target"
            return stype or rtype

        def _get_details(sinfo: Dict[str, Any]) -> str:
            """Get extra details like physical table name from XMLProperties."""
            if sinfo.get("rec_type") != "CustomStage":
                return ""
            # Find the stage record and extract TableName from XMLProperties
            rec = job.find(f"Record[@Identifier='{sinfo['id']}']")
            if rec is None:
                return ""
            props_coll = rec.find("Collection[@Type='CustomProperty']")
            if props_coll is None:
                return ""
            xml_props_val = ""
            for sub in props_coll.findall("SubRecord"):
                name_prop = sub.find("Property[@Name='Name']")
                val_prop = sub.find("Property[@Name='Value']")
                if (name_prop is not None
                        and name_prop.text == "XMLProperties"
                        and val_prop is not None):
                    xml_props_val = val_prop.text or ""
            if xml_props_val:
                tbl = self._extract_cdata_from_xml_props(xml_props_val, "TableName")
                if tbl:
                    cleaned = re.sub(r"#[^#]+#", "", tbl).strip(".")
                    return cleaned
            return ""

        # --- Step 7: Build the ordered flow list ------------------------
        flow: List[Dict[str, Any]] = []
        for step_num, sid in enumerate(topo_order, 1):
            sinfo = stages[sid]
            role = _classify_role(sinfo, sid)
            details = _get_details(sinfo)

            # Build input link descriptions with type annotation
            input_link_descs: List[str] = []
            for lname in stage_input_links[sid]:
                lt = stage_input_link_types[sid].get(lname, "")
                if lt == "2":
                    input_link_descs.append(f"{lname} (reference)")
                elif lt == "1":
                    input_link_descs.append(f"{lname} (stream)")
                else:
                    input_link_descs.append(lname)

            flow.append({
                "step": step_num,
                "stage_name": sinfo["name"],
                "stage_type": sinfo.get("stage_type", "") or sinfo.get("rec_type", ""),
                "role": role,
                "input_links": input_link_descs,
                "output_links": stage_output_links[sid],
                "details": details,
            })

        return flow


# ============================================================================
# SQL Column Parser - Decomposes source SQL into per-column expressions
# ============================================================================
class SqlColumnParser:
    """Parses SQL SELECT clauses to build per-column expression maps.

    Handles CTE (WITH ... AS) queries, nested subqueries, window functions,
    CASE expressions, aggregates, Oracle-style outer joins, and parameterized refs.
    """

    def parse_sql(self, sql: str) -> Dict[str, Dict[str, str]]:
        """Parse a SQL statement and return per-column mapping.

        Returns dict mapping column_alias -> {
            "expression": SQL expression from outer SELECT,
            "cte_expression": deeper CTE-level expression if traceable,
            "physical_tables": comma-separated base tables,
            "transformation_type": direct/aggregation/case/window/expression/constant,
            "cte_name": which CTE provides this column (if applicable),
        }
        """
        if not sql or not sql.strip():
            return {}

        sql_clean = sql.strip()
        result: Dict[str, Dict[str, str]] = {}

        # Detect CTE queries
        ctes = self._extract_ctes(sql_clean)
        if ctes:
            # Find the final SELECT after all CTEs
            final_select = self._find_final_select(sql_clean)
            if not final_select:
                return result
            outer_cols = self._parse_select_columns(final_select)
            result = self._resolve_cte_columns(outer_cols, ctes, sql_clean)
        else:
            # Simple or subquery SELECT
            outer_cols = self._parse_select_columns(sql_clean)
            tables = self._extract_physical_tables(sql_clean)
            tables_str = ", ".join(tables)
            for col in outer_cols:
                alias = col["alias"].upper()
                expr = col["expression"].strip()
                ttype = self._classify_expression(expr)
                # For simple TABLE.COL passthrough, mark as direct
                result[alias] = {
                    "expression": expr,
                    "cte_expression": "",
                    "physical_tables": tables_str,
                    "transformation_type": ttype,
                    "cte_name": "",
                }

        return result

    # ------------------------------------------------------------------
    @staticmethod
    def _extract_ctes(sql: str) -> Dict[str, str]:
        """Extract CTE name -> CTE body SQL from a WITH clause."""
        stripped = sql.strip()
        if not re.match(r"(?i)^WITH\s", stripped):
            return {}

        ctes: Dict[str, str] = {}
        pos = 4  # skip "WITH"
        length = len(stripped)

        while pos < length:
            # Skip whitespace and commas
            while pos < length and stripped[pos] in (" ", "\t", "\n", "\r", ","):
                pos += 1
            if pos >= length:
                break

            # Check if we've hit the final SELECT (not inside a CTE)
            rest = stripped[pos:]
            if re.match(r"(?i)^SELECT\s", rest):
                break

            # Match CTE name: NAME AS (
            m = re.match(r"(?i)(\w+)\s+AS\s*\(", rest)
            if not m:
                break

            cte_name = m.group(1)
            # Position of the opening paren
            paren_start = pos + m.end() - 1
            # Find matching closing paren using depth tracking
            depth = 1
            i = paren_start + 1
            while i < length and depth > 0:
                ch = stripped[i]
                if ch == "(":
                    depth += 1
                elif ch == ")":
                    depth -= 1
                elif ch == "'":
                    # Skip string literals
                    i += 1
                    while i < length and stripped[i] != "'":
                        i += 1
                i += 1

            if depth == 0:
                body = stripped[paren_start + 1 : i - 1].strip()
                ctes[cte_name] = body
                pos = i
            else:
                break

        return ctes

    # ------------------------------------------------------------------
    @staticmethod
    def _find_final_select(sql: str) -> str:
        """Find the final SELECT statement at paren depth 0 (after all CTEs)."""
        stripped = sql.strip()
        length = len(stripped)
        depth = 0
        last_select_pos = -1

        i = 0
        while i < length:
            ch = stripped[i]
            if ch == "(":
                depth += 1
            elif ch == ")":
                depth -= 1
            elif ch == "'":
                # Skip string literals
                i += 1
                while i < length and stripped[i] != "'":
                    i += 1
            elif depth == 0:
                rest = stripped[i:]
                if re.match(r"(?i)^SELECT\s", rest):
                    last_select_pos = i
            i += 1

        if last_select_pos >= 0:
            return stripped[last_select_pos:]
        return ""

    # ------------------------------------------------------------------
    @staticmethod
    def _find_from_at_depth_zero(sql: str, start: int = 0) -> int:
        """Find the position of the first FROM keyword at paren depth 0."""
        length = len(sql)
        depth = 0
        i = start
        while i < length:
            ch = sql[i]
            if ch == "(":
                depth += 1
            elif ch == ")":
                depth -= 1
            elif ch == "'":
                i += 1
                while i < length and sql[i] != "'":
                    i += 1
            elif depth == 0:
                rest = sql[i:]
                if re.match(r"(?i)^FROM\s", rest):
                    return i
            i += 1
        return -1

    # ------------------------------------------------------------------
    def _parse_select_columns(self, sql: str) -> List[Dict[str, str]]:
        """Parse a SELECT clause into individual column entries.

        Returns list of dicts: {"expression": ..., "alias": ...}
        """
        stripped = sql.strip()

        # Find SELECT keyword
        m = re.match(r"(?i)^SELECT\s+", stripped)
        if not m:
            return []
        select_start = m.end()

        # Strip DISTINCT and Oracle hints
        rest = stripped[select_start:]
        rest = re.sub(r"(?i)^DISTINCT\s+", "", rest)
        rest = re.sub(r"/\*\+.*?\*/\s*", "", rest, flags=re.DOTALL)

        # Find FROM at depth 0
        from_pos = self._find_from_at_depth_zero(rest)
        if from_pos > 0:
            select_body = rest[:from_pos].strip()
        else:
            select_body = rest.strip()

        # Split by commas at paren depth 0
        columns: List[str] = []
        depth = 0
        current = []
        for ch in select_body:
            if ch == "(":
                depth += 1
                current.append(ch)
            elif ch == ")":
                depth -= 1
                current.append(ch)
            elif ch == "'" :
                current.append(ch)
            elif ch == "," and depth == 0:
                columns.append("".join(current).strip())
                current = []
            else:
                current.append(ch)
        if current:
            columns.append("".join(current).strip())

        result: List[Dict[str, str]] = []
        for col_expr in columns:
            if not col_expr:
                continue
            alias, expression = self._extract_alias(col_expr)
            if alias:
                result.append({"expression": expression, "alias": alias})

        return result

    # ------------------------------------------------------------------
    @staticmethod
    def _extract_alias(col_expr: str) -> Tuple[str, str]:
        """Extract alias and expression from a column expression.

        Handles: expr AS alias, expr alias (implicit), TABLE.COL, bare COL
        """
        stripped = col_expr.strip().rstrip(",")
        if len(stripped) > 4096:
            return stripped[:64], stripped

        # Pattern: ... AS alias
        m = re.match(r"(?i)^(.+?)\s+[Aa][Ss]\s+(\w+)\s*$", stripped)
        if m:
            return m.group(2), m.group(1).strip()

        # Pattern: closing paren followed by alias with no space: )ALIAS
        m = re.search(r"\)\s*(\w+)\s*$", stripped)
        if m:
            alias_candidate = m.group(1)
            # Make sure it's not a SQL keyword
            keywords = {"FROM", "WHERE", "AND", "OR", "NOT", "IN", "IS", "NULL",
                        "THEN", "ELSE", "END", "WHEN", "CASE", "AS", "ON", "BY",
                        "GROUP", "ORDER", "HAVING", "BETWEEN", "LIKE", "JOIN",
                        "LEFT", "RIGHT", "OUTER", "INNER", "FULL", "CROSS"}
            if alias_candidate.upper() not in keywords:
                expr = stripped[: m.start() + 1].strip()
                return alias_candidate, expr

        # Pattern: expr followed by space and a simple word alias
        # e.g., "SUM(x) my_alias" or "a.col my_alias"
        m = re.match(r"^(.+?)\s+(\w+)\s*$", stripped)
        if m:
            potential_alias = m.group(2)
            potential_expr = m.group(1).strip()
            keywords = {"FROM", "WHERE", "AND", "OR", "NOT", "IN", "IS", "NULL",
                        "THEN", "ELSE", "END", "WHEN", "CASE", "AS", "ON", "BY",
                        "GROUP", "ORDER", "HAVING", "BETWEEN", "LIKE", "DESC",
                        "ASC", "NULLS", "LAST", "FIRST", "JOIN", "LEFT", "RIGHT",
                        "OUTER", "INNER", "FULL", "CROSS", "SELECT", "DISTINCT"}
            if potential_alias.upper() not in keywords:
                # Verify the expression part has balanced parens
                depth = 0
                for ch in potential_expr:
                    if ch == "(":
                        depth += 1
                    elif ch == ")":
                        depth -= 1
                if depth == 0:
                    return potential_alias, potential_expr

        # Pattern: TABLE.COL or SCHEMA.TABLE.COL
        if "." in stripped and "(" not in stripped and " " not in stripped:
            alias = stripped.split(".")[-1]
            return alias, stripped

        # Pattern: bare column name
        if re.match(r"^\w+$", stripped):
            return stripped, stripped

        # Pattern: expression with * (SELECT *)
        if stripped.strip() == "*":
            return "*", "*"

        # Fallback: use the whole expression as alias (cleaned)
        # Try to find last word
        words = stripped.split()
        if words:
            last_word = words[-1].strip(")")
            if re.match(r"^\w+$", last_word):
                return last_word, stripped
        return "", stripped

    # ------------------------------------------------------------------
    def _parse_nested_subquery_columns(self, sql_body: str) -> List[Dict[str, str]]:
        """Parse columns from a nested subquery in a FROM clause.

        Given a CTE body like:
            SELECT col1, SUM(col2) AS agg FROM (SELECT ... AS col1, CASE ... AS col2 FROM tbl) ...
        This finds and parses the innermost SELECT to extract the real expressions.
        """
        # Find subquery in FROM clause: FROM (SELECT ...)
        m = re.search(r"(?i)\bFROM\s*\(", sql_body)
        if not m:
            return []
        # Track parens to find the matching close
        start = m.end() - 1  # position of '('
        depth = 1
        i = start + 1
        length = len(sql_body)
        while i < length and depth > 0:
            ch = sql_body[i]
            if ch == "(":
                depth += 1
            elif ch == ")":
                depth -= 1
            elif ch == "'":
                i += 1
                while i < length and sql_body[i] != "'":
                    i += 1
            i += 1
        if depth == 0:
            inner_sql = sql_body[start + 1 : i - 1].strip()
            return self._parse_select_columns(inner_sql)
        return []

    def _resolve_cte_columns(
        self,
        outer_columns: List[Dict[str, str]],
        ctes: Dict[str, str],
        full_sql: str,
    ) -> Dict[str, Dict[str, str]]:
        """Resolve outer SELECT columns through CTE definitions."""
        result: Dict[str, Dict[str, str]] = {}

        # Parse each CTE's columns and physical tables
        cte_parsed: Dict[str, List[Dict[str, str]]] = {}
        cte_tables: Dict[str, List[str]] = {}
        # Also parse nested subquery columns within each CTE
        cte_inner_parsed: Dict[str, List[Dict[str, str]]] = {}
        for cte_name, cte_body in ctes.items():
            cte_parsed[cte_name] = self._parse_select_columns("SELECT " + cte_body
                                                               if not re.match(r"(?i)^\s*SELECT\s", cte_body)
                                                               else cte_body)
            cte_tables[cte_name] = self._extract_physical_tables(cte_body)
            # Parse nested subquery if present
            cte_inner_parsed[cte_name] = self._parse_nested_subquery_columns(cte_body)

        for col in outer_columns:
            alias = col["alias"].upper()
            expr = col["expression"].strip()

            # Determine which CTE this references
            cte_name = ""
            cte_col_name = ""
            if "." in expr and "(" not in expr and " " not in expr:
                parts = expr.split(".")
                potential_cte = parts[0]
                cte_col_name = parts[-1]
                if potential_cte in ctes:
                    cte_name = potential_cte

            if cte_name and cte_col_name:
                # Look up the column in the CTE's parsed columns
                cte_cols = cte_parsed.get(cte_name, [])
                cte_expr = ""
                for cc in cte_cols:
                    if cc["alias"].upper() == cte_col_name.upper():
                        cte_expr = cc["expression"]
                        break

                if not cte_expr:
                    cte_expr = cte_col_name

                # Check if CTE expression itself references another CTE
                deeper_expr = cte_expr
                if "." in cte_expr and "(" not in cte_expr and " " not in cte_expr:
                    inner_parts = cte_expr.split(".")
                    inner_cte = inner_parts[0]
                    inner_col = inner_parts[-1]
                    if inner_cte in ctes:
                        inner_cte_cols = cte_parsed.get(inner_cte, [])
                        for icc in inner_cte_cols:
                            if icc["alias"].upper() == inner_col.upper():
                                deeper_expr = icc["expression"]
                                break

                # If the CTE-level expression is still "direct" (bare column name),
                # trace into the CTE's nested subquery for the real expression
                ttype = self._classify_expression(deeper_expr)
                if ttype == "direct" and cte_inner_parsed.get(cte_name):
                    inner_cols = cte_inner_parsed[cte_name]
                    for ic in inner_cols:
                        if ic["alias"].upper() == deeper_expr.upper():
                            inner_expr = ic["expression"]
                            inner_ttype = self._classify_expression(inner_expr)
                            if inner_ttype != "direct":
                                deeper_expr = inner_expr
                                ttype = inner_ttype
                            break

                tables = cte_tables.get(cte_name, [])
                # Also include tables from referenced inner CTEs
                if "." in cte_expr and "(" not in cte_expr:
                    inner_cte_ref = cte_expr.split(".")[0]
                    if inner_cte_ref in cte_tables:
                        for t in cte_tables[inner_cte_ref]:
                            if t not in tables:
                                tables.append(t)

                result[alias] = {
                    "expression": expr,
                    "cte_expression": deeper_expr if deeper_expr != cte_col_name else cte_expr,
                    "physical_tables": ", ".join(tables),
                    "transformation_type": ttype,
                    "cte_name": cte_name,
                }
            else:
                # Not a CTE reference - direct expression in outer SELECT
                all_tables = []
                for tlist in cte_tables.values():
                    for t in tlist:
                        if t not in all_tables:
                            all_tables.append(t)
                # Also get tables from the final SELECT's FROM clause
                final_tables = self._extract_physical_tables(
                    self._find_final_select(full_sql) or full_sql
                )
                for t in final_tables:
                    if t not in all_tables:
                        all_tables.append(t)

                ttype = self._classify_expression(expr)
                result[alias] = {
                    "expression": expr,
                    "cte_expression": expr,
                    "physical_tables": ", ".join(all_tables),
                    "transformation_type": ttype,
                    "cte_name": "",
                }

        return result

    # ------------------------------------------------------------------
    @staticmethod
    def _extract_physical_tables(sql: str) -> List[str]:
        """Extract schema.table or plain table names from FROM/JOIN clauses.

        Searches the entire SQL including nested subqueries.
        Handles parameterized refs like #Schema#.TABLE_NAME.
        Skips SQL keywords and short aliases.
        """
        tables: List[str] = []
        skip_keywords = {
            "SELECT", "WHERE", "AND", "OR", "ON", "IN", "AS",
            "CASE", "WHEN", "THEN", "ELSE", "END", "NOT", "NULL",
            "GROUP", "ORDER", "HAVING", "BETWEEN", "EXISTS",
            "DUAL", "LEFT", "RIGHT", "OUTER", "INNER", "FULL",
            "CROSS", "NATURAL", "SET", "INTO", "VALUES", "UPDATE",
            "DELETE", "INSERT", "CREATE", "ALTER", "DROP", "TABLE",
        }
        # Pattern 1: parameterized refs like #...#.TABLE_NAME
        for m in re.finditer(
            r"(?:FROM|JOIN)\s+(?:\(\s*)*#[^#]+#\.(\w+)", sql, re.IGNORECASE
        ):
            table = m.group(1)
            if table.upper() not in skip_keywords and table not in tables:
                tables.append(table)

        # Pattern 2: standard schema.table or plain table
        for m in re.finditer(
            r"(?:FROM|JOIN)\s+(?:\(\s*)*(\w+\.\w+)", sql, re.IGNORECASE
        ):
            table = m.group(1)
            cleaned = re.sub(r"#[^#]+#", "", table).strip(".")
            upper = cleaned.upper()
            if upper not in skip_keywords and len(cleaned) > 2 and cleaned not in tables:
                tables.append(cleaned)

        # Pattern 3: plain table names (no schema)
        for m in re.finditer(
            r"(?:FROM|JOIN)\s+(?:\(\s*)*(\w+)(?:\s|$|,)", sql, re.IGNORECASE
        ):
            table = m.group(1)
            upper = table.upper()
            if upper not in skip_keywords and len(table) > 2 and table not in tables:
                tables.append(table)

        return tables

    # ------------------------------------------------------------------
    @staticmethod
    def _extract_join_info(sql: str) -> List[Dict[str, str]]:
        """Extract JOIN clauses and their conditions from SQL."""
        joins: List[Dict[str, str]] = []
        # Match various JOIN types
        pattern = r"((?:LEFT|RIGHT|FULL)?\s*(?:OUTER)?\s*JOIN)\s+(\w+(?:\.\w+)?)\s+(?:(\w+)\s+)?ON\s+(.*?)(?=(?:LEFT|RIGHT|FULL|INNER|CROSS)?\s*(?:OUTER)?\s*JOIN\s|WHERE\s|GROUP\s|ORDER\s|$)"
        for m in re.finditer(pattern, sql, re.IGNORECASE | re.DOTALL):
            join_type = re.sub(r"\s+", " ", m.group(1).strip().upper())
            table = m.group(2)
            condition = m.group(4).strip().rstrip(",").strip()
            joins.append({
                "join_type": join_type,
                "table": table,
                "condition": condition,
            })
        return joins

    # ------------------------------------------------------------------
    @staticmethod
    def _classify_expression(expr: str) -> str:
        """Classify a SQL expression into a transformation type."""
        if not expr:
            return "direct"

        upper = expr.upper().strip()

        # Literal constants
        if re.match(r"^-?\d+(\.\d+)?$", upper) or re.match(r"^'[^']*'$", upper):
            return "constant"

        # Simple column reference: TABLE.COL or just COL
        if re.match(r"^\w+(\.\w+)?$", upper):
            return "direct"

        # Window functions
        if " OVER " in upper or "OVER(" in upper:
            return "window"

        # CASE expressions
        if "CASE " in upper or "CASE\n" in upper:
            return "case"

        # Aggregate functions
        if re.search(r"\b(SUM|COUNT|AVG|MAX|MIN|FIRST_VALUE|LAST_VALUE|RANK)\s*\(", upper):
            return "aggregation"

        return "expression"

    # ------------------------------------------------------------------
    @staticmethod
    def _type_label(ttype: str) -> str:
        """Convert classification type to human-readable label."""
        labels = {
            "direct": "Direct Move",
            "aggregation": "Aggregation",
            "case": "CASE expression",
            "window": "Window function",
            "expression": "Expression",
            "constant": "Constant",
        }
        return labels.get(ttype, "Expression")

    # ------------------------------------------------------------------
    @staticmethod
    def _extract_outer_function(expr: str):
        """Extract outermost function call using balanced paren tracking.

        Returns (func_name, inner_args, suffix_after_close_paren) or None.
        suffix captures the OVER clause for window functions.
        Returns None if there is arithmetic/other content after the function call
        (i.e., the expression is not a single function call).
        """
        expr_stripped = expr.strip()
        func_names = (
            "SUM", "COUNT", "AVG", "MAX", "MIN",
            "NVL", "NVL2", "COALESCE", "NULLIF", "DECODE",
            "TRIM", "LTRIM", "RTRIM", "UPPER", "LOWER",
            "TO_CHAR", "TO_DATE", "TO_NUMBER", "TO_TIMESTAMP",
            "SUBSTR", "REPLACE", "LPAD", "RPAD", "TRANSLATE",
            "ROUND", "TRUNC", "ABS", "SIGN", "MOD", "CEIL", "FLOOR",
            "LENGTH", "INSTR", "CONCAT", "CAST", "CONVERT",
            "FIRST_VALUE", "LAST_VALUE", "RANK", "ROW_NUMBER",
            "DENSE_RANK", "LEAD", "LAG", "NTILE",
        )
        pattern = r"(?i)^(" + "|".join(func_names) + r")\s*\("
        m = re.match(pattern, expr_stripped)
        if not m:
            return None

        func_name = m.group(1).upper()
        paren_start = m.end() - 1

        # Find matching close paren using depth tracking
        depth = 1
        i = paren_start + 1
        while i < len(expr_stripped) and depth > 0:
            ch = expr_stripped[i]
            if ch == "(":
                depth += 1
            elif ch == ")":
                depth -= 1
            elif ch == "'":
                i += 1
                while i < len(expr_stripped) and expr_stripped[i] != "'":
                    i += 1
            i += 1

        if depth != 0:
            return None

        inner = expr_stripped[paren_start + 1 : i - 1].strip()
        suffix = expr_stripped[i:].strip()

        # If there's content after the close paren that is NOT an OVER clause,
        # this is not a single outer function (e.g., SUM(x) - SUM(y))
        if suffix and not re.match(r"(?i)^\s*OVER\s*\(", suffix):
            return None

        return (func_name, inner, suffix)

    # ------------------------------------------------------------------
    @staticmethod
    def _has_significant_inner_logic(inner: str) -> bool:
        """Check if inner expression has transformation logic worth decomposing."""
        upper = inner.upper().strip()
        # CASE expression
        if re.search(r"\bCASE\b", upper):
            return True
        # Aggregate function (nested)
        if re.search(r"\b(SUM|COUNT|AVG|MAX|MIN)\s*\(", upper):
            return True
        # Window function
        if " OVER " in upper or "OVER(" in upper:
            return True
        # Expression functions that indicate a transformation step
        if re.search(
            r"\b(NVL|NVL2|COALESCE|DECODE|TRIM|LTRIM|RTRIM|TO_CHAR|TO_DATE|"
            r"TO_NUMBER|SUBSTR|REPLACE|UPPER|LOWER|ROUND|TRUNC)\s*\(",
            upper,
        ):
            return True
        return False

    # ------------------------------------------------------------------
    @staticmethod
    def _decompose_expression_levels(expr: str) -> List[Tuple[str, str]]:
        """Decompose a multi-level SQL expression into ordered transformation steps.

        Returns list of (expression_text, classification_label) tuples in
        execution order (innermost transformation first).

        For single-level expressions, returns a single-element list.
        """
        if not expr or not expr.strip():
            return []

        expr = expr.strip()
        classify = SqlColumnParser._classify_expression
        overall_type = classify(expr)

        # Simple expressions: direct column refs, constants
        if overall_type in ("direct", "constant"):
            return [(expr, SqlColumnParser._type_label(overall_type))]

        # Try extracting outermost function
        func_info = SqlColumnParser._extract_outer_function(expr)

        if func_info:
            func_name, inner, suffix = func_info
            is_window = bool(re.match(r"(?i)\s*OVER\s*\(", suffix))

            # Strip DISTINCT for classification but remember it
            has_distinct = bool(re.match(r"(?i)^\s*DISTINCT\s+", inner))
            inner_for_check = re.sub(r"(?i)^\s*DISTINCT\s+", "", inner).strip() if has_distinct else inner

            if SqlColumnParser._has_significant_inner_logic(inner_for_check):
                # Inner expression is complex - decompose it recursively
                inner_levels = SqlColumnParser._decompose_expression_levels(inner_for_check)
                if inner_levels:
                    levels = list(inner_levels)
                    last_step = len(levels)
                    distinct_prefix = "DISTINCT " if has_distinct else ""
                    if is_window:
                        over_part = suffix.strip()
                        outer_expr = f"{func_name}({distinct_prefix}<result of step {last_step}>) {over_part}"
                        levels.append((outer_expr, "Window function"))
                    else:
                        outer_expr = f"{func_name}({distinct_prefix}<result of step {last_step}>)"
                        outer_type_label = SqlColumnParser._type_label(classify(f"{func_name}(x)"))
                        levels.append((outer_expr, outer_type_label))
                    return levels

            # Inner is simple or not worth decomposing - single level
            type_label = "Window function" if is_window else SqlColumnParser._type_label(overall_type)
            return [(expr, type_label)]

        # Not a single outer function - check for CASE expression
        if overall_type == "case":
            return [(expr, "CASE expression")]

        # Arithmetic or complex expression - scan for nested complex functions
        levels = SqlColumnParser._decompose_arithmetic_levels(expr)
        if len(levels) > 1:
            return levels

        # Fallback: single level
        return [(expr, SqlColumnParser._type_label(overall_type))]

    # ------------------------------------------------------------------
    @staticmethod
    def _decompose_arithmetic_levels(expr: str) -> List[Tuple[str, str]]:
        """Decompose an arithmetic expression combining multiple function calls.

        E.g., SUM(A) - SUM(NVL(B, 0)) ->
          1. NVL(B, 0) [Expression]
          2. SUM(A) - SUM(<result of step 1>) [Aggregation]
        """
        func_names_re = (
            r"SUM|COUNT|AVG|MAX|MIN|NVL|NVL2|COALESCE|TRIM|LTRIM|RTRIM|"
            r"UPPER|LOWER|TO_CHAR|TO_DATE|TO_NUMBER|SUBSTR|REPLACE|ROUND|TRUNC|"
            r"FIRST_VALUE|LAST_VALUE|RANK|ROW_NUMBER|DENSE_RANK|LEAD|LAG"
        )
        pattern = re.compile(r"(?i)\b(" + func_names_re + r")\s*\(")

        # Find all top-level function calls (skip nested ones)
        func_calls = []  # (start, end, func_name, inner_args)
        for m in pattern.finditer(expr):
            start = m.start()
            # Skip if inside an already-found function call
            skip = False
            for prev_start, prev_end, _, _ in func_calls:
                if prev_start <= start < prev_end:
                    skip = True
                    break
            if skip:
                continue

            func_name = m.group(1).upper()
            paren_start = m.end() - 1
            depth = 1
            i = paren_start + 1
            while i < len(expr) and depth > 0:
                ch = expr[i]
                if ch == "(":
                    depth += 1
                elif ch == ")":
                    depth -= 1
                elif ch == "'":
                    i += 1
                    while i < len(expr) and expr[i] != "'":
                        i += 1
                i += 1
            if depth == 0:
                inner = expr[paren_start + 1 : i - 1].strip()
                func_calls.append((start, i, func_name, inner))

        # For each function call, check if inner has significant logic
        levels = []
        replacements = []  # (start, end, replacement_text)

        for start, end, func_name, inner in func_calls:
            if SqlColumnParser._has_significant_inner_logic(inner):
                inner_levels = SqlColumnParser._decompose_expression_levels(inner)
                if inner_levels and inner_levels[-1][1] != "Direct Move":
                    levels.extend(inner_levels)
                    last_step = len(levels)
                    new_call = f"{func_name}(<result of step {last_step}>)"
                    replacements.append((start, end, new_call))

        if not levels:
            return [(expr, SqlColumnParser._type_label(
                SqlColumnParser._classify_expression(expr)
            ))]

        # Apply replacements in reverse order to maintain positions
        modified = expr
        for start, end, replacement in reversed(sorted(replacements)):
            modified = modified[:start] + replacement + modified[end:]

        overall_type = SqlColumnParser._classify_expression(expr)
        levels.append((modified, SqlColumnParser._type_label(overall_type)))
        return levels

    # ------------------------------------------------------------------
    @staticmethod
    def _format_transformation_steps(
        levels: List[Tuple[str, str]],
        cte_name: str = "",
        note_suffix: str = "",
    ) -> str:
        """Format decomposed transformation levels into numbered text.

        If there is only one level, returns the expression with optional note.
        If multiple levels, returns numbered steps with optional note.
        """
        if not levels:
            return ""

        # Build the trailing note line
        note = note_suffix
        if not note and cte_name:
            note = f"-- from CTE {cte_name}"

        if len(levels) == 1:
            text = levels[0][0]
            if note:
                text += f"\n{note}"
            return text

        lines = []
        for i, (step_expr, step_type) in enumerate(levels, 1):
            lines.append(f"{i}. {step_expr}  [{step_type}]")

        if note:
            lines.append(note)

        return "\n".join(lines)


# ============================================================================
# Helper functions
# ============================================================================
def format_data_type(sql_type: int, precision: int, scale: int) -> str:
    type_name = SQL_TYPE_MAP.get(sql_type, f"UNKNOWN({sql_type})")
    if type_name == "VARCHAR":
        return f"VARCHAR({precision})"
    elif type_name == "CHAR":
        return f"CHAR({precision})"
    elif type_name in ("NUMERIC", "DECIMAL") and scale > 0:
        return f"DECIMAL({precision},{scale})"
    elif type_name == "NUMERIC":
        return f"NUMERIC({precision})"
    elif type_name == "DATE":
        return "DATE"
    elif type_name == "TIMESTAMP":
        return "TIMESTAMP"
    elif type_name in ("INTEGER", "SMALLINT", "BIGINT"):
        return type_name
    elif type_name == "FLOAT":
        return f"FLOAT({precision})"
    return type_name


def _strip_link_prefix(expr: str) -> str:
    """Strip DataStage link name prefixes (e.g. fromTrfCalc.COL -> COL)."""
    return re.sub(r"\b\w+\.", "", expr)


def _convert_if_then_else(d: str) -> str:
    """Convert DataStage If/Then/Else to SQL CASE/WHEN/THEN/ELSE/END pseudo code."""
    result = _strip_link_prefix(d)

    # Convert @NULL to NULL
    result = result.replace("@NULL", "NULL")

    # Convert DataStage functions to SQL equivalents inside the expression
    result = re.sub(r"NullToValue\((\w+)\s*,\s*([^)]+)\)", r"COALESCE(\1, \2)", result)
    result = re.sub(r"NullToZero\((\w+)\)", r"COALESCE(\1, 0)", result)
    result = re.sub(r"StringToDecimal\((\w+)\)", r"CAST(\1 AS DECIMAL)", result)

    # Convert DataStage substring notation col[1,3] to SUBSTR(col, 1, 3)
    result = re.sub(r"(\w+)\[(\d+),(\d+)\]", r"SUBSTR(\1, \2, \3)", result)

    # Convert If/Then/Else to CASE/WHEN/THEN/ELSE/END
    result = re.sub(r"\bIf\b", "CASE WHEN", result, flags=re.IGNORECASE)
    result = re.sub(r"\s+Then\b", " THEN", result, flags=re.IGNORECASE)
    result = re.sub(r"\s+Else\s+If\b", "\n  WHEN", result, flags=re.IGNORECASE)
    result = re.sub(r"\s+Else\b", "\n  ELSE", result, flags=re.IGNORECASE)
    result += "\nEND"

    return result


def datastage_to_sql(derivation: str, target_col_name: str = "") -> str:
    """Convert a DataStage derivation expression to platform-independent SQL pseudo code."""
    if not derivation:
        return "Direct Move from source query"

    d = derivation.strip()

    # Strip DataStage type cast/precision annotations like \(20) or \(10,2)
    d = re.sub(r"\\+\(\d+(?:,\d+)?\)", "", d).strip()

    # System macros -> standard SQL date/timestamp functions
    if d in ("DSJobStartDate", "DSJobStartTimestamp"):
        return "CURRENT_DATE"

    # CurrentTimestamp() -> standard SQL
    if d == "CurrentTimestamp()":
        return "CURRENT_TIMESTAMP"

    # Literal numeric constants
    if re.match(r"^-?\d+(\.\d+)?$", d):
        return d

    # Literal string constants (including empty string)
    if re.match(r"^'[^']*'$", d):
        return d

    # Job parameters (standalone identifiers without dots or parens)
    if re.match(r"^[a-zA-Z_]\w*$", d) and "." not in d and "(" not in d:
        if d.startswith("DS"):
            return "CURRENT_DATE"
        return f":{d} (Job Parameter)"

    # date_from_string -> TO_DATE equivalent
    if re.match(r"^date_from_string\(\w+\)$", d, re.IGNORECASE):
        return "CURRENT_DATE"

    # Simple passthrough: CntData.CYC_DT or fromStaging.COL_NAME
    if "." in d and "(" not in d and " " not in d and "[" not in d:
        src_col = d.split(".")[-1]
        if target_col_name and src_col != target_col_name:
            return f"Direct Move (Renamed: {src_col} → {target_col_name})"
        return "Direct Move from source query"

    # Simple trim: trim(CntData.CNT_ID)
    if d.lower().startswith("trim(") and d.endswith(")") and " " not in d:
        inner = d[5:-1]
        if "." in inner:
            col = inner.split(".")[-1]
            return f"TRIM({col})"
        return f"TRIM({inner})"

    # NullToValue(link.COL, default) -> COALESCE(COL, default)
    m = re.match(r"^NullToValue\((?:\w+\.)?(\w+)\s*,\s*(.+)\)$", d, re.IGNORECASE)
    if m:
        col = m.group(1)
        default = m.group(2)
        return f"COALESCE({col}, {default})"

    # NullToZero(link.COL) -> COALESCE(COL, 0)
    m = re.match(r"^NullToZero\((?:\w+\.)?(\w+)\)$", d, re.IGNORECASE)
    if m:
        return f"COALESCE({m.group(1)}, 0)"

    # StringToDecimal(link.COL) -> CAST(COL AS DECIMAL)
    m = re.match(r"^StringToDecimal\((?:\w+\.)?(\w+)\)$", d, re.IGNORECASE)
    if m:
        return f"CAST({m.group(1)} AS DECIMAL)"

    # StringToDate(str, fmt) -> TO_DATE(str, fmt)
    m = re.match(r'^StringToDate\((.+?),\s*"?(.+?)"?\)$', d, re.IGNORECASE)
    if m:
        val = m.group(1)
        fmt = m.group(2).replace("%yyyy", "YYYY").replace("%mm", "MM").replace("%dd", "DD")
        return f"TO_DATE({val}, '{fmt}')"

    # Left(link.COL, n) -> SUBSTR(COL, 1, n)
    m = re.match(r"^Left\((?:\w+\.)?(\w+)\s*,\s*(\d+)\)$", d, re.IGNORECASE)
    if m:
        return f"SUBSTR({m.group(1)}, 1, {m.group(2)})"

    # Checksum(cols) -> HASH(cols)
    m = re.match(r"^Checksum\((.+)\)$", d, re.IGNORECASE)
    if m:
        inner = _strip_link_prefix(m.group(1))
        return f"HASH({inner})"

    # Conditional lookup with concatenation (Server jobs - @NULL pattern)
    if "if " in d.lower() and "@null" in d.lower() and ":" in d:
        parts = d.split("else ")
        if len(parts) > 1:
            else_part = parts[-1].strip()
            concat_parts = else_part.split(":")
            sql_parts = []
            for p in concat_parts:
                p = p.strip()
                if p.lower().startswith("trim(") and "." in p:
                    col = p.split(".")[-1].rstrip(")")
                    sql_parts.append(f"TRIM({col})")
                elif "." in p:
                    col = p.split(".")[-1]
                    sql_parts.append(col)
                else:
                    sql_parts.append(p)
            concat_expr = ", ".join(sql_parts)
            return (
                "CASE\n"
                "  WHEN Lookup.KEY_COL IS NULL THEN NULL\n"
                f"  ELSE CONCAT({concat_expr})\n"
                "END"
            )

    # Conditional lookup without concatenation (Server jobs - @NULL pattern)
    if "if " in d.lower() and "@null" in d.lower():
        parts = d.split("else ")
        col_name = ""
        if len(parts) > 1:
            else_part = parts[-1].strip()
            if "." in else_part:
                col_name = else_part.split(".")[-1].rstrip(")")
                if else_part.lower().startswith("trim("):
                    col_name = f"TRIM({col_name})"
        return (
            "CASE\n"
            "  WHEN Lookup.KEY_COL IS NULL THEN NULL\n"
            f"  ELSE {col_name}\n"
            "END"
        )

    # Trim on lookup column: trim(LkupCntID.CNT_LOB_TP_CD)
    if d.lower().startswith("trim(") and "." in d:
        inner = d[5:-1]
        parts = inner.split(".")
        if len(parts) == 2:
            col = parts[1]
            return f"TRIM({col})"

    # Generic If/Then/Else expressions (Parallel jobs)
    if re.match(r"^If\s+", d, re.IGNORECASE):
        return _convert_if_then_else(d)

    # Fallback: strip link names and return cleaned expression
    cleaned = _strip_link_prefix(d)
    return cleaned


def determine_source_info(
    derivation: str, source_col_str: str, source_table: str,
    source_stage_name: str = "",
    source_link_table_map: Optional[Dict[str, str]] = None,
) -> Tuple[str, str]:
    """Determine source table name and source column name from derivation.
    Uses source_link_table_map to resolve per-column source tables based on
    which source stage link the resolved derivation references."""
    if not derivation:
        return source_table, source_col_str

    d = derivation.strip()

    # Strip DataStage type cast/precision annotations like \(20) or \(10,2)
    d = re.sub(r"\\+\(\d+(?:,\d+)?\)", "", d).strip()

    # System macros / timestamp functions - source is runtime
    if d in ("DSJobStartDate", "DSJobStartTimestamp", "CurrentTimestamp()"):
        return "System Generated", d

    if "date_from_string" in d.lower():
        return "System Generated", d

    # Literal constants
    if re.match(r"^-?\d+(\.\d+)?$", d) or re.match(r"^'[^']*'$", d):
        return "Constant", d

    # Job parameters (standalone identifiers without dots)
    if re.match(r"^[a-zA-Z_]\w*$", d) and "." not in d:
        if d.startswith("DS"):
            return "System Generated", d
        return "Job Parameter", d

    # StringToDate with literal
    if re.match(r"^StringToDate\(", d, re.IGNORECASE):
        return "Constant", d

    # Check lookup references (Server jobs)
    if "LkupAddr." in derivation:
        src_table = "LkupAddrHash (Hashed File Lookup)"
    elif "LkupCntID." in derivation or "LkupCnt." in derivation:
        src_table = "CntLkupHash (Hashed File Lookup)"
    else:
        # Try to resolve per-column source table from the derivation's link prefix
        src_table = ""
        if source_link_table_map and "." in d and "(" not in d and " " not in d:
            link_prefix = d.split(".")[0]
            if link_prefix in source_link_table_map:
                src_table = source_link_table_map[link_prefix]

        # Fallback to default source table logic
        if not src_table:
            if source_stage_name:
                src_table = source_stage_name
            else:
                src_table = source_table

    # Extract column name
    src_col = _extract_source_col(derivation, source_col_str)
    return src_table, src_col


def _extract_source_col(derivation: str, fallback: str) -> str:
    d = derivation.strip()

    # Strip DataStage type cast/precision annotations like \(20) or \(10,2)
    d = re.sub(r"\\+\(\d+(?:,\d+)?\)", "", d).strip()

    # System macros / functions - return as-is
    if d in ("DSJobStartDate", "DSJobStartTimestamp", "CurrentTimestamp()"):
        return d
    # Literal constants
    if re.match(r"^-?\d+(\.\d+)?$", d) or re.match(r"^'[^']*'$", d):
        return d
    # Job parameters
    if re.match(r"^[a-zA-Z_]\w*$", d) and "." not in d:
        return d

    # trim(X.COL) -> COL
    if d.lower().startswith("trim(") and d.endswith(")") and " " not in d:
        inner = d[5:-1]
        return inner.split(".")[-1] if "." in inner else inner
    # X.COL -> COL
    if "." in d and "(" not in d and " " not in d and "[" not in d:
        return d.split(".")[-1]

    # NullToValue(link.COL, val) -> COL
    m = re.match(r"^NullToValue\((?:\w+\.)?(\w+)\s*,", d, re.IGNORECASE)
    if m:
        return m.group(1)
    # NullToZero(link.COL) -> COL
    m = re.match(r"^NullToZero\((?:\w+\.)?(\w+)\)$", d, re.IGNORECASE)
    if m:
        return m.group(1)
    # StringToDecimal(link.COL) -> COL
    m = re.match(r"^StringToDecimal\((?:\w+\.)?(\w+)\)$", d, re.IGNORECASE)
    if m:
        return m.group(1)

    # Conditional: extract from else branch
    if "else " in d.lower():
        else_part = d.split("else ")[-1].strip()
        if ":" in else_part:
            parts = []
            for p in else_part.split(":"):
                p = p.strip()
                if "." in p:
                    parts.append(p.split(".")[-1].rstrip(")"))
            return ", ".join(parts)
        if "." in else_part:
            return else_part.split(".")[-1].rstrip(")")

    # Strip link prefix from fallback (e.g. "toTargetTbl.PolicyID" -> "PolicyID")
    if fallback and "." in fallback and "(" not in fallback and " " not in fallback:
        return fallback.split(".")[-1]
    return fallback


def _cell(ws, row, col, value, font=None, fill=None, alignment=None):
    """Helper to set cell value and style."""
    cell = ws.cell(row=row, column=col, value=value)
    cell.font = font or NORMAL_FONT
    if fill:
        cell.fill = fill
    cell.alignment = alignment or LEFT_WRAP
    cell.border = THIN_BORDER
    return cell


# ============================================================================
# STTM Generator
# ============================================================================
class STTMGenerator(BaseGenerator):
    """Generates STTM Excel workbook from DataStage XML."""

    def __init__(
        self,
        xml_path: Optional[str] = None,
        reference_path: Optional[str] = None,
        plans_dir: str = "plans",
        output_dir: str = "output",
    ) -> None:
        super().__init__(plans_dir=plans_dir, output_dir=output_dir)
        root = get_project_root()
        self.root = root

        if xml_path:
            resolved = (root / xml_path).resolve()
            allowed_input = (root / "input").resolve()
            allowed_kb = (root / "knowledgebase").resolve()
            if not (resolved.is_relative_to(allowed_input)
                    or resolved.is_relative_to(allowed_kb)):
                raise ValueError(
                    f"Path traversal blocked: XML path must be under input/ or knowledgebase/, got {xml_path}"
                )
            self.xml_path: Optional[Path] = resolved
        else:
            self.xml_path = None

        if reference_path:
            resolved_ref = (root / reference_path).resolve()
            allowed_kb = (root / "knowledgebase").resolve()
            if not resolved_ref.is_relative_to(allowed_kb):
                raise ValueError(
                    f"Path traversal blocked: reference path must be under knowledgebase/, got {reference_path}"
                )
            self.reference_path = resolved_ref
        else:
            self.reference_path = root / "knowledgebase" / "cdsaisf_awf_sttm_v1.0.xlsx"

    def _find_all_xmls(self) -> List[Path]:
        """Find all DataStage XML files in input/."""
        input_dir = self.root / "input"
        if input_dir.exists():
            return sorted(input_dir.glob("*.xml"))
        # Fallback to knowledgebase/ for backward compatibility
        kb = self.root / "knowledgebase"
        return sorted(kb.glob("*.xml"))

    def generate(self) -> None:
        """Parse all DataStage XMLs and generate individual STTM Excel files."""
        if self.xml_path:
            xml_files = [Path(self.xml_path)]
        else:
            xml_files = self._find_all_xmls()

        if not xml_files:
            self.logger.error("No XML files found in input/ (or knowledgebase/)")
            return

        self.logger.info(f"Found {len(xml_files)} XML file(s) to process")

        for xml_file in xml_files:
            self.logger.info(f"{'=' * 60}")
            self._generate_single(xml_file)

        self.logger.info(f"{'=' * 60}")
        self.logger.info(f"Completed: {len(xml_files)} STTM file(s) generated")

    def _generate_single(self, xml_path: Path) -> None:
        """Parse a single DataStage XML and generate its STTM Excel + summary."""
        self.logger.info(f"Parsing XML: {xml_path.name}")

        parser = DataStageParser(xml_path)
        job_meta = parser.get_job_metadata()
        job_params = parser.get_job_parameters()
        param_variables = parser.get_parameterized_variables()
        source_table_full = parser.get_source_table()
        source_sql = parser.get_source_sql()
        target_table_full = parser.get_target_table_name()
        columns = parser.get_transformer_output_columns()
        lookup_stages = parser.get_lookup_stages()
        lookups = parser.get_lookup_columns()

        # --- Parse source SQL into per-column expression maps ---
        source_sql_per_stage = parser.get_source_sql_per_stage()
        sql_parser = SqlColumnParser()
        sql_column_maps: Dict[str, Dict[str, Dict[str, str]]] = {}
        for link_name, stage_sql in source_sql_per_stage.items():
            try:
                sql_column_maps[link_name] = sql_parser.parse_sql(stage_sql)
            except Exception:
                pass  # Graceful fallback if SQL parsing fails

        # Build a merged column map (all source columns across all stages)
        merged_sql_columns: Dict[str, Dict[str, str]] = {}
        for link_name, col_map in sql_column_maps.items():
            for alias, info in col_map.items():
                alias_upper = alias.upper()
                if alias_upper not in merged_sql_columns:
                    info["source_link"] = link_name
                    merged_sql_columns[alias_upper] = info

        # Extract SQL-based CTEs and JOINs for Lookup_Definitions tab
        for link_name, stage_sql in source_sql_per_stage.items():
            try:
                ctes = sql_parser._extract_ctes(stage_sql)
                if not ctes:
                    continue

                # Build a map of JOIN info keyed by table name
                joins = sql_parser._extract_join_info(stage_sql)
                join_map: Dict[str, Dict[str, str]] = {}
                for j in joins:
                    join_map[j["table"]] = j

                # Parse final SELECT to determine which CTE is the primary FROM
                final_select = sql_parser._find_final_select(stage_sql)
                # Determine which columns come from each CTE
                final_cols = sql_parser._parse_select_columns(final_select) if final_select else []
                cte_columns: Dict[str, List[str]] = {name: [] for name in ctes}
                for fc in final_cols:
                    expr = fc["expression"]
                    if "." in expr and "(" not in expr and " " not in expr:
                        cte_ref = expr.split(".")[0]
                        col_name = expr.split(".")[-1]
                        if cte_ref in cte_columns:
                            cte_columns[cte_ref].append(col_name)

                # Extract physical tables for each CTE
                cte_phys_tables: Dict[str, List[str]] = {}
                for cte_name, cte_body in ctes.items():
                    cte_phys_tables[cte_name] = sql_parser._extract_physical_tables(cte_body)

                # Add each CTE as a lookup definition
                for cte_name in ctes:
                    j = join_map.get(cte_name)
                    if j:
                        link_type = f"SQL {j['join_type']} (CTE)"
                        join_condition = j["condition"]
                    else:
                        # Primary CTE (FROM clause, not a JOIN)
                        link_type = "SQL Primary Source (CTE)"
                        join_condition = ""

                    phys_tables = cte_phys_tables.get(cte_name, [])
                    cols_provided = cte_columns.get(cte_name, [])

                    lookup_stages.append({
                        "lookup_name": cte_name,
                        "link_name": link_name,
                        "link_type": link_type,
                        "join_condition": join_condition,
                        "file_name": ", ".join(phys_tables) if phys_tables else cte_name,
                        "columns": [],
                        "cte_columns_provided": cols_provided,
                    })

                # Also add non-CTE JOINs (physical table joins)
                for j in joins:
                    if j["table"] not in ctes and "." in j["table"]:
                        lookup_stages.append({
                            "lookup_name": j["table"].split(".")[-1],
                            "link_name": link_name,
                            "link_type": f"SQL {j['join_type']}",
                            "join_condition": j["condition"],
                            "file_name": j["table"],
                            "columns": [],
                        })
            except Exception:
                pass

        # For multi-source jobs (no CTEs), add each source stage as a lookup definition
        # This covers Channel (7 sources), Coverage (6 sources), LifeCompass (5 sources)
        if len(source_sql_per_stage) > 1:
            # Check if any stage has CTEs — if so, CTE logic above already handled it
            any_ctes = any(
                sql_parser._extract_ctes(sql) for sql in source_sql_per_stage.values()
            )
            if not any_ctes:
                # Track which link names already have DataStage-level lookups
                existing_lookup_names = {
                    lkp.get("lookup_name", "") for lkp in lookup_stages
                }
                for link_name, stage_sql in source_sql_per_stage.items():
                    try:
                        tables = sql_parser._extract_physical_tables(stage_sql)
                        col_map = sql_column_maps.get(link_name, {})
                        col_names = list(col_map.keys())
                        # Count non-direct transformations
                        transforms = [
                            v for v in col_map.values()
                            if v.get("transformation_type", "direct") != "direct"
                        ]
                        # Determine source type label
                        if transforms:
                            trans_types = set(
                                v.get("transformation_type", "") for v in transforms
                            )
                            type_label = ", ".join(sorted(trans_types))
                            link_type = f"Source Stage ({type_label})"
                        else:
                            link_type = "Source Stage (direct)"

                        # Build SQL summary for notes
                        sql_trimmed = stage_sql.strip()
                        if len(sql_trimmed) > 500:
                            sql_summary = sql_trimmed[:500] + "..."
                        else:
                            sql_summary = sql_trimmed

                        primary_table = tables[0] if tables else link_name
                        # Clean schema prefix for display name
                        display_name = primary_table.split(".")[-1] if "." in primary_table else primary_table

                        lookup_stages.append({
                            "lookup_name": display_name,
                            "link_name": link_name,
                            "link_type": link_type,
                            "join_condition": "",
                            "file_name": ", ".join(tables) if tables else link_name,
                            "columns": [],
                            "cte_columns_provided": [c.lower() for c in col_names],
                            "source_sql": sql_summary,
                        })
                    except Exception:
                        pass

        job_name = job_meta.get("job_name", "unknown")
        self.logger.info(f"Job: {job_name}")
        self.logger.info(f"Source: {source_table_full}")
        self.logger.info(f"Target: {target_table_full}")
        self.logger.info(f"Columns: {len(columns)}")
        self.logger.info(f"Lookups: {len(lookup_stages)}")

        # Derive schema and table name
        if "." in target_table_full:
            schema_name, target_table = target_table_full.split(".", 1)
        elif ", " not in source_table_full and "." in source_table_full:
            schema_name = source_table_full.split(".")[0]
            target_table = target_table_full
        else:
            schema_name = ""
            target_table = target_table_full

        # For multi-table sources (parallel jobs with CTEs), derive schema from first table
        if not schema_name and ", " in source_table_full:
            first_table = source_table_full.split(",")[0].strip()
            if "." in first_table:
                schema_name = first_table.split(".")[0]

        # Determine the source stage name for parallel jobs (link name mapping)
        # Use the first actual schema.table_name from the list as default
        source_stage_name = ""
        if ", " in source_table_full:
            source_stage_name = source_table_full.split(",")[0].strip()

        # Build source link -> physical table mapping for per-column resolution
        source_stages_info = parser.get_source_stages_info()
        source_link_table_map: Dict[str, str] = {}
        for link_name, info in source_stages_info.items():
            tables = info.get("tables", [])
            if tables:
                # Prefer a table with schema; if none has schema, prepend target schema
                table_with_schema = ""
                for t in tables:
                    if "." in t:
                        table_with_schema = t
                        break
                if table_with_schema:
                    source_link_table_map[link_name] = table_with_schema
                elif schema_name:
                    source_link_table_map[link_name] = f"{schema_name}.{tables[0]}"
                else:
                    source_link_table_map[link_name] = tables[0]
            else:
                source_link_table_map[link_name] = info.get("stage_name", "")
        self.logger.info(f"Source stage links: {source_link_table_map}")

        # Replace stage names in source_table_full with physical table names
        # (use only source stage links for the source table list)
        if source_link_table_map:
            physical_tables = list(dict.fromkeys(source_link_table_map.values()))
            if physical_tables:
                source_table_full = ", ".join(physical_tables)
                self.logger.info(f"Source (physical): {source_table_full}")
                # Re-derive schema from physical tables if needed
                if not schema_name:
                    for pt in physical_tables:
                        if "." in pt:
                            schema_name = pt.split(".")[0]
                            break
                # Update source_stage_name to first physical table
                source_stage_name = physical_tables[0]

        # Save original source-only map for per-column resolution
        original_source_map = dict(source_link_table_map)

        # Extend link map with intermediate pipeline links (PxLookup/PxJoin/transformer outputs)
        source_link_table_map = parser.build_extended_link_map(source_link_table_map)
        self.logger.info(f"Extended link map: {source_link_table_map}")

        # Build per-column resolution for intermediate links (use original source map
        # so intermediate links aren't treated as already-resolved source links)
        column_link_map = parser.build_column_link_map(original_source_map)
        self.logger.info(f"Column link map keys: {list(column_link_map.keys())}")

        # Try loading plan for metadata overrides
        plan = self.load_master_plan()
        plan_meta = {}
        if plan:
            plan_meta = plan.get("components", {}).get("sttm_metadata_header", {})

        subject_area = plan_meta.get("subject_area", job_meta.get("category", "").split("\\")[-1] or "DataStage")
        nk_columns = plan_meta.get("nk_column_list", "")

        # Detect NK columns from key positions
        if not nk_columns:
            nk_cols = [c["name"] for c in columns if c.get("key_position", 0) > 0]
            nk_columns = ", ".join(nk_cols)

        # Build mapping rows
        sttm_rows = self._build_rows(
            columns, source_table_full, target_table, subject_area, plan,
            source_stage_name=source_stage_name,
            sql_column_map=merged_sql_columns,
            source_link_table_map=source_link_table_map,
        )

        # Extract job flow for the Job_Flow tab
        job_flow = parser.get_job_flow()
        self.logger.info(f"Job flow stages: {len(job_flow)}")

        # Create workbook with correct tab order:
        # Index, Version History, STTM tab, Job_Flow, Lookup_Definitions, Job_Variables, Dependency Details, Common Rules
        wb = openpyxl.Workbook()
        self._create_index_tab(wb, target_table, source_table_full, job_name, subject_area)
        self._create_version_history_tab(wb)
        self._create_sttm_tab(
            wb, sttm_rows, target_table, schema_name, subject_area,
            source_sql, nk_columns, job_name, plan_meta,
        )
        self._create_job_flow_tab(wb, job_flow)
        self._create_lookup_definitions_tab(wb, lookup_stages, lookups, source_link_table_map, column_link_map)
        self._create_job_variables_tab(wb, job_params, param_variables)
        self._create_dependency_details_tab(wb)
        self._create_common_rules_tab(wb)

        # Save workbook
        output_file = f"{job_name}_sttm.xlsx"
        output_path = self.output_dir / output_file
        output_path.parent.mkdir(parents=True, exist_ok=True)
        wb.save(str(output_path))
        self.logger.info(f"STTM saved: {output_path}")

        # Generate summary
        summary_path = self._generate_summary(
            job_meta, job_params, source_table_full, source_sql,
            target_table, schema_name, columns, lookup_stages,
            sttm_rows, output_path, nk_columns, xml_path,
        )
        self.logger.info(f"Summary saved: {summary_path}")

    # ------------------------------------------------------------------
    # Build STTM mapping rows
    # ------------------------------------------------------------------
    def _build_rows(
        self, columns, source_table, target_table, subject_area, plan,
        source_stage_name: str = "",
        sql_column_map: Optional[Dict[str, Dict[str, str]]] = None,
        source_link_table_map: Optional[Dict[str, str]] = None,
    ) -> List[Dict[str, str]]:
        rows: List[Dict[str, str]] = []

        # Get business definitions from plan if available
        biz_defs = {}
        if plan:
            for m in plan.get("components", {}).get("source_to_target_mappings", []):
                biz_defs[m.get("target_column", "")] = m.get("business_definition", "")

        for col in columns:
            derivation = col.get("derivation", "")
            source_col_str = col.get("source_column", "")
            sql_type = col.get("sql_type", 12)
            precision = col.get("precision", 0)
            scale = col.get("scale", 0)
            nullable = col.get("nullable", True)
            target_col_name = col.get("name", "")

            # Use derivation trace to find the originating source link
            # This handles cases where the resolved derivation is a function
            # (e.g., Checksum()) with no link prefix to look up
            col_source_stage = source_stage_name
            if source_link_table_map:
                trace = col.get("derivation_trace", [])
                for link in trace:
                    if link in source_link_table_map:
                        col_source_stage = source_link_table_map[link]
                        break

            src_table, src_col = determine_source_info(
                derivation, source_col_str, source_table,
                source_stage_name=col_source_stage,
                source_link_table_map=source_link_table_map,
            )
            data_type = format_data_type(sql_type, precision, scale)
            transform_sql = datastage_to_sql(derivation, target_col_name=target_col_name)

            # --- Enhance with SQL decomposition ---
            if sql_column_map and transform_sql in (
                "Direct Move from source query",
            ):
                # Try to find column in SQL column map
                col_key = target_col_name.upper()
                # Also try the source column name from the derivation
                if "." in derivation and "(" not in derivation:
                    src_col_from_deriv = derivation.split(".")[-1].upper()
                    if src_col_from_deriv in sql_column_map:
                        col_key = src_col_from_deriv

                sql_info = sql_column_map.get(col_key)
                if sql_info:
                    cte_expr = sql_info.get("cte_expression", "") or sql_info.get("expression", "")
                    ttype = sql_info.get("transformation_type", "direct")
                    cte_name = sql_info.get("cte_name", "")

                    # Only override if there's actual transformation logic
                    if ttype != "direct" and cte_expr:
                        # Clean link prefixes from the CTE expression
                        cleaned_expr = _strip_link_prefix(cte_expr)
                        # Decompose multi-level transformations
                        levels = SqlColumnParser._decompose_expression_levels(cleaned_expr)
                        transform_sql = SqlColumnParser._format_transformation_steps(
                            levels, cte_name=cte_name,
                        )

                    # Update source table from physical tables
                    phys_tables = sql_info.get("physical_tables", "")
                    if phys_tables:
                        # Use first physical table, strip schema for display
                        first_table = phys_tables.split(",")[0].strip()
                        if "." in first_table:
                            src_table = first_table.split(".")[-1]
                        else:
                            src_table = first_table

                    # Update source column from CTE expression
                    if cte_expr and ttype != "direct":
                        # Extract the base column(s) from the expression
                        base_cols = re.findall(r"\b\w+\.(\w+)\b", cte_expr)
                        if not base_cols:
                            # Try extracting from aggregate: SUM(COL)
                            base_cols = re.findall(
                                r"(?:SUM|COUNT|AVG|MAX|MIN|NVL|COALESCE)\s*\(\s*(?:\w+\.)?(\w+)",
                                cte_expr, re.IGNORECASE,
                            )
                        if base_cols:
                            # Deduplicate while preserving order
                            seen = set()
                            unique = []
                            for c in base_cols:
                                if c.upper() not in seen:
                                    seen.add(c.upper())
                                    unique.append(c)
                            src_col = ", ".join(unique)
                        else:
                            src_col = f"derived - {target_col_name}"

            # Handle "Direct Move (Renamed: ...)" with SQL decomposition too
            if sql_column_map and transform_sql.startswith("Direct Move (Renamed:"):
                # Extract source column name from the rename
                rename_match = re.match(
                    r"Direct Move \(Renamed: (\w+)", transform_sql
                )
                if rename_match:
                    renamed_from = rename_match.group(1).upper()
                    sql_info = sql_column_map.get(renamed_from)
                    if sql_info:
                        cte_expr = sql_info.get("cte_expression", "") or sql_info.get("expression", "")
                        ttype = sql_info.get("transformation_type", "direct")
                        cte_name = sql_info.get("cte_name", "")
                        if ttype != "direct" and cte_expr:
                            cleaned_expr = _strip_link_prefix(cte_expr)
                            rename_note = f"-- Renamed: {renamed_from} -> {target_col_name}"
                            if cte_name:
                                note = f"{rename_note}, from CTE {cte_name}"
                            else:
                                note = rename_note
                            levels = SqlColumnParser._decompose_expression_levels(cleaned_expr)
                            transform_sql = SqlColumnParser._format_transformation_steps(
                                levels, note_suffix=note,
                            )
                        phys_tables = sql_info.get("physical_tables", "")
                        if phys_tables:
                            first_table = phys_tables.split(",")[0].strip()
                            if "." in first_table:
                                src_table = first_table.split(".")[-1]
                            else:
                                src_table = first_table

            rows.append({
                "Subject Area": subject_area,
                "Target Table": target_table,
                "Target Column Name ": target_col_name,
                "Business Definition": biz_defs.get(target_col_name, ""),
                "Target Data Type": data_type,
                "Target Nullability": "Null" if nullable else "Not null",
                "Source Table Name": src_table,
                "Source Column Name": src_col,
                "Source Column Type": data_type,
                "Source Transformational Rule/Logic": transform_sql,
                "Pending Questions/Queries": "",
                "Obeservation": "",
            })

        return rows

    # ------------------------------------------------------------------
    # Tab: Job_Flow
    # ------------------------------------------------------------------
    def _create_job_flow_tab(self, wb, job_flow: List[Dict[str, Any]]):
        """Create a Job_Flow tab showing the ordered data flow from source to target.

        The tab displays each stage in execution order with:
        - Step number, stage name, type, role
        - Input/output links showing what feeds in and flows out
        - Physical table or other details
        - A visual 'Flow Path' column with arrow notation
        """
        ws = wb.create_sheet("Job_Flow")

        # --- Color fills for different roles ---
        SOURCE_FILL = PatternFill(start_color="C6EFCE", end_color="C6EFCE", fill_type="solid")
        TARGET_FILL = PatternFill(start_color="F4CCCC", end_color="F4CCCC", fill_type="solid")
        LOOKUP_FILL = PatternFill(start_color="FCE4D6", end_color="FCE4D6", fill_type="solid")
        TRANSFORM_FILL = PatternFill(start_color="D9E2F3", end_color="D9E2F3", fill_type="solid")
        JOIN_FILL = PatternFill(start_color="E2EFDA", end_color="E2EFDA", fill_type="solid")
        DEFAULT_FILL = PatternFill(start_color="F2F2F2", end_color="F2F2F2", fill_type="solid")

        ROLE_FILLS = {
            "Source": SOURCE_FILL,
            "Target": TARGET_FILL,
            "Lookup": LOOKUP_FILL,
            "Transformer": TRANSFORM_FILL,
            "Join": JOIN_FILL,
            "Funnel": JOIN_FILL,
            "DataSet": DEFAULT_FILL,
            "Sort": DEFAULT_FILL,
            "Filter": DEFAULT_FILL,
            "Remove Duplicates": DEFAULT_FILL,
        }

        headers = [
            "#", "Stage Name", "Stage Type", "Role",
            "Input Links", "Output Links",
            "Physical Table / Details", "Flow Path",
        ]
        for i, h in enumerate(headers, 1):
            _cell(ws, 1, i, h, BOLD_FONT, HEADER_FILL, CENTER_WRAP)

        widths = [5, 28, 22, 18, 40, 30, 40, 55]
        for i, w in enumerate(widths, 1):
            ws.column_dimensions[get_column_letter(i)].width = w

        # --- Build a flow-path string for each step ---
        # This creates a visual representation like:
        #   [Source: OracleSrc] --> lnk_src --> [Lookup: LkpProd] --> lnk_out --> [Transformer: Trx] --> ...
        for row_idx, step in enumerate(job_flow, 2):
            step_num = step["step"]
            stage_name = step["stage_name"]
            stage_type = step["stage_type"]
            role = step["role"]
            in_links = step["input_links"]
            out_links = step["output_links"]
            details = step.get("details", "")

            # Build flow path: show input arrows into this stage, then output arrows out
            parts: List[str] = []
            if in_links:
                parts.append(" , ".join(in_links))
                parts.append("-->")
            parts.append(f"[ {role}: {stage_name} ]")
            if out_links:
                parts.append("-->")
                parts.append(" , ".join(out_links))
            flow_path = "  ".join(parts)

            role_fill = ROLE_FILLS.get(role, DEFAULT_FILL)

            _cell(ws, row_idx, 1, step_num, NORMAL_FONT, role_fill)
            _cell(ws, row_idx, 2, stage_name, BOLD_FONT, role_fill)
            _cell(ws, row_idx, 3, stage_type, NORMAL_FONT, role_fill)
            _cell(ws, row_idx, 4, role, BOLD_FONT, role_fill)
            _cell(ws, row_idx, 5, "\n".join(in_links) if in_links else "(none)", NORMAL_FONT, role_fill)
            _cell(ws, row_idx, 6, "\n".join(out_links) if out_links else "(none)", NORMAL_FONT, role_fill)
            _cell(ws, row_idx, 7, details, NORMAL_FONT, role_fill)
            _cell(ws, row_idx, 8, flow_path, NORMAL_FONT, role_fill)

        # --- Add a summary section below the flow table ---
        summary_row = len(job_flow) + 3
        _cell(ws, summary_row, 1, "Flow Summary", BOLD_FONT, META_FILL)
        ws.merge_cells(start_row=summary_row, start_column=1,
                       end_row=summary_row, end_column=8)

        # Count stages by role
        role_counts: Dict[str, int] = {}
        for step in job_flow:
            r = step["role"]
            role_counts[r] = role_counts.get(r, 0) + 1

        row = summary_row + 1
        for role_name, count in role_counts.items():
            _cell(ws, row, 1, role_name, BOLD_FONT)
            _cell(ws, row, 2, count, NORMAL_FONT)
            row += 1

        # --- Add a full pipeline path (linear chain summary) ---
        row += 1
        _cell(ws, row, 1, "Pipeline Path", BOLD_FONT, META_FILL)
        ws.merge_cells(start_row=row, start_column=1,
                       end_row=row, end_column=8)
        row += 1

        # Build a simplified linear path showing the main flow
        path_parts: List[str] = []
        for step in job_flow:
            role = step["role"]
            name = step["stage_name"]
            if role in ("Source", "Target", "Transformer", "Lookup", "Join"):
                label = f"[{role}: {name}]"
            else:
                label = f"[{name}]"
            path_parts.append(label)
        full_path = "  -->  ".join(path_parts)
        _cell(ws, row, 1, full_path, NORMAL_FONT)
        ws.merge_cells(start_row=row, start_column=1,
                       end_row=row, end_column=8)
        ws.row_dimensions[row].height = 45

    # ------------------------------------------------------------------
    # Tab: Index (headers only)
    # ------------------------------------------------------------------
    def _create_index_tab(self, wb, target_table, source_table, job_name, subject_area):
        ws = wb.active
        ws.title = "Index"
        headers = [
            "#", "Index", "Table Load Type", "Table Refresh Frequency",
            "Table Load SLA", "Source System Name", "Comments", "STTM",
            "Project Teams", "Owner",
        ]
        for i, h in enumerate(headers, 1):
            _cell(ws, 1, i, h, BOLD_FONT, HEADER_FILL, CENTER_WRAP)
            ws.column_dimensions[get_column_letter(i)].width = 22

    # ------------------------------------------------------------------
    # Tab: Version History (headers only)
    # ------------------------------------------------------------------
    def _create_version_history_tab(self, wb):
        ws = wb.create_sheet("Version History")
        headers = ["Sno", "Version ", "Date", "Updated By", "Table name",
                    "Mapping Changes", "Reason", "Comment"]
        for i, h in enumerate(headers, 1):
            _cell(ws, 1, i, h, BOLD_FONT, HEADER_FILL, CENTER_WRAP)
            ws.column_dimensions[get_column_letter(i)].width = 25

    # ------------------------------------------------------------------
    # Tab: Common Rules
    # ------------------------------------------------------------------
    def _create_common_rules_tab(self, wb):
        ws = wb.create_sheet("Common Rules")
        rules = [
            ("Default Record Population Rule:", ""),
            ("Rule: 1", "When ever there is Source Table/Column Name mapped -- When ever we do not have a value from the source system(i.e NULL values or no value in the transaction) then populate -98 for all the SK values and NF for all the code values, NOT FOUND for all the description values."),
            ("Rule: 2", "When ever we have a value from the source system(Value is present in the transaction) but the corresponding value is not present in the target table then populate -99 for all the SK values and UNK for all the code values, UNKNOWN for all the description values"),
            ("Rule: 3", "When ever there is no Source Table/Column Name mapped - Populate -97 for all the SK values and NA for all the code values, NOT APPLICABLE for all the description values"),
            ("Rule: 4", "Apply ETL null handling functions for comparing null values"),
            ("", "eg: cnt_id <> '' apply coalesce() function or DataStage/IDMC/DBT/Redshift function to handle null"),
        ]
        for row_idx, (label, desc) in enumerate(rules, 1):
            if label:
                _cell(ws, row_idx, 1, label, BOLD_FONT)
            if desc:
                _cell(ws, row_idx, 2, desc, NORMAL_FONT)
        ws.column_dimensions["A"].width = 15
        ws.column_dimensions["B"].width = 120

    # ------------------------------------------------------------------
    # Tab: Dependency Details (headers only)
    # ------------------------------------------------------------------
    def _create_dependency_details_tab(self, wb):
        ws = wb.create_sheet("Dependency Details")
        headers = ["Sno", "Table name", "Target Schema Name", "Frequency",
                    "Dependency On", "Comment"]
        for i, h in enumerate(headers, 1):
            _cell(ws, 1, i, h, BOLD_FONT, HEADER_FILL, CENTER_WRAP)
            ws.column_dimensions[get_column_letter(i)].width = 30

    # ------------------------------------------------------------------
    # Tab: Job_Variables
    # ------------------------------------------------------------------
    def _create_job_variables_tab(self, wb, job_params, param_variables):
        ws = wb.create_sheet("Job_Variables")
        headers = [
            "#", "Variable Name", "Parent / Scope", "Type",
            "Default Value", "Possible Values", "Description",
        ]
        for i, h in enumerate(headers, 1):
            _cell(ws, 1, i, h, BOLD_FONT, HEADER_FILL, CENTER_WRAP)

        widths = [5, 35, 35, 25, 25, 30, 55]
        for i, w in enumerate(widths, 1):
            ws.column_dimensions[get_column_letter(i)].width = w

        row_idx = 2

        for idx, jp in enumerate(job_params, 1):
            param_type = jp.get("type", "String")
            default = "(encrypted)" if param_type == "Encrypted" else jp.get("default", "")
            description = jp.get("help", "") or jp.get("prompt", "")
            _cell(ws, row_idx, 1, idx, NORMAL_FONT)
            _cell(ws, row_idx, 2, jp.get("name", ""), NORMAL_FONT)
            _cell(ws, row_idx, 3, "Job Parameter", NORMAL_FONT)
            _cell(ws, row_idx, 4, param_type, NORMAL_FONT)
            _cell(ws, row_idx, 5, default, NORMAL_FONT)
            _cell(ws, row_idx, 6, "", NORMAL_FONT)
            _cell(ws, row_idx, 7, description, NORMAL_FONT)
            row_idx += 1

        start_idx = len(job_params) + 1
        for idx, pv in enumerate(param_variables, start_idx):
            _cell(ws, row_idx, 1, idx, NORMAL_FONT)
            _cell(ws, row_idx, 2, pv.get("name", ""), BOLD_FONT)
            _cell(ws, row_idx, 3, pv.get("parent", ""), NORMAL_FONT)
            _cell(ws, row_idx, 4, pv.get("type", ""), NORMAL_FONT)
            _cell(ws, row_idx, 5, pv.get("default", ""), NORMAL_FONT)
            _cell(ws, row_idx, 6, pv.get("possible_values", ""), NORMAL_FONT)
            _cell(ws, row_idx, 7, pv.get("description", ""), NORMAL_FONT)
            row_idx += 1

    # ------------------------------------------------------------------
    # Tab: Lookup_Definitions
    # ------------------------------------------------------------------
    def _create_lookup_definitions_tab(self, wb, lookup_stages, lookups_dict,
                                       source_link_table_map=None,
                                       column_link_map=None):
        ws = wb.create_sheet("Lookup_Definitions")
        headers = [
            "#", "Lookup Name", "Link Name", "Lookup Type",
            "File Location", "Key Column (Lookup Side)",
            "Key Expression (Source Side)", "Columns Returned",
            "Column Details (Name | Type | Nullable | Key)",
            "Null/Filter Condition", "Used By Target Columns", "Notes",
        ]
        for i, h in enumerate(headers, 1):
            _cell(ws, 1, i, h, BOLD_FONT, HEADER_FILL, CENTER_WRAP)

        widths = [5, 20, 18, 22, 45, 22, 40, 45, 55, 55, 40, 55]
        for i, w in enumerate(widths, 1):
            ws.column_dimensions[get_column_letter(i)].width = w

        link_map = source_link_table_map or {}
        col_map = column_link_map or {}

        def _resolve_derivation_display(deriv: str) -> str:
            """Replace link name prefixes in derivations with physical table names."""
            if not deriv or "." not in deriv:
                return deriv
            prefix = deriv.split(".")[0]
            col_part = deriv.split(".", 1)[1]
            # Try per-column resolution first (handles multi-source links)
            if prefix in col_map:
                physical = col_map[prefix].get(col_part)
                if physical:
                    return f"{physical}.{col_part}"
            # Fall back to link-level resolution
            if prefix in link_map:
                return f"{link_map[prefix]}.{col_part}"
            return deriv

        row_idx = 2
        for idx, lkp in enumerate(lookup_stages, 1):
            cols = lkp.get("columns", [])
            file_name = lkp.get("file_name", lkp.get("lookup_name", ""))
            link_name = lkp.get("link_name", "")
            directory = lkp.get("directory", "")
            link_type = lkp.get("link_type", "Hashed File Lookup")

            # Resolve file_name to physical table if possible
            file_location = file_name
            if file_name in link_map:
                file_location = link_map[file_name]
            elif lkp.get("ref_input") and lkp["ref_input"] in link_map:
                file_location = link_map[lkp["ref_input"]]
            for inp in lkp.get("input_sources", []):
                inp_link = inp.get("link_name", "")
                if inp_link in link_map:
                    if inp.get("link_type") == "2" or (not lkp.get("ref_input")):
                        file_location = link_map[inp_link]
                        break

            # For PxLookup/PxJoin stages, use enhanced column info
            if lkp.get("key_columns"):
                key_col = ", ".join(lkp.get("key_columns", []))
                key_expr_list = lkp.get("key_expressions", [])
                key_expr = ", ".join(_resolve_derivation_display(k) for k in key_expr_list) if key_expr_list else ""
                returned_cols = lkp.get("returned_columns", [])

                # Build column details from output columns with resolved table names
                col_details_lines = []
                for c in cols:
                    deriv = c.get("derivation", "")
                    resolved = _resolve_derivation_display(deriv)
                    col_details_lines.append(f"{c['name']} = {resolved}")

                # Build notes with input sources
                notes_parts = []
                if lkp.get("ref_input"):
                    ref_display = lkp["ref_input"]
                    for inp in lkp.get("input_sources", []):
                        if inp.get("link_type") == "2" and inp["link_name"] in link_map:
                            ref_display = link_map[inp["link_name"]]
                            break
                    notes_parts.append(f"Reference source: {ref_display}")
                if lkp.get("main_input"):
                    notes_parts.append(f"Main input: {lkp['main_input']}")
                for inp in lkp.get("input_sources", []):
                    inp_link = inp.get("link_name", "")
                    stage = inp.get("stage_name", "")
                    table = link_map.get(inp_link, stage)
                    notes_parts.append(f"Input link: {inp_link} from {table}")
                notes = "\n".join(notes_parts)
            else:
                # Original Hashed File Lookup / CTE / Source Stage handling
                key_col = ""
                key_expr = ""
                returned_cols = []
                col_details_lines = []
                for c in cols:
                    col_type = format_data_type(
                        c.get("sql_type", 12), c.get("precision", 0), c.get("scale", 0),
                    )
                    nullable_str = "Nullable" if c.get("nullable", True) else "Not Null"
                    key_str = " | Key" if c.get("key_position", 0) > 0 else ""
                    col_details_lines.append(f"{c['name']} | {col_type} | {nullable_str}{key_str}")

                    if c.get("key_position", 0) > 0:
                        key_col = c["name"]
                        key_expr = c.get("key_expression", "")
                    else:
                        returned_cols.append(c["name"])

                # For CTE-based lookups, populate columns from cte_columns_provided
                cte_cols_provided = lkp.get("cte_columns_provided", [])
                if not returned_cols and cte_cols_provided:
                    returned_cols = cte_cols_provided

                # Use join_condition from SQL-based lookups if available
                join_condition = lkp.get("join_condition", "")
                if not key_expr and join_condition:
                    key_expr = join_condition
                elif not key_expr and key_col:
                    key_expr = f"TRIM(source.{key_col})"

                source_sql_note = lkp.get("source_sql", "")
                if join_condition:
                    notes = f"SQL JOIN: {join_condition}"
                elif link_type.startswith("SQL Primary"):
                    notes = f"Primary source CTE. Physical tables: {file_name}"
                elif link_type.startswith("Source Stage"):
                    notes = f"Source SQL:\n{source_sql_note}" if source_sql_note else f"Source stage reading from {file_name}"
                else:
                    notes = f"Reference/Lookup link. Joins source key to {file_name}.{key_col}"

            _cell(ws, row_idx, 1, idx, NORMAL_FONT)
            _cell(ws, row_idx, 2, lkp.get("lookup_name", file_name), NORMAL_FONT)
            _cell(ws, row_idx, 3, link_name, NORMAL_FONT)
            _cell(ws, row_idx, 4, link_type, NORMAL_FONT)
            _cell(ws, row_idx, 5, file_location if not directory else f"{directory}/{file_name}", NORMAL_FONT)
            _cell(ws, row_idx, 6, key_col, NORMAL_FONT)
            _cell(ws, row_idx, 7, key_expr or "", NORMAL_FONT)
            _cell(ws, row_idx, 8, ", ".join(returned_cols), NORMAL_FONT)
            _cell(ws, row_idx, 9, "\n".join(col_details_lines), NORMAL_FONT)
            _cell(ws, row_idx, 10, "", NORMAL_FONT)
            _cell(ws, row_idx, 11, ", ".join(returned_cols), NORMAL_FONT)
            _cell(ws, row_idx, 12, notes, NORMAL_FONT)

            ws.row_dimensions[row_idx].height = max(60, len(cols) * 18)
            row_idx += 1

    # ------------------------------------------------------------------
    # Tab: STTM mapping (main tab)
    # ------------------------------------------------------------------
    def _create_sttm_tab(
        self, wb, sttm_rows, target_table, schema_name,
        subject_area, source_sql, nk_columns, job_name, plan_meta,
    ):
        sheet_name = target_table[:31]
        ws = wb.create_sheet(sheet_name)

        # Row 1: Back to Index
        _cell(ws, 1, 1, "Back to Index", LINK_FONT, META_FILL)

        # Row 2: Metadata
        meta_row = [
            ("Target Table Name", True, HEADER_FILL),
            (target_table, False, None),
            ("Target Schema Name", True, HEADER_FILL),
            (schema_name, True, None),
            ("Created By", True, HEADER_FILL),
            (plan_meta.get("created_by", ""), False, None),
            ("Last Updated By", True, HEADER_FILL),
            (plan_meta.get("last_updated_by", ""), False, None),
        ]
        for i, (val, bold, fill) in enumerate(meta_row, 1):
            _cell(ws, 2, i, val, BOLD_FONT if bold else NORMAL_FONT, fill)

        # Row 3: Purpose
        _cell(ws, 3, 1, "Purpose", BOLD_FONT, HEADER_FILL)
        purpose = plan_meta.get("purpose", f"{target_table} - DataStage Job: {job_name}")
        _cell(ws, 3, 2, str(purpose).strip(), NORMAL_FONT)
        ws.merge_cells("B3:D3")
        _cell(ws, 3, 5, "Created On", BOLD_FONT, HEADER_FILL)
        _cell(ws, 3, 6, datetime.now().strftime("%Y-%m-%d"), NORMAL_FONT)
        _cell(ws, 3, 7, "Last Updated On", BOLD_FONT, HEADER_FILL)
        _cell(ws, 3, 8, datetime.now().strftime("%Y-%m-%d"), NORMAL_FONT)

        # Row 4: blank
        ws.merge_cells("A4:H4")

        # Row 5: Extraction details
        db_op = plan_meta.get("database_operation", "Extract to Sequential File (Flat File)")
        _cell(ws, 5, 1, f"Database Operation/Table Load Type: \n{db_op}", BLUE_FONT, META_FILL)
        extraction = plan_meta.get("extraction_criteria", "Full extract - no WHERE clause filter")
        _cell(ws, 5, 3, f"Extraction Criteria:\n{extraction}", BOLD_FONT, META_FILL)
        _cell(ws, 5, 4, f"Main Query:\n{source_sql}", BOLD_FONT, META_FILL)
        _cell(ws, 5, 5, "Lookup Definitions:\nRefer to Lookup_Definitions tab for full details.", BOLD_FONT, META_FILL)
        _cell(ws, 5, 7, f"NK Column List: {nk_columns}", RED_FONT, WHITE_FILL)

        # Row 6: Column headers
        col_headers = [
            "Subject Area", "Target Table", "Target Column Name ",
            "Business Definition", "Target Data Type", "Target Nullability",
            "Source Table Name", "Source Column Name", "Source Column Type",
            "Source Transformational Rule/Logic",
            "Pending Questions/Queries", "Obeservation",
        ]
        for i, h in enumerate(col_headers, 1):
            _cell(ws, 6, i, h, BOLD_FONT, HEADER_FILL, CENTER_WRAP)

        # Row 7: Surrogate Key
        sk_vals = [
            subject_area, target_table, f"{target_table}_SK", "Surrogate key",
            "BIGINT", "Not null", "NA", "NA", "BIGINT", "Surrogate key", "", "",
        ]
        for i, v in enumerate(sk_vals, 1):
            _cell(ws, 7, i, v, NORMAL_FONT)

        # Row 8+: Data rows
        nk_list = [c.strip() for c in nk_columns.split(",")]
        row = 8
        for data_row in sttm_rows:
            for i, h in enumerate(col_headers, 1):
                _cell(ws, row, i, data_row.get(h, ""), NORMAL_FONT)
            # Highlight NK columns
            col_name = data_row.get("Target Column Name ", "")
            if col_name in nk_list:
                ws.cell(row=row, column=3).fill = NK_FILL
            row += 1

        # Column widths
        widths = [24.5, 32.7, 32.3, 53.0, 26.7, 20.5, 29.2, 22.0, 14.5, 57.0, 31.8, 33.4]
        for i, w in enumerate(widths, 1):
            ws.column_dimensions[get_column_letter(i)].width = w
        ws.row_dimensions[5].height = 200

    # ------------------------------------------------------------------
    # Generate summary markdown
    # ------------------------------------------------------------------
    def _generate_summary(
        self, job_meta, job_params, source_table, source_sql,
        target_table, schema_name, columns, lookup_stages,
        sttm_rows, output_path, nk_columns, xml_path=None,
    ) -> Path:
        src_xml = xml_path or self.xml_path or Path("unknown.xml")
        lines = [
            f"# Reverse Engineering Summary: {job_meta.get('job_name', 'unknown')}",
            "",
            "## Source File",
            f"- **DataStage XML Export:** `{src_xml.name}`",
            f"- **Reference STTM Format:** `{self.reference_path.name}`",
            "",
            "## Job Metadata",
            "| Attribute | Value |",
            "|---|---|",
        ]
        for k, v in job_meta.items():
            lines.append(f"| {k} | `{v}` |")

        lines += [
            "",
            "## Job Parameters",
            "| Parameter | Default | Type |",
            "|---|---|---|",
        ]
        for p in job_params:
            default = "(encrypted)" if p.get("type") == "Encrypted" else p.get("default", "")
            lines.append(f"| `{p.get('name', '')}` | `{default}` | {p.get('type', 'String')} |")

        lines += [
            "",
            "## Source Table",
            f"- **Full Name:** {source_table}",
            f"- **Schema:** {schema_name}",
            f"- **SQL:**",
            "```sql",
            source_sql,
            "```",
            "",
            "## Target Table",
            f"- **Table:** {target_table}",
            f"- **Schema:** {schema_name}",
            f"- **NK Columns:** {nk_columns}",
            "",
            "## Lookup Definitions",
        ]
        for i, lkp in enumerate(lookup_stages, 1):
            lines.append(f"### Lookup {i}: {lkp.get('lookup_name', lkp.get('file_name', ''))}")
            lines.append(f"- **Link:** {lkp.get('link_name', '')}")
            lines.append(f"- **Type:** {lkp.get('link_type', 'Hashed File')}")
            cols = lkp.get("columns", [])
            col_names = [c["name"] for c in cols if c.get("key_position", 0) == 0]
            lines.append(f"- **Returns:** {', '.join(col_names)}")
            lines.append("")

        lines += [
            "## Column Mapping Summary",
            f"Total columns: {len(sttm_rows) + 1} (including SK)",
            "",
            "| # | Target Column | Source | Transformation |",
            "|---|---|---|---|",
            f"| 1 | {target_table}_SK | NA | Surrogate key |",
        ]
        for i, row in enumerate(sttm_rows, 2):
            rule = row.get("Source Transformational Rule/Logic", "").split("\n")[0]
            lines.append(
                f"| {i} | {row['Target Column Name ']} | "
                f"{row['Source Table Name']}.{row['Source Column Name']} | {rule} |"
            )

        lines += [
            "",
            "## Output Generated",
            f"- **STTM File:** `{output_path.name}`",
            f"- **Generated:** {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}",
        ]

        summary_path = self.output_dir / f"{job_meta.get('job_name', 'unknown')}_summary.md"
        summary_path.parent.mkdir(parents=True, exist_ok=True)
        summary_path.write_text("\n".join(lines), encoding="utf-8")
        return summary_path


# ============================================================================
# CLI Entry Point
# ============================================================================
def main() -> None:
    parser = argparse.ArgumentParser(description="Generate STTM from DataStage XML export")
    parser.add_argument("--xml", help="Path to DataStage XML export file")
    parser.add_argument("--reference", help="Path to reference STTM Excel file")
    parser.add_argument("--output", default="output", help="Output directory (default: output)")
    args = parser.parse_args()

    root = get_project_root()
    generator = STTMGenerator(
        xml_path=args.xml,
        reference_path=args.reference,
        plans_dir=str(root / "plans"),
        output_dir=str(root / args.output),
    )
    generator.generate()


if __name__ == "__main__":
    main()
