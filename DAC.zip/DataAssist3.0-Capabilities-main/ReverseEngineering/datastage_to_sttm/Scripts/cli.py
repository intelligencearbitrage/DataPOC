"""
CLI entry point for the STTM Generator toolkit.

Exposes all available commands through a single interface:
    python cli.py generate   -- Generate STTM Excel from DataStage XML
    python cli.py validate   -- Validate a generated STTM workbook
    python cli.py accuracy   -- Run accuracy report (STTM vs source XML)
    python cli.py build      -- Discover and run all generators
    python cli.py refine     -- Run refinement loop on validation errors
"""

import argparse
import sys
from pathlib import Path

SCRIPT_DIR = Path(__file__).resolve().parent
sys.path.insert(0, str(SCRIPT_DIR))


def cmd_generate(args):
    from generate_sttm import main as generate_main
    sys.argv = ["generate_sttm.py"]
    if args.xml:
        sys.argv.extend(["--xml", args.xml])
    generate_main()


def cmd_validate(args):
    from validator import main as validate_main
    sys.argv = ["validator.py"]
    if args.file:
        sys.argv.extend(["--file", args.file])
    if args.output:
        sys.argv.extend(["--output", args.output])
    validate_main()


def cmd_accuracy(args):
    from accuracy_report import main as accuracy_main
    accuracy_main()


def cmd_build(args):
    from build_all import main as build_main
    build_main()


def cmd_refine(args):
    from refiner import main as refine_main
    sys.argv = ["refiner.py"]
    if args.report:
        sys.argv.extend(["--report", args.report])
    if args.feedback:
        sys.argv.extend(["--feedback", args.feedback])
    if args.max_iterations:
        sys.argv.extend(["--max-iterations", str(args.max_iterations)])
    refine_main()


def main():
    parser = argparse.ArgumentParser(
        prog="cli.py",
        description="STTM Generator -- DataStage XML to Source-to-Target Mapping Excel",
    )
    subparsers = parser.add_subparsers(dest="command", required=True)

    # -- generate --
    gen_parser = subparsers.add_parser(
        "generate",
        help="Generate STTM Excel workbook from DataStage XML",
    )
    gen_parser.add_argument(
        "--xml",
        help="Path to a specific DataStage XML file (default: process all in input/)",
    )
    gen_parser.set_defaults(func=cmd_generate)

    # -- validate --
    val_parser = subparsers.add_parser(
        "validate",
        help="Validate a generated STTM Excel workbook",
    )
    val_parser.add_argument(
        "--file",
        help="Path to STTM Excel file to validate (default: auto-detect in output/)",
    )
    val_parser.add_argument(
        "--output",
        default="output",
        help="Output directory (default: output)",
    )
    val_parser.set_defaults(func=cmd_validate)

    # -- accuracy --
    acc_parser = subparsers.add_parser(
        "accuracy",
        help="Run accuracy report comparing STTM output against source XML",
    )
    acc_parser.set_defaults(func=cmd_accuracy)

    # -- build --
    build_parser = subparsers.add_parser(
        "build",
        help="Discover and run all generate_*.py scripts",
    )
    build_parser.set_defaults(func=cmd_build)

    # -- refine --
    ref_parser = subparsers.add_parser(
        "refine",
        help="Run refinement loop to patch output based on validation errors",
    )
    ref_parser.add_argument(
        "--report",
        help="Path to accuracy report (default: output/accuracy_report.txt)",
    )
    ref_parser.add_argument(
        "--feedback",
        help="Path to human feedback text file",
    )
    ref_parser.add_argument(
        "--max-iterations",
        type=int,
        default=3,
        help="Maximum refinement iterations (default: 3)",
    )
    ref_parser.set_defaults(func=cmd_refine)

    args = parser.parse_args()
    args.func(args)


if __name__ == "__main__":
    main()
