"""
Master Build Script - Discovers and runs all generator scripts.

Usage:
    python scripts/build_all.py
"""

import importlib
import sys
from pathlib import Path

SCRIPTS_DIR = Path(__file__).resolve().parent
PROJECT_ROOT = SCRIPTS_DIR.parent
sys.path.insert(0, str(SCRIPTS_DIR))

from utils import setup_logging, get_timestamp


def main():
    logger = setup_logging('build_all')
    logger.info("=" * 60)
    logger.info("Build All - Starting")
    logger.info("=" * 60)

    generators = sorted(SCRIPTS_DIR.glob('generate_*.py'))

    if not generators:
        logger.warning("No generate_*.py scripts found in scripts/")
        return

    logger.info(f"Found {len(generators)} generator(s): {[g.stem for g in generators]}")

    for gen_path in generators:
        module_name = gen_path.stem
        logger.info(f"Running: {module_name}")
        try:
            module = importlib.import_module(module_name)
            if hasattr(module, 'main'):
                module.main()
        except Exception as e:
            logger.error(f"{module_name} failed: {e}")

    logger.info("Build Complete")


if __name__ == '__main__':
    main()
