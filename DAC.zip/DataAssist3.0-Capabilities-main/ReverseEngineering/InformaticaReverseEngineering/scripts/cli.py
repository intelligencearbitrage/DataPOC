"""
Unified CLI entry point for Informatica Reverse Engineering.

Delegates to the underlying modules:
  aggregate  -> informatica_reverse_engineering.agent_interface.aggregate_cli
  analyze    -> informatica_reverse_engineering.agent_interface.cli (analyze)
  visualize  -> informatica_reverse_engineering.agent_interface.cli (visualize)
  validate   -> informatica_reverse_engineering.agents.accuracy_validator
"""

import sys
from pathlib import Path

# Ensure the scripts/ directory is on sys.path for package discovery.
_scripts_dir = Path(__file__).resolve().parent
if str(_scripts_dir) not in sys.path:
    sys.path.insert(0, str(_scripts_dir))


USAGE = """\
usage: cli.py <command> [options]

Informatica PowerCenter Reverse Engineering Tool

commands:
  aggregate   Multi-XML aggregated lineage (Excel + CSV + JSON + DAG)
  analyze     Single-XML deep analysis (all export formats)
  visualize   Generate Cytoscape or Mermaid lineage visualization
  validate    Run accuracy validation against source XMLs

Run 'cli.py <command> --help' for command-specific options.
"""


def main():
    if len(sys.argv) < 2 or sys.argv[1] in ("-h", "--help"):
        print(USAGE)
        return 0

    command = sys.argv[1]

    if command == "aggregate":
        # Strip 'aggregate' from argv so aggregate_cli.main() sees the right args
        sys.argv = [sys.argv[0]] + sys.argv[2:]
        from informatica_reverse_engineering.agent_interface.aggregate_cli import main as agg_main
        return agg_main()

    elif command in ("analyze", "visualize", "lineage", "batch"):
        # Pass [command, ...rest] to the inner CLI which expects a subcommand
        args = [command] + sys.argv[2:]
        from informatica_reverse_engineering.agent_interface.cli import main as inner_main
        return inner_main(args)

    elif command == "validate":
        return _run_validate(sys.argv[2:])

    else:
        print(f"Unknown command: {command}\n")
        print(USAGE)
        return 1


def _run_validate(args):
    """Run accuracy validation via AccuracyValidator."""
    import argparse

    parser = argparse.ArgumentParser(
        prog="cli.py validate",
        description="Run accuracy validation comparing output against source XMLs",
    )
    parser.add_argument(
        "--xml", required=False,
        help="Single XML file to validate against",
    )
    parser.add_argument(
        "--input-dir", required=False,
        help="Directory of XML files for batch validation",
    )
    parser.add_argument(
        "--output-dir", required=False,
        help="Output directory containing reverse-engineered results (for single-file mode)",
    )
    parser.add_argument(
        "--output-base", required=False,
        help="Base output directory for batch mode (per-XML subfolders)",
    )
    parser.add_argument(
        "--aggregated-output", required=False,
        help="Aggregated output directory (multiple XMLs, one output folder)",
    )
    parser.add_argument(
        "--param-file", required=False,
        help="Parameter file (.par/.prm) for resolving placeholders",
    )
    parser.add_argument(
        "-v", "--verbose", action="store_true",
        help="Verbose logging",
    )
    parsed = parser.parse_args(args)

    from informatica_reverse_engineering.utils.logging_config import setup_logging, get_logger
    from informatica_reverse_engineering.utils.path_utils import sanitize_path
    setup_logging(level=10 if parsed.verbose else 20)
    logger = get_logger("validate")

    from informatica_reverse_engineering.agents.accuracy_validator import AccuracyValidator
    validator = AccuracyValidator()

    if parsed.xml and parsed.output_dir:
        # Single file mode
        xml_path = sanitize_path(parsed.xml)
        out_dir = sanitize_path(parsed.output_dir)
        logger.info(f"Validating {xml_path} against {out_dir}")
        report = validator.validate_single(
            str(xml_path), str(out_dir),
            param_file=parsed.param_file,
        )
        score = report.get("overall_score", 0)
        grade = report.get("letter_grade", "?")
        issues = len(report.get("issues", []))
        logger.info(f"Score: {score:.1f} ({grade}) | Issues: {issues}")

    elif parsed.input_dir and parsed.aggregated_output:
        # Aggregated mode
        inp_dir = sanitize_path(parsed.input_dir)
        agg_out = sanitize_path(parsed.aggregated_output)
        logger.info(f"Aggregated validation: {inp_dir} -> {agg_out}")
        agg_report = validator.validate_aggregated(
            str(inp_dir), str(agg_out),
            param_file=parsed.param_file,
        )
        report_path = agg_out / "aggregated_accuracy_report.xlsx"
        validator.write_aggregated_report(agg_report, str(report_path))
        score = agg_report.get("overall_score", 0)
        grade = agg_report.get("letter_grade", "?")
        logger.info(f"Overall: {score:.1f} ({grade}) | XMLs: {agg_report.get('xml_count', 0)} | Report: {report_path}")

    elif parsed.input_dir and parsed.output_base:
        # Batch mode
        inp_dir = sanitize_path(parsed.input_dir)
        out_base = sanitize_path(parsed.output_base)
        logger.info(f"Batch validation: {inp_dir} -> {out_base}")
        batch_report = validator.validate_batch(
            str(inp_dir), str(out_base),
            param_file=parsed.param_file,
        )
        summary_path = out_base / "accuracy_batch_summary.xlsx"
        validator.write_batch_report(batch_report, str(summary_path))
        logger.info(f"Batch complete | Report: {summary_path}")

    else:
        parser.print_help()
        print("\nExamples:")
        print("  cli.py validate --xml file.xml --output-dir ./output/")
        print("  cli.py validate --input-dir ./xmls/ --aggregated-output ./output/")
        print("  cli.py validate --input-dir ./xmls/ --output-base ./output/")
        return 1

    return 0


if __name__ == "__main__":
    sys.exit(main() or 0)
