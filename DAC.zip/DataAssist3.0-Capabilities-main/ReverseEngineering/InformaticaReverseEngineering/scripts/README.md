<div align="center">

# Informatica Reverse Engineering

**Source Table → Transformation Chain → Target Table**

**Field-level data lineage extraction from Informatica PowerCenter XML exports for forward engineering to medallion architecture**

[![Python 3.8+](https://img.shields.io/badge/Python-3.8%2B-3776AB?logo=python&logoColor=white)](https://python.org)
[![Informatica](https://img.shields.io/badge/Informatica-PowerCenter-FF6D00)](https://www.informatica.com)
[![Output](https://img.shields.io/badge/Output-Excel%20%7C%20CSV%20%7C%20JSON%20%7C%20DAG-4CAF50)](#-output-files)

[Quick Start](#-quick-start) | [Architecture](#-architecture--data-flow) | [Output](#-output-files) | [Validation](#-accuracy-validation--13-dimensions)

</div>

---

## What It Does

Informatica PowerCenter stores ETL logic in proprietary XML exports (POWERMART format). This tool parses those XMLs and extracts:

- **Field-level lineage** — source table.field → transformation chain → target table.field
- **Transformation details** — expressions, lookups, joins, filters, routers, unions, SQL overrides
- **Cross-XML aggregation** — links tables shared across multiple workflows into a unified graph
- **Parameter resolution** — resolves `$Param_*` placeholders from `.par`/`.prm` files
- **Interactive DAG visualization** — HTML-based lineage graphs with field-level detail
- **Accuracy validation** — 13 weighted dimensions, automated scoring, letter grades

---

## Quick Start

### Setup

```bash
# Install dependencies
cd InformaticaReverseEngineering/scripts
pip install -r requirements.txt
```

### Full Run — All XMLs with Params, BTEQ, DAG, and Validation

```bash
python cli.py aggregate "../inputs/" \
  --param-file "../inputs/All_Params.txt" \
  --bteq-dir "../inputs/Bteq_scripts_PROD/" \
  --build-dag \
  --validate \
  -o "../output/full_run" \
  -v
```

This produces everything in one shot: Enhanced Excel (14 sheets), CSV, JSON lineage, parameter catalog, unified graph, interactive DAG (HTML + JSON + GraphML), and accuracy validation report.

Replace the folder path with a single XML file path to process just one workflow.

### Other Commands

```bash
# Single-XML deep analysis (Excel + JSON + CSV + HTML)
python cli.py analyze -i ../inputs/your_workflow.xml -o ../output/analysis --format all -v

# Visualization only (Cytoscape or Mermaid)
python cli.py visualize -i ../inputs/your_workflow.xml -o ../output/lineage.html --format cytoscape

# Standalone accuracy validation against existing output
python cli.py validate --input-dir ../inputs/ --aggregated-output ../output/full_run
```

Run `python cli.py <command> --help` for all available flags.

> **Optional — Agentic Validation Layer:** For LLM-powered validation/refinement, set `export ANTHROPIC_API_KEY=sk-ant-...` and add `--agentic-post-run` to the aggregate command.

---

## Architecture — Data Flow

```
  ┌───────────────────┐  ┌──────────────────────┐  ┌──────────────────────┐
  │ Informatica XML(s) │  │ Parameter File (opt.) │  │ BTEQ Scripts (opt.)  │
  │ POWERMART exports  │  │ All_Params.txt        │  │ .sh / .ksh scripts   │
  └────────┬──────────┘  └──────────┬───────────┘  └──────────┬───────────┘
           │                        │                          │
           └────────────────┬───────┘──────────────────────────┘
                            ▼
              ┌──────────────────────────┐
              │  Stage 0 — Initialization │
              │  Parse CLI args, collect  │
              │  XMLs, create output dir  │
              └────────────┬─────────────┘
                           ▼
              ┌──────────────────────────┐
              │  Stage 1 — Load Params   │
              │  Map $Param_* / $$Var    │
              │  values per workflow      │
              └────────────┬─────────────┘
                           ▼
  ┌────────────────────────────────────────────────────────────┐
  │  Stage 2 — Aggregation Engine (core pipeline)              │
  │                                                            │
  │  Phase 1  Parse all XMLs (PowermartParser)                 │
  │  Phase 2  Extract lineage via 3 parallel experts           │
  │           (MappingStructure, FieldMapping, OperatorLogic)  │
  │  Phase 3  Build unified graph (tables + edges)             │
  │  Phase 4  Resolve cross-mapping links                      │
  │           (XML-A target = XML-B source)                    │
  │  Phase 5  Detect schema conflicts                          │
  │  Phase 6  Compute hop counts (BFS)                         │
  └────────────────────────┬───────────────────────────────────┘
                           ▼
              ┌──────────────────────────┐
              │  Stage 3 — Extract Params │
              │  Catalog $Param_*, $$Var, │
              │  $PM* with usage locations │
              └────────────┬─────────────┘
                           ▼
              ┌──────────────────────────┐
              │  Stage 4 — Export JSON    │
              │  aggregated_lineage.json  │
              │  (table registry, field   │
              │   lineage, transforms)    │
              └────────────┬─────────────┘
                           ▼
     ┌─────────────────────┼─────────────────────┐
     ▼                     ▼                     ▼
 ┌──────────┐      ┌──────────────┐      ┌───────────┐
 │ unified_ │      │ param_       │      │ lineage   │
 │ graph    │      │ catalog      │      │ .csv      │
 │ .json    │      │ .json        │      │           │
 └──────────┘      └──────────────┘      └───────────┘
                           │
                           ▼
  ┌────────────────────────────────────────────────────────────┐
  │  Stage 6 — Enhanced Excel (14 sheets)                      │
  │  Lineage, Expressions, Unions, Routers, Joiners, Lookups,  │
  │  Pre/Post SQL, BTEQ Details, View Details, Source/Target   │
  │  Definitions, Target Load Plan, Session Execution Flow     │
  └────────────────────────┬───────────────────────────────────┘
                           ▼
              ┌──────────────────────────┐
              │  Stage 7 — DAG Builder   │
              │  Interactive HTML + JSON  │
              │  + GraphML visualization  │
              └────────────┬─────────────┘
                           ▼
              ┌──────────────────────────┐
              │  Stage 8 — Validation    │
              │  13 weighted dimensions   │
              │  → accuracy_report.xlsx   │
              └──────────────────────────┘
```

### Stage Summary

| Stage | What Happens |
|-------|-------------|
| **0 — Init** | Parse CLI args, collect `.xml` files, create versioned output directory |
| **1 — Load Params** | Read `All_Params.txt`, map `$Param_*` / `$$Variable` values per workflow/session |
| **2 — Aggregation** | Parse XMLs into sources/targets/transformations, trace field-level lineage, build unified graph, resolve cross-mapping links |
| **3 — Extract Params** | Scan documents for every `$Param_*`, `$$Variable`, `$PM*` reference with usage locations |
| **4 — Export JSON** | Write `aggregated_lineage.json` with table registry, field lineage, transformation metadata |
| **5 — Supporting Files** | Export unified graph JSON, parameter catalog JSON, conflicts report, flat CSV |
| **6 — Enhanced Excel** | 14-sheet workbook: lineage, expressions, unions, routers, joiners, lookups, pre/post SQL, BTEQ, views, source/target defs, load plan, session flow |
| **7 — DAG** | Build unified DAG (Workflow -> Session -> Mapping -> Transformation -> Field), export to JSON, GraphML, interactive HTML |
| **8 — Validation** | Compare output against XML ground truth across 13 weighted dimensions, produce accuracy report |

---

## Output Files

| File | Description |
|------|-------------|
| `*_enhanced_output.xlsx` | 14-sheet Excel: Aggregated Lineage, Source/Target Definitions, Target Load Plan, Session Execution Flow, Expression Details, Union/Router/Joiner/Lookup Details, Pre-Post SQL, BTEQ Details, View Details |
| `*_aggregated_lineage.csv` | Flat CSV with all lineage rows |
| `*_aggregated_lineage.json` | JSON lineage for downstream processing |
| `*_parameter_catalog.json` | All resolved parameters |
| `*_unified_lineage_graph.json` | Unified graph structure |
| `dag/*_dag.html` | Interactive DAG visualization (with `--build-dag`) |
| `dag/*_dag.json` | DAG in JSON format (with `--build-dag`) |
| `dag/*_dag.graphml` | GraphML for yEd/Gephi (with `--build-dag`) |
| `*_accuracy_report.xlsx` | Accuracy validation report (with `--validate`) |

---


---

## Assumptions and Limitations

- **Input format** — Expects Informatica PowerCenter POWERMART XML exports. Other Informatica formats (IICS, CDI) are not supported.
- **Parameter resolution** — `$Param_*` placeholders are only resolved when a `.par`/`.prm` parameter file is provided via `--param-file`.
- **Flat file sources/targets** — Matched by file path or partial name; may require manual review.
- **Agentic layer** — Requires an Anthropic API key and the optional dependencies listed in `requirements.txt`.
- **Output versioning** — If the output directory already exists, the CLI auto-increments the folder name (e.g., `v1` -> `v1_v2`).

---

<div align="center">

**Built for forward engineering to medallion architecture (Bronze / Silver / Gold)**

</div>
