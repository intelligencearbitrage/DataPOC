"""Path tracer for lineage traversal."""

from typing import Dict, List, Optional, Set, Tuple
from ..models.lineage_models import LineageGraph, FieldLineageEdge, EndToEndFieldLineage


class PathTracer:
    """Traces data flow paths through the lineage graph."""

    def __init__(self, graph: LineageGraph):
        """
        Initialize the path tracer.

        Args:
            graph: The lineage graph to trace
        """
        self.graph = graph

    def trace_to_sources(self, instance: str, field: str) -> List[List[FieldLineageEdge]]:
        """
        Trace all paths from a field back to its ultimate sources.

        Args:
            instance: The instance name
            field: The field name

        Returns:
            List of paths, where each path is a list of edges
        """
        node_id = f"{instance}.{field}"
        return self._trace_backward(node_id, set())

    def _trace_backward(
        self, node_id: str, visited: Set[str]
    ) -> List[List[FieldLineageEdge]]:
        """Recursively trace backward from a node."""
        if node_id in visited:
            return []  # Cycle detected

        visited.add(node_id)
        sources = self.graph.get_sources(node_id)

        if not sources:
            # This is an ultimate source
            return [[]]

        all_paths = []
        for source_id in sources:
            # Find the edge connecting source to current node
            edge = self._find_edge(source_id, node_id)
            if edge:
                sub_paths = self._trace_backward(source_id, visited.copy())
                for path in sub_paths:
                    all_paths.append(path + [edge])

        return all_paths

    def _find_edge(self, source_id: str, target_id: str) -> Optional[FieldLineageEdge]:
        """Find the edge connecting two nodes."""
        for edge in self.graph.edges:
            edge_source = f"{edge.source_instance}.{edge.source_field}"
            edge_target = f"{edge.target_instance}.{edge.target_field}"
            if edge_source == source_id and edge_target == target_id:
                return edge
        return None

    def get_all_source_fields(self, instance: str, field: str) -> List[Tuple[str, str]]:
        """
        Get all ultimate source fields for a target field.

        Args:
            instance: Target instance name
            field: Target field name

        Returns:
            List of (instance, field) tuples for ultimate sources
        """
        sources = []
        paths = self.trace_to_sources(instance, field)

        for path in paths:
            if path:
                # The first edge in the path has the source
                first_edge = path[0]
                # Check if this is an ultimate source (has no incoming edges)
                source_id = f"{first_edge.source_instance}.{first_edge.source_field}"
                if not self.graph.get_sources(source_id):
                    sources.append((first_edge.source_instance, first_edge.source_field))
            else:
                # Empty path means the node itself is a source
                sources.append((instance, field))

        return list(set(sources))

    def build_transformation_chain(self, path: List[FieldLineageEdge]) -> str:
        """
        Build a human-readable transformation chain from a path.

        Args:
            path: List of edges representing the path

        Returns:
            String describing the transformation chain
        """
        if not path:
            return "Direct source"

        parts = []
        for edge in path:
            if edge.expression:
                parts.append(f"{edge.source_instance}({edge.expression})")
            else:
                parts.append(edge.source_instance)

        return " -> ".join(parts)
