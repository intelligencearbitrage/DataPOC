"""Main lineage extraction module."""

from typing import Any, Dict, List, Optional
import time

from ..parsers.powermart_parser import PowermartDocument
from ..models.lineage_models import LineageResult, EndToEndFieldLineage, LineageGraph, FieldLineageEdge
from ..experts.base_expert import ExpertContext
from ..experts.integration_expert import IntegrationExpert
from ..experts.visual_lineage_expert import VisualLineageExpert
from ..experts.reviewer_expert import ReviewerExpert
from ..utils.logging_config import get_logger


logger = get_logger("lineage_extractor")


class LineageExtractor:
    """
    Main class for extracting field-level lineage from Informatica documents.

    Coordinates the multi-expert architecture to analyze mappings and
    extract comprehensive lineage information.
    """

    def __init__(self, parallel: bool = True, parameter_loader=None):
        """
        Initialize the lineage extractor.

        Args:
            parallel: Whether to run experts in parallel
            parameter_loader: ParameterFileLoader for resolving session-level params
        """
        self.parallel = parallel
        self.integration_expert = IntegrationExpert(parallel=parallel, parameter_loader=parameter_loader)
        self.visual_expert = VisualLineageExpert()
        self.reviewer_expert = ReviewerExpert()

    def extract(self, document: PowermartDocument) -> LineageResult:
        """
        Extract complete lineage from an Informatica document.

        Args:
            document: Parsed PowermartDocument

        Returns:
            LineageResult with all extracted lineage information
        """
        logger.info(f"Starting lineage extraction for {document.file_path or 'document'}")
        start_time = time.time()

        # Create context
        context = ExpertContext(document=document)

        # Run integration expert (orchestrates other experts)
        integration_result = self.integration_expert.analyze(context)
        context.previous_results["IntegrationExpert"] = integration_result

        # Get field mapping results for visual expert
        field_mapping_data = integration_result.data.get("expert_results", {}).get("FieldMapping", {})
        if field_mapping_data:
            from ..experts.models.expert_result import ExpertResult, ExpertStatus
            # Include both lineage_graphs AND end_to_end_lineages for visual expert
            visual_data = field_mapping_data.get("data", {}).copy()
            visual_data["end_to_end_lineages"] = integration_result.data.get("end_to_end_lineages", [])

            # Include SQL overrides from MappingStructure expert
            structure_data = integration_result.data.get("expert_results", {}).get("MappingStructure", {})
            visual_data["sql_overrides"] = structure_data.get("data", {}).get("sql_overrides", [])

            context.previous_results["FieldMapping"] = ExpertResult(
                expert_name="FieldMapping",
                status=ExpertStatus.COMPLETED,
                data=visual_data,
            )

        # Run visual lineage expert
        visual_result = self.visual_expert.analyze(context)
        context.previous_results["VisualLineage"] = visual_result

        # Run reviewer expert
        review_result = self.reviewer_expert.analyze(context)

        # Build final result
        result = self._build_result(document, integration_result, visual_result, review_result)

        elapsed = time.time() - start_time
        logger.info(f"Lineage extraction complete in {elapsed:.2f}s")

        return result

    def _build_result(
        self,
        document: PowermartDocument,
        integration_result,
        visual_result,
        review_result,
    ) -> LineageResult:
        """Build the final LineageResult."""
        # Get end-to-end lineages from integration result
        lineages_data = integration_result.data.get("end_to_end_lineages", [])
        field_lineages = []

        for ld in lineages_data:
            # Convert intermediate_steps from dict to FieldLineageEdge objects
            intermediate_steps = []
            for step_dict in ld.get("intermediate_steps", []):
                edge = FieldLineageEdge(
                    source_instance=step_dict.get("source_instance", ""),
                    source_field=step_dict.get("source_field", ""),
                    source_type=step_dict.get("source_type", ""),
                    target_instance=step_dict.get("target_instance", ""),
                    target_field=step_dict.get("target_field", ""),
                    target_type=step_dict.get("target_type", ""),
                    expression=step_dict.get("expression", ""),
                    expression_explanation=step_dict.get("expression_explanation", ""),
                )
                intermediate_steps.append(edge)

            lineage = EndToEndFieldLineage(
                target_table=ld.get("target_table", ""),
                target_field=ld.get("target_field", ""),
                target_datatype=ld.get("target_datatype", ""),
                mapping_name=ld.get("mapping_name", ""),
                session_name=ld.get("session_name", ""),
                ultimate_sources=ld.get("ultimate_sources", []),
                intermediate_steps=intermediate_steps,
                transformation_chain=ld.get("transformation_chain", ""),
                transformation_explanation=ld.get("transformation_explanation", ""),
                hop_count=ld.get("hop_count", 0),
                lookup_tables=ld.get("lookup_tables", []),
                aggregation_applied=ld.get("aggregation_applied", False),
                filter_applied=ld.get("filter_applied", False),
                filter_condition=ld.get("filter_condition", ""),
                router_applied=ld.get("router_applied", False),
                router_condition=ld.get("router_condition", ""),
                joiner_condition=ld.get("joiner_condition", ""),
                joiner_type=ld.get("joiner_type", ""),
                update_strategy=ld.get("update_strategy", ""),
                sql_override=ld.get("sql_override", ""),
                source_qualifier_name=ld.get("source_qualifier_name", ""),
                resolved_sql_override=ld.get("resolved_sql_override", ""),
                custom_transformation_inputs=ld.get("custom_transformation_inputs", []),
                lookup_name=ld.get("lookup_name", ""),
                lookup_condition=ld.get("lookup_condition", ""),
                lookup_sql_override=ld.get("lookup_sql_override", ""),
                sql_logic=ld.get("sql_logic", ""),
                union_details=ld.get("union_details", {}),
                lookup_input_lineage=ld.get("lookup_input_lineage", ""),
            )
            field_lineages.append(lineage)

        # Get review data
        review_data = review_result.data if review_result.is_successful else {}
        coverage = review_data.get("coverage_report", {})

        # Get unmapped target fields as a list (not the count from coverage)
        # The actual list is in the field mapping result
        field_mapping_data = integration_result.data.get("expert_results", {}).get("FieldMapping", {})
        unmapped_fields_list = field_mapping_data.get("data", {}).get("unmapped_fields", [])
        # Convert to the expected format if needed
        unmapped_target_fields = []
        for uf in unmapped_fields_list:
            if isinstance(uf, dict):
                unmapped_target_fields.append({
                    "target": uf.get("target", ""),
                    "field": uf.get("field", ""),
                    "mapping": uf.get("mapping", ""),
                })
            else:
                # Handle if it's already in a different format
                unmapped_target_fields.append(uf)

        # Collect lookup tables
        operator_data = integration_result.data.get("expert_results", {}).get("OperatorLogic", {}).get("data", {})
        lookups = operator_data.get("lookups", [])
        lookup_tables = list(set(l.get("table_name", "") for l in lookups if l.get("table_name")))

        # Collect aggregators and filters
        aggregators = [a.get("name") for a in operator_data.get("aggregators", [])]
        filters = [f.get("name") for f in operator_data.get("filters", [])]

        return LineageResult(
            mapping_name=document.file_path or "unknown",
            source_count=document.source_count,
            target_count=document.target_count,
            transformation_count=len(document.transformations),
            field_lineages=field_lineages,
            unmapped_target_fields=unmapped_target_fields,
            lookup_tables=lookup_tables,
            aggregators=aggregators,
            filters=filters,
        )

    def extract_for_mapping(
        self, document: PowermartDocument, mapping_name: str
    ) -> Optional[LineageResult]:
        """
        Extract lineage for a specific mapping.

        Args:
            document: Parsed PowermartDocument
            mapping_name: Name of the mapping to analyze

        Returns:
            LineageResult for the specific mapping, or None if not found
        """
        mapping = document.get_mapping(mapping_name)
        if not mapping:
            logger.warning(f"Mapping not found: {mapping_name}")
            return None

        # Create a filtered document with only the specified mapping
        # For now, just run full extraction
        # TODO: Implement targeted extraction
        return self.extract(document)
