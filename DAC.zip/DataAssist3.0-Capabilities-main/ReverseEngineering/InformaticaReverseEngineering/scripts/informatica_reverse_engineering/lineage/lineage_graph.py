"""Lineage graph builder and utilities."""

from typing import Dict, List, Optional, Set
from ..models.lineage_models import LineageGraph, LineageNode, FieldLineageEdge, LineageNodeType
from ..models.mapping_models import Mapping
from ..models.connector_models import Connector


class LineageGraphBuilder:
    """Builder for constructing lineage graphs from Informatica mappings."""

    def build_from_mapping(self, mapping: Mapping) -> LineageGraph:
        """
        Build a lineage graph from a mapping's connectors.

        Args:
            mapping: The Informatica mapping

        Returns:
            LineageGraph representing the data flow
        """
        graph = LineageGraph()

        # Build transformation lookup
        trans_lookup = {t.name.lower(): t for t in mapping.transformations}

        for connector in mapping.connectors:
            # Create edge
            edge = FieldLineageEdge(
                source_instance=connector.from_instance,
                source_field=connector.from_field,
                source_type=connector.from_instance_type,
                target_instance=connector.to_instance,
                target_field=connector.to_field,
                target_type=connector.to_instance_type,
            )

            # Try to get expression
            trans = trans_lookup.get(connector.from_instance.lower())
            if trans:
                field = trans.get_field(connector.from_field)
                if field and field.expression:
                    edge.expression = field.expression

            graph.add_edge(edge)

            # Create source node
            source_node = LineageNode(
                instance_name=connector.from_instance,
                field_name=connector.from_field,
                instance_type=connector.from_instance_type,
                node_type=self._get_node_type(connector.from_instance_type),
            )
            graph.add_node(source_node)

            # Create target node
            target_node = LineageNode(
                instance_name=connector.to_instance,
                field_name=connector.to_field,
                instance_type=connector.to_instance_type,
                node_type=self._get_node_type(connector.to_instance_type),
            )
            graph.add_node(target_node)

        return graph

    def _get_node_type(self, instance_type: str) -> LineageNodeType:
        """Determine node type from instance type string."""
        inst_lower = instance_type.lower()
        if "source" in inst_lower:
            return LineageNodeType.SOURCE
        elif "target" in inst_lower:
            return LineageNodeType.TARGET
        elif "lookup" in inst_lower:
            return LineageNodeType.LOOKUP
        else:
            return LineageNodeType.TRANSFORMATION

    def get_instance_level_graph(self, graph: LineageGraph) -> Dict:
        """
        Create a simplified instance-level graph.

        Args:
            graph: The full field-level graph

        Returns:
            Dictionary with instances and connections
        """
        instances: Dict[str, Dict] = {}
        connections: Set[tuple] = set()

        for edge in graph.edges:
            # Track instances
            if edge.source_instance not in instances:
                instances[edge.source_instance] = {
                    "name": edge.source_instance,
                    "type": edge.source_type,
                    "fields": set(),
                }
            instances[edge.source_instance]["fields"].add(edge.source_field)

            if edge.target_instance not in instances:
                instances[edge.target_instance] = {
                    "name": edge.target_instance,
                    "type": edge.target_type,
                    "fields": set(),
                }
            instances[edge.target_instance]["fields"].add(edge.target_field)

            # Track connections
            if edge.source_instance != edge.target_instance:
                connections.add((edge.source_instance, edge.target_instance))

        # Convert sets to lists for serialization
        for inst in instances.values():
            inst["fields"] = list(inst["fields"])
            inst["field_count"] = len(inst["fields"])

        return {
            "instances": list(instances.values()),
            "connections": [{"from": c[0], "to": c[1]} for c in connections],
        }
