"""Transformation classifier for categorizing transformations."""

from enum import Enum
from typing import Dict, List, Optional
from ..models.transformation_models import Transformation, TransformationType


class TransformationCategory(Enum):
    """High-level categories for transformations."""

    DATA_MOVEMENT = "data_movement"  # Source Qualifier, Target Definition
    DATA_TRANSFORMATION = "data_transformation"  # Expression
    DATA_FILTERING = "data_filtering"  # Filter, Router
    DATA_AGGREGATION = "data_aggregation"  # Aggregator
    DATA_LOOKUP = "data_lookup"  # Lookup
    DATA_JOIN = "data_join"  # Joiner
    DATA_NORMALIZATION = "data_normalization"  # Normalizer
    DATA_SORTING = "data_sorting"  # Sorter
    CONTROL_FLOW = "control_flow"  # Update Strategy, Sequence Generator
    CUSTOM = "custom"  # Custom transformations
    UNKNOWN = "unknown"


class TransformationClassifier:
    """Classifies transformations into categories."""

    # Mapping from TransformationType to TransformationCategory
    TYPE_TO_CATEGORY: Dict[TransformationType, TransformationCategory] = {
        TransformationType.SOURCE_QUALIFIER: TransformationCategory.DATA_MOVEMENT,
        TransformationType.SOURCE_DEFINITION: TransformationCategory.DATA_MOVEMENT,
        TransformationType.TARGET_DEFINITION: TransformationCategory.DATA_MOVEMENT,
        TransformationType.EXPRESSION: TransformationCategory.DATA_TRANSFORMATION,
        TransformationType.FILTER: TransformationCategory.DATA_FILTERING,
        TransformationType.ROUTER: TransformationCategory.DATA_FILTERING,
        TransformationType.AGGREGATOR: TransformationCategory.DATA_AGGREGATION,
        TransformationType.LOOKUP_PROCEDURE: TransformationCategory.DATA_LOOKUP,
        TransformationType.JOINER: TransformationCategory.DATA_JOIN,
        TransformationType.NORMALIZER: TransformationCategory.DATA_NORMALIZATION,
        TransformationType.SORTER: TransformationCategory.DATA_SORTING,
        TransformationType.RANK: TransformationCategory.DATA_SORTING,
        TransformationType.UPDATE_STRATEGY: TransformationCategory.CONTROL_FLOW,
        TransformationType.SEQUENCE_GENERATOR: TransformationCategory.CONTROL_FLOW,
        TransformationType.CUSTOM: TransformationCategory.CUSTOM,
        TransformationType.SQL: TransformationCategory.DATA_TRANSFORMATION,
        TransformationType.STORED_PROCEDURE: TransformationCategory.CUSTOM,
        TransformationType.UNION: TransformationCategory.DATA_JOIN,
    }

    def classify(self, transformation: Transformation) -> TransformationCategory:
        """
        Classify a transformation.

        Args:
            transformation: The transformation to classify

        Returns:
            TransformationCategory
        """
        trans_type = transformation.transformation_type
        return self.TYPE_TO_CATEGORY.get(trans_type, TransformationCategory.UNKNOWN)

    def classify_by_type(self, type_str: str) -> TransformationCategory:
        """
        Classify by transformation type string.

        Args:
            type_str: Transformation type string

        Returns:
            TransformationCategory
        """
        trans_type = TransformationType.from_string(type_str)
        return self.TYPE_TO_CATEGORY.get(trans_type, TransformationCategory.UNKNOWN)

    def get_category_description(self, category: TransformationCategory) -> str:
        """Get description for a category."""
        descriptions = {
            TransformationCategory.DATA_MOVEMENT: "Moves data between sources and targets",
            TransformationCategory.DATA_TRANSFORMATION: "Transforms field values using expressions",
            TransformationCategory.DATA_FILTERING: "Filters or routes rows based on conditions",
            TransformationCategory.DATA_AGGREGATION: "Aggregates data using GROUP BY operations",
            TransformationCategory.DATA_LOOKUP: "Looks up values from reference tables",
            TransformationCategory.DATA_JOIN: "Joins multiple data streams",
            TransformationCategory.DATA_NORMALIZATION: "Normalizes nested or repeated data",
            TransformationCategory.DATA_SORTING: "Sorts or ranks data",
            TransformationCategory.CONTROL_FLOW: "Controls data loading behavior",
            TransformationCategory.CUSTOM: "Custom or stored procedure transformation",
            TransformationCategory.UNKNOWN: "Unknown transformation type",
        }
        return descriptions.get(category, "Unknown")

    def classify_all(
        self, transformations: List[Transformation]
    ) -> Dict[TransformationCategory, List[Transformation]]:
        """
        Classify all transformations and group by category.

        Args:
            transformations: List of transformations

        Returns:
            Dictionary mapping categories to transformations
        """
        result: Dict[TransformationCategory, List[Transformation]] = {}

        for trans in transformations:
            category = self.classify(trans)
            if category not in result:
                result[category] = []
            result[category].append(trans)

        return result
