"""Expression analyzer for transformation logic."""

from typing import Any, Dict, List, Optional
from ..parsers.expression_parser import ExpressionParser, ParsedExpression


class ExpressionAnalyzer:
    """Analyzes transformation expressions and provides explanations."""

    def __init__(self):
        self.parser = ExpressionParser()

    def analyze(self, expression: str) -> ParsedExpression:
        """
        Analyze an expression and return parsed result.

        Args:
            expression: The expression to analyze

        Returns:
            ParsedExpression with analysis results
        """
        return self.parser.parse(expression)

    def get_explanation(self, expression: str) -> str:
        """
        Get human-readable explanation of an expression.

        Args:
            expression: The expression to explain

        Returns:
            Human-readable explanation
        """
        parsed = self.parser.parse(expression)
        return parsed.explanation

    def get_referenced_fields(self, expression: str) -> List[str]:
        """
        Get all fields referenced in an expression.

        Args:
            expression: The expression to analyze

        Returns:
            List of field names
        """
        parsed = self.parser.parse(expression)
        return parsed.referenced_fields

    def get_functions_used(self, expression: str) -> List[str]:
        """
        Get all functions used in an expression.

        Args:
            expression: The expression to analyze

        Returns:
            List of function names
        """
        parsed = self.parser.parse(expression)
        return parsed.functions_used

    def is_aggregate(self, expression: str) -> bool:
        """
        Check if expression contains aggregate functions.

        Args:
            expression: The expression to check

        Returns:
            True if contains aggregates
        """
        parsed = self.parser.parse(expression)
        aggregate_functions = {"SUM", "COUNT", "AVG", "MAX", "MIN", "FIRST", "LAST", "MEDIAN", "STDDEV"}
        return bool(set(parsed.functions_used) & aggregate_functions)

    def analyze_batch(self, expressions: List[str]) -> List[ParsedExpression]:
        """
        Analyze multiple expressions.

        Args:
            expressions: List of expressions

        Returns:
            List of ParsedExpression results
        """
        return [self.analyze(expr) for expr in expressions]
