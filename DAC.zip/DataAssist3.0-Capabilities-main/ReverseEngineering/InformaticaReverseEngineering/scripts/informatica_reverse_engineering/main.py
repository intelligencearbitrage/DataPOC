"""Main entry point for Informatica Reverse Engineering tool."""

import sys

from .agent_interface.cli import main as cli_main


def main():
    """Main entry point."""
    return cli_main()


if __name__ == "__main__":
    sys.exit(main())
