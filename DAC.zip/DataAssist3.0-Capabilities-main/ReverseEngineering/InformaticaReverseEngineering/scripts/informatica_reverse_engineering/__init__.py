"""
Informatica PowerCenter Reverse Engineering Tool

A tool to reverse engineer Informatica PowerCenter mappings and workflows from XML exports,
extracting field-level lineage information and generating comprehensive documentation.
"""

__version__ = "1.0.0"
__author__ = "Informatica RE Team"

from .main import main

__all__ = ["main", "__version__"]
