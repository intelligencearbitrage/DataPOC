"""Programmatic API for Informatica Reverse Engineering."""

from pathlib import Path
from typing import Any, Dict, List, Optional, Union

from ..parsers.powermart_parser import PowermartParser, PowermartDocument
from ..lineage.lineage_extractor import LineageExtractor
from ..models.lineage_models import LineageResult
from ..experts.integration_expert import IntegrationExpert
from ..experts.base_expert import ExpertContext
from ..exporters.excel_exporter import ExcelExporter
from ..exporters.json_exporter import JSONExporter
from ..exporters.documentation_generator import DocumentationGenerator
from ..visualization.visual_exporter import VisualExporter
from ..utils.logging_config import setup_logging


class InformaticaREAPI:
    """
    High-level API for Informatica reverse engineering.

    Example usage:
        api = InformaticaREAPI()
        result = api.analyze("mapping.xml")
        api.export_excel(result, "output.xlsx")
    """

    def __init__(self, parallel: bool = True, verbose: bool = False):
        """
        Initialize the API.

        Args:
            parallel: Use parallel processing for experts
            verbose: Enable verbose logging
        """
        log_level = 10 if verbose else 20
        setup_logging(level=log_level)

        self.parallel = parallel
        self.parser = PowermartParser()
        self.extractor = LineageExtractor(parallel=parallel)
        self.integration_expert = IntegrationExpert(parallel=parallel)

    def parse(self, file_path: Union[str, Path]) -> PowermartDocument:
        """
        Parse an Informatica XML file.

        Args:
            file_path: Path to XML file

        Returns:
            PowermartDocument with parsed content
        """
        return self.parser.parse_file(file_path)

    def analyze(self, file_path: Union[str, Path]) -> Dict[str, Any]:
        """
        Perform full analysis on an Informatica XML file.

        Args:
            file_path: Path to XML file

        Returns:
            Dictionary with document, lineage_result, and expert_analysis
        """
        document = self.parse(file_path)
        context = ExpertContext(document=document)

        # Run integration expert
        integration_result = self.integration_expert.analyze(context)

        # Extract lineage
        lineage_result = self.extractor.extract(document)

        return {
            "document": document,
            "lineage_result": lineage_result,
            "expert_analysis": integration_result.data,
        }

    def extract_lineage(self, file_path: Union[str, Path]) -> LineageResult:
        """
        Extract field-level lineage from an Informatica XML file.

        Args:
            file_path: Path to XML file

        Returns:
            LineageResult with extracted lineage
        """
        document = self.parse(file_path)
        return self.extractor.extract(document)

    def export_excel(
        self,
        analysis_result: Dict[str, Any],
        output_path: Union[str, Path],
    ) -> str:
        """
        Export analysis results to Excel.

        Args:
            analysis_result: Result from analyze()
            output_path: Output file path

        Returns:
            Path to created file
        """
        exporter = ExcelExporter()
        return exporter.export(
            analysis_result["lineage_result"],
            analysis_result["document"],
            output_path,
            analysis_result.get("expert_analysis"),
        )

    def export_json(
        self,
        analysis_result: Dict[str, Any],
        output_path: Union[str, Path],
    ) -> str:
        """
        Export analysis results to JSON.

        Args:
            analysis_result: Result from analyze()
            output_path: Output file path

        Returns:
            Path to created file
        """
        exporter = JSONExporter()
        return exporter.export(
            analysis_result["lineage_result"],
            analysis_result["document"],
            output_path,
            analysis_result.get("expert_analysis"),
        )

    def export_documentation(
        self,
        analysis_result: Dict[str, Any],
        output_path: Union[str, Path],
        title: str = "Informatica Lineage Analysis",
    ) -> str:
        """
        Export analysis results to HTML documentation.

        Args:
            analysis_result: Result from analyze()
            output_path: Output file path
            title: Document title

        Returns:
            Path to created file
        """
        generator = DocumentationGenerator()
        return generator.generate(
            analysis_result["lineage_result"],
            analysis_result["document"],
            output_path,
            title,
            analysis_result.get("expert_analysis"),
        )

    def export_visualization(
        self,
        analysis_result: Dict[str, Any],
        output_path: Union[str, Path],
        title: str = "Informatica Lineage",
    ) -> str:
        """
        Export visual lineage to HTML.

        Args:
            analysis_result: Result from analyze()
            output_path: Output file path
            title: Visualization title

        Returns:
            Path to created file
        """
        from ..experts.visual_lineage_expert import VisualLineageExpert
        from ..experts.models.expert_result import ExpertResult, ExpertStatus

        document = analysis_result["document"]
        expert_analysis = analysis_result.get("expert_analysis", {})

        # Create context and run visual expert
        context = ExpertContext(document=document)
        field_mapping_data = expert_analysis.get("expert_results", {}).get("FieldMapping", {}).get("data", {})
        context.previous_results["FieldMapping"] = ExpertResult(
            expert_name="FieldMapping",
            status=ExpertStatus.COMPLETED,
            data=field_mapping_data,
        )

        vis_expert = VisualLineageExpert()
        vis_result = vis_expert.analyze(context)

        visual_exporter = VisualExporter()
        cytoscape_data = vis_result.data.get("cytoscape_data", {})

        return visual_exporter.export_all_mappings_html(cytoscape_data, output_path, title)
