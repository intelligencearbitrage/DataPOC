"""Batch processor for multiple Informatica XML files."""

from pathlib import Path
from typing import List, Optional, Union
from dataclasses import dataclass, field

from ..parsers.powermart_parser import PowermartParser, PowermartDocument
from ..lineage.lineage_extractor import LineageExtractor
from ..models.lineage_models import LineageResult
from ..utils.logging_config import get_logger

logger = get_logger("batch_processor")


@dataclass
class BatchResult:
    """Result from batch processing."""

    successful: List[str] = field(default_factory=list)
    failed: List[dict] = field(default_factory=list)
    documents: List[PowermartDocument] = field(default_factory=list)
    lineage_results: List[LineageResult] = field(default_factory=list)

    @property
    def total(self) -> int:
        return len(self.successful) + len(self.failed)

    @property
    def success_rate(self) -> float:
        if self.total == 0:
            return 100.0
        return (len(self.successful) / self.total) * 100


class BatchProcessor:
    """Processes multiple Informatica XML files."""

    def __init__(self, parallel: bool = True):
        """
        Initialize batch processor.

        Args:
            parallel: Whether to use parallel processing for experts
        """
        self.parallel = parallel
        self.parser = PowermartParser()
        self.extractor = LineageExtractor(parallel=parallel)

    def process_directory(
        self,
        input_dir: Union[str, Path],
        pattern: str = "*.xml",
    ) -> BatchResult:
        """
        Process all XML files in a directory.

        Args:
            input_dir: Directory containing XML files
            pattern: Glob pattern for file matching

        Returns:
            BatchResult with processing results
        """
        input_dir = Path(input_dir)
        if not input_dir.exists():
            raise FileNotFoundError(f"Directory not found: {input_dir}")

        # Find files (handle both .xml and .XML)
        files = list(input_dir.glob(pattern))
        files.extend(list(input_dir.glob(pattern.upper())))
        files = list(set(files))  # Remove duplicates

        logger.info(f"Found {len(files)} files matching pattern '{pattern}'")

        return self.process_files(files)

    def process_files(self, files: List[Path]) -> BatchResult:
        """
        Process a list of XML files.

        Args:
            files: List of file paths

        Returns:
            BatchResult with processing results
        """
        result = BatchResult()

        for file_path in files:
            try:
                logger.info(f"Processing: {file_path.name}")

                # Parse document
                document = self.parser.parse_file(file_path)
                result.documents.append(document)

                # Extract lineage
                lineage_result = self.extractor.extract(document)
                result.lineage_results.append(lineage_result)

                result.successful.append(str(file_path))
                logger.info(f"  Success: {document.source_count} sources, "
                           f"{document.target_count} targets, "
                           f"{len(lineage_result.field_lineages)} lineages")

            except Exception as e:
                logger.error(f"  Failed: {e}")
                result.failed.append({
                    "file": str(file_path),
                    "error": str(e),
                })

        logger.info(f"Batch processing complete: "
                   f"{len(result.successful)}/{result.total} successful "
                   f"({result.success_rate:.1f}%)")

        return result

    def process_single(self, file_path: Union[str, Path]) -> tuple:
        """
        Process a single XML file.

        Args:
            file_path: Path to XML file

        Returns:
            Tuple of (PowermartDocument, LineageResult)
        """
        file_path = Path(file_path)
        document = self.parser.parse_file(file_path)
        lineage_result = self.extractor.extract(document)
        return document, lineage_result
