"""Command-line interface for Informatica Reverse Engineering tool."""

import argparse
import sys
from pathlib import Path
from typing import List, Optional

from ..parsers.powermart_parser import PowermartParser
from ..lineage.lineage_extractor import LineageExtractor
from ..exporters.excel_exporter import ExcelExporter
from ..exporters.json_exporter import JSONExporter
from ..exporters.csv_exporter import CSVExporter
from ..exporters.documentation_generator import DocumentationGenerator
from ..visualization.visual_exporter import VisualExporter
from ..experts.integration_expert import IntegrationExpert
from ..experts.base_expert import ExpertContext
from ..utils.logging_config import setup_logging, get_logger
from ..utils.path_utils import sanitize_path

# Agentic layer — soft dependency
try:
    from ..agentic.graph import MultiAgentGraph, create_initial_state
    AGENTIC_AVAILABLE = True
except ImportError:
    MultiAgentGraph = None
    create_initial_state = None
    AGENTIC_AVAILABLE = False


def main(args: Optional[List[str]] = None):
    """Main entry point for CLI."""
    parser = create_parser()
    parsed_args = parser.parse_args(args)

    # Setup logging
    log_level = 10 if parsed_args.verbose else 20  # DEBUG or INFO
    setup_logging(level=log_level)
    logger = get_logger("cli")

    # Handle commands
    if parsed_args.command == "analyze":
        return cmd_analyze(parsed_args, logger)
    elif parsed_args.command == "lineage":
        return cmd_lineage(parsed_args, logger)
    elif parsed_args.command == "batch":
        return cmd_batch(parsed_args, logger)
    elif parsed_args.command == "visualize":
        return cmd_visualize(parsed_args, logger)
    else:
        parser.print_help()
        return 1


def create_parser() -> argparse.ArgumentParser:
    """Create argument parser."""
    parser = argparse.ArgumentParser(
        prog="informatica-re",
        description="Informatica PowerCenter Reverse Engineering Tool",
    )
    parser.add_argument("-v", "--verbose", action="store_true", help="Verbose output")

    subparsers = parser.add_subparsers(dest="command", help="Commands")

    # Analyze command
    analyze_parser = subparsers.add_parser(
        "analyze", help="Analyze Informatica XML file"
    )
    analyze_parser.add_argument(
        "-i", "--input", required=True, help="Input XML file"
    )
    analyze_parser.add_argument(
        "-o", "--output", required=True, help="Output directory"
    )
    analyze_parser.add_argument(
        "--title", default="Informatica Analysis", help="Report title"
    )
    analyze_parser.add_argument(
        "--format", choices=["all", "excel", "json", "csv", "html"],
        default="all", help="Output format"
    )
    analyze_parser.add_argument(
        "--agentic-post-run", action="store_true",
        help="Run agentic validation/refinement after analysis"
    )
    analyze_parser.add_argument(
        "--agentic-manifest",
        help="Path to ground-truth manifest JSON for agentic validation"
    )
    analyze_parser.add_argument(
        "--max-agentic-retries", type=int, default=3,
        help="Max agentic refinement iterations (default: 3)"
    )
    analyze_parser.add_argument(
        "--param-file",
        nargs="*",
        default=None,
        help="One or more Informatica .par/.prm parameter files to resolve $Param placeholders"
    )

    # Lineage command
    lineage_parser = subparsers.add_parser(
        "lineage", help="Extract field-level lineage"
    )
    lineage_parser.add_argument(
        "-i", "--input", required=True, help="Input XML file"
    )
    lineage_parser.add_argument(
        "-o", "--output", required=True, help="Output file path"
    )
    lineage_parser.add_argument(
        "--format", choices=["excel", "json", "csv"],
        default="excel", help="Output format"
    )

    # Batch command
    batch_parser = subparsers.add_parser(
        "batch", help="Process multiple XML files"
    )
    batch_parser.add_argument(
        "-i", "--input", required=True, help="Input directory"
    )
    batch_parser.add_argument(
        "-o", "--output", required=True, help="Output directory"
    )
    batch_parser.add_argument(
        "--pattern", default="*.xml", help="File pattern (default: *.xml)"
    )
    batch_parser.add_argument(
        "--title", default="Informatica Batch Analysis", help="Report title"
    )

    # Visualize command
    viz_parser = subparsers.add_parser(
        "visualize", help="Generate visual lineage"
    )
    viz_parser.add_argument(
        "-i", "--input", required=True, help="Input XML file"
    )
    viz_parser.add_argument(
        "-o", "--output", required=True, help="Output HTML file"
    )
    viz_parser.add_argument(
        "--format", choices=["cytoscape", "mermaid"],
        default="cytoscape", help="Visualization format"
    )
    viz_parser.add_argument(
        "--title", default="Informatica Lineage", help="Visualization title"
    )

    return parser


def cmd_analyze(args, logger):
    """Handle analyze command."""
    input_path = sanitize_path(args.input)
    output_dir = sanitize_path(args.output)

    if not input_path.exists():
        logger.error(f"Input file not found: {input_path}")
        return 1

    output_dir.mkdir(parents=True, exist_ok=True)

    logger.info(f"Analyzing: {input_path}")

    # Parse document
    parser = PowermartParser()
    document = parser.parse_file(input_path)

    logger.info(document.summary())

    # Run full analysis with integration expert
    context = ExpertContext(document=document)
    integration_expert = IntegrationExpert(parallel=True)
    integration_result = integration_expert.analyze(context)

    # Extract lineage
    extractor = LineageExtractor()
    lineage_result = extractor.extract(document)

    # Export based on format
    output_format = args.format
    created_files = []

    if output_format in ["all", "excel"]:
        excel_exporter = ExcelExporter()
        excel_path = output_dir / f"{input_path.stem}_lineage.xlsx"
        excel_exporter.export(lineage_result, document, excel_path, integration_result.data)
        created_files.append(str(excel_path))
        logger.info(f"Created: {excel_path}")

    if output_format in ["all", "json"]:
        json_exporter = JSONExporter()
        json_path = output_dir / f"{input_path.stem}_lineage.json"
        json_exporter.export(lineage_result, document, json_path, integration_result.data)
        created_files.append(str(json_path))
        logger.info(f"Created: {json_path}")

    if output_format in ["all", "csv"]:
        csv_exporter = CSVExporter()
        csv_files = csv_exporter.export(lineage_result, document, output_dir, f"{input_path.stem}_")
        created_files.extend(csv_files)
        logger.info(f"Created {len(csv_files)} CSV files")

    if output_format in ["all", "html"]:
        doc_generator = DocumentationGenerator()
        html_path = output_dir / f"{input_path.stem}_documentation.html"
        doc_generator.generate(lineage_result, document, html_path, args.title, integration_result.data)
        created_files.append(str(html_path))
        logger.info(f"Created: {html_path}")

        # Also create visual lineage
        visual_exporter = VisualExporter()
        visual_result = integration_result.data.get("expert_results", {}).get("FieldMapping", {}).get("data", {})
        if visual_result:
            from ..experts.visual_lineage_expert import VisualLineageExpert

            # Include SQL overrides from MappingStructure expert
            structure_data = integration_result.data.get("expert_results", {}).get("MappingStructure", {})
            sql_overrides = structure_data.get("data", {}).get("sql_overrides", [])
            visual_data = visual_result.copy()
            visual_data["sql_overrides"] = sql_overrides

            vis_expert = VisualLineageExpert()
            context.previous_results["FieldMapping"] = type('obj', (object,), {
                'is_successful': True,
                'data': visual_data
            })()
            vis_result = vis_expert.analyze(context)

            cytoscape_data = vis_result.data.get("cytoscape_data", {})
            if cytoscape_data:
                viz_path = output_dir / f"{input_path.stem}_visual_lineage.html"
                visual_exporter.export_all_mappings_html(cytoscape_data, viz_path, args.title)
                created_files.append(str(viz_path))
                logger.info(f"Created: {viz_path}")

    logger.info(f"Analysis complete. Created {len(created_files)} files.")

    if args.agentic_post_run:
        try:
            execute_agentic_post_run(
                input_path, output_dir,
                getattr(args, 'agentic_manifest', None),
                args.max_agentic_retries, logger,
            )
        except Exception as exc:
            logger.error(f"Agentic post-run failed: {exc}")

    return 0


def cmd_lineage(args, logger):
    """Handle lineage command."""
    input_path = sanitize_path(args.input)
    output_path = sanitize_path(args.output)

    if not input_path.exists():
        logger.error(f"Input file not found: {input_path}")
        return 1

    logger.info(f"Extracting lineage from: {input_path}")

    # Parse and extract
    parser = PowermartParser()
    document = parser.parse_file(input_path)

    extractor = LineageExtractor()
    lineage_result = extractor.extract(document)

    # Export
    output_format = args.format
    output_path.parent.mkdir(parents=True, exist_ok=True)

    if output_format == "excel":
        exporter = ExcelExporter()
        exporter.export(lineage_result, document, output_path)
    elif output_format == "json":
        exporter = JSONExporter()
        exporter.export(lineage_result, document, output_path)
    elif output_format == "csv":
        exporter = CSVExporter()
        exporter.export(lineage_result, document, output_path.parent, output_path.stem + "_")

    logger.info(f"Lineage exported to: {output_path}")
    return 0


def cmd_batch(args, logger):
    """Handle batch command."""
    input_dir = sanitize_path(args.input)
    output_dir = sanitize_path(args.output)

    if not input_dir.exists():
        logger.error(f"Input directory not found: {input_dir}")
        return 1

    output_dir.mkdir(parents=True, exist_ok=True)

    # Find XML files
    pattern = args.pattern.upper()  # Handle .XML extension
    xml_files = list(input_dir.glob(args.pattern)) + list(input_dir.glob(pattern))
    xml_files = list(set(xml_files))  # Remove duplicates

    if not xml_files:
        logger.error(f"No files matching pattern '{args.pattern}' found in {input_dir}")
        return 1

    logger.info(f"Found {len(xml_files)} XML files to process")

    parser = PowermartParser()
    extractor = LineageExtractor()
    excel_exporter = ExcelExporter()

    for xml_file in xml_files:
        logger.info(f"Processing: {xml_file.name}")
        try:
            document = parser.parse_file(xml_file)
            lineage_result = extractor.extract(document)

            output_path = output_dir / f"{xml_file.stem}_lineage.xlsx"
            excel_exporter.export(lineage_result, document, output_path)
            logger.info(f"  -> {output_path.name}")
        except Exception as e:
            logger.error(f"  Error processing {xml_file.name}: {e}")

    logger.info("Batch processing complete")
    return 0


def cmd_visualize(args, logger):
    """Handle visualize command."""
    input_path = sanitize_path(args.input)
    output_path = sanitize_path(args.output)

    if not input_path.exists():
        logger.error(f"Input file not found: {input_path}")
        return 1

    logger.info(f"Generating visualization for: {input_path}")

    # Parse and analyze
    parser = PowermartParser()
    document = parser.parse_file(input_path)

    context = ExpertContext(document=document)
    integration_expert = IntegrationExpert(parallel=True)
    integration_result = integration_expert.analyze(context)

    # Get visual data
    from ..experts.visual_lineage_expert import VisualLineageExpert
    from ..experts.models.expert_result import ExpertResult, ExpertStatus

    field_mapping_data = integration_result.data.get("expert_results", {}).get("FieldMapping", {}).get("data", {})

    # Include SQL overrides from MappingStructure expert
    structure_data = integration_result.data.get("expert_results", {}).get("MappingStructure", {})
    sql_overrides = structure_data.get("data", {}).get("sql_overrides", [])
    visual_data = field_mapping_data.copy()
    visual_data["sql_overrides"] = sql_overrides

    context.previous_results["FieldMapping"] = ExpertResult(
        expert_name="FieldMapping",
        status=ExpertStatus.COMPLETED,
        data=visual_data,
    )

    vis_expert = VisualLineageExpert()
    vis_result = vis_expert.analyze(context)

    visual_exporter = VisualExporter()
    output_path.parent.mkdir(parents=True, exist_ok=True)

    if args.format == "cytoscape":
        cytoscape_data = vis_result.data.get("cytoscape_data", {})
        visual_exporter.export_all_mappings_html(cytoscape_data, output_path, args.title)
    else:  # mermaid
        mermaid_diagrams = vis_result.data.get("mermaid_diagrams", {})
        visual_exporter.export_mermaid_html(mermaid_diagrams, output_path, args.title)

    logger.info(f"Visualization saved to: {output_path}")
    return 0


def execute_agentic_post_run(xml_path, output_dir, ground_truth=None, max_retries=3, logger=None):
    """Run the agentic validation/refinement loop after script-layer extraction.

    Parameters
    ----------
    xml_path : Path
        Path to the source Informatica XML file.
    output_dir : Path
        Directory where script-layer outputs were written.
    ground_truth : str | None
        Optional path to a ground-truth manifest JSON.
    max_retries : int
        Maximum number of refinement iterations.
    logger : logging.Logger | None
        Logger instance (falls back to module-level get_logger).
    """
    if logger is None:
        logger = get_logger("cli.agentic")

    if not AGENTIC_AVAILABLE:
        logger.warning(
            "Agentic modules not available — install the agentic package or "
            "ensure scripts/agentic/ is on sys.path. Skipping post-run."
        )
        return

    logger.info("Starting agentic post-run validation...")

    initial_state = create_initial_state(
        xml_filepath=str(xml_path),
        output_directory=str(output_dir),
        ground_truth_filepath=str(ground_truth) if ground_truth else None,
        max_retries=max_retries,
    )

    graph = MultiAgentGraph().build_graph()
    config = {"configurable": {"thread_id": initial_state["session_id"]}}

    final_state = None
    for event in graph.stream(initial_state, config):
        node_name = list(event.keys())[0]
        logger.info(f"  agentic -> {node_name}")
        final_state = event[node_name]

    if final_state is None:
        logger.warning("Agentic graph produced no output.")
        return

    passed = final_state.get("lineage_validation_passed", False)
    retries = final_state.get("lineage_retry_count", 0)
    metrics = final_state.get("validation_metrics") or {}
    fixes = final_state.get("applied_fixes") or []

    accuracy = metrics.get("weighted_accuracy", 0)
    checks_passed = metrics.get("checks_passed", 0)
    total_checks = metrics.get("total_checks", 0)

    logger.info(
        f"Agentic post-run complete — "
        f"{'PASSED' if passed else 'NEEDS REVIEW'} | "
        f"accuracy={accuracy:.1f}% | "
        f"checks={checks_passed}/{total_checks} | "
        f"retries={retries} | fixes={len(fixes)}"
    )


if __name__ == "__main__":
    sys.exit(main())
