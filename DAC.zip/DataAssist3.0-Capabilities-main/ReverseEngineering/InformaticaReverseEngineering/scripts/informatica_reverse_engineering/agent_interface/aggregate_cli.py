"""
CLI interface for multi-XML lineage aggregation.

Provides command-line access to the InformaticaLineageAggregator
for forward engineering to medallion architecture.
"""

import argparse
import csv
import json
import os
import re
import sys
from pathlib import Path
from typing import Dict, List

from ..aggregation import InformaticaLineageAggregator
from ..extractors import ParameterExtractor
from ..exporters import AutoMedallionExporter
from ..utils.logging_config import get_logger, setup_logging
from werkzeug.utils import safe_join
from ..utils.path_utils import sanitize_path

# Agentic layer — soft dependency
try:
    from ..agentic.graph import MultiAgentGraph, create_initial_state
    AGENTIC_AVAILABLE = True
except ImportError:
    MultiAgentGraph = None
    create_initial_state = None
    AGENTIC_AVAILABLE = False


logger = get_logger("aggregate_cli")


def main():
    """Main entry point for aggregation CLI."""
    parser = argparse.ArgumentParser(
        description="Aggregate Informatica PowerCenter XMLs for medallion architecture forward engineering",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # Aggregate all XMLs in a directory
  python -m informatica_reverse_engineering.agent_interface.aggregate_cli ./xml_files/

  # Aggregate specific XML files
  python -m informatica_reverse_engineering.agent_interface.aggregate_cli file1.xml file2.xml file3.xml

  # Specify output directory
  python -m informatica_reverse_engineering.agent_interface.aggregate_cli ./xml_files/ -o ./output/

  # Generate conflicts report separately
  python -m informatica_reverse_engineering.agent_interface.aggregate_cli ./xml_files/ --conflicts-report
        """
    )

    parser.add_argument(
        "input",
        nargs="+",
        help="XML files or directory containing XML files"
    )

    parser.add_argument(
        "-o", "--output",
        default="./output",
        help="Output directory for generated files (default: ./output)"
    )

    parser.add_argument(
        "-p", "--pattern",
        default="*.xml",
        help="Glob pattern for XML files when input is a directory (default: *.xml)"
    )

    parser.add_argument(
        "--no-conflicts",
        action="store_true",
        help="Disable conflict detection"
    )

    parser.add_argument(
        "--conflicts-report",
        action="store_true",
        help="Generate separate conflicts report file"
    )

    parser.add_argument(
        "-v", "--verbose",
        action="store_true",
        help="Enable verbose output"
    )

    parser.add_argument(
        "--json-only",
        action="store_true",
        help="Only output JSON (no Excel or HTML)"
    )

    parser.add_argument(
        "--param-file",
        nargs="*",
        default=None,
        help="One or more Informatica .par/.prm parameter files to resolve $Param placeholders"
    )

    parser.add_argument(
        "--no-excel",
        action="store_true",
        help="Skip generating the enhanced Excel workbook"
    )

    parser.add_argument(
        "--bteq-dir",
        default=None,
        help="Directory containing BTEQ .sh/.ksh scripts for the BTEQ Details sheet"
    )

    parser.add_argument(
        "--agentic-post-run",
        action="store_true",
        help="Run agentic validation/refinement after aggregation"
    )
    parser.add_argument(
        "--max-agentic-retries",
        type=int,
        default=3,
        help="Max agentic refinement iterations (default: 3)"
    )
    parser.add_argument(
        "--build-dag",
        action="store_true",
        help="Build and export a full DAG (JSON + GraphML + interactive HTML) alongside normal output"
    )
    parser.add_argument(
        "--validate",
        action="store_true",
        help="Run accuracy validation after aggregation and produce aggregated_accuracy_report.xlsx"
    )

    args = parser.parse_args()

    # Setup logging
    log_level = "DEBUG" if args.verbose else "INFO"
    setup_logging(log_level)

    # Collect XML files
    xml_files = collect_xml_files(args.input, args.pattern)

    if not xml_files:
        logger.error("No XML files found")
        sys.exit(1)

    logger.info(f"Found {len(xml_files)} XML files to process")

    # Auto-detect param files from input paths if --param-file not given
    param_files = list(args.param_file) if args.param_file else []
    if not param_files:
        _param_exts = {".txt", ".prm", ".par"}
        for input_path in args.input:
            p = Path(input_path)
            if p.is_file() and p.suffix.lower() in _param_exts:
                param_files.append(str(p.absolute()))
            elif p.is_dir():
                for ext in _param_exts:
                    for pf in p.glob(f"*{ext}"):
                        param_files.append(str(pf.absolute()))
        if param_files:
            logger.info(f"Auto-detected {len(param_files)} parameter file(s) from input: {[Path(f).name for f in param_files]}")

    # Create output directory — auto-version if it already exists
    output_dir = sanitize_path(args.output)
    if output_dir.exists():
        base = output_dir
        version = 1
        while output_dir.exists():
            version += 1
            output_dir = Path(f"{base}_v{version}")
        logger.info(f"Output directory '{base}' exists, using '{output_dir}' instead")
    output_dir.mkdir(parents=True, exist_ok=True)

    # Run aggregation
    try:
        result = run_aggregation(
            xml_files=xml_files,
            output_dir=output_dir,
            detect_conflicts=not args.no_conflicts,
            generate_conflicts_report=args.conflicts_report,
            param_files=param_files or None,
        )

        # Print summary
        print_summary(result)

        logger.info(f"Output written to {output_dir}")

        # Generate enhanced Excel workbook (CSV + Expression/Union/Router/SQL sheets)
        if not args.no_excel:
            csv_path = result["output_files"]["aggregated_csv"]
            _fp = result.get("_file_prefix", "")
            excel_path = output_dir / f"{_fp}enhanced_output.xlsx"
            try:
                from ..exporters.enhanced_excel_exporter import generate_enhanced_excel
                bteq_dir = sanitize_path(args.bteq_dir) if args.bteq_dir else None
                generate_enhanced_excel(
                    csv_path=Path(csv_path),
                    input_xml_paths=[Path(f) for f in xml_files],
                    param_file_paths=[Path(f) for f in param_files] if param_files else [],
                    output_path=excel_path,
                    bteq_dir=bteq_dir,
                )
                result["output_files"]["enhanced_excel"] = str(excel_path)
                logger.info(f"Enhanced Excel: {excel_path}")
            except Exception as exc:
                logger.warning(f"Enhanced Excel generation failed: {exc}")

        # Build full DAG if requested (additive — does not affect existing output)
        if args.build_dag:
            _build_and_export_dag(xml_files, output_dir, param_files=param_files or None)

        # Agentic post-run: validate each XML against the aggregated output
        if args.agentic_post_run:
            _run_agentic_on_xmls(xml_files, output_dir, args.max_agentic_retries)

        # Accuracy validation: compare output against XML ground truth
        if args.validate:
            logger.info("Running accuracy validation...")
            try:
                from ..agents.accuracy_validator import AccuracyValidator

                # Determine XML input directory from the first XML file
                xml_input_dir = str(Path(xml_files[0]).parent)

                validator = AccuracyValidator()
                agg_report = validator.validate_aggregated(
                    xml_input_dir, str(output_dir),
                    param_file=param_files[0] if param_files else None,
                )

                # Write report
                report_path = output_dir / "aggregated_accuracy_report.xlsx"
                validator.write_aggregated_report(agg_report, str(report_path))

                logger.info(f"  Overall Score: {agg_report.get('overall_score', 0)} ({agg_report.get('letter_grade', '?')})")
                logger.info(f"  XMLs validated: {agg_report.get('xml_count', 0)}")
                logger.info(f"  Total field lineages: {agg_report.get('total_field_lineages', 0)}")
                logger.info(f"  Report: {report_path}")

                total_issues = sum(len(r.get("issues", [])) for r in agg_report.get("per_xml_reports", []))
                logger.info(f"  Total issues: {total_issues}")

                result["output_files"]["accuracy_report"] = str(report_path)
                result["accuracy"] = {
                    "overall_score": agg_report.get("overall_score", 0),
                    "letter_grade": agg_report.get("letter_grade", ""),
                    "xml_count": agg_report.get("xml_count", 0),
                    "total_issues": total_issues,
                }
            except Exception as exc:
                logger.warning(f"Accuracy validation failed: {exc}")
                if args.verbose:
                    import traceback
                    traceback.print_exc()

        return 0

    except Exception as e:
        logger.error(f"Aggregation failed: {e}")
        if args.verbose:
            import traceback
            traceback.print_exc()
        sys.exit(1)


def collect_xml_files(inputs: List[str], pattern: str) -> List[str]:
    """Collect XML files from inputs (files or directories)."""
    xml_files = []

    for input_path in inputs:
        path = sanitize_path(input_path)

        if path.is_file():
            if path.suffix.lower() == ".xml":
                xml_files.append(str(path.absolute()))
            else:
                logger.warning(f"Skipping non-XML file: {path}")

        elif path.is_dir():
            matches = list(path.glob(pattern))
            xml_files.extend([str(f.absolute()) for f in matches])

        else:
            logger.warning(f"Path not found: {path}")

    return sorted(set(xml_files))


def run_aggregation(
    xml_files: List[str],
    output_dir: Path,
    detect_conflicts: bool = True,
    generate_conflicts_report: bool = False,
    param_files: List[str] = None,
) -> dict:
    """
    Run the aggregation pipeline.

    Returns summary statistics.
    """
    from ..utils.parameter_file_loader import ParameterFileLoader

    # Step 0: Load external parameter files FIRST so they are available during extraction
    param_loader = ParameterFileLoader()
    if param_files:
        logger.info(f"Step 0: Loading {len(param_files)} parameter file(s)...")
        for pf in param_files:
            pf_path = sanitize_path(pf)
            # Auto-detect consolidated format (contains ===== headers)
            is_consolidated = False
            if pf_path.exists():
                try:
                    with open(pf_path, "r", encoding="utf-8", errors="replace") as _fp:
                        for _line in _fp:
                            stripped = _line.strip()
                            if stripped.startswith("=====") and stripped.endswith("====="):
                                is_consolidated = True
                                break
                            # Only check the first 5 non-empty lines
                            if stripped:
                                break
                except Exception:
                    pass

            if is_consolidated:
                # Extract workflow names from XML paths and load matching sections
                for xf in xml_files:
                    wf_name = Path(xf).stem  # e.g. wf_SHAWILN_..._LOAD
                    loaded = param_loader.load_consolidated(pf_path, wf_name)
                    if loaded:
                        logger.info(f"  Loaded {loaded} params for workflow '{wf_name}' from consolidated file")
            else:
                param_loader.load(pf_path)

        if param_loader.parameters:
            logger.info(f"  Total external parameters loaded: {len(param_loader.parameters)}")

    # Initialize components — pass param_loader so Pre/Post SQL gets resolved during extraction
    aggregator = InformaticaLineageAggregator(
        detect_conflicts=detect_conflicts,
        parameter_loader=param_loader if param_loader.parameters else None,
    )
    param_extractor = ParameterExtractor()
    exporter = AutoMedallionExporter()

    # Step 1: Aggregate lineage from all XMLs
    logger.info("Step 1: Aggregating lineage from XML files...")
    unified_graph = aggregator.aggregate_xmls(xml_files)

    # Step 2: Extract parameters
    logger.info("Step 2: Extracting parameters...")
    param_catalog = param_extractor.extract_from_documents(aggregator.documents)

    # Step 2b: Merge loaded params into catalog
    if param_loader.parameters:
        param_loader.merge_into_catalog(param_catalog)
        logger.info(f"  Merged {len(param_loader.parameters)} external parameters into catalog")

    # Derive a file prefix from the input XML name(s) so output files are
    # distinguishable (e.g. wf_SHAW_NAME_ILN_SRC_STG_LOAD_aggregated_lineage.json).
    if len(xml_files) == 1:
        _file_prefix = Path(xml_files[0]).stem + "_"
    else:
        _file_prefix = ""

    # Step 3: Export to AutoMedallion format
    logger.info("Step 3: Exporting to AutoMedallion format...")
    output_json_path = safe_join(output_dir, f"{_file_prefix}aggregated_lineage.json")

    automedallion_output = exporter.export(
        unified_graph=unified_graph,
        documents=aggregator.documents,
        lineage_results=aggregator.lineage_results,
        parameter_catalog=param_catalog,
        output_path=str(output_json_path),
    )

    # Step 4: Generate conflicts report if requested
    if generate_conflicts_report and unified_graph.conflicts:
        conflicts_path = output_dir / "table_conflicts_report.json"
        exporter.export_conflicts_report(unified_graph, str(conflicts_path))

    # Step 5: Export unified graph details
    graph_path = safe_join(str(output_dir), f"{_file_prefix}unified_lineage_graph.json")
    with open(graph_path, "w", encoding="utf-8") as f:
        json.dump(unified_graph.to_dict(), f, indent=2, default=str)

    # Step 6: Export parameter catalog
    params_path = safe_join(str(output_dir), f"{_file_prefix}parameter_catalog.json")
    with open(params_path, "w", encoding="utf-8") as f:
        json.dump(param_catalog.to_dict(), f, indent=2, default=str)

    # Step 7: Export aggregated lineage as CSV
    logger.info("Step 7: Exporting aggregated lineage as CSV...")
    # Build $$variable annotation map from VALUEPAIR chains + SETVARIABLE
    var_annotations = _build_variable_annotations(aggregator.documents)

    # Resolve $$variables and parameters in the JSON field_lineage so that
    # resolved_sql_override is populated in the JSON output as well.
    _patch_resolved_sql_in_json(output_json_path, param_loader, var_annotations)

    csv_path = _export_aggregated_csv(output_json_path, output_dir, param_loader, var_annotations=var_annotations, file_prefix=_file_prefix)

    return {
        "xml_files_processed": len(xml_files),
        "tables_found": unified_graph.table_count,
        "edges_found": unified_graph.edge_count,
        "cross_mapping_links": len(unified_graph.cross_mapping_links),
        "conflicts_found": len(unified_graph.conflicts),
        "parameters_found": param_catalog.total_count,
        "has_conflicts_requiring_review": unified_graph.has_conflicts,
        "output_files": {
            "automedallion_input": str(output_json_path),
            "aggregated_csv": str(csv_path),
            "unified_graph": str(graph_path),
            "parameters": str(params_path),
        },
        "_file_prefix": _file_prefix,
    }


def print_summary(result: dict) -> None:
    """Print aggregation summary."""
    print("\n" + "=" * 60)
    print("INFORMATICA LINEAGE AGGREGATION SUMMARY")
    print("=" * 60)
    print(f"  XML Files Processed:     {result['xml_files_processed']}")
    print(f"  Tables Found:            {result['tables_found']}")
    print(f"  Edges Found:             {result['edges_found']}")
    print(f"  Cross-Mapping Links:     {result['cross_mapping_links']}")
    print(f"  Parameters Found:        {result['parameters_found']}")
    print(f"  Conflicts Found:         {result['conflicts_found']}")

    if result['has_conflicts_requiring_review']:
        print("\n  WARNING: Some conflicts require manual review!")
        print("  Please check the conflicts report.")

    print("\n  Output Files:")
    for name, path in result['output_files'].items():
        print(f"    - {name}: {path}")

    print("=" * 60 + "\n")


def _format_union_details(details) -> str:
    """Format union_details dict into a human-readable string."""
    if not isinstance(details, dict) or not details:
        return ""
    name = details.get("union_name", "Union")
    count = details.get("group_count", 0)
    groups = details.get("groups", [])
    group_sources = details.get("group_sources", {})
    if not groups:
        return ""
    if group_sources:
        # Show each group with its source feeds
        group_parts = []
        for g in groups:
            srcs = group_sources.get(g, [])
            if srcs:
                group_parts.append(f"{g} <- {', '.join(srcs)}")
            else:
                group_parts.append(g)
        return f"{name}: {count} groups | {' | '.join(group_parts)}"
    return f"{name}: {count} groups ({', '.join(groups)})"


def _build_variable_annotations(documents) -> Dict[str, str]:
    """Build annotation map for unresolved $$variables from VALUEPAIR chains and SETVARIABLE.

    Traces chains like:
      $$FROM_CLAUSE <- $$DEDUP_SQL_IN <- $$DEDUP_SQL <- SETVARIABLE($$DEDUP_SQL, DED_DUP_SQL)
    And produces:
      '$$FROM_CLAUSE' -> '$$FROM_CLAUSE (= runtime value from DEDUP_CTL_TBL.DED_DUP_SQL via $$DEDUP_SQL)'

    Returns:
        Dict mapping $$variable_name -> annotated string
    """
    # Collect VALUEPAIR assignments: $$VAR -> $$OTHER_VAR
    vp_chain: Dict[str, str] = {}  # $$name -> $$value (both with $$ prefix)
    # Collect SETVARIABLE info: $$VAR -> (source_field, source_table_hint)
    setvar_info: Dict[str, tuple] = {}

    _docs = documents.values() if isinstance(documents, dict) else documents
    for doc in _docs:
        # Scan session VALUEPAIR assignments
        for session in doc.sessions:
            for comp in getattr(session, 'components', []):
                for vp in getattr(comp, 'value_pairs', []):
                    name = vp.get('name', '')
                    value = vp.get('value', '')
                    if name.startswith('$$') and value.startswith('$$'):
                        vp_chain[name.lower()] = value.lower()

        # Scan mappings for SETVARIABLE expressions
        for mapping in doc.mappings:
            for trans in mapping.transformations:
                for fld in trans.fields:
                    if fld.expression and 'SETVARIABLE' in fld.expression.upper():
                        m = re.match(
                            r'SETVARIABLE\s*\(\s*(\$\$\w+)\s*,\s*(\w+)\s*\)',
                            fld.expression.strip(), re.IGNORECASE
                        )
                        if m:
                            var_name = m.group(1).lower()
                            source_field = m.group(2)
                            # Try to find the source table for this field
                            source_table = ""
                            for src in mapping.sources:
                                for sf in src.fields:
                                    if sf.name.lower() == source_field.lower():
                                        source_table = src.name
                                        break
                                if source_table:
                                    break
                            setvar_info[var_name] = (source_field, source_table)

    # Build annotations by tracing chains
    annotations: Dict[str, str] = {}
    for var_name in vp_chain:
        if not var_name.startswith('$$'):
            continue
        # Trace the chain
        chain = [var_name]
        current = var_name
        for _ in range(10):  # cap depth
            nxt = vp_chain.get(current)
            if not nxt or nxt in chain:
                break
            chain.append(nxt)
            current = nxt

        # Check if any variable in the chain has a SETVARIABLE entry.
        # The SETVARIABLE may be on an intermediate variable (e.g.,
        # $$FROM_CLAUSE -> $$DEDUP_SQL_IN -> $$DEDUP_SQL -> $$WF_INIT
        # where SETVARIABLE is on $$DEDUP_SQL, not the terminal).
        sv = None
        sv_var = None
        for _cv in reversed(chain):
            sv = setvar_info.get(_cv)
            if sv:
                sv_var = _cv
                break
        if sv:
            src_field, src_table = sv
            if src_table:
                desc = f"runtime value from {src_table}.{src_field}"
            else:
                desc = f"runtime value from {src_field}"
            if sv_var and sv_var != var_name:
                desc += f" via {sv_var.lstrip('$')}"
            # Store annotation for the original variable
            annotations[var_name] = f"{var_name} (= {desc})"

    return annotations


def _patch_resolved_sql_in_json(json_path, param_loader, var_annotations):
    """Resolve parameters and $$variable annotations in the JSON field_lineage.

    Resolves $Param_* placeholders and $$variable annotations across ALL
    relevant fields in field_lineage entries so the JSON is self-contained
    for downstream consumers (forward engineering team).

    Fields resolved:
    - sql_override -> resolved_sql_override
    - ultimate_sources[].table
    - source_tables[]
    - transformation_chain
    - transformation_explanation
    - sql_logic
    - lookup_condition
    - lookup_sql_override
    - lookup_input_lineage
    """
    import json as _json
    safe_json_path = os.path.realpath(json_path)
    if ".." in str(json_path):
        raise ValueError(f"Path traversal detected: {json_path}")
    with open(safe_json_path, "r", encoding="utf-8") as f:
        data = _json.load(f)

    field_lineage = data.get("field_lineage", [])
    if not field_lineage:
        return

    has_params = param_loader and param_loader.parameters

    def _resolve(text, mapping_name="", session_name=""):
        if not text or not has_params:
            return text
        if session_name and hasattr(param_loader, "resolve_for_session"):
            return param_loader.resolve_for_session(text, session_name)
        if mapping_name and hasattr(param_loader, "resolve_for_mapping"):
            return param_loader.resolve_for_mapping(text, mapping_name)
        return param_loader.resolve_placeholders(text)

    def _annotate_vars(text):
        if not var_annotations or not text or "$$" not in text:
            return text
        result = text
        for var_key, var_desc in var_annotations.items():
            result = re.sub(
                re.escape(var_key), var_desc, result,
                flags=re.IGNORECASE,
            )
        return result

    changed = False
    for entry in field_lineage:
        mapping_name = entry.get("mapping_name", "")
        session_name = entry.get("session_name", "")

        # --- sql_override -> resolved_sql_override ---
        sql = entry.get("sql_override", "")
        if sql:
            resolved = _annotate_vars(_resolve(sql, mapping_name, session_name))
            if resolved != sql:
                entry["resolved_sql_override"] = resolved
                changed = True

        # --- ultimate_sources[].table ---
        for src in entry.get("ultimate_sources", []):
            tbl = src.get("table", "")
            if tbl:
                resolved_tbl = _resolve(tbl, mapping_name, session_name)
                if resolved_tbl != tbl:
                    src["table"] = resolved_tbl
                    tbl = resolved_tbl
                    changed = True
                # Strip sc_ prefix from unresolved shortcut instance names
                # and try to qualify with schema from table_registry or
                # the aggregated lineage metadata (source instances carry
                # DBDNAME which maps to a database parameter).
                bare_tbl = tbl.rsplit(".", 1)[-1] if "." in tbl else tbl
                if bare_tbl.startswith("sc_") and "." not in tbl:
                    stripped = bare_tbl[3:]
                    # Look up in table_registry for the actual name
                    registry = data.get("table_registry", {})
                    if stripped in registry or stripped.upper() in registry or stripped.lower() in registry:
                        # Try to find schema prefix from other entries that
                        # reference the same table with a schema prefix.
                        # E.g., if another field_lineage entry has
                        # "P_APPL_EXTRCT_01_V1.CLAS_KEY_CONTROL_STRIKE_VW_FR2052A"
                        # and this one has "sc_CLAS_KEY_CONTROL_VW_FR2052A",
                        # try to find a sibling with the same schema.
                        schema_prefix = ""
                        for other_entry in field_lineage:
                            for other_src in other_entry.get("ultimate_sources", []):
                                other_tbl = other_src.get("table", "")
                                if "." in other_tbl and not other_tbl.startswith("sc_"):
                                    # Check if the schema part is a known database
                                    other_schema = other_tbl.rsplit(".", 1)[0]
                                    other_bare = other_tbl.rsplit(".", 1)[-1]
                                    # Use this schema if it's from the same mapping
                                    if other_schema and other_bare != stripped:
                                        schema_prefix = other_schema
                                        break
                            if schema_prefix:
                                break

                        if schema_prefix:
                            src["table"] = f"{schema_prefix}.{stripped}"
                        else:
                            src["table"] = stripped
                        changed = True

                # Fill in missing datatype from table_registry for any source
                # that has an empty datatype (regardless of sc_ prefix).
                if not src.get("datatype"):
                    _src_tbl = src.get("table", "")
                    _bare_src = _src_tbl.rsplit(".", 1)[-1] if "." in _src_tbl else _src_tbl
                    src_field = src.get("field", "")
                    bare_field = src_field.rsplit("/", 1)[-1] if "/" in src_field else src_field
                    registry = data.get("table_registry", {})
                    reg_entry = registry.get(_bare_src) or registry.get(_bare_src.upper()) or registry.get(_bare_src.lower())
                    if reg_entry and isinstance(reg_entry, dict):
                        cols = reg_entry.get("columns", {})
                        # columns can be a dict {col_name: {datatype, precision, scale}}
                        # or a list [{name, datatype, ...}]
                        if isinstance(cols, dict):
                            col_info = cols.get(bare_field) or cols.get(bare_field.upper()) or cols.get(bare_field.lower())
                            if col_info and isinstance(col_info, dict):
                                dt = col_info.get("datatype", "")
                                prec = col_info.get("precision", "")
                                scale = col_info.get("scale", "")
                                if dt:
                                    if prec and scale:
                                        src["datatype"] = f"{dt}({prec},{scale})"
                                    elif prec:
                                        src["datatype"] = f"{dt}({prec})"
                                    else:
                                        src["datatype"] = dt
                                    changed = True
                        elif isinstance(cols, list):
                            for col in cols:
                                col_name = col.get("name", "") if isinstance(col, dict) else ""
                                if col_name.lower() == bare_field.lower():
                                    dt = col.get("datatype", "")
                                    prec = col.get("precision", "")
                                    scale = col.get("scale", "")
                                    if dt:
                                        if prec and scale:
                                            src["datatype"] = f"{dt}({prec},{scale})"
                                        elif prec:
                                            src["datatype"] = f"{dt}({prec})"
                                        else:
                                            src["datatype"] = dt
                                        changed = True
                                    break

        # --- source_tables[] ---
        src_tables = entry.get("source_tables", [])
        if isinstance(src_tables, list):
            for i, st in enumerate(src_tables):
                resolved_st = _resolve(st, mapping_name, session_name)
                if resolved_st != st:
                    src_tables[i] = resolved_st
                    changed = True

        # --- lookup_tables[] ---
        lkp_tables = entry.get("lookup_tables", [])
        if isinstance(lkp_tables, list):
            for i, lt in enumerate(lkp_tables):
                resolved_lt = _resolve(str(lt), mapping_name, session_name)
                if resolved_lt != str(lt):
                    lkp_tables[i] = resolved_lt
                    changed = True
        elif isinstance(lkp_tables, str) and lkp_tables:
            resolved_lt = _resolve(lkp_tables, mapping_name, session_name)
            if resolved_lt != lkp_tables:
                entry["lookup_tables"] = resolved_lt
                changed = True

        # --- string fields ---
        for field_key in (
            "transformation_chain",
            "transformation_explanation",
            "sql_logic",
            "lookup_condition",
            "lookup_sql_override",
            "lookup_input_lineage",
        ):
            val = entry.get(field_key, "")
            if val:
                resolved_val = _annotate_vars(_resolve(val, mapping_name, session_name))
                if resolved_val != val:
                    entry[field_key] = resolved_val
                    changed = True

    if changed:
        with open(safe_json_path, "w", encoding="utf-8") as f:
            _json.dump(data, f, indent=2, default=str)


def _flatten_custom_inputs(inputs) -> str:
    """Flatten custom_transformation_inputs list to a semicolon-separated string."""
    if not isinstance(inputs, list) or not inputs:
        return ""
    parts = []
    for ci in inputs:
        if isinstance(ci, dict):
            inp = ci.get("input_field", "")
            frm_inst = ci.get("from_instance", "")
            frm_fld = ci.get("from_field", "")
            grp = ci.get("union_group", "")
            entry = f"{inp} <- {frm_inst}.{frm_fld}"
            if grp:
                entry += f" [{grp}]"
            parts.append(entry)
    return "; ".join(parts)


def _translate_json_entry_to_row(entry: dict) -> dict:
    """Translate a JSON field_lineage entry to the canonical CSV row format.

    The JSON uses ``to_dict()`` keys (snake_case, raw Python types) while the
    per-XML CSV produced by ``EndToEndFieldLineage.to_row()`` uses Title Case
    column names, ``Yes``/``No`` booleans, and flattened source strings.
    """
    # Parse ultimate_sources list into separate table/field/datatype columns
    ultimate_sources = entry.get("ultimate_sources", [])
    source_tables = []
    source_fields = []
    source_datatypes = []
    if isinstance(ultimate_sources, list):
        for src in ultimate_sources:
            if isinstance(src, dict):
                table = src.get("table", "")
                field_name = src.get("field", "")
                datatype = src.get("datatype", "")
                if table:
                    source_tables.append(table)
                if field_name:
                    source_fields.append(
                        f"{table}.{field_name}" if table else field_name
                    )
                if datatype:
                    source_datatypes.append(datatype)

    # Flatten intermediate_steps into an End-to-End Dataflow description
    # Edges come from backward trace (target->source), so we reverse and
    # deduplicate to build a clean source->target chain.
    intermediate_steps = entry.get("intermediate_steps", [])
    dataflow = entry.get("end_to_end_dataflow", "")
    if not dataflow and isinstance(intermediate_steps, list) and intermediate_steps:
        # Build ordered node chain from edges (reverse since trace is backward)
        node_chain = []
        seen = set()
        for step in reversed(intermediate_steps):
            if isinstance(step, dict):
                src = f"{step.get('source_instance', '')}.{step.get('source_field', '')}"
                tgt = f"{step.get('target_instance', '')}.{step.get('target_field', '')}"
                if src not in seen:
                    node_chain.append(src)
                    seen.add(src)
                if tgt not in seen:
                    node_chain.append(tgt)
                    seen.add(tgt)
        dataflow = " -> ".join(node_chain)

    # Flatten lookup_tables list
    lookup_tables = entry.get("lookup_tables", [])
    if isinstance(lookup_tables, list):
        lookups_str = "; ".join(str(lt) for lt in lookup_tables)
    else:
        lookups_str = str(lookup_tables) if lookup_tables else ""

    def _bool_to_yesno(val) -> str:
        if isinstance(val, bool):
            return "Yes" if val else "No"
        if isinstance(val, str):
            return "Yes" if val.lower() in ("true", "yes") else "No"
        return "No"

    # Fallback enrichment for sparse descriptions
    description = entry.get("transformation_explanation", "")
    _sparse_patterns = {"direct field mapping", "direct mapping", "no transformation"}
    is_sparse = (
        not description
        or description.strip().lower() in _sparse_patterns
        or all(tok in description.lower() for tok in ("direct", "mapping"))
    )
    if is_sparse:
        enrichment_parts = []
        sql_ov = entry.get("sql_override", "")
        if sql_ov:
            snippet = sql_ov.strip().replace("\n", " ")[:120]
            enrichment_parts.append(f"Source data read via SQL: {snippet}")
        if isinstance(intermediate_steps, list) and intermediate_steps:
            names = []
            for s in intermediate_steps:
                if isinstance(s, dict):
                    n = s.get("source_instance", "") or s.get("target_instance", "")
                    if n and n not in names:
                        names.append(n)
            if names:
                enrichment_parts.append(f"Data path: {' -> '.join(names)}")
        lkp = entry.get("lookup_tables", [])
        if isinstance(lkp, list) and lkp:
            enrichment_parts.append(f"Enriched via lookup(s): {', '.join(str(l) for l in lkp)}")
        if enrichment_parts:
            description = ". ".join(enrichment_parts)
        elif not description:
            description = "Direct field mapping - value copied without modification"

    row = {
        "Target Table": entry.get("target_table", ""),
        "Target Field": entry.get("target_field", ""),
        "Target Datatype": entry.get("target_datatype", ""),
        "Ultimate Source Table": ", ".join(sorted(set(source_tables))) if source_tables else "",
        "Ultimate Source Field": "; ".join(source_fields) if source_fields else "",
        "Source Datatype": "; ".join(source_datatypes) if source_datatypes else "",
        "Source Qualifier": entry.get("source_qualifier_name", ""),
        "Transformation Logic": entry.get("transformation_chain", ""),
        "SQL Logic": entry.get("sql_logic", ""),
        "Transformation Description": description,
        "End-to-End Dataflow": dataflow,
        "Hop Count": entry.get("hop_count", 0),
        "Lookup Tables": lookups_str,
        "Lookup Name": entry.get("lookup_name", ""),
        "Lookup Condition": entry.get("lookup_condition", ""),
        "Lookup SQL Override": entry.get("lookup_sql_override", ""),
        "Has Transformation": _bool_to_yesno(entry.get("has_transformation", False)),
        "Aggregation Applied": _bool_to_yesno(entry.get("aggregation_applied", False)),
        "Filter Applied": _bool_to_yesno(entry.get("filter_applied", False)),
        "Filter Condition": entry.get("filter_condition", ""),
        "Router Applied": _bool_to_yesno(entry.get("router_applied", False)),
        "Router Condition": entry.get("router_condition", ""),
        "Joiner Condition": entry.get("joiner_condition", ""),
        "Joiner Type": entry.get("joiner_type", ""),
        "Update Strategy": entry.get("update_strategy", ""),
        "SQL Override": entry.get("sql_override", ""),
        "Resolved SQL Override": entry.get("resolved_sql_override", ""),
        # Custom transformation inputs
        "Custom Transformation Inputs": _flatten_custom_inputs(entry.get("custom_transformation_inputs", [])),
        # Union details
        "Union Details": _format_union_details(entry.get("union_details", {})),
        # Lookup input lineage
        "Lookup Input Lineage": entry.get("lookup_input_lineage", ""),
        # Aggregation-specific extras
        "Source Tables": ", ".join(entry.get("source_tables", [])) if isinstance(entry.get("source_tables"), list) else "",
        "Source XML": entry.get("source_xml", ""),
        "Mapping Name": entry.get("mapping_name", ""),
    }
    return row


# Canonical column order for the aggregated CSV
_CSV_COLUMNS = [
    "Target Table", "Target Field", "Target Datatype",
    "Ultimate Source Table", "Ultimate Source Field", "Source Datatype",
    "Source Qualifier",
    "Transformation Logic", "SQL Logic", "Transformation Description", "End-to-End Dataflow",
    "Hop Count", "Lookup Tables", "Lookup Name", "Lookup Condition", "Lookup SQL Override",
    "Lookup Input Lineage",
    "Has Transformation", "Aggregation Applied", "Filter Applied", "Filter Condition",
    "Router Applied", "Router Condition",
    "Joiner Condition", "Joiner Type", "Update Strategy",
    "SQL Override", "Resolved SQL Override",
    "Custom Transformation Inputs",
    "Union Details",
    "Source Tables", "Source XML", "Mapping Name",
]


def _export_aggregated_csv(json_path: Path, output_dir: Path, param_loader=None, var_annotations=None, file_prefix: str = "") -> Path:
    """Convert the aggregated lineage JSON to a CSV file.

    Translates each ``field_lineage`` JSON entry into the canonical per-XML
    CSV column format (Title Case headers, Yes/No booleans, flattened sources)
    so the agentic trigger_node can load it without column-name mismatches.

    When a ``param_loader`` is provided, $Param placeholders in SQL Override
    and Transformation Logic columns are resolved and the resolved SQL is
    written to the "Resolved SQL Override" column.

    Returns the path to the generated CSV.
    """
    safe_json_path = os.path.realpath(json_path)
    if ".." in str(json_path):
        raise ValueError(f"Path traversal detected: {json_path}")
    with open(safe_json_path, "r", encoding="utf-8") as f:
        data = json.load(f)

    field_lineage = data.get("field_lineage", [])

    csv_path = safe_join(str(output_dir), f"{file_prefix}aggregated_lineage.csv")

    if not field_lineage:
        logger.warning("No field_lineage entries found — CSV will be empty")
        csv_path.write_text("", encoding="utf-8")
        return csv_path

    with open(csv_path, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=_CSV_COLUMNS, extrasaction="ignore", quoting=csv.QUOTE_ALL)
        writer.writeheader()

        for entry in field_lineage:
            row = _translate_json_entry_to_row(entry)

            # Resolve parameter placeholders if a loader was provided
            # Use per-mapping resolution so BUILD and TGT_STG_LOAD get
            # their own session-specific param values.
            if param_loader and param_loader.parameters:
                mapping_name = row.get("Mapping Name", "")
                session_name = entry.get("session_name", "")

                def _resolve(txt):
                    if session_name and hasattr(param_loader, 'resolve_for_session'):
                        return param_loader.resolve_for_session(txt, session_name)
                    if mapping_name and hasattr(param_loader, 'resolve_for_mapping'):
                        return param_loader.resolve_for_mapping(txt, mapping_name)
                    return param_loader.resolve_placeholders(txt)

                sql_override = row.get("SQL Override", "")
                if sql_override:
                    resolved = _resolve(sql_override)
                    if resolved != sql_override:
                        row["Resolved SQL Override"] = resolved
                        row["SQL Override"] = resolved
                    # Annotate remaining $$variables with VALUEPAIR chain info
                    if var_annotations and '$$' in resolved:
                        annotated = resolved
                        for var_key, var_desc in var_annotations.items():
                            # Replace $$VAR_NAME with the annotated version
                            annotated = re.sub(
                                re.escape(var_key), var_desc, annotated,
                                flags=re.IGNORECASE
                            )
                        if annotated != resolved:
                            row["Resolved SQL Override"] = annotated

                logic = row.get("Transformation Logic", "")
                if logic:
                    row["Transformation Logic"] = _resolve(logic)

                desc = row.get("Transformation Description", "")
                if desc:
                    row["Transformation Description"] = _resolve(desc)

                sql_logic = row.get("SQL Logic", "")
                if sql_logic:
                    row["SQL Logic"] = _resolve(sql_logic)

                lookup_tbls = row.get("Lookup Tables", "")
                if lookup_tbls:
                    row["Lookup Tables"] = _resolve(lookup_tbls)

                lookup_cond = row.get("Lookup Condition", "")
                if lookup_cond:
                    row["Lookup Condition"] = _resolve(lookup_cond)

                ult_src_tbl = row.get("Ultimate Source Table", "")
                if ult_src_tbl:
                    row["Ultimate Source Table"] = _resolve(ult_src_tbl)

                ult_src_fld = row.get("Ultimate Source Field", "")
                if ult_src_fld:
                    row["Ultimate Source Field"] = _resolve(ult_src_fld)

                lkp_sql_ovr = row.get("Lookup SQL Override", "")
                if lkp_sql_ovr:
                    row["Lookup SQL Override"] = _resolve(lkp_sql_ovr)

                src_tables = row.get("Source Tables", "")
                if src_tables:
                    row["Source Tables"] = _resolve(src_tables)

                lkp_input_lin = row.get("Lookup Input Lineage", "")
                if lkp_input_lin:
                    row["Lookup Input Lineage"] = _resolve(lkp_input_lin)

            from ..utils.path_utils import sanitize_csv_row
            writer.writerow(sanitize_csv_row(row))

    logger.info(f"Created: {csv_path} ({len(field_lineage)} rows)")
    return csv_path


def _build_combined_ground_truth(xml_files, extract_fn) -> dict:
    """Merge per-XML ground truths into a single combined ground truth.

    Args:
        xml_files: List of XML file paths.
        extract_fn: Callable that takes an XML path and returns a ground-truth dict.

    Returns:
        Merged ground truth dictionary usable by the lineage validator.
    """
    combined = None

    for xml_file in xml_files:
        try:
            gt = extract_fn(xml_file)
        except Exception as exc:
            logger.warning(f"  Skipping ground truth for {Path(xml_file).name}: {exc}")
            continue

        if combined is None:
            # Deep-copy the first result as the base
            combined = json.loads(json.dumps(gt, default=str))
            continue

        # --- Lists: union (deduplicate) ---
        for key in ("sources", "targets", "mappings"):
            existing = set(combined.get(key, []))
            for item in gt.get(key, []):
                if item not in existing:
                    combined[key].append(item)
                    existing.add(item)

        # --- Field dicts: merge with union of field lists ---
        for key in ("source_fields", "target_fields"):
            for name, fields in gt.get(key, {}).items():
                if name not in combined[key]:
                    combined[key][name] = list(fields)
                else:
                    existing = set(combined[key][name])
                    for f in fields:
                        if f not in existing:
                            combined[key][name].append(f)
                            existing.add(f)

        # --- Transformation counts: sum by type ---
        for ttype, count in gt.get("transformations", {}).items():
            combined.setdefault("transformations", {})[ttype] = (
                combined.get("transformations", {}).get(ttype, 0) + count
            )

        # --- Transformation detail lists: concatenate ---
        for key in (
            "expression_transformations", "lookup_transformations",
            "joiner_transformations", "filter_transformations",
            "aggregator_transformations", "router_transformations",
            "union_transformations",
        ):
            combined.setdefault(key, []).extend(gt.get(key, []))

        # --- Connectors: concatenate ---
        combined.setdefault("connectors", []).extend(gt.get("connectors", []))

        # --- target_field_connectors: merge ---
        for tgt_field, conns in gt.get("target_field_connectors", {}).items():
            combined.setdefault("target_field_connectors", {}).setdefault(tgt_field, []).extend(conns)

        # --- Expressions: merge dicts ---
        for expr_key, expr_val in gt.get("expressions", {}).items():
            combined.setdefault("expressions", {})[expr_key] = expr_val

        # --- Pattern flags: OR together ---
        for flag in (
            "has_lookup", "has_aggregation", "has_joiner",
            "has_filter", "has_union", "has_router", "has_sequence",
        ):
            if gt.get(flag):
                combined[flag] = True

    if combined is None:
        return {}

    # --- Recompute scalar counts from merged lists ---
    combined["source_count"] = len(combined.get("sources", []))
    combined["target_count"] = len(combined.get("targets", []))
    combined["mapping_count"] = len(combined.get("mappings", []))
    combined["transformation_count"] = sum(combined.get("transformations", {}).values())
    combined["connector_count"] = len(combined.get("connectors", []))
    combined["expression_count"] = len(combined.get("expressions", {}))

    return combined


def _run_agentic_on_xmls(xml_files, output_dir, max_retries=3):
    """Run agentic validation on the aggregated output using combined ground truth.

    Instead of validating per-XML (which mismatches single-XML ground truth
    against all-XML CSV data), this builds a combined ground truth from every
    XML and runs a single validation pass against the full aggregated CSV.
    """
    if not AGENTIC_AVAILABLE:
        logger.warning(
            "Agentic modules not available — install the agentic package or "
            "ensure scripts/agentic/ is on sys.path. Skipping post-run."
        )
        return

    # Import extract_ground_truth_from_xml from the agentic utils
    try:
        from ..agentic.utils import extract_ground_truth_from_xml
    except ImportError:
        logger.error("Cannot import extract_ground_truth_from_xml — skipping post-run.")
        return

    logger.info("Starting agentic post-run validation on aggregated output...")

    # Step 1: Build combined ground truth from all XMLs
    logger.info(f"  Building combined ground truth from {len(xml_files)} XML(s)...")
    combined_gt = _build_combined_ground_truth(xml_files, extract_ground_truth_from_xml)

    if not combined_gt:
        logger.error("  Failed to build combined ground truth — skipping post-run.")
        return

    logger.info(
        f"  Combined ground truth: "
        f"{combined_gt.get('source_count', 0)} sources, "
        f"{combined_gt.get('target_count', 0)} targets, "
        f"{combined_gt.get('mapping_count', 0)} mappings"
    )

    # Step 2: Save combined ground truth for reproducibility
    gt_path = safe_join(str(output_dir), "combined_ground_truth.json")
    with open(gt_path, "w", encoding="utf-8") as f:
        json.dump(combined_gt, f, indent=2, default=str)
    logger.info(f"  Saved combined ground truth to {gt_path}")

    # Step 3: Create initial state with ground_truth_filepath pointing to combined file
    # Use the first XML as the nominal xml_filepath (trigger_node needs it for session naming)
    initial_state = create_initial_state(
        xml_filepath=xml_files[0],
        output_directory=str(output_dir),
        ground_truth_filepath=str(gt_path),
        max_retries=max_retries,
    )

    # Step 4: Run agentic graph once — trigger_node loads the aggregated CSV
    # (now with correct column names), validator uses pre-built combined ground truth
    try:
        graph = MultiAgentGraph().build_graph()
        config = {"configurable": {"thread_id": initial_state["session_id"]}}

        final_state = None
        for event in graph.stream(initial_state, config):
            node_name = list(event.keys())[0]
            logger.info(f"    agentic -> {node_name}")
            final_state = event[node_name]

        if final_state and final_state.get("lineage_validation_passed", False):
            metrics = final_state.get("validation_metrics", {})
            coverage = metrics.get("field_coverage", {}).get("percentage", 0)
            logger.info(f"  Agentic validation PASSED (coverage: {coverage:.1f}%)")
        else:
            logger.info("  Agentic validation NEEDS REVIEW")

    except Exception as exc:
        logger.error(f"  Agentic validation failed: {exc}")

    logger.info("Agentic post-run complete.")


def _build_and_export_dag(xml_files, output_dir, documents=None, param_files=None):
    """Build a single unified InformaticaDAG from all XMLs and export it.

    Uses the enriched LineageResult (after IntegrationExpert processing) so the
    DAG shows the same resolved data as the Excel/CSV output — resolved
    parameters, expression explanations, qualified table names.
    """
    try:
        from ..dag import DAGExporter, DAGQuery, LineageResultToDAGConverter
        from ..dag.dag_visual import export_rich_html
        from ..parsers.powermart_parser import PowermartParser
        from ..lineage.lineage_extractor import LineageExtractor
    except ImportError as exc:
        logger.warning(f"DAG module not available: {exc}")
        return

    param_loader = None
    if param_files:
        from ..utils.parameter_file_loader import ParameterFileLoader
        param_loader = ParameterFileLoader()
        wf_names = [Path(xf).stem for xf in xml_files]
        for pf in param_files:
            try:
                for wf_name in wf_names:
                    param_loader.load_consolidated(pf, wf_name)
            except Exception:
                try:
                    param_loader.load(pf)
                except Exception:
                    pass
        if param_loader.parameters:
            logger.info(f"  DAG: Loaded {len(param_loader.parameters)} parameters for resolution")

    logger.info("Building enriched Informatica DAG (from LineageResult)...")

    pairs = []
    if documents:
        if isinstance(documents, dict):
            for xml_file in xml_files:
                doc = documents.get(xml_file) or documents.get(str(xml_file))
                if doc:
                    pairs.append((str(xml_file), doc))
        else:
            for xml_file, doc in zip(xml_files, documents):
                pairs.append((str(xml_file), doc))
    else:
        parser = PowermartParser()
        for xml_file in xml_files:
            try:
                doc = parser.parse_file(xml_file)
                pairs.append((str(xml_file), doc))
            except Exception as exc:
                logger.warning(f"  Failed to parse {Path(xml_file).stem} for DAG: {exc}")

    if not pairs:
        logger.warning("  No documents available for DAG build")
        return

    extractor = LineageExtractor()
    triples = []
    for xml_path, doc in pairs:
        try:
            lineage_result = extractor.extract(doc)
            triples.append((xml_path, doc, lineage_result))
            logger.info(f"  Extracted lineage for {Path(xml_path).stem}: "
                        f"{len(lineage_result.field_lineages)} field lineages")
        except Exception as exc:
            logger.warning(f"  Lineage extraction failed for {Path(xml_path).stem}: {exc}")

    if not triples:
        logger.warning("  No lineage results available for DAG build")
        return

    try:
        converter = LineageResultToDAGConverter(param_loader=param_loader)
        dag = converter.convert(triples)

        dag_dir = safe_join(str(output_dir), "dag")
        Path(dag_dir).mkdir(parents=True, exist_ok=True)

        if len(pairs) == 1:
            file_prefix = Path(pairs[0][0]).stem
        else:
            file_prefix = "unified"

        DAGExporter.to_json(dag, safe_join(dag_dir, f"{file_prefix}_dag.json"))
        DAGExporter.to_graphml(dag, safe_join(dag_dir, f"{file_prefix}_dag.graphml"))

        if len(pairs) == 1:
            title = f"{file_prefix} Interactive Lineage"
        else:
            title = f"Unified Interactive Lineage ({len(pairs)} XMLs)"
        export_rich_html(dag, safe_join(dag_dir, f"{file_prefix}_dag.html"), title=title)

        stats = dag.get_statistics()
        logger.info(
            f"  Unified DAG: {stats['total_nodes']} nodes, {stats['total_edges']} edges, "
            f"{stats.get('mapping_count', 0)} mappings from {len(pairs)} XML(s)"
        )

        query = DAGQuery(dag)
        exec_order = query.get_execution_order()
        if exec_order:
            logger.info(f"  Execution order: {[s.get('task', '') for s in exec_order]}")

    except Exception as exc:
        logger.warning(f"  DAG build failed: {exc}")


if __name__ == "__main__":
    sys.exit(main())
