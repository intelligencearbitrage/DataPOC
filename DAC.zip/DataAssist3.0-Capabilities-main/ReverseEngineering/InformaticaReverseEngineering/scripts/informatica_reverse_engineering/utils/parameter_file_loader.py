"""
Parameter File Loader for Informatica .par/.prm files.

Parses Informatica PowerCenter parameter files and resolves
$Param_* / $$Var placeholders in SQL overrides and expressions.
"""

import os
import re
from pathlib import Path
from werkzeug.utils import safe_join
from typing import Dict, List, Optional, Union

from .logging_config import get_logger

logger = get_logger("parameter_file_loader")


def _read_text_auto_encoding(file_path: Path) -> str:
    """Read a text file, falling back from UTF-8 to latin-1.

    Informatica .prm/.par files may contain non-UTF-8 bytes (e.g. the
    delimiter character Ð = 0xD0 which is valid latin-1 but an incomplete
    UTF-8 sequence).  Try strict UTF-8 first; on failure fall back to
    latin-1 which accepts every byte value.
    """
    try:
        return file_path.read_text(encoding="utf-8")
    except (UnicodeDecodeError, ValueError):
        return file_path.read_text(encoding="latin-1")


class ParameterFileLoader:
    """
    Loads and resolves Informatica parameter files (.par / .prm).

    File format:
        [SectionName]
        $ParamName=Value
        $$VarName=Value

    Sections are optional; parameters outside a section are treated as global.
    """

    def __init__(self):
        self._params: Dict[str, str] = {}
        self._sections: Dict[str, Dict[str, str]] = {}
        # Per-mapping params: Global + session-specific overrides
        self._global_params: Dict[str, str] = {}
        self._session_params: Dict[str, Dict[str, str]] = {}  # session_key_lower -> {params}

    @property
    def parameters(self) -> Dict[str, str]:
        """All loaded parameters (flattened across sections)."""
        return dict(self._params)

    @property
    def sections(self) -> Dict[str, Dict[str, str]]:
        """Parameters grouped by section."""
        return dict(self._sections)

    def load(self, file_path: Union[str, Path]) -> int:
        """Load a single parameter file.

        Returns the number of parameters loaded from this file.
        """
        _raw = Path(file_path)
        file_path = Path(safe_join(str(_raw.parent), _raw.name))
        if not file_path.exists():
            logger.warning(f"Parameter file not found: {file_path}")
            return 0

        count = 0
        current_section = "_global_"

        try:
            text = _read_text_auto_encoding(file_path)
        except Exception as e:
            logger.error(f"Failed to read parameter file {file_path}: {e}")
            return 0

        for raw_line in text.splitlines():
            line = raw_line.strip()

            # Skip empty lines and comments
            if not line or line.startswith("#") or line.startswith(";"):
                continue

            # Section header
            section_match = re.match(r"^\[(.+)\]\s*$", line)
            if section_match:
                current_section = section_match.group(1).strip()
                continue

            # Parameter assignment: $ParamName=Value or $$VarName=Value
            param_match = re.match(r"^(\$\$?\w+)\s*=\s*(.*)", line)
            if param_match:
                param_name = param_match.group(1)
                param_value = param_match.group(2).strip().replace("\ufffd", "")
                self._params[param_name] = param_value
                self._sections.setdefault(current_section, {})[param_name] = param_value
                count += 1
                continue

        logger.info(f"Loaded {count} parameters from {file_path.name}")
        return count

    def load_consolidated(
        self, file_path: Union[str, Path], workflow_name: str
    ) -> int:
        """Load parameters from a consolidated param file for a specific workflow.

        A consolidated file concatenates many .prm files separated by
        ``===== wf_NAME.prm =====`` headers.  This method extracts only the
        section that matches *workflow_name*, parses its ``[Global]`` and
        per-session ``[...]`` sub-sections, and stores the result.

        Global params are stored in ``_global_params``.  Per-session params
        (keyed by session/mapping name) are stored in ``_session_params``.
        The flat ``_params`` dict gets Global + ALL session params merged
        (for backward compatibility), but ``resolve_for_mapping()`` should
        be used for per-mapping resolution.

        Returns the number of parameters loaded.
        """
        _raw = Path(file_path)
        file_path = Path(safe_join(str(_raw.parent), _raw.name))
        if not file_path.exists():
            logger.warning(f"Consolidated parameter file not found: {file_path}")
            return 0

        # Normalise the workflow name for matching (strip .xml/.prm, lowercase)
        wf_key = re.sub(r"\.(xml|prm)$", "", workflow_name, flags=re.IGNORECASE).lower()

        try:
            text = _read_text_auto_encoding(file_path)
        except Exception as e:
            logger.error(f"Failed to read consolidated parameter file {file_path}: {e}")
            return 0

        # --- Locate the workflow section ---
        section_lines: List[str] = []
        in_section = False
        for raw_line in text.splitlines():
            stripped = raw_line.strip()
            # Check for ===== delimiter
            if stripped.startswith("=====") and stripped.endswith("====="):
                if in_section:
                    break  # reached the next workflow — stop
                # Extract workflow name from header
                header_name = stripped.strip("= ").strip()
                header_key = re.sub(
                    r"\.(prm|xml)$", "", header_name, flags=re.IGNORECASE
                ).lower()
                if header_key == wf_key:
                    in_section = True
                continue
            if in_section:
                section_lines.append(raw_line)

        if not section_lines:
            # Fallback: the .prm header may differ from the actual workflow name
            # (e.g., header "wf_X.prm" but workflow is "wf_X_DW_LOAD").
            # Scan ALL sections for session headers [FOLDER.WF:workflow_name.ST:...]
            # that contain our workflow name and collect params from that section.
            _all_sections = text.split("\n")
            _fallback_lines: List[str] = []
            _in_fallback = False
            _wf_pattern = f".wf:{wf_key}."
            for raw_line in _all_sections:
                stripped = raw_line.strip()
                if stripped.startswith("=====") and stripped.endswith("====="):
                    if _in_fallback:
                        break
                    continue
                # Check if a section header contains our workflow name
                sec_match = re.match(r"^\[(.+)\]\s*$", stripped)
                if sec_match:
                    sec_name = sec_match.group(1).lower()
                    if _wf_pattern in sec_name:
                        _in_fallback = True
                        # Also include the [Global] section from the SAME .prm block
                        # Find the ===== block that contains this session header
                        # and re-extract from its [Global] section
                if _in_fallback:
                    _fallback_lines.append(raw_line)

            if _fallback_lines:
                # Re-extract: find the ===== block containing the matched session
                # and collect everything from that block
                section_lines = []
                _in_block = False
                _found_wf_session = False
                for raw_line in _all_sections:
                    stripped = raw_line.strip()
                    if stripped.startswith("=====") and stripped.endswith("====="):
                        if _in_block and _found_wf_session:
                            break
                        _in_block = True
                        _found_wf_session = False
                        section_lines = []
                        continue
                    if _in_block:
                        section_lines.append(raw_line)
                        sec_match = re.match(r"^\[(.+)\]\s*$", stripped)
                        if sec_match and _wf_pattern in sec_match.group(1).lower():
                            _found_wf_session = True

                if not _found_wf_session:
                    section_lines = []

            if not section_lines:
                logger.warning(
                    f"Workflow \'{workflow_name}\' not found in consolidated param file"
                )
                return 0

        # --- Parse the extracted section into Global + per-session ---
        count = 0
        current_section = "_global_"
        is_global = True

        for raw_line in section_lines:
            line = raw_line.strip()

            # Skip empty lines, comments (;  --  ##)
            if not line or line.startswith(";") or line.startswith("--") or line.startswith("##"):
                continue

            # Section header  [SectionName]
            section_match = re.match(r"^\[(.+)\]\s*$", line)
            if section_match:
                current_section = section_match.group(1).strip()
                is_global = current_section.lower() == "global"
                continue

            # Parameter assignment: $ParamName=Value  or  $$VarName=Value
            param_match = re.match(r"^(\$\$?\w+)\s*=\s*(.*)", line)
            if param_match:
                param_name = param_match.group(1)
                param_value = param_match.group(2).strip().replace("\ufffd", "")

                if is_global:
                    self._global_params[param_name] = param_value
                else:
                    # Extract mapping name from session header
                    # Format: FOLDER.WF:workflow.ST:s_m_MAPPING_NAME
                    # Session name s_m_XXX -> mapping name m_XXX
                    session_key = current_section.lower()
                    self._session_params.setdefault(session_key, {})[param_name] = param_value

                # Also store in flat _params (backward compat)
                self._params[param_name] = param_value
                self._sections.setdefault(current_section, {})[param_name] = param_value
                count += 1
                continue

        logger.info(
            f"Loaded {count} parameters for workflow \'{workflow_name}\' "
            f"from {file_path.name} "
            f"(global={len(self._global_params)}, sessions={len(self._session_params)})"
        )
        return count

    def resolve_for_mapping(self, text: str, mapping_name: str) -> str:
        """Replace placeholders using Global + the session params that match *mapping_name*.

        The session header format is ``FOLDER.WF:wf_NAME.ST:s_m_MAPPING_NAME``.
        We match by checking if the mapping name appears in the session key.
        Global params are applied first, then session-specific params override.
        """
        if not text or (not self._global_params and not self._session_params):
            # Fall back to flat resolve
            return self.resolve_placeholders(text)

        # Build merged param dict: Global + matching session
        merged = dict(self._global_params)

        mapping_lower = mapping_name.lower()
        # Session key format: "edw_stg.wf:wf_xxx.st:s_m_mapping_name"
        # Try to match: session contains the mapping name, or
        # session contains s_<mapping_name> (session prefix is s_)
        for session_key, session_params in self._session_params.items():
            # Extract the part after .ST: (session name)
            st_match = re.search(r"\.st:(.+)$", session_key, re.IGNORECASE)
            if st_match:
                session_name = st_match.group(1).strip().lower()
                # s_m_SHAWILN_AGMT_FEATURE_BUILD -> m_SHAWILN_AGMT_FEATURE_BUILD
                derived_mapping = re.sub(r"^s_", "", session_name)
                if derived_mapping == mapping_lower:
                    merged.update(session_params)
                    break

        if not merged:
            return self.resolve_placeholders(text)

        result = text
        for _pass in range(3):
            prev = result
            for name in sorted(merged, key=len, reverse=True):
                value = merged[name]
                display_value = value if value else "''"
                pattern = re.escape(name) + r'(?:\s*\(=\s*[^)]*\))?'
                result = re.sub(pattern, display_value, result, flags=re.IGNORECASE)
            if result == prev or '$' not in result:
                break

        return result

    def resolve_for_session(self, text: str, session_name: str) -> str:
        """Replace placeholders using Global + the session params that match *session_name*.

        The session section header format is ``FOLDER.WF:wf_NAME.ST:session_name``.
        We match by checking if the session name appears after ``.ST:`` in the
        stored session keys.  Global params are applied first, then
        session-specific params override.
        """
        if not text or (not self._global_params and not self._session_params):
            return self.resolve_placeholders(text)

        # Build merged param dict: Global + matching session
        merged = dict(self._global_params)

        session_lower = session_name.lower()
        for session_key, session_params in self._session_params.items():
            # Extract the part after .ST: (session name)
            st_match = re.search(r"\.st:(.+)$", session_key, re.IGNORECASE)
            if st_match:
                key_session_name = st_match.group(1).strip().lower()
                if key_session_name == session_lower:
                    merged.update(session_params)
                    break

        if not merged:
            return self.resolve_placeholders(text)

        result = text
        for _pass in range(3):
            prev = result
            for name in sorted(merged, key=len, reverse=True):
                value = merged[name]
                display_value = value if value else "''"
                pattern = re.escape(name) + r'(?:\s*\(=\s*[^)]*\))?'
                result = re.sub(pattern, display_value, result, flags=re.IGNORECASE)
            if result == prev or '$' not in result:
                break

        return result

    def load_multiple(self, file_paths: List[Union[str, Path]]) -> int:
        """Load multiple parameter files. Later files override earlier ones.

        Returns the total number of parameters loaded.
        """
        total = 0
        for fp in file_paths:
            total += self.load(fp)
        return total

    def resolve_placeholders(self, text: str) -> str:
        """Replace $Param_* and $$Var placeholders in text with loaded values.

        Matching is case-insensitive (Informatica parameter names are
        case-insensitive).  Sorts parameter names by length descending to
        avoid partial matches (e.g., replacing $Param_DB before $Param_D).

        Runs up to 3 passes to handle nested references (e.g.,
        $Param_SP_Call containing $Param_Semantic_Database).
        """
        if not text or not self._params:
            return text

        result = text
        for _pass in range(3):
            prev = result
            for name in sorted(self._params, key=len, reverse=True):
                value = self._params[name]
                display_value = value if value else "''"
                pattern = re.escape(name) + r'(?:\s*\(=\s*[^)]*\))?'
                result = re.sub(pattern, display_value, result, flags=re.IGNORECASE)
            if result == prev or '$' not in result:
                break

        return result

    def merge_into_catalog(self, param_catalog) -> int:
        """Merge loaded parameters into an existing ParameterCatalog.

        Args:
            param_catalog: A ParameterCatalog instance with an add() method.

        Returns:
            Number of parameters merged.
        """
        count = 0
        for name, value in self._params.items():
            try:
                param_catalog.add(name=name, value=value, source="parameter_file")
                count += 1
            except Exception:
                # Catalog may not support add() or may have a different signature
                pass
        return count
