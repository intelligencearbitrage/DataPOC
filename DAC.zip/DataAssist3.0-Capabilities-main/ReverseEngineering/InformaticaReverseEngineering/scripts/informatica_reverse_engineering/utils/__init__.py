"""Utility functions."""

from .xml_utils import get_attr, get_child_text, parse_xml_file
from .string_utils import clean_text, normalize_name
from .logging_config import setup_logging

# XDM-based utilities (lxml/XPath)
from .xml_utils_xdm import XDMXMLParser, FieldContext, ConnectorContext, parse_xml_file_xdm
from .xpath_builder import (
    InformaticaXPathBuilder,
    InformaticaXPathPatterns,
    xpath_builder,
    TransformationType,
    InstanceType,
    PortType,
)
from .mapping_ast import (
    MappingAST,
    TransformationNode,
    ConnectorEdge,
    FieldNode,
    NodeType,
    ASTVisitor,
    ExpressionCollector,
    TransformationCounter,
)
from .expression_explainer import (
    InformaticaExpressionExplainer,
    explain_expression,
    explain_transformation_chain,
)

# Phase 3: Advanced graph analysis
try:
    from .mapping_ast import (
        AdvancedGraphAnalyzer,
        StronglyConnectedComponent,
        CriticalPath,
        DependencyInfo,
    )
    PHASE3_AVAILABLE = True
except ImportError:
    PHASE3_AVAILABLE = False

# Phase 4: Saxon XPath 2.0/3.0 support (optional)
try:
    from .saxon_xpath_provider import (
        XPathProvider,
        XPathProviderFactory,
        SaxonXPathProvider,
        LxmlXPathProvider,
        XPathVersion,
        XPathQueryResult,
        InformaticaXPath2Patterns,
        XPath2Pattern,
        is_saxon_available,
        SAXON_AVAILABLE,
    )
    PHASE4_AVAILABLE = True
except ImportError:
    PHASE4_AVAILABLE = False
    SAXON_AVAILABLE = False

    def is_saxon_available():
        return False

__all__ = [
    # Original utilities
    "get_attr",
    "get_child_text",
    "parse_xml_file",
    "clean_text",
    "normalize_name",
    "setup_logging",
    # XDM utilities
    "XDMXMLParser",
    "FieldContext",
    "ConnectorContext",
    "parse_xml_file_xdm",
    # XPath builder
    "InformaticaXPathBuilder",
    "InformaticaXPathPatterns",
    "xpath_builder",
    "TransformationType",
    "InstanceType",
    "PortType",
    # Mapping AST
    "MappingAST",
    "TransformationNode",
    "ConnectorEdge",
    "FieldNode",
    "NodeType",
    "ASTVisitor",
    "ExpressionCollector",
    "TransformationCounter",
    # Expression Explainer
    "InformaticaExpressionExplainer",
    "explain_expression",
    "explain_transformation_chain",
]

# Add Phase 3 exports if available
if PHASE3_AVAILABLE:
    __all__.extend([
        "AdvancedGraphAnalyzer",
        "StronglyConnectedComponent",
        "CriticalPath",
        "DependencyInfo",
        "PHASE3_AVAILABLE",
    ])

# Add Phase 4 exports if available
if PHASE4_AVAILABLE:
    __all__.extend([
        "XPathProvider",
        "XPathProviderFactory",
        "SaxonXPathProvider",
        "LxmlXPathProvider",
        "XPathVersion",
        "XPathQueryResult",
        "InformaticaXPath2Patterns",
        "XPath2Pattern",
        "is_saxon_available",
        "SAXON_AVAILABLE",
        "PHASE4_AVAILABLE",
    ])
