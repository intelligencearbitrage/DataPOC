"""Shared utility for building mapping flow summary data.

Used by all exporters (Excel, JSON, CSV, HTML) to ensure consistent
mapping flow summary across all output formats.
"""

from typing import Any, Dict, List, Optional, Set, Tuple


def _resolve_session_to_mapping(session_mapping_name: str, mapping_names: Set[str]) -> Optional[str]:
    """
    Resolve a session's MAPPINGNAME to an actual mapping name.

    In Informatica, sessions may reference mappings with prefixes like 'sc_'
    (shortcut prefix). This function handles fuzzy matching.

    Args:
        session_mapping_name: The MAPPINGNAME attribute from the session XML
        mapping_names: Set of actual mapping names in the document

    Returns:
        The matched mapping name, or None if no match
    """
    # Exact match first
    if session_mapping_name in mapping_names:
        return session_mapping_name

    # Try stripping common prefixes: sc_, SC_
    prefixes_to_strip = ['sc_', 'SC_']
    for prefix in prefixes_to_strip:
        if session_mapping_name.startswith(prefix):
            stripped = session_mapping_name[len(prefix):]
            if stripped in mapping_names:
                return stripped

    # Try case-insensitive match
    session_lower = session_mapping_name.lower()
    for mname in mapping_names:
        if mname.lower() == session_lower:
            return mname

    # Try case-insensitive after stripping sc_ prefix
    for prefix in prefixes_to_strip:
        if session_lower.startswith(prefix.lower()):
            stripped_lower = session_lower[len(prefix):]
            for mname in mapping_names:
                if mname.lower() == stripped_lower:
                    return mname

    return None


def _resolve_table_names(
    raw_names: Set[str],
    doc_names: Dict[str, str],
    strip_prefixes: List[str],
) -> List[str]:
    """
    Resolve instance/transformation names to actual document-level source/target table names.

    Args:
        raw_names: Set of raw names from instances
        doc_names: Dict of lower_name -> actual_name from document sources/targets
        strip_prefixes: Prefixes to strip for matching (e.g., ['sq_', 'sc_', 'src_'])

    Returns:
        Sorted list of resolved table names
    """
    resolved = set()
    for name in raw_names:
        name_lower = name.lower()
        clean_name = name_lower
        for prefix in strip_prefixes:
            clean_name = clean_name.replace(prefix, '')

        matched = False
        for doc_lower, doc_actual in doc_names.items():
            if clean_name in doc_lower or doc_lower in clean_name:
                resolved.add(doc_actual)
                matched = True
        if not matched:
            resolved.add(name)

    return sorted(resolved)


def build_mapping_flow_summary(document) -> List[Dict[str, Any]]:
    """
    Build mapping flow summary data from a PowermartDocument.

    This is the single source of truth for mapping flow summary logic,
    used by all exporters.

    Returns a list of dicts with keys:
        sequence, mapping_name, source_tables, target_tables,
        depends_on_mapping, session_name, workflow_name
    """
    mapping_names = {m.name for m in document.mappings}

    # Step 1: Build mapping info (sources, targets)
    mapping_info = {}
    for mapping in document.mappings:
        source_tables = set()
        target_tables = set()

        for source in mapping.sources:
            source_tables.add(source.name)
        for target in mapping.targets:
            target_tables.add(target.name)

        # Fallback to instances if sources/targets are empty
        if not source_tables:
            for inst in mapping.source_instances:
                source_tables.add(inst.transformation_name)
        if not target_tables:
            for inst in mapping.target_instances:
                target_tables.add(inst.transformation_name)

        # Resolve against document-level source/target definitions
        doc_source_names = {s.name.lower(): s.name for s in document.sources}
        doc_target_names = {t.name.lower(): t.name for t in document.targets}

        resolved_sources = _resolve_table_names(
            source_tables, doc_source_names,
            ['sq_', 'sc_', 'src_']
        )
        resolved_targets = _resolve_table_names(
            target_tables, doc_target_names,
            ['sq_', 'sc_', 'tgt_']
        )

        mapping_info[mapping.name] = {
            "sources": resolved_sources,
            "targets": resolved_targets,
            "session_name": "",
            "workflow_name": "",
        }

    # Step 2: Link sessions to mappings (with fuzzy matching) and get execution order
    # session_name -> resolved_mapping_name
    session_to_mapping = {}
    # resolved_mapping_name -> session_name
    mapping_to_session = {}
    execution_order = []  # List of (topo_index, mapping_name, session_name)
    workflow_name = ""

    # Build workflow link dependency map: session_name -> list of predecessor session names
    session_predecessors = {}  # to_session -> [from_session, ...]

    for workflow in document.workflows:
        workflow_name = workflow.name

        # Get topological execution order
        try:
            exec_order = workflow.get_execution_order()
        except Exception:
            exec_order = []

        # Build session predecessor map from workflow links
        for link in workflow.links:
            from_task = link.from_task
            to_task = link.to_task
            # Skip the Start task as a predecessor
            if from_task.lower() == 'start':
                continue
            if to_task not in session_predecessors:
                session_predecessors[to_task] = []
            session_predecessors[to_task].append(from_task)

        # Match sessions to mappings
        for session in workflow.sessions:
            resolved_mapping = _resolve_session_to_mapping(
                session.mapping_name, mapping_names
            )
            if resolved_mapping:
                session_to_mapping[session.name] = resolved_mapping
                mapping_to_session[resolved_mapping] = session.name
                if resolved_mapping in mapping_info:
                    mapping_info[resolved_mapping]["session_name"] = session.name
                    mapping_info[resolved_mapping]["workflow_name"] = workflow_name

                # Position in execution order
                if session.name in exec_order:
                    idx = exec_order.index(session.name)
                    execution_order.append((idx, resolved_mapping, session.name))

    # Also check document-level sessions (for cases not in workflow)
    for session in document.sessions:
        if session.mapping_name:
            resolved_mapping = _resolve_session_to_mapping(
                session.mapping_name, mapping_names
            )
            if resolved_mapping and resolved_mapping in mapping_info:
                if not mapping_info[resolved_mapping]["session_name"]:
                    mapping_info[resolved_mapping]["session_name"] = session.name

    # Step 3: Sort by execution order
    if execution_order:
        execution_order.sort(key=lambda x: x[0])
        ordered_mappings = [(m[1], m[2]) for m in execution_order]
    else:
        ordered_mappings = [
            (m.name, mapping_info[m.name]["session_name"])
            for m in document.mappings
        ]

    # Step 4: Determine dependencies from BOTH data overlap AND workflow links
    mapping_targets_map = {
        name: set(info["targets"]) for name, info in mapping_info.items()
    }

    def get_dependencies(mapping_name: str) -> List[str]:
        """
        Get dependencies for a mapping from two sources:
        1. Data dependencies: mapping B's sources overlap with mapping A's targets
        2. Workflow execution dependencies: workflow links define explicit predecessor sessions
        """
        deps = set()

        # Data dependency: my sources overlap with another mapping's targets
        if mapping_name in mapping_info:
            my_sources = set(mapping_info[mapping_name]["sources"])
            for other_name, other_targets in mapping_targets_map.items():
                if other_name != mapping_name and my_sources & other_targets:
                    deps.add(other_name)

        # Workflow link dependency: predecessor sessions map to predecessor mappings
        my_session = mapping_to_session.get(mapping_name)
        if my_session and my_session in session_predecessors:
            for pred_session in session_predecessors[my_session]:
                pred_mapping = session_to_mapping.get(pred_session)
                if pred_mapping and pred_mapping != mapping_name:
                    deps.add(pred_mapping)

        return sorted(deps)

    # Step 5: Build the summary rows
    summary = []
    seen = set()
    seq = 0

    for mapping_name, session_name in ordered_mappings:
        if mapping_name in seen or mapping_name not in mapping_info:
            continue
        seen.add(mapping_name)
        seq += 1

        info = mapping_info[mapping_name]
        deps = get_dependencies(mapping_name)

        summary.append({
            "sequence": seq,
            "mapping_name": mapping_name,
            "source_tables": info["sources"],
            "target_tables": info["targets"],
            "depends_on_mapping": deps if deps else None,
            "session_name": info["session_name"] or session_name,
            "workflow_name": info["workflow_name"] or workflow_name,
        })

    # Handle any remaining mappings not in execution order
    for mapping in document.mappings:
        if mapping.name not in seen:
            seq += 1
            info = mapping_info[mapping.name]
            deps = get_dependencies(mapping.name)
            summary.append({
                "sequence": seq,
                "mapping_name": mapping.name,
                "source_tables": info["sources"],
                "target_tables": info["targets"],
                "depends_on_mapping": deps if deps else None,
                "session_name": info["session_name"],
                "workflow_name": info["workflow_name"],
            })

    return summary
