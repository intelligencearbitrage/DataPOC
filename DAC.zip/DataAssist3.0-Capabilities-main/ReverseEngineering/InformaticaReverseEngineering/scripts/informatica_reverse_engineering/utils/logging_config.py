"""Logging configuration."""

import logging
import sys
from pathlib import Path
from typing import Optional


def setup_logging(
    level: int = logging.INFO,
    log_file: Optional[str] = None,
    format_string: Optional[str] = None
) -> logging.Logger:
    """
    Configure logging for the application.

    Args:
        level: Logging level (default INFO)
        log_file: Optional file path for log output
        format_string: Custom format string

    Returns:
        Configured logger instance
    """
    if format_string is None:
        format_string = "%(asctime)s - %(name)s - %(levelname)s - %(message)s"

    # Create formatter
    formatter = logging.Formatter(format_string)

    # Get root logger for the package
    logger = logging.getLogger("informatica_reverse_engineering")
    logger.setLevel(level)

    # Remove existing handlers
    logger.handlers.clear()

    # Console handler — force UTF-8 to avoid UnicodeEncodeError on Windows (cp1252)
    utf8_stdout = open(sys.stdout.fileno(), mode="w", encoding="utf-8", closefd=False)
    console_handler = logging.StreamHandler(utf8_stdout)
    console_handler.setLevel(level)
    console_handler.setFormatter(formatter)
    logger.addHandler(console_handler)

    # File handler if specified
    if log_file:
        log_path = Path(log_file)
        log_path.parent.mkdir(parents=True, exist_ok=True)
        file_handler = logging.FileHandler(log_path, encoding="utf-8")
        file_handler.setLevel(level)
        file_handler.setFormatter(formatter)
        logger.addHandler(file_handler)

    return logger


def get_logger(name: str) -> logging.Logger:
    """Get a logger with the package namespace."""
    return logging.getLogger(f"informatica_reverse_engineering.{name}")
