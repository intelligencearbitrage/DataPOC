"""
Expression Explainer for Informatica Expressions.

Converts Informatica PowerCenter expressions to human-readable English descriptions.
Supports common functions, operators, and patterns used in Informatica transformations.
"""

import re
from typing import Any, List, Dict, Tuple, Optional
from dataclasses import dataclass


@dataclass
class ExpressionPart:
    """A parsed part of an expression."""
    type: str  # "function", "field", "literal", "operator", "variable"
    value: str
    arguments: List["ExpressionPart"] = None

    def __post_init__(self):
        if self.arguments is None:
            self.arguments = []


class InformaticaExpressionExplainer:
    """
    Converts Informatica expressions to English descriptions.

    Supports:
    - Common functions (IIF, DECODE, NVL, SUBSTR, etc.)
    - String manipulation functions
    - Date functions
    - Aggregate functions
    - Lookup references
    - Mathematical operations
    - Concatenation
    - Variable references
    """

    # Function descriptions - maps function name to (description template, arg names)
    FUNCTION_DESCRIPTIONS = {
        # Conditional
        "IIF": ("If {0} then return {1}, otherwise return {2}", ["condition", "true_value", "false_value"]),
        "DECODE": ("Match {0} against values and return corresponding result", ["value", "search/result pairs"]),
        "CASE": ("Evaluate conditions and return matching result", ["conditions"]),

        # Null handling
        "NVL": ("If {0} is null, use {1} instead", ["value", "default"]),
        "ISNULL": ("Check if {0} is null", ["value"]),
        "NULLIF": ("Return null if {0} equals {1}", ["value1", "value2"]),
        "COALESCE": ("Return the first non-null value from: {0}", ["values"]),

        # String functions
        "SUBSTR": ("Extract substring from {0} starting at position {1} for {2} characters", ["string", "start", "length"]),
        "SUBSTRING": ("Extract substring from {0} starting at position {1} for {2} characters", ["string", "start", "length"]),
        "UPPER": ("Convert {0} to uppercase", ["string"]),
        "LOWER": ("Convert {0} to lowercase", ["string"]),
        "LTRIM": ("Remove leading spaces from {0}", ["string"]),
        "RTRIM": ("Remove trailing spaces from {0}", ["string"]),
        "TRIM": ("Remove leading and trailing spaces from {0}", ["string"]),
        "LPAD": ("Left-pad {0} with {2} to length {1}", ["string", "length", "pad_char"]),
        "RPAD": ("Right-pad {0} with {2} to length {1}", ["string", "length", "pad_char"]),
        "LENGTH": ("Get the length of {0}", ["string"]),
        "INSTR": ("Find position of {1} in {0}", ["string", "search"]),
        "REPLACE": ("Replace {1} with {2} in {0}", ["string", "old", "new"]),
        "REPLACECHR": ("Replace characters {1} with {2} in {0}", ["string", "old_chars", "new_char"]),
        "REPLACESTR": ("Replace string {1} with {2} in {0}", ["string", "old_str", "new_str"]),
        "CONCAT": ("Concatenate {0} and {1}", ["string1", "string2"]),
        "REG_EXTRACT": ("Extract pattern {1} from {0}", ["string", "pattern"]),
        "REG_MATCH": ("Check if {0} matches pattern {1}", ["string", "pattern"]),
        "REG_REPLACE": ("Replace pattern {1} with {2} in {0}", ["string", "pattern", "replacement"]),
        "INITCAP": ("Capitalize first letter of each word in {0}", ["string"]),
        "REVERSE": ("Reverse the string {0}", ["string"]),
        "SOUNDEX": ("Get soundex code for {0}", ["string"]),
        "METAPHONE": ("Get metaphone code for {0}", ["string"]),
        "CHR": ("Get character for ASCII code {0}", ["code"]),
        "ASCII": ("Get ASCII code for character {0}", ["char"]),

        # Date functions
        "TO_DATE": ("Convert {0} to date using format {1}", ["string", "format"]),
        "TO_CHAR": ("Convert {0} to string using format {1}", ["value", "format"]),
        "SYSDATE": ("Current system date/time", []),
        "SYSTIMESTAMP": ("Current system timestamp", []),
        "ADD_TO_DATE": ("Add {2} {1} to {0}", ["date", "unit", "amount"]),
        "DATE_DIFF": ("Calculate difference in {2} between {0} and {1}", ["date1", "date2", "unit"]),
        "DATE_COMPARE": ("Compare {0} with {1}", ["date1", "date2"]),
        "GET_DATE_PART": ("Get {1} from {0}", ["date", "part"]),
        "SET_DATE_PART": ("Set {1} of {0} to {2}", ["date", "part", "value"]),
        "TRUNC": ("Truncate {0} to {1}", ["date", "precision"]),
        "LAST_DAY": ("Get last day of the month for {0}", ["date"]),
        "ROUND": ("Round {0} to {1}", ["value", "precision"]),
        "MAKE_DATE_TIME": ("Create date/time from components", ["components"]),

        # Numeric functions
        "ABS": ("Absolute value of {0}", ["number"]),
        "CEIL": ("Round {0} up to nearest integer", ["number"]),
        "FLOOR": ("Round {0} down to nearest integer", ["number"]),
        "MOD": ("Remainder of {0} divided by {1}", ["dividend", "divisor"]),
        "POWER": ("Raise {0} to power {1}", ["base", "exponent"]),
        "SQRT": ("Square root of {0}", ["number"]),
        "LOG": ("Logarithm of {0}", ["number"]),
        "EXP": ("e raised to power {0}", ["number"]),
        "SIGN": ("Sign of {0} (-1, 0, or 1)", ["number"]),

        # Type conversion
        "TO_INTEGER": ("Convert {0} to integer", ["value"]),
        "TO_BIGINT": ("Convert {0} to big integer", ["value"]),
        "TO_DECIMAL": ("Convert {0} to decimal with scale {1}", ["value", "scale"]),
        "TO_FLOAT": ("Convert {0} to floating point", ["value"]),
        "CAST": ("Cast {0} to type {1}", ["value", "type"]),

        # Aggregate functions
        "SUM": ("Sum of {0}", ["values"]),
        "AVG": ("Average of {0}", ["values"]),
        "COUNT": ("Count of {0}", ["values"]),
        "MAX": ("Maximum value of {0}", ["values"]),
        "MIN": ("Minimum value of {0}", ["values"]),
        "FIRST": ("First value of {0}", ["values"]),
        "LAST": ("Last value of {0}", ["values"]),
        "MEDIAN": ("Median of {0}", ["values"]),
        "STDDEV": ("Standard deviation of {0}", ["values"]),
        "VARIANCE": ("Variance of {0}", ["values"]),

        # Lookup
        "LOOKUP": ("Lookup {0} from lookup transformation", ["fields"]),

        # Error handling
        "ERROR": ("Raise error: {0}", ["message"]),
        "ABORT": ("Abort with message: {0}", ["message"]),

        # Miscellaneous
        "SETCOUNTVARIABLE": ("Set counter variable {0} to {1}", ["var", "value"]),
        "SETVARIABLE": ("Set variable {0} to {1}", ["var", "value"]),
    }

    # Operator descriptions
    OPERATOR_DESCRIPTIONS = {
        "||": "concatenate",
        "+": "add",
        "-": "subtract",
        "*": "multiply",
        "/": "divide",
        "=": "equals",
        "!=": "not equals",
        "<>": "not equals",
        ">": "greater than",
        "<": "less than",
        ">=": "greater than or equal to",
        "<=": "less than or equal to",
        "AND": "and",
        "OR": "or",
        "NOT": "not",
    }

    def __init__(self):
        self.max_depth = 5  # Prevent infinite recursion

    def explain(self, expression: str, context: Optional[Dict] = None) -> str:
        """
        Convert an Informatica expression to English.

        Args:
            expression: The Informatica expression
            context: Optional context (transformation name, field names, etc.)

        Returns:
            Human-readable English description
        """
        if not expression or not expression.strip():
            return "No transformation (direct mapping)"

        expression = expression.strip()

        # Handle simple cases
        if self._is_simple_field_reference(expression):
            return f"Direct copy of field {self._clean_field_name(expression)}"

        if self._is_literal(expression):
            return f"Constant value: {expression}"

        if self._is_variable(expression):
            return f"Value from variable {expression}"

        # Parse and explain complex expressions
        try:
            explanation = self._explain_expression(expression, 0)
            return self._clean_explanation(explanation)
        except Exception as e:
            # Fallback to basic description
            return self._basic_explain(expression)

    def _explain_expression(self, expr: str, depth: int) -> str:
        """Recursively explain an expression."""
        if depth > self.max_depth:
            return expr

        expr = expr.strip()

        # Check for function calls
        func_match = re.match(r'^(\w+)\s*\((.*)\)$', expr, re.DOTALL)
        if func_match:
            func_name = func_match.group(1).upper()
            args_str = func_match.group(2)
            return self._explain_function(func_name, args_str, depth)

        # Check for concatenation
        if '||' in expr:
            return self._explain_concatenation(expr, depth)

        # Check for arithmetic
        if self._has_arithmetic(expr):
            return self._explain_arithmetic(expr, depth)

        # Check for comparison
        if self._has_comparison(expr):
            return self._explain_comparison(expr, depth)

        # Check for lookup reference
        if ':LKP.' in expr.upper():
            return self._explain_lookup(expr)

        # Check for variable
        if expr.startswith('$') or expr.startswith('$$'):
            return f"value of variable {expr}"

        # Field reference
        if self._is_field_reference(expr):
            return f"field {self._clean_field_name(expr)}"

        # Literal
        if self._is_literal(expr):
            return self._explain_literal(expr)

        return expr

    def _explain_function(self, func_name: str, args_str: str, depth: int) -> str:
        """Explain a function call."""
        args = self._parse_arguments(args_str)

        # Get function template
        if func_name in self.FUNCTION_DESCRIPTIONS:
            template, arg_names = self.FUNCTION_DESCRIPTIONS[func_name]

            # Explain each argument
            explained_args = []
            for i, arg in enumerate(args):
                explained = self._explain_expression(arg.strip(), depth + 1)
                explained_args.append(explained)

            # Fill template
            try:
                if len(explained_args) >= len(arg_names):
                    return template.format(*explained_args[:len(arg_names)])
                elif explained_args:
                    # Partial arguments
                    return template.format(*explained_args + ["..."] * (len(arg_names) - len(explained_args)))
                else:
                    return template.format(*["..." for _ in arg_names])
            except (IndexError, KeyError):
                return f"{func_name} function applied to {', '.join(explained_args)}"

        # Unknown function
        explained_args = [self._explain_expression(a.strip(), depth + 1) for a in args]
        return f"{func_name} function applied to {', '.join(explained_args)}"

    def _explain_concatenation(self, expr: str, depth: int) -> str:
        """Explain concatenation operations."""
        parts = self._split_by_operator(expr, '||')
        explained = [self._explain_expression(p.strip(), depth + 1) for p in parts]

        if len(explained) == 2:
            return f"Combine {explained[0]} with {explained[1]}"
        else:
            return f"Combine: {', '.join(explained)}"

    def _explain_arithmetic(self, expr: str, depth: int) -> str:
        """Explain arithmetic operations."""
        # Find the main operator
        for op in ['+', '-', '*', '/']:
            if op in expr:
                parts = self._split_by_operator(expr, op)
                if len(parts) >= 2:
                    left = self._explain_expression(parts[0].strip(), depth + 1)
                    right = self._explain_expression(parts[1].strip(), depth + 1)
                    op_word = self.OPERATOR_DESCRIPTIONS.get(op, op)
                    return f"{left} {op_word} {right}"

        return expr

    def _explain_comparison(self, expr: str, depth: int) -> str:
        """Explain comparison operations."""
        for op in ['>=', '<=', '!=', '<>', '=', '>', '<']:
            if op in expr:
                parts = expr.split(op, 1)
                if len(parts) == 2:
                    left = self._explain_expression(parts[0].strip(), depth + 1)
                    right = self._explain_expression(parts[1].strip(), depth + 1)
                    op_word = self.OPERATOR_DESCRIPTIONS.get(op, op)
                    return f"{left} {op_word} {right}"

        return expr

    def _explain_lookup(self, expr: str) -> str:
        """Explain lookup reference."""
        match = re.search(r':LKP\.(\w+)', expr, re.IGNORECASE)
        if match:
            lookup_name = match.group(1)
            return f"value from lookup {lookup_name}"
        return "lookup value"

    def _explain_literal(self, expr: str) -> str:
        """Explain a literal value."""
        expr = expr.strip()
        if expr.startswith("'") and expr.endswith("'"):
            value = expr[1:-1]
            if not value:
                return "empty string"
            return f"'{value}'"
        if expr.upper() == "NULL":
            return "null"
        if re.match(r'^-?\d+\.?\d*$', expr):
            return expr
        return expr

    def _parse_arguments(self, args_str: str) -> List[str]:
        """Parse function arguments, handling nested parentheses."""
        args = []
        current = ""
        depth = 0
        in_string = False
        string_char = None

        for char in args_str:
            if char in ("'", '"') and (not in_string or char == string_char):
                in_string = not in_string
                if in_string:
                    string_char = char
                else:
                    string_char = None
                current += char
            elif not in_string:
                if char == '(':
                    depth += 1
                    current += char
                elif char == ')':
                    depth -= 1
                    current += char
                elif char == ',' and depth == 0:
                    args.append(current.strip())
                    current = ""
                else:
                    current += char
            else:
                current += char

        if current.strip():
            args.append(current.strip())

        return args

    def _split_by_operator(self, expr: str, operator: str) -> List[str]:
        """Split expression by operator, respecting parentheses and strings."""
        parts = []
        current = ""
        depth = 0
        in_string = False
        i = 0

        while i < len(expr):
            char = expr[i]

            if char in ("'", '"') and not in_string:
                in_string = True
                current += char
            elif char in ("'", '"') and in_string:
                in_string = False
                current += char
            elif not in_string:
                if char == '(':
                    depth += 1
                    current += char
                elif char == ')':
                    depth -= 1
                    current += char
                elif depth == 0 and expr[i:i+len(operator)] == operator:
                    parts.append(current)
                    current = ""
                    i += len(operator) - 1
                else:
                    current += char
            else:
                current += char

            i += 1

        if current:
            parts.append(current)

        return parts

    def _is_simple_field_reference(self, expr: str) -> bool:
        """Check if expression is a simple field reference."""
        expr = expr.strip()
        # Simple field name or table.field
        return bool(re.match(r'^[A-Za-z_][A-Za-z0-9_]*(\.[A-Za-z_][A-Za-z0-9_]*)?$', expr))

    def _is_field_reference(self, expr: str) -> bool:
        """Check if expression looks like a field reference."""
        expr = expr.strip()
        return bool(re.match(r'^[A-Za-z_][A-Za-z0-9_]*(\.[A-Za-z_][A-Za-z0-9_]*)?$', expr))

    def _is_literal(self, expr: str) -> bool:
        """Check if expression is a literal value."""
        expr = expr.strip()
        if expr.startswith("'") and expr.endswith("'"):
            return True
        if expr.upper() == "NULL":
            return True
        if re.match(r'^-?\d+\.?\d*$', expr):
            return True
        return False

    def _is_variable(self, expr: str) -> bool:
        """Check if expression is a variable reference."""
        return expr.strip().startswith('$')

    def _has_arithmetic(self, expr: str) -> bool:
        """Check if expression contains arithmetic operators."""
        # Simple check - more sophisticated would parse
        return any(op in expr for op in ['+', '-', '*', '/'])

    def _has_comparison(self, expr: str) -> bool:
        """Check if expression contains comparison operators."""
        return any(op in expr for op in ['>=', '<=', '!=', '<>', '=', '>', '<'])

    def _clean_field_name(self, field: str) -> str:
        """Clean up a field name for display."""
        field = field.strip()
        # Remove table prefix if simple
        if '.' in field:
            parts = field.split('.')
            if len(parts) == 2:
                return f"{parts[1]} (from {parts[0]})"
        return field

    def _clean_explanation(self, explanation: str) -> str:
        """Clean up the final explanation."""
        # Capitalize first letter
        if explanation:
            explanation = explanation[0].upper() + explanation[1:]

        # Remove extra spaces
        explanation = re.sub(r'\s+', ' ', explanation)

        # Clean up common patterns
        explanation = explanation.replace("field field", "field")

        return explanation.strip()

    def _basic_explain(self, expression: str) -> str:
        """Provide a basic explanation when parsing fails."""
        expr_lower = expression.lower()

        # Detect patterns
        patterns = []

        if 'iif(' in expr_lower:
            patterns.append("conditional logic")
        if 'nvl(' in expr_lower or 'isnull(' in expr_lower:
            patterns.append("null handling")
        if 'substr(' in expr_lower:
            patterns.append("substring extraction")
        if 'to_date(' in expr_lower:
            patterns.append("date conversion")
        if 'to_char(' in expr_lower:
            patterns.append("string conversion")
        if ':lkp.' in expr_lower:
            patterns.append("lookup reference")
        if '||' in expression:
            patterns.append("string concatenation")
        if 'upper(' in expr_lower or 'lower(' in expr_lower:
            patterns.append("case conversion")
        if 'trim(' in expr_lower or 'ltrim(' in expr_lower or 'rtrim(' in expr_lower:
            patterns.append("whitespace trimming")
        if 'decode(' in expr_lower:
            patterns.append("value decoding")
        if 'sum(' in expr_lower or 'avg(' in expr_lower or 'count(' in expr_lower:
            patterns.append("aggregation")

        if patterns:
            return f"Applies {', '.join(patterns)}"

        return f"Transformation: {expression[:100]}..." if len(expression) > 100 else f"Transformation: {expression}"


def explain_expression(expression: str, context: Optional[Dict] = None) -> str:
    """
    Convenience function to explain an expression.

    Args:
        expression: Informatica expression
        context: Optional context information

    Returns:
        English description
    """
    explainer = InformaticaExpressionExplainer()
    return explainer.explain(expression, context)


def explain_transformation_chain(chain: List[str]) -> str:
    """
    Explain a chain of transformations.

    Args:
        chain: List of transformation descriptions in format "TransformName: Expression"

    Returns:
        Combined English explanation
    """
    explainer = InformaticaExpressionExplainer()
    explanations = []

    for item in chain:
        # Parse "TransformName: Expression" format
        if ':' in item:
            parts = item.split(':', 1)
            transform_name = parts[0].strip()
            expression = parts[1].strip() if len(parts) > 1 else ""

            if expression:
                explanation = explainer.explain(expression)
                explanations.append(f"In {transform_name}: {explanation}")
            else:
                explanations.append(f"Passes through {transform_name}")
        else:
            explanation = explainer.explain(item)
            explanations.append(explanation)

    if not explanations:
        return "Direct field mapping"

    if len(explanations) == 1:
        return explanations[0]

    return " -> Then ".join(explanations)


def explain_transformation_chain_with_context(
    chain: List[str],
    intermediate_steps: Optional[List[Dict]] = None,
    sql_override: str = "",
    has_aggregation: bool = False,
    has_filter: bool = False,
    has_router: bool = False,
    router_condition: str = "",
    lookup_tables: Optional[List[str]] = None,
    union_details: Optional[Dict[str, Any]] = None,
) -> str:
    """
    Build a holistic transformation description with full context.

    Unlike ``explain_transformation_chain()``, this function weaves together
    the data path, operator context (SQL override, lookups, filters, routers,
    aggregation), and per-step expression explanations into a single
    coherent narrative.

    Args:
        chain: List of transformation descriptions ("TransformName: Expression").
        intermediate_steps: List of edge dicts with instance names/types.
        sql_override: SQL override text from the Source Qualifier.
        has_aggregation: Whether an Aggregator is in the path.
        has_filter: Whether a Filter is in the path.
        has_router: Whether a Router is in the path.
        router_condition: Router condition text.
        lookup_tables: List of lookup table names.

    Returns:
        A comprehensive English description of the transformation.
    """
    explainer = InformaticaExpressionExplainer()
    lookup_tables = lookup_tables or []
    intermediate_steps = intermediate_steps or []
    parts: List[str] = []

    # 1. Describe the data path through operators
    operator_types_seen = set()
    operator_path_names = []
    for step in intermediate_steps:
        if isinstance(step, dict):
            inst_name = step.get("source_instance", "") or step.get("target_instance", "")
            inst_type = step.get("source_type", "") or step.get("target_type", "")
        else:
            inst_name = getattr(step, "source_instance", "") or getattr(step, "target_instance", "")
            inst_type = getattr(step, "source_type", "") or getattr(step, "target_type", "")
        if inst_name and inst_name not in operator_path_names:
            operator_path_names.append(inst_name)
            if inst_type:
                operator_types_seen.add(inst_type.lower())

    if operator_path_names:
        parts.append(f"Data flows through: {' -> '.join(operator_path_names)}")

    # 2. SQL override context
    if sql_override:
        parts.append("Source data is read via custom SQL")

    # 3. Per-step expression explanations (skip direct copies)
    # Chain entries may contain inline annotations from integration_expert:
    #   - "(= BUILT-IN VARIABLE: ...)" for SESSSTARTTIME, SYSDATE, etc.
    #   - "(= SEQUENCE GENERATOR: ...)" for NEXTVAL/CURRVAL
    #   - Multi-line entries with "var : definition" prefix lines for local variables
    # We strip these before calling explain() and re-attach them after.
    _annotation_re = re.compile(
        r'\s*\(=\s*(BUILT-IN VARIABLE|SEQUENCE GENERATOR):[^)]*\)'
    )
    # Pattern to detect start of a variable definition line: "var_name : expression"
    _var_def_start_re = re.compile(r'^([A-Za-z_]\w*)\s*:\s+(.+)$')

    step_explanations = []
    for item in chain:
        # Handle multi-line entries with variable definitions at the top.
        # Format: "TRANS:\nvar1 : def1\nvar2 : def2\n\noutput_expr"
        # Double newline separates variable definitions from the output expression.
        if '\n\n' in item:
            header_and_vars, output_expr = item.split('\n\n', 1)
            output_expr = output_expr.strip()
            header_lines = header_and_vars.split('\n')
            # First line: "TRANS_NAME:"
            first_line = header_lines[0].strip()
            transform_name = first_line.rstrip(':').strip() if first_line.endswith(':') else first_line
            # Parse variable definitions (may span multiple lines each).
            # A new var def starts with "var_name : expr"; continuation lines
            # are everything else (indented, closing parens, etc.)
            var_defs = []
            cur_var = None
            cur_def_lines: list = []
            for line in header_lines[1:]:
                m = _var_def_start_re.match(line)
                if m:
                    if cur_var:
                        var_defs.append((cur_var, "\n".join(cur_def_lines).strip()))
                    cur_var = m.group(1)
                    cur_def_lines = [m.group(2)]
                elif cur_var:
                    cur_def_lines.append(line)
            if cur_var:
                var_defs.append((cur_var, "\n".join(cur_def_lines).strip()))
            # Strip inline annotations and explain the output expression
            annotation_strings = [m.group() for m in _annotation_re.finditer(output_expr)]
            clean_expression = _annotation_re.sub('', output_expr).strip()
            explanation = explainer.explain(clean_expression) if clean_expression else ""
            if annotation_strings:
                explanation = (explanation + " " + " ".join(
                    s.strip() for s in annotation_strings
                )).strip()
            # Append variable context: "where var1 = def1; var2 = def2"
            if var_defs:
                where_parts = [f"{vn} = {vd}" for vn, vd in var_defs]
                explanation = explanation + ", where " + "; ".join(where_parts)
            if explanation and "direct copy" not in explanation.lower():
                step_explanations.append(f"In {transform_name}: {explanation}")
            elif explanation:
                step_explanations.append(f"In {transform_name}: {explanation}")
            continue

        # Handle Union pass-through entries specially — don't feed them
        # to the expression explainer as they're not Informatica expressions.
        # Format: "Union: Union pass-through (OUTPUT_FIELD <- INPUT_FIELD)"
        _union_pt_match = re.match(
            r'^(.+?):\s*Union pass-through\s*\((\w+)\s*<-\s*(\w+)\)$', item
        )
        if _union_pt_match:
            _u_name = _union_pt_match.group(1).strip()
            _u_out = _union_pt_match.group(2)
            _u_in = _union_pt_match.group(3)
            step_explanations.append(
                f"In {_u_name}: Union pass-through ({_u_out} <- {_u_in})"
            )
            continue

        if ':' in item:
            transform_name, expression = item.split(':', 1)
            transform_name = transform_name.strip()
            expression = expression.strip()
            if expression:
                # Extract annotations and strip them for the explainer
                annotation_strings = [m.group() for m in _annotation_re.finditer(expression)]
                clean_expression = _annotation_re.sub('', expression).strip()
                explanation = explainer.explain(clean_expression) if clean_expression else ""
                # Re-attach annotations to the explanation
                if annotation_strings:
                    explanation = (explanation + " " + " ".join(
                        s.strip() for s in annotation_strings
                    )).strip()
                # Skip noise — only include when there's a real transformation
                if explanation and "direct copy" not in explanation.lower():
                    step_explanations.append(f"In {transform_name}: {explanation}")
                elif explanation and "direct copy" in explanation.lower() and annotation_strings:
                    # Direct copy but has annotations — still include
                    step_explanations.append(f"In {transform_name}: {explanation}")
        else:
            clean_item = _annotation_re.sub('', item).strip()
            annotation_strings = [m.group() for m in _annotation_re.finditer(item)]
            explanation = explainer.explain(clean_item) if clean_item else ""
            if annotation_strings:
                explanation = (explanation + " " + " ".join(
                    s.strip() for s in annotation_strings
                )).strip()
            if explanation and "direct copy" not in explanation.lower():
                step_explanations.append(explanation)
            elif explanation and "direct copy" in explanation.lower() and annotation_strings:
                step_explanations.append(explanation)

    if step_explanations:
        parts.append(" -> ".join(step_explanations))
    elif chain:
        # All chain items were direct copies — include the field name for clarity
        last_item = chain[-1]
        if ':' in last_item:
            field_name = last_item.split(':', 1)[1].strip()
        else:
            field_name = last_item.strip()
        if field_name:
            parts.append(f"Direct copy of field {field_name}")
        else:
            parts.append("Direct field mapping (no expression applied)")
    else:
        parts.append("Direct field mapping (no expression applied)")

    # 4. Operator context
    context_notes = []
    if has_aggregation:
        context_notes.append("data is aggregated (grouped)")
    if has_filter:
        context_notes.append("rows are filtered before reaching the target")
    if has_router:
        if router_condition:
            context_notes.append(f"data is routed via condition: {router_condition}")
        else:
            context_notes.append("data passes through a Router transformation")
    if lookup_tables:
        context_notes.append(f"enriched via lookup(s): {', '.join(lookup_tables)}")

    if context_notes:
        parts.append("Additionally, " + "; ".join(context_notes))

    if not parts:
        return "Direct field mapping - value copied without modification"

    return ". ".join(parts)
