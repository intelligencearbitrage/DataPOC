"""
Mapping AST (Abstract Syntax Tree) for Informatica PowerCenter.

This module provides an AST-like representation of Informatica mappings,
enabling structured traversal and analysis similar to how SQL ASTs work.

Key concepts:
- MappingAST: Root node representing a complete mapping
- TransformationNode: Node representing a transformation with fields and logic
- ConnectorEdge: Edge representing data flow between nodes
- LineageGraph: Graph representation for efficient traversal

The AST enables:
- Visitor pattern for transformation analysis
- Graph traversal for lineage extraction
- Pattern matching for complex transformation detection
- Circular dependency detection
"""

from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Optional, Set, Tuple, Iterator
from enum import Enum
from collections import deque
import logging

logger = logging.getLogger(__name__)


class NodeType(Enum):
    """Types of nodes in the mapping AST."""
    SOURCE = "source"
    TARGET = "target"
    SOURCE_QUALIFIER = "source_qualifier"
    EXPRESSION = "expression"
    FILTER = "filter"
    AGGREGATOR = "aggregator"
    LOOKUP = "lookup"
    JOINER = "joiner"
    ROUTER = "router"
    NORMALIZER = "normalizer"
    UPDATE_STRATEGY = "update_strategy"
    SEQUENCE = "sequence"
    SORTER = "sorter"
    UNION = "union"
    RANK = "rank"
    SQL_TRANSFORM = "sql_transform"
    STORED_PROCEDURE = "stored_procedure"
    CUSTOM = "custom"
    UNKNOWN = "unknown"

    @staticmethod
    def from_informatica_type(type_str: str) -> "NodeType":
        """Convert Informatica type string to NodeType."""
        type_map = {
            "source definition": NodeType.SOURCE,
            "target definition": NodeType.TARGET,
            "source qualifier": NodeType.SOURCE_QUALIFIER,
            "expression": NodeType.EXPRESSION,
            "filter": NodeType.FILTER,
            "aggregator": NodeType.AGGREGATOR,
            "lookup procedure": NodeType.LOOKUP,
            "joiner": NodeType.JOINER,
            "router": NodeType.ROUTER,
            "normalizer": NodeType.NORMALIZER,
            "update strategy": NodeType.UPDATE_STRATEGY,
            "sequence generator": NodeType.SEQUENCE,
            "sorter": NodeType.SORTER,
            "union": NodeType.UNION,
            "rank": NodeType.RANK,
            "sql transformation": NodeType.SQL_TRANSFORM,
            "stored procedure": NodeType.STORED_PROCEDURE,
            "custom transformation": NodeType.CUSTOM,
        }
        return type_map.get(type_str.lower(), NodeType.UNKNOWN)


@dataclass
class FieldNode:
    """
    Represents a field in a transformation.

    Similar to a variable in an AST, a field can be:
    - Input port (receiving data)
    - Output port (sending data)
    - Both (pass-through)
    """
    name: str
    datatype: str = ""
    precision: int = 0
    scale: int = 0
    expression: str = ""
    default_value: str = ""
    is_input: bool = False
    is_output: bool = False
    is_key: bool = False
    is_nullable: bool = True
    description: str = ""

    # References for lineage
    source_fields: List[str] = field(default_factory=list)
    target_fields: List[str] = field(default_factory=list)

    @property
    def port_type(self) -> str:
        """Get port type as string."""
        if self.is_input and self.is_output:
            return "INPUT/OUTPUT"
        elif self.is_input:
            return "INPUT"
        elif self.is_output:
            return "OUTPUT"
        return "UNKNOWN"

    @property
    def has_expression(self) -> bool:
        """Check if field has transformation expression."""
        return bool(self.expression and self.expression.strip())

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            "name": self.name,
            "datatype": self.datatype,
            "precision": self.precision,
            "scale": self.scale,
            "expression": self.expression,
            "port_type": self.port_type,
            "has_expression": self.has_expression,
        }


@dataclass
class TransformationNode:
    """
    AST node representing a transformation instance.

    This is analogous to an expression node in a SQL AST.
    It contains fields (ports) and transformation logic.
    """
    name: str
    transformation_name: str  # Original transformation definition name
    node_type: NodeType
    informatica_type: str  # Original Informatica type string
    fields: Dict[str, FieldNode] = field(default_factory=dict)
    attributes: Dict[str, str] = field(default_factory=dict)
    description: str = ""

    # Graph relationships (populated during AST building)
    incoming_edges: List["ConnectorEdge"] = field(default_factory=list)
    outgoing_edges: List["ConnectorEdge"] = field(default_factory=list)

    @property
    def is_source(self) -> bool:
        """Check if this is a source node."""
        return self.node_type in (NodeType.SOURCE, NodeType.SOURCE_QUALIFIER)

    @property
    def is_target(self) -> bool:
        """Check if this is a target node."""
        return self.node_type == NodeType.TARGET

    @property
    def is_transformation(self) -> bool:
        """Check if this is a transformation (not source/target)."""
        return not self.is_source and not self.is_target

    @property
    def input_fields(self) -> List[FieldNode]:
        """Get all input fields."""
        return [f for f in self.fields.values() if f.is_input]

    @property
    def output_fields(self) -> List[FieldNode]:
        """Get all output fields."""
        return [f for f in self.fields.values() if f.is_output]

    @property
    def expression_fields(self) -> List[FieldNode]:
        """Get fields with expressions."""
        return [f for f in self.fields.values() if f.has_expression]

    def get_field(self, name: str) -> Optional[FieldNode]:
        """Get field by name (case-insensitive)."""
        name_lower = name.lower()
        for fname, fnode in self.fields.items():
            if fname.lower() == name_lower:
                return fnode
        return None

    def add_field(self, field_node: FieldNode) -> None:
        """Add a field to this transformation."""
        self.fields[field_node.name] = field_node

    def get_upstream_nodes(self) -> List["TransformationNode"]:
        """Get all nodes that feed into this one."""
        return [edge.from_node for edge in self.incoming_edges if edge.from_node]

    def get_downstream_nodes(self) -> List["TransformationNode"]:
        """Get all nodes that this one feeds into."""
        return [edge.to_node for edge in self.outgoing_edges if edge.to_node]

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            "name": self.name,
            "transformation_name": self.transformation_name,
            "node_type": self.node_type.value,
            "informatica_type": self.informatica_type,
            "field_count": len(self.fields),
            "input_fields": len(self.input_fields),
            "output_fields": len(self.output_fields),
            "expression_fields": len(self.expression_fields),
            "incoming_connections": len(self.incoming_edges),
            "outgoing_connections": len(self.outgoing_edges),
        }


@dataclass
class ConnectorEdge:
    """
    Edge representing data flow between transformation nodes.

    Similar to an edge in a data flow graph or dependency in an AST.
    """
    from_instance: str
    from_field: str
    to_instance: str
    to_field: str
    from_instance_type: str = ""
    to_instance_type: str = ""

    # Node references (populated during AST building)
    from_node: Optional[TransformationNode] = None
    to_node: Optional[TransformationNode] = None

    @property
    def edge_id(self) -> str:
        """Unique identifier for this edge."""
        return f"{self.from_instance}.{self.from_field}->{self.to_instance}.{self.to_field}"

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            "from_instance": self.from_instance,
            "from_field": self.from_field,
            "to_instance": self.to_instance,
            "to_field": self.to_field,
            "from_instance_type": self.from_instance_type,
            "to_instance_type": self.to_instance_type,
        }


@dataclass
class MappingAST:
    """
    Abstract Syntax Tree for an Informatica mapping.

    This class provides a structured, traversable representation of a mapping,
    enabling:
    - Visitor pattern for analysis
    - Graph traversal for lineage
    - Pattern matching for complex transformations
    - Efficient queries using indexes

    Example:
        ast = MappingAST("m_MyMapping")
        ast.add_node(source_node)
        ast.add_node(expr_node)
        ast.add_edge(connector)
        ast.build()

        # Traverse from sources to targets
        for path in ast.trace_all_paths():
            print(path)

        # Find all expressions
        for node in ast.find_nodes_by_type(NodeType.EXPRESSION):
            print(node.expression_fields)
    """
    mapping_name: str
    nodes: Dict[str, TransformationNode] = field(default_factory=dict)
    edges: List[ConnectorEdge] = field(default_factory=list)
    variables: Dict[str, Any] = field(default_factory=dict)
    description: str = ""

    # Indexes for efficient querying (built in build() method)
    _source_nodes: List[TransformationNode] = field(default_factory=list)
    _target_nodes: List[TransformationNode] = field(default_factory=list)
    _nodes_by_type: Dict[NodeType, List[TransformationNode]] = field(default_factory=dict)
    _edges_by_to: Dict[str, List[ConnectorEdge]] = field(default_factory=dict)
    _edges_by_from: Dict[str, List[ConnectorEdge]] = field(default_factory=dict)
    _built: bool = False

    def add_node(self, node: TransformationNode) -> None:
        """Add a transformation node to the AST."""
        self.nodes[node.name.lower()] = node
        self._built = False

    def add_edge(self, edge: ConnectorEdge) -> None:
        """Add a connector edge to the AST."""
        self.edges.append(edge)
        self._built = False

    def get_node(self, name: str) -> Optional[TransformationNode]:
        """Get node by name (case-insensitive)."""
        return self.nodes.get(name.lower())

    def build(self) -> None:
        """
        Build indexes and resolve references.

        Call this after adding all nodes and edges.
        """
        if self._built:
            return

        # Build node indexes
        self._source_nodes = []
        self._target_nodes = []
        self._nodes_by_type = {}

        for node in self.nodes.values():
            if node.is_source:
                self._source_nodes.append(node)
            elif node.is_target:
                self._target_nodes.append(node)

            if node.node_type not in self._nodes_by_type:
                self._nodes_by_type[node.node_type] = []
            self._nodes_by_type[node.node_type].append(node)

        # Build edge indexes
        self._edges_by_to = {}
        self._edges_by_from = {}

        for edge in self.edges:
            # Index by to_instance
            to_key = edge.to_instance.lower()
            if to_key not in self._edges_by_to:
                self._edges_by_to[to_key] = []
            self._edges_by_to[to_key].append(edge)

            # Index by from_instance
            from_key = edge.from_instance.lower()
            if from_key not in self._edges_by_from:
                self._edges_by_from[from_key] = []
            self._edges_by_from[from_key].append(edge)

            # Resolve node references
            edge.from_node = self.get_node(edge.from_instance)
            edge.to_node = self.get_node(edge.to_instance)

            # Update node edge lists
            if edge.from_node:
                edge.from_node.outgoing_edges.append(edge)
            if edge.to_node:
                edge.to_node.incoming_edges.append(edge)

        self._built = True

    # =========================================================================
    # Query Methods
    # =========================================================================

    @property
    def source_nodes(self) -> List[TransformationNode]:
        """Get all source nodes."""
        if not self._built:
            self.build()
        return self._source_nodes

    @property
    def target_nodes(self) -> List[TransformationNode]:
        """Get all target nodes."""
        if not self._built:
            self.build()
        return self._target_nodes

    def find_nodes_by_type(self, node_type: NodeType) -> List[TransformationNode]:
        """Find all nodes of a specific type."""
        if not self._built:
            self.build()
        return self._nodes_by_type.get(node_type, [])

    def get_edges_to(self, instance_name: str) -> List[ConnectorEdge]:
        """Get all edges pointing to an instance."""
        if not self._built:
            self.build()
        return self._edges_by_to.get(instance_name.lower(), [])

    def get_edges_from(self, instance_name: str) -> List[ConnectorEdge]:
        """Get all edges originating from an instance."""
        if not self._built:
            self.build()
        return self._edges_by_from.get(instance_name.lower(), [])

    # =========================================================================
    # Lineage Traversal Methods
    # =========================================================================

    def trace_field_backward(
        self,
        instance: str,
        field_name: str,
        visited: Optional[Set[str]] = None
    ) -> List[List[ConnectorEdge]]:
        """
        Trace a field backward to its sources.

        Returns all paths from the field to source fields.
        """
        if not self._built:
            self.build()

        if visited is None:
            visited = set()

        key = f"{instance.lower()}.{field_name.lower()}"
        if key in visited:
            return []  # Avoid cycles
        visited.add(key)

        paths = []
        edges = self.get_edges_to(instance)

        for edge in edges:
            if edge.to_field.lower() == field_name.lower():
                # Check if we've reached a source
                if edge.from_node and edge.from_node.is_source:
                    paths.append([edge])
                else:
                    # Continue tracing backward
                    upstream_paths = self.trace_field_backward(
                        edge.from_instance,
                        edge.from_field,
                        visited.copy()
                    )
                    for path in upstream_paths:
                        paths.append([edge] + path)

        return paths

    def trace_field_forward(
        self,
        instance: str,
        field_name: str,
        visited: Optional[Set[str]] = None
    ) -> List[List[ConnectorEdge]]:
        """
        Trace a field forward to its targets.

        Returns all paths from the field to target fields.
        """
        if not self._built:
            self.build()

        if visited is None:
            visited = set()

        key = f"{instance.lower()}.{field_name.lower()}"
        if key in visited:
            return []
        visited.add(key)

        paths = []
        edges = self.get_edges_from(instance)

        for edge in edges:
            if edge.from_field.lower() == field_name.lower():
                if edge.to_node and edge.to_node.is_target:
                    paths.append([edge])
                else:
                    downstream_paths = self.trace_field_forward(
                        edge.to_instance,
                        edge.to_field,
                        visited.copy()
                    )
                    for path in downstream_paths:
                        paths.append([edge] + path)

        return paths

    def get_all_source_to_target_paths(self) -> List[Dict[str, Any]]:
        """
        Get all paths from sources to targets.

        Returns list of dictionaries with path information.
        """
        if not self._built:
            self.build()

        all_paths = []

        for target_node in self._target_nodes:
            for field_name, field_node in target_node.fields.items():
                if field_node.is_input:  # Target fields receive data
                    paths = self.trace_field_backward(target_node.name, field_name)
                    for path in paths:
                        if path:
                            source_edge = path[-1]  # Last edge in backward path
                            all_paths.append({
                                "target_instance": target_node.name,
                                "target_field": field_name,
                                "source_instance": source_edge.from_instance,
                                "source_field": source_edge.from_field,
                                "path": [e.edge_id for e in path],
                                "hop_count": len(path),
                            })

        return all_paths

    # =========================================================================
    # Analysis Methods
    # =========================================================================

    def find_unmapped_target_fields(self) -> List[Dict[str, str]]:
        """Find target fields with no incoming edges."""
        if not self._built:
            self.build()

        unmapped = []
        for target_node in self._target_nodes:
            # Get all edges to this target
            target_edges = self.get_edges_to(target_node.name)
            mapped_fields = {e.to_field.lower() for e in target_edges}

            for field_name, field_node in target_node.fields.items():
                if field_name.lower() not in mapped_fields:
                    unmapped.append({
                        "target": target_node.transformation_name,
                        "instance": target_node.name,
                        "field": field_name,
                        "datatype": field_node.datatype,
                    })

        return unmapped

    def find_expression_chains(self) -> List[List[TransformationNode]]:
        """Find chains of expression transformations."""
        if not self._built:
            self.build()

        expr_nodes = self.find_nodes_by_type(NodeType.EXPRESSION)
        chains = []

        for node in expr_nodes:
            chain = [node]
            current = node

            # Follow downstream expression nodes
            while True:
                downstream = current.get_downstream_nodes()
                expr_downstream = [n for n in downstream if n.node_type == NodeType.EXPRESSION]
                if expr_downstream:
                    next_node = expr_downstream[0]
                    if next_node not in chain:  # Avoid cycles
                        chain.append(next_node)
                        current = next_node
                    else:
                        break
                else:
                    break

            if len(chain) > 1:
                chains.append(chain)

        return chains

    def detect_cycles(self) -> List[List[str]]:
        """
        Detect cycles in the mapping.

        Returns list of cycles (each cycle is a list of instance names).
        """
        if not self._built:
            self.build()

        cycles = []
        visited = set()
        rec_stack = set()

        def dfs(node_name: str, path: List[str]) -> None:
            visited.add(node_name)
            rec_stack.add(node_name)
            path.append(node_name)

            for edge in self.get_edges_from(node_name):
                next_name = edge.to_instance.lower()

                if next_name in rec_stack:
                    # Found cycle
                    cycle_start = path.index(next_name)
                    cycles.append(path[cycle_start:] + [next_name])
                elif next_name not in visited:
                    dfs(next_name, path.copy())

            rec_stack.remove(node_name)

        for node_name in self.nodes:
            if node_name not in visited:
                dfs(node_name, [])

        return cycles

    def get_execution_order(self) -> List[str]:
        """
        Get topological order of nodes.

        Returns list of instance names in execution order.
        """
        if not self._built:
            self.build()

        in_degree: Dict[str, int] = {name: 0 for name in self.nodes}
        for edge in self.edges:
            to_key = edge.to_instance.lower()
            if to_key in in_degree:
                in_degree[to_key] += 1

        queue = deque([name for name, degree in in_degree.items() if degree == 0])
        result = []

        while queue:
            node_name = queue.popleft()
            result.append(node_name)

            for edge in self.get_edges_from(node_name):
                to_key = edge.to_instance.lower()
                if to_key in in_degree:
                    in_degree[to_key] -= 1
                    if in_degree[to_key] == 0:
                        queue.append(to_key)

        return result

    def get_statistics(self) -> Dict[str, Any]:
        """Get comprehensive statistics about the mapping."""
        if not self._built:
            self.build()

        node_type_counts = {}
        for node_type, nodes in self._nodes_by_type.items():
            node_type_counts[node_type.value] = len(nodes)

        total_fields = sum(len(node.fields) for node in self.nodes.values())
        total_expressions = sum(
            len(node.expression_fields) for node in self.nodes.values()
        )

        return {
            "mapping_name": self.mapping_name,
            "node_count": len(self.nodes),
            "edge_count": len(self.edges),
            "source_count": len(self._source_nodes),
            "target_count": len(self._target_nodes),
            "node_types": node_type_counts,
            "total_fields": total_fields,
            "total_expressions": total_expressions,
            "unmapped_target_fields": len(self.find_unmapped_target_fields()),
            "has_cycles": len(self.detect_cycles()) > 0,
        }

    # =========================================================================
    # Visitor Pattern Support
    # =========================================================================

    def accept(self, visitor: "ASTVisitor") -> Any:
        """Accept a visitor for traversal."""
        return visitor.visit_mapping(self)

    def traverse_breadth_first(self) -> Iterator[TransformationNode]:
        """Traverse nodes in breadth-first order from sources."""
        if not self._built:
            self.build()

        visited = set()
        queue = deque(self._source_nodes)

        while queue:
            node = queue.popleft()
            if node.name.lower() in visited:
                continue
            visited.add(node.name.lower())
            yield node

            for downstream in node.get_downstream_nodes():
                if downstream.name.lower() not in visited:
                    queue.append(downstream)

    def traverse_depth_first(
        self,
        start_node: Optional[TransformationNode] = None
    ) -> Iterator[TransformationNode]:
        """Traverse nodes in depth-first order."""
        if not self._built:
            self.build()

        visited = set()
        start_nodes = [start_node] if start_node else self._source_nodes

        def dfs(node: TransformationNode) -> Iterator[TransformationNode]:
            if node.name.lower() in visited:
                return
            visited.add(node.name.lower())
            yield node

            for downstream in node.get_downstream_nodes():
                yield from dfs(downstream)

        for start in start_nodes:
            yield from dfs(start)

    def to_dict(self) -> Dict[str, Any]:
        """Convert AST to dictionary representation."""
        return {
            "mapping_name": self.mapping_name,
            "description": self.description,
            "nodes": {name: node.to_dict() for name, node in self.nodes.items()},
            "edges": [edge.to_dict() for edge in self.edges],
            "statistics": self.get_statistics(),
        }


class ASTVisitor:
    """
    Base visitor class for AST traversal.

    Subclass this to implement custom analysis.

    Example:
        class ExpressionAnalyzer(ASTVisitor):
            def visit_expression(self, node):
                for field in node.expression_fields:
                    self.analyze_expression(field.expression)
    """

    def visit_mapping(self, ast: MappingAST) -> Any:
        """Visit the mapping root."""
        for node in ast.nodes.values():
            self.visit_node(node)
        return None

    def visit_node(self, node: TransformationNode) -> Any:
        """Visit a transformation node. Override in subclass."""
        method_name = f"visit_{node.node_type.value}"
        visitor_method = getattr(self, method_name, self.generic_visit)
        return visitor_method(node)

    def generic_visit(self, node: TransformationNode) -> Any:
        """Default visitor for unhandled node types."""
        pass

    def visit_source(self, node: TransformationNode) -> Any:
        """Visit source node."""
        return self.generic_visit(node)

    def visit_target(self, node: TransformationNode) -> Any:
        """Visit target node."""
        return self.generic_visit(node)

    def visit_expression(self, node: TransformationNode) -> Any:
        """Visit expression node."""
        return self.generic_visit(node)

    def visit_filter(self, node: TransformationNode) -> Any:
        """Visit filter node."""
        return self.generic_visit(node)

    def visit_aggregator(self, node: TransformationNode) -> Any:
        """Visit aggregator node."""
        return self.generic_visit(node)

    def visit_lookup(self, node: TransformationNode) -> Any:
        """Visit lookup node."""
        return self.generic_visit(node)

    def visit_joiner(self, node: TransformationNode) -> Any:
        """Visit joiner node."""
        return self.generic_visit(node)


class ExpressionCollector(ASTVisitor):
    """Visitor that collects all expressions from a mapping."""

    def __init__(self):
        self.expressions: List[Dict[str, Any]] = []

    def visit_node(self, node: TransformationNode) -> None:
        for field in node.expression_fields:
            self.expressions.append({
                "node": node.name,
                "node_type": node.node_type.value,
                "field": field.name,
                "expression": field.expression,
                "datatype": field.datatype,
            })


class LineageCollector(ASTVisitor):
    """Visitor that collects lineage information."""

    def __init__(self):
        self.lineage_paths: List[Dict[str, Any]] = []

    def visit_target(self, node: TransformationNode) -> None:
        """For each target field, trace back to sources."""
        ast = node  # We need access to the full AST
        # This visitor would need the AST reference passed in
        pass


class TransformationCounter(ASTVisitor):
    """Visitor that counts transformations by type."""

    def __init__(self):
        self.counts: Dict[str, int] = {}

    def visit_node(self, node: TransformationNode) -> None:
        type_name = node.node_type.value
        self.counts[type_name] = self.counts.get(type_name, 0) + 1


# =============================================================================
# Phase 3: Advanced Graph Analysis
# =============================================================================

@dataclass
class StronglyConnectedComponent:
    """Represents a strongly connected component in the mapping graph."""
    nodes: List[str]
    is_cycle: bool
    entry_points: List[str] = field(default_factory=list)
    exit_points: List[str] = field(default_factory=list)

    @property
    def size(self) -> int:
        return len(self.nodes)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "nodes": self.nodes,
            "is_cycle": self.is_cycle,
            "size": self.size,
            "entry_points": self.entry_points,
            "exit_points": self.exit_points,
        }


@dataclass
class CriticalPath:
    """Represents a critical path in the transformation graph."""
    nodes: List[str]
    total_complexity: int
    bottleneck_node: str
    bottleneck_type: str

    def to_dict(self) -> Dict[str, Any]:
        return {
            "nodes": self.nodes,
            "length": len(self.nodes),
            "total_complexity": self.total_complexity,
            "bottleneck_node": self.bottleneck_node,
            "bottleneck_type": self.bottleneck_type,
        }


@dataclass
class DependencyInfo:
    """Information about a node's dependencies."""
    node_name: str
    direct_dependencies: List[str]
    transitive_dependencies: List[str]
    direct_dependents: List[str]
    transitive_dependents: List[str]
    depth_from_source: int
    depth_to_target: int

    def to_dict(self) -> Dict[str, Any]:
        return {
            "node_name": self.node_name,
            "direct_dependencies": self.direct_dependencies,
            "direct_dependency_count": len(self.direct_dependencies),
            "transitive_dependencies": self.transitive_dependencies,
            "transitive_dependency_count": len(self.transitive_dependencies),
            "direct_dependents": self.direct_dependents,
            "direct_dependent_count": len(self.direct_dependents),
            "transitive_dependents": self.transitive_dependents,
            "transitive_dependent_count": len(self.transitive_dependents),
            "depth_from_source": self.depth_from_source,
            "depth_to_target": self.depth_to_target,
        }


class AdvancedGraphAnalyzer:
    """
    Advanced graph analysis algorithms for Informatica mappings.

    Provides:
    - Tarjan's algorithm for finding SCCs
    - Johnson's algorithm for finding all elementary cycles
    - Critical path analysis
    - Dependency analysis with transitive closure
    - Bottleneck detection
    """

    def __init__(self, ast: MappingAST):
        """Initialize with a MappingAST."""
        self.ast = ast
        if not ast._built:
            ast.build()

        # Build adjacency lists
        self._adj: Dict[str, List[str]] = {}
        self._reverse_adj: Dict[str, List[str]] = {}

        for node_name in ast.nodes:
            self._adj[node_name] = []
            self._reverse_adj[node_name] = []

        for edge in ast.edges:
            from_key = edge.from_instance.lower()
            to_key = edge.to_instance.lower()
            if from_key in self._adj and to_key in self._adj:
                if to_key not in self._adj[from_key]:
                    self._adj[from_key].append(to_key)
                if from_key not in self._reverse_adj[to_key]:
                    self._reverse_adj[to_key].append(from_key)

    # =========================================================================
    # Tarjan's Algorithm for Strongly Connected Components
    # =========================================================================

    def find_strongly_connected_components(self) -> List[StronglyConnectedComponent]:
        """
        Find all strongly connected components using Tarjan's algorithm.

        Returns list of SCCs. An SCC with more than one node indicates a cycle.
        """
        index_counter = [0]
        stack = []
        lowlinks: Dict[str, int] = {}
        index: Dict[str, int] = {}
        on_stack: Dict[str, bool] = {}
        sccs: List[List[str]] = []

        def strongconnect(node: str) -> None:
            index[node] = index_counter[0]
            lowlinks[node] = index_counter[0]
            index_counter[0] += 1
            stack.append(node)
            on_stack[node] = True

            for successor in self._adj.get(node, []):
                if successor not in index:
                    strongconnect(successor)
                    lowlinks[node] = min(lowlinks[node], lowlinks[successor])
                elif on_stack.get(successor, False):
                    lowlinks[node] = min(lowlinks[node], index[successor])

            # If node is a root node, pop the stack and generate an SCC
            if lowlinks[node] == index[node]:
                scc = []
                while True:
                    w = stack.pop()
                    on_stack[w] = False
                    scc.append(w)
                    if w == node:
                        break
                sccs.append(scc)

        for node in self.ast.nodes:
            if node not in index:
                strongconnect(node)

        # Convert to StronglyConnectedComponent objects
        result = []
        for scc_nodes in sccs:
            is_cycle = len(scc_nodes) > 1 or self._has_self_loop(scc_nodes[0])
            entry_points = self._find_scc_entry_points(scc_nodes)
            exit_points = self._find_scc_exit_points(scc_nodes)

            result.append(StronglyConnectedComponent(
                nodes=scc_nodes,
                is_cycle=is_cycle,
                entry_points=entry_points,
                exit_points=exit_points,
            ))

        return result

    def _has_self_loop(self, node: str) -> bool:
        """Check if a node has a self-loop."""
        return node in self._adj.get(node, [])

    def _find_scc_entry_points(self, scc_nodes: List[str]) -> List[str]:
        """Find nodes in SCC that have incoming edges from outside."""
        scc_set = set(scc_nodes)
        entry_points = []
        for node in scc_nodes:
            for predecessor in self._reverse_adj.get(node, []):
                if predecessor not in scc_set:
                    entry_points.append(node)
                    break
        return entry_points

    def _find_scc_exit_points(self, scc_nodes: List[str]) -> List[str]:
        """Find nodes in SCC that have outgoing edges to outside."""
        scc_set = set(scc_nodes)
        exit_points = []
        for node in scc_nodes:
            for successor in self._adj.get(node, []):
                if successor not in scc_set:
                    exit_points.append(node)
                    break
        return exit_points

    # =========================================================================
    # Johnson's Algorithm for All Elementary Cycles
    # =========================================================================

    def find_all_elementary_cycles(self) -> List[List[str]]:
        """
        Find all elementary cycles using Johnson's algorithm.

        This is more comprehensive than simple DFS cycle detection.
        """
        cycles = []
        blocked = set()
        blocked_map: Dict[str, Set[str]] = {node: set() for node in self.ast.nodes}
        stack = []

        # Get nodes in order
        nodes = list(self.ast.nodes.keys())

        def unblock(node: str) -> None:
            blocked.discard(node)
            for w in list(blocked_map[node]):
                blocked_map[node].discard(w)
                if w in blocked:
                    unblock(w)

        def circuit(node: str, start: str, subgraph_adj: Dict[str, List[str]]) -> bool:
            found_cycle = False
            stack.append(node)
            blocked.add(node)

            for successor in subgraph_adj.get(node, []):
                if successor == start:
                    cycles.append(list(stack) + [start])
                    found_cycle = True
                elif successor not in blocked:
                    if circuit(successor, start, subgraph_adj):
                        found_cycle = True

            if found_cycle:
                unblock(node)
            else:
                for successor in subgraph_adj.get(node, []):
                    blocked_map[successor].add(node)

            stack.pop()
            return found_cycle

        # Find cycles starting from each node
        for i, start_node in enumerate(nodes):
            # Build subgraph with only nodes >= start_node (by index)
            subgraph_nodes = set(nodes[i:])
            subgraph_adj: Dict[str, List[str]] = {}
            for node in subgraph_nodes:
                subgraph_adj[node] = [n for n in self._adj.get(node, []) if n in subgraph_nodes]

            blocked.clear()
            for node in self.ast.nodes:
                blocked_map[node].clear()

            circuit(start_node, start_node, subgraph_adj)

        return cycles

    # =========================================================================
    # Critical Path Analysis
    # =========================================================================

    def find_critical_paths(self, complexity_weights: Optional[Dict[str, int]] = None) -> List[CriticalPath]:
        """
        Find critical paths (longest paths) in the transformation graph.

        Args:
            complexity_weights: Optional weights for node types

        Returns:
            List of critical paths
        """
        if complexity_weights is None:
            complexity_weights = self._default_complexity_weights()

        # Calculate longest path from each source
        critical_paths = []

        for source_node in self.ast.source_nodes:
            path, complexity = self._find_longest_path_from(
                source_node.name.lower(),
                complexity_weights
            )
            if path:
                bottleneck_node, bottleneck_type = self._find_bottleneck(path, complexity_weights)
                critical_paths.append(CriticalPath(
                    nodes=path,
                    total_complexity=complexity,
                    bottleneck_node=bottleneck_node,
                    bottleneck_type=bottleneck_type,
                ))

        # Sort by complexity (longest first)
        critical_paths.sort(key=lambda p: p.total_complexity, reverse=True)
        return critical_paths

    def _default_complexity_weights(self) -> Dict[str, int]:
        """Default complexity weights for different transformation types."""
        return {
            NodeType.SOURCE.value: 1,
            NodeType.SOURCE_QUALIFIER.value: 2,
            NodeType.TARGET.value: 1,
            NodeType.EXPRESSION.value: 3,
            NodeType.FILTER.value: 2,
            NodeType.AGGREGATOR.value: 5,
            NodeType.LOOKUP.value: 4,
            NodeType.JOINER.value: 5,
            NodeType.ROUTER.value: 3,
            NodeType.NORMALIZER.value: 4,
            NodeType.UPDATE_STRATEGY.value: 2,
            NodeType.SORTER.value: 4,
            NodeType.UNION.value: 3,
            NodeType.RANK.value: 4,
            NodeType.SQL_TRANSFORM.value: 5,
            NodeType.STORED_PROCEDURE.value: 5,
            NodeType.UNKNOWN.value: 2,
        }

    def _find_longest_path_from(
        self,
        start: str,
        weights: Dict[str, int]
    ) -> Tuple[List[str], int]:
        """Find the longest weighted path from a starting node."""
        dist: Dict[str, int] = {start: 0}
        parent: Dict[str, Optional[str]] = {start: None}
        visited = set()
        queue = deque([start])

        # Process nodes in BFS order but keep track of longest distance
        while queue:
            node = queue.popleft()
            if node in visited:
                continue
            visited.add(node)

            node_obj = self.ast.get_node(node)
            node_weight = weights.get(
                node_obj.node_type.value if node_obj else NodeType.UNKNOWN.value,
                2
            )

            for successor in self._adj.get(node, []):
                new_dist = dist[node] + node_weight
                if successor not in dist or new_dist > dist[successor]:
                    dist[successor] = new_dist
                    parent[successor] = node
                if successor not in visited:
                    queue.append(successor)

        # Find the farthest target node
        max_dist = -1
        end_node = None
        for target in self.ast.target_nodes:
            target_name = target.name.lower()
            if target_name in dist and dist[target_name] > max_dist:
                max_dist = dist[target_name]
                end_node = target_name

        if end_node is None:
            return [], 0

        # Reconstruct path
        path = []
        current = end_node
        while current is not None:
            path.append(current)
            current = parent.get(current)
        path.reverse()

        return path, max_dist

    def _find_bottleneck(
        self,
        path: List[str],
        weights: Dict[str, int]
    ) -> Tuple[str, str]:
        """Find the bottleneck (highest complexity) node in a path."""
        max_weight = -1
        bottleneck_node = ""
        bottleneck_type = ""

        for node_name in path:
            node_obj = self.ast.get_node(node_name)
            if node_obj:
                node_type = node_obj.node_type.value
                weight = weights.get(node_type, 2)
                if weight > max_weight:
                    max_weight = weight
                    bottleneck_node = node_name
                    bottleneck_type = node_type

        return bottleneck_node, bottleneck_type

    # =========================================================================
    # Dependency Analysis
    # =========================================================================

    def get_dependency_info(self, node_name: str) -> DependencyInfo:
        """Get comprehensive dependency information for a node."""
        node_key = node_name.lower()

        # Direct dependencies (predecessors)
        direct_deps = list(self._reverse_adj.get(node_key, []))

        # Transitive dependencies (all ancestors)
        transitive_deps = self._get_transitive_closure(node_key, reverse=True)

        # Direct dependents (successors)
        direct_dependents = list(self._adj.get(node_key, []))

        # Transitive dependents (all descendants)
        transitive_dependents = self._get_transitive_closure(node_key, reverse=False)

        # Depth from source
        depth_from_source = self._calculate_depth_from_source(node_key)

        # Depth to target
        depth_to_target = self._calculate_depth_to_target(node_key)

        return DependencyInfo(
            node_name=node_name,
            direct_dependencies=direct_deps,
            transitive_dependencies=list(transitive_deps),
            direct_dependents=direct_dependents,
            transitive_dependents=list(transitive_dependents),
            depth_from_source=depth_from_source,
            depth_to_target=depth_to_target,
        )

    def _get_transitive_closure(self, node: str, reverse: bool = False) -> Set[str]:
        """Get transitive closure of dependencies or dependents."""
        adj = self._reverse_adj if reverse else self._adj
        visited = set()
        queue = deque([node])

        while queue:
            current = queue.popleft()
            for neighbor in adj.get(current, []):
                if neighbor not in visited:
                    visited.add(neighbor)
                    queue.append(neighbor)

        return visited

    def _calculate_depth_from_source(self, node: str) -> int:
        """Calculate shortest path distance from any source."""
        # BFS from all sources
        visited = set()
        queue = deque()

        for source in self.ast.source_nodes:
            source_key = source.name.lower()
            queue.append((source_key, 0))
            visited.add(source_key)

        while queue:
            current, depth = queue.popleft()
            if current == node:
                return depth

            for successor in self._adj.get(current, []):
                if successor not in visited:
                    visited.add(successor)
                    queue.append((successor, depth + 1))

        return -1  # Not reachable from any source

    def _calculate_depth_to_target(self, node: str) -> int:
        """Calculate shortest path distance to any target."""
        # BFS from node
        visited = set()
        queue = deque([(node, 0)])
        visited.add(node)
        target_names = {t.name.lower() for t in self.ast.target_nodes}

        while queue:
            current, depth = queue.popleft()
            if current in target_names:
                return depth

            for successor in self._adj.get(current, []):
                if successor not in visited:
                    visited.add(successor)
                    queue.append((successor, depth + 1))

        return -1  # No target reachable

    # =========================================================================
    # Graph Metrics
    # =========================================================================

    def calculate_graph_metrics(self) -> Dict[str, Any]:
        """Calculate comprehensive graph metrics."""
        # Find SCCs
        sccs = self.find_strongly_connected_components()
        cyclic_sccs = [scc for scc in sccs if scc.is_cycle]

        # Calculate fan-in/fan-out
        max_fan_in = 0
        max_fan_out = 0
        max_fan_in_node = ""
        max_fan_out_node = ""

        for node in self.ast.nodes:
            fan_in = len(self._reverse_adj.get(node, []))
            fan_out = len(self._adj.get(node, []))

            if fan_in > max_fan_in:
                max_fan_in = fan_in
                max_fan_in_node = node
            if fan_out > max_fan_out:
                max_fan_out = fan_out
                max_fan_out_node = node

        # Critical paths
        critical_paths = self.find_critical_paths()

        # Calculate connectivity
        weakly_connected = self._is_weakly_connected()

        return {
            "node_count": len(self.ast.nodes),
            "edge_count": len(self.ast.edges),
            "scc_count": len(sccs),
            "cyclic_scc_count": len(cyclic_sccs),
            "has_cycles": len(cyclic_sccs) > 0,
            "max_fan_in": max_fan_in,
            "max_fan_in_node": max_fan_in_node,
            "max_fan_out": max_fan_out,
            "max_fan_out_node": max_fan_out_node,
            "critical_path_length": critical_paths[0].total_complexity if critical_paths else 0,
            "critical_path_nodes": critical_paths[0].nodes if critical_paths else [],
            "is_weakly_connected": weakly_connected,
        }

    def _is_weakly_connected(self) -> bool:
        """Check if the graph is weakly connected."""
        if not self.ast.nodes:
            return True

        # Build undirected adjacency
        undirected_adj: Dict[str, Set[str]] = {node: set() for node in self.ast.nodes}
        for node in self.ast.nodes:
            for neighbor in self._adj.get(node, []):
                undirected_adj[node].add(neighbor)
                undirected_adj[neighbor].add(node)

        # BFS from first node
        start = next(iter(self.ast.nodes))
        visited = set()
        queue = deque([start])

        while queue:
            current = queue.popleft()
            if current in visited:
                continue
            visited.add(current)
            for neighbor in undirected_adj.get(current, set()):
                if neighbor not in visited:
                    queue.append(neighbor)

        return len(visited) == len(self.ast.nodes)
