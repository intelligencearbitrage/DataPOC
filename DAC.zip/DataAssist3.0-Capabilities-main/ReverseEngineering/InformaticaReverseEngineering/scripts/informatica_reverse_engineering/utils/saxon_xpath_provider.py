"""
Saxon XPath Provider for XPath 2.0/3.0/3.1 Support.

This module provides enhanced XPath capabilities using Saxon-HE (Home Edition)
via the saxonche Python API. Saxon enables:

- XPath 2.0/3.0/3.1 functions (tokenize, matches, replace, etc.)
- Advanced string manipulation
- Date/time handling functions
- Regular expression support with full XPath regex syntax
- Improved type system and type conversions
- Sequence operations

When saxonche is not available, the system falls back to lxml's XPath 1.0.

Installation:
    pip install saxonche

Note: saxonche requires Python 3.8+ and includes the Saxon-HE processor.
"""

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Union, Callable
from pathlib import Path
from enum import Enum
import logging
import re

# Try to import lxml (always available as fallback)
from lxml import etree

# Try to import saxonche (optional)
try:
    import saxonche
    from saxonche import PySaxonProcessor, PyXdmValue, PyXdmNode, PyXdmAtomicValue
    SAXON_AVAILABLE = True
except ImportError:
    SAXON_AVAILABLE = False
    PySaxonProcessor = None
    PyXdmValue = None
    PyXdmNode = None
    PyXdmAtomicValue = None

logger = logging.getLogger(__name__)


class XPathVersion(Enum):
    """Supported XPath versions."""
    XPATH_1_0 = "1.0"
    XPATH_2_0 = "2.0"
    XPATH_3_0 = "3.0"
    XPATH_3_1 = "3.1"


@dataclass
class XPathQueryResult:
    """
    Result of an XPath query with metadata.

    Supports both lxml elements and Saxon XDM values.
    """
    values: List[Any]
    query: str
    count: int
    xpath_version: XPathVersion
    provider: str  # "saxon" or "lxml"

    def __iter__(self):
        return iter(self.values)

    def __len__(self):
        return self.count

    def first(self) -> Optional[Any]:
        """Get first result or None."""
        return self.values[0] if self.values else None

    def as_strings(self) -> List[str]:
        """Convert all values to strings."""
        result = []
        for val in self.values:
            if hasattr(val, 'get'):
                # lxml element - get string value
                result.append(val.text or "")
            elif hasattr(val, 'string_value'):
                # Saxon XdmValue
                result.append(val.string_value)
            else:
                result.append(str(val))
        return result

    def as_elements(self) -> List[etree._Element]:
        """Get only element results (lxml fallback mode)."""
        return [v for v in self.values if isinstance(v, etree._Element)]


class XPathProvider(ABC):
    """Abstract base class for XPath providers."""

    @abstractmethod
    def get_version(self) -> XPathVersion:
        """Get the XPath version supported by this provider."""
        pass

    @abstractmethod
    def query(self, xpath: str, context: Optional[Any] = None) -> XPathQueryResult:
        """Execute an XPath query."""
        pass

    @abstractmethod
    def query_single(self, xpath: str, context: Optional[Any] = None) -> Optional[Any]:
        """Execute an XPath query and return single result."""
        pass

    @abstractmethod
    def load_document(self, file_path: Union[str, Path]) -> Any:
        """Load an XML document."""
        pass

    @abstractmethod
    def load_string(self, xml_string: str) -> Any:
        """Load XML from string."""
        pass


class LxmlXPathProvider(XPathProvider):
    """
    XPath 1.0 provider using lxml.

    This is the fallback provider when Saxon is not available.
    """

    def __init__(self):
        self.document: Optional[etree._Element] = None
        self._cache: Dict[str, XPathQueryResult] = {}

    def get_version(self) -> XPathVersion:
        return XPathVersion.XPATH_1_0

    def load_document(self, file_path: Union[str, Path]) -> etree._Element:
        """Load XML document using lxml."""
        path = Path(file_path)
        if not path.exists():
            raise FileNotFoundError(f"XML file not found: {path}")

        self._cache.clear()

        # Try different encodings
        encodings = ["utf-8", "windows-1252", "cp1252", "latin-1"]

        for encoding in encodings:
            try:
                parser = etree.XMLParser(
                    encoding=encoding,
                    recover=True,
                    remove_blank_text=True
                )
                tree = etree.parse(str(path), parser)
                self.document = tree.getroot()
                return self.document
            except (etree.XMLSyntaxError, UnicodeDecodeError):
                continue

        # Last resort: binary read
        parser = etree.XMLParser(recover=True, remove_blank_text=True)
        with open(path, "rb") as f:
            tree = etree.parse(f, parser)
        self.document = tree.getroot()
        return self.document

    def load_string(self, xml_string: str) -> etree._Element:
        """Load XML from string."""
        self._cache.clear()
        parser = etree.XMLParser(recover=True, remove_blank_text=True)
        self.document = etree.fromstring(xml_string.encode(), parser)
        return self.document

    def query(
        self,
        xpath: str,
        context: Optional[etree._Element] = None,
        use_cache: bool = True
    ) -> XPathQueryResult:
        """Execute XPath 1.0 query using lxml."""
        if self.document is None:
            raise ValueError("No document loaded")

        element = context if context is not None else self.document
        cache_key = f"{id(element)}:{xpath}"

        if use_cache and cache_key in self._cache:
            return self._cache[cache_key]

        try:
            results = element.xpath(xpath)
            if isinstance(results, list):
                values = results
            else:
                values = [results] if results else []

            result = XPathQueryResult(
                values=values,
                query=xpath,
                count=len(values),
                xpath_version=XPathVersion.XPATH_1_0,
                provider="lxml"
            )

            if use_cache:
                self._cache[cache_key] = result

            return result
        except etree.XPathError as e:
            logger.error(f"XPath 1.0 error for '{xpath}': {e}")
            return XPathQueryResult(
                values=[],
                query=xpath,
                count=0,
                xpath_version=XPathVersion.XPATH_1_0,
                provider="lxml"
            )

    def query_single(
        self,
        xpath: str,
        context: Optional[etree._Element] = None
    ) -> Optional[Any]:
        """Execute query and return single result."""
        result = self.query(xpath, context)
        return result.first()


class SaxonXPathProvider(XPathProvider):
    """
    XPath 2.0/3.0/3.1 provider using Saxon-HE.

    Provides advanced XPath capabilities including:
    - XPath 2.0/3.0/3.1 functions
    - Full regex support
    - Date/time functions
    - Sequence operations
    - Type conversions
    """

    def __init__(self, xpath_version: XPathVersion = XPathVersion.XPATH_3_1):
        if not SAXON_AVAILABLE:
            raise ImportError(
                "saxonche is not installed. Install with: pip install saxonche"
            )

        self._xpath_version = xpath_version
        self._processor: Optional[PySaxonProcessor] = None
        self._document_node: Optional[PyXdmNode] = None
        self._lxml_document: Optional[etree._Element] = None
        self._cache: Dict[str, XPathQueryResult] = {}
        self._initialize_processor()

    def _initialize_processor(self) -> None:
        """Initialize the Saxon processor."""
        self._processor = PySaxonProcessor(license=False)
        logger.info(f"Saxon-HE initialized: version {self._processor.version}")

    def get_version(self) -> XPathVersion:
        return self._xpath_version

    def load_document(self, file_path: Union[str, Path]) -> PyXdmNode:
        """Load XML document using Saxon."""
        path = Path(file_path)
        if not path.exists():
            raise FileNotFoundError(f"XML file not found: {path}")

        self._cache.clear()

        # Load with Saxon
        self._document_node = self._processor.parse_xml(xml_file_name=str(path))

        # Also load with lxml for compatibility (element access)
        lxml_provider = LxmlXPathProvider()
        self._lxml_document = lxml_provider.load_document(path)

        return self._document_node

    def load_string(self, xml_string: str) -> PyXdmNode:
        """Load XML from string using Saxon."""
        self._cache.clear()

        self._document_node = self._processor.parse_xml(xml_text=xml_string)

        # Also load with lxml for compatibility
        lxml_provider = LxmlXPathProvider()
        self._lxml_document = lxml_provider.load_string(xml_string)

        return self._document_node

    def query(
        self,
        xpath: str,
        context: Optional[Any] = None,
        use_cache: bool = True
    ) -> XPathQueryResult:
        """
        Execute XPath 2.0/3.0/3.1 query using Saxon.

        Args:
            xpath: XPath expression (can use XPath 2.0/3.0 functions)
            context: Optional context node
            use_cache: Whether to cache results

        Returns:
            XPathQueryResult with values
        """
        if self._document_node is None:
            raise ValueError("No document loaded")

        cache_key = f"{id(context)}:{xpath}" if context else f"root:{xpath}"

        if use_cache and cache_key in self._cache:
            return self._cache[cache_key]

        try:
            # Create XPath compiler
            xpath_processor = self._processor.new_xpath_processor()

            # Set context item
            if context is not None:
                xpath_processor.set_context(xdm_item=context)
            else:
                xpath_processor.set_context(xdm_item=self._document_node)

            # Execute query
            xdm_result = xpath_processor.evaluate(xpath)

            # Convert results
            values = []
            if xdm_result is not None:
                if hasattr(xdm_result, '__iter__'):
                    for item in xdm_result:
                        values.append(self._convert_xdm_value(item))
                else:
                    values.append(self._convert_xdm_value(xdm_result))

            result = XPathQueryResult(
                values=values,
                query=xpath,
                count=len(values),
                xpath_version=self._xpath_version,
                provider="saxon"
            )

            if use_cache:
                self._cache[cache_key] = result

            return result

        except Exception as e:
            logger.error(f"Saxon XPath error for '{xpath}': {e}")
            return XPathQueryResult(
                values=[],
                query=xpath,
                count=0,
                xpath_version=self._xpath_version,
                provider="saxon"
            )

    def query_single(
        self,
        xpath: str,
        context: Optional[Any] = None
    ) -> Optional[Any]:
        """Execute query and return single result."""
        result = self.query(xpath, context)
        return result.first()

    def _convert_xdm_value(self, value: Any) -> Any:
        """Convert Saxon XDM value to Python value."""
        if value is None:
            return None

        if hasattr(value, 'string_value'):
            # XdmAtomicValue or XdmNode
            if hasattr(value, 'node_kind'):
                # It's a node - return as-is for now
                return value
            return value.string_value

        return value

    def get_lxml_document(self) -> Optional[etree._Element]:
        """Get the lxml document for compatibility operations."""
        return self._lxml_document

    # =========================================================================
    # XPath 2.0/3.0 Specific Functions
    # =========================================================================

    def tokenize(self, text: str, pattern: str) -> List[str]:
        """
        XPath 2.0 tokenize function.

        Splits text by regex pattern.
        """
        xpath = f"tokenize('{self._escape_string(text)}', '{pattern}')"
        result = self.query(xpath, use_cache=False)
        return result.as_strings()

    def matches(self, text: str, pattern: str, flags: str = "") -> bool:
        """
        XPath 2.0 matches function.

        Tests if text matches regex pattern.
        """
        if flags:
            xpath = f"matches('{self._escape_string(text)}', '{pattern}', '{flags}')"
        else:
            xpath = f"matches('{self._escape_string(text)}', '{pattern}')"

        result = self.query(xpath, use_cache=False)
        first = result.first()
        return first == "true" or first is True

    def replace(self, text: str, pattern: str, replacement: str, flags: str = "") -> str:
        """
        XPath 2.0 replace function.

        Replaces regex matches in text.
        """
        if flags:
            xpath = f"replace('{self._escape_string(text)}', '{pattern}', '{replacement}', '{flags}')"
        else:
            xpath = f"replace('{self._escape_string(text)}', '{pattern}', '{replacement}')"

        result = self.query(xpath, use_cache=False)
        return result.first() or ""

    def analyze_string(self, text: str, pattern: str) -> Dict[str, List[str]]:
        """
        XPath 3.0 analyze-string function.

        Returns matched and non-matched portions.
        """
        # This is a simplified implementation
        xpath = f"analyze-string('{self._escape_string(text)}', '{pattern}')"
        result = self.query(xpath, use_cache=False)

        matches = []
        non_matches = []

        # Parse analyze-string result (which is XML)
        for item in result.values:
            if hasattr(item, 'string_value'):
                # Would need to parse the analyze-string XML result
                pass

        return {"matches": matches, "non_matches": non_matches}

    def distinct_values(self, xpath_expr: str) -> List[Any]:
        """
        XPath 2.0 distinct-values function.

        Returns unique values from a sequence.
        """
        xpath = f"distinct-values({xpath_expr})"
        result = self.query(xpath, use_cache=False)
        return result.values

    def format_number(self, value: Union[int, float], picture: str) -> str:
        """
        XPath 2.0 format-number function.

        Formats a number according to a picture string.
        """
        xpath = f"format-number({value}, '{picture}')"
        result = self.query(xpath, use_cache=False)
        return result.first() or ""

    def format_date(self, date_str: str, picture: str) -> str:
        """
        XPath 2.0 format-date function.

        Formats a date according to a picture string.
        """
        xpath = f"format-date(xs:date('{date_str}'), '{picture}')"
        result = self.query(xpath, use_cache=False)
        return result.first() or ""

    def _escape_string(self, text: str) -> str:
        """Escape string for XPath expression."""
        # Escape single quotes by doubling them
        return text.replace("'", "''")

    def close(self) -> None:
        """Release Saxon processor resources."""
        if self._processor:
            # Saxon processor cleanup
            self._processor = None
            self._document_node = None
            self._lxml_document = None
            self._cache.clear()


class XPathProviderFactory:
    """
    Factory for creating XPath providers.

    Automatically selects the best available provider.
    """

    @staticmethod
    def create(
        prefer_saxon: bool = True,
        xpath_version: XPathVersion = XPathVersion.XPATH_3_1
    ) -> XPathProvider:
        """
        Create an XPath provider.

        Args:
            prefer_saxon: If True, use Saxon if available
            xpath_version: Preferred XPath version for Saxon

        Returns:
            XPathProvider instance
        """
        if prefer_saxon and SAXON_AVAILABLE:
            try:
                return SaxonXPathProvider(xpath_version)
            except Exception as e:
                logger.warning(f"Failed to initialize Saxon, falling back to lxml: {e}")

        return LxmlXPathProvider()

    @staticmethod
    def is_saxon_available() -> bool:
        """Check if Saxon is available."""
        return SAXON_AVAILABLE

    @staticmethod
    def get_available_versions() -> List[XPathVersion]:
        """Get available XPath versions."""
        versions = [XPathVersion.XPATH_1_0]  # lxml always available
        if SAXON_AVAILABLE:
            versions.extend([
                XPathVersion.XPATH_2_0,
                XPathVersion.XPATH_3_0,
                XPathVersion.XPATH_3_1
            ])
        return versions


@dataclass
class XPath2Pattern:
    """
    XPath 2.0/3.0 pattern for Informatica queries.

    Contains both the XPath expression and fallback XPath 1.0 expression.
    """
    name: str
    description: str
    xpath_2: str  # XPath 2.0/3.0 expression
    xpath_1: str  # XPath 1.0 fallback
    requires_saxon: bool = False

    def get_xpath(self, provider: XPathProvider) -> str:
        """Get appropriate XPath for the provider."""
        if provider.get_version() == XPathVersion.XPATH_1_0:
            return self.xpath_1
        return self.xpath_2


class InformaticaXPath2Patterns:
    """
    Advanced XPath 2.0/3.0 patterns for Informatica queries.

    These patterns leverage XPath 2.0/3.0 functions for more powerful
    queries than possible with XPath 1.0.
    """

    # =========================================================================
    # Expression Analysis Patterns (using regex functions)
    # =========================================================================

    @staticmethod
    def expressions_with_pattern(pattern: str) -> XPath2Pattern:
        """
        Find expressions matching a regex pattern.

        XPath 2.0: Uses matches() function
        XPath 1.0: Uses contains() (less precise)
        """
        return XPath2Pattern(
            name="expressions_with_pattern",
            description=f"Expressions matching pattern '{pattern}'",
            xpath_2=f"//TRANSFORMFIELD[matches(@EXPRESSION, '{pattern}', 'i')]",
            xpath_1=f"//TRANSFORMFIELD[contains(@EXPRESSION, '{pattern}')]",
            requires_saxon=False
        )

    @staticmethod
    def expressions_with_function_call(function_name: str) -> XPath2Pattern:
        """
        Find expressions with specific function calls.

        XPath 2.0: Uses regex to match function call syntax
        XPath 1.0: Simple contains check
        """
        return XPath2Pattern(
            name="expressions_with_function",
            description=f"Expressions calling {function_name}()",
            xpath_2=f"//TRANSFORMFIELD[matches(@EXPRESSION, '{function_name}\\s*\\(', 'i')]",
            xpath_1=f"//TRANSFORMFIELD[contains(translate(@EXPRESSION, 'ABCDEFGHIJKLMNOPQRSTUVWXYZ', 'abcdefghijklmnopqrstuvwxyz'), '{function_name.lower()}(')]",
            requires_saxon=False
        )

    @staticmethod
    def nested_iif_expressions(min_depth: int = 2) -> XPath2Pattern:
        """
        Find expressions with nested IIF statements.

        XPath 2.0: Count IIF occurrences
        XPath 1.0: Check for multiple IIF strings
        """
        return XPath2Pattern(
            name="nested_iif",
            description=f"Expressions with {min_depth}+ nested IIF",
            xpath_2=f"//TRANSFORMFIELD[count(tokenize(upper-case(@EXPRESSION), 'IIF\\s*\\(')) > {min_depth}]",
            xpath_1="//TRANSFORMFIELD[contains(@EXPRESSION, 'IIF') and contains(substring-after(@EXPRESSION, 'IIF'), 'IIF')]",
            requires_saxon=True
        )

    @staticmethod
    def expressions_with_field_reference(field_pattern: str) -> XPath2Pattern:
        """
        Find expressions referencing fields matching a pattern.

        Matches field references like TABLE.FIELD_NAME
        """
        return XPath2Pattern(
            name="field_references",
            description=f"Expressions referencing fields matching '{field_pattern}'",
            xpath_2=f"//TRANSFORMFIELD[matches(@EXPRESSION, '[A-Za-z_][A-Za-z0-9_]*\\.{field_pattern}')]",
            xpath_1=f"//TRANSFORMFIELD[contains(@EXPRESSION, '.{field_pattern}')]",
            requires_saxon=False
        )

    # =========================================================================
    # Transformation Chain Patterns
    # =========================================================================

    @staticmethod
    def transformations_by_type_sequence(types: List[str]) -> XPath2Pattern:
        """
        Find transformations that appear in a specific type sequence.

        For example, find Filters that feed into Aggregators.
        """
        type_conditions = " and ".join(
            f".//TRANSFORMATION[@TYPE='{t}']" for t in types
        )
        return XPath2Pattern(
            name="type_sequence",
            description=f"Mappings with transformation sequence: {' -> '.join(types)}",
            xpath_2=f"//MAPPING[{type_conditions}]",
            xpath_1=f"//MAPPING[{type_conditions}]",
            requires_saxon=False
        )

    @staticmethod
    def high_fanout_transformations(threshold: int = 5) -> XPath2Pattern:
        """
        Find transformations with high fan-out (many outgoing connections).
        """
        return XPath2Pattern(
            name="high_fanout",
            description=f"Transformations with {threshold}+ outgoing connections",
            xpath_2=f"""
                //TRANSFORMATION[
                    count(
                        ancestor::MAPPING//CONNECTOR[@FROMINSTANCE=current()/@NAME]
                    ) > {threshold}
                ]
            """.strip(),
            xpath_1=f"""
                //TRANSFORMATION[
                    count(
                        ancestor::MAPPING//CONNECTOR[@FROMINSTANCE=current()/@NAME]
                    ) > {threshold}
                ]
            """.strip(),
            requires_saxon=False
        )

    @staticmethod
    def high_fanin_transformations(threshold: int = 5) -> XPath2Pattern:
        """
        Find transformations with high fan-in (many incoming connections).
        """
        return XPath2Pattern(
            name="high_fanin",
            description=f"Transformations with {threshold}+ incoming connections",
            xpath_2=f"""
                //TRANSFORMATION[
                    count(
                        ancestor::MAPPING//CONNECTOR[@TOINSTANCE=current()/@NAME]
                    ) > {threshold}
                ]
            """.strip(),
            xpath_1=f"""
                //TRANSFORMATION[
                    count(
                        ancestor::MAPPING//CONNECTOR[@TOINSTANCE=current()/@NAME]
                    ) > {threshold}
                ]
            """.strip(),
            requires_saxon=False
        )

    # =========================================================================
    # Data Quality Patterns
    # =========================================================================

    @staticmethod
    def fields_with_null_handling() -> XPath2Pattern:
        """
        Find fields that handle NULL values (ISNULL, NVL, COALESCE, etc.).
        """
        return XPath2Pattern(
            name="null_handling",
            description="Fields with NULL handling expressions",
            xpath_2="//TRANSFORMFIELD[matches(@EXPRESSION, '(ISNULL|NVL|COALESCE|NULLIF)\\s*\\(', 'i')]",
            xpath_1="//TRANSFORMFIELD[contains(@EXPRESSION, 'ISNULL') or contains(@EXPRESSION, 'NVL') or contains(@EXPRESSION, 'COALESCE')]",
            requires_saxon=False
        )

    @staticmethod
    def fields_with_type_conversion() -> XPath2Pattern:
        """
        Find fields with type conversion functions.
        """
        return XPath2Pattern(
            name="type_conversion",
            description="Fields with type conversion expressions",
            xpath_2="//TRANSFORMFIELD[matches(@EXPRESSION, '(TO_CHAR|TO_DATE|TO_INTEGER|TO_DECIMAL|TO_FLOAT|CAST)\\s*\\(', 'i')]",
            xpath_1="//TRANSFORMFIELD[contains(@EXPRESSION, 'TO_CHAR') or contains(@EXPRESSION, 'TO_DATE') or contains(@EXPRESSION, 'TO_INTEGER')]",
            requires_saxon=False
        )

    @staticmethod
    def fields_with_string_manipulation() -> XPath2Pattern:
        """
        Find fields with string manipulation functions.
        """
        return XPath2Pattern(
            name="string_manipulation",
            description="Fields with string manipulation expressions",
            xpath_2="//TRANSFORMFIELD[matches(@EXPRESSION, '(SUBSTR|UPPER|LOWER|TRIM|LTRIM|RTRIM|LPAD|RPAD|CONCAT|REPLACE|INSTR|LENGTH)\\s*\\(', 'i')]",
            xpath_1="//TRANSFORMFIELD[contains(@EXPRESSION, 'SUBSTR') or contains(@EXPRESSION, 'UPPER') or contains(@EXPRESSION, 'LOWER') or contains(@EXPRESSION, 'TRIM')]",
            requires_saxon=False
        )

    @staticmethod
    def fields_with_date_functions() -> XPath2Pattern:
        """
        Find fields using date/time functions.
        """
        return XPath2Pattern(
            name="date_functions",
            description="Fields with date/time expressions",
            xpath_2="//TRANSFORMFIELD[matches(@EXPRESSION, '(SYSDATE|ADD_TO_DATE|DATE_DIFF|DATE_COMPARE|TRUNC|GET_DATE_PART|LAST_DAY|SET_DATE_PART|SYSTIMESTAMP)\\s*\\(?', 'i')]",
            xpath_1="//TRANSFORMFIELD[contains(@EXPRESSION, 'SYSDATE') or contains(@EXPRESSION, 'ADD_TO_DATE') or contains(@EXPRESSION, 'DATE_DIFF')]",
            requires_saxon=False
        )

    # =========================================================================
    # Lookup Analysis Patterns
    # =========================================================================

    @staticmethod
    def lookup_expressions() -> XPath2Pattern:
        """
        Find all lookup references in expressions.
        """
        return XPath2Pattern(
            name="lookup_expressions",
            description="Fields referencing lookups",
            xpath_2="//TRANSFORMFIELD[matches(@EXPRESSION, ':LKP\\.[A-Za-z_][A-Za-z0-9_]*')]",
            xpath_1="//TRANSFORMFIELD[contains(@EXPRESSION, ':LKP.')]",
            requires_saxon=False
        )

    @staticmethod
    def lookup_with_override() -> XPath2Pattern:
        """
        Find lookups with SQL override.
        """
        return XPath2Pattern(
            name="lookup_override",
            description="Lookup transformations with SQL override",
            xpath_2="//TRANSFORMATION[@TYPE='Lookup Procedure'][.//TABLEATTRIBUTE[@NAME='Sql Query' and string-length(@VALUE) > 0]]",
            xpath_1="//TRANSFORMATION[@TYPE='Lookup Procedure'][.//TABLEATTRIBUTE[@NAME='Sql Query'][@VALUE!='']]",
            requires_saxon=False
        )

    @staticmethod
    def connected_lookups() -> XPath2Pattern:
        """
        Find lookups that are actually connected (not orphaned).
        """
        return XPath2Pattern(
            name="connected_lookups",
            description="Connected lookup transformations",
            xpath_2="""
                //TRANSFORMATION[@TYPE='Lookup Procedure'][
                    @NAME = ancestor::MAPPING//INSTANCE[@TYPE='Transformation']/@TRANSFORMATION_NAME
                ]
            """.strip(),
            xpath_1="""
                //TRANSFORMATION[@TYPE='Lookup Procedure'][
                    @NAME = ancestor::MAPPING//INSTANCE[@TYPE='Transformation']/@TRANSFORMATION_NAME
                ]
            """.strip(),
            requires_saxon=False
        )

    # =========================================================================
    # Complexity Analysis Patterns
    # =========================================================================

    @staticmethod
    def complex_expressions(min_length: int = 100) -> XPath2Pattern:
        """
        Find expressions exceeding a complexity threshold.
        """
        return XPath2Pattern(
            name="complex_expressions",
            description=f"Expressions longer than {min_length} characters",
            xpath_2=f"//TRANSFORMFIELD[string-length(@EXPRESSION) > {min_length}]",
            xpath_1=f"//TRANSFORMFIELD[string-length(@EXPRESSION) > {min_length}]",
            requires_saxon=False
        )

    @staticmethod
    def expressions_with_multiple_operations(min_ops: int = 5) -> XPath2Pattern:
        """
        Find expressions with multiple operators/operations.
        """
        return XPath2Pattern(
            name="multi_operation_expressions",
            description=f"Expressions with {min_ops}+ operations",
            xpath_2=f"""
                //TRANSFORMFIELD[
                    count(tokenize(@EXPRESSION, '[+\\-*/]')) > {min_ops}
                ]
            """.strip(),
            xpath_1="//TRANSFORMFIELD[string-length(@EXPRESSION) > 50]",  # Approximation
            requires_saxon=True
        )

    # =========================================================================
    # Workflow Patterns
    # =========================================================================

    @staticmethod
    def sessions_with_pre_post_sql() -> XPath2Pattern:
        """
        Find sessions with pre/post-session SQL.
        """
        return XPath2Pattern(
            name="sessions_with_sql",
            description="Sessions with pre/post SQL commands",
            xpath_2="""
                //SESSION[
                    .//ATTRIBUTE[@NAME='Pre SQL' and string-length(@VALUE) > 0] or
                    .//ATTRIBUTE[@NAME='Post SQL' and string-length(@VALUE) > 0]
                ]
            """.strip(),
            xpath_1="""
                //SESSION[
                    .//ATTRIBUTE[@NAME='Pre SQL'][@VALUE!=''] or
                    .//ATTRIBUTE[@NAME='Post SQL'][@VALUE!='']
                ]
            """.strip(),
            requires_saxon=False
        )

    @staticmethod
    def parallel_workflow_tasks() -> XPath2Pattern:
        """
        Find workflow tasks that can run in parallel.
        """
        return XPath2Pattern(
            name="parallel_tasks",
            description="Tasks with parallel execution potential",
            xpath_2="""
                //TASK[
                    not(
                        @NAME = preceding-sibling::WORKFLOWLINK/@TOINSTANCE or
                        @NAME = following-sibling::WORKFLOWLINK/@FROMINSTANCE
                    )
                ]
            """.strip(),
            xpath_1="""
                //TASK[
                    not(@NAME = ancestor::WORKFLOW//WORKFLOWLINK/@TOINSTANCE)
                ]
            """.strip(),
            requires_saxon=False
        )


# Convenience function
def create_xpath_provider(prefer_saxon: bool = True) -> XPathProvider:
    """Create an XPath provider using the factory."""
    return XPathProviderFactory.create(prefer_saxon=prefer_saxon)


# Export availability flag
def is_saxon_available() -> bool:
    """Check if Saxon XPath 2.0/3.0 support is available."""
    return SAXON_AVAILABLE
