"""
XDM-based XML utilities for Informatica parsing using lxml and XPath.

This module provides enhanced XML parsing capabilities using the XML Data Model (XDM)
principles, similar to how AST (Abstract Syntax Tree) is used for SQL parsing.

Key improvements over standard ElementTree:
- Full XPath 1.0 support for complex queries (via lxml)
- Optional XPath 2.0/3.0/3.1 support (via Saxon-HE)
- Pattern-based element detection
- Context-aware parsing
- More efficient traversal for lineage extraction

Phase 4 Enhancement:
- Saxon integration for XPath 2.0/3.0/3.1 support
- Advanced regex functions (matches, replace, tokenize)
- Date/time functions
- Sequence operations
"""

from lxml import etree
from typing import Any, Dict, List, Optional, Set, Tuple, Union, Callable
from pathlib import Path
from dataclasses import dataclass, field
import logging
import re

# Import Saxon provider (Phase 4)
try:
    from .saxon_xpath_provider import (
        XPathProvider,
        XPathProviderFactory,
        SaxonXPathProvider,
        LxmlXPathProvider,
        XPathVersion,
        XPathQueryResult,
        InformaticaXPath2Patterns,
        XPath2Pattern,
        is_saxon_available,
        SAXON_AVAILABLE,
    )
    PHASE4_AVAILABLE = True
except ImportError:
    PHASE4_AVAILABLE = False
    SAXON_AVAILABLE = False
    XPathProvider = None
    XPathProviderFactory = None
    SaxonXPathProvider = None
    LxmlXPathProvider = None
    XPathVersion = None
    XPathQueryResult = None
    InformaticaXPath2Patterns = None
    XPath2Pattern = None

    def is_saxon_available():
        return False

logger = logging.getLogger(__name__)


@dataclass
class XPathResult:
    """Result of an XPath query with metadata."""
    elements: List[etree._Element]
    query: str
    count: int

    def __iter__(self):
        return iter(self.elements)

    def __len__(self):
        return self.count

    def first(self) -> Optional[etree._Element]:
        """Get first result or None."""
        return self.elements[0] if self.elements else None

    def values(self, attr: str) -> List[str]:
        """Get attribute values from all elements."""
        return [elem.get(attr, "") for elem in self.elements]


@dataclass
class FieldContext:
    """Context information for a field in the XML document."""
    name: str
    instance: str
    instance_type: str
    datatype: str = ""
    precision: int = 0
    scale: int = 0
    expression: str = ""
    is_input: bool = False
    is_output: bool = False
    parent_transformation: Optional[str] = None
    source_definition: Optional[str] = None
    target_definition: Optional[str] = None


@dataclass
class ConnectorContext:
    """Enhanced connector information with full context."""
    from_instance: str
    from_field: str
    from_instance_type: str
    to_instance: str
    to_field: str
    to_instance_type: str
    from_field_context: Optional[FieldContext] = None
    to_field_context: Optional[FieldContext] = None
    mapping_name: str = ""


class XDMXMLParser:
    """
    Enhanced XML parser using lxml and XPath for Informatica PowerCenter XML.

    This class provides XDM-like capabilities for parsing and querying
    Informatica XML exports, enabling:
    - Efficient XPath-based queries
    - Pattern-based transformation detection
    - Context-aware field resolution
    - Improved accuracy for lineage extraction

    Example usage:
        parser = XDMXMLParser("mapping.xml")

        # Find all unmapped target fields
        unmapped = parser.find_unmapped_target_fields("m_MyMapping")

        # Get transformation chain
        chain = parser.get_transformation_chain("SQ_Source", "T_Target")

        # Query with XPath
        filters = parser.xpath("//TRANSFORMATION[@TYPE='Filter']")
    """

    def __init__(
        self,
        file_path: Optional[Union[str, Path]] = None,
        use_saxon: bool = True
    ):
        """
        Initialize the XDM XML parser.

        Args:
            file_path: Optional path to XML file to parse immediately
            use_saxon: If True and Saxon is available, use XPath 2.0/3.0 (Phase 4)
        """
        self.root: Optional[etree._Element] = None
        self.file_path: Optional[Path] = None
        self._xpath_cache: Dict[str, XPathResult] = {}
        self._field_cache: Dict[str, FieldContext] = {}
        self._connector_cache: Dict[str, List[ConnectorContext]] = {}

        # Phase 4: Saxon XPath 2.0/3.0 provider
        self._saxon_provider: Optional[Any] = None
        self._use_saxon = use_saxon and PHASE4_AVAILABLE and SAXON_AVAILABLE

        if self._use_saxon:
            try:
                self._saxon_provider = XPathProviderFactory.create(prefer_saxon=True)
                logger.info(f"Saxon XPath provider initialized: {self._saxon_provider.get_version().value}")
            except Exception as e:
                logger.warning(f"Failed to initialize Saxon provider: {e}")
                self._use_saxon = False
                self._saxon_provider = None

        if file_path:
            self.parse(file_path)

    def parse(self, file_path: Union[str, Path]) -> etree._Element:
        """
        Parse an XML file using lxml.

        Args:
            file_path: Path to XML file

        Returns:
            Root element of parsed XML

        Raises:
            FileNotFoundError: If file doesn't exist
            etree.XMLSyntaxError: If XML is invalid
        """
        self.file_path = Path(file_path)
        if not self.file_path.exists():
            raise FileNotFoundError(f"XML file not found: {self.file_path}")

        # Clear caches on new parse
        self._xpath_cache.clear()
        self._field_cache.clear()
        self._connector_cache.clear()

        # Try different encodings
        encodings = ["utf-8", "windows-1252", "cp1252", "latin-1"]

        for encoding in encodings:
            try:
                parser = etree.XMLParser(
                    encoding=encoding,
                    recover=True,  # Recover from minor errors
                    remove_blank_text=True
                )
                tree = etree.parse(str(self.file_path), parser)
                self.root = tree.getroot()
                logger.debug(f"Parsed XML with encoding: {encoding}")
                return self.root
            except (etree.XMLSyntaxError, UnicodeDecodeError) as e:
                logger.debug(f"Failed with encoding {encoding}: {e}")
                continue

        # Last resort: read as binary and let lxml detect encoding
        parser = etree.XMLParser(recover=True, remove_blank_text=True)
        with open(self.file_path, "rb") as f:
            tree = etree.parse(f, parser)
        self.root = tree.getroot()

        # Phase 4: Also load into Saxon provider if available
        if self._use_saxon and self._saxon_provider:
            try:
                self._saxon_provider.load_document(self.file_path)
                logger.debug("Document loaded into Saxon provider")
            except Exception as e:
                logger.warning(f"Failed to load document into Saxon: {e}")

        return self.root

    def parse_string(self, xml_string: str) -> etree._Element:
        """Parse XML from string."""
        self._xpath_cache.clear()
        self._field_cache.clear()
        self._connector_cache.clear()

        parser = etree.XMLParser(recover=True, remove_blank_text=True)
        self.root = etree.fromstring(xml_string.encode(), parser)

        # Phase 4: Also load into Saxon provider if available
        if self._use_saxon and self._saxon_provider:
            try:
                self._saxon_provider.load_string(xml_string)
            except Exception as e:
                logger.warning(f"Failed to load string into Saxon: {e}")

        return self.root

    # =========================================================================
    # Core XPath Query Methods
    # =========================================================================

    def xpath(
        self,
        query: str,
        context: Optional[etree._Element] = None,
        use_cache: bool = True
    ) -> XPathResult:
        """
        Execute an XPath query on the document.

        Args:
            query: XPath expression
            context: Optional context element (defaults to root)
            use_cache: Whether to use cached results

        Returns:
            XPathResult with matching elements
        """
        if self.root is None:
            raise ValueError("No XML document loaded. Call parse() first.")

        # Check cache
        cache_key = f"{id(context if context is not None else self.root)}:{query}"
        if use_cache and cache_key in self._xpath_cache:
            return self._xpath_cache[cache_key]

        element = context if context is not None else self.root
        try:
            results = element.xpath(query)
            # Handle both element lists and attribute/text results
            if isinstance(results, list):
                if results and isinstance(results[0], etree._Element):
                    elements = results
                else:
                    # String/number results - wrap in empty list
                    elements = []
            else:
                elements = []

            result = XPathResult(
                elements=elements,
                query=query,
                count=len(elements)
            )

            if use_cache:
                self._xpath_cache[cache_key] = result

            return result
        except etree.XPathError as e:
            logger.error(f"XPath error for query '{query}': {e}")
            return XPathResult(elements=[], query=query, count=0)

    def xpath_values(self, query: str, context: Optional[etree._Element] = None) -> List[str]:
        """
        Execute XPath query and return string values.

        Useful for attribute or text queries.
        """
        if self.root is None:
            raise ValueError("No XML document loaded.")

        element = context or self.root
        try:
            results = element.xpath(query)
            if isinstance(results, list):
                return [str(r) for r in results]
            return [str(results)]
        except etree.XPathError as e:
            logger.error(f"XPath error: {e}")
            return []

    # =========================================================================
    # Informatica-Specific Query Methods
    # =========================================================================

    def get_mappings(self) -> XPathResult:
        """Get all MAPPING elements."""
        return self.xpath("//MAPPING")

    def get_mapping(self, name: str) -> Optional[etree._Element]:
        """Get a specific mapping by name (case-insensitive)."""
        # Try exact match first
        result = self.xpath(f"//MAPPING[@NAME='{name}']")
        first_result = result.first()
        if first_result is not None:
            return first_result

        # Try case-insensitive match
        for mapping in self.xpath("//MAPPING"):
            if mapping.get("NAME", "").lower() == name.lower():
                return mapping
        return None

    def get_sources(self) -> XPathResult:
        """Get all SOURCE elements."""
        return self.xpath("//SOURCE")

    def get_targets(self) -> XPathResult:
        """Get all TARGET elements."""
        return self.xpath("//TARGET")

    def get_transformations(self, trans_type: Optional[str] = None) -> XPathResult:
        """
        Get TRANSFORMATION elements, optionally filtered by type.

        Args:
            trans_type: Optional transformation type filter (e.g., 'Filter', 'Expression')
        """
        if trans_type:
            return self.xpath(f"//TRANSFORMATION[@TYPE='{trans_type}']")
        return self.xpath("//TRANSFORMATION")

    def get_connectors(self, mapping_name: Optional[str] = None) -> XPathResult:
        """
        Get CONNECTOR elements, optionally within a specific mapping.

        Args:
            mapping_name: Optional mapping name to scope the query
        """
        if mapping_name:
            mapping = self.get_mapping(mapping_name)
            if mapping is not None:
                return self.xpath(".//CONNECTOR", context=mapping)
            return XPathResult(elements=[], query="", count=0)
        return self.xpath("//MAPPING//CONNECTOR")

    def get_workflows(self) -> XPathResult:
        """Get all WORKFLOW elements."""
        return self.xpath("//WORKFLOW")

    def get_sessions(self) -> XPathResult:
        """Get all SESSION elements."""
        return self.xpath("//SESSION")

    # =========================================================================
    # Field-Level Lineage Queries
    # =========================================================================

    def find_unmapped_target_fields(self, mapping_name: str) -> List[Dict[str, str]]:
        """
        Find target fields that have no incoming connector.

        This uses XPath to efficiently detect unmapped fields in a single pass.

        Args:
            mapping_name: Name of the mapping to analyze

        Returns:
            List of dicts with unmapped field info
        """
        mapping = self.get_mapping(mapping_name)
        if mapping is None:
            return []

        unmapped = []

        # Get all target instances in the mapping
        target_instances = self.xpath(
            ".//INSTANCE[@TYPE='Target Definition']",
            context=mapping
        )

        # Get all connectors in the mapping
        connectors = self.xpath(".//CONNECTOR", context=mapping)

        # Build set of (to_instance, to_field) pairs from connectors
        mapped_fields: Set[Tuple[str, str]] = set()
        for conn in connectors:
            to_inst = (conn.get("TOINSTANCE", "") or "").strip().lower()
            to_field = (conn.get("TOFIELD", "") or "").strip().lower()
            if to_inst and to_field:
                mapped_fields.add((to_inst, to_field))

        # For each target instance, find unmapped fields
        for instance in target_instances:
            instance_name = instance.get("NAME", "")
            target_name = instance.get("TRANSFORMATION_NAME", "")

            # Find the TARGET definition
            target_def = self.xpath(f"//TARGET[@NAME='{target_name}']").first()
            if target_def is None:
                # Try with shortcut handling
                if target_name.startswith("Shortcut_to_"):
                    target_name = target_name[12:]  # Remove prefix
                    target_def = self.xpath(f"//TARGET[@NAME='{target_name}']").first()

            if target_def is None:
                continue

            # Get all target fields
            target_fields = self.xpath(".//TARGETFIELD", context=target_def)

            for field_elem in target_fields:
                field_name = field_elem.get("NAME", "")

                # Check if this field is mapped
                lookup_key = (instance_name.lower(), field_name.lower())
                if lookup_key not in mapped_fields:
                    unmapped.append({
                        "target": target_name,
                        "instance": instance_name,
                        "field": field_name,
                        "datatype": field_elem.get("DATATYPE", ""),
                        "precision": field_elem.get("PRECISION", ""),
                    })

        return unmapped

    def find_source_fields_for_target(
        self,
        mapping_name: str,
        target_field: str
    ) -> List[Dict[str, Any]]:
        """
        Find all source fields that contribute to a target field.

        Uses backward traversal through connectors to trace lineage.

        Args:
            mapping_name: Name of the mapping
            target_field: Name of the target field

        Returns:
            List of source field information with transformation path
        """
        mapping = self.get_mapping(mapping_name)
        if mapping is None:
            return []

        # Build connector graph
        connectors = self.xpath(".//CONNECTOR", context=mapping)

        # Build adjacency lists for backward traversal
        # Key: (to_instance, to_field), Value: list of (from_instance, from_field, connector)
        backward_edges: Dict[Tuple[str, str], List[Tuple[str, str, etree._Element]]] = {}

        for conn in connectors:
            to_key = (
                conn.get("TOINSTANCE", "").lower(),
                conn.get("TOFIELD", "").lower()
            )
            from_info = (
                conn.get("FROMINSTANCE", ""),
                conn.get("FROMFIELD", ""),
                conn
            )
            if to_key not in backward_edges:
                backward_edges[to_key] = []
            backward_edges[to_key].append(from_info)

        # Find target instances
        target_instances = self.xpath(
            f".//INSTANCE[@TYPE='Target Definition']",
            context=mapping
        )

        results = []
        visited = set()

        def trace_backward(instance: str, field: str, path: List[Dict]) -> None:
            """Recursively trace backward to sources."""
            key = (instance.lower(), field.lower())

            if key in visited:
                return
            visited.add(key)

            if key not in backward_edges:
                # Check if this is a source
                instance_elem = self.xpath(
                    f".//INSTANCE[@NAME='{instance}']",
                    context=mapping
                ).first()

                if instance_elem is not None:
                    inst_type = instance_elem.get("TYPE", "")
                    if "Source" in inst_type:
                        # Found a source
                        results.append({
                            "source_instance": instance,
                            "source_field": field,
                            "instance_type": inst_type,
                            "path": list(path)
                        })
                return

            for from_inst, from_field, conn in backward_edges[key]:
                step = {
                    "from_instance": from_inst,
                    "from_field": from_field,
                    "to_instance": instance,
                    "to_field": field,
                    "from_type": conn.get("FROMINSTANCETYPE", ""),
                    "to_type": conn.get("TOINSTANCETYPE", "")
                }
                trace_backward(from_inst, from_field, path + [step])

        # Start tracing from target instances
        for target_inst in target_instances:
            inst_name = target_inst.get("NAME", "")
            trace_backward(inst_name, target_field, [])

        return results

    def get_transformation_expressions(
        self,
        mapping_name: str,
        transformation_name: Optional[str] = None
    ) -> List[Dict[str, str]]:
        """
        Get all expressions from transformations in a mapping.

        Args:
            mapping_name: Name of the mapping
            transformation_name: Optional specific transformation name

        Returns:
            List of expression information
        """
        mapping = self.get_mapping(mapping_name)
        if mapping is None:
            return []

        if transformation_name:
            xpath_query = f".//TRANSFORMATION[@NAME='{transformation_name}']//TRANSFORMFIELD[@EXPRESSION]"
        else:
            xpath_query = ".//TRANSFORMATION//TRANSFORMFIELD[@EXPRESSION]"

        expr_fields = self.xpath(xpath_query, context=mapping)

        results = []
        for field in expr_fields:
            trans = field.getparent()
            results.append({
                "transformation": trans.get("NAME", "") if trans is not None else "",
                "transformation_type": trans.get("TYPE", "") if trans is not None else "",
                "field_name": field.get("NAME", ""),
                "expression": field.get("EXPRESSION", ""),
                "datatype": field.get("DATATYPE", ""),
                "port_type": field.get("PORTTYPE", ""),
            })

        return results

    # =========================================================================
    # Pattern Detection Methods
    # =========================================================================

    def find_transformations_with_filter(self, mapping_name: Optional[str] = None) -> XPathResult:
        """Find all Filter transformations."""
        if mapping_name:
            mapping = self.get_mapping(mapping_name)
            if mapping is not None:
                return self.xpath(".//TRANSFORMATION[@TYPE='Filter']", context=mapping)
        return self.xpath("//TRANSFORMATION[@TYPE='Filter']")

    def find_transformations_with_aggregation(self, mapping_name: Optional[str] = None) -> XPathResult:
        """Find all Aggregator transformations."""
        if mapping_name:
            mapping = self.get_mapping(mapping_name)
            if mapping is not None:
                return self.xpath(".//TRANSFORMATION[@TYPE='Aggregator']", context=mapping)
        return self.xpath("//TRANSFORMATION[@TYPE='Aggregator']")

    def find_transformations_with_lookup(self, mapping_name: Optional[str] = None) -> XPathResult:
        """Find all Lookup transformations."""
        if mapping_name:
            mapping = self.get_mapping(mapping_name)
            if mapping is not None:
                return self.xpath(".//TRANSFORMATION[@TYPE='Lookup Procedure']", context=mapping)
        return self.xpath("//TRANSFORMATION[@TYPE='Lookup Procedure']")

    def find_transformations_with_joiner(self, mapping_name: Optional[str] = None) -> XPathResult:
        """Find all Joiner transformations."""
        if mapping_name:
            mapping = self.get_mapping(mapping_name)
            if mapping is not None:
                return self.xpath(".//TRANSFORMATION[@TYPE='Joiner']", context=mapping)
        return self.xpath("//TRANSFORMATION[@TYPE='Joiner']")

    def find_normalizers(self, mapping_name: Optional[str] = None) -> XPathResult:
        """Find all Normalizer transformations."""
        if mapping_name:
            mapping = self.get_mapping(mapping_name)
            if mapping is not None:
                return self.xpath(".//TRANSFORMATION[@TYPE='Normalizer']", context=mapping)
        return self.xpath("//TRANSFORMATION[@TYPE='Normalizer']")

    def find_expressions_containing(
        self,
        function_pattern: str,
        mapping_name: Optional[str] = None
    ) -> List[Dict[str, str]]:
        """
        Find expressions containing a specific function or pattern.

        Args:
            function_pattern: Function name or regex pattern to search for
            mapping_name: Optional mapping to scope search

        Returns:
            List of matching expressions with context
        """
        if mapping_name:
            expressions = self.get_transformation_expressions(mapping_name)
        else:
            expressions = []
            for mapping in self.get_mappings():
                mapping_name_val = mapping.get("NAME", "")
                expressions.extend(self.get_transformation_expressions(mapping_name_val))

        pattern = re.compile(function_pattern, re.IGNORECASE)
        return [expr for expr in expressions if pattern.search(expr.get("expression", ""))]

    def find_sql_overrides(self, mapping_name: Optional[str] = None) -> List[Dict[str, str]]:
        """Find all SQL overrides in source qualifiers."""
        sq_transforms = None
        if mapping_name:
            mapping = self.get_mapping(mapping_name)
            if mapping is not None:
                sq_transforms = self.xpath(
                    ".//TRANSFORMATION[@TYPE='Source Qualifier']",
                    context=mapping
                )
        if sq_transforms is None:
            sq_transforms = self.xpath("//TRANSFORMATION[@TYPE='Source Qualifier']")

        overrides = []
        for sq in sq_transforms:
            sql_query_attr = self.xpath(
                ".//TABLEATTRIBUTE[@NAME='Sql Query']",
                context=sq
            ).first()

            if sql_query_attr is not None:
                sql = sql_query_attr.get("VALUE", "")
                if sql.strip():
                    overrides.append({
                        "transformation": sq.get("NAME", ""),
                        "sql_override": sql
                    })

        return overrides

    # =========================================================================
    # Context Building Methods
    # =========================================================================

    def get_field_context(self, instance: str, field_name: str, mapping_name: str) -> Optional[FieldContext]:
        """
        Get full context for a field including datatype, expression, etc.

        Args:
            instance: Instance name
            field_name: Field name
            mapping_name: Mapping name

        Returns:
            FieldContext with full information or None
        """
        cache_key = f"{mapping_name}:{instance}:{field_name}"
        if cache_key in self._field_cache:
            return self._field_cache[cache_key]

        mapping = self.get_mapping(mapping_name)
        if mapping is None:
            return None

        # Find the instance
        inst_elem = self.xpath(f".//INSTANCE[@NAME='{instance}']", context=mapping).first()
        if inst_elem is None:
            return None

        inst_type = inst_elem.get("TYPE", "")
        trans_name = inst_elem.get("TRANSFORMATION_NAME", "")

        context = FieldContext(
            name=field_name,
            instance=instance,
            instance_type=inst_type
        )

        # Find field definition based on instance type
        if "Source" in inst_type:
            # Look in SOURCE definitions
            source_def = self.xpath(f"//SOURCE[@NAME='{trans_name}']").first()
            if source_def is None and trans_name.startswith("Shortcut_to_"):
                source_def = self.xpath(f"//SOURCE[@NAME='{trans_name[12:]}']").first()

            if source_def is not None:
                field_elem = self.xpath(
                    f".//SOURCEFIELD[@NAME='{field_name}']",
                    context=source_def
                ).first()
                if field_elem is not None:
                    context.datatype = field_elem.get("DATATYPE", "")
                    context.precision = int(field_elem.get("PRECISION", "0") or "0")
                    context.scale = int(field_elem.get("SCALE", "0") or "0")
                    context.source_definition = trans_name
                    context.is_input = True

        elif "Target" in inst_type:
            # Look in TARGET definitions
            target_def = self.xpath(f"//TARGET[@NAME='{trans_name}']").first()
            if target_def is None and trans_name.startswith("Shortcut_to_"):
                target_def = self.xpath(f"//TARGET[@NAME='{trans_name[12:]}']").first()

            if target_def is not None:
                field_elem = self.xpath(
                    f".//TARGETFIELD[@NAME='{field_name}']",
                    context=target_def
                ).first()
                if field_elem is not None:
                    context.datatype = field_elem.get("DATATYPE", "")
                    context.precision = int(field_elem.get("PRECISION", "0") or "0")
                    context.scale = int(field_elem.get("SCALE", "0") or "0")
                    context.target_definition = trans_name
                    context.is_output = True

        else:
            # Look in TRANSFORMATION definitions
            trans_def = self.xpath(f"//TRANSFORMATION[@NAME='{trans_name}']").first()
            if trans_def is not None:
                field_elem = self.xpath(
                    f".//TRANSFORMFIELD[@NAME='{field_name}']",
                    context=trans_def
                ).first()
                if field_elem is not None:
                    context.datatype = field_elem.get("DATATYPE", "")
                    context.precision = int(field_elem.get("PRECISION", "0") or "0")
                    context.scale = int(field_elem.get("SCALE", "0") or "0")
                    context.expression = field_elem.get("EXPRESSION", "")
                    context.parent_transformation = trans_name

                    port_type = field_elem.get("PORTTYPE", "").upper()
                    context.is_input = "INPUT" in port_type
                    context.is_output = "OUTPUT" in port_type

        self._field_cache[cache_key] = context
        return context

    def get_connector_contexts(self, mapping_name: str) -> List[ConnectorContext]:
        """
        Get all connectors in a mapping with full context.

        Args:
            mapping_name: Name of the mapping

        Returns:
            List of ConnectorContext with full field information
        """
        if mapping_name in self._connector_cache:
            return self._connector_cache[mapping_name]

        mapping = self.get_mapping(mapping_name)
        if mapping is None:
            return []

        connectors = self.xpath(".//CONNECTOR", context=mapping)
        contexts = []

        for conn in connectors:
            from_inst = conn.get("FROMINSTANCE", "")
            from_field = conn.get("FROMFIELD", "")
            to_inst = conn.get("TOINSTANCE", "")
            to_field = conn.get("TOFIELD", "")

            ctx = ConnectorContext(
                from_instance=from_inst,
                from_field=from_field,
                from_instance_type=conn.get("FROMINSTANCETYPE", ""),
                to_instance=to_inst,
                to_field=to_field,
                to_instance_type=conn.get("TOINSTANCETYPE", ""),
                mapping_name=mapping_name
            )

            # Enrich with field context
            ctx.from_field_context = self.get_field_context(from_inst, from_field, mapping_name)
            ctx.to_field_context = self.get_field_context(to_inst, to_field, mapping_name)

            contexts.append(ctx)

        self._connector_cache[mapping_name] = contexts
        return contexts

    # =========================================================================
    # Analysis Helper Methods
    # =========================================================================

    def get_mapping_statistics(self, mapping_name: str) -> Dict[str, Any]:
        """
        Get comprehensive statistics for a mapping.

        Args:
            mapping_name: Name of the mapping

        Returns:
            Dictionary with mapping statistics
        """
        mapping = self.get_mapping(mapping_name)
        if mapping is None:
            return {}

        # Count transformations by type
        trans_types: Dict[str, int] = {}
        for trans in self.xpath(".//TRANSFORMATION", context=mapping):
            trans_type = trans.get("TYPE", "Unknown")
            trans_types[trans_type] = trans_types.get(trans_type, 0) + 1

        # Count connectors
        connectors = self.xpath(".//CONNECTOR", context=mapping)

        # Count instances by type
        inst_types: Dict[str, int] = {}
        for inst in self.xpath(".//INSTANCE", context=mapping):
            inst_type = inst.get("TYPE", "Unknown")
            inst_types[inst_type] = inst_types.get(inst_type, 0) + 1

        # Count expressions
        expressions = self.xpath(".//TRANSFORMFIELD[@EXPRESSION]", context=mapping)

        # Find unmapped fields
        unmapped = self.find_unmapped_target_fields(mapping_name)

        return {
            "mapping_name": mapping_name,
            "transformation_count": sum(trans_types.values()),
            "transformation_types": trans_types,
            "connector_count": len(connectors),
            "instance_count": sum(inst_types.values()),
            "instance_types": inst_types,
            "expression_count": len(expressions),
            "unmapped_target_fields": len(unmapped),
            "has_filters": trans_types.get("Filter", 0) > 0,
            "has_aggregators": trans_types.get("Aggregator", 0) > 0,
            "has_lookups": trans_types.get("Lookup Procedure", 0) > 0,
            "has_joiners": trans_types.get("Joiner", 0) > 0,
            "has_normalizers": trans_types.get("Normalizer", 0) > 0,
        }

    def validate_connectors(self, mapping_name: str) -> List[Dict[str, str]]:
        """
        Validate all connectors in a mapping.

        Checks for:
        - Missing source instances
        - Missing target instances
        - Invalid field references

        Args:
            mapping_name: Name of the mapping

        Returns:
            List of validation issues
        """
        mapping = self.get_mapping(mapping_name)
        if mapping is None:
            return [{"error": f"Mapping '{mapping_name}' not found"}]

        issues = []

        # Get all instances
        instances = {
            inst.get("NAME", "").lower(): inst
            for inst in self.xpath(".//INSTANCE", context=mapping)
        }

        # Check each connector
        for conn in self.xpath(".//CONNECTOR", context=mapping):
            from_inst = conn.get("FROMINSTANCE", "")
            to_inst = conn.get("TOINSTANCE", "")

            if from_inst.lower() not in instances:
                issues.append({
                    "type": "missing_from_instance",
                    "connector": f"{from_inst}.{conn.get('FROMFIELD', '')} -> {to_inst}.{conn.get('TOFIELD', '')}",
                    "message": f"From instance '{from_inst}' not found in mapping"
                })

            if to_inst.lower() not in instances:
                issues.append({
                    "type": "missing_to_instance",
                    "connector": f"{from_inst}.{conn.get('FROMFIELD', '')} -> {to_inst}.{conn.get('TOFIELD', '')}",
                    "message": f"To instance '{to_inst}' not found in mapping"
                })

        return issues

    # =========================================================================
    # Utility Methods
    # =========================================================================

    def element_to_dict(self, element: etree._Element, include_children: bool = True) -> Dict[str, Any]:
        """Convert lxml element to dictionary."""
        result = {"_tag": element.tag}
        result.update(dict(element.attrib))

        if include_children:
            children = list(element)
            if children:
                result["_children"] = [
                    self.element_to_dict(child, include_children)
                    for child in children
                ]

        if element.text and element.text.strip():
            result["_text"] = element.text.strip()

        return result

    def get_attr(self, element: etree._Element, name: str, default: str = "") -> str:
        """Get attribute value with whitespace handling."""
        value = element.get(name, default)
        return value.strip() if value else default

    def get_attr_bool(self, element: etree._Element, name: str, default: bool = False) -> bool:
        """Get attribute as boolean."""
        value = self.get_attr(element, name, "").upper()
        if value in ["YES", "TRUE", "1"]:
            return True
        if value in ["NO", "FALSE", "0"]:
            return False
        return default

    def get_attr_int(self, element: etree._Element, name: str, default: int = 0) -> int:
        """Get attribute as integer."""
        value = self.get_attr(element, name, "")
        try:
            return int(value) if value else default
        except ValueError:
            return default

    def clear_cache(self) -> None:
        """Clear all caches."""
        self._xpath_cache.clear()
        self._field_cache.clear()
        self._connector_cache.clear()

    # =========================================================================
    # Phase 4: Saxon XPath 2.0/3.0 Methods
    # =========================================================================

    def is_saxon_enabled(self) -> bool:
        """Check if Saxon XPath 2.0/3.0 is available and enabled."""
        return self._use_saxon and self._saxon_provider is not None

    def get_xpath_version(self) -> str:
        """Get the current XPath version being used."""
        if self.is_saxon_enabled() and hasattr(self._saxon_provider, 'get_version'):
            return self._saxon_provider.get_version().value
        return "1.0"

    def xpath_2(
        self,
        query: str,
        context: Optional[etree._Element] = None
    ) -> "XPathQueryResult":
        """
        Execute an XPath 2.0/3.0 query using Saxon.

        Falls back to XPath 1.0 (lxml) if Saxon is not available.

        Args:
            query: XPath 2.0/3.0 expression
            context: Optional context element

        Returns:
            XPathQueryResult with results

        Example:
            # Using XPath 2.0 matches() function
            result = parser.xpath_2("//TRANSFORMFIELD[matches(@EXPRESSION, 'IIF.*IIF', 'i')]")
        """
        if not PHASE4_AVAILABLE:
            # Fall back to lxml
            lxml_result = self.xpath(query, context)
            return XPathResult(
                elements=lxml_result.elements,
                query=query,
                count=lxml_result.count
            )

        if self.is_saxon_enabled():
            return self._saxon_provider.query(query, context)
        else:
            # Fall back to lxml XPath 1.0
            lxml_result = self.xpath(query, context)
            return XPathQueryResult(
                values=lxml_result.elements,
                query=query,
                count=lxml_result.count,
                xpath_version=XPathVersion.XPATH_1_0 if XPathVersion else None,
                provider="lxml"
            )

    def query_pattern(
        self,
        pattern: "XPath2Pattern",
        mapping_name: Optional[str] = None
    ) -> List[Dict[str, Any]]:
        """
        Execute an Informatica XPath 2.0 pattern.

        Automatically selects XPath 2.0 or 1.0 based on availability.

        Args:
            pattern: XPath2Pattern instance
            mapping_name: Optional mapping to scope the query

        Returns:
            List of matching element information
        """
        if not PHASE4_AVAILABLE:
            return []

        # Select appropriate XPath based on provider
        if self.is_saxon_enabled():
            xpath = pattern.xpath_2
        else:
            xpath = pattern.xpath_1

        # Execute query
        if self.is_saxon_enabled():
            result = self._saxon_provider.query(xpath)
            elements = result.values
        else:
            result = self.xpath(xpath)
            elements = result.elements

        # Convert to dictionaries
        results = []
        for elem in elements:
            if hasattr(elem, 'attrib'):
                # lxml element
                results.append({
                    "tag": elem.tag,
                    "name": elem.get("NAME", ""),
                    "type": elem.get("TYPE", ""),
                    "expression": elem.get("EXPRESSION", ""),
                    **dict(elem.attrib)
                })
            elif hasattr(elem, 'string_value'):
                # Saxon XDM value
                results.append({"value": elem.string_value})
            else:
                results.append({"value": str(elem)})

        return results

    def find_expressions_matching(
        self,
        pattern: str,
        mapping_name: Optional[str] = None,
        use_regex: bool = True
    ) -> List[Dict[str, str]]:
        """
        Find expressions matching a pattern using XPath 2.0 regex if available.

        Args:
            pattern: Search pattern (regex if use_regex=True)
            mapping_name: Optional mapping to scope search
            use_regex: If True and Saxon available, use regex matching

        Returns:
            List of matching expressions with context
        """
        if self.is_saxon_enabled() and use_regex and PHASE4_AVAILABLE:
            # Use XPath 2.0 matches() function
            if mapping_name:
                mapping = self.get_mapping(mapping_name)
                if mapping is None:
                    return []
                xpath = f".//TRANSFORMFIELD[matches(@EXPRESSION, '{pattern}', 'i')]"
                result = self._saxon_provider.query(xpath)
            else:
                xpath = f"//TRANSFORMFIELD[matches(@EXPRESSION, '{pattern}', 'i')]"
                result = self._saxon_provider.query(xpath)

            matches = []
            for elem in result.values:
                if hasattr(elem, 'get'):
                    parent = elem.getparent()
                    matches.append({
                        "transformation": parent.get("NAME", "") if parent is not None else "",
                        "transformation_type": parent.get("TYPE", "") if parent is not None else "",
                        "field_name": elem.get("NAME", ""),
                        "expression": elem.get("EXPRESSION", ""),
                    })
            return matches
        else:
            # Fall back to XPath 1.0 contains()
            return self.find_expressions_containing(pattern, mapping_name)

    def tokenize_expression(self, expression: str, delimiter: str = ",") -> List[str]:
        """
        Tokenize an expression using XPath 2.0 tokenize() if available.

        Args:
            expression: Expression to tokenize
            delimiter: Delimiter regex pattern

        Returns:
            List of tokens
        """
        if self.is_saxon_enabled() and hasattr(self._saxon_provider, 'tokenize'):
            return self._saxon_provider.tokenize(expression, delimiter)
        else:
            # Fall back to Python split
            import re as regex_module
            return regex_module.split(delimiter, expression)

    def analyze_expression_complexity(
        self,
        mapping_name: str
    ) -> List[Dict[str, Any]]:
        """
        Analyze expression complexity using XPath 2.0 functions.

        Returns expressions ranked by complexity metrics.

        Args:
            mapping_name: Name of the mapping

        Returns:
            List of expressions with complexity metrics
        """
        expressions = self.get_transformation_expressions(mapping_name)

        results = []
        for expr in expressions:
            expr_text = expr.get("expression", "")

            # Calculate complexity metrics
            metrics = {
                "length": len(expr_text),
                "function_count": 0,
                "nesting_depth": 0,
                "operator_count": 0,
            }

            # Count function calls
            if self.is_saxon_enabled() and hasattr(self._saxon_provider, 'tokenize'):
                # Use Saxon tokenize for more accurate counting
                tokens = self._saxon_provider.tokenize(expr_text, r'\(')
                metrics["function_count"] = len(tokens) - 1
            else:
                # Simple count
                metrics["function_count"] = expr_text.count('(')

            # Calculate nesting depth
            depth = 0
            max_depth = 0
            for char in expr_text:
                if char == '(':
                    depth += 1
                    max_depth = max(max_depth, depth)
                elif char == ')':
                    depth -= 1
            metrics["nesting_depth"] = max_depth

            # Count operators
            for op in ['+', '-', '*', '/', '||', '=', '<', '>', '!=']:
                metrics["operator_count"] += expr_text.count(op)

            # Calculate overall complexity score
            metrics["complexity_score"] = (
                metrics["length"] / 10 +
                metrics["function_count"] * 5 +
                metrics["nesting_depth"] * 3 +
                metrics["operator_count"] * 2
            )

            results.append({
                **expr,
                "complexity": metrics
            })

        # Sort by complexity score
        results.sort(key=lambda x: x["complexity"]["complexity_score"], reverse=True)

        return results

    def get_xpath2_patterns(self) -> Optional[type]:
        """
        Get the InformaticaXPath2Patterns class for advanced queries.

        Returns:
            InformaticaXPath2Patterns class or None if not available
        """
        if PHASE4_AVAILABLE:
            return InformaticaXPath2Patterns
        return None

    def close(self) -> None:
        """Release resources including Saxon processor."""
        self.clear_cache()
        if self._saxon_provider and hasattr(self._saxon_provider, 'close'):
            self._saxon_provider.close()
            self._saxon_provider = None


# Convenience functions for backward compatibility
def parse_xml_file_xdm(file_path: Union[str, Path]) -> etree._Element:
    """Parse XML file using lxml (drop-in replacement for ET version)."""
    parser = XDMXMLParser(file_path)
    return parser.root


def get_attr(element: etree._Element, name: str, default: str = "") -> str:
    """Get attribute value (compatible with both ET and lxml elements)."""
    value = element.get(name, default)
    return value.strip() if value else default


def get_attr_bool(element: etree._Element, name: str, default: bool = False) -> bool:
    """Get attribute as boolean."""
    value = get_attr(element, name, "").upper()
    if value in ["YES", "TRUE", "1"]:
        return True
    if value in ["NO", "FALSE", "0"]:
        return False
    return default


def get_attr_int(element: etree._Element, name: str, default: int = 0) -> int:
    """Get attribute as integer."""
    value = get_attr(element, name, "")
    try:
        return int(value) if value else default
    except ValueError:
        return default
