"""XML utility functions for Informatica parsing."""

import os
import xml.etree.ElementTree as ET
import defusedxml.ElementTree as DefusedET
from typing import Any, Dict, List, Optional, Union
from pathlib import Path


def get_attr(element: ET.Element, name: str, default: str = "") -> str:
    """
    Get attribute value from XML element, handling whitespace.

    Args:
        element: XML element
        name: Attribute name
        default: Default value if attribute not found

    Returns:
        Attribute value or default
    """
    value = element.get(name, default)
    if value is None:
        return default
    return value.strip()


def get_attr_bool(element: ET.Element, name: str, default: bool = False) -> bool:
    """Get attribute as boolean (YES/NO or TRUE/FALSE)."""
    value = get_attr(element, name, "").upper()
    if value in ["YES", "TRUE", "1"]:
        return True
    if value in ["NO", "FALSE", "0"]:
        return False
    return default


def get_attr_int(element: ET.Element, name: str, default: int = 0) -> int:
    """Get attribute as integer."""
    value = get_attr(element, name, "")
    try:
        return int(value) if value else default
    except ValueError:
        return default


def get_child_text(element: ET.Element, tag: str, default: str = "") -> str:
    """Get text content of a child element."""
    child = element.find(tag)
    if child is not None and child.text:
        return child.text.strip()
    return default


def parse_xml_file(file_path: Union[str, Path]) -> ET.Element:
    """
    Parse an XML file and return the root element.

    Args:
        file_path: Path to XML file

    Returns:
        Root Element of the parsed XML

    Raises:
        FileNotFoundError: If file doesn't exist
        ET.ParseError: If XML is invalid
    """
    safe_path = os.path.realpath(file_path)
    if ".." in str(file_path):
        raise ValueError(f"Path traversal detected: {file_path}")
    if not os.path.exists(safe_path):
        raise FileNotFoundError(f"XML file not found: {safe_path}")

    # Try different encodings
    encodings = ["utf-8", "windows-1252", "cp1252", "latin-1"]

    for encoding in encodings:
        try:
            with open(safe_path, "r", encoding=encoding) as f:
                content = f.read()
            # Remove BOM if present
            if content.startswith('\ufeff'):
                content = content[1:]
            return DefusedET.fromstring(content)
        except (UnicodeDecodeError, ET.ParseError):
            continue

    # Last resort: read as binary and decode
    with open(safe_path, "rb") as f:
        content = f.read()
    # Try to detect encoding from XML declaration
    content_str = content.decode("utf-8", errors="replace")
    return DefusedET.fromstring(content_str)


def find_all_recursive(element: ET.Element, tag: str) -> List[ET.Element]:
    """Find all elements with tag recursively."""
    return list(element.iter(tag))


def element_to_dict(element: ET.Element) -> Dict[str, Any]:
    """Convert XML element to dictionary."""
    result = {"_tag": element.tag}
    result.update(element.attrib)

    children = list(element)
    if children:
        result["_children"] = [element_to_dict(child) for child in children]

    if element.text and element.text.strip():
        result["_text"] = element.text.strip()

    return result


def clean_expression(expression: str) -> str:
    """Clean and normalize an expression string."""
    if not expression:
        return ""
    # Remove excessive whitespace
    result = " ".join(expression.split())
    return result


def decode_xml_entities(text: str) -> str:
    """Decode XML entities in text."""
    if not text:
        return ""
    replacements = {
        "&amp;": "&",
        "&lt;": "<",
        "&gt;": ">",
        "&quot;": '"',
        "&apos;": "'",
        "&#xD;": "\r",
        "&#xA;": "\n",
        "&#x9;": "\t",
    }
    result = text
    for entity, char in replacements.items():
        result = result.replace(entity, char)
    return result
