"""Path and data sanitization utilities for security (CWE-23, CWE-1236)."""

import os
from pathlib import Path
from typing import Any, Dict, List, Union

_FORMULA_PREFIXES = ("=", "+", "-", "@")


def sanitize_path(user_input: Union[str, Path]) -> Path:
    """Resolve a user-supplied path, blocking directory traversal.

    Converts the path to its canonical absolute form and rejects
    inputs that contain '..' components, which could escape the
    intended directory boundary.

    Raises:
        ValueError: If the raw input contains '..' traversal segments.
    """
    raw = Path(user_input)
    for part in raw.parts:
        if part == "..":
            raise ValueError(
                f"Directory traversal detected in path: {user_input}"
            )
    return raw.resolve()


def safe_join(base_dir: Union[str, Path], filename: str) -> Path:
    """Safely join a base directory with a filename.

    Ensures the resulting path stays within *base_dir* after resolution.

    Raises:
        ValueError: If the joined path escapes the base directory.
    """
    base = Path(base_dir).resolve()
    target = (base / filename).resolve()
    if not str(target).startswith(str(base) + os.sep) and target != base:
        raise ValueError(
            f"Path escapes base directory: {filename} resolves outside {base}"
        )
    return target


def sanitize_csv_value(value: Any) -> Any:
    """Neutralize formula injection in a single cell value (CWE-1236).

    If a string value starts with ``=``, ``+``, ``-``, or ``@`` it could be
    interpreted as a formula by spreadsheet software.  Prepending a single
    quote prevents execution while preserving the visible content.
    """
    if isinstance(value, str) and value and value[0] in _FORMULA_PREFIXES:
        return "'" + value
    return value


def sanitize_csv_row(row: Dict[str, Any]) -> Dict[str, Any]:
    """Sanitize all values in a CSV dict-row against formula injection."""
    return {k: sanitize_csv_value(v) for k, v in row.items()}
