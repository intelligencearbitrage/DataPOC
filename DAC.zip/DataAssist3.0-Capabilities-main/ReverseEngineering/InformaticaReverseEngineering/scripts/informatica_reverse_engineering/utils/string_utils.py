"""String utility functions."""

import re
from typing import Optional


def clean_text(text: Optional[str]) -> str:
    """Clean text by removing excessive whitespace."""
    if not text:
        return ""
    return " ".join(text.split())


def normalize_name(name: str) -> str:
    """Normalize a name for comparison (lowercase, no special chars)."""
    if not name:
        return ""
    return re.sub(r'[^a-z0-9_]', '_', name.lower())


def truncate(text: str, max_length: int = 100, suffix: str = "...") -> str:
    """Truncate text to max length with suffix."""
    if not text or len(text) <= max_length:
        return text
    return text[:max_length - len(suffix)] + suffix


def to_snake_case(name: str) -> str:
    """Convert PascalCase or camelCase to snake_case."""
    if not name:
        return ""
    s1 = re.sub('(.)([A-Z][a-z]+)', r'\1_\2', name)
    return re.sub('([a-z0-9])([A-Z])', r'\1_\2', s1).lower()


def to_title_case(name: str) -> str:
    """Convert snake_case to Title Case."""
    if not name:
        return ""
    return " ".join(word.capitalize() for word in name.replace("_", " ").split())


def escape_for_excel(text: str) -> str:
    """Escape text for safe Excel output."""
    if not text:
        return ""
    # Escape formulas that start with =, +, -, @
    if text and text[0] in ['=', '+', '-', '@']:
        return "'" + text
    return text


def extract_function_name(expression: str) -> Optional[str]:
    """Extract the main function name from an expression."""
    if not expression:
        return None
    # Match function name at start: FUNC_NAME(...)
    match = re.match(r'^([A-Z_][A-Z0-9_]*)\s*\(', expression.strip(), re.IGNORECASE)
    if match:
        return match.group(1).upper()
    return None


def split_qualified_name(name: str) -> tuple:
    """Split qualified name into parts (schema.table -> (schema, table))."""
    if not name:
        return ("", "")
    parts = name.split(".")
    if len(parts) == 1:
        return ("", parts[0])
    if len(parts) == 2:
        return (parts[0], parts[1])
    # More than 2 parts: db.schema.table
    return (".".join(parts[:-1]), parts[-1])
