"""
XPath Query Builder for Informatica PowerCenter XML.

Provides a fluent interface for building complex XPath queries
specific to Informatica PowerCenter XML exports.

This module enables pattern-based queries similar to AST visitors
for SQL parsing, allowing detection of complex transformation
patterns and lineage paths.
"""

from dataclasses import dataclass, field
from typing import List, Optional, Set, Dict, Any
from enum import Enum


class TransformationType(Enum):
    """Informatica transformation types."""
    SOURCE_QUALIFIER = "Source Qualifier"
    EXPRESSION = "Expression"
    FILTER = "Filter"
    AGGREGATOR = "Aggregator"
    LOOKUP = "Lookup Procedure"
    JOINER = "Joiner"
    ROUTER = "Router"
    NORMALIZER = "Normalizer"
    UPDATE_STRATEGY = "Update Strategy"
    SEQUENCE = "Sequence Generator"
    SORTER = "Sorter"
    UNION = "Union"
    RANK = "Rank"
    SQL_TRANSFORM = "SQL Transformation"
    STORED_PROCEDURE = "Stored Procedure"
    CUSTOM = "Custom Transformation"


class InstanceType(Enum):
    """Informatica instance types."""
    SOURCE_DEFINITION = "Source Definition"
    TARGET_DEFINITION = "Target Definition"
    SOURCE_QUALIFIER = "Source Qualifier"
    TRANSFORMATION = "Transformation"


class PortType(Enum):
    """Transformation port types."""
    INPUT = "INPUT"
    OUTPUT = "OUTPUT"
    INPUT_OUTPUT = "INPUT/OUTPUT"
    LOOKUP_OUTPUT = "LOOKUP/OUTPUT"
    PASS_THROUGH = "PASS-THROUGH"


@dataclass
class XPathQuery:
    """
    Represents a built XPath query with metadata.

    Attributes:
        xpath: The XPath expression string
        description: Human-readable description of what this query finds
        returns_type: Type of elements this query returns
        parameters: Named parameters that were substituted into the query
    """
    xpath: str
    description: str = ""
    returns_type: str = "elements"
    parameters: Dict[str, str] = field(default_factory=dict)

    def __str__(self) -> str:
        return self.xpath


class InformaticaXPathBuilder:
    """
    Fluent builder for Informatica-specific XPath queries.

    Example usage:
        builder = InformaticaXPathBuilder()

        # Find all filters in a mapping
        query = builder.in_mapping("m_MyMapping").transformations().of_type(Filter).build()

        # Find unmapped target fields
        query = builder.in_mapping("m_MyMapping").target_fields().without_incoming_connector().build()

        # Find complex transformation chains
        query = builder.in_mapping("m_MyMapping").connectors().from_type(Filter).to_type(Aggregator).build()
    """

    def __init__(self):
        self._parts: List[str] = []
        self._predicates: List[str] = []
        self._context: str = ""
        self._mapping_name: Optional[str] = None
        self._description_parts: List[str] = []
        self._parameters: Dict[str, str] = {}

    def reset(self) -> "InformaticaXPathBuilder":
        """Reset the builder for a new query."""
        self._parts = []
        self._predicates = []
        self._context = ""
        self._mapping_name = None
        self._description_parts = []
        self._parameters = {}
        return self

    # =========================================================================
    # Context Methods
    # =========================================================================

    def in_mapping(self, mapping_name: str) -> "InformaticaXPathBuilder":
        """Scope query to a specific mapping."""
        self._mapping_name = mapping_name
        self._context = f"//MAPPING[@NAME='{mapping_name}']"
        self._description_parts.append(f"in mapping '{mapping_name}'")
        self._parameters["mapping_name"] = mapping_name
        return self

    def in_any_mapping(self) -> "InformaticaXPathBuilder":
        """Scope query to all mappings."""
        self._context = "//MAPPING"
        self._description_parts.append("in all mappings")
        return self

    def in_workflow(self, workflow_name: str) -> "InformaticaXPathBuilder":
        """Scope query to a specific workflow."""
        self._context = f"//WORKFLOW[@NAME='{workflow_name}']"
        self._description_parts.append(f"in workflow '{workflow_name}'")
        self._parameters["workflow_name"] = workflow_name
        return self

    def in_session(self, session_name: str) -> "InformaticaXPathBuilder":
        """Scope query to a specific session."""
        self._context = f"//SESSION[@NAME='{session_name}']"
        self._description_parts.append(f"in session '{session_name}'")
        self._parameters["session_name"] = session_name
        return self

    def anywhere(self) -> "InformaticaXPathBuilder":
        """Query entire document without scope."""
        self._context = ""
        self._description_parts.append("anywhere in document")
        return self

    # =========================================================================
    # Element Selection Methods
    # =========================================================================

    def transformations(self) -> "InformaticaXPathBuilder":
        """Select TRANSFORMATION elements."""
        self._parts.append(".//TRANSFORMATION")
        self._description_parts.append("transformations")
        return self

    def sources(self) -> "InformaticaXPathBuilder":
        """Select SOURCE elements."""
        self._parts.append("//SOURCE")
        self._description_parts.append("sources")
        return self

    def targets(self) -> "InformaticaXPathBuilder":
        """Select TARGET elements."""
        self._parts.append("//TARGET")
        self._description_parts.append("targets")
        return self

    def source_fields(self) -> "InformaticaXPathBuilder":
        """Select SOURCEFIELD elements."""
        self._parts.append(".//SOURCEFIELD")
        self._description_parts.append("source fields")
        return self

    def target_fields(self) -> "InformaticaXPathBuilder":
        """Select TARGETFIELD elements."""
        self._parts.append(".//TARGETFIELD")
        self._description_parts.append("target fields")
        return self

    def transform_fields(self) -> "InformaticaXPathBuilder":
        """Select TRANSFORMFIELD elements."""
        self._parts.append(".//TRANSFORMFIELD")
        self._description_parts.append("transform fields")
        return self

    def connectors(self) -> "InformaticaXPathBuilder":
        """Select CONNECTOR elements."""
        self._parts.append(".//CONNECTOR")
        self._description_parts.append("connectors")
        return self

    def instances(self) -> "InformaticaXPathBuilder":
        """Select INSTANCE elements."""
        self._parts.append(".//INSTANCE")
        self._description_parts.append("instances")
        return self

    def table_attributes(self) -> "InformaticaXPathBuilder":
        """Select TABLEATTRIBUTE elements."""
        self._parts.append(".//TABLEATTRIBUTE")
        self._description_parts.append("table attributes")
        return self

    def mapping_variables(self) -> "InformaticaXPathBuilder":
        """Select MAPPINGVARIABLE elements."""
        self._parts.append(".//MAPPINGVARIABLE")
        self._description_parts.append("mapping variables")
        return self

    def sessions(self) -> "InformaticaXPathBuilder":
        """Select SESSION elements."""
        self._parts.append(".//SESSION")
        self._description_parts.append("sessions")
        return self

    def tasks(self) -> "InformaticaXPathBuilder":
        """Select TASK elements."""
        self._parts.append(".//TASK")
        self._description_parts.append("tasks")
        return self

    def workflow_links(self) -> "InformaticaXPathBuilder":
        """Select WORKFLOWLINK elements."""
        self._parts.append(".//WORKFLOWLINK")
        self._description_parts.append("workflow links")
        return self

    # =========================================================================
    # Filter/Predicate Methods
    # =========================================================================

    def of_type(self, trans_type: TransformationType) -> "InformaticaXPathBuilder":
        """Filter transformations by type."""
        self._predicates.append(f"@TYPE='{trans_type.value}'")
        self._description_parts.append(f"of type {trans_type.value}")
        self._parameters["transformation_type"] = trans_type.value
        return self

    def of_instance_type(self, inst_type: InstanceType) -> "InformaticaXPathBuilder":
        """Filter instances by type."""
        self._predicates.append(f"@TYPE='{inst_type.value}'")
        self._description_parts.append(f"of instance type {inst_type.value}")
        return self

    def named(self, name: str) -> "InformaticaXPathBuilder":
        """Filter elements by NAME attribute."""
        self._predicates.append(f"@NAME='{name}'")
        self._description_parts.append(f"named '{name}'")
        self._parameters["name"] = name
        return self

    def name_contains(self, pattern: str) -> "InformaticaXPathBuilder":
        """Filter elements where NAME contains pattern."""
        self._predicates.append(f"contains(@NAME, '{pattern}')")
        self._description_parts.append(f"with name containing '{pattern}'")
        return self

    def name_starts_with(self, prefix: str) -> "InformaticaXPathBuilder":
        """Filter elements where NAME starts with prefix."""
        self._predicates.append(f"starts-with(@NAME, '{prefix}')")
        self._description_parts.append(f"with name starting with '{prefix}'")
        return self

    def with_attribute(self, attr_name: str, attr_value: Optional[str] = None) -> "InformaticaXPathBuilder":
        """Filter elements having a specific attribute."""
        if attr_value is not None:
            self._predicates.append(f"@{attr_name}='{attr_value}'")
            self._description_parts.append(f"with {attr_name}='{attr_value}'")
        else:
            self._predicates.append(f"@{attr_name}")
            self._description_parts.append(f"having attribute {attr_name}")
        return self

    def with_expression(self) -> "InformaticaXPathBuilder":
        """Filter fields that have an EXPRESSION attribute."""
        self._predicates.append("@EXPRESSION")
        self._description_parts.append("with expression")
        return self

    def expression_contains(self, pattern: str) -> "InformaticaXPathBuilder":
        """Filter fields where expression contains pattern."""
        self._predicates.append(f"contains(@EXPRESSION, '{pattern}')")
        self._description_parts.append(f"where expression contains '{pattern}'")
        return self

    def with_port_type(self, port_type: PortType) -> "InformaticaXPathBuilder":
        """Filter fields by port type."""
        self._predicates.append(f"@PORTTYPE='{port_type.value}'")
        self._description_parts.append(f"with port type {port_type.value}")
        return self

    def with_datatype(self, datatype: str) -> "InformaticaXPathBuilder":
        """Filter fields by datatype."""
        self._predicates.append(f"@DATATYPE='{datatype}'")
        self._description_parts.append(f"of datatype {datatype}")
        return self

    # =========================================================================
    # Connector-Specific Filters
    # =========================================================================

    def from_instance(self, instance_name: str) -> "InformaticaXPathBuilder":
        """Filter connectors by source instance."""
        self._predicates.append(f"@FROMINSTANCE='{instance_name}'")
        self._description_parts.append(f"from instance '{instance_name}'")
        return self

    def to_instance(self, instance_name: str) -> "InformaticaXPathBuilder":
        """Filter connectors by target instance."""
        self._predicates.append(f"@TOINSTANCE='{instance_name}'")
        self._description_parts.append(f"to instance '{instance_name}'")
        return self

    def from_instance_type(self, inst_type: str) -> "InformaticaXPathBuilder":
        """Filter connectors by source instance type."""
        self._predicates.append(f"@FROMINSTANCETYPE='{inst_type}'")
        self._description_parts.append(f"from instance type '{inst_type}'")
        return self

    def to_instance_type(self, inst_type: str) -> "InformaticaXPathBuilder":
        """Filter connectors by target instance type."""
        self._predicates.append(f"@TOINSTANCETYPE='{inst_type}'")
        self._description_parts.append(f"to instance type '{inst_type}'")
        return self

    def from_field(self, field_name: str) -> "InformaticaXPathBuilder":
        """Filter connectors by source field."""
        self._predicates.append(f"@FROMFIELD='{field_name}'")
        self._description_parts.append(f"from field '{field_name}'")
        return self

    def to_field(self, field_name: str) -> "InformaticaXPathBuilder":
        """Filter connectors by target field."""
        self._predicates.append(f"@TOFIELD='{field_name}'")
        self._description_parts.append(f"to field '{field_name}'")
        return self

    # =========================================================================
    # Negation and Existence Methods
    # =========================================================================

    def without_incoming_connector(self) -> "InformaticaXPathBuilder":
        """
        Filter fields that have no incoming connector.
        Used to find unmapped target fields.
        """
        # This creates a more complex predicate
        self._predicates.append(
            "not(ancestor::MAPPING//CONNECTOR[@TOFIELD=current()/@NAME])"
        )
        self._description_parts.append("without incoming connector")
        return self

    def without_outgoing_connector(self) -> "InformaticaXPathBuilder":
        """Filter fields that have no outgoing connector."""
        self._predicates.append(
            "not(ancestor::MAPPING//CONNECTOR[@FROMFIELD=current()/@NAME])"
        )
        self._description_parts.append("without outgoing connector")
        return self

    def not_matching(self, predicate: str) -> "InformaticaXPathBuilder":
        """Add a negated predicate."""
        self._predicates.append(f"not({predicate})")
        self._description_parts.append(f"not matching: {predicate}")
        return self

    def exists(self, child_path: str) -> "InformaticaXPathBuilder":
        """Filter elements that have a specific child."""
        self._predicates.append(child_path)
        self._description_parts.append(f"containing {child_path}")
        return self

    # =========================================================================
    # Counting and Comparison Methods
    # =========================================================================

    def with_count_greater_than(self, child_path: str, count: int) -> "InformaticaXPathBuilder":
        """Filter elements where child count exceeds threshold."""
        self._predicates.append(f"count({child_path}) > {count}")
        self._description_parts.append(f"with more than {count} {child_path}")
        return self

    def with_count_less_than(self, child_path: str, count: int) -> "InformaticaXPathBuilder":
        """Filter elements where child count is below threshold."""
        self._predicates.append(f"count({child_path}) < {count}")
        self._description_parts.append(f"with fewer than {count} {child_path}")
        return self

    def with_count_equals(self, child_path: str, count: int) -> "InformaticaXPathBuilder":
        """Filter elements where child count equals value."""
        self._predicates.append(f"count({child_path}) = {count}")
        self._description_parts.append(f"with exactly {count} {child_path}")
        return self

    # =========================================================================
    # Custom Predicate Methods
    # =========================================================================

    def where(self, predicate: str) -> "InformaticaXPathBuilder":
        """Add a custom predicate."""
        self._predicates.append(predicate)
        self._description_parts.append(f"where {predicate}")
        return self

    def and_(self) -> "InformaticaXPathBuilder":
        """Explicit AND (predicates are ANDed by default)."""
        return self

    def or_predicate(self, predicate: str) -> "InformaticaXPathBuilder":
        """Add an OR predicate to the last predicate."""
        if self._predicates:
            last = self._predicates.pop()
            self._predicates.append(f"({last} or {predicate})")
        else:
            self._predicates.append(predicate)
        return self

    # =========================================================================
    # Axis Methods
    # =========================================================================

    def parent(self) -> "InformaticaXPathBuilder":
        """Navigate to parent element."""
        self._parts.append("/..")
        self._description_parts.append("parent")
        return self

    def ancestors(self, element_name: Optional[str] = None) -> "InformaticaXPathBuilder":
        """Navigate to ancestors."""
        if element_name:
            self._parts.append(f"/ancestor::{element_name}")
        else:
            self._parts.append("/ancestor::*")
        self._description_parts.append(f"ancestors{' ' + element_name if element_name else ''}")
        return self

    def descendants(self, element_name: Optional[str] = None) -> "InformaticaXPathBuilder":
        """Navigate to descendants."""
        if element_name:
            self._parts.append(f"//descendant::{element_name}")
        else:
            self._parts.append("//descendant::*")
        self._description_parts.append(f"descendants{' ' + element_name if element_name else ''}")
        return self

    def following_sibling(self, element_name: Optional[str] = None) -> "InformaticaXPathBuilder":
        """Navigate to following siblings."""
        if element_name:
            self._parts.append(f"/following-sibling::{element_name}")
        else:
            self._parts.append("/following-sibling::*")
        return self

    def preceding_sibling(self, element_name: Optional[str] = None) -> "InformaticaXPathBuilder":
        """Navigate to preceding siblings."""
        if element_name:
            self._parts.append(f"/preceding-sibling::{element_name}")
        else:
            self._parts.append("/preceding-sibling::*")
        return self

    # =========================================================================
    # Output Methods
    # =========================================================================

    def select_attribute(self, attr_name: str) -> "InformaticaXPathBuilder":
        """Select an attribute instead of the element."""
        self._parts.append(f"/@{attr_name}")
        self._description_parts.append(f"select attribute {attr_name}")
        return self

    def select_text(self) -> "InformaticaXPathBuilder":
        """Select text content."""
        self._parts.append("/text()")
        self._description_parts.append("select text content")
        return self

    # =========================================================================
    # Build Methods
    # =========================================================================

    def build(self) -> XPathQuery:
        """
        Build the final XPath query.

        Returns:
            XPathQuery with the constructed expression
        """
        # Start with context
        xpath = self._context

        # Add element path with predicates
        if self._parts:
            element_path = self._parts[0]

            # Add predicates to the main element selection
            if self._predicates:
                predicate_str = " and ".join(self._predicates)
                # Insert predicates into the element selector
                if element_path.endswith("]"):
                    # Already has predicates, append
                    element_path = element_path[:-1] + " and " + predicate_str + "]"
                else:
                    element_path = element_path + "[" + predicate_str + "]"

            xpath = xpath + element_path

            # Add remaining parts (axis navigations, attribute selections, etc.)
            for part in self._parts[1:]:
                xpath = xpath + part

        # If no parts but predicates exist, invalid state
        if not self._parts and self._predicates:
            raise ValueError("Predicates specified without element selection")

        # Generate description
        description = " ".join(self._description_parts) if self._description_parts else "XPath query"

        return XPathQuery(
            xpath=xpath,
            description=description.capitalize(),
            parameters=self._parameters.copy()
        )

    def build_string(self) -> str:
        """Build and return just the XPath string."""
        return self.build().xpath


class InformaticaXPathPatterns:
    """
    Pre-built XPath patterns for common Informatica queries.

    These are optimized, tested patterns that can be used directly
    or as templates for custom queries.
    """

    # =========================================================================
    # Mapping Patterns
    # =========================================================================

    @staticmethod
    def all_mappings() -> str:
        """Get all mappings."""
        return "//MAPPING"

    @staticmethod
    def mapping_by_name(name: str) -> str:
        """Get mapping by name."""
        return f"//MAPPING[@NAME='{name}']"

    @staticmethod
    def mappings_containing_transformation_type(trans_type: str) -> str:
        """Find mappings containing a specific transformation type."""
        return f"//MAPPING[.//TRANSFORMATION[@TYPE='{trans_type}']]"

    # =========================================================================
    # Transformation Patterns
    # =========================================================================

    @staticmethod
    def all_transformations_in_mapping(mapping_name: str) -> str:
        """Get all transformations in a mapping."""
        return f"//MAPPING[@NAME='{mapping_name}']//TRANSFORMATION"

    @staticmethod
    def transformations_by_type(trans_type: str, mapping_name: Optional[str] = None) -> str:
        """Get transformations by type."""
        if mapping_name:
            return f"//MAPPING[@NAME='{mapping_name}']//TRANSFORMATION[@TYPE='{trans_type}']"
        return f"//TRANSFORMATION[@TYPE='{trans_type}']"

    @staticmethod
    def filters() -> str:
        """Get all filter transformations."""
        return "//TRANSFORMATION[@TYPE='Filter']"

    @staticmethod
    def aggregators() -> str:
        """Get all aggregator transformations."""
        return "//TRANSFORMATION[@TYPE='Aggregator']"

    @staticmethod
    def lookups() -> str:
        """Get all lookup transformations."""
        return "//TRANSFORMATION[@TYPE='Lookup Procedure']"

    @staticmethod
    def joiners() -> str:
        """Get all joiner transformations."""
        return "//TRANSFORMATION[@TYPE='Joiner']"

    @staticmethod
    def normalizers() -> str:
        """Get all normalizer transformations."""
        return "//TRANSFORMATION[@TYPE='Normalizer']"

    @staticmethod
    def expressions() -> str:
        """Get all expression transformations."""
        return "//TRANSFORMATION[@TYPE='Expression']"

    # =========================================================================
    # Connector Patterns
    # =========================================================================

    @staticmethod
    def all_connectors_in_mapping(mapping_name: str) -> str:
        """Get all connectors in a mapping."""
        return f"//MAPPING[@NAME='{mapping_name}']//CONNECTOR"

    @staticmethod
    def connectors_to_target(mapping_name: str) -> str:
        """Get connectors going to target instances."""
        return f"//MAPPING[@NAME='{mapping_name}']//CONNECTOR[@TOINSTANCETYPE='Target Definition']"

    @staticmethod
    def connectors_from_source(mapping_name: str) -> str:
        """Get connectors coming from source instances."""
        return f"//MAPPING[@NAME='{mapping_name}']//CONNECTOR[@FROMINSTANCETYPE='Source Definition' or @FROMINSTANCETYPE='Source Qualifier']"

    @staticmethod
    def connectors_between_instances(from_instance: str, to_instance: str) -> str:
        """Get connectors between two specific instances."""
        return f"//CONNECTOR[@FROMINSTANCE='{from_instance}' and @TOINSTANCE='{to_instance}']"

    @staticmethod
    def connectors_for_field(field_name: str, direction: str = "to") -> str:
        """Get connectors for a specific field."""
        if direction.lower() == "to":
            return f"//CONNECTOR[@TOFIELD='{field_name}']"
        return f"//CONNECTOR[@FROMFIELD='{field_name}']"

    # =========================================================================
    # Field Patterns
    # =========================================================================

    @staticmethod
    def fields_with_expression(mapping_name: Optional[str] = None) -> str:
        """Get fields that have expressions."""
        if mapping_name:
            return f"//MAPPING[@NAME='{mapping_name}']//TRANSFORMFIELD[@EXPRESSION]"
        return "//TRANSFORMFIELD[@EXPRESSION]"

    @staticmethod
    def expressions_containing_function(function_name: str) -> str:
        """Get expressions containing a specific function."""
        return f"//TRANSFORMFIELD[contains(@EXPRESSION, '{function_name}(')]"

    @staticmethod
    def aggregate_expressions() -> str:
        """Get expressions containing aggregate functions."""
        return "//TRANSFORMFIELD[contains(@EXPRESSION, 'SUM(') or contains(@EXPRESSION, 'COUNT(') or contains(@EXPRESSION, 'AVG(') or contains(@EXPRESSION, 'MAX(') or contains(@EXPRESSION, 'MIN(')]"

    @staticmethod
    def iif_expressions() -> str:
        """Get expressions containing IIF conditions."""
        return "//TRANSFORMFIELD[contains(@EXPRESSION, 'IIF(')]"

    @staticmethod
    def lookup_expressions() -> str:
        """Get expressions with lookup references."""
        return "//TRANSFORMFIELD[contains(@EXPRESSION, ':LKP.')]"

    # =========================================================================
    # Unmapped Field Patterns
    # =========================================================================

    @staticmethod
    def target_fields_in_mapping(mapping_name: str) -> str:
        """
        Get all target field names from instances in a mapping.

        Note: This gets the TARGET definition fields, not instance fields.
        """
        return f"""//MAPPING[@NAME='{mapping_name}']//INSTANCE[@TYPE='Target Definition']/@TRANSFORMATION_NAME"""

    @staticmethod
    def source_fields_in_mapping(mapping_name: str) -> str:
        """Get all source field names from instances in a mapping."""
        return f"""//MAPPING[@NAME='{mapping_name}']//INSTANCE[contains(@TYPE, 'Source')]/@TRANSFORMATION_NAME"""

    # =========================================================================
    # SQL Override Patterns
    # =========================================================================

    @staticmethod
    def sql_overrides() -> str:
        """Get SQL override attributes from source qualifiers."""
        return "//TRANSFORMATION[@TYPE='Source Qualifier']//TABLEATTRIBUTE[@NAME='Sql Query'][@VALUE!='']"

    @staticmethod
    def sql_overrides_in_mapping(mapping_name: str) -> str:
        """Get SQL overrides in a specific mapping."""
        return f"//MAPPING[@NAME='{mapping_name}']//TRANSFORMATION[@TYPE='Source Qualifier']//TABLEATTRIBUTE[@NAME='Sql Query'][@VALUE!='']"

    # =========================================================================
    # Workflow Patterns
    # =========================================================================

    @staticmethod
    def all_workflows() -> str:
        """Get all workflows."""
        return "//WORKFLOW"

    @staticmethod
    def sessions_in_workflow(workflow_name: str) -> str:
        """Get sessions in a workflow."""
        return f"//WORKFLOW[@NAME='{workflow_name}']//SESSION"

    @staticmethod
    def workflow_links(workflow_name: str) -> str:
        """Get workflow links."""
        return f"//WORKFLOW[@NAME='{workflow_name}']//WORKFLOWLINK"

    @staticmethod
    def workflow_variables(workflow_name: str) -> str:
        """Get workflow variables."""
        return f"//WORKFLOW[@NAME='{workflow_name}']//WORKFLOWVARIABLE"

    # =========================================================================
    # Complex Patterns
    # =========================================================================

    @staticmethod
    def transformation_chain_with_filter_and_aggregator(mapping_name: str) -> str:
        """Find mappings with both filter and aggregator (potential performance issue)."""
        return f"""//MAPPING[@NAME='{mapping_name}'][.//TRANSFORMATION[@TYPE='Filter']][.//TRANSFORMATION[@TYPE='Aggregator']]"""

    @staticmethod
    def multi_lookup_mappings() -> str:
        """Find mappings with multiple lookups."""
        return "//MAPPING[count(.//TRANSFORMATION[@TYPE='Lookup Procedure']) > 1]"

    @staticmethod
    def complex_expressions() -> str:
        """Find expressions with nested function calls (high complexity)."""
        return "//TRANSFORMFIELD[string-length(@EXPRESSION) > 100]"

    @staticmethod
    def passthrough_fields() -> str:
        """Find potential pass-through fields (input = output name)."""
        return "//TRANSFORMFIELD[@PORTTYPE='INPUT/OUTPUT']"


# Convenience function to create builder
def xpath_builder() -> InformaticaXPathBuilder:
    """Create a new XPath builder instance."""
    return InformaticaXPathBuilder()


# Export patterns class
patterns = InformaticaXPathPatterns
