"""
Query API for the Informatica DAG.

Provides high-level traversal methods:
  - trace_field(): backward lineage from a target field to ultimate sources
  - impact_analysis(): forward lineage from a source field to all downstream targets
  - get_execution_order(): topological sort across all mappings in workflow order
  - get_data_flow_summary(): end-to-end summary of all source-to-target paths
"""

from collections import deque
from typing import Any, Dict, List, Optional, Set, Tuple
import logging

from .dag_builder import InformaticaDAG, DAGNode, DAGEdge, DAGNodeLevel, DAGEdgeType

logger = logging.getLogger(__name__)


class DAGQuery:
    """Query interface for an InformaticaDAG."""

    def __init__(self, dag: InformaticaDAG):
        self.dag = dag
        if not dag._built:
            dag._build_indexes()

    # ------------------------------------------------------------------
    # Field-level backward trace
    # ------------------------------------------------------------------

    def trace_field(
        self,
        target_table: str,
        field_name: str,
        max_depth: int = 30,
    ) -> Dict[str, Any]:
        """
        Trace a target field backward to its ultimate sources.

        Args:
            target_table: Target table/instance name (case-insensitive)
            field_name: Field name (case-insensitive)
            max_depth: Maximum traversal depth

        Returns:
            Dict with 'sources', 'path', 'transformations' keys
        """
        # Find the field node
        target_lower = target_table.lower()
        field_lower = field_name.lower()

        start_nodes = []
        for nid, node in self.dag.nodes.items():
            if node.level == DAGNodeLevel.FIELD and \
               node.name.lower() == field_lower and \
               target_lower in nid.lower():
                start_nodes.append(nid)

        if not start_nodes:
            return {"sources": [], "path": [], "transformations": [], "error": "Field not found"}

        all_sources = []
        all_path = []
        all_transformations = []
        visited: Set[str] = set()

        for start_id in start_nodes:
            self._trace_backward(
                start_id, visited, all_sources, all_path,
                all_transformations, 0, max_depth,
            )

        return {
            "target": f"{target_table}.{field_name}",
            "sources": all_sources,
            "path": all_path,
            "transformations": all_transformations,
            "hop_count": len(all_path),
        }

    def _trace_backward(
        self,
        node_id: str,
        visited: Set[str],
        sources: List[Dict],
        path: List[Dict],
        transformations: List[str],
        depth: int,
        max_depth: int,
    ) -> None:
        if node_id in visited or depth > max_depth:
            return
        visited.add(node_id)

        node = self.dag.get_node(node_id)
        if not node:
            return

        reverse_edges = self.dag.get_reverse_edges(node_id)

        if not reverse_edges:
            # Terminal node — this is an ultimate source
            if node.level == DAGNodeLevel.FIELD:
                parent_id = "/".join(node_id.split("/")[:-1])
                parent = self.dag.get_node(parent_id)
                sources.append({
                    "node_id": node_id,
                    "field": node.name,
                    "transformation": parent.name if parent else "",
                    "transformation_type": parent.node_type if parent else "",
                    "datatype": node.metadata.get("datatype", ""),
                    "expression": node.metadata.get("expression", ""),
                })
            return

        for edge in reverse_edges:
            if edge.edge_type in (DAGEdgeType.CONNECTOR, DAGEdgeType.CROSS_MAPPING,
                                   DAGEdgeType.EXPRESSION_PASS):
                path.append(edge.to_dict())

                # Record transformation if the source is a field in a transformation
                source_node = self.dag.get_node(edge.source_id)
                if source_node and source_node.level == DAGNodeLevel.FIELD:
                    parent_id = "/".join(edge.source_id.split("/")[:-1])
                    parent = self.dag.get_node(parent_id)
                    if parent and parent.name not in transformations:
                        transformations.append(parent.name)

                self._trace_backward(
                    edge.source_id, visited, sources, path,
                    transformations, depth + 1, max_depth,
                )

    # ------------------------------------------------------------------
    # Field-level forward trace (impact analysis)
    # ------------------------------------------------------------------

    def impact_analysis(
        self,
        source_table: str,
        field_name: str,
        max_depth: int = 30,
    ) -> Dict[str, Any]:
        """
        Trace a source field forward to all downstream targets.

        Args:
            source_table: Source table/instance name (case-insensitive)
            field_name: Field name (case-insensitive)
            max_depth: Maximum traversal depth

        Returns:
            Dict with 'targets', 'path', 'transformations' keys
        """
        source_lower = source_table.lower()
        field_lower = field_name.lower()

        start_nodes = []
        for nid, node in self.dag.nodes.items():
            if node.level == DAGNodeLevel.FIELD and \
               node.name.lower() == field_lower and \
               source_lower in nid.lower():
                start_nodes.append(nid)

        if not start_nodes:
            return {"targets": [], "path": [], "transformations": [], "error": "Field not found"}

        all_targets = []
        all_path = []
        all_transformations = []
        visited: Set[str] = set()

        for start_id in start_nodes:
            self._trace_forward(
                start_id, visited, all_targets, all_path,
                all_transformations, 0, max_depth,
            )

        return {
            "source": f"{source_table}.{field_name}",
            "targets": all_targets,
            "path": all_path,
            "transformations": all_transformations,
        }

    def _trace_forward(
        self,
        node_id: str,
        visited: Set[str],
        targets: List[Dict],
        path: List[Dict],
        transformations: List[str],
        depth: int,
        max_depth: int,
    ) -> None:
        if node_id in visited or depth > max_depth:
            return
        visited.add(node_id)

        forward_edges = self.dag.get_forward_edges(node_id)

        if not forward_edges:
            # Terminal node — this is a downstream target
            node = self.dag.get_node(node_id)
            if node and node.level == DAGNodeLevel.FIELD:
                parent_id = "/".join(node_id.split("/")[:-1])
                parent = self.dag.get_node(parent_id)
                targets.append({
                    "node_id": node_id,
                    "field": node.name,
                    "transformation": parent.name if parent else "",
                    "transformation_type": parent.node_type if parent else "",
                })
            return

        for edge in forward_edges:
            if edge.edge_type in (DAGEdgeType.CONNECTOR, DAGEdgeType.CROSS_MAPPING,
                                   DAGEdgeType.EXPRESSION_PASS):
                path.append(edge.to_dict())
                source_node = self.dag.get_node(edge.target_id)
                if source_node and source_node.level == DAGNodeLevel.FIELD:
                    parent_id = "/".join(edge.target_id.split("/")[:-1])
                    parent = self.dag.get_node(parent_id)
                    if parent and parent.name not in transformations:
                        transformations.append(parent.name)

                self._trace_forward(
                    edge.target_id, visited, targets, path,
                    transformations, depth + 1, max_depth,
                )

    # ------------------------------------------------------------------
    # Execution order (topological sort across workflow)
    # ------------------------------------------------------------------

    def get_execution_order(self) -> List[Dict[str, Any]]:
        """
        Get execution order: workflow tasks -> sessions -> mappings,
        respecting workflow link dependencies.

        Returns list of steps, each with type, name, and mapping AST stats.
        """
        steps = []

        for wf_node in self.dag.workflow_nodes:
            # Get workflow task ordering from workflow links
            task_adj: Dict[str, List[str]] = {}
            task_in_degree: Dict[str, int] = {}

            for edge in self.dag.edges:
                if edge.edge_type == DAGEdgeType.WORKFLOW_LINK:
                    src_task = edge.source_id.split("/")[-1]
                    tgt_task = edge.target_id.split("/")[-1]
                    task_adj.setdefault(src_task, []).append(tgt_task)
                    task_in_degree.setdefault(src_task, 0)
                    task_in_degree.setdefault(tgt_task, 0)
                    task_in_degree[tgt_task] = task_in_degree.get(tgt_task, 0) + 1

            # Kahn's topological sort
            queue = deque([t for t, d in task_in_degree.items() if d == 0])
            ordered_tasks = []
            while queue:
                task = queue.popleft()
                ordered_tasks.append(task)
                for nxt in task_adj.get(task, []):
                    task_in_degree[nxt] -= 1
                    if task_in_degree[nxt] == 0:
                        queue.append(nxt)

            # Map tasks to sessions and mappings
            for task_name in ordered_tasks:
                sess_id = f"{wf_node.id}/{task_name}"
                sess_node = self.dag.get_node(sess_id)

                step = {"task": task_name, "workflow": wf_node.name}

                if sess_node and sess_node.level == DAGNodeLevel.SESSION:
                    step["type"] = "session"
                    mapping_name = sess_node.metadata.get("mapping_name", "")
                    step["mapping"] = mapping_name

                    # Add MappingAST stats if available
                    ast = self.dag.mapping_asts.get(mapping_name.lower())
                    if ast:
                        step["mapping_stats"] = ast.get_statistics()
                else:
                    step["type"] = "task"

                steps.append(step)

        return steps

    # ------------------------------------------------------------------
    # Data flow summary
    # ------------------------------------------------------------------

    def get_data_flow_summary(self) -> List[Dict[str, Any]]:
        """
        Get a summary of all source-to-target data flows across all mappings.

        Returns list of flows: source_table -> [transformations] -> target_table.
        """
        flows = []

        for map_name, ast in self.dag.mapping_asts.items():
            for path_info in ast.get_all_source_to_target_paths():
                flows.append({
                    "mapping": ast.mapping_name,
                    "source_instance": path_info["source_instance"],
                    "source_field": path_info["source_field"],
                    "target_instance": path_info["target_instance"],
                    "target_field": path_info["target_field"],
                    "hop_count": path_info["hop_count"],
                })

        return flows

    # ------------------------------------------------------------------
    # Cross-mapping analysis
    # ------------------------------------------------------------------

    def get_cross_mapping_links(self) -> List[Dict[str, Any]]:
        """Get all cross-mapping links detected in the DAG."""
        links = []
        for edge in self.dag.edges:
            if edge.edge_type == DAGEdgeType.CROSS_MAPPING:
                links.append(edge.to_dict())
        return links

    # ------------------------------------------------------------------
    # Per-mapping AST access
    # ------------------------------------------------------------------

    def get_mapping_ast(self, mapping_name: str) -> Optional[Any]:
        """Get the MappingAST for a specific mapping."""
        return self.dag.mapping_asts.get(mapping_name.lower())

    def get_mapping_execution_order(self, mapping_name: str) -> List[str]:
        """Get topological sort of transformation instances within a mapping."""
        ast = self.dag.mapping_asts.get(mapping_name.lower())
        if ast:
            return ast.get_execution_order()
        return []

    def get_mapping_cycles(self, mapping_name: str) -> List[List[str]]:
        """Detect cycles within a mapping."""
        ast = self.dag.mapping_asts.get(mapping_name.lower())
        if ast:
            return ast.detect_cycles()
        return []
