"""
DAG export to JSON, GraphML, and Cytoscape.js formats.

Produces standalone output files that can be consumed by
visualization tools or downstream systems.
"""

import json
from pathlib import Path
from typing import Any, Dict, Optional
import logging

from .dag_builder import InformaticaDAG, DAGNodeLevel, DAGEdgeType

logger = logging.getLogger(__name__)


class DAGExporter:
    """Export an InformaticaDAG to various formats."""

    # ------------------------------------------------------------------
    # JSON
    # ------------------------------------------------------------------

    @staticmethod
    def to_json(dag: InformaticaDAG, output_path: str, indent: int = 2) -> str:
        """
        Export the full DAG as a JSON file.

        Args:
            dag: The InformaticaDAG to export
            output_path: Path to write the JSON file
            indent: JSON indentation level

        Returns:
            Path to the written file
        """
        data = dag.to_dict()
        path = Path(output_path)
        path.parent.mkdir(parents=True, exist_ok=True)
        with open(path, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=indent, default=str)
        logger.info(f"DAG exported to JSON: {path} ({len(dag.nodes)} nodes, {len(dag.edges)} edges)")
        return str(path)

    # ------------------------------------------------------------------
    # GraphML (for tools like yEd, Gephi, Neo4j)
    # ------------------------------------------------------------------

    @staticmethod
    def to_graphml(dag: InformaticaDAG, output_path: str) -> str:
        """
        Export the DAG as GraphML XML.

        Args:
            dag: The InformaticaDAG to export
            output_path: Path to write the GraphML file

        Returns:
            Path to the written file
        """
        import xml.etree.ElementTree as ET

        graphml = ET.Element("graphml", xmlns="http://graphml.graphstruct.org/xmlns")

        # Define data keys
        keys = [
            ("d_level", "node", "level", "string"),
            ("d_type", "node", "node_type", "string"),
            ("d_name", "node", "name", "string"),
            ("d_edge_type", "edge", "edge_type", "string"),
        ]
        for key_id, for_attr, attr_name, attr_type in keys:
            ET.SubElement(graphml, "key", id=key_id, **{
                "for": for_attr,
                "attr.name": attr_name,
                "attr.type": attr_type,
            })

        graph = ET.SubElement(graphml, "graph", id="informatica_dag", edgedefault="directed")

        # Nodes
        for node in dag.nodes.values():
            n_elem = ET.SubElement(graph, "node", id=_sanitize_id(node.id))
            _add_data(n_elem, "d_level", node.level.value)
            _add_data(n_elem, "d_type", node.node_type)
            _add_data(n_elem, "d_name", node.name)

        # Edges
        for i, edge in enumerate(dag.edges):
            e_elem = ET.SubElement(
                graph, "edge",
                id=f"e{i}",
                source=_sanitize_id(edge.source_id),
                target=_sanitize_id(edge.target_id),
            )
            _add_data(e_elem, "d_edge_type", edge.edge_type.value)

        tree = ET.ElementTree(graphml)
        path = Path(output_path)
        path.parent.mkdir(parents=True, exist_ok=True)
        tree.write(str(path), encoding="unicode", xml_declaration=True)
        logger.info(f"DAG exported to GraphML: {path}")
        return str(path)

    # ------------------------------------------------------------------
    # Cytoscape.js JSON (for interactive HTML visualization)
    # ------------------------------------------------------------------

    @staticmethod
    def to_cytoscape(dag: InformaticaDAG, output_path: str) -> str:
        """
        Export the DAG as Cytoscape.js JSON for interactive visualization.

        Args:
            dag: The InformaticaDAG to export
            output_path: Path to write the Cytoscape JSON file

        Returns:
            Path to the written file
        """
        elements = []

        # Color map by level
        level_colors = {
            DAGNodeLevel.WORKFLOW: "#2196F3",
            DAGNodeLevel.SESSION: "#4CAF50",
            DAGNodeLevel.MAPPING: "#FF9800",
            DAGNodeLevel.TRANSFORMATION: "#9C27B0",
            DAGNodeLevel.FIELD: "#607D8B",
        }

        # Shape map by level
        level_shapes = {
            DAGNodeLevel.WORKFLOW: "diamond",
            DAGNodeLevel.SESSION: "hexagon",
            DAGNodeLevel.MAPPING: "rectangle",
            DAGNodeLevel.TRANSFORMATION: "ellipse",
            DAGNodeLevel.FIELD: "round-rectangle",
        }

        # Add nodes
        for node in dag.nodes.values():
            # Determine parent for compound nodes
            parts = node.id.rsplit("/", 1)
            parent = parts[0] if len(parts) > 1 and parts[0] in dag.nodes else None

            elem = {
                "data": {
                    "id": node.id,
                    "label": node.name,
                    "level": node.level.value,
                    "node_type": node.node_type,
                    "color": level_colors.get(node.level, "#999999"),
                    "shape": level_shapes.get(node.level, "ellipse"),
                },
            }
            if parent:
                elem["data"]["parent"] = parent
            elements.append(elem)

        # Edge color map
        edge_colors = {
            DAGEdgeType.CONNECTOR: "#666666",
            DAGEdgeType.CROSS_MAPPING: "#E91E63",
            DAGEdgeType.WORKFLOW_LINK: "#2196F3",
            DAGEdgeType.WORKFLOW_TO_SESSION: "#4CAF50",
            DAGEdgeType.SESSION_TO_MAPPING: "#FF9800",
            DAGEdgeType.EXPRESSION_PASS: "#9C27B0",
        }

        # Add edges
        for i, edge in enumerate(dag.edges):
            elements.append({
                "data": {
                    "id": f"e{i}",
                    "source": edge.source_id,
                    "target": edge.target_id,
                    "edge_type": edge.edge_type.value,
                    "color": edge_colors.get(edge.edge_type, "#999999"),
                },
            })

        cyto_data = {"elements": elements, "statistics": dag.get_statistics()}

        path = Path(output_path)
        path.parent.mkdir(parents=True, exist_ok=True)
        with open(path, "w", encoding="utf-8") as f:
            json.dump(cyto_data, f, indent=2, default=str)
        logger.info(f"DAG exported to Cytoscape JSON: {path}")
        return str(path)

    # ------------------------------------------------------------------
    # Interactive HTML (self-contained Cytoscape.js viewer)
    # ------------------------------------------------------------------

    @staticmethod
    def to_html(dag: InformaticaDAG, output_path: str, title: str = "") -> str:
        """
        Export the DAG as a self-contained interactive HTML page
        using Cytoscape.js (inlined, no CDN dependency).

        Default view shows transformation-level nodes with instance-level
        edges (aggregated from field connectors). Toggle to field-level view
        for full detail.

        Args:
            dag: The InformaticaDAG to export
            output_path: Path to write the HTML file
            title: Page title

        Returns:
            Path to the written file
        """
        if not title:
            title = f"Informatica DAG - {dag.source_xml or 'Unknown'}"

        stats = dag.get_statistics()

        # --- Load Cytoscape.js inline ---
        cyto_js = ""
        _cyto_paths = [
            Path(__file__).parent / "cytoscape.min.js",
            Path("/tmp/cytoscape.min.js"),
        ]
        for _cp in _cyto_paths:
            if _cp.exists():
                cyto_js = _cp.read_text(encoding="utf-8")
                break
        if not cyto_js:
            # Fallback to CDN
            cyto_js = '// CDN fallback\n'
            cyto_script_tag = '<script src="https://unpkg.com/cytoscape@3.28.1/dist/cytoscape.min.js"></script>'
        else:
            cyto_script_tag = ""

        # Transformation type colors
        trans_colors = {
            "source definition": "#4CAF50",
            "source qualifier": "#8BC34A",
            "target definition": "#F44336",
            "expression": "#FF9800",
            "filter": "#FFEB3B",
            "aggregator": "#03A9F4",
            "lookup procedure": "#9C27B0",
            "joiner": "#E91E63",
            "router": "#00BCD4",
            "custom transformation": "#795548",
            "sequence generator": "#607D8B",
            "update strategy": "#FF5722",
            "normalizer": "#009688",
        }

        # --- Build TRANSFORMATION-LEVEL elements (default view) ---
        trans_elements = []
        # Collect unique transformation nodes
        for node in dag.nodes.values():
            if node.level != DAGNodeLevel.TRANSFORMATION:
                continue
            color = trans_colors.get(node.node_type.lower(), "#9C27B0")
            field_count = node.metadata.get("field_count", 0)
            trans_elements.append({
                "data": {
                    "id": node.id,
                    "label": node.name,
                    "level": "transformation",
                    "node_type": node.node_type,
                    "color": color,
                    "field_count": field_count,
                },
            })

        # Build instance-level edges (aggregate field connectors to instance level)
        inst_edge_set = set()
        for edge in dag.edges:
            if edge.edge_type == DAGEdgeType.CONNECTOR:
                # Strip field from IDs to get transformation IDs
                src_parts = edge.source_id.rsplit("/", 1)
                tgt_parts = edge.target_id.rsplit("/", 1)
                if len(src_parts) == 2 and len(tgt_parts) == 2:
                    src_trans = src_parts[0]
                    tgt_trans = tgt_parts[0]
                    if src_trans != tgt_trans:
                        ekey = f"{src_trans}|{tgt_trans}"
                        if ekey not in inst_edge_set:
                            inst_edge_set.add(ekey)
                            trans_elements.append({
                                "data": {
                                    "id": f"te_{len(inst_edge_set)}",
                                    "source": src_trans,
                                    "target": tgt_trans,
                                    "edge_type": "connector",
                                    "color": "#78909C",
                                },
                            })
            elif edge.edge_type == DAGEdgeType.CROSS_MAPPING:
                trans_elements.append({
                    "data": {
                        "id": f"xm_{edge.source_id}_{edge.target_id}",
                        "source": edge.source_id,
                        "target": edge.target_id,
                        "edge_type": "cross_mapping",
                        "color": "#E91E63",
                    },
                })

        # --- Build FIELD-LEVEL elements ---
        field_elements = []
        for node in dag.nodes.values():
            if node.level == DAGNodeLevel.FIELD:
                parent_id = "/".join(node.id.rsplit("/", 1)[:-1])
                parent = dag.get_node(parent_id)
                color = "#B0BEC5"
                if parent:
                    color = trans_colors.get(parent.node_type.lower(), "#B0BEC5")
                field_elements.append({
                    "data": {
                        "id": node.id,
                        "label": node.name,
                        "level": "field",
                        "node_type": node.metadata.get("datatype", ""),
                        "color": color,
                        "parent": parent_id if parent_id in dag.nodes else None,
                    },
                })

        for i, edge in enumerate(dag.edges):
            if edge.edge_type == DAGEdgeType.CONNECTOR:
                field_elements.append({
                    "data": {
                        "id": f"fe_{i}",
                        "source": edge.source_id,
                        "target": edge.target_id,
                        "edge_type": "connector",
                        "color": "#78909C",
                    },
                })

        trans_elements_json = json.dumps(trans_elements, default=str)
        field_elements_json = json.dumps(field_elements, default=str)

        # Build legend HTML
        legend_items = "".join(
            f'<span style="display:inline-block;margin:0 8px;">'
            f'<span style="display:inline-block;width:10px;height:10px;'
            f'border-radius:50%;background:{color};margin-right:3px;"></span>'
            f'{ttype.title()}</span>'
            for ttype, color in trans_colors.items()
        )

        html = f"""<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>{title}</title>
{cyto_script_tag}
<script>{cyto_js}</script>
<style>
* {{ box-sizing: border-box; }}
body {{ margin:0; font-family: 'Segoe UI', Arial, sans-serif; background: #1a1a2e; color: #eee; }}
#cy {{ width:100%; height:calc(100vh - 110px); }}
#header {{ padding:8px 20px; background:#16213e; display:flex; justify-content:space-between; align-items:center; }}
#header h3 {{ margin:0; font-size:16px; }}
#stats {{ font-size:12px; color:#aaa; }}
#controls {{ padding:6px 20px; background:#0f3460; font-size:12px; display:flex; align-items:center; gap:6px; flex-wrap:wrap; }}
#controls button {{ padding:5px 14px; border:none; border-radius:4px; cursor:pointer; background:#e94560; color:#fff; font-size:12px; }}
#controls button:hover {{ background:#c73e54; }}
#controls button.active {{ background:#4CAF50; }}
#controls select {{ padding:5px; border-radius:4px; font-size:12px; }}
#legend {{ padding:4px 20px; background:#0a1931; font-size:11px; color:#aaa; overflow-x:auto; white-space:nowrap; }}
#tooltip {{ position:fixed; background:#222; color:#eee; padding:8px 12px; border-radius:6px;
  font-size:12px; pointer-events:none; display:none; z-index:999; max-width:350px;
  border:1px solid #444; box-shadow:0 2px 8px rgba(0,0,0,0.5); }}
</style>
</head>
<body>
<div id="header">
  <h3>{title}</h3>
  <span id="stats">Nodes: {stats['total_nodes']} | Edges: {stats['total_edges']} | Mappings: {stats.get('mapping_count', 0)}</span>
</div>
<div id="controls">
  <button onclick="cy.fit()" title="Fit all nodes in view">Fit</button>
  <button id="btnTrans" class="active" onclick="switchView('transformation')">Transformation View</button>
  <button id="btnField" onclick="switchView('field')">Field View</button>
  <span style="color:#666;">|</span>
  <select id="layoutSelect">
    <option value="breadthfirst">Breadth-First</option>
    <option value="cose">CoSE (Force)</option>
    <option value="grid">Grid</option>
    <option value="circle">Circle</option>
    <option value="concentric">Concentric</option>
  </select>
  <button onclick="runLayout()">Re-layout</button>
  <span style="color:#666;">|</span>
  <input type="text" id="searchBox" placeholder="Search node..." style="padding:5px;border-radius:4px;border:1px solid #555;background:#1a1a2e;color:#eee;width:160px;font-size:12px;" oninput="searchNode(this.value)">
</div>
<div id="legend">{legend_items}</div>
<div id="cy"></div>
<div id="tooltip"></div>
<script>
var transElements = {trans_elements_json};
var fieldElements = {field_elements_json};
var currentView = 'transformation';
var cy;

function createCy(elements) {{
  if (cy) cy.destroy();
  cy = cytoscape({{
    container: document.getElementById('cy'),
    elements: elements,
    style: [
      {{ selector: 'node', style: {{
        'label': 'data(label)',
        'background-color': 'data(color)',
        'font-size': '9px',
        'color': '#fff',
        'text-outline-width': 1,
        'text-outline-color': '#222',
        'text-valign': 'center',
        'text-halign': 'center',
        'width': 'label',
        'height': 'label',
        'padding': '8px',
        'shape': 'round-rectangle',
      }}}},
      {{ selector: 'node[level="field"]', style: {{
        'font-size': '7px',
        'padding': '4px',
        'background-opacity': 0.8,
      }}}},
      {{ selector: ':parent', style: {{
        'background-opacity': 0.08,
        'border-width': 1,
        'border-color': 'data(color)',
        'border-opacity': 0.4,
        'label': 'data(label)',
        'font-size': '11px',
        'text-valign': 'top',
        'text-halign': 'center',
        'color': '#aaa',
        'padding': '15px',
      }}}},
      {{ selector: 'edge', style: {{
        'width': 1.5,
        'line-color': 'data(color)',
        'target-arrow-color': 'data(color)',
        'target-arrow-shape': 'triangle',
        'curve-style': 'bezier',
        'arrow-scale': 0.7,
        'opacity': 0.7,
      }}}},
      {{ selector: 'edge[edge_type="cross_mapping"]', style: {{
        'width': 3, 'line-style': 'dashed', 'opacity': 1,
      }}}},
      {{ selector: '.highlighted', style: {{
        'border-width': 3, 'border-color': '#FFD700',
        'background-color': '#FFD700', 'color': '#000',
        'text-outline-color': '#FFD700', 'z-index': 999,
      }}}},
      {{ selector: '.dimmed', style: {{ 'opacity': 0.15 }} }},
      {{ selector: '.hl-edge', style: {{ 'width': 3, 'opacity': 1, 'line-color': '#FFD700', 'target-arrow-color': '#FFD700' }} }},
    ],
    layout: {{ name: 'breadthfirst', directed: true, spacingFactor: 1.5, animate: false }},
  }});

  // Tooltip on hover
  var tooltip = document.getElementById('tooltip');
  cy.on('mouseover', 'node', function(e) {{
    var d = e.target.data();
    var info = '<b>' + d.label + '</b><br>Type: ' + (d.node_type || d.level);
    if (d.field_count) info += '<br>Fields: ' + d.field_count;
    tooltip.innerHTML = info;
    tooltip.style.display = 'block';
  }});
  cy.on('mousemove', 'node', function(e) {{
    tooltip.style.left = (e.originalEvent.clientX + 12) + 'px';
    tooltip.style.top = (e.originalEvent.clientY + 12) + 'px';
  }});
  cy.on('mouseout', 'node', function() {{ tooltip.style.display = 'none'; }});

  // Click to highlight lineage path
  cy.on('tap', 'node', function(e) {{
    cy.elements().removeClass('highlighted dimmed hl-edge');
    var node = e.target;
    var connected = node.successors().union(node.predecessors()).union(node);
    connected.nodes().addClass('highlighted');
    connected.edges().addClass('hl-edge');
    cy.elements().not(connected).addClass('dimmed');
  }});
  cy.on('tap', function(e) {{
    if (e.target === cy) cy.elements().removeClass('highlighted dimmed hl-edge');
  }});

  setTimeout(function() {{ cy.fit(undefined, 30); }}, 100);
}}

function switchView(view) {{
  currentView = view;
  document.getElementById('btnTrans').className = (view==='transformation') ? 'active' : '';
  document.getElementById('btnField').className = (view==='field') ? 'active' : '';
  if (view === 'transformation') {{
    createCy(transElements);
  }} else {{
    // For field view, include transformation nodes as parents + field nodes + edges
    var combined = transElements.filter(function(e) {{ return e.data && !e.data.source; }});
    createCy(combined.concat(fieldElements));
  }}
}}

function runLayout() {{
  var name = document.getElementById('layoutSelect').value;
  var opts = {{ name: name, animate: false }};
  if (name === 'breadthfirst') {{ opts.directed = true; opts.spacingFactor = 1.5; }}
  if (name === 'cose') {{ opts.nodeOverlap = 20; opts.idealEdgeLength = function(){{ return 80; }}; }}
  if (name === 'concentric') {{ opts.concentric = function(n){{ return n.degree(); }}; opts.levelWidth = function(){{ return 2; }}; }}
  cy.layout(opts).run();
  setTimeout(function() {{ cy.fit(undefined, 30); }}, 100);
}}

function searchNode(query) {{
  cy.elements().removeClass('highlighted dimmed hl-edge');
  if (!query || query.length < 2) return;
  var q = query.toLowerCase();
  var matches = cy.nodes().filter(function(n) {{ return n.data('label').toLowerCase().indexOf(q) >= 0; }});
  if (matches.length > 0) {{
    matches.addClass('highlighted');
    cy.elements().not(matches).addClass('dimmed');
    cy.fit(matches, 50);
  }}
}}

// Initialize with transformation view
createCy(transElements);
</script>
</body>
</html>"""

        path = Path(output_path)
        path.parent.mkdir(parents=True, exist_ok=True)
        with open(path, "w", encoding="utf-8") as f:
            f.write(html)
        logger.info(f"DAG exported to interactive HTML: {path}")
        return str(path)


def _sanitize_id(node_id: str) -> str:
    """Sanitize a node ID for GraphML (no special chars)."""
    return node_id.replace("/", "__").replace(" ", "_")


def _add_data(parent, key: str, value: str) -> None:
    """Add a <data> element to a GraphML node/edge."""
    import xml.etree.ElementTree as ET
    d = ET.SubElement(parent, "data", key=key)
    d.text = str(value)
