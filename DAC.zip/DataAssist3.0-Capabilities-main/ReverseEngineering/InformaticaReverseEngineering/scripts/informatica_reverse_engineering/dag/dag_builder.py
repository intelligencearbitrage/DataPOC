"""
Unified DAG builder for Informatica PowerCenter.

Builds a single traversable graph that connects:
  Workflow -> Session -> Mapping -> Transformation -> Field

Uses the existing MappingAST infrastructure for per-mapping graphs and
adds cross-mapping + workflow-level edges on top.
"""

from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict, List, Optional, Set, Tuple
from collections import deque
import logging

from ..utils.mapping_ast import (
    MappingAST,
    TransformationNode,
    ConnectorEdge,
    FieldNode,
    NodeType,
)
from ..parsers.powermart_parser import PowermartDocument
from ..models.mapping_models import Mapping

logger = logging.getLogger(__name__)


class DAGNodeLevel(Enum):
    """Hierarchy level of a node in the unified DAG."""
    WORKFLOW = "workflow"
    SESSION = "session"
    MAPPING = "mapping"
    TRANSFORMATION = "transformation"
    FIELD = "field"


class DAGEdgeType(Enum):
    """Type of edge in the unified DAG."""
    WORKFLOW_TO_SESSION = "workflow_to_session"
    SESSION_TO_MAPPING = "session_to_mapping"
    CONNECTOR = "connector"               # Field-level data flow (from XML CONNECTOR)
    CROSS_MAPPING = "cross_mapping"        # Target of mapping A = Source of mapping B
    EXPRESSION_PASS = "expression_pass"    # Expression OUTPUT -> INPUT port ref
    WORKFLOW_LINK = "workflow_link"         # Task ordering within a workflow


@dataclass
class DAGNode:
    """A node in the unified DAG."""
    id: str                         # Unique key, e.g. "wf_X/s_BUILD/m_BUILD/exp_INPUT/RATE"
    name: str                       # Display name
    level: DAGNodeLevel
    node_type: str = ""             # Informatica type (e.g. "Expression", "Source Qualifier")
    metadata: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "name": self.name,
            "level": self.level.value,
            "node_type": self.node_type,
            "metadata": self.metadata,
        }


@dataclass
class DAGEdge:
    """An edge in the unified DAG."""
    source_id: str
    target_id: str
    edge_type: DAGEdgeType
    metadata: Dict[str, Any] = field(default_factory=dict)

    @property
    def edge_key(self) -> str:
        return f"{self.source_id}->{self.target_id}"

    def to_dict(self) -> Dict[str, Any]:
        return {
            "source_id": self.source_id,
            "target_id": self.target_id,
            "edge_type": self.edge_type.value,
            "metadata": self.metadata,
        }


class MappingASTBuilder:
    """
    Builds a MappingAST from a parsed Mapping object.

    Standalone version of the builder from powermart_parser_xdm.py
    so any mapping from any XML can produce a MappingAST without
    requiring XDM mode.
    """

    @staticmethod
    def build(mapping: Mapping) -> MappingAST:
        ast = MappingAST(mapping_name=mapping.name)

        # Create nodes from instances
        for instance in mapping.instances:
            node = TransformationNode(
                name=instance.name,
                transformation_name=instance.transformation_name,
                node_type=NodeType.from_informatica_type(instance.transformation_type),
                informatica_type=instance.transformation_type,
            )

            # Add fields from the transformation definition
            trans = mapping.get_transformation(instance.transformation_name)
            if not trans:
                # Try matching by instance name (some mappings use instance name directly)
                trans = mapping.get_transformation(instance.name)
            if not trans:
                # Check targets and sources — they also carry fields
                # Instance names often have sc_ prefix: sc_TABLENAME -> TABLENAME
                names_to_check = [
                    instance.transformation_name.lower(),
                    instance.name.lower(),
                ]
                for prefix in ("sc_", "shortcut_to_", "sq_", "sq_sc_"):
                    for n in list(names_to_check):
                        if n.startswith(prefix):
                            names_to_check.append(n[len(prefix):])
                for tgt in mapping.targets:
                    if tgt.name.lower() in names_to_check:
                        trans = tgt
                        break
            if not trans:
                for src in mapping.sources:
                    if src.name.lower() in names_to_check:
                        trans = src
                        break
            if trans:
                for fld in trans.fields:
                    field_node = FieldNode(
                        name=fld.name,
                        datatype=fld.datatype,
                        precision=fld.precision,
                        scale=fld.scale,
                        expression=getattr(fld, "expression", "") or "",
                        default_value=getattr(fld, "default_value", "") or "",
                        is_input="INPUT" in (getattr(fld, "port_type", "") or "").upper(),
                        is_output="OUTPUT" in (getattr(fld, "port_type", "") or "").upper(),
                    )
                    node.add_field(field_node)

            ast.add_node(node)

        # Create edges from connectors
        for connector in mapping.connectors:
            edge = ConnectorEdge(
                from_instance=connector.from_instance,
                from_field=connector.from_field,
                to_instance=connector.to_instance,
                to_field=connector.to_field,
                from_instance_type=connector.from_instance_type or "",
                to_instance_type=connector.to_instance_type or "",
            )
            ast.add_edge(edge)

        ast.build()
        return ast


class InformaticaDAG:
    """
    Unified Directed Acyclic Graph for an Informatica PowerCenter document.

    Connects all levels: Workflow -> Session -> Mapping -> Transformation -> Field.
    Provides adjacency lists, traversal methods, and cross-mapping edges.
    """

    def __init__(self):
        self.nodes: Dict[str, DAGNode] = {}
        self.edges: List[DAGEdge] = []
        self._forward_adj: Dict[str, List[DAGEdge]] = {}
        self._reverse_adj: Dict[str, List[DAGEdge]] = {}
        self._edge_set: Set[str] = set()

        # Per-mapping ASTs for field-level traversal
        self.mapping_asts: Dict[str, MappingAST] = {}

        # Source XML file path(s)
        self.source_xml: str = ""
        self.source_xmls: List[str] = []

        self._built = False

    # ------------------------------------------------------------------
    # Building
    # ------------------------------------------------------------------

    def add_node(self, node: DAGNode) -> None:
        if node.id not in self.nodes:
            self.nodes[node.id] = node
            self._built = False

    def add_edge(self, edge: DAGEdge) -> None:
        key = edge.edge_key
        if key not in self._edge_set:
            self.edges.append(edge)
            self._edge_set.add(key)
            self._built = False

    def _build_indexes(self) -> None:
        if self._built:
            return
        self._forward_adj = {}
        self._reverse_adj = {}
        for edge in self.edges:
            self._forward_adj.setdefault(edge.source_id, []).append(edge)
            self._reverse_adj.setdefault(edge.target_id, []).append(edge)
        self._built = True

    # ------------------------------------------------------------------
    # Query helpers
    # ------------------------------------------------------------------

    def get_node(self, node_id: str) -> Optional[DAGNode]:
        return self.nodes.get(node_id)

    def get_forward_edges(self, node_id: str) -> List[DAGEdge]:
        if not self._built:
            self._build_indexes()
        return self._forward_adj.get(node_id, [])

    def get_reverse_edges(self, node_id: str) -> List[DAGEdge]:
        if not self._built:
            self._build_indexes()
        return self._reverse_adj.get(node_id, [])

    def get_nodes_by_level(self, level: DAGNodeLevel) -> List[DAGNode]:
        return [n for n in self.nodes.values() if n.level == level]

    @property
    def workflow_nodes(self) -> List[DAGNode]:
        return self.get_nodes_by_level(DAGNodeLevel.WORKFLOW)

    @property
    def mapping_nodes(self) -> List[DAGNode]:
        return self.get_nodes_by_level(DAGNodeLevel.MAPPING)

    @property
    def transformation_nodes(self) -> List[DAGNode]:
        return self.get_nodes_by_level(DAGNodeLevel.TRANSFORMATION)

    @property
    def field_nodes(self) -> List[DAGNode]:
        return self.get_nodes_by_level(DAGNodeLevel.FIELD)

    # ------------------------------------------------------------------
    # Statistics
    # ------------------------------------------------------------------

    def get_statistics(self) -> Dict[str, Any]:
        if not self._built:
            self._build_indexes()
        level_counts = {}
        for node in self.nodes.values():
            level_counts[node.level.value] = level_counts.get(node.level.value, 0) + 1
        edge_type_counts = {}
        for edge in self.edges:
            edge_type_counts[edge.edge_type.value] = edge_type_counts.get(edge.edge_type.value, 0) + 1
        return {
            "total_nodes": len(self.nodes),
            "total_edges": len(self.edges),
            "nodes_by_level": level_counts,
            "edges_by_type": edge_type_counts,
            "mapping_count": len(self.mapping_asts),
        }

    def to_dict(self) -> Dict[str, Any]:
        if not self._built:
            self._build_indexes()
        return {
            "source_xml": self.source_xml,
            "statistics": self.get_statistics(),
            "nodes": [n.to_dict() for n in self.nodes.values()],
            "edges": [e.to_dict() for e in self.edges],
        }

    # ------------------------------------------------------------------
    # Class method: build from a parsed document
    # ------------------------------------------------------------------

    def _add_document(self, doc: PowermartDocument) -> None:
        """Add all nodes and edges from a single PowermartDocument into this DAG."""

        # --- Workflow level ---
        for workflow in doc.workflows:
            wf_id = workflow.name
            self.add_node(DAGNode(
                id=wf_id,
                name=workflow.name,
                level=DAGNodeLevel.WORKFLOW,
                node_type="Workflow",
                metadata={
                    "is_enabled": getattr(workflow, "is_enabled", True),
                    "task_count": len(workflow.tasks),
                    "session_count": len(workflow.sessions),
                },
            ))

            # Workflow task links
            for link in workflow.links:
                self.add_edge(DAGEdge(
                    source_id=f"{wf_id}/{link.from_task}",
                    target_id=f"{wf_id}/{link.to_task}",
                    edge_type=DAGEdgeType.WORKFLOW_LINK,
                    metadata={"condition": link.condition},
                ))

            # --- Session level ---
            for session in workflow.sessions:
                sess_id = f"{wf_id}/{session.name}"
                mapping_name = getattr(session, "mapping_name", "") or ""
                self.add_node(DAGNode(
                    id=sess_id,
                    name=session.name,
                    level=DAGNodeLevel.SESSION,
                    node_type="Session",
                    metadata={"mapping_name": mapping_name},
                ))
                self.add_edge(DAGEdge(
                    source_id=wf_id,
                    target_id=sess_id,
                    edge_type=DAGEdgeType.WORKFLOW_TO_SESSION,
                ))

                # --- Link session to its mapping ---
                if mapping_name:
                    mapping_obj = None
                    for m in doc.mappings:
                        if m.name.lower() == mapping_name.lower():
                            mapping_obj = m
                            break
                        # Try shortcut resolution (sc_ prefix)
                        if m.name.lower() == f"sc_{mapping_name}".lower():
                            mapping_obj = m
                            break
                        if f"sc_{m.name}".lower() == mapping_name.lower():
                            mapping_obj = m
                            break

                    if mapping_obj:
                        map_id = f"{wf_id}/{session.name}/{mapping_obj.name}"
                        self.add_edge(DAGEdge(
                            source_id=sess_id,
                            target_id=map_id,
                            edge_type=DAGEdgeType.SESSION_TO_MAPPING,
                        ))

        # --- Mapping level (include all mappings, even if not linked to a session) ---
        for mapping in doc.mappings:
            # Find the parent session/workflow for this mapping
            map_id = None
            for wf in doc.workflows:
                for sess in wf.sessions:
                    sess_mapping = getattr(sess, "mapping_name", "") or ""
                    if sess_mapping.lower() == mapping.name.lower() or \
                       sess_mapping.lower() == f"sc_{mapping.name}".lower() or \
                       f"sc_{sess_mapping}".lower() == mapping.name.lower():
                        map_id = f"{wf.name}/{sess.name}/{mapping.name}"
                        break
                if map_id:
                    break
            if not map_id:
                map_id = mapping.name

            self.add_node(DAGNode(
                id=map_id,
                name=mapping.name,
                level=DAGNodeLevel.MAPPING,
                node_type="Mapping",
                metadata={
                    "source_count": len(mapping.sources),
                    "target_count": len(mapping.targets),
                    "transformation_count": len(mapping.transformations),
                    "connector_count": len(mapping.connectors),
                },
            ))

            # Build MappingAST
            try:
                ast = MappingASTBuilder.build(mapping)
                self.mapping_asts[mapping.name.lower()] = ast
            except Exception as exc:
                logger.warning(f"Failed to build MappingAST for {mapping.name}: {exc}")
                continue

            # --- Transformation nodes ---
            for inst_name, trans_node in ast.nodes.items():
                trans_id = f"{map_id}/{trans_node.name}"
                self.add_node(DAGNode(
                    id=trans_id,
                    name=trans_node.name,
                    level=DAGNodeLevel.TRANSFORMATION,
                    node_type=trans_node.informatica_type,
                    metadata={
                        "ast_node_type": trans_node.node_type.value,
                        "field_count": len(trans_node.fields),
                        "input_fields": len(trans_node.input_fields),
                        "output_fields": len(trans_node.output_fields),
                        "expression_fields": len(trans_node.expression_fields),
                    },
                ))

                # --- Field nodes ---
                for fname, fnode in trans_node.fields.items():
                    field_id = f"{trans_id}/{fnode.name}"
                    self.add_node(DAGNode(
                        id=field_id,
                        name=fnode.name,
                        level=DAGNodeLevel.FIELD,
                        node_type=fnode.port_type,
                        metadata={
                            "datatype": fnode.datatype,
                            "expression": fnode.expression,
                            "precision": fnode.precision,
                            "scale": fnode.scale,
                        },
                    ))

            # --- Connector edges (field-level data flow) ---
            for edge in ast.edges:
                from_trans_id = f"{map_id}/{edge.from_instance}"
                to_trans_id = f"{map_id}/{edge.to_instance}"
                from_field_id = f"{from_trans_id}/{edge.from_field}"
                to_field_id = f"{to_trans_id}/{edge.to_field}"
                self.add_edge(DAGEdge(
                    source_id=from_field_id,
                    target_id=to_field_id,
                    edge_type=DAGEdgeType.CONNECTOR,
                    metadata={
                        "from_instance": edge.from_instance,
                        "from_field": edge.from_field,
                        "to_instance": edge.to_instance,
                        "to_field": edge.to_field,
                        "from_instance_type": edge.from_instance_type,
                        "to_instance_type": edge.to_instance_type,
                    },
                ))

    # ------------------------------------------------------------------
    # Class methods: build from parsed documents
    # ------------------------------------------------------------------

    @classmethod
    def from_document(
        cls,
        doc: PowermartDocument,
        source_xml: str = "",
    ) -> "InformaticaDAG":
        """
        Build a complete DAG from a single parsed PowermartDocument.

        Args:
            doc: Parsed Informatica document (from PowermartParser)
            source_xml: Path to the source XML file
        """
        dag = cls()
        dag.source_xml = source_xml
        dag.source_xmls = [source_xml] if source_xml else []

        dag._add_document(doc)
        _add_cross_mapping_edges(dag)

        dag._build_indexes()
        logger.info(
            f"Built InformaticaDAG: {len(dag.nodes)} nodes, {len(dag.edges)} edges, "
            f"{len(dag.mapping_asts)} mappings"
        )
        return dag

    @classmethod
    def from_documents(
        cls,
        docs: List[Tuple[str, PowermartDocument]],
    ) -> "InformaticaDAG":
        """
        Build a unified DAG from multiple parsed PowermartDocuments.

        Args:
            docs: List of (source_xml_path, PowermartDocument) tuples

        Returns:
            Single InformaticaDAG containing all workflows, mappings,
            transformations, and fields with cross-mapping edges detected
            across all documents.
        """
        dag = cls()
        dag.source_xmls = [xml_path for xml_path, _ in docs]
        dag.source_xml = docs[0][0] if docs else ""

        for xml_path, doc in docs:
            dag._add_document(doc)

        # Detect cross-mapping edges across ALL documents at once
        _add_cross_mapping_edges(dag)

        dag._build_indexes()
        logger.info(
            f"Built unified InformaticaDAG from {len(docs)} XMLs: "
            f"{len(dag.nodes)} nodes, {len(dag.edges)} edges, "
            f"{len(dag.mapping_asts)} mappings"
        )
        return dag


def _add_cross_mapping_edges(dag: InformaticaDAG) -> None:
    """
    Detect cross-mapping links where a target table in one mapping
    is a source in another, and add DAGEdges for them.

    Scans all transformation nodes already in the DAG, so this works
    for both single-document and multi-document DAGs.
    """
    # Collect target tables per mapping
    target_tables: Dict[str, List[Tuple[str, str]]] = {}  # table_lower -> [(map_id, instance_name)]
    source_tables: Dict[str, List[Tuple[str, str]]] = {}

    for node in dag.nodes.values():
        if node.level == DAGNodeLevel.TRANSFORMATION:
            ntype = node.metadata.get("ast_node_type", "")
            if ntype == "target":
                tbl_name = node.name.lower()
                # Strip common prefixes for matching
                for prefix in ("sc_", "shortcut_to_"):
                    if tbl_name.startswith(prefix):
                        tbl_name = tbl_name[len(prefix):]
                target_tables.setdefault(tbl_name, []).append((node.id, node.name))
            elif ntype in ("source", "source_qualifier"):
                tbl_name = node.name.lower()
                for prefix in ("sc_", "shortcut_to_", "sq_", "sq_sc_"):
                    if tbl_name.startswith(prefix):
                        tbl_name = tbl_name[len(prefix):]
                source_tables.setdefault(tbl_name, []).append((node.id, node.name))

    # Find matches: target in mapping A = source in mapping B
    for tbl_name, tgt_entries in target_tables.items():
        src_entries = source_tables.get(tbl_name, [])
        for tgt_id, tgt_name in tgt_entries:
            for src_id, src_name in src_entries:
                # Skip self-references within the same mapping
                tgt_mapping = "/".join(tgt_id.split("/")[:-1])
                src_mapping = "/".join(src_id.split("/")[:-1])
                if tgt_mapping != src_mapping:
                    dag.add_edge(DAGEdge(
                        source_id=tgt_id,
                        target_id=src_id,
                        edge_type=DAGEdgeType.CROSS_MAPPING,
                        metadata={
                            "table_name": tbl_name,
                            "from_mapping": tgt_mapping,
                            "to_mapping": src_mapping,
                        },
                    ))
