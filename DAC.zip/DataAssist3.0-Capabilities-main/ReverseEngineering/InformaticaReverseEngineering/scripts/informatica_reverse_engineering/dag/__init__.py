"""
Informatica DAG (Directed Acyclic Graph) module.

Provides a unified, traversable graph representation of Informatica
PowerCenter workflows — connecting Workflow -> Session -> Mapping ->
Transformation -> Field as a single DAG.

This is an additive module that does NOT modify existing parser output.
"""

from .dag_builder import InformaticaDAG, MappingASTBuilder, DAGNode, DAGEdge
from .dag_query import DAGQuery
from .dag_exporter import DAGExporter
from .lineage_to_dag_converter import LineageResultToDAGConverter

__all__ = [
    "InformaticaDAG",
    "MappingASTBuilder",
    "DAGNode",
    "DAGEdge",
    "DAGQuery",
    "DAGExporter",
    "LineageResultToDAGConverter",
]
