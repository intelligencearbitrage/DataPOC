"""
Converter: LineageResult → InformaticaDAG.

Builds the DAG from the *enriched* lineage output (after IntegrationExpert
processing) rather than the raw XML parse.  This ensures the DAG shows:
  - Resolved parameter placeholders ($Param_* → actual values)
  - Expression explanations (English descriptions)
  - Qualified target table names (database prefix)
  - The same data that appears in the Excel/CSV output

Follows the same pattern as the SQL RE ``LineageToVisualConverter``.
"""

from typing import Dict, List, Optional, Set, Tuple
import logging

from .dag_builder import (
    InformaticaDAG, DAGNode, DAGEdge,
    DAGNodeLevel, DAGEdgeType,
)
from ..parsers.powermart_parser import PowermartDocument
from ..models.lineage_models import LineageResult, EndToEndFieldLineage, FieldLineageEdge

logger = logging.getLogger(__name__)


class LineageResultToDAGConverter:
    """Convert LineageResult(s) + PowermartDocument(s) into a unified InformaticaDAG.

    Uses PowermartDocument for the Workflow → Session → Mapping hierarchy,
    and LineageResult for the enriched Transformation → Field edges.
    """

    def __init__(self, param_loader=None):
        """
        Args:
            param_loader: Optional ParameterFileLoader for resolving $Param_*
                          placeholders in node names and metadata.
        """
        self._dag: Optional[InformaticaDAG] = None
        self._param_loader = param_loader
        # Maps instance name (lowercase) → qualified table name from LineageResult
        self._instance_to_qualified: Dict[str, str] = {}

    def _resolve(self, text: str) -> str:
        """Resolve $Param_* placeholders if a param_loader is available."""
        if not text or not self._param_loader:
            return text
        return self._param_loader.resolve_placeholders(text)

    def convert(
        self,
        docs_and_results: List[Tuple[str, PowermartDocument, LineageResult]],
    ) -> InformaticaDAG:
        """Build a unified DAG from one or more (xml_path, document, lineage_result) tuples.

        Args:
            docs_and_results: List of (xml_path, PowermartDocument, LineageResult)

        Returns:
            InformaticaDAG with enriched metadata from the lineage pipeline.
        """
        dag = InformaticaDAG()
        dag.source_xmls = [xml_path for xml_path, _, _ in docs_and_results]
        dag.source_xml = dag.source_xmls[0] if dag.source_xmls else ""
        self._dag = dag

        for xml_path, doc, lineage_result in docs_and_results:
            self._add_hierarchy(doc)
            self._add_lineage_edges(doc, lineage_result)

        # Cross-mapping edges (target in mapping A = source in mapping B)
        self._add_cross_mapping_edges()

        # Resolve $Param_* placeholders in all node names and metadata
        if self._param_loader and self._param_loader.parameters:
            self._resolve_parameters()

        # After params are resolved, rename target/source nodes to match Excel
        # (e.g., "sc_SHAWILN_FEATURE_TGT_STG" → "P_EDW_STG_01_E0.SHAWILN_FEATURE_TGT_STG")
        self._apply_qualified_names(dag)

        dag._build_indexes()

        logger.info(
            f"Built enriched DAG from {len(docs_and_results)} XML(s): "
            f"{len(dag.nodes)} nodes, {len(dag.edges)} edges, "
            f"{len(set(n.id.split('/')[0] for n in dag.nodes.values() if n.level == DAGNodeLevel.WORKFLOW))} workflows"
        )
        return dag

    # ------------------------------------------------------------------
    # Hierarchy: Workflow → Session → Mapping  (from PowermartDocument)
    # ------------------------------------------------------------------

    def _add_hierarchy(self, doc: PowermartDocument) -> None:
        """Add workflow/session/mapping nodes from the document."""
        dag = self._dag

        for workflow in doc.workflows:
            wf_id = workflow.name
            dag.add_node(DAGNode(
                id=wf_id,
                name=workflow.name,
                level=DAGNodeLevel.WORKFLOW,
                node_type="Workflow",
                metadata={
                    "is_enabled": getattr(workflow, "is_enabled", True),
                    "task_count": len(workflow.tasks),
                    "session_count": len(workflow.sessions),
                },
            ))

            for link in workflow.links:
                dag.add_edge(DAGEdge(
                    source_id=f"{wf_id}/{link.from_task}",
                    target_id=f"{wf_id}/{link.to_task}",
                    edge_type=DAGEdgeType.WORKFLOW_LINK,
                    metadata={"condition": link.condition},
                ))

            for session in workflow.sessions:
                sess_id = f"{wf_id}/{session.name}"
                mapping_name = getattr(session, "mapping_name", "") or ""
                dag.add_node(DAGNode(
                    id=sess_id,
                    name=session.name,
                    level=DAGNodeLevel.SESSION,
                    node_type="Session",
                    metadata={"mapping_name": mapping_name},
                ))
                dag.add_edge(DAGEdge(
                    source_id=wf_id,
                    target_id=sess_id,
                    edge_type=DAGEdgeType.WORKFLOW_TO_SESSION,
                ))

                if mapping_name:
                    mapping_obj = self._find_mapping(doc, mapping_name)
                    if mapping_obj:
                        map_id = f"{wf_id}/{session.name}/{mapping_obj.name}"
                        dag.add_node(DAGNode(
                            id=map_id,
                            name=mapping_obj.name,
                            level=DAGNodeLevel.MAPPING,
                            node_type="Mapping",
                            metadata={
                                "source_count": len(mapping_obj.sources),
                                "target_count": len(mapping_obj.targets),
                                "transformation_count": len(mapping_obj.transformations),
                                "connector_count": len(mapping_obj.connectors),
                            },
                        ))
                        dag.add_edge(DAGEdge(
                            source_id=sess_id,
                            target_id=map_id,
                            edge_type=DAGEdgeType.SESSION_TO_MAPPING,
                        ))

        # Also add orphan mappings (not linked to any session)
        for mapping in doc.mappings:
            map_id = self._resolve_mapping_id(doc, mapping.name)
            if map_id not in dag.nodes:
                dag.add_node(DAGNode(
                    id=map_id,
                    name=mapping.name,
                    level=DAGNodeLevel.MAPPING,
                    node_type="Mapping",
                    metadata={
                        "source_count": len(mapping.sources),
                        "target_count": len(mapping.targets),
                        "transformation_count": len(mapping.transformations),
                        "connector_count": len(mapping.connectors),
                    },
                ))

    # ------------------------------------------------------------------
    # Enriched edges: from LineageResult  (after IntegrationExpert)
    # ------------------------------------------------------------------

    def _add_lineage_edges(self, doc: PowermartDocument, result: LineageResult) -> None:
        """Add transformation/field nodes and edges from the enriched LineageResult."""
        dag = self._dag

        # Collect all unique instances (transformations) and fields from intermediate steps
        for lineage in result.field_lineages:
            mapping_name = lineage.mapping_name
            map_id = self._resolve_mapping_id(doc, mapping_name)

            # Build instance name → qualified table name mapping
            # target_table is like "$Param_STG_Database.SHAWILN_FEATURE_TGT_STG"
            # The bare table name maps to the sc_TABLENAME instance
            if lineage.target_table:
                bare_target = lineage.target_table.split(".")[-1].lower()
                self._instance_to_qualified[bare_target] = lineage.target_table
            for src_info in lineage.ultimate_sources:
                src_table = src_info.get("table", "")
                if src_table:
                    bare_source = src_table.split(".")[-1].lower()
                    self._instance_to_qualified[bare_source] = src_table

            for step in lineage.intermediate_steps:
                # --- Source side ---
                src_trans_id = f"{map_id}/{step.source_instance}"
                src_field_id = f"{src_trans_id}/{step.source_field}"

                dag.add_node(DAGNode(
                    id=src_trans_id,
                    name=step.source_instance,
                    level=DAGNodeLevel.TRANSFORMATION,
                    node_type=step.source_type,
                    metadata={
                        "ast_node_type": self._classify_type(step.source_type),
                    },
                ))
                dag.add_node(DAGNode(
                    id=src_field_id,
                    name=step.source_field,
                    level=DAGNodeLevel.FIELD,
                    node_type="",
                    metadata={
                        "datatype": "",
                        "expression": "",
                        "expression_explanation": "",
                    },
                ))

                # --- Target side ---
                tgt_trans_id = f"{map_id}/{step.target_instance}"
                tgt_field_id = f"{tgt_trans_id}/{step.target_field}"

                dag.add_node(DAGNode(
                    id=tgt_trans_id,
                    name=step.target_instance,
                    level=DAGNodeLevel.TRANSFORMATION,
                    node_type=step.target_type,
                    metadata={
                        "ast_node_type": self._classify_type(step.target_type),
                    },
                ))
                dag.add_node(DAGNode(
                    id=tgt_field_id,
                    name=step.target_field,
                    level=DAGNodeLevel.FIELD,
                    node_type="",
                    metadata={
                        "datatype": "",
                        "expression": step.expression,
                        "expression_explanation": step.expression_explanation,
                    },
                ))

                # --- Edge ---
                dag.add_edge(DAGEdge(
                    source_id=src_field_id,
                    target_id=tgt_field_id,
                    edge_type=DAGEdgeType.CONNECTOR,
                    metadata={
                        "from_instance": step.source_instance,
                        "from_field": step.source_field,
                        "to_instance": step.target_instance,
                        "to_field": step.target_field,
                        "from_instance_type": step.source_type,
                        "to_instance_type": step.target_type,
                        "expression": step.expression,
                        "expression_explanation": step.expression_explanation,
                    },
                ))

            # Also add the target table/field node with enriched metadata
            # (qualified table name, datatype, transformation explanation)
            tgt_table = lineage.target_table
            tgt_field = lineage.target_field
            # Find the last step's target instance for the target node
            if lineage.intermediate_steps:
                last_step = lineage.intermediate_steps[-1]
                last_trans_id = f"{map_id}/{last_step.target_instance}"
                last_field_id = f"{last_trans_id}/{last_step.target_field}"
                # Enrich the target field node with lineage metadata
                if last_field_id in dag.nodes:
                    node = dag.nodes[last_field_id]
                    node.metadata["datatype"] = lineage.target_datatype
                    node.metadata["qualified_target"] = tgt_table
                    node.metadata["transformation_chain"] = lineage.transformation_chain
                    node.metadata["transformation_explanation"] = lineage.transformation_explanation
                    node.metadata["sql_logic"] = lineage.sql_logic
                    node.metadata["hop_count"] = lineage.hop_count
                    if lineage.lookup_name:
                        node.metadata["lookup_name"] = lineage.lookup_name
                    if lineage.lookup_condition:
                        node.metadata["lookup_condition"] = lineage.lookup_condition
                    if lineage.filter_condition:
                        node.metadata["filter_condition"] = lineage.filter_condition
                    if lineage.router_condition:
                        node.metadata["router_condition"] = lineage.router_condition

            # Enrich source field nodes with datatype from ultimate_sources
            for src_info in lineage.ultimate_sources:
                src_table = src_info.get("table", "")
                src_field = src_info.get("field", "")
                src_datatype = src_info.get("datatype", "")
                if lineage.intermediate_steps:
                    first_step = lineage.intermediate_steps[0]
                    first_field_id = f"{map_id}/{first_step.source_instance}/{first_step.source_field}"
                    if first_field_id in dag.nodes:
                        dag.nodes[first_field_id].metadata["datatype"] = src_datatype
                        dag.nodes[first_field_id].metadata["qualified_source"] = src_table

        # Update transformation node field counts
        self._update_field_counts(dag)

    # ------------------------------------------------------------------
    # Cross-mapping edges
    # ------------------------------------------------------------------

    def _add_cross_mapping_edges(self) -> None:
        """Detect target→source cross-mapping links across all documents."""
        dag = self._dag
        target_tables: Dict[str, List[Tuple[str, str]]] = {}
        source_tables: Dict[str, List[Tuple[str, str]]] = {}

        for node in dag.nodes.values():
            if node.level != DAGNodeLevel.TRANSFORMATION:
                continue
            ntype = self._classify_type(node.node_type)
            name_lower = node.name.lower()
            # Strip prefixes for matching
            for prefix in ("sc_", "shortcut_to_"):
                if name_lower.startswith(prefix):
                    name_lower = name_lower[len(prefix):]

            if ntype == "target":
                target_tables.setdefault(name_lower, []).append((node.id, node.name))
            elif ntype in ("source", "source_qualifier"):
                for prefix in ("sq_", "sq_sc_"):
                    if name_lower.startswith(prefix):
                        name_lower = name_lower[len(prefix):]
                source_tables.setdefault(name_lower, []).append((node.id, node.name))

        for tbl_name, tgt_entries in target_tables.items():
            for src_id, src_name in source_tables.get(tbl_name, []):
                for tgt_id, tgt_name in tgt_entries:
                    tgt_mapping = "/".join(tgt_id.split("/")[:-1])
                    src_mapping = "/".join(src_id.split("/")[:-1])
                    if tgt_mapping != src_mapping:
                        dag.add_edge(DAGEdge(
                            source_id=tgt_id,
                            target_id=src_id,
                            edge_type=DAGEdgeType.CROSS_MAPPING,
                            metadata={
                                "table_name": tbl_name,
                                "from_mapping": tgt_mapping,
                                "to_mapping": src_mapping,
                            },
                        ))

    # ------------------------------------------------------------------
    # Qualified name resolution
    # ------------------------------------------------------------------

    def _apply_qualified_names(self, dag: InformaticaDAG) -> None:
        """Rename target and source transformation nodes using qualified table names.

        Builds a mapping from instance names (e.g., ``sc_SHAWILN_FEATURE_TGT_STG``)
        to qualified table names (e.g., ``P_EDW_STG_01_E0.SHAWILN_FEATURE_TGT_STG``)
        using the ``_instance_to_qualified`` lookup built during lineage processing.
        """
        if not self._instance_to_qualified:
            return

        # Resolve $Param_* in the lookup values themselves
        resolved_lookup = {}
        for k, v in self._instance_to_qualified.items():
            resolved_lookup[k] = self._resolve(v)

        renamed = 0
        for node in dag.nodes.values():
            if node.level != DAGNodeLevel.TRANSFORMATION:
                continue
            ntype = node.metadata.get("ast_node_type", "")
            if ntype not in ("target", "source", "source_qualifier"):
                continue

            # Try exact match, then stripped prefix match
            node_name_lower = node.name.lower()
            qualified = resolved_lookup.get(node_name_lower)
            if not qualified:
                for prefix in ("sc_", "shortcut_to_", "sq_", "sq_sc_"):
                    if node_name_lower.startswith(prefix):
                        qualified = resolved_lookup.get(node_name_lower[len(prefix):])
                        if qualified:
                            break

            if qualified and "$" not in qualified:
                node.name = qualified
                renamed += 1

        if renamed:
            logger.info(f"  Renamed {renamed} source/target nodes to qualified table names")

    # ------------------------------------------------------------------
    # Parameter resolution
    # ------------------------------------------------------------------

    def _resolve_parameters(self) -> None:
        """Resolve $Param_* placeholders in all DAG node names and metadata."""
        dag = self._dag
        resolved_count = 0

        for node in dag.nodes.values():
            # Resolve node name
            new_name = self._resolve(node.name)
            if new_name != node.name:
                node.name = new_name
                resolved_count += 1

            # Resolve metadata string values
            for key in list(node.metadata.keys()):
                val = node.metadata[key]
                if isinstance(val, str) and "$" in val:
                    node.metadata[key] = self._resolve(val)

        # Resolve edge metadata
        for edge in dag.edges:
            for key in list(edge.metadata.keys()):
                val = edge.metadata[key]
                if isinstance(val, str) and "$" in val:
                    edge.metadata[key] = self._resolve(val)

        if resolved_count:
            logger.info(f"  Resolved $Param_* placeholders in {resolved_count} node names")

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    def _find_mapping(self, doc: PowermartDocument, mapping_name: str):
        """Find a mapping in the document by name (with sc_ resolution)."""
        name_lower = mapping_name.lower()
        for m in doc.mappings:
            if m.name.lower() == name_lower:
                return m
            if m.name.lower() == f"sc_{name_lower}":
                return m
            if f"sc_{m.name.lower()}" == name_lower:
                return m
        return None

    def _resolve_mapping_id(self, doc: PowermartDocument, mapping_name: str) -> str:
        """Resolve mapping name to its full DAG path (wf/session/mapping)."""
        for wf in doc.workflows:
            for sess in wf.sessions:
                sess_mapping = getattr(sess, "mapping_name", "") or ""
                if sess_mapping.lower() == mapping_name.lower() or \
                   sess_mapping.lower() == f"sc_{mapping_name.lower()}" or \
                   f"sc_{sess_mapping.lower()}" == mapping_name.lower():
                    return f"{wf.name}/{sess.name}/{mapping_name}"
        return mapping_name

    @staticmethod
    def _classify_type(instance_type: str) -> str:
        """Classify an Informatica instance type to a role category."""
        t = (instance_type or "").lower()
        if "source qualifier" in t:
            return "source_qualifier"
        if "source" in t:
            return "source"
        if "target" in t:
            return "target"
        if "lookup" in t:
            return "lookup"
        if "filter" in t:
            return "filter"
        if "router" in t:
            return "router"
        if "aggregat" in t:
            return "aggregator"
        if "joiner" in t:
            return "joiner"
        if "expression" in t:
            return "expression"
        if "custom" in t or "union" in t:
            return "custom"
        if "update strategy" in t:
            return "update_strategy"
        return "transformation"

    @staticmethod
    def _update_field_counts(dag: InformaticaDAG) -> None:
        """Update field_count metadata on transformation nodes."""
        trans_field_counts: Dict[str, int] = {}
        for node in dag.nodes.values():
            if node.level == DAGNodeLevel.FIELD:
                parent_id = "/".join(node.id.rsplit("/", 1)[:-1]) if "/" in node.id else ""
                if parent_id:
                    trans_field_counts[parent_id] = trans_field_counts.get(parent_id, 0) + 1

        for trans_id, count in trans_field_counts.items():
            if trans_id in dag.nodes:
                dag.nodes[trans_id].metadata["field_count"] = count
