"""
Rich interactive DAG visualization.

Generates a self-contained HTML page with:
- Table-card nodes showing fields (expandable/collapsible)
- Color-coded by role (Source, Intermediate, Target)
- Field-level edge connections with typed line styles
- Detail sidebar on click (properties, upstream, downstream, expression refs)
- Search, zoom, fit, LR/TB layout toggle
- Mapping group boxes
- Fully offline — no CDN dependencies
"""

import json
import re
from pathlib import Path
from typing import Any, Dict, List, Set, Tuple
import logging

from .dag_builder import InformaticaDAG, DAGNode, DAGEdge, DAGNodeLevel, DAGEdgeType

logger = logging.getLogger(__name__)


def export_rich_html(dag: InformaticaDAG, output_path: str, title: str = "") -> str:
    if not dag._built:
        dag._build_indexes()

    if not title:
        xml_name = Path(dag.source_xml).stem if dag.source_xml else "Informatica DAG"
        title = f"{xml_name} Interactive Lineage"

    tables = _build_table_data(dag)
    edges = _build_edge_data(dag)
    stats = _compute_stats(tables, edges)

    # Build expression-reference index: for each field, which sibling output
    # expressions reference it?
    expr_refs = _build_expression_refs(dag)

    tables_json = json.dumps(tables, default=str)
    edges_json = json.dumps(edges, default=str)
    expr_refs_json = json.dumps(expr_refs, default=str)

    html = _TEMPLATE.replace("{{TITLE}}", title)
    html = html.replace("{{TABLES_JSON}}", tables_json)
    html = html.replace("{{EDGES_JSON}}", edges_json)
    html = html.replace("{{EXPR_REFS_JSON}}", expr_refs_json)
    html = html.replace("{{STATS_SOURCES}}", str(stats["sources"]))
    html = html.replace("{{STATS_INTERMEDIATE}}", str(stats["intermediate"]))
    html = html.replace("{{STATS_TARGETS}}", str(stats["targets"]))
    html = html.replace("{{STATS_EDGES}}", str(stats["edges"]))
    html = html.replace("{{STATS_FIELDS}}", str(stats["fields"]))

    path = Path(output_path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        f.write(html)
    logger.info(f"Rich DAG visualization exported: {path}")
    return str(path)


def _build_table_data(dag: InformaticaDAG) -> List[Dict]:
    tables = []
    for node in dag.nodes.values():
        if node.level != DAGNodeLevel.TRANSFORMATION:
            continue

        ast_type = node.metadata.get("ast_node_type", "")
        if ast_type in ("source", "source_qualifier"):
            role = "source"
        elif ast_type == "target":
            role = "target"
        else:
            role = "intermediate"

        fields = []
        for fnode in dag.nodes.values():
            if fnode.level == DAGNodeLevel.FIELD and fnode.id.startswith(node.id + "/"):
                in_count = len(dag.get_reverse_edges(fnode.id))
                out_count = len(dag.get_forward_edges(fnode.id))
                fields.append({
                    "name": fnode.name,
                    "id": fnode.id,
                    "datatype": fnode.metadata.get("datatype", ""),
                    "expression": fnode.metadata.get("expression", ""),
                    "expression_explanation": fnode.metadata.get("expression_explanation", ""),
                    "port_type": fnode.node_type or "",
                    "in_count": in_count,
                    "out_count": out_count,
                    # Enriched metadata from LineageResult
                    "qualified_target": fnode.metadata.get("qualified_target", ""),
                    "qualified_source": fnode.metadata.get("qualified_source", ""),
                    "sql_logic": fnode.metadata.get("sql_logic", ""),
                    "transformation_chain": fnode.metadata.get("transformation_chain", ""),
                    "transformation_explanation": fnode.metadata.get("transformation_explanation", ""),
                    "hop_count": fnode.metadata.get("hop_count", 0),
                    "router_condition": fnode.metadata.get("router_condition", ""),
                    "filter_condition": fnode.metadata.get("filter_condition", ""),
                    "lookup_name": fnode.metadata.get("lookup_name", ""),
                    "lookup_condition": fnode.metadata.get("lookup_condition", ""),
                })

        mapping_id = node.id.rsplit("/", 1)[0] if "/" in node.id else ""
        mapping_name = mapping_id.split("/")[-1] if mapping_id else ""

        tables.append({
            "id": node.id,
            "name": node.name,
            "type": node.node_type,
            "role": role,
            "field_count": len(fields),
            "fields": fields,
            "mapping": mapping_id,
            "mapping_name": mapping_name,
        })

    return tables


def _build_edge_data(dag: InformaticaDAG) -> List[Dict]:
    edges = []
    for edge in dag.edges:
        if edge.edge_type not in (DAGEdgeType.CONNECTOR, DAGEdgeType.CROSS_MAPPING):
            continue

        src_trans_id = edge.source_id.rsplit("/", 1)[0] if "/" in edge.source_id else ""
        tgt_trans_id = edge.target_id.rsplit("/", 1)[0] if "/" in edge.target_id else ""
        tgt_trans = dag.get_node(tgt_trans_id)

        edge_style = "direct"
        if edge.edge_type == DAGEdgeType.CROSS_MAPPING:
            edge_style = "cross_mapping"
        elif tgt_trans:
            ttype = (tgt_trans.node_type or "").lower()
            if "aggregat" in ttype:
                edge_style = "aggregation"
            elif "lookup" in ttype:
                edge_style = "lookup"
            elif "filter" in ttype or "router" in ttype:
                edge_style = "filter"
            elif "expression" in ttype:
                edge_style = "expression"
            elif "custom" in ttype or "union" in ttype:
                edge_style = "union"

        edges.append({
            "source_field_id": edge.source_id,
            "target_field_id": edge.target_id,
            "source_trans_id": src_trans_id,
            "target_trans_id": tgt_trans_id,
            "edge_style": edge_style,
            "from_field": edge.metadata.get("from_field", ""),
            "to_field": edge.metadata.get("to_field", ""),
            "expression_explanation": edge.metadata.get("expression_explanation", ""),
        })

    return edges


def _build_expression_refs(dag: InformaticaDAG) -> Dict[str, List[Dict]]:
    """For each INPUT field in an expression transformation, find which
    sibling OUTPUT fields reference it in their expression text."""
    refs: Dict[str, List[Dict]] = {}

    for node in dag.nodes.values():
        if node.level != DAGNodeLevel.TRANSFORMATION:
            continue
        ntype = (node.node_type or "").lower()
        if "expression" not in ntype:
            continue

        # Collect all field nodes for this transformation
        field_nodes = []
        for fnode in dag.nodes.values():
            if fnode.level == DAGNodeLevel.FIELD and fnode.id.startswith(node.id + "/"):
                field_nodes.append(fnode)

        input_fields = [f for f in field_nodes if "INPUT" in (f.node_type or "").upper()]
        output_fields = [f for f in field_nodes if "OUTPUT" in (f.node_type or "").upper()
                         and f.metadata.get("expression", "")]

        for inp in input_fields:
            inp_name = inp.name.upper()
            referencing = []
            for out in output_fields:
                expr = (out.metadata.get("expression", "") or "").upper()
                # Strip string literals before matching
                expr_clean = re.sub(r"'[^']*'", "", expr)
                # Word-boundary match
                if re.search(r'\b' + re.escape(inp_name) + r'\b', expr_clean):
                    referencing.append({
                        "field_name": out.name,
                        "field_id": out.id,
                        "expression": out.metadata.get("expression", "")[:120],
                    })
            if referencing:
                refs[inp.id] = referencing

    return refs


def _compute_stats(tables, edges):
    sources = sum(1 for t in tables if t["role"] == "source")
    targets = sum(1 for t in tables if t["role"] == "target")
    intermediate = sum(1 for t in tables if t["role"] == "intermediate")
    fields = sum(t["field_count"] for t in tables)
    return {"sources": sources, "intermediate": intermediate, "targets": targets, "edges": len(edges), "fields": fields}


# ---------------------------------------------------------------------------
# HTML Template
# ---------------------------------------------------------------------------

_TEMPLATE = r"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>{{TITLE}}</title>
<style>
:root {
  --bg: #0f1623; --bg2: #1a2236; --bg3: #232d42;
  --text: #e0e6f0; --text2: #8892a6; --border: #2a3550;
  --source: #2ecc71; --source-bg: rgba(46,204,113,0.06); --source-border: rgba(46,204,113,0.25);
  --intermediate: #f1c40f; --inter-bg: rgba(241,196,15,0.06); --inter-border: rgba(241,196,15,0.25);
  --target: #3498db; --target-bg: rgba(52,152,219,0.06); --target-border: rgba(52,152,219,0.25);
  --accent: #e74c3c; --link: #6c5ce7;
}
* { box-sizing: border-box; margin: 0; padding: 0; }
body { font-family: 'Segoe UI', system-ui, -apple-system, sans-serif; background: var(--bg); color: var(--text); overflow: hidden; height: 100vh; display: flex; flex-direction: column; }

#header { display: flex; align-items: center; justify-content: space-between; padding: 8px 20px; background: var(--bg2); border-bottom: 1px solid var(--border); z-index: 100; }
#header h1 { font-size: 14px; font-weight: 600; }
.stat-badges { display: flex; gap: 8px; }
.badge { padding: 3px 12px; border-radius: 20px; font-size: 11px; font-weight: 600; }
.badge-source { background: var(--source); color: #000; }
.badge-inter { background: var(--intermediate); color: #000; }
.badge-target { background: var(--target); color: #fff; }
.badge-edge { background: var(--bg3); color: var(--text2); border: 1px solid var(--border); }

#toolbar { display: flex; align-items: center; gap: 6px; padding: 6px 20px; background: var(--bg2); border-bottom: 1px solid var(--border); flex-wrap: wrap; }
#searchBox { flex: 1; min-width: 180px; max-width: 400px; padding: 6px 12px; border-radius: 6px; border: 1px solid var(--border); background: var(--bg); color: var(--text); font-size: 12px; outline: none; }
#searchBox:focus { border-color: var(--link); }
#searchBox::placeholder { color: var(--text2); }
.btn { padding: 5px 14px; border: 1px solid var(--border); border-radius: 6px; background: var(--bg3); color: var(--text); cursor: pointer; font-size: 11px; font-weight: 500; transition: all 0.15s; white-space: nowrap; }
.btn:hover { background: var(--border); }
.btn.active { background: var(--link); border-color: var(--link); color: #fff; }
.btn-group { display: flex; gap: 0; }
.btn-group .btn { border-radius: 0; margin-left: -1px; }
.btn-group .btn:first-child { border-radius: 6px 0 0 6px; margin-left: 0; }
.btn-group .btn:last-child { border-radius: 0 6px 6px 0; }
.sep { width: 1px; height: 24px; background: var(--border); }
select.filter-select { padding: 5px 8px; border-radius: 6px; border: 1px solid var(--border); background: var(--bg); color: var(--text); font-size: 11px; outline: none; cursor: pointer; }

#legend { display: flex; gap: 14px; padding: 4px 20px; background: var(--bg); border-bottom: 1px solid var(--border); font-size: 10px; color: var(--text2); align-items: center; flex-wrap: wrap; }
.legend-item { display: flex; align-items: center; gap: 4px; }
.legend-dot { width: 8px; height: 8px; border-radius: 50%; }
.legend-line { width: 20px; height: 0; border-top: 2px solid; }
.legend-line.dashed { border-top-style: dashed; }

#main { display: flex; flex: 1; min-height: 0; }
#canvas-wrap { flex: 1; position: relative; overflow: hidden; cursor: grab; }
#canvas-wrap.grabbing { cursor: grabbing; }
#canvas { position: absolute; top: 0; left: 0; transform-origin: 0 0; }
#svg-edges { position: absolute; top: 0; left: 0; pointer-events: none; overflow: visible; z-index: 0; }

/* Mapping group boxes */
.mapping-group { position: absolute; border-radius: 12px; border: 1.5px dashed; padding: 8px; z-index: 0; pointer-events: none; }

/* Table cards */
.table-card { position: absolute; min-width: 200px; max-width: 260px; border-radius: 8px; overflow: hidden; box-shadow: 0 2px 10px rgba(0,0,0,0.3); transition: box-shadow 0.2s, opacity 0.2s; cursor: pointer; z-index: 1; }
.table-card:hover { box-shadow: 0 4px 20px rgba(0,0,0,0.5); }
.table-card.highlighted { box-shadow: 0 0 0 2px #FFD700, 0 4px 20px rgba(255,215,0,0.3); z-index: 5; }
.table-card.dimmed { opacity: 0.15; }
.card-header { padding: 7px 10px; display: flex; justify-content: space-between; align-items: center; font-weight: 600; font-size: 11px; cursor: pointer; gap: 6px; }
.card-header .hdr-name { flex: 1; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.card-header .hdr-type { font-size: 9px; font-weight: 400; opacity: 0.7; }
.card-header .count { font-size: 10px; padding: 1px 7px; border-radius: 10px; background: rgba(255,255,255,0.2); flex-shrink: 0; }
.card-source .card-header { background: var(--source); color: #000; }
.card-intermediate .card-header { background: var(--intermediate); color: #000; }
.card-target .card-header { background: var(--target); color: #fff; }
.card-body { background: var(--bg2); max-height: 280px; overflow-y: auto; }
.card-body.collapsed { display: none; }
.field-row { padding: 4px 10px; font-size: 11px; display: flex; justify-content: space-between; align-items: center; border-bottom: 1px solid var(--border); cursor: pointer; transition: background 0.1s; gap: 4px; }
.field-row:hover { background: var(--bg3); }
.field-row.highlighted { background: rgba(255,215,0,0.15); }
.field-row .fname { flex: 1; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; font-size: 11px; }
.field-row .ftype { color: var(--text2); font-size: 9px; flex-shrink: 0; }
.field-row .fport { font-size: 8px; padding: 1px 4px; border-radius: 3px; flex-shrink: 0; }
.fport-in { background: rgba(46,204,113,0.2); color: var(--source); }
.fport-out { background: rgba(52,152,219,0.2); color: var(--target); }
.fport-io { background: rgba(241,196,15,0.2); color: var(--intermediate); }
.field-more { padding: 4px 10px; font-size: 10px; color: var(--text2); text-align: center; border-bottom: 1px solid var(--border); cursor: pointer; }
.field-more:hover { background: var(--bg3); color: var(--text); }

/* Detail panel */
#detail { width: 0; background: var(--bg2); border-left: 1px solid var(--border); overflow-y: auto; transition: width 0.25s; flex-shrink: 0; }
#detail.open { width: 380px; }
#detail-content { padding: 14px; min-width: 360px; }
.detail-close { float: right; cursor: pointer; font-size: 18px; color: var(--text2); background: none; border: none; padding: 4px; }
.detail-close:hover { color: var(--text); }
.detail-title { font-size: 16px; font-weight: 700; margin-bottom: 4px; word-break: break-all; }
.detail-subtitle { font-size: 11px; color: var(--text2); margin-bottom: 8px; }
.detail-badge { display: inline-block; padding: 2px 10px; border-radius: 12px; font-size: 10px; font-weight: 600; margin-bottom: 10px; }
.detail-section { margin-top: 14px; }
.detail-section h3 { font-size: 11px; text-transform: uppercase; color: var(--text2); letter-spacing: 0.5px; margin-bottom: 6px; display: flex; justify-content: space-between; align-items: center; }
.prop-grid { display: grid; grid-template-columns: auto 1fr; gap: 3px 10px; font-size: 12px; }
.prop-label { color: var(--text2); }
.prop-value { font-weight: 500; word-break: break-all; }
.lineage-item { padding: 6px 8px; background: var(--bg); border-radius: 6px; margin-bottom: 4px; font-size: 11px; border: 1px solid var(--border); cursor: pointer; transition: border-color 0.15s; }
.lineage-item:hover { border-color: var(--link); }
.lineage-item .li-name { font-weight: 600; margin-bottom: 2px; }
.lineage-tag { display: inline-block; padding: 1px 6px; border-radius: 3px; font-size: 9px; font-weight: 600; margin-right: 4px; }
.tag-direct { background: var(--source); color: #000; }
.tag-expr { background: var(--intermediate); color: #000; }
.tag-lookup { background: var(--link); color: #fff; }
.tag-agg { background: var(--accent); color: #fff; }
.tag-union { background: #00bcd4; color: #000; }
.tag-filter { background: #ff9800; color: #000; }
.tag-ref { background: #9b59b6; color: #fff; }
.expr-box { margin-top: 4px; padding: 6px 8px; background: var(--bg3); border-radius: 4px; font-family: 'Consolas', 'Courier New', monospace; font-size: 10px; color: var(--text2); white-space: pre-wrap; word-break: break-all; max-height: 120px; overflow-y: auto; }

/* Zoom controls */
#zoom-controls { position: absolute; bottom: 16px; left: 16px; display: flex; flex-direction: column; gap: 3px; z-index: 50; }
#zoom-controls .btn { width: 32px; height: 32px; padding: 0; display: flex; align-items: center; justify-content: center; font-size: 16px; border-radius: 8px; }

/* Minimap */
#minimap { position: absolute; bottom: 16px; right: 16px; width: 180px; height: 120px; background: var(--bg2); border: 1px solid var(--border); border-radius: 8px; z-index: 50; overflow: hidden; cursor: pointer; }
#minimap canvas { width: 100%; height: 100%; }
#minimap-viewport { position: absolute; border: 1.5px solid var(--link); background: rgba(108,92,231,0.1); pointer-events: none; }

/* Impact Analysis banner */
#impact-banner { display:none; padding:6px 20px; background:rgba(231,76,60,0.1); border-bottom:1px solid rgba(231,76,60,0.3); font-size:11px; color:var(--text); align-items:center; gap:8px; }
#impact-banner.open { display:flex; }
#impact-banner .ib-close { cursor:pointer; color:var(--text2); background:none; border:none; font-size:16px; margin-left:auto; }
#impact-banner .ib-count { background:var(--accent); color:#fff; padding:1px 8px; border-radius:10px; font-weight:600; font-size:10px; }

/* Data quality indicator bars on field rows */
.field-row { position: relative; }
.fq-bar { position:absolute; left:0; top:0; bottom:0; width:3px; border-radius:2px 0 0 2px; }
.fq-pass { background: var(--source); }
.fq-expr { background: var(--intermediate); }
.fq-hard { background: var(--accent); }
.fq-lookup { background: var(--link); }

/* Copy toast */
#copy-toast { position:fixed; bottom:30px; left:50%; transform:translateX(-50%); background:var(--source); color:#000; padding:8px 24px; border-radius:8px; font-size:12px; font-weight:600; z-index:300; display:none; box-shadow:0 4px 12px rgba(0,0,0,0.3); }
#copy-toast.show { display:block; animation: toastFade 2s ease-out forwards; }
#edge-tooltip { position:fixed; background:var(--bg2); color:var(--text); padding:8px 12px; border-radius:6px; font-size:11px; pointer-events:none; display:none; z-index:400; max-width:350px; border:1px solid var(--border); box-shadow:0 4px 16px rgba(0,0,0,0.5); line-height:1.5; }
#edge-tooltip .ett-label { font-weight:600; margin-bottom:3px; }
#edge-tooltip .ett-sub { color:var(--text2); font-size:10px; }
#edge-tooltip .ett-expr { font-family:monospace; font-size:10px; color:var(--intermediate); margin-top:4px; max-height:60px; overflow:hidden; word-break:break-all; }
@keyframes toastFade { 0%{opacity:1;} 70%{opacity:1;} 100%{opacity:0;} }

/* Quality legend in toolbar */
.ql-item { display:inline-flex; align-items:center; gap:3px; font-size:10px; color:var(--text2); }
.ql-bar { width:3px; height:12px; border-radius:1px; }

/* Search dropdown */
#searchResults { position: absolute; top: 100%; left: 0; right: 0; max-height: 320px; overflow-y: auto; background: var(--bg2); border: 1px solid var(--border); border-top: none; border-radius: 0 0 6px 6px; z-index: 200; display: none; }
#searchResults.open { display: block; }
.sr-item { padding: 6px 12px; font-size: 11px; cursor: pointer; border-bottom: 1px solid var(--border); display: flex; justify-content: space-between; align-items: center; gap: 8px; }
.sr-item:hover, .sr-item.active { background: var(--bg3); }
.sr-field { font-weight: 600; flex: 1; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.sr-trans { color: var(--text2); font-size: 10px; flex-shrink: 0; max-width: 150px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.sr-role { font-size: 9px; padding: 1px 6px; border-radius: 3px; flex-shrink: 0; }

/* Field-level edges (overlay SVG) */
#svg-field-edges { position: absolute; top: 0; left: 0; pointer-events: none; overflow: visible; z-index: 2; }

/* Lineage path timeline */
.lineage-path { margin-top: 8px; }
.lp-step { display: flex; align-items: stretch; min-height: 36px; }
.lp-line { width: 24px; display: flex; flex-direction: column; align-items: center; flex-shrink: 0; }
.lp-dot { width: 10px; height: 10px; border-radius: 50%; border: 2px solid; flex-shrink: 0; }
.lp-connector { flex: 1; width: 2px; background: var(--border); }
.lp-content { flex: 1; padding: 2px 0 8px 8px; }
.lp-field { font-weight: 600; font-size: 12px; cursor: pointer; }
.lp-field:hover { text-decoration: underline; }
.lp-trans { font-size: 10px; color: var(--text2); }
.lp-action { font-size: 10px; color: var(--intermediate); font-style: italic; margin-top: 1px; }
.lp-dot-source { border-color: var(--source); background: var(--source); }
.lp-dot-intermediate { border-color: var(--intermediate); background: transparent; }
.lp-dot-target { border-color: var(--target); background: var(--target); }

/* Scrollbar */
::-webkit-scrollbar { width: 5px; }
::-webkit-scrollbar-track { background: var(--bg); }
::-webkit-scrollbar-thumb { background: var(--border); border-radius: 3px; }
</style>
</head>
<body>
<div id="header">
  <h1>{{TITLE}}</h1>
  <div class="stat-badges">
    <span class="badge badge-source">Sources: {{STATS_SOURCES}}</span>
    <span class="badge badge-inter">Transforms: {{STATS_INTERMEDIATE}}</span>
    <span class="badge badge-target">Targets: {{STATS_TARGETS}}</span>
    <span class="badge badge-edge">Edges: {{STATS_EDGES}}</span>
    <span class="badge badge-edge">Fields: {{STATS_FIELDS}}</span>
  </div>
</div>
<div id="toolbar">
  <div style="position:relative;flex:1;min-width:180px;max-width:400px;">
    <input type="text" id="searchBox" placeholder="Search tables or fields... (press / to focus)">
    <div id="searchResults"></div>
  </div>
  <button class="btn" onclick="fitView()">Fit</button>
  <button class="btn" onclick="zoomIn()">+</button>
  <button class="btn" onclick="zoomOut()">&minus;</button>
  <span class="sep"></span>
  <button class="btn" onclick="expandAll()">Expand All</button>
  <button class="btn" onclick="collapseAll()">Collapse All</button>
  <button class="btn" onclick="resetView()">Reset</button>
  <span class="sep"></span>
  <div class="btn-group">
    <button class="btn active" id="btnLR" onclick="setLayout('LR')">LR</button>
    <button class="btn" id="btnTB" onclick="setLayout('TB')">TB</button>
  </div>
  <span class="sep"></span>
  <button class="btn" id="btnImpact" onclick="toggleImpactMode()">Impact Analysis</button>
  <span class="sep"></span>
  <select class="filter-select" id="mappingFilter" onchange="filterMapping(this.value)">
    <option value="">All Mappings</option>
  </select>
  <span class="sep"></span>
  <span class="ql-item"><span class="ql-bar" style="background:var(--source)"></span> Pass-through</span>
  <span class="ql-item"><span class="ql-bar" style="background:var(--intermediate)"></span> Transformed</span>
  <span class="ql-item"><span class="ql-bar" style="background:var(--accent)"></span> Hardcoded</span>
  <span class="ql-item"><span class="ql-bar" style="background:var(--link)"></span> Lookup</span>
</div>
<div id="legend">
  <span class="legend-item"><span class="legend-dot" style="background:var(--source)"></span> Source</span>
  <span class="legend-item"><span class="legend-dot" style="background:var(--intermediate)"></span> Intermediate</span>
  <span class="legend-item"><span class="legend-dot" style="background:var(--target)"></span> Target</span>
  <span style="color:var(--border)">|</span>
  <span class="legend-item"><span class="legend-line" style="border-color:var(--source)"></span> Direct</span>
  <span class="legend-item"><span class="legend-line dashed" style="border-color:var(--intermediate)"></span> Expression</span>
  <span class="legend-item"><span class="legend-line dashed" style="border-color:var(--accent)"></span> Aggregation</span>
  <span class="legend-item"><span class="legend-line dashed" style="border-color:var(--link)"></span> Lookup</span>
  <span class="legend-item"><span class="legend-line" style="border-color:#00bcd4"></span> Union</span>
  <span class="legend-item"><span class="legend-line dashed" style="border-color:#ff9800"></span> Filter/Router</span>
</div>
<!-- Impact analysis banner -->
<div id="impact-banner">
  <span style="font-weight:600;">Impact Analysis:</span>
  <span id="impact-text"></span>
  <button class="ib-close" onclick="clearImpact()">&times;</button>
</div>

<!-- Copy toast -->
<div id="copy-toast">Copied to clipboard!</div>
<div id="edge-tooltip"></div>

<!-- Workflow summary bar -->
<div id="summary-bar" style="padding:5px 20px;background:var(--bg2);border-bottom:1px solid var(--border);font-size:11px;color:var(--text2);display:flex;align-items:flex-start;gap:8px;">
  <span style="font-weight:600;color:var(--text);cursor:pointer;white-space:nowrap;flex-shrink:0;" onclick="toggleFlowSummary()" title="Click to expand/collapse">Data Flow <span id="flow-toggle">&#9660;</span></span>
  <span id="flow-summary" style="flex:1;"></span>
  <span style="cursor:pointer;color:var(--link);font-weight:600;flex-shrink:0;white-space:nowrap;" onclick="toggleHelp()">? Help</span>
</div>

<!-- Help overlay -->
<div id="help-overlay" style="display:none;position:fixed;top:0;left:0;right:0;bottom:0;background:rgba(0,0,0,0.75);z-index:999;overflow-y:auto;">
  <div style="max-width:640px;margin:40px auto;background:var(--bg2);border-radius:12px;border:1px solid var(--border);padding:28px 32px;">
    <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:16px;">
      <h2 style="font-size:18px;font-weight:700;">How to Read This Diagram</h2>
      <button onclick="toggleHelp()" style="background:none;border:none;color:var(--text2);font-size:22px;cursor:pointer;">&times;</button>
    </div>

    <h3 style="font-size:13px;color:var(--source);margin:14px 0 6px;">What is this?</h3>
    <p style="font-size:12px;line-height:1.6;color:var(--text);">This is an <b>interactive data lineage diagram</b> showing how data flows through an Informatica PowerCenter workflow. Each box represents a step in the data pipeline. Lines between boxes show data connections.</p>

    <h3 style="font-size:13px;color:var(--source);margin:14px 0 6px;">The Boxes (Transformations)</h3>
    <div style="font-size:12px;line-height:1.8;">
      <div><span style="display:inline-block;width:12px;height:12px;background:var(--source);border-radius:3px;vertical-align:middle;margin-right:6px;"></span> <b>Green = Source</b> — Where data comes FROM (database tables, files)</div>
      <div><span style="display:inline-block;width:12px;height:12px;background:var(--intermediate);border-radius:3px;vertical-align:middle;margin-right:6px;"></span> <b>Yellow = Transformation</b> — Steps that modify, filter, combine, or enrich the data</div>
      <div><span style="display:inline-block;width:12px;height:12px;background:var(--target);border-radius:3px;vertical-align:middle;margin-right:6px;"></span> <b>Blue = Target</b> — Where data is LOADED TO (destination tables)</div>
    </div>

    <h3 style="font-size:13px;color:var(--intermediate);margin:14px 0 6px;">The Lines (Data Flow)</h3>
    <div style="font-size:12px;line-height:1.8;">
      <div><span style="display:inline-block;width:20px;border-top:2px solid var(--source);vertical-align:middle;margin-right:6px;"></span> <b>Solid green</b> — Direct data pass-through (no change)</div>
      <div><span style="display:inline-block;width:20px;border-top:2px dashed var(--intermediate);vertical-align:middle;margin-right:6px;"></span> <b>Dashed yellow</b> — Data is transformed by an expression/formula</div>
      <div><span style="display:inline-block;width:20px;border-top:2px dashed var(--accent);vertical-align:middle;margin-right:6px;"></span> <b>Dashed red</b> — Data is aggregated (grouped/summed)</div>
      <div><span style="display:inline-block;width:20px;border-top:2px dashed var(--link);vertical-align:middle;margin-right:6px;"></span> <b>Dashed purple</b> — Data is enriched via a lookup (like a JOIN)</div>
      <div><span style="display:inline-block;width:20px;border-top:2px solid #00bcd4;vertical-align:middle;margin-right:6px;"></span> <b>Solid cyan</b> — Data is combined from multiple streams (UNION)</div>
      <div><span style="display:inline-block;width:20px;border-top:2px dashed #ff9800;vertical-align:middle;margin-right:6px;"></span> <b>Dashed orange</b> — Data is filtered or routed by conditions</div>
    </div>
    <p style="font-size:11px;color:var(--text2);margin-top:4px;">Numbers on lines show how many fields flow through that connection.</p>

    <h3 style="font-size:13px;color:var(--target);margin:14px 0 6px;">How to Use</h3>
    <div style="font-size:12px;line-height:1.8;">
      <div><b>Click a field</b> in any box → see its full lineage path, upstream sources, and downstream targets</div>
      <div><b>Click a line</b> between boxes → see all field mappings on that connection</div>
      <div><b>Search</b> (press /) → type a field name to find it and navigate directly to it</div>
      <div><b>Mapping filter</b> → dropdown to show only one mapping at a time</div>
      <div><b>Zoom</b> → mouse wheel or +/- buttons | <b>Pan</b> → click and drag on the background</div>
      <div><b>Expand/Collapse</b> → click a box header to show/hide its fields</div>
      <div><b>Escape</b> → close the detail panel and reset highlights</div>
    </div>

    <h3 style="font-size:13px;color:var(--link);margin:14px 0 6px;">Transformation Types Explained</h3>
    <div style="font-size:12px;line-height:1.8;">
      <div><b>Source Definition / Source Qualifier</b> — Reads data from a database table or file</div>
      <div><b>Expression</b> — Applies formulas to calculate new values or modify existing ones</div>
      <div><b>Filter</b> — Removes rows that don't meet a condition (like SQL WHERE)</div>
      <div><b>Router</b> — Splits data into different streams based on conditions (like IF/ELSE)</div>
      <div><b>Lookup</b> — Fetches extra data from another table (like SQL JOIN)</div>
      <div><b>Aggregator</b> — Groups rows and computes summaries (like SQL GROUP BY)</div>
      <div><b>Custom Transformation / Union</b> — Combines multiple data streams into one</div>
      <div><b>Target Definition</b> — Writes the final data to a destination table</div>
    </div>

    <h3 style="font-size:13px;color:var(--link);margin:14px 0 6px;">Field Quality Indicators (colored left bar)</h3>
    <div style="font-size:12px;line-height:1.8;">
      <div><span style="display:inline-block;width:3px;height:14px;background:var(--source);vertical-align:middle;margin-right:8px;border-radius:1px;"></span> <b>Green</b> — Pass-through: data flows through unchanged</div>
      <div><span style="display:inline-block;width:3px;height:14px;background:var(--intermediate);vertical-align:middle;margin-right:8px;border-radius:1px;"></span> <b>Yellow</b> — Transformed: an expression/formula modifies this field</div>
      <div><span style="display:inline-block;width:3px;height:14px;background:var(--accent);vertical-align:middle;margin-right:8px;border-radius:1px;"></span> <b>Red</b> — Hardcoded or no upstream source</div>
      <div><span style="display:inline-block;width:3px;height:14px;background:var(--link);vertical-align:middle;margin-right:8px;border-radius:1px;"></span> <b>Purple</b> — Enriched via lookup from another table</div>
    </div>

    <h3 style="font-size:13px;color:var(--accent);margin:14px 0 6px;">Impact Analysis</h3>
    <div style="font-size:12px;line-height:1.6;">
      <p>Click <b>"Impact Analysis"</b> in the toolbar to activate. Then click any source field to see: <i>"If I change this field, which target fields are affected?"</i> The banner at the top will list all impacted target fields with clickable links.</p>
    </div>

    <div style="margin-top:20px;text-align:center;">
      <button class="btn" onclick="toggleHelp()" style="padding:8px 32px;font-size:13px;">Got it!</button>
    </div>
  </div>
</div>

<div id="main">
  <div id="canvas-wrap">
    <div id="canvas">
      <svg id="svg-edges" xmlns="http://www.w3.org/2000/svg" width="12000" height="12000"></svg>
      <svg id="svg-field-edges" xmlns="http://www.w3.org/2000/svg" width="12000" height="12000"></svg>
    </div>
    <div id="zoom-controls">
      <button class="btn" onclick="zoomIn()" title="Zoom in">+</button>
      <button class="btn" onclick="zoomOut()" title="Zoom out">&minus;</button>
      <button class="btn" onclick="fitView()" title="Fit all">&#x26F6;</button>
    </div>
    <div id="minimap"><canvas id="minimap-canvas"></canvas><div id="minimap-viewport"></div></div>
  </div>
  <div id="detail">
    <div id="detail-content"></div>
  </div>
</div>

<script>
// --- Data ---
var tables = {{TABLES_JSON}};
var edges = {{EDGES_JSON}};
var exprRefs = {{EXPR_REFS_JSON}};

// --- State ---
var scale = 1, panX = 0, panY = 0;
var layoutDir = 'LR';
var cardExpanded = {};
var cardShowAll = {};
var selectedFieldId = null;
var activeMappingFilter = '';
var FIELD_SHOW_LIMIT = 20;

// --- DOM refs ---
var canvas = document.getElementById('canvas');
var svgEdges = document.getElementById('svg-edges');
var svgFieldEdges = document.getElementById('svg-field-edges');
var canvasWrap = document.getElementById('canvas-wrap');
var detail = document.getElementById('detail');
var detailContent = document.getElementById('detail-content');
var searchBox = document.getElementById('searchBox');
var edgeTooltip = document.getElementById('edge-tooltip');

// --- Indexes ---
var _edgeByTarget = {}, _edgeBySource = {};
edges.forEach(function(e) {
  if (!_edgeByTarget[e.target_field_id]) _edgeByTarget[e.target_field_id] = [];
  _edgeByTarget[e.target_field_id].push(e);
  if (!_edgeBySource[e.source_field_id]) _edgeBySource[e.source_field_id] = [];
  _edgeBySource[e.source_field_id].push(e);
});
var _cssToId = {};
tables.forEach(function(t) { _cssToId[css(t.id)] = t.id; });
var _tableById = {};
tables.forEach(function(t) { _tableById[t.id] = t; });

// Populate mapping filter
var mappings = [];
tables.forEach(function(t) {
  if (t.mapping_name && mappings.indexOf(t.mapping_name) < 0) mappings.push(t.mapping_name);
});
var mf = document.getElementById('mappingFilter');
mappings.forEach(function(m) {
  var o = document.createElement('option'); o.value = m; o.textContent = m; mf.appendChild(o);
});

// --- Layout engine ---
function computeLayout() {
  var visibleTables = tables.filter(function(t) {
    return !activeMappingFilter || t.mapping_name === activeMappingFilter;
  });

  // Assign layers via BFS
  var adj = {}, radj = {};
  visibleTables.forEach(function(t) { adj[t.id] = []; radj[t.id] = []; });
  edges.forEach(function(e) {
    if (adj[e.source_trans_id] && adj[e.target_trans_id] && e.source_trans_id !== e.target_trans_id) {
      if (adj[e.source_trans_id].indexOf(e.target_trans_id) < 0) adj[e.source_trans_id].push(e.target_trans_id);
      if (radj[e.target_trans_id].indexOf(e.source_trans_id) < 0) radj[e.target_trans_id].push(e.source_trans_id);
    }
  });

  var depth = {};
  var queue = [];
  visibleTables.forEach(function(t) {
    if (t.role === 'source' || !radj[t.id] || radj[t.id].length === 0) {
      depth[t.id] = 0; queue.push(t.id);
    }
  });
  while (queue.length > 0) {
    var cur = queue.shift();
    (adj[cur] || []).forEach(function(nxt) {
      var nd = (depth[cur] || 0) + 1;
      if (depth[nxt] === undefined || nd > depth[nxt]) { depth[nxt] = nd; queue.push(nxt); }
    });
  }
  visibleTables.forEach(function(t) { if (depth[t.id] === undefined) depth[t.id] = 0; });

  var layers = {};
  visibleTables.forEach(function(t) { var d = depth[t.id]; if (!layers[d]) layers[d] = []; layers[d].push(t); });

  var layerKeys = Object.keys(layers).map(Number).sort(function(a,b){return a-b;});
  var CARD_W = 240;
  var colGap = layoutDir === 'LR' ? (CARD_W + 100) : (CARD_W + 40);
  var rowGap = 20;
  var startX = 60, startY = 60;

  // Compute card heights
  visibleTables.forEach(function(t) {
    t._expanded = cardExpanded[t.id] !== false;
    var showAll = cardShowAll[t.id];
    var fc = t._expanded ? (showAll ? t.fields.length : Math.min(t.fields.length, FIELD_SHOW_LIMIT)) : 0;
    var moreRow = (!showAll && t.fields.length > FIELD_SHOW_LIMIT && t._expanded) ? 24 : 0;
    t._h = 34 + fc * 24 + moreRow + (t._expanded ? 2 : 0);
    t._w = CARD_W;
  });

  layerKeys.forEach(function(li, ci) {
    var layer = layers[li];
    // Sort within layer: targets at bottom, sources at top, by name
    layer.sort(function(a,b) {
      if (a.role !== b.role) { var ord = {source:0, intermediate:1, target:2}; return (ord[a.role]||1) - (ord[b.role]||1); }
      return a.name.localeCompare(b.name);
    });
    var y = startY;
    layer.forEach(function(t) {
      if (layoutDir === 'LR') { t._x = startX + ci * colGap; t._y = y; }
      else { t._x = y; t._y = startY + ci * colGap; }
      y += t._h + rowGap;
    });
  });

  // Hide filtered-out tables
  tables.forEach(function(t) {
    t._visible = !activeMappingFilter || t.mapping_name === activeMappingFilter;
    if (!t._visible) { t._x = -9999; t._y = -9999; }
  });
}

// --- Render ---
function render() {
  computeLayout();
  renderCards();
  renderEdges();
  applyTransform();
  updateMinimap();
}

function renderCards() {
  // Remove only card/group elements, keep SVGs
  Array.from(canvas.children).forEach(function(ch) { if (ch !== svgEdges && ch !== svgFieldEdges) canvas.removeChild(ch); });
  clearFieldEdges();

  // Mapping group boxes
  var mappingBounds = {};
  tables.forEach(function(t) {
    if (!t._visible) return;
    var mk = t.mapping_name || 'default';
    if (!mappingBounds[mk]) mappingBounds[mk] = {minX:Infinity, minY:Infinity, maxX:-Infinity, maxY:-Infinity};
    var b = mappingBounds[mk];
    if (t._x < b.minX) b.minX = t._x;
    if (t._y < b.minY) b.minY = t._y;
    if (t._x + t._w > b.maxX) b.maxX = t._x + t._w;
    if (t._y + t._h > b.maxY) b.maxY = t._y + t._h;
  });
  var groupColors = ['rgba(46,204,113,0.12)', 'rgba(52,152,219,0.12)', 'rgba(241,196,15,0.12)', 'rgba(108,92,231,0.12)'];
  var groupBorderColors = ['rgba(46,204,113,0.3)', 'rgba(52,152,219,0.3)', 'rgba(241,196,15,0.3)', 'rgba(108,92,231,0.3)'];
  var gi = 0;
  Object.keys(mappingBounds).forEach(function(mk) {
    var b = mappingBounds[mk];
    if (b.minX === Infinity) return;
    var pad = 16;
    var grp = document.createElement('div');
    grp.className = 'mapping-group';
    grp.style.left = (b.minX - pad) + 'px';
    grp.style.top = (b.minY - 28) + 'px';
    grp.style.width = (b.maxX - b.minX + pad * 2) + 'px';
    grp.style.height = (b.maxY - b.minY + pad + 28) + 'px';
    grp.style.background = groupColors[gi % groupColors.length];
    grp.style.borderColor = groupBorderColors[gi % groupBorderColors.length];
    // Label
    var lbl = document.createElement('div');
    lbl.style.cssText = 'position:absolute;top:-1px;left:12px;font-size:10px;font-weight:600;color:var(--text2);background:var(--bg);padding:0 6px;border-radius:3px;';
    lbl.textContent = mk;
    grp.appendChild(lbl);
    canvas.appendChild(grp);
    gi++;
  });

  // Cards
  tables.forEach(function(t) {
    if (!t._visible) return;
    var card = document.createElement('div');
    card.className = 'table-card card-' + t.role;
    card.id = 'card-' + css(t.id);
    card.style.left = t._x + 'px';
    card.style.top = t._y + 'px';
    card.style.width = t._w + 'px';

    var hdr = document.createElement('div');
    hdr.className = 'card-header';
    var typeShort = (t.type || '').replace(' Definition','').replace(' Procedure','').replace(' Transformation','');
    hdr.innerHTML = '<span class="hdr-name" title="' + esc(t.name) + ' (' + esc(t.type) + ')">' + esc(t.name) + '</span>' +
      '<span class="hdr-type">' + esc(typeShort) + '</span>' +
      '<span class="count">' + t.field_count + '</span>';
    hdr.onclick = function() { toggleCard(t.id); };
    card.appendChild(hdr);

    var body = document.createElement('div');
    body.className = 'card-body' + (t._expanded ? '' : ' collapsed');
    body.id = 'body-' + css(t.id);

    var showAll = cardShowAll[t.id];
    var maxShow = showAll ? t.fields.length : Math.min(t.fields.length, FIELD_SHOW_LIMIT);
    for (var i = 0; i < maxShow; i++) {
      var f = t.fields[i];
      var row = document.createElement('div');
      row.className = 'field-row';
      row.id = 'frow-' + css(f.id);
      row.setAttribute('data-field-id', f.id);

      var pt = f.port_type || '';
      var ptClass = 'fport-io', ptLabel = 'I/O';
      if (pt === 'INPUT') { ptClass = 'fport-in'; ptLabel = 'IN'; }
      else if (pt === 'OUTPUT') { ptClass = 'fport-out'; ptLabel = 'OUT'; }

      // Connection indicator
      var connDots = '';
      if (f.in_count > 0) connDots += '<span style="color:var(--source);font-size:9px;" title="' + f.in_count + ' incoming">&larr;' + f.in_count + '</span> ';
      if (f.out_count > 0) connDots += '<span style="color:var(--target);font-size:9px;" title="' + f.out_count + ' outgoing">&rarr;' + f.out_count + '</span>';

      // Data quality indicator
      var fqClass = getFieldQuality(f, t);
      row.innerHTML = '<span class="fq-bar ' + fqClass + '"></span>' +
        '<span class="fname" style="padding-left:6px;" title="' + esc(f.name) + (f.expression ? '\nExpr: ' + esc(f.expression) : '') + '">' + esc(f.name) + '</span>' +
        (f.datatype ? '<span class="ftype">' + esc(f.datatype) + '</span>' : '') +
        '<span class="fport ' + ptClass + '">' + ptLabel + '</span>';
      row.onclick = (function(fld, tbl) { return function(e) { e.stopPropagation(); selectField(fld, tbl); }; })(f, t);
      body.appendChild(row);
    }
    if (!showAll && t.fields.length > FIELD_SHOW_LIMIT) {
      var more = document.createElement('div');
      more.className = 'field-more';
      more.innerHTML = '&#x25BC; Show all ' + t.fields.length + ' fields (' + (t.fields.length - FIELD_SHOW_LIMIT) + ' more)';
      more.onclick = (function(tid) { return function(e) { e.stopPropagation(); cardShowAll[tid] = true; render(); }; })(t.id);
      body.appendChild(more);
    } else if (showAll && t.fields.length > FIELD_SHOW_LIMIT) {
      var less = document.createElement('div');
      less.className = 'field-more';
      less.innerHTML = '&#x25B2; Show fewer';
      less.onclick = (function(tid) { return function(e) { e.stopPropagation(); cardShowAll[tid] = false; render(); }; })(t.id);
      body.appendChild(less);
    }

    card.appendChild(body);
    canvas.appendChild(card);
  });
}

function showEdgeTooltip(ie, evt) {
  var srcName = ie.src.split('/').pop();
  var tgtName = ie.tgt.split('/').pop();
  var actionWords = {
    direct: 'Pass-through', expression: 'Expression Transform', aggregation: 'Aggregation',
    lookup: 'Lookup', filter: 'Filter/Router', union: 'Union/Custom', cross_mapping: 'Cross-Mapping',
  };
  var action = actionWords[ie.style] || ie.style;
  // Collect sample field mappings for this edge
  var samples = [];
  edges.forEach(function(e) {
    if (e.source_trans_id === ie.src && e.target_trans_id === ie.tgt && samples.length < 4) {
      var expr = e.expression_explanation || '';
      var label = (e.from_field || '?') + ' \u2192 ' + (e.to_field || '?');
      if (expr) label += ' (' + expr + ')';
      samples.push(label);
    }
  });
  var h = '<div class="ett-label">' + esc(srcName) + ' \u2192 ' + esc(tgtName) + '</div>';
  h += '<div class="ett-sub">' + esc(action) + ' \u00b7 ' + ie.count + ' field(s)</div>';
  if (samples.length) {
    h += '<div class="ett-expr">' + samples.map(function(s){ return esc(s); }).join('<br>') + '</div>';
    if (ie.count > 4) h += '<div class="ett-sub">... and ' + (ie.count - 4) + ' more</div>';
  }
  edgeTooltip.innerHTML = h;
  edgeTooltip.style.display = 'block';
  edgeTooltip.style.left = (evt.clientX + 14) + 'px';
  edgeTooltip.style.top = (evt.clientY + 14) + 'px';
}
function hideEdgeTooltip() { edgeTooltip.style.display = 'none'; }

function renderEdges() {
  var NS = 'http://www.w3.org/2000/svg';
  while (svgEdges.firstChild) svgEdges.removeChild(svgEdges.firstChild);

  var styleColors = {
    direct: '#2ecc71', expression: '#f1c40f', aggregation: '#e74c3c',
    lookup: '#6c5ce7', filter: '#ff9800', union: '#00bcd4', cross_mapping: '#e91e63',
  };
  var dashStyles = { expression: '6,3', aggregation: '6,3', lookup: '6,3', filter: '4,3' };

  var defs = document.createElementNS(NS, 'defs');
  Object.keys(styleColors).forEach(function(s) {
    var marker = document.createElementNS(NS, 'marker');
    marker.setAttribute('id', 'arrow-' + s);
    marker.setAttribute('viewBox', '0 0 10 8');
    marker.setAttribute('refX', '10'); marker.setAttribute('refY', '4');
    marker.setAttribute('markerWidth', '7'); marker.setAttribute('markerHeight', '5');
    marker.setAttribute('orient', 'auto');
    var mp = document.createElementNS(NS, 'path');
    mp.setAttribute('d', 'M0,0 L10,4 L0,8 Z');
    mp.setAttribute('fill', styleColors[s]); mp.setAttribute('opacity', '0.9');
    marker.appendChild(mp); defs.appendChild(marker);
  });
  svgEdges.appendChild(defs);

  // Aggregate to instance-level
  var instEdges = {};
  edges.forEach(function(e) {
    var st = _tableById[e.source_trans_id], tt = _tableById[e.target_trans_id];
    if (!st || !tt || !st._visible || !tt._visible) return;
    var key = e.source_trans_id + '|' + e.target_trans_id;
    if (!instEdges[key]) instEdges[key] = { src: e.source_trans_id, tgt: e.target_trans_id, style: e.edge_style, count: 0 };
    instEdges[key].count++;
  });

  var ieList = Object.values(instEdges);

  // For edges between same pair, offset them slightly
  ieList.forEach(function(ie, idx) {
    var srcT = _tableById[ie.src], tgtT = _tableById[ie.tgt];
    if (!srcT || !tgtT) return;

    var x1, y1, x2, y2;
    if (layoutDir === 'LR') {
      x1 = srcT._x + srcT._w; y1 = srcT._y + srcT._h / 2;
      x2 = tgtT._x; y2 = tgtT._y + tgtT._h / 2;
    } else {
      x1 = srcT._x + srcT._w / 2; y1 = srcT._y + srcT._h;
      x2 = tgtT._x + tgtT._w / 2; y2 = tgtT._y;
    }

    var col = styleColors[ie.style] || '#78909c';
    var dash = dashStyles[ie.style] || '';

    // Bezier control points with better curve
    var dx = x2 - x1, dy = y2 - y1;
    var d;
    if (layoutDir === 'LR') {
      var cx = Math.max(Math.abs(dx) * 0.4, 60);
      d = 'M' + x1 + ',' + y1 + ' C' + (x1+cx) + ',' + y1 + ' ' + (x2-cx) + ',' + y2 + ' ' + x2 + ',' + y2;
    } else {
      var cy = Math.max(Math.abs(dy) * 0.4, 60);
      d = 'M' + x1 + ',' + y1 + ' C' + x1 + ',' + (y1+cy) + ' ' + x2 + ',' + (y2-cy) + ' ' + x2 + ',' + y2;
    }

    var path = document.createElementNS(NS, 'path');
    path.setAttribute('d', d);
    path.setAttribute('fill', 'none');
    path.setAttribute('stroke', col);
    path.setAttribute('stroke-width', '2');
    if (dash) path.setAttribute('stroke-dasharray', dash);
    path.setAttribute('opacity', '0.6');
    path.setAttribute('marker-end', 'url(#arrow-' + ie.style + ')');
    path.setAttribute('data-edge-key', ie.src + '|' + ie.tgt);
    // Make edges clickable
    path.style.pointerEvents = 'stroke';
    path.style.cursor = 'pointer';
    path.onclick = function() { showEdgeDetail(ie); };
    (function(ieRef) {
      path.onmouseenter = function(ev) { showEdgeTooltip(ieRef, ev); path.setAttribute('stroke-width', '4'); path.setAttribute('opacity', '1'); };
      path.onmousemove = function(ev) { edgeTooltip.style.left = (ev.clientX + 14) + 'px'; edgeTooltip.style.top = (ev.clientY + 14) + 'px'; };
      path.onmouseleave = function() { hideEdgeTooltip(); path.setAttribute('stroke-width', '2'); path.setAttribute('opacity', '0.6'); };
    })(ie);
    svgEdges.appendChild(path);

    // Edge label: action + count
    var mx = (x1 + x2) / 2, my = (y1 + y2) / 2;
    var actionWords = {
      direct: '', expression: 'transforms', aggregation: 'aggregates',
      lookup: 'lookups', filter: 'filters', union: 'combines', cross_mapping: 'cross-map',
    };
    var actionWord = actionWords[ie.style] || '';
    var labelText = ie.count + (actionWord ? ' ' + actionWord : '');

    // Background rect for readability
    var bg = document.createElementNS(NS, 'rect');
    var estW = labelText.length * 5.5 + 10;
    bg.setAttribute('x', mx - estW/2); bg.setAttribute('y', my - 16);
    bg.setAttribute('width', estW); bg.setAttribute('height', 14);
    bg.setAttribute('rx', '3'); bg.setAttribute('fill', 'var(--bg)'); bg.setAttribute('opacity', '0.85');
    svgEdges.appendChild(bg);

    var label = document.createElementNS(NS, 'text');
    label.setAttribute('x', mx); label.setAttribute('y', my - 6);
    label.setAttribute('text-anchor', 'middle');
    label.setAttribute('fill', col); label.setAttribute('font-size', '9');
    label.setAttribute('font-weight', '600');
    label.setAttribute('font-family', 'Segoe UI, sans-serif');
    label.setAttribute('opacity', '0.95');
    label.textContent = labelText;
    svgEdges.appendChild(label);
  });
}

// --- Interactions ---
function toggleCard(id) {
  cardExpanded[id] = cardExpanded[id] === false;
  render();
}
function expandAll() { tables.forEach(function(t) { cardExpanded[t.id] = true; }); render(); }
function collapseAll() { tables.forEach(function(t) { cardExpanded[t.id] = false; cardShowAll[t.id] = false; }); render(); }

function selectField(field, table) {
  selectedFieldId = field.id;
  if (impactMode) {
    runImpactAnalysis(field.id);
    showDetail(field, table);
  } else {
    highlightLineage(field.id);
    drawFieldEdges(field.id);
    showDetail(field, table);
  }
}

function highlightLineage(fieldId) {
  var upstream = new Set(), downstream = new Set();
  function traceUp(fid, depth) {
    if (upstream.has(fid) || depth > 40) return;
    upstream.add(fid);
    (_edgeByTarget[fid] || []).forEach(function(e) { traceUp(e.source_field_id, depth+1); });
  }
  function traceDown(fid, depth) {
    if (downstream.has(fid) || depth > 40) return;
    downstream.add(fid);
    (_edgeBySource[fid] || []).forEach(function(e) { traceDown(e.target_field_id, depth+1); });
  }
  traceUp(fieldId, 0); traceDown(fieldId, 0);

  var connected = new Set([...upstream, ...downstream]);
  var connectedTrans = new Set();
  connected.forEach(function(fid) { var t = getTransId(fid); if (t) connectedTrans.add(t); });

  var connectedEdgeKeys = new Set();
  edges.forEach(function(e) {
    if (connected.has(e.source_field_id) && connected.has(e.target_field_id)) {
      connectedEdgeKeys.add(e.source_trans_id + '|' + e.target_trans_id);
    }
  });

  document.querySelectorAll('.table-card').forEach(function(c) {
    var raw = c.id.replace('card-', '');
    var tid = _cssToId[raw];
    if (!tid) return;
    c.classList.toggle('dimmed', connectedTrans.size > 0 && !connectedTrans.has(tid));
    c.classList.toggle('highlighted', connectedTrans.has(tid));
  });
  document.querySelectorAll('.field-row').forEach(function(r) {
    var fid = r.getAttribute('data-field-id');
    r.classList.toggle('highlighted', connected.has(fid));
  });
  document.querySelectorAll('#svg-edges path[data-edge-key]').forEach(function(p) {
    var key = p.getAttribute('data-edge-key');
    if (connectedEdgeKeys.has(key)) {
      p.setAttribute('opacity', '1'); p.setAttribute('stroke-width', '3');
    } else {
      p.setAttribute('opacity', '0.08'); p.setAttribute('stroke-width', '1');
    }
  });
}

function showDetail(field, table) {
  detail.classList.add('open');

  var upstreams = _edgeByTarget[field.id] || [];
  var downstreams = _edgeBySource[field.id] || [];
  var refs = exprRefs[field.id] || [];

  var roleColor = table.role === 'source' ? 'var(--source)' :
    (table.role === 'target' ? 'var(--target)' : 'var(--intermediate)');
  var roleName = table.role.charAt(0).toUpperCase() + table.role.slice(1);

  var h = '<button class="detail-close" onclick="closeDetail()">&times;</button>';
  h += '<div class="detail-title" style="display:flex;align-items:center;gap:8px;">' + esc(field.name) + '<span onclick="copyFieldName(\'' + escAttr(field.name) + '\')" style="cursor:pointer;font-size:12px;color:var(--text2);flex-shrink:0;" title="Copy field name">&#x2398;</span></div>';
  h += '<div class="detail-subtitle">' + esc(table.name) + ' &middot; ' + esc(table.type) + ' &middot; ' + esc(table.mapping_name) + '</div>';
  h += '<span class="detail-badge" style="background:' + roleColor + ';color:#000;">' + roleName + '</span>';

  // Properties
  h += '<div class="detail-section"><h3>Properties</h3>';
  h += '<div class="prop-grid">';
  h += '<span class="prop-label">Datatype</span><span class="prop-value">' + esc(field.datatype || 'N/A') + '</span>';
  h += '<span class="prop-label">Port</span><span class="prop-value">' + esc(field.port_type || 'N/A') + '</span>';
  h += '<span class="prop-label">Connections</span><span class="prop-value">' + upstreams.length + ' in / ' + downstreams.length + ' out</span>';
  if (field.qualified_target) h += '<span class="prop-label">Target Table</span><span class="prop-value">' + esc(field.qualified_target) + '</span>';
  if (field.qualified_source) h += '<span class="prop-label">Source Table</span><span class="prop-value">' + esc(field.qualified_source) + '</span>';
  if (field.hop_count) h += '<span class="prop-label">Hop Count</span><span class="prop-value">' + field.hop_count + '</span>';
  h += '</div>';
  var transDesc = getTransDescription(table.type);
  if (transDesc) h += '<div style="margin-top:8px;padding:6px 8px;background:var(--bg);border-radius:6px;font-size:11px;color:var(--text2);line-height:1.5;border-left:3px solid var(--link);">' + esc(transDesc) + '</div>';
  h += '</div>';

  // Expression
  if (field.expression && field.expression !== field.name) {
    h += '<div class="detail-section"><h3>Expression</h3>';
    h += '<div class="expr-box">' + esc(field.expression) + '</div>';
    if (field.expression_explanation) h += '<div style="margin-top:4px;font-size:11px;color:var(--text2);font-style:italic;">' + esc(field.expression_explanation) + '</div>';
    h += '</div>';
  }

  // SQL Logic (from enriched lineage — shows SQL-like representation)
  if (field.sql_logic) {
    h += '<div class="detail-section"><h3>SQL Logic</h3>';
    h += '<div class="expr-box" style="white-space:pre-wrap;">' + esc(field.sql_logic) + '</div></div>';
  }

  // Transformation Explanation (English narrative of end-to-end flow)
  if (field.transformation_explanation) {
    h += '<div class="detail-section"><h3>Transformation Explanation</h3>';
    h += '<div style="font-size:12px;line-height:1.6;color:var(--text);padding:6px 8px;background:var(--bg);border-radius:6px;border-left:3px solid var(--intermediate);">' + esc(field.transformation_explanation) + '</div></div>';
  }

  // Router Condition
  if (field.router_condition) {
    h += '<div class="detail-section"><h3>Router Condition</h3>';
    h += '<div class="expr-box" style="white-space:pre-wrap;border-left-color:#00BCD4;">' + esc(field.router_condition) + '</div></div>';
  }

  // Filter Condition
  if (field.filter_condition) {
    h += '<div class="detail-section"><h3>Filter Condition</h3>';
    h += '<div class="expr-box" style="white-space:pre-wrap;border-left-color:#FF9800;">' + esc(field.filter_condition) + '</div></div>';
  }

  // Lookup Details
  if (field.lookup_name || field.lookup_condition) {
    h += '<div class="detail-section"><h3>Lookup Details</h3>';
    if (field.lookup_name) h += '<div style="font-size:12px;margin-bottom:4px;"><span style="color:var(--text2);">Lookup:</span> <b>' + esc(field.lookup_name) + '</b></div>';
    if (field.lookup_condition) h += '<div class="expr-box" style="white-space:pre-wrap;border-left-color:#9C27B0;">' + esc(field.lookup_condition) + '</div>';
    h += '</div>';
  }

  // Transformation Chain (compact notation)
  if (field.transformation_chain) {
    h += '<div class="detail-section"><h3>Transformation Chain</h3>';
    h += '<div style="font-size:11px;color:var(--text2);font-family:monospace;padding:6px 8px;background:var(--bg);border-radius:6px;word-break:break-all;">' + esc(field.transformation_chain) + '</div></div>';
  }

  // Full Lineage Path
  var pathHtml = renderLineagePath(field.id);
  var pathNodes = buildLineagePath(field.id);
  if (pathNodes.length > 1) {
    h += '<div class="detail-section"><h3>Full Lineage Path <span style="background:var(--bg3);padding:1px 8px;border-radius:10px;">' + pathNodes.length + ' hops</span> <span class="btn" style="padding:2px 10px;font-size:10px;margin-left:4px;" onclick="copyLineagePath(\'' + escAttr(field.id) + '\')">Copy Path</span></h3>';
    h += pathHtml;
    h += '</div>';
  }

  // Upstream
  h += '<div class="detail-section"><h3>Upstream Sources <span style="background:var(--bg3);padding:1px 8px;border-radius:10px;">' + upstreams.length + '</span></h3>';
  if (upstreams.length === 0) h += '<div style="font-size:11px;color:var(--text2);padding:4px 0;">No upstream connectors — ultimate source or consumed by expressions</div>';
  upstreams.forEach(function(e) {
    var tag = getEdgeTag(e.edge_style);
    var srcTrans = e.source_trans_id.split('/').pop();
    h += '<div class="lineage-item" onclick="navigateToField(\'' + escAttr(e.source_field_id) + '\')">' +
      '<div class="li-name">' + esc(e.from_field || e.source_field_id.split('/').pop()) + '</div>' +
      '<span class="lineage-tag ' + tag.cls + '">' + tag.label + '</span>' +
      '<span style="font-size:10px;color:var(--text2);">from ' + esc(srcTrans) + '</span></div>';
  });
  h += '</div>';

  // Downstream
  h += '<div class="detail-section"><h3>Downstream Targets <span style="background:var(--bg3);padding:1px 8px;border-radius:10px;">' + downstreams.length + '</span></h3>';
  if (downstreams.length === 0) h += '<div style="font-size:11px;color:var(--text2);padding:4px 0;">No downstream connectors — terminal target or internal to transformation</div>';
  downstreams.forEach(function(e) {
    var tgtTrans = e.target_trans_id.split('/').pop();
    h += '<div class="lineage-item" onclick="navigateToField(\'' + escAttr(e.target_field_id) + '\')">' +
      '<div class="li-name">' + esc(e.to_field || e.target_field_id.split('/').pop()) + '</div>' +
      '<span style="font-size:10px;color:var(--text2);">to ' + esc(tgtTrans) + '</span></div>';
  });
  h += '</div>';

  // Expression references (fields that use this field in their expression)
  if (refs.length > 0) {
    h += '<div class="detail-section"><h3>Used In Expressions <span style="background:var(--bg3);padding:1px 8px;border-radius:10px;">' + refs.length + '</span></h3>';
    refs.forEach(function(r) {
      h += '<div class="lineage-item" onclick="navigateToField(\'' + escAttr(r.field_id) + '\')">' +
        '<div class="li-name">' + esc(r.field_name) + '</div>' +
        '<span class="lineage-tag tag-ref">EXPR REF</span>' +
        '<div class="expr-box" style="margin-top:3px;max-height:60px;">' + esc(r.expression) + '</div></div>';
    });
    h += '</div>';
  }

  detailContent.innerHTML = h;
}

function showEdgeDetail(ie) {
  detail.classList.add('open');
  var srcT = _tableById[ie.src], tgtT = _tableById[ie.tgt];
  if (!srcT || !tgtT) return;

  // Find individual field edges
  var fieldEdges = edges.filter(function(e) {
    return e.source_trans_id === ie.src && e.target_trans_id === ie.tgt;
  });

  var h = '<button class="detail-close" onclick="closeDetail()">&times;</button>';
  h += '<div class="detail-title">Edge: ' + ie.count + ' field connections</div>';
  h += '<div class="detail-subtitle">' + esc(srcT.name) + ' &rarr; ' + esc(tgtT.name) + '</div>';
  var tag = getEdgeTag(ie.style);
  h += '<span class="detail-badge lineage-tag ' + tag.cls + '">' + tag.label + '</span>';

  h += '<div class="detail-section"><h3>Field Mappings <span style="background:var(--bg3);padding:1px 8px;border-radius:10px;">' + fieldEdges.length + '</span></h3>';
  fieldEdges.forEach(function(e) {
    h += '<div class="lineage-item">' +
      '<span style="color:var(--source);font-weight:600;">' + esc(e.from_field) + '</span>' +
      ' <span style="color:var(--text2);">&rarr;</span> ' +
      '<span style="color:var(--target);font-weight:600;">' + esc(e.to_field) + '</span></div>';
  });
  h += '</div>';

  detailContent.innerHTML = h;
}

function navigateToField(fieldId) {
  var transId = getTransId(fieldId);
  if (!transId) return;
  var table = _tableById[transId];
  if (!table) return;
  var field = null;
  table.fields.forEach(function(f) { if (f.id === fieldId) field = f; });
  if (field) {
    // Expand the card
    cardExpanded[transId] = true;
    // Check if we need to show all fields
    var idx = table.fields.indexOf(field);
    if (idx >= FIELD_SHOW_LIMIT) cardShowAll[transId] = true;
    render();
    selectField(field, table);
    // Pan to the card
    var el = document.getElementById('card-' + css(transId));
    if (el) {
      var rect = canvasWrap.getBoundingClientRect();
      panX = rect.width / 2 - (table._x + table._w / 2) * scale;
      panY = rect.height / 2 - (table._y + table._h / 2) * scale;
      applyTransform();
    }
  }
}

function closeDetail() {
  detail.classList.remove('open');
  selectedFieldId = null;
  document.getElementById('impact-banner').classList.remove('open');
  document.querySelectorAll('.table-card').forEach(function(c) { c.classList.remove('dimmed', 'highlighted'); });
  document.querySelectorAll('.field-row').forEach(function(r) { r.classList.remove('highlighted'); });
  document.querySelectorAll('#svg-edges path[data-edge-key]').forEach(function(p) {
    p.setAttribute('opacity', '0.6'); p.setAttribute('stroke-width', '2');
  });
  clearFieldEdges();
}

// --- Feature: Field-Level Edge Drawing ---
function clearFieldEdges() {
  while (svgFieldEdges.firstChild) svgFieldEdges.removeChild(svgFieldEdges.firstChild);
}

function drawFieldEdges(fieldId) {
  clearFieldEdges();
  var NS = 'http://www.w3.org/2000/svg';

  // Collect connected field-level edges for the full lineage
  var upstream = new Set(), downstream = new Set();
  function traceUp(fid, d) { if (upstream.has(fid)||d>40) return; upstream.add(fid); (_edgeByTarget[fid]||[]).forEach(function(e){traceUp(e.source_field_id,d+1);}); }
  function traceDown(fid, d) { if (downstream.has(fid)||d>40) return; downstream.add(fid); (_edgeBySource[fid]||[]).forEach(function(e){traceDown(e.target_field_id,d+1);}); }
  traceUp(fieldId, 0); traceDown(fieldId, 0);
  var connected = new Set([...upstream, ...downstream]);

  // Get field-level edges that connect two connected fields
  var fieldEdges = edges.filter(function(e) {
    return connected.has(e.source_field_id) && connected.has(e.target_field_id);
  });

  var styleColors = {
    direct: '#2ecc71', expression: '#f1c40f', aggregation: '#e74c3c',
    lookup: '#6c5ce7', filter: '#ff9800', union: '#00bcd4', cross_mapping: '#e91e63',
  };

  // Arrow defs
  var defs = document.createElementNS(NS, 'defs');
  var marker = document.createElementNS(NS, 'marker');
  marker.setAttribute('id', 'farrow');
  marker.setAttribute('viewBox', '0 0 8 6'); marker.setAttribute('refX', '8'); marker.setAttribute('refY', '3');
  marker.setAttribute('markerWidth', '6'); marker.setAttribute('markerHeight', '4'); marker.setAttribute('orient', 'auto');
  var mp = document.createElementNS(NS, 'path');
  mp.setAttribute('d', 'M0,0 L8,3 L0,6 Z'); mp.setAttribute('fill', '#FFD700'); mp.setAttribute('opacity', '0.9');
  marker.appendChild(mp); defs.appendChild(marker);
  svgFieldEdges.appendChild(defs);

  fieldEdges.forEach(function(e) {
    var srcPos = getFieldRowPos(e.source_field_id, 'right');
    var tgtPos = getFieldRowPos(e.target_field_id, 'left');
    if (!srcPos || !tgtPos) return;

    var col = styleColors[e.edge_style] || '#FFD700';
    var x1 = srcPos.x, y1 = srcPos.y, x2 = tgtPos.x, y2 = tgtPos.y;

    var dx = x2 - x1;
    var cx = Math.max(Math.abs(dx) * 0.35, 40);
    var d;
    if (layoutDir === 'LR') {
      d = 'M'+x1+','+y1+' C'+(x1+cx)+','+y1+' '+(x2-cx)+','+y2+' '+x2+','+y2;
    } else {
      var cy = Math.max(Math.abs(y2-y1)*0.35, 40);
      d = 'M'+x1+','+y1+' C'+x1+','+(y1+cy)+' '+x2+','+(y2-cy)+' '+x2+','+y2;
    }

    var path = document.createElementNS(NS, 'path');
    path.setAttribute('d', d);
    path.setAttribute('fill', 'none');
    path.setAttribute('stroke', col);
    path.setAttribute('stroke-width', '1.5');
    path.setAttribute('opacity', '0.8');
    path.setAttribute('marker-end', 'url(#farrow)');
    svgFieldEdges.appendChild(path);

    // Small dots at endpoints
    [srcPos, tgtPos].forEach(function(p) {
      var c = document.createElementNS(NS, 'circle');
      c.setAttribute('cx', p.x); c.setAttribute('cy', p.y);
      c.setAttribute('r', '3'); c.setAttribute('fill', col); c.setAttribute('opacity', '0.9');
      svgFieldEdges.appendChild(c);
    });
  });
}

function getFieldRowPos(fieldId, side) {
  // Calculate field row position based on card layout data
  var transId = getTransId(fieldId);
  var table = _tableById[transId];
  if (!table || !table._visible) return null;

  var fieldName = fieldId.split('/').pop();
  var fieldIdx = -1;
  var showAll = cardShowAll[table.id];
  var maxShow = showAll ? table.fields.length : Math.min(table.fields.length, FIELD_SHOW_LIMIT);
  for (var i = 0; i < maxShow; i++) {
    if (table.fields[i].id === fieldId) { fieldIdx = i; break; }
  }

  // If field not visible (collapsed or beyond limit), use card center
  var expanded = cardExpanded[table.id] !== false;
  if (!expanded || fieldIdx < 0) {
    var cy = table._y + table._h / 2;
    return { x: side === 'right' ? table._x + table._w : table._x, y: cy };
  }

  var headerH = 34;
  var rowH = 24;
  var fy = table._y + headerH + fieldIdx * rowH + rowH / 2;
  var fx = side === 'right' ? table._x + table._w : table._x;
  return { x: fx, y: fy };
}

// --- Feature: Full Lineage Path ---
function buildLineagePath(fieldId) {
  // Trace complete path from ultimate source to ultimate target through the selected field
  // First trace all the way up, then all the way down
  var pathUp = [];
  function tracePathUp(fid, visited) {
    if (visited.has(fid)) return;
    visited.add(fid);
    var incoming = _edgeByTarget[fid] || [];
    if (incoming.length === 0) {
      pathUp.push(fid);
      return;
    }
    // Follow first incoming (primary path)
    incoming.forEach(function(e) {
      tracePathUp(e.source_field_id, visited);
    });
    pathUp.push(fid);
  }
  tracePathUp(fieldId, new Set());

  var pathDown = [];
  function tracePathDown(fid, visited) {
    if (visited.has(fid)) return;
    visited.add(fid);
    pathDown.push(fid);
    var outgoing = _edgeBySource[fid] || [];
    outgoing.forEach(function(e) {
      tracePathDown(e.target_field_id, visited);
    });
  }
  tracePathDown(fieldId, new Set());

  // Merge: pathUp gives source->selected, pathDown gives selected->targets
  // Remove duplicate of selected field
  var fullPath = pathUp.slice();
  for (var i = 1; i < pathDown.length; i++) {
    if (fullPath.indexOf(pathDown[i]) < 0) fullPath.push(pathDown[i]);
  }

  return fullPath;
}

function renderLineagePath(fieldId) {
  var path = buildLineagePath(fieldId);
  if (path.length <= 1) return '<div style="font-size:11px;color:var(--text2);padding:4px 0;">No multi-hop lineage path found</div>';

  var h = '<div class="lineage-path">';
  path.forEach(function(fid, idx) {
    var transId = getTransId(fid);
    var table = _tableById[transId];
    var fieldName = fid.split('/').pop();
    var transName = transId ? transId.split('/').pop() : '';
    var role = table ? table.role : 'intermediate';
    var isSelected = fid === fieldId;

    // Determine what happens at this step
    var action = '';
    if (idx > 0) {
      var prevFid = path[idx - 1];
      var connectingEdge = edges.find(function(e) { return e.source_field_id === prevFid && e.target_field_id === fid; });
      if (connectingEdge) {
        var actionMap = {
          direct: 'pass-through', expression: 'expression transform', aggregation: 'aggregation',
          lookup: 'lookup enrichment', filter: 'filter/router', union: 'union merge', cross_mapping: 'cross-mapping link'
        };
        action = actionMap[connectingEdge.edge_style] || connectingEdge.edge_style;
      }
      // Check if field name changed
      var prevName = prevFid.split('/').pop();
      if (prevName !== fieldName && action) action += ' (renamed)';
    }

    // Check expression
    var field = null;
    if (table) table.fields.forEach(function(f) { if (f.id === fid) field = f; });
    var expr = field && field.expression && field.expression !== fieldName ? field.expression : '';

    var dotClass = 'lp-dot-' + role;
    var nameStyle = isSelected ? 'color:#FFD700;font-weight:700;' : '';

    h += '<div class="lp-step">';
    h += '<div class="lp-line">';
    if (idx > 0) h += '<div class="lp-connector"></div>';
    h += '<div class="lp-dot ' + dotClass + '"></div>';
    if (idx < path.length - 1) h += '<div class="lp-connector"></div>';
    h += '</div>';
    h += '<div class="lp-content">';
    if (action) h += '<div class="lp-action">' + esc(action) + '</div>';
    h += '<div class="lp-field" style="' + nameStyle + '" onclick="navigateToField(\'' + escAttr(fid) + '\')">' + esc(fieldName) + '</div>';
    h += '<div class="lp-trans">' + esc(transName) + (table ? ' <span style="opacity:0.6;">(' + esc(table.type || '') + ')</span>' : '') + '</div>';
    if (expr) h += '<div class="expr-box" style="margin:2px 0 0;max-height:40px;font-size:9px;">' + esc(expr.substring(0, 100)) + (expr.length > 100 ? '...' : '') + '</div>';
    h += '</div></div>';
  });
  h += '</div>';
  return h;
}

function filterMapping(val) {
  activeMappingFilter = val;
  render();
  setTimeout(fitView, 50);
}

function resetView() {
  closeDetail();
  searchBox.value = '';
  activeMappingFilter = '';
  document.getElementById('mappingFilter').value = '';
  tables.forEach(function(t) { cardExpanded[t.id] = true; cardShowAll[t.id] = false; });
  render();
  setTimeout(fitView, 50);
}

// --- Pan & Zoom ---
function applyTransform() {
  canvas.style.transform = 'translate(' + panX + 'px,' + panY + 'px) scale(' + scale + ')';
  updateMinimap();
}
function zoomIn() { zoomTo(scale * 1.25); }
function zoomOut() { zoomTo(scale / 1.25); }
function zoomTo(s) {
  var rect = canvasWrap.getBoundingClientRect();
  var cx = rect.width / 2, cy = rect.height / 2;
  var ns = Math.min(Math.max(s, 0.1), 3);
  panX = cx - (cx - panX) * (ns / scale);
  panY = cy - (cy - panY) * (ns / scale);
  scale = ns;
  applyTransform();
}
function fitView() {
  var vis = tables.filter(function(t) { return t._visible; });
  if (vis.length === 0) return;
  var minX=Infinity, minY=Infinity, maxX=-Infinity, maxY=-Infinity;
  vis.forEach(function(t) {
    if (t._x < minX) minX = t._x;
    if (t._y < minY) minY = t._y;
    if (t._x + t._w > maxX) maxX = t._x + t._w;
    if (t._y + t._h > maxY) maxY = t._y + t._h;
  });
  var w = canvasWrap.clientWidth, h = canvasWrap.clientHeight;
  var gw = maxX - minX + 120, gh = maxY - minY + 100;
  scale = Math.min(w / gw, h / gh, 1.2);
  panX = (w - gw * scale) / 2 - (minX - 40) * scale;
  panY = (h - gh * scale) / 2 - (minY - 30) * scale;
  applyTransform();
}

// Mouse pan
var dragging = false, dragStartX, dragStartY;
canvasWrap.addEventListener('mousedown', function(e) {
  if (e.target === canvasWrap || e.target.tagName === 'svg' || e.target.tagName === 'DIV' && e.target.id === 'canvas') {
    dragging = true; dragStartX = e.clientX - panX; dragStartY = e.clientY - panY;
    canvasWrap.classList.add('grabbing');
  }
});
window.addEventListener('mousemove', function(e) {
  if (dragging) { panX = e.clientX - dragStartX; panY = e.clientY - dragStartY; applyTransform(); }
});
window.addEventListener('mouseup', function() { dragging = false; canvasWrap.classList.remove('grabbing'); });
canvasWrap.addEventListener('wheel', function(e) {
  e.preventDefault();
  var factor = e.deltaY > 0 ? 0.9 : 1.1;
  var rect = canvasWrap.getBoundingClientRect();
  var mx = e.clientX - rect.left, my = e.clientY - rect.top;
  var ns = Math.min(Math.max(scale * factor, 0.1), 3);
  panX = mx - (mx - panX) * (ns / scale);
  panY = my - (my - panY) * (ns / scale);
  scale = ns;
  applyTransform();
}, { passive: false });

// Layout toggle
function setLayout(dir) {
  layoutDir = dir;
  document.getElementById('btnLR').classList.toggle('active', dir === 'LR');
  document.getElementById('btnTB').classList.toggle('active', dir === 'TB');
  render(); setTimeout(fitView, 50);
}

// --- Feature: Search with Navigate Dropdown ---
var searchResults = document.getElementById('searchResults');
var srActiveIdx = -1;
var srItems = [];

// Build flat search index
var _searchIndex = [];
tables.forEach(function(t) {
  t.fields.forEach(function(f) {
    _searchIndex.push({ fieldName: f.name, fieldId: f.id, transName: t.name, transId: t.id, role: t.role, type: t.type });
  });
});

searchBox.addEventListener('input', function() {
  var q = this.value.toLowerCase().trim();
  srActiveIdx = -1;
  // Also highlight cards
  document.querySelectorAll('.table-card').forEach(function(c) { c.classList.remove('dimmed', 'highlighted'); });
  document.querySelectorAll('.field-row').forEach(function(r) { r.classList.remove('highlighted'); });

  if (q.length < 2) { searchResults.classList.remove('open'); searchResults.innerHTML = ''; srItems = []; return; }

  // Find matches (field name or transformation name)
  var matches = [];
  _searchIndex.forEach(function(si) {
    if (si.fieldName.toLowerCase().indexOf(q) >= 0 || si.transName.toLowerCase().indexOf(q) >= 0) {
      matches.push(si);
    }
  });

  // Deduplicate and limit
  var seen = {};
  var unique = [];
  matches.forEach(function(m) {
    if (!seen[m.fieldId] && unique.length < 50) { seen[m.fieldId] = true; unique.push(m); }
  });
  // Sort: exact field name match first, then by name
  unique.sort(function(a, b) {
    var aExact = a.fieldName.toLowerCase() === q ? 0 : 1;
    var bExact = b.fieldName.toLowerCase() === q ? 0 : 1;
    if (aExact !== bExact) return aExact - bExact;
    return a.fieldName.localeCompare(b.fieldName);
  });

  srItems = unique;
  if (unique.length === 0) {
    searchResults.innerHTML = '<div style="padding:8px 12px;font-size:11px;color:var(--text2);">No matches found</div>';
    searchResults.classList.add('open');
    return;
  }

  var roleColors = { source: 'var(--source)', intermediate: 'var(--intermediate)', target: 'var(--target)' };
  var h = '';
  unique.forEach(function(m, idx) {
    h += '<div class="sr-item" data-idx="' + idx + '" onclick="searchNavigate(' + idx + ')">' +
      '<span class="sr-field">' + highlightMatch(esc(m.fieldName), q) + '</span>' +
      '<span class="sr-trans">' + esc(m.transName) + '</span>' +
      '<span class="sr-role" style="background:' + (roleColors[m.role] || 'var(--bg3)') + ';color:#000;">' + m.role.charAt(0).toUpperCase() + '</span>' +
      '</div>';
  });
  searchResults.innerHTML = h;
  searchResults.classList.add('open');

  // Also dim/highlight cards
  var matchedTrans = new Set();
  unique.forEach(function(m) { matchedTrans.add(m.transId); });
  tables.forEach(function(t) {
    if (!t._visible) return;
    var el = document.getElementById('card-' + css(t.id));
    if (el) {
      if (matchedTrans.has(t.id)) el.classList.add('highlighted');
      else el.classList.add('dimmed');
    }
  });
});

searchBox.addEventListener('keydown', function(e) {
  if (!searchResults.classList.contains('open') || srItems.length === 0) return;
  if (e.key === 'ArrowDown') { e.preventDefault(); srActiveIdx = Math.min(srActiveIdx + 1, srItems.length - 1); updateSrActive(); }
  else if (e.key === 'ArrowUp') { e.preventDefault(); srActiveIdx = Math.max(srActiveIdx - 1, 0); updateSrActive(); }
  else if (e.key === 'Enter' && srActiveIdx >= 0) { e.preventDefault(); searchNavigate(srActiveIdx); }
});

function updateSrActive() {
  document.querySelectorAll('.sr-item').forEach(function(el, i) { el.classList.toggle('active', i === srActiveIdx); });
  var active = document.querySelector('.sr-item.active');
  if (active) active.scrollIntoView({ block: 'nearest' });
}

function searchNavigate(idx) {
  var m = srItems[idx];
  if (!m) return;
  searchResults.classList.remove('open');
  searchBox.value = m.fieldName;
  navigateToField(m.fieldId);
}

function highlightMatch(text, q) {
  var i = text.toLowerCase().indexOf(q.toLowerCase());
  if (i < 0) return text;
  return text.substring(0, i) + '<mark style="background:#FFD700;color:#000;border-radius:2px;padding:0 1px;">' + text.substring(i, i + q.length) + '</mark>' + text.substring(i + q.length);
}

searchBox.addEventListener('blur', function() { setTimeout(function() { searchResults.classList.remove('open'); }, 200); });

document.addEventListener('keydown', function(e) {
  if (e.key === '/' && document.activeElement !== searchBox) { e.preventDefault(); searchBox.focus(); }
  if (e.key === 'Escape') {
    searchResults.classList.remove('open');
    closeDetail();
    searchBox.blur();
    searchBox.value = '';
    document.querySelectorAll('.table-card').forEach(function(c) { c.classList.remove('dimmed', 'highlighted'); });
  }
});

// Minimap
function updateMinimap() {
  var mc = document.getElementById('minimap-canvas');
  var mv = document.getElementById('minimap-viewport');
  if (!mc) return;
  var ctx = mc.getContext('2d');
  var mw = 180, mh = 120;
  mc.width = mw; mc.height = mh;
  ctx.clearRect(0, 0, mw, mh);

  var vis = tables.filter(function(t) { return t._visible; });
  if (vis.length === 0) return;
  var minX=Infinity, minY=Infinity, maxX=-Infinity, maxY=-Infinity;
  vis.forEach(function(t) {
    if (t._x < minX) minX = t._x; if (t._y < minY) minY = t._y;
    if (t._x+t._w > maxX) maxX = t._x+t._w; if (t._y+t._h > maxY) maxY = t._y+t._h;
  });
  var gw = maxX - minX + 40, gh = maxY - minY + 40;
  var s = Math.min(mw / gw, mh / gh);
  var ox = (mw - gw * s) / 2 - (minX - 20) * s;
  var oy = (mh - gh * s) / 2 - (minY - 20) * s;

  var roleColors = { source: '#2ecc71', intermediate: '#f1c40f', target: '#3498db' };
  vis.forEach(function(t) {
    ctx.fillStyle = roleColors[t.role] || '#888';
    ctx.globalAlpha = 0.7;
    ctx.fillRect(t._x * s + ox, t._y * s + oy, t._w * s, Math.max(t._h * s, 2));
  });
  ctx.globalAlpha = 1;

  // Viewport rect
  var cw = canvasWrap.clientWidth, ch = canvasWrap.clientHeight;
  var vx = (-panX / scale) * s + ox;
  var vy = (-panY / scale) * s + oy;
  var vw = (cw / scale) * s;
  var vh = (ch / scale) * s;
  mv.style.left = Math.max(0, vx) + 'px';
  mv.style.top = Math.max(0, vy) + 'px';
  mv.style.width = Math.min(vw, mw) + 'px';
  mv.style.height = Math.min(vh, mh) + 'px';
}

// Helpers
function esc(s) { if (!s) return ''; var d = document.createElement('div'); d.textContent = s; return d.innerHTML; }
function escAttr(s) { return (s || '').replace(/'/g, "\\'").replace(/"/g, '&quot;'); }
function css(id) { return id.replace(/[^a-zA-Z0-9]/g, '__'); }
function getTransId(fid) { var i = fid.lastIndexOf('/'); return i > 0 ? fid.substring(0, i) : null; }
function getEdgeTag(style) {
  var tags = {
    direct: {cls:'tag-direct', label:'DIRECT'}, expression: {cls:'tag-expr', label:'EXPRESSION'},
    aggregation: {cls:'tag-agg', label:'AGGREGATION'}, lookup: {cls:'tag-lookup', label:'LOOKUP'},
    filter: {cls:'tag-filter', label:'FILTER/ROUTER'}, union: {cls:'tag-union', label:'UNION'},
    cross_mapping: {cls:'tag-ref', label:'CROSS-MAP'},
  };
  return tags[style] || {cls:'tag-direct', label: style.toUpperCase()};
}

// --- Feature: Data Quality Indicators ---
function getFieldQuality(field, table) {
  var hasUpstream = field.in_count > 0;
  var hasExpr = field.expression && field.expression !== field.name && field.expression !== '';
  var isLookupField = (table.type || '').toLowerCase().indexOf('lookup') >= 0 && (field.port_type || '').toUpperCase() === 'OUTPUT';
  var isPassThrough = hasUpstream && !hasExpr;

  // Check if field comes from a lookup (target trans is lookup)
  if (isLookupField) return 'fq-lookup';
  // Check if upstream exists but comes via a lookup edge
  if (hasUpstream) {
    var upEdges = _edgeByTarget[field.id] || [];
    var fromLookup = upEdges.some(function(e) { return e.edge_style === 'lookup'; });
    if (fromLookup) return 'fq-lookup';
  }
  if (!hasUpstream && hasExpr) return 'fq-hard';  // hardcoded/derived with no source
  if (!hasUpstream && !hasExpr && table.role !== 'source') return 'fq-hard';  // orphan
  if (hasExpr) return 'fq-expr';  // transformed
  if (isPassThrough) return 'fq-pass';  // pass-through
  return '';  // source fields (no indicator needed)
}

// --- Feature: Impact Analysis Mode ---
var impactMode = false;

function toggleImpactMode() {
  impactMode = !impactMode;
  document.getElementById('btnImpact').classList.toggle('active', impactMode);
  if (!impactMode) clearImpact();
}

function clearImpact() {
  document.getElementById('impact-banner').classList.remove('open');
  document.querySelectorAll('.table-card').forEach(function(c) { c.classList.remove('dimmed', 'highlighted'); });
  document.querySelectorAll('.field-row').forEach(function(r) { r.classList.remove('highlighted'); });
  document.querySelectorAll('#svg-edges path[data-edge-key]').forEach(function(p) {
    p.setAttribute('opacity', '0.6'); p.setAttribute('stroke-width', '2');
  });
  clearFieldEdges();
}

function runImpactAnalysis(fieldId) {
  // Trace ALL downstream from this field to find every target field impacted
  var downstream = new Set();
  function traceDown(fid, d) {
    if (downstream.has(fid) || d > 50) return;
    downstream.add(fid);
    (_edgeBySource[fid] || []).forEach(function(e) { traceDown(e.target_field_id, d+1); });
  }
  traceDown(fieldId, 0);

  // Find which of these are target fields
  var impactedTargets = [];
  var impactedTrans = new Set();
  downstream.forEach(function(fid) {
    var tid = getTransId(fid);
    if (!tid) return;
    impactedTrans.add(tid);
    var table = _tableById[tid];
    if (table && table.role === 'target') {
      var fname = fid.split('/').pop();
      impactedTargets.push({ fieldName: fname, tableName: table.name, fieldId: fid });
    }
  });

  // Also add expression refs (fields that use this in their expression)
  var refs = exprRefs[fieldId] || [];
  refs.forEach(function(r) {
    // Trace downstream from each referencing field too
    var refDown = new Set();
    function traceRefDown(fid, d) {
      if (refDown.has(fid) || d > 50) return;
      refDown.add(fid);
      impactedTrans.add(getTransId(fid));
      (_edgeBySource[fid] || []).forEach(function(e) { traceRefDown(e.target_field_id, d+1); });
    }
    traceRefDown(r.field_id, 0);
    refDown.forEach(function(fid) {
      downstream.add(fid);
      var tid = getTransId(fid);
      if (tid) impactedTrans.add(tid);
      var table = _tableById[tid];
      if (table && table.role === 'target') {
        var fname = fid.split('/').pop();
        if (!impactedTargets.some(function(t) { return t.fieldId === fid; })) {
          impactedTargets.push({ fieldName: fname, tableName: table.name, fieldId: fid });
        }
      }
    });
  });

  // Highlight
  document.querySelectorAll('.table-card').forEach(function(c) {
    var raw = c.id.replace('card-', '');
    var tid = _cssToId[raw];
    if (!tid) return;
    c.classList.toggle('dimmed', !impactedTrans.has(tid));
    c.classList.toggle('highlighted', impactedTrans.has(tid));
  });
  document.querySelectorAll('.field-row').forEach(function(r) {
    var fid = r.getAttribute('data-field-id');
    r.classList.toggle('highlighted', downstream.has(fid));
  });
  // Highlight edges
  var connectedEdgeKeys = new Set();
  edges.forEach(function(e) {
    if (downstream.has(e.source_field_id) && downstream.has(e.target_field_id)) {
      connectedEdgeKeys.add(e.source_trans_id + '|' + e.target_trans_id);
    }
  });
  document.querySelectorAll('#svg-edges path[data-edge-key]').forEach(function(p) {
    var key = p.getAttribute('data-edge-key');
    if (connectedEdgeKeys.has(key)) { p.setAttribute('opacity', '1'); p.setAttribute('stroke-width', '3'); }
    else { p.setAttribute('opacity', '0.08'); p.setAttribute('stroke-width', '1'); }
  });

  drawFieldEdges(fieldId);

  // Build banner
  var sourceField = fieldId.split('/').pop();
  var sourceTrans = (getTransId(fieldId) || '').split('/').pop();
  var banner = document.getElementById('impact-banner');
  var bannerText = document.getElementById('impact-text');

  if (impactedTargets.length === 0) {
    bannerText.innerHTML = 'Changing <b>' + esc(sourceField) + '</b> in <b>' + esc(sourceTrans) + '</b> has <span class="ib-count">0</span> target field impacts (data may be filtered out or unused).';
  } else {
    var targetList = impactedTargets.map(function(t) {
      return '<span onclick="navigateToField(\'' + escAttr(t.fieldId) + '\')" style="cursor:pointer;text-decoration:underline;color:var(--target);">' + esc(t.fieldName) + '</span> (' + esc(t.tableName) + ')';
    }).join(', ');
    bannerText.innerHTML = 'Changing <b>' + esc(sourceField) + '</b> in <b>' + esc(sourceTrans) + '</b> impacts <span class="ib-count">' + impactedTargets.length + '</span> target field' + (impactedTargets.length > 1 ? 's' : '') + ': ' + targetList;
  }
  banner.classList.add('open');
}

// --- Feature: Copy Lineage Path ---
function copyLineagePath(fieldId) {
  var path = buildLineagePath(fieldId);
  if (path.length === 0) return;

  var lines = [];
  var selectedName = fieldId.split('/').pop();
  lines.push('=== Lineage Path for: ' + selectedName + ' ===');
  lines.push('');

  path.forEach(function(fid, idx) {
    var transId = getTransId(fid);
    var fieldName = fid.split('/').pop();
    var transName = transId ? transId.split('/').pop() : '';
    var table = _tableById[transId];
    var typeName = table ? table.type : '';
    var role = table ? table.role.toUpperCase() : '';

    var prefix = idx === 0 ? '[SOURCE]' : (idx === path.length - 1 ? '[TARGET]' : '  [' + (idx) + ']  ');
    var line = prefix + '  ' + fieldName + '  (' + transName + ' / ' + typeName + ')';

    // Action between steps
    if (idx > 0) {
      var prevFid = path[idx - 1];
      var edge = edges.find(function(e) { return e.source_field_id === prevFid && e.target_field_id === fid; });
      var action = edge ? edge.edge_style : 'connection';
      var prevName = prevFid.split('/').pop();
      var renamed = prevName !== fieldName ? ' (renamed: ' + prevName + ' -> ' + fieldName + ')' : '';
      lines.push('         |  ' + action + renamed);
    }
    lines.push(line);
  });

  lines.push('');
  lines.push('Total hops: ' + path.length);

  var text = lines.join('\n');

  navigator.clipboard.writeText(text).then(function() {
    showCopyToast('Lineage path copied to clipboard!');
  }).catch(function() {
    // Fallback
    var ta = document.createElement('textarea');
    ta.value = text; document.body.appendChild(ta); ta.select();
    document.execCommand('copy'); document.body.removeChild(ta);
    showCopyToast('Lineage path copied to clipboard!');
  });
}

function copyFieldName(name) {
  navigator.clipboard.writeText(name).catch(function() {
    var ta = document.createElement('textarea');
    ta.value = name; document.body.appendChild(ta); ta.select();
    document.execCommand('copy'); document.body.removeChild(ta);
  });
  showCopyToast('Copied: ' + name);
}

function showCopyToast(msg) {
  var toast = document.getElementById('copy-toast');
  toast.textContent = msg;
  toast.classList.remove('show');
  void toast.offsetWidth; // force reflow
  toast.classList.add('show');
  setTimeout(function() { toast.classList.remove('show'); }, 2200);
}

// --- Help overlay ---
function toggleHelp() {
  var h = document.getElementById('help-overlay');
  h.style.display = h.style.display === 'none' ? 'block' : 'none';
}

// --- Transformation type plain-English descriptions ---
var transTypeDescriptions = {
  'source definition': 'Reads raw data from a database table or flat file. This is where the data journey begins.',
  'source qualifier': 'Controls how source data is read — can apply SQL filters, joins, or custom queries before data enters the pipeline.',
  'expression': 'Applies formulas and calculations to transform data values. Like a spreadsheet formula applied to every row.',
  'filter': 'Removes rows that do not meet a specified condition. Only matching rows pass through to the next step.',
  'router': 'Splits incoming data into multiple output streams based on different conditions — like a multi-way IF/ELSE.',
  'lookup procedure': 'Fetches additional data from a reference table based on matching keys — similar to a SQL JOIN or VLOOKUP.',
  'aggregator': 'Groups rows together and computes summary values (COUNT, SUM, MAX, MIN) — like SQL GROUP BY.',
  'custom transformation': 'Combines multiple input data streams into a single output stream (UNION ALL).',
  'target definition': 'Writes the final transformed data into the destination database table. This is where the data journey ends.',
  'mapplet': 'A reusable group of transformations packaged together — like a function that can be called from multiple places.',
};

function getTransDescription(type) {
  if (!type) return '';
  return transTypeDescriptions[type.toLowerCase()] || '';
}

// --- Auto-generated workflow summary ---
function buildFlowSummary() {
  var sources = tables.filter(function(t) { return t.role === 'source' && t.type && t.type.toLowerCase().indexOf('qualifier') < 0; });
  var targets = tables.filter(function(t) { return t.role === 'target'; });
  var intermediates = tables.filter(function(t) { return t.role === 'intermediate'; });

  var sourceNames = sources.map(function(t) { return t.name.replace(/^sc_/, '').replace(/^SQ_sc_/, ''); });
  var targetNames = targets.map(function(t) { return t.name.replace(/^sc_/, ''); });

  // Detect what transformations are involved
  var ops = [];
  var hasExpr = intermediates.some(function(t) { return (t.type||'').toLowerCase().indexOf('expression') >= 0; });
  var hasFilter = intermediates.some(function(t) { return (t.type||'').toLowerCase().indexOf('filter') >= 0; });
  var hasRouter = intermediates.some(function(t) { return (t.type||'').toLowerCase().indexOf('router') >= 0; });
  var hasLookup = intermediates.some(function(t) { return (t.type||'').toLowerCase().indexOf('lookup') >= 0; });
  var hasAgg = intermediates.some(function(t) { return (t.type||'').toLowerCase().indexOf('aggregat') >= 0; });
  var hasUnion = intermediates.some(function(t) { var tt = (t.type||'').toLowerCase(); return tt.indexOf('custom') >= 0 || tt.indexOf('union') >= 0; });
  if (hasExpr) ops.push('transforms values');
  if (hasUnion) ops.push('combines streams');
  if (hasFilter) ops.push('filters rows');
  if (hasRouter) ops.push('routes by condition');
  if (hasLookup) ops.push('enriches via lookups');
  if (hasAgg) ops.push('aggregates/groups');

  var unique = function(arr) { var s = {}; return arr.filter(function(x) { if (s[x]) return false; s[x]=1; return true; }); };
  sourceNames = unique(sourceNames);
  targetNames = unique(targetNames);

  var summary = 'Reads from <b>' + sourceNames.join(', ') + '</b>';
  if (ops.length > 0) summary += ' &rarr; ' + ops.join(', ');
  summary += ' &rarr; loads into <b>' + targetNames.join(', ') + '</b>';
  summary += ' <span style="color:var(--text2);margin-left:8px;">(' + tables.length + ' steps, ' + edges.length + ' field connections)</span>';

  document.getElementById('flow-summary').innerHTML = summary;
}

var flowExpanded = true;
function toggleFlowSummary() {
  flowExpanded = !flowExpanded;
  var el = document.getElementById('flow-summary');
  var toggle = document.getElementById('flow-toggle');
  if (flowExpanded) {
    el.style.display = '';
    toggle.innerHTML = '&#9660;';
  } else {
    el.style.display = 'none';
    toggle.innerHTML = '&#9654;';
  }
}

// Init
tables.forEach(function(t) { cardExpanded[t.id] = true; });
render();
buildFlowSummary();
setTimeout(fitView, 200);

// Show help on first visit
if (!localStorage.getItem('dag_help_seen')) {
  toggleHelp();
  localStorage.getItem('dag_help_seen', '1');
}
</script>
</body>
</html>"""
