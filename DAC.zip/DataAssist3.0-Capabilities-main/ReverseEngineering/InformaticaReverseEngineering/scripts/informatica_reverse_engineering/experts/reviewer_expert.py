"""Reviewer Expert - Verifies completeness and identifies issues."""

from typing import Any, Dict, List, Optional, Set

from .base_expert import BaseExpert, ExpertType, ExpertContext
from .models.expert_result import ExpertResult, ExpertStatus


class ReviewerExpert(BaseExpert):
    """
    Expert for reviewing and validating lineage results.

    Responsibilities:
    - Verify completeness of lineage extraction
    - Check for unmapped fields
    - Validate lineage paths
    - Generate coverage report
    - Identify gaps and issues
    - Coordinate refinement with other experts
    """

    def __init__(self):
        super().__init__("ReviewerExpert", ExpertType.REVIEWER)

    def analyze(self, context: ExpertContext) -> ExpertResult:
        """Review and validate all expert results."""
        self.logger.info("Starting review analysis")

        results = {
            "coverage_report": {},
            "issues": [],
            "warnings": [],
            "recommendations": [],
            "quality_score": 0.0,
        }

        # Get previous expert results
        integration_result = context.previous_results.get("IntegrationExpert")
        field_mapping_result = context.previous_results.get("FieldMapping")
        structure_result = context.previous_results.get("MappingStructure")

        if not integration_result:
            return self._create_result(
                status=ExpertStatus.FAILED,
                errors=["Integration results required for review"],
            )

        # Review coverage
        coverage = self._review_coverage(context, field_mapping_result)
        results["coverage_report"] = coverage

        # Identify issues
        issues = self._identify_issues(context, integration_result, field_mapping_result)
        results["issues"] = issues

        # Generate warnings
        warnings = self._generate_warnings(context, integration_result)
        results["warnings"] = warnings

        # Generate recommendations
        recommendations = self._generate_recommendations(results)
        results["recommendations"] = recommendations

        # Calculate quality score
        quality_score = self._calculate_quality_score(results)
        results["quality_score"] = quality_score

        # Determine if refinement is needed
        needs_refinement = quality_score < 0.8 or len(issues) > 5

        self.logger.info(f"Review complete. Quality score: {quality_score:.2f}")

        return self._create_result(
            status=ExpertStatus.NEEDS_REFINEMENT if needs_refinement else ExpertStatus.COMPLETED,
            data=results,
            warnings=warnings,
            confidence=quality_score,
        )

    def _review_coverage(
        self, context: ExpertContext, field_mapping_result: Optional[ExpertResult]
    ) -> Dict[str, Any]:
        """Review lineage coverage."""
        doc = context.document
        coverage = {
            "total_sources": len(doc.sources),
            "total_targets": len(doc.targets),
            "total_source_fields": 0,
            "total_target_fields": 0,
            "mapped_target_fields": 0,
            "unmapped_target_fields": 0,
            "coverage_percentage": 0.0,
            "by_mapping": {},
        }

        # Count fields
        for source in doc.sources:
            coverage["total_source_fields"] += source.field_count

        for target in doc.targets:
            coverage["total_target_fields"] += target.field_count

        # Get unmapped fields from field mapping result
        if field_mapping_result and field_mapping_result.is_successful:
            unmapped = field_mapping_result.data.get("unmapped_fields", [])
            coverage["unmapped_target_fields"] = len(unmapped)
            coverage["mapped_target_fields"] = coverage["total_target_fields"] - len(unmapped)

            # Coverage by mapping
            for mapping in doc.mappings:
                mapping_unmapped = [u for u in unmapped if u.get("mapping") == mapping.name]
                mapping_targets = sum(t.field_count for t in mapping.targets)
                mapping_mapped = mapping_targets - len(mapping_unmapped)

                coverage["by_mapping"][mapping.name] = {
                    "total_fields": mapping_targets,
                    "mapped_fields": mapping_mapped,
                    "unmapped_fields": len(mapping_unmapped),
                    "coverage_percentage": (mapping_mapped / mapping_targets * 100) if mapping_targets > 0 else 100,
                }

        # Calculate overall coverage
        if coverage["total_target_fields"] > 0:
            coverage["coverage_percentage"] = (
                coverage["mapped_target_fields"] / coverage["total_target_fields"] * 100
            )

        return coverage

    def _identify_issues(
        self,
        context: ExpertContext,
        integration_result: ExpertResult,
        field_mapping_result: Optional[ExpertResult],
    ) -> List[Dict[str, Any]]:
        """Identify issues in the lineage extraction."""
        issues = []

        # Check for unmapped fields
        if field_mapping_result and field_mapping_result.is_successful:
            unmapped = field_mapping_result.data.get("unmapped_fields", [])
            for field in unmapped:
                issues.append({
                    "type": "unmapped_field",
                    "severity": "warning",
                    "mapping": field.get("mapping", ""),
                    "target": field.get("target", ""),
                    "field": field.get("field", ""),
                    "message": f"Target field {field.get('target')}.{field.get('field')} has no incoming data flow",
                })

        # Check for circular dependencies
        if field_mapping_result and field_mapping_result.is_successful:
            graphs = field_mapping_result.data.get("lineage_graphs", {})
            for mapping_name, graph in graphs.items():
                if self._has_circular_dependency(graph):
                    issues.append({
                        "type": "circular_dependency",
                        "severity": "error",
                        "mapping": mapping_name,
                        "message": f"Mapping {mapping_name} may have circular dependencies",
                    })

        # Check for orphan transformations
        for mapping in context.document.mappings:
            orphans = self._find_orphan_transformations(mapping)
            for orphan in orphans:
                issues.append({
                    "type": "orphan_transformation",
                    "severity": "warning",
                    "mapping": mapping.name,
                    "transformation": orphan,
                    "message": f"Transformation {orphan} in mapping {mapping.name} has no connections",
                })

        # Check expert failures
        for name, result in context.previous_results.items():
            if result.status == ExpertStatus.FAILED:
                issues.append({
                    "type": "expert_failure",
                    "severity": "error",
                    "expert": name,
                    "errors": result.errors,
                    "message": f"Expert {name} failed during analysis",
                })

        return issues

    def _has_circular_dependency(self, graph_data: Dict) -> bool:
        """Check if graph has circular dependencies."""
        edges = graph_data.get("edges", [])
        adjacency: Dict[str, Set[str]] = {}

        for edge in edges:
            source = f"{edge['source_instance']}.{edge['source_field']}"
            target = f"{edge['target_instance']}.{edge['target_field']}"

            if source not in adjacency:
                adjacency[source] = set()
            adjacency[source].add(target)

        # DFS to detect cycle
        visited = set()
        rec_stack = set()

        def has_cycle(node: str) -> bool:
            visited.add(node)
            rec_stack.add(node)

            for neighbor in adjacency.get(node, []):
                if neighbor not in visited:
                    if has_cycle(neighbor):
                        return True
                elif neighbor in rec_stack:
                    return True

            rec_stack.remove(node)
            return False

        for node in adjacency:
            if node not in visited:
                if has_cycle(node):
                    return True

        return False

    def _find_orphan_transformations(self, mapping) -> List[str]:
        """Find transformations with no connections."""
        connected_instances = set()

        for conn in mapping.connectors:
            connected_instances.add(conn.from_instance.lower())
            connected_instances.add(conn.to_instance.lower())

        orphans = []
        for trans in mapping.transformations:
            if trans.name.lower() not in connected_instances:
                orphans.append(trans.name)

        return orphans

    def _generate_warnings(
        self, context: ExpertContext, integration_result: ExpertResult
    ) -> List[str]:
        """Generate warning messages."""
        warnings = []

        # Collect warnings from all experts
        for name, result in context.previous_results.items():
            warnings.extend(result.warnings)

        # Add integration warnings
        warnings.extend(integration_result.warnings)

        # Check for low confidence
        for name, result in context.previous_results.items():
            if result.confidence < 0.7:
                warnings.append(f"Expert {name} has low confidence ({result.confidence:.2f})")

        return warnings

    def _generate_recommendations(self, results: Dict) -> List[str]:
        """Generate recommendations for improvement."""
        recommendations = []

        # Based on coverage
        coverage = results.get("coverage_report", {})
        if coverage.get("coverage_percentage", 100) < 90:
            recommendations.append(
                f"Coverage is {coverage['coverage_percentage']:.1f}%. "
                "Review unmapped target fields and add missing transformations."
            )

        # Based on issues
        issues = results.get("issues", [])
        error_count = sum(1 for i in issues if i.get("severity") == "error")
        warning_count = sum(1 for i in issues if i.get("severity") == "warning")

        if error_count > 0:
            recommendations.append(
                f"Found {error_count} errors that need immediate attention."
            )

        if warning_count > 5:
            recommendations.append(
                f"Found {warning_count} warnings. Consider reviewing the mapping configuration."
            )

        # General recommendations
        unmapped_count = coverage.get("unmapped_target_fields", 0)
        if unmapped_count > 0:
            recommendations.append(
                f"{unmapped_count} target fields are unmapped. "
                "These may be populated by default values or external processes."
            )

        return recommendations

    def _calculate_quality_score(self, results: Dict) -> float:
        """Calculate overall quality score (0.0 to 1.0)."""
        score = 1.0

        # Deduct for coverage
        coverage_pct = results.get("coverage_report", {}).get("coverage_percentage", 100)
        if coverage_pct < 100:
            score -= (100 - coverage_pct) / 200  # Max 0.5 deduction

        # Deduct for issues
        issues = results.get("issues", [])
        error_count = sum(1 for i in issues if i.get("severity") == "error")
        warning_count = sum(1 for i in issues if i.get("severity") == "warning")

        score -= error_count * 0.1  # 0.1 per error
        score -= warning_count * 0.02  # 0.02 per warning

        return max(0.0, min(1.0, score))
