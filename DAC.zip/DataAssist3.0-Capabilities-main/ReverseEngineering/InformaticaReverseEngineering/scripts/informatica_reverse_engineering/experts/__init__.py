"""Multi-Expert Architecture for Informatica Reverse Engineering."""

from .base_expert import BaseExpert, ExpertType
from .mapping_structure_expert import MappingStructureExpert
from .field_mapping_expert import FieldMappingExpert
from .operator_logic_expert import OperatorLogicExpert
from .integration_expert import IntegrationExpert
from .visual_lineage_expert import VisualLineageExpert
from .reviewer_expert import ReviewerExpert

# Phase 2 XDM-enhanced experts (optional imports)
try:
    from .field_mapping_expert_xdm import FieldMappingExpertXDM
    from .pattern_detector import PatternDetector, PatternType, PatternSeverity, DetectedPattern
    from .context_aware_expression_analyzer import (
        ContextAwareExpressionAnalyzer,
        AnalyzedExpression,
        FieldReference,
        FunctionCall,
    )
    XDM_EXPERTS_AVAILABLE = True
except ImportError:
    XDM_EXPERTS_AVAILABLE = False

__all__ = [
    "BaseExpert",
    "ExpertType",
    "MappingStructureExpert",
    "FieldMappingExpert",
    "OperatorLogicExpert",
    "IntegrationExpert",
    "VisualLineageExpert",
    "ReviewerExpert",
]

# Add XDM exports if available (Phase 2)
if XDM_EXPERTS_AVAILABLE:
    __all__.extend([
        "FieldMappingExpertXDM",
        "PatternDetector",
        "PatternType",
        "PatternSeverity",
        "DetectedPattern",
        "ContextAwareExpressionAnalyzer",
        "AnalyzedExpression",
        "FieldReference",
        "FunctionCall",
        "XDM_EXPERTS_AVAILABLE",
    ])

# Phase 3 experts (optional imports)
try:
    from .dependency_graph_expert import (
        DependencyGraphExpert,
        CircularDependency,
        ImpactAnalysis,
        MappingDependencyGraph,
    )
    from .transformation_chain_analyzer import (
        TransformationChainAnalyzer,
        TransformationChain,
        ChainType,
        OptimizationType,
        OptimizationRecommendation,
        ParallelExecutionOpportunity,
        ChainAnalysisResult,
    )
    PHASE3_EXPERTS_AVAILABLE = True
except ImportError:
    PHASE3_EXPERTS_AVAILABLE = False

# Add Phase 3 exports if available
if PHASE3_EXPERTS_AVAILABLE:
    __all__.extend([
        "DependencyGraphExpert",
        "CircularDependency",
        "ImpactAnalysis",
        "MappingDependencyGraph",
        "TransformationChainAnalyzer",
        "TransformationChain",
        "ChainType",
        "OptimizationType",
        "OptimizationRecommendation",
        "ParallelExecutionOpportunity",
        "ChainAnalysisResult",
        "PHASE3_EXPERTS_AVAILABLE",
    ])
