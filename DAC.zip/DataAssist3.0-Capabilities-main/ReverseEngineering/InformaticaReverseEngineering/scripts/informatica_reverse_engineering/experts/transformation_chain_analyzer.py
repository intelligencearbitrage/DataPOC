"""
Transformation Chain Analyzer for Informatica Mappings.

Analyzes transformation chains to identify:
- Critical paths and bottlenecks
- Transformation dependencies
- Parallel execution opportunities
- Optimization recommendations
"""

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Set, Tuple
from enum import Enum

from ..utils.mapping_ast import (
    MappingAST,
    TransformationNode,
    NodeType,
    AdvancedGraphAnalyzer,
    StronglyConnectedComponent,
    CriticalPath,
    DependencyInfo,
)
from ..utils.logging_config import get_logger


logger = get_logger("transformation_chain_analyzer")


class ChainType(Enum):
    """Types of transformation chains."""
    LINEAR = "linear"
    BRANCHING = "branching"
    MERGING = "merging"
    PARALLEL = "parallel"
    CYCLIC = "cyclic"


class OptimizationType(Enum):
    """Types of optimization recommendations."""
    PARALLELIZE = "parallelize"
    COMBINE_EXPRESSIONS = "combine_expressions"
    REDUCE_LOOKUPS = "reduce_lookups"
    ADD_FILTER_EARLY = "add_filter_early"
    REMOVE_REDUNDANT = "remove_redundant"
    BREAK_CYCLE = "break_cycle"
    SPLIT_CHAIN = "split_chain"


@dataclass
class TransformationChain:
    """Represents a chain of transformations."""
    nodes: List[str]
    chain_type: ChainType
    source_node: str
    target_node: str
    length: int
    total_complexity: int
    bottleneck_node: Optional[str] = None
    bottleneck_type: Optional[str] = None
    expressions_count: int = 0
    lookups_count: int = 0
    aggregators_count: int = 0

    def to_dict(self) -> Dict[str, Any]:
        return {
            "nodes": self.nodes,
            "chain_type": self.chain_type.value,
            "source_node": self.source_node,
            "target_node": self.target_node,
            "length": self.length,
            "total_complexity": self.total_complexity,
            "bottleneck_node": self.bottleneck_node,
            "bottleneck_type": self.bottleneck_type,
            "expressions_count": self.expressions_count,
            "lookups_count": self.lookups_count,
            "aggregators_count": self.aggregators_count,
        }


@dataclass
class OptimizationRecommendation:
    """Recommendation for optimizing a transformation chain."""
    optimization_type: OptimizationType
    description: str
    affected_nodes: List[str]
    estimated_impact: str  # "high", "medium", "low"
    details: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "optimization_type": self.optimization_type.value,
            "description": self.description,
            "affected_nodes": self.affected_nodes,
            "estimated_impact": self.estimated_impact,
            "details": self.details,
        }


@dataclass
class ParallelExecutionOpportunity:
    """Identifies transformations that could run in parallel."""
    parallel_groups: List[List[str]]
    sync_point: str
    potential_speedup: float

    def to_dict(self) -> Dict[str, Any]:
        return {
            "parallel_groups": self.parallel_groups,
            "sync_point": self.sync_point,
            "potential_speedup": self.potential_speedup,
            "group_count": len(self.parallel_groups),
        }


@dataclass
class ChainAnalysisResult:
    """Complete result of chain analysis."""
    mapping_name: str
    chains: List[TransformationChain]
    critical_paths: List[CriticalPath]
    sccs: List[StronglyConnectedComponent]
    parallel_opportunities: List[ParallelExecutionOpportunity]
    recommendations: List[OptimizationRecommendation]
    metrics: Dict[str, Any]

    def to_dict(self) -> Dict[str, Any]:
        return {
            "mapping_name": self.mapping_name,
            "chains": [c.to_dict() for c in self.chains],
            "critical_paths": [p.to_dict() for p in self.critical_paths],
            "strongly_connected_components": [s.to_dict() for s in self.sccs],
            "parallel_opportunities": [p.to_dict() for p in self.parallel_opportunities],
            "recommendations": [r.to_dict() for r in self.recommendations],
            "metrics": self.metrics,
        }


class TransformationChainAnalyzer:
    """
    Analyzes transformation chains in Informatica mappings.

    Uses the MappingAST and AdvancedGraphAnalyzer to:
    - Identify all transformation chains
    - Find critical paths and bottlenecks
    - Detect parallel execution opportunities
    - Generate optimization recommendations
    """

    # Complexity weights for different transformation types
    COMPLEXITY_WEIGHTS = {
        NodeType.SOURCE.value: 1,
        NodeType.SOURCE_QUALIFIER.value: 2,
        NodeType.TARGET.value: 1,
        NodeType.EXPRESSION.value: 3,
        NodeType.FILTER.value: 2,
        NodeType.AGGREGATOR.value: 5,
        NodeType.LOOKUP.value: 4,
        NodeType.JOINER.value: 5,
        NodeType.ROUTER.value: 3,
        NodeType.NORMALIZER.value: 4,
        NodeType.UPDATE_STRATEGY.value: 2,
        NodeType.SORTER.value: 4,
        NodeType.UNION.value: 3,
        NodeType.RANK.value: 4,
        NodeType.SQL_TRANSFORM.value: 5,
        NodeType.STORED_PROCEDURE.value: 5,
        NodeType.UNKNOWN.value: 2,
    }

    def __init__(self, mapping_asts: Optional[Dict[str, MappingAST]] = None):
        """
        Initialize the analyzer.

        Args:
            mapping_asts: Pre-built MappingAST instances by mapping name
        """
        self._mapping_asts = mapping_asts or {}

    def set_mapping_ast(self, mapping_name: str, ast: MappingAST) -> None:
        """Set a MappingAST for a specific mapping."""
        self._mapping_asts[mapping_name.lower()] = ast

    def analyze(self, mapping_name: str) -> Optional[ChainAnalysisResult]:
        """
        Perform complete chain analysis on a mapping.

        Args:
            mapping_name: Name of the mapping to analyze

        Returns:
            ChainAnalysisResult or None if mapping not found
        """
        ast = self._mapping_asts.get(mapping_name.lower())
        if not ast:
            logger.warning(f"No AST found for mapping: {mapping_name}")
            return None

        logger.info(f"Analyzing transformation chains for: {mapping_name}")

        # Create advanced analyzer
        analyzer = AdvancedGraphAnalyzer(ast)

        # Find all chains
        chains = self._find_all_chains(ast)

        # Get critical paths
        critical_paths = analyzer.find_critical_paths(self.COMPLEXITY_WEIGHTS)

        # Find SCCs (cycles)
        sccs = analyzer.find_strongly_connected_components()
        cyclic_sccs = [scc for scc in sccs if scc.is_cycle]

        # Find parallel opportunities
        parallel_opportunities = self._find_parallel_opportunities(ast, analyzer)

        # Generate recommendations
        recommendations = self._generate_recommendations(
            ast, chains, critical_paths, cyclic_sccs, parallel_opportunities
        )

        # Calculate metrics
        metrics = analyzer.calculate_graph_metrics()
        metrics.update({
            "chain_count": len(chains),
            "cyclic_chain_count": sum(1 for c in chains if c.chain_type == ChainType.CYCLIC),
            "parallel_opportunity_count": len(parallel_opportunities),
            "recommendation_count": len(recommendations),
        })

        return ChainAnalysisResult(
            mapping_name=mapping_name,
            chains=chains,
            critical_paths=critical_paths,
            sccs=cyclic_sccs,
            parallel_opportunities=parallel_opportunities,
            recommendations=recommendations,
            metrics=metrics,
        )

    def _find_all_chains(self, ast: MappingAST) -> List[TransformationChain]:
        """Find all transformation chains in the mapping."""
        chains = []

        # Build adjacency for chain detection
        adj: Dict[str, List[str]] = {}
        reverse_adj: Dict[str, List[str]] = {}

        for node in ast.nodes:
            adj[node] = []
            reverse_adj[node] = []

        for edge in ast.edges:
            from_key = edge.from_instance.lower()
            to_key = edge.to_instance.lower()
            if from_key in adj and to_key in adj:
                if to_key not in adj[from_key]:
                    adj[from_key].append(to_key)
                if from_key not in reverse_adj[to_key]:
                    reverse_adj[to_key].append(from_key)

        # Find chains starting from each source
        visited_chains = set()

        for source_node in ast.source_nodes:
            source_key = source_node.name.lower()
            chain_paths = self._trace_chains_from(source_key, adj, ast)

            for path in chain_paths:
                chain_key = "->".join(path)
                if chain_key not in visited_chains:
                    visited_chains.add(chain_key)
                    chain = self._build_chain(path, ast, adj, reverse_adj)
                    chains.append(chain)

        return chains

    def _trace_chains_from(
        self,
        start: str,
        adj: Dict[str, List[str]],
        ast: MappingAST,
        max_depth: int = 50
    ) -> List[List[str]]:
        """Trace all chains from a starting node to targets."""
        paths = []
        target_names = {t.name.lower() for t in ast.target_nodes}

        def dfs(current: str, path: List[str], depth: int) -> None:
            if depth > max_depth:
                return

            if current in target_names:
                paths.append(list(path))
                return

            for successor in adj.get(current, []):
                if successor not in path:  # Avoid cycles in path
                    path.append(successor)
                    dfs(successor, path, depth + 1)
                    path.pop()

        dfs(start, [start], 0)
        return paths

    def _build_chain(
        self,
        path: List[str],
        ast: MappingAST,
        adj: Dict[str, List[str]],
        reverse_adj: Dict[str, List[str]]
    ) -> TransformationChain:
        """Build a TransformationChain from a path."""
        # Determine chain type
        chain_type = self._determine_chain_type(path, adj, reverse_adj)

        # Calculate complexity
        total_complexity = 0
        bottleneck_node = None
        bottleneck_type = None
        max_complexity = 0

        expressions_count = 0
        lookups_count = 0
        aggregators_count = 0

        for node_name in path:
            node = ast.get_node(node_name)
            if node:
                node_type = node.node_type.value
                complexity = self.COMPLEXITY_WEIGHTS.get(node_type, 2)
                total_complexity += complexity

                if complexity > max_complexity:
                    max_complexity = complexity
                    bottleneck_node = node_name
                    bottleneck_type = node_type

                # Count specific types
                if node.node_type == NodeType.EXPRESSION:
                    expressions_count += 1
                elif node.node_type == NodeType.LOOKUP:
                    lookups_count += 1
                elif node.node_type == NodeType.AGGREGATOR:
                    aggregators_count += 1

        return TransformationChain(
            nodes=path,
            chain_type=chain_type,
            source_node=path[0] if path else "",
            target_node=path[-1] if path else "",
            length=len(path),
            total_complexity=total_complexity,
            bottleneck_node=bottleneck_node,
            bottleneck_type=bottleneck_type,
            expressions_count=expressions_count,
            lookups_count=lookups_count,
            aggregators_count=aggregators_count,
        )

    def _determine_chain_type(
        self,
        path: List[str],
        adj: Dict[str, List[str]],
        reverse_adj: Dict[str, List[str]]
    ) -> ChainType:
        """Determine the type of a chain."""
        # Check for cycles
        path_set = set(path)
        for node in path:
            for successor in adj.get(node, []):
                if successor in path_set and path.index(successor) < path.index(node):
                    return ChainType.CYCLIC

        # Check for branching (multiple outputs from a node)
        has_branching = False
        for node in path[:-1]:  # Exclude last node
            if len(adj.get(node, [])) > 1:
                has_branching = True
                break

        # Check for merging (multiple inputs to a node)
        has_merging = False
        for node in path[1:]:  # Exclude first node
            if len(reverse_adj.get(node, [])) > 1:
                has_merging = True
                break

        if has_branching and has_merging:
            return ChainType.PARALLEL
        elif has_branching:
            return ChainType.BRANCHING
        elif has_merging:
            return ChainType.MERGING
        else:
            return ChainType.LINEAR

    def _find_parallel_opportunities(
        self,
        ast: MappingAST,
        analyzer: AdvancedGraphAnalyzer
    ) -> List[ParallelExecutionOpportunity]:
        """Find opportunities for parallel execution."""
        opportunities = []

        # Find nodes with multiple outgoing edges (branching points)
        for node_name, node in ast.nodes.items():
            downstream = node.get_downstream_nodes()
            if len(downstream) > 1:
                # This is a branching point
                parallel_groups = []
                for downstream_node in downstream:
                    # Get the chain from this node to its merge point or target
                    chain = self._get_independent_chain(downstream_node.name.lower(), ast, analyzer)
                    if chain:
                        parallel_groups.append(chain)

                if len(parallel_groups) > 1:
                    # Find sync point (where branches merge)
                    sync_point = self._find_sync_point(parallel_groups, ast, analyzer)

                    # Calculate potential speedup
                    max_length = max(len(g) for g in parallel_groups)
                    total_length = sum(len(g) for g in parallel_groups)
                    speedup = total_length / max_length if max_length > 0 else 1.0

                    opportunities.append(ParallelExecutionOpportunity(
                        parallel_groups=parallel_groups,
                        sync_point=sync_point,
                        potential_speedup=speedup,
                    ))

        return opportunities

    def _get_independent_chain(
        self,
        start: str,
        ast: MappingAST,
        analyzer: AdvancedGraphAnalyzer
    ) -> List[str]:
        """Get the chain of nodes that are independent (single predecessor)."""
        chain = [start]
        current = start

        while True:
            node = ast.get_node(current)
            if not node:
                break

            downstream = node.get_downstream_nodes()
            if len(downstream) != 1:
                break

            next_node = downstream[0]
            # Check if this node has multiple predecessors (merge point)
            if len(next_node.get_upstream_nodes()) > 1:
                break

            chain.append(next_node.name.lower())
            current = next_node.name.lower()

            if len(chain) > 50:  # Safety limit
                break

        return chain

    def _find_sync_point(
        self,
        parallel_groups: List[List[str]],
        ast: MappingAST,
        analyzer: AdvancedGraphAnalyzer
    ) -> str:
        """Find where parallel branches merge."""
        # Get all reachable nodes from each branch
        reachable_sets = []
        for group in parallel_groups:
            if group:
                last_node = group[-1]
                reachable = analyzer._get_transitive_closure(last_node, reverse=False)
                reachable_sets.append(reachable)

        if not reachable_sets:
            return ""

        # Find common reachable nodes
        common = reachable_sets[0].copy()
        for reachable in reachable_sets[1:]:
            common &= reachable

        if not common:
            return ""

        # Return the first common node (closest sync point)
        # We'd ideally want the one with minimum distance
        return min(common) if common else ""

    def _generate_recommendations(
        self,
        ast: MappingAST,
        chains: List[TransformationChain],
        critical_paths: List[CriticalPath],
        cyclic_sccs: List[StronglyConnectedComponent],
        parallel_opportunities: List[ParallelExecutionOpportunity]
    ) -> List[OptimizationRecommendation]:
        """Generate optimization recommendations."""
        recommendations = []

        # Recommendation: Break cycles
        for scc in cyclic_sccs:
            recommendations.append(OptimizationRecommendation(
                optimization_type=OptimizationType.BREAK_CYCLE,
                description=f"Circular dependency detected with {len(scc.nodes)} nodes",
                affected_nodes=scc.nodes,
                estimated_impact="high",
                details={
                    "entry_points": scc.entry_points,
                    "exit_points": scc.exit_points,
                },
            ))

        # Recommendation: Combine consecutive expressions
        consecutive_expr_chains = self._find_consecutive_type_chains(
            ast, NodeType.EXPRESSION, min_length=3
        )
        for chain in consecutive_expr_chains:
            recommendations.append(OptimizationRecommendation(
                optimization_type=OptimizationType.COMBINE_EXPRESSIONS,
                description=f"Consider combining {len(chain)} consecutive expression transformations",
                affected_nodes=chain,
                estimated_impact="medium",
            ))

        # Recommendation: Add early filters
        for chain in chains:
            if chain.lookups_count > 0 or chain.aggregators_count > 0:
                # Check if there's a filter late in the chain
                filter_positions = []
                for i, node_name in enumerate(chain.nodes):
                    node = ast.get_node(node_name)
                    if node and node.node_type == NodeType.FILTER:
                        filter_positions.append(i)

                if filter_positions and filter_positions[0] > len(chain.nodes) // 2:
                    recommendations.append(OptimizationRecommendation(
                        optimization_type=OptimizationType.ADD_FILTER_EARLY,
                        description="Consider moving filter transformation earlier in the chain",
                        affected_nodes=[chain.nodes[filter_positions[0]]],
                        estimated_impact="high",
                        details={
                            "current_position": filter_positions[0],
                            "chain_length": len(chain.nodes),
                        },
                    ))

        # Recommendation: Parallelize
        for opportunity in parallel_opportunities:
            if opportunity.potential_speedup > 1.5:
                recommendations.append(OptimizationRecommendation(
                    optimization_type=OptimizationType.PARALLELIZE,
                    description=f"Potential {opportunity.potential_speedup:.1f}x speedup through parallelization",
                    affected_nodes=[g[0] for g in opportunity.parallel_groups if g],
                    estimated_impact="high" if opportunity.potential_speedup > 2 else "medium",
                    details={
                        "parallel_groups": opportunity.parallel_groups,
                        "sync_point": opportunity.sync_point,
                    },
                ))

        # Recommendation: Reduce lookups
        lookup_heavy_chains = [c for c in chains if c.lookups_count >= 3]
        for chain in lookup_heavy_chains:
            recommendations.append(OptimizationRecommendation(
                optimization_type=OptimizationType.REDUCE_LOOKUPS,
                description=f"Chain has {chain.lookups_count} lookup transformations - consider combining or caching",
                affected_nodes=chain.nodes,
                estimated_impact="high",
                details={"lookup_count": chain.lookups_count},
            ))

        # Recommendation: Split long chains
        long_chains = [c for c in chains if c.length > 15]
        for chain in long_chains:
            recommendations.append(OptimizationRecommendation(
                optimization_type=OptimizationType.SPLIT_CHAIN,
                description=f"Long chain with {chain.length} transformations - consider splitting into sub-mappings",
                affected_nodes=chain.nodes,
                estimated_impact="medium",
                details={"chain_length": chain.length},
            ))

        return recommendations

    def _find_consecutive_type_chains(
        self,
        ast: MappingAST,
        node_type: NodeType,
        min_length: int = 2
    ) -> List[List[str]]:
        """Find chains of consecutive transformations of the same type."""
        chains = []
        visited = set()

        for node_name, node in ast.nodes.items():
            if node.node_type != node_type or node_name in visited:
                continue

            chain = [node_name]
            visited.add(node_name)
            current = node

            # Follow downstream
            while True:
                downstream = current.get_downstream_nodes()
                next_node = None
                for d in downstream:
                    if d.node_type == node_type and d.name.lower() not in visited:
                        next_node = d
                        break

                if not next_node:
                    break

                chain.append(next_node.name.lower())
                visited.add(next_node.name.lower())
                current = next_node

            if len(chain) >= min_length:
                chains.append(chain)

        return chains

    def get_chain_summary(self, mapping_name: str) -> Optional[Dict[str, Any]]:
        """Get a summary of chain analysis for a mapping."""
        result = self.analyze(mapping_name)
        if not result:
            return None

        return {
            "mapping_name": mapping_name,
            "total_chains": len(result.chains),
            "critical_path_length": result.critical_paths[0].total_complexity if result.critical_paths else 0,
            "has_cycles": any(s.is_cycle for s in result.sccs),
            "cycle_count": sum(1 for s in result.sccs if s.is_cycle),
            "parallel_opportunities": len(result.parallel_opportunities),
            "recommendations": len(result.recommendations),
            "high_impact_recommendations": sum(
                1 for r in result.recommendations if r.estimated_impact == "high"
            ),
        }
