"""Expert result models."""

from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict, List, Optional
from datetime import datetime


class ExpertStatus(Enum):
    """Status of expert analysis."""

    PENDING = "pending"
    IN_PROGRESS = "in_progress"
    COMPLETED = "completed"
    FAILED = "failed"
    NEEDS_REFINEMENT = "needs_refinement"


@dataclass
class ExpertResult:
    """Result from an expert analysis."""

    expert_name: str
    status: ExpertStatus
    confidence: float = 1.0  # 0.0 to 1.0
    data: Dict[str, Any] = field(default_factory=dict)
    errors: List[str] = field(default_factory=list)
    warnings: List[str] = field(default_factory=list)
    timestamp: str = field(default_factory=lambda: datetime.now().isoformat())
    processing_time_ms: float = 0.0

    @property
    def is_successful(self) -> bool:
        """Check if analysis was successful."""
        return self.status == ExpertStatus.COMPLETED and not self.errors

    def to_dict(self) -> Dict[str, Any]:
        return {
            "expert_name": self.expert_name,
            "status": self.status.value,
            "confidence": self.confidence,
            "is_successful": self.is_successful,
            "data": self.data,
            "errors": self.errors,
            "warnings": self.warnings,
            "timestamp": self.timestamp,
            "processing_time_ms": self.processing_time_ms,
        }


@dataclass
class ConflictResolution:
    """Resolution of conflicts between expert results."""

    conflict_type: str
    experts_involved: List[str]
    resolution_strategy: str
    resolved_value: Any
    confidence: float = 1.0

    def to_dict(self) -> Dict[str, Any]:
        return {
            "conflict_type": self.conflict_type,
            "experts_involved": self.experts_involved,
            "resolution_strategy": self.resolution_strategy,
            "resolved_value": str(self.resolved_value),
            "confidence": self.confidence,
        }
