"""
Dependency Graph Expert for Informatica Mappings.

Provides comprehensive dependency analysis including:
- Circular dependency detection and analysis
- Transformation dependency graphs
- Impact analysis
- Dependency metrics
"""

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Set

from .base_expert import BaseExpert, ExpertType, ExpertContext
from .models.expert_result import ExpertResult, ExpertStatus
from .transformation_chain_analyzer import (
    TransformationChainAnalyzer,
    ChainAnalysisResult,
)
from ..models.mapping_models import Mapping
from ..utils.mapping_ast import (
    MappingAST,
    AdvancedGraphAnalyzer,
    StronglyConnectedComponent,
    CriticalPath,
    DependencyInfo,
)
from ..utils.xml_utils_xdm import XDMXMLParser


@dataclass
class CircularDependency:
    """Represents a detected circular dependency."""
    cycle_nodes: List[str]
    cycle_length: int
    entry_point: str
    exit_point: str
    severity: str  # "error", "warning"
    affected_transformations: List[str]
    recommendation: str

    def to_dict(self) -> Dict[str, Any]:
        return {
            "cycle_nodes": self.cycle_nodes,
            "cycle_length": self.cycle_length,
            "entry_point": self.entry_point,
            "exit_point": self.exit_point,
            "severity": self.severity,
            "affected_transformations": self.affected_transformations,
            "recommendation": self.recommendation,
        }


@dataclass
class ImpactAnalysis:
    """Impact analysis for a transformation."""
    transformation_name: str
    direct_impact: List[str]
    transitive_impact: List[str]
    impact_score: float
    is_bottleneck: bool
    risk_level: str  # "high", "medium", "low"

    def to_dict(self) -> Dict[str, Any]:
        return {
            "transformation_name": self.transformation_name,
            "direct_impact": self.direct_impact,
            "direct_impact_count": len(self.direct_impact),
            "transitive_impact": self.transitive_impact,
            "transitive_impact_count": len(self.transitive_impact),
            "impact_score": self.impact_score,
            "is_bottleneck": self.is_bottleneck,
            "risk_level": self.risk_level,
        }


@dataclass
class MappingDependencyGraph:
    """Complete dependency graph for a mapping."""
    mapping_name: str
    nodes: List[str]
    edges: List[Dict[str, str]]
    circular_dependencies: List[CircularDependency]
    critical_paths: List[CriticalPath]
    impact_analyses: List[ImpactAnalysis]
    metrics: Dict[str, Any]

    def to_dict(self) -> Dict[str, Any]:
        return {
            "mapping_name": self.mapping_name,
            "node_count": len(self.nodes),
            "edge_count": len(self.edges),
            "nodes": self.nodes,
            "edges": self.edges,
            "circular_dependencies": [c.to_dict() for c in self.circular_dependencies],
            "critical_paths": [p.to_dict() for p in self.critical_paths],
            "impact_analyses": [i.to_dict() for i in self.impact_analyses],
            "metrics": self.metrics,
        }


class DependencyGraphExpert(BaseExpert):
    """
    Expert for analyzing transformation dependencies in Informatica mappings.

    Capabilities:
    - Detect and analyze circular dependencies using Tarjan's and Johnson's algorithms
    - Build complete dependency graphs
    - Perform impact analysis for each transformation
    - Calculate dependency metrics
    - Integrate with TransformationChainAnalyzer for comprehensive analysis
    """

    def __init__(
        self,
        xdm_parser: Optional[XDMXMLParser] = None,
        mapping_asts: Optional[Dict[str, MappingAST]] = None,
    ):
        """
        Initialize the Dependency Graph Expert.

        Args:
            xdm_parser: Optional XDM parser for XPath queries
            mapping_asts: Pre-built MappingAST instances
        """
        super().__init__("DependencyGraphExpert", ExpertType.INTEGRATION)
        self.xdm_parser = xdm_parser
        self._mapping_asts = mapping_asts or {}
        self._chain_analyzer = TransformationChainAnalyzer(mapping_asts)

    def set_mapping_ast(self, mapping_name: str, ast: MappingAST) -> None:
        """Set a MappingAST for a specific mapping."""
        self._mapping_asts[mapping_name.lower()] = ast
        self._chain_analyzer.set_mapping_ast(mapping_name, ast)

    def analyze(self, context: ExpertContext) -> ExpertResult:
        """Analyze dependencies for all mappings in the document."""
        self.logger.info("Starting dependency graph analysis")

        doc = context.document
        results = {
            "dependency_graphs": {},
            "chain_analyses": {},
            "circular_dependencies_summary": [],
            "statistics": {},
        }
        warnings = []

        total_mappings = 0
        total_cycles = 0
        total_critical_paths = 0
        total_high_impact = 0

        for mapping in doc.mappings:
            self.logger.debug(f"Analyzing dependencies for: {mapping.name}")

            # Get or build AST
            ast = self._get_or_build_ast(mapping)
            if not ast:
                warnings.append(f"Could not build AST for mapping {mapping.name}")
                continue

            # Build dependency graph
            dep_graph = self._build_dependency_graph(mapping, ast)
            results["dependency_graphs"][mapping.name] = dep_graph.to_dict()

            # Run chain analysis
            chain_result = self._chain_analyzer.analyze(mapping.name)
            if chain_result:
                results["chain_analyses"][mapping.name] = chain_result.to_dict()

            # Track statistics
            total_mappings += 1
            total_cycles += len(dep_graph.circular_dependencies)
            total_critical_paths += len(dep_graph.critical_paths)
            total_high_impact += sum(
                1 for i in dep_graph.impact_analyses if i.risk_level == "high"
            )

            # Add circular dependencies to summary
            for cd in dep_graph.circular_dependencies:
                results["circular_dependencies_summary"].append({
                    "mapping": mapping.name,
                    **cd.to_dict()
                })

            if dep_graph.circular_dependencies:
                warnings.append(
                    f"Mapping {mapping.name} has {len(dep_graph.circular_dependencies)} circular dependencies"
                )

        results["statistics"] = {
            "total_mappings_analyzed": total_mappings,
            "total_circular_dependencies": total_cycles,
            "total_critical_paths": total_critical_paths,
            "total_high_impact_transformations": total_high_impact,
            "mappings_with_cycles": sum(
                1 for m in results["dependency_graphs"].values()
                if m.get("circular_dependencies")
            ),
        }

        # Calculate confidence
        confidence = self._calculate_confidence(results)

        self.logger.info(f"Dependency analysis complete: {results['statistics']}")

        return self._create_result(
            status=ExpertStatus.COMPLETED,
            data=results,
            warnings=warnings,
            confidence=confidence,
        )

    def _get_or_build_ast(self, mapping: Mapping) -> Optional[MappingAST]:
        """Get existing AST or return None."""
        return self._mapping_asts.get(mapping.name.lower())

    def _build_dependency_graph(
        self,
        mapping: Mapping,
        ast: MappingAST
    ) -> MappingDependencyGraph:
        """Build complete dependency graph for a mapping."""
        # Create advanced analyzer
        analyzer = AdvancedGraphAnalyzer(ast)

        # Get nodes and edges
        nodes = list(ast.nodes.keys())
        edges = [
            {"from": e.from_instance, "to": e.to_instance}
            for e in ast.edges
        ]

        # Find circular dependencies
        circular_deps = self._find_circular_dependencies(ast, analyzer)

        # Find critical paths
        critical_paths = analyzer.find_critical_paths()

        # Perform impact analysis
        impact_analyses = self._perform_impact_analysis(ast, analyzer, critical_paths)

        # Calculate metrics
        metrics = analyzer.calculate_graph_metrics()
        metrics.update({
            "circular_dependency_count": len(circular_deps),
            "critical_path_count": len(critical_paths),
            "bottleneck_count": sum(1 for i in impact_analyses if i.is_bottleneck),
        })

        return MappingDependencyGraph(
            mapping_name=mapping.name,
            nodes=nodes,
            edges=edges,
            circular_dependencies=circular_deps,
            critical_paths=critical_paths,
            impact_analyses=impact_analyses,
            metrics=metrics,
        )

    def _find_circular_dependencies(
        self,
        ast: MappingAST,
        analyzer: AdvancedGraphAnalyzer
    ) -> List[CircularDependency]:
        """Find and analyze circular dependencies."""
        circular_deps = []

        # Get SCCs with cycles
        sccs = analyzer.find_strongly_connected_components()
        cyclic_sccs = [scc for scc in sccs if scc.is_cycle]

        for scc in cyclic_sccs:
            # Determine severity based on cycle characteristics
            severity = "error" if len(scc.nodes) > 2 else "warning"

            # Find affected transformations (nodes in and around the cycle)
            affected = list(scc.nodes)
            for node in scc.entry_points:
                dep_info = analyzer.get_dependency_info(node)
                affected.extend(dep_info.direct_dependencies)
            for node in scc.exit_points:
                dep_info = analyzer.get_dependency_info(node)
                affected.extend(dep_info.direct_dependents)
            affected = list(set(affected))

            # Generate recommendation
            recommendation = self._generate_cycle_recommendation(scc, ast)

            circular_deps.append(CircularDependency(
                cycle_nodes=scc.nodes,
                cycle_length=len(scc.nodes),
                entry_point=scc.entry_points[0] if scc.entry_points else scc.nodes[0],
                exit_point=scc.exit_points[0] if scc.exit_points else scc.nodes[-1],
                severity=severity,
                affected_transformations=affected,
                recommendation=recommendation,
            ))

        return circular_deps

    def _generate_cycle_recommendation(
        self,
        scc: StronglyConnectedComponent,
        ast: MappingAST
    ) -> str:
        """Generate a recommendation for breaking a cycle."""
        if len(scc.nodes) == 1:
            return f"Remove self-referencing edge in transformation '{scc.nodes[0]}'"

        if len(scc.nodes) == 2:
            return f"Break bidirectional dependency between '{scc.nodes[0]}' and '{scc.nodes[1]}'"

        # For larger cycles, suggest removing the edge to the entry point
        if scc.entry_points:
            return f"Consider removing or restructuring the edge leading into '{scc.entry_points[0]}'"

        return "Restructure the transformations to eliminate the circular dependency"

    def _perform_impact_analysis(
        self,
        ast: MappingAST,
        analyzer: AdvancedGraphAnalyzer,
        critical_paths: List[CriticalPath]
    ) -> List[ImpactAnalysis]:
        """Perform impact analysis for transformations."""
        impact_analyses = []

        # Get nodes on critical paths
        critical_path_nodes = set()
        for path in critical_paths:
            critical_path_nodes.update(path.nodes)

        # Get bottleneck nodes
        bottleneck_nodes = {p.bottleneck_node for p in critical_paths if p.bottleneck_node}

        for node_name in ast.nodes:
            dep_info = analyzer.get_dependency_info(node_name)

            # Calculate impact score
            direct_impact_count = len(dep_info.direct_dependents)
            transitive_impact_count = len(dep_info.transitive_dependents)

            # Impact score: weighted sum of direct and transitive impact
            impact_score = direct_impact_count * 2 + transitive_impact_count * 0.5

            # Determine if bottleneck
            is_bottleneck = node_name in bottleneck_nodes

            # Determine risk level
            if is_bottleneck or transitive_impact_count > 10:
                risk_level = "high"
            elif transitive_impact_count > 5 or direct_impact_count > 3:
                risk_level = "medium"
            else:
                risk_level = "low"

            impact_analyses.append(ImpactAnalysis(
                transformation_name=node_name,
                direct_impact=dep_info.direct_dependents,
                transitive_impact=dep_info.transitive_dependents,
                impact_score=impact_score,
                is_bottleneck=is_bottleneck,
                risk_level=risk_level,
            ))

        # Sort by impact score
        impact_analyses.sort(key=lambda i: i.impact_score, reverse=True)

        return impact_analyses

    def _calculate_confidence(self, results: Dict[str, Any]) -> float:
        """Calculate confidence score for the analysis."""
        confidence = 0.95

        # Reduce confidence for mappings with many cycles
        cycle_count = results["statistics"].get("total_circular_dependencies", 0)
        if cycle_count > 0:
            confidence -= min(0.1, cycle_count * 0.02)

        # Reduce confidence for high number of high-impact transformations
        high_impact = results["statistics"].get("total_high_impact_transformations", 0)
        if high_impact > 10:
            confidence -= 0.05

        return max(0.7, confidence)

    def analyze_single_mapping(self, mapping_name: str) -> Optional[MappingDependencyGraph]:
        """
        Analyze dependencies for a single mapping.

        Args:
            mapping_name: Name of the mapping to analyze

        Returns:
            MappingDependencyGraph or None if mapping not found
        """
        ast = self._mapping_asts.get(mapping_name.lower())
        if not ast:
            self.logger.warning(f"No AST found for mapping: {mapping_name}")
            return None

        # Create a minimal Mapping object for the method
        class MinimalMapping:
            def __init__(self, name):
                self.name = name

        mapping = MinimalMapping(mapping_name)
        return self._build_dependency_graph(mapping, ast)

    def get_transformation_impact(
        self,
        mapping_name: str,
        transformation_name: str
    ) -> Optional[ImpactAnalysis]:
        """
        Get impact analysis for a specific transformation.

        Args:
            mapping_name: Name of the mapping
            transformation_name: Name of the transformation

        Returns:
            ImpactAnalysis or None
        """
        dep_graph = self.analyze_single_mapping(mapping_name)
        if not dep_graph:
            return None

        for impact in dep_graph.impact_analyses:
            if impact.transformation_name.lower() == transformation_name.lower():
                return impact

        return None

    def get_circular_dependencies(
        self,
        mapping_name: Optional[str] = None
    ) -> List[CircularDependency]:
        """
        Get all circular dependencies, optionally filtered by mapping.

        Args:
            mapping_name: Optional mapping name to filter

        Returns:
            List of CircularDependency
        """
        all_deps = []

        mappings_to_check = (
            [mapping_name] if mapping_name
            else list(self._mapping_asts.keys())
        )

        for m_name in mappings_to_check:
            ast = self._mapping_asts.get(m_name.lower())
            if ast:
                analyzer = AdvancedGraphAnalyzer(ast)
                deps = self._find_circular_dependencies(ast, analyzer)
                all_deps.extend(deps)

        return all_deps
