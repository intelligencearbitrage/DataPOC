"""Operator Logic Expert - Analyzes filters, joins, aggregators, routers, etc."""

from typing import Any, Dict, List, Optional

from .base_expert import BaseExpert, ExpertType, ExpertContext
from .models.expert_result import ExpertResult, ExpertStatus
from ..models.transformation_models import TransformationType
from ..parsers.expression_parser import ExpressionParser


class OperatorLogicExpert(BaseExpert):
    """
    Expert for analyzing operator-level logic in Informatica transformations.

    Responsibilities:
    - Analyze Filter conditions
    - Parse Aggregator grouping and sorting
    - Extract Router conditions
    - Parse Joiner conditions
    - Analyze Normalizer structures
    - Extract Update Strategy logic
    """

    def __init__(self):
        super().__init__("OperatorLogicExpert", ExpertType.OPERATOR_LOGIC)
        self.expression_parser = ExpressionParser()

    def analyze(self, context: ExpertContext) -> ExpertResult:
        """Analyze operator-level logic."""
        self.logger.info("Starting operator logic analysis")

        doc = context.document
        results = {
            "filters": [],
            "aggregators": [],
            "lookups": [],
            "joiners": [],
            "routers": [],
            "normalizers": [],
            "update_strategies": [],
            "sorters": [],
            "sql_transforms": [],
            "stored_procedures": [],
            "source_filters": [],
            "statistics": {},
        }
        warnings = []

        for mapping in doc.mappings:
            for trans in mapping.transformations:
                trans_type = TransformationType.from_string(trans.type)

                if trans_type == TransformationType.FILTER:
                    filter_info = self._analyze_filter(mapping.name, trans)
                    results["filters"].append(filter_info)

                elif trans_type == TransformationType.AGGREGATOR:
                    agg_info = self._analyze_aggregator(mapping.name, trans)
                    results["aggregators"].append(agg_info)

                elif trans_type == TransformationType.LOOKUP_PROCEDURE:
                    lookup_info = self._analyze_lookup(mapping.name, trans)
                    results["lookups"].append(lookup_info)

                elif trans_type == TransformationType.JOINER:
                    joiner_info = self._analyze_joiner(mapping.name, trans)
                    results["joiners"].append(joiner_info)

                elif trans_type == TransformationType.ROUTER:
                    router_info = self._analyze_router(mapping.name, trans)
                    results["routers"].append(router_info)

                elif trans_type == TransformationType.NORMALIZER:
                    norm_info = self._analyze_normalizer(mapping.name, trans)
                    results["normalizers"].append(norm_info)

                elif trans_type == TransformationType.UPDATE_STRATEGY:
                    upd_info = self._analyze_update_strategy(mapping.name, trans)
                    results["update_strategies"].append(upd_info)

                elif trans_type == TransformationType.SORTER:
                    sort_info = self._analyze_sorter(mapping.name, trans)
                    results["sorters"].append(sort_info)

                elif trans_type == TransformationType.SQL:
                    sql_info = self._analyze_sql_transform(mapping.name, trans)
                    results["sql_transforms"].append(sql_info)
                elif trans_type == TransformationType.STORED_PROCEDURE:
                    sp_info = self._analyze_stored_procedure(mapping.name, trans)
                    results["stored_procedures"].append(sp_info)

                # Collect Source Filters from Source Qualifier transformations
                if trans_type == TransformationType.SOURCE_QUALIFIER:
                    source_filter = trans.get_attribute("Source Filter")
                    if source_filter:
                        results["source_filters"].append({
                            "mapping": mapping.name,
                            "transformation": trans.name,
                            "source_filter": source_filter,
                        })

        # Also analyze reusable (folder-level) transformations not inside any mapping
        # This captures reusable Stored Procedures, etc.
        mapping_trans_names = set()
        for mapping in doc.mappings:
            for trans in mapping.transformations:
                mapping_trans_names.add(trans.name)

        for trans in getattr(doc, 'transformations', []):
            if trans.name in mapping_trans_names:
                continue  # Already analyzed inside a mapping
            trans_type = TransformationType.from_string(trans.type)
            if trans_type == TransformationType.STORED_PROCEDURE:
                sp_info = self._analyze_stored_procedure("(Reusable)", trans)
                results["stored_procedures"].append(sp_info)

        # Calculate statistics
        results["statistics"] = {
            "stored_procedure_count": len(results["stored_procedures"]),
            "source_filter_count": len(results["source_filters"]),
            "filter_count": len(results["filters"]),
            "aggregator_count": len(results["aggregators"]),
            "lookup_count": len(results["lookups"]),
            "joiner_count": len(results["joiners"]),
            "router_count": len(results["routers"]),
            "normalizer_count": len(results["normalizers"]),
            "update_strategy_count": len(results["update_strategies"]),
            "sorter_count": len(results["sorters"]),
            "sql_transform_count": len(results["sql_transforms"]),
        }

        self.logger.info(f"Operator logic analysis complete: {results['statistics']}")

        return self._create_result(
            status=ExpertStatus.COMPLETED,
            data=results,
            warnings=warnings,
            confidence=0.95,
        )

    def _analyze_filter(self, mapping_name: str, trans) -> Dict[str, Any]:
        """Analyze a Filter transformation."""
        condition = trans.filter_condition or ""
        parsed = self.expression_parser.parse(condition)

        return {
            "mapping": mapping_name,
            "name": trans.name,
            "condition": condition,
            "condition_explanation": parsed.explanation,
            "referenced_fields": parsed.referenced_fields,
            "input_fields": [f.name for f in trans.input_fields],
            "output_fields": [f.name for f in trans.output_fields],
        }

    def _analyze_aggregator(self, mapping_name: str, trans) -> Dict[str, Any]:
        """Analyze an Aggregator transformation."""
        group_by_fields = []
        aggregate_fields = []

        for field in trans.fields:
            if field.expression_type and field.expression_type.upper() == "GROUPBY":
                group_by_fields.append({
                    "name": field.name,
                    "expression": field.expression,
                })
            elif field.has_expression:
                parsed = self.expression_parser.parse(field.expression)
                aggregate_fields.append({
                    "name": field.name,
                    "expression": field.expression,
                    "explanation": parsed.explanation,
                    "functions": parsed.functions_used,
                })

        # Get sorted ports count
        sorted_ports = trans.get_attribute("Number Of Sorted Ports")

        return {
            "mapping": mapping_name,
            "name": trans.name,
            "group_by_fields": group_by_fields,
            "aggregate_fields": aggregate_fields,
            "sorted_ports": int(sorted_ports) if sorted_ports else 0,
        }

    def _analyze_lookup(self, mapping_name: str, trans) -> Dict[str, Any]:
        """Analyze a Lookup transformation."""
        condition = trans.lookup_condition or ""
        sql_override = trans.lookup_sql_override
        table_name = trans.get_attribute("Lookup table name") or ""
        caching = trans.get_attribute("Lookup caching enabled") or "YES"
        multiple_match = trans.get_attribute("Lookup policy on multiple match") or "Use First Value"

        lookup_ports = []
        return_ports = []

        for field in trans.fields:
            if "lookup" in field.port_type.lower():
                if "return" in field.port_type.lower() or "output" in field.port_type.lower():
                    return_ports.append(field.name)
                else:
                    lookup_ports.append(field.name)

        return {
            "mapping": mapping_name,
            "name": trans.name,
            "table_name": table_name,
            "condition": condition,
            "sql_override": sql_override,
            "caching_enabled": caching.upper() == "YES",
            "multiple_match_policy": multiple_match,
            "lookup_ports": lookup_ports,
            "return_ports": return_ports,
        }

    def _analyze_joiner(self, mapping_name: str, trans) -> Dict[str, Any]:
        """Analyze a Joiner transformation."""
        join_condition = trans.get_attribute("Join Condition") or ""
        join_type = trans.get_attribute("Join Type") or "Normal"

        master_ports = []
        detail_ports = []

        for field in trans.fields:
            # Determine if master or detail based on naming convention
            if "_M" in field.name or "MASTER" in field.name.upper():
                master_ports.append(field.name)
            else:
                detail_ports.append(field.name)

        return {
            "mapping": mapping_name,
            "name": trans.name,
            "join_type": join_type,
            "join_condition": join_condition,
            "sorted_input": trans.get_attribute("Sorted Input") or "NO",
            "master_ports": master_ports,
            "detail_ports": detail_ports,
        }

    def _analyze_stored_procedure(self, mapping_name: str, trans) -> Dict[str, Any]:
        """Analyze a Stored Procedure transformation."""
        return {
            "mapping": mapping_name,
            "name": trans.name,
            "procedure_name": trans.get_attribute("Stored Procedure Name") or "",
            "procedure_type": trans.get_attribute("Stored Procedure Type") or "",
            "connection_info": trans.get_attribute("Connection Information") or "",
            "call_text": trans.get_attribute("Call Text") or "",
            "execution_order": trans.get_attribute("Execution Order") or "",
            "input_fields": [f.name for f in trans.input_fields],
            "output_fields": [f.name for f in trans.output_fields],
        }

    def _analyze_router(self, mapping_name: str, trans) -> Dict[str, Any]:
        """Analyze a Router transformation."""
        groups = []
        output_groups = []

        # Prefer parsed GROUP elements (trans.groups) over TABLEATTRIBUTE fallback
        if trans.groups:
            for rg in trans.router_groups:
                condition = rg.expression
                parsed = self.expression_parser.parse(condition) if condition else None
                group_info = {
                    "name": rg.name,
                    "condition": condition,
                    "explanation": parsed.explanation if parsed else ("Default group - receives unmatched rows" if rg.is_default else ""),
                    "is_default": rg.is_default,
                }
                groups.append({
                    "name": rg.name,
                    "condition": condition,
                    "explanation": group_info["explanation"],
                })
                output_groups.append(group_info)
        else:
            # Fallback: Router groups from table attributes
            for attr in trans.attributes:
                if attr.name.startswith("Group ") or attr.name.startswith("Router Group "):
                    parsed = self.expression_parser.parse(attr.value)
                    group_info = {
                        "name": attr.name,
                        "condition": attr.value,
                        "explanation": parsed.explanation,
                        "is_default": False,
                    }
                    groups.append({
                        "name": attr.name,
                        "condition": attr.value,
                        "explanation": parsed.explanation,
                    })
                    output_groups.append(group_info)

        return {
            "mapping": mapping_name,
            "name": trans.name,
            "groups": groups,
            "output_groups": output_groups,
            "input_fields": [f.name for f in trans.input_fields],
        }

    def _analyze_normalizer(self, mapping_name: str, trans) -> Dict[str, Any]:
        """Analyze a Normalizer transformation."""
        occurs_fields = []
        regular_fields = []

        for field in trans.fields:
            if field.ref_source_field:
                # Field references a source field (OCCURS structure)
                occurs_fields.append({
                    "name": field.name,
                    "ref_field": field.ref_source_field,
                })
            else:
                regular_fields.append(field.name)

        return {
            "mapping": mapping_name,
            "name": trans.name,
            "occurs_fields": occurs_fields,
            "regular_fields": regular_fields,
        }

    def _analyze_update_strategy(self, mapping_name: str, trans) -> Dict[str, Any]:
        """Analyze an Update Strategy transformation."""
        expression = trans.update_strategy_expression or ""
        parsed = self.expression_parser.parse(expression)

        forward_rejected = trans.get_attribute("Forward Rejected Rows") or "YES"

        return {
            "mapping": mapping_name,
            "name": trans.name,
            "expression": expression,
            "explanation": parsed.explanation,
            "forward_rejected": forward_rejected.upper() == "YES",
        }

    def _analyze_sorter(self, mapping_name: str, trans) -> Dict[str, Any]:
        """Analyze a Sorter transformation."""
        sort_keys = []
        distinct = trans.get_attribute("Distinct") or "NO"

        for field in trans.fields:
            # Check if field is a sort key
            sort_direction = field.expression_type
            if sort_direction:
                sort_keys.append({
                    "name": field.name,
                    "direction": sort_direction,
                })

        return {
            "mapping": mapping_name,
            "name": trans.name,
            "sort_keys": sort_keys,
            "distinct": distinct.upper() == "YES",
        }

    def _analyze_sql_transform(self, mapping_name: str, trans) -> Dict[str, Any]:
        """Analyze a SQL transformation."""
        sql_query = trans.get_attribute("Sql Query") or trans.sql_query or ""
        auto_commit = trans.get_attribute("Auto_Commit") or "FALSE"

        return {
            "mapping": mapping_name,
            "name": trans.name,
            "sql_query": sql_query,
            "auto_commit": auto_commit.upper() == "TRUE",
        }
