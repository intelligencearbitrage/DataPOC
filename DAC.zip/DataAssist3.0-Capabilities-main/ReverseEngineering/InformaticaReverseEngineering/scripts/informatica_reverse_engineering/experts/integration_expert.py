"""Integration Expert - Orchestrates all experts and builds end-to-end lineage."""

from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import Any, Dict, List, Optional, Union
import re
import time

from .base_expert import BaseExpert, ExpertType, ExpertContext
from .models.expert_result import ExpertResult, ExpertStatus, ConflictResolution
from .mapping_structure_expert import MappingStructureExpert
from .field_mapping_expert import FieldMappingExpert
from .operator_logic_expert import OperatorLogicExpert
from ..models.lineage_models import EndToEndFieldLineage, LineageResult
from ..parsers.expression_parser import ExpressionParser
from ..utils.expression_explainer import (
    InformaticaExpressionExplainer,
    explain_transformation_chain,
    explain_transformation_chain_with_context,
)

# Optional XDM imports (Phase 2)
try:
    from .field_mapping_expert_xdm import FieldMappingExpertXDM
    from .pattern_detector import PatternDetector
    from .context_aware_expression_analyzer import ContextAwareExpressionAnalyzer
    from ..utils.xml_utils_xdm import XDMXMLParser
    from ..utils.mapping_ast import MappingAST
    XDM_AVAILABLE = True
except ImportError:
    XDM_AVAILABLE = False

# Optional Phase 3 imports
try:
    from .dependency_graph_expert import DependencyGraphExpert
    from .transformation_chain_analyzer import TransformationChainAnalyzer
    from ..utils.mapping_ast import AdvancedGraphAnalyzer
    PHASE3_AVAILABLE = True
except ImportError:
    PHASE3_AVAILABLE = False


# Built-in Informatica runtime variables and their descriptions.
# Used to annotate transformation logic so readers don't need to look them up.
BUILTIN_VARIABLES = {
    "SESSSTARTTIME": "session start timestamp [date/time]",
    "SYSDATE": "current system date [date/time]",
    "SYSTIMESTAMP": "current system timestamp [date/time]",
    "WORKFLOWSTARTTIME": "workflow start timestamp [date/time]",
}


class IntegrationExpert(BaseExpert):
    """
    Expert for integrating results from all other experts.

    Responsibilities:
    - Orchestrate parallel expert execution
    - Combine results from all experts
    - Resolve conflicts between experts
    - Build end-to-end field-level lineage
    - Calculate overall confidence scores
    """

    def __init__(
        self,
        parallel: bool = True,
        max_workers: int = 3,
        use_xdm: bool = True,
        xdm_parser: Optional["XDMXMLParser"] = None,
        mapping_asts: Optional[Dict[str, "MappingAST"]] = None,
        parameter_loader=None,
    ):
        """
        Initialize the Integration Expert.

        Args:
            parallel: Run sub-experts in parallel
            max_workers: Maximum parallel workers
            use_xdm: Use XDM-enhanced experts when available
            xdm_parser: Pre-initialized XDM parser for XPath queries
            mapping_asts: Pre-built MappingAST instances by mapping name
            parameter_loader: ParameterFileLoader for resolving session-level params
        """
        super().__init__("IntegrationExpert", ExpertType.INTEGRATION)
        self.parallel = parallel
        self.max_workers = max_workers
        self.expression_parser = ExpressionParser()

        # XDM configuration
        self.use_xdm = use_xdm and XDM_AVAILABLE
        self.xdm_parser = xdm_parser
        self.mapping_asts = mapping_asts or {}

        # Parameter loader for resolving $Param_* in flat file names, etc.
        self.parameter_loader = parameter_loader

        # Initialize sub-experts
        self.mapping_structure_expert = MappingStructureExpert(parameter_loader=parameter_loader)
        self.operator_logic_expert = OperatorLogicExpert()

        # Initialize field mapping expert (XDM-enhanced or standard)
        if self.use_xdm and XDM_AVAILABLE:
            self.field_mapping_expert = FieldMappingExpertXDM(xdm_parser=xdm_parser)
            if mapping_asts:
                for name, ast in mapping_asts.items():
                    self.field_mapping_expert.set_mapping_ast(name, ast)
            self.logger.info("Using XDM-enhanced FieldMappingExpert")
        else:
            self.field_mapping_expert = FieldMappingExpert()

        # Initialize XDM-specific experts (Phase 2)
        self.pattern_detector = None
        self.expression_analyzer = None

        if self.use_xdm and XDM_AVAILABLE and xdm_parser is not None:
            self.pattern_detector = PatternDetector(xdm_parser=xdm_parser)
            if mapping_asts:
                for name, ast in mapping_asts.items():
                    self.pattern_detector.set_mapping_ast(name, ast)
            self.expression_analyzer = ContextAwareExpressionAnalyzer(
                xdm_parser=xdm_parser
            )

        # Initialize Phase 3 experts
        self.dependency_graph_expert = None
        self.chain_analyzer = None

        if self.use_xdm and PHASE3_AVAILABLE and mapping_asts:
            self.dependency_graph_expert = DependencyGraphExpert(
                xdm_parser=xdm_parser,
                mapping_asts=mapping_asts,
            )
            self.chain_analyzer = TransformationChainAnalyzer(
                mapping_asts=mapping_asts,
            )
            self.logger.info("Phase 3 experts initialized (dependency graph, chain analysis)")

    def analyze(self, context: ExpertContext) -> ExpertResult:
        """Orchestrate all experts and integrate results."""
        self.logger.info("Starting integration analysis")
        start_time = time.time()

        doc = context.document
        expert_results = {}
        warnings = []

        # Run sub-experts
        if self.parallel:
            expert_results = self._run_parallel(context)
        else:
            expert_results = self._run_sequential(context)

        # Check for failures
        for name, result in expert_results.items():
            if result.status == ExpertStatus.FAILED:
                warnings.append(f"Expert {name} failed: {result.errors}")

        # Run XDM-specific analysis if available
        xdm_results = {}
        if self.use_xdm:
            xdm_results = self._run_xdm_analysis(context)
            for name, result in xdm_results.items():
                if result.get("status") == "failed":
                    warnings.append(f"XDM analysis {name} failed: {result.get('errors', [])}")

        # Build end-to-end lineage
        lineage_results = self._build_end_to_end_lineage(context, expert_results)

        # Combine all results
        integrated_data = {
            "expert_results": {name: r.to_dict() for name, r in expert_results.items()},
            "end_to_end_lineages": [l.to_dict() for l in lineage_results],
            "summary": self._build_summary(doc, expert_results, lineage_results),
        }

        # Add XDM results if available
        if xdm_results:
            integrated_data["xdm_analysis"] = xdm_results
            integrated_data["summary"]["xdm_enabled"] = True
        else:
            integrated_data["summary"]["xdm_enabled"] = False

        # Calculate combined confidence
        confidences = [r.confidence for r in expert_results.values() if r.is_successful]

        # Boost confidence if XDM analysis was successful
        if xdm_results and all(r.get("status") == "completed" for r in xdm_results.values()):
            confidences.append(0.98)  # XDM analysis boost

        combined_confidence = sum(confidences) / len(confidences) if confidences else 0.5

        processing_time = (time.time() - start_time) * 1000
        self.logger.info(f"Integration complete in {processing_time:.2f}ms")

        return self._create_result(
            status=ExpertStatus.COMPLETED,
            data=integrated_data,
            warnings=warnings,
            confidence=combined_confidence,
            processing_time_ms=processing_time,
        )

    def _run_xdm_analysis(self, context: ExpertContext) -> Dict[str, Any]:
        """Run XDM-specific analysis (pattern detection, expression analysis)."""
        results = {}

        # Pattern Detection
        if self.pattern_detector:
            try:
                self.logger.debug("Running pattern detection")
                patterns = []
                for mapping in context.document.mappings:
                    mapping_patterns = self.pattern_detector.detect_all_patterns(mapping.name)
                    patterns.extend([p.to_dict() for p in mapping_patterns])

                results["pattern_detection"] = {
                    "status": "completed",
                    "patterns": patterns,
                    "pattern_count": len(patterns),
                    "by_severity": self._group_patterns_by_severity(patterns),
                    "by_type": self._group_patterns_by_type(patterns),
                }
            except Exception as e:
                self.logger.error(f"Pattern detection failed: {e}")
                results["pattern_detection"] = {
                    "status": "failed",
                    "errors": [str(e)],
                }

        # Expression Analysis
        if self.expression_analyzer:
            try:
                self.logger.debug("Running context-aware expression analysis")
                analyzed_expressions = []

                for mapping in context.document.mappings:
                    for trans in mapping.transformations:
                        for field in trans.expressions:
                            analyzed = self.expression_analyzer.analyze_expression(
                                expression=field.expression,
                                transformation=trans.name,
                                mapping_name=mapping.name,
                            )
                            analyzed_expressions.append(analyzed.to_dict())

                results["expression_analysis"] = {
                    "status": "completed",
                    "expressions": analyzed_expressions,
                    "expression_count": len(analyzed_expressions),
                    "with_issues": sum(1 for e in analyzed_expressions if e.get("potential_issues")),
                }
            except Exception as e:
                self.logger.error(f"Expression analysis failed: {e}")
                results["expression_analysis"] = {
                    "status": "failed",
                    "errors": [str(e)],
                }

        # Phase 3: Dependency Graph Analysis
        if self.dependency_graph_expert:
            try:
                self.logger.debug("Running dependency graph analysis")
                dep_result = self.dependency_graph_expert.analyze(context)

                if dep_result.is_successful:
                    results["dependency_analysis"] = {
                        "status": "completed",
                        "dependency_graphs": dep_result.data.get("dependency_graphs", {}),
                        "circular_dependencies": dep_result.data.get("circular_dependencies_summary", []),
                        "statistics": dep_result.data.get("statistics", {}),
                    }
                else:
                    results["dependency_analysis"] = {
                        "status": "failed",
                        "errors": dep_result.errors,
                    }
            except Exception as e:
                self.logger.error(f"Dependency analysis failed: {e}")
                results["dependency_analysis"] = {
                    "status": "failed",
                    "errors": [str(e)],
                }

        # Phase 3: Transformation Chain Analysis
        if self.chain_analyzer:
            try:
                self.logger.debug("Running transformation chain analysis")
                chain_results = []

                for mapping in context.document.mappings:
                    chain_result = self.chain_analyzer.analyze(mapping.name)
                    if chain_result:
                        chain_results.append({
                            "mapping": mapping.name,
                            "chains": [c.to_dict() for c in chain_result.chains],
                            "critical_paths": [p.to_dict() for p in chain_result.critical_paths],
                            "recommendations": [r.to_dict() for r in chain_result.recommendations],
                            "metrics": chain_result.metrics,
                        })

                results["chain_analysis"] = {
                    "status": "completed",
                    "mappings_analyzed": len(chain_results),
                    "results": chain_results,
                    "total_recommendations": sum(
                        len(r.get("recommendations", [])) for r in chain_results
                    ),
                }
            except Exception as e:
                self.logger.error(f"Chain analysis failed: {e}")
                results["chain_analysis"] = {
                    "status": "failed",
                    "errors": [str(e)],
                }

        return results

    def _group_patterns_by_severity(self, patterns: List[Dict]) -> Dict[str, int]:
        """Group patterns by severity."""
        severity_counts = {}
        for p in patterns:
            severity = p.get("severity", "unknown")
            severity_counts[severity] = severity_counts.get(severity, 0) + 1
        return severity_counts

    def _group_patterns_by_type(self, patterns: List[Dict]) -> Dict[str, int]:
        """Group patterns by type."""
        type_counts = {}
        for p in patterns:
            ptype = p.get("pattern_type", "unknown")
            type_counts[ptype] = type_counts.get(ptype, 0) + 1
        return type_counts

    def _run_parallel(self, context: ExpertContext) -> Dict[str, ExpertResult]:
        """Run sub-experts in parallel."""
        results = {}

        experts = [
            ("MappingStructure", self.mapping_structure_expert),
            ("FieldMapping", self.field_mapping_expert),
            ("OperatorLogic", self.operator_logic_expert),
        ]

        with ThreadPoolExecutor(max_workers=self.max_workers) as executor:
            futures = {
                executor.submit(expert._timed_analyze, context): name
                for name, expert in experts
            }

            for future in as_completed(futures):
                name = futures[future]
                try:
                    results[name] = future.result()
                except Exception as e:
                    self.logger.error(f"Expert {name} failed: {e}")
                    results[name] = ExpertResult(
                        expert_name=name,
                        status=ExpertStatus.FAILED,
                        errors=[str(e)],
                    )

        return results

    def _run_sequential(self, context: ExpertContext) -> Dict[str, ExpertResult]:
        """Run sub-experts sequentially."""
        results = {}

        experts = [
            ("MappingStructure", self.mapping_structure_expert),
            ("FieldMapping", self.field_mapping_expert),
            ("OperatorLogic", self.operator_logic_expert),
        ]

        for name, expert in experts:
            try:
                results[name] = expert._timed_analyze(context)
                # Update context with results for subsequent experts
                context.previous_results[name] = results[name]
            except Exception as e:
                self.logger.error(f"Expert {name} failed: {e}")
                results[name] = ExpertResult(
                    expert_name=name,
                    status=ExpertStatus.FAILED,
                    errors=[str(e)],
                )

        return results

    def _build_end_to_end_lineage(
        self, context: ExpertContext, expert_results: Dict[str, ExpertResult]
    ) -> List[EndToEndFieldLineage]:
        """Build end-to-end field-level lineage from expert results."""
        lineages = []

        field_mapping_result = expert_results.get("FieldMapping")
        operator_result = expert_results.get("OperatorLogic")

        if not field_mapping_result or not field_mapping_result.is_successful:
            return lineages

        # Get lineage graphs
        lineage_graphs = field_mapping_result.data.get("lineage_graphs", {})

        # Get operator information for enrichment
        filters = {}
        aggregators = {}
        lookups = {}
        routers = {}
        joiners = {}
        update_strategies = {}

        if operator_result and operator_result.is_successful:
            for f in operator_result.data.get("filters", []):
                key = f"{f['mapping']}.{f['name']}"
                filters[key] = f
            for a in operator_result.data.get("aggregators", []):
                key = f"{a['mapping']}.{a['name']}"
                aggregators[key] = a
            for l in operator_result.data.get("lookups", []):
                key = f"{l['mapping']}.{l['name']}"
                lookups[key] = l
            for r in operator_result.data.get("routers", []):
                key = f"{r['mapping']}.{r['name']}"
                routers[key] = r
            for j in operator_result.data.get("joiners", []):
                key = f"{j['mapping']}.{j['name']}"
                joiners[key] = j
            for u in operator_result.data.get("update_strategies", []):
                key = f"{u['mapping']}.{u['name']}"
                update_strategies[key] = u

        # Get SQL overrides from MappingStructure expert
        sql_overrides = {}
        mapping_structure_result = expert_results.get("MappingStructure")
        if mapping_structure_result and mapping_structure_result.is_successful:
            for sq in mapping_structure_result.data.get("sql_overrides", []):
                key = f"{sq['mapping']}.{sq['transformation']}"
                sql_overrides[key] = sq

        # Merge session-level SQL overrides from SESSTRANSFORMATIONINST.
        # In Informatica, a session can override the mapping-level SQL Query
        # on a Source Qualifier via an ATTRIBUTE element inside
        # SESSTRANSFORMATIONINST.  Session-level overrides take precedence.
        doc_shortcuts = getattr(context.document, 'shortcuts', {}) or {}
        for _sess in context.document.sessions:
            _sess_mapping_raw = _sess.mapping_name or ""
            if not _sess_mapping_raw:
                continue
            # Resolve session mapping name (may have sc_ prefix from shortcut)
            _sess_mapping = _sess_mapping_raw
            _sess_mapping_lower = _sess_mapping.lower()
            if _sess_mapping_lower in doc_shortcuts:
                _sess_mapping = doc_shortcuts[_sess_mapping_lower]
            elif _sess_mapping_lower.startswith("sc_"):
                _sess_mapping = _sess_mapping[3:]
            for _ti in _sess.transformation_insts:
                _ti_sql = _ti.get_attribute("Sql Query")
                if _ti_sql and _ti_sql.strip():
                    _ti_key = f"{_sess_mapping}.{_ti.sinstance_name}"
                    sql_overrides[_ti_key] = {
                        "mapping": _sess_mapping,
                        "transformation": _ti.sinstance_name,
                        "sql_query": _ti_sql,
                        "source": "session",
                    }
                    self.logger.debug(
                        f"Session-level SQL override: {_ti_key} from session {_sess.name}"
                    )

        # Process each mapping
        for mapping in context.document.mappings:
            graph_data = lineage_graphs.get(mapping.name, {})
            if not graph_data:
                continue

            # Build sequence generator lookup for this mapping.
            # Maps (receiving_instance_lower, port_lower) -> {name, start, increment, port}
            # Reusable Sequence transformations may be at the document level (not in
            # mapping.transformations), so we build a combined lookup by instance name.
            seq_gen_lookup: Dict[tuple, Dict[str, str]] = {}
            # Collect all sequence transformations: mapping-level + document-level
            all_seq_trans: Dict[str, Any] = {}  # name_lower -> Transformation
            for trans in mapping.transformations:
                if "sequence" in trans.type.lower():
                    all_seq_trans[trans.name.lower()] = trans
            for trans in getattr(context.document, 'transformations', []):
                if "sequence" in trans.type.lower():
                    all_seq_trans[trans.name.lower()] = trans
            # Find instances that reference sequence transformations
            seq_instance_names: Dict[str, Any] = {}  # inst_name_lower -> Transformation
            for inst in mapping.instances:
                trans_name = (inst.transformation_name or inst.name).lower()
                if trans_name in all_seq_trans:
                    seq_instance_names[inst.name.lower()] = all_seq_trans[trans_name]
            # Trace connectors from sequence instances to receiving instances
            for conn in mapping.connectors:
                if (conn.from_instance.lower() in seq_instance_names
                        and conn.from_field.upper() in ("NEXTVAL", "CURRVAL")):
                    seq_trans = seq_instance_names[conn.from_instance.lower()]
                    start_val = seq_trans.get_attribute("Start Value") or "0"
                    incr_val = seq_trans.get_attribute("Increment By") or "1"
                    seq_gen_lookup[(conn.to_instance.lower(), conn.to_field.lower())] = {
                        "name": seq_trans.name,
                        "start": start_val,
                        "increment": incr_val,
                        "port": conn.from_field.upper(),
                    }

            # Build port-type lookup and Custom Transformation port mapping.
            # port_type_lookup: (instance_lower, field_lower) -> port_type string
            # custom_tx_port_map: (instance_lower, output_port_lower) -> [input_port_lower, ...]
            # inst_to_trans_map: instance_lower -> Transformation object
            port_type_lookup: Dict[tuple, str] = {}
            custom_tx_port_map: Dict[tuple, list] = {}
            # Build instance-to-transformation mapping (mapping + document level)
            _all_trans_map: Dict[str, Any] = {}
            for trans in mapping.transformations:
                _all_trans_map[trans.name.lower()] = trans
            for trans in getattr(context.document, 'transformations', []):
                _all_trans_map[trans.name.lower()] = trans
            inst_to_trans_map: Dict[str, Any] = {}
            for inst in mapping.instances:
                _trans_name = (inst.transformation_name or inst.name).lower()
                if _trans_name in _all_trans_map:
                    inst_to_trans_map[inst.name.lower()] = _all_trans_map[_trans_name]
            # Populate port_type_lookup
            for inst in mapping.instances:
                _inst_lower = inst.name.lower()
                _trans = inst_to_trans_map.get(_inst_lower)
                if not _trans:
                    continue
                for fld in _trans.fields:
                    port_type_lookup[(_inst_lower, fld.name.lower())] = fld.port_type
            # Build Custom Transformation output-to-input port mapping
            for inst in mapping.instances:
                if "custom" not in inst.transformation_type.lower():
                    continue
                _inst_lower = inst.name.lower()
                _trans = inst_to_trans_map.get(_inst_lower)
                if not _trans:
                    continue
                _output_ports = [f.name for f in _trans.fields if f.is_output and not f.is_input]
                _input_ports = [f.name for f in _trans.fields if f.is_input and not f.is_output]
                for _out_port in _output_ports:
                    _out_lower = _out_port.lower()
                    _matching = []
                    for _in_port in _input_ports:
                        _in_lower = _in_port.lower()
                        # Try progressively stripping trailing digits:
                        # ERROR_CODE41 -> ERROR_CODE4 (strip 1 digit)
                        # ERROR_CODE41 -> ERROR_CODE  (strip all digits)
                        # This handles both patterns:
                        #   output ERROR_CODE4, inputs ERROR_CODE41/42
                        #   output FEATURE_NM, inputs FEATURE_NM2/3/4
                        _matched = False
                        _base_all = re.sub(r'\d+$', '', _in_lower)
                        if _base_all == _out_lower:
                            _matched = True
                        elif len(_in_lower) > len(_out_lower) and _in_lower[:len(_out_lower)] == _out_lower and _in_lower[len(_out_lower):].isdigit():
                            # Input starts with output name + trailing digits only
                            _matched = True
                        if _matched:
                            _matching.append(_in_lower)
                    if _matching:
                        custom_tx_port_map[(_inst_lower, _out_lower)] = _matching

            # For each target field, trace lineage backward
            # First try using mapping.targets (target table definitions)
            if mapping.targets:
                # Check if multiple target instances share the same transformation_name
                # (i.e. the same target definition). This happens with Router-fed targets,
                # Joiner-based pipelines, or any pattern where one target table receives
                # data from multiple independent pipelines. In such cases, iterate
                # target_instances instead of targets to get per-instance lineage.
                from collections import Counter as _Counter
                _target_trans_counts = _Counter(
                    inst.transformation_name.lower() for inst in mapping.target_instances
                )
                has_multi_instance = any(c > 1 for c in _target_trans_counts.values())

                if has_multi_instance:
                    # Iterate target_instances directly so each Router path gets
                    # its own lineage traced from the correct instance-specific node.
                    for inst in mapping.target_instances:
                        # Find the target definition for this instance's transformation_name
                        target_def = None
                        trans_name_lower = inst.transformation_name.lower()
                        for t in mapping.targets:
                            if t.name.lower() == trans_name_lower:
                                target_def = t
                                break
                        # If not found, try resolving via shortcuts (sc_ADDRESS -> ADDRESS)
                        if not target_def and doc_shortcuts:
                            resolved_name = doc_shortcuts.get(trans_name_lower)
                            if resolved_name:
                                for t in mapping.targets:
                                    if t.name.lower() == resolved_name.lower():
                                        target_def = t
                                        break
                        if not target_def:
                            continue
                        for target_field in target_def.fields:
                            lineage = self._trace_field_lineage(
                                mapping, target_def, target_field,
                                graph_data, filters, aggregators, lookups,
                                shortcuts=doc_shortcuts,
                                instance_name_override=inst.name,
                                routers=routers,
                                sql_overrides=sql_overrides,
                                joiners=joiners,
                                update_strategies=update_strategies,
                                seq_gen_lookup=seq_gen_lookup,
                                port_type_lookup=port_type_lookup,
                                custom_tx_port_map=custom_tx_port_map,
                                inst_to_trans_map=inst_to_trans_map,
                                sessions=context.document.sessions,
                                mapplets=context.document.mapplets,
                            )
                            if lineage:
                                lineages.append(lineage)
                else:
                    for target in mapping.targets:
                        for target_field in target.fields:
                            lineage = self._trace_field_lineage(
                                mapping, target, target_field,
                                graph_data, filters, aggregators, lookups,
                                shortcuts=doc_shortcuts,
                                routers=routers,
                                sql_overrides=sql_overrides,
                                joiners=joiners,
                                update_strategies=update_strategies,
                                seq_gen_lookup=seq_gen_lookup,
                                port_type_lookup=port_type_lookup,
                                custom_tx_port_map=custom_tx_port_map,
                                inst_to_trans_map=inst_to_trans_map,
                                sessions=context.document.sessions,
                                mapplets=context.document.mapplets,
                            )
                            if lineage:
                                lineages.append(lineage)
            else:
                # Fallback: derive target fields from edges going to target instances
                edges = graph_data.get("edges", [])
                target_inst_names = {inst.name.lower() for inst in mapping.target_instances}

                # Build lookup from instance name to transformation name (target definition name)
                inst_to_trans = {
                    inst.name.lower(): inst.transformation_name.lower()
                    for inst in mapping.target_instances
                }

                # Build lookup from target definition name to target object
                target_def_lookup = {
                    t.name.lower(): t for t in context.document.targets
                }

                # Collect unique target fields from edges
                target_fields_seen = set()
                for edge in edges:
                    target_inst = edge.get("target_instance", "")
                    target_field_name = edge.get("target_field", "")
                    target_type = edge.get("target_type", "")

                    # Check if this edge goes to a target instance
                    if (target_inst.lower() in target_inst_names or
                        "target" in target_type.lower()):
                        field_key = f"{target_inst}.{target_field_name}"
                        if field_key not in target_fields_seen:
                            target_fields_seen.add(field_key)

                            # Look up the field datatype from the target definition
                            field_datatype = ""
                            trans_name = inst_to_trans.get(target_inst.lower(), "")
                            if trans_name:
                                # Try exact match first
                                target_def = target_def_lookup.get(trans_name)

                                # Try without common prefixes (sc_, shortcut_to_)
                                if not target_def:
                                    for prefix in ["sc_", "shortcut_to_"]:
                                        if trans_name.startswith(prefix):
                                            stripped_name = trans_name[len(prefix):]
                                            target_def = target_def_lookup.get(stripped_name)
                                            if target_def:
                                                break

                                # Try partial match as last resort
                                if not target_def:
                                    for def_name, def_obj in target_def_lookup.items():
                                        if def_name in trans_name or trans_name in def_name:
                                            target_def = def_obj
                                            break

                                if target_def:
                                    for fld in target_def.fields:
                                        if fld.name.lower() == target_field_name.lower():
                                            field_datatype = fld.full_datatype
                                            break

                            # Create a minimal target-like object for tracing
                            class TargetProxy:
                                def __init__(self, name):
                                    self.name = name
                            class FieldProxy:
                                def __init__(self, name, datatype=""):
                                    self.name = name
                                    self.full_datatype = datatype

                            # Resolve the instance name to actual target name
                            resolved_target_name = target_inst
                            if target_def:
                                resolved_target_name = target_def.name
                            elif doc_shortcuts:
                                resolved = doc_shortcuts.get(target_inst.lower())
                                if resolved:
                                    resolved_target_name = resolved
                                else:
                                    # Instance name not in shortcuts — try
                                    # transformation_name (sc_ERROR_LOG → ERROR_LOG)
                                    trans_name = inst_to_trans.get(target_inst.lower(), "")
                                    if trans_name:
                                        resolved = doc_shortcuts.get(trans_name)
                                        if resolved:
                                            resolved_target_name = resolved
                                    if resolved_target_name == target_inst and target_inst.lower().startswith("sc_"):
                                        resolved_target_name = target_inst[3:]

                            target_proxy = TargetProxy(resolved_target_name)
                            field_proxy = FieldProxy(target_field_name, field_datatype)

                            lineage = self._trace_field_lineage(
                                mapping, target_proxy, field_proxy,
                                graph_data, filters, aggregators, lookups,
                                shortcuts=doc_shortcuts,
                                routers=routers,
                                sql_overrides=sql_overrides,
                                joiners=joiners,
                                update_strategies=update_strategies,
                                seq_gen_lookup=seq_gen_lookup,
                                port_type_lookup=port_type_lookup,
                                custom_tx_port_map=custom_tx_port_map,
                                inst_to_trans_map=inst_to_trans_map,
                                sessions=context.document.sessions,
                                mapplets=context.document.mapplets,
                            )
                            if lineage:
                                lineages.append(lineage)

        return lineages

    def _has_router_with_duplicate_definitions(self, mapping) -> bool:
        """
        Check if a mapping has a Router transformation with multiple target instances
        that share the same transformation_name (i.e. the same target definition).

        This happens when e.g. LND_PARTY_ACCOUNT has 3 Router-fed instances:
        sc_LND_PARTY_ACCOUNT, sc_LND_PARTY_ACCOUNT1, sc_LND_PARTY_ACCOUNT11
        all pointing to the same target definition LND_PARTY_ACCOUNT.
        """
        # Check if there's a Router transformation
        # transformation_type can be an Enum or a string depending on the parser
        has_router = any(
            (getattr(t.transformation_type, 'value', t.transformation_type) or '').upper() == "ROUTER"
            for t in mapping.transformations
        )
        if not has_router:
            return False

        # Check if any transformation_name appears more than once among target instances
        from collections import Counter
        trans_name_counts = Counter(
            inst.transformation_name.lower() for inst in mapping.target_instances
        )
        return any(count > 1 for count in trans_name_counts.values())

    def _resolve_source_qualifier_to_table(
        self,
        sq_instance_name: str,
        mapping,
        shortcuts: Optional[Dict[str, str]] = None,
        sessions: Optional[list] = None,
    ) -> Optional[str]:
        """
        Resolve a Source Qualifier instance to its actual source table name.

        Source Qualifiers (SQ_*) have associated_sources that link to the
        actual source table instances. If the source is a shortcut, we also
        resolve it to the actual table name.

        Args:
            sq_instance_name: Name of the Source Qualifier instance (e.g., "SQ_PARTY_ACCOUNT")
            mapping: The mapping object containing instances
            shortcuts: Dictionary mapping shortcut names to actual table names

        Returns:
            The actual source table name, or None if not found
        """
        shortcuts = shortcuts or {}
        sq_name_lower = sq_instance_name.lower()

        # Find the Source Qualifier instance
        sq_instance = None
        for inst in mapping.instances:
            if inst.name.lower() == sq_name_lower:
                sq_instance = inst
                break

        if not sq_instance:
            return None

        # Check if this is a Source Qualifier by transformation type
        ttype = sq_instance.transformation_type.upper()
        if not (ttype.startswith("SOURCE QUALIFIER") or ttype.startswith("XML SOURCE QUALIFIER")):
            return None

        # Get the associated source from associated_sources
        if sq_instance.associated_sources:
            # Return the first associated source name
            assoc_source_name = sq_instance.associated_sources[0].name

            # Now resolve this to the actual source table name
            # by looking up the source instance
            source_table_name = None
            for src_inst in mapping.source_instances:
                if src_inst.name.lower() == assoc_source_name.lower():
                    # Get the transformation_name which might be a shortcut
                    source_table_name = src_inst.transformation_name
                    break

            if not source_table_name:
                source_table_name = assoc_source_name

            # Check if this is a shortcut and resolve to actual table name
            source_name_lower = source_table_name.lower()
            if source_name_lower in shortcuts:
                actual_table = shortcuts[source_name_lower]
                self.logger.debug(f"Resolved shortcut: {source_table_name} -> {actual_table}")
                return self._qualify_source_table(actual_table, mapping, sessions=sessions, shortcuts=shortcuts)

            # Resolve source instance name to actual source definition name
            # and qualify with owner/schema.  Source instances often have sc_ prefix
            # (e.g. sc_SHAW_MAST_ILN_STG) while the source definition has the real
            # table name (e.g. SHAW_MAST_ILN_STG) with owner_name for schema.
            qualified = self._qualify_source_table(source_table_name, mapping, sessions=sessions, shortcuts=shortcuts)
            return qualified

        # Fallback for XML Source Qualifiers: associated_sources is often empty.
        # Find the Source Definition instance whose name appears in the SQ name.
        sq_lower = sq_name_lower
        for src_inst in mapping.source_instances:
            src_type = getattr(src_inst, "transformation_type", "")
            if "source definition" in str(src_type).lower():
                src_name = src_inst.transformation_name or src_inst.name
                if src_name.lower() in sq_lower:
                    source_name_lower = src_name.lower()
                    if source_name_lower in shortcuts:
                        return self._qualify_source_table(shortcuts[source_name_lower], mapping, sessions=sessions, shortcuts=shortcuts)
                    return self._qualify_source_table(src_name, mapping, sessions=sessions, shortcuts=shortcuts)

        return None

    # DBDNAME-to-$Param mapping: maps the logical database name on INSTANCE
    # tags to the corresponding $Param_* placeholder that resolves to the
    # production database at runtime.
    _DBDNAME_TO_PARAM = {
        "edw_td_stg": "$Param_STG_Database",
        "edw_td_base": "$Param_BASE_Database",
        "edw_td_utilwork": "$Param_Work_Database",
        "edw_td_cntl": "$Param_Control_Database",
        "edw_td_control": "$Param_Control_Database",
        "edw_td_etl_app": "$Param_SP_Database",
        "ccardm_td": "$Param_CCAR_Database",
        "edw_app_extract": "$Param_STG_Database1",
    }

    def _qualify_source_table(self, source_name: str, mapping, sessions=None, shortcuts=None) -> str:
        """
        Resolve a source instance/table name to a fully qualified name (owner.table).

        Matches the given source_name against mapping.sources to find the actual
        source definition, then derives the database/schema from the INSTANCE
        DBDNAME attribute + parameter mapping.  The OWNERNAME attribute on
        <SOURCE> tags is intentionally ignored because it often contains
        dev-environment prefixes (e.g. D2_EDW_STG_01_E0) that do not match
        the production runtime values.

        Resolution priority:
        1. Session-level ATTRIBUTE "Owner Name" override ($Param_*)
        2. INSTANCE DBDNAME -> $Param_* mapping
        3. Bare table name (no prefix)

        Args:
            source_name: Raw source name (may be sc_ prefixed instance name)
            mapping: The mapping object containing source definitions
            sessions: Optional list of Session objects for session-level overrides

        Returns:
            Fully qualified table name (e.g., $Param_STG_Database.SHAW_MAST_ILN_STG)
        """
        source_name_lower = source_name.lower()

        # Check session-level owner/prefix overrides first (runtime values
        # take precedence over design-time owner_name from source definition)
        session_owner = None
        if sessions:
            mapping_name_lower = mapping.name.lower()
            # Also accept shortcut-prefixed mapping names (e.g. sc_m_X matches m_X)
            for session in sessions:
                _sm = (session.mapping_name or "").lower()
                if not _sm:
                    continue
                _match = (_sm == mapping_name_lower)
                if not _match:
                    # Try stripping sc_ prefix from session mapping name
                    if _sm.startswith("sc_") and _sm[3:] == mapping_name_lower:
                        _match = True
                    # Also resolve via shortcuts dict
                    elif shortcuts and shortcuts.get(_sm, "").lower() == mapping_name_lower:
                        _match = True
                if _match:
                    for ti in session.transformation_insts:
                        _ti_lower = ti.sinstance_name.lower()
                        _ti_stripped = _ti_lower[3:] if _ti_lower.startswith("sc_") else _ti_lower
                        if (_ti_lower == source_name_lower
                                or _ti_stripped == source_name_lower):
                            # When Source Table Name is set AND already contains
                            # a schema prefix (e.g., "dbo.table"), use it directly.
                            # Otherwise use Owner Name as the schema prefix.
                            _stn = ti.source_table_name
                            if _stn and "." in _stn:
                                return _stn
                            if ti.owner_name:
                                session_owner = ti.owner_name
                            elif ti.table_name_prefix:
                                session_owner = ti.table_name_prefix
                            break
                    if session_owner:
                        break

        # Look up INSTANCE db_dname for this source to derive $Param_* prefix.
        # Prefer Source Definition instances (which carry DBDNAME) over Source Qualifiers.
        instance_db_dname = None
        _db_dname_candidates = []
        for inst in mapping.instances:
            if not inst.is_source:
                continue
            _inst_name_l = inst.name.lower()
            _trans_name_l = (inst.transformation_name or "").lower()
            _trans_stripped = _trans_name_l[3:] if _trans_name_l.startswith("sc_") else _trans_name_l
            if (_inst_name_l == source_name_lower
                    or _trans_name_l == source_name_lower
                    or _trans_stripped == source_name_lower):
                _db_dname_candidates.append((inst.db_dname or "", inst.transformation_type or ""))
        # Pick the first candidate with a non-empty db_dname (prefer Source Definition)
        for _dbd, _ttype in _db_dname_candidates:
            if _dbd:
                instance_db_dname = _dbd
                break
        if not instance_db_dname and _db_dname_candidates:
            instance_db_dname = _db_dname_candidates[0][0]

        # Try to match against mapping.sources (source definitions)
        for src_def in mapping.sources:
            src_def_lower = src_def.name.lower()

            # Exact match
            if src_def_lower == source_name_lower:
                return self._build_qualified_name(src_def, session_owner, instance_db_dname,
                                                  sessions=sessions, source_instance_name=source_name)

            # Strip common prefixes (sc_, sq_, src_) and match
            stripped = source_name_lower
            for prefix in ("sc_", "sq_", "src_"):
                if stripped.startswith(prefix):
                    stripped = stripped[len(prefix):]
                    break

            if stripped == src_def_lower:
                return self._build_qualified_name(src_def, session_owner, instance_db_dname,
                                                  sessions=sessions, source_instance_name=source_name)

            # Check if source def name is contained in instance name
            if src_def_lower in source_name_lower:
                return self._build_qualified_name(src_def, session_owner, instance_db_dname,
                                                  sessions=sessions, source_instance_name=source_name)

        # Try shortcut resolution: instance transformation_name -> shortcut -> source def
        if shortcuts:
            for inst in mapping.instances:
                if inst.name.lower() == source_name_lower and inst.is_source:
                    trans_name = inst.transformation_name.lower()
                    resolved = shortcuts.get(trans_name)
                    if resolved:
                        for src_def in mapping.sources:
                            if src_def.name.lower() == resolved.lower():
                                return self._build_qualified_name(
                                    src_def, session_owner, instance_db_dname,
                                    sessions=sessions, source_instance_name=source_name,
                                )
                    break

        # No matching source definition found — return as-is
        return source_name

    def _qualify_target_table(
        self,
        target_table: str,
        target_instance_name: str,
        mapping,
        sessions=None,
        shortcuts=None,
    ) -> str:
        """
        Qualify a target table name with its database prefix.

        Reads "Table Name Prefix" from the session's SESSTRANSFORMATIONINST
        for the target instance and resolves $Param_* placeholders.

        Args:
            target_table: The resolved target table name (e.g. SHAWILN_AGMT_LMT_TGT_STG)
            target_instance_name: The target instance name (e.g. sc_SHAWILN_AGMT_LMT_TGT_STG)
            mapping: The Mapping object
            sessions: Optional list of Session objects
            shortcuts: Optional shortcuts dict

        Returns:
            Qualified name (e.g. P_EDW_STG_01_E0.SHAWILN_AGMT_LMT_TGT_STG)
        """
        if not sessions or "." in target_table:
            return target_table

        # Skip flat file targets
        for tgt_def in mapping.targets:
            if tgt_def.name.lower() == target_table.lower():
                if hasattr(tgt_def, "database_type") and tgt_def.database_type and \
                        "flat file" in tgt_def.database_type.lower():
                    return target_table

        target_inst_lower = target_instance_name.lower()
        mapping_name_lower = mapping.name.lower()
        db_prefix = None

        for session in sessions:
            _sm = (session.mapping_name or "").lower()
            if not _sm:
                continue
            _match = (_sm == mapping_name_lower)
            if not _match:
                if _sm.startswith("sc_") and _sm[3:] == mapping_name_lower:
                    _match = True
                elif f"sc_{_sm}" == mapping_name_lower:
                    _match = True
                elif shortcuts and shortcuts.get(_sm, "").lower() == mapping_name_lower:
                    _match = True
            if not _match:
                continue

            # Build set of names to match against session transformation insts
            _match_names = {target_inst_lower}
            # Add sc_ prefixed variant
            _match_names.add(f"sc_{target_inst_lower}")
            # Add all target instance names that resolve to this target table
            for _tgt_inst in mapping.target_instances:
                _trans_resolved = _tgt_inst.transformation_name.lower()
                if shortcuts:
                    _trans_resolved = shortcuts.get(_trans_resolved, _trans_resolved).lower()
                _trans_stripped = _trans_resolved[3:] if _trans_resolved.startswith("sc_") else _trans_resolved
                if _trans_stripped == target_table.lower() or _tgt_inst.name.lower() == target_inst_lower:
                    _match_names.add(_tgt_inst.name.lower())

            for ti in session.transformation_insts:
                _ti_lower = ti.sinstance_name.lower()
                if _ti_lower in _match_names:
                    if ti.table_name_prefix:
                        db_prefix = ti.table_name_prefix
                    elif ti.owner_name:
                        db_prefix = ti.owner_name
                    break
            if db_prefix:
                break

        if not db_prefix:
            return target_table

        # Resolve $Param_* placeholders
        if db_prefix.startswith("$") and self.parameter_loader:
            resolved = self.parameter_loader.resolve_placeholders(db_prefix)
            if resolved != db_prefix:
                db_prefix = resolved

        # If still unresolved ($Param_*), try DBDNAME mapping
        if db_prefix.startswith("$"):
            param_key = db_prefix.lstrip("$")
            mapped = self._DBDNAME_TO_PARAM.get(param_key.lower())
            if mapped:
                db_prefix = mapped

        return f"{db_prefix}.{target_table}"

    def _build_qualified_name(self, source_def, session_owner=None, instance_db_dname=None,
                              sessions=None, source_instance_name=None) -> str:
        """Build database.table_name from a source definition.

        Resolution priority (OWNERNAME on <SOURCE> is intentionally ignored):
        1. Flat file sources: resolve to actual filename from session extension
        2. session_owner - session-level ATTRIBUTE "Owner Name" (may contain $Param_*)
        3. instance_db_dname mapped to $Param_* via _DBDNAME_TO_PARAM
        4. Bare table name (no prefix)

        Args:
            source_def: Source definition object with name
            session_owner: Optional session-level owner override (may contain $Param_*)
            instance_db_dname: Optional DBDNAME from the source INSTANCE tag
            sessions: Optional list of Session objects for flat file attribute lookup
            source_instance_name: Instance name to match against session extensions
        """
        table_name = source_def.name

        # 0. Flat file sources: resolve to actual filename from session extension
        if hasattr(source_def, "database_type") and source_def.database_type and \
                "flat file" in source_def.database_type.lower():
            resolved_name = self._resolve_flat_file_name(
                source_instance_name or table_name, sessions
            )
            if resolved_name:
                return resolved_name

        # 1. Session-level owner takes precedence (runtime override)
        if session_owner:
            return f"{session_owner}.{table_name}"

        # 2. Map INSTANCE DBDNAME to $Param_* placeholder
        if instance_db_dname:
            param = self._DBDNAME_TO_PARAM.get(instance_db_dname.lower())
            if param:
                return f"{param}.{table_name}"

        # 3. No prefix available
        return table_name

    def _resolve_flat_file_name(self, source_instance_name: str, sessions=None) -> Optional[str]:
        """Resolve a flat file source instance to its actual filename.

        Looks up the SESSIONEXTENSION for the source instance and extracts
        'Source filename' and 'Source file directory' attributes, then resolves
        any $Param_* / $PM* references.

        The instance name may be the source def name (e.g. FF_LKUP_SBMN_CNTL)
        while the session extension uses the shortcut/instance name (e.g.
        sc_FF_LKUP_SBMN_CNTL), so we try multiple matching strategies.

        Returns:
            Resolved filename (with path), or None if not found.
        """
        if not sessions:
            return None

        instance_lower = source_instance_name.lower()
        for session in sessions:
            for ext in session.extensions:
                ext_name_lower = ext.sinstance_name.lower()
                # Try exact match, sc_ prefixed match, or containment
                if not (ext_name_lower == instance_lower
                        or ext_name_lower == f"sc_{instance_lower}"
                        or instance_lower in ext_name_lower):
                    continue
                src_filename = ext.get_attribute("Source filename")
                if not src_filename:
                    continue

                src_dir = ext.get_attribute("Source file directory") or ""
                # Resolve $Param_* / $PM* placeholders
                if self.parameter_loader:
                    src_filename = self.parameter_loader.resolve_for_session(
                        src_filename, session.name
                    )
                    if src_dir:
                        src_dir = self.parameter_loader.resolve_for_session(
                            src_dir, session.name
                        )

                # Build path: dir/filename or just filename
                src_dir = src_dir.rstrip("\\/")
                if src_dir:
                    return f"{src_dir}/{src_filename}"
                return src_filename

        return None

    def _resolve_flat_file_target_name(self, target_instance_name: str, sessions=None) -> Optional[str]:
        """Resolve a flat file target instance to its actual output filename.

        Mirrors _resolve_flat_file_name but looks for 'Output filename' and
        'Output file directory' attributes in WRITER session extensions.

        Returns:
            Resolved filename (with path), or None if not found.
        """
        if not sessions:
            return None

        instance_lower = target_instance_name.lower()
        for session in sessions:
            for ext in session.extensions:
                if ext.extension_type.upper() != "WRITER":
                    continue
                ext_name_lower = ext.sinstance_name.lower()
                # Try exact match, sc_ prefixed match, or containment
                if not (ext_name_lower == instance_lower
                        or ext_name_lower == f"sc_{instance_lower}"
                        or instance_lower in ext_name_lower):
                    continue
                tgt_filename = ext.get_attribute("Output filename")
                if not tgt_filename:
                    continue

                tgt_dir = ext.get_attribute("Output file directory") or ""
                # Resolve $Param_* / $PM* placeholders
                if self.parameter_loader:
                    tgt_filename = self.parameter_loader.resolve_for_session(
                        tgt_filename, session.name
                    )
                    if tgt_dir:
                        tgt_dir = self.parameter_loader.resolve_for_session(
                            tgt_dir, session.name
                        )

                # Build path: dir/filename or just filename
                tgt_dir = tgt_dir.rstrip("\\/")
                if tgt_dir:
                    return f"{tgt_dir}/{tgt_filename}"
                return tgt_filename

        return None

    @staticmethod
    def _extract_tables_and_fields_from_expr(
        expr: str, alias_to_table: Dict[str, str]
    ) -> tuple:
        """Extract all real tables and table.field references from a SQL expression.

        Returns:
            (tables: List[str], fields: List[Dict]) where each field dict has
            {"table": "schema.table", "field": "col_name"}.
        """
        tables = []
        fields = []
        _sql_kw = {
            'select', 'from', 'where', 'case', 'when', 'then', 'else', 'end',
            'and', 'or', 'not', 'in', 'is', 'null', 'between', 'like', 'as',
            'cast', 'trim', 'coalesce', 'on', 'inner', 'join', 'left', 'right',
            'full', 'cross', 'union', 'group', 'order', 'by', 'having', 'exists',
            'distinct', 'all', 'char', 'varchar', 'integer', 'bigint', 'date',
            'format', 'current_date', 'current_time', 'current_timestamp',
            'abs', 'sum', 'count', 'max', 'min', 'avg', 'char_length',
            'substring', 'substr', 'upper', 'lower', 'replace', 'lpad', 'rpad',
            'ltrim', 'rtrim', 'concat', 'len', 'length', 'qualify', 'row_number',
            'over', 'partition',
        }
        # Find FROM/JOIN table references
        for m in re.finditer(r'\b(?:FROM|JOIN)\s+([\w.$]+)', expr, re.IGNORECASE):
            tbl = m.group(1)
            if '.' in tbl and tbl.split('.')[0].lower() not in _sql_kw:
                if tbl not in tables:
                    tables.append(tbl)
        # Find alias.column references and resolve aliases
        for m in re.finditer(r'\b([A-Za-z_]\w*)\s*\.\s*([A-Za-z_]\w*)', expr):
            prefix = m.group(1)
            col = m.group(2)
            if prefix.lower() in _sql_kw:
                continue
            resolved = alias_to_table.get(prefix.lower(), prefix)
            if resolved == "SQL_DERIVED":
                continue
            if '.' in resolved:
                if resolved not in tables:
                    tables.append(resolved)
                fields.append({"table": resolved, "field": col})
        return tables, fields

    @staticmethod
    def _parse_sql_column_to_table(sql_text: str, return_expressions: bool = False) -> Union[Dict[str, str], tuple]:
        """Parse a SQL Override SELECT to map each output column to its source table.

        Handles:
        - alias.column (e.g. DTE.CURRENT_STRT_DT -> resolve DTE alias)
        - table.column (e.g. SHAW_GL_ILN_RAW.GLILev1)
        - (SELECT col FROM table ...) AS alias -> subquery source table
        - bare column names -> first/default table in FROM

        Args:
            sql_text: The SQL Override text to parse
            return_expressions: If True, also return a dict of derived column
                expressions (column_lower -> SQL expression string) for columns
                that are not simple table.column references.

        Returns:
            If return_expressions is False:
                Dict mapping output_column_name_lower -> fully-qualified table name
            If return_expressions is True:
                Tuple of (column_to_table dict, column_to_expression dict)
        """
        _empty = ({}, {}, {}, {}) if return_expressions else {}
        if not sql_text:
            return _empty

        # Normalize whitespace and fix "schema. table" -> "schema.table"
        sql = re.sub(r'\s+', ' ', sql_text.strip())
        sql = re.sub(r'\.\s+', '.', sql)

        # Split into SELECT ... FROM ... WHERE ...
        # Find FROM position (not inside subquery)
        from_pos = -1
        depth = 0
        sql_upper = sql.upper()
        for i in range(len(sql) - 4):
            if sql[i] == '(':
                depth += 1
            elif sql[i] == ')':
                depth -= 1
            elif depth == 0 and sql_upper[i:i+5] == ' FROM' and (i + 5 >= len(sql) or (not sql[i+5].isalnum() and sql[i+5] != '_')):
                from_pos = i + 5
                break

        if from_pos < 0:
            return _empty

        select_part = sql[len('SELECT '):from_pos - 5].strip() if sql_upper.startswith('SELECT') else ""
        rest = sql[from_pos:].strip()

        # Extract FROM clause (up to WHERE/GROUP BY/ORDER BY/HAVING or end)
        where_pos = len(rest)
        depth = 0
        rest_upper = rest.upper()
        for i in range(len(rest)):
            if rest[i] == '(':
                depth += 1
            elif rest[i] == ')':
                depth -= 1
            elif depth == 0:
                for kw in (' WHERE ', ' GROUP ', ' ORDER ', ' HAVING '):
                    if rest_upper[i:i+len(kw)] == kw:
                        where_pos = i
                        break
                if where_pos != len(rest):
                    break
        from_clause = rest[:where_pos].strip()

        # Parse FROM clause: extract table/alias pairs
        # Handle: schema.table alias, schema.table AS alias, (subquery) alias
        alias_to_table: Dict[str, str] = {}
        default_table = None

        # Split by comma (but not inside parens)
        from_items = []
        depth = 0
        current = []
        for ch in from_clause:
            if ch == '(':
                depth += 1
                current.append(ch)
            elif ch == ')':
                depth -= 1
                current.append(ch)
            elif ch == ',' and depth == 0:
                from_items.append(''.join(current).strip())
                current = []
            else:
                current.append(ch)
        if current:
            from_items.append(''.join(current).strip())

        # Further split each comma-item by JOIN keywords so that
        # "table1 alias1 INNER JOIN table2 alias2 ON ..." becomes
        # separate items ["table1 alias1", "table2 alias2 ON ..."].
        expanded_items = []
        _join_re = re.compile(
            r'\b(?:LEFT\s+OUTER\s+JOIN|INNER\s+JOIN|LEFT\s+JOIN|RIGHT\s+JOIN|'
            r'FULL\s+OUTER\s+JOIN|FULL\s+JOIN|CROSS\s+JOIN|JOIN)\b',
            re.IGNORECASE,
        )
        for item in from_items:
            parts = _join_re.split(item)
            for p in parts:
                p = p.strip()
                if p:
                    # Strip ON clause: keep only the table/alias portion
                    on_match = re.search(r'\bON\b', p, re.IGNORECASE)
                    if on_match:
                        p = p[:on_match.start()].strip()
                    if p:
                        expanded_items.append(p)
        from_items = expanded_items

        for item in from_items:
            item = item.strip()
            if not item:
                continue
            # Remove JOIN keywords
            for jk in ('CROSS JOIN', 'LEFT JOIN', 'RIGHT JOIN', 'INNER JOIN', 'FULL JOIN', 'JOIN'):
                if item.upper().startswith(jk):
                    item = item[len(jk):].strip()

            # Handle parenthesized FROM items
            if item.startswith('('):
                inner = item.strip('()')
                inner_upper = inner.strip().upper()
                # True subquery: (SELECT ...) alias
                if inner_upper.startswith('SELECT '):
                    close = item.rfind(')')
                    if close > 0:
                        subquery = item[1:close]
                        alias_part = item[close+1:].strip()
                        alias = alias_part.split()[-1] if alias_part.split() else ""
                        sub_from = re.search(r'\bFROM\s+([\w.$]+)', subquery, re.IGNORECASE)
                        if sub_from and alias:
                            alias_to_table[alias.lower()] = sub_from.group(1)
                        elif alias:
                            # Subquery has no real FROM table (e.g., inline
                            # constants like CROSS JOIN (SELECT 'I' UNION
                            # SELECT 'O') IO_IND).  Register as SQL_DERIVED
                            # so downstream code doesn't treat the alias as a
                            # real table name.
                            alias_to_table[alias.lower()] = "SQL_DERIVED"
                    continue
                # Parenthesized JOIN group: (table1 alias1 INNER JOIN table2 alias2 ON ...)
                # Strip parens and extract table/alias pairs from the join parts
                # Remove ON clauses first
                join_part = re.split(r'\bON\b', inner, flags=re.IGNORECASE)[0]
                # Split by JOIN keywords
                join_tables = re.split(
                    r'\b(?:INNER\s+JOIN|LEFT\s+JOIN|RIGHT\s+JOIN|FULL\s+JOIN|CROSS\s+JOIN|JOIN)\b',
                    join_part, flags=re.IGNORECASE)
                for jt in join_tables:
                    jt = jt.strip()
                    if not jt:
                        continue
                    jt_parts = jt.split()
                    if not jt_parts:
                        continue
                    tbl = jt_parts[0]
                    als = None
                    if len(jt_parts) >= 3 and jt_parts[1].upper() == 'AS':
                        als = jt_parts[2]
                    elif len(jt_parts) >= 2 and jt_parts[1].upper() not in ('ON', 'USING', 'WHERE'):
                        als = jt_parts[1]
                    if als:
                        alias_to_table[als.lower()] = tbl
                    if default_table is None:
                        default_table = tbl
                continue

            # Regular table: [schema.]table [AS] alias
            parts = item.split()
            if not parts:
                continue
            table_name = parts[0]
            alias = None
            if len(parts) >= 3 and parts[1].upper() == 'AS':
                alias = parts[2]
            elif len(parts) >= 2 and parts[1].upper() not in ('ON', 'USING', 'WHERE'):
                alias = parts[1]

            if alias:
                alias_to_table[alias.lower()] = table_name
            if default_table is None:
                default_table = table_name

        # Parse SELECT columns to map output names to source tables
        result: Dict[str, str] = {}
        # Track SQL expressions for derived columns (non-simple table.column)
        derived_exprs: Dict[str, str] = {}
        # Per-column: all tables and fields referenced in each column's expression
        col_all_tables: Dict[str, List[str]] = {}
        col_all_fields: Dict[str, List[Dict[str, str]]] = {}

        # Split SELECT by comma (not inside parens)
        select_items = []
        depth = 0
        current = []
        for ch in select_part:
            if ch == '(':
                depth += 1
                current.append(ch)
            elif ch == ')':
                depth -= 1
                current.append(ch)
            elif ch == ',' and depth == 0:
                select_items.append(''.join(current).strip())
                current = []
            else:
                current.append(ch)
        if current:
            select_items.append(''.join(current).strip())

        for item in select_items:
            item = item.strip()
            if not item:
                continue

            # Determine output column name (alias or last part)
            # Handle: expr AS alias, expr alias, or just expr
            output_name = None
            source_table = None

            # Subquery: (SELECT col FROM table ...) AS alias
            if item.startswith('('):
                close = item.rfind(')')
                if close > 0:
                    subquery = item[1:close]
                    rest_part = item[close+1:].strip()
                    # Get alias
                    parts = rest_part.split()
                    if parts:
                        output_name = parts[-1] if parts[-1].upper() != 'AS' else (parts[-1] if len(parts) > 1 else None)
                        if len(parts) >= 2 and parts[0].upper() == 'AS':
                            output_name = parts[1]
                    # Extract table from subquery
                    sub_from = re.search(r'\bFROM\s+([\w.$]+)', subquery, re.IGNORECASE)
                    if sub_from:
                        source_table = sub_from.group(1)
            else:
                # SQL keywords that should never be treated as table names
                _sql_keywords = {
                    'case', 'when', 'then', 'else', 'end', 'and', 'or',
                    'not', 'in', 'is', 'null', 'between', 'like',
                    'select', 'from', 'where', 'cast', 'trim', 'coalesce',
                    'isnull', 'nvl', 'ifnull', 'nullif', 'convert',
                    'substring', 'substr', 'upper', 'lower', 'replace',
                    'concat', 'len', 'length', 'charindex', 'position',
                }

                # Check for AS alias
                as_match = re.search(r'\bAS\s+(\w+)\s*$', item, re.IGNORECASE)
                if as_match:
                    output_name = as_match.group(1)
                    expr = item[:as_match.start()].strip()
                else:
                    # Last word-like token is the alias or column name
                    # Handle function calls like DB.FUNC(args) alias
                    parts = item.split()
                    if len(parts) >= 2 and not parts[-1].endswith(')'):
                        output_name = parts[-1]
                        expr = ' '.join(parts[:-1])
                    else:
                        expr = item
                        # Extract output_name from table.column references
                        # inside function calls like trim(table.col) or
                        # complex expressions like CASE WHEN table.col ...
                        # Find the first valid table.column reference
                        tbl_col_ref = re.search(
                            r'\b([A-Za-z_]\w*)\s*\.\s*([A-Za-z_]\w*)', expr
                        )
                        if tbl_col_ref and tbl_col_ref.group(1).lower() not in _sql_keywords:
                            output_name = tbl_col_ref.group(2)
                        else:
                            # Fallback: strip parens and use what remains
                            clean = re.sub(r'\([^)]*\)', '', expr).strip()
                            if '.' in clean:
                                output_name = clean.rsplit('.', 1)[1]
                            else:
                                output_name = clean if clean.lower() not in _sql_keywords else None

                if not source_table:
                    # Determine source table from the expression.
                    # Find the first proper table.column reference, skipping
                    # SQL keywords that could appear before the dot.
                    tbl_col_match = re.search(
                        r'\b([A-Za-z_]\w*)\s*\.\s*([A-Za-z_]\w*)', expr
                    )
                    if tbl_col_match:
                        prefix = tbl_col_match.group(1).strip()
                        suffix = tbl_col_match.group(2).strip()
                        if prefix.lower() not in _sql_keywords:
                            resolved = alias_to_table.get(prefix.lower())
                            if resolved:
                                source_table = resolved
                            else:
                                # Check if prefix.suffix is a schema.table
                                # that matches a FROM table (not alias.column).
                                _full_ref = f"{prefix}.{suffix}"
                                _known_tables = set(alias_to_table.values())
                                if _full_ref in _known_tables or _full_ref.lower() in {t.lower() for t in _known_tables}:
                                    source_table = _full_ref
                                elif default_table and prefix.lower() == default_table.split('.')[0].lower():
                                    # prefix is the schema part of default_table
                                    source_table = default_table
                                else:
                                    source_table = prefix

            if output_name and source_table:
                result[output_name.lower()] = source_table
            elif output_name and default_table:
                result[output_name.lower()] = default_table

            # Extract ALL tables and fields referenced in this column's expression
            if output_name and return_expressions:
                _item_tables, _item_fields = IntegrationExpert._extract_tables_and_fields_from_expr(
                    item, alias_to_table
                )
                # Check if this is a pure constant (no real table references)
                _is_constant = not _item_tables and not _item_fields
                # Check for string/number literals only
                _stripped_expr = re.sub(r"'[^']*'", '', item)  # remove string literals
                _stripped_expr = re.sub(r'\b\d+\b', '', _stripped_expr)  # remove numbers
                _stripped_expr = re.sub(r'\bAS\s+\w+\s*$', '', _stripped_expr, flags=re.IGNORECASE)  # remove AS alias
                _has_table_ref = bool(re.search(r'\b[A-Za-z_]\w*\s*\.\s*[A-Za-z_]\w*', _stripped_expr))
                if _is_constant and not _has_table_ref:
                    # Distinguish true constants ('I', NULL, SYSDATE, 123)
                    # from bare column names (NA_BK, FILLER_1) that just
                    # lack a table prefix.  Bare columns from
                    # "SELECT col FROM table" come from the FROM table.
                    _bare_stripped = _stripped_expr.strip()
                    _bare_inner = re.sub(r'\b\w+\s*\(', '', _bare_stripped)
                    _bare_inner = _bare_inner.replace(')', '').replace(',', ' ').strip()
                    _sql_kw = {'null', 'sysdate', 'current_timestamp', 'current_date',
                               'true', 'false', 'date', 'interval', 'cast', 'trim',
                               'as', 'and', 'or', 'not', 'case', 'when', 'then',
                               'else', 'end', 'in', 'is', 'between', 'like', 'format'}
                    _remaining_ids = [t for t in re.findall(r'\b[A-Za-z_]\w*\b', _bare_inner)
                                      if t.lower() not in _sql_kw]
                    if not _remaining_ids:
                        # True constant — no column identifiers remain
                        col_all_tables[output_name.lower()] = []
                        col_all_fields[output_name.lower()] = []
                    elif default_table:
                        # Bare column reference — attribute to the FROM table
                        col_all_tables[output_name.lower()] = [default_table]
                        _fld_name = _remaining_ids[0] if _remaining_ids else output_name.lower()
                        col_all_fields[output_name.lower()] = [{"table": default_table, "field": _fld_name}]
                    else:
                        col_all_tables[output_name.lower()] = []
                        col_all_fields[output_name.lower()] = []
                else:
                    col_all_tables[output_name.lower()] = _item_tables
                    col_all_fields[output_name.lower()] = _item_fields

            # Track derived expressions: columns where the SQL expression is
            # not a simple alias.column reference (contains ||, CASE, CAST,
            # function calls, arithmetic, etc.)
            if output_name and return_expressions:
                raw_expr = item.strip()
                # Strip trailing AS alias
                _as_m = re.search(r'\bAS\s+\w+\s*$', raw_expr, re.IGNORECASE)
                if _as_m:
                    raw_expr = raw_expr[:_as_m.start()].strip()
                # A simple column is "alias.column" or just "column" with no
                # operators.  Anything else is a derivation.
                _simple = re.fullmatch(r'[\w$]+(?:\.[\w$]+)?', raw_expr)
                if not _simple and raw_expr:
                    # Resolve table aliases in the expression for readability
                    def _resolve_alias(m):
                        alias = m.group(1)
                        col = m.group(2)
                        tbl = alias_to_table.get(alias.lower(), alias)
                        return f"{tbl}.{col}"
                    resolved_expr = re.sub(
                        r'\b([A-Za-z_]\w*)\s*\.\s*([A-Za-z_]\w*)',
                        _resolve_alias, raw_expr
                    )
                    derived_exprs[output_name.lower()] = resolved_expr

        # Replace SQL_DERIVED with the primary real table from the SQL.
        # SQL_DERIVED means the column comes from an inline subquery with
        # no real FROM table (e.g., constants).  For lineage purposes, use
        # the main table from the SQL as the source.
        if "SQL_DERIVED" in result.values():
            _real_table = default_table
            if not _real_table:
                # Find first non-SQL_DERIVED table in alias_to_table
                for _at_val in alias_to_table.values():
                    if _at_val != "SQL_DERIVED":
                        _real_table = _at_val
                        break
            if _real_table:
                for _col, _tbl in result.items():
                    if _tbl == "SQL_DERIVED":
                        result[_col] = _real_table

        if return_expressions:
            return result, derived_exprs, col_all_tables, col_all_fields
        return result

    def _trace_field_lineage(
        self,
        mapping,
        target,
        target_field,
        graph_data: Dict,
        filters: Dict,
        aggregators: Dict,
        lookups: Dict,
        shortcuts: Optional[Dict[str, str]] = None,
        instance_name_override: Optional[str] = None,
        routers: Optional[Dict] = None,
        sql_overrides: Optional[Dict] = None,
        joiners: Optional[Dict] = None,
        update_strategies: Optional[Dict] = None,
        seq_gen_lookup: Optional[Dict[tuple, Dict[str, str]]] = None,
        port_type_lookup: Optional[Dict[tuple, str]] = None,
        custom_tx_port_map: Optional[Dict[tuple, list]] = None,
        inst_to_trans_map: Optional[Dict[str, Any]] = None,
        sessions: Optional[list] = None,
        mapplets: Optional[Dict] = None,
    ) -> Optional[EndToEndFieldLineage]:
        """Trace lineage for a single target field.

        Args:
            instance_name_override: When provided, use this exact instance name
                instead of searching by transformation_name. Used for Router
                mappings where multiple instances share the same definition.
            routers: Dict of router analysis results keyed by mapping.name.trans.name
            sql_overrides: Dict of SQL override info keyed by mapping.name.trans.name
            joiners: Dict of joiner analysis results keyed by mapping.name.trans.name
            update_strategies: Dict of update strategy results keyed by mapping.name.trans.name
        """
        shortcuts = shortcuts or {}
        routers = routers or {}
        sql_overrides = sql_overrides or {}
        joiners = joiners or {}
        update_strategies = update_strategies or {}
        seq_gen_lookup = seq_gen_lookup or {}
        port_type_lookup = port_type_lookup or {}
        custom_tx_port_map = custom_tx_port_map or {}
        inst_to_trans_map = inst_to_trans_map or {}
        mapplets = mapplets or {}
        from ..models.lineage_models import FieldLineageEdge

        # If caller supplied an explicit instance name (Router per-instance mode),
        # use it directly — skip the multi-strategy search.
        if instance_name_override:
            target_instance = instance_name_override
        else:
            # Find target instance - try multiple matching strategies
            target_instance = None
            target_name_lower = target.name.lower()

            # Strategy 1: Exact match on transformation_name
            for inst in mapping.target_instances:
                if inst.transformation_name.lower() == target_name_lower:
                    target_instance = inst.name
                    break

            # Strategy 2: Exact match on instance name
            if not target_instance:
                for inst in mapping.target_instances:
                    if inst.name.lower() == target_name_lower:
                        target_instance = inst.name
                        break

            # Strategy 3: Substring match (original behavior as fallback)
            if not target_instance:
                for inst in mapping.target_instances:
                    if target_name_lower in inst.transformation_name.lower():
                        target_instance = inst.name
                        break

            # Strategy 4: Shortcut resolution — the instance transformation_name
            # may be a shortcut (e.g. sc_ERRORLOG) that resolves to the target
            # definition name (e.g. ERROR_LOG1) via the shortcuts dict.
            if not target_instance and shortcuts:
                for inst in mapping.target_instances:
                    resolved = shortcuts.get(inst.transformation_name.lower())
                    if resolved and resolved.lower() == target_name_lower:
                        target_instance = inst.name
                        break

            # Strategy 5: If only one target instance, use it
            if not target_instance and len(mapping.target_instances) == 1:
                target_instance = mapping.target_instances[0].name

        if not target_instance:
            self.logger.debug(f"Could not find target instance for {target.name}")
            return None

        # Build reverse adjacency from edges (case-insensitive keys)
        edges = graph_data.get("edges", [])
        reverse_adj: Dict[str, List[Dict]] = {}
        # Also keep a mapping from lowercase key to original key for lookup
        key_case_map: Dict[str, str] = {}

        for edge in edges:
            target_key = f"{edge['target_instance']}.{edge['target_field']}"
            target_key_lower = target_key.lower()
            if target_key_lower not in reverse_adj:
                reverse_adj[target_key_lower] = []
                key_case_map[target_key_lower] = target_key
            reverse_adj[target_key_lower].append(edge)
            # Also map source keys to original case
            source_key = f"{edge['source_instance']}.{edge['source_field']}"
            key_case_map[source_key.lower()] = source_key

        # Build Source Qualifier to actual source table mapping for this mapping
        sq_to_source_table: Dict[str, str] = {}
        for inst in mapping.instances:
            ttype = inst.transformation_type.upper()
            if ttype.startswith("SOURCE QUALIFIER") or ttype.startswith("XML SOURCE QUALIFIER"):
                actual_source = self._resolve_source_qualifier_to_table(inst.name, mapping, shortcuts, sessions=sessions)
                if actual_source:
                    sq_to_source_table[inst.name.lower()] = actual_source
                    self.logger.debug(f"SQ resolution: {inst.name} -> {actual_source}")

        # Find the session that corresponds to this mapping for session-scoped
        # parameter resolution.  When a workflow has multiple sessions, each
        # session may define different values for $Param_Source_Table etc.
        _mapping_session_name = ""
        if sessions:
            for _sess in sessions:
                _sess_mapping = getattr(_sess, "mapping_name", "")
                if _sess_mapping and _sess_mapping.lower() == mapping.name.lower():
                    _mapping_session_name = _sess.name
                    break
                # Also try shortcut resolution (sc_ prefix)
                if _sess_mapping and (
                    _sess_mapping.lower() == f"sc_{mapping.name}".lower()
                    or f"sc_{_sess_mapping}".lower() == mapping.name.lower()
                ):
                    _mapping_session_name = _sess.name
                    break

        # Build SQL Override column → table mapping for multi-table SQ overrides.
        # When a SQ has a SQL Override with multiple tables in FROM, each SELECT
        # column may come from a different table.  This dict maps
        # (sq_name_lower, field_name_lower) -> fully-qualified table name.
        # Also build a parallel dict for derived column expressions:
        # (sq_name_lower, field_name_lower) -> SQL expression string
        sq_field_to_table: Dict[tuple, str] = {}
        sq_field_to_sql_expr: Dict[tuple, str] = {}
        # Per-column: all tables and fields from SQL override for source replacement
        sq_field_all_tables: Dict[tuple, List[str]] = {}
        sq_field_all_fields: Dict[tuple, List[Dict[str, str]]] = {}
        # Track which SQs have session SQL overrides
        _session_override_sqs: set = set()
        if sql_overrides:
            for _sq_key, _sq_info in sql_overrides.items():
                _sql_text = _sq_info.get("sql_query", "")
                if not _sql_text:
                    continue
                # Resolve parameters in the SQL text using session-scoped params
                _resolved_sql = _sql_text
                if self.parameter_loader:
                    if _mapping_session_name and hasattr(self.parameter_loader, "resolve_for_session"):
                        _resolved_sql = self.parameter_loader.resolve_for_session(
                            _sql_text, _mapping_session_name
                        )
                    else:
                        _resolved_sql = self.parameter_loader.resolve_placeholders(_sql_text)
                _col_map, _expr_map, _col_tables_map, _col_fields_map = self._parse_sql_column_to_table(
                    _resolved_sql, return_expressions=True
                )
                # When a session-level SQL override specifies a different source
                # table, update sq_to_source_table so that the ultimate source
                # table reflects the session-level override.  This handles both
                # "SELECT * FROM table" (_col_map has '*' key) and truly empty
                # _col_map cases.
                _sq_parts = _sq_key.split(".", 1)
                _sq_inst = _sq_parts[1] if len(_sq_parts) > 1 else _sq_parts[0]
                if _sq_info.get("source") == "session":
                    # Extract the FROM table — works for SELECT * and explicit columns
                    import re as _re
                    _from_match = _re.search(
                        r'\bFROM\s+([\w.$]+)', _resolved_sql, _re.IGNORECASE
                    )
                    if _from_match:
                        _from_table = _from_match.group(1)
                        sq_to_source_table[_sq_inst.lower()] = _from_table
                        self.logger.debug(
                            f"Session SQL override: updated SQ {_sq_inst} source to {_from_table}"
                        )
                # Only mark SQ for per-column replacement when the SQL has
                # explicit column mappings (not SELECT *).  SELECT * means
                # "all columns from the table" so there is no per-column
                # differentiation — sq_to_source_table already handles it.
                _is_select_star = set(_col_map.keys()) == {"*"} if _col_map else False
                if _sq_info.get("source") == "session" and not _is_select_star:
                    _session_override_sqs.add(_sq_inst.lower())
                if _col_map:
                    for _col_lower, _tbl in _col_map.items():
                        sq_field_to_table[(_sq_inst.lower(), _col_lower)] = _tbl
                    for _col_lower, _expr in _expr_map.items():
                        sq_field_to_sql_expr[(_sq_inst.lower(), _col_lower)] = _expr
                    # Store per-column table and field lists
                    for _col_lower, _tbls in _col_tables_map.items():
                        sq_field_all_tables[(_sq_inst.lower(), _col_lower)] = _tbls
                    for _col_lower, _flds in _col_fields_map.items():
                        sq_field_all_fields[(_sq_inst.lower(), _col_lower)] = _flds
                elif _sq_info.get("source") == "session":
                    # No top-level FROM clause (e.g., SELECT expr with subqueries).
                    # Extract ALL tables from the entire SQL as a wildcard entry
                    # keyed by '*' so any field from this SQ gets all tables.
                    _all_tbls, _all_flds = IntegrationExpert._extract_tables_and_fields_from_expr(
                        _resolved_sql, {}
                    )
                    if _all_tbls:
                        sq_field_all_tables[(_sq_inst.lower(), "*")] = _all_tbls
                        sq_field_all_fields[(_sq_inst.lower(), "*")] = _all_flds
                    # Also map SQ port names to expressions via positional matching.
                    # Informatica maps SQL SELECT columns to SQ ports by position,
                    # so port names may differ from SQL aliases (e.g., port NATURAL_KEY
                    # maps to SQL alias AGMT_NK at position 0).
                    _sq_trans_obj = mapping.get_transformation(_sq_inst)
                    if _sq_trans_obj and _expr_map:
                        _sq_port_names = [
                            f.name.lower() for f in _sq_trans_obj.fields
                            if f.port_type.upper() in ("OUTPUT", "INPUT/OUTPUT")
                        ]
                        _sql_col_names = list(_col_map.keys())
                        for _pi, _pname in enumerate(_sq_port_names):
                            if _pi < len(_sql_col_names):
                                _sql_col = _sql_col_names[_pi]
                                if _sql_col in _expr_map and (_sq_inst.lower(), _pname) not in sq_field_to_sql_expr:
                                    sq_field_to_sql_expr[(_sq_inst.lower(), _pname)] = _expr_map[_sql_col]

        # Build positional constant map: when a SQL Override SELECT column
        # is a constant (e.g., 'I', NULL, 123), the SQ output port at that
        # position receives a hard-coded value, not a source column.
        # Dict: (sq_lower, port_lower) -> constant_value_str
        sq_constant_ports: Dict[tuple, str] = {}
        if sql_overrides:
            for _sq_key, _sq_info in sql_overrides.items():
                _sql_text = _sq_info.get("sql_query", "")
                if not _sql_text:
                    continue
                _sq_parts = _sq_key.split(".", 1)
                _sq_inst = _sq_parts[1] if len(_sq_parts) > 1 else _sq_parts[0]
                _sq_trans_obj = mapping.get_transformation(_sq_inst)
                if not _sq_trans_obj:
                    continue
                _sq_port_names = [
                    f.name.lower() for f in _sq_trans_obj.fields
                    if f.port_type.upper() in ("OUTPUT", "INPUT/OUTPUT")
                ]
                # Get the per-column tables from already-parsed data
                _sql_col_keys = [k for k in sq_field_all_tables if k[0] == _sq_inst.lower()]
                if not _sql_col_keys:
                    continue
                for _pi, _pname in enumerate(_sq_port_names):
                    if _pi < len(_sql_col_keys):
                        _col_key = _sql_col_keys[_pi]
                        _col_tbls = sq_field_all_tables.get(_col_key, [])
                        _col_flds = sq_field_all_fields.get(_col_key, [])
                        # Empty tables AND empty fields = true constant
                        if not _col_tbls and not _col_flds:
                            # Retrieve the original SQL expression for display
                            _const_expr = sq_field_to_sql_expr.get((_sq_inst.lower(), _col_key[1]), "")
                            if not _const_expr:
                                _const_expr = sq_field_to_sql_expr.get((_sq_inst.lower(), _pname), "")
                            sq_constant_ports[(_sq_inst.lower(), _pname)] = _const_expr or "CONSTANT"

        # Build source field datatype lookup: "source_table.field_name" -> full_datatype
        # Also build XML group lookup: "source_table.field_name" -> group (XPath path)
        source_field_dtypes: Dict[str, str] = {}
        source_field_groups: Dict[str, str] = {}
        for src in mapping.sources:
            for fld in src.fields:
                key = f"{src.name}.{fld.name}".lower()
                source_field_dtypes[key] = fld.full_datatype
                grp = getattr(fld, "group", "")
                if grp:
                    source_field_groups[key] = grp

        # Build instance name -> transformation type lookup for Feedback #2
        inst_type_lookup: Dict[str, str] = {}
        for inst in mapping.instances:
            inst_type_lookup[inst.name.lower()] = inst.transformation_type.upper()

        # Build local variable lookup for Feedback #5: variable expansion
        # Maps (transformation_name_lower, var_name_lower) -> expression
        local_var_lookup: Dict[tuple, str] = {}
        for trans in mapping.transformations:
            for fld in trans.fields:
                if fld.is_local_variable and fld.expression:
                    local_var_lookup[(trans.name.lower(), fld.name.lower())] = fld.expression

        # Build mapping variable/parameter lookup for Feedback #5
        # Maps var_name_lower (without $$) -> description string
        mapping_var_lookup: Dict[str, str] = {}
        for mv in getattr(mapping, 'variables', []):
            var_name = mv.name.lstrip('$')
            if mv.default_value:
                mapping_var_lookup[var_name.lower()] = mv.default_value
            elif mv.is_param:
                mapping_var_lookup[var_name.lower()] = f"MAPPING PARAMETER [{mv.datatype}]"
            else:
                mapping_var_lookup[var_name.lower()] = f"MAPPING VARIABLE [{mv.datatype}]"

        # Start from target field and trace backward (use lowercase for lookup)
        target_key = f"{target_instance}.{target_field.name}"
        target_key_lower = target_key.lower()

        if target_key_lower not in reverse_adj:
            self.logger.debug(f"No incoming edges for {target_key}")
            return None

        # BFS/DFS to find all source paths
        visited = set()
        path_edges = []
        ultimate_sources = []
        lookup_tables = []
        lookup_details = []  # Feedback #4: [{name, condition, sql_override}]
        has_aggregation = False
        has_filter = False
        has_router = False
        router_condition_str = ""
        filter_condition_str = ""
        joiner_condition_str = ""
        joiner_type_str = ""
        update_strategy_str = ""
        sql_override_str = ""
        _sql_override_parts: Dict[str, str] = {}  # SQ name -> SQL override text
        transformation_chain = []
        source_qualifier_names = []  # Track SQ instance names encountered
        _sq_names_seen_lower = set()  # Case-insensitive dedup
        custom_transformation_inputs = []  # Track inputs to Custom Transformations

        # Track whether the trace has passed through a Lookup RETURN port
        # (value generated by lookup table, not the upstream SQ). When set,
        # we skip attributing the SQ SQL override to this field.
        _passed_through_complex_transform = [False]

        # Lookup input lineage parts (populated during trace and post-processing)
        lookup_input_lineage_parts: list = []

        def trace_back(current_key_lower: str, depth: int = 0):
            nonlocal has_aggregation, has_filter, has_router, router_condition_str
            nonlocal filter_condition_str, joiner_condition_str, joiner_type_str, update_strategy_str

            if current_key_lower in visited or depth > 20:
                return
            visited.add(current_key_lower)

            incoming_edges = reverse_adj.get(current_key_lower, [])

            # Filter out Normalizer self-edges (OUTPUT→INPUT with same instance
            # and field name).  The XDM graph creates these edges for normalizer
            # ports that share a name between OUTPUT and INPUT sides.  Following
            # them creates a loop that stops the trace prematurely.
            if incoming_edges:
                _cur_parts = current_key_lower.split(".", 1)
                if len(_cur_parts) == 2:
                    _cur_inst = _cur_parts[0]
                    if "NORMALIZER" in inst_type_lookup.get(_cur_inst, ""):
                        incoming_edges = [
                            e for e in incoming_edges
                            if not (e.get("source_instance", "").lower() == _cur_inst
                                    and e.get("source_field", "").lower() == _cur_parts[1])
                        ]

            # Joiner port filtering: when the current node is a joiner,
            # a MASTER port only receives data from the master pipeline
            # and a DETAIL port only from the detail pipeline.  Filter
            # incoming edges to respect this — prevents attributing a
            # field to both sides of the join.
            if incoming_edges and len(incoming_edges) > 1:
                _cur_parts_j = current_key_lower.split(".", 1)
                if len(_cur_parts_j) == 2:
                    _cur_inst_j = _cur_parts_j[0]
                    _cur_ttype_j = inst_type_lookup.get(_cur_inst_j, "").lower()
                    if "joiner" in _cur_ttype_j:
                        _cur_field_j = _cur_parts_j[1]
                        _joiner_trans = mapping.get_transformation(
                            key_case_map.get(_cur_inst_j, _cur_inst_j).split(".")[0]
                        )
                        if _joiner_trans:
                            _jfld = _joiner_trans.get_field(_cur_field_j)
                            if _jfld:
                                _jpt = _jfld.port_type.upper()
                                if "MASTER" in _jpt:
                                    # Keep only edges from master-side instances
                                    _master_edges = [
                                        e for e in incoming_edges
                                        if any("MASTER" in (
                                            _joiner_trans.get_field(e.get("target_field", "")).port_type.upper()
                                            if _joiner_trans.get_field(e.get("target_field", "")) else ""
                                        ) for _ in [1])
                                    ]
                                    if _master_edges:
                                        incoming_edges = _master_edges
                                elif "DETAIL" in _jpt:
                                    _detail_edges = [
                                        e for e in incoming_edges
                                        if any("DETAIL" in (
                                            _joiner_trans.get_field(e.get("target_field", "")).port_type.upper()
                                            if _joiner_trans.get_field(e.get("target_field", "")) else ""
                                        ) for _ in [1])
                                    ]
                                    if _detail_edges:
                                        incoming_edges = _detail_edges

            if not incoming_edges:
                # No incoming connectors — this could be a terminal source OR an
                # intermediate node (Union output, Lookup return) that we can trace deeper.
                original_key = key_case_map.get(current_key_lower, current_key_lower)
                parts = original_key.split(".", 1)
                if len(parts) != 2:
                    return
                instance_name = parts[0]
                field_name = parts[1]
                inst_lower = instance_name.lower()
                field_lower = field_name.lower()

                # --- Deep tracing: Custom Transformation (Union) pass-through ---
                # If this is an OUTPUT port of a Custom Transformation, find matching
                # INPUT ports and continue DFS to trace back to the actual source.
                ct_inputs = custom_tx_port_map.get((inst_lower, field_lower))
                if ct_inputs:
                    # Record Custom Transformation inputs before potentially returning
                    inst_obj = mapping.get_instance(instance_name)
                    if inst_obj and "custom" in inst_obj.transformation_type.lower():
                        # Build field->group lookup from the transformation definition
                        _ct_trans = inst_to_trans_map.get(inst_lower)
                        _ct_field_group = {}
                        if _ct_trans:
                            for _ctf in _ct_trans.fields:
                                if _ctf.group:
                                    _ct_field_group[_ctf.name.lower()] = _ctf.group
                        input_connectors = mapping.get_connectors_to(instance_name)
                        for conn in input_connectors:
                            entry = {
                                "input_field": conn.to_field,
                                "from_instance": conn.from_instance,
                                "from_field": conn.from_field,
                            }
                            _grp = _ct_field_group.get(conn.to_field.lower(), "")
                            if _grp:
                                entry["union_group"] = _grp
                            custom_transformation_inputs.append(entry)
                    found_any = False
                    for in_port in ct_inputs:
                        in_key = f"{inst_lower}.{in_port}"
                        in_edges = reverse_adj.get(in_key, [])
                        if in_edges:
                            found_any = True
                            # Use original case for display
                            in_port_display = key_case_map.get(in_key, in_port)
                            if "." in in_port_display:
                                in_port_display = in_port_display.split(".", 1)[1]
                            # Include group name in chain entry if available
                            _grp_label = _ct_field_group.get(in_port, "")
                            if _grp_label:
                                transformation_chain.append(
                                    f"{instance_name}: Union group [{_grp_label}] ({field_name} <- {in_port_display})"
                                )
                            else:
                                transformation_chain.append(
                                    f"{instance_name}: Union pass-through ({field_name} <- {in_port_display})"
                                )
                            trace_back(in_key, depth + 1)
                    if found_any:
                        return

                # --- Deep tracing: Expression OUTPUT → INPUT port pass-through ---
                # When an Expression transformation's OUTPUT port has no incoming
                # connectors, parse its expression to find referenced INPUT ports
                # and continue the DFS through them to reach the actual source.
                _inst_ttype_pt = inst_type_lookup.get(inst_lower, "")
                if ("EXPRESSION" in _inst_ttype_pt and
                        "SOURCE" not in _inst_ttype_pt):
                    _tx = (inst_to_trans_map.get(inst_lower) or
                           mapping.get_transformation(instance_name))
                    if _tx:
                        _fld = _tx.get_field(field_name)
                        if _fld and _fld.is_output and _fld.expression:
                            _found_ref = False
                            _seen_refs = set()

                            # --- Handle :LKP.TABLE_NAME(...) inline lookup ---
                            # When expression uses :LKP.name(args), resolve the
                            # lookup transformation and record it as the source.
                            _lkp_inline = re.match(
                                r':LKP\.(\w+)\s*\(', _fld.expression.strip()
                            )
                            if _lkp_inline:
                                _lkp_name = _lkp_inline.group(1)
                                _lkp_tx = (inst_to_trans_map.get(_lkp_name.lower()) or
                                           mapping.get_transformation(_lkp_name))
                                if _lkp_tx:
                                    _lkp_table = _lkp_tx.get_attribute("Lookup table name") or ""
                                    if _lkp_table:
                                        _passed_through_complex_transform[0] = True
                                        # Resolve $Param_ in lookup table name
                                        if "$" in _lkp_table and self.parameter_loader:
                                            _lkp_table = self.parameter_loader.resolve_placeholders(_lkp_table)
                                        ultimate_sources.append({
                                            "table": _lkp_table,
                                            "field": field_name,
                                            "datatype": _fld.datatype if _fld else "",
                                            "lookup_source": True,
                                        })
                                        lookup_tables.append(_lkp_table)
                                        _lkp_cond = _lkp_tx.get_attribute("Lookup condition") or ""
                                        lookup_details.append({
                                            "name": _lkp_name,
                                            "condition": _lkp_cond,
                                            "sql_override": _lkp_tx.get_attribute("Lookup Sql Override") or "",
                                        })
                                        transformation_chain.append(
                                            f"{instance_name}: :LKP.{_lkp_name} -> Lookup RETURN {field_name} FROM {_lkp_table}"
                                        )
                                        _found_ref = True

                                        # Also trace the lookup input args through
                                        # local variables to find INPUT port refs
                                        _lkp_args_expr = _fld.expression[_lkp_inline.end():]
                                        _lkp_args_no_str = re.sub(r"'[^']*'", "", _lkp_args_expr)
                                        for _la_m in re.finditer(r'\b([A-Za-z_]\w*)\b', _lkp_args_no_str):
                                            _la_ref = _la_m.group(1)
                                            _la_port = _tx.get_field(_la_ref)
                                            if _la_port and _la_port.is_local_variable and _la_port.expression:
                                                # Expand local variable and find INPUT ports
                                                _lv_expr = re.sub(r"'[^']*'", "", _la_port.expression)
                                                for _lv_m in re.finditer(r'\b([A-Za-z_]\w*)\b', _lv_expr):
                                                    _lv_ref = _lv_m.group(1)
                                                    _lv_port = _tx.get_field(_lv_ref)
                                                    if _lv_port and _lv_port.is_input:
                                                        _lv_key = f"{inst_lower}.{_lv_ref.lower()}"
                                                        if reverse_adj.get(_lv_key):
                                                            trace_back(_lv_key, depth + 1)
                                            elif _la_port and _la_port.is_input:
                                                _la_key = f"{inst_lower}.{_la_ref.lower()}"
                                                if reverse_adj.get(_la_key):
                                                    trace_back(_la_key, depth + 1)

                            if not _found_ref:
                                # Strip string literals before scanning for field
                                # references so that words inside quotes (e.g.
                                # 'INTEREST RATE') are not mistaken for port names.
                                _expr_no_strings = re.sub(
                                    r"'[^']*'", "", _fld.expression
                                )
                                for _ref_m in re.finditer(r'\b([A-Za-z_]\w*)\b',
                                                           _expr_no_strings):
                                    _ref = _ref_m.group(1)
                                    _ref_l = _ref.lower()
                                    if _ref_l in _seen_refs:
                                        continue
                                    _seen_refs.add(_ref_l)
                                    _ref_port = _tx.get_field(_ref)
                                    if _ref_port and _ref_port.is_input:
                                        _in_key = f"{inst_lower}.{_ref_l}"
                                        if reverse_adj.get(_in_key):
                                            _found_ref = True
                                            trace_back(_in_key, depth + 1)
                                    # Follow LOCAL VARIABLE references to find
                                    # INPUT ports they depend on.
                                    elif _ref_port and _ref_port.is_local_variable and _ref_port.expression:
                                        _lv_expr = re.sub(r"'[^']*'", "", _ref_port.expression)
                                        for _lv_m in re.finditer(r'\b([A-Za-z_]\w*)\b', _lv_expr):
                                            _lv_ref = _lv_m.group(1)
                                            _lv_l = _lv_ref.lower()
                                            if _lv_l in _seen_refs:
                                                continue
                                            _seen_refs.add(_lv_l)
                                            _lv_port = _tx.get_field(_lv_ref)
                                            if _lv_port and _lv_port.is_input:
                                                _lv_key = f"{inst_lower}.{_lv_l}"
                                                if reverse_adj.get(_lv_key):
                                                    _found_ref = True
                                                    trace_back(_lv_key, depth + 1)
                            if _found_ref:
                                return

                # --- Deep tracing: Aggregator OUTPUT-only port ---
                # When an Aggregator's output-only port (e.g. ROW_ID1 with
                # EXPRESSION="MAX(ROW_ID)") has no incoming connectors, parse
                # the aggregate expression to find the referenced input port
                # and continue tracing upstream through it.
                if "AGGREGAT" in _inst_ttype_pt:
                    _agg_tx = (inst_to_trans_map.get(inst_lower) or
                               mapping.get_transformation(instance_name))
                    if _agg_tx:
                        _agg_fld = _agg_tx.get_field(field_name)
                        if _agg_fld and _agg_fld.is_output and _agg_fld.expression:
                            _agg_found = False
                            _agg_seen = set()
                            _agg_expr_no_strings = re.sub(
                                r"'[^']*'", "", _agg_fld.expression
                            )
                            for _agg_m in re.finditer(r'\b([A-Za-z_]\w*)\b',
                                                       _agg_expr_no_strings):
                                _agg_ref = _agg_m.group(1)
                                _agg_ref_l = _agg_ref.lower()
                                if _agg_ref_l in _agg_seen:
                                    continue
                                _agg_seen.add(_agg_ref_l)
                                _agg_ref_port = _agg_tx.get_field(_agg_ref)
                                if _agg_ref_port and _agg_ref_port.is_input:
                                    _agg_in_key = f"{inst_lower}.{_agg_ref_l}"
                                    if reverse_adj.get(_agg_in_key):
                                        _agg_found = True
                                        transformation_chain.append(
                                            f"{instance_name}: {_agg_fld.expression}"
                                        )
                                        trace_back(_agg_in_key, depth + 1)
                            if _agg_found:
                                return

                # --- Deep tracing: Normalizer OUTPUT-only port ---
                # Normalizer takes N input fields and produces M output fields
                # (unpivoting/normalizing data).  OUTPUT ports have no backward
                # connectors in the graph.  Use REF_SOURCE_FIELD to trace only
                # the input ports that belong to the same normalized group as
                # the output field being traced.
                if "NORMALIZER" in _inst_ttype_pt:
                    _nrm_tx = inst_to_trans_map.get(inst_lower)
                    _nrm_in_conns = mapping.get_connectors_to(instance_name)
                    if _nrm_in_conns:
                        _nrm_found = False
                        _nrm_seen_keys = set()
                        # Find which input port names to trace via ref_source_field
                        _nrm_allowed_inputs = None
                        if _nrm_tx:
                            _nrm_out_fld = _nrm_tx.get_field(field_name)
                            if _nrm_out_fld and _nrm_out_fld.ref_source_field:
                                _nrm_ref = _nrm_out_fld.ref_source_field.lower()
                                _nrm_allowed_inputs = set()
                                for _nrm_f in _nrm_tx.fields:
                                    if (_nrm_f.is_input
                                            and _nrm_f.ref_source_field
                                            and _nrm_f.ref_source_field.lower() == _nrm_ref):
                                        _nrm_allowed_inputs.add(_nrm_f.name.lower())
                        for _nrm_c in _nrm_in_conns:
                            # If we resolved the allowed input set, skip ports not in it
                            if (_nrm_allowed_inputs is not None
                                    and _nrm_c.to_field.lower() not in _nrm_allowed_inputs):
                                continue
                            _nrm_key = f"{_nrm_c.from_instance}.{_nrm_c.from_field}".lower()
                            if _nrm_key not in visited and _nrm_key not in _nrm_seen_keys:
                                _nrm_seen_keys.add(_nrm_key)
                                _nrm_found = True
                                # Capture SQL override when the Normalizer's upstream
                                # connector comes from a Source Qualifier.  The normal
                                # edge-processing code at line ~2644 never sees this
                                # because the deep-trace bypasses the regular edge loop.
                                _nrm_from_inst = _nrm_c.from_instance
                                _nrm_from_type = inst_type_lookup.get(_nrm_from_inst.lower(), "")
                                if "SOURCE QUALIFIER" in _nrm_from_type:
                                    _nrm_sq_key = f"{mapping.name}.{_nrm_from_inst}"
                                    for _nsk in sql_overrides:
                                        if _nsk.lower() == _nrm_sq_key.lower():
                                            _sql_override_parts[_nrm_from_inst] = sql_overrides[_nsk].get("sql_query", "")
                                            break
                                    if _nrm_from_inst.lower() not in _sq_names_seen_lower:
                                        source_qualifier_names.append(_nrm_from_inst)
                                        _sq_names_seen_lower.add(_nrm_from_inst.lower())
                                trace_back(_nrm_key, depth + 1)
                        if _nrm_found:
                            return

                # --- Original terminal handling ---
                # Record Custom Transformation inputs (if not already handled above)
                if not ct_inputs:
                    inst_obj = mapping.get_instance(instance_name)
                    if inst_obj and "custom" in inst_obj.transformation_type.lower():
                        # Build field->group lookup from the transformation definition
                        _ct_trans2 = inst_to_trans_map.get(inst_lower)
                        _ct_field_group2 = {}
                        if _ct_trans2:
                            for _ctf2 in _ct_trans2.fields:
                                if _ctf2.group:
                                    _ct_field_group2[_ctf2.name.lower()] = _ctf2.group
                        input_connectors = mapping.get_connectors_to(instance_name)
                        for conn in input_connectors:
                            entry = {
                                "input_field": conn.to_field,
                                "from_instance": conn.from_instance,
                                "from_field": conn.from_field,
                            }
                            _grp2 = _ct_field_group2.get(conn.to_field.lower(), "")
                            if _grp2:
                                entry["union_group"] = _grp2
                            custom_transformation_inputs.append(entry)

                # --- Deep tracing: Router OUTPUT port ---
                # Router output ports are terminal (no incoming connectors).
                # Map the output port to the corresponding INPUT port by
                # stripping the numeric suffix, and record the Router group condition.
                inst_ttype = inst_type_lookup.get(inst_lower, "")
                if "ROUTER" in inst_ttype:
                    _rtr_trans = inst_to_trans_map.get(inst_lower)
                    if _rtr_trans:
                        _rtr_fld = _rtr_trans.get_field(field_name)
                        if _rtr_fld and _rtr_fld.group:
                            _fld_group_name = _rtr_fld.group
                            # Find the group definition to get the condition
                            for _rg in _rtr_trans.groups:
                                if _rg.name == _fld_group_name and _rg.group_type.upper() != "INPUT":
                                    has_router = True
                                    if _rg.is_default:
                                        router_condition_str = f"{_rg.name}: DEFAULT"
                                    elif _rg.expression:
                                        router_condition_str = f"{_rg.name}: {_rg.expression}"
                                    break
                            # Map to INPUT port: strip numeric suffix
                            _input_name = re.sub(r'\d+$', '', field_name)
                            _input_key = f"{inst_lower}.{_input_name.lower()}"
                            if reverse_adj.get(_input_key):
                                transformation_chain.append(
                                    f"{instance_name}: Router [{_fld_group_name}] {field_name}"
                                )
                                trace_back(_input_key, depth + 1)
                                return

                # --- Deep tracing: Lookup RETURN/OUTPUT port ---
                # When a Lookup's RETURN or LOOKUP/OUTPUT port is terminal,
                # trace through the lookup's INPUT ports to find the real
                # physical source. Record the lookup table as context.
                if "LOOKUP" in inst_ttype:
                    _lkp_trans = inst_to_trans_map.get(inst_lower)
                    if _lkp_trans:
                        _lkp_fld = _lkp_trans.get_field(field_name)
                        _is_return = (_lkp_fld and (
                            "RETURN" in (_lkp_fld.port_type or "").upper()
                            or ("LOOKUP" in (_lkp_fld.port_type or "").upper()
                                and "OUTPUT" in (_lkp_fld.port_type or "").upper()
                                and "INPUT" not in (_lkp_fld.port_type or "").upper())
                        ))
                        if _is_return:
                            # This is a lookup-generated value. The data comes from the
                            # LOOKUP TABLE, not from upstream. Record the lookup table
                            # as the ultimate source and capture the lookup condition.
                            _passed_through_complex_transform[0] = True
                            _lkp_table = _lkp_trans.get_attribute("Lookup table name") or ""
                            _lkp_condition = _lkp_trans.get_attribute("Lookup condition") or ""
                            _lkp_sql_ovr = _lkp_trans.get_attribute("Lookup Sql Override") or ""
                            ultimate_sources.append({
                                "table": _lkp_table or instance_name,
                                "field": field_name,
                                "datatype": _lkp_fld.datatype if _lkp_fld else "",
                                "lookup_source": True,
                            })
                            lookup_tables.append(_lkp_table or instance_name)
                            lookup_details.append({
                                "name": instance_name,
                                "condition": _lkp_condition,
                                "sql_override": _lkp_sql_ovr,
                            })
                            transformation_chain.append(
                                f"{instance_name}: Lookup RETURN {field_name}"
                            )
                            return

                # --- Deep tracing: Mapplet output port ---
                # Trace inside the mapplet to find the actual transformation
                # and expression that produces this output port.
                if "MAPPLET" in inst_ttype or "CUSTOM" in inst_ttype:
                    _mapplet_inst = mapping.get_instance(instance_name)
                    if _mapplet_inst and "mapplet" in _mapplet_inst.transformation_type.lower():
                        # Look up the mapplet definition, resolving shortcuts
                        _mplt_trans_name = _mapplet_inst.transformation_name.lower()
                        _mplt_info = mapplets.get(_mplt_trans_name)
                        if not _mplt_info:
                            # Try resolving shortcut prefixes (sc_, shortcut_to_)
                            _resolved_mplt = shortcuts.get(_mplt_trans_name, "")
                            if _resolved_mplt:
                                _mplt_info = mapplets.get(_resolved_mplt.lower())
                            if not _mplt_info and _mplt_trans_name.startswith("sc_"):
                                _mplt_info = mapplets.get(_mplt_trans_name[3:])
                            if not _mplt_info and _mplt_trans_name.startswith("shortcut_to_"):
                                _mplt_info = mapplets.get(_mplt_trans_name[12:])

                        _handled_by_mapplet = False
                        if _mplt_info:
                            # Trace backwards through all internal connectors
                            # from the output port to the input port, recording
                            # each internal transformation in the chain.
                            _input_ports = _mplt_info.transformations.get("input", {})
                            # Also collect input ports from Input Transformation instances
                            for _inp_key, _inp_type in _mplt_info.transformation_types.items():
                                if "input" in _inp_type.lower() and "transformation" in _inp_type.lower():
                                    _inp_exprs = _mplt_info.transformations.get(_inp_key, {})
                                    _input_ports.update(_inp_exprs)

                            # Find the Output Transformation instance name
                            _out_trans_name = "output"
                            for _tn, _tt in _mplt_info.transformation_types.items():
                                if "output" in _tt.lower() and "transformation" in _tt.lower():
                                    _out_trans_name = _tn
                                    break

                            # Walk the internal connector chain backwards
                            _cur_inst = _out_trans_name
                            _cur_field = field_name.lower()
                            _internal_chain = []  # [(inst, field, type, expr)]
                            _reached_input = False
                            _input_field = None
                            _hit_lookup = False
                            _visited_internal = set()

                            for _depth_cap in range(15):
                                _conn_key = (_cur_inst.lower(), _cur_field)
                                if _conn_key in _visited_internal:
                                    break
                                _visited_internal.add(_conn_key)
                                _prev = _mplt_info.connectors.get(_conn_key)
                                if not _prev:
                                    # Try case-insensitive lookup
                                    for _ck, _cv in _mplt_info.connectors.items():
                                        if (isinstance(_ck, tuple) and len(_ck) == 2
                                                and _ck[0].lower() == _cur_inst.lower()
                                                and _ck[1].lower() == _cur_field):
                                            _prev = _cv
                                            break
                                    if not _prev:
                                        break
                                _prev_inst, _prev_field = _prev
                                _prev_inst_lower = _prev_inst.lower()
                                _prev_type = _mplt_info.transformation_types.get(_prev_inst_lower, "")
                                _prev_exprs = _mplt_info.transformations.get(_prev_inst_lower, {})
                                _prev_expr = _prev_exprs.get(_prev_field.lower(), "")

                                if "input" in _prev_type.lower() and "transformation" in _prev_type.lower():
                                    # Reached the Input Transformation — this connects to outer
                                    _reached_input = True
                                    _input_field = _prev_field
                                    break

                                _internal_chain.append((_prev_inst, _prev_field, _prev_type, _prev_expr))

                                if "lookup" in _prev_type.lower():
                                    _hit_lookup = True
                                    break

                                _cur_inst = _prev_inst
                                _cur_field = _prev_field.lower()

                            # Build transformation chain entries for internal transforms
                            if _internal_chain:
                                _chain_parts = []
                                for _ci, _cf, _ct, _ce in reversed(_internal_chain):
                                    if "expression" in _ct.lower():
                                        if _ce and _ce.lower().strip() != _cf.lower():
                                            _chain_parts.append(f"{instance_name}.{_ci}: {_ce}")
                                        else:
                                            _chain_parts.append(f"{instance_name}.{_ci}: {_cf} (pass-through)")
                                    elif "custom" in _ct.lower():
                                        _chain_parts.append(f"{instance_name}.{_ci}: Custom Transform -> {_cf}")
                                    elif "lookup" in _ct.lower():
                                        pass  # handled separately below
                                    else:
                                        _chain_parts.append(f"{instance_name}.{_ci}: {_cf}")

                                if _chain_parts:
                                    transformation_chain.extend(_chain_parts)

                            # Handle the terminal: either reached input or hit lookup
                            if _hit_lookup and _internal_chain:
                                _lkp_inst, _lkp_field, _, _ = _internal_chain[-1]
                                _lkp_inst_lower = _lkp_inst.lower()
                                _lkp_table = _mplt_info.lookup_tables.get(_lkp_inst_lower, "")
                                _lkp_cond = _mplt_info.lookup_conditions.get(_lkp_inst_lower, "")
                                transformation_chain.append(
                                    f"{instance_name}.{_lkp_inst}: Lookup RETURN {_lkp_field}"
                                    + (f" FROM {_lkp_table}" if _lkp_table else "")
                                )
                                ultimate_sources.append({
                                    "table": _lkp_table or f"{_lkp_inst} (Lookup)",
                                    "field": _lkp_field,
                                    "datatype": "",
                                })
                                if _lkp_table:
                                    lookup_tables.append(_lkp_table)
                                lookup_details.append({
                                    "name": _lkp_inst,
                                    "condition": _lkp_cond,
                                    "sql_override": "",
                                })
                                if _lkp_cond and _mplt_info.connectors:
                                    _mplt_lkp_lineage = []
                                    for _eq in re.split(r'\bAND\b|\bOR\b', _lkp_cond, flags=re.IGNORECASE):
                                        _eq = _eq.strip()
                                        if '=' not in _eq:
                                            continue
                                        _sides = _eq.split('=', 1)
                                        _lhs = _sides[0].strip()
                                        _rhs = _sides[1].strip()
                                        _rhs_conn = _mplt_info.connectors.get((_lkp_inst_lower, _rhs.lower()))
                                        _lhs_conn = _mplt_info.connectors.get((_lkp_inst_lower, _lhs.lower()))
                                        if _rhs_conn:
                                            _mplt_lkp_lineage.append(
                                                f"{_lkp_inst}.{_lhs} = {_rhs} <- {_rhs_conn[0]}.{_rhs_conn[1]}"
                                            )
                                        elif _lhs_conn:
                                            _mplt_lkp_lineage.append(
                                                f"{_lkp_inst}.{_rhs} = {_lhs} <- {_lhs_conn[0]}.{_lhs_conn[1]}"
                                            )
                                    if _mplt_lkp_lineage:
                                        lookup_input_lineage_parts.extend(_mplt_lkp_lineage)
                                _handled_by_mapplet = True

                            elif _reached_input and _input_field:
                                # Trace through outer connectors
                                _mapplet_in_conns = mapping.get_connectors_to(instance_name)
                                for _mc in _mapplet_in_conns:
                                    if _mc.to_field.lower() == _input_field.lower():
                                        _mc_key = f"{_mc.from_instance}.{_mc.from_field}".lower()
                                        if _mc_key not in visited:
                                            trace_back(_mc_key, depth + 1)
                                            _handled_by_mapplet = True
                                            break

                            elif _internal_chain and not _reached_input:
                                _last_inst, _last_field, _last_type, _last_expr = _internal_chain[-1]
                                if "custom" in _last_type.lower():
                                    # Custom Transform terminal: the internal
                                    # chain reached a Custom Transformation
                                    # output port but can't trace further
                                    # inside the CT (it's a black box).  Trace
                                    # through ALL outer mapplet input connectors.
                                    _mapplet_in_conns = mapping.get_connectors_to(instance_name)
                                    if _mapplet_in_conns:
                                        for _mc in _mapplet_in_conns:
                                            _mc_key = f"{_mc.from_instance}.{_mc.from_field}".lower()
                                            if _mc_key not in visited:
                                                trace_back(_mc_key, depth + 1)
                                                _handled_by_mapplet = True
                                elif _last_expr and _last_expr.lower().strip() not in _input_ports:
                                    # Check if the expression references any
                                    # input port (e.g. TO_CHAR(in_SRC_ID)
                                    # references in_SRC_ID).  If so, the value
                                    # depends on mapplet inputs — NOT hard-coded.
                                    _expr_refs_input = any(
                                        _ip in _last_expr.lower()
                                        for _ip in _input_ports
                                    )
                                    # Also check if inputs come from a Custom
                                    # Transform (e.g. address validator).
                                    _has_ct_input = False
                                    if not _expr_refs_input:
                                        _last_inst_lower = _last_inst.lower()
                                        for (_ti, _tf), (_fi, _ff) in _mplt_info.connectors.items():
                                            if _ti.lower() == _last_inst_lower:
                                                _fi_type = _mplt_info.transformation_types.get(_fi.lower(), "")
                                                if "custom" in _fi_type.lower():
                                                    _has_ct_input = True
                                                    break
                                    if _expr_refs_input or _has_ct_input:
                                        # Trace through outer connectors
                                        _mapplet_in_conns = mapping.get_connectors_to(instance_name)
                                        if _mapplet_in_conns:
                                            for _mc in _mapplet_in_conns:
                                                _mc_key = f"{_mc.from_instance}.{_mc.from_field}".lower()
                                                if _mc_key not in visited:
                                                    trace_back(_mc_key, depth + 1)
                                                    _handled_by_mapplet = True
                                    else:
                                        # Internal chain ended at a generated value
                                        ultimate_sources.append({
                                            "table": "HARD CODED VALUE",
                                            "field": f"{_last_inst}.{_last_field}",
                                            "datatype": "",
                                            "generated_expression": _last_expr,
                                        })
                                        _handled_by_mapplet = True

                        # Fallback: trace through outer connectors if mapplet
                        # internal tracing didn't handle it
                        if not _handled_by_mapplet:
                            _mapplet_in_conns = mapping.get_connectors_to(instance_name)
                            if _mapplet_in_conns:
                                _found_mapplet_src = False
                                for _mc in _mapplet_in_conns:
                                    _mc_key = f"{_mc.from_instance}.{_mc.from_field}".lower()
                                    if _mc_key not in visited:
                                        _found_mapplet_src = True
                                        transformation_chain.append(
                                            f"{instance_name}: Mapplet pass-through"
                                        )
                                        trace_back(_mc_key, depth + 1)
                                if _found_mapplet_src:
                                    return

                        if _handled_by_mapplet:
                            return

                # Feedback #2: If this is an Expression or Sequence Generator,
                # it's not a real data source — label as HARD CODED VALUE.
                is_expression = "EXPRESSION" in inst_ttype and "SOURCE" not in inst_ttype
                is_seq_gen = "SEQUENCE" in inst_ttype

                if is_expression or is_seq_gen:
                    # Before labeling as HARD CODED VALUE, check if the
                    # expression's output port derives from an input port
                    # that has upstream connectors.  This handles shortcut
                    # expressions where get_transformation() returns None.
                    _traced_through_expr = False
                    if is_expression:
                        # Try to find the expression text for this port
                        gen_expr = ""
                        trans_obj = mapping.get_transformation(instance_name)
                        # Shortcut: if not found locally, try document-level
                        if not trans_obj and shortcuts:
                            _sc_resolved = shortcuts.get(inst_lower, "")
                            if _sc_resolved:
                                for _doc_trans in mapping.transformations:
                                    if _doc_trans.name.lower() == _sc_resolved.lower():
                                        trans_obj = _doc_trans
                                        break
                            # Also check document-level transformations
                            if not trans_obj and hasattr(mapping, '_parent_doc'):
                                for _dt in getattr(mapping._parent_doc, 'transformations', []):
                                    if _dt.name.lower() == (_sc_resolved or instance_name).lower():
                                        trans_obj = _dt
                                        break
                        if trans_obj:
                            fld_obj = trans_obj.get_field(field_name)
                            if fld_obj and fld_obj.expression:
                                gen_expr = fld_obj.expression.strip()
                        # Determine which input port this output derives from.
                        # Strategy: (a) parse the expression for input port refs,
                        # (b) use naming convention o_X -> X, (c) INPUT/OUTPUT port
                        # with same name as field.
                        _input_connectors = mapping.get_connectors_to(instance_name)
                        _input_fields = {c.to_field.lower(): c for c in _input_connectors} if _input_connectors else {}
                        _candidate_input = None
                        if gen_expr and _input_fields:
                            # (a) Check if expression references an input port
                            for _ipf in _input_fields:
                                if _ipf in gen_expr.lower():
                                    _candidate_input = _ipf
                                    break
                        if not _candidate_input and _input_fields:
                            # (b) Naming convention: o_X -> X, or OUT_X -> X
                            _field_lower = field_name.lower()
                            for _prefix in ("o_", "out_"):
                                if _field_lower.startswith(_prefix):
                                    _stripped = _field_lower[len(_prefix):]
                                    if _stripped in _input_fields:
                                        _candidate_input = _stripped
                                        break
                        if not _candidate_input and field_name.lower() in _input_fields:
                            # (c) INPUT/OUTPUT port with same name
                            _candidate_input = field_name.lower()
                        if _candidate_input and _candidate_input in _input_fields:
                            _src_conn = _input_fields[_candidate_input]
                            _upstream_key = f"{_src_conn.from_instance}.{_src_conn.from_field}".lower()
                            if _upstream_key not in visited:
                                if gen_expr:
                                    transformation_chain.append(
                                        f"{instance_name}: {gen_expr}"
                                    )
                                trace_back(_upstream_key, depth + 1)
                                _traced_through_expr = True
                    if not _traced_through_expr:
                        # Truly a generated/hardcoded value
                        gen_expr = ""
                        trans_obj = mapping.get_transformation(instance_name)
                        if trans_obj:
                            fld_obj = trans_obj.get_field(field_name)
                            if fld_obj and fld_obj.expression:
                                gen_expr = fld_obj.expression.strip()
                        ultimate_sources.append({
                            "table": "HARD CODED VALUE",
                            "field": field_name,
                            "datatype": "",
                            "generated_expression": gen_expr,
                        })
                        self.logger.debug(
                            f"Expression/SeqGen ultimate source: {instance_name}.{field_name} -> HARD CODED VALUE"
                        )
                else:
                    # Check if this SQ port receives a constant from SQL Override
                    _const_val = sq_constant_ports.get((inst_lower, field_name.lower()))
                    if _const_val:
                        ultimate_sources.append({
                            "table": "HARD CODED VALUE",
                            "field": field_name,
                            "datatype": "",
                            "generated_expression": _const_val,
                        })
                        if inst_lower not in _sq_names_seen_lower:
                            source_qualifier_names.append(instance_name)
                            _sq_names_seen_lower.add(inst_lower)
                        return

                    # Check if this is a Source Qualifier and resolve to actual table
                    actual_table = sq_to_source_table.get(inst_lower)
                    # SQL Override multi-table: if the SQL maps this field to a
                    # specific table, use that instead of the default SQ table.
                    _sql_table = sq_field_to_table.get((inst_lower, field_name.lower()))
                    if not _sql_table:
                        # Fallback: positional matching between SQ output ports
                        # and SQL Override SELECT columns.  In Informatica, the
                        # SQL Override columns map to SQ ports by position, so
                        # the SQ port name may differ from the SQL column alias.
                        _sq_trans = mapping.get_transformation(instance_name)
                        if _sq_trans:
                            _sq_out_fields = [
                                f.name.lower() for f in _sq_trans.fields
                                if f.port_type.upper() in ("OUTPUT", "INPUT/OUTPUT")
                            ]
                            # Collect SQL column names for this SQ in insertion order
                            _sql_cols = [
                                col for (sq, col) in sq_field_to_table
                                if sq == inst_lower
                            ]
                            if field_name.lower() in _sq_out_fields and _sql_cols:
                                _pos = _sq_out_fields.index(field_name.lower())
                                if _pos < len(_sql_cols):
                                    _sql_table = sq_field_to_table.get(
                                        (inst_lower, _sql_cols[_pos])
                                    )
                    if _sql_table:
                        actual_table = _sql_table
                    if actual_table:
                        # Feedback #1: Look up source field datatype
                        # actual_table may now be qualified (owner.table), so try
                        # both the full name and just the table part
                        src_key = f"{actual_table}.{field_name}".lower()
                        src_dt = source_field_dtypes.get(src_key, "")
                        if not src_dt and "." in actual_table:
                            bare_table = actual_table.rsplit(".", 1)[-1]
                            src_key_bare = f"{bare_table}.{field_name}".lower()
                            src_dt = source_field_dtypes.get(src_key_bare, "")
                            if src_dt:
                                src_key = src_key_bare
                        # Feedback #3: Enrich with XML group (XPath)
                        xml_group = source_field_groups.get(src_key, "")
                        display_field = f"{xml_group}/{field_name}" if xml_group else field_name
                        # Check for SQL derivation expression
                        _sql_deriv = sq_field_to_sql_expr.get((inst_lower, field_name.lower()), "")
                        src_entry = {
                            "table": actual_table,
                            "field": display_field,
                            "datatype": src_dt,
                            "source_qualifier": instance_name,
                        }
                        if _sql_deriv:
                            src_entry["sql_derivation"] = _sql_deriv
                        ultimate_sources.append(src_entry)
                        if inst_lower not in _sq_names_seen_lower:
                            source_qualifier_names.append(instance_name)
                            _sq_names_seen_lower.add(inst_lower)
                        self.logger.debug(f"Resolved ultimate source: {instance_name} -> {actual_table}")
                    else:
                        # Resolve source instance name to qualified table name
                        resolved_table = self._qualify_source_table(instance_name, mapping, sessions=sessions, shortcuts=shortcuts)
                        # Feedback #1: Try to look up datatype from source definitions
                        # Try both the resolved name and original instance name
                        src_key = f"{resolved_table}.{field_name}".lower()
                        src_dt = source_field_dtypes.get(src_key, "")
                        if not src_dt:
                            src_key_orig = f"{instance_name}.{field_name}".lower()
                            src_dt = source_field_dtypes.get(src_key_orig, "")
                        # Also try with just the table name (without owner prefix)
                        if not src_dt and "." in resolved_table:
                            bare_table = resolved_table.rsplit(".", 1)[-1]
                            src_key_bare = f"{bare_table}.{field_name}".lower()
                            src_dt = source_field_dtypes.get(src_key_bare, "")
                        # Feedback #3: Enrich with XML group (XPath)
                        xml_group = source_field_groups.get(src_key, "")
                        if not xml_group:
                            xml_group = source_field_groups.get(f"{instance_name}.{field_name}".lower(), "")
                        display_field = f"{xml_group}/{field_name}" if xml_group else field_name
                        ultimate_sources.append({
                            "table": resolved_table,
                            "field": display_field,
                            "datatype": src_dt,
                        })
                return

            # Expression explainer for edge-level explanations
            explainer = InformaticaExpressionExplainer()

            # Extract instance info for the current node (needed for SQL Override intercept)
            _cur_parts = current_key_lower.split(".", 1)
            _cur_inst_name = key_case_map.get(current_key_lower, current_key_lower).split(".", 1)[0] if "." in key_case_map.get(current_key_lower, current_key_lower) else _cur_parts[0]
            _cur_field_name = key_case_map.get(current_key_lower, current_key_lower).split(".", 1)[1] if "." in key_case_map.get(current_key_lower, current_key_lower) else (_cur_parts[1] if len(_cur_parts) > 1 else "")
            _cur_inst_lower = _cur_parts[0]
            _cur_inst_ttype = inst_type_lookup.get(_cur_inst_lower, "")

            for edge in incoming_edges:
                # Check if field name changed across a Source Qualifier -> Expression edge.
                # A field rename (e.g., CUR_ETL_LOAD_TS -> ROW_INS_TS) means the SQ
                # provides the data under a different name.  Resolve through the SQ
                # to the actual source table so the ultimate_source reflects the real
                # origin, while still recording the SQ in source_qualifier_names.
                source_type = edge.get("source_type", "")
                target_type = edge.get("target_type", "")
                if "expression" in target_type.lower() and "source qualifier" in source_type.lower():
                    src_field = edge.get("source_field", "").lower()
                    tgt_field = edge.get("target_field", "").lower()
                    if src_field and tgt_field and src_field != tgt_field:
                        sq_inst_name = edge['source_instance']
                        # SQL Override multi-table: check field-level mapping first
                        _sql_tbl = sq_field_to_table.get((sq_inst_name.lower(), src_field))
                        if _sql_tbl:
                            source_table_name = _sql_tbl
                        else:
                            # Resolve the SQ to its actual source table
                            actual_table = sq_to_source_table.get(sq_inst_name.lower())
                            source_table_name = actual_table if actual_table else self._qualify_source_table(sq_inst_name, mapping, sessions=sessions, shortcuts=shortcuts)
                        # Feedback #1: Look up source field datatype
                        _rename_src_key = f"{source_table_name}.{edge['source_field']}".lower()
                        src_dt = source_field_dtypes.get(_rename_src_key, "")
                        if not src_dt and "." in source_table_name:
                            _bare = source_table_name.rsplit(".", 1)[-1]
                            src_dt = source_field_dtypes.get(f"{_bare}.{edge['source_field']}".lower(), "")
                        # Feedback #3: XML group (XPath)
                        xml_group = source_field_groups.get(_rename_src_key, "")
                        _rename_display = (
                            f"{xml_group}/{edge['source_field']}" if xml_group else edge["source_field"]
                        )
                        _rename_src_entry = {
                            "table": source_table_name,
                            "field": _rename_display,
                            "datatype": src_dt,
                            "source_qualifier": sq_inst_name,
                        }
                        _rename_deriv = sq_field_to_sql_expr.get((sq_inst_name.lower(), src_field), "")
                        if _rename_deriv:
                            _rename_src_entry["sql_derivation"] = _rename_deriv
                        ultimate_sources.append(_rename_src_entry)
                        if sq_inst_name.lower() not in _sq_names_seen_lower:
                            source_qualifier_names.append(sq_inst_name)
                            _sq_names_seen_lower.add(sq_inst_name.lower())
                        # Still record the edge for intermediate_steps
                        edge_obj = FieldLineageEdge(
                            source_instance=edge["source_instance"],
                            source_field=edge["source_field"],
                            source_type=edge["source_type"],
                            target_instance=edge["target_instance"],
                            target_field=edge["target_field"],
                            target_type=edge["target_type"],
                            expression=edge.get("expression", ""),
                            expression_explanation=f"Field renamed from {edge['source_field']} to {edge['target_field']}",
                        )
                        path_edges.append(edge_obj)
                        if edge.get("expression"):
                            transformation_chain.append(f"{edge['source_instance']}: {edge['expression']}")
                        # Capture SQL Override from this SQ — collect all SQ overrides
                        # so multi-source mappings show all SQL overrides.
                        if sq_inst_name not in _sql_override_parts:
                            sq_key = f"{mapping.name}.{sq_inst_name}"
                            for sk in sql_overrides:
                                if sk.lower() == sq_key.lower():
                                    _sql_override_parts[sq_inst_name] = sql_overrides[sk].get("sql_query", "")
                                    break
                        continue

                # Generate explanation for the expression
                expression = edge.get("expression", "")
                if expression:
                    edge_explanation = explainer.explain(expression)
                else:
                    edge_explanation = "Direct mapping"

                edge_obj = FieldLineageEdge(
                    source_instance=edge["source_instance"],
                    source_field=edge["source_field"],
                    source_type=edge["source_type"],
                    target_instance=edge["target_instance"],
                    target_field=edge["target_field"],
                    target_type=edge["target_type"],
                    expression=expression,
                    expression_explanation=edge_explanation,
                )
                path_edges.append(edge_obj)

                # Check for operators (use lowercase for lookups)
                key = f"{mapping.name}.{edge['source_instance']}".lower()
                if key in aggregators or key.lower() in {k.lower() for k in aggregators}:
                    has_aggregation = True

                # Check for filter and capture condition
                # Check both source and target side of the edge since the
                # filter can appear on either end depending on trace direction.
                target_key = f"{mapping.name}.{edge['target_instance']}".lower()
                for fk in filters:
                    fk_lower = fk.lower()
                    if fk_lower == key or fk_lower == target_key:
                        has_filter = True
                        if not filter_condition_str:
                            filter_condition_str = filters[fk].get("condition", "")
                        break

                # Check for lookup — Feedback #4: also capture name, condition, sql override
                # Only record the lookup as a contributing source if the field
                # is a RETURN/LOOKUP/OUTPUT port (i.e., generated by the lookup),
                # not a pass-through INPUT/OUTPUT port.
                for lk in lookups:
                    if lk.lower() == key:
                        lk_info = lookups[lk]
                        _src_field_port = port_type_lookup.get(
                            (edge["source_instance"].lower(), edge["source_field"].lower()), ""
                        )
                        _is_lkp_generated = (
                            "RETURN" in _src_field_port.upper()
                            or ("LOOKUP" in _src_field_port.upper()
                                and "OUTPUT" in _src_field_port.upper()
                                and "INPUT" not in _src_field_port.upper())
                        )
                        if _is_lkp_generated:
                            _passed_through_complex_transform[0] = True
                            lookup_tables.append(lk_info.get("table_name", edge["source_instance"]))
                            lookup_details.append({
                                "name": lk_info.get("name", edge["source_instance"]),
                                "condition": lk_info.get("condition", ""),
                                "sql_override": lk_info.get("sql_override", "") or "",
                            })
                        break

                # Check for joiner and capture condition/type
                for jk in joiners:
                    if jk.lower() == key:
                        if not joiner_condition_str:
                            joiner_condition_str = joiners[jk].get("join_condition", "")
                            joiner_type_str = joiners[jk].get("join_type", "")
                        break

                # Check for update strategy and capture expression
                for uk in update_strategies:
                    if uk.lower() == key:
                        if not update_strategy_str:
                            update_strategy_str = update_strategies[uk].get("expression", "")
                            transformation_chain.append(
                                f"{edge['source_instance']}: Update Strategy [{update_strategy_str}]"
                            )
                        break

                # Check for router - use suffix-based group matching
                # Only determine the condition once; the DFS may encounter the
                # same router via an internal edge (no suffix) which would
                # incorrectly overwrite a previously matched suffix condition.
                for rk in routers:
                    if rk.lower() == key:
                        has_router = True
                        if router_condition_str:
                            break  # Already matched — don't overwrite
                        router_info = routers[rk]
                        matched_group = False
                        router_trans = mapping.get_transformation(edge['source_instance'])
                        if router_trans and router_trans.groups:
                            # Strategy 1: Use the field's group attribute directly.
                            # Check both source_field and target_field (for internal
                            # Router edges where INPUT maps to OUTPUT).
                            for _check_field_name in (edge.get("target_field", ""),
                                                       edge.get("source_field", "")):
                                if matched_group:
                                    break
                                _rf = router_trans.get_field(_check_field_name)
                                if _rf and _rf.group:
                                    for _rg in router_trans.groups:
                                        if (_rg.name == _rf.group
                                                and _rg.group_type.upper() != "INPUT"):
                                            if _rg.is_default:
                                                router_condition_str = f"{_rg.name}: DEFAULT"
                                            elif _rg.expression:
                                                router_condition_str = f"{_rg.name}: {_rg.expression}"
                                            matched_group = True
                                            break
                            # Strategy 2: Suffix-based matching as fallback
                            if not matched_group:
                                source_field = edge.get("source_field", "")
                                suffix_match = re.search(r'(\d+)$', source_field)
                                if suffix_match:
                                    suffix_num = int(suffix_match.group(1))
                                    output_groups_ordered = [
                                        g for g in router_trans.groups
                                        if g.group_type.upper() != "INPUT"
                                    ]
                                    group_idx = suffix_num - 1
                                    if 0 <= group_idx < len(output_groups_ordered):
                                        grp = output_groups_ordered[group_idx]
                                        cond = grp.expression or ""
                                        grp_name = grp.name or f"Group {suffix_num}"
                                        if grp.is_default:
                                            router_condition_str = f"{grp_name}: DEFAULT"
                                        else:
                                            router_condition_str = f"{grp_name}: {cond}"
                                        matched_group = True
                        # Fallback: use output_groups from operator analysis
                        if not matched_group:
                            output_groups = router_info.get("output_groups", router_info.get("groups", []))
                            if output_groups:
                                for grp in output_groups:
                                    if grp.get("condition") and not grp.get("is_default", False):
                                        router_condition_str = f"{grp.get('name', '')}: {grp['condition']}"
                                        break
                                if not router_condition_str and output_groups:
                                    router_condition_str = f"{output_groups[0].get('name', '')}: {output_groups[0].get('condition', 'DEFAULT')}"
                        break

                # Check for SQL override (Source Qualifier) and track SQ name
                # Only attribute SQL override if the trace hasn't passed through
                # complex transforms (Lookup RETURN, Filter, Router) — those mean
                # the field value is derived downstream, not directly from the SQ SQL.
                source_type = edge.get("source_type", "")
                if "source qualifier" in source_type.lower():
                    sq_inst_name = edge['source_instance']
                    if sq_inst_name.lower() not in _sq_names_seen_lower:
                        source_qualifier_names.append(sq_inst_name)
                        _sq_names_seen_lower.add(sq_inst_name.lower())
                    if sq_inst_name not in _sql_override_parts:
                        sq_key = f"{mapping.name}.{sq_inst_name}"
                        for sk in sql_overrides:
                            if sk.lower() == sq_key.lower():
                                _sql_override_parts[sq_inst_name] = sql_overrides[sk].get("sql_query", "")
                                break

                # Add to transformation chain and detect inline lookup references
                if edge.get("expression"):
                    transformation_chain.append(f"{edge['source_instance']}: {edge['expression']}")
                    # Scan for :LKP.<name> references in expression text
                    for _lkp_m in re.finditer(r':LKP\.(\w+)', edge['expression'], re.IGNORECASE):
                        _lkp_name = _lkp_m.group(1)
                        _lkp_key = f"{mapping.name}.{_lkp_name}"
                        _resolved_lkp = False
                        for _lk_key, _lk_val in lookups.items():
                            if _lk_key.lower() == _lkp_key.lower():
                                lookup_tables.append(_lk_val.get("table_name", _lkp_name))
                                # Feedback #4: Also capture inline lookup details
                                lookup_details.append({
                                    "name": _lk_val.get("name", _lkp_name),
                                    "condition": _lk_val.get("condition", ""),
                                    "sql_override": _lk_val.get("sql_override", "") or "",
                                })
                                _resolved_lkp = True
                                break
                        if not _resolved_lkp:
                            lookup_tables.append(_lkp_name)

                # Continue tracing (use lowercase key)
                source_key_lower = f"{edge['source_instance']}.{edge['source_field']}".lower()

                # Handle self-referencing edges: when Source instance and Source
                # Qualifier share the same name (e.g., sc_SHAW_TRAN_ILN_CDC is
                # both SOURCE and SQ), connectors create edges like
                #   sc_X.field (Source Def) -> sc_X.field (SQ)
                # where source_key == current_key.  Recursing would hit the
                # visited set and return without reaching terminal handling.
                # Instead, treat this as a terminal and resolve to the actual
                # source table directly.
                if source_key_lower == current_key_lower:
                    _self_inst = edge['source_instance']
                    _self_field = edge['source_field']
                    _self_inst_lower = _self_inst.lower()
                    # SQL Override multi-table: check field-level mapping first
                    _self_table = sq_field_to_table.get((_self_inst_lower, _self_field.lower()))
                    # Try SQ resolution
                    if not _self_table:
                        _self_table = sq_to_source_table.get(_self_inst_lower)
                    if not _self_table:
                        _self_table = self._qualify_source_table(
                            _self_inst, mapping, sessions=sessions, shortcuts=shortcuts
                        )
                    _self_src_key = f"{_self_table}.{_self_field}".lower()
                    _self_dt = source_field_dtypes.get(_self_src_key, "")
                    if not _self_dt and "." in _self_table:
                        _bare = _self_table.rsplit(".", 1)[-1]
                        _self_dt = source_field_dtypes.get(
                            f"{_bare}.{_self_field}".lower(), ""
                        )
                    xml_grp = source_field_groups.get(_self_src_key, "")
                    _disp_field = (
                        f"{xml_grp}/{_self_field}" if xml_grp else _self_field
                    )
                    _self_src_entry = {
                        "table": _self_table,
                        "field": _disp_field,
                        "datatype": _self_dt,
                        "source_qualifier": _self_inst,
                    }
                    _self_deriv = sq_field_to_sql_expr.get((_self_inst_lower, _self_field.lower()), "")
                    if _self_deriv:
                        _self_src_entry["sql_derivation"] = _self_deriv
                    ultimate_sources.append(_self_src_entry)
                    if _self_inst_lower not in _sq_names_seen_lower:
                        source_qualifier_names.append(_self_inst)
                        _sq_names_seen_lower.add(_self_inst_lower)
                    # Capture SQL override from this SQ if applicable
                    if _self_inst not in _sql_override_parts:
                        _sq_key = f"{mapping.name}.{_self_inst}"
                        for _sk in sql_overrides:
                            if _sk.lower() == _sq_key.lower():
                                _sql_override_parts[_self_inst] = sql_overrides[_sk].get("sql_query", "")
                                break
                    continue

                # SQL Override intercept: when the current node is a Source
                # Qualifier with a SQL Override, the positional connector from
                # Source Definition is based on the *original* source table
                # columns, not the SQL Override SELECT columns.  Resolve via
                # sq_field_to_table (positional matching) instead.
                _edge_src_type = edge.get("source_type", "")
                if ("source qualifier" in _cur_inst_ttype.lower()
                        and "source" in _edge_src_type.lower()
                        and "qualifier" not in _edge_src_type.lower()):
                    # Check if this SQ port receives a constant from SQL Override
                    _const_val2 = sq_constant_ports.get((_cur_inst_lower, _cur_field_name.lower()))
                    if _const_val2:
                        ultimate_sources.append({
                            "table": "HARD CODED VALUE",
                            "field": _cur_field_name,
                            "datatype": "",
                            "generated_expression": _const_val2,
                        })
                        if _cur_inst_lower not in _sq_names_seen_lower:
                            source_qualifier_names.append(_cur_inst_name)
                            _sq_names_seen_lower.add(_cur_inst_lower)
                        if _cur_inst_name not in _sql_override_parts:
                            _sq_key_c = f"{mapping.name}.{_cur_inst_name}"
                            for _sk_c in sql_overrides:
                                if _sk_c.lower() == _sq_key_c.lower():
                                    _sql_override_parts[_cur_inst_name] = sql_overrides[_sk_c].get("sql_query", "")
                                    break
                        continue
                    # Check direct field lookup first
                    _sql_tbl2 = sq_field_to_table.get((_cur_inst_lower, _cur_field_name.lower()))
                    if not _sql_tbl2:
                        # Positional fallback: match SQ port to SQL column
                        _sq_trans2 = mapping.get_transformation(_cur_inst_name)
                        if _sq_trans2:
                            _sq_out2 = [
                                f.name.lower() for f in _sq_trans2.fields
                                if f.port_type.upper() in ("OUTPUT", "INPUT/OUTPUT")
                            ]
                            _sql_cols2 = [
                                col for (sq, col) in sq_field_to_table
                                if sq == _cur_inst_lower
                            ]
                            if _cur_field_name.lower() in _sq_out2 and _sql_cols2:
                                _pos2 = _sq_out2.index(_cur_field_name.lower())
                                if _pos2 < len(_sql_cols2):
                                    _sql_tbl2 = sq_field_to_table.get(
                                        (_cur_inst_lower, _sql_cols2[_pos2])
                                    )
                    if _sql_tbl2:
                        # Resolved via SQL Override — use this table
                        _sql_src_key = f"{_sql_tbl2}.{_cur_field_name}".lower()
                        _sql_dt = source_field_dtypes.get(_sql_src_key, "")
                        if not _sql_dt and "." in _sql_tbl2:
                            _bare2 = _sql_tbl2.rsplit(".", 1)[-1]
                            _sql_dt = source_field_dtypes.get(
                                f"{_bare2}.{_cur_field_name}".lower(), ""
                            )
                        xml_grp2 = source_field_groups.get(_sql_src_key, "")
                        _disp2 = f"{xml_grp2}/{_cur_field_name}" if xml_grp2 else _cur_field_name
                        ultimate_sources.append({
                            "table": _sql_tbl2,
                            "field": _disp2,
                            "datatype": _sql_dt,
                            "source_qualifier": _cur_inst_name,
                        })
                        if _cur_inst_lower not in _sq_names_seen_lower:
                            source_qualifier_names.append(_cur_inst_name)
                            _sq_names_seen_lower.add(_cur_inst_lower)
                        continue

                # Handle cross-hop visited collision for dual-role shortcuts:
                # When an sc_ instance is used as both SOURCE and TARGET (same
                # shortcut name), the source_key at the terminal hop matches
                # the initial target_key already in visited.  The field name
                # is identical on both sides (passthrough), so the DFS would
                # silently stop without recording any ultimate_source.
                # Detect: source_key is already in visited AND edge source_type
                # is "Source Definition" (we've reached the actual source table).
                # Resolve to the physical source table directly — same logic as
                # the self-referencing handler above.
                _edge_src_type_dr = edge.get("source_type", "").lower()
                if (source_key_lower in visited
                        and source_key_lower != current_key_lower
                        and "source" in _edge_src_type_dr
                        and "qualifier" not in _edge_src_type_dr):
                    _dr_inst = edge['source_instance']
                    _dr_field = edge['source_field']
                    _dr_inst_lower = _dr_inst.lower()
                    _dr_table = sq_field_to_table.get((_dr_inst_lower, _dr_field.lower()))
                    if not _dr_table:
                        _dr_table = sq_to_source_table.get(_dr_inst_lower)
                    if not _dr_table:
                        _dr_table = self._qualify_source_table(
                            _dr_inst, mapping, sessions=sessions, shortcuts=shortcuts
                        )
                    _dr_src_key = f"{_dr_table}.{_dr_field}".lower()
                    _dr_dt = source_field_dtypes.get(_dr_src_key, "")
                    if not _dr_dt and "." in _dr_table:
                        _bare_dr = _dr_table.rsplit(".", 1)[-1]
                        _dr_dt = source_field_dtypes.get(
                            f"{_bare_dr}.{_dr_field}".lower(), ""
                        )
                    xml_grp_dr = source_field_groups.get(_dr_src_key, "")
                    _disp_dr = f"{xml_grp_dr}/{_dr_field}" if xml_grp_dr else _dr_field
                    _dr_src_entry = {
                        "table": _dr_table,
                        "field": _disp_dr,
                        "datatype": _dr_dt,
                        "source_qualifier": _dr_inst,
                    }
                    _dr_deriv = sq_field_to_sql_expr.get((_dr_inst_lower, _dr_field.lower()), "")
                    if _dr_deriv:
                        _dr_src_entry["sql_derivation"] = _dr_deriv
                    ultimate_sources.append(_dr_src_entry)
                    if _dr_inst_lower not in _sq_names_seen_lower:
                        source_qualifier_names.append(_dr_inst)
                        _sq_names_seen_lower.add(_dr_inst_lower)
                    if _dr_inst not in _sql_override_parts:
                        _sq_key_dr = f"{mapping.name}.{_dr_inst}"
                        for _sk_dr in sql_overrides:
                            if _sk_dr.lower() == _sq_key_dr.lower():
                                _sql_override_parts[_dr_inst] = sql_overrides[_sk_dr].get("sql_query", "")
                                break
                    continue

                trace_back(source_key_lower, depth + 1)

        trace_back(target_key_lower)

        # For SQs without a SQL Override, check for Source Filter and
        # synthesize a SQL override: SELECT * FROM <table> WHERE <filter>
        for _sq_name in source_qualifier_names:
            if _sq_name in _sql_override_parts:
                continue
            _sq_trans = mapping.get_transformation(_sq_name)
            if _sq_trans:
                _src_filter = _sq_trans.get_attribute("Source Filter")
                if _src_filter and _src_filter.strip():
                    _sq_source = sq_to_source_table.get(_sq_name.lower(), "")
                    if _sq_source:
                        _sql_override_parts[_sq_name] = (
                            f"SELECT * FROM {_sq_source} WHERE {_src_filter.strip()}"
                        )

        # Build sql_override_str from collected parts
        if _sql_override_parts:
            if len(_sql_override_parts) == 1:
                sql_override_str = next(iter(_sql_override_parts.values()))
            else:
                # Multiple SQ overrides — format with SQ name headers
                _parts = []
                for _sq_name, _sq_sql in _sql_override_parts.items():
                    _parts.append(f"[{_sq_name}] {_sq_sql}")
                sql_override_str = "\n".join(_parts)

        if not ultimate_sources:
            return None

        # ------------------------------------------------------------------
        # ------------------------------------------------------------------
        # Post-processing: Ensure all source fields referenced in expressions
        # appear in ultimate_sources (Validator Feedback: unique fields in
        # transformation logic must appear in Ultimate Source Field).
        # The DFS visited-set can prevent some fields from being traced to
        # their terminal when multiple Union groups share intermediate nodes.
        # ------------------------------------------------------------------
        _existing_src_fields = set()
        for src in ultimate_sources:
            _sf = src.get("field", "")
            # Strip table prefix and XML group prefix for comparison
            _bare = _sf.rsplit("/", 1)[-1] if "/" in _sf else _sf
            _existing_src_fields.add(_bare.lower())
        # Also exclude field names that appear as intermediate ports in the
        # traced dataflow — these are already accounted for and should not be
        # re-added as separate source entries from a different table.
        # Only exclude fields that are NOT from the ultimate sources themselves
        # (to preserve HARD CODED VALUE entries with datatypes).
        _ult_src_field_names = set()
        for _us in ultimate_sources:
            _usf = _us.get("field", "")
            _usf_bare = _usf.rsplit("/", 1)[-1] if "/" in _usf else _usf
            _ult_src_field_names.add(_usf_bare.lower())
        for _pe in path_edges:
            if _pe.source_field.lower() not in _ult_src_field_names:
                _existing_src_fields.add(_pe.source_field.lower())
            if _pe.target_field.lower() not in _ult_src_field_names:
                _existing_src_fields.add(_pe.target_field.lower())

        # Build mapping from source definition names (mapping.sources) to
        # the instance names used by the DFS in ultimate_sources.
        # E.g. SHAW_MAST_ILN_STG (source def) -> sc_SHAW_MAST_ILN_STG (instance)
        _src_def_to_instance: Dict[str, str] = {}
        for _si in mapping.source_instances:
            _si_type = getattr(_si, "transformation_type", "")
            if "source qualifier" in str(_si_type).lower():
                continue
            # Match source defs to instances: the instance name often contains
            # the source def name (e.g. sc_SHAW_MAST_ILN_STG contains SHAW_MAST_ILN_STG)
            _si_lower = _si.name.lower()
            for _sd in mapping.sources:
                _sd_lower = _sd.name.lower()
                if _sd_lower in _si_lower and _sd_lower not in _src_def_to_instance:
                    _src_def_to_instance[_sd_lower] = _si.name

        # Build a reverse lookup: field_name_lower -> (table, datatype)
        # from source_field_dtypes, using instance names (as used in the DFS).
        _src_field_reverse: Dict[str, tuple] = {}
        for _sfd_key, _sfd_dt in source_field_dtypes.items():
            _sfd_parts = _sfd_key.split(".", 1)
            if len(_sfd_parts) == 2:
                _sfd_tbl, _sfd_fld = _sfd_parts
                _sfd_fld_l = _sfd_fld.lower()
                # Resolve to qualified table name (e.g. D2_EDW_STG_01_E0.SHAW_MAST_ILN_STG)
                _instance_name = _src_def_to_instance.get(_sfd_tbl.lower(), _sfd_tbl)
                _resolved_tbl = self._qualify_source_table(_instance_name, mapping, sessions=sessions, shortcuts=shortcuts)
                if _sfd_fld_l not in _src_field_reverse:
                    _src_field_reverse[_sfd_fld_l] = (_resolved_tbl, _sfd_dt)

        # Informatica built-in functions and keywords to exclude
        _FUNC_KEYWORDS = {
            "iif", "decode", "isnull", "not", "null", "and", "or", "cast", "as",
            "to_date", "to_char", "to_integer", "to_decimal", "to_float",
            "ltrim", "rtrim", "trim", "upper", "lower", "substr", "instr",
            "lpad", "rpad", "length", "concat", "replace", "replacestr",
            "abs", "round", "trunc", "mod", "power", "ceil", "floor",
            "add_to_date", "date_diff", "get_date_part", "sysdate",
            "is_date", "is_number", "is_spaces", "is_integer",
            "lookup", "return", "in", "true", "false", "else", "then",
            "when", "case", "end", "like", "between", "from", "where",
            "select", "varchar", "decimal", "integer", "timestamp", "date",
            "format", "yyyy", "mm", "dd", "hh24", "hh", "mi", "ss",
            "us", "interval", "hour", "second", "built", "variable",
            "sequence", "generator", "di",
        }

        for entry in transformation_chain:
            colon_idx = entry.find(": ")
            if colon_idx <= 0:
                continue
            expr = entry[colon_idx + 2:]
            # Skip non-expression entries
            if any(marker in expr for marker in (
                "Union pass-through", "Union group [", "Mapplet pass-through",
                "Lookup RETURN", "Router [",
            )):
                continue
            # Extract field-like tokens (strip single-quoted strings first
            # so hard-coded values like 'INTEREST RATE' don't match source fields)
            _expr_no_strings = re.sub(r"'[^']*'", "", expr)
            for _fm in re.finditer(r'\b([A-Za-z_]\w*)\b', _expr_no_strings):
                _token = _fm.group(1)
                _token_l = _token.lower()
                if _token_l in _FUNC_KEYWORDS:
                    continue
                if _token_l in _existing_src_fields:
                    continue
                # Check if it's a known source field
                if _token_l in _src_field_reverse:
                    _tbl, _dt = _src_field_reverse[_token_l]
                    ultimate_sources.append({
                        "table": _tbl,
                        "field": _token,
                        "datatype": _dt,
                    })
                    _existing_src_fields.add(_token_l)

        # ------------------------------------------------------------------
        # Post-processing: When a session SQL override exists, replace mapping
        # source definition names with the real tables from the SQL override.
        # This runs AFTER the "ensure all source fields" block to avoid
        # re-addition of old source names.
        # ------------------------------------------------------------------
        if _session_override_sqs and sq_field_all_tables:
            _new_sources = []
            _override_src_defs = set()
            for _sqn in source_qualifier_names:
                if _sqn.lower() in _session_override_sqs:
                    _sq_inputs = mapping.get_connectors_to(_sqn)
                    if _sq_inputs:
                        for _sqc in _sq_inputs:
                            _override_src_defs.add(_sqc.from_instance.lower())
                            if shortcuts:
                                _resolved = shortcuts.get(_sqc.from_instance.lower(), "")
                                if _resolved:
                                    _override_src_defs.add(_resolved.lower())
            for src in ultimate_sources:
                _tbl = src.get("table", "")
                _fld = src.get("field", "")
                if _tbl == "HARD CODED VALUE":
                    _new_sources.append(src)
                    continue
                _tbl_bare = _tbl.rsplit(".", 1)[-1].lower() if "." in _tbl else _tbl.lower()
                _is_from_override_sq = (
                    _tbl_bare in _override_src_defs
                    or _tbl.lower() in _override_src_defs
                    or _tbl.lower() in {v.lower() for v in sq_to_source_table.values()}
                )
                if not _is_from_override_sq:
                    _sq_check = src.get("source_qualifier", "")
                    _is_from_override_sq = _sq_check and _sq_check.lower() in _session_override_sqs
                if not _is_from_override_sq:
                    _new_sources.append(src)
                    continue
                _sq_name = src.get("source_qualifier", "")
                if not _sq_name:
                    for _sqn in source_qualifier_names:
                        if _sqn.lower() in _session_override_sqs:
                            _sq_name = _sqn
                            break
                if not _sq_name or _sq_name.lower() not in _session_override_sqs:
                    _new_sources.append(src)
                    continue
                _sq_lower = _sq_name.lower()
                _fld_lower = _fld.rsplit(".", 1)[-1].lower() if "." in _fld else _fld.lower()
                _col_tbls = sq_field_all_tables.get((_sq_lower, _fld_lower))
                _col_flds = sq_field_all_fields.get((_sq_lower, _fld_lower))
                if _col_tbls is None:
                    _sq_trans = mapping.get_transformation(_sq_name)
                    if _sq_trans:
                        _sq_ports = [
                            f.name.lower() for f in _sq_trans.fields
                            if f.port_type.upper() in ("OUTPUT", "INPUT/OUTPUT")
                        ]
                        if _fld_lower in _sq_ports:
                            _pos = _sq_ports.index(_fld_lower)
                            _sql_cols = [k for k in sq_field_all_tables if k[0] == _sq_lower]
                            if _pos < len(_sql_cols):
                                _col_tbls = sq_field_all_tables.get(_sql_cols[_pos])
                                _col_flds = sq_field_all_fields.get(_sql_cols[_pos])
                if _col_tbls is None:
                    _col_tbls = sq_field_all_tables.get((_sq_lower, "*"))
                    _col_flds = sq_field_all_fields.get((_sq_lower, "*"))
                if _col_tbls is not None:
                    if not _col_tbls:
                        _new_sources.append({
                            "table": "HARD CODED VALUE",
                            "field": _fld,
                            "datatype": src.get("datatype", ""),
                        })
                    elif _col_flds:
                        for _cf in _col_flds:
                            _new_sources.append({
                                "table": _cf["table"],
                                "field": f"{_cf['table']}.{_cf['field']}",
                                "datatype": "",
                            })
                        _fld_tables = {_cf["table"] for _cf in _col_flds}
                        for _ct in _col_tbls:
                            if _ct not in _fld_tables:
                                _new_sources.append({
                                    "table": _ct,
                                    "field": f"{_ct}.(SQL Override)",
                                    "datatype": "",
                                })
                    else:
                        for _ct in _col_tbls:
                            _new_sources.append({
                                "table": _ct,
                                "field": f"{_ct}.(SQL Override)",
                                "datatype": "",
                            })
                else:
                    _new_sources.append(src)
            _seen_src = set()
            _deduped = []
            for _s in _new_sources:
                _key = (_s.get("table", ""), _s.get("field", ""))
                if _key not in _seen_src:
                    _seen_src.add(_key)
                    _deduped.append(_s)
            ultimate_sources = _deduped

        # ------------------------------------------------------------------
        # Post-processing: Backtrack lookup condition INPUT fields.
        # For each lookup, identify the INPUT ports used in the lookup
        # condition and trace them back to their source.
        # (lookup_input_lineage_parts may already have entries from
        #  mapplet-internal lookups populated during trace_back.)
        # ------------------------------------------------------------------
        _seen_lkp_names: set = set()
        for _ld in lookup_details:
            _lkp_inst_name = _ld.get("name", "")
            _lkp_condition = _ld.get("condition", "")
            if not _lkp_inst_name or not _lkp_condition:
                continue
            # Deduplicate: skip if we've already processed this lookup
            _lkp_key = (_lkp_inst_name.lower(), _lkp_condition.lower())
            if _lkp_key in _seen_lkp_names:
                continue
            _seen_lkp_names.add(_lkp_key)

            _lkp_trans = inst_to_trans_map.get(_lkp_inst_name.lower())
            if not _lkp_trans:
                _lkp_trans = mapping.get_transformation(_lkp_inst_name)
            if not _lkp_trans:
                continue

            # Build set of INPUT port names (including INPUT/OUTPUT pass-through)
            # that can serve as condition input fields.  Exclude RETURN and
            # pure LOOKUP/OUTPUT ports (those are lookup-table columns).
            _lkp_input_ports = {}
            _lkp_return_or_lkp_ports = set()
            for _lf in _lkp_trans.fields:
                _pt = (_lf.port_type or "").upper()
                if "RETURN" in _pt:
                    _lkp_return_or_lkp_ports.add(_lf.name.lower())
                elif "INPUT" in _pt:
                    _lkp_input_ports[_lf.name.lower()] = _lf.name

            # Parse condition: "LKP_FIELD = INPUT_FIELD AND ..."
            # The INPUT_FIELD is the right-hand side of each comparison.
            _cond_input_fields = []
            for _eq_part in re.split(r'\bAND\b|\bOR\b', _lkp_condition, flags=re.IGNORECASE):
                _eq_part = _eq_part.strip()
                if '=' not in _eq_part:
                    continue
                _sides = _eq_part.split('=', 1)
                if len(_sides) != 2:
                    continue
                _lhs = _sides[0].strip()
                _rhs = _sides[1].strip()
                # The INPUT field is the one that's an INPUT port on the lookup
                # (not a RETURN port or lookup table field)
                if _rhs.lower() in _lkp_input_ports:
                    _cond_input_fields.append((_lhs.strip(), _lkp_input_ports[_rhs.lower()]))
                elif _lhs.lower() in _lkp_input_ports:
                    _cond_input_fields.append((_rhs.strip(), _lkp_input_ports[_lhs.lower()]))

            if not _cond_input_fields:
                continue

            # Trace each condition input field back through connectors,
            # following pass-through (INPUT/OUTPUT) ports to the true origin.
            _lkp_conns = mapping.get_connectors_to(_lkp_inst_name)
            _conn_map = {}  # to_field_lower -> (from_instance, from_field)
            for _lc in _lkp_conns:
                _conn_map[_lc.to_field.lower()] = (_lc.from_instance, _lc.from_field)

            for _lkp_field, _input_port_name in _cond_input_fields:
                _conn = _conn_map.get(_input_port_name.lower())
                if _conn:
                    _from_inst, _from_field = _conn
                    # Trace through pass-through transformations to the true origin
                    _via_parts = []
                    _visited = {_lkp_inst_name.lower()}
                    for _ in range(10):  # cap depth to avoid cycles
                        _fi_lower = _from_inst.lower()
                        if _fi_lower in _visited:
                            break
                        _visited.add(_fi_lower)
                        # Look up the upstream transformation
                        _up_trans = inst_to_trans_map.get(_fi_lower)
                        if not _up_trans:
                            _up_trans = mapping.get_transformation(_from_inst)
                        if not _up_trans:
                            break
                        # Check if _from_field is an INPUT/OUTPUT pass-through port
                        _is_passthrough = False
                        for _uf in _up_trans.fields:
                            if _uf.name.lower() == _from_field.lower():
                                _pt = (_uf.port_type or "").upper()
                                if "INPUT" in _pt and "OUTPUT" in _pt and "LOOKUP" not in _pt and "RETURN" not in _pt:
                                    _is_passthrough = True
                                break
                        if not _is_passthrough:
                            break
                        # It's a pass-through — trace one more hop back
                        _up_conns = mapping.get_connectors_to(_from_inst)
                        _up_conn_map = {}
                        for _uc in _up_conns:
                            _up_conn_map[_uc.to_field.lower()] = (_uc.from_instance, _uc.from_field)
                        _next = _up_conn_map.get(_from_field.lower())
                        if not _next:
                            break
                        _via_parts.append(_from_inst)
                        _from_inst, _from_field = _next

                    _src_desc = f"{_from_inst}.{_from_field}"
                    if _via_parts:
                        _src_desc += f" (via {', '.join(_via_parts)})"
                    # Annotate with SQL derivation if the input port traces to a
                    # derived column in the SQ SQL Override (e.g., AGMT_NK =
                    # SHAW_MAST.BK || 'Ð' || SHAW_MAST.CUSLN).
                    # Check using multiple field names: the original input port
                    # name, the final traced field name, and each intermediate
                    # field name encountered during the backward trace.
                    _lkp_input_deriv = ""
                    _lkp_deriv_col = ""
                    # Collect all (instance, field) pairs from the trace chain
                    # so we can check each against sq_field_to_sql_expr.
                    _trace_pairs = [(_from_inst.lower(), _from_field.lower())]
                    # Rebuild intermediate pairs: walk the chain again to get
                    # the field name at each via-instance.
                    _tmp_inst, _tmp_field = _conn  # start from lookup's direct input
                    _tmp_visited = {_lkp_inst_name.lower()}
                    for _vp in _via_parts:
                        _trace_pairs.append((_tmp_inst.lower(), _tmp_field.lower()))
                        _tmp_visited.add(_tmp_inst.lower())
                        _up_conns2 = mapping.get_connectors_to(_tmp_inst)
                        _up_map2 = {uc.to_field.lower(): (uc.from_instance, uc.from_field) for uc in _up_conns2}
                        _nxt2 = _up_map2.get(_tmp_field.lower())
                        if _nxt2:
                            _tmp_inst, _tmp_field = _nxt2
                        else:
                            break
                    # Also check the input port name itself against all SQ instances
                    for _vi in _via_parts:
                        _trace_pairs.append((_vi.lower(), _input_port_name.lower()))
                    _trace_pairs.append((_from_inst.lower(), _input_port_name.lower()))
                    for _tp_inst, _tp_field in _trace_pairs:
                        _tp_deriv = sq_field_to_sql_expr.get((_tp_inst, _tp_field), "")
                        if _tp_deriv:
                            _lkp_input_deriv = _tp_deriv
                            _lkp_deriv_col = _tp_field.upper()
                            break
                    _lineage_entry = f"{_lkp_inst_name}.{_lkp_field} = {_input_port_name} <- {_src_desc}"
                    if _lkp_input_deriv:
                        _deriv_label = _lkp_deriv_col or _input_port_name
                        _lineage_entry += f" [SQL: {_deriv_label} = {_lkp_input_deriv}]"
                    lookup_input_lineage_parts.append(_lineage_entry)
                else:
                    # Fallback: check if this lookup is called via :LKP.NAME(...)
                    # inline from an expression and resolve args from there.
                    _inline_resolved = False
                    _lkp_input_port_names = list(_lkp_input_ports.values())
                    for _expr_trans in mapping.transformations:
                        for _expr_fld in _expr_trans.fields:
                            if not _expr_fld.expression:
                                continue
                            _lkp_call = re.match(
                                r':LKP\.(\w+)\s*\(([^)]*)\)',
                                _expr_fld.expression.strip(),
                            )
                            if not _lkp_call or _lkp_call.group(1).lower() != _lkp_inst_name.lower():
                                continue
                            # Parse the inline arguments
                            _args_str = _lkp_call.group(2)
                            _args = [a.strip() for a in _args_str.split(',')]
                            # Map args positionally to INPUT ports
                            _port_idx = _lkp_input_port_names.index(_input_port_name) if _input_port_name in _lkp_input_port_names else -1
                            if _port_idx >= 0 and _port_idx < len(_args):
                                _arg = _args[_port_idx]
                                if _arg.startswith("'") and _arg.endswith("'"):
                                    # Hard-coded string literal
                                    _src_desc = f"{_arg} (hard coded)"
                                else:
                                    # Check if it's a local variable in the expression transformation
                                    _lv_fld = _expr_trans.get_field(_arg)
                                    if _lv_fld and _lv_fld.is_local_variable and _lv_fld.expression:
                                        _lv_expr_clean = re.sub(r"'[^']*'", "", _lv_fld.expression)
                                        # Find INPUT port refs in the local var expression
                                        _lv_sources = []
                                        for _lv_m in re.finditer(r'\b([A-Za-z_]\w*)\b', _lv_expr_clean):
                                            _lv_ref = _lv_m.group(1)
                                            _lv_port = _expr_trans.get_field(_lv_ref)
                                            if _lv_port and _lv_port.is_input:
                                                # Trace this input port back through connectors
                                                _lv_conn_key = f"{_expr_trans.name}.{_lv_ref}".lower()
                                                _lv_edge = reverse_adj.get(_lv_conn_key, [])
                                                if _lv_edge:
                                                    _lv_src = f"{_lv_edge[0]['source_instance']}.{_lv_edge[0]['source_field']}"
                                                    if _lv_src not in _lv_sources:
                                                        _lv_sources.append(_lv_src)
                                        if _lv_sources:
                                            _src_desc = f"{_arg} = {_lv_fld.expression[:80]} <- {', '.join(_lv_sources)}"
                                        else:
                                            _src_desc = f"{_arg} (local var: {_lv_fld.expression[:60]})"
                                    elif _lv_fld and _lv_fld.is_input:
                                        _src_desc = f"{_expr_trans.name}.{_arg}"
                                    else:
                                        _src_desc = f"{_arg} (from {_expr_trans.name})"
                                lookup_input_lineage_parts.append(
                                    f"{_lkp_inst_name}.{_lkp_field} = {_input_port_name} <- {_src_desc}"
                                )
                                _inline_resolved = True
                            break
                        if _inline_resolved:
                            break
                    if not _inline_resolved:
                        lookup_input_lineage_parts.append(
                            f"{_lkp_inst_name}.{_lkp_field} = {_input_port_name} <- (unresolved)"
                        )

        _lookup_input_lineage_str = "; ".join(lookup_input_lineage_parts)

        # Save raw chain for SQL logic generation (before post-processing passes)
        raw_chain = list(transformation_chain)

        # Feedback #5: Expand $$variable references in the transformation chain.
        # Check both LOCAL VARIABLE ports on the transformation and mapping-level
        # MAPPINGVARIABLE definitions, e.g.  $$EFF_DT  ->  $$EFF_DT (= SYSDATE)
        expanded_chain = []
        for entry in transformation_chain:
            # entry format: "INSTANCE_NAME: expression"
            colon_idx = entry.find(": ")
            if colon_idx > 0:
                trans_inst = entry[:colon_idx]
                expr_text = entry[colon_idx + 2:]
                # Find all $$VAR references
                var_refs = re.findall(r'\$\$(\w+)', expr_text)
                for var_name in var_refs:
                    # First try local variable on the same transformation
                    var_expr = local_var_lookup.get((trans_inst.lower(), var_name.lower()))
                    if not var_expr:
                        # Then try mapping-level variable/parameter
                        var_expr = mapping_var_lookup.get(var_name.lower())
                    if var_expr:
                        # Inline the variable definition
                        expr_text = re.sub(
                            r'\$\$' + re.escape(var_name) + r'(?!\w)',
                            f'$${var_name} (= {var_expr.strip()})',
                            expr_text,
                        )
                expanded_chain.append(f"{trans_inst}: {expr_text}")
            else:
                expanded_chain.append(entry)

        # Pass 2: Annotate local variable ports (non-$$ variables like v_INS_UPD_IND).
        # Group consecutive entries from the same transformation, collect all local
        # variables referenced across them, and emit a single merged entry with
        # variable definitions listed at the top in "var : definition" format
        # followed by the output port expression.
        annotated_chain = []
        idx = 0
        while idx < len(expanded_chain):
            entry = expanded_chain[idx]
            colon_idx = entry.find(": ")
            if colon_idx <= 0:
                annotated_chain.append(entry)
                idx += 1
                continue

            trans_inst = entry[:colon_idx]
            # Gather consecutive entries from the same transformation instance
            group_exprs = [entry[colon_idx + 2:]]
            j = idx + 1
            while j < len(expanded_chain):
                next_entry = expanded_chain[j]
                nc = next_entry.find(": ")
                if nc > 0 and next_entry[:nc] == trans_inst:
                    group_exprs.append(next_entry[nc + 2:])
                    j += 1
                else:
                    break

            # Collect all local variables referenced across the group
            referenced_vars: list = []  # ordered, no duplicates
            seen_var_names: set = set()
            for expr in group_exprs:
                _expr_no_strings = re.sub(r"'[^']*'", "", expr)
                for token_match in re.finditer(r'\b([A-Za-z_]\w*)\b', _expr_no_strings):
                    token = token_match.group(1)
                    start = token_match.start()
                    if start >= 2 and expr[start-2:start] == '$$':
                        continue
                    if start >= 1 and expr[start-1] == '$':
                        continue
                    if token.lower() not in seen_var_names:
                        var_def = local_var_lookup.get((trans_inst.lower(), token.lower()))
                        if var_def:
                            referenced_vars.append((token, var_def.strip()))
                            seen_var_names.add(token.lower())

            if not referenced_vars:
                # No local variables — keep entries as-is
                for k in range(idx, j):
                    annotated_chain.append(expanded_chain[k])
                idx = j
                continue

            # Topological sort: if var_a's definition references var_b, var_b comes first
            var_order: list = []
            var_map = {name.lower(): (name, defn) for name, defn in referenced_vars}
            placed = set()
            def _place(vname_lower: str):
                if vname_lower in placed:
                    return
                placed.add(vname_lower)
                name, defn = var_map[vname_lower]
                # Check which other referenced vars appear in this var's definition
                _defn_no_strings = re.sub(r"'[^']*'", "", defn)
                for dep_match in re.finditer(r'\b([A-Za-z_]\w*)\b', _defn_no_strings):
                    dep = dep_match.group(1).lower()
                    if dep != vname_lower and dep in var_map:
                        _place(dep)
                var_order.append((name, defn))
            for vname_lower in var_map:
                _place(vname_lower)

            # Determine output expression: the entry whose expression is NOT itself
            # a local variable's definition (i.e. it's the output port).
            # Prefer the first entry (output port expression) since the chain is
            # ordered output-port-first then variable-definitions after.
            output_expr = group_exprs[0]
            for expr in group_exprs:
                expr_s = expr.strip()
                is_var_def = False
                for _, vdef in var_order:
                    if expr_s == vdef:
                        is_var_def = True
                        break
                # Also check if the expression is just a variable reference
                if local_var_lookup.get((trans_inst.lower(), expr_s.lower())):
                    is_var_def = True
                if not is_var_def:
                    output_expr = expr
                    break

            # Build merged entry: TRANS:\nvar1 : def1\nvar2 : def2\n\noutput_expr
            # Double newline separates variable definitions from output expression.
            var_lines = [f"{trans_inst}:"]
            for vname, vdef in var_order:
                var_lines.append(f"{vname} : {vdef}")
            annotated_chain.append("\n".join(var_lines) + "\n\n" + output_expr)
            idx = j

        # Pass 3 & 4: Annotate built-in variables and sequence generator references.
        # Helper to apply built-in and sequence annotations to an expression text.
        def _annotate_builtins_and_seqs(expr_text: str, trans_inst_lower: str) -> str:
            for builtin_name, builtin_desc in BUILTIN_VARIABLES.items():
                pattern = r'\b' + re.escape(builtin_name) + r'\b(?!\s*\(=)'
                if re.search(pattern, expr_text):
                    expr_text = re.sub(
                        pattern,
                        f'{builtin_name} (= BUILT-IN VARIABLE: {builtin_desc})',
                        expr_text,
                    )
            for seq_port in ("NEXTVAL", "CURRVAL"):
                pattern = r'\b' + seq_port + r'\b(?!\s*\(=)'
                if re.search(pattern, expr_text):
                    seq_info = seq_gen_lookup.get((trans_inst_lower, seq_port.lower()))
                    if seq_info:
                        annotation = (
                            f"(= SEQUENCE GENERATOR: {seq_info['name']}, "
                            f"start={seq_info['start']}, increment={seq_info['increment']})"
                        )
                        expr_text = re.sub(
                            pattern,
                            f'{seq_port} {annotation}',
                            expr_text,
                        )
            return expr_text

        final_chain = []
        for entry in annotated_chain:
            # Multi-line entries (merged with variable definitions)
            if '\n\n' in entry:
                header_and_vars, output_expr = entry.split('\n\n', 1)
                h_lines = header_and_vars.split('\n')
                trans_inst = h_lines[0].rstrip(':').strip()
                # Annotate both variable definitions and the output expression
                annotated_h_lines = [h_lines[0]]
                for h_line in h_lines[1:]:
                    annotated_h_lines.append(
                        _annotate_builtins_and_seqs(h_line, trans_inst.lower())
                    )
                output_expr = _annotate_builtins_and_seqs(output_expr, trans_inst.lower())
                final_chain.append("\n".join(annotated_h_lines) + "\n\n" + output_expr)
                continue

            colon_idx = entry.find(": ")
            if colon_idx > 0:
                trans_inst = entry[:colon_idx]
                expr_text = entry[colon_idx + 2:]
                expr_text = _annotate_builtins_and_seqs(expr_text, trans_inst.lower())
                final_chain.append(f"{trans_inst}: {expr_text}")
            else:
                final_chain.append(entry)

        # Build transformation chain string (raw logic)
        transformation_chain_str = ""
        if final_chain:
            transformation_chain_str = " -> ".join(final_chain)
        elif path_edges:
            transformation_chain_str = "Direct field mapping"

        # Build English explanation using context-aware expression explainer
        # Convert path_edges to dicts for the explainer
        step_dicts = [e.to_dict() for e in path_edges] if path_edges else []
        transformation_explanation = explain_transformation_chain_with_context(
            chain=final_chain,
            intermediate_steps=step_dicts,
            sql_override=sql_override_str,
            has_aggregation=has_aggregation,
            has_filter=has_filter,
            has_router=has_router,
            router_condition=router_condition_str,
            lookup_tables=list(set(lookup_tables)),
        )

        # Resolve the target table name.
        # For Router per-instance mode, use the instance name so each
        # Router path has a distinct target identity in the STTM.
        if instance_name_override:
            lineage_target_table = instance_name_override
        else:
            lineage_target_table = target.name

        # Resolve shortcut names (sc_ prefix) to actual target definition names.
        # The instance name (e.g. sc_ERROR_LOG_FEATURE) may not appear directly
        # in shortcuts. The shortcut maps transformation_name (e.g. sc_ERROR_LOG)
        # → actual table name (e.g. ERROR_LOG). So we look up the instance's
        # transformation_name first, then resolve that through shortcuts.
        if shortcuts:
            resolved = shortcuts.get(lineage_target_table.lower())
            if resolved:
                lineage_target_table = resolved
            elif instance_name_override:
                # Instance name didn't match — find the transformation_name
                # for this instance and resolve that instead
                for _tgt_inst in mapping.target_instances:
                    if _tgt_inst.name.lower() == instance_name_override.lower():
                        trans_name = _tgt_inst.transformation_name
                        resolved = shortcuts.get(trans_name.lower())
                        if resolved:
                            lineage_target_table = resolved
                        break
            elif target.name.lower() not in shortcuts:
                # For non-override mode, try resolving via transformation_name
                for _tgt_inst in mapping.target_instances:
                    if _tgt_inst.transformation_name.lower() == target.name.lower():
                        resolved = shortcuts.get(_tgt_inst.transformation_name.lower())
                        if resolved:
                            lineage_target_table = resolved
                        break

        # Flat file targets: resolve to actual output filename from session
        # extension, mirroring how flat file sources are resolved.
        # Session extensions are keyed by the INSTANCE name (e.g.
        # sc_CLAS_KEY_CONTROL_VW_FR2052A), which may differ from the resolved
        # target definition name (e.g. CLAS_KEY_CONTROL_EXTRACT_FR2052A).
        #
        # Strategy: find the target INSTANCE whose transformation_name matches
        # the current target definition, then use that instance name to look up
        # the file writer session extension.  This handles dual-role shortcuts
        # where the same sc_ name is used as both source and target.
        if hasattr(target, "database_type") and target.database_type and \
                "flat file" in target.database_type.lower():
            _resolved_ff = None

            # First: find the specific target instance for THIS target definition.
            # The target instance name (e.g. sc_CLAS_KEY_CONTROL_VW_FR2052A) is
            # what session extensions use as SINSTANCENAME.  We need to find the
            # target instance whose connector chain leads to THIS target def.
            #
            # Strategy: check connectors — the target instance that receives data
            # (has connectors TO it) for fields that match this target's fields.
            _ff_candidates = []
            if instance_name_override:
                _ff_candidates.append(instance_name_override)

            # Find target instance by matching connector destinations against
            # this target definition's field names.
            _target_field_names = {f.name.lower() for f in target.fields} if hasattr(target, 'fields') else set()
            if _target_field_names:
                for _tgt_inst in mapping.target_instances:
                    # Count connectors going TO this instance with matching field names
                    _match_count = 0
                    for _conn in mapping.connectors:
                        if _conn.to_instance.lower() == _tgt_inst.name.lower():
                            if _conn.to_field.lower() in _target_field_names:
                                _match_count += 1
                    if _match_count > 0:
                        _ff_candidates.append(_tgt_inst.name)
                        break

            # Fallback: the resolved name and original target.name
            _ff_candidates.append(lineage_target_table)
            _ff_candidates.append(target.name)

            # Deduplicate while preserving order
            _seen_ff = set()
            _ff_unique = []
            for c in _ff_candidates:
                if c and c.lower() not in _seen_ff:
                    _seen_ff.add(c.lower())
                    _ff_unique.append(c)
            for _ff_name in _ff_unique:
                _resolved_ff = self._resolve_flat_file_target_name(
                    _ff_name, sessions
                )
                if _resolved_ff:
                    lineage_target_table = _resolved_ff
                    break

        # Build the source qualifier name string from collected SQ names
        sq_name_str = "; ".join(dict.fromkeys(source_qualifier_names)) if source_qualifier_names else ""

        # Feedback #4: Build lookup detail strings
        lkp_names = "; ".join(dict.fromkeys(d["name"] for d in lookup_details)) if lookup_details else ""
        lkp_conditions = "; ".join(
            dict.fromkeys(d["condition"] for d in lookup_details if d["condition"])
        ) if lookup_details else ""
        lkp_sql_overrides = "; ".join(
            dict.fromkeys(d["sql_override"] for d in lookup_details if d["sql_override"])
        ) if lookup_details else ""

        # Collect the mapping's base source table names as a fallback for
        # fields whose ultimate source is a lookup alias.
        # Only include Source Definition instances (not Source Qualifiers).
        _mapping_src_tables = []
        _seen_src = set()
        for _src_inst in mapping.source_instances:
            _src_type = getattr(_src_inst, "transformation_type", "")
            if "source qualifier" in str(_src_type).lower():
                continue
            _sname = (_src_inst.transformation_name or _src_inst.name)
            if _sname.lower() not in _seen_src:
                _seen_src.add(_sname.lower())
                _mapping_src_tables.append(_sname)

        # Build SQL-like transformation logic
        sql_logic_str = self._format_sql_logic(
            target_field_name=target_field.name,
            raw_chain=raw_chain,
            lookup_details=lookup_details,
            lookup_tables=lookup_tables,
            filter_condition=filter_condition_str,
            ultimate_sources=ultimate_sources,
            router_condition=router_condition_str,
            joiner_condition=joiner_condition_str,
            joiner_type=joiner_type_str,
            mapping_source_tables=_mapping_src_tables,
        )

        # Build union_details from custom_transformation_inputs groups
        union_details: Dict[str, Any] = {}
        if custom_transformation_inputs:
            _union_groups_seen: Dict[str, list] = {}
            _union_group_sources: Dict[str, list] = {}
            _union_name = ""
            for ci in custom_transformation_inputs:
                grp = ci.get("union_group", "")
                if grp:
                    if grp not in _union_groups_seen:
                        _union_groups_seen[grp] = []
                        _union_group_sources[grp] = []
                    _union_groups_seen[grp].append(ci.get("input_field", ""))
                    _src_entry = f"{ci.get('from_instance', '')}.{ci.get('from_field', '')}"
                    if _src_entry not in _union_group_sources[grp]:
                        _union_group_sources[grp].append(_src_entry)
                    # Try to find the union transformation name
                    if not _union_name:
                        for inst in mapping.instances:
                            if "custom" in inst.transformation_type.lower():
                                _union_name = inst.name
                                break
            if _union_groups_seen:
                union_details = {
                    "union_name": _union_name,
                    "group_count": len(_union_groups_seen),
                    "groups": list(_union_groups_seen.keys()),
                    "group_fields": {g: flds for g, flds in _union_groups_seen.items()},
                    "group_sources": {g: srcs for g, srcs in _union_group_sources.items()},
                }

        # Qualify target table with database prefix from session attributes
        lineage_target_table = self._qualify_target_table(
            lineage_target_table,
            instance_name_override or lineage_target_table,
            mapping, sessions, shortcuts,
        )

        return EndToEndFieldLineage(
            target_table=lineage_target_table,
            target_field=target_field.name,
            target_datatype=target_field.full_datatype,
            mapping_name=mapping.name,
            session_name=_mapping_session_name,
            ultimate_sources=ultimate_sources,
            intermediate_steps=path_edges,
            transformation_chain=transformation_chain_str,
            transformation_explanation=transformation_explanation,
            hop_count=len(path_edges),
            lookup_tables=list(set(lookup_tables)),
            aggregation_applied=has_aggregation,
            filter_applied=has_filter,
            filter_condition=filter_condition_str,
            router_applied=has_router,
            router_condition=router_condition_str,
            joiner_condition=joiner_condition_str,
            joiner_type=joiner_type_str,
            update_strategy=update_strategy_str,
            sql_override=sql_override_str,
            source_qualifier_name=sq_name_str,
            custom_transformation_inputs=custom_transformation_inputs,
            lookup_name=lkp_names,
            lookup_condition=lkp_conditions,
            lookup_sql_override=lkp_sql_overrides,
            sql_logic=sql_logic_str,
            union_details=union_details,
            lookup_input_lineage=_lookup_input_lineage_str,
        )

    def _format_sql_logic(
        self,
        target_field_name: str,
        raw_chain: list,
        lookup_details: list,
        lookup_tables: list,
        filter_condition: str,
        ultimate_sources: list,
        router_condition: str,
        joiner_condition: str,
        joiner_type: str,
        mapping_source_tables: Optional[List[str]] = None,
    ) -> str:
        """Build a SQL-like representation of the transformation logic.

        Represents lookups as LEFT JOINs, unions as UNION ALL subqueries,
        filters as WHERE clauses, and all expressions in SELECT.
        """
        if not raw_chain and not ultimate_sources:
            return ""

        # --- Step 1: Parse raw chain to detect Union groups ---
        # Union boundary entries: "Instance: Union pass-through (...)" or "Instance: Union group [GROUP] (...)"
        UNION_MARKERS = ("Union pass-through", "Union group [")
        segments = [[]]  # segment 0 = pre-Union (closest to target)
        union_group_names = []  # group name for each Union segment
        for entry in raw_chain:
            if any(m in entry for m in UNION_MARKERS):
                segments.append([])  # start new group
                # Extract group name if present
                _gm = re.search(r'Union group \[([^\]]+)\]', entry)
                union_group_names.append(_gm.group(1) if _gm else f"Group {len(segments) - 1}")
            else:
                segments[-1].append(entry)
        has_union = len(segments) > 1

        # --- Step 2: Determine source tables ---
        # Collect lookup alias names so we can exclude them from the FROM clause
        lookup_alias_names = set()
        for detail in lookup_details:
            lkp_name = detail.get("name", "")
            if lkp_name:
                lookup_alias_names.add(lkp_name.lower())

        source_tables = []
        for src in ultimate_sources:
            tbl = src.get("table", "")
            if tbl and tbl != "HARD CODED VALUE":
                source_tables.append(tbl)
        # Deduplicate preserving order, separating real tables from lookup aliases
        seen_tables = set()
        unique_source_tables = []
        lookup_source_tables = []
        for t in source_tables:
            if t.lower() not in seen_tables:
                seen_tables.add(t.lower())
                if t.lower() in lookup_alias_names:
                    lookup_source_tables.append(t)
                else:
                    unique_source_tables.append(t)

        # --- Step 3: Build LEFT JOIN clauses for lookups ---
        join_clauses = []
        seen_lookups = set()
        for i, detail in enumerate(lookup_details):
            lkp_name = detail.get("name", "")
            if lkp_name.lower() in seen_lookups:
                continue
            seen_lookups.add(lkp_name.lower())
            # Get table name (parallel list)
            lkp_table = lookup_tables[i] if i < len(lookup_tables) else lkp_name
            condition = detail.get("condition", "")
            sql_ovr = detail.get("sql_override", "")
            join_line = f"LEFT JOIN {lkp_table} {lkp_name}"
            if condition:
                # Format condition with ON and AND
                parts = [p.strip() for p in condition.split(" AND ")]
                join_line += f"\n  ON " + "\n  AND ".join(parts)
            if sql_ovr:
                join_line += f"\n  /* SQL Override: {sql_ovr} */"
            join_clauses.append(join_line)

        # --- Step 4: Build joiner clause ---
        joiner_clause = ""
        if joiner_condition:
            jtype = joiner_type.upper() if joiner_type else "INNER"
            if "DETAIL OUTER" in jtype:
                jtype = "LEFT OUTER"
            elif "MASTER OUTER" in jtype:
                jtype = "RIGHT OUTER"
            elif "FULL OUTER" in jtype:
                jtype = "FULL OUTER"
            else:
                jtype = "INNER"
            parts = [p.strip() for p in joiner_condition.split(" AND ")]
            joiner_clause = f"{jtype} JOIN /* joiner */\n  ON " + "\n  AND ".join(parts)

        # --- Step 5: Build WHERE clause ---
        where_clause = ""
        if filter_condition:
            where_clause = f"WHERE {filter_condition}"

        # --- Step 6: Determine SELECT expression ---
        def _extract_expr(entry: str) -> str:
            """Extract expression part from 'INSTANCE: expression' format."""
            ci = entry.find(": ")
            return entry[ci + 2:] if ci > 0 else entry

        def _extract_instance(entry: str) -> str:
            ci = entry.find(": ")
            return entry[:ci] if ci > 0 else ""

        def _is_pass_through(expr: str) -> bool:
            """Check if expression is just a field name (no operators/functions)."""
            return bool(re.match(r'^[A-Za-z_]\w*$', expr.strip()))

        # For the SELECT expression, find the most meaningful expression in the chain.
        # The chain is ordered from target-side to source-side.
        # - Entry 0 is closest to target (often a pass-through)
        # - Deeper entries have the actual expressions
        select_expr = ""
        if has_union:
            # Build UNION ALL subquery from each group's expression
            union_groups = []
            for g_idx, seg in enumerate(segments[1:], start=1):
                # Find the first expression entry in this group segment
                group_expr = target_field_name
                for entry in seg:
                    expr = _extract_expr(entry)
                    if not _is_pass_through(expr):
                        group_expr = expr
                        break
                union_groups.append(group_expr)

            # Also check if segment 0 (pre-Union) has the expression for group 1
            # Group 1 goes through normal edges, not Union pass-through
            # Look for a non-pass-through expression in the chain that's NOT in a Union segment
            group1_expr = None
            for entry in segments[0]:
                expr = _extract_expr(entry)
                if not _is_pass_through(expr):
                    group1_expr = expr
                    break

            # Build the UNION ALL subquery with group labels
            from_table = unique_source_tables[0] if unique_source_tables else "source"
            union_parts = []
            if group1_expr:
                union_parts.append(
                    f"  SELECT {group1_expr} AS {target_field_name} FROM {from_table}  /* Group 1 */"
                )
            for g_idx, g_expr in enumerate(union_groups):
                g_name = union_group_names[g_idx] if g_idx < len(union_group_names) else f"Group {g_idx + 2}"
                union_parts.append(
                    f"  SELECT {g_expr} AS {target_field_name} FROM {from_table}  /* {g_name} */"
                )
            select_expr = f"u.{target_field_name}"
        else:
            # No Union — find the deepest non-pass-through expression
            all_entries = segments[0] if segments else []
            deepest_expr = None
            for entry in reversed(all_entries):
                expr = _extract_expr(entry)
                if not _is_pass_through(expr):
                    deepest_expr = expr
                    break
            # Check if ultimate source is a lookup return port
            lkp_source = None
            for src in ultimate_sources:
                tbl = src.get("table", "")
                fld = src.get("field", "")
                if tbl and any(tbl.lower() == d.get("name", "").lower() for d in lookup_details):
                    lkp_source = f"{tbl}.{fld}"
                    break

            if deepest_expr:
                select_expr = deepest_expr
            elif lkp_source:
                select_expr = lkp_source
            else:
                # Simple pass-through from source
                src_fields = [src.get("field", "") for src in ultimate_sources if src.get("field")]
                if src_fields:
                    select_expr = f"src.{src_fields[0]}"
                else:
                    select_expr = target_field_name

        # --- Step 7: Assemble SQL ---
        lines = []

        # SELECT
        if select_expr != target_field_name and not _is_pass_through(select_expr):
            lines.append(f"SELECT {select_expr} AS {target_field_name}")
        else:
            lines.append(f"SELECT {select_expr}")

        # FROM (with UNION ALL subquery if applicable)
        # When all ultimate sources are lookup aliases, fall back to the
        # mapping's base source tables so the FROM clause references the
        # real source table (e.g. sc_SHAW_MAST_ILN_STG) instead of the
        # lookup alias.
        from_tables = unique_source_tables
        if not from_tables and mapping_source_tables:
            from_tables = mapping_source_tables

        if has_union and 'union_parts' in dir():
            lines.append("FROM (")
            lines.append("\n  UNION ALL\n".join(union_parts))
            lines.append(") u")
        elif from_tables:
            lines.append(f"FROM {', '.join(from_tables)} src")
        else:
            lines.append("FROM source")

        # JOINer
        if joiner_clause:
            lines.append(joiner_clause)

        # LEFT JOINs (lookups)
        for jc in join_clauses:
            lines.append(jc)

        # WHERE
        if where_clause:
            lines.append(where_clause)

        # Router condition as comment
        if router_condition:
            lines.append(f"-- Router: {router_condition}")

        return "\n".join(lines)

    def _build_summary(
        self,
        doc,
        expert_results: Dict[str, ExpertResult],
        lineages: List[EndToEndFieldLineage],
    ) -> Dict[str, Any]:
        """Build summary statistics."""
        return {
            "document_info": {
                "file": doc.file_path,
                "creation_date": doc.creation_date,
                "repository": doc.repository.name if doc.repository else None,
                "folder": doc.folder.name if doc.folder else None,
            },
            "counts": {
                "sources": doc.source_count,
                "targets": doc.target_count,
                "mappings": doc.mapping_count,
                "workflows": doc.workflow_count,
                "end_to_end_lineages": len(lineages),
            },
            "expert_status": {
                name: result.status.value
                for name, result in expert_results.items()
            },
            "expert_confidence": {
                name: result.confidence
                for name, result in expert_results.items()
            },
        }

    @classmethod
    def from_xdm_parse_result(
        cls,
        xdm_result: "XDMParseResult",
        parallel: bool = True,
        max_workers: int = 3,
    ) -> "IntegrationExpert":
        """
        Create an XDM-enabled IntegrationExpert from XDM parse results.

        Args:
            xdm_result: Result from PowermartParserXDM.parse()
            parallel: Run sub-experts in parallel
            max_workers: Maximum parallel workers

        Returns:
            IntegrationExpert configured with XDM capabilities
        """
        return cls(
            parallel=parallel,
            max_workers=max_workers,
            use_xdm=True,
            xdm_parser=xdm_result.xdm_parser,
            mapping_asts=xdm_result.mapping_asts,
        )

    @classmethod
    def is_xdm_available(cls) -> bool:
        """Check if XDM capabilities are available."""
        return XDM_AVAILABLE
