"""
Pattern Detector for Informatica Mappings.

Uses XPath queries to detect complex transformation patterns,
potential issues, and optimization opportunities.
"""

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Set
from enum import Enum

from ..utils.xml_utils_xdm import XDMXMLParser
from ..utils.xpath_builder import InformaticaXPathPatterns, xpath_builder, TransformationType
from ..utils.mapping_ast import MappingAST, NodeType
from ..utils.logging_config import get_logger


logger = get_logger("pattern_detector")


class PatternType(Enum):
    """Types of patterns detected."""
    # Performance patterns
    MULTI_LOOKUP = "multi_lookup"
    LOOKUP_CHAIN = "lookup_chain"
    FILTER_AFTER_AGGREGATOR = "filter_after_aggregator"
    COMPLEX_EXPRESSION_CHAIN = "complex_expression_chain"
    LARGE_TRANSFORMATION_CHAIN = "large_transformation_chain"

    # Data quality patterns
    UNMAPPED_FIELDS = "unmapped_fields"
    NULLABLE_TO_NOTNULL = "nullable_to_notnull"
    DATATYPE_MISMATCH = "datatype_mismatch"
    POTENTIAL_DATA_LOSS = "potential_data_loss"

    # Structural patterns
    PARALLEL_BRANCHES = "parallel_branches"
    DIAMOND_PATTERN = "diamond_pattern"
    CIRCULAR_DEPENDENCY = "circular_dependency"
    ORPHAN_TRANSFORMATION = "orphan_transformation"

    # Complexity patterns
    HIGH_FAN_OUT = "high_fan_out"
    HIGH_FAN_IN = "high_fan_in"
    DEEP_NESTING = "deep_nesting"

    # SQL patterns
    SQL_OVERRIDE = "sql_override"
    DYNAMIC_SQL = "dynamic_sql"


class PatternSeverity(Enum):
    """Severity of detected patterns."""
    INFO = "info"
    WARNING = "warning"
    ERROR = "error"
    OPTIMIZATION = "optimization"


@dataclass
class DetectedPattern:
    """Represents a detected pattern in a mapping."""
    pattern_type: PatternType
    severity: PatternSeverity
    mapping_name: str
    description: str
    location: str = ""
    affected_elements: List[str] = field(default_factory=list)
    recommendation: str = ""
    details: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "pattern_type": self.pattern_type.value,
            "severity": self.severity.value,
            "mapping_name": self.mapping_name,
            "description": self.description,
            "location": self.location,
            "affected_elements": self.affected_elements,
            "recommendation": self.recommendation,
            "details": self.details,
        }


class PatternDetector:
    """
    Detects complex patterns in Informatica mappings using XPath.

    Capabilities:
    - Performance anti-patterns (multiple lookups, filter after aggregator)
    - Data quality issues (unmapped fields, datatype mismatches)
    - Structural patterns (parallel branches, diamond patterns, cycles)
    - Complexity metrics (fan-in/fan-out, nesting depth)
    - SQL patterns (overrides, dynamic SQL)

    Example:
        detector = PatternDetector(xdm_parser)
        patterns = detector.detect_all_patterns("m_MyMapping")
        for pattern in patterns:
            print(f"{pattern.severity}: {pattern.description}")
    """

    def __init__(self, xdm_parser: XDMXMLParser):
        """
        Initialize the pattern detector.

        Args:
            xdm_parser: XDM parser with loaded XML document
        """
        self.xdm = xdm_parser
        self._mapping_asts: Dict[str, MappingAST] = {}

    def set_mapping_ast(self, mapping_name: str, ast: MappingAST) -> None:
        """Set a pre-built MappingAST for a mapping."""
        self._mapping_asts[mapping_name.lower()] = ast

    def detect_all_patterns(self, mapping_name: Optional[str] = None) -> List[DetectedPattern]:
        """
        Detect all patterns in the specified mapping or all mappings.

        Args:
            mapping_name: Optional mapping name to analyze

        Returns:
            List of detected patterns
        """
        patterns = []

        if mapping_name:
            mappings = [mapping_name]
        else:
            mappings = self.xdm.xpath_values("//MAPPING/@NAME")

        for mapping in mappings:
            patterns.extend(self._detect_performance_patterns(mapping))
            patterns.extend(self._detect_data_quality_patterns(mapping))
            patterns.extend(self._detect_structural_patterns(mapping))
            patterns.extend(self._detect_complexity_patterns(mapping))
            patterns.extend(self._detect_sql_patterns(mapping))

        return patterns

    # =========================================================================
    # Performance Pattern Detection
    # =========================================================================

    def _detect_performance_patterns(self, mapping_name: str) -> List[DetectedPattern]:
        """Detect performance-related patterns."""
        patterns = []

        # Multi-lookup detection
        patterns.extend(self._detect_multi_lookup(mapping_name))

        # Lookup chain detection
        patterns.extend(self._detect_lookup_chains(mapping_name))

        # Filter after aggregator
        patterns.extend(self._detect_filter_after_aggregator(mapping_name))

        # Complex expression chains
        patterns.extend(self._detect_complex_expression_chains(mapping_name))

        return patterns

    def _detect_multi_lookup(self, mapping_name: str) -> List[DetectedPattern]:
        """Detect mappings with multiple lookups (potential performance issue)."""
        patterns = []

        mapping = self.xdm.get_mapping(mapping_name)
        if mapping is None:
            return patterns

        lookups = self.xdm.xpath(
            ".//TRANSFORMATION[@TYPE='Lookup Procedure']",
            context=mapping
        )

        if len(lookups) > 3:
            lookup_names = [l.get("NAME", "") for l in lookups]
            patterns.append(DetectedPattern(
                pattern_type=PatternType.MULTI_LOOKUP,
                severity=PatternSeverity.WARNING,
                mapping_name=mapping_name,
                description=f"Mapping has {len(lookups)} lookup transformations which may impact performance",
                location="Multiple locations",
                affected_elements=lookup_names,
                recommendation="Consider consolidating lookups or using cached lookups",
                details={"lookup_count": len(lookups), "lookups": lookup_names},
            ))

        return patterns

    def _detect_lookup_chains(self, mapping_name: str) -> List[DetectedPattern]:
        """Detect chained lookups (lookup feeding another lookup)."""
        patterns = []

        mapping = self.xdm.get_mapping(mapping_name)
        if mapping is None:
            return patterns

        # Find lookups
        lookups = self.xdm.xpath(
            ".//TRANSFORMATION[@TYPE='Lookup Procedure']",
            context=mapping
        )
        lookup_names = {l.get("NAME", "").lower() for l in lookups}

        # Check connectors for lookup-to-lookup connections
        connectors = self.xdm.xpath(".//CONNECTOR", context=mapping)

        chains = []
        for conn in connectors:
            from_inst = conn.get("FROMINSTANCE", "").lower()
            to_inst = conn.get("TOINSTANCE", "").lower()

            if from_inst in lookup_names and to_inst in lookup_names:
                chains.append((conn.get("FROMINSTANCE", ""), conn.get("TOINSTANCE", "")))

        if chains:
            patterns.append(DetectedPattern(
                pattern_type=PatternType.LOOKUP_CHAIN,
                severity=PatternSeverity.WARNING,
                mapping_name=mapping_name,
                description=f"Found {len(chains)} lookup chain(s) - lookups feeding other lookups",
                location="Lookup transformations",
                affected_elements=[f"{c[0]} -> {c[1]}" for c in chains],
                recommendation="Consider using SQL joins in the lookup query or caching lookup results",
                details={"chains": chains},
            ))

        return patterns

    def _detect_filter_after_aggregator(self, mapping_name: str) -> List[DetectedPattern]:
        """Detect filter transformations after aggregators."""
        patterns = []

        mapping = self.xdm.get_mapping(mapping_name)
        if mapping is None:
            return patterns

        # Find aggregators
        aggregators = self.xdm.xpath(
            ".//TRANSFORMATION[@TYPE='Aggregator']",
            context=mapping
        )
        agg_names = {a.get("NAME", "").lower() for a in aggregators}

        # Find filters
        filters = self.xdm.xpath(
            ".//TRANSFORMATION[@TYPE='Filter']",
            context=mapping
        )
        filter_names = {f.get("NAME", "").lower() for f in filters}

        # Check connectors for aggregator-to-filter connections
        connectors = self.xdm.xpath(".//CONNECTOR", context=mapping)

        for conn in connectors:
            from_inst = conn.get("FROMINSTANCE", "").lower()
            to_inst = conn.get("TOINSTANCE", "").lower()

            if from_inst in agg_names and to_inst in filter_names:
                patterns.append(DetectedPattern(
                    pattern_type=PatternType.FILTER_AFTER_AGGREGATOR,
                    severity=PatternSeverity.OPTIMIZATION,
                    mapping_name=mapping_name,
                    description="Filter transformation after Aggregator - consider moving filter before aggregation",
                    location=f"{conn.get('FROMINSTANCE', '')} -> {conn.get('TOINSTANCE', '')}",
                    affected_elements=[conn.get("FROMINSTANCE", ""), conn.get("TOINSTANCE", "")],
                    recommendation="Move filter logic before aggregation to reduce rows processed by aggregator",
                ))

        return patterns

    def _detect_complex_expression_chains(self, mapping_name: str) -> List[DetectedPattern]:
        """Detect chains of expression transformations."""
        patterns = []

        ast = self._mapping_asts.get(mapping_name.lower())
        if not ast:
            return patterns

        expr_nodes = ast.find_nodes_by_type(NodeType.EXPRESSION)
        if len(expr_nodes) < 2:
            return patterns

        # Find chains of expressions
        visited = set()
        for node in expr_nodes:
            if node.name.lower() in visited:
                continue

            chain = [node]
            current = node

            while True:
                downstream = current.get_downstream_nodes()
                expr_downstream = [n for n in downstream if n.node_type == NodeType.EXPRESSION]
                if expr_downstream and expr_downstream[0].name.lower() not in visited:
                    next_node = expr_downstream[0]
                    chain.append(next_node)
                    visited.add(next_node.name.lower())
                    current = next_node
                else:
                    break

            if len(chain) >= 3:
                patterns.append(DetectedPattern(
                    pattern_type=PatternType.COMPLEX_EXPRESSION_CHAIN,
                    severity=PatternSeverity.INFO,
                    mapping_name=mapping_name,
                    description=f"Expression chain with {len(chain)} transformations",
                    location="Expression transformations",
                    affected_elements=[n.name for n in chain],
                    recommendation="Consider consolidating expressions if they're doing related transformations",
                    details={"chain_length": len(chain)},
                ))

        return patterns

    # =========================================================================
    # Data Quality Pattern Detection
    # =========================================================================

    def _detect_data_quality_patterns(self, mapping_name: str) -> List[DetectedPattern]:
        """Detect data quality-related patterns."""
        patterns = []

        # Unmapped fields
        patterns.extend(self._detect_unmapped_fields_pattern(mapping_name))

        # Datatype mismatches
        patterns.extend(self._detect_datatype_mismatches(mapping_name))

        return patterns

    def _detect_unmapped_fields_pattern(self, mapping_name: str) -> List[DetectedPattern]:
        """Detect unmapped target fields."""
        patterns = []

        unmapped = self.xdm.find_unmapped_target_fields(mapping_name)

        if unmapped:
            fields = [f"{u['target']}.{u['field']}" for u in unmapped]
            patterns.append(DetectedPattern(
                pattern_type=PatternType.UNMAPPED_FIELDS,
                severity=PatternSeverity.WARNING,
                mapping_name=mapping_name,
                description=f"{len(unmapped)} target field(s) have no incoming data",
                location="Target definition",
                affected_elements=fields,
                recommendation="Map the fields or verify they should receive NULL values",
                details={"unmapped_count": len(unmapped), "fields": unmapped},
            ))

        return patterns

    def _detect_datatype_mismatches(self, mapping_name: str) -> List[DetectedPattern]:
        """Detect potential datatype mismatches in mappings."""
        patterns = []

        mapping = self.xdm.get_mapping(mapping_name)
        if mapping is None:
            return patterns

        connectors = self.xdm.xpath(".//CONNECTOR", context=mapping)

        mismatches = []
        for conn in connectors:
            from_ctx = self.xdm.get_field_context(
                conn.get("FROMINSTANCE", ""),
                conn.get("FROMFIELD", ""),
                mapping_name
            )
            to_ctx = self.xdm.get_field_context(
                conn.get("TOINSTANCE", ""),
                conn.get("TOFIELD", ""),
                mapping_name
            )

            if from_ctx and to_ctx and from_ctx.datatype and to_ctx.datatype:
                # Check for potential data loss
                if self._is_potential_data_loss(from_ctx, to_ctx):
                    mismatches.append({
                        "from": f"{conn.get('FROMINSTANCE', '')}.{conn.get('FROMFIELD', '')}",
                        "to": f"{conn.get('TOINSTANCE', '')}.{conn.get('TOFIELD', '')}",
                        "from_type": f"{from_ctx.datatype}({from_ctx.precision})",
                        "to_type": f"{to_ctx.datatype}({to_ctx.precision})",
                    })

        if mismatches:
            patterns.append(DetectedPattern(
                pattern_type=PatternType.POTENTIAL_DATA_LOSS,
                severity=PatternSeverity.WARNING,
                mapping_name=mapping_name,
                description=f"{len(mismatches)} connector(s) may cause data loss due to precision/type changes",
                location="Connectors",
                affected_elements=[m["from"] + " -> " + m["to"] for m in mismatches],
                recommendation="Verify datatype conversions are intentional",
                details={"mismatches": mismatches},
            ))

        return patterns

    def _is_potential_data_loss(self, from_ctx, to_ctx) -> bool:
        """Check if datatype conversion might cause data loss."""
        # Check precision reduction
        if from_ctx.precision > to_ctx.precision and to_ctx.precision > 0:
            return True

        # Check scale reduction for decimal types
        if from_ctx.scale > to_ctx.scale and to_ctx.scale >= 0:
            if from_ctx.datatype.lower() in ["decimal", "number", "numeric"]:
                return True

        # Check string to number
        if from_ctx.datatype.lower() in ["varchar", "string", "char"]:
            if to_ctx.datatype.lower() in ["integer", "number", "decimal", "bigint"]:
                return True

        return False

    # =========================================================================
    # Structural Pattern Detection
    # =========================================================================

    def _detect_structural_patterns(self, mapping_name: str) -> List[DetectedPattern]:
        """Detect structural patterns."""
        patterns = []

        ast = self._mapping_asts.get(mapping_name.lower())
        if not ast:
            return patterns

        # Circular dependencies
        patterns.extend(self._detect_circular_dependencies(mapping_name, ast))

        # Diamond patterns
        patterns.extend(self._detect_diamond_patterns(mapping_name, ast))

        # Orphan transformations
        patterns.extend(self._detect_orphan_transformations(mapping_name, ast))

        return patterns

    def _detect_circular_dependencies(
        self, mapping_name: str, ast: MappingAST
    ) -> List[DetectedPattern]:
        """Detect circular dependencies in the mapping."""
        patterns = []

        cycles = ast.detect_cycles()

        for cycle in cycles:
            patterns.append(DetectedPattern(
                pattern_type=PatternType.CIRCULAR_DEPENDENCY,
                severity=PatternSeverity.ERROR,
                mapping_name=mapping_name,
                description=f"Circular dependency detected: {' -> '.join(cycle)}",
                location="Transformation flow",
                affected_elements=cycle,
                recommendation="Remove circular dependency to ensure proper data flow",
                details={"cycle": cycle},
            ))

        return patterns

    def _detect_diamond_patterns(
        self, mapping_name: str, ast: MappingAST
    ) -> List[DetectedPattern]:
        """Detect diamond patterns (multiple paths converging)."""
        patterns = []

        # Find nodes with multiple incoming paths from the same source
        for node_name, node in ast.nodes.items():
            if len(node.incoming_edges) > 1:
                # Check if edges come from different branches of the same source
                source_origins: Dict[str, List[str]] = {}

                for edge in node.incoming_edges:
                    # Trace back to source
                    if edge.from_node:
                        origins = self._trace_to_sources(edge.from_node, ast)
                        for origin in origins:
                            if origin not in source_origins:
                                source_origins[origin] = []
                            source_origins[origin].append(edge.from_instance)

                # Check for diamond (same source reaching through multiple paths)
                for origin, paths in source_origins.items():
                    if len(set(paths)) > 1:
                        patterns.append(DetectedPattern(
                            pattern_type=PatternType.DIAMOND_PATTERN,
                            severity=PatternSeverity.INFO,
                            mapping_name=mapping_name,
                            description=f"Diamond pattern: {origin} reaches {node.name} through multiple paths",
                            location=node.name,
                            affected_elements=[origin] + paths + [node.name],
                            recommendation="Verify data consistency when same source reaches target through different transformation paths",
                        ))
                        break

        return patterns

    def _trace_to_sources(self, node, ast: MappingAST, visited: Optional[Set[str]] = None) -> Set[str]:
        """Trace node back to its sources."""
        if visited is None:
            visited = set()

        if node.name.lower() in visited:
            return set()
        visited.add(node.name.lower())

        if node.is_source:
            return {node.name}

        sources = set()
        for upstream in node.get_upstream_nodes():
            sources.update(self._trace_to_sources(upstream, ast, visited))

        return sources

    def _detect_orphan_transformations(
        self, mapping_name: str, ast: MappingAST
    ) -> List[DetectedPattern]:
        """Detect transformations not connected to data flow."""
        patterns = []

        orphans = []
        for node_name, node in ast.nodes.items():
            if not node.is_source and not node.is_target:
                if len(node.incoming_edges) == 0 and len(node.outgoing_edges) == 0:
                    orphans.append(node.name)

        if orphans:
            patterns.append(DetectedPattern(
                pattern_type=PatternType.ORPHAN_TRANSFORMATION,
                severity=PatternSeverity.WARNING,
                mapping_name=mapping_name,
                description=f"{len(orphans)} transformation(s) are not connected to data flow",
                location="Transformations",
                affected_elements=orphans,
                recommendation="Remove unused transformations or connect them to data flow",
                details={"orphans": orphans},
            ))

        return patterns

    # =========================================================================
    # Complexity Pattern Detection
    # =========================================================================

    def _detect_complexity_patterns(self, mapping_name: str) -> List[DetectedPattern]:
        """Detect complexity-related patterns."""
        patterns = []

        ast = self._mapping_asts.get(mapping_name.lower())
        if not ast:
            return patterns

        # High fan-out
        for node_name, node in ast.nodes.items():
            if len(node.outgoing_edges) > 10:
                patterns.append(DetectedPattern(
                    pattern_type=PatternType.HIGH_FAN_OUT,
                    severity=PatternSeverity.INFO,
                    mapping_name=mapping_name,
                    description=f"Transformation {node.name} has high fan-out ({len(node.outgoing_edges)} outgoing connections)",
                    location=node.name,
                    affected_elements=[node.name],
                    recommendation="Consider if this complexity is necessary",
                    details={"fan_out": len(node.outgoing_edges)},
                ))

        # High fan-in
        for node_name, node in ast.nodes.items():
            if len(node.incoming_edges) > 10:
                patterns.append(DetectedPattern(
                    pattern_type=PatternType.HIGH_FAN_IN,
                    severity=PatternSeverity.INFO,
                    mapping_name=mapping_name,
                    description=f"Transformation {node.name} has high fan-in ({len(node.incoming_edges)} incoming connections)",
                    location=node.name,
                    affected_elements=[node.name],
                    recommendation="Consider if this complexity is necessary",
                    details={"fan_in": len(node.incoming_edges)},
                ))

        return patterns

    # =========================================================================
    # SQL Pattern Detection
    # =========================================================================

    def _detect_sql_patterns(self, mapping_name: str) -> List[DetectedPattern]:
        """Detect SQL-related patterns."""
        patterns = []

        sql_overrides = self.xdm.find_sql_overrides(mapping_name)

        for override in sql_overrides:
            sql = override.get("sql_override", "")
            trans = override.get("transformation", "")

            severity = PatternSeverity.INFO
            recommendation = "Document the SQL override and ensure it's optimized"

            # Check for potential issues in SQL
            sql_lower = sql.lower()
            issues = []

            if "select *" in sql_lower:
                issues.append("SELECT * may return unnecessary columns")
                severity = PatternSeverity.WARNING

            if "distinct" in sql_lower:
                issues.append("DISTINCT may be expensive - verify it's needed")

            if sql_lower.count("join") > 2:
                issues.append(f"Complex SQL with {sql_lower.count('join')} JOINs")
                severity = PatternSeverity.WARNING

            patterns.append(DetectedPattern(
                pattern_type=PatternType.SQL_OVERRIDE,
                severity=severity,
                mapping_name=mapping_name,
                description=f"SQL override in {trans}" + (f": {', '.join(issues)}" if issues else ""),
                location=trans,
                affected_elements=[trans],
                recommendation=recommendation,
                details={
                    "transformation": trans,
                    "sql_preview": sql[:200] + "..." if len(sql) > 200 else sql,
                    "issues": issues,
                },
            ))

        return patterns

    # =========================================================================
    # Summary Methods
    # =========================================================================

    def get_pattern_summary(self, patterns: List[DetectedPattern]) -> Dict[str, Any]:
        """Get a summary of detected patterns."""
        summary = {
            "total_patterns": len(patterns),
            "by_severity": {},
            "by_type": {},
            "by_mapping": {},
        }

        for pattern in patterns:
            # By severity
            sev = pattern.severity.value
            if sev not in summary["by_severity"]:
                summary["by_severity"][sev] = 0
            summary["by_severity"][sev] += 1

            # By type
            ptype = pattern.pattern_type.value
            if ptype not in summary["by_type"]:
                summary["by_type"][ptype] = 0
            summary["by_type"][ptype] += 1

            # By mapping
            mapping = pattern.mapping_name
            if mapping not in summary["by_mapping"]:
                summary["by_mapping"][mapping] = 0
            summary["by_mapping"][mapping] += 1

        return summary
