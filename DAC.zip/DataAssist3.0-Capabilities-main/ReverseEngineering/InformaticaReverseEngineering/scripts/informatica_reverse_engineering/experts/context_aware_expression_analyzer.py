"""
Context-Aware Expression Analyzer.

Analyzes Informatica transformation expressions with full XML context,
including field datatypes, source definitions, and transformation chains.
"""

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Set, Tuple
from enum import Enum
import re

from ..utils.xml_utils_xdm import XDMXMLParser, FieldContext
from ..utils.mapping_ast import MappingAST, TransformationNode
from ..parsers.expression_parser import ExpressionParser, ParsedExpression
from ..utils.logging_config import get_logger


logger = get_logger("expression_analyzer")


class ExpressionComplexity(Enum):
    """Complexity level of an expression."""
    SIMPLE = "simple"  # Direct field reference or simple operation
    MODERATE = "moderate"  # Conditional or function call
    COMPLEX = "complex"  # Nested functions or multiple conditions
    VERY_COMPLEX = "very_complex"  # Deep nesting or many operations


class DataTypeCompatibility(Enum):
    """Datatype compatibility status."""
    COMPATIBLE = "compatible"
    IMPLICIT_CONVERSION = "implicit_conversion"
    EXPLICIT_CONVERSION = "explicit_conversion"
    POTENTIAL_DATA_LOSS = "potential_data_loss"
    INCOMPATIBLE = "incompatible"


@dataclass
class FieldReference:
    """A field reference within an expression."""
    field_name: str
    field_context: Optional[FieldContext] = None
    is_lookup: bool = False
    lookup_transformation: str = ""
    is_variable: bool = False
    is_port: bool = False

    def to_dict(self) -> Dict[str, Any]:
        return {
            "field_name": self.field_name,
            "datatype": self.field_context.datatype if self.field_context else "",
            "precision": self.field_context.precision if self.field_context else 0,
            "is_lookup": self.is_lookup,
            "lookup_transformation": self.lookup_transformation,
            "is_variable": self.is_variable,
        }


@dataclass
class FunctionCall:
    """A function call within an expression."""
    function_name: str
    arguments: List[str]
    return_type: str = ""
    is_aggregate: bool = False
    is_conditional: bool = False
    is_date: bool = False
    is_string: bool = False
    is_numeric: bool = False

    def to_dict(self) -> Dict[str, Any]:
        return {
            "function_name": self.function_name,
            "argument_count": len(self.arguments),
            "return_type": self.return_type,
            "is_aggregate": self.is_aggregate,
            "is_conditional": self.is_conditional,
        }


@dataclass
class AnalyzedExpression:
    """Result of context-aware expression analysis."""
    expression: str
    transformation: str
    field_name: str
    mapping_name: str

    # Parsed components
    field_references: List[FieldReference] = field(default_factory=list)
    function_calls: List[FunctionCall] = field(default_factory=list)
    literals: List[str] = field(default_factory=list)
    operators: List[str] = field(default_factory=list)

    # Analysis results
    complexity: ExpressionComplexity = ExpressionComplexity.SIMPLE
    output_datatype: str = ""
    output_precision: int = 0
    output_scale: int = 0

    # Lineage
    source_fields: List[str] = field(default_factory=list)
    lookup_fields: List[str] = field(default_factory=list)
    variable_references: List[str] = field(default_factory=list)

    # Issues
    warnings: List[str] = field(default_factory=list)
    potential_issues: List[str] = field(default_factory=list)

    # Explanation
    explanation: str = ""
    business_logic: str = ""

    def to_dict(self) -> Dict[str, Any]:
        return {
            "expression": self.expression,
            "transformation": self.transformation,
            "field_name": self.field_name,
            "mapping_name": self.mapping_name,
            "complexity": self.complexity.value,
            "output_datatype": self.output_datatype,
            "field_references": [f.to_dict() for f in self.field_references],
            "function_calls": [f.to_dict() for f in self.function_calls],
            "source_fields": self.source_fields,
            "lookup_fields": self.lookup_fields,
            "variable_references": self.variable_references,
            "warnings": self.warnings,
            "potential_issues": self.potential_issues,
            "explanation": self.explanation,
            "business_logic": self.business_logic,
        }


class ContextAwareExpressionAnalyzer:
    """
    Analyzes Informatica expressions with full XML context.

    Key capabilities:
    - Resolves field references to actual source/target definitions
    - Validates datatype compatibility
    - Detects potential data loss
    - Traces expression dependencies through transformation chains
    - Generates human-readable explanations

    Example:
        analyzer = ContextAwareExpressionAnalyzer(xdm_parser)
        result = analyzer.analyze_expression(
            expression="IIF(ISNULL(AMOUNT), 0, AMOUNT * RATE)",
            transformation="exp_Calculate",
            mapping_name="m_Sales"
        )
        print(result.explanation)
        print(result.source_fields)
    """

    # Function categorization
    AGGREGATE_FUNCTIONS = {
        "SUM", "AVG", "COUNT", "MAX", "MIN", "FIRST", "LAST",
        "MEDIAN", "PERCENTILE", "STDDEV", "VARIANCE"
    }

    CONDITIONAL_FUNCTIONS = {
        "IIF", "DECODE", "CASE", "ISNULL", "NVL", "NVL2",
        "NULLIF", "COALESCE"
    }

    DATE_FUNCTIONS = {
        "SYSDATE", "SYSTIMESTAMP", "ADD_TO_DATE", "DATE_DIFF",
        "GET_DATE_PART", "SET_DATE_PART", "TO_DATE", "TO_CHAR",
        "TRUNC", "ROUND", "LAST_DAY", "NEXT_DAY", "MONTHS_BETWEEN"
    }

    STRING_FUNCTIONS = {
        "SUBSTR", "LTRIM", "RTRIM", "TRIM", "UPPER", "LOWER",
        "INITCAP", "CONCAT", "LENGTH", "INSTR", "REPLACE",
        "RPAD", "LPAD", "REVERSE", "SOUNDEX", "METAPHONE"
    }

    NUMERIC_FUNCTIONS = {
        "ABS", "CEIL", "FLOOR", "ROUND", "TRUNC", "MOD",
        "POWER", "SQRT", "LOG", "EXP", "SIGN"
    }

    CONVERSION_FUNCTIONS = {
        "TO_CHAR", "TO_DATE", "TO_DECIMAL", "TO_INTEGER",
        "TO_BIGINT", "TO_FLOAT"
    }

    def __init__(self, xdm_parser: XDMXMLParser):
        """
        Initialize the analyzer.

        Args:
            xdm_parser: XDM parser with loaded XML document
        """
        self.xdm = xdm_parser
        self.expression_parser = ExpressionParser()
        self._mapping_asts: Dict[str, MappingAST] = {}

    def set_mapping_ast(self, mapping_name: str, ast: MappingAST) -> None:
        """Set a pre-built MappingAST."""
        self._mapping_asts[mapping_name.lower()] = ast

    def analyze_expression(
        self,
        expression: str,
        transformation: str,
        mapping_name: str,
        field_name: str = ""
    ) -> AnalyzedExpression:
        """
        Analyze an expression with full context.

        Args:
            expression: The expression to analyze
            transformation: Name of the transformation containing the expression
            mapping_name: Name of the mapping
            field_name: Optional field name for the expression

        Returns:
            AnalyzedExpression with full analysis
        """
        result = AnalyzedExpression(
            expression=expression,
            transformation=transformation,
            field_name=field_name,
            mapping_name=mapping_name,
        )

        if not expression or not expression.strip():
            result.complexity = ExpressionComplexity.SIMPLE
            result.explanation = "Empty or direct pass-through expression"
            return result

        # Parse the expression
        parsed = self.expression_parser.parse(expression)

        # Extract and resolve field references
        result.field_references = self._resolve_field_references(
            parsed.referenced_fields, transformation, mapping_name
        )

        # Categorize field references
        for ref in result.field_references:
            if ref.is_lookup:
                result.lookup_fields.append(f"{ref.lookup_transformation}.{ref.field_name}")
            elif ref.is_variable:
                result.variable_references.append(ref.field_name)
            else:
                result.source_fields.append(ref.field_name)

        # Extract function calls
        result.function_calls = self._extract_function_calls(expression)

        # Extract literals and operators directly from expression
        result.literals = self._extract_literals(expression)
        result.operators = self._extract_operators(expression)

        # Determine complexity
        result.complexity = self._determine_complexity(expression, result)

        # Infer output datatype
        result.output_datatype, result.output_precision, result.output_scale = \
            self._infer_output_datatype(result)

        # Check for potential issues
        result.warnings, result.potential_issues = self._check_issues(result)

        # Generate explanation
        result.explanation = self._generate_explanation(result)
        result.business_logic = self._infer_business_logic(result)

        return result

    def analyze_all_expressions(self, mapping_name: str) -> List[AnalyzedExpression]:
        """
        Analyze all expressions in a mapping.

        Args:
            mapping_name: Name of the mapping

        Returns:
            List of AnalyzedExpression for each expression field
        """
        results = []

        mapping = self.xdm.get_mapping(mapping_name)
        if mapping is None:
            return results

        # Find all transform fields with expressions
        expr_fields = self.xdm.xpath(
            ".//TRANSFORMATION//TRANSFORMFIELD[@EXPRESSION]",
            context=mapping
        )

        for field_elem in expr_fields:
            trans_elem = field_elem.getparent()
            if trans_elem is not None:
                trans_name = trans_elem.get("NAME", "")
                field_name = field_elem.get("NAME", "")
                expression = field_elem.get("EXPRESSION", "")

                if expression.strip():
                    result = self.analyze_expression(
                        expression=expression,
                        transformation=trans_name,
                        mapping_name=mapping_name,
                        field_name=field_name
                    )
                    results.append(result)

        return results

    def _resolve_field_references(
        self,
        field_names: List[str],
        transformation: str,
        mapping_name: str
    ) -> List[FieldReference]:
        """Resolve field references to their context."""
        references = []

        for field_name in field_names:
            ref = FieldReference(field_name=field_name)

            # Check for lookup reference (LKP.field)
            if ":LKP." in field_name.upper():
                ref.is_lookup = True
                parts = field_name.split(".")
                if len(parts) >= 2:
                    ref.lookup_transformation = parts[0].replace(":LKP", "")
                    ref.field_name = parts[-1]

            # Check for variable reference ($$variable)
            elif field_name.startswith("$$"):
                ref.is_variable = True
                ref.field_name = field_name[2:]

            # Check for port reference
            else:
                ref.is_port = True
                # Try to get context
                ctx = self.xdm.get_field_context(transformation, field_name, mapping_name)
                if ctx:
                    ref.field_context = ctx

            references.append(ref)

        return references

    def _extract_function_calls(self, expression: str) -> List[FunctionCall]:
        """Extract function calls from expression."""
        functions = []

        # Pattern to match function calls
        func_pattern = r'([A-Z_][A-Z0-9_]*)\s*\('
        matches = re.finditer(func_pattern, expression.upper())

        for match in matches:
            func_name = match.group(1)

            # Determine function type
            func = FunctionCall(
                function_name=func_name,
                arguments=[],  # Would need more complex parsing for args
                is_aggregate=func_name in self.AGGREGATE_FUNCTIONS,
                is_conditional=func_name in self.CONDITIONAL_FUNCTIONS,
                is_date=func_name in self.DATE_FUNCTIONS,
                is_string=func_name in self.STRING_FUNCTIONS,
                is_numeric=func_name in self.NUMERIC_FUNCTIONS,
            )

            # Infer return type
            func.return_type = self._infer_function_return_type(func_name)

            functions.append(func)

        return functions

    def _extract_literals(self, expression: str) -> List[str]:
        """Extract string and numeric literals from expression."""
        literals = []

        # Extract string literals (single-quoted)
        string_pattern = r"'([^']*)'"
        for match in re.finditer(string_pattern, expression):
            literals.append(f"'{match.group(1)}'")

        # Extract numeric literals
        num_pattern = r'\b(\d+\.?\d*)\b'
        for match in re.finditer(num_pattern, expression):
            literals.append(match.group(1))

        return literals

    def _extract_operators(self, expression: str) -> List[str]:
        """Extract operators from expression."""
        operators = []

        # Comparison operators
        comparison_ops = ['>=', '<=', '<>', '!=', '=', '>', '<']
        for op in comparison_ops:
            if op in expression:
                operators.append(op)

        # Arithmetic operators
        arithmetic_ops = ['+', '-', '*', '/', '||']
        for op in arithmetic_ops:
            if op in expression:
                operators.append(op)

        # Logical operators (case insensitive)
        expr_upper = expression.upper()
        logical_ops = ['AND', 'OR', 'NOT']
        for op in logical_ops:
            if f' {op} ' in expr_upper or expr_upper.startswith(f'{op} ') or expr_upper.endswith(f' {op}'):
                operators.append(op)

        return list(set(operators))  # Remove duplicates

    def _infer_function_return_type(self, func_name: str) -> str:
        """Infer the return type of a function."""
        func_upper = func_name.upper()

        if func_upper in self.AGGREGATE_FUNCTIONS:
            if func_upper == "COUNT":
                return "integer"
            return "decimal"

        if func_upper in {"IIF", "DECODE", "CASE", "NVL", "NVL2", "COALESCE"}:
            return "varies"  # Depends on arguments

        if func_upper in {"ISNULL", "IS_NUMBER", "IS_DATE", "IS_SPACES"}:
            return "integer"  # Returns 0 or 1

        if func_upper in self.DATE_FUNCTIONS:
            if func_upper in {"TO_CHAR", "DATE_DIFF"}:
                return "string" if func_upper == "TO_CHAR" else "integer"
            return "date/time"

        if func_upper in self.STRING_FUNCTIONS:
            if func_upper in {"LENGTH", "INSTR"}:
                return "integer"
            return "string"

        if func_upper in self.NUMERIC_FUNCTIONS:
            return "decimal"

        if func_upper in {"TO_INTEGER", "TO_BIGINT"}:
            return "integer"

        if func_upper == "TO_DECIMAL":
            return "decimal"

        if func_upper == "TO_DATE":
            return "date/time"

        return "unknown"

    def _determine_complexity(
        self, expression: str, result: AnalyzedExpression
    ) -> ExpressionComplexity:
        """Determine expression complexity."""
        # Count nesting depth
        max_depth = 0
        current_depth = 0
        for char in expression:
            if char == '(':
                current_depth += 1
                max_depth = max(max_depth, current_depth)
            elif char == ')':
                current_depth -= 1

        # Count functions and conditionals
        func_count = len(result.function_calls)
        conditional_count = sum(1 for f in result.function_calls if f.is_conditional)
        aggregate_count = sum(1 for f in result.function_calls if f.is_aggregate)

        # Expression length
        expr_len = len(expression)

        # Determine complexity
        if max_depth >= 4 or func_count >= 5 or expr_len > 500:
            return ExpressionComplexity.VERY_COMPLEX
        elif max_depth >= 3 or func_count >= 3 or conditional_count >= 2 or aggregate_count >= 1:
            return ExpressionComplexity.COMPLEX
        elif func_count >= 1 or conditional_count >= 1 or max_depth >= 2:
            return ExpressionComplexity.MODERATE
        else:
            return ExpressionComplexity.SIMPLE

    def _infer_output_datatype(
        self, result: AnalyzedExpression
    ) -> Tuple[str, int, int]:
        """Infer the output datatype of the expression."""
        # Check for explicit conversion functions
        for func in result.function_calls:
            if func.function_name.upper() in self.CONVERSION_FUNCTIONS:
                return func.return_type, 0, 0

        # Check for aggregate functions
        for func in result.function_calls:
            if func.is_aggregate:
                if func.function_name.upper() == "COUNT":
                    return "integer", 10, 0
                return "decimal", 28, 10

        # Infer from field references
        for ref in result.field_references:
            if ref.field_context:
                return ref.field_context.datatype, ref.field_context.precision, ref.field_context.scale

        return "", 0, 0

    def _check_issues(
        self, result: AnalyzedExpression
    ) -> Tuple[List[str], List[str]]:
        """Check for potential issues in the expression."""
        warnings = []
        issues = []

        # Check for division by zero potential
        if "/" in result.expression and "IIF" not in result.expression.upper():
            if not re.search(r'ISNULL\s*\([^)]*\)\s*,\s*[^,)]+\)', result.expression, re.IGNORECASE):
                issues.append("Division operation without null check - potential divide by zero")

        # Check for null handling
        if result.field_references and not any(
            f.function_name.upper() in {"ISNULL", "NVL", "NVL2", "COALESCE"}
            for f in result.function_calls
        ):
            if result.complexity != ExpressionComplexity.SIMPLE:
                warnings.append("Expression uses fields without explicit null handling")

        # Check for string concatenation with nulls
        if "||" in result.expression:
            if not any(f.function_name.upper() in {"NVL", "COALESCE"} for f in result.function_calls):
                warnings.append("String concatenation may produce NULL if any operand is NULL")

        # Check for date arithmetic
        date_refs = [r for r in result.field_references if r.field_context and "date" in r.field_context.datatype.lower()]
        if date_refs and not any(f.is_date for f in result.function_calls):
            warnings.append("Date field used without date functions - verify date handling")

        # Check for very complex expressions
        if result.complexity == ExpressionComplexity.VERY_COMPLEX:
            warnings.append("Very complex expression - consider breaking into multiple transformations")

        return warnings, issues

    def _generate_explanation(self, result: AnalyzedExpression) -> str:
        """Generate human-readable explanation of the expression."""
        parts = []

        # Describe main operation
        if result.function_calls:
            main_funcs = [f.function_name for f in result.function_calls[:3]]
            parts.append(f"Uses functions: {', '.join(main_funcs)}")

        # Describe inputs
        if result.source_fields:
            parts.append(f"Reads from fields: {', '.join(result.source_fields[:5])}")

        if result.lookup_fields:
            parts.append(f"Looks up: {', '.join(result.lookup_fields)}")

        if result.variable_references:
            parts.append(f"Uses variables: {', '.join(result.variable_references)}")

        # Describe conditionals
        conditional_funcs = [f for f in result.function_calls if f.is_conditional]
        if conditional_funcs:
            parts.append(f"Contains conditional logic ({len(conditional_funcs)} condition(s))")

        # Describe aggregation
        aggregate_funcs = [f for f in result.function_calls if f.is_aggregate]
        if aggregate_funcs:
            agg_names = [f.function_name for f in aggregate_funcs]
            parts.append(f"Performs aggregation: {', '.join(agg_names)}")

        return "; ".join(parts) if parts else "Simple field mapping"

    def _infer_business_logic(self, result: AnalyzedExpression) -> str:
        """Attempt to infer business logic from the expression."""
        expr_upper = result.expression.upper()

        # Common patterns
        if "IIF" in expr_upper and "ISNULL" in expr_upper:
            return "Handles null values with conditional logic"

        if "DECODE" in expr_upper:
            return "Maps codes to values (lookup/decode pattern)"

        if any(f.is_aggregate for f in result.function_calls):
            return "Calculates aggregate/summary values"

        if "SYSDATE" in expr_upper or "SYSTIMESTAMP" in expr_upper:
            return "Uses current date/time for audit or calculation"

        if "CONCAT" in expr_upper or "||" in result.expression:
            return "Concatenates/combines values"

        if "SUBSTR" in expr_upper:
            return "Extracts portion of string value"

        if any(f.function_name.upper() in {"UPPER", "LOWER", "TRIM"} for f in result.function_calls):
            return "Standardizes string format"

        if "ROUND" in expr_upper or "TRUNC" in expr_upper:
            return "Rounds or truncates numeric values"

        return ""

    # =========================================================================
    # Analysis Summary Methods
    # =========================================================================

    def get_expression_summary(self, mapping_name: str) -> Dict[str, Any]:
        """Get summary of all expressions in a mapping."""
        expressions = self.analyze_all_expressions(mapping_name)

        summary = {
            "total_expressions": len(expressions),
            "by_complexity": {},
            "by_function": {},
            "with_issues": 0,
            "with_warnings": 0,
            "aggregate_expressions": 0,
            "conditional_expressions": 0,
        }

        for expr in expressions:
            # By complexity
            comp = expr.complexity.value
            summary["by_complexity"][comp] = summary["by_complexity"].get(comp, 0) + 1

            # By function
            for func in expr.function_calls:
                fn = func.function_name
                summary["by_function"][fn] = summary["by_function"].get(fn, 0) + 1

            # Issues and warnings
            if expr.potential_issues:
                summary["with_issues"] += 1
            if expr.warnings:
                summary["with_warnings"] += 1

            # Aggregates and conditionals
            if any(f.is_aggregate for f in expr.function_calls):
                summary["aggregate_expressions"] += 1
            if any(f.is_conditional for f in expr.function_calls):
                summary["conditional_expressions"] += 1

        return summary

    def find_expressions_with_function(
        self, mapping_name: str, function_name: str
    ) -> List[AnalyzedExpression]:
        """Find all expressions using a specific function."""
        all_exprs = self.analyze_all_expressions(mapping_name)
        return [
            expr for expr in all_exprs
            if any(f.function_name.upper() == function_name.upper() for f in expr.function_calls)
        ]

    def find_expressions_with_field(
        self, mapping_name: str, field_name: str
    ) -> List[AnalyzedExpression]:
        """Find all expressions referencing a specific field."""
        all_exprs = self.analyze_all_expressions(mapping_name)
        return [
            expr for expr in all_exprs
            if any(r.field_name.upper() == field_name.upper() for r in expr.field_references)
        ]
