"""Field Mapping Expert - Analyzes field-level relationships and processing logic."""

from typing import Any, Dict, List, Optional, Set, Tuple

from .base_expert import BaseExpert, ExpertType, ExpertContext
from .models.expert_result import ExpertResult, ExpertStatus
from ..models.mapping_models import Mapping
from ..models.connector_models import Connector
from ..models.lineage_models import FieldLineageEdge, LineageGraph, LineageNode, LineageNodeType
from ..parsers.expression_parser import ExpressionParser


class FieldMappingExpert(BaseExpert):
    """
    Expert for analyzing field-level mapping relationships.

    Responsibilities:
    - Parse field-level processing logic
    - Build field relationships from CONNECTOR elements
    - Track data flow through transformation ports
    - Extract expression logic for each field
    """

    def __init__(self):
        super().__init__("FieldMappingExpert", ExpertType.FIELD_MAPPING)
        self.expression_parser = ExpressionParser()

    def analyze(self, context: ExpertContext) -> ExpertResult:
        """Analyze field-level mappings."""
        self.logger.info("Starting field mapping analysis")

        doc = context.document
        results = {
            "field_mappings": [],
            "lineage_graphs": {},
            "expressions": [],
            "unmapped_fields": [],
            "statistics": {},
        }
        warnings = []

        total_mappings = 0
        total_edges = 0
        total_expressions = 0

        for mapping in doc.mappings:
            self.logger.debug(f"Analyzing mapping: {mapping.name}")

            # Build lineage graph from connectors
            graph = self._build_lineage_graph(mapping)
            results["lineage_graphs"][mapping.name] = graph.to_dict()
            total_edges += graph.edge_count

            # Extract field mappings
            field_mappings = self._extract_field_mappings(mapping, graph)
            results["field_mappings"].extend(field_mappings)
            total_mappings += len(field_mappings)

            # Extract expressions
            expressions = self._extract_expressions(mapping)
            results["expressions"].extend(expressions)
            total_expressions += len(expressions)

            # Find unmapped target fields
            unmapped = self._find_unmapped_fields(mapping, graph)
            results["unmapped_fields"].extend(unmapped)
            if unmapped:
                warnings.append(
                    f"Mapping {mapping.name} has {len(unmapped)} unmapped target fields"
                )

        results["statistics"] = {
            "total_field_mappings": total_mappings,
            "total_edges": total_edges,
            "total_expressions": total_expressions,
            "unmapped_field_count": len(results["unmapped_fields"]),
        }

        confidence = 0.95
        if results["unmapped_fields"]:
            # Reduce confidence if there are unmapped fields
            confidence = max(0.7, 0.95 - (len(results["unmapped_fields"]) * 0.02))

        self.logger.info(f"Field mapping analysis complete: {results['statistics']}")

        return self._create_result(
            status=ExpertStatus.COMPLETED,
            data=results,
            warnings=warnings,
            confidence=confidence,
        )

    def _build_lineage_graph(self, mapping: Mapping) -> LineageGraph:
        """Build a lineage graph from CONNECTOR elements."""
        graph = LineageGraph()

        # Build transformation lookup by name
        trans_lookup = {t.name.lower(): t for t in mapping.transformations}

        # Build instance lookup - maps instance name to the instance object
        instance_lookup = {inst.name.lower(): inst for inst in mapping.instances}

        # Build instance-to-transformation lookup - maps instance name to its transformation
        inst_to_trans = {}
        for inst in mapping.instances:
            # Try to find transformation by transformation_name
            trans = trans_lookup.get(inst.transformation_name.lower())
            if trans:
                inst_to_trans[inst.name.lower()] = trans
            # Also try by instance name (sometimes they match)
            elif inst.name.lower() in trans_lookup:
                inst_to_trans[inst.name.lower()] = trans_lookup[inst.name.lower()]

        self.logger.debug(f"Built instance lookup with {len(instance_lookup)} instances")
        self.logger.debug(f"Built inst_to_trans lookup with {len(inst_to_trans)} mappings")

        # Process each connector
        for conn in mapping.connectors:
            # Create edge
            edge = FieldLineageEdge(
                source_instance=conn.from_instance,
                source_field=conn.from_field,
                source_type=conn.from_instance_type,
                target_instance=conn.to_instance,
                target_field=conn.to_field,
                target_type=conn.to_instance_type,
            )

            # Try to get expression for source field using instance-to-transformation lookup
            trans = inst_to_trans.get(conn.from_instance.lower())
            if not trans:
                # Fallback: try direct transformation lookup
                trans = trans_lookup.get(conn.from_instance.lower())

            if trans:
                field = trans.get_field(conn.from_field)
                if field and field.expression:
                    edge.expression = field.expression
                    parsed = self.expression_parser.parse(field.expression)
                    edge.expression_explanation = parsed.explanation

            graph.add_edge(edge)

            # Create nodes
            source_node = LineageNode(
                instance_name=conn.from_instance,
                field_name=conn.from_field,
                instance_type=conn.from_instance_type,
                node_type=self._determine_node_type(conn.from_instance_type),
            )
            target_node = LineageNode(
                instance_name=conn.to_instance,
                field_name=conn.to_field,
                instance_type=conn.to_instance_type,
                node_type=self._determine_node_type(conn.to_instance_type),
            )

            graph.add_node(source_node)
            graph.add_node(target_node)

        return graph

    def _determine_node_type(self, instance_type: str) -> LineageNodeType:
        """Determine node type from instance type."""
        inst_type_lower = instance_type.lower()
        if "source" in inst_type_lower:
            return LineageNodeType.SOURCE
        elif "target" in inst_type_lower:
            return LineageNodeType.TARGET
        elif "lookup" in inst_type_lower:
            return LineageNodeType.LOOKUP
        else:
            return LineageNodeType.TRANSFORMATION

    def _extract_field_mappings(
        self, mapping: Mapping, graph: LineageGraph
    ) -> List[Dict[str, Any]]:
        """Extract field mapping information."""
        field_mappings = []

        for edge in graph.edges:
            mapping_info = {
                "mapping_name": mapping.name,
                "source_instance": edge.source_instance,
                "source_field": edge.source_field,
                "source_type": edge.source_type,
                "target_instance": edge.target_instance,
                "target_field": edge.target_field,
                "target_type": edge.target_type,
                "expression": edge.expression,
                "expression_explanation": edge.expression_explanation,
                "is_direct_mapping": edge.is_direct_mapping,
            }
            field_mappings.append(mapping_info)

        return field_mappings

    def _extract_expressions(self, mapping: Mapping) -> List[Dict[str, Any]]:
        """Extract all expressions from transformations."""
        expressions = []

        for trans in mapping.transformations:
            for field in trans.expressions:
                parsed = self.expression_parser.parse(field.expression)
                expr_info = {
                    "mapping_name": mapping.name,
                    "transformation": trans.name,
                    "transformation_type": trans.type,
                    "field_name": field.name,
                    "port_type": field.port_type,
                    "expression": field.expression,
                    "expression_type": field.expression_type,
                    "parsed": parsed.to_dict(),
                }
                expressions.append(expr_info)

        return expressions

    def _find_unmapped_fields(
        self, mapping: Mapping, graph: LineageGraph
    ) -> List[Dict[str, str]]:
        """Find target fields that have no incoming data flow."""
        unmapped = []

        # Get all target instances
        target_instances = {
            inst.name.lower(): inst
            for inst in mapping.instances
            if inst.is_target
        }

        # Get all target fields from targets
        for target in mapping.targets:
            for field in target.fields:
                # Check if any edge connects to this target field
                field_has_input = False
                for inst_name in target_instances:
                    node_id = f"{inst_name}.{field.name.lower()}"
                    if graph.reverse_adjacency.get(node_id):
                        field_has_input = True
                        break

                if not field_has_input:
                    # Also check by checking connectors directly
                    for conn in mapping.connectors:
                        if (conn.to_field.lower() == field.name.lower() and
                            conn.to_instance_type.lower() == "target definition"):
                            field_has_input = True
                            break

                if not field_has_input:
                    unmapped.append({
                        "mapping": mapping.name,
                        "target": target.name,
                        "field": field.name,
                    })

        return unmapped
