"""Mapping Structure Expert - Analyzes sources, targets, transformations, sessions."""

from typing import Any, Dict, List, Optional

from .base_expert import BaseExpert, ExpertType, ExpertContext
from .models.expert_result import ExpertResult, ExpertStatus
from ..models.mapping_models import Mapping
from ..models.transformation_models import TransformationType


class MappingStructureExpert(BaseExpert):
    """
    Expert for analyzing Informatica mapping structure.

    Responsibilities:
    - Identify all sources, targets, and transformations
    - Extract session variables and parameters
    - Parse SQL overrides
    - Map pre/post session tasks
    - Classify transformation types
    """

    def __init__(self, parameter_loader=None):
        super().__init__("MappingStructureExpert", ExpertType.MAPPING_STRUCTURE)
        self.parameter_loader = parameter_loader

    def analyze(self, context: ExpertContext) -> ExpertResult:
        """Analyze mapping structure."""
        self.logger.info("Starting mapping structure analysis")

        doc = context.document
        results = {
            "sources": [],
            "targets": [],
            "transformations": [],
            "transformation_types": {},
            "sql_overrides": [],
            "session_variables": [],
            "mapping_variables": [],
            "pre_session_tasks": [],
            "post_session_tasks": [],
            "session_pre_sql": [],
            "session_post_sql": [],
            "session_sql_overrides": [],
            "source_table_overrides": [],
            "target_table_overrides": [],
            "table_name_prefixes": [],
            "owner_name_overrides": [],
            "session_commands": [],
            "source_filters": [],
            "target_load_orders": [],
            "folder_owner": "",
            "statistics": {},
        }
        warnings = []

        # Analyze sources
        for source in doc.sources:
            results["sources"].append({
                "name": source.name,
                "qualified_name": source.qualified_name,
                "database_type": source.database_type,
                "field_count": source.field_count,
                "key_fields": [f.name for f in source.key_fields],
                "fields": [f.to_dict() for f in source.fields],
            })

        # Analyze targets
        for target in doc.targets:
            results["targets"].append({
                "name": target.name,
                "database_type": target.database_type,
                "field_count": target.field_count,
                "key_fields": [f.name for f in target.key_fields],
                "fields": [f.to_dict() for f in target.fields],
            })

        # Analyze mappings and their transformations
        transformation_type_counts = {}
        for mapping in doc.mappings:
            mapping_info = self._analyze_mapping(mapping)
            results["transformations"].extend(mapping_info["transformations"])

            # Count transformation types
            for trans in mapping_info["transformations"]:
                trans_type = trans.get("type", "Unknown")
                transformation_type_counts[trans_type] = \
                    transformation_type_counts.get(trans_type, 0) + 1

            # Collect mapping variables
            for var in mapping.variables:
                results["mapping_variables"].append({
                    "mapping": mapping.name,
                    "name": var.name,
                    "datatype": var.datatype,
                    "default_value": var.default_value,
                    "is_param": var.is_param,
                })

            # Collect SQL overrides
            for sql_override in mapping_info["sql_overrides"]:
                results["sql_overrides"].append(sql_override)

            # Collect target load order (Gap 4)
            if mapping.target_load_order:
                results["target_load_orders"].append({
                    "mapping": mapping.name,
                    "target_load_order": mapping.target_load_order,
                })

        results["transformation_types"] = transformation_type_counts

        # Capture folder owner (Gap 3)
        if doc.folder:
            results["folder_owner"] = doc.folder.owner

        # Analyze sessions
        for session in doc.sessions:
            session_info = self._analyze_session(session)
            results["session_variables"].extend(session_info.get("variables", []))
            results["pre_session_tasks"].extend(session_info.get("pre_session", []))
            results["post_session_tasks"].extend(session_info.get("post_session", []))
            results["session_pre_sql"].extend(session_info.get("session_pre_sql", []))
            results["session_post_sql"].extend(session_info.get("session_post_sql", []))
            results["session_sql_overrides"].extend(session_info.get("session_sql_overrides", []))
            results["source_table_overrides"].extend(session_info.get("source_table_overrides", []))
            results["target_table_overrides"].extend(session_info.get("target_table_overrides", []))
            results["table_name_prefixes"].extend(session_info.get("table_name_prefixes", []))
            results["owner_name_overrides"].extend(session_info.get("owner_name_overrides", []))
            results["session_commands"].extend(session_info.get("session_commands", []))
            results["source_filters"].extend(session_info.get("source_filters", []))

        # Analyze workflows
        for workflow in doc.workflows:
            for var in workflow.variables:
                results["session_variables"].append({
                    "workflow": workflow.name,
                    "name": var.name,
                    "datatype": var.datatype,
                    "default_value": var.default_value,
                })

        # Calculate statistics
        results["statistics"] = {
            "source_count": len(doc.sources),
            "target_count": len(doc.targets),
            "mapping_count": len(doc.mappings),
            "workflow_count": len(doc.workflows),
            "session_count": len(doc.sessions),
            "transformation_count": len(results["transformations"]),
            "sql_override_count": len(results["sql_overrides"]),
            "variable_count": len(results["mapping_variables"]) + len(results["session_variables"]),
        }

        self.logger.info(f"Structure analysis complete: {results['statistics']}")

        return self._create_result(
            status=ExpertStatus.COMPLETED,
            data=results,
            warnings=warnings,
            confidence=0.95,
        )

    def _resolve_session_param(self, text: str, session_name: str) -> str:
        """Resolve $Param_* placeholders in text using the parameter loader.

        Uses session-scoped parameters (merged with Global) when available,
        falling back to flat resolution or returning the text unchanged.
        """
        if not text or not self.parameter_loader:
            return text
        return self.parameter_loader.resolve_for_session(text, session_name)

    def _analyze_mapping(self, mapping: Mapping) -> Dict[str, Any]:
        """Analyze a single mapping."""
        result = {
            "name": mapping.name,
            "transformations": [],
            "sql_overrides": [],
        }

        for trans in mapping.transformations:
            trans_info = {
                "name": trans.name,
                "type": trans.type,
                "reusable": trans.reusable,
                "input_count": len(trans.input_fields),
                "output_count": len(trans.output_fields),
                "has_expressions": len(trans.expressions) > 0,
            }

            # Check for SQL override
            sql_query = trans.sql_query
            if sql_query:
                result["sql_overrides"].append({
                    "mapping": mapping.name,
                    "transformation": trans.name,
                    "sql_query": sql_query,
                })
                trans_info["has_sql_override"] = True

            # Check for filter condition
            filter_cond = trans.filter_condition
            if filter_cond:
                trans_info["filter_condition"] = filter_cond

            # Check for lookup condition
            lookup_cond = trans.lookup_condition
            if lookup_cond:
                trans_info["lookup_condition"] = lookup_cond

            # Check for lookup SQL override
            lookup_sql = trans.lookup_sql_override
            if lookup_sql:
                result["sql_overrides"].append({
                    "mapping": mapping.name,
                    "transformation": trans.name,
                    "type": "lookup",
                    "sql_query": lookup_sql,
                })

            result["transformations"].append(trans_info)

        return result

    def _analyze_session(self, session) -> Dict[str, Any]:
        """Analyze a session."""
        result = {
            "name": session.name,
            "mapping": session.mapping_name,
            "variables": [],
            "pre_session": [],
            "post_session": [],
            "session_pre_sql": [],
            "session_post_sql": [],
            "session_sql_overrides": [],
            "source_table_overrides": [],
            "target_table_overrides": [],
            "table_name_prefixes": [],
            "owner_name_overrides": [],
            "session_commands": [],
            "source_filters": [],
        }

        # Extract session components
        for comp in session.components:
            comp_info = {
                "session": session.name,
                "name": comp.ref_object_name,
                "type": comp.component_type,
            }

            if "pre-session" in comp.component_type.lower():
                result["pre_session"].append(comp_info)
            elif "post-session" in comp.component_type.lower():
                result["post_session"].append(comp_info)

            # Collect session commands with value pairs and attributes
            cmd_info = {
                "session": session.name,
                "component_name": comp.task_name or comp.ref_object_name or comp.component_type,
                "component_type": comp.component_type,
                "ref_object_name": comp.ref_object_name,
                "reusable": comp.reusable,
                "task_name": comp.task_name,
                "task_type": comp.task_type,
                "value_pairs": comp.value_pairs,
                "attributes": {a.name: a.value for a in comp.attributes},
            }
            result["session_commands"].append(cmd_info)

        # Extract session-level SQL metadata from extensions (Gap 3)
        for ext in session.extensions:
            if ext.pre_sql:
                resolved_sql = self._resolve_session_param(ext.pre_sql, session.name)
                result["session_pre_sql"].append({
                    "session": session.name,
                    "instance": ext.sinstance_name,
                    "type": ext.extension_type,
                    "sql": resolved_sql,
                    "raw_sql": ext.pre_sql,
                })
            if ext.post_sql:
                resolved_sql = self._resolve_session_param(ext.post_sql, session.name)
                result["session_post_sql"].append({
                    "session": session.name,
                    "instance": ext.sinstance_name,
                    "type": ext.extension_type,
                    "sql": resolved_sql,
                    "raw_sql": ext.post_sql,
                })
            if ext.sql_override:
                resolved_sql = self._resolve_session_param(ext.sql_override, session.name)
                result["session_sql_overrides"].append({
                    "session": session.name,
                    "instance": ext.sinstance_name,
                    "sql": resolved_sql,
                    "raw_sql": ext.sql_override,
                })
            if ext.source_table_name:
                result["source_table_overrides"].append({
                    "session": session.name,
                    "instance": ext.sinstance_name,
                    "table_name": ext.source_table_name,
                })
            if ext.target_table_name:
                result["target_table_overrides"].append({
                    "session": session.name,
                    "instance": ext.sinstance_name,
                    "table_name": ext.target_table_name,
                })

        # Also extract Pre/Post SQL from SESSTRANSFORMATIONINST attributes
        for ti in session.transformation_insts:
            if ti.pre_sql:
                resolved_sql = self._resolve_session_param(ti.pre_sql, session.name)
                # Avoid duplicates if the same instance already contributed via extension
                already_added = any(
                    e["instance"] == ti.sinstance_name and e["raw_sql"] == ti.pre_sql
                    for e in result["session_pre_sql"]
                )
                if not already_added:
                    result["session_pre_sql"].append({
                        "session": session.name,
                        "instance": ti.sinstance_name,
                        "type": ti.transformation_type,
                        "sql": resolved_sql,
                        "raw_sql": ti.pre_sql,
                    })
            if ti.post_sql:
                resolved_sql = self._resolve_session_param(ti.post_sql, session.name)
                already_added = any(
                    e["instance"] == ti.sinstance_name and e["raw_sql"] == ti.post_sql
                    for e in result["session_post_sql"]
                )
                if not already_added:
                    result["session_post_sql"].append({
                        "session": session.name,
                        "instance": ti.sinstance_name,
                        "type": ti.transformation_type,
                        "sql": resolved_sql,
                        "raw_sql": ti.post_sql,
                    })
            if ti.target_table_name:
                result["target_table_overrides"].append({
                    "session": session.name,
                    "instance": ti.sinstance_name,
                    "table_name": ti.target_table_name,
                })
            if ti.table_name_prefix:
                result["table_name_prefixes"].append({
                    "session": session.name,
                    "instance": ti.sinstance_name,
                    "prefix": ti.table_name_prefix,
                })
            # Collect Owner Name overrides from SESSTRANSFORMATIONINST attributes
            if ti.owner_name:
                result["owner_name_overrides"].append({
                    "session": session.name,
                    "instance": ti.sinstance_name,
                    "transformation_type": ti.transformation_type,
                    "owner_name": ti.owner_name,
                    "source_table_name": ti.source_table_name or "",
                })
            # Collect Source Table Name overrides from SESSTRANSFORMATIONINST attributes
            if ti.source_table_name:
                already_added = any(
                    e["instance"] == ti.sinstance_name and e["table_name"] == ti.source_table_name
                    for e in result["source_table_overrides"]
                )
                if not already_added:
                    result["source_table_overrides"].append({
                        "session": session.name,
                        "instance": ti.sinstance_name,
                        "table_name": ti.source_table_name,
                    })

        # Collect source filters from session extensions
        for ext in session.extensions:
            sf = ext.source_filter
            if sf:
                result["source_filters"].append({
                    "session": session.name,
                    "instance": ext.sinstance_name,
                    "source": "Session Extension",
                    "source_filter": sf,
                })

        return result
