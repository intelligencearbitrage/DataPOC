"""Base expert class for Informatica reverse engineering."""

from abc import ABC, abstractmethod
from dataclasses import dataclass
from enum import Enum
from typing import Any, Dict, List, Optional
import time

from .models.expert_result import ExpertResult, ExpertStatus
from ..parsers.powermart_parser import PowermartDocument
from ..utils.logging_config import get_logger


class ExpertType(Enum):
    """Types of expert agents."""

    MAPPING_STRUCTURE = "mapping_structure"
    FIELD_MAPPING = "field_mapping"
    OPERATOR_LOGIC = "operator_logic"
    INTEGRATION = "integration"
    VISUAL_LINEAGE = "visual_lineage"
    REVIEWER = "reviewer"


@dataclass
class ExpertContext:
    """Context passed to experts for analysis."""

    document: PowermartDocument
    mapping_name: Optional[str] = None
    workflow_name: Optional[str] = None
    previous_results: Dict[str, ExpertResult] = None
    options: Dict[str, Any] = None

    def __post_init__(self):
        if self.previous_results is None:
            self.previous_results = {}
        if self.options is None:
            self.options = {}


class BaseExpert(ABC):
    """
    Abstract base class for Informatica reverse engineering experts.

    Each expert specializes in analyzing a specific aspect of Informatica
    mappings and workflows.
    """

    def __init__(self, name: str, expert_type: ExpertType):
        self.name = name
        self.expert_type = expert_type
        self.logger = get_logger(f"expert.{name}")

    @abstractmethod
    def analyze(self, context: ExpertContext) -> ExpertResult:
        """
        Perform analysis on the provided context.

        Args:
            context: ExpertContext containing document and options

        Returns:
            ExpertResult with analysis results
        """
        pass

    def refine(self, context: ExpertContext, feedback: Dict[str, Any]) -> ExpertResult:
        """
        Refine analysis based on feedback from other experts.

        Default implementation just re-runs analysis.
        Subclasses can override for smarter refinement.

        Args:
            context: ExpertContext with updated previous_results
            feedback: Feedback from reviewer or other experts

        Returns:
            Refined ExpertResult
        """
        return self.analyze(context)

    def _create_result(
        self,
        status: ExpertStatus,
        data: Dict[str, Any] = None,
        errors: List[str] = None,
        warnings: List[str] = None,
        confidence: float = 1.0,
        processing_time_ms: float = 0.0,
    ) -> ExpertResult:
        """Helper to create an ExpertResult."""
        return ExpertResult(
            expert_name=self.name,
            status=status,
            confidence=confidence,
            data=data or {},
            errors=errors or [],
            warnings=warnings or [],
            processing_time_ms=processing_time_ms,
        )

    def _timed_analyze(self, context: ExpertContext) -> ExpertResult:
        """Run analyze with timing."""
        start_time = time.time()
        try:
            result = self.analyze(context)
            result.processing_time_ms = (time.time() - start_time) * 1000
            return result
        except Exception as e:
            self.logger.error(f"Analysis failed: {e}")
            return self._create_result(
                status=ExpertStatus.FAILED,
                errors=[str(e)],
                processing_time_ms=(time.time() - start_time) * 1000,
            )
