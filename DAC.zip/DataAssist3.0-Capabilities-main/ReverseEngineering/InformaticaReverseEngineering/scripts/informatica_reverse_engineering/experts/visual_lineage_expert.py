"""Visual Lineage Expert - Generates visual lineage representations."""

from typing import Any, Dict, List, Optional, Set, Tuple
from collections import defaultdict

from .base_expert import BaseExpert, ExpertType, ExpertContext
from .models.expert_result import ExpertResult, ExpertStatus


class VisualLineageExpert(BaseExpert):
    """
    Expert for generating visual lineage representations.

    Responsibilities:
    - Generate instance-level lineage visualization (one node per transformation)
    - Show complete data flow from source to target with all intermediate transformations
    - Display transformation types, field counts, and expressions
    - Create Cytoscape.js and Mermaid visualizations
    """

    def __init__(self):
        super().__init__("VisualLineageExpert", ExpertType.VISUAL_LINEAGE)

    def analyze(self, context: ExpertContext) -> ExpertResult:
        """Generate visual lineage data."""
        self.logger.info("Starting visual lineage generation")

        field_mapping_result = context.previous_results.get("FieldMapping")

        if not field_mapping_result or not field_mapping_result.is_successful:
            return self._create_result(
                status=ExpertStatus.FAILED,
                errors=["FieldMapping results required for visualization"],
            )

        results = {
            "cytoscape_data": {},
            "mermaid_diagrams": {},
            "summary_graphs": {},
        }
        warnings = []

        # Get lineage graphs (these contain all edges between fields)
        lineage_graphs = field_mapping_result.data.get("lineage_graphs", {})

        # Get SQL overrides indexed by mapping and transformation
        sql_overrides = field_mapping_result.data.get("sql_overrides", [])
        sql_override_map = self._build_sql_override_map(sql_overrides)

        for mapping_name, graph_data in lineage_graphs.items():
            # Get SQL overrides for this mapping
            mapping_sql_overrides = sql_override_map.get(mapping_name, {})

            # Generate instance-level Cytoscape.js data (one node per transformation)
            cytoscape_data = self._generate_instance_level_cytoscape(
                mapping_name, graph_data, mapping_sql_overrides
            )
            results["cytoscape_data"][mapping_name] = cytoscape_data

            # Generate Mermaid diagram at instance level
            mermaid = self._generate_instance_level_mermaid(mapping_name, graph_data)
            results["mermaid_diagrams"][mapping_name] = mermaid

            # Generate summary graph
            summary = self._generate_summary_graph(mapping_name, graph_data)
            results["summary_graphs"][mapping_name] = summary

        self.logger.info(f"Generated visualizations for {len(lineage_graphs)} mappings")

        return self._create_result(
            status=ExpertStatus.COMPLETED,
            data=results,
            warnings=warnings,
            confidence=0.95,
        )

    def _build_sql_override_map(self, sql_overrides: List[Dict]) -> Dict[str, Dict[str, str]]:
        """Build a map of SQL overrides by mapping name and transformation name."""
        result: Dict[str, Dict[str, str]] = {}
        for override in sql_overrides:
            mapping = override.get("mapping", "")
            trans = override.get("transformation", "")
            sql_query = override.get("sql_query", "")
            override_type = override.get("type", "source_qualifier")

            if mapping and trans and sql_query:
                if mapping not in result:
                    result[mapping] = {}
                result[mapping][trans] = {
                    "sql_query": sql_query,
                    "type": override_type,
                }
        return result

    def _generate_instance_level_cytoscape(
        self, mapping_name: str, graph_data: Dict, sql_overrides: Dict[str, Dict] = None
    ) -> Dict[str, Any]:
        """
        Generate Cytoscape.js data at instance level (one node per transformation).

        This shows the data flow between transformations, with field details
        available when clicking on nodes or edges.
        """
        edges_list = graph_data.get("edges", [])
        sql_overrides = sql_overrides or {}

        if not edges_list:
            return {
                "elements": {"nodes": [], "edges": []},
                "mapping_name": mapping_name,
                "statistics": {},
            }

        # Collect instance information
        instances: Dict[str, Dict] = {}  # instance_name -> {type, fields, expressions, field_details}
        instance_connections: Dict[str, Set[str]] = defaultdict(set)  # from_inst -> {to_inst}
        connection_fields: Dict[str, List[Dict]] = defaultdict(list)  # "from->to" -> [field mappings]

        for edge in edges_list:
            source_inst = edge.get("source_instance", "")
            source_field = edge.get("source_field", "")
            source_type = edge.get("source_type", "")
            target_inst = edge.get("target_instance", "")
            target_field = edge.get("target_field", "")
            target_type = edge.get("target_type", "")
            expression = edge.get("expression", "")
            expression_explanation = edge.get("expression_explanation", "")

            # Track source instance
            if source_inst:
                if source_inst not in instances:
                    instances[source_inst] = {
                        "name": source_inst,
                        "type": source_type,
                        "fields": set(),
                        "expressions": [],
                        "field_details": {},  # field_name -> {expression, explanation}
                    }
                instances[source_inst]["fields"].add(source_field)

            # Track target instance
            if target_inst:
                if target_inst not in instances:
                    instances[target_inst] = {
                        "name": target_inst,
                        "type": target_type,
                        "fields": set(),
                        "expressions": [],
                        "field_details": {},  # field_name -> {expression, explanation}
                    }
                instances[target_inst]["fields"].add(target_field)

                # Track expression for this specific field
                if expression or expression_explanation:
                    # Add to expressions list (for backward compatibility)
                    instances[target_inst]["expressions"].append({
                        "field": target_field,
                        "expression": expression,
                        "explanation": expression_explanation,
                    })
                    # Also add to field_details for comprehensive field-level info
                    instances[target_inst]["field_details"][target_field] = {
                        "expression": expression,
                        "explanation": expression_explanation or self._generate_default_explanation(expression),
                    }
                else:
                    # Even for direct mappings, add field detail with explanation
                    if target_field not in instances[target_inst]["field_details"]:
                        instances[target_inst]["field_details"][target_field] = {
                            "expression": "",
                            "explanation": f"Direct mapping from upstream transformation",
                        }

            # Track connection between instances
            if source_inst and target_inst and source_inst != target_inst:
                instance_connections[source_inst].add(target_inst)
                conn_key = f"{source_inst}->{target_inst}"
                connection_fields[conn_key].append({
                    "source_field": source_field,
                    "target_field": target_field,
                    "expression": expression,
                    "expression_explanation": expression_explanation or self._generate_default_explanation(expression, source_field, target_field),
                })

        # Determine which instances are sources (no incoming) and targets (no outgoing)
        all_sources = set(instance_connections.keys())
        all_targets = set()
        for targets in instance_connections.values():
            all_targets.update(targets)

        ultimate_sources = all_sources - all_targets
        ultimate_targets = all_targets - all_sources

        # Color scheme for different node types
        colors = {
            "source": "#4CAF50",
            "source_qualifier": "#66BB6A",
            "target": "#9C27B0",
            "expression": "#2196F3",
            "filter": "#FF5722",
            "aggregator": "#FF9800",
            "lookup": "#FFC107",
            "joiner": "#00BCD4",
            "router": "#E91E63",
            "update_strategy": "#795548",
            "normalizer": "#607D8B",
            "transformation": "#3F51B5",
        }

        # Build nodes
        nodes = []
        for inst_name, inst_data in instances.items():
            node_type = self._get_node_type(inst_data["type"])
            is_source = inst_name in ultimate_sources
            is_target = inst_name in ultimate_targets
            field_count = len(inst_data["fields"])
            expr_count = len(inst_data["expressions"])

            # Get ALL field details with expressions and explanations
            field_details = []
            for field_name in sorted(inst_data["fields"]):
                detail = inst_data.get("field_details", {}).get(field_name, {})
                field_details.append({
                    "field": field_name,
                    "expression": detail.get("expression", ""),
                    "explanation": detail.get("explanation", "Source field - data origin"),
                })

            # Check for SQL override (for source qualifiers and lookups)
            sql_override_info = sql_overrides.get(inst_name, {})
            sql_query = sql_override_info.get("sql_query", "") if sql_override_info else ""

            node_data = {
                "id": inst_name,
                "label": inst_name,
                "type": node_type,
                "instance_type": inst_data["type"],
                "field_count": field_count,
                "expression_count": expr_count,
                "fields": sorted(list(inst_data["fields"])),
                "field_details": field_details,  # All fields with expressions and explanations
                "expressions": inst_data["expressions"],  # Keep for backward compatibility
                "is_source": is_source,
                "is_target": is_target,
            }

            # Add SQL override if present
            if sql_query:
                node_data["sql_override"] = sql_query

            nodes.append({
                "data": node_data,
                "classes": node_type,
                "style": {"background-color": colors.get(node_type, colors["transformation"])},
            })

        # Build edges between instances
        edges = []
        edge_idx = 0
        for source_inst, target_insts in instance_connections.items():
            for target_inst in target_insts:
                conn_key = f"{source_inst}->{target_inst}"
                field_mappings = connection_fields.get(conn_key, [])
                field_count = len(field_mappings)

                # Collect all expressions for this connection
                expressions = [fm["expression"] for fm in field_mappings if fm["expression"]]
                expr_sample = expressions[0] if expressions else ""

                edges.append({
                    "data": {
                        "id": f"e_{edge_idx}",
                        "source": source_inst,
                        "target": target_inst,
                        "field_count": field_count,
                        "field_mappings": field_mappings,
                        "label": f"{field_count} fields",
                        "expression_sample": expr_sample[:50] + "..." if len(expr_sample) > 50 else expr_sample,
                    },
                })
                edge_idx += 1

        # Calculate statistics
        source_count = len(ultimate_sources)
        target_count = len(ultimate_targets)
        transformation_count = len(instances) - source_count - target_count

        return {
            "elements": {
                "nodes": nodes,
                "edges": edges,
            },
            "mapping_name": mapping_name,
            "statistics": {
                "total_instances": len(instances),
                "total_connections": len(edges),
                "source_count": source_count,
                "target_count": target_count,
                "transformation_count": transformation_count,
            },
        }

    def _get_node_type(self, instance_type: str) -> str:
        """Map Informatica instance type to visualization node type."""
        if not instance_type:
            return "transformation"

        instance_lower = instance_type.lower()

        if "source definition" in instance_lower:
            return "source"
        elif "source qualifier" in instance_lower:
            return "source_qualifier"
        elif "target" in instance_lower:
            return "target"
        elif "expression" in instance_lower:
            return "expression"
        elif "filter" in instance_lower:
            return "filter"
        elif "aggregator" in instance_lower:
            return "aggregator"
        elif "lookup" in instance_lower:
            return "lookup"
        elif "joiner" in instance_lower:
            return "joiner"
        elif "router" in instance_lower:
            return "router"
        elif "update strategy" in instance_lower:
            return "update_strategy"
        elif "normalizer" in instance_lower:
            return "normalizer"
        else:
            return "transformation"

    def _generate_instance_level_mermaid(
        self, mapping_name: str, graph_data: Dict
    ) -> str:
        """Generate Mermaid flowchart at instance level."""
        edges_list = graph_data.get("edges", [])

        if not edges_list:
            return f"flowchart LR\n    subgraph {self._sanitize_id(mapping_name)}[\"{mapping_name}\"]\n    end"

        # Collect instance information
        instances: Dict[str, str] = {}  # instance_name -> type
        connections: Set[Tuple[str, str]] = set()

        for edge in edges_list:
            source_inst = edge.get("source_instance", "")
            source_type = edge.get("source_type", "")
            target_inst = edge.get("target_instance", "")
            target_type = edge.get("target_type", "")

            if source_inst:
                instances[source_inst] = source_type
            if target_inst:
                instances[target_inst] = target_type
            if source_inst and target_inst and source_inst != target_inst:
                connections.add((source_inst, target_inst))

        lines = ["flowchart LR"]
        lines.append(f"    subgraph {self._sanitize_id(mapping_name)}[\"{mapping_name}\"]")

        # Add nodes
        for inst_name, inst_type in instances.items():
            node_id = self._sanitize_id(inst_name)
            shape = self._get_mermaid_shape(inst_type)
            lines.append(f"        {node_id}{shape[0]}\"{inst_name}\"{shape[1]}")

        # Add edges
        for source_inst, target_inst in connections:
            source_id = self._sanitize_id(source_inst)
            target_id = self._sanitize_id(target_inst)
            lines.append(f"        {source_id} --> {target_id}")

        lines.append("    end")
        return "\n".join(lines)

    def _get_mermaid_shape(self, instance_type: str) -> Tuple[str, str]:
        """Get Mermaid shape based on transformation type."""
        if not instance_type:
            return "[", "]"

        instance_lower = instance_type.lower()

        if "source" in instance_lower:
            return "([", "])"  # Stadium shape for source
        elif "target" in instance_lower:
            return "[[", "]]"  # Subroutine shape for target
        elif "expression" in instance_lower:
            return "[", "]"   # Rectangle for expression
        elif "filter" in instance_lower:
            return "{", "}"   # Diamond for filter
        elif "aggregator" in instance_lower:
            return "{{", "}}"  # Hexagon for aggregator
        elif "lookup" in instance_lower:
            return "[(", ")]"  # Cylinder for lookup
        elif "router" in instance_lower:
            return "{", "}"   # Diamond for router
        else:
            return "[", "]"   # Default rectangle

    def _generate_summary_graph(
        self, mapping_name: str, graph_data: Dict
    ) -> Dict[str, Any]:
        """Generate a summary showing instance-level flow."""
        instances: Dict[str, Dict] = {}
        connections: List[Dict] = []
        connection_set: Set[str] = set()

        for edge in graph_data.get("edges", []):
            source_inst = edge.get("source_instance", "")
            source_type = edge.get("source_type", "")
            target_inst = edge.get("target_instance", "")
            target_type = edge.get("target_type", "")

            # Track source instance
            if source_inst and source_inst not in instances:
                instances[source_inst] = {
                    "name": source_inst,
                    "type": source_type,
                    "field_count": 0,
                }
            if source_inst:
                instances[source_inst]["field_count"] += 1

            # Track target instance
            if target_inst and target_inst not in instances:
                instances[target_inst] = {
                    "name": target_inst,
                    "type": target_type,
                    "field_count": 0,
                }

            # Track connection between instances
            conn_key = f"{source_inst}->{target_inst}"
            if conn_key not in connection_set and source_inst and target_inst and source_inst != target_inst:
                connection_set.add(conn_key)
                connections.append({
                    "from": source_inst,
                    "to": target_inst,
                })

        return {
            "mapping_name": mapping_name,
            "instances": list(instances.values()),
            "connections": connections,
        }

    def _sanitize_id(self, name: str) -> str:
        """Sanitize name for use as Mermaid ID."""
        sanitized = name.replace(" ", "_").replace("-", "_").replace(".", "_")
        sanitized = "".join(c if c.isalnum() or c == "_" else "_" for c in sanitized)
        if sanitized and not sanitized[0].isalpha():
            sanitized = "n_" + sanitized
        return sanitized

    def _generate_default_explanation(
        self, expression: str, source_field: str = None, target_field: str = None
    ) -> str:
        """Generate a default English explanation for an expression."""
        if not expression:
            if source_field and target_field:
                if source_field.lower() == target_field.lower():
                    return f"Direct passthrough - field value copied without modification"
                else:
                    return f"Field renamed from {source_field} to {target_field}"
            return "Direct mapping from upstream transformation"

        expr_lower = expression.lower().strip()

        # Check for common patterns
        if expr_lower.startswith("'") and expr_lower.endswith("'"):
            return f"Constant value: {expression}"

        if expr_lower.isdigit() or (expr_lower.startswith("-") and expr_lower[1:].isdigit()):
            return f"Constant numeric value: {expression}"

        if "iif(" in expr_lower:
            return f"Conditional logic - returns different values based on condition"

        if "decode(" in expr_lower:
            return f"Lookup/switch logic - maps input value to corresponding output"

        if "isnull(" in expr_lower:
            return f"Null check - tests if value is null"

        if "nvl(" in expr_lower or "nvl2(" in expr_lower:
            return f"Null handling - replaces null with default value"

        if "to_date(" in expr_lower or "to_char(" in expr_lower:
            return f"Date/string conversion"

        if "substr(" in expr_lower or "substring(" in expr_lower:
            return f"Extracts portion of string"

        if "concat(" in expr_lower or "||" in expression:
            return f"Concatenates multiple values into single string"

        if "trunc(" in expr_lower:
            return f"Truncates value (date or number)"

        if "round(" in expr_lower:
            return f"Rounds numeric value"

        if "ltrim(" in expr_lower or "rtrim(" in expr_lower or "trim(" in expr_lower:
            return f"Removes whitespace from string"

        if "upper(" in expr_lower or "lower(" in expr_lower:
            return f"Converts string case"

        if "setvariable(" in expr_lower:
            return f"Sets mapping/workflow variable"

        if "lookup(" in expr_lower or "lkp_" in expr_lower:
            return f"Retrieves value from lookup table"

        if "abort(" in expr_lower:
            return f"Aborts session with error message if condition met"

        if "error(" in expr_lower:
            return f"Generates error if condition met"

        if "+" in expression or "-" in expression or "*" in expression or "/" in expression:
            if any(op in expression for op in ["+", "-", "*", "/"]):
                return f"Arithmetic calculation"

        # If expression is just a field name
        if expression.replace("_", "").isalnum():
            return f"Direct passthrough of field: {expression}"

        return f"Transformation applied: {expression[:50]}..." if len(expression) > 50 else f"Transformation applied"
