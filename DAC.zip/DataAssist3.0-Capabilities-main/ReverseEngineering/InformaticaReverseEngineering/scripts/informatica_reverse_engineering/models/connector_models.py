"""Connector models for Informatica PowerCenter.

CONNECTOR elements are the KEY to field-level lineage extraction.
They define the complete data flow graph from source to target.
"""

from dataclasses import dataclass
from typing import Any, Dict, Optional


@dataclass
class Connector:
    """
    Represents a data flow connection between transformation instances.

    This is the KEY element for field-level lineage extraction.
    Each CONNECTOR defines a single edge in the data flow graph:
    - FROMINSTANCE/FROMFIELD: Source of data
    - TOINSTANCE/TOFIELD: Destination of data

    XML Example:
    <CONNECTOR FROMFIELD="LNKEY" FROMINSTANCE="SQ_LN_MTGTERMS"
               FROMINSTANCETYPE="Source Qualifier"
               TOFIELD="i_LNKEY" TOINSTANCE="exp_COLUMN_SETUP"
               TOINSTANCETYPE="Expression"/>
    """

    from_instance: str
    from_field: str
    from_instance_type: str
    to_instance: str
    to_field: str
    to_instance_type: str

    @property
    def source_key(self) -> str:
        """Get unique key for source node."""
        return f"{self.from_instance}.{self.from_field}"

    @property
    def target_key(self) -> str:
        """Get unique key for target node."""
        return f"{self.to_instance}.{self.to_field}"

    @property
    def edge_key(self) -> str:
        """Get unique key for this edge."""
        return f"{self.source_key}->{self.target_key}"

    @property
    def is_to_target(self) -> bool:
        """Check if this connects to a target."""
        return self.to_instance_type.lower() in ["target definition", "target"]

    @property
    def is_from_source(self) -> bool:
        """Check if this connects from a source."""
        return self.from_instance_type.lower() in ["source definition", "source", "source qualifier"]

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            "from_instance": self.from_instance,
            "from_field": self.from_field,
            "from_instance_type": self.from_instance_type,
            "to_instance": self.to_instance,
            "to_field": self.to_field,
            "to_instance_type": self.to_instance_type,
            "source_key": self.source_key,
            "target_key": self.target_key,
            "is_to_target": self.is_to_target,
            "is_from_source": self.is_from_source,
        }

    def __hash__(self) -> int:
        return hash(self.edge_key)

    def __eq__(self, other: object) -> bool:
        if not isinstance(other, Connector):
            return False
        return self.edge_key == other.edge_key
