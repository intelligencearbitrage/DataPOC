"""Workflow models for Informatica PowerCenter."""

from collections import deque
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

from .base_models import BaseModel
from .session_models import Session, SessionAttribute


@dataclass
class WorkflowVariable:
    """Workflow variable."""

    name: str
    datatype: str
    default_value: str = ""
    is_null: bool = False
    is_persistent: bool = False
    precision: int = 0
    scale: int = 0
    user_defined: bool = True
    description: str = ""

    def to_dict(self) -> Dict[str, Any]:
        return {
            "name": self.name,
            "datatype": self.datatype,
            "default_value": self.default_value,
            "is_null": self.is_null,
            "is_persistent": self.is_persistent,
            "description": self.description,
        }


@dataclass
class ScheduleInfo:
    """Schedule information."""

    schedule_type: str  # "ONDEMAND", "SCHEDULED", "REUSABLE"
    start_date: str = ""
    start_time: str = ""
    end_date: str = ""
    end_time: str = ""
    repeat_interval: str = ""

    def to_dict(self) -> Dict[str, Any]:
        return {
            "schedule_type": self.schedule_type,
            "start_date": self.start_date,
            "start_time": self.start_time,
            "end_date": self.end_date,
            "end_time": self.end_time,
            "repeat_interval": self.repeat_interval,
        }


@dataclass
class Scheduler:
    """Workflow scheduler."""

    name: str
    reusable: bool = False
    version_number: int = 1
    description: str = ""
    schedule_info: Optional[ScheduleInfo] = None

    def to_dict(self) -> Dict[str, Any]:
        return {
            "name": self.name,
            "reusable": self.reusable,
            "description": self.description,
            "schedule_info": self.schedule_info.to_dict() if self.schedule_info else None,
        }


@dataclass
class Task:
    """Workflow task (Start, Email, Command, etc.)."""

    name: str
    task_type: str  # "Start", "Email", "Command", "Session", "Control", "Decision", "Wait"
    description: str = ""
    reusable: bool = False
    version_number: int = 1
    attributes: List[SessionAttribute] = field(default_factory=list)

    def get_attribute(self, name: str) -> Optional[str]:
        """Get attribute value by name."""
        name_lower = name.lower()
        for attr in self.attributes:
            if attr.name.lower() == name_lower:
                return attr.value
        return None

    @property
    def is_start(self) -> bool:
        return self.task_type.lower() == "start"

    @property
    def is_session(self) -> bool:
        return self.task_type.lower() == "session"

    @property
    def is_email(self) -> bool:
        return self.task_type.lower() == "email"

    @property
    def is_command(self) -> bool:
        return self.task_type.lower() == "command"

    @property
    def is_worklet(self) -> bool:
        return self.task_type.lower() == "worklet"

    def to_dict(self) -> Dict[str, Any]:
        return {
            "name": self.name,
            "task_type": self.task_type,
            "description": self.description,
            "reusable": self.reusable,
            "is_start": self.is_start,
            "is_session": self.is_session,
            "is_worklet": self.is_worklet,
            "attributes": [a.to_dict() for a in self.attributes],
        }


@dataclass
class WorkflowLink:
    """
    Workflow link connecting tasks.

    Defines control flow between tasks with optional conditions.
    """

    from_task: str
    to_task: str
    condition: str = ""  # Condition expression for conditional execution

    @property
    def is_conditional(self) -> bool:
        """Check if link has a condition."""
        return bool(self.condition and self.condition.strip())

    @property
    def is_success_condition(self) -> bool:
        """Check if link depends on success status."""
        return "SUCCEEDED" in self.condition.upper() if self.condition else False

    @property
    def is_failure_condition(self) -> bool:
        """Check if link depends on failure status."""
        return "FAILED" in self.condition.upper() if self.condition else False

    def to_dict(self) -> Dict[str, Any]:
        return {
            "from_task": self.from_task,
            "to_task": self.to_task,
            "condition": self.condition,
            "is_conditional": self.is_conditional,
            "is_success_condition": self.is_success_condition,
            "is_failure_condition": self.is_failure_condition,
        }


@dataclass
class Worklet(BaseModel):
    """Represents an Informatica worklet (reusable sub-workflow)."""

    is_valid: bool = True
    version_number: int = 1
    scheduler: Optional[Scheduler] = None
    tasks: List[Task] = field(default_factory=list)
    sessions: List[Session] = field(default_factory=list)
    links: List[WorkflowLink] = field(default_factory=list)
    variables: List[WorkflowVariable] = field(default_factory=list)
    attributes: List[SessionAttribute] = field(default_factory=list)

    def get_execution_order(self) -> List[str]:
        """Get the execution order of tasks via topological sort."""
        in_degree: Dict[str, int] = {}
        adjacency: Dict[str, List[str]] = {}

        for task in self.tasks:
            in_degree[task.name] = 0
            adjacency[task.name] = []

        for session in self.sessions:
            if session.name not in in_degree:
                in_degree[session.name] = 0
                adjacency[session.name] = []

        for link in self.links:
            if link.from_task not in in_degree:
                in_degree[link.from_task] = 0
                adjacency[link.from_task] = []
            if link.to_task not in in_degree:
                in_degree[link.to_task] = 0
                adjacency[link.to_task] = []
            adjacency[link.from_task].append(link.to_task)
            in_degree[link.to_task] += 1

        queue = deque([name for name, degree in in_degree.items() if degree == 0])
        result = []
        while queue:
            task_name = queue.popleft()
            result.append(task_name)
            for next_task in adjacency.get(task_name, []):
                if next_task in in_degree:
                    in_degree[next_task] -= 1
                    if in_degree[next_task] == 0:
                        queue.append(next_task)
        return result

    def to_dict(self) -> Dict[str, Any]:
        return {
            "name": self.name,
            "description": self.description,
            "is_valid": self.is_valid,
            "task_count": len(self.tasks),
            "session_count": len(self.sessions),
            "link_count": len(self.links),
            "execution_order": self.get_execution_order(),
            "tasks": [t.to_dict() for t in self.tasks],
            "sessions": [s.to_dict() for s in self.sessions],
            "links": [l.to_dict() for l in self.links],
            "variables": [v.to_dict() for v in self.variables],
        }


@dataclass
class Workflow(BaseModel):
    """Represents an Informatica workflow."""

    is_enabled: bool = True
    is_valid: bool = True
    is_service: bool = False
    is_runnable_service: bool = False
    reusable_scheduler: bool = False
    scheduler_name: str = ""
    server_name: str = ""
    server_domain_name: str = ""
    suspend_on_error: bool = False
    tasks_must_run_on_server: bool = False
    version_number: int = 1
    scheduler: Optional[Scheduler] = None
    tasks: List[Task] = field(default_factory=list)
    sessions: List[Session] = field(default_factory=list)
    links: List[WorkflowLink] = field(default_factory=list)
    variables: List[WorkflowVariable] = field(default_factory=list)
    attributes: List[SessionAttribute] = field(default_factory=list)
    worklets: List[Worklet] = field(default_factory=list)

    @property
    def start_task(self) -> Optional[Task]:
        """Get the start task."""
        for task in self.tasks:
            if task.is_start:
                return task
        return None

    @property
    def session_tasks(self) -> List[Task]:
        """Get all session tasks."""
        return [t for t in self.tasks if t.is_session]

    def get_task(self, name: str) -> Optional[Task]:
        """Get task by name (case-insensitive)."""
        name_lower = name.lower()
        for task in self.tasks:
            if task.name.lower() == name_lower:
                return task
        return None

    def get_session(self, name: str) -> Optional[Session]:
        """Get session by name (case-insensitive)."""
        name_lower = name.lower()
        for session in self.sessions:
            if session.name.lower() == name_lower:
                return session
        return None

    def get_links_from(self, task_name: str) -> List[WorkflowLink]:
        """Get all links from a specific task."""
        return [l for l in self.links if l.from_task.lower() == task_name.lower()]

    def get_links_to(self, task_name: str) -> List[WorkflowLink]:
        """Get all links to a specific task."""
        return [l for l in self.links if l.to_task.lower() == task_name.lower()]

    def get_execution_order(self) -> List[str]:
        """
        Get the execution order of tasks.

        Returns list of task names in topological order.
        """
        # Build adjacency list and in-degree count
        in_degree: Dict[str, int] = {}
        adjacency: Dict[str, List[str]] = {}

        # Initialize with tasks
        for task in self.tasks:
            in_degree[task.name] = 0
            adjacency[task.name] = []

        # Also include sessions as tasks (sessions can be referenced in workflow links)
        for session in self.sessions:
            if session.name not in in_degree:
                in_degree[session.name] = 0
                adjacency[session.name] = []

        # Build graph - also ensure any referenced tasks exist
        for link in self.links:
            # Ensure both tasks exist in the dictionaries
            if link.from_task not in in_degree:
                in_degree[link.from_task] = 0
                adjacency[link.from_task] = []
            if link.to_task not in in_degree:
                in_degree[link.to_task] = 0
                adjacency[link.to_task] = []

            adjacency[link.from_task].append(link.to_task)
            in_degree[link.to_task] += 1

        # Topological sort
        queue = deque([name for name, degree in in_degree.items() if degree == 0])
        result = []

        while queue:
            task_name = queue.popleft()
            result.append(task_name)

            for next_task in adjacency.get(task_name, []):
                if next_task in in_degree:
                    in_degree[next_task] -= 1
                    if in_degree[next_task] == 0:
                        queue.append(next_task)

        return result

    def to_dict(self) -> Dict[str, Any]:
        return {
            "name": self.name,
            "description": self.description,
            "is_enabled": self.is_enabled,
            "is_valid": self.is_valid,
            "server_name": self.server_name,
            "server_domain_name": self.server_domain_name,
            "scheduler": self.scheduler.to_dict() if self.scheduler else None,
            "task_count": len(self.tasks),
            "session_count": len(self.sessions),
            "link_count": len(self.links),
            "variable_count": len(self.variables),
            "execution_order": self.get_execution_order(),
            "tasks": [t.to_dict() for t in self.tasks],
            "sessions": [s.to_dict() for s in self.sessions],
            "links": [l.to_dict() for l in self.links],
            "variables": [v.to_dict() for v in self.variables],
            "worklets": [w.to_dict() for w in self.worklets],
        }
