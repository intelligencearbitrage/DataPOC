"""Session models for Informatica PowerCenter."""

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

from .base_models import BaseModel


@dataclass
class SessionAttribute:
    """Session-level attribute."""

    name: str
    value: str

    def to_dict(self) -> Dict[str, Any]:
        return {"name": self.name, "value": self.value}


@dataclass
class Partition:
    """Session partition."""

    name: str
    description: str = ""

    def to_dict(self) -> Dict[str, Any]:
        return {"name": self.name, "description": self.description}


@dataclass
class ConnectionReference:
    """Database connection reference."""

    cnx_ref_name: str
    connection_name: str
    connection_number: int
    connection_type: str  # "Relational", "Application", etc.
    connection_subtype: str = ""
    variable: str = ""  # $DBConnection_source, $DBConnection_target

    def to_dict(self) -> Dict[str, Any]:
        return {
            "cnx_ref_name": self.cnx_ref_name,
            "connection_name": self.connection_name,
            "connection_number": self.connection_number,
            "connection_type": self.connection_type,
            "connection_subtype": self.connection_subtype,
            "variable": self.variable,
        }


@dataclass
class SessionTransformationInst:
    """Session transformation instance (SESSTRANSFORMATIONINST)."""

    sinstance_name: str
    transformation_name: str
    transformation_type: str
    stage: int
    pipeline: int
    is_repartition_point: bool = False
    partition_type: str = ""  # "PASS THROUGH", "ROUND ROBIN", etc.
    partitions: List[Partition] = field(default_factory=list)
    attributes: List[SessionAttribute] = field(default_factory=list)

    def get_attribute(self, name: str) -> Optional[str]:
        """Get attribute value by name."""
        name_lower = name.lower()
        for attr in self.attributes:
            if attr.name.lower() == name_lower:
                return attr.value
        return None

    @property
    def owner_name(self) -> Optional[str]:
        """Get Owner Name from transformation instance attributes."""
        return self.get_attribute("Owner Name")

    @property
    def source_table_name(self) -> Optional[str]:
        """Get Source Table Name from transformation instance attributes."""
        return self.get_attribute("Source Table Name")

    @property
    def pre_sql(self) -> Optional[str]:
        """Get Pre SQL from transformation instance attributes."""
        return self.get_attribute("Pre SQL")

    @property
    def post_sql(self) -> Optional[str]:
        """Get Post SQL from transformation instance attributes."""
        return self.get_attribute("Post SQL")

    @property
    def target_table_name(self) -> Optional[str]:
        """Get Target Table Name from transformation instance attributes."""
        return self.get_attribute("Target Table Name")

    @property
    def table_name_prefix(self) -> Optional[str]:
        """Get Table Name Prefix (owner/schema) from transformation instance attributes."""
        return self.get_attribute("Table Name Prefix")

    def to_dict(self) -> Dict[str, Any]:
        return {
            "sinstance_name": self.sinstance_name,
            "transformation_name": self.transformation_name,
            "transformation_type": self.transformation_type,
            "stage": self.stage,
            "pipeline": self.pipeline,
            "is_repartition_point": self.is_repartition_point,
            "partition_type": self.partition_type,
            "partitions": [p.to_dict() for p in self.partitions],
            "attributes": [a.to_dict() for a in self.attributes],
            "owner_name": self.owner_name,
            "source_table_name": self.source_table_name,
            "pre_sql": self.pre_sql,
            "post_sql": self.post_sql,
            "target_table_name": self.target_table_name,
            "table_name_prefix": self.table_name_prefix,
        }


@dataclass
class SessionExtension:
    """Session extension for readers/writers/lookups."""

    name: str
    sinstance_name: str
    extension_type: str  # "WRITER", "READER", "LOOKUPEXTENSION"
    subtype: str  # "Relational Writer", "Relational Reader", etc.
    transformation_type: str
    dsq_inst_name: str = ""  # Data source qualifier instance name
    dsq_inst_type: str = ""
    connections: List[ConnectionReference] = field(default_factory=list)
    attributes: List[SessionAttribute] = field(default_factory=list)

    def get_attribute(self, name: str) -> Optional[str]:
        """Get attribute value by name."""
        name_lower = name.lower()
        for attr in self.attributes:
            if attr.name.lower() == name_lower:
                return attr.value
        return None

    @property
    def target_load_type(self) -> Optional[str]:
        """Get target load type for writer extensions."""
        return self.get_attribute("Target load type")

    @property
    def truncate_target(self) -> bool:
        """Check if target should be truncated."""
        val = self.get_attribute("Truncate target table option")
        return val and val.upper() == "YES"

    @property
    def pre_sql(self) -> Optional[str]:
        return self.get_attribute("Pre SQL")

    @property
    def post_sql(self) -> Optional[str]:
        return self.get_attribute("Post SQL")

    @property
    def sql_override(self) -> Optional[str]:
        return self.get_attribute("Sql Query")

    @property
    def source_table_name(self) -> Optional[str]:
        return self.get_attribute("Source Table Name")

    @property
    def target_table_name(self) -> Optional[str]:
        return self.get_attribute("Target Table Name")

    @property
    def source_filter(self) -> Optional[str]:
        return self.get_attribute("Source filter")

    def to_dict(self) -> Dict[str, Any]:
        return {
            "name": self.name,
            "sinstance_name": self.sinstance_name,
            "extension_type": self.extension_type,
            "subtype": self.subtype,
            "transformation_type": self.transformation_type,
            "dsq_inst_name": self.dsq_inst_name,
            "connections": [c.to_dict() for c in self.connections],
            "attributes": [a.to_dict() for a in self.attributes],
            "pre_sql": self.pre_sql,
            "post_sql": self.post_sql,
            "sql_override": self.sql_override,
            "source_table_name": self.source_table_name,
            "target_table_name": self.target_table_name,
            "source_filter": self.source_filter,
        }


@dataclass
class SessionComponent:
    """Session component (Email, variable assignment, etc.)."""

    ref_object_name: str
    component_type: str  # "Failure Email", "Success Email", "Pre-session variable assignment", etc.
    reusable: bool = False
    task_name: str = ""
    task_type: str = ""
    attributes: List[SessionAttribute] = field(default_factory=list)
    value_pairs: List[Dict[str, str]] = field(default_factory=list)  # [{exec_order, name, value}]

    def to_dict(self) -> Dict[str, Any]:
        return {
            "ref_object_name": self.ref_object_name,
            "component_type": self.component_type,
            "reusable": self.reusable,
            "task_name": self.task_name,
            "task_type": self.task_type,
            "attributes": [a.to_dict() for a in self.attributes],
            "value_pairs": self.value_pairs,
        }


@dataclass
class ConfigReference:
    """Configuration reference."""

    ref_object_name: str
    config_type: str  # "Session config"

    def to_dict(self) -> Dict[str, Any]:
        return {"ref_object_name": self.ref_object_name, "config_type": self.config_type}


@dataclass
class Session(BaseModel):
    """Represents an Informatica session."""

    mapping_name: str = ""
    is_valid: bool = True
    reusable: bool = False
    sort_order: str = "Binary"
    version_number: int = 1
    transformation_insts: List[SessionTransformationInst] = field(default_factory=list)
    extensions: List[SessionExtension] = field(default_factory=list)
    components: List[SessionComponent] = field(default_factory=list)
    config_refs: List[ConfigReference] = field(default_factory=list)
    attributes: List[SessionAttribute] = field(default_factory=list)

    def get_attribute(self, name: str) -> Optional[str]:
        """Get session attribute value by name."""
        name_lower = name.lower()
        for attr in self.attributes:
            if attr.name.lower() == name_lower:
                return attr.value
        return None

    @property
    def commit_interval(self) -> Optional[int]:
        """Get commit interval."""
        val = self.get_attribute("Commit Interval")
        return int(val) if val else None

    @property
    def pre_session_commands(self) -> List[SessionComponent]:
        """Get pre-session components."""
        return [c for c in self.components if "pre-session" in c.component_type.lower()]

    @property
    def post_session_commands(self) -> List[SessionComponent]:
        """Get post-session components."""
        return [c for c in self.components if "post-session" in c.component_type.lower()]

    @property
    def readers(self) -> List[SessionExtension]:
        """Get reader extensions."""
        return [e for e in self.extensions if e.extension_type.upper() == "READER"]

    @property
    def writers(self) -> List[SessionExtension]:
        """Get writer extensions."""
        return [e for e in self.extensions if e.extension_type.upper() == "WRITER"]

    @property
    def lookups(self) -> List[SessionExtension]:
        """Get lookup extensions."""
        return [e for e in self.extensions if e.extension_type.upper() == "LOOKUPEXTENSION"]

    @property
    def all_pre_sql(self) -> List[Dict[str, str]]:
        """Collect all Pre SQL from extensions and transformation instances."""
        results = []
        for ext in self.extensions:
            if ext.pre_sql:
                results.append({"instance": ext.sinstance_name, "type": ext.extension_type, "sql": ext.pre_sql})
        for ti in self.transformation_insts:
            if ti.pre_sql:
                # Avoid duplicates if the same instance already contributed via extension
                already_added = any(r["instance"] == ti.sinstance_name and r["sql"] == ti.pre_sql for r in results)
                if not already_added:
                    results.append({"instance": ti.sinstance_name, "type": ti.transformation_type, "sql": ti.pre_sql})
        return results

    @property
    def all_post_sql(self) -> List[Dict[str, str]]:
        """Collect all Post SQL from extensions and transformation instances."""
        results = []
        for ext in self.extensions:
            if ext.post_sql:
                results.append({"instance": ext.sinstance_name, "type": ext.extension_type, "sql": ext.post_sql})
        for ti in self.transformation_insts:
            if ti.post_sql:
                already_added = any(r["instance"] == ti.sinstance_name and r["sql"] == ti.post_sql for r in results)
                if not already_added:
                    results.append({"instance": ti.sinstance_name, "type": ti.transformation_type, "sql": ti.post_sql})
        return results

    @property
    def sql_overrides(self) -> List[Dict[str, str]]:
        """Collect all SQL overrides from reader extensions."""
        results = []
        for ext in self.extensions:
            if ext.sql_override:
                results.append({"instance": ext.sinstance_name, "sql": ext.sql_override})
        return results

    @property
    def source_table_overrides(self) -> List[Dict[str, str]]:
        """Collect source table name overrides."""
        results = []
        for ext in self.readers:
            if ext.source_table_name:
                results.append({"instance": ext.sinstance_name, "table_name": ext.source_table_name})
        return results

    def to_dict(self) -> Dict[str, Any]:
        return {
            "name": self.name,
            "description": self.description,
            "mapping_name": self.mapping_name,
            "is_valid": self.is_valid,
            "reusable": self.reusable,
            "transformation_inst_count": len(self.transformation_insts),
            "extension_count": len(self.extensions),
            "component_count": len(self.components),
            "transformation_insts": [t.to_dict() for t in self.transformation_insts],
            "extensions": [e.to_dict() for e in self.extensions],
            "components": [c.to_dict() for c in self.components],
            "config_refs": [c.to_dict() for c in self.config_refs],
            "attributes": [a.to_dict() for a in self.attributes],
        }
