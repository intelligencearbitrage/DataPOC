"""Transformation models for Informatica PowerCenter."""

from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict, List, Optional

from .base_models import BaseModel, FieldBase


class TransformationType(Enum):
    """Informatica transformation types."""

    EXPRESSION = "Expression"
    SOURCE_QUALIFIER = "Source Qualifier"
    LOOKUP_PROCEDURE = "Lookup Procedure"
    FILTER = "Filter"
    AGGREGATOR = "Aggregator"
    NORMALIZER = "Normalizer"
    ROUTER = "Router"
    JOINER = "Joiner"
    UPDATE_STRATEGY = "Update Strategy"
    CUSTOM = "Custom Transformation"
    SEQUENCE_GENERATOR = "Sequence Generator"
    UNION = "Union"
    SORTER = "Sorter"
    RANK = "Rank"
    SQL = "SQL Transformation"
    STORED_PROCEDURE = "Stored Procedure"
    SOURCE_DEFINITION = "Source Definition"
    TARGET_DEFINITION = "Target Definition"
    UNKNOWN = "Unknown"

    @classmethod
    def from_string(cls, type_str: str) -> "TransformationType":
        """Convert string to TransformationType."""
        type_map = {t.value.lower(): t for t in cls}
        # Treat XML Source Qualifier as a Source Qualifier subtype
        type_map["xml source qualifier"] = cls.SOURCE_QUALIFIER
        type_str_lower = type_str.lower().strip()
        return type_map.get(type_str_lower, cls.UNKNOWN)


class PortType(Enum):
    """Transformation port types."""

    INPUT = "INPUT"
    OUTPUT = "OUTPUT"
    INPUT_OUTPUT = "INPUT/OUTPUT"
    LOOKUP = "LOOKUP"
    LOOKUP_RETURN = "LOOKUP/RETURN"
    LOOKUP_RETURN_OUTPUT = "LOOKUP/RETURN/OUTPUT"
    LOCAL_VARIABLE = "LOCAL VARIABLE"
    UNKNOWN = "UNKNOWN"

    @classmethod
    def from_string(cls, port_str: str) -> "PortType":
        """Convert string to PortType."""
        port_map = {p.value.lower(): p for p in cls}
        return port_map.get(port_str.lower().strip(), cls.UNKNOWN)


@dataclass
class RouterGroup:
    """Router transformation group definition."""

    name: str
    expression: str
    order: int = 0
    group_type: str = ""       # "OUTPUT" or "OUTPUT/DEFAULT"
    description: str = ""

    @property
    def is_default(self) -> bool:
        return "DEFAULT" in self.group_type.upper() if self.group_type else False

    def to_dict(self) -> Dict[str, Any]:
        return {
            "name": self.name,
            "expression": self.expression,
            "order": self.order,
            "group_type": self.group_type,
            "description": self.description,
            "is_default": self.is_default,
        }


@dataclass
class TableAttribute:
    """Transformation table attribute (configuration)."""

    name: str
    value: str

    def to_dict(self) -> Dict[str, Any]:
        return {"name": self.name, "value": self.value}


@dataclass
class TransformField(FieldBase):
    """Represents a field/port in an Informatica transformation."""

    port_type: str = "INPUT"  # INPUT, OUTPUT, INPUT/OUTPUT, LOOKUP, LOCAL VARIABLE
    expression: str = ""  # Transformation expression
    expression_type: str = ""  # GENERAL, GROUPBY, AGGREGATE
    default_value: str = ""
    picture_text: str = ""
    ref_source_field: str = ""  # For Normalizer - reference to source field
    group: str = ""  # GROUP attribute for Union/Custom transformations (e.g., "NATURAL_KEY_1")

    @property
    def port_type_enum(self) -> PortType:
        """Get port type as enum."""
        return PortType.from_string(self.port_type)

    @property
    def is_input(self) -> bool:
        """Check if port is an input."""
        return self.port_type in ["INPUT", "INPUT/OUTPUT", "LOOKUP"]

    @property
    def is_output(self) -> bool:
        """Check if port is an output."""
        return self.port_type in ["OUTPUT", "INPUT/OUTPUT", "LOOKUP/RETURN/OUTPUT"]

    @property
    def is_local_variable(self) -> bool:
        """Check if port is a local variable."""
        return self.port_type == "LOCAL VARIABLE"

    @property
    def has_expression(self) -> bool:
        """Check if field has a transformation expression."""
        return bool(self.expression and self.expression.strip())

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        result = super().to_dict()
        result.update({
            "port_type": self.port_type,
            "expression": self.expression,
            "expression_type": self.expression_type,
            "default_value": self.default_value,
            "is_input": self.is_input,
            "is_output": self.is_output,
            "is_local_variable": self.is_local_variable,
            "has_expression": self.has_expression,
        })
        return result


@dataclass
class Transformation(BaseModel):
    """Represents an Informatica transformation."""

    type: str = ""  # Expression, Source Qualifier, Filter, etc.
    reusable: bool = False
    fields: List[TransformField] = field(default_factory=list)
    attributes: List[TableAttribute] = field(default_factory=list)
    groups: List[RouterGroup] = field(default_factory=list)
    object_version: int = 1
    version_number: int = 1
    template_id: str = ""  # For Custom transformations
    template_name: str = ""  # For Custom transformations

    @property
    def transformation_type(self) -> TransformationType:
        """Get transformation type as enum."""
        return TransformationType.from_string(self.type)

    @property
    def input_fields(self) -> List[TransformField]:
        """Get input ports."""
        return [f for f in self.fields if f.is_input]

    @property
    def output_fields(self) -> List[TransformField]:
        """Get output ports."""
        return [f for f in self.fields if f.is_output]

    @property
    def local_variables(self) -> List[TransformField]:
        """Get local variable ports."""
        return [f for f in self.fields if f.is_local_variable]

    @property
    def expressions(self) -> List[TransformField]:
        """Get fields with expressions."""
        return [f for f in self.fields if f.has_expression]

    def get_attribute(self, name: str) -> Optional[str]:
        """Get attribute value by name (case-insensitive)."""
        name_lower = name.lower()
        for attr in self.attributes:
            if attr.name.lower() == name_lower:
                return attr.value
        return None

    def get_field(self, name: str) -> Optional[TransformField]:
        """Get field by name (case-insensitive)."""
        name_lower = name.lower()
        for fld in self.fields:
            if fld.name.lower() == name_lower:
                return fld
        return None

    @property
    def sql_query(self) -> Optional[str]:
        """Get SQL query override if present (for Source Qualifier)."""
        return self.get_attribute("Sql Query")

    @property
    def filter_condition(self) -> Optional[str]:
        """Get filter condition if present (for Filter transformation)."""
        return self.get_attribute("Filter Condition")

    @property
    def lookup_condition(self) -> Optional[str]:
        """Get lookup condition if present (for Lookup transformation)."""
        return self.get_attribute("Lookup condition")

    @property
    def lookup_sql_override(self) -> Optional[str]:
        """Get lookup SQL override if present."""
        return self.get_attribute("Lookup Sql Override")

    @property
    def update_strategy_expression(self) -> Optional[str]:
        """Get update strategy expression if present."""
        return self.get_attribute("Update Strategy Expression")

    @property
    def router_groups(self) -> List[RouterGroup]:
        """Get router groups sorted by order."""
        return sorted(self.groups, key=lambda g: g.order)

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            "name": self.name,
            "description": self.description,
            "type": self.type,
            "transformation_type": self.transformation_type.value,
            "reusable": self.reusable,
            "field_count": len(self.fields),
            "input_count": len(self.input_fields),
            "output_count": len(self.output_fields),
            "fields": [f.to_dict() for f in self.fields],
            "attributes": [a.to_dict() for a in self.attributes],
            "groups": [g.to_dict() for g in self.groups],
            "sql_query": self.sql_query,
            "filter_condition": self.filter_condition,
            "lookup_condition": self.lookup_condition,
        }
