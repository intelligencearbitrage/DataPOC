"""Lineage models for field-level data lineage."""

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Set
from enum import Enum


class LineageNodeType(Enum):
    """Types of nodes in the lineage graph."""

    SOURCE = "source"
    TARGET = "target"
    TRANSFORMATION = "transformation"
    LOOKUP = "lookup"
    UNKNOWN = "unknown"


@dataclass
class FieldLineageEdge:
    """
    Single edge in the field-level lineage graph.

    Represents a data flow from one field to another through a transformation.
    """

    source_instance: str
    source_field: str
    source_type: str  # Instance type (Source Definition, Expression, etc.)
    target_instance: str
    target_field: str
    target_type: str  # Instance type
    expression: str = ""  # Transformation expression if applicable
    expression_explanation: str = ""  # English explanation of the expression

    @property
    def edge_id(self) -> str:
        """Get unique edge identifier."""
        return f"{self.source_instance}.{self.source_field}->{self.target_instance}.{self.target_field}"

    @property
    def is_direct_mapping(self) -> bool:
        """Check if this is a direct field mapping (no transformation)."""
        return not self.expression or self.source_field.lower() == self.target_field.lower()

    def to_dict(self) -> Dict[str, Any]:
        return {
            "source_instance": self.source_instance,
            "source_field": self.source_field,
            "source_type": self.source_type,
            "target_instance": self.target_instance,
            "target_field": self.target_field,
            "target_type": self.target_type,
            "expression": self.expression,
            "expression_explanation": self.expression_explanation,
            "is_direct_mapping": self.is_direct_mapping,
        }


@dataclass
class LineageNode:
    """Node in the lineage graph (a specific field in an instance)."""

    instance_name: str
    field_name: str
    instance_type: str
    node_type: LineageNodeType = LineageNodeType.UNKNOWN
    datatype: str = ""
    expression: str = ""

    @property
    def node_id(self) -> str:
        """Get unique node identifier."""
        return f"{self.instance_name}.{self.field_name}"

    def to_dict(self) -> Dict[str, Any]:
        return {
            "instance_name": self.instance_name,
            "field_name": self.field_name,
            "instance_type": self.instance_type,
            "node_type": self.node_type.value,
            "datatype": self.datatype,
            "expression": self.expression,
            "node_id": self.node_id,
        }


@dataclass
class EndToEndFieldLineage:
    """
    Complete source-to-target lineage for a single target field.

    Represents the full data flow path from ultimate source(s) to a target field.
    """

    target_table: str
    target_field: str
    target_datatype: str = ""
    mapping_name: str = ""  # Source mapping name
    session_name: str = ""  # Session name for session-scoped param resolution
    ultimate_sources: List[Dict[str, str]] = field(default_factory=list)  # [{table, field, datatype}]
    intermediate_steps: List[FieldLineageEdge] = field(default_factory=list)
    transformation_chain: str = ""  # Human-readable transformation chain
    transformation_explanation: str = ""  # English explanation
    hop_count: int = 0
    lookup_tables: List[str] = field(default_factory=list)
    aggregation_applied: bool = False
    filter_applied: bool = False
    filter_condition: str = ""
    router_applied: bool = False
    router_condition: str = ""
    joiner_condition: str = ""
    joiner_type: str = ""
    update_strategy: str = ""
    sql_override: str = ""
    source_qualifier_name: str = ""
    resolved_sql_override: str = ""
    custom_transformation_inputs: List[Dict[str, str]] = field(default_factory=list)  # [{input_field, from_instance, from_field, union_group?}]
    lookup_name: str = ""  # Feedback #4: lookup transformation instance name(s)
    lookup_condition: str = ""  # Feedback #4: lookup join condition(s)
    lookup_sql_override: str = ""  # Feedback #4: lookup SQL override(s)
    sql_logic: str = ""  # SQL-like representation of the transformation logic
    union_details: Dict[str, Any] = field(default_factory=dict)  # {union_name, group_count, groups, group_fields}
    lookup_input_lineage: str = ""  # Backtracking for lookup condition input fields

    @property
    def has_transformation(self) -> bool:
        """Check if any transformation is applied."""
        return any(not e.is_direct_mapping for e in self.intermediate_steps)

    @property
    def source_tables(self) -> List[str]:
        """Get list of unique source tables."""
        tables = set()
        for src in self.ultimate_sources:
            if src.get("table"):
                tables.add(src["table"])
        return sorted(tables)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "target_table": self.target_table,
            "target_field": self.target_field,
            "target_datatype": self.target_datatype,
            "mapping_name": self.mapping_name,
            "session_name": self.session_name,
            "ultimate_sources": self.ultimate_sources,
            "source_tables": self.source_tables,
            "intermediate_steps": [s.to_dict() for s in self.intermediate_steps],
            "transformation_chain": self.transformation_chain,
            "transformation_explanation": self.transformation_explanation,
            "hop_count": self.hop_count,
            "lookup_tables": self.lookup_tables,
            "has_transformation": self.has_transformation,
            "aggregation_applied": self.aggregation_applied,
            "filter_applied": self.filter_applied,
            "filter_condition": self.filter_condition,
            "router_applied": self.router_applied,
            "router_condition": self.router_condition,
            "joiner_condition": self.joiner_condition,
            "joiner_type": self.joiner_type,
            "update_strategy": self.update_strategy,
            "sql_override": self.sql_override,
            "source_qualifier_name": self.source_qualifier_name,
            "resolved_sql_override": self.resolved_sql_override,
            "custom_transformation_inputs": self.custom_transformation_inputs,
            "lookup_name": self.lookup_name,
            "lookup_condition": self.lookup_condition,
            "lookup_sql_override": self.lookup_sql_override,
            "sql_logic": self.sql_logic,
            "union_details": self.union_details,
            "lookup_input_lineage": self.lookup_input_lineage,
        }

    def to_row(self) -> Dict[str, Any]:
        """Convert to row format for Excel/CSV export."""
        # Build ultimate source table and field strings
        ultimate_source_tables = []
        ultimate_source_fields = []
        ultimate_source_datatypes = []
        for src in self.ultimate_sources:
            table = src.get("table", "")
            field = src.get("field", "")
            datatype = src.get("datatype", "")
            if table:
                ultimate_source_tables.append(table)
            if field:
                ultimate_source_fields.append(f"{table}.{field}" if table else field)
            if datatype:
                ultimate_source_datatypes.append(datatype)

        lookups_str = "; ".join(self.lookup_tables) if self.lookup_tables else ""

        return {
            "Mapping Name": self.mapping_name,
            "Target Table": self.target_table,
            "Target Field": self.target_field,
            "Target Datatype": self.target_datatype,
            "Ultimate Source Table": ", ".join(sorted(set(ultimate_source_tables))) if ultimate_source_tables else "",
            "Ultimate Source Field": "; ".join(ultimate_source_fields) if ultimate_source_fields else "",
            "Source Datatype": "; ".join(ultimate_source_datatypes) if ultimate_source_datatypes else "",
            "Source Qualifier": self.source_qualifier_name,
            "Transformation Logic": self.transformation_chain,
            "SQL Logic": self.sql_logic,
            "Transformation Description": self.transformation_explanation,
            "End-to-End Dataflow": self.generate_dataflow_description(),
            "Hop Count": self.hop_count,
            "Lookup Tables": lookups_str,
            "Lookup Name": self.lookup_name,
            "Lookup Condition": self.lookup_condition,
            "Lookup SQL Override": self.lookup_sql_override,
            "Has Transformation": "Yes" if self.has_transformation else "No",
            "Aggregation Applied": "Yes" if self.aggregation_applied else "No",
            "Filter Applied": "Yes" if self.filter_applied else "No",
            "Filter Condition": self.filter_condition,
            "Router Applied": "Yes" if self.router_applied else "No",
            "Router Condition": self.router_condition,
            "Joiner Condition": self.joiner_condition,
            "Joiner Type": self.joiner_type,
            "Update Strategy": self.update_strategy,
            "SQL Override": self.sql_override,
            "Resolved SQL Override": self.resolved_sql_override,
            "Custom Transformation Inputs": "; ".join(
                f"{ci.get('input_field', '')} <- {ci.get('from_instance', '')}.{ci.get('from_field', '')}"
                + (f" [{ci.get('union_group', '')}]" if ci.get('union_group') else "")
                for ci in self.custom_transformation_inputs
            ) if self.custom_transformation_inputs else "",
            "Union Details": (
                f"{self.union_details.get('union_name', 'Union')}: "
                f"{self.union_details.get('group_count', 0)} groups "
                f"({', '.join(self.union_details.get('groups', []))})"
            ) if self.union_details else "",
            "Lookup Input Lineage": self.lookup_input_lineage,
        }

    def generate_dataflow_description(self) -> str:
        """
        Generate a human-readable end-to-end dataflow description.

        Documents the complete data path from source to target with
        English explanations at each transformation step.
        """
        if not self.ultimate_sources and not self.intermediate_steps:
            return f"No lineage traced for {self.target_table}.{self.target_field}"

        parts = []

        # Start with the source
        if self.ultimate_sources:
            source_fields = [f"{s.get('table', 'Unknown')}.{s.get('field', 'Unknown')}"
                           for s in self.ultimate_sources]
            if len(source_fields) == 1:
                parts.append(f"Data originates from {source_fields[0]}")
            else:
                parts.append(f"Data originates from multiple sources: {', '.join(source_fields)}")

        # Process intermediate steps to build the narrative
        if self.intermediate_steps:
            # Group edges by transformation to describe each step
            transformation_descriptions = []
            processed_instances = set()

            for edge in self.intermediate_steps:
                target_inst = edge.target_instance
                if target_inst in processed_instances:
                    continue
                processed_instances.add(target_inst)

                inst_type = self._get_readable_type(edge.target_type)

                # Build description for this transformation
                if edge.expression and edge.expression.strip():
                    if edge.expression_explanation:
                        desc = f"{target_inst} ({inst_type}): {edge.expression_explanation}"
                    else:
                        desc = f"{target_inst} ({inst_type}): applies expression '{edge.expression[:50]}{'...' if len(edge.expression) > 50 else ''}'"
                else:
                    desc = f"{target_inst} ({inst_type}): passes data through"

                transformation_descriptions.append(desc)

            if transformation_descriptions:
                parts.append("The data flows through: " + " -> ".join(transformation_descriptions))

        # End with the target
        parts.append(f"Finally, the data arrives at target {self.target_table}.{self.target_field}")

        # Add notes about special processing
        notes = []
        if self.aggregation_applied:
            notes.append("aggregation is applied")
        if self.filter_applied:
            notes.append("filtering is applied")
        if self.router_applied:
            if self.router_condition:
                notes.append(f"data is routed through condition: {self.router_condition}")
            else:
                notes.append("data passes through a router")
        if self.sql_override:
            notes.append(f"source data is read via custom SQL override")
        if self.lookup_tables:
            notes.append(f"data is enriched via lookup(s): {', '.join(self.lookup_tables)}")

        if notes:
            parts.append(f"Note: {', '.join(notes)}")

        return ". ".join(parts) + "."

    def _get_readable_type(self, instance_type: str) -> str:
        """Convert instance type to readable format."""
        if not instance_type:
            return "Transformation"

        type_lower = instance_type.lower()

        if "source definition" in type_lower:
            return "Source"
        elif "source qualifier" in type_lower:
            return "Source Qualifier - reads data from database"
        elif "target definition" in type_lower or "target" in type_lower:
            return "Target"
        elif "expression" in type_lower:
            return "Expression - calculates/transforms values"
        elif "filter" in type_lower:
            return "Filter - filters rows based on condition"
        elif "aggregator" in type_lower:
            return "Aggregator - groups and aggregates data"
        elif "lookup" in type_lower:
            return "Lookup - retrieves data from reference table"
        elif "joiner" in type_lower:
            return "Joiner - joins data from multiple sources"
        elif "router" in type_lower:
            return "Router - routes data to different targets"
        elif "update strategy" in type_lower:
            return "Update Strategy - determines insert/update/delete action"
        elif "normalizer" in type_lower:
            return "Normalizer - converts columns to rows"
        elif "sorter" in type_lower:
            return "Sorter - sorts data"
        else:
            return instance_type


@dataclass
class LineageGraph:
    """
    Graph representation of data lineage.

    Stores nodes (fields) and edges (data flows) for lineage analysis.
    """

    nodes: Dict[str, LineageNode] = field(default_factory=dict)  # node_id -> node
    edges: List[FieldLineageEdge] = field(default_factory=list)
    adjacency_list: Dict[str, List[str]] = field(default_factory=dict)  # from_node -> [to_nodes]
    reverse_adjacency: Dict[str, List[str]] = field(default_factory=dict)  # to_node -> [from_nodes]

    def add_node(self, node: LineageNode) -> None:
        """Add a node to the graph."""
        self.nodes[node.node_id] = node
        if node.node_id not in self.adjacency_list:
            self.adjacency_list[node.node_id] = []
        if node.node_id not in self.reverse_adjacency:
            self.reverse_adjacency[node.node_id] = []

    def add_edge(self, edge: FieldLineageEdge) -> None:
        """Add an edge to the graph."""
        self.edges.append(edge)

        # Create nodes if they don't exist
        source_id = f"{edge.source_instance}.{edge.source_field}"
        target_id = f"{edge.target_instance}.{edge.target_field}"

        if source_id not in self.adjacency_list:
            self.adjacency_list[source_id] = []
        if target_id not in self.reverse_adjacency:
            self.reverse_adjacency[target_id] = []

        # Update adjacency lists
        if target_id not in self.adjacency_list[source_id]:
            self.adjacency_list[source_id].append(target_id)
        if source_id not in self.reverse_adjacency[target_id]:
            self.reverse_adjacency[target_id].append(source_id)

    def get_sources(self, node_id: str) -> List[str]:
        """Get all source nodes for a given node."""
        return self.reverse_adjacency.get(node_id, [])

    def get_targets(self, node_id: str) -> List[str]:
        """Get all target nodes for a given node."""
        return self.adjacency_list.get(node_id, [])

    def trace_lineage_backward(self, node_id: str, visited: Optional[Set[str]] = None) -> List[List[str]]:
        """
        Trace lineage backward from a node to all ultimate sources.

        Returns list of paths, where each path is a list of node_ids.
        """
        if visited is None:
            visited = set()

        if node_id in visited:
            return []  # Cycle detected

        visited.add(node_id)
        sources = self.get_sources(node_id)

        if not sources:
            # This is an ultimate source
            return [[node_id]]

        all_paths = []
        for source_id in sources:
            sub_paths = self.trace_lineage_backward(source_id, visited.copy())
            for path in sub_paths:
                all_paths.append(path + [node_id])

        return all_paths

    def get_source_nodes(self) -> List[LineageNode]:
        """Get all nodes that are sources (no incoming edges)."""
        return [
            node for node_id, node in self.nodes.items()
            if not self.reverse_adjacency.get(node_id, [])
        ]

    def get_target_nodes(self) -> List[LineageNode]:
        """Get all nodes that are targets (no outgoing edges)."""
        return [
            node for node_id, node in self.nodes.items()
            if not self.adjacency_list.get(node_id, [])
        ]

    @property
    def node_count(self) -> int:
        return len(self.nodes)

    @property
    def edge_count(self) -> int:
        return len(self.edges)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "node_count": self.node_count,
            "edge_count": self.edge_count,
            "nodes": {k: v.to_dict() for k, v in self.nodes.items()},
            "edges": [e.to_dict() for e in self.edges],
        }


@dataclass
class LineageResult:
    """Complete lineage analysis result for a mapping."""

    mapping_name: str
    source_count: int = 0
    target_count: int = 0
    transformation_count: int = 0
    field_lineages: List[EndToEndFieldLineage] = field(default_factory=list)
    lineage_graph: Optional[LineageGraph] = None
    unmapped_target_fields: List[Dict[str, str]] = field(default_factory=list)
    lookup_tables: List[str] = field(default_factory=list)
    aggregators: List[str] = field(default_factory=list)
    filters: List[str] = field(default_factory=list)

    @property
    def coverage_percentage(self) -> float:
        """Calculate lineage coverage percentage."""
        total = len(self.field_lineages) + len(self.unmapped_target_fields)
        if total == 0:
            return 100.0
        return (len(self.field_lineages) / total) * 100

    def to_dict(self) -> Dict[str, Any]:
        return {
            "mapping_name": self.mapping_name,
            "source_count": self.source_count,
            "target_count": self.target_count,
            "transformation_count": self.transformation_count,
            "lineage_count": len(self.field_lineages),
            "coverage_percentage": self.coverage_percentage,
            "unmapped_count": len(self.unmapped_target_fields),
            "field_lineages": [l.to_dict() for l in self.field_lineages],
            "unmapped_target_fields": self.unmapped_target_fields,
            "lookup_tables": self.lookup_tables,
            "aggregators": self.aggregators,
            "filters": self.filters,
        }
