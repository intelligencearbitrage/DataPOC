"""Base models for Informatica PowerCenter objects."""

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional


@dataclass
class BaseModel:
    """Base class for all Informatica models."""

    name: str
    description: str = ""

    def to_dict(self) -> Dict[str, Any]:
        """Convert model to dictionary."""
        result = {}
        for key, value in self.__dict__.items():
            if hasattr(value, 'to_dict'):
                result[key] = value.to_dict()
            elif isinstance(value, list):
                result[key] = [
                    item.to_dict() if hasattr(item, 'to_dict') else item
                    for item in value
                ]
            else:
                result[key] = value
        return result


@dataclass
class FieldBase:
    """Base class for field definitions (Source/Target/Transform fields)."""

    name: str
    datatype: str
    precision: int = 0
    scale: int = 0
    field_number: int = 0
    description: str = ""
    nullable: bool = True

    @property
    def full_datatype(self) -> str:
        """Get full datatype string with precision/scale."""
        if self.precision > 0:
            if self.scale > 0:
                return f"{self.datatype}({self.precision},{self.scale})"
            return f"{self.datatype}({self.precision})"
        return self.datatype

    def to_dict(self) -> Dict[str, Any]:
        """Convert field to dictionary."""
        return {
            "name": self.name,
            "datatype": self.datatype,
            "full_datatype": self.full_datatype,
            "precision": self.precision,
            "scale": self.scale,
            "field_number": self.field_number,
            "description": self.description,
            "nullable": self.nullable,
        }
