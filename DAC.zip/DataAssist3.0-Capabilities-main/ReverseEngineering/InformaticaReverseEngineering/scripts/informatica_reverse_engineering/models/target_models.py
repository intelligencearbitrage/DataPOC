"""Target models for Informatica PowerCenter."""

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

from .base_models import BaseModel, FieldBase


@dataclass
class TargetField(FieldBase):
    """Represents a field in an Informatica target definition."""

    keytype: str = "NOT A KEY"  # "PRIMARY KEY", "FOREIGN KEY", "UNIQUE KEY", "NOT A KEY"
    picture_text: str = ""
    business_name: str = ""

    @property
    def is_key(self) -> bool:
        """Check if field is a key."""
        return self.keytype in ["PRIMARY KEY", "FOREIGN KEY", "UNIQUE KEY"]

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        result = super().to_dict()
        result.update({
            "keytype": self.keytype,
            "is_key": self.is_key,
            "business_name": self.business_name,
        })
        return result


@dataclass
class TargetLoadOrder:
    """Target load order specification."""

    order: int
    target_instance: str

    def to_dict(self) -> Dict[str, Any]:
        return {"order": self.order, "target_instance": self.target_instance}


@dataclass
class Target(BaseModel):
    """Represents an Informatica target definition."""

    database_type: str = ""  # "Microsoft SQL Server", "Oracle", "Flat File", etc.
    constraint: str = ""
    table_options: str = ""
    fields: List[TargetField] = field(default_factory=list)
    load_orders: List[TargetLoadOrder] = field(default_factory=list)
    object_version: int = 1
    version_number: int = 1
    business_name: str = ""

    @property
    def field_count(self) -> int:
        """Get number of fields."""
        return len(self.fields)

    @property
    def key_fields(self) -> List[TargetField]:
        """Get list of key fields."""
        return [f for f in self.fields if f.is_key]

    def get_field(self, name: str) -> Optional[TargetField]:
        """Get field by name (case-insensitive)."""
        name_lower = name.lower()
        for fld in self.fields:
            if fld.name.lower() == name_lower:
                return fld
        return None

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            "name": self.name,
            "description": self.description,
            "database_type": self.database_type,
            "constraint": self.constraint,
            "field_count": self.field_count,
            "fields": [f.to_dict() for f in self.fields],
            "load_orders": [lo.to_dict() for lo in self.load_orders],
            "business_name": self.business_name,
        }
