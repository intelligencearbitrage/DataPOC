"""Mapping models for Informatica PowerCenter."""

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

from .base_models import BaseModel
from .source_models import Source
from .target_models import Target
from .transformation_models import Transformation
from .connector_models import Connector


@dataclass
class MappingVariable:
    """Mapping variable ($$variable)."""

    name: str
    datatype: str
    default_value: str = ""
    precision: int = 0
    scale: int = 0
    is_param: bool = False
    is_expression_variable: bool = False
    user_defined: bool = True
    agg_function: str = ""
    description: str = ""

    def to_dict(self) -> Dict[str, Any]:
        return {
            "name": self.name,
            "datatype": self.datatype,
            "default_value": self.default_value,
            "precision": self.precision,
            "scale": self.scale,
            "is_param": self.is_param,
            "is_expression_variable": self.is_expression_variable,
            "description": self.description,
        }


@dataclass
class AssociatedSourceInstance:
    """Associated source instance for Source Qualifier."""

    name: str

    def to_dict(self) -> Dict[str, Any]:
        return {"name": self.name}


@dataclass
class Instance:
    """
    Represents an instance of a transformation in a mapping.

    Instances connect transformations and sources/targets in the data flow.
    Types: SOURCE, TARGET, TRANSFORMATION
    """

    name: str
    transformation_name: str
    transformation_type: str
    instance_type: str  # SOURCE, TARGET, TRANSFORMATION
    description: str = ""
    reusable: bool = False
    db_dname: str = ""  # Database name (for SOURCE)
    associated_sources: List[AssociatedSourceInstance] = field(default_factory=list)
    attributes: Dict[str, str] = field(default_factory=dict)

    @property
    def is_source(self) -> bool:
        """Check if this instance is a source (by instance_type or transformation_type)."""
        return (self.instance_type.upper() == "SOURCE" or
                self.transformation_type.upper() == "SOURCE" or
                "SOURCE" in self.transformation_type.upper())

    @property
    def is_target(self) -> bool:
        """Check if this instance is a target (by instance_type or transformation_type)."""
        return (self.instance_type.upper() == "TARGET" or
                self.transformation_type.upper() == "TARGET" or
                "TARGET" in self.transformation_type.upper())

    @property
    def is_transformation(self) -> bool:
        """Check if this is a pure transformation (not source or target)."""
        return not self.is_source and not self.is_target

    def to_dict(self) -> Dict[str, Any]:
        return {
            "name": self.name,
            "transformation_name": self.transformation_name,
            "transformation_type": self.transformation_type,
            "instance_type": self.instance_type,
            "description": self.description,
            "reusable": self.reusable,
            "db_dname": self.db_dname,
            "associated_sources": [s.to_dict() for s in self.associated_sources],
            "is_source": self.is_source,
            "is_target": self.is_target,
            "is_transformation": self.is_transformation,
        }


@dataclass
class Mapping(BaseModel):
    """
    Represents an Informatica mapping.

    A mapping contains:
    - Sources: Input table definitions
    - Targets: Output table definitions
    - Transformations: Data transformation logic
    - Instances: Instantiated transformations in data flow
    - Connectors: Field-level connections between instances
    - Variables: Mapping variables and parameters
    """

    is_valid: bool = True
    object_version: int = 1
    version_number: int = 1
    sources: List[Source] = field(default_factory=list)
    targets: List[Target] = field(default_factory=list)
    transformations: List[Transformation] = field(default_factory=list)
    instances: List[Instance] = field(default_factory=list)
    connectors: List[Connector] = field(default_factory=list)
    variables: List[MappingVariable] = field(default_factory=list)
    target_load_order: List[str] = field(default_factory=list)
    target_load_order_detailed: List[Dict[str, Any]] = field(default_factory=list)

    @property
    def source_instances(self) -> List[Instance]:
        """Get source instances."""
        return [i for i in self.instances if i.is_source]

    @property
    def target_instances(self) -> List[Instance]:
        """Get target instances."""
        return [i for i in self.instances if i.is_target]

    @property
    def transformation_instances(self) -> List[Instance]:
        """Get transformation instances."""
        return [i for i in self.instances if i.is_transformation]

    def get_source(self, name: str) -> Optional[Source]:
        """Get source by name (case-insensitive)."""
        name_lower = name.lower()
        for src in self.sources:
            if src.name.lower() == name_lower:
                return src
        return None

    def get_target(self, name: str) -> Optional[Target]:
        """Get target by name (case-insensitive)."""
        name_lower = name.lower()
        for tgt in self.targets:
            if tgt.name.lower() == name_lower:
                return tgt
        return None

    def get_transformation(self, name: str) -> Optional[Transformation]:
        """Get transformation by name (case-insensitive)."""
        name_lower = name.lower()
        for trans in self.transformations:
            if trans.name.lower() == name_lower:
                return trans
        return None

    def get_instance(self, name: str) -> Optional[Instance]:
        """Get instance by name (case-insensitive)."""
        name_lower = name.lower()
        for inst in self.instances:
            if inst.name.lower() == name_lower:
                return inst
        return None

    @property
    def has_target_load_order(self) -> bool:
        return len(self.target_load_order) > 0

    def get_connectors_from(self, instance_name: str) -> List[Connector]:
        """Get all connectors from a specific instance."""
        return [c for c in self.connectors if c.from_instance.lower() == instance_name.lower()]

    def get_connectors_to(self, instance_name: str) -> List[Connector]:
        """Get all connectors to a specific instance."""
        return [c for c in self.connectors if c.to_instance.lower() == instance_name.lower()]

    def to_dict(self) -> Dict[str, Any]:
        return {
            "name": self.name,
            "description": self.description,
            "is_valid": self.is_valid,
            "source_count": len(self.sources),
            "target_count": len(self.targets),
            "transformation_count": len(self.transformations),
            "instance_count": len(self.instances),
            "connector_count": len(self.connectors),
            "variable_count": len(self.variables),
            "sources": [s.to_dict() for s in self.sources],
            "targets": [t.to_dict() for t in self.targets],
            "transformations": [t.to_dict() for t in self.transformations],
            "instances": [i.to_dict() for i in self.instances],
            "connectors": [c.to_dict() for c in self.connectors],
            "variables": [v.to_dict() for v in self.variables],
            "target_load_order": self.target_load_order,
            "target_load_order_detailed": self.target_load_order_detailed,
        }
