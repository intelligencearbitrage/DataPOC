"""Source models for Informatica PowerCenter."""

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

from .base_models import BaseModel, FieldBase


@dataclass
class SourceField(FieldBase):
    """Represents a field in an Informatica source definition."""

    keytype: str = "NOT A KEY"  # "PRIMARY KEY", "FOREIGN KEY", "UNIQUE KEY", "NOT A KEY"
    field_type: str = "ELEMITEM"  # "ELEMITEM", "GRPITEM"
    hidden: bool = False
    level: int = 0
    occurs: int = 0
    offset: int = 0
    physical_length: int = 0
    physical_offset: int = 0
    usage_flags: str = ""
    business_name: str = ""
    group: str = ""  # XML group name (XPath hierarchy element)

    @property
    def is_key(self) -> bool:
        """Check if field is a key."""
        return self.keytype in ["PRIMARY KEY", "FOREIGN KEY", "UNIQUE KEY"]

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        result = super().to_dict()
        result.update({
            "keytype": self.keytype,
            "field_type": self.field_type,
            "hidden": self.hidden,
            "is_key": self.is_key,
            "business_name": self.business_name,
        })
        return result


@dataclass
class Source(BaseModel):
    """Represents an Informatica source definition."""

    database_type: str = ""  # "Microsoft SQL Server", "Oracle", "DB2", etc.
    db_dname: str = ""  # Database name
    owner_name: str = ""  # Schema/owner name
    fields: List[SourceField] = field(default_factory=list)
    table_attributes: List[Dict[str, str]] = field(default_factory=list)  # [{name, value}] TABLEATTRIBUTE elements
    object_version: int = 1
    version_number: int = 1
    business_name: str = ""

    @property
    def qualified_name(self) -> str:
        """Get fully qualified source name."""
        parts = []
        if self.db_dname:
            parts.append(self.db_dname)
        if self.owner_name:
            parts.append(self.owner_name)
        parts.append(self.name)
        return ".".join(parts)

    @property
    def field_count(self) -> int:
        """Get number of fields."""
        return len(self.fields)

    @property
    def key_fields(self) -> List[SourceField]:
        """Get list of key fields."""
        return [f for f in self.fields if f.is_key]

    def get_field(self, name: str) -> Optional[SourceField]:
        """Get field by name (case-insensitive)."""
        name_lower = name.lower()
        for fld in self.fields:
            if fld.name.lower() == name_lower:
                return fld
        return None

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            "name": self.name,
            "description": self.description,
            "database_type": self.database_type,
            "db_dname": self.db_dname,
            "owner_name": self.owner_name,
            "qualified_name": self.qualified_name,
            "field_count": self.field_count,
            "fields": [f.to_dict() for f in self.fields],
            "table_attributes": self.table_attributes,
            "business_name": self.business_name,
        }
