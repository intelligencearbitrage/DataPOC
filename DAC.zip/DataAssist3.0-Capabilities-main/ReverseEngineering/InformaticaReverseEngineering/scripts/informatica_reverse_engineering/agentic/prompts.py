"""
LLM Prompts for Informatica Agentic Workflow.

This module contains all prompts used by the agents for:
- Lineage validation
- Error analysis
- Code refinement
- Output correction
"""


# =============================================================================
# LINEAGE VALIDATION PROMPT
# =============================================================================

LINEAGE_VALIDATION_PROMPT = """You are a data lineage validation expert for Informatica PowerCenter ETL processes.

**Task:** Compare the extracted lineage against the ground truth and identify discrepancies.

**Ground Truth:**
```json
{ground_truth_json}
```

**Extracted Lineage:**
```json
{extracted_lineage_json}
```

**Validation Tasks:**
1. Calculate field coverage (% of target fields with traced sources)
2. Identify missing lineage paths (fields in ground truth but not extracted)
3. Validate transformation logic accuracy (compare expressions)
4. Score explanation quality (0-100 based on completeness and accuracy)

**Response Format (JSON):**
```json
{{
    "field_coverage": {{
        "total_target_fields": <int>,
        "mapped_fields": <int>,
        "coverage_percentage": <float>
    }},
    "missing_paths": [
        {{
            "target_table": "<table_name>",
            "target_field": "<field_name>",
            "expected_sources": ["<source1>", "<source2>"]
        }}
    ],
    "transformation_accuracy": {{
        "correct_expressions": <int>,
        "incorrect_expressions": <int>,
        "accuracy_percentage": <float>
    }},
    "explanation_quality_score": <int 0-100>,
    "issues": [
        {{
            "type": "missing_source|incorrect_expression|missing_explanation",
            "severity": "high|medium|low",
            "description": "<issue description>",
            "affected_field": "<field_name>"
        }}
    ],
    "overall_score": <int 0-100>
}}
```

Be thorough and precise in your validation."""


# =============================================================================
# ERROR ANALYSIS PROMPT
# =============================================================================

ERROR_ANALYSIS_PROMPT = """You are a code debugging expert for Informatica PowerCenter reverse engineering tools.

**Task:** Analyze lineage extraction failures and determine the best fix strategy.

**Validation Issues Found:**
```json
{issues_json}
```

**Current Metrics:**
```json
{metrics_json}
```

**XML Sample (first 2000 chars):**
```xml
{xml_sample}
```

**Analysis Tasks:**
1. Identify root causes of each issue
2. Classify each issue as:
   - OUTPUT_FIX: Can be fixed by re-extracting data from XML without code changes
   - CODE_FIX: Requires parser/expert code modifications
3. Identify specific code modules that need fixing
4. Prioritize fixes by impact on lineage quality

**Known Code Modules:**
- parsers/expression_parser.py - Parses Informatica expressions
- parsers/connector_parser.py - Parses CONNECTOR elements
- parsers/powermart_parser_xdm.py - Main XML parser
- experts/field_mapping_expert.py - Builds lineage graph from connectors
- experts/pattern_detector.py - Detects SCD/CDC patterns
- lineage/path_tracer.py - Traces transformation paths
- lineage/lineage_extractor.py - Main lineage extraction

**Response Format (JSON):**
```json
{{
    "root_causes": [
        "Cause 1: Description of what's causing the issue",
        "Cause 2: Another root cause"
    ],
    "fix_strategy": "output|code|both",
    "confidence": <float 0.0-1.0>,
    "targeted_modules": [
        {{
            "module": "path/to/module.py",
            "issue": "Specific issue in this module",
            "priority": "high|medium|low",
            "suggested_fix": "Brief description of how to fix"
        }}
    ],
    "output_fixable_issues": [
        {{
            "issue_type": "missing_source|missing_expression",
            "how_to_fix": "Description of how to extract from XML"
        }}
    ]
}}
```

Focus on actionable fixes that will improve lineage coverage and accuracy."""


# =============================================================================
# CODE REFINEMENT PROMPT
# =============================================================================

CODE_REFINEMENT_PROMPT = """You are a Python code improvement expert specializing in Informatica PowerCenter parsing.

**Target Module:** {module_path}

**Current Code (first 4000 chars):**
```python
{current_code}
```

**Issues to Fix:**
```json
{issues_json}
```

**Related Validation Issues:**
```json
{validation_issues}
```

**Your Task:**
Generate SPECIFIC, WORKING code fixes that:
1. Address the identified issues
2. Improve extraction accuracy
3. Handle edge cases
4. Maintain backward compatibility

**CRITICAL REQUIREMENTS:**
1. Provide the EXACT old code snippet to replace (must match exactly)
2. Provide the EXACT new code to replace it with
3. Use proper Python indentation (4 spaces)
4. Ensure new code is syntactically correct
5. Keep changes minimal and focused

**Response Format (JSON):**
```json
{{
    "fixes": [
        {{
            "method": "method_name_being_fixed",
            "explanation": "Brief explanation of what this fix does",
            "old_code": "EXACT code snippet to find and replace",
            "new_code": "New code to replace with",
            "impact": "Expected improvement from this fix"
        }}
    ],
    "summary": "Overall summary of changes"
}}
```

**IMPORTANT:**
- The old_code must be an EXACT match of what's in the file
- Include enough context (3-5 lines before/after) to ensure unique matching
- Do NOT use placeholders like "..." or "# existing code"
- Each fix should be atomic and testable independently"""


# =============================================================================
# OUTPUT CORRECTION PROMPT
# =============================================================================

OUTPUT_CORRECTION_PROMPT = """You are an Informatica PowerCenter expert helping to enhance lineage extraction output.

**Task:** Given the XML structure and current output, extract additional lineage information.

**Current Lineage Entry:**
```json
{current_lineage}
```

**Relevant XML Section:**
```xml
{xml_section}
```

**Target Field:** {target_field}
**Target Table:** {target_table}

**Tasks:**
1. Find the source field(s) that flow into this target
2. Trace the transformation path through the XML
3. Extract the expression/transformation logic
4. Generate a human-readable explanation

**Response Format (JSON):**
```json
{{
    "sources_found": [
        {{
            "source_table": "<table_name>",
            "source_field": "<field_name>",
            "source_type": "source|lookup|variable"
        }}
    ],
    "transformation_path": ["Step1", "Step2", "Step3"],
    "expression": "<raw expression if found>",
    "explanation": "Human-readable explanation of what this transformation does",
    "confidence": <float 0.0-1.0>
}}
```

Be thorough in tracing the data flow through the XML structure."""


# =============================================================================
# EXPRESSION EXPLANATION PROMPT
# =============================================================================

EXPRESSION_EXPLANATION_PROMPT = """You are an Informatica PowerCenter expression expert.

**Task:** Explain the following Informatica expression in plain English.

**Expression:**
```
{expression}
```

**Context:**
- Field Name: {field_name}
- Transformation Type: {transformation_type}
- Input Fields: {input_fields}

**Tasks:**
1. Parse the expression and identify all functions used
2. Explain what each function does
3. Describe the overall transformation in business terms
4. Identify any conditional logic or special cases

**Response Format (JSON):**
```json
{{
    "functions_used": ["IIF", "DECODE", "LTRIM", etc.],
    "technical_explanation": "Step-by-step explanation of what the expression does",
    "business_explanation": "What this means in business terms",
    "conditional_logic": "Description of any IF/CASE conditions",
    "special_cases": ["NULL handling", "Default values", etc.],
    "complexity_score": <int 1-10>
}}
```

Make the explanation clear for both technical and non-technical audiences."""


# =============================================================================
# PATTERN DETECTION PROMPT
# =============================================================================

PATTERN_DETECTION_PROMPT = """You are an Informatica PowerCenter pattern detection expert.

**Task:** Identify ETL patterns in the given mapping structure.

**Mapping Structure:**
```json
{mapping_structure}
```

**Transformations:**
```json
{transformations}
```

**Look for these patterns:**
1. **SCD Type 1**: Update in place, no history
2. **SCD Type 2**: Insert new row, maintain history with effective dates
3. **CDC (Change Data Capture)**: Track inserts/updates/deletes
4. **Lookup Chain**: Multiple sequential lookups
5. **Filter Pattern**: Data filtering/routing
6. **Aggregation Pattern**: Grouping and summarizing
7. **Pivot/Unpivot**: Data restructuring
8. **Error Handling**: Error trapping and routing

**Response Format (JSON):**
```json
{{
    "patterns_detected": [
        {{
            "pattern_type": "SCD_TYPE_2|CDC|LOOKUP_CHAIN|etc.",
            "confidence": <float 0.0-1.0>,
            "evidence": ["Transformation X has...", "Field Y indicates..."],
            "transformations_involved": ["EXP_TRANSFORM", "LKP_CUSTOMER"],
            "description": "How this pattern is implemented in the mapping"
        }}
    ],
    "total_patterns": <int>,
    "dominant_pattern": "Most significant pattern type"
}}
```

Be precise in pattern identification and provide clear evidence."""


# =============================================================================
# GROUND TRUTH GENERATION PROMPT
# =============================================================================

GROUND_TRUTH_GENERATION_PROMPT = """You are an Informatica PowerCenter documentation expert.

**Task:** Generate ground truth lineage for the given mapping based on the XML structure.

**Mapping Name:** {mapping_name}

**XML Structure:**
```xml
{xml_content}
```

**Tasks:**
1. Identify all target fields in the mapping
2. For each target field, trace back to the ultimate source(s)
3. Document the transformation chain
4. Extract the expression/logic for each field
5. Generate human-readable explanations

**Response Format (JSON):**
```json
{{
    "mapping_name": "{mapping_name}",
    "field_lineages": [
        {{
            "target_table": "<target_table_name>",
            "target_field": "<field_name>",
            "target_datatype": "<datatype>",
            "ultimate_sources": [
                {{"table": "<source_table>", "field": "<source_field>"}}
            ],
            "transformation_chain": "SQ_SOURCE → EXP_TRANSFORM → TGT_TABLE",
            "transformation_expression": "<raw expression>",
            "transformation_explanation": "Plain English explanation"
        }}
    ],
    "expected_patterns": ["pattern1", "pattern2"],
    "metadata": {{
        "total_source_fields": <int>,
        "total_target_fields": <int>,
        "total_transformations": <int>
    }}
}}
```

Be thorough and accurate - this will be used as validation ground truth."""


# =============================================================================
# SEMANTIC VALIDATION PROMPT
# =============================================================================

SEMANTIC_VALIDATION_PROMPT = """You are a data lineage validation expert for Informatica PowerCenter ETL.

**Task:** Perform semantic validation of extracted lineage against XML ground truth.

**Ground Truth from XML (auto-extracted):**
```json
{ground_truth_json}
```

**Extracted Lineage Output:**
```json
{extracted_lineage_json}
```

**XML Content Sample:**
```xml
{xml_sample}
```

**Semantic Validation Tasks:**
1. **Data Flow Completeness**: Verify all source→target paths are captured
2. **Expression Accuracy**: Check if transformation expressions match XML EXPRESSION attributes
3. **Connector Coverage**: Ensure all CONNECTOR elements from XML are reflected in lineage chains
4. **Transformation Chain Correctness**: Verify each step in chain exists in XML
5. **Source Attribution**: Confirm each field traces to correct ultimate sources
6. **Pattern Recognition**: Check if complex patterns (LKP, AGG, JNR) are properly reflected

**Response Format (JSON):**
```json
{{
    "semantic_score": <int 0-100>,
    "validation_passed": <boolean>,
    "data_flow_issues": [
        {{
            "type": "missing_path|incorrect_path|phantom_path",
            "description": "<detailed description>",
            "expected": "<what should be there>",
            "actual": "<what was found>",
            "severity": "critical|high|medium|low"
        }}
    ],
    "expression_issues": [
        {{
            "field": "<target.field>",
            "expected_expression": "<from XML>",
            "extracted_expression": "<from lineage>",
            "issue": "mismatch|missing|truncated"
        }}
    ],
    "connector_gaps": [
        {{
            "connector": "<from_instance.from_field → to_instance.to_field>",
            "issue": "not_reflected_in_chain"
        }}
    ],
    "chain_issues": [
        {{
            "field": "<target.field>",
            "chain": "<extracted chain>",
            "issue": "unknown_element|wrong_order|incomplete"
        }}
    ],
    "recommendations": [
        "Specific, actionable recommendation 1",
        "Specific, actionable recommendation 2"
    ],
    "gap_analysis": "Detailed paragraph explaining the overall quality and gaps"
}}
```

Be thorough and specific. Identify EVERY discrepancy, no matter how small."""
