"""
Utility Functions for Informatica Agentic Workflow.

This module provides helper functions for:
- LLM initialization
- File I/O operations
- Metrics calculation
- Lineage comparison
"""

import os
import json
import re
from datetime import datetime
from typing import Any, Dict, List, Optional, Tuple
from pathlib import Path

try:
    import dotenv
    dotenv.load_dotenv()
except ImportError:
    pass  # dotenv optional — ANTHROPIC_API_KEY can be set via environment


# =============================================================================
# LLM INITIALIZATION
# =============================================================================

def get_anthropic_llm(model: str = "claude-sonnet-4-20250514", temperature: float = 0.1):
    """
    Initialize and return an Anthropic Claude LLM instance.

    Args:
        model: The model to use (default: claude-sonnet-4-20250514)
        temperature: Temperature for generation (default: 0.1)

    Returns:
        Configured LLM instance
    """
    from langchain_anthropic import ChatAnthropic

    api_key = os.getenv("ANTHROPIC_API_KEY")
    if not api_key:
        raise ValueError("ANTHROPIC_API_KEY not found in environment variables")

    return ChatAnthropic(
        model=model,
        temperature=temperature,
        anthropic_api_key=api_key,
        max_tokens=4096
    )


def get_openai_llm(model: str = "gpt-4o", temperature: float = 0.1):
    """
    Initialize and return an OpenAI LLM instance (fallback).

    Args:
        model: The model to use (default: gpt-4o)
        temperature: Temperature for generation (default: 0.1)

    Returns:
        Configured LLM instance
    """
    from langchain_openai import ChatOpenAI

    api_key = os.getenv("OPENAI_API_KEY")
    if not api_key:
        raise ValueError("OPENAI_API_KEY not found in environment variables")

    return ChatOpenAI(
        model=model,
        temperature=temperature,
        openai_api_key=api_key
    )


# =============================================================================
# FILE I/O OPERATIONS
# =============================================================================

def load_json_file(filepath: str) -> Dict[str, Any]:
    """
    Load a JSON file and return its contents.

    Args:
        filepath: Path to the JSON file

    Returns:
        Parsed JSON data as a dictionary
    """
    with open(filepath, 'r', encoding='utf-8') as f:
        return json.load(f)


def save_json_file(filepath: str, data: Any, indent: int = 2) -> bool:
    """
    Save data to a JSON file.

    Args:
        filepath: Path to save the JSON file
        data: Data to serialize
        indent: Indentation level (default: 2)

    Returns:
        True if successful, False otherwise
    """
    try:
        os.makedirs(os.path.dirname(filepath), exist_ok=True)
        with open(filepath, 'w', encoding='utf-8') as f:
            json.dump(data, f, indent=indent, default=str)
        return True
    except Exception as e:
        print(f"Error saving JSON: {e}")
        return False


def load_xml_file(filepath: str) -> str:
    """
    Load an XML file and return its contents as a string.

    Args:
        filepath: Path to the XML file

    Returns:
        XML content as string
    """
    # Try multiple encodings
    encodings = ['utf-8', 'utf-8-sig', 'cp1252', 'latin-1']

    for encoding in encodings:
        try:
            with open(filepath, 'r', encoding=encoding) as f:
                return f.read()
        except UnicodeDecodeError:
            continue

    # Fallback: read as binary and decode with errors='replace'
    with open(filepath, 'rb') as f:
        return f.read().decode('utf-8', errors='replace')


def read_file_content(filepath: str) -> str:
    """
    Read a file and return its contents.

    Args:
        filepath: Path to the file

    Returns:
        File content as string
    """
    with open(filepath, 'r', encoding='utf-8') as f:
        return f.read()


def write_file_content(filepath: str, content: str) -> bool:
    """
    Write content to a file.

    Args:
        filepath: Path to the file
        content: Content to write

    Returns:
        True if successful, False otherwise
    """
    try:
        os.makedirs(os.path.dirname(filepath), exist_ok=True)
        with open(filepath, 'w', encoding='utf-8') as f:
            f.write(content)
        return True
    except Exception as e:
        print(f"Error writing file: {e}")
        return False


# =============================================================================
# METRICS CALCULATION
# =============================================================================

def calculate_lineage_metrics(
    lineage_output: Optional[Dict[str, Any]],
    end_to_end_lineages: Optional[List[Dict[str, Any]]]
) -> Dict[str, Any]:
    """
    Calculate metrics from lineage output.

    Args:
        lineage_output: Full lineage output dictionary
        end_to_end_lineages: List of field-level lineage entries

    Returns:
        Dictionary of calculated metrics
    """
    metrics = {
        "total_lineages": 0,
        "fields_with_source": 0,
        "fields_without_source": 0,
        "expressions_parsed": 0,
        "expressions_explained": 0,
        "unique_source_tables": set(),
        "unique_target_tables": set(),
        "avg_hop_count": 0.0,
        "timestamp": datetime.now().isoformat()
    }

    lineages = end_to_end_lineages or []

    if not lineages and lineage_output:
        # Try to extract lineages from output
        lineages = lineage_output.get("end_to_end_lineages", [])
        if not lineages:
            lineages = lineage_output.get("field_lineages", [])

    if not lineages:
        return metrics

    total_hops = 0

    for lineage in lineages:
        metrics["total_lineages"] += 1

        # Check sources
        sources = lineage.get("ultimate_sources", [])
        if sources:
            metrics["fields_with_source"] += 1
            for source in sources:
                if isinstance(source, dict):
                    metrics["unique_source_tables"].add(source.get("table", ""))
                elif isinstance(source, str):
                    metrics["unique_source_tables"].add(source.split(".")[0] if "." in source else source)
        else:
            metrics["fields_without_source"] += 1

        # Track target tables
        target_table = lineage.get("target_table", "")
        if target_table:
            metrics["unique_target_tables"].add(target_table)

        # Check expressions
        chain = lineage.get("transformation_chain", "")
        explanation = lineage.get("transformation_explanation", "")
        expression = lineage.get("transformation_expression", "")

        if chain or expression:
            metrics["expressions_parsed"] += 1
        if explanation and len(explanation) > 10:
            metrics["expressions_explained"] += 1

        # Track hop count
        hop_count = lineage.get("hop_count", 0)
        if not hop_count and chain:
            hop_count = chain.count("→") + 1
        total_hops += hop_count

    # Calculate averages
    if metrics["total_lineages"] > 0:
        metrics["avg_hop_count"] = total_hops / metrics["total_lineages"]

    # Convert sets to counts
    metrics["unique_source_tables"] = len(metrics["unique_source_tables"])
    metrics["unique_target_tables"] = len(metrics["unique_target_tables"])

    return metrics


def calculate_validation_score(metrics: Dict[str, Any]) -> float:
    """
    Calculate an overall validation score from metrics.

    Args:
        metrics: Dictionary of validation metrics

    Returns:
        Overall score between 0 and 100
    """
    scores = []

    # Field coverage score (weight: 40%)
    total = metrics.get("total_lineages", 0)
    with_source = metrics.get("fields_with_source", 0)
    if total > 0:
        coverage_score = (with_source / total) * 100
        scores.append(("coverage", coverage_score, 0.4))

    # Expression quality score (weight: 30%)
    parsed = metrics.get("expressions_parsed", 0)
    explained = metrics.get("expressions_explained", 0)
    if parsed > 0:
        expression_score = (explained / parsed) * 100
        scores.append(("expression", expression_score, 0.3))

    # Source diversity score (weight: 15%)
    source_tables = metrics.get("unique_source_tables", 0)
    target_tables = metrics.get("unique_target_tables", 0)
    if target_tables > 0:
        diversity_score = min(100, (source_tables / target_tables) * 50)
        scores.append(("diversity", diversity_score, 0.15))

    # Hop count score (weight: 15%) - penalize very low or very high
    avg_hops = metrics.get("avg_hop_count", 0)
    if avg_hops > 0:
        # Optimal is around 3-5 hops
        if 3 <= avg_hops <= 5:
            hop_score = 100
        elif avg_hops < 3:
            hop_score = 70 + (avg_hops / 3) * 30
        else:
            hop_score = max(50, 100 - (avg_hops - 5) * 10)
        scores.append(("hop", hop_score, 0.15))

    # Calculate weighted average
    if not scores:
        return 0.0

    total_weight = sum(w for _, _, w in scores)
    weighted_sum = sum(score * weight for _, score, weight in scores)

    return weighted_sum / total_weight if total_weight > 0 else 0.0


# =============================================================================
# LINEAGE COMPARISON
# =============================================================================

def compare_lineage_outputs(
    extracted: List[Dict[str, Any]],
    ground_truth: List[Dict[str, Any]]
) -> Dict[str, Any]:
    """
    Compare extracted lineage against ground truth.

    Args:
        extracted: List of extracted lineage entries
        ground_truth: List of ground truth lineage entries

    Returns:
        Comparison results with accuracy and mismatches
    """
    comparison = {
        "accuracy": 0.0,
        "matches": [],
        "mismatches": [],
        "missing_in_extracted": [],
        "extra_in_extracted": [],
        "field_level_accuracy": {}
    }

    if not ground_truth:
        comparison["accuracy"] = 100.0 if not extracted else 0.0
        return comparison

    # Build lookup for extracted lineages
    extracted_lookup = {}
    for entry in extracted:
        key = f"{entry.get('target_table', '')}.{entry.get('target_field', '')}"
        extracted_lookup[key] = entry

    # Compare against ground truth
    matches = 0
    total = len(ground_truth)

    for gt_entry in ground_truth:
        key = f"{gt_entry.get('target_table', '')}.{gt_entry.get('target_field', '')}"

        if key in extracted_lookup:
            ext_entry = extracted_lookup[key]

            # Compare sources
            gt_sources = set()
            for s in gt_entry.get("ultimate_sources", []):
                if isinstance(s, dict):
                    gt_sources.add(f"{s.get('table', '')}.{s.get('field', '')}")
                else:
                    gt_sources.add(str(s))

            ext_sources = set()
            for s in ext_entry.get("ultimate_sources", []):
                if isinstance(s, dict):
                    ext_sources.add(f"{s.get('table', '')}.{s.get('field', '')}")
                else:
                    ext_sources.add(str(s))

            # Calculate overlap
            if gt_sources:
                overlap = len(gt_sources & ext_sources) / len(gt_sources)
            else:
                overlap = 1.0 if not ext_sources else 0.5

            if overlap >= 0.8:
                matches += 1
                comparison["matches"].append({
                    "field": key,
                    "accuracy": overlap
                })
            else:
                comparison["mismatches"].append({
                    "type": "source_mismatch",
                    "field": key,
                    "expected_sources": list(gt_sources),
                    "actual_sources": list(ext_sources),
                    "overlap": overlap
                })

            comparison["field_level_accuracy"][key] = overlap

            # Remove from lookup
            del extracted_lookup[key]
        else:
            comparison["missing_in_extracted"].append({
                "type": "missing_field",
                "field": key,
                "expected_sources": gt_entry.get("ultimate_sources", [])
            })

    # Any remaining in lookup are extra
    for key, entry in extracted_lookup.items():
        comparison["extra_in_extracted"].append({
            "field": key,
            "sources": entry.get("ultimate_sources", [])
        })

    # Calculate overall accuracy
    if total > 0:
        comparison["accuracy"] = (matches / total) * 100

    return comparison


# =============================================================================
# XML PARSING HELPERS
# =============================================================================

def extract_xml_section(
    xml_content: str,
    tag: str,
    name_attr: Optional[str] = None
) -> Optional[str]:
    """
    Extract a specific section from XML content.

    Args:
        xml_content: Full XML content
        tag: Tag name to find
        name_attr: Optional NAME attribute to match

    Returns:
        Extracted XML section or None
    """
    try:
        from lxml import etree

        # Parse XML
        root = etree.fromstring(xml_content.encode('utf-8'))

        # Find elements
        if name_attr:
            elements = root.xpath(f"//{tag}[@NAME='{name_attr}']")
        else:
            elements = root.xpath(f"//{tag}")

        if elements:
            return etree.tostring(elements[0], pretty_print=True, encoding='unicode')
    except Exception as e:
        print(f"Error extracting XML section: {e}")

    return None


def find_connectors_for_field(
    xml_content: str,
    field_name: str
) -> List[Dict[str, Any]]:
    """
    Find all CONNECTOR elements related to a field.

    Args:
        xml_content: Full XML content
        field_name: Field name to search for

    Returns:
        List of connector dictionaries
    """
    connectors = []

    try:
        from lxml import etree

        # Parse XML
        root = etree.fromstring(xml_content.encode('utf-8'))

        # Find connectors where this field is source or target
        xpath = f"//CONNECTOR[@TOFIELD='{field_name}' or @FROMFIELD='{field_name}']"
        elements = root.xpath(xpath)

        for elem in elements:
            connectors.append({
                "from_instance": elem.get("FROMINSTANCE", ""),
                "from_field": elem.get("FROMFIELD", ""),
                "to_instance": elem.get("TOINSTANCE", ""),
                "to_field": elem.get("TOFIELD", ""),
            })
    except Exception as e:
        print(f"Error finding connectors: {e}")

    return connectors


# =============================================================================
# CODE ANALYSIS HELPERS
# =============================================================================

def extract_method_from_code(
    code: str,
    method_name: str
) -> Optional[str]:
    """
    Extract a specific method from Python code.

    Args:
        code: Full Python code
        method_name: Method name to extract

    Returns:
        Method code or None
    """
    # Pattern to match method definition
    pattern = rf'(\s*def {method_name}\s*\([^)]*\)[^:]*:.*?)(?=\n\s*def |\n\s*class |\Z)'

    match = re.search(pattern, code, re.DOTALL)
    if match:
        return match.group(1)

    return None


def find_method_location(
    code: str,
    method_name: str
) -> Optional[Tuple[int, int]]:
    """
    Find the line numbers where a method is defined.

    Args:
        code: Full Python code
        method_name: Method name to find

    Returns:
        Tuple of (start_line, end_line) or None
    """
    lines = code.split('\n')
    start_line = None
    end_line = None
    indent = None

    for i, line in enumerate(lines):
        if start_line is None:
            # Look for method definition
            match = re.match(rf'^(\s*)def {method_name}\s*\(', line)
            if match:
                start_line = i
                indent = len(match.group(1))
        else:
            # Look for end of method
            stripped = line.strip()
            if stripped and not stripped.startswith('#'):
                current_indent = len(line) - len(line.lstrip())
                if current_indent <= indent and (
                    stripped.startswith('def ') or
                    stripped.startswith('class ') or
                    stripped.startswith('@')
                ):
                    end_line = i - 1
                    break

    if start_line is not None:
        if end_line is None:
            end_line = len(lines) - 1
        return (start_line, end_line)

    return None


# =============================================================================
# GROUND TRUTH AUTO-GENERATION FROM XML
# =============================================================================

def extract_ground_truth_from_xml(xml_filepath: str) -> Dict[str, Any]:
    """
    Auto-generate ground truth by extracting facts from Informatica XML.
    Uses XPath/regex analysis to establish what SHOULD be in the output.

    Args:
        xml_filepath: Path to the Informatica PowerCenter XML file

    Returns:
        Dictionary with ground truth counts and semantic details
    """
    from lxml import etree

    ground_truth = {
        # Counts
        "source_count": 0,
        "target_count": 0,
        "mapping_count": 0,
        "transformation_count": 0,
        "connector_count": 0,
        "workflow_count": 0,
        "session_count": 0,

        # Source details
        "sources": [],
        "source_fields": {},  # {source_name: [field_list]}

        # Target details
        "targets": [],
        "target_fields": {},  # {target_name: [field_list]}

        # Transformation details
        "transformations": {},  # {type: count}
        "expression_transformations": [],  # EXP transformations with expressions
        "lookup_transformations": [],  # LKP transformations
        "joiner_transformations": [],  # JNR transformations
        "filter_transformations": [],  # FIL transformations
        "aggregator_transformations": [],  # AGG transformations
        "router_transformations": [],  # RTR transformations
        "union_transformations": [],  # UNI transformations

        # Connector details (data flow)
        "connectors": [],  # [{from_instance, from_field, to_instance, to_field}]
        "target_field_connectors": {},  # {target.field: [source connectors]}

        # Expression details
        "expressions": {},  # {transform_name.field: expression}
        "expression_count": 0,

        # Patterns detected
        "has_lookup": False,
        "has_aggregation": False,
        "has_joiner": False,
        "has_filter": False,
        "has_union": False,
        "has_router": False,
        "has_sequence": False,

        # Metadata
        "repository_name": "",
        "folder_name": "",
        "mappings": []
    }

    try:
        tree = etree.parse(xml_filepath)
        root = tree.getroot()

        # Extract repository/folder info
        repo = root.find(".//REPOSITORY")
        if repo is not None:
            ground_truth["repository_name"] = repo.get("NAME", "")

        folder = root.find(".//FOLDER")
        if folder is not None:
            ground_truth["folder_name"] = folder.get("NAME", "")

        # Count and extract SOURCES
        sources = root.xpath(".//SOURCE")
        ground_truth["source_count"] = len(sources)
        for src in sources:
            src_name = src.get("NAME", "")
            ground_truth["sources"].append(src_name)
            fields = [f.get("NAME", "") for f in src.xpath(".//SOURCEFIELD")]
            ground_truth["source_fields"][src_name] = fields

        # Count and extract TARGETS
        targets = root.xpath(".//TARGET")
        ground_truth["target_count"] = len(targets)
        for tgt in targets:
            tgt_name = tgt.get("NAME", "")
            ground_truth["targets"].append(tgt_name)
            fields = [f.get("NAME", "") for f in tgt.xpath(".//TARGETFIELD")]
            ground_truth["target_fields"][tgt_name] = fields

        # Count MAPPINGS
        mappings = root.xpath(".//MAPPING")
        ground_truth["mapping_count"] = len(mappings)
        ground_truth["mappings"] = [m.get("NAME", "") for m in mappings]

        # Count WORKFLOWS and SESSIONS
        workflows = root.xpath(".//WORKFLOW")
        ground_truth["workflow_count"] = len(workflows)

        sessions = root.xpath(".//SESSION")
        ground_truth["session_count"] = len(sessions)

        # Extract TRANSFORMATIONS
        transformations = root.xpath(".//TRANSFORMATION")
        ground_truth["transformation_count"] = len(transformations)

        transform_types = {}
        for xform in transformations:
            xform_type = xform.get("TYPE", "")
            xform_name = xform.get("NAME", "")

            transform_types[xform_type] = transform_types.get(xform_type, 0) + 1

            # Track specific transformation types
            if "Expression" in xform_type:
                expr_fields = []
                for field in xform.xpath(".//TRANSFORMFIELD"):
                    field_name = field.get("NAME", "")
                    expression = field.get("EXPRESSION", "")
                    if expression:
                        ground_truth["expressions"][f"{xform_name}.{field_name}"] = expression
                        ground_truth["expression_count"] += 1
                        expr_fields.append({"field": field_name, "expression": expression})
                ground_truth["expression_transformations"].append({
                    "name": xform_name,
                    "fields": expr_fields
                })

            elif "Lookup" in xform_type:
                ground_truth["has_lookup"] = True
                ground_truth["lookup_transformations"].append(xform_name)

            elif "Aggregator" in xform_type:
                ground_truth["has_aggregation"] = True
                ground_truth["aggregator_transformations"].append(xform_name)

            elif "Joiner" in xform_type:
                ground_truth["has_joiner"] = True
                ground_truth["joiner_transformations"].append(xform_name)

            elif "Filter" in xform_type:
                ground_truth["has_filter"] = True
                ground_truth["filter_transformations"].append(xform_name)

            elif "Router" in xform_type:
                ground_truth["has_router"] = True
                ground_truth["router_transformations"].append(xform_name)

            elif "Union" in xform_type:
                ground_truth["has_union"] = True
                ground_truth["union_transformations"].append(xform_name)

            elif "Sequence" in xform_type:
                ground_truth["has_sequence"] = True

        ground_truth["transformations"] = transform_types

        # Extract CONNECTORS (data flow)
        connectors = root.xpath(".//CONNECTOR")
        ground_truth["connector_count"] = len(connectors)

        for conn in connectors:
            connector_info = {
                "from_instance": conn.get("FROMINSTANCE", ""),
                "from_field": conn.get("FROMFIELD", ""),
                "to_instance": conn.get("TOINSTANCE", ""),
                "to_field": conn.get("TOFIELD", "")
            }
            ground_truth["connectors"].append(connector_info)

            # Track connectors to target fields
            to_key = f"{connector_info['to_instance']}.{connector_info['to_field']}"
            if to_key not in ground_truth["target_field_connectors"]:
                ground_truth["target_field_connectors"][to_key] = []
            ground_truth["target_field_connectors"][to_key].append(connector_info)

    except Exception as e:
        print(f"Error extracting ground truth from XML: {e}")
        import traceback
        traceback.print_exc()

    return ground_truth


def validate_lineage_against_ground_truth(
    extracted_lineage: List[Dict[str, Any]],
    ground_truth: Dict[str, Any]
) -> Dict[str, Any]:
    """
    Comprehensive validation of extracted lineage against auto-generated ground truth.

    Validation Rules:
    1. TARGET RECALL - All expected targets must appear (≥90%)
    2. FIELD RECALL - All expected fields per target must appear (≥80%)
    3. SOURCE TRACEABILITY - Each field must have traced sources (≥70%)
    4. EXPRESSION COVERAGE - Fields should have expressions (warning if <50%)
    5. CONNECTOR COVERAGE - All XML connectors should be reflected (≥85%)
    6. TRANSFORMATION CHAIN - Each chain element must exist in XML
    7. EXPRESSION ACCURACY - Extracted expressions should match XML
    8. DUPLICATE DETECTION - No duplicate lineage entries allowed
    9. EMPTY SOURCE DETECTION - Flag fields with missing sources (<10%)
    10. PATTERN VALIDATION - LKP/AGG/JNR/FIL must appear in chains
    11. FIELD-LEVEL ISSUES - Report specific per-field problems

    Args:
        extracted_lineage: List of extracted field lineage entries (can be None or empty)
        ground_truth: Auto-generated ground truth from XML

    Returns:
        Validation result with accuracy metrics, issues, and field-level details
    """
    # Handle None or empty lineage
    if extracted_lineage is None:
        extracted_lineage = []

    result = {
        "passed": False,
        "accuracy": 0.0,
        "recall_scores": {},
        "issues": [],
        "warnings": [],
        "stats": {},
        "field_issues": [],  # Per-field issues
        "threshold_failures": [],  # Which thresholds failed
        "checks_passed": 0,
        "total_checks": 11  # Total validation rules
    }

    # ==========================================================================
    # EXTRACT EXPECTED VALUES FROM GROUND TRUTH
    # ==========================================================================
    expected_targets = set(ground_truth.get("targets", []))
    expected_target_fields = {}
    for tgt, fields in ground_truth.get("target_fields", {}).items():
        expected_target_fields[tgt] = set(fields)

    total_expected_fields = sum(len(f) for f in expected_target_fields.values())
    expected_sources = set(ground_truth.get("sources", []))
    expected_connectors = ground_truth.get("connectors", [])
    expected_expressions = ground_truth.get("expressions", {})  # {transform.field: expression}
    expected_transformations = ground_truth.get("transformations", {})

    # ==========================================================================
    # ANALYZE EXTRACTED LINEAGE
    # ==========================================================================
    extracted_targets = set()
    extracted_fields = {}  # {target: set(fields)}
    extracted_sources = set()
    extracted_chains = []  # All transformation chains
    fields_with_source = 0
    fields_with_expression = 0
    fields_with_chain = 0
    empty_source_fields = []

    # Duplicate detection
    lineage_signatures = set()
    duplicate_entries = []

    for entry in extracted_lineage:
        target_table = entry.get("target_table", "")
        target_field = entry.get("target_field", "")

        # Create signature for duplicate detection
        signature = f"{target_table}.{target_field}"
        if signature in lineage_signatures:
            duplicate_entries.append(signature)
        else:
            lineage_signatures.add(signature)

        extracted_targets.add(target_table)
        if target_table not in extracted_fields:
            extracted_fields[target_table] = set()
        extracted_fields[target_table].add(target_field)

        # Track sources
        sources = entry.get("ultimate_sources", [])
        if sources:
            fields_with_source += 1
            for src in sources:
                if isinstance(src, dict):
                    extracted_sources.add(src.get("table", ""))
                elif isinstance(src, str):
                    extracted_sources.add(src.split(".")[0] if "." in src else src)
        else:
            empty_source_fields.append(signature)

        # Track chains
        chain = entry.get("transformation_chain", "")
        if chain:
            fields_with_chain += 1
            extracted_chains.append(chain)

        # Track expressions
        if entry.get("transformation_expression") or entry.get("transformation_explanation"):
            fields_with_expression += 1

    total_extracted_fields = len(extracted_lineage)

    # ==========================================================================
    # RULE 1: TARGET RECALL (≥90%)
    # ==========================================================================
    if expected_targets:
        matched_targets = extracted_targets & expected_targets
        target_recall = len(matched_targets) / len(expected_targets) * 100
        missing_targets = expected_targets - extracted_targets
    else:
        target_recall = 100.0
        missing_targets = set()

    target_recall_passed = target_recall >= 90
    if not target_recall_passed:
        result["threshold_failures"].append(
            f"TARGET_RECALL: {target_recall:.1f}% (expected ≥90%)"
        )
        if missing_targets:
            result["issues"].append(f"Missing targets: {list(missing_targets)[:5]}")

    # ==========================================================================
    # RULE 2: FIELD RECALL (≥80%)
    # ==========================================================================
    field_recalls = []
    missing_fields_by_target = {}

    for tgt, expected_fields in expected_target_fields.items():
        if tgt in extracted_fields:
            overlap = extracted_fields[tgt] & expected_fields
            recall = len(overlap) / len(expected_fields) * 100 if expected_fields else 100
            field_recalls.append(recall)

            # Track missing fields per target
            missing = expected_fields - extracted_fields[tgt]
            if missing:
                missing_fields_by_target[tgt] = list(missing)[:5]
        else:
            field_recalls.append(0.0)
            missing_fields_by_target[tgt] = list(expected_fields)[:5]

    field_recall = sum(field_recalls) / len(field_recalls) if field_recalls else 0.0
    field_recall_passed = field_recall >= 80

    if not field_recall_passed:
        result["threshold_failures"].append(
            f"FIELD_RECALL: {field_recall:.1f}% (expected ≥80%)"
        )
        for tgt, fields in list(missing_fields_by_target.items())[:3]:
            result["field_issues"].append({
                "type": "missing_field",
                "target": tgt,
                "fields": fields
            })

    # ==========================================================================
    # RULE 3: SOURCE TRACEABILITY (≥70%)
    # ==========================================================================
    source_recall = (fields_with_source / total_extracted_fields * 100) if total_extracted_fields > 0 else 0.0
    source_recall_passed = source_recall >= 70

    if not source_recall_passed:
        result["threshold_failures"].append(
            f"SOURCE_TRACEABILITY: {source_recall:.1f}% (expected ≥70%)"
        )
        result["issues"].append(f"Low source traceability: {source_recall:.1f}% of fields have traced sources")

    # ==========================================================================
    # RULE 4: EXPRESSION COVERAGE (warning if <50%)
    # ==========================================================================
    expression_coverage = (fields_with_expression / total_extracted_fields * 100) if total_extracted_fields > 0 else 0.0
    expression_coverage_passed = expression_coverage >= 50

    if not expression_coverage_passed:
        result["warnings"].append(f"Low expression coverage: {expression_coverage:.1f}%")

    # ==========================================================================
    # RULE 5: CONNECTOR COVERAGE (≥85%)
    # ==========================================================================
    if expected_connectors:
        # Helper function to normalize names for matching
        def normalize_name(name: str) -> str:
            """Normalize instance/field names for fuzzy matching."""
            if not name:
                return ""
            # Convert to lowercase
            normalized = name.lower().strip()
            # Remove common prefixes
            prefixes_to_remove = [
                "shortcut_to_", "shortcut_", "sq_", "sq_shortcut_to_",
                "lkp_", "exp_", "rtr_", "jnr_", "flt_", "agg_", "unq_"
            ]
            for prefix in prefixes_to_remove:
                if normalized.startswith(prefix):
                    normalized = normalized[len(prefix):]
                    break
            # Remove trailing underscores/numbers
            import re
            normalized = re.sub(r'_\d+$', '', normalized)
            return normalized

        def names_match(name1: str, name2: str) -> bool:
            """Check if two names match (with normalization)."""
            if not name1 or not name2:
                return False
            # Exact match first
            if name1.lower() == name2.lower():
                return True
            # Normalized match
            norm1 = normalize_name(name1)
            norm2 = normalize_name(name2)
            if norm1 == norm2:
                return True
            # Check if one contains the other
            if norm1 in norm2 or norm2 in norm1:
                return True
            # Handle variations like ECH_PTY_ACCNT vs ECH_MTG_PTY_ACCNT
            if norm1.replace("mtg_", "") == norm2 or norm2.replace("mtg_", "") == norm1:
                return True
            return False

        # Build a combined text from all chains for efficient searching
        all_chains_combined = " ".join(extracted_chains).lower()

        # Also build from end_to_end_dataflow
        all_dataflows = []
        for entry in extracted_lineage:
            dataflow = entry.get("end_to_end_dataflow", "")
            if dataflow:
                all_dataflows.append(dataflow.lower())
        all_dataflows_combined = " ".join(all_dataflows)

        # Check how many connector paths appear in lineage chains
        matched_connectors = 0
        unmatched_connectors = []

        for conn in expected_connectors:
            from_inst = conn.get('from_instance', '')
            from_field = conn.get('from_field', '')
            to_inst = conn.get('to_instance', '')
            to_field = conn.get('to_field', '')

            # Check if this connector is reflected in any chain
            found = False

            # Method 1: Check in transformation chains (normalized)
            from_inst_norm = normalize_name(from_inst)
            from_field_lower = from_field.lower()
            to_inst_norm = normalize_name(to_inst)
            to_field_lower = to_field.lower()

            # Check in combined chains
            if (from_inst_norm in all_chains_combined or from_field_lower in all_chains_combined) and \
               (to_inst_norm in all_chains_combined or to_field_lower in all_chains_combined):
                found = True

            # Method 2: Check in end-to-end dataflows
            if not found and all_dataflows_combined:
                if (from_inst_norm in all_dataflows_combined or from_field_lower in all_dataflows_combined) and \
                   (to_inst_norm in all_dataflows_combined or to_field_lower in all_dataflows_combined):
                    found = True

            # Method 3: Check field-level match in extracted lineages
            if not found:
                for entry in extracted_lineage:
                    target_table = entry.get("target_table", "")
                    target_field = entry.get("target_field", "")

                    # Check if to_field matches target_field
                    if names_match(to_field, target_field) and names_match(to_inst, target_table):
                        # Check if from_field appears in sources or chain
                        sources = entry.get("ultimate_sources", [])
                        chain = entry.get("transformation_chain", "")

                        for src in sources:
                            src_table = src.get("table", "") if isinstance(src, dict) else str(src).split(".")[0]
                            src_field = src.get("field", "") if isinstance(src, dict) else str(src).split(".")[-1] if "." in str(src) else ""

                            if names_match(from_field, src_field) or names_match(from_inst, src_table):
                                found = True
                                break

                        if not found and from_field_lower in chain.lower():
                            found = True

                        if found:
                            break

            if found:
                matched_connectors += 1
            else:
                unmatched_connectors.append(f"{from_inst}.{from_field} → {to_inst}.{to_field}")

        connector_coverage = (matched_connectors / len(expected_connectors) * 100) if expected_connectors else 100.0
    else:
        connector_coverage = 100.0
        unmatched_connectors = []

    connector_coverage_passed = connector_coverage >= 85
    if not connector_coverage_passed:
        result["threshold_failures"].append(
            f"CONNECTOR_COVERAGE: {connector_coverage:.1f}% (expected ≥85%)"
        )
        result["issues"].append(f"Missing connectors in lineage: {len(unmatched_connectors)} unmatched")
        if unmatched_connectors[:3]:
            result["field_issues"].append({
                "type": "missing_connector",
                "connectors": unmatched_connectors[:5]
            })

    # ==========================================================================
    # RULE 6: TRANSFORMATION CHAIN VALIDATION
    # ==========================================================================
    invalid_chain_elements = []
    known_transforms = set()

    # Build set of known transformation names
    for xform_type, count in expected_transformations.items():
        known_transforms.add(xform_type)

    # Also add specific transformation instance names
    for xform_list in [
        ground_truth.get("expression_transformations", []),
        ground_truth.get("lookup_transformations", []),
        ground_truth.get("aggregator_transformations", []),
        ground_truth.get("joiner_transformations", []),
        ground_truth.get("filter_transformations", []),
    ]:
        for item in xform_list:
            if isinstance(item, dict):
                known_transforms.add(item.get("name", ""))
            else:
                known_transforms.add(str(item))

    # Also add source and target names as valid chain elements
    known_transforms.update(expected_sources)
    known_transforms.update(expected_targets)

    # Check each chain for unknown elements
    for chain in extracted_chains[:50]:  # Sample first 50
        # Split chain by arrows
        elements = [e.strip() for e in chain.replace("→", ",").replace("->", ",").split(",")]
        for elem in elements:
            elem_clean = elem.strip()
            if elem_clean and not any(known in elem_clean or elem_clean in known for known in known_transforms):
                if elem_clean not in invalid_chain_elements:
                    invalid_chain_elements.append(elem_clean)

    chain_validation_passed = len(invalid_chain_elements) == 0
    if not chain_validation_passed:
        result["warnings"].append(f"Unknown elements in transformation chains: {invalid_chain_elements[:5]}")

    # ==========================================================================
    # RULE 7: EXPRESSION ACCURACY (sample check)
    # ==========================================================================
    expression_mismatches = []

    for entry in extracted_lineage[:50]:  # Sample first 50
        extracted_expr = entry.get("transformation_expression", "")
        if not extracted_expr:
            continue

        # Try to find matching expression in ground truth
        target_field = entry.get("target_field", "")

        for gt_key, gt_expr in expected_expressions.items():
            if target_field in gt_key:
                # Simple comparison (could use fuzzy matching)
                if extracted_expr and gt_expr:
                    # Normalize and compare
                    extracted_norm = extracted_expr.replace(" ", "").upper()
                    gt_norm = gt_expr.replace(" ", "").upper()

                    # Check if key parts match
                    if extracted_norm not in gt_norm and gt_norm not in extracted_norm:
                        # Allow some flexibility - check for function calls
                        if len(extracted_norm) > 10 and len(gt_norm) > 10:
                            similarity = len(set(extracted_norm) & set(gt_norm)) / max(len(set(extracted_norm)), len(set(gt_norm)))
                            if similarity < 0.5:
                                expression_mismatches.append({
                                    "field": f"{entry.get('target_table', '')}.{target_field}",
                                    "extracted": extracted_expr[:50],
                                    "expected": gt_expr[:50]
                                })
                break

    expression_accuracy_passed = len(expression_mismatches) <= 5  # Allow some tolerance
    if not expression_accuracy_passed:
        result["warnings"].append(f"Expression mismatches found: {len(expression_mismatches)}")
        result["field_issues"].extend([
            {"type": "expression_mismatch", **m} for m in expression_mismatches[:3]
        ])

    # ==========================================================================
    # RULE 8: DUPLICATE DETECTION (0 allowed)
    # ==========================================================================
    duplicate_detection_passed = len(duplicate_entries) == 0
    if not duplicate_detection_passed:
        result["threshold_failures"].append(
            f"DUPLICATE_ENTRIES: {len(duplicate_entries)} duplicates found (expected 0)"
        )
        result["issues"].append(f"Duplicate lineage entries: {duplicate_entries[:5]}")

    # ==========================================================================
    # RULE 9: EMPTY SOURCE DETECTION (<10%)
    # ==========================================================================
    empty_source_ratio = (len(empty_source_fields) / total_extracted_fields * 100) if total_extracted_fields > 0 else 0.0
    empty_source_passed = empty_source_ratio < 10

    if not empty_source_passed:
        result["threshold_failures"].append(
            f"EMPTY_SOURCES: {empty_source_ratio:.1f}% of fields have no source (expected <10%)"
        )
        result["field_issues"].append({
            "type": "empty_source",
            "fields": empty_source_fields[:10],
            "count": len(empty_source_fields)
        })

    # ==========================================================================
    # RULE 10: PATTERN VALIDATION (LKP/AGG/JNR/FIL/RTR/UNI)
    # ==========================================================================
    pattern_issues = []

    if ground_truth.get("has_lookup"):
        if not any("LKP" in str(chain).upper() or "LOOKUP" in str(chain).upper() for chain in extracted_chains):
            pattern_issues.append("Lookup transformations (LKP) not reflected in lineage chains")

    if ground_truth.get("has_aggregation"):
        if not any("AGG" in str(chain).upper() or "AGGREGATOR" in str(chain).upper() for chain in extracted_chains):
            pattern_issues.append("Aggregator transformations (AGG) not reflected in lineage chains")

    if ground_truth.get("has_joiner"):
        if not any("JNR" in str(chain).upper() or "JOINER" in str(chain).upper() for chain in extracted_chains):
            pattern_issues.append("Joiner transformations (JNR) not reflected in lineage chains")

    if ground_truth.get("has_filter"):
        if not any("FIL" in str(chain).upper() or "FILTER" in str(chain).upper() for chain in extracted_chains):
            pattern_issues.append("Filter transformations (FIL) not reflected in lineage chains")

    if ground_truth.get("has_router"):
        if not any("RTR" in str(chain).upper() or "ROUTER" in str(chain).upper() for chain in extracted_chains):
            pattern_issues.append("Router transformations (RTR) not reflected in lineage chains")

    if ground_truth.get("has_union"):
        if not any("UNI" in str(chain).upper() or "UNION" in str(chain).upper() for chain in extracted_chains):
            pattern_issues.append("Union transformations (UNI) not reflected in lineage chains")

    pattern_validation_passed = len(pattern_issues) == 0
    if not pattern_validation_passed:
        result["issues"].extend(pattern_issues)

    # ==========================================================================
    # RULE 11: SOURCE COMPLETENESS (all expected sources should appear)
    # ==========================================================================
    if expected_sources:
        # Normalize source names for comparison (case-insensitive, remove prefixes)
        def normalize_source_name(name: str) -> str:
            """Normalize source table name for matching."""
            if not name:
                return ""
            normalized = name.lower().strip()
            # Remove common prefixes
            prefixes = ["shortcut_to_", "sq_", "lkp_", "sq_shortcut_to_"]
            for prefix in prefixes:
                if normalized.startswith(prefix):
                    normalized = normalized[len(prefix):]
                    break
            return normalized

        # Create normalized versions for matching
        expected_sources_normalized = {normalize_source_name(s): s for s in expected_sources}
        extracted_sources_normalized = {normalize_source_name(s): s for s in extracted_sources}

        # Match using normalized names
        matched_sources = set()
        for ext_norm, ext_orig in extracted_sources_normalized.items():
            for exp_norm, exp_orig in expected_sources_normalized.items():
                # Exact normalized match
                if ext_norm == exp_norm:
                    matched_sources.add(exp_orig)
                # Partial match (one contains the other)
                elif ext_norm and exp_norm and (ext_norm in exp_norm or exp_norm in ext_norm):
                    matched_sources.add(exp_orig)

        source_completeness = len(matched_sources) / len(expected_sources) * 100
        missing_sources = expected_sources - matched_sources
    else:
        source_completeness = 100.0
        missing_sources = set()

    source_completeness_passed = source_completeness >= 80
    if not source_completeness_passed:
        result["threshold_failures"].append(
            f"SOURCE_COMPLETENESS: {source_completeness:.1f}% (expected ≥80%)"
        )
        if missing_sources:
            result["issues"].append(f"Missing sources: {list(missing_sources)[:5]}")

    # ==========================================================================
    # CALCULATE RECALL SCORES
    # ==========================================================================
    result["recall_scores"] = {
        "target_recall": round(target_recall, 1),
        "field_recall": round(field_recall, 1),
        "source_traceability": round(source_recall, 1),
        "expression_coverage": round(expression_coverage, 1),
        "connector_coverage": round(connector_coverage, 1),
        "source_completeness": round(source_completeness, 1)
    }

    # ==========================================================================
    # POPULATE STATS
    # ==========================================================================
    result["stats"] = {
        "expected_targets": len(expected_targets),
        "extracted_targets": len(extracted_targets),
        "missing_targets": list(missing_targets)[:5],
        "expected_fields": total_expected_fields,
        "extracted_fields": total_extracted_fields,
        "fields_with_source": fields_with_source,
        "fields_without_source": len(empty_source_fields),
        "fields_with_expression": fields_with_expression,
        "fields_with_chain": fields_with_chain,
        "expected_connectors": ground_truth.get("connector_count", 0),
        "matched_connectors": matched_connectors if expected_connectors else 0,
        "expected_expressions": ground_truth.get("expression_count", 0),
        "expected_sources": len(expected_sources),
        "extracted_sources": len(extracted_sources),
        "duplicate_count": len(duplicate_entries),
        "expression_mismatches": len(expression_mismatches),
        "pattern_issues": len(pattern_issues)
    }

    # ==========================================================================
    # COUNT CHECKS PASSED
    # ==========================================================================
    checks_passed = sum([
        target_recall_passed,
        field_recall_passed,
        source_recall_passed,
        expression_coverage_passed,
        connector_coverage_passed,
        chain_validation_passed,
        expression_accuracy_passed,
        duplicate_detection_passed,
        empty_source_passed,
        pattern_validation_passed,
        source_completeness_passed
    ])

    result["checks_passed"] = checks_passed
    result["total_checks"] = 11

    # ==========================================================================
    # CALCULATE OVERALL ACCURACY (weighted)
    # ==========================================================================
    weights = {
        "target_recall": 0.15,
        "field_recall": 0.20,
        "source_traceability": 0.20,
        "expression_coverage": 0.10,
        "connector_coverage": 0.15,
        "source_completeness": 0.10
    }

    # Add check-based component (10% weight for checks passed ratio)
    check_score = (checks_passed / 11) * 100

    result["accuracy"] = sum(
        result["recall_scores"].get(k, 0) * w
        for k, w in weights.items()
    ) + (check_score * 0.10)

    # ==========================================================================
    # DETERMINE PASS/FAIL
    # ==========================================================================
    # Critical thresholds that MUST pass:
    critical_passed = (
        target_recall >= 90 and
        field_recall >= 80 and
        source_recall >= 70 and
        duplicate_detection_passed and
        pattern_validation_passed
    )

    # Non-critical warnings don't fail validation
    result["passed"] = critical_passed and len(result["threshold_failures"]) <= 2

    return result


# =============================================================================
# LLM SEMANTIC VALIDATION
# =============================================================================

def llm_semantic_validation(
    extracted_lineage: List[Dict[str, Any]],
    ground_truth: Dict[str, Any],
    xml_content: str,
    session_folder: str = None
) -> Dict[str, Any]:
    """
    Use LLM for semantic validation - deep analysis of lineage correctness.

    This provides:
    1. Data flow completeness analysis
    2. Expression accuracy checking
    3. Connector coverage validation
    4. Semantic gap analysis

    Args:
        extracted_lineage: List of extracted field lineage entries
        ground_truth: Auto-generated ground truth from XML
        xml_content: Original XML content (for context)
        session_folder: Path to save results

    Returns:
        Semantic validation result with detailed issues
    """
    from .prompts import SEMANTIC_VALIDATION_PROMPT

    result = {
        "semantic_score": 0,
        "validation_passed": False,
        "data_flow_issues": [],
        "expression_issues": [],
        "connector_gaps": [],
        "chain_issues": [],
        "recommendations": [],
        "gap_analysis": "",
        "llm_error": None
    }

    try:
        llm = get_anthropic_llm(model="claude-sonnet-4-20250514", temperature=0.1)

        # Prepare ground truth summary (avoid token limits)
        gt_summary = {
            "sources": ground_truth.get("sources", [])[:10],
            "targets": ground_truth.get("targets", [])[:10],
            "target_fields": {k: v[:10] for k, v in list(ground_truth.get("target_fields", {}).items())[:5]},
            "connectors_count": ground_truth.get("connector_count", 0),
            "connectors_sample": ground_truth.get("connectors", [])[:20],
            "expressions_sample": dict(list(ground_truth.get("expressions", {}).items())[:10]),
            "transformation_types": ground_truth.get("transformations", {}),
            "patterns": {
                "has_lookup": ground_truth.get("has_lookup", False),
                "has_aggregation": ground_truth.get("has_aggregation", False),
                "has_joiner": ground_truth.get("has_joiner", False),
                "has_filter": ground_truth.get("has_filter", False),
                "has_router": ground_truth.get("has_router", False),
                "has_union": ground_truth.get("has_union", False)
            }
        }

        # Prepare lineage summary
        lineage_summary = []
        for entry in extracted_lineage[:30]:  # Sample 30 entries
            lineage_summary.append({
                "target": f"{entry.get('target_table', '')}.{entry.get('target_field', '')}",
                "sources": entry.get("ultimate_sources", [])[:3],
                "chain": entry.get("transformation_chain", "")[:100],
                "expression": entry.get("transformation_expression", "")[:100] if entry.get("transformation_expression") else ""
            })

        # Prepare prompt
        prompt = SEMANTIC_VALIDATION_PROMPT.format(
            ground_truth_json=json.dumps(gt_summary, indent=2, default=str),
            extracted_lineage_json=json.dumps(lineage_summary, indent=2, default=str),
            xml_sample=xml_content[:3000] if xml_content else "Not available"
        )

        # Call LLM
        response = llm.invoke(prompt)
        response_text = response.content if hasattr(response, 'content') else str(response)

        # Parse JSON response
        json_match = re.search(r'```json\s*(.*?)\s*```', response_text, re.DOTALL)
        if json_match:
            response_text = json_match.group(1)

        llm_result = json.loads(response_text)

        result["semantic_score"] = llm_result.get("semantic_score", 0)
        result["validation_passed"] = llm_result.get("validation_passed", False)
        result["data_flow_issues"] = llm_result.get("data_flow_issues", [])
        result["expression_issues"] = llm_result.get("expression_issues", [])
        result["connector_gaps"] = llm_result.get("connector_gaps", [])
        result["chain_issues"] = llm_result.get("chain_issues", [])
        result["recommendations"] = llm_result.get("recommendations", [])
        result["gap_analysis"] = llm_result.get("gap_analysis", "")

    except json.JSONDecodeError as e:
        result["llm_error"] = f"Failed to parse LLM response: {e}"
        # Set defaults
        result["semantic_score"] = 50
        result["gap_analysis"] = "LLM semantic validation failed - using threshold-based validation only"
    except Exception as e:
        result["llm_error"] = f"LLM validation error: {e}"
        result["semantic_score"] = 50
        result["gap_analysis"] = f"Error during semantic validation: {str(e)}"

    # Save results if session folder provided
    if session_folder:
        save_json_file(
            os.path.join(session_folder, "llm_semantic_validation.json"),
            result
        )

    return result


# =============================================================================
# LOGGING HELPERS
# =============================================================================

def log_section(title: str, char: str = "=", width: int = 70):
    """Print a formatted section header."""
    print(f"\n{char * width}")
    print(f"  {title}")
    print(f"{char * width}")


def log_metrics(metrics: Dict[str, Any], indent: int = 3):
    """Print metrics in a formatted way."""
    prefix = " " * indent
    for key, value in metrics.items():
        if isinstance(value, float):
            print(f"{prefix}- {key}: {value:.2f}")
        elif isinstance(value, dict):
            print(f"{prefix}- {key}:")
            for k, v in value.items():
                print(f"{prefix}    {k}: {v}")
        else:
            print(f"{prefix}- {key}: {value}")
