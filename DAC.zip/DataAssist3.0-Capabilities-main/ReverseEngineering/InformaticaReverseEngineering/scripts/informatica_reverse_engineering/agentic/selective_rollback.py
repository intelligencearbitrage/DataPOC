"""
Selective Rollback - Safe Code Change Management.

This module provides functionality for:
- Creating backups before code changes
- Applying code fixes safely
- Rolling back changes if they don't improve results
- Managing backup history
"""

import os
import shutil
import re
import difflib
from datetime import datetime
from typing import Any, Dict, List, Optional, Tuple
from pathlib import Path


class SelectiveRollback:
    """Manages safe code modifications with backup and rollback support."""
    
    def __init__(self, backup_dir: Optional[str] = None):
        """
        Initialize the rollback manager.
        
        Args:
            backup_dir: Directory to store backups (default: creates temp dir)
        """
        if backup_dir:
            self.backup_dir = Path(backup_dir)
        else:
            # Create backup directory in the Agentic folder
            self.backup_dir = Path(__file__).parent / "backups"
        
        self.backup_dir.mkdir(parents=True, exist_ok=True)
        self.backup_registry: Dict[str, List[Dict[str, Any]]] = {}
    
    def create_backup(self, filepath: str) -> Optional[str]:
        """
        Create a backup of a file before modification.
        
        Args:
            filepath: Path to the file to backup
        
        Returns:
            Path to the backup file, or None if failed
        """
        try:
            filepath = Path(filepath)
            
            if not filepath.exists():
                print(f"[WARN]  File not found: {filepath}")
                return None
            
            # Create backup filename with timestamp
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            backup_name = f"{filepath.stem}_{timestamp}{filepath.suffix}.bak"
            backup_path = self.backup_dir / backup_name
            
            # Copy the file
            shutil.copy2(filepath, backup_path)
            
            # Register the backup
            filepath_str = str(filepath)
            if filepath_str not in self.backup_registry:
                self.backup_registry[filepath_str] = []
            
            self.backup_registry[filepath_str].append({
                "backup_path": str(backup_path),
                "timestamp": datetime.now().isoformat(),
                "original_path": filepath_str
            })
            
            return str(backup_path)
            
        except Exception as e:
            print(f"[FAIL] Failed to create backup: {e}")
            return None
    
    def apply_fix(
        self,
        filepath: str,
        old_code: str,
        new_code: str,
        create_backup: bool = True
    ) -> bool:
        """
        Apply a code fix to a file.
        
        Args:
            filepath: Path to the file to modify
            old_code: The code to find and replace
            new_code: The new code to insert
            create_backup: Whether to create a backup first
        
        Returns:
            True if fix was applied successfully
        """
        try:
            filepath = Path(filepath)
            
            if not filepath.exists():
                print(f"[WARN]  File not found: {filepath}")
                return False
            
            # Read current content
            with open(filepath, 'r', encoding='utf-8') as f:
                content = f.read()
            
            # Check if old_code exists in the file
            if old_code not in content:
                # Try with normalized whitespace
                normalized_old = self._normalize_whitespace(old_code)
                normalized_content = self._normalize_whitespace(content)
                
                if normalized_old not in normalized_content:
                    print(f"[WARN]  Old code not found in file")
                    print(f"   Looking for: {old_code[:100]}...")
                    return False
                
                # Find and replace with whitespace handling
                content = self._smart_replace(content, old_code, new_code)
            else:
                # Simple replacement
                content = content.replace(old_code, new_code, 1)
            
            # Create backup if requested (and not already done)
            if create_backup:
                backup_path = self.create_backup(str(filepath))
                if not backup_path:
                    print(f"[WARN]  Could not create backup, aborting fix")
                    return False
            
            # Write the modified content
            with open(filepath, 'w', encoding='utf-8') as f:
                f.write(content)
            
            return True
            
        except Exception as e:
            print(f"[FAIL] Failed to apply fix: {e}")
            return False
    
    def _normalize_whitespace(self, text: str) -> str:
        """Normalize whitespace for comparison."""
        # Replace multiple spaces/tabs with single space
        text = re.sub(r'[ \t]+', ' ', text)
        # Normalize line endings
        text = text.replace('\r\n', '\n').replace('\r', '\n')
        # Remove trailing whitespace from lines
        lines = [line.rstrip() for line in text.split('\n')]
        return '\n'.join(lines)
    
    def _smart_replace(
        self,
        content: str,
        old_code: str,
        new_code: str
    ) -> str:
        """
        Smart replacement that handles whitespace differences.
        
        Args:
            content: Original file content
            old_code: Code to find
            new_code: Code to replace with
        
        Returns:
            Modified content
        """
        # Try to find the best match using difflib
        old_lines = old_code.strip().split('\n')
        content_lines = content.split('\n')
        
        # Use SequenceMatcher to find the best matching block
        matcher = difflib.SequenceMatcher(None, content_lines, old_lines)
        
        best_match = None
        best_ratio = 0.0
        
        for i in range(len(content_lines) - len(old_lines) + 1):
            block = content_lines[i:i + len(old_lines)]
            ratio = difflib.SequenceMatcher(None, block, old_lines).ratio()
            if ratio > best_ratio:
                best_ratio = ratio
                best_match = i
        
        if best_match is not None and best_ratio > 0.8:
            # Replace the matched block
            new_lines = new_code.strip().split('\n')
            result_lines = (
                content_lines[:best_match] +
                new_lines +
                content_lines[best_match + len(old_lines):]
            )
            return '\n'.join(result_lines)
        
        # Fallback: return original content
        return content
    
    def rollback(self, filepath: str, backup_path: Optional[str] = None) -> bool:
        """
        Rollback a file to its backup.
        
        Args:
            filepath: Path to the file to rollback
            backup_path: Specific backup to restore (default: most recent)
        
        Returns:
            True if rollback was successful
        """
        try:
            filepath = Path(filepath)
            filepath_str = str(filepath)
            
            if backup_path:
                # Use specified backup
                backup = Path(backup_path)
            else:
                # Find most recent backup
                if filepath_str not in self.backup_registry:
                    print(f"[WARN]  No backups found for: {filepath}")
                    return False
                
                backups = self.backup_registry[filepath_str]
                if not backups:
                    print(f"[WARN]  No backups in registry for: {filepath}")
                    return False
                
                backup = Path(backups[-1]["backup_path"])
            
            if not backup.exists():
                print(f"[WARN]  Backup file not found: {backup}")
                return False
            
            # Restore from backup
            shutil.copy2(backup, filepath)
            
            print(f"[OK] Rolled back: {filepath.name}")
            return True
            
        except Exception as e:
            print(f"[FAIL] Failed to rollback: {e}")
            return False
    
    def rollback_all(self, filepaths: List[str]) -> Dict[str, bool]:
        """
        Rollback multiple files to their backups.
        
        Args:
            filepaths: List of file paths to rollback
        
        Returns:
            Dictionary mapping filepath to rollback success
        """
        results = {}
        for filepath in filepaths:
            results[filepath] = self.rollback(filepath)
        return results
    
    def get_diff(self, filepath: str, backup_path: Optional[str] = None) -> str:
        """
        Get a diff between current file and its backup.
        
        Args:
            filepath: Path to the current file
            backup_path: Specific backup to compare (default: most recent)
        
        Returns:
            Unified diff string
        """
        try:
            filepath = Path(filepath)
            filepath_str = str(filepath)
            
            if backup_path:
                backup = Path(backup_path)
            else:
                if filepath_str not in self.backup_registry or not self.backup_registry[filepath_str]:
                    return "No backup found"
                backup = Path(self.backup_registry[filepath_str][-1]["backup_path"])
            
            if not filepath.exists() or not backup.exists():
                return "File or backup not found"
            
            # Read both files
            with open(filepath, 'r', encoding='utf-8') as f:
                current_lines = f.readlines()
            
            with open(backup, 'r', encoding='utf-8') as f:
                backup_lines = f.readlines()
            
            # Generate diff
            diff = difflib.unified_diff(
                backup_lines,
                current_lines,
                fromfile=f"backup: {backup.name}",
                tofile=f"current: {filepath.name}",
                lineterm=''
            )
            
            return '\n'.join(diff)
            
        except Exception as e:
            return f"Error generating diff: {e}"
    
    def cleanup_old_backups(self, max_age_hours: int = 24) -> int:
        """
        Clean up old backup files.
        
        Args:
            max_age_hours: Maximum age of backups to keep
        
        Returns:
            Number of backups deleted
        """
        deleted = 0
        cutoff = datetime.now().timestamp() - (max_age_hours * 3600)
        
        try:
            for backup_file in self.backup_dir.glob("*.bak"):
                if backup_file.stat().st_mtime < cutoff:
                    backup_file.unlink()
                    deleted += 1
            
            # Also clean up registry
            for filepath, backups in list(self.backup_registry.items()):
                self.backup_registry[filepath] = [
                    b for b in backups
                    if Path(b["backup_path"]).exists()
                ]
                if not self.backup_registry[filepath]:
                    del self.backup_registry[filepath]
        
        except Exception as e:
            print(f"Error during cleanup: {e}")
        
        return deleted
    
    def list_backups(self, filepath: Optional[str] = None) -> List[Dict[str, Any]]:
        """
        List all backups for a file or all files.
        
        Args:
            filepath: Optional filepath to filter by
        
        Returns:
            List of backup information dictionaries
        """
        if filepath:
            return self.backup_registry.get(filepath, [])
        
        all_backups = []
        for fp, backups in self.backup_registry.items():
            for backup in backups:
                all_backups.append({
                    **backup,
                    "file": fp
                })
        
        return sorted(all_backups, key=lambda x: x["timestamp"], reverse=True)
    
    def verify_backup(self, backup_path: str) -> Dict[str, Any]:
        """
        Verify a backup file's integrity.
        
        Args:
            backup_path: Path to the backup file
        
        Returns:
            Verification result dictionary
        """
        result = {
            "exists": False,
            "readable": False,
            "size": 0,
            "created": None
        }
        
        try:
            backup = Path(backup_path)
            result["exists"] = backup.exists()
            
            if result["exists"]:
                result["size"] = backup.stat().st_size
                result["created"] = datetime.fromtimestamp(
                    backup.stat().st_mtime
                ).isoformat()
                
                # Try to read it
                with open(backup, 'r', encoding='utf-8') as f:
                    content = f.read()
                    result["readable"] = True
                    result["lines"] = len(content.split('\n'))
        
        except Exception as e:
            result["error"] = str(e)
        
        return result
