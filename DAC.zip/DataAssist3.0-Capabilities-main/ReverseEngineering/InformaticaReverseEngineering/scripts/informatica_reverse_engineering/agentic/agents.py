"""
Agent Nodes for Informatica Reverse Engineering Agentic Workflow.

This module contains all agent node implementations for the post-output
validation and self-healing code improvement workflow.
"""

import os
import json
import glob
import shutil
import re
import csv
from datetime import datetime
from typing import Any, Dict, List, Optional
from pathlib import Path

import dotenv
dotenv.load_dotenv()

# Import utilities - support both package and direct imports
try:
    from .utils import (
        get_anthropic_llm,
        load_json_file,
        load_xml_file,
        save_json_file,
        calculate_lineage_metrics,
        compare_lineage_outputs,
        extract_ground_truth_from_xml,
        validate_lineage_against_ground_truth,
        llm_semantic_validation,
    )
    from .prompts import (
        LINEAGE_VALIDATION_PROMPT,
        ERROR_ANALYSIS_PROMPT,
        CODE_REFINEMENT_PROMPT,
        OUTPUT_CORRECTION_PROMPT,
    )
    from .output_corrector import OutputCorrector
    from .selective_rollback import SelectiveRollback
except ImportError:
    from utils import (
        get_anthropic_llm,
        load_json_file,
        load_xml_file,
        save_json_file,
        calculate_lineage_metrics,
        compare_lineage_outputs,
        extract_ground_truth_from_xml,
        validate_lineage_against_ground_truth,
        llm_semantic_validation,
    )
    from prompts import (
        LINEAGE_VALIDATION_PROMPT,
        ERROR_ANALYSIS_PROMPT,
        CODE_REFINEMENT_PROMPT,
        OUTPUT_CORRECTION_PROMPT,
    )
    from output_corrector import OutputCorrector
    from selective_rollback import SelectiveRollback


# =============================================================================
# TRIGGER NODE
# =============================================================================

def trigger_node(state: Dict[str, Any]) -> Dict[str, Any]:
    """
    Trigger Node: Initialize the agentic workflow by loading existing outputs.

    This node is called AFTER the main Informatica pipeline has completed.
    It loads the generated outputs for validation.

    Args:
        state: Current workflow state

    Returns:
        Updated state with loaded outputs
    """
    print("\n" + "=" * 70)
    print("  TRIGGER NODE: Initializing Agentic Validation Workflow")
    print("=" * 70)

    xml_filepath = state.get("xml_filepath", "")
    output_directory = state.get("output_directory", "")
    session_id = state.get("session_id", "unknown")

    print(f"[DIR] XML File: {xml_filepath}")
    print(f"[DIR] Output Directory: {output_directory}")
    print(f"[KEY] Session ID: {session_id}")

    # Create session output folder for agentic artifacts
    session_folder = os.path.join(output_directory, "agentic_sessions", session_id)
    os.makedirs(session_folder, exist_ok=True)

    # Load existing outputs from the output directory
    lineage_output = None
    end_to_end_lineages = None
    parse_result = None

    # Try to find and load lineage CSV (primary) or JSON (fallback)
    csv_pattern = "*_lineage.csv"
    csv_matches = glob.glob(os.path.join(output_directory, csv_pattern))

    if csv_matches:
        try:
            # Load from CSV file
            csv_file = csv_matches[0]
            end_to_end_lineages = []

            with open(csv_file, 'r', encoding='utf-8') as f:
                reader = csv.DictReader(f)
                for row in reader:
                    # Parse ultimate sources into list format expected by validator
                    ultimate_sources = []
                    source_tables = row.get("Ultimate Source Table", "")
                    source_fields = row.get("Ultimate Source Field", "")

                    if source_tables and source_fields:
                        # Handle multiple sources (comma-separated tables, semicolon-separated fields)
                        tables = [t.strip() for t in source_tables.split(",")]
                        fields = [f.strip() for f in source_fields.split(";")]

                        for field in fields:
                            if "." in field:
                                # Field already has table prefix (e.g., "table.column")
                                parts = field.split(".")
                                ultimate_sources.append({
                                    "table": parts[0].strip(),
                                    "field": parts[1].strip() if len(parts) > 1 else ""
                                })
                            elif tables:
                                # Use first table as default
                                ultimate_sources.append({
                                    "table": tables[0].strip(),
                                    "field": field.strip()
                                })

                    # Convert CSV row to lineage entry format matching validator expectations
                    lineage_entry = {
                        "target_table": row.get("Target Table", ""),
                        "target_field": row.get("Target Field", ""),
                        "target_datatype": row.get("Target Datatype", ""),
                        "ultimate_sources": ultimate_sources,  # List format for validator
                        "ultimate_source_table": source_tables,  # Keep original for reference
                        "ultimate_source_field": source_fields,  # Keep original for reference
                        "transformation_chain": row.get("Transformation Logic", ""),
                        "transformation_explanation": row.get("Transformation Description", ""),
                        "transformation_expression": row.get("Transformation Logic", ""),
                        "end_to_end_dataflow": row.get("End-to-End Dataflow", ""),
                        "hop_count": int(row.get("Hop Count", 0) or 0),
                        "lookup_tables": row.get("Lookup Tables", ""),
                        "has_transformation": row.get("Has Transformation", "No") == "Yes",
                        "aggregation_applied": row.get("Aggregation Applied", "No") == "Yes",
                        "filter_applied": row.get("Filter Applied", "No") == "Yes"
                    }
                    end_to_end_lineages.append(lineage_entry)

            print(f"[OK] Loaded lineage from CSV: {os.path.basename(csv_file)}")
            print(f"   Found {len(end_to_end_lineages)} lineage entries")
            sources_populated = sum(1 for e in end_to_end_lineages if e.get("ultimate_sources"))
            print(f"   Fields with sources: {sources_populated}/{len(end_to_end_lineages)}")
            lineage_output = {"field_lineages": end_to_end_lineages}

        except Exception as e:
            print(f"[WARN]  Failed to load CSV {csv_matches[0]}: {e}")

    # Fallback to JSON if CSV not found or failed
    if not end_to_end_lineages:
        lineage_patterns = [
            "*_lineage.json",
            "*_field_lineage.json",
            "*_e2e_results.json",
            "*_full_analysis.json"
        ]

        for pattern in lineage_patterns:
            matches = glob.glob(os.path.join(output_directory, pattern))
            if matches:
                try:
                    lineage_output = load_json_file(matches[0])
                    print(f"[OK] Loaded lineage output (JSON fallback): {os.path.basename(matches[0])}")

                    # Extract end-to-end lineages - support multiple output formats
                    if isinstance(lineage_output, dict):
                        # Try different possible locations for lineage data
                        end_to_end_lineages = lineage_output.get("end_to_end_lineages", [])

                        if not end_to_end_lineages:
                            end_to_end_lineages = lineage_output.get("field_lineages", [])

                        if not end_to_end_lineages:
                            # Check nested lineage_result structure
                            lineage_result = lineage_output.get("lineage_result", {})
                            if lineage_result:
                                end_to_end_lineages = lineage_result.get("field_lineages", [])

                        if end_to_end_lineages:
                            print(f"   Found {len(end_to_end_lineages)} lineage entries")
                    break
                except Exception as e:
                    print(f"[WARN]  Failed to load {matches[0]}: {e}")

    # Find output file paths
    excel_files = glob.glob(os.path.join(output_directory, "*.xlsx"))
    json_files = glob.glob(os.path.join(output_directory, "*.json"))
    html_files = glob.glob(os.path.join(output_directory, "*.html"))

    # Load ground truth if specified
    ground_truth = None
    ground_truth_filepath = state.get("ground_truth_filepath")
    if ground_truth_filepath and os.path.exists(ground_truth_filepath):
        try:
            ground_truth = load_json_file(ground_truth_filepath)
            print(f"[OK] Loaded ground truth: {os.path.basename(ground_truth_filepath)}")
        except Exception as e:
            print(f"[WARN]  Failed to load ground truth: {e}")

    # Calculate initial metrics
    initial_metrics = calculate_lineage_metrics(lineage_output, end_to_end_lineages)
    print(f"\n[STATS] Initial Metrics:")
    print(f"   - Total lineage entries: {initial_metrics.get('total_lineages', 0)}")
    print(f"   - Fields with sources: {initial_metrics.get('fields_with_source', 0)}")
    print(f"   - Expressions parsed: {initial_metrics.get('expressions_parsed', 0)}")

    return {
        **state,
        "lineage_output": lineage_output,
        "end_to_end_lineages": end_to_end_lineages,
        "parse_result": parse_result,
        "ground_truth": ground_truth,
        "excel_output_path": excel_files[0] if excel_files else None,
        "json_output_path": json_files[0] if json_files else None,
        "html_output_path": html_files[0] if html_files else None,
        "session_output_folder": session_folder,
        "initial_metrics": initial_metrics,
    }


# =============================================================================
# LINEAGE VALIDATOR NODE
# =============================================================================

def lineage_validator_node(state: Dict[str, Any]) -> Dict[str, Any]:
    """
    Lineage Validator Node: Compare extracted lineage against auto-generated ground truth.

    Auto-generates ground truth from XML using XPath extraction, then validates:
    - Target recall (% of expected targets found)
    - Field recall (% of expected fields found)
    - Source traceability (% of fields with traced sources)
    - Expression coverage (% of fields with expressions)

    Args:
        state: Current workflow state

    Returns:
        Updated state with validation results
    """
    print("\n" + "=" * 70)
    print("  [CHECK] LINEAGE VALIDATOR: Checking Lineage Quality Against Ground Truth")
    print("=" * 70)

    xml_filepath = state.get("xml_filepath", "")
    lineage_output = state.get("lineage_output", {}) or {}
    end_to_end_lineages = state.get("end_to_end_lineages") or []
    retry_count = state.get("lineage_retry_count", 0)
    session_folder = state.get("session_output_folder", "")

    # Handle case where lineage hasn't been extracted yet
    if not end_to_end_lineages:
        print("\n[WARN]  No lineage data found. Attempting to load from output file...")

        # Try to load from lineage_output
        if lineage_output and "end_to_end_lineages" in lineage_output:
            end_to_end_lineages = lineage_output.get("end_to_end_lineages", [])
        else:
            # No lineage available - return with indication to run extraction first
            print("[FAIL] No lineage data available. Please run lineage extraction first.")
            end_to_end_lineages = []

    # USE PRE-BUILT GROUND TRUTH IF AVAILABLE, OTHERWISE AUTO-GENERATE
    ground_truth = state.get("ground_truth")
    if not ground_truth:
        print(f"\n[STATS] Extracting Ground Truth from XML...")
        ground_truth = extract_ground_truth_from_xml(xml_filepath)
    else:
        print(f"\n[STATS] Using pre-built Ground Truth from state...")

    print(f"   Ground Truth Statistics:")
    print(f"   - Sources: {ground_truth.get('source_count', 0)}")
    print(f"   - Targets: {ground_truth.get('target_count', 0)}")
    print(f"   - Mappings: {ground_truth.get('mapping_count', 0)}")
    print(f"   - Transformations: {ground_truth.get('transformation_count', 0)}")
    print(f"   - Connectors: {ground_truth.get('connector_count', 0)}")
    print(f"   - Expressions: {ground_truth.get('expression_count', 0)}")

    # Detect patterns
    patterns = []
    if ground_truth.get("has_lookup"):
        patterns.append("Lookup")
    if ground_truth.get("has_aggregation"):
        patterns.append("Aggregation")
    if ground_truth.get("has_joiner"):
        patterns.append("Joiner")
    if ground_truth.get("has_filter"):
        patterns.append("Filter")
    if ground_truth.get("has_union"):
        patterns.append("Union")
    if ground_truth.get("has_router"):
        patterns.append("Router")

    if patterns:
        print(f"   - Patterns Detected: {', '.join(patterns)}")

    # VALIDATE EXTRACTED LINEAGE AGAINST GROUND TRUTH
    print(f"\n[CHECK] Validating Extracted Lineage (Attempt {retry_count + 1})...")
    validation_result = validate_lineage_against_ground_truth(end_to_end_lineages, ground_truth)

    # Print recall scores with thresholds
    print(f"\n[CHART] Recall Scores (11 Validation Rules):")
    thresholds = {
        "target_recall": 90,
        "field_recall": 80,
        "source_traceability": 70,
        "expression_coverage": 50,
        "connector_coverage": 85,
        "source_completeness": 80
    }
    for metric, value in validation_result.get("recall_scores", {}).items():
        threshold = thresholds.get(metric, 50)
        status = "[OK]" if value >= threshold else "[FAIL]"
        print(f"   {status} {metric.replace('_', ' ').title()}: {value:.1f}% (threshold: {threshold}%)")

    # Print checks summary
    checks_passed = validation_result.get("checks_passed", 0)
    total_checks = validation_result.get("total_checks", 11)
    print(f"\n[NUM] Validation Checks: {checks_passed}/{total_checks} passed")

    # Print threshold failures
    if validation_result.get("threshold_failures"):
        print(f"\n[FAIL] Threshold Failures:")
        for failure in validation_result["threshold_failures"]:
            print(f"   - {failure}")

    # Print stats
    stats = validation_result.get("stats", {})
    print(f"\n[LIST] Statistics:")
    print(f"   - Expected Targets: {stats.get('expected_targets', 0)} | Extracted: {stats.get('extracted_targets', 0)}")
    print(f"   - Expected Fields: {stats.get('expected_fields', 0)} | Extracted: {stats.get('extracted_fields', 0)}")
    print(f"   - Fields with Source: {stats.get('fields_with_source', 0)} | Without: {stats.get('fields_without_source', 0)}")
    print(f"   - Expected Connectors: {stats.get('expected_connectors', 0)} | Matched: {stats.get('matched_connectors', 0)}")
    print(f"   - Duplicate Entries: {stats.get('duplicate_count', 0)}")
    print(f"   - Expression Mismatches: {stats.get('expression_mismatches', 0)}")
    print(f"   - Pattern Issues: {stats.get('pattern_issues', 0)}")

    # Print field-level issues
    field_issues = validation_result.get("field_issues", [])
    if field_issues:
        print(f"\n[CHECK] Field-Level Issues ({len(field_issues)} found):")
        for issue in field_issues[:5]:
            issue_type = issue.get("type", "unknown")
            if issue_type == "missing_field":
                print(f"   - Missing fields in {issue.get('target', 'unknown')}: {issue.get('fields', [])[:3]}")
            elif issue_type == "missing_connector":
                print(f"   - Missing connectors: {issue.get('connectors', [])[:2]}")
            elif issue_type == "empty_source":
                print(f"   - Empty source fields ({issue.get('count', 0)}): {issue.get('fields', [])[:3]}")
            elif issue_type == "expression_mismatch":
                print(f"   - Expression mismatch: {issue.get('field', '')} - extracted: {issue.get('extracted', '')[:30]}...")
        if len(field_issues) > 5:
            print(f"   ... and {len(field_issues) - 5} more field-level issues")

    # Print aggregate issues
    if validation_result.get("issues"):
        print(f"\n[WARN]  Issues Found ({len(validation_result['issues'])}):")
        for issue in validation_result["issues"][:5]:
            print(f"   - {issue}")
        if len(validation_result["issues"]) > 5:
            print(f"   ... and {len(validation_result['issues']) - 5} more")

    if validation_result.get("warnings"):
        print(f"\n[FAST] Warnings ({len(validation_result['warnings'])}):")
        for warning in validation_result["warnings"][:3]:
            print(f"   - {warning}")

    # Overall result
    validation_passed = validation_result.get("passed", False)
    accuracy = validation_result.get("accuracy", 0)

    print(f"\n[TARGET] Overall Accuracy: {accuracy:.1f}%")
    print(f"   Validation Result: {'[OK] PASSED' if validation_passed else '[FAIL] FAILED'}")

    # Build comprehensive validation metrics for downstream nodes
    validation_metrics = {
        "field_coverage": {
            "total_target_fields": stats.get("expected_fields", 0),
            "mapped_fields": stats.get("extracted_fields", 0),
            "percentage": validation_result["recall_scores"].get("field_recall", 0)
        },
        "source_tracing": {
            "fields_with_source": stats.get("fields_with_source", 0),
            "fields_without_source": stats.get("fields_without_source", 0),
            "orphan_percentage": 100 - validation_result["recall_scores"].get("source_traceability", 0)
        },
        "transformation_quality": {
            "expressions_parsed": stats.get("fields_with_expression", 0),
            "quality_score": validation_result["recall_scores"].get("expression_coverage", 0)
        },
        "connector_coverage": {
            "expected": stats.get("expected_connectors", 0),
            "matched": stats.get("matched_connectors", 0),
            "percentage": validation_result["recall_scores"].get("connector_coverage", 0)
        },
        "data_quality": {
            "duplicates": stats.get("duplicate_count", 0),
            "expression_mismatches": stats.get("expression_mismatches", 0),
            "pattern_issues": stats.get("pattern_issues", 0)
        },
        "ground_truth_available": True,
        "recall_scores": validation_result.get("recall_scores", {}),
        "checks_passed": checks_passed,
        "total_checks": total_checks
    }

    # ==========================================================================
    # LLM SEMANTIC VALIDATION (optional deep analysis)
    # ==========================================================================
    semantic_validation_result = None
    enable_llm_validation = state.get("enable_llm_validation", True)

    if not validation_passed and enable_llm_validation:
        print(f"\n[AI] Running LLM Semantic Validation (deep analysis)...")
        try:
            # Load XML content for context
            xml_content = load_xml_file(xml_filepath) if xml_filepath else ""

            semantic_validation_result = llm_semantic_validation(
                extracted_lineage=end_to_end_lineages,
                ground_truth=ground_truth,
                xml_content=xml_content,
                session_folder=session_folder
            )

            print(f"   [STATS] Semantic Score: {semantic_validation_result.get('semantic_score', 0)}/100")

            if semantic_validation_result.get("data_flow_issues"):
                print(f"   [FAIL] Data Flow Issues: {len(semantic_validation_result['data_flow_issues'])}")
                for issue in semantic_validation_result["data_flow_issues"][:2]:
                    print(f"      - [{issue.get('severity', 'medium')}] {issue.get('description', '')[:60]}...")

            if semantic_validation_result.get("connector_gaps"):
                print(f"   [FAIL] Connector Gaps: {len(semantic_validation_result['connector_gaps'])}")

            if semantic_validation_result.get("recommendations"):
                print(f"\n   [IDEA] LLM Recommendations:")
                for rec in semantic_validation_result["recommendations"][:3]:
                    print(f"      - {rec[:80]}...")

            if semantic_validation_result.get("gap_analysis"):
                print(f"\n   [NOTE] Gap Analysis: {semantic_validation_result['gap_analysis'][:200]}...")

            # Add semantic issues to validation issues
            if semantic_validation_result.get("data_flow_issues"):
                for issue in semantic_validation_result["data_flow_issues"][:5]:
                    validation_result["issues"].append(f"[SEMANTIC] {issue.get('description', 'Unknown issue')}")

        except Exception as e:
            print(f"   [WARN]  LLM semantic validation failed: {e}")
            semantic_validation_result = {"llm_error": str(e)}

    # Update validation metrics with semantic results
    if semantic_validation_result:
        validation_metrics["semantic_validation"] = {
            "score": semantic_validation_result.get("semantic_score", 0),
            "passed": semantic_validation_result.get("validation_passed", False),
            "data_flow_issues": len(semantic_validation_result.get("data_flow_issues", [])),
            "connector_gaps": len(semantic_validation_result.get("connector_gaps", [])),
            "has_error": semantic_validation_result.get("llm_error") is not None
        }

    # Update validation history
    validation_history = state.get("validation_history", [])
    validation_history.append({
        "attempt": retry_count + 1,
        "passed": validation_passed,
        "accuracy": accuracy,
        "recall_scores": validation_result.get("recall_scores", {}),
        "issues_count": len(validation_result.get("issues", [])),
        "field_issues_count": len(field_issues),
        "checks_passed": checks_passed,
        "total_checks": total_checks,
        "threshold_failures": validation_result.get("threshold_failures", []),
        "semantic_score": semantic_validation_result.get("semantic_score", 0) if semantic_validation_result else None,
        "timestamp": datetime.now().isoformat()
    })

    # Save validation results
    session_folder = state.get("session_output_folder")
    if session_folder:
        save_json_file(
            os.path.join(session_folder, f"validation_attempt_{retry_count + 1}.json"),
            {
                "ground_truth_stats": {
                    "sources": ground_truth.get("source_count"),
                    "targets": ground_truth.get("target_count"),
                    "transformations": ground_truth.get("transformation_count"),
                    "connectors": ground_truth.get("connector_count"),
                    "expressions": ground_truth.get("expression_count"),
                    "patterns": patterns
                },
                "validation_result": validation_result,
                "semantic_validation": semantic_validation_result,
                "timestamp": datetime.now().isoformat()
            }
        )

        # Save full ground truth for debugging
        save_json_file(
            os.path.join(session_folder, "auto_generated_ground_truth.json"),
            ground_truth
        )

    return {
        **state,
        "ground_truth": ground_truth,  # Auto-generated ground truth
        "lineage_validation_result": validation_result,
        "lineage_validation_passed": validation_passed,
        "validation_metrics": validation_metrics,
        "validation_issues": validation_result.get("issues", []),
        "semantic_validation_result": semantic_validation_result,
        "validation_history": validation_history,
        "lineage_retry_count": retry_count + 1,
    }


# =============================================================================
# ERROR ANALYZER NODE
# =============================================================================

def error_analyzer_node(state: Dict[str, Any]) -> Dict[str, Any]:
    """
    Error Analyzer Node: Classify issues and determine fix strategy.

    Uses LLM to:
    1. Analyze root causes of validation failures
    2. Classify: OUTPUT_FIX vs CODE_FIX
    3. Identify specific code modules to target
    4. Prioritize fixes by impact

    Args:
        state: Current workflow state

    Returns:
        Updated state with error analysis and fix strategy
    """
    print("\n" + "=" * 70)
    print("  [TEST] ERROR ANALYZER: Classifying Issues and Determining Strategy")
    print("=" * 70)

    validation_result = state.get("lineage_validation_result") or {}
    validation_metrics = state.get("validation_metrics") or {}
    issues = list(state.get("validation_issues") or [])
    xml_filepath = state.get("xml_filepath", "")

    # Also pull in threshold failures and field issues that the validator
    # stores separately from the main issues list
    for failure in validation_result.get("threshold_failures", []):
        issues.append({"type": "threshold_failure", "description": str(failure)})
    for field_issue in validation_result.get("field_issues", []):
        if isinstance(field_issue, dict):
            issues.append(field_issue)
        else:
            issues.append({"type": "field_issue", "description": str(field_issue)})

    # Initialize error analysis
    error_analysis = {
        "root_causes": [],
        "fix_strategy": None,
        "targeted_modules": [],
        "confidence": 0.0,
        "issue_classification": {
            "output_fixable": [],
            "code_fixable": [],
            "unknown": []
        }
    }

    # Classify issues by type based on new 11 validation rules
    output_corrector = OutputCorrector()

    # Map issue types from validation to fix categories
    output_fixable_types = [
        "missing_source", "missing_expression", "incomplete_chain",
        "empty_source",  # Can trace from XML connectors
        "expression_mismatch",  # Can re-extract from XML
        "missing_field",  # Can look for more fields in XML
    ]

    code_fixable_types = [
        "parse_error", "connector_missing", "pattern_missed",
        "missing_connector",  # Connector parser needs fix
        "duplicate_entry",  # Dedup logic needed
        "chain_validation_error",  # Path tracer issue
        "low_connector_coverage",  # Connector traversal issue
    ]

    for issue in issues:
        # Handle string issues (from validation_issues list)
        if isinstance(issue, str):
            issue = {"type": "validation_failure", "description": issue}

        issue_type = issue.get("type", "unknown")
        issue_desc = str(issue.get("description", issue_type)).lower()

        # All issues are output-fixable (no code refiner path)
        if issue_type in output_fixable_types:
            error_analysis["issue_classification"]["output_fixable"].append(issue)
        elif any(kw in issue_desc for kw in ["missing source", "empty source", "expression", "missing field",
                                              "missing target", "recall", "threshold", "connector",
                                              "duplicate", "pattern", "mismatch"]):
            error_analysis["issue_classification"]["output_fixable"].append(issue)
        else:
            # Default: treat all issues as output-fixable
            error_analysis["issue_classification"]["output_fixable"].append(issue)

    # Determine fix strategy — output-only
    output_fixable_count = len(error_analysis["issue_classification"]["output_fixable"])
    total_issues = len(issues)

    if total_issues == 0:
        error_analysis["fix_strategy"] = None
        error_analysis["confidence"] = 1.0
    else:
        error_analysis["fix_strategy"] = "output"
        error_analysis["confidence"] = 0.8

    # Use LLM for deeper analysis if we have issues
    if issues and len(issues) > 0:
        try:
            llm = get_anthropic_llm()

            # Prepare prompt
            prompt = ERROR_ANALYSIS_PROMPT.format(
                issues_json=json.dumps(issues[:20], indent=2),  # Limit to 20 issues
                metrics_json=json.dumps(validation_metrics, indent=2),
                xml_sample=_get_xml_sample(xml_filepath)
            )

            response = llm.invoke(prompt)

            # Parse LLM response
            llm_analysis = _parse_llm_json_response(response.content)

            if llm_analysis:
                error_analysis["root_causes"] = llm_analysis.get("root_causes", [])
                error_analysis["targeted_modules"] = llm_analysis.get("targeted_modules", [])

                # LLM can override fix strategy if confident
                llm_strategy = llm_analysis.get("fix_strategy")
                llm_confidence = llm_analysis.get("confidence", 0)

                if llm_confidence > error_analysis["confidence"]:
                    error_analysis["fix_strategy"] = llm_strategy
                    error_analysis["confidence"] = llm_confidence

        except Exception as e:
            print(f"[WARN]  LLM analysis failed: {e}")
            error_analysis["llm_error"] = str(e)

    # Identify targeted modules based on issues
    if not error_analysis["targeted_modules"]:
        error_analysis["targeted_modules"] = _identify_target_modules(issues)

    # Log results
    print(f"\n[LIST] Error Analysis Results:")
    print(f"   - Root Causes: {len(error_analysis['root_causes'])}")
    print(f"   - Fix Strategy: {error_analysis['fix_strategy']}")
    print(f"   - Confidence: {error_analysis['confidence']:.1%}")
    print(f"   - Targeted Modules: {len(error_analysis['targeted_modules'])}")
    print(f"   - Output-Fixable: {output_fixable_count}")

    # Update refinement history
    refinement_history = state.get("refinement_history", [])
    refinement_history.append({
        "stage": "error_analysis",
        "analysis": error_analysis,
        "timestamp": datetime.now().isoformat()
    })

    return {
        **state,
        "error_analysis": error_analysis,
        "fix_strategy": error_analysis["fix_strategy"],
        "targeted_modules": error_analysis["targeted_modules"],
        "refinement_history": refinement_history,
    }


# =============================================================================
# OUTPUT CORRECTOR NODE
# =============================================================================

def output_corrector_node(state: Dict[str, Any]) -> Dict[str, Any]:
    """
    Output Corrector Node: Enhance output directly without code changes.

    Attempts to:
    1. Re-parse XML for missing data
    2. Enhance field mappings
    3. Add missing transformation explanations

    Args:
        state: Current workflow state

    Returns:
        Updated state with enhanced output
    """
    print("\n" + "=" * 70)
    print("  [FIX] OUTPUT CORRECTOR: Enhancing Output Directly")
    print("=" * 70)

    lineage_output = state.get("lineage_output", {})
    end_to_end_lineages = state.get("end_to_end_lineages", [])
    xml_filepath = state.get("xml_filepath", "")
    error_analysis = state.get("error_analysis", {})

    output_fixable = error_analysis.get("issue_classification", {}).get("output_fixable", [])

    output_enhanced = False
    enhancements_made = []

    if not output_fixable:
        print("[INFO]  No output-fixable issues found")
        return {
            **state,
            "output_enhanced": False,
            "enhancements_made": [],
        }

    # Initialize output corrector
    corrector = OutputCorrector()

    # Try to enhance each issue
    for issue in output_fixable:
        issue_type = issue.get("type")

        if issue_type == "missing_source":
            # Try to find source from XML
            target_field = issue.get("target_field")
            target_table = issue.get("target_table")

            try:
                enhanced = corrector.find_missing_source(
                    xml_filepath=xml_filepath,
                    target_table=target_table,
                    target_field=target_field
                )

                if enhanced:
                    # Update the lineage entry
                    for lineage in end_to_end_lineages:
                        if (lineage.get("target_field") == target_field and
                            lineage.get("target_table") == target_table):
                            lineage["ultimate_sources"] = enhanced.get("sources", [])
                            lineage["transformation_chain"] = enhanced.get("chain", "")
                            output_enhanced = True
                            enhancements_made.append({
                                "type": "source_found",
                                "field": target_field,
                                "sources": enhanced.get("sources", [])
                            })
                            break
            except Exception as e:
                print(f"[WARN]  Failed to enhance {target_field}: {e}")

        elif issue_type == "missing_expression":
            # Try to add expression explanation
            target_field = issue.get("target_field")

            try:
                explanation = corrector.explain_expression(
                    xml_filepath=xml_filepath,
                    field_name=target_field
                )

                if explanation:
                    for lineage in end_to_end_lineages:
                        if lineage.get("target_field") == target_field:
                            lineage["transformation_explanation"] = explanation
                            output_enhanced = True
                            enhancements_made.append({
                                "type": "expression_explained",
                                "field": target_field
                            })
                            break
            except Exception as e:
                print(f"[WARN]  Failed to explain expression for {target_field}: {e}")

        elif issue_type == "empty_source":
            # Try to find sources for fields with empty source attribution
            fields = issue.get("fields", [])
            for field_key in fields[:5]:  # Limit to 5 fields
                parts = field_key.split(".") if "." in field_key else [None, field_key]
                target_table = parts[0] if len(parts) > 1 else None
                target_field = parts[-1]

                try:
                    enhanced = corrector.find_missing_source(
                        xml_filepath=xml_filepath,
                        target_table=target_table,
                        target_field=target_field
                    )

                    if enhanced and enhanced.get("sources"):
                        for lineage in end_to_end_lineages:
                            if lineage.get("target_field") == target_field:
                                lineage["ultimate_sources"] = enhanced.get("sources", [])
                                lineage["transformation_chain"] = enhanced.get("chain", lineage.get("transformation_chain", ""))
                                output_enhanced = True
                                enhancements_made.append({
                                    "type": "empty_source_fixed",
                                    "field": target_field,
                                    "sources": enhanced.get("sources", [])
                                })
                                break
                except Exception as e:
                    print(f"[WARN]  Failed to fix empty source for {target_field}: {e}")

        elif issue_type == "expression_mismatch":
            # Try to re-extract expression from XML
            field = issue.get("field", "")
            expected = issue.get("expected", "")

            if expected:
                for lineage in end_to_end_lineages:
                    if field.endswith(lineage.get("target_field", "")):
                        lineage["transformation_expression"] = expected
                        output_enhanced = True
                        enhancements_made.append({
                            "type": "expression_corrected",
                            "field": field,
                            "expression": expected
                        })
                        break

    print(f"\n[STATS] Output Correction Results:")
    print(f"   - Issues Processed: {len(output_fixable)}")
    print(f"   - Enhancements Made: {len(enhancements_made)}")
    print(f"   - Output Enhanced: {'[OK] Yes' if output_enhanced else '[FAIL] No'}")

    # Save enhanced output
    if output_enhanced:
        session_folder = state.get("session_output_folder")
        if session_folder:
            save_json_file(
                os.path.join(session_folder, "enhanced_lineage.json"),
                {"end_to_end_lineages": end_to_end_lineages}
            )

    return {
        **state,
        "end_to_end_lineages": end_to_end_lineages,
        "output_enhanced": output_enhanced,
        "enhancements_made": enhancements_made,
    }


# =============================================================================
# CODE REFINER NODE
# =============================================================================

def code_refiner_node(state: Dict[str, Any]) -> Dict[str, Any]:
    """
    Code Refiner Node: Generate code patches to fix parser/expert issues.

    Uses LLM to analyze code and generate specific fixes for:
    - Expression parsing improvements
    - Connector traversal logic
    - Field mapping enhancements
    - Pattern detection accuracy
    - Duplicate detection (new)
    - Connector coverage (new)

    Args:
        state: Current workflow state

    Returns:
        Updated state with proposed code patches
    """
    print("\n" + "=" * 70)
    print("  [TOOL]  CODE REFINER: Generating Code Patches")
    print("=" * 70)

    error_analysis = state.get("error_analysis", {})
    targeted_modules = state.get("targeted_modules", [])
    validation_issues = state.get("validation_issues", [])

    # NEW: Get comprehensive validation data
    validation_result = state.get("lineage_validation_result", {})
    field_issues = validation_result.get("field_issues", [])
    threshold_failures = validation_result.get("threshold_failures", [])
    semantic_validation = state.get("semantic_validation_result", {})
    recall_scores = validation_result.get("recall_scores", {})

    proposed_fixes = []

    if not targeted_modules:
        print("[INFO]  No targeted modules identified")
        return {
            **state,
            "proposed_fixes": [],
        }

    # Get LLM
    try:
        llm = get_anthropic_llm()
    except Exception as e:
        print(f"[WARN]  Failed to initialize LLM: {e}")
        return {
            **state,
            "proposed_fixes": [],
            "refiner_error": str(e),
        }

    # Build comprehensive issue context for LLM
    comprehensive_issues = {
        "validation_issues": validation_issues[:10],
        "field_issues": field_issues[:10],
        "threshold_failures": threshold_failures,
        "recall_scores": recall_scores,
        "semantic_recommendations": semantic_validation.get("recommendations", [])[:5] if semantic_validation else [],
        "data_flow_issues": semantic_validation.get("data_flow_issues", [])[:5] if semantic_validation else [],
    }

    # Process each targeted module
    for module_info in targeted_modules[:3]:  # Limit to 3 modules per iteration
        module_path = module_info.get("module", "")
        issue = module_info.get("issue", "")
        priority = module_info.get("priority", "medium")

        print(f"\n[CHECK] Analyzing: {module_path}")
        print(f"   Issue: {issue}")
        print(f"   Priority: {priority}")

        # Read current module code
        full_module_path = _get_full_module_path(module_path)

        if not os.path.exists(full_module_path):
            print(f"[WARN]  Module not found: {full_module_path}")
            continue

        try:
            with open(full_module_path, 'r', encoding='utf-8') as f:
                current_code = f.read()
        except Exception as e:
            print(f"[WARN]  Failed to read module: {e}")
            continue

        # Generate fix using LLM with comprehensive context
        prompt = CODE_REFINEMENT_PROMPT.format(
            module_path=module_path,
            current_code=current_code[:4000],  # First 4000 chars
            issues_json=json.dumps([{
                "module_issue": issue,
                "priority": priority,
                "threshold_failures": threshold_failures,
                "recall_scores": recall_scores
            }], indent=2),
            validation_issues=json.dumps(comprehensive_issues, indent=2)
        )

        try:
            response = llm.invoke(prompt)
            llm_fixes = _parse_llm_json_response(response.content)

            if llm_fixes and "fixes" in llm_fixes:
                for fix in llm_fixes["fixes"]:
                    proposed_fixes.append({
                        "module": module_path,
                        "full_path": full_module_path,
                        "method": fix.get("method", ""),
                        "old_code": fix.get("old_code", ""),
                        "new_code": fix.get("new_code", ""),
                        "explanation": fix.get("explanation", ""),
                        "priority": priority,
                        "status": "proposed"
                    })
        except Exception as e:
            print(f"[WARN]  LLM fix generation failed: {e}")

    print(f"\n[STATS] Code Refinement Results:")
    print(f"   - Modules Analyzed: {len(targeted_modules[:3])}")
    print(f"   - Fixes Proposed: {len(proposed_fixes)}")

    # Save proposed fixes
    session_folder = state.get("session_output_folder")
    if session_folder and proposed_fixes:
        save_json_file(
            os.path.join(session_folder, "proposed_fixes.json"),
            {"fixes": proposed_fixes}
        )

    return {
        **state,
        "proposed_fixes": proposed_fixes,
    }


# =============================================================================
# CODE APPLICATOR NODE
# =============================================================================

def code_applicator_node(state: Dict[str, Any]) -> Dict[str, Any]:
    """
    Code Applicator Node: Apply code patches with backup and rollback support.

    For each proposed fix:
    1. Create backup of original file
    2. Apply the code change
    3. Record the change for potential rollback

    Args:
        state: Current workflow state

    Returns:
        Updated state with applied fixes and backup paths
    """
    print("\n" + "=" * 70)
    print("  [NOTE] CODE APPLICATOR: Applying Code Patches")
    print("=" * 70)

    proposed_fixes = state.get("proposed_fixes", [])

    if not proposed_fixes:
        print("[INFO]  No fixes to apply")
        return {
            **state,
            "applied_fixes": [],
            "code_backup_paths": {},
        }

    rollback_manager = SelectiveRollback()
    applied_fixes = []
    code_backup_paths = {}

    for fix in proposed_fixes:
        module_path = fix.get("full_path", "")
        method = fix.get("method", "")
        old_code = fix.get("old_code", "")
        new_code = fix.get("new_code", "")

        if not module_path or not old_code or not new_code:
            print(f"[WARN]  Incomplete fix: {fix.get('module', 'unknown')}")
            fix["status"] = "skipped"
            applied_fixes.append(fix)
            continue

        print(f"\n[FIX] Applying fix to: {fix.get('module', 'unknown')}")
        print(f"   Method: {method}")

        # Create backup
        backup_path = rollback_manager.create_backup(module_path)
        if backup_path:
            code_backup_paths[module_path] = backup_path
            print(f"   [OK] Backup created: {os.path.basename(backup_path)}")
        else:
            print(f"   [WARN]  Failed to create backup")
            fix["status"] = "backup_failed"
            applied_fixes.append(fix)
            continue

        # Apply the fix
        success = rollback_manager.apply_fix(module_path, old_code, new_code)

        if success:
            print(f"   [OK] Fix applied successfully")
            fix["status"] = "applied"
        else:
            print(f"   [FAIL] Fix application failed")
            fix["status"] = "failed"
            # Rollback immediately if fix failed
            rollback_manager.rollback(module_path, backup_path)

        applied_fixes.append(fix)

    # Summary
    successful = sum(1 for f in applied_fixes if f["status"] == "applied")
    failed = sum(1 for f in applied_fixes if f["status"] == "failed")

    print(f"\n[STATS] Code Application Results:")
    print(f"   - Fixes Applied: {successful}")
    print(f"   - Fixes Failed: {failed}")
    print(f"   - Backups Created: {len(code_backup_paths)}")

    return {
        **state,
        "applied_fixes": applied_fixes,
        "code_backup_paths": code_backup_paths,
    }


# =============================================================================
# TEST EXECUTOR NODE
# =============================================================================

def test_executor_node(state: Dict[str, Any]) -> Dict[str, Any]:
    """
    Test Executor Node: Re-run the pipeline and compare results.

    Steps:
    1. Re-run the Informatica extraction with fixed code
    2. Compare before/after metrics
    3. Determine if improvement occurred
    4. Rollback if no improvement

    Args:
        state: Current workflow state

    Returns:
        Updated state with test results
    """
    print("\n" + "=" * 70)
    print("  [TEST] TEST EXECUTOR: Testing Code Fixes")
    print("=" * 70)

    applied_fixes = state.get("applied_fixes", [])
    code_backup_paths = state.get("code_backup_paths", {})
    xml_filepath = state.get("xml_filepath", "")
    initial_metrics = state.get("initial_metrics", {})
    ground_truth = state.get("ground_truth", {})  # Get auto-generated ground truth

    # Get initial validation scores for comparison
    initial_validation = state.get("lineage_validation_result", {})
    initial_recall_scores = initial_validation.get("recall_scores", {})
    initial_checks_passed = initial_validation.get("checks_passed", 0)

    successful_fixes = [f for f in applied_fixes if f["status"] == "applied"]

    if not successful_fixes:
        print("[INFO]  No successful fixes to test")
        return {
            **state,
            "test_results": {
                "improved": False,
                "reason": "no_fixes_applied"
            }
        }

    print(f"\n[RETRY] Re-running extraction with {len(successful_fixes)} fixes applied...")

    # Re-run the extraction pipeline
    try:
        # Import and run the extraction
        from informatica_reverse_engineering.parsers.powermart_parser_xdm import PowermartParserXDM
        from informatica_reverse_engineering.lineage.lineage_extractor import LineageExtractor
        from informatica_reverse_engineering.experts.base_expert import ExpertContext

        # Parse XML
        parser = PowermartParserXDM()
        xdm_result = parser.parse_file(xml_filepath)
        doc = xdm_result.document

        # Extract lineage
        extractor = LineageExtractor()
        new_lineage_result = extractor.extract(doc)

        # Calculate new metrics
        new_lineages = []
        if hasattr(new_lineage_result, 'field_lineages'):
            for fl in new_lineage_result.field_lineages:
                new_lineages.append({
                    "target_table": fl.target_table,
                    "target_field": fl.target_field,
                    "ultimate_sources": fl.ultimate_sources,
                    "transformation_chain": fl.transformation_chain,
                    "transformation_explanation": fl.transformation_explanation
                })

        new_metrics = calculate_lineage_metrics(None, new_lineages)

        # NEW: Run comprehensive validation on new lineages
        new_validation = validate_lineage_against_ground_truth(new_lineages, ground_truth)
        new_recall_scores = new_validation.get("recall_scores", {})
        new_checks_passed = new_validation.get("checks_passed", 0)

        print(f"\n[STATS] Before vs After Basic Metrics:")
        print(f"   - Total Lineages: {initial_metrics.get('total_lineages', 0)} → {new_metrics.get('total_lineages', 0)}")
        print(f"   - Fields with Source: {initial_metrics.get('fields_with_source', 0)} → {new_metrics.get('fields_with_source', 0)}")
        print(f"   - Expressions Parsed: {initial_metrics.get('expressions_parsed', 0)} → {new_metrics.get('expressions_parsed', 0)}")

        # NEW: Print validation score comparison
        print(f"\n[CHART] Before vs After Validation Scores:")
        for metric in ["target_recall", "field_recall", "source_traceability", "connector_coverage"]:
            old_val = initial_recall_scores.get(metric, 0)
            new_val = new_recall_scores.get(metric, 0)
            delta_str = f"+{new_val - old_val:.1f}" if new_val > old_val else f"{new_val - old_val:.1f}"
            status = "[OK]" if new_val >= old_val else "[FAIL]"
            print(f"   {status} {metric}: {old_val:.1f}% → {new_val:.1f}% ({delta_str}%)")

        print(f"\n   Checks Passed: {initial_checks_passed}/11 → {new_checks_passed}/11")

        # Calculate delta
        delta = {
            "total_lineages": new_metrics.get("total_lineages", 0) - initial_metrics.get("total_lineages", 0),
            "fields_with_source": new_metrics.get("fields_with_source", 0) - initial_metrics.get("fields_with_source", 0),
            "expressions_parsed": new_metrics.get("expressions_parsed", 0) - initial_metrics.get("expressions_parsed", 0),
            "checks_passed": new_checks_passed - initial_checks_passed,
            "accuracy": new_validation.get("accuracy", 0) - initial_validation.get("accuracy", 0)
        }

        # Determine if improved - now considers validation checks too
        metrics_improved = any(v > 0 for k, v in delta.items() if k not in ["checks_passed", "accuracy"])
        validation_improved = delta["checks_passed"] > 0 or delta["accuracy"] > 0
        improved = metrics_improved or validation_improved

        test_results = {
            "improved": improved,
            "before_metrics": initial_metrics,
            "after_metrics": new_metrics,
            "delta": delta,
            "new_lineages": new_lineages,
            # NEW: Include comprehensive validation comparison
            "before_validation": {
                "recall_scores": initial_recall_scores,
                "checks_passed": initial_checks_passed,
                "accuracy": initial_validation.get("accuracy", 0)
            },
            "after_validation": {
                "recall_scores": new_recall_scores,
                "checks_passed": new_checks_passed,
                "accuracy": new_validation.get("accuracy", 0),
                "passed": new_validation.get("passed", False)
            }
        }

        print(f"\n   Result: {'[OK] IMPROVED' if improved else '[FAIL] NOT IMPROVED'}")

        # Rollback if not improved
        if not improved:
            print("\n[BACK]  Rolling back changes...")
            rollback_manager = SelectiveRollback()

            for module_path, backup_path in code_backup_paths.items():
                rollback_manager.rollback(module_path, backup_path)
                print(f"   [BACK]  Rolled back: {os.path.basename(module_path)}")

            # Update fix statuses
            for fix in applied_fixes:
                if fix["status"] == "applied":
                    fix["status"] = "rolled_back"
        else:
            # Update state with new lineages
            state["end_to_end_lineages"] = new_lineages

        # Save test results
        session_folder = state.get("session_output_folder")
        if session_folder:
            save_json_file(
                os.path.join(session_folder, "test_results.json"),
                test_results
            )

        return {
            **state,
            "test_results": test_results,
            "applied_fixes": applied_fixes,
        }

    except Exception as e:
        print(f"[FAIL] Test execution failed: {e}")

        # Rollback on error
        rollback_manager = SelectiveRollback()
        for module_path, backup_path in code_backup_paths.items():
            rollback_manager.rollback(module_path, backup_path)

        return {
            **state,
            "test_results": {
                "improved": False,
                "reason": "execution_error",
                "error": str(e)
            }
        }


# =============================================================================
# HELPER FUNCTIONS
# =============================================================================

def _get_xml_sample(xml_filepath: str, max_chars: int = 2000) -> str:
    """Get a sample of the XML file for LLM analysis."""
    try:
        with open(xml_filepath, 'r', encoding='utf-8') as f:
            content = f.read(max_chars)
        return content
    except Exception:
        return ""


def _parse_llm_json_response(response: str) -> Optional[Dict[str, Any]]:
    """Parse JSON from LLM response."""
    try:
        # Try to extract JSON from the response
        json_match = re.search(r'\{[\s\S]*\}', response)
        if json_match:
            return json.loads(json_match.group())
    except Exception:
        pass
    return None


def _identify_target_modules(issues: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """Identify which code modules to target based on issues (updated for 11 validation rules)."""
    module_mapping = {
        # Original mappings
        "missing_source": {
            "module": "experts/field_mapping_expert.py",
            "issue": "Field mapping not capturing all source connections",
            "priority": "high"
        },
        "missing_expression": {
            "module": "parsers/expression_parser.py",
            "issue": "Expression parsing incomplete",
            "priority": "medium"
        },
        "parse_error": {
            "module": "parsers/powermart_parser_xdm.py",
            "issue": "XML parsing error",
            "priority": "high"
        },
        "connector_missing": {
            "module": "parsers/connector_parser.py",
            "issue": "Connector not being captured",
            "priority": "high"
        },
        "pattern_missed": {
            "module": "experts/pattern_detector.py",
            "issue": "Pattern detection not working",
            "priority": "medium"
        },
        "incomplete_chain": {
            "module": "lineage/path_tracer.py",
            "issue": "Transformation chain incomplete",
            "priority": "medium"
        },
        # NEW mappings for 11 validation rules
        "missing_connector": {
            "module": "parsers/connector_parser.py",
            "issue": "CONNECTOR elements not fully captured from XML",
            "priority": "high"
        },
        "low_connector_coverage": {
            "module": "lineage/path_tracer.py",
            "issue": "Connector coverage below 85% - path tracing incomplete",
            "priority": "high"
        },
        "empty_source": {
            "module": "experts/field_mapping_expert.py",
            "issue": "Fields have empty source attribution",
            "priority": "high"
        },
        "duplicate_entry": {
            "module": "lineage/lineage_extractor.py",
            "issue": "Duplicate lineage entries being created",
            "priority": "medium"
        },
        "expression_mismatch": {
            "module": "parsers/expression_parser.py",
            "issue": "Expression extraction not matching XML EXPRESSION attributes",
            "priority": "medium"
        },
        "chain_validation_error": {
            "module": "lineage/path_tracer.py",
            "issue": "Unknown elements in transformation chains",
            "priority": "medium"
        },
        "missing_field": {
            "module": "experts/field_mapping_expert.py",
            "issue": "Target fields not being captured",
            "priority": "high"
        },
        "source_completeness": {
            "module": "parsers/powermart_parser_xdm.py",
            "issue": "Source tables not fully extracted from XML",
            "priority": "high"
        }
    }

    targeted = []
    seen_modules = set()

    for issue in issues:
        issue_type = issue.get("type", "")
        if issue_type in module_mapping and issue_type not in seen_modules:
            targeted.append(module_mapping[issue_type])
            seen_modules.add(issue_type)

    return targeted


def _get_full_module_path(module_path: str) -> str:
    """Get the full path to a module file."""
    # Get the informatica_reverse_engineering directory
    current_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    return os.path.join(current_dir, module_path)
