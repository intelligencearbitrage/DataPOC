"""
LangGraph Workflow Definition for Informatica Agentic Solution.

This module defines the multi-agent workflow for post-output validation
and self-healing code improvements.
"""

from langgraph.graph import StateGraph, START, END
from langgraph.checkpoint.memory import InMemorySaver
from typing_extensions import TypedDict
from typing import Optional, List, Dict, Any, Literal

# Support both package import and direct import
try:
    from . import agents as ag
except ImportError:
    import agents as ag


class OrchestrationState(TypedDict):
    """
    State for the Informatica Agentic orchestration workflow.
    
    This state is used POST-output generation to validate and improve
    the reverse engineering results.
    """
    
    # =========================================================================
    # INPUT TRACKING
    # =========================================================================
    user_input: str
    xml_filepath: str
    ground_truth_filepath: Optional[str]
    ground_truth: Optional[Dict[str, Any]]
    output_directory: str
    
    # =========================================================================
    # PHASE OUTPUTS FROM EXISTING PIPELINE
    # =========================================================================
    # XDM Parse Result from Phase 1
    parse_result: Optional[Dict[str, Any]]
    
    # Lineage output from LineageExtractor
    lineage_output: Optional[Dict[str, Any]]
    
    # End-to-end lineages (field-level mappings)
    end_to_end_lineages: Optional[List[Dict[str, Any]]]
    
    # Documentation and exports
    documentation_output: Optional[Dict[str, Any]]
    excel_output_path: Optional[str]
    json_output_path: Optional[str]
    html_output_path: Optional[str]
    
    # =========================================================================
    # VALIDATION TRACKING
    # =========================================================================
    lineage_validation_result: Optional[Dict[str, Any]]
    lineage_validation_passed: bool
    
    # Detailed validation metrics
    validation_metrics: Optional[Dict[str, Any]]
    # {
    #     "field_coverage": {"total", "mapped", "unmapped", "percentage"},
    #     "source_tracing": {"with_source", "without_source", "orphan_pct"},
    #     "transformation_quality": {"parsed", "explained", "quality_score"},
    #     "pattern_detection": {"detected", "validated", "accuracy"}
    # }
    
    # =========================================================================
    # ERROR ANALYSIS
    # =========================================================================
    error_analysis: Optional[Dict[str, Any]]
    # {
    #     "root_causes": [...],
    #     "fix_strategy": "code" | "output" | "both",
    #     "targeted_modules": [{module, issue, priority}],
    #     "confidence": float
    # }
    
    fix_strategy: Optional[Literal["output"]]
    targeted_modules: Optional[List[Dict[str, Any]]]

    # =========================================================================
    # OUTPUT FIX TRACKING
    # =========================================================================
    applied_fixes: Optional[List[Dict[str, Any]]]
    # [{
    #     "type": str,
    #     "field": str,
    #     "description": str,
    #     "status": "applied" | "failed"
    # }]
    
    # =========================================================================
    # RETRY MANAGEMENT
    # =========================================================================
    lineage_retry_count: int
    parser_retry_count: int
    max_retries: int  # Default: 3
    
    # =========================================================================
    # HISTORY TRACKING
    # =========================================================================
    validation_history: Optional[List[Dict[str, Any]]]
    refinement_history: Optional[List[Dict[str, Any]]]
    
    # Session tracking
    session_id: Optional[str]
    session_output_folder: Optional[str]


class MultiAgentGraph:
    """
    A StateGraph that orchestrates agents for post-output validation
    and output-only refinement.

    The refiner only patches files in output/ — script fixes are done
    by the developer using Claude directly.
    """

    def __init__(self):
        """Initialize agent node references."""
        self.trigger_node = ag.trigger_node
        self.lineage_validator_node = ag.lineage_validator_node
        self.error_analyzer_node = ag.error_analyzer_node
        self.output_corrector_node = ag.output_corrector_node

    def build_graph(self) -> StateGraph:
        """
        Build the multi-agent graph structure.

        Workflow:
        1. Trigger Node: Load existing outputs, initialize validation
        2. Lineage Validator: Compare against ground truth
        3. Error Analyzer: Classify issues (if validation fails)
        4. Output Corrector: Patch output files directly
        5. Loop back to Validator or END
        """
        workflow = StateGraph(OrchestrationState)

        # Add nodes
        workflow.add_node("Trigger", self.trigger_node)
        workflow.add_node("Lineage_Validator", self.lineage_validator_node)
        workflow.add_node("Error_Analyzer", self.error_analyzer_node)
        workflow.add_node("Output_Corrector", self.output_corrector_node)

        # =====================================================================
        # WORKFLOW EDGES
        # =====================================================================

        # Start → Trigger → Lineage Validator
        workflow.add_edge(START, "Trigger")
        workflow.add_edge("Trigger", "Lineage_Validator")

        # Lineage Validator → (Pass → END) or (Fail → Error Analyzer)
        workflow.add_conditional_edges(
            "Lineage_Validator",
            self.route_lineage_validation,
            {
                "pass": END,
                "fail": "Error_Analyzer",
                "max_retries": END
            }
        )

        # Error Analyzer → Output Corrector or give up
        workflow.add_conditional_edges(
            "Error_Analyzer",
            self.route_error_analysis,
            {
                "fix": "Output_Corrector",
                "give_up": END
            }
        )

        # Output Corrector → Re-validate or done
        workflow.add_conditional_edges(
            "Output_Corrector",
            self.route_output_correction,
            {
                "revalidate": "Lineage_Validator",
                "done": END
            }
        )

        # Compile with checkpointer for state persistence
        graph = workflow.compile(checkpointer=InMemorySaver())

        return graph

    # =========================================================================
    # ROUTING FUNCTIONS
    # =========================================================================
    
    def route_lineage_validation(
        self, state: OrchestrationState
    ) -> Literal["pass", "fail", "max_retries"]:
        """Route based on lineage validation results."""
        validation_passed = state.get("lineage_validation_passed", False)
        retry_count = state.get("lineage_retry_count", 0)
        max_retries = state.get("max_retries", 3)
        
        if validation_passed:
            metrics = state.get("validation_metrics", {})
            coverage = metrics.get("field_coverage", {}).get("percentage", 0)
            print(f"[OK] Lineage validation PASSED (coverage: {coverage:.1f}%)")
            return "pass"
        
        if retry_count >= max_retries:
            print(f"[WARN]  Max retries ({max_retries}) exceeded - proceeding with best effort")
            return "max_retries"
        
        print(f"[RETRY] Lineage validation FAILED - analyzing errors (attempt {retry_count + 1}/{max_retries})")
        return "fail"

    def route_error_analysis(
        self, state: OrchestrationState
    ) -> Literal["fix", "give_up"]:
        """Route based on error analysis results."""
        error_analysis = state.get("error_analysis") or {}
        confidence = error_analysis.get("confidence", 0)
        issues = error_analysis.get("issue_classification", {})
        output_fixable = issues.get("output_fixable", [])

        if confidence < 0.3:
            print(f"[WARN]  Low confidence ({confidence:.1%}) in error analysis - giving up")
            return "give_up"

        if output_fixable:
            print(f"[FIX] Strategy: OUTPUT FIX - patching output directly ({len(output_fixable)} issues)")
            return "fix"

        # Even if classifier found nothing, try output fix if there are validation issues
        validation_issues = state.get("validation_issues") or []
        if validation_issues:
            print(f"[FIX] Strategy: OUTPUT FIX - attempting to patch {len(validation_issues)} validation issues")
            return "fix"

        print(f"[WARN]  No fixable issues identified")
        return "give_up"

    def route_output_correction(
        self, state: OrchestrationState
    ) -> Literal["revalidate", "done"]:
        """Route after output correction."""
        output_enhanced = state.get("output_enhanced", False)

        if output_enhanced:
            print(f"[OK] Output enhanced - re-validating")
            return "revalidate"

        print(f"[WARN]  Output correction complete - no enhancements made")
        return "done"


def create_initial_state(
    xml_filepath: str,
    output_directory: str,
    ground_truth_filepath: Optional[str] = None,
    max_retries: int = 3
) -> OrchestrationState:
    """
    Create initial state for the agentic workflow.
    
    Args:
        xml_filepath: Path to the Informatica XML file
        output_directory: Path to the output directory with generated files
        ground_truth_filepath: Optional path to ground truth JSON
        max_retries: Maximum number of refinement attempts
    
    Returns:
        OrchestrationState ready for workflow execution
    """
    import uuid
    from datetime import datetime
    
    session_id = f"session_{datetime.now().strftime('%Y%m%d_%H%M%S')}_{uuid.uuid4().hex[:8]}"
    
    return OrchestrationState(
        user_input=f"Validate and improve lineage for {xml_filepath}",
        xml_filepath=xml_filepath,
        ground_truth_filepath=ground_truth_filepath,
        ground_truth=None,
        output_directory=output_directory,
        
        # Phase outputs (will be loaded by trigger node)
        parse_result=None,
        lineage_output=None,
        end_to_end_lineages=None,
        documentation_output=None,
        excel_output_path=None,
        json_output_path=None,
        html_output_path=None,
        
        # Validation
        lineage_validation_result=None,
        lineage_validation_passed=False,
        validation_metrics=None,
        
        # Error analysis
        error_analysis=None,
        fix_strategy=None,
        targeted_modules=None,

        # Output fixes
        applied_fixes=None,
        
        # Retry management
        lineage_retry_count=0,
        parser_retry_count=0,
        max_retries=max_retries,
        
        # History
        validation_history=[],
        refinement_history=[],
        session_id=session_id,
        session_output_folder=None
    )
