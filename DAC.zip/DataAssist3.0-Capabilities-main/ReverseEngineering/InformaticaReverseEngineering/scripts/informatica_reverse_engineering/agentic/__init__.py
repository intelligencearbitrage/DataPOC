"""
Informatica Reverse Engineering - Agentic Solution

An intelligent multi-agent system for improving Informatica XML reverse engineering
through self-healing code fixes and output validation.

This module is triggered POST-output generation to:
1. Validate lineage output against ground truth
2. Analyze errors and classify fix strategies
3. Apply code fixes or output enhancements
4. Re-test and verify improvements

Key Components:
- graph.py: LangGraph workflow orchestration
- agents.py: Individual agent node implementations
- prompts.py: LLM prompts for each agent
- tools.py: Agent tools for validation and extraction
- utils.py: Helper functions and utilities
- output_corrector.py: Intelligent error triage
- selective_rollback.py: Safe code rollback mechanism
"""

# Lazy imports — graph and agents require LangGraph/LangChain which may not be installed.
# Individual modules (prompts, utils, output_corrector, selective_rollback) can be
# imported directly without the full LLM stack.
try:
    from .graph import MultiAgentGraph, OrchestrationState
    from .agents import (
        trigger_node,
        lineage_validator_node,
        error_analyzer_node,
        output_corrector_node,
        code_refiner_node,
        code_applicator_node,
        test_executor_node,
    )
except ImportError:
    try:
        from graph import MultiAgentGraph, OrchestrationState
        from agents import (
            trigger_node,
            lineage_validator_node,
            error_analyzer_node,
            output_corrector_node,
            code_refiner_node,
            code_applicator_node,
            test_executor_node,
        )
    except ImportError:
        # LangGraph/LangChain not installed — set to None so individual modules
        # (prompts, utils, output_corrector, selective_rollback) still work.
        MultiAgentGraph = None
        OrchestrationState = None
        trigger_node = None
        lineage_validator_node = None
        error_analyzer_node = None
        output_corrector_node = None
        code_refiner_node = None
        code_applicator_node = None
        test_executor_node = None

__version__ = "1.0.0"
__all__ = [
    "MultiAgentGraph",
    "OrchestrationState",
    "trigger_node",
    "lineage_validator_node",
    "error_analyzer_node",
    "output_corrector_node",
    "code_refiner_node",
    "code_applicator_node",
    "test_executor_node",
]
