"""
Output Corrector - Intelligent Error Triage and Output Enhancement.

This module analyzes validation errors and decides:
1. CODE FIX: Parser/expert has a bug → route to code refiner
2. OUTPUT FIX: Parser working but missed data → extract from XML directly

The corrector can also directly enhance output by re-extracting data
from the original XML file when the issue is data coverage rather than
parser logic.
"""

import re
import json
from typing import Any, Dict, List, Optional, Tuple
from lxml import etree
from pathlib import Path


class OutputCorrector:
    """Intelligent error triage and output correction for Informatica lineage."""
    
    def __init__(self):
        """Initialize the output corrector with classification patterns."""
        
        # Patterns for issues we can fix by direct output enhancement
        self.output_fixable_patterns = {
            "missing_source": r"missing.*source|source.*not found|no source",
            "missing_expression": r"missing.*expression|expression.*empty|no expression",
            "incomplete_chain": r"incomplete.*chain|chain.*missing|transformation chain",
            "unmapped_field": r"unmapped|not mapped|field.*missing",
            "missing_explanation": r"missing.*explanation|no explanation|explanation.*empty"
        }
        
        # Patterns that need code fixes
        self.code_fix_patterns = {
            "parse_error": r"parse error|parsing failed|xml error|syntax error",
            "connector_missing": r"connector.*not.*found|missing connector|connector.*error",
            "pattern_missed": r"pattern.*not.*detected|missed pattern|pattern.*error",
            "type_error": r"type error|invalid type|wrong type",
            "structure_error": r"structure.*invalid|malformed|corrupted"
        }
    
    def analyze_and_triage(
        self,
        validation_result: Dict[str, Any],
        xml_filepath: str,
        current_output: Dict[str, Any]
    ) -> Dict[str, Any]:
        """
        Analyze validation errors and determine the fix strategy.
        
        Args:
            validation_result: Validation result with issues
            xml_filepath: Path to the original Informatica XML
            current_output: Current lineage output
        
        Returns:
            Triage result with fix strategy and details
        """
        issues = validation_result.get("issues", [])
        
        result = {
            "fix_strategy": None,
            "output_fixable": [],
            "code_fixable": [],
            "unknown": [],
            "confidence": 0.0,
            "enhancement_potential": {}
        }
        
        for issue in issues:
            issue_type = issue.get("type", "")
            description = issue.get("description", str(issue))
            
            # Classify the issue
            classified = False
            
            # Check if output-fixable
            for pattern_name, pattern in self.output_fixable_patterns.items():
                if re.search(pattern, description.lower()) or issue_type == pattern_name:
                    result["output_fixable"].append({
                        "issue": issue,
                        "pattern": pattern_name,
                        "can_enhance": True
                    })
                    classified = True
                    break
            
            if not classified:
                # Check if code-fixable
                for pattern_name, pattern in self.code_fix_patterns.items():
                    if re.search(pattern, description.lower()) or issue_type == pattern_name:
                        result["code_fixable"].append({
                            "issue": issue,
                            "pattern": pattern_name
                        })
                        classified = True
                        break
            
            if not classified:
                result["unknown"].append(issue)
        
        # Determine overall strategy
        output_count = len(result["output_fixable"])
        code_count = len(result["code_fixable"])
        total = output_count + code_count + len(result["unknown"])
        
        if total == 0:
            result["fix_strategy"] = None
            result["confidence"] = 1.0
        elif code_count == 0 and output_count > 0:
            result["fix_strategy"] = "output"
            result["confidence"] = 0.8
        elif output_count == 0 and code_count > 0:
            result["fix_strategy"] = "code"
            result["confidence"] = 0.7
        elif output_count >= code_count:
            result["fix_strategy"] = "both"
            result["confidence"] = 0.6
        else:
            result["fix_strategy"] = "code"
            result["confidence"] = 0.5
        
        # Analyze enhancement potential
        if result["output_fixable"]:
            result["enhancement_potential"] = self._analyze_enhancement_potential(
                xml_filepath,
                result["output_fixable"]
            )
        
        return result
    
    def _analyze_enhancement_potential(
        self,
        xml_filepath: str,
        fixable_issues: List[Dict[str, Any]]
    ) -> Dict[str, Any]:
        """
        Analyze how much we can potentially enhance from the XML.
        
        Args:
            xml_filepath: Path to the XML file
            fixable_issues: List of output-fixable issues
        
        Returns:
            Enhancement potential analysis
        """
        potential = {
            "can_find_sources": False,
            "can_find_expressions": False,
            "estimated_improvement": 0.0
        }
        
        try:
            tree = etree.parse(xml_filepath)
            root = tree.getroot()
            
            # Check if XML has connectors we can use
            connectors = root.xpath(".//CONNECTOR")
            if connectors:
                potential["can_find_sources"] = True
                potential["connector_count"] = len(connectors)
            
            # Check if XML has expressions we can use
            expressions = root.xpath(".//TRANSFORMFIELD[@EXPRESSION]")
            if expressions:
                potential["can_find_expressions"] = True
                potential["expression_count"] = len(expressions)
            
            # Estimate improvement potential
            issue_count = len(fixable_issues)
            if potential["can_find_sources"] and potential["can_find_expressions"]:
                potential["estimated_improvement"] = min(0.9, issue_count * 0.15)
            elif potential["can_find_sources"]:
                potential["estimated_improvement"] = min(0.6, issue_count * 0.1)
            
        except Exception as e:
            potential["error"] = str(e)
        
        return potential
    
    def find_missing_source(
        self,
        xml_filepath: str,
        target_table: str,
        target_field: str
    ) -> Optional[Dict[str, Any]]:
        """
        Find missing source for a target field by tracing connectors in XML.
        
        Args:
            xml_filepath: Path to the Informatica XML
            target_table: Target table name
            target_field: Target field name
        
        Returns:
            Dictionary with found sources and transformation chain
        """
        try:
            tree = etree.parse(xml_filepath)
            root = tree.getroot()
            
            sources = []
            chain = []
            
            # Find the target instance
            # Target tables typically appear as TARGET or target transformation
            current_instance = target_table
            current_field = target_field
            visited = set()
            
            # Trace backwards through connectors
            max_hops = 20  # Prevent infinite loops
            hop = 0
            
            while hop < max_hops:
                hop += 1
                
                if current_instance in visited:
                    break
                visited.add(current_instance)
                
                # Find connector to this instance/field
                xpath = f".//CONNECTOR[@TOINSTANCE='{current_instance}' and @TOFIELD='{current_field}']"
                connectors = root.xpath(xpath)
                
                if not connectors:
                    # Try without field match
                    xpath = f".//CONNECTOR[@TOINSTANCE='{current_instance}']"
                    connectors = root.xpath(xpath)
                    connectors = [c for c in connectors if c.get("TOFIELD", "").upper() == current_field.upper()]
                
                if not connectors:
                    break
                
                conn = connectors[0]
                from_instance = conn.get("FROMINSTANCE", "")
                from_field = conn.get("FROMFIELD", "")
                
                chain.insert(0, f"{from_instance}.{from_field}")
                
                # Check if this is a source (SQ_, source qualifier or actual source)
                if self._is_source_instance(root, from_instance):
                    sources.append({
                        "table": from_instance,
                        "field": from_field,
                        "type": "source"
                    })
                    break
                
                # Continue tracing
                current_instance = from_instance
                current_field = from_field
            
            if sources:
                chain.append(f"{target_table}.{target_field}")
                return {
                    "sources": sources,
                    "chain": " → ".join(chain),
                    "hops": hop
                }
            
        except Exception as e:
            print(f"Error finding missing source: {e}")
        
        return None
    
    def _is_source_instance(self, root: etree._Element, instance_name: str) -> bool:
        """Check if an instance is a source (source qualifier or source table)."""
        # Check for source qualifier pattern
        if instance_name.upper().startswith("SQ_"):
            return True
        
        # Check if it's defined as a SOURCE in the XML
        sources = root.xpath(f".//SOURCE[@NAME='{instance_name}']")
        if sources:
            return True
        
        # Check for SOURCEINSTANCE
        source_instances = root.xpath(f".//INSTANCE[@NAME='{instance_name}']")
        for inst in source_instances:
            if inst.get("TYPE", "").upper() == "SOURCE":
                return True
        
        return False
    
    def explain_expression(
        self,
        xml_filepath: str,
        field_name: str
    ) -> Optional[str]:
        """
        Find and explain expression for a field.
        
        Args:
            xml_filepath: Path to the Informatica XML
            field_name: Field name to find expression for
        
        Returns:
            Human-readable explanation of the expression
        """
        try:
            tree = etree.parse(xml_filepath)
            root = tree.getroot()
            
            # Find the field's expression
            xpath = f".//TRANSFORMFIELD[@NAME='{field_name}']"
            fields = root.xpath(xpath)
            
            for field in fields:
                expression = field.get("EXPRESSION", "")
                if expression:
                    return self._generate_expression_explanation(expression, field_name)
            
            # Try case-insensitive search
            all_fields = root.xpath(".//TRANSFORMFIELD[@EXPRESSION]")
            for field in all_fields:
                if field.get("NAME", "").upper() == field_name.upper():
                    expression = field.get("EXPRESSION", "")
                    return self._generate_expression_explanation(expression, field_name)
        
        except Exception as e:
            print(f"Error explaining expression: {e}")
        
        return None
    
    def _generate_expression_explanation(
        self,
        expression: str,
        field_name: str
    ) -> str:
        """
        Generate a human-readable explanation of an expression.
        
        Args:
            expression: The Informatica expression
            field_name: Name of the field
        
        Returns:
            Human-readable explanation
        """
        explanations = []
        expr_upper = expression.upper()
        
        # Detect common patterns
        if "IIF" in expr_upper:
            explanations.append("Conditional logic (IF-THEN-ELSE)")
        if "DECODE" in expr_upper:
            explanations.append("Value mapping/lookup based on input")
        if "NVL" in expr_upper or "ISNULL" in expr_upper:
            explanations.append("NULL value handling with default")
        if "LTRIM" in expr_upper or "RTRIM" in expr_upper or "TRIM" in expr_upper:
            explanations.append("String trimming to remove whitespace")
        if "UPPER" in expr_upper:
            explanations.append("Convert to uppercase")
        if "LOWER" in expr_upper:
            explanations.append("Convert to lowercase")
        if "TO_DATE" in expr_upper:
            explanations.append("String to date conversion")
        if "TO_CHAR" in expr_upper:
            explanations.append("Convert to string format")
        if "TO_INTEGER" in expr_upper or "TO_DECIMAL" in expr_upper:
            explanations.append("Numeric type conversion")
        if "SUBSTR" in expr_upper:
            explanations.append("Extract substring from text")
        if "CONCAT" in expr_upper or "||" in expression:
            explanations.append("String concatenation")
        if "LOOKUP" in expr_upper or ":LKP" in expr_upper:
            explanations.append("Lookup from reference table")
        if "SUM" in expr_upper or "AVG" in expr_upper or "COUNT" in expr_upper:
            explanations.append("Aggregation calculation")
        
        if explanations:
            return f"Field '{field_name}': {'; '.join(explanations)}. Expression: {expression}"
        else:
            return f"Field '{field_name}' transformation: {expression}"
    
    def enhance_lineage_entry(
        self,
        xml_filepath: str,
        lineage_entry: Dict[str, Any]
    ) -> Dict[str, Any]:
        """
        Enhance a lineage entry by extracting additional data from XML.
        
        Args:
            xml_filepath: Path to the Informatica XML
            lineage_entry: Current lineage entry to enhance
        
        Returns:
            Enhanced lineage entry
        """
        enhanced = lineage_entry.copy()
        
        target_table = lineage_entry.get("target_table", "")
        target_field = lineage_entry.get("target_field", "")
        
        # Try to find missing sources
        if not lineage_entry.get("ultimate_sources"):
            source_result = self.find_missing_source(
                xml_filepath,
                target_table,
                target_field
            )
            if source_result:
                enhanced["ultimate_sources"] = source_result["sources"]
                enhanced["transformation_chain"] = source_result.get("chain", "")
                enhanced["enhanced"] = True
        
        # Try to add expression explanation
        if not lineage_entry.get("transformation_explanation"):
            explanation = self.explain_expression(xml_filepath, target_field)
            if explanation:
                enhanced["transformation_explanation"] = explanation
                enhanced["enhanced"] = True
        
        return enhanced
    
    def batch_enhance_output(
        self,
        xml_filepath: str,
        lineages: List[Dict[str, Any]],
        issues: List[Dict[str, Any]]
    ) -> Tuple[List[Dict[str, Any]], Dict[str, Any]]:
        """
        Batch enhance multiple lineage entries.
        
        Args:
            xml_filepath: Path to the Informatica XML
            lineages: List of lineage entries
            issues: List of identified issues
        
        Returns:
            Tuple of (enhanced lineages, enhancement statistics)
        """
        enhanced_lineages = []
        stats = {
            "total": len(lineages),
            "enhanced": 0,
            "sources_added": 0,
            "explanations_added": 0,
            "unchanged": 0
        }
        
        # Build lookup of issues by field
        issue_fields = set()
        for issue in issues:
            field = issue.get("target_field") or issue.get("affected_field")
            if field:
                issue_fields.add(field)
        
        for lineage in lineages:
            target_field = lineage.get("target_field", "")
            
            # Only enhance if there's a known issue
            if target_field in issue_fields or not lineage.get("ultimate_sources"):
                enhanced = self.enhance_lineage_entry(xml_filepath, lineage)
                
                if enhanced.get("enhanced"):
                    stats["enhanced"] += 1
                    if enhanced.get("ultimate_sources") and not lineage.get("ultimate_sources"):
                        stats["sources_added"] += 1
                    if enhanced.get("transformation_explanation") and not lineage.get("transformation_explanation"):
                        stats["explanations_added"] += 1
                    enhanced_lineages.append(enhanced)
                else:
                    stats["unchanged"] += 1
                    enhanced_lineages.append(lineage)
            else:
                stats["unchanged"] += 1
                enhanced_lineages.append(lineage)
        
        return enhanced_lineages, stats
