"""
Data models for multi-XML lineage aggregation.

These models represent the unified lineage graph structure that combines
lineage information from multiple Informatica PowerCenter XML files.
"""

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Set
from enum import Enum


class TransformationType(Enum):
    """Types of transformations for complexity analysis."""
    EXTRACT = "extract"           # Source extraction, minimal transformation
    TRANSFORM = "transform"       # Expression, calculation, cleansing
    AGGREGATE = "aggregate"       # Aggregation, grouping
    LOOKUP = "lookup"             # Lookup transformation
    JOIN = "join"                 # Joiner transformation
    FILTER = "filter"             # Filter transformation
    ROUTE = "route"               # Router transformation
    UPDATE_STRATEGY = "update_strategy"  # Update strategy
    UNKNOWN = "unknown"


class NodeType(Enum):
    """Types of nodes in the unified graph."""
    SOURCE = "source"             # Ultimate source table
    TARGET = "target"             # Ultimate target table
    STAGING = "staging"           # Intermediate staging table
    LOOKUP = "lookup"             # Lookup reference table
    WORK = "work"                 # Work/temporary table
    UNKNOWN = "unknown"


@dataclass
class TableNode:
    """
    Node in the unified lineage graph representing a table.

    Attributes:
        table_name: Name of the table
        source_xml: XML file this table was extracted from
        node_type: Type of node (source, target, staging, etc.)
        transformation_types: Set of transformation types applied
        hop_count: Distance from ultimate sources (computed)
        expressions: List of transformation expressions applied to this table
        columns: Dictionary of column definitions {col_name: {datatype, precision, scale}}
        database_type: Database type (Oracle, SQL Server, etc.)
        owner: Schema/owner name
        is_target: Boolean flag indicating if this table appeared as a TARGET
        target_columns: Original TARGET column definitions (preserved separately)
    """
    table_name: str
    source_xml: str
    node_type: NodeType = NodeType.UNKNOWN
    transformation_types: Set[TransformationType] = field(default_factory=set)
    hop_count: int = -1  # -1 means not computed
    expressions: List[str] = field(default_factory=list)
    columns: Dict[str, Dict[str, Any]] = field(default_factory=dict)
    database_type: str = ""
    owner: str = ""
    mapping_name: str = ""
    is_target: bool = False
    target_columns: Optional[Dict[str, Dict[str, Any]]] = None

    @property
    def qualified_name(self) -> str:
        """Get fully qualified table name."""
        if self.owner:
            return f"{self.owner}.{self.table_name}"
        return self.table_name

    @property
    def complexity_score(self) -> float:
        """
        Calculate complexity score based on transformation types.

        Score ranges from 0.0 (simple) to 1.0 (complex).
        Used for medallion layer classification.
        """
        score = 0.0

        # Aggregation is highly complex
        if TransformationType.AGGREGATE in self.transformation_types:
            score += 0.3

        # Joins add complexity
        if TransformationType.JOIN in self.transformation_types:
            score += 0.2

        # Lookups add moderate complexity
        if TransformationType.LOOKUP in self.transformation_types:
            score += 0.15

        # Transformations/expressions add complexity
        if TransformationType.TRANSFORM in self.transformation_types:
            score += 0.1

        # Filters add slight complexity
        if TransformationType.FILTER in self.transformation_types:
            score += 0.05

        # Routers add complexity (multiple output paths)
        if TransformationType.ROUTE in self.transformation_types:
            score += 0.1

        # Update strategy adds complexity
        if TransformationType.UPDATE_STRATEGY in self.transformation_types:
            score += 0.1

        # Additional complexity from expression count
        expr_complexity = min(0.2, len(self.expressions) * 0.02)
        score += expr_complexity

        return min(1.0, score)

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary representation."""
        return {
            "table_name": self.table_name,
            "qualified_name": self.qualified_name,
            "source_xml": self.source_xml,
            "node_type": self.node_type.value,
            "transformation_types": [t.value for t in self.transformation_types],
            "hop_count": self.hop_count,
            "complexity_score": self.complexity_score,
            "expression_count": len(self.expressions),
            "column_count": len(self.columns),
            "database_type": self.database_type,
            "owner": self.owner,
            "mapping_name": self.mapping_name,
        }


@dataclass
class TableEdge:
    """
    Edge in the unified lineage graph representing data flow between tables.

    Attributes:
        source_table: Source table name
        target_table: Target table name
        source_xml: XML file this edge was derived from
        transformation_type: Type of transformation on this edge
        field_mappings: Field-level mappings {target_field: source_field}
        expressions: Transformation expressions
    """
    source_table: str
    target_table: str
    source_xml: str
    transformation_type: TransformationType = TransformationType.UNKNOWN
    field_mappings: Dict[str, str] = field(default_factory=dict)
    expressions: Dict[str, str] = field(default_factory=dict)  # {target_field: expression}

    @property
    def edge_id(self) -> str:
        """Get unique edge identifier."""
        return f"{self.source_table}->{self.target_table}"

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary representation."""
        return {
            "source_table": self.source_table,
            "target_table": self.target_table,
            "source_xml": self.source_xml,
            "transformation_type": self.transformation_type.value,
            "field_mapping_count": len(self.field_mappings),
            "expression_count": len(self.expressions),
        }


@dataclass
class CrossMappingLink:
    """
    Link between tables across different mappings/XMLs.

    Represents a connection where a target table in one mapping
    becomes a source table in another mapping.
    """
    source_xml: str
    source_table: str
    source_mapping: str
    target_xml: str
    target_table: str
    target_mapping: str
    link_type: str = "direct"  # direct, staging, lookup
    confidence: float = 1.0    # Confidence in the link (1.0 = exact match)

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary representation."""
        return {
            "source_xml": self.source_xml,
            "source_table": self.source_table,
            "source_mapping": self.source_mapping,
            "target_xml": self.target_xml,
            "target_table": self.target_table,
            "target_mapping": self.target_mapping,
            "link_type": self.link_type,
            "confidence": self.confidence,
        }


@dataclass
class TableConflict:
    """
    Represents a conflict when the same table appears in multiple XMLs
    with different structures.
    """
    table_name: str
    source_files: List[str]
    conflict_type: str  # schema_mismatch, type_mismatch, column_mismatch
    differences: Dict[str, Any] = field(default_factory=dict)
    recommendation: str = ""
    requires_manual_review: bool = True

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary representation."""
        return {
            "table_name": self.table_name,
            "source_files": self.source_files,
            "conflict_type": self.conflict_type,
            "differences": self.differences,
            "recommendation": self.recommendation,
            "requires_manual_review": self.requires_manual_review,
        }


@dataclass
class UnifiedLineageGraph:
    """
    Unified lineage graph combining multiple Informatica XMLs.

    This is the main data structure for multi-XML analysis,
    containing all tables, edges, and cross-mapping links.
    """
    tables: Dict[str, TableNode] = field(default_factory=dict)  # table_name -> TableNode
    edges: List[TableEdge] = field(default_factory=list)
    cross_mapping_links: List[CrossMappingLink] = field(default_factory=list)
    conflicts: List[TableConflict] = field(default_factory=list)

    # Adjacency lists for graph traversal
    adjacency_list: Dict[str, List[str]] = field(default_factory=dict)  # source -> [targets]
    reverse_adjacency: Dict[str, List[str]] = field(default_factory=dict)  # target -> [sources]

    # Metadata
    source_xmls: List[str] = field(default_factory=list)
    creation_timestamp: str = ""

    def add_table(self, table: TableNode) -> None:
        """
        Add a table node to the graph.

        When a table appears as both SOURCE and TARGET:
        - TARGET columns are authoritative for output tables
        - SOURCE columns are kept for input-only tables
        - Both are tracked for lineage analysis
        """
        existing = self.tables.get(table.table_name)
        if existing:
            # Merge information from multiple sources
            existing.transformation_types.update(table.transformation_types)
            existing.expressions.extend(table.expressions)

            # Handle column merging based on node type
            if table.node_type == NodeType.TARGET:
                # This table is a TARGET - use TARGET column definitions
                existing.is_target = True
                existing.target_columns = table.columns.copy()
                # Replace columns with TARGET columns (authoritative)
                existing.columns = table.columns.copy()
                # Update node type to TARGET if not already
                if existing.node_type != NodeType.TARGET:
                    existing.node_type = NodeType.TARGET
            elif not existing.is_target:
                # Not yet seen as TARGET, so merge SOURCE columns
                # This handles intermediate transformations
                existing.columns.update(table.columns)
            # else: existing.is_target is True, don't overwrite TARGET columns

            # Update metadata if more specific
            if table.database_type and not existing.database_type:
                existing.database_type = table.database_type
            if table.owner and not existing.owner:
                existing.owner = table.owner
            if table.mapping_name and not existing.mapping_name:
                existing.mapping_name = table.mapping_name
        else:
            # First time seeing this table
            if table.node_type == NodeType.TARGET:
                table.is_target = True
                table.target_columns = table.columns.copy()
            self.tables[table.table_name] = table
            self.adjacency_list[table.table_name] = []
            self.reverse_adjacency[table.table_name] = []

    def add_edge(self, edge: TableEdge) -> None:
        """Add an edge to the graph."""
        self.edges.append(edge)

        # Update adjacency lists
        if edge.source_table not in self.adjacency_list:
            self.adjacency_list[edge.source_table] = []
        if edge.target_table not in self.reverse_adjacency:
            self.reverse_adjacency[edge.target_table] = []

        if edge.target_table not in self.adjacency_list[edge.source_table]:
            self.adjacency_list[edge.source_table].append(edge.target_table)
        if edge.source_table not in self.reverse_adjacency[edge.target_table]:
            self.reverse_adjacency[edge.target_table].append(edge.source_table)

    def add_cross_mapping_link(self, link: CrossMappingLink) -> None:
        """Add a cross-mapping link."""
        self.cross_mapping_links.append(link)

        # Also add to adjacency lists
        if link.source_table not in self.adjacency_list:
            self.adjacency_list[link.source_table] = []
        if link.target_table not in self.reverse_adjacency:
            self.reverse_adjacency[link.target_table] = []

        if link.target_table not in self.adjacency_list[link.source_table]:
            self.adjacency_list[link.source_table].append(link.target_table)
        if link.source_table not in self.reverse_adjacency[link.target_table]:
            self.reverse_adjacency[link.target_table].append(link.source_table)

    def add_conflict(self, conflict: TableConflict) -> None:
        """Add a table conflict."""
        self.conflicts.append(conflict)

    def get_ultimate_sources(self) -> List[TableNode]:
        """Get all tables that are ultimate sources (no incoming edges)."""
        return [
            table for name, table in self.tables.items()
            if not self.reverse_adjacency.get(name, [])
        ]

    def get_ultimate_targets(self) -> List[TableNode]:
        """Get all tables that are ultimate targets (no outgoing edges)."""
        return [
            table for name, table in self.tables.items()
            if not self.adjacency_list.get(name, [])
        ]

    def compute_hop_counts(self) -> None:
        """
        Compute hop counts for all tables using BFS from ultimate sources.

        Hop count represents the distance from the nearest ultimate source.
        """
        from collections import deque

        # Find ultimate sources
        sources = self.get_ultimate_sources()

        # Initialize hop counts
        for table in self.tables.values():
            table.hop_count = -1

        # BFS from all sources
        queue = deque()
        for source in sources:
            source.hop_count = 0
            queue.append(source.table_name)

        while queue:
            current_name = queue.popleft()
            current = self.tables.get(current_name)
            if not current:
                continue

            # Process all downstream tables
            for target_name in self.adjacency_list.get(current_name, []):
                target = self.tables.get(target_name)
                if target and (target.hop_count == -1 or target.hop_count > current.hop_count + 1):
                    target.hop_count = current.hop_count + 1
                    queue.append(target_name)

    def get_tables_by_hop_count(self, min_hops: int, max_hops: int) -> List[TableNode]:
        """Get tables within a hop count range."""
        return [
            table for table in self.tables.values()
            if min_hops <= table.hop_count <= max_hops
        ]

    def get_end_to_end_paths(self) -> List[List[str]]:
        """
        Get all end-to-end paths from ultimate sources to ultimate targets.

        Returns list of paths, where each path is a list of table names.
        """
        sources = self.get_ultimate_sources()
        targets = {t.table_name for t in self.get_ultimate_targets()}

        all_paths = []

        def dfs(current: str, path: List[str], visited: Set[str]):
            if current in visited:
                return  # Cycle detected

            visited.add(current)
            path.append(current)

            if current in targets:
                all_paths.append(path.copy())

            for next_table in self.adjacency_list.get(current, []):
                dfs(next_table, path, visited.copy())

            path.pop()

        for source in sources:
            dfs(source.table_name, [], set())

        return all_paths

    @property
    def table_count(self) -> int:
        """Get total number of tables."""
        return len(self.tables)

    @property
    def edge_count(self) -> int:
        """Get total number of edges."""
        return len(self.edges)

    @property
    def has_conflicts(self) -> bool:
        """Check if there are any conflicts requiring manual review."""
        return any(c.requires_manual_review for c in self.conflicts)

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary representation."""
        return {
            "table_count": self.table_count,
            "edge_count": self.edge_count,
            "cross_mapping_link_count": len(self.cross_mapping_links),
            "conflict_count": len(self.conflicts),
            "has_conflicts": self.has_conflicts,
            "source_xmls": self.source_xmls,
            "creation_timestamp": self.creation_timestamp,
            "tables": {name: t.to_dict() for name, t in self.tables.items()},
            "edges": [e.to_dict() for e in self.edges],
            "cross_mapping_links": [l.to_dict() for l in self.cross_mapping_links],
            "conflicts": [c.to_dict() for c in self.conflicts],
        }


# ============================================================================
# Parameter Models
# ============================================================================

class ParameterType(Enum):
    """Types of Informatica parameters."""
    MAPPING_PARAMETER = "mapping_parameter"      # $PM_*
    MAPPING_VARIABLE = "mapping_variable"        # $$*
    WORKFLOW_VARIABLE = "workflow_variable"      # $*
    SESSION_PARAMETER = "session_parameter"      # Session-level
    CONNECTION_VARIABLE = "connection_variable"  # $DBConnection_*
    SYSTEM_VARIABLE = "system_variable"          # $PM_INTEGRATION_SERVICE, etc.


@dataclass
class ParameterUsage:
    """
    Record of where a parameter is used.
    """
    xml_file: str
    mapping_name: str
    transformation_name: str
    field_name: str
    expression: str
    context: str = ""  # Additional context (SQL Query, Lookup Condition, etc.)

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary representation."""
        return {
            "xml_file": self.xml_file,
            "mapping_name": self.mapping_name,
            "transformation_name": self.transformation_name,
            "field_name": self.field_name,
            "expression": self.expression,
            "context": self.context,
        }


@dataclass
class Parameter:
    """
    Represents an Informatica parameter extracted from XMLs.
    """
    name: str
    parameter_type: ParameterType
    default_value: Optional[str] = None
    inferred_data_type: str = "VARCHAR"
    description: str = ""
    usages: List[ParameterUsage] = field(default_factory=list)
    source_xmls: List[str] = field(default_factory=list)

    @property
    def usage_count(self) -> int:
        """Get total number of usages."""
        return len(self.usages)

    @property
    def snowflake_param_name(self) -> str:
        """
        Get Snowflake-compatible parameter name.

        Converts Informatica parameter naming to Snowflake stored procedure parameter.
        """
        # Remove Informatica prefixes
        name = self.name
        if name.startswith("$$"):
            name = name[2:]
        elif name.startswith("$PM"):
            name = name[3:]
        elif name.startswith("$"):
            name = name[1:]

        # Add appropriate prefix based on type
        if self.parameter_type == ParameterType.MAPPING_PARAMETER:
            return f"P_{name.upper()}"
        elif self.parameter_type == ParameterType.MAPPING_VARIABLE:
            return f"V_{name.upper()}"
        elif self.parameter_type == ParameterType.SESSION_PARAMETER:
            return f"S_{name.upper()}"
        else:
            return f"P_{name.upper()}"

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary representation."""
        return {
            "name": self.name,
            "parameter_type": self.parameter_type.value,
            "snowflake_param_name": self.snowflake_param_name,
            "default_value": self.default_value,
            "inferred_data_type": self.inferred_data_type,
            "description": self.description,
            "usage_count": self.usage_count,
            "source_xmls": self.source_xmls,
            "usages": [u.to_dict() for u in self.usages],
        }


@dataclass
class ParameterCatalog:
    """
    Complete catalog of all parameters across multiple XMLs.
    """
    parameters: Dict[str, Parameter] = field(default_factory=dict)  # param_name -> Parameter

    def add_parameter(self, param: Parameter) -> None:
        """Add or merge a parameter."""
        existing = self.parameters.get(param.name)
        if existing:
            # Merge usages
            existing.usages.extend(param.usages)
            # Merge source XMLs
            for xml in param.source_xmls:
                if xml not in existing.source_xmls:
                    existing.source_xmls.append(xml)
        else:
            self.parameters[param.name] = param

    def get_by_type(self, param_type: ParameterType) -> List[Parameter]:
        """Get all parameters of a specific type."""
        return [p for p in self.parameters.values() if p.parameter_type == param_type]

    def get_for_mapping(self, mapping_name: str) -> List[Parameter]:
        """Get all parameters used in a specific mapping."""
        result = []
        for param in self.parameters.values():
            for usage in param.usages:
                if usage.mapping_name == mapping_name:
                    if param not in result:
                        result.append(param)
                    break
        return result

    @property
    def total_count(self) -> int:
        """Get total number of unique parameters."""
        return len(self.parameters)

    def to_stored_procedure_params(self) -> List[Dict[str, str]]:
        """
        Convert to stored procedure parameter definitions.

        Returns list of {name, type, default} for Snowflake stored procedure.
        """
        result = []
        for param in self.parameters.values():
            result.append({
                "name": param.snowflake_param_name,
                "type": param.inferred_data_type,
                "default": param.default_value or "NULL",
            })
        return result

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary representation."""
        return {
            "total_count": self.total_count,
            "by_type": {
                pt.value: len(self.get_by_type(pt))
                for pt in ParameterType
            },
            "parameters": {name: p.to_dict() for name, p in self.parameters.items()},
        }
