"""
Aggregation module for multi-XML lineage unification.

This module provides components for combining lineage from multiple
Informatica PowerCenter XML files into a unified dependency graph.
"""

from .aggregation_models import (
    TableNode,
    TableEdge,
    CrossMappingLink,
    TableConflict,
    UnifiedLineageGraph,
    ParameterType,
    Parameter,
    ParameterUsage,
    ParameterCatalog,
)
from .lineage_aggregator import InformaticaLineageAggregator
from .cross_reference_resolver import CrossReferenceResolver

__all__ = [
    "TableNode",
    "TableEdge",
    "CrossMappingLink",
    "TableConflict",
    "UnifiedLineageGraph",
    "ParameterType",
    "Parameter",
    "ParameterUsage",
    "ParameterCatalog",
    "InformaticaLineageAggregator",
    "CrossReferenceResolver",
]
