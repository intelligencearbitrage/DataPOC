"""
Transformation Metadata Extractor - Extracts complete transformation logic from Informatica XMLs.

This module ensures ZERO business logic loss by comprehensively extracting all
transformation metadata from Informatica PowerCenter XML files.
"""

import xml.etree.ElementTree as ET
from typing import Dict, List, Optional
import logging

from .transformation_metadata import (
    RouterTransformationMetadata,
    RouterGroupMetadata,
    JoinerTransformationMetadata,
    JoinType,
    LookupTransformationMetadata,
    FilterTransformationMetadata,
    AggregatorTransformationMetadata,
    UpdateStrategyTransformationMetadata,
    UnionTransformationMetadata,
    RankTransformationMetadata,
    SorterTransformationMetadata,
    SQLTransformationMetadata,
    TargetInstanceMetadata,
    MappingTransformationGraph,
)

logger = logging.getLogger(__name__)


class TransformationExtractor:
    """
    Extracts comprehensive transformation metadata from Informatica XML.

    Ensures all business logic is captured including:
    - Router groups with conditions and target mappings
    - Joiner conditions and join types
    - Lookup conditions and SQL overrides
    - Filter conditions
    - Aggregator groups and expressions
    - Update Strategy flags
    - All other transformation types
    """

    def extract_mapping_graph(self, xml_file: str, mapping_element: ET.Element) -> MappingTransformationGraph:
        """
        Extract complete transformation graph for a mapping.

        Args:
            xml_file: Source XML file path
            mapping_element: MAPPING XML element

        Returns:
            MappingTransformationGraph with complete metadata
        """
        mapping_name = mapping_element.get('NAME', 'UNKNOWN')
        graph = MappingTransformationGraph(
            mapping_name=mapping_name,
            source_file=xml_file
        )

        logger.info(f"Extracting transformation graph for mapping: {mapping_name}")

        # Extract all transformations by type
        for trans_elem in mapping_element.findall('.//TRANSFORMATION'):
            trans_type = trans_elem.get('TYPE', '')
            trans_name = trans_elem.get('NAME', '')

            if trans_type == 'Router':
                router_metadata = self._extract_router(trans_elem)
                graph.routers[trans_name] = router_metadata
                logger.info(f"  Extracted Router: {trans_name} with {len(router_metadata.groups)} groups")

            elif trans_type == 'Joiner':
                joiner_metadata = self._extract_joiner(trans_elem)
                graph.joiners[trans_name] = joiner_metadata
                logger.info(f"  Extracted Joiner: {trans_name} ({joiner_metadata.join_type.value})")

            elif trans_type == 'Lookup Procedure':
                lookup_metadata = self._extract_lookup(trans_elem)
                graph.lookups[trans_name] = lookup_metadata
                logger.info(f"  Extracted Lookup: {trans_name}")

            elif trans_type == 'Filter':
                filter_metadata = self._extract_filter(trans_elem)
                graph.filters[trans_name] = filter_metadata
                logger.info(f"  Extracted Filter: {trans_name}")

            elif trans_type == 'Aggregator':
                aggregator_metadata = self._extract_aggregator(trans_elem)
                graph.aggregators[trans_name] = aggregator_metadata
                logger.info(f"  Extracted Aggregator: {trans_name}")

            elif trans_type == 'Update Strategy':
                update_strategy_metadata = self._extract_update_strategy(trans_elem)
                graph.update_strategies[trans_name] = update_strategy_metadata
                logger.info(f"  Extracted Update Strategy: {trans_name}")

            elif trans_type == 'Union':
                union_metadata = self._extract_union(trans_elem)
                graph.unions[trans_name] = union_metadata
                logger.info(f"  Extracted Union: {trans_name}")

            elif trans_type == 'Rank':
                rank_metadata = self._extract_rank(trans_elem)
                graph.ranks[trans_name] = rank_metadata
                logger.info(f"  Extracted Rank: {trans_name}")

            elif trans_type == 'Sorter':
                sorter_metadata = self._extract_sorter(trans_elem)
                graph.sorters[trans_name] = sorter_metadata
                logger.info(f"  Extracted Sorter: {trans_name}")

            elif trans_type == 'SQL':
                sql_metadata = self._extract_sql_transformation(trans_elem)
                graph.sql_transformations[trans_name] = sql_metadata
                logger.info(f"  Extracted SQL Transformation: {trans_name}")

        # Extract target instances
        graph.target_instances = self._extract_target_instances(mapping_element)
        logger.info(f"  Extracted {len(graph.target_instances)} target instances")

        # Extract connections (data flow)
        graph.connections = self._extract_connections(mapping_element)
        logger.info(f"  Extracted {len(graph.connections)} connections")

        # Map Router groups to target instances
        self._map_router_groups_to_targets(graph)

        # Resolve Joiner master/detail sources from connector field analysis
        self._resolve_joiner_sources(graph)

        # Populate source_transformation on non-Router target instances
        self._populate_target_instance_metadata(graph)

        return graph

    def _extract_router(self, trans_elem: ET.Element) -> RouterTransformationMetadata:
        """Extract Router transformation metadata."""
        trans_name = trans_elem.get('NAME', '')
        router = RouterTransformationMetadata(transformation_name=trans_name)

        # Extract Router groups
        for group_elem in trans_elem.findall('.//GROUP'):
            group_name = group_elem.get('NAME', '')
            group_type = group_elem.get('TYPE', '')
            condition = group_elem.get('EXPRESSION', '')

            is_default = 'DEFAULT' in group_type

            group_metadata = RouterGroupMetadata(
                group_name=group_name,
                condition=condition,
                group_type=group_type,
                is_default=is_default
            )
            router.groups.append(group_metadata)

        # Build field → group map from TRANSFORMFIELD elements
        for field_elem in trans_elem.findall('.//TRANSFORMFIELD'):
            field_name = field_elem.get('NAME', '')
            group_attr = field_elem.get('GROUP', '')
            if field_name and group_attr:
                router.field_group_map[field_name] = group_attr

        return router

    def _extract_joiner(self, trans_elem: ET.Element) -> JoinerTransformationMetadata:
        """Extract Joiner transformation metadata."""
        trans_name = trans_elem.get('NAME', '')
        joiner = JoinerTransformationMetadata(transformation_name=trans_name)

        # Extract join type from TABLEATTRIBUTE
        for attr_elem in trans_elem.findall('.//TABLEATTRIBUTE'):
            attr_name = attr_elem.get('NAME', '')
            attr_value = attr_elem.get('VALUE', '')

            if attr_name == 'Join Type':
                if 'Master Outer' in attr_value:
                    joiner.join_type = JoinType.MASTER_OUTER
                elif 'Detail Outer' in attr_value:
                    joiner.join_type = JoinType.DETAIL_OUTER
                elif 'Full Outer' in attr_value:
                    joiner.join_type = JoinType.FULL_OUTER
                else:
                    joiner.join_type = JoinType.NORMAL

            elif attr_name == 'Join Condition':
                joiner.join_condition = attr_value

        # Extract master and detail ports using PORTTYPE attribute
        # In Informatica Joiners, PORTTYPE contains "MASTER" for master ports.
        # All other INPUT or INPUT/OUTPUT ports are implicitly detail ports.
        for field_elem in trans_elem.findall('.//TRANSFORMFIELD'):
            port_name = field_elem.get('NAME', '')
            port_type = field_elem.get('PORTTYPE', '')
            port_type_upper = port_type.upper() if port_type else ''

            if 'MASTER' in port_type_upper:
                joiner.master_ports.append(port_name)
            elif 'INPUT' in port_type_upper:
                # Any non-MASTER input port is a detail port
                joiner.detail_ports.append(port_name)

        return joiner

    def _extract_lookup(self, trans_elem: ET.Element) -> LookupTransformationMetadata:
        """Extract Lookup transformation metadata."""
        trans_name = trans_elem.get('NAME', '')
        lookup = LookupTransformationMetadata(transformation_name=trans_name)

        # Extract lookup attributes
        for attr_elem in trans_elem.findall('.//TABLEATTRIBUTE'):
            attr_name = attr_elem.get('NAME', '')
            attr_value = attr_elem.get('VALUE', '')

            if attr_name == 'Lookup table name':
                lookup.lookup_table = attr_value
            elif attr_name == 'Lookup condition':
                lookup.lookup_condition = attr_value
            elif attr_name == 'Lookup SQL Override':
                lookup.lookup_sql_override = attr_value
            elif attr_name == 'Lookup Policy':
                lookup.lookup_policy = attr_value

        # Extract return ports (OUTPUT ports)
        for field_elem in trans_elem.findall('.//TRANSFORMFIELD'):
            port_type = field_elem.get('PORTTYPE', '')
            port_name = field_elem.get('NAME', '')
            if port_type == 'OUTPUT':
                lookup.return_ports.append(port_name)

        return lookup

    def _extract_filter(self, trans_elem: ET.Element) -> FilterTransformationMetadata:
        """Extract Filter transformation metadata."""
        trans_name = trans_elem.get('NAME', '')
        filter_trans = FilterTransformationMetadata(transformation_name=trans_name)

        # Extract filter condition from TABLEATTRIBUTE
        for attr_elem in trans_elem.findall('.//TABLEATTRIBUTE'):
            attr_name = attr_elem.get('NAME', '')
            if attr_name == 'Filter Condition':
                filter_trans.filter_condition = attr_elem.get('VALUE', '')

        return filter_trans

    def _extract_aggregator(self, trans_elem: ET.Element) -> AggregatorTransformationMetadata:
        """Extract Aggregator transformation metadata."""
        trans_name = trans_elem.get('NAME', '')
        aggregator = AggregatorTransformationMetadata(transformation_name=trans_name)

        # Extract GROUP BY ports and aggregate expressions
        for field_elem in trans_elem.findall('.//TRANSFORMFIELD'):
            port_name = field_elem.get('NAME', '')
            port_type = field_elem.get('PORTTYPE', '')
            expression = field_elem.get('EXPRESSION', '')
            expression_type = field_elem.get('EXPRESSIONTYPE', '')

            # GROUPBY ports
            if expression_type == 'GROUPBY':
                aggregator.group_by_ports.append(port_name)
            # Aggregate expressions (SUM, AVG, etc.)
            elif expression and any(func in expression.upper() for func in ['SUM', 'AVG', 'COUNT', 'MIN', 'MAX', 'FIRST', 'LAST']):
                aggregator.aggregate_expressions[port_name] = expression

        return aggregator

    def _extract_update_strategy(self, trans_elem: ET.Element) -> UpdateStrategyTransformationMetadata:
        """Extract Update Strategy transformation metadata."""
        trans_name = trans_elem.get('NAME', '')
        update_strategy = UpdateStrategyTransformationMetadata(transformation_name=trans_name)

        # Extract update strategy expression from TABLEATTRIBUTE
        for attr_elem in trans_elem.findall('.//TABLEATTRIBUTE'):
            attr_name = attr_elem.get('NAME', '')
            if attr_name == 'Update Strategy Expression':
                update_strategy.update_strategy_expression = attr_elem.get('VALUE', '')

        return update_strategy

    def _extract_union(self, trans_elem: ET.Element) -> UnionTransformationMetadata:
        """Extract Union transformation metadata."""
        trans_name = trans_elem.get('NAME', '')
        union = UnionTransformationMetadata(transformation_name=trans_name)

        # Extract input groups
        for group_elem in trans_elem.findall('.//GROUP'):
            group_name = group_elem.get('NAME', '')
            group_type = group_elem.get('TYPE', '')
            if group_type == 'INPUT':
                union.input_groups.append(group_name)

        return union

    def _extract_rank(self, trans_elem: ET.Element) -> RankTransformationMetadata:
        """Extract Rank transformation metadata."""
        trans_name = trans_elem.get('NAME', '')
        rank = RankTransformationMetadata(transformation_name=trans_name)

        # Extract rank configuration from TABLEATTRIBUTE
        for attr_elem in trans_elem.findall('.//TABLEATTRIBUTE'):
            attr_name = attr_elem.get('NAME', '')
            attr_value = attr_elem.get('VALUE', '')

            if attr_name == 'Top N':
                try:
                    rank.top_n = int(attr_value)
                except ValueError:
                    pass
            elif attr_name == 'Rank Type':
                rank.rank_type = attr_value

        # Extract rank and group by ports
        for field_elem in trans_elem.findall('.//TRANSFORMFIELD'):
            port_name = field_elem.get('NAME', '')
            expression_type = field_elem.get('EXPRESSIONTYPE', '')

            if expression_type == 'RANK':
                rank.rank_ports.append(port_name)
            elif expression_type == 'GROUPBY':
                rank.group_by_ports.append(port_name)

        return rank

    def _extract_sorter(self, trans_elem: ET.Element) -> SorterTransformationMetadata:
        """Extract Sorter transformation metadata."""
        trans_name = trans_elem.get('NAME', '')
        sorter = SorterTransformationMetadata(transformation_name=trans_name)

        # Extract sort keys from TRANSFORMFIELD
        for field_elem in trans_elem.findall('.//TRANSFORMFIELD'):
            port_name = field_elem.get('NAME', '')
            sort_direction = field_elem.get('SORTDIRECTION', '')

            if sort_direction:
                sorter.sort_keys.append({
                    'port': port_name,
                    'direction': sort_direction
                })

        # Check for distinct option
        for attr_elem in trans_elem.findall('.//TABLEATTRIBUTE'):
            attr_name = attr_elem.get('NAME', '')
            if attr_name == 'Distinct':
                sorter.distinct = attr_elem.get('VALUE', '').upper() == 'TRUE'

        return sorter

    def _extract_sql_transformation(self, trans_elem: ET.Element) -> SQLTransformationMetadata:
        """Extract SQL Transformation metadata."""
        trans_name = trans_elem.get('NAME', '')
        sql_trans = SQLTransformationMetadata(transformation_name=trans_name)

        # Extract SQL query from TABLEATTRIBUTE
        for attr_elem in trans_elem.findall('.//TABLEATTRIBUTE'):
            attr_name = attr_elem.get('NAME', '')
            attr_value = attr_elem.get('VALUE', '')

            if attr_name == 'Sql Query':
                sql_trans.sql_query = attr_value
            elif attr_name == 'Database Type':
                sql_trans.database_type = attr_value

        # Extract input/output ports
        for field_elem in trans_elem.findall('.//TRANSFORMFIELD'):
            port_name = field_elem.get('NAME', '')
            port_type = field_elem.get('PORTTYPE', '')

            if port_type == 'INPUT':
                sql_trans.input_ports.append(port_name)
            elif port_type == 'OUTPUT':
                sql_trans.output_ports.append(port_name)

        return sql_trans

    def _extract_target_instances(self, mapping_elem: ET.Element) -> List[TargetInstanceMetadata]:
        """Extract all target instances."""
        target_instances = []

        for instance_elem in mapping_elem.findall('.//INSTANCE'):
            if instance_elem.get('TYPE') == 'TARGET':
                instance_name = instance_elem.get('NAME', '')
                physical_table = instance_elem.get('TRANSFORMATION_NAME', '')

                target_instance = TargetInstanceMetadata(
                    instance_name=instance_name,
                    physical_table_name=physical_table
                )
                target_instances.append(target_instance)

        # Extract load order
        for load_order_elem in mapping_elem.findall('.//TARGETLOADORDER'):
            instance_name = load_order_elem.get('TARGETINSTANCE', '')
            order = int(load_order_elem.get('ORDER', '1'))

            for target in target_instances:
                if target.instance_name == instance_name:
                    target.load_order = order

        return target_instances

    def _extract_connections(self, mapping_elem: ET.Element) -> List[Dict[str, str]]:
        """Extract all CONNECTOR elements showing data flow with field-level detail."""
        connections = []

        for connector_elem in mapping_elem.findall('.//CONNECTOR'):
            from_instance = connector_elem.get('FROMINSTANCE', '')
            to_instance = connector_elem.get('TOINSTANCE', '')
            from_field = connector_elem.get('FROMFIELD', '')
            to_field = connector_elem.get('TOFIELD', '')
            from_type = connector_elem.get('FROMINSTANCETYPE', '')
            to_type = connector_elem.get('TOINSTANCETYPE', '')

            if from_instance and to_instance:
                connections.append({
                    'from': from_instance,
                    'to': to_instance,
                    'from_field': from_field,
                    'to_field': to_field,
                    'from_type': from_type,
                    'to_type': to_type,
                })

        return connections

    def _map_router_groups_to_targets(self, graph: MappingTransformationGraph):
        """
        Map Router output groups to their target instances using field_group_map.

        Algorithm:
        1. For each CONNECTOR from the Router, look up FROMFIELD in field_group_map
           to determine which Router group the connection belongs to.
        2. The TOINSTANCE is the downstream expression transform →
           set group.expression_transform_name.
        3. Trace from expression transform through connections to find
           target instance → set group.target_instance_name.
        4. Set target_instance.source_transformation and .router_group.
        """
        for router_name, router_metadata in graph.routers.items():
            # Build group lookup by name
            group_by_name = {g.group_name: g for g in router_metadata.groups}

            # Track which downstream instances belong to which group
            # {downstream_instance_name: group_name}
            downstream_to_group = {}

            # Step 1-2: Use field_group_map to link Router → downstream expression transforms
            for conn in graph.connections:
                if conn['from'] != router_name:
                    continue
                from_field = conn.get('from_field', '')
                to_instance = conn['to']

                # Look up which group this field belongs to
                group_name = router_metadata.field_group_map.get(from_field, '')
                if group_name and group_name in group_by_name:
                    group = group_by_name[group_name]
                    # The first downstream instance is the expression transform
                    if not group.expression_transform_name:
                        group.expression_transform_name = to_instance
                    downstream_to_group[to_instance] = group_name

            # Step 3: Trace from expression transforms to target instances
            for group in router_metadata.output_groups:
                if group.expression_transform_name:
                    target = self._trace_to_target(group.expression_transform_name, graph)
                    if target:
                        group.target_instance_name = target.instance_name
                        # Step 4: Set reverse links on target instance
                        target.source_transformation = group.expression_transform_name
                        target.router_group = group.group_name
                        logger.info(
                            f"    Mapped Router group '{group.group_name}' "
                            f"-> Expression '{group.expression_transform_name}' "
                            f"-> Target '{target.instance_name}'"
                        )

            # Fallback: if field_group_map was empty, use old approach
            # (trace all connections from router and assign by position)
            unmapped_groups = [g for g in router_metadata.output_groups
                               if not g.target_instance_name]
            if unmapped_groups:
                seen_targets = set()
                for conn in graph.connections:
                    if conn['from'] == router_name:
                        target = self._trace_to_target(conn['to'], graph)
                        if target and target.instance_name not in seen_targets:
                            seen_targets.add(target.instance_name)
                            if unmapped_groups:
                                group = unmapped_groups.pop(0)
                                group.target_instance_name = target.instance_name
                                if not group.expression_transform_name:
                                    group.expression_transform_name = conn['to']
                                logger.info(
                                    f"    Fallback-mapped Router group '{group.group_name}' "
                                    f"-> Target '{target.instance_name}'"
                                )

    def _resolve_joiner_sources(self, graph: MappingTransformationGraph):
        """
        For each Joiner, find upstream source instances by matching connector fields
        against master/detail port names.
        """
        for joiner_name, joiner in graph.joiners.items():
            master_port_set = set(p.upper() for p in joiner.master_ports)
            detail_port_set = set(p.upper() for p in joiner.detail_ports)

            master_candidates = {}
            detail_candidates = {}

            for conn in graph.connections:
                if conn['to'] != joiner_name:
                    continue
                to_field = conn.get('to_field', '').upper()
                from_instance = conn['from']

                if to_field in master_port_set:
                    master_candidates[from_instance] = master_candidates.get(from_instance, 0) + 1
                elif to_field in detail_port_set:
                    detail_candidates[from_instance] = detail_candidates.get(from_instance, 0) + 1

            # Pick the instance that matched the most ports
            if master_candidates:
                joiner.master_source = max(master_candidates, key=master_candidates.get)
                logger.info(f"    Joiner '{joiner_name}' master_source = '{joiner.master_source}'")
            if detail_candidates:
                joiner.detail_source = max(detail_candidates, key=detail_candidates.get)
                logger.info(f"    Joiner '{joiner_name}' detail_source = '{joiner.detail_source}'")

    def _populate_target_instance_metadata(self, graph: MappingTransformationGraph):
        """
        For non-Router targets (those without source_transformation already set),
        trace connectors backward to find the feeding transformation.
        """
        for target in graph.target_instances:
            if target.source_transformation:
                continue  # Already set by Router mapping

            # Find connectors pointing to this target instance
            for conn in graph.connections:
                if conn['to'] == target.instance_name:
                    target.source_transformation = conn['from']
                    logger.info(
                        f"    Target '{target.instance_name}' "
                        f"source_transformation = '{conn['from']}'"
                    )
                    break  # Take the first match

    def _trace_to_target(self, transformation_name: str, graph: MappingTransformationGraph, visited: set = None) -> Optional[TargetInstanceMetadata]:
        """
        Trace connections from a transformation to find the target instance it feeds.

        Args:
            transformation_name: Current transformation name
            graph: Mapping transformation graph
            visited: Set of visited transformations (to avoid cycles)

        Returns:
            TargetInstanceMetadata if found, None otherwise
        """
        if visited is None:
            visited = set()

        if transformation_name in visited:
            return None

        visited.add(transformation_name)

        # Check if this is a target instance
        for target in graph.target_instances:
            if target.instance_name == transformation_name:
                return target

        # Find next transformation in the flow
        for conn in graph.connections:
            if conn['from'] == transformation_name:
                result = self._trace_to_target(conn['to'], graph, visited)
                if result:
                    return result

        return None
