"""
Cross-reference resolver for multi-XML lineage analysis.

This module identifies connections between tables across different
Informatica PowerCenter XML files.
"""

from typing import Dict, List, Set, Tuple

from ..parsers.powermart_parser import PowermartDocument
from ..utils.logging_config import get_logger

from .aggregation_models import (
    CrossMappingLink,
    UnifiedLineageGraph,
)


logger = get_logger("cross_reference_resolver")


class CrossReferenceResolver:
    """
    Resolves cross-mapping references between Informatica XMLs.

    Identifies where a target table in one mapping becomes a source
    table in another mapping, creating the multi-hop data flow.
    """

    def __init__(self, fuzzy_match: bool = False, match_threshold: float = 0.9):
        """
        Initialize the cross-reference resolver.

        Args:
            fuzzy_match: Enable fuzzy matching for table names
            match_threshold: Threshold for fuzzy matching (0.0-1.0)
        """
        self.fuzzy_match = fuzzy_match
        self.match_threshold = match_threshold

    def resolve(
        self,
        documents: Dict[str, PowermartDocument],
        graph: UnifiedLineageGraph
    ) -> List[CrossMappingLink]:
        """
        Resolve cross-mapping references across all documents.

        Args:
            documents: Dictionary of xml_path -> PowermartDocument
            graph: The unified lineage graph being built

        Returns:
            List of CrossMappingLink objects
        """
        logger.info(f"Resolving cross-references across {len(documents)} documents")

        links = []

        # Collect all sources and targets across documents
        all_sources = self._collect_sources(documents)
        all_targets = self._collect_targets(documents)

        logger.debug(f"Found {len(all_sources)} source entries, {len(all_targets)} target entries")

        # Find matches: target in one doc that's a source in another doc
        for target_name, target_info_list in all_targets.items():
            # Check if this target is used as a source anywhere
            source_matches = self._find_source_matches(target_name, all_sources)

            for target_info in target_info_list:
                for source_info in source_matches:
                    # Skip if same XML (not a cross-reference)
                    if target_info["xml_path"] == source_info["xml_path"]:
                        continue

                    # Create cross-mapping link
                    link = CrossMappingLink(
                        source_xml=target_info["xml_path"],
                        source_table=target_name,
                        source_mapping=target_info["mapping_name"],
                        target_xml=source_info["xml_path"],
                        target_table=source_info["table_name"],
                        target_mapping=source_info["mapping_name"],
                        link_type=self._determine_link_type(target_name, source_info["table_name"]),
                        confidence=self._calculate_confidence(target_name, source_info["table_name"]),
                    )
                    links.append(link)

        # Also check for staging table patterns
        staging_links = self._find_staging_patterns(documents, all_sources, all_targets)
        links.extend(staging_links)

        logger.info(f"Resolved {len(links)} cross-mapping links")
        return links

    def _collect_sources(
        self,
        documents: Dict[str, PowermartDocument]
    ) -> Dict[str, List[Dict]]:
        """
        Collect all source tables across documents.

        Returns dict mapping table_name to list of {xml_path, mapping_name, table_name}
        """
        sources: Dict[str, List[Dict]] = {}

        for xml_path, doc in documents.items():
            # Collect from source definitions
            for source in doc.sources:
                name = source.name.upper()
                if name not in sources:
                    sources[name] = []
                sources[name].append({
                    "xml_path": xml_path,
                    "table_name": source.name,
                    "mapping_name": "",  # Source is at folder level
                    "owner": source.owner_name,
                })

            # Collect from mapping instances
            for mapping in doc.mappings:
                for instance in mapping.instances:
                    if instance.is_source:
                        name = instance.transformation_name.upper()
                        # Handle shortcut naming
                        if name.startswith("SHORTCUT_TO_"):
                            name = name[12:]

                        if name not in sources:
                            sources[name] = []
                        sources[name].append({
                            "xml_path": xml_path,
                            "table_name": instance.transformation_name,
                            "mapping_name": mapping.name,
                            "owner": "",
                        })

        return sources

    def _collect_targets(
        self,
        documents: Dict[str, PowermartDocument]
    ) -> Dict[str, List[Dict]]:
        """
        Collect all target tables across documents.

        Returns dict mapping table_name to list of {xml_path, mapping_name, table_name}
        """
        targets: Dict[str, List[Dict]] = {}

        for xml_path, doc in documents.items():
            # Collect from target definitions
            for target in doc.targets:
                name = target.name.upper()
                if name not in targets:
                    targets[name] = []
                targets[name].append({
                    "xml_path": xml_path,
                    "table_name": target.name,
                    "mapping_name": "",  # Target is at folder level
                    "owner": getattr(target, "owner_name", ""),
                })

            # Collect from mapping instances
            for mapping in doc.mappings:
                for instance in mapping.instances:
                    if instance.is_target:
                        name = instance.transformation_name.upper()
                        if name.startswith("SHORTCUT_TO_"):
                            name = name[12:]

                        if name not in targets:
                            targets[name] = []
                        targets[name].append({
                            "xml_path": xml_path,
                            "table_name": instance.transformation_name,
                            "mapping_name": mapping.name,
                            "owner": "",
                        })

        return targets

    def _find_source_matches(
        self,
        target_name: str,
        all_sources: Dict[str, List[Dict]]
    ) -> List[Dict]:
        """
        Find sources that match a target name.

        Uses exact matching by default, with optional fuzzy matching.
        """
        target_upper = target_name.upper()

        # Exact match
        if target_upper in all_sources:
            return all_sources[target_upper]

        # Try fuzzy matching if enabled
        if self.fuzzy_match:
            matches = []
            for source_name, source_info_list in all_sources.items():
                similarity = self._calculate_similarity(target_upper, source_name)
                if similarity >= self.match_threshold:
                    for info in source_info_list:
                        info["match_confidence"] = similarity
                        matches.append(info)
            return matches

        return []

    def _find_staging_patterns(
        self,
        documents: Dict[str, PowermartDocument],
        all_sources: Dict[str, List[Dict]],
        all_targets: Dict[str, List[Dict]]
    ) -> List[CrossMappingLink]:
        """
        Find staging table patterns across mappings.

        Looks for common patterns like:
        - LND_TABLE -> CDC_TABLE -> ECH_TABLE
        - *_STG -> *_WRK -> *_TGT
        """
        links = []

        # Define common staging patterns
        patterns = [
            ("LND_", "CDC_"),    # Landing to CDC
            ("CDC_", "ECH_"),    # CDC to ECH
            ("_STG", "_WRK"),    # Staging to Work
            ("_WRK", "_TGT"),    # Work to Target
            ("_RAW", "_STG"),    # Raw to Staging
            ("_STG", "_CUR"),    # Staging to Current
        ]

        for target_name, target_info_list in all_targets.items():
            target_upper = target_name.upper()

            for from_pattern, to_pattern in patterns:
                # Check if target matches the "from" pattern
                if from_pattern in target_upper:
                    # Look for corresponding "to" pattern source
                    expected_source = target_upper.replace(from_pattern, to_pattern)

                    for source_name, source_info_list in all_sources.items():
                        if source_name.upper() == expected_source:
                            for target_info in target_info_list:
                                for source_info in source_info_list:
                                    if target_info["xml_path"] != source_info["xml_path"]:
                                        link = CrossMappingLink(
                                            source_xml=target_info["xml_path"],
                                            source_table=target_name,
                                            source_mapping=target_info["mapping_name"],
                                            target_xml=source_info["xml_path"],
                                            target_table=source_info["table_name"],
                                            target_mapping=source_info["mapping_name"],
                                            link_type="staging",
                                            confidence=0.9,  # Pattern-based match
                                        )
                                        links.append(link)

        return links

    def _determine_link_type(self, source_name: str, target_name: str) -> str:
        """
        Determine the type of cross-mapping link.

        Returns:
            "direct" - exact name match
            "staging" - staging pattern match
            "lookup" - appears to be a lookup relationship
        """
        source_upper = source_name.upper()
        target_upper = target_name.upper()

        # Check for exact match
        if source_upper == target_upper:
            return "direct"

        # Check for lookup patterns
        if "LKP_" in source_upper or "LOOKUP" in source_upper:
            return "lookup"

        # Check for staging patterns
        staging_indicators = ["_STG", "_WRK", "_TMP", "_TEMP", "LND_", "CDC_"]
        if any(ind in source_upper or ind in target_upper for ind in staging_indicators):
            return "staging"

        return "direct"

    def _calculate_confidence(self, source_name: str, target_name: str) -> float:
        """
        Calculate confidence score for a cross-mapping link.

        Returns:
            1.0 for exact match
            0.9 for case-insensitive match
            Lower values for pattern-based or fuzzy matches
        """
        if source_name == target_name:
            return 1.0

        if source_name.upper() == target_name.upper():
            return 0.95

        # Calculate similarity for non-exact matches
        return self._calculate_similarity(source_name.upper(), target_name.upper())

    def _calculate_similarity(self, str1: str, str2: str) -> float:
        """
        Calculate similarity between two strings.

        Uses Levenshtein ratio for fuzzy matching.
        """
        if str1 == str2:
            return 1.0

        # Simple ratio based on common prefix/suffix
        max_len = max(len(str1), len(str2))
        if max_len == 0:
            return 1.0

        # Count common characters
        common = sum(1 for a, b in zip(str1, str2) if a == b)

        return common / max_len

    def get_mapping_sequence(
        self,
        links: List[CrossMappingLink]
    ) -> List[List[str]]:
        """
        Build ordered sequences of mappings from cross-mapping links.

        Returns list of sequences, where each sequence is an ordered
        list of mapping names showing the data flow.
        """
        # Build adjacency list from links
        adjacency: Dict[str, List[str]] = {}
        for link in links:
            if link.source_mapping not in adjacency:
                adjacency[link.source_mapping] = []
            adjacency[link.source_mapping].append(link.target_mapping)

        # Find starting points (mappings with no incoming links)
        all_targets = {link.target_mapping for link in links}
        all_sources = {link.source_mapping for link in links}
        start_mappings = all_sources - all_targets

        # Build sequences using DFS
        sequences = []
        visited: Set[str] = set()

        def dfs(mapping: str, path: List[str]):
            if mapping in visited:
                return
            visited.add(mapping)
            path.append(mapping)

            next_mappings = adjacency.get(mapping, [])
            if not next_mappings:
                # End of sequence
                sequences.append(path.copy())
            else:
                for next_mapping in next_mappings:
                    dfs(next_mapping, path)

            path.pop()
            visited.remove(mapping)

        for start in start_mappings:
            dfs(start, [])

        return sequences
