"""
Transformation Metadata Models - Comprehensive extraction of Informatica transformation logic.

This module defines data structures to capture ALL business logic from Informatica
transformations, ensuring zero loss of transformation rules, conditions, and logic.
"""

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Set
from enum import Enum


class JoinType(Enum):
    """Joiner transformation join types."""
    NORMAL = "Normal Join"  # Inner join
    MASTER_OUTER = "Master Outer Join"  # Left outer join
    DETAIL_OUTER = "Detail Outer Join"  # Right outer join
    FULL_OUTER = "Full Outer Join"  # Full outer join


class UpdateStrategyFlag(Enum):
    """Update strategy transformation flags."""
    DD_INSERT = 0
    DD_UPDATE = 1
    DD_DELETE = 2
    DD_REJECT = 3


@dataclass
class RouterGroupMetadata:
    """
    Metadata for a single Router group.

    Represents one output path from a Router transformation with its condition.
    """
    group_name: str
    condition: str  # Informatica expression for routing condition
    group_type: str  # INPUT, OUTPUT, OUTPUT/DEFAULT
    is_default: bool = False
    target_instance_name: Optional[str] = None  # Which target instance this feeds
    expression_transform_name: Optional[str] = None  # Downstream expression transformation

    def to_dict(self) -> Dict[str, Any]:
        return {
            "group_name": self.group_name,
            "condition": self.condition,
            "group_type": self.group_type,
            "is_default": self.is_default,
            "target_instance_name": self.target_instance_name,
            "expression_transform_name": self.expression_transform_name,
        }


@dataclass
class RouterTransformationMetadata:
    """
    Complete metadata for a Router transformation.

    Routers conditionally route records to different output groups based on conditions.
    Each output group may feed different target instances, requiring separate INSERT statements.
    """
    transformation_name: str
    groups: List[RouterGroupMetadata] = field(default_factory=list)
    input_transformation: Optional[str] = None  # Upstream transformation feeding router
    field_group_map: Dict[str, str] = field(default_factory=dict)  # TRANSFORMFIELD NAME -> GROUP name

    @property
    def output_groups(self) -> List[RouterGroupMetadata]:
        """Get non-default output groups."""
        return [g for g in self.groups if not g.is_default and g.group_type != "INPUT"]

    @property
    def has_multiple_paths(self) -> bool:
        """Check if router creates multiple data paths."""
        return len(self.output_groups) > 1

    def to_dict(self) -> Dict[str, Any]:
        return {
            "transformation_name": self.transformation_name,
            "groups": [g.to_dict() for g in self.groups],
            "input_transformation": self.input_transformation,
            "output_group_count": len(self.output_groups),
            "has_multiple_paths": self.has_multiple_paths,
            "field_group_map": self.field_group_map,
        }


@dataclass
class JoinerTransformationMetadata:
    """
    Complete metadata for a Joiner transformation.

    Joiners combine records from two sources based on join conditions.
    """
    transformation_name: str
    join_type: JoinType = JoinType.NORMAL
    join_condition: str = ""  # Complete join condition expression
    master_source: Optional[str] = None  # Master (left) source transformation
    detail_source: Optional[str] = None  # Detail (right) source transformation
    master_ports: List[str] = field(default_factory=list)  # Ports from master
    detail_ports: List[str] = field(default_factory=list)  # Ports from detail

    def get_sql_join_type(self) -> str:
        """Get SQL equivalent join type."""
        mapping = {
            JoinType.NORMAL: "INNER JOIN",
            JoinType.MASTER_OUTER: "LEFT OUTER JOIN",
            JoinType.DETAIL_OUTER: "RIGHT OUTER JOIN",
            JoinType.FULL_OUTER: "FULL OUTER JOIN",
        }
        return mapping.get(self.join_type, "INNER JOIN")

    def to_dict(self) -> Dict[str, Any]:
        return {
            "transformation_name": self.transformation_name,
            "join_type": self.join_type.value,
            "sql_join_type": self.get_sql_join_type(),
            "join_condition": self.join_condition,
            "master_source": self.master_source,
            "detail_source": self.detail_source,
            "master_port_count": len(self.master_ports),
            "detail_port_count": len(self.detail_ports),
        }


@dataclass
class LookupTransformationMetadata:
    """
    Complete metadata for a Lookup transformation.

    Lookups retrieve values from a lookup table based on lookup conditions.
    """
    transformation_name: str
    lookup_table: Optional[str] = None  # Lookup table name
    lookup_condition: str = ""  # Lookup condition expression
    lookup_sql_override: Optional[str] = None  # Custom SQL for lookup
    return_ports: List[str] = field(default_factory=list)  # Ports returned from lookup
    lookup_policy: str = "Use Cache"  # Use Cache, Use Uncached, Use Dynamic Cache

    def to_dict(self) -> Dict[str, Any]:
        return {
            "transformation_name": self.transformation_name,
            "lookup_table": self.lookup_table,
            "lookup_condition": self.lookup_condition,
            "has_sql_override": bool(self.lookup_sql_override),
            "return_port_count": len(self.return_ports),
            "lookup_policy": self.lookup_policy,
        }


@dataclass
class FilterTransformationMetadata:
    """
    Complete metadata for a Filter transformation.

    Filters pass only records that satisfy the filter condition.
    """
    transformation_name: str
    filter_condition: str = ""  # Filter condition expression

    def to_dict(self) -> Dict[str, Any]:
        return {
            "transformation_name": self.transformation_name,
            "filter_condition": self.filter_condition,
        }


@dataclass
class AggregatorTransformationMetadata:
    """
    Complete metadata for an Aggregator transformation.

    Aggregators perform aggregate calculations (SUM, AVG, COUNT, etc.) with optional grouping.
    """
    transformation_name: str
    group_by_ports: List[str] = field(default_factory=list)  # Ports used for GROUP BY
    aggregate_expressions: Dict[str, str] = field(default_factory=dict)  # {port: agg_expression}

    def to_dict(self) -> Dict[str, Any]:
        return {
            "transformation_name": self.transformation_name,
            "group_by_ports": self.group_by_ports,
            "aggregate_expressions": self.aggregate_expressions,
            "has_grouping": len(self.group_by_ports) > 0,
        }


@dataclass
class UpdateStrategyTransformationMetadata:
    """
    Complete metadata for an Update Strategy transformation.

    Update Strategy determines whether records should be inserted, updated, deleted, or rejected.
    """
    transformation_name: str
    update_strategy_expression: str = ""  # Expression determining update strategy
    # Expressions typically use DD_INSERT (0), DD_UPDATE (1), DD_DELETE (2), DD_REJECT (3)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "transformation_name": self.transformation_name,
            "update_strategy_expression": self.update_strategy_expression,
        }


@dataclass
class UnionTransformationMetadata:
    """
    Complete metadata for a Union transformation.

    Unions combine multiple input pipelines into a single output stream.
    """
    transformation_name: str
    input_groups: List[str] = field(default_factory=list)  # List of input group names
    union_all: bool = True  # UNION ALL (True) vs UNION (False)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "transformation_name": self.transformation_name,
            "input_group_count": len(self.input_groups),
            "union_all": self.union_all,
        }


@dataclass
class RankTransformationMetadata:
    """
    Complete metadata for a Rank transformation.

    Ranks records based on specified ports, optionally partitioning by group ports.
    """
    transformation_name: str
    rank_ports: List[str] = field(default_factory=list)  # Ports to rank on
    group_by_ports: List[str] = field(default_factory=list)  # Partition by ports
    top_n: Optional[int] = None  # Top N records to select
    rank_type: str = "Dense"  # Dense, Standard

    def to_dict(self) -> Dict[str, Any]:
        return {
            "transformation_name": self.transformation_name,
            "rank_ports": self.rank_ports,
            "group_by_ports": self.group_by_ports,
            "top_n": self.top_n,
            "rank_type": self.rank_type,
        }


@dataclass
class SorterTransformationMetadata:
    """
    Complete metadata for a Sorter transformation.

    Sorters sort records based on specified sort keys.
    """
    transformation_name: str
    sort_keys: List[Dict[str, str]] = field(default_factory=list)  # [{port, direction}]
    distinct: bool = False  # Remove duplicates

    def to_dict(self) -> Dict[str, Any]:
        return {
            "transformation_name": self.transformation_name,
            "sort_keys": self.sort_keys,
            "distinct": self.distinct,
        }


@dataclass
class SQLTransformationMetadata:
    """
    Complete metadata for a SQL Transformation.

    SQL transformations execute custom SQL queries.
    """
    transformation_name: str
    sql_query: str = ""  # Complete SQL query
    database_type: str = ""  # Oracle, SQL Server, etc.
    input_ports: List[str] = field(default_factory=list)
    output_ports: List[str] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "transformation_name": self.transformation_name,
            "has_sql_query": bool(self.sql_query),
            "database_type": self.database_type,
            "input_port_count": len(self.input_ports),
            "output_port_count": len(self.output_ports),
        }


@dataclass
class TargetInstanceMetadata:
    """
    Metadata for a target instance.

    Multiple target instances can point to the same physical table,
    representing different data paths (e.g., from different Router groups).
    """
    instance_name: str  # Unique instance name (e.g., sc_LND_PARTY_ACCOUNT1)
    physical_table_name: str  # Physical table name (e.g., LND_PARTY_ACCOUNT)
    source_transformation: Optional[str] = None  # Transformation feeding this instance
    router_group: Optional[str] = None  # Router group name if from router
    load_order: int = 1  # Load order number

    def to_dict(self) -> Dict[str, Any]:
        return {
            "instance_name": self.instance_name,
            "physical_table_name": self.physical_table_name,
            "source_transformation": self.source_transformation,
            "router_group": self.router_group,
            "load_order": self.load_order,
        }


@dataclass
class MappingTransformationGraph:
    """
    Complete transformation graph for a single mapping.

    This captures the ENTIRE data flow including all transformation logic,
    ensuring zero business logic loss.
    """
    mapping_name: str
    source_file: str

    # All transformations by type
    routers: Dict[str, RouterTransformationMetadata] = field(default_factory=dict)
    joiners: Dict[str, JoinerTransformationMetadata] = field(default_factory=dict)
    lookups: Dict[str, LookupTransformationMetadata] = field(default_factory=dict)
    filters: Dict[str, FilterTransformationMetadata] = field(default_factory=dict)
    aggregators: Dict[str, AggregatorTransformationMetadata] = field(default_factory=dict)
    update_strategies: Dict[str, UpdateStrategyTransformationMetadata] = field(default_factory=dict)
    unions: Dict[str, UnionTransformationMetadata] = field(default_factory=dict)
    ranks: Dict[str, RankTransformationMetadata] = field(default_factory=dict)
    sorters: Dict[str, SorterTransformationMetadata] = field(default_factory=dict)
    sql_transformations: Dict[str, SQLTransformationMetadata] = field(default_factory=dict)

    # Target instances (may be multiple per physical table)
    target_instances: List[TargetInstanceMetadata] = field(default_factory=list)

    # Connection graph showing data flow
    connections: List[Dict[str, str]] = field(default_factory=list)  # [{from, to, from_group}]

    def get_target_instances_for_table(self, table_name: str) -> List[TargetInstanceMetadata]:
        """Get all target instances for a physical table."""
        return [t for t in self.target_instances if t.physical_table_name == table_name]

    def has_router(self) -> bool:
        """Check if mapping has any router transformations."""
        return len(self.routers) > 0

    def has_multiple_target_instances(self) -> bool:
        """Check if any physical table has multiple target instances."""
        table_counts = {}
        for instance in self.target_instances:
            table_counts[instance.physical_table_name] = table_counts.get(instance.physical_table_name, 0) + 1
        return any(count > 1 for count in table_counts.values())

    def get_complexity_score(self) -> float:
        """Calculate transformation complexity score."""
        score = 0.0
        score += len(self.routers) * 0.15
        score += len(self.joiners) * 0.15
        score += len(self.lookups) * 0.10
        score += len(self.filters) * 0.05
        score += len(self.aggregators) * 0.20
        score += len(self.update_strategies) * 0.10
        score += len(self.unions) * 0.10
        score += len(self.ranks) * 0.10
        return min(1.0, score)

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary representation."""
        return {
            "mapping_name": self.mapping_name,
            "source_file": self.source_file,
            "transformation_counts": {
                "routers": len(self.routers),
                "joiners": len(self.joiners),
                "lookups": len(self.lookups),
                "filters": len(self.filters),
                "aggregators": len(self.aggregators),
                "update_strategies": len(self.update_strategies),
                "unions": len(self.unions),
                "ranks": len(self.ranks),
                "sorters": len(self.sorters),
                "sql_transformations": len(self.sql_transformations),
            },
            "target_instance_count": len(self.target_instances),
            "has_router": self.has_router(),
            "has_multiple_target_instances": self.has_multiple_target_instances(),
            "complexity_score": self.get_complexity_score(),
            "routers": {k: v.to_dict() for k, v in self.routers.items()},
            "joiners": {k: v.to_dict() for k, v in self.joiners.items()},
            "lookups": {k: v.to_dict() for k, v in self.lookups.items()},
            "filters": {k: v.to_dict() for k, v in self.filters.items()},
            "aggregators": {k: v.to_dict() for k, v in self.aggregators.items()},
            "update_strategies": {k: v.to_dict() for k, v in self.update_strategies.items()},
            "target_instances": [t.to_dict() for t in self.target_instances],
        }
