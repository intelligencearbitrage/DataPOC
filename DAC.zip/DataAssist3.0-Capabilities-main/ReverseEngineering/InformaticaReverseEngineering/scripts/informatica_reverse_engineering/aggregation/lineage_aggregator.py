"""
Informatica Lineage Aggregator for multi-XML analysis.

This module combines lineage from multiple Informatica PowerCenter XML files
into a unified dependency graph for end-to-end analysis.
"""

import os
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional, Set, Tuple

from ..parsers.powermart_parser import PowermartParser, PowermartDocument
from ..lineage.lineage_extractor import LineageExtractor
from ..models.lineage_models import LineageResult, EndToEndFieldLineage
from ..utils.logging_config import get_logger

from .aggregation_models import (
    TableNode,
    TableEdge,
    CrossMappingLink,
    TableConflict,
    UnifiedLineageGraph,
    TransformationType,
    NodeType,
)
from .cross_reference_resolver import CrossReferenceResolver


logger = get_logger("lineage_aggregator")


class InformaticaLineageAggregator:
    """
    Aggregates lineage from multiple Informatica XML files into a unified graph.

    This class orchestrates the parsing, extraction, and aggregation of lineage
    information from multiple PowerCenter XML exports.
    """

    def __init__(self, detect_conflicts: bool = True, parameter_loader=None):
        """
        Initialize the lineage aggregator.

        Args:
            detect_conflicts: Whether to detect and flag table conflicts
            parameter_loader: ParameterFileLoader for resolving session-level params
        """
        self.parser = PowermartParser()
        self.lineage_extractor = LineageExtractor(parallel=True, parameter_loader=parameter_loader)
        self.cross_ref_resolver = CrossReferenceResolver()
        self.detect_conflicts = detect_conflicts

        # Storage for parsed documents
        self.documents: Dict[str, PowermartDocument] = {}
        self.lineage_results: Dict[str, LineageResult] = {}

    def aggregate_from_directory(
        self,
        directory: str,
        pattern: str = "*.xml"
    ) -> UnifiedLineageGraph:
        """
        Aggregate lineage from all XML files in a directory.

        Args:
            directory: Path to directory containing XML files
            pattern: Glob pattern for XML files (default: *.xml)

        Returns:
            UnifiedLineageGraph with combined lineage
        """
        path = Path(directory)
        xml_files = list(path.glob(pattern))

        if not xml_files:
            logger.warning(f"No XML files found in {directory} matching {pattern}")
            return UnifiedLineageGraph()

        logger.info(f"Found {len(xml_files)} XML files in {directory}")
        return self.aggregate_xmls([str(f) for f in xml_files])

    def aggregate_xmls(self, xml_paths: List[str]) -> UnifiedLineageGraph:
        """
        Aggregate lineage from multiple XML files.

        Args:
            xml_paths: List of paths to Informatica XML files

        Returns:
            UnifiedLineageGraph with combined lineage
        """
        logger.info(f"Starting aggregation of {len(xml_paths)} XML files")

        # Initialize unified graph
        unified_graph = UnifiedLineageGraph()
        unified_graph.source_xmls = xml_paths
        unified_graph.creation_timestamp = datetime.now().isoformat()

        # Phase 1: Parse all XMLs
        logger.info("Phase 1: Parsing XML files...")
        for xml_path in xml_paths:
            try:
                doc = self._parse_xml(xml_path)
                if doc:
                    self.documents[xml_path] = doc
            except Exception as e:
                logger.error(f"Error parsing {xml_path}: {e}")

        # Phase 2: Extract lineage from each document
        logger.info("Phase 2: Extracting lineage from each document...")
        for xml_path, doc in self.documents.items():
            try:
                result = self.lineage_extractor.extract(doc)
                self.lineage_results[xml_path] = result
            except Exception as e:
                logger.error(f"Error extracting lineage from {xml_path}: {e}")

        # Phase 3: Build unified graph from documents
        logger.info("Phase 3: Building unified graph...")
        self._build_unified_graph(unified_graph)

        # Phase 4: Resolve cross-mapping references
        logger.info("Phase 4: Resolving cross-mapping references...")
        self._resolve_cross_references(unified_graph)

        # Phase 5: Detect conflicts if enabled
        if self.detect_conflicts:
            logger.info("Phase 5: Detecting conflicts...")
            self._detect_conflicts(unified_graph)

        # Phase 6: Compute hop counts
        logger.info("Phase 6: Computing hop counts...")
        unified_graph.compute_hop_counts()

        logger.info(
            f"Aggregation complete: {unified_graph.table_count} tables, "
            f"{unified_graph.edge_count} edges, "
            f"{len(unified_graph.cross_mapping_links)} cross-mapping links, "
            f"{len(unified_graph.conflicts)} conflicts"
        )

        return unified_graph

    def _parse_xml(self, xml_path: str) -> Optional[PowermartDocument]:
        """Parse a single XML file."""
        try:
            logger.debug(f"Parsing: {xml_path}")
            return self.parser.parse_file(xml_path)
        except Exception as e:
            logger.error(f"Failed to parse {xml_path}: {e}")
            return None

    def _build_unified_graph(self, graph: UnifiedLineageGraph) -> None:
        """
        Build the unified graph from parsed documents.

        Extracts tables and edges from all documents and adds them to the graph.
        """
        for xml_path, doc in self.documents.items():
            xml_name = os.path.basename(xml_path)

            # Add source tables
            for source in doc.sources:
                table_node = self._create_table_node_from_source(source, xml_name)
                graph.add_table(table_node)

            # Add target tables
            for target in doc.targets:
                table_node = self._create_table_node_from_target(target, xml_name)
                graph.add_table(table_node)

            # Add edges from mappings
            for mapping in doc.mappings:
                self._add_edges_from_mapping(graph, mapping, doc, xml_name)

    def _create_table_node_from_source(self, source, xml_name: str) -> TableNode:
        """Create a TableNode from a Source object."""
        columns = {}
        for field in source.fields:
            columns[field.name] = {
                "datatype": field.datatype,
                "precision": field.precision,
                "scale": field.scale,
                "nullable": field.nullable,
            }

        return TableNode(
            table_name=source.name,
            source_xml=xml_name,
            node_type=NodeType.SOURCE,
            columns=columns,
            database_type=source.database_type,
            owner=source.owner_name,
        )

    def _create_table_node_from_target(self, target, xml_name: str) -> TableNode:
        """Create a TableNode from a Target object."""
        columns = {}
        for field in target.fields:
            columns[field.name] = {
                "datatype": field.datatype,
                "precision": field.precision,
                "scale": field.scale,
                "nullable": getattr(field, "nullable", True),
            }

        return TableNode(
            table_name=target.name,
            source_xml=xml_name,
            node_type=NodeType.TARGET,
            columns=columns,
            database_type=target.database_type,
            owner=getattr(target, "owner_name", ""),
        )

    def _add_edges_from_mapping(
        self,
        graph: UnifiedLineageGraph,
        mapping,
        doc: PowermartDocument,
        xml_name: str
    ) -> None:
        """
        Add edges to the graph from a mapping's lineage.

        Analyzes the mapping's transformations to determine:
        - Source to target relationships
        - Transformation types applied
        - Field-level mappings
        """
        # Get lineage result for this document
        lineage_result = self.lineage_results.get(doc.file_path)
        if not lineage_result:
            return

        # Build transformation type lookup from mapping
        trans_types = self._analyze_transformation_types(mapping)

        # Process field lineages to extract table-level edges
        source_tables: Set[str] = set()
        target_tables: Set[str] = set()
        field_mappings: Dict[Tuple[str, str], Dict[str, str]] = {}  # (src, tgt) -> {tgt_field: src_field}
        expressions: Dict[Tuple[str, str], Dict[str, str]] = {}  # (src, tgt) -> {tgt_field: expr}

        for field_lineage in lineage_result.field_lineages:
            target_table = field_lineage.target_table
            target_field = field_lineage.target_field
            target_tables.add(target_table)

            for source_info in field_lineage.ultimate_sources:
                source_table = source_info.get("table", "")
                source_field = source_info.get("field", "")

                # If the source is an intermediate transformation (not a known
                # table), resolve it back to the actual source table so that
                # end_to_end_lineage paths can be computed correctly.
                if source_table and source_table not in graph.tables:
                    resolved = self._resolve_to_source_table(source_table, mapping, doc)
                    if resolved:
                        source_table = resolved

                if source_table:
                    source_tables.add(source_table)

                    # Record field mapping
                    key = (source_table, target_table)
                    if key not in field_mappings:
                        field_mappings[key] = {}
                        expressions[key] = {}

                    field_mappings[key][target_field] = source_field

                    # Record expression if any
                    if field_lineage.transformation_chain:
                        expressions[key][target_field] = field_lineage.transformation_chain

        # Create edges for each source-target pair
        for source_table, target_table in field_mappings.keys():
            # Determine transformation type based on transformations used
            transformation_type = self._determine_edge_transformation_type(
                trans_types, lineage_result
            )

            edge = TableEdge(
                source_table=source_table,
                target_table=target_table,
                source_xml=xml_name,
                transformation_type=transformation_type,
                field_mappings=field_mappings.get((source_table, target_table), {}),
                expressions=expressions.get((source_table, target_table), {}),
            )
            graph.add_edge(edge)

            # Update target table's transformation types
            if target_table in graph.tables:
                graph.tables[target_table].transformation_types.add(transformation_type)
                graph.tables[target_table].mapping_name = mapping.name

    def _resolve_to_source_table(
        self, transformation_name: str, mapping, doc
    ) -> Optional[str]:
        """Resolve an intermediate transformation name to its actual source table.

        When trace_back() terminates at an Expression or Custom transformation
        that has no incoming connector edges, the transformation's instance name
        is recorded as the "ultimate source".  This method traces backward
        through the mapping's connectors to find the Source Definition that
        feeds the transformation, returning the actual table name.
        """
        # Build a set of known source table names for quick lookup
        source_def_names = set()
        for src in doc.sources:
            source_def_names.add(src.name.lower())

        # BFS backward from the transformation instance through connectors
        visited = set()
        queue = [transformation_name]
        while queue:
            current = queue.pop(0)
            current_lower = current.lower()
            if current_lower in visited:
                continue
            visited.add(current_lower)

            for conn in mapping.connectors:
                if conn.to_instance.lower() == current_lower:
                    from_inst = conn.from_instance
                    from_lower = from_inst.lower()
                    # Check if the feeder is a Source Definition
                    if from_lower in source_def_names:
                        return from_inst
                    # Check if feeder is a source instance (transformation_name
                    # may match a source definition name)
                    for si in mapping.source_instances:
                        if si.name.lower() == from_lower:
                            actual = si.transformation_name or si.name
                            if actual.lower() in source_def_names:
                                return actual
                    # Continue tracing backward
                    if from_lower not in visited:
                        queue.append(from_inst)

        return None

    def _analyze_transformation_types(self, mapping) -> Dict[str, str]:
        """
        Analyze mapping to identify transformation types used.

        Returns dict mapping transformation instance name to type string.
        """
        result = {}
        for trans in mapping.transformations:
            # Handle both enum and string transformation_type
            trans_type = trans.transformation_type
            if hasattr(trans_type, 'value'):
                # It's an enum
                result[trans.name] = trans_type.value
            else:
                # It's a string
                result[trans.name] = str(trans_type)
        return result

    def _determine_edge_transformation_type(
        self,
        trans_types: Dict[str, str],
        lineage_result: LineageResult
    ) -> TransformationType:
        """
        Determine the transformation type for an edge based on the lineage.
        """
        # Check for aggregation
        if lineage_result.aggregators:
            return TransformationType.AGGREGATE

        # Check for lookups
        if lineage_result.lookup_tables:
            return TransformationType.LOOKUP

        # Check for filters
        if lineage_result.filters:
            return TransformationType.FILTER

        # Check transformation types in the mapping
        type_values = set(str(t).lower() for t in trans_types.values())

        if "joiner" in type_values:
            return TransformationType.JOIN
        if "router" in type_values:
            return TransformationType.ROUTE
        if "update strategy" in type_values:
            return TransformationType.UPDATE_STRATEGY
        if "expression" in type_values:
            return TransformationType.TRANSFORM

        # Default to extract if only Source Qualifier
        return TransformationType.EXTRACT

    def _resolve_cross_references(self, graph: UnifiedLineageGraph) -> None:
        """
        Resolve cross-mapping references between XMLs.

        Identifies where a target in one mapping becomes a source in another.
        """
        links = self.cross_ref_resolver.resolve(self.documents, graph)
        for link in links:
            graph.add_cross_mapping_link(link)

    def _detect_conflicts(self, graph: UnifiedLineageGraph) -> None:
        """
        Detect conflicting table definitions across XMLs.

        Flags tables that appear in multiple XMLs with different structures.
        """
        # Group tables by name across all documents
        table_definitions: Dict[str, List[Tuple[str, TableNode]]] = {}

        for xml_path, doc in self.documents.items():
            xml_name = os.path.basename(xml_path)

            # Collect all sources
            for source in doc.sources:
                if source.name not in table_definitions:
                    table_definitions[source.name] = []
                node = self._create_table_node_from_source(source, xml_name)
                table_definitions[source.name].append((xml_name, node))

            # Collect all targets
            for target in doc.targets:
                if target.name not in table_definitions:
                    table_definitions[target.name] = []
                node = self._create_table_node_from_target(target, xml_name)
                table_definitions[target.name].append((xml_name, node))

        # Check for conflicts
        for table_name, definitions in table_definitions.items():
            if len(definitions) <= 1:
                continue  # No conflict possible

            # Compare definitions
            conflict = self._compare_table_definitions(table_name, definitions)
            if conflict:
                graph.add_conflict(conflict)

    def _compare_table_definitions(
        self,
        table_name: str,
        definitions: List[Tuple[str, TableNode]]
    ) -> Optional[TableConflict]:
        """
        Compare table definitions from multiple sources.

        Returns a TableConflict if differences are found.
        """
        if len(definitions) < 2:
            return None

        base_xml, base_node = definitions[0]
        base_columns = set(base_node.columns.keys())
        source_files = [xml for xml, _ in definitions]

        differences = {
            "added_columns": [],
            "removed_columns": [],
            "type_changes": [],
        }

        has_differences = False

        for xml_name, node in definitions[1:]:
            node_columns = set(node.columns.keys())

            # Check for added columns
            added = node_columns - base_columns
            if added:
                differences["added_columns"].extend(list(added))
                has_differences = True

            # Check for removed columns
            removed = base_columns - node_columns
            if removed:
                differences["removed_columns"].extend(list(removed))
                has_differences = True

            # Check for type changes in common columns
            common = base_columns & node_columns
            for col in common:
                base_type = base_node.columns[col].get("datatype", "")
                node_type = node.columns[col].get("datatype", "")
                if base_type.lower() != node_type.lower():
                    differences["type_changes"].append({
                        "column": col,
                        "from": base_type,
                        "to": node_type,
                    })
                    has_differences = True

        if not has_differences:
            return None

        # Determine conflict type
        if differences["type_changes"]:
            conflict_type = "type_mismatch"
        elif differences["added_columns"] or differences["removed_columns"]:
            conflict_type = "schema_mismatch"
        else:
            conflict_type = "column_mismatch"

        # Generate recommendation
        recommendation = self._generate_conflict_recommendation(
            table_name, definitions, differences
        )

        return TableConflict(
            table_name=table_name,
            source_files=source_files,
            conflict_type=conflict_type,
            differences=differences,
            recommendation=recommendation,
            requires_manual_review=True,
        )

    def _generate_conflict_recommendation(
        self,
        table_name: str,
        definitions: List[Tuple[str, TableNode]],
        differences: Dict[str, Any]
    ) -> str:
        """Generate a recommendation for resolving a table conflict."""
        # Find the definition with most columns (likely the newest/most complete)
        max_cols = 0
        recommended_xml = ""
        for xml_name, node in definitions:
            if len(node.columns) > max_cols:
                max_cols = len(node.columns)
                recommended_xml = xml_name

        parts = [f"Use definition from {recommended_xml} (has most columns: {max_cols})"]

        if differences["added_columns"]:
            parts.append(f"Added columns: {', '.join(differences['added_columns'][:5])}")
        if differences["removed_columns"]:
            parts.append(f"Removed columns: {', '.join(differences['removed_columns'][:5])}")
        if differences["type_changes"]:
            changes = differences["type_changes"][:3]
            change_strs = [f"{c['column']}: {c['from']} -> {c['to']}" for c in changes]
            parts.append(f"Type changes: {'; '.join(change_strs)}")

        return ". ".join(parts)

    def get_document(self, xml_path: str) -> Optional[PowermartDocument]:
        """Get parsed document by path."""
        return self.documents.get(xml_path)

    def get_lineage_result(self, xml_path: str) -> Optional[LineageResult]:
        """Get lineage result by path."""
        return self.lineage_results.get(xml_path)

    def export_to_automedallion_format(
        self,
        graph: UnifiedLineageGraph
    ) -> Dict[str, Any]:
        """
        Export unified graph to AutoMedallion-compatible format.

        This produces the JSON structure expected by AutoMedallion's
        classifier and schema agents.
        """
        # Build table registry
        table_registry = {}
        for name, table in graph.tables.items():
            table_registry[name] = {
                "table_name": name,
                "qualified_name": table.qualified_name,
                "columns": table.columns,
                "database_type": table.database_type,
                "owner": table.owner,
                "primary_keys": [],  # Would need to be extracted from source/target metadata
            }

        # Build end-to-end lineage
        e2e_lineage = []
        paths = graph.get_end_to_end_paths()
        for path in paths:
            if len(path) >= 2:
                e2e_lineage.append({
                    "source_table": path[0],
                    "target_table": path[-1],
                    "intermediate_tables": path[1:-1] if len(path) > 2 else [],
                    "hop_count": len(path) - 1,
                    "lookup_tables": [],  # Would need more analysis
                })

        # Build files processed
        files_processed = []
        for xml_path, doc in self.documents.items():
            files_processed.append({
                "file_path": xml_path,
                "mapping_count": doc.mapping_count,
                "source_count": doc.source_count,
                "target_count": doc.target_count,
            })

        # Build Informatica metadata for downstream processing
        informatica_metadata = {
            "unified_graph": graph.to_dict(),
            "cross_mapping_links": [l.to_dict() for l in graph.cross_mapping_links],
            "conflicts": [c.to_dict() for c in graph.conflicts],
            "has_conflicts_requiring_review": graph.has_conflicts,
        }

        return {
            "files_processed": files_processed,
            "table_registry": table_registry,
            "end_to_end_lineage": e2e_lineage,
            "informatica_metadata": informatica_metadata,
            "source_type": "informatica_powercenter",
            "aggregation_timestamp": datetime.now().isoformat(),
        }
