"""Parser for Informatica SOURCE elements."""

import io
import xml.etree.ElementTree as ET
import defusedxml.ElementTree as DefusedET
from typing import Dict, List

from ..models.source_models import Source, SourceField
from ..utils.xml_utils import get_attr, get_attr_bool, get_attr_int


class SourceParser:
    """Parser for Informatica SOURCE and SOURCEFIELD elements."""

    def parse_source_field(self, element: ET.Element) -> SourceField:
        """
        Parse a SOURCEFIELD element.

        XML Example:
        <SOURCEFIELD BUSINESSNAME="" DATATYPE="varchar" DESCRIPTION=""
                     FIELDNUMBER="1" FIELDPROPERTY="0" FIELDTYPE="ELEMITEM"
                     HIDDEN="NO" KEYTYPE="PRIMARY KEY" LENGTH="0" LEVEL="0"
                     NAME="LNKEY" NULLABLE="NOTNULL" OCCURS="0" OFFSET="0"
                     PHYSICALLENGTH="20" PHYSICALOFFSET="0" PICTURETEXT=""
                     PRECISION="20" SCALE="0" USAGE_FLAGS=""/>
        """
        nullable_str = get_attr(element, "NULLABLE", "NULL")
        nullable = nullable_str.upper() != "NOTNULL"

        return SourceField(
            name=get_attr(element, "NAME"),
            datatype=get_attr(element, "DATATYPE"),
            precision=get_attr_int(element, "PRECISION"),
            scale=get_attr_int(element, "SCALE"),
            field_number=get_attr_int(element, "FIELDNUMBER"),
            description=get_attr(element, "DESCRIPTION"),
            nullable=nullable,
            keytype=get_attr(element, "KEYTYPE", "NOT A KEY"),
            field_type=get_attr(element, "FIELDTYPE", "ELEMITEM"),
            hidden=get_attr_bool(element, "HIDDEN"),
            level=get_attr_int(element, "LEVEL"),
            occurs=get_attr_int(element, "OCCURS"),
            offset=get_attr_int(element, "OFFSET"),
            physical_length=get_attr_int(element, "PHYSICALLENGTH"),
            physical_offset=get_attr_int(element, "PHYSICALOFFSET"),
            usage_flags=get_attr(element, "USAGE_FLAGS"),
            business_name=get_attr(element, "BUSINESSNAME"),
            group=get_attr(element, "GROUP"),
        )

    def _parse_xml_group_xpaths(self, element: ET.Element) -> Dict[str, str]:
        """Extract full XPath for each XML group from XMLINFO metadata.

        For XML sources, Informatica stores a METATABLE inside
        XMLINFO/XMLTEXT[@TYPE='TABLE'] that maps each flat group name
        (e.g. X_Serial_Collateral) to its full XPath in the XML schema
        (e.g. Xrf-Document/Registration-List/New-Registration/Collaterals/Serial-Collateral).

        Returns:
            Dict mapping group name -> full XPath string.
        """
        group_xpaths: Dict[str, str] = {}
        for xmlinfo in element.iter("XMLINFO"):
            for xmltext in xmlinfo.iter("XMLTEXT"):
                if xmltext.get("TYPE", "") != "TABLE":
                    continue
                text = xmltext.get("TEXT", "")
                if not text:
                    continue
                try:
                    meta_root = DefusedET.parse(io.StringIO(text)).getroot()
                    for grp in meta_root.iter("GROUP"):
                        gname = grp.get("GROUPNAME", "")
                        if not gname:
                            continue
                        gsat_elem = grp.find("GROUPSAT")
                        if gsat_elem is not None and gsat_elem.text:
                            group_xpaths[gname] = gsat_elem.text
                except ET.ParseError:
                    pass
        return group_xpaths

    def parse_source(self, element: ET.Element) -> Source:
        """
        Parse a SOURCE element.

        XML Example:
        <SOURCE BUSINESSNAME="" DATABASETYPE="Microsoft SQL Server"
                DBDNAME="Landing_LOS" DESCRIPTION="" NAME="LN_MTGTERMS"
                OBJECTVERSION="1" OWNERNAME="EMPOWER_WK" VERSIONNUMBER="1">
            <SOURCEFIELD ... />
            ...
        </SOURCE>
        """
        # For XML sources, resolve flat group names to full XPaths
        db_type = get_attr(element, "DATABASETYPE", "").upper()
        group_xpaths: Dict[str, str] = {}
        if "XML" in db_type:
            group_xpaths = self._parse_xml_group_xpaths(element)

        # Parse all SOURCEFIELD children
        fields = []
        for field_elem in element.findall("SOURCEFIELD"):
            fld = self.parse_source_field(field_elem)
            # Replace flat group name with full XPath if available
            if fld.group and fld.group in group_xpaths:
                fld.group = group_xpaths[fld.group]
            fields.append(fld)

        # Sort fields by field number
        fields.sort(key=lambda f: f.field_number)

        # Parse TABLEATTRIBUTE children (e.g. Source Filter, User Defined Join)
        table_attributes = []
        for ta_elem in element.findall("TABLEATTRIBUTE"):
            ta_name = get_attr(ta_elem, "NAME")
            ta_value = get_attr(ta_elem, "VALUE")
            if ta_name:
                table_attributes.append({"name": ta_name, "value": ta_value})

        return Source(
            name=get_attr(element, "NAME"),
            description=get_attr(element, "DESCRIPTION"),
            database_type=get_attr(element, "DATABASETYPE"),
            db_dname=get_attr(element, "DBDNAME"),
            owner_name=get_attr(element, "OWNERNAME"),
            fields=fields,
            table_attributes=table_attributes,
            object_version=get_attr_int(element, "OBJECTVERSION", 1),
            version_number=get_attr_int(element, "VERSIONNUMBER", 1),
            business_name=get_attr(element, "BUSINESSNAME"),
        )

    def parse_all(self, root: ET.Element) -> List[Source]:
        """
        Parse all SOURCE elements from the XML.

        Args:
            root: Root element of the XML (POWERMART or FOLDER)

        Returns:
            List of Source objects
        """
        sources = []
        for source_elem in root.iter("SOURCE"):
            sources.append(self.parse_source(source_elem))
        return sources
