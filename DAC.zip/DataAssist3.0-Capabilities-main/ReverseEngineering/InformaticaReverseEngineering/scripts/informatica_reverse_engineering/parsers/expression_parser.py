"""Parser for Informatica transformation expressions."""

import re
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Tuple
from enum import Enum


class FunctionCategory(Enum):
    """Categories of Informatica functions."""

    CONDITIONAL = "conditional"
    STRING = "string"
    DATE = "date"
    NUMERIC = "numeric"
    AGGREGATE = "aggregate"
    CONVERSION = "conversion"
    NULL_HANDLING = "null_handling"
    LOOKUP = "lookup"
    VARIABLE = "variable"
    ERROR = "error"
    UDF = "user_defined"
    UNKNOWN = "unknown"


@dataclass
class FunctionInfo:
    """Information about an Informatica function."""

    name: str
    category: FunctionCategory
    description_template: str
    arg_names: List[str] = field(default_factory=list)


# Informatica function definitions
INFORMATICA_FUNCTIONS: Dict[str, FunctionInfo] = {
    # Conditional
    "IIF": FunctionInfo(
        "IIF", FunctionCategory.CONDITIONAL,
        "If {condition} then {true_value} else {false_value}",
        ["condition", "true_value", "false_value"]
    ),
    "DECODE": FunctionInfo(
        "DECODE", FunctionCategory.CONDITIONAL,
        "Maps {value} to corresponding output based on defined mappings",
        ["value", "search1", "result1", "..."]
    ),
    "CASE": FunctionInfo(
        "CASE", FunctionCategory.CONDITIONAL,
        "Evaluates conditions and returns corresponding result",
        []
    ),

    # Null handling
    "ISNULL": FunctionInfo(
        "ISNULL", FunctionCategory.NULL_HANDLING,
        "Returns TRUE if {value} is NULL",
        ["value"]
    ),
    "NVL": FunctionInfo(
        "NVL", FunctionCategory.NULL_HANDLING,
        "Returns {value1} if not NULL, otherwise returns {value2}",
        ["value1", "value2"]
    ),
    "NVL2": FunctionInfo(
        "NVL2", FunctionCategory.NULL_HANDLING,
        "If {value} is not NULL returns {not_null_result}, otherwise {null_result}",
        ["value", "not_null_result", "null_result"]
    ),
    "NULLIF": FunctionInfo(
        "NULLIF", FunctionCategory.NULL_HANDLING,
        "Returns NULL if {value1} equals {value2}",
        ["value1", "value2"]
    ),

    # String functions
    "LTRIM": FunctionInfo(
        "LTRIM", FunctionCategory.STRING,
        "Removes leading whitespace/characters from {string}",
        ["string", "trim_chars"]
    ),
    "RTRIM": FunctionInfo(
        "RTRIM", FunctionCategory.STRING,
        "Removes trailing whitespace/characters from {string}",
        ["string", "trim_chars"]
    ),
    "TRIM": FunctionInfo(
        "TRIM", FunctionCategory.STRING,
        "Removes leading and trailing whitespace from {string}",
        ["string"]
    ),
    "SUBSTR": FunctionInfo(
        "SUBSTR", FunctionCategory.STRING,
        "Extracts substring from {string} starting at position {start} for {length} characters",
        ["string", "start", "length"]
    ),
    "CONCAT": FunctionInfo(
        "CONCAT", FunctionCategory.STRING,
        "Concatenates {strings} together",
        ["string1", "string2"]
    ),
    "LENGTH": FunctionInfo(
        "LENGTH", FunctionCategory.STRING,
        "Returns the length of {string}",
        ["string"]
    ),
    "UPPER": FunctionInfo(
        "UPPER", FunctionCategory.STRING,
        "Converts {string} to uppercase",
        ["string"]
    ),
    "LOWER": FunctionInfo(
        "LOWER", FunctionCategory.STRING,
        "Converts {string} to lowercase",
        ["string"]
    ),
    "INSTR": FunctionInfo(
        "INSTR", FunctionCategory.STRING,
        "Returns position of {search} in {string}",
        ["string", "search"]
    ),
    "REPLACE": FunctionInfo(
        "REPLACE", FunctionCategory.STRING,
        "Replaces {search} with {replacement} in {string}",
        ["string", "search", "replacement"]
    ),
    "REPLACESTR": FunctionInfo(
        "REPLACESTR", FunctionCategory.STRING,
        "Replaces multiple strings in {string}",
        ["string", "search", "replacement"]
    ),
    "LPAD": FunctionInfo(
        "LPAD", FunctionCategory.STRING,
        "Left-pads {string} to {length} with {pad_char}",
        ["string", "length", "pad_char"]
    ),
    "RPAD": FunctionInfo(
        "RPAD", FunctionCategory.STRING,
        "Right-pads {string} to {length} with {pad_char}",
        ["string", "length", "pad_char"]
    ),
    "REG_EXTRACT": FunctionInfo(
        "REG_EXTRACT", FunctionCategory.STRING,
        "Extracts text matching regex pattern from {string}",
        ["string", "pattern", "group"]
    ),
    "REG_MATCH": FunctionInfo(
        "REG_MATCH", FunctionCategory.STRING,
        "Returns TRUE if {string} matches regex {pattern}",
        ["string", "pattern"]
    ),
    "REG_REPLACE": FunctionInfo(
        "REG_REPLACE", FunctionCategory.STRING,
        "Replaces regex matches in {string}",
        ["string", "pattern", "replacement"]
    ),

    # Date functions
    "TO_DATE": FunctionInfo(
        "TO_DATE", FunctionCategory.DATE,
        "Converts {string} to date using format {format}",
        ["string", "format"]
    ),
    "TO_CHAR": FunctionInfo(
        "TO_CHAR", FunctionCategory.CONVERSION,
        "Converts {value} to string using format {format}",
        ["value", "format"]
    ),
    "SYSDATE": FunctionInfo(
        "SYSDATE", FunctionCategory.DATE,
        "Returns current system date and time",
        []
    ),
    "SYSTIMESTAMP": FunctionInfo(
        "SYSTIMESTAMP", FunctionCategory.DATE,
        "Returns current system timestamp",
        []
    ),
    "ADD_TO_DATE": FunctionInfo(
        "ADD_TO_DATE", FunctionCategory.DATE,
        "Adds {amount} {unit} to {date}",
        ["date", "unit", "amount"]
    ),
    "DATE_DIFF": FunctionInfo(
        "DATE_DIFF", FunctionCategory.DATE,
        "Returns difference between {date1} and {date2} in {unit}",
        ["date1", "date2", "unit"]
    ),
    "TRUNC": FunctionInfo(
        "TRUNC", FunctionCategory.DATE,
        "Truncates {date} to {precision}",
        ["date", "precision"]
    ),
    "GET_DATE_PART": FunctionInfo(
        "GET_DATE_PART", FunctionCategory.DATE,
        "Extracts {part} from {date}",
        ["date", "part"]
    ),

    # Numeric functions
    "ROUND": FunctionInfo(
        "ROUND", FunctionCategory.NUMERIC,
        "Rounds {number} to {precision} decimal places",
        ["number", "precision"]
    ),
    "ABS": FunctionInfo(
        "ABS", FunctionCategory.NUMERIC,
        "Returns absolute value of {number}",
        ["number"]
    ),
    "MOD": FunctionInfo(
        "MOD", FunctionCategory.NUMERIC,
        "Returns remainder of {dividend} divided by {divisor}",
        ["dividend", "divisor"]
    ),
    "POWER": FunctionInfo(
        "POWER", FunctionCategory.NUMERIC,
        "Returns {base} raised to power {exponent}",
        ["base", "exponent"]
    ),
    "CEIL": FunctionInfo(
        "CEIL", FunctionCategory.NUMERIC,
        "Returns smallest integer greater than or equal to {number}",
        ["number"]
    ),
    "FLOOR": FunctionInfo(
        "FLOOR", FunctionCategory.NUMERIC,
        "Returns largest integer less than or equal to {number}",
        ["number"]
    ),

    # Aggregate functions
    "SUM": FunctionInfo(
        "SUM", FunctionCategory.AGGREGATE,
        "Calculates sum of {values}",
        ["values"]
    ),
    "COUNT": FunctionInfo(
        "COUNT", FunctionCategory.AGGREGATE,
        "Counts number of {values}",
        ["values"]
    ),
    "AVG": FunctionInfo(
        "AVG", FunctionCategory.AGGREGATE,
        "Calculates average of {values}",
        ["values"]
    ),
    "MAX": FunctionInfo(
        "MAX", FunctionCategory.AGGREGATE,
        "Returns maximum of {values}",
        ["values"]
    ),
    "MIN": FunctionInfo(
        "MIN", FunctionCategory.AGGREGATE,
        "Returns minimum of {values}",
        ["values"]
    ),
    "FIRST": FunctionInfo(
        "FIRST", FunctionCategory.AGGREGATE,
        "Returns first value in group",
        ["values"]
    ),
    "LAST": FunctionInfo(
        "LAST", FunctionCategory.AGGREGATE,
        "Returns last value in group",
        ["values"]
    ),
    "MEDIAN": FunctionInfo(
        "MEDIAN", FunctionCategory.AGGREGATE,
        "Returns median of {values}",
        ["values"]
    ),
    "STDDEV": FunctionInfo(
        "STDDEV", FunctionCategory.AGGREGATE,
        "Returns standard deviation of {values}",
        ["values"]
    ),

    # Conversion functions
    "TO_INTEGER": FunctionInfo(
        "TO_INTEGER", FunctionCategory.CONVERSION,
        "Converts {value} to integer",
        ["value"]
    ),
    "TO_DECIMAL": FunctionInfo(
        "TO_DECIMAL", FunctionCategory.CONVERSION,
        "Converts {value} to decimal with precision {precision}",
        ["value", "precision"]
    ),
    "TO_FLOAT": FunctionInfo(
        "TO_FLOAT", FunctionCategory.CONVERSION,
        "Converts {value} to float",
        ["value"]
    ),
    "TO_BIGINT": FunctionInfo(
        "TO_BIGINT", FunctionCategory.CONVERSION,
        "Converts {value} to big integer",
        ["value"]
    ),

    # Variable functions
    "SETVARIABLE": FunctionInfo(
        "SETVARIABLE", FunctionCategory.VARIABLE,
        "Sets variable {variable} to {value}",
        ["variable", "value"]
    ),
    "SETCOUNTVARIABLE": FunctionInfo(
        "SETCOUNTVARIABLE", FunctionCategory.VARIABLE,
        "Sets count variable {variable} to {value}",
        ["variable", "value"]
    ),
    "SETMAXVARIABLE": FunctionInfo(
        "SETMAXVARIABLE", FunctionCategory.VARIABLE,
        "Sets max variable {variable} to maximum of current and {value}",
        ["variable", "value"]
    ),

    # Error handling
    "ERROR": FunctionInfo(
        "ERROR", FunctionCategory.ERROR,
        "Raises an error with message: {message}",
        ["message"]
    ),
    "ABORT": FunctionInfo(
        "ABORT", FunctionCategory.ERROR,
        "Aborts the session with message: {message}",
        ["message"]
    ),

    # Lookup
    "LOOKUP": FunctionInfo(
        "LOOKUP", FunctionCategory.LOOKUP,
        "Looks up value from lookup transformation",
        ["return_port", "condition"]
    ),
}


@dataclass
class ParsedExpression:
    """Result of parsing an expression."""

    original: str
    main_function: Optional[str] = None
    category: FunctionCategory = FunctionCategory.UNKNOWN
    referenced_fields: List[str] = field(default_factory=list)
    referenced_variables: List[str] = field(default_factory=list)
    functions_used: List[str] = field(default_factory=list)
    explanation: str = ""
    is_simple_passthrough: bool = False
    is_constant: bool = False

    def to_dict(self) -> Dict[str, Any]:
        return {
            "original": self.original,
            "main_function": self.main_function,
            "category": self.category.value,
            "referenced_fields": self.referenced_fields,
            "referenced_variables": self.referenced_variables,
            "functions_used": self.functions_used,
            "explanation": self.explanation,
            "is_simple_passthrough": self.is_simple_passthrough,
            "is_constant": self.is_constant,
        }


class ExpressionParser:
    """Parser for Informatica transformation expressions."""

    # Regex patterns
    FUNCTION_PATTERN = re.compile(r'([A-Z_][A-Z0-9_]*)\s*\(', re.IGNORECASE)
    FIELD_PATTERN = re.compile(r'\b([A-Z_][A-Z0-9_]*)\b', re.IGNORECASE)
    VARIABLE_PATTERN = re.compile(r'\$\$([A-Z_][A-Z0-9_]*)', re.IGNORECASE)
    STRING_LITERAL = re.compile(r"'[^']*'")
    UDF_PATTERN = re.compile(r':UDF\.([A-Z_][A-Z0-9_]*)', re.IGNORECASE)

    # Keywords to exclude from field detection
    KEYWORDS = {
        'AND', 'OR', 'NOT', 'NULL', 'TRUE', 'FALSE', 'IS', 'IN', 'BETWEEN',
        'LIKE', 'CASE', 'WHEN', 'THEN', 'ELSE', 'END', 'AS', 'BY', 'ASC',
        'DESC', 'DD_INSERT', 'DD_UPDATE', 'DD_DELETE', 'DD_REJECT',
    }

    def __init__(self):
        pass

    def parse(self, expression: str) -> ParsedExpression:
        """
        Parse an Informatica expression.

        Args:
            expression: The expression string to parse

        Returns:
            ParsedExpression object with analysis results
        """
        if not expression or not expression.strip():
            return ParsedExpression(
                original="",
                is_simple_passthrough=True,
                explanation="Empty expression (passthrough)"
            )

        expr = expression.strip()
        result = ParsedExpression(original=expr)

        # Check for simple passthrough (just a field name)
        if re.match(r'^[A-Z_][A-Z0-9_]*$', expr, re.IGNORECASE):
            result.is_simple_passthrough = True
            result.referenced_fields = [expr]
            result.explanation = f"Direct passthrough of field: {expr}"
            return result

        # Check for constant
        if self._is_constant(expr):
            result.is_constant = True
            result.explanation = f"Constant value: {expr}"
            return result

        # Extract functions used (including UDFs)
        result.functions_used = self._extract_functions(expr)
        if result.functions_used:
            result.main_function = result.functions_used[0]
            func_info = INFORMATICA_FUNCTIONS.get(result.main_function.upper())
            if func_info:
                result.category = func_info.category

        # Extract referenced fields
        result.referenced_fields = self._extract_fields(expr)

        # Extract referenced variables
        result.referenced_variables = self._extract_variables(expr)

        # Generate explanation
        result.explanation = self._generate_explanation(result)

        return result

    def _is_constant(self, expr: str) -> bool:
        """Check if expression is a constant value."""
        expr = expr.strip()
        # Numeric constant
        if re.match(r'^-?\d+(\.\d+)?$', expr):
            return True
        # String constant
        if re.match(r"^'[^']*'$", expr):
            return True
        # NULL
        if expr.upper() == 'NULL':
            return True
        return False

    def _extract_functions(self, expr: str) -> List[str]:
        """Extract all function names from expression."""
        functions = []

        # Find UDF functions first
        udf_matches = self.UDF_PATTERN.findall(expr)
        for udf in udf_matches:
            functions.append(f"UDF_{udf}")

        # Remove string literals to avoid false matches
        clean_expr = self.STRING_LITERAL.sub('', expr)

        # Find regular functions
        matches = self.FUNCTION_PATTERN.findall(clean_expr)
        for match in matches:
            func_name = match.upper()
            if func_name not in self.KEYWORDS and func_name not in functions:
                functions.append(func_name)

        return functions

    def _extract_fields(self, expr: str) -> List[str]:
        """Extract field references from expression."""
        # Remove string literals
        clean_expr = self.STRING_LITERAL.sub('', expr)

        # Remove function names (they're not fields)
        for func in self.FUNCTION_PATTERN.findall(clean_expr):
            clean_expr = re.sub(rf'\b{func}\s*\(', '(', clean_expr, flags=re.IGNORECASE)

        # Remove variables
        clean_expr = self.VARIABLE_PATTERN.sub('', clean_expr)

        # Remove UDF references
        clean_expr = self.UDF_PATTERN.sub('', clean_expr)

        # Find all identifiers
        fields = []
        for match in self.FIELD_PATTERN.findall(clean_expr):
            if match.upper() not in self.KEYWORDS and match not in fields:
                # Check if it's actually a field (not a number or keyword)
                if not re.match(r'^\d', match):
                    fields.append(match)

        return fields

    def _extract_variables(self, expr: str) -> List[str]:
        """Extract variable references from expression."""
        return [f"$${v}" for v in self.VARIABLE_PATTERN.findall(expr)]

    def _generate_explanation(self, result: ParsedExpression) -> str:
        """Generate English explanation of the expression."""
        if result.is_simple_passthrough:
            return f"Direct passthrough of field: {result.referenced_fields[0] if result.referenced_fields else 'unknown'}"

        if result.is_constant:
            return f"Constant value: {result.original}"

        if not result.main_function:
            if result.referenced_fields:
                return f"Expression using fields: {', '.join(result.referenced_fields)}"
            return "Complex expression"

        func_info = INFORMATICA_FUNCTIONS.get(result.main_function.upper())
        if func_info:
            # Build explanation from template
            explanation = func_info.description_template

            # Add field references
            if result.referenced_fields:
                fields_str = ", ".join(result.referenced_fields)
                explanation += f" (using fields: {fields_str})"

            # Add variable references
            if result.referenced_variables:
                vars_str = ", ".join(result.referenced_variables)
                explanation += f" (variables: {vars_str})"

            return explanation

        return f"Uses {result.main_function} function on: {', '.join(result.referenced_fields) or 'values'}"

    def get_transformation_description(self, expression: str) -> str:
        """
        Get a human-readable description of a transformation expression.

        Args:
            expression: The expression to describe

        Returns:
            Human-readable description
        """
        parsed = self.parse(expression)
        return parsed.explanation
