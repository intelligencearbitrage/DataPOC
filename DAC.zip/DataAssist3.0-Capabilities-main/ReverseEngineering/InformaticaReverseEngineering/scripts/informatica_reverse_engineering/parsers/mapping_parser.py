"""Parser for Informatica MAPPING elements."""

import xml.etree.ElementTree as ET
from typing import List, Optional

from ..models.mapping_models import (
    Mapping,
    Instance,
    MappingVariable,
    AssociatedSourceInstance,
)
from ..utils.xml_utils import get_attr, get_attr_bool, get_attr_int

from .source_parser import SourceParser
from .target_parser import TargetParser
from .transformation_parser import TransformationParser
from .connector_parser import ConnectorParser


class MappingParser:
    """Parser for Informatica MAPPING elements."""

    def __init__(self):
        self.source_parser = SourceParser()
        self.target_parser = TargetParser()
        self.transformation_parser = TransformationParser()
        self.connector_parser = ConnectorParser()

    def parse_mapping_variable(self, element: ET.Element) -> MappingVariable:
        """
        Parse a MAPPINGVARIABLE element.

        XML Example:
        <MAPPINGVARIABLE DATATYPE="string" DEFAULTVALUE="" DESCRIPTION=""
                         ISEXPRESSIONVARIABLE="NO" ISPARAM="YES"
                         NAME="$$InterfaceName" PRECISION="100" SCALE="0"
                         USERDEFINED="YES"/>
        """
        return MappingVariable(
            name=get_attr(element, "NAME"),
            datatype=get_attr(element, "DATATYPE"),
            default_value=get_attr(element, "DEFAULTVALUE"),
            precision=get_attr_int(element, "PRECISION"),
            scale=get_attr_int(element, "SCALE"),
            is_param=get_attr_bool(element, "ISPARAM"),
            is_expression_variable=get_attr_bool(element, "ISEXPRESSIONVARIABLE"),
            user_defined=get_attr_bool(element, "USERDEFINED"),
            agg_function=get_attr(element, "AGGFUNCTION"),
            description=get_attr(element, "DESCRIPTION"),
        )

    def parse_associated_source(self, element: ET.Element) -> AssociatedSourceInstance:
        """Parse ASSOCIATED_SOURCE_INSTANCE element."""
        return AssociatedSourceInstance(name=get_attr(element, "NAME"))

    def parse_instance(self, element: ET.Element) -> Instance:
        """
        Parse an INSTANCE element.

        XML Example:
        <INSTANCE DESCRIPTION="" NAME="Shortcut_to_ST_MORT_LOAN_PRCS_XT3"
                  TRANSFORMATION_NAME="Shortcut_to_ST_MORT_LOAN_PRCS_XT3"
                  TRANSFORMATION_TYPE="Target Definition" TYPE="TARGET"/>

        <INSTANCE DBDNAME="Landing_LOS" DESCRIPTION=""
                  NAME="Shortcut_to_LN_MTGTERMS"
                  TRANSFORMATION_NAME="Shortcut_to_LN_MTGTERMS"
                  TRANSFORMATION_TYPE="Source Definition" TYPE="SOURCE"/>

        <INSTANCE DESCRIPTION="" NAME="exp_COLUMN_SETUP" REUSABLE="NO"
                  TRANSFORMATION_NAME="exp_COLUMN_SETUP"
                  TRANSFORMATION_TYPE="Expression" TYPE="TRANSFORMATION">
            <ASSOCIATED_SOURCE_INSTANCE NAME="Shortcut_to_LN_MTGTERMS"/>
        </INSTANCE>
        """
        # Parse associated sources
        associated_sources = []
        for assoc_elem in element.findall("ASSOCIATED_SOURCE_INSTANCE"):
            associated_sources.append(self.parse_associated_source(assoc_elem))

        # Parse TABLEATTRIBUTE children for instance-level attributes
        attributes = {}
        for attr_elem in element.findall("TABLEATTRIBUTE"):
            name = get_attr(attr_elem, "NAME")
            value = get_attr(attr_elem, "VALUE")
            if name:
                attributes[name] = value

        return Instance(
            name=get_attr(element, "NAME"),
            transformation_name=get_attr(element, "TRANSFORMATION_NAME"),
            transformation_type=get_attr(element, "TRANSFORMATION_TYPE"),
            instance_type=get_attr(element, "TYPE"),
            description=get_attr(element, "DESCRIPTION"),
            reusable=get_attr_bool(element, "REUSABLE"),
            db_dname=get_attr(element, "DBDNAME"),
            associated_sources=associated_sources,
            attributes=attributes,
        )

    def parse_mapping(self, element: ET.Element) -> Mapping:
        """
        Parse a MAPPING element.

        XML Example:
        <MAPPING DESCRIPTION="" ISVALID="YES"
                 NAME="m_Common_Check_For_New_Or_Open_Process_Step"
                 OBJECTVERSION="1" VERSIONNUMBER="180">
            <TRANSFORMATION ... />
            <INSTANCE ... />
            <CONNECTOR ... />
            <MAPPINGVARIABLE ... />
        </MAPPING>
        """
        # Parse transformations within mapping
        transformations = []
        for trans_elem in element.findall("TRANSFORMATION"):
            transformations.append(
                self.transformation_parser.parse_transformation(trans_elem)
            )

        # Parse instances
        instances = []
        for inst_elem in element.findall("INSTANCE"):
            instances.append(self.parse_instance(inst_elem))

        # Parse connectors (the KEY for field-level lineage)
        connectors = self.connector_parser.parse_from_mapping(element)

        # Parse mapping variables
        variables = []
        for var_elem in element.findall("MAPPINGVARIABLE"):
            variables.append(self.parse_mapping_variable(var_elem))

        # Parse target load order
        # Each TARGETLOADORDER is a direct child of MAPPING with ORDER and TARGETINSTANCE attributes
        target_load_order_entries = []
        for tlo_elem in element.findall("TARGETLOADORDER"):
            instance_name = get_attr(tlo_elem, "TARGETINSTANCE")
            order = get_attr_int(tlo_elem, "ORDER", 1)
            if instance_name:
                target_load_order_entries.append((order, instance_name))
        # Sort by ORDER and extract just the instance names
        target_load_order_entries.sort(key=lambda x: x[0])
        target_load_order = [name for _, name in target_load_order_entries]
        target_load_order_detailed = [
            {"order": order, "target_instance": name}
            for order, name in target_load_order_entries
        ]

        return Mapping(
            name=get_attr(element, "NAME"),
            description=get_attr(element, "DESCRIPTION"),
            is_valid=get_attr_bool(element, "ISVALID", True),
            object_version=get_attr_int(element, "OBJECTVERSION", 1),
            version_number=get_attr_int(element, "VERSIONNUMBER", 1),
            sources=[],  # Sources are at folder level, linked later
            targets=[],  # Targets are at folder level, linked later
            transformations=transformations,
            instances=instances,
            connectors=connectors,
            variables=variables,
            target_load_order=target_load_order,
            target_load_order_detailed=target_load_order_detailed,
        )

    def parse_all(self, root: ET.Element) -> List[Mapping]:
        """
        Parse all MAPPING elements from the XML.

        Args:
            root: Root element of the XML

        Returns:
            List of Mapping objects
        """
        mappings = []
        for mapping_elem in root.iter("MAPPING"):
            mappings.append(self.parse_mapping(mapping_elem))
        return mappings
