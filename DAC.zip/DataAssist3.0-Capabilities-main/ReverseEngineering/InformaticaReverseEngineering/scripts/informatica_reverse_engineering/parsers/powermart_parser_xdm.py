"""
XDM-Enhanced parser for Informatica POWERMART XML exports.

This parser uses lxml and XPath for efficient parsing and querying,
while maintaining full compatibility with the existing PowermartParser.

Key improvements:
- XPath-based element querying
- Context-aware field resolution
- MappingAST generation for structural analysis
- Improved accuracy for lineage extraction
"""

from lxml import etree
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional, Union, Tuple

from ..models.source_models import Source, SourceField
from ..models.target_models import Target, TargetField
from ..models.transformation_models import Transformation, TransformField
from ..models.mapping_models import Mapping, Instance
from ..models.connector_models import Connector
from ..models.session_models import Session, SessionAttribute
from ..models.workflow_models import Workflow, Task, WorkflowLink

from ..utils.xml_utils_xdm import XDMXMLParser, FieldContext, ConnectorContext
from ..utils.xpath_builder import InformaticaXPathBuilder, InformaticaXPathPatterns, xpath_builder
from ..utils.mapping_ast import MappingAST, TransformationNode, ConnectorEdge, FieldNode, NodeType
from ..utils.logging_config import get_logger

from .powermart_parser import PowermartDocument, RepositoryInfo, FolderInfo

logger = get_logger("powermart_parser_xdm")


@dataclass
class XDMParseResult:
    """
    Extended parse result with XDM capabilities.

    Contains both the standard PowermartDocument and XDM-specific artifacts
    like MappingASTs for structural analysis.
    """
    document: PowermartDocument
    xdm_parser: XDMXMLParser
    mapping_asts: Dict[str, MappingAST] = field(default_factory=dict)

    def get_ast(self, mapping_name: str) -> Optional[MappingAST]:
        """Get the AST for a specific mapping."""
        return self.mapping_asts.get(mapping_name.lower())

    def query(self, xpath: str):
        """Execute XPath query on the document."""
        return self.xdm_parser.xpath(xpath)


class PowermartParserXDM:
    """
    XDM-Enhanced parser for Informatica POWERMART XML exports.

    This parser provides improved accuracy and efficiency through:
    - lxml-based parsing with XPath support
    - MappingAST generation for structural analysis
    - Context-aware field resolution
    - Efficient batch queries

    Example:
        parser = PowermartParserXDM()
        result = parser.parse_file("mapping.xml")

        # Access standard document
        doc = result.document

        # Use XPath queries
        filters = result.query("//TRANSFORMATION[@TYPE='Filter']")

        # Use MappingAST for analysis
        ast = result.get_ast("m_MyMapping")
        unmapped = ast.find_unmapped_target_fields()
    """

    def __init__(self, build_ast: bool = True):
        """
        Initialize the XDM parser.

        Args:
            build_ast: Whether to build MappingASTs for all mappings
        """
        self.build_ast = build_ast
        self.xdm: Optional[XDMXMLParser] = None

    def parse_file(self, file_path: Union[str, Path]) -> XDMParseResult:
        """
        Parse an Informatica POWERMART XML file.

        Args:
            file_path: Path to the XML file

        Returns:
            XDMParseResult with document and XDM artifacts
        """
        path = Path(file_path)
        logger.info(f"Parsing Informatica XML file with XDM: {path}")

        # Initialize XDM parser
        self.xdm = XDMXMLParser(path)

        # Parse the document
        doc = self._parse_document()
        doc.file_path = str(path)

        # Build MappingASTs if requested
        mapping_asts = {}
        if self.build_ast:
            for mapping in doc.mappings:
                ast = self._build_mapping_ast(mapping)
                mapping_asts[mapping.name.lower()] = ast

        logger.info(f"Parsed: {doc.source_count} sources, {doc.target_count} targets, "
                   f"{doc.mapping_count} mappings, {doc.workflow_count} workflows")

        return XDMParseResult(
            document=doc,
            xdm_parser=self.xdm,
            mapping_asts=mapping_asts
        )

    def parse_string(self, xml_content: str) -> XDMParseResult:
        """Parse Informatica XML from a string."""
        self.xdm = XDMXMLParser()
        self.xdm.parse_string(xml_content)

        doc = self._parse_document()

        mapping_asts = {}
        if self.build_ast:
            for mapping in doc.mappings:
                ast = self._build_mapping_ast(mapping)
                mapping_asts[mapping.name.lower()] = ast

        return XDMParseResult(
            document=doc,
            xdm_parser=self.xdm,
            mapping_asts=mapping_asts
        )

    def _parse_document(self) -> PowermartDocument:
        """Parse the full document using XPath queries."""
        root = self.xdm.root

        # Get root attributes
        creation_date = self.xdm.get_attr(root, "CREATION_DATE")
        repository_version = self.xdm.get_attr(root, "REPOSITORY_VERSION")

        # Parse repository info
        repository = self._parse_repository()

        # Parse folder info
        folder = self._parse_folder()

        # Parse all sources using XPath
        sources = self._parse_all_sources()
        logger.debug(f"Parsed {len(sources)} sources")

        # Parse all targets
        targets = self._parse_all_targets()
        logger.debug(f"Parsed {len(targets)} targets")

        # Parse all transformations at folder level
        transformations = self._parse_all_transformations()
        logger.debug(f"Parsed {len(transformations)} transformations")

        # Parse all mappings
        mappings = self._parse_all_mappings()
        logger.debug(f"Parsed {len(mappings)} mappings")

        # Link sources and targets to mappings
        self._link_sources_targets(mappings, sources, targets)

        # Parse all sessions
        sessions = self._parse_all_sessions()
        logger.debug(f"Parsed {len(sessions)} sessions")

        # Parse all workflows
        workflows = self._parse_all_workflows()
        logger.debug(f"Parsed {len(workflows)} workflows")

        return PowermartDocument(
            creation_date=creation_date,
            repository_version=repository_version,
            repository=repository,
            folder=folder,
            sources=sources,
            targets=targets,
            transformations=transformations,
            mappings=mappings,
            sessions=sessions,
            workflows=workflows,
        )

    def _parse_repository(self) -> Optional[RepositoryInfo]:
        """Parse repository information."""
        repo_result = self.xdm.xpath("//REPOSITORY")
        if repo_result.first() is not None:
            elem = repo_result.first()
            return RepositoryInfo(
                name=self.xdm.get_attr(elem, "NAME"),
                version=self.xdm.get_attr(elem, "VERSION"),
                codepage=self.xdm.get_attr(elem, "CODEPAGE"),
                database_type=self.xdm.get_attr(elem, "DATABASETYPE"),
            )
        return None

    def _parse_folder(self) -> Optional[FolderInfo]:
        """Parse folder information."""
        folder_result = self.xdm.xpath("//FOLDER")
        if folder_result.first() is not None:
            elem = folder_result.first()
            shared = self.xdm.get_attr(elem, "SHARED", "").upper() == "SHARED"
            return FolderInfo(
                name=self.xdm.get_attr(elem, "NAME"),
                owner=self.xdm.get_attr(elem, "OWNER"),
                shared=shared,
                group=self.xdm.get_attr(elem, "GROUP"),
                description=self.xdm.get_attr(elem, "DESCRIPTION"),
            )
        return None

    def _parse_all_sources(self) -> List[Source]:
        """Parse all SOURCE elements using XPath."""
        sources = []
        # Get sources at folder level (not inside mappings)
        source_elements = self.xdm.xpath("//FOLDER/SOURCE")

        for elem in source_elements:
            source = self._parse_source(elem)
            sources.append(source)

        return sources

    def _parse_source(self, elem: etree._Element) -> Source:
        """Parse a single SOURCE element."""
        source = Source(
            name=self.xdm.get_attr(elem, "NAME"),
            db_dname=self.xdm.get_attr(elem, "DBDNAME"),
            owner_name=self.xdm.get_attr(elem, "OWNERNAME"),
            database_type=self.xdm.get_attr(elem, "DATABASETYPE"),
            description=self.xdm.get_attr(elem, "DESCRIPTION"),
        )

        # Parse source fields using XPath
        field_elements = self.xdm.xpath(".//SOURCEFIELD", context=elem)
        for field_elem in field_elements:
            field = SourceField(
                name=self.xdm.get_attr(field_elem, "NAME"),
                datatype=self.xdm.get_attr(field_elem, "DATATYPE"),
                precision=self.xdm.get_attr_int(field_elem, "PRECISION"),
                scale=self.xdm.get_attr_int(field_elem, "SCALE"),
                keytype=self.xdm.get_attr(field_elem, "KEYTYPE", "NOT A KEY"),
                nullable=self.xdm.get_attr(field_elem, "NULLABLE", "NULL") == "NULL",
                field_number=self.xdm.get_attr_int(field_elem, "FIELDNUMBER"),
                description=self.xdm.get_attr(field_elem, "DESCRIPTION"),
            )
            source.fields.append(field)

        return source

    def _parse_all_targets(self) -> List[Target]:
        """Parse all TARGET elements using XPath."""
        targets = []
        # Get targets at folder level
        target_elements = self.xdm.xpath("//FOLDER/TARGET")

        for elem in target_elements:
            target = self._parse_target(elem)
            targets.append(target)

        return targets

    def _parse_target(self, elem: etree._Element) -> Target:
        """Parse a single TARGET element."""
        target = Target(
            name=self.xdm.get_attr(elem, "NAME"),
            database_type=self.xdm.get_attr(elem, "DATABASETYPE"),
            description=self.xdm.get_attr(elem, "DESCRIPTION"),
        )

        # Parse target fields using XPath
        field_elements = self.xdm.xpath(".//TARGETFIELD", context=elem)
        for field_elem in field_elements:
            field = TargetField(
                name=self.xdm.get_attr(field_elem, "NAME"),
                datatype=self.xdm.get_attr(field_elem, "DATATYPE"),
                precision=self.xdm.get_attr_int(field_elem, "PRECISION"),
                scale=self.xdm.get_attr_int(field_elem, "SCALE"),
                keytype=self.xdm.get_attr(field_elem, "KEYTYPE", "NOT A KEY"),
                nullable=self.xdm.get_attr(field_elem, "NULLABLE", "NULL") == "NULL",
                field_number=self.xdm.get_attr_int(field_elem, "FIELDNUMBER"),
                description=self.xdm.get_attr(field_elem, "DESCRIPTION"),
            )
            target.fields.append(field)

        return target

    def _parse_all_transformations(self) -> List[Transformation]:
        """Parse all TRANSFORMATION elements at folder level."""
        transformations = []
        # Get transformations at folder level (reusable)
        trans_elements = self.xdm.xpath("//FOLDER/TRANSFORMATION")

        for elem in trans_elements:
            trans = self._parse_transformation(elem)
            transformations.append(trans)

        return transformations

    def _parse_transformation(self, elem: etree._Element) -> Transformation:
        """Parse a single TRANSFORMATION element."""
        trans = Transformation(
            name=self.xdm.get_attr(elem, "NAME"),
            type=self.xdm.get_attr(elem, "TYPE"),
            description=self.xdm.get_attr(elem, "DESCRIPTION"),
            reusable=self.xdm.get_attr_bool(elem, "REUSABLE"),
        )

        # Parse transform fields
        field_elements = self.xdm.xpath(".//TRANSFORMFIELD", context=elem)
        for field_elem in field_elements:
            field = TransformField(
                name=self.xdm.get_attr(field_elem, "NAME"),
                datatype=self.xdm.get_attr(field_elem, "DATATYPE"),
                precision=self.xdm.get_attr_int(field_elem, "PRECISION"),
                scale=self.xdm.get_attr_int(field_elem, "SCALE"),
                port_type=self.xdm.get_attr(field_elem, "PORTTYPE", "INPUT/OUTPUT"),
                expression=self.xdm.get_attr(field_elem, "EXPRESSION"),
                default_value=self.xdm.get_attr(field_elem, "DEFAULTVALUE"),
                description=self.xdm.get_attr(field_elem, "DESCRIPTION"),
                ref_source_field=self.xdm.get_attr(field_elem, "REF_FIELD"),
            )
            trans.fields.append(field)

        # Parse table attributes
        from ..models.transformation_models import TableAttribute
        attr_elements = self.xdm.xpath(".//TABLEATTRIBUTE", context=elem)
        for attr_elem in attr_elements:
            attr = TableAttribute(
                name=self.xdm.get_attr(attr_elem, "NAME"),
                value=self.xdm.get_attr(attr_elem, "VALUE"),
            )
            trans.attributes.append(attr)

        return trans

    def _parse_all_mappings(self) -> List[Mapping]:
        """Parse all MAPPING elements."""
        mappings = []
        mapping_elements = self.xdm.xpath("//MAPPING")

        for elem in mapping_elements:
            mapping = self._parse_mapping(elem)
            mappings.append(mapping)

        return mappings

    def _parse_mapping(self, elem: etree._Element) -> Mapping:
        """Parse a single MAPPING element."""
        mapping = Mapping(
            name=self.xdm.get_attr(elem, "NAME"),
            description=self.xdm.get_attr(elem, "DESCRIPTION"),
            is_valid=self.xdm.get_attr_bool(elem, "ISVALID", True),
        )

        # Parse transformations within mapping
        trans_elements = self.xdm.xpath(".//TRANSFORMATION", context=elem)
        for trans_elem in trans_elements:
            trans = self._parse_transformation(trans_elem)
            mapping.transformations.append(trans)

        # Parse instances
        instance_elements = self.xdm.xpath(".//INSTANCE", context=elem)
        for inst_elem in instance_elements:
            # Determine instance type from transformation type
            trans_type = self.xdm.get_attr(inst_elem, "TYPE")
            if "Source" in trans_type:
                inst_type = "SOURCE"
            elif "Target" in trans_type:
                inst_type = "TARGET"
            else:
                inst_type = "TRANSFORMATION"

            instance = Instance(
                name=self.xdm.get_attr(inst_elem, "NAME"),
                transformation_name=self.xdm.get_attr(inst_elem, "TRANSFORMATION_NAME"),
                transformation_type=trans_type,
                instance_type=inst_type,
                description=self.xdm.get_attr(inst_elem, "DESCRIPTION"),
                reusable=self.xdm.get_attr_bool(inst_elem, "REUSABLE"),
            )
            mapping.instances.append(instance)

        # Parse connectors
        connector_elements = self.xdm.xpath(".//CONNECTOR", context=elem)
        for conn_elem in connector_elements:
            connector = Connector(
                from_instance=self.xdm.get_attr(conn_elem, "FROMINSTANCE"),
                from_field=self.xdm.get_attr(conn_elem, "FROMFIELD"),
                from_instance_type=self.xdm.get_attr(conn_elem, "FROMINSTANCETYPE"),
                to_instance=self.xdm.get_attr(conn_elem, "TOINSTANCE"),
                to_field=self.xdm.get_attr(conn_elem, "TOFIELD"),
                to_instance_type=self.xdm.get_attr(conn_elem, "TOINSTANCETYPE"),
            )
            mapping.connectors.append(connector)

        # Parse mapping variables
        from ..models.mapping_models import MappingVariable
        var_elements = self.xdm.xpath(".//MAPPINGVARIABLE", context=elem)
        for var_elem in var_elements:
            var = MappingVariable(
                name=self.xdm.get_attr(var_elem, "NAME"),
                datatype=self.xdm.get_attr(var_elem, "DATATYPE"),
                default_value=self.xdm.get_attr(var_elem, "DEFAULTVALUE"),
                precision=self.xdm.get_attr_int(var_elem, "PRECISION"),
                scale=self.xdm.get_attr_int(var_elem, "SCALE"),
                is_expression_variable=self.xdm.get_attr_bool(var_elem, "ISEXPRESSIONVARIABLE"),
                is_param=self.xdm.get_attr_bool(var_elem, "ISPARAM"),
            )
            mapping.variables.append(var)

        return mapping

    def _parse_all_sessions(self) -> List[Session]:
        """Parse all SESSION elements."""
        sessions = []
        session_elements = self.xdm.xpath("//SESSION")

        for elem in session_elements:
            session = self._parse_session(elem)
            sessions.append(session)

        return sessions

    def _parse_session(self, elem: etree._Element) -> Session:
        """Parse a single SESSION element."""
        session = Session(
            name=self.xdm.get_attr(elem, "NAME"),
            mapping_name=self.xdm.get_attr(elem, "MAPPINGNAME"),
            description=self.xdm.get_attr(elem, "DESCRIPTION"),
            is_valid=self.xdm.get_attr_bool(elem, "ISVALID", True),
            reusable=self.xdm.get_attr_bool(elem, "REUSABLE"),
        )

        # Parse session attributes
        attr_elements = self.xdm.xpath(".//ATTRIBUTE", context=elem)
        for attr_elem in attr_elements:
            attr = SessionAttribute(
                name=self.xdm.get_attr(attr_elem, "NAME"),
                value=self.xdm.get_attr(attr_elem, "VALUE"),
            )
            session.attributes.append(attr)

        return session

    def _parse_all_workflows(self) -> List[Workflow]:
        """Parse all WORKFLOW elements."""
        workflows = []
        workflow_elements = self.xdm.xpath("//WORKFLOW")

        for elem in workflow_elements:
            workflow = self._parse_workflow(elem)
            workflows.append(workflow)

        return workflows

    def _parse_workflow(self, elem: etree._Element) -> Workflow:
        """Parse a single WORKFLOW element."""
        workflow = Workflow(
            name=self.xdm.get_attr(elem, "NAME"),
            description=self.xdm.get_attr(elem, "DESCRIPTION"),
            is_enabled=self.xdm.get_attr_bool(elem, "ISENABLED", True),
            is_valid=self.xdm.get_attr_bool(elem, "ISVALID", True),
            server_name=self.xdm.get_attr(elem, "SERVERNAME"),
            server_domain_name=self.xdm.get_attr(elem, "SERVERDOMAINNAME"),
        )

        # Parse tasks
        task_elements = self.xdm.xpath(".//TASK", context=elem)
        for task_elem in task_elements:
            task = Task(
                name=self.xdm.get_attr(task_elem, "NAME"),
                task_type=self.xdm.get_attr(task_elem, "TYPE"),
                description=self.xdm.get_attr(task_elem, "DESCRIPTION"),
                reusable=self.xdm.get_attr_bool(task_elem, "REUSABLE"),
            )
            workflow.tasks.append(task)

        # Parse workflow links
        link_elements = self.xdm.xpath(".//WORKFLOWLINK", context=elem)
        for link_elem in link_elements:
            link = WorkflowLink(
                from_task=self.xdm.get_attr(link_elem, "FROMTASK"),
                to_task=self.xdm.get_attr(link_elem, "TOTASK"),
                condition=self.xdm.get_attr(link_elem, "CONDITION"),
            )
            workflow.links.append(link)

        # Parse sessions within workflow
        session_elements = self.xdm.xpath(".//SESSION", context=elem)
        for session_elem in session_elements:
            session = self._parse_session(session_elem)
            workflow.sessions.append(session)

        return workflow

    def _link_sources_targets(
        self,
        mappings: List[Mapping],
        sources: List[Source],
        targets: List[Target]
    ) -> None:
        """Link sources and targets to their mappings."""
        source_lookup = {s.name.lower(): s for s in sources}
        target_lookup = {t.name.lower(): t for t in targets}

        for mapping in mappings:
            mapping_sources = []
            mapping_targets = []

            for instance in mapping.instances:
                if instance.is_source:
                    src_name = instance.transformation_name.lower()
                    if src_name.startswith("shortcut_to_"):
                        src_name = src_name[12:]

                    source = source_lookup.get(src_name)
                    if source and source not in mapping_sources:
                        mapping_sources.append(source)

                elif instance.is_target:
                    tgt_name = instance.transformation_name.lower()
                    if tgt_name.startswith("shortcut_to_"):
                        tgt_name = tgt_name[12:]

                    target = target_lookup.get(tgt_name)
                    if target and target not in mapping_targets:
                        mapping_targets.append(target)

            mapping.sources = mapping_sources
            mapping.targets = mapping_targets

    # =========================================================================
    # MappingAST Building
    # =========================================================================

    def _build_mapping_ast(self, mapping: Mapping) -> MappingAST:
        """
        Build a MappingAST for structural analysis.

        Args:
            mapping: The mapping to build AST for

        Returns:
            MappingAST with nodes and edges
        """
        ast = MappingAST(mapping_name=mapping.name)

        # Create nodes for each instance
        for instance in mapping.instances:
            node = TransformationNode(
                name=instance.name,
                transformation_name=instance.transformation_name,
                node_type=NodeType.from_informatica_type(instance.transformation_type),
                informatica_type=instance.transformation_type,
            )

            # Add fields from the corresponding transformation
            trans = mapping.get_transformation(instance.transformation_name)
            if trans:
                for field in trans.fields:
                    field_node = FieldNode(
                        name=field.name,
                        datatype=field.datatype,
                        precision=field.precision,
                        scale=field.scale,
                        expression=field.expression,
                        default_value=field.default_value,
                        is_input="INPUT" in field.port_type.upper(),
                        is_output="OUTPUT" in field.port_type.upper(),
                    )
                    node.add_field(field_node)

            ast.add_node(node)

        # Create edges from connectors
        for connector in mapping.connectors:
            edge = ConnectorEdge(
                from_instance=connector.from_instance,
                from_field=connector.from_field,
                to_instance=connector.to_instance,
                to_field=connector.to_field,
                from_instance_type=connector.from_instance_type,
                to_instance_type=connector.to_instance_type,
            )
            ast.add_edge(edge)

        # Build indexes
        ast.build()

        return ast

    # =========================================================================
    # XDM-Specific Query Methods
    # =========================================================================

    def find_unmapped_target_fields(self, mapping_name: str) -> List[Dict[str, str]]:
        """
        Find target fields with no incoming connectors.

        Uses XPath for efficient detection.
        """
        if self.xdm is None:
            raise ValueError("No document loaded")
        return self.xdm.find_unmapped_target_fields(mapping_name)

    def find_expressions_containing(
        self,
        function_pattern: str,
        mapping_name: Optional[str] = None
    ) -> List[Dict[str, str]]:
        """Find expressions containing a specific function pattern."""
        if self.xdm is None:
            raise ValueError("No document loaded")
        return self.xdm.find_expressions_containing(function_pattern, mapping_name)

    def find_sql_overrides(self, mapping_name: Optional[str] = None) -> List[Dict[str, str]]:
        """Find SQL overrides in source qualifiers."""
        if self.xdm is None:
            raise ValueError("No document loaded")
        return self.xdm.find_sql_overrides(mapping_name)

    def get_mapping_statistics(self, mapping_name: str) -> Dict[str, Any]:
        """Get comprehensive statistics for a mapping."""
        if self.xdm is None:
            raise ValueError("No document loaded")
        return self.xdm.get_mapping_statistics(mapping_name)

    def validate_connectors(self, mapping_name: str) -> List[Dict[str, str]]:
        """Validate connectors in a mapping."""
        if self.xdm is None:
            raise ValueError("No document loaded")
        return self.xdm.validate_connectors(mapping_name)

    def query(self, xpath: str):
        """Execute arbitrary XPath query on the document."""
        if self.xdm is None:
            raise ValueError("No document loaded")
        return self.xdm.xpath(xpath)
