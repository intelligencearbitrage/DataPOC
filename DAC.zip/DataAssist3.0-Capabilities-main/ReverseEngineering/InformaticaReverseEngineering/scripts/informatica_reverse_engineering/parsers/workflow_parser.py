"""Parser for Informatica WORKFLOW elements."""

import xml.etree.ElementTree as ET
from typing import List, Optional

from ..models.workflow_models import (
    Workflow,
    Worklet,
    Task,
    WorkflowLink,
    WorkflowVariable,
    Scheduler,
    ScheduleInfo,
)
from ..models.session_models import SessionAttribute
from ..utils.xml_utils import get_attr, get_attr_bool, get_attr_int, decode_xml_entities

from .session_parser import SessionParser


class WorkflowParser:
    """Parser for Informatica WORKFLOW elements."""

    def __init__(self):
        self.session_parser = SessionParser()

    def parse_workflow_variable(self, element: ET.Element) -> WorkflowVariable:
        """Parse a WORKFLOWVARIABLE element."""
        return WorkflowVariable(
            name=get_attr(element, "NAME"),
            datatype=get_attr(element, "DATATYPE"),
            default_value=get_attr(element, "DEFAULTVALUE"),
            is_null=get_attr_bool(element, "ISNULL"),
            is_persistent=get_attr_bool(element, "ISPERSISTENT"),
            precision=get_attr_int(element, "PRECISION"),
            scale=get_attr_int(element, "SCALE"),
            user_defined=get_attr_bool(element, "USERDEFINED"),
            description=get_attr(element, "DESCRIPTION"),
        )

    def parse_schedule_info(self, element: ET.Element) -> ScheduleInfo:
        """Parse a SCHEDULEINFO element."""
        return ScheduleInfo(
            schedule_type=get_attr(element, "SCHEDULETYPE"),
            start_date=get_attr(element, "STARTDATE"),
            start_time=get_attr(element, "STARTTIME"),
            end_date=get_attr(element, "ENDDATE"),
            end_time=get_attr(element, "ENDTIME"),
            repeat_interval=get_attr(element, "REPEATINTERVAL"),
        )

    def parse_scheduler(self, element: ET.Element) -> Scheduler:
        """
        Parse a SCHEDULER element.

        XML Example:
        <SCHEDULER DESCRIPTION="" NAME="Scheduler" REUSABLE="NO" VERSIONNUMBER="9">
            <SCHEDULEINFO SCHEDULETYPE="ONDEMAND"/>
        </SCHEDULER>
        """
        schedule_info = None
        si_elem = element.find("SCHEDULEINFO")
        if si_elem is not None:
            schedule_info = self.parse_schedule_info(si_elem)

        return Scheduler(
            name=get_attr(element, "NAME"),
            reusable=get_attr_bool(element, "REUSABLE"),
            version_number=get_attr_int(element, "VERSIONNUMBER", 1),
            description=get_attr(element, "DESCRIPTION"),
            schedule_info=schedule_info,
        )

    def parse_task(self, element: ET.Element) -> Task:
        """
        Parse a TASK element.

        XML Example:
        <TASK DESCRIPTION="" NAME="Start" REUSABLE="NO" TYPE="Start" VERSIONNUMBER="9"/>
        <TASK DESCRIPTION="Email task..." NAME="eml_OnFailure" REUSABLE="YES"
              TYPE="Email" VERSIONNUMBER="9"/>
        """
        # Parse attributes
        attributes = []
        for attr_elem in element.findall("ATTRIBUTE"):
            attributes.append(SessionAttribute(
                name=get_attr(attr_elem, "NAME"),
                value=decode_xml_entities(get_attr(attr_elem, "VALUE")),
            ))

        return Task(
            name=get_attr(element, "NAME"),
            task_type=get_attr(element, "TYPE"),
            description=get_attr(element, "DESCRIPTION"),
            reusable=get_attr_bool(element, "REUSABLE"),
            version_number=get_attr_int(element, "VERSIONNUMBER", 1),
            attributes=attributes,
        )

    def parse_workflow_link(self, element: ET.Element) -> WorkflowLink:
        """
        Parse a WORKFLOWLINK element.

        XML Example:
        <WORKFLOWLINK CONDITION="$s_Session1.Status = SUCCEEDED"
                      FROMTASK="s_Session1" TOTASK="s_Session2"/>
        <WORKFLOWLINK CONDITION="" FROMTASK="Start" TOTASK="s_Session1"/>
        """
        return WorkflowLink(
            from_task=get_attr(element, "FROMTASK"),
            to_task=get_attr(element, "TOTASK"),
            condition=decode_xml_entities(get_attr(element, "CONDITION")),
        )

    def parse_task_instance(self, element: ET.Element) -> Task:
        """
        Parse a TASKINSTANCE element (worklet or session instance reference).

        XML Example:
        <TASKINSTANCE NAME="wklt_inst" TASKNAME="wklt_LoadData"
                      TASKTYPE="Worklet" REUSABLE="NO" .../>
        """
        attributes = []
        for attr_elem in element.findall("ATTRIBUTE"):
            attributes.append(SessionAttribute(
                name=get_attr(attr_elem, "NAME"),
                value=decode_xml_entities(get_attr(attr_elem, "VALUE")),
            ))

        # Store taskname as an attribute for later resolution
        taskname = get_attr(element, "TASKNAME")
        if taskname:
            attributes.append(SessionAttribute(name="taskname", value=taskname))

        reusable_val = get_attr(element, "REUSABLE")
        if reusable_val:
            attributes.append(SessionAttribute(name="reusable", value=reusable_val))

        return Task(
            name=get_attr(element, "NAME"),
            task_type=get_attr(element, "TASKTYPE"),
            description=get_attr(element, "DESCRIPTION"),
            reusable=get_attr_bool(element, "REUSABLE"),
            version_number=get_attr_int(element, "VERSIONNUMBER", 1),
            attributes=attributes,
        )

    def parse_worklet(self, element: ET.Element) -> Worklet:
        """
        Parse a WORKLET element (same structure as WORKFLOW).

        XML Example:
        <WORKLET NAME="wklt_LoadData" ...>
            <SCHEDULER ... />
            <TASK ... />
            <SESSION ... />
            <WORKFLOWLINK ... />
        </WORKLET>
        """
        scheduler = None
        sched_elem = element.find("SCHEDULER")
        if sched_elem is not None:
            scheduler = self.parse_scheduler(sched_elem)

        tasks = []
        for task_elem in element.findall("TASK"):
            tasks.append(self.parse_task(task_elem))

        # Also parse TASKINSTANCE elements within the worklet
        for ti_elem in element.findall("TASKINSTANCE"):
            tasks.append(self.parse_task_instance(ti_elem))

        sessions = []
        for session_elem in element.findall("SESSION"):
            sessions.append(self.session_parser.parse_session(session_elem))

        links = []
        for link_elem in element.findall("WORKFLOWLINK"):
            links.append(self.parse_workflow_link(link_elem))

        variables = []
        for var_elem in element.findall("WORKFLOWVARIABLE"):
            variables.append(self.parse_workflow_variable(var_elem))

        attributes = []
        for attr_elem in element.findall("ATTRIBUTE"):
            attributes.append(SessionAttribute(
                name=get_attr(attr_elem, "NAME"),
                value=decode_xml_entities(get_attr(attr_elem, "VALUE")),
            ))

        return Worklet(
            name=get_attr(element, "NAME"),
            description=get_attr(element, "DESCRIPTION"),
            is_valid=get_attr_bool(element, "ISVALID", True),
            version_number=get_attr_int(element, "VERSIONNUMBER", 1),
            scheduler=scheduler,
            tasks=tasks,
            sessions=sessions,
            links=links,
            variables=variables,
            attributes=attributes,
        )

    def parse_all_worklets(self, root: ET.Element) -> List[Worklet]:
        """
        Parse all WORKLET elements from the XML.

        Args:
            root: Root element of the XML

        Returns:
            List of Worklet objects
        """
        worklets = []
        for wklt_elem in root.iter("WORKLET"):
            worklets.append(self.parse_worklet(wklt_elem))
        return worklets

    def parse_workflow(self, element: ET.Element) -> Workflow:
        """
        Parse a WORKFLOW element.

        XML Example:
        <WORKFLOW DESCRIPTION="..." ISENABLED="YES" ISRUNNABLESERVICE="NO"
                  ISSERVICE="NO" ISVALID="YES" NAME="wf_GL_Entries_Transaction_Output"
                  REUSABLE_SCHEDULER="NO" SCHEDULERNAME="Scheduler"
                  SERVERNAME="PWC_Integration" SERVER_DOMAINNAME="Domain_Production"
                  SUSPEND_ON_ERROR="NO" TASKS_MUST_RUN_ON_SERVER="NO" VERSIONNUMBER="9">
            <SCHEDULER ... />
            <TASK ... />
            <SESSION ... />
            <WORKFLOWLINK ... />
        </WORKFLOW>
        """
        # Parse scheduler
        scheduler = None
        sched_elem = element.find("SCHEDULER")
        if sched_elem is not None:
            scheduler = self.parse_scheduler(sched_elem)

        # Parse tasks
        tasks = []
        for task_elem in element.findall("TASK"):
            tasks.append(self.parse_task(task_elem))

        # Parse TASKINSTANCE elements (worklet/session references)
        for ti_elem in element.findall("TASKINSTANCE"):
            tasks.append(self.parse_task_instance(ti_elem))

        # Parse sessions
        sessions = []
        for session_elem in element.findall("SESSION"):
            sessions.append(self.session_parser.parse_session(session_elem))

        # Parse workflow links
        links = []
        for link_elem in element.findall("WORKFLOWLINK"):
            links.append(self.parse_workflow_link(link_elem))

        # Parse workflow variables
        variables = []
        for var_elem in element.findall("WORKFLOWVARIABLE"):
            variables.append(self.parse_workflow_variable(var_elem))

        # Parse workflow-level attributes
        attributes = []
        for attr_elem in element.findall("ATTRIBUTE"):
            attributes.append(SessionAttribute(
                name=get_attr(attr_elem, "NAME"),
                value=decode_xml_entities(get_attr(attr_elem, "VALUE")),
            ))

        return Workflow(
            name=get_attr(element, "NAME"),
            description=get_attr(element, "DESCRIPTION"),
            is_enabled=get_attr_bool(element, "ISENABLED", True),
            is_valid=get_attr_bool(element, "ISVALID", True),
            is_service=get_attr_bool(element, "ISSERVICE"),
            is_runnable_service=get_attr_bool(element, "ISRUNNABLESERVICE"),
            reusable_scheduler=get_attr_bool(element, "REUSABLE_SCHEDULER"),
            scheduler_name=get_attr(element, "SCHEDULERNAME"),
            server_name=get_attr(element, "SERVERNAME"),
            server_domain_name=get_attr(element, "SERVER_DOMAINNAME"),
            suspend_on_error=get_attr_bool(element, "SUSPEND_ON_ERROR"),
            tasks_must_run_on_server=get_attr_bool(element, "TASKS_MUST_RUN_ON_SERVER"),
            version_number=get_attr_int(element, "VERSIONNUMBER", 1),
            scheduler=scheduler,
            tasks=tasks,
            sessions=sessions,
            links=links,
            variables=variables,
            attributes=attributes,
        )

    def parse_all(self, root: ET.Element) -> List[Workflow]:
        """
        Parse all WORKFLOW elements from the XML.

        Args:
            root: Root element of the XML

        Returns:
            List of Workflow objects
        """
        workflows = []
        for wf_elem in root.iter("WORKFLOW"):
            workflows.append(self.parse_workflow(wf_elem))
        return workflows
