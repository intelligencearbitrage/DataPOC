"""Parser for Informatica TRANSFORMATION elements."""

import xml.etree.ElementTree as ET
from typing import List, Optional

import re

from ..models.transformation_models import (
    Transformation,
    TransformField,
    TableAttribute,
    RouterGroup,
)
from ..utils.xml_utils import get_attr, get_attr_bool, get_attr_int, decode_xml_entities


class TransformationParser:
    """Parser for Informatica TRANSFORMATION elements."""

    def parse_table_attribute(self, element: ET.Element) -> TableAttribute:
        """
        Parse a TABLEATTRIBUTE element.

        XML Example:
        <TABLEATTRIBUTE NAME="Tracing Level" VALUE="Normal"/>
        <TABLEATTRIBUTE NAME="Filter Condition" VALUE="NOT ISNULL(Err_Code)"/>
        """
        return TableAttribute(
            name=get_attr(element, "NAME"),
            value=decode_xml_entities(get_attr(element, "VALUE")),
        )

    def parse_transform_field(self, element: ET.Element) -> TransformField:
        """
        Parse a TRANSFORMFIELD element.

        XML Example:
        <TRANSFORMFIELD DATATYPE="integer" DEFAULTVALUE="" DESCRIPTION=""
                        EXPRESSION="COUNT(BATCH_ID)" EXPRESSIONTYPE="GENERAL"
                        NAME="RECORD_COUNT" PICTURETEXT="" PORTTYPE="OUTPUT"
                        PRECISION="10" SCALE="0"/>
        """
        nullable_str = get_attr(element, "NULLABLE", "NULL")
        nullable = nullable_str.upper() != "NOTNULL"

        return TransformField(
            name=get_attr(element, "NAME"),
            datatype=get_attr(element, "DATATYPE"),
            precision=get_attr_int(element, "PRECISION"),
            scale=get_attr_int(element, "SCALE"),
            description=get_attr(element, "DESCRIPTION"),
            nullable=nullable,
            port_type=get_attr(element, "PORTTYPE", "INPUT"),
            expression=decode_xml_entities(get_attr(element, "EXPRESSION")),
            expression_type=get_attr(element, "EXPRESSIONTYPE"),
            default_value=get_attr(element, "DEFAULTVALUE"),
            picture_text=get_attr(element, "PICTURETEXT"),
            ref_source_field=get_attr(element, "REF_FIELD") or get_attr(element, "REF_SOURCE_FIELD"),
            group=get_attr(element, "GROUP"),
        )

    def parse_group(self, element: ET.Element) -> RouterGroup:
        """
        Parse a GROUP element within a Router transformation.

        XML Example:
        <GROUP NAME="VALID_RECORDS" DESCRIPTION="Valid rows"
               EXPRESSION="IS_VALID = 'Y'" ORDER="1" TYPE="OUTPUT"/>
        """
        return RouterGroup(
            name=get_attr(element, "NAME"),
            expression=decode_xml_entities(get_attr(element, "EXPRESSION")),
            order=get_attr_int(element, "ORDER"),
            group_type=get_attr(element, "TYPE"),
            description=get_attr(element, "DESCRIPTION"),
        )

    def parse_transformation(self, element: ET.Element) -> Transformation:
        """
        Parse a TRANSFORMATION element.

        XML Example:
        <TRANSFORMATION DESCRIPTION="" NAME="exp_COLUMN_SETUP" OBJECTVERSION="1"
                        REUSABLE="NO" TYPE="Expression" VERSIONNUMBER="1">
            <TRANSFORMFIELD ... />
            <TABLEATTRIBUTE ... />
        </TRANSFORMATION>
        """
        # Parse TRANSFORMFIELD children
        fields = []
        for field_elem in element.findall("TRANSFORMFIELD"):
            fields.append(self.parse_transform_field(field_elem))

        # Also parse SOURCEFIELD for Normalizer transformations
        for field_elem in element.findall("SOURCEFIELD"):
            # Convert SOURCEFIELD to TransformField format
            sf = TransformField(
                name=get_attr(field_elem, "NAME"),
                datatype=get_attr(field_elem, "DATATYPE"),
                precision=get_attr_int(field_elem, "PRECISION"),
                scale=get_attr_int(field_elem, "SCALE"),
                port_type="INPUT",
                ref_source_field=get_attr(field_elem, "NAME"),
            )
            fields.append(sf)

        # Parse TABLEATTRIBUTE children
        attributes = []
        for attr_elem in element.findall("TABLEATTRIBUTE"):
            attributes.append(self.parse_table_attribute(attr_elem))

        # Parse GROUP children (for Router transformations)
        groups = []
        for group_elem in element.findall("GROUP"):
            groups.append(self.parse_group(group_elem))

        # Fallback: if no GROUP elements but TABLEATTRIBUTE entries match
        # "Group \d+" pattern, synthesize RouterGroup objects
        if not groups:
            for attr in attributes:
                if re.match(r"^(?:Router\s+)?Group\s+\d+$", attr.name, re.IGNORECASE):
                    groups.append(RouterGroup(
                        name=attr.name,
                        expression=attr.value,
                        order=int(re.search(r"\d+", attr.name).group()) if re.search(r"\d+", attr.name) else 0,
                        group_type="OUTPUT",
                        description="",
                    ))

        return Transformation(
            name=get_attr(element, "NAME"),
            description=get_attr(element, "DESCRIPTION"),
            type=get_attr(element, "TYPE"),
            reusable=get_attr_bool(element, "REUSABLE"),
            fields=fields,
            attributes=attributes,
            groups=groups,
            object_version=get_attr_int(element, "OBJECTVERSION", 1),
            version_number=get_attr_int(element, "VERSIONNUMBER", 1),
            template_id=get_attr(element, "TEMPLATEID"),
            template_name=get_attr(element, "TEMPLATENAME"),
        )

    def parse_all(self, root: ET.Element) -> List[Transformation]:
        """
        Parse all TRANSFORMATION elements from the XML.

        Args:
            root: Root element of the XML

        Returns:
            List of Transformation objects
        """
        transformations = []
        for trans_elem in root.iter("TRANSFORMATION"):
            transformations.append(self.parse_transformation(trans_elem))
        return transformations
