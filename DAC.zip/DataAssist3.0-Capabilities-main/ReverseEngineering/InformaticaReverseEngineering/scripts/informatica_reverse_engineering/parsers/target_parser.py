"""Parser for Informatica TARGET elements."""

import xml.etree.ElementTree as ET
from typing import List

from ..models.target_models import Target, TargetField, TargetLoadOrder
from ..utils.xml_utils import get_attr, get_attr_bool, get_attr_int


class TargetParser:
    """Parser for Informatica TARGET and TARGETFIELD elements."""

    def parse_target_field(self, element: ET.Element) -> TargetField:
        """
        Parse a TARGETFIELD element.

        XML Example:
        <TARGETFIELD BUSINESSNAME="" DATATYPE="char" DESCRIPTION=""
                     FIELDNUMBER="1" KEYTYPE="NOT A KEY" NAME="DUMMY_FIELD"
                     NULLABLE="NULL" PICTURETEXT="" PRECISION="1" SCALE="0"/>
        """
        nullable_str = get_attr(element, "NULLABLE", "NULL")
        nullable = nullable_str.upper() != "NOTNULL"

        return TargetField(
            name=get_attr(element, "NAME"),
            datatype=get_attr(element, "DATATYPE"),
            precision=get_attr_int(element, "PRECISION"),
            scale=get_attr_int(element, "SCALE"),
            field_number=get_attr_int(element, "FIELDNUMBER"),
            description=get_attr(element, "DESCRIPTION"),
            nullable=nullable,
            keytype=get_attr(element, "KEYTYPE", "NOT A KEY"),
            picture_text=get_attr(element, "PICTURETEXT"),
            business_name=get_attr(element, "BUSINESSNAME"),
        )

    def parse_target_load_order(self, element: ET.Element) -> TargetLoadOrder:
        """Parse a TARGETLOADORDER element."""
        return TargetLoadOrder(
            order=get_attr_int(element, "ORDER", 1),
            target_instance=get_attr(element, "TARGETINSTANCE"),
        )

    def parse_target(self, element: ET.Element) -> Target:
        """
        Parse a TARGET element.

        XML Example:
        <TARGET BUSINESSNAME="" CONSTRAINT="" DATABASETYPE="Microsoft SQL Server"
                DESCRIPTION="" NAME="DUMMY" OBJECTVERSION="1" TABLEOPTIONS=""
                VERSIONNUMBER="186">
            <TARGETFIELD ... />
            <TARGETLOADORDER ORDER="1" TARGETINSTANCE="DUMMY"/>
        </TARGET>
        """
        # Parse all TARGETFIELD children
        fields = []
        for field_elem in element.findall("TARGETFIELD"):
            fields.append(self.parse_target_field(field_elem))

        # Sort fields by field number
        fields.sort(key=lambda f: f.field_number)

        # Parse load orders
        load_orders = []
        for lo_elem in element.findall("TARGETLOADORDER"):
            load_orders.append(self.parse_target_load_order(lo_elem))

        return Target(
            name=get_attr(element, "NAME"),
            description=get_attr(element, "DESCRIPTION"),
            database_type=get_attr(element, "DATABASETYPE"),
            constraint=get_attr(element, "CONSTRAINT"),
            table_options=get_attr(element, "TABLEOPTIONS"),
            fields=fields,
            load_orders=load_orders,
            object_version=get_attr_int(element, "OBJECTVERSION", 1),
            version_number=get_attr_int(element, "VERSIONNUMBER", 1),
            business_name=get_attr(element, "BUSINESSNAME"),
        )

    def parse_all(self, root: ET.Element) -> List[Target]:
        """
        Parse all TARGET elements from the XML.

        Args:
            root: Root element of the XML

        Returns:
            List of Target objects
        """
        targets = []
        for target_elem in root.iter("TARGET"):
            targets.append(self.parse_target(target_elem))
        return targets
