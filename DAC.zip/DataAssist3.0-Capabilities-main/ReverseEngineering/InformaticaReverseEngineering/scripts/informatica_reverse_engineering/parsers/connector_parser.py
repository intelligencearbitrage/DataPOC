"""Parser for Informatica CONNECTOR elements.

CONNECTOR elements are the KEY to field-level lineage extraction.
They define the complete data flow graph from source to target.
"""

import xml.etree.ElementTree as ET
from typing import List

from ..models.connector_models import Connector
from ..utils.xml_utils import get_attr


class ConnectorParser:
    """Parser for Informatica CONNECTOR elements."""

    def parse_connector(self, element: ET.Element) -> Connector:
        """
        Parse a CONNECTOR element.

        XML Example:
        <CONNECTOR FROMFIELD="LNKEY" FROMINSTANCE="SQ_Shortcut_to_LN_MTGTERMS"
                   FROMINSTANCETYPE="Source Qualifier"
                   TOFIELD="i_LNKEY" TOINSTANCE="exp_COLUMN_SETUP"
                   TOINSTANCETYPE="Expression"/>

        The CONNECTOR element defines:
        - FROMINSTANCE/FROMFIELD: Source of data flow
        - TOINSTANCE/TOFIELD: Destination of data flow
        - FROMINSTANCETYPE/TOINSTANCETYPE: Types of the instances
        """
        return Connector(
            from_instance=get_attr(element, "FROMINSTANCE"),
            from_field=get_attr(element, "FROMFIELD"),
            from_instance_type=get_attr(element, "FROMINSTANCETYPE"),
            to_instance=get_attr(element, "TOINSTANCE"),
            to_field=get_attr(element, "TOFIELD"),
            to_instance_type=get_attr(element, "TOINSTANCETYPE"),
        )

    def parse_all(self, root: ET.Element) -> List[Connector]:
        """
        Parse all CONNECTOR elements from the XML.

        Args:
            root: Root element of the XML (typically MAPPING)

        Returns:
            List of Connector objects
        """
        connectors = []
        for conn_elem in root.iter("CONNECTOR"):
            connectors.append(self.parse_connector(conn_elem))
        return connectors

    def parse_from_mapping(self, mapping_elem: ET.Element) -> List[Connector]:
        """
        Parse all CONNECTOR elements within a specific MAPPING element.

        Args:
            mapping_elem: MAPPING element

        Returns:
            List of Connector objects
        """
        connectors = []
        for conn_elem in mapping_elem.findall("CONNECTOR"):
            connectors.append(self.parse_connector(conn_elem))
        return connectors
