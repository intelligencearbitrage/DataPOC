"""Main parser for Informatica POWERMART XML exports."""

import xml.etree.ElementTree as ET
import defusedxml.ElementTree as DefusedET
from dataclasses import dataclass, field
from pathlib import Path
from werkzeug.utils import safe_join
from typing import Any, Dict, List, Optional, Union

from ..models.source_models import Source
from ..models.target_models import Target
from ..models.transformation_models import Transformation
from ..models.mapping_models import Mapping
from ..models.session_models import Session
from ..models.workflow_models import Workflow, Worklet

from ..utils.xml_utils import get_attr, parse_xml_file
from ..utils.logging_config import get_logger

from .source_parser import SourceParser
from .target_parser import TargetParser
from .transformation_parser import TransformationParser
from .mapping_parser import MappingParser
from .session_parser import SessionParser
from .workflow_parser import WorkflowParser


logger = get_logger("powermart_parser")


@dataclass
class MappletInfo:
    """Lightweight representation of an Informatica MAPPLET.

    Stores internal transformations, connectors, and field expressions
    so the lineage engine can trace through mapplet boundaries.
    """
    name: str
    # Internal transformations: trans_name -> {field_name -> expression}
    transformations: Dict[str, Dict[str, str]] = field(default_factory=dict)
    # Internal transformation types: trans_name -> type (e.g. "Expression", "Lookup Procedure")
    transformation_types: Dict[str, str] = field(default_factory=dict)
    # Internal connectors: (to_instance, to_field) -> (from_instance, from_field)
    connectors: Dict[tuple, tuple] = field(default_factory=dict)
    # Lookup table names: trans_name -> table_name
    lookup_tables: Dict[str, str] = field(default_factory=dict)
    # Lookup conditions: trans_name -> condition
    lookup_conditions: Dict[str, str] = field(default_factory=dict)


@dataclass
class RepositoryInfo:
    """Information about the Informatica repository."""

    name: str
    version: str
    codepage: str
    database_type: str

    def to_dict(self) -> Dict[str, Any]:
        return {
            "name": self.name,
            "version": self.version,
            "codepage": self.codepage,
            "database_type": self.database_type,
        }


@dataclass
class FolderInfo:
    """Information about an Informatica folder."""

    name: str
    owner: str
    shared: bool
    group: str = ""
    description: str = ""

    def to_dict(self) -> Dict[str, Any]:
        return {
            "name": self.name,
            "owner": self.owner,
            "shared": self.shared,
            "group": self.group,
            "description": self.description,
        }


@dataclass
class PowermartDocument:
    """
    Represents a complete parsed Informatica POWERMART XML document.

    Contains all sources, targets, transformations, mappings, sessions,
    and workflows from the XML export.
    """

    creation_date: str
    repository_version: str
    repository: Optional[RepositoryInfo] = None
    folder: Optional[FolderInfo] = None
    sources: List[Source] = field(default_factory=list)
    targets: List[Target] = field(default_factory=list)
    transformations: List[Transformation] = field(default_factory=list)
    mappings: List[Mapping] = field(default_factory=list)
    sessions: List[Session] = field(default_factory=list)
    workflows: List[Workflow] = field(default_factory=list)
    worklets: List[Worklet] = field(default_factory=list)
    mapplets: Dict[str, MappletInfo] = field(default_factory=dict)
    file_path: Optional[str] = None

    def get_mapping(self, name: str) -> Optional[Mapping]:
        """Get mapping by name (case-insensitive)."""
        name_lower = name.lower()
        for mapping in self.mappings:
            if mapping.name.lower() == name_lower:
                return mapping
        return None

    def get_workflow(self, name: str) -> Optional[Workflow]:
        """Get workflow by name (case-insensitive)."""
        name_lower = name.lower()
        for workflow in self.workflows:
            if workflow.name.lower() == name_lower:
                return workflow
        return None

    def get_source(self, name: str) -> Optional[Source]:
        """Get source by name (case-insensitive)."""
        name_lower = name.lower()
        for source in self.sources:
            if source.name.lower() == name_lower:
                return source
        return None

    def get_target(self, name: str) -> Optional[Target]:
        """Get target by name (case-insensitive)."""
        name_lower = name.lower()
        for target in self.targets:
            if target.name.lower() == name_lower:
                return target
        return None

    @property
    def source_count(self) -> int:
        return len(self.sources)

    @property
    def target_count(self) -> int:
        return len(self.targets)

    @property
    def mapping_count(self) -> int:
        return len(self.mappings)

    @property
    def workflow_count(self) -> int:
        return len(self.workflows)

    @property
    def worklet_count(self) -> int:
        return len(self.worklets)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "creation_date": self.creation_date,
            "repository_version": self.repository_version,
            "repository": self.repository.to_dict() if self.repository else None,
            "folder": self.folder.to_dict() if self.folder else None,
            "source_count": self.source_count,
            "target_count": self.target_count,
            "mapping_count": self.mapping_count,
            "workflow_count": self.workflow_count,
            "sources": [s.to_dict() for s in self.sources],
            "targets": [t.to_dict() for t in self.targets],
            "mappings": [m.to_dict() for m in self.mappings],
            "workflows": [w.to_dict() for w in self.workflows],
            "worklets": [w.to_dict() for w in self.worklets],
            "file_path": self.file_path,
        }

    def summary(self) -> str:
        """Get a summary of the document contents."""
        lines = [
            f"Informatica POWERMART Document",
            f"  File: {self.file_path or 'N/A'}",
            f"  Created: {self.creation_date}",
            f"  Repository Version: {self.repository_version}",
        ]
        if self.repository:
            lines.append(f"  Repository: {self.repository.name}")
        if self.folder:
            lines.append(f"  Folder: {self.folder.name}")
        lines.extend([
            f"",
            f"  Sources: {self.source_count}",
            f"  Targets: {self.target_count}",
            f"  Mappings: {self.mapping_count}",
            f"  Workflows: {self.workflow_count}",
            f"  Worklets: {self.worklet_count}",
        ])
        return "\n".join(lines)


class PowermartParser:
    """
    Main parser for Informatica POWERMART XML exports.

    This parser coordinates all sub-parsers to extract complete information
    from Informatica XML exports including sources, targets, transformations,
    mappings, sessions, and workflows.
    """

    def __init__(self):
        self.source_parser = SourceParser()
        self.target_parser = TargetParser()
        self.transformation_parser = TransformationParser()
        self.mapping_parser = MappingParser()
        self.session_parser = SessionParser()
        self.workflow_parser = WorkflowParser()

    def parse_file(self, file_path: Union[str, Path]) -> PowermartDocument:
        """
        Parse an Informatica POWERMART XML file.

        Args:
            file_path: Path to the XML file

        Returns:
            PowermartDocument containing all parsed objects
        """
        _raw = Path(file_path)
        path = Path(safe_join(str(_raw.parent), _raw.name))
        logger.info(f"Parsing Informatica XML file: {path}")

        # Parse XML
        root = parse_xml_file(path)

        # Parse the document
        doc = self.parse_element(root)
        doc.file_path = str(path)

        logger.info(f"Parsed: {doc.source_count} sources, {doc.target_count} targets, "
                   f"{doc.mapping_count} mappings, {doc.workflow_count} workflows")

        return doc

    def parse_element(self, root: ET.Element) -> PowermartDocument:
        """
        Parse a POWERMART XML element tree.

        Args:
            root: Root element (should be POWERMART)

        Returns:
            PowermartDocument containing all parsed objects
        """
        # Get root attributes
        creation_date = get_attr(root, "CREATION_DATE")
        repository_version = get_attr(root, "REPOSITORY_VERSION")

        # Parse repository info
        repository = None
        repo_elem = root.find(".//REPOSITORY")
        if repo_elem is not None:
            repository = RepositoryInfo(
                name=get_attr(repo_elem, "NAME"),
                version=get_attr(repo_elem, "VERSION"),
                codepage=get_attr(repo_elem, "CODEPAGE"),
                database_type=get_attr(repo_elem, "DATABASETYPE"),
            )

        # Parse folder info
        folder = None
        folder_elem = root.find(".//FOLDER")
        if folder_elem is not None:
            shared = get_attr(folder_elem, "SHARED", "").upper() == "SHARED"
            folder = FolderInfo(
                name=get_attr(folder_elem, "NAME"),
                owner=get_attr(folder_elem, "OWNER"),
                shared=shared,
                group=get_attr(folder_elem, "GROUP"),
                description=get_attr(folder_elem, "DESCRIPTION"),
            )

        # Parse all shortcuts (SHORTCUT elements map instance names to real definitions)
        shortcuts = self._parse_shortcuts(root)
        logger.debug(f"Parsed {len(shortcuts)} shortcuts")

        # Parse all mapplets (for deep tracing through mapplet boundaries)
        mapplets = self._parse_mapplets(root)
        logger.debug(f"Parsed {len(mapplets)} mapplets")

        # Parse all sources
        sources = self.source_parser.parse_all(root)
        logger.debug(f"Parsed {len(sources)} sources")

        # Parse all targets
        targets = self.target_parser.parse_all(root)
        logger.debug(f"Parsed {len(targets)} targets")

        # Parse all transformations at folder level (reusable)
        transformations = self.transformation_parser.parse_all(root)
        logger.debug(f"Parsed {len(transformations)} transformations")

        # Parse all mappings
        mappings = self.mapping_parser.parse_all(root)
        logger.debug(f"Parsed {len(mappings)} mappings")

        # Link sources and targets to mappings
        self._link_sources_targets(mappings, sources, targets, shortcuts)

        # Parse all sessions
        sessions = self.session_parser.parse_all(root)
        logger.debug(f"Parsed {len(sessions)} sessions")

        # Parse all workflows
        workflows = self.workflow_parser.parse_all(root)
        logger.debug(f"Parsed {len(workflows)} workflows")

        # Parse all worklets
        worklets = self.workflow_parser.parse_all_worklets(root)
        logger.debug(f"Parsed {len(worklets)} worklets")

        # Resolve worklet references within workflows
        if worklets:
            worklet_lookup = {w.name.lower(): w for w in worklets}
            for workflow in workflows:
                for task in workflow.tasks:
                    if task.is_worklet:
                        taskname_attr = task.get_attribute("taskname")
                        if taskname_attr:
                            resolved = worklet_lookup.get(taskname_attr.lower())
                            if resolved and resolved not in workflow.worklets:
                                workflow.worklets.append(resolved)

        doc = PowermartDocument(
            creation_date=creation_date,
            repository_version=repository_version,
            repository=repository,
            folder=folder,
            sources=sources,
            targets=targets,
            transformations=transformations,
            mappings=mappings,
            sessions=sessions,
            workflows=workflows,
            worklets=worklets,
            mapplets=mapplets,
        )
        doc.shortcuts = shortcuts
        return doc

    def _parse_shortcuts(self, root: ET.Element) -> Dict[str, str]:
        """
        Parse SHORTCUT elements to build a name -> actual object name mapping.

        Shortcuts reference objects (sources, targets, mappings) defined in
        other folders. The shortcut NAME is used as the instance
        transformation_name, while REFOBJECTNAME is the actual definition name.

        Returns:
            Dict mapping shortcut name (lowercase) to actual name.
        """
        shortcuts = {}
        for sc in root.iter("SHORTCUT"):
            sc_name = get_attr(sc, "NAME")
            ref_name = get_attr(sc, "REFOBJECTNAME")
            if sc_name and ref_name:
                shortcuts[sc_name.lower()] = ref_name
        return shortcuts

    @staticmethod
    def _parse_mapplets(root: ET.Element) -> Dict[str, MappletInfo]:
        """Parse MAPPLET elements to capture internal transformations and connectors.

        Returns:
            Dict mapping mapplet name (lowercase) to MappletInfo.
        """
        mapplets: Dict[str, MappletInfo] = {}
        for mapplet_elem in root.iter("MAPPLET"):
            name = get_attr(mapplet_elem, "NAME")
            if not name:
                continue
            info = MappletInfo(name=name)

            # Parse internal transformations
            for trans_elem in mapplet_elem.findall("TRANSFORMATION"):
                trans_name = get_attr(trans_elem, "NAME")
                trans_type = get_attr(trans_elem, "TYPE")
                if not trans_name:
                    continue
                info.transformation_types[trans_name.lower()] = trans_type

                # Capture field expressions
                field_exprs: Dict[str, str] = {}
                for field_elem in trans_elem.findall("TRANSFORMFIELD"):
                    fname = get_attr(field_elem, "NAME")
                    fexpr = get_attr(field_elem, "EXPRESSION")
                    if fname:
                        field_exprs[fname.lower()] = fexpr or ""
                info.transformations[trans_name.lower()] = field_exprs

                # Capture lookup table name and condition
                if "lookup" in trans_type.lower():
                    for attr_elem in trans_elem.findall("TABLEATTRIBUTE"):
                        attr_name = get_attr(attr_elem, "NAME")
                        attr_val = get_attr(attr_elem, "VALUE")
                        if attr_name == "Lookup table name" and attr_val:
                            info.lookup_tables[trans_name.lower()] = attr_val
                        elif attr_name == "Lookup condition" and attr_val:
                            info.lookup_conditions[trans_name.lower()] = attr_val

            # Capture transformation types from INSTANCE elements for
            # reusable transformations (e.g. Custom Transformation) that don't
            # have their own TRANSFORMATION definition inside the MAPPLET.
            for inst_elem in mapplet_elem.findall("INSTANCE"):
                inst_name = get_attr(inst_elem, "NAME")
                inst_type = get_attr(inst_elem, "TRANSFORMATION_TYPE")
                if inst_name and inst_type:
                    inst_key = inst_name.lower()
                    if inst_key not in info.transformation_types:
                        info.transformation_types[inst_key] = inst_type

            # Parse internal connectors
            for conn_elem in mapplet_elem.findall("CONNECTOR"):
                from_inst = get_attr(conn_elem, "FROMINSTANCE")
                from_field = get_attr(conn_elem, "FROMFIELD")
                to_inst = get_attr(conn_elem, "TOINSTANCE")
                to_field = get_attr(conn_elem, "TOFIELD")
                if from_inst and from_field and to_inst and to_field:
                    info.connectors[(to_inst.lower(), to_field.lower())] = (
                        from_inst, from_field
                    )

            mapplets[name.lower()] = info
            logger.debug(f"Parsed mapplet '{name}': {len(info.transformations)} transformations, {len(info.connectors)} connectors")

        return mapplets

    @staticmethod
    def _resolve_name(name: str, shortcuts: Dict[str, str]) -> str:
        """Resolve an instance name to its actual definition name.

        Tries, in order:
        1. Shortcut map lookup
        2. Strip ``sc_`` prefix
        3. Strip ``shortcut_to_`` prefix
        4. Return as-is
        """
        name_lower = name.lower()
        # Direct shortcut resolution
        if name_lower in shortcuts:
            return shortcuts[name_lower].lower()
        # Common prefixes
        if name_lower.startswith("shortcut_to_"):
            return name_lower[12:]
        if name_lower.startswith("sc_"):
            return name_lower[3:]
        return name_lower

    def _link_sources_targets(
        self,
        mappings: List[Mapping],
        sources: List[Source],
        targets: List[Target],
        shortcuts: Optional[Dict[str, str]] = None,
    ) -> None:
        """
        Link sources and targets to their mappings based on instances.

        In Informatica XML, sources and targets are defined at folder level,
        and mappings reference them through INSTANCE elements.
        """
        shortcuts = shortcuts or {}
        # Build lookup dictionaries
        source_lookup = {s.name.lower(): s for s in sources}
        target_lookup = {t.name.lower(): t for t in targets}

        for mapping in mappings:
            mapping_sources = []
            mapping_targets = []

            for instance in mapping.instances:
                # Check if instance references a source
                if instance.is_source:
                    src_name = self._resolve_name(
                        instance.transformation_name, shortcuts
                    )
                    source = source_lookup.get(src_name)
                    if source and source not in mapping_sources:
                        mapping_sources.append(source)

                # Check if instance references a target
                elif instance.is_target:
                    tgt_name = self._resolve_name(
                        instance.transformation_name, shortcuts
                    )
                    target = target_lookup.get(tgt_name)
                    if target and target not in mapping_targets:
                        mapping_targets.append(target)

            mapping.sources = mapping_sources
            mapping.targets = mapping_targets

    def parse_string(self, xml_content: str) -> PowermartDocument:
        """
        Parse Informatica XML from a string.

        Args:
            xml_content: XML content as string

        Returns:
            PowermartDocument containing all parsed objects
        """
        root = DefusedET.fromstring(xml_content)
        return self.parse_element(root)