"""Parser for Informatica SESSION elements."""

import xml.etree.ElementTree as ET
from typing import List, Optional

from ..models.session_models import (
    Session,
    SessionTransformationInst,
    SessionExtension,
    SessionComponent,
    SessionAttribute,
    ConfigReference,
    ConnectionReference,
    Partition,
)
from ..utils.xml_utils import get_attr, get_attr_bool, get_attr_int, decode_xml_entities


class SessionParser:
    """Parser for Informatica SESSION elements."""

    def parse_session_attribute(self, element: ET.Element) -> SessionAttribute:
        """Parse an ATTRIBUTE element."""
        return SessionAttribute(
            name=get_attr(element, "NAME"),
            value=decode_xml_entities(get_attr(element, "VALUE")),
        )

    def parse_partition(self, element: ET.Element) -> Partition:
        """Parse a PARTITION element."""
        return Partition(
            name=get_attr(element, "NAME"),
            description=get_attr(element, "DESCRIPTION"),
        )

    def parse_connection_reference(self, element: ET.Element) -> ConnectionReference:
        """Parse a CONNECTIONREFERENCE element."""
        return ConnectionReference(
            cnx_ref_name=get_attr(element, "CNXREFNAME"),
            connection_name=get_attr(element, "CONNECTIONNAME"),
            connection_number=get_attr_int(element, "CONNECTIONNUMBER", 1),
            connection_type=get_attr(element, "CONNECTIONTYPE"),
            connection_subtype=get_attr(element, "CONNECTIONSUBTYPE"),
            variable=get_attr(element, "VARIABLE"),
        )

    def parse_session_transformation_inst(
        self, element: ET.Element
    ) -> SessionTransformationInst:
        """
        Parse a SESSTRANSFORMATIONINST element.

        XML Example:
        <SESSTRANSFORMATIONINST ISREPARTITIONPOINT="YES" PARTITIONTYPE="PASS THROUGH"
                                PIPELINE="1" SINSTANCENAME="Shortcut_to_TARGET"
                                STAGE="1" TRANSFORMATIONNAME="Shortcut_to_TARGET"
                                TRANSFORMATIONTYPE="Target Definition">
            <ATTRIBUTE NAME="Table Name Prefix" VALUE="$Param_target_owner"/>
            <PARTITION DESCRIPTION="" NAME="Partition #1"/>
        </SESSTRANSFORMATIONINST>
        """
        # Parse attributes
        attributes = []
        for attr_elem in element.findall("ATTRIBUTE"):
            attributes.append(self.parse_session_attribute(attr_elem))

        # Parse partitions
        partitions = []
        for part_elem in element.findall("PARTITION"):
            partitions.append(self.parse_partition(part_elem))

        return SessionTransformationInst(
            sinstance_name=get_attr(element, "SINSTANCENAME"),
            transformation_name=get_attr(element, "TRANSFORMATIONNAME"),
            transformation_type=get_attr(element, "TRANSFORMATIONTYPE"),
            stage=get_attr_int(element, "STAGE"),
            pipeline=get_attr_int(element, "PIPELINE"),
            is_repartition_point=get_attr_bool(element, "ISREPARTITIONPOINT"),
            partition_type=get_attr(element, "PARTITIONTYPE"),
            partitions=partitions,
            attributes=attributes,
        )

    def parse_session_extension(self, element: ET.Element) -> SessionExtension:
        """
        Parse a SESSIONEXTENSION element.

        XML Example:
        <SESSIONEXTENSION NAME="Relational Writer"
                          SINSTANCENAME="Shortcut_to_TARGET"
                          SUBTYPE="Relational Writer"
                          TRANSFORMATIONTYPE="Target Definition" TYPE="WRITER">
            <CONNECTIONREFERENCE CNXREFNAME="DB Connection"
                                 CONNECTIONNAME="" CONNECTIONNUMBER="1"
                                 CONNECTIONSUBTYPE="" CONNECTIONTYPE="Relational"
                                 VARIABLE="$DBConnection_target"/>
            <ATTRIBUTE NAME="Target load type" VALUE="Normal"/>
        </SESSIONEXTENSION>
        """
        # Parse connections
        connections = []
        for conn_elem in element.findall("CONNECTIONREFERENCE"):
            connections.append(self.parse_connection_reference(conn_elem))

        # Parse attributes
        attributes = []
        for attr_elem in element.findall("ATTRIBUTE"):
            attributes.append(self.parse_session_attribute(attr_elem))

        return SessionExtension(
            name=get_attr(element, "NAME"),
            sinstance_name=get_attr(element, "SINSTANCENAME"),
            extension_type=get_attr(element, "TYPE"),
            subtype=get_attr(element, "SUBTYPE"),
            transformation_type=get_attr(element, "TRANSFORMATIONTYPE"),
            dsq_inst_name=get_attr(element, "DSQINSTNAME"),
            dsq_inst_type=get_attr(element, "DSQINSTTYPE"),
            connections=connections,
            attributes=attributes,
        )

    def parse_session_component(self, element: ET.Element) -> SessionComponent:
        """
        Parse a SESSIONCOMPONENT element.

        XML Example:
        <SESSIONCOMPONENT REFOBJECTNAME="eml_OnFailure" REUSABLE="YES"
                          TYPE="Failure Email"/>
        <SESSIONCOMPONENT REFOBJECTNAME="presession_variable_assignment"
                          REUSABLE="NO" TYPE="Pre-session variable assignment">
            <TASK ... />
        </SESSIONCOMPONENT>
        """
        # Parse embedded task if present
        task_name = ""
        task_type = ""
        attributes = []
        value_pairs = []

        task_elem = element.find("TASK")
        if task_elem is not None:
            task_name = get_attr(task_elem, "NAME")
            task_type = get_attr(task_elem, "TYPE")
            for attr_elem in task_elem.findall("ATTRIBUTE"):
                attributes.append(self.parse_session_attribute(attr_elem))
            # Parse VALUEPAIR elements (command steps, variable assignments)
            for vp_elem in task_elem.findall("VALUEPAIR"):
                value_pairs.append({
                    "exec_order": get_attr(vp_elem, "EXECORDER"),
                    "name": get_attr(vp_elem, "NAME"),
                    "value": decode_xml_entities(get_attr(vp_elem, "VALUE")),
                    "reverse_assignment": get_attr(vp_elem, "REVERSEASSIGNMENT", "NO"),
                })

        # Also parse VALUEPAIR elements that are direct children of the
        # SESSIONCOMPONENT (not inside TASK).  Variable assignments like
        # $$FROM_CLAUSE = $$DEDUP_SQL_IN live here.
        for vp_elem in element.findall("VALUEPAIR"):
            value_pairs.append({
                "exec_order": get_attr(vp_elem, "EXECORDER"),
                "name": get_attr(vp_elem, "NAME"),
                "value": decode_xml_entities(get_attr(vp_elem, "VALUE")),
                "reverse_assignment": get_attr(vp_elem, "REVERSEASSIGNMENT", "NO"),
            })

        return SessionComponent(
            ref_object_name=get_attr(element, "REFOBJECTNAME"),
            component_type=get_attr(element, "TYPE"),
            reusable=get_attr_bool(element, "REUSABLE"),
            task_name=task_name,
            task_type=task_type,
            attributes=attributes,
            value_pairs=value_pairs,
        )

    def parse_config_reference(self, element: ET.Element) -> ConfigReference:
        """Parse a CONFIGREFERENCE element."""
        return ConfigReference(
            ref_object_name=get_attr(element, "REFOBJECTNAME"),
            config_type=get_attr(element, "TYPE"),
        )

    def parse_session(self, element: ET.Element) -> Session:
        """
        Parse a SESSION element.

        XML Example:
        <SESSION DESCRIPTION="..." ISVALID="YES"
                 MAPPINGNAME="m_GL_Generate_BatchHeader"
                 NAME="s_GL_Generate_BatchHeader" REUSABLE="NO"
                 SORTORDER="Binary" VERSIONNUMBER="9">
            <SESSTRANSFORMATIONINST ... />
            <CONFIGREFERENCE ... />
            <SESSIONCOMPONENT ... />
            <SESSIONEXTENSION ... />
            <ATTRIBUTE ... />
        </SESSION>
        """
        # Parse transformation instances
        transformation_insts = []
        for ti_elem in element.findall("SESSTRANSFORMATIONINST"):
            transformation_insts.append(self.parse_session_transformation_inst(ti_elem))

        # Parse session extensions
        extensions = []
        for ext_elem in element.findall("SESSIONEXTENSION"):
            extensions.append(self.parse_session_extension(ext_elem))

        # Parse session components
        components = []
        for comp_elem in element.findall("SESSIONCOMPONENT"):
            components.append(self.parse_session_component(comp_elem))

        # Parse config references
        config_refs = []
        for cfg_elem in element.findall("CONFIGREFERENCE"):
            config_refs.append(self.parse_config_reference(cfg_elem))

        # Parse session-level attributes
        attributes = []
        for attr_elem in element.findall("ATTRIBUTE"):
            attributes.append(self.parse_session_attribute(attr_elem))

        return Session(
            name=get_attr(element, "NAME"),
            description=get_attr(element, "DESCRIPTION"),
            mapping_name=get_attr(element, "MAPPINGNAME"),
            is_valid=get_attr_bool(element, "ISVALID", True),
            reusable=get_attr_bool(element, "REUSABLE"),
            sort_order=get_attr(element, "SORTORDER", "Binary"),
            version_number=get_attr_int(element, "VERSIONNUMBER", 1),
            transformation_insts=transformation_insts,
            extensions=extensions,
            components=components,
            config_refs=config_refs,
            attributes=attributes,
        )

    def parse_all(self, root: ET.Element) -> List[Session]:
        """
        Parse all SESSION elements from the XML.

        Args:
            root: Root element of the XML

        Returns:
            List of Session objects
        """
        sessions = []
        for session_elem in root.iter("SESSION"):
            sessions.append(self.parse_session(session_elem))
        return sessions
