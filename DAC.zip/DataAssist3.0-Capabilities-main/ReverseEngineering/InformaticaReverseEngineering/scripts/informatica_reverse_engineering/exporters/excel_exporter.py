"""Excel exporter for lineage results."""

from pathlib import Path
from typing import Any, Dict, List, Optional, Union
import json

from ..models.lineage_models import LineageResult, EndToEndFieldLineage
from ..parsers.powermart_parser import PowermartDocument
from werkzeug.utils import safe_join
from ..utils.logging_config import get_logger
from ..utils.path_utils import sanitize_csv_value

logger = get_logger("excel_exporter")

try:
    from openpyxl import Workbook
    from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
    from openpyxl.utils import get_column_letter
    OPENPYXL_AVAILABLE = True
except ImportError:
    OPENPYXL_AVAILABLE = False
    logger.warning("openpyxl not installed. Excel export will use CSV fallback.")


def _safe_cell(ws, row, column, value):
    """Write a value to a cell with formula injection protection."""
    return ws.cell(row=row, column=column, value=sanitize_csv_value(value))


class ExcelExporter:
    """Exports lineage results to Excel format."""

    def __init__(self):
        self.header_font = None
        self.header_fill = None
        self.border = None

        if OPENPYXL_AVAILABLE:
            self.header_font = Font(bold=True, color="FFFFFF")
            self.header_fill = PatternFill(start_color="4472C4", end_color="4472C4", fill_type="solid")
            self.border = Border(
                left=Side(style='thin'),
                right=Side(style='thin'),
                top=Side(style='thin'),
                bottom=Side(style='thin')
            )

    def export(
        self,
        lineage_result: LineageResult,
        document: PowermartDocument,
        output_path: Union[str, Path],
        integration_data: Optional[Dict] = None,
    ) -> str:
        """
        Export lineage results to Excel.

        Args:
            lineage_result: The lineage analysis result
            document: The original PowermartDocument
            output_path: Path for the output file
            integration_data: Optional additional data from integration expert

        Returns:
            Path to the created file
        """
        _raw = Path(output_path)
        output_path = Path(safe_join(str(_raw.parent), _raw.name))
        output_path.parent.mkdir(parents=True, exist_ok=True)

        if not OPENPYXL_AVAILABLE:
            # Fallback to CSV
            csv_path = output_path.with_suffix('.csv')
            return self._export_csv_fallback(lineage_result, csv_path)

        logger.info(f"Exporting lineage to Excel: {output_path}")

        wb = Workbook()

        # Remove default sheet
        wb.remove(wb.active)

        # Create sheets
        self._create_summary_sheet(wb, lineage_result, document)
        self._create_mapping_flow_summary_sheet(wb, document)
        self._create_lineage_sheet(wb, lineage_result)
        self._create_sources_sheet(wb, document)
        self._create_targets_sheet(wb, document, integration_data)
        self._create_transformations_sheet(wb, document, integration_data)
        self._create_expressions_sheet(wb, integration_data)
        self._create_lookups_sheet(wb, integration_data)
        self._create_filters_sheet(wb, integration_data)
        self._create_joiners_sheet(wb, integration_data)
        self._create_routers_sheet(wb, integration_data)
        self._create_stored_procedures_sheet(wb, document, integration_data)
        self._create_source_filters_sheet(wb, document, integration_data)
        self._create_sql_overrides_sheet(wb, integration_data)
        self._create_session_commands_sheet(wb, integration_data)
        self._create_session_metadata_sheet(wb, document, integration_data)
        self._create_target_load_order_sheet(wb, document, integration_data)
        self._create_worklets_sheet(wb, document)

        # Save workbook
        wb.save(output_path)
        logger.info(f"Excel export complete: {output_path}")

        return str(output_path)

    def export_per_mapping(
        self,
        lineage_result: LineageResult,
        document: PowermartDocument,
        output_dir: Union[str, Path],
        integration_data: Optional[Dict] = None,
    ) -> List[str]:
        """
        Export separate Excel files for each mapping in the document.

        Args:
            lineage_result: The lineage analysis result
            document: The original PowermartDocument
            output_dir: Directory for the output files
            integration_data: Optional additional data from integration expert

        Returns:
            List of paths to created files
        """
        output_dir = Path(output_dir)
        output_dir.mkdir(parents=True, exist_ok=True)

        if not OPENPYXL_AVAILABLE:
            logger.warning("openpyxl not available, skipping per-mapping export")
            return []

        created_files = []

        for mapping in document.mappings:
            mapping_name = mapping.name
            logger.info(f"Exporting lineage for mapping: {mapping_name}")

            # Filter lineage results for this mapping only
            mapping_lineages = self._filter_lineages_for_mapping(
                lineage_result, mapping, document
            )

            if not mapping_lineages:
                logger.warning(f"No lineage found for mapping: {mapping_name}")
                continue

            # Create a filtered LineageResult for this mapping
            from ..models.lineage_models import LineageResult as LR
            filtered_result = LR(
                mapping_name=mapping_name,
                source_count=len(mapping.sources) or len(mapping.source_instances),
                target_count=len(mapping.targets) or len(mapping.target_instances),
                transformation_count=len(mapping.transformations),
                field_lineages=mapping_lineages,
                lookup_tables=[lt for lt in lineage_result.lookup_tables 
                              if self._is_lookup_in_mapping(lt, mapping)],
                aggregators=[agg for agg in lineage_result.aggregators
                            if self._is_in_mapping(agg, mapping)],
                filters=[f for f in lineage_result.filters
                        if self._is_in_mapping(f, mapping)],
            )

            # Create workbook for this mapping
            wb = Workbook()
            wb.remove(wb.active)

            # Create a mini-document with just this mapping's data
            mini_doc = self._create_mini_document(document, mapping)

            # Store document reference for session filtering in _filter_integration_data_for_mapping
            self._current_document = document
            # Filter integration data for this mapping
            filtered_integration_data = self._filter_integration_data_for_mapping(
                integration_data, mapping_name
            )
            self._current_document = None

            # Create sheets
            self._create_mapping_summary_sheet(wb, filtered_result, mini_doc, mapping_name)
            self._create_lineage_sheet(wb, filtered_result)
            self._create_sources_sheet(wb, mini_doc)
            self._create_targets_sheet(wb, mini_doc, filtered_integration_data)
            self._create_transformations_sheet(wb, mini_doc, filtered_integration_data)
            self._create_expressions_sheet(wb, filtered_integration_data)
            self._create_lookups_sheet(wb, filtered_integration_data)
            self._create_filters_sheet(wb, filtered_integration_data)
            self._create_joiners_sheet(wb, filtered_integration_data)
            self._create_routers_sheet(wb, filtered_integration_data)
            self._create_stored_procedures_sheet(wb, mini_doc, filtered_integration_data)
            self._create_source_filters_sheet(wb, mini_doc, filtered_integration_data)
            self._create_session_commands_sheet(wb, filtered_integration_data)

            # Save workbook
            safe_name = "".join(c if c.isalnum() or c in ('_', '-') else '_' for c in mapping_name)
            output_path = output_dir / f"{safe_name}_lineage.xlsx"
            wb.save(output_path)
            created_files.append(str(output_path))
            logger.info(f"Created: {output_path}")

        return created_files

    def _filter_lineages_for_mapping(
        self, 
        lineage_result: LineageResult, 
        mapping, 
        document: PowermartDocument
    ) -> List[EndToEndFieldLineage]:
        """Filter lineage results to only include those from this mapping."""
        # Get all source and target names for this mapping
        mapping_sources = {src.name.lower() for src in mapping.sources}
        mapping_targets = {tgt.name.lower() for tgt in mapping.targets}
        
        # Also include instance names if sources/targets are empty
        if not mapping_targets:
            for inst in mapping.target_instances:
                mapping_targets.add(inst.transformation_name.lower())
        
        # Also look up the document-level targets that match
        for target in document.targets:
            target_lower = target.name.lower()
            for inst in mapping.target_instances:
                inst_lower = inst.transformation_name.lower()
                # Check if instance name matches target name (with or without prefixes)
                clean_inst = inst_lower.replace('sc_', '').replace('tgt_', '')
                if clean_inst in target_lower or target_lower in clean_inst:
                    mapping_targets.add(target_lower)
        
        # Filter lineages where target_table belongs to this mapping
        filtered = []
        for lineage in lineage_result.field_lineages:
            target_table = lineage.target_table.lower() if lineage.target_table else ""
            # Check if this lineage's target is in this mapping's targets
            if target_table in mapping_targets:
                filtered.append(lineage)
            # Also check if target matches any instance name pattern
            elif any(target_table.startswith(t) or t.startswith(target_table) for t in mapping_targets):
                filtered.append(lineage)
            # Check without prefixes
            elif any(target_table.replace('sc_', '').replace('tgt_', '') in t.replace('sc_', '').replace('tgt_', '') 
                    or t.replace('sc_', '').replace('tgt_', '') in target_table.replace('sc_', '').replace('tgt_', '')
                    for t in mapping_targets):
                filtered.append(lineage)
        
        return filtered

    def _is_lookup_in_mapping(self, lookup_name: str, mapping) -> bool:
        """Check if a lookup is used in this mapping."""
        lookup_lower = lookup_name.lower()
        for trans in mapping.transformations:
            if trans.transformation_type.upper() == "LOOKUP PROCEDURE" or "LOOKUP" in trans.transformation_type.upper():
                if trans.name.lower() == lookup_lower:
                    return True
        return False

    def _is_in_mapping(self, name: str, mapping) -> bool:
        """Check if a named element is in this mapping."""
        name_lower = name.lower()
        for trans in mapping.transformations:
            if trans.name.lower() == name_lower:
                return True
        return False

    def _create_mini_document(self, document: PowermartDocument, mapping) -> PowermartDocument:
        """Create a mini PowermartDocument containing only data from one mapping."""
        
        # Get relevant sources: either from mapping directly or from doc-level sources matching instances
        mapping_sources = list(mapping.sources)
        if not mapping_sources:
            # Find doc-level sources that match this mapping's source instances
            source_inst_names = {inst.transformation_name.lower() for inst in mapping.source_instances}
            for src in document.sources:
                src_lower = src.name.lower()
                for inst_name in source_inst_names:
                    # Check if instance name matches source (with common prefixes stripped)
                    clean_inst = inst_name.replace('sq_', '').replace('sc_', '').replace('src_', '')
                    if clean_inst in src_lower or src_lower in clean_inst:
                        mapping_sources.append(src)
                        break
        
        # Get relevant targets: either from mapping directly or from doc-level targets matching instances
        mapping_targets = list(mapping.targets)
        if not mapping_targets:
            # Find doc-level targets that match this mapping's target instances
            target_inst_names = {inst.transformation_name.lower() for inst in mapping.target_instances}
            for tgt in document.targets:
                tgt_lower = tgt.name.lower()
                for inst_name in target_inst_names:
                    clean_inst = inst_name.replace('sc_', '').replace('tgt_', '')
                    if clean_inst in tgt_lower or tgt_lower in clean_inst:
                        mapping_targets.append(tgt)
                        break
        
        # Create a new document with just this mapping's data
        mini_doc = PowermartDocument(
            creation_date=document.creation_date,
            repository_version=document.repository_version,
            repository=document.repository,
            folder=document.folder,
            sources=mapping_sources,
            targets=mapping_targets,
            transformations=mapping.transformations[:],  # Copy the mapping's transformations
            mappings=[mapping],
            sessions=[s for s in document.sessions if s.mapping_name == mapping.name],
            workflows=document.workflows,  # Keep workflows for context
            worklets=document.worklets,
            file_path=document.file_path
        )
        return mini_doc

    def _filter_integration_data_for_mapping(
        self, 
        integration_data: Optional[Dict], 
        mapping_name: str
    ) -> Optional[Dict]:
        """Filter integration data to only include data for a specific mapping."""
        if not integration_data:
            return None
        
        filtered = {"expert_results": {}}
        
        expert_results = integration_data.get("expert_results", {})
        
        # Filter FieldMapping data
        field_mapping = expert_results.get("FieldMapping", {}).get("data", {})
        if field_mapping:
            mapping_name_lower = mapping_name.lower()
            # Filter expressions for this mapping
            filtered_expressions = [
                e for e in field_mapping.get("expressions", [])
                if e.get("mapping_name", "").lower() == mapping_name_lower
            ]
            # Filter field_mappings for this mapping
            filtered_field_mappings = [
                fm for fm in field_mapping.get("field_mappings", [])
                if fm.get("mapping_name", "").lower() == mapping_name_lower
            ]
            # Filter unmapped_fields for this mapping
            filtered_unmapped = [
                u for u in field_mapping.get("unmapped_fields", [])
                if u.get("mapping", "").lower() == mapping_name_lower
            ]
            # Get lineage graph for this mapping
            lineage_graphs = field_mapping.get("lineage_graphs", {})
            mapping_graph = {mapping_name: lineage_graphs[mapping_name]} if mapping_name in lineage_graphs else {}
            
            filtered["expert_results"]["FieldMapping"] = {
                "data": {
                    "expressions": filtered_expressions,
                    "field_mappings": filtered_field_mappings,
                    "unmapped_fields": filtered_unmapped,
                    "lineage_graphs": mapping_graph,
                    "field_contexts": field_mapping.get("field_contexts", {}),
                    "statistics": {
                        "total_field_mappings": len(filtered_field_mappings),
                        "total_expressions": len(filtered_expressions),
                        "unmapped_field_count": len(filtered_unmapped),
                    },
                }
            }
        
        # Find associated session names for this mapping
        mapping_sessions = set()
        if hasattr(self, '_current_document') and self._current_document:
            for sess in self._current_document.sessions:
                if sess.mapping_name == mapping_name:
                    mapping_sessions.add(sess.name)
        
        mapping_name_lower = mapping_name.lower()
        
        # Filter MappingStructure data
        structure = expert_results.get("MappingStructure", {}).get("data", {})
        if structure:
            filtered["expert_results"]["MappingStructure"] = {
                "data": {
                    "sql_overrides": [s for s in structure.get("sql_overrides", []) 
                                     if s.get("mapping") == mapping_name],
                    "session_pre_sql": [s for s in structure.get("session_pre_sql", [])
                                       if not mapping_sessions or s.get("session", "") in mapping_sessions],
                    "session_post_sql": [s for s in structure.get("session_post_sql", [])
                                        if not mapping_sessions or s.get("session", "") in mapping_sessions],
                    "session_sql_overrides": [s for s in structure.get("session_sql_overrides", [])
                                             if not mapping_sessions or s.get("session", "") in mapping_sessions],
                    "source_table_overrides": [s for s in structure.get("source_table_overrides", [])
                                              if not mapping_sessions or s.get("session", "") in mapping_sessions],
                    "target_table_overrides": [s for s in structure.get("target_table_overrides", [])
                                              if not mapping_sessions or s.get("session", "") in mapping_sessions],
                    "table_name_prefixes": [s for s in structure.get("table_name_prefixes", [])
                                           if not mapping_sessions or s.get("session", "") in mapping_sessions],
                    "owner_name_overrides": [s for s in structure.get("owner_name_overrides", [])
                                            if not mapping_sessions or s.get("session", "") in mapping_sessions],
                    "source_filters": [s for s in structure.get("source_filters", [])
                                      if s.get("mapping", "").lower() == mapping_name_lower
                                      or s.get("session", "") in mapping_sessions],
                    "session_commands": [s for s in structure.get("session_commands", [])
                                        if s.get("session", "") in mapping_sessions],
                }
            }
        
        # Filter OperatorLogic data — use "mapping" key (not "mapping_name")
        operator = expert_results.get("OperatorLogic", {}).get("data", {})
        if operator:
            filtered["expert_results"]["OperatorLogic"] = {
                "data": {
                    "filters": [f for f in operator.get("filters", []) 
                               if f.get("mapping", f.get("mapping_name", "")).lower() == mapping_name_lower],
                    "lookups": [l for l in operator.get("lookups", []) 
                               if l.get("mapping", l.get("mapping_name", "")).lower() == mapping_name_lower],
                    "aggregators": [a for a in operator.get("aggregators", []) 
                                   if a.get("mapping", a.get("mapping_name", "")).lower() == mapping_name_lower],
                    "joiners": [j for j in operator.get("joiners", []) 
                               if j.get("mapping", j.get("mapping_name", "")).lower() == mapping_name_lower],
                    "routers": [r for r in operator.get("routers", []) 
                               if r.get("mapping", r.get("mapping_name", "")).lower() == mapping_name_lower],
                    "stored_procedures": [sp for sp in operator.get("stored_procedures", [])
                                         if sp.get("mapping", "").lower() == mapping_name_lower
                                         or sp.get("mapping", "") == "(Reusable)"],
                    "source_filters": [sf for sf in operator.get("source_filters", [])
                                      if sf.get("mapping", "").lower() == mapping_name_lower],
                }
            }
        
        return filtered

    def _create_mapping_summary_sheet(self, wb, lineage_result: LineageResult, document: PowermartDocument, mapping_name: str):
        """Create summary sheet for a single mapping."""
        ws = wb.create_sheet("Summary")

        # Add summary data
        data = [
            [f"Mapping Lineage: {mapping_name}", ""],
            ["", ""],
            ["Document Information", ""],
            ["File", document.file_path or "N/A"],
            ["Creation Date", document.creation_date],
            ["Repository", document.repository.name if document.repository else "N/A"],
            ["Folder", document.folder.name if document.folder else "N/A"],
            ["", ""],
            ["Mapping Statistics", ""],
            ["Sources", lineage_result.source_count],
            ["Targets", lineage_result.target_count],
            ["Transformations", lineage_result.transformation_count],
            ["Field Lineages", len(lineage_result.field_lineages)],
            ["Lookup Tables", len(lineage_result.lookup_tables)],
            ["Filters", len(lineage_result.filters)],
        ]

        for row_idx, row_data in enumerate(data, 1):
            for col_idx, value in enumerate(row_data, 1):
                cell = _safe_cell(ws, row_idx, col_idx, value)
                if col_idx == 1 and value:
                    cell.font = Font(bold=True)

        ws.column_dimensions['A'].width = 25
        ws.column_dimensions['B'].width = 50

    def _create_summary_sheet(self, wb, lineage_result: LineageResult, document: PowermartDocument):
        """Create summary sheet."""
        ws = wb.create_sheet("Summary")

        # Add summary data
        data = [
            ["Informatica Lineage Analysis Summary", ""],
            ["", ""],
            ["Document Information", ""],
            ["File", document.file_path or "N/A"],
            ["Creation Date", document.creation_date],
            ["Repository", document.repository.name if document.repository else "N/A"],
            ["Folder", document.folder.name if document.folder else "N/A"],
            ["Folder Owner", document.folder.owner if document.folder else "N/A"],
            ["", ""],
            ["Statistics", ""],
            ["Sources", lineage_result.source_count],
            ["Targets", lineage_result.target_count],
            ["Transformations", lineage_result.transformation_count],
            ["Field Lineages", len(lineage_result.field_lineages)],
            ["Lookup Tables", len(lineage_result.lookup_tables)],
            ["Aggregators", len(lineage_result.aggregators)],
            ["Filters", len(lineage_result.filters)],
            ["", ""],
            ["Coverage", f"{lineage_result.coverage_percentage:.1f}%"],
        ]

        for row_idx, row_data in enumerate(data, 1):
            for col_idx, value in enumerate(row_data, 1):
                cell = _safe_cell(ws, row_idx, col_idx, value)
                if col_idx == 1 and value:
                    cell.font = Font(bold=True)

        # Adjust column widths
        ws.column_dimensions['A'].width = 25
        ws.column_dimensions['B'].width = 50

    def _create_mapping_flow_summary_sheet(self, wb, document: PowermartDocument):
        """Create mapping flow summary sheet showing all mappings with sources, targets, and dependencies."""
        from ..utils.mapping_flow_utils import build_mapping_flow_summary

        ws = wb.create_sheet("Mapping Flow Summary")

        headers = [
            "Sequence", "Mapping Name", "Source Tables", "Target Tables", 
            "Depends On Mapping", "Session Name", "Workflow Name"
        ]

        for col_idx, header in enumerate(headers, 1):
            cell = ws.cell(row=1, column=col_idx, value=header)
            self._apply_header_style(cell)

        summary = build_mapping_flow_summary(document)

        row_idx = 2
        for entry in summary:
            deps = entry["depends_on_mapping"]
            _safe_cell(ws, row_idx,1, value=entry["sequence"])
            _safe_cell(ws, row_idx,2, value=entry["mapping_name"])
            _safe_cell(ws, row_idx,3, value=", ".join(entry["source_tables"]))
            _safe_cell(ws, row_idx,4, value=", ".join(entry["target_tables"]))
            _safe_cell(ws, row_idx,5, value=", ".join(deps) if deps else "-")
            _safe_cell(ws, row_idx,6, value=entry["session_name"] or "")
            _safe_cell(ws, row_idx,7, value=entry["workflow_name"] or "")
            row_idx += 1

        self._auto_adjust_columns(ws)
        ws.freeze_panes = "A2"

    def _create_lineage_sheet(self, wb, lineage_result: LineageResult):
        """Create source-to-target lineage sheet."""
        ws = wb.create_sheet("Source_to_Target_Lineage")

        headers = [
            "Mapping Name",
            "Target Table", "Target Field", "Target Datatype",
            "Ultimate Source Table", "Ultimate Source Field",
            "Transformation Logic", "Transformation Description",
            "End-to-End Dataflow",
            "Hop Count", "Lookup Tables",
            "Has Transformation", "Aggregation Applied", "Filter Applied",
            "Router Applied", "Router Condition", "SQL Override"
        ]

        # Write headers
        for col_idx, header in enumerate(headers, 1):
            cell = ws.cell(row=1, column=col_idx, value=header)
            self._apply_header_style(cell)

        # Write data
        for row_idx, lineage in enumerate(lineage_result.field_lineages, 2):
            row_data = lineage.to_row()
            for col_idx, header in enumerate(headers, 1):
                value = row_data.get(header, "")
                cell = _safe_cell(ws, row_idx, col_idx, value)
                # Enable text wrapping for the dataflow description column
                if header == "End-to-End Dataflow" and OPENPYXL_AVAILABLE:
                    cell.alignment = Alignment(wrap_text=True, vertical='top')

        # Auto-adjust column widths
        self._auto_adjust_columns(ws)

        # Set wider column for dataflow description
        ws.column_dimensions['I'].width = 80  # End-to-End Dataflow column (shifted by Mapping Name)

        # Freeze header row
        ws.freeze_panes = "A2"

    def _create_sources_sheet(self, wb, document: PowermartDocument):
        """Create sources sheet with Mapping Name association."""
        ws = wb.create_sheet("Sources")

        headers = ["Mapping Name", "Source Name", "Database", "Owner", "Field Name", "Datatype", "Key Type", "Nullable"]

        for col_idx, header in enumerate(headers, 1):
            cell = ws.cell(row=1, column=col_idx, value=header)
            self._apply_header_style(cell)

        # Build source-to-mapping lookup
        source_to_mappings: dict = {}
        for mapping in document.mappings:
            for inst in mapping.source_instances:
                inst_name = inst.transformation_name.lower() if hasattr(inst, 'transformation_name') else (inst.name.lower() if hasattr(inst, 'name') else "")
                if inst_name:
                    # Strip common prefixes to match source names
                    clean_inst = inst_name.replace('sq_', '').replace('sc_', '').replace('src_', '')
                    source_to_mappings.setdefault(inst_name, set()).add(mapping.name)
                    source_to_mappings.setdefault(clean_inst, set()).add(mapping.name)
            for src in mapping.sources:
                source_to_mappings.setdefault(src.name.lower(), set()).add(mapping.name)

        row_idx = 2
        for source in document.sources:
            # Find mapping names for this source
            src_lower = source.name.lower()
            mapping_names_set = source_to_mappings.get(src_lower, set())
            # Also try fuzzy match if exact match didn't work
            if not mapping_names_set:
                for key, names in source_to_mappings.items():
                    if key in src_lower or src_lower in key:
                        mapping_names_set = mapping_names_set | names
            mapping_names = ", ".join(sorted(mapping_names_set))
            for field in source.fields:
                _safe_cell(ws, row_idx,1, value=mapping_names)
                _safe_cell(ws, row_idx,2, value=source.name)
                _safe_cell(ws, row_idx,3, value=source.db_dname)
                _safe_cell(ws, row_idx,4, value=source.owner_name)
                _safe_cell(ws, row_idx,5, value=field.name)
                _safe_cell(ws, row_idx,6, value=field.full_datatype)
                _safe_cell(ws, row_idx,7, value=field.keytype)
                _safe_cell(ws, row_idx,8, value="Yes" if field.nullable else "No")
                row_idx += 1

        self._auto_adjust_columns(ws)
        ws.freeze_panes = "A2"

    def _create_targets_sheet(self, wb, document: PowermartDocument, integration_data: Optional[Dict] = None):
        """Create targets sheet."""
        ws = wb.create_sheet("Targets")

        headers = ["Mapping Name", "Target Name", "Database Type", "Field Name", "Datatype", "Key Type", "Nullable", "Load Order"]

        for col_idx, header in enumerate(headers, 1):
            cell = ws.cell(row=1, column=col_idx, value=header)
            self._apply_header_style(cell)

        # Build a lookup for target load order across all mappings
        target_load_positions = {}
        # Build a lookup mapping target name -> list of mapping names
        target_to_mappings = {}
        for mapping in document.mappings:
            if mapping.target_load_order:
                for idx, tgt_name in enumerate(mapping.target_load_order, 1):
                    target_load_positions[tgt_name.lower()] = idx
            # Associate targets with their mappings
            for tgt_inst in mapping.target_instances:
                inst_name = tgt_inst.transformation_name.lower() if hasattr(tgt_inst, 'transformation_name') else (tgt_inst.name.lower() if hasattr(tgt_inst, 'name') else "")
                if inst_name:
                    target_to_mappings.setdefault(inst_name, set()).add(mapping.name)
                    # Strip common prefixes to match document-level target names
                    clean = inst_name.replace('sc_to_', '').replace('sc_', '').replace('tgt_', '')
                    if clean != inst_name:
                        target_to_mappings.setdefault(clean, set()).add(mapping.name)
            for tgt in mapping.targets:
                tgt_key = tgt.name.lower()
                target_to_mappings.setdefault(tgt_key, set()).add(mapping.name)

        row_idx = 2
        for target in document.targets:
            load_order = target_load_positions.get(target.name.lower(), "")
            tgt_lower = target.name.lower()
            mapping_names_set = target_to_mappings.get(tgt_lower, set())
            if not mapping_names_set:
                for key, names in target_to_mappings.items():
                    if key in tgt_lower or tgt_lower in key:
                        mapping_names_set = mapping_names_set | names
            mapping_names = ", ".join(sorted(mapping_names_set))
            for field in target.fields:
                _safe_cell(ws, row_idx,1, value=mapping_names)
                _safe_cell(ws, row_idx,2, value=target.name)
                _safe_cell(ws, row_idx,3, value=target.database_type)
                _safe_cell(ws, row_idx,4, value=field.name)
                _safe_cell(ws, row_idx,5, value=field.full_datatype)
                _safe_cell(ws, row_idx,6, value=field.keytype)
                _safe_cell(ws, row_idx,7, value="Yes" if field.nullable else "No")
                _safe_cell(ws, row_idx,8, value=load_order)
                row_idx += 1

        self._auto_adjust_columns(ws)
        ws.freeze_panes = "A2"

    def _create_transformations_sheet(self, wb, document: PowermartDocument, integration_data: Optional[Dict]):
        """Create transformations sheet."""
        ws = wb.create_sheet("Transformations")

        headers = ["Mapping", "Transformation Name", "Type", "Reusable", "Input Count", "Output Count", "Has SQL Override"]

        for col_idx, header in enumerate(headers, 1):
            cell = ws.cell(row=1, column=col_idx, value=header)
            self._apply_header_style(cell)

        row_idx = 2
        for mapping in document.mappings:
            for trans in mapping.transformations:
                _safe_cell(ws, row_idx,1, value=mapping.name)
                _safe_cell(ws, row_idx,2, value=trans.name)
                _safe_cell(ws, row_idx,3, value=trans.type)
                _safe_cell(ws, row_idx,4, value="Yes" if trans.reusable else "No")
                _safe_cell(ws, row_idx,5, value=len(trans.input_fields))
                _safe_cell(ws, row_idx,6, value=len(trans.output_fields))
                _safe_cell(ws, row_idx,7, value="Yes" if trans.sql_query else "No")
                row_idx += 1

        self._auto_adjust_columns(ws)
        ws.freeze_panes = "A2"

    def _create_expressions_sheet(self, wb, integration_data: Optional[Dict]):
        """Create expressions sheet."""
        ws = wb.create_sheet("Expressions")

        headers = ["Mapping", "Transformation", "Field", "Port Type", "Expression", "Explanation"]

        for col_idx, header in enumerate(headers, 1):
            cell = ws.cell(row=1, column=col_idx, value=header)
            self._apply_header_style(cell)

        if integration_data:
            field_mapping_data = integration_data.get("expert_results", {}).get("FieldMapping", {}).get("data", {})
            expressions = field_mapping_data.get("expressions", [])

            row_idx = 2
            for expr in expressions:
                _safe_cell(ws, row_idx,1, value=expr.get("mapping_name", ""))
                _safe_cell(ws, row_idx,2, value=expr.get("transformation", ""))
                _safe_cell(ws, row_idx,3, value=expr.get("field_name", ""))
                _safe_cell(ws, row_idx,4, value=expr.get("port_type", ""))
                _safe_cell(ws, row_idx,5, value=expr.get("expression", ""))
                parsed = expr.get("parsed", {})
                _safe_cell(ws, row_idx,6, value=parsed.get("explanation", ""))
                row_idx += 1

        self._auto_adjust_columns(ws)
        ws.freeze_panes = "A2"

    def _create_lookups_sheet(self, wb, integration_data: Optional[Dict]):
        """Create lookups sheet."""
        ws = wb.create_sheet("Lookups")

        headers = ["Mapping", "Lookup Name", "Table Name", "Condition", "Caching", "Multiple Match Policy"]

        for col_idx, header in enumerate(headers, 1):
            cell = ws.cell(row=1, column=col_idx, value=header)
            self._apply_header_style(cell)

        if integration_data:
            operator_data = integration_data.get("expert_results", {}).get("OperatorLogic", {}).get("data", {})
            lookups = operator_data.get("lookups", [])

            row_idx = 2
            for lookup in lookups:
                _safe_cell(ws, row_idx,1, value=lookup.get("mapping", ""))
                _safe_cell(ws, row_idx,2, value=lookup.get("name", ""))
                _safe_cell(ws, row_idx,3, value=lookup.get("table_name", ""))
                _safe_cell(ws, row_idx,4, value=lookup.get("condition", ""))
                _safe_cell(ws, row_idx,5, value="Yes" if lookup.get("caching_enabled") else "No")
                _safe_cell(ws, row_idx,6, value=lookup.get("multiple_match_policy", ""))
                row_idx += 1

        self._auto_adjust_columns(ws)
        ws.freeze_panes = "A2"

    def _create_filters_sheet(self, wb, integration_data: Optional[Dict]):
        """Create filters sheet."""
        ws = wb.create_sheet("Filters")

        headers = ["Mapping", "Filter Name", "Condition", "Explanation"]

        for col_idx, header in enumerate(headers, 1):
            cell = ws.cell(row=1, column=col_idx, value=header)
            self._apply_header_style(cell)

        if integration_data:
            operator_data = integration_data.get("expert_results", {}).get("OperatorLogic", {}).get("data", {})
            filters = operator_data.get("filters", [])

            row_idx = 2
            for flt in filters:
                _safe_cell(ws, row_idx,1, value=flt.get("mapping", ""))
                _safe_cell(ws, row_idx,2, value=flt.get("name", ""))
                _safe_cell(ws, row_idx,3, value=flt.get("condition", ""))
                _safe_cell(ws, row_idx,4, value=flt.get("condition_explanation", ""))
                row_idx += 1

        self._auto_adjust_columns(ws)
        ws.freeze_panes = "A2"

    def _create_routers_sheet(self, wb, integration_data: Optional[Dict]):
        """Create routers sheet."""
        ws = wb.create_sheet("Routers")

        headers = ["Mapping", "Router Name", "Group Name", "Condition", "Explanation", "Is Default"]

        for col_idx, header in enumerate(headers, 1):
            cell = ws.cell(row=1, column=col_idx, value=header)
            self._apply_header_style(cell)

        if integration_data:
            operator_data = integration_data.get("expert_results", {}).get("OperatorLogic", {}).get("data", {})
            routers = operator_data.get("routers", [])

            row_idx = 2
            for router in routers:
                output_groups = router.get("output_groups", router.get("groups", []))
                for group in output_groups:
                    _safe_cell(ws, row_idx,1, value=router.get("mapping", ""))
                    _safe_cell(ws, row_idx,2, value=router.get("name", ""))
                    _safe_cell(ws, row_idx,3, value=group.get("name", ""))
                    _safe_cell(ws, row_idx,4, value=group.get("condition", ""))
                    _safe_cell(ws, row_idx,5, value=group.get("explanation", ""))
                    _safe_cell(ws, row_idx,6, value="Yes" if group.get("is_default") else "No")
                    row_idx += 1

        self._auto_adjust_columns(ws)
        ws.freeze_panes = "A2"

    def _create_joiners_sheet(self, wb, integration_data: Optional[Dict]):
        """Create joiners sheet showing joiner transformation details."""
        ws = wb.create_sheet("Joiners")

        headers = [
            "Mapping", "Joiner Name", "Join Condition", "Join Type",
            "Sorted Input", "Master Table", "Detail Table",
            "Input Fields", "Output Fields"
        ]

        for col_idx, header in enumerate(headers, 1):
            cell = ws.cell(row=1, column=col_idx, value=header)
            self._apply_header_style(cell)

        if integration_data:
            operator_data = integration_data.get("expert_results", {}).get("OperatorLogic", {}).get("data", {})
            joiners = operator_data.get("joiners", [])

            row_idx = 2
            for joiner in joiners:
                _safe_cell(ws, row_idx,1, value=joiner.get("mapping", ""))
                _safe_cell(ws, row_idx,2, value=joiner.get("name", ""))
                _safe_cell(ws, row_idx,3, value=joiner.get("join_condition", ""))
                _safe_cell(ws, row_idx,4, value=joiner.get("join_type", ""))
                _safe_cell(ws, row_idx,5, value=joiner.get("sorted_input", ""))
                _safe_cell(ws, row_idx,6, value=joiner.get("master_table", ""))
                _safe_cell(ws, row_idx,7, value=joiner.get("detail_table", ""))
                # Format field lists as comma-separated strings
                input_fields = joiner.get("input_fields", [])
                output_fields = joiner.get("output_fields", [])
                _safe_cell(ws, row_idx,8, value=", ".join(input_fields) if isinstance(input_fields, list) else str(input_fields))
                _safe_cell(ws, row_idx,9, value=", ".join(output_fields) if isinstance(output_fields, list) else str(output_fields))
                row_idx += 1

        self._auto_adjust_columns(ws)
        ws.freeze_panes = "A2"

    def _create_stored_procedures_sheet(self, wb, document: PowermartDocument, integration_data: Optional[Dict]):
        """Create stored procedures sheet showing SP transformation details."""
        ws = wb.create_sheet("Stored Procedures")

        headers = [
            "Mapping Name", "Mapping", "Transformation Name", "Stored Procedure Name",
            "Procedure Type", "Connection Information",
            "Call Text", "Execution Order",
            "Input Fields", "Output Fields"
        ]

        for col_idx, header in enumerate(headers, 1):
            cell = ws.cell(row=1, column=col_idx, value=header)
            self._apply_header_style(cell)

        # Build SP name -> mapping name(s) lookup from mapping instances
        sp_to_mappings: dict = {}
        for mapping in document.mappings:
            for inst in mapping.instances:
                inst_name_lower = inst.transformation_name.lower() if hasattr(inst, 'transformation_name') else inst.name.lower()
                if inst_name_lower:
                    sp_to_mappings.setdefault(inst_name_lower, set()).add(mapping.name)
                    # Also store with common prefixes stripped
                    clean = inst_name_lower.replace('sc_', '').replace('src_', '')
                    if clean != inst_name_lower:
                        sp_to_mappings.setdefault(clean, set()).add(mapping.name)

        if integration_data:
            operator_data = integration_data.get("expert_results", {}).get("OperatorLogic", {}).get("data", {})
            stored_procs = operator_data.get("stored_procedures", [])

            row_idx = 2
            for sp in stored_procs:
                sp_name_lower = sp.get("name", "").lower()
                mapping_names_set = sp_to_mappings.get(sp_name_lower, set())
                # Fuzzy fallback: check if SP name is contained in any instance name
                if not mapping_names_set:
                    for key, names in sp_to_mappings.items():
                        if sp_name_lower and (sp_name_lower in key or key in sp_name_lower):
                            mapping_names_set = mapping_names_set | names
                mapping_names = ", ".join(sorted(mapping_names_set))
                _safe_cell(ws, row_idx,1, value=mapping_names)
                _safe_cell(ws, row_idx,2, value=sp.get("mapping", ""))
                _safe_cell(ws, row_idx,3, value=sp.get("name", ""))
                _safe_cell(ws, row_idx,4, value=sp.get("procedure_name", ""))
                _safe_cell(ws, row_idx,5, value=sp.get("procedure_type", ""))
                _safe_cell(ws, row_idx,6, value=sp.get("connection_info", ""))
                _safe_cell(ws, row_idx,7, value=sp.get("call_text", ""))
                _safe_cell(ws, row_idx,8, value=sp.get("execution_order", ""))
                input_fields = sp.get("input_fields", [])
                output_fields = sp.get("output_fields", [])
                _safe_cell(ws, row_idx,9, value=", ".join(input_fields) if isinstance(input_fields, list) else str(input_fields))
                _safe_cell(ws, row_idx,10, value=", ".join(output_fields) if isinstance(output_fields, list) else str(output_fields))
                row_idx += 1

        self._auto_adjust_columns(ws)
        ws.freeze_panes = "A2"

    def _create_source_filters_sheet(self, wb, document: PowermartDocument, integration_data: Optional[Dict]):
        """Create source filters sheet showing SQ-level and session-level source filters."""
        ws = wb.create_sheet("Source Filters")

        headers = [
            "Mapping", "Source/Transformation", "Filter Source",
            "Source Filter"
        ]

        for col_idx, header in enumerate(headers, 1):
            cell = ws.cell(row=1, column=col_idx, value=header)
            self._apply_header_style(cell)

        row_idx = 2

        # Collect source filters from operator logic expert (SQ level)
        if integration_data:
            operator_data = integration_data.get("expert_results", {}).get("OperatorLogic", {}).get("data", {})
            source_filters = operator_data.get("source_filters", [])

            for sf in source_filters:
                _safe_cell(ws, row_idx,1, value=sf.get("mapping", ""))
                _safe_cell(ws, row_idx,2, value=sf.get("transformation", ""))
                _safe_cell(ws, row_idx,3, value="Source Qualifier")
                # Normalize CRLF/LF for clean display
                filter_text = sf.get("source_filter", "").replace("\r\n", " ").replace("\n", " ").strip()
                _safe_cell(ws, row_idx,4, value=filter_text)
                row_idx += 1

            # Collect source filters from session-level (mapping structure expert)
            structure_data = integration_data.get("expert_results", {}).get("MappingStructure", {}).get("data", {})
            session_source_filters = structure_data.get("source_filters", [])

            for sf in session_source_filters:
                _safe_cell(ws, row_idx,1, value=sf.get("mapping", sf.get("session", "")))
                _safe_cell(ws, row_idx,2, value=sf.get("instance", ""))
                _safe_cell(ws, row_idx,3, value="Session Extension")
                # Normalize CRLF/LF for clean display
                filter_text = sf.get("source_filter", "").replace("\r\n", " ").replace("\n", " ").strip()
                _safe_cell(ws, row_idx,4, value=filter_text)
                row_idx += 1

        # Also check source-level TABLEATTRIBUTE (for future XML files)
        for source in document.sources:
            for attr in getattr(source, 'table_attributes', []):
                if attr.get("name", "").lower() == "source filter" and attr.get("value"):
                    _safe_cell(ws, row_idx,1, value="")
                    _safe_cell(ws, row_idx,2, value=source.name)
                    _safe_cell(ws, row_idx,3, value="Source Definition")
                    # Normalize CRLF/LF for clean display
                    filter_text = attr.get("value", "").replace("\r\n", " ").replace("\n", " ").strip()
                    _safe_cell(ws, row_idx,4, value=filter_text)
                    row_idx += 1

        self._auto_adjust_columns(ws)
        ws.freeze_panes = "A2"

    def _create_session_commands_sheet(self, wb, integration_data: Optional[Dict]):
        """Create session commands sheet showing pre/post session commands and variable assignments."""
        ws = wb.create_sheet("Session Commands")

        headers = [
            "Session Name", "Component Name", "Component Type",
            "Exec Order", "Variable/Command Name", "Value"
        ]

        for col_idx, header in enumerate(headers, 1):
            cell = ws.cell(row=1, column=col_idx, value=header)
            self._apply_header_style(cell)

        if integration_data:
            structure_data = integration_data.get("expert_results", {}).get("MappingStructure", {}).get("data", {})
            session_commands = structure_data.get("session_commands", [])

            row_idx = 2
            for cmd in session_commands:
                value_pairs = cmd.get("value_pairs", [])
                if value_pairs:
                    for vp in value_pairs:
                        _safe_cell(ws, row_idx,1, value=cmd.get("session", ""))
                        _safe_cell(ws, row_idx,2, value=cmd.get("component_name", ""))
                        _safe_cell(ws, row_idx,3, value=cmd.get("component_type", ""))
                        _safe_cell(ws, row_idx,4, value=vp.get("exec_order", ""))
                        _safe_cell(ws, row_idx,5, value=vp.get("name", ""))
                        _safe_cell(ws, row_idx,6, value=vp.get("value", ""))
                        row_idx += 1
                else:
                    # Write component even if no value pairs (show attributes instead)
                    attributes = cmd.get("attributes", {})
                    if attributes:
                        for attr_name, attr_value in attributes.items():
                            _safe_cell(ws, row_idx,1, value=cmd.get("session", ""))
                            _safe_cell(ws, row_idx,2, value=cmd.get("component_name", ""))
                            _safe_cell(ws, row_idx,3, value=cmd.get("component_type", ""))
                            _safe_cell(ws, row_idx,4, value="")
                            _safe_cell(ws, row_idx,5, value=attr_name)
                            _safe_cell(ws, row_idx,6, value=attr_value)
                            row_idx += 1
                    else:
                        _safe_cell(ws, row_idx,1, value=cmd.get("session", ""))
                        _safe_cell(ws, row_idx,2, value=cmd.get("component_name", ""))
                        _safe_cell(ws, row_idx,3, value=cmd.get("component_type", ""))
                        row_idx += 1

        self._auto_adjust_columns(ws)
        ws.freeze_panes = "A2"

    def _create_sql_overrides_sheet(self, wb, integration_data: Optional[Dict]):
        """Create SQL overrides sheet."""
        ws = wb.create_sheet("SQL Overrides")

        headers = ["Mapping", "Transformation", "Type", "SQL Query"]

        for col_idx, header in enumerate(headers, 1):
            cell = ws.cell(row=1, column=col_idx, value=header)
            self._apply_header_style(cell)

        if integration_data:
            structure_data = integration_data.get("expert_results", {}).get("MappingStructure", {}).get("data", {})
            sql_overrides = structure_data.get("sql_overrides", [])

            row_idx = 2
            for sq in sql_overrides:
                _safe_cell(ws, row_idx,1, value=sq.get("mapping", ""))
                _safe_cell(ws, row_idx,2, value=sq.get("transformation", ""))
                _safe_cell(ws, row_idx,3, value=sq.get("type", "SQ"))
                _safe_cell(ws, row_idx,4, value=sq.get("sql_query", ""))
                row_idx += 1

        self._auto_adjust_columns(ws)
        ws.freeze_panes = "A2"

    def _create_session_metadata_sheet(self, wb, document: PowermartDocument, integration_data: Optional[Dict] = None):
        """Create session metadata sheet."""
        ws = wb.create_sheet("Session Metadata")

        headers = [
            "Session Name", "Mapping", "Instance", "Type",
            "Owner Name", "Source Table Name",
            "Pre SQL", "Post SQL", "SQL Override",
            "Source Table Override", "Target Table Name", "Table Name Prefix",
            "Connection"
        ]

        for col_idx, header in enumerate(headers, 1):
            cell = ws.cell(row=1, column=col_idx, value=header)
            self._apply_header_style(cell)

        if integration_data:
            structure_data = integration_data.get("expert_results", {}).get("MappingStructure", {}).get("data", {})

            row_idx = 2

            # Combine pre_sql, post_sql, sql_overrides, source_table_overrides
            # into per-extension rows
            session_metadata = {}

            for item in structure_data.get("session_pre_sql", []):
                key = (item.get("session", ""), item.get("instance", ""))
                if key not in session_metadata:
                    session_metadata[key] = {"session": item.get("session", ""), "instance": item.get("instance", ""), "type": item.get("type", "")}
                session_metadata[key]["pre_sql"] = item.get("sql", "")

            for item in structure_data.get("session_post_sql", []):
                key = (item.get("session", ""), item.get("instance", ""))
                if key not in session_metadata:
                    session_metadata[key] = {"session": item.get("session", ""), "instance": item.get("instance", ""), "type": item.get("type", "")}
                session_metadata[key]["post_sql"] = item.get("sql", "")

            for item in structure_data.get("session_sql_overrides", []):
                key = (item.get("session", ""), item.get("instance", ""))
                if key not in session_metadata:
                    session_metadata[key] = {"session": item.get("session", ""), "instance": item.get("instance", ""), "type": ""}
                session_metadata[key]["sql_override"] = item.get("sql", "")

            for item in structure_data.get("source_table_overrides", []):
                key = (item.get("session", ""), item.get("instance", ""))
                if key not in session_metadata:
                    session_metadata[key] = {"session": item.get("session", ""), "instance": item.get("instance", ""), "type": ""}
                session_metadata[key]["source_table_override"] = item.get("table_name", "")

            for item in structure_data.get("target_table_overrides", []):
                key = (item.get("session", ""), item.get("instance", ""))
                if key not in session_metadata:
                    session_metadata[key] = {"session": item.get("session", ""), "instance": item.get("instance", ""), "type": ""}
                session_metadata[key]["target_table_name"] = item.get("table_name", "")

            for item in structure_data.get("table_name_prefixes", []):
                key = (item.get("session", ""), item.get("instance", ""))
                if key not in session_metadata:
                    session_metadata[key] = {"session": item.get("session", ""), "instance": item.get("instance", ""), "type": ""}
                session_metadata[key]["table_name_prefix"] = item.get("prefix", "")

            # Add owner_name_overrides data
            for item in structure_data.get("owner_name_overrides", []):
                key = (item.get("session", ""), item.get("instance", ""))
                if key not in session_metadata:
                    session_metadata[key] = {"session": item.get("session", ""), "instance": item.get("instance", ""), "type": item.get("type", "")}
                session_metadata[key]["owner_name"] = item.get("owner_name", "")
                if item.get("source_table_name"):
                    session_metadata[key]["source_table_name"] = item.get("source_table_name", "")

            for meta in session_metadata.values():
                _safe_cell(ws, row_idx,1, value=meta.get("session", ""))
                _safe_cell(ws, row_idx,2, value="")  # mapping not directly available here
                _safe_cell(ws, row_idx,3, value=meta.get("instance", ""))
                _safe_cell(ws, row_idx,4, value=meta.get("type", ""))
                _safe_cell(ws, row_idx,5, value=meta.get("owner_name", ""))
                _safe_cell(ws, row_idx,6, value=meta.get("source_table_name", ""))
                _safe_cell(ws, row_idx,7, value=meta.get("pre_sql", ""))
                _safe_cell(ws, row_idx,8, value=meta.get("post_sql", ""))
                _safe_cell(ws, row_idx,9, value=meta.get("sql_override", ""))
                _safe_cell(ws, row_idx,10, value=meta.get("source_table_override", ""))
                _safe_cell(ws, row_idx,11, value=meta.get("target_table_name", ""))
                _safe_cell(ws, row_idx,12, value=meta.get("table_name_prefix", ""))
                _safe_cell(ws, row_idx,13, value=meta.get("connection", ""))
                row_idx += 1

        self._auto_adjust_columns(ws)
        ws.freeze_panes = "A2"

    def _create_target_load_order_sheet(self, wb, document: PowermartDocument, integration_data: Optional[Dict]):
        """Create target load order sheet."""
        ws = wb.create_sheet("Target Load Order")

        headers = ["Mapping", "Load Sequence", "Target Instance Name"]

        for col_idx, header in enumerate(headers, 1):
            cell = ws.cell(row=1, column=col_idx, value=header)
            self._apply_header_style(cell)

        row_idx = 2
        for mapping in document.mappings:
            if mapping.target_load_order:
                for seq, tgt_name in enumerate(mapping.target_load_order, 1):
                    _safe_cell(ws, row_idx,1, value=mapping.name)
                    _safe_cell(ws, row_idx,2, value=seq)
                    _safe_cell(ws, row_idx,3, value=tgt_name)
                    row_idx += 1

        self._auto_adjust_columns(ws)
        ws.freeze_panes = "A2"

    def _create_worklets_sheet(self, wb, document: PowermartDocument):
        """Create worklets sheet showing worklet details and their internal structure."""
        ws = wb.create_sheet("Worklets")

        headers = [
            "Worklet Name", "Description", "Is Valid",
            "Version", "Task Count", "Session Count", "Link Count",
            "Execution Order",
            "Task Name", "Task Type", "Task Description",
            "Session Name", "Session Mapping", "Session Description",
            "Link From", "Link To", "Link Condition"
        ]

        for col_idx, header in enumerate(headers, 1):
            cell = ws.cell(row=1, column=col_idx, value=header)
            self._apply_header_style(cell)

        row_idx = 2
        for worklet in document.worklets:
            exec_order = " -> ".join(worklet.get_execution_order()) if worklet.get_execution_order() else ""

            # Write a summary row for the worklet
            _safe_cell(ws, row_idx,1, value=worklet.name)
            _safe_cell(ws, row_idx,2, value=worklet.description)
            _safe_cell(ws, row_idx,3, value="Yes" if worklet.is_valid else "No")
            _safe_cell(ws, row_idx,4, value=worklet.version_number)
            _safe_cell(ws, row_idx,5, value=len(worklet.tasks))
            _safe_cell(ws, row_idx,6, value=len(worklet.sessions))
            _safe_cell(ws, row_idx,7, value=len(worklet.links))
            _safe_cell(ws, row_idx,8, value=exec_order)
            row_idx += 1

            # Write task rows
            for task in worklet.tasks:
                _safe_cell(ws, row_idx,1, value=worklet.name)
                _safe_cell(ws, row_idx,9, value=task.name)
                _safe_cell(ws, row_idx,10, value=task.task_type)
                _safe_cell(ws, row_idx,11, value=task.description)
                row_idx += 1

            # Write session rows
            for session in worklet.sessions:
                _safe_cell(ws, row_idx,1, value=worklet.name)
                _safe_cell(ws, row_idx,12, value=session.name)
                _safe_cell(ws, row_idx,13, value=session.mapping_name)
                _safe_cell(ws, row_idx,14, value=session.description)
                row_idx += 1

            # Write link rows
            for link in worklet.links:
                _safe_cell(ws, row_idx,1, value=worklet.name)
                _safe_cell(ws, row_idx,15, value=link.from_task)
                _safe_cell(ws, row_idx,16, value=link.to_task)
                _safe_cell(ws, row_idx,17, value=link.condition)
                row_idx += 1

        self._auto_adjust_columns(ws)
        ws.freeze_panes = "A2"

    def _apply_header_style(self, cell):
        """Apply header styling to a cell."""
        if OPENPYXL_AVAILABLE and self.header_font:
            cell.font = self.header_font
            cell.fill = self.header_fill
            cell.alignment = Alignment(horizontal='center', vertical='center')

    def _auto_adjust_columns(self, ws):
        """Auto-adjust column widths based on content."""
        if not OPENPYXL_AVAILABLE:
            return

        for column_cells in ws.columns:
            max_length = 0
            column = column_cells[0].column_letter
            for cell in column_cells:
                try:
                    if cell.value:
                        max_length = max(max_length, len(str(cell.value)))
                except:
                    pass
            adjusted_width = min(max_length + 2, 50)
            ws.column_dimensions[column].width = adjusted_width

    def _export_csv_fallback(self, lineage_result: LineageResult, output_path: Path) -> str:
        """Fallback CSV export when openpyxl is not available."""
        import csv

        with open(output_path, 'w', newline='', encoding='utf-8') as f:
            writer = csv.writer(f, quoting=csv.QUOTE_ALL)

            # Write headers
            headers = [
                "Mapping Name",
                "Target Table", "Target Field", "Target Datatype",
                "Ultimate Source Table", "Ultimate Source Field",
                "Transformation Logic", "Transformation Description",
                "End-to-End Dataflow",
                "Hop Count", "Lookup Tables"
            ]
            writer.writerow(headers)

            # Write data
            for lineage in lineage_result.field_lineages:
                row_data = lineage.to_row()
                row = [row_data.get(h, "") for h in headers]
                writer.writerow(row)

        logger.info(f"CSV fallback export complete: {output_path}")
        return str(output_path)
