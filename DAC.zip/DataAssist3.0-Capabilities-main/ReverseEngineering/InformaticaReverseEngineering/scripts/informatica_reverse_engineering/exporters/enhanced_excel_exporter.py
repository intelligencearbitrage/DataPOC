"""
Generate an enhanced Excel workbook from Informatica aggregated lineage output.

Sheet 1: Aggregated Lineage (the existing CSV output, unchanged)
Sheet 2: Expression Details
Sheet 3: Union Details
Sheet 4: Router Details
Sheet 5: Joiner Details
Sheet 6: Lookup Details
Sheet 7: Pre/Post SQL with STTM columns

All $Param_* placeholders are resolved using the provided parameter file.

Usage:
    python scripts/generate_enhanced_excel.py \
        --csv output/important_xml_eval_v2_v10/informatica_aggregated_lineage.csv \
        --input inputs/important_xml/ \
        --param-file inputs/important_xml/All_params.txt \
        -o output/important_xml_eval_v2_v10/informatica_enhanced_output.xlsx
"""

import argparse
import csv
import os
import re as _re
import sys
from pathlib import Path
from typing import Dict, List, Optional, Tuple

from ..parsers.powermart_parser import PowermartParser, PowermartDocument
from ..lineage.lineage_extractor import LineageExtractor
from ..utils.parameter_file_loader import ParameterFileLoader
from ..utils.logging_config import setup_logging, get_logger
from ..utils.path_utils import sanitize_path

try:
    from openpyxl import Workbook
    from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
except ImportError:
    print("ERROR: openpyxl is required. Install it with: pip install openpyxl")
    sys.exit(1)

logger = get_logger("generate_enhanced_excel")

# Styling
HEADER_FONT = Font(bold=True, color="FFFFFF")
HEADER_FILL = PatternFill(start_color="4472C4", end_color="4472C4", fill_type="solid")


def apply_header_style(cell):
    cell.font = HEADER_FONT
    cell.fill = HEADER_FILL
    cell.alignment = Alignment(horizontal="center", vertical="center")


def auto_adjust_columns(ws):
    for column_cells in ws.columns:
        max_length = 0
        column = column_cells[0].column_letter
        for cell in column_cells:
            try:
                if cell.value:
                    max_length = max(max_length, len(str(cell.value)))
            except Exception:
                pass
        ws.column_dimensions[column].width = min(max_length + 2, 60)


def resolve_text(text: str, param_loader: ParameterFileLoader, mapping_name: str = "") -> str:
    """Resolve $Param_* placeholders in text."""
    if not text or not param_loader.parameters:
        return text
    if mapping_name and hasattr(param_loader, "resolve_for_mapping"):
        return param_loader.resolve_for_mapping(text, mapping_name)
    return param_loader.resolve_placeholders(text)


def resolve_text_for_session(text: str, param_loader: ParameterFileLoader, session_name: str = "") -> str:
    """Resolve $Param_* placeholders using session-scoped params (Global + session override)."""
    if not text or not param_loader.parameters:
        return text
    if session_name and hasattr(param_loader, "resolve_for_session"):
        return param_loader.resolve_for_session(text, session_name)
    return param_loader.resolve_placeholders(text)


def collect_xml_files(input_paths: List[str]) -> List[Path]:
    """Collect XML files from input paths (files or directories)."""
    xml_files = []
    for inp in input_paths:
        p = Path(inp)
        if p.is_file() and p.suffix.lower() == ".xml":
            xml_files.append(p)
        elif p.is_dir():
            xml_files.extend(sorted(p.glob("*.xml")))
            xml_files.extend(sorted(p.glob("*.XML")))
    return list({f.resolve(): f for f in xml_files}.values())


def parse_all_documents(xml_files: List[Path]) -> List[PowermartDocument]:
    """Parse all XML files into PowermartDocument objects."""
    parser = PowermartParser()
    documents = []
    for xml_file in xml_files:
        try:
            doc = parser.parse_file(sanitize_path(xml_file))
            documents.append(doc)
            logger.info(f"Parsed: {xml_file.name} ({doc.mapping_count} mappings, {len(doc.sessions)} sessions)")
        except Exception as e:
            logger.error(f"Failed to parse {xml_file.name}: {e}")
    return documents


def load_param_file(param_paths: List[str], xml_files: List[Path]) -> ParameterFileLoader:
    """Load parameter file(s) into a ParameterFileLoader."""
    loader = ParameterFileLoader()
    import re
    for pf in param_paths:
        pf_path = sanitize_path(pf)
        if not pf_path.exists():
            logger.warning(f"Param file not found: {pf}")
            continue
        # Detect consolidated format (===== headers)
        is_consolidated = False
        try:
            with open(pf_path, "r", encoding="utf-8", errors="replace") as fp:
                for line in fp:
                    stripped = line.strip()
                    if stripped.startswith("=====") and stripped.endswith("====="):
                        is_consolidated = True
                        break
                    if stripped:
                        break
        except Exception:
            pass

        if is_consolidated:
            for xf in xml_files:
                wf_name = xf.stem
                loaded = loader.load_consolidated(pf_path, wf_name)
                if loaded:
                    logger.info(f"  Loaded {loaded} params for workflow '{wf_name}'")
        else:
            loader.load(pf_path)

    logger.info(f"Total parameters loaded: {len(loader.parameters)}")
    return loader


def build_mapping_to_sessions(documents: List[PowermartDocument]) -> Dict[str, List[str]]:
    """Build mapping_name (lower) -> [session_name, ...] lookup across all documents."""
    result: Dict[str, List[str]] = {}
    for doc in documents:
        for session in doc.sessions:
            key = session.mapping_name.lower() if session.mapping_name else ""
            if key:
                result.setdefault(key, []).append(session.name)
    return result


# ---------------------------------------------------------------
# Summary Sheet: XML metadata overview
# ---------------------------------------------------------------
def create_summary_sheet(
    wb: Workbook,
    documents: List[PowermartDocument],
    xml_files: List[Path],
):
    """Create a Summary sheet with XML metadata in label-value format."""
    ws = wb.create_sheet("Summary")
    label_font = Font(bold=True)

    row_idx = 1
    for doc in documents:
        file_path = doc.file_path or ""
        complete_path = str(Path(file_path).resolve()) if file_path else ""
        folder_name = doc.folder.name if doc.folder else ""
        folder_owner = doc.folder.owner if doc.folder else ""
        repo_name = doc.repository.name if doc.repository else ""
        creation_date = doc.creation_date or ""

        # Document Information section
        ws.cell(row=row_idx, column=1, value="Document Information").font = Font(bold=True, size=12)
        row_idx += 1

        file_name = Path(file_path).name if file_path else ""
        info_rows = [
            ("File Name", file_name),
            ("Complete Path", complete_path),
            ("Creation Date", creation_date),
            ("Repository", repo_name),
            ("Folder", folder_name),
            ("Folder Owner", folder_owner),
        ]
        for label, value in info_rows:
            ws.cell(row=row_idx, column=1, value=label).font = label_font
            ws.cell(row=row_idx, column=2, value=value)
            row_idx += 1

        row_idx += 1  # blank row

        # Workflow / Session / Mapping table
        wf_names = [w.name for w in doc.workflows] or [""]

        # Build session -> mapping pairs
        sess_mapping_pairs = []
        for s in doc.sessions:
            sess_mapping_pairs.append((s.name, s.mapping_name or ""))
        # Include worklet child sessions
        session_lookup = {s.name.lower(): s for s in doc.sessions}
        for w in doc.worklets:
            for wt in w.tasks:
                if wt.task_type.lower() == "session":
                    ws_name = wt.get_attribute("taskname") or wt.name
                    sess_obj = session_lookup.get(ws_name.lower())
                    if sess_obj and (sess_obj.name, sess_obj.mapping_name or "") not in sess_mapping_pairs:
                        sess_mapping_pairs.append((f"{w.name}/{sess_obj.name}", sess_obj.mapping_name or ""))

        if not sess_mapping_pairs:
            sess_mapping_pairs = [("", "")]

        # Table header
        for ci, header in enumerate(["Workflow", "Session", "Mapping"], 1):
            cell = ws.cell(row=row_idx, column=ci, value=header)
            apply_header_style(cell)
        row_idx += 1

        # Table rows
        for wf_name in wf_names:
            for sess_name, mapping_name in sess_mapping_pairs:
                ws.cell(row=row_idx, column=1, value=wf_name)
                ws.cell(row=row_idx, column=2, value=sess_name)
                ws.cell(row=row_idx, column=3, value=mapping_name)
                row_idx += 1

    auto_adjust_columns(ws)
    logger.info(f"Summary: {row_idx - 1} rows")


# ---------------------------------------------------------------
# Aggregated Lineage (CSV as-is)
# ---------------------------------------------------------------
def create_aggregated_lineage_sheet(wb: Workbook, csv_path: Path):
    """Read the aggregated CSV and write it as Sheet 1."""
    ws = wb.create_sheet("Aggregated Lineage")
    with open(csv_path, "r", encoding="utf-8") as f:
        reader = csv.reader(f)
        for row_idx, row in enumerate(reader, 1):
            for col_idx, value in enumerate(row, 1):
                cell = ws.cell(row=row_idx, column=col_idx, value=value)
                if row_idx == 1:
                    apply_header_style(cell)
    auto_adjust_columns(ws)
    ws.freeze_panes = "A2"


# ---------------------------------------------------------------
# Sheet 2: Expression Details
# ---------------------------------------------------------------
def create_expression_details_sheet(
    wb: Workbook,
    documents: List[PowermartDocument],
    mapping_to_sessions: Dict[str, List[str]],
    param_loader: ParameterFileLoader,
):
    ws = wb.create_sheet("Expression Details")
    headers = ["Session Name", "Expression Transformation Name", "Column Name",
               "Expression Used", "Input Field", "Output Field"]
    for col_idx, header in enumerate(headers, 1):
        apply_header_style(ws.cell(row=1, column=col_idx, value=header))

    row_idx = 2
    for doc in documents:
        for mapping in doc.mappings:
            session_names = ", ".join(mapping_to_sessions.get(mapping.name.lower(), []))
            # Mapping-level expression transformations
            for trans in mapping.transformations:
                if trans.type.lower() != "expression":
                    continue

                # Build connector lookups for this expression transformation
                in_map: Dict[str, str] = {}
                for c in mapping.get_connectors_to(trans.name):
                    in_map[c.to_field.lower()] = f"{c.from_instance}.{c.from_field}"
                out_map: Dict[str, List[str]] = {}
                for c in mapping.get_connectors_from(trans.name):
                    out_map.setdefault(c.from_field.lower(), []).append(
                        f"{c.to_instance}.{c.to_field}")

                for fld in trans.fields:
                    if not fld.has_expression:
                        continue
                    expr = resolve_text(fld.expression, param_loader, mapping.name)
                    input_field = in_map.get(fld.name.lower(), "")
                    output_fields = "; ".join(out_map.get(fld.name.lower(), []))
                    ws.cell(row=row_idx, column=1, value=session_names)
                    ws.cell(row=row_idx, column=2, value=trans.name)
                    ws.cell(row=row_idx, column=3, value=fld.name)
                    ws.cell(row=row_idx, column=4, value=expr)
                    ws.cell(row=row_idx, column=5, value=input_field)
                    ws.cell(row=row_idx, column=6, value=output_fields)
                    row_idx += 1

            # Mapplet internal expression transformations
            _seen_mapplets = set()
            for inst in mapping.instances:
                if "mapplet" not in inst.transformation_type.lower():
                    continue
                mplt_def_name = inst.transformation_name.lower()
                if mplt_def_name in _seen_mapplets:
                    continue
                _seen_mapplets.add(mplt_def_name)

                mplt_info = doc.mapplets.get(mplt_def_name)
                if not mplt_info:
                    continue

                for trans_name, trans_type in mplt_info.transformation_types.items():
                    if "expression" not in trans_type.lower():
                        continue
                    field_exprs = mplt_info.transformations.get(trans_name, {})
                    for field_name, expr_raw in field_exprs.items():
                        if not expr_raw:
                            continue
                        expr = resolve_text(expr_raw, param_loader, mapping.name)
                        display_name = f"{mplt_info.name}.{trans_name}"
                        ws.cell(row=row_idx, column=1, value=session_names)
                        ws.cell(row=row_idx, column=2, value=display_name)
                        ws.cell(row=row_idx, column=3, value=field_name)
                        ws.cell(row=row_idx, column=4, value=expr)
                        row_idx += 1

    auto_adjust_columns(ws)
    ws.freeze_panes = "A2"
    logger.info(f"Expression Details: {row_idx - 2} rows")


# ---------------------------------------------------------------
# Sheet 3: Union Details
# ---------------------------------------------------------------
def create_union_details_sheet(
    wb: Workbook,
    documents: List[PowermartDocument],
    mapping_to_sessions: Dict[str, List[str]],
    param_loader: ParameterFileLoader,
):
    ws = wb.create_sheet("Union Details")
    headers = ["Session Name", "Union Transformation Name", "Group Name", "Column Name"]
    for col_idx, header in enumerate(headers, 1):
        apply_header_style(ws.cell(row=1, column=col_idx, value=header))

    row_idx = 2
    for doc in documents:
        for mapping in doc.mappings:
            session_names = ", ".join(mapping_to_sessions.get(mapping.name.lower(), []))
            for trans in mapping.transformations:
                if trans.type.lower() not in ("union", "custom transformation"):
                    continue
                group_fields: Dict[str, List[str]] = {}
                for fld in trans.fields:
                    grp = fld.group if fld.group else "OUTPUT"
                    group_fields.setdefault(grp, []).append(fld.name)
                if not group_fields:
                    continue
                for grp_name, fields in group_fields.items():
                    for field_name in fields:
                        ws.cell(row=row_idx, column=1, value=session_names)
                        ws.cell(row=row_idx, column=2, value=trans.name)
                        ws.cell(row=row_idx, column=3, value=grp_name)
                        ws.cell(row=row_idx, column=4, value=field_name)
                        row_idx += 1

    auto_adjust_columns(ws)
    ws.freeze_panes = "A2"
    logger.info(f"Union Details: {row_idx - 2} rows")


# ---------------------------------------------------------------
# Sheet 4: Router Details
# ---------------------------------------------------------------
def create_router_details_sheet(
    wb: Workbook,
    documents: List[PowermartDocument],
    mapping_to_sessions: Dict[str, List[str]],
    param_loader: ParameterFileLoader,
):
    ws = wb.create_sheet("Router Details")
    headers = ["Session Name", "Router Name", "Group Name", "Group Condition", "Column Name"]
    for col_idx, header in enumerate(headers, 1):
        apply_header_style(ws.cell(row=1, column=col_idx, value=header))

    row_idx = 2
    for doc in documents:
        for mapping in doc.mappings:
            session_names = ", ".join(mapping_to_sessions.get(mapping.name.lower(), []))
            for trans in mapping.transformations:
                if trans.type.lower() != "router":
                    continue

                # Group conditions
                group_conditions: Dict[str, str] = {}
                for rg in trans.router_groups:
                    group_conditions[rg.name] = resolve_text(rg.expression, param_loader, mapping.name)
                for attr in trans.attributes:
                    if attr.name.lower().startswith("group ") or attr.name.lower().startswith("router group "):
                        group_conditions.setdefault(attr.name, resolve_text(attr.value, param_loader, mapping.name))

                # Group fields
                group_fields: Dict[str, List[str]] = {}
                for fld in trans.fields:
                    if not fld.is_output:
                        continue
                    grp = fld.group if fld.group else ""
                    if grp:
                        group_fields.setdefault(grp, []).append(fld.name)
                    else:
                        matched = False
                        for grp_name in group_conditions:
                            if grp_name.upper() in fld.name.upper():
                                group_fields.setdefault(grp_name, []).append(fld.name)
                                matched = True
                                break
                        if not matched:
                            for grp_name in group_conditions:
                                group_fields.setdefault(grp_name, []).append(fld.name)

                if not group_fields and group_conditions:
                    for grp_name, condition in group_conditions.items():
                        ws.cell(row=row_idx, column=1, value=session_names)
                        ws.cell(row=row_idx, column=2, value=trans.name)
                        ws.cell(row=row_idx, column=3, value=grp_name)
                        ws.cell(row=row_idx, column=4, value=condition)
                        ws.cell(row=row_idx, column=5, value="")
                        row_idx += 1
                else:
                    for grp_name, fields in group_fields.items():
                        condition = group_conditions.get(grp_name, "")
                        for field_name in fields:
                            ws.cell(row=row_idx, column=1, value=session_names)
                            ws.cell(row=row_idx, column=2, value=trans.name)
                            ws.cell(row=row_idx, column=3, value=grp_name)
                            ws.cell(row=row_idx, column=4, value=condition)
                            ws.cell(row=row_idx, column=5, value=field_name)
                            row_idx += 1

    auto_adjust_columns(ws)
    ws.freeze_panes = "A2"
    logger.info(f"Router Details: {row_idx - 2} rows")


# ---------------------------------------------------------------
# Sheet 5: Joiner Details
# ---------------------------------------------------------------
def _trace_joiner_source_table(
    mapping,
    joiner_name: str,
    port_names: set,
    param_loader: ParameterFileLoader,
) -> str:
    """Trace CONNECTOR tags backward from a joiner to find the originating source table.

    Follows the chain: source_instance -> ... -> joiner for the given ports,
    resolving the INSTANCE DBDNAME to a $Param_* placeholder.
    """
    from informatica_reverse_engineering.experts.integration_expert import IntegrationExpert

    # DBDNAME-to-$Param mapping (same as IntegrationExpert)
    dbdname_to_param = IntegrationExpert._DBDNAME_TO_PARAM

    joiner_lower = joiner_name.lower()
    port_names_lower = {p.lower() for p in port_names}

    # Find which instances feed into the joiner for these ports
    feeding_instances = set()
    for conn in mapping.connectors:
        if (conn.to_instance.lower() == joiner_lower and
                conn.to_field.lower() in port_names_lower):
            feeding_instances.add(conn.from_instance.lower())

    # Trace each feeding instance back to the ultimate source
    visited = set()
    queue = list(feeding_instances)
    source_tables = set()

    while queue:
        inst_name = queue.pop(0)
        if inst_name in visited:
            continue
        visited.add(inst_name)

        instance_obj = mapping.get_instance(inst_name)

        # Source Qualifiers (SQ_*) are transformations, not actual sources.
        # Skip through them to reach the real Source Definition instances.
        is_sq = (instance_obj and
                 "source qualifier" in (instance_obj.transformation_type or "").lower())

        # Check if this instance is a real source (Source Definition with db_dname)
        if instance_obj and instance_obj.is_source and not is_sq:
            # Resolve qualified name using DBDNAME
            table_name = instance_obj.transformation_name or instance_obj.name
            # Strip sc_ prefix to match source definition
            bare_name = table_name
            for prefix in ("sc_", "sq_", "src_"):
                if bare_name.lower().startswith(prefix):
                    bare_name = bare_name[len(prefix):]
                    break

            # Find source definition
            src_def = mapping.get_source(bare_name)
            if not src_def:
                src_def = mapping.get_source(table_name)

            if src_def:
                # Use DBDNAME from instance to derive $Param prefix
                db_dname = instance_obj.db_dname
                if db_dname:
                    param = dbdname_to_param.get(db_dname.lower())
                    if param:
                        resolved = resolve_text(param, param_loader, mapping.name)
                        source_tables.add(f"{resolved}.{src_def.name}")
                    else:
                        source_tables.add(f"{db_dname}.{src_def.name}")
                else:
                    source_tables.add(src_def.name)
            else:
                source_tables.add(table_name)
            continue

        # Not a real source (transformation or SQ) — trace further back
        for conn in mapping.connectors:
            if conn.to_instance.lower() == inst_name:
                if conn.from_instance.lower() not in visited:
                    queue.append(conn.from_instance.lower())

    return ", ".join(sorted(source_tables)) if source_tables else ""


def create_joiner_details_sheet(
    wb: Workbook,
    documents: List[PowermartDocument],
    mapping_to_sessions: Dict[str, List[str]],
    param_loader: ParameterFileLoader,
):
    ws = wb.create_sheet("Joiner Details")
    headers = [
        "Session Name", "Mapping Name", "Joiner Name",
        "Join Type", "Join Condition",
        "Master Table", "Detail Table",
        "Master Columns", "Detail Columns",
    ]
    for col_idx, header in enumerate(headers, 1):
        apply_header_style(ws.cell(row=1, column=col_idx, value=header))

    row_idx = 2
    for doc in documents:
        for mapping in doc.mappings:
            session_names = ", ".join(mapping_to_sessions.get(mapping.name.lower(), []))

            for trans in mapping.transformations:
                if trans.type.lower() != "joiner":
                    continue

                # Join Type and Condition from TABLEATTRIBUTE
                join_type = trans.get_attribute("Join Type") or ""
                join_condition = trans.get_attribute("Join Condition") or ""
                join_condition = resolve_text(join_condition, param_loader, mapping.name)

                # Separate master vs detail ports
                master_ports = []
                detail_ports = []
                for fld in trans.fields:
                    pt = fld.port_type.upper()
                    if "MASTER" in pt:
                        master_ports.append(fld.name)
                    elif fld.is_input and "OUTPUT" not in pt:
                        # Pure input (detail side)
                        detail_ports.append(fld.name)
                    elif "INPUT" in pt and "MASTER" not in pt:
                        # INPUT/OUTPUT without MASTER = detail
                        detail_ports.append(fld.name)

                # Trace master/detail ports back through connectors to source tables
                master_table = _trace_joiner_source_table(
                    mapping, trans.name, set(master_ports), param_loader
                )
                detail_table = _trace_joiner_source_table(
                    mapping, trans.name, set(detail_ports), param_loader
                )

                master_cols_str = ", ".join(master_ports)
                detail_cols_str = ", ".join(detail_ports)

                ws.cell(row=row_idx, column=1, value=session_names)
                ws.cell(row=row_idx, column=2, value=mapping.name)
                ws.cell(row=row_idx, column=3, value=trans.name)
                ws.cell(row=row_idx, column=4, value=join_type)
                ws.cell(row=row_idx, column=5, value=join_condition)
                ws.cell(row=row_idx, column=6, value=master_table)
                ws.cell(row=row_idx, column=7, value=detail_table)
                ws.cell(row=row_idx, column=8, value=master_cols_str)
                ws.cell(row=row_idx, column=9, value=detail_cols_str)
                row_idx += 1

    auto_adjust_columns(ws)
    ws.freeze_panes = "A2"
    logger.info(f"Joiner Details: {row_idx - 2} rows")


# ---------------------------------------------------------------
# Sheet 6: Lookup Details
# ---------------------------------------------------------------
def create_lookup_details_sheet(
    wb: Workbook,
    documents: List[PowermartDocument],
    mapping_to_sessions: Dict[str, List[str]],
    param_loader: ParameterFileLoader,
):
    import re as _re

    ws = wb.create_sheet("Lookup Details")
    headers = [
        "Session Name", "Mapping Name", "Lookup Name",
        "Lookup Table Name", "Lookup Condition",
        "Lookup SQL Override", "Lookup Input Lineage",
    ]
    for col_idx, header in enumerate(headers, 1):
        apply_header_style(ws.cell(row=1, column=col_idx, value=header))

    row_idx = 2
    for doc in documents:
        # Build session lookup: (mapping_lower, trans_name_lower) -> SessionTransformationInst
        sess_ti_map: Dict[tuple, object] = {}
        for wf in doc.workflows:
            for sess in wf.sessions:
                for ti in sess.transformation_insts:
                    key = (
                        (sess.mapping_name or "").lower(),
                        ti.transformation_name.lower(),
                    )
                    sess_ti_map[key] = ti

        for mapping in doc.mappings:
            session_names = ", ".join(mapping_to_sessions.get(mapping.name.lower(), []))

            for trans in mapping.transformations:
                ttype = trans.transformation_type
                ttype_str = ttype.value if hasattr(ttype, "value") else str(ttype)
                if "lookup" not in ttype_str.lower():
                    continue

                lkp_name = trans.name

                # --- Lookup table name (session override first) ---
                mapping_table = trans.get_attribute("Lookup table name") or ""
                session_table = ""
                ti = sess_ti_map.get((mapping.name.lower(), trans.name.lower()))
                if ti:
                    session_table = ti.get_attribute("Lookup table name") or ""
                lkp_table = session_table if session_table else mapping_table
                lkp_table = resolve_text(lkp_table, param_loader, mapping.name)

                # --- Lookup condition ---
                lkp_condition = trans.get_attribute("Lookup condition") or ""

                # --- Lookup SQL Override ---
                lkp_sql_override = trans.get_attribute("Lookup Sql Override") or ""
                lkp_sql_override = resolve_text(lkp_sql_override, param_loader, mapping.name)

                # --- Lookup Input Lineage ---
                # Identify condition input ports (RHS of each condition clause)
                _input_ports = {}
                for fld in trans.fields:
                    pt = fld.port_type
                    pt_str = (pt.value if hasattr(pt, "value") else str(pt or "")).upper()
                    if "INPUT" in pt_str:
                        _input_ports[fld.name.lower()] = fld.name

                _cond_input_fields = []
                for eq_part in _re.split(r"\bAND\b|\bOR\b", lkp_condition, flags=_re.IGNORECASE):
                    eq_part = eq_part.strip()
                    if "=" not in eq_part:
                        continue
                    sides = eq_part.split("=", 1)
                    if len(sides) != 2:
                        continue
                    lhs = sides[0].strip()
                    rhs = sides[1].strip()
                    if rhs.lower() in _input_ports:
                        _cond_input_fields.append(_input_ports[rhs.lower()])
                    elif lhs.lower() in _input_ports:
                        _cond_input_fields.append(_input_ports[lhs.lower()])

                # Trace connectors to find source for each condition input,
                # following pass-through (INPUT/OUTPUT) ports to the true origin.
                conns_to_lkp = mapping.get_connectors_to(lkp_name)
                conn_map = {}
                for c in conns_to_lkp:
                    conn_map[c.to_field.lower()] = (c.from_instance, c.from_field)

                _trans_by_name = {t.name.lower(): t for t in mapping.transformations}

                lineage_parts = []
                for input_port in _cond_input_fields:
                    conn = conn_map.get(input_port.lower())
                    if conn:
                        _from_inst, _from_field = conn
                        _via_parts = []
                        _visited = {lkp_name.lower()}
                        for _ in range(10):
                            _fi_lower = _from_inst.lower()
                            if _fi_lower in _visited:
                                break
                            _visited.add(_fi_lower)
                            _up_trans = _trans_by_name.get(_fi_lower)
                            if not _up_trans:
                                break
                            _is_passthrough = False
                            for _uf in _up_trans.fields:
                                if _uf.name.lower() == _from_field.lower():
                                    _pt = (_uf.port_type.value if hasattr(_uf.port_type, "value") else str(_uf.port_type or "")).upper()
                                    if "INPUT" in _pt and "OUTPUT" in _pt and "LOOKUP" not in _pt and "RETURN" not in _pt:
                                        _is_passthrough = True
                                    break
                            if not _is_passthrough:
                                break
                            _up_conns = mapping.get_connectors_to(_from_inst)
                            _up_conn_map = {uc.to_field.lower(): (uc.from_instance, uc.from_field) for uc in _up_conns}
                            _next = _up_conn_map.get(_from_field.lower())
                            if not _next:
                                break
                            _via_parts.append(_from_inst)
                            _from_inst, _from_field = _next

                        _src_desc = f"{_from_inst}.{_from_field}"
                        if _via_parts:
                            _src_desc += f" (via {', '.join(_via_parts)})"
                        lineage_parts.append(f"{input_port} <- {_src_desc}")
                    else:
                        lineage_parts.append(f"{input_port} <- (unresolved)")
                lkp_input_lineage = "; ".join(lineage_parts)

                ws.cell(row=row_idx, column=1, value=session_names)
                ws.cell(row=row_idx, column=2, value=mapping.name)
                ws.cell(row=row_idx, column=3, value=lkp_name)
                ws.cell(row=row_idx, column=4, value=lkp_table)
                ws.cell(row=row_idx, column=5, value=lkp_condition)
                ws.cell(row=row_idx, column=6, value=lkp_sql_override)
                ws.cell(row=row_idx, column=7, value=lkp_input_lineage)
                row_idx += 1

        # --- Lookups inside mapplets referenced by this mapping ---
        for mplt_key, mplt_info in doc.mapplets.items():
            for lkp_name_lower, lkp_condition in mplt_info.lookup_conditions.items():
                lkp_table = mplt_info.lookup_tables.get(lkp_name_lower, "")
                lkp_table = resolve_text(lkp_table, param_loader, mapping.name)

                lkp_sql_override = ""  # Mapplet lookups don't typically have separate SQL override in MappletInfo

                # Derive input lineage from mapplet connectors
                _input_fields = []
                for eq_part in _re.split(r"\bAND\b|\bOR\b", lkp_condition, flags=_re.IGNORECASE):
                    eq_part = eq_part.strip()
                    if "=" not in eq_part:
                        continue
                    sides = eq_part.split("=", 1)
                    if len(sides) != 2:
                        continue
                    lhs = sides[0].strip()
                    rhs = sides[1].strip()
                    # The input port is the one with in_ prefix or matching connectors
                    # In mapplet connectors, key is (to_instance, to_field) -> (from_instance, from_field)
                    rhs_conn = mplt_info.connectors.get((lkp_name_lower, rhs.lower()))
                    lhs_conn = mplt_info.connectors.get((lkp_name_lower, lhs.lower()))
                    if rhs_conn:
                        _input_fields.append(f"{rhs} <- {rhs_conn[0]}.{rhs_conn[1]}")
                    elif lhs_conn:
                        _input_fields.append(f"{lhs} <- {lhs_conn[0]}.{lhs_conn[1]}")

                lkp_input_lineage = "; ".join(_input_fields)

                # Use original case name from transformation_types
                lkp_display_name = lkp_name_lower
                for orig_name, ttype in mplt_info.transformation_types.items():
                    if orig_name == lkp_name_lower:
                        lkp_display_name = orig_name
                        break

                # Find original-case name from transformations dict keys
                for tname in mplt_info.transformations:
                    if tname == lkp_name_lower:
                        break

                ws.cell(row=row_idx, column=1, value=session_names)
                ws.cell(row=row_idx, column=2, value=f"{mapping.name} (mapplet: {mplt_info.name})")
                ws.cell(row=row_idx, column=3, value=lkp_display_name)
                ws.cell(row=row_idx, column=4, value=lkp_table)
                ws.cell(row=row_idx, column=5, value=lkp_condition)
                ws.cell(row=row_idx, column=6, value=lkp_sql_override)
                ws.cell(row=row_idx, column=7, value=lkp_input_lineage)
                row_idx += 1

    auto_adjust_columns(ws)
    ws.freeze_panes = "A2"
    logger.info(f"Lookup Details: {row_idx - 2} rows")


# ---------------------------------------------------------------
# Sheet 7: Pre/Post SQL with STTM
# ---------------------------------------------------------------
def _build_folder_tasks_lookup_for_excel(doc: PowermartDocument) -> Dict[str, List[Dict[str, str]]]:
    """Build a lookup of folder-level TASK elements and their VALUEPAIR children.

    Uses the document's file_path to parse the XML directly and extract
    VALUEPAIR data for reusable command tasks defined at the folder level.
    """
    import defusedxml.ElementTree as DefusedET

    lookup: Dict[str, List[Dict[str, str]]] = {}
    xml_path = getattr(doc, "file_path", None)
    if not xml_path:
        return lookup

    try:
        tree = DefusedET.parse(xml_path)
        root = tree.getroot()
        for folder_elem in root.iter("FOLDER"):
            for task_elem in folder_elem.findall("TASK"):
                task_name = task_elem.get("NAME", "")
                if not task_name:
                    continue
                value_pairs = []
                for vp_elem in task_elem.findall("VALUEPAIR"):
                    value_pairs.append({
                        "exec_order": vp_elem.get("EXECORDER", ""),
                        "name": vp_elem.get("NAME", ""),
                        "value": vp_elem.get("VALUE", ""),
                    })
                if value_pairs:
                    lookup[task_name] = value_pairs

            # Also check TASK elements inside WORKFLOW elements
            for wf_elem in folder_elem.findall("WORKFLOW"):
                for task_elem in wf_elem.findall("TASK"):
                    task_name = task_elem.get("NAME", "")
                    if not task_name or task_name in lookup:
                        continue
                    value_pairs = []
                    for vp_elem in task_elem.findall("VALUEPAIR"):
                        value_pairs.append({
                            "exec_order": vp_elem.get("EXECORDER", ""),
                            "name": vp_elem.get("NAME", ""),
                            "value": vp_elem.get("VALUE", ""),
                        })
                    if value_pairs:
                        lookup[task_name] = value_pairs
    except Exception as e:
        logger.warning(f"Could not parse XML for folder tasks lookup: {e}")

    return lookup


def create_pre_post_sql_sheet(
    wb: Workbook,
    documents: List[PowermartDocument],
    param_loader: ParameterFileLoader,
):
    ws = wb.create_sheet("Pre-Post SQL")
    headers = [
        "Session/Task Name", "Type", "Command/SQL",
        "Command Name", "Referenced Task", "Details",
        "Source Table", "Source Column",
        "Target Table", "Target Column",
        "Transformation Logic",
        "Join Condition", "Filter Condition",
    ]
    for col_idx, header in enumerate(headers, 1):
        apply_header_style(ws.cell(row=1, column=col_idx, value=header))

    row_idx = 2

    # Extract lineage per document for STTM
    extractor = LineageExtractor(parallel=False)

    for doc in documents:
        # Build folder-level tasks lookup for reusable command resolution
        folder_tasks_lookup = _build_folder_tasks_lookup_for_excel(doc)

        # Build session -> mapping lookup
        session_to_mapping: Dict[str, str] = {}
        for session in doc.sessions:
            if session.mapping_name:
                session_to_mapping[session.name] = session.mapping_name

        # Build set of sessions that belong to worklets (to avoid duplication)
        # Also register worklet display names in session_to_mapping for lineage lookup
        _worklet_session_names: set = set()
        for w in doc.worklets:
            for wt in w.tasks:
                if wt.task_type.lower() == "session":
                    _ws_name = wt.get_attribute("taskname") or wt.name
                    _worklet_session_names.add(_ws_name.lower())
                    _mapping = session_to_mapping.get(_ws_name, "")
                    if _mapping:
                        session_to_mapping[f"{w.name}/{_ws_name}"] = _mapping

        # Collect Pre/Post SQL from sessions (skip worklet sessions — handled below)
        sql_entries = []
        for session in doc.sessions:
            if session.name.lower() in _worklet_session_names:
                continue
            mapping_name = session.mapping_name or ""
            for item in session.all_pre_sql:
                sql_entries.append({
                    "session": session.name,
                    "mapping": mapping_name,
                    "sql_type": "Pre-SQL",
                    "sql": item.get("sql", ""),
                })
            for item in session.all_post_sql:
                sql_entries.append({
                    "session": session.name,
                    "mapping": mapping_name,
                    "sql_type": "Post-SQL",
                    "sql": item.get("sql", ""),
                })

        # Collect session commands from SESSIONCOMPONENT (skip worklet sessions)
        cmd_entries = []
        for session in doc.sessions:
            if session.name.lower() in _worklet_session_names:
                continue
            for comp in session.components:
                comp_type_lower = comp.component_type.lower()
                if "command" not in comp_type_lower:
                    continue

                # Determine the SQL Type label
                if "pre-session" in comp_type_lower:
                    cmd_sql_type = "Pre-Session Command"
                elif "success" in comp_type_lower:
                    cmd_sql_type = "Post-Session Success Command"
                elif "failure" in comp_type_lower:
                    cmd_sql_type = "Post-Session Failure Command"
                else:
                    cmd_sql_type = f"Session Command ({comp.component_type})"

                # Get value_pairs - from embedded task or folder-level lookup
                value_pairs = comp.value_pairs
                if comp.reusable and not value_pairs:
                    folder_vps = folder_tasks_lookup.get(comp.ref_object_name, [])
                    if folder_vps:
                        value_pairs = folder_vps

                if value_pairs:
                    for vp in value_pairs:
                        cmd_entries.append({
                            "session": session.name,
                            "sql_type": cmd_sql_type,
                            "command_name": vp.get("name", ""),
                            "command_value": vp.get("value", ""),
                            "referenced_task": comp.ref_object_name,
                        })
                else:
                    # No value pairs - just record the reference
                    cmd_entries.append({
                        "session": session.name,
                        "sql_type": cmd_sql_type,
                        "command_name": "",
                        "command_value": "",
                        "referenced_task": comp.ref_object_name,
                    })

        # Collect workflow-level tasks (Command, Email, Decision - not Session/Start)
        wf_task_entries = []
        skip_types = {"session", "start"}
        wf_task_seen = set()

        # Build worklet name -> worklet object lookup
        worklet_lookup = {w.name.lower(): w for w in doc.worklets}
        # Build session name -> session object lookup
        session_lookup = {s.name.lower(): s for s in doc.sessions}

        for wf in doc.workflows:
            for task in wf.tasks:
                task_type_lower = task.task_type.lower()
                if task_type_lower in skip_types:
                    continue
                if task.name in wf_task_seen:
                    continue
                wf_task_seen.add(task.name)

                # For worklet tasks, expand child sessions' pre/post SQL and commands
                if task_type_lower == "worklet":
                    taskname_ref = task.get_attribute("taskname") or task.name
                    worklet = worklet_lookup.get(taskname_ref.lower())
                    if worklet:
                        # Find session tasks inside the worklet
                        for wt_task in worklet.tasks:
                            if wt_task.task_type.lower() != "session":
                                continue
                            wt_sess_name = wt_task.get_attribute("taskname") or wt_task.name
                            sess_obj = session_lookup.get(wt_sess_name.lower())
                            if not sess_obj:
                                continue
                            display_name = f"{task.name}/{sess_obj.name}"

                            # Pre/Post SQL from session extensions and transformation insts
                            for item in sess_obj.all_pre_sql:
                                sql_entries.append({
                                    "session": display_name,
                                    "resolve_session": sess_obj.name,
                                    "mapping": sess_obj.mapping_name or "",
                                    "sql_type": "Pre-SQL",
                                    "sql": item.get("sql", ""),
                                })
                            for item in sess_obj.all_post_sql:
                                sql_entries.append({
                                    "session": display_name,
                                    "resolve_session": sess_obj.name,
                                    "mapping": sess_obj.mapping_name or "",
                                    "sql_type": "Post-SQL",
                                    "sql": item.get("sql", ""),
                                })

                            # Session commands from SESSIONCOMPONENT
                            for comp in sess_obj.components:
                                comp_type_lower_c = comp.component_type.lower()
                                if "command" not in comp_type_lower_c:
                                    continue
                                if "pre-session" in comp_type_lower_c:
                                    cmd_sql_type_c = "Pre-Session Command"
                                elif "success" in comp_type_lower_c:
                                    cmd_sql_type_c = "Post-Session Success Command"
                                elif "failure" in comp_type_lower_c:
                                    cmd_sql_type_c = "Post-Session Failure Command"
                                else:
                                    cmd_sql_type_c = f"Session Command ({comp.component_type})"

                                value_pairs_c = comp.value_pairs
                                if comp.reusable and not value_pairs_c:
                                    folder_vps_c = folder_tasks_lookup.get(comp.ref_object_name, [])
                                    if folder_vps_c:
                                        value_pairs_c = folder_vps_c

                                if value_pairs_c:
                                    for vp in value_pairs_c:
                                        cmd_entries.append({
                                            "session": display_name,
                                            "resolve_session": sess_obj.name,
                                            "sql_type": cmd_sql_type_c,
                                            "command_name": vp.get("name", ""),
                                            "command_value": vp.get("value", ""),
                                            "referenced_task": comp.ref_object_name,
                                        })
                                else:
                                    cmd_entries.append({
                                        "session": display_name,
                                        "resolve_session": sess_obj.name,
                                        "sql_type": cmd_sql_type_c,
                                        "command_name": "",
                                        "command_value": "",
                                        "referenced_task": comp.ref_object_name,
                                    })
                    continue

                wf_sql_type = f"Workflow {task.task_type} Task"

                # Look up folder-level task data for VALUEPAIR commands
                taskname_ref = task.get_attribute("taskname") or task.name
                folder_vps = folder_tasks_lookup.get(taskname_ref, [])

                if folder_vps:
                    for vp in folder_vps:
                        wf_task_entries.append({
                            "task_name": task.name,
                            "sql_type": wf_sql_type,
                            "command_name": vp.get("name", ""),
                            "command_value": vp.get("value", ""),
                            "referenced_task": taskname_ref if taskname_ref != task.name else "",
                            "details": task.description or "",
                        })
                else:
                    wf_task_entries.append({
                        "task_name": task.name,
                        "sql_type": wf_sql_type,
                        "command_name": "",
                        "command_value": "",
                        "referenced_task": taskname_ref if taskname_ref != task.name else "",
                        "details": task.description or "",
                    })

        has_any_data = sql_entries or cmd_entries or wf_task_entries
        if not has_any_data:
            continue

        # Extract lineage for STTM columns (only relevant for SQL entries)
        lineage_result = None
        if sql_entries:
            try:
                lineage_result = extractor.extract(doc)
            except Exception as e:
                logger.warning(f"Could not extract lineage for STTM: {e}")

        # Build session -> lineages
        session_lineages: Dict[str, list] = {}
        if lineage_result:
            for lineage in lineage_result.field_lineages:
                m_name = lineage.mapping_name
                for sess_name, map_name in session_to_mapping.items():
                    if map_name and map_name.lower() == m_name.lower():
                        session_lineages.setdefault(sess_name, []).append(lineage)

        # Collect join/filter conditions from mappings
        session_join_conditions: Dict[str, List[str]] = {}
        session_filter_conditions: Dict[str, List[str]] = {}
        for mapping in doc.mappings:
            mapping_lower = mapping.name.lower()
            sessions_for_mapping = [
                s for s, m in session_to_mapping.items()
                if m and m.lower() == mapping_lower
            ]
            for trans in mapping.transformations:
                t_lower = trans.type.lower()
                if t_lower == "joiner":
                    cond = ""
                    for attr in trans.attributes:
                        if attr.name.lower() == "join condition":
                            cond = attr.value
                            break
                    if not cond:
                        # Try from fields
                        for fld in trans.fields:
                            if fld.expression and "=" in fld.expression:
                                cond = fld.expression
                                break
                    if cond:
                        resolved_cond = resolve_text(cond, param_loader, mapping.name)
                        for sn in sessions_for_mapping:
                            session_join_conditions.setdefault(sn, []).append(
                                f"{trans.name}: {resolved_cond}"
                            )
                elif t_lower == "filter":
                    cond = ""
                    for fld in trans.fields:
                        if fld.has_expression:
                            cond = fld.expression
                            break
                    if cond:
                        resolved_cond = resolve_text(cond, param_loader, mapping.name)
                        for sn in sessions_for_mapping:
                            session_filter_conditions.setdefault(sn, []).append(
                                f"{trans.name}: {resolved_cond}"
                            )

        # Write SQL rows
        for sql_entry in sql_entries:
            sess_name = sql_entry["session"]
            sql_type = sql_entry["sql_type"]
            mapping_name = sql_entry["mapping"]
            resolve_sess = sql_entry.get("resolve_session", sess_name)
            sql_query = resolve_text_for_session(sql_entry["sql"], param_loader, resolve_sess)

            join_conds = "; ".join(session_join_conditions.get(sess_name, []))
            filter_conds = "; ".join(session_filter_conditions.get(sess_name, []))

            lineages = session_lineages.get(sess_name, [])
            if lineages:
                for lineage in lineages:
                    row_data = lineage.to_row()
                    ws.cell(row=row_idx, column=1, value=sess_name)
                    ws.cell(row=row_idx, column=2, value=sql_type)
                    ws.cell(row=row_idx, column=3, value=sql_query)
                    # Columns 4-5 (Command Name, Referenced Task) left empty for SQL rows
                    # Column 6 (Details) left empty for SQL rows
                    ws.cell(row=row_idx, column=7, value=resolve_text(row_data.get("Ultimate Source Table", ""), param_loader, mapping_name))
                    ws.cell(row=row_idx, column=8, value=resolve_text(row_data.get("Ultimate Source Field", ""), param_loader, mapping_name))
                    ws.cell(row=row_idx, column=9, value=resolve_text(row_data.get("Target Table", ""), param_loader, mapping_name))
                    ws.cell(row=row_idx, column=10, value=resolve_text(row_data.get("Target Field", ""), param_loader, mapping_name))
                    ws.cell(row=row_idx, column=11, value=resolve_text(row_data.get("Transformation Logic", ""), param_loader, mapping_name))
                    ws.cell(row=row_idx, column=12, value=join_conds)
                    ws.cell(row=row_idx, column=13, value=filter_conds)
                    row_idx += 1
            else:
                ws.cell(row=row_idx, column=1, value=sess_name)
                ws.cell(row=row_idx, column=2, value=sql_type)
                ws.cell(row=row_idx, column=3, value=sql_query)
                ws.cell(row=row_idx, column=12, value=join_conds)
                ws.cell(row=row_idx, column=13, value=filter_conds)
                row_idx += 1

        # Write session command rows
        for cmd_entry in cmd_entries:
            sess_name = cmd_entry["session"]
            resolve_sess = cmd_entry.get("resolve_session", sess_name)
            cmd_value = resolve_text_for_session(cmd_entry["command_value"], param_loader, resolve_sess)

            ws.cell(row=row_idx, column=1, value=sess_name)
            ws.cell(row=row_idx, column=2, value=cmd_entry["sql_type"])
            ws.cell(row=row_idx, column=3, value=cmd_value)
            ws.cell(row=row_idx, column=4, value=cmd_entry["command_name"])
            ws.cell(row=row_idx, column=5, value=cmd_entry["referenced_task"])
            row_idx += 1

        # Write workflow task rows
        for wf_entry in wf_task_entries:
            cmd_value = resolve_text(wf_entry["command_value"], param_loader)

            ws.cell(row=row_idx, column=1, value=wf_entry["task_name"])
            ws.cell(row=row_idx, column=2, value=wf_entry["sql_type"])
            ws.cell(row=row_idx, column=3, value=cmd_value)
            ws.cell(row=row_idx, column=4, value=wf_entry["command_name"])
            ws.cell(row=row_idx, column=5, value=wf_entry["referenced_task"])
            ws.cell(row=row_idx, column=6, value=wf_entry["details"])
            row_idx += 1

    auto_adjust_columns(ws)
    ws.freeze_panes = "A2"
    logger.info(f"Pre-Post SQL: {row_idx - 2} rows")


# ---------------------------------------------------------------------------
# BTEQ Details helpers
# ---------------------------------------------------------------------------

def _parse_bteq_script(script_content: str) -> Tuple[str, str]:
    """Split a shell/ksh script into its description block and the script body.

    The description block starts at the ``# Description:`` line and includes
    everything up to (but not including) the closing ``#---`` separator.
    This captures Description, Arguments, Returns, etc.

    The script body is everything after the last ``#---`` header separator.

    Returns:
        (description_block, script_body)
    """
    lines = script_content.splitlines()

    # --- Extract description block (from "# Description:" to next #---) ---
    desc_start = -1
    desc_end = -1
    for i, line in enumerate(lines):
        stripped = line.strip()
        if desc_start == -1:
            if stripped.lower().startswith("# description:"):
                desc_start = i
        else:
            if stripped.startswith("#---"):
                desc_end = i
                break

    if desc_start != -1:
        end = desc_end if desc_end != -1 else len(lines)
        desc_block = "\n".join(lines[desc_start:end]).rstrip()
    else:
        desc_block = ""

    # --- Extract script body (everything after the last #--- separator) ---
    last_separator_idx = -1
    for i, line in enumerate(lines):
        if line.strip().startswith("#---"):
            last_separator_idx = i

    if last_separator_idx == -1:
        return (desc_block, script_content.strip())

    body_start = last_separator_idx + 1
    while body_start < len(lines):
        stripped = lines[body_start].strip()
        if stripped == "#" or stripped == "":
            body_start += 1
        else:
            break

    body = "\n".join(lines[body_start:]).strip()
    return (desc_block, body)


def _collect_bteq_references(
    documents: List["PowermartDocument"],
    param_loader: "ParameterFileLoader" = None,
) -> List[dict]:
    """Scan parsed XML documents for .sh/.ksh script references.

    Looks in:
      - Session component VALUEPAIR values (pre/post session commands)
      - Workflow task VALUEPAIR values (command tasks)
      - Folder-level and workflow-level TASK VALUEPAIRs (via XML re-parse,
        same approach as _build_folder_tasks_lookup_for_excel)

    Parameter placeholders ($Param_*) are resolved before scanning so that
    commands like ``$Param_ETL_PROCESS_LOG_START`` which resolve to
    ``ksh /home/.../RUN_SQL.ksh ...`` are detected.

    Returns a list of dicts:
      {session_task_name, command_type, full_command, script_filename}
    """
    refs: List[dict] = []
    seen: set = set()  # (session_task_name, script_filename) dedup

    def _resolve(text: str, session_name: str = "") -> str:
        """Resolve $Param_* placeholders if a loader is available."""
        if not text or not param_loader or not param_loader.parameters:
            return text
        if session_name and hasattr(param_loader, "resolve_for_session"):
            return param_loader.resolve_for_session(text, session_name)
        return param_loader.resolve_placeholders(text)

    def _extract_script_refs(task_name: str, cmd_type: str, cmd_value: str):
        """Extract .sh/.ksh filenames from a command string and append to refs."""
        path_matches = _re.findall(r'[\w/\\.-]+\.(?:sh|ksh)\b', cmd_value, _re.IGNORECASE)
        for pm in path_matches:
            fname = Path(pm).name
            key = (task_name, fname)
            if key not in seen:
                seen.add(key)
                refs.append({
                    "session_task_name": task_name,
                    "command_type": cmd_type,
                    "full_command": cmd_value,
                    "script_filename": fname,
                })

    for doc in documents:
        # Build folder-level tasks lookup (re-parses XML to get VALUEPAIRs)
        folder_tasks_lookup = _build_folder_tasks_lookup_for_excel(doc)

        # --- Session components (pre/post session commands) ---
        for session in doc.sessions:
            for comp in session.components:
                comp_type_lower = comp.component_type.lower()
                if "command" not in comp_type_lower:
                    continue

                if "pre-session" in comp_type_lower:
                    cmd_type = "Pre-Session Command"
                elif "success" in comp_type_lower:
                    cmd_type = "Post-Session Success Command"
                elif "failure" in comp_type_lower:
                    cmd_type = "Post-Session Failure Command"
                else:
                    cmd_type = f"Session Command ({comp.component_type})"

                value_pairs = comp.value_pairs
                if comp.reusable and not value_pairs:
                    value_pairs = folder_tasks_lookup.get(comp.ref_object_name, [])

                for vp in value_pairs:
                    raw_value = vp.get("value", "")
                    resolved_value = _resolve(raw_value, session.name)
                    _extract_script_refs(session.name, cmd_type, resolved_value)

        # --- Workflow-level command tasks ---
        wf_task_seen: set = set()
        skip_types = {"session", "start"}
        for wf in doc.workflows:
            for task in getattr(wf, "tasks", []):
                task_type_lower = task.task_type.lower()
                if task_type_lower in skip_types:
                    continue
                if task.name in wf_task_seen:
                    continue
                wf_task_seen.add(task.name)

                wf_cmd_type = f"Workflow {task.task_type} Task"

                # Check folder/workflow-level VALUEPAIR lookup
                taskname_ref = (task.get_attribute("taskname") if hasattr(task, "get_attribute") else None) or task.name
                vps = folder_tasks_lookup.get(taskname_ref, [])
                for vp in vps:
                    raw_value = vp.get("value", "")
                    resolved_value = _resolve(raw_value)
                    _extract_script_refs(task.name, wf_cmd_type, resolved_value)

    return refs


def _load_bteq_scripts(bteq_dir: Optional[Path]) -> Dict[str, Tuple[str, str]]:
    """Load all .sh/.ksh files from the BTEQ directory.

    Returns:
        Dict mapping lowercase filename -> (header_block, script_body)
    """
    scripts: Dict[str, Tuple[str, str]] = {}
    if not bteq_dir or not bteq_dir.exists():
        return scripts

    for ext in ("*.sh", "*.ksh"):
        for fpath in bteq_dir.glob(ext):
            try:
                content = fpath.read_text(encoding="utf-8", errors="replace")
                header, body = _parse_bteq_script(content)
                scripts[fpath.name.lower()] = (header, body)
            except Exception as e:
                logger.warning(f"Could not read BTEQ script {fpath.name}: {e}")
    return scripts


def create_bteq_details_sheet(
    wb: "Workbook",
    documents: List["PowermartDocument"],
    bteq_dir: Optional[Path] = None,
    param_loader: "ParameterFileLoader" = None,
):
    """Create the 'BTEQ Details' sheet in the workbook.

    Scans XML documents for .sh/.ksh references in pre/post commands,
    matches them by filename to scripts in bteq_dir, and writes rows
    with the script description and full content.
    """
    ws = wb.create_sheet("BTEQ Details")
    headers = [
        "Session/Task Name",
        "Command Type",
        "File Name",
        "Full Command",
        "Description",
        "Script",
    ]
    for col_idx, header in enumerate(headers, 1):
        apply_header_style(ws.cell(row=1, column=col_idx, value=header))

    # Collect all BTEQ references from the XML documents
    refs = _collect_bteq_references(documents, param_loader)
    if not refs:
        logger.info("BTEQ Details: no script references found in XMLs")
        auto_adjust_columns(ws)
        ws.freeze_panes = "A2"
        return

    # Load available BTEQ scripts
    bteq_scripts = _load_bteq_scripts(bteq_dir)
    logger.info(f"Loaded {len(bteq_scripts)} BTEQ script(s) from {bteq_dir}")

    row_idx = 2
    for ref in refs:
        fname = ref["script_filename"]
        fname_lower = fname.lower()

        header = ""
        body = ""
        if fname_lower in bteq_scripts:
            header, body = bteq_scripts[fname_lower]

        ws.cell(row=row_idx, column=1, value=ref["session_task_name"])
        ws.cell(row=row_idx, column=2, value=ref["command_type"])
        ws.cell(row=row_idx, column=3, value=fname)
        ws.cell(row=row_idx, column=4, value=ref["full_command"])
        ws.cell(row=row_idx, column=5, value=header if header else ("(file not found)" if fname_lower not in bteq_scripts else "(no description in script)"))
        ws.cell(row=row_idx, column=6, value=body if body else ("(file not found)" if fname_lower not in bteq_scripts else "(no script body)"))
        row_idx += 1

    auto_adjust_columns(ws)
    ws.freeze_panes = "A2"
    logger.info(f"BTEQ Details: {row_idx - 2} rows")


# ---------------------------------------------------------------------------
# View Details helpers
# ---------------------------------------------------------------------------

def _parse_command_args(full_command: str) -> Dict[str, str]:
    """Parse -KEY VALUE pairs from a shell command string."""
    args: Dict[str, str] = {}
    tokens = full_command.rstrip("; \t").split()
    i = 0
    while i < len(tokens):
        token = tokens[i]
        if token.startswith("-") and len(token) > 1 and not token[1:].replace(".", "").replace("/", "").isdigit():
            key = token.lstrip("-")
            if i + 1 < len(tokens) and not tokens[i + 1].startswith("-"):
                args[key] = tokens[i + 1].rstrip(";")
                i += 2
            else:
                args[key] = ""
                i += 1
        else:
            i += 1
    return args


def _parse_case_var_mapping(script_body: str) -> Dict[str, str]:
    """Parse case statement to find arg→shell_variable mapping.

    Matches: -KEY ) export VAR_NAME=$2
    Returns: {"KEY": "VAR_NAME", ...}
    """
    mapping: Dict[str, str] = {}
    pattern = _re.compile(r'-(\w+)\s*\)\s*export\s+(\w+)\s*=\s*\$2', _re.MULTILINE)
    for m in pattern.finditer(script_body):
        mapping[m.group(1)] = m.group(2)
    return mapping


def _build_var_substitution_map(
    cmd_args: Dict[str, str],
    case_mapping: Dict[str, str],
) -> Dict[str, str]:
    """Build a shell-variable → actual-value substitution map."""
    subs: Dict[str, str] = {}
    for arg_name, value in cmd_args.items():
        if arg_name in case_mapping:
            var = case_mapping[arg_name]
            subs[f"${{{var}}}"] = value
            subs[f"${var}"] = value
        subs[f"${{{arg_name}}}"] = value
        subs[f"${arg_name}"] = value
        subs[f"${{ARG_{arg_name}}}"] = value
        subs[f"$ARG_{arg_name}"] = value
    return subs


def _apply_var_substitutions(text: str, subs: Dict[str, str]) -> str:
    """Substitute shell variables, longest names first to avoid partial matches."""
    for var in sorted(subs.keys(), key=len, reverse=True):
        text = text.replace(var, subs[var])
    return text


def _extract_view_sql_sections(script_body: str) -> str:
    """Extract REPLACE VIEW / CREATE VIEW SQL from a ksh script body."""
    if not script_body:
        return ""

    lines = script_body.splitlines()
    sections: List[str] = []

    # Strategy 1: heredoc blocks containing REPLACE/CREATE VIEW
    i = 0
    while i < len(lines):
        m = _re.search(r'<<\s*[\'"]?(\w+)[\'"]?', lines[i])
        if m:
            marker = m.group(1)
            start = i + 1
            j = start
            while j < len(lines) and lines[j].strip() != marker:
                j += 1
            block = "\n".join(lines[start:j])
            if _re.search(r'(?:REPLACE|CREATE)\s+VIEW', block, _re.IGNORECASE):
                sections.append(block.strip())
            i = j + 1
            continue
        i += 1

    if sections:
        return "\n\n".join(sections)

    # Strategy 2: BTEQ.ksh -xo "SQL" blocks
    bteq_pattern = _re.compile(
        r'BTEQ\.ksh\s+[^"]*-xo\s+"(.*?)"\s*[\$\w>]',
        _re.DOTALL,
    )
    for m in bteq_pattern.finditer(script_body):
        sql = m.group(1).strip()
        if _re.search(r'REPLACE\s+VIEW|CREATE\s+VIEW', sql, _re.IGNORECASE):
            sections.append(sql)

    if sections:
        return "\n\n".join(sections)

    # Strategy 3: fallback — lines around REPLACE/CREATE VIEW
    for i, line in enumerate(lines):
        if _re.search(r'(?:REPLACE|CREATE)\s+VIEW', line, _re.IGNORECASE):
            end = min(len(lines), i + 25)
            for j in range(i + 1, end):
                if lines[j].rstrip().endswith(";"):
                    end = j + 1
                    break
            sections.append("\n".join(lines[i:end]).strip())

    return "\n\n".join(sections) if sections else ""


def _classify_view_type(script_filename: str, script_body: str) -> str:
    """Classify view type from script name/content."""
    fname = script_filename.upper()
    if "CLEANSING" in fname:
        return "Cleansing"
    if "CDC" in fname:
        return "CDC"
    if script_body and _re.search(r'cleansing', script_body, _re.IGNORECASE):
        return "Cleansing"
    if script_body and _re.search(r'\bCDC\b|change.?data.?capture', script_body, _re.IGNORECASE):
        return "CDC"
    return "Other"


def _extract_view_identity(cmd_args: Dict[str, str]) -> Tuple[str, str]:
    """Return (view_name, view_database) from command args."""
    name_keys = ["RAW_VW_NM", "CDC_VIEW_NM", "VIEW_NM", "VW_NM"]
    db_keys = ["VW_DB_NM", "CDC_VIEW_DB_NM", "VIEW_DB_NM", "VW_DB"]

    view_name = ""
    view_db = ""
    for k in name_keys:
        if k in cmd_args:
            view_name = cmd_args[k]
            break
    for k in db_keys:
        if k in cmd_args:
            view_db = cmd_args[k]
            break
    return (view_name, view_db)


def _extract_source_tables(cmd_args: Dict[str, str], view_type: str) -> str:
    """Extract source table references from command arguments."""
    sources: List[str] = []

    if view_type == "Cleansing":
        db = cmd_args.get("STG_DB_NM", "")
        raw = cmd_args.get("RAW_TB_NM", "")
        lnd = cmd_args.get("LND_TB_NM", "")
        if db and raw:
            sources.append(f"{db}.{raw}")
        elif raw:
            sources.append(raw)
        if lnd:
            sources.append(f"{db}.{lnd}" if db else lnd)
    elif view_type == "CDC":
        db = cmd_args.get("LND_DB_NM", "")
        tbl = cmd_args.get("LND_TABLE_NM", "")
        prev = cmd_args.get("LND_TABLE_NM_PREV", "")
        if db and tbl:
            sources.append(f"{db}.{tbl}")
        elif tbl:
            sources.append(tbl)
        if db and prev:
            sources.append(f"{db}.{prev}")
        elif prev:
            sources.append(prev)
    else:
        tbl_args = {k: v for k, v in cmd_args.items()
                    if ("TB_NM" in k.upper() or "TABLE_NM" in k.upper())
                    and "VIEW" not in k.upper() and "VW" not in k.upper()}
        for v in tbl_args.values():
            sources.append(v)

    return ", ".join(sources) if sources else ""


def create_view_details_sheet(
    wb: "Workbook",
    documents: List["PowermartDocument"],
    bteq_dir: Optional[Path] = None,
    param_loader: "ParameterFileLoader" = None,
):
    """Create the 'View Details' sheet.

    Filters BTEQ script references for view-generating scripts, extracts
    view definitions, substitutes actual parameter values, and writes rows.
    """
    ws = wb.create_sheet("View Details")
    headers = [
        "Session/Task Name",
        "Script Name",
        "View Name",
        "View Database",
        "View Type",
        "Source Tables",
        "Full Command",
        "View SQL",
        "Parameters",
        "Description",
    ]
    for col_idx, header in enumerate(headers, 1):
        apply_header_style(ws.cell(row=1, column=col_idx, value=header))

    refs = _collect_bteq_references(documents, param_loader)
    if not refs:
        logger.info("View Details: no script references found")
        auto_adjust_columns(ws)
        ws.freeze_panes = "A2"
        return

    bteq_scripts = _load_bteq_scripts(bteq_dir)

    row_idx = 2
    for ref in refs:
        fname = ref["script_filename"]
        fname_lower = fname.lower()

        header_block = ""
        body = ""
        if fname_lower in bteq_scripts:
            header_block, body = bteq_scripts[fname_lower]

        # Filter: only view-generating scripts
        is_view = bool(_re.search(r'view', fname, _re.IGNORECASE))
        if not is_view and body:
            is_view = bool(_re.search(r'(?:REPLACE|CREATE)\s+VIEW', body, _re.IGNORECASE))
        if not is_view:
            continue

        cmd_args = _parse_command_args(ref["full_command"])
        case_mapping = _parse_case_var_mapping(body) if body else {}
        subs = _build_var_substitution_map(cmd_args, case_mapping)

        view_name, view_db = _extract_view_identity(cmd_args)
        view_type = _classify_view_type(fname, body)
        source_tables = _extract_source_tables(cmd_args, view_type)

        raw_sql = _extract_view_sql_sections(body) if body else ""
        view_sql = _apply_var_substitutions(raw_sql, subs) if raw_sql else "(script not found)"

        params_str = "; ".join(f"{k}={v}" for k, v in cmd_args.items())

        ws.cell(row=row_idx, column=1, value=ref["session_task_name"])
        ws.cell(row=row_idx, column=2, value=fname)
        ws.cell(row=row_idx, column=3, value=view_name)
        ws.cell(row=row_idx, column=4, value=view_db)
        ws.cell(row=row_idx, column=5, value=view_type)
        ws.cell(row=row_idx, column=6, value=source_tables)
        ws.cell(row=row_idx, column=7, value=ref["full_command"])
        ws.cell(row=row_idx, column=8, value=view_sql)
        ws.cell(row=row_idx, column=9, value=params_str)
        ws.cell(row=row_idx, column=10, value=header_block if header_block else "(no description)")
        row_idx += 1

    auto_adjust_columns(ws)
    ws.freeze_panes = "A2"
    logger.info(f"View Details: {row_idx - 2} rows")


# ---------------------------------------------------------------
# Sheet 10: Source Definitions
# ---------------------------------------------------------------
def _resolve_sources_for_mapping(mapping, doc) -> list:
    """Resolve all source definitions used by a mapping.

    Combines mapping.sources with document-level sources referenced
    via shortcut instances (sc_ prefix) to handle dual-role shortcuts.
    """
    doc_source_map = {s.name.lower(): s for s in doc.sources}
    shortcuts = getattr(doc, 'shortcuts', {}) or {}
    seen = {s.name.lower() for s in mapping.sources}
    result = list(mapping.sources)

    for inst in mapping.source_instances:
        if 'source qualifier' in inst.transformation_type.lower():
            continue
        tname = inst.transformation_name.lower()
        # Direct match against doc sources
        if tname in doc_source_map and tname not in seen:
            result.append(doc_source_map[tname])
            seen.add(tname)
        # Shortcut resolution
        resolved = shortcuts.get(tname, '')
        if resolved and resolved.lower() in doc_source_map and resolved.lower() not in seen:
            result.append(doc_source_map[resolved.lower()])
            seen.add(resolved.lower())
        # Strip sc_ prefix
        if tname.startswith('sc_'):
            bare = tname[3:]
            if bare in doc_source_map and bare not in seen:
                result.append(doc_source_map[bare])
                seen.add(bare)
    return result


def _resolve_targets_for_mapping(mapping, doc) -> list:
    """Resolve all target definitions used by a mapping.

    Combines mapping.targets with document-level targets referenced
    via shortcut instances (sc_ prefix).
    """
    doc_target_map = {t.name.lower(): t for t in doc.targets}
    shortcuts = getattr(doc, 'shortcuts', {}) or {}
    seen = {t.name.lower() for t in mapping.targets}
    result = list(mapping.targets)

    for inst in mapping.target_instances:
        tname = inst.transformation_name.lower()
        if tname in doc_target_map and tname not in seen:
            result.append(doc_target_map[tname])
            seen.add(tname)
        resolved = shortcuts.get(tname, '')
        if resolved and resolved.lower() in doc_target_map and resolved.lower() not in seen:
            result.append(doc_target_map[resolved.lower()])
            seen.add(resolved.lower())
        if tname.startswith('sc_'):
            bare = tname[3:]
            if bare in doc_target_map and bare not in seen:
                result.append(doc_target_map[bare])
                seen.add(bare)
    return result


def create_source_definitions_sheet(
    wb: Workbook,
    documents: List[PowermartDocument],
):
    """Create a sheet with field-level source definition metadata per mapping."""
    ws = wb.create_sheet("Source Definitions")
    headers = [
        "Mapping Name", "Source Name", "Database Type", "Database Name",
        "Owner", "Field Name", "Datatype", "Precision", "Scale",
        "Nullable", "Key Type",
    ]
    for col_idx, header in enumerate(headers, 1):
        cell = ws.cell(row=1, column=col_idx, value=header)
        apply_header_style(cell)

    row_idx = 2
    for doc in documents:
        for mapping in doc.mappings:
            all_sources = _resolve_sources_for_mapping(mapping, doc)
            for source in all_sources:
                for fld in source.fields:
                    ws.cell(row=row_idx, column=1, value=mapping.name)
                    ws.cell(row=row_idx, column=2, value=source.name)
                    ws.cell(row=row_idx, column=3, value=source.database_type)
                    ws.cell(row=row_idx, column=4, value=source.db_dname)
                    ws.cell(row=row_idx, column=5, value=source.owner_name)
                    ws.cell(row=row_idx, column=6, value=fld.name)
                    ws.cell(row=row_idx, column=7, value=fld.datatype)
                    ws.cell(row=row_idx, column=8, value=fld.precision)
                    ws.cell(row=row_idx, column=9, value=fld.scale)
                    ws.cell(row=row_idx, column=10, value=fld.nullable)
                    ws.cell(row=row_idx, column=11, value=getattr(fld, "keytype", ""))
                    row_idx += 1

    auto_adjust_columns(ws)
    ws.freeze_panes = "A2"
    logger.info(f"Source Definitions: {row_idx - 2} rows")


# ---------------------------------------------------------------
# Sheet 11: Target Definitions
# ---------------------------------------------------------------
def create_target_definitions_sheet(
    wb: Workbook,
    documents: List[PowermartDocument],
):
    """Create a sheet with field-level target definition metadata per mapping."""
    ws = wb.create_sheet("Target Definitions")
    headers = [
        "Mapping Name", "Target Name", "Database Type",
        "Field Name", "Datatype", "Precision", "Scale",
        "Nullable", "Key Type",
    ]
    for col_idx, header in enumerate(headers, 1):
        cell = ws.cell(row=1, column=col_idx, value=header)
        apply_header_style(cell)

    row_idx = 2
    for doc in documents:
        for mapping in doc.mappings:
            all_targets = _resolve_targets_for_mapping(mapping, doc)
            for target in all_targets:
                for fld in target.fields:
                    ws.cell(row=row_idx, column=1, value=mapping.name)
                    ws.cell(row=row_idx, column=2, value=target.name)
                    ws.cell(row=row_idx, column=3, value=target.database_type)
                    ws.cell(row=row_idx, column=4, value=fld.name)
                    ws.cell(row=row_idx, column=5, value=fld.datatype)
                    ws.cell(row=row_idx, column=6, value=fld.precision)
                    ws.cell(row=row_idx, column=7, value=fld.scale)
                    ws.cell(row=row_idx, column=8, value=fld.nullable)
                    ws.cell(row=row_idx, column=9, value=getattr(fld, "keytype", ""))
                    row_idx += 1

    auto_adjust_columns(ws)
    ws.freeze_panes = "A2"
    logger.info(f"Target Definitions: {row_idx - 2} rows")


# ---------------------------------------------------------------
# Sheet 12: Target Load Plan
# ---------------------------------------------------------------
def create_target_load_plan_sheet(
    wb: Workbook,
    documents: List[PowermartDocument],
):
    """Create a sheet showing pipeline execution order within each mapping."""
    ws = wb.create_sheet("Target Load Plan")
    headers = ["Mapping Name", "Target Instance", "Load Order"]
    for col_idx, header in enumerate(headers, 1):
        cell = ws.cell(row=1, column=col_idx, value=header)
        apply_header_style(cell)

    row_idx = 2
    for doc in documents:
        for mapping in doc.mappings:
            for entry in mapping.target_load_order_detailed:
                ws.cell(row=row_idx, column=1, value=mapping.name)
                ws.cell(row=row_idx, column=2, value=entry["target_instance"])
                ws.cell(row=row_idx, column=3, value=entry["order"])
                row_idx += 1

    auto_adjust_columns(ws)
    ws.freeze_panes = "A2"
    logger.info(f"Target Load Plan: {row_idx - 2} rows")


# ---------------------------------------------------------------
# Sheet 13: Session Execution Flow
# ---------------------------------------------------------------
def create_session_execution_flow_sheet(
    wb: Workbook,
    documents: List[PowermartDocument],
):
    """Create a sheet showing session execution order within each workflow.

    When a workflow contains worklet tasks, the worklet's internal
    execution order is expanded as sub-rows (e.g. ``1.1``, ``1.2``).
    """
    ws = wb.create_sheet("Session Execution Flow")
    headers = ["Workflow Name", "Execution Order", "Task/Session Name", "Task Type"]
    for col_idx, header in enumerate(headers, 1):
        cell = ws.cell(row=1, column=col_idx, value=header)
        apply_header_style(cell)

    row_idx = 2
    for doc in documents:
        # Build worklet lookup: name_lower -> Worklet object
        worklet_map = {}
        for wklt in getattr(doc, 'worklets', []) or []:
            worklet_map[wklt.name.lower()] = wklt

        for workflow in doc.workflows:
            execution_order = workflow.get_execution_order()
            # Build task type lookup
            task_type_map = {}
            for task in workflow.tasks:
                task_type_map[task.name.lower()] = task.task_type
            for session in workflow.sessions:
                task_type_map[session.name.lower()] = "Session"

            for seq, task_name in enumerate(execution_order, 1):
                task_type = task_type_map.get(task_name.lower(), "")
                ws.cell(row=row_idx, column=1, value=workflow.name)
                ws.cell(row=row_idx, column=2, value=seq)
                ws.cell(row=row_idx, column=3, value=task_name)
                ws.cell(row=row_idx, column=4, value=task_type)
                row_idx += 1

                # Expand worklet internal tasks as sub-rows
                if task_type.lower() == "worklet" and task_name.lower() in worklet_map:
                    wklt = worklet_map[task_name.lower()]
                    wklt_order = wklt.get_execution_order()
                    # Build worklet task type lookup
                    wklt_type_map = {}
                    for wt in wklt.tasks:
                        wklt_type_map[wt.name.lower()] = wt.task_type
                    for ws_sess in wklt.sessions:
                        wklt_type_map[ws_sess.name.lower()] = "Session"

                    for sub_seq, sub_task in enumerate(wklt_order, 1):
                        sub_type = wklt_type_map.get(sub_task.lower(), "")
                        ws.cell(row=row_idx, column=1, value=workflow.name)
                        ws.cell(row=row_idx, column=2, value=f"{seq}.{sub_seq}")
                        ws.cell(row=row_idx, column=3, value=f"  {wklt.name}/{sub_task}")
                        ws.cell(row=row_idx, column=4, value=sub_type)
                        row_idx += 1

    auto_adjust_columns(ws)
    ws.freeze_panes = "A2"
    logger.info(f"Session Execution Flow: {row_idx - 2} rows")


def generate_enhanced_excel(
    csv_path: Path,
    input_xml_paths: List[Path],
    param_file_paths: List[Path],
    output_path: Path,
    bteq_dir: Optional[Path] = None,
):
    """Generate enhanced Excel workbook from aggregated lineage CSV and XML inputs.

    This is the core function that can be called programmatically (e.g. from
    the aggregate CLI) or via the command-line ``main()`` entry point.

    Args:
        bteq_dir: Optional path to directory containing BTEQ .sh/.ksh scripts.
                  When provided, a "BTEQ Details" sheet is added.
    """
    if not csv_path.exists():
        raise FileNotFoundError(f"CSV file not found: {csv_path}")

    output_path.parent.mkdir(parents=True, exist_ok=True)

    # Collect XML files from paths (files or directories)
    xml_files = collect_xml_files([str(p) for p in input_xml_paths])
    if not xml_files:
        raise ValueError("No XML files found in input paths")
    logger.info(f"Found {len(xml_files)} XML file(s)")

    # Parse documents
    documents = parse_all_documents(xml_files)
    if not documents:
        raise ValueError("No documents successfully parsed")

    # Load param files
    param_paths = [str(p) for p in param_file_paths]
    param_loader = load_param_file(param_paths, xml_files)

    # Build mapping -> sessions lookup
    mapping_to_sessions = build_mapping_to_sessions(documents)

    # Create workbook
    wb = Workbook()
    wb.remove(wb.active)  # Remove default sheet

    # Sheet order:
    # 1. Summary
    # 2. Aggregated Lineage
    # 3. Source Definitions
    # 4. Target Definitions
    # 5. Target Load Plan
    # 6. Session Execution Flow
    # 7. Expression Details
    # 8. Union Details
    # 9. Router Details
    # 10. Joiner Details
    # 11. Lookup Details
    # 12. Pre-Post SQL
    # 13+ BTEQ Details, View Details (if applicable)

    logger.info("Creating Sheet: Summary...")
    create_summary_sheet(wb, documents, xml_files)

    logger.info("Creating Sheet: Aggregated Lineage...")
    create_aggregated_lineage_sheet(wb, csv_path)

    logger.info("Creating Sheet: Source Definitions...")
    create_source_definitions_sheet(wb, documents)

    logger.info("Creating Sheet: Target Definitions...")
    create_target_definitions_sheet(wb, documents)

    logger.info("Creating Sheet: Target Load Plan...")
    create_target_load_plan_sheet(wb, documents)

    logger.info("Creating Sheet: Session Execution Flow...")
    create_session_execution_flow_sheet(wb, documents)

    logger.info("Creating Sheet: Expression Details...")
    create_expression_details_sheet(wb, documents, mapping_to_sessions, param_loader)

    logger.info("Creating Sheet: Union Details...")
    create_union_details_sheet(wb, documents, mapping_to_sessions, param_loader)

    logger.info("Creating Sheet: Router Details...")
    create_router_details_sheet(wb, documents, mapping_to_sessions, param_loader)

    logger.info("Creating Sheet: Joiner Details...")
    create_joiner_details_sheet(wb, documents, mapping_to_sessions, param_loader)

    logger.info("Creating Sheet: Lookup Details...")
    create_lookup_details_sheet(wb, documents, mapping_to_sessions, param_loader)

    logger.info("Creating Sheet: Pre-Post SQL...")
    create_pre_post_sql_sheet(wb, documents, param_loader)

    logger.info("Creating Sheet: BTEQ Details...")
    create_bteq_details_sheet(wb, documents, bteq_dir, param_loader)

    logger.info("Creating Sheet: View Details...")
    create_view_details_sheet(wb, documents, bteq_dir, param_loader)

    # Save
    wb.save(output_path)
    logger.info(f"Enhanced Excel saved to: {output_path}")
    print(f"\nOutput: {output_path}")
    print(f"Sheets: {[ws.title for ws in wb.worksheets]}")


def main():
    parser = argparse.ArgumentParser(
        description="Generate enhanced Excel from Informatica aggregated lineage output"
    )
    parser.add_argument(
        "--csv", required=True,
        help="Path to the aggregated lineage CSV (previous output)"
    )
    parser.add_argument(
        "--input", "-i", nargs="+", required=True,
        help="XML files or directory containing XML files"
    )
    parser.add_argument(
        "--param-file", "-p", nargs="+", default=[],
        help="Parameter file(s) for resolving $Param_* placeholders"
    )
    parser.add_argument(
        "--output", "-o", default=None,
        help="Output Excel file path (default: same dir as CSV with .xlsx extension)"
    )
    parser.add_argument(
        "--bteq-dir",
        default=None,
        help="Directory containing BTEQ .sh/.ksh scripts for the BTEQ Details sheet"
    )
    parser.add_argument(
        "-v", "--verbose", action="store_true",
        help="Enable verbose output"
    )
    args = parser.parse_args()

    setup_logging("DEBUG" if args.verbose else "INFO")

    csv_path = sanitize_path(args.csv)

    # Determine output path
    if args.output:
        output_path = sanitize_path(args.output)
    else:
        output_path = csv_path.with_name("informatica_enhanced_output.xlsx")

    # Auto-detect param files from input dirs if not specified
    param_paths = list(args.param_file)
    if not param_paths:
        param_exts = {".txt", ".prm", ".par"}
        for inp in args.input:
            p = Path(inp)
            if p.is_file() and p.suffix.lower() in param_exts:
                param_paths.append(str(p))
            elif p.is_dir():
                for ext in param_exts:
                    for pf in p.glob(f"*{ext}"):
                        param_paths.append(str(pf))
        if param_paths:
            logger.info(f"Auto-detected {len(param_paths)} parameter file(s)")

    bteq_dir = sanitize_path(args.bteq_dir) if args.bteq_dir else None

    try:
        generate_enhanced_excel(
            csv_path=csv_path,
            input_xml_paths=[Path(p) for p in args.input],
            param_file_paths=[Path(p) for p in param_paths],
            output_path=output_path,
            bteq_dir=bteq_dir,
        )
    except (FileNotFoundError, ValueError) as e:
        logger.error(str(e))
        sys.exit(1)


if __name__ == "__main__":
    main()
