"""JSON exporter for lineage results."""

import json
from pathlib import Path
from typing import Any, Dict, List, Optional, Union

from ..models.lineage_models import LineageResult
from ..parsers.powermart_parser import PowermartDocument
from werkzeug.utils import safe_join
from ..utils.logging_config import get_logger

logger = get_logger("json_exporter")


class JSONExporter:
    """Exports lineage results to JSON format."""

    def __init__(self, indent: int = 2, ensure_ascii: bool = False):
        """
        Initialize JSON exporter.

        Args:
            indent: JSON indentation level
            ensure_ascii: Whether to escape non-ASCII characters
        """
        self.indent = indent
        self.ensure_ascii = ensure_ascii

    def export(
        self,
        lineage_result: LineageResult,
        document: PowermartDocument,
        output_path: Union[str, Path],
        integration_data: Optional[Dict] = None,
    ) -> str:
        """
        Export lineage results to JSON.

        Args:
            lineage_result: The lineage analysis result
            document: The original PowermartDocument
            output_path: Path for the output file
            integration_data: Optional additional data from integration expert

        Returns:
            Path to the created file
        """
        _raw = Path(output_path)
        output_path = Path(safe_join(str(_raw.parent), _raw.name))
        output_path.parent.mkdir(parents=True, exist_ok=True)

        logger.info(f"Exporting lineage to JSON: {output_path}")

        # Build complete export data
        # Build target-to-mapping lookup
        target_to_mappings = {}
        for mapping in document.mappings:
            for inst in mapping.target_instances:
                inst_name = inst.transformation_name.lower()
                target_to_mappings.setdefault(inst_name, set()).add(mapping.name)
                # Strip common prefixes to match document-level target names
                clean = inst_name.replace('sc_to_', '').replace('sc_', '').replace('tgt_', '')
                if clean != inst_name:
                    target_to_mappings.setdefault(clean, set()).add(mapping.name)
            for tgt in mapping.targets:
                target_to_mappings.setdefault(tgt.name.lower(), set()).add(mapping.name)

        targets_with_mapping = []
        for t in document.targets:
            t_dict = t.to_dict()
            tgt_lower = t.name.lower()
            mapping_names_set = target_to_mappings.get(tgt_lower, set())
            if not mapping_names_set:
                for key, names in target_to_mappings.items():
                    if key in tgt_lower or tgt_lower in key:
                        mapping_names_set = mapping_names_set | names
            t_dict["mapping_name"] = ", ".join(sorted(mapping_names_set))
            targets_with_mapping.append(t_dict)

        # Build source-to-mapping lookup
        source_to_mappings = {}
        for mapping in document.mappings:
            for inst in mapping.source_instances:
                inst_name = inst.transformation_name.lower()
                clean_inst = inst_name.replace('sq_', '').replace('sc_', '').replace('src_', '')
                source_to_mappings.setdefault(inst_name, set()).add(mapping.name)
                source_to_mappings.setdefault(clean_inst, set()).add(mapping.name)
            for src in mapping.sources:
                source_to_mappings.setdefault(src.name.lower(), set()).add(mapping.name)

        sources_with_mapping = []
        for s in document.sources:
            s_dict = s.to_dict()
            src_lower = s.name.lower()
            mapping_names_set = source_to_mappings.get(src_lower, set())
            if not mapping_names_set:
                for key, names in source_to_mappings.items():
                    if key in src_lower or src_lower in key:
                        mapping_names_set = mapping_names_set | names
            s_dict["mapping_name"] = ", ".join(sorted(mapping_names_set))
            sources_with_mapping.append(s_dict)

        export_data = {
            "metadata": {
                "file": document.file_path,
                "creation_date": document.creation_date,
                "repository_version": document.repository_version,
                "repository": document.repository.to_dict() if document.repository else None,
                "folder": document.folder.to_dict() if document.folder else None,
                "folder_owner": document.folder.owner if document.folder else "",
            },
            "statistics": {
                "source_count": lineage_result.source_count,
                "target_count": lineage_result.target_count,
                "transformation_count": lineage_result.transformation_count,
                "lineage_count": len(lineage_result.field_lineages),
                "coverage_percentage": lineage_result.coverage_percentage,
            },
            "lineage_result": lineage_result.to_dict(),
            "sources": sources_with_mapping,
            "targets": targets_with_mapping,
            "mappings": [m.to_dict() for m in document.mappings],
            "workflows": [w.to_dict() for w in document.workflows],
            "worklets": [w.to_dict() for w in document.worklets],
        }

        # Include integration data if available
        if integration_data:
            export_data["expert_analysis"] = integration_data
            # Enrich stored procedures with resolved mapping names
            sp_to_mappings: dict = {}
            for mapping in document.mappings:
                for inst in mapping.instances:
                    inst_name_lower = inst.transformation_name.lower() if hasattr(inst, 'transformation_name') else inst.name.lower()
                    if inst_name_lower:
                        sp_to_mappings.setdefault(inst_name_lower, set()).add(mapping.name)
                        clean = inst_name_lower.replace('sc_', '').replace('src_', '')
                        if clean != inst_name_lower:
                            sp_to_mappings.setdefault(clean, set()).add(mapping.name)
            try:
                sps = integration_data["expert_results"]["OperatorLogic"]["data"]["stored_procedures"]
                enriched_sps = []
                for sp in sps:
                    sp_copy = dict(sp)
                    sp_name_lower = sp.get("name", "").lower()
                    mapping_names_set = sp_to_mappings.get(sp_name_lower, set())
                    if not mapping_names_set:
                        for key, names in sp_to_mappings.items():
                            if sp_name_lower and (sp_name_lower in key or key in sp_name_lower):
                                mapping_names_set = mapping_names_set | names
                    sp_copy["mapping_name"] = ", ".join(sorted(mapping_names_set))
                    enriched_sps.append(sp_copy)
                import copy
                ea_copy = copy.deepcopy(integration_data)
                ea_copy["expert_results"]["OperatorLogic"]["data"]["stored_procedures"] = enriched_sps
                export_data["expert_analysis"] = ea_copy
            except (KeyError, TypeError):
                pass

        # Include mapping flow summary
        from ..utils.mapping_flow_utils import build_mapping_flow_summary
        export_data["mapping_flow_summary"] = build_mapping_flow_summary(document)

        # Write JSON
        with open(output_path, 'w', encoding='utf-8') as f:
            json.dump(export_data, f, indent=self.indent, ensure_ascii=self.ensure_ascii)

        logger.info(f"JSON export complete: {output_path}")
        return str(output_path)

    def export_per_mapping(
        self,
        lineage_result: LineageResult,
        document: PowermartDocument,
        output_dir: Union[str, Path],
        integration_data: Optional[Dict] = None,
    ) -> List[str]:
        """
        Export separate JSON files for each mapping in the document.

        Args:
            lineage_result: The lineage analysis result
            document: The original PowermartDocument
            output_dir: Directory for the output files
            integration_data: Optional additional data from integration expert

        Returns:
            List of paths to created files
        """
        output_dir = Path(output_dir)
        output_dir.mkdir(parents=True, exist_ok=True)

        created_files = []

        for mapping in document.mappings:
            mapping_name = mapping.name
            logger.info(f"Exporting JSON for mapping: {mapping_name}")

            # Build mapping-specific sources/targets from document level
            mapping_sources = list(mapping.sources)
            if not mapping_sources:
                source_inst_names = {inst.transformation_name.lower() for inst in mapping.source_instances}
                for src in document.sources:
                    src_lower = src.name.lower()
                    for inst_name in source_inst_names:
                        clean_inst = inst_name.replace('sq_', '').replace('sc_', '').replace('src_', '')
                        if clean_inst in src_lower or src_lower in clean_inst:
                            mapping_sources.append(src)
                            break

            mapping_targets = list(mapping.targets)
            if not mapping_targets:
                target_inst_names = {inst.transformation_name.lower() for inst in mapping.target_instances}
                for tgt in document.targets:
                    tgt_lower = tgt.name.lower()
                    for inst_name in target_inst_names:
                        clean_inst = inst_name.replace('sc_', '').replace('tgt_', '')
                        if clean_inst in tgt_lower or tgt_lower in clean_inst:
                            mapping_targets.append(tgt)
                            break

            # Filter lineage for this mapping's targets
            target_names = {t.name.lower() for t in mapping_targets}
            for inst in mapping.target_instances:
                target_names.add(inst.transformation_name.lower())

            mapping_lineages = [
                l for l in lineage_result.field_lineages
                if l.target_table and l.target_table.lower() in target_names
            ]

            # Build export data
            export_data = {
                "metadata": {
                    "file": document.file_path,
                    "mapping_name": mapping_name,
                    "creation_date": document.creation_date,
                    "repository": document.repository.to_dict() if document.repository else None,
                    "folder": document.folder.to_dict() if document.folder else None,
                },
                "statistics": {
                    "source_count": len(mapping_sources),
                    "target_count": len(mapping_targets),
                    "transformation_count": len(mapping.transformations),
                    "lineage_count": len(mapping_lineages),
                },
                "sources": [s.to_dict() for s in mapping_sources],
                "targets": [t.to_dict() for t in mapping_targets],
                "transformations": [t.to_dict() for t in mapping.transformations],
                "lineages": [l.to_row() for l in mapping_lineages],
            }

            # Filter integration data for this mapping
            if integration_data:
                export_data["expert_analysis"] = self._filter_integration_data(
                    integration_data, mapping_name
                )

            safe_name = "".join(c if c.isalnum() or c in ('_', '-') else '_' for c in mapping_name)
            json_path = output_dir / f"{safe_name}_lineage.json"

            with open(json_path, 'w', encoding='utf-8') as f:
                json.dump(export_data, f, indent=self.indent, ensure_ascii=self.ensure_ascii)

            created_files.append(str(json_path))
            logger.info(f"Created: {json_path}")

        return created_files

    def _filter_integration_data(self, integration_data: Dict, mapping_name: str) -> Dict:
        """Filter integration expert data for a specific mapping."""
        filtered = {}
        expert_results = integration_data.get("expert_results", {})
        for expert_name, expert_data in expert_results.items():
            data = expert_data.get("data", {})
            filtered_data = {}
            for key, value in data.items():
                if isinstance(value, list):
                    # Filter list items that have a mapping_name field
                    filtered_items = [
                        item for item in value
                        if not isinstance(item, dict) or
                        item.get("mapping", "") == mapping_name or
                        item.get("mapping_name", "") == mapping_name or
                        "mapping" not in item and "mapping_name" not in item
                    ]
                    if filtered_items:
                        filtered_data[key] = filtered_items
                else:
                    filtered_data[key] = value
            if filtered_data:
                filtered[expert_name] = {"data": filtered_data}
        return {"expert_results": filtered} if filtered else {}

    def export_lineage_only(
        self,
        lineage_result: LineageResult,
        output_path: Union[str, Path],
    ) -> str:
        """
        Export only lineage results (lighter weight).

        Args:
            lineage_result: The lineage analysis result
            output_path: Path for the output file

        Returns:
            Path to the created file
        """
        output_path = Path(output_path)
        output_path.parent.mkdir(parents=True, exist_ok=True)

        with open(output_path, 'w', encoding='utf-8') as f:
            json.dump(lineage_result.to_dict(), f, indent=self.indent, ensure_ascii=self.ensure_ascii)

        return str(output_path)
