"""
AutoMedallion exporter for Informatica reverse engineering output.

This module exports Informatica lineage data in a format compatible
with the AutoMedallion solution for medallion architecture transformation.

Enhanced in Phase 4 to include detailed transformation metadata for
forward engineering to Snowflake SQL:
- Sequence Generator settings
- Stored Procedure configuration
- Rank transformation settings
- Normalizer OCCURS metadata
- Source Qualifier Pre/Post SQL
- Target load Pre/Post SQL
- Update Strategy key columns
"""

import json
import os
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional

from ..aggregation.aggregation_models import (
    UnifiedLineageGraph,
    ParameterCatalog,
    TableNode,
    NodeType,
)
from ..parsers.powermart_parser import PowermartDocument
from ..models.lineage_models import LineageResult, EndToEndFieldLineage
from ..extractors.transformation_metadata_extractor import (
    TransformationMetadataExtractor,
    TransformationMetadataCatalog,
)
# NEW: Import comprehensive transformation extractor for complete business logic capture
from ..aggregation.transformation_extractor import TransformationExtractor
from ..utils.logging_config import get_logger


logger = get_logger("automedallion_exporter")


class AutoMedallionExporter:
    """
    Exports Informatica lineage data in AutoMedallion-compatible format.

    Produces JSON output that can be consumed by AutoMedallion's
    classifier, schema, and SQL refactor agents.

    Enhanced in Phase 4 to include detailed transformation metadata
    for forward engineering to Snowflake SQL.
    """

    def __init__(self):
        """Initialize the exporter."""
        self._transformation_extractor = TransformationMetadataExtractor()
        # NEW: Comprehensive transformation extractor for complete business logic capture
        self._comprehensive_transformation_extractor = TransformationExtractor()

    def export(
        self,
        unified_graph: UnifiedLineageGraph,
        documents: Dict[str, PowermartDocument],
        lineage_results: Dict[str, LineageResult],
        parameter_catalog: Optional[ParameterCatalog] = None,
        output_path: Optional[str] = None,
        include_transformation_metadata: bool = True
    ) -> Dict[str, Any]:
        """
        Export to AutoMedallion-compatible format.

        Args:
            unified_graph: The unified lineage graph
            documents: Dictionary of xml_path -> PowermartDocument
            lineage_results: Dictionary of xml_path -> LineageResult
            parameter_catalog: Optional parameter catalog
            output_path: Optional path to write JSON file
            include_transformation_metadata: Whether to include detailed
                transformation metadata for forward engineering (Phase 4)

        Returns:
            Dictionary in AutoMedallion input format
        """
        logger.info("Exporting to AutoMedallion format")

        # Build the main structure
        output = {
            "metadata": self._build_metadata(documents),
            "files_processed": self._build_files_processed(documents, lineage_results),
            "table_registry": self._build_table_registry(unified_graph, documents),
            "end_to_end_lineage": self._build_e2e_lineage(unified_graph, lineage_results),
            "informatica_metadata": self._build_informatica_metadata(
                unified_graph, parameter_catalog
            ),
            "field_lineage": self._build_field_lineage(lineage_results),
        }

        # Add transformation metadata for forward engineering (Phase 4)
        if include_transformation_metadata:
            output["transformation_metadata"] = self._build_transformation_metadata(documents)

        # NEW: Add comprehensive transformation graphs for complete business logic capture
        # This includes Router groups, Joiner conditions, Lookup details, etc.
        output["transformation_graphs"] = self._build_transformation_graphs(documents)
        logger.info(f"Extracted {len(output['transformation_graphs'])} transformation graphs")

        # Add expression_details: flat list of every expression field across all mappings
        output["expression_details"] = self._build_expression_details(documents)
        logger.info(f"Extracted {len(output['expression_details'])} expression detail entries")

        # Write to file if path provided
        if output_path:
            self._write_json(output, output_path)

        logger.info(
            f"Export complete: {len(output['table_registry'])} tables, "
            f"{len(output['end_to_end_lineage'])} lineage paths"
        )

        return output

    def _build_metadata(self, documents: Dict[str, PowermartDocument]) -> Dict[str, Any]:
        """Build metadata section."""
        return {
            "source_type": "informatica_powercenter",
            "export_timestamp": datetime.now().isoformat(),
            "document_count": len(documents),
            "exporter_version": "1.0.0",
        }

    def _build_files_processed(
        self,
        documents: Dict[str, PowermartDocument],
        lineage_results: Dict[str, LineageResult]
    ) -> List[Dict[str, Any]]:
        """Build files_processed section."""
        files = []

        for xml_path, doc in documents.items():
            lineage = lineage_results.get(xml_path)

            file_info = {
                "file_path": xml_path,
                "file_name": os.path.basename(xml_path),
                "mapping_count": doc.mapping_count,
                "workflow_count": doc.workflow_count,
                "source_count": doc.source_count,
                "target_count": doc.target_count,
                "transformation_count": len(doc.transformations),
                "repository": doc.repository.name if doc.repository else None,
                "folder": doc.folder.name if doc.folder else None,
                "creation_date": doc.creation_date,
            }

            if lineage:
                file_info["lineage_coverage"] = lineage.coverage_percentage
                file_info["field_lineage_count"] = len(lineage.field_lineages)

            files.append(file_info)

        return files

    def _build_table_registry(
        self,
        graph: UnifiedLineageGraph,
        documents: Dict[str, PowermartDocument]
    ) -> Dict[str, Dict[str, Any]]:
        """
        Build table_registry section.

        This is the main table metadata used by AutoMedallion's classifier.
        Enhanced with source classification metadata for accurate LANDING vs BRONZE detection.

        Column Handling:
        - For TARGET tables: Uses TARGET column definitions (authoritative)
        - For SOURCE-only tables: Uses SOURCE column definitions
        - Validates and warns if SQ output columns differ from TARGET columns
        """
        registry = {}

        for table_name, table_node in graph.tables.items():
            # Get enhanced source classification metadata
            source_classification = self._get_source_classification_metadata(
                table_name, table_node, documents, graph
            )

            # Use TARGET columns if available (most accurate for output tables)
            columns_to_use = table_node.columns
            column_source = "TARGET" if table_node.is_target else "SOURCE"

            # Validate: warn if TARGET columns differ significantly from SQ output
            if table_node.is_target and table_node.target_columns:
                columns_to_use = table_node.target_columns
                if len(table_node.target_columns) != len(table_node.columns):
                    logger.warning(
                        f"Table {table_name}: TARGET has {len(table_node.target_columns)} columns "
                        f"but intermediate processing has {len(table_node.columns)} columns. "
                        f"Using TARGET columns as authoritative."
                    )

            registry[table_name] = {
                "table_name": table_name,
                "qualified_name": table_node.qualified_name,
                "database_type": table_node.database_type,
                "owner": table_node.owner,
                "columns": columns_to_use,
                "column_count": len(columns_to_use),
                "column_source": column_source,  # NEW: indicates if columns from TARGET or SOURCE
                "is_target": table_node.is_target,  # NEW: flag indicating if this is a TARGET table
                "primary_keys": self._extract_primary_keys(table_name, documents),
                "node_type": table_node.node_type.value,
                "hop_count": table_node.hop_count,
                "complexity_score": table_node.complexity_score,
                "transformation_types": [t.value for t in table_node.transformation_types],
                "source_xml": table_node.source_xml,
                "mapping_name": table_node.mapping_name,
                # Enhanced source classification metadata
                "source_classification": source_classification,
            }

        return registry

    def _get_source_classification_metadata(
        self,
        table_name: str,
        table_node: TableNode,
        documents: Dict[str, PowermartDocument],
        graph: UnifiedLineageGraph
    ) -> Dict[str, Any]:
        """
        Get source classification metadata for accurate LANDING vs BRONZE detection.

        Returns metadata about:
        - Whether this is a control/reference table
        - Downstream transformation information
        - Whether it's used as a lookup source
        - Resolved source table names (for Source Qualifiers)
        """
        name_upper = table_name.upper()

        # Check if this is a control/reference table based on naming
        is_control_table = self._is_control_table_by_name(name_upper)

        # Check if this table has downstream targets (used as source in a flow)
        has_downstream_targets = self._has_downstream_targets(table_name, graph)

        # Check if this is used as a lookup source
        is_lookup_source = table_node.node_type == NodeType.LOOKUP

        # Get downstream transformation types
        downstream_transformations = self._get_downstream_transformations(
            table_name, documents
        )

        # Determine if this should be LANDING based on all factors
        # LANDING = control table OR external reference with no downstream processing
        is_likely_landing = (
            is_control_table and
            not has_downstream_targets and
            not downstream_transformations
        )

        return {
            "is_control_table": is_control_table,
            "has_downstream_targets": has_downstream_targets,
            "is_lookup_source": is_lookup_source,
            "downstream_transformations": downstream_transformations,
            "is_likely_landing": is_likely_landing,
        }

    def _is_control_table_by_name(self, name_upper: str) -> bool:
        """Check if a table name indicates a control/reference table."""
        # Control table prefixes
        control_prefixes = (
            "CNTL_", "CTL_", "CTRL_", "REF_", "MASTER_",
            "LKP_", "PARAM_", "CONFIG_",
        )

        # Control table suffixes
        control_suffixes = (
            "_MASTER", "_CONTROL", "_PARAM", "_CONFIG",
            "_REF", "_LOOKUP",
        )

        if name_upper.startswith(control_prefixes):
            return True

        if name_upper.endswith(control_suffixes):
            return True

        # Special case: tables with "SYSTEM" and "MASTER" together
        if "SYSTEM" in name_upper and "MASTER" in name_upper:
            return True

        return False

    def _has_downstream_targets(
        self,
        table_name: str,
        graph: UnifiedLineageGraph
    ) -> bool:
        """Check if this table has any downstream target tables."""
        # Look for edges where this table is the source
        for edge in graph.edges:
            if edge.source_table.upper() == table_name.upper():
                return True

        # Also check cross-mapping links
        for link in graph.cross_mapping_links:
            if link.source_table.upper() == table_name.upper():
                return True

        return False

    def _get_downstream_transformations(
        self,
        table_name: str,
        documents: Dict[str, PowermartDocument]
    ) -> List[str]:
        """Get transformation types applied to data from this table."""
        transformations = set()
        table_name_lower = table_name.lower()

        for doc in documents.values():
            for mapping in doc.mappings:
                # Check if this table is a source in this mapping
                is_source_in_mapping = False
                for src_inst in mapping.source_instances:
                    if src_inst.transformation_name.lower() == table_name_lower:
                        is_source_in_mapping = True
                        break

                if is_source_in_mapping:
                    # Collect transformation types in this mapping
                    for trans in mapping.transformations:
                        # Handle both string and enum transformation_type
                        trans_type = trans.transformation_type
                        if hasattr(trans_type, 'value'):
                            trans_type = trans_type.value
                        trans_type_lower = str(trans_type).lower()
                        if trans_type_lower not in ("source qualifier", "target"):
                            transformations.add(trans_type_lower)

        return list(transformations)

    def _extract_primary_keys(
        self,
        table_name: str,
        documents: Dict[str, PowermartDocument]
    ) -> List[str]:
        """Extract primary key columns for a table."""
        primary_keys = []

        for doc in documents.values():
            # Check sources
            for source in doc.sources:
                if source.name.upper() == table_name.upper():
                    for field in source.fields:
                        if hasattr(field, "key_type") and field.key_type == "PRIMARY KEY":
                            primary_keys.append(field.name)

            # Check targets
            for target in doc.targets:
                if target.name.upper() == table_name.upper():
                    for field in target.fields:
                        if hasattr(field, "key_type") and field.key_type == "PRIMARY KEY":
                            primary_keys.append(field.name)

        return list(set(primary_keys))

    def _build_e2e_lineage(
        self,
        graph: UnifiedLineageGraph,
        lineage_results: Dict[str, LineageResult]
    ) -> List[Dict[str, Any]]:
        """
        Build end_to_end_lineage section.

        Contains table-level lineage paths from sources to targets.
        """
        lineage_entries = []

        # Get all end-to-end paths from the graph
        paths = graph.get_end_to_end_paths()

        for path in paths:
            if len(path) < 2:
                continue

            source_table = path[0]
            target_table = path[-1]
            intermediate = path[1:-1]

            # Get hop count from target table
            target_node = graph.tables.get(target_table)
            hop_count = target_node.hop_count if target_node else len(path) - 1

            # Collect lookup tables from the path
            lookup_tables = []
            for table in path:
                node = graph.tables.get(table)
                if node and node.node_type == NodeType.LOOKUP:
                    lookup_tables.append(table)

            entry = {
                "source_table": source_table,
                "target_table": target_table,
                "intermediate_tables": intermediate,
                "full_path": path,
                "hop_count": hop_count,
                "lookup_tables": lookup_tables,
                "has_aggregation": self._path_has_aggregation(path, graph),
                "has_filter": self._path_has_filter(path, graph),
            }
            lineage_entries.append(entry)

        # Also add cross-mapping lineage
        for link in graph.cross_mapping_links:
            # Check if this link creates a new path not already captured
            entry = {
                "source_table": link.source_table,
                "target_table": link.target_table,
                "intermediate_tables": [],
                "full_path": [link.source_table, link.target_table],
                "hop_count": 1,
                "lookup_tables": [],
                "cross_mapping": True,
                "source_mapping": link.source_mapping,
                "target_mapping": link.target_mapping,
                "link_type": link.link_type,
                "confidence": link.confidence,
            }
            lineage_entries.append(entry)

        return lineage_entries

    def _path_has_aggregation(self, path: List[str], graph: UnifiedLineageGraph) -> bool:
        """Check if any table in the path has aggregation."""
        from ..aggregation.aggregation_models import TransformationType
        for table_name in path:
            node = graph.tables.get(table_name)
            if node and TransformationType.AGGREGATE in node.transformation_types:
                return True
        return False

    def _path_has_filter(self, path: List[str], graph: UnifiedLineageGraph) -> bool:
        """Check if any table in the path has filtering."""
        from ..aggregation.aggregation_models import TransformationType
        for table_name in path:
            node = graph.tables.get(table_name)
            if node and TransformationType.FILTER in node.transformation_types:
                return True
        return False

    def _build_informatica_metadata(
        self,
        graph: UnifiedLineageGraph,
        parameter_catalog: Optional[ParameterCatalog]
    ) -> Dict[str, Any]:
        """
        Build informatica_metadata section.

        Contains Informatica-specific information for downstream processing.
        """
        metadata = {
            "unified_graph_summary": {
                "table_count": graph.table_count,
                "edge_count": graph.edge_count,
                "cross_mapping_link_count": len(graph.cross_mapping_links),
                "conflict_count": len(graph.conflicts),
                "source_xmls": graph.source_xmls,
            },
            "cross_mapping_links": [l.to_dict() for l in graph.cross_mapping_links],
            "conflicts": [c.to_dict() for c in graph.conflicts],
            "has_conflicts_requiring_review": graph.has_conflicts,
        }

        # Add parameters if available
        if parameter_catalog:
            metadata["parameters"] = parameter_catalog.to_dict()
            metadata["stored_procedure_params"] = parameter_catalog.to_stored_procedure_params()

        return metadata

    def _build_field_lineage(
        self,
        lineage_results: Dict[str, LineageResult]
    ) -> List[Dict[str, Any]]:
        """
        Build field_lineage section.

        Contains detailed field-level lineage for each target field.
        """
        field_lineage = []

        for xml_path, result in lineage_results.items():
            xml_name = os.path.basename(xml_path)

            for fl in result.field_lineages:
                entry = fl.to_dict()
                entry["source_xml"] = xml_name
                # Keep the per-lineage mapping_name (actual Informatica mapping name)
                # set by integration_expert; only fall back to result-level name
                # if missing.
                if not entry.get("mapping_name"):
                    entry["mapping_name"] = result.mapping_name
                field_lineage.append(entry)

        return field_lineage

    def _write_json(self, data: Dict[str, Any], output_path: str) -> None:
        """Write data to JSON file."""
        path = Path(output_path)
        path.parent.mkdir(parents=True, exist_ok=True)

        with open(path, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2, default=str)

        logger.info(f"Written AutoMedallion input to {output_path}")

    def export_conflicts_report(
        self,
        graph: UnifiedLineageGraph,
        output_path: str
    ) -> None:
        """
        Export a separate conflicts report for manual review.

        Args:
            graph: The unified lineage graph
            output_path: Path to write the conflicts JSON
        """
        if not graph.conflicts:
            logger.info("No conflicts to report")
            return

        report = {
            "report_type": "table_conflicts",
            "generated_at": datetime.now().isoformat(),
            "total_conflicts": len(graph.conflicts),
            "requires_manual_review": graph.has_conflicts,
            "conflicts": [c.to_dict() for c in graph.conflicts],
            "summary": {
                "by_type": {},
                "affected_tables": [c.table_name for c in graph.conflicts],
            },
        }

        # Summarize by type
        for conflict in graph.conflicts:
            ctype = conflict.conflict_type
            if ctype not in report["summary"]["by_type"]:
                report["summary"]["by_type"][ctype] = 0
            report["summary"]["by_type"][ctype] += 1

        self._write_json(report, output_path)
        logger.info(f"Written conflicts report to {output_path}")

    def _build_transformation_metadata(
        self,
        documents: Dict[str, PowermartDocument]
    ) -> Dict[str, Any]:
        """
        Build transformation metadata section for forward engineering.

        This method extracts detailed transformation metadata from Informatica
        documents that is needed for accurate Snowflake SQL generation.

        Includes:
        - Sequence Generator settings
        - Stored Procedure configuration
        - Rank transformation settings
        - Normalizer OCCURS metadata
        - Aggregator HAVING conditions
        - Source Qualifier Pre/Post SQL and User Defined Joins
        - Target load Pre/Post SQL
        - Update Strategy key columns

        Args:
            documents: Dictionary of xml_path -> PowermartDocument

        Returns:
            Dictionary containing all transformation metadata
        """
        # Reset extractor for fresh extraction
        self._transformation_extractor.reset()

        # Extract metadata from all documents
        catalog = self._transformation_extractor.extract_from_documents(documents)

        # Convert to dictionary for JSON serialization
        return catalog.to_dict()

    def _build_transformation_graphs(
        self,
        documents: Dict[str, PowermartDocument]
    ) -> Dict[str, Any]:
        """
        Build comprehensive transformation graphs for complete business logic capture.

        This method extracts COMPLETE transformation logic including:
        - Router groups with conditions and target instance mappings
        - Joiner conditions and join types
        - Lookup conditions and SQL overrides
        - Filter conditions
        - Aggregator groups and expressions
        - Update Strategy flags
        - All other transformation types

        This ensures ZERO business logic loss during Informatica to Snowflake conversion.

        Args:
            documents: Dictionary of xml_path -> PowermartDocument

        Returns:
            Dictionary mapping mapping_name -> MappingTransformationGraph
        """
        logger.info("Extracting comprehensive transformation graphs")

        transformation_graphs = {}

        for xml_path, doc in documents.items():
            # Need to parse the XML directly for transformation graph extraction
            import defusedxml.ElementTree as DefusedET
            tree = DefusedET.parse(xml_path)
            root = tree.getroot()

            # Extract transformation graph for each mapping
            for mapping_elem in root.iter('MAPPING'):
                try:
                    mapping_graph = self._comprehensive_transformation_extractor.extract_mapping_graph(
                        xml_path,
                        mapping_elem
                    )
                    transformation_graphs[mapping_graph.mapping_name] = mapping_graph.to_dict()

                    logger.info(
                        f"  Extracted transformation graph for '{mapping_graph.mapping_name}': "
                        f"{len(mapping_graph.routers)} Routers, "
                        f"{len(mapping_graph.joiners)} Joiners, "
                        f"{len(mapping_graph.lookups)} Lookups, "
                        f"{len(mapping_graph.target_instances)} target instances"
                    )

                    # Log critical Router scenarios
                    if mapping_graph.has_multiple_target_instances():
                        router_count = len(mapping_graph.routers)
                        target_count = len(mapping_graph.target_instances)
                        logger.warning(
                            f"  ⚠ CRITICAL: Mapping '{mapping_graph.mapping_name}' has "
                            f"{router_count} Router(s) with {target_count} target instances. "
                            f"This requires multiple INSERT statements."
                        )

                except Exception as e:
                    logger.error(
                        f"  Failed to extract transformation graph from {xml_path}: {e}",
                        exc_info=True
                    )

        logger.info(f"Transformation graph extraction complete: {len(transformation_graphs)} mappings")

        return transformation_graphs

    def _build_expression_details(
        self,
        documents: Dict[str, PowermartDocument]
    ) -> List[Dict[str, Any]]:
        """Build a flat list of all expression transformation fields across all mappings.

        This provides the same data that the Excel "Expression Details" sheet
        contains, so the JSON is self-contained for forward engineering consumers.

        Each entry contains:
        - session_name: the session that runs this mapping
        - mapping_name: the mapping containing the expression
        - transformation_name: the expression transformation name
        - field_name: the output/variable field name
        - expression: the Informatica expression text
        - datatype: field datatype with precision
        - port_type: INPUT, OUTPUT, INPUT/OUTPUT, or LOCAL VARIABLE

        Returns:
            List of expression detail dicts
        """
        details: List[Dict[str, Any]] = []

        for xml_path, doc in documents.items():
            # Build mapping_name -> session_name lookup
            mapping_to_session: Dict[str, str] = {}
            for session in doc.sessions:
                m_name = session.mapping_name or ""
                if m_name:
                    # Strip sc_ prefix if present
                    clean = m_name[3:] if m_name.lower().startswith("sc_") else m_name
                    mapping_to_session[clean.lower()] = session.name

            for mapping in doc.mappings:
                session_name = mapping_to_session.get(mapping.name.lower(), "")

                for trans in mapping.transformations:
                    ttype = str(trans.transformation_type).lower()
                    if "expression" not in ttype:
                        continue

                    # Build connector lookups for lineage
                    in_map: Dict[str, str] = {}
                    for c in mapping.get_connectors_to(trans.name):
                        in_map[c.to_field.lower()] = f"{c.from_instance}.{c.from_field}"
                    out_map: Dict[str, List[str]] = {}
                    for c in mapping.get_connectors_from(trans.name):
                        out_map.setdefault(c.from_field.lower(), []).append(
                            f"{c.to_instance}.{c.to_field}")

                    for fld in trans.fields:
                        expr = fld.expression if fld.expression else ""
                        # Determine port type
                        port_type = getattr(fld, "port_type", "")
                        if not port_type:
                            is_input = getattr(fld, "is_input", False)
                            is_output = getattr(fld, "is_output", False)
                            is_local = getattr(fld, "is_local_variable", False)
                            if is_local:
                                port_type = "LOCAL VARIABLE"
                            elif is_input and is_output:
                                port_type = "INPUT/OUTPUT"
                            elif is_output:
                                port_type = "OUTPUT"
                            elif is_input:
                                port_type = "INPUT"

                        dt = getattr(fld, "datatype", "") or ""
                        prec = getattr(fld, "precision", "") or ""
                        scale = getattr(fld, "scale", "") or ""
                        full_dt = f"{dt}({prec})" if prec else str(dt)
                        if scale and str(scale) != "0":
                            full_dt = f"{dt}({prec},{scale})"

                        input_field = in_map.get(fld.name.lower(), "")
                        output_field = "; ".join(out_map.get(fld.name.lower(), []))

                        details.append({
                            "session_name": session_name,
                            "mapping_name": mapping.name,
                            "transformation_name": trans.name,
                            "field_name": fld.name,
                            "expression": expr,
                            "datatype": full_dt,
                            "port_type": port_type,
                            "input_field": input_field,
                            "output_field": output_field,
                        })

        return details
