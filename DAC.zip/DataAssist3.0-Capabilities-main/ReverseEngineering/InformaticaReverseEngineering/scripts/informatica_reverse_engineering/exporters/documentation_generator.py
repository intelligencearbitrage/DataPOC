"""Documentation generator for lineage results."""

from pathlib import Path
from typing import Any, Dict, Optional, Union
from datetime import datetime

from ..models.lineage_models import LineageResult
from ..parsers.powermart_parser import PowermartDocument
from werkzeug.utils import safe_join
from ..utils.logging_config import get_logger

logger = get_logger("documentation_generator")


class DocumentationGenerator:
    """Generates HTML documentation for lineage analysis."""

    def __init__(self):
        pass

    def generate(
        self,
        lineage_result: LineageResult,
        document: PowermartDocument,
        output_path: Union[str, Path],
        title: str = "Informatica Lineage Analysis",
        integration_data: Optional[Dict] = None,
    ) -> str:
        """
        Generate HTML documentation.

        Args:
            lineage_result: The lineage analysis result
            document: The original PowermartDocument
            output_path: Path for the output file
            title: Document title
            integration_data: Optional additional data

        Returns:
            Path to the created file
        """
        _raw = Path(output_path)
        output_path = Path(safe_join(str(_raw.parent), _raw.name))
        output_path.parent.mkdir(parents=True, exist_ok=True)

        logger.info(f"Generating documentation: {output_path}")

        html_content = self._generate_html(lineage_result, document, title, integration_data)

        with open(output_path, 'w', encoding='utf-8') as f:
            f.write(html_content)

        logger.info(f"Documentation generated: {output_path}")
        return str(output_path)

    def generate_per_mapping(
        self,
        lineage_result: LineageResult,
        document: PowermartDocument,
        output_dir,
        title: str = "Informatica Lineage Analysis",
        integration_data=None,
    ):
        """
        Generate separate HTML documentation for each mapping.

        Returns:
            List of paths to created files
        """
        from pathlib import Path
        output_dir = Path(output_dir)
        output_dir.mkdir(parents=True, exist_ok=True)

        created_files = []

        for mapping in document.mappings:
            mapping_name = mapping.name

            # Build mapping-specific sources/targets
            mapping_sources = list(mapping.sources)
            if not mapping_sources:
                source_inst_names = {inst.transformation_name.lower() for inst in mapping.source_instances}
                for src in document.sources:
                    for inst_name in source_inst_names:
                        clean_inst = inst_name.replace('sq_', '').replace('sc_', '').replace('src_', '')
                        if clean_inst in src.name.lower() or src.name.lower() in clean_inst:
                            mapping_sources.append(src)
                            break

            mapping_targets = list(mapping.targets)
            if not mapping_targets:
                target_inst_names = {inst.transformation_name.lower() for inst in mapping.target_instances}
                for tgt in document.targets:
                    for inst_name in target_inst_names:
                        clean_inst = inst_name.replace('sc_', '').replace('tgt_', '')
                        if clean_inst in tgt.name.lower() or tgt.name.lower() in clean_inst:
                            mapping_targets.append(tgt)
                            break

            # Filter lineage for this mapping's targets
            target_names = {t.name.lower() for t in mapping_targets}
            for inst in mapping.target_instances:
                target_names.add(inst.transformation_name.lower())

            mapping_lineages = [
                l for l in lineage_result.field_lineages
                if l.target_table and l.target_table.lower() in target_names
            ]

            # Create a filtered LineageResult
            from ..models.lineage_models import LineageResult as LR
            filtered_result = LR(
                mapping_name=mapping_name,
                source_count=len(mapping_sources),
                target_count=len(mapping_targets),
                transformation_count=len(mapping.transformations),
                field_lineages=mapping_lineages,
            )

            # Create mini document
            mini_doc = PowermartDocument(
                creation_date=document.creation_date,
                repository_version=document.repository_version,
                repository=document.repository,
                folder=document.folder,
                sources=mapping_sources,
                targets=mapping_targets,
                transformations=mapping.transformations[:],
                mappings=[mapping],
                sessions=[s for s in document.sessions if s.mapping_name == mapping_name],
                workflows=document.workflows,
                worklets=document.worklets,
                file_path=document.file_path
            )

            safe_name = "".join(c if c.isalnum() or c in ('_', '-') else '_' for c in mapping_name)
            html_path = output_dir / f"{safe_name}_documentation.html"

            html_content = self._generate_html(
                filtered_result, mini_doc, f"{title} - {mapping_name}", integration_data
            )

            with open(html_path, 'w', encoding='utf-8') as f:
                f.write(html_content)

            created_files.append(str(html_path))
            logger.info(f"Created: {html_path}")

        return created_files

    def _generate_html(
        self,
        lineage_result: LineageResult,
        document: PowermartDocument,
        title: str,
        integration_data: Optional[Dict],
    ) -> str:
        """Generate the HTML content."""
        return f"""<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{title}</title>
    <style>
        :root {{
            --primary-color: #4472C4;
            --secondary-color: #6c757d;
            --success-color: #28a745;
            --warning-color: #ffc107;
            --danger-color: #dc3545;
            --light-bg: #f8f9fa;
            --border-color: #dee2e6;
        }}
        body {{
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, sans-serif;
            margin: 0;
            padding: 20px;
            background-color: var(--light-bg);
            color: #333;
        }}
        .container {{
            max-width: 1400px;
            margin: 0 auto;
            background: white;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }}
        h1 {{
            color: var(--primary-color);
            border-bottom: 3px solid var(--primary-color);
            padding-bottom: 15px;
        }}
        h2 {{
            color: var(--primary-color);
            margin-top: 30px;
        }}
        h3 {{
            color: var(--secondary-color);
        }}
        .stats-grid {{
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin: 20px 0;
        }}
        .stat-card {{
            background: var(--light-bg);
            padding: 20px;
            border-radius: 8px;
            text-align: center;
            border-left: 4px solid var(--primary-color);
        }}
        .stat-value {{
            font-size: 2rem;
            font-weight: bold;
            color: var(--primary-color);
        }}
        .stat-label {{
            color: var(--secondary-color);
            font-size: 0.9rem;
        }}
        table {{
            width: 100%;
            border-collapse: collapse;
            margin: 20px 0;
            font-size: 0.9rem;
        }}
        th, td {{
            padding: 12px;
            text-align: left;
            border: 1px solid var(--border-color);
        }}
        th {{
            background: var(--primary-color);
            color: white;
            font-weight: 600;
            position: sticky;
            top: 0;
        }}
        tr:nth-child(even) {{
            background-color: var(--light-bg);
        }}
        tr:hover {{
            background-color: #e9ecef;
        }}
        .badge {{
            display: inline-block;
            padding: 3px 8px;
            border-radius: 12px;
            font-size: 0.8rem;
            font-weight: 500;
        }}
        .badge-success {{ background: var(--success-color); color: white; }}
        .badge-warning {{ background: var(--warning-color); color: #333; }}
        .badge-danger {{ background: var(--danger-color); color: white; }}
        .badge-info {{ background: var(--primary-color); color: white; }}
        .expression {{
            font-family: 'Courier New', monospace;
            background: #f5f5f5;
            padding: 2px 6px;
            border-radius: 3px;
            font-size: 0.85rem;
        }}
        .collapsible {{
            background: var(--light-bg);
            border: none;
            padding: 15px;
            width: 100%;
            text-align: left;
            cursor: pointer;
            font-size: 1rem;
            border-radius: 4px;
            margin: 5px 0;
        }}
        .collapsible:hover {{
            background: #e9ecef;
        }}
        .collapsible:after {{
            content: '+';
            float: right;
            font-weight: bold;
        }}
        .collapsible.active:after {{
            content: '-';
        }}
        .content {{
            display: none;
            padding: 15px;
            background: white;
            border: 1px solid var(--border-color);
            border-radius: 4px;
        }}
        .footer {{
            margin-top: 40px;
            padding-top: 20px;
            border-top: 1px solid var(--border-color);
            text-align: center;
            color: var(--secondary-color);
            font-size: 0.9rem;
        }}
    </style>
</head>
<body>
    <div class="container">
        <h1>{title}</h1>

        <h2>Document Information</h2>
        <div class="stats-grid">
            <div class="stat-card">
                <div class="stat-label">File</div>
                <div style="font-size: 0.9rem; word-break: break-all;">{document.file_path or 'N/A'}</div>
            </div>
            <div class="stat-card">
                <div class="stat-label">Creation Date</div>
                <div>{document.creation_date}</div>
            </div>
            <div class="stat-card">
                <div class="stat-label">Repository</div>
                <div>{document.repository.name if document.repository else 'N/A'}</div>
            </div>
            <div class="stat-card">
                <div class="stat-label">Folder</div>
                <div>{document.folder.name if document.folder else 'N/A'}</div>
            </div>
        </div>

        <h2>Statistics</h2>
        <div class="stats-grid">
            <div class="stat-card">
                <div class="stat-value">{lineage_result.source_count}</div>
                <div class="stat-label">Sources</div>
            </div>
            <div class="stat-card">
                <div class="stat-value">{lineage_result.target_count}</div>
                <div class="stat-label">Targets</div>
            </div>
            <div class="stat-card">
                <div class="stat-value">{lineage_result.transformation_count}</div>
                <div class="stat-label">Transformations</div>
            </div>
            <div class="stat-card">
                <div class="stat-value">{len(lineage_result.field_lineages)}</div>
                <div class="stat-label">Field Lineages</div>
            </div>
            <div class="stat-card">
                <div class="stat-value">{lineage_result.coverage_percentage:.1f}%</div>
                <div class="stat-label">Coverage</div>
            </div>
        </div>

        <h2>Source to Target Lineage</h2>
        {self._generate_lineage_table(lineage_result)}

        <h2>Mapping Flow Summary</h2>
        {self._generate_mapping_flow_summary(document)}

        <h2>Sources</h2>
        {self._generate_sources_section(document)}

        <h2>Targets</h2>
        {self._generate_targets_section(document)}

        <h2>Mappings</h2>
        {self._generate_mappings_section(document)}

        <h2>Worklets</h2>
        {self._generate_worklets_section(document)}

        <h2>Session Details</h2>
        {self._generate_session_details_section(document, integration_data)}

        <h2>Joiners</h2>
        {self._generate_joiners_section(integration_data)}

        <h2>Stored Procedures</h2>
        {self._generate_stored_procedures_section(document, integration_data)}

        <h2>Source Filters</h2>
        {self._generate_source_filters_section(document, integration_data)}

        <h2>Session Commands</h2>
        {self._generate_session_commands_section(integration_data)}

        <div class="footer">
            Generated on {datetime.now().strftime('%Y-%m-%d %H:%M:%S')} by Informatica Reverse Engineering Tool
        </div>
    </div>

    <script>
        document.querySelectorAll('.collapsible').forEach(button => {{
            button.addEventListener('click', function() {{
                this.classList.toggle('active');
                var content = this.nextElementSibling;
                content.style.display = content.style.display === 'block' ? 'none' : 'block';
            }});
        }});
    </script>
</body>
</html>"""

    def _generate_lineage_table(self, lineage_result: LineageResult) -> str:
        """Generate lineage table HTML."""
        if not lineage_result.field_lineages:
            return "<p>No field lineages found.</p>"

        rows = []
        for lineage in lineage_result.field_lineages:
            sources = ", ".join(lineage.source_tables)
            has_trans = '<span class="badge badge-info">Yes</span>' if lineage.has_transformation else '<span class="badge badge-secondary">No</span>'

            rows.append(f"""
                <tr>
                    <td>{lineage.mapping_name}</td>
                    <td>{lineage.target_table}</td>
                    <td>{lineage.target_field}</td>
                    <td>{sources}</td>
                    <td class="expression">{lineage.transformation_chain[:100]}{'...' if len(lineage.transformation_chain) > 100 else ''}</td>
                    <td>{lineage.hop_count}</td>
                    <td>{has_trans}</td>
                </tr>""")

        return f"""
        <table>
            <thead>
                <tr>
                    <th>Mapping Name</th>
                    <th>Target Table</th>
                    <th>Target Field</th>
                    <th>Source Table(s)</th>
                    <th>Transformation</th>
                    <th>Hops</th>
                    <th>Has Transform</th>
                </tr>
            </thead>
            <tbody>
                {''.join(rows)}
            </tbody>
        </table>"""

    def _generate_mapping_flow_summary(self, document: PowermartDocument) -> str:
        """Generate mapping flow summary HTML showing sequence, sources, targets, and dependencies."""
        from ..utils.mapping_flow_utils import build_mapping_flow_summary

        if not document.mappings:
            return "<p>No mappings found.</p>"

        summary = build_mapping_flow_summary(document)

        rows = []
        for entry in summary:
            deps = entry["depends_on_mapping"]
            deps_html = ", ".join(deps) if deps else '<span class="badge badge-success">None (Entry Point)</span>'
            rows.append(f"""
                <tr>
                    <td>{entry["sequence"]}</td>
                    <td><strong>{entry["mapping_name"]}</strong></td>
                    <td>{", ".join(entry["source_tables"])}</td>
                    <td>{", ".join(entry["target_tables"])}</td>
                    <td>{deps_html}</td>
                    <td>{entry["session_name"] or ""}</td>
                    <td>{entry["workflow_name"] or ""}</td>
                </tr>""")

        return f"""
        <table>
            <thead>
                <tr>
                    <th>Sequence</th>
                    <th>Mapping Name</th>
                    <th>Source Tables</th>
                    <th>Target Tables</th>
                    <th>Depends On Mapping</th>
                    <th>Session Name</th>
                    <th>Workflow Name</th>
                </tr>
            </thead>
            <tbody>
                {''.join(rows)}
            </tbody>
        </table>"""

    def _generate_sources_section(self, document: PowermartDocument) -> str:
        """Generate sources section HTML with Mapping Name."""
        # Build source-to-mapping lookup
        source_to_mappings = {}
        for mapping in document.mappings:
            for inst in mapping.source_instances:
                inst_name = inst.transformation_name.lower()
                clean_inst = inst_name.replace('sq_', '').replace('sc_', '').replace('src_', '')
                source_to_mappings.setdefault(inst_name, set()).add(mapping.name)
                source_to_mappings.setdefault(clean_inst, set()).add(mapping.name)
            for src in mapping.sources:
                source_to_mappings.setdefault(src.name.lower(), set()).add(mapping.name)

        sections = []
        for source in document.sources:
            src_lower = source.name.lower()
            mapping_names_set = source_to_mappings.get(src_lower, set())
            if not mapping_names_set:
                for key, names in source_to_mappings.items():
                    if key in src_lower or src_lower in key:
                        mapping_names_set = mapping_names_set | names
            mapping_names = ", ".join(sorted(mapping_names_set))
            mapping_label = f" | <strong>Mapping:</strong> {mapping_names}" if mapping_names else ""
            fields_html = "".join([
                f"<tr><td>{f.name}</td><td>{f.full_datatype}</td><td>{f.keytype}</td></tr>"
                for f in source.fields
            ])
            sections.append(f"""
            <button class="collapsible">{source.name} ({source.field_count} fields)</button>
            <div class="content">
                <p><strong>Database:</strong> {source.db_dname} | <strong>Owner:</strong> {source.owner_name}{mapping_label}</p>
                <table>
                    <thead><tr><th>Field</th><th>Datatype</th><th>Key Type</th></tr></thead>
                    <tbody>{fields_html}</tbody>
                </table>
            </div>""")
        return "".join(sections) if sections else "<p>No sources found.</p>"

    def _generate_targets_section(self, document: PowermartDocument) -> str:
        """Generate targets section HTML, ordered by load plan when available, with Mapping Name."""
        # Build target-to-mapping lookup
        target_to_mappings = {}
        for mapping in document.mappings:
            for inst in mapping.target_instances:
                inst_name = inst.transformation_name.lower()
                target_to_mappings.setdefault(inst_name, set()).add(mapping.name)
                # Strip common prefixes to match document-level target names
                clean = inst_name.replace('sc_to_', '').replace('sc_', '').replace('tgt_', '')
                if clean != inst_name:
                    target_to_mappings.setdefault(clean, set()).add(mapping.name)
            for tgt in mapping.targets:
                target_to_mappings.setdefault(tgt.name.lower(), set()).add(mapping.name)

        # Build target load order lookup
        target_load_positions = {}
        for mapping in document.mappings:
            if mapping.target_load_order:
                for idx, tgt_name in enumerate(mapping.target_load_order, 1):
                    target_load_positions[tgt_name.lower()] = idx

        # Sort targets by load order if available
        targets_sorted = sorted(
            document.targets,
            key=lambda t: target_load_positions.get(t.name.lower(), 999)
        )

        sections = []
        for target in targets_sorted:
            load_seq = target_load_positions.get(target.name.lower())
            seq_label = f" - Load Sequence #{load_seq}" if load_seq else ""
            tgt_lower = target.name.lower()
            mapping_names_set = target_to_mappings.get(tgt_lower, set())
            if not mapping_names_set:
                for key, names in target_to_mappings.items():
                    if key in tgt_lower or tgt_lower in key:
                        mapping_names_set = mapping_names_set | names
            mapping_names = ", ".join(sorted(mapping_names_set))
            mapping_label = f" | <strong>Mapping:</strong> {mapping_names}" if mapping_names else ""
            fields_html = "".join([
                f"<tr><td>{f.name}</td><td>{f.full_datatype}</td><td>{f.keytype}</td></tr>"
                for f in target.fields
            ])
            sections.append(f"""
            <button class="collapsible">{target.name} ({target.field_count} fields{seq_label})</button>
            <div class="content">
                <p><strong>Database Type:</strong> {target.database_type}{mapping_label}</p>
                <table>
                    <thead><tr><th>Field</th><th>Datatype</th><th>Key Type</th></tr></thead>
                    <tbody>{fields_html}</tbody>
                </table>
            </div>""")
        return "".join(sections) if sections else "<p>No targets found.</p>"

    def _generate_mappings_section(self, document: PowermartDocument) -> str:
        """Generate mappings section HTML."""
        sections = []
        for mapping in document.mappings:
            trans_list = "".join([
                f"<li><strong>{t.name}</strong> ({t.type})</li>"
                for t in mapping.transformations
            ])
            load_order_html = ""
            if mapping.target_load_order:
                load_items = "".join([
                    f"<li>{idx}. {name}</li>"
                    for idx, name in enumerate(mapping.target_load_order, 1)
                ])
                load_order_html = f"<p><strong>Target Load Order:</strong></p><ol>{load_items}</ol>"

            sections.append(f"""
            <button class="collapsible">{mapping.name}</button>
            <div class="content">
                <p><strong>Valid:</strong> {'Yes' if mapping.is_valid else 'No'}</p>
                <p><strong>Transformations:</strong></p>
                <ul>{trans_list}</ul>
                {load_order_html}
            </div>""")
        return "".join(sections) if sections else "<p>No mappings found.</p>"

    def _generate_worklets_section(self, document: PowermartDocument) -> str:
        """Generate worklets section HTML."""
        if not hasattr(document, 'worklets') or not document.worklets:
            return "<p>No worklets found.</p>"

        sections = []
        for worklet in document.worklets:
            task_list = "".join([
                f"<li><strong>{t.name}</strong> ({t.task_type})</li>"
                for t in worklet.tasks
            ])
            session_list = "".join([
                f"<li><strong>{s.name}</strong> (mapping: {s.mapping_name})</li>"
                for s in worklet.sessions
            ])
            exec_order = ", ".join(worklet.get_execution_order())

            sections.append(f"""
            <button class="collapsible">{worklet.name} ({len(worklet.tasks)} tasks, {len(worklet.sessions)} sessions)</button>
            <div class="content">
                <p><strong>Execution Order:</strong> {exec_order}</p>
                <p><strong>Tasks:</strong></p>
                <ul>{task_list}</ul>
                <p><strong>Sessions:</strong></p>
                <ul>{session_list if session_list else '<li>None</li>'}</ul>
            </div>""")
        return "".join(sections)

    def _generate_session_details_section(self, document: PowermartDocument, integration_data: Optional[Dict]) -> str:
        """Generate session details section showing Pre/Post SQL, overrides, owner_name, source_table_name."""
        if not integration_data:
            return "<p>No session metadata available.</p>"

        structure_data = integration_data.get("expert_results", {}).get("MappingStructure", {}).get("data", {})
        pre_sql = structure_data.get("session_pre_sql", [])
        post_sql = structure_data.get("session_post_sql", [])
        sql_overrides = structure_data.get("session_sql_overrides", [])
        source_overrides = structure_data.get("source_table_overrides", [])
        owner_overrides = structure_data.get("owner_name_overrides", [])

        if not any([pre_sql, post_sql, sql_overrides, source_overrides, owner_overrides]):
            return "<p>No session-level SQL metadata found.</p>"

        rows = []
        all_items = (
            [(item, "Pre SQL", item.get("sql", "")) for item in pre_sql] +
            [(item, "Post SQL", item.get("sql", "")) for item in post_sql] +
            [(item, "SQL Override", item.get("sql", "")) for item in sql_overrides] +
            [(item, "Source Table Override", item.get("table_name", "")) for item in source_overrides] +
            [(item, "Owner Name", item.get("owner_name", "")) for item in owner_overrides] +
            [(item, "Source Table Name", item.get("source_table_name", "")) for item in owner_overrides if item.get("source_table_name")]
        )

        for item, detail_type, value in all_items:
            rows.append(f"""
                <tr>
                    <td>{item.get('session', '')}</td>
                    <td>{item.get('instance', '')}</td>
                    <td>{detail_type}</td>
                    <td class="expression">{value}</td>
                </tr>""")

        return f"""
        <table>
            <thead>
                <tr>
                    <th>Session</th>
                    <th>Instance</th>
                    <th>Detail Type</th>
                    <th>Value</th>
                </tr>
            </thead>
            <tbody>
                {''.join(rows)}
            </tbody>
        </table>""" if rows else "<p>No session-level SQL metadata found.</p>"

    def _generate_joiners_section(self, integration_data: Optional[Dict]) -> str:
        """Generate joiners section HTML (Observation 7)."""
        if not integration_data:
            return "<p>No joiner information available.</p>"

        joiners = integration_data.get("expert_results", {}).get("OperatorLogic", {}).get("data", {}).get("joiners", [])
        if not joiners:
            return "<p>No joiners found.</p>"

        rows = []
        for j in joiners:
            input_fields = j.get("input_fields", [])
            output_fields = j.get("output_fields", [])
            in_str = ", ".join(input_fields) if isinstance(input_fields, list) else str(input_fields)
            out_str = ", ".join(output_fields) if isinstance(output_fields, list) else str(output_fields)
            rows.append(f"""
                <tr>
                    <td>{j.get("mapping", "")}</td>
                    <td>{j.get("name", "")}</td>
                    <td class="expression">{j.get("join_condition", "")}</td>
                    <td>{j.get("join_type", "")}</td>
                    <td>{j.get("sorted_input", "")}</td>
                    <td>{j.get("master_table", "")}</td>
                    <td>{j.get("detail_table", "")}</td>
                </tr>""")

        return f"""
        <table>
            <thead>
                <tr>
                    <th>Mapping</th>
                    <th>Joiner Name</th>
                    <th>Join Condition</th>
                    <th>Join Type</th>
                    <th>Sorted Input</th>
                    <th>Master Table</th>
                    <th>Detail Table</th>
                </tr>
            </thead>
            <tbody>
                {''.join(rows)}
            </tbody>
        </table>"""

    def _generate_stored_procedures_section(self, document: PowermartDocument, integration_data: Optional[Dict]) -> str:
        """Generate stored procedures section HTML (Observation 3)."""
        if not integration_data:
            return "<p>No stored procedure information available.</p>"

        sps = integration_data.get("expert_results", {}).get("OperatorLogic", {}).get("data", {}).get("stored_procedures", [])
        if not sps:
            return "<p>No stored procedures found.</p>"

        # Build SP name -> mapping name(s) lookup from mapping instances
        sp_to_mappings: dict = {}
        for mapping in document.mappings:
            for inst in mapping.instances:
                inst_name_lower = inst.transformation_name.lower() if hasattr(inst, 'transformation_name') else inst.name.lower()
                if inst_name_lower:
                    sp_to_mappings.setdefault(inst_name_lower, set()).add(mapping.name)
                    clean = inst_name_lower.replace('sc_', '').replace('src_', '')
                    if clean != inst_name_lower:
                        sp_to_mappings.setdefault(clean, set()).add(mapping.name)

        rows = []
        for sp in sps:
            sp_name_lower = sp.get("name", "").lower()
            mapping_names_set = sp_to_mappings.get(sp_name_lower, set())
            if not mapping_names_set:
                for key, names in sp_to_mappings.items():
                    if sp_name_lower and (sp_name_lower in key or key in sp_name_lower):
                        mapping_names_set = mapping_names_set | names
            mapping_names = ", ".join(sorted(mapping_names_set))
            rows.append(f"""
                <tr>
                    <td>{mapping_names}</td>
                    <td>{sp.get("mapping", "")}</td>
                    <td>{sp.get("name", "")}</td>
                    <td>{sp.get("procedure_name", "")}</td>
                    <td>{sp.get("procedure_type", "")}</td>
                    <td>{sp.get("connection_info", "")}</td>
                    <td class="expression">{sp.get("call_text", "")}</td>
                    <td>{sp.get("execution_order", "")}</td>
                </tr>""")

        return f"""
        <table>
            <thead>
                <tr>
                    <th>Mapping Name</th>
                    <th>Mapping</th>
                    <th>Transformation</th>
                    <th>Procedure Name</th>
                    <th>Type</th>
                    <th>Connection</th>
                    <th>Call Text</th>
                    <th>Execution Order</th>
                </tr>
            </thead>
            <tbody>
                {''.join(rows)}
            </tbody>
        </table>"""

    def _generate_source_filters_section(self, document: PowermartDocument, integration_data: Optional[Dict]) -> str:
        """Generate source filters section HTML (Observations 1 & 2)."""
        if not integration_data:
            return "<p>No source filter information available.</p>"

        op_data = integration_data.get("expert_results", {}).get("OperatorLogic", {}).get("data", {})
        sq_filters = op_data.get("source_filters", [])
        struct_data = integration_data.get("expert_results", {}).get("MappingStructure", {}).get("data", {})
        session_filters = struct_data.get("source_filters", [])

        # Document-level table attribute filters
        doc_filters = []
        for source in document.sources:
            for attr in getattr(source, 'table_attributes', []):
                if attr.get("name", "").lower() == "source filter" and attr.get("value"):
                    doc_filters.append({"source": source.name, "value": attr["value"]})

        if not any([sq_filters, session_filters, doc_filters]):
            return "<p>No source filters found.</p>"

        rows = []
        for sf in sq_filters:
            filter_text = sf.get("source_filter", "").replace("\r\n", " ").replace("\n", " ").strip()
            rows.append(f"""
                <tr>
                    <td>{sf.get("mapping", "")}</td>
                    <td>{sf.get("transformation", "")}</td>
                    <td><span class="badge badge-info">Source Qualifier</span></td>
                    <td class="expression">{filter_text}</td>
                </tr>""")
        for sf in session_filters:
            filter_text = sf.get("source_filter", "").replace("\r\n", " ").replace("\n", " ").strip()
            rows.append(f"""
                <tr>
                    <td>{sf.get("mapping", sf.get("session", ""))}</td>
                    <td>{sf.get("instance", "")}</td>
                    <td><span class="badge badge-warning">Session Extension</span></td>
                    <td class="expression">{filter_text}</td>
                </tr>""")
        for df in doc_filters:
            filter_text = df["value"].replace("\r\n", " ").replace("\n", " ").strip()
            rows.append(f"""
                <tr>
                    <td></td>
                    <td>{df["source"]}</td>
                    <td><span class="badge badge-success">Table Attribute</span></td>
                    <td class="expression">{filter_text}</td>
                </tr>""")

        return f"""
        <table>
            <thead>
                <tr>
                    <th>Mapping</th>
                    <th>Source/Transformation</th>
                    <th>Filter Source</th>
                    <th>Source Filter</th>
                </tr>
            </thead>
            <tbody>
                {''.join(rows)}
            </tbody>
        </table>"""

    def _generate_session_commands_section(self, integration_data: Optional[Dict]) -> str:
        """Generate session commands section HTML (Observation 4)."""
        if not integration_data:
            return "<p>No session command information available.</p>"

        commands = integration_data.get("expert_results", {}).get("MappingStructure", {}).get("data", {}).get("session_commands", [])
        if not commands:
            return "<p>No session commands found.</p>"

        rows = []
        for cmd in commands:
            value_pairs = cmd.get("value_pairs", [])
            if value_pairs:
                for vp in value_pairs:
                    rows.append(f"""
                <tr>
                    <td>{cmd.get("session", "")}</td>
                    <td>{cmd.get("component_name", "")}</td>
                    <td>{cmd.get("component_type", "")}</td>
                    <td>{vp.get("exec_order", "")}</td>
                    <td>{vp.get("name", "")}</td>
                    <td class="expression">{vp.get("value", "")}</td>
                </tr>""")
            elif cmd.get("attributes"):
                for attr_name, attr_value in cmd["attributes"].items():
                    rows.append(f"""
                <tr>
                    <td>{cmd.get("session", "")}</td>
                    <td>{cmd.get("component_name", "")}</td>
                    <td>{cmd.get("component_type", "")}</td>
                    <td></td>
                    <td>{attr_name}</td>
                    <td class="expression">{attr_value}</td>
                </tr>""")
            else:
                rows.append(f"""
                <tr>
                    <td>{cmd.get("session", "")}</td>
                    <td>{cmd.get("component_name", "")}</td>
                    <td>{cmd.get("component_type", "")}</td>
                    <td></td>
                    <td></td>
                    <td></td>
                </tr>""")

        return f"""
        <table>
            <thead>
                <tr>
                    <th>Session</th>
                    <th>Component</th>
                    <th>Type</th>
                    <th>Exec Order</th>
                    <th>Variable/Command</th>
                    <th>Value</th>
                </tr>
            </thead>
            <tbody>
                {''.join(rows)}
            </tbody>
        </table>"""
