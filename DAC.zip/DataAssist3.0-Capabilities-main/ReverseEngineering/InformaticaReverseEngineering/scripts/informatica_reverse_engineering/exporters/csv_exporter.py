"""CSV exporter for lineage results."""

import csv
from pathlib import Path
from typing import Any, Dict, List, Optional, Union

from ..models.lineage_models import LineageResult
from ..parsers.powermart_parser import PowermartDocument
from werkzeug.utils import safe_join
from ..utils.logging_config import get_logger
from ..utils.path_utils import sanitize_csv_row

logger = get_logger("csv_exporter")


def _safe_writerow(writer, row):
    """Write a row to CSV with formula injection protection."""
    if isinstance(row, dict):
        writer.writerow(sanitize_csv_row(row))
    else:
        writer.writerow(row)


class CSVExporter:
    """Exports lineage results to CSV format."""

    def export(
        self,
        lineage_result: LineageResult,
        document: PowermartDocument,
        output_dir: Union[str, Path],
        prefix: str = "",
        integration_data: Optional[Dict] = None,
    ) -> List[str]:
        """
        Export lineage results to multiple CSV files.

        Args:
            lineage_result: The lineage analysis result
            document: The original PowermartDocument
            output_dir: Directory for output files
            prefix: Optional prefix for file names
            integration_data: Optional additional data from integration expert

        Returns:
            List of paths to created files
        """
        _raw_dir = Path(output_dir)
        output_dir = Path(safe_join(str(_raw_dir.parent), _raw_dir.name))
        output_dir.mkdir(parents=True, exist_ok=True)

        logger.info(f"Exporting lineage to CSV in: {output_dir}")

        created_files = []

        # Export lineage
        lineage_path = safe_join(str(output_dir), f"{prefix}lineage.csv")
        self._export_lineage(lineage_result, lineage_path)
        created_files.append(str(lineage_path))

        # Export sources
        sources_path = safe_join(str(output_dir), f"{prefix}sources.csv")
        self._export_sources(document, sources_path)
        created_files.append(str(sources_path))

        # Export targets (with Mapping Name)
        targets_path = safe_join(str(output_dir), f"{prefix}targets.csv")
        self._export_targets(document, targets_path)
        created_files.append(str(targets_path))

        # Export transformations
        trans_path = safe_join(str(output_dir), f"{prefix}transformations.csv")
        self._export_transformations(document, trans_path)
        created_files.append(str(trans_path))

        # Export mapping flow summary
        flow_path = safe_join(str(output_dir), f"{prefix}mapping_flow_summary.csv")
        self._export_mapping_flow_summary(document, flow_path)
        created_files.append(str(flow_path))

        # Export new observation-based CSV files when integration_data available
        if integration_data:
            joiners_path = safe_join(str(output_dir), f"{prefix}joiners.csv")
            self._export_joiners(integration_data, joiners_path)
            created_files.append(str(joiners_path))

            sp_path = safe_join(str(output_dir), f"{prefix}stored_procedures.csv")
            self._export_stored_procedures(document, integration_data, sp_path)
            created_files.append(str(sp_path))

            sf_path = safe_join(str(output_dir), f"{prefix}source_filters.csv")
            self._export_source_filters(document, integration_data, sf_path)
            created_files.append(str(sf_path))

            sc_path = safe_join(str(output_dir), f"{prefix}session_commands.csv")
            self._export_session_commands(integration_data, sc_path)
            created_files.append(str(sc_path))

            sm_path = safe_join(str(output_dir), f"{prefix}session_metadata.csv")
            self._export_session_metadata(integration_data, sm_path)
            created_files.append(str(sm_path))

        logger.info(f"CSV export complete: {len(created_files)} files")
        return created_files

    def _export_lineage(self, lineage_result: LineageResult, output_path: Path):
        """Export lineage to CSV."""
        headers = [
            "Target Table", "Target Field", "Target Datatype",
            "Mapping Name",
            "Ultimate Source Table", "Ultimate Source Field", "Source Qualifier",
            "Transformation Logic", "Transformation Description",
            "End-to-End Dataflow",
            "Hop Count", "Lookup Tables",
            "Has Transformation", "Aggregation Applied", "Filter Applied",
            "Router Applied", "Router Condition", "SQL Override",
            "Resolved SQL Override"
        ]

        with open(output_path, 'w', newline='', encoding='utf-8') as f:
            writer = csv.DictWriter(f, fieldnames=headers, quoting=csv.QUOTE_ALL)
            writer.writeheader()

            for lineage in lineage_result.field_lineages:
                writer.writerow(sanitize_csv_row(lineage.to_row()))

    def _export_sources(self, document: PowermartDocument, output_path: Path):
        """Export sources to CSV with Mapping Name."""
        headers = ["Mapping Name", "Source Name", "Database", "Owner", "Field Name", "Datatype", "Key Type", "Nullable"]

        # Build source-to-mapping lookup
        source_to_mappings: Dict[str, set] = {}
        for mapping in document.mappings:
            for inst in mapping.source_instances:
                inst_name = inst.transformation_name.lower()
                clean_inst = inst_name.replace('sq_', '').replace('sc_', '').replace('src_', '')
                source_to_mappings.setdefault(inst_name, set()).add(mapping.name)
                source_to_mappings.setdefault(clean_inst, set()).add(mapping.name)
            for src in mapping.sources:
                source_to_mappings.setdefault(src.name.lower(), set()).add(mapping.name)

        with open(output_path, 'w', newline='', encoding='utf-8') as f:
            writer = csv.DictWriter(f, fieldnames=headers, quoting=csv.QUOTE_ALL)
            writer.writeheader()

            for source in document.sources:
                src_lower = source.name.lower()
                mapping_names_set = source_to_mappings.get(src_lower, set())
                if not mapping_names_set:
                    for key, names in source_to_mappings.items():
                        if key in src_lower or src_lower in key:
                            mapping_names_set = mapping_names_set | names
                mapping_names = ", ".join(sorted(mapping_names_set))
                for field in source.fields:
                    _safe_writerow(writer, {
                        "Mapping Name": mapping_names,
                        "Source Name": source.name,
                        "Database": source.db_dname,
                        "Owner": source.owner_name,
                        "Field Name": field.name,
                        "Datatype": field.full_datatype,
                        "Key Type": field.keytype,
                        "Nullable": "Yes" if field.nullable else "No",
                    })

    def _export_targets(self, document: PowermartDocument, output_path: Path):
        """Export targets to CSV with Mapping Name association."""
        headers = ["Mapping Name", "Target Name", "Database Type", "Field Name", "Datatype", "Key Type", "Nullable"]

        # Build target-to-mapping lookup from document
        target_to_mappings: Dict[str, set] = {}
        for mapping in document.mappings:
            for inst in mapping.target_instances:
                inst_name = inst.transformation_name.lower()
                target_to_mappings.setdefault(inst_name, set()).add(mapping.name)
                # Strip common prefixes to match document-level target names
                clean = inst_name.replace('sc_to_', '').replace('sc_', '').replace('tgt_', '')
                if clean != inst_name:
                    target_to_mappings.setdefault(clean, set()).add(mapping.name)
            for tgt in mapping.targets:
                target_to_mappings.setdefault(tgt.name.lower(), set()).add(mapping.name)

        with open(output_path, 'w', newline='', encoding='utf-8') as f:
            writer = csv.DictWriter(f, fieldnames=headers, quoting=csv.QUOTE_ALL)
            writer.writeheader()

            for target in document.targets:
                tgt_lower = target.name.lower()
                mapping_names_set = target_to_mappings.get(tgt_lower, set())
                if not mapping_names_set:
                    for key, names in target_to_mappings.items():
                        if key in tgt_lower or tgt_lower in key:
                            mapping_names_set = mapping_names_set | names
                mapping_names = ", ".join(sorted(mapping_names_set))
                for field in target.fields:
                    _safe_writerow(writer, {
                        "Mapping Name": mapping_names,
                        "Target Name": target.name,
                        "Database Type": target.database_type,
                        "Field Name": field.name,
                        "Datatype": field.full_datatype,
                        "Key Type": field.keytype,
                        "Nullable": "Yes" if field.nullable else "No",
                    })

    def _export_transformations(self, document: PowermartDocument, output_path: Path):
        """Export transformations to CSV."""
        headers = ["Mapping", "Transformation Name", "Type", "Reusable", "Input Count", "Output Count"]

        with open(output_path, 'w', newline='', encoding='utf-8') as f:
            writer = csv.DictWriter(f, fieldnames=headers, quoting=csv.QUOTE_ALL)
            writer.writeheader()

            for mapping in document.mappings:
                for trans in mapping.transformations:
                    _safe_writerow(writer, {
                        "Mapping": mapping.name,
                        "Transformation Name": trans.name,
                        "Type": trans.type,
                        "Reusable": "Yes" if trans.reusable else "No",
                        "Input Count": len(trans.input_fields),
                        "Output Count": len(trans.output_fields),
                    })

    def _export_mapping_flow_summary(self, document: PowermartDocument, output_path: Path):
        """Export mapping flow summary to CSV showing sequence, sources, targets, and dependencies."""
        from ..utils.mapping_flow_utils import build_mapping_flow_summary

        headers = [
            "Sequence", "Mapping Name", "Source Tables", "Target Tables",
            "Depends On Mapping", "Session Name", "Workflow Name"
        ]

        summary = build_mapping_flow_summary(document)

        with open(output_path, 'w', newline='', encoding='utf-8') as f:
            writer = csv.DictWriter(f, fieldnames=headers, quoting=csv.QUOTE_ALL)
            writer.writeheader()

            for entry in summary:
                deps = entry["depends_on_mapping"]
                _safe_writerow(writer, {
                    "Sequence": entry["sequence"],
                    "Mapping Name": entry["mapping_name"],
                    "Source Tables": ", ".join(entry["source_tables"]),
                    "Target Tables": ", ".join(entry["target_tables"]),
                    "Depends On Mapping": ", ".join(deps) if deps else "-",
                    "Session Name": entry["session_name"] or "",
                    "Workflow Name": entry["workflow_name"] or "",
                })

    def export_per_mapping(
        self,
        lineage_result: LineageResult,
        document: PowermartDocument,
        output_dir,
        prefix: str = "",
        integration_data: Optional[Dict] = None,
    ) -> List[str]:
        """
        Export separate CSV files for each mapping.

        Args:
            lineage_result: The lineage analysis result
            document: The original PowermartDocument
            output_dir: Directory for the output files
            prefix: Optional prefix for file names
            integration_data: Optional additional data from integration expert

        Returns:
            List of paths to created files
        """
        output_dir = Path(output_dir)
        output_dir.mkdir(parents=True, exist_ok=True)

        created_files = []

        for mapping in document.mappings:
            mapping_name = mapping.name
            safe_name = "".join(c if c.isalnum() or c in ('_', '-') else '_' for c in mapping_name)

            # Build mapping-specific sources/targets from document level
            mapping_sources = list(mapping.sources)
            if not mapping_sources:
                source_inst_names = {inst.transformation_name.lower() for inst in mapping.source_instances}
                for src in document.sources:
                    for inst_name in source_inst_names:
                        clean_inst = inst_name.replace('sq_', '').replace('sc_', '').replace('src_', '')
                        if clean_inst in src.name.lower() or src.name.lower() in clean_inst:
                            mapping_sources.append(src)
                            break

            mapping_targets = list(mapping.targets)
            if not mapping_targets:
                target_inst_names = {inst.transformation_name.lower() for inst in mapping.target_instances}
                for tgt in document.targets:
                    for inst_name in target_inst_names:
                        clean_inst = inst_name.replace('sc_', '').replace('tgt_', '')
                        if clean_inst in tgt.name.lower() or tgt.name.lower() in clean_inst:
                            mapping_targets.append(tgt)
                            break

            # Filter lineage for this mapping's targets
            target_names = {t.name.lower() for t in mapping_targets}
            for inst in mapping.target_instances:
                target_names.add(inst.transformation_name.lower())
                target_names.add(inst.name.lower())  # Also add instance name (e.g., sc_to_SHAW_MAST_ILN_STG)

            mapping_lineages = [
                l for l in lineage_result.field_lineages
                if l.target_table and l.target_table.lower() in target_names
            ]

            # Export lineage CSV
            lineage_path = output_dir / f"{safe_name}_lineage.csv"
            lineage_headers = [
                "Mapping Name",
                "Target Table", "Target Field", "Target Datatype",
                "Ultimate Source Table", "Ultimate Source Field", "Source Qualifier",
                "Transformation Logic", "Transformation Description",
                "End-to-End Dataflow",
                "Hop Count", "Lookup Tables",
                "Has Transformation", "Aggregation Applied", "Filter Applied",
                "Router Applied", "Router Condition", "SQL Override",
                "Resolved SQL Override"
            ]
            with open(lineage_path, 'w', newline='', encoding='utf-8') as f:
                writer = csv.DictWriter(f, fieldnames=lineage_headers, quoting=csv.QUOTE_ALL)
                writer.writeheader()
                for lineage in mapping_lineages:
                    writer.writerow(sanitize_csv_row(lineage.to_row()))
            created_files.append(str(lineage_path))

            # Export sources CSV (with Mapping Name)
            sources_path = output_dir / f"{safe_name}_sources.csv"
            src_headers = ["Mapping Name", "Source Name", "Database", "Owner", "Field Name", "Datatype", "Key Type", "Nullable"]
            with open(sources_path, 'w', newline='', encoding='utf-8') as f:
                writer = csv.DictWriter(f, fieldnames=src_headers, quoting=csv.QUOTE_ALL)
                writer.writeheader()
                for source in mapping_sources:
                    for field in source.fields:
                        _safe_writerow(writer, {
                            "Mapping Name": mapping_name,
                            "Source Name": source.name,
                            "Database": source.db_dname,
                            "Owner": source.owner_name,
                            "Field Name": field.name,
                            "Datatype": field.full_datatype,
                            "Key Type": field.keytype,
                            "Nullable": "Yes" if field.nullable else "No",
                        })
            created_files.append(str(sources_path))

            # Export targets CSV (with Mapping Name)
            targets_path = output_dir / f"{safe_name}_targets.csv"
            tgt_headers = ["Mapping Name", "Target Name", "Database Type", "Field Name", "Datatype", "Key Type", "Nullable"]
            with open(targets_path, 'w', newline='', encoding='utf-8') as f:
                writer = csv.DictWriter(f, fieldnames=tgt_headers, quoting=csv.QUOTE_ALL)
                writer.writeheader()
                for target in mapping_targets:
                    for field in target.fields:
                        _safe_writerow(writer, {
                            "Mapping Name": mapping_name,
                            "Target Name": target.name,
                            "Database Type": target.database_type,
                            "Field Name": field.name,
                            "Datatype": field.full_datatype,
                            "Key Type": field.keytype,
                            "Nullable": "Yes" if field.nullable else "No",
                        })
            created_files.append(str(targets_path))

            # Export transformations CSV
            trans_path = output_dir / f"{safe_name}_transformations.csv"
            trans_headers = ["Mapping", "Transformation Name", "Type", "Reusable", "Input Count", "Output Count"]
            with open(trans_path, 'w', newline='', encoding='utf-8') as f:
                writer = csv.DictWriter(f, fieldnames=trans_headers, quoting=csv.QUOTE_ALL)
                writer.writeheader()
                for trans in mapping.transformations:
                    _safe_writerow(writer, {
                        "Mapping": mapping_name,
                        "Transformation Name": trans.name,
                        "Type": trans.type,
                        "Reusable": "Yes" if trans.reusable else "No",
                        "Input Count": len(trans.input_fields),
                        "Output Count": len(trans.output_fields),
                    })
            created_files.append(str(trans_path))

            # Export observation-based CSVs filtered to this mapping
            if integration_data:
                # Find associated session name(s) for this mapping
                mapping_sessions = set()
                for sess in document.sessions:
                    if sess.mapping_name == mapping_name:
                        mapping_sessions.add(sess.name)

                mapping_name_lower = mapping_name.lower()

                # Joiners
                all_joiners = integration_data.get("expert_results", {}).get("OperatorLogic", {}).get("data", {}).get("joiners", [])
                mapping_joiners = [j for j in all_joiners if j.get("mapping", "").lower() == mapping_name_lower]
                if mapping_joiners:
                    joiners_path = output_dir / f"{safe_name}_joiners.csv"
                    jn_headers = ["Mapping", "Joiner Name", "Join Condition", "Join Type", "Sorted Input", "Master Table", "Detail Table", "Input Fields", "Output Fields"]
                    with open(joiners_path, 'w', newline='', encoding='utf-8') as f:
                        writer = csv.DictWriter(f, fieldnames=jn_headers, quoting=csv.QUOTE_ALL)
                        writer.writeheader()
                        for joiner in mapping_joiners:
                            in_f = joiner.get("input_fields", [])
                            out_f = joiner.get("output_fields", [])
                            _safe_writerow(writer, {
                                "Mapping": joiner.get("mapping", ""),
                                "Joiner Name": joiner.get("name", ""),
                                "Join Condition": joiner.get("join_condition", ""),
                                "Join Type": joiner.get("join_type", ""),
                                "Sorted Input": joiner.get("sorted_input", ""),
                                "Master Table": joiner.get("master_table", ""),
                                "Detail Table": joiner.get("detail_table", ""),
                                "Input Fields": ", ".join(in_f) if isinstance(in_f, list) else str(in_f),
                                "Output Fields": ", ".join(out_f) if isinstance(out_f, list) else str(out_f),
                            })
                    created_files.append(str(joiners_path))

                # Stored Procedures
                all_sps = integration_data.get("expert_results", {}).get("OperatorLogic", {}).get("data", {}).get("stored_procedures", [])
                mapping_sps = [sp for sp in all_sps if sp.get("mapping", "").lower() == mapping_name_lower or sp.get("mapping", "") == "(Reusable)"]
                if mapping_sps:
                    sp_path = output_dir / f"{safe_name}_stored_procedures.csv"
                    sp_headers = ["Mapping Name", "Mapping", "Transformation Name", "Stored Procedure Name", "Procedure Type", "Connection Information", "Call Text", "Execution Order", "Input Fields", "Output Fields"]
                    with open(sp_path, 'w', newline='', encoding='utf-8') as f:
                        writer = csv.DictWriter(f, fieldnames=sp_headers, quoting=csv.QUOTE_ALL)
                        writer.writeheader()
                        for sp in mapping_sps:
                            in_f = sp.get("input_fields", [])
                            out_f = sp.get("output_fields", [])
                            _safe_writerow(writer, {
                                "Mapping Name": mapping_name,
                                "Mapping": sp.get("mapping", ""),
                                "Transformation Name": sp.get("name", ""),
                                "Stored Procedure Name": sp.get("procedure_name", ""),
                                "Procedure Type": sp.get("procedure_type", ""),
                                "Connection Information": sp.get("connection_info", ""),
                                "Call Text": sp.get("call_text", ""),
                                "Execution Order": sp.get("execution_order", ""),
                                "Input Fields": ", ".join(in_f) if isinstance(in_f, list) else str(in_f),
                                "Output Fields": ", ".join(out_f) if isinstance(out_f, list) else str(out_f),
                            })
                    created_files.append(str(sp_path))

                # Source Filters
                op_data = integration_data.get("expert_results", {}).get("OperatorLogic", {}).get("data", {})
                struct_data = integration_data.get("expert_results", {}).get("MappingStructure", {}).get("data", {})
                sq_filters = [sf for sf in op_data.get("source_filters", []) if sf.get("mapping", "").lower() == mapping_name_lower]
                sess_filters = [sf for sf in struct_data.get("source_filters", []) if sf.get("session", "") in mapping_sessions or sf.get("mapping", "").lower() == mapping_name_lower]
                doc_filters = []
                for source in mapping_sources:
                    for attr in getattr(source, 'table_attributes', []):
                        if attr.get("name", "").lower() == "source filter" and attr.get("value"):
                            doc_filters.append({"source": source.name, "value": attr["value"]})
                if sq_filters or sess_filters or doc_filters:
                    sf_path = output_dir / f"{safe_name}_source_filters.csv"
                    sf_headers = ["Mapping", "Source/Transformation", "Filter Source", "Source Filter"]
                    with open(sf_path, 'w', newline='', encoding='utf-8') as f:
                        writer = csv.DictWriter(f, fieldnames=sf_headers, quoting=csv.QUOTE_ALL)
                        writer.writeheader()
                        for sf in sq_filters:
                            filter_text = sf.get("source_filter", "").replace("\r\n", " ").replace("\n", " ").strip()
                            _safe_writerow(writer, {"Mapping": sf.get("mapping", ""), "Source/Transformation": sf.get("transformation", ""), "Filter Source": "Source Qualifier", "Source Filter": filter_text})
                        for sf in sess_filters:
                            filter_text = sf.get("source_filter", "").replace("\r\n", " ").replace("\n", " ").strip()
                            _safe_writerow(writer, {"Mapping": sf.get("mapping", sf.get("session", "")), "Source/Transformation": sf.get("instance", ""), "Filter Source": "Session Extension", "Source Filter": filter_text})
                        for df in doc_filters:
                            filter_text = df["value"].replace("\r\n", " ").replace("\n", " ").strip()
                            _safe_writerow(writer, {"Mapping": mapping_name, "Source/Transformation": df["source"], "Filter Source": "Table Attribute", "Source Filter": filter_text})
                    created_files.append(str(sf_path))

                # Session Commands
                all_cmds = struct_data.get("session_commands", [])
                mapping_cmds = [cmd for cmd in all_cmds if cmd.get("session", "") in mapping_sessions]
                if mapping_cmds:
                    sc_path = output_dir / f"{safe_name}_session_commands.csv"
                    sc_headers = ["Session Name", "Component Name", "Component Type", "Exec Order", "Variable/Command Name", "Value"]
                    with open(sc_path, 'w', newline='', encoding='utf-8') as f:
                        writer = csv.DictWriter(f, fieldnames=sc_headers, quoting=csv.QUOTE_ALL)
                        writer.writeheader()
                        for cmd in mapping_cmds:
                            vps = cmd.get("value_pairs", [])
                            if vps:
                                for vp in vps:
                                    _safe_writerow(writer, {"Session Name": cmd.get("session", ""), "Component Name": cmd.get("component_name", ""), "Component Type": cmd.get("component_type", ""), "Exec Order": vp.get("exec_order", ""), "Variable/Command Name": vp.get("name", ""), "Value": vp.get("value", "")})
                            elif cmd.get("attributes"):
                                for aname, aval in cmd["attributes"].items():
                                    _safe_writerow(writer, {"Session Name": cmd.get("session", ""), "Component Name": cmd.get("component_name", ""), "Component Type": cmd.get("component_type", ""), "Exec Order": "", "Variable/Command Name": aname, "Value": aval})
                            else:
                                _safe_writerow(writer, {"Session Name": cmd.get("session", ""), "Component Name": cmd.get("component_name", ""), "Component Type": cmd.get("component_type", ""), "Exec Order": "", "Variable/Command Name": "", "Value": ""})
                    created_files.append(str(sc_path))

                # Session Metadata
                meta_lists = [
                    ("session_pre_sql", "pre_sql", "sql"),
                    ("session_post_sql", "post_sql", "sql"),
                    ("session_sql_overrides", "sql_override", "sql"),
                    ("source_table_overrides", "source_table_override", "table_name"),
                    ("target_table_overrides", "target_table_name", "table_name"),
                    ("table_name_prefixes", "table_name_prefix", "prefix"),
                ]
                session_meta: Dict[tuple, Dict] = {}
                for list_key, meta_key, value_key in meta_lists:
                    for item in struct_data.get(list_key, []):
                        if item.get("session", "") in mapping_sessions:
                            key = (item.get("session", ""), item.get("instance", ""))
                            m = session_meta.setdefault(key, {})
                            m[meta_key] = item.get(value_key, "")
                for item in struct_data.get("owner_name_overrides", []):
                    if item.get("session", "") in mapping_sessions:
                        key = (item.get("session", ""), item.get("instance", ""))
                        m = session_meta.setdefault(key, {})
                        m["owner_name"] = item.get("owner_name", "")
                        if item.get("source_table_name"):
                            m["source_table_name"] = item.get("source_table_name", "")
                if session_meta:
                    sm_path = output_dir / f"{safe_name}_session_metadata.csv"
                    sm_headers = ["Session Name", "Mapping", "Instance", "Type", "Owner Name", "Source Table Name", "Pre SQL", "Post SQL", "SQL Override", "Source Table Override", "Target Table Name", "Table Name Prefix", "Connection"]
                    with open(sm_path, 'w', newline='', encoding='utf-8') as f:
                        writer = csv.DictWriter(f, fieldnames=sm_headers, quoting=csv.QUOTE_ALL)
                        writer.writeheader()
                        for (sess, inst), meta in session_meta.items():
                            _safe_writerow(writer, {"Session Name": sess, "Mapping": mapping_name, "Instance": inst, "Type": "", "Owner Name": meta.get("owner_name", ""), "Source Table Name": meta.get("source_table_name", ""), "Pre SQL": meta.get("pre_sql", ""), "Post SQL": meta.get("post_sql", ""), "SQL Override": meta.get("sql_override", ""), "Source Table Override": meta.get("source_table_override", ""), "Target Table Name": meta.get("target_table_name", ""), "Table Name Prefix": meta.get("table_name_prefix", ""), "Connection": meta.get("connection", "")})
                    created_files.append(str(sm_path))

            logger.info(f"Created CSV files for mapping: {mapping_name}")

        return created_files

    # ---- New observation-based CSV export methods ----

    def _export_joiners(self, integration_data: Dict, output_path: Path):
        """Export joiner details to CSV (Observation 7)."""
        headers = [
            "Mapping", "Joiner Name", "Join Condition", "Join Type",
            "Sorted Input", "Master Table", "Detail Table",
            "Input Fields", "Output Fields"
        ]
        joiners = integration_data.get("expert_results", {}).get("OperatorLogic", {}).get("data", {}).get("joiners", [])

        with open(output_path, 'w', newline='', encoding='utf-8') as f:
            writer = csv.DictWriter(f, fieldnames=headers, quoting=csv.QUOTE_ALL)
            writer.writeheader()
            for joiner in joiners:
                input_fields = joiner.get("input_fields", [])
                output_fields = joiner.get("output_fields", [])
                _safe_writerow(writer, {
                    "Mapping": joiner.get("mapping", ""),
                    "Joiner Name": joiner.get("name", ""),
                    "Join Condition": joiner.get("join_condition", ""),
                    "Join Type": joiner.get("join_type", ""),
                    "Sorted Input": joiner.get("sorted_input", ""),
                    "Master Table": joiner.get("master_table", ""),
                    "Detail Table": joiner.get("detail_table", ""),
                    "Input Fields": ", ".join(input_fields) if isinstance(input_fields, list) else str(input_fields),
                    "Output Fields": ", ".join(output_fields) if isinstance(output_fields, list) else str(output_fields),
                })

    def _export_stored_procedures(self, document: PowermartDocument, integration_data: Dict, output_path: Path):
        """Export stored procedure details to CSV (Observation 3)."""
        headers = [
            "Mapping Name", "Mapping", "Transformation Name", "Stored Procedure Name",
            "Procedure Type", "Connection Information", "Call Text",
            "Execution Order", "Input Fields", "Output Fields"
        ]
        sps = integration_data.get("expert_results", {}).get("OperatorLogic", {}).get("data", {}).get("stored_procedures", [])

        # Build SP name -> mapping name(s) lookup from mapping instances
        sp_to_mappings: dict = {}
        for mapping in document.mappings:
            for inst in mapping.instances:
                inst_name_lower = inst.transformation_name.lower() if hasattr(inst, 'transformation_name') else inst.name.lower()
                if inst_name_lower:
                    sp_to_mappings.setdefault(inst_name_lower, set()).add(mapping.name)
                    clean = inst_name_lower.replace('sc_', '').replace('src_', '')
                    if clean != inst_name_lower:
                        sp_to_mappings.setdefault(clean, set()).add(mapping.name)

        with open(output_path, 'w', newline='', encoding='utf-8') as f:
            writer = csv.DictWriter(f, fieldnames=headers, quoting=csv.QUOTE_ALL)
            writer.writeheader()
            for sp in sps:
                input_fields = sp.get("input_fields", [])
                output_fields = sp.get("output_fields", [])
                sp_name_lower = sp.get("name", "").lower()
                mapping_names_set = sp_to_mappings.get(sp_name_lower, set())
                if not mapping_names_set:
                    for key, names in sp_to_mappings.items():
                        if sp_name_lower and (sp_name_lower in key or key in sp_name_lower):
                            mapping_names_set = mapping_names_set | names
                _safe_writerow(writer, {
                    "Mapping Name": ", ".join(sorted(mapping_names_set)),
                    "Mapping": sp.get("mapping", ""),
                    "Transformation Name": sp.get("name", ""),
                    "Stored Procedure Name": sp.get("procedure_name", ""),
                    "Procedure Type": sp.get("procedure_type", ""),
                    "Connection Information": sp.get("connection_info", ""),
                    "Call Text": sp.get("call_text", ""),
                    "Execution Order": sp.get("execution_order", ""),
                    "Input Fields": ", ".join(input_fields) if isinstance(input_fields, list) else str(input_fields),
                    "Output Fields": ", ".join(output_fields) if isinstance(output_fields, list) else str(output_fields),
                })

    def _export_source_filters(self, document: PowermartDocument, integration_data: Dict, output_path: Path):
        """Export source filter details to CSV (Observations 1 & 2)."""
        headers = ["Mapping", "Source/Transformation", "Filter Source", "Source Filter"]

        # Collect from OperatorLogic (SQ-level filters)
        op_data = integration_data.get("expert_results", {}).get("OperatorLogic", {}).get("data", {})
        sq_filters = op_data.get("source_filters", [])

        # Collect from MappingStructure (session-level filters)
        struct_data = integration_data.get("expert_results", {}).get("MappingStructure", {}).get("data", {})
        session_filters = struct_data.get("source_filters", [])

        with open(output_path, 'w', newline='', encoding='utf-8') as f:
            writer = csv.DictWriter(f, fieldnames=headers, quoting=csv.QUOTE_ALL)
            writer.writeheader()

            # SQ-level source filters
            for sf in sq_filters:
                # Normalize CRLF/LF in source filter text for clean single-line display
                filter_text = sf.get("source_filter", "").replace("\r\n", " ").replace("\n", " ").strip()
                _safe_writerow(writer, {
                    "Mapping": sf.get("mapping", ""),
                    "Source/Transformation": sf.get("transformation", ""),
                    "Filter Source": "Source Qualifier",
                    "Source Filter": filter_text,
                })

            # Session-level source filters
            for sf in session_filters:
                # Normalize CRLF/LF in source filter text for clean single-line display
                filter_text = sf.get("source_filter", "").replace("\r\n", " ").replace("\n", " ").strip()
                _safe_writerow(writer, {
                    "Mapping": sf.get("mapping", sf.get("session", "")),
                    "Source/Transformation": sf.get("instance", ""),
                    "Filter Source": "Session Extension",
                    "Source Filter": filter_text,
                })

            # Document-level source filters from TABLEATTRIBUTE
            for source in document.sources:
                for attr in getattr(source, 'table_attributes', []):
                    if attr.get("name", "").lower() == "source filter" and attr.get("value"):
                        _safe_writerow(writer, {
                            "Mapping": "",
                            "Source/Transformation": source.name,
                            "Filter Source": "Table Attribute",
                            "Source Filter": attr["value"],
                        })

    def _export_session_commands(self, integration_data: Dict, output_path: Path):
        """Export session commands and variable assignments to CSV (Observation 4)."""
        headers = [
            "Session Name", "Component Name", "Component Type",
            "Exec Order", "Variable/Command Name", "Value"
        ]
        commands = integration_data.get("expert_results", {}).get("MappingStructure", {}).get("data", {}).get("session_commands", [])

        with open(output_path, 'w', newline='', encoding='utf-8') as f:
            writer = csv.DictWriter(f, fieldnames=headers, quoting=csv.QUOTE_ALL)
            writer.writeheader()

            for cmd in commands:
                value_pairs = cmd.get("value_pairs", [])
                if value_pairs:
                    for vp in value_pairs:
                        _safe_writerow(writer, {
                            "Session Name": cmd.get("session", ""),
                            "Component Name": cmd.get("component_name", ""),
                            "Component Type": cmd.get("component_type", ""),
                            "Exec Order": vp.get("exec_order", ""),
                            "Variable/Command Name": vp.get("name", ""),
                            "Value": vp.get("value", ""),
                        })
                elif cmd.get("attributes"):
                    for attr_name, attr_value in cmd["attributes"].items():
                        _safe_writerow(writer, {
                            "Session Name": cmd.get("session", ""),
                            "Component Name": cmd.get("component_name", ""),
                            "Component Type": cmd.get("component_type", ""),
                            "Exec Order": "",
                            "Variable/Command Name": attr_name,
                            "Value": attr_value,
                        })
                else:
                    _safe_writerow(writer, {
                        "Session Name": cmd.get("session", ""),
                        "Component Name": cmd.get("component_name", ""),
                        "Component Type": cmd.get("component_type", ""),
                        "Exec Order": "",
                        "Variable/Command Name": "",
                        "Value": "",
                    })

    def _export_session_metadata(self, integration_data: Dict, output_path: Path):
        """Export session metadata with owner_name and source_table_name to CSV (Observation 6)."""
        headers = [
            "Session Name", "Mapping", "Instance", "Type",
            "Owner Name", "Source Table Name",
            "Pre SQL", "Post SQL", "SQL Override",
            "Source Table Override", "Target Table Name",
            "Table Name Prefix", "Connection"
        ]
        struct_data = integration_data.get("expert_results", {}).get("MappingStructure", {}).get("data", {})

        # Build aggregated session metadata keyed by (session, instance)
        session_metadata: Dict[tuple, Dict] = {}

        data_lists = [
            ("session_pre_sql", "pre_sql", "sql"),
            ("session_post_sql", "post_sql", "sql"),
            ("session_sql_overrides", "sql_override", "sql"),
            ("source_table_overrides", "source_table_override", "table_name"),
            ("target_table_overrides", "target_table_name", "table_name"),
            ("table_name_prefixes", "table_name_prefix", "prefix"),
        ]

        for list_key, meta_key, value_key in data_lists:
            for item in struct_data.get(list_key, []):
                key = (item.get("session", ""), item.get("instance", ""))
                meta = session_metadata.setdefault(key, {})
                meta[meta_key] = item.get(value_key, "")

        # Owner name overrides (includes source_table_name)
        for item in struct_data.get("owner_name_overrides", []):
            key = (item.get("session", ""), item.get("instance", ""))
            meta = session_metadata.setdefault(key, {})
            meta["owner_name"] = item.get("owner_name", "")
            if item.get("source_table_name"):
                meta["source_table_name"] = item.get("source_table_name", "")

        with open(output_path, 'w', newline='', encoding='utf-8') as f:
            writer = csv.DictWriter(f, fieldnames=headers, quoting=csv.QUOTE_ALL)
            writer.writeheader()

            for (session, instance), meta in session_metadata.items():
                _safe_writerow(writer, {
                    "Session Name": session,
                    "Mapping": "",
                    "Instance": instance,
                    "Type": "",
                    "Owner Name": meta.get("owner_name", ""),
                    "Source Table Name": meta.get("source_table_name", ""),
                    "Pre SQL": meta.get("pre_sql", ""),
                    "Post SQL": meta.get("post_sql", ""),
                    "SQL Override": meta.get("sql_override", ""),
                    "Source Table Override": meta.get("source_table_override", ""),
                    "Target Table Name": meta.get("target_table_name", ""),
                    "Table Name Prefix": meta.get("table_name_prefix", ""),
                    "Connection": meta.get("connection", ""),
                })
