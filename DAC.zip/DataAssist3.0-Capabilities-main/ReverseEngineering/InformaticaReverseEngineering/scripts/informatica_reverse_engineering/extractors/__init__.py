"""
Extractors module for specialized data extraction from Informatica XMLs.

This module provides extractors for specific types of information
such as parameters, variables, embedded SQL, and transformation metadata.

Components:
- ParameterExtractor: Extracts $Param_*, $$*, $PM* parameters
- TransformationMetadataExtractor: Extracts detailed transformation settings
  for forward engineering to Snowflake SQL

The TransformationMetadataExtractor handles:
- Sequence Generator (complete extraction)
- Stored Procedure (complete extraction)
- Rank transformation (complete extraction)
- Normalizer (enhanced with OCCURS metadata)
- Aggregator (enhanced with HAVING condition)
- Source Qualifier (enhanced with Pre/Post SQL)
- Target Load (enhanced with session-level SQL)
- Update Strategy (enhanced with key columns)
"""

from .parameter_extractor import ParameterExtractor
from .transformation_metadata_extractor import (
    TransformationMetadataExtractor,
    TransformationMetadataCatalog,
    SequenceMetadata,
    StoredProcedureMetadata,
    RankMetadata,
    NormalizerMetadata,
    AggregatorMetadata,
    SourceQualifierMetadata,
    TargetLoadMetadata,
    SessionSQLMetadata,
    UpdateStrategyMetadata,
    SequenceApproach,
    StoredProcedureMode,
    RankFunction,
)

__all__ = [
    # Parameter extraction
    "ParameterExtractor",
    # Transformation metadata extraction
    "TransformationMetadataExtractor",
    "TransformationMetadataCatalog",
    # Metadata dataclasses
    "SequenceMetadata",
    "StoredProcedureMetadata",
    "RankMetadata",
    "NormalizerMetadata",
    "AggregatorMetadata",
    "SourceQualifierMetadata",
    "TargetLoadMetadata",
    "SessionSQLMetadata",
    "UpdateStrategyMetadata",
    # Enums
    "SequenceApproach",
    "StoredProcedureMode",
    "RankFunction",
]
