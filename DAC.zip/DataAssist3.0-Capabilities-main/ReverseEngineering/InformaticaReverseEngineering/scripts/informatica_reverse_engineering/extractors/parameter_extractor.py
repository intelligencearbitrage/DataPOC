"""
Parameter extractor for Informatica PowerCenter XMLs.

This module extracts and catalogs all parameters ($Param_*, $$*, etc.)
from Informatica XML files for conversion to stored procedure parameters.
"""

import re
from typing import Any, Dict, List, Optional, Set

from ..parsers.powermart_parser import PowermartDocument
from ..aggregation.aggregation_models import (
    Parameter,
    ParameterType,
    ParameterUsage,
    ParameterCatalog,
)
from ..utils.logging_config import get_logger


logger = get_logger("parameter_extractor")


class ParameterExtractor:
    """
    Extracts parameters from Informatica PowerCenter documents.

    Identifies and catalogs all parameter references including:
    - $Param_* (workflow/session parameters)
    - $$* (mapping variables)
    - $PM* (mapping parameters)
    - System variables
    """

    # Regex patterns for different parameter types
    PATTERNS = {
        ParameterType.MAPPING_PARAMETER: re.compile(r'\$PM[A-Za-z_][A-Za-z0-9_]*'),
        ParameterType.MAPPING_VARIABLE: re.compile(r'\$\$[A-Za-z_][A-Za-z0-9_]*'),
        ParameterType.WORKFLOW_VARIABLE: re.compile(r'\$(?!PM|\$)[A-Za-z_][A-Za-z0-9_]*'),
        ParameterType.CONNECTION_VARIABLE: re.compile(r'\$DBConnection[A-Za-z0-9_]*'),
        ParameterType.SYSTEM_VARIABLE: re.compile(
            r'\$PM(?:INTEGRATION_SERVICE|WORKFLOW_NAME|MAPPING_NAME|SESSION_NAME|'
            r'REPOSITORY_NAME|FOLDER_NAME|SOURCE_FILE_DIRECTORY|TARGET_FILE_DIRECTORY|'
            r'CACHE_DIR|TEMP_DIR|LOG_DIR|BATCH_ID)\b'
        ),
    }

    # Common parameter patterns and their likely data types
    TYPE_INFERENCE_PATTERNS = {
        r'(?i)date|dt|time|ts': 'TIMESTAMP_NTZ',
        r'(?i)count|cnt|num|id|seq': 'INTEGER',
        r'(?i)amt|amount|price|cost|balance': 'NUMBER(18,2)',
        r'(?i)flag|ind|indicator|is_|has_': 'BOOLEAN',
        r'(?i)pct|percent|rate': 'NUMBER(5,4)',
        r'(?i)name|desc|description|text|comment': 'VARCHAR(500)',
        r'(?i)table|schema|database|file|path|dir': 'VARCHAR(255)',
    }

    def __init__(self):
        """Initialize the parameter extractor."""
        self.catalog = ParameterCatalog()

    def extract_from_documents(
        self,
        documents: Dict[str, PowermartDocument]
    ) -> ParameterCatalog:
        """
        Extract parameters from multiple documents.

        Args:
            documents: Dictionary of xml_path -> PowermartDocument

        Returns:
            ParameterCatalog with all extracted parameters
        """
        logger.info(f"Extracting parameters from {len(documents)} documents")

        for xml_path, doc in documents.items():
            self.extract_from_document(doc, xml_path)

        logger.info(f"Extracted {self.catalog.total_count} unique parameters")
        return self.catalog

    def extract_from_document(
        self,
        document: PowermartDocument,
        xml_path: str = ""
    ) -> List[Parameter]:
        """
        Extract parameters from a single document.

        Args:
            document: PowermartDocument to extract from
            xml_path: Path to the XML file (for tracking)

        Returns:
            List of Parameter objects found in this document
        """
        parameters: List[Parameter] = []
        xml_name = xml_path or document.file_path or "unknown"

        # Extract from mappings
        for mapping in document.mappings:
            mapping_params = self._extract_from_mapping(mapping, xml_name)
            parameters.extend(mapping_params)

        # Extract from sessions
        for session in document.sessions:
            session_params = self._extract_from_session(session, xml_name)
            parameters.extend(session_params)

        # Extract from workflows
        for workflow in document.workflows:
            workflow_params = self._extract_from_workflow(workflow, xml_name)
            parameters.extend(workflow_params)

        # Add all parameters to catalog
        for param in parameters:
            self.catalog.add_parameter(param)

        logger.debug(f"Extracted {len(parameters)} parameters from {xml_name}")
        return parameters

    def _extract_from_mapping(self, mapping, xml_name: str) -> List[Parameter]:
        """Extract parameters from a mapping."""
        parameters: List[Parameter] = []
        found_params: Dict[str, Parameter] = {}

        # Extract from mapping variables
        for var in mapping.variables:
            param = self._create_parameter_from_variable(var, xml_name, mapping.name)
            if param and param.name not in found_params:
                found_params[param.name] = param

        # Extract from transformations
        for trans in mapping.transformations:
            trans_params = self._extract_from_transformation(trans, xml_name, mapping.name)
            for param in trans_params:
                if param.name not in found_params:
                    found_params[param.name] = param
                else:
                    # Merge usages
                    found_params[param.name].usages.extend(param.usages)

        return list(found_params.values())

    def _extract_from_transformation(
        self,
        trans,
        xml_name: str,
        mapping_name: str
    ) -> List[Parameter]:
        """Extract parameters from a transformation."""
        parameters: List[Parameter] = []
        found_params: Dict[str, Parameter] = {}

        # Extract from transform fields
        for field in trans.fields:
            expression = field.expression or ""
            if expression:
                params = self._extract_from_expression(
                    expression, xml_name, mapping_name, trans.name, field.name
                )
                for param in params:
                    if param.name not in found_params:
                        found_params[param.name] = param
                    else:
                        found_params[param.name].usages.extend(param.usages)

        # Extract from table attributes (SQL Query, Lookup Condition, etc.)
        for attr in trans.attributes:
            value = attr.value or ""
            if value:
                context = attr.name  # "Sql Query", "Lookup condition", etc.
                params = self._extract_from_expression(
                    value, xml_name, mapping_name, trans.name, "",
                    context=context
                )
                for param in params:
                    if param.name not in found_params:
                        found_params[param.name] = param
                    else:
                        found_params[param.name].usages.extend(param.usages)

        return list(found_params.values())

    def _extract_from_session(self, session, xml_name: str) -> List[Parameter]:
        """Extract parameters from a session."""
        parameters: List[Parameter] = []
        found_params: Dict[str, Parameter] = {}

        # Extract from session attributes (list of SessionAttribute objects)
        for attr in session.attributes:
            attr_name = getattr(attr, 'name', '')
            attr_value = getattr(attr, 'value', '')
            if isinstance(attr_value, str) and attr_value:
                params = self._extract_from_expression(
                    attr_value, xml_name, "", session.name, "",
                    context=f"Session.{attr_name}"
                )
                for param in params:
                    if param.name not in found_params:
                        found_params[param.name] = param
                    else:
                        found_params[param.name].usages.extend(param.usages)

        # Extract from session extensions (readers/writers/lookups)
        for ext in session.extensions:
            for attr in ext.attributes:
                attr_name = getattr(attr, 'name', '')
                attr_value = getattr(attr, 'value', '')
                if isinstance(attr_value, str) and attr_value:
                    params = self._extract_from_expression(
                        attr_value, xml_name, "", session.name, "",
                        context=f"SessionExtension.{attr_name}"
                    )
                    for param in params:
                        if param.name not in found_params:
                            found_params[param.name] = param
                        else:
                            found_params[param.name].usages.extend(param.usages)

        return list(found_params.values())

    def _extract_from_workflow(self, workflow, xml_name: str) -> List[Parameter]:
        """Extract parameters from a workflow."""
        parameters: List[Parameter] = []
        found_params: Dict[str, Parameter] = {}

        # Extract from workflow variables
        for var in workflow.variables:
            param = self._create_parameter_from_variable(var, xml_name, workflow.name)
            if param and param.name not in found_params:
                found_params[param.name] = param

        return list(found_params.values())

    def _extract_from_expression(
        self,
        expression: str,
        xml_name: str,
        mapping_name: str,
        trans_name: str,
        field_name: str,
        context: str = ""
    ) -> List[Parameter]:
        """
        Extract parameters from an expression string.

        Searches for all parameter patterns and creates Parameter objects.
        """
        parameters: List[Parameter] = []
        found_names: Set[str] = set()

        for param_type, pattern in self.PATTERNS.items():
            matches = pattern.findall(expression)
            for match in matches:
                if match not in found_names:
                    found_names.add(match)

                    usage = ParameterUsage(
                        xml_file=xml_name,
                        mapping_name=mapping_name,
                        transformation_name=trans_name,
                        field_name=field_name,
                        expression=expression[:200],  # Truncate long expressions
                        context=context,
                    )

                    param = Parameter(
                        name=match,
                        parameter_type=self._classify_parameter(match, param_type),
                        inferred_data_type=self._infer_data_type(match, expression),
                        usages=[usage],
                        source_xmls=[xml_name],
                    )
                    parameters.append(param)

        return parameters

    def _create_parameter_from_variable(
        self,
        var,
        xml_name: str,
        parent_name: str
    ) -> Optional[Parameter]:
        """Create a Parameter from a mapping/workflow variable definition."""
        if not hasattr(var, "name"):
            return None

        var_name = var.name
        if not var_name:
            return None

        # Determine parameter type
        if var_name.startswith("$$"):
            param_type = ParameterType.MAPPING_VARIABLE
        elif var_name.startswith("$PM"):
            param_type = ParameterType.MAPPING_PARAMETER
        else:
            param_type = ParameterType.WORKFLOW_VARIABLE

        # Get default value if available
        default_value = getattr(var, "default_value", None) or getattr(var, "value", None)

        # Get data type if available
        data_type = getattr(var, "datatype", None) or self._infer_data_type(var_name)

        return Parameter(
            name=var_name,
            parameter_type=param_type,
            default_value=default_value,
            inferred_data_type=self._convert_informatica_type(data_type),
            description=getattr(var, "description", ""),
            source_xmls=[xml_name],
        )

    def _classify_parameter(
        self,
        param_name: str,
        default_type: ParameterType
    ) -> ParameterType:
        """
        Classify a parameter into the appropriate type.

        Uses pattern matching to override default type if needed.
        """
        # Check for system variables first
        system_vars = {
            "$PMINTEGRATION_SERVICE", "$PMWORKFLOW_NAME", "$PMMAPPING_NAME",
            "$PMSESSION_NAME", "$PMREPOSITORY_NAME", "$PMFOLDER_NAME",
            "$PMSOURCE_FILE_DIRECTORY", "$PMTARGET_FILE_DIRECTORY",
            "$PMCACHE_DIR", "$PMTEMP_DIR", "$PMLOG_DIR", "$PMBATCH_ID"
        }

        param_upper = param_name.upper().replace("_", "")
        for sys_var in system_vars:
            if sys_var.replace("_", "") in param_upper:
                return ParameterType.SYSTEM_VARIABLE

        # Check for connection variables
        if "DBCONNECTION" in param_upper:
            return ParameterType.CONNECTION_VARIABLE

        return default_type

    def _infer_data_type(self, param_name: str, expression: str = "") -> str:
        """
        Infer the data type of a parameter based on its name and context.
        """
        param_lower = param_name.lower()

        # Check against known patterns
        for pattern, data_type in self.TYPE_INFERENCE_PATTERNS.items():
            if re.search(pattern, param_lower):
                return data_type

        # Check expression context for hints
        if expression:
            expr_lower = expression.lower()

            # Date/time context
            if any(kw in expr_lower for kw in ["to_date", "date", "timestamp", "sysdate"]):
                return "TIMESTAMP_NTZ"

            # Numeric context
            if any(kw in expr_lower for kw in ["sum(", "count(", "avg(", "number"]):
                return "NUMBER"

            # Boolean context
            if any(kw in expr_lower for kw in ["iif(", "= true", "= false", "is null"]):
                return "BOOLEAN"

        # Default to VARCHAR
        return "VARCHAR(255)"

    def _convert_informatica_type(self, informatica_type: str) -> str:
        """
        Convert Informatica data type to Snowflake equivalent.
        """
        if not informatica_type:
            return "VARCHAR(255)"

        type_upper = informatica_type.upper()

        # Direct mappings
        type_mappings = {
            "STRING": "VARCHAR",
            "NSTRING": "VARCHAR",
            "TEXT": "VARCHAR",
            "INTEGER": "INTEGER",
            "BIGINT": "BIGINT",
            "SMALLINT": "SMALLINT",
            "DECIMAL": "NUMBER",
            "DOUBLE": "FLOAT",
            "REAL": "FLOAT",
            "DATE/TIME": "TIMESTAMP_NTZ",
            "DATETIME": "TIMESTAMP_NTZ",
            "DATE": "DATE",
            "BINARY": "BINARY",
        }

        for inf_type, sf_type in type_mappings.items():
            if inf_type in type_upper:
                return sf_type

        return "VARCHAR(255)"

    def get_catalog(self) -> ParameterCatalog:
        """Get the parameter catalog."""
        return self.catalog

    def reset(self) -> None:
        """Reset the extractor state."""
        self.catalog = ParameterCatalog()

    def export_for_stored_procedures(self) -> Dict[str, Any]:
        """
        Export parameters in format suitable for stored procedure generation.

        Returns dict with parameter definitions and groupings.
        """
        return {
            "parameters": self.catalog.to_stored_procedure_params(),
            "total_count": self.catalog.total_count,
            "by_type": {
                pt.value: [p.to_dict() for p in self.catalog.get_by_type(pt)]
                for pt in ParameterType
            },
        }
