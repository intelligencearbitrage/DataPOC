"""
Transformation Metadata Extractor for Informatica PowerCenter XMLs.

This module extracts detailed transformation-specific metadata that is
required for forward engineering to Snowflake SQL. It fills the gaps
identified in Phase 3/4 translators.

Handles:
- Sequence Generator (CRITICAL - was completely missing)
- Stored Procedure (CRITICAL - was completely missing)
- Rank Transformation (CRITICAL - was completely missing)
- Normalizer (ENHANCED - adds OCCURS count, key columns)
- Aggregator (ENHANCED - adds HAVING condition)
- Source Qualifier (ENHANCED - adds Pre/Post SQL, User Defined Join)
- Target Load (ENHANCED - adds Pre/Post SQL from SessionExtension)
- Update Strategy (ENHANCED - adds KEY_COLUMNS detection)
"""

import re
import xml.etree.ElementTree as ET
import defusedxml.ElementTree as DefusedET
from typing import Any, Dict, List, Optional, Set
from dataclasses import dataclass, field
from enum import Enum

from ..parsers.powermart_parser import PowermartDocument
from ..models.transformation_models import TransformationType, Transformation
from ..utils.logging_config import get_logger


logger = get_logger("transformation_metadata_extractor")


class SequenceApproach(Enum):
    """How to generate sequence values in Snowflake."""
    SEQUENCE = "sequence"       # Use Snowflake SEQUENCE object
    IDENTITY = "identity"       # Use IDENTITY column
    ROW_NUMBER = "row_number"   # Use ROW_NUMBER() window function


class StoredProcedureMode(Enum):
    """Execution mode for stored procedure transformation."""
    NORMAL = "normal"           # Execute once
    PER_ROW = "per_row"         # Execute once per input row
    PRE_SESSION = "pre_session"  # Execute before main processing
    POST_SESSION = "post_session"  # Execute after main processing


class RankFunction(Enum):
    """Snowflake ranking function to use."""
    ROW_NUMBER = "ROW_NUMBER"
    RANK = "RANK"
    DENSE_RANK = "DENSE_RANK"
    NTILE = "NTILE"


@dataclass
class SequenceMetadata:
    """Metadata for Sequence Generator transformation."""
    transformation_name: str
    mapping_name: str
    sequence_name: str
    start_value: int = 1
    increment: int = 1
    end_value: Optional[int] = None
    cycle: bool = False
    output_port: str = ""
    current_value_port: str = ""
    approach: SequenceApproach = SequenceApproach.SEQUENCE
    reset_on_session: bool = False

    def to_dict(self) -> Dict[str, Any]:
        return {
            "transformation_name": self.transformation_name,
            "mapping_name": self.mapping_name,
            "sequence_name": self.sequence_name,
            "start_value": self.start_value,
            "increment": self.increment,
            "end_value": self.end_value,
            "cycle": self.cycle,
            "output_port": self.output_port,
            "current_value_port": self.current_value_port,
            "approach": self.approach.value,
            "reset_on_session": self.reset_on_session,
        }


@dataclass
class StoredProcedureMetadata:
    """Metadata for Stored Procedure transformation."""
    transformation_name: str
    mapping_name: str
    procedure_name: str
    owner_name: str = ""
    connection_name: str = ""
    execution_mode: StoredProcedureMode = StoredProcedureMode.NORMAL
    parameters: List[Dict[str, Any]] = field(default_factory=list)
    has_return_value: bool = False
    is_resultset: bool = False
    stop_on_error: bool = True
    procedure_body: str = ""
    database_type: str = "Oracle"  # Source database type

    def to_dict(self) -> Dict[str, Any]:
        return {
            "transformation_name": self.transformation_name,
            "mapping_name": self.mapping_name,
            "procedure_name": self.procedure_name,
            "owner_name": self.owner_name,
            "connection_name": self.connection_name,
            "execution_mode": self.execution_mode.value,
            "parameters": self.parameters,
            "has_return_value": self.has_return_value,
            "is_resultset": self.is_resultset,
            "stop_on_error": self.stop_on_error,
            "procedure_body": self.procedure_body,
            "database_type": self.database_type,
        }


@dataclass
class RankMetadata:
    """Metadata for Rank transformation."""
    transformation_name: str
    mapping_name: str
    rank_column: str = ""
    rank_direction: str = "DESC"  # DESC or ASC
    partition_columns: List[str] = field(default_factory=list)
    top_n: Optional[int] = None
    rank_function: RankFunction = RankFunction.ROW_NUMBER
    rank_output_port: str = "RANKINDEX"
    case_sensitive: bool = False

    def to_dict(self) -> Dict[str, Any]:
        return {
            "transformation_name": self.transformation_name,
            "mapping_name": self.mapping_name,
            "rank_column": self.rank_column,
            "rank_direction": self.rank_direction,
            "partition_columns": self.partition_columns,
            "top_n": self.top_n,
            "rank_function": self.rank_function.value,
            "rank_output_port": self.rank_output_port,
            "case_sensitive": self.case_sensitive,
        }


@dataclass
class NormalizerMetadata:
    """Enhanced metadata for Normalizer transformation."""
    transformation_name: str
    mapping_name: str
    occurs_columns: List[str] = field(default_factory=list)
    occurs_count: int = 1
    key_columns: List[str] = field(default_factory=list)
    value_column: str = "VALUE"
    index_column: str = "OCCURS_INDEX"
    source_data_type: str = "RELATIONAL"  # RELATIONAL, ARRAY, VARIANT
    level: int = 1

    def to_dict(self) -> Dict[str, Any]:
        return {
            "transformation_name": self.transformation_name,
            "mapping_name": self.mapping_name,
            "occurs_columns": self.occurs_columns,
            "occurs_count": self.occurs_count,
            "key_columns": self.key_columns,
            "value_column": self.value_column,
            "index_column": self.index_column,
            "source_data_type": self.source_data_type,
            "level": self.level,
        }


@dataclass
class AggregatorMetadata:
    """Enhanced metadata for Aggregator transformation."""
    transformation_name: str
    mapping_name: str
    group_by_columns: List[str] = field(default_factory=list)
    aggregate_expressions: Dict[str, str] = field(default_factory=dict)
    having_condition: str = ""
    sorted_ports: int = 0
    pre_sorted: bool = False
    aggregate_cache: str = "Auto"

    def to_dict(self) -> Dict[str, Any]:
        return {
            "transformation_name": self.transformation_name,
            "mapping_name": self.mapping_name,
            "group_by_columns": self.group_by_columns,
            "aggregate_expressions": self.aggregate_expressions,
            "having_condition": self.having_condition,
            "sorted_ports": self.sorted_ports,
            "pre_sorted": self.pre_sorted,
            "aggregate_cache": self.aggregate_cache,
        }


@dataclass
class SourceQualifierMetadata:
    """Enhanced metadata for Source Qualifier transformation."""
    transformation_name: str
    mapping_name: str
    sql_query: str = ""
    user_defined_join: str = ""
    source_filter: str = ""
    pre_sql: str = ""
    post_sql: str = ""
    select_distinct: bool = False
    sorted_ports: int = 0
    source_tables: List[str] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "transformation_name": self.transformation_name,
            "mapping_name": self.mapping_name,
            "sql_query": self.sql_query,
            "user_defined_join": self.user_defined_join,
            "source_filter": self.source_filter,
            "pre_sql": self.pre_sql,
            "post_sql": self.post_sql,
            "select_distinct": self.select_distinct,
            "sorted_ports": self.sorted_ports,
            "source_tables": self.source_tables,
        }


@dataclass
class TargetLoadMetadata:
    """Enhanced metadata for Target load settings from SessionExtension."""
    target_name: str
    session_name: str
    pre_sql: str = ""
    post_sql: str = ""
    insert_override_sql: str = ""
    update_override_sql: str = ""
    delete_override_sql: str = ""
    truncate_target: bool = False
    load_type: str = "NORMAL"  # NORMAL, INSERT, UPDATE, DELETE, UPSERT
    reject_file: str = ""
    reject_threshold: int = 0

    def to_dict(self) -> Dict[str, Any]:
        return {
            "target_name": self.target_name,
            "session_name": self.session_name,
            "pre_sql": self.pre_sql,
            "post_sql": self.post_sql,
            "insert_override_sql": self.insert_override_sql,
            "update_override_sql": self.update_override_sql,
            "delete_override_sql": self.delete_override_sql,
            "truncate_target": self.truncate_target,
            "load_type": self.load_type,
            "reject_file": self.reject_file,
            "reject_threshold": self.reject_threshold,
        }


@dataclass
class SessionSQLMetadata:
    """Metadata for Session-level Pre/Post SQL."""
    session_name: str
    workflow_name: str
    pre_session_sql: str = ""
    post_session_sql: str = ""
    post_session_success_sql: str = ""
    post_session_failure_sql: str = ""
    connection_pre_sql: str = ""
    connection_post_sql: str = ""
    pre_session_command: str = ""
    post_session_success_command: str = ""
    post_session_failure_command: str = ""

    def to_dict(self) -> Dict[str, Any]:
        return {
            "session_name": self.session_name,
            "workflow_name": self.workflow_name,
            "pre_session_sql": self.pre_session_sql,
            "post_session_sql": self.post_session_sql,
            "post_session_success_sql": self.post_session_success_sql,
            "post_session_failure_sql": self.post_session_failure_sql,
            "connection_pre_sql": self.connection_pre_sql,
            "connection_post_sql": self.connection_post_sql,
            "pre_session_command": self.pre_session_command,
            "post_session_success_command": self.post_session_success_command,
            "post_session_failure_command": self.post_session_failure_command,
        }


@dataclass
class WorkflowTaskMetadata:
    """Metadata for workflow-level tasks (Command, Email, Decision, etc.)."""
    task_name: str
    task_type: str
    workflow_name: str
    commands: List[Dict[str, str]] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "task_name": self.task_name,
            "task_type": self.task_type,
            "workflow_name": self.workflow_name,
            "commands": self.commands,
        }


@dataclass
class UpdateStrategyMetadata:
    """Enhanced metadata for Update Strategy transformation."""
    transformation_name: str
    mapping_name: str
    update_strategy_expression: str = ""
    key_columns: List[str] = field(default_factory=list)
    update_columns: List[str] = field(default_factory=list)
    insert_columns: List[str] = field(default_factory=list)
    forward_rejected: bool = True
    tracing_level: str = "Normal"

    def to_dict(self) -> Dict[str, Any]:
        return {
            "transformation_name": self.transformation_name,
            "mapping_name": self.mapping_name,
            "update_strategy_expression": self.update_strategy_expression,
            "key_columns": self.key_columns,
            "update_columns": self.update_columns,
            "insert_columns": self.insert_columns,
            "forward_rejected": self.forward_rejected,
            "tracing_level": self.tracing_level,
        }


@dataclass
class TransformationMetadataCatalog:
    """Catalog of all extracted transformation metadata."""
    sequences: List[SequenceMetadata] = field(default_factory=list)
    stored_procedures: List[StoredProcedureMetadata] = field(default_factory=list)
    ranks: List[RankMetadata] = field(default_factory=list)
    normalizers: List[NormalizerMetadata] = field(default_factory=list)
    aggregators: List[AggregatorMetadata] = field(default_factory=list)
    source_qualifiers: List[SourceQualifierMetadata] = field(default_factory=list)
    target_loads: List[TargetLoadMetadata] = field(default_factory=list)
    session_sqls: List[SessionSQLMetadata] = field(default_factory=list)
    update_strategies: List[UpdateStrategyMetadata] = field(default_factory=list)
    workflow_tasks: List[WorkflowTaskMetadata] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "sequences": [s.to_dict() for s in self.sequences],
            "stored_procedures": [sp.to_dict() for sp in self.stored_procedures],
            "ranks": [r.to_dict() for r in self.ranks],
            "normalizers": [n.to_dict() for n in self.normalizers],
            "aggregators": [a.to_dict() for a in self.aggregators],
            "source_qualifiers": [sq.to_dict() for sq in self.source_qualifiers],
            "target_loads": [tl.to_dict() for tl in self.target_loads],
            "session_sqls": [ss.to_dict() for ss in self.session_sqls],
            "update_strategies": [us.to_dict() for us in self.update_strategies],
            "workflow_tasks": [wt.to_dict() for wt in self.workflow_tasks],
            "statistics": self.get_statistics(),
        }

    def get_statistics(self) -> Dict[str, int]:
        return {
            "sequence_count": len(self.sequences),
            "stored_procedure_count": len(self.stored_procedures),
            "rank_count": len(self.ranks),
            "normalizer_count": len(self.normalizers),
            "aggregator_count": len(self.aggregators),
            "source_qualifier_count": len(self.source_qualifiers),
            "target_load_count": len(self.target_loads),
            "session_sql_count": len(self.session_sqls),
            "update_strategy_count": len(self.update_strategies),
            "workflow_task_count": len(self.workflow_tasks),
        }


class TransformationMetadataExtractor:
    """
    Extracts detailed transformation metadata for forward engineering.

    This extractor fills the gaps identified in Phase 3/4 translators:
    - Sequence Generator attributes
    - Stored Procedure configuration
    - Rank transformation settings
    - Enhanced Normalizer metadata
    - Source Qualifier Pre/Post SQL
    - Target Pre/Post SQL from sessions
    """

    def __init__(self):
        """Initialize the extractor."""
        self.catalog = TransformationMetadataCatalog()

    def extract_from_documents(
        self,
        documents: Dict[str, PowermartDocument]
    ) -> TransformationMetadataCatalog:
        """
        Extract transformation metadata from multiple documents.

        Args:
            documents: Dictionary of xml_path -> PowermartDocument

        Returns:
            TransformationMetadataCatalog with all extracted metadata
        """
        logger.info(f"Extracting transformation metadata from {len(documents)} documents")

        for xml_path, doc in documents.items():
            self.extract_from_document(doc, xml_path)

        stats = self.catalog.get_statistics()
        logger.info(f"Extraction complete: {stats}")

        return self.catalog

    def extract_from_document(
        self,
        document: PowermartDocument,
        xml_path: str = ""
    ) -> None:
        """
        Extract transformation metadata from a single document.

        Args:
            document: PowermartDocument to extract from
            xml_path: Path to the XML file (for tracking)
        """
        # Build a lookup of folder-level TASK elements (Command tasks with VALUEPAIRs)
        # These are siblings of WORKFLOW inside the FOLDER element.
        folder_tasks_lookup = self._build_folder_tasks_lookup(xml_path)

        # Extract from mappings
        for mapping in document.mappings:
            for trans in mapping.transformations:
                trans_type = TransformationType.from_string(trans.type)

                if trans_type == TransformationType.SEQUENCE_GENERATOR:
                    seq = self._extract_sequence(trans, mapping.name)
                    self.catalog.sequences.append(seq)

                elif trans_type == TransformationType.STORED_PROCEDURE:
                    sp = self._extract_stored_procedure(trans, mapping.name)
                    self.catalog.stored_procedures.append(sp)

                elif trans_type == TransformationType.RANK:
                    rank = self._extract_rank(trans, mapping.name)
                    self.catalog.ranks.append(rank)

                elif trans_type == TransformationType.NORMALIZER:
                    norm = self._extract_normalizer(trans, mapping.name)
                    self.catalog.normalizers.append(norm)

                elif trans_type == TransformationType.AGGREGATOR:
                    agg = self._extract_aggregator(trans, mapping.name)
                    self.catalog.aggregators.append(agg)

                elif trans_type == TransformationType.SOURCE_QUALIFIER:
                    sq = self._extract_source_qualifier(trans, mapping.name)
                    self.catalog.source_qualifiers.append(sq)

                elif trans_type == TransformationType.UPDATE_STRATEGY:
                    us = self._extract_update_strategy(trans, mapping.name)
                    self.catalog.update_strategies.append(us)

        # Extract from sessions
        for session in document.sessions:
            # Extract session-level SQL and commands
            session_sql = self._extract_session_sql(session, document, folder_tasks_lookup)
            if session_sql:
                self.catalog.session_sqls.append(session_sql)

            # Extract target load settings from session extensions
            for ext in session.extensions:
                if ext.extension_type.lower() in ["writer", "target"]:
                    target_load = self._extract_target_load(ext, session.name)
                    if target_load:
                        self.catalog.target_loads.append(target_load)

        # Extract workflow-level tasks (Command, Email, Decision, etc.)
        self._extract_workflow_tasks(document, folder_tasks_lookup)

        # Merge session-level Pre/Post SQL overrides from transformation instances
        # into the corresponding source qualifier catalog entries.
        # In Informatica, the actual runtime Pre/Post SQL for Source Qualifiers
        # is often set as a session-level override in SESSTRANSFORMATIONINST,
        # not in the mapping-level TRANSFORMATION definition.
        self._merge_session_sql_overrides(document)

    def _extract_sequence(self, trans: Transformation, mapping_name: str) -> SequenceMetadata:
        """Extract Sequence Generator metadata."""
        # Get attributes
        start_value = self._get_attr_int(trans, "Start Value", 1)
        increment = self._get_attr_int(trans, "Increment By", 1)
        end_value = self._get_attr_int(trans, "End Value", None)
        cycle_str = self._get_attr(trans, "Cycle", "NO")
        reset_str = self._get_attr(trans, "Reset", "NO")

        # Find output ports
        output_port = ""
        current_value_port = ""
        for field in trans.fields:
            field_name_upper = field.name.upper()
            if "NEXTVAL" in field_name_upper or field_name_upper == "NEXTVAL":
                output_port = field.name
            elif "CURRVAL" in field_name_upper or field_name_upper == "CURRVAL":
                current_value_port = field.name

        # If no standard naming, use first output port
        if not output_port:
            for field in trans.output_fields:
                output_port = field.name
                break

        # Generate sequence name
        seq_name = f"SEQ_{mapping_name}_{trans.name}".upper().replace(" ", "_")

        return SequenceMetadata(
            transformation_name=trans.name,
            mapping_name=mapping_name,
            sequence_name=seq_name,
            start_value=start_value,
            increment=increment,
            end_value=end_value,
            cycle=cycle_str.upper() == "YES",
            output_port=output_port,
            current_value_port=current_value_port,
            approach=SequenceApproach.SEQUENCE,
            reset_on_session=reset_str.upper() == "YES",
        )

    def _extract_stored_procedure(self, trans: Transformation, mapping_name: str) -> StoredProcedureMetadata:
        """Extract Stored Procedure transformation metadata."""
        # Get attributes
        proc_name = self._get_attr(trans, "Stored Procedure Name", "")
        owner_name = self._get_attr(trans, "Owner Name", "")
        connection = self._get_attr(trans, "Connection Information", "")
        sp_type = self._get_attr(trans, "Stored Procedure Type", "Normal")
        has_return = self._get_attr(trans, "Has Return Value", "NO")
        is_resultset = self._get_attr(trans, "Is Resultset", "NO")
        stop_error = self._get_attr(trans, "Stop On Error", "YES")
        db_type = self._get_attr(trans, "Database Type", "Oracle")

        # Determine execution mode
        mode_map = {
            "normal": StoredProcedureMode.NORMAL,
            "per_row": StoredProcedureMode.PER_ROW,
            "call per row": StoredProcedureMode.PER_ROW,
            "pre session": StoredProcedureMode.PRE_SESSION,
            "post session": StoredProcedureMode.POST_SESSION,
        }
        exec_mode = mode_map.get(sp_type.lower(), StoredProcedureMode.NORMAL)

        # Extract parameters from ports
        parameters = []
        for field in trans.fields:
            port_type = field.port_type.lower() if field.port_type else ""
            direction = "IN"
            if "output" in port_type or "out" in port_type:
                direction = "OUT"
            elif "inout" in port_type:
                direction = "INOUT"
            elif "input" in port_type or "in" in port_type:
                direction = "IN"

            parameters.append({
                "name": field.name,
                "datatype": field.datatype or "VARCHAR",
                "precision": field.precision,
                "scale": field.scale,
                "direction": direction,
            })

        return StoredProcedureMetadata(
            transformation_name=trans.name,
            mapping_name=mapping_name,
            procedure_name=proc_name or trans.name,
            owner_name=owner_name,
            connection_name=connection,
            execution_mode=exec_mode,
            parameters=parameters,
            has_return_value=has_return.upper() == "YES",
            is_resultset=is_resultset.upper() == "YES",
            stop_on_error=stop_error.upper() == "YES",
            database_type=db_type,
        )

    def _extract_rank(self, trans: Transformation, mapping_name: str) -> RankMetadata:
        """Extract Rank transformation metadata."""
        # Get attributes
        top_n_str = self._get_attr(trans, "Top/Bottom", "")
        case_sensitive = self._get_attr(trans, "Case Sensitive String Comparison", "NO")

        # Determine TOP N value
        top_n = None
        if top_n_str:
            match = re.search(r'(\d+)', top_n_str)
            if match:
                top_n = int(match.group(1))

        # Find rank column, partition columns, and output port
        rank_column = ""
        rank_direction = "DESC"
        partition_columns = []
        rank_output_port = "RANKINDEX"

        for field in trans.fields:
            field_name_upper = field.name.upper()

            # Look for RANKINDEX output port
            if "RANKINDEX" in field_name_upper or field_name_upper == "RANKINDEX":
                rank_output_port = field.name

            # Check for rank column based on expression type
            expr_type = (field.expression_type or "").upper()
            if expr_type in ["DESC", "DESCENDING"]:
                rank_column = field.name
                rank_direction = "DESC"
            elif expr_type in ["ASC", "ASCENDING"]:
                rank_column = field.name
                rank_direction = "ASC"

            # Check for group by / partition columns
            if expr_type == "GROUPBY":
                partition_columns.append(field.name)

        # Determine rank function based on settings
        rank_func = RankFunction.ROW_NUMBER
        if self._get_attr(trans, "Rank Type", "") == "Rank":
            rank_func = RankFunction.RANK
        elif self._get_attr(trans, "Dense Rank", "NO").upper() == "YES":
            rank_func = RankFunction.DENSE_RANK

        return RankMetadata(
            transformation_name=trans.name,
            mapping_name=mapping_name,
            rank_column=rank_column,
            rank_direction=rank_direction,
            partition_columns=partition_columns,
            top_n=top_n,
            rank_function=rank_func,
            rank_output_port=rank_output_port,
            case_sensitive=case_sensitive.upper() == "YES",
        )

    def _extract_normalizer(self, trans: Transformation, mapping_name: str) -> NormalizerMetadata:
        """Extract enhanced Normalizer metadata."""
        occurs_columns = []
        key_columns = []
        occurs_count = 1

        # Analyze fields to find OCCURS structure
        occurs_pattern = re.compile(r'(\w+)(\d+)$')

        field_groups: Dict[str, List[str]] = {}

        for field in trans.fields:
            # Check if field has ref_source_field (indicates OCCURS)
            if field.ref_source_field:
                occurs_columns.append(field.name)

                # Try to determine occurs count from naming pattern
                match = occurs_pattern.match(field.name)
                if match:
                    base_name = match.group(1)
                    index = int(match.group(2))
                    if base_name not in field_groups:
                        field_groups[base_name] = []
                    field_groups[base_name].append(index)

            # Fields with no ref_source_field and marked as INPUT are likely keys
            elif "input" in (field.port_type or "").lower():
                key_columns.append(field.name)

        # Calculate max occurs count from field groups
        for base_name, indices in field_groups.items():
            max_idx = max(indices) if indices else 1
            occurs_count = max(occurs_count, max_idx)

        # Determine output value column naming
        value_column = "VALUE"
        index_column = "OCCURS_INDEX"
        for field in trans.output_fields:
            name_upper = field.name.upper()
            if "VALUE" in name_upper:
                value_column = field.name
            elif "INDEX" in name_upper or "OCCUR" in name_upper:
                index_column = field.name

        return NormalizerMetadata(
            transformation_name=trans.name,
            mapping_name=mapping_name,
            occurs_columns=occurs_columns,
            occurs_count=occurs_count,
            key_columns=key_columns,
            value_column=value_column,
            index_column=index_column,
            source_data_type="RELATIONAL",
            level=1,
        )

    def _extract_aggregator(self, trans: Transformation, mapping_name: str) -> AggregatorMetadata:
        """Extract enhanced Aggregator metadata."""
        group_by_columns = []
        aggregate_expressions = {}

        for field in trans.fields:
            expr_type = (field.expression_type or "").upper()

            if expr_type == "GROUPBY":
                group_by_columns.append(field.name)
            elif field.expression:
                aggregate_expressions[field.name] = field.expression

        # Get HAVING condition if present
        having_condition = self._get_attr(trans, "Having Condition", "")

        # Get sort and cache settings
        sorted_ports = self._get_attr_int(trans, "Number Of Sorted Ports", 0)
        pre_sorted = self._get_attr(trans, "Sorted Input", "NO").upper() == "YES"
        cache = self._get_attr(trans, "Aggregate Cache", "Auto")

        return AggregatorMetadata(
            transformation_name=trans.name,
            mapping_name=mapping_name,
            group_by_columns=group_by_columns,
            aggregate_expressions=aggregate_expressions,
            having_condition=having_condition,
            sorted_ports=sorted_ports,
            pre_sorted=pre_sorted,
            aggregate_cache=cache,
        )

    def _extract_source_qualifier(self, trans: Transformation, mapping_name: str) -> SourceQualifierMetadata:
        """Extract enhanced Source Qualifier metadata."""
        sql_query = self._get_attr(trans, "Sql Query", "")
        user_join = self._get_attr(trans, "User Defined Join", "")
        source_filter = trans.filter_condition or self._get_attr(trans, "Source Filter", "")
        pre_sql = self._get_attr(trans, "Pre SQL", "")
        post_sql = self._get_attr(trans, "Post SQL", "")
        distinct = self._get_attr(trans, "Select Distinct", "NO")
        sorted_ports = self._get_attr_int(trans, "Number Of Sorted Ports", 0)

        # Find source tables from connected sources
        source_tables = []
        # Note: This would need to be populated from the mapping's source definitions
        # For now, we'll try to extract from SQL Query if present
        if sql_query:
            # Simple extraction from FROM clause
            from_match = re.search(r'FROM\s+([A-Za-z0-9_.,\s]+)', sql_query, re.IGNORECASE)
            if from_match:
                tables_str = from_match.group(1)
                # Split on common delimiters
                tables = re.split(r'[,\s]+', tables_str)
                source_tables = [t.strip() for t in tables if t.strip() and t.upper() not in ["WHERE", "JOIN", "LEFT", "RIGHT", "INNER", "OUTER"]]

        return SourceQualifierMetadata(
            transformation_name=trans.name,
            mapping_name=mapping_name,
            sql_query=sql_query,
            user_defined_join=user_join,
            source_filter=source_filter,
            pre_sql=pre_sql,
            post_sql=post_sql,
            select_distinct=distinct.upper() == "YES",
            sorted_ports=sorted_ports,
            source_tables=source_tables,
        )

    def _extract_update_strategy(self, trans: Transformation, mapping_name: str) -> UpdateStrategyMetadata:
        """Extract enhanced Update Strategy metadata."""
        expression = trans.update_strategy_expression or self._get_attr(trans, "Update Strategy Expression", "")
        forward_rejected = self._get_attr(trans, "Forward Rejected Rows", "YES")
        tracing = self._get_attr(trans, "Tracing Level", "Normal")

        # Infer key columns from expression or connected target
        key_columns = []
        update_columns = []
        insert_columns = []

        # Analyze fields to categorize
        for field in trans.fields:
            field_name = field.name
            field_name_upper = field_name.upper()

            # Common key column patterns
            if any(kw in field_name_upper for kw in ["_ID", "_KEY", "_PK", "ID_"]):
                key_columns.append(field_name)
            else:
                # Non-key fields are typically update/insert columns
                update_columns.append(field_name)
                insert_columns.append(field_name)

        return UpdateStrategyMetadata(
            transformation_name=trans.name,
            mapping_name=mapping_name,
            update_strategy_expression=expression,
            key_columns=key_columns,
            update_columns=update_columns,
            insert_columns=insert_columns,
            forward_rejected=forward_rejected.upper() == "YES",
            tracing_level=tracing,
        )

    def _extract_session_sql(self, session, document: PowermartDocument,
                             folder_tasks_lookup: Optional[Dict[str, List[Dict[str, str]]]] = None) -> Optional[SessionSQLMetadata]:
        """Extract session-level Pre/Post SQL and session commands."""
        # Get session attributes
        pre_session = ""
        post_session = ""
        post_success = ""
        post_failure = ""
        conn_pre = ""
        conn_post = ""

        for attr in session.attributes:
            attr_name = getattr(attr, 'name', '').lower()
            attr_value = getattr(attr, 'value', '')

            if 'pre' in attr_name and 'sql' in attr_name:
                if 'session' in attr_name:
                    pre_session = attr_value
                elif 'connection' in attr_name:
                    conn_pre = attr_value
            elif 'post' in attr_name and 'sql' in attr_name:
                if 'success' in attr_name:
                    post_success = attr_value
                elif 'failure' in attr_name or 'fail' in attr_name:
                    post_failure = attr_value
                elif 'session' in attr_name:
                    post_session = attr_value
                elif 'connection' in attr_name:
                    conn_post = attr_value

        # Extract session commands from SESSIONCOMPONENT elements
        pre_cmd = ""
        post_success_cmd = ""
        post_failure_cmd = ""

        for comp in session.components:
            comp_type_lower = comp.component_type.lower()
            if "command" not in comp_type_lower:
                continue

            # Get value_pairs - either from embedded task or folder-level lookup
            value_pairs = comp.value_pairs
            if comp.reusable and not value_pairs and folder_tasks_lookup:
                folder_vps = folder_tasks_lookup.get(comp.ref_object_name)
                if folder_vps:
                    value_pairs = folder_vps

            # Format commands as string: "name1: value1; name2: value2"
            cmd_parts = []
            for vp in value_pairs:
                name = vp.get("name", "")
                value = vp.get("value", "")
                if name and value:
                    cmd_parts.append(f"{name}: {value}")
                elif value:
                    cmd_parts.append(value)
            cmd_str = "; ".join(cmd_parts)

            if "pre-session" in comp_type_lower and "command" in comp_type_lower:
                pre_cmd = cmd_str
            elif "success" in comp_type_lower and "command" in comp_type_lower:
                post_success_cmd = cmd_str
            elif "failure" in comp_type_lower and "command" in comp_type_lower:
                post_failure_cmd = cmd_str

        # Only create metadata if any SQL or command was found
        if any([pre_session, post_session, post_success, post_failure, conn_pre, conn_post,
                pre_cmd, post_success_cmd, post_failure_cmd]):
            # Find workflow name
            workflow_name = ""
            for wf in document.workflows:
                workflow_name = wf.name
                break

            return SessionSQLMetadata(
                session_name=session.name,
                workflow_name=workflow_name,
                pre_session_sql=pre_session,
                post_session_sql=post_session,
                post_session_success_sql=post_success,
                post_session_failure_sql=post_failure,
                connection_pre_sql=conn_pre,
                connection_post_sql=conn_post,
                pre_session_command=pre_cmd,
                post_session_success_command=post_success_cmd,
                post_session_failure_command=post_failure_cmd,
            )

        return None

    def _extract_target_load(self, extension, session_name: str) -> Optional[TargetLoadMetadata]:
        """Extract target load settings from SessionExtension."""
        target_name = getattr(extension, 'sinstancename', '') or getattr(extension, 'name', '')
        if not target_name:
            return None

        # Extract attributes
        pre_sql = ""
        post_sql = ""
        insert_override = ""
        update_override = ""
        delete_override = ""
        truncate = False
        load_type = "NORMAL"
        reject_file = ""
        reject_threshold = 0

        for attr in extension.attributes:
            attr_name = getattr(attr, 'name', '').lower()
            attr_value = getattr(attr, 'value', '')

            if 'pre' in attr_name and 'sql' in attr_name:
                pre_sql = attr_value
            elif 'post' in attr_name and 'sql' in attr_name:
                post_sql = attr_value
            elif 'insert' in attr_name and 'override' in attr_name:
                insert_override = attr_value
            elif 'update' in attr_name and 'override' in attr_name:
                update_override = attr_value
            elif 'delete' in attr_name and 'override' in attr_name:
                delete_override = attr_value
            elif 'truncate' in attr_name:
                truncate = attr_value.upper() == "YES"
            elif 'load type' in attr_name or 'target load type' in attr_name:
                load_type = attr_value.upper()
            elif 'reject' in attr_name:
                if 'file' in attr_name:
                    reject_file = attr_value
                elif 'threshold' in attr_name or 'limit' in attr_name:
                    try:
                        reject_threshold = int(attr_value)
                    except ValueError:
                        pass

        # Only return if meaningful settings found
        if any([pre_sql, post_sql, insert_override, update_override, delete_override, truncate]):
            return TargetLoadMetadata(
                target_name=target_name,
                session_name=session_name,
                pre_sql=pre_sql,
                post_sql=post_sql,
                insert_override_sql=insert_override,
                update_override_sql=update_override,
                delete_override_sql=delete_override,
                truncate_target=truncate,
                load_type=load_type,
                reject_file=reject_file,
                reject_threshold=reject_threshold,
            )

        return None

    def _build_folder_tasks_lookup(self, xml_path: str) -> Dict[str, List[Dict[str, str]]]:
        """
        Build a lookup of folder-level TASK elements and their VALUEPAIR children.

        Folder-level TASKs (siblings of WORKFLOW inside FOLDER) contain the actual
        command definitions for reusable session components. This parses the XML
        directly to extract VALUEPAIR data that the model doesn't capture for
        folder-level tasks.

        Args:
            xml_path: Path to the XML file

        Returns:
            Dictionary mapping task name -> list of {name, value} dicts from VALUEPAIRs
        """
        lookup: Dict[str, List[Dict[str, str]]] = {}
        if not xml_path:
            return lookup

        try:
            tree = DefusedET.parse(xml_path)
            root = tree.getroot()

            # Find TASK elements: both direct children of FOLDER (reusable tasks)
            # and children of WORKFLOW (non-reusable inline Command tasks)
            for folder_elem in root.iter("FOLDER"):
                for task_elem in folder_elem.findall("TASK"):
                    task_name = task_elem.get("NAME", "")
                    if not task_name:
                        continue

                    value_pairs = []
                    for vp_elem in task_elem.findall("VALUEPAIR"):
                        value_pairs.append({
                            "exec_order": vp_elem.get("EXECORDER", ""),
                            "name": vp_elem.get("NAME", ""),
                            "value": vp_elem.get("VALUE", ""),
                        })

                    if value_pairs:
                        lookup[task_name] = value_pairs

                # Also check TASK elements inside WORKFLOW elements
                for wf_elem in folder_elem.findall("WORKFLOW"):
                    for task_elem in wf_elem.findall("TASK"):
                        task_name = task_elem.get("NAME", "")
                        if not task_name or task_name in lookup:
                            continue

                        value_pairs = []
                        for vp_elem in task_elem.findall("VALUEPAIR"):
                            value_pairs.append({
                                "exec_order": vp_elem.get("EXECORDER", ""),
                                "name": vp_elem.get("NAME", ""),
                                "value": vp_elem.get("VALUE", ""),
                            })

                        if value_pairs:
                            lookup[task_name] = value_pairs
        except Exception as e:
            logger.warning(f"Could not parse XML for folder tasks lookup: {e}")

        return lookup

    def _extract_workflow_tasks(self, document: PowermartDocument,
                                folder_tasks_lookup: Dict[str, List[Dict[str, str]]]) -> None:
        """
        Extract workflow-level tasks (Command, Email, Decision, etc.).

        These are TASKINSTANCE elements inside WORKFLOW that reference non-Session,
        non-Start tasks defined at the folder level.

        Args:
            document: PowermartDocument to extract from
            folder_tasks_lookup: Lookup of folder-level TASK VALUEPAIRs
        """
        skip_types = {"session", "start"}

        for wf in document.workflows:
            for task in wf.tasks:
                task_type_lower = task.task_type.lower()
                if task_type_lower in skip_types:
                    continue

                # Look up folder-level task data for VALUEPAIR commands
                commands = []
                # Check if there's a "taskname" attribute (from TASKINSTANCE parsing)
                taskname_ref = task.get_attribute("taskname") or task.name
                folder_vps = folder_tasks_lookup.get(taskname_ref, [])
                for vp in folder_vps:
                    commands.append({
                        "name": vp.get("name", ""),
                        "value": vp.get("value", ""),
                    })

                wt = WorkflowTaskMetadata(
                    task_name=task.name,
                    task_type=task.task_type,
                    workflow_name=wf.name,
                    commands=commands,
                )
                self.catalog.workflow_tasks.append(wt)

    def _merge_session_sql_overrides(self, document) -> None:
        """
        Merge session-level Pre/Post SQL overrides from SESSTRANSFORMATIONINST
        into the corresponding source qualifier catalog entries.

        In Informatica, runtime Pre/Post SQL for Source Qualifiers is often
        configured as session-level overrides in SESSTRANSFORMATIONINST rather
        than in the mapping-level TRANSFORMATION definition.
        """
        for session in document.sessions:
            # Use the Session model's all_pre_sql and all_post_sql properties
            # which aggregate from both extensions and transformation_insts
            all_pre = session.all_pre_sql
            all_post = session.all_post_sql

            # Try to merge Pre SQL into matching source_qualifier entries
            for pre_entry in all_pre:
                instance_name = pre_entry.get("instance", "")
                sql = pre_entry.get("sql", "")
                if not sql:
                    continue

                # Find matching source qualifier by transformation name
                matched = False
                for sq in self.catalog.source_qualifiers:
                    if sq.transformation_name.lower() == instance_name.lower():
                        if not sq.pre_sql:
                            sq.pre_sql = sql
                        matched = True
                        break

                # If no matching SQ found, also check target_loads
                if not matched:
                    for tl in self.catalog.target_loads:
                        if tl.target_name.lower() == instance_name.lower():
                            if not tl.pre_sql:
                                tl.pre_sql = sql
                            matched = True
                            break

                # If still no match, create a new session_sql entry
                if not matched:
                    # Find workflow name
                    workflow_name = ""
                    for wf in document.workflows:
                        workflow_name = wf.name
                        break

                    # Check if session_sql entry exists for this session
                    existing = None
                    for ss in self.catalog.session_sqls:
                        if ss.session_name == session.name:
                            existing = ss
                            break

                    if existing:
                        if not existing.pre_session_sql:
                            existing.pre_session_sql = f"[{instance_name}] {sql}"
                        else:
                            existing.pre_session_sql += f"\n[{instance_name}] {sql}"
                    else:
                        self.catalog.session_sqls.append(SessionSQLMetadata(
                            session_name=session.name,
                            workflow_name=workflow_name,
                            pre_session_sql=f"[{instance_name}] {sql}",
                        ))

            # Same for Post SQL
            for post_entry in all_post:
                instance_name = post_entry.get("instance", "")
                sql = post_entry.get("sql", "")
                if not sql:
                    continue

                matched = False
                for sq in self.catalog.source_qualifiers:
                    if sq.transformation_name.lower() == instance_name.lower():
                        if not sq.post_sql:
                            sq.post_sql = sql
                        matched = True
                        break

                if not matched:
                    for tl in self.catalog.target_loads:
                        if tl.target_name.lower() == instance_name.lower():
                            if not tl.post_sql:
                                tl.post_sql = sql
                            matched = True
                            break

                if not matched:
                    workflow_name = ""
                    for wf in document.workflows:
                        workflow_name = wf.name
                        break

                    existing = None
                    for ss in self.catalog.session_sqls:
                        if ss.session_name == session.name:
                            existing = ss
                            break

                    if existing:
                        if not existing.post_session_sql:
                            existing.post_session_sql = f"[{instance_name}] {sql}"
                        else:
                            existing.post_session_sql += f"\n[{instance_name}] {sql}"
                    else:
                        self.catalog.session_sqls.append(SessionSQLMetadata(
                            session_name=session.name,
                            workflow_name=workflow_name,
                            post_session_sql=f"[{instance_name}] {sql}",
                        ))

    # Helper methods

    def _get_attr(self, trans: Transformation, attr_name: str, default: str = "") -> str:
        """Get transformation attribute by name."""
        value = trans.get_attribute(attr_name)
        return value if value else default

    def _get_attr_int(self, trans: Transformation, attr_name: str, default: Optional[int] = None) -> Optional[int]:
        """Get transformation attribute as integer."""
        value = trans.get_attribute(attr_name)
        if value:
            try:
                return int(value)
            except ValueError:
                pass
        return default

    def get_catalog(self) -> TransformationMetadataCatalog:
        """Get the transformation metadata catalog."""
        return self.catalog

    def reset(self) -> None:
        """Reset the extractor state."""
        self.catalog = TransformationMetadataCatalog()
