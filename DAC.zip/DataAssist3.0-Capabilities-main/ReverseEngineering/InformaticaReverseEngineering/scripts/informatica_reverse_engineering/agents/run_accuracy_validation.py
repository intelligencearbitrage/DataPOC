"""
CLI entry point for Informatica RE accuracy validation.

Usage:
    # Single file
    python -m informatica_reverse_engineering.agents.run_accuracy_validation \
        --xml inputs/Auto_Loans_XML/wf_XXX.xml \
        --output-dir output/Auto_Loans_All_v2/wf_XXX/

    # Batch (all XMLs)
    python -m informatica_reverse_engineering.agents.run_accuracy_validation \
        --input-dir inputs/Auto_Loans_XML/ \
        --output-base output/Auto_Loans_All_v2/
"""

import argparse
import sys
import time
from pathlib import Path

_SCRIPTS_DIR = Path(__file__).resolve().parent.parent.parent
if str(_SCRIPTS_DIR) not in sys.path:
    sys.path.insert(0, str(_SCRIPTS_DIR))

from informatica_reverse_engineering.agents.accuracy_validator import AccuracyValidator
from informatica_reverse_engineering.utils.logging_config import setup_logging, get_logger

logger = get_logger("run_accuracy_validation")


def main():
    parser = argparse.ArgumentParser(
        description="Informatica RE Accuracy Validator",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )

    # Single-file mode
    parser.add_argument("--xml", help="Single XML file to validate")
    parser.add_argument("--output-dir", help="Output directory for that XML")

    # Batch mode (per-XML output folders)
    parser.add_argument("--input-dir", help="Directory of XML files (batch mode)")
    parser.add_argument("--output-base", help="Base output directory (batch mode)")

    # Aggregated mode (multiple XMLs, one output folder)
    parser.add_argument("--aggregated-output", help="Aggregated output directory (multi-XML)")

    # Optional
    parser.add_argument("--param-file", help="Parameter file path (for context)")
    parser.add_argument("-v", "--verbose", action="store_true")

    args = parser.parse_args()
    setup_logging("DEBUG" if args.verbose else "INFO")

    validator = AccuracyValidator()

    if args.input_dir and args.aggregated_output:
        # ── Aggregated mode ──────────────────────────────────────────────
        input_dir = Path(args.input_dir)
        output_dir = Path(args.aggregated_output)

        logger.info(f"Aggregated validation: XMLs from {input_dir}, output at {output_dir}")
        start = time.time()

        agg_report = validator.validate_aggregated(
            str(input_dir), str(output_dir), args.param_file
        )

        elapsed = time.time() - start

        # Write report
        report_path = output_dir / "aggregated_accuracy_report.xlsx"
        validator.write_aggregated_report(agg_report, str(report_path))

        # Print summary
        print(f"\n{'='*70}")
        print(f"AGGREGATED VALIDATION COMPLETE — {agg_report['xml_count']} XMLs in {elapsed:.1f}s")
        print(f"{'='*70}")
        print(f"  Overall Score: {agg_report['overall_score']} ({agg_report['letter_grade']})")
        print(f"  Total Field Lineages: {agg_report['total_field_lineages']}")
        print()

        per_xml = agg_report.get("per_xml_reports", [])
        scores = [r["overall_score"] for r in per_xml if r.get("dimensions")]
        if scores:
            print(f"  Highest:  {max(scores):.1f}")
            print(f"  Lowest:   {min(scores):.1f}")
            print()

        print("  Per-XML Scores:")
        for r in sorted(per_xml, key=lambda x: -x.get("overall_score", 0)):
            iss = len(r.get("issues", []))
            lc = r.get("field_lineage_count", 0)
            print(f"    {r['overall_score']:5.1f} ({r['letter_grade']:<2}) {r['workflow_name']} ({lc} lineages, {iss} issues)")

        print()
        print("  Cross-XML Checks:")
        for check in agg_report.get("cross_xml", {}).get("checks", []):
            print(f"    [{check['status']}] {check['check']}: {check['details']}")

        print(f"\n  Report: {report_path}")
        print(f"{'='*70}\n")
        return 0

    elif args.xml and args.output_dir:
        # ── Single-file mode ─────────────────────────────────────────────
        xml_path = Path(args.xml)
        output_dir = Path(args.output_dir)

        if not xml_path.exists():
            logger.error(f"XML not found: {xml_path}")
            return 1

        logger.info(f"Validating: {xml_path.stem}")
        report = validator.validate(str(xml_path), str(output_dir), args.param_file)

        report_path = output_dir / f"{xml_path.stem}_accuracy_report.xlsx"
        validator.write_report(report, str(report_path))

        _print_report(report)
        logger.info(f"Report saved: {report_path}")
        return 0

    elif args.input_dir and args.output_base:
        # ── Batch mode ───────────────────────────────────────────────────
        input_dir = Path(args.input_dir)
        output_base = Path(args.output_base)

        xml_files = sorted(input_dir.glob("*.xml")) + sorted(input_dir.glob("*.XML"))
        if not xml_files:
            logger.error(f"No XML files in {input_dir}")
            return 1

        logger.info(f"Batch validating {len(xml_files)} XMLs")
        start = time.time()

        reports = []
        for i, xml_path in enumerate(xml_files, 1):
            wf_name = xml_path.stem
            output_dir = output_base / wf_name

            if not output_dir.exists():
                logger.warning(f"[{i}/{len(xml_files)}] No output for {wf_name}, skipping")
                continue

            logger.info(f"[{i}/{len(xml_files)}] {wf_name}")
            try:
                report = validator.validate(str(xml_path), str(output_dir), args.param_file)
                reports.append(report)

                # Write per-workflow report
                report_path = output_dir / f"{wf_name}_accuracy_report.xlsx"
                validator.write_report(report, str(report_path))

                grade = report["letter_grade"]
                score = report["overall_score"]
                issues = len(report.get("issues", []))
                logger.info(f"  Score: {score} ({grade}) | Issues: {issues}")

            except Exception as e:
                logger.error(f"  FAILED: {e}")
                reports.append({
                    "workflow_name": wf_name,
                    "overall_score": 0.0,
                    "letter_grade": "F",
                    "dimensions": [],
                    "issues": [{"severity": "High", "dimension": "General",
                                "issue": str(e), "affected_table": "",
                                "affected_field": "", "mapping": ""}],
                })

        elapsed = time.time() - start

        # Write batch summary
        summary_path = output_base / "accuracy_batch_summary.xlsx"
        validator.write_batch_summary(reports, str(summary_path))

        # Print batch summary
        print(f"\n{'='*70}")
        print(f"BATCH VALIDATION COMPLETE — {len(reports)} workflows in {elapsed:.1f}s")
        print(f"{'='*70}")

        scores = [r["overall_score"] for r in reports]
        if scores:
            avg = sum(scores) / len(scores)
            print(f"  Average Score: {avg:.1f} ({_letter_grade_inline(avg)})")
            print(f"  Highest:       {max(scores):.1f}")
            print(f"  Lowest:        {min(scores):.1f}")
            print()

            # Grade distribution
            grades = {}
            for r in reports:
                g = r["letter_grade"]
                grades[g] = grades.get(g, 0) + 1
            print("  Grade Distribution:")
            for g in ["A+", "A", "A-", "B+", "B", "B-", "C+", "C", "D", "F"]:
                if g in grades:
                    print(f"    {g}: {grades[g]}")

        print(f"\n  Summary: {summary_path}")
        print(f"{'='*70}\n")
        return 0

    else:
        parser.print_help()
        return 1


def _print_report(report):
    print(f"\n{'='*60}")
    print(f"ACCURACY REPORT: {report['workflow_name']}")
    print(f"Overall: {report['overall_score']} ({report['letter_grade']})")
    print(f"{'='*60}")
    print(f"{'Dimension':<30} {'Weight':>6} {'Score':>6} {'Exp':>5} {'Found':>5} {'Issues':>6}")
    print(f"{'-'*60}")
    for dim in report["dimensions"]:
        print(f"{dim['name']:<30} {dim['weight']:>5}% {dim['score']:>5.1f} {dim['expected']:>5} {dim['found']:>5} {dim['issue_count']:>6}")
    print(f"{'='*60}")
    issues = report.get("issues", [])
    if issues:
        print(f"\nIssues ({len(issues)}):")
        for iss in issues[:20]:
            print(f"  [{iss['severity']}] {iss['dimension']}: {iss['issue']}")
        if len(issues) > 20:
            print(f"  ... and {len(issues) - 20} more")
    print()


def _letter_grade_inline(score):
    if score >= 95: return "A+"
    if score >= 90: return "A"
    if score >= 85: return "A-"
    if score >= 80: return "B+"
    if score >= 75: return "B"
    if score >= 70: return "B-"
    if score >= 65: return "C+"
    if score >= 60: return "C"
    if score >= 50: return "D"
    return "F"


if __name__ == "__main__":
    sys.exit(main())
