"""
Informatica Reverse Engineering Accuracy Validator.

Compares the source Informatica XML (ground truth) against the generated
output (aggregated lineage JSON + enhanced Excel) and scores accuracy
across 13 weighted dimensions.

Output: a separate accuracy_report.xlsx with Score Summary and Issues sheets.
Does NOT modify existing output files.
"""

import json
import re
import os
from pathlib import Path
from werkzeug.utils import safe_join
from typing import Any, Dict, List, Optional, Tuple

from openpyxl import Workbook, load_workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side

import sys

_SCRIPTS_DIR = Path(__file__).resolve().parent.parent.parent
if str(_SCRIPTS_DIR) not in sys.path:
    sys.path.insert(0, str(_SCRIPTS_DIR))

from informatica_reverse_engineering.parsers.powermart_parser import PowermartParser
from informatica_reverse_engineering.utils.logging_config import get_logger

logger = get_logger("accuracy_validator")

# ── Styling ──────────────────────────────────────────────────────────────────
HEADER_FONT = Font(bold=True, color="FFFFFF", size=11)
HEADER_FILL = PatternFill(start_color="4472C4", end_color="4472C4", fill_type="solid")
PASS_FILL = PatternFill(start_color="C6EFCE", end_color="C6EFCE", fill_type="solid")
WARN_FILL = PatternFill(start_color="FFEB9C", end_color="FFEB9C", fill_type="solid")
FAIL_FILL = PatternFill(start_color="FFC7CE", end_color="FFC7CE", fill_type="solid")
GRADE_FONT = Font(bold=True, size=14)
BORDER = Border(
    bottom=Side(style="thin", color="D9D9D9"),
)


def _apply_header(cell):
    cell.font = HEADER_FONT
    cell.fill = HEADER_FILL
    cell.alignment = Alignment(horizontal="center", vertical="center")


def _score_fill(score: float) -> PatternFill:
    if score >= 85:
        return PASS_FILL
    if score >= 60:
        return WARN_FILL
    return FAIL_FILL


def _letter_grade(score: float) -> str:
    if score >= 95:
        return "A+"
    if score >= 90:
        return "A"
    if score >= 85:
        return "A-"
    if score >= 80:
        return "B+"
    if score >= 75:
        return "B"
    if score >= 70:
        return "B-"
    if score >= 65:
        return "C+"
    if score >= 60:
        return "C"
    if score >= 50:
        return "D"
    return "F"


# ── Dimension Definition ─────────────────────────────────────────────────────

DIMENSIONS = [
    {"name": "Source Table Coverage", "weight": 15},
    {"name": "Source Field Coverage", "weight": 12},
    {"name": "Target Table Coverage", "weight": 15},
    {"name": "Target Field Coverage", "weight": 12},
    {"name": "Lookup Capture", "weight": 8},
    {"name": "Transformation Coverage", "weight": 8},
    {"name": "Parameter Resolution", "weight": 6},
    {"name": "Session Coverage", "weight": 5},
    {"name": "SQL Override Capture", "weight": 5},
    {"name": "Pre/Post SQL Capture", "weight": 4},
    {"name": "BTEQ/Command Task Capture", "weight": 4},
    {"name": "Workflow Task Coverage", "weight": 3},
    {"name": "Cross-Sheet Integrity", "weight": 3},
]


def _strip_brackets(name: str) -> str:
    """Strip SQL Server bracket notation: [Schema].[dbo].[Table] -> Schema.dbo.Table"""
    return re.sub(r"\[([^\]]*)\]", r"\1", name)


# ── Main Validator ───────────────────────────────────────────────────────────

class AccuracyValidator:
    """Scores Informatica RE output accuracy against XML ground truth."""

    def __init__(self):
        self.parser = PowermartParser()

    def validate(
        self,
        xml_path: str,
        output_dir: str,
        param_file: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Run full validation and return the report dict."""
        xml_path = Path(xml_path)
        output_dir = Path(output_dir)
        wf_name = xml_path.stem

        # ── Parse XML ground truth ───────────────────────────────────────
        doc = self.parser.parse_file(str(xml_path))

        # ── Load output JSON ─────────────────────────────────────────────
        json_path = self._find_file(output_dir, "_aggregated_lineage.json")
        if not json_path:
            return self._empty_report(wf_name, "aggregated_lineage.json not found")
        with open(json_path, encoding="utf-8") as f:
            output_json = json.load(f)

        # ── Load output Excel ────────────────────────────────────────────
        xlsx_path = self._find_file(output_dir, "_enhanced_output.xlsx")
        excel_sheets = {}
        if xlsx_path:
            wb = load_workbook(xlsx_path, read_only=True, data_only=True)
            for sheet_name in wb.sheetnames:
                ws = wb[sheet_name]
                rows = list(ws.iter_rows(values_only=True))
                if rows:
                    headers = [str(h or "").strip() for h in rows[0]]
                    data_rows = []
                    for row in rows[1:]:
                        data_rows.append({
                            headers[i]: (str(row[i]).strip() if i < len(row) and row[i] is not None else "")
                            for i in range(len(headers))
                        })
                    excel_sheets[sheet_name] = data_rows
            wb.close()

        field_lineage = output_json.get("field_lineage", [])

        # ── Score each dimension ─────────────────────────────────────────
        results = []
        all_issues = []

        # 1. Source Table Coverage
        score, expected, found, issues = self._check_source_tables(doc, field_lineage)
        results.append({"score": score, "expected": expected, "found": found})
        all_issues.extend(issues)

        # 2. Source Field Coverage
        score, expected, found, issues = self._check_source_fields(doc, field_lineage)
        results.append({"score": score, "expected": expected, "found": found})
        all_issues.extend(issues)

        # 3. Target Table Coverage
        score, expected, found, issues = self._check_target_tables(doc, field_lineage)
        results.append({"score": score, "expected": expected, "found": found})
        all_issues.extend(issues)

        # 4. Target Field Coverage
        score, expected, found, issues = self._check_target_fields(doc, field_lineage)
        results.append({"score": score, "expected": expected, "found": found})
        all_issues.extend(issues)

        # 5. Lookup Capture
        score, expected, found, issues = self._check_lookups(doc, field_lineage, excel_sheets)
        results.append({"score": score, "expected": expected, "found": found})
        all_issues.extend(issues)

        # 6. Transformation Coverage
        score, expected, found, issues = self._check_transformations(doc, excel_sheets, field_lineage)
        results.append({"score": score, "expected": expected, "found": found})
        all_issues.extend(issues)

        # 7. Parameter Resolution
        score, expected, found, issues = self._check_parameters(field_lineage, output_json)
        results.append({"score": score, "expected": expected, "found": found})
        all_issues.extend(issues)

        # 8. Session Coverage
        score, expected, found, issues = self._check_sessions(doc, excel_sheets)
        results.append({"score": score, "expected": expected, "found": found})
        all_issues.extend(issues)

        # 9. SQL Override Capture
        score, expected, found, issues = self._check_sql_overrides(doc, field_lineage)
        results.append({"score": score, "expected": expected, "found": found})
        all_issues.extend(issues)

        # 10. Pre/Post SQL Capture
        score, expected, found, issues = self._check_pre_post_sql(doc, excel_sheets)
        results.append({"score": score, "expected": expected, "found": found})
        all_issues.extend(issues)

        # 11. BTEQ/Command Task Capture
        score, expected, found, issues = self._check_bteq(doc, excel_sheets)
        results.append({"score": score, "expected": expected, "found": found})
        all_issues.extend(issues)

        # 12. Workflow Task Coverage
        score, expected, found, issues = self._check_workflow_tasks(doc, excel_sheets, output_json)
        results.append({"score": score, "expected": expected, "found": found})
        all_issues.extend(issues)

        # 13. Cross-Sheet Integrity
        score, expected, found, issues = self._check_cross_sheet(field_lineage, excel_sheets)
        results.append({"score": score, "expected": expected, "found": found})
        all_issues.extend(issues)

        # ── Compute weighted overall ─────────────────────────────────────
        total_weight = sum(d["weight"] for d in DIMENSIONS)
        weighted_sum = sum(
            r["score"] * d["weight"] for r, d in zip(results, DIMENSIONS)
        )
        overall = weighted_sum / total_weight if total_weight else 0.0
        grade = _letter_grade(overall)

        report = {
            "workflow_name": wf_name,
            "overall_score": round(overall, 1),
            "letter_grade": grade,
            "dimensions": [
                {
                    "name": d["name"],
                    "weight": d["weight"],
                    "score": round(r["score"], 1),
                    "expected": r["expected"],
                    "found": r["found"],
                    "issue_count": sum(
                        1 for iss in all_issues if iss["dimension"] == d["name"]
                    ),
                }
                for d, r in zip(DIMENSIONS, results)
            ],
            "issues": all_issues,
        }
        return report

    # ── Aggregated Validation ────────────────────────────────────────────

    def validate_aggregated(
        self,
        xml_dir: str,
        output_dir: str,
        param_file: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Validate an aggregated output (multiple XMLs → one output folder).

        Groups field_lineage by source_xml, scores each XML individually,
        then runs cross-XML checks on the aggregated output.
        """
        xml_dir = Path(xml_dir)
        output_dir = Path(output_dir)

        # ── Load aggregated JSON ─────────────────────────────────────────
        json_path = self._find_file(output_dir, "_lineage.json") or self._find_file(output_dir, "lineage.json")
        if not json_path:
            return {"error": "No aggregated lineage JSON found", "per_xml_reports": [], "cross_xml": {}}
        with open(json_path, encoding="utf-8") as f:
            output_json = json.load(f)

        # ── Load Excel ───────────────────────────────────────────────────
        xlsx_path = self._find_file(output_dir, "_enhanced_output.xlsx") or self._find_file(output_dir, "enhanced_output.xlsx")
        excel_sheets = {}
        if xlsx_path:
            wb = load_workbook(xlsx_path, read_only=True, data_only=True)
            for sheet_name in wb.sheetnames:
                ws = wb[sheet_name]
                rows = list(ws.iter_rows(values_only=True))
                if rows:
                    headers = [str(h or "").strip() for h in rows[0]]
                    data_rows = []
                    for row in rows[1:]:
                        data_rows.append({
                            headers[i]: (str(row[i]).strip() if i < len(row) and row[i] is not None else "")
                            for i in range(len(headers))
                        })
                    excel_sheets[sheet_name] = data_rows
            wb.close()

        field_lineage = output_json.get("field_lineage", [])

        # ── Group field_lineage by source_xml ────────────────────────────
        from collections import defaultdict
        xml_groups: Dict[str, list] = defaultdict(list)
        for entry in field_lineage:
            src_xml = entry.get("source_xml", "unknown")
            xml_groups[src_xml].append(entry)

        # ── Find matching XML files ──────────────────────────────────────
        xml_files = sorted(xml_dir.glob("*.xml")) + sorted(xml_dir.glob("*.XML"))
        xml_by_name = {f.name: f for f in xml_files}
        # Also map by stem for flexible matching
        xml_by_stem = {f.stem.lower(): f for f in xml_files}

        # ── Per-XML validation ───────────────────────────────────────────
        per_xml_reports = []
        for src_xml_name, entries in sorted(xml_groups.items()):
            # Find the actual XML file
            xml_file = xml_by_name.get(src_xml_name)
            if not xml_file:
                stem = src_xml_name.replace(".xml", "").replace(".XML", "").lower()
                xml_file = xml_by_stem.get(stem)
            if not xml_file:
                per_xml_reports.append({
                    "workflow_name": src_xml_name,
                    "overall_score": 0.0,
                    "letter_grade": "F",
                    "dimensions": [],
                    "issues": [{"severity": "High", "dimension": "General",
                                "issue": f"XML file not found for source_xml='{src_xml_name}'",
                                "affected_table": "", "affected_field": "", "mapping": ""}],
                })
                continue

            # Parse XML
            doc = self.parser.parse_file(str(xml_file))

            # Filter Excel sheets by session names from this XML
            xml_session_names = {s.name.lower() for s in doc.sessions}

            # Build per-XML excel_sheets by filtering rows
            per_xml_sheets = {}
            for sheet_name, rows in excel_sheets.items():
                filtered = []
                for row in rows:
                    # Check if row belongs to this XML's sessions
                    session_val = ""
                    for key in ("Session Name", "Session/Task Name"):
                        session_val = row.get(key, "").strip().lower()
                        if session_val:
                            break
                    if session_val:
                        if any(xs in session_val or session_val in xs for xs in xml_session_names):
                            filtered.append(row)
                    else:
                        # Rows without session info — include for all
                        filtered.append(row)
                per_xml_sheets[sheet_name] = filtered

            # Override Aggregated Lineage sheet with filtered entries
            per_xml_sheets["Aggregated Lineage"] = [
                {"Target Table": e.get("target_table", ""), "Target Field": e.get("target_field", "")}
                for e in entries
            ]

            # Run the 13-dimension scoring with filtered data
            results = []
            all_issues = []

            checks = [
                (self._check_source_tables, (doc, entries)),
                (self._check_source_fields, (doc, entries)),
                (self._check_target_tables, (doc, entries)),
                (self._check_target_fields, (doc, entries)),
                (self._check_lookups, (doc, entries, per_xml_sheets)),
                (self._check_transformations, (doc, per_xml_sheets, entries)),
                (self._check_parameters, (entries, output_json)),
                (self._check_sessions, (doc, per_xml_sheets)),
                (self._check_sql_overrides, (doc, entries)),
                (self._check_pre_post_sql, (doc, per_xml_sheets)),
                (self._check_bteq, (doc, per_xml_sheets)),
                (self._check_workflow_tasks, (doc, per_xml_sheets, output_json)),
                (self._check_cross_sheet, (entries, per_xml_sheets)),
            ]

            for check_fn, args in checks:
                score, expected, found, issues = check_fn(*args)
                results.append({"score": score, "expected": expected, "found": found})
                all_issues.extend(issues)

            total_weight = sum(d["weight"] for d in DIMENSIONS)
            weighted_sum = sum(r["score"] * d["weight"] for r, d in zip(results, DIMENSIONS))
            overall = weighted_sum / total_weight if total_weight else 0.0

            per_xml_reports.append({
                "workflow_name": src_xml_name.replace(".xml", "").replace(".XML", ""),
                "overall_score": round(overall, 1),
                "letter_grade": _letter_grade(overall),
                "field_lineage_count": len(entries),
                "dimensions": [
                    {
                        "name": d["name"],
                        "weight": d["weight"],
                        "score": round(r["score"], 1),
                        "expected": r["expected"],
                        "found": r["found"],
                        "issue_count": sum(1 for iss in all_issues if iss["dimension"] == d["name"]),
                    }
                    for d, r in zip(DIMENSIONS, results)
                ],
                "issues": all_issues,
            })

        # ── Cross-XML checks ─────────────────────────────────────────────
        cross_xml = self._check_cross_xml(output_json, output_dir)

        # ── Overall aggregated score ─────────────────────────────────────
        scores = [r["overall_score"] for r in per_xml_reports if r.get("dimensions")]
        avg_score = sum(scores) / len(scores) if scores else 0.0

        return {
            "overall_score": round(avg_score, 1),
            "letter_grade": _letter_grade(avg_score),
            "xml_count": len(xml_groups),
            "total_field_lineages": len(field_lineage),
            "per_xml_reports": per_xml_reports,
            "cross_xml": cross_xml,
        }

    def _check_cross_xml(self, output_json: Dict, output_dir: Path) -> Dict:
        """Run cross-XML checks on the aggregated output."""
        checks = []

        # Load unified graph
        graph_path = self._find_file(output_dir, "_lineage_graph.json") or self._find_file(output_dir, "lineage_graph.json")
        graph = {}
        if graph_path:
            with open(graph_path, encoding="utf-8") as f:
                graph = json.load(f)

        # Check 1: Cross-mapping links resolved
        cross_links = graph.get("cross_mapping_links", [])
        checks.append({
            "check": "Cross-Mapping Links",
            "status": "PASS" if len(cross_links) > 0 or not graph else "INFO",
            "details": f"{len(cross_links)} cross-mapping links found",
            "count": len(cross_links),
        })

        # Check 2: Table conflicts
        conflicts = graph.get("conflicts", [])
        checks.append({
            "check": "Table Conflicts",
            "status": "WARN" if conflicts else "PASS",
            "details": f"{len(conflicts)} conflicts detected" if conflicts else "No conflicts",
            "count": len(conflicts),
        })

        # Check 3: Unified graph completeness
        table_count = graph.get("table_count", 0)
        edge_count = graph.get("edge_count", 0)
        checks.append({
            "check": "Unified Graph",
            "status": "PASS" if table_count > 0 else "FAIL",
            "details": f"{table_count} tables, {edge_count} edges",
            "count": table_count,
        })

        # Check 4: All source_xml values have field_lineage entries
        field_lineage = output_json.get("field_lineage", [])
        xml_names = set(e.get("source_xml", "") for e in field_lineage)
        empty_xmls = [x for x in xml_names if not any(e.get("source_xml") == x for e in field_lineage)]
        checks.append({
            "check": "All XMLs Have Lineage",
            "status": "PASS" if not empty_xmls else "FAIL",
            "details": f"{len(xml_names)} XMLs with data" if not empty_xmls else f"Empty: {empty_xmls}",
            "count": len(xml_names),
        })

        # Check 5: No duplicate field_lineage entries
        seen = set()
        dupes = 0
        for e in field_lineage:
            key = f"{e.get('source_xml','')}.{e.get('mapping_name','')}.{e.get('target_table','')}.{e.get('target_field','')}"
            if key in seen:
                dupes += 1
            seen.add(key)
        checks.append({
            "check": "No Duplicate Lineages",
            "status": "PASS" if dupes == 0 else "WARN",
            "details": f"{dupes} duplicates found" if dupes else "No duplicates",
            "count": dupes,
        })

        return {"checks": checks}

    @staticmethod
    def write_aggregated_report(agg_report: Dict, output_path: str) -> None:
        """Write aggregated validation report Excel."""
        wb = Workbook()

        per_xml = agg_report.get("per_xml_reports", [])
        cross_xml = agg_report.get("cross_xml", {})

        # ── Sheet 1: Aggregated Summary ──────────────────────────────────
        ws_sum = wb.active
        ws_sum.title = "Aggregated Summary"
        summary_data = [
            ("Total XMLs", agg_report.get("xml_count", 0)),
            ("Total Field Lineages", agg_report.get("total_field_lineages", 0)),
            ("Overall Score", agg_report.get("overall_score", 0)),
            ("Letter Grade", agg_report.get("letter_grade", "")),
            ("Total Issues", sum(len(r.get("issues", [])) for r in per_xml)),
        ]
        ws_sum.append(["Metric", "Value"])
        for col in range(1, 3):
            _apply_header(ws_sum.cell(1, col))
        for label, val in summary_data:
            ws_sum.append([label, val])

        r_score = 4  # Row with Overall Score
        ws_sum.cell(r_score, 2).fill = _score_fill(agg_report.get("overall_score", 0))
        ws_sum.cell(r_score, 2).font = Font(bold=True, size=14)

        for col in ws_sum.columns:
            max_len = max(len(str(c.value or "")) for c in col)
            ws_sum.column_dimensions[col[0].column_letter].width = min(max_len + 3, 40)

        # ── Sheet 2: Per-XML Summary ─────────────────────────────────────
        ws = wb.create_sheet("Per-XML Summary")

        dim_short = [
            "source_tables", "source_fields", "target_tables", "target_fields",
            "lookup_capture", "transformation_coverage", "parameter_resolution",
            "session_coverage", "sql_override_capture", "pre_post_sql",
            "bteq_capture", "workflow_tasks", "cross_sheet_integrity",
        ]
        headers = ["File", "Score", "Grade", "Lineages", "Issues"]
        headers.extend(dim_short)
        ws.append(headers)
        for col in range(1, len(headers) + 1):
            _apply_header(ws.cell(1, col))

        for report in sorted(per_xml, key=lambda r: -r.get("overall_score", 0)):
            row = [
                report["workflow_name"],
                report["overall_score"],
                report["letter_grade"],
                report.get("field_lineage_count", 0),
                len(report.get("issues", [])),
            ]
            for dim in report.get("dimensions", []):
                row.append(dim["score"])
            ws.append(row)
            r = ws.max_row
            ws.cell(r, 2).fill = _score_fill(report["overall_score"])
            for ci in range(6, 6 + len(dim_short)):
                cell = ws.cell(r, ci)
                if cell.value is not None:
                    cell.fill = _score_fill(float(cell.value))

        ws.freeze_panes = "A2"
        for col in ws.columns:
            max_len = max(len(str(c.value or "")) for c in col)
            ws.column_dimensions[col[0].column_letter].width = min(max_len + 3, 45)

        # ── Sheet 2: Issues ──────────────────────────────────────────────
        ws2 = wb.create_sheet("Issues")
        issue_headers = ["File", "Severity", "Dimension", "Issue",
                         "Affected Table", "Affected Field", "Mapping"]
        ws2.append(issue_headers)
        for col in range(1, len(issue_headers) + 1):
            _apply_header(ws2.cell(1, col))

        for report in sorted(per_xml, key=lambda r: r.get("workflow_name", "")):
            wf_name = report.get("workflow_name", "")
            for iss in report.get("issues", []):
                ws2.append([
                    wf_name, iss.get("severity", ""), iss.get("dimension", ""),
                    iss.get("issue", ""), iss.get("affected_table", ""),
                    iss.get("affected_field", ""), iss.get("mapping", ""),
                ])
                r = ws2.max_row
                sev = iss.get("severity", "")
                if sev == "High":
                    ws2.cell(r, 2).fill = FAIL_FILL
                elif sev == "Medium":
                    ws2.cell(r, 2).fill = WARN_FILL
                else:
                    ws2.cell(r, 2).fill = PASS_FILL

        ws2.freeze_panes = "A2"
        for col in ws2.columns:
            max_len = max(len(str(c.value or "")) for c in col)
            ws2.column_dimensions[col[0].column_letter].width = min(max_len + 3, 60)

        # ── Sheet 3: Cross-XML Analysis ──────────────────────────────────
        ws3 = wb.create_sheet("Cross-XML Analysis")
        ws3.append(["Check", "Status", "Details", "Count"])
        for col in range(1, 5):
            _apply_header(ws3.cell(1, col))

        for check in cross_xml.get("checks", []):
            ws3.append([
                check["check"], check["status"],
                check["details"], check.get("count", 0),
            ])
            r = ws3.max_row
            status = check["status"]
            if status == "PASS":
                ws3.cell(r, 2).fill = PASS_FILL
            elif status == "WARN":
                ws3.cell(r, 2).fill = WARN_FILL
            elif status == "FAIL":
                ws3.cell(r, 2).fill = FAIL_FILL

        for col in ws3.columns:
            max_len = max(len(str(c.value or "")) for c in col)
            ws3.column_dimensions[col[0].column_letter].width = min(max_len + 3, 50)

        wb.save(output_path)

    # ── Dimension Checks ─────────────────────────────────────────────────

    def _check_source_tables(self, doc, field_lineage) -> Tuple:
        dim = "Source Table Coverage"
        # Identify flat file sources so we can match them by file name
        flat_file_sources = set()
        xml_tables = set()
        for src in doc.sources:
            db_type = getattr(src, "database_type", "") or ""
            if "flat file" in db_type.lower():
                flat_file_sources.add(src.name.lower())
            xml_tables.add(src.name.lower())
        # Also add lookup tables from transformations.
        # Skip $Param_* names — these are unresolved and the output will have
        # the resolved table name (e.g., $Param_Source_XREF -> AGREEMENT_SK_XREF).
        # The resolved name is already captured via ultimate_sources/lookup_tables.
        param_source_tables = set()
        for m in doc.mappings:
            for t in m.transformations:
                if "lookup" in t.type.lower():
                    tbl = t.get_attribute("Lookup table name") or ""
                    if tbl:
                        bare = tbl.rsplit(".", 1)[-1].lower() if "." in tbl else tbl.lower()
                        if "$" in bare:
                            param_source_tables.add(bare)
                        else:
                            xml_tables.add(bare)

        # Track which SQs have session SQL overrides — when a session
        # overrides the SQL, the output shows real database tables instead of
        # XML source definition names. Mark these XML source defs as covered.
        _has_session_sql_override = False
        for s in doc.sessions:
            for ti in getattr(s, "transformation_insts", []):
                if hasattr(ti, "attributes"):
                    for attr in ti.attributes:
                        if getattr(attr, "name", "") == "Sql Query":
                            val = getattr(attr, "value", "") or ""
                            if val.strip():
                                _has_session_sql_override = True
                                break

        output_tables = set()
        # Also collect full paths/names for flat file matching
        output_table_full = set()
        for entry in field_lineage:
            for src in entry.get("ultimate_sources", []):
                tbl = _strip_brackets(src.get("table", ""))
                if tbl:
                    output_table_full.add(tbl.lower())
                    bare = tbl.rsplit(".", 1)[-1].lower() if "." in tbl else tbl.lower()
                    # For file paths, also extract the file name stem
                    if "/" in tbl:
                        fname = tbl.rsplit("/", 1)[-1].lower()
                        # Strip extension (.csv, .dat, .txt)
                        fname_stem = fname.rsplit(".", 1)[0] if "." in fname else fname
                        output_tables.add(fname)
                        output_tables.add(fname_stem)
                    output_tables.add(bare)
            for lt in entry.get("lookup_tables", []):
                if isinstance(lt, str) and lt:
                    bare = lt.rsplit(".", 1)[-1].lower() if "." in lt else lt.lower()
                    output_tables.add(bare)

        # Remove synthetic entries
        output_tables.discard("hard coded value")

        matched = set()
        for xml_tbl in xml_tables:
            if xml_tbl in output_tables:
                matched.add(xml_tbl)
            elif xml_tbl in flat_file_sources:
                xml_bare = xml_tbl.replace("ff_", "").replace("sc_", "")
                for out_tbl in output_tables | output_table_full:
                    if xml_bare in out_tbl or xml_tbl in out_tbl:
                        matched.add(xml_tbl)
                        break
                if xml_tbl not in matched and output_table_full:
                    for full_path in output_table_full:
                        if "/" in full_path:
                            matched.add(xml_tbl)
                            break
            else:
                # CDC -> WRK resolution: e.g., SHAWILN_AGMT_MTRC_CDC maps to
                # SHAWILN_AGMT_MTRC_WRK_1 in the output (two-step write pattern)
                # Also handle general partial/fuzzy matching for source table variants
                xml_stem = re.sub(r"_cdc$|_tgt_stg$|_src_stg$", "", xml_tbl)
                for out_tbl in output_tables:
                    out_stem = re.sub(r"_wrk_\d+$|_cdc$|_tgt_stg$|_cur$|_hist$", "", out_tbl)
                    if xml_stem and out_stem and xml_stem == out_stem:
                        matched.add(xml_tbl)
                        break

                # Param-resolved name matching: when $Param resolves a table name,
                # the output may have a suffix/prefix added (e.g., RAW -> RAW_VW,
                # TABLE -> TABLE_HIST).  Match if the XML name is a substring of
                # the output name or vice versa (with minimum length to avoid
                # spurious matches on short names).
                if xml_tbl not in matched and len(xml_tbl) >= 6:
                    for out_tbl in output_tables:
                        if len(out_tbl) >= 6 and (
                            out_tbl.startswith(xml_tbl) or xml_tbl.startswith(out_tbl)
                        ):
                            matched.add(xml_tbl)
                            break

        missing = xml_tables - matched

        # When session SQL overrides exist, XML source definitions replaced by
        # real SQL tables should not be flagged as missing.  Check if the
        # missing source is an XML source definition that feeds a SQ with a
        # session SQL override — if so, the override replaced it.
        if _has_session_sql_override and missing:
            override_sq_sources = set()
            for s in doc.sessions:
                for ti in getattr(s, "transformation_insts", []):
                    has_sql = False
                    if hasattr(ti, "attributes"):
                        for attr in ti.attributes:
                            if getattr(attr, "name", "") == "Sql Query":
                                val = getattr(attr, "value", "") or ""
                                if val.strip():
                                    has_sql = True
                                    break
                    if has_sql:
                        # Find the SQ instance name and trace back to source defs
                        sq_name = getattr(ti, "sinstance_name", "")
                        if sq_name:
                            for m in doc.mappings:
                                for conn in m.connectors:
                                    if conn.to_instance.lower() == sq_name.lower():
                                        inst = conn.from_instance.lower()
                                        override_sq_sources.add(inst)
                                        # Also add sc_-stripped version
                                        if inst.startswith("sc_"):
                                            override_sq_sources.add(inst[3:])
            # Sources feeding overridden SQs are covered by the SQL override
            for src_name in list(missing):
                bare = src_name.rsplit(".", 1)[-1].lower() if "." in src_name else src_name.lower()
                if bare in override_sq_sources:
                    matched.add(src_name)
                    missing.discard(src_name)

        issues = []
        for tbl in sorted(missing):
            issues.append({
                "severity": "High",
                "dimension": dim,
                "issue": f"Source table '{tbl}' in XML but not found in output",
                "affected_table": tbl,
                "affected_field": "",
                "mapping": "",
            })

        score = (len(matched) / len(xml_tables) * 100) if xml_tables else 100.0
        return score, len(xml_tables), len(matched), issues

    def _check_source_fields(self, doc, field_lineage) -> Tuple:
        dim = "Source Field Coverage"
        # Identify flat file sources
        flat_file_sources = set()
        for src in doc.sources:
            db_type = getattr(src, "database_type", "") or ""
            if "flat file" in db_type.lower():
                flat_file_sources.add(src.name.lower())

        # Get source fields that ACTUALLY REACH A TARGET via field-level
        # tracing.  A source field connected to SQ but whose field name never
        # appears in any downstream connector chain to a target is not a real
        # mapping and should not be counted as "expected" (false positive).
        #
        # Algorithm: trace each source field forward through the connector
        # graph field-by-field.  A source field is "target-reaching" if its
        # field name (possibly renamed) eventually appears in a connector
        # whose to_instance is a target.
        xml_fields = set()
        for m in doc.mappings:
            # Build target instance set
            target_inst_names = set()
            for tgt in m.targets:
                target_inst_names.add(tgt.name.lower())
            for inst in getattr(m, 'target_instances', []):
                target_inst_names.add(inst.name.lower())

            # Build forward adjacency: (from_inst, from_field) -> [(to_inst, to_field)]
            connector_list = m.connectors
            fwd = {}
            for conn in connector_list:
                key = (conn.from_instance.lower(), conn.from_field.lower())
                fwd.setdefault(key, []).append(
                    (conn.to_instance.lower(), conn.to_field.lower())
                )

            # For each source→SQ connector, trace forward to see if it
            # eventually reaches a target instance.
            source_names = set()
            for src in m.sources:
                source_names.add(src.name.lower())

            for conn in connector_list:
                from_inst = conn.from_instance.lower()
                from_inst_bare = from_inst.replace("sc_", "")
                if from_inst_bare not in source_names and from_inst not in source_names:
                    continue

                # BFS from the SQ field this source field connects to
                src_name = from_inst_bare if from_inst_bare in source_names else from_inst
                field_name = conn.from_field.lower()
                to_inst = conn.to_instance.lower()
                to_field = conn.to_field.lower()

                # Trace forward from (to_inst, to_field)
                visited = set()
                queue = [(to_inst, to_field)]
                reaches_target = False
                while queue:
                    cur_inst, cur_field = queue.pop(0)
                    if (cur_inst, cur_field) in visited:
                        continue
                    visited.add((cur_inst, cur_field))

                    if cur_inst in target_inst_names:
                        reaches_target = True
                        break

                    # Follow forward connectors from this (inst, field)
                    for next_inst, next_field in fwd.get((cur_inst, cur_field), []):
                        queue.append((next_inst, next_field))

                if reaches_target:
                    xml_fields.add(f"{src_name}.{field_name}")

        output_fields = set()
        # Also collect just the field names for flat file matching
        output_field_names = set()
        for entry in field_lineage:
            for src in entry.get("ultimate_sources", []):
                tbl = src.get("table", "")
                fld = src.get("field", "")
                if tbl and fld and "hard coded" not in tbl.lower():
                    bare_tbl = tbl.rsplit(".", 1)[-1].lower()
                    # For file paths, extract the file name stem
                    if "/" in tbl:
                        fname = tbl.rsplit("/", 1)[-1].lower()
                        fname_stem = fname.rsplit(".", 1)[0] if "." in fname else fname
                        bare_tbl = fname_stem
                    bare_fld = fld.rsplit("/", 1)[-1].lower()
                    output_fields.add(f"{bare_tbl}.{bare_fld}")
                    output_field_names.add(bare_fld)

        matched = xml_fields & output_fields
        # For flat file sources, match by field name only since table name
        # will be a file path instead of the XML source name
        missing = xml_fields - matched
        flat_matched = set()
        for fld_key in missing:
            tbl, field_name = fld_key.split(".", 1)
            if tbl in flat_file_sources and field_name in output_field_names:
                flat_matched.add(fld_key)
        matched |= flat_matched
        missing = xml_fields - matched

        # Param-resolved table name matching: when $Param resolves a source
        # table name, the output may have a suffix/prefix added (e.g.,
        # MCLD_CR_CCAR_FICO_RAW -> MCLD_CR_CCAR_FICO_RAW_VW).
        # Match by field name if the XML table is a prefix of the output table.
        param_matched = set()
        if missing:
            # Build a lookup: output field_name -> set of output table names
            output_field_to_tables = {}
            for out_key in output_fields:
                out_tbl, out_fld = out_key.split(".", 1)
                output_field_to_tables.setdefault(out_fld, set()).add(out_tbl)

            for fld_key in missing:
                xml_tbl, field_name = fld_key.split(".", 1)
                if field_name in output_field_to_tables:
                    for out_tbl in output_field_to_tables[field_name]:
                        # Match if XML table is prefix of output table or vice versa
                        if len(xml_tbl) >= 6 and len(out_tbl) >= 6 and (
                            out_tbl.startswith(xml_tbl) or xml_tbl.startswith(out_tbl)
                        ):
                            param_matched.add(fld_key)
                            break
            matched |= param_matched
            missing = xml_fields - matched

        # When session SQL overrides exist, source definition fields are
        # replaced by SQL column expressions. Exclude fields from source
        # definitions that feed overridden SQs.
        if missing:
            override_src_defs = set()
            for s in doc.sessions:
                for ti in getattr(s, "transformation_insts", []):
                    has_sql = False
                    if hasattr(ti, "attributes"):
                        for attr in ti.attributes:
                            if getattr(attr, "name", "") == "Sql Query":
                                val = getattr(attr, "value", "") or ""
                                if val.strip():
                                    has_sql = True
                                    break
                    if has_sql:
                        sq_name = getattr(ti, "sinstance_name", "")
                        if sq_name:
                            for m_obj in doc.mappings:
                                for conn in m_obj.connectors:
                                    if conn.to_instance.lower() == sq_name.lower():
                                        override_src_defs.add(conn.from_instance.lower().replace("sc_", ""))
            if override_src_defs:
                override_matched = set()
                for fld_key in missing:
                    tbl_part = fld_key.split(".", 1)[0]
                    if tbl_part in override_src_defs:
                        override_matched.add(fld_key)
                matched |= override_matched
                missing = xml_fields - matched

        issues = []
        for fld in sorted(missing):
            tbl, field_name = fld.split(".", 1)
            issues.append({
                "severity": "Medium",
                "dimension": dim,
                "issue": f"Connected source field '{fld}' not found in output",
                "affected_table": tbl,
                "affected_field": field_name,
                "mapping": "",
            })

        score = (len(matched) / len(xml_fields) * 100) if xml_fields else 100.0
        return score, len(xml_fields), len(matched), issues

    def _check_target_tables(self, doc, field_lineage) -> Tuple:
        dim = "Target Table Coverage"
        # Identify flat file targets
        flat_file_targets = set()
        xml_tables = set()
        for tgt in doc.targets:
            xml_tables.add(tgt.name.lower())
            db_type = getattr(tgt, "database_type", "") or ""
            if "flat file" in db_type.lower() or tgt.name.lower().startswith("ff_"):
                flat_file_targets.add(tgt.name.lower())

        output_tables = set()
        output_tables_full = set()
        for entry in field_lineage:
            tbl = entry.get("target_table", "")
            if tbl:
                output_tables_full.add(tbl.lower())
                bare = tbl.rsplit(".", 1)[-1].lower()
                output_tables.add(bare)
                # For file paths, also extract file name stem
                if "/" in tbl:
                    fname = tbl.rsplit("/", 1)[-1].lower()
                    fname_stem = fname.rsplit(".", 1)[0] if "." in fname else fname
                    output_tables.add(fname)
                    output_tables.add(fname_stem)

        matched = set()
        for xml_tbl in xml_tables:
            if xml_tbl in output_tables:
                matched.add(xml_tbl)
            elif xml_tbl in flat_file_targets:
                # Flat file targets: match by partial name
                xml_bare = xml_tbl.replace("ff_", "")
                for out_tbl in output_tables | output_tables_full:
                    if xml_bare in out_tbl or xml_tbl in out_tbl:
                        matched.add(xml_tbl)
                        break
                # If any file-path target exists in output, count flat file as matched
                if xml_tbl not in matched:
                    for full in output_tables_full:
                        if "/" in full:
                            matched.add(xml_tbl)
                            break

        missing = xml_tables - matched

        issues = []
        for tbl in sorted(missing):
            issues.append({
                "severity": "High",
                "dimension": dim,
                "issue": f"Target table '{tbl}' in XML but not found in output",
                "affected_table": tbl,
                "affected_field": "",
                "mapping": "",
            })

        score = (len(matched) / len(xml_tables) * 100) if xml_tables else 100.0
        return score, len(xml_tables), len(matched), issues

    def _check_target_fields(self, doc, field_lineage) -> Tuple:
        dim = "Target Field Coverage"
        # Identify flat file targets
        flat_file_targets = set()
        for tgt in doc.targets:
            db_type = getattr(tgt, "database_type", "") or ""
            if "flat file" in db_type.lower() or tgt.name.lower().startswith("ff_"):
                flat_file_targets.add(tgt.name.lower())

        # Build set of connected target fields (fields with at least one
        # connector pointing TO them).  Unconnected fields (e.g., error_log
        # UPDATE_TS, TRACK_ID, FF_DUMMY FIELD_2/FIELD_3) are excluded from
        # the expected set since they have no mapping data flow.
        connected_target_fields = set()
        for m in doc.mappings:
            # Build target instance -> target definition name mapping
            tgt_inst_to_def = {}
            for inst in m.target_instances:
                # Try shortcut resolution
                def_name = inst.transformation_name.lower()
                resolved = (doc.shortcuts or {}).get(def_name, def_name)
                tgt_inst_to_def[inst.name.lower()] = resolved
            for conn in m.connectors:
                to_inst = conn.to_instance.lower()
                to_field = conn.to_field.lower()
                # Check if this connector goes to a target instance
                if to_inst in tgt_inst_to_def:
                    tgt_def = tgt_inst_to_def[to_inst]
                    connected_target_fields.add(f"{tgt_def}.{to_field}")
                # Also check by target name directly
                for tgt in doc.targets:
                    if to_inst == tgt.name.lower() or to_inst.replace("sc_", "") == tgt.name.lower():
                        connected_target_fields.add(f"{tgt.name.lower()}.{to_field}")

        # Detect SP-only workflows (only m_DUMMY mapping with real data)
        is_sp_only = all(
            "dummy" in m.name.lower() or "error_log" in m.name.lower()
            for m in doc.mappings
        )

        xml_fields = set()
        for tgt in doc.targets:
            for fld in tgt.fields:
                fld_key = f"{tgt.name.lower()}.{fld.name.lower()}"
                # Only include connected fields (or all fields if we couldn't
                # determine connectivity, e.g., no connectors found)
                if connected_target_fields:
                    if fld_key in connected_target_fields:
                        xml_fields.add(fld_key)
                else:
                    xml_fields.add(fld_key)

        # For SP-only workflows, only expect the connected dummy field
        if is_sp_only and not xml_fields:
            return 100.0, 0, 0, []

        output_fields = set()
        output_field_names = set()
        for entry in field_lineage:
            tbl = entry.get("target_table", "")
            fld = entry.get("target_field", "")
            if tbl and fld:
                bare_tbl = tbl.rsplit(".", 1)[-1].lower()
                # For file paths, extract file name stem
                if "/" in tbl:
                    fname = tbl.rsplit("/", 1)[-1].lower()
                    bare_tbl = fname.rsplit(".", 1)[0] if "." in fname else fname
                output_fields.add(f"{bare_tbl}.{fld.lower()}")
                output_field_names.add(fld.lower())

        matched = xml_fields & output_fields
        # For flat file targets, match by field name only
        missing = xml_fields - matched
        flat_matched = set()
        for fld_key in missing:
            tbl, field_name = fld_key.split(".", 1)
            if tbl in flat_file_targets and field_name in output_field_names:
                flat_matched.add(fld_key)
        matched |= flat_matched
        missing = xml_fields - matched

        issues = []
        for fld in sorted(missing):
            tbl, field_name = fld.split(".", 1)
            issues.append({
                "severity": "High",
                "dimension": dim,
                "issue": f"Target field '{fld}' in XML but not in field_lineage",
                "affected_table": tbl,
                "affected_field": field_name,
                "mapping": "",
            })

        score = (len(matched) / len(xml_fields) * 100) if xml_fields else 100.0
        return score, len(xml_fields), len(matched), issues

    def _check_lookups(self, doc, field_lineage, excel_sheets) -> Tuple:
        dim = "Lookup Capture"
        xml_lookups = {}
        for m in doc.mappings:
            for t in m.transformations:
                if "lookup" in t.type.lower():
                    tbl = t.get_attribute("Lookup table name") or ""
                    cond = t.get_attribute("Lookup condition") or ""
                    xml_lookups[t.name.lower()] = {
                        "table": tbl,
                        "condition": cond,
                        "mapping": m.name,
                    }

        if not xml_lookups:
            return 100.0, 0, 0, []

        lookup_rows = excel_sheets.get("Lookup Details", [])
        excel_lookups = {}
        for row in lookup_rows:
            name = row.get("Lookup Name", "").lower()
            if name:
                excel_lookups[name] = {
                    "table": row.get("Lookup Table Name", ""),
                    "condition": row.get("Lookup Condition", ""),
                }

        total_checks = 0
        passed_checks = 0
        issues = []

        for lkp_name, xml_info in xml_lookups.items():
            excel_info = excel_lookups.get(lkp_name)

            # Name match
            total_checks += 1
            if excel_info:
                passed_checks += 1
            else:
                issues.append({
                    "severity": "High",
                    "dimension": dim,
                    "issue": f"Lookup '{lkp_name}' not found in Lookup Details sheet",
                    "affected_table": xml_info["table"],
                    "affected_field": "",
                    "mapping": xml_info["mapping"],
                })
                continue

            # Table match — resolve $Param in XML table name before comparing,
            # since output will have resolved params (e.g., P_EDW_BASE_01_E0.LKP_CD_TYPE)
            total_checks += 1
            xml_tbl_raw = xml_info["table"]
            xml_bare = xml_tbl_raw.rsplit(".", 1)[-1].lower() if xml_tbl_raw else ""
            # If XML table has $Param_, it's unresolved — compare bare names only
            # and also accept if the output table's bare name is a valid resolved form
            xml_has_param = "$" in xml_tbl_raw
            excel_bare = excel_info["table"].rsplit(".", 1)[-1].lower() if excel_info["table"] else ""
            table_matched = False
            if xml_bare and excel_bare:
                if xml_bare == excel_bare:
                    table_matched = True
                elif xml_has_param and excel_bare:
                    # XML has unresolved params — if output has any table, accept it
                    table_matched = True
            if table_matched:
                passed_checks += 1
            elif xml_bare:
                issues.append({
                    "severity": "Medium",
                    "dimension": dim,
                    "issue": f"Lookup '{lkp_name}' table mismatch: XML='{xml_info['table']}' vs Output='{excel_info['table']}'",
                    "affected_table": xml_info["table"],
                    "affected_field": "",
                    "mapping": xml_info["mapping"],
                })

            # Condition match
            total_checks += 1
            xml_cond = re.sub(r"\s+", " ", xml_info["condition"]).strip().lower()
            excel_cond = re.sub(r"\s+", " ", excel_info["condition"]).strip().lower()
            if xml_cond and excel_cond and xml_cond == excel_cond:
                passed_checks += 1
            elif xml_cond and not excel_cond:
                issues.append({
                    "severity": "Medium",
                    "dimension": dim,
                    "issue": f"Lookup '{lkp_name}' condition missing in output",
                    "affected_table": xml_info["table"],
                    "affected_field": "",
                    "mapping": xml_info["mapping"],
                })
            else:
                passed_checks += 1  # Both empty or close enough

        score = (passed_checks / total_checks * 100) if total_checks else 100.0
        return score, total_checks, passed_checks, issues

    def _check_transformations(self, doc, excel_sheets, field_lineage) -> Tuple:
        dim = "Transformation Coverage"
        xml_transforms = {}
        for m in doc.mappings:
            for t in m.transformations:
                xml_transforms[f"{m.name}.{t.name}".lower()] = {
                    "name": t.name,
                    "type": t.type,
                    "mapping": m.name,
                }

        # Also add mapplet transformations
        for mp_name, mp_obj in (doc.mapplets or {}).items():
            if hasattr(mp_obj, "transformations"):
                for t in mp_obj.transformations:
                    if not hasattr(t, "name"):
                        continue
                    xml_transforms[f"mapplet.{mp_name}.{t.name}".lower()] = {
                        "name": t.name,
                        "type": f"Mapplet/{t.type}",
                        "mapping": f"mapplet:{mp_name}",
                    }

        if not xml_transforms:
            return 100.0, 0, 0, []

        # Collect all transformation names from output
        output_trans_names = set()

        # From Excel sheets
        sheet_map = {
            "Expression Details": "Expression Transformation Name",
            "Router Details": "Router Name",
            "Union Details": "Union Transformation Name",
            "Joiner Details": "Joiner Name",
            "Lookup Details": "Lookup Name",
        }
        for sheet_name, col_name in sheet_map.items():
            for row in excel_sheets.get(sheet_name, []):
                name = row.get(col_name, "").strip().lower()
                if name:
                    output_trans_names.add(name)

        # From field_lineage intermediate_steps
        for entry in field_lineage:
            for step in entry.get("intermediate_steps", []):
                for key in ("source_instance", "target_instance"):
                    inst = step.get(key, "").lower()
                    if inst:
                        output_trans_names.add(inst)
            # Transformation chain text
            chain = entry.get("transformation_chain", "")
            for match in re.finditer(r"(\w+):", chain):
                output_trans_names.add(match.group(1).lower())

        total_checks = 0
        passed_checks = 0
        issues = []

        type_checks = {}  # Track per-type results

        for key, info in xml_transforms.items():
            t_name = info["name"].lower()
            t_type = info["type"]
            total_checks += 1

            found = t_name in output_trans_names
            # Fuzzy match: SQ instance suffixes (SQ_sc_X1 vs SQ_sc_X11)
            # Strip trailing digits and re-check
            if not found:
                t_stem = re.sub(r"\d+$", "", t_name)
                for out_name in output_trans_names:
                    out_stem = re.sub(r"\d+$", "", out_name)
                    if t_stem and t_stem == out_stem:
                        found = True
                        break
            if found:
                passed_checks += 1
            else:
                issues.append({
                    "severity": "Medium",
                    "dimension": dim,
                    "issue": f"Transformation '{info['name']}' (type={t_type}) not found in output",
                    "affected_table": "",
                    "affected_field": "",
                    "mapping": info["mapping"],
                })

            type_checks.setdefault(t_type, {"total": 0, "found": 0})
            type_checks[t_type]["total"] += 1
            if found:
                type_checks[t_type]["found"] += 1

        # Verify details for specific types
        detail_issues = self._verify_transformation_details(doc, excel_sheets, field_lineage)
        issues.extend(detail_issues)

        score = (passed_checks / total_checks * 100) if total_checks else 100.0
        return score, total_checks, passed_checks, issues

    def _verify_transformation_details(self, doc, excel_sheets, field_lineage) -> List[Dict]:
        dim = "Transformation Coverage"
        issues = []

        # Router: verify group conditions
        router_rows = excel_sheets.get("Router Details", [])
        excel_router_groups = {}
        for row in router_rows:
            rname = row.get("Router Name", "").lower()
            gcond = row.get("Group Condition", "").strip()
            if rname and gcond:
                excel_router_groups.setdefault(rname, set()).add(
                    re.sub(r"\s+", " ", gcond).lower()
                )

        for m in doc.mappings:
            for t in m.transformations:
                if "router" in t.type.lower():
                    for grp in getattr(t, "groups", []):
                        xml_cond = re.sub(r"\s+", " ", (grp.expression or "")).strip().lower()
                        if xml_cond and t.name.lower() in excel_router_groups:
                            excel_conds = excel_router_groups[t.name.lower()]
                            if xml_cond not in excel_conds:
                                issues.append({
                                    "severity": "Low",
                                    "dimension": dim,
                                    "issue": f"Router '{t.name}' group condition not matched in output: '{grp.expression[:60]}'",
                                    "affected_table": "",
                                    "affected_field": "",
                                    "mapping": m.name,
                                })

        # Expression: verify expression formulas captured
        expr_rows = excel_sheets.get("Expression Details", [])
        excel_expr_names = set()
        for row in expr_rows:
            name = row.get("Expression Transformation Name", "").lower()
            if name:
                excel_expr_names.add(name)

        for m in doc.mappings:
            for t in m.transformations:
                if t.type.lower() == "expression":
                    if t.name.lower() not in excel_expr_names:
                        has_expressions = any(
                            f.expression for f in t.fields if f.expression
                        )
                        if has_expressions:
                            issues.append({
                                "severity": "Low",
                                "dimension": dim,
                                "issue": f"Expression '{t.name}' has formulas in XML but missing from Expression Details sheet",
                                "affected_table": "",
                                "affected_field": "",
                                "mapping": m.name,
                            })

        # Joiner: verify join conditions
        joiner_rows = excel_sheets.get("Joiner Details", [])
        for m in doc.mappings:
            for t in m.transformations:
                if "joiner" in t.type.lower():
                    xml_cond = t.get_attribute("Join Condition") or ""
                    if xml_cond:
                        found = False
                        for row in joiner_rows:
                            if row.get("Joiner Name", "").lower() == t.name.lower():
                                found = True
                                excel_cond = row.get("Join Condition", "")
                                if not excel_cond:
                                    issues.append({
                                        "severity": "Low",
                                        "dimension": dim,
                                        "issue": f"Joiner '{t.name}' condition empty in output",
                                        "affected_table": "",
                                        "affected_field": "",
                                        "mapping": m.name,
                                    })
                                break
                        if not found:
                            issues.append({
                                "severity": "Medium",
                                "dimension": dim,
                                "issue": f"Joiner '{t.name}' not found in Joiner Details sheet",
                                "affected_table": "",
                                "affected_field": "",
                                "mapping": m.name,
                            })

        return issues

    def _check_parameters(self, field_lineage, output_json) -> Tuple:
        dim = "Parameter Resolution"
        param_pattern = re.compile(r"\$\$?Param_\w+")

        # Strategy: check the RESOLVED/final fields for remaining $Param_ references.
        # If resolved_sql_override exists, use it instead of sql_override.
        # If target_table is resolved (no $Param), don't count source sql_override params
        # as unresolved since they're already resolved in the resolved field.
        # Only count params that appear in final consumer-facing fields as unresolved.

        # Fields that represent FINAL resolved output (what downstream consumers see)
        resolved_fields = [
            "resolved_sql_override", "target_table",
            "transformation_chain", "transformation_explanation",
            "lookup_condition", "lookup_sql_override",
        ]

        all_params_seen = set()
        unresolved_set = set()

        for entry in field_lineage:
            # Collect all params from the original sql_override to know total scope
            orig_sql = entry.get("sql_override", "") or ""
            for m in param_pattern.findall(orig_sql):
                all_params_seen.add(m)

            # Check resolved fields for remaining unresolved params
            for key in resolved_fields:
                val = entry.get(key, "") or ""
                # For sql_override: prefer resolved_sql_override if available
                if key == "resolved_sql_override" and not val:
                    val = entry.get("sql_override", "") or ""
                for m in param_pattern.findall(val):
                    all_params_seen.add(m)
                    unresolved_set.add(m)

            # Check source tables — these should be fully resolved
            for src in entry.get("ultimate_sources", []):
                tbl = src.get("table", "")
                for m in param_pattern.findall(tbl):
                    all_params_seen.add(m)
                    unresolved_set.add(m)

        # If resolved_sql_override exists and has fewer params than sql_override,
        # those were successfully resolved — remove from unresolved set
        for entry in field_lineage:
            resolved = entry.get("resolved_sql_override", "")
            orig = entry.get("sql_override", "")
            if resolved and orig:
                orig_params = set(param_pattern.findall(orig))
                resolved_params = set(param_pattern.findall(resolved))
                for p in (orig_params - resolved_params):
                    unresolved_set.discard(p)

        total_refs = len(all_params_seen)
        resolved_count = total_refs - len(unresolved_set)

        issues = []
        for p in sorted(unresolved_set):
            issues.append({
                "severity": "Medium",
                "dimension": dim,
                "issue": f"Parameter '{p}' unresolved in output",
                "affected_table": "",
                "affected_field": "",
                "mapping": "",
            })

        score = (resolved_count / total_refs * 100) if total_refs else 100.0
        return max(0, score), total_refs, max(0, resolved_count), issues

    def _check_sessions(self, doc, excel_sheets) -> Tuple:
        dim = "Session Coverage"
        xml_sessions = set()
        for s in doc.sessions:
            xml_sessions.add(s.name.lower())

        output_sessions = set()
        for sheet_name, rows in excel_sheets.items():
            for row in rows:
                for key in ("Session Name", "Session/Task Name"):
                    val = row.get(key, "").strip().lower()
                    if val:
                        output_sessions.add(val)

        matched = set()
        for xs in xml_sessions:
            for os_name in output_sessions:
                if xs in os_name or os_name in xs:
                    matched.add(xs)
                    break

        missing = xml_sessions - matched
        issues = []
        for s in sorted(missing):
            issues.append({
                "severity": "Medium",
                "dimension": dim,
                "issue": f"Session '{s}' not found in any Excel sheet",
                "affected_table": "",
                "affected_field": "",
                "mapping": "",
            })

        score = (len(matched) / len(xml_sessions) * 100) if xml_sessions else 100.0
        return score, len(xml_sessions), len(matched), issues

    def _check_sql_overrides(self, doc, field_lineage) -> Tuple:
        dim = "SQL Override Capture"
        xml_sq_with_sql = set()
        for m in doc.mappings:
            for t in m.transformations:
                if "source qualifier" in t.type.lower():
                    sql = t.get_attribute("Sql Query") or ""
                    if sql.strip():
                        xml_sq_with_sql.add(f"{m.name}.{t.name}".lower())

        if not xml_sq_with_sql:
            return 100.0, 0, 0, []

        # Check which mappings have sql_override in output
        output_mappings_with_sql = set()
        for entry in field_lineage:
            if entry.get("sql_override"):
                mapping = entry.get("mapping_name", "").lower()
                sq_name = entry.get("source_qualifier_name", "").lower()
                if mapping and sq_name:
                    output_mappings_with_sql.add(f"{mapping}.{sq_name}")
                elif mapping:
                    output_mappings_with_sql.add(mapping)

        matched = set()
        for xml_key in xml_sq_with_sql:
            for out_key in output_mappings_with_sql:
                if xml_key == out_key or xml_key.startswith(out_key) or out_key.startswith(xml_key):
                    matched.add(xml_key)
                    break
            # Also check by mapping name only
            if xml_key not in matched:
                xml_mapping = xml_key.split(".")[0]
                for out_key in output_mappings_with_sql:
                    if xml_mapping in out_key:
                        matched.add(xml_key)
                        break

        missing = xml_sq_with_sql - matched
        issues = []
        for sq in sorted(missing):
            issues.append({
                "severity": "High",
                "dimension": dim,
                "issue": f"SQL Override for '{sq}' not captured in output",
                "affected_table": "",
                "affected_field": "",
                "mapping": sq.split(".")[0],
            })

        score = (len(matched) / len(xml_sq_with_sql) * 100) if xml_sq_with_sql else 100.0
        return score, len(xml_sq_with_sql), len(matched), issues

    def _check_pre_post_sql(self, doc, excel_sheets) -> Tuple:
        dim = "Pre/Post SQL Capture"
        xml_sql_count = 0

        # Collect all sessions including worklet child sessions
        all_sessions = list(doc.sessions)
        session_lookup = {s.name.lower(): s for s in doc.sessions}
        for w in doc.worklets:
            for wt in w.tasks:
                if wt.task_type.lower() == "session":
                    ws_name = getattr(wt, "name", "")
                    taskname = wt.get_attribute("taskname") or ws_name
                    sess = session_lookup.get(taskname.lower())
                    # Avoid double-counting if already in all_sessions
                    if sess and sess not in all_sessions:
                        all_sessions.append(sess)

        # Session-level pre/post SQL from components (value_pairs)
        for s in all_sessions:
            for comp in getattr(s, "components", []):
                for vp in getattr(comp, "value_pairs", []):
                    name = vp.get("name", "").lower()
                    value = vp.get("value", "").strip()
                    if value and any(kw in name for kw in [
                        "pre sql", "post sql", "pre session", "post session",
                        "pre-session", "post-session",
                    ]):
                        xml_sql_count += 1

            # Session extensions pre/post SQL
            for ext in getattr(s, "extensions", []):
                if hasattr(ext, "pre_sql") and ext.pre_sql:
                    xml_sql_count += 1
                if hasattr(ext, "post_sql") and ext.post_sql:
                    xml_sql_count += 1

            # SESSTRANSFORMATIONINST pre/post SQL
            for ti in getattr(s, "transformation_insts", []):
                if hasattr(ti, "pre_sql") and ti.pre_sql:
                    xml_sql_count += 1
                if hasattr(ti, "post_sql") and ti.post_sql:
                    xml_sql_count += 1

        # Target-level pre/post SQL from transformations
        for m in doc.mappings:
            for t in m.transformations:
                if "source qualifier" in t.type.lower():
                    for attr_name in ["Pre SQL", "Post SQL"]:
                        val = t.get_attribute(attr_name) or ""
                        if val.strip():
                            xml_sql_count += 1

        if xml_sql_count == 0:
            return 100.0, 0, 0, []

        pre_post_rows = excel_sheets.get("Pre-Post SQL", [])
        output_count = len([r for r in pre_post_rows if r.get("Command/SQL", "").strip()])

        issues = []
        if output_count < xml_sql_count:
            issues.append({
                "severity": "Medium",
                "dimension": dim,
                "issue": f"Pre/Post SQL: XML has {xml_sql_count} SQL statements, output captured {output_count}",
                "affected_table": "",
                "affected_field": "",
                "mapping": "",
            })

        score = min(100.0, (output_count / xml_sql_count * 100)) if xml_sql_count else 100.0
        return score, xml_sql_count, output_count, issues

    def _check_bteq(self, doc, excel_sheets) -> Tuple:
        dim = "BTEQ/Command Task Capture"
        # Count command tasks in workflow
        xml_command_tasks = 0
        for wf in doc.workflows:
            for task in getattr(wf, "tasks", []):
                task_type = getattr(task, "task_type", "")
                if "command" in task_type.lower():
                    xml_command_tasks += 1

        if xml_command_tasks == 0:
            return 100.0, 0, 0, []

        bteq_rows = excel_sheets.get("BTEQ Details", [])
        output_count = len([r for r in bteq_rows if r.get("Full Command", "").strip()])

        issues = []
        if output_count < xml_command_tasks:
            issues.append({
                "severity": "Medium",
                "dimension": dim,
                "issue": f"BTEQ: XML has {xml_command_tasks} command tasks, output captured {output_count}",
                "affected_table": "",
                "affected_field": "",
                "mapping": "",
            })

        score = min(100.0, (output_count / xml_command_tasks * 100)) if xml_command_tasks else 100.0
        return score, xml_command_tasks, output_count, issues

    def _check_workflow_tasks(self, doc, excel_sheets, output_json) -> Tuple:
        dim = "Workflow Task Coverage"
        xml_tasks = set()
        for wf in doc.workflows:
            for task in getattr(wf, "tasks", []):
                name = getattr(task, "name", "")
                if name and name.lower() != "start":
                    xml_tasks.add(name.lower())

        if not xml_tasks:
            return 100.0, 0, 0, []

        # Check output for task references
        output_tasks = set()
        # From sessions
        for s in doc.sessions:
            output_tasks.add(s.name.lower())
        # From Excel session columns
        for sheet_name, rows in excel_sheets.items():
            for row in rows:
                for key in ("Session Name", "Session/Task Name"):
                    val = row.get(key, "").strip().lower()
                    if val:
                        output_tasks.add(val)

        matched = xml_tasks & output_tasks
        missing = xml_tasks - output_tasks

        issues = []
        for t in sorted(missing):
            issues.append({
                "severity": "Low",
                "dimension": dim,
                "issue": f"Workflow task '{t}' not found in output",
                "affected_table": "",
                "affected_field": "",
                "mapping": "",
            })

        score = (len(matched) / len(xml_tasks) * 100) if xml_tasks else 100.0
        return score, len(xml_tasks), len(matched), issues

    def _check_cross_sheet(self, field_lineage, excel_sheets) -> Tuple:
        dim = "Cross-Sheet Integrity"
        total_checks = 0
        passed_checks = 0
        issues = []

        # Check 1: Lookup names in field_lineage exist in Lookup Details
        # Normalize: split semicolon/comma-separated names and deduplicate
        lineage_lookups = set()
        for entry in field_lineage:
            lname = entry.get("lookup_name", "").strip().lower()
            if lname:
                for part in re.split(r"[;,]", lname):
                    part = part.strip()
                    if part:
                        lineage_lookups.add(part)

        excel_lookups = set()
        for row in excel_sheets.get("Lookup Details", []):
            name = row.get("Lookup Name", "").strip().lower()
            if name:
                for part in re.split(r"[;,]", name):
                    part = part.strip()
                    if part:
                        excel_lookups.add(part)

        for lname in lineage_lookups:
            total_checks += 1
            if lname in excel_lookups:
                passed_checks += 1
            else:
                issues.append({
                    "severity": "Low",
                    "dimension": dim,
                    "issue": f"Lookup '{lname}' in field_lineage but not in Lookup Details sheet",
                    "affected_table": "",
                    "affected_field": "",
                    "mapping": "",
                })

        # Check 2: Session names consistent across sheets
        session_names_per_sheet = {}
        for sheet_name, rows in excel_sheets.items():
            sessions = set()
            for row in rows:
                for key in ("Session Name", "Session/Task Name"):
                    val = row.get(key, "").strip().lower()
                    if val:
                        sessions.add(val)
            if sessions:
                session_names_per_sheet[sheet_name] = sessions

        if len(session_names_per_sheet) >= 2:
            all_sessions = set()
            for s in session_names_per_sheet.values():
                all_sessions |= s
            for sname in all_sessions:
                total_checks += 1
                # Check if present in at least 2 sheets (expected for sessions with data)
                count = sum(1 for s in session_names_per_sheet.values() if sname in s)
                if count >= 1:
                    passed_checks += 1

        # Check 3: field_lineage row count matches CSV row count
        total_checks += 1
        lineage_sheet = excel_sheets.get("Aggregated Lineage", [])
        if len(field_lineage) == len(lineage_sheet):
            passed_checks += 1
        else:
            issues.append({
                "severity": "High",
                "dimension": dim,
                "issue": f"JSON field_lineage ({len(field_lineage)} rows) != Excel Aggregated Lineage ({len(lineage_sheet)} rows)",
                "affected_table": "",
                "affected_field": "",
                "mapping": "",
            })

        score = (passed_checks / total_checks * 100) if total_checks else 100.0
        return score, total_checks, passed_checks, issues

    # ── Helpers ───────────────────────────────────────────────────────────

    def _find_file(self, directory: Path, suffix: str) -> Optional[Path]:
        _safe_dir = Path(safe_join(str(directory.parent), directory.name))
        for f in _safe_dir.iterdir():
            if f.name.endswith(suffix):
                return Path(safe_join(str(_safe_dir), f.name))
        return None

    def _empty_report(self, wf_name: str, reason: str) -> Dict:
        return {
            "workflow_name": wf_name,
            "overall_score": 0.0,
            "letter_grade": "F",
            "dimensions": [
                {"name": d["name"], "weight": d["weight"], "score": 0, "expected": 0, "found": 0, "issue_count": 1}
                for d in DIMENSIONS
            ],
            "issues": [{"severity": "High", "dimension": "General", "issue": reason,
                        "affected_table": "", "affected_field": "", "mapping": ""}],
        }

    # ── Excel Report Writer ──────────────────────────────────────────────

    @staticmethod
    def write_report(report: Dict, output_path: str) -> None:
        """Write accuracy report to Excel."""
        wb = Workbook()

        # ── Sheet 1: Score Summary ───────────────────────────────────────
        ws = wb.active
        ws.title = "Score Summary"

        # Header row
        ws.append(["Workflow", report["workflow_name"]])
        ws.append(["Overall Score", report["overall_score"]])
        ws.append(["Letter Grade", report["letter_grade"]])
        ws.append([])

        # Style the grade
        ws["B3"].font = GRADE_FONT
        ws["B2"].fill = _score_fill(report["overall_score"])
        ws["B2"].font = Font(bold=True, size=12)

        # Dimension table
        headers = ["Dimension", "Weight (%)", "Score", "Expected", "Found", "Issues"]
        ws.append(headers)
        header_row = ws.max_row
        for col in range(1, len(headers) + 1):
            _apply_header(ws.cell(header_row, col))

        for dim in report["dimensions"]:
            row = [
                dim["name"],
                dim["weight"],
                dim["score"],
                dim["expected"],
                dim["found"],
                dim["issue_count"],
            ]
            ws.append(row)
            r = ws.max_row
            ws.cell(r, 3).fill = _score_fill(dim["score"])

        # Auto-width
        for col in ws.columns:
            max_len = max(len(str(c.value or "")) for c in col)
            ws.column_dimensions[col[0].column_letter].width = min(max_len + 3, 40)

        # ── Sheet 2: Issues ──────────────────────────────────────────────
        ws2 = wb.create_sheet("Issues")
        headers2 = ["Severity", "Dimension", "Issue", "Affected Table", "Affected Field", "Mapping"]
        ws2.append(headers2)
        for col in range(1, len(headers2) + 1):
            _apply_header(ws2.cell(1, col))

        for iss in report["issues"]:
            ws2.append([
                iss["severity"],
                iss["dimension"],
                iss["issue"],
                iss.get("affected_table", ""),
                iss.get("affected_field", ""),
                iss.get("mapping", ""),
            ])
            r = ws2.max_row
            sev = iss["severity"]
            if sev == "High":
                ws2.cell(r, 1).fill = FAIL_FILL
            elif sev == "Medium":
                ws2.cell(r, 1).fill = WARN_FILL
            else:
                ws2.cell(r, 1).fill = PASS_FILL

        for col in ws2.columns:
            max_len = max(len(str(c.value or "")) for c in col)
            ws2.column_dimensions[col[0].column_letter].width = min(max_len + 3, 60)

        wb.save(output_path)

    @staticmethod
    def write_batch_summary(reports: List[Dict], output_path: str) -> None:
        """Write batch summary Excel matching SQL RE validator format.

        Sheet 1 — Batch Summary: one row per workflow with dimension scores as columns.
        Sheet 2 — Issues: all issues across all workflows.
        """
        wb = Workbook()

        # ── Sheet 1: Batch Summary ───────────────────────────────────────
        ws = wb.active
        ws.title = "Batch Summary"

        # Short column names for dimensions (matching SQL RE style)
        dim_short_names = [
            "source_tables", "source_fields", "target_tables", "target_fields",
            "lookup_capture", "transformation_coverage", "parameter_resolution",
            "session_coverage", "sql_override_capture", "pre_post_sql",
            "bteq_capture", "workflow_tasks", "cross_sheet_integrity",
        ]

        headers = ["File", "Score", "Grade", "Issues"]
        headers.extend(dim_short_names)
        ws.append(headers)
        for col in range(1, len(headers) + 1):
            _apply_header(ws.cell(1, col))

        for report in sorted(reports, key=lambda r: -r.get("overall_score", 0)):
            row = [
                report["workflow_name"],
                report["overall_score"],
                report["letter_grade"],
                len(report.get("issues", [])),
            ]
            for dim in report.get("dimensions", []):
                row.append(dim["score"])
            ws.append(row)
            r = ws.max_row
            # Color the score cell
            ws.cell(r, 2).fill = _score_fill(report["overall_score"])
            # Color each dimension score
            for ci in range(5, 5 + len(dim_short_names)):
                cell = ws.cell(r, ci)
                if cell.value is not None:
                    cell.fill = _score_fill(float(cell.value))

        # Freeze header row
        ws.freeze_panes = "A2"

        for col in ws.columns:
            max_len = max(len(str(c.value or "")) for c in col)
            ws.column_dimensions[col[0].column_letter].width = min(max_len + 3, 45)

        # ── Sheet 2: Issues ──────────────────────────────────────────────
        ws2 = wb.create_sheet("Issues")
        issue_headers = ["File", "Severity", "Dimension", "Issue",
                         "Affected Table", "Affected Field", "Mapping"]
        ws2.append(issue_headers)
        for col in range(1, len(issue_headers) + 1):
            _apply_header(ws2.cell(1, col))

        for report in sorted(reports, key=lambda r: r.get("workflow_name", "")):
            wf_name = report.get("workflow_name", "")
            for iss in report.get("issues", []):
                ws2.append([
                    wf_name,
                    iss.get("severity", ""),
                    iss.get("dimension", ""),
                    iss.get("issue", ""),
                    iss.get("affected_table", ""),
                    iss.get("affected_field", ""),
                    iss.get("mapping", ""),
                ])
                r = ws2.max_row
                sev = iss.get("severity", "")
                if sev == "High":
                    ws2.cell(r, 2).fill = FAIL_FILL
                elif sev == "Medium":
                    ws2.cell(r, 2).fill = WARN_FILL
                else:
                    ws2.cell(r, 2).fill = PASS_FILL

        ws2.freeze_panes = "A2"

        for col in ws2.columns:
            max_len = max(len(str(c.value or "")) for c in col)
            ws2.column_dimensions[col[0].column_letter].width = min(max_len + 3, 60)

        wb.save(output_path)
