"""Visual exporter - main interface for visualization."""

from pathlib import Path
from typing import Any, Dict, List, Optional, Union

from .renderers.html_renderer import HTMLRenderer
from .renderers.mermaid_renderer import MermaidRenderer
from .graph_converter import GraphConverter
from ..utils.logging_config import get_logger

logger = get_logger("visual_exporter")


class VisualExporter:
    """Main interface for exporting lineage visualizations."""

    def __init__(self):
        self.html_renderer = HTMLRenderer()
        self.mermaid_renderer = MermaidRenderer()
        self.graph_converter = GraphConverter()

    def export_interactive_html(
        self,
        cytoscape_data: Dict[str, Any],
        output_path: Union[str, Path],
        title: str = "Informatica Field-Level Lineage",
    ) -> str:
        """
        Export interactive HTML visualization.

        Args:
            cytoscape_data: Cytoscape.js data from VisualLineageExpert
            output_path: Path for output file
            title: Page title

        Returns:
            Path to created file
        """
        return self.html_renderer.render(cytoscape_data, output_path, title)

    def export_all_mappings_html(
        self,
        cytoscape_data_dict: Dict[str, Dict],
        output_path: Union[str, Path],
        title: str = "Informatica Field-Level Lineage",
    ) -> str:
        """
        Export all mappings to a single interactive HTML.

        Args:
            cytoscape_data_dict: Dictionary of mapping_name -> cytoscape_data
            output_path: Path for output file
            title: Page title

        Returns:
            Path to created file
        """
        return self.html_renderer.render_multiple(cytoscape_data_dict, output_path, title)

    def export_mermaid_html(
        self,
        mermaid_diagrams: Dict[str, str],
        output_path: Union[str, Path],
        title: str = "Informatica Lineage Diagrams",
    ) -> str:
        """
        Export Mermaid diagrams to HTML.

        Args:
            mermaid_diagrams: Dictionary of mapping_name -> mermaid_code
            output_path: Path for output file
            title: Page title

        Returns:
            Path to created file
        """
        return self.mermaid_renderer.render_multiple(mermaid_diagrams, output_path, title)

    def export_mermaid_markdown(
        self,
        mermaid_diagrams: Dict[str, str],
        output_path: Union[str, Path],
    ) -> str:
        """
        Export Mermaid diagrams to Markdown.

        Args:
            mermaid_diagrams: Dictionary of mapping_name -> mermaid_code
            output_path: Path for output file

        Returns:
            Path to created file
        """
        return self.mermaid_renderer.save_markdown(mermaid_diagrams, output_path)

    def export_per_mapping_html(
        self,
        cytoscape_data_dict: Dict[str, Dict],
        output_dir: Union[str, Path],
        title: str = "Informatica Field-Level Lineage",
    ) -> List[str]:
        """
        Export separate HTML visualization for each mapping.

        Args:
            cytoscape_data_dict: Dictionary of mapping_name -> cytoscape_data
            output_dir: Directory for output files
            title: Page title prefix

        Returns:
            List of paths to created files
        """
        output_dir = Path(output_dir)
        output_dir.mkdir(parents=True, exist_ok=True)

        created_files = []
        for mapping_name, cytoscape_data in cytoscape_data_dict.items():
            safe_name = "".join(c if c.isalnum() or c in ('_', '-') else '_' for c in mapping_name)
            output_path = output_dir / f"{safe_name}_visual_lineage.html"
            self.html_renderer.render(cytoscape_data, output_path, f"{title} - {mapping_name}")
            created_files.append(str(output_path))
            logger.info(f"Created: {output_path}")

        return created_files
