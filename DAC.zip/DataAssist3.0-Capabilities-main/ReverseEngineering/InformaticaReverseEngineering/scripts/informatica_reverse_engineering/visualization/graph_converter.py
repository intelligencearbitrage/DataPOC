"""Graph converter for visualization formats."""

from typing import Any, Dict, List


class GraphConverter:
    """Converts lineage graphs between different formats."""

    def to_cytoscape(self, graph_data: Dict) -> Dict[str, Any]:
        """
        Convert lineage graph to Cytoscape.js format.

        Args:
            graph_data: Lineage graph data

        Returns:
            Cytoscape.js compatible data
        """
        nodes = []
        edges = []
        node_ids = set()

        for edge_data in graph_data.get("edges", []):
            source_id = f"{edge_data['source_instance']}.{edge_data['source_field']}"
            target_id = f"{edge_data['target_instance']}.{edge_data['target_field']}"

            if source_id not in node_ids:
                nodes.append({
                    "data": {
                        "id": source_id,
                        "label": edge_data['source_field'],
                        "instance": edge_data['source_instance'],
                        "type": self._get_node_type(edge_data.get('source_type', '')),
                    }
                })
                node_ids.add(source_id)

            if target_id not in node_ids:
                nodes.append({
                    "data": {
                        "id": target_id,
                        "label": edge_data['target_field'],
                        "instance": edge_data['target_instance'],
                        "type": self._get_node_type(edge_data.get('target_type', '')),
                    }
                })
                node_ids.add(target_id)

            edges.append({
                "data": {
                    "source": source_id,
                    "target": target_id,
                    "expression": edge_data.get('expression', ''),
                }
            })

        return {"nodes": nodes, "edges": edges}

    def to_mermaid(self, graph_data: Dict, direction: str = "LR") -> str:
        """
        Convert lineage graph to Mermaid flowchart.

        Args:
            graph_data: Lineage graph data
            direction: Flow direction (LR, TB, RL, BT)

        Returns:
            Mermaid diagram code
        """
        lines = [f"flowchart {direction}"]

        # Track unique instances
        instances = {}
        for edge_data in graph_data.get("edges", []):
            src = edge_data["source_instance"]
            tgt = edge_data["target_instance"]

            if src not in instances:
                instances[src] = {
                    "type": edge_data.get("source_type", ""),
                    "fields": set()
                }
            instances[src]["fields"].add(edge_data["source_field"])

            if tgt not in instances:
                instances[tgt] = {
                    "type": edge_data.get("target_type", ""),
                    "fields": set()
                }
            instances[tgt]["fields"].add(edge_data["target_field"])

        # Create nodes
        for inst_name, inst_data in instances.items():
            node_id = self._sanitize_id(inst_name)
            shape = self._get_mermaid_shape(inst_data["type"])
            lines.append(f"    {node_id}{shape[0]}{inst_name}{shape[1]}")

        # Create edges
        edge_set = set()
        for edge_data in graph_data.get("edges", []):
            src_id = self._sanitize_id(edge_data["source_instance"])
            tgt_id = self._sanitize_id(edge_data["target_instance"])
            edge_key = f"{src_id}->{tgt_id}"

            if edge_key not in edge_set and src_id != tgt_id:
                edge_set.add(edge_key)
                lines.append(f"    {src_id} --> {tgt_id}")

        return "\n".join(lines)

    def _get_node_type(self, instance_type: str) -> str:
        """Determine node type from instance type."""
        inst_lower = instance_type.lower()
        if "source" in inst_lower:
            return "source"
        elif "target" in inst_lower:
            return "target"
        elif "lookup" in inst_lower:
            return "lookup"
        return "transformation"

    def _get_mermaid_shape(self, instance_type: str) -> tuple:
        """Get Mermaid shape for instance type."""
        inst_lower = instance_type.lower()
        if "source" in inst_lower:
            return ("([", "])")  # Stadium shape
        elif "target" in inst_lower:
            return ("[[", "]]")  # Subroutine shape
        elif "lookup" in inst_lower:
            return ("{{", "}}")  # Hexagon
        return ("[", "]")  # Rectangle

    def _sanitize_id(self, name: str) -> str:
        """Sanitize name for Mermaid ID."""
        sanitized = "".join(c if c.isalnum() or c == "_" else "_" for c in name)
        if sanitized and not sanitized[0].isalpha():
            sanitized = "n_" + sanitized
        return sanitized
