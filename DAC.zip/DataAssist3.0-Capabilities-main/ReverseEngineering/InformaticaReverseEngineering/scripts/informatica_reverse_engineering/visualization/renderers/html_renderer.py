"""HTML renderer using Cytoscape.js for interactive lineage visualization."""

from pathlib import Path
from typing import Any, Dict, List, Optional, Union
import json

from ...utils.logging_config import get_logger

logger = get_logger("html_renderer")


class HTMLRenderer:
    """Renders interactive lineage graphs using Cytoscape.js."""

    def render(
        self,
        cytoscape_data: Dict[str, Any],
        output_path: Union[str, Path],
        title: str = "Informatica Field-Level Lineage",
    ) -> str:
        """
        Render Cytoscape data to interactive HTML.

        Args:
            cytoscape_data: Cytoscape.js compatible data structure
            output_path: Path for the output file
            title: Page title

        Returns:
            Path to the created file
        """
        output_path = Path(output_path)
        output_path.parent.mkdir(parents=True, exist_ok=True)

        elements = cytoscape_data.get("elements", {})
        mapping_name = cytoscape_data.get("mapping_name", "Unknown")

        html_content = self._generate_html(elements, title, mapping_name)

        with open(output_path, 'w', encoding='utf-8') as f:
            f.write(html_content)

        logger.info(f"HTML visualization saved: {output_path}")
        return str(output_path)

    def render_multiple(
        self,
        cytoscape_data_dict: Dict[str, Dict],
        output_path: Union[str, Path],
        title: str = "Informatica Field-Level Lineage",
    ) -> str:
        """
        Render multiple mappings to a single HTML file.

        Args:
            cytoscape_data_dict: Dictionary of mapping_name -> cytoscape_data
            output_path: Path for the output file
            title: Page title

        Returns:
            Path to the created file
        """
        output_path = Path(output_path)
        output_path.parent.mkdir(parents=True, exist_ok=True)

        html_content = self._generate_multi_html(cytoscape_data_dict, title)

        with open(output_path, 'w', encoding='utf-8') as f:
            f.write(html_content)

        logger.info(f"HTML visualization saved: {output_path}")
        return str(output_path)

    def _generate_html(self, elements: Dict, title: str, mapping_name: str) -> str:
        """Generate HTML with Cytoscape.js visualization."""
        elements_json = json.dumps(elements, indent=2)

        return f"""<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{title}</title>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/cytoscape/3.23.0/cytoscape.min.js"></script>
    <style>
        * {{
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }}
        body {{
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            background: #1a1a2e;
            color: #eee;
        }}
        .header {{
            background: #16213e;
            padding: 15px 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            border-bottom: 2px solid #0f3460;
        }}
        .header h1 {{
            font-size: 1.4rem;
            color: #e94560;
        }}
        .controls {{
            display: flex;
            gap: 10px;
        }}
        .btn {{
            padding: 8px 16px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 0.9rem;
            transition: all 0.2s;
        }}
        .btn-primary {{
            background: #e94560;
            color: white;
        }}
        .btn-secondary {{
            background: #0f3460;
            color: white;
        }}
        .btn:hover {{
            opacity: 0.8;
            transform: translateY(-1px);
        }}
        #cy {{
            width: 100%;
            height: calc(100vh - 120px);
            background: #1a1a2e;
        }}
        .legend {{
            position: fixed;
            bottom: 20px;
            left: 20px;
            background: rgba(22, 33, 62, 0.95);
            padding: 15px;
            border-radius: 8px;
            border: 1px solid #0f3460;
        }}
        .legend-item {{
            display: flex;
            align-items: center;
            margin: 5px 0;
            font-size: 0.85rem;
        }}
        .legend-color {{
            width: 20px;
            height: 20px;
            border-radius: 4px;
            margin-right: 10px;
        }}
        .info-panel {{
            position: fixed;
            right: 20px;
            top: 80px;
            width: 300px;
            background: rgba(22, 33, 62, 0.95);
            padding: 15px;
            border-radius: 8px;
            border: 1px solid #0f3460;
            display: none;
        }}
        .info-panel h3 {{
            color: #e94560;
            margin-bottom: 10px;
        }}
        .info-panel .field {{
            margin: 8px 0;
        }}
        .info-panel .label {{
            color: #888;
            font-size: 0.8rem;
        }}
        .info-panel .value {{
            font-family: monospace;
            word-break: break-all;
        }}
    </style>
</head>
<body>
    <div class="header">
        <h1>{title} - {mapping_name}</h1>
        <div class="controls">
            <button class="btn btn-primary" onclick="fit()">Fit View</button>
            <button class="btn btn-secondary" onclick="layout('dagre')">Hierarchical</button>
            <button class="btn btn-secondary" onclick="layout('cose')">Force Layout</button>
            <button class="btn btn-secondary" onclick="layout('grid')">Grid</button>
        </div>
    </div>

    <div id="cy"></div>

    <div class="legend">
        <div class="legend-item">
            <div class="legend-color" style="background: #4CAF50;"></div>
            <span>Source</span>
        </div>
        <div class="legend-item">
            <div class="legend-color" style="background: #9C27B0;"></div>
            <span>Target</span>
        </div>
        <div class="legend-item">
            <div class="legend-color" style="background: #2196F3;"></div>
            <span>Transformation</span>
        </div>
        <div class="legend-item">
            <div class="legend-color" style="background: #FF9800;"></div>
            <span>Lookup</span>
        </div>
    </div>

    <div class="info-panel" id="infoPanel">
        <h3>Node Details</h3>
        <div class="field">
            <div class="label">Instance</div>
            <div class="value" id="infoInstance">-</div>
        </div>
        <div class="field">
            <div class="label">Field</div>
            <div class="value" id="infoField">-</div>
        </div>
        <div class="field">
            <div class="label">Type</div>
            <div class="value" id="infoType">-</div>
        </div>
        <div class="field">
            <div class="label">Expression</div>
            <div class="value" id="infoExpression">-</div>
        </div>
    </div>

    <script>
        const elements = {elements_json};

        const cy = cytoscape({{
            container: document.getElementById('cy'),
            elements: elements.nodes.concat(elements.edges),
            style: [
                {{
                    selector: 'node',
                    style: {{
                        'background-color': function(ele) {{
                            const type = ele.data('type');
                            if (type === 'source') return '#4CAF50';
                            if (type === 'target') return '#9C27B0';
                            if (type === 'lookup') return '#FF9800';
                            return '#2196F3';
                        }},
                        'label': 'data(label)',
                        'color': '#fff',
                        'text-valign': 'center',
                        'text-halign': 'center',
                        'font-size': '10px',
                        'width': '60px',
                        'height': '60px',
                        'border-width': '2px',
                        'border-color': '#fff'
                    }}
                }},
                {{
                    selector: 'edge',
                    style: {{
                        'width': 2,
                        'line-color': '#888',
                        'target-arrow-color': '#888',
                        'target-arrow-shape': 'triangle',
                        'curve-style': 'bezier',
                        'label': 'data(label)',
                        'font-size': '8px',
                        'color': '#aaa',
                        'text-rotation': 'autorotate'
                    }}
                }},
                {{
                    selector: ':selected',
                    style: {{
                        'border-width': '4px',
                        'border-color': '#e94560'
                    }}
                }}
            ],
            layout: {{
                name: 'cose',
                animate: true,
                animationDuration: 500
            }}
        }});

        // Node click handler
        cy.on('tap', 'node', function(evt) {{
            const node = evt.target;
            const panel = document.getElementById('infoPanel');
            panel.style.display = 'block';
            document.getElementById('infoInstance').textContent = node.data('instance') || '-';
            document.getElementById('infoField').textContent = node.data('label') || '-';
            document.getElementById('infoType').textContent = node.data('type') || '-';
        }});

        // Edge click handler
        cy.on('tap', 'edge', function(evt) {{
            const edge = evt.target;
            const panel = document.getElementById('infoPanel');
            panel.style.display = 'block';
            document.getElementById('infoInstance').textContent = 'Edge';
            document.getElementById('infoField').textContent = edge.data('source') + ' -> ' + edge.data('target');
            document.getElementById('infoType').textContent = 'Connection';
            document.getElementById('infoExpression').textContent = edge.data('expression') || '-';
        }});

        // Background click handler
        cy.on('tap', function(evt) {{
            if (evt.target === cy) {{
                document.getElementById('infoPanel').style.display = 'none';
            }}
        }});

        function fit() {{
            cy.fit();
        }}

        function layout(name) {{
            cy.layout({{ name: name, animate: true, animationDuration: 500 }}).run();
        }}
    </script>
</body>
</html>"""

    def _generate_multi_html(self, cytoscape_data_dict: Dict[str, Dict], title: str) -> str:
        """Generate HTML with multiple mapping visualizations."""
        mapping_data = json.dumps({
            name: data.get("elements", {})
            for name, data in cytoscape_data_dict.items()
        }, indent=2)

        mapping_options = "".join([
            f'<option value="{name}">{name}</option>'
            for name in cytoscape_data_dict.keys()
        ])

        return f"""<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{title}</title>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/cytoscape/3.23.0/cytoscape.min.js"></script>
    <style>
        * {{ margin: 0; padding: 0; box-sizing: border-box; }}
        body {{ font-family: -apple-system, BlinkMacSystemFont, sans-serif; background: #1a1a2e; color: #eee; }}
        .header {{ background: #16213e; padding: 15px 20px; display: flex; justify-content: space-between; align-items: center; }}
        .header h1 {{ font-size: 1.4rem; color: #e94560; }}
        .controls {{ display: flex; gap: 10px; align-items: center; }}
        select, .btn {{ padding: 8px 16px; border: none; border-radius: 4px; font-size: 0.9rem; cursor: pointer; }}
        select {{ background: #0f3460; color: white; }}
        .btn {{ background: #e94560; color: white; }}
        .btn:hover {{ opacity: 0.8; }}
        #cy {{ width: 100%; height: calc(100vh - 60px); background: #1a1a2e; }}
        .legend {{
            position: fixed;
            bottom: 20px;
            left: 20px;
            background: rgba(22, 33, 62, 0.95);
            padding: 15px;
            border-radius: 8px;
            border: 1px solid #0f3460;
            font-size: 0.85rem;
        }}
        .legend-title {{ font-weight: bold; margin-bottom: 10px; color: #e94560; }}
        .legend-item {{ display: flex; align-items: center; margin: 5px 0; }}
        .legend-shape {{ width: 24px; height: 24px; margin-right: 10px; display: flex; align-items: center; justify-content: center; }}
        .info-panel {{
            position: fixed;
            right: 20px;
            top: 80px;
            width: 350px;
            max-height: calc(100vh - 100px);
            overflow-y: auto;
            background: rgba(22, 33, 62, 0.98);
            padding: 20px;
            border-radius: 8px;
            border: 1px solid #0f3460;
            display: none;
            box-shadow: 0 4px 20px rgba(0,0,0,0.3);
        }}
        .info-panel h3 {{ color: #e94560; margin-bottom: 15px; font-size: 1.1rem; }}
        .info-panel .field {{ margin: 12px 0; }}
        .info-panel .label {{ color: #888; font-size: 0.75rem; text-transform: uppercase; letter-spacing: 0.5px; }}
        .info-panel .value {{ font-family: 'Consolas', monospace; word-break: break-word; margin-top: 4px; background: rgba(0,0,0,0.2); padding: 8px; border-radius: 4px; }}
        .info-panel .close-btn {{ position: absolute; top: 10px; right: 10px; background: none; border: none; color: #888; cursor: pointer; font-size: 1.2rem; }}
        .info-panel .close-btn:hover {{ color: #e94560; }}
    </style>
</head>
<body>
    <div class="header">
        <h1>{title}</h1>
        <div class="controls">
            <select id="mappingSelect" onchange="loadMapping(this.value)">{mapping_options}</select>
            <button class="btn" onclick="cy.fit()">Fit View</button>
            <button class="btn" onclick="setLayout('breadthfirst')">Hierarchical</button>
            <button class="btn" onclick="setLayout('cose')">Force</button>
        </div>
    </div>
    <div id="cy"></div>

    <div class="legend">
        <div class="legend-title">Node Types</div>
        <div class="legend-item">
            <div class="legend-shape"><svg width="20" height="20"><ellipse cx="10" cy="10" rx="10" ry="6" fill="#4CAF50"/></svg></div>
            <span>Source</span>
        </div>
        <div class="legend-item">
            <div class="legend-shape"><svg width="20" height="20"><ellipse cx="10" cy="10" rx="10" ry="6" fill="#66BB6A"/></svg></div>
            <span>Source Qualifier</span>
        </div>
        <div class="legend-item">
            <div class="legend-shape"><svg width="20" height="20"><rect x="2" y="5" width="16" height="10" fill="#2196F3"/></svg></div>
            <span>Expression</span>
        </div>
        <div class="legend-item">
            <div class="legend-shape"><svg width="20" height="20"><polygon points="10,2 18,10 10,18 2,10" fill="#FF5722"/></svg></div>
            <span>Filter</span>
        </div>
        <div class="legend-item">
            <div class="legend-shape"><svg width="20" height="20"><polygon points="10,2 18,7 18,13 10,18 2,13 2,7" fill="#FF9800"/></svg></div>
            <span>Aggregator</span>
        </div>
        <div class="legend-item">
            <div class="legend-shape"><svg width="20" height="20"><rect x="4" y="2" width="12" height="16" rx="6" fill="#FFC107"/></svg></div>
            <span>Lookup</span>
        </div>
        <div class="legend-item">
            <div class="legend-shape"><svg width="20" height="20"><polygon points="10,2 18,10 10,18 2,10" fill="#E91E63"/></svg></div>
            <span>Router</span>
        </div>
        <div class="legend-item">
            <div class="legend-shape"><svg width="20" height="20"><rect x="0" y="5" width="20" height="10" fill="#9C27B0"/></svg></div>
            <span>Target</span>
        </div>
    </div>

    <div class="info-panel" id="infoPanel">
        <button class="close-btn" onclick="closeInfoPanel()">&times;</button>
        <h3 id="infoPanelTitle">Node Details</h3>
        <div class="field">
            <div class="label">Instance</div>
            <div class="value" id="infoInstance">-</div>
        </div>
        <div class="field">
            <div class="label">Type</div>
            <div class="value" id="infoType">-</div>
        </div>
        <div class="field" id="sqlOverrideField" style="display:none;">
            <div class="label" style="color: #e94560;">SQL Override</div>
            <div class="value" id="infoSqlOverride" style="background: rgba(233,69,96,0.1); border: 1px solid #e94560; font-size: 0.8rem; max-height: 150px; overflow-y: auto;">-</div>
        </div>
        <div class="field">
            <div class="label">Fields</div>
            <div class="value" id="infoField">-</div>
        </div>
        <div class="field" id="fieldDetailsField" style="display:none;">
            <div class="label">Field Details (with Explanations)</div>
            <div class="value" id="infoFieldDetails" style="font-size: 0.8rem; max-height: 300px; overflow-y: auto;">-</div>
        </div>
        <div class="field" id="exprField" style="display:none;">
            <div class="label">Expressions</div>
            <div class="value" id="infoExpression">-</div>
        </div>
        <div class="field" id="explainField" style="display:none;">
            <div class="label">Description</div>
            <div class="value" id="infoExplanation">-</div>
        </div>
    </div>

    <script>
        const allMappings = {mapping_data};
        let cy;

        function getNodeColor(type) {{
            const colors = {{
                'source': '#4CAF50',
                'source_qualifier': '#66BB6A',
                'target': '#9C27B0',
                'expression': '#2196F3',
                'filter': '#FF5722',
                'aggregator': '#FF9800',
                'lookup': '#FFC107',
                'joiner': '#00BCD4',
                'router': '#E91E63',
                'update_strategy': '#795548',
                'normalizer': '#607D8B',
                'transformation': '#3F51B5'
            }};
            return colors[type] || '#3F51B5';
        }}

        function getNodeShape(type) {{
            const shapes = {{
                'source': 'ellipse',
                'source_qualifier': 'ellipse',
                'target': 'rectangle',
                'expression': 'round-rectangle',
                'filter': 'diamond',
                'aggregator': 'hexagon',
                'lookup': 'barrel',
                'joiner': 'octagon',
                'router': 'diamond',
                'update_strategy': 'tag',
                'normalizer': 'round-rectangle',
                'transformation': 'round-rectangle'
            }};
            return shapes[type] || 'ellipse';
        }}

        function initCy(elements) {{
            if (cy) cy.destroy();
            cy = cytoscape({{
                container: document.getElementById('cy'),
                elements: (elements.nodes || []).concat(elements.edges || []),
                style: [
                    {{
                        selector: 'node',
                        style: {{
                            'background-color': function(ele) {{ return getNodeColor(ele.data('type')); }},
                            'shape': function(ele) {{ return getNodeShape(ele.data('type')); }},
                            'label': function(ele) {{
                                const inst = ele.data('instance') || '';
                                const field = ele.data('label') || '';
                                return inst + '\\n' + field;
                            }},
                            'color': '#fff',
                            'text-valign': 'center',
                            'text-halign': 'center',
                            'text-wrap': 'wrap',
                            'text-max-width': '100px',
                            'font-size': '9px',
                            'width': '80px',
                            'height': '50px',
                            'border-width': '2px',
                            'border-color': '#fff',
                            'text-outline-color': '#000',
                            'text-outline-width': '1px'
                        }}
                    }},
                    {{
                        selector: 'edge',
                        style: {{
                            'width': 2,
                            'line-color': '#666',
                            'target-arrow-color': '#666',
                            'target-arrow-shape': 'triangle',
                            'curve-style': 'bezier',
                            'label': function(ele) {{
                                const expr = ele.data('expression') || '';
                                return expr.length > 30 ? expr.substring(0, 30) + '...' : expr;
                            }},
                            'font-size': '8px',
                            'color': '#aaa',
                            'text-rotation': 'autorotate',
                            'text-background-color': '#1a1a2e',
                            'text-background-opacity': 0.8,
                            'text-background-padding': '2px'
                        }}
                    }},
                    {{
                        selector: ':selected',
                        style: {{
                            'border-width': '4px',
                            'border-color': '#e94560',
                            'line-color': '#e94560',
                            'target-arrow-color': '#e94560'
                        }}
                    }},
                    {{
                        selector: 'node:active',
                        style: {{
                            'overlay-opacity': 0.2
                        }}
                    }}
                ],
                layout: {{
                    name: 'breadthfirst',
                    directed: true,
                    spacingFactor: 1.5,
                    animate: true,
                    animationDuration: 500
                }}
            }});

            // Node click handler
            cy.on('tap', 'node', function(evt) {{
                const node = evt.target;
                showNodeInfo(node);
            }});

            // Edge click handler
            cy.on('tap', 'edge', function(evt) {{
                const edge = evt.target;
                showEdgeInfo(edge);
            }});

            // Background click handler
            cy.on('tap', function(evt) {{
                if (evt.target === cy) {{
                    closeInfoPanel();
                }}
            }});
        }}

        function showNodeInfo(node) {{
            const panel = document.getElementById('infoPanel');
            document.getElementById('infoPanelTitle').textContent = 'Transformation Details';
            document.getElementById('infoInstance').textContent = node.data('label') || node.data('id') || '-';
            document.getElementById('infoType').textContent = (node.data('instance_type') || node.data('type') || '-');

            // Show SQL Override if present (for Source Qualifiers and Lookups)
            const sqlOverride = node.data('sql_override') || '';
            if (sqlOverride) {{
                document.getElementById('infoSqlOverride').textContent = sqlOverride;
                document.getElementById('sqlOverrideField').style.display = 'block';
            }} else {{
                document.getElementById('sqlOverrideField').style.display = 'none';
            }}

            // Show field count and list
            const fields = node.data('fields') || [];
            const fieldCount = node.data('field_count') || fields.length;
            let fieldText = fieldCount + ' field(s)';
            if (fields.length > 0) {{
                fieldText += ': ' + fields.slice(0, 8).join(', ');
                if (fields.length > 8) fieldText += '... (+' + (fields.length - 8) + ' more)';
            }}
            document.getElementById('infoField').textContent = fieldText;

            // Show ALL field details with expressions and explanations
            const fieldDetails = node.data('field_details') || [];
            if (fieldDetails.length > 0) {{
                let detailsHtml = '';
                fieldDetails.forEach(function(fd) {{
                    const fieldName = fd.field || '';
                    const expression = fd.expression || '';
                    const explanation = fd.explanation || 'Source field - data origin';

                    detailsHtml += '<div style="margin-bottom: 10px; padding-bottom: 8px; border-bottom: 1px solid rgba(255,255,255,0.1);">';
                    detailsHtml += '<strong style="color: #4CAF50;">' + fieldName + '</strong><br/>';
                    if (expression) {{
                        detailsHtml += '<span style="color: #888;">Expression:</span> <code style="color: #FFC107;">' + escapeHtml(expression.substring(0, 80)) + (expression.length > 80 ? '...' : '') + '</code><br/>';
                    }}
                    detailsHtml += '<span style="color: #2196F3;">' + escapeHtml(explanation) + '</span>';
                    detailsHtml += '</div>';
                }});
                document.getElementById('infoFieldDetails').innerHTML = detailsHtml;
                document.getElementById('fieldDetailsField').style.display = 'block';
            }} else {{
                document.getElementById('fieldDetailsField').style.display = 'none';
            }}

            // Hide old expression field (now using fieldDetails)
            document.getElementById('exprField').style.display = 'none';
            document.getElementById('explainField').style.display = 'none';

            panel.style.display = 'block';
        }}

        function escapeHtml(text) {{
            if (!text) return '';
            return text.replace(/&/g, '&amp;')
                       .replace(/</g, '&lt;')
                       .replace(/>/g, '&gt;')
                       .replace(/"/g, '&quot;')
                       .replace(/'/g, '&#039;')
                       .replace(/\\n/g, '<br/>');
        }}

        function showEdgeInfo(edge) {{
            const panel = document.getElementById('infoPanel');
            document.getElementById('infoPanelTitle').textContent = 'Connection Details';
            document.getElementById('infoInstance').textContent = edge.data('source') + ' → ' + edge.data('target');
            document.getElementById('infoType').textContent = 'Data Flow';

            // Hide SQL override (not applicable to edges)
            document.getElementById('sqlOverrideField').style.display = 'none';

            // Show field mapping count
            const fieldMappings = edge.data('field_mappings') || [];
            const fieldCount = edge.data('field_count') || fieldMappings.length;
            document.getElementById('infoField').textContent = fieldCount + ' field mapping(s)';

            // Show ALL field mappings with expressions and explanations
            if (fieldMappings.length > 0) {{
                let detailsHtml = '';
                fieldMappings.forEach(function(fm) {{
                    const sourceField = fm.source_field || '';
                    const targetField = fm.target_field || '';
                    const expression = fm.expression || '';
                    const explanation = fm.expression_explanation || 'Direct field mapping';

                    detailsHtml += '<div style="margin-bottom: 10px; padding-bottom: 8px; border-bottom: 1px solid rgba(255,255,255,0.1);">';
                    detailsHtml += '<strong style="color: #4CAF50;">' + sourceField + '</strong>';
                    detailsHtml += ' <span style="color: #e94560;">→</span> ';
                    detailsHtml += '<strong style="color: #9C27B0;">' + targetField + '</strong><br/>';
                    if (expression) {{
                        detailsHtml += '<span style="color: #888;">Expression:</span> <code style="color: #FFC107;">' + escapeHtml(expression.substring(0, 60)) + (expression.length > 60 ? '...' : '') + '</code><br/>';
                    }}
                    detailsHtml += '<span style="color: #2196F3;">' + escapeHtml(explanation) + '</span>';
                    detailsHtml += '</div>';
                }});
                document.getElementById('infoFieldDetails').innerHTML = detailsHtml;
                document.getElementById('fieldDetailsField').style.display = 'block';
            }} else {{
                document.getElementById('fieldDetailsField').style.display = 'none';
            }}

            // Hide old expression/explanation fields (now using fieldDetails)
            document.getElementById('exprField').style.display = 'none';
            document.getElementById('explainField').style.display = 'none';

            panel.style.display = 'block';
        }}

        function closeInfoPanel() {{
            document.getElementById('infoPanel').style.display = 'none';
        }}

        function loadMapping(name) {{
            initCy(allMappings[name] || {{ nodes: [], edges: [] }});
        }}

        function setLayout(layoutName) {{
            const layoutOptions = {{
                'breadthfirst': {{ name: 'breadthfirst', directed: true, spacingFactor: 1.5 }},
                'cose': {{ name: 'cose', nodeRepulsion: 8000, idealEdgeLength: 100 }},
                'dagre': {{ name: 'dagre', rankDir: 'LR' }},
                'grid': {{ name: 'grid' }}
            }};
            cy.layout({{ ...layoutOptions[layoutName], animate: true, animationDuration: 500 }}).run();
        }}

        loadMapping(Object.keys(allMappings)[0]);
    </script>
</body>
</html>"""
