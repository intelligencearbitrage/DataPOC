"""Mermaid diagram renderer for lineage visualization."""

from pathlib import Path
from typing import Any, Dict, List, Optional, Union

from ...utils.logging_config import get_logger

logger = get_logger("mermaid_renderer")


class MermaidRenderer:
    """Renders lineage graphs as Mermaid diagrams."""

    def render(
        self,
        mermaid_code: str,
        output_path: Union[str, Path],
        title: str = "Informatica Lineage",
    ) -> str:
        """
        Render Mermaid code to HTML.

        Args:
            mermaid_code: Mermaid diagram code
            output_path: Path for the output file
            title: Page title

        Returns:
            Path to the created file
        """
        output_path = Path(output_path)
        output_path.parent.mkdir(parents=True, exist_ok=True)

        html_content = self._generate_html(mermaid_code, title)

        with open(output_path, 'w', encoding='utf-8') as f:
            f.write(html_content)

        logger.info(f"Mermaid visualization saved: {output_path}")
        return str(output_path)

    def render_multiple(
        self,
        mermaid_diagrams: Dict[str, str],
        output_path: Union[str, Path],
        title: str = "Informatica Lineage",
    ) -> str:
        """
        Render multiple Mermaid diagrams to HTML.

        Args:
            mermaid_diagrams: Dictionary of mapping_name -> mermaid_code
            output_path: Path for the output file
            title: Page title

        Returns:
            Path to the created file
        """
        output_path = Path(output_path)
        output_path.parent.mkdir(parents=True, exist_ok=True)

        html_content = self._generate_multi_html(mermaid_diagrams, title)

        with open(output_path, 'w', encoding='utf-8') as f:
            f.write(html_content)

        logger.info(f"Mermaid visualization saved: {output_path}")
        return str(output_path)

    def save_markdown(
        self,
        mermaid_diagrams: Dict[str, str],
        output_path: Union[str, Path],
    ) -> str:
        """
        Save Mermaid diagrams as Markdown file.

        Args:
            mermaid_diagrams: Dictionary of mapping_name -> mermaid_code
            output_path: Path for the output file

        Returns:
            Path to the created file
        """
        output_path = Path(output_path)
        output_path.parent.mkdir(parents=True, exist_ok=True)

        lines = ["# Informatica Lineage Diagrams\n"]

        for name, code in mermaid_diagrams.items():
            lines.append(f"## {name}\n")
            lines.append("```mermaid")
            lines.append(code)
            lines.append("```\n")

        with open(output_path, 'w', encoding='utf-8') as f:
            f.write("\n".join(lines))

        return str(output_path)

    def _generate_html(self, mermaid_code: str, title: str) -> str:
        """Generate HTML with Mermaid diagram."""
        # Escape backticks in mermaid code
        escaped_code = mermaid_code.replace("`", "\\`")

        return f"""<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{title}</title>
    <script src="https://cdn.jsdelivr.net/npm/mermaid/dist/mermaid.min.js"></script>
    <style>
        body {{
            font-family: -apple-system, BlinkMacSystemFont, sans-serif;
            background: #f5f5f5;
            margin: 0;
            padding: 20px;
        }}
        .container {{
            max-width: 1200px;
            margin: 0 auto;
            background: white;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
        }}
        h1 {{
            color: #333;
            border-bottom: 2px solid #e94560;
            padding-bottom: 15px;
        }}
        .mermaid {{
            text-align: center;
            margin: 20px 0;
        }}
    </style>
</head>
<body>
    <div class="container">
        <h1>{title}</h1>
        <div class="mermaid">
{mermaid_code}
        </div>
    </div>
    <script>
        mermaid.initialize({{ startOnLoad: true, theme: 'default' }});
    </script>
</body>
</html>"""

    def _generate_multi_html(self, mermaid_diagrams: Dict[str, str], title: str) -> str:
        """Generate HTML with multiple Mermaid diagrams."""
        diagrams_html = []
        for name, code in mermaid_diagrams.items():
            diagrams_html.append(f"""
        <div class="diagram-section">
            <h2>{name}</h2>
            <div class="mermaid">
{code}
            </div>
        </div>""")

        return f"""<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{title}</title>
    <script src="https://cdn.jsdelivr.net/npm/mermaid/dist/mermaid.min.js"></script>
    <style>
        body {{
            font-family: -apple-system, BlinkMacSystemFont, sans-serif;
            background: #f5f5f5;
            margin: 0;
            padding: 20px;
        }}
        .container {{
            max-width: 1200px;
            margin: 0 auto;
        }}
        h1 {{
            color: #333;
            text-align: center;
        }}
        .diagram-section {{
            background: white;
            padding: 20px;
            margin: 20px 0;
            border-radius: 8px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
        }}
        .diagram-section h2 {{
            color: #e94560;
            margin-bottom: 15px;
        }}
        .mermaid {{
            text-align: center;
        }}
    </style>
</head>
<body>
    <div class="container">
        <h1>{title}</h1>
        {''.join(diagrams_html)}
    </div>
    <script>
        mermaid.initialize({{ startOnLoad: true, theme: 'default' }});
    </script>
</body>
</html>"""
