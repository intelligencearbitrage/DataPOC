#!/usr/bin/env python3
"""
CLI entry point for the Glue Optimization Engine.

Usage (from project root):
    python scripts/GLUEOPTIMIZER-SOLUTION/cli.py -k knowledgebase -o output
    python scripts/GLUEOPTIMIZER-SOLUTION/cli.py -k knowledgebase -o output --llm-enabled
"""

import argparse
import sys
import os

# Resolve project root (two levels up from this script)
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
PROJECT_ROOT = os.path.abspath(os.path.join(SCRIPT_DIR, "..", ".."))

# Add engine directory to path so glue_optimization_engine can be imported
sys.path.insert(0, SCRIPT_DIR)

from glue_optimization_engine import GlueOptimizationEngine


def main():
    parser = argparse.ArgumentParser(
        prog="glue-optimizer",
        description="AWS Glue ETL Job Optimization Engine",
    )
    parser.add_argument(
        "--knowledgebase", "-k",
        default=os.path.join(PROJECT_ROOT, "knowledgebase"),
        help="Path to knowledgebase directory (default: <project_root>/knowledgebase/)",
    )
    parser.add_argument(
        "--output", "-o",
        default=os.path.join(PROJECT_ROOT, "output"),
        help="Path to output directory (default: <project_root>/output/)",
    )
    parser.add_argument(
        "--llm-enabled", action="store_true",
        help="Enable LLM-assisted rule learning via Amazon Bedrock",
    )
    parser.add_argument(
        "--llm-model-id",
        default="anthropic.claude-3-sonnet-20240229-v1:0",
        help="Bedrock model ID (default: anthropic.claude-3-sonnet-20240229-v1:0)",
    )
    args = parser.parse_args()

    engine = GlueOptimizationEngine(
        knowledgebase_dir=args.knowledgebase,
        output_dir=args.output,
        llm_enabled=args.llm_enabled,
        llm_model_id=args.llm_model_id,
    )
    engine.run()


if __name__ == "__main__":
    main()
