# GLUEOPTIMIZER-SOLUTION

Deterministic optimization engine for AWS Glue ETL jobs. Reads job metrics, PySpark scripts, and configuration artifacts, performs rule-based Root Cause Analysis (RCA), applies structured optimizations, and generates YAML reports with optimized artifacts.

## What It Does

1. **Reads** `glue_job_metrics.xlsx` from the knowledgebase to identify threshold-exceeding jobs
2. **Loads** corresponding artifacts (`.py`, `.yml`, `.json`, `.txt`) for each flagged job
3. **Analyzes** artifacts using 49+ rules across six categories:
   - Code Quality (syntax errors, artificial delays, dead code)
   - Spark Anti-Patterns (collect, repartition, toPandas, coalesce(1), UDFs, cache leaks, groupByKey)
   - SQL Inefficiency (SELECT *, correlated subqueries, Cartesian joins, ORDER BY without LIMIT)
   - Config Issues (worker count/type scaling, timeout, memory-intensive ops)
   - IO Performance (chunk sizes, fetchsize tuning)
   - Runtime Analysis (long-running stages, OOM, GC overhead, shuffle spill, data skew)
4. **Generates** optimized artifacts, structured YAML RCA reports, and executive summaries
5. **Validates** optimized output by re-running analysis to confirm fixes

## Setup

```bash
pip install -r requirements.txt
```

**boto3** is only required if you enable LLM-assisted analysis (`--llm-enabled`). Without it, the engine runs fully deterministic.

## How to Run

```bash
# Basic run (local directories)
python cli.py -k /path/to/knowledgebase -o /path/to/output

# With LLM fallback enabled
python cli.py -k /path/to/knowledgebase -o /path/to/output --llm-enabled

# Custom Bedrock model
python cli.py -k /path/to/knowledgebase -o /path/to/output \
    --llm-enabled --llm-model-id anthropic.claude-3-haiku-20240307-v1:0
```

### Arguments

| Argument | Short | Default | Description |
|----------|-------|---------|-------------|
| `--knowledgebase` | `-k` | `knowledgebase` | Directory with job artifacts (Excel, PySpark, configs) |
| `--output` | `-o` | `output` | Directory for optimized artifacts and reports |
| `--llm-enabled` | | `false` | Enable LLM-assisted rule learning via Bedrock |
| `--llm-model-id` | | `anthropic.claude-3-sonnet-*` | Bedrock model ID for LLM analysis |

## Knowledgebase Structure

Place these files in your knowledgebase directory:

```
knowledgebase/
├── glue_job_metrics.xlsx          # Job metrics with threshold columns
├── <job_name>.py                  # PySpark ETL scripts
├── <job_name>.json                # Glue job configuration
├── <job_name>_resolved_conf.yml   # Resolved Spark/Hive configuration
└── <job_name>_cloudwatch.txt      # CloudWatch log excerpts (optional)
```

## Output Structure

```
output/
├── optimized/                     # Optimized PySpark scripts and configs
│   ├── <job_name>.py
│   └── <job_name>.json
├── rca_reports/                   # Per-job YAML RCA reports
│   └── <job_name>_rca.yaml
└── summary.yaml                   # Executive summary across all jobs
```

## Assumptions

- Input Excel file (`glue_job_metrics.xlsx`) must exist in the knowledgebase directory with columns for job name and performance metrics
- PySpark scripts are valid Python 3 (engine uses AST parsing)
- Job artifact filenames match the job names from the Excel metrics
- AWS credentials are configured in the environment if using `--llm-enabled`

## Limitations

- SQL optimization recommendations are heuristic-based; complex query rewrites may need manual review
- AST-based transformations preserve semantics but may alter formatting
- CloudWatch log analysis depends on standard Glue log format
- LLM fallback requires network access to Amazon Bedrock
