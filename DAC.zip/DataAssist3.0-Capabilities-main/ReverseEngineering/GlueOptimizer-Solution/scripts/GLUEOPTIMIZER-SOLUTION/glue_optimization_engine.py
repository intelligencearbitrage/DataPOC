#!/usr/bin/env python3
from __future__ import annotations
"""
Glue Optimization Engine (v2.0)
================================
A deterministic, reusable, fully executable Python module that:
  1. Reads glue_job_metrics.xlsx and identifies threshold-exceeding jobs
  2. Dynamically loads only corresponding artifacts (.py, .yml, .json, .txt)
  3. Performs rule-based Root Cause Analysis (RCA) via a modular registry
  4. Maps each detected root cause to a deterministic artifact transformation
  5. Applies structured optimizations only when justified
  6. Validates outputs through re-analysis
  7. Generates structured YAML RCA output, optimized artifacts, and summaries
  8. Optionally invokes LLM-assisted rule learning when no rules match

RCA Rule Categories:
  - Code Quality: syntax errors, artificial delays, dead code
  - Spark Anti-Patterns: collect, repartition, data amplification, toPandas,
    coalesce(1), broadcast large DFs, UDFs, cache leaks, groupByKey
  - SQL Inefficiency: SELECT *, correlated subqueries, Cartesian joins,
    missing join predicates, ORDER BY without LIMIT, deep nesting,
    UNION vs UNION ALL, unbounded aggregation
  - Config Issues: worker count/type scaling based on data volume and job type,
    timeout misconfiguration, memory-intensive operation detection
  - IO Performance: small chunk sizes, fetchsize tuning
  - Runtime Analysis: long-running stages, OOM, GC overhead, shuffle spill,
    data skew detection from CloudWatch logs

Architecture:
  - RCARule abstract base class
  - RULE_REGISTRY with dynamically registered concrete rules
  - AST-based Python transformations
  - Structured YAML / JSON manipulation
  - Log-based timestamp and pattern analysis
  - Smart worker scaling engine (G.025X -> G.1X -> G.2X -> G.4X -> G.8X, Z.2X)
  - Optional LLM fallback via Amazon Bedrock (Claude)
"""

import os
import re
import sys
import ast
import json
import copy
import glob
import time
import math
import textwrap
import datetime
import importlib
import importlib.util
from abc import ABC, abstractmethod
from collections import OrderedDict

import openpyxl
import yaml


# =============================================================================
# Constants
# =============================================================================

GLUE_WORKER_TYPES = ["G.025X", "G.1X", "G.2X", "G.4X", "G.8X", "Z.2X"]

WORKER_TYPE_MEMORY_GB = {
    "G.025X": 2, "G.1X": 4, "G.2X": 8, "G.4X": 16, "G.8X": 32, "Z.2X": 8,
}

WORKER_TYPE_VCPU = {
    "G.025X": 2, "G.1X": 4, "G.2X": 8, "G.4X": 16, "G.8X": 32, "Z.2X": 8,
}


# =============================================================================
# RCA Rule Abstract Base Class
# =============================================================================

class RCARule(ABC):
    """Every RCA rule must inherit from this class and register itself."""

    @property
    @abstractmethod
    def rule_id(self) -> str:
        ...

    @property
    @abstractmethod
    def rule_name(self) -> str:
        ...

    @property
    @abstractmethod
    def category(self) -> str:
        ...

    @abstractmethod
    def detect(self, artifacts: dict) -> list:
        ...

    @abstractmethod
    def classify_severity(self, finding: dict) -> str:
        ...

    @abstractmethod
    def recommend_fix(self, finding: dict) -> str:
        ...

    @abstractmethod
    def transformation_mapping(self, finding: dict) -> dict:
        ...


# =============================================================================
# Rule Registry
# =============================================================================

RULE_REGISTRY: list[RCARule] = []


def register_rule(cls):
    RULE_REGISTRY.append(cls())
    return cls


# =============================================================================
# AST Utilities
# =============================================================================

class ASTPatternVisitor(ast.NodeVisitor):
    """Collects occurrences of PySpark anti-patterns via AST traversal."""

    def __init__(self):
        self.collect_calls = []
        self.count_calls = []
        self.show_calls = []
        self.repartition_calls = []
        self.coalesce_calls = []
        self.sleep_calls = []
        self.array_repeat_refs = []
        self.explode_refs = []
        self.chunk_size_assigns = []
        self.to_pandas_calls = []
        self.broadcast_calls = []
        self.udf_calls = []
        self.cache_calls = []
        self.persist_calls = []
        self.unpersist_calls = []
        self.group_by_key_calls = []
        self.cross_join_calls = []
        self.distinct_calls = []
        self.sort_calls = []
        self.write_calls = []
        self.fetchsize_values = []
        self.string_constants = []
        self.conf_set_calls = []     # conf.set("spark.x", "val") calls
        self.set_master_calls = []   # .setMaster("local") calls
        self.spark_context_calls = []  # SparkContext(conf=...) calls

    def visit_Call(self, node):
        attr_name = self._get_call_attr(node)
        if attr_name == "collect":
            self.collect_calls.append(node)
        elif attr_name == "count":
            self.count_calls.append(node)
        elif attr_name == "show":
            self.show_calls.append(node)
        elif attr_name == "repartition":
            self.repartition_calls.append(node)
        elif attr_name == "coalesce":
            self.coalesce_calls.append(node)
        elif attr_name == "sleep":
            self.sleep_calls.append(node)
        elif attr_name == "array_repeat":
            self.array_repeat_refs.append(node)
        elif attr_name == "explode":
            self.explode_refs.append(node)
        elif attr_name == "toPandas":
            self.to_pandas_calls.append(node)
        elif attr_name == "broadcast":
            self.broadcast_calls.append(node)
        elif attr_name in ("udf", "pandas_udf"):
            self.udf_calls.append(node)
        elif attr_name == "cache":
            self.cache_calls.append(node)
        elif attr_name == "persist":
            self.persist_calls.append(node)
        elif attr_name == "unpersist":
            self.unpersist_calls.append(node)
        elif attr_name == "groupByKey":
            self.group_by_key_calls.append(node)
        elif attr_name == "crossJoin":
            self.cross_join_calls.append(node)
        elif attr_name == "distinct":
            self.distinct_calls.append(node)
        elif attr_name in ("sort", "orderBy"):
            self.sort_calls.append(node)
        elif attr_name in ("save", "write", "insertInto"):
            self.write_calls.append(node)
        elif attr_name == "set" and self._is_conf_set(node):
            self.conf_set_calls.append(node)
        elif attr_name == "setMaster":
            self.set_master_calls.append(node)
        # Detect SparkContext(conf=...) instantiation
        if isinstance(node.func, ast.Name) and node.func.id == "SparkContext":
            self.spark_context_calls.append(node)
        self.generic_visit(node)

    def visit_Assign(self, node):
        for target in node.targets:
            if isinstance(target, ast.Name) and target.id == "chunk_size":
                self.chunk_size_assigns.append(node)
        self.generic_visit(node)

    def visit_Constant(self, node):
        if isinstance(node.value, str) and len(node.value) > 10:
            self.string_constants.append(node)
        self.generic_visit(node)

    @staticmethod
    def _is_conf_set(node):
        """Check if this is a conf.set("spark.x", "val") call."""
        if (isinstance(node.func, ast.Attribute) and node.func.attr == "set"
                and node.args and len(node.args) >= 2):
            first_arg = node.args[0]
            if isinstance(first_arg, ast.Constant) and isinstance(first_arg.value, str):
                return first_arg.value.startswith("spark.")
        return False

    @staticmethod
    def _get_call_attr(node):
        if isinstance(node.func, ast.Attribute):
            return node.func.attr
        if isinstance(node.func, ast.Name):
            return node.func.id
        return None


def safe_parse_ast(source_code: str):
    try:
        tree = ast.parse(source_code)
        return tree, None
    except SyntaxError as e:
        return None, str(e)


def get_call_int_arg(node, index=0):
    """Extract integer argument from a function call at given index."""
    if node.args and len(node.args) > index and isinstance(node.args[index], ast.Constant):
        val = node.args[index].value
        if isinstance(val, int):
            return val
    return None


# =============================================================================
# SQL Utilities
# =============================================================================

def _normalize_sql(sql: str) -> str:
    return re.sub(r'\s+', ' ', sql.upper().strip())


def _generate_optimized_sql(original_sql: str, finding: dict) -> str:
    """Apply the fix described in a finding to the original SQL and return the optimized version.

    Used by recommend_fix() to include the actual optimized SQL query text.
    Returns empty string if the fix cannot be applied programmatically.
    """
    if not original_sql:
        return ""
    optimized = original_sql
    action = finding.get("_fix_action", "")

    if action == "fix_non_sargable":
        original = finding.get("original", "")
        replacement = finding.get("replacement", "")
        if original and replacement:
            optimized = re.sub(re.escape(original), replacement, optimized, flags=re.IGNORECASE)

    elif action == "fix_duplicate_in":
        original_clause = finding.get("original_clause", "")
        fixed_clause = finding.get("fixed_clause", "")
        if original_clause and fixed_clause:
            optimized = optimized.replace(original_clause, fixed_clause)

    elif action == "add_broadcast":
        aliases = finding.get("broadcast_aliases", "")
        if aliases:
            optimized = re.sub(
                r'(?i)(SELECT\s+)',
                r'\1/*+ BROADCAST(' + aliases + ') */ ',
                optimized, count=1)

    elif action == "remove_distinct":
        optimized = re.sub(r'(?i)\bSELECT\s+DISTINCT\b', 'SELECT', optimized, count=1)

    elif action == "replace_not_in":
        # Provide a template showing NOT EXISTS replacement
        pass  # Cannot safely auto-generate without schema context

    elif action == "move_having_to_where":
        # Cannot safely auto-generate without knowing full query structure
        pass

    if optimized == original_sql:
        return ""
    return optimized


def detect_select_star(sql: str) -> bool:
    return bool(re.search(r'SELECT\s+\*', _normalize_sql(sql)))


def detect_correlated_subquery(sql: str) -> bool:
    normalized = _normalize_sql(sql)
    outer_alias_pattern = re.findall(r'FROM\s+(\w+)\s+(\w+)', normalized)
    aliases = {alias for _, alias in outer_alias_pattern}
    subquery_match = re.findall(r'\(\s*SELECT\s+.*?WHERE\s+.*?\)', normalized, re.DOTALL)
    for sq in subquery_match:
        for alias in aliases:
            if re.search(rf'{alias}\.\w+', sq):
                return True
    return False


def detect_missing_join_predicate(sql: str) -> bool:
    """Detect JOINs without ON clause (potential Cartesian product)."""
    normalized = _normalize_sql(sql)
    join_count = len(re.findall(r'\bJOIN\b', normalized))
    on_count = len(re.findall(r'\bON\b', normalized))
    cross_join = bool(re.search(r'CROSS\s+JOIN', normalized))
    comma_join = bool(re.search(r'FROM\s+\w+\s*,\s*\w+', normalized))
    if cross_join or comma_join:
        return True
    return join_count > 0 and on_count < join_count


def detect_cartesian_join(sql: str) -> bool:
    """Detect explicit CROSS JOINs or comma-separated FROM tables without WHERE."""
    normalized = _normalize_sql(sql)
    if re.search(r'CROSS\s+JOIN', normalized):
        return True
    tables_in_from = re.findall(r'FROM\s+([\w\s,]+?)(?:\s+WHERE|\s+JOIN|\s+GROUP|\s+ORDER|\s+LIMIT|\s*$)', normalized)
    for tables_str in tables_in_from:
        if ',' in tables_str and 'WHERE' not in normalized:
            return True
    return False


def detect_order_by_without_limit(sql: str) -> bool:
    """ORDER BY on large datasets without LIMIT causes full sort."""
    normalized = _normalize_sql(sql)
    has_order = bool(re.search(r'ORDER\s+BY', normalized))
    has_limit = bool(re.search(r'LIMIT\s+\d+', normalized))
    is_subquery_order = bool(re.search(r'OVER\s*\(.*ORDER\s+BY', normalized))
    if has_order and not has_limit and not is_subquery_order:
        return True
    return False


def detect_union_without_all(sql: str) -> bool:
    """UNION (without ALL) causes unnecessary DISTINCT operation."""
    normalized = _normalize_sql(sql)
    return bool(re.search(r'\bUNION\b(?!\s+ALL)', normalized))


def detect_deep_nesting(sql: str, max_depth: int = 3) -> int:
    """Count subquery nesting depth by counting SELECT keywords in nested parens."""
    depth = 0
    max_found = 0
    for char in sql.upper():
        if char == '(':
            depth += 1
            max_found = max(max_found, depth)
        elif char == ')':
            depth -= 1
    select_count = len(re.findall(r'\bSELECT\b', sql.upper()))
    return select_count - 1 if select_count > 1 else 0


def detect_unbounded_aggregation(sql: str) -> bool:
    """GROUP BY without WHERE on large tables -- full table scan aggregation."""
    normalized = _normalize_sql(sql)
    has_group_by = bool(re.search(r'GROUP\s+BY', normalized))
    has_where = bool(re.search(r'WHERE', normalized))
    has_join = bool(re.search(r'JOIN', normalized))
    return has_group_by and not has_where and has_join


def detect_non_sargable_functions(sql: str) -> list[dict]:
    """Extract specific function-wrapped predicates from WHERE clause for targeted fixes."""
    normalized = re.sub(r'\s+', ' ', sql.strip())
    where_match = re.search(
        r'\bWHERE\b\s+(.*?)(?:\s+GROUP\s+BY|\s+ORDER\s+BY|\s+HAVING|\s+LIMIT|\s+UNION|$)',
        normalized, re.IGNORECASE | re.DOTALL)
    if not where_match:
        return []
    where_clause = where_match.group(1)
    results = []
    # year(col) >= YYYY  ->  col >= 'YYYY-01-01'
    for m in re.finditer(r'\bYEAR\s*\(\s*([\w.]+)\s*\)\s*(>=?|<=?|=|!=|<>)\s*(\d{4})', where_clause, re.IGNORECASE):
        col, op, yr = m.group(1), m.group(2), m.group(3)
        if op == '>=':
            fix = f"{col} >= '{yr}-01-01'"
        elif op == '>':
            fix = f"{col} >= '{int(yr)+1}-01-01'"
        elif op == '=':
            fix = f"{col} >= '{yr}-01-01' AND {col} < '{int(yr)+1}-01-01'"
        elif op == '<=':
            fix = f"{col} < '{int(yr)+1}-01-01'"
        elif op == '<':
            fix = f"{col} < '{yr}-01-01'"
        else:
            fix = None
        if fix:
            results.append({"original": m.group(0), "replacement": fix, "function": "YEAR"})
    # month(col) = N  ->  range-based predicate
    for m in re.finditer(r'\bMONTH\s*\(\s*([\w.]+)\s*\)\s*=\s*(\d{1,2})', where_clause, re.IGNORECASE):
        results.append({"original": m.group(0), "replacement": None, "function": "MONTH",
                         "advisory": f"MONTH({m.group(1)}) prevents pushdown -- consider range predicate or computed column"})
    # upper(col) = 'VALUE' / lower(col) = 'value'  ->  col = 'VALUE'
    for m in re.finditer(r'\b(UPPER|LOWER)\s*\(\s*([\w.]+)\s*\)\s*=\s*\'([^\']*)\'', where_clause, re.IGNORECASE):
        func, col, val = m.group(1).upper(), m.group(2), m.group(3)
        fix = f"{col} = '{val}'"
        results.append({"original": m.group(0), "replacement": fix, "function": func})
    # cast(col as type) = val  ->  advisory
    for m in re.finditer(r'\bCAST\s*\(\s*([\w.]+)\s+AS\s+\w+\s*\)', where_clause, re.IGNORECASE):
        results.append({"original": m.group(0), "replacement": None, "function": "CAST",
                         "advisory": f"CAST({m.group(1)} AS ...) prevents pushdown -- store data in target type or compare without cast"})
    # to_date(col, ...) comparisons
    for m in re.finditer(r'\bTO_DATE\s*\(\s*([\w.]+)', where_clause, re.IGNORECASE):
        results.append({"original": m.group(0), "replacement": None, "function": "TO_DATE",
                         "advisory": f"TO_DATE({m.group(1)}) prevents pushdown -- compare raw column with string date if format is sortable"})
    # coalesce/nvl(col, default) = val  ->  advisory
    for m in re.finditer(r'\b(COALESCE|NVL|IFNULL|ISNULL)\s*\(\s*([\w.]+)', where_clause, re.IGNORECASE):
        results.append({"original": m.group(0), "replacement": None, "function": m.group(1).upper(),
                         "advisory": f"{m.group(1).upper()}({m.group(2)}) prevents pushdown -- use IS NULL/IS NOT NULL with separate predicates"})
    # trim(col) = 'val'
    for m in re.finditer(r'\b(TRIM|LTRIM|RTRIM)\s*\(\s*([\w.]+)\s*\)\s*=\s*\'([^\']*)\'', where_clause, re.IGNORECASE):
        func, col, val = m.group(1).upper(), m.group(2), m.group(3)
        results.append({"original": m.group(0), "replacement": f"{col} = '{val}'", "function": func,
                         "advisory": f"{func}({col}) prevents pushdown -- clean data at source or use LIKE pattern"})
    return results


def detect_duplicate_in_values(sql: str) -> list[dict]:
    """Detect duplicate values in IN (...) clauses."""
    results = []
    for m in re.finditer(r'(\w+(?:\.\w+)?)\s+IN\s*\(([^)]+)\)', sql, re.IGNORECASE):
        col = m.group(1)
        values_str = m.group(2)
        # Parse individual values (handle quoted strings and numbers)
        values = [v.strip().strip("'\"") for v in values_str.split(',')]
        seen = set()
        dupes = set()
        for v in values:
            norm = v.upper()
            if norm in seen:
                dupes.add(v)
            seen.add(norm)
        if dupes:
            unique_vals = []
            seen_unique = set()
            for v in values:
                if v.upper() not in seen_unique:
                    unique_vals.append(v)
                    seen_unique.add(v.upper())
            results.append({
                "column": col, "duplicates": list(dupes),
                "original_clause": m.group(0),
                "fixed_clause": f"{col} IN ({', '.join(repr(v) if not v.replace('.','').replace('-','').isdigit() else v for v in unique_vals)})",
            })
    return results


def detect_distinct_on_multi_join(sql: str) -> bool:
    """Detect SELECT DISTINCT on queries with multiple JOINs."""
    normalized = _normalize_sql(sql)
    has_distinct = bool(re.search(r'SELECT\s+DISTINCT', normalized))
    join_count = len(re.findall(r'\bJOIN\b', normalized))
    return has_distinct and join_count >= 2


def detect_not_in_subquery(sql: str) -> bool:
    """Detect NOT IN (subquery) which is slow and NULL-unsafe."""
    normalized = _normalize_sql(sql)
    return bool(re.search(r'NOT\s+IN\s*\(\s*SELECT', normalized))


def detect_having_without_aggregation(sql: str) -> list[str]:
    """Detect HAVING conditions that could be in WHERE (no aggregate function)."""
    normalized = re.sub(r'\s+', ' ', sql.strip())
    having_match = re.search(r'\bHAVING\b\s+(.*?)(?:\s+ORDER\s+BY|\s+LIMIT|\s+UNION|$)',
                             normalized, re.IGNORECASE | re.DOTALL)
    if not having_match:
        return []
    having_clause = having_match.group(1)
    # Split on AND/OR to get individual conditions
    conditions = re.split(r'\s+(?:AND|OR)\s+', having_clause, flags=re.IGNORECASE)
    non_agg = []
    agg_funcs = r'\b(?:COUNT|SUM|AVG|MIN|MAX|COLLECT_LIST|COLLECT_SET|STDDEV|VARIANCE)\s*\('
    for cond in conditions:
        if not re.search(agg_funcs, cond, re.IGNORECASE):
            non_agg.append(cond.strip())
    return non_agg


def detect_implicit_type_coercion(sql: str) -> list[dict]:
    """Detect implicit type coercion patterns that prevent pushdown."""
    results = []
    normalized = re.sub(r'\s+', ' ', sql.strip())
    # String column compared to number: col = 123 (when col is likely string based on naming)
    # Numeric column compared to string: numeric_col = '123'
    # These cause implicit CAST which prevents pushdown
    # Pattern: quoted value compared with = to a column ending in _id, _cd, _num
    for m in re.finditer(r'(\w+(?:_id|_cd|_num|_code|_no|_number))\s*=\s*(\d+)\b', normalized, re.IGNORECASE):
        results.append({"column": m.group(1), "value": m.group(2), "issue": "numeric_literal_for_likely_string_column"})
    return results


def detect_like_leading_wildcard(sql: str) -> bool:
    """LIKE '%value' prevents index usage."""
    normalized = _normalize_sql(sql)
    return bool(re.search(r"LIKE\s+'%", normalized))


def detect_non_sargable_where(sql: str) -> bool:
    """Functions on columns in WHERE clause prevent predicate pushdown."""
    normalized = _normalize_sql(sql)
    # Extract the WHERE clause (everything between WHERE and GROUP/ORDER/HAVING/LIMIT/UNION/end)
    where_match = re.search(
        r'\bWHERE\b\s+(.*?)(?:\s+GROUP\s+BY|\s+ORDER\s+BY|\s+HAVING|\s+LIMIT|\s+UNION|$)',
        normalized, re.DOTALL)
    if not where_match:
        return False
    where_clause = where_match.group(1)
    # Check for functions wrapping column references anywhere in the WHERE clause
    func_pattern = (
        r'\b(?:UPPER|LOWER|TRIM|LTRIM|RTRIM|CAST|COALESCE|NVL|NVL2|IFNULL|ISNULL|'
        r'SUBSTR|SUBSTRING|LEFT|RIGHT|CONCAT|REPLACE|TRANSLATE|'
        r'YEAR|MONTH|DAY|DAYOFWEEK|DAYOFYEAR|HOUR|MINUTE|SECOND|QUARTER|WEEKOFYEAR|'
        r'DATE|TO_DATE|DATE_FORMAT|TO_TIMESTAMP|FROM_UNIXTIME|UNIX_TIMESTAMP|'
        r'ABS|CEIL|CEILING|FLOOR|ROUND|MOD|SIGN|'
        r'LENGTH|CHAR_LENGTH|CHARACTER_LENGTH|'
        r'DECODE|REGEXP_REPLACE|REGEXP_EXTRACT)\s*\('
    )
    return bool(re.search(func_pattern, where_clause))


# =============================================================================
# Log Analysis Utilities
# =============================================================================

LOG_TS_PATTERN = re.compile(r'(\d{4}-\d{2}-\d{2}\s+\d{2}:\d{2}:\d{2})')

OOM_PATTERNS = [
    re.compile(r'java\.lang\.OutOfMemoryError', re.IGNORECASE),
    re.compile(r'Container killed by YARN for exceeding memory', re.IGNORECASE),
    re.compile(r'ExecutorLostFailure.*OOM', re.IGNORECASE),
    re.compile(r'insufficient memory', re.IGNORECASE),
    re.compile(r'MemoryError', re.IGNORECASE),
]

GC_OVERHEAD_PATTERNS = [
    re.compile(r'GC overhead limit exceeded', re.IGNORECASE),
    re.compile(r'Executor.*GC time.*exceeded', re.IGNORECASE),
    re.compile(r'excessive GC', re.IGNORECASE),
]

SHUFFLE_SPILL_PATTERNS = [
    re.compile(r'Spill.*disk', re.IGNORECASE),
    re.compile(r'ExternalSorter.*spilling', re.IGNORECASE),
    re.compile(r'shuffle.*spill', re.IGNORECASE),
    re.compile(r'bytes spilled', re.IGNORECASE),
]

DATA_SKEW_PATTERNS = [
    re.compile(r'skew', re.IGNORECASE),
    re.compile(r'Task.*took significantly longer', re.IGNORECASE),
    re.compile(r'speculative.*execution', re.IGNORECASE),
    re.compile(r'straggler', re.IGNORECASE),
]

TIMEOUT_PATTERNS = [
    re.compile(r'TimeoutException', re.IGNORECASE),
    re.compile(r'Connection.*timed?\s*out', re.IGNORECASE),
    re.compile(r'Read timed out', re.IGNORECASE),
    re.compile(r'Socket timeout', re.IGNORECASE),
]

DISK_SPACE_PATTERNS = [
    re.compile(r'No space left on device', re.IGNORECASE),
    re.compile(r'disk.*full', re.IGNORECASE),
]

DRIVER_OOM_PATTERNS = [
    re.compile(r'driver.*OutOfMemoryError', re.IGNORECASE),
    re.compile(r'collect.*caused.*OOM', re.IGNORECASE),
]

# --- Common Job Failure Patterns ---

DB_CONNECTION_ERROR_PATTERNS = [
    re.compile(r'java\.sql\.SQLException', re.IGNORECASE),
    re.compile(r'Communications link failure', re.IGNORECASE),
    re.compile(r'Unable to connect to database', re.IGNORECASE),
    re.compile(r'Connection refused', re.IGNORECASE),
    re.compile(r'could not connect to server', re.IGNORECASE),
    re.compile(r'No suitable driver found', re.IGNORECASE),
    re.compile(r'Access denied for user', re.IGNORECASE),
    re.compile(r'authentication failed', re.IGNORECASE),
    re.compile(r'Login failed for user', re.IGNORECASE),
    re.compile(r'ORA-\d{5}', re.IGNORECASE),
    re.compile(r'FATAL:\s+password authentication failed', re.IGNORECASE),
    re.compile(r'connection.*reset', re.IGNORECASE),
    re.compile(r'Too many connections', re.IGNORECASE),
    re.compile(r'max_connections', re.IGNORECASE),
    re.compile(r'Connection pool exhausted', re.IGNORECASE),
]

BAD_S3_PATH_PATTERNS = [
    re.compile(r'AmazonS3Exception', re.IGNORECASE),
    re.compile(r'NoSuchBucket', re.IGNORECASE),
    re.compile(r'NoSuchKey', re.IGNORECASE),
    re.compile(r'The specified bucket does not exist', re.IGNORECASE),
    re.compile(r'The specified key does not exist', re.IGNORECASE),
    re.compile(r'Access Denied.*S3', re.IGNORECASE),
    re.compile(r'S3.*Access Denied', re.IGNORECASE),
    re.compile(r'Invalid S3 path', re.IGNORECASE),
    re.compile(r'Path does not exist.*s3', re.IGNORECASE),
    re.compile(r's3://[^\s]+.*not found', re.IGNORECASE),
    re.compile(r'Unable to.*s3.*path', re.IGNORECASE),
    re.compile(r'AnalysisException.*Path does not exist', re.IGNORECASE),
]

BROKEN_PIPE_PATTERNS = [
    re.compile(r'BrokenPipeError', re.IGNORECASE),
    re.compile(r'Broken pipe', re.IGNORECASE),
    re.compile(r'Connection reset by peer', re.IGNORECASE),
    re.compile(r'Connection was closed', re.IGNORECASE),
    re.compile(r'Stream closed', re.IGNORECASE),
    re.compile(r'Premature end of.*stream', re.IGNORECASE),
    re.compile(r'EOFException', re.IGNORECASE),
    re.compile(r'ClosedChannelException', re.IGNORECASE),
    re.compile(r'Remote host closed connection', re.IGNORECASE),
]

VALUE_TOO_LONG_PATTERNS = [
    re.compile(r'value too long for.*type', re.IGNORECASE),
    re.compile(r'String or binary data would be truncated', re.IGNORECASE),
    re.compile(r'ORA-12899.*value too large', re.IGNORECASE),
    re.compile(r'Data too long for column', re.IGNORECASE),
    re.compile(r'string data.*truncated', re.IGNORECASE),
    re.compile(r'ERROR.*value too long', re.IGNORECASE),
    re.compile(r'field.*exceeds.*maximum.*length', re.IGNORECASE),
    re.compile(r'character varying.*too long', re.IGNORECASE),
    re.compile(r'DataException.*truncat', re.IGNORECASE),
]

DUPLICATE_CONSTRAINT_PATTERNS = [
    re.compile(r'duplicate key.*violates unique constraint', re.IGNORECASE),
    re.compile(r'Duplicate entry.*for key', re.IGNORECASE),
    re.compile(r'unique.*constraint.*violated', re.IGNORECASE),
    re.compile(r'IntegrityError.*duplicate', re.IGNORECASE),
    re.compile(r'ORA-00001.*unique constraint', re.IGNORECASE),
    re.compile(r'Cannot insert duplicate key', re.IGNORECASE),
    re.compile(r'PRIMARY KEY constraint.*Violation', re.IGNORECASE),
    re.compile(r'UNIQUE constraint failed', re.IGNORECASE),
    re.compile(r'duplicate.*primary.*key', re.IGNORECASE),
]

PERMISSION_DENIED_PATTERNS = [
    re.compile(r'AccessDeniedException', re.IGNORECASE),
    re.compile(r'Access Denied', re.IGNORECASE),
    re.compile(r'not authorized to perform', re.IGNORECASE),
    re.compile(r'Permission denied', re.IGNORECASE),
    re.compile(r'Forbidden', re.IGNORECASE),
    re.compile(r'IAM.*policy.*deny', re.IGNORECASE),
    re.compile(r'insufficient permissions', re.IGNORECASE),
    re.compile(r'UnauthorizedAccess', re.IGNORECASE),
    re.compile(r'is not authorized', re.IGNORECASE),
]

SCHEMA_MISMATCH_PATTERNS = [
    re.compile(r'AnalysisException.*cannot resolve', re.IGNORECASE),
    re.compile(r'Column.*not found', re.IGNORECASE),
    re.compile(r'Schema mismatch', re.IGNORECASE),
    re.compile(r'cannot cast.*to', re.IGNORECASE),
    re.compile(r'data type mismatch', re.IGNORECASE),
    re.compile(r'invalid input syntax for type', re.IGNORECASE),
    re.compile(r'ClassCastException', re.IGNORECASE),
    re.compile(r'NumberFormatException', re.IGNORECASE),
    re.compile(r'incompatible.*schema', re.IGNORECASE),
    re.compile(r'does not match.*expected.*schema', re.IGNORECASE),
]

NULL_CONSTRAINT_PATTERNS = [
    re.compile(r'NOT NULL constraint failed', re.IGNORECASE),
    re.compile(r'cannot be null', re.IGNORECASE),
    re.compile(r'null value.*violates not-null', re.IGNORECASE),
    re.compile(r'Column.*is not nullable', re.IGNORECASE),
    re.compile(r'NullPointerException', re.IGNORECASE),
    re.compile(r'ORA-01400.*cannot insert NULL', re.IGNORECASE),
    re.compile(r'IntegrityError.*null', re.IGNORECASE),
]

SERIALIZATION_ERROR_PATTERNS = [
    re.compile(r'SerializationException', re.IGNORECASE),
    re.compile(r'NotSerializableException', re.IGNORECASE),
    re.compile(r'Task not serializable', re.IGNORECASE),
    re.compile(r'cannot serialize', re.IGNORECASE),
    re.compile(r'Serialization stack', re.IGNORECASE),
    re.compile(r'PicklingError', re.IGNORECASE),
    re.compile(r'cannot pickle', re.IGNORECASE),
]

RESOURCE_LIMIT_PATTERNS = [
    re.compile(r'MaxResultsExceededException', re.IGNORECASE),
    re.compile(r'Maximum.*concurrent.*exceeded', re.IGNORECASE),
    re.compile(r'Rate exceeded', re.IGNORECASE),
    re.compile(r'ThrottlingException', re.IGNORECASE),
    re.compile(r'TooManyRequestsException', re.IGNORECASE),
    re.compile(r'Slow down', re.IGNORECASE),
    re.compile(r'Service Unavailable', re.IGNORECASE),
    re.compile(r'limit.*exceeded', re.IGNORECASE),
]

FILE_FORMAT_ERROR_PATTERNS = [
    re.compile(r'not a Parquet file', re.IGNORECASE),
    re.compile(r'Could not read footer', re.IGNORECASE),
    re.compile(r'Malformed.*CSV', re.IGNORECASE),
    re.compile(r'CSV.*parse.*error', re.IGNORECASE),
    re.compile(r'JSON.*parse.*error', re.IGNORECASE),
    re.compile(r'Unexpected.*end.*input', re.IGNORECASE),
    re.compile(r'corrupt.*file', re.IGNORECASE),
    re.compile(r'Unable to infer schema', re.IGNORECASE),
    re.compile(r'MalformedRecordException', re.IGNORECASE),
]


def parse_log_timestamps(log_text: str) -> list[datetime.datetime]:
    timestamps = []
    for match in LOG_TS_PATTERN.finditer(log_text):
        try:
            ts = datetime.datetime.strptime(match.group(1), "%Y-%m-%d %H:%M:%S")
            timestamps.append(ts)
        except ValueError:
            continue
    return timestamps


def find_long_running_stages(log_text: str, threshold_minutes: int = 5) -> list[dict]:
    timestamps = parse_log_timestamps(log_text)
    log_lines = log_text.splitlines()

    # Build a mapping: timestamp -> log line text (message portion)
    ts_to_line: dict[str, str] = {}
    for line in log_lines:
        m = LOG_TS_PATTERN.search(line)
        if m:
            ts_to_line[m.group(1)] = line.strip()

    gaps = []
    for i in range(1, len(timestamps)):
        delta = (timestamps[i] - timestamps[i - 1]).total_seconds() / 60.0
        if delta >= threshold_minutes:
            # The last log line printed before the gap = breadcrumb
            start_ts_str = timestamps[i - 1].strftime("%Y-%m-%d %H:%M:%S")
            breadcrumb_line = ts_to_line.get(start_ts_str, "")
            # Strip the timestamp prefix to get just the message
            breadcrumb_msg = re.sub(
                r'^\d{4}-\d{2}-\d{2}\s+\d{2}:\d{2}:\d{2}\s+\w+\s+(?:\[.*?\]\s+)?'
                r'(?:\d{4}-\d{2}-\d{2}\s+\d{2}:\d{2}:\d{2}\s+)?',
                '', breadcrumb_line
            ).strip()
            gaps.append({
                "start": timestamps[i - 1].isoformat(),
                "end": timestamps[i].isoformat(),
                "duration_minutes": round(delta, 2),
                "breadcrumb_line": breadcrumb_line,
                "breadcrumb_msg": breadcrumb_msg,
            })
    return gaps


def detect_log_patterns(log_text: str, patterns: list) -> list[str]:
    """Return list of matched log lines for a given set of patterns."""
    matches = []
    for line in log_text.splitlines():
        for p in patterns:
            if p.search(line):
                matches.append(line.strip())
                break
    return matches


def extract_row_counts_from_log(log_text: str) -> list[int]:
    """Extract numeric row counts from log lines with various formats.

    Handles: 'row count: 123', 'rows : 1,280,000', 'Output Records : 950,000',
    '1280000 rows', 'Total: 5000 records', etc.
    """
    counts = []
    patterns = [
        # "row count: 123" / "record count: 123" / "count: 123"
        r'(?:row\s*count|record\s*count|count)[:\s]+(\d[\d,]*)',
        # "rows : 1,280,000" / "rows: 123" / "records : 500"
        r'(?:rows|records)\s*:\s*(\d[\d,]*)',
        # "Output Records : 950,000" / "Input Records: 100"
        r'(?:Output|Input|Total|Source|Target)\s+(?:Records?|Rows?)\s*:\s*(\d[\d,]*)',
        # "policy_master rows : 1,280,000" (table_name rows : N)
        r'\w+\s+rows?\s*:\s*(\d[\d,]*)',
        # "Loaded 1280000 rows" / "Read 500000 records" / "Written 100000 rows"
        r'(?:Loaded|Read|Written|Processed|Inserted|Fetched)\s+(\d[\d,]*)\s+(?:rows?|records?)',
        # "1280000 rows loaded" / "500 records processed"
        r'(\d[\d,]*)\s+(?:rows?|records?)\s+(?:loaded|read|written|processed|inserted|fetched)',
    ]
    for pattern in patterns:
        for match in re.finditer(pattern, log_text, re.IGNORECASE):
            val = match.group(1).replace(',', '')
            try:
                counts.append(int(val))
            except ValueError:
                pass
    return counts


# =============================================================================
# Log-to-Code Correlation Engine
# =============================================================================

# Operation patterns detected from log breadcrumb messages
# Each tuple: (operation_id, regex_pattern, description)
BREADCRUMB_OPERATION_PATTERNS = [
    # Count operations
    ("count_op", re.compile(
        r'(?:count(?:ing)?|row\s*count|record\s*count|starting\s+count)\s+(?:operation|for|of)?',
        re.IGNORECASE), "count() operation on large dataset"),
    # Data amplification / explode
    ("data_amplification", re.compile(
        r'(?:amplif|explod|expand|repeat|cross\s*join|cartesian)',
        re.IGNORECASE), "data amplification (explode/array_repeat/cross join)"),
    # Shuffle / repartition
    ("shuffle_op", re.compile(
        r'(?:shuffle|repartition|partition|redistribute)',
        re.IGNORECASE), "shuffle/repartition operation"),
    # Query execution
    ("query_exec", re.compile(
        r'(?:query|sql|transformation|executing.*(?:query|sql)|query\s+(?:still\s+)?running)',
        re.IGNORECASE), "SQL/transformation query execution"),
    # Aggregation
    ("aggregation", re.compile(
        r'(?:aggregat|group\s*by|rollup|cube|pivot|summariz)',
        re.IGNORECASE), "aggregation on large dataset"),
    # Join operations
    ("join_op", re.compile(
        r'(?:join|merge|lookup|enrich)',
        re.IGNORECASE), "join operation"),
    # Write / output
    ("write_op", re.compile(
        r'(?:writ|output|upload|sav|export|load.*target|insert)',
        re.IGNORECASE), "write/output operation"),
    # Load / read
    ("load_op", re.compile(
        r'(?:load|read|fetch|ingest|import|extract|source)',
        re.IGNORECASE), "data loading/reading"),
    # Collect / toPandas
    ("collect_op", re.compile(
        r'(?:collect|toPandas|to_pandas|bring.*driver)',
        re.IGNORECASE), "collect/toPandas bringing data to driver"),
]


def correlate_breadcrumb_to_source(breadcrumb_msg: str, py_source: str) -> dict:
    """Trace a log breadcrumb message back to the Python source code.

    Returns dict with:
      - source_line: the line number in source that printed the message (or -1)
      - next_code_lines: the code lines following the print/log statement
      - operation: the identified operation type from breadcrumb + code context
    """
    result = {"source_line": -1, "next_code_lines": [], "operation": None,
              "operation_desc": "", "code_context": ""}
    if not breadcrumb_msg or not py_source:
        return result

    # Step 1: Try to find the print/logger statement in source that produced this message
    source_lines = py_source.splitlines()
    best_match_line = -1
    best_match_score = 0

    # Extract key words from breadcrumb (strip dynamic values like numbers, timestamps)
    msg_cleaned = re.sub(r'\d+', '', breadcrumb_msg).strip().lower()
    msg_words = set(re.findall(r'[a-z_]{3,}', msg_cleaned))

    for idx, sline in enumerate(source_lines):
        stripped = sline.strip()
        # Look for print() or logger/logging calls
        if not re.match(r'(?:print\s*\(|logger\.|logging\.|log\.)', stripped):
            continue
        # Extract the string content from the print/log call
        str_content = re.findall(r'["\']([^"\']+)["\']', stripped)
        if not str_content:
            # f-string: extract text between quotes
            str_content = re.findall(r'f["\']([^"\']+)["\']', stripped)
        line_text = ' '.join(str_content).lower()
        line_words = set(re.findall(r'[a-z_]{3,}', line_text))
        # Score: number of overlapping words
        if msg_words and line_words:
            overlap = len(msg_words & line_words)
            if overlap > best_match_score:
                best_match_score = overlap
                best_match_line = idx

    result["source_line"] = best_match_line + 1 if best_match_line >= 0 else -1

    # Step 2: Collect code lines after the matched print statement (next 10 non-empty lines)
    start = best_match_line + 1 if best_match_line >= 0 else 0
    code_after = []
    for idx in range(start, min(start + 15, len(source_lines))):
        line = source_lines[idx].strip()
        if line and not line.startswith('#'):
            code_after.append(line)
        if len(code_after) >= 10:
            break
    result["next_code_lines"] = code_after
    result["code_context"] = '\n'.join(code_after)

    # Step 3: Identify operation type from BOTH the breadcrumb message and the code context
    combined_text = breadcrumb_msg + ' ' + result["code_context"]
    for op_id, pattern, desc in BREADCRUMB_OPERATION_PATTERNS:
        if pattern.search(combined_text):
            result["operation"] = op_id
            result["operation_desc"] = desc
            break

    return result


# Mapping from identified slow operation -> actionable fix target
OPERATION_FIX_MAP = {
    "count_op": {
        "artifact": "python", "action": "remove_unnecessary_action",
        "recommendation": "Remove unnecessary count() that triggers full dataset evaluation",
        "code_pattern": "count()",
    },
    "data_amplification": {
        "artifact": "python", "action": "replace_data_amplification",
        "recommendation": "Replace array_repeat + explode with direct withColumn assignment",
        "code_pattern": "array_repeat/explode",
    },
    "shuffle_op": {
        "artifact": "yaml", "action": "scale_for_shuffle",
        "recommendation": "Increase workers/memory for heavy shuffle, or reduce partition count",
    },
    "query_exec": {
        "artifact": "json", "action": "optimize_slow_query",
        "recommendation": "Optimize SQL query -- add filters, reduce SELECT *, add LIMIT, check JOINs",
    },
    "aggregation": {
        "artifact": "yaml", "action": "scale_for_aggregation",
        "recommendation": "Scale workers for large aggregation, or add pre-filtering to reduce data volume",
    },
    "join_op": {
        "artifact": "yaml", "action": "scale_for_join",
        "recommendation": "Scale workers for join-heavy workload, or broadcast smaller tables",
    },
    "write_op": {
        "artifact": "python", "action": "optimize_write",
        "recommendation": "Check for coalesce(1) bottleneck, or increase parallelism for writes",
        "code_pattern": "coalesce/repartition",
    },
    "load_op": {
        "artifact": "json", "action": "optimize_source_query",
        "recommendation": "Add partition pruning or push-down predicates to source query",
    },
    "collect_op": {
        "artifact": "python", "action": "replace_collect",
        "recommendation": "Replace collect()/toPandas() with Spark-native operations or limit() first",
        "code_pattern": "collect()/toPandas()",
    },
}


# =============================================================================
# Worker Scaling Engine
# =============================================================================

def recommend_worker_config(current_type: str, current_count: int,
                            total_data_rows: int = 0,
                            has_joins: bool = False,
                            has_window_functions: bool = False,
                            has_oom: bool = False,
                            has_shuffle_spill: bool = False,
                            has_gc_overhead: bool = False,
                            execution_duration: int = 0,
                            threshold: int = 0) -> dict:
    """
    Deterministic worker scaling recommendation based on multiple signals.

    Returns dict with: recommended_type, recommended_count, reasons
    """
    reasons = []
    rec_type = current_type
    rec_count = current_count

    type_index = GLUE_WORKER_TYPES.index(current_type) if current_type in GLUE_WORKER_TYPES else 1

    # --- Signal 1: Data volume based scaling ---
    if total_data_rows > 0:
        if total_data_rows > 500_000_000:  # 500M+ rows
            min_workers = 20
            min_type_idx = 3  # G.4X
            reasons.append(f"Data volume ({total_data_rows:,} rows) requires at least {min_workers} workers with G.4X+")
        elif total_data_rows > 100_000_000:  # 100M+ rows
            min_workers = 10
            min_type_idx = 2  # G.2X
            reasons.append(f"Data volume ({total_data_rows:,} rows) requires at least {min_workers} workers with G.2X+")
        elif total_data_rows > 10_000_000:  # 10M+ rows
            min_workers = 6
            min_type_idx = 1  # G.1X
            reasons.append(f"Data volume ({total_data_rows:,} rows) requires at least {min_workers} workers")
        elif total_data_rows > 1_000_000:  # 1M+ rows
            min_workers = 4
            min_type_idx = 1
            reasons.append(f"Data volume ({total_data_rows:,} rows) requires at least {min_workers} workers")
        else:
            min_workers = 2
            min_type_idx = 0

        rec_count = max(rec_count, min_workers)
        type_index = max(type_index, min_type_idx)

    # --- Signal 2: Complex operations need more memory per worker ---
    if has_joins and has_window_functions:
        type_index = max(type_index, 2)  # G.2X minimum
        rec_count = max(rec_count, 8)
        reasons.append("Complex JOINs + window functions require G.2X+ with more workers")
    elif has_joins:
        type_index = max(type_index, 1)  # G.1X minimum
        rec_count = max(rec_count, 6)
        reasons.append("JOIN operations require adequate worker count")

    # --- Signal 3: OOM signals need bigger worker types ---
    if has_oom:
        type_index = min(type_index + 2, len(GLUE_WORKER_TYPES) - 2)  # Jump 2 sizes
        rec_count = max(rec_count, 10)  # Absolute minimum for OOM
        reasons.append("OOM detected -- need larger worker type and more workers")

    # --- Signal 4: GC overhead needs more memory ---
    if has_gc_overhead:
        type_index = min(type_index + 1, len(GLUE_WORKER_TYPES) - 2)
        reasons.append("GC overhead detected -- need larger worker type for more memory")

    # --- Signal 5: Shuffle spill needs more workers for parallelism ---
    if has_shuffle_spill:
        rec_count = max(rec_count, 10)  # Absolute minimum for shuffle spill
        type_index = max(type_index, 2)  # G.2X for disk I/O
        reasons.append("Shuffle spill to disk detected -- need more workers and memory")

    # --- Signal 6: Execution overshoot ratio ---
    if threshold > 0 and execution_duration > 0:
        overshoot = execution_duration / threshold
        if overshoot > 3.0:
            rec_count = max(rec_count, 15)
            type_index = min(type_index + 1, len(GLUE_WORKER_TYPES) - 2)
            reasons.append(f"Execution {overshoot:.1f}x over threshold -- significant scaling needed")
        elif overshoot > 2.0:
            rec_count = max(rec_count, 10)
            reasons.append(f"Execution {overshoot:.1f}x over threshold -- scaling needed")
        elif overshoot > 1.0:
            rec_count = max(rec_count, 6)
            reasons.append(f"Execution {overshoot:.1f}x over threshold -- moderate scaling needed")

    # --- Ensure minimum of 2 workers ---
    rec_count = max(rec_count, 2)

    # --- Z.2X is for ML workloads; don't recommend it for ETL ---
    rec_type = GLUE_WORKER_TYPES[min(type_index, 4)]

    if rec_type == current_type and rec_count == current_count:
        return {"recommended_type": current_type, "recommended_count": current_count,
                "changed": False, "reasons": reasons}

    return {
        "recommended_type": rec_type,
        "recommended_count": rec_count,
        "changed": True,
        "reasons": reasons,
    }


# =============================================================================
# Concrete RCA Rule Implementations
# =============================================================================

# --- Code Quality Rules ---

@register_rule
class SyntaxErrorRule(RCARule):
    rule_id = "RCA-001"
    rule_name = "Python Syntax Error Detection"
    category = "code_quality"

    def detect(self, artifacts):
        findings = []
        py_source = artifacts.get("python_source", "")
        if not py_source:
            return findings
        _, err = safe_parse_ast(py_source)
        if err:
            findings.append({
                "rule_id": self.rule_id, "description": f"Python syntax error: {err}",
                "artifact": "python", "error": err,
            })
        return findings

    def classify_severity(self, finding):
        return "critical"

    def recommend_fix(self, finding):
        return f"Fix syntax error: {finding['error']}"

    def transformation_mapping(self, finding):
        return {"artifact_type": "python", "action": "fix_syntax_error", "details": finding["error"]}


@register_rule
class ArtificialDelayRule(RCARule):
    rule_id = "RCA-002"
    rule_name = "Artificial Delay Detection"
    category = "code_quality"

    def detect(self, artifacts):
        findings = []
        py_source = artifacts.get("python_source", "")
        tree, _ = safe_parse_ast(py_source)
        if tree is None:
            return findings
        visitor = ASTPatternVisitor()
        visitor.visit(tree)
        for node in visitor.sleep_calls:
            for parent in ast.walk(tree):
                if isinstance(parent, (ast.While, ast.For)):
                    for child in ast.walk(parent):
                        if child is node:
                            findings.append({
                                "rule_id": self.rule_id,
                                "description": "time.sleep() inside loop adds artificial delay",
                                "artifact": "python", "line": node.lineno,
                            })
        return findings

    def classify_severity(self, finding):
        return "high"

    def recommend_fix(self, finding):
        return f"Remove time.sleep() at line {finding['line']} from processing loop"

    def transformation_mapping(self, finding):
        return {"artifact_type": "python", "action": "remove_sleep_in_loop", "line": finding["line"]}


# --- Spark Anti-Pattern Rules ---

@register_rule
class CollectAntiPatternRule(RCARule):
    rule_id = "RCA-010"
    rule_name = "Spark collect() Anti-Pattern"
    category = "spark_antipattern"

    def detect(self, artifacts):
        findings = []
        py_source = artifacts.get("python_source", "")
        tree, _ = safe_parse_ast(py_source)
        if tree is None:
            return findings
        visitor = ASTPatternVisitor()
        visitor.visit(tree)
        for node in visitor.collect_calls:
            findings.append({
                "rule_id": self.rule_id,
                "description": "collect() brings entire dataset to driver, risking OOM",
                "artifact": "python", "line": node.lineno,
            })
        return findings

    def classify_severity(self, finding):
        return "critical"

    def recommend_fix(self, finding):
        return f"Replace collect() at line {finding['line']} with first()/take(N)/limit(N)"

    def transformation_mapping(self, finding):
        return {"artifact_type": "python", "action": "replace_collect", "line": finding["line"]}


@register_rule
class UnnecessaryActionRule(RCARule):
    rule_id = "RCA-011"
    rule_name = "Unnecessary Spark Action Detection"
    category = "spark_antipattern"

    def detect(self, artifacts):
        findings = []
        py_source = artifacts.get("python_source", "")
        tree, _ = safe_parse_ast(py_source)
        if tree is None:
            return findings
        visitor = ASTPatternVisitor()
        visitor.visit(tree)
        for node in visitor.count_calls:
            if self._is_unused_action(tree, node):
                findings.append({
                    "rule_id": self.rule_id,
                    "description": "Unnecessary count() triggers full dataset evaluation",
                    "artifact": "python", "line": node.lineno, "action_type": "count",
                })
        for node in visitor.show_calls:
            findings.append({
                "rule_id": self.rule_id,
                "description": "show() in production triggers unnecessary evaluation",
                "artifact": "python", "line": node.lineno, "action_type": "show",
            })
        return findings

    @staticmethod
    def _is_unused_action(tree, count_node):
        for node in ast.walk(tree):
            if isinstance(node, ast.Assign):
                if isinstance(node.value, ast.Call) and node.value is count_node:
                    return False
        return True

    def classify_severity(self, finding):
        return "high"

    def recommend_fix(self, finding):
        return f"Remove unnecessary {finding['action_type']}() at line {finding['line']}"

    def transformation_mapping(self, finding):
        return {"artifact_type": "python", "action": "remove_unnecessary_action",
                "line": finding["line"], "action_type": finding["action_type"]}


@register_rule
class ExcessiveRepartitionRule(RCARule):
    rule_id = "RCA-012"
    rule_name = "Excessive/Unnecessary Repartition Detection"
    category = "spark_antipattern"

    def detect(self, artifacts):
        findings = []
        py_source = artifacts.get("python_source", "")
        tree, _ = safe_parse_ast(py_source)
        if tree is None:
            return findings
        visitor = ASTPatternVisitor()
        visitor.visit(tree)
        for node in visitor.repartition_calls:
            n = get_call_int_arg(node)
            if n is not None:
                if n > 500:
                    desc = f"repartition({n}) creates excessive partitions, causing costly shuffle"
                elif n < 2:
                    desc = f"repartition({n}) creates too few partitions, causing bottleneck"
                else:
                    continue  # Reasonable partition count (2-500), no action needed
                findings.append({
                    "rule_id": self.rule_id, "description": desc,
                    "artifact": "python", "line": node.lineno, "partition_count": n,
                })
        return findings

    def classify_severity(self, finding):
        n = finding.get("partition_count", 0)
        if n > 1000 or n < 2:
            return "high"
        return "medium"

    def recommend_fix(self, finding):
        return f"Remove or adjust repartition({finding['partition_count']}) at line {finding['line']}"

    def transformation_mapping(self, finding):
        return {"artifact_type": "python", "action": "remove_or_adjust_repartition",
                "line": finding["line"], "partition_count": finding["partition_count"]}


@register_rule
class DataAmplificationRule(RCARule):
    rule_id = "RCA-013"
    rule_name = "Data Amplification Anti-Pattern"
    category = "spark_antipattern"

    def detect(self, artifacts):
        findings = []
        py_source = artifacts.get("python_source", "")
        tree, _ = safe_parse_ast(py_source)
        if tree is None:
            return findings
        visitor = ASTPatternVisitor()
        visitor.visit(tree)
        if visitor.array_repeat_refs and visitor.explode_refs:
            ar_node = visitor.array_repeat_refs[0]
            # Extract the value being repeated (first arg of array_repeat)
            repeated_value = "lit(1)"
            try:
                if ar_node.args:
                    repeated_value = ast.unparse(ar_node.args[0])
            except Exception:
                pass
            # Walk the AST to find the enclosing assignment for array_repeat
            # to get the source DataFrame variable
            ar_source_df = None
            ar_col_name = None
            explode_col_name = None
            explode_target_var = None
            for node in ast.walk(tree):
                if isinstance(node, ast.Assign):
                    # Check if this assignment contains the array_repeat call
                    if self._contains_node(node, ar_node):
                        # Extract source df: var = SOURCE.withColumn(...)
                        if (isinstance(node.value, ast.Call) and
                                isinstance(node.value.func, ast.Attribute) and
                                node.value.func.attr == "withColumn"):
                            if isinstance(node.value.func.value, ast.Name):
                                ar_source_df = node.value.func.value.id
                            # Extract column name (first arg of withColumn)
                            if node.value.args:
                                try:
                                    ar_col_name = ast.literal_eval(node.value.args[0])
                                except Exception:
                                    pass
                    # Check if this assignment contains the explode call
                    for exp_node in visitor.explode_refs:
                        if self._contains_node(node, exp_node):
                            if node.targets and isinstance(node.targets[0], ast.Name):
                                explode_target_var = node.targets[0].id
                            if (isinstance(node.value, ast.Call) and
                                    isinstance(node.value.func, ast.Attribute) and
                                    node.value.func.attr == "withColumn"):
                                if node.value.args:
                                    try:
                                        explode_col_name = ast.literal_eval(node.value.args[0])
                                    except Exception:
                                        pass
            findings.append({
                "rule_id": self.rule_id,
                "description": "array_repeat + explode causes massive data amplification",
                "artifact": "python",
                "array_repeat_line": ar_node.lineno,
                "explode_line": visitor.explode_refs[0].lineno,
                "repeated_value": repeated_value,
                "ar_source_df": ar_source_df,
                "ar_col_name": ar_col_name,
                "explode_col_name": explode_col_name,
                "explode_target_var": explode_target_var,
            })
        return findings

    @staticmethod
    def _contains_node(parent, target):
        """Check if target AST node is a descendant of parent."""
        for node in ast.walk(parent):
            if node is target:
                return True
        return False

    def classify_severity(self, finding):
        return "critical"

    def recommend_fix(self, finding):
        col_name = finding.get("explode_col_name") or finding.get("ar_col_name") or "column"
        value = finding.get("repeated_value", "lit(1)")
        return (f"Replace array_repeat + explode data amplification with direct "
                f"withColumn(\"{col_name}\", {value})")

    def transformation_mapping(self, finding):
        return {"artifact_type": "python", "action": "replace_data_amplification",
                "array_repeat_line": finding["array_repeat_line"],
                "explode_line": finding["explode_line"],
                "repeated_value": finding.get("repeated_value", "lit(1)"),
                "ar_source_df": finding.get("ar_source_df"),
                "ar_col_name": finding.get("ar_col_name"),
                "explode_col_name": finding.get("explode_col_name"),
                "explode_target_var": finding.get("explode_target_var")}


@register_rule
class ToPandasAntiPatternRule(RCARule):
    rule_id = "RCA-014"
    rule_name = "toPandas() Anti-Pattern"
    category = "spark_antipattern"

    def detect(self, artifacts):
        findings = []
        py_source = artifacts.get("python_source", "")
        tree, _ = safe_parse_ast(py_source)
        if tree is None:
            return findings
        visitor = ASTPatternVisitor()
        visitor.visit(tree)
        lines = py_source.splitlines()
        for node in visitor.to_pandas_calls:
            # Skip if limit() is already applied before toPandas()
            line_text = lines[node.lineno - 1] if node.lineno <= len(lines) else ""
            if ".limit(" in line_text and ".toPandas()" in line_text:
                continue
            findings.append({
                "rule_id": self.rule_id,
                "description": "toPandas() brings entire distributed DataFrame to driver memory",
                "artifact": "python", "line": node.lineno,
            })
        return findings

    def classify_severity(self, finding):
        return "critical"

    def recommend_fix(self, finding):
        return f"Replace toPandas() at line {finding['line']} with Spark-native operations or limit() before toPandas()"

    def transformation_mapping(self, finding):
        return {"artifact_type": "python", "action": "replace_to_pandas", "line": finding["line"]}


@register_rule
class CoalesceOneRule(RCARule):
    rule_id = "RCA-015"
    rule_name = "coalesce(1) Output Bottleneck"
    category = "spark_antipattern"

    def detect(self, artifacts):
        findings = []
        py_source = artifacts.get("python_source", "")
        tree, _ = safe_parse_ast(py_source)
        if tree is None:
            return findings
        visitor = ASTPatternVisitor()
        visitor.visit(tree)
        for node in visitor.coalesce_calls:
            n = get_call_int_arg(node)
            if n is not None and n == 1:
                findings.append({
                    "rule_id": self.rule_id,
                    "description": "coalesce(1) forces all data through a single partition for write",
                    "artifact": "python", "line": node.lineno,
                })
        return findings

    def classify_severity(self, finding):
        return "high"

    def recommend_fix(self, finding):
        return f"Remove coalesce(1) at line {finding['line']} -- let Spark use natural parallelism for writes"

    def transformation_mapping(self, finding):
        return {"artifact_type": "python", "action": "remove_coalesce_one", "line": finding["line"]}


@register_rule
class CacheWithoutUnpersistRule(RCARule):
    rule_id = "RCA-016"
    rule_name = "cache()/persist() Without unpersist()"
    category = "spark_antipattern"

    def detect(self, artifacts):
        findings = []
        py_source = artifacts.get("python_source", "")
        tree, _ = safe_parse_ast(py_source)
        if tree is None:
            return findings
        visitor = ASTPatternVisitor()
        visitor.visit(tree)
        # Count unique variable names that are cached/persisted vs unpersisted
        def _var_name(node):
            """Extract variable name from a method call like df.cache()."""
            if isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute):
                val = node.func.value
                if isinstance(val, ast.Name):
                    return val.id
                if isinstance(val, ast.Attribute):
                    return ast.dump(val)
            return id(node)  # fallback: unique per node
        cached_vars = {_var_name(n) for n in visitor.cache_calls + visitor.persist_calls}
        unpersisted_vars = {_var_name(n) for n in visitor.unpersist_calls}
        cache_count = len(cached_vars)
        unpersist_count = len(cached_vars & unpersisted_vars)
        if cache_count > 0 and unpersist_count < cache_count:
            findings.append({
                "rule_id": self.rule_id,
                "description": f"{cache_count} cache/persist calls but only {unpersist_count} unpersist -- memory leak risk",
                "artifact": "python",
                "cache_count": cache_count, "unpersist_count": unpersist_count,
            })
        return findings

    def classify_severity(self, finding):
        return "medium"

    def recommend_fix(self, finding):
        return "Add unpersist() calls after cached DataFrames are no longer needed"

    def transformation_mapping(self, finding):
        return {"artifact_type": "python", "action": "flag_cache_leak",
                "cache_count": finding["cache_count"]}


@register_rule
class GroupByKeyRule(RCARule):
    rule_id = "RCA-017"
    rule_name = "groupByKey() Anti-Pattern"
    category = "spark_antipattern"

    def detect(self, artifacts):
        findings = []
        py_source = artifacts.get("python_source", "")
        tree, _ = safe_parse_ast(py_source)
        if tree is None:
            return findings
        visitor = ASTPatternVisitor()
        visitor.visit(tree)
        for node in visitor.group_by_key_calls:
            findings.append({
                "rule_id": self.rule_id,
                "description": "groupByKey() shuffles all data before grouping -- use reduceByKey/aggregateByKey instead",
                "artifact": "python", "line": node.lineno,
            })
        return findings

    def classify_severity(self, finding):
        return "high"

    def recommend_fix(self, finding):
        return f"Replace groupByKey() at line {finding['line']} with reduceByKey() or aggregateByKey()"

    def transformation_mapping(self, finding):
        return {"artifact_type": "python", "action": "replace_group_by_key", "line": finding["line"]}


@register_rule
class CrossJoinCodeRule(RCARule):
    rule_id = "RCA-018"
    rule_name = "Spark crossJoin() Detection"
    category = "spark_antipattern"

    def detect(self, artifacts):
        findings = []
        py_source = artifacts.get("python_source", "")
        tree, _ = safe_parse_ast(py_source)
        if tree is None:
            return findings
        visitor = ASTPatternVisitor()
        visitor.visit(tree)
        for node in visitor.cross_join_calls:
            findings.append({
                "rule_id": self.rule_id,
                "description": "crossJoin() produces Cartesian product -- row count explodes to N*M",
                "artifact": "python", "line": node.lineno,
            })
        return findings

    def classify_severity(self, finding):
        return "critical"

    def recommend_fix(self, finding):
        return f"Replace crossJoin() at line {finding['line']} with a proper JOIN condition"

    def transformation_mapping(self, finding):
        return {"artifact_type": "python", "action": "flag_cross_join", "line": finding["line"]}


@register_rule
class SmallChunkSizeRule(RCARule):
    rule_id = "RCA-019"
    rule_name = "Small Transfer Chunk Size"
    category = "io_performance"

    def detect(self, artifacts):
        findings = []
        py_source = artifacts.get("python_source", "")
        tree, _ = safe_parse_ast(py_source)
        if tree is None:
            return findings
        visitor = ASTPatternVisitor()
        visitor.visit(tree)
        for node in visitor.chunk_size_assigns:
            if isinstance(node.value, ast.BinOp):
                val = self._eval_binop(node.value)
                if val and val < 32 * 1024 * 1024:
                    findings.append({
                        "rule_id": self.rule_id,
                        "description": f"chunk_size is {val // (1024*1024)}MB -- too small for large file transfers",
                        "artifact": "python", "line": node.lineno, "current_size": val,
                    })
        return findings

    @staticmethod
    def _eval_binop(node):
        try:
            return eval(compile(ast.Expression(body=node), "<>", "eval"))
        except Exception:
            return None

    def classify_severity(self, finding):
        return "medium"

    def recommend_fix(self, finding):
        return f"Scale chunk_size at line {finding['line']} based on data volume (32MB-128MB)"

    def transformation_mapping(self, finding):
        return {"artifact_type": "python", "action": "increase_chunk_size", "line": finding["line"]}


# --- SQL Inefficiency Rules ---

@register_rule
class SelectStarSQLRule(RCARule):
    rule_id = "RCA-020"
    rule_name = "SELECT * Anti-Pattern"
    category = "sql_inefficiency"

    def detect(self, artifacts):
        findings = []
        for key, value in self._walk_sql_strings(artifacts):
            if detect_select_star(value):
                findings.append({
                    "rule_id": self.rule_id,
                    "description": f"SELECT * in '{key}' fetches unnecessary columns",
                    "artifact": "json" if "json" in key else "python",
                    "json_path": key, "sql": value,
                })
        return findings

    def _walk_sql_strings(self, artifacts):
        json_config = artifacts.get("json_config")
        if json_config:
            yield from self._walk_json(json_config, "json")
        py_source = artifacts.get("python_source", "")
        tree, _ = safe_parse_ast(py_source)
        if tree:
            for node in ast.walk(tree):
                if isinstance(node, ast.Constant) and isinstance(node.value, str):
                    if len(node.value) > 15:
                        yield f"python:line_{node.lineno}", node.value

    def _walk_json(self, obj, prefix=""):
        if isinstance(obj, dict):
            for k, v in obj.items():
                path = f"{prefix}.{k}" if prefix else k
                yield from self._walk_json(v, path)
        elif isinstance(obj, list):
            for i, v in enumerate(obj):
                yield from self._walk_json(v, f"{prefix}[{i}]")
        elif isinstance(obj, str) and len(obj) > 15:
            yield prefix, obj

    def classify_severity(self, finding):
        return "medium"

    def recommend_fix(self, finding):
        rec = f"Replace SELECT * with explicit column list in {finding['json_path']}"
        sql = finding.get("sql", "")
        if sql:
            rec += f"\n\nOriginal SQL (replace * with specific columns):\n{sql}"
        return rec

    def transformation_mapping(self, finding):
        return {"artifact_type": finding["artifact"], "action": "replace_select_star",
                "json_path": finding.get("json_path", "")}


@register_rule
class CorrelatedSubqueryRule(RCARule):
    rule_id = "RCA-021"
    rule_name = "Correlated Subquery Detection"
    category = "sql_inefficiency"

    def detect(self, artifacts):
        findings = []
        for key, value in self._walk_sql_strings(artifacts):
            if detect_correlated_subquery(value):
                findings.append({
                    "rule_id": self.rule_id,
                    "description": f"Correlated subquery in '{key}' causes N+1 execution",
                    "artifact": "json" if "json" in key else "python",
                    "json_path": key, "sql": value,
                })
        return findings

    def _walk_sql_strings(self, artifacts):
        json_config = artifacts.get("json_config")
        if json_config:
            yield from _walk_json_strings(json_config, "json")
        py_source = artifacts.get("python_source", "")
        tree, _ = safe_parse_ast(py_source)
        if tree:
            for node in ast.walk(tree):
                if isinstance(node, ast.Constant) and isinstance(node.value, str) and len(node.value) > 20:
                    yield f"python:line_{node.lineno}", node.value

    def classify_severity(self, finding):
        return "high"

    def recommend_fix(self, finding):
        rec = f"Replace correlated subquery with JOIN or window function in {finding['json_path']}"
        sql = finding.get("sql", "")
        if sql:
            rec += f"\n\nOriginal SQL (requires manual refactoring):\n{sql}"
        return rec

    def transformation_mapping(self, finding):
        return {"artifact_type": "json", "action": "replace_correlated_subquery",
                "json_path": finding["json_path"]}


@register_rule
class CartesianJoinSQLRule(RCARule):
    rule_id = "RCA-022"
    rule_name = "Cartesian/Cross Join Detection in SQL"
    category = "sql_inefficiency"

    def detect(self, artifacts):
        findings = []
        for key, value in _walk_all_sql(artifacts):
            if detect_cartesian_join(value):
                findings.append({
                    "rule_id": self.rule_id,
                    "description": f"Cartesian/cross join in '{key}' -- produces N*M rows, causing data explosion",
                    "artifact": "json" if "json" in key else "python",
                    "json_path": key, "sql": value,
                })
        return findings

    def classify_severity(self, finding):
        return "critical"

    def recommend_fix(self, finding):
        rec = f"Add proper JOIN condition or replace CROSS JOIN in {finding['json_path']}"
        sql = finding.get("sql", "")
        if sql:
            rec += f"\n\nOriginal SQL (requires manual refactoring):\n{sql}"
        return rec

    def transformation_mapping(self, finding):
        return {"artifact_type": finding["artifact"], "action": "flag_cartesian_join",
                "json_path": finding["json_path"]}


@register_rule
class MissingJoinPredicateRule(RCARule):
    rule_id = "RCA-023"
    rule_name = "Missing JOIN Predicate Detection"
    category = "sql_inefficiency"

    def detect(self, artifacts):
        findings = []
        for key, value in _walk_all_sql(artifacts):
            if detect_missing_join_predicate(value):
                findings.append({
                    "rule_id": self.rule_id,
                    "description": f"JOIN without proper ON clause in '{key}' -- potential Cartesian product",
                    "artifact": "json" if "json" in key else "python",
                    "json_path": key, "sql": value,
                })
        return findings

    def classify_severity(self, finding):
        return "critical"

    def recommend_fix(self, finding):
        rec = f"Add ON clause to JOIN in {finding['json_path']} to prevent Cartesian product"
        sql = finding.get("sql", "")
        if sql:
            rec += f"\n\nOriginal SQL (requires manual refactoring):\n{sql}"
        return rec

    def transformation_mapping(self, finding):
        return {"artifact_type": finding["artifact"], "action": "flag_missing_join_predicate",
                "json_path": finding["json_path"]}


@register_rule
class OrderByWithoutLimitRule(RCARule):
    rule_id = "RCA-024"
    rule_name = "ORDER BY Without LIMIT Detection"
    category = "sql_inefficiency"

    def detect(self, artifacts):
        findings = []
        for key, value in _walk_all_sql(artifacts):
            if detect_order_by_without_limit(value):
                findings.append({
                    "rule_id": self.rule_id,
                    "description": f"ORDER BY without LIMIT in '{key}' -- causes full dataset sort",
                    "artifact": "json" if "json" in key else "python",
                    "json_path": key, "sql": value,
                })
        return findings

    def classify_severity(self, finding):
        return "medium"

    def recommend_fix(self, finding):
        rec = f"Add LIMIT clause or remove ORDER BY in {finding['json_path']}"
        sql = finding.get("sql", "")
        if sql:
            # Show SQL with a LIMIT 1000 appended as example
            optimized = sql.rstrip().rstrip(';') + " LIMIT 1000"
            rec += f"\n\nOptimized SQL (example with LIMIT):\n{optimized}"
        return rec

    def transformation_mapping(self, finding):
        return {"artifact_type": finding["artifact"], "action": "flag_order_without_limit",
                "json_path": finding["json_path"]}


@register_rule
class UnionWithoutAllRule(RCARule):
    rule_id = "RCA-025"
    rule_name = "UNION Without ALL Detection"
    category = "sql_inefficiency"

    def detect(self, artifacts):
        findings = []
        for key, value in _walk_all_sql(artifacts):
            if detect_union_without_all(value):
                # Analyze if UNION ALL is safe (no dedup risk)
                safe_for_all = self._is_safe_for_union_all(value)
                findings.append({
                    "rule_id": self.rule_id,
                    "description": f"UNION (without ALL) in '{key}' -- "
                                   f"{'safe to replace with UNION ALL (sources are distinct)' if safe_for_all else 'UNION dedup may be intentional -- annotating only'}",
                    "artifact": "json" if "json" in key else "python",
                    "json_path": key, "sql": value,
                    "safe_for_all": safe_for_all,
                })
        return findings

    @staticmethod
    def _is_safe_for_union_all(sql: str) -> bool:
        """Determine if UNION can safely be replaced with UNION ALL.

        Safe when:
        - Each branch of UNION selects from different tables (no overlap)
        - Each branch already has DISTINCT
        - Each branch has different WHERE conditions that guarantee no overlap
        Not safe when:
        - Same table appears in multiple branches (dedup may be intentional)
        - No clear separation between data sources
        """
        normalized = re.sub(r'\s+', ' ', sql.upper().strip())
        # Split on UNION (not UNION ALL) to get branches
        branches = re.split(r'\bUNION\b(?!\s+ALL)', normalized)
        if len(branches) < 2:
            return False
        # Extract FROM tables in each branch
        branch_tables = []
        for branch in branches:
            tables = set()
            from_matches = re.findall(r'FROM\s+(\w+)', branch)
            join_matches = re.findall(r'JOIN\s+(\w+)', branch)
            tables.update(t for t in from_matches)
            tables.update(t for t in join_matches)
            branch_tables.append(tables)
        # If branches select from completely different tables -> safe
        all_tables = [t for ts in branch_tables for t in ts]
        if len(set(all_tables)) == len(all_tables):
            return True
        # If each branch already has DISTINCT -> UNION is redundant
        all_have_distinct = all(
            re.search(r'SELECT\s+DISTINCT', branch) for branch in branches
        )
        if all_have_distinct:
            return True
        # Otherwise not safe to auto-replace
        return False

    def classify_severity(self, finding):
        return "medium" if finding.get("safe_for_all") else "low"

    def recommend_fix(self, finding):
        if finding.get("safe_for_all"):
            rec = f"Replace UNION with UNION ALL in {finding['json_path']} -- data sources are distinct, dedup is unnecessary overhead"
            sql = finding.get("sql", "")
            if sql:
                optimized = re.sub(r'\bUNION\b(?!\s+ALL)', 'UNION ALL', sql, flags=re.IGNORECASE)
                if optimized != sql:
                    rec += f"\n\nOptimized SQL:\n{optimized}"
            return rec
        return f"UNION in {finding['json_path']} may require dedup -- annotated for review, not auto-replaced"

    def transformation_mapping(self, finding):
        return {"artifact_type": finding["artifact"], "action": "flag_union_without_all",
                "json_path": finding["json_path"],
                "safe_for_all": finding.get("safe_for_all", False)}


@register_rule
class DeepNestingSQLRule(RCARule):
    rule_id = "RCA-026"
    rule_name = "Deeply Nested Subquery Detection"
    category = "sql_inefficiency"

    MAX_NESTING = 3

    def detect(self, artifacts):
        findings = []
        for key, value in _walk_all_sql(artifacts):
            depth = detect_deep_nesting(value)
            if depth >= self.MAX_NESTING:
                findings.append({
                    "rule_id": self.rule_id,
                    "description": f"SQL in '{key}' has {depth} levels of subquery nesting -- consider CTEs",
                    "artifact": "json" if "json" in key else "python",
                    "json_path": key, "nesting_depth": depth,
                })
        return findings

    def classify_severity(self, finding):
        if finding.get("nesting_depth", 0) >= 5:
            return "high"
        return "medium"

    def recommend_fix(self, finding):
        rec = f"Refactor nested subqueries in {finding['json_path']} to CTEs (WITH clause)"
        sql = finding.get("sql", "")
        if sql:
            rec += f"\n\nOriginal SQL (requires manual CTE refactoring):\n{sql}"
        return rec

    def transformation_mapping(self, finding):
        return {"artifact_type": finding["artifact"], "action": "flag_deep_nesting",
                "json_path": finding["json_path"]}


@register_rule
class UnboundedAggregationRule(RCARule):
    rule_id = "RCA-027"
    rule_name = "Unbounded Aggregation Detection"
    category = "sql_inefficiency"

    def detect(self, artifacts):
        findings = []
        for key, value in _walk_all_sql(artifacts):
            if detect_unbounded_aggregation(value):
                findings.append({
                    "rule_id": self.rule_id,
                    "description": f"GROUP BY with JOINs but no WHERE in '{key}' -- full table scan aggregation",
                    "artifact": "json" if "json" in key else "python",
                    "json_path": key,
                })
        return findings

    def classify_severity(self, finding):
        return "medium"

    def recommend_fix(self, finding):
        rec = f"Add WHERE predicates to filter data before aggregation in {finding['json_path']}"
        sql = finding.get("sql", "")
        if sql:
            rec += f"\n\nOriginal SQL (requires manual WHERE clause addition):\n{sql}"
        return rec

    def transformation_mapping(self, finding):
        return {"artifact_type": finding["artifact"], "action": "flag_unbounded_aggregation",
                "json_path": finding["json_path"]}


@register_rule
class NonSargablePredicateRule(RCARule):
    rule_id = "RCA-028"
    rule_name = "Non-Sargable WHERE Predicate Detection"
    category = "sql_inefficiency"

    def detect(self, artifacts):
        findings = []
        for key, value in _walk_all_sql(artifacts):
            # Detailed function-level detection with auto-fix candidates
            func_issues = detect_non_sargable_functions(value)
            for issue in func_issues:
                desc = (
                    f"{issue['function']}() wrapping column in WHERE clause of '{key}' "
                    f"prevents predicate pushdown"
                )
                findings.append({
                    "rule_id": self.rule_id,
                    "description": desc,
                    "artifact": "json" if "json" in key else "python",
                    "json_path": key,
                    "sql": value,
                    "function": issue["function"],
                    "original": issue["original"],
                    "replacement": issue.get("replacement"),
                    "advisory": issue.get("advisory"),
                })
            # Fallback: catch any remaining non-sargable patterns not covered above
            if not func_issues and detect_non_sargable_where(value):
                findings.append({
                    "rule_id": self.rule_id,
                    "description": f"Function applied to column in WHERE clause in '{key}' prevents predicate pushdown",
                    "artifact": "json" if "json" in key else "python",
                    "json_path": key,
                    "function": "unknown",
                    "original": None,
                    "replacement": None,
                })
            if detect_like_leading_wildcard(value):
                findings.append({
                    "rule_id": self.rule_id,
                    "description": f"LIKE with leading wildcard in '{key}' prevents index usage",
                    "artifact": "json" if "json" in key else "python",
                    "json_path": key,
                    "function": "LIKE",
                    "original": None,
                    "replacement": None,
                })
        return findings

    def classify_severity(self, finding):
        func = finding.get("function", "")
        if func in ("YEAR", "MONTH", "DAY", "TO_DATE", "DATE_FORMAT"):
            return "high"
        if func in ("UPPER", "LOWER", "TRIM"):
            return "medium"
        return "medium"

    def recommend_fix(self, finding):
        if finding.get("replacement"):
            rec = (
                f"Replace '{finding['original']}' with '{finding['replacement']}' "
                f"in {finding['json_path']} to enable predicate pushdown"
            )
            sql = finding.get("sql", "")
            if sql:
                optimized = _generate_optimized_sql(sql, {
                    "_fix_action": "fix_non_sargable",
                    "original": finding["original"],
                    "replacement": finding["replacement"],
                })
                if optimized:
                    rec += f"\n\nOptimized SQL:\n{optimized}"
            return rec
        if finding.get("advisory"):
            return finding["advisory"]
        return f"Refactor non-sargable predicate in {finding['json_path']} to allow predicate pushdown"

    def transformation_mapping(self, finding):
        if finding.get("replacement") and finding.get("original"):
            return {"artifact_type": finding["artifact"], "action": "fix_non_sargable_predicate",
                    "json_path": finding["json_path"],
                    "original": finding["original"], "replacement": finding["replacement"]}
        return {"artifact_type": finding["artifact"], "action": "flag_non_sargable",
                "json_path": finding["json_path"]}


@register_rule
class DuplicateInValuesRule(RCARule):
    rule_id = "RCA-029"
    rule_name = "Duplicate Values in IN Clause"
    category = "sql_inefficiency"

    def detect(self, artifacts):
        findings = []
        for key, value in _walk_all_sql(artifacts):
            dupes = detect_duplicate_in_values(value)
            for d in dupes:
                findings.append({
                    "rule_id": self.rule_id,
                    "description": (
                        f"Duplicate value(s) {d['duplicates']} in IN clause for "
                        f"column {d['column']} in '{key}' -- redundant comparisons"
                    ),
                    "artifact": "json" if "json" in key else "python",
                    "json_path": key,
                    "sql": value,
                    "original_clause": d["original_clause"],
                    "fixed_clause": d["fixed_clause"],
                })
        return findings

    def classify_severity(self, finding):
        return "low"

    def recommend_fix(self, finding):
        rec = (
            f"Remove duplicate values from IN clause: "
            f"replace '{finding['original_clause']}' with '{finding['fixed_clause']}'"
        )
        sql = finding.get("sql", "")
        if sql:
            optimized = _generate_optimized_sql(sql, {
                "_fix_action": "fix_duplicate_in",
                "original_clause": finding["original_clause"],
                "fixed_clause": finding["fixed_clause"],
            })
            if optimized:
                rec += f"\n\nOptimized SQL:\n{optimized}"
        return rec

    def transformation_mapping(self, finding):
        return {"artifact_type": finding["artifact"], "action": "fix_duplicate_in_values",
                "json_path": finding["json_path"],
                "original": finding["original_clause"], "replacement": finding["fixed_clause"]}


@register_rule
class DistinctOnMultiJoinRule(RCARule):
    rule_id = "RCA-031"
    rule_name = "SELECT DISTINCT on Multi-Table JOIN"
    category = "sql_inefficiency"

    def detect(self, artifacts):
        findings = []
        for key, value in _walk_all_sql(artifacts):
            if detect_distinct_on_multi_join(value):
                join_count = len(re.findall(r'\bJOIN\b', value, re.IGNORECASE))
                findings.append({
                    "rule_id": self.rule_id,
                    "description": (
                        f"SELECT DISTINCT on {join_count}-way JOIN in '{key}' -- "
                        f"expensive full-dataset shuffle for dedup. If join keys produce "
                        f"unique rows, DISTINCT is unnecessary overhead"
                    ),
                    "artifact": "json" if "json" in key else "python",
                    "json_path": key, "sql": value, "join_count": join_count,
                })
        return findings

    def classify_severity(self, finding):
        if finding.get("join_count", 0) >= 4:
            return "high"
        return "medium"

    def recommend_fix(self, finding):
        rec = (
            f"Review whether DISTINCT is required in {finding['json_path']}. "
            f"If join keys produce unique rows, remove DISTINCT to eliminate shuffle. "
            f"Annotated for manual review since removal may affect business logic."
        )
        sql = finding.get("sql", "")
        if sql:
            optimized = _generate_optimized_sql(sql, {"_fix_action": "remove_distinct"})
            if optimized:
                rec += f"\n\nOptimized SQL (if DISTINCT is not needed):\n{optimized}"
        return rec

    def transformation_mapping(self, finding):
        return {"artifact_type": finding["artifact"], "action": "flag_distinct_on_join",
                "json_path": finding["json_path"]}


@register_rule
class BroadcastHintRule(RCARule):
    rule_id = "RCA-032"
    rule_name = "Missing BROADCAST Hint for Small Dimension Tables"
    category = "sql_inefficiency"

    BROADCAST_ROW_THRESHOLD = 100_000

    def detect(self, artifacts):
        findings = []
        log_text = artifacts.get("log_text", "")
        row_counts_map = self._extract_table_row_counts(log_text)
        if not row_counts_map:
            return findings

        for key, value in _walk_all_sql(artifacts):
            normalized = _normalize_sql(value)
            if 'JOIN' not in normalized:
                continue
            # Already has BROADCAST hints? Skip.
            if re.search(r'/\*\+.*BROADCAST', normalized):
                continue
            # Find all JOIN aliases and map to table names
            small_tables = []
            # Pattern: JOIN table_name alias ON ...
            for m in re.finditer(
                r'JOIN\s+(\w+)\s+(\w+)\s+ON', value, re.IGNORECASE
            ):
                table_name = m.group(1).lower()
                alias = m.group(2)
                # Check if we know the row count for this table
                # Fuzzy match: strip common suffixes and compare root names
                for log_table, count in row_counts_map.items():
                    if self._tables_match(log_table, table_name) \
                            and count <= self.BROADCAST_ROW_THRESHOLD:
                        small_tables.append({"alias": alias, "table": table_name, "rows": count})
                        break

            if small_tables:
                aliases_str = ", ".join(t["alias"] for t in small_tables)
                details = "; ".join(f"{t['table']}({t['alias']})={t['rows']:,} rows" for t in small_tables)
                findings.append({
                    "rule_id": self.rule_id,
                    "description": (
                        f"Small dimension table(s) joined without BROADCAST hint in '{key}': "
                        f"{details}. CSV sources provide no statistics -- "
                        f"Spark cannot auto-detect these as broadcastable"
                    ),
                    "artifact": "json" if "json" in key else "python",
                    "json_path": key,
                    "sql": value,
                    "small_tables": small_tables,
                    "broadcast_aliases": aliases_str,
                })
        return findings

    @staticmethod
    def _extract_table_row_counts(log_text: str) -> dict:
        """Extract per-table row counts from log lines like 'table_name rows : 1,280,000'."""
        counts = {}
        for m in re.finditer(
            r'(\w+)\s+rows?\s*:\s*([\d,]+)', log_text, re.IGNORECASE
        ):
            table = m.group(1)
            count = int(m.group(2).replace(',', ''))
            counts[table] = count
        # Also handle "Loaded 500 rows from table_name"
        for m in re.finditer(
            r'(?:Loaded|Read|Fetched)\s+([\d,]+)\s+(?:rows?|records?)\s+(?:from|for)\s+(\w+)',
            log_text, re.IGNORECASE
        ):
            count = int(m.group(1).replace(',', ''))
            table = m.group(2)
            counts[table] = count
        return counts

    @staticmethod
    def _tables_match(log_table: str, sql_table: str) -> bool:
        """Fuzzy match table names across log and SQL.

        Strips common suffixes (_view, _src, _master, _reference, _ref, _tbl, _table)
        and compares root names. Handles cases like:
          log: 'agent_master' vs sql: 'agent_view'  -> match on 'agent'
          log: 'plan_reference' vs sql: 'plan_view'  -> match on 'plan'
        """
        suffixes = ('_view', '_src', '_master', '_reference', '_ref', '_tbl', '_table')
        a = log_table.lower()
        b = sql_table.lower()
        # Direct match
        if a in b or b in a:
            return True
        # Strip suffixes and compare roots
        for s in suffixes:
            if a.endswith(s):
                a = a[:-len(s)]
            if b.endswith(s):
                b = b[:-len(s)]
        return a == b or a in b or b in a

    def classify_severity(self, finding):
        return "high"

    def recommend_fix(self, finding):
        aliases = finding.get("broadcast_aliases", "")
        rec = (
            f"Add BROADCAST hint: /*+ BROADCAST({aliases}) */ in "
            f"{finding['json_path']} to convert sort-merge joins to "
            f"broadcast hash joins, eliminating shuffle for small tables"
        )
        sql = finding.get("sql", "")
        if sql:
            optimized = _generate_optimized_sql(sql, {
                "_fix_action": "add_broadcast",
                "broadcast_aliases": aliases,
            })
            if optimized:
                rec += f"\n\nOptimized SQL:\n{optimized}"
        return rec

    def transformation_mapping(self, finding):
        return {"artifact_type": finding["artifact"], "action": "add_broadcast_hint",
                "json_path": finding["json_path"],
                "broadcast_aliases": finding.get("broadcast_aliases", "")}


@register_rule
class NotInSubqueryRule(RCARule):
    rule_id = "RCA-033"
    rule_name = "NOT IN Subquery Anti-Pattern"
    category = "sql_inefficiency"

    def detect(self, artifacts):
        findings = []
        for key, value in _walk_all_sql(artifacts):
            if detect_not_in_subquery(value):
                findings.append({
                    "rule_id": self.rule_id,
                    "description": (
                        f"NOT IN (SELECT ...) in '{key}' -- slow nested loop execution and "
                        f"NULL-unsafe (returns empty if subquery contains NULL). "
                        f"Replace with NOT EXISTS or LEFT JOIN ... IS NULL"
                    ),
                    "artifact": "json" if "json" in key else "python",
                    "json_path": key, "sql": value,
                })
        return findings

    def classify_severity(self, finding):
        return "high"

    def recommend_fix(self, finding):
        rec = (
            f"Replace NOT IN (SELECT ...) with LEFT JOIN ... WHERE key IS NULL "
            f"or NOT EXISTS in {finding['json_path']} -- faster and NULL-safe"
        )
        sql = finding.get("sql", "")
        if sql:
            rec += f"\n\nOriginal SQL (requires manual refactoring):\n{sql}"
        return rec

    def transformation_mapping(self, finding):
        return {"artifact_type": finding["artifact"], "action": "flag_not_in_subquery",
                "json_path": finding["json_path"]}


@register_rule
class HavingWithoutAggregationRule(RCARule):
    rule_id = "RCA-034"
    rule_name = "HAVING Clause Without Aggregation"
    category = "sql_inefficiency"

    def detect(self, artifacts):
        findings = []
        for key, value in _walk_all_sql(artifacts):
            non_agg = detect_having_without_aggregation(value)
            if non_agg:
                findings.append({
                    "rule_id": self.rule_id,
                    "description": (
                        f"HAVING clause in '{key}' contains non-aggregate condition(s): "
                        f"{', '.join(non_agg[:3])}. These should be in WHERE clause "
                        f"to filter rows BEFORE aggregation, not after"
                    ),
                    "artifact": "json" if "json" in key else "python",
                    "json_path": key, "sql": value, "conditions": non_agg,
                })
        return findings

    def classify_severity(self, finding):
        return "medium"

    def recommend_fix(self, finding):
        rec = (
            f"Move non-aggregate conditions from HAVING to WHERE in "
            f"{finding['json_path']} -- filters applied before GROUP BY reduce "
            f"data processed during aggregation"
        )
        sql = finding.get("sql", "")
        if sql:
            rec += f"\n\nOriginal SQL (requires manual refactoring):\n{sql}"
        return rec

    def transformation_mapping(self, finding):
        return {"artifact_type": finding["artifact"], "action": "flag_having_without_agg",
                "json_path": finding["json_path"]}


@register_rule
class ImplicitTypeCoercionRule(RCARule):
    rule_id = "RCA-035"
    rule_name = "Implicit Type Coercion in Predicates"
    category = "sql_inefficiency"

    def detect(self, artifacts):
        findings = []
        for key, value in _walk_all_sql(artifacts):
            coercions = detect_implicit_type_coercion(value)
            for c in coercions:
                findings.append({
                    "rule_id": self.rule_id,
                    "description": (
                        f"Implicit type coercion in '{key}': column {c['column']} compared "
                        f"to numeric literal {c['value']} -- if column is string type, "
                        f"Spark applies implicit CAST preventing pushdown"
                    ),
                    "artifact": "json" if "json" in key else "python",
                    "json_path": key, "sql": value,
                    "column": c["column"], "value": c["value"],
                })
        return findings

    def classify_severity(self, finding):
        return "low"

    def recommend_fix(self, finding):
        rec = (
            f"Ensure type consistency in {finding['json_path']}: if {finding['column']} is "
            f"a string column, compare with '{finding['value']}' (quoted) instead of "
            f"{finding['value']} (numeric literal)"
        )
        sql = finding.get("sql", "")
        if sql:
            rec += f"\n\nOriginal SQL (verify column types before changing):\n{sql}"
        return rec

    def transformation_mapping(self, finding):
        return {"artifact_type": finding["artifact"], "action": "flag_implicit_coercion",
                "json_path": finding["json_path"]}


# --- Config Issue Rules ---

@register_rule
class SmartConfigProvisioningRule(RCARule):
    rule_id = "RCA-030"
    rule_name = "Smart Configuration Provisioning Analysis"
    category = "config_issue"

    MIN_WORKERS = 3

    def detect(self, artifacts):
        findings = []
        yml_config = artifacts.get("yml_config")
        config = self._extract_config(yml_config) if yml_config else {}
        workers_raw = config.get("NumberOfWorkers", config.get("numberOfWorkers", ""))
        worker_type = config.get("WorkerType", "G.1X")
        timeout_raw = config.get("Timeout", "")

        # Fallback: extract from raw YAML text if parsed config is empty
        yml_source = artifacts.get("yml_source", "")
        if not workers_raw and yml_source:
            m = re.search(r'NumberOfWorkers\s*:\s*["\']?(\d+)', yml_source, re.IGNORECASE)
            if m:
                workers_raw = m.group(1)
        if worker_type == "G.1X" and yml_source:
            m = re.search(r'WorkerType\s*:\s*["\']?([\w.]+)', yml_source, re.IGNORECASE)
            if m:
                worker_type = m.group(1)
        if not timeout_raw and yml_source:
            m = re.search(r'Timeout\s*:\s*["\']?(\d+)', yml_source, re.IGNORECASE)
            if m:
                timeout_raw = m.group(1)

        try:
            workers = int(workers_raw)
        except (ValueError, TypeError):
            return findings

        log_text = artifacts.get("log_text", "")
        row_counts = extract_row_counts_from_log(log_text)
        total_rows = sum(row_counts) if row_counts else 0

        has_oom = bool(detect_log_patterns(log_text, OOM_PATTERNS))
        has_gc = bool(detect_log_patterns(log_text, GC_OVERHEAD_PATTERNS))
        has_spill = bool(detect_log_patterns(log_text, SHUFFLE_SPILL_PATTERNS))

        py_source = artifacts.get("python_source", "")
        has_joins = bool(re.search(r'\.join\(|JOIN', py_source, re.IGNORECASE))
        has_windows = bool(re.search(r'OVER\s*\(|Window\.', py_source, re.IGNORECASE))
        json_source = artifacts.get("json_source", "")
        if json_source:
            has_joins = has_joins or bool(re.search(r'JOIN', json_source, re.IGNORECASE))
            has_windows = has_windows or bool(re.search(r'OVER\s*\(', json_source, re.IGNORECASE))

        exec_duration = artifacts.get("_execution_duration", 0)
        threshold = artifacts.get("_threshold_limit", 0)

        rec = recommend_worker_config(
            current_type=worker_type,
            current_count=workers,
            total_data_rows=total_rows,
            has_joins=has_joins,
            has_window_functions=has_windows,
            has_oom=has_oom,
            has_shuffle_spill=has_spill,
            has_gc_overhead=has_gc,
            execution_duration=exec_duration,
            threshold=threshold,
        )

        if rec["changed"] or workers < self.MIN_WORKERS:
            findings.append({
                "rule_id": self.rule_id,
                "description": (
                    f"NumberOfWorkers={workers} ({worker_type}) is under-provisioned. "
                    f"Recommend {rec['recommended_count']} workers with {rec['recommended_type']}. "
                    f"Reasons: {'; '.join(rec['reasons'])}"
                ),
                "artifact": "yaml",
                "current_workers": workers,
                "current_type": worker_type,
                "recommended_workers": rec["recommended_count"],
                "recommended_type": rec["recommended_type"],
                "reasons": rec["reasons"],
                "total_data_rows": total_rows,
                "has_oom": has_oom,
                "has_gc_overhead": has_gc,
                "has_shuffle_spill": has_spill,
            })

        try:
            timeout = int(timeout_raw)
            if exec_duration > 0 and timeout > 0:
                if exec_duration > timeout * 0.8:
                    findings.append({
                        "rule_id": self.rule_id,
                        "description": f"Timeout={timeout}min is dangerously close to execution duration ({exec_duration}min) -- risk of timeout failure",
                        "artifact": "yaml",
                        "current_timeout": timeout,
                        "execution_duration": exec_duration,
                        "issue_type": "timeout_risk",
                    })
        except (ValueError, TypeError):
            pass

        return findings

    @staticmethod
    def _extract_config(yml_config):
        if isinstance(yml_config, dict):
            for key, val in yml_config.items():
                if isinstance(val, dict):
                    return val
        return yml_config if isinstance(yml_config, dict) else {}

    def classify_severity(self, finding):
        if finding.get("has_oom"):
            return "critical"
        if finding.get("has_shuffle_spill") or finding.get("has_gc_overhead"):
            return "high"
        if finding.get("current_workers", 999) <= 1:
            return "critical"
        if finding.get("issue_type") == "timeout_risk":
            return "high"
        return "high"

    def recommend_fix(self, finding):
        if finding.get("issue_type") == "timeout_risk":
            return f"Increase Timeout from {finding['current_timeout']}min (execution uses {finding['execution_duration']}min)"
        rec_w = finding.get("recommended_workers", "?")
        rec_t = finding.get("recommended_type", "?")
        return f"Scale to {rec_w} workers with {rec_t}. {'; '.join(finding.get('reasons', []))}"

    def transformation_mapping(self, finding):
        if finding.get("issue_type") == "timeout_risk":
            return {"artifact_type": "yaml", "action": "increase_timeout",
                    "current_timeout": finding["current_timeout"],
                    "execution_duration": finding["execution_duration"]}
        return {
            "artifact_type": "yaml", "action": "scale_workers",
            "recommended_workers": finding.get("recommended_workers"),
            "recommended_type": finding.get("recommended_type"),
        }


# --- Runtime / Log Analysis Rules ---

@register_rule
class LogDurationAnomalyRule(RCARule):
    rule_id = "RCA-040"
    rule_name = "Log-Based Duration Anomaly"
    category = "runtime_analysis"

    STAGE_GAP_THRESHOLD_MINUTES = 10

    def detect(self, artifacts):
        findings = []
        log_text = artifacts.get("log_text", "")
        if not log_text:
            return findings
        py_source = artifacts.get("python_source", "")
        gaps = find_long_running_stages(log_text, self.STAGE_GAP_THRESHOLD_MINUTES)
        for gap in gaps:
            breadcrumb = gap.get("breadcrumb_msg", "")
            # Correlate breadcrumb to source code and identify the slow operation
            correlation = correlate_breadcrumb_to_source(breadcrumb, py_source)
            operation = correlation.get("operation")
            fix_info = OPERATION_FIX_MAP.get(operation) if operation else None

            if fix_info:
                # Actionable finding -- we know what operation caused the slowdown
                src_line = correlation.get("source_line", -1)
                desc = (f"Long-running stage {gap['duration_minutes']}min "
                        f"({gap['start']} to {gap['end']}): "
                        f"stuck at \"{breadcrumb}\" -> {correlation['operation_desc']}")
                if src_line > 0:
                    desc += f" (near source line {src_line})"
                findings.append({
                    "rule_id": self.rule_id,
                    "description": desc,
                    "artifact": fix_info["artifact"],
                    "stage_start": gap["start"], "stage_end": gap["end"],
                    "duration_minutes": gap["duration_minutes"],
                    "breadcrumb_msg": breadcrumb,
                    "root_cause_operation": operation,
                    "source_line": src_line,
                    "code_context": correlation.get("code_context", ""),
                    "fix_action": fix_info["action"],
                })
            else:
                # No operation identified -- diagnostic-only log finding
                desc = f"Long-running stage: {gap['duration_minutes']}min ({gap['start']} to {gap['end']})"
                if breadcrumb:
                    desc += f" -- last activity: \"{breadcrumb}\""
                findings.append({
                    "rule_id": self.rule_id,
                    "description": desc,
                    "artifact": "log",
                    "stage_start": gap["start"], "stage_end": gap["end"],
                    "duration_minutes": gap["duration_minutes"],
                    "breadcrumb_msg": breadcrumb,
                })
        return findings

    def classify_severity(self, finding):
        d = finding["duration_minutes"]
        if d > 30:
            return "critical"
        if d > 15:
            return "high"
        return "medium"

    def recommend_fix(self, finding):
        operation = finding.get("root_cause_operation")
        fix_info = OPERATION_FIX_MAP.get(operation) if operation else None
        dur = finding["duration_minutes"]
        window = f"({finding['stage_start']} to {finding['stage_end']})"
        breadcrumb = finding.get("breadcrumb_msg", "")
        if fix_info:
            return (f"Stage {window} slow for {dur}min -- last log: \"{breadcrumb}\" -> "
                    f"{fix_info['recommendation']}")
        return f"Investigate {dur}min bottleneck {window} -- last activity: \"{breadcrumb}\""

    def transformation_mapping(self, finding):
        operation = finding.get("root_cause_operation")
        fix_info = OPERATION_FIX_MAP.get(operation) if operation else None
        if fix_info:
            return {
                "artifact_type": fix_info["artifact"],
                "action": fix_info["action"],
                "source_line": finding.get("source_line", -1),
                "details": finding,
            }
        return {"artifact_type": "log", "action": "flag_long_running_stage", "details": finding}


@register_rule
class OOMDetectionRule(RCARule):
    rule_id = "RCA-041"
    rule_name = "OutOfMemory Error Detection"
    category = "runtime_analysis"

    def detect(self, artifacts):
        findings = []
        log_text = artifacts.get("log_text", "")
        if not log_text:
            return findings
        oom_lines = detect_log_patterns(log_text, OOM_PATTERNS)
        driver_oom_lines = detect_log_patterns(log_text, DRIVER_OOM_PATTERNS)
        if driver_oom_lines:
            findings.append({
                "rule_id": self.rule_id,
                "description": f"Driver OOM detected -- likely caused by collect()/toPandas(). Lines: {driver_oom_lines[:3]}",
                "artifact": "log", "oom_type": "driver", "matched_lines": driver_oom_lines[:5],
            })
        elif oom_lines:
            findings.append({
                "rule_id": self.rule_id,
                "description": f"Executor OOM detected -- need larger worker type or more workers. Lines: {oom_lines[:3]}",
                "artifact": "log", "oom_type": "executor", "matched_lines": oom_lines[:5],
            })
        return findings

    def classify_severity(self, finding):
        return "critical"

    def recommend_fix(self, finding):
        if finding.get("oom_type") == "driver":
            return "Driver OOM: remove collect()/toPandas() or increase driver memory"
        return "Executor OOM: increase WorkerType or NumberOfWorkers"

    def transformation_mapping(self, finding):
        return {"artifact_type": "yaml", "action": "scale_for_oom", "oom_type": finding.get("oom_type")}


@register_rule
class GCOverheadDetectionRule(RCARule):
    rule_id = "RCA-042"
    rule_name = "GC Overhead Detection"
    category = "runtime_analysis"

    def detect(self, artifacts):
        findings = []
        log_text = artifacts.get("log_text", "")
        if not log_text:
            return findings
        gc_lines = detect_log_patterns(log_text, GC_OVERHEAD_PATTERNS)
        if gc_lines:
            findings.append({
                "rule_id": self.rule_id,
                "description": f"GC overhead detected -- executors spending too much time in garbage collection",
                "artifact": "log", "matched_lines": gc_lines[:5],
            })
        return findings

    def classify_severity(self, finding):
        return "high"

    def recommend_fix(self, finding):
        return "Increase WorkerType for more memory per executor, or reduce data per partition"

    def transformation_mapping(self, finding):
        return {"artifact_type": "yaml", "action": "scale_for_gc"}


@register_rule
class ShuffleSpillDetectionRule(RCARule):
    rule_id = "RCA-043"
    rule_name = "Shuffle Spill to Disk Detection"
    category = "runtime_analysis"

    def detect(self, artifacts):
        findings = []
        log_text = artifacts.get("log_text", "")
        if not log_text:
            return findings
        spill_lines = detect_log_patterns(log_text, SHUFFLE_SPILL_PATTERNS)
        if spill_lines:
            findings.append({
                "rule_id": self.rule_id,
                "description": "Shuffle data spilling to disk -- insufficient memory for shuffle operations",
                "artifact": "log", "matched_lines": spill_lines[:5],
            })
        return findings

    def classify_severity(self, finding):
        return "high"

    def recommend_fix(self, finding):
        return "Increase WorkerType/NumberOfWorkers to reduce shuffle spill, or optimize shuffle-heavy operations"

    def transformation_mapping(self, finding):
        return {"artifact_type": "yaml", "action": "scale_for_shuffle_spill"}


@register_rule
class DataSkewDetectionRule(RCARule):
    rule_id = "RCA-044"
    rule_name = "Data Skew Detection"
    category = "runtime_analysis"

    def detect(self, artifacts):
        findings = []
        log_text = artifacts.get("log_text", "")
        if not log_text:
            return findings
        skew_lines = detect_log_patterns(log_text, DATA_SKEW_PATTERNS)
        if skew_lines:
            findings.append({
                "rule_id": self.rule_id,
                "description": "Data skew detected -- uneven partition sizes causing straggler tasks",
                "artifact": "log", "matched_lines": skew_lines[:5],
            })
        return findings

    def classify_severity(self, finding):
        return "high"

    def recommend_fix(self, finding):
        return "Add salting to skewed join keys, or use adaptive query execution (AQE) to handle skew"

    def transformation_mapping(self, finding):
        return {"artifact_type": "log", "action": "flag_data_skew"}


@register_rule
class ConnectionTimeoutDetectionRule(RCARule):
    rule_id = "RCA-045"
    rule_name = "Connection/Socket Timeout Detection"
    category = "runtime_analysis"

    def detect(self, artifacts):
        findings = []
        log_text = artifacts.get("log_text", "")
        if not log_text:
            return findings
        timeout_lines = detect_log_patterns(log_text, TIMEOUT_PATTERNS)
        if timeout_lines:
            findings.append({
                "rule_id": self.rule_id,
                "description": "Connection/socket timeout detected -- network or database connectivity issue",
                "artifact": "log", "matched_lines": timeout_lines[:5],
            })
        return findings

    def classify_severity(self, finding):
        return "high"

    def recommend_fix(self, finding):
        return "Increase connection timeout settings, check VPC/security group configuration, or add retry logic"

    def transformation_mapping(self, finding):
        return {"artifact_type": "log", "action": "flag_connection_timeout"}


# --- Common Job Failure Detection Rules ---

@register_rule
class DBConnectionErrorRule(RCARule):
    """Detects database connection failures in CloudWatch logs including
    authentication errors, connection refused, pool exhaustion, and driver issues."""
    rule_id = "RCA-050"
    rule_name = "Database Connection Error Detection"
    category = "runtime_failure"

    def detect(self, artifacts):
        findings = []
        log_text = artifacts.get("log_text", "")
        if not log_text:
            return findings
        matched_lines = detect_log_patterns(log_text, DB_CONNECTION_ERROR_PATTERNS)
        if matched_lines:
            # Classify the sub-type for targeted recommendations
            sub_type = "generic_db_error"
            sample = " ".join(matched_lines[:3]).lower()
            if any(kw in sample for kw in ("access denied", "authentication failed", "login failed", "password")):
                sub_type = "auth_failure"
            elif any(kw in sample for kw in ("connection refused", "could not connect", "communications link")):
                sub_type = "connection_refused"
            elif any(kw in sample for kw in ("too many connections", "pool exhausted", "max_connections")):
                sub_type = "pool_exhaustion"
            elif any(kw in sample for kw in ("no suitable driver",)):
                sub_type = "missing_driver"
            elif any(kw in sample for kw in ("connection.*reset", "reset")):
                sub_type = "connection_reset"
            findings.append({
                "rule_id": self.rule_id,
                "description": f"Database connection error detected: {sub_type.replace('_', ' ')}",
                "artifact": "log", "matched_lines": matched_lines[:5],
                "sub_type": sub_type,
            })
        return findings

    def classify_severity(self, finding):
        return "critical"

    def recommend_fix(self, finding):
        sub_type = finding.get("sub_type", "generic_db_error")
        recommendations = {
            "auth_failure": (
                "1. Verify database credentials in AWS Secrets Manager or connection parameters | "
                "2. Check that the IAM role/user has the correct database permissions | "
                "3. Ensure the password has not expired or been rotated | "
                "4. Confirm the username matches the database grant (case-sensitive)"
            ),
            "connection_refused": (
                "1. Verify the database endpoint hostname and port in YAML config | "
                "2. Check that the database instance is running and accepting connections | "
                "3. Verify VPC security groups allow inbound traffic from Glue ENIs on the DB port | "
                "4. Confirm the Glue job subnet has a route to the database (VPC peering, NAT gateway, or same VPC) | "
                "5. Check if the database is in a private subnet -- Glue needs VPC configuration with proper subnet/SG"
            ),
            "pool_exhaustion": (
                "1. Reduce the number of concurrent Spark partitions writing to the database | "
                "2. Add connection pooling parameters: maxConnections, minConnections in JDBC URL | "
                "3. Increase max_connections on the database server | "
                "4. Use coalesce() before JDBC write to limit parallel connections | "
                "5. Add retry logic with exponential backoff for transient pool exhaustion"
            ),
            "missing_driver": (
                "1. Add the JDBC driver JAR to the Glue job's --extra-jars parameter | "
                "2. Upload the driver JAR to S3 and reference it in the YAML config | "
                "3. Verify the JDBC URL format matches the driver (e.g., jdbc:mysql://, jdbc:postgresql://) | "
                "4. For Glue 3.0+, some drivers are pre-installed -- check Glue version compatibility"
            ),
            "connection_reset": (
                "1. Check for network instability between Glue VPC and database | "
                "2. Increase connection timeout and socket timeout in JDBC URL parameters | "
                "3. Add keepalive settings to prevent idle connection drops | "
                "4. Verify no firewall or NAT gateway is terminating long-lived connections | "
                "5. Consider adding retry logic with reconnection for intermittent resets"
            ),
            "generic_db_error": (
                "1. Check the full error stack trace in CloudWatch logs for specific error codes | "
                "2. Verify database endpoint, port, credentials, and VPC/security group configuration | "
                "3. Test database connectivity from the Glue VPC using a Lambda function or EC2 instance | "
                "4. Check database server logs for corresponding connection attempts | "
                "5. Ensure the JDBC driver version is compatible with the database version"
            ),
        }
        return recommendations.get(sub_type, recommendations["generic_db_error"])

    def transformation_mapping(self, finding):
        return {"artifact_type": "advisory", "action": "flag_db_connection_error",
                "sub_type": finding.get("sub_type", "generic_db_error")}


@register_rule
class BadS3PathErrorRule(RCARule):
    """Detects S3 path errors including missing buckets, missing keys,
    access denied, and invalid path formats."""
    rule_id = "RCA-051"
    rule_name = "Bad S3 Path Error Detection"
    category = "runtime_failure"

    def detect(self, artifacts):
        findings = []
        log_text = artifacts.get("log_text", "")
        if not log_text:
            return findings
        matched_lines = detect_log_patterns(log_text, BAD_S3_PATH_PATTERNS)
        if matched_lines:
            sub_type = "generic_s3_error"
            sample = " ".join(matched_lines[:3]).lower()
            if any(kw in sample for kw in ("nosuchbucket", "bucket does not exist")):
                sub_type = "missing_bucket"
            elif any(kw in sample for kw in ("nosuchkey", "key does not exist", "not found")):
                sub_type = "missing_key"
            elif any(kw in sample for kw in ("access denied",)):
                sub_type = "s3_access_denied"
            elif any(kw in sample for kw in ("path does not exist", "analysisexception")):
                sub_type = "invalid_path"
            # Try to extract the bad S3 path from log lines
            s3_path = None
            for line in matched_lines:
                m = re.search(r'(s3[an]?://[^\s,\'"]+)', line, re.IGNORECASE)
                if m:
                    s3_path = m.group(1)
                    break
            findings.append({
                "rule_id": self.rule_id,
                "description": f"S3 path error detected: {sub_type.replace('_', ' ')}"
                               + (f" -- path: {s3_path}" if s3_path else ""),
                "artifact": "log", "matched_lines": matched_lines[:5],
                "sub_type": sub_type, "s3_path": s3_path,
            })
        return findings

    def classify_severity(self, finding):
        return "critical"

    def recommend_fix(self, finding):
        sub_type = finding.get("sub_type", "generic_s3_error")
        s3_path = finding.get("s3_path", "")
        path_hint = f" (path: {s3_path})" if s3_path else ""
        recommendations = {
            "missing_bucket": (
                f"1. Verify the S3 bucket name in YAML config -- bucket does not exist{path_hint} | "
                "2. Check for typos in the bucket name (case-sensitive, no uppercase allowed) | "
                "3. Confirm the bucket is in the same AWS region as the Glue job | "
                "4. If cross-region, add the region parameter to S3 client configuration"
            ),
            "missing_key": (
                f"1. Verify the S3 object key/prefix in YAML config{path_hint} | "
                "2. Check if the source file exists using: aws s3 ls <path> | "
                "3. Confirm the file was not moved/deleted by another process | "
                "4. Check if the path uses date partitions and the expected partition exists | "
                "5. Verify path separators (use / not \\) and no trailing whitespace"
            ),
            "s3_access_denied": (
                f"1. Check the Glue job IAM role has s3:GetObject and s3:ListBucket permissions{path_hint} | "
                "2. Verify the S3 bucket policy allows access from the Glue IAM role | "
                "3. Check if the bucket has requester-pays enabled | "
                "4. Verify no S3 bucket access point or VPC endpoint policy is blocking access | "
                "5. If cross-account, ensure both IAM role policy and bucket policy grant access"
            ),
            "invalid_path": (
                f"1. Verify the S3 path format: s3://bucket-name/key/path{path_hint} | "
                "2. Check YAML config for correct path variable substitution | "
                "3. Ensure the path does not contain special characters or spaces | "
                "4. Verify Spark can read the file format at the path (Parquet, CSV, JSON, etc.)"
            ),
            "generic_s3_error": (
                f"1. Check the S3 path in YAML config and verify it exists{path_hint} | "
                "2. Verify IAM role permissions for S3 access | "
                "3. Test with: aws s3 ls <path> using the Glue job role | "
                "4. Check CloudWatch logs for the full S3 exception stack trace"
            ),
        }
        return recommendations.get(sub_type, recommendations["generic_s3_error"])

    def transformation_mapping(self, finding):
        return {"artifact_type": "advisory", "action": "flag_bad_s3_path",
                "sub_type": finding.get("sub_type", "generic_s3_error"),
                "s3_path": finding.get("s3_path")}


@register_rule
class BrokenPipeErrorRule(RCARule):
    """Detects broken pipe and connection reset errors which indicate
    premature connection termination during data transfer."""
    rule_id = "RCA-052"
    rule_name = "Broken Pipe / Connection Reset Detection"
    category = "runtime_failure"

    def detect(self, artifacts):
        findings = []
        log_text = artifacts.get("log_text", "")
        if not log_text:
            return findings
        matched_lines = detect_log_patterns(log_text, BROKEN_PIPE_PATTERNS)
        if matched_lines:
            sub_type = "broken_pipe"
            sample = " ".join(matched_lines[:3]).lower()
            if any(kw in sample for kw in ("reset by peer", "connection reset")):
                sub_type = "connection_reset_by_peer"
            elif any(kw in sample for kw in ("eofexception", "premature end")):
                sub_type = "premature_eof"
            elif any(kw in sample for kw in ("closedchannel", "stream closed")):
                sub_type = "closed_channel"
            findings.append({
                "rule_id": self.rule_id,
                "description": f"Broken pipe / connection reset detected: {sub_type.replace('_', ' ')}",
                "artifact": "log", "matched_lines": matched_lines[:5],
                "sub_type": sub_type,
            })
        return findings

    def classify_severity(self, finding):
        return "high"

    def recommend_fix(self, finding):
        sub_type = finding.get("sub_type", "broken_pipe")
        recommendations = {
            "broken_pipe": (
                "1. Check if the target system (database/API/S3) is dropping connections due to idle timeout | "
                "2. Reduce batch/chunk size for writes to keep connections active | "
                "3. Add retry logic with exponential backoff for transient failures | "
                "4. Verify network stability between Glue VPC and target endpoint | "
                "5. If writing to JDBC, add socketTimeout and connectTimeout to JDBC URL"
            ),
            "connection_reset_by_peer": (
                "1. The remote server forcibly closed the connection -- check target server logs | "
                "2. Verify the target server can handle the write throughput (reduce parallelism with coalesce) | "
                "3. Check if a load balancer or proxy is terminating connections prematurely | "
                "4. Increase keepalive settings on both Glue job and target server | "
                "5. Add connection retry configuration in JDBC/HTTP client options"
            ),
            "premature_eof": (
                "1. Source data stream was interrupted -- check source system availability | "
                "2. If reading from S3, the file may be corrupted or still being written | "
                "3. Verify source file integrity (check S3 object size and ETag) | "
                "4. Add retry logic for transient S3/network failures | "
                "5. If reading compressed files, verify the compression format matches file extension"
            ),
            "closed_channel": (
                "1. Network connection was closed unexpectedly -- check VPC/NAT gateway limits | "
                "2. Verify no connection idle timeout is configured below the operation duration | "
                "3. Increase Spark network timeout: spark.network.timeout=600s | "
                "4. Check if Spark executor lost connection to driver due to GC pause or OOM | "
                "5. Review executor logs for the root cause of channel closure"
            ),
        }
        return recommendations.get(sub_type, recommendations["broken_pipe"])

    def transformation_mapping(self, finding):
        return {"artifact_type": "advisory", "action": "flag_broken_pipe",
                "sub_type": finding.get("sub_type", "broken_pipe")}


@register_rule
class ValueTooLongErrorRule(RCARule):
    """Detects data truncation errors when inserting values that exceed
    the target column length definition."""
    rule_id = "RCA-053"
    rule_name = "Value Too Long / Data Truncation Detection"
    category = "runtime_failure"

    def detect(self, artifacts):
        findings = []
        log_text = artifacts.get("log_text", "")
        if not log_text:
            return findings
        matched_lines = detect_log_patterns(log_text, VALUE_TOO_LONG_PATTERNS)
        if matched_lines:
            # Try to extract column name from error message
            column_name = None
            for line in matched_lines:
                m = re.search(r'column\s+["\']?(\w+)["\']?', line, re.IGNORECASE)
                if m:
                    column_name = m.group(1)
                    break
                m = re.search(r'for\s+(?:type\s+)?(?:character\s+)?(?:varying\s*)?\((\d+)\)', line, re.IGNORECASE)
                if m:
                    break
            findings.append({
                "rule_id": self.rule_id,
                "description": "Data truncation error -- value too long for target column definition"
                               + (f" (column: {column_name})" if column_name else ""),
                "artifact": "log", "matched_lines": matched_lines[:5],
                "column_name": column_name,
            })
        return findings

    def classify_severity(self, finding):
        return "high"

    def recommend_fix(self, finding):
        col = finding.get("column_name")
        col_hint = f" (column: {col})" if col else ""
        return (
            f"1. Identify the column causing truncation{col_hint} from the full error stack trace | "
            "2. Compare source data max length with target column definition | "
            "3. Option A: ALTER TABLE to increase the target column length to accommodate the data | "
            "4. Option B: Add a SUBSTRING/CAST in the SQL query or Python transform to trim the value | "
            "5. Option C: Add a data quality check before insert to flag/handle oversized values | "
            "6. If using Glue DynamicFrame, use ResolveChoice to handle type mismatches | "
            "7. Check if source data has changed schema (new longer values) and update DDL accordingly"
        )

    def transformation_mapping(self, finding):
        return {"artifact_type": "advisory", "action": "flag_value_too_long",
                "column_name": finding.get("column_name")}


@register_rule
class DuplicateConstraintErrorRule(RCARule):
    """Detects unique/primary key constraint violations when inserting
    duplicate records into the target database."""
    rule_id = "RCA-054"
    rule_name = "Duplicate / Unique Constraint Violation Detection"
    category = "runtime_failure"

    def detect(self, artifacts):
        findings = []
        log_text = artifacts.get("log_text", "")
        if not log_text:
            return findings
        matched_lines = detect_log_patterns(log_text, DUPLICATE_CONSTRAINT_PATTERNS)
        if matched_lines:
            # Try to extract constraint name or table name
            constraint_name = None
            table_name = None
            for line in matched_lines:
                m = re.search(r'constraint\s+["\']?(\w+)["\']?', line, re.IGNORECASE)
                if m:
                    constraint_name = m.group(1)
                m2 = re.search(r'(?:table|into)\s+["\']?(\w+)["\']?', line, re.IGNORECASE)
                if m2:
                    table_name = m2.group(1)
            desc_parts = ["Duplicate key / unique constraint violation detected"]
            if constraint_name:
                desc_parts.append(f"constraint: {constraint_name}")
            if table_name:
                desc_parts.append(f"table: {table_name}")
            findings.append({
                "rule_id": self.rule_id,
                "description": " -- ".join(desc_parts),
                "artifact": "log", "matched_lines": matched_lines[:5],
                "constraint_name": constraint_name,
                "table_name": table_name,
            })
        return findings

    def classify_severity(self, finding):
        return "high"

    def recommend_fix(self, finding):
        constraint = finding.get("constraint_name")
        table = finding.get("table_name")
        constraint_hint = f" (constraint: {constraint})" if constraint else ""
        table_hint = f" (table: {table})" if table else ""
        return (
            f"1. Identify the duplicate key column(s){constraint_hint}{table_hint} causing the violation | "
            "2. Option A: Add DISTINCT or GROUP BY in the source query to deduplicate before insert | "
            "3. Option B: Use MERGE/UPSERT (INSERT ON CONFLICT UPDATE) instead of plain INSERT | "
            "4. Option C: Add a dropDuplicates() call on the DataFrame before writing to the target | "
            "5. Option D: Use Spark df.dropDuplicates([key_columns]) to remove exact duplicates | "
            "6. Investigate why duplicates exist -- check if the source query JOINs are producing fan-out | "
            "7. If incremental load, ensure the watermark/filter correctly excludes already-loaded records | "
            "8. For idempotent loads, consider TRUNCATE + INSERT or staging table pattern"
        )

    def transformation_mapping(self, finding):
        return {"artifact_type": "advisory", "action": "flag_duplicate_constraint",
                "constraint_name": finding.get("constraint_name"),
                "table_name": finding.get("table_name")}


@register_rule
class PermissionDeniedErrorRule(RCARule):
    """Detects IAM/access permission errors when the Glue job role lacks
    required permissions for AWS services or database access."""
    rule_id = "RCA-055"
    rule_name = "Permission Denied / Access Error Detection"
    category = "runtime_failure"

    def detect(self, artifacts):
        findings = []
        log_text = artifacts.get("log_text", "")
        if not log_text:
            return findings
        matched_lines = detect_log_patterns(log_text, PERMISSION_DENIED_PATTERNS)
        if matched_lines:
            sub_type = "generic_permission"
            sample = " ".join(matched_lines[:3]).lower()
            if any(kw in sample for kw in ("iam", "policy", "not authorized")):
                sub_type = "iam_policy"
            elif any(kw in sample for kw in ("s3",)):
                sub_type = "s3_permission"
            findings.append({
                "rule_id": self.rule_id,
                "description": f"Permission denied error detected: {sub_type.replace('_', ' ')}",
                "artifact": "log", "matched_lines": matched_lines[:5],
                "sub_type": sub_type,
            })
        return findings

    def classify_severity(self, finding):
        return "critical"

    def recommend_fix(self, finding):
        sub_type = finding.get("sub_type", "generic_permission")
        recommendations = {
            "iam_policy": (
                "1. Check the Glue job IAM role and its attached policies | "
                "2. Use AWS CloudTrail to find the exact API call that was denied | "
                "3. Add the required permission to the IAM role policy (least-privilege) | "
                "4. Check for SCP (Service Control Policy) or permission boundary restrictions | "
                "5. Verify the IAM role trust policy allows Glue service to assume it"
            ),
            "s3_permission": (
                "1. Verify the Glue IAM role has s3:GetObject, s3:PutObject, s3:ListBucket as needed | "
                "2. Check S3 bucket policy for explicit deny statements | "
                "3. If cross-account, ensure both IAM role and bucket policy grant access | "
                "4. Check for S3 VPC endpoint policy restrictions | "
                "5. Verify no S3 Block Public Access setting is interfering (for cross-account)"
            ),
            "generic_permission": (
                "1. Identify the AWS service and API call being denied from the error message | "
                "2. Check the Glue job IAM role permissions in the IAM console | "
                "3. Use AWS CloudTrail Event History to find the denied API call and required permission | "
                "4. Add the required permission to the Glue IAM role | "
                "5. Check for organization-level SCPs or permission boundaries that may restrict access"
            ),
        }
        return recommendations.get(sub_type, recommendations["generic_permission"])

    def transformation_mapping(self, finding):
        return {"artifact_type": "advisory", "action": "flag_permission_denied",
                "sub_type": finding.get("sub_type", "generic_permission")}


@register_rule
class SchemaMismatchErrorRule(RCARule):
    """Detects schema mismatch errors where source data schema does not match
    the expected schema or target table definition."""
    rule_id = "RCA-056"
    rule_name = "Schema Mismatch / Type Cast Error Detection"
    category = "runtime_failure"

    def detect(self, artifacts):
        findings = []
        log_text = artifacts.get("log_text", "")
        if not log_text:
            return findings
        matched_lines = detect_log_patterns(log_text, SCHEMA_MISMATCH_PATTERNS)
        if matched_lines:
            sub_type = "generic_schema_error"
            sample = " ".join(matched_lines[:3]).lower()
            if any(kw in sample for kw in ("cannot resolve", "column.*not found", "not found")):
                sub_type = "missing_column"
            elif any(kw in sample for kw in ("cannot cast", "data type mismatch", "numberformat", "classcast")):
                sub_type = "type_mismatch"
            elif any(kw in sample for kw in ("incompatible.*schema", "does not match")):
                sub_type = "schema_evolution"
            # Try to extract column name
            column_name = None
            for line in matched_lines:
                m = re.search(r'(?:column|resolve)\s+[`"\']?(\w+)[`"\']?', line, re.IGNORECASE)
                if m:
                    column_name = m.group(1)
                    break
            findings.append({
                "rule_id": self.rule_id,
                "description": f"Schema mismatch error: {sub_type.replace('_', ' ')}"
                               + (f" (column: {column_name})" if column_name else ""),
                "artifact": "log", "matched_lines": matched_lines[:5],
                "sub_type": sub_type, "column_name": column_name,
            })
        return findings

    def classify_severity(self, finding):
        return "high"

    def recommend_fix(self, finding):
        sub_type = finding.get("sub_type", "generic_schema_error")
        col = finding.get("column_name")
        col_hint = f" (column: {col})" if col else ""
        recommendations = {
            "missing_column": (
                f"1. Verify the column{col_hint} exists in the source data/table | "
                "2. Check if the source schema has changed (column renamed or removed) | "
                "3. Use printSchema() to inspect the actual DataFrame schema before the failing operation | "
                "4. If using Glue DynamicFrame, use ApplyMapping to handle schema changes gracefully | "
                "5. Add schema validation at the start of the job to fail fast with clear error messages"
            ),
            "type_mismatch": (
                f"1. Check the data type of column{col_hint} in source vs target schema | "
                "2. Add explicit CAST() in SQL or .cast() in PySpark to convert types correctly | "
                "3. Handle null values that may cause type inference issues | "
                "4. Use Glue ResolveChoice to handle ambiguous types in DynamicFrames | "
                "5. Verify that numeric columns do not contain non-numeric strings in the source data"
            ),
            "schema_evolution": (
                "1. Source schema has evolved -- compare current vs expected schema | "
                "2. Use mergeSchema option for Parquet reads: .option('mergeSchema', 'true') | "
                "3. Update the target table DDL to match the new source schema | "
                "4. Use Glue DynamicFrame with ApplyMapping for explicit schema transformation | "
                "5. Consider implementing a schema registry or validation step before processing"
            ),
            "generic_schema_error": (
                f"1. Compare source and target schemas to find the mismatch{col_hint} | "
                "2. Use df.printSchema() to inspect the actual DataFrame schema | "
                "3. Add explicit type casting or column mapping to handle differences | "
                "4. Check if the data source has changed its schema since the job was written"
            ),
        }
        return recommendations.get(sub_type, recommendations["generic_schema_error"])

    def transformation_mapping(self, finding):
        return {"artifact_type": "advisory", "action": "flag_schema_mismatch",
                "sub_type": finding.get("sub_type", "generic_schema_error"),
                "column_name": finding.get("column_name")}


@register_rule
class NullConstraintErrorRule(RCARule):
    """Detects NOT NULL constraint violations and NullPointerExceptions
    when processing or inserting null values into non-nullable columns."""
    rule_id = "RCA-057"
    rule_name = "NULL Constraint / NullPointerException Detection"
    category = "runtime_failure"

    def detect(self, artifacts):
        findings = []
        log_text = artifacts.get("log_text", "")
        if not log_text:
            return findings
        matched_lines = detect_log_patterns(log_text, NULL_CONSTRAINT_PATTERNS)
        if matched_lines:
            sub_type = "null_constraint"
            sample = " ".join(matched_lines[:3]).lower()
            if "nullpointerexception" in sample:
                sub_type = "null_pointer"
            column_name = None
            for line in matched_lines:
                m = re.search(r'column\s+["\']?(\w+)["\']?', line, re.IGNORECASE)
                if m:
                    column_name = m.group(1)
                    break
            findings.append({
                "rule_id": self.rule_id,
                "description": f"NULL constraint violation detected: {sub_type.replace('_', ' ')}"
                               + (f" (column: {column_name})" if column_name else ""),
                "artifact": "log", "matched_lines": matched_lines[:5],
                "sub_type": sub_type, "column_name": column_name,
            })
        return findings

    def classify_severity(self, finding):
        sub_type = finding.get("sub_type", "null_constraint")
        return "critical" if sub_type == "null_pointer" else "high"

    def recommend_fix(self, finding):
        sub_type = finding.get("sub_type", "null_constraint")
        col = finding.get("column_name")
        col_hint = f" (column: {col})" if col else ""
        if sub_type == "null_pointer":
            return (
                "1. NullPointerException indicates a code-level null reference -- check variable initialization | "
                "2. Verify DataFrame operations are not performed on a null/empty DataFrame | "
                "3. Add null checks: if df is not None and df.count() > 0 | "
                "4. Check if a Spark action (collect, first) returned None on an empty DataFrame | "
                "5. Review the full stack trace to identify the exact line and variable causing the NPE"
            )
        return (
            f"1. Identify the NOT NULL column{col_hint} causing the constraint violation | "
            "2. Add .fillna() or .na.fill() to provide default values for null columns before insert | "
            "3. Add a WHERE clause to filter out rows with null values in required columns | "
            "4. Use COALESCE() in SQL to provide fallback values: COALESCE(column, default_value) | "
            "5. Add a data quality check to identify and log rows with unexpected nulls | "
            "6. If using Glue DynamicFrame, use Filter transform to remove null rows"
        )

    def transformation_mapping(self, finding):
        return {"artifact_type": "advisory", "action": "flag_null_constraint",
                "sub_type": finding.get("sub_type", "null_constraint"),
                "column_name": finding.get("column_name")}


@register_rule
class SerializationErrorRule(RCARule):
    """Detects Spark serialization errors when tasks or objects cannot be
    serialized for distribution across executors."""
    rule_id = "RCA-058"
    rule_name = "Task Serialization Error Detection"
    category = "runtime_failure"

    def detect(self, artifacts):
        findings = []
        log_text = artifacts.get("log_text", "")
        if not log_text:
            return findings
        matched_lines = detect_log_patterns(log_text, SERIALIZATION_ERROR_PATTERNS)
        if matched_lines:
            sub_type = "java_serialization"
            sample = " ".join(matched_lines[:3]).lower()
            if any(kw in sample for kw in ("pickle", "cannot pickle")):
                sub_type = "python_pickle"
            findings.append({
                "rule_id": self.rule_id,
                "description": f"Serialization error detected: {sub_type.replace('_', ' ')}",
                "artifact": "log", "matched_lines": matched_lines[:5],
                "sub_type": sub_type,
            })
        return findings

    def classify_severity(self, finding):
        return "critical"

    def recommend_fix(self, finding):
        sub_type = finding.get("sub_type", "java_serialization")
        if sub_type == "python_pickle":
            return (
                "1. Check for non-serializable objects (DB connections, file handles) used inside UDFs | "
                "2. Move non-serializable object creation inside the UDF function body | "
                "3. Use broadcast variables for large read-only data instead of closures | "
                "4. Replace Python UDFs with Spark-native functions where possible | "
                "5. For PySpark, avoid referencing self or class instances inside map/filter lambdas"
            )
        return (
            "1. Check for non-serializable objects referenced in Spark transformations | "
            "2. Make referenced classes implement java.io.Serializable | "
            "3. Move object creation (DB connections, clients) inside mapPartitions instead of map | "
            "4. Use broadcast variables for large shared read-only data | "
            "5. Enable Kryo serialization: spark.serializer=org.apache.spark.serializer.KryoSerializer | "
            "6. Register custom classes with Kryo: spark.kryo.classesToRegister"
        )

    def transformation_mapping(self, finding):
        return {"artifact_type": "advisory", "action": "flag_serialization_error",
                "sub_type": finding.get("sub_type", "java_serialization")}


@register_rule
class ResourceLimitErrorRule(RCARule):
    """Detects AWS service throttling, rate limiting, and resource
    quota exceeded errors."""
    rule_id = "RCA-059"
    rule_name = "Resource Limit / Throttling Error Detection"
    category = "runtime_failure"

    def detect(self, artifacts):
        findings = []
        log_text = artifacts.get("log_text", "")
        if not log_text:
            return findings
        matched_lines = detect_log_patterns(log_text, RESOURCE_LIMIT_PATTERNS)
        if matched_lines:
            sub_type = "generic_throttle"
            sample = " ".join(matched_lines[:3]).lower()
            if any(kw in sample for kw in ("throttl", "rate exceeded", "slow down")):
                sub_type = "api_throttling"
            elif any(kw in sample for kw in ("service unavailable",)):
                sub_type = "service_unavailable"
            elif any(kw in sample for kw in ("concurrent", "limit.*exceeded")):
                sub_type = "concurrency_limit"
            findings.append({
                "rule_id": self.rule_id,
                "description": f"Resource limit / throttling error detected: {sub_type.replace('_', ' ')}",
                "artifact": "log", "matched_lines": matched_lines[:5],
                "sub_type": sub_type,
            })
        return findings

    def classify_severity(self, finding):
        return "high"

    def recommend_fix(self, finding):
        sub_type = finding.get("sub_type", "generic_throttle")
        recommendations = {
            "api_throttling": (
                "1. Add exponential backoff and retry logic for AWS API calls | "
                "2. Reduce the number of parallel API calls (lower Spark partition count) | "
                "3. Use batch API operations instead of individual calls where available | "
                "4. Request a service quota increase via AWS Support if hitting account limits | "
                "5. Spread the load across multiple time windows to avoid peak-hour throttling"
            ),
            "service_unavailable": (
                "1. The AWS service is temporarily unavailable -- retry the job after a few minutes | "
                "2. Add retry logic with exponential backoff (recommended: 3 retries, base 2s) | "
                "3. Check AWS Health Dashboard for any ongoing service disruptions | "
                "4. If persistent, contact AWS Support to investigate the service endpoint"
            ),
            "concurrency_limit": (
                "1. Check AWS Glue concurrent job run limits (default: 200 per account) | "
                "2. Reduce concurrent job runs or stagger job scheduling | "
                "3. Request a Glue concurrency limit increase via AWS Support | "
                "4. Review job scheduling to avoid multiple large jobs running simultaneously | "
                "5. Consider breaking the job into smaller batches that run sequentially"
            ),
            "generic_throttle": (
                "1. Identify which AWS service is being throttled from the error message | "
                "2. Add exponential backoff retry logic for the throttled API calls | "
                "3. Reduce concurrency (fewer Spark partitions or workers) | "
                "4. Request a quota increase for the specific service limit | "
                "5. Review and optimize API call patterns to reduce request volume"
            ),
        }
        return recommendations.get(sub_type, recommendations["generic_throttle"])

    def transformation_mapping(self, finding):
        return {"artifact_type": "advisory", "action": "flag_resource_limit",
                "sub_type": finding.get("sub_type", "generic_throttle")}


@register_rule
class FileFormatErrorRule(RCARule):
    """Detects file format errors when reading source data files that are
    corrupted, in an unexpected format, or have malformed records."""
    rule_id = "RCA-060"
    rule_name = "File Format / Corrupt Data Detection"
    category = "runtime_failure"

    def detect(self, artifacts):
        findings = []
        log_text = artifacts.get("log_text", "")
        if not log_text:
            return findings
        matched_lines = detect_log_patterns(log_text, FILE_FORMAT_ERROR_PATTERNS)
        if matched_lines:
            sub_type = "generic_format_error"
            sample = " ".join(matched_lines[:3]).lower()
            if any(kw in sample for kw in ("parquet", "footer")):
                sub_type = "parquet_error"
            elif any(kw in sample for kw in ("csv", "malformed")):
                sub_type = "csv_error"
            elif any(kw in sample for kw in ("json",)):
                sub_type = "json_error"
            elif any(kw in sample for kw in ("corrupt",)):
                sub_type = "corrupt_file"
            elif any(kw in sample for kw in ("unable to infer schema",)):
                sub_type = "schema_inference"
            findings.append({
                "rule_id": self.rule_id,
                "description": f"File format error detected: {sub_type.replace('_', ' ')}",
                "artifact": "log", "matched_lines": matched_lines[:5],
                "sub_type": sub_type,
            })
        return findings

    def classify_severity(self, finding):
        return "high"

    def recommend_fix(self, finding):
        sub_type = finding.get("sub_type", "generic_format_error")
        recommendations = {
            "parquet_error": (
                "1. The Parquet file is corrupted or not a valid Parquet file | "
                "2. Verify the file was written completely (check S3 multipart upload completion) | "
                "3. If the file was generated by another process, verify it uses a compatible Parquet version | "
                "4. Try reading with .option('mergeSchema', 'true') to handle schema differences | "
                "5. Re-generate the source file or restore from backup"
            ),
            "csv_error": (
                "1. Check the CSV delimiter, quote character, and escape settings match the actual file | "
                "2. Add .option('mode', 'PERMISSIVE') to skip malformed rows (logs to _corrupt_record) | "
                "3. Check for unescaped delimiters or newlines within fields | "
                "4. Add .option('multiLine', 'true') if CSV fields contain embedded newlines | "
                "5. Verify the file encoding (UTF-8, Latin-1, etc.) matches the read configuration"
            ),
            "json_error": (
                "1. Verify the JSON file is valid JSON (use jsonlint or python -m json.tool) | "
                "2. Add .option('mode', 'PERMISSIVE') to handle malformed JSON records | "
                "3. Check if the file is newline-delimited JSON (NDJSON) vs array JSON | "
                "4. Add .option('multiLine', 'true') for multi-line JSON files | "
                "5. Verify file encoding is UTF-8"
            ),
            "corrupt_file": (
                "1. The source file appears to be corrupted -- verify file integrity | "
                "2. Check S3 object metadata (size, ETag) against expected values | "
                "3. Re-download or re-generate the source file | "
                "4. If compressed, verify the compression format matches the file extension | "
                "5. Check if the file was partially uploaded (interrupted multipart upload)"
            ),
            "schema_inference": (
                "1. Provide an explicit schema instead of relying on schema inference | "
                "2. Use .schema(StructType([...])) when reading the DataFrame | "
                "3. Check if the source file is empty (Spark cannot infer schema from empty files) | "
                "4. For CSV, add .option('header', 'true') if the first row contains column names | "
                "5. Verify the source path contains at least one valid file with data"
            ),
            "generic_format_error": (
                "1. Verify the source file format matches the read format (Parquet, CSV, JSON, etc.) | "
                "2. Check for file corruption or incomplete uploads | "
                "3. Add .option('mode', 'PERMISSIVE') to handle malformed records gracefully | "
                "4. Provide an explicit schema to avoid inference errors | "
                "5. Test reading the file locally to reproduce and diagnose the format issue"
            ),
        }
        return recommendations.get(sub_type, recommendations["generic_format_error"])

    def transformation_mapping(self, finding):
        return {"artifact_type": "advisory", "action": "flag_file_format_error",
                "sub_type": finding.get("sub_type", "generic_format_error")}


# --- Missing Cache/Persist for Reused DataFrames ---

@register_rule
class MissingCachePersistRule(RCARule):
    """Detects DataFrames that are reused multiple times in the code without
    being cached or persisted. Each reuse triggers a full recomputation of the
    DAG, leading to redundant I/O, shuffles, and compute cycles.

    Detection logic:
    - Walk the AST to find all DataFrame variable assignments
    - Count how many times each variable is referenced in subsequent operations
    - Flag variables referenced 2+ times that lack a .cache() or .persist() call
    - Exclude loop variables and single-use intermediates
    """
    rule_id = "RCA-061"
    rule_name = "Missing cache()/persist() for Reused DataFrame"
    category = "spark_antipattern"

    # Minimum number of reuses to trigger a recommendation
    MIN_REUSE_THRESHOLD = 2

    # Common DataFrame creation patterns (methods that return a new DataFrame)
    DF_CREATION_METHODS = {
        'read', 'load', 'sql', 'table', 'select', 'filter', 'where',
        'groupBy', 'agg', 'join', 'union', 'unionAll', 'unionByName',
        'withColumn', 'withColumnRenamed', 'drop', 'distinct', 'dropDuplicates',
        'orderBy', 'sort', 'limit', 'repartition', 'coalesce',
        'crossJoin', 'subtract', 'intersect', 'exceptAll',
        'from_catalog', 'from_options', 'fromDF',
        'create_dynamic_frame', 'DynamicFrame',
    }

    # Spark actions that consume a DataFrame (each triggers full DAG execution)
    DF_ACTIONS = {
        'count', 'collect', 'show', 'take', 'first', 'head', 'toPandas',
        'foreach', 'foreachPartition', 'write', 'save', 'insertInto',
        'write_dynamic_frame', 'getSink', 'purge_table',
    }

    # Spark transformations that consume a DataFrame as input
    DF_TRANSFORMS = {
        'select', 'filter', 'where', 'groupBy', 'agg', 'join',
        'union', 'unionAll', 'unionByName', 'withColumn', 'withColumnRenamed',
        'drop', 'distinct', 'dropDuplicates', 'orderBy', 'sort', 'limit',
        'repartition', 'coalesce', 'crossJoin', 'subtract', 'intersect',
        'alias', 'toDF', 'printSchema', 'dtypes', 'columns', 'schema',
        'apply', 'ApplyMapping', 'apply_mapping', 'resolveChoice',
    }

    def detect(self, artifacts):
        findings = []
        py_source = artifacts.get("python_source", "")
        tree, _ = safe_parse_ast(py_source)
        if tree is None:
            return findings

        # Step 1: Find all DataFrame-like variable assignments
        df_vars = {}  # var_name -> assignment line number
        for node in ast.walk(tree):
            if isinstance(node, ast.Assign) and len(node.targets) == 1:
                target = node.targets[0]
                if isinstance(target, ast.Name):
                    var_name = target.id
                    if self._is_df_creation(node.value):
                        df_vars[var_name] = node.lineno

        # Step 2: Find which df_vars are cached/persisted
        cached_vars = set()
        source_lines = py_source.splitlines()
        for line in source_lines:
            for var in df_vars:
                if re.search(rf'\b{re.escape(var)}\.(?:cache|persist)\s*\(', line):
                    cached_vars.add(var)

        # Step 3: Count reuses of each uncached variable
        uncached_vars = set(df_vars.keys()) - cached_vars
        reuse_counts = {}
        for node in ast.walk(tree):
            # Count attribute accesses like df.method()
            if isinstance(node, ast.Attribute) and isinstance(node.value, ast.Name):
                var_name = node.value.id
                if var_name in uncached_vars:
                    attr = node.attr
                    if attr in self.DF_ACTIONS or attr in self.DF_TRANSFORMS:
                        reuse_counts[var_name] = reuse_counts.get(var_name, 0) + 1
            # Count direct function call args like join(df, ...)
            if isinstance(node, ast.Call):
                for arg in node.args:
                    if isinstance(arg, ast.Name) and arg.id in uncached_vars:
                        reuse_counts[arg.id] = reuse_counts.get(arg.id, 0) + 1

        # Step 4: Flag variables reused above threshold
        for var_name, count in reuse_counts.items():
            if count >= self.MIN_REUSE_THRESHOLD:
                findings.append({
                    "rule_id": self.rule_id,
                    "description": (
                        f"DataFrame '{var_name}' is used {count} times without cache()/persist(). "
                        f"Each reuse recomputes the entire DAG from scratch."
                    ),
                    "artifact": "python",
                    "line": df_vars.get(var_name),
                    "var_name": var_name,
                    "reuse_count": count,
                })
        return findings

    def _is_df_creation(self, node):
        """Check if an AST node looks like a DataFrame creation expression."""
        if isinstance(node, ast.Call):
            # Check direct function calls: spark.read.csv(...), DynamicFrame.fromDF(...)
            if isinstance(node.func, ast.Attribute):
                if node.func.attr in self.DF_CREATION_METHODS:
                    return True
                # Chained: spark.read.format(...).load(...)
                if isinstance(node.func.value, ast.Call):
                    return self._is_df_creation(node.func.value)
            if isinstance(node.func, ast.Name):
                if node.func.id in ('DynamicFrame', 'DataFrame'):
                    return True
        # Check attribute access that returns a DF: glueContext.create_dynamic_frame
        if isinstance(node, ast.Attribute) and node.attr in self.DF_CREATION_METHODS:
            return True
        return False

    def classify_severity(self, finding):
        count = finding.get("reuse_count", 0)
        if count >= 4:
            return "high"
        return "medium"

    def recommend_fix(self, finding):
        var = finding.get("var_name", "df")
        count = finding.get("reuse_count", 0)
        line = finding.get("line", "?")
        return (
            f"Add {var}.cache() (or .persist(StorageLevel.MEMORY_AND_DISK)) after line {line} "
            f"where '{var}' is created. This DataFrame is consumed {count} times -- caching "
            f"prevents {count - 1} redundant DAG recomputations. "
            f"Remember to add {var}.unpersist() when the DataFrame is no longer needed."
        )

    def transformation_mapping(self, finding):
        return {
            "artifact_type": "python",
            "action": "insert_cache_persist",
            "line": finding.get("line"),
            "var_name": finding.get("var_name"),
            "reuse_count": finding.get("reuse_count"),
        }


# --- Data Volume / No-Findings Advisory ---

@register_rule
class AllOptimizedStillSlowRule(RCARule):
    """Detects when a job exceeds threshold but all code, config, and SQL
    appear correctly optimized.  This indicates the root cause is likely
    the raw data volume itself, which cannot be resolved through code or
    config changes alone.

    This rule runs LAST (Phase 2) and only fires when NO other rule has
    produced findings for the same job.  The engine checks this via the
    _no_other_findings flag injected into artifacts by _process_job.
    """
    rule_id = "RCA-046"
    rule_name = "All-Optimized-But-Still-Slow Advisory"
    category = "data_volume_advisory"

    def detect(self, artifacts):
        findings = []
        # This rule only fires when the engine sets _no_other_findings = True
        if not artifacts.get("_no_other_findings"):
            return findings
        exec_dur = artifacts.get("_execution_duration", 0)
        threshold = artifacts.get("_threshold_limit", 0)
        if exec_dur > threshold and threshold > 0:
            ratio = round(exec_dur / threshold, 1)
            findings.append({
                "rule_id": self.rule_id,
                "description": (
                    f"Job exceeds threshold by {ratio}x ({exec_dur}min vs {threshold}min limit) "
                    f"but no code, SQL, or configuration anti-patterns were detected. "
                    f"This strongly suggests the performance issue is driven by raw data volume. "
                    f"Since this engine does not inspect actual data, a manual data investigation "
                    f"is recommended: check row counts, partition sizes, data skew distribution, "
                    f"and whether source tables have grown significantly."
                ),
                "artifact": "advisory",
                "exec_duration": exec_dur,
                "threshold": threshold,
                "ratio": ratio,
            })
        return findings

    def classify_severity(self, finding):
        ratio = finding.get("ratio", 1)
        if ratio >= 3:
            return "critical"
        elif ratio >= 2:
            return "high"
        return "medium"

    def recommend_fix(self, finding):
        ratio = finding.get("ratio", 1)
        recommendations = [
            "Investigate source data volume -- check if tables have grown significantly",
            "Analyze partition sizes and distribution for data skew",
            "Consider implementing incremental processing (process only new/changed data)",
            "Evaluate data retention policies to reduce historical data processed",
        ]
        if ratio >= 3:
            recommendations.append(
                "CRITICAL: Job is running 3x+ over threshold with no detectable code issues. "
                "This requires a data architecture review -- possible solutions include: "
                "table partitioning strategy, data archival, or switching to incremental ETL"
            )
        return " | ".join(recommendations)

    def transformation_mapping(self, finding):
        # No artifact modification -- this is an advisory-only finding
        return {"artifact_type": "advisory", "action": "data_volume_advisory"}


# --- Spark/Glue Version Configuration Issues ---

@register_rule
class SparkGlueVersionConfigRule(RCARule):
    """Detects Spark configuration issues related to AWS Glue versions.

    Common issues:
    - Glue 2.0 uses Spark 2.4 which doesn't support AQE (Adaptive Query Execution)
    - Glue 3.0 uses Spark 3.1 -- AQE available but not enabled by default
    - Glue 4.0 uses Spark 3.3 -- AQE enabled by default but may need tuning
    - Missing spark.sql.shuffle.partitions (defaults to 200, may be wrong)
    - Missing spark.sql.adaptive.enabled for Glue 3.0
    - Deprecated Spark configs for newer Glue versions
    - Missing spark.serializer (Kryo is faster than default Java)
    """
    rule_id = "RCA-047"
    rule_name = "Spark/Glue Version Configuration Analysis"
    category = "config_issue"

    GLUE_SPARK_MAP = {
        "0.9": "2.2", "1.0": "2.4", "2.0": "2.4",
        "3.0": "3.1", "4.0": "3.3", "5.0": "3.5",
    }

    def detect(self, artifacts):
        findings = []
        yml_config = artifacts.get("yml_config")
        py_source = artifacts.get("python_source", "")

        yml_source = artifacts.get("yml_source", "")
        # Detect Glue version from YAML config, raw YAML text, or Python source
        glue_version = self._detect_glue_version(yml_config, py_source, yml_source)
        spark_configs = self._extract_spark_configs(yml_config, py_source)

        if glue_version:
            spark_version = self.GLUE_SPARK_MAP.get(glue_version, "unknown")
            # Check for invalid/unknown Glue version
            if glue_version not in self.GLUE_SPARK_MAP:
                findings.append({
                    "rule_id": self.rule_id,
                    "description": (
                        f"GlueVersion {glue_version} is invalid -- AWS Glue only supports versions "
                        f"{', '.join(sorted(self.GLUE_SPARK_MAP.keys()))}. "
                        f"Recommend changing to 4.0 (Spark 3.3 with AQE enabled by default)."
                    ),
                    "artifact": "yaml", "issue_type": "invalid_glue_version",
                    "glue_version": glue_version,
                })
            # Check for AQE issues
            elif glue_version in ("2.0", "1.0", "0.9"):
                if spark_configs.get("spark.sql.adaptive.enabled"):
                    findings.append({
                        "rule_id": self.rule_id,
                        "description": (
                            f"Glue version {glue_version} uses Spark {spark_version} which does NOT support "
                            f"Adaptive Query Execution (AQE). spark.sql.adaptive.enabled config will be ignored. "
                            f"Consider upgrading to Glue 3.0+ for AQE support."
                        ),
                        "artifact": "yaml", "issue_type": "aqe_not_supported",
                        "glue_version": glue_version, "spark_version": spark_version,
                    })
            elif glue_version == "3.0":
                if not spark_configs.get("spark.sql.adaptive.enabled"):
                    findings.append({
                        "rule_id": self.rule_id,
                        "description": (
                            f"Glue version 3.0 uses Spark 3.1 -- AQE is available but NOT enabled by default. "
                            f"Enable spark.sql.adaptive.enabled=true for automatic shuffle partition coalescing "
                            f"and join optimization."
                        ),
                        "artifact": "yaml", "issue_type": "aqe_not_enabled",
                        "glue_version": glue_version, "spark_version": spark_version,
                    })

        # Check for missing recommended Spark configs regardless of version
        json_source = artifacts.get("json_source", "")
        if not spark_configs.get("spark.serializer"):
            # Flag if there are JOINs or shuffles in Python code OR SQL in JSON config
            has_shuffle_ops = bool(
                re.search(r'\.(join|groupBy|reduceByKey|repartition)\s*\(', py_source)
                or re.search(r'\bJOIN\b', json_source, re.IGNORECASE)
                or re.search(r'\bGROUP\s+BY\b', json_source, re.IGNORECASE)
            )
            if has_shuffle_ops:
                findings.append({
                    "rule_id": self.rule_id,
                    "description": (
                        "spark.serializer is not set -- defaults to Java serialization which is slow. "
                        "Set spark.serializer=org.apache.spark.serializer.KryoSerializer for 2-10x "
                        "faster serialization during shuffles and joins."
                    ),
                    "artifact": "yaml", "issue_type": "missing_kryo_serializer",
                    "glue_version": glue_version or "unknown",
                })

        # Check shuffle partitions -- flag both misconfigured AND missing
        shuffle_partitions = spark_configs.get("spark.sql.shuffle.partitions")
        if not shuffle_partitions:
            # Missing entirely -- recommend based on data volume
            log_text = artifacts.get("log_text", "")
            row_counts = extract_row_counts_from_log(log_text)
            total_rows = sum(row_counts) if row_counts else 0
            has_shuffle_ops = bool(
                re.search(r'\bJOIN\b', json_source, re.IGNORECASE)
                or re.search(r'\bGROUP\s+BY\b', json_source, re.IGNORECASE)
                or re.search(r'\.(join|groupBy|repartition)\s*\(', py_source)
            )
            if has_shuffle_ops and total_rows > 0:
                if total_rows > 100_000_000:
                    rec = "500-2000"
                elif total_rows > 10_000_000:
                    rec = "200-500"
                elif total_rows > 1_000_000:
                    rec = "50-200"
                else:
                    rec = "20-50"
                findings.append({
                    "rule_id": self.rule_id,
                    "description": (
                        f"spark.sql.shuffle.partitions is not configured (defaults to 200). "
                        f"With {total_rows:,} total rows and shuffle operations (JOINs/GROUP BY), "
                        f"recommend setting to {rec} for optimal parallelism."
                    ),
                    "artifact": "yaml", "issue_type": "missing_shuffle_partitions",
                    "total_rows": total_rows,
                })
        if shuffle_partitions:
            try:
                sp_val = int(shuffle_partitions)
                log_text = artifacts.get("log_text", "")
                row_counts = extract_row_counts_from_log(log_text)
                total_rows = sum(row_counts) if row_counts else 0
                if total_rows > 100_000_000 and sp_val < 500:
                    findings.append({
                        "rule_id": self.rule_id,
                        "description": (
                            f"spark.sql.shuffle.partitions={sp_val} is too low for {total_rows:,} rows. "
                            f"Recommend 500-2000 partitions for datasets >100M rows to prevent memory pressure "
                            f"and shuffle spills."
                        ),
                        "artifact": "yaml", "issue_type": "low_shuffle_partitions",
                        "current_value": sp_val, "recommended_min": 500,
                    })
                elif total_rows < 100_000 and sp_val > 200:
                    findings.append({
                        "rule_id": self.rule_id,
                        "description": (
                            f"spark.sql.shuffle.partitions={sp_val} is unnecessarily high for {total_rows:,} rows. "
                            f"Recommend 20-50 partitions for small datasets to reduce task scheduling overhead."
                        ),
                        "artifact": "yaml", "issue_type": "high_shuffle_partitions",
                        "current_value": sp_val, "recommended_max": 50,
                    })
            except (ValueError, TypeError):
                pass

        # Check for deprecated Glue 2.0 configs used with Glue 3.0+
        glue_ver_float = 0.0
        try:
            glue_ver_float = float(glue_version) if glue_version else 0.0
        except (ValueError, TypeError):
            pass
        if glue_ver_float >= 3.0:
            deprecated_configs = {
                "spark.yarn.executor.memoryOverhead": "Use spark.executor.memoryOverhead instead (YARN prefix deprecated in Spark 3.x)",
                "spark.yarn.driver.memoryOverhead": "Use spark.driver.memoryOverhead instead (YARN prefix deprecated in Spark 3.x)",
            }
            for dep_key, dep_msg in deprecated_configs.items():
                if dep_key in spark_configs:
                    findings.append({
                        "rule_id": self.rule_id,
                        "description": f"Deprecated config '{dep_key}' found for Glue {glue_version}. {dep_msg}",
                        "artifact": "yaml", "issue_type": "deprecated_config",
                        "deprecated_key": dep_key, "glue_version": glue_version,
                    })

        # --- NEW: Detect setMaster("local") in Python source ---
        if py_source:
            for m in re.finditer(r'\.setMaster\s*\(\s*["\']local["\']', py_source):
                line_no = py_source[:m.start()].count('\n') + 1
                findings.append({
                    "rule_id": self.rule_id,
                    "description": (
                        "setMaster('local') forces single-JVM execution, negating the entire "
                        "Glue distributed cluster. Remove setMaster() and let Glue manage the "
                        "SparkContext via GlueContext."
                    ),
                    "artifact": "python", "issue_type": "set_master_local",
                    "line": line_no,
                })

        # --- NEW: Detect manual memory overrides that conflict with Glue worker types ---
        glue_managed_memory_keys = {
            "spark.driver.memory": "Glue manages driver memory based on WorkerType; manual override conflicts with G.1X=16GB, G.2X=32GB limits",
            "spark.executor.memory": "Glue manages executor memory based on WorkerType; manual override conflicts with worker allocation",
            "spark.yarn.executor.memory": "Deprecated in Glue 3.0+; Glue manages executor memory via WorkerType",
        }
        if py_source:
            for mem_key, mem_msg in glue_managed_memory_keys.items():
                for m in re.finditer(
                    rf'conf\.set\s*\(\s*["\']({re.escape(mem_key)})["\']\s*,\s*["\']([^"\']+)["\']',
                    py_source
                ):
                    line_no = py_source[:m.start()].count('\n') + 1
                    findings.append({
                        "rule_id": self.rule_id,
                        "description": (
                            f"Manual memory override '{mem_key}={m.group(2)}' found in Python source. "
                            f"{mem_msg}. Remove this line and configure WorkerType in YAML instead."
                        ),
                        "artifact": "python", "issue_type": "manual_memory_override",
                        "line": line_no, "config_key": mem_key, "config_value": m.group(2),
                    })

        # --- NEW: Detect invalid/no-op Spark config keys ---
        invalid_config_keys = {
            "spark.sql.optimizer": "Not a valid Spark config key; Catalyst optimizer is always enabled. Remove this line.",
        }
        if py_source:
            for inv_key, inv_msg in invalid_config_keys.items():
                for m in re.finditer(
                    rf'conf\.set\s*\(\s*["\']({re.escape(inv_key)})["\']\s*,',
                    py_source
                ):
                    line_no = py_source[:m.start()].count('\n') + 1
                    findings.append({
                        "rule_id": self.rule_id,
                        "description": f"Invalid config key '{inv_key}' found. {inv_msg}",
                        "artifact": "python", "issue_type": "invalid_config_key",
                        "line": line_no, "config_key": inv_key,
                    })

        # --- NEW: Detect autoBroadcastJoinThreshold disabled (-1) ---
        broadcast_val = spark_configs.get("spark.sql.autoBroadcastJoinThreshold")
        if broadcast_val and str(broadcast_val).strip() == "-1":
            # Find the line in Python source for precise commenting
            bcast_line = None
            if py_source:
                for m in re.finditer(r'autoBroadcastJoinThreshold.*-1', py_source):
                    bcast_line = py_source[:m.start()].count('\n') + 1
                    break
            findings.append({
                "rule_id": self.rule_id,
                "description": (
                    "spark.sql.autoBroadcastJoinThreshold=-1 completely disables broadcast joins, "
                    "forcing expensive shuffle-based SortMergeJoin even when one table is small. "
                    "Set to 10485760 (10MB) to re-enable."
                ),
                "artifact": "python" if bcast_line else "yaml",
                "issue_type": "broadcast_join_disabled",
                "line": bcast_line,
            })

        # --- NEW: Detect manual SparkConf+SparkContext that should be Glue-managed ---
        if py_source and re.search(r'SparkConf\s*\(', py_source):
            # Check if GlueContext is also used (meaning this is a Glue job)
            if re.search(r'GlueContext', py_source):
                # Find lines with SparkConf() creation
                for m in re.finditer(r'(SparkConf\s*\(\s*\))', py_source):
                    line_no = py_source[:m.start()].count('\n') + 1
                    findings.append({
                        "rule_id": self.rule_id,
                        "description": (
                            "Manual SparkConf()/SparkContext creation detected in a Glue job. "
                            "Glue manages SparkContext via GlueContext. Move Spark configs to "
                            "YAML --conf and use bare SparkContext() or let GlueContext handle it."
                        ),
                        "artifact": "python", "issue_type": "manual_spark_conf",
                        "line": line_no,
                    })

        return findings

    @staticmethod
    def _detect_glue_version(yml_config, py_source, yml_source=""):
        """Extract Glue version from YAML config, raw YAML text, or Python source."""
        if yml_config:
            # Check common YAML paths for Glue version
            for key_path in ["GlueVersion", "glueVersion", "glue_version"]:
                val = yml_config.get(key_path)
                if val:
                    return str(val)
            # Check nested: default_arguments, job config, etc.
            default_args = yml_config.get("default_arguments", yml_config.get("DefaultArguments", {}))
            if isinstance(default_args, dict):
                ver = default_args.get("--GlueVersion", default_args.get("GlueVersion"))
                if ver:
                    return str(ver)
            # Walk all values looking for GlueVersion
            for key, val in yml_config.items():
                if isinstance(val, dict):
                    for k2, v2 in val.items():
                        if "glue" in k2.lower() and "version" in k2.lower():
                            return str(v2)
        # Fallback: scan raw YAML text with regex (handles malformed YAML)
        if yml_source:
            m = re.search(r'GlueVersion\s*:\s*["\']?(\d+\.?\d*)["\']?', yml_source, re.IGNORECASE)
            if m:
                return m.group(1)
        if py_source:
            m = re.search(r"GlueVersion['\"]?\s*[:=]\s*['\"](\d+\.?\d*)['\"]", py_source)
            if m:
                return m.group(1)
        return None

    @staticmethod
    def _extract_spark_configs(yml_config, py_source):
        """Extract all Spark configurations from YAML and Python source."""
        configs = {}
        if yml_config:
            default_args = yml_config.get("default_arguments", yml_config.get("DefaultArguments", {}))
            if isinstance(default_args, dict):
                conf_str = default_args.get("--conf", "")
                if conf_str:
                    for pair in conf_str.split("--conf"):
                        pair = pair.strip()
                        if "=" in pair:
                            k, v = pair.split("=", 1)
                            configs[k.strip()] = v.strip()
                # Also check direct spark.* keys
                for k, v in default_args.items():
                    if k.startswith("spark."):
                        configs[k] = str(v)
        if py_source:
            # Catch conf.set("spark.x", "val") pattern -- the primary pattern in Glue jobs
            for m in re.finditer(r'\.set\s*\(\s*["\']+(spark\.\w+[\w.]*)["\']+ *,\s*["\']+([^"\']+)["\']+', py_source):
                configs[m.group(1)] = m.group(2)
            # Catch spark.x = "val" or "spark.x": "val" patterns
            for m in re.finditer(r'["\']?(spark\.\w+[\w.]*)["\']?\s*[:=]\s*["\']?([^\s"\',)]+)["\']?', py_source):
                if m.group(1) not in configs:
                    configs[m.group(1)] = m.group(2)
            # Also catch .config("spark.x", "val") pattern
            for m in re.finditer(r'\.config\s*\(\s*["\']+(spark\.\w+[\w.]*)["\']+ *,\s*["\']+([^"\']+)["\']+', py_source):
                configs[m.group(1)] = m.group(2)
        return configs

    def classify_severity(self, finding):
        issue_type = finding.get("issue_type", "")
        if issue_type in ("set_master_local", "manual_spark_conf", "broadcast_join_disabled"):
            return "critical"
        elif issue_type in ("manual_memory_override", "invalid_config_key"):
            return "high"
        elif issue_type in ("aqe_not_supported", "deprecated_config"):
            return "medium"
        elif issue_type in ("aqe_not_enabled", "missing_kryo_serializer", "missing_shuffle_partitions"):
            return "medium"
        elif issue_type == "low_shuffle_partitions":
            return "high"
        return "low"

    def recommend_fix(self, finding):
        issue_type = finding.get("issue_type", "")
        if issue_type == "set_master_local":
            return "Remove .setMaster('local') -- let Glue manage cluster mode via GlueContext"
        elif issue_type == "manual_memory_override":
            return (
                f"Remove conf.set('{finding.get('config_key')}', '{finding.get('config_value')}') -- "
                f"Glue manages memory via WorkerType (G.1X=16GB, G.2X=32GB, G.4X=64GB)"
            )
        elif issue_type == "invalid_config_key":
            return f"Remove conf.set('{finding.get('config_key')}', ...) -- not a valid Spark configuration key"
        elif issue_type == "broadcast_join_disabled":
            return "Change autoBroadcastJoinThreshold from -1 to 10485760 (10MB) to re-enable broadcast joins"
        elif issue_type == "manual_spark_conf":
            return "Remove manual SparkConf(); move Spark configs to YAML --conf and use bare SparkContext()"
        elif issue_type == "aqe_not_supported":
            return f"Upgrade Glue version from {finding.get('glue_version')} to 3.0+ to enable AQE"
        elif issue_type == "aqe_not_enabled":
            return "Add --conf spark.sql.adaptive.enabled=true to default_arguments"
        elif issue_type == "invalid_glue_version":
            return f"Change GlueVersion from {finding.get('glue_version')} to 4.0 (Spark 3.3 with AQE enabled by default)"
        elif issue_type == "missing_kryo_serializer":
            return "Add --conf spark.serializer=org.apache.spark.serializer.KryoSerializer to default_arguments"
        elif issue_type == "missing_shuffle_partitions":
            return f"Add spark.sql.shuffle.partitions config based on data volume ({finding.get('total_rows', 0):,} rows)"
        elif issue_type == "low_shuffle_partitions":
            return f"Increase spark.sql.shuffle.partitions from {finding.get('current_value')} to {finding.get('recommended_min')}+"
        elif issue_type == "high_shuffle_partitions":
            return f"Decrease spark.sql.shuffle.partitions from {finding.get('current_value')} to {finding.get('recommended_max')}"
        elif issue_type == "deprecated_config":
            return f"Replace deprecated config '{finding.get('deprecated_key')}' with its Spark 3.x equivalent"
        return "Review Spark configuration for Glue version compatibility"

    def transformation_mapping(self, finding):
        issue_type = finding.get("issue_type", "")
        if issue_type == "set_master_local":
            return {"artifact_type": "python", "action": "comment_out_spark_config_line",
                    "line": finding.get("line"),
                    "reason": "setMaster('local') forces single-JVM mode, negating Glue cluster"}
        elif issue_type == "manual_memory_override":
            return {"artifact_type": "python", "action": "comment_out_spark_config_line",
                    "line": finding.get("line"),
                    "reason": f"Glue manages memory via WorkerType; {finding.get('config_key')} override removed"}
        elif issue_type == "invalid_config_key":
            return {"artifact_type": "python", "action": "comment_out_spark_config_line",
                    "line": finding.get("line"),
                    "reason": f"'{finding.get('config_key')}' is not a valid Spark config key"}
        elif issue_type == "broadcast_join_disabled":
            if finding.get("line"):
                return {"artifact_type": "python", "action": "replace_spark_config_value",
                        "line": finding.get("line"),
                        "old_value": "-1", "new_value": "10485760",
                        "reason": "Re-enable broadcast joins (10MB threshold)"}
            else:
                return {"artifact_type": "yaml", "action": "add_spark_config",
                        "config_key": "spark.sql.autoBroadcastJoinThreshold",
                        "config_value": "10485760"}
        elif issue_type == "manual_spark_conf":
            return {"artifact_type": "advisory", "action": "spark_conf_advisory",
                    "line": finding.get("line"),
                    "reason": "Move Spark configs from Python to YAML --conf; use bare SparkContext()"}
        elif issue_type == "aqe_not_enabled":
            return {"artifact_type": "yaml", "action": "add_spark_config",
                    "config_key": "spark.sql.adaptive.enabled", "config_value": "true"}
        elif issue_type == "invalid_glue_version":
            return {"artifact_type": "yaml", "action": "fix_glue_version",
                    "old_version": finding.get("glue_version"), "new_version": "4.0"}
        elif issue_type == "missing_kryo_serializer":
            return {"artifact_type": "yaml", "action": "add_spark_config",
                    "config_key": "spark.serializer",
                    "config_value": "org.apache.spark.serializer.KryoSerializer"}
        elif issue_type == "missing_shuffle_partitions":
            total = finding.get("total_rows", 0)
            if total > 100_000_000:
                val = "500"
            elif total > 10_000_000:
                val = "300"
            elif total > 1_000_000:
                val = "100"
            else:
                val = "50"
            return {"artifact_type": "yaml", "action": "add_spark_config",
                    "config_key": "spark.sql.shuffle.partitions", "config_value": val}
        elif issue_type == "low_shuffle_partitions":
            return {"artifact_type": "yaml", "action": "add_spark_config",
                    "config_key": "spark.sql.shuffle.partitions",
                    "config_value": str(finding.get("recommended_min", 500))}
        elif issue_type == "high_shuffle_partitions":
            return {"artifact_type": "yaml", "action": "add_spark_config",
                    "config_key": "spark.sql.shuffle.partitions",
                    "config_value": str(finding.get("recommended_max", 50))}
        elif issue_type == "deprecated_config":
            dep_key = finding.get("deprecated_key", "")
            new_key = dep_key.replace("spark.yarn.", "spark.")
            return {"artifact_type": "yaml", "action": "replace_spark_config",
                    "old_config_key": dep_key, "new_config_key": new_key}
        # Advisory only for version upgrade suggestions
        return {"artifact_type": "advisory", "action": "spark_version_advisory"}


# =============================================================================
# SQL String Walker (shared utility for SQL rules)
# =============================================================================

def _walk_json_strings(obj, prefix=""):
    if isinstance(obj, dict):
        for k, v in obj.items():
            path = f"{prefix}.{k}" if prefix else k
            yield from _walk_json_strings(v, path)
    elif isinstance(obj, list):
        for i, v in enumerate(obj):
            yield from _walk_json_strings(v, f"{prefix}[{i}]")
    elif isinstance(obj, str) and len(obj) > 15:
        yield prefix, obj


def _walk_all_sql(artifacts):
    """Walk all SQL strings from both JSON config and Python inline strings."""
    json_config = artifacts.get("json_config")
    if json_config:
        yield from _walk_json_strings(json_config, "json")
    py_source = artifacts.get("python_source", "")
    tree, _ = safe_parse_ast(py_source)
    if tree:
        for node in ast.walk(tree):
            if isinstance(node, ast.Constant) and isinstance(node.value, str):
                val = node.value.strip()
                if len(val) > 20 and re.search(r'\b(SELECT|INSERT|UPDATE|DELETE|FROM|JOIN)\b', val, re.IGNORECASE):
                    yield f"python:line_{node.lineno}", val


# =============================================================================
# Transformation Engine
# =============================================================================

class TransformationEngine:

    @staticmethod
    def _clean_python_source(source: str) -> str:
        """Fix common syntax issues: non-printable chars, mangled import lines."""
        # Replace non-breaking spaces (U+00A0) and other non-printable whitespace with regular spaces
        cleaned = source.replace('\u00a0', ' ')
        for cp in ['\u200b', '\u200c', '\u200d', '\ufeff', '\u2028', '\u2029']:
            cleaned = cleaned.replace(cp, '')

        # Normalize line endings
        cleaned = cleaned.replace('\r\n', '\n').replace('\r', '\n')

        # Context-aware tab replacement: match neighboring space-indented lines
        raw_lines = cleaned.splitlines(keepends=True)
        tab_fixed = []
        for idx, line in enumerate(raw_lines):
            content = line.lstrip(' \t')
            if not content.strip() or '\t' not in line[:len(line) - len(content)]:
                # No tabs in indent -- convert any remaining tabs in content
                tab_fixed.append(line.replace('\t', '    '))
                continue
            # Line has tabs in its indent -- find neighbor indent from space-only lines
            # Check both previous and next; prefer previous (same block level)
            prev_indent = None
            next_indent = None
            for j in range(idx - 1, max(idx - 5, -1), -1):
                nline = raw_lines[j]
                ncontent = nline.lstrip(' ')
                if ncontent.strip() and '\t' not in nline[:len(nline) - len(ncontent)]:
                    prev_indent = len(nline) - len(ncontent)
                    break
            for j in range(idx + 1, min(idx + 5, len(raw_lines))):
                nline = raw_lines[j]
                ncontent = nline.lstrip(' ')
                if ncontent.strip() and '\t' not in nline[:len(nline) - len(ncontent)]:
                    next_indent = len(nline) - len(ncontent)
                    break
            # Prefer previous line's indent (avoids matching continuation lines)
            # Fall back to next, then to min of both
            if prev_indent is not None and next_indent is not None:
                neighbor_indent = min(prev_indent, next_indent)
            elif prev_indent is not None:
                neighbor_indent = prev_indent
            elif next_indent is not None:
                neighbor_indent = next_indent
            else:
                neighbor_indent = None
            if neighbor_indent is not None:
                tab_fixed.append(' ' * neighbor_indent + content)
            else:
                tab_fixed.append(line.replace('\t', '    '))
        cleaned = ''.join(tab_fixed)

        # Fix indentation: snap misaligned lines (e.g. 5 spaces -> 8 spaces)
        indent_counts = []
        for line in cleaned.splitlines():
            content = line.lstrip(' ')
            if content and not content.startswith('#'):
                indent = len(line) - len(content)
                if indent > 0:
                    indent_counts.append(indent)
        indent_unit = 4
        if indent_counts:
            from math import gcd
            from functools import reduce
            g = reduce(gcd, indent_counts)
            if g in (2, 4, 8):
                indent_unit = g

        all_lines = cleaned.splitlines(keepends=True)
        line_indents = []
        for line in all_lines:
            content = line.lstrip(' ')
            if content.strip():
                line_indents.append(len(line) - len(line.lstrip(' ')))
            else:
                line_indents.append(-1)

        fixed_indent_lines = []
        for idx, line in enumerate(all_lines):
            content = line.lstrip(' ')
            if content.strip():
                indent = line_indents[idx]
                if indent > 0 and indent % indent_unit != 0:
                    neighbor_indent = None
                    for j in range(idx + 1, min(idx + 5, len(all_lines))):
                        if line_indents[j] >= 0:
                            neighbor_indent = line_indents[j]
                            break
                    if neighbor_indent is None:
                        for j in range(idx - 1, max(idx - 5, -1), -1):
                            if line_indents[j] >= 0:
                                neighbor_indent = line_indents[j]
                                break
                    if neighbor_indent is not None and neighbor_indent % indent_unit == 0:
                        if abs(indent - neighbor_indent) < indent_unit:
                            snapped = neighbor_indent
                        else:
                            snapped = round(indent / indent_unit) * indent_unit
                    else:
                        snapped = round(indent / indent_unit) * indent_unit
                    fixed_indent_lines.append(' ' * snapped + content)
                else:
                    fixed_indent_lines.append(line)
            else:
                fixed_indent_lines.append(line)
        cleaned = ''.join(fixed_indent_lines)

        # Fix mangled lines where multiple statements are jammed together
        # e.g. "mport paramikofrom io import BytesIO" or "apply(    frame=final_dyf,mappings=["
        result_lines = []
        for line in cleaned.splitlines(keepends=True):
            stripped = line.rstrip('\n\r')
            indent = len(stripped) - len(stripped.lstrip())
            content = stripped.lstrip()

            # Fix lines with multiple imports jammed together: "mport paramikofrom io import BytesIO"
            # Detect "from" keyword appearing mid-line after a non-whitespace char
            parts = re.split(r'(?<=[a-zA-Z0-9_])(?=from\s+\S+\s+import\s)', content)
            if len(parts) > 1:
                prefix = ' ' * indent
                for i, part in enumerate(parts):
                    # First part might be a broken import like "mport paramiko"
                    p = part.strip()
                    if p and not p.startswith(('import ', 'from ')):
                        # Try to fix truncated "import" -> "import"
                        if re.match(r'^mport\s', p):
                            p = 'i' + p
                        elif re.match(r'^port\s', p):
                            p = 'im' + p
                    if p:
                        result_lines.append(prefix + p + '\n')
                continue

            # Fix lines where a function call and keyword args are jammed:
            # "apply(    frame=..." -> preserve as-is (valid Python with odd whitespace)
            # But fix "mapped_dyf = ApplyMapping.apply(    frame=final_dyf,mappings=["
            # by splitting at keyword-arg boundaries after "),"
            if re.search(r'\)\s*,\s*[a-zA-Z_]+=', content) and content.count('(') < content.count(','):
                # This is likely jammed kwargs -- leave for AST to handle after non-printable cleanup
                pass

            result_lines.append(line)

        cleaned = ''.join(result_lines)

        # Final pass: fix lines that have multiple statements jammed (no newline)
        # Pattern: "statement1statement2" where statement2 starts with a Python keyword
        # Exclude 'import'/'from' -- those are already handled by the first pass
        stmt_keywords = r'(?:class|def|if|elif|else|for|while|try|except|finally|with|return|raise|assert)'
        final_lines = []
        for line in cleaned.splitlines(keepends=True):
            stripped = line.rstrip('\n\r')
            indent = len(stripped) - len(stripped.lstrip())
            content = stripped.lstrip()
            # Split on keyword boundaries mid-line (skip comments and strings)
            if content.startswith('#'):
                final_lines.append(line)
                continue
            split = re.split(r'(?<=[a-zA-Z0-9_\)\]\"\'])\s*(?=' + stmt_keywords + r'\s+)', content)
            if len(split) > 1:
                prefix = ' ' * indent
                for part in split:
                    if part.strip():
                        final_lines.append(prefix + part.strip() + '\n')
            else:
                final_lines.append(line)

        return ''.join(final_lines)

    def apply_python_transforms(self, source: str, transformations: list[dict]) -> str:
        # Pre-step: clean syntax issues (non-printable chars, mangled lines)
        for t in transformations:
            if t.get("action") == "fix_syntax_error":
                source = self._clean_python_source(source)
                break

        lines = source.splitlines(keepends=True)
        lines_to_remove = set()
        line_replacements = {}

        for t in transformations:
            action = t.get("action", "")
            line = t.get("line")

            if action == "remove_unnecessary_action":
                if line and line <= len(lines):
                    old = lines[line - 1]
                    stripped = old.strip()
                    indent = old[:len(old) - len(old.lstrip())]
                    action_type = t.get("action_type", "")
                    if action_type == "count":
                        # Replace count() with lightweight alternative instead of commenting out.
                        # If count() result is assigned (e.g. n = df.count()), replace with df.limit(1).count()
                        # If standalone (e.g. df.count()), replace with df.limit(1).count() for existence check
                        count_match = re.match(r'^(\s*)(\w+)\s*=\s*(.+)\.count\(\s*\)', old)
                        if count_match:
                            var_name = count_match.group(2)
                            df_expr = count_match.group(3)
                            line_replacements[line] = (
                                indent + f'{var_name} = {df_expr}.limit(1).count()'
                                f'  # OPTIMIZED: full count() replaced with limit(1).count() to avoid full scan\n'
                            )
                        elif re.search(r'\.count\(\s*\)', stripped):
                            new = re.sub(r'\.count\(\s*\)', '.limit(1).count()', old)
                            line_replacements[line] = new.rstrip('\n') + '  # OPTIMIZED: full count() replaced with limit(1).count()\n'
                        else:
                            line_replacements[line] = indent + stripped + "  # OPTIMIZED: count() usage flagged\n"
                    elif action_type == "show":
                        # Replace show() with show(5, truncate=True) for limited output
                        new = re.sub(r'\.show\(\s*\)', '.show(5, truncate=True)', old)
                        if new != old:
                            line_replacements[line] = new.rstrip('\n') + '  # OPTIMIZED: show() replaced with show(5)\n'
                        else:
                            line_replacements[line] = indent + stripped.replace('.show()', '.show(5, truncate=True)') + "  # OPTIMIZED\n"
                    else:
                        line_replacements[line] = indent + "# OPTIMIZED: " + stripped + "\n"

            elif action == "replace_collect":
                if line and line <= len(lines):
                    old = lines[line - 1]
                    if ".collect()[0]" in old:
                        line_replacements[line] = old.replace(".collect()[0]", ".first()")
                    elif ".collect()" in old:
                        line_replacements[line] = old.replace(".collect()", ".take(100)")

            elif action == "remove_or_adjust_repartition":
                if line and line <= len(lines):
                    old = lines[line - 1]
                    orig_n = t.get("partition_count", 0)
                    # Estimate optimal partition count from log row counts
                    row_count = t.get("total_data_rows", 0)
                    if row_count > 100_000_000:
                        optimal_n = 200
                    elif row_count > 10_000_000:
                        optimal_n = 100
                    elif row_count > 1_000_000:
                        optimal_n = 50
                    else:
                        optimal_n = 20
                    # Replace the partition count, don't remove the line
                    new = re.sub(r'\.repartition\(\s*\d+\s*\)',
                                 f'.repartition({optimal_n})', old)
                    if new != old:
                        line_replacements[line] = new
                    else:
                        # Couldn't regex-replace, comment out with recommendation
                        indent = old[:len(old) - len(old.lstrip())]
                        line_replacements[line] = (indent +
                            f"# OPTIMIZED: repartition({orig_n}) -> repartition({optimal_n})\n" +
                            old.replace(f'repartition({orig_n})', f'repartition({optimal_n})'))

            elif action == "replace_data_amplification":
                # Smart replacement: instead of commenting out withColumn,
                # replace the array_repeat+explode pair with a single direct
                # withColumn that preserves the column but eliminates amplification.
                repeated_value = t.get("repeated_value", "lit(1)")
                ar_source_df = t.get("ar_source_df")
                explode_col_name = t.get("explode_col_name")
                explode_target_var = t.get("explode_target_var")

                # --- Helper: find full statement range for a target line ---
                def _find_stmt_range(target_line):
                    target_stripped = lines[target_line - 1].strip() if target_line <= len(lines) else ""
                    # If the target line itself starts a statement (assignment),
                    # don't walk backward -- it's already a statement start.
                    target_is_stmt_start = bool(re.match(r'^\w+\s*=', target_stripped))
                    stmt_start = target_line
                    if not target_is_stmt_start:
                        for j in range(target_line - 1, max(target_line - 10, 0), -1):
                            ln = lines[j - 1].strip()
                            if not ln or ln.startswith('#'):
                                break
                            stmt_start = j
                            if re.match(r'^\w+\s*=', ln):
                                break
                    stmt_end = target_line
                    paren_depth = 0
                    for j in range(stmt_start, min(target_line + 10, len(lines) + 1)):
                        ln = lines[j - 1]
                        paren_depth += ln.count('(') - ln.count(')')
                        stmt_end = j
                        if paren_depth <= 0:
                            break
                    return stmt_start, stmt_end

                ar_line = t.get("array_repeat_line")
                exp_line = t.get("explode_line")

                # Step 1: Comment out the array_repeat statement (intermediate
                # array column is no longer needed)
                if ar_line and ar_line <= len(lines):
                    ar_start, ar_end = _find_stmt_range(ar_line)
                    for j in range(ar_start, ar_end + 1):
                        if j <= len(lines) and j not in line_replacements:
                            old = lines[j - 1]
                            indent = old[:len(old) - len(old.lstrip())]
                            line_replacements[j] = indent + "# OPTIMIZED(removed): " + old.strip() + "  # intermediate array no longer needed\n"

                # Step 2: Replace the explode statement with a direct withColumn
                if exp_line and exp_line <= len(lines):
                    exp_start, exp_end = _find_stmt_range(exp_line)
                    # Build the replacement line
                    first_line = lines[exp_start - 1]
                    indent = first_line[:len(first_line) - len(first_line.lstrip())]
                    # Determine variable names for the replacement
                    target_var = explode_target_var
                    source_df = ar_source_df
                    if not target_var:
                        # Try to extract from the first line of the explode stmt
                        m = re.match(r'(\w+)\s*=\s*(\w+)\.', first_line.strip())
                        if m:
                            target_var = m.group(1)
                            source_df = source_df or m.group(2)
                    col_name = explode_col_name or "value"
                    src = source_df or (target_var if target_var else "df")
                    replacement = (
                        f'{indent}{target_var} = {src}.withColumn("{col_name}", {repeated_value})'
                        f'  # OPTIMIZED: replaced array_repeat+explode amplification with direct value\n'
                    )
                    # Replace first line, blank out remaining lines of statement
                    for j in range(exp_start, exp_end + 1):
                        if j <= len(lines) and j not in line_replacements:
                            if j == exp_start:
                                line_replacements[j] = replacement
                            else:
                                line_replacements[j] = ""  # remove continuation lines

            elif action == "remove_sleep_in_loop":
                if line and line <= len(lines):
                    old = lines[line - 1]
                    indent = old[:len(old) - len(old.lstrip())]
                    line_replacements[line] = indent + "# OPTIMIZED: " + old.strip() + "  # artificial delay removed\n"

            elif action == "comment_out_spark_config_line":
                # Comment out problematic Spark config lines (setMaster, memory overrides, invalid keys)
                if line and line <= len(lines):
                    old = lines[line - 1]
                    indent = old[:len(old) - len(old.lstrip())]
                    reason = t.get("reason", "removed by RCA-047")
                    # Also check if this line is part of a chained call (e.g., SparkConf().setAppName().setMaster())
                    stripped = old.strip()
                    if '.setMaster(' in stripped and '.setAppName(' in stripped:
                        # Chain: remove only .setMaster(...) part, keep the rest
                        new = re.sub(r'\.setMaster\s*\([^)]*\)', '', old)
                        line_replacements[line] = new.rstrip('\n') + f'  # OPTIMIZED: removed setMaster -- {reason}\n'
                    else:
                        line_replacements[line] = indent + f"# OPTIMIZED: {stripped}  # {reason}\n"

            elif action == "replace_spark_config_value":
                # Replace a specific config value (e.g., -1 -> 10485760 for broadcast threshold)
                if line and line <= len(lines):
                    old = lines[line - 1]
                    old_val = t.get("old_value", "")
                    new_val = t.get("new_value", "")
                    reason = t.get("reason", "")
                    if old_val and new_val:
                        # Replace value in quotes: "old_val" -> "new_val"
                        new = re.sub(rf'(["\']){re.escape(old_val)}(["\'])',
                                     rf'\g<1>{new_val}\g<2>', old)
                        if new != old:
                            line_replacements[line] = new.rstrip('\n') + f'  # OPTIMIZED: {reason}\n'

            elif action == "increase_chunk_size":
                if line and line <= len(lines):
                    old = lines[line - 1]
                    row_count = t.get("total_data_rows", 0)
                    # Scale chunk size based on data volume
                    if row_count > 100_000_000:      # 100M+ rows -> 128MB chunks
                        chunk_mb = 128
                    elif row_count > 10_000_000:      # 10M+ rows -> 96MB chunks
                        chunk_mb = 96
                    elif row_count > 1_000_000:       # 1M+ rows -> 64MB chunks
                        chunk_mb = 64
                    else:                              # <1M rows -> 32MB chunks
                        chunk_mb = 32
                    new = re.sub(r'(\d+)\s*\*\s*1024\s*\*\s*1024', f'{chunk_mb} * 1024 * 1024', old)
                    if new != old:
                        line_replacements[line] = new.rstrip('\n') + f'  # OPTIMIZED: chunk_size scaled to {chunk_mb}MB based on data volume\n'

            elif action == "remove_coalesce_one":
                if line and line <= len(lines):
                    old = lines[line - 1]
                    # Replace coalesce(1) with a reasonable partition count
                    # based on data volume from logs
                    row_count = t.get("total_data_rows", 0)
                    if row_count > 100_000_000:
                        optimal_n = 50
                    elif row_count > 10_000_000:
                        optimal_n = 20
                    elif row_count > 1_000_000:
                        optimal_n = 10
                    else:
                        optimal_n = 4
                    new = re.sub(r'\.coalesce\(\s*1\s*\)',
                                 f'.coalesce({optimal_n})', old)
                    if new != old:
                        line_replacements[line] = new

            elif action == "replace_to_pandas":
                if line and line <= len(lines):
                    old = lines[line - 1]
                    new = old.replace(".toPandas()", ".limit(10000).toPandas()")
                    if new != old:
                        line_replacements[line] = new

            elif action == "replace_group_by_key":
                if line and line <= len(lines):
                    old = lines[line - 1]
                    new = old.replace(".groupByKey()", ".reduceByKey(lambda a, b: a + b)")
                    if new != old:
                        line_replacements[line] = new

            elif action == "replace_select_star":
                # Handle SELECT * in Python string literals
                json_path = t.get("json_path", "")
                if json_path.startswith("python:line_"):
                    try:
                        target_line = int(json_path.split("_")[-1])
                    except ValueError:
                        continue
                    if target_line and target_line <= len(lines):
                        old = lines[target_line - 1]
                        # Replace SELECT * with SELECT /*specify_columns*/ inside the string
                        new = re.sub(r'SELECT\s+\*', 'SELECT /*specify_columns*/', old, flags=re.IGNORECASE)
                        if new != old:
                            line_replacements[target_line] = new

            elif action == "flag_cache_leak":
                # Find all variable names that call .cache() or .persist()
                # and insert .unpersist() calls before job.commit()
                cached_vars = set()
                for idx_l, ln in enumerate(lines, 1):
                    m = re.match(r'^(\s*)(\w+)\s*[.=].*\.(?:cache|persist)\s*\(', ln)
                    if m:
                        cached_vars.add(m.group(2))
                    # Also handle: var.cache() on its own line
                    m2 = re.match(r'^\s*(\w+)\.(?:cache|persist)\s*\(', ln)
                    if m2:
                        cached_vars.add(m2.group(1))
                if cached_vars:
                    # Find job.commit() line and insert unpersist before it
                    for idx_l, ln in enumerate(lines):
                        if 'job.commit()' in ln:
                            indent = ' ' * (len(ln) - len(ln.lstrip()))
                            unpersist_block = ''
                            for var in sorted(cached_vars):
                                unpersist_block += f'{indent}{var}.unpersist()\n'
                            lines[idx_l] = unpersist_block + ln
                            break

            elif action == "insert_cache_persist":
                # Insert .cache() call after the DataFrame assignment line
                var_name = t.get("var_name", "")
                target_line = t.get("line")
                if target_line and target_line <= len(lines) and var_name:
                    old = lines[target_line - 1]
                    indent = old[:len(old) - len(old.lstrip())]
                    # Check if .cache() is already present on this line
                    if '.cache()' not in old and '.persist(' not in old:
                        cache_line = f'{indent}{var_name}.cache()  # OPTIMIZED(RCA-061): reused {t.get("reuse_count", "multiple")} times\n'
                        lines[target_line - 1] = old.rstrip('\n') + '\n' + cache_line
                    # Also insert .unpersist() before job.commit() if not already handled
                    for idx_l, ln in enumerate(lines):
                        if 'job.commit()' in ln:
                            commit_indent = ' ' * (len(ln) - len(ln.lstrip()))
                            # Only add if not already present
                            preceding = lines[max(0, idx_l - 10):idx_l]
                            if not any(f'{var_name}.unpersist()' in p for p in preceding):
                                lines[idx_l] = f'{commit_indent}{var_name}.unpersist()\n' + ln
                            break

            elif action == "llm_line_replace":
                # Generic handler for LLM-generated line-level replacements.
                # The LLM provides exact old_code and new_code for a specific line.
                target_line = t.get("line")
                old_code = t.get("old_code", "")
                new_code = t.get("new_code", "")
                if target_line and target_line <= len(lines) and new_code:
                    old = lines[target_line - 1]
                    indent = old[:len(old) - len(old.lstrip())]
                    if old_code and old_code.strip() in old:
                        # Exact match found -- replace the matching portion
                        replaced = old.replace(old_code.strip(), new_code.strip())
                        line_replacements[target_line] = replaced if replaced.endswith('\n') else replaced + '\n'
                    else:
                        # Fallback: comment out old line, insert new line
                        line_replacements[target_line] = (
                            indent + "# OPTIMIZED(LLM): " + old.strip() + "\n" +
                            indent + new_code.strip() + "  # LLM-generated fix\n"
                        )

        result = []
        for i, ln in enumerate(lines, 1):
            if i in lines_to_remove:
                continue
            result.append(line_replacements.get(i, ln))
        return "".join(result)

    def apply_yaml_transforms(self, yml_data: dict, transformations: list[dict]) -> dict:
        result = copy.deepcopy(yml_data)
        for t in transformations:
            action = t.get("action", "")

            if action == "scale_workers":
                rec_count = t.get("recommended_workers")
                rec_type = t.get("recommended_type")
                if rec_count:
                    self._set_yaml_value(result, "NumberOfWorkers", str(rec_count))
                if rec_type:
                    self._set_yaml_value(result, "WorkerType", rec_type)

            elif action in ("increase_workers", "scale_for_oom", "scale_for_gc",
                           "scale_for_shuffle_spill", "scale_for_shuffle",
                           "scale_for_aggregation", "scale_for_join"):
                current = t.get("current_workers", 2)
                rec = max(current * 3, 10)
                self._set_yaml_value(result, "NumberOfWorkers", str(rec))
                worker_type = self._get_yaml_value(result, "WorkerType") or "G.1X"
                type_idx = GLUE_WORKER_TYPES.index(worker_type) if worker_type in GLUE_WORKER_TYPES else 1
                new_idx = min(type_idx + 1, 4)
                self._set_yaml_value(result, "WorkerType", GLUE_WORKER_TYPES[new_idx])

            elif action == "enable_aqe_for_skew":
                # Enable Adaptive Query Execution for data skew handling
                default_args = result.get("DefaultArguments", result.get("default_arguments", {}))
                if default_args is None:
                    default_args = {}
                default_args["--conf"] = (default_args.get("--conf", "") +
                    " spark.sql.adaptive.enabled=true"
                    " spark.sql.adaptive.skewJoin.enabled=true"
                    " spark.sql.adaptive.skewJoin.skewedPartitionThresholdInBytes=256MB").strip()
                if "DefaultArguments" in result:
                    result["DefaultArguments"] = default_args
                elif "default_arguments" in result:
                    result["default_arguments"] = default_args
                else:
                    result["DefaultArguments"] = default_args

            elif action == "increase_timeout":
                exec_dur = t.get("execution_duration", 30)
                new_timeout = int(exec_dur * 2)
                self._set_yaml_value(result, "Timeout", str(new_timeout))

            elif action == "fix_glue_version":
                old_ver = t.get("old_version", "")
                new_ver = t.get("new_version", "4.0")
                self._set_yaml_value(result, "GlueVersion", new_ver)

            elif action == "add_spark_config":
                # Add or update a Spark configuration in default_arguments --conf
                config_key = t.get("config_key", "")
                config_value = t.get("config_value", "")
                if config_key and config_value:
                    default_args = result.get("DefaultArguments", result.get("default_arguments", {}))
                    if default_args is None:
                        default_args = {}
                    conf_str = default_args.get("--conf", "")
                    # Check if config already exists and update it
                    if config_key in conf_str:
                        conf_str = re.sub(
                            rf'{re.escape(config_key)}=\S+',
                            f'{config_key}={config_value}',
                            conf_str
                        )
                    else:
                        conf_str = (conf_str + f" {config_key}={config_value}").strip()
                    default_args["--conf"] = conf_str
                    if "DefaultArguments" in result:
                        result["DefaultArguments"] = default_args
                    elif "default_arguments" in result:
                        result["default_arguments"] = default_args
                    else:
                        result["DefaultArguments"] = default_args

            elif action == "replace_spark_config":
                # Replace a deprecated Spark config key with a new one
                old_key = t.get("old_config_key", "")
                new_key = t.get("new_config_key", "")
                if old_key and new_key:
                    default_args = result.get("DefaultArguments", result.get("default_arguments", {}))
                    if default_args and isinstance(default_args, dict):
                        conf_str = default_args.get("--conf", "")
                        if old_key in conf_str:
                            conf_str = conf_str.replace(old_key, new_key)
                            default_args["--conf"] = conf_str
                            if "DefaultArguments" in result:
                                result["DefaultArguments"] = default_args
                            elif "default_arguments" in result:
                                result["default_arguments"] = default_args

            elif action == "llm_yaml_update":
                # Generic handler for LLM-generated YAML key updates.
                key = t.get("key", "")
                new_value = t.get("new_value")
                if key and new_value is not None:
                    self._set_yaml_value(result, key, str(new_value))

        return result

    def apply_json_transforms(self, json_data: dict, transformations: list[dict]) -> dict:
        result = copy.deepcopy(json_data)
        for t in transformations:
            action = t.get("action", "")
            json_path = t.get("json_path", "")

            if action == "replace_select_star":
                # Collect all queries from JSON to provide column context
                all_queries = {}
                self._collect_all_queries(result, all_queries)
                self._apply_sql_fix_at_path(result, json_path,
                                            lambda sql: self._fix_select_star(sql, all_queries))

            elif action == "replace_correlated_subquery":
                self._apply_sql_fix_at_path(result, json_path, self._fix_correlated_subquery)

            elif action == "flag_order_without_limit":
                self._apply_sql_fix_at_path(result, json_path, self._fix_order_without_limit)

            elif action == "flag_union_without_all":
                safe_for_all = t.get("safe_for_all", False)
                self._apply_sql_fix_at_path(result, json_path,
                                            lambda sql: self._fix_union_without_all(sql, safe_for_all))

            elif action == "flag_unbounded_aggregation":
                self._apply_sql_fix_at_path(result, json_path, self._fix_unbounded_aggregation)

            elif action == "flag_cartesian_join":
                self._apply_sql_fix_at_path(result, json_path, self._annotate_sql_issue,
                                            "CARTESIAN JOIN: add proper JOIN condition")

            elif action == "flag_missing_join_predicate":
                self._apply_sql_fix_at_path(result, json_path, self._annotate_sql_issue,
                                            "MISSING JOIN PREDICATE: add ON clause")

            elif action == "flag_deep_nesting":
                self._apply_sql_fix_at_path(result, json_path, self._fix_deep_nesting)

            elif action == "fix_non_sargable_predicate":
                original = t.get("original", "")
                replacement = t.get("replacement", "")
                if original and replacement:
                    self._apply_sql_fix_at_path(
                        result, json_path,
                        lambda sql, orig=original, repl=replacement: re.sub(
                            re.escape(orig), repl, sql, flags=re.IGNORECASE))

            elif action == "flag_non_sargable":
                self._apply_sql_fix_at_path(result, json_path, self._annotate_sql_issue,
                                            "NON-SARGABLE PREDICATE: refactor for predicate pushdown")

            elif action == "fix_duplicate_in_values":
                original = t.get("original", "")
                replacement = t.get("replacement", "")
                if original and replacement:
                    self._apply_sql_fix_at_path(
                        result, json_path,
                        lambda sql, orig=original, repl=replacement: sql.replace(orig, repl))

            elif action == "flag_distinct_on_join":
                pass  # Advisory only -- DISTINCT removal may affect business logic

            elif action == "add_broadcast_hint":
                aliases = t.get("broadcast_aliases", "")
                if aliases:
                    self._apply_sql_fix_at_path(
                        result, json_path,
                        lambda sql, a=aliases: re.sub(
                            r'(?i)(SELECT\s+)',
                            r'\1/*+ BROADCAST(' + a + ') */ ',
                            sql, count=1))

            elif action == "flag_not_in_subquery":
                self._apply_sql_fix_at_path(result, json_path, self._annotate_sql_issue,
                                            "NOT IN SUBQUERY: replace with LEFT JOIN ... IS NULL or NOT EXISTS")

            elif action == "flag_having_without_agg":
                self._apply_sql_fix_at_path(result, json_path, self._annotate_sql_issue,
                                            "HAVING WITHOUT AGGREGATE: move non-aggregate conditions to WHERE")

            elif action == "flag_implicit_coercion":
                pass  # Advisory only -- requires schema knowledge to auto-fix

            elif action in ("optimize_slow_query", "optimize_source_query"):
                # Apply all available SQL optimizations to all queries in the JSON
                self._optimize_all_queries(result)

            elif action == "llm_json_update":
                # Generic handler for LLM-generated JSON/SQL replacements.
                # LLM provides the dotted path and old/new SQL strings.
                llm_json_path = t.get("json_path", "")
                old_sql = t.get("old_sql", "")
                new_sql = t.get("new_sql", "")
                if llm_json_path and new_sql:
                    parts = llm_json_path.split(".")
                    obj = result
                    for p in parts[:-1]:
                        if isinstance(obj, dict) and p in obj:
                            obj = obj[p]
                        else:
                            obj = None
                            break
                    if obj is not None and isinstance(obj, dict):
                        last_key = parts[-1]
                        if last_key in obj:
                            current_val = obj[last_key]
                            if old_sql and old_sql in str(current_val):
                                obj[last_key] = str(current_val).replace(old_sql, new_sql)
                            else:
                                obj[last_key] = new_sql

        return result

    # --- JSON SQL fix helpers ---

    @staticmethod
    def _collect_all_queries(data, result_dict, prefix=""):
        """Recursively collect all SQL query strings from a JSON config."""
        if isinstance(data, dict):
            for k, v in data.items():
                path = f"{prefix}.{k}" if prefix else k
                if isinstance(v, str) and re.search(r'(?i)\bSELECT\b', v):
                    result_dict[path] = {"sql": v}
                elif isinstance(v, dict):
                    if "sql" in v and isinstance(v["sql"], str):
                        result_dict[path] = v
                    TransformationEngine._collect_all_queries(v, result_dict, path)
                elif isinstance(v, list):
                    for i, item in enumerate(v):
                        TransformationEngine._collect_all_queries(item, result_dict, f"{path}[{i}]")

    def _apply_sql_fix_at_path(self, data, json_path: str, fix_fn, *args):
        """Navigate JSON to the value at json_path and apply fix_fn to SQL string."""
        # json_path format: "json.table_queries.orders.sql" or "json.final_query.sql"
        parts = json_path.split(".")
        # Strip leading "json" prefix from path
        if parts and parts[0] == "json":
            parts = parts[1:]
        # Handle array index notation like "[0]"
        keys = []
        for p in parts:
            idx_match = re.match(r'^(.+)\[(\d+)\]$', p)
            if idx_match:
                keys.append(idx_match.group(1))
                keys.append(int(idx_match.group(2)))
            else:
                keys.append(p)
        # Navigate to parent and set the fixed value
        obj = data
        for k in keys[:-1]:
            if isinstance(obj, dict) and k in obj:
                obj = obj[k]
            elif isinstance(obj, list) and isinstance(k, int) and k < len(obj):
                obj = obj[k]
            else:
                return  # path not found
        last_key = keys[-1] if keys else None
        if last_key is None:
            return
        if isinstance(obj, dict) and last_key in obj and isinstance(obj[last_key], str):
            obj[last_key] = fix_fn(obj[last_key], *args)
        elif isinstance(obj, dict):
            # The path might point to a dict with an "sql" key, or the value is the SQL itself
            # Try to find the SQL string in the value
            val = obj.get(last_key)
            if isinstance(val, str):
                obj[last_key] = fix_fn(val, *args)
            elif isinstance(val, dict) and "sql" in val:
                val["sql"] = fix_fn(val["sql"], *args)

    @staticmethod
    def _extract_columns_from_sql(sql: str) -> list:
        """Extract column names referenced in ON, WHERE, GROUP BY, ORDER BY, and HAVING clauses."""
        columns = set()
        normalized = re.sub(r'\s+', ' ', sql.strip())

        # Extract columns from ON clauses: ON t.col1 = c.col2
        for m in re.finditer(r'ON\s+(.+?)(?=\s+(?:LEFT|RIGHT|INNER|OUTER|CROSS|WHERE|GROUP|ORDER|HAVING|LIMIT|UNION|$))',
                             normalized, re.IGNORECASE):
            on_clause = m.group(1)
            for col in re.findall(r'(\w+\.\w+)', on_clause):
                columns.add(col)

        # Extract columns from WHERE clause
        where_match = re.search(r'WHERE\s+(.+?)(?=\s+(?:GROUP|ORDER|HAVING|LIMIT|UNION|$))',
                                normalized, re.IGNORECASE)
        if where_match:
            for col in re.findall(r'(\w+\.\w+)', where_match.group(1)):
                columns.add(col)
            for col in re.findall(r'(?<!\.)(\b[a-z_]\w*\b)(?:\s*[=<>!]|\s+(?:IN|LIKE|BETWEEN|IS))',
                                  where_match.group(1), re.IGNORECASE):
                if col.upper() not in ('AND', 'OR', 'NOT', 'NULL', 'IN', 'LIKE', 'BETWEEN', 'IS', 'TRUE', 'FALSE'):
                    columns.add(col)

        # Extract columns from GROUP BY
        group_match = re.search(r'GROUP\s+BY\s+(.+?)(?=\s+(?:HAVING|ORDER|LIMIT|UNION|$))',
                                normalized, re.IGNORECASE)
        if group_match:
            for col in re.findall(r'(\w+(?:\.\w+)?)', group_match.group(1)):
                if col.upper() not in ('ASC', 'DESC'):
                    columns.add(col)

        # Extract columns from ORDER BY
        order_match = re.search(r'ORDER\s+BY\s+(.+?)(?=\s+(?:LIMIT|UNION|$))',
                                normalized, re.IGNORECASE)
        if order_match:
            for col in re.findall(r'(\w+(?:\.\w+)?)', order_match.group(1)):
                if col.upper() not in ('ASC', 'DESC', 'NULLS', 'FIRST', 'LAST'):
                    columns.add(col)

        return sorted(columns)

    def _fix_select_star(self, sql: str, all_queries: dict = None) -> str:
        """Replace SELECT * with explicit columns found in the query and related queries.

        Analyzes ON, WHERE, GROUP BY, ORDER BY clauses to find actual columns used.
        Only falls back to /*specify_columns*/ if no columns can be resolved.
        """
        normalized = re.sub(r'\s+', ' ', sql.strip())

        # Step 1: Extract columns used within THIS query
        columns_found = self._extract_columns_from_sql(sql)

        # Step 2: If we have related queries context, also look for columns there
        if all_queries:
            for q_key, q_val in all_queries.items():
                q_sql = q_val.get("sql", "") if isinstance(q_val, dict) else (q_val if isinstance(q_val, str) else "")
                if q_sql and q_sql != sql:
                    columns_found.extend(self._extract_columns_from_sql(q_sql))
            # Deduplicate
            columns_found = sorted(set(columns_found))

        # Step 3: Find table aliases
        alias_pattern = re.findall(
            r'(?:FROM|JOIN)\s+(\w+(?:\.\w+)*)\s+(\w+)(?:\s+ON|\s+LEFT|\s+RIGHT|\s+INNER|\s+OUTER|\s+CROSS|\s+WHERE|\s+GROUP|\s+ORDER|\s*,|\s*$)',
            normalized, re.IGNORECASE
        )

        if columns_found:
            # We found real columns -- use them instead of /*specify_columns*/
            col_list = ", ".join(columns_found)
            return re.sub(r'(?i)SELECT\s+\*', f'SELECT {col_list}', sql, count=1)

        # No columns found in query context -- keep SELECT * but annotate
        if alias_pattern and len(alias_pattern) >= 2:
            qualified = ", ".join(f"{alias}.*" for _, alias in alias_pattern)
            return re.sub(r'(?i)SELECT\s+\*',
                          f'SELECT /*specify_columns*/ {qualified}', sql, count=1)
        elif alias_pattern and len(alias_pattern) == 1:
            _, alias = alias_pattern[0]
            return re.sub(r'(?i)SELECT\s+\*',
                          f'SELECT /*specify_columns*/ {alias}.*', sql, count=1)

        return re.sub(r'(?i)SELECT\s+\*', 'SELECT /*specify_columns*/ *', sql, count=1)

    @staticmethod
    def _fix_correlated_subquery(sql: str) -> str:
        """Rewrite correlated subqueries to JOIN or window function where possible.

        Handles common patterns:
        1. WHERE col IN (SELECT col FROM ... WHERE outer.col = inner.col) -> JOIN
        2. WHERE EXISTS (SELECT 1 FROM ... WHERE outer.col = inner.col) -> JOIN
        3. Scalar subquery in SELECT (SELECT (SELECT agg FROM ...)) -> window function
        If pattern is not recognized, annotates for manual review.
        """
        normalized = re.sub(r'\s+', ' ', sql.strip())
        upper = normalized.upper()

        # Pattern 1: WHERE col IN (SELECT col FROM table WHERE outer.col = inner.col)
        in_pattern = re.compile(
            r'(?i)(SELECT\s+.+?\s+FROM\s+(\w+)\s+(\w+))'  # outer: SELECT ... FROM table alias
            r'(.*?)'                                         # middle (other JOINs, etc.)
            r'\s+WHERE\s+(.*?)'                              # WHERE clause start
            r'(\w+(?:\.\w+)?)\s+IN\s*\(\s*'                 # col IN (
            r'SELECT\s+(\w+(?:\.\w+)?)\s+'                  # SELECT inner_col
            r'FROM\s+(\w+)\s+(\w+)\s+'                      # FROM inner_table inner_alias
            r'WHERE\s+(\w+\.\w+)\s*=\s*(\w+\.\w+)'         # WHERE outer.col = inner.col
            r'\s*\)',                                         # closing paren
            re.DOTALL
        )
        m = in_pattern.search(normalized)
        if m:
            outer_select = m.group(1)
            outer_table = m.group(2)
            outer_alias = m.group(3)
            middle = m.group(4)
            where_prefix = m.group(5).strip()
            in_col = m.group(6)
            inner_select_col = m.group(7)
            inner_table = m.group(8)
            inner_alias = m.group(9)
            corr_left = m.group(10)
            corr_right = m.group(11)
            # Build JOIN version
            join_condition = f"{corr_left} = {corr_right}"
            result = f"{outer_select}{middle} JOIN {inner_table} {inner_alias} ON {join_condition}"
            # Preserve remaining WHERE conditions if any
            remaining_where = where_prefix.strip()
            if remaining_where and remaining_where.upper() not in ('', 'AND', 'OR'):
                remaining_where = re.sub(r'(?i)\s*(AND|OR)\s*$', '', remaining_where).strip()
                if remaining_where:
                    result += f" WHERE {remaining_where}"
            elif not remaining_where or remaining_where.upper() in ('AND', 'OR'):
                pass  # no remaining WHERE needed
            return result + "  /* OPTIMIZED: correlated IN subquery rewritten as JOIN */"

        # Pattern 2: WHERE EXISTS (SELECT 1 FROM table WHERE outer.col = inner.col)
        exists_pattern = re.compile(
            r'(?i)(SELECT\s+.+?\s+FROM\s+(\w+)\s+(\w+))'   # outer
            r'(.*?)'                                          # middle
            r'\s+WHERE\s+(.*?)'                               # WHERE prefix
            r'EXISTS\s*\(\s*'                                 # EXISTS (
            r'SELECT\s+(?:1|\*)\s+'                           # SELECT 1 or *
            r'FROM\s+(\w+)\s+(\w+)\s+'                       # FROM inner_table inner_alias
            r'WHERE\s+(\w+\.\w+)\s*=\s*(\w+\.\w+)'          # WHERE correlation
            r'(?:\s+AND\s+(.+?))?'                            # optional extra conditions
            r'\s*\)',                                          # closing paren
            re.DOTALL
        )
        m = exists_pattern.search(normalized)
        if m:
            outer_select = m.group(1)
            middle = m.group(4)
            where_prefix = m.group(5).strip()
            inner_table = m.group(6)
            inner_alias = m.group(7)
            corr_left = m.group(8)
            corr_right = m.group(9)
            extra_cond = m.group(10)
            join_on = f"{corr_left} = {corr_right}"
            if extra_cond:
                join_on += f" AND {extra_cond.strip()}"
            result = f"{outer_select}{middle} JOIN {inner_table} {inner_alias} ON {join_on}"
            remaining_where = where_prefix.strip()
            if remaining_where and remaining_where.upper() not in ('', 'AND', 'OR'):
                remaining_where = re.sub(r'(?i)\s*(AND|OR)\s*$', '', remaining_where).strip()
                if remaining_where:
                    result += f" WHERE {remaining_where}"
            return result + "  /* OPTIMIZED: EXISTS subquery rewritten as JOIN */"

        # Pattern 3: Scalar subquery in SELECT -> window function hint
        scalar_pattern = re.compile(
            r'(?i)SELECT\s+(.+?),\s*\(\s*SELECT\s+(COUNT|SUM|AVG|MAX|MIN)\s*\('
            r'(.+?)\)\s+FROM\s+(\w+)\s+(\w+)\s+WHERE\s+(\w+\.\w+)\s*=\s*(\w+\.\w+)\s*\)',
            re.DOTALL
        )
        m = scalar_pattern.search(normalized)
        if m:
            outer_cols = m.group(1).strip()
            agg_func = m.group(2).upper()
            agg_col = m.group(3).strip()
            inner_table = m.group(4)
            inner_alias = m.group(5)
            corr_left = m.group(6)
            corr_right = m.group(7)
            # Determine partition column from correlation
            partition_col = corr_right if '.' in corr_right else corr_left
            partition_col_name = partition_col.split('.')[-1] if '.' in partition_col else partition_col
            window_expr = f"{agg_func}({agg_col}) OVER (PARTITION BY {partition_col_name})"
            # Replace the scalar subquery with window function
            replacement = re.sub(
                r'(?i)\(\s*SELECT\s+(?:COUNT|SUM|AVG|MAX|MIN)\s*\(.+?\)\s+FROM\s+\w+\s+\w+\s+WHERE\s+\w+\.\w+\s*=\s*\w+\.\w+\s*\)',
                window_expr,
                normalized, count=1
            )
            return replacement + "  /* OPTIMIZED: scalar subquery rewritten as window function */"

        # Fallback: annotate for manual review if pattern not recognized
        return re.sub(
            r'(?i)(\(\s*SELECT\s+)',
            r'/* OPTIMIZE: convert correlated subquery to JOIN or window function -- pattern not auto-recognized */ \1',
            sql, count=1
        )

    @staticmethod
    def _fix_order_without_limit(sql: str) -> str:
        """Optimize ORDER BY queries without adding LIMIT (which could break business logic).

        Instead of adding LIMIT, annotate the ORDER BY as a performance concern
        and suggest removing it if the downstream consumer doesn't need ordering
        (e.g., when followed by GROUP BY or aggregation).
        """
        normalized_upper = re.sub(r'\s+', ' ', sql.upper().strip())
        if re.search(r'ORDER\s+BY', normalized_upper) and not re.search(r'LIMIT\s+\d+', normalized_upper):
            # Don't touch window function ORDER BY
            if re.search(r'OVER\s*\(.*ORDER\s+BY', normalized_upper):
                return sql
            # Check if there's a GROUP BY -- ORDER BY before GROUP BY is usually pointless
            has_group_by = bool(re.search(r'GROUP\s+BY', normalized_upper))
            if has_group_by:
                # Remove the ORDER BY entirely -- sorting before aggregation is wasted work
                result = re.sub(
                    r'\s+ORDER\s+BY\s+[^)]+?(?=\s+GROUP\s+BY)',
                    ' ', sql, flags=re.IGNORECASE
                )
                if result != sql:
                    return result + '  /* OPTIMIZED: removed ORDER BY before GROUP BY -- sorting before aggregation is wasted */'
            # Otherwise annotate as performance concern but don't add LIMIT
            return sql + '  /* PERF WARNING: ORDER BY without LIMIT causes full dataset sort -- remove if ordering not required by downstream */'
        return sql

    @staticmethod
    def _fix_union_without_all(sql: str, safe_for_all: bool = False) -> str:
        """Handle UNION optimization based on safety analysis.

        Only replaces UNION with UNION ALL when data sources are confirmed distinct
        (different tables or each branch already has DISTINCT).
        Otherwise annotates for manual review to avoid breaking business logic.
        """
        if safe_for_all:
            return re.sub(
                r'(?i)\bUNION\b(?!\s+ALL)', 'UNION ALL', sql
            ) + '  /* OPTIMIZED: UNION replaced with UNION ALL -- data sources are distinct, dedup was unnecessary */'
        else:
            return re.sub(
                r'(?i)\bUNION\b(?!\s+ALL)',
                'UNION  /* PERF WARNING: UNION adds DISTINCT sort overhead -- verify if dedup is required, use UNION ALL if not */',
                sql
            )

    @staticmethod
    def _fix_unbounded_aggregation(sql: str) -> str:
        """Annotate unbounded aggregation -- adding WHERE requires domain knowledge."""
        return re.sub(
            r'(?i)(GROUP\s+BY)',
            r'/* OPTIMIZE: add WHERE clause to filter before aggregation */ \1',
            sql, count=1
        )

    @staticmethod
    def _fix_deep_nesting(sql: str) -> str:
        """Annotate deeply nested subqueries."""
        return re.sub(
            r'(?i)(\(\s*SELECT\s+)',
            r'/* OPTIMIZE: refactor to CTE (WITH clause) */ \1',
            sql, count=1
        )

    @staticmethod
    def _annotate_sql_issue(sql: str, message: str) -> str:
        """Add a leading comment to flag the issue."""
        return f"/* OPTIMIZE: {message} */ {sql}"

    def _optimize_all_queries(self, data, _visited=None):
        """Walk the entire JSON tree and apply all SQL fixes to every SQL string found."""
        if _visited is None:
            _visited = set()
        obj_id = id(data)
        if obj_id in _visited:
            return
        _visited.add(obj_id)
        if isinstance(data, dict):
            for key in list(data.keys()):
                val = data[key]
                if isinstance(val, str) and re.search(r'\bSELECT\b', val, re.IGNORECASE):
                    val = self._fix_select_star(val)
                    val = self._fix_order_without_limit(val)
                    val = self._fix_union_without_all(val)
                    data[key] = val
                elif isinstance(val, (dict, list)):
                    self._optimize_all_queries(val, _visited)
        elif isinstance(data, list):
            for i, item in enumerate(data):
                if isinstance(item, str) and re.search(r'\bSELECT\b', item, re.IGNORECASE):
                    item = self._fix_select_star(item)
                    item = self._fix_order_without_limit(item)
                    item = self._fix_union_without_all(item)
                    data[i] = item
                elif isinstance(item, (dict, list)):
                    self._optimize_all_queries(item, _visited)

    @staticmethod
    def _set_yaml_value(data, key, value):
        if isinstance(data, dict):
            for k, v in data.items():
                if k == key:
                    data[k] = value
                    return True
                if isinstance(v, dict):
                    if TransformationEngine._set_yaml_value(v, key, value):
                        return True
        return False

    @staticmethod
    def _get_yaml_value(data, key):
        if isinstance(data, dict):
            for k, v in data.items():
                if k == key:
                    return v
                if isinstance(v, dict):
                    r = TransformationEngine._get_yaml_value(v, key)
                    if r is not None:
                        return r
        return None


# =============================================================================
# LLM Rule Learner (Optional Fallback)
# =============================================================================

class LLMRuleLearner:
    """
    When no existing RCA rule detects an issue for a threshold-exceeding job,
    optionally invoke an LLM to analyze artifacts and generate a new rule.
    """

    RULE_GENERATION_PROMPT = textwrap.dedent("""\
    You are an expert AWS Glue / PySpark performance analyst.

    A Glue job exceeded its execution threshold but no existing RCA rule detected the issue.
    Analyze the following artifacts and generate a NEW deterministic RCA rule.

    Job: {job_name}
    Execution Duration: {execution_duration} min (threshold: {threshold_limit} min)

    === Python Script ===
    {python_source}

    === YAML Configuration ===
    {yml_source}

    === JSON Configuration ===
    {json_source}

    === CloudWatch Logs ===
    {log_text}

    Generate a Python class that:
    1. Inherits from RCARule
    2. Has a unique rule_id (format: "RCA-LLM-XXX")
    3. Implements detect(), classify_severity(), recommend_fix(), transformation_mapping()
    4. Uses AST analysis for Python issues, structured parsing for YAML/JSON
    5. Is deterministic and generic (not specific to this exact job)

    CRITICAL - transformation_mapping() MUST return a dict with these fields:
      For Python issues:
        {{"artifact_type": "python", "action": "llm_line_replace",
          "line": <line_number>, "old_code": "<exact original line>",
          "new_code": "<optimized replacement line>"}}
      For YAML config issues:
        {{"artifact_type": "yaml", "action": "llm_yaml_update",
          "key": "<yaml key path e.g. NumberOfWorkers>",
          "new_value": "<new value>"}}
      For JSON/SQL issues:
        {{"artifact_type": "json", "action": "llm_json_update",
          "json_path": "<dotted path e.g. table_queries.orders.sql>",
          "old_sql": "<original SQL>", "new_sql": "<optimized SQL>"}}

    You can also reuse existing engine actions if applicable:
      Python: "remove_unnecessary_action", "replace_collect", "remove_or_adjust_repartition",
              "replace_data_amplification", "replace_to_pandas", "remove_coalesce_one",
              "replace_group_by_key", "remove_sleep", "flag_cache_leak"
      YAML:   "scale_workers", "increase_workers", "increase_timeout"
      JSON:   "replace_select_star", "flag_order_without_limit", "flag_missing_join_predicate"

    Return ONLY the Python class code, no explanations.
    """)

    def __init__(self, enabled=False, model_id="anthropic.claude-3-sonnet-20240229-v1:0",
                 rules_dir="output/rules"):
        self.enabled = enabled
        self.model_id = model_id
        self.rules_dir = rules_dir

    def learn_rule(self, job_info: dict, artifacts: dict) -> list:
        if not self.enabled:
            return []
        try:
            import boto3
            bedrock = boto3.client("bedrock-runtime", region_name="us-east-1")
        except Exception as e:
            print(f"[LLM Learner] Bedrock init failed: {e}")
            return []

        prompt = self.RULE_GENERATION_PROMPT.format(
            job_name=job_info.get("job_name", "unknown"),
            execution_duration=job_info.get("execution_duration", "?"),
            threshold_limit=job_info.get("threshold_limit", "?"),
            python_source=artifacts.get("python_source", "N/A")[:3000],
            yml_source=artifacts.get("yml_source", "N/A")[:1500],
            json_source=artifacts.get("json_source", "N/A")[:2000],
            log_text=artifacts.get("log_text", "N/A")[:2000],
        )

        try:
            response = bedrock.invoke_model(
                modelId=self.model_id,
                contentType="application/json", accept="application/json",
                body=json.dumps({
                    "anthropic_version": "bedrock-2023-05-31",
                    "max_tokens": 4096,
                    "messages": [{"role": "user", "content": prompt}],
                }),
            )
            resp_body = json.loads(response["body"].read())
            rule_code = resp_body["content"][0]["text"]
        except Exception as e:
            print(f"[LLM Learner] Bedrock invocation failed: {e}")
            return []

        return self._register_and_run(rule_code, artifacts, job_info)

    def _register_and_run(self, rule_code: str, artifacts: dict, job_info: dict) -> list:
        code_match = re.search(r'(class\s+\w+.*?)(?=\nclass\s|\Z)', rule_code, re.DOTALL)
        if not code_match:
            print("[LLM Learner] Could not extract class from response")
            return []

        class_code = code_match.group(1).strip()
        try:
            tree = ast.parse(class_code)
        except SyntaxError as e:
            print(f"[LLM Learner] Generated code syntax error: {e}")
            return []

        class_name = None
        for node in ast.walk(tree):
            if isinstance(node, ast.ClassDef):
                class_name = node.name
                break
        if not class_name:
            return []

        # Save to external rules directory (backward compatible)
        rule_filepath = os.path.join(self.rules_dir, f"llm_rule_{class_name.lower()}.py")
        full_code = (
            "import ast, re, json\n"
            "from glue_optimization_engine import RCARule, safe_parse_ast, ASTPatternVisitor\n\n"
            + class_code
        )
        os.makedirs(self.rules_dir, exist_ok=True)
        with open(rule_filepath, "w") as f:
            f.write(full_code)
        print(f"[LLM Learner] Persisted rule to {rule_filepath}")

        # Inject the new rule into the engine script itself so future
        # runs are fully self-contained without needing the external file
        self._inject_rule_into_engine(class_code, class_name)

        namespace = {"RCARule": RCARule, "ast": ast, "re": re, "json": json,
                     "safe_parse_ast": safe_parse_ast, "ASTPatternVisitor": ASTPatternVisitor}
        try:
            exec(class_code, namespace)
            rule_cls = namespace.get(class_name)
            if rule_cls:
                instance = rule_cls()
                RULE_REGISTRY.append(instance)
                print(f"[LLM Learner] Registered: {instance.rule_id} - {instance.rule_name}")
                return instance.detect(artifacts)
        except Exception as e:
            print(f"[LLM Learner] Failed to instantiate: {e}")
        return []

    def _inject_rule_into_engine(self, class_code: str, class_name: str):
        """Inject an LLM-generated rule directly into the engine .py file.

        Inserts the new rule class (with @register_rule decorator) just before
        the LLMRuleLearner class definition, so next time the engine runs,
        the rule is a built-in rule -- no LLM call needed.
        """
        try:
            engine_path = os.path.abspath(__file__)
            with open(engine_path, "r") as f:
                engine_source = f.read()

            # Check if this rule class is already in the engine
            if f"class {class_name}" in engine_source:
                print(f"[LLM Learner] Rule {class_name} already in engine, skipping injection")
                return

            # Prepare the rule code with @register_rule decorator
            injection_block = (
                f"\n\n# --- LLM-Generated Rule (auto-injected) ---\n"
                f"@register_rule\n"
                f"{class_code}\n"
                f"# --- End LLM-Generated Rule ---\n"
            )

            # Insert just before the LLMRuleLearner class
            marker = "class LLMRuleLearner:"
            marker_pos = engine_source.find(marker)
            if marker_pos == -1:
                print(f"[LLM Learner] Could not find insertion point in engine")
                return

            updated_source = (
                engine_source[:marker_pos]
                + injection_block + "\n"
                + engine_source[marker_pos:]
            )

            with open(engine_path, "w") as f:
                f.write(updated_source)
            print(f"[LLM Learner] Injected {class_name} into engine script: {engine_path}")
            print(f"[LLM Learner] Future runs will use this rule WITHOUT calling LLM")
        except Exception as e:
            print(f"[LLM Learner] Engine injection failed (rule still saved to {self.rules_dir}): {e}")


# =============================================================================
# Dynamic Rule Loader
# =============================================================================

def load_external_rules(rules_dir: str):
    if not os.path.isdir(rules_dir):
        return
    existing_ids = {r.rule_id for r in RULE_REGISTRY}
    for filepath in sorted(glob.glob(os.path.join(rules_dir, "*.py"))):
        if filepath.endswith("__init__.py"):
            continue
        module_name = os.path.basename(filepath).replace(".py", "")
        try:
            spec = importlib.util.spec_from_file_location(module_name, filepath)
            mod = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(mod)
            for attr_name in dir(mod):
                attr = getattr(mod, attr_name)
                if isinstance(attr, type) and issubclass(attr, RCARule) and attr is not RCARule:
                    instance = attr()
                    if instance.rule_id not in existing_ids:
                        RULE_REGISTRY.append(instance)
                        existing_ids.add(instance.rule_id)
                        print(f"[Loader] Loaded external rule: {instance.rule_id}")
        except Exception as e:
            print(f"[Loader] Failed to load {filepath}: {e}")


# =============================================================================
# Validation Engine
# =============================================================================

class ValidationEngine:
    @staticmethod
    def validate(original_findings: list, optimized_artifacts: dict) -> dict:
        original_rule_ids = {f.get("rule_id") for f in original_findings}

        # Rules that analyse historical log text should be skipped during
        # re-validation because the log never changes.  Their transforms have
        # already been applied to python/yaml/json artifacts.
        log_analysis_rules = set()
        for f in original_findings:
            t = f.get("transformation", {})
            if t.get("artifact_type") in ("python", "yaml", "json", "log"):
                # If the rule's category is runtime_analysis it reads from log_text
                if f.get("rule_id", "").startswith("RCA-04"):
                    log_analysis_rules.add(f.get("rule_id"))

        remaining = []
        newly_found = []
        for rule in RULE_REGISTRY:
            if rule.rule_id in log_analysis_rules:
                continue
            new_findings = rule.detect(optimized_artifacts)
            for f in new_findings:
                if f.get("artifact") in ("python", "yaml", "json"):
                    if f.get("rule_id") in original_rule_ids:
                        remaining.append(f)
                    else:
                        newly_found.append(f)
        resolved = len(original_findings) - len(remaining)
        all_remaining = remaining + newly_found
        return {
            "status": "passed" if not remaining else "partial",
            "original_finding_count": len(original_findings),
            "resolved_count": max(resolved, 0),
            "remaining_findings": all_remaining,
        }


# =============================================================================
# Main Orchestrator
# =============================================================================

class GlueOptimizationEngine:

    @staticmethod
    def _safe_path(base_dir: str, *parts: str) -> str:
        joined = os.path.join(base_dir, *parts)
        resolved = os.path.realpath(joined)
        if not resolved.startswith(os.path.realpath(base_dir) + os.sep) and resolved != os.path.realpath(base_dir):
            raise ValueError(f"Path traversal blocked: {joined!r} escapes {base_dir!r}")
        return resolved

    def __init__(self, knowledgebase_dir: str, output_dir: str,
                 llm_enabled: bool = False,
                 llm_model_id: str = "anthropic.claude-3-sonnet-20240229-v1:0"):
        self.kb_dir = os.path.realpath(knowledgebase_dir)
        self.output_dir = os.path.realpath(output_dir)
        self.transformer = TransformationEngine()
        self.validator = ValidationEngine()
        self.llm_learner = LLMRuleLearner(
            enabled=llm_enabled, model_id=llm_model_id,
            rules_dir=self._safe_path(self.output_dir, "rules"),
        )
        self.results = []
        for d in ("", "rca_reports", "optimized", "rules"):
            os.makedirs(self._safe_path(self.output_dir, d) if d else self.output_dir, exist_ok=True)

    def run(self):
        print("=" * 60)
        print("Glue Optimization Engine v2.0 -- Starting")
        print("=" * 60)

        load_external_rules(self._safe_path(self.output_dir, "rules"))
        print(f"[Engine] {len(RULE_REGISTRY)} RCA rules loaded")

        jobs = self._read_metrics()
        if not jobs:
            print("[Engine] No jobs found. Terminating.")
            sys.exit(0)

        qualifying = [j for j in jobs if j["execution_duration"] > j["threshold_limit"]]
        if not qualifying:
            print("[Engine] No jobs exceed threshold. Terminating.")
            sys.exit(0)

        for j in jobs:
            if j not in qualifying:
                print(f"[Engine] SKIP: {j['job_name']} ({j['execution_duration']}min <= {j['threshold_limit']}min)")

        print(f"[Engine] {len(qualifying)} jobs exceed threshold\n")

        for job in qualifying:
            print(f"{'-' * 50}")
            print(f"[Engine] Processing: {job['job_name']}")
            print(f"{'-' * 50}")
            self._process_job(job)

        self._write_summary()
        self._write_validation_report()
        print("\n" + "=" * 60)
        print("Glue Optimization Engine v2.0 -- Complete")
        print("=" * 60)

    def _read_metrics(self) -> list[dict]:
        xlsx_path = self._safe_path(self.kb_dir, "glue_job_metrics.xlsx")
        if not os.path.exists(xlsx_path):
            print(f"[Engine] ERROR: {xlsx_path} not found")
            return []
        wb = openpyxl.load_workbook(xlsx_path, read_only=True)
        ws = wb.active
        rows = list(ws.iter_rows(values_only=True))
        if len(rows) < 2:
            return []
        headers = [str(h).strip() for h in rows[0]]
        jobs = []
        for row in rows[1:]:
            entry = dict(zip(headers, row))
            entry["threshold_limit"] = int(entry.get("threshold_limit", 0))
            entry["execution_duration"] = int(entry.get("execution_duration", 0))
            jobs.append(entry)
        wb.close()
        return jobs

    # Rule categories for phased processing
    PHASE1_RULES = {
        # Config/infra -- fix these first (most common root cause)
        "RCA-001",   # Syntax errors (must parse before anything)
        "RCA-030",   # Worker scaling / timeout
        "RCA-040",   # Log-based duration anomaly (drives config + targeted code fixes)
        "RCA-041",   # OOM -> scale config
        "RCA-042",   # GC overhead -> scale config
        "RCA-043",   # Shuffle spill -> scale config
        "RCA-044",   # Data skew -> enable AQE config
        "RCA-045",   # Connection timeout -> config
        "RCA-047",   # Spark/Glue version config issues
    }
    # RCA-046 is special -- runs only when no other rules find issues (advisory-only)

    def _process_job(self, job: dict):
        artifacts = self._load_artifacts(job)
        if artifacts is None:
            return

        artifacts["_execution_duration"] = job["execution_duration"]
        artifacts["_threshold_limit"] = job["threshold_limit"]

        # Extract data volume from logs -- used by transforms to size partitions
        log_text = artifacts.get("log_text", "")
        row_counts = extract_row_counts_from_log(log_text)
        total_data_rows = sum(row_counts) if row_counts else 0

        # -- Phase 1: Log analysis + Config/Infra fixes --
        # Check CloudWatch logs first to find where the job is slow,
        # then fix config (workers, DPU, timeout, persist) before touching code.
        phase1_findings = []
        for rule in RULE_REGISTRY:
            if rule.rule_id not in self.PHASE1_RULES:
                continue
            findings = rule.detect(artifacts)
            for f in findings:
                f["severity"] = rule.classify_severity(f)
                f["recommendation"] = rule.recommend_fix(f)
                f["transformation"] = rule.transformation_mapping(f)
                f["transformation"]["total_data_rows"] = total_data_rows
                f["phase"] = 1
            phase1_findings.extend(findings)

        if phase1_findings:
            print(f"[Engine] Phase 1 (config/infra): {len(phase1_findings)} findings")

        # Apply Phase 1 transforms (config/infra)
        opt_py = artifacts.get("python_source", "")
        opt_yml = artifacts.get("yml_config")
        opt_json = artifacts.get("json_config")

        py_t1 = [f["transformation"] for f in phase1_findings if f["transformation"].get("artifact_type") == "python"]
        yml_t1 = [f["transformation"] for f in phase1_findings if f["transformation"].get("artifact_type") == "yaml"]
        json_t1 = [f["transformation"] for f in phase1_findings if f["transformation"].get("artifact_type") == "json"]

        if py_t1 and opt_py:
            opt_py = self.transformer.apply_python_transforms(opt_py, py_t1)
        if yml_t1 and opt_yml:
            opt_yml = self.transformer.apply_yaml_transforms(opt_yml, yml_t1)
        if json_t1 and opt_json:
            opt_json = self.transformer.apply_json_transforms(opt_json, json_t1)

        # -- Phase 2: Code optimization (only where logs show slowness) --
        # Now run remaining rules on the Phase-1-optimized artifacts.
        # These code-level fixes only apply if the log analysis identified
        # a code pattern as the bottleneck.
        phase1_artifacts = {
            "python_source": opt_py, "yml_config": opt_yml, "json_config": opt_json,
            "log_text": log_text,
            "yml_source": yaml.dump(opt_yml) if opt_yml else "",
            "json_source": json.dumps(opt_json, indent=2) if opt_json else "",
            "_execution_duration": job["execution_duration"],
            "_threshold_limit": job["threshold_limit"],
        }

        # Collect the slow code lines identified by RCA-040 log correlation
        log_slow_lines = set()
        log_slow_operations = set()
        for f in phase1_findings:
            if f.get("rule_id") == "RCA-040":
                src_line = f.get("source_line", -1)
                if src_line > 0:
                    # Include the source line and surrounding context (+/-10 lines)
                    for offset in range(-10, 15):
                        log_slow_lines.add(src_line + offset)
                op = f.get("root_cause_operation")
                if op:
                    log_slow_operations.add(op)

        phase2_findings = []
        for rule in RULE_REGISTRY:
            if rule.rule_id in self.PHASE1_RULES:
                continue
            findings = rule.detect(phase1_artifacts)
            for f in findings:
                f["severity"] = rule.classify_severity(f)
                f["recommendation"] = rule.recommend_fix(f)
                f["transformation"] = rule.transformation_mapping(f)
                f["transformation"]["total_data_rows"] = total_data_rows
                f["phase"] = 2
            phase2_findings.extend(findings)

        if phase2_findings:
            print(f"[Engine] Phase 2 (code optimization): {len(phase2_findings)} findings")

        # Apply Phase 2 transforms
        py_t2 = [f["transformation"] for f in phase2_findings if f["transformation"].get("artifact_type") == "python"]
        yml_t2 = [f["transformation"] for f in phase2_findings if f["transformation"].get("artifact_type") == "yaml"]
        json_t2 = [f["transformation"] for f in phase2_findings if f["transformation"].get("artifact_type") == "json"]

        if py_t2 and opt_py:
            opt_py = self.transformer.apply_python_transforms(opt_py, py_t2)
        if yml_t2 and opt_yml:
            opt_yml = self.transformer.apply_yaml_transforms(opt_yml, yml_t2)
        if json_t2 and opt_json:
            opt_json = self.transformer.apply_json_transforms(opt_json, json_t2)

        # -- Combine findings and validate --
        all_findings = phase1_findings + phase2_findings

        # -- RCA-046: All-optimized-but-still-slow advisory --
        # If no findings from Phase 1 or 2, check if this is a data volume issue
        if not all_findings:
            advisory_artifacts = dict(phase1_artifacts)
            advisory_artifacts["_no_other_findings"] = True
            for rule in RULE_REGISTRY:
                if rule.rule_id == "RCA-046":
                    advisory_findings = rule.detect(advisory_artifacts)
                    for f in advisory_findings:
                        f["severity"] = rule.classify_severity(f)
                        f["recommendation"] = rule.recommend_fix(f)
                        f["transformation"] = rule.transformation_mapping(f)
                        f["phase"] = 2
                    all_findings.extend(advisory_findings)
                    if advisory_findings:
                        print(f"[Engine] Advisory: job appears optimized but exceeds threshold -- likely data volume issue")
                    break

        if not all_findings and self.llm_learner.enabled:
            print(f"[Engine] No rules matched. Invoking LLM learner...")
            llm_findings = self.llm_learner.learn_rule(job, artifacts)
            for f in llm_findings:
                f["phase"] = 3  # LLM-generated phase
                for rule in RULE_REGISTRY:
                    if f.get("rule_id") == rule.rule_id:
                        f["severity"] = rule.classify_severity(f)
                        f["recommendation"] = rule.recommend_fix(f)
                        f["transformation"] = rule.transformation_mapping(f)
                        f["transformation"]["total_data_rows"] = total_data_rows
                        break
            all_findings.extend(llm_findings)

            # Apply LLM-generated transforms to produce optimized artifacts
            if llm_findings:
                llm_py_t = [f["transformation"] for f in llm_findings if f.get("transformation", {}).get("artifact_type") == "python"]
                llm_yml_t = [f["transformation"] for f in llm_findings if f.get("transformation", {}).get("artifact_type") == "yaml"]
                llm_json_t = [f["transformation"] for f in llm_findings if f.get("transformation", {}).get("artifact_type") == "json"]
                if llm_py_t and opt_py:
                    opt_py = self.transformer.apply_python_transforms(opt_py, llm_py_t)
                if llm_yml_t and opt_yml:
                    opt_yml = self.transformer.apply_yaml_transforms(opt_yml, llm_yml_t)
                if llm_json_t and opt_json:
                    opt_json = self.transformer.apply_json_transforms(opt_json, llm_json_t)
                print(f"[Engine] LLM phase: applied {len(llm_py_t)} Python, {len(llm_yml_t)} YAML, {len(llm_json_t)} JSON transforms")

        if not all_findings:
            print(f"[Engine] No root causes detected for {job['job_name']}")
            self._write_rca_report(job, [], "no_issues_detected")
            self.results.append({"job": job, "findings": [], "validation": {"status": "passed"}, "optimized": False})
            return

        print(f"[Engine] {len(all_findings)} findings for {job['job_name']}")

        optimized_artifacts = {
            "python_source": opt_py, "yml_config": opt_yml, "json_config": opt_json,
            "log_text": log_text,
            "yml_source": yaml.dump(opt_yml) if opt_yml else "",
            "json_source": json.dumps(opt_json, indent=2) if opt_json else "",
            "_execution_duration": job["execution_duration"],
            "_threshold_limit": job["threshold_limit"],
        }

        validation = self.validator.validate(all_findings, optimized_artifacts)
        print(f"[Engine] Validation: {validation['status']} ({validation['resolved_count']}/{validation['original_finding_count']} resolved)")

        llm_py_t = [f["transformation"] for f in all_findings if f.get("phase") == 3 and f.get("transformation", {}).get("artifact_type") == "python"]
        llm_yml_t = [f["transformation"] for f in all_findings if f.get("phase") == 3 and f.get("transformation", {}).get("artifact_type") == "yaml"]
        llm_json_t = [f["transformation"] for f in all_findings if f.get("phase") == 3 and f.get("transformation", {}).get("artifact_type") == "json"]
        all_py_t = py_t1 + py_t2 + llm_py_t
        all_yml_t = yml_t1 + yml_t2 + llm_yml_t
        all_json_t = json_t1 + json_t2 + llm_json_t
        self._write_rca_report(job, all_findings, validation["status"])
        self._write_optimized_artifacts(job, opt_py, opt_yml, opt_json, all_py_t, all_yml_t, all_json_t)
        self.results.append({"job": job, "findings": all_findings, "validation": validation, "optimized": True})

    def _load_artifacts(self, job: dict) -> dict | None:
        job_name = job["job_name"]
        log_name = job.get("cloudwatch_log_name")
        yml_name = job.get("variable_yml_name")
        json_name = job.get("json_config_name")

        py_path = self._safe_path(self.kb_dir, job_name)
        log_path = self._safe_path(self.kb_dir, log_name) if log_name else None
        yml_path = self._safe_path(self.kb_dir, yml_name) if yml_name else None
        json_path = self._safe_path(self.kb_dir, json_name) if json_name else None

        missing = []
        if not os.path.exists(py_path):
            missing.append(job_name)
        if log_name and not os.path.exists(log_path):
            missing.append(log_name)
        if yml_name and not os.path.exists(yml_path):
            missing.append(yml_name)

        if missing:
            print(f"[Engine] SKIP {job_name}: missing: {missing}")
            self._write_rca_report(job, [], "skipped_missing_files", missing)
            self.results.append({"job": job, "findings": [],
                                 "validation": {"status": "skipped", "reason": f"missing: {missing}"},
                                 "optimized": False})
            return None

        artifacts = {}
        with open(py_path, "r") as f:
            artifacts["python_source"] = f.read()
        if log_path and os.path.exists(log_path):
            with open(log_path, "r") as f:
                artifacts["log_text"] = f.read()
        else:
            artifacts["log_text"] = ""
        if yml_path and os.path.exists(yml_path):
            with open(yml_path, "r") as f:
                artifacts["yml_source"] = f.read()
                f.seek(0)
                try:
                    artifacts["yml_config"] = yaml.safe_load(f)
                except yaml.YAMLError:
                    artifacts["yml_config"] = {}
        else:
            artifacts["yml_source"] = ""
            artifacts["yml_config"] = {}
        if json_path and os.path.exists(json_path):
            with open(json_path, "r") as f:
                artifacts["json_source"] = f.read()
                f.seek(0)
                try:
                    artifacts["json_config"] = json.load(f)
                except json.JSONDecodeError:
                    artifacts["json_config"] = {}
        else:
            artifacts["json_source"] = ""
            artifacts["json_config"] = None

        print(f"[Engine] Loaded artifacts for {job_name}")
        return artifacts

    def _write_rca_report(self, job, findings, status, missing_files=None):
        job_stem = os.path.basename(job["job_name"]).replace(".py", "")
        path = self._safe_path(self.output_dir, "rca_reports", f"{job_stem}_rca.yaml")
        report = {
            "job_name": job["job_name"],
            "execution_duration_minutes": job["execution_duration"],
            "threshold_limit_minutes": job["threshold_limit"],
            "analysis_timestamp": datetime.datetime.now().isoformat(),
            "status": status,
        }
        if missing_files:
            report["skip_reason"] = f"Missing: {', '.join(missing_files)}"
        if findings:
            report["root_causes"] = []
            for f in findings:
                rc = {
                    "rule_id": f.get("rule_id"), "description": f.get("description"),
                    "severity": f.get("severity"), "category": f.get("category", ""),
                    "artifact": f.get("artifact"), "recommendation": f.get("recommendation"),
                }
                if "line" in f:
                    rc["line"] = f["line"]
                report["root_causes"].append(rc)
        with open(path, "w") as fp:
            yaml.dump(report, fp, default_flow_style=False, sort_keys=False, width=120)
        print(f"[Engine] RCA report: {path}")

    def _write_optimized_artifacts(self, job, opt_py, opt_yml, opt_json, py_t, yml_t, json_t):
        job_stem = os.path.basename(job["job_name"]).replace(".py", "")
        opt_dir = self._safe_path(self.output_dir, "optimized")
        if py_t and opt_py:
            with open(self._safe_path(opt_dir, os.path.basename(job["job_name"])), "w") as f:
                f.write(opt_py)
        if yml_t and opt_yml:
            yml_name = os.path.basename(job.get("variable_yml_name", f"{job_stem}.yml"))
            with open(self._safe_path(opt_dir, yml_name), "w") as f:
                yaml.dump(opt_yml, f, default_flow_style=False, sort_keys=False)
        if json_t and opt_json:
            json_name = job.get("json_config_name")
            if json_name:
                with open(self._safe_path(opt_dir, os.path.basename(json_name)), "w") as f:
                    json.dump(opt_json, f, indent=2)

    def _write_summary(self):
        path = self._safe_path(self.output_dir, "optimization_summary.md")
        lines = [
            "# Glue Optimization Summary (v2.0)",
            f"\nGenerated: {datetime.datetime.now().isoformat()}",
            f"\nTotal jobs analyzed: {len(self.results)}",
            f"Total rules available: {len(RULE_REGISTRY)}", "",
        ]
        for r in self.results:
            job = r["job"]
            lines.append(f"## {job['job_name']}")
            lines.append(f"- Duration: {job['execution_duration']}min (threshold: {job['threshold_limit']}min)")
            lines.append(f"- Findings: {len(r['findings'])}")
            lines.append(f"- Validation: {r['validation'].get('status', 'N/A')}")
            lines.append(f"- Optimized: {'Yes' if r['optimized'] else 'No'}")
            if r["findings"]:
                lines.append("\n### Root Causes")
                for f in r["findings"]:
                    lines.append(f"- **[{f.get('rule_id')}]** {f.get('description')} (severity: {f.get('severity')})")
            lines.append("")
        with open(path, "w") as f:
            f.write("\n".join(lines))
        print(f"[Engine] Summary: {path}")

    def _write_validation_report(self):
        path = self._safe_path(self.output_dir, "reviewer_validation.yaml")
        report = {"validation_timestamp": datetime.datetime.now().isoformat(), "jobs": []}
        all_passed = True
        for r in self.results:
            entry = {"job_name": r["job"]["job_name"], "status": r["validation"].get("status"),
                     "findings_count": len(r["findings"]), "optimized": r["optimized"]}
            if entry["status"] not in ("passed", "skipped"):
                all_passed = False
            report["jobs"].append(entry)
        report["overall_status"] = "passed" if all_passed else "partial"
        report["total_rules_available"] = len(RULE_REGISTRY)
        with open(path, "w") as f:
            yaml.dump(report, f, default_flow_style=False, sort_keys=False)
        print(f"[Engine] Validation: {path}")


# =============================================================================
# CLI Entry Point
# =============================================================================

def main():
    import argparse
    parser = argparse.ArgumentParser(description="Glue Optimization Engine v2.0")
    parser.add_argument("--knowledgebase", "-k", default="knowledgebase")
    parser.add_argument("--output", "-o", default="output")
    parser.add_argument("--llm-enabled", action="store_true")
    parser.add_argument("--llm-model-id", default="anthropic.claude-3-sonnet-20240229-v1:0")
    args = parser.parse_args()

    engine = GlueOptimizationEngine(
        knowledgebase_dir=args.knowledgebase, output_dir=args.output,
        llm_enabled=args.llm_enabled, llm_model_id=args.llm_model_id,
    )
    engine.run()


if __name__ == "__main__":
    main()
