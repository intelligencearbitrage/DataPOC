"""
STTM Validation Test Suite
Validates generated STTM Excel workbooks against source .bin/.prm input files.
10 test cases per STTM workbook.

Usage:
    python scripts/test_sttm_validation.py
"""

import json
import re
import os
import sys
from pathlib import Path
from collections import defaultdict

import openpyxl

PROJECT_ROOT = Path(__file__).resolve().parent.parent.parent
INPUTS_DIR = PROJECT_ROOT / 'inputs'
OUTPUT_DIR = PROJECT_ROOT / 'output'


# ---------------------------------------------------------------------------
# Helpers — reuse parsing logic from generate_sttm.py
# ---------------------------------------------------------------------------

def parse_prm(prm_path):
    params = {}
    with open(prm_path, 'r') as f:
        section = 'Global'
        for line in f:
            line = line.strip()
            if not line or line.startswith('#'):
                continue
            if line.startswith('['):
                section = line[:line.rfind(']') + 1]
                continue
            if '=' in line and section in ('Global', '[Global]'):
                k, v = line.split('=', 1)
                params[k.strip()] = v.strip()
    return params


def resolve_text(text, params):
    if not text:
        return text
    result = text
    for key, value in sorted(params.items(), key=lambda x: -len(x[0])):
        if key.startswith('$$'):
            result = result.replace(key, value)
    return result


def identify_type(t):
    if 'dataAdapter' in t:
        da = t['dataAdapter']
        obj = da.get('object', {})
        cq = (obj.get('customQuery') or '').strip()
        on = (obj.get('objectName') or '').strip()
        if 'fieldMappingMode' in t:
            return 'TARGET'
        name_lower = t.get('name', '').lower()
        if cq:
            # Lookups have customQuery but are named lkp_*/Lookup*
            if (name_lower.startswith(('lkp_', 'lookup')) and
                    not name_lower.startswith(('src_', 'source'))):
                return 'LOOKUP'
            return 'SOURCE'
        if on and not cq:
            return 'TARGET'
        if name_lower.startswith(('src_', 'source')):
            return 'SOURCE'
        if name_lower.startswith(('tgt_', 'target')):
            return 'TARGET'
    if 'joinConditions' in t:
        return 'JOINER'
    if 'inputGroups' in t:
        return 'UNION'
    if 'groupFilterConditions' in t:
        return 'ROUTER'
    if 'sortEntries' in t:
        return 'SORTER'
    if 'filterConditions' in t:
        return 'FILTER'
    fields = t.get('fields', [])
    has_agg = any(
        f.get('expression', '') and
        re.search(r'\b(SUM|COUNT|AVG|MAX|MIN|FIRST|LAST)\s*\(', f.get('expression', ''), re.IGNORECASE)
        for f in fields
    )
    if has_agg:
        return 'AGGREGATOR'
    if 'state' in t and 'incrementBy' in t.get('state', {}):
        return 'SEQUENCE'
    return 'EXPRESSION'


def get_source_table(t, params):
    """Get resolved source table from a SOURCE transformation."""
    da = t.get('dataAdapter', {})
    obj = da.get('object', {})
    query = obj.get('customQuery', '')
    resolved = resolve_text(query, params)
    tables = re.findall(r'\bFROM\s+(\S+?)(?:\s|$|;|\))', resolved, re.IGNORECASE)
    cleaned = []
    for tbl in tables:
        tbl = tbl.strip('(').strip(')').strip(',')
        if tbl.upper() in ('SELECT', 'WHERE', 'GROUP', 'ORDER', 'HAVING', 'UNION', 'LIMIT', '('):
            continue
        if tbl:
            cleaned.append(tbl)
    return cleaned[0] if cleaned else ''


def get_target_table(t, params):
    """Get resolved target table from a TARGET transformation."""
    da = t.get('dataAdapter', {})
    obj = da.get('object', {})
    object_name = obj.get('objectName', '')
    schema_keys = ['$$cfsib_schema', '$$jpSchemaName', '$$jpschema_name',
                   '$$EDM_HUB_IVR_PUBLISH_DB_SCHEMA1', '$$EDM_HUB_IVR_PUBLISH_DB_SCHEMA',
                   '$$EDM_HUB_PZ_INSURANCE_CSX_SCHEMA', '$$Tgt_reject']
    schema = ''
    for key in schema_keys:
        schema = params.get(key, '')
        if schema:
            break
    if schema and object_name:
        return f'{schema}.{object_name}'
    return object_name


def discover_pairs():
    """Match .bin files to .prm/.param files. Returns (bin_path, [param_paths])."""
    bin_files = sorted(INPUTS_DIR.glob('*.bin'))
    param_files = list(INPUTS_DIR.glob('*.prm')) + list(INPUTS_DIR.glob('*.param'))
    pairs = []
    for bf in bin_files:
        stem = bf.stem.lower()
        matched = []
        if stem.startswith('gmad_'):
            for pf in param_files:
                if 'gmad' in pf.stem.lower():
                    matched = [pf]
                    break
        elif stem.startswith('pdds_'):
            for pf in param_files:
                if 'pdds' in pf.stem.lower():
                    matched = [pf]
                    break
        elif stem.startswith('ivr_'):
            base = None
            specific = None
            for pf in param_files:
                pf_lower = pf.stem.lower()
                if 'ivrcalllogs' in pf_lower or ('ivr' in pf_lower and 'csx' in pf_lower):
                    specific = pf
                elif 'csx' in pf_lower and 'ivr' not in pf_lower:
                    base = pf
            matched = [p for p in [base, specific] if p]
        if not matched:
            for pf in param_files:
                if 'csx' in pf.stem.lower() and 'ivr' not in pf.stem.lower():
                    matched = [pf]
                    break
        if not matched and param_files:
            matched = [param_files[0]]
        if matched:
            pairs.append((bf, matched))
    return pairs


# ---------------------------------------------------------------------------
# Test Cases
# ---------------------------------------------------------------------------

class TestResult:
    def __init__(self, test_id, name, passed, expected, actual, detail=''):
        self.test_id = test_id
        self.name = name
        self.passed = passed
        self.expected = expected
        self.actual = actual
        self.detail = detail

    def __str__(self):
        status = 'PASS' if self.passed else 'FAIL'
        s = f"  [{status}] TC-{self.test_id}: {self.name}"
        if not self.passed:
            s += f"\n         Expected: {self.expected}"
            s += f"\n         Actual:   {self.actual}"
            if self.detail:
                s += f"\n         Detail:   {self.detail}"
        return s


def run_tests_for_mapping(bin_path, prm_paths):
    """Run 10 test cases for a single mapping's STTM output."""
    # Load ground truth
    with open(bin_path) as f:
        data = json.load(f)
    content = data['content']
    transformations = content.get('transformations', [])
    links = content.get('links', [])
    # Merge params from all param files
    params = {}
    for pp in prm_paths:
        params.update(parse_prm(pp))

    # Classify transformations
    type_map = {}
    for t in transformations:
        type_map[t['name']] = identify_type(t)

    sources = [t for t in transformations if type_map[t['name']] in ('SOURCE', 'LOOKUP')]
    targets = [t for t in transformations if type_map[t['name']] == 'TARGET']

    # Load STTM workbook
    xlsx_name = f'{bin_path.stem}_sttm.xlsx'
    xlsx_path = OUTPUT_DIR / xlsx_name
    if not xlsx_path.exists():
        return [TestResult(i, f"Workbook exists ({xlsx_name})", False, 'File exists', 'File not found')
                for i in range(1, 11)]

    wb = openpyxl.load_workbook(str(xlsx_path))
    results = []

    # ---- TC-1: Tab Order ----
    expected_prefix = ['Index', 'Version History', 'Summary']
    expected_suffix = ['Lookup_Definitions', 'Transformation_Logic', 'Data_Flow']
    sheets = wb.sheetnames
    prefix_ok = sheets[:3] == expected_prefix
    suffix_ok = sheets[-3:] == expected_suffix
    results.append(TestResult(
        1, "Workbook tab order (Index > Version History > Summary > STTM tabs > Lookup > Transformation > Data_Flow)",
        prefix_ok and suffix_ok,
        f"Prefix={expected_prefix}, Suffix={expected_suffix}",
        f"Prefix={sheets[:3]}, Suffix={sheets[-3:]}",
    ))

    # ---- TC-2: All sources captured in Lookup_Definitions ----
    ws_lookup = wb['Lookup_Definitions']
    lookup_source_names = set()
    for row in ws_lookup.iter_rows(min_row=2, values_only=True):
        if row[1]:
            lookup_source_names.add(row[1])
    expected_src_names = {s['name'] for s in sources}
    missing = expected_src_names - lookup_source_names
    results.append(TestResult(
        2, "All sources present in Lookup_Definitions",
        len(missing) == 0,
        f"{len(expected_src_names)} sources: {sorted(expected_src_names)}",
        f"{len(lookup_source_names)} sources (missing: {sorted(missing)})" if missing else f"{len(lookup_source_names)} sources",
    ))

    # ---- TC-3: Source table names resolved with schema prefix ----
    lookup_tables = []
    for row in ws_lookup.iter_rows(min_row=2, values_only=True):
        if row[2]:
            lookup_tables.append(str(row[2]))
    unresolved = [t for t in lookup_tables if '$$' in t]
    no_schema = [t for t in lookup_tables if t and '.' not in t and '$$' not in t]
    results.append(TestResult(
        3, "Source tables resolved with schema prefix (no $$variables, has schema.table)",
        len(unresolved) == 0 and len(no_schema) == 0,
        "All tables as schema.table with no $$variables",
        f"Unresolved: {unresolved}, No schema: {no_schema}" if (unresolved or no_schema) else "All resolved correctly",
    ))

    # ---- TC-4: Target table name correct ----
    for tgt in targets:
        expected_tgt = get_target_table(tgt, params)
        # Check in Index tab
        ws_index = wb['Index']
        index_target_names = []
        for row in ws_index.iter_rows(min_row=2, values_only=True):
            if row[1]:
                index_target_names.append(str(row[1]))
        expected_table_only = expected_tgt.split('.')[-1] if '.' in expected_tgt else expected_tgt
        found = expected_table_only in index_target_names
        results.append(TestResult(
            4, f"Target table '{expected_table_only}' present in Index tab",
            found,
            expected_table_only,
            str(index_target_names),
        ))
        break  # test first target

    # ---- TC-5: All transformations present in Data_Flow ----
    ws_flow = wb['Data_Flow']
    flow_names = set()
    for row in ws_flow.iter_rows(min_row=3, values_only=True):  # Row 4+ are data rows
        if row and row[1]:
            flow_names.add(str(row[1]))
    expected_names = {t['name'] for t in transformations}
    missing_flow = expected_names - flow_names
    results.append(TestResult(
        5, "All transformations present in Data_Flow tab",
        len(missing_flow) == 0,
        f"{len(expected_names)} transformations",
        f"{len(flow_names)} found (missing: {sorted(missing_flow)})" if missing_flow else f"{len(flow_names)} found",
    ))

    # ---- TC-6: Transformation type accuracy in Data_Flow ----
    flow_type_map = {}
    for row in ws_flow.iter_rows(min_row=3, values_only=True):
        if row and row[1] and row[2]:
            flow_type_map[str(row[1])] = str(row[2]).upper()
    type_mismatches = []
    for name, expected_type in type_map.items():
        actual_type = flow_type_map.get(name, 'MISSING')
        if actual_type != expected_type and actual_type != 'MISSING':
            type_mismatches.append(f"{name}: expected={expected_type}, actual={actual_type}")
    results.append(TestResult(
        6, "Transformation types match in Data_Flow",
        len(type_mismatches) == 0,
        "All types match",
        f"{len(type_mismatches)} mismatches: {type_mismatches[:5]}",
    ))

    # ---- TC-7: Target field count matches in STTM tab ----
    for tgt in targets:
        expected_tgt_table = get_target_table(tgt, params)
        tgt_table_name = expected_tgt_table.split('.')[-1] if '.' in expected_tgt_table else expected_tgt_table
        sheet_name = tgt_table_name[:31]
        if sheet_name not in wb.sheetnames:
            results.append(TestResult(7, f"Target STTM tab '{sheet_name}' exists", False, sheet_name, "Not found"))
            break
        ws_sttm = wb[sheet_name]
        # Count unique target fields — row 7+ column C (Target Column Name)
        # Multiple rows per target field are expected (one per source table/column pair)
        unique_target_fields = set()
        for row in ws_sttm.iter_rows(min_row=7, values_only=True):
            if row and row[2] and str(row[2]).strip():
                unique_target_fields.add(str(row[2]).strip())
        sttm_field_count = len(unique_target_fields)
        expected_field_count = len(tgt.get('fields', []))
        results.append(TestResult(
            7, f"Target field count in STTM tab (expected={expected_field_count})",
            sttm_field_count == expected_field_count,
            expected_field_count,
            sttm_field_count,
        ))
        break

    # ---- TC-8: Join conditions captured (if joiners exist) ----
    joiners = [t for t in transformations if type_map[t['name']] == 'JOINER']
    if joiners:
        ws_txfm = wb['Transformation_Logic']
        txfm_text = ''
        for row in ws_txfm.iter_rows(min_row=2, values_only=True):
            if row and row[3]:
                txfm_text += str(row[3]) + '\n'
        all_jc_found = True
        missing_jc = []
        for j in joiners:
            for jc in j.get('joinConditions', []):
                left = jc.get('leftOperand', '')
                right = jc.get('rightOperand', '')
                if left and right:
                    if left not in txfm_text or right not in txfm_text:
                        all_jc_found = False
                        missing_jc.append(f"{left} = {right}")
        results.append(TestResult(
            8, "Join conditions captured in Transformation_Logic",
            all_jc_found,
            f"All join conditions present",
            f"Missing: {missing_jc}" if missing_jc else "All present",
        ))
    else:
        results.append(TestResult(8, "Join conditions (N/A — no joiners)", True, "N/A", "N/A"))

    # ---- TC-9: Summary tab — Ext Lake Flag accuracy ----
    ws_summary = wb['Summary']
    ext_lake_errors = []
    for row in ws_summary.iter_rows(min_row=2, values_only=True):
        if row and row[1] and row[5]:
            src_schema = str(row[1])
            flag = str(row[5])
            expected_flag = 'Y' if src_schema.startswith('ext_lake') else 'N'
            if flag != expected_flag:
                ext_lake_errors.append(f"{src_schema}: expected={expected_flag}, actual={flag}")
        if row and row[0] and not str(row[0]).isdigit():
            break  # reached Job Flow section
    results.append(TestResult(
        9, "Ext Lake Flag accuracy in Summary tab",
        len(ext_lake_errors) == 0,
        "All flags correct",
        f"Errors: {ext_lake_errors}" if ext_lake_errors else "All correct",
    ))

    # ---- TC-10: Computed expressions captured (not all 'Direct Move') ----
    # Check that expressions with actual logic are not marked as "Direct Move"
    has_expressions = False
    for t in transformations:
        ttype = type_map[t['name']]
        if ttype in ('EXPRESSION', 'AGGREGATOR'):
            for f in t.get('fields', []):
                expr = f.get('expression', '')
                if expr and expr.strip():
                    has_expressions = True
                    break
        if has_expressions:
            break

    if has_expressions:
        # Check STTM tab for at least some non-"Direct Move" entries in the expression column
        for tgt in targets:
            expected_tgt_table = get_target_table(tgt, params)
            tgt_table_name = expected_tgt_table.split('.')[-1] if '.' in expected_tgt_table else expected_tgt_table
            sheet_name = tgt_table_name[:31]
            if sheet_name not in wb.sheetnames:
                break
            ws_sttm = wb[sheet_name]
            non_direct = 0
            total_fields = 0
            for row in ws_sttm.iter_rows(min_row=7, values_only=True):
                if row and row[2] and str(row[2]).strip():
                    total_fields += 1
                    # Column index 9 = "Source Transformational Rule/Logic"
                    expr_val = str(row[9] or '')
                    if expr_val and 'Direct Move' not in expr_val and expr_val.strip():
                        non_direct += 1
            results.append(TestResult(
                10, "Computed expressions captured (not all 'Direct Move')",
                non_direct > 0,
                "At least 1 computed expression",
                f"{non_direct}/{total_fields} fields have expressions",
            ))
            break
    else:
        results.append(TestResult(10, "Computed expressions (N/A — passthrough only)", True, "N/A", "N/A"))

    return results


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main():
    pairs = discover_pairs()
    if not pairs:
        print("No .bin/.prm pairs found in inputs/")
        sys.exit(1)

    all_results = {}
    total_pass = 0
    total_fail = 0
    total_tests = 0

    print("=" * 70)
    print("STTM VALIDATION TEST SUITE")
    print("=" * 70)

    for bin_path, prm_paths in pairs:
        xlsx_name = f'{bin_path.stem}_sttm.xlsx'
        prm_names = ' + '.join(p.name for p in prm_paths)
        print(f"\n{'─' * 70}")
        print(f"STTM: {xlsx_name}")
        print(f"  Input: {bin_path.name} + {prm_names}")
        print(f"{'─' * 70}")

        results = run_tests_for_mapping(bin_path, prm_paths)
        all_results[xlsx_name] = results

        passed = sum(1 for r in results if r.passed)
        failed = sum(1 for r in results if not r.passed)
        total_pass += passed
        total_fail += failed
        total_tests += len(results)

        for r in results:
            print(r)
        print(f"\n  Result: {passed}/{len(results)} passed")

    # Summary
    print(f"\n{'=' * 70}")
    print("OVERALL SUMMARY")
    print(f"{'=' * 70}")
    print(f"  Total STTMs tested:  {len(all_results)}")
    print(f"  Total test cases:    {total_tests}")
    print(f"  Passed:              {total_pass}")
    print(f"  Failed:              {total_fail}")
    accuracy = (total_pass / total_tests * 100) if total_tests > 0 else 0
    print(f"  Accuracy:            {accuracy:.1f}%")

    print(f"\n{'─' * 70}")
    print("PER-STTM ACCURACY:")
    print(f"{'─' * 70}")
    for xlsx_name, results in all_results.items():
        passed = sum(1 for r in results if r.passed)
        pct = (passed / len(results) * 100) if results else 0
        status = "PASS" if passed == len(results) else "WARN"
        print(f"  [{status}] {xlsx_name}: {passed}/{len(results)} ({pct:.0f}%)")

    # Failure detail
    failures = [(xlsx, r) for xlsx, rl in all_results.items() for r in rl if not r.passed]
    if failures:
        print(f"\n{'─' * 70}")
        print("FAILURE DETAILS:")
        print(f"{'─' * 70}")
        for xlsx, r in failures:
            print(f"  {xlsx} > TC-{r.test_id}: {r.name}")
            print(f"    Expected: {r.expected}")
            print(f"    Actual:   {r.actual}")
            if r.detail:
                print(f"    Detail:   {r.detail}")

    print(f"\n{'=' * 70}")
    return 0 if total_fail == 0 else 1


if __name__ == '__main__':
    sys.exit(main())
