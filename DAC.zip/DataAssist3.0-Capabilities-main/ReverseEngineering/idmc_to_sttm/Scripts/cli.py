#!/usr/bin/env python3
"""
STTM Generator CLI — Single entry point for all STTM generation,
validation, and refinement commands.

Usage:
    python scripts/sttm-generator/cli.py generate
    python scripts/sttm-generator/cli.py generate --input-dir /path/to/inputs --output-dir /path/to/output
    python scripts/sttm-generator/cli.py validate
    python scripts/sttm-generator/cli.py validate --input-dir inputs --output-dir output
    python scripts/sttm-generator/cli.py agentic-validate
    python scripts/sttm-generator/cli.py agentic-validate --output-file output/some_sttm.xlsx --dry-run
    python scripts/sttm-generator/cli.py refine
    python scripts/sttm-generator/cli.py refine --report path/to/report.yaml --feedback feedback.txt --max-iterations 5
    python scripts/sttm-generator/cli.py run-all
"""

import argparse
import sys
from pathlib import Path

SCRIPTS_DIR = Path(__file__).resolve().parent
PROJECT_ROOT = SCRIPTS_DIR.parent.parent
sys.path.insert(0, str(SCRIPTS_DIR))


def cmd_generate(args):
    """Generate STTM workbooks from IDMC .bin and .prm/.param files."""
    input_dir = Path(args.input_dir)
    output_dir = Path(args.output_dir)
    if not input_dir.is_absolute():
        input_dir = PROJECT_ROOT / input_dir
    if not output_dir.is_absolute():
        output_dir = PROJECT_ROOT / output_dir

    from generate_sttm import main as gen_main
    sys.argv = ['generate_sttm', '--input-dir', str(input_dir), '--output-dir', str(output_dir)]
    gen_main()


def cmd_validate(args):
    """Run the 10-test validation suite against generated STTM workbooks."""
    input_dir = Path(args.input_dir)
    output_dir = Path(args.output_dir)
    if not input_dir.is_absolute():
        input_dir = PROJECT_ROOT / input_dir
    if not output_dir.is_absolute():
        output_dir = PROJECT_ROOT / output_dir

    from test_sttm_validation import main as val_main
    sys.argv = ['test_sttm_validation', '--input-dir', str(input_dir), '--output-dir', str(output_dir)]
    return val_main()


def cmd_agentic_validate(args):
    """Run agentic validator producing a structured YAML report."""
    argv = ['validator']
    if args.output_file:
        argv += ['--output-file', args.output_file]
    if args.dry_run:
        argv.append('--dry-run')

    from validator import main as av_main
    sys.argv = argv
    return av_main()


def cmd_refine(args):
    """Run agentic refiner to patch output based on validation report."""
    argv = ['refiner']
    if args.report:
        argv += ['--report', args.report]
    if args.feedback:
        argv += ['--feedback', args.feedback]
    argv += ['--max-iterations', str(args.max_iterations)]

    from refiner import main as ref_main
    sys.argv = argv
    return ref_main()


def cmd_run_all(args):
    """Generate STTMs, then validate, then run agentic validation."""
    print("=== Step 1/3: Generating STTM workbooks ===")
    cmd_generate(args)
    print("\n=== Step 2/3: Running test suite validation ===")
    rc = cmd_validate(args)
    print("\n=== Step 3/3: Running agentic validation ===")
    args.output_file = None
    args.dry_run = False
    cmd_agentic_validate(args)
    return rc


def main():
    parser = argparse.ArgumentParser(
        description='STTM Generator CLI — Generate, validate, and refine IDMC-to-STTM workbooks',
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    subparsers = parser.add_subparsers(dest='command', help='Available commands')

    # generate
    gen_parser = subparsers.add_parser('generate', help='Generate STTM workbooks from .bin/.prm files')
    gen_parser.add_argument('--input-dir', default='inputs',
                            help='Directory containing .bin and .prm/.param files (default: inputs)')
    gen_parser.add_argument('--output-dir', default='output',
                            help='Directory for generated .xlsx files (default: output)')

    # validate
    val_parser = subparsers.add_parser('validate', help='Run 10-test validation suite')
    val_parser.add_argument('--input-dir', default='inputs',
                            help='Directory containing .bin and .prm/.param files (default: inputs)')
    val_parser.add_argument('--output-dir', default='output',
                            help='Directory containing generated .xlsx files (default: output)')

    # agentic-validate
    av_parser = subparsers.add_parser('agentic-validate', help='Run agentic validator (YAML report)')
    av_parser.add_argument('--output-file', default=None,
                           help='Validate a specific output file only')
    av_parser.add_argument('--dry-run', action='store_true',
                           help='List checks without running')

    # refine
    ref_parser = subparsers.add_parser('refine', help='Run agentic refiner to patch output')
    ref_parser.add_argument('--report', default=None,
                            help='Path to validation report YAML')
    ref_parser.add_argument('--feedback', default=None,
                            help='Path to human feedback text file')
    ref_parser.add_argument('--max-iterations', type=int, default=3,
                            help='Maximum refinement iterations (default: 3)')

    # run-all
    all_parser = subparsers.add_parser('run-all', help='Generate + validate + agentic-validate')
    all_parser.add_argument('--input-dir', default='inputs',
                            help='Directory containing .bin and .prm/.param files (default: inputs)')
    all_parser.add_argument('--output-dir', default='output',
                            help='Directory for generated .xlsx files (default: output)')

    args = parser.parse_args()

    if args.command is None:
        parser.print_help()
        return 1

    commands = {
        'generate': cmd_generate,
        'validate': cmd_validate,
        'agentic-validate': cmd_agentic_validate,
        'refine': cmd_refine,
        'run-all': cmd_run_all,
    }

    rc = commands[args.command](args)
    return rc if rc else 0


if __name__ == '__main__':
    sys.exit(main())
