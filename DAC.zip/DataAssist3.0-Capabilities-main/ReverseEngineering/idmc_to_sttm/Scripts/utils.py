"""
Shared utility functions for toolkit scripts.

Provides YAML I/O, path helpers, and logging setup used across
parsers, generators, and validators.
"""

import logging
import sys
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, Optional

import yaml


def load_yaml(file_path: Path) -> Dict[str, Any]:
    """Load and parse a YAML file. Returns empty dict if file not found."""
    path = Path(file_path)
    if not path.exists():
        logging.warning(f"YAML file not found: {path}")
        return {}
    with open(path, 'r', encoding='utf-8') as f:
        data = yaml.safe_load(f)
    return data if data is not None else {}


def save_yaml(data: Dict[str, Any], file_path: Path) -> Path:
    """Save data as YAML to the given path. Creates parent directories."""
    path = Path(file_path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, 'w', encoding='utf-8') as f:
        yaml.dump(data, f, default_flow_style=False, sort_keys=False)
    return path


def load_all_yaml(directory: Path) -> Dict[str, Dict]:
    """Load all YAML files in a directory. Returns dict keyed by filename stem."""
    results = {}
    dir_path = Path(directory)
    if not dir_path.exists():
        logging.warning(f"Directory not found: {dir_path}")
        return results
    for yaml_file in sorted(dir_path.glob('*.yaml')):
        results[yaml_file.stem] = load_yaml(yaml_file)
    for yml_file in sorted(dir_path.glob('*.yml')):
        results[yml_file.stem] = load_yaml(yml_file)
    return results


def get_project_root() -> Path:
    """Get the project root directory (parent of scripts/)."""
    return Path(__file__).resolve().parent.parent.parent


def get_timestamp() -> str:
    """Get current timestamp as formatted string."""
    return datetime.now().strftime('%Y-%m-%d %H:%M:%S')


def setup_logging(
    name: str,
    log_dir: Optional[Path] = None,
    level: int = logging.INFO
) -> logging.Logger:
    """Set up a logger that writes to console and optionally to a file."""
    logger = logging.getLogger(name)
    logger.setLevel(level)

    # Console handler
    console = logging.StreamHandler(sys.stdout)
    console.setLevel(level)
    console.setFormatter(logging.Formatter(
        '%(asctime)s | %(name)s | %(levelname)s | %(message)s',
        datefmt='%Y-%m-%d %H:%M:%S'
    ))
    logger.addHandler(console)

    # File handler (optional)
    if log_dir:
        log_path = Path(log_dir)
        log_path.mkdir(parents=True, exist_ok=True)
        file_handler = logging.FileHandler(
            log_path / f'{name}_{datetime.now().strftime("%Y%m%d")}.log',
            encoding='utf-8'
        )
        file_handler.setLevel(level)
        file_handler.setFormatter(logging.Formatter(
            '%(asctime)s | %(name)s | %(levelname)s | %(message)s',
            datefmt='%Y-%m-%d %H:%M:%S'
        ))
        logger.addHandler(file_handler)

    return logger
