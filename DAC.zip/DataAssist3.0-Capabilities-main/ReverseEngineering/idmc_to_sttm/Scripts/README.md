# STTM Generator

Reverse-engineers Informatica Data Management Cloud (IDMC) mapping exports into Source-to-Target Mapping (STTM) Excel workbooks. Parses `.bin` (JSON) mapping files and `.prm`/`.param` parameter files, then produces fully documented STTM `.xlsx` deliverables with field-level lineage, transformation logic, and data flow diagrams.

## Problem It Solves

IDMC exports mapping definitions as raw JSON `.bin` files with no business-readable documentation. This tool automates the creation of structured STTM workbooks that data engineers and analysts can use to understand source-to-target data flows, transformation logic, and lineage without needing access to IDMC itself.

## Features

- **STTM Generation**: Produces Excel workbooks with Index, Version History, Summary, per-target STTM tabs, Lookup Definitions, Transformation Logic, and Data Flow tabs
- **Multi-row source lineage**: Each target field expands to N rows (one per source table + column pair)
- **Expression-to-SQL conversion**: IDMC functions mapped to SQL equivalents (DECODE to CASE WHEN, INSTR to POSITION, etc.)
- **LOOKUP detection**: Distinguishes LOOKUP transformations from SOURCEs by naming convention and upstream connections
- **Parameter resolution**: Resolves `$$variable` references from `.prm`/`.param` files
- **10-test validation suite**: Automated quality checks per workbook
- **Agentic validator**: Structured YAML validation reports with categorized issues
- **Agentic refiner**: Rule-based patching of output files with regression detection

## Setup

### Prerequisites

- Python 3.8 or higher

### Installation

```bash
# Install dependencies
pip install -r scripts/sttm-generator/requirements.txt
```

### Input Files

Place your IDMC export files in the `inputs/` directory at the project root:

- `.bin` files: IDMC mapping exports (JSON format)
- `.prm` / `.param` files: Parameter files with connection and schema variables

#### Input Pairing Rules

| .bin pattern   | Parameter file(s)                                  |
|---------------|---------------------------------------------------|
| `gmad_*.bin`  | `finance_GMAD_master.prm`                         |
| `pdds_*.bin`  | `finance_PDDS_master.prm`                         |
| `ivr_*.bin`   | `EDM_CSX.param` + `EDM_CSX_IvrCallLogs.param`    |
| All others    | `EDM_CSX.param` (fallback)                        |

## How to Run

All commands are accessed through `cli.py`:

```bash
# Generate STTM workbooks from inputs/
python scripts/sttm-generator/cli.py generate

# Generate with custom directories
python scripts/sttm-generator/cli.py generate --input-dir /path/to/inputs --output-dir /path/to/output

# Run 10-test validation suite
python scripts/sttm-generator/cli.py validate

# Run agentic validator (produces YAML report)
python scripts/sttm-generator/cli.py agentic-validate

# Run agentic validator on a specific file
python scripts/sttm-generator/cli.py agentic-validate --output-file output/some_sttm.xlsx

# Dry run (list checks without executing)
python scripts/sttm-generator/cli.py agentic-validate --dry-run

# Run agentic refiner (patches output based on validation report)
python scripts/sttm-generator/cli.py refine

# Refine with human feedback
python scripts/sttm-generator/cli.py refine --feedback feedback.txt --max-iterations 5

# Full pipeline: generate + validate + agentic-validate
python scripts/sttm-generator/cli.py run-all
```

## Output

Each `.bin` file produces one STTM `.xlsx` workbook in the `output/` directory with tabs:

1. **Index** - Target table inventory
2. **Version History** - Change tracking
3. **Summary** - Source/target overview with merged job flow diagram
4. **Target STTM tabs** - Field-level mappings with multi-step transformation logic
5. **Lookup_Definitions** - Source and lookup SQL queries
6. **Transformation_Logic** - All transformation blocks documented
7. **Data_Flow** - End-to-end pipeline view, color-coded by transformation type

## Scripts Overview

| File                       | Purpose                                              |
|---------------------------|------------------------------------------------------|
| `cli.py`                  | Unified CLI entry point (this file)                  |
| `generate_sttm.py`       | Core STTM generator                                 |
| `test_sttm_validation.py`| 10-test validation suite                             |
| `validator.py`            | Agentic validator (structured YAML reports)          |
| `refiner.py`              | Agentic refiner (patches output files)               |
| `prompts.py`              | Centralized prompts for agentic layer                |
| `base_validator.py`       | Base class for validators                            |
| `base_generator.py`       | Base class for generators                            |
| `base_parser.py`          | Base class for input parsers                         |
| `utils.py`                | Shared utilities (logging, YAML I/O, path helpers)   |

## Assumptions and Limitations

- Input `.bin` files must be valid JSON exports from IDMC
- Parameter resolution depends on correctly paired `.prm`/`.param` files; unmatched variables will appear as `$$variable` in output
- Schema qualification relies on parameter keys like `$$cfsib_schema`, `$$jpSchemaName`, etc. being present in the parameter files
- The refiner can only patch certain issue categories (e.g., source column prefixes); structural issues like multi-row lineage require regeneration
- The tool does not connect to IDMC or any database; it works entirely from exported files

## Environment Requirements

- Python >= 3.8
- `openpyxl >= 3.1.0` (Excel workbook generation)
- `pyyaml >= 6.0` (YAML report I/O for agentic layer)
