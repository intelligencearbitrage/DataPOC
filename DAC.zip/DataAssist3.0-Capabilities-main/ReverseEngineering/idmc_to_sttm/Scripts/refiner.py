#!/usr/bin/env python3
"""
STTM Refiner — Agentic layer that patches output/ STTM workbooks based on
validation reports and optional human feedback.

Only writes to output/ — never modifies scripts/, inputs/, or knowledgebase/.

Usage:
    python scripts/refiner.py
    python scripts/refiner.py --report thoughts/logs/agentic/validation_report.yaml
    python scripts/refiner.py --feedback feedback.txt
    python scripts/refiner.py --max-iterations 5
"""

import argparse
import re
import sys
from pathlib import Path
from typing import Any, Dict, List, Optional

import openpyxl

# Ensure scripts/ is importable
SCRIPTS_DIR = Path(__file__).resolve().parent
PROJECT_ROOT = SCRIPTS_DIR.parent.parent
sys.path.insert(0, str(SCRIPTS_DIR))

from utils import setup_logging, load_yaml, save_yaml, get_timestamp

from prompts import (  # noqa: F401
    REFINER_SYSTEM_PROMPT,
    REFINER_PATCH_PROMPT,
    FEEDBACK_VALIDATION_PROMPT,
)

OUTPUT_DIR = PROJECT_ROOT / 'output'
LOG_DIR = PROJECT_ROOT / 'thoughts' / 'logs' / 'agentic'


def _safe_resolve_path(user_path: str) -> Path:
    """Resolve a user-supplied path, anchored to project root, rejecting traversal."""
    if not user_path:
        raise ValueError("Empty path")
    safe = re.sub(r'[^\w.\-/\\ ]', '', user_path)
    if safe != user_path:
        raise ValueError(f"Path contains disallowed characters: {user_path!r}")
    if '..' in safe.replace('\\', '/').split('/'):
        raise ValueError(f"Path traversal blocked: {user_path!r}")
    candidate = (PROJECT_ROOT / safe).resolve()
    if not candidate.is_relative_to(PROJECT_ROOT.resolve()):
        raise ValueError(
            f"Path '{user_path}' resolves outside the project root. "
            f"All paths must be within {PROJECT_ROOT}"
        )
    return candidate

# IDMC prefixes to strip from source column names
IDMC_PREFIXES = ('o_', 'exp_', 'e_', 'ch_', 'of_', 'change_')

# Max line changes per patch (guardrail)
MAX_PATCH_LINES = 50


def _find_latest_report() -> Optional[Path]:
    """Find the most recent validation report in the agentic log dir."""
    if not LOG_DIR.exists():
        return None
    reports = sorted(LOG_DIR.glob('validation_report_*.yaml'), reverse=True)
    return reports[0] if reports else None


def _load_report(report_path: Path) -> Dict[str, Any]:
    """Load a validation report YAML."""
    resolved = report_path.resolve()
    if not resolved.is_relative_to(PROJECT_ROOT.resolve()):
        raise ValueError(
            f"Report path '{report_path}' resolves outside the project root. "
            f"All paths must be within {PROJECT_ROOT}"
        )
    return load_yaml(resolved)


def _validate_feedback(feedback_text: str) -> bool:
    """Basic feedback validation — check it's non-empty and actionable."""
    if not feedback_text or not feedback_text.strip():
        return False
    # Reject feedback that tries to modify scripts or inputs
    forbidden = ['scripts/', 'inputs/', 'knowledgebase/', 'rm ', 'delete ']
    for term in forbidden:
        if term in feedback_text.lower():
            return False
    return True


# ---------------------------------------------------------------------------
# Patch functions — rule-based fixes for known issue categories
# ---------------------------------------------------------------------------

def fix_source_col_prefixes(xlsx_path: Path, logger) -> int:
    """Strip IDMC prefixes from Source Column Name cells."""
    wb = openpyxl.load_workbook(str(xlsx_path))
    skip_tabs = {'Index', 'Version History', 'Summary',
                 'Lookup_Definitions', 'Transformation_Logic', 'Data_Flow'}
    fix_count = 0

    for sn in wb.sheetnames:
        if sn in skip_tabs:
            continue
        ws = wb[sn]
        for row in range(7, ws.max_row + 1):
            field = ws.cell(row, 3).value
            src_col = ws.cell(row, 8).value or ''
            if not field or not src_col:
                continue

            # Iteratively strip prefixes
            remaining = src_col
            candidates = [remaining]
            while True:
                stripped = False
                for prefix in IDMC_PREFIXES:
                    if remaining.lower().startswith(prefix):
                        remaining = remaining[len(prefix):]
                        candidates.append(remaining)
                        stripped = True
                        break
                if not stripped:
                    break

            # Pick best candidate (target field name match preferred)
            best = src_col
            for candidate in reversed(candidates):
                if candidate and candidate.lower() == field.lower():
                    best = candidate
                    break

            if best != src_col:
                ws.cell(row, 8).value = best
                fix_count += 1
                logger.info(f'  Fixed {sn}/{field}: {src_col} → {best}')

    if fix_count > 0:
        wb.save(str(xlsx_path))
        logger.info(f'  Saved {xlsx_path.name} with {fix_count} source column fixes')
    return fix_count


# ---------------------------------------------------------------------------
# Refiner loop
# ---------------------------------------------------------------------------

class STTMRefiner:
    """Patches STTM output files based on validation issues."""

    def __init__(self, max_iterations: int = 3):
        self.max_iterations = max_iterations
        self.logger = setup_logging('refiner', log_dir=LOG_DIR)

    def run(self, report_path: Optional[Path] = None,
            feedback_path: Optional[Path] = None) -> Dict[str, Any]:
        """Run the refinement loop."""
        # Load validation report
        if report_path is None:
            report_path = _find_latest_report()
        if report_path is None or not report_path.exists():
            self.logger.warning('No validation report found. Run validator.py first.')
            return {'status': 'no_report', 'iterations': 0}

        report = _load_report(report_path)
        issues = report.get('validation_report', {}).get('issues', [])

        # Load human feedback if provided
        feedback: Optional[str] = None
        if feedback_path and feedback_path.exists():
            feedback = feedback_path.read_text(encoding='utf-8')
            if not _validate_feedback(feedback):
                self.logger.warning('Feedback rejected — invalid or out of scope.')
                feedback = None
            else:
                self.logger.info(f'Loaded feedback from {feedback_path}')

        if not issues and not feedback:
            self.logger.info('No issues to fix and no feedback. Nothing to refine.')
            return {'status': 'clean', 'iterations': 0}

        iteration_log: List[Dict] = []
        prev_error_count = len([i for i in issues if i['severity'] == 'ERROR'])

        for iteration in range(1, self.max_iterations + 1):
            self.logger.info(f'\n--- Refinement iteration {iteration}/{self.max_iterations} ---')
            fixes_applied = 0

            # Fix known issue categories
            for issue in issues:
                if issue['severity'] not in ('ERROR', 'WARNING'):
                    continue
                category = issue.get('category', '')
                output_file = issue.get('output_file', '')
                xlsx_path = OUTPUT_DIR / output_file if output_file else None

                if not xlsx_path or not xlsx_path.exists():
                    continue

                if category == 'source_column_name':
                    fixes_applied += fix_source_col_prefixes(xlsx_path, self.logger)
                elif category in ('multi_row_lineage', 'column_to_table'):
                    # These require regeneration — cannot be patched in output.
                    # Log and skip; user should re-run generate_sttm.py.
                    self.logger.info(
                        f'  [{category}] {output_file}: requires regeneration, '
                        f'not patchable. Re-run generate_sttm.py.'
                    )

            iteration_log.append({
                'iteration': iteration,
                'fixes_applied': fixes_applied,
                'timestamp': get_timestamp(),
            })

            if fixes_applied == 0:
                self.logger.info('No fixes applied — stopping refinement loop.')
                break

            # Re-validate
            self.logger.info('Re-running validation...')
            from validator import STTMValidator
            validator = STTMValidator()
            issues = validator.validate()
            error_count = len([i for i in issues if i['severity'] == 'ERROR'])

            # Check for regression
            if error_count > prev_error_count:
                self.logger.warning(
                    f'Accuracy regression: {error_count} errors (was {prev_error_count}). Stopping.'
                )
                break
            prev_error_count = error_count

            if error_count == 0:
                self.logger.info('All errors resolved!')
                break

        # Save iteration log
        summary = {
            'refiner_log': {
                'timestamp': get_timestamp(),
                'iterations': len(iteration_log),
                'iteration_details': iteration_log,
                'final_error_count': prev_error_count,
            }
        }
        log_path = LOG_DIR / f'refiner_log_{get_timestamp().replace(" ", "_").replace(":", "")}.yaml'
        save_yaml(summary, log_path)
        self.logger.info(f'Refiner log saved: {log_path}')

        return summary


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def main():
    parser = argparse.ArgumentParser(description='STTM Refiner (Agentic Layer)')
    parser.add_argument('--report', help='Path to validation report YAML')
    parser.add_argument('--feedback', help='Path to human feedback text file')
    parser.add_argument('--max-iterations', type=int, default=3,
                        help='Maximum refinement iterations (default: 3)')
    args = parser.parse_args()

    report_path = _safe_resolve_path(args.report) if args.report else None
    feedback_path = _safe_resolve_path(args.feedback) if args.feedback else None

    refiner = STTMRefiner(max_iterations=args.max_iterations)
    result = refiner.run(report_path=report_path, feedback_path=feedback_path)

    status = result.get('status', 'unknown')
    iterations = result.get('refiner_log', {}).get('iterations', 0) if 'refiner_log' in result else result.get('iterations', 0)

    print(f"\n{'=' * 60}")
    print("REFINER SUMMARY")
    print(f"{'=' * 60}")
    print(f"  Status:     {status if status else 'completed'}")
    print(f"  Iterations: {iterations}")
    print(f"{'=' * 60}")

    return 0


if __name__ == '__main__':
    sys.exit(main())
