"""
IDMC to STTM Generator - Parses IDMC .bin mapping files and .prm parameter files,
then generates Source-to-Target Mapping (STTM) Excel documents.

Each .bin file in inputs/ is paired with its .prm file and produces one STTM .xlsx in output/.

Usage:
    python scripts/generate_sttm.py
"""

import json
import re
import sys
from pathlib import Path
from collections import OrderedDict
from datetime import datetime

import openpyxl
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side

SCRIPTS_DIR = Path(__file__).resolve().parent
PROJECT_ROOT = SCRIPTS_DIR.parent.parent
sys.path.insert(0, str(SCRIPTS_DIR))

from base_generator import BaseGenerator
from utils import setup_logging


# ---------------------------------------------------------------------------
# IDMC Expression to SQL converter
# ---------------------------------------------------------------------------

def idmc_expr_to_sql(expr):
    """Convert an IDMC expression to approximate SQL equivalent."""
    if not expr:
        return ''
    sql = expr

    # IIF -> CASE WHEN
    def replace_iif(match):
        inner = match.group(1)
        depth = 0
        parts = []
        current = []
        for ch in inner:
            if ch == '(':
                depth += 1
                current.append(ch)
            elif ch == ')':
                depth -= 1
                current.append(ch)
            elif ch == ',' and depth == 0:
                parts.append(''.join(current).strip())
                current = []
            else:
                current.append(ch)
        parts.append(''.join(current).strip())
        if len(parts) == 3:
            return f"CASE WHEN {parts[0]} THEN {parts[1]} ELSE {parts[2]} END"
        return match.group(0)

    # Simple function replacements
    replacements = [
        (r'\bTO_BIGINT\s*\(', 'CAST('),
        (r'\bTO_INTEGER\s*\(', 'CAST('),
        (r'\bTO_CHAR\s*\(', 'CAST('),
        (r'\bTO_DATE\s*\(', 'TO_DATE('),
        (r'\bTO_DECIMAL\s*\(', 'CAST('),
        (r'\bTO_FLOAT\s*\(', 'CAST('),
        (r'\bSUBSTR\s*\(', 'SUBSTRING('),
        (r'\bLTRIM\s*\(', 'LTRIM('),
        (r'\bRTRIM\s*\(', 'RTRIM('),
        (r'\bINSTR\s*\(', 'POSITION('),
        (r'\bSYSDATE\b', 'CURRENT_TIMESTAMP'),
        (r'\bSESSIONSTARTTIME\b', 'CURRENT_TIMESTAMP'),
        (r'\bSetMaxVariable\s*\([^)]*\)', 'CURRENT_TIMESTAMP'),
        (r'\bLENGTH\s*\(', 'LEN('),
        (r'\bCONCAT\s*\(', 'CONCAT('),
        (r'\bLOWER\s*\(', 'LOWER('),
        (r'\bUPPER\s*\(', 'UPPER('),
        (r'\bREPLACESTR\s*\(', 'REPLACE('),
        (r'\bREPLACECHR\s*\(', 'REPLACE('),
        (r'\bREG_EXTRACT\s*\(', 'REGEXP_SUBSTR('),
        (r'\bIS_DATE\s*\(', 'TRY_TO_DATE('),
        (r'\bIS_NUMBER\s*\(', 'TRY_TO_NUMBER('),
        (r'\bADD_TO_DATE\s*\(', 'DATEADD('),
        (r'\bDATE_DIFF\s*\(', 'DATEDIFF('),
        (r'\bGET_DATE_PART\s*\(', 'DATE_PART('),
        (r'\bTRUNC\s*\(', 'TRUNC('),
        (r'\bROUND\s*\(', 'ROUND('),
        (r'\bABS\s*\(', 'ABS('),
        (r'\bMOD\s*\(', 'MOD('),
        (r'\bPOWER\s*\(', 'POWER('),
        (r'\bLOOKUP\s*\(', 'LOOKUP('),
        (r'\bFIRST\s*\(', 'FIRST_VALUE('),
        (r'\bLAST\s*\(', 'LAST_VALUE('),
    ]
    for pattern, replacement in replacements:
        sql = re.sub(pattern, replacement, sql, flags=re.IGNORECASE)

    # DECODE -> CASE
    decode_pattern = r'\bDECODE\s*\(TRUE\s*,'
    if re.search(decode_pattern, sql, re.IGNORECASE):
        sql = re.sub(decode_pattern, 'CASE ', sql, flags=re.IGNORECASE)
        sql = sql.replace(')', ' END', 1) if sql.count(')') > 0 else sql

    # IIF replacements (iterative for nested)
    for _ in range(10):
        new_sql = re.sub(r'\bIIF\s*\((.+)\)', replace_iif, sql, count=1, flags=re.IGNORECASE)
        if new_sql == sql:
            break
        sql = new_sql

    return sql


# ---------------------------------------------------------------------------
# PRM Parser
# ---------------------------------------------------------------------------

def parse_prm(prm_path):
    """Parse a .prm parameter file into a dict of resolved variables."""
    params = {}
    current_section = 'Global'
    with open(prm_path, 'r', encoding='utf-8') as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith('#'):
                continue
            if line.startswith('['):
                bracket_end = line.rfind(']')
                if bracket_end > 0:
                    current_section = line[:bracket_end + 1]
                continue
            if '=' in line:
                key, value = line.split('=', 1)
                key = key.strip()
                value = value.strip()
                if current_section == 'Global' or current_section == '[Global]':
                    params[key] = value
                else:
                    params[f'{current_section}.{key}'] = value
    return params


def resolve_text(text, params):
    """Resolve $$variable references in text using params dict."""
    if not text:
        return text
    result = text
    for key, value in sorted(params.items(), key=lambda x: -len(x[0])):
        if key.startswith('$$'):
            result = result.replace(key, value)
    return result


# ---------------------------------------------------------------------------
# IDMC Mapping Parser
# ---------------------------------------------------------------------------

class IDMCMapping:
    """Parses and represents a single IDMC mapping from a .bin file."""

    def __init__(self, bin_path, prm_paths):
        self.bin_path = Path(bin_path)
        # Support single path or list of paths
        if isinstance(prm_paths, (str, Path)):
            prm_paths = [prm_paths]
        self.prm_paths = [Path(p) for p in prm_paths]
        # Merge params from all files (later files override earlier ones)
        self.params = {}
        for pp in self.prm_paths:
            self.params.update(parse_prm(pp))
        self.content = None
        self.transformations = []
        self.links = []
        self.id_map = {}
        self.field_id_map = {}
        self.graph = {}
        self.reverse_graph = {}
        self._parse()

    def _parse(self):
        with open(self.bin_path, 'r', encoding='utf-8') as f:
            data = json.load(f)
        self.content = data['content']
        self.transformations = self.content.get('transformations', [])
        self.links = self.content.get('links', [])

        for t in self.transformations:
            tid = t.get('$$ID')
            self.id_map[tid] = t
            for fld in t.get('fields', []):
                fid = fld.get('$$ID')
                if fid is not None:
                    self.field_id_map[fid] = (t, fld)

        for link in self.links:
            from_id = link['fromTransformation']['##ID']
            to_id = link['toTransformation']['##ID']
            from_t = self.id_map.get(from_id)
            to_t = self.id_map.get(to_id)
            if from_t and to_t:
                fn = from_t['name']
                tn = to_t['name']
                self.graph.setdefault(fn, []).append(tn)
                self.reverse_graph.setdefault(tn, []).append(fn)

    @property
    def name(self):
        return self.content.get('name', '')

    @property
    def description(self):
        for ann in self.content.get('annotations', []):
            body = ann.get('body', '')
            if body and body.strip():
                return body.strip()
        return ''

    @property
    def mapping_parameters(self):
        return self.content.get('parameters', [])

    def resolve(self, text):
        return resolve_text(text, self.params)

    # -- Type identification (structural, not by $$class number) --

    def identify_type(self, t):
        if 'dataAdapter' in t:
            da = t['dataAdapter']
            obj = da.get('object', {})
            cq = (obj.get('customQuery') or '').strip()
            on = (obj.get('objectName') or '').strip()
            if 'fieldMappingMode' in t:
                return 'TARGET'
            name_lower = t.get('name', '').lower()
            if cq:
                # Lookups have customQuery + dataAdapter but also have upstream connections.
                # True SOURCEs have no upstream. Also detect by naming convention.
                if (name_lower.startswith(('lkp_', 'lookup')) and
                        not name_lower.startswith(('src_', 'source'))):
                    return 'LOOKUP'
                # Check if it has upstream connections (Lookups do, SOURCEs don't)
                if self.reverse_graph.get(t.get('name', '')) and not name_lower.startswith(('src_', 'source')):
                    return 'LOOKUP'
                return 'SOURCE'
            if on and not cq:
                return 'TARGET'
            if name_lower.startswith(('src_', 'source')):
                return 'SOURCE'
            if name_lower.startswith(('tgt_', 'target')):
                return 'TARGET'
        if 'joinConditions' in t:
            return 'JOINER'
        if 'inputGroups' in t:
            return 'UNION'
        if 'groupFilterConditions' in t:
            return 'ROUTER'
        if 'sortEntries' in t:
            return 'SORTER'
        if 'filterConditions' in t:
            return 'FILTER'
        name_lower = t.get('name', '').lower()
        if name_lower.startswith(('agg_',)):
            return 'AGGREGATOR'
        fields = t.get('fields', [])
        has_agg = any(
            f.get('expression', '') and
            re.search(r'\b(SUM|COUNT|AVG|MAX|MIN|FIRST|LAST)\s*\(', f.get('expression', ''), re.IGNORECASE)
            for f in fields
        )
        if has_agg:
            return 'AGGREGATOR'
        if 'state' in t and 'incrementBy' in t.get('state', {}):
            return 'SEQUENCE'
        return 'EXPRESSION'

    def get_transformations_by_type(self, ttype):
        return [t for t in self.transformations if self.identify_type(t) == ttype]

    def get_sources(self):
        return self.get_transformations_by_type('SOURCE')

    def get_targets(self):
        return self.get_transformations_by_type('TARGET')

    # -- Connection / table resolution --

    def get_connection_info(self, t):
        if 'dataAdapter' not in t:
            return {}
        da = t['dataAdapter']
        conn_ref_obj = da.get('connectionId$', da.get('connectionId', ''))
        if isinstance(conn_ref_obj, dict):
            # Reference by ##ID — match against $$ID in parameters
            ref_id = conn_ref_obj.get('##ID')
            for p in self.mapping_parameters:
                if p.get('$$ID') == ref_id:
                    param_name = p.get('name', '')
                    conn_type = p.get('anonymousType', {}).get('connectionType', '')
                    resolved = self.params.get(f'$${param_name}', param_name)
                    return {'parameter': param_name, 'connectionType': conn_type, 'resolved': resolved}
            return {'parameter': str(ref_id), 'connectionType': '', 'resolved': ''}
        conn_name = conn_ref_obj if isinstance(conn_ref_obj, str) else ''
        for p in self.mapping_parameters:
            param_name = p.get('name', '')
            if param_name == conn_name or f'$${param_name}' == conn_name:
                conn_type = p.get('anonymousType', {}).get('connectionType', '')
                resolved = self.params.get(f'$${param_name}', param_name)
                return {'parameter': param_name, 'connectionType': conn_type, 'resolved': resolved}
        return {'parameter': conn_name, 'connectionType': '', 'resolved': conn_name}

    def get_source_tables(self, t):
        """Extract resolved source table(s) from a SOURCE transformation's customQuery."""
        if 'dataAdapter' not in t:
            return []
        da = t['dataAdapter']
        obj = da.get('object', {})
        query = obj.get('customQuery', '')
        if not query:
            return []
        resolved = self.resolve(query)
        tables = re.findall(r'\bFROM\s+(\S+?)(?:\s|$|;|\))', resolved, re.IGNORECASE)
        join_tables = re.findall(r'\bJOIN\s+(\S+?)(?:\s|$|;|\))', resolved, re.IGNORECASE)
        all_tables = tables + join_tables
        # Filter out subquery aliases and keywords
        cleaned = []
        for tbl in all_tables:
            tbl = tbl.strip('(').strip(')').strip(',')
            if tbl.upper() in ('SELECT', 'WHERE', 'GROUP', 'ORDER', 'HAVING', 'UNION', 'LIMIT', '('):
                continue
            if tbl:
                cleaned.append(tbl)
        return cleaned

    def get_primary_source_table(self, t):
        """Get the main source table (first FROM clause)."""
        tables = self.get_source_tables(t)
        return tables[0] if tables else t.get('name', '')

    def get_source_column_table_map(self, t):
        """Parse a SOURCE transformation's customQuery to map output columns to their tables.

        Returns dict: {output_col_lower: (table_name, raw_col_name)}
        For columns with explicit alias.column references, maps to the correct table.
        Resolves subquery aliases to their primary inner table.
        """
        if 'dataAdapter' not in t:
            return {}
        da = t['dataAdapter']
        obj = da.get('object', {})
        query = obj.get('customQuery', '')
        if not query:
            return {}
        resolved = self.resolve(query)

        # Step 1: Build alias -> table mapping from FROM/JOIN clauses
        alias_map = {}  # alias_lower -> resolved_table_name

        # First pass: find direct table references (schema.TABLE ALIAS)
        for m in re.finditer(r'\b(?:FROM|(?:INNER|LEFT|RIGHT|FULL|CROSS)\s+(?:OUTER\s+)?JOIN|JOIN)\s+(\S+?)[\s,]+(\w+)\s', resolved, re.IGNORECASE):
            tbl = m.group(1).strip('(').strip(')')
            alias = m.group(2)
            if alias.upper() in ('ON', 'WHERE', 'GROUP', 'ORDER', 'HAVING', 'SET',
                                  'SELECT', 'INNER', 'LEFT', 'RIGHT', 'FULL', 'CROSS',
                                  'JOIN', 'AS', 'AND', 'OR', 'DISTINCT'):
                continue
            if tbl.startswith('(') or not tbl:
                continue
            alias_map[alias.lower()] = tbl

        # Second pass: find subquery aliases — ) ALIAS ON/WHERE/GROUP/LEFT/etc.
        for m in re.finditer(r'\)\s*(\w+)\s+(?:ON|WHERE|GROUP|LEFT|RIGHT|INNER|FULL|CROSS|JOIN|ORDER)', resolved, re.IGNORECASE):
            alias = m.group(1)
            if alias.upper() in ('ON', 'WHERE', 'GROUP', 'ORDER', 'HAVING',
                                  'SELECT', 'INNER', 'LEFT', 'RIGHT', 'AS', 'AND'):
                continue
            if alias.lower() in alias_map:
                continue  # already resolved to a direct table
            # Find the matching opening paren for this subquery
            end_pos = m.start()
            depth = 1
            pos = end_pos
            while pos > 0 and depth > 0:
                pos -= 1
                if resolved[pos] == ')':
                    depth += 1
                elif resolved[pos] == '(':
                    depth -= 1
            subquery = resolved[pos:end_pos + 1]
            # Extract the primary table from inside the subquery
            inner_tables = re.findall(r'\bFROM\s+(\S+?)(?:\s|$|;|\))', subquery, re.IGNORECASE)
            for inner_t in inner_tables:
                inner_t = inner_t.strip('(').strip(')')
                if inner_t.upper() not in ('SELECT', 'WHERE', 'GROUP', '(', ''):
                    alias_map[alias.lower()] = inner_t
                    break

        # Also handle the final subquery alias at end of query: ) ALIAS\nGROUP BY
        for m in re.finditer(r'\)\s*(\w+)\s*$', resolved.strip(), re.IGNORECASE | re.MULTILINE):
            alias = m.group(1)
            if alias.lower() not in alias_map and alias.upper() not in ('ON', 'WHERE', 'GROUP'):
                end_pos = m.start()
                depth = 1
                pos = end_pos
                while pos > 0 and depth > 0:
                    pos -= 1
                    if resolved[pos] == ')':
                        depth += 1
                    elif resolved[pos] == '(':
                        depth -= 1
                inner = resolved[pos:end_pos + 1]
                inner_tables = re.findall(r'\bFROM\s+(\S+?)(?:\s|$|;|\))', inner, re.IGNORECASE)
                for inner_t in inner_tables:
                    inner_t = inner_t.strip('(').strip(')')
                    if inner_t.upper() not in ('SELECT', 'WHERE', 'GROUP', '(', ''):
                        alias_map[alias.lower()] = inner_t
                        break

        # Step 2: Parse SELECT columns to map output_col -> (table, raw_col)
        col_map = {}
        # Extract the SELECT clause (up to first FROM at depth 0)
        select_match = re.match(r'\s*SELECT\s+(?:DISTINCT\s+)?(.+?)\s+FROM\s', resolved, re.IGNORECASE | re.DOTALL)
        if not select_match:
            return {}
        select_clause = select_match.group(1)

        # Split by commas (respecting parentheses)
        depth = 0
        current = []
        select_items = []
        for ch in select_clause:
            if ch == '(':
                depth += 1
                current.append(ch)
            elif ch == ')':
                depth -= 1
                current.append(ch)
            elif ch == ',' and depth == 0:
                select_items.append(''.join(current).strip())
                current = []
            else:
                current.append(ch)
        if current:
            select_items.append(''.join(current).strip())

        for item in select_items:
            item = item.strip()
            if not item:
                continue
            # Extract the output name (after AS or the last identifier)
            as_match = re.search(r'\bAS\s+(\w+)\s*$', item, re.IGNORECASE)
            if as_match:
                output_name = as_match.group(1)
                expr_part = item[:as_match.start()].strip()
            else:
                output_name = item.split('.')[-1].strip().split()[-1].strip(')')
                expr_part = item

            # Find alias.column reference in the expression part
            alias_col_match = re.search(r'(\w+)\.(\w+)', expr_part)
            if alias_col_match:
                alias = alias_col_match.group(1)
                raw_col = alias_col_match.group(2)
                table = alias_map.get(alias.lower(), alias)
                col_map[output_name.lower()] = (table, raw_col)
            else:
                primary = self.get_primary_source_table(t)
                col_map[output_name.lower()] = (primary, output_name)

        return col_map

    def _extract_expression_input_fields(self, expr, upstream_fields):
        """Extract field name references from an IDMC expression.

        Args:
            expr: IDMC expression string
            upstream_fields: set of known field names (lowercase) from upstream transformations

        Returns:
            set of field names (original case from upstream_fields) referenced in the expression
        """
        if not expr:
            return set()
        # Tokenize: extract identifiers (word characters) that aren't function names
        # Functions are followed by '(', string literals are in quotes
        # Remove string literals first
        cleaned = re.sub(r"'[^']*'", '', expr)
        # Extract all identifiers
        tokens = re.findall(r'\b([A-Za-z_]\w*)\b', cleaned)
        # Filter out IDMC function names
        idmc_functions = {
            'iif', 'isnull', 'ltrim', 'rtrim', 'trim', 'upper', 'lower', 'substr',
            'concat', 'length', 'to_date', 'to_char', 'to_integer', 'to_bigint',
            'to_decimal', 'to_float', 'decode', 'instr', 'replacestr', 'replacechr',
            'reg_extract', 'is_date', 'is_number', 'add_to_date', 'date_diff',
            'get_date_part', 'trunc', 'round', 'abs', 'mod', 'power', 'lookup',
            'first', 'last', 'sum', 'count', 'avg', 'max', 'min', 'md5',
            'lpad', 'rpad', 'chr', 'setmaxvariable', 'sysdate', 'sessionstarttime',
            'true', 'false', 'null', 'and', 'or', 'not', 'in', 'between',
            'case', 'when', 'then', 'else', 'end', 'cast', 'as',
        }
        # Build case-insensitive lookup from upstream_fields
        upstream_lower = {}  # lower -> original
        for uf in upstream_fields:
            upstream_lower[uf.lower()] = uf

        result = set()
        for token in tokens:
            if token.lower() in idmc_functions:
                continue
            if token.lower() in upstream_lower:
                result.add(upstream_lower[token.lower()])
        return result

    def _get_all_upstream_fields(self, transformation_name):
        """Get all field names visible from upstream transformations.

        Recursively follows passthrough transformations (JOINER, SORTER, FILTER,
        UNION, ROUTER, LOOKUP with 0 fields) to collect fields from deeper sources.
        """
        fields = set()
        visited = set()

        def _collect(name):
            if name in visited:
                return
            visited.add(name)
            t = self.get_transformation_by_name(name)
            if t is None:
                return
            t_fields = t.get('fields', [])
            ttype = self.identify_type(t)
            if t_fields:
                for fld in t_fields:
                    fields.add(fld['name'])
            # For passthrough types or zero-field transformations, recurse upstream
            if not t_fields or ttype in ('JOINER', 'SORTER', 'FILTER', 'UNION', 'ROUTER', 'LOOKUP'):
                for up in self.get_upstream(name):
                    _collect(up)

        for up_name in self.get_upstream(transformation_name):
            _collect(up_name)
        return fields

    def trace_field_source_pairs(self, field_name, transformation_name, visited=None):
        """Trace a field backward through the DAG to find ALL (source_table, source_column) pairs.

        Unlike trace_field_all_sources which returns (list_of_tables, single_column),
        this returns a list of (table_name, column_name) tuples — one per distinct source.
        For expressions referencing multiple fields, each referenced field is traced separately.

        Returns:
            list of (source_table, source_column) tuples
        """
        if visited is None:
            visited = set()
        visit_key = (field_name.lower(), transformation_name)
        if visit_key in visited:
            return []
        visited.add(visit_key)

        t = self.get_transformation_by_name(transformation_name)
        if t is None:
            return []

        ttype = self.identify_type(t)

        # Normalize o_/exp_ prefix
        for prefix in ('o_', 'exp_', 'e_', 'ch_', 'of_', 'change_'):
            if field_name.lower().startswith(prefix):
                t_fields = {fld['name'].lower() for fld in t.get('fields', [])}
                if field_name.lower() not in t_fields:
                    stripped = field_name[len(prefix):]
                    if stripped.lower() in t_fields or ttype not in ('EXPRESSION',):
                        field_name = stripped
                break

        # SOURCE: terminal — map column to specific table within the query
        if ttype == 'SOURCE':
            src_fields = {fld['name'].lower() for fld in t.get('fields', [])}
            if field_name.lower() not in src_fields:
                return []
            col_table_map = self.get_source_column_table_map(t)
            if field_name.lower() in col_table_map:
                table, raw_col = col_table_map[field_name.lower()]
                return [(table, raw_col)]
            else:
                # Fallback to primary source table
                src_table = self.get_primary_source_table(t)
                return [(src_table, field_name)]

        # EXPRESSION: extract ALL input fields from the expression and trace each
        if ttype == 'EXPRESSION':
            fn_lower = field_name.lower()
            match_names = [fn_lower, f'o_{fn_lower}', f'exp_{fn_lower}']
            for fld in t.get('fields', []):
                if fld['name'].lower() in match_names:
                    expr = fld.get('expression', '')
                    exp_type = fld.get('expFieldType', '')
                    if expr and exp_type in ('OUTPUT', 'VARIABLE', None, ''):
                        # Get all upstream fields and extract references from expression
                        upstream_fields = self._get_all_upstream_fields(transformation_name)
                        referenced_fields = self._extract_expression_input_fields(expr, upstream_fields)
                        if referenced_fields:
                            pairs = []
                            for ref_field in referenced_fields:
                                for up in self.get_upstream(transformation_name):
                                    up_pairs = self.trace_field_source_pairs(ref_field, up, visited)
                                    pairs.extend(up_pairs)
                            return pairs
                        else:
                            # No field references found (e.g. constants) — trace field_name upstream
                            pairs = []
                            for up in self.get_upstream(transformation_name):
                                pairs.extend(self.trace_field_source_pairs(field_name, up, visited))
                            return pairs
            # Passthrough — field not found in this expression, trace upstream
            pairs = []
            for up in self.get_upstream(transformation_name):
                pairs.extend(self.trace_field_source_pairs(field_name, up, visited))
            return pairs

        # AGGREGATOR: extract field references from aggregate expression
        if ttype == 'AGGREGATOR':
            for fld in t.get('fields', []):
                if fld['name'].lower() == field_name.lower():
                    expr = fld.get('expression', '')
                    if expr:
                        upstream_fields = self._get_all_upstream_fields(transformation_name)
                        referenced_fields = self._extract_expression_input_fields(expr, upstream_fields)
                        if referenced_fields:
                            pairs = []
                            for ref_field in referenced_fields:
                                for up in self.get_upstream(transformation_name):
                                    pairs.extend(self.trace_field_source_pairs(ref_field, up, visited))
                            return pairs
            # Passthrough or group-by field
            pairs = []
            for up in self.get_upstream(transformation_name):
                pairs.extend(self.trace_field_source_pairs(field_name, up, visited))
            return pairs

        # JOINER: handle D1_/D_ detail-side prefix remapping
        if ttype == 'JOINER':
            upstreams = self.get_upstream(transformation_name)
            pairs = []
            for up in upstreams:
                # Try field as-is
                up_pairs = self.trace_field_source_pairs(field_name, up, visited)
                if up_pairs:
                    pairs.extend(up_pairs)
                else:
                    # Try stripping D1_/D_ prefix (detail-side convention)
                    for jp in ('D1_', 'D_', 'D2_'):
                        if field_name.lower().startswith(jp.lower()):
                            stripped = field_name[len(jp):]
                            up_pairs = self.trace_field_source_pairs(stripped, up, set(visited))
                            if up_pairs:
                                pairs.extend(up_pairs)
                                break
            return pairs

        # LOOKUP: if the field is one of the lookup's own output fields, map to the lookup's table.
        # Otherwise, pass through to upstream (the main pipeline).
        if ttype == 'LOOKUP':
            lookup_fields = {fld['name'].lower() for fld in t.get('fields', [])}
            if field_name.lower() in lookup_fields:
                # This field comes from the lookup query itself
                col_table_map = self.get_source_column_table_map(t)
                if field_name.lower() in col_table_map:
                    table, raw_col = col_table_map[field_name.lower()]
                    return [(table, raw_col)]
                else:
                    src_table = self.get_primary_source_table(t)
                    return [(src_table, field_name)]
            # Not a lookup output field — pass through to upstream
            pairs = []
            for up in self.get_upstream(transformation_name):
                pairs.extend(self.trace_field_source_pairs(field_name, up, visited))
            return pairs

        # SEQUENCE
        if ttype == 'SEQUENCE':
            pairs = []
            for up in self.get_upstream(transformation_name):
                pairs.extend(self.trace_field_source_pairs(field_name, up, visited))
            return pairs

        # UNION / ROUTER / SORTER / FILTER: follow ALL upstreams
        upstreams = self.get_upstream(transformation_name)
        pairs = []
        for up in upstreams:
            pairs.extend(self.trace_field_source_pairs(field_name, up, visited))
        return pairs

    def get_custom_query_resolved(self, t):
        if 'dataAdapter' not in t:
            return ''
        da = t['dataAdapter']
        obj = da.get('object', {})
        query = obj.get('customQuery', '')
        return self.resolve(query)

    def get_target_table(self, t):
        if 'dataAdapter' not in t:
            return ''
        da = t['dataAdapter']
        obj = da.get('object', {})
        object_name = obj.get('objectName', '')
        # Try common schema parameters in priority order
        schema_keys = ['$$cfsib_schema', '$$jpSchemaName', '$$jpschema_name',
                       '$$EDM_HUB_IVR_PUBLISH_DB_SCHEMA1', '$$EDM_HUB_IVR_PUBLISH_DB_SCHEMA',
                       '$$EDM_HUB_PZ_INSURANCE_CSX_SCHEMA', '$$Tgt_reject']
        schema = ''
        for key in schema_keys:
            schema = self.params.get(key, '')
            if schema:
                break
        if schema and object_name:
            return f'{schema}.{object_name}'
        return object_name

    # -- Data flow --

    def get_upstream(self, name):
        return self.reverse_graph.get(name, [])

    def get_downstream(self, name):
        return self.graph.get(name, [])

    def get_transformation_by_name(self, name):
        for t in self.transformations:
            if t['name'] == name:
                return t
        return None

    def topological_order(self):
        """Return transformations in topological order (source to target)."""
        visited = set()
        order = []

        def dfs(name):
            if name in visited:
                return
            visited.add(name)
            for up in self.get_upstream(name):
                dfs(up)
            order.append(name)

        for t in self.transformations:
            dfs(t['name'])
        return order

    def detect_load_type(self):
        targets = self.get_targets()
        tgt_names = [t['name'].lower() for t in targets]

        # Collect write operations from all targets
        all_operations = []
        has_pre_sql_truncate = False
        has_pre_sql_delete = False
        for tgt in targets:
            da = tgt.get('dataAdapter', {})
            wo = da.get('writeOptions', {})
            ops = wo.get('operations', [])
            all_operations.extend([op.lower() for op in ops])
            for prop in tgt.get('advancedProperties', []):
                pname = prop.get('name', '').lower()
                pval = (prop.get('value', '') or '').upper()
                if 'pre' in pname and 'sql' in pname:
                    if 'TRUNCATE' in pval:
                        has_pre_sql_truncate = True
                    if 'DELETE' in pval:
                        has_pre_sql_delete = True

        has_insert = 'insert' in all_operations
        has_update = 'update' in all_operations
        has_upsert = 'upsert' in all_operations
        has_delete = 'delete' in all_operations

        # Type-2 (SCD): Active/InActive target flows with Insert + Update
        has_active_inactive = (any('active' in n for n in tgt_names)
                               and any('inactive' in n for n in tgt_names))
        if has_active_inactive and (has_update or has_insert):
            return 'Type-2 (SCD)'

        # UPSERT: target write operation is Upsert
        if has_upsert:
            return 'UPSERT'

        # Type-1: Has Update operation but no Active/InActive pattern
        if has_update and not has_active_inactive:
            return 'Type-1'

        # Truncate & Load: pre-SQL contains TRUNCATE
        if has_pre_sql_truncate:
            return 'Truncate & Load'

        # Append Overwrite: pre-SQL contains DELETE (partial delete before insert)
        if has_pre_sql_delete and has_insert:
            return 'Append Overwrite'

        # Append: Insert-only with no truncate/delete, single target, no router
        has_router = any(self.identify_type(t) == 'ROUTER' for t in self.transformations)
        if has_insert and not has_router and len(targets) == 1:
            return 'Append'

        return 'Truncate & Load'

    def build_data_flow_paths(self):
        """Build all paths from sources to targets."""
        sources = [t['name'] for t in self.get_sources()]
        targets = [t['name'] for t in self.get_targets()]
        paths = []

        def find_paths(current, target, path):
            if current == target:
                paths.append(list(path))
                return
            for downstream in self.get_downstream(current):
                if downstream not in path:
                    path.append(downstream)
                    find_paths(downstream, target, path)
                    path.pop()

        for src in sources:
            for tgt in targets:
                find_paths(src, tgt, [src])
        return paths

    # -- Field lineage tracing --

    def get_target_manual_mappings(self, tgt_t):
        """Get manual mappings for a target: {target_field_name: upstream_field_name}."""
        mm = tgt_t.get('manualMappings', {})
        if isinstance(mm, list):
            for m in mm:
                if 'mappingList' in m:
                    mm = m
                    break
            else:
                return {}
        mapping_list = mm.get('mappingList', [])
        result = {}
        for entry in mapping_list:
            from_field_name = entry.get('fromFieldName', '')
            to_field_ref = entry.get('toField', {})
            to_field_id = to_field_ref.get('##ID')
            if to_field_id is not None and to_field_id in self.field_id_map:
                _, to_fld = self.field_id_map[to_field_id]
                result[to_fld['name']] = from_field_name
            elif from_field_name:
                result[from_field_name] = from_field_name
        return result

    def trace_field(self, field_name, transformation_name, visited=None):
        """
        Trace a field backward through the transformation chain.
        Returns (source_table, source_column, transformation_rule, all_expressions).
        """
        if visited is None:
            visited = set()
        visit_key = (field_name, transformation_name)
        if visit_key in visited:
            return ('', field_name, '', [])
        visited.add(visit_key)

        t = self.get_transformation_by_name(transformation_name)
        if t is None:
            return ('', field_name, '', [])

        ttype = self.identify_type(t)

        # SOURCE: terminal node
        if ttype == 'SOURCE':
            src_table = self.get_primary_source_table(t)
            return (src_table, field_name, 'Direct Move from source query', [])

        # EXPRESSION: check if this field has an expression (including o_/exp_ prefix)
        if ttype == 'EXPRESSION':
            fn_lower = field_name.lower()
            expr_match_names = {fn_lower, f'o_{fn_lower}', f'exp_{fn_lower}'}
            for fld in t.get('fields', []):
                if fld['name'].lower() in expr_match_names:
                    expr = fld.get('expression', '')
                    exp_type = fld.get('expFieldType', '')
                    if expr and exp_type in ('OUTPUT', 'VARIABLE', None, ''):
                        sql_expr = idmc_expr_to_sql(expr)
                        upstreams = self.get_upstream(transformation_name)
                        src_tables = []
                        for up in upstreams:
                            up_t = self.get_transformation_by_name(up)
                            if up_t and self.identify_type(up_t) == 'SOURCE':
                                src_tables.append(self.get_primary_source_table(up_t))
                        # Walk upstream to find source tables
                        if not src_tables:
                            for up in upstreams:
                                s, _, _, _ = self.trace_field(field_name, up, visited)
                                if s:
                                    src_tables.append(s)
                        src_table = src_tables[0] if src_tables else ''
                        return (src_table, field_name, sql_expr, [(transformation_name, expr, sql_expr)])
            # Field not found with expression - passthrough, trace upstream
            upstreams = self.get_upstream(transformation_name)
            for up in upstreams:
                result = self.trace_field(field_name, up, visited)
                if result[0] or result[2] != '':
                    return result
            return ('', field_name, '', [])

        # AGGREGATOR: check for aggregate expression or group-by passthrough
        if ttype == 'AGGREGATOR':
            for fld in t.get('fields', []):
                if fld['name'].lower() == field_name.lower():
                    expr = fld.get('expression', '')
                    if expr:
                        sql_expr = idmc_expr_to_sql(expr)
                        upstreams = self.get_upstream(transformation_name)
                        src_tables = []
                        for up in upstreams:
                            s, _, _, _ = self.trace_field(field_name, up, visited)
                            if s:
                                src_tables.append(s)
                        src_table = src_tables[0] if src_tables else ''
                        return (src_table, field_name, sql_expr, [(transformation_name, expr, sql_expr)])
            upstreams = self.get_upstream(transformation_name)
            for up in upstreams:
                result = self.trace_field(field_name, up, visited)
                if result[0]:
                    return result
            return ('', field_name, '', [])

        # JOINER: passthrough from one of the join sides
        if ttype == 'JOINER':
            upstreams = self.get_upstream(transformation_name)
            for up in upstreams:
                result = self.trace_field(field_name, up, visited)
                if result[0]:
                    join_info = self._get_join_info(t)
                    if join_info:
                        exprs = result[3] + [(transformation_name, f'JOIN: {join_info}', f'JOIN: {join_info}')]
                        return (result[0], result[1], result[2], exprs)
                    return result
            return ('', field_name, '', [])

        # LOOKUP: if the field is a lookup output, return lookup source; else passthrough
        if ttype == 'LOOKUP':
            lookup_fields = {fld['name'].lower() for fld in t.get('fields', [])}
            if field_name.lower() in lookup_fields:
                src_table = self.get_primary_source_table(t)
                return (src_table, field_name, 'Direct Move from source query', [])
            upstreams = self.get_upstream(transformation_name)
            for up in upstreams:
                result = self.trace_field(field_name, up, visited)
                if result[0]:
                    return result
            return ('', field_name, '', [])

        # UNION / ROUTER / SORTER / FILTER: passthrough upstream
        upstreams = self.get_upstream(transformation_name)
        for up in upstreams:
            result = self.trace_field(field_name, up, visited)
            if result[0]:
                return result

        return ('', field_name, '', [])

    def trace_field_all_sources(self, field_name, transformation_name, visited=None):
        """
        Like trace_field but follows ALL branches through UNIONs.
        Returns (list_of_source_tables, source_column, transformation_rule, all_expressions).
        """
        if visited is None:
            visited = set()
        visit_key = (field_name, transformation_name)
        if visit_key in visited:
            return ([], field_name, '', [])
        visited.add(visit_key)

        t = self.get_transformation_by_name(transformation_name)
        if t is None:
            return ([], field_name, '', [])

        ttype = self.identify_type(t)

        # Normalize o_/exp_ prefix: if field_name starts with o_ or exp_ and doesn't exist
        # in this transformation's fields, try without the prefix
        for prefix in ('o_', 'exp_'):
            if field_name.lower().startswith(prefix):
                t_fields = {fld['name'].lower() for fld in t.get('fields', [])}
                if field_name.lower() not in t_fields:
                    stripped = field_name[len(prefix):]
                    if stripped.lower() in t_fields or ttype not in ('EXPRESSION',):
                        field_name = stripped
                break

        # SOURCE: terminal node — only return if field exists in this source
        if ttype == 'SOURCE':
            src_fields = {fld['name'].lower() for fld in t.get('fields', [])}
            if field_name.lower() not in src_fields:
                return ([], field_name, '', [])
            src_table = self.get_primary_source_table(t)
            return ([src_table] if src_table else [], field_name, 'Direct Move from source query', [])

        # SEQUENCE: generates surrogate keys with incrementBy (only for _sk fields)
        if ttype == 'SEQUENCE':
            upstreams = self.get_upstream(transformation_name)
            all_src = []
            if field_name.lower().endswith('_sk'):
                state = t.get('state', {})
                inc = state.get('incrementBy', '1')
                rule = f'Increment by {inc} for every new insert based on IDX_NUM'
                for up in upstreams:
                    srcs, _, _, _ = self.trace_field_all_sources(field_name, up, visited)
                    all_src.extend(srcs)
                return (all_src, field_name, rule, [(transformation_name, f'NEXTVAL (incrementBy={inc})', rule)])
            # Non-_sk fields: passthrough
            rule = ''
            exprs = []
            for up in upstreams:
                srcs, col, r, e = self.trace_field_all_sources(field_name, up, visited)
                all_src.extend(srcs)
                if r:
                    rule = r
                if e:
                    exprs = e
            return (all_src, field_name, rule, exprs)

        # EXPRESSION: check if this field has an expression (including o_/exp_ prefix variants)
        if ttype == 'EXPRESSION':
            fn_lower = field_name.lower()
            match_names = [fn_lower, f'o_{fn_lower}', f'exp_{fn_lower}']
            for fld in t.get('fields', []):
                if fld['name'].lower() in match_names:
                    expr = fld.get('expression', '')
                    exp_type = fld.get('expFieldType', '')
                    if expr and exp_type in ('OUTPUT', 'VARIABLE', None, ''):
                        sql_expr = idmc_expr_to_sql(expr)
                        upstreams = self.get_upstream(transformation_name)
                        all_src = []
                        upstream_exprs = []
                        for up in upstreams:
                            srcs, _, _, up_e = self.trace_field_all_sources(field_name, up, visited)
                            all_src.extend(srcs)
                            if up_e:
                                upstream_exprs.extend(up_e)
                        # Accumulate: upstream expressions first, then this transformation's expression
                        all_exprs = upstream_exprs + [(transformation_name, expr, sql_expr)]
                        return (all_src, field_name, sql_expr, all_exprs)
            # Passthrough
            upstreams = self.get_upstream(transformation_name)
            all_src = []
            rule = ''
            exprs = []
            for up in upstreams:
                srcs, col, r, e = self.trace_field_all_sources(field_name, up, visited)
                all_src.extend(srcs)
                if r:
                    rule = r
                if e:
                    exprs = e
            return (all_src, field_name, rule, exprs)

        # AGGREGATOR
        if ttype == 'AGGREGATOR':
            for fld in t.get('fields', []):
                if fld['name'].lower() == field_name.lower():
                    expr = fld.get('expression', '')
                    if expr:
                        sql_expr = idmc_expr_to_sql(expr)
                        upstreams = self.get_upstream(transformation_name)
                        all_src = []
                        upstream_exprs = []
                        for up in upstreams:
                            srcs, _, _, up_e = self.trace_field_all_sources(field_name, up, visited)
                            all_src.extend(srcs)
                            if up_e:
                                upstream_exprs.extend(up_e)
                        all_exprs = upstream_exprs + [(transformation_name, expr, sql_expr)]
                        return (all_src, field_name, sql_expr, all_exprs)
            upstreams = self.get_upstream(transformation_name)
            all_src = []
            for up in upstreams:
                srcs, _, _, _ = self.trace_field_all_sources(field_name, up, visited)
                all_src.extend(srcs)
            return (all_src, field_name, '', [])

        # JOINER: follow all upstream sides
        if ttype == 'JOINER':
            upstreams = self.get_upstream(transformation_name)
            all_src = []
            rule = ''
            exprs = []
            for up in upstreams:
                srcs, col, r, e = self.trace_field_all_sources(field_name, up, visited)
                if srcs:
                    all_src.extend(srcs)
                    if r:
                        rule = r
                    if e:
                        exprs = e
            return (all_src, field_name, rule, exprs)

        # LOOKUP: if field is a lookup output, return the lookup's source; else pass through
        if ttype == 'LOOKUP':
            lookup_fields = {fld['name'].lower() for fld in t.get('fields', [])}
            if field_name.lower() in lookup_fields:
                src_table = self.get_primary_source_table(t)
                return ([src_table] if src_table else [], field_name, 'Direct Move from source query', [])
            # Pass through to upstream
            upstreams = self.get_upstream(transformation_name)
            all_src = []
            rule = ''
            exprs = []
            for up in upstreams:
                srcs, col, r, e = self.trace_field_all_sources(field_name, up, visited)
                all_src.extend(srcs)
                if r:
                    rule = r
                if e:
                    exprs = e
            return (all_src, field_name, rule, exprs)

        # UNION / ROUTER / SORTER / FILTER: follow ALL upstreams
        upstreams = self.get_upstream(transformation_name)
        all_src = []
        rule = ''
        exprs = []
        for up in upstreams:
            srcs, col, r, e = self.trace_field_all_sources(field_name, up, visited)
            all_src.extend(srcs)
            if r and r != 'Direct Move from source query':
                rule = r
            elif not rule and r:
                rule = r
            if e:
                exprs = e
        return (all_src, field_name, rule, exprs)

    def _get_join_info(self, t):
        join_type = t.get('joinType', '')
        conditions = t.get('joinConditions', [])
        if not conditions:
            return ''
        cond_strs = []
        for jc in conditions:
            left = jc.get('leftOperand', '')
            op = jc.get('operator', '=')
            right = jc.get('rightOperand', '')
            cond_strs.append(f'{left} {op} {right}')
        sql_join_type = {
            'Master Outer Join': 'LEFT OUTER JOIN',
            'Detail Outer Join': 'RIGHT OUTER JOIN',
            'Full Outer Join': 'FULL OUTER JOIN',
            'Normal Join': 'INNER JOIN',
        }.get(join_type, join_type)
        return f'{sql_join_type} ON {" AND ".join(cond_strs)}'

    # -- Transformation documentation --

    def document_transformation(self, t):
        """Generate a documentation dict for a transformation."""
        ttype = self.identify_type(t)
        doc = {
            'name': t['name'],
            'type': ttype,
            'fields': [],
            'expressions': [],
            'sql_block': '',
        }

        upstreams = self.get_upstream(t['name'])
        upstream_str = ', '.join(upstreams) if upstreams else 'N/A'

        if ttype == 'SOURCE':
            doc['connection'] = self.get_connection_info(t)
            doc['source_table'] = self.get_primary_source_table(t)
            doc['custom_query'] = self.get_custom_query_resolved(t)
            doc['fields'] = [
                {'name': f['name'], 'type': self._get_field_type_str(f),
                 'precision': f.get('precision', ''), 'scale': f.get('scale', '')}
                for f in t.get('fields', [])
            ]

        elif ttype == 'TARGET':
            doc['target_table'] = self.get_target_table(t)
            doc['connection'] = self.get_connection_info(t)
            doc['fieldMappingMode'] = t.get('fieldMappingMode', '')
            adv = {p['name']: p.get('value', '') for p in t.get('advancedProperties', [])}
            doc['pre_sql'] = adv.get('Pre SQL', '')
            doc['post_sql'] = adv.get('Post SQL', '')
            doc['fields'] = [
                {'name': f['name'], 'type': self._get_field_type_str(f),
                 'precision': f.get('precision', ''), 'scale': f.get('scale', '')}
                for f in t.get('fields', [])
            ]

        elif ttype == 'EXPRESSION':
            for f in t.get('fields', []):
                expr = f.get('expression', '')
                if expr:
                    doc['expressions'].append({
                        'field': f['name'],
                        'expFieldType': f.get('expFieldType', ''),
                        'idmc_expr': expr,
                        'sql_expr': idmc_expr_to_sql(expr),
                    })
            sql_parts = []
            for e in doc['expressions']:
                if e['expFieldType'] != 'VARIABLE':
                    sql_parts.append(f"  {e['sql_expr']} AS {e['field']}")
            if sql_parts:
                doc['sql_block'] = f"SELECT\n{','.join(sql_parts)}\nFROM {upstream_str}"

        elif ttype == 'AGGREGATOR':
            group_by = []
            agg_exprs = []
            for f in t.get('fields', []):
                expr = f.get('expression', '')
                if expr:
                    agg_exprs.append({
                        'field': f['name'],
                        'idmc_expr': expr,
                        'sql_expr': idmc_expr_to_sql(expr),
                    })
                else:
                    group_by.append(f['name'])
            doc['group_by'] = group_by
            doc['expressions'] = agg_exprs
            gb_str = ', '.join(group_by)
            agg_parts = [f"  {a['sql_expr']} AS {a['field']}" for a in agg_exprs]
            all_parts = [f"  {g}" for g in group_by] + agg_parts
            doc['sql_block'] = f"SELECT\n{','.join(all_parts)}\nFROM {upstream_str}\nGROUP BY {gb_str}"

        elif ttype == 'JOINER':
            doc['join_info'] = self._get_join_info(t)
            doc['join_type'] = t.get('joinType', '')
            doc['join_conditions'] = t.get('joinConditions', [])

        elif ttype == 'UNION':
            input_groups = t.get('inputGroups', [])
            doc['input_groups'] = [
                {'name': ig.get('name', ''), 'fields': ig.get('fieldMapping', {}).get('fields', [])}
                for ig in input_groups
            ]

        elif ttype == 'ROUTER':
            doc['filter_conditions'] = t.get('groupFilterConditions', [])

        elif ttype == 'FILTER':
            doc['filter_conditions'] = t.get('filterConditions', [])

        elif ttype == 'SORTER':
            doc['sort_entries'] = t.get('sortEntries', [])

        return doc

    def _get_field_type_str(self, field):
        pt = field.get('platformType', {})
        if isinstance(pt, dict):
            sid = pt.get('##SID', '')
            # Extract type name from SID like "smd:.../string"
            if '/' in sid:
                return sid.rsplit('/', 1)[-1].upper()
            return str(sid)
        return str(pt).upper()

    def get_field_data_type_for_sttm(self, field):
        """Get a display-friendly data type string for STTM output."""
        base_type = self._get_field_type_str(field)
        precision = field.get('precision', '')
        scale = field.get('scale', '')
        if base_type in ('STRING', 'VARCHAR'):
            return f'VARCHAR({precision})' if precision else 'VARCHAR'
        if base_type in ('BIGINT', 'INTEGER', 'INT'):
            return base_type
        if base_type in ('DECIMAL', 'NUMERIC', 'NUMBER'):
            if precision and scale:
                return f'DECIMAL({precision},{scale})'
            return f'DECIMAL({precision})' if precision else 'DECIMAL'
        if base_type in ('FLOAT', 'DOUBLE'):
            return base_type
        if base_type == 'DATE':
            return 'DATE'
        if base_type in ('DATETIME', 'TIMESTAMP'):
            return 'TIMESTAMP'
        if precision:
            return f'{base_type}({precision})'
        return base_type


# ---------------------------------------------------------------------------
# STTM Excel Writer
# ---------------------------------------------------------------------------

# Style constants
HEADER_FILL = PatternFill(start_color='4472C4', end_color='4472C4', fill_type='solid')
HEADER_FONT = Font(name='Calibri', size=11, bold=True, color='FFFFFF')
META_LABEL_FILL = PatternFill(start_color='D6E4F0', end_color='D6E4F0', fill_type='solid')
META_LABEL_FONT = Font(name='Calibri', size=11, bold=True)
DATA_FONT = Font(name='Calibri', size=10)
THIN_BORDER = Border(
    left=Side(style='thin'), right=Side(style='thin'),
    top=Side(style='thin'), bottom=Side(style='thin')
)
WRAP_ALIGNMENT = Alignment(wrap_text=True, vertical='top')

STTM_COLUMNS = [
    'Subject Area', 'Target Table', 'Target Column Name',
    'Business Definition', 'Target Data Type', 'Target Nullability',
    'Source Table Name', 'Source Column Name', 'Source Column Type',
    'Source Transformational Rule/Logic', 'Pending Questions/Queries', 'Observation'
]


def _build_field_transformation_lookup(mapping):
    """Build a lookup: field_name (lower) -> list of (transformation_name, type, logic_text).

    Scans ALL transformations in topological order. For EXPRESSION and AGGREGATOR
    types, records each output field and its expression. For JOINER, ROUTER, FILTER,
    UNION, SEQUENCE types, records the transformation-level logic for fields that
    pass through them.

    Returns a dict mapping normalised field names to ordered lists of
    (transformation_name, pseudo_code_line) tuples.
    """
    lookup = {}  # field_name_lower -> [(txf_name, pseudo_code)]

    # Strip common IDMC output prefixes to map back to target field name
    def _normalise_field_name(raw_name):
        low = raw_name.lower()
        for prefix in ('o_', 'exp_', 'e_', 'ch_', 'of_'):
            if low.startswith(prefix):
                return low[len(prefix):]
        return low

    topo_order = mapping.topological_order()
    for tname in topo_order:
        t = mapping.get_transformation_by_name(tname)
        if t is None:
            continue
        ttype = mapping.identify_type(t)

        if ttype in ('EXPRESSION', 'AGGREGATOR'):
            for fld in t.get('fields', []):
                expr = fld.get('expression', '')
                if not expr:
                    continue
                exp_type = fld.get('expFieldType', '')
                # Skip VARIABLE-only fields (internal pipeline variables)
                if exp_type == 'VARIABLE':
                    continue
                raw_name = fld['name']
                norm = _normalise_field_name(raw_name)
                sql_expr = idmc_expr_to_sql(expr)
                pseudo = f'[{tname}] ({ttype}): {raw_name} = {sql_expr}'
                lookup.setdefault(norm, []).append((tname, pseudo))

        elif ttype == 'JOINER':
            join_info = mapping._get_join_info(t)
            if join_info:
                # Joiner affects all fields passing through — record once per field
                for fld in t.get('fields', []):
                    norm = _normalise_field_name(fld['name'])
                    pseudo = f'[{tname}] (JOINER): {join_info}'
                    lookup.setdefault(norm, []).append((tname, pseudo))

        elif ttype == 'ROUTER':
            doc = mapping.document_transformation(t)
            for fc in doc.get('filter_conditions', []):
                cond = fc.get('advancedFilterCondition', '')
                group_name = fc.get('name', '')
                if cond:
                    for fld in t.get('fields', []):
                        norm = _normalise_field_name(fld['name'])
                        pseudo = f'[{tname}] (ROUTER): Group {group_name}, Condition: {cond}'
                        lookup.setdefault(norm, []).append((tname, pseudo))

        elif ttype == 'FILTER':
            doc = mapping.document_transformation(t)
            filter_text_parts = []
            for fc in doc.get('filter_conditions', []):
                filter_text_parts.append(
                    f'{fc.get("fieldName", "")} {fc.get("operator", "")} {fc.get("filterValue", "")}'
                )
            if filter_text_parts:
                filter_text = '; '.join(filter_text_parts)
                for fld in t.get('fields', []):
                    norm = _normalise_field_name(fld['name'])
                    pseudo = f'[{tname}] (FILTER): {filter_text}'
                    lookup.setdefault(norm, []).append((tname, pseudo))

        elif ttype == 'SEQUENCE':
            state = t.get('state', {})
            inc = state.get('incrementBy', '1')
            for fld in t.get('fields', []):
                if fld['name'].lower().endswith('_sk') or fld['name'].lower() == 'nextval':
                    norm = _normalise_field_name(fld['name'])
                    pseudo = f'[{tname}] (SEQUENCE): Increment by {inc}'
                    lookup.setdefault(norm, []).append((tname, pseudo))

    # Deduplicate: same transformation shouldn't appear twice for same field
    for field_key in lookup:
        seen = set()
        deduped = []
        for txf_name, pseudo in lookup[field_key]:
            key = (txf_name, pseudo)
            if key not in seen:
                seen.add(key)
                deduped.append((txf_name, pseudo))
        lookup[field_key] = deduped

    return lookup


def write_sttm_sheet(ws, mapping, target_t, logger):
    """Write a single STTM tab for one target transformation."""
    target_table = mapping.get_target_table(target_t)
    target_name = target_table.split('.')[-1] if target_table else target_t['name']
    schema_name = target_table.split('.')[0] if '.' in target_table else ''
    description = mapping.description or f'This mapping loads data into {target_name}'

    # Build lookup of source query info
    sources = mapping.get_sources()
    source_queries = {}
    for src in sources:
        src_query = mapping.get_custom_query_resolved(src)
        src_table = mapping.get_primary_source_table(src)
        source_queries[src['name']] = {'query': src_query, 'table': src_table}

    # Build data flow description
    paths = mapping.build_data_flow_paths()
    flow_str = ''
    for path in paths:
        flow_str += ' --> '.join(path) + '\n'

    # -- Row 1: Back to Index
    ws.cell(row=1, column=1, value='Back to Index').font = Font(name='Calibri', size=11, bold=True, color='4472C4')

    # -- Row 2: Metadata
    meta_labels_r2 = [
        (1, 'Target Table Name'), (2, target_name),
        (3, 'Target Schema Name'), (4, schema_name),
        (5, 'Created By'), (6, 'Auto-generated'),
        (7, 'Last Updated By'), (8, 'Auto-generated'),
    ]
    for col, val in meta_labels_r2:
        cell = ws.cell(row=2, column=col, value=val)
        if col in (1, 3, 5, 7):
            cell.fill = META_LABEL_FILL
            cell.font = META_LABEL_FONT
        cell.border = THIN_BORDER

    # -- Row 3: Purpose
    ws.cell(row=3, column=1, value='Purpose').fill = META_LABEL_FILL
    ws.cell(row=3, column=1).font = META_LABEL_FONT
    ws.cell(row=3, column=1).border = THIN_BORDER
    ws.cell(row=3, column=2, value=description).border = THIN_BORDER
    ws.cell(row=3, column=5, value='Created On').fill = META_LABEL_FILL
    ws.cell(row=3, column=5).font = META_LABEL_FONT
    ws.cell(row=3, column=5).border = THIN_BORDER
    ws.cell(row=3, column=6, value=datetime.now().strftime('%Y-%m-%d')).border = THIN_BORDER
    ws.cell(row=3, column=7, value='Last Updated On').fill = META_LABEL_FILL
    ws.cell(row=3, column=7).font = META_LABEL_FONT
    ws.cell(row=3, column=7).border = THIN_BORDER
    ws.cell(row=3, column=8, value=datetime.now().strftime('%Y-%m-%d')).border = THIN_BORDER

    # -- Row 5: Load type, extraction, queries
    adv_props = {p['name']: p.get('value', '') for p in target_t.get('advancedProperties', [])}

    # Compose main query from source custom queries
    main_queries = []
    for src in sources:
        q = mapping.get_custom_query_resolved(src)
        if q:
            main_queries.append(f'-- Source: {src["name"]}\n{q}')
    main_query_text = '\n\n'.join(main_queries)

    load_type = mapping.detect_load_type()
    ROW5_LABEL_FILL = PatternFill(start_color='FDE9D9', end_color='FDE9D9', fill_type='solid')
    ROW5_LOAD_FONT = Font(name='Calibri', size=9, bold=True, color='0066FF')
    ROW5_LABEL_FONT = Font(name='Calibri', size=9, bold=True)
    ROW5_NK_FONT = Font(name='Calibri', size=9, bold=True, color='FF0000')

    ws.row_dimensions[5].height = 72

    ws.cell(row=5, column=1, value=f'Database Operation/Table Load Type:\n{load_type}')
    ws.cell(row=5, column=1).fill = ROW5_LABEL_FILL
    ws.cell(row=5, column=1).font = ROW5_LOAD_FONT
    ws.cell(row=5, column=1).alignment = WRAP_ALIGNMENT
    ws.cell(row=5, column=1).border = THIN_BORDER

    ws.cell(row=5, column=2).font = ROW5_LABEL_FONT
    ws.cell(row=5, column=2).border = THIN_BORDER

    ws.cell(row=5, column=3, value=f'Extraction Criteria:\n{flow_str}')
    ws.cell(row=5, column=3).fill = ROW5_LABEL_FILL
    ws.cell(row=5, column=3).font = ROW5_LABEL_FONT
    ws.cell(row=5, column=3).alignment = WRAP_ALIGNMENT
    ws.cell(row=5, column=3).border = THIN_BORDER

    ws.cell(row=5, column=4, value=f'Main Query:\n{main_query_text}')
    ws.cell(row=5, column=4).fill = ROW5_LABEL_FILL
    ws.cell(row=5, column=4).font = ROW5_LABEL_FONT
    ws.cell(row=5, column=4).alignment = WRAP_ALIGNMENT
    ws.cell(row=5, column=4).border = THIN_BORDER

    ws.cell(row=5, column=5).fill = ROW5_LABEL_FILL
    ws.cell(row=5, column=5).font = ROW5_LABEL_FONT
    ws.cell(row=5, column=5).border = THIN_BORDER

    ws.cell(row=5, column=6).border = THIN_BORDER

    nk_fields = [f['name'] for f in target_t.get('fields', []) if f['name'].lower().endswith(('_nk', '_id_nk'))]
    nk_text = f'NK Column List:\n{", ".join(nk_fields)}' if nk_fields else 'NK Column List:'
    ws.cell(row=5, column=7, value=nk_text)
    ws.cell(row=5, column=7).font = ROW5_NK_FONT
    ws.cell(row=5, column=7).alignment = WRAP_ALIGNMENT
    ws.cell(row=5, column=7).border = THIN_BORDER

    ws.cell(row=5, column=8).border = THIN_BORDER

    # -- Row 6: Column headers
    for col_idx, header in enumerate(STTM_COLUMNS, 1):
        cell = ws.cell(row=6, column=col_idx, value=header)
        cell.fill = HEADER_FILL
        cell.font = HEADER_FONT
        cell.border = THIN_BORDER
        cell.alignment = Alignment(horizontal='center', vertical='center', wrap_text=True)

    # -- Data rows (row 7+): One row per (target field, source table, source column) pair
    manual_mappings = mapping.get_target_manual_mappings(target_t)
    upstream_of_target = mapping.get_upstream(target_t['name'])

    # Build field -> transformation logic lookup from Transformation_Logic data
    txf_lookup = _build_field_transformation_lookup(mapping)

    # Build a set of all source field names for prefix-stripping validation
    _source_field_names = set()
    for src in sources:
        for sf in src.get('fields', []):
            _source_field_names.add(sf['name'].lower())

    # Get subject area from mapping name
    mapping_name = mapping.name
    subject_area = mapping_name.replace('m_finance_', '').replace('m_', '').split('_')[0].upper()
    if 'GMAD' in mapping_name.upper():
        subject_area = 'Finance-GMAD'
    elif 'PDDS' in mapping_name.upper():
        subject_area = 'Finance-PDDS'

    row_num = 7
    for field in target_t.get('fields', []):
        field_name = field['name']
        data_type = mapping.get_field_data_type_for_sttm(field)

        # Find upstream field name from manual mappings
        upstream_field = manual_mappings.get(field_name, field_name)

        # Trace field lineage using the new pair-based method
        source_pairs = []  # list of (source_table, source_column)
        if upstream_of_target:
            for up_name in upstream_of_target:
                pairs = mapping.trace_field_source_pairs(upstream_field, up_name)
                if pairs:
                    source_pairs.extend(pairs)
                    break

        # Deduplicate (table, column) pairs while preserving order
        seen_pairs = set()
        unique_pairs = []
        for tbl, col in source_pairs:
            key = (tbl.lower(), col.lower())
            if key not in seen_pairs:
                seen_pairs.add(key)
                unique_pairs.append((tbl, col))

        # Strip IDMC prefixes from source column names
        cleaned_pairs = []
        _idmc_prefixes = ('o_', 'exp_', 'e_', 'ch_', 'of_', 'change_')
        for src_tbl, src_col in unique_pairs:
            _remaining = src_col
            _candidates = [src_col]
            while True:
                _stripped = False
                for _p in _idmc_prefixes:
                    if _remaining.lower().startswith(_p):
                        _remaining = _remaining[len(_p):]
                        _candidates.append(_remaining)
                        _stripped = True
                        break
                if not _stripped:
                    break
            # Pick best candidate
            best = src_col
            for candidate in reversed(_candidates):
                if not candidate:
                    continue
                if candidate.lower() in _source_field_names:
                    best = candidate
                    break
                if candidate.lower() == field_name.lower():
                    best = candidate
                    break
            else:
                # Use the most stripped version
                if _candidates[-1]:
                    best = _candidates[-1]
            cleaned_pairs.append((src_tbl, best))

        # If no pairs found, fall back to the old trace for source info
        if not cleaned_pairs:
            fallback_table = ''
            fallback_col = upstream_field
            if upstream_of_target:
                for up_name in upstream_of_target:
                    src_tables, src_col, rule, _ = mapping.trace_field_all_sources(
                        upstream_field, up_name
                    )
                    if src_tables:
                        fallback_table = src_tables[0]
                        fallback_col = src_col
                        break
            # Strip IDMC prefixes from fallback column
            _remaining = fallback_col
            _candidates = [fallback_col]
            while True:
                _stripped = False
                for _p in _idmc_prefixes:
                    if _remaining.lower().startswith(_p):
                        _remaining = _remaining[len(_p):]
                        _candidates.append(_remaining)
                        _stripped = True
                        break
                if not _stripped:
                    break
            best = fallback_col
            for candidate in reversed(_candidates):
                if not candidate:
                    continue
                if candidate.lower() == field_name.lower():
                    best = candidate
                    break
                if candidate.lower() in _source_field_names:
                    best = candidate
                    break
            else:
                if _candidates[-1]:
                    best = _candidates[-1]
            if any(fallback_col.lower().startswith(p) for p in _idmc_prefixes) and best == fallback_col:
                best = field_name
            cleaned_pairs = [(fallback_table, best)]

        # Build transformation rule from Transformation_Logic lookup
        transformation_rule = 'Direct Move from source query'
        fn_lower = field_name.lower()
        txf_entries = txf_lookup.get(fn_lower, [])
        if txf_entries:
            if len(txf_entries) == 1:
                transformation_rule = txf_entries[0][1]
            else:
                transformation_rule = '\n'.join(
                    f'Step {i}: {pseudo}'
                    for i, (_txf_name, pseudo) in enumerate(txf_entries, 1)
                )
        # Fallback: if no lookup entries, check DAG-traced expr_chain
        elif upstream_of_target:
            for up_name in upstream_of_target:
                _, _, rule, expr_chain = mapping.trace_field_all_sources(
                    upstream_field, up_name
                )
                if expr_chain:
                    steps = [(t_name, sql_e) for t_name, _, sql_e in expr_chain
                             if sql_e and sql_e != 'Direct Move from source query']
                    if steps:
                        if len(steps) == 1:
                            transformation_rule = f'[{steps[0][0]}]: {steps[0][1]}'
                        else:
                            transformation_rule = '\n'.join(
                                f'Step {i} [{t_name}]: {sql_e}'
                                for i, (t_name, sql_e) in enumerate(steps, 1)
                            )
                        break
                elif rule and rule != 'Direct Move from source query':
                    transformation_rule = rule
                    break

        if field_name.lower().endswith('_sk'):
            transformation_rule = 'Increment row number by 1'
        if 'edh_' in field_name.lower():
            transformation_rule = ''

        # Determine nullability
        nullable = 'Null'
        if field_name.lower().endswith(('_sk', '_key', '_id')) or field_name.lower() in ('batch_key',):
            nullable = 'Not null'

        # Write one row per (source_table, source_column) pair
        for pair_idx, (src_tbl, src_col) in enumerate(cleaned_pairs):
            # Source column type - try to find from source transformation fields
            source_col_type = ''
            for src in sources:
                for sf in src.get('fields', []):
                    if sf['name'].lower() == src_col.lower():
                        source_col_type = mapping.get_field_data_type_for_sttm(sf)
                        break
                if source_col_type:
                    break
            if not source_col_type:
                source_col_type = data_type

            row_data = [
                subject_area,
                target_name,
                field_name,
                '',  # Business Definition
                data_type,
                nullable,
                src_tbl,
                src_col,
                source_col_type,
                transformation_rule if pair_idx == 0 else '',  # rule on first row only
                '',  # Pending Questions
                '',  # Observation
            ]

            for col_idx, value in enumerate(row_data, 1):
                cell = ws.cell(row=row_num, column=col_idx, value=value)
                cell.font = DATA_FONT
                cell.border = THIN_BORDER
                cell.alignment = Alignment(vertical='top', wrap_text=True)

            row_num += 1

        logger.info(f'  Field: {field_name} -> {len(cleaned_pairs)} source pair(s)')

    # Set column widths
    col_widths = [18, 35, 30, 30, 18, 14, 45, 30, 18, 60, 25, 25]
    for i, w in enumerate(col_widths, 1):
        ws.column_dimensions[openpyxl.utils.get_column_letter(i)].width = w

    return row_num - 7  # number of field rows


def _render_flow_node(mapping, node_name, visited):
    """Recursively render a node and its upstream tree as ASCII lines.
    Returns (lines, connect_idx) where connect_idx is the line index
    that should connect to the next downstream node."""
    t = mapping.get_transformation_by_name(node_name)
    ttype = mapping.identify_type(t) if t else 'UNKNOWN'
    label = f"[{ttype.capitalize()}: {node_name}]"

    upstreams = list(dict.fromkeys(
        u for u in mapping.get_upstream(node_name) if u not in visited
    ))
    visited.add(node_name)

    if not upstreams:
        return [label], 0

    if len(upstreams) == 1:
        child_lines, child_conn = _render_flow_node(mapping, upstreams[0], visited)
        child_lines[child_conn] += f" --> {label}"
        return child_lines, child_conn

    # Multiple upstreams — render each branch, then merge
    blocks = []
    for up in upstreams:
        block = _render_flow_node(mapping, up, visited)
        blocks.append(block)

    # Stack blocks vertically
    combined = []
    conn_indices = []
    for block_lines, conn in blocks:
        offset = len(combined)
        conn_indices.append(offset + conn)
        combined.extend(block_lines)

    # Pad all lines to same width
    max_w = max(len(line) for line in combined)
    padded = [line.ljust(max_w) for line in combined]

    first = conn_indices[0]
    last = conn_indices[-1]
    mid_conn = conn_indices[len(conn_indices) // 2]

    for i in range(len(padded)):
        if i == mid_conn:
            padded[i] += f" --+--> {label}"
        elif i in conn_indices:
            padded[i] += " --+"
        elif first < i < last:
            padded[i] += "   |"

    return padded, mid_conn


def _build_job_flow_lines(mapping, target_name):
    """Build multi-line job flow text showing all branches merging into one target."""
    lines, _ = _render_flow_node(mapping, target_name, set())
    return lines


def write_summary_sheet(ws, mapping, logger):
    """Write the Summary sheet showing source/target table and merged job flow below."""
    MONO_FONT = Font(name='Consolas', size=9)
    FLOW_HEADER_FONT = Font(name='Calibri', size=11, bold=True, color='FFFFFF')
    FLOW_HEADER_FILL = PatternFill(start_color='4472C4', end_color='4472C4', fill_type='solid')

    # --- Source / Target table ---
    headers = ['#', 'Source Schema', 'Source Table', 'Target Schema', 'Target Table', 'Ext Lake Flag']
    for col_idx, header in enumerate(headers, 1):
        cell = ws.cell(row=1, column=col_idx, value=header)
        cell.fill = HEADER_FILL
        cell.font = HEADER_FONT
        cell.border = THIN_BORDER
        cell.alignment = Alignment(horizontal='center', wrap_text=True)

    sources = mapping.get_sources()
    targets = mapping.get_targets()

    # Build target info (schema.table) for all targets
    target_entries = []
    for tgt in targets:
        tgt_table_full = mapping.get_target_table(tgt)
        if '.' in tgt_table_full:
            tgt_schema, tgt_table = tgt_table_full.split('.', 1)
        else:
            tgt_schema = ''
            tgt_table = tgt_table_full
        target_entries.append((tgt_schema, tgt_table, tgt['name']))

    # Collect unique (src_schema, src_table, tgt_schema, tgt_table) rows
    seen_rows = set()
    summary_rows = []
    for src in sources:
        all_tables = mapping.get_source_tables(src)
        if not all_tables:
            all_tables = [mapping.get_primary_source_table(src)]
        for src_table_full in all_tables:
            if '.' in src_table_full:
                src_schema, src_table = src_table_full.split('.', 1)
            else:
                src_schema = ''
                src_table = src_table_full
            for tgt_schema, tgt_table, tgt_name in target_entries:
                row_key = (src_schema, src_table, tgt_schema, tgt_table)
                if row_key in seen_rows:
                    continue
                seen_rows.add(row_key)
                ext_lake_flag = 'Y' if src_schema.startswith('ext_lake') else 'N'
                summary_rows.append((src_schema, src_table, tgt_schema, tgt_table, ext_lake_flag))

    row_idx = 2
    for src_schema, src_table, tgt_schema, tgt_table, ext_lake_flag in summary_rows:
        row_data = [
            row_idx - 1, src_schema, src_table,
            tgt_schema, tgt_table, ext_lake_flag,
        ]
        for col_idx, value in enumerate(row_data, 1):
            cell = ws.cell(row=row_idx, column=col_idx, value=value)
            cell.font = DATA_FONT
            cell.border = THIN_BORDER
            cell.alignment = Alignment(vertical='top', wrap_text=True)
        row_idx += 1

    table_rows = row_idx - 2

    # --- Job Flow section below the table ---
    row_idx += 1  # blank separator row

    for tgt_schema, tgt_table, tgt_name in target_entries:
        # Section header
        cell = ws.cell(row=row_idx, column=1, value=f"Job Flow: {tgt_name}")
        cell.fill = FLOW_HEADER_FILL
        cell.font = FLOW_HEADER_FONT
        cell.border = THIN_BORDER
        # Merge header across columns
        ws.merge_cells(start_row=row_idx, start_column=1, end_row=row_idx, end_column=6)
        row_idx += 1

        # Render the merged flow
        flow_lines = _build_job_flow_lines(mapping, tgt_name)
        for line in flow_lines:
            cell = ws.cell(row=row_idx, column=1, value=line)
            cell.font = MONO_FONT
            cell.alignment = Alignment(vertical='top', wrap_text=False)
            # Merge across columns so long lines are visible
            ws.merge_cells(start_row=row_idx, start_column=1, end_row=row_idx, end_column=6)
            row_idx += 1

        row_idx += 1  # blank row between targets

    col_widths = [5, 35, 40, 35, 40, 14]
    for i, w in enumerate(col_widths, 1):
        ws.column_dimensions[openpyxl.utils.get_column_letter(i)].width = w

    logger.info(f'  Wrote {table_rows} rows to Summary sheet')


def write_index_sheet(ws, entries):
    """Write the Index sheet."""
    headers = ['#', 'Index', 'Table Load Type', 'Table Refresh Frequency',
               'Table Load SLA', 'Source System Name', 'Comments', 'STTM',
               'Project Teams', 'Owner']
    for col_idx, header in enumerate(headers, 1):
        cell = ws.cell(row=1, column=col_idx, value=header)
        cell.fill = HEADER_FILL
        cell.font = HEADER_FONT
        cell.border = THIN_BORDER
        cell.alignment = Alignment(horizontal='center', wrap_text=True)

    for row_idx, entry in enumerate(entries, 2):
        for col_idx, value in enumerate(entry, 1):
            cell = ws.cell(row=row_idx, column=col_idx, value=value)
            cell.font = DATA_FONT
            cell.border = THIN_BORDER
            cell.alignment = Alignment(vertical='top', wrap_text=True)

    col_widths = [5, 40, 20, 25, 20, 50, 30, 8, 20, 20]
    for i, w in enumerate(col_widths, 1):
        ws.column_dimensions[openpyxl.utils.get_column_letter(i)].width = w


def write_version_history_sheet(ws):
    """Write the Version History sheet with header row for manual fill."""
    headers = ['#', 'Version', 'Date', 'Updated By', 'Table Name',
               'Mapping Changes', 'Reason', 'Comment']
    for col_idx, header in enumerate(headers, 1):
        cell = ws.cell(row=1, column=col_idx, value=header)
        cell.fill = HEADER_FILL
        cell.font = HEADER_FONT
        cell.border = THIN_BORDER
        cell.alignment = Alignment(horizontal='center', wrap_text=True)

    col_widths = [5, 12, 15, 20, 35, 40, 30, 30]
    for i, w in enumerate(col_widths, 1):
        ws.column_dimensions[openpyxl.utils.get_column_letter(i)].width = w


def write_lookup_sheet(ws, mapping, logger):
    """Write the Lookup_Definitions sheet documenting all source queries."""
    headers = ['#', 'Source Name', 'Source Table', 'Connection', 'Custom Query (Resolved)']
    for col_idx, header in enumerate(headers, 1):
        cell = ws.cell(row=1, column=col_idx, value=header)
        cell.fill = HEADER_FILL
        cell.font = HEADER_FONT
        cell.border = THIN_BORDER
        cell.alignment = Alignment(horizontal='center', wrap_text=True)

    sources = mapping.get_sources()
    lookups = mapping.get_transformations_by_type('LOOKUP')
    all_source_defs = sources + lookups
    for row_idx, src in enumerate(all_source_defs, 2):
        conn = mapping.get_connection_info(src)
        src_table = mapping.get_primary_source_table(src)
        query = mapping.get_custom_query_resolved(src)

        row_data = [
            row_idx - 1,
            src['name'],
            src_table,
            f"{conn.get('parameter', '')} ({conn.get('resolved', '')})",
            query,
        ]
        for col_idx, value in enumerate(row_data, 1):
            cell = ws.cell(row=row_idx, column=col_idx, value=value)
            cell.font = DATA_FONT
            cell.border = THIN_BORDER
            cell.alignment = Alignment(vertical='top', wrap_text=True)

    col_widths = [5, 35, 45, 35, 100]
    for i, w in enumerate(col_widths, 1):
        ws.column_dimensions[openpyxl.utils.get_column_letter(i)].width = w

    logger.info(f'  Wrote {len(all_source_defs)} source definitions to Lookup_Definitions')


def write_transformation_sheet(ws, mapping, logger):
    """Write a Transformation_Logic sheet documenting all transformation steps."""
    headers = ['#', 'Transformation', 'Type', 'Logic / SQL Equivalent']
    for col_idx, header in enumerate(headers, 1):
        cell = ws.cell(row=1, column=col_idx, value=header)
        cell.fill = HEADER_FILL
        cell.font = HEADER_FONT
        cell.border = THIN_BORDER

    topo_order = mapping.topological_order()
    row_idx = 2
    for idx, tname in enumerate(topo_order, 1):
        t = mapping.get_transformation_by_name(tname)
        if t is None:
            continue
        doc = mapping.document_transformation(t)
        ttype = doc['type']

        logic_parts = []
        if ttype == 'SOURCE':
            query = doc.get('custom_query', '')
            if query:
                logic_parts.append(f'Source Query:\n{query}')
        elif ttype == 'TARGET':
            logic_parts.append(f'Target Table: {doc.get("target_table", "")}')
            if doc.get('pre_sql'):
                logic_parts.append(f'Pre SQL: {doc["pre_sql"]}')
            if doc.get('post_sql'):
                logic_parts.append(f'Post SQL: {doc["post_sql"]}')
        elif ttype == 'EXPRESSION':
            for e in doc.get('expressions', []):
                logic_parts.append(
                    f'{e["field"]} ({e["expFieldType"]}): '
                    f'{e["idmc_expr"]}\n  SQL: {e["sql_expr"]}'
                )
        elif ttype == 'AGGREGATOR':
            if doc.get('group_by'):
                logic_parts.append(f'GROUP BY: {", ".join(doc["group_by"])}')
            for e in doc.get('expressions', []):
                logic_parts.append(f'{e["field"]}: {e["idmc_expr"]}\n  SQL: {e["sql_expr"]}')
        elif ttype == 'JOINER':
            logic_parts.append(doc.get('join_info', ''))
        elif ttype == 'ROUTER':
            for fc in doc.get('filter_conditions', []):
                logic_parts.append(
                    f'Group: {fc.get("name", "")}, '
                    f'Condition: {fc.get("advancedFilterCondition", "")}'
                )
        elif ttype == 'FILTER':
            for fc in doc.get('filter_conditions', []):
                logic_parts.append(
                    f'{fc.get("fieldName", "")} {fc.get("operator", "")} {fc.get("filterValue", "")}'
                )
        elif ttype == 'SORTER':
            for se in doc.get('sort_entries', []):
                direction = 'ASC' if se.get('ascending', True) else 'DESC'
                logic_parts.append(f'{se.get("fieldName", "")} {direction}')
        elif ttype == 'SEQUENCE':
            state = t.get('state', {})
            inc = state.get('incrementBy', '1')
            start = state.get('startValue', '0')
            logic_parts.append(f'Increment by {inc} for every new insert based on IDX_NUM')
            logic_parts.append(f'Start Value: {start}')
        elif ttype == 'UNION':
            for ig in doc.get('input_groups', []):
                logic_parts.append(f'Input Group: {ig["name"]}')

        logic_text = '\n'.join(logic_parts) if logic_parts else 'Passthrough'

        row_data = [idx, tname, ttype, logic_text]
        for col_idx, value in enumerate(row_data, 1):
            cell = ws.cell(row=row_idx, column=col_idx, value=value)
            cell.font = DATA_FONT
            cell.border = THIN_BORDER
            cell.alignment = Alignment(vertical='top', wrap_text=True)
        row_idx += 1

    col_widths = [5, 40, 15, 120]
    for i, w in enumerate(col_widths, 1):
        ws.column_dimensions[openpyxl.utils.get_column_letter(i)].width = w

    logger.info(f'  Wrote {row_idx - 2} transformation docs to Transformation_Logic')


# ---------------------------------------------------------------------------
# Data Flow sheet — end-to-end pipeline view
# ---------------------------------------------------------------------------

# Color palette per transformation type
TYPE_FILLS = {
    'SOURCE':      PatternFill(start_color='C6EFCE', end_color='C6EFCE', fill_type='solid'),  # green
    'EXPRESSION':  PatternFill(start_color='BDD7EE', end_color='BDD7EE', fill_type='solid'),  # blue
    'AGGREGATOR':  PatternFill(start_color='D9E2F3', end_color='D9E2F3', fill_type='solid'),  # light indigo
    'JOINER':      PatternFill(start_color='FCE4D6', end_color='FCE4D6', fill_type='solid'),  # peach
    'UNION':       PatternFill(start_color='E2EFDA', end_color='E2EFDA', fill_type='solid'),  # light green
    'ROUTER':      PatternFill(start_color='FFF2CC', end_color='FFF2CC', fill_type='solid'),  # yellow
    'FILTER':      PatternFill(start_color='F8CBAD', end_color='F8CBAD', fill_type='solid'),  # salmon
    'SORTER':      PatternFill(start_color='EDEDED', end_color='EDEDED', fill_type='solid'),  # grey
    'TARGET':      PatternFill(start_color='D6B4FC', end_color='D6B4FC', fill_type='solid'),  # purple
}

FLOW_COLUMNS = [
    'Step', 'Transformation', 'Type',
    'Feeds From', 'Feeds To',
    'Physical Table / Connection',
    'Key Logic (Query / Join / Filter / Route)',
    'Input Fields',
    'Output Fields',
    'Field-Level IDMC Expressions',
    'Field-Level SQL Equivalent',
]


def write_data_flow_sheet(ws, mapping, logger):
    """Write an end-to-end Data_Flow tab covering source -> transformations -> target."""

    # ---- title row ----
    ws.merge_cells(start_row=1, start_column=1, end_row=1, end_column=len(FLOW_COLUMNS))
    title_cell = ws.cell(row=1, column=1,
                         value=f'End-to-End Data Flow: {mapping.name}')
    title_cell.font = Font(name='Calibri', size=13, bold=True, color='FFFFFF')
    title_cell.fill = PatternFill(start_color='333F4F', end_color='333F4F', fill_type='solid')
    title_cell.alignment = Alignment(horizontal='center', vertical='center')

    # ---- column headers (row 2) ----
    header_row = 2
    for col_idx, header in enumerate(FLOW_COLUMNS, 1):
        cell = ws.cell(row=header_row, column=col_idx, value=header)
        cell.fill = HEADER_FILL
        cell.font = HEADER_FONT
        cell.border = THIN_BORDER
        cell.alignment = Alignment(horizontal='center', vertical='center', wrap_text=True)

    # ---- data rows ----
    topo_order = mapping.topological_order()
    row = header_row + 1
    step = 0

    for tname in topo_order:
        t = mapping.get_transformation_by_name(tname)
        if t is None:
            continue
        ttype = mapping.identify_type(t)
        step += 1

        feeds_from = ', '.join(mapping.get_upstream(tname)) or '—'
        feeds_to = ', '.join(mapping.get_downstream(tname)) or '—'

        # Physical table / connection
        phys = ''
        if ttype == 'SOURCE':
            src_table = mapping.get_primary_source_table(t)
            conn = mapping.get_connection_info(t)
            phys = f'{src_table}\nConn: $${conn.get("parameter","")} ({conn.get("resolved","")})\nType: {conn.get("connectionType","")}'
        elif ttype == 'TARGET':
            tgt_table = mapping.get_target_table(t)
            conn = mapping.get_connection_info(t)
            phys = f'{tgt_table}\nConn: $${conn.get("parameter","")} ({conn.get("resolved","")})\nType: {conn.get("connectionType","")}'

        # Key logic
        key_logic = _build_key_logic(mapping, t, ttype)

        # Input / output fields
        fields = t.get('fields', [])
        expr_fields = []      # fields that carry expressions
        passthru_fields = []   # simple passthrough

        for f in fields:
            expr = f.get('expression', '')
            eft = f.get('expFieldType', '')
            if expr:
                expr_fields.append(f)
            else:
                passthru_fields.append(f)

        # Build human-readable lists
        input_field_names = _get_input_field_names(mapping, t, ttype)
        output_field_names = [f['name'] for f in fields]

        idmc_expr_lines = []
        sql_expr_lines = []
        for f in expr_fields:
            eft = f.get('expFieldType', '')
            tag = f'[{eft}] ' if eft else ''
            idmc_expr_lines.append(f'{f["name"]} {tag}= {f.get("expression","")}')
            sql_expr_lines.append(f'{f["name"]} = {idmc_expr_to_sql(f.get("expression",""))}')

        row_data = [
            step,
            tname,
            ttype,
            feeds_from,
            feeds_to,
            phys,
            key_logic,
            '\n'.join(input_field_names),
            '\n'.join(output_field_names),
            '\n'.join(idmc_expr_lines) if idmc_expr_lines else '— (all passthrough)',
            '\n'.join(sql_expr_lines) if sql_expr_lines else '— (all passthrough)',
        ]

        type_fill = TYPE_FILLS.get(ttype)
        for col_idx, value in enumerate(row_data, 1):
            cell = ws.cell(row=row, column=col_idx, value=value)
            cell.font = DATA_FONT
            cell.border = THIN_BORDER
            cell.alignment = Alignment(vertical='top', wrap_text=True)
            if type_fill:
                cell.fill = type_fill

        row += 1

    # ---- column widths ----
    col_widths = [6, 32, 14, 32, 32, 50, 70, 45, 45, 65, 65]
    for i, w in enumerate(col_widths, 1):
        ws.column_dimensions[openpyxl.utils.get_column_letter(i)].width = w

    # Freeze header
    ws.freeze_panes = 'A3'

    logger.info(f'  Wrote {step} steps to Data_Flow sheet')


def _build_key_logic(mapping, t, ttype):
    """Compose the 'Key Logic' cell for a transformation."""
    parts = []

    if ttype == 'SOURCE':
        query = mapping.get_custom_query_resolved(t)
        if query:
            parts.append(query)

    elif ttype == 'TARGET':
        adv = {p['name']: p.get('value', '') for p in t.get('advancedProperties', [])}
        mode = t.get('fieldMappingMode', '')
        if mode:
            parts.append(f'Field Mapping Mode: {mode}')
        for lbl in ('Pre SQL', 'Post SQL', 'Update Override'):
            val = adv.get(lbl, '')
            if val:
                parts.append(f'{lbl}: {val}')

    elif ttype == 'JOINER':
        jtype = t.get('joinType', '')
        sql_jtype = {
            'Master Outer Join': 'LEFT OUTER JOIN',
            'Detail Outer Join': 'RIGHT OUTER JOIN',
            'Full Outer Join': 'FULL OUTER JOIN',
            'Normal Join': 'INNER JOIN',
        }.get(jtype, jtype)
        parts.append(f'Join Type: {sql_jtype}')
        for jc in t.get('joinConditions', []):
            parts.append(f'  ON {jc.get("leftOperand","")} {jc.get("operator","=")} {jc.get("rightOperand","")}')
        # Identify master / detail groups
        groups = t.get('groups', [])
        for g in groups:
            gname = g if isinstance(g, str) else g.get('name', '')
            if gname:
                parts.append(f'Group: {gname}')

    elif ttype == 'ROUTER':
        for fc in t.get('groupFilterConditions', []):
            parts.append(f'Group [{fc.get("name","")}]: {fc.get("advancedFilterCondition","")}')

    elif ttype == 'FILTER':
        for fc in t.get('filterConditions', []):
            parts.append(f'{fc.get("fieldName","")} {fc.get("operator","")} {fc.get("filterValue","")}')
        # Also check advancedFilterCondition at the transformation level
        adv_fc = t.get('advancedFilterCondition', '')
        if adv_fc:
            parts.append(f'Advanced: {adv_fc}')

    elif ttype == 'SORTER':
        mode = t.get('sorterMode', '')
        if mode:
            parts.append(f'Mode: {mode}')
        for se in t.get('sortEntries', []):
            direction = 'ASC' if se.get('ascending', True) else 'DESC'
            parts.append(f'{se.get("fieldName","")} {direction}')

    elif ttype == 'UNION':
        for ig in t.get('inputGroups', []):
            ig_name = ig.get('name', '')
            fm_fields = ig.get('fieldMapping', {}).get('fields', [])
            if fm_fields:
                mapped = ', '.join(f.get('name', '') for f in fm_fields[:8])
                suffix = '...' if len(fm_fields) > 8 else ''
                parts.append(f'Input Group [{ig_name}]: {mapped}{suffix}')
            else:
                parts.append(f'Input Group [{ig_name}]')

    elif ttype == 'AGGREGATOR':
        group_by = [f['name'] for f in t.get('fields', []) if not f.get('expression')]
        agg_fields = [f for f in t.get('fields', []) if f.get('expression')]
        if group_by:
            parts.append(f'GROUP BY: {", ".join(group_by)}')
        for af in agg_fields:
            parts.append(f'{af["name"]} = {af.get("expression","")}')

    return '\n'.join(parts) if parts else '— (passthrough / expression only)'


def _get_input_field_names(mapping, t, ttype):
    """Determine the list of input field names for a transformation."""
    if ttype == 'SOURCE':
        # Input is the source table columns; use fields from dataAdapter.object.fields if available
        da_fields = t.get('dataAdapter', {}).get('object', {}).get('fields', [])
        if da_fields:
            return [f.get('name', '') for f in da_fields]
        # Fallback: same as output fields
        return [f'(source) {f["name"]}' for f in t.get('fields', [])]

    if ttype == 'TARGET':
        # Input = what the upstream feeds into this target
        mm = mapping.get_target_manual_mappings(t)
        if mm:
            return [f'{tgt_fld} <- {src_fld}' for tgt_fld, src_fld in mm.items()]
        return [f['name'] for f in t.get('fields', [])]

    # For other types, input = union of upstream output fields
    upstreams = mapping.get_upstream(t['name'])
    input_names = []
    seen = set()
    for up in upstreams:
        up_t = mapping.get_transformation_by_name(up)
        if up_t:
            for f in up_t.get('fields', []):
                eft = f.get('expFieldType', '')
                if eft == 'VARIABLE':
                    continue
                if f['name'] not in seen:
                    input_names.append(f['name'])
                    seen.add(f['name'])
    return input_names if input_names else [f['name'] for f in t.get('fields', [])]


# ---------------------------------------------------------------------------
# Generator (integrates with build_all.py framework)
# ---------------------------------------------------------------------------

class STTMGenerator(BaseGenerator):
    """Generates STTM Excel workbooks from IDMC .bin and .prm files."""

    def __init__(self):
        super().__init__(plans_dir=str(PROJECT_ROOT / 'plans'), output_dir=str(PROJECT_ROOT / 'output'))
        self.input_dir = PROJECT_ROOT / 'inputs'

    def discover_input_pairs(self):
        """Find .bin files and match them with .prm/.param files.
        Returns list of (bin_path, [param_path, ...]) tuples.
        Multiple param files are merged (later files override earlier ones)."""
        bin_files = sorted(self.input_dir.glob('*.bin'))
        param_files = list(self.input_dir.glob('*.prm')) + list(self.input_dir.glob('*.param'))

        pairs = []
        for bf in bin_files:
            stem = bf.stem.lower()
            matched = []
            if stem.startswith('gmad_'):
                for pf in param_files:
                    if 'gmad' in pf.stem.lower():
                        matched = [pf]
                        break
            elif stem.startswith('pdds_'):
                for pf in param_files:
                    if 'pdds' in pf.stem.lower():
                        matched = [pf]
                        break
            elif stem.startswith('ivr_'):
                # Merge EDM_CSX (base) + EDM_CSX_IvrCallLogs (specific overrides)
                base = None
                specific = None
                for pf in param_files:
                    pf_lower = pf.stem.lower()
                    if 'ivrcalllogs' in pf_lower or ('ivr' in pf_lower and 'csx' in pf_lower):
                        specific = pf
                    elif 'csx' in pf_lower and 'ivr' not in pf_lower:
                        base = pf
                matched = [p for p in [base, specific] if p]
            if not matched:
                # Try EDM_CSX as a general fallback for non-finance mappings
                for pf in param_files:
                    if 'csx' in pf.stem.lower() and 'ivr' not in pf.stem.lower():
                        matched = [pf]
                        break
            if not matched and param_files:
                matched = [param_files[0]]
            if matched:
                pairs.append((bf, matched))
            else:
                self.logger.warning(f'No parameter file found for {bf.name}, skipping')
        return pairs

    def generate(self):
        pairs = self.discover_input_pairs()
        self.logger.info(f'Found {len(pairs)} .bin/param pairs to process')

        for bin_path, prm_paths in pairs:
            prm_names = ' + '.join(p.name for p in prm_paths)
            self.logger.info(f'Processing: {bin_path.name} with {prm_names}')
            try:
                self._generate_sttm(bin_path, prm_paths)
            except Exception as e:
                self.logger.error(f'Failed to process {bin_path.name}: {e}')
                import traceback
                traceback.print_exc()

    def _generate_sttm(self, bin_path, prm_paths):
        mapping = IDMCMapping(bin_path, prm_paths)
        self.logger.info(f'  Mapping: {mapping.name}')
        self.logger.info(f'  Description: {mapping.description}')

        targets = mapping.get_targets()
        sources = mapping.get_sources()
        self.logger.info(f'  Sources: {len(sources)}, Targets: {len(targets)}')

        if not targets:
            self.logger.warning(f'  No targets found in {bin_path.name}, skipping')
            return

        # Create workbook
        wb = openpyxl.Workbook()

        # Index sheet
        ws_index = wb.active
        ws_index.title = 'Index'

        load_type = mapping.detect_load_type()
        index_entries = []
        for idx, tgt in enumerate(targets, 1):
            tgt_table = mapping.get_target_table(tgt)
            tgt_name = tgt_table.split('.')[-1] if tgt_table else tgt['name']
            src_tables = [mapping.get_primary_source_table(s) for s in sources]
            index_entries.append([
                idx,                              # #
                tgt_name,                         # Index
                load_type,                        # Table Load Type
                '',                               # Table Refresh Frequency
                '',                               # Table Load SLA
                ', '.join(src_tables),            # Source System Name
                '',                               # Comments
                'Y',                              # STTM
                '',                               # Project Teams
                '',                               # Owner
            ])

        write_index_sheet(ws_index, index_entries)

        # Version History sheet
        ws_version = wb.create_sheet('Version History')
        write_version_history_sheet(ws_version)

        # Summary sheet
        ws_summary = wb.create_sheet('Summary')
        write_summary_sheet(ws_summary, mapping, self.logger)

        # STTM sheet per target (before Lookup/Transformation/Data_Flow)
        for tgt in targets:
            tgt_table = mapping.get_target_table(tgt)
            tgt_name = tgt_table.split('.')[-1] if tgt_table else tgt['name']
            # Excel sheet name max 31 chars
            sheet_name = tgt_name[:31]
            ws = wb.create_sheet(sheet_name)
            field_count = write_sttm_sheet(ws, mapping, tgt, self.logger)
            self.logger.info(f'  Wrote {field_count} fields to sheet: {sheet_name}')

        # Lookup_Definitions sheet
        ws_lookup = wb.create_sheet('Lookup_Definitions')
        write_lookup_sheet(ws_lookup, mapping, self.logger)

        # Transformation_Logic sheet
        ws_txfm = wb.create_sheet('Transformation_Logic')
        write_transformation_sheet(ws_txfm, mapping, self.logger)

        # Data_Flow sheet (end-to-end pipeline view)
        ws_flow = wb.create_sheet('Data_Flow')
        write_data_flow_sheet(ws_flow, mapping, self.logger)

        # Save
        output_name = f'{bin_path.stem}_sttm.xlsx'
        output_path = Path(self.output_dir) / output_name
        output_path.parent.mkdir(parents=True, exist_ok=True)
        wb.save(str(output_path))
        self.logger.info(f'  STTM saved: {output_path}')


def main():
    logger = setup_logging('generate_sttm', log_dir=PROJECT_ROOT / 'thoughts' / 'logs')
    logger.info('=' * 60)
    logger.info('STTM Generator - Starting')
    logger.info('=' * 60)

    generator = STTMGenerator()
    generator.generate()

    logger.info('=' * 60)
    logger.info('STTM Generator - Complete')
    logger.info('=' * 60)


if __name__ == '__main__':
    main()
