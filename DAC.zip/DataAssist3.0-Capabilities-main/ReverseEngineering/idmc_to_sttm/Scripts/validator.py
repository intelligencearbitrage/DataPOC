#!/usr/bin/env python3
"""
STTM Validator — Agentic layer that compares generated STTM workbooks
against source .bin / .prm / .param files and produces a structured
validation report (YAML).

Extends BaseValidator and reuses helpers from test_sttm_validation.py.

Usage:
    python scripts/validator.py
    python scripts/validator.py --output-file output/ivr_party_cnt_role_sttm.xlsx
    python scripts/validator.py --dry-run
"""

import argparse
import json
import re
import sys
from pathlib import Path
from typing import Any, Dict, List, Optional, Set

import openpyxl

# Ensure scripts/ is importable
SCRIPTS_DIR = Path(__file__).resolve().parent
PROJECT_ROOT = SCRIPTS_DIR.parent.parent
sys.path.insert(0, str(SCRIPTS_DIR))

from base_validator import BaseValidator
from utils import setup_logging, save_yaml, get_timestamp

from prompts import (  # noqa: F401 — imported for auditability
    VALIDATOR_SYSTEM_PROMPT,
    VALIDATOR_COMPARISON_PROMPT,
    VALIDATOR_SOURCE_COL_PROMPT,
    VALIDATOR_TRANSFORM_LOGIC_PROMPT,
)

INPUTS_DIR = PROJECT_ROOT / 'inputs'
OUTPUT_DIR = PROJECT_ROOT / 'output'
LOG_DIR = PROJECT_ROOT / 'thoughts' / 'logs' / 'agentic'

# Known IDMC field name prefixes that should be stripped
IDMC_PREFIXES = ('o_', 'exp_', 'e_', 'ch_', 'of_', 'change_')


# ---------------------------------------------------------------------------
# Helpers (lightweight, no dependency on generate_sttm internals)
# ---------------------------------------------------------------------------

def parse_prm(prm_path: Path) -> Dict[str, str]:
    """Parse a .prm/.param file and return Global-section parameters."""
    params: Dict[str, str] = {}
    with open(prm_path, 'r') as f:
        section = 'Global'
        for line in f:
            line = line.strip()
            if not line or line.startswith('#'):
                continue
            if line.startswith('['):
                section = line[:line.rfind(']') + 1]
                continue
            if '=' in line and section in ('Global', '[Global]'):
                k, v = line.split('=', 1)
                params[k.strip()] = v.strip()
    return params


def find_bin_prm_pairs() -> List[tuple]:
    """Discover .bin → .prm/.param pairings in inputs/."""
    pairs = []
    for bin_path in sorted(INPUTS_DIR.glob('*.bin')):
        stem = bin_path.stem.lower()
        prm_paths: List[Path] = []
        if stem.startswith('gmad'):
            p = INPUTS_DIR / 'finance_GMAD_master.prm'
            if p.exists():
                prm_paths.append(p)
        elif stem.startswith('pdds'):
            p = INPUTS_DIR / 'finance_PDDS_master.prm'
            if p.exists():
                prm_paths.append(p)
        elif stem.startswith('ivr'):
            for name in ('EDM_CSX.param', 'EDM_CSX_IvrCallLogs.param'):
                p = INPUTS_DIR / name
                if p.exists():
                    prm_paths.append(p)
        if not prm_paths:
            p = INPUTS_DIR / 'EDM_CSX.param'
            if p.exists():
                prm_paths.append(p)
        pairs.append((bin_path, prm_paths))
    return pairs


def _load_bin(bin_path: Path) -> Dict[str, Any]:
    """Load an IDMC .bin (JSON) file."""
    with open(bin_path, 'r', encoding='utf-8') as f:
        return json.load(f)


def _identify_type(t: Dict, reverse_graph: Optional[Dict] = None) -> str:
    """Identify transformation type by structural features.

    Detects LOOKUP transformations by naming convention (lkp_*/Lookup*) and
    presence of upstream connections (unlike true SOURCEs which have none).
    """
    name_lower = t.get('name', '').lower()
    if 'dataAdapter' in t:
        da = t['dataAdapter']
        obj = da.get('object', {})
        cq = obj.get('customQuery')
        if cq:
            # Lookups have customQuery + dataAdapter but also upstream connections.
            # True SOURCEs have no upstream. Detect by naming convention first.
            if (name_lower.startswith(('lkp_', 'lookup')) and
                    not name_lower.startswith(('src_', 'source'))):
                return 'LOOKUP'
            # Check upstream connections if reverse_graph provided
            if reverse_graph and reverse_graph.get(t.get('name', '')) and \
                    not name_lower.startswith(('src_', 'source')):
                return 'LOOKUP'
            return 'SOURCE'
        if obj.get('objectName') or t.get('fieldMappingMode'):
            return 'TARGET'
    if t.get('joinConditions'):
        return 'JOINER'
    if t.get('inputGroups'):
        return 'UNION'
    if t.get('groupFilterConditions'):
        return 'ROUTER'
    if t.get('sortEntries'):
        return 'SORTER'
    if t.get('filterConditions'):
        return 'FILTER'
    state = t.get('state', {})
    if 'incrementBy' in state:
        return 'SEQUENCE'
    for fld in t.get('fields', []):
        expr = fld.get('expression', '')
        eft = fld.get('expFieldType', '')
        if expr and any(agg in expr.upper() for agg in ('SUM(', 'COUNT(', 'MAX(', 'MIN(', 'FIRST(', 'LAST(')):
            return 'AGGREGATOR'
        if eft in ('OUTPUT', 'VARIABLE', 'INPUT'):
            return 'EXPRESSION'
    return 'EXPRESSION'


# ---------------------------------------------------------------------------
# Validator
# ---------------------------------------------------------------------------

class STTMValidator(BaseValidator):
    """Validates generated STTM workbooks against source .bin/.prm files."""

    def __init__(self, target_dir: str = 'output', specific_file: Optional[str] = None):
        super().__init__(target_dir=target_dir)
        self.specific_file = specific_file

    def report(self, issues: List[Dict[str, str]]) -> Dict[str, Any]:
        """Generate a validation report using our issue dict format."""
        errors = [i for i in issues if i.get('severity') == 'ERROR']
        warnings = [i for i in issues if i.get('severity') == 'WARNING']
        infos = [i for i in issues if i.get('severity') == 'INFO']

        report = {
            'validation_report': {
                'timestamp': get_timestamp(),
                'validator': self.__class__.__name__,
                'summary': {
                    'total_issues': len(issues),
                    'errors': len(errors),
                    'warnings': len(warnings),
                    'info': len(infos),
                    'passed': len(errors) == 0,
                },
                'issues': issues,
            }
        }

        status = "PASSED" if len(errors) == 0 else "FAILED"
        self.logger.info(
            f"Validation {status}: {len(errors)} errors, "
            f"{len(warnings)} warnings, {len(infos)} info"
        )

        for issue in errors:
            self.logger.error(f"[{issue.get('output_file', '?')}] {issue.get('description', '')}")
        for issue in warnings:
            self.logger.warning(f"[{issue.get('output_file', '?')}] {issue.get('description', '')}")

        return report

    def validate(self) -> List[Dict[str, str]]:
        """Run all validation checks across all STTM workbooks."""
        issues: List[Dict[str, str]] = []
        pairs = find_bin_prm_pairs()

        for bin_path, prm_paths in pairs:
            xlsx_name = f'{bin_path.stem}_sttm.xlsx'
            xlsx_path = OUTPUT_DIR / xlsx_name

            if self.specific_file and xlsx_name != Path(self.specific_file).name:
                continue

            if not xlsx_path.exists():
                issues.append({
                    'id': f'{xlsx_name}-MISSING',
                    'severity': 'ERROR',
                    'category': 'file_existence',
                    'description': f'Expected STTM workbook not found: {xlsx_name}',
                    'source_file': str(bin_path),
                    'output_file': str(xlsx_path),
                })
                continue

            data = _load_bin(bin_path)
            params: Dict[str, str] = {}
            for prm in prm_paths:
                params.update(parse_prm(prm))

            wb = openpyxl.load_workbook(str(xlsx_path))
            issues.extend(self._check_tab_order(wb, xlsx_name, bin_path))
            issues.extend(self._check_data_flow_completeness(wb, data, xlsx_name, bin_path))
            issues.extend(self._check_source_col_prefixes(wb, xlsx_name, bin_path))
            issues.extend(self._check_transformation_logic(wb, xlsx_name, bin_path))
            issues.extend(self._check_schema_qualification(wb, data, params, xlsx_name, bin_path))
            issues.extend(self._check_field_count(wb, data, xlsx_name, bin_path))
            issues.extend(self._check_ext_lake_flag(wb, xlsx_name, bin_path))
            issues.extend(self._check_multi_row_lineage(wb, data, xlsx_name, bin_path))
            issues.extend(self._check_column_to_table(wb, xlsx_name, bin_path))

        return issues

    # -- Individual checks ---------------------------------------------------

    def _check_tab_order(self, wb, xlsx_name: str, bin_path: Path) -> List[Dict]:
        """TC-1: Verify workbook tab order."""
        issues = []
        sheets = wb.sheetnames
        expected_first = ['Index', 'Version History', 'Summary']
        expected_last = ['Lookup_Definitions', 'Transformation_Logic', 'Data_Flow']

        if sheets[:3] != expected_first or sheets[-3:] != expected_last:
            issues.append({
                'id': f'{xlsx_name}-TAB_ORDER',
                'severity': 'ERROR',
                'category': 'tab_order',
                'description': (
                    f'Tab order incorrect. Expected first 3: {expected_first}, '
                    f'last 3: {expected_last}. Got: {sheets}'
                ),
                'source_file': str(bin_path),
                'output_file': xlsx_name,
            })
        return issues

    def _check_data_flow_completeness(self, wb, data: Dict, xlsx_name: str, bin_path: Path) -> List[Dict]:
        """TC-5: Every transformation must appear in Data_Flow."""
        issues = []
        if 'Data_Flow' not in wb.sheetnames:
            issues.append({
                'id': f'{xlsx_name}-NO_DATAFLOW',
                'severity': 'ERROR',
                'category': 'data_flow',
                'description': 'Data_Flow tab missing from workbook',
                'source_file': str(bin_path),
                'output_file': xlsx_name,
            })
            return issues

        ws = wb['Data_Flow']
        df_names = set()
        for row in range(3, ws.max_row + 1):
            val = ws.cell(row, 2).value
            if val:
                df_names.add(val.strip())

        bin_names = {t['name'] for t in data.get('content', {}).get('transformations', [])}
        missing = bin_names - df_names
        if missing:
            issues.append({
                'id': f'{xlsx_name}-DF_MISSING_TRANSFORMS',
                'severity': 'ERROR',
                'category': 'data_flow',
                'description': f'{len(missing)} transformation(s) missing from Data_Flow: {sorted(missing)[:5]}',
                'source_file': str(bin_path),
                'output_file': xlsx_name,
            })
        return issues

    def _check_source_col_prefixes(self, wb, xlsx_name: str, bin_path: Path) -> List[Dict]:
        """TC-NEW: Source Column Name must not have IDMC prefixes."""
        issues = []
        skip_tabs = {'Index', 'Version History', 'Summary',
                     'Lookup_Definitions', 'Transformation_Logic', 'Data_Flow'}
        prefixed_fields = []

        for sn in wb.sheetnames:
            if sn in skip_tabs:
                continue
            ws = wb[sn]
            for row in range(7, ws.max_row + 1):
                field = ws.cell(row, 3).value
                src_col = ws.cell(row, 8).value or ''
                if not field:
                    continue
                if any(src_col.lower().startswith(p) for p in IDMC_PREFIXES):
                    prefixed_fields.append(f'{sn}/{field}: {src_col}')

        if prefixed_fields:
            issues.append({
                'id': f'{xlsx_name}-SRC_COL_PREFIX',
                'severity': 'ERROR',
                'category': 'source_column_name',
                'description': (
                    f'{len(prefixed_fields)} field(s) have IDMC-prefixed source '
                    f'column names: {prefixed_fields[:5]}'
                ),
                'source_file': str(bin_path),
                'output_file': xlsx_name,
            })
        return issues

    def _check_transformation_logic(self, wb, xlsx_name: str, bin_path: Path) -> List[Dict]:
        """TC-NEW: Source Transformational Rule/Logic must not all be 'Direct Move'."""
        issues = []
        skip_tabs = {'Index', 'Version History', 'Summary',
                     'Lookup_Definitions', 'Transformation_Logic', 'Data_Flow'}

        for sn in wb.sheetnames:
            if sn in skip_tabs:
                continue
            ws = wb[sn]
            total = 0
            direct_move = 0
            for row in range(7, ws.max_row + 1):
                field = ws.cell(row, 3).value
                rule = ws.cell(row, 10).value or ''
                if not field:
                    continue
                # Skip _sk and edh_ fields as they have special overrides
                if field.lower().endswith('_sk') or field.lower().startswith('edh_'):
                    continue
                total += 1
                if rule == 'Direct Move from source query' or rule == '':
                    direct_move += 1

            if total > 0 and direct_move == total:
                issues.append({
                    'id': f'{xlsx_name}-{sn}-ALL_DIRECT_MOVE',
                    'severity': 'WARNING',
                    'category': 'transformation_logic',
                    'description': (
                        f'Sheet "{sn}": ALL {total} non-audit/non-SK fields show '
                        f'"Direct Move" — expected some computed expressions'
                    ),
                    'source_file': str(bin_path),
                    'output_file': xlsx_name,
                })
        return issues

    def _check_schema_qualification(self, wb, data: Dict, params: Dict,
                                     xlsx_name: str, bin_path: Path) -> List[Dict]:
        """TC-3: Source tables must be schema-qualified, no $$variables."""
        issues = []
        skip_tabs = {'Index', 'Version History', 'Summary',
                     'Lookup_Definitions', 'Transformation_Logic', 'Data_Flow'}
        unresolved = []
        no_schema = []

        for sn in wb.sheetnames:
            if sn in skip_tabs:
                continue
            ws = wb[sn]
            for row in range(7, ws.max_row + 1):
                src_table = ws.cell(row, 7).value or ''
                if not src_table.strip():
                    continue
                for table_line in src_table.split('\n'):
                    table_line = table_line.strip()
                    if not table_line:
                        continue
                    if '$$' in table_line:
                        unresolved.append(table_line)
                    elif '.' not in table_line:
                        no_schema.append(table_line)

        if unresolved or no_schema:
            issues.append({
                'id': f'{xlsx_name}-SCHEMA_QUAL',
                'severity': 'ERROR',
                'category': 'schema_qualification',
                'description': (
                    f'Unresolved: {unresolved[:3]}, No schema: {no_schema[:3]}'
                ),
                'source_file': str(bin_path),
                'output_file': xlsx_name,
            })
        return issues

    def _check_field_count(self, wb, data: Dict, xlsx_name: str, bin_path: Path) -> List[Dict]:
        """TC-7: Target field count in STTM tab matches .bin.

        With multi-row lineage, the STTM tab may have more rows than target
        fields (one row per source pair). Count unique target field names.
        """
        issues = []
        # Build reverse graph for LOOKUP detection
        reverse_graph = self._build_reverse_graph(data)
        targets = [t for t in data.get('content', {}).get('transformations', [])
                    if _identify_type(t, reverse_graph) == 'TARGET']

        skip_tabs = {'Index', 'Version History', 'Summary',
                     'Lookup_Definitions', 'Transformation_Logic', 'Data_Flow'}
        sttm_tabs = [s for s in wb.sheetnames if s not in skip_tabs]

        for i, tgt in enumerate(targets):
            expected = len(tgt.get('fields', []))
            if i < len(sttm_tabs):
                ws = wb[sttm_tabs[i]]
                # Count unique target field names (multi-row lineage means
                # multiple rows per field)
                unique_fields: Set[str] = set()
                for r in range(7, ws.max_row + 1):
                    val = ws.cell(r, 3).value
                    if val:
                        unique_fields.add(val.strip())
                actual = len(unique_fields)
                if actual != expected:
                    issues.append({
                        'id': f'{xlsx_name}-FIELD_COUNT-{sttm_tabs[i]}',
                        'severity': 'WARNING',
                        'category': 'field_count',
                        'description': (
                            f'Sheet "{sttm_tabs[i]}": expected {expected} unique target fields, '
                            f'got {actual}'
                        ),
                        'source_file': str(bin_path),
                        'output_file': xlsx_name,
                    })
        return issues

    @staticmethod
    def _build_reverse_graph(data: Dict) -> Dict[str, List[str]]:
        """Build reverse graph (child→parents) from .bin links for LOOKUP detection."""
        reverse: Dict[str, List[str]] = {}
        for link in data.get('content', {}).get('links', []):
            src = link.get('source', '')
            tgt = link.get('target', '')
            if tgt not in reverse:
                reverse[tgt] = []
            reverse[tgt].append(src)
        return reverse

    def _check_multi_row_lineage(self, wb, data: Dict, xlsx_name: str, bin_path: Path) -> List[Dict]:
        """TC-14: Multi-row lineage — fields with multiple sources should have multiple rows."""
        issues = []
        skip_tabs = {'Index', 'Version History', 'Summary',
                     'Lookup_Definitions', 'Transformation_Logic', 'Data_Flow'}
        empty_source_fields = []

        for sn in wb.sheetnames:
            if sn in skip_tabs:
                continue
            ws = wb[sn]
            for row in range(7, ws.max_row + 1):
                field = ws.cell(row, 3).value
                src_tbl = ws.cell(row, 7).value or ''
                src_col = ws.cell(row, 8).value or ''
                if not field:
                    continue
                if not src_tbl.strip() and not src_col.strip():
                    # Skip audit/SK fields
                    if not (field.lower().endswith('_sk') or field.lower().startswith('edh_')):
                        empty_source_fields.append(f'{sn}/{field}')

        if len(empty_source_fields) > 10:
            issues.append({
                'id': f'{xlsx_name}-EMPTY_SOURCE_LINEAGE',
                'severity': 'WARNING',
                'category': 'multi_row_lineage',
                'description': (
                    f'{len(empty_source_fields)} non-audit fields have empty source table/column: '
                    f'{empty_source_fields[:5]}'
                ),
                'source_file': str(bin_path),
                'output_file': xlsx_name,
            })
        return issues

    def _check_column_to_table(self, wb, xlsx_name: str, bin_path: Path) -> List[Dict]:
        """TC-15: Source table names should not be transformation aliases."""
        issues = []
        skip_tabs = {'Index', 'Version History', 'Summary',
                     'Lookup_Definitions', 'Transformation_Logic', 'Data_Flow'}
        alias_tables = []

        for sn in wb.sheetnames:
            if sn in skip_tabs:
                continue
            ws = wb[sn]
            for row in range(7, ws.max_row + 1):
                src_tbl = ws.cell(row, 7).value or ''
                if not src_tbl.strip():
                    continue
                # Flag tables that look like IDMC transformation names
                # (e.g., SRC_xxx, lkp_xxx, Dim_Prty without schema)
                for tbl in src_tbl.split('\n'):
                    tbl = tbl.strip()
                    if not tbl:
                        continue
                    if tbl.lower().startswith(('src_', 'lkp_', 'exp_', 'agg_', 'flt_', 'jnr_', 'srt_')):
                        alias_tables.append(f'{sn}/R{row}: {tbl}')

        if alias_tables:
            issues.append({
                'id': f'{xlsx_name}-ALIAS_TABLE_NAMES',
                'severity': 'WARNING',
                'category': 'column_to_table',
                'description': (
                    f'{len(alias_tables)} source table(s) look like IDMC transformation names: '
                    f'{alias_tables[:5]}'
                ),
                'source_file': str(bin_path),
                'output_file': xlsx_name,
            })
        return issues

    def _check_ext_lake_flag(self, wb, xlsx_name: str, bin_path: Path) -> List[Dict]:
        """TC-9: Ext Lake Flag accuracy."""
        issues = []
        if 'Summary' not in wb.sheetnames:
            return issues
        ws = wb['Summary']
        for row in range(2, ws.max_row + 1):
            src_schema = ws.cell(row, 2).value or ''
            flag = ws.cell(row, 6).value or ''
            if not src_schema.strip():
                continue
            expected = 'Y' if 'ext_lake' in src_schema.lower() else 'N'
            if flag != expected:
                issues.append({
                    'id': f'{xlsx_name}-EXT_LAKE-R{row}',
                    'severity': 'WARNING',
                    'category': 'ext_lake_flag',
                    'description': (
                        f'Row {row}: source "{src_schema}" has Ext Lake Flag="{flag}", '
                        f'expected "{expected}"'
                    ),
                    'source_file': str(bin_path),
                    'output_file': xlsx_name,
                })
        return issues


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def main():
    parser = argparse.ArgumentParser(description='STTM Validator (Agentic Layer)')
    parser.add_argument('--output-file', help='Validate a specific output file only')
    parser.add_argument('--dry-run', action='store_true', help='List checks without running')
    args = parser.parse_args()

    logger = setup_logging('validator', log_dir=LOG_DIR)

    if args.dry_run:
        print("Dry run — checks that would be performed:")
        checks = [
            'TC-1: Tab order', 'TC-3: Schema qualification',
            'TC-5: Data_Flow completeness', 'TC-7: Field count (unique target fields)',
            'TC-9: Ext Lake Flag', 'TC-11: Source column prefix check',
            'TC-12: Transformation logic cross-reference',
            'TC-14: Multi-row lineage completeness',
            'TC-15: Column-to-table resolution (no alias tables)',
        ]
        for c in checks:
            print(f"  {c}")
        return 0

    validator = STTMValidator(specific_file=args.output_file)
    issues = validator.validate()
    report = validator.report(issues)

    # Save report
    report_path = LOG_DIR / f'validation_report_{get_timestamp().replace(" ", "_").replace(":", "")}.yaml'
    save_yaml(report, report_path)
    logger.info(f"Report saved: {report_path}")

    # Console summary
    errors = [i for i in issues if i['severity'] == 'ERROR']
    warnings = [i for i in issues if i['severity'] == 'WARNING']
    print(f"\n{'=' * 60}")
    print("AGENTIC VALIDATION SUMMARY")
    print(f"{'=' * 60}")
    print(f"  Errors:   {len(errors)}")
    print(f"  Warnings: {len(warnings)}")
    print(f"  Total:    {len(issues)}")

    if errors:
        print(f"\n{'─' * 60}")
        print("ERRORS:")
        for e in errors:
            print(f"  [{e['category']}] {e['output_file']}: {e['description'][:120]}")

    if warnings:
        print(f"\n{'─' * 60}")
        print("WARNINGS:")
        for w in warnings:
            print(f"  [{w['category']}] {w['output_file']}: {w['description'][:120]}")

    print(f"{'=' * 60}")
    return 1 if errors else 0


if __name__ == '__main__':
    sys.exit(main())
