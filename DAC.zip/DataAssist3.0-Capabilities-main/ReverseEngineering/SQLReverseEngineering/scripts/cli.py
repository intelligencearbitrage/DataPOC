"""
Entry point for the SQL Reverse Engineering toolkit.

Delegates to the full CLI implementation in tools/agent_interface/cli.py.
Run this file directly or invoke as a module:

    python cli.py <command> [options]
    python -m sql_reverse_engineering.cli <command> [options]

Use `python cli.py --help` to list all available commands.
"""

import sys
import os

# Ensure the sql_reverse_engineering package is importable regardless of how this file is invoked.
# This file lives in scripts/; the package lives in scripts/sql_reverse_engineering/.
_here = os.path.dirname(os.path.abspath(__file__))

if _here not in sys.path:
    sys.path.insert(0, _here)

from sql_reverse_engineering.tools.agent_interface.cli import main  # noqa: E402

if __name__ == "__main__":
    main()
