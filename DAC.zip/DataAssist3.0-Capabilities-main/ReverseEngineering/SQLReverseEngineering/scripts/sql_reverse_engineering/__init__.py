"""
SQL Reverse Engineering package.

Provides automated SQL parsing, element extraction, field-level lineage
tracking, and documentation generation via a LangGraph multi-agent pipeline.

Subpackages:
    agents/   - Agentic validation & refinement layer (validator, refiner, prompts)
    tools/    - Core analysis modules (AST, lineage, visualization, etc.)
    schema/   - DDL schema loading and column resolution
"""
