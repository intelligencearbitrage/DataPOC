"""Schema module for loading table schemas from DDL files."""

from .ddl_parser import DDLSchemaLoader

__all__ = ["DDLSchemaLoader"]
