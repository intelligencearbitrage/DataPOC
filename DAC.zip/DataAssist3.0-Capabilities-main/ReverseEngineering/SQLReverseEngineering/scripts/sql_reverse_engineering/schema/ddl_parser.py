"""
DDL Schema Loader module.

Parses DDL files to extract table schemas for accurate column resolution
during lineage extraction.
"""

import sqlglot
from sqlglot import exp
from typing import Dict, List, Optional, Tuple
import glob
import os
import re
from dataclasses import dataclass, field


@dataclass
class ColumnDefinition:
    """Column definition from DDL."""
    name: str
    data_type: str
    is_nullable: bool = True
    default_value: Optional[str] = None
    is_primary_key: bool = False


@dataclass
class TableSchema:
    """Table schema extracted from DDL."""
    name: str
    schema_name: Optional[str] = None
    database_name: Optional[str] = None
    columns: List[ColumnDefinition] = field(default_factory=list)
    primary_key: List[str] = field(default_factory=list)

    def get_column_names(self) -> List[str]:
        """Get list of column names."""
        return [col.name for col in self.columns]

    def get_qualified_name(self) -> str:
        """Get fully qualified table name."""
        parts = [p for p in [self.database_name, self.schema_name, self.name] if p]
        return ".".join(parts)


class DDLSchemaLoader:
    """
    Parse DDL files to extract table schemas for accurate column resolution.
    Supports Teradata, SQL Server, Snowflake, and PostgreSQL DDL syntax.
    """

    def __init__(self, dialect: str = "teradata"):
        """
        Initialize loader.

        Args:
            dialect: SQL dialect for parsing DDL
        """
        self.dialect = dialect
        self.schemas: Dict[str, TableSchema] = {}

    def load_from_directory(self, ddl_directory: str,
                             file_patterns: List[str] = None) -> Dict[str, List[str]]:
        """
        Load schemas from all DDL files in a directory.

        Args:
            ddl_directory: Directory containing DDL files
            file_patterns: Glob patterns for DDL files (default: *.sql, *.ddl, *.txt)

        Returns:
            Dict mapping table names to column lists
        """
        if file_patterns is None:
            file_patterns = ["**/*.sql", "**/*.ddl", "**/*.txt", "**/*.vw"]

        for pattern in file_patterns:
            full_pattern = os.path.join(ddl_directory, pattern)
            for ddl_file in glob.glob(full_pattern, recursive=True):
                try:
                    self.load_from_file(ddl_file)
                except Exception as e:
                    # Log error but continue processing other files
                    print(f"Warning: Error parsing {ddl_file}: {e}")

        return self.get_simple_schema()

    def load_from_file(self, filepath: str) -> Dict[str, TableSchema]:
        """
        Load schemas from a single DDL file.

        Args:
            filepath: Path to DDL file

        Returns:
            Dict of table schemas from this file
        """
        with open(filepath, 'r', encoding='utf-8', errors='ignore') as f:
            ddl_content = f.read()

        return self.load_from_string(ddl_content)

    def load_from_string(self, ddl_content: str) -> Dict[str, TableSchema]:
        """
        Load schemas from DDL string.

        Args:
            ddl_content: DDL content string

        Returns:
            Dict of table schemas
        """
        # Pre-process DDL to handle dialect-specific syntax
        ddl_content = self._preprocess_ddl(ddl_content)

        # Split into individual CREATE statements for reliable parsing.
        # Parsing a huge concatenated file as one blob often fails in SQLGlot
        # and the regex fallback is less accurate.
        create_chunks = re.split(r'(?=CREATE\s+TABLE\s)', ddl_content, flags=re.IGNORECASE)

        for chunk in create_chunks:
            chunk = chunk.strip()
            if not chunk or not re.match(r'CREATE\s+TABLE\s', chunk, re.IGNORECASE):
                continue
            # Isolate just the first statement (up to the first ;)
            semi_idx = chunk.find(';')
            if semi_idx > 0:
                chunk = chunk[:semi_idx + 1]
            try:
                stmt = sqlglot.parse_one(chunk, read=self.dialect)
                if isinstance(stmt, exp.Create):
                    schema = self._parse_create_table(stmt)
                    if schema:
                        self.schemas[schema.name.upper()] = schema
            except Exception:
                # Per-statement regex fallback
                self._parse_with_regex(chunk)

        return self.schemas

    def _preprocess_ddl(self, ddl: str) -> str:
        """
        Preprocess DDL to normalize dialect-specific syntax.

        Args:
            ddl: Raw DDL string

        Returns:
            Preprocessed DDL
        """
        # Remove comments
        ddl = re.sub(r'--.*?(?:\n|$)', '\n', ddl)
        ddl = re.sub(r'/\*.*?\*/', '', ddl, flags=re.DOTALL)

        # Strip combined-schema file artifacts:
        # - Banner lines (====...), "Request Text" headers
        # - Wrapping double quotes around entire CREATE statements
        ddl = re.sub(r'^[=]{3,}\s*$', '', ddl, flags=re.MULTILINE)
        ddl = re.sub(r'^\s*"Request Text"\s*$', '', ddl, flags=re.MULTILINE)
        # Unwrap quoted DDL: "CREATE ... ;" → CREATE ... ;
        ddl = re.sub(r'"(CREATE\s)', r'\1', ddl, flags=re.IGNORECASE)
        ddl = re.sub(r';\s*"\s*$', ';', ddl, flags=re.MULTILINE)

        # Remove Teradata-specific CREATE SET/MULTISET TABLE
        ddl = re.sub(r'CREATE\s+(?:SET|MULTISET)\s+TABLE',
                     'CREATE TABLE', ddl, flags=re.IGNORECASE)

        # Remove VOLATILE keyword
        ddl = re.sub(r'CREATE\s+VOLATILE\s+TABLE',
                     'CREATE TABLE', ddl, flags=re.IGNORECASE)

        # Remove table options between table name and opening paren
        # This pattern matches: table_name ,FALLBACK, NO BEFORE JOURNAL, etc. (
        # and replaces with: table_name (
        ddl = re.sub(
            r'(CREATE\s+TABLE\s+[\w.]+)\s*,?\s*'
            r'(?:,?\s*(?:NO\s+)?(?:FALLBACK|BEFORE\s+JOURNAL|AFTER\s+JOURNAL|'
            r'CHECKSUM\s*=\s*\w+|DEFAULT\s+MERGEBLOCKRATIO|MAP\s*=\s*\w+)\s*)*'
            r'\s*\(',
            r'\1 (',
            ddl,
            flags=re.IGNORECASE | re.DOTALL
        )

        # Remove CHARACTER SET clauses
        ddl = re.sub(r'\s+CHARACTER\s+SET\s+(?:LATIN|UNICODE)(?:\s+(?:NOT\s+)?CASESPECIFIC)?',
                     '', ddl, flags=re.IGNORECASE)

        # Remove FORMAT clauses for dates
        ddl = re.sub(r"\s+FORMAT\s+'[^']*'", '', ddl, flags=re.IGNORECASE)

        # Remove BYTEINT and replace with SMALLINT
        ddl = re.sub(r'\bBYTEINT\b', 'SMALLINT', ddl, flags=re.IGNORECASE)

        # Remove LOCK ROW FOR ACCESS
        ddl = re.sub(r'LOCK\s+ROW\s+FOR\s+ACCESS', '', ddl, flags=re.IGNORECASE)

        # Remove LOCKING ROW FOR ACCESS
        ddl = re.sub(r'LOCKING\s+ROW\s+FOR\s+ACCESS', '', ddl, flags=re.IGNORECASE)

        # Remove Teradata PRIMARY INDEX clause (including column list)
        ddl = re.sub(r'\)\s*PRIMARY\s+INDEX\s*\([^)]*\)', ')', ddl, flags=re.IGNORECASE)
        ddl = re.sub(r'\)\s*UNIQUE\s*PRIMARY\s+INDEX\s*\([^)]*\)', ')', ddl, flags=re.IGNORECASE)
        ddl = re.sub(r'\)\s*NO\s+PRIMARY\s+INDEX', ')', ddl, flags=re.IGNORECASE)

        # Remove Teradata PARTITION BY clause (complex nested structure)
        # First, find and remove PARTITION BY with its nested RANGE_N expressions
        ddl = re.sub(r'\s*PARTITION\s+BY\s*\([^;]+\)\s*;', ';', ddl, flags=re.IGNORECASE)

        return ddl

    def _parse_create_table(self, stmt: exp.Create) -> Optional[TableSchema]:
        """
        Parse a CREATE TABLE statement.

        Args:
            stmt: SQLGlot Create expression

        Returns:
            TableSchema or None
        """
        if not isinstance(stmt, exp.Create):
            return None

        # Check if it's a table creation
        kind = stmt.args.get('kind')
        if kind and str(kind).upper() != 'TABLE':
            return None

        # Get table name - handle both Table and Schema expressions
        table_expr = stmt.this
        if not table_expr:
            return None

        # If stmt.this is a Schema expression, get the Table from it
        if isinstance(table_expr, exp.Schema):
            table = table_expr.this
        else:
            table = table_expr

        if not table:
            return None

        table_name = table.name if hasattr(table, 'name') else str(table)
        schema_name = table.db if hasattr(table, 'db') and table.db else None
        database_name = table.catalog if hasattr(table, 'catalog') and table.catalog else None

        # Get columns
        columns = []
        primary_key = []

        # Find column definitions
        for col_def in stmt.find_all(exp.ColumnDef):
            col_name = col_def.this.name if col_def.this else None
            if not col_name:
                continue

            data_type = "UNKNOWN"
            if col_def.kind:
                data_type = col_def.kind.sql(dialect=self.dialect)

            is_nullable = True
            is_primary_key = False
            default_value = None

            # Check constraints
            for constraint in col_def.find_all(exp.ColumnConstraint):
                kind = constraint.kind
                if isinstance(kind, exp.NotNullColumnConstraint):
                    is_nullable = False
                elif isinstance(kind, exp.PrimaryKeyColumnConstraint):
                    is_primary_key = True
                    primary_key.append(col_name)

            columns.append(ColumnDefinition(
                name=col_name,
                data_type=data_type,
                is_nullable=is_nullable,
                default_value=default_value,
                is_primary_key=is_primary_key
            ))

        return TableSchema(
            name=table_name,
            schema_name=schema_name,
            database_name=database_name,
            columns=columns,
            primary_key=primary_key
        )

    def _parse_with_regex(self, ddl: str) -> None:
        """
        Fall back to regex-based parsing for non-standard DDL.

        Args:
            ddl: DDL string
        """
        # Pattern to match CREATE TABLE statements
        create_pattern = re.compile(
            r'CREATE\s+(?:OR\s+REPLACE\s+)?TABLE\s+'
            r'(?:IF\s+NOT\s+EXISTS\s+)?'
            r'([^\s(]+)\s*\('
            r'([^;]+?)'
            r'\)',
            re.IGNORECASE | re.DOTALL
        )

        for match in create_pattern.finditer(ddl):
            table_name = match.group(1).strip().strip('"').strip('`')
            columns_def = match.group(2)

            # Parse table name components
            name_parts = table_name.split('.')
            if len(name_parts) == 3:
                database_name, schema_name, table_name = name_parts
            elif len(name_parts) == 2:
                database_name = None
                schema_name, table_name = name_parts
            else:
                database_name = None
                schema_name = None

            # Parse columns
            columns = self._parse_columns_regex(columns_def)

            schema = TableSchema(
                name=table_name,
                schema_name=schema_name,
                database_name=database_name,
                columns=columns
            )

            self.schemas[table_name.upper()] = schema

    def _parse_columns_regex(self, columns_def: str) -> List[ColumnDefinition]:
        """
        Parse column definitions using regex.

        Args:
            columns_def: Column definition string

        Returns:
            List of ColumnDefinition objects
        """
        columns = []

        # Split by commas, but not commas inside parentheses
        depth = 0
        current = []
        parts = []

        for char in columns_def:
            if char == '(':
                depth += 1
            elif char == ')':
                depth -= 1
            elif char == ',' and depth == 0:
                parts.append(''.join(current).strip())
                current = []
                continue
            current.append(char)

        if current:
            parts.append(''.join(current).strip())

        # Column pattern
        col_pattern = re.compile(
            r'^["\']?(\w+)["\']?\s+(\w+(?:\s*\([^)]+\))?)',
            re.IGNORECASE
        )

        for part in parts:
            part = part.strip()

            # Skip constraints
            if part.upper().startswith(('PRIMARY', 'FOREIGN', 'UNIQUE', 'CHECK', 'CONSTRAINT', 'INDEX')):
                continue

            match = col_pattern.match(part)
            if match:
                col_name = match.group(1)
                data_type = match.group(2)

                is_nullable = 'NOT NULL' not in part.upper()
                is_primary_key = 'PRIMARY KEY' in part.upper()

                columns.append(ColumnDefinition(
                    name=col_name,
                    data_type=data_type,
                    is_nullable=is_nullable,
                    is_primary_key=is_primary_key
                ))

        return columns

    def get_schema(self, table_name: str) -> Optional[TableSchema]:
        """
        Get schema for a specific table.

        Args:
            table_name: Table name (case-insensitive)

        Returns:
            TableSchema or None
        """
        return self.schemas.get(table_name.upper())

    def get_columns(self, table_name: str) -> List[str]:
        """
        Get column names for a table.

        Args:
            table_name: Table name

        Returns:
            List of column names
        """
        schema = self.get_schema(table_name)
        return schema.get_column_names() if schema else []

    def get_simple_schema(self) -> Dict[str, List[str]]:
        """
        Get simplified schema dict for SQLGlot lineage.

        Returns:
            Dict mapping table names to column name lists
        """
        return {
            name: schema.get_column_names()
            for name, schema in self.schemas.items()
        }

    def get_all_tables(self) -> List[str]:
        """
        Get all loaded table names.

        Returns:
            List of table names
        """
        return list(self.schemas.keys())

    def merge(self, other: 'DDLSchemaLoader') -> None:
        """
        Merge another schema loader's schemas into this one.

        Args:
            other: Another DDLSchemaLoader
        """
        self.schemas.update(other.schemas)

    def to_dict(self) -> Dict[str, Dict]:
        """
        Convert schemas to dictionary format.

        Returns:
            Dictionary representation of all schemas
        """
        return {
            name: {
                'name': schema.name,
                'schema_name': schema.schema_name,
                'database_name': schema.database_name,
                'columns': [
                    {
                        'name': col.name,
                        'data_type': col.data_type,
                        'is_nullable': col.is_nullable,
                        'is_primary_key': col.is_primary_key
                    }
                    for col in schema.columns
                ],
                'primary_key': schema.primary_key
            }
            for name, schema in self.schemas.items()
        }
