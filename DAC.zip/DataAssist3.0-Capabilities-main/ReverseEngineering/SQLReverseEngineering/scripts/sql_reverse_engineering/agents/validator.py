"""
Lineage Validator - Validates _lineage.csv and _structured.xlsx output
against source SQL stored procedures.

Scans output directories organized per-procedure, compares each pair of
deliverables against the matching source SQL in inputs/.

Produces a structured YAML validation report in thoughts/logs/agentic/.

Usage:
    python -m sql_reverse_engineering.agents.validator
    python -m sql_reverse_engineering.agents.validator --output-dir output/FRY14Q_SP
    python -m sql_reverse_engineering.agents.validator --dry-run
"""

import argparse
import csv
import re
import sys
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

AGENTS_DIR = Path(__file__).resolve().parent
PACKAGE_DIR = AGENTS_DIR.parent
SCRIPTS_DIR = PACKAGE_DIR.parent
PROJECT_ROOT = SCRIPTS_DIR.parent
sys.path.insert(0, str(SCRIPTS_DIR))

from base_validator import BaseValidator
from sql_reverse_engineering.agents.prompts import VALIDATOR_SYSTEM_PROMPT
from utils import get_project_root, get_timestamp, save_yaml, setup_logging

# Expected lineage CSV columns
EXPECTED_LINEAGE_COLUMNS = [
    "Source_Table", "Source_Attribute", "Transformation_Logic",
    "Target_Table", "Target_Attribute", "DML_Operation",
    "Join_Conditions", "Filter_Conditions",
]

# Expected structured XLSX sheets
EXPECTED_XLSX_SHEETS = [
    "Summary", "Column Lineage", "Table Aliases",
    "Join Conditions", "Filter Conditions",
]

# DML patterns to detect in source SQL
DML_PATTERNS = {
    "INSERT_SELECT": re.compile(r"(?i)\bINSERT\s+INTO\s+([\w.]+).*?\bSELECT\b", re.DOTALL),
    "UPDATE_SET": re.compile(r"(?i)\bUPDATE\s+([\w.]+)\s+.*?\bSET\b", re.DOTALL),
    "DELETE": re.compile(r"(?i)\bDELETE\s+FROM\s+([\w.]+)", re.DOTALL),
    "MERGE": re.compile(r"(?i)\bMERGE\s+INTO\s+([\w.]+)", re.DOTALL),
    "SELECT_INTO": re.compile(r"(?i)\bSELECT\b.+?\bINTO\b\s+([\w,\s]+)\s+\bFROM\b", re.DOTALL),
    "CREATE_VOLATILE": re.compile(r"(?i)\bCREATE\s+(?:SET\s+|MULTISET\s+)?VOLATILE\s+TABLE\s+([\w.]+)", re.DOTALL),
}

TABLE_FROM_PATTERN = re.compile(r"(?i)\bFROM\s+([\w.]+)", re.DOTALL)
TABLE_JOIN_PATTERN = re.compile(r"(?i)\bJOIN\s+([\w.]+)", re.DOTALL)
TABLE_INSERT_PATTERN = re.compile(r"(?i)\bINSERT\s+INTO\s+([\w.]+)", re.DOTALL)
TABLE_UPDATE_PATTERN = re.compile(r"(?i)\bUPDATE\s+([\w.]+)", re.DOTALL)
TABLE_MERGE_PATTERN = re.compile(r"(?i)\bMERGE\s+INTO\s+([\w.]+)", re.DOTALL)
WHERE_PATTERN = re.compile(r"(?i)\bWHERE\s+(.+?)(?:\bGROUP\b|\bORDER\b|\bHAVING\b|\bINSERT\b|\bUPDATE\b|\bEND\b|;)", re.DOTALL)
JOIN_ON_PATTERN = re.compile(r"(?i)\bJOIN\s+[\w.]+\s+\w+\s+ON\s+(.+?)(?:\bWHERE\b|\bJOIN\b|\bGROUP\b|\bORDER\b|;|\))", re.DOTALL)


class LineageValidator(BaseValidator):
    """Validates _lineage.csv and _structured.xlsx output files."""

    def __init__(
        self,
        output_dir: str = "output/FRY14Q_SP",
        inputs_dir: str = "inputs",
        knowledgebase_dir: str = "knowledgebase",
        dry_run: bool = False,
    ):
        super().__init__(target_dir=output_dir)
        self.project_root = get_project_root()
        self.output_dir = self.project_root / output_dir
        self.inputs_dir = self.project_root / inputs_dir
        self.knowledgebase_dir = self.project_root / knowledgebase_dir
        self.log_dir = self.project_root / "thoughts" / "logs" / "agentic"
        self.dry_run = dry_run
        self.issues: List[Dict[str, Any]] = []
        self.passed_checks: List[str] = []
        self.issue_counter = 0

    def _next_issue_id(self) -> str:
        self.issue_counter += 1
        return f"V-{self.issue_counter:03d}"

    def _add_issue(
        self, severity: str, category: str, description: str,
        source_file: str = "", output_file: str = "",
    ) -> None:
        if source_file and not (self.project_root / source_file).exists():
            self.logger.warning(f"Skipping issue — source file does not exist: {source_file}")
            return
        if output_file and not (self.project_root / output_file).exists():
            self.logger.warning(f"Skipping issue — output file does not exist: {output_file}")
            return
        self.issues.append({
            "id": self._next_issue_id(), "severity": severity,
            "category": category, "description": description,
            "source_file": source_file, "output_file": output_file,
        })

    def _find_source_sql(self, proc_name: str) -> Optional[Path]:
        """Find the source SQL file matching a procedure name."""
        for sql_file in self.inputs_dir.rglob("*.sql"):
            if sql_file.stem == proc_name:
                return sql_file
        return None

    def _read_csv(self, csv_path: Path) -> Tuple[List[str], List[Dict[str, str]]]:
        rows, headers = [], []
        try:
            with open(csv_path, "r", encoding="utf-8") as f:
                reader = csv.DictReader(f)
                headers = reader.fieldnames or []
                for row in reader:
                    rows.append(row)
        except Exception as e:
            self.logger.error(f"Failed to read CSV {csv_path}: {e}")
        return headers, rows

    def _read_xlsx_sheets(self, xlsx_path: Path) -> Dict[str, List[list]]:
        """Read all sheets from an XLSX file. Returns {sheet_name: [rows]}."""
        sheets: Dict[str, List[list]] = {}
        try:
            import openpyxl
            wb = openpyxl.load_workbook(xlsx_path, read_only=True, data_only=True)
            for name in wb.sheetnames:
                ws = wb[name]
                sheet_rows = []
                for row in ws.iter_rows(values_only=True):
                    sheet_rows.append(list(row))
                sheets[name] = sheet_rows
            wb.close()
        except ImportError:
            self.logger.error("openpyxl not installed — cannot validate XLSX files")
        except Exception as e:
            self.logger.error(f"Failed to read XLSX {xlsx_path}: {e}")
        return sheets

    def _read_sql(self, sql_path: Path) -> str:
        try:
            return sql_path.read_text(encoding="utf-8")
        except Exception as e:
            self.logger.error(f"Failed to read SQL {sql_path}: {e}")
            return ""

    def _normalize_table_name(self, name: str) -> str:
        parts = name.strip().split(".")
        return parts[-1].upper()

    def _extract_tables_from_sql(self, sql_content: str) -> Dict[str, List[str]]:
        tables: Dict[str, List[str]] = {"source_tables": [], "target_tables": [], "volatile_tables": []}
        for match in TABLE_FROM_PATTERN.finditer(sql_content):
            t = match.group(1).strip().rstrip(",;)")
            if t.upper() not in ("SELECT", "SET", "VALUES", "TABLE"):
                tables["source_tables"].append(t)
        for match in TABLE_JOIN_PATTERN.finditer(sql_content):
            tables["source_tables"].append(match.group(1).strip().rstrip(",;)"))
        for match in TABLE_INSERT_PATTERN.finditer(sql_content):
            tables["target_tables"].append(match.group(1).strip())
        for match in TABLE_UPDATE_PATTERN.finditer(sql_content):
            t = match.group(1).strip()
            if t.upper() != "SET":
                tables["target_tables"].append(t)
        for match in TABLE_MERGE_PATTERN.finditer(sql_content):
            tables["target_tables"].append(match.group(1).strip())
        for match in DML_PATTERNS["CREATE_VOLATILE"].finditer(sql_content):
            tables["volatile_tables"].append(match.group(1).strip())
        for key in tables:
            tables[key] = list(dict.fromkeys(tables[key]))
        return tables

    # =========================================================================
    # LINEAGE CSV VALIDATION
    # =========================================================================

    def validate_lineage_csv(
        self, csv_path: Path, sql_path: Path, sql_content: str,
        sql_tables: Dict[str, List[str]],
    ) -> None:
        rel_csv = str(csv_path.relative_to(self.project_root))
        rel_sql = str(sql_path.relative_to(self.project_root))

        headers, rows = self._read_csv(csv_path)

        # Structure check
        if not headers:
            self._add_issue("high", "structural_error", "Lineage CSV is empty or unreadable", output_file=rel_csv)
            return

        missing_cols = [c for c in EXPECTED_LINEAGE_COLUMNS if c not in headers]
        if missing_cols:
            self._add_issue("medium", "schema_mismatch",
                f"Missing expected columns: {', '.join(missing_cols)}",
                output_file=rel_csv)
        else:
            self.passed_checks.append(f"Lineage CSV columns valid: {csv_path.name}")

        if not rows:
            self._add_issue("high", "missing_content", "Lineage CSV has no data rows",
                source_file=rel_sql, output_file=rel_csv)
            return

        self.passed_checks.append(f"Lineage CSV has {len(rows)} rows: {csv_path.name}")

        # Table reference checks
        csv_source_tables = {self._normalize_table_name(r.get("Source_Table", ""))
            for r in rows if r.get("Source_Table", "").strip()}
        csv_target_tables = {self._normalize_table_name(r.get("Target_Table", ""))
            for r in rows if r.get("Target_Table", "").strip()}
        sql_target_norm = {self._normalize_table_name(t) for t in sql_tables["target_tables"]}
        sql_volatile_norm = {self._normalize_table_name(t) for t in sql_tables["volatile_tables"]}

        missing_targets = sql_target_norm - csv_target_tables - sql_volatile_norm
        if missing_targets:
            self._add_issue("high", "missing_content",
                f"SQL target tables missing from lineage CSV: {', '.join(sorted(missing_targets))}",
                source_file=rel_sql, output_file=rel_csv)
        else:
            self.passed_checks.append(f"All SQL targets present in CSV: {csv_path.name}")

        # DML coverage
        dml_types_in_sql = set()
        for op_type, pattern in DML_PATTERNS.items():
            if pattern.search(sql_content):
                dml_types_in_sql.add(op_type)
        csv_dml_values = {r.get("DML_Operation", "").upper() for r in rows}

        if "INSERT_SELECT" in dml_types_in_sql and not any(
            "INSERT" in v or "SELECT" in v or "CREATE VOLATILE" in v for v in csv_dml_values
        ):
            self._add_issue("high", "missing_dml_coverage",
                "Source has INSERT statements but no INSERT mappings in lineage CSV",
                source_file=rel_sql, output_file=rel_csv)

        if "UPDATE_SET" in dml_types_in_sql and not any("UPDATE" in v for v in csv_dml_values):
            self._add_issue("high", "missing_dml_coverage",
                "Source has UPDATE statements but no UPDATE mappings in lineage CSV",
                source_file=rel_sql, output_file=rel_csv)

        if "MERGE" in dml_types_in_sql and not any("MERGE" in v for v in csv_dml_values):
            self._add_issue("high", "missing_dml_coverage",
                "Source has MERGE statements but no MERGE mappings in lineage CSV",
                source_file=rel_sql, output_file=rel_csv)

        # Empty fields
        empty_logic = sum(1 for r in rows if not r.get("Transformation_Logic", "").strip())
        if empty_logic > 0:
            self._add_issue("medium", "empty_field",
                f"{empty_logic} row(s) have empty Transformation_Logic",
                source_file=rel_sql, output_file=rel_csv)
        else:
            self.passed_checks.append(f"All rows have Transformation_Logic: {csv_path.name}")

        empty_src_attr = sum(1 for r in rows if not r.get("Source_Attribute", "").strip())
        empty_tgt_attr = sum(1 for r in rows if not r.get("Target_Attribute", "").strip())
        if empty_src_attr:
            self._add_issue("medium", "empty_field",
                f"{empty_src_attr} row(s) have empty Source_Attribute",
                source_file=rel_sql, output_file=rel_csv)
        if empty_tgt_attr:
            self._add_issue("medium", "empty_field",
                f"{empty_tgt_attr} row(s) have empty Target_Attribute",
                source_file=rel_sql, output_file=rel_csv)

        # Join conditions check
        has_joins_in_sql = bool(JOIN_ON_PATTERN.search(sql_content))
        has_joins_in_csv = any(r.get("Join_Conditions", "").strip() for r in rows)
        if has_joins_in_sql and not has_joins_in_csv:
            self._add_issue("medium", "missing_joins",
                "Source SQL has JOIN conditions but none captured in lineage CSV",
                source_file=rel_sql, output_file=rel_csv)

        # Filter conditions check
        has_where_in_sql = bool(WHERE_PATTERN.search(sql_content))
        has_filters_in_csv = any(r.get("Filter_Conditions", "").strip() for r in rows)
        if has_where_in_sql and not has_filters_in_csv:
            self._add_issue("medium", "missing_filters",
                "Source SQL has WHERE conditions but none captured in lineage CSV",
                source_file=rel_sql, output_file=rel_csv)

        return rows  # return for cross-check with XLSX

    # =========================================================================
    # STRUCTURED XLSX VALIDATION
    # =========================================================================

    def validate_structured_xlsx(
        self, xlsx_path: Path, sql_path: Path, sql_content: str,
        csv_rows: Optional[List[Dict[str, str]]] = None,
    ) -> None:
        rel_xlsx = str(xlsx_path.relative_to(self.project_root))
        rel_sql = str(sql_path.relative_to(self.project_root))

        sheets = self._read_xlsx_sheets(xlsx_path)
        if not sheets:
            self._add_issue("high", "structural_error",
                "Structured XLSX is empty or unreadable", output_file=rel_xlsx)
            return

        # Check expected sheets exist
        missing_sheets = [s for s in EXPECTED_XLSX_SHEETS if s not in sheets]
        if missing_sheets:
            self._add_issue("medium", "missing_xlsx_sheet",
                f"Missing expected sheets: {', '.join(missing_sheets)}",
                output_file=rel_xlsx)
        else:
            self.passed_checks.append(f"All 5 expected sheets present: {xlsx_path.name}")

        # Validate Column Lineage sheet
        col_lineage = sheets.get("Column Lineage", [])
        if len(col_lineage) <= 1:
            self._add_issue("high", "missing_content",
                "Column Lineage sheet has no data rows",
                source_file=rel_sql, output_file=rel_xlsx)
        else:
            data_rows = len(col_lineage) - 1  # minus header
            self.passed_checks.append(f"Column Lineage has {data_rows} rows: {xlsx_path.name}")

            # Cross-check with CSV row count
            if csv_rows is not None:
                csv_count = len(csv_rows)
                if abs(data_rows - csv_count) > 2:  # allow small variance
                    self._add_issue("medium", "cross_file_mismatch",
                        f"Row count mismatch: lineage CSV has {csv_count} rows, "
                        f"XLSX Column Lineage has {data_rows} rows",
                        source_file=rel_sql, output_file=rel_xlsx)
                else:
                    self.passed_checks.append(
                        f"CSV/XLSX row counts consistent: {xlsx_path.name}")

        # Validate Join Conditions sheet
        join_sheet = sheets.get("Join Conditions", [])
        has_joins_in_sql = bool(JOIN_ON_PATTERN.search(sql_content))
        if has_joins_in_sql:
            has_join_data = len(join_sheet) > 1 and not (
                len(join_sheet) == 2 and join_sheet[1] and
                "no join" in str(join_sheet[1][0]).lower()
            )
            if not has_join_data:
                self._add_issue("medium", "missing_joins",
                    "Source SQL has JOINs but XLSX Join Conditions sheet is empty",
                    source_file=rel_sql, output_file=rel_xlsx)
            else:
                self.passed_checks.append(f"Join conditions captured: {xlsx_path.name}")

        # Validate Filter Conditions sheet
        filter_sheet = sheets.get("Filter Conditions", [])
        has_where_in_sql = bool(WHERE_PATTERN.search(sql_content))
        if has_where_in_sql:
            has_filter_data = len(filter_sheet) > 1 and not (
                len(filter_sheet) == 2 and filter_sheet[1] and
                "no filter" in str(filter_sheet[1][0]).lower()
            )
            if not has_filter_data:
                self._add_issue("medium", "missing_filters",
                    "Source SQL has WHERE clauses but XLSX Filter Conditions sheet is empty",
                    source_file=rel_sql, output_file=rel_xlsx)
            else:
                self.passed_checks.append(f"Filter conditions captured: {xlsx_path.name}")

    # =========================================================================
    # PER-PROCEDURE VALIDATION
    # =========================================================================

    def validate_procedure(self, proc_dir: Path) -> None:
        """Validate all output files for a single procedure."""
        proc_name = proc_dir.name
        self.logger.info(f"Validating procedure: {proc_name}")

        lineage_csv = proc_dir / f"{proc_name}_lineage.csv"
        structured_xlsx = proc_dir / f"{proc_name}_structured.xlsx"

        # Check files exist
        if not lineage_csv.exists():
            self._add_issue("high", "missing_file",
                f"Missing _lineage.csv for {proc_name}",
                output_file=str(proc_dir.relative_to(self.project_root)))
            return
        if not structured_xlsx.exists():
            self._add_issue("high", "missing_file",
                f"Missing _structured.xlsx for {proc_name}",
                output_file=str(proc_dir.relative_to(self.project_root)))

        # Find source SQL
        sql_path = self._find_source_sql(proc_name)
        if not sql_path:
            self._add_issue("low", "no_source_match",
                f"No matching source SQL file found for {proc_name}",
                output_file=str(lineage_csv.relative_to(self.project_root)))
            return

        sql_content = self._read_sql(sql_path)
        if not sql_content:
            return

        sql_tables = self._extract_tables_from_sql(sql_content)

        # Validate lineage CSV
        csv_rows = self.validate_lineage_csv(lineage_csv, sql_path, sql_content, sql_tables)

        # Validate structured XLSX
        if structured_xlsx.exists():
            self.validate_structured_xlsx(structured_xlsx, sql_path, sql_content, csv_rows)

    # =========================================================================
    # MAIN VALIDATION
    # =========================================================================

    def validate(self) -> List[Dict[str, str]]:
        """Run validation on all procedure output directories."""
        self.logger.info("=" * 60)
        self.logger.info("Lineage Validator - Starting")
        self.logger.info(f"Output dir: {self.output_dir}")
        self.logger.info(f"Inputs dir: {self.inputs_dir}")
        self.logger.info("=" * 60)

        if not self.output_dir.exists():
            self._add_issue("high", "structural_error",
                f"Output directory does not exist: {self.output_dir}")
            return self.issues

        # Find procedure directories (contain _lineage.csv files)
        proc_dirs = sorted([
            d for d in self.output_dir.iterdir()
            if d.is_dir() and (d / f"{d.name}_lineage.csv").exists()
        ])

        # Also check for flat _lineage.csv files (FRY14Q_SP_output style)
        flat_csvs = sorted(self.output_dir.glob("*_lineage.csv"))
        flat_procs = set()
        for csv_file in flat_csvs:
            if not csv_file.name.endswith("_volatile_lineage.csv"):
                flat_procs.add(csv_file)

        total = len(proc_dirs) + len(flat_procs)
        if total == 0:
            self._add_issue("high", "missing_content",
                "No procedure outputs found (no _lineage.csv files)",
                output_file=str(self.output_dir.relative_to(self.project_root)))
            return self.issues

        self.logger.info(f"Found {len(proc_dirs)} procedure dir(s), {len(flat_procs)} flat file(s)")

        if self.dry_run:
            self.logger.info("DRY RUN — listing procedures only")
            for d in proc_dirs:
                self.logger.info(f"  Would validate: {d.name}/")
            for f in flat_procs:
                self.logger.info(f"  Would validate: {f.name}")
            self.passed_checks.append("Dry run completed successfully")
            return self.issues

        # Validate per-procedure directories
        for proc_dir in proc_dirs:
            self.validate_procedure(proc_dir)

        # Validate flat lineage CSVs (no matching XLSX expected here)
        for csv_file in flat_procs:
            proc_name = csv_file.stem.replace("_lineage", "")
            sql_path = self._find_source_sql(proc_name)
            if sql_path:
                sql_content = self._read_sql(sql_path)
                sql_tables = self._extract_tables_from_sql(sql_content)
                self.validate_lineage_csv(csv_file, sql_path, sql_content, sql_tables)

        self.logger.info("=" * 60)
        self.logger.info(f"Validation complete: {len(self.issues)} issue(s), "
            f"{len(self.passed_checks)} check(s) passed")
        self.logger.info("=" * 60)
        return self.issues

    def calculate_accuracy(self) -> float:
        total = len(self.issues) + len(self.passed_checks)
        if total == 0:
            return 100.0
        return round((len(self.passed_checks) / total) * 100, 1)

    def generate_report(self) -> Dict[str, Any]:
        accuracy = self.calculate_accuracy()
        high = [i for i in self.issues if i.get("severity") == "high"]
        medium = [i for i in self.issues if i.get("severity") == "medium"]
        low = [i for i in self.issues if i.get("severity") == "low"]
        return {
            "validation_report": {
                "timestamp": get_timestamp(),
                "validator": "LineageValidator",
                "output_directory": str(self.output_dir),
                "overall_accuracy": accuracy,
                "summary": {
                    "total_issues": len(self.issues),
                    "high_severity": len(high),
                    "medium_severity": len(medium),
                    "low_severity": len(low),
                    "checks_passed": len(self.passed_checks),
                    "total_checks": len(self.issues) + len(self.passed_checks),
                },
                "issues": self.issues,
                "passed_checks": self.passed_checks,
            }
        }

    def save_report(self, report: Dict[str, Any]) -> Path:
        self.log_dir.mkdir(parents=True, exist_ok=True)
        ts = get_timestamp().replace(" ", "_").replace(":", "")
        report_path = self.log_dir / f"validation_{ts}.yaml"
        save_yaml(report, report_path)
        self.logger.info(f"Report saved: {report_path}")
        return report_path

    def print_summary(self, report: Dict[str, Any]) -> None:
        vr = report["validation_report"]
        s = vr["summary"]
        print("\n" + "=" * 60)
        print("LINEAGE VALIDATION REPORT")
        print("=" * 60)
        print(f"Timestamp:        {vr['timestamp']}")
        print(f"Output directory:  {vr['output_directory']}")
        print(f"Overall accuracy:  {vr['overall_accuracy']}%")
        print(f"Total checks:      {s['total_checks']}")
        print(f"Passed:            {s['checks_passed']}")
        print(f"Issues found:      {s['total_issues']}")
        print(f"  High severity:   {s['high_severity']}")
        print(f"  Medium severity: {s['medium_severity']}")
        print(f"  Low severity:    {s['low_severity']}")
        if vr["issues"]:
            print("\n--- ISSUES ---")
            for issue in vr["issues"]:
                print(f"\n[{issue['id']}] ({issue['severity'].upper()}) {issue['category']}")
                print(f"  {issue['description']}")
                if issue.get("source_file"):
                    print(f"  Source: {issue['source_file']}")
                if issue.get("output_file"):
                    print(f"  Output: {issue['output_file']}")
        if vr["passed_checks"]:
            print(f"\n--- PASSED CHECKS ({len(vr['passed_checks'])}) ---")
            for check in vr["passed_checks"][:20]:
                print(f"  [PASS] {check}")
            if len(vr["passed_checks"]) > 20:
                print(f"  ... and {len(vr['passed_checks']) - 20} more")
        print("\n" + "=" * 60)


# Keep backward-compatible alias
STTMValidator = LineageValidator


def main():
    parser = argparse.ArgumentParser(
        description="Validate lineage CSV and structured XLSX output against source SQL"
    )
    parser.add_argument("--output-dir", default="output/FRY14Q_SP",
        help="Directory containing procedure output (default: output/FRY14Q_SP)")
    parser.add_argument("--inputs-dir", default="inputs",
        help="Directory containing source SQL files (default: inputs)")
    parser.add_argument("--dry-run", action="store_true",
        help="List files without running validation")
    args = parser.parse_args()

    validator = LineageValidator(
        output_dir=args.output_dir, inputs_dir=args.inputs_dir, dry_run=args.dry_run)
    validator.validate()
    report = validator.generate_report()
    validator.save_report(report)
    validator.print_summary(report)

    if report["validation_report"]["summary"]["high_severity"] > 0:
        sys.exit(1)


if __name__ == "__main__":
    main()
