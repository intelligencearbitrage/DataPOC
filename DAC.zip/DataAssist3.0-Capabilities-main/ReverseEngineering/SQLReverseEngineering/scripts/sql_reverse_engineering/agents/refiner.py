"""
STTM Refiner - Patches output STTM CSV files based on validation errors and human feedback.

Reads a validation report, optionally reads human feedback, validates the feedback,
generates patches for output/ files, and re-runs the validator in an automated loop.

Usage:
    python -m sql_reverse_engineering.agents.refiner
    python -m sql_reverse_engineering.agents.refiner --report thoughts/logs/agentic/validation_XXXX.yaml
    python -m sql_reverse_engineering.agents.refiner --feedback feedback.txt
    python -m sql_reverse_engineering.agents.refiner --max-iterations 5
"""

import argparse
import csv
import io
import re
import sys
from pathlib import Path
from typing import Any, Dict, List, Optional

# Ensure scripts/ is on the Python path for utils imports
AGENTS_DIR = Path(__file__).resolve().parent
PACKAGE_DIR = AGENTS_DIR.parent  # sql_reverse_engineering/
SCRIPTS_DIR = PACKAGE_DIR.parent  # scripts/
PROJECT_ROOT = SCRIPTS_DIR.parent  # project root
sys.path.insert(0, str(SCRIPTS_DIR))

from sql_reverse_engineering.agents.prompts import (
    FEEDBACK_VALIDATION_PROMPT,
    REFINER_PATCH_PROMPT,
    REFINER_SYSTEM_PROMPT,
)
from sql_reverse_engineering.agents.validator import LineageValidator
from utils import get_project_root, get_timestamp, load_yaml, save_yaml, setup_logging

# Guardrail constants
MAX_LINES_PER_FIX = 50
DEFAULT_MAX_ITERATIONS = 3
ALLOWED_WRITE_DIR = "output"


class STTMRefiner:
    """Patches STTM CSV output files based on validation issues and human feedback."""

    def __init__(
        self,
        report_path: Optional[str] = None,
        feedback_path: Optional[str] = None,
        max_iterations: int = DEFAULT_MAX_ITERATIONS,
        output_dir: str = "output/FRY14Q_SP",
        inputs_dir: str = "inputs",
    ):
        self.project_root = get_project_root()
        self.log_dir = self.project_root / "thoughts" / "logs" / "agentic"
        self.logger = setup_logging(
            "STTMRefiner", log_dir=self.log_dir
        )
        self.report_path = report_path
        self.feedback_path = feedback_path
        self.max_iterations = min(max_iterations, 10)  # Hard ceiling
        self.output_dir = output_dir
        self.inputs_dir = inputs_dir
        self.accuracy_history: List[Dict[str, Any]] = []
        self.stale_issues: Dict[str, int] = {}  # issue_id -> consecutive fail count

    # =========================================================================
    # GUARDRAILS
    # =========================================================================

    def _resolve_project_path(self, raw: str) -> Optional[Path]:
        """Resolve a user-supplied path and reject traversal outside project_root."""
        p = Path(raw)
        resolved = (self.project_root / p if not p.is_absolute() else p).resolve()
        try:
            resolved.relative_to(self.project_root.resolve())
        except ValueError:
            self.logger.error(
                f"Path '{raw}' resolves outside the project root and will not be used."
            )
            return None
        return resolved

    def _is_safe_write_path(self, file_path: Path) -> bool:
        """Guardrail: ensure we only write to output/ directory."""
        try:
            resolved = file_path.resolve()
            output_root = (self.project_root / ALLOWED_WRITE_DIR).resolve()
            return str(resolved).startswith(str(output_root))
        except Exception:
            return False

    def _check_diff_size(self, original: str, patched: str) -> int:
        """Count the number of changed lines between original and patched content."""
        orig_lines = original.splitlines()
        patch_lines = patched.splitlines()
        changed = 0
        max_len = max(len(orig_lines), len(patch_lines))
        for i in range(max_len):
            orig_line = orig_lines[i] if i < len(orig_lines) else ""
            patch_line = patch_lines[i] if i < len(patch_lines) else ""
            if orig_line != patch_line:
                changed += 1
        return changed

    # =========================================================================
    # REPORT & FEEDBACK LOADING
    # =========================================================================

    def _find_latest_report(self) -> Optional[Path]:
        """Find the most recent validation report in the agentic log directory."""
        if self.report_path:
            path = self._resolve_project_path(self.report_path)
            if path and path.exists():
                return path

        if not self.log_dir.exists():
            return None
        reports = sorted(
            self.log_dir.glob("validation_*.yaml"),
            key=lambda p: p.stat().st_mtime,
            reverse=True,
        )
        return reports[0] if reports else None

    def load_report(self) -> Optional[Dict[str, Any]]:
        """Load the validation report."""
        report_path = self._find_latest_report()
        if not report_path:
            self.logger.error("No validation report found. Run validator.py first.")
            return None
        self.logger.info(f"Loading report: {report_path}")
        return load_yaml(report_path)

    def load_feedback(self) -> Optional[str]:
        """Load human feedback from file if provided."""
        if not self.feedback_path:
            return None
        path = Path(self._resolve_project_path(self.feedback_path)).relative_to(self.project_root)
        if not path:
            return None
        if not path.exists():
            self.logger.warning(f"Feedback file not found: {path}")
            return None
        return path.read_text(encoding="utf-8").strip()

    # =========================================================================
    # FEEDBACK VALIDATION
    # =========================================================================

    def validate_feedback(
        self, feedback: str, report: Dict[str, Any]
    ) -> Dict[str, Any]:
        """Validate human feedback before accepting it into the refinement loop."""
        self.logger.info("Validating human feedback...")
        validation_result = {
            "timestamp": get_timestamp(),
            "human_feedback_raw": feedback,
            "validation_results": [],
            "accepted_feedback": [],
            "rejected_feedback": [],
        }

        items = [line.strip() for line in feedback.split("\n") if line.strip()]
        issues = report.get("validation_report", {}).get("issues", [])
        issue_descriptions = {i.get("description", "") for i in issues}

        for item in items:
            checks = []

            # Relevance check
            is_relevant = False
            for desc in issue_descriptions:
                if any(
                    word.lower() in item.lower()
                    for word in desc.split()
                    if len(word) > 3
                ):
                    is_relevant = True
                    break
            if any(
                term in item.lower()
                for term in [
                    "sttm", "mapping", "source_table", "target_table",
                    "transformation", "column", "csv", "output",
                    "missing", "incorrect", "wrong", "add", "fix",
                ]
            ):
                is_relevant = True

            checks.append({
                "check": "relevance",
                "item": item,
                "result": "PASS" if is_relevant else "FAIL",
                "reason": (
                    "Feedback relates to STTM validation issues"
                    if is_relevant
                    else "Feedback does not relate to any validation issue or output"
                ),
            })

            # Actionability check
            is_actionable = bool(
                re.search(
                    r"(?i)(add|remove|change|fix|correct|update|replace|"
                    r"include|missing|wrong|should be|needs to)",
                    item,
                )
            )
            checks.append({
                "check": "actionability",
                "item": item,
                "result": "PASS" if is_actionable else "FAIL",
                "reason": (
                    "Feedback contains actionable instruction"
                    if is_actionable
                    else "Feedback is not actionable as an output patch"
                ),
            })

            # Source consistency check
            contradicts_source = bool(
                re.search(
                    r"(?i)(ignore source|override|don't use source|"
                    r"change the sql|modify input|edit knowledgebase)",
                    item,
                )
            )
            checks.append({
                "check": "source_consistency",
                "item": item,
                "result": "FAIL" if contradicts_source else "PASS",
                "reason": (
                    "Feedback contradicts source data"
                    if contradicts_source
                    else "Feedback is consistent with source data"
                ),
            })

            validation_result["validation_results"].extend(checks)

            all_pass = all(c["result"] == "PASS" for c in checks)
            if all_pass:
                validation_result["accepted_feedback"].append(item)
            else:
                failed_checks = [
                    c["check"] for c in checks if c["result"] == "FAIL"
                ]
                validation_result["rejected_feedback"].append({
                    "item": item,
                    "reason": f"Failed checks: {', '.join(failed_checks)}",
                })

        feedback_log_path = self.log_dir / f"feedback_validation_{get_timestamp().replace(' ', '_').replace(':', '')}.yaml"
        self.log_dir.mkdir(parents=True, exist_ok=True)
        save_yaml(validation_result, feedback_log_path)
        self.logger.info(
            f"Feedback validation: {len(validation_result['accepted_feedback'])} accepted, "
            f"{len(validation_result['rejected_feedback'])} rejected"
        )

        return validation_result

    # =========================================================================
    # PATCHING
    # =========================================================================

    def _read_output_file(self, rel_path: str) -> Optional[str]:
        """Read an output file content."""
        path = self.project_root / rel_path
        if not path.exists():
            return None
        return path.read_text(encoding="utf-8")

    def _read_source_file(self, rel_path: str) -> Optional[str]:
        """Read a source file content."""
        path = self.project_root / rel_path
        if not path.exists():
            return None
        return path.read_text(encoding="utf-8")

    def _write_output_file(self, rel_path: str, content: str) -> bool:
        """Write patched content to an output file (with guardrails)."""
        path = self.project_root / rel_path

        if not self._is_safe_write_path(path):
            self.logger.error(
                f"BLOCKED: Attempted write outside output/: {rel_path}"
            )
            return False

        if "scripts/" in rel_path:
            self.logger.error(
                f"BLOCKED: Attempted to modify script: {rel_path}"
            )
            return False

        if rel_path.startswith("inputs/") or rel_path.startswith("knowledgebase/"):
            self.logger.error(
                f"BLOCKED: Attempted to modify immutable directory: {rel_path}"
            )
            return False

        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(content, encoding="utf-8")
        return True

    def apply_rule_based_fix(
        self, issue: Dict[str, Any], human_feedback: Optional[str] = None
    ) -> Optional[Dict[str, Any]]:
        """Apply a rule-based fix for a specific issue."""
        output_file = issue.get("output_file", "")
        source_file = issue.get("source_file", "")
        category = issue.get("category", "")
        issue_id = issue.get("id", "")

        # Stale loop detection
        if self.stale_issues.get(issue_id, 0) >= 2:
            self.logger.info(
                f"Skipping stale issue {issue_id} — failed in 2+ consecutive iterations"
            )
            return {
                "issue_id": issue_id,
                "status": "skipped_stale",
                "reason": "Failed to improve in 2 consecutive iterations",
            }

        if not output_file:
            return {
                "issue_id": issue_id,
                "status": "skipped",
                "reason": "No output file specified",
            }

        output_content = self._read_output_file(output_file)
        if output_content is None:
            return {
                "issue_id": issue_id,
                "status": "skipped",
                "reason": f"Output file not found: {output_file}",
            }

        source_content = ""
        if source_file:
            source_content = self._read_source_file(source_file) or ""

        if category == "empty_field":
            return {
                "issue_id": issue_id,
                "status": "flagged_for_review",
                "reason": "Empty field fixes require AI analysis or human input",
                "output_file": output_file,
            }

        elif category == "schema_mismatch":
            return {
                "issue_id": issue_id,
                "status": "flagged_for_review",
                "reason": "Schema mismatch requires regenerating the output",
                "output_file": output_file,
            }

        elif category == "missing_dml_coverage":
            return {
                "issue_id": issue_id,
                "status": "flagged_for_review",
                "reason": (
                    "Missing DML coverage requires analysis of source SQL to "
                    "generate correct STTM rows"
                ),
                "output_file": output_file,
                "source_file": source_file,
            }

        elif category == "phantom_reference":
            return {
                "issue_id": issue_id,
                "status": "flagged_for_review",
                "reason": "Phantom table references need manual verification",
                "output_file": output_file,
            }

        elif category == "missing_volatile_chain":
            return {
                "issue_id": issue_id,
                "status": "flagged_for_review",
                "reason": (
                    "Missing volatile table chain requires SQL analysis to "
                    "add both hop rows"
                ),
                "output_file": output_file,
                "source_file": source_file,
            }

        elif category == "missing_content" and "target tables" in issue.get("description", ""):
            return {
                "issue_id": issue_id,
                "status": "flagged_for_review",
                "reason": "Missing target table mappings require SQL analysis",
                "output_file": output_file,
                "source_file": source_file,
            }

        else:
            return {
                "issue_id": issue_id,
                "status": "flagged_for_review",
                "reason": f"Category '{category}' requires manual analysis",
                "output_file": output_file,
            }

    def run_iteration(
        self,
        issues: List[Dict[str, Any]],
        iteration: int,
        human_feedback: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Run a single refinement iteration."""
        self.logger.info(f"\n--- Iteration {iteration} ---")
        iteration_log = {
            "iteration": iteration,
            "timestamp": get_timestamp(),
            "trigger": (
                "validation_errors + human_feedback"
                if human_feedback
                else "validation_errors"
            ),
            "issues_attempted": [],
            "human_feedback_applied": human_feedback or "",
        }

        for issue in issues:
            if issue.get("severity") == "low" and not human_feedback:
                continue

            result = self.apply_rule_based_fix(issue, human_feedback)
            if result:
                iteration_log["issues_attempted"].append(result)

                issue_id = issue.get("id", "")
                if result.get("status") in ("flagged_for_review", "skipped"):
                    self.stale_issues[issue_id] = (
                        self.stale_issues.get(issue_id, 0) + 1
                    )
                else:
                    self.stale_issues[issue_id] = 0

        log_path = (
            self.log_dir
            / f"iteration_{iteration}_refiner_{get_timestamp().replace(' ', '_').replace(':', '')}.yaml"
        )
        save_yaml(iteration_log, log_path)

        return iteration_log

    # =========================================================================
    # REFINEMENT LOOP
    # =========================================================================

    def run(self) -> Dict[str, Any]:
        """Run the full refinement loop."""
        self.logger.info("=" * 60)
        self.logger.info("STTM Refiner - Starting")
        self.logger.info(f"Max iterations: {self.max_iterations}")
        self.logger.info("=" * 60)

        report = self.load_report()
        if not report:
            return {"status": "error", "message": "No validation report found"}

        issues = report.get("validation_report", {}).get("issues", [])
        if not issues:
            self.logger.info("No issues to refine — output is clean!")
            return {"status": "no_issues", "message": "Validation passed with no issues"}

        initial_accuracy = report.get("validation_report", {}).get(
            "overall_accuracy", 0
        )
        self.accuracy_history.append({
            "stage": "initial_validation",
            "accuracy": initial_accuracy,
            "issues_found": len(issues),
        })

        human_feedback = Path(self.project_root).joinpath(Path(human_feedback)).resolve()
        accepted_feedback = None
        if human_feedback:
            fb_result = self.validate_feedback(human_feedback, report)
            accepted_items = fb_result.get("accepted_feedback", [])
            if accepted_items:
                accepted_feedback = "\n".join(accepted_items)
                self.logger.info(
                    f"Accepted {len(accepted_items)} feedback item(s)"
                )
            else:
                self.logger.warning("All feedback items were rejected")

        prev_accuracy = initial_accuracy
        for iteration in range(1, self.max_iterations + 1):
            iter_log = self.run_iteration(issues, iteration, accepted_feedback)

            self.logger.info(f"Re-running validator after iteration {iteration}...")
            validator = LineageValidator(
                output_dir=self.output_dir,
                inputs_dir=self.inputs_dir,
            )
            validator.validate()
            new_report = validator.generate_report()
            validator.save_report(new_report)

            new_accuracy = new_report["validation_report"]["overall_accuracy"]
            new_issues = new_report["validation_report"]["issues"]

            self.accuracy_history.append({
                "stage": f"iteration_{iteration}",
                "accuracy": new_accuracy,
                "issues_patched": len(issues) - len(new_issues),
                "issues_remaining": len(new_issues),
            })

            self.logger.info(
                f"Iteration {iteration}: accuracy {prev_accuracy}% -> {new_accuracy}%, "
                f"issues {len(issues)} -> {len(new_issues)}"
            )

            if not new_issues:
                self.logger.info("All issues resolved!")
                break

            if new_accuracy < prev_accuracy:
                self.logger.warning(
                    f"Accuracy regression detected ({prev_accuracy}% -> {new_accuracy}%). "
                    f"Stopping loop for human review."
                )
                break

            if new_accuracy == prev_accuracy and len(new_issues) == len(issues):
                self.logger.warning(
                    "No improvement detected. Stopping loop for human review."
                )
                break

            prev_accuracy = new_accuracy
            issues = new_issues
            accepted_feedback = None

        progression = {
            "run_id": f"run_{get_timestamp().replace(' ', '_').replace(':', '')}",
            "progression": self.accuracy_history,
            "trend": self._calculate_trend(),
        }
        save_yaml(
            progression,
            self.log_dir / f"accuracy_progression_{get_timestamp().replace(' ', '_').replace(':', '')}.yaml",
        )

        summary = {
            "run_summary": {
                "timestamp": get_timestamp(),
                "initial_accuracy": initial_accuracy,
                "final_accuracy": self.accuracy_history[-1]["accuracy"],
                "iterations_run": len(self.accuracy_history) - 1,
                "max_iterations": self.max_iterations,
                "human_feedback_provided": human_feedback is not None,
                "trend": self._calculate_trend(),
                "accuracy_progression": self.accuracy_history,
            }
        }
        save_yaml(
            summary,
            self.log_dir / f"run_summary_{get_timestamp().replace(' ', '_').replace(':', '')}.yaml",
        )

        self.print_summary(summary)
        return summary

    def _calculate_trend(self) -> str:
        """Determine the accuracy trend across iterations."""
        if len(self.accuracy_history) < 2:
            return "insufficient_data"
        accuracies = [h["accuracy"] for h in self.accuracy_history]
        if all(a >= b for a, b in zip(accuracies[1:], accuracies)):
            return "improving"
        if all(a <= b for a, b in zip(accuracies[1:], accuracies)):
            return "regressing"
        return "mixed"

    def print_summary(self, summary: Dict[str, Any]) -> None:
        """Print a human-readable summary to console."""
        rs = summary["run_summary"]
        print("\n" + "=" * 60)
        print("STTM REFINEMENT SUMMARY")
        print("=" * 60)
        print(f"Timestamp:           {rs['timestamp']}")
        print(f"Initial accuracy:    {rs['initial_accuracy']}%")
        print(f"Final accuracy:      {rs['final_accuracy']}%")
        print(f"Iterations run:      {rs['iterations_run']}")
        print(f"Max iterations:      {rs['max_iterations']}")
        print(f"Human feedback:      {'Yes' if rs['human_feedback_provided'] else 'No'}")
        print(f"Trend:               {rs['trend']}")

        print("\n--- Accuracy Progression ---")
        for entry in rs["accuracy_progression"]:
            stage = entry["stage"]
            acc = entry["accuracy"]
            extra = ""
            if "issues_patched" in entry:
                extra = (
                    f" (patched: {entry['issues_patched']}, "
                    f"remaining: {entry['issues_remaining']})"
                )
            elif "issues_found" in entry:
                extra = f" (issues found: {entry['issues_found']})"
            print(f"  {stage}: {acc}%{extra}")

        print("\n" + "=" * 60)


def main():
    """Entry point for the STTM refiner."""
    parser = argparse.ArgumentParser(
        description="Refine STTM CSV output based on validation errors and feedback"
    )
    parser.add_argument(
        "--report",
        default=None,
        help="Path to validation report YAML (default: latest in thoughts/logs/agentic/)",
    )
    parser.add_argument(
        "--feedback",
        default=None,
        help="Path to human feedback text file",
    )
    parser.add_argument(
        "--max-iterations",
        type=int,
        default=DEFAULT_MAX_ITERATIONS,
        help=f"Maximum refinement iterations (default: {DEFAULT_MAX_ITERATIONS})",
    )
    parser.add_argument(
        "--output-dir",
        default="output/FRY14Q_SP",
        help="Directory containing lineage output files (default: output/FRY14Q_SP)",
    )
    parser.add_argument(
        "--inputs-dir",
        default="inputs",
        help="Directory containing source SQL files (default: inputs)",
    )
    args = parser.parse_args()

    refiner = STTMRefiner(
        report_path=args.report,
        feedback_path=args.feedback,
        max_iterations=args.max_iterations,
        output_dir=args.output_dir,
        inputs_dir=args.inputs_dir,
    )
    refiner.run()


if __name__ == "__main__":
    main()
