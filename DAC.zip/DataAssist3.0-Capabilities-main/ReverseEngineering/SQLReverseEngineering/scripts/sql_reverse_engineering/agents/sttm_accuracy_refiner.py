"""
STTM Accuracy Refiner — iterative file-by-file refinement loop that:

1. Analyzes accuracy validation results to find common error patterns
2. Presents patterns to the user for each file
3. Re-generates STTM output (re-runs the pipeline) after user fixes
4. Re-validates until accuracy is good or max iterations reached

Usage:
    # After a batch validation, refine interactively
    python -m sql_reverse_engineering.agents.sttm_accuracy_refiner \
        --output-dir output/SP_VIEWS_STTM --inputs-dir inputs/SP_VIEWS

    # Auto mode (re-generate + re-validate without prompts)
    python -m sql_reverse_engineering.agents.sttm_accuracy_refiner \
        --output-dir output/SP_VIEWS_STTM --inputs-dir inputs/SP_VIEWS --auto

    # Single file
    python -m sql_reverse_engineering.agents.sttm_accuracy_refiner \
        --sql input.sql --xlsx output_structured.xlsx
"""

import argparse
import sys
from collections import Counter
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple
from werkzeug.utils import safe_join, secure_filename

AGENTS_DIR = Path(__file__).resolve().parent
PACKAGE_DIR = AGENTS_DIR.parent
SCRIPTS_DIR = PACKAGE_DIR.parent
PROJECT_ROOT = SCRIPTS_DIR.parent
sys.path.insert(0, str(SCRIPTS_DIR))

# Refiner-specific prompts (inlined after accuracy_prompts.py was removed)
ACCURACY_REFINER_SYSTEM_PROMPT = """\
You are an accuracy refinement agent for Teradata SQL reverse engineering output.
Your job is to identify common error patterns across a batch of STTM validations,
present them to the user, and iteratively re-generate + re-validate each file
until accuracy meets the target threshold or max iterations are reached.

Refinement loop per file:
1. Show current accuracy score and issues
2. Offer the user the option to fix pipeline code, then re-generate
3. Re-run the STTM pipeline to produce new structured XLSX
4. Re-validate with the accuracy agent
5. Report delta (improved / regressed / unchanged)
6. Repeat until target score or max iterations

You are safety-conscious:
- Only write to the output/ directory
- Never modify source SQL files or knowledgebase/
- Stop on accuracy regression to avoid making things worse
- Track progression for auditability
"""

REFINER_PATTERN_PROMPT = """\
PATTERN DETECTION — Analyze accuracy reports from {file_count} files.

Look for recurring issues across files:
- Same dimension failing repeatedly (e.g., filter_capture across 80% of files)
- Same type of missing content (e.g., WHERE clauses not captured)
- Systematic mismatches (e.g., join IDs never assigned)

Group by dimension and normalize issue text to find the top patterns.
These patterns suggest pipeline bugs rather than per-file anomalies.
"""

REFINER_REGEN_PROMPT = """\
REGENERATION — Re-running STTM pipeline for {sql_file}.

Steps:
1. Parse SQL with SQLASTGenerator
2. Extract elements with SQLElementExtractor
3. Extract lineage with LineageExtractor
4. Merge into LineageGraph
5. Generate structured XLSX with SourceTargetMappingGenerator

After regeneration, re-validate with STTMAccuracyAgent to measure delta.
Target score: {threshold}. Iteration: {iteration}/{max_iterations}.
Previous score: {previous_score}.
"""


def _grade(score: float) -> str:
    """Convert numeric score to letter grade."""
    if score >= 90:
        return "A"
    if score >= 75:
        return "B"
    if score >= 60:
        return "C"
    return "F"


class STTMAccuracyAgent:  # noqa: D101 — stub; use AICodeReviewer instead
    """Removed stub.

    STTMAccuracyAgent has been superseded by AICodeReviewer
    (agent_interface.ai_code_reviewer). The old agent used sqlglot for both
    generation and scoring, making validation circular.

    For single-file review use:
        from agent_interface.ai_code_reviewer import AICodeReviewer

    For batch scoring wire AICodeReviewer into the refiner loop.
    """

    def __init__(self, *args, **kwargs):
        raise RuntimeError(
            "STTMAccuracyAgent has been removed. "
            "Use AICodeReviewer from agent_interface.ai_code_reviewer instead."
        )
from utils import get_timestamp, save_yaml, setup_logging

DEFAULT_MAX_ITERATIONS = 3
MAX_ITERATIONS_CEILING = 5
GOOD_SCORE_THRESHOLD = 85.0


def _resolve_cli_path(raw: str, must_be_under: Optional[Path] = None) -> Path:
    """Resolve a CLI-supplied path and reject traversal outside *must_be_under*.

    Absolute paths that escape the allowed base (e.g. via ``/`` or ``..``) are
    rejected so that command-line arguments cannot read or write arbitrary files.
    The returned path has its basename sanitized via secure_filename + safe_join
    so that static analysis tools can verify no filename-level traversal is possible.
    """
    resolved = Path(raw).resolve()
    if must_be_under is not None:
        base = must_be_under.resolve()
        try:
            resolved.relative_to(base)
        except ValueError:
            print(
                f"Error: '{raw}' resolves to '{resolved}', which is outside "
                f"the allowed directory '{base}'.",
                file=sys.stderr,
            )
            sys.exit(1)
    return Path(safe_join(str(resolved.parent), secure_filename(resolved.name)))


# ---------------------------------------------------------------------------
# Pattern Detection
# ---------------------------------------------------------------------------

def detect_common_patterns(
    batch_results: List[Dict[str, Any]],
) -> List[Dict[str, Any]]:
    """Analyze a batch of accuracy reports and extract common error patterns.

    Returns a list of pattern dicts sorted by frequency (most common first).
    """
    dimension_issues: Counter = Counter()
    dimension_examples: Dict[str, List[str]] = {}
    low_dimension_scores: Counter = Counter()

    for result in batch_results:
        report = result.get("report", {}).get("accuracy_report", {})
        file_name = result.get("file", "unknown")
        blocks = report.get("blocks", [])

        for block in blocks:
            dims = block.get("dimensions", {})
            for dim_name, dim_data in dims.items():
                score = dim_data.get("score", 100.0)
                issues = dim_data.get("issues", [])

                if score < 100.0:
                    low_dimension_scores[dim_name] += 1

                for issue_text in issues:
                    # Normalize issue to a pattern key
                    pattern_key = _normalize_issue(dim_name, issue_text)
                    dimension_issues[pattern_key] += 1
                    if pattern_key not in dimension_examples:
                        dimension_examples[pattern_key] = []
                    if len(dimension_examples[pattern_key]) < 3:
                        dimension_examples[pattern_key].append(
                            f"{file_name} block {block.get('block_index', '?')}: {issue_text[:120]}"
                        )

    patterns = []
    for pattern_key, count in dimension_issues.most_common():
        dim_name, pattern_desc = pattern_key.split("|", 1)
        patterns.append({
            "dimension": dim_name,
            "pattern": pattern_desc,
            "occurrences": count,
            "affected_files": count,
            "examples": dimension_examples.get(pattern_key, []),
        })

    return patterns


def _normalize_issue(dim_name: str, issue_text: str) -> str:
    """Normalize an issue string to a pattern key for grouping."""
    text = issue_text.strip()
    # Strip specific counts/percentages to group similar issues
    import re
    text = re.sub(r'\(\d+\)', '(N)', text)
    text = re.sub(r'\d+%', 'N%', text)
    text = re.sub(r'\d+/\d+', 'N/M', text)
    # Strip specific column/table lists but keep the prefix
    text = re.sub(r':\s+[A-Z_,\s]+$', ': [columns]', text)
    # Keep first 80 chars
    if len(text) > 80:
        text = text[:77] + "..."
    return f"{dim_name}|{text}"


def summarize_file_issues(report: Dict[str, Any]) -> List[str]:
    """Extract a concise list of issues from a single file's accuracy report."""
    issues = []
    ar = report.get("accuracy_report", {})
    for block in ar.get("blocks", []):
        block_idx = block.get("block_index", "?")
        target = block.get("target_table_short", "?")
        score = block.get("overall_score", 0)
        dims = block.get("dimensions", {})
        for dim_name, dim_data in dims.items():
            for issue_text in dim_data.get("issues", []):
                issues.append(
                    f"Block {block_idx} [{target}] ({dim_name}): {issue_text}"
                )
    return issues


# ---------------------------------------------------------------------------
# STTM Re-generation
# ---------------------------------------------------------------------------

def regenerate_sttm(sql_path: str, output_dir: str, dialect: str = "teradata") -> bool:
    """Re-run the STTM pipeline for a single SQL file.

    Returns True if regeneration succeeded.
    """
    try:
        # Import pipeline classes
        sys.path.insert(0, str(PROJECT_ROOT / "scripts" / "sql_reverse_engineering" / "tools"))
        sys.path.insert(0, str(PROJECT_ROOT / "scripts" / "sql_reverse_engineering"))

        from ast_generator.parser import SQLASTGenerator
        from deconstructor.element_extractor import SQLElementExtractor
        from documentation.mapping_generator import SourceTargetMappingGenerator
        from lineage.lineage_extractor import LineageExtractor
        from lineage.lineage_graph import LineageGraph

        sql_file = _resolve_cli_path(sql_path, must_be_under=PROJECT_ROOT)
        sql = sql_file.read_text(encoding="utf-8", errors="replace")
        base_name = sql_file.stem

        generator = SQLASTGenerator(dialect=dialect)
        result = generator.parse_safe(sql)

        if not result.success:
            return False

        all_elements = []
        merged_graph = LineageGraph()

        for stmt in result.statements:
            extractor = SQLElementExtractor(stmt, dialect)
            elements = extractor.extract_all()
            all_elements.append(elements)

            lineage_extractor = LineageExtractor(schema=None, dialect=dialect)
            lineage = lineage_extractor.extract_lineage(stmt.sql(dialect=dialect))
            merged_graph.merge(lineage)

        elements = all_elements[0] if all_elements else None

        doc_gen = SourceTargetMappingGenerator(
            merged_graph, elements, all_element_catalogs=all_elements
        )

        import os
        safe_output_dir = _resolve_cli_path(output_dir, must_be_under=PROJECT_ROOT)
        xlsx_path = str(safe_output_dir / f"{base_name}_structured.xlsx")
        doc_gen.generate_structured_excel(xlsx_path, sql_path)

        # Also regenerate lineage CSV if the generator supports it
        csv_path = str(safe_output_dir / f"{base_name}_lineage.csv")
        try:
            doc_gen.generate_csv(csv_path)
        except Exception:
            pass  # CSV generation is optional

        return True
    except Exception as e:
        print(f"  Regeneration failed: {e}")
        return False


# ---------------------------------------------------------------------------
# Accuracy Refiner
# ---------------------------------------------------------------------------

class STTMAccuracyRefiner:
    """Iterative file-by-file refinement loop for STTM accuracy.

    After the accuracy validator identifies issues, the refiner:
    1. Detects common error patterns across the batch
    2. For each file with issues, presents patterns to the user
    3. Optionally re-generates STTM output (after user fixes pipeline code)
    4. Re-validates to check if accuracy improved
    5. Repeats up to max_iterations per file or until score >= threshold
    """

    def __init__(
        self,
        max_iterations: int = DEFAULT_MAX_ITERATIONS,
        score_threshold: float = GOOD_SCORE_THRESHOLD,
        auto: bool = False,
        dialect: str = "teradata",
    ):
        self.max_iterations = min(max_iterations, MAX_ITERATIONS_CEILING)
        self.score_threshold = score_threshold
        self.auto = auto
        self.dialect = dialect
        self.log_dir = PROJECT_ROOT / "thoughts" / "logs" / "agentic"
        self.logger = setup_logging("STTMAccuracyRefiner", log_dir=self.log_dir)
        self.progression: List[Dict[str, Any]] = []

    # =========================================================================
    # SINGLE FILE REFINEMENT
    # =========================================================================

    def refine_single(
        self,
        sql_path: str,
        xlsx_path: str,
        output_dir: str,
        initial_report: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """Refine a single SQL+XLSX pair iteratively.

        Returns a dict with the file's refinement history.
        """
        sql_name = Path(sql_path).stem
        self.logger.info(f"Refining: {sql_name}")

        history = {
            "file": sql_name,
            "sql_path": sql_path,
            "xlsx_path": xlsx_path,
            "iterations": [],
            "initial_score": None,
            "final_score": None,
            "outcome": "pending",
        }

        # Get initial score from provided report or run a fresh validation
        if initial_report:
            ar = initial_report.get("accuracy_report", {})
            current_score = ar.get("overall_score", 0.0)
            current_grade = ar.get("grade", "F")
            current_report = initial_report
        else:
            agent = STTMAccuracyAgent(sql_path=sql_path, xlsx_path=xlsx_path, auto=True)
            current_report = agent.run()
            ar = current_report.get("accuracy_report", {})
            current_score = ar.get("overall_score", 0.0)
            current_grade = ar.get("grade", "F")

        history["initial_score"] = current_score

        if current_score >= self.score_threshold:
            self.logger.info(
                f"  {sql_name}: score {current_score:.1f} [{current_grade}] "
                f">= threshold {self.score_threshold}. No refinement needed."
            )
            history["final_score"] = current_score
            history["outcome"] = "already_good"
            return history

        for iteration in range(1, self.max_iterations + 1):
            self.logger.info(f"\n  --- {sql_name} iteration {iteration}/{self.max_iterations} ---")

            # Show issues for this file
            issues = summarize_file_issues(current_report)
            if not issues:
                self.logger.info(f"  No issues found. Score: {current_score:.1f}")
                history["outcome"] = "no_issues"
                break

            print(f"\n  [{sql_name}] Score: {current_score:.1f} [{current_grade}] "
                  f"({len(issues)} issue(s)), iteration {iteration}/{self.max_iterations}")
            for iss in issues[:10]:
                print(f"    - {iss}")
            if len(issues) > 10:
                print(f"    ... and {len(issues) - 10} more")

            # Ask user what to do (unless auto mode)
            action = self._prompt_action(sql_name, current_score, iteration)

            if action == "skip":
                self.logger.info(f"  User skipped {sql_name}")
                history["outcome"] = "skipped"
                break

            if action == "accept":
                self.logger.info(f"  User accepted {sql_name} as-is")
                history["outcome"] = "accepted"
                break

            # action == "regenerate"
            print(f"  Re-generating STTM for {sql_name}...")
            success = regenerate_sttm(sql_path, output_dir, self.dialect)

            if not success:
                print(f"  Regeneration failed for {sql_name}. Skipping further iterations.")
                history["iterations"].append({
                    "iteration": iteration,
                    "action": "regenerate",
                    "success": False,
                    "score_before": current_score,
                })
                history["outcome"] = "regen_failed"
                break

            # Re-validate
            print(f"  Re-validating {sql_name}...")
            agent = STTMAccuracyAgent(sql_path=sql_path, xlsx_path=xlsx_path, auto=True)
            new_report = agent.run()
            new_ar = new_report.get("accuracy_report", {})
            new_score = new_ar.get("overall_score", 0.0)
            new_grade = new_ar.get("grade", "F")

            delta = new_score - current_score
            direction = "improved" if delta > 0 else ("regressed" if delta < 0 else "unchanged")

            history["iterations"].append({
                "iteration": iteration,
                "action": "regenerate",
                "success": True,
                "score_before": current_score,
                "score_after": new_score,
                "delta": round(delta, 1),
                "direction": direction,
            })

            print(f"  {sql_name}: {current_score:.1f} -> {new_score:.1f} [{new_grade}] ({direction})")

            if new_score >= self.score_threshold:
                print(f"  Target accuracy reached for {sql_name}!")
                history["outcome"] = "target_reached"
                current_score = new_score
                current_report = new_report
                break

            if new_score < current_score:
                print(f"  Accuracy regressed. Stopping refinement for {sql_name}.")
                history["outcome"] = "regression"
                current_score = new_score
                current_report = new_report
                break

            if new_score == current_score:
                print(f"  No improvement. Stopping refinement for {sql_name}.")
                history["outcome"] = "no_improvement"
                break

            current_score = new_score
            current_grade = new_grade
            current_report = new_report
        else:
            history["outcome"] = "max_iterations"

        history["final_score"] = current_score
        return history

    def _prompt_action(self, sql_name: str, score: float, iteration: int) -> str:
        """Prompt user for action on a file. Returns 'regenerate', 'skip', or 'accept'."""
        if self.auto:
            return "regenerate"

        print(f"\n  Options for {sql_name} (score {score:.1f}, iter {iteration}):")
        print("    1. Re-generate STTM and re-validate")
        print("    2. Skip this file")
        print("    3. Accept current score")
        while True:
            try:
                raw = input("  Enter choice (1-3): ").strip()
                choice = int(raw)
                if choice == 1:
                    return "regenerate"
                if choice == 2:
                    return "skip"
                if choice == 3:
                    return "accept"
            except (ValueError, EOFError):
                pass
            print("  Please enter 1, 2, or 3")

    # =========================================================================
    # BATCH REFINEMENT
    # =========================================================================

    def refine_batch(
        self,
        batch_results: List[Dict[str, Any]],
        output_dir: str,
    ) -> Dict[str, Any]:
        """Refine a batch of files based on accuracy validation results.

        Args:
            batch_results: List of dicts with keys: file, sql_path, xlsx_path,
                           score, grade, report
            output_dir: Directory where STTM output files live
        """
        total = len(batch_results)
        self.logger.info("=" * 70)
        self.logger.info("STTM ACCURACY REFINER — BATCH MODE")
        self.logger.info(f"  Files: {total}")
        self.logger.info(f"  Max iterations per file: {self.max_iterations}")
        self.logger.info(f"  Score threshold: {self.score_threshold}")
        self.logger.info("=" * 70)

        # Phase 1: Pattern detection across the batch
        patterns = detect_common_patterns(batch_results)
        if patterns:
            self._print_patterns(patterns, total)
            if not self.auto:
                self._prompt_pattern_review()

        # Phase 2: Sort files by score (worst first) and refine
        needs_refinement = [
            r for r in batch_results
            if r.get("score", 0) < self.score_threshold
        ]
        needs_refinement.sort(key=lambda r: r.get("score", 0))

        already_good = total - len(needs_refinement)
        print(f"\n  {already_good} file(s) already >= {self.score_threshold} threshold")
        print(f"  {len(needs_refinement)} file(s) need refinement\n")

        if not needs_refinement:
            return self._build_batch_summary([], patterns, batch_results)

        file_histories = []
        for i, result in enumerate(needs_refinement, 1):
            sql_name = result.get("file", "unknown")
            sql_path = result.get("sql_path", "")
            xlsx_path = result.get("xlsx_path", "")
            initial_report = result.get("report")

            print(f"\n{'='*60}")
            print(f"[{i}/{len(needs_refinement)}] Refining: {sql_name} "
                  f"(current score: {result.get('score', 0):.1f})")
            print(f"{'='*60}")

            history = self.refine_single(
                sql_path=sql_path,
                xlsx_path=xlsx_path,
                output_dir=output_dir,
                initial_report=initial_report,
            )
            file_histories.append(history)

        summary = self._build_batch_summary(file_histories, patterns, batch_results)

        # Save report
        self.log_dir.mkdir(parents=True, exist_ok=True)
        ts = get_timestamp().replace(" ", "_").replace(":", "")
        save_yaml(summary, self.log_dir / f"refiner_batch_{ts}.yaml")

        self._print_batch_summary(summary)
        return summary

    # =========================================================================
    # PATTERN DISPLAY
    # =========================================================================

    def _print_patterns(self, patterns: List[Dict[str, Any]], total_files: int):
        """Print detected common patterns."""
        print("\n" + "=" * 70)
        print("COMMON ERROR PATTERNS DETECTED")
        print("=" * 70)
        for i, p in enumerate(patterns[:15], 1):
            pct = (p["occurrences"] / max(total_files, 1)) * 100
            print(f"\n  {i}. [{p['dimension']}] {p['pattern']}")
            print(f"     Occurrences: {p['occurrences']} ({pct:.0f}% of files)")
            for ex in p["examples"][:2]:
                print(f"     e.g. {ex}")
        if len(patterns) > 15:
            print(f"\n  ... and {len(patterns) - 15} more patterns")
        print()

    def _prompt_pattern_review(self):
        """Let the user review patterns before proceeding."""
        print("  Review the patterns above. If you want to fix pipeline code")
        print("  before re-generating, do so now.")
        print()
        while True:
            try:
                raw = input("  Press Enter to proceed with refinement (or 'q' to quit): ").strip()
                if raw.lower() == "q":
                    print("  Refinement cancelled.")
                    sys.exit(0)
                break
            except EOFError:
                break

    # =========================================================================
    # SUMMARY
    # =========================================================================

    def _build_batch_summary(
        self,
        file_histories: List[Dict[str, Any]],
        patterns: List[Dict[str, Any]],
        original_results: List[Dict[str, Any]],
    ) -> Dict[str, Any]:
        """Build the batch refinement summary report."""
        improved = [h for h in file_histories if
                    h.get("final_score", 0) > h.get("initial_score", 0)]
        target_reached = [h for h in file_histories if h.get("outcome") == "target_reached"]
        regressed = [h for h in file_histories if h.get("outcome") == "regression"]

        initial_scores = [r.get("score", 0) for r in original_results]
        avg_initial = sum(initial_scores) / len(initial_scores) if initial_scores else 0

        final_scores = []
        for r in original_results:
            # Check if this file was refined
            refined = next(
                (h for h in file_histories if h.get("file") == r.get("file")),
                None,
            )
            if refined and refined.get("final_score") is not None:
                final_scores.append(refined["final_score"])
            else:
                final_scores.append(r.get("score", 0))
        avg_final = sum(final_scores) / len(final_scores) if final_scores else 0

        return {
            "refiner_batch_report": {
                "timestamp": get_timestamp(),
                "config": {
                    "max_iterations_per_file": self.max_iterations,
                    "score_threshold": self.score_threshold,
                    "auto_mode": self.auto,
                },
                "summary": {
                    "total_files": len(original_results),
                    "files_refined": len(file_histories),
                    "files_improved": len(improved),
                    "files_target_reached": len(target_reached),
                    "files_regressed": len(regressed),
                    "avg_initial_score": round(avg_initial, 1),
                    "avg_final_score": round(avg_final, 1),
                    "avg_delta": round(avg_final - avg_initial, 1),
                },
                "common_patterns": patterns[:10],
                "file_histories": file_histories,
            }
        }

    def _print_batch_summary(self, summary: Dict[str, Any]):
        """Print the batch refinement summary."""
        r = summary["refiner_batch_report"]
        s = r["summary"]
        w = 70

        print("\n" + "=" * w)
        print("STTM ACCURACY REFINER — BATCH SUMMARY")
        print("=" * w)
        print(f"  Total files:         {s['total_files']}")
        print(f"  Files refined:       {s['files_refined']}")
        print(f"  Files improved:      {s['files_improved']}")
        print(f"  Target reached:      {s['files_target_reached']}")
        print(f"  Files regressed:     {s['files_regressed']}")
        print()
        print(f"  Avg initial score:   {s['avg_initial_score']:.1f}")
        print(f"  Avg final score:     {s['avg_final_score']:.1f}")
        print(f"  Avg delta:           {'+' if s['avg_delta'] >= 0 else ''}{s['avg_delta']:.1f}")
        print()

        # Per-file results
        print(f"  {'File':<45} {'Before':>7} {'After':>7} {'Outcome':<15}")
        print("  " + "-" * 67)
        for h in r.get("file_histories", []):
            before = h.get("initial_score", 0)
            after = h.get("final_score", before)
            outcome = h.get("outcome", "?")
            print(f"  {h['file']:<45} {before:>6.1f} {after:>6.1f}  {outcome}")

        print("\n" + "=" * w)
        report_path = self.log_dir / "refiner_batch_*.yaml"
        print(f"  Report saved to: {report_path}")
        print("=" * w)


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def main():
    parser = argparse.ArgumentParser(
        description="STTM Accuracy Refiner — iterative file-by-file refinement"
    )

    # Single-file mode
    parser.add_argument("--sql", help="Path to source SQL file")
    parser.add_argument("--xlsx", help="Path to structured XLSX output")

    # Batch mode
    parser.add_argument("--output-dir", help="Output directory with XLSX files")
    parser.add_argument("--inputs-dir", help="Inputs directory with SQL files")

    # Common
    parser.add_argument("--max-iterations", type=int, default=DEFAULT_MAX_ITERATIONS,
                        help=f"Max iterations per file (default: {DEFAULT_MAX_ITERATIONS}, max: {MAX_ITERATIONS_CEILING})")
    parser.add_argument("--threshold", type=float, default=GOOD_SCORE_THRESHOLD,
                        help=f"Score threshold to consider 'good' (default: {GOOD_SCORE_THRESHOLD})")
    parser.add_argument("--auto", action="store_true",
                        help="Auto mode — no interactive prompts")
    parser.add_argument("--dialect", default="teradata",
                        help="SQL dialect (default: teradata)")

    args = parser.parse_args()

    refiner = STTMAccuracyRefiner(
        max_iterations=args.max_iterations,
        score_threshold=args.threshold,
        auto=args.auto,
        dialect=args.dialect,
    )

    if args.sql and args.xlsx:
        # Single-file mode
        sql_path = _resolve_cli_path(args.sql)
        xlsx_path = _resolve_cli_path(args.xlsx)
        output_dir = str(xlsx_path.parent)
        history = refiner.refine_single(
            sql_path=str(sql_path),
            xlsx_path=str(xlsx_path),
            output_dir=output_dir,
        )
        print(f"\nResult: {history['outcome']} "
              f"(score: {history.get('initial_score', 0):.1f} -> {history.get('final_score', 0):.1f})")

    elif args.output_dir and args.inputs_dir:
        # Batch mode — first validate, then refine
        raise RuntimeError(
            "Batch mode scoring via STTMAccuracyAgent has been removed. "
            "Use AICodeReviewer (agent_interface.ai_code_reviewer) for scoring, "
            "or run refine_single() per file."
        )

        output_dir_path = _resolve_cli_path(args.output_dir, must_be_under=PROJECT_ROOT)
        inputs_dir_path = _resolve_cli_path(args.inputs_dir, must_be_under=PROJECT_ROOT)

        pairs = find_pairs(str(output_dir_path), str(inputs_dir_path))
        if not pairs:
            print("No matching SQL+XLSX pairs found.")
            return

        print(f"Found {len(pairs)} pair(s). Running initial validation...\n")

        batch_results = []
        for sql_path, xlsx_path in pairs:
            sql_name = Path(sql_path).stem
            agent = STTMAccuracyAgent(sql_path=sql_path, xlsx_path=xlsx_path, auto=True)
            try:
                report = agent.run()
                batch_results.append({
                    "file": sql_name,
                    "sql_path": sql_path,
                    "xlsx_path": xlsx_path,
                    "score": agent.state.overall_score,
                    "grade": agent.state.grade,
                    "report": report,
                })
                print(f"  {sql_name}: {agent.state.overall_score:.1f} [{agent.state.grade}]")
            except Exception as e:
                print(f"  {sql_name}: ERROR — {e}")
                batch_results.append({
                    "file": sql_name,
                    "sql_path": sql_path,
                    "xlsx_path": xlsx_path,
                    "score": 0.0,
                    "grade": "ERR",
                    "report": {},
                })

        refiner.refine_batch(batch_results, output_dir=str(output_dir_path))

    else:
        parser.print_help()
        print("\nEither provide --sql + --xlsx, or --output-dir + --inputs-dir")
        sys.exit(1)


if __name__ == "__main__":
    main()
