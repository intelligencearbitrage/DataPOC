"""
Agents package for SQL Reverse Engineering.

Provides the agentic validation & refinement layer:
    prompts    - Centralized prompts for validator and refiner
    validator  - Lineage CSV and structured XLSX validation against source SQL
    refiner    - Output patching based on validation errors and human feedback
"""
