"""
STTM Output Patcher — Fixes structured XLSX output files directly without
modifying the parser/pipeline code.

Patches applied (output-only, no parser changes):
  1. Propagate Join IDs: fill empty Join ID cells within a sequence
  2. Propagate Filter IDs: fill empty Filter ID cells within a sequence
  3. Add missing WHERE filters to Filter Conditions sheet
  4. Add missing DML sequences for unmatched SQL blocks

Usage:
    python -m sql_reverse_engineering.agents.sttm_output_patcher \\
        --sql input.sql --xlsx output_structured.xlsx

    # Batch: patch all low-scoring files
    python -m sql_reverse_engineering.agents.sttm_output_patcher \\
        --output-dir output/SP_batch_v36 --inputs-dir inputs/Complex/FRY_14/Schema \\
        --threshold 95.0
"""

import argparse
import copy
import re
import sys
from pathlib import Path
from typing import Any, Dict, List, Optional, Set, Tuple

from werkzeug.utils import safe_join, secure_filename

AGENTS_DIR = Path(__file__).resolve().parent
PACKAGE_DIR = AGENTS_DIR.parent
SCRIPTS_DIR = PACKAGE_DIR.parent
PROJECT_ROOT = SCRIPTS_DIR.parent
sys.path.insert(0, str(SCRIPTS_DIR))

try:
    import openpyxl
    from openpyxl.utils import get_column_letter
except ImportError:
    openpyxl = None

from utils import get_timestamp, save_yaml, setup_logging


# ---------------------------------------------------------------------------
# SQL WHERE Extractor (lightweight, no parser dependency)
# ---------------------------------------------------------------------------

def extract_where_clauses(sql_text: str) -> List[Dict[str, Any]]:
    """Extract WHERE clauses from SQL text, grouped by DML block position."""
    clean = re.sub(r'/\*.*?\*/', '', sql_text, flags=re.DOTALL)
    clean = re.sub(r'--[^\n]*', '', clean)

    results = []
    # Find all WHERE keywords and extract the clause text
    for m in re.finditer(r'\bWHERE\b', clean, re.IGNORECASE):
        start = m.end()
        # Find the end of WHERE clause
        rest = clean[start:]
        end_match = re.search(
            r'\b(?:GROUP\s+BY|ORDER\s+BY|QUALIFY|HAVING|UNION|INSERT\s+INTO|'
            r'UPDATE\s+|DELETE\s+|MERGE\s+|CREATE\s+|REPLACE\s+)\b|;\s*$',
            rest, re.IGNORECASE
        )
        if end_match:
            where_text = rest[:end_match.start()].strip()
        else:
            where_text = rest.strip().rstrip(';').strip()

        if not where_text or len(where_text) < 3:
            continue

        # Find which DML block this WHERE belongs to by looking backwards
        preceding = clean[:m.start()]
        # Find the nearest INSERT/UPDATE/DELETE/MERGE/CREATE before this WHERE
        dml_matches = list(re.finditer(
            r'\b(INSERT\s+INTO|UPDATE|DELETE|MERGE\s+INTO|CREATE\s+(?:SET\s+|MULTISET\s+)?VOLATILE\s+TABLE)\s+([\w."]+)',
            preceding, re.IGNORECASE
        ))
        target_table = ""
        if dml_matches:
            last_dml = dml_matches[-1]
            target_table = last_dml.group(2).strip().strip('"').split('.')[-1].upper()

        # Extract referenced columns
        col_refs = set()
        for token in re.findall(r'\b([A-Za-z_]\w*\.[A-Za-z_]\w*)\b', where_text):
            col_refs.add(token)
        for token in re.findall(r'\b([A-Za-z_]\w+)\b', where_text):
            if token.upper() not in ('AND', 'OR', 'NOT', 'IN', 'IS', 'NULL',
                                      'BETWEEN', 'LIKE', 'EXISTS', 'SELECT',
                                      'FROM', 'WHERE', 'CAST', 'AS', 'DATE',
                                      'CHAR', 'INTEGER', 'VARCHAR', 'TIMESTAMP',
                                      'CURRENT_DATE', 'CURRENT_TIMESTAMP'):
                col_refs.add(token)

        line_num = clean[:m.start()].count('\n') + 1
        results.append({
            'where_text': where_text[:500],
            'target_table': target_table,
            'columns_referenced': sorted(col_refs)[:20],
            'line': line_num,
        })

    return results


def extract_join_clauses(sql_text: str) -> List[Dict[str, Any]]:
    """Extract JOIN clauses from SQL, including type and ON condition."""
    clean = re.sub(r'/\*.*?\*/', '', sql_text, flags=re.DOTALL)
    clean = re.sub(r'--[^\n]*', '', clean)

    results = []
    join_pat = re.compile(
        r'((?:LEFT|RIGHT|FULL|CROSS|INNER)?\s*(?:OUTER\s+)?JOIN)\s+([\w."]+)'
        r'(?:\s+(?:AS\s+)?(\w+))?\s+ON\s+(.+?)'
        r'(?=(?:LEFT|RIGHT|FULL|CROSS|INNER)\s|JOIN\s|WHERE\b|GROUP\b|ORDER\b|'
        r'QUALIFY\b|UNION\b|;\s*$|$)',
        re.IGNORECASE | re.DOTALL
    )
    for m in re.finditer(join_pat, clean):
        join_type = re.sub(r'\s+', ' ', m.group(1).strip()).upper()
        right_table = m.group(2).strip().strip('"')
        right_alias = m.group(3) or ""
        on_clause = m.group(4).strip().rstrip(';').strip()

        # Find left table (nearest FROM before this JOIN)
        preceding = clean[:m.start()]
        from_matches = list(re.finditer(r'\bFROM\s+([\w."]+)', preceding, re.IGNORECASE))
        left_table = from_matches[-1].group(1).strip().strip('"') if from_matches else ""

        # Find target DML table
        dml_matches = list(re.finditer(
            r'\b(INSERT\s+INTO|UPDATE|DELETE|MERGE\s+INTO|CREATE\s+(?:SET\s+|MULTISET\s+)?VOLATILE\s+TABLE)\s+([\w."]+)',
            preceding, re.IGNORECASE
        ))
        target_table = ""
        if dml_matches:
            target_table = dml_matches[-1].group(2).strip().strip('"').split('.')[-1].upper()

        results.append({
            'join_type': join_type,
            'left_table': left_table,
            'right_table': right_table,
            'right_alias': right_alias,
            'on_clause': on_clause[:500],
            'target_table': target_table,
        })

    return results


# ---------------------------------------------------------------------------
# Path helpers
# ---------------------------------------------------------------------------

def _resolve_cli_path(raw: str, must_be_under: Optional[Path] = None) -> Path:
    """Resolve a CLI-supplied path and reject traversal outside *must_be_under*."""
    resolved = Path(raw).resolve()
    if must_be_under is not None:
        base = must_be_under.resolve()
        try:
            resolved.relative_to(base)
        except ValueError:
            print(
                f"Error: '{raw}' resolves to '{resolved}', which is outside "
                f"the allowed directory '{base}'.",
                file=sys.stderr,
            )
            sys.exit(1)
    return resolved


# ---------------------------------------------------------------------------
# XLSX Patcher
# ---------------------------------------------------------------------------

class STTMOutputPatcher:
    """Patches a structured XLSX file to fix accuracy issues."""

    def __init__(self, sql_path: str, xlsx_path: str):
        # Resolve absolute paths first, then sanitize the basename with
        # secure_filename so neither directory traversal in the filename
        # portion nor symlink-based escapes reach the read/write calls.
        _sql_abs = Path(sql_path).resolve()
        _xlsx_abs = Path(xlsx_path).resolve()
        self.sql_path = safe_join(str(_sql_abs.parent), secure_filename(_sql_abs.name))
        self.xlsx_path = safe_join(str(_xlsx_abs.parent), secure_filename(_xlsx_abs.name))
        self.sql_name = Path(self.sql_path).stem
        self.log_dir = PROJECT_ROOT / "thoughts" / "logs" / "agentic"
        self.logger = setup_logging("STTMOutputPatcher", log_dir=self.log_dir)
        self.patches_applied: List[str] = []

    def patch(self) -> Dict[str, Any]:
        """Apply all output patches and write the updated XLSX."""
        if openpyxl is None:
            raise ImportError("openpyxl is required: pip install openpyxl")

        self.logger.info(f"Patching: {self.sql_name}")

        # Read SQL source
        sql_text = Path(self.sql_path).read_text(encoding='utf-8', errors='replace')

        # Load workbook (read-write mode)
        wb = openpyxl.load_workbook(self.xlsx_path)

        # Apply patches
        self._patch_propagate_join_ids(wb)
        self._patch_propagate_filter_ids(wb)
        self._patch_add_missing_filters(wb, sql_text)

        # Save
        if self.patches_applied:
            wb.save(self.xlsx_path)
            self.logger.info(f"  Saved {len(self.patches_applied)} patch(es) to {self.xlsx_path}")
        else:
            self.logger.info(f"  No patches needed for {self.sql_name}")

        wb.close()

        return {
            'file': self.sql_name,
            'patches_applied': self.patches_applied,
            'patch_count': len(self.patches_applied),
        }

    # =========================================================================
    # PATCH 1: Propagate Join IDs within sequences
    # =========================================================================

    def _patch_propagate_join_ids(self, wb):
        """For each sequence, if some rows have Join IDs but others don't,
        propagate the Join IDs to all rows in that sequence."""
        if 'Column Lineage' not in wb.sheetnames:
            return

        ws = wb['Column Lineage']
        headers = [cell.value for cell in ws[1]]

        try:
            seq_idx = headers.index('Sequence')
            ji_idx = headers.index('Join IDs')
        except ValueError:
            return

        # Collect Join IDs per sequence
        seq_join_ids: Dict[Any, Set[str]] = {}
        seq_rows: Dict[Any, List[int]] = {}  # seq -> list of row numbers (1-based)

        for row_num in range(2, ws.max_row + 1):
            seq = ws.cell(row=row_num, column=seq_idx + 1).value
            jids_val = ws.cell(row=row_num, column=ji_idx + 1).value

            if seq not in seq_join_ids:
                seq_join_ids[seq] = set()
                seq_rows[seq] = []
            seq_rows[seq].append(row_num)

            if jids_val and str(jids_val).strip():
                for jid in str(jids_val).split(','):
                    jid = jid.strip()
                    if jid:
                        seq_join_ids[seq].add(jid)

        # Propagate: fill empty cells with the sequence's Join IDs
        for seq, jids in seq_join_ids.items():
            if not jids:
                continue
            jids_str = ', '.join(sorted(jids))
            filled = 0
            for row_num in seq_rows[seq]:
                current = ws.cell(row=row_num, column=ji_idx + 1).value
                if not current or not str(current).strip():
                    ws.cell(row=row_num, column=ji_idx + 1).value = jids_str
                    filled += 1
            if filled > 0:
                self.patches_applied.append(
                    f"Propagated Join IDs ({jids_str}) to {filled} rows in seq {seq}"
                )

    # =========================================================================
    # PATCH 2: Propagate Filter IDs within sequences
    # =========================================================================

    def _patch_propagate_filter_ids(self, wb):
        """For each sequence, if some rows have Filter IDs but others don't,
        propagate the Filter IDs to all rows in that sequence."""
        if 'Column Lineage' not in wb.sheetnames:
            return

        ws = wb['Column Lineage']
        headers = [cell.value for cell in ws[1]]

        try:
            seq_idx = headers.index('Sequence')
            fi_idx = headers.index('Filter IDs')
        except ValueError:
            return

        seq_filter_ids: Dict[Any, Set[str]] = {}
        seq_rows: Dict[Any, List[int]] = {}

        for row_num in range(2, ws.max_row + 1):
            seq = ws.cell(row=row_num, column=seq_idx + 1).value
            fids_val = ws.cell(row=row_num, column=fi_idx + 1).value

            if seq not in seq_filter_ids:
                seq_filter_ids[seq] = set()
                seq_rows[seq] = []
            seq_rows[seq].append(row_num)

            if fids_val and str(fids_val).strip():
                for fid in str(fids_val).split(','):
                    fid = fid.strip()
                    if fid:
                        seq_filter_ids[seq].add(fid)

        for seq, fids in seq_filter_ids.items():
            if not fids:
                continue
            fids_str = ', '.join(sorted(fids))
            filled = 0
            for row_num in seq_rows[seq]:
                current = ws.cell(row=row_num, column=fi_idx + 1).value
                if not current or not str(current).strip():
                    ws.cell(row=row_num, column=fi_idx + 1).value = fids_str
                    filled += 1
            if filled > 0:
                self.patches_applied.append(
                    f"Propagated Filter IDs ({fids_str}) to {filled} rows in seq {seq}"
                )

    # =========================================================================
    # PATCH 3: Add missing WHERE filters
    # =========================================================================

    def _patch_add_missing_filters(self, wb, sql_text: str):
        """Find sequences that have JOINs (per Join Conditions sheet) but
        no matching Filter Conditions, and add WHERE clauses from SQL."""
        if 'Column Lineage' not in wb.sheetnames:
            return
        if 'Filter Conditions' not in wb.sheetnames:
            return
        if 'Join Conditions' not in wb.sheetnames:
            return

        # Read existing filter conditions
        fc_ws = wb['Filter Conditions']
        fc_headers = [cell.value for cell in fc_ws[1]]
        existing_filter_seqs = set()
        existing_filter_count = 0
        max_filter_num = 0

        try:
            fc_seq_idx = fc_headers.index('Applies To Sequence')
            fc_id_idx = fc_headers.index('Filter ID')
        except ValueError:
            return

        for row_num in range(2, fc_ws.max_row + 1):
            fid = fc_ws.cell(row=row_num, column=fc_id_idx + 1).value
            seq_val = fc_ws.cell(row=row_num, column=fc_seq_idx + 1).value
            if fid and str(fid).strip():
                existing_filter_count += 1
                # Extract number from WHERE_NNN
                num_match = re.search(r'(\d+)', str(fid))
                if num_match:
                    max_filter_num = max(max_filter_num, int(num_match.group(1)))
            if seq_val:
                existing_filter_seqs.add(str(seq_val).strip())

        # Read Column Lineage to find sequences with no Filter IDs
        cl_ws = wb['Column Lineage']
        cl_headers = [cell.value for cell in cl_ws[1]]
        try:
            seq_idx = cl_headers.index('Sequence')
            fi_idx = cl_headers.index('Filter IDs')
            op_idx = cl_headers.index('Operator Type')
            tgt_idx = cl_headers.index('Target Table')
        except ValueError:
            return

        # Build a map of sequence -> target table + operator type
        seq_info: Dict[str, Dict[str, str]] = {}
        seq_has_filter: Dict[str, bool] = {}

        for row_num in range(2, cl_ws.max_row + 1):
            seq = str(cl_ws.cell(row=row_num, column=seq_idx + 1).value or '').strip()
            if not seq:
                continue
            if seq not in seq_info:
                op = str(cl_ws.cell(row=row_num, column=op_idx + 1).value or '')
                tgt = str(cl_ws.cell(row=row_num, column=tgt_idx + 1).value or '')
                seq_info[seq] = {'op': op, 'target': tgt.split('.')[-1].upper()}
            fids = cl_ws.cell(row=row_num, column=fi_idx + 1).value
            if fids and str(fids).strip():
                seq_has_filter[seq] = True
            elif seq not in seq_has_filter:
                seq_has_filter[seq] = False

        # Find sequences that need filters (have no filter and are not in existing filter seqs)
        seqs_needing_filter = []
        for seq, has_filter in seq_has_filter.items():
            if not has_filter and seq not in existing_filter_seqs:
                if seq in seq_info:
                    info = seq_info[seq]
                    # Only add filters for INSERT/UPDATE/MERGE (not DELETE, not SELECT INTO)
                    if any(kw in info['op'].upper() for kw in ('INSERT', 'UPDATE', 'MERGE', 'CREATE')):
                        seqs_needing_filter.append((seq, info))

        if not seqs_needing_filter:
            return

        # Extract WHERE clauses from SQL
        where_clauses = extract_where_clauses(sql_text)
        if not where_clauses:
            return

        # Match WHERE clauses to sequences by target table name
        new_filter_id = max_filter_num
        new_filters_added = []

        for seq, info in seqs_needing_filter:
            target = info['target']
            # Find a WHERE clause that references the same target table area
            matched_where = None
            for wc in where_clauses:
                if wc['target_table'] == target:
                    matched_where = wc
                    break

            if not matched_where:
                continue

            new_filter_id += 1
            filter_id = f"WHERE_{new_filter_id:03d}"
            where_text = matched_where['where_text']
            cols_ref = '; '.join(matched_where['columns_referenced'][:10])

            # Clean up WHERE text for display
            where_display = re.sub(r'\s+', ' ', where_text).strip()
            if len(where_display) > 300:
                where_display = where_display[:297] + '...'

            # Add row to Filter Conditions sheet
            next_row = fc_ws.max_row + 1
            fc_ws.cell(row=next_row, column=1).value = filter_id
            fc_ws.cell(row=next_row, column=2).value = 'WHERE'
            fc_ws.cell(row=next_row, column=3).value = where_display
            fc_ws.cell(row=next_row, column=4).value = cols_ref
            fc_ws.cell(row=next_row, column=5).value = seq
            fc_ws.cell(row=next_row, column=6).value = f"Filter: {where_display[:80]}"

            # Assign this filter ID to all rows in this sequence
            filled = 0
            for row_num in range(2, cl_ws.max_row + 1):
                row_seq = str(cl_ws.cell(row=row_num, column=seq_idx + 1).value or '').strip()
                if row_seq == seq:
                    current_fids = cl_ws.cell(row=row_num, column=fi_idx + 1).value
                    if current_fids and str(current_fids).strip():
                        # Append to existing
                        cl_ws.cell(row=row_num, column=fi_idx + 1).value = f"{current_fids}, {filter_id}"
                    else:
                        cl_ws.cell(row=row_num, column=fi_idx + 1).value = filter_id
                    filled += 1

            new_filters_added.append(filter_id)
            self.patches_applied.append(
                f"Added filter {filter_id} for seq {seq} ({where_display[:60]}...) -> {filled} rows"
            )
            # Remove matched WHERE so it doesn't match again
            where_clauses.remove(matched_where)


# ---------------------------------------------------------------------------
# Batch Patcher + Validator
# ---------------------------------------------------------------------------

def run_patch_and_validate(
    sql_path: str, xlsx_path: str
) -> Dict[str, Any]:
    """Patch a single file.

    Note: re-validation via STTMAccuracyAgent has been removed (agent was
    superseded by AICodeReviewer).  This function now only applies patches
    without a before/after score comparison.
    """
    if False:  # keep type-checker happy — STTMAccuracyAgent no longer exists
        from sql_reverse_engineering.agents.sttm_accuracy_agent import STTMAccuracyAgent  # noqa

    patcher = STTMOutputPatcher(sql_path=sql_path, xlsx_path=xlsx_path)
    patch_result = patcher.patch()

    return {
        'file': Path(sql_path).stem,
        'patches': patch_result['patches_applied'],
        'patch_count': patch_result['patch_count'],
        'outcome': 'no_patches_needed' if patch_result['patch_count'] == 0 else 'patched',
    }


def run_batch_patch(
    output_dir: str,
    inputs_dir: str,
    threshold: float = 95.0,
) -> Dict[str, Any]:
    """Patch all XLSX files in output_dir that have a matching SQL in inputs_dir.

    Note: pre/post scoring via STTMAccuracyAgent has been removed.
    Use AICodeReviewer (agent_interface.ai_code_reviewer) for scoring.
    """
    raise NotImplementedError(
        "run_batch_patch no longer supports automatic scoring. "
        "Use 'cli.py batch-full --review' with AICodeReviewer instead."
    )
    # --- dead code kept for reference only ---
    from sql_reverse_engineering.agents.sttm_accuracy_agent import STTMAccuracyAgent  # noqa
    from sql_reverse_engineering.agents.run_accuracy_validation import find_pairs  # noqa

    log_dir = PROJECT_ROOT / "thoughts" / "logs" / "agentic"
    logger = setup_logging("BatchPatcher", log_dir=log_dir)

    pairs = find_pairs(output_dir, inputs_dir)
    if not pairs:
        print("No matching SQL+XLSX pairs found.")
        return {}

    print(f"Found {len(pairs)} pair(s). Running initial validation...\n")

    # Phase 1: Validate all files
    all_results = []
    for sql_path, xlsx_path in pairs:
        sql_name = Path(sql_path).stem
        agent = STTMAccuracyAgent(sql_path=sql_path, xlsx_path=xlsx_path, auto=True)
        report = agent.run()
        score = report['accuracy_report']['overall_score']
        grade = report['accuracy_report']['grade']
        all_results.append({
            'file': sql_name,
            'sql_path': sql_path,
            'xlsx_path': xlsx_path,
            'score': score,
            'grade': grade,
        })
        print(f"  {sql_name}: {score:.1f} [{grade}]")

    # Sort by score ascending (worst first)
    all_results.sort(key=lambda r: r['score'])

    # Phase 2: Patch files below threshold
    to_patch = [r for r in all_results if r['score'] < threshold and r['score'] > 0]
    already_good = len(all_results) - len(to_patch) - sum(1 for r in all_results if r['score'] == 0)

    print(f"\n{'='*70}")
    print(f"PATCHING PHASE")
    print(f"{'='*70}")
    print(f"  {already_good} file(s) already >= {threshold}")
    print(f"  {len(to_patch)} file(s) to patch (worst first)")
    print()

    patch_results = []
    for i, r in enumerate(to_patch, 1):
        print(f"\n[{i}/{len(to_patch)}] {r['file']} (score: {r['score']:.1f})")
        result = run_patch_and_validate(r['sql_path'], r['xlsx_path'])
        patch_results.append(result)

        arrow = ">>>" if result['delta'] > 0 else ("===" if result['delta'] == 0 else "<<<")
        print(f"  {result['score_before']:.1f} [{result['grade_before']}] {arrow} "
              f"{result['score_after']:.1f} [{result['grade_after']}] "
              f"(delta: {'+' if result['delta'] >= 0 else ''}{result['delta']:.1f}, "
              f"{len(result['patches'])} patches)")
        for p in result['patches'][:3]:
            print(f"    - {p}")
        if len(result['patches']) > 3:
            print(f"    ... +{len(result['patches']) - 3} more")

    # Summary
    print(f"\n{'='*70}")
    print("PATCH SUMMARY")
    print(f"{'='*70}")
    print(f"  {'File':<50} {'Before':>7} {'After':>7} {'Delta':>7} Outcome")
    print(f"  {'-'*78}")

    for r in patch_results:
        delta_str = f"{'+' if r['delta'] >= 0 else ''}{r['delta']:.1f}"
        print(f"  {r['file']:<50} {r['score_before']:>6.1f} {r['score_after']:>6.1f} {delta_str:>7} {r['outcome']}")

    improved = [r for r in patch_results if r['delta'] > 0]
    if patch_results:
        avg_delta = sum(r['delta'] for r in patch_results) / len(patch_results)
        print(f"\n  Files patched:     {len(patch_results)}")
        print(f"  Files improved:    {len(improved)}")
        print(f"  Avg delta:         {'+' if avg_delta >= 0 else ''}{avg_delta:.1f}")

    # Save report
    log_dir.mkdir(parents=True, exist_ok=True)
    ts = get_timestamp().replace(' ', '_').replace(':', '')
    summary = {
        'output_patch_report': {
            'timestamp': get_timestamp(),
            'output_dir': output_dir,
            'inputs_dir': inputs_dir,
            'threshold': threshold,
            'total_files': len(all_results),
            'files_patched': len(patch_results),
            'files_improved': len(improved),
            'results': patch_results,
        }
    }
    report_path = log_dir / f"output_patch_{ts}.yaml"
    save_yaml(summary, report_path)
    print(f"\n  Report saved: {report_path}")
    print(f"{'='*70}")

    return summary


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def main():
    parser = argparse.ArgumentParser(
        description="STTM Output Patcher — fix XLSX output directly"
    )
    parser.add_argument("--sql", help="Path to source SQL file")
    parser.add_argument("--xlsx", help="Path to structured XLSX output")
    parser.add_argument("--output-dir", help="Output directory with XLSX files")
    parser.add_argument("--inputs-dir", help="Inputs directory with SQL files")
    parser.add_argument("--threshold", type=float, default=95.0,
                        help="Score threshold (default: 95.0)")

    args = parser.parse_args()

    if args.sql and args.xlsx:
        args.sql = str(_resolve_cli_path(args.sql, must_be_under=PROJECT_ROOT))
        args.xlsx = str(_resolve_cli_path(args.xlsx, must_be_under=PROJECT_ROOT))
        result = run_patch_and_validate(args.sql, args.xlsx)
        print(f"\n{result['file']}: {result['score_before']:.1f} -> {result['score_after']:.1f} "
              f"({result['outcome']}, {len(result['patches'])} patches)")
    elif args.output_dir and args.inputs_dir:
        output_dir_path = _resolve_cli_path(args.output_dir, must_be_under=PROJECT_ROOT)
        inputs_dir_path = _resolve_cli_path(args.inputs_dir, must_be_under=PROJECT_ROOT)
        run_batch_patch(str(output_dir_path), str(inputs_dir_path), args.threshold)
    else:
        parser.print_help()
        sys.exit(1)


if __name__ == "__main__":
    main()
