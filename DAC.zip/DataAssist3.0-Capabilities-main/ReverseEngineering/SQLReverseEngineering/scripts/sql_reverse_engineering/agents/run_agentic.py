"""
Agentic Workflow Runner - Single entry point for validate-review-refine loop.

Orchestrates the full agentic workflow:
  1. Validate output against source SQL
  2. Show results and prompt for human review
  3. Optionally refine with automated loop + human feedback

Usage:
    python -m sql_reverse_engineering.agents.run_agentic
    python -m sql_reverse_engineering.agents.run_agentic --output-dir output/FRY14Q_SP_STTM
    python -m sql_reverse_engineering.agents.run_agentic --auto  (skip prompts, validate + refine)
"""

import argparse
import sys
from pathlib import Path

AGENTS_DIR = Path(__file__).resolve().parent
PACKAGE_DIR = AGENTS_DIR.parent
SCRIPTS_DIR = PACKAGE_DIR.parent
PROJECT_ROOT = SCRIPTS_DIR.parent
sys.path.insert(0, str(SCRIPTS_DIR))

from sql_reverse_engineering.agents.validator import STTMValidator
from sql_reverse_engineering.agents.refiner import STTMRefiner
from utils import get_timestamp


def prompt_user(message: str, choices: list[str]) -> str:
    """Prompt the user for a choice. Returns the chosen option."""
    print(f"\n{message}")
    for i, choice in enumerate(choices, 1):
        print(f"  {i}. {choice}")
    while True:
        try:
            raw = input(f"\nEnter choice (1-{len(choices)}): ").strip()
            idx = int(raw)
            if 1 <= idx <= len(choices):
                return choices[idx - 1]
        except (ValueError, EOFError):
            pass
        print(f"Please enter a number between 1 and {len(choices)}")


def prompt_feedback() -> str:
    """Prompt the user for optional feedback text."""
    print("\nEnter feedback for the refiner (one item per line, empty line to finish):")
    lines = []
    try:
        while True:
            line = input("  > ")
            if not line.strip():
                break
            lines.append(line.strip())
    except EOFError:
        pass
    return "\n".join(lines)


def run_workflow(
    output_dir: str,
    inputs_dir: str,
    max_iterations: int,
    auto: bool,
) -> None:
    """Run the full agentic workflow."""

    # =========================================================================
    # STEP 1: VALIDATE
    # =========================================================================
    print("\n" + "=" * 60)
    print("STEP 1: VALIDATION")
    print("=" * 60)

    validator = STTMValidator(
        output_dir=output_dir,
        inputs_dir=inputs_dir,
    )
    validator.validate()
    report = validator.generate_report()
    report_path = validator.save_report(report)
    validator.print_summary(report)

    vr = report["validation_report"]
    issues = vr["issues"]

    if not issues:
        print("\nNo issues found — output is clean!")
        return

    # =========================================================================
    # STEP 2: HUMAN REVIEW (first pass)
    # =========================================================================
    if auto:
        decision = "Proceed to refinement"
        feedback = None
    else:
        decision = prompt_user(
            f"Found {len(issues)} issue(s). What would you like to do?",
            [
                "Accept output as-is",
                "Proceed to refinement",
                "Proceed to refinement with feedback",
            ],
        )

        if decision == "Accept output as-is":
            print("\nOutput accepted. No refinement performed.")
            return

        feedback = None
        if decision == "Proceed to refinement with feedback":
            feedback = prompt_feedback()
            if not feedback:
                print("No feedback provided — proceeding without feedback.")
                feedback = None

    # =========================================================================
    # STEP 3: REFINE
    # =========================================================================
    print("\n" + "=" * 60)
    print("STEP 3: REFINEMENT LOOP")
    print("=" * 60)

    # Write feedback to temp file if provided
    feedback_path = None
    if feedback:
        feedback_file = PROJECT_ROOT / "thoughts" / "logs" / "agentic" / "user_feedback.txt"
        feedback_file.parent.mkdir(parents=True, exist_ok=True)
        feedback_file.write_text(feedback, encoding="utf-8")
        feedback_path = str(feedback_file)
        print(f"Feedback saved: {feedback_file}")

    refiner = STTMRefiner(
        report_path=str(report_path),
        feedback_path=feedback_path,
        max_iterations=max_iterations,
        output_dir=output_dir,
        inputs_dir=inputs_dir,
    )
    result = refiner.run()

    # =========================================================================
    # STEP 4: FINAL REVIEW
    # =========================================================================
    if auto:
        print("\nAuto mode — workflow complete.")
        return

    # Re-validate to show final state
    print("\n" + "=" * 60)
    print("STEP 4: FINAL REVIEW")
    print("=" * 60)

    final_validator = STTMValidator(
        output_dir=output_dir,
        inputs_dir=inputs_dir,
    )
    final_validator.validate()
    final_report = final_validator.generate_report()
    final_validator.save_report(final_report)
    final_validator.print_summary(final_report)

    final_issues = final_report["validation_report"]["issues"]

    if not final_issues:
        print("\nAll issues resolved!")
        return

    # Offer another round
    while True:
        decision = prompt_user(
            f"{len(final_issues)} issue(s) remain. What would you like to do?",
            [
                "Accept output as final",
                "Add feedback and re-run refinement",
                "Dismiss remaining issues",
            ],
        )

        if decision in ("Accept output as final", "Dismiss remaining issues"):
            print("\nOutput accepted.")
            return

        if decision == "Add feedback and re-run refinement":
            new_feedback = prompt_feedback()
            if not new_feedback:
                print("No feedback — skipping.")
                continue

            feedback_file = PROJECT_ROOT / "thoughts" / "logs" / "agentic" / "user_feedback.txt"
            feedback_file.write_text(new_feedback, encoding="utf-8")

            refiner = STTMRefiner(
                feedback_path=str(feedback_file),
                max_iterations=max_iterations,
                output_dir=output_dir,
                inputs_dir=inputs_dir,
            )
            refiner.run()

            # Re-validate
            final_validator = STTMValidator(
                output_dir=output_dir,
                inputs_dir=inputs_dir,
            )
            final_validator.validate()
            final_report = final_validator.generate_report()
            final_validator.save_report(final_report)
            final_validator.print_summary(final_report)
            final_issues = final_report["validation_report"]["issues"]

            if not final_issues:
                print("\nAll issues resolved!")
                return


def main():
    """Entry point."""
    parser = argparse.ArgumentParser(
        description="Run the full agentic validate-review-refine workflow"
    )
    parser.add_argument(
        "--output-dir",
        default="output/FRY14Q_SP",
        help="Directory containing output files to validate (default: output/FRY14Q_SP)",
    )
    parser.add_argument(
        "--inputs-dir",
        default="inputs",
        help="Directory containing source SQL files (default: inputs)",
    )
    parser.add_argument(
        "--max-iterations",
        type=int,
        default=3,
        help="Max refinement iterations per loop (default: 3)",
    )
    parser.add_argument(
        "--auto",
        action="store_true",
        help="Auto mode — skip prompts, validate then refine automatically",
    )
    args = parser.parse_args()

    run_workflow(
        output_dir=args.output_dir,
        inputs_dir=args.inputs_dir,
        max_iterations=args.max_iterations,
        auto=args.auto,
    )


if __name__ == "__main__":
    main()
