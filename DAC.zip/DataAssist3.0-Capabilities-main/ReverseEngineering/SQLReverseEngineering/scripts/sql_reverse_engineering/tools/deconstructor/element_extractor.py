"""
SQL Element Extractor module.

Main orchestrator that extracts all SQL elements from a parsed AST.
Coordinates the individual extractors and builds the complete ElementCatalog.
"""

import sqlglot
from sqlglot import exp
from typing import List, Optional, Dict
import uuid
import sys
import os

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from models.data_models import (
    ElementCatalog, WhereClause, WhereCondition, GroupByClause,
    OrderByClause, ColumnRef
)
from deconstructor.case_extractor import CaseExtractor
from deconstructor.join_extractor import JoinExtractor
from deconstructor.function_extractor import FunctionExtractor
from deconstructor.subquery_cte_extractor import SubqueryCTEExtractor


class SQLElementExtractor:
    """
    Traverse AST and extract all SQL elements with full detail.
    Main orchestrator for the deconstructor module.
    """

    def __init__(self, ast: exp.Expression, dialect: str = "teradata", volatile_handler=None):
        """
        Initialize extractor with parsed AST.

        Args:
            ast: Parsed SQL AST
            dialect: SQL dialect
            volatile_handler: VolatileTableHandler instance for accessing volatile table definitions
        """
        self.ast = ast
        self.dialect = dialect
        self.volatile_handler = volatile_handler

        # Initialize individual extractors
        self.case_extractor = CaseExtractor(dialect)
        self.join_extractor = JoinExtractor(dialect)
        self.function_extractor = FunctionExtractor(dialect)
        self.subquery_cte_extractor = SubqueryCTEExtractor(dialect)

    def extract_all(self) -> ElementCatalog:
        """
        Main extraction method - calls all extractors and builds ElementCatalog.

        Returns:
            ElementCatalog with all extracted elements
        """
        # Determine statement type
        statement_type = self._get_statement_type()

        # Find source and target tables
        source_tables = self._extract_source_tables()
        target_table = self._extract_target_table()

        # Extract CTEs including volatile tables
        ctes = self.subquery_cte_extractor.extract_ctes(self.ast)
        
        # Extract volatile tables from volatile_handler if available
        volatile_ctes = []
        if self.volatile_handler:
            print(f"  DEBUG Element Extractor: volatile_handler exists, extracting from handler...")
            volatile_ctes = self._extract_volatile_tables_from_handler()
            print(f"  DEBUG Element Extractor: Extracted {len(volatile_ctes)} volatile CTEs from handler")
        else:
            print(f"  DEBUG Element Extractor: No volatile_handler, trying AST extraction...")
            # Fallback: try to extract from AST (for single-statement files)
            volatile_ctes = self._extract_volatile_tables_as_ctes()
            print(f"  DEBUG Element Extractor: Extracted {len(volatile_ctes)} volatile CTEs from AST")
        
        print(f"  DEBUG Element Extractor: Total CTEs = {len(ctes)} standard + {len(volatile_ctes)} volatile = {len(ctes) + len(volatile_ctes)}")
        all_ctes = ctes + volatile_ctes

        return ElementCatalog(
            statement_id=str(uuid.uuid4())[:8],
            statement_type=statement_type,
            raw_sql=self.ast.sql(dialect=self.dialect),
            case_statements=self.case_extractor.extract(self.ast),
            functions=self.function_extractor.extract(self.ast),
            joins=self.join_extractor.extract(self.ast),
            where_clause=self._extract_where_clause(),
            ctes=all_ctes,
            subqueries=self.subquery_cte_extractor.extract_subqueries(self.ast),
            group_by=self._extract_group_by(),
            order_by=self._extract_order_by(),
            source_tables=source_tables,
            target_table=target_table
        )

    def _get_statement_type(self) -> str:
        """
        Determine the type of SQL statement.

        Returns:
            Statement type string
        """
        # Check for SELECT INTO (Teradata SPL: SELECT ... INTO variable ... FROM ...)
        # sqlglot parses this as exp.Select with an 'into' arg
        if isinstance(self.ast, exp.Select) and self.ast.args.get('into'):
            return "SELECT INTO"

        type_map = {
            exp.Select: "SELECT",
            exp.Insert: "INSERT",
            exp.Update: "UPDATE",
            exp.Delete: "DELETE",
            exp.Create: "CREATE",
            exp.Drop: "DROP",
            exp.Alter: "ALTER",
            exp.Merge: "MERGE",
            exp.Union: "UNION",
        }

        for exp_type, name in type_map.items():
            if isinstance(self.ast, exp_type):
                return name

        return self.ast.__class__.__name__.upper()

    def _extract_source_tables(self) -> List[str]:
        """
        Extract all source tables from the query.
        Includes tables from FROM, JOIN, subqueries, CTEs, and UNIONs.
        Excludes target tables and handles schema prefixes correctly.
        
        Returns:
            List of table names
        """
        tables = []
        seen: Set[str] = set()
        
        # Skip the target table in INSERT/UPDATE/DELETE statements
        target = self._extract_target_table()
        if target:
            seen.add(target.lower())
        
        # Helper to add table if not seen
        def add_table(table_name: Optional[str]):
            if table_name and table_name.lower() not in seen:
                seen.add(table_name.lower())
                tables.append(table_name)
        
        # Find all Table expressions in the entire AST
        for table_expression in self.ast.find_all(exp.Table):
            table_name = self._get_table_name_safe(table_expression)
            add_table(table_name)
        
        # Handle UNION statements - each branch may have different tables
        for union_expression in self.ast.find_all(exp.Union):
            # Process left side
            if hasattr(union_expression, 'left') and union_expression.left:
                for table_expression in union_expression.left.find_all(exp.Table):
                    table_name = self._get_table_name_safe(table_expression)
                    add_table(table_name)
            
            # Process right side
            if hasattr(union_expression, 'right') and union_expression.right:
                for table_expression in union_expression.right.find_all(exp.Table):
                    table_name = self._get_table_name_safe(table_expression)
                    add_table(table_name)
        
        # Extract tables from CTEs
        for cte_expression in self.ast.find_all(exp.CTE):
            if hasattr(cte_expression, 'this') and cte_expression.this:
                for table_expression in cte_expression.this.find_all(exp.Table):
                    table_name = self._get_table_name_safe(table_expression)
                    add_table(table_name)
        
        # Extract tables from subqueries
        for subquery_expression in self.ast.find_all(exp.Subquery):
            if hasattr(subquery_expression, 'this') and subquery_expression.this:
                for table_expression in subquery_expression.this.find_all(exp.Table):
                    table_name = self._get_table_name_safe(table_expression)
                    add_table(table_name)
        
        return tables

    def _extract_target_table(self) -> Optional[str]:
        """
        Extract the target table for INSERT/UPDATE/DELETE/MERGE statements.
        Uses _get_table_name_safe for consistent handling of schema prefixes.
        
        Returns:
            Target table name or None
        """
        # Handle INSERT statements
        if isinstance(self.ast, exp.Insert):
            if hasattr(self.ast, 'this') and self.ast.this:
                return self._get_table_name_safe(self.ast.this)
        
        # Handle UPDATE statements
        if isinstance(self.ast, exp.Update):
            if hasattr(self.ast, 'this') and self.ast.this:
                return self._get_table_name_safe(self.ast.this)
        
        # Handle DELETE statements
        if isinstance(self.ast, exp.Delete):
            if hasattr(self.ast, 'this') and self.ast.this:
                return self._get_table_name_safe(self.ast.this)
        
        # Handle MERGE statements
        if isinstance(self.ast, exp.Merge):
            if hasattr(self.ast, 'this') and self.ast.this:
                return self._get_table_name_safe(self.ast.this)
        
        # Handle CREATE TABLE statements
        if isinstance(self.ast, exp.Create):
            if hasattr(self.ast, 'this') and self.ast.this:
                return self._get_table_name_safe(self.ast.this)

        # Handle SELECT INTO (Teradata SPL: SELECT ... INTO variable)
        if isinstance(self.ast, exp.Select):
            into = self.ast.args.get('into')
            if into:
                for tbl in into.find_all(exp.Table):
                    return self._get_table_name_safe(tbl)

        return None

    def _extract_where_clause(self) -> Optional[WhereClause]:
        """
        Extract WHERE clause from the outermost query level only.
        Nested subquery/UNION WHERE clauses are handled by the subquery
        decomposer and should not leak to the root element.

        Returns:
            WhereClause object or None
        """
        # Find the outermost SELECT's WHERE clause only (not nested subqueries)
        main_select = None
        if isinstance(self.ast, exp.Select):
            main_select = self.ast
        elif isinstance(self.ast, exp.Insert):
            # INSERT...SELECT: get the SELECT portion
            sel = self.ast.args.get('expression')
            if isinstance(sel, exp.Select):
                main_select = sel
            elif isinstance(sel, exp.Union):
                # For INSERT...UNION, get WHERE from each branch at top level
                main_select = None
                all_conditions = []
                all_sql_parts = []
                for branch_select in sel.find_all(exp.Select):
                    # Only direct branch SELECTs, not nested subqueries
                    # Check parent chain: stop at the first Select inside a Subquery
                    parent = branch_select.parent
                    is_nested = False
                    while parent and parent is not sel:
                        if isinstance(parent, exp.Subquery):
                            is_nested = True
                            break
                        parent = parent.parent
                    if is_nested:
                        continue
                    where_node = branch_select.args.get("where")
                    if where_node and where_node.this:
                        where_sql = where_node.sql(dialect=self.dialect)
                        all_sql_parts.append(where_sql)
                        conditions = self._parse_where_conditions(where_node.this)
                        all_conditions.extend(conditions)
                if all_conditions:
                    combined_sql = "; ".join(all_sql_parts)
                    return WhereClause(sql_text=combined_sql, conditions=all_conditions)
                return None
        elif isinstance(self.ast, exp.Update):
            main_select = None
            where_node = self.ast.args.get("where")
            if where_node and where_node.this:
                where_sql = where_node.sql(dialect=self.dialect)
                conditions = self._parse_where_conditions(where_node.this)
                if conditions:
                    return WhereClause(sql_text=where_sql, conditions=conditions)
            return None
        elif isinstance(self.ast, exp.Delete):
            main_select = None
            where_node = self.ast.args.get("where")
            if where_node and where_node.this:
                where_sql = where_node.sql(dialect=self.dialect)
                conditions = self._parse_where_conditions(where_node.this)
                if conditions:
                    return WhereClause(sql_text=where_sql, conditions=conditions)
            return None
        elif isinstance(self.ast, exp.Create):
            # CREATE VIEW / CREATE VOLATILE TABLE AS SELECT: find inner SELECT
            inner_select = self.ast.find(exp.Select)
            if inner_select:
                main_select = inner_select

        if main_select is None:
            return None

        where_node = main_select.args.get("where")
        all_conditions = []
        all_sql_parts = []

        if where_node and where_node.this:
            where_sql = where_node.sql(dialect=self.dialect)
            all_sql_parts.append(where_sql)
            all_conditions.extend(self._parse_where_conditions(where_node.this))

        # Also capture QUALIFY clause (Teradata-specific row-level filter)
        qualify_node = main_select.args.get("qualify")
        if qualify_node and qualify_node.this:
            qualify_sql = qualify_node.sql(dialect=self.dialect)
            all_sql_parts.append(qualify_sql)
            all_conditions.extend(self._parse_where_conditions(qualify_node.this))

        if not all_conditions:
            return None

        return WhereClause(
            sql_text="; ".join(all_sql_parts),
            conditions=all_conditions
        )

    def _parse_where_conditions(self, condition_expression: exp.Expression) -> List[WhereCondition]:
        """
        Parse WHERE conditions recursively, handling AND/OR logic.
        
        Args:
            condition_expression: The condition expression to parse
            
        Returns:
            List of WhereCondition objects
        """
        conditions = []
        
        if condition_expression is None:
            return conditions
        
        # Handle AND conditions
        if isinstance(condition_expression, exp.And):
            if hasattr(condition_expression, 'left') and condition_expression.left:
                conditions.extend(self._parse_where_conditions(condition_expression.left))
            if hasattr(condition_expression, 'right') and condition_expression.right:
                conditions.extend(self._parse_where_conditions(condition_expression.right))
            return conditions
        
        # Handle OR conditions
        if isinstance(condition_expression, exp.Or):
            if hasattr(condition_expression, 'left') and condition_expression.left:
                conditions.extend(self._parse_where_conditions(condition_expression.left))
            if hasattr(condition_expression, 'right') and condition_expression.right:
                conditions.extend(self._parse_where_conditions(condition_expression.right))
            return conditions
        
        # Handle individual conditions (EQ, GT, LT, etc.)
        expression_sql = condition_expression.sql(dialect=self.dialect)
        columns_referenced = self._extract_columns_from_expression(condition_expression)
        
        # Determine operator
        operator = self._get_operator_from_expression(condition_expression)
        
        # Check for subquery
        has_subquery = len(list(condition_expression.find_all(exp.Subquery))) > 0
        
        condition = WhereCondition(
            expression=expression_sql,
            columns_referenced=columns_referenced,
            operator=operator,
            has_subquery=has_subquery
        )
        conditions.append(condition)
        
        return conditions

    def _extract_columns(self, expr: exp.Expression) -> List[ColumnRef]:
        """
        Extract all column references from an expression.

        Args:
            expr: SQLGlot expression

        Returns:
            List of ColumnRef objects
        """
        columns = []

        if expr is None:
            return columns

        for col in expr.find_all(exp.Column):
            columns.append(ColumnRef(
                table_name=col.table if col.table else "",
                column_name=col.name
            ))

        return columns

    def _extract_group_by(self) -> Optional[GroupByClause]:
        """
        Extract GROUP BY clause from the query.
        
        Returns:
            GroupByClause object or None
        """
        group_by_expression = self.ast.find(exp.Group)
        
        if not group_by_expression:
            return None
        
        columns = []
        
        # Extract columns from GROUP BY
        if hasattr(group_by_expression, 'expressions'):
            for group_expression in group_by_expression.expressions:
                if isinstance(group_expression, exp.Column):
                    column_name = group_expression.name if hasattr(group_expression, 'name') else ""
                    table_name = ""
                    if hasattr(group_expression, 'table') and group_expression.table:
                        table_name = group_expression.table
                    
                    column_ref = ColumnRef(
                        table_name=table_name,
                        column_name=column_name
                    )
                    columns.append(column_ref)
                elif hasattr(group_expression, 'name'):
                    # Handle other expression types with name attribute
                    column_ref = ColumnRef(
                        table_name="",
                        column_name=group_expression.name
                    )
                    columns.append(column_ref)
        
        if not columns:
            return None
        
        sql_text = group_by_expression.sql(dialect=self.dialect)
        
        return GroupByClause(
            columns=columns,
            sql_text=sql_text
        )

    def _extract_order_by(self) -> Optional[OrderByClause]:
        """
        Extract ORDER BY clause from the query.
        
        Returns:
            OrderByClause object or None
        """
        order_by_expression = self.ast.find(exp.Order)
        
        if not order_by_expression:
            return None
        
        columns = []
        directions = []
        
        # Extract columns and directions from ORDER BY
        if hasattr(order_by_expression, 'expressions'):
            for order_expression in order_by_expression.expressions:
                # Handle Ordered expressions (column with ASC/DESC)
                if isinstance(order_expression, exp.Ordered):
                    # Get the column
                    if hasattr(order_expression, 'this') and order_expression.this:
                        column_expression = order_expression.this
                        if isinstance(column_expression, exp.Column):
                            column_name = column_expression.name if hasattr(column_expression, 'name') else ""
                            table_name = ""
                            if hasattr(column_expression, 'table') and column_expression.table:
                                table_name = column_expression.table
                            
                            column_ref = ColumnRef(
                                table_name=table_name,
                                column_name=column_name
                            )
                            columns.append(column_ref)
                        elif hasattr(column_expression, 'name'):
                            column_ref = ColumnRef(
                                table_name="",
                                column_name=column_expression.name
                            )
                            columns.append(column_ref)
                    
                    # Get direction (default to ASC)
                    direction = "DESC" if order_expression.args.get('desc') else "ASC"
                    directions.append(direction)
                
                # Handle plain Column expressions (default ASC)
                elif isinstance(order_expression, exp.Column):
                    column_name = order_expression.name if hasattr(order_expression, 'name') else ""
                    table_name = ""
                    if hasattr(order_expression, 'table') and order_expression.table:
                        table_name = order_expression.table
                    
                    column_ref = ColumnRef(
                        table_name=table_name,
                        column_name=column_name
                    )
                    columns.append(column_ref)
                    directions.append("ASC")
        
        if not columns:
            return None
        
        sql_text = order_by_expression.sql(dialect=self.dialect)
        
        return OrderByClause(
            columns=columns,
            directions=directions,
            sql_text=sql_text
        )

    def get_all_columns(self) -> List[ColumnRef]:
        """
        Get all columns referenced anywhere in the SQL.

        Returns:
            List of all unique ColumnRef objects
        """
        columns = []

        for col in self.ast.find_all(exp.Column):
            columns.append(ColumnRef(
                table_name=col.table if col.table else "",
                column_name=col.name
            ))

        return list(set(columns))

    def get_output_columns(self) -> List[ColumnRef]:
        """
        Get output columns (SELECT clause or INSERT columns).

        Returns:
            List of output ColumnRef objects
        """
        columns = []

        if isinstance(self.ast, exp.Select):
            for expr in self.ast.expressions:
                if isinstance(expr, exp.Alias):
                    columns.append(ColumnRef(
                        table_name="",
                        column_name=expr.alias
                    ))
                elif isinstance(expr, exp.Column):
                    columns.append(ColumnRef(
                        table_name=expr.table if expr.table else "",
                        column_name=expr.name
                    ))
                elif isinstance(expr, exp.Star):
                    columns.append(ColumnRef(
                        table_name=expr.table if hasattr(expr, 'table') and expr.table else "",
                        column_name="*"
                    ))

        elif isinstance(self.ast, exp.Insert):
            # Get columns from INSERT statement
            if self.ast.args.get('columns'):
                for col in self.ast.args['columns']:
                    if isinstance(col, exp.Column):
                        columns.append(ColumnRef(
                            table_name="",
                            column_name=col.name
                        ))

        return columns



    def _get_operator_from_expression(self, expression: exp.Expression) -> Optional[str]:
        """
        Determine the operator from a condition expression.
        
        Args:
            expression: SQLGlot expression
            
        Returns:
            Operator string or None
        """
        operator_map = {
            exp.EQ: "=",
            exp.NEQ: "!=",
            exp.GT: ">",
            exp.GTE: ">=",
            exp.LT: "<",
            exp.LTE: "<=",
            exp.Like: "LIKE",
            exp.ILike: "ILIKE",
            exp.In: "IN",
            exp.Is: "IS",
            exp.Between: "BETWEEN",
        }
        
        for expression_type, operator_string in operator_map.items():
            if isinstance(expression, expression_type):
                return operator_string
        
        # Check for NOT IN
        if isinstance(expression, exp.Not):
            if hasattr(expression, 'this') and isinstance(expression.this, exp.In):
                return "NOT IN"
        
        return None

    def _extract_columns_from_expression(self, expression: exp.Expression) -> List[ColumnRef]:
        """
        Extract all column references from an expression.
        
        Args:
            expression: SQLGlot expression to extract columns from
            
        Returns:
            List of ColumnRef objects
        """
        columns = []
        seen = set()
        
        if expression is None:
            return columns
        
        for column_expression in expression.find_all(exp.Column):
            column_name = column_expression.name if hasattr(column_expression, 'name') else None
            if not column_name:
                continue
            
            # Extract table reference
            table_name = ""
            if hasattr(column_expression, 'table') and column_expression.table:
                table_name = column_expression.table
            
            # Create unique key to avoid duplicates
            key = f"{table_name}.{column_name}".lower()
            if key in seen:
                continue
            seen.add(key)
            
            # Extract schema if available
            schema_name = None
            if hasattr(column_expression, 'db') and column_expression.db:
                schema_name = column_expression.db
            
            column_ref = ColumnRef(
                table_name=table_name if table_name else "",
                column_name=column_name,
                schema_name=schema_name
            )
            columns.append(column_ref)
        
        return columns

    def _create_where_condition(self, expression: exp.Expression, alias_map: Dict[str, str]) -> Optional[WhereCondition]:
        """
        Create a WhereCondition from a single predicate expression.
        
        Args:
            expression: The predicate expression
            alias_map: Mapping of aliases to table names
            
        Returns:
            WhereCondition object or None
        """
        if expression is None:
            return None
        
        # Get the SQL text of the expression
        expression_sql = expression.sql(dialect=self.dialect)
        
        # Extract columns referenced in this condition
        columns_referenced = []
        for column in expression.find_all(exp.Column):
            col_ref = self._create_column_ref(column, alias_map)
            if col_ref:
                columns_referenced.append(col_ref)
        
        # Determine the operator
        operator = self._get_operator_from_expression(expression)
        
        # Check for subquery
        has_subquery = len(list(expression.find_all(exp.Subquery))) > 0
        
        return WhereCondition(
            expression=expression_sql,
            columns_referenced=columns_referenced,
            operator=operator,
            has_subquery=has_subquery
        )

    def _get_table_name(self, table_expression: exp.Expression) -> Optional[str]:
        """
        Safely extract table name from a table expression.
        Handles both simple table references and schema-qualified names.
        
        Args:
            table_expression: SQLGlot expression that might be a table
            
        Returns:
            Table name string or None if not a valid table reference
        """
        if not isinstance(table_expression, exp.Table):
            return None
        
        # Safely extract table name
        table_name = table_expression.name if hasattr(table_expression, 'name') else None
        if not table_name:
            return None
        
        # Check for schema/database prefix
        if hasattr(table_expression, 'db') and table_expression.db:
            return f"{table_expression.db}.{table_name}"
        
        return table_name

    def _extract_volatile_tables_from_handler(self) -> List:
        """
        Extract volatile tables from VolatileTableHandler as CTEs.
        This is the primary method when processing stored procedures.
        
        Returns:
            List of CTEDefinition objects for volatile tables
        """
        from models.data_models import CTEDefinition
        
        volatile_ctes = []
        
        if not self.volatile_handler or not hasattr(self.volatile_handler, 'volatile_tables'):
            return volatile_ctes
        
        # Extract each volatile table from handler
        for table_name, table_info in self.volatile_handler.volatile_tables.items():
            # table_info is a VolatileTableDefinition dataclass, not a dict
            # Access attributes directly, not via .get()
            definition_sql = getattr(table_info, 'definition_sql', '')
            if not definition_sql:
                # Try to extract from create_sql
                create_sql = getattr(table_info, 'create_sql', '')
                if 'AS (' in create_sql.upper():
                    definition_sql = create_sql.split('AS (', 1)[1].rsplit(')', 1)[0]
            
            # Get column names
            columns = getattr(table_info, 'columns', [])
            
            # Get source tables (tables referenced in the volatile table definition)
            source_tables = getattr(table_info, 'source_tables', [])
            
            # Create CTEDefinition
            cte_definition = CTEDefinition(
                name=table_name,
                definition_sql=definition_sql if definition_sql else "-- Definition not available",
                columns=columns if columns else [],
                is_recursive=False,
                dependencies=[],
                source_tables=source_tables if source_tables else [],
                is_volatile_table=True
            )
            volatile_ctes.append(cte_definition)
        
        return volatile_ctes
    
    def _extract_volatile_tables_as_ctes(self) -> List:
        """
        Extract Teradata volatile tables from AST and treat them as CTEs.
        Fallback method for single-statement files without volatile_handler.
        Volatile tables function as temporary named result sets similar to CTEs.
        
        Returns:
            List of CTEDefinition objects for volatile tables
        """
        from models.data_models import CTEDefinition
        
        volatile_ctes = []
        
        # Find all CREATE statements
        for create_statement in self.ast.find_all(exp.Create):
            sql_text = create_statement.sql(dialect=self.dialect)
            
            # Check if this is a volatile table
            if 'VOLATILE' in sql_text.upper():
                # Extract table name
                table_name = None
                if hasattr(create_statement, 'this') and create_statement.this:
                    table_name = self._get_table_name_safe(create_statement.this)
                
                if not table_name:
                    continue
                
                # Extract the SELECT query (the definition)
                definition_sql = ""
                source_tables = []
                columns = []
                
                if hasattr(create_statement, 'expression') and create_statement.expression:
                    query_expression = create_statement.expression
                    definition_sql = query_expression.sql(dialect=self.dialect)
                    
                    # Extract source tables from the query
                    for table_expression in query_expression.find_all(exp.Table):
                        source_table = self._get_table_name_safe(table_expression)
                        if source_table and source_table != table_name:
                            source_tables.append(source_table)
                    
                    # Extract column names from SELECT
                    if isinstance(query_expression, exp.Select):
                        for select_expression in query_expression.expressions:
                            if hasattr(select_expression, 'alias') and select_expression.alias:
                                columns.append(select_expression.alias)
                            elif isinstance(select_expression, exp.Column):
                                columns.append(select_expression.name)
                            elif hasattr(select_expression, 'name'):
                                columns.append(select_expression.name)
                
                # Create CTEDefinition for the volatile table
                cte_definition = CTEDefinition(
                    name=table_name,
                    definition_sql=definition_sql,
                    columns=columns if columns else None,
                    is_recursive=False,
                    dependencies=[],
                    source_tables=source_tables if source_tables else None,
                    is_volatile_table=True
                )
                volatile_ctes.append(cte_definition)
        
        return volatile_ctes

    def _extract_output_columns(self, select_expr: exp.Expression) -> List[str]:
        """
        Extract output column names from a SELECT expression.

        Args:
            select_expr: The SELECT expression

        Returns:
            List of column names
        """
        columns = []
        
        if not select_expr:
            return columns
        
        # Find the SELECT clause
        select = select_expr if isinstance(select_expr, exp.Select) else select_expr.find(exp.Select)
        
        if not select:
            return columns
        
        # Get expressions from SELECT
        expressions = select.expressions if hasattr(select, 'expressions') else []
        
        for expr in expressions:
            try:
                # Check for alias first
                if hasattr(expr, 'alias') and expr.alias:
                    columns.append(expr.alias)
                elif isinstance(expr, exp.Column):
                    col_name = expr.name if hasattr(expr, 'name') else None
                    if col_name:
                        columns.append(col_name)
                elif isinstance(expr, exp.Alias):
                    alias_name = expr.alias if hasattr(expr, 'alias') else None
                    if alias_name:
                        columns.append(alias_name)
                else:
                    # For complex expressions, try to get the SQL
                    expr_sql = expr.sql(dialect=self.dialect)
                    if expr_sql:
                        columns.append(expr_sql)
            except Exception:
                continue
        
        return columns

    def _build_alias_map(self) -> Dict[str, str]:
        """
        Build a mapping of table aliases to actual table names.
        Critical for resolving column references to their source tables.
        
        Returns:
            Dict mapping alias -> actual table name
        """
        alias_map = {}
        
        # Extract from main FROM clause
        for table in self.ast.find_all(exp.Table):
            table_name = self._get_table_name_safe(table)
            if not table_name:
                continue
            
            # Check for alias
            alias = None
            if hasattr(table, 'alias') and table.alias:
                alias = table.alias.name if hasattr(table.alias, 'name') else str(table.alias)
            
            if alias:
                alias_map[alias] = table_name
            else:
                # Table without alias maps to itself
                alias_map[table_name] = table_name
        
        # Extract from subqueries with aliases
        for subquery in self.ast.find_all(exp.Subquery):
            if hasattr(subquery, 'alias') and subquery.alias:
                alias = subquery.alias.name if hasattr(subquery.alias, 'name') else str(subquery.alias)
                # Subquery alias maps to the subquery identifier
                alias_map[alias] = f"SUBQUERY_{alias}"
        
        # Extract from CTEs
        for cte in self.ast.find_all(exp.CTE):
            cte_name = None
            if hasattr(cte, 'alias') and cte.alias:
                cte_name = cte.alias.name if hasattr(cte.alias, 'name') else str(cte.alias)
            elif hasattr(cte, 'this') and hasattr(cte.this, 'name'):
                cte_name = cte.this.name
            
            if cte_name:
                alias_map[cte_name] = f"CTE_{cte_name}"
        
        return alias_map

    def _get_table_name_safe(self, table_expression: exp.Expression) -> Optional[str]:
        """
        Safely extract table name from a table expression.
        Handles schema prefixes and various expression types.
        
        Args:
            table_expression: SQLGlot expression that might be a table reference
            
        Returns:
            Table name string or None if not extractable
        """
        if table_expression is None:
            return None
        
        # Handle Table expressions directly
        if isinstance(table_expression, exp.Table):
            table_name = table_expression.name if hasattr(table_expression, 'name') else None
            if not table_name:
                return None
            
            # Check for schema/database prefix
            if hasattr(table_expression, 'db') and table_expression.db:
                return f"{table_expression.db}.{table_name}"
            
            return table_name
        
        # Handle Schema expressions (INSERT INTO table (col_list) ...)
        if isinstance(table_expression, exp.Schema):
            if hasattr(table_expression, 'this'):
                return self._get_table_name_safe(table_expression.this)
            return None

        # Handle Alias expressions (e.g., table AS alias)
        if isinstance(table_expression, exp.Alias):
            # Get the underlying table
            if hasattr(table_expression, 'this'):
                return self._get_table_name_safe(table_expression.this)
            return None
        
        # Handle Subquery expressions
        if isinstance(table_expression, exp.Subquery):
            # Return alias if available
            if hasattr(table_expression, 'alias') and table_expression.alias:
                return table_expression.alias
            return None
        
        # Handle Column expressions (extract table reference)
        if isinstance(table_expression, exp.Column):
            if hasattr(table_expression, 'table') and table_expression.table:
                return table_expression.table
            return None
        
        # Try to get name attribute as fallback
        if hasattr(table_expression, 'name') and table_expression.name:
            return table_expression.name
        
        return None

    def _extract_source_columns_with_tables(self) -> List[ColumnRef]:
        """
        Extract all source columns with their table references.
        
        Returns:
            List of ColumnRef objects with table information
        """
        columns = []
        seen = set()  # Deduplicate
        alias_map = self._build_alias_map()
        
        for column in self.ast.find_all(exp.Column):
            column_name = None
            table_ref = None
            
            # Extract column name
            if hasattr(column, 'name') and column.name:
                column_name = column.name
            elif hasattr(column, 'this'):
                if hasattr(column.this, 'name'):
                    column_name = column.this.name
                else:
                    column_name = str(column.this)
            
            if not column_name:
                continue
            
            # Extract table reference
            if hasattr(column, 'table') and column.table:
                table_ref = str(column.table)
            
            # Resolve alias to actual table name
            actual_table = None
            if table_ref:
                actual_table = alias_map.get(table_ref, table_ref)
            
            # Create unique key for deduplication
            key = (actual_table or '', column_name)
            if key in seen:
                continue
            seen.add(key)
            
            # Create ColumnRef
            col_ref = ColumnRef(
                table_name=actual_table or 'UNKNOWN',
                column_name=column_name,
                schema_name=None,
                alias=None
            )
            columns.append(col_ref)
        
        return columns

    def _has_subquery(self, expression: exp.Expression) -> bool:
        """
        Check if an expression contains a subquery.
        
        Args:
            expression: SQLGlot expression to check
            
        Returns:
            True if contains subquery, False otherwise
        """
        if expression is None:
            return False
        
        # Check for subquery types
        subquery_types = (exp.Subquery, exp.Select, exp.Exists)
        
        for subq in expression.find_all(*subquery_types):
            # Skip if it's the expression itself
            if subq is expression:
                continue
            return True
        
        return False

    def _extract_static_lineage(self) -> Dict[str, List[Dict[str, str]]]:
        """
        Extract column-level lineage mapping target columns to source columns.
        Maps each output column to its source table(s) and column(s).
        
        Returns:
            Dict mapping target_column -> list of {source_table, source_column}
        """
        lineage = {}
        alias_map = self._build_alias_map()
        
        # Find the main SELECT statement
        select_stmt = self.ast.find(exp.Select)
        if not select_stmt:
            return lineage
        
        # Process each column in the SELECT list
        for idx, expression in enumerate(select_stmt.expressions):
            # Determine the output column name
            output_name = self._get_output_column_name(expression, idx)
            
            # Extract source columns from this expression
            source_columns = self._extract_source_columns_from_expression(expression, alias_map)
            
            if source_columns:
                lineage[output_name] = source_columns
        
        return lineage

    def _resolve_column_table(self, column_expression: exp.Column, alias_map: Dict[str, str]) -> str:
        """
        Resolve the actual table name for a column reference using the alias map.
        
        Args:
            column_expression: SQLGlot Column expression
            alias_map: Map of aliases to actual table names
            
        Returns:
            Resolved table name or 'UNKNOWN' if cannot be resolved
        """
        # Get the table reference from the column
        table_ref = None
        
        if hasattr(column_expression, 'table') and column_expression.table:
            table_ref = str(column_expression.table)
        
        if not table_ref:
            # Column has no table qualifier - try to infer from context
            return 'UNKNOWN'
        
        # Look up in alias map
        if table_ref in alias_map:
            return alias_map[table_ref]
        
        # Try case-insensitive lookup
        table_ref_upper = table_ref.upper()
        for alias, actual_table in alias_map.items():
            if alias.upper() == table_ref_upper:
                return actual_table
        
        # Return the reference as-is if not found in map
        return table_ref

    def _extract_conditions_recursive(self, expression: exp.Expression, conditions: List[WhereCondition]) -> None:
        """
        Recursively extract conditions from AND/OR expressions.
        
        Args:
            expression: Current expression to process
            conditions: List to append conditions to
        """
        if expression is None:
            return
        
        # Handle AND expressions
        if isinstance(expression, exp.And):
            if hasattr(expression, 'this'):
                self._extract_conditions_recursive(expression.this, conditions)
            if hasattr(expression, 'expression'):
                self._extract_conditions_recursive(expression.expression, conditions)
            return
        
        # Handle OR expressions
        if isinstance(expression, exp.Or):
            if hasattr(expression, 'this'):
                self._extract_conditions_recursive(expression.this, conditions)
            if hasattr(expression, 'expression'):
                self._extract_conditions_recursive(expression.expression, conditions)
            return
        
        # Handle parenthesized expressions
        if isinstance(expression, exp.Paren):
            if hasattr(expression, 'this'):
                self._extract_conditions_recursive(expression.this, conditions)
            return
        
        # This is a leaf condition - extract it
        condition = self._create_where_condition(expression)
        if condition:
            conditions.append(condition)

    def _get_condition_operator(self, expression: exp.Expression) -> Optional[str]:
        """
        Determine the operator type for a condition expression.
        
        Args:
            expression: Condition expression
            
        Returns:
            Operator string (=, !=, >, <, >=, <=, LIKE, IN, BETWEEN, IS NULL, etc.)
        """
        operator_map = {
            exp.EQ: "=",
            exp.NEQ: "!=",
            exp.GT: ">",
            exp.GTE: ">=",
            exp.LT: "<",
            exp.LTE: "<=",
            exp.Like: "LIKE",
            exp.ILike: "ILIKE",
            exp.In: "IN",
            exp.Between: "BETWEEN",
            exp.Is: "IS",
            exp.Not: "NOT",
            exp.Exists: "EXISTS",
            exp.RegexpLike: "REGEXP",
        }
        
        for exp_type, op_str in operator_map.items():
            if isinstance(expression, exp_type):
                return op_str
        
        return None

    def _extract_select_column_lineage(self, lineage: Dict, source_tables: List[str], target_table: Optional[str]) -> None:
        """
        Extract column lineage from SELECT expressions.
        
        Args:
            lineage: Lineage dictionary to populate
            source_tables: List of source table names
            target_table: Target table name (if any)
        """
        select_expr = self.ast if isinstance(self.ast, exp.Select) else self.ast.find(exp.Select)
        if not select_expr:
            return
        
        # Get SELECT expressions (columns)
        for idx, expr in enumerate(select_expr.expressions):
            target_col = None
            source_cols = []
            
            # Get alias or column name as target
            if isinstance(expr, exp.Alias):
                target_col = expr.alias
                inner_expr = expr.this
            else:
                if isinstance(expr, exp.Column):
                    target_col = expr.name
                inner_expr = expr
            
            # Extract source columns from the expression
            for col in inner_expr.find_all(exp.Column) if hasattr(inner_expr, 'find_all') else []:
                col_name = col.name if hasattr(col, 'name') else None
                table_name = None
                if hasattr(col, 'table') and col.table:
                    table_name = col.table
                
                if col_name:
                    source_cols.append({
                        'column': col_name,
                        'table': table_name
                    })
            
            # Create lineage edges
            for source_col in source_cols:
                if target_col:
                    lineage['column_lineage'].append({
                        'source_table': source_col.get('table'),
                        'source_column': source_col['column'],
                        'target_table': target_table,
                        'target_column': target_col
                    })

    def _extract_insert_column_lineage(self, lineage: Dict, source_tables: List[str], target_table: Optional[str]) -> None:
        """
        Extract column lineage from INSERT statements.
        
        Args:
            lineage: Lineage dictionary to populate
            source_tables: List of source table names
            target_table: Target table name
        """
        if not isinstance(self.ast, exp.Insert):
            return
        
        # Get target columns from INSERT
        target_columns = []
        schema = self.ast.find(exp.Schema)
        if schema:
            for col in schema.expressions:
                if isinstance(col, exp.Column):
                    target_columns.append(col.name)
                elif hasattr(col, 'name'):
                    target_columns.append(col.name)
        
        # Get source SELECT
        select_expr = self.ast.find(exp.Select)
        if select_expr and target_columns:
            for idx, expr in enumerate(select_expr.expressions):
                if idx >= len(target_columns):
                    break
                
                target_col = target_columns[idx]
                
                # Extract source columns
                for col in expr.find_all(exp.Column) if hasattr(expr, 'find_all') else []:
                    col_name = col.name if hasattr(col, 'name') else None
                    table_name = col.table if hasattr(col, 'table') and col.table else None
                    
                    if col_name:
                        lineage['column_lineage'].append({
                            'source_table': table_name,
                            'source_column': col_name,
                            'target_table': target_table,
                            'target_column': target_col
                        })

    def _extract_update_column_lineage(self, lineage: Dict, source_tables: List[str], target_table: Optional[str]) -> None:
        """
        Extract column lineage from UPDATE statements.
        
        Args:
            lineage: Lineage dictionary to populate
            source_tables: List of source table names
            target_table: Target table name
        """
        if not isinstance(self.ast, exp.Update):
            return
        
        # Find SET expressions
        for eq_expr in self.ast.find_all(exp.EQ):
            # Left side is target column
            left = eq_expr.left
            right = eq_expr.right
            
            target_col = None
            if isinstance(left, exp.Column):
                target_col = left.name
            
            if target_col and right:
                # Extract source columns from right side
                for col in right.find_all(exp.Column) if hasattr(right, 'find_all') else []:
                    col_name = col.name if hasattr(col, 'name') else None
                    table_name = col.table if hasattr(col, 'table') and col.table else None
                    
                    if col_name:
                        lineage['column_lineage'].append({
                            'source_table': table_name,
                            'source_column': col_name,
                            'target_table': target_table,
                            'target_column': target_col
                        })

    def _get_output_column_name(self, expression: exp.Expression, index: int) -> str:
        """
        Determine the output column name for a SELECT expression.
        
        Args:
            expression: The SELECT list expression
            index: Position in SELECT list (for unnamed columns)
            
        Returns:
            Column name string
        """
        # Check for explicit alias
        if hasattr(expression, 'alias') and expression.alias:
            return expression.alias.name if hasattr(expression.alias, 'name') else str(expression.alias)
        
        # For Alias expressions
        if isinstance(expression, exp.Alias):
            if hasattr(expression, 'alias') and expression.alias:
                return str(expression.alias)
            elif hasattr(expression, 'this'):
                return self._get_output_column_name(expression.this, index)
        
        # For simple column references
        if isinstance(expression, exp.Column):
            return expression.name if hasattr(expression, 'name') else f"column_{index}"
        
        # For star expressions
        if isinstance(expression, exp.Star):
            return "*"
        
        # Default: use position-based name
        return f"column_{index}"

    def _extract_single_column_reference(self, column: exp.Column, alias_map: Dict[str, str]) -> Optional[Dict[str, str]]:
        """
        Extract information from a single column reference.
        
        Args:
            column: SQLGlot Column expression
            alias_map: Mapping of aliases to table names
            
        Returns:
            Dict with column info or None
        """
        if not isinstance(column, exp.Column):
            return None
        
        # Get column name
        column_name = None
        if hasattr(column, 'name') and column.name:
            column_name = column.name
        elif hasattr(column, 'this'):
            this = column.this
            if isinstance(this, str):
                column_name = this
            elif hasattr(this, 'name'):
                column_name = this.name
        
        if not column_name:
            return None
        
        # Get table reference (alias or name)
        table_ref = None
        if hasattr(column, 'table') and column.table:
            table_ref = column.table
        
        # Resolve alias to actual table name
        actual_table = None
        if table_ref:
            actual_table = alias_map.get(table_ref, table_ref)
        
        return {
            'column_name': column_name,
            'table_alias': table_ref,
            'table_name': actual_table,
            'expression': column.sql(dialect=self.dialect)
        }

    def _get_comparison_operator(self, expression: exp.Expression) -> Optional[str]:
        """
        Get the comparison operator from an expression.
        
        Args:
            expression: SQLGlot expression
            
        Returns:
            Operator string or None
        """
        operator_map = {
            exp.EQ: "=",
            exp.NEQ: "!=",
            exp.GT: ">",
            exp.GTE: ">=",
            exp.LT: "<",
            exp.LTE: "<=",
            exp.Like: "LIKE",
            exp.ILike: "ILIKE",
            exp.In: "IN",
            exp.Between: "BETWEEN",
            exp.Is: "IS",
            exp.Not: "NOT",
            exp.Exists: "EXISTS",
        }
        
        for exp_type, op_str in operator_map.items():
            if isinstance(expression, exp_type):
                return op_str
        
        return None

    def _create_column_reference(self, column: exp.Column, alias_map: Dict[str, str]) -> Optional[ColumnRef]:
        """
        Create a ColumnRef from a Column expression.
        
        Args:
            column: SQLGlot Column expression
            alias_map: Mapping of aliases to table names
            
        Returns:
            ColumnRef object or None
        """
        if not isinstance(column, exp.Column):
            return None
        
        # Get column name
        column_name = None
        if hasattr(column, 'name') and column.name:
            column_name = column.name
        elif hasattr(column, 'this'):
            this = column.this
            if isinstance(this, str):
                column_name = this
            elif hasattr(this, 'name'):
                column_name = this.name
        
        if not column_name:
            return None
        
        # Get table reference
        table_ref = None
        if hasattr(column, 'table') and column.table:
            table_ref = column.table
        
        # Resolve to actual table name
        actual_table = alias_map.get(table_ref, table_ref) if table_ref else None
        
        # Use actual_table or a placeholder if unknown
        table_name = actual_table if actual_table else "__unknown__"
        
        return ColumnRef(
            table_name=table_name,
            column_name=column_name,
            schema_name=None,
            alias=None
        )

    def _resolve_column_to_table(self, column_expression: exp.Column, alias_map: Optional[Dict[str, str]] = None) -> Optional[str]:
        """
        Resolve a column reference to its source table.
        Uses the alias map to translate aliases to actual table names.
        
        Args:
            column_expression: SQLGlot Column expression
            alias_map: Optional pre-built alias map (builds one if not provided)
            
        Returns:
            Resolved table name or None if cannot be determined
        """
        if not isinstance(column_expression, exp.Column):
            return None
        
        # Build alias map if not provided
        if alias_map is None:
            alias_map = self._build_alias_map()
        
        # Try to get table reference from the column
        table_ref = None
        
        # Check for explicit table qualifier
        if hasattr(column_expression, 'table') and column_expression.table:
            table_ref = column_expression.table
        
        if not table_ref:
            # No explicit table qualifier - try to infer from context
            # Look for parent FROM clause or JOIN
            parent = column_expression.parent
            while parent:
                if isinstance(parent, exp.Select):
                    # Get the first table from FROM clause
                    from_clause = parent.find(exp.From)
                    if from_clause:
                        for table in from_clause.find_all(exp.Table):
                            return self._get_table_name_safe(table)
                    break
                parent = getattr(parent, 'parent', None)
            return None
        
        # Resolve alias to actual table name
        if table_ref in alias_map:
            return alias_map[table_ref]
        
        return table_ref

    def _extract_tables_from_expression(self, expression: exp.Expression) -> List[str]:
        """
        Extract all table references from an expression.
        
        Args:
            expression: SQLGlot expression to analyze
            
        Returns:
            List of table names referenced in the expression
        """
        tables = []
        seen = set()
        
        if expression is None:
            return tables
        
        # Find all column references
        for col in expression.find_all(exp.Column):
            table_name = None
            if hasattr(col, 'table') and col.table:
                table_name = col.table
            
            if table_name and table_name not in seen:
                seen.add(table_name)
                tables.append(table_name)
        
        # Find all direct table references
        for table in expression.find_all(exp.Table):
            table_name = self._get_table_name_safe(table)
            if table_name and table_name not in seen:
                seen.add(table_name)
                tables.append(table_name)
        
        return tables

    def _extract_single_condition(self, expression: exp.Expression) -> Optional[WhereCondition]:
        """
        Extract a single WHERE condition from an expression.
        
        Args:
            expression: A single condition expression (EQ, GT, LT, IN, LIKE, etc.)
            
        Returns:
            WhereCondition object or None
        """
        if expression is None:
            return None
        
        # Get the SQL text of the condition
        expr_sql = expression.sql(dialect=self.dialect)
        
        # Determine the operator
        operator = self._get_condition_operator(expression)
        
        # Extract all columns referenced in this condition
        columns_referenced = self._extract_columns_from_expression(expression)
        
        # Check if condition contains a subquery
        has_subquery = len(list(expression.find_all(exp.Subquery))) > 0
        
        return WhereCondition(
            expression=expr_sql,
            columns_referenced=columns_referenced,
            operator=operator,
            has_subquery=has_subquery
        )

    def _extract_source_columns_from_expression(self, expression: exp.Expression, alias_map: Dict[str, str]) -> List[Dict[str, str]]:
        """
        Extract all source columns referenced in an expression.
        
        Args:
            expression: SQLGlot expression to analyze
            alias_map: Mapping of aliases to table names
            
        Returns:
            List of dicts with source_table and source_column keys
        """
        sources = []
        seen = set()
        
        # Find all column references in the expression
        for column in expression.find_all(exp.Column):
            column_name = column.name if hasattr(column, 'name') else None
            if not column_name:
                continue
            
            # Get table reference
            table_ref = None
            if hasattr(column, 'table') and column.table:
                table_ref = column.table
            
            # Resolve alias to actual table name
            if table_ref and table_ref in alias_map:
                actual_table = alias_map[table_ref]
            elif table_ref:
                actual_table = table_ref
            else:
                actual_table = "UNKNOWN"
            
            # Deduplicate
            key = f"{actual_table}.{column_name}"
            if key not in seen:
                seen.add(key)
                sources.append({
                    "source_table": actual_table,
                    "source_column": column_name
                })
        
        return sources

    def _create_column_ref(self, column: exp.Column, alias_map: Dict[str, str]) -> Optional[ColumnRef]:
        """
        Create a ColumnRef from a Column expression.
        
        Args:
            column: SQLGlot Column expression
            alias_map: Mapping of aliases to table names
            
        Returns:
            ColumnRef object or None
        """
        if not isinstance(column, exp.Column):
            return None
        
        column_name = column.name if hasattr(column, 'name') else None
        if not column_name:
            return None
        
        # Get table reference
        table_ref = None
        if hasattr(column, 'table') and column.table:
            table_ref = column.table
        
        # Resolve alias to actual table name
        if table_ref and table_ref in alias_map:
            table_name = alias_map[table_ref]
        elif table_ref:
            table_name = table_ref
        else:
            table_name = "UNKNOWN"
        
        # Extract schema if present
        schema_name = None
        if '.' in table_name:
            parts = table_name.split('.')
            if len(parts) == 2:
                schema_name = parts[0]
                table_name = parts[1]
        
        return ColumnRef(
            table_name=table_name,
            column_name=column_name,
            schema_name=schema_name,
            alias=None
        )
def extract_elements(sql: str, dialect: str = "teradata") -> ElementCatalog:
    """
    Convenience function to extract elements from SQL string.

    Args:
        sql: SQL string to analyze
        dialect: SQL dialect

    Returns:
        ElementCatalog with all extracted elements
    """
    ast = sqlglot.parse_one(sql, read=dialect)
    extractor = SQLElementExtractor(ast, dialect)
    return extractor.extract_all()
