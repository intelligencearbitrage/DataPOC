"""
Subquery and CTE Extractor module.

Extracts subqueries and CTEs with recursive expansion and complete details.
"""

import sqlglot
from sqlglot import exp
from typing import List, Dict, Set, Optional
import sys
import os

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from models.data_models import CTEDefinition, Subquery, ColumnRef


class SubqueryCTEExtractor:
    """
    Extract subqueries and CTEs with recursive expansion.
    Handles nested CTEs, correlated subqueries, and CTE dependencies.
    """

    def __init__(self, dialect: str = "teradata"):
        """
        Initialize extractor.

        Args:
            dialect: SQL dialect for generating SQL text
        """
        self.dialect = dialect
        self._extracted_subquery_ids = set()  # Track extracted subqueries by unique ID
        self._extracted_function_ids = set()  # Track extracted functions by unique ID

    def extract_ctes(self, ast: exp.Expression) -> List[CTEDefinition]:
        """
        Extract CTEs (WITH clauses) with complete details.
        Also detects CREATE VOLATILE TABLE statements and treats them as CTEs.

        Args:
            ast: Parsed SQL AST

        Returns:
            List of CTEDefinition objects
        """
        ctes = []

        # DEBUG: Check what type of statement we're processing
        ast_type = type(ast).__name__
        print(f"  DEBUG CTE Extractor: Processing {ast_type} statement")

        # Check if this is a CREATE VOLATILE TABLE statement
        # CREATE VOLATILE TABLE acts like a CTE (temporary result set)
        if isinstance(ast, exp.Create):
            raw_sql = ast.sql(dialect=self.dialect).upper()
            print(f"  DEBUG CTE Extractor: Found CREATE statement, checking for VOLATILE...")
            if 'VOLATILE' in raw_sql and 'TABLE' in raw_sql:
                print(f"  DEBUG CTE Extractor: [OK] Found VOLATILE TABLE!")
                volatile_cte = self._extract_volatile_as_cte(ast)
                if volatile_cte:
                    print(f"  DEBUG CTE Extractor: [OK] Extracted volatile CTE: {volatile_cte.name}")
                    ctes.append(volatile_cte)
                else:
                    print(f"  DEBUG CTE Extractor: [FAIL] Failed to extract volatile CTE")
        
        # Also search for CREATE VOLATILE TABLE within complex statements
        for create_stmt in ast.find_all(exp.Create):
            if create_stmt == ast:
                continue  # Already processed above
            raw_sql = create_stmt.sql(dialect=self.dialect).upper()
            if 'VOLATILE' in raw_sql and 'TABLE' in raw_sql:
                print(f"  DEBUG CTE Extractor: Found nested VOLATILE TABLE")
                volatile_cte = self._extract_volatile_as_cte(create_stmt)
                if volatile_cte and volatile_cte.name not in [c.name for c in ctes]:
                    ctes.append(volatile_cte)
        
        # Text-based fallback detection for VOLATILE TABLE
        try:
            full_sql = ast.sql(dialect=self.dialect).upper()
            if 'VOLATILE' in full_sql and 'TABLE' in full_sql and not ctes:
                import re
                # Pattern to match CREATE [MULTISET] VOLATILE TABLE name AS (...)
                pattern = r'CREATE\s+(?:MULTISET\s+)?VOLATILE\s+TABLE\s+(\w+)\s+AS\s*\(([^)]+(?:\([^)]*\)[^)]*)*?)\)'
                matches = re.findall(pattern, full_sql, re.IGNORECASE | re.DOTALL)
                for match in matches:
                    table_name = match[0]
                    definition_sql = match[1].strip()
                    if table_name and table_name not in [c.name for c in ctes]:
                        print(f"  DEBUG CTE Extractor: Text-based extraction found: {table_name}")
                        cte_def = CTEDefinition(
                            name=table_name,
                            definition_sql=definition_sql,
                            columns=None,
                            is_recursive=False,
                            dependencies=[],
                            source_tables=None,
                            column_lineage=None,
                            is_volatile_table=True
                        )
                        ctes.append(cte_def)
        except Exception as e:
            print(f"  DEBUG CTE Extractor: Text-based fallback failed: {e}")

        # Extract standard CTEs from WITH clause
        with_clause = ast.find(exp.With)
        if with_clause:
            # Get all CTE names first for dependency tracking
            all_cte_names = set()
            for cte_expr in with_clause.expressions:
                if hasattr(cte_expr, 'alias'):
                    all_cte_names.add(cte_expr.alias)

            # Extract each CTE
            for cte_expr in with_clause.expressions:
                cte_def = self._extract_cte(cte_expr, all_cte_names)
                if cte_def and cte_def.name not in [c.name for c in ctes]:
                    ctes.append(cte_def)

        return ctes

    def _extract_volatile_as_cte(self, create_expr: exp.Create) -> Optional[CTEDefinition]:
        """
        Extract CREATE VOLATILE TABLE as a CTE equivalent.
        
        Args:
            create_expr: SQLGlot Create expression
            
        Returns:
            CTEDefinition representing the volatile table, or None
        """
        try:
            # Get table name - handle various AST structures
            table_name = None
            if hasattr(create_expr, 'this'):
                table_expr = create_expr.this
                if hasattr(table_expr, 'name'):
                    table_name = table_expr.name
                elif isinstance(table_expr, exp.Table):
                    table_name = table_expr.name if hasattr(table_expr, 'name') else None
                elif hasattr(table_expr, 'this') and hasattr(table_expr.this, 'name'):
                    table_name = table_expr.this.name
            
            if not table_name:
                # Try to extract from SQL text as fallback
                sql_text = create_expr.sql(dialect=self.dialect)
                import re
                match = re.search(r'VOLATILE\s+TABLE\s+(\w+)', sql_text, re.IGNORECASE)
                if match:
                    table_name = match.group(1)
            
            if not table_name:
                print(f"  DEBUG: Could not extract table name from volatile table")
                return None
            
            # Get the SELECT query - it's in the 'expression' attribute
            select_query = None
            if hasattr(create_expr, 'expression') and create_expr.expression:
                select_query = create_expr.expression
            
            # Build definition SQL
            definition_sql = ""
            if select_query:
                definition_sql = select_query.sql(dialect=self.dialect)
            else:
                # Fallback: extract from full SQL
                full_sql = create_expr.sql(dialect=self.dialect)
                as_match = re.search(r'\bAS\s*\((.+)\)', full_sql, re.IGNORECASE | re.DOTALL)
                if as_match:
                    definition_sql = as_match.group(1).strip()
            
            # Get columns from SELECT
            columns = []
            if select_query and isinstance(select_query, exp.Select):
                columns = self._get_select_columns(select_query)
            
            # Get source tables from the SELECT query
            source_tables = []
            if select_query:
                for table in select_query.find_all(exp.Table):
                    if hasattr(table, 'name') and table.name:
                        tbl_name = table.name
                        if hasattr(table, 'db') and table.db:
                            tbl_name = f"{table.db}.{tbl_name}"
                        if tbl_name not in source_tables:
                            source_tables.append(tbl_name)
            
            # Create CTEDefinition with correct parameter names
            cte_def = CTEDefinition(
                name=table_name,
                definition_sql=definition_sql,
                columns=columns if columns else None,
                is_recursive=False,
                dependencies=[],
                source_tables=source_tables if source_tables else None,
                column_lineage=None,
                is_volatile_table=True
            )
            
            print(f"  DEBUG: Successfully created CTEDefinition for volatile table: {table_name}")
            return cte_def
            
        except Exception as e:
            print(f"  DEBUG: Error extracting volatile table as CTE: {e}")
            import traceback
            traceback.print_exc()
            return None

    def _old_extract_ctes_method_below(self, ast: exp.Expression) -> List[CTEDefinition]:
        """OLD METHOD - DO NOT USE"""
        ctes = []

        with_clause = ast.find(exp.With)
        if with_clause:
            # Get all CTE names first for dependency tracking
            all_cte_names = set()
            for cte_expr in with_clause.expressions:
                if hasattr(cte_expr, 'alias'):
                    all_cte_names.add(cte_expr.alias)

            # Extract each CTE
            for cte_expr in with_clause.expressions:
                cte_def = self._extract_cte(cte_expr, all_cte_names)
                ctes.append(cte_def)

        # Extract Teradata VOLATILE TABLE statements as CTE equivalents
        volatile_ctes = self._extract_volatile_tables_as_ctes(ast)
        ctes.extend(volatile_ctes)

        return ctes

    def _extract_cte(self, cte_expr: exp.CTE, all_cte_names: Set[str]) -> CTEDefinition:
        """
        Extract a single CTE definition.

        Args:
            cte_expr: SQLGlot CTE expression
            all_cte_names: Set of all CTE names for dependency tracking

        Returns:
            CTEDefinition with complete details
        """
        cte_name = cte_expr.alias
        cte_query = cte_expr.this

        # Get column aliases if specified
        columns = []
        if hasattr(cte_expr, 'args') and cte_expr.args.get('alias'):
            alias_obj = cte_expr.args.get('alias')
            if hasattr(alias_obj, 'columns'):
                columns = [col.name for col in alias_obj.columns]

        # If no explicit columns, try to infer from SELECT
        if not columns and isinstance(cte_query, exp.Select):
            columns = self._get_select_columns(cte_query)

        # Check for recursive CTE
        is_recursive = self._is_recursive_cte(cte_query, cte_name)

        # Find dependencies (other CTEs referenced)
        dependencies = self._find_cte_dependencies(cte_query, all_cte_names, cte_name)

        # Find source tables
        source_tables = self._find_source_tables(cte_query)

        return CTEDefinition(
            name=cte_name,
            definition_sql=cte_query.sql(dialect=self.dialect),
            columns=columns,
            is_recursive=is_recursive,
            dependencies=dependencies,
            source_tables=source_tables
        )

    def _get_select_columns(self, select_expr: exp.Select) -> List[str]:
        """
        Extract column names from a SELECT expression.
        
        Args:
            select_expr: SQLGlot Select expression
            
        Returns:
            List of column names/aliases
        """
        columns = []
        
        if not select_expr or not hasattr(select_expr, 'expressions'):
            return columns
        
        for expr in select_expr.expressions:
            col_name = None
            
            # Check for alias first
            if hasattr(expr, 'alias') and expr.alias:
                col_name = expr.alias
            elif isinstance(expr, exp.Alias):
                col_name = expr.alias if hasattr(expr, 'alias') else None
            elif isinstance(expr, exp.Column):
                col_name = expr.name if hasattr(expr, 'name') else None
            elif hasattr(expr, 'name'):
                col_name = expr.name
            elif hasattr(expr, 'this'):
                # Handle nested expressions
                inner = expr.this
                if hasattr(inner, 'name'):
                    col_name = inner.name
                elif hasattr(inner, 'alias'):
                    col_name = inner.alias
            
            if col_name:
                columns.append(col_name)
            else:
                # Fallback: use SQL representation
                try:
                    sql_repr = expr.sql(dialect=self.dialect)
                    if sql_repr and len(sql_repr) < 100:  # Reasonable length
                        columns.append(sql_repr)
                except:
                    pass
        
        return columns

    def _is_recursive_cte(self, cte_query: exp.Expression, cte_name: str) -> bool:
        """
        Check if a CTE is recursive (references itself).

        Args:
            cte_query: The CTE query expression
            cte_name: Name of the CTE

        Returns:
            True if recursive, False otherwise
        """
        if cte_query is None or not cte_name:
            return False
        
        cte_name_lower = cte_name.lower()
        
        # Check all table references in the CTE query
        for table in cte_query.find_all(exp.Table):
            table_name = self._get_table_name_safe(table)
            if table_name and table_name.lower() == cte_name_lower:
                return True
        
        return False

    def _find_cte_dependencies(self, cte_query: exp.Expression, all_cte_names: Set[str], current_cte_name: str) -> List[str]:
        """
        Find dependencies on other CTEs within a CTE query.

        Args:
            cte_query: The CTE query expression
            all_cte_names: Set of all CTE names in the query
            current_cte_name: Name of the current CTE (to exclude self-reference)

        Returns:
            List of CTE names that this CTE depends on
        """
        dependencies = []
        
        if cte_query is None:
            return dependencies
        
        current_lower = current_cte_name.lower() if current_cte_name else ""
        cte_names_lower = {name.lower(): name for name in all_cte_names}
        
        # Check all table references
        for table in cte_query.find_all(exp.Table):
            table_name = self._get_table_name_safe(table)
            if table_name:
                table_name_lower = table_name.lower()
                # Check if this table is another CTE (not self)
                if table_name_lower in cte_names_lower and table_name_lower != current_lower:
                    original_name = cte_names_lower[table_name_lower]
                    if original_name not in dependencies:
                        dependencies.append(original_name)
        
        return dependencies

    def _find_source_tables(self, query_expr: exp.Expression) -> List[str]:
        """
        Find all source tables referenced in a query expression.
        Excludes CTEs and volatile tables that are defined in the same query.

        Args:
            query_expr: Query expression to analyze

        Returns:
            List of source table names
        """
        tables = []
        processed = set()
        
        if query_expr is None:
            return tables
        
        # Find all table references
        for table_expr in query_expr.find_all(exp.Table):
            table_name = self._get_table_name_safe(table_expr)
            if table_name and table_name not in processed:
                processed.add(table_name)
                tables.append(table_name)
        
        return tables

    def extract_subqueries(self, ast: exp.Expression) -> List[Subquery]:
        """
        Extract all subqueries with deduplication.
        
        Args:
            ast: Parsed SQL AST
            
        Returns:
            List of Subquery objects
        """
        subqueries = []
        self._extracted_subquery_ids = set()  # Reset for each extraction
        
        # Find all subquery expressions
        for subquery_expr in ast.find_all(exp.Subquery):
            subquery = self._extract_subquery(subquery_expr)
            if subquery:
                # Create unique ID based on SQL text to deduplicate
                subquery_id = hash(subquery.query_sql.strip().upper())
                if subquery_id not in self._extracted_subquery_ids:
                    self._extracted_subquery_ids.add(subquery_id)
                    subqueries.append(subquery)
        
        # Also find SELECT expressions that are used as subqueries (in FROM, WHERE, etc.)
        for select_expr in ast.find_all(exp.Select):
            # Skip the main query
            if select_expr == ast:
                continue
            # Skip if already captured as Subquery
            parent = select_expr.parent
            if isinstance(parent, exp.Subquery):
                continue
            # Check if this SELECT is nested (not the main query)
            if self._is_nested_select(select_expr, ast):
                subquery = self._extract_select_as_subquery(select_expr)
                if subquery:
                    subquery_id = hash(subquery.query_sql.strip().upper())
                    if subquery_id not in self._extracted_subquery_ids:
                        self._extracted_subquery_ids.add(subquery_id)
                        subqueries.append(subquery)
        
        return subqueries

    def _determine_subquery_context(self, subq: exp.Subquery) -> str:
        """
        Determine the context where a subquery appears.

        Args:
            subq: SQLGlot Subquery expression

        Returns:
            Context string: SELECT, WHERE, FROM, HAVING, EXISTS, IN
        """
        parent = subq.parent

        while parent:
            if isinstance(parent, exp.Select):
                # Check if it's in the SELECT expressions
                if subq in getattr(parent, 'expressions', []):
                    return "SELECT"
                return "FROM"

            if isinstance(parent, exp.Where):
                return "WHERE"

            if isinstance(parent, exp.Having):
                return "HAVING"

            if isinstance(parent, exp.Exists):
                return "EXISTS"

            if isinstance(parent, exp.In):
                return "IN"

            if isinstance(parent, exp.From):
                return "FROM"

            if isinstance(parent, exp.Join):
                return "JOIN"

            parent = parent.parent

        return "UNKNOWN"

    def _check_correlation(self, subq: exp.Subquery,
                           outer_ast: exp.Expression) -> tuple:
        """
        Check if a subquery is correlated and find correlation columns.

        Args:
            subq: SQLGlot Subquery expression
            outer_ast: Outer query AST

        Returns:
            Tuple of (is_correlated, correlation_columns)
        """
        # Get tables from outer query
        outer_tables = set()
        outer_aliases = set()

        for table in outer_ast.find_all(exp.Table):
            outer_tables.add(table.name.upper())
            if hasattr(table, 'alias') and table.alias:
                outer_aliases.add(table.alias.upper())

        # Get tables from subquery
        subq_tables = set()
        for table in subq.this.find_all(exp.Table):
            subq_tables.add(table.name.upper())
            if hasattr(table, 'alias') and table.alias:
                subq_tables.add(table.alias.upper())

        # Find columns in subquery that reference outer tables
        correlation_columns = []

        for col in subq.this.find_all(exp.Column):
            if col.table:
                table_upper = col.table.upper()
                # Check if column references outer query table
                if table_upper in outer_tables or table_upper in outer_aliases:
                    if table_upper not in subq_tables:
                        correlation_columns.append(ColumnRef(
                            table_name=col.table,
                            column_name=col.name
                        ))

        is_correlated = len(correlation_columns) > 0

        return is_correlated, correlation_columns

    def resolve_cte_lineage(self, ctes: List[CTEDefinition]) -> Dict[str, Dict[str, List[ColumnRef]]]:
        """
        Resolve CTE lineage by tracing columns through CTE chain.

        Args:
            ctes: List of CTEDefinition objects

        Returns:
            Dict mapping CTE name -> column -> source columns
        """
        # Build CTE lookup
        cte_map = {cte.name.upper(): cte for cte in ctes}

        # Topologically sort CTEs by dependencies
        sorted_ctes = self._topological_sort_ctes(ctes)

        # Resolve lineage for each CTE
        resolved = {}

        for cte_name in sorted_ctes:
            cte = cte_map.get(cte_name.upper())
            if cte:
                resolved[cte_name] = self._resolve_single_cte_lineage(cte, resolved, cte_map)

        return resolved

    def _topological_sort_ctes(self, ctes: List[CTEDefinition]) -> List[str]:
        """
        Topologically sort CTEs based on dependencies.

        Args:
            ctes: List of CTEDefinition objects

        Returns:
            List of CTE names in dependency order
        """
        # Build dependency graph
        graph = {}
        in_degree = {}

        for cte in ctes:
            cte_name = cte.name.upper()
            graph[cte_name] = []
            in_degree[cte_name] = 0

        for cte in ctes:
            cte_name = cte.name.upper()
            for dep in cte.dependencies:
                dep_upper = dep.upper()
                if dep_upper in graph:
                    graph[dep_upper].append(cte_name)
                    in_degree[cte_name] += 1

        # Kahn's algorithm
        result = []
        queue = [name for name, degree in in_degree.items() if degree == 0]

        while queue:
            node = queue.pop(0)
            result.append(node)

            for neighbor in graph.get(node, []):
                in_degree[neighbor] -= 1
                if in_degree[neighbor] == 0:
                    queue.append(neighbor)

        # Handle cycles (recursive CTEs) - add remaining
        remaining = [cte.name for cte in ctes if cte.name.upper() not in result]
        result.extend(remaining)

        return result

    def _resolve_single_cte_lineage(self, cte: CTEDefinition,
                                     resolved: Dict,
                                     cte_map: Dict) -> Dict[str, List[ColumnRef]]:
        """
        Resolve lineage for a single CTE.

        Args:
            cte: CTEDefinition to resolve
            resolved: Already resolved CTEs
            cte_map: Map of CTE names to definitions

        Returns:
            Dict mapping column name -> source columns
        """
        lineage = {}

        # Parse the CTE query
        try:
            ast = sqlglot.parse_one(f"SELECT * FROM ({cte.definition_sql})", read=self.dialect)
        except Exception:
            return lineage

        # For each output column, trace to source
        for col_name in cte.columns:
            lineage[col_name] = self._trace_column_sources(col_name, ast, resolved, cte_map)

        return lineage

    def _trace_column_sources(self, col_name: str,
                               ast: exp.Expression,
                               resolved: Dict,
                               cte_map: Dict) -> List[ColumnRef]:
        """
        Trace a column back to its source columns.

        Args:
            col_name: Column name to trace
            ast: Query AST
            resolved: Already resolved CTEs
            cte_map: Map of CTE names to definitions

        Returns:
            List of source ColumnRef objects
        """
        sources = []

        # Find the column in SELECT
        select = ast.find(exp.Select)
        if not select:
            return sources

        for expr in select.expressions:
            # Check if this expression produces the column
            alias = None
            if isinstance(expr, exp.Alias):
                alias = expr.alias
                expr = expr.this
            elif isinstance(expr, exp.Column):
                alias = expr.name

            if alias and alias.upper() == col_name.upper():
                # Extract columns from this expression
                for col in expr.find_all(exp.Column) if hasattr(expr, 'find_all') else []:
                    sources.append(ColumnRef(
                        table_name=col.table if col.table else "",
                        column_name=col.name
                    ))

                if isinstance(expr, exp.Column):
                    sources.append(ColumnRef(
                        table_name=expr.table if expr.table else "",
                        column_name=expr.name
                    ))

        return sources

    def _extract_volatile_tables_as_ctes(self, ast: exp.Expression) -> List[CTEDefinition]:
        """
        Extract Teradata VOLATILE TABLE statements as CTE equivalents.
        Uses both AST-based and text-based fallback detection.

        Args:
            ast: Parsed SQL AST

        Returns:
            List of CTEDefinition objects for volatile tables
        """
        volatile_ctes = []
        processed_names = set()

        # Strategy 1: AST-based detection using exp.Create
        for create_stmt in ast.find_all(exp.Create):
            try:
                create_sql = create_stmt.sql(dialect=self.dialect).upper()
                
                # Check if this is a volatile table creation
                if 'VOLATILE' in create_sql:
                    table_name = None
                    
                    # Extract table name from the Create statement
                    if hasattr(create_stmt, 'this') and create_stmt.this:
                        if hasattr(create_stmt.this, 'name'):
                            table_name = create_stmt.this.name
                        elif hasattr(create_stmt.this, 'this') and hasattr(create_stmt.this.this, 'name'):
                            table_name = create_stmt.this.this.name
                    
                    if not table_name:
                        continue
                    
                    if table_name in processed_names:
                        continue
                    processed_names.add(table_name)
                    
                    # Extract the query definition (SELECT after AS)
                    query_expr = create_stmt.expression if hasattr(create_stmt, 'expression') else None
                    definition_sql = query_expr.sql(dialect=self.dialect) if query_expr else create_sql
                    
                    # Extract columns from the SELECT
                    columns = []
                    if query_expr and isinstance(query_expr, exp.Select):
                        columns = self._get_select_columns(query_expr)
                    
                    # Find source tables referenced in the volatile table definition
                    source_tables = []
                    if query_expr:
                        source_tables = self._find_source_tables(query_expr)
                    
                    # Find dependencies on other CTEs/volatile tables
                    dependencies = []
                    if query_expr:
                        dependencies = self._find_cte_dependencies(query_expr, processed_names, table_name)
                    
                    volatile_cte = CTEDefinition(
                        name=table_name,
                        definition_sql=definition_sql,
                        columns=columns,
                        is_recursive=False,
                        dependencies=dependencies,
                        source_tables=source_tables,
                        is_volatile_table=True
                    )
                    volatile_ctes.append(volatile_cte)
            except Exception:
                continue

        # Strategy 2: Text-based fallback detection
        try:
            full_sql = ast.sql(dialect=self.dialect)
            volatile_ctes.extend(self._extract_volatile_tables_from_text(full_sql, processed_names))
        except Exception:
            pass

        return volatile_ctes

    def _extract_volatile_table_definition(self, create_stmt: exp.Create, create_sql: str) -> Optional[CTEDefinition]:
        """
        Extract a single volatile table definition as a CTEDefinition.

        Args:
            create_stmt: SQLGlot Create expression
            create_sql: Original SQL text of the CREATE statement

        Returns:
            CTEDefinition or None if extraction fails
        """
        try:
            # Extract table name
            table_name = None
            if hasattr(create_stmt, 'this') and create_stmt.this:
                if hasattr(create_stmt.this, 'name'):
                    table_name = create_stmt.this.name
                elif hasattr(create_stmt.this, 'this') and hasattr(create_stmt.this.this, 'name'):
                    table_name = create_stmt.this.this.name
            
            if not table_name:
                # Try to extract from SQL text using regex
                import re
                match = re.search(r'VOLATILE\s+TABLE\s+([\w\.]+)', create_sql, re.IGNORECASE)
                if match:
                    table_name = match.group(1).split('.')[-1]  # Get just the table name
            
            if not table_name:
                return None
            
            # Extract the query (SELECT statement after AS)
            query = None
            definition_sql = ""
            
            if hasattr(create_stmt, 'expression') and create_stmt.expression:
                query = create_stmt.expression
                definition_sql = query.sql(dialect=self.dialect)
            else:
                # Try to extract from SQL text
                import re
                as_match = re.search(r'\bAS\s*\((.+?)\)\s*(WITH\s+DATA)?', create_sql, re.IGNORECASE | re.DOTALL)
                if as_match:
                    definition_sql = as_match.group(1).strip()
            
            # Extract columns
            columns = []
            if query and isinstance(query, exp.Select):
                columns = self._get_select_columns(query)
            
            # Find source tables from the query
            source_tables = []
            if query:
                source_tables = self._find_source_tables(query)
            
            # Find dependencies (other volatile tables or CTEs referenced)
            dependencies = []
            if query:
                # This would need the full list of volatile table names
                # For now, we'll leave it empty and let the caller handle dependencies
                pass
            
            return CTEDefinition(
                name=table_name,
                definition_sql=definition_sql,
                columns=columns,
                is_recursive=False,
                dependencies=dependencies,
                source_tables=source_tables,
                is_volatile_table=True
            )
        except Exception:
            return None

    def _extract_volatile_tables_from_text(self, sql_text: str, processed_names: Set[str]) -> List[CTEDefinition]:
        """
        Fallback text-based extraction of volatile tables using regex.

        Args:
            sql_text: Full SQL text
            processed_names: Set of already processed table names

        Returns:
            List of CTEDefinition objects
        """
        import re
        volatile_ctes = []
        
        # Pattern to match CREATE VOLATILE TABLE statements
        # Handles: CREATE MULTISET VOLATILE TABLE, CREATE VOLATILE TABLE, etc.
        pattern = r'CREATE\s+(?:MULTISET\s+)?VOLATILE\s+TABLE\s+([\w\.]+)\s+AS\s*\(([^;]+?)\)\s*(?:WITH\s+DATA)?'
        
        matches = re.finditer(pattern, sql_text, re.IGNORECASE | re.DOTALL)
        
        for match in matches:
            table_name = match.group(1).strip()
            
            # Remove schema prefix if present for comparison
            simple_name = table_name.split('.')[-1] if '.' in table_name else table_name
            
            if simple_name in processed_names or table_name in processed_names:
                continue
            
            processed_names.add(simple_name)
            processed_names.add(table_name)
            
            definition_sql = match.group(2).strip()
            
            # Try to parse the definition to extract columns and source tables
            columns = []
            source_tables = []
            
            try:
                parsed_def = sqlglot.parse_one(definition_sql, read=self.dialect)
                if isinstance(parsed_def, exp.Select):
                    columns = self._get_select_columns(parsed_def)
                    source_tables = self._find_source_tables(parsed_def)
            except Exception:
                pass
            
            volatile_cte = CTEDefinition(
                name=simple_name,
                definition_sql=definition_sql,
                columns=columns,
                is_recursive=False,
                dependencies=[],
                source_tables=source_tables,
                is_volatile_table=True
            )
            volatile_ctes.append(volatile_cte)
        
        return volatile_ctes

    def extract_all_where_clauses(self, ast: exp.Expression) -> List[Dict]:
        """
        Extract WHERE clauses from ALL contexts including subqueries, CTEs, and UNION branches.

        Args:
            ast: Parsed SQL AST

        Returns:
            List of dictionaries with WHERE clause information
        """
        where_clauses = []
        seen_where_sql = set()  # Deduplication
        
        # Find ALL WHERE clauses in the entire AST
        for where_expr in ast.find_all(exp.Where):
            where_sql = where_expr.sql(dialect=self.dialect)
            
            # Deduplicate
            if where_sql in seen_where_sql:
                continue
            seen_where_sql.add(where_sql)
            
            # Determine context
            context = self._determine_where_context(where_expr)
            
            # Extract columns referenced
            columns_referenced = []
            for column in where_expr.find_all(exp.Column):
                col_ref = self._create_column_ref(column)
                if col_ref:
                    columns_referenced.append(col_ref)
            
            # Check for subqueries in WHERE
            has_subquery = len(list(where_expr.find_all(exp.Subquery))) > 0
            
            where_info = {
                'sql_text': where_sql,
                'context': context,
                'columns_referenced': columns_referenced,
                'has_subquery': has_subquery
            }
            where_clauses.append(where_info)
        
        return where_clauses

    def _extract_where_clause_details(self, where_expr: exp.Where) -> Optional[Dict]:
        """
        Extract detailed information from a WHERE clause expression.

        Args:
            where_expr: SQLGlot Where expression

        Returns:
            Dictionary with WHERE clause details or None
        """
        if not where_expr or not where_expr.this:
            return None
        
        try:
            # Get the SQL text of the WHERE clause
            sql_text = where_expr.sql(dialect=self.dialect)
            
            # Extract all conditions
            conditions = self._parse_where_conditions(where_expr.this)
            
            # Extract all columns referenced in the WHERE clause
            columns_referenced = self._extract_columns_from_expression(where_expr)
            
            # Check if WHERE contains subqueries
            has_subquery = len(list(where_expr.find_all(exp.Subquery))) > 0
            
            # Determine the context (main query, subquery, CTE, etc.)
            context = self._determine_where_context(where_expr)
            
            return {
                'sql_text': sql_text,
                'conditions': conditions,
                'columns_referenced': columns_referenced,
                'has_subquery': has_subquery,
                'context': context
            }
        except Exception:
            return None

    def _parse_where_conditions(self, condition_expr: exp.Expression) -> List[Dict]:
        """
        Parse WHERE conditions recursively, handling AND/OR logic.

        Args:
            condition_expr: The condition expression from WHERE clause

        Returns:
            List of condition dictionaries
        """
        conditions = []
        
        if condition_expr is None:
            return conditions
        
        try:
            # Handle AND conditions
            if isinstance(condition_expr, exp.And):
                # Recursively process left and right sides
                conditions.extend(self._parse_where_conditions(condition_expr.left))
                conditions.extend(self._parse_where_conditions(condition_expr.right))
            
            # Handle OR conditions
            elif isinstance(condition_expr, exp.Or):
                # Recursively process left and right sides
                left_conditions = self._parse_where_conditions(condition_expr.left)
                right_conditions = self._parse_where_conditions(condition_expr.right)
                
                # Mark these as part of an OR group
                for cond in left_conditions:
                    cond['or_group'] = True
                for cond in right_conditions:
                    cond['or_group'] = True
                
                conditions.extend(left_conditions)
                conditions.extend(right_conditions)
            
            # Handle comparison operators (=, !=, <, >, <=, >=)
            elif isinstance(condition_expr, (exp.EQ, exp.NEQ, exp.LT, exp.GT, exp.LTE, exp.GTE)):
                conditions.append(self._extract_comparison_condition(condition_expr))
            
            # Handle LIKE conditions
            elif isinstance(condition_expr, exp.Like):
                conditions.append(self._extract_like_condition(condition_expr))
            
            # Handle IN conditions
            elif isinstance(condition_expr, exp.In):
                conditions.append(self._extract_in_condition(condition_expr))
            
            # Handle BETWEEN conditions
            elif isinstance(condition_expr, exp.Between):
                conditions.append(self._extract_between_condition(condition_expr))
            
            # Handle IS NULL / IS NOT NULL
            elif isinstance(condition_expr, exp.Is):
                conditions.append(self._extract_is_condition(condition_expr))
            
            # Handle EXISTS conditions
            elif isinstance(condition_expr, exp.Exists):
                conditions.append(self._extract_exists_condition(condition_expr))
            
            # Handle NOT conditions
            elif isinstance(condition_expr, exp.Not):
                inner_conditions = self._parse_where_conditions(condition_expr.this)
                for cond in inner_conditions:
                    cond['negated'] = True
                conditions.extend(inner_conditions)
            
            # Handle parenthesized expressions
            elif isinstance(condition_expr, exp.Paren):
                conditions.extend(self._parse_where_conditions(condition_expr.this))
            
            # Fallback for other expression types
            else:
                conditions.append({
                    'expression': condition_expr.sql(dialect=self.dialect),
                    'columns_referenced': self._extract_columns_from_expression(condition_expr),
                    'operator': type(condition_expr).__name__,
                    'has_subquery': len(list(condition_expr.find_all(exp.Subquery))) > 0
                })
        
        except Exception:
            # If parsing fails, return the raw expression
            try:
                conditions.append({
                    'expression': condition_expr.sql(dialect=self.dialect),
                    'columns_referenced': [],
                    'operator': 'UNKNOWN',
                    'has_subquery': False
                })
            except Exception:
                pass
        
        return conditions

    def _extract_comparison_condition(self, condition_expr: exp.Expression) -> Dict:
        """
        Extract details from a comparison condition (=, !=, <, >, etc.).

        Args:
            condition_expr: Comparison expression

        Returns:
            Dictionary with condition details
        """
        operator_map = {
            exp.EQ: '=',
            exp.NEQ: '!=',
            exp.LT: '<',
            exp.GT: '>',
            exp.LTE: '<=',
            exp.GTE: '>='
        }
        
        operator = operator_map.get(type(condition_expr), '=')
        
        columns = self._extract_columns_from_expression(condition_expr)
        has_subquery = len(list(condition_expr.find_all(exp.Subquery))) > 0
        
        return {
            'expression': condition_expr.sql(dialect=self.dialect),
            'columns_referenced': columns,
            'operator': operator,
            'has_subquery': has_subquery
        }

    def _extract_like_condition(self, condition_expr: exp.Like) -> Dict:
        """
        Extract details from a LIKE condition.

        Args:
            condition_expr: Like expression

        Returns:
            Dictionary with condition details
        """
        columns = self._extract_columns_from_expression(condition_expr)
        
        return {
            'expression': condition_expr.sql(dialect=self.dialect),
            'columns_referenced': columns,
            'operator': 'LIKE',
            'has_subquery': False
        }

    def _extract_in_condition(self, condition_expr: exp.In) -> Dict:
        """
        Extract details from an IN condition.

        Args:
            condition_expr: In expression

        Returns:
            Dictionary with condition details
        """
        columns = self._extract_columns_from_expression(condition_expr)
        has_subquery = len(list(condition_expr.find_all(exp.Subquery))) > 0
        
        return {
            'expression': condition_expr.sql(dialect=self.dialect),
            'columns_referenced': columns,
            'operator': 'IN',
            'has_subquery': has_subquery
        }

    def _extract_between_condition(self, condition_expr: exp.Between) -> Dict:
        """
        Extract details from a BETWEEN condition.

        Args:
            condition_expr: Between expression

        Returns:
            Dictionary with condition details
        """
        columns = self._extract_columns_from_expression(condition_expr)
        
        return {
            'expression': condition_expr.sql(dialect=self.dialect),
            'columns_referenced': columns,
            'operator': 'BETWEEN',
            'has_subquery': False
        }

    def _extract_is_condition(self, condition_expr: exp.Is) -> Dict:
        """
        Extract details from an IS NULL / IS NOT NULL condition.

        Args:
            condition_expr: Is expression

        Returns:
            Dictionary with condition details
        """
        columns = self._extract_columns_from_expression(condition_expr)
        
        # Determine if it's IS NULL or IS NOT NULL
        operator = 'IS NULL'
        if hasattr(condition_expr, 'args') and condition_expr.args.get('not'):
            operator = 'IS NOT NULL'
        
        return {
            'expression': condition_expr.sql(dialect=self.dialect),
            'columns_referenced': columns,
            'operator': operator,
            'has_subquery': False
        }

    def _extract_exists_condition(self, condition_expr: exp.Exists) -> Dict:
        """
        Extract details from an EXISTS condition.

        Args:
            condition_expr: Exists expression

        Returns:
            Dictionary with condition details
        """
        columns = self._extract_columns_from_expression(condition_expr)
        
        return {
            'expression': condition_expr.sql(dialect=self.dialect),
            'columns_referenced': columns,
            'operator': 'EXISTS',
            'has_subquery': True
        }

    def _extract_columns_from_expression(self, expression: exp.Expression) -> List[ColumnRef]:
        """
        Extract all column references from an expression.

        Args:
            expression: SQLGlot expression

        Returns:
            List of ColumnRef objects
        """
        columns = []
        
        if expression is None:
            return columns
        
        try:
            for col_expr in expression.find_all(exp.Column):
                try:
                    column_name = col_expr.name if hasattr(col_expr, 'name') else None
                    if not column_name:
                        continue
                    
                    # Extract table name safely
                    table_name = None
                    if hasattr(col_expr, 'table') and col_expr.table:
                        table_name = col_expr.table
                    
                    # Use empty string if no table name (required field)
                    columns.append(ColumnRef(
                        table_name=table_name or '',
                        column_name=column_name,
                        schema_name=None,
                        alias=None
                    ))
                except Exception:
                    continue
        except Exception:
            pass
        
        return columns

    def _determine_where_context(self, where_expr: exp.Where) -> str:
        """
        Determine the context of a WHERE clause.

        Args:
            where_expr: WHERE expression

        Returns:
            String describing the context
        """
        current = where_expr.parent
        
        while current:
            # Check if in a subquery
            if isinstance(current, exp.Subquery):
                return "SUBQUERY"
            
            # Check if in a CTE
            if isinstance(current, exp.CTE):
                cte_name = current.alias if hasattr(current, 'alias') else "unknown"
                return f"CTE:{cte_name}"
            
            # Check if in a UNION branch
            if isinstance(current, exp.Union):
                return "UNION_BRANCH"
            
            # Check if in CREATE statement (volatile table)
            if isinstance(current, exp.Create):
                return "VOLATILE_TABLE"
            
            current = current.parent
        
        return "MAIN_QUERY"

    def _preprocess_sql(self, sql: str) -> str:
        """
        Preprocess SQL to handle Teradata-specific syntax.

        Args:
            sql: Raw SQL string

        Returns:
            Normalized SQL string
        """
        import re
        # Handle Teradata 'SEL' abbreviation for SELECT
        # Match 'SEL' at word boundary, case insensitive
        # Avoid matching 'SEL' within words like 'SELF' or 'SELECT'
        normalized = re.sub(
            r'\bSEL\b(?!ECT)',
            'SELECT',
            sql,
            flags=re.IGNORECASE
        )
        return normalized

    def _generate_subquery_id(self, subquery_expr: exp.Expression) -> str:
        """
        Generate a unique identifier for a subquery based on its SQL and position.

        Args:
            subquery_expr: SQLGlot subquery expression

        Returns:
            Unique string identifier
        """
        # Use SQL text and hash for uniqueness
        sql_text = subquery_expr.sql(dialect=self.dialect)
        # Include parent context to differentiate same SQL in different locations
        parent_context = ""
        if subquery_expr.parent:
            parent_type = type(subquery_expr.parent).__name__
            parent_context = parent_type
        
        unique_key = f"{sql_text}|{parent_context}"
        return unique_key

    def _generate_function_id(self, func_expr: exp.Expression, depth: int = 0) -> str:
        """
        Generate a unique identifier for a function call.

        Args:
            func_expr: SQLGlot function expression
            depth: Nesting depth of the function

        Returns:
            Unique string identifier
        """
        func_name = func_expr.name if hasattr(func_expr, 'name') else str(type(func_expr).__name__)
        sql_text = func_expr.sql(dialect=self.dialect)
        
        # Include depth to differentiate nested vs top-level
        unique_key = f"{func_name}|{sql_text}|{depth}"
        return unique_key

    def _determine_subquery_type(self, subquery_expr: exp.Subquery) -> str:
        """
        Determine the type of subquery based on its context.
        
        Args:
            subquery_expr: SQLGlot Subquery expression
            
        Returns:
            String indicating subquery type
        """
        parent = subquery_expr.parent
        
        if not parent:
            return "UNKNOWN"
        
        if isinstance(parent, exp.From):
            return "DERIVED_TABLE"
        elif isinstance(parent, exp.In):
            return "IN_CLAUSE"
        elif isinstance(parent, exp.Exists):
            return "EXISTS"
        elif isinstance(parent, exp.EQ) or isinstance(parent, exp.GT) or isinstance(parent, exp.LT):
            return "SCALAR"
        elif isinstance(parent, exp.Select):
            return "SCALAR"
        elif isinstance(parent, exp.Join):
            return "JOIN_SUBQUERY"
        else:
            return "SCALAR"

    def _is_in_select_list(self, expr: exp.Expression) -> bool:
        """
        Check if an expression is within a SELECT list.

        Args:
            expr: SQLGlot expression

        Returns:
            True if in SELECT list, False otherwise
        """
        current = expr.parent
        while current:
            if isinstance(current, exp.Select):
                # Check if expr is in the expressions list
                for select_expr in current.expressions:
                    if self._contains_expression(select_expr, expr):
                        return True
                return False
            current = current.parent
        return False

    def _contains_expression(self, container: exp.Expression, target: exp.Expression) -> bool:
        """
        Check if container expression contains the target expression.

        Args:
            container: Expression to search in
            target: Expression to find

        Returns:
            True if target is found in container
        """
        if container is target:
            return True
        for child in container.walk():
            if child is target:
                return True
        return False

    def _is_correlated_subquery(self, subquery_expr: exp.Subquery) -> bool:
        """
        Check if a subquery is correlated (references outer query tables).
        
        Args:
            subquery_expr: SQLGlot Subquery expression
            
        Returns:
            True if correlated, False otherwise
        """
        # Get tables defined within the subquery
        inner_tables = set()
        for table in subquery_expr.find_all(exp.Table):
            if hasattr(table, 'name') and table.name:
                inner_tables.add(table.name.lower())
            if hasattr(table, 'alias') and table.alias:
                inner_tables.add(table.alias.lower())
        
        # Check columns - if any reference tables not in inner_tables, it's correlated
        for column in subquery_expr.find_all(exp.Column):
            if hasattr(column, 'table') and column.table:
                table_ref = column.table.lower()
                if table_ref not in inner_tables:
                    return True
        
        return False

    def _is_inside_expression(self, child: exp.Expression, container: exp.Expression) -> bool:
        """
        Check if child expression is inside container expression.

        Args:
            child: Potential child expression
            container: Container expression

        Returns:
            True if child is inside container
        """
        current = child.parent
        while current:
            if current is container:
                return True
            current = current.parent
        return False

    def _find_correlation_columns(self, subquery_expr: exp.Subquery, outer_ast: exp.Expression) -> List[str]:
        """
        Find columns that correlate the subquery to the outer query.

        Args:
            subquery_expr: The subquery expression
            outer_ast: The outer query AST

        Returns:
            List of correlation column references
        """
        correlation_columns = []
        
        # Get outer table names/aliases
        outer_tables = set()
        for table in outer_ast.find_all(exp.Table):
            if self._is_inside_expression(table, subquery_expr):
                continue
            table_name = table.name if hasattr(table, 'name') else None
            if table_name:
                outer_tables.add(table_name.lower())
            if hasattr(table, 'alias') and table.alias:
                outer_tables.add(table.alias.lower())
        
        # Get inner table names
        inner_tables = set()
        inner_query = subquery_expr.this
        for table in inner_query.find_all(exp.Table):
            table_name = table.name if hasattr(table, 'name') else None
            if table_name:
                inner_tables.add(table_name.lower())
            if hasattr(table, 'alias') and table.alias:
                inner_tables.add(table.alias.lower())
        
        # Find columns referencing outer tables
        for column in inner_query.find_all(exp.Column):
            table_ref = column.table if hasattr(column, 'table') else None
            if table_ref:
                table_ref_lower = table_ref.lower()
                if table_ref_lower in outer_tables and table_ref_lower not in inner_tables:
                    col_name = column.name if hasattr(column, 'name') else str(column)
                    correlation_columns.append(f"{table_ref}.{col_name}")
        
        return correlation_columns

    def _get_table_name(self, table_expr: exp.Expression) -> Optional[str]:
        """
        Safely extract table name from a table expression.

        Args:
            table_expr: SQLGlot expression (should be Table)

        Returns:
            Table name string or None
        """
        if not isinstance(table_expr, exp.Table):
            return None
        
        table_name = table_expr.name if hasattr(table_expr, 'name') else None
        if not table_name:
            return None
        
        # Check for schema/database prefix
        if hasattr(table_expr, 'db') and table_expr.db:
            return f"{table_expr.db}.{table_name}"
        
        return table_name

    def _create_column_ref(self, column_expr: exp.Column) -> Optional[ColumnRef]:
        """
        Create a ColumnRef from a SQLGlot Column expression.

        Args:
            column_expr: SQLGlot Column expression

        Returns:
            ColumnRef object or None
        """
        if not isinstance(column_expr, exp.Column):
            return None
        
        column_name = column_expr.name if hasattr(column_expr, 'name') else None
        if not column_name:
            return None
        
        table_name = column_expr.table if hasattr(column_expr, 'table') else ""
        if not table_name:
            table_name = ""
        
        return ColumnRef(
            table_name=table_name,
            column_name=column_name
        )

    def _extract_all_where_clauses(self, ast: exp.Expression) -> List[exp.Where]:
        """
        Recursively extract ALL WHERE clauses from the AST including:
        - Main query WHERE
        - Subqueries in SELECT list
        - Subqueries in FROM clause (derived tables)
        - UNION branch WHERE clauses
        - Subqueries in WHERE conditions
        - CTE/volatile table definitions

        Args:
            ast: Parsed SQL AST

        Returns:
            List of all WHERE clause expressions
        """
        all_where_clauses = []
        processed_ids = set()
        
        def collect_where_clauses(node: exp.Expression):
            """Recursively collect WHERE clauses from all contexts."""
            if node is None:
                return
            
            # Generate unique ID for this node to avoid duplicates
            node_id = id(node)
            if node_id in processed_ids:
                return
            processed_ids.add(node_id)
            
            # If this is a WHERE clause, add it
            if isinstance(node, exp.Where):
                all_where_clauses.append(node)
            
            # Recursively process all child nodes
            for child in node.walk():
                child_id = id(child)
                if child_id not in processed_ids:
                    processed_ids.add(child_id)
                    if isinstance(child, exp.Where):
                        all_where_clauses.append(child)
        
        # Use find_all to get all WHERE clauses
        for where_clause in ast.find_all(exp.Where):
            where_id = id(where_clause)
            if where_id not in processed_ids:
                processed_ids.add(where_id)
                all_where_clauses.append(where_clause)
        
        # Also check UNION branches explicitly
        for union_expr in ast.find_all(exp.Union):
            # Check left side of union
            if hasattr(union_expr, 'left') and union_expr.left:
                for where_clause in union_expr.left.find_all(exp.Where):
                    where_id = id(where_clause)
                    if where_id not in processed_ids:
                        processed_ids.add(where_id)
                        all_where_clauses.append(where_clause)
            
            # Check right side of union
            if hasattr(union_expr, 'right') and union_expr.right:
                for where_clause in union_expr.right.find_all(exp.Where):
                    where_id = id(where_clause)
                    if where_id not in processed_ids:
                        processed_ids.add(where_id)
                        all_where_clauses.append(where_clause)
        
        # Check subqueries explicitly
        for subquery in ast.find_all(exp.Subquery):
            for where_clause in subquery.find_all(exp.Where):
                where_id = id(where_clause)
                if where_id not in processed_ids:
                    processed_ids.add(where_id)
                    all_where_clauses.append(where_clause)
        
        return all_where_clauses

    def _generate_function_unique_id(self, func_expr: exp.Expression) -> str:
        """
        Generate a unique identifier for a function to prevent double-counting.
        Uses position information and normalized SQL text.

        Args:
            func_expr: Function expression

        Returns:
            Unique string identifier for this function instance
        """
        # Get the SQL representation normalized
        try:
            func_sql = func_expr.sql(dialect=self.dialect).upper().strip()
        except Exception:
            func_sql = str(func_expr).upper().strip()
        
        # Get position information if available
        start_pos = -1
        end_pos = -1
        
        if hasattr(func_expr, 'meta') and func_expr.meta:
            if hasattr(func_expr.meta, 'start'):
                start_pos = func_expr.meta.start
            if hasattr(func_expr.meta, 'end'):
                end_pos = func_expr.meta.end
        
        # Create unique ID combining SQL text and position
        # This ensures same function at different positions are counted separately
        # but same function encountered through different traversal paths is counted once
        unique_id = f"{func_sql}|{start_pos}|{end_pos}|{id(func_expr)}"
        
        return unique_id

    def _is_function_already_extracted(self, func_expr: exp.Expression) -> bool:
        """
        Check if a function has already been extracted to prevent duplicates.

        Args:
            func_expr: Function expression to check

        Returns:
            True if already extracted, False otherwise
        """
        unique_id = self._generate_function_unique_id(func_expr)
        
        if unique_id in self._extracted_function_ids:
            return True
        
        self._extracted_function_ids.add(unique_id)
        return False

    def _generate_subquery_unique_id(self, subquery_expr: exp.Expression) -> str:
        """
        Generate a unique identifier for a subquery to prevent double-counting.

        Args:
            subquery_expr: Subquery expression

        Returns:
            Unique string identifier for this subquery instance
        """
        # Get the SQL representation normalized
        try:
            subquery_sql = subquery_expr.sql(dialect=self.dialect).upper().strip()
        except Exception:
            subquery_sql = str(subquery_expr).upper().strip()
        
        # Use object id as part of unique identifier
        # This ensures same subquery object is not counted twice
        unique_id = f"{hash(subquery_sql)}|{id(subquery_expr)}"
        
        return unique_id

    def _is_subquery_already_extracted(self, subquery_expr: exp.Expression) -> bool:
        """
        Check if a subquery has already been extracted to prevent duplicates.

        Args:
            subquery_expr: Subquery expression to check

        Returns:
            True if already extracted, False otherwise
        """
        unique_id = self._generate_subquery_unique_id(subquery_expr)
        
        if unique_id in self._extracted_subquery_ids:
            return True
        
        self._extracted_subquery_ids.add(unique_id)
        return False

    def _get_referenced_tables(self, query_expr: exp.Expression) -> List[str]:
        """
        Extract all referenced table names from a query expression.
        Helper method for volatile table extraction and CTE dependency tracking.

        Args:
            query_expr: Query expression to analyze

        Returns:
            List of table names referenced in the query
        """
        tables = []
        processed = set()
        
        if query_expr is None:
            return tables
        
        for table_expr in query_expr.find_all(exp.Table):
            table_name = self._get_table_name_safe(table_expr)
            if table_name and table_name not in processed:
                processed.add(table_name)
                tables.append(table_name)
        
        return tables

    def _get_table_name_safe(self, table_expr: exp.Expression) -> Optional[str]:
        """
        Safely extract table name from a table expression.
        Handles both Table and other expression types without crashing.

        Args:
            table_expr: Expression that might be a table reference

        Returns:
            Table name string or None if not extractable
        """
        if not isinstance(table_expr, exp.Table):
            return None
        
        # Safely extract table name
        table_name = None
        if hasattr(table_expr, 'name') and table_expr.name:
            table_name = table_expr.name
        elif hasattr(table_expr, 'this') and hasattr(table_expr.this, 'name'):
            table_name = table_expr.this.name
        
        if not table_name:
            return None
        
        # Check for schema/database prefix
        schema_prefix = None
        if hasattr(table_expr, 'db') and table_expr.db:
            schema_prefix = table_expr.db
        elif hasattr(table_expr, 'catalog') and table_expr.catalog:
            schema_prefix = table_expr.catalog
        
        if schema_prefix:
            return f"{schema_prefix}.{table_name}"
        
        return table_name

    def _extract_subquery(self, subquery_expr: exp.Subquery) -> Optional[Subquery]:
        """
        Extract details from a subquery expression.
        
        Args:
            subquery_expr: SQLGlot Subquery expression
            
        Returns:
            Subquery object or None
        """
        try:
            # Get the inner SELECT
            inner_select = subquery_expr.this if hasattr(subquery_expr, 'this') else None
            if not inner_select:
                return None
            
            # Generate SQL text
            sql_text = subquery_expr.sql(dialect=self.dialect)
            
            # Determine subquery type based on context
            subquery_type = self._determine_subquery_type(subquery_expr)
            
            # Get alias if present
            alias = None
            if hasattr(subquery_expr, 'alias') and subquery_expr.alias:
                alias = subquery_expr.alias
            
            # Extract source tables
            source_tables = []
            for table in subquery_expr.find_all(exp.Table):
                if hasattr(table, 'name') and table.name:
                    tbl_name = table.name
                    if hasattr(table, 'db') and table.db:
                        tbl_name = f"{table.db}.{tbl_name}"
                    if tbl_name not in source_tables:
                        source_tables.append(tbl_name)
            
            # Extract output columns
            output_columns = []
            if isinstance(inner_select, exp.Select):
                output_columns = self._get_select_columns(inner_select)
            
            # Check if correlated
            is_correlated = self._is_correlated_subquery(subquery_expr)
            
            return Subquery(
                alias=alias or "",
                query_sql=sql_text,
                context=subquery_type,
                is_correlated=is_correlated,
                output_columns=output_columns if output_columns else [],
                source_tables=source_tables if source_tables else []
            )
            
        except Exception as e:
            print(f"  DEBUG: Error extracting subquery: {e}")
            return None

    def _is_nested_select(self, select_expr: exp.Select, root_ast: exp.Expression) -> bool:
        """
        Check if a SELECT expression is nested (not the main query).
        
        Args:
            select_expr: The SELECT expression to check
            root_ast: The root AST
            
        Returns:
            True if nested, False otherwise
        """
        # Walk up the parent chain
        current = select_expr.parent
        while current:
            # If we find a Subquery, From, Where, or similar, it's nested
            if isinstance(current, (exp.Subquery, exp.In, exp.Exists)):
                return True
            # If we reach the root, it's not nested
            if current == root_ast:
                return False
            current = current.parent if hasattr(current, 'parent') else None
        return False

    def _extract_select_as_subquery(self, select_expr: exp.Select) -> Optional[Subquery]:
        """
        Extract a SELECT expression as a subquery.
        
        Args:
            select_expr: SQLGlot Select expression
            
        Returns:
            Subquery object or None
        """
        try:
            sql_text = select_expr.sql(dialect=self.dialect)
            
            # Determine type based on parent context
            subquery_type = "SCALAR"
            parent = select_expr.parent
            if parent:
                if isinstance(parent, exp.From):
                    subquery_type = "DERIVED_TABLE"
                elif isinstance(parent, exp.In):
                    subquery_type = "IN_CLAUSE"
                elif isinstance(parent, exp.Exists):
                    subquery_type = "EXISTS"
            
            # Extract source tables
            source_tables = []
            for table in select_expr.find_all(exp.Table):
                if hasattr(table, 'name') and table.name:
                    tbl_name = table.name
                    if hasattr(table, 'db') and table.db:
                        tbl_name = f"{table.db}.{tbl_name}"
                    if tbl_name not in source_tables:
                        source_tables.append(tbl_name)
            
            # Extract output columns
            output_columns = self._get_select_columns(select_expr)
            
            return Subquery(
                alias="",
                query_sql=sql_text,
                context=subquery_type,
                is_correlated=False,
                output_columns=output_columns if output_columns else [],
                source_tables=source_tables if source_tables else []
            )
            
        except Exception as e:
            print(f"  DEBUG: Error extracting select as subquery: {e}")
            return None
