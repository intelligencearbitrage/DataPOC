"""
Function Extractor module.

Extracts all function calls with complete parameter details including
nested functions, aggregate functions, and window functions.
"""

import sqlglot
from sqlglot import exp
from typing import List, Optional, Set
import sys
import os

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from models.data_models import FunctionCall, FunctionParameter, ColumnRef


class FunctionExtractor:
    """
    Extract all function calls with complete parameter details.
    Captures built-in functions, aggregates, window functions, and UDFs.
    """

    # Common aggregate functions
    AGGREGATE_FUNCTIONS = {
        'SUM', 'COUNT', 'AVG', 'MIN', 'MAX', 'STDDEV', 'VARIANCE',
        'LISTAGG', 'STRING_AGG', 'GROUP_CONCAT', 'ARRAY_AGG',
        'FIRST', 'LAST', 'MEDIAN', 'PERCENTILE', 'PERCENTILE_CONT',
        'PERCENTILE_DISC', 'APPROX_COUNT_DISTINCT'
    }

    # Common window functions
    WINDOW_FUNCTIONS = {
        'ROW_NUMBER', 'RANK', 'DENSE_RANK', 'NTILE',
        'LEAD', 'LAG', 'FIRST_VALUE', 'LAST_VALUE', 'NTH_VALUE',
        'CUME_DIST', 'PERCENT_RANK'
    }

    def __init__(self, dialect: str = "teradata"):
        """
        Initialize extractor.

        Args:
            dialect: SQL dialect for generating SQL text
        """
        self.dialect = dialect

    def extract(self, ast: exp.Expression) -> List[FunctionCall]:
        """
        Extract all function calls from AST.

        Args:
            ast: Parsed SQL AST

        Returns:
            List of FunctionCall objects
        """
        functions = []
        seen_sql: Set[str] = set()

        for func_node in ast.find_all(exp.Func):
            func_sql = func_node.sql(dialect=self.dialect)

            # Avoid duplicates
            if func_sql not in seen_sql:
                seen_sql.add(func_sql)
                func_call = self._extract_function(func_node)
                functions.append(func_call)

        return functions

    def _extract_function(self, func_node: exp.Func) -> FunctionCall:
        """
        Extract a single function call with all details.

        Args:
            func_node: SQLGlot Func expression

        Returns:
            FunctionCall with complete details
        """
        func_name = self._get_function_name(func_node)

        # Check if aggregate or window function
        is_aggregate = func_name.upper() in self.AGGREGATE_FUNCTIONS
        is_window = func_name.upper() in self.WINDOW_FUNCTIONS

        # Extract parameters
        parameters = self._extract_parameters(func_node)

        # Find nested functions
        nested_functions = self._find_nested_functions(func_node)

        # Handle window function specifics
        window_partition_by = []
        window_order_by = []

        # Check for OVER clause (window function)
        parent = func_node.parent
        if parent and isinstance(parent, exp.Window):
            is_window = True
            window_partition_by = self._extract_partition_by(parent)
            window_order_by = self._extract_order_by(parent)

        return FunctionCall(
            function_name=func_name,
            sql_text=func_node.sql(dialect=self.dialect),
            parameters=parameters,
            nested_functions=nested_functions,
            return_type=self._infer_return_type(func_node),
            is_aggregate=is_aggregate,
            is_window=is_window,
            window_partition_by=window_partition_by,
            window_order_by=window_order_by
        )

    def _get_function_name(self, func_node: exp.Func) -> str:
        """
        Get the function name.

        Args:
            func_node: SQLGlot Func expression

        Returns:
            Function name string
        """
        # Try sql_name() method first
        if hasattr(func_node, 'sql_name'):
            try:
                return func_node.sql_name()
            except Exception:
                pass

        # Fall back to class name
        return func_node.__class__.__name__

    def _extract_parameters(self, func_node: exp.Func) -> List[FunctionParameter]:
        """
        Extract function parameters.

        Args:
            func_node: SQLGlot Func expression

        Returns:
            List of FunctionParameter objects
        """
        parameters = []

        # Get expressions (arguments) from the function
        expressions = []

        # Check for 'expressions' attribute
        if hasattr(func_node, 'expressions') and func_node.expressions:
            expressions = func_node.expressions

        # Check for 'this' attribute (single argument)
        elif func_node.this:
            expressions = [func_node.this]

        # Check args
        elif func_node.args:
            for key, value in func_node.args.items():
                if value is not None:
                    if isinstance(value, list):
                        expressions.extend(value)
                    elif isinstance(value, exp.Expression):
                        expressions.append(value)

        for i, param_expr in enumerate(expressions):
            if param_expr is None:
                continue

            is_literal = self._is_literal(param_expr)
            literal_value = None

            if is_literal:
                literal_value = param_expr.sql(dialect=self.dialect)

            parameters.append(FunctionParameter(
                position=i,
                expression=param_expr.sql(dialect=self.dialect) if param_expr else "",
                columns_referenced=self._extract_columns(param_expr),
                is_literal=is_literal,
                literal_value=literal_value
            ))

        return parameters

    def _is_literal(self, expr: exp.Expression) -> bool:
        """
        Check if an expression is a literal value.

        Args:
            expr: SQLGlot expression

        Returns:
            True if literal, False otherwise
        """
        # Check for various literal types that may exist in different sqlglot versions
        literal_types = [exp.Literal, exp.Null, exp.Boolean, exp.Star]

        # Add optional types if they exist
        for type_name in ['Number', 'String']:
            if hasattr(exp, type_name):
                literal_types.append(getattr(exp, type_name))

        return isinstance(expr, tuple(literal_types))

    def _extract_columns(self, expr: exp.Expression) -> List[ColumnRef]:
        """
        Extract all column references from an expression.

        Args:
            expr: SQLGlot expression

        Returns:
            List of ColumnRef objects
        """
        columns = []

        if expr is None:
            return columns

        for col in expr.find_all(exp.Column):
            columns.append(ColumnRef(
                table_name=col.table if col.table else "",
                column_name=col.name
            ))

        return columns

    def _find_nested_functions(self, func_node: exp.Func) -> List[FunctionCall]:
        """
        Find functions nested within this function's arguments.

        Args:
            func_node: SQLGlot Func expression

        Returns:
            List of nested FunctionCall objects
        """
        nested = []
        func_sql = func_node.sql(dialect=self.dialect)

        for nested_func in func_node.find_all(exp.Func):
            nested_sql = nested_func.sql(dialect=self.dialect)

            # Skip self
            if nested_sql == func_sql:
                continue

            # Only include direct children (avoid deep nesting)
            if self._is_direct_child(func_node, nested_func):
                nested.append(self._extract_function(nested_func))

        return nested

    def _is_direct_child(self, parent: exp.Func, child: exp.Func) -> bool:
        """
        Check if child is a direct nested function of parent.

        Args:
            parent: Parent function node
            child: Potential child function node

        Returns:
            True if direct child, False otherwise
        """
        # Check depth difference
        parent_depth = len(list(parent.walk()))
        child_parent = child.parent

        while child_parent:
            if isinstance(child_parent, exp.Func) and child_parent != parent:
                return False
            if child_parent == parent:
                return True
            child_parent = child_parent.parent

        return False

    def _infer_return_type(self, func_node: exp.Func) -> Optional[str]:
        """
        Infer the return type of a function.

        Args:
            func_node: SQLGlot Func expression

        Returns:
            Inferred return type or None
        """
        func_name = self._get_function_name(func_node).upper()

        # Type inference based on function name
        type_map = {
            # String functions
            'UPPER': 'VARCHAR', 'LOWER': 'VARCHAR', 'TRIM': 'VARCHAR',
            'LTRIM': 'VARCHAR', 'RTRIM': 'VARCHAR', 'SUBSTRING': 'VARCHAR',
            'CONCAT': 'VARCHAR', 'REPLACE': 'VARCHAR', 'COALESCE': 'ANY',

            # Numeric functions
            'SUM': 'NUMERIC', 'AVG': 'NUMERIC', 'COUNT': 'INTEGER',
            'ABS': 'NUMERIC', 'ROUND': 'NUMERIC', 'FLOOR': 'INTEGER',
            'CEIL': 'INTEGER', 'MOD': 'NUMERIC',

            # Date functions
            'CURRENT_DATE': 'DATE', 'CURRENT_TIMESTAMP': 'TIMESTAMP',
            'DATEADD': 'DATE', 'DATEDIFF': 'INTEGER', 'YEAR': 'INTEGER',
            'MONTH': 'INTEGER', 'DAY': 'INTEGER',

            # Window functions
            'ROW_NUMBER': 'INTEGER', 'RANK': 'INTEGER', 'DENSE_RANK': 'INTEGER',
            'NTILE': 'INTEGER',

            # Type conversion
            'CAST': 'CONVERTED', 'CONVERT': 'CONVERTED',

            # Aggregate
            'MIN': 'ANY', 'MAX': 'ANY',
        }

        return type_map.get(func_name)

    def _extract_partition_by(self, window: exp.Window) -> List[ColumnRef]:
        """
        Extract PARTITION BY columns from a window function.

        Args:
            window: SQLGlot Window expression

        Returns:
            List of ColumnRef objects
        """
        columns = []

        partition_by = window.args.get("partition_by")
        if partition_by:
            for col in partition_by:
                if isinstance(col, exp.Column):
                    columns.append(ColumnRef(
                        table_name=col.table if col.table else "",
                        column_name=col.name
                    ))

        return columns

    def _extract_order_by(self, window: exp.Window) -> List[ColumnRef]:
        """
        Extract ORDER BY columns from a window function.

        Args:
            window: SQLGlot Window expression

        Returns:
            List of ColumnRef objects
        """
        columns = []

        order_by = window.args.get("order")
        if order_by:
            if isinstance(order_by, exp.Order):
                for ordered_expr in order_by.expressions:
                    col = ordered_expr.this if isinstance(ordered_expr, exp.Ordered) else ordered_expr
                    if isinstance(col, exp.Column):
                        columns.append(ColumnRef(
                            table_name=col.table if col.table else "",
                            column_name=col.name
                        ))

        return columns

    def get_aggregate_functions(self, functions: List[FunctionCall]) -> List[FunctionCall]:
        """
        Filter to only aggregate functions.

        Args:
            functions: List of all FunctionCall objects

        Returns:
            List of aggregate FunctionCall objects
        """
        return [f for f in functions if f.is_aggregate]

    def get_window_functions(self, functions: List[FunctionCall]) -> List[FunctionCall]:
        """
        Filter to only window functions.

        Args:
            functions: List of all FunctionCall objects

        Returns:
            List of window FunctionCall objects
        """
        return [f for f in functions if f.is_window]

    def get_all_function_columns(self, functions: List[FunctionCall]) -> List[ColumnRef]:
        """
        Get all columns referenced in function calls.

        Args:
            functions: List of FunctionCall objects

        Returns:
            List of all unique ColumnRef objects
        """
        columns = []
        for func in functions:
            columns.extend(func.get_all_columns())
        return list(set(columns))
