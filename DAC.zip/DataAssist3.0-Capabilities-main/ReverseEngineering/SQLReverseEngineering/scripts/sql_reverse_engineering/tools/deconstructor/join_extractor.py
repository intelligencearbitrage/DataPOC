"""
JOIN Extractor module.

Extracts JOIN conditions with complete predicate details including
join type, tables involved, and all ON conditions.
"""

import sqlglot
from sqlglot import exp
from typing import List, Optional, Tuple
import sys
import os

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from models.data_models import JoinInfo, JoinCondition, ColumnRef


class JoinExtractor:
    """
    Extract JOIN conditions with complete predicate details.
    Captures join type, participating tables, and all ON conditions.
    """

    def __init__(self, dialect: str = "teradata"):
        """
        Initialize extractor.

        Args:
            dialect: SQL dialect for generating SQL text
        """
        self.dialect = dialect

    def extract(self, ast: exp.Expression) -> List[JoinInfo]:
        """
        Extract all JOINs with complete condition details.

        Only extracts joins from the outermost query level (and UNION
        branches at the same level). Joins inside scalar subqueries
        (e.g. in CASE/COALESCE expressions) are excluded — they belong
        to a different query scope.

        Args:
            ast: Parsed SQL AST

        Returns:
            List of JoinInfo objects
        """
        joins = []

        # Collect outermost SELECT nodes (handles UNION branches)
        outer_selects = self._get_outer_selects(ast)

        for select_node in outer_selects:
            joins_list = select_node.args.get("joins") or []
            for join_node in joins_list:
                join_info = self._extract_join(join_node, ast)
                joins.append(join_info)

        return joins

    def _get_outer_selects(self, ast: exp.Expression) -> List[exp.Select]:
        """
        Get outermost SELECT nodes, including UNION branches.

        Args:
            ast: Parsed SQL AST

        Returns:
            List of outermost Select expressions
        """
        # Handle UNION — collect all branch SELECTs
        if isinstance(ast, exp.Union):
            result = []
            for node in ast.find_all(exp.Select):
                # Only include SELECTs whose parent chain goes through
                # Union nodes up to the root — not nested subqueries
                parent = node.parent
                is_outer = False
                while parent is not None:
                    if parent is ast:
                        is_outer = True
                        break
                    if isinstance(parent, (exp.Union,)):
                        parent = parent.parent
                        continue
                    # If we hit a Subquery or another Select, it's nested
                    break
                if is_outer:
                    result.append(node)
            return result

        # Handle INSERT ... SELECT — find the inner SELECT
        if isinstance(ast, exp.Insert):
            inner = ast.find(exp.Select)
            if inner:
                # The SELECT might be a UNION
                select_parent = inner.parent
                if isinstance(select_parent, exp.Union):
                    return self._get_outer_selects(select_parent)
                return [inner]
            return []

        # Handle CREATE TABLE AS SELECT
        if isinstance(ast, exp.Create):
            inner = ast.find(exp.Select)
            if inner:
                select_parent = inner.parent
                if isinstance(select_parent, exp.Union):
                    return self._get_outer_selects(select_parent)
                return [inner]
            return []

        # Plain SELECT
        if isinstance(ast, exp.Select):
            return [ast]

        # Fallback: find first Select
        sel = ast.find(exp.Select)
        return [sel] if sel else []

    def _extract_join(self, join_node: exp.Join, ast: exp.Expression) -> JoinInfo:
        """
        Extract a single JOIN with all details.

        Args:
            join_node: SQLGlot Join expression
            ast: Full AST for context

        Returns:
            JoinInfo with complete details
        """
        # Determine join type
        join_type = self._get_join_type(join_node)

        # Get right table (the table being joined)
        right_table, right_alias = self._get_table_info(join_node.this)

        # Get left table (from preceding FROM or JOIN)
        left_table, left_alias = self._get_left_table(join_node, ast)

        # Extract ON conditions
        on_expr = join_node.args.get("on")
        conditions = []
        predicate_sql = None

        if on_expr:
            predicate_sql = on_expr.sql(dialect=self.dialect)
            conditions = self._extract_conditions(on_expr)

        return JoinInfo(
            join_type=join_type,
            left_table=left_table,
            right_table=right_table,
            left_alias=left_alias,
            right_alias=right_alias,
            conditions=conditions,
            predicate_sql=predicate_sql
        )

    def _get_join_type(self, join_node: exp.Join) -> str:
        """
        Determine the type of JOIN.

        Args:
            join_node: SQLGlot Join expression

        Returns:
            Join type string: INNER, LEFT, RIGHT, FULL, CROSS
        """
        # Check for specific join type flags
        if join_node.args.get("side"):
            side = str(join_node.args.get("side")).upper()
            if "LEFT" in side:
                return "LEFT"
            elif "RIGHT" in side:
                return "RIGHT"
            elif "FULL" in side:
                return "FULL"

        if join_node.args.get("kind"):
            kind = str(join_node.args.get("kind")).upper()
            if "CROSS" in kind:
                return "CROSS"
            elif "OUTER" in kind:
                return "FULL"

        # Default to INNER
        return "INNER"

    def _get_table_info(self, table_expr: exp.Expression) -> Tuple[str, Optional[str]]:
        """
        Extract table name and alias from a table expression.

        Args:
            table_expr: SQLGlot expression representing a table

        Returns:
            Tuple of (table_name, alias)
        """
        if table_expr is None:
            return "", None

        # Handle Table expression
        if isinstance(table_expr, exp.Table):
            name = table_expr.name
            if table_expr.db:
                name = f"{table_expr.db}.{name}"
            alias = table_expr.alias if hasattr(table_expr, 'alias') else None
            return name, alias

        # Handle Alias expression
        if isinstance(table_expr, exp.Alias):
            inner = table_expr.this
            if isinstance(inner, exp.Table):
                name = inner.name
                if inner.db:
                    name = f"{inner.db}.{name}"
                return name, table_expr.alias

        # Handle Subquery
        if isinstance(table_expr, exp.Subquery):
            alias = table_expr.alias if hasattr(table_expr, 'alias') else "subquery"
            return f"({table_expr.this.sql(dialect=self.dialect)[:50]}...)", alias

        # Fallback
        return str(table_expr), None

    def _get_left_table(self, join_node: exp.Join, ast: exp.Expression) -> Tuple[str, Optional[str]]:
        """
        Get the left table in a JOIN (the table being joined to).

        For chained joins (FROM A JOIN B JOIN C), the left table of
        the Nth join is the right table of the (N-1)th join — not the
        FROM table. Only the first join's left table is the FROM table.

        Args:
            join_node: SQLGlot Join expression
            ast: Full AST for context

        Returns:
            Tuple of (table_name, alias)
        """
        # Walk up to find the nearest enclosing Select
        parent = join_node.parent
        while parent is not None:
            if isinstance(parent, exp.Select):
                joins_list = parent.args.get("joins") or []
                # Find position of this join in the chain
                for idx, j in enumerate(joins_list):
                    if j is join_node:
                        if idx > 0:
                            # Left table is the preceding join's right table
                            return self._get_table_info(joins_list[idx - 1].this)
                        else:
                            # First join — left table is FROM clause
                            from_clause = parent.args.get("from") or parent.args.get("from_")
                            if from_clause:
                                return self._get_table_info(from_clause.this)
                        break
                # If not found in joins list, try FROM as fallback
                from_clause = parent.args.get("from") or parent.args.get("from_")
                if from_clause:
                    return self._get_table_info(from_clause.this)
                break
            parent = getattr(parent, 'parent', None)

        # Fallback: search the full AST
        from_clause = ast.find(exp.From)
        if from_clause:
            return self._get_table_info(from_clause.this)

        return "", None

    def _extract_conditions(self, on_expr: exp.Expression) -> List[JoinCondition]:
        """
        Extract individual conditions from an ON clause.

        Args:
            on_expr: SQLGlot expression for ON clause

        Returns:
            List of JoinCondition objects
        """
        conditions = []

        # Handle simple equality
        if isinstance(on_expr, exp.EQ):
            conditions.append(self._make_condition(on_expr, "="))
            return conditions

        # Handle AND conditions
        if isinstance(on_expr, exp.And):
            for cond in self._flatten_and(on_expr):
                conditions.extend(self._extract_conditions(cond))
            return conditions

        # Handle OR conditions
        if isinstance(on_expr, exp.Or):
            # Keep OR as a single complex condition
            left_col = self._get_first_column(on_expr)
            if left_col:
                conditions.append(JoinCondition(
                    left_column=left_col,
                    operator="COMPLEX",
                    right_literal=on_expr.sql(dialect=self.dialect)
                ))
            return conditions

        # Handle other comparison operators
        if isinstance(on_expr, (exp.GT, exp.GTE, exp.LT, exp.LTE, exp.NEQ)):
            operator_map = {
                exp.GT: ">",
                exp.GTE: ">=",
                exp.LT: "<",
                exp.LTE: "<=",
                exp.NEQ: "<>"
            }
            conditions.append(self._make_condition(on_expr, operator_map.get(type(on_expr), "?")))
            return conditions

        # Fallback for other expressions
        left_col = self._get_first_column(on_expr)
        if left_col:
            conditions.append(JoinCondition(
                left_column=left_col,
                operator="COMPLEX",
                right_literal=on_expr.sql(dialect=self.dialect)
            ))

        return conditions

    def _flatten_and(self, and_expr: exp.And) -> List[exp.Expression]:
        """
        Flatten nested AND expressions.

        Args:
            and_expr: SQLGlot And expression

        Returns:
            List of individual condition expressions
        """
        result = []

        if isinstance(and_expr.this, exp.And):
            result.extend(self._flatten_and(and_expr.this))
        else:
            result.append(and_expr.this)

        if isinstance(and_expr.expression, exp.And):
            result.extend(self._flatten_and(and_expr.expression))
        else:
            result.append(and_expr.expression)

        return result

    def _make_condition(self, comp_expr: exp.Expression, operator: str) -> JoinCondition:
        """
        Create a JoinCondition from a comparison expression.

        Args:
            comp_expr: Comparison expression
            operator: Comparison operator string

        Returns:
            JoinCondition object
        """
        left = comp_expr.this
        right = comp_expr.expression

        left_col = self._expr_to_column_ref(left)
        right_col = self._expr_to_column_ref(right)

        if not left_col:
            # If left is not a column, swap
            if right_col:
                left_col = right_col
                right_col = None

        if not left_col:
            left_col = ColumnRef(table_name="", column_name=left.sql(dialect=self.dialect) if left else "?")

        return JoinCondition(
            left_column=left_col,
            operator=operator,
            right_column=right_col,
            right_literal=right.sql(dialect=self.dialect) if right and not right_col else None
        )

    def _expr_to_column_ref(self, expr: exp.Expression) -> Optional[ColumnRef]:
        """
        Convert an expression to a ColumnRef if it's a column.

        Args:
            expr: SQLGlot expression

        Returns:
            ColumnRef or None
        """
        if expr is None:
            return None

        if isinstance(expr, exp.Column):
            return ColumnRef(
                table_name=expr.table if expr.table else "",
                column_name=expr.name
            )

        return None

    def _get_first_column(self, expr: exp.Expression) -> Optional[ColumnRef]:
        """
        Get the first column reference in an expression.

        Args:
            expr: SQLGlot expression

        Returns:
            First ColumnRef found or None
        """
        col = expr.find(exp.Column)
        if col:
            return ColumnRef(
                table_name=col.table if col.table else "",
                column_name=col.name
            )
        return None

    def extract_scalar_subquery_joins(self, ast: exp.Expression) -> List[Tuple[JoinInfo, List[str]]]:
        """
        Extract JOINs from scalar subqueries (e.g. inside CASE/COALESCE in the SELECT list).

        These are joins that exist inside correlated subqueries, not at the
        outer query level. Returns tuples of (JoinInfo, [column_aliases])
        where column_aliases are all SELECT column aliases that contain
        this join pattern.

        Args:
            ast: Parsed SQL AST

        Returns:
            List of (JoinInfo, [column_aliases]) tuples, deduplicated by join signature
        """
        # Collect all (join_key, JoinInfo, col_alias) triples
        raw_results = []
        outer_selects = self._get_outer_selects(ast)

        for select_node in outer_selects:
            select_expressions = select_node.args.get("expressions") or []
            for sel_expr in select_expressions:
                col_alias = ""
                if isinstance(sel_expr, exp.Alias):
                    col_alias = sel_expr.alias or ""

                for subq in sel_expr.find_all(exp.Subquery):
                    inner = subq.this if hasattr(subq, 'this') else None
                    if not isinstance(inner, exp.Select):
                        continue
                    joins_list = inner.args.get("joins") or []
                    for join_node in joins_list:
                        join_info = self._extract_join(join_node, inner)
                        key = (join_info.join_type, join_info.left_table or "",
                               join_info.right_table or "", join_info.predicate_sql or "")
                        raw_results.append((key, join_info, col_alias))

        # Deduplicate joins but collect all associated column aliases
        seen = {}  # key -> (JoinInfo, set of col_aliases)
        for key, join_info, col_alias in raw_results:
            if key not in seen:
                seen[key] = (join_info, set())
            if col_alias:
                seen[key][1].add(col_alias)

        return [(ji, sorted(aliases)) for ji, aliases in seen.values()]

    def get_all_join_columns(self, joins: List[JoinInfo]) -> List[ColumnRef]:
        """
        Get all columns involved in JOINs.

        Args:
            joins: List of JoinInfo objects

        Returns:
            List of all unique ColumnRef objects
        """
        columns = []
        for join in joins:
            columns.extend(join.get_all_columns())
        return list(set(columns))
