"""
Subquery Decomposer module.

Recursively walks FROM-clause subqueries in a SQL AST to produce
per-level column mapping rows. Handles:
- Nested derived tables (FROM (SELECT ...) alias)
- UNION/UNION ALL branch disambiguation (AF1_1, AF1_2, ...)
- Per-level WHERE filters and JOIN conditions
- Hop counting and subquery relation chain building
"""

import sqlglot
from sqlglot import exp
from typing import List, Dict, Optional, Tuple, Set
import re
import sys
import os

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from models.data_models import ColumnMappingRecord, JoinConditionDetail, FilterConditionDetail, ColumnRef


class SubqueryLevel:
    """Represents one level in a subquery decomposition."""
    def __init__(self, alias: str, ast: exp.Expression, depth: int,
                 parent_alias: str = "", union_branch_idx: int = 0,
                 union_type: str = ""):
        self.alias = alias
        self.ast = ast
        self.depth = depth
        self.parent_alias = parent_alias
        self.union_branch_idx = union_branch_idx
        self.union_type = union_type
        self.columns: List[Tuple[str, str, str]] = []  # (col_name, source_expr, source_table)
        self.source_tables: List[str] = []
        self.joins: List[Dict] = []
        self.where_filter: str = ""
        self.qualify_filter: str = ""
        self.group_by: str = ""
        self.children: List['SubqueryLevel'] = []


class SubqueryDecomposer:
    """
    Recursively decomposes nested subqueries in a SQL AST.

    For a query like:
        INSERT INTO target
        SELECT AF2.col1, MAXIMUM(AF2.col2)
        FROM (
            SELECT AF1.col1, AF1.col2
            FROM (
                SELECT AF.col1, B.col2
                FROM (SELECT * FROM base_table) AF
                INNER JOIN lookup B ON AF.key = B.key
            ) AF1
            WHERE AF1.filter = 'X'
            UNION
            SELECT AF1.col1, AF1.col2
            FROM (...) AF1
            WHERE AF1.filter = 'Y'
        ) AF2
        GROUP BY AF2.col1

    Produces rows at each level:
    - Level 0 (outermost): AF2 -> target
    - Level 1 (UNION branches): AF1_1 -> AF2, AF1_2 -> AF2
    - Level 2 (innermost): base_table -> AF_1, lookup -> AF_1, etc.
    """

    def __init__(self, dialect: str = "teradata"):
        self.dialect = dialect
        self._u_counter = 0  # Global counter for UNION branch U aliases (U1, U2, ...)

    def decompose(self, ast: exp.Expression, target_table: str,
                  dml_sequence: int = None, operator_type: str = "INSERT",
                  existing_join_ids: List[str] = None,
                  existing_filter_ids: List[str] = None) -> List[ColumnMappingRecord]:
        """
        Decompose subqueries in the given AST into per-level mapping rows.

        Args:
            ast: Parsed SQL AST (typically an INSERT...SELECT or SELECT)
            target_table: The final target table name
            dml_sequence: DML sequence number from the parent
            operator_type: DML operation type
            existing_join_ids: Join IDs already assigned to this statement
            existing_filter_ids: Filter IDs already assigned to this statement

        Returns:
            List of ColumnMappingRecord for intermediate subquery levels
        """
        # Find the SELECT part of the statement
        select_ast = self._find_select(ast)
        if not select_ast:
            return []

        # Build the subquery tree
        root = self._build_subquery_tree(select_ast, target_table, depth=0)
        if not root or not root.children:
            return []

        # Generate mapping rows from the tree
        rows = self._generate_rows(root, target_table, dml_sequence, operator_type)
        return rows

    def _find_select(self, ast: exp.Expression) -> Optional[exp.Select]:
        """Find the main SELECT from an INSERT...SELECT or standalone SELECT."""
        if isinstance(ast, exp.Insert):
            # The INSERT stores the SELECT in .expression
            expr = ast.expression
            if isinstance(expr, exp.Select):
                return expr
            # Fallback: find nested
            return ast.find(exp.Select)
        elif isinstance(ast, exp.Select):
            return ast
        # Try to find any SELECT in children
        for child in ast.walk():
            if isinstance(child, exp.Select):
                return child
        return None

    def _get_from_subqueries(self, select: exp.Select) -> List[exp.Subquery]:
        """Get direct subqueries from the FROM clause of a SELECT."""
        subqueries = []
        # sqlglot stores FROM as 'from_' in some versions, or accessible via find(From)
        from_node = select.find(exp.From)
        if not from_node:
            return subqueries

        # From.this is the primary table/subquery
        if isinstance(from_node.this, exp.Subquery):
            subqueries.append(from_node.this)

        # From.expressions has additional tables (comma-joins)
        for expr in from_node.expressions:
            if isinstance(expr, exp.Subquery):
                subqueries.append(expr)

        return subqueries

    def _get_join_subqueries(self, select: exp.Select) -> List[exp.Subquery]:
        """Get subqueries from JOIN clauses (direct children only, not nested)."""
        subqueries = []
        for join_node in select.args.get("joins") or []:
            join_this = join_node.this
            if isinstance(join_this, exp.Subquery):
                subqueries.append(join_this)
        return subqueries

    def _build_subquery_tree(self, select: exp.Select, alias: str,
                             depth: int, parent_alias: str = "",
                             union_branch_idx: int = 0,
                             union_type: str = "",
                             branch_suffix: int = 0) -> Optional[SubqueryLevel]:
        """
        Recursively build a tree of SubqueryLevel objects.

        Walks FROM clause to find derived tables (subqueries), and
        handles UNION/UNION ALL by splitting into numbered branches.

        Args:
            branch_suffix: If > 0, we are inside UNION branch N.
                All child subquery aliases get suffixed with _N for disambiguation.
        """
        if not isinstance(select, exp.Select):
            return None

        level = SubqueryLevel(
            alias=alias,
            ast=select,
            depth=depth,
            parent_alias=parent_alias,
            union_branch_idx=union_branch_idx,
            union_type=union_type
        )

        # Extract columns selected at this level
        level.columns = self._extract_select_columns(select)

        # Extract source tables (non-subquery FROM sources)
        level.source_tables = self._extract_source_tables(select)

        # Extract WHERE filter (only direct, not from subqueries)
        where = select.args.get("where")
        if where:
            try:
                level.where_filter = where.this.sql(dialect=self.dialect)
            except Exception:
                level.where_filter = str(where.this) if where.this else ""

        # Extract GROUP BY
        group = select.args.get("group")
        if group:
            try:
                level.group_by = group.sql(dialect=self.dialect)
            except Exception:
                level.group_by = ""

        # Extract JOINs at this level
        level.joins = self._extract_joins(select)

        # Process FROM-clause subqueries
        for subq in self._get_from_subqueries(select):
            self._process_subquery_child(subq, level, alias, depth,
                                          branch_suffix=branch_suffix)

        # Process JOIN-clause subqueries
        for subq in self._get_join_subqueries(select):
            self._process_subquery_child(subq, level, alias, depth,
                                          branch_suffix=branch_suffix)

        return level

    def _process_subquery_child(self, subq: exp.Subquery, level: SubqueryLevel,
                                 parent_alias: str, parent_depth: int,
                                 branch_suffix: int = 0):
        """Process a single subquery found in FROM or JOIN, handling UNIONs.

        Args:
            branch_suffix: If > 0, we are inside UNION branch N.
                Child subquery aliases get suffixed with _N.
        """
        sub_alias = self._get_subquery_alias(subq)
        inner = subq.this  # The expression inside the Subquery wrapper

        if isinstance(inner, exp.Union):
            # UNION/UNION ALL - collect all branches
            branches = []
            self._collect_union_branches(inner, branches)
            if len(branches) > 1:
                # Create an intermediate level for the outer subquery alias (e.g., AF2)
                # This preserves the alias chain: target -> AF2 -> U1, U2...
                intermediate = SubqueryLevel(
                    alias=sub_alias, ast=branches[0][0],
                    depth=parent_depth + 1, parent_alias=parent_alias
                )
                # Set columns with empty source_table so _walk_tree uses child.alias
                first_cols = self._extract_select_columns(branches[0][0])
                intermediate.columns = [(name, expr, "") for name, expr, _ in first_cols]
                intermediate.source_tables = []

                for branch_idx, (branch_select, u_type) in enumerate(branches, 1):
                    # Create a U_N level for EVERY UNION branch SELECT block.
                    # Uses global counter so U aliases are unique across all UNIONs.
                    self._u_counter += 1
                    u_alias = "U{0}".format(self._u_counter)

                    u_level = SubqueryLevel(
                        alias=u_alias, ast=branch_select,
                        depth=parent_depth + 2, parent_alias=sub_alias,
                        union_branch_idx=branch_idx, union_type=u_type
                    )
                    # Extract columns from the branch SELECT
                    u_level.columns = self._extract_select_columns(branch_select)
                    # Extract branch-level source tables (non-subquery, e.g. CROSS JOIN tables)
                    u_level.source_tables = self._extract_source_tables(branch_select)
                    # Extract branch-level JOINs (CROSS JOIN, etc.)
                    u_level.joins = self._extract_joins(branch_select)
                    # Extract branch-level WHERE filter
                    branch_where = branch_select.args.get("where")
                    if branch_where and branch_where.this:
                        try:
                            u_level.where_filter = branch_where.this.sql(dialect=self.dialect)
                        except Exception:
                            u_level.where_filter = str(branch_where.this) if branch_where.this else ""

                    # Build inner FROM subquery as a child of U_N (if present)
                    inner_from_subqs = self._get_from_subqueries(branch_select)
                    if inner_from_subqs:
                        from_alias = self._get_subquery_alias(inner_from_subqs[0])
                        inner_alias = "{0}_{1}".format(from_alias, branch_idx) if from_alias else "{0}_{1}".format(sub_alias, branch_idx)

                        inner_select = inner_from_subqs[0].this
                        if isinstance(inner_select, (exp.Select, exp.Union)):
                            child = self._build_subquery_tree(
                                inner_select, inner_alias, parent_depth + 3,
                                parent_alias=u_alias,
                                union_branch_idx=branch_idx,
                                union_type=u_type,
                                branch_suffix=branch_idx
                            )
                            if child:
                                u_level.children.append(child)

                    # Also process JOIN subqueries within the branch SELECT
                    for join_subq in self._get_join_subqueries(branch_select):
                        self._process_subquery_child(
                            join_subq, u_level, u_alias, parent_depth + 2,
                            branch_suffix=branch_idx
                        )

                    # For simple branches (no inner FROM subquery),
                    # U_N is a leaf — its source_tables are the physical tables.
                    # _walk_tree will emit leaf-level rows: physical_table -> U_N
                    intermediate.children.append(u_level)

                level.children.append(intermediate)

            elif branches:
                child = self._build_subquery_tree(
                    branches[0][0], sub_alias, parent_depth + 1,
                    parent_alias=parent_alias,
                    branch_suffix=branch_suffix
                )
                if child:
                    level.children.append(child)

        elif isinstance(inner, exp.Select):
            # Apply branch suffix for disambiguation of duplicate aliases
            actual_alias = sub_alias
            if branch_suffix > 0 and sub_alias:
                actual_alias = f"{sub_alias}_{branch_suffix}"

            child = self._build_subquery_tree(
                inner, actual_alias, parent_depth + 1,
                parent_alias=parent_alias,
                branch_suffix=branch_suffix
            )
            if child:
                level.children.append(child)

        elif isinstance(inner, exp.Subquery):
            # Nested Subquery wrapper — happens with parenthesized JOINs:
            # FROM ((UNION...) E INNER JOIN (subq) FGE ON ...)
            # sqlglot parses this as: Subquery(no alias) -> Subquery(E, joins=[FGE])
            # Unwrap the inner subquery and process it + its JOINs.
            self._process_subquery_child(inner, level, parent_alias,
                                          parent_depth, branch_suffix=branch_suffix)
            # Process any JOINs attached to the inner Subquery
            inner_joins = inner.args.get("joins") or []
            for join_node in inner_joins:
                join_this = join_node.this
                if isinstance(join_this, exp.Subquery):
                    self._process_subquery_child(
                        join_this, level, parent_alias, parent_depth,
                        branch_suffix=branch_suffix
                    )

    def _collect_union_branches(self, node: exp.Expression, branches: List,
                                _root_union_type: str = ""):
        """Recursively collect all branches of a UNION into a flat list.

        The first branch also receives the UNION type so that all branches
        (including the first) carry the union indicator in the output.
        """
        if isinstance(node, exp.Union):
            union_type = "UNION ALL" if node.args.get("distinct") is False else "UNION"
            # Pass union_type down so the leftmost leaf gets it
            self._collect_union_branches(node.this, branches,
                                          _root_union_type=_root_union_type or union_type)
            # Right side
            right = node.expression
            if isinstance(right, exp.Union):
                self._collect_union_branches(right, branches,
                                              _root_union_type=union_type)
            elif isinstance(right, exp.Select):
                branches.append((right, union_type))
        elif isinstance(node, exp.Select):
            # First branch: use the union type from the parent UNION node
            branches.append((node, _root_union_type))

    def _extract_select_columns(self, select: exp.Select) -> List[Tuple[str, str, str]]:
        """
        Extract columns from SELECT clause.

        Returns list of (output_name, source_expression, source_table).
        """
        columns = []
        if not isinstance(select, exp.Select):
            return columns

        for expr in select.expressions:
            output_name = ""
            source_expr = ""
            source_table = ""

            # Get the alias (output name)
            if isinstance(expr, exp.Alias):
                output_name = expr.alias
                inner = expr.this
            else:
                inner = expr
                # Use the column name as output name
                if isinstance(inner, exp.Column):
                    output_name = inner.name
                elif isinstance(inner, exp.Star):
                    output_name = "*"

            # Get source expression
            try:
                source_expr = inner.sql(dialect=self.dialect)
            except Exception:
                source_expr = str(inner) if inner else ""

            # Get source table
            if isinstance(inner, exp.Column):
                tbl = inner.table
                if tbl:
                    source_table = tbl
                # Also check for schema-qualified column
                col_parts = []
                if hasattr(inner, 'args'):
                    table_node = inner.args.get('table')
                    if table_node:
                        source_table = table_node.name if hasattr(table_node, 'name') else str(table_node)
            elif isinstance(inner, exp.Star):
                source_table = "*"

            if not output_name:
                output_name = source_expr

            columns.append((output_name, source_expr, source_table))

        return columns

    def _extract_source_tables(self, select: exp.Select) -> List[str]:
        """Extract non-subquery source table names from FROM and JOIN."""
        tables = []
        if not isinstance(select, exp.Select):
            return tables

        from_node = select.find(exp.From)
        if from_node:
            # Direct table in FROM (not inside a subquery)
            if isinstance(from_node.this, exp.Table):
                name = self._get_table_name(from_node.this)
                if name:
                    tables.append(name)
            # Additional tables in FROM (comma-joins)
            for expr in from_node.expressions:
                if isinstance(expr, exp.Table):
                    name = self._get_table_name(expr)
                    if name:
                        tables.append(name)

        # Also get tables from JOINs (non-subquery, direct children only)
        for join_node in select.args.get("joins") or []:
            join_this = join_node.this
            if isinstance(join_this, exp.Table):
                name = self._get_table_name(join_this)
                if name:
                    tables.append(name)

        return tables

    def _extract_joins(self, select: exp.Select) -> List[Dict]:
        """Extract JOIN info at this level only (direct children, not nested)."""
        joins = []
        for join_node in select.args.get("joins") or []:
            join_type = "INNER"
            kind = join_node.args.get("kind") or ""
            side = join_node.args.get("side") or ""
            if side:
                join_type = str(side).upper()
            if kind:
                join_type = str(kind).upper()
            if not side and not kind:
                if join_node.args.get("natural"):
                    join_type = "NATURAL"

            # Get joined table/subquery name
            right_table = ""
            right_alias = ""
            join_this = join_node.this
            if isinstance(join_this, exp.Table):
                right_table = self._get_table_name(join_this)
                right_alias = join_this.alias or ""
            elif isinstance(join_this, exp.Subquery):
                right_alias = self._get_subquery_alias(join_this)
                right_table = f"(subquery) {right_alias}"

            # Get ON condition
            on_cond = join_node.args.get("on")
            on_sql = ""
            if on_cond:
                try:
                    on_sql = on_cond.sql(dialect=self.dialect)
                except Exception:
                    on_sql = str(on_cond)

            joins.append({
                "join_type": join_type,
                "right_table": right_table,
                "right_alias": right_alias,
                "on_condition": on_sql
            })

        return joins

    def _get_subquery_alias(self, subquery: exp.Subquery) -> str:
        """Get the alias of a subquery."""
        if hasattr(subquery, 'alias') and subquery.alias:
            return subquery.alias
        # Try to find TableAlias
        alias_node = subquery.args.get("alias")
        if alias_node:
            if hasattr(alias_node, 'this'):
                return str(alias_node.this)
            return str(alias_node)
        return ""

    def _get_table_name(self, table: exp.Table) -> str:
        """Get fully qualified table name."""
        parts = []
        if table.catalog:
            parts.append(table.catalog)
        if table.db:
            parts.append(table.db)
        if table.name:
            parts.append(table.name)
        return ".".join(parts) if parts else ""

    def _generate_rows(self, root: SubqueryLevel, target_table: str,
                       dml_sequence: int = None,
                       operator_type: str = "INSERT") -> List[ColumnMappingRecord]:
        """
        Generate ColumnMappingRecord rows from the subquery tree.

        Walks the tree depth-first, emitting rows for each child level
        that show how columns flow from source to the alias at that level.
        """
        rows = []
        self._walk_tree(root, target_table, dml_sequence, operator_type, rows, [])
        return rows

    def _walk_tree(self, level: SubqueryLevel, final_target: str,
                   dml_sequence: int, operator_type: str,
                   rows: List[ColumnMappingRecord],
                   ancestor_chain: List[str]):
        """
        Recursively walk the subquery tree and emit rows.

        ancestor_chain tracks the path from root to current level's parent,
        e.g. ["AF2_1", "AF1"] means we are inside AF1 which is inside AF2_1.
        """
        for child in level.children:
            # The target for this child's rows is the parent (level)
            row_target = level.alias if level.depth > 0 else final_target

            # Hop count = depth of this child (how many subquery levels from target)
            hops = child.depth

            # Build hop detail: child -> parent -> ... -> final_target
            # ancestor_chain has path from root down to level
            # We want: child.alias -> level.alias -> ... -> final_target
            chain_to_target = [child.alias]
            if level.depth > 0:
                chain_to_target.append(level.alias)
            # Add ancestors back up to root
            for a in reversed(ancestor_chain):
                if a not in chain_to_target:
                    chain_to_target.append(a)
            chain_to_target.append(final_target)
            # Deduplicate while preserving order
            seen = set()
            deduped = []
            for item in chain_to_target:
                if item not in seen:
                    seen.add(item)
                    deduped.append(item)
            hop_detail = " -> ".join(deduped)

            # Source subquery relation: what this child feeds from
            source_subquery_relation = child.alias

            # Target subquery relation: what this child feeds into
            target_subquery_relation = row_target

            # Union condition note
            union_note = ""
            if child.union_branch_idx > 0 and child.union_type:
                base_alias = child.alias.rsplit("_", 1)[0] if "_" in child.alias else child.alias
                union_note = f"{child.union_type} branch {child.union_branch_idx} of {base_alias}"

            # WHERE filter and JOIN info only belong on THIS level's rows when
            # the child is a leaf (no deeper subqueries). If the child has children,
            # those WHERE/JOINs will be emitted at the correct deeper level via
            # leaf rows, preventing the filter from leaking to parent levels.
            is_leaf = not child.children
            where_text = "" if is_leaf else (child.where_filter or "")
            join_notes = ""
            if not is_leaf and child.joins:
                join_parts = [f"{j['join_type']} JOIN {j['right_table']} ON {j['on_condition']}" for j in child.joins]
                join_notes = "; ".join(join_parts)

            # Build notes
            notes_parts = []
            if union_note:
                notes_parts.append(union_note)
            if where_text:
                notes_parts.append(f"WHERE: {where_text}")
            if join_notes:
                notes_parts.append(f"JOIN: {join_notes}")
            if child.group_by:
                notes_parts.append(f"GROUP BY: {child.group_by}")
            notes = "; ".join(notes_parts)

            # Emit rows for each column at this child level
            # Use child.alias as source (preserving subquery alias chain)
            #
            # SELECT * resolution: when a child's SELECT list is just "*",
            # resolve it using the parent level's columns that reference the
            # child's original alias.  E.g. AF_1 has SELECT *, but parent
            # AF1_1 selects AF.AGMT_ID, AF.FEATURE_ID, … — propagate those
            # columns so the STTM shows individual column-level mappings
            # instead of a single "*" row.
            effective_columns = child.columns
            if (len(child.columns) == 1 and child.columns[0][0] == "*"
                    and level.columns):
                # Derive the child's original alias (before _N suffix)
                base_alias = child.alias.rsplit("_", 1)[0] if "_" in child.alias else child.alias
                parent_cols_for_child = [
                    (col_name, src_expr, base_alias)
                    for col_name, src_expr, src_tbl in level.columns
                    if src_tbl.upper() == base_alias.upper()
                ]
                if parent_cols_for_child:
                    effective_columns = parent_cols_for_child

            emitted_any = False
            for col_name, source_expr, source_table in effective_columns:
                emitted_any = True
                row = ColumnMappingRecord(
                    source_table=child.alias,
                    source_column=col_name,
                    target_table=row_target,
                    target_column=col_name,
                    transformation_type="DIRECT" if "." in source_expr else "INDIRECT",
                    transformation_subtype="IDENTITY" if "." in source_expr else "TRANSFORMATION",
                    transformation_sql=source_expr,
                    english_explanation=f"Column {col_name} flows from {child.alias} to {row_target}",
                    source_columns_involved=[source_expr] if source_expr else [],
                    dml_sequence=dml_sequence,
                    operator_type=operator_type,
                    join_ids=[],
                    filter_ids=[],
                    source_alias=child.alias,
                    target_alias=level.alias if level.depth > 0 else "",
                    subquery_alias=child.alias,
                    union_type=child.union_type,
                    group_by=child.group_by,
                    hops=hops,
                    hop_detail=hop_detail,
                    source_subquery_relation=source_subquery_relation,
                    target_subquery_relation=target_subquery_relation,
                    notes=notes,
                    is_subquery_decomposition=True,
                )
                rows.append(row)

            # For leaf levels (no children): emit rows showing actual source tables -> child alias
            # This produces the deepest level mapping: e.g., AGREEMENT_FEATURE -> AF_1
            if not child.children:
                leaf_target = child.alias
                leaf_hops = hops + 1
                leaf_hop_detail = hop_detail  # Already includes the chain

                # Use the resolved effective_columns here too, so that
                # SELECT * leaves get individual column rows.
                leaf_columns = effective_columns
                for col_name, source_expr, source_table in leaf_columns:
                    src_table = source_table if source_table and source_table != "*" else ""
                    # When columns were resolved from the parent (SELECT *),
                    # source_table is the alias (e.g. "AF") not a physical
                    # table.  For leaf rows we need the actual physical table
                    # from child.source_tables.
                    if src_table and "." not in src_table and child.source_tables:
                        # It's an alias — resolve to the physical table
                        src_table = child.source_tables[0] if len(child.source_tables) == 1 else src_table
                    if not src_table and child.source_tables:
                        src_table = child.source_tables[0] if len(child.source_tables) == 1 else ""
                    if not src_table:
                        src_table = child.source_tables[0] if child.source_tables else ""
                    if not src_table or src_table == child.alias:
                        continue

                    leaf_notes_parts = []
                    if child.where_filter:
                        leaf_notes_parts.append(f"WHERE: {child.where_filter}")
                    if child.joins:
                        join_parts = [f"{j['join_type']} JOIN {j['right_table']} ON {j['on_condition']}" for j in child.joins]
                        leaf_notes_parts.append(f"JOIN: {'; '.join(join_parts)}")
                    leaf_notes = "; ".join(leaf_notes_parts)

                    leaf_row = ColumnMappingRecord(
                        source_table=src_table,
                        source_column=col_name if col_name != "*" else col_name,
                        target_table=leaf_target,
                        target_column=col_name if col_name != "*" else col_name,
                        transformation_type="DIRECT",
                        transformation_subtype="IDENTITY",
                        transformation_sql=source_expr,
                        english_explanation=f"Column {col_name} flows from {src_table} to {leaf_target}",
                        source_columns_involved=[source_expr] if source_expr else [],
                        dml_sequence=dml_sequence,
                        operator_type=operator_type,
                        join_ids=[],
                        filter_ids=[],
                        source_alias="",
                        target_alias=child.alias,
                        subquery_alias=child.alias,
                        union_type="",
                        group_by="",
                        hops=leaf_hops,
                        hop_detail=leaf_hop_detail,
                        source_subquery_relation=src_table,
                        target_subquery_relation=leaf_target,
                        notes=leaf_notes,
                        is_subquery_decomposition=True,
                    )
                    rows.append(leaf_row)

            # Emit additional rows for columns sourced from non-subquery JOIN
            # tables at this child level.  E.g. when child = AF1_1 has
            # SELECT AF.col1, B.CD_DESC, B.CD_TYPE FROM (subq) AF JOIN B,
            # the subquery child AF_1 only resolves AF columns.  B columns
            # need explicit leaf rows: physical_join_table -> child.alias.
            if child.joins and child.columns:
                # Build alias -> physical table map from JOINs
                join_alias_to_table = {}
                for j in child.joins:
                    j_alias = j.get('right_alias', '') or ''
                    if not j_alias:
                        # Use short table name as alias
                        j_alias = j['right_table'].split('.')[-1] if '.' in j['right_table'] else j['right_table']
                    join_alias_to_table[j_alias.upper()] = j['right_table']

                # Find columns in child.columns that come from JOIN tables
                for col_name, source_expr, source_table in child.columns:
                    if source_table and source_table.upper() in join_alias_to_table:
                        physical_table = join_alias_to_table[source_table.upper()]
                        # Don't duplicate if already emitted
                        join_leaf_hops = hops + 1
                        join_leaf_notes = ""
                        if child.joins:
                            jparts = [f"{jj['join_type']} JOIN {jj['right_table']} ON {jj['on_condition']}" for jj in child.joins]
                            join_leaf_notes = f"JOIN: {'; '.join(jparts)}"

                        join_leaf_row = ColumnMappingRecord(
                            source_table=physical_table,
                            source_column=col_name,
                            target_table=child.alias,
                            target_column=col_name,
                            transformation_type="DIRECT",
                            transformation_subtype="IDENTITY",
                            transformation_sql=source_expr,
                            english_explanation=f"Column {col_name} flows from {physical_table} (JOIN) to {child.alias}",
                            source_columns_involved=[source_expr] if source_expr else [],
                            dml_sequence=dml_sequence,
                            operator_type=operator_type,
                            join_ids=[],
                            filter_ids=[],
                            source_alias="",
                            target_alias=child.alias,
                            subquery_alias=child.alias,
                            union_type="",
                            group_by="",
                            hops=join_leaf_hops,
                            hop_detail=hop_detail,
                            source_subquery_relation=physical_table,
                            target_subquery_relation=child.alias,
                            notes=join_leaf_notes,
                            is_subquery_decomposition=True,
                        )
                        rows.append(join_leaf_row)

            # Recurse into grandchildren
            new_chain = ancestor_chain + [level.alias] if level.depth > 0 else ancestor_chain
            self._walk_tree(child, final_target, dml_sequence, operator_type, rows, new_chain)

    def decompose_from_raw_sql(self, raw_sql: str, target_table: str,
                                dml_sequence: int = None,
                                operator_type: str = "INSERT") -> List[ColumnMappingRecord]:
        """
        Parse raw SQL and decompose subqueries.

        Convenience method that parses the SQL first, then decomposes.

        Args:
            raw_sql: Raw SQL string
            target_table: Final target table name
            dml_sequence: DML sequence number
            operator_type: DML operation type

        Returns:
            List of ColumnMappingRecord for intermediate levels
        """
        # Clean SQL for parsing
        cleaned = self._clean_sql_for_parsing(raw_sql)

        try:
            parsed = sqlglot.parse(cleaned, read=self.dialect)
            if parsed:
                ast = parsed[0]
                return self.decompose(ast, target_table, dml_sequence, operator_type)
        except Exception as e:
            print(f"  WARNING SubqueryDecomposer: Failed to parse SQL: {e}")

        return []

    def _clean_sql_for_parsing(self, sql: str) -> str:
        """Clean Teradata SQL for sqlglot parsing."""
        # Fix Teradata export embedded quotes (line breaks within identifiers)
        # Pattern: "...\n"... where quotes split an identifier across lines
        sql = re.sub(r'"\s*\n\s*"', '', sql)
        # Remove remaining standalone double-quotes that aren't part of identifiers
        sql = re.sub(r'(?<![A-Za-z0-9_])"(?![A-Za-z0-9_])', '', sql)
        # Remove comments
        sql = re.sub(r'---[^\n]*', '', sql)  # Triple-dash first
        sql = re.sub(r'--[^\n]*', '', sql)
        sql = re.sub(r'/\*.*?\*/', '', sql, flags=re.DOTALL)
        # Remove Teradata-specific keywords that confuse parser
        sql = re.sub(r'\bCOLLECT\s+STATISTICS\b.*?;', '', sql, flags=re.IGNORECASE | re.DOTALL)
        sql = re.sub(r'\bBT\s*;', '', sql, flags=re.IGNORECASE)
        sql = re.sub(r'\bET\s*;', '', sql, flags=re.IGNORECASE)
        # Replace MAXIMUM with MAX for standard SQL
        sql = re.sub(r'\bMAXIMUM\s*\(', 'MAX(', sql, flags=re.IGNORECASE)
        return sql.strip()
