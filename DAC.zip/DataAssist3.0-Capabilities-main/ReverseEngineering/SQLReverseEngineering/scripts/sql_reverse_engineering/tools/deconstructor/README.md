# Deconstructor Module

## Overview

The Deconstructor module extracts and analyzes detailed SQL elements from parsed Abstract Syntax Trees (ASTs). It systematically breaks down complex SQL queries into individual, analyzable components including columns, joins, functions, subqueries, CTEs, CASE statements, and predicates. This module is essential for data lineage analysis, query optimization, and SQL documentation generation.

## Purpose

The Deconstructor transforms monolithic SQL ASTs into structured, queryable metadata that can be used for:
- **Data Lineage Tracking**: Identify column-level transformations and data flow
- **Impact Analysis**: Understand dependencies between tables, columns, and queries
- **Query Documentation**: Generate comprehensive documentation of SQL logic
- **Code Review**: Analyze query complexity and identify optimization opportunities
- **Migration Planning**: Extract metadata for cross-platform SQL migrations

## Architecture

The module uses a coordinated extraction pattern with specialized extractors:

```
SQLElementExtractor (Orchestrator)
    ├── CaseExtractor (CASE statements)
    ├── JoinExtractor (JOIN conditions)
    ├── FunctionExtractor (Function calls)
    └── SubqueryCTEExtractor (Subqueries & CTEs)
```

Each extractor focuses on a specific SQL construct, ensuring clean separation of concerns and maintainability.

## Components

### 1. SQLElementExtractor (`element_extractor.py`)

**Main orchestrator** that coordinates all individual extractors and builds the complete ElementCatalog.

#### Key Features:
- Traverse AST and extract all SQL elements systematically
- Coordinate specialized extractors for different SQL constructs
- Build comprehensive ElementCatalog with all query metadata
- Handle nested structures and complex query patterns
- Extract WHERE clause conditions with detailed operators
- Parse GROUP BY and ORDER BY clauses
- Identify source and target tables for all statement types

#### Responsibilities:
- Statement type detection (SELECT, INSERT, UPDATE, DELETE, etc.)
- Table extraction (source and target)
- WHERE clause parsing with condition decomposition
- GROUP BY and ORDER BY extraction
- Column reference tracking across all clauses

### 2. CaseExtractor (`case_extractor.py`)

Extracts **CASE expressions** with complete branch details, preserving all business logic without abstraction.

#### Key Features:
- Parse CASE WHEN/THEN/ELSE structures completely
- Extract all branches with conditions and results
- Handle nested CASE statements recursively
- Track ELSE clauses and default values
- Identify columns used in conditions and results
- Generate human-readable business logic descriptions

#### Capabilities:
- Simple CASE expressions
- Searched CASE expressions (with predicates)
- Nested CASE within CASE
- CASE in SELECT, WHERE, and ORDER BY clauses
- Output alias tracking

### 3. JoinExtractor (`join_extractor.py`)

Extracts **JOIN operations** with complete predicate details including join type, tables involved, and all ON conditions.

#### Key Features:
- Identify all join types: INNER, LEFT, RIGHT, FULL, CROSS
- Extract join conditions with complete predicate analysis
- Track table relationships and aliases
- Handle multi-table joins with complex conditions
- Support OR conditions in JOIN predicates
- Parse inequality joins (>, <, >=, <=, <>)

#### Supported Join Types:
- INNER JOIN
- LEFT OUTER JOIN
- RIGHT OUTER JOIN  
- FULL OUTER JOIN
- CROSS JOIN
- Implicit joins (comma-separated tables)

### 4. FunctionExtractor (`function_extractor.py`)

Extracts **function calls** with complete parameter details including nested functions, aggregate functions, and window functions.

#### Key Features:
- Identify all function types (built-in, aggregate, window, UDF)
- Extract function arguments with positional tracking
- Track function nesting and composition
- Support window functions with PARTITION BY and ORDER BY
- Classify aggregate vs scalar functions automatically
- Detect literal vs column parameters

#### Function Categories:
- **Aggregate Functions**: SUM, COUNT, AVG, MIN, MAX, STDDEV, etc.
- **Window Functions**: ROW_NUMBER, RANK, LEAD, LAG, FIRST_VALUE, etc.
- **String Functions**: CONCAT, SUBSTRING, TRIM, UPPER, LOWER, etc.
- **Date Functions**: CURRENT_DATE, DATEADD, DATEDIFF, etc.
- **Math Functions**: ROUND, FLOOR, CEIL, ABS, etc.
- **User-Defined Functions**: Custom functions from any schema

### 5. SubqueryCTEExtractor (`subquery_cte_extractor.py`)

Extracts **subqueries and CTEs** (Common Table Expressions) with recursive expansion and complete dependency tracking.

#### Key Features:
- Parse WITH clause CTE definitions
- Extract subqueries from all contexts (SELECT, WHERE, FROM, HAVING)
- Handle recursive CTEs with self-reference detection
- Track CTE dependencies and reference chains
- Identify correlated vs uncorrelated subqueries
- Extract output columns and source tables for each subquery/CTE

#### Subquery Contexts:
- Scalar subqueries (in SELECT or WHERE)
- Table subqueries (in FROM clause)
- EXISTS subqueries
- IN/NOT IN subqueries
- Subqueries in HAVING clause

#### CTE Features:
- Simple CTEs
- Recursive CTEs
- CTE dependency chains
- CTE column aliasing

## Installation

This module requires the AST Generator module and depends on:

```bash
pip install sqlglot
```

## Usage

### Basic Element Extraction

```python
from tools.ast_generator import SQLASTGenerator
from tools.deconstructor import SQLElementExtractor

# Parse SQL first
parser = SQLASTGenerator(dialect="teradata")
ast = parser.parse("""
    SELECT 
        c.customer_id,
        c.customer_name,
        CASE 
            WHEN o.total_amount > 1000 THEN 'VIP'
            WHEN o.total_amount > 500 THEN 'Regular'
            ELSE 'Basic'
        END as customer_tier,
        SUM(o.total_amount) as lifetime_value
    FROM customers c
    INNER JOIN orders o ON c.customer_id = o.customer_id
    WHERE c.status = 'ACTIVE'
    GROUP BY c.customer_id, c.customer_name, customer_tier
""")

# Extract all elements
extractor = SQLElementExtractor(ast, dialect="teradata")
catalog = extractor.extract_all()

# Access extracted elements
print(f"Statement Type: {catalog.statement_type}")
print(f"Source Tables: {catalog.source_tables}")
print(f"Number of JOINs: {len(catalog.joins)}")
print(f"Number of Functions: {len(catalog.functions)}")
print(f"Number of CASE statements: {len(catalog.case_statements)}")
```

### Extracting CASE Statements

```python
from tools.deconstructor import CaseExtractor

case_extractor = CaseExtractor(dialect="teradata")

sql = """
    SELECT 
        CASE 
            WHEN age < 18 THEN 'Minor'
            WHEN age BETWEEN 18 AND 65 THEN 'Adult'
            ELSE 'Senior'
        END as age_group
    FROM users
"""

ast = parser.parse(sql)
case_statements = case_extractor.extract(ast)

for case_stmt in case_statements:
    print(f"CASE Statement: {case_stmt.sql_text}")
    print(f"Output Alias: {case_stmt.output_alias}")
    
    for i, branch in enumerate(case_stmt.branches, 1):
        print(f"  Branch {i}:")
        print(f"    Condition: {branch.condition}")
        print(f"    Result: {branch.result}")
        print(f"    Columns in condition: {branch.condition_columns}")
    
    if case_stmt.else_result:
        print(f"  ELSE: {case_stmt.else_result}")

# Generate business logic description
description = case_extractor.to_business_logic_description(case_statements[0])
print(f"\nBusiness Logic:\n{description}")
```

### Extracting JOIN Information

```python
from tools.deconstructor import JoinExtractor

join_extractor = JoinExtractor(dialect="teradata")

sql = """
    SELECT *
    FROM customers c
    INNER JOIN orders o ON c.customer_id = o.customer_id
    LEFT JOIN order_items oi ON o.order_id = oi.order_id AND oi.quantity > 0
    WHERE c.region = 'US'
"""

ast = parser.parse(sql)
joins = join_extractor.extract(ast)

for join in joins:
    print(f"Join Type: {join.join_type}")
    print(f"Left Table: {join.left_table} (alias: {join.left_alias})")
    print(f"Right Table: {join.right_table} (alias: {join.right_alias})")
    print(f"Join Predicate: {join.predicate_sql}")
    
    for condition in join.conditions:
        if condition.left_column and condition.right_column:
            print(f"  {condition.left_column.column_name} {condition.operator} {condition.right_column.column_name}")
        elif condition.left_column and condition.right_literal:
            print(f"  {condition.left_column.column_name} {condition.operator} {condition.right_literal}")
```

### Extracting Functions

```python
from tools.deconstructor import FunctionExtractor

func_extractor = FunctionExtractor(dialect="teradata")

sql = """
    SELECT 
        customer_id,
        UPPER(customer_name) as name,
        SUM(total_amount) as total,
        AVG(COALESCE(discount, 0)) as avg_discount,
        ROW_NUMBER() OVER (PARTITION BY region ORDER BY total_amount DESC) as rank
    FROM orders
    GROUP BY customer_id, customer_name
"""

ast = parser.parse(sql)
functions = func_extractor.extract(ast)

for func in functions:
    print(f"Function: {func.function_name}")
    print(f"  SQL: {func.sql_text}")
    print(f"  Is Aggregate: {func.is_aggregate}")
    print(f"  Is Window: {func.is_window}")
    
    if func.is_window:
        print(f"  Partition By: {func.window_partition_by}")
        print(f"  Order By: {func.window_order_by}")
    
    print(f"  Parameters:")
    for param in func.parameters:
        print(f"    Position {param.position}: {param.expression}")
        if param.is_literal:
            print(f"      Literal value: {param.literal_value}")
        else:
            print(f"      Columns: {[col.column_name for col in param.columns_referenced]}")
    
    if func.nested_functions:
        print(f"  Nested functions: {len(func.nested_functions)}")
```

### Extracting Subqueries and CTEs

```python
from tools.deconstructor import SubqueryCTEExtractor

subquery_extractor = SubqueryCTEExtractor(dialect="teradata")

sql = """
    WITH customer_totals AS (
        SELECT 
            customer_id,
            SUM(order_amount) as total_amount
        FROM orders
        GROUP BY customer_id
    ),
    vip_customers AS (
        SELECT customer_id
        FROM customer_totals
        WHERE total_amount > 10000
    )
    SELECT 
        c.customer_name,
        ct.total_amount,
        (SELECT COUNT(*) FROM orders o WHERE o.customer_id = c.customer_id) as order_count
    FROM customers c
    INNER JOIN customer_totals ct ON c.customer_id = ct.customer_id
    WHERE c.customer_id IN (SELECT customer_id FROM vip_customers)
"""

ast = parser.parse(sql)

# Extract CTEs
ctes = subquery_extractor.extract_ctes(ast)
for cte in ctes:
    print(f"CTE: {cte.name}")
    print(f"  Columns: {cte.columns}")
    print(f"  Definition: {cte.definition_sql[:100]}...")
    print(f"  Is Recursive: {cte.is_recursive}")
    print(f"  Dependencies: {cte.dependencies}")
    print(f"  Source Tables: {cte.source_tables}")

# Extract subqueries
subqueries = subquery_extractor.extract_subqueries(ast)
for subq in subqueries:
    print(f"Subquery: {subq.alias}")
    print(f"  Context: {subq.context}")
    print(f"  Is Correlated: {subq.is_correlated}")
    if subq.is_correlated:
        print(f"  Correlation Columns: {subq.correlation_columns}")
    print(f"  Output Columns: {subq.output_columns}")
    print(f"  Source Tables: {subq.source_tables}")
```

### Complete Element Catalog

```python
# Extract everything at once
catalog = extractor.extract_all()

# Access comprehensive metadata
print(f"Statement ID: {catalog.statement_id}")
print(f"Statement Type: {catalog.statement_type}")
print(f"Raw SQL: {catalog.raw_sql}")

# Source and target tables
print(f"\nTarget Table: {catalog.target_table}")
print(f"Source Tables: {catalog.source_tables}")

# WHERE clause
if catalog.where_clause:
    print(f"\nWHERE Clause: {catalog.where_clause.sql_text}")
    for condition in catalog.where_clause.conditions:
        print(f"  {condition.expression} (operator: {condition.operator})")
        print(f"    Columns: {[col.column_name for col in condition.columns_referenced]}")
        if condition.has_subquery:
            print(f"    Contains subquery")

# GROUP BY
if catalog.group_by:
    print(f"\nGROUP BY:")
    for expr in catalog.group_by.expressions:
        print(f"  {expr}")
    print(f"  Columns: {[col.column_name for col in catalog.group_by.columns]}")

# ORDER BY
if catalog.order_by:
    print(f"\nORDER BY:")
    for item in catalog.order_by.items:
        print(f"  {item.expression} {item.direction}")

# Statistics
print(f"\nStatistics:")
print(f"  CASE statements: {len(catalog.case_statements)}")
print(f"  Functions: {len(catalog.functions)}")
print(f"  JOINs: {len(catalog.joins)}")
print(f"  CTEs: {len(catalog.ctes)}")
print(f"  Subqueries: {len(catalog.subqueries)}")
```

## Best Practices

1. **Always Parse First**: Use AST Generator before Deconstructor
2. **Check Element Existence**: Not all queries have all element types
3. **Handle Nested Structures**: Use recursive methods for nested CASE/functions
4. **Track Aliases**: Column and table aliases are crucial for lineage
5. **Validate Complex Queries**: Test with increasingly complex SQL patterns
6. **Use Type Hints**: Leverage data models for type safety
7. **Cache Catalogs**: Reuse extracted catalogs for multiple analyses

## Performance Considerations

- **Large Queries**: Consider streaming or chunking for very large SQL files
- **Nested Structures**: Deep nesting may increase extraction time
- **Duplicate Detection**: Extractors deduplicate by SQL text
- **Memory Usage**: Complex queries produce large catalogs

## Limitations

- Some proprietary SQL extensions may not be fully supported
- Extremely complex nested structures may require manual verification
- Dynamic SQL elements cannot be extracted from static analysis
- Some dialect-specific constructs may need custom handling

## Dependencies

- **SQLGlot**: Core parsing and AST traversal
- **ast_generator**: Must be used to generate ASTs first
- **models/data_models**: Data classes for all extracted elements

## Related Modules

- **tools/ast_generator**: Generates ASTs for deconstruction
- **tools/lineage**: Uses catalogs for lineage tracking
- **tools/documentation**: Generates docs from catalogs
- **tools/visualization**: Visualizes extracted elements

## Contributing

When extending this module:
1. Add new extractor classes for new SQL constructs
2. Register extractors in `SQLElementExtractor`
3. Define data models in `models/data_models`
4. Add unit tests for new extractors
5. Update this README with usage examples

## License

Part of the SQL Reverse Engineering project.

## Support

For issues or questions, refer to the main project documentation or raise an issue in the project repository.
