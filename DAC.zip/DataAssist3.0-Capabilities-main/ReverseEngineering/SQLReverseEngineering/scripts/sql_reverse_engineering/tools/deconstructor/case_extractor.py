"""
CASE Statement Extractor module.

Extracts CASE statements with complete branch details, preserving all
business logic without abstraction.
"""

import sqlglot
from sqlglot import exp
from typing import List, Optional
import uuid
import sys
import os

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from models.data_models import CaseStatement, CaseBranch, ColumnRef


class CaseExtractor:
    """
    Extract CASE statements with complete branch details.
    Captures all WHEN/THEN/ELSE branches without abstracting any logic.
    """

    def __init__(self, dialect: str = "teradata"):
        """
        Initialize extractor.

        Args:
            dialect: SQL dialect for generating SQL text
        """
        self.dialect = dialect

    def extract(self, ast: exp.Expression) -> List[CaseStatement]:
        """
        Extract all CASE statements from AST.

        Args:
            ast: Parsed SQL AST

        Returns:
            List of CaseStatement objects with complete branch details
        """
        cases = []

        for case_node in ast.find_all(exp.Case):
            case_stmt = self._extract_case(case_node)
            cases.append(case_stmt)

        return cases

    def _extract_case(self, case_node: exp.Case) -> CaseStatement:
        """
        Extract a single CASE statement with all branches.

        Args:
            case_node: SQLGlot Case expression

        Returns:
            CaseStatement with complete details
        """
        branches = []

        # Get the IFs (WHEN/THEN pairs)
        ifs = case_node.args.get("ifs", [])

        for when_node in ifs:
            # when_node is an If expression with 'this' (condition) and 'true' (result)
            condition_expr = when_node.this
            result_expr = when_node.args.get("true")

            branch = CaseBranch(
                condition=condition_expr.sql(dialect=self.dialect) if condition_expr else "",
                result=result_expr.sql(dialect=self.dialect) if result_expr else "",
                condition_columns=self._extract_columns(condition_expr) if condition_expr else [],
                result_columns=self._extract_columns(result_expr) if result_expr else []
            )
            branches.append(branch)

        # Get ELSE clause
        else_result = None
        else_columns = []
        default_expr = case_node.args.get("default")
        if default_expr:
            else_result = default_expr.sql(dialect=self.dialect)
            else_columns = self._extract_columns(default_expr)

        # Get output alias if present
        output_alias = None
        parent = case_node.parent
        if parent and isinstance(parent, exp.Alias):
            output_alias = parent.alias

        return CaseStatement(
            expression_id=str(uuid.uuid4())[:8],
            sql_text=case_node.sql(dialect=self.dialect),
            branches=branches,
            else_result=else_result,
            else_columns=else_columns,
            output_alias=output_alias
        )

    def _extract_columns(self, expr: exp.Expression) -> List[ColumnRef]:
        """
        Extract all column references from an expression.

        Args:
            expr: SQLGlot expression

        Returns:
            List of ColumnRef objects
        """
        columns = []

        if expr is None:
            return columns

        for col in expr.find_all(exp.Column):
            columns.append(ColumnRef(
                table_name=col.table if col.table else "",
                column_name=col.name,
                alias=None
            ))

        return columns

    def extract_nested_cases(self, case_stmt: CaseStatement) -> List[CaseStatement]:
        """
        Extract nested CASE statements within a CASE statement.

        Args:
            case_stmt: CaseStatement to analyze

        Returns:
            List of nested CaseStatement objects
        """
        nested = []

        # Parse the SQL text to find nested CASE statements
        try:
            ast = sqlglot.parse_one(f"SELECT {case_stmt.sql_text}", read=self.dialect)
            for case_node in ast.find_all(exp.Case):
                # Skip the outer CASE (the one we're analyzing)
                if case_node.sql(dialect=self.dialect) != case_stmt.sql_text:
                    nested.append(self._extract_case(case_node))
        except Exception:
            pass

        return nested

    def get_all_columns(self, case_stmt: CaseStatement) -> List[ColumnRef]:
        """
        Get all columns referenced in a CASE statement.

        Args:
            case_stmt: CaseStatement to analyze

        Returns:
            List of all unique ColumnRef objects
        """
        return case_stmt.get_all_source_columns()

    def to_business_logic_description(self, case_stmt: CaseStatement) -> str:
        """
        Generate a human-readable description of the CASE logic.

        Args:
            case_stmt: CaseStatement to describe

        Returns:
            Human-readable description string
        """
        lines = []

        for i, branch in enumerate(case_stmt.branches, 1):
            lines.append(f"Branch {i}: WHEN {branch.condition}")
            lines.append(f"         THEN {branch.result}")

        if case_stmt.else_result:
            lines.append(f"Default:  ELSE {case_stmt.else_result}")

        return "\n".join(lines)
