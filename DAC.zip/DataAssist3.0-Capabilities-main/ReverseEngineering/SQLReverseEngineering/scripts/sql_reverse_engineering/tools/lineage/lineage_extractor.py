"""
Lineage Extractor module.

Core lineage extraction using SQLGlot's native lineage capabilities.
Traces column-level lineage from source to target with transformation classification.

Supports:
- Static SQL lineage extraction
- Dynamic SQL detection and expansion
- Merged lineage from both static and dynamic SQL
"""
import sqlglot
from sqlglot import exp
from typing import Dict, List, Optional, Set, Tuple, Any
import sys
import os
import re
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from models.data_models import ColumnRef, TransformationType, TransformationSubtype, TransformationInfo, LineageEdge
from lineage.lineage_graph import LineageGraph
from lineage.transformation_classifier import TransformationClassifier
from lineage.cte_resolver import CTEResolver

class LineageExtractor:
    """
    Core lineage extraction using SQLGlot's native lineage capabilities.
    """

    def __init__(self, schema: Dict[str, List[str]]=None, dialect: str='teradata', alias_map: Dict[str, str]=None, volatile_handler=None):
        """
        Initialize extractor.

        Args:
            schema: Optional schema dict {table_name: [column_names]}
            dialect: SQL dialect
            alias_map: Optional pre-built alias map from Output Corrector {alias: table_name}
            volatile_handler: Optional VolatileTableHandler with volatile table lineage
        """
        self.schema = schema or {}
        self.schema_normalized = {k.upper(): v for k, v in self.schema.items()}
        self.dialect = dialect
        self.classifier = TransformationClassifier(dialect)
        self.cte_resolver = CTEResolver(dialect)
        self.prebuilt_alias_map = {k.upper(): v.upper() for k, v in alias_map.items()} if alias_map else {}
        self.volatile_handler = volatile_handler
        # Track aliases that map to different tables across scopes (e.g., GL1 -> CATGRY1 in one CASE branch, GL1 -> CATGRY3 in another)
        self._alias_conflicts = set()  # alias keys (uppercase) with conflicting table mappings
        # Track aliases that originate from subquery/derived table nodes (exp.Subquery),
        # as opposed to regular table aliases (exp.Table). Only subquery aliases should
        # appear in the "Subquery Alias" column of the STTM output.
        self._subquery_alias_keys = set()  # alias keys (uppercase) from derived tables

    def extract_lineage(self, sql: str) -> LineageGraph:
        """
        Extract column-level lineage from SQL.

        Args:
            sql: SQL string

        Returns:
            LineageGraph with complete lineage
        """
        # Handle CALL DBC.SYSEXECSQL('...') dynamic SQL wrappers —
        # extract the SQL string from inside and process it directly.
        stripped = sql.strip()
        if re.match(r"CALL\s+DBC\.SYSEXECSQL\s*\(\s*'", stripped, re.IGNORECASE):
            inner_match = re.search(r"CALL\s+DBC\.SYSEXECSQL\s*\(\s*'(.*?)'\s*\)\s*;?\s*$", stripped, re.IGNORECASE | re.DOTALL)
            if inner_match:
                inner_sql = inner_match.group(1)
                # Handle concatenated variable references like '|| V_ID ||'
                inner_sql = re.sub(r"'\s*\|\|\s*\w+\s*\|\|\s*'", '0', inner_sql)
                return self._extract_static_lineage(inner_sql)

        if self.volatile_handler:
            try:
                normalized_sql = self._normalize_teradata_literals(sql)
                ast = sqlglot.parse_one(normalized_sql, read=self.dialect)
                # For CREATE statements targeting volatile tables, skip only if
                # the CREATE has no SELECT (pure DDL).  INSERT/CREATE-AS-SELECT
                # statements should still be processed to capture what flows
                # INTO the volatile table.
                if isinstance(ast, exp.Create):
                    target_table = self._get_target_table(ast)
                    if target_table:
                        target_upper = target_table.upper()
                        simple_name = target_upper.split('.')[-1] if '.' in target_upper else target_upper
                        if target_upper in self.volatile_handler.volatile_tables or simple_name in self.volatile_handler.volatile_tables:
                            # Only skip if there's no SELECT inside — pure DDL
                            if not ast.find(exp.Select):
                                return LineageGraph()
            except Exception:
                pass
        return self._extract_static_lineage(sql)

    def _get_table_name(self, table_expr) -> Optional[str]:
        """Helper to safely extract table name."""
        if table_expr is None:
            return None
        if isinstance(table_expr, exp.Table):
            name = table_expr.name
            if hasattr(table_expr, 'db') and table_expr.db:
                name = f'{table_expr.db}.{name}'
            return name
        if isinstance(table_expr, exp.Schema):
            if hasattr(table_expr, 'this') and table_expr.this:
                return self._get_table_name(table_expr.this)
            return str(table_expr)
        if hasattr(table_expr, 'name'):
            return table_expr.name
        try:
            return table_expr.sql(dialect=self.dialect)
        except Exception:
            return str(table_expr)

    def _get_target_table(self, ast: exp.Expression) -> Optional[str]:
        """
        Get the target table name.

        Args:
            ast: Parsed AST

        Returns:
            Target table name or None
        """
        if isinstance(ast, exp.Insert):
            return self._get_table_name(ast.this)
        elif isinstance(ast, (exp.Update, exp.Delete)):
            return self._get_table_name(ast.this)
        elif isinstance(ast, exp.Create):
            return self._get_table_name(ast.this)
        elif isinstance(ast, exp.Select):
            # Handle SELECT ... INTO variable (Teradata SPL)
            into = ast.args.get('into')
            if into:
                for tbl in into.find_all(exp.Table):
                    return self._get_table_name(tbl)
        return None

    def _get_main_query(self, ast: exp.Expression) -> Optional[exp.Expression]:
        """
        Get the main query (SELECT) from the AST.
        Recursively unwraps nested FROM-subqueries to find the innermost
        SELECT that has real tables (not just subquery aliases).

        Args:
            ast: Parsed AST

        Returns:
            Main SELECT expression or None
        """
        query = None
        if isinstance(ast, exp.Select):
            query = ast
        elif isinstance(ast, exp.Union):
            return ast
        elif isinstance(ast, exp.Insert):
            if hasattr(ast, 'expression') and ast.expression:
                if isinstance(ast.expression, (exp.Select, exp.Union)):
                    query = ast.expression
                elif isinstance(ast.expression, exp.Subquery):
                    inner = ast.expression.this
                    if isinstance(inner, (exp.Select, exp.Union)):
                        query = inner
            if query is None:
                for child in ast.iter_expressions():
                    if isinstance(child, exp.Union):
                        return child
                    if isinstance(child, exp.Select):
                        query = child
                        break
                    if isinstance(child, exp.Subquery):
                        inner = child.this
                        if isinstance(inner, (exp.Select, exp.Union)):
                            query = inner
                            break
            if query is None:
                query = ast.find(exp.Select)
        elif isinstance(ast, exp.Create):
            query = ast.find(exp.Select)
        else:
            query = ast.find(exp.Select)
        if query is None:
            return None
        # Recursively unwrap: if SELECT only has a single FROM subquery
        # with no JOINs at this level, descend into the subquery to find
        # the SELECT that actually references real tables.
        if isinstance(query, exp.Select):
            query = self._unwrap_single_subquery(query)
        return query

    def _unwrap_single_subquery(self, select_expr: exp.Expression) -> exp.Expression:
        """
        Unwrap SELECT ... FROM (single subquery) AS alias patterns.
        When a SELECT's only FROM source is a single subquery (no JOINs),
        descend into the subquery. Repeats until we find a SELECT with
        real tables or JOINs. Collects intermediate wrapper SELECTs that
        have transformations for later processing.

        Only unwraps when the outer SELECT is a pure passthrough (SELECT *
        or table.*). Preserves the outer SELECT when it has GROUP BY,
        HAVING, or explicit column projections that would be lost.

        Args:
            select_expr: A SELECT expression

        Returns:
            The innermost meaningful SELECT or the original
        """
        if not isinstance(select_expr, exp.Select):
            return select_expr
        from_arg = select_expr.args.get('from_') or select_expr.args.get('from')
        joins_arg = select_expr.args.get('joins')
        # Only unwrap if there's a FROM with a single subquery and no JOINs
        if not from_arg or joins_arg:
            return select_expr
        # Don't unwrap if outer SELECT has GROUP BY or HAVING
        if select_expr.args.get('group') or select_expr.args.get('having'):
            return select_expr
        # Don't unwrap if outer SELECT has explicit column projections
        # (not SELECT * or table.*). Named columns would be lost after unwrapping.
        expressions = list(select_expr.expressions)
        if expressions:
            is_star = any(isinstance(e, exp.Star) for e in expressions)
            is_table_star = any(
                isinstance(e, exp.Column) and isinstance(getattr(e, 'this', None), exp.Star)
                for e in expressions
            )
            if not is_star and not is_table_star:
                # Has named column expressions — don't unwrap
                return select_expr
        from_source = from_arg.this
        if isinstance(from_source, exp.Subquery):
            inner = from_source.this
            if isinstance(inner, exp.Select):
                return self._unwrap_single_subquery(inner)
            elif isinstance(inner, exp.Union):
                return inner
        return select_expr

    def _collect_wrapper_transformations(self, ast: exp.Expression, main_query: exp.Expression) -> Dict[str, exp.Expression]:
        """
        Walk the wrapper SELECT levels between the original INSERT's SELECT
        and the unwrapped main_query, collecting non-trivial column transformations.

        For example, if the INSERT has:
            SELECT ... FROM (
                SEL B.col1, (COALESCE(B.X,0) + ...) AS PCO_LTD FROM (
                    SELECT ... FROM real_tables  <-- main_query
                ) B
            ) A

        This collects PCO_LTD -> COALESCE formula from the wrapper level.

        Args:
            ast: The full AST (Insert node)
            main_query: The innermost unwrapped SELECT

        Returns:
            Dict mapping column_name_upper -> transformation expression
        """
        transformations = {}

        # Get the original SELECT from the INSERT
        original_select = None
        if isinstance(ast, exp.Insert):
            if hasattr(ast, 'expression') and ast.expression:
                if isinstance(ast.expression, exp.Select):
                    original_select = ast.expression
                elif isinstance(ast.expression, exp.Subquery) and isinstance(ast.expression.this, exp.Select):
                    original_select = ast.expression.this

        if original_select is None or original_select is main_query:
            return transformations

        # Walk through wrapper levels
        current = original_select
        while current is not main_query and isinstance(current, exp.Select):
            for col_expr in current.expressions:
                if isinstance(col_expr, exp.Alias):
                    col_name = col_expr.alias
                    inner_expr = col_expr.this
                    # Only capture non-trivial transformations (not simple column refs)
                    if col_name and not isinstance(inner_expr, exp.Column):
                        transformations[col_name.upper()] = inner_expr

            # Descend into FROM subquery
            from_arg = current.args.get('from_') or current.args.get('from')
            if from_arg and isinstance(from_arg.this, exp.Subquery):
                inner = from_arg.this.this
                if isinstance(inner, exp.Select):
                    current = inner
                else:
                    break
            else:
                break

        return transformations

    def _add_wrapper_aliases(self, ast: exp.Expression, main_query: exp.Expression, alias_map: Dict[str, str]) -> None:
        """
        Add wrapper subquery aliases to the alias_map so that wrapper-level
        expressions referencing B.column can be traced through the main_query.

        Args:
            ast: The full AST (Insert node)
            main_query: The innermost unwrapped SELECT
            alias_map: The alias map to augment
        """
        original_select = None
        if isinstance(ast, exp.Insert):
            if hasattr(ast, 'expression') and ast.expression:
                if isinstance(ast.expression, exp.Select):
                    original_select = ast.expression
                elif isinstance(ast.expression, exp.Subquery) and isinstance(ast.expression.this, exp.Select):
                    original_select = ast.expression.this

        if original_select is None or original_select is main_query:
            return

        # Collect wrapper subquery aliases
        current = original_select
        while current is not main_query and isinstance(current, exp.Select):
            from_arg = current.args.get('from_') or current.args.get('from')
            if from_arg and isinstance(from_arg.this, exp.Subquery):
                subq = from_arg.this
                if hasattr(subq, 'alias') and subq.alias:
                    alias_str = subq.alias if isinstance(subq.alias, str) else str(subq.alias)
                    alias_upper = alias_str.upper()
                    if alias_upper not in alias_map:
                        # Map wrapper alias to the first real FROM table of main_query
                        main_from = main_query.args.get('from_') or main_query.args.get('from')
                        if main_from and hasattr(main_from, 'this'):
                            if isinstance(main_from.this, exp.Table):
                                first_table = main_from.this.name
                                if main_from.this.db:
                                    first_table = f'{main_from.this.db}.{first_table}'
                                alias_map[alias_upper] = first_table.upper()
                inner = subq.this
                if isinstance(inner, exp.Select):
                    current = inner
                else:
                    break
            else:
                break

    def _get_insert_columns(self, ast: exp.Expression) -> Optional[List[str]]:
        """
        Get column names from INSERT statement column list.

        Args:
            ast: Parsed AST

        Returns:
            List of column names or None if not an INSERT
        """
        if not isinstance(ast, exp.Insert):
            return None
        schema = ast.this
        if schema and hasattr(schema, 'expressions') and schema.expressions:
            columns = []
            for col_expr in schema.expressions:
                if isinstance(col_expr, exp.Column):
                    columns.append(col_expr.name)
                elif hasattr(col_expr, 'name'):
                    columns.append(col_expr.name)
                else:
                    columns.append(str(col_expr))
            return columns if columns else None
        return None

    def _get_schema_columns(self, table_name: str) -> List[str]:
        """
        Get column names for a table from the schema.
        Handles both qualified (schema.table) and unqualified table names.

        Args:
            table_name: Table name (may include schema prefix)

        Returns:
            List of column names, or empty list if not found
        """
        if not self.schema_normalized:
            return []
        table_upper = table_name.upper()
        if table_upper in self.schema_normalized:
            return self.schema_normalized[table_upper]
        if '.' in table_name:
            simple_name = table_name.split('.')[-1].upper()
            if simple_name in self.schema_normalized:
                return self.schema_normalized[simple_name]
        for key, cols in self.schema_normalized.items():
            key_simple = key.split('.')[-1] if '.' in key else key
            if key_simple == table_upper or key_simple == table_name.split('.')[-1].upper():
                return cols
        return []

    def _expand_star(self, star_expr: exp.Star, ast: exp.Expression, alias_map: Dict[str, str]) -> List[Tuple[str, str, exp.Expression]]:
        """
        Expand a SELECT * or table.* to individual column references using schema.

        Args:
            star_expr: The Star expression
            ast: Full AST for context
            alias_map: Map of table aliases to actual table names

        Returns:
            List of (column_name, source_table, column_expression) tuples
        """
        expanded = []
        table_qualifier = None
        if hasattr(star_expr, 'table') and star_expr.table:
            table_qualifier = star_expr.table
        elif hasattr(star_expr, 'parent') and isinstance(star_expr.parent, exp.Column):
            table_qualifier = star_expr.parent.table
        parent = star_expr.parent
        if parent and hasattr(parent, 'this') and isinstance(parent.this, exp.Identifier):
            table_qualifier = parent.this.name
        if table_qualifier:
            actual_table = alias_map.get(table_qualifier.upper(), table_qualifier)
            schema_cols = self._get_schema_columns(actual_table)
            if schema_cols:
                for col_name in schema_cols:
                    col_expr = exp.Column(this=exp.to_identifier(col_name), table=exp.to_identifier(table_qualifier))
                    expanded.append((col_name, actual_table, col_expr))
            else:
                # Build a Column(table=qualifier, this=Star) so that
                # _trace_column_sources can resolve the table qualifier.
                col_star = exp.Column(
                    this=exp.Star(),
                    table=exp.to_identifier(table_qualifier)
                )
                expanded.append(('*', actual_table, col_star))
        else:
            from_clause = ast.find(exp.From)
            if from_clause and from_clause.this:
                main_table = self._get_table_from_expr(from_clause.this, alias_map)
                if main_table:
                    schema_cols = self._get_schema_columns(main_table)
                    for col_name in schema_cols:
                        col_expr = exp.Column(this=exp.to_identifier(col_name), table=exp.to_identifier(main_table))
                        expanded.append((col_name, main_table, col_expr))
            for join in ast.find_all(exp.Join):
                if join.this:
                    join_table = self._get_table_from_expr(join.this, alias_map)
                    if join_table:
                        schema_cols = self._get_schema_columns(join_table)
                        for col_name in schema_cols:
                            col_expr = exp.Column(this=exp.to_identifier(col_name), table=exp.to_identifier(join_table))
                            expanded.append((col_name, join_table, col_expr))
            if not expanded:
                # No schema available — create a single * entry but preserve
                # the source table name from FROM clause so lineage edges can
                # reference the correct source table instead of LITERAL.
                all_tables = []
                from_clause = ast.find(exp.From)
                if from_clause and from_clause.this:
                    tbl = self._get_table_from_expr(from_clause.this, alias_map)
                    if tbl:
                        all_tables.append(tbl)
                for join in ast.find_all(exp.Join):
                    if join.this:
                        jt = self._get_table_from_expr(join.this, alias_map)
                        if jt:
                            all_tables.append(jt)
                if all_tables:
                    for tbl in all_tables:
                        col_star = exp.Column(
                            this=exp.Star(),
                            table=exp.to_identifier(tbl)
                        )
                        expanded.append(('*', tbl, col_star))
                else:
                    expanded.append(('*', '', star_expr))
        return expanded

    def _get_table_from_expr(self, table_expr: exp.Expression, alias_map: Dict[str, str]) -> Optional[str]:
        """
        Extract table name from a table expression.

        Args:
            table_expr: Table expression
            alias_map: Alias map

        Returns:
            Table name or None
        """
        if isinstance(table_expr, exp.Table):
            name = table_expr.name
            if table_expr.db:
                name = f'{table_expr.db}.{name}'
            return name
        elif isinstance(table_expr, exp.Alias):
            return self._get_table_from_expr(table_expr.this, alias_map)
        return None

    def _get_output_columns(self, query: exp.Expression, target_table: Optional[str], insert_columns: Optional[List[str]]=None, ast: exp.Expression=None) -> List[tuple]:
        """
        Get output columns and their expressions.
        Expands SELECT * using schema when available.

        Args:
            query: Query expression
            target_table: Target table name
            insert_columns: Column names from INSERT statement (if applicable)
            ast: Full AST for context (used for star expansion)

        Returns:
            List of (column_name, expression) tuples
        """
        columns = []
        if not isinstance(query, exp.Select):
            return columns
        alias_map = self._build_alias_map(ast) if ast else self._build_alias_map(query)
        insert_col_idx = 0
        for idx, expr in enumerate(query.expressions):
            col_name = None
            col_expr = expr
            if isinstance(expr, exp.Alias):
                col_name = expr.alias
                col_expr = expr.this
                if isinstance(col_expr, exp.Star):
                    expanded = self._expand_star(col_expr, ast or query, alias_map)
                    for exp_col_name, source_table, exp_col_expr in expanded:
                        if insert_columns and insert_col_idx < len(insert_columns):
                            final_col_name = insert_columns[insert_col_idx]
                            insert_col_idx += 1
                        else:
                            final_col_name = exp_col_name
                        columns.append((final_col_name, exp_col_expr))
                    continue
            elif isinstance(expr, exp.Column):
                if hasattr(expr, 'this') and isinstance(expr.this, exp.Star):
                    expanded = self._expand_star(expr.this, ast or query, alias_map)
                    for exp_col_name, source_table, exp_col_expr in expanded:
                        if insert_columns and insert_col_idx < len(insert_columns):
                            final_col_name = insert_columns[insert_col_idx]
                            insert_col_idx += 1
                        else:
                            final_col_name = exp_col_name
                        columns.append((final_col_name, exp_col_expr))
                    continue
                else:
                    col_name = expr.name
                    col_expr = expr
            elif isinstance(expr, exp.Star):
                expanded = self._expand_star(expr, ast or query, alias_map)
                for exp_col_name, source_table, exp_col_expr in expanded:
                    if insert_columns and insert_col_idx < len(insert_columns):
                        final_col_name = insert_columns[insert_col_idx]
                        insert_col_idx += 1
                    else:
                        final_col_name = exp_col_name
                    columns.append((final_col_name, exp_col_expr))
                continue
            elif isinstance(expr, exp.Dot):
                if isinstance(expr.expression, exp.Star):
                    table_name = expr.this.name if hasattr(expr.this, 'name') else str(expr.this)
                    actual_table = alias_map.get(table_name.upper(), table_name)
                    schema_cols = self._get_schema_columns(actual_table)
                    if schema_cols:
                        for exp_col_name in schema_cols:
                            col_expr_new = exp.Column(this=exp.to_identifier(exp_col_name), table=exp.to_identifier(table_name))
                            if insert_columns and insert_col_idx < len(insert_columns):
                                final_col_name = insert_columns[insert_col_idx]
                                insert_col_idx += 1
                            else:
                                final_col_name = exp_col_name
                            columns.append((final_col_name, col_expr_new))
                        continue
                    else:
                        col_name = '*'
                        col_expr = expr
                else:
                    col_name = expr.expression.name if hasattr(expr.expression, 'name') else str(expr.expression)
                    col_expr = expr
            else:
                if insert_columns and insert_col_idx < len(insert_columns):
                    col_name = insert_columns[insert_col_idx]
                else:
                    col_name = f'col_{len(columns) + 1}'
                col_expr = expr
            if insert_columns and insert_col_idx < len(insert_columns):
                col_name = insert_columns[insert_col_idx]
                insert_col_idx += 1
            columns.append((col_name, col_expr))
        return columns

    def _trace_column_sources(self, expr: exp.Expression, resolved_ctes: Dict, ast: exp.Expression, alias_map: Dict[str, str]) -> List[ColumnRef]:
            """
            Trace column sources from an expression.
            Searches through all tables in the AST including nested subqueries and JOINs.

            Args:
                expr: Column expression to trace
                resolved_ctes: Resolved CTE definitions
                ast: Full AST for context
                alias_map: Table alias map

            Returns:
                List of ColumnRef sources
            """
            sources = []

            if expr is None:
                return sources

            # Handle scalar subqueries: (SELECT col FROM table)
            # When the expression itself is a scalar subquery, resolve columns
            # against the subquery's own FROM table, not the outer query.
            if isinstance(expr, exp.Subquery):
                inner_select = expr.this if hasattr(expr, 'this') else None
                if isinstance(inner_select, exp.Select):
                    subquery_tables = []
                    for table in inner_select.find_all(exp.Table):
                        tname = table.name
                        if hasattr(table, 'db') and table.db:
                            tname = f'{table.db}.{tname}'
                        if tname:
                            subquery_tables.append(tname)
                    for col in inner_select.find_all(exp.Column):
                        col_name = col.name if hasattr(col, 'name') else str(col)
                        table_ref = None
                        if hasattr(col, 'table') and col.table:
                            table_qualifier = col.table.upper()
                            table_ref = alias_map.get(table_qualifier) or col.table
                        elif subquery_tables:
                            table_ref = subquery_tables[0]
                        sources.append(ColumnRef(
                            table_name=table_ref if table_ref else '',
                            column_name=col_name
                        ))
                    if sources:
                        return sources

            # Collect Column references from the expression, but skip columns
            # that are inside scalar subquery predicates (ON/WHERE clauses).
            # Only value-output columns (SELECT list) from scalar subqueries
            # should create lineage edges; predicate columns are just filters.
            columns_found = []
            for col in expr.find_all(exp.Column):
                if self._is_scalar_subquery_predicate_col(col, expr):
                    continue
                columns_found.append(col)

            # If no columns found, check if expr itself is a column
            if not columns_found and isinstance(expr, exp.Column):
                columns_found = [expr]

            # Build a comprehensive table list from the entire AST
            all_tables = {}  # table_name_upper -> full_table_name

            # Collect all tables from the AST recursively
            for table in ast.find_all(exp.Table):
                table_name = table.name
                if hasattr(table, 'db') and table.db:
                    table_name = f'{table.db}.{table_name}'
                if table_name:
                    table_upper = table_name.upper()
                    simple_name = table_name.split('.')[-1].upper() if '.' in table_name else table_upper
                    all_tables[simple_name] = table_name
                    all_tables[table_upper] = table_name
                    # Also add alias if present
                    if hasattr(table, 'alias') and table.alias:
                        alias_str = table.alias if isinstance(table.alias, str) else str(table.alias)
                        all_tables[alias_str.upper()] = table_name

            # Process each column reference
            for col in columns_found:
                col_name = col.name if hasattr(col, 'name') else str(col)
                table_ref = None

                # Check if this column is inside a scalar subquery within the expression
                subquery_from_table = self._find_enclosing_subquery_table(col, expr)
                if subquery_from_table:
                    table_ref = subquery_from_table
                # Check if column has explicit table qualifier
                elif hasattr(col, 'table') and col.table:
                    table_qualifier = col.table
                    table_qualifier_upper = table_qualifier.upper() if table_qualifier else ''

                    # Resolve through alias map first
                    if table_qualifier_upper in alias_map:
                        table_ref = alias_map[table_qualifier_upper]
                    elif table_qualifier_upper in all_tables:
                        table_ref = all_tables[table_qualifier_upper]
                    else:
                        table_ref = table_qualifier
                else:
                    # Unqualified column - try to find which table it belongs to
                    col_name_upper = col_name.upper() if col_name else ''

                    # First, check if the column is an output alias of a JOINed subquery.
                    # e.g., JOIN (SELECT MAX(RPTID) AS MAX_RPT_ID FROM T) B
                    # MAX_RPT_ID comes from B, not the main FROM table.
                    if not table_ref and isinstance(ast, exp.Select) and col_name_upper:
                        for join_node in ast.find_all(exp.Join):
                            if isinstance(join_node.this, exp.Subquery):
                                sq = join_node.this
                                sq_alias = sq.alias
                                inner_sel = sq.find(exp.Select)
                                if inner_sel:
                                    for sel_col in inner_sel.expressions:
                                        sel_alias = sel_col.alias if hasattr(sel_col, 'alias') else None
                                        if sel_alias and str(sel_alias).upper() == col_name_upper:
                                            # Column comes from this subquery — resolve to its source table
                                            sq_inner_from = inner_sel.args.get('from')
                                            if sq_inner_from and isinstance(sq_inner_from.this, exp.Table):
                                                t = sq_inner_from.this
                                                table_ref = f'{t.db}.{t.name}' if hasattr(t, 'db') and t.db else t.name
                                            elif sq_alias:
                                                sq_alias_str = sq_alias if isinstance(sq_alias, str) else str(sq_alias)
                                                table_ref = alias_map.get(sq_alias_str.upper(), sq_alias_str)
                                            break
                            if table_ref:
                                break

                    # Then prefer the FROM clause table of the AST being traced
                    # (most likely source for unqualified columns)
                    if not table_ref and isinstance(ast, exp.Select):
                        from_clause = ast.args.get('from') or ast.args.get('from_')
                        if from_clause:
                            from_source = from_clause.this
                            from_tbl = None
                            if isinstance(from_source, exp.Table):
                                from_tbl = from_source.name
                                if hasattr(from_source, 'db') and from_source.db:
                                    from_tbl = f'{from_source.db}.{from_tbl}'
                            elif isinstance(from_source, exp.Subquery):
                                # Derived table — resolve through alias
                                sq_alias = from_source.alias
                                if sq_alias:
                                    sq_alias_str = sq_alias if isinstance(sq_alias, str) else str(sq_alias)
                                    from_tbl = alias_map.get(sq_alias_str.upper())
                            if from_tbl:
                                table_ref = from_tbl

                    # Then check schema for column existence
                    if not table_ref:
                        for tbl_key, tbl_name in all_tables.items():
                            schema_cols = self._get_schema_columns(tbl_name)
                            if schema_cols:
                                col_name_upper = col_name.upper() if col_name else ''
                                if col_name_upper in [c.upper() for c in schema_cols]:
                                    table_ref = tbl_name
                                    break

                    # If not found in schema, try alias map
                    if not table_ref:
                        for alias_key, alias_val in alias_map.items():
                            if alias_val and alias_val in all_tables:
                                table_ref = all_tables.get(alias_val, alias_val)
                                break

                    # Last resort - use first table from all_tables
                    if not table_ref and all_tables:
                        table_ref = next(iter(all_tables.values()))

                # Check if this is a CTE reference
                if table_ref:
                    table_ref_upper = table_ref.upper() if table_ref else ''
                    if resolved_ctes and table_ref_upper in resolved_ctes:
                        cte_info = resolved_ctes[table_ref_upper]
                        # Try to trace through CTE to actual source
                        if hasattr(cte_info, 'source_tables') and cte_info.source_tables:
                            for src_table in cte_info.source_tables:
                                sources.append(ColumnRef(
                                    table_name=src_table,
                                    column_name=col_name
                                ))
                            continue

                # For volatile tables, keep them as direct sources.
                # The volatile handler already provides edges from volatile tables
                # to their real source tables. Expanding here incorrectly maps
                # WHERE/JOIN clause tables as column sources.

                # Create source reference
                sources.append(ColumnRef(
                    table_name=table_ref if table_ref else '',
                    column_name=col_name
                ))

            # If no columns found but expression exists, try to extract from literals or functions
            if not sources and expr is not None:
                # Check for function calls that might reference tables
                for func in expr.find_all(exp.Func):
                    func_name = func.name if hasattr(func, 'name') else ''
                    if func_name:
                        func_upper = func_name.upper()
                        # Some functions like CAST, ADD_MONTHS might be mistaken for tables
                        # Don't add them as sources
                        if func_upper not in ('CAST', 'ADD_MONTHS', 'EXTRACT', 'COALESCE', 'NVL', 'TRIM', 'UPPER', 'LOWER'):
                            continue

                # If still no sources, create a LITERAL source reference
                # This indicates a literal or computed value with no table origin
                if not sources:
                    sources.append(ColumnRef(
                        table_name='LITERAL',
                        column_name='LITERAL'
                    ))

            # Capture FROM/JOIN tables from scalar subqueries embedded in the
            # expression (e.g., CASE WHEN ... THEN (SELECT col FROM T1 JOIN T2 ON ...)).
            # The column-level tracing above only picks up the table referenced in
            # the subquery's SELECT list.  The other tables participating in the
            # subquery's FROM/JOINs are also lineage sources and must be included.
            if expr is not None and not isinstance(expr, (exp.Column, exp.Literal)):
                for sq in expr.find_all(exp.Subquery):
                    inner_sel = sq.this if hasattr(sq, 'this') else None
                    if not isinstance(inner_sel, exp.Select):
                        continue
                    # Collect all tables from the subquery's FROM + JOINs
                    sq_tables = []
                    for tbl in inner_sel.find_all(exp.Table):
                        tname = tbl.name
                        if hasattr(tbl, 'db') and tbl.db:
                            tname = f'{tbl.db}.{tname}'
                        if tname:
                            sq_tables.append(tname)
                    # Determine the output column name from the subquery's SELECT list
                    sq_col_name = None
                    if inner_sel.expressions:
                        first_sel = inner_sel.expressions[0]
                        if isinstance(first_sel, exp.Alias):
                            sq_col_name = first_sel.alias
                        elif isinstance(first_sel, exp.Column):
                            sq_col_name = first_sel.name
                    # Add each subquery table as a source (use the output column or '*')
                    for sq_tbl in sq_tables:
                        sources.append(ColumnRef(
                            table_name=sq_tbl,
                            column_name=sq_col_name or '*'
                        ))

            # Deduplicate sources
            seen = set()
            unique_sources = []
            for src in sources:
                key = (src.table_name.upper() if src.table_name else '', src.column_name.upper() if src.column_name else '')
                if key not in seen:
                    seen.add(key)
                    unique_sources.append(src)

            return unique_sources

    def _extract_literals(self, expr: exp.Expression) -> List[tuple]:
        """
        Extract literal values from an expression.

        Args:
            expr: Expression to analyze

        Returns:
            List of (value, type) tuples for literals found
        """
        literals = []
        if expr is None:
            return literals
        for lit in expr.find_all(exp.Literal):
            if lit.is_string:
                literals.append((lit.this, 'STRING'))
            elif lit.is_number:
                literals.append((lit.this, 'NUMBER'))
        for bool_lit in expr.find_all(exp.Boolean):
            literals.append((str(bool_lit.this), 'BOOLEAN'))
        for null_lit in expr.find_all(exp.Null):
            literals.append(('NULL', 'NULL'))
        for cast in expr.find_all(exp.Cast):
            inner = cast.this
            if isinstance(inner, exp.Literal) and inner.is_string:
                value = inner.this
                if self._looks_like_date(value):
                    literals.append((value, 'DATE/DATETIME'))
        return literals

    def _looks_like_date(self, value: str) -> bool:
        """Check if a string looks like a date/datetime value."""
        import re
        date_patterns = ['^\\d{4}-\\d{2}-\\d{2}', '^\\d{2}/\\d{2}/\\d{4}', '^\\d{4}/\\d{2}/\\d{2}']
        for pattern in date_patterns:
            if re.match(pattern, str(value)):
                return True
        return False

    def _build_alias_map(self, ast: exp.Expression) -> Dict[str, str]:
            """
            Build a map of table aliases to actual table names.
            Recursively traverses ALL subqueries to capture every table reference.

            Args:
                ast: Parsed AST

            Returns:
                Dict mapping alias (uppercase) to table name (uppercase)
            """
            alias_map = {}
            # Reset conflict tracking for this build pass
            self._alias_conflicts = set()
            # Reset subquery alias tracking for this build pass
            self._subquery_alias_keys = set()

            # Start with prebuilt alias map if available
            if self.prebuilt_alias_map:
                alias_map.update(self.prebuilt_alias_map)

            # Recursively build alias map from entire AST
            self._build_alias_map_recursive(ast, alias_map, set())

            return alias_map

    def _build_alias_map_recursive(self, node: exp.Expression, alias_map: Dict[str, str], visited: set) -> None:
            """
            Recursively traverse AST to build complete alias map.
            Handles nested subqueries, CTEs, JOINs, and all table references.

            Args:
                node: Current AST node
                alias_map: Dict to populate with alias -> table mappings
                visited: Set of already-visited node ids to prevent exponential traversal
            """
            if node is None:
                return
            node_id = id(node)
            if node_id in visited:
                return
            visited.add(node_id)

            # Handle CTE definitions - map CTE name to itself
            if isinstance(node, exp.CTE):
                cte_alias = node.alias
                if cte_alias:
                    cte_name = cte_alias if isinstance(cte_alias, str) else str(cte_alias)
                    alias_map[cte_name.upper()] = cte_name.upper()

            # Handle Table expressions with aliases
            if isinstance(node, exp.Table):
                table_name = node.name
                if hasattr(node, 'db') and node.db:
                    table_name = f'{node.db}.{table_name}'
                if hasattr(node, 'catalog') and node.catalog:
                    table_name = f'{node.catalog}.{table_name}'

                table_name_upper = table_name.upper() if table_name else ''

                # Check for alias on the table
                table_alias = node.alias
                if table_alias:
                    alias_str = table_alias if isinstance(table_alias, str) else str(table_alias)
                    alias_key_upper = alias_str.upper()
                    # Track conflicting alias mappings (same alias -> different tables)
                    existing = alias_map.get(alias_key_upper)
                    if existing and existing != alias_key_upper and existing != table_name_upper:
                        self._alias_conflicts.add(alias_key_upper)
                    alias_map[alias_key_upper] = table_name_upper

                # Also map table name to itself (for unqualified references)
                if table_name_upper:
                    simple_name = table_name.split('.')[-1].upper() if '.' in table_name else table_name_upper
                    alias_map[simple_name] = table_name_upper
                    alias_map[table_name_upper] = table_name_upper

            # Handle Alias expressions (e.g., subquery AS alias)
            if isinstance(node, exp.Alias):
                alias_name = node.alias
                if alias_name:
                    alias_str = alias_name if isinstance(alias_name, str) else str(alias_name)
                    # If the aliased thing is a table, map it
                    if isinstance(node.this, exp.Table):
                        inner_table = node.this
                        inner_name = inner_table.name
                        if hasattr(inner_table, 'db') and inner_table.db:
                            inner_name = f'{inner_table.db}.{inner_name}'
                        alias_map[alias_str.upper()] = inner_name.upper() if inner_name else alias_str.upper()
                    elif isinstance(node.this, exp.Subquery):
                        # Mark as a subquery/derived-table alias
                        self._subquery_alias_keys.add(alias_str.upper())
                        source_tables = self._extract_subquery_source_tables(node.this)
                        if source_tables:
                            alias_map[alias_str.upper()] = source_tables[0].upper()
                        else:
                            alias_map[alias_str.upper()] = alias_str.upper()
                    else:
                        alias_map[alias_str.upper()] = alias_str.upper()

            # Handle Subquery expressions - recurse into them
            if isinstance(node, exp.Subquery):
                if hasattr(node, 'alias') and node.alias:
                    alias_str = node.alias if isinstance(node.alias, str) else str(node.alias)
                    # Mark as a subquery/derived-table alias (not a regular table alias)
                    self._subquery_alias_keys.add(alias_str.upper())
                    # Resolve subquery alias to its first inner source table
                    source_tables = self._extract_subquery_source_tables(node)
                    if source_tables:
                        alias_map[alias_str.upper()] = source_tables[0].upper()
                    else:
                        alias_map[alias_str.upper()] = alias_str.upper()
                # Recurse into subquery's inner expression
                if hasattr(node, 'this') and node.this:
                    self._build_alias_map_recursive(node.this, alias_map, visited)

            # Handle FROM clause
            if isinstance(node, exp.From):
                if hasattr(node, 'this') and node.this:
                    self._build_alias_map_recursive(node.this, alias_map, visited)

            # Handle JOIN expressions
            if isinstance(node, exp.Join):
                if hasattr(node, 'this') and node.this:
                    self._build_alias_map_recursive(node.this, alias_map, visited)
                # Also check ON condition for any table references
                if hasattr(node, 'args'):
                    on_clause = node.args.get('on')
                    if on_clause:
                        self._build_alias_map_recursive(on_clause, alias_map, visited)

            # Handle UNION - process both branches
            if isinstance(node, exp.Union):
                if hasattr(node, 'this') and node.this:
                    self._build_alias_map_recursive(node.this, alias_map, visited)
                if hasattr(node, 'expression') and node.expression:
                    self._build_alias_map_recursive(node.expression, alias_map, visited)

            # Handle SELECT - process FROM, JOINs, and subqueries in columns
            if isinstance(node, exp.Select):
                # Process FROM clause
                from_clause = node.args.get('from')
                if from_clause:
                    self._build_alias_map_recursive(from_clause, alias_map, visited)

                # Process all JOINs
                joins = node.args.get('joins') or []
                for join in joins:
                    self._build_alias_map_recursive(join, alias_map, visited)

                # Process column expressions (may contain subqueries)
                for expr in node.expressions:
                    self._build_alias_map_recursive(expr, alias_map, visited)

                # Process WHERE clause (may contain subqueries)
                where_clause = node.args.get('where')
                if where_clause:
                    self._build_alias_map_recursive(where_clause, alias_map, visited)

            # Handle INSERT - process the expression (SELECT part)
            if isinstance(node, exp.Insert):
                if hasattr(node, 'expression') and node.expression:
                    self._build_alias_map_recursive(node.expression, alias_map, visited)

            # Handle CREATE - process the expression
            if isinstance(node, exp.Create):
                if hasattr(node, 'expression') and node.expression:
                    self._build_alias_map_recursive(node.expression, alias_map, visited)

            # Generic recursion for other node types
            if hasattr(node, 'iter_expressions'):
                for child in node.iter_expressions():
                    if child is not node:  # Avoid infinite recursion
                        self._build_alias_map_recursive(child, alias_map, visited)

    def _add_table_alias(self, table_expr: exp.Expression, alias_map: Dict[str, str]) -> None:
        """
        Add table alias to map, recursing into subqueries to collect inner aliases.

        Args:
            table_expr: Table expression
            alias_map: Alias map to update
        """
        if isinstance(table_expr, exp.Table):
            name = table_expr.name
            if table_expr.db:
                name = f'{table_expr.db}.{name}'
            alias = table_expr.alias if hasattr(table_expr, 'alias') and table_expr.alias else None
            if alias:
                alias_map[alias.upper()] = name
        elif isinstance(table_expr, exp.Subquery):
            alias = table_expr.alias if hasattr(table_expr, 'alias') and table_expr.alias else None
            inner = table_expr.this
            if alias:
                source_tables = self._extract_subquery_source_tables(table_expr)
                if source_tables:
                    alias_map[alias.upper()] = source_tables[0]
            # Recurse into the subquery to collect inner aliases
            if isinstance(inner, (exp.Select, exp.Union)):
                self._build_alias_map_recursive(inner, alias_map)
        elif isinstance(table_expr, exp.Alias):
            inner = table_expr.this
            if isinstance(inner, exp.Table):
                name = inner.name
                if inner.db:
                    name = f'{inner.db}.{name}'
                alias_map[table_expr.alias.upper()] = name
            elif isinstance(inner, (exp.Subquery, exp.Select)):
                source_tables = self._extract_subquery_source_tables(inner)
                if source_tables:
                    alias_map[table_expr.alias.upper()] = source_tables[0]
                # Recurse into subquery
                select_inner = inner.this if isinstance(inner, exp.Subquery) else inner
                if isinstance(select_inner, (exp.Select, exp.Union)):
                    self._build_alias_map_recursive(select_inner, alias_map)

    def _extract_subquery_source_tables(self, subquery_expr: exp.Expression) -> List[str]:
        """
        Extract source table names from a subquery expression.
        Prioritises the FROM-clause source over JOINed tables so that
        the first element represents the primary data source.

        Args:
            subquery_expr: Subquery or Select expression

        Returns:
            List of source table names found in the subquery
        """
        select_expr = subquery_expr
        if isinstance(subquery_expr, exp.Subquery):
            select_expr = subquery_expr.this
        if select_expr is None:
            return []

        # For UNION, recurse into the first branch
        if isinstance(select_expr, exp.Union):
            branches = []
            node = select_expr
            while isinstance(node, exp.Union):
                branches.append(node.this)
                node = node.expression
            branches.append(node)
            if branches:
                return self._extract_subquery_source_tables(branches[0])
            # fallback
            tables = []
            for table in select_expr.find_all(exp.Table):
                name = table.name
                if table.db:
                    name = f'{table.db}.{name}'
                if name and name not in tables:
                    tables.append(name)
            return tables

        # For SELECT, prioritise FROM clause source
        if isinstance(select_expr, exp.Select):
            from_clause = select_expr.args.get('from') or select_expr.args.get('from_')
            if from_clause:
                from_source = from_clause.this
                if isinstance(from_source, exp.Table):
                    name = from_source.name
                    if from_source.db:
                        name = f'{from_source.db}.{name}'
                    if name:
                        return [name]
                elif isinstance(from_source, exp.Subquery):
                    # Recurse into FROM subquery
                    result = self._extract_subquery_source_tables(from_source)
                    if result:
                        return result

        # Fallback: collect all tables
        tables = []
        for table in select_expr.find_all(exp.Table):
            name = table.name
            if table.db:
                name = f'{table.db}.{name}'
            if name and name not in tables:
                tables.append(name)
        return tables

    def _find_enclosing_subquery_table(self, col: exp.Expression, root_expr: exp.Expression) -> Optional[str]:
        """
        Check if a Column node is inside a scalar subquery within root_expr.
        If so, resolve the column's table qualifier against the subquery's
        own FROM + JOIN tables.

        This handles expressions like:
            CASE WHEN ... THEN (SELECT GLS.col FROM GL1 INNER JOIN GLS ON ...)

        Where the Column 'GLS.col' should resolve to the GLS table, not GL1.

        Args:
            col: A Column expression node
            root_expr: The root expression we're tracing

        Returns:
            The resolved table name if inside a subquery, or None
        """
        # If the column IS the root expression, there's no enclosing subquery
        if col is root_expr:
            return None
        node = col.parent if hasattr(col, 'parent') else None
        while node is not None and node is not root_expr:
            if isinstance(node, exp.Subquery):
                inner = node.this if hasattr(node, 'this') else None
                if isinstance(inner, exp.Select):
                    # Build alias map from subquery's FROM + JOINs
                    sq_alias_map = {}  # alias_upper -> full_table_name
                    from_arg = inner.args.get('from_') or inner.args.get('from')
                    first_table = None
                    if from_arg and hasattr(from_arg, 'this'):
                        first_table = self._extract_table_name_and_alias(from_arg.this, sq_alias_map)
                    for join_node in (inner.args.get("joins") or []):
                        self._extract_table_name_and_alias(join_node.this, sq_alias_map)

                    # Resolve column's table qualifier against subquery alias map
                    col_qualifier = col.table if hasattr(col, 'table') and col.table else None
                    if col_qualifier:
                        resolved = sq_alias_map.get(col_qualifier.upper())
                        if resolved:
                            return resolved
                    # Fallback to FROM table
                    return first_table
                return None
            node = node.parent if hasattr(node, 'parent') else None
        return None

    def _extract_table_name_and_alias(self, table_expr: exp.Expression, alias_map: Dict[str, str]) -> Optional[str]:
        """
        Extract table name from a Table/Subquery expression and register
        its alias in alias_map.  Returns the full table name.
        """
        if isinstance(table_expr, exp.Table):
            tname = table_expr.name
            if hasattr(table_expr, 'db') and table_expr.db:
                tname = f'{table_expr.db}.{tname}'
            if hasattr(table_expr, 'alias') and table_expr.alias:
                alias_map[str(table_expr.alias).upper()] = tname
            # Also register by simple name
            alias_map[tname.split('.')[-1].upper()] = tname
            return tname
        if isinstance(table_expr, exp.Subquery):
            alias_str = table_expr.alias if hasattr(table_expr, 'alias') else None
            if alias_str:
                alias_map[str(alias_str).upper()] = str(alias_str)
                return str(alias_str)
        return None

    def _is_scalar_subquery_predicate_col(self, col: exp.Expression, root_expr: exp.Expression) -> bool:
        """
        Check if a column is inside a scalar subquery's predicate (ON/WHERE/JOIN)
        rather than its SELECT list.

        Columns in a scalar subquery's SELECT list are value sources that flow
        into the target.  Columns in ON/WHERE are just predicates and should not
        create separate lineage edges.

        Args:
            col: A Column expression node
            root_expr: The root expression being traced

        Returns:
            True if the column is a predicate column inside a scalar subquery
        """
        if col is root_expr:
            return False

        # Walk up from the column to find the nearest enclosing Subquery
        node = col.parent if hasattr(col, 'parent') else None
        enclosing_subquery = None
        while node is not None and node is not root_expr:
            if isinstance(node, exp.Subquery):
                enclosing_subquery = node
                break
            node = node.parent if hasattr(node, 'parent') else None

        if enclosing_subquery is None:
            return False  # Not inside a subquery at all

        # Found an enclosing subquery. Check if the column is in the SELECT list.
        inner = enclosing_subquery.this if hasattr(enclosing_subquery, 'this') else None
        if not isinstance(inner, exp.Select):
            return False

        # Check if col is a descendant of one of the SELECT expressions
        for sel_expr in (inner.expressions or []):
            if col is sel_expr:
                return False
            # Walk all descendants of this select expression
            for descendant in sel_expr.walk():
                if isinstance(descendant, tuple):
                    descendant = descendant[0]
                if descendant is col:
                    return False

        # The column is inside the subquery but NOT in its SELECT list
        # → it's a predicate column (FROM/ON/WHERE/JOIN)
        return True

    def _get_subquery_source_tables(self, ast: exp.Expression) -> List[str]:
        """
        Get source tables from subqueries in the FROM clause.

        This is used as a fallback for resolving orphaned aliases
        (e.g., Informatica PM_* aliases that reference undefined table aliases).

        Args:
            ast: Parsed AST

        Returns:
            List of source table names from subqueries
        """
        tables = []
        from_clause = ast.find(exp.From)
        if from_clause and from_clause.this:
            if isinstance(from_clause.this, exp.Subquery):
                tables.extend(self._extract_subquery_source_tables(from_clause.this))
        for join in ast.find_all(exp.Join):
            if join.this and isinstance(join.this, exp.Subquery):
                tables.extend(self._extract_subquery_source_tables(join.this))
        return tables

    def extract_lineage_for_column(self, sql: str, column_name: str) -> List[ColumnRef]:
        """
        Extract lineage for a specific output column.

        Args:
            sql: SQL string
            column_name: Output column name

        Returns:
            List of source ColumnRef objects
        """
        try:
            ast = sqlglot.parse_one(sql, read=self.dialect)
        except Exception:
            return []
        resolved_ctes = self.cte_resolver.resolve(ast)
        main_query = self._get_main_query(ast)
        if not main_query:
            return []
        if isinstance(main_query, exp.Select):
            for expr in main_query.expressions:
                col_name = None
                col_expr = expr
                if isinstance(expr, exp.Alias):
                    col_name = expr.alias
                    col_expr = expr.this
                elif isinstance(expr, exp.Column):
                    col_name = expr.name
                    col_expr = expr
                if col_name and col_name.upper() == column_name.upper():
                    return self._trace_column_sources(col_expr, resolved_ctes, ast)
        return []

    def get_all_source_tables(self, sql: str) -> List[str]:
        """
        Get all source tables from SQL.

        Args:
            sql: SQL string

        Returns:
            List of table names
        """
        try:
            ast = sqlglot.parse_one(sql, read=self.dialect)
        except Exception:
            return []
        tables = set()
        target = self._get_target_table(ast)
        for table in ast.find_all(exp.Table):
            name = table.name
            if table.db:
                name = f'{table.db}.{name}'
            if target and name == target:
                continue
            tables.add(name)
        return list(tables)

    def extract_lineage_with_dynamic_sql(self, sql: str) -> Tuple[LineageGraph, Dict[str, Any]]:
        """
        Extract lineage including dynamic SQL analysis.

        This method:
        1. Extracts lineage from the static SQL
        2. Detects and reconstructs dynamic SQL
        3. Extracts lineage from reconstructed dynamic SQL
        4. Merges all lineage into a combined graph

        Args:
            sql: SQL string (may contain dynamic SQL)

        Returns:
            Tuple of (combined LineageGraph, dynamic_sql_metadata dict)
        """
        try:
            from dynamic_sql import DynamicSQLAnalyzer, DynamicSQLLineageHelper
        except ImportError:
            return (self._extract_static_lineage(sql), {'has_dynamic_sql': False})
        analyzer = DynamicSQLAnalyzer(dialect=self.dialect)
        helper = DynamicSQLLineageHelper(analyzer)
        combined_graph = self._extract_static_lineage(sql)
        dynamic_result = analyzer.analyze(sql)
        if not dynamic_result.has_dynamic_sql():
            return (combined_graph, {'has_dynamic_sql': False})
        dynamic_sql_list = helper.get_lineage_sql(sql)
        for dynamic_sql in dynamic_sql_list:
            try:
                dynamic_graph = self._extract_static_lineage(dynamic_sql)
                combined_graph.merge(dynamic_graph)
            except Exception as e:
                pass
        metadata = helper.get_dynamic_sql_metadata(sql)
        metadata['expanded_statements'] = analyzer.get_expanded_statements(sql)
        return (combined_graph, metadata)

    def _replace_teradata_literal(self, match):
        """Replace Teradata literal syntax with CAST."""
        literal_value = match.group(2)
        type_spec = match.group(3)
        return f"CAST('{literal_value}' AS {type_spec})"

    def _replace_teradata_literal2(self, match):
        """Replace Teradata literal syntax with CAST (pattern 2)."""
        literal_value = match.group(1)
        type_spec = match.group(2)
        return f"CAST('{literal_value}' AS {type_spec})"

    def _normalize_teradata_literals(self, sql: str) -> str:
        """
        Convert Teradata-specific syntax to standard SQL format.

        Handles:
        - SEL -> SELECT (Teradata shorthand)
        - '9999-12-31' (DATE) -> CAST('9999-12-31' AS DATE)
        - '9999-12-31 11:59:59' (TIMESTAMP(0)) -> CAST('9999-12-31 11:59:59' AS TIMESTAMP(0))

        Args:
            sql: SQL string with potential Teradata syntax

        Returns:
            SQL string with normalized syntax
        """
        # Strip banner/header lines (e.g., ======... VIEW: name ======...)
        sql = re.sub(r'^[=]{3,}.*$', '', sql, flags=re.MULTILINE)
        sql = re.sub(r'^\s*VIEW:\s+.*$', '', sql, flags=re.MULTILINE)

        # Rejoin corrupted split-quoted tokens from copy-paste artifacts.
        # e.g., `1000000."` + newline + `"00)` → `1000000.00)`
        sql = re.sub(r'"\s*\n\s*"', '', sql)

        # Convert Teradata SEL shorthand to standard SELECT
        sql = re.sub(r'\bSEL\b(?!ECT)', 'SELECT', sql, flags=re.IGNORECASE)

        # Strip Teradata inline type annotations: `expr (DECIMAL(N,M))` → `expr`
        # Negative lookbehind preserves CAST(X AS DECIMAL(N,M)).
        sql = re.sub(
            r'(?<!\bAS)\s*\(DECIMAL\s*\(\s*\d+\s*,\s*\d+\s*\)\)',
            '',
            sql, flags=re.IGNORECASE
        )

        # Strip Teradata transaction markers (BT; / ET;) and COLLECT STATISTICS
        # that sometimes get appended to extracted statements and cause
        # SQLGlot to produce Block AST nodes instead of proper DML.
        sql = re.sub(r';\s*(?:BT|ET)\s*;', ';', sql, flags=re.IGNORECASE)
        sql = re.sub(r';\s*COLLECT\s+STATISTICS\b[^;]*;?', ';', sql, flags=re.IGNORECASE)
        # Strip trailing BT; / ET; at end of statement
        sql = re.sub(r';\s*(?:BT|ET)\s*;?\s*$', '', sql, flags=re.IGNORECASE)

        teradata_literal_pattern = re.compile("(\\('([^']+)'\\s*\\(([A-Z][A-Z0-9_]*(?:\\s*\\(\\s*\\d+\\s*\\))?)\\)\\))", re.IGNORECASE)
        sql = teradata_literal_pattern.sub(self._replace_teradata_literal, sql)
        teradata_literal_pattern2 = re.compile("'([^']+)'\\s*\\(([A-Z][A-Z0-9_]*(?:\\s*\\(\\s*\\d+\\s*\\))?)\\)", re.IGNORECASE)
        result = []
        last_end = 0
        for match in teradata_literal_pattern2.finditer(sql):
            start = match.start()
            prefix = sql[max(0, start - 5):start].upper()
            if 'CAST(' not in prefix and 'AS ' not in prefix:
                result.append(sql[last_end:start])
                result.append(self._replace_teradata_literal2(match))
                last_end = match.end()
        result.append(sql[last_end:])
        sql = ''.join(result) if result else sql
        return sql

    def _extract_join_conditions(self, query: exp.Expression, alias_map: Dict[str, str]) -> str:
        """Extract JOIN conditions from a query, resolving aliases to table names."""
        joins = []
        select_node = query
        if not isinstance(select_node, exp.Select):
            for node in query.walk():
                if isinstance(node, exp.Select):
                    select_node = node
                    break
        if not isinstance(select_node, exp.Select):
            return ""
        for join in (select_node.args.get("joins") or []):
            try:
                # Get join type
                join_type_parts = []
                if hasattr(join, 'side') and join.side:
                    join_type_parts.append(str(join.side).upper())
                if hasattr(join, 'kind') and join.kind:
                    join_type_parts.append(str(join.kind).upper())
                join_type_parts.append("JOIN")
                join_type = " ".join(join_type_parts)
                # Get join table
                join_table = ""
                if isinstance(join.this, exp.Table):
                    join_table = join.this.sql(dialect=self.dialect)
                elif isinstance(join.this, exp.Subquery):
                    join_table = "(subquery)"
                    if hasattr(join.this, 'alias') and join.this.alias:
                        join_table = f"(subquery) {join.this.alias}"
                else:
                    join_table = join.this.sql(dialect=self.dialect)[:100]
                # Get ON condition
                on_clause = join.args.get("on")
                on_text = on_clause.sql(dialect=self.dialect) if on_clause else ""
                # Resolve aliases in ON text
                if alias_map and on_text:
                    on_text = self._resolve_aliases_in_sql(on_text, alias_map)
                joins.append(f"{join_type} {join_table} ON {on_text}" if on_text else f"{join_type} {join_table}")
            except Exception:
                continue
        return "; ".join(joins)

    def _extract_where_conditions(self, query: exp.Expression) -> str:
        """Extract WHERE conditions from a query, including subqueries in FROM."""
        select_node = query
        if isinstance(query, exp.Union):
            # For UNION, collect WHERE from first branch
            branches = []
            node = query
            while isinstance(node, exp.Union):
                branches.append(node.this)
                node = node.expression
            branches.append(node)
            if branches:
                return self._extract_where_conditions(branches[0])
            return ""
        if not isinstance(select_node, exp.Select):
            for node in query.walk():
                if isinstance(node, exp.Select):
                    select_node = node
                    break
        if not isinstance(select_node, exp.Select):
            return ""
        # Check outer WHERE first
        where_clause = select_node.args.get('where')
        if where_clause and hasattr(where_clause, 'this') and where_clause.this:
            return where_clause.this.sql(dialect=self.dialect)
        # If no outer WHERE, look inside FROM subqueries
        from_arg = select_node.args.get('from') or select_node.args.get('from_')
        if from_arg:
            from_source = from_arg.this
            if isinstance(from_source, exp.Subquery) and from_source.this:
                return self._extract_where_conditions(from_source.this)
        return ""

    def _resolve_aliases_in_sql(self, sql_text: str, alias_map: Dict[str, str]) -> str:
        """
        Replace table aliases in SQL text with actual table names.
        E.g., 'B.PCO_LTD' becomes 'HLC_MAIN.PCO_LTD' if B maps to HLC_MAIN.

        Skips alias resolution when it would destroy semantic distinctions:
        - Variant A: Multiple aliases for the same table (e.g., GM and GP both
          alias LKLPSGLSTAGE — resolving both to the physical name makes
          GM.col <> GP.col evaluate to FALSE).
        - Variant B: Same alias maps to different tables across scopes (e.g.,
          GL1 = CATGRY1 in one CASE branch, GL1 = CATGRY3 in another —
          resolving to the last table seen is wrong for earlier branches).

        Args:
            sql_text: SQL expression text
            alias_map: Alias map (uppercase keys -> uppercase values)

        Returns:
            SQL text with aliases resolved (preserving ambiguous aliases)
        """
        if not alias_map or not sql_text:
            return sql_text

        # Detect Variant A: multiple aliases → same physical table
        # Build reverse map: table -> [aliases that differ from the table name]
        reverse_map = {}
        for alias_key, table_name in alias_map.items():
            if alias_key == table_name:
                continue
            reverse_map.setdefault(table_name, []).append(alias_key)
        multi_alias_tables = set()
        for table_name, aliases in reverse_map.items():
            if len(aliases) > 1:
                multi_alias_tables.update(a.upper() for a in aliases)

        # Combine with Variant B conflicts (same alias → different tables)
        skip_aliases = multi_alias_tables | self._alias_conflicts

        result = sql_text
        for alias_key, table_name in alias_map.items():
            # Skip if alias is same as table name (no resolution needed)
            if alias_key == table_name:
                continue
            # Skip ambiguous aliases to preserve semantic distinctions
            if alias_key.upper() in skip_aliases:
                continue
            # Only replace short aliases (1-2 chars) or known wrapper aliases
            # to avoid replacing legitimate identifiers
            if len(alias_key) <= 3 or alias_key in ('CNSL', 'CHF', 'CHF_THIMONTH', 'PREV_PCO'):
                pattern = re.compile(r'\b' + re.escape(alias_key) + r'\.', re.IGNORECASE)
                result = pattern.sub(table_name + '.', result)
        return result

    def _extract_static_lineage(self, sql: str) -> LineageGraph:
        """
            Extract lineage from static SQL.

            Args:
                sql: SQL string

            Returns:
                LineageGraph with lineage edges
            """
        graph = LineageGraph()
        try:
            normalized_sql = self._normalize_teradata_literals(sql)
            ast = sqlglot.parse_one(normalized_sql, read=self.dialect)
            target_table = self._get_target_table(ast)
            resolved_ctes = self.cte_resolver.resolve(ast)
            insert_columns = self._get_insert_columns(ast)
            # Detect DML operation type
            dml_operation = ""
            if isinstance(ast, exp.Insert):
                dml_operation = "INSERT"
            elif isinstance(ast, exp.Create):
                create_kind = ast.args.get('kind', '')
                if str(create_kind).upper() == 'VIEW':
                    dml_operation = "CREATE VIEW"
                else:
                    dml_operation = "CREATE VOLATILE TABLE AS SELECT"
            elif isinstance(ast, exp.Update):
                dml_operation = "UPDATE"
            elif isinstance(ast, exp.Delete):
                dml_operation = "DELETE"
            elif isinstance(ast, exp.Select) and ast.args.get('into'):
                dml_operation = "SELECT INTO"
                # Use INTO variable names as target column names
                into_node = ast.args.get('into')
                if into_node and not insert_columns:
                    into_vars = [tbl.name for tbl in into_node.find_all(exp.Table) if hasattr(tbl, 'name')]
                    if into_vars:
                        insert_columns = into_vars

            # For DELETE statements, create a single self-referencing edge
            # (target.* -> target.*) with WHERE conditions as filter metadata.
            # The WHERE subquery is a filter, not a lineage source.
            if dml_operation == "DELETE" and target_table:
                where_conditions = ""
                where_clause = ast.args.get('where')
                if where_clause and hasattr(where_clause, 'this') and where_clause.this:
                    try:
                        where_conditions = where_clause.this.sql(dialect=self.dialect)
                    except Exception:
                        where_conditions = str(where_clause.this)
                source_ref = ColumnRef(table_name=target_table, column_name='*')
                target_ref = ColumnRef(table_name=target_table, column_name='*')
                transform = TransformationInfo(
                    type='DELETE',
                    subtype='DELETE ALL' if not where_conditions else 'DELETE WHERE',
                    description=f'Delete from {target_table}',
                    sql_expression=ast.sql(dialect=self.dialect),
                    source_columns=[],
                    complexity_score=1
                )
                edge = LineageEdge(
                    source=source_ref, target=target_ref,
                    transformation=transform,
                    dml_operation=dml_operation,
                    where_conditions=where_conditions
                )
                graph.add_edge(edge)
                return graph

            # For UPDATE statements, extract SET clause column mappings
            # instead of treating the FROM subquery as the lineage source.
            if dml_operation == "UPDATE" and target_table:
                set_expressions = ast.args.get('expressions') or []
                if set_expressions:
                    # Build alias map from the UPDATE's FROM clause and full AST
                    from_clause = ast.args.get('from_')
                    update_alias_map = {}
                    if from_clause:
                        update_alias_map = self._build_alias_map(ast)
                    if self.prebuilt_alias_map:
                        for k, v in self.prebuilt_alias_map.items():
                            if k not in update_alias_map:
                                update_alias_map[k] = v

                    # Extract WHERE conditions for metadata
                    where_conditions = ""
                    where_clause = ast.args.get('where')
                    if where_clause and hasattr(where_clause, 'this') and where_clause.this:
                        try:
                            where_conditions = where_clause.this.sql(dialect=self.dialect)
                        except Exception:
                            where_conditions = str(where_clause.this)

                    # Extract JOIN conditions from FROM clause
                    join_conditions = ""
                    if from_clause:
                        try:
                            join_conditions = self._extract_join_conditions(ast, update_alias_map)
                        except Exception:
                            pass

                    seen_edges = set()
                    for eq_expr in set_expressions:
                        if not isinstance(eq_expr, exp.EQ):
                            continue
                        left = eq_expr.this  # target column
                        right = eq_expr.expression  # source expression

                        # Get target column name
                        target_col_name = left.name if isinstance(left, exp.Column) else left.sql(dialect=self.dialect)

                        # Classify the source expression
                        transform_info = self.classifier.classify(right, target_col_name)
                        transformation_sql = right.sql(dialect=self.dialect) if right else target_col_name

                        # Trace source columns from the right side
                        sources = self._trace_column_sources(right, resolved_ctes, ast, update_alias_map)

                        # Resolve unqualified source columns: in UPDATE context,
                        # columns with no table or with an alias not in the FROM
                        # clause are from the target table itself.
                        from_aliases = set(k.upper() for k in update_alias_map.keys())
                        from_tables = set(v.upper() for v in update_alias_map.values())
                        resolved_sources = []
                        for source in sources:
                            src_tbl = (source.table_name or "").upper()
                            if not src_tbl or (src_tbl not in from_aliases
                                               and src_tbl not in from_tables
                                               and src_tbl != target_table.upper()):
                                # Unresolved alias — belongs to target table
                                resolved_sources.append(ColumnRef(
                                    table_name=target_table,
                                    column_name=source.column_name
                                ))
                            else:
                                resolved_sources.append(source)

                        if resolved_sources:
                            for source in resolved_sources:
                                target_ref = ColumnRef(table_name=target_table, column_name=target_col_name)
                                edge_key = (
                                    source.table_name.upper() if source.table_name else '',
                                    source.column_name.upper(),
                                    target_ref.table_name.upper(),
                                    target_ref.column_name.upper()
                                )
                                if edge_key not in seen_edges:
                                    seen_edges.add(edge_key)
                                    # Determine subquery alias
                                    _subquery_alias = ""
                                    src_tbl_upper = source.table_name.upper() if source.table_name else ''
                                    if src_tbl_upper and src_tbl_upper in update_alias_map:
                                        _subquery_alias = src_tbl_upper

                                    edge = LineageEdge(
                                        source=source, target=target_ref,
                                        transformation=transform_info,
                                        dml_operation=dml_operation,
                                        join_conditions=join_conditions,
                                        where_conditions=where_conditions,
                                        subquery_alias=_subquery_alias
                                    )
                                    graph.add_edge(edge)
                        else:
                            # No traceable sources — self-referencing transform
                            target_ref = ColumnRef(table_name=target_table, column_name=target_col_name)
                            source_ref = ColumnRef(table_name=target_table, column_name=target_col_name)
                            edge_key = (source_ref.table_name.upper(), source_ref.column_name.upper(),
                                        target_ref.table_name.upper(), target_ref.column_name.upper())
                            if edge_key not in seen_edges:
                                seen_edges.add(edge_key)
                                edge = LineageEdge(
                                    source=source_ref, target=target_ref,
                                    transformation=transform_info,
                                    dml_operation=dml_operation,
                                    join_conditions=join_conditions,
                                    where_conditions=where_conditions
                                )
                                graph.add_edge(edge)
                    return graph

                # Fallback: simple UPDATE with no SET expressions parsed —
                # create a single self-referencing edge
                source_ref = ColumnRef(table_name=target_table, column_name='*')
                target_ref = ColumnRef(table_name=target_table, column_name='*')
                transform = TransformationInfo(
                    type='UPDATE', subtype='UPDATE',
                    description=f'Update {target_table}',
                    sql_expression=ast.sql(dialect=self.dialect),
                    source_columns=[], complexity_score=1
                )
                edge = LineageEdge(
                    source=source_ref, target=target_ref,
                    transformation=transform,
                    dml_operation=dml_operation
                )
                graph.add_edge(edge)
                return graph

            main_query = self._get_main_query(ast)
            if not main_query:
                return graph
            # Build alias map from main_query (after unwrapping) so aliases
            # are collected from the correct nesting level
            alias_map = self._build_alias_map(main_query)
            # Add wrapper subquery aliases (A, B) so wrapper-level
            # expressions can be traced through the main query context
            self._add_wrapper_aliases(ast, main_query, alias_map)
            if self.prebuilt_alias_map:
                for k, v in self.prebuilt_alias_map.items():
                    if k not in alias_map:
                        alias_map[k] = v
            # Detect derived table subqueries containing UNION/UNION ALL.
            # When FROM (SELECT ... UNION ALL SELECT ...) AS A, alias A maps to
            # only the first branch table. Build a map of alias -> all branch tables
            # so we can emit lineage edges for every UNION branch.
            union_alias_tables = {}  # alias_upper -> [table1, table2, ...]
            union_branch_where = {}  # alias_upper -> [branch1_where, branch2_where, ...]
            self._detect_union_derived_tables(main_query, union_alias_tables, union_branch_where)
            # Also check the INSERT-level AST (outer query) for derived tables
            if ast is not main_query:
                self._detect_union_derived_tables(ast, union_alias_tables, union_branch_where)

            # Collect transformations from wrapper levels (between INSERT's SELECT
            # and the unwrapped main_query) for columns like PCO_LTD that have
            # formulas at an intermediate level
            wrapper_transforms = self._collect_wrapper_transformations(ast, main_query)
            # Extract JOIN and WHERE conditions from the main query
            join_conditions = self._extract_join_conditions(main_query, alias_map)
            where_conditions = self._extract_where_conditions(main_query)
            # Build a reverse alias map: real_table -> [alias1, alias2, ...]
            reverse_alias_map = {}
            for alias_key, real_tbl in alias_map.items():
                real_upper = real_tbl.upper()
                if real_upper not in reverse_alias_map:
                    reverse_alias_map[real_upper] = []
                reverse_alias_map[real_upper].append(alias_key)
            seen_edges = set()
            if isinstance(main_query, exp.Union):
                # Detect UNION vs UNION ALL
                _union_type = "UNION ALL" if getattr(main_query, 'args', {}).get('distinct') is False else "UNION"
                # sqlglot: Union.args['distinct'] is False for UNION ALL, True/missing for UNION
                # More robust: check the SQL text
                try:
                    union_sql_upper = main_query.sql(dialect=self.dialect).upper()
                    if 'UNION ALL' in union_sql_upper:
                        _union_type = "UNION ALL"
                    else:
                        _union_type = "UNION"
                except Exception:
                    pass
                union_branches = self._flatten_union(main_query)
                first_branch = union_branches[0] if union_branches else None
                if first_branch and isinstance(first_branch, exp.Select):
                    output_columns = self._get_output_columns(first_branch, target_table, insert_columns, main_query)
                    for branch_idx, branch in enumerate(union_branches):
                        if not isinstance(branch, exp.Select):
                            continue
                        branch_alias_map = self._build_alias_map(branch)
                        for k, v in alias_map.items():
                            if k not in branch_alias_map:
                                branch_alias_map[k] = v
                        branch_columns = list(branch.expressions) if hasattr(branch, 'expressions') else []
                        for col_idx, (col_name, col_expr) in enumerate(output_columns):
                            if col_idx < len(branch_columns):
                                branch_expr = branch_columns[col_idx]
                                if isinstance(branch_expr, exp.Alias):
                                    branch_expr = branch_expr.this
                            else:
                                branch_expr = col_expr
                            sources = self._trace_column_sources(branch_expr, resolved_ctes, branch, branch_alias_map)
                            transform_info = self.classifier.classify(branch_expr, col_name)
                            transformation_sql = branch_expr.sql(dialect=self.dialect) if branch_expr else col_name
                            is_identity_hop = False
                            if transform_info.type == TransformationType.DIRECT:
                                if transformation_sql.upper().strip() == col_name.upper().strip():
                                    is_identity_hop = True
                                if '.' in transformation_sql:
                                    simple_col = transformation_sql.split('.')[-1].upper().strip()
                                    if simple_col == col_name.upper().strip():
                                        is_identity_hop = True
                            # Extract alias hints from the branch expression
                            _branch_alias_hints = set()
                            if branch_expr:
                                for _c in branch_expr.find_all(exp.Column):
                                    if hasattr(_c, 'table') and _c.table:
                                        _branch_alias_hints.add(_c.table.upper())
                            if sources:
                                for source in sources:
                                    source_tbl = source.table_name.upper() if source.table_name else ''
                                    target_tbl = (target_table or '').upper()
                                    same_table = source_tbl and target_tbl and source_tbl == target_tbl
                                    if is_identity_hop and same_table and source.column_name.upper() == col_name.upper() and dml_operation != "INSERT":
                                        continue
                                    target_ref = ColumnRef(table_name=target_table or '', column_name=col_name)
                                    # Detect subquery alias: prefer alias from expression AST
                                    # Only use aliases that originate from derived tables (exp.Subquery),
                                    # not regular table aliases (exp.Table like FROM schema.tbl MST).
                                    _subquery_alias = ""
                                    if source_tbl and source_tbl in reverse_alias_map:
                                        aliases = reverse_alias_map[source_tbl]
                                        # Exclude the table name itself and its simple (unqualified) form —
                                        # these are not real aliases, just auto-entries from _build_alias_map.
                                        _src_simple = source_tbl.split('.')[-1] if '.' in source_tbl else source_tbl
                                        short_aliases = [a for a in aliases if a != source_tbl and a != _src_simple and a in self._subquery_alias_keys]
                                        if len(short_aliases) > 1 and _branch_alias_hints:
                                            matching = [a for a in short_aliases if a in _branch_alias_hints]
                                            _subquery_alias = matching[0] if matching else short_aliases[0]
                                        else:
                                            _subquery_alias = short_aliases[0] if short_aliases else ""
                                    elif source_tbl and source_tbl in branch_alias_map:
                                        _subquery_alias = source_tbl
                                    edge_key = (source.table_name.upper() if source.table_name else '', source.column_name.upper(), target_ref.table_name.upper() if target_ref.table_name else '', target_ref.column_name.upper())
                                    if edge_key not in seen_edges:
                                        seen_edges.add(edge_key)
                                        edge = LineageEdge(source=source, target=target_ref, transformation=transform_info, dml_operation=dml_operation, join_conditions=join_conditions, where_conditions=where_conditions, subquery_alias=_subquery_alias, union_type=_union_type)
                                        graph.add_edge(edge)
                            elif not is_identity_hop:
                                target_ref = ColumnRef(table_name=target_table or '', column_name=col_name)
                                source_ref = ColumnRef(table_name='', column_name=col_name)
                                edge_key = ('', col_name.upper(), target_ref.table_name.upper() if target_ref.table_name else '', target_ref.column_name.upper())
                                if edge_key not in seen_edges:
                                    seen_edges.add(edge_key)
                                    edge = LineageEdge(source=source_ref, target=target_ref, transformation=transform_info, dml_operation=dml_operation, join_conditions=join_conditions, where_conditions=where_conditions, subquery_alias="", union_type=_union_type)
                                    graph.add_edge(edge)
            else:
                output_columns = self._get_output_columns(main_query, target_table, insert_columns, main_query)
                for col_name, col_expr in output_columns:
                    # Check if a wrapper level has a transformation for this column
                    # (e.g., PCO_LTD has a COALESCE formula at an intermediate level)
                    wrapper_expr = wrapper_transforms.get(col_name.upper()) if wrapper_transforms else None
                    if wrapper_expr:
                        # Use wrapper transformation for classification
                        transform_info = self.classifier.classify(wrapper_expr, col_name)
                        transformation_sql = wrapper_expr.sql(dialect=self.dialect)
                        # Resolve aliases in transformation text (e.g., B.PCO_LTD -> HLC_MAIN.PCO_LTD)
                        transformation_sql = self._resolve_aliases_in_sql(transformation_sql, alias_map)
                        transform_info.sql_expression = transformation_sql
                        # Trace sources from the wrapper expression through main_query context
                        wrapper_sources = self._trace_column_sources(wrapper_expr, resolved_ctes, main_query, alias_map)
                        # Also get the direct source from main_query level for this column
                        direct_sources = self._trace_column_sources(col_expr, resolved_ctes, main_query, alias_map)
                        # Merge: use wrapper sources (more complete) if available, else direct
                        sources = wrapper_sources if wrapper_sources else direct_sources
                    else:
                        sources = self._trace_column_sources(col_expr, resolved_ctes, main_query, alias_map)
                        transform_info = self.classifier.classify(col_expr, col_name)
                        transformation_sql = col_expr.sql(dialect=self.dialect) if col_expr else col_name
                        # Resolve aliases in transformation text
                        resolved_sql = self._resolve_aliases_in_sql(transformation_sql, alias_map)
                        if resolved_sql != transformation_sql:
                            transformation_sql = resolved_sql
                            transform_info.sql_expression = transformation_sql
                    is_identity_hop = False
                    if transform_info.type == TransformationType.DIRECT:
                        if transformation_sql.upper().strip() == col_name.upper().strip():
                            is_identity_hop = True
                        if '.' in transformation_sql:
                            simple_col = transformation_sql.split('.')[-1].upper().strip()
                            if simple_col == col_name.upper().strip():
                                is_identity_hop = True
                    # Extract original alias qualifiers from the column expression AST
                    # so we can assign correct subquery_alias when same table has multiple aliases
                    _expr_alias_hints = set()
                    _trace_expr = wrapper_expr if wrapper_expr else col_expr
                    if _trace_expr:
                        for _c in _trace_expr.find_all(exp.Column):
                            if hasattr(_c, 'table') and _c.table:
                                _expr_alias_hints.add(_c.table.upper())
                    if sources:
                        for source in sources:
                            # Only skip identity hops when source and target are the same table
                            source_tbl = source.table_name.upper() if source.table_name else ''
                            target_tbl = (target_table or '').upper()
                            same_table = source_tbl and target_tbl and source_tbl == target_tbl
                            if is_identity_hop and same_table and source.column_name.upper() == col_name.upper() and dml_operation != "INSERT":
                                continue
                            target_ref = ColumnRef(table_name=target_table or '', column_name=col_name)
                            # Detect subquery alias: prefer the alias that actually appears
                            # in the column expression. When same table has multiple aliases
                            # (e.g., GM and GP both alias LKLPSGLSTAGE), pick the one from
                            # the expression AST rather than the first in the list.
                            # Only use aliases that originate from derived tables (exp.Subquery),
                            # not regular table aliases (exp.Table like FROM schema.tbl MST).
                            _subquery_alias = ""
                            if source_tbl and source_tbl in reverse_alias_map:
                                aliases = reverse_alias_map[source_tbl]
                                # Exclude the table name itself and its simple (unqualified) form —
                                # these are not real aliases, just auto-entries from _build_alias_map.
                                _src_simple = source_tbl.split('.')[-1] if '.' in source_tbl else source_tbl
                                short_aliases = [a for a in aliases if a != source_tbl and a != _src_simple and a in self._subquery_alias_keys]
                                if len(short_aliases) > 1 and _expr_alias_hints:
                                    # Multiple aliases for same table — pick the one from the expression
                                    matching = [a for a in short_aliases if a in _expr_alias_hints]
                                    _subquery_alias = matching[0] if matching else short_aliases[0]
                                else:
                                    _subquery_alias = short_aliases[0] if short_aliases else ""
                            elif source_tbl and source_tbl in alias_map:
                                _subquery_alias = source_tbl
                            edge_key = (source.table_name.upper() if source.table_name else '', source.column_name.upper(), target_ref.table_name.upper() if target_ref.table_name else '', target_ref.column_name.upper())
                            if edge_key not in seen_edges:
                                seen_edges.add(edge_key)
                                edge = LineageEdge(source=source, target=target_ref, transformation=transform_info, dml_operation=dml_operation, join_conditions=join_conditions, where_conditions=where_conditions, subquery_alias=_subquery_alias)
                                graph.add_edge(edge)
                    elif not is_identity_hop:
                        target_ref = ColumnRef(table_name=target_table or '', column_name=col_name)
                        source_ref = ColumnRef(table_name='', column_name=col_name)
                        edge_key = ('', col_name.upper(), target_ref.table_name.upper() if target_ref.table_name else '', target_ref.column_name.upper())
                        if edge_key not in seen_edges:
                            seen_edges.add(edge_key)
                            edge = LineageEdge(source=source_ref, target=target_ref, transformation=transform_info, dml_operation=dml_operation, join_conditions=join_conditions, where_conditions=where_conditions)
                            graph.add_edge(edge)

            # Duplicate edges for UNION-derived table aliases.
            # If alias A mapped to table1 (first branch) but the derived table
            # is UNION ALL of table1 and table2, create matching edges for table2.
            # Each branch gets its own correct join/where conditions.
            if union_alias_tables:
                extra_edges = []
                for existing_edge in list(graph.edges):
                    src_upper = existing_edge.source.table_name.upper() if existing_edge.source.table_name else ''
                    # Check if this source table is the first branch of a UNION alias
                    for alias_key, branch_tables in union_alias_tables.items():
                        if not branch_tables or len(branch_tables) < 2:
                            continue
                        primary_table = branch_tables[0].upper()
                        if src_upper == primary_table:
                            # Get per-branch WHERE conditions if available
                            branch_wheres = union_branch_where.get(alias_key, [])
                            # Create edges for all other branches
                            for branch_offset, other_table in enumerate(branch_tables[1:], start=1):
                                ek = (other_table.upper(), existing_edge.source.column_name.upper(),
                                      existing_edge.target.table_name.upper() if existing_edge.target.table_name else '',
                                      existing_edge.target.column_name.upper())
                                if ek not in seen_edges:
                                    seen_edges.add(ek)
                                    new_source = ColumnRef(
                                        table_name=other_table,
                                        column_name=existing_edge.source.column_name
                                    )
                                    union_type = getattr(existing_edge, 'union_type', '') or 'UNION ALL'
                                    # Update transformation SQL to reference the new table
                                    orig_transform = existing_edge.transformation
                                    new_sql = orig_transform.sql_expression
                                    if primary_table and new_sql:
                                        new_sql = re.sub(
                                            re.escape(primary_table), other_table.upper(),
                                            new_sql, flags=re.IGNORECASE
                                        )
                                    new_src_cols = []
                                    for sc in orig_transform.source_columns:
                                        if sc.table_name and sc.table_name.upper() == primary_table:
                                            new_src_cols.append(ColumnRef(table_name=other_table, column_name=sc.column_name))
                                        else:
                                            new_src_cols.append(sc)
                                    new_transform = TransformationInfo(
                                        type=orig_transform.type,
                                        subtype=orig_transform.subtype,
                                        description=orig_transform.description,
                                        sql_expression=new_sql,
                                        source_columns=new_src_cols,
                                        complexity_score=orig_transform.complexity_score
                                    )
                                    # Update join conditions: replace primary table
                                    # name with this branch's table name
                                    new_join = existing_edge.join_conditions
                                    if primary_table and new_join:
                                        new_join = re.sub(
                                            re.escape(primary_table), other_table.upper(),
                                            new_join, flags=re.IGNORECASE
                                        )
                                    # Use branch-specific WHERE conditions if available,
                                    # otherwise fall back to replacing table name in existing
                                    if branch_wheres and branch_offset < len(branch_wheres):
                                        new_where = branch_wheres[branch_offset]
                                    else:
                                        new_where = existing_edge.where_conditions
                                        if primary_table and new_where:
                                            new_where = re.sub(
                                                re.escape(primary_table), other_table.upper(),
                                                new_where, flags=re.IGNORECASE
                                            )
                                    new_edge = LineageEdge(
                                        source=new_source,
                                        target=existing_edge.target,
                                        transformation=new_transform,
                                        dml_operation=existing_edge.dml_operation,
                                        join_conditions=new_join,
                                        where_conditions=new_where,
                                        subquery_alias=alias_key,
                                        union_type=union_type
                                    )
                                    extra_edges.append(new_edge)
                for extra in extra_edges:
                    graph.add_edge(extra)

            # Capture JOIN tables that contributed no column-level edges.
            # These tables still participate in the data flow (e.g., an INNER JOIN
            # restricts which rows are selected) and should appear as sources.
            if target_table and (isinstance(main_query, exp.Select) or isinstance(ast, exp.Insert)):
                edge_source_tables = {
                    e.source.table_name.upper()
                    for e in graph.edges
                    if e.source.table_name
                }
                query_for_joins = main_query if isinstance(main_query, exp.Select) else ast
                for join_node in query_for_joins.find_all(exp.Join):
                    join_tbl_expr = join_node.this
                    # Collect table names from this JOIN expression.
                    # Direct table references yield one name; derived tables
                    # (subqueries) yield all real tables inside the subquery.
                    join_table_names = []
                    if isinstance(join_tbl_expr, exp.Table):
                        jt_name = join_tbl_expr.name
                        if hasattr(join_tbl_expr, 'db') and join_tbl_expr.db:
                            jt_name = f'{join_tbl_expr.db}.{jt_name}'
                        join_table_names.append(jt_name)
                    elif isinstance(join_tbl_expr, exp.Alias) and isinstance(join_tbl_expr.this, exp.Table):
                        tbl = join_tbl_expr.this
                        jt_name = tbl.name
                        if hasattr(tbl, 'db') and tbl.db:
                            jt_name = f'{tbl.db}.{tbl.name}'
                        join_table_names.append(jt_name)
                    else:
                        # Derived table / subquery in JOIN — extract real tables inside
                        inner = join_tbl_expr
                        if isinstance(inner, exp.Alias):
                            inner = inner.this
                        if isinstance(inner, (exp.Subquery, exp.Select)):
                            for tbl in inner.find_all(exp.Table):
                                tname = tbl.name
                                if hasattr(tbl, 'db') and tbl.db:
                                    tname = f'{tbl.db}.{tname}'
                                if tname:
                                    join_table_names.append(tname)
                    for jt_name in join_table_names:
                        jt_upper = jt_name.upper()
                        # Also check via alias resolution
                        resolved = alias_map.get(jt_upper, jt_upper)
                        if resolved not in edge_source_tables and jt_upper not in edge_source_tables:
                            edge_key = (jt_upper, '*', (target_table or '').upper(), '*')
                            if edge_key not in seen_edges:
                                seen_edges.add(edge_key)
                                source_ref = ColumnRef(table_name=jt_name, column_name='*')
                                target_ref = ColumnRef(table_name=target_table, column_name='*')
                                transform = TransformationInfo(
                                    type=TransformationType.INDIRECT, subtype=TransformationSubtype.JOIN,
                                    description=f'{jt_name} participates via JOIN condition',
                                    sql_expression=join_conditions,
                                    source_columns=[], complexity_score=1
                                )
                                edge = LineageEdge(
                                    source=source_ref, target=target_ref,
                                    transformation=transform,
                                    dml_operation=dml_operation,
                                    join_conditions=join_conditions,
                                    where_conditions=where_conditions
                                )
                                graph.add_edge(edge)

            # Also capture tables from derived subqueries in the main FROM clause
            # (not just JOINs but also nested subqueries in FROM).
            if target_table and main_query and isinstance(main_query, exp.Select):
                edge_source_tables = {
                    e.source.table_name.upper()
                    for e in graph.edges
                    if e.source.table_name
                }
                from_clause = main_query.args.get('from')
                if from_clause:
                    for sq in from_clause.find_all(exp.Subquery):
                        for tbl in sq.find_all(exp.Table):
                            tname = tbl.name
                            if hasattr(tbl, 'db') and tbl.db:
                                tname = f'{tbl.db}.{tname}'
                            if tname:
                                t_upper = tname.upper()
                                if t_upper not in edge_source_tables:
                                    edge_key = (t_upper, '*', (target_table or '').upper(), '*')
                                    if edge_key not in seen_edges:
                                        seen_edges.add(edge_key)
                                        source_ref = ColumnRef(table_name=tname, column_name='*')
                                        target_ref = ColumnRef(table_name=target_table, column_name='*')
                                        transform = TransformationInfo(
                                            type=TransformationType.INDIRECT, subtype=TransformationSubtype.JOIN,
                                            description=f'{tname} participates via derived subquery',
                                            sql_expression='',
                                            source_columns=[], complexity_score=1
                                        )
                                        edge = LineageEdge(
                                            source=source_ref, target=target_ref,
                                            transformation=transform,
                                            dml_operation=dml_operation,
                                            join_conditions=join_conditions,
                                            where_conditions=where_conditions
                                        )
                                        graph.add_edge(edge)

            # Capture tables from WHERE clause subqueries (filter sources).
            # These are tables referenced in patterns like:
            #   WHERE (SELECT col FROM table) BETWEEN ...
            #   AND col IN (SELECT col FROM table WHERE ...)
            # They don't contribute columns but control row filtering.
            if target_table and main_query:
                edge_source_tables = {
                    e.source.table_name.upper()
                    for e in graph.edges
                    if e.source.table_name
                }
                # Gather all WHERE clauses across the entire AST (including
                # those inside FROM-subqueries / derived tables / unions).
                where_nodes = list(ast.find_all(exp.Where))
                for where_node in where_nodes:
                    for sq in where_node.find_all(exp.Subquery):
                        for tbl in sq.find_all(exp.Table):
                            tname = tbl.name
                            if hasattr(tbl, 'db') and tbl.db:
                                tname = f'{tbl.db}.{tname}'
                            if tname:
                                t_upper = tname.upper()
                                if t_upper not in edge_source_tables:
                                    edge_key = (t_upper, '*', (target_table or '').upper(), '*')
                                    if edge_key not in seen_edges:
                                        seen_edges.add(edge_key)
                                        edge_source_tables.add(t_upper)
                                        source_ref = ColumnRef(table_name=tname, column_name='*')
                                        target_ref = ColumnRef(table_name=target_table, column_name='*')
                                        transform = TransformationInfo(
                                            type=TransformationType.INDIRECT, subtype=TransformationSubtype.FILTER,
                                            description=f'{tname} participates via WHERE subquery filter',
                                            sql_expression='',
                                            source_columns=[], complexity_score=1
                                        )
                                        edge = LineageEdge(
                                            source=source_ref, target=target_ref,
                                            transformation=transform,
                                            dml_operation=dml_operation,
                                            join_conditions=join_conditions,
                                            where_conditions=where_conditions
                                        )
                                        graph.add_edge(edge)

        except Exception as e:
            import logging
            logging.warning(f'Error extracting lineage: {e}')
        return graph

    def _flatten_union(self, union_expr: exp.Expression) -> List[exp.Expression]:
        """
        Flatten nested UNION expressions into a list of SELECT statements.
        
        Args:
            union_expr: Union expression
            
        Returns:
            List of SELECT expressions
        """
        parts = []
        if not isinstance(union_expr, exp.Union):
            if isinstance(union_expr, exp.Select):
                return [union_expr]
            return []
        if isinstance(union_expr.this, exp.Union):
            parts.extend(self._flatten_union(union_expr.this))
        elif isinstance(union_expr.this, exp.Select):
            parts.append(union_expr.this)
        if isinstance(union_expr.expression, exp.Union):
            parts.extend(self._flatten_union(union_expr.expression))
        elif isinstance(union_expr.expression, exp.Select):
            parts.append(union_expr.expression)
        return parts

    def _detect_union_derived_tables(self, query: exp.Expression, union_alias_tables: Dict[str, List[str]],
                                     union_branch_where: Dict[str, List[str]] = None) -> None:
        """
        Detect derived table subqueries that contain UNION/UNION ALL.
        Populates union_alias_tables with alias -> [branch_table1, branch_table2, ...].
        Optionally populates union_branch_where with alias -> [branch1_where, branch2_where, ...].

        For example, FROM (SELECT * FROM T1 WHERE x=1 UNION ALL SELECT * FROM T2 WHERE y=2) A
        produces: {'A': ['T1', 'T2']} and union_branch_where: {'A': ['x=1', 'y=2']}

        Args:
            query: AST to search
            union_alias_tables: Dict to populate with alias -> branch tables
            union_branch_where: Optional dict to populate with alias -> per-branch WHERE conditions
        """
        if query is None:
            return

        # Find Subquery nodes with aliases that contain UNION
        for subquery in query.find_all(exp.Subquery):
            alias = subquery.alias
            if not alias:
                continue
            alias_str = alias if isinstance(alias, str) else str(alias)
            inner = subquery.this
            if isinstance(inner, exp.Union):
                branches = self._flatten_union(inner)
                branch_tables = []
                branch_wheres = []
                for branch in branches:
                    if isinstance(branch, exp.Select):
                        # Get the primary FROM table of this branch
                        from_arg = branch.args.get('from_') or branch.args.get('from')
                        if from_arg:
                            table_node = from_arg.this
                            if isinstance(table_node, exp.Table):
                                tbl_name = table_node.name
                                if hasattr(table_node, 'db') and table_node.db:
                                    tbl_name = f'{table_node.db}.{tbl_name}'
                                if tbl_name:
                                    branch_tables.append(tbl_name)
                                    # Extract WHERE conditions for this branch
                                    branch_where = ""
                                    where_clause = branch.args.get('where')
                                    if where_clause and hasattr(where_clause, 'this') and where_clause.this:
                                        try:
                                            branch_where = where_clause.this.sql(dialect=self.dialect)
                                        except Exception:
                                            pass
                                    branch_wheres.append(branch_where)
                if len(branch_tables) >= 2:
                    union_alias_tables[alias_str.upper()] = branch_tables
                    if union_branch_where is not None:
                        union_branch_where[alias_str.upper()] = branch_wheres

    def _get_corresponding_expr_from_branch(self, branch: exp.Select, output_col: str, branch_idx: int, insert_columns: Optional[List[str]]) -> Optional[exp.Expression]:
        """
        Get the expression from a UNION branch that corresponds to a specific output column.
        
        Args:
            branch: SELECT expression from a UNION branch
            output_col: The output column name we're looking for
            branch_idx: Index of this branch in the UNION
            insert_columns: INSERT column names if available
            
        Returns:
            The corresponding expression or None
        """
        if not isinstance(branch, exp.Select):
            return None
        branch_exprs = list(branch.expressions)
        if insert_columns and output_col in insert_columns:
            col_idx = insert_columns.index(output_col)
            if col_idx < len(branch_exprs):
                return branch_exprs[col_idx]
        for idx, expr in enumerate(branch_exprs):
            expr_name = None
            if isinstance(expr, exp.Alias):
                expr_name = expr.alias
            elif isinstance(expr, exp.Column):
                expr_name = expr.name
            if expr_name and expr_name.upper() == output_col.upper():
                return expr
        if insert_columns:
            try:
                col_idx = insert_columns.index(output_col)
                if col_idx < len(branch_exprs):
                    return branch_exprs[col_idx]
            except ValueError:
                pass
        return None

class DynamicSQLAwareExtractor(LineageExtractor):
    """
    Enhanced LineageExtractor with built-in dynamic SQL handling.

    Automatically detects and processes dynamic SQL patterns,
    providing comprehensive lineage that includes both static
    and dynamic SQL operations.
    """

    def __init__(self, schema: Dict[str, List[str]]=None, dialect: str='teradata'):
        """
        Initialize extractor.

        Args:
            schema: Optional schema dict {table_name: [column_names]}
            dialect: SQL dialect
        """
        super().__init__(schema, dialect)
        self.dynamic_sql_metadata: Dict[str, Any] = {}

    def extract_lineage(self, sql: str) -> LineageGraph:
        """
        Extract lineage with automatic dynamic SQL handling.

        Overrides parent method to include dynamic SQL analysis.

        Args:
            sql: SQL string

        Returns:
            LineageGraph with complete lineage (static + dynamic)
        """
        graph, metadata = self.extract_lineage_with_dynamic_sql(sql)
        self.dynamic_sql_metadata = metadata
        return graph

    def get_dynamic_sql_info(self) -> Dict[str, Any]:
        """
        Get information about dynamic SQL found in the last analysis.

        Returns:
            Dict with dynamic SQL metadata
        """
        return self.dynamic_sql_metadata

    def has_dynamic_sql(self) -> bool:
        """Check if last analyzed SQL contained dynamic SQL."""
        return self.dynamic_sql_metadata.get('has_dynamic_sql', False)

    def get_expanded_statements(self) -> List[Dict[str, Any]]:
        """Get list of expanded dynamic SQL statements."""
        return self.dynamic_sql_metadata.get('expanded_statements', [])

def extract_lineage(sql: str, dialect: str='teradata', schema: Dict[str, List[str]]=None) -> LineageGraph:
    """
    Convenience function to extract lineage from SQL.

    Args:
        sql: SQL string
        dialect: SQL dialect
        schema: Optional schema dict

    Returns:
        LineageGraph with complete lineage
    """
    extractor = LineageExtractor(schema=schema, dialect=dialect)
    return extractor.extract_lineage(sql)
