"""
Cross-File Lineage Stitcher module.

Stitches lineage across multiple SQL files to create end-to-end
data flow from ultimate sources to final targets.
"""

import sys
import os
from typing import Dict, List, Optional, Set, Tuple, Any
from dataclasses import dataclass, field
from enum import Enum
import networkx as nx

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from lineage.lineage_graph import LineageGraph
from models.data_models import ColumnRef, LineageEdge, TransformationInfo


class TableRole(Enum):
    """Classification of table role in the data pipeline."""
    SOURCE = "SOURCE"           # Ultimate data source (only read from, never written to)
    INTERMEDIATE = "INTERMEDIATE"  # Both read and written (staging tables)
    TARGET = "TARGET"           # Final destination (only written to)
    UNKNOWN = "UNKNOWN"


@dataclass
class TableInfo:
    """Information about a table in the pipeline."""
    table_name: str
    role: TableRole = TableRole.UNKNOWN
    written_by: List[str] = field(default_factory=list)  # Source files that write to this table
    read_by: List[str] = field(default_factory=list)     # Source files that read from this table
    columns: List[str] = field(default_factory=list)
    schema_name: Optional[str] = None

    def to_dict(self) -> Dict[str, Any]:
        return {
            "table_name": self.table_name,
            "role": self.role.value,
            "written_by": self.written_by,
            "read_by": self.read_by,
            "columns": self.columns,
            "schema_name": self.schema_name
        }


@dataclass
class EndToEndLineage:
    """Complete end-to-end lineage for a target column."""
    target_table: str
    target_column: str
    source_columns: List[ColumnRef] = field(default_factory=list)
    intermediate_hops: List[Dict[str, Any]] = field(default_factory=list)
    transformation_chain: List[str] = field(default_factory=list)
    confidence: float = 1.0

    def to_dict(self) -> Dict[str, Any]:
        return {
            "target_table": self.target_table,
            "target_column": self.target_column,
            "source_columns": [c.to_dict() for c in self.source_columns],
            "intermediate_hops": self.intermediate_hops,
            "transformation_chain": self.transformation_chain,
            "hop_count": len(self.intermediate_hops),
            "confidence": self.confidence
        }


class TableRegistry:
    """
    Registry for tracking tables and their roles in the data pipeline.

    Classifies tables as:
    - SOURCE: Tables that are only read from (never written to in any SQL file)
    - INTERMEDIATE: Tables that are both read and written
    - TARGET: Tables that are only written to (never read from in any SQL file)
    """

    def __init__(self):
        """Initialize the registry."""
        self._tables: Dict[str, TableInfo] = {}

    def register_write(self, table_name: str, source_file: str) -> None:
        """
        Register that a table is written to by a SQL file.

        Args:
            table_name: Table name
            source_file: File that writes to this table
        """
        key = self._normalize_name(table_name)

        if key not in self._tables:
            self._tables[key] = TableInfo(table_name=table_name)

        if source_file not in self._tables[key].written_by:
            self._tables[key].written_by.append(source_file)

        self._update_role(key)

    def register_read(self, table_name: str, source_file: str) -> None:
        """
        Register that a table is read from by a SQL file.

        Args:
            table_name: Table name
            source_file: File that reads from this table
        """
        key = self._normalize_name(table_name)

        if key not in self._tables:
            self._tables[key] = TableInfo(table_name=table_name)

        if source_file not in self._tables[key].read_by:
            self._tables[key].read_by.append(source_file)

        self._update_role(key)

    def register_columns(self, table_name: str, columns: List[str]) -> None:
        """Register column names for a table."""
        key = self._normalize_name(table_name)

        if key not in self._tables:
            self._tables[key] = TableInfo(table_name=table_name)

        self._tables[key].columns = columns

    def _update_role(self, key: str) -> None:
        """Update table role based on read/write status."""
        info = self._tables[key]

        if info.written_by and info.read_by:
            info.role = TableRole.INTERMEDIATE
        elif info.written_by and not info.read_by:
            info.role = TableRole.TARGET
        elif info.read_by and not info.written_by:
            info.role = TableRole.SOURCE
        else:
            info.role = TableRole.UNKNOWN

    def _normalize_name(self, name: str) -> str:
        """Normalize table name for lookup."""
        return name.upper().strip()

    def get_table(self, table_name: str) -> Optional[TableInfo]:
        """Get table info by name."""
        return self._tables.get(self._normalize_name(table_name))

    def get_role(self, table_name: str) -> TableRole:
        """Get table role."""
        info = self.get_table(table_name)
        return info.role if info else TableRole.UNKNOWN

    def get_source_tables(self) -> List[str]:
        """Get all source tables."""
        return [info.table_name for info in self._tables.values()
                if info.role == TableRole.SOURCE]

    def get_intermediate_tables(self) -> List[str]:
        """Get all intermediate tables."""
        return [info.table_name for info in self._tables.values()
                if info.role == TableRole.INTERMEDIATE]

    def get_target_tables(self) -> List[str]:
        """Get all target tables."""
        return [info.table_name for info in self._tables.values()
                if info.role == TableRole.TARGET]

    def get_all_tables(self) -> Dict[str, TableInfo]:
        """Get all registered tables."""
        return self._tables.copy()

    def to_dict(self) -> Dict[str, Any]:
        """Export registry to dictionary."""
        return {
            "tables": {k: v.to_dict() for k, v in self._tables.items()},
            "sources": self.get_source_tables(),
            "intermediates": self.get_intermediate_tables(),
            "targets": self.get_target_tables()
        }


class CrossFileLineageStitcher:
    """
    Stitches lineage across multiple files to create end-to-end data flow.

    Algorithm:
    1. Build table registry from all processed statements
    2. Build file dependency graph based on table relationships
    3. Topologically sort files for processing order
    4. Stitch lineage graphs by resolving intermediate table references
    5. Generate end-to-end lineage from ultimate sources to final targets
    """

    def __init__(self):
        """Initialize the stitcher."""
        self.table_registry = TableRegistry()
        self.file_lineage: Dict[str, LineageGraph] = {}
        self.file_order: List[str] = []
        self.stitched_graph = LineageGraph()
        self.end_to_end_lineage: Dict[str, List[EndToEndLineage]] = {}

    def add_file_lineage(self, source_file: str, lineage: LineageGraph,
                         target_table: Optional[str] = None,
                         source_tables: Optional[List[str]] = None) -> None:
        """
        Add lineage from a processed SQL file.

        Args:
            source_file: Source file name
            lineage: LineageGraph from the file
            target_table: Target table of the statement
            source_tables: Source tables of the statement
        """
        self.file_lineage[source_file] = lineage

        # Register tables
        if target_table:
            self.table_registry.register_write(target_table, source_file)

        if source_tables:
            for table in source_tables:
                self.table_registry.register_read(table, source_file)

        # Also extract tables from lineage edges
        for edge in lineage.edges:
            if edge.target.table_name:
                self.table_registry.register_write(edge.target.table_name, source_file)
            if edge.source.table_name and edge.source.table_name != "[HARDCODED]":
                self.table_registry.register_read(edge.source.table_name, source_file)

    def stitch_lineage(self) -> LineageGraph:
        """
        Stitch all file lineages into a unified end-to-end graph.

        Returns:
            Combined LineageGraph with end-to-end lineage
        """
        # Build file dependency graph
        file_deps = self._build_file_dependencies()

        # Topological sort for processing order
        self.file_order = self._topological_sort(file_deps)

        # Initialize stitched graph
        self.stitched_graph = LineageGraph()

        # Process files in dependency order
        for source_file in self.file_order:
            if source_file in self.file_lineage:
                self._stitch_file_lineage(source_file)

        # Generate end-to-end lineage for target tables
        self._generate_end_to_end_lineage()

        return self.stitched_graph

    def _build_file_dependencies(self) -> Dict[str, Set[str]]:
        """
        Build dependency graph between files.

        A file A depends on file B if:
        - B writes to a table that A reads from

        Returns:
            Dict mapping file to set of files it depends on
        """
        dependencies: Dict[str, Set[str]] = {f: set() for f in self.file_lineage.keys()}

        for table_name, info in self.table_registry.get_all_tables().items():
            # For each file that reads from this table
            for reader in info.read_by:
                # It depends on all files that write to this table
                for writer in info.written_by:
                    if reader != writer:
                        dependencies[reader].add(writer)

        return dependencies

    def _topological_sort(self, dependencies: Dict[str, Set[str]]) -> List[str]:
        """
        Topologically sort files based on dependencies.

        Args:
            dependencies: File dependency graph

        Returns:
            Sorted list of files (dependencies first)
        """
        # Build NetworkX graph
        G = nx.DiGraph()

        for file in dependencies.keys():
            G.add_node(file)

        for file, deps in dependencies.items():
            for dep in deps:
                G.add_edge(dep, file)  # dep -> file means dep must come first

        try:
            return list(nx.topological_sort(G))
        except nx.NetworkXUnfeasible:
            # Cycle detected - return original order with warning
            print("Warning: Circular dependency detected in file lineage")
            return list(dependencies.keys())

    def _stitch_file_lineage(self, source_file: str) -> None:
        """
        Stitch lineage from a single file into the combined graph.

        Resolves intermediate table references by linking to their sources.

        Args:
            source_file: Source file name
        """
        lineage = self.file_lineage[source_file]

        for edge in lineage.edges:
            # Check if source is an intermediate table
            source_table = edge.source.table_name
            source_role = self.table_registry.get_role(source_table)

            if source_role == TableRole.INTERMEDIATE:
                # Resolve to ultimate sources through the intermediate
                ultimate_sources = self._resolve_to_ultimate_sources(edge.source)

                for ultimate_source in ultimate_sources:
                    # Create new edge from ultimate source to target
                    self.stitched_graph.add_lineage(
                        ultimate_source,
                        edge.target,
                        edge.transformation
                    )
            else:
                # Direct source - add edge as-is
                self.stitched_graph.add_edge(edge)

    def _resolve_to_ultimate_sources(self, intermediate_col: ColumnRef) -> List[ColumnRef]:
        """
        Resolve an intermediate column to its ultimate source columns.

        Follows lineage backwards through intermediate tables until
        reaching ultimate source tables.

        Args:
            intermediate_col: Column in intermediate table

        Returns:
            List of ultimate source ColumnRefs
        """
        ultimate_sources = []
        visited = set()

        def trace_back(col_ref: ColumnRef, depth: int = 0) -> None:
            """Recursively trace column back to sources."""
            if depth > 10:  # Prevent infinite loops
                return

            col_key = col_ref.qualified_name()
            if col_key in visited:
                return
            visited.add(col_key)

            table_role = self.table_registry.get_role(col_ref.table_name)

            if table_role == TableRole.SOURCE:
                # Found ultimate source
                ultimate_sources.append(col_ref)
                return

            # Search through already-stitched lineage for sources
            sources = self.stitched_graph.get_sources(col_ref)

            if not sources:
                # Also check file lineages
                for file_lineage in self.file_lineage.values():
                    sources.extend(file_lineage.get_sources(col_ref))

            if not sources:
                # No further sources found - this might be an ultimate source
                ultimate_sources.append(col_ref)
                return

            # Continue tracing
            for source in sources:
                trace_back(source, depth + 1)

        trace_back(intermediate_col)
        return ultimate_sources

    def _generate_end_to_end_lineage(self) -> None:
        """Generate end-to-end lineage records for all target tables."""
        self.end_to_end_lineage = {}

        for target_table in self.table_registry.get_target_tables():
            target_lineages = []

            # Find all target columns for this table
            target_columns = set()
            for edge in self.stitched_graph.edges:
                if edge.target.table_name.upper() == target_table.upper():
                    target_columns.add(edge.target.column_name)

            # Build end-to-end lineage for each target column
            for target_col in target_columns:
                target_ref = ColumnRef(table_name=target_table, column_name=target_col)
                lineage = self._build_column_lineage(target_ref)
                if lineage:
                    target_lineages.append(lineage)

            self.end_to_end_lineage[target_table] = target_lineages

    def _build_column_lineage(self, target: ColumnRef) -> Optional[EndToEndLineage]:
        """
        Build end-to-end lineage for a single target column.

        Args:
            target: Target column reference

        Returns:
            EndToEndLineage or None
        """
        # Get all ultimate sources
        all_sources = self.stitched_graph.get_all_sources_recursive(target)

        # Filter to actual source tables
        source_refs = [
            src for src in all_sources
            if self.table_registry.get_role(src.table_name) == TableRole.SOURCE
        ]

        if not source_refs:
            # Use direct sources
            source_refs = self.stitched_graph.get_sources(target)

        # Build transformation chain
        transformation_chain = []
        for edge in self.stitched_graph.edges:
            if edge.target.qualified_name() == target.qualified_name():
                if edge.transformation.sql_expression:
                    transformation_chain.append(edge.transformation.sql_expression)

        return EndToEndLineage(
            target_table=target.table_name,
            target_column=target.column_name,
            source_columns=source_refs,
            transformation_chain=transformation_chain,
            confidence=1.0 if source_refs else 0.5
        )

    def get_end_to_end_lineage(self, target_table: str) -> List[EndToEndLineage]:
        """
        Get end-to-end lineage for a target table.

        Args:
            target_table: Target table name

        Returns:
            List of EndToEndLineage records
        """
        return self.end_to_end_lineage.get(target_table.upper(), [])

    def get_processing_order(self) -> List[str]:
        """Get the determined file processing order."""
        return self.file_order

    def get_table_summary(self) -> Dict[str, Any]:
        """Get summary of table classification."""
        return self.table_registry.to_dict()

    def export_stitched_lineage_csv(self, output_path: str) -> None:
        """
        Export stitched lineage to CSV.

        Args:
            output_path: Output file path
        """
        import csv

        rows = []
        for edge in self.stitched_graph.edges:
            rows.append({
                "Source_Table": edge.source.table_name,
                "Source_Column": edge.source.column_name,
                "Transformation": edge.transformation.sql_expression,
                "Target_Table": edge.target.table_name,
                "Target_Column": edge.target.column_name,
                "Transformation_Type": edge.transformation.type.value if edge.transformation.type else "",
                "Source_Role": self.table_registry.get_role(edge.source.table_name).value
            })

        with open(output_path, 'w', newline='', encoding='utf-8') as f:
            if rows:
                writer = csv.DictWriter(f, fieldnames=rows[0].keys())
                writer.writeheader()
                writer.writerows(rows)

    def export_end_to_end_csv(self, output_path: str) -> None:
        """
        Export end-to-end lineage to CSV.

        Args:
            output_path: Output file path
        """
        import csv

        rows = []
        for target_table, lineages in self.end_to_end_lineage.items():
            for lineage in lineages:
                source_tables = ", ".join(set(s.table_name for s in lineage.source_columns))
                source_columns = ", ".join(s.qualified_name() for s in lineage.source_columns)

                rows.append({
                    "Target_Table": lineage.target_table,
                    "Target_Column": lineage.target_column,
                    "Source_Tables": source_tables,
                    "Source_Columns": source_columns,
                    "Hop_Count": len(lineage.intermediate_hops),
                    "Transformations": " -> ".join(lineage.transformation_chain[:3]),
                    "Confidence": lineage.confidence
                })

        with open(output_path, 'w', newline='', encoding='utf-8') as f:
            if rows:
                writer = csv.DictWriter(f, fieldnames=rows[0].keys())
                writer.writeheader()
                writer.writerows(rows)
