"""
Volatile Table Handler Module.

Handles CREATE VOLATILE TABLE AS (SELECT ...) statements in stored procedures.
Provides enhanced lineage extraction with:
1. Per-statement DML operation tracking
2. Schema prefix preservation
3. Correct source column resolution
4. Join and WHERE condition extraction per volatile table
5. STTM (Source to Target Mapping) generation

This module addresses the 10 issues identified in lineage extraction:
1. Table Schema details - preserves schema prefixes
2. DML_Operation - tracks per statement operation
3. Source column mapping (e.g., CALENDAR_DATE -> CCAR_DATE)
4. Join conditions for volatile tables
5. WHERE conditions per volatile table
6. Hardcoded value source tracking
7. Column filtering (e.g., HLC_MAIN only 4 columns)
8. Volatile table specific metadata
9. STTM for each volatile table
10. Proper source tracking through volatile table chain
"""

import re
import sqlglot
from sqlglot import exp
from typing import Dict, List, Optional, Set, Tuple, Any
from dataclasses import dataclass, field
from enum import Enum


class DMLOperationType(Enum):
    """Types of DML operations."""
    CREATE_VOLATILE_TABLE = "CREATE VOLATILE TABLE AS SELECT"
    INSERT_INTO = "INSERT INTO"
    INSERT_SELECT = "INSERT SELECT"
    UPDATE = "UPDATE"
    DELETE = "DELETE"
    MERGE = "MERGE"
    CREATE_TABLE = "CREATE TABLE"
    CREATE_VIEW = "CREATE VIEW"
    UNKNOWN = "UNKNOWN"


@dataclass
class VolatileTableDefinition:
    """Definition of a volatile table extracted from stored procedure."""
    table_name: str
    dml_operation: DMLOperationType
    source_tables: List[str]  # With schema prefixes (all referenced tables)
    columns: List[str]  # Output column names
    column_mappings: Dict[str, str]  # target_col -> source_expression
    column_sources: Dict[str, str]  # target_col -> source_column (simple name)
    join_conditions: str
    where_conditions: str
    sttm: str  # Full SQL statement
    raw_select: str  # The SELECT portion
    depends_on: List[str]  # Other volatile tables this depends on
    from_tables: List[str] = field(default_factory=list)  # Only FROM/JOIN tables (not WHERE)
    column_union_sources: Dict[str, List[Tuple[str, str]]] = field(default_factory=dict)  # target_col -> [(source_table, source_col)] per UNION branch


@dataclass
class VolatileLineageEdge:
    """Lineage edge with volatile table metadata."""
    source_table: str  # With schema prefix
    source_column: str
    target_table: str  # Volatile table name
    target_column: str
    transformation: str
    dml_operation: str
    join_conditions: str
    where_conditions: str
    is_hardcoded: bool = False
    hardcoded_value: str = ""
    sttm: str = ""


class VolatileTableHandler:
    """
    Handler for volatile tables in stored procedures.
    
    Extracts volatile table definitions and provides enhanced lineage
    with per-table DML operations, join/where conditions, and STTM.
    """
    
    # Known schema prefixes for tables
    SCHEMA_PREFIXES = {
        'CCAR_CONSUMER_MODEL_COMBINED': 'P_CCARDM_01_E0',
        'SHAW_MAST_ILN_STG': 'P_EDW_STG_01_V0',
        'SHAW_MAST_LOC_STG': 'P_EDW_STG_01_V0',
        'SHAW_TRAN_ILN_STG': 'P_EDW_STG_01_V0',
        'SHAW_TRAN_LOC_STG': 'P_EDW_STG_01_V0',
        'CCAR_RECFI_DYNAMIC_CNSL': 'P_CCARDM_01_V0',
        'CCAR_HELOC_INTERNAL_CNSL': 'P_CCARDM_01_V0',
        'CCAR_DT': 'P_CCARDM_01_V0',
        'MDL_SHAW_CHARGEOFFREC': 'P_CCARDM_01_V0',
        'BUSINESSCALENDAR': 'SYS_CALENDAR',
    }
    
    def __init__(self, dialect: str = "teradata"):
        """
        Initialize the handler.
        
        Args:
            dialect: SQL dialect for parsing
        """
        self.dialect = dialect
        self.volatile_tables: Dict[str, VolatileTableDefinition] = {}
        self.processing_order: List[str] = []
    
    def add_schema_prefix(self, table_name: str) -> str:
        """
        Add schema prefix to a table name if known.
        
        Args:
            table_name: Table name (may or may not have schema)
            
        Returns:
            Table name with schema prefix
        """
        # Already has schema
        if '.' in table_name:
            return table_name
        
        # Check for known prefixes
        table_upper = table_name.upper()
        for base_name, prefix in self.SCHEMA_PREFIXES.items():
            if table_upper == base_name.upper():
                return f"{prefix}.{table_name}"
        
        # Check if it's a volatile table (no schema needed)
        if table_upper in self.volatile_tables:
            return table_name
        
        return table_name
    
    def extract_volatile_tables(self, sql: str) -> Dict[str, VolatileTableDefinition]:
        """
        Extract all volatile table definitions from a stored procedure.
        
        Args:
            sql: Stored procedure SQL content
            
        Returns:
            Dict mapping table names to their definitions
        """
        self.volatile_tables = {}
        self.processing_order = []
        
        # Remove comments
        sql = self._remove_comments(sql)
        
        # Extract CREATE VOLATILE TABLE statements
        self._extract_create_volatile_tables(sql)
        
        # Determine processing order based on dependencies
        self._resolve_dependencies()
        
        return self.volatile_tables
    
    def _remove_comments(self, sql: str) -> str:
        """Remove SQL comments."""
        # Remove single-line comments
        sql = re.sub(r'--[^\n]*', '', sql)
        # Remove multi-line comments
        sql = re.sub(r'/\*.*?\*/', '', sql, flags=re.DOTALL)
        return sql
    
    def _extract_create_volatile_tables(self, sql: str) -> None:
        """
        Extract CREATE VOLATILE TABLE AS (SELECT ...) statements.
        
        Args:
            sql: SQL content
        """
        # Pattern for CREATE VOLATILE TABLE
        pattern = re.compile(
            r'CREATE\s+(?:MULTISET\s+)?VOLATILE\s+(?:TABLE\s+)?([\w.#]+)\s+AS\s*\(',
            re.IGNORECASE | re.DOTALL
        )
        
        for match in pattern.finditer(sql):
            table_name = match.group(1).upper()
            start_paren = match.end() - 1
            
            # Find matching closing paren
            select_sql = self._extract_balanced_parens(sql, start_paren)
            if not select_sql:
                continue
            
            # Normalize SELECT
            select_sql = self._normalize_select(select_sql)
            
            # Parse the SELECT to extract metadata
            definition = self._parse_volatile_table_select(
                table_name, select_sql, match.group(0) + select_sql + ")"
            )
            
            if definition:
                self.volatile_tables[table_name] = definition
    
    def _extract_balanced_parens(self, sql: str, start_pos: int) -> Optional[str]:
        """
        Extract content between balanced parentheses.
        
        Args:
            sql: SQL content
            start_pos: Position of opening paren
            
        Returns:
            Content between parens or None
        """
        if start_pos >= len(sql) or sql[start_pos] != '(':
            return None
        
        paren_count = 1
        pos = start_pos + 1
        in_string = False
        string_char = None
        
        while pos < len(sql) and paren_count > 0:
            char = sql[pos]
            if in_string:
                if char == string_char:
                    in_string = False
                    string_char = None
            elif char in ("'", '"'):
                in_string = True
                string_char = char
            elif char == '(':
                paren_count += 1
            elif char == ')':
                paren_count -= 1
            pos += 1
        
        if paren_count != 0:
            return None
        
        return sql[start_pos + 1:pos - 1].strip()
    
    def _normalize_select(self, sql: str) -> str:
        """Normalize SELECT statement (convert SEL to SELECT)."""
        if re.match(r'\s*SEL\b', sql, re.IGNORECASE) and not re.match(r'\s*SELECT\b', sql, re.IGNORECASE):
            sql = re.sub(r'^\s*SEL\b', 'SELECT', sql, flags=re.IGNORECASE)
        return sql
    
    def _parse_volatile_table_select(
        self, table_name: str, select_sql: str, full_sql: str
    ) -> Optional[VolatileTableDefinition]:
        """
        Parse a SELECT statement to extract volatile table definition.
        
        Args:
            table_name: Name of the volatile table
            select_sql: The SELECT portion
            full_sql: Full CREATE VOLATILE TABLE statement
            
        Returns:
            VolatileTableDefinition or None
        """
        try:
            parsed = sqlglot.parse_one(select_sql, dialect=self.dialect)
            if not parsed:
                return None
            
            # Extract columns
            columns = []
            column_mappings = {}
            column_sources = {}
            
            # Build alias-to-source map to resolve references to earlier aliases
            alias_to_source = {}
            
            for select_expr in parsed.find_all(exp.Select):
                # Check if this is a SELECT * (need to expand from subquery)
                has_star = any(isinstance(col_expr, exp.Star) for col_expr in select_expr.expressions)
                
                if has_star:
                    # Handle SELECT * by extracting columns from subqueries
                    subquery_columns = self._extract_columns_from_subquery(select_expr)
                    for col_name, source_expr, source_col in subquery_columns:
                        col_name_upper = col_name.upper()
                        if col_name_upper not in columns:
                            columns.append(col_name_upper)
                            column_mappings[col_name_upper] = source_expr
                            column_sources[col_name_upper] = source_col
                    # If no columns found from subquery, try to get them from UNION branches
                    if not columns:
                        union_columns = self._extract_columns_from_union(parsed)
                        for col_name, source_expr, source_col in union_columns:
                            col_name_upper = col_name.upper()
                            if col_name_upper not in columns:
                                columns.append(col_name_upper)
                                column_mappings[col_name_upper] = source_expr
                                column_sources[col_name_upper] = source_col
                    break  # Only process first SELECT for SELECT *
                
                # First pass: build alias map from simple aliases
                for col_expr in select_expr.expressions:
                    if isinstance(col_expr, exp.Alias):
                        alias_name = col_expr.alias.upper() if col_expr.alias else None
                        if alias_name and hasattr(col_expr, 'this'):
                            if isinstance(col_expr.this, exp.Column):
                                # Simple alias: CALENDAR_DATE AS CCAR_DATE
                                alias_to_source[alias_name] = col_expr.this.name
                
                # Second pass: extract columns with alias resolution
                for col_expr in select_expr.expressions:
                    col_name, source_expr, source_col = self._extract_column_info(col_expr)
                    if col_name and col_name != '*':
                        col_name_upper = col_name.upper()
                        columns.append(col_name_upper)
                        column_mappings[col_name_upper] = source_expr
                        
                        # Resolve alias references in source_col
                        resolved_source_col = self._resolve_alias_references(source_col, alias_to_source)
                        column_sources[col_name_upper] = resolved_source_col
                break  # Only first SELECT
            
            # Extract all source tables (for dependency tracking)
            source_tables = []
            depends_on = []

            for table in parsed.find_all(exp.Table):
                table_name_full = self._get_full_table_name(table)
                table_name_upper = table_name_full.upper().split('.')[-1]

                # Check if it's another volatile table
                if table_name_upper in self.volatile_tables:
                    depends_on.append(table_name_upper)

                # Add with schema prefix
                source_tables.append(self.add_schema_prefix(table_name_full))

            # Extract only FROM/JOIN tables (not WHERE subquery tables)
            from_tables = self._extract_primary_from_tables(parsed)

            # Extract JOIN conditions (top-level only)
            join_conditions = self._extract_join_conditions(parsed)

            # Extract WHERE conditions (top-level only)
            where_conditions = self._extract_where_conditions(parsed)

            # Detect UNION and extract per-branch source tables
            column_union_sources: Dict[str, List[Tuple[str, str]]] = {}
            union_node = self._find_union_node(parsed)
            if union_node and columns:
                branches = self._flatten_union_branches(union_node)
                for branch in branches:
                    if not isinstance(branch, exp.Select):
                        continue
                    branch_alias_map = self._build_table_alias_map_from_select(branch)
                    branch_from_tables: List[str] = []
                    self._collect_from_tables(branch, branch_from_tables)
                    # Add schema prefixes to branch_from_tables
                    branch_from_tables = [self.add_schema_prefix(t) for t in branch_from_tables]
                    branch_exprs = list(branch.expressions) if hasattr(branch, 'expressions') else []

                    # Check if branch uses SELECT * — if so, attribute ALL columns
                    # to this branch's source tables (deepest real table)
                    has_star = any(
                        isinstance(e, exp.Star) or
                        (isinstance(e, exp.Column) and hasattr(e, 'this') and isinstance(e.this, exp.Star))
                        for e in branch_exprs
                    )
                    if has_star:
                        # Find the deepest real source table in this branch
                        deep_tables = self._extract_primary_from_tables(branch)
                        deep_tables = [self.add_schema_prefix(t) for t in deep_tables]
                        # Attribute all columns to each deep source table
                        for col_name in columns:
                            src_col = column_sources.get(col_name, col_name)
                            if col_name not in column_union_sources:
                                column_union_sources[col_name] = []
                            for dt in deep_tables:
                                entry = (dt, src_col)
                                if entry not in column_union_sources[col_name]:
                                    column_union_sources[col_name].append(entry)
                    else:
                        # Non-star branch: match columns by position
                        for idx, b_expr in enumerate(branch_exprs):
                            if idx < len(columns):
                                col_name = columns[idx]
                                src_table = self._extract_table_from_branch_expr(
                                    b_expr, branch_from_tables, branch_alias_map
                                )
                                src_col = self._extract_source_col_name(b_expr)
                                if col_name not in column_union_sources:
                                    column_union_sources[col_name] = []
                                entry = (src_table, src_col)
                                if entry not in column_union_sources[col_name]:
                                    column_union_sources[col_name].append(entry)

            return VolatileTableDefinition(
                table_name=table_name,
                dml_operation=DMLOperationType.CREATE_VOLATILE_TABLE,
                source_tables=source_tables,
                columns=columns,
                column_mappings=column_mappings,
                column_sources=column_sources,
                join_conditions=join_conditions,
                where_conditions=where_conditions,
                sttm=full_sql,
                raw_select=select_sql,
                depends_on=depends_on,
                from_tables=from_tables,
                column_union_sources=column_union_sources
            )
            
        except Exception as e:
            # Fallback to regex parsing
            return self._parse_volatile_table_regex(table_name, select_sql, full_sql)
    
    def _resolve_alias_references(self, source_col: str, alias_to_source: Dict[str, str]) -> str:
        """
        Resolve alias references in source column string.
        
        For example, if source_col is "CCAR_DATE, CCAR_DATE" and alias_to_source has
        {"CCAR_DATE": "CALENDAR_DATE"}, returns "CALENDAR_DATE, CALENDAR_DATE".
        
        Args:
            source_col: Comma-separated source columns that may contain alias references
            alias_to_source: Map of alias names to their actual source columns
            
        Returns:
            Resolved source column string
        """
        if not source_col or not alias_to_source:
            return source_col
        
        # Split by comma and resolve each part
        parts = [p.strip() for p in source_col.split(',')]
        resolved_parts = []
        
        for part in parts:
            part_upper = part.upper()
            if part_upper in alias_to_source:
                resolved_parts.append(alias_to_source[part_upper])
            else:
                resolved_parts.append(part)
        
        return ', '.join(resolved_parts)
    
    def _extract_columns_from_subquery(self, select_expr: exp.Expression) -> List[Tuple[str, str, str]]:
        """
        Extract columns from subqueries in a SELECT * statement.
        
        When we have SELECT * FROM (SELECT col1 AS alias1, col2 AS alias2 FROM ...),
        we need to extract the column definitions from the inner SELECT.
        
        Args:
            select_expr: The outer SELECT expression containing SELECT *
            
        Returns:
            List of tuples: (column_name, source_expression, source_column)
        """
        result = []
        
        try:
            # Find the FROM clause and look for subqueries
            from_clause = select_expr.find(exp.From)
            if not from_clause:
                return result
            
            # Look for subqueries in the FROM clause
            for subquery in from_clause.find_all(exp.Subquery):
                inner_select = subquery.find(exp.Select)
                if inner_select:
                    for col_expr in inner_select.expressions:
                        col_name, source_expr, source_col = self._extract_column_info(col_expr)
                        if col_name and col_name != '*':
                            result.append((col_name, source_expr, source_col))
                    if result:
                        return result  # Found columns from first subquery
            
            # Also check for derived tables (alias for subquery results)
            for table_alias in from_clause.find_all(exp.TableAlias):
                parent = table_alias.parent
                if isinstance(parent, exp.Subquery):
                    inner_select = parent.find(exp.Select)
                    if inner_select:
                        for col_expr in inner_select.expressions:
                            col_name, source_expr, source_col = self._extract_column_info(col_expr)
                            if col_name and col_name != '*':
                                result.append((col_name, source_expr, source_col))
                        if result:
                            return result
                            
        except Exception as e:
            pass  # Silently fail and return empty result
            
        return result
    
    def _extract_columns_from_union(self, parsed: exp.Expression) -> List[Tuple[str, str, str]]:
        """
        Extract columns from UNION/UNION ALL statements.
        
        When we have SELECT * FROM (SELECT ... UNION ALL SELECT ...),
        we need to extract columns from the first branch of the UNION.
        
        Args:
            parsed: The parsed SQL expression
            
        Returns:
            List of tuples: (column_name, source_expression, source_column)
        """
        result = []
        
        try:
            # Find UNION expressions
            for union_expr in parsed.find_all(exp.Union):
                # Get the left (first) branch of the UNION
                left = union_expr.left
                if isinstance(left, exp.Select):
                    for col_expr in left.expressions:
                        col_name, source_expr, source_col = self._extract_column_info(col_expr)
                        if col_name and col_name != '*':
                            result.append((col_name, source_expr, source_col))
                    if result:
                        return result
                # Check for nested subqueries in the left branch
                elif isinstance(left, exp.Subquery):
                    inner_select = left.find(exp.Select)
                    if inner_select:
                        for col_expr in inner_select.expressions:
                            col_name, source_expr, source_col = self._extract_column_info(col_expr)
                            if col_name and col_name != '*':
                                result.append((col_name, source_expr, source_col))
                        if result:
                            return result
                            
        except Exception as e:
            pass  # Silently fail and return empty result
            
        return result

    def _extract_column_info(self, col_expr: exp.Expression) -> Tuple[str, str, str]:
        """
        Extract column name, source expression, and source column from expression.
        
        Returns:
            (column_name, transformation_expression, source_column)
        """
        col_name = None
        source_expr = ""
        source_col = ""
        
        try:
            # Get the SQL representation
            source_expr = col_expr.sql(dialect=self.dialect)
            
            # Check for alias
            if isinstance(col_expr, exp.Alias):
                col_name = col_expr.alias
                # Get the underlying expression
                if hasattr(col_expr, 'this'):
                    if isinstance(col_expr.this, exp.Column):
                        source_col = col_expr.this.name
                    else:
                        # Extract actual source columns from complex expressions
                        source_col = self._extract_source_columns_from_expr(col_expr.this)
            elif hasattr(col_expr, 'alias') and col_expr.alias:
                col_name = col_expr.alias
                source_col = self._extract_source_columns_from_expr(col_expr)
            elif isinstance(col_expr, exp.Column):
                col_name = col_expr.name
                source_col = col_expr.name
            elif hasattr(col_expr, 'name'):
                col_name = col_expr.name
                source_col = col_expr.name
                
        except Exception:
            pass
        
        return (col_name, source_expr, source_col)
    
    def _extract_source_columns_from_expr(self, expr: exp.Expression) -> str:
        """
        Extract actual source column names from a complex expression.
        
        This handles expressions like:
        - EXTRACT(YEAR FROM CCAR_DATE) -> CCAR_DATE
        - ADD_MONTHS(CURRENT_DATE, -1) -> CURRENT_DATE
        - CALENDAR_DATE * 100 + MONTH_OF_YEAR -> CALENDAR_DATE, MONTH_OF_YEAR
        - COALESCE(A, B) -> A, B
        
        Returns:
            Comma-separated list of source column names, or the expression SQL if no columns found
        """
        if expr is None:
            return ""
        
        # Find all column references in the expression
        columns = []
        for col in expr.find_all(exp.Column):
            col_name = col.name
            if col_name and col_name.upper() not in [c.upper() for c in columns]:
                columns.append(col_name)
        
        # Also check for CURRENT_DATE, CURRENT_TIMESTAMP which are special
        expr_sql = expr.sql(dialect=self.dialect)
        if 'CURRENT_DATE' in expr_sql.upper() and 'CURRENT_DATE' not in [c.upper() for c in columns]:
            columns.append('CURRENT_DATE')
        if 'CURRENT_TIMESTAMP' in expr_sql.upper() and 'CURRENT_TIMESTAMP' not in [c.upper() for c in columns]:
            columns.append('CURRENT_TIMESTAMP')
        
        if columns:
            return ', '.join(columns)
        else:
            # No columns found - return expression (likely hardcoded)
            return expr_sql
    
    def _get_full_table_name(self, table: exp.Table) -> str:
        """Get full table name including schema."""
        name = table.name
        if hasattr(table, 'db') and table.db:
            name = f"{table.db}.{name}"
        return name
    
    def _extract_primary_from_tables(self, parsed: exp.Expression) -> List[str]:
        """
        Extract only FROM/JOIN source tables, not WHERE subquery tables.
        Recursively unwraps FROM subqueries to find real table names.
        For UNION queries, extracts FROM tables from each branch.

        Args:
            parsed: Parsed SQL expression

        Returns:
            List of primary FROM/JOIN table names with schema prefixes
        """
        from_tables = []

        if isinstance(parsed, exp.Union):
            # Process both UNION branches
            for branch in [parsed.this, parsed.expression]:
                if isinstance(branch, exp.Select):
                    self._collect_from_tables(branch, from_tables)
            # Also handle deeper UNION nesting
            if isinstance(parsed.this, exp.Union):
                from_tables.extend(self._extract_primary_from_tables(parsed.this))
        elif isinstance(parsed, exp.Select):
            self._collect_from_tables(parsed, from_tables)

        # Deduplicate while preserving order
        seen = set()
        unique = []
        for t in from_tables:
            t_upper = t.upper()
            if t_upper not in seen:
                seen.add(t_upper)
                unique.append(t)
        return unique

    def _collect_from_tables(self, select_node: exp.Select, from_tables: List[str]) -> None:
        """
        Collect tables from a SELECT's FROM and JOIN clauses.
        Recursively unwraps FROM subqueries to find real tables.

        Args:
            select_node: A SELECT expression
            from_tables: List to append table names to
        """
        # Process FROM clause
        from_arg = select_node.args.get('from_') or select_node.args.get('from')
        if from_arg and hasattr(from_arg, 'this'):
            self._unwrap_from_source(from_arg.this, from_tables)

        # Process JOIN clauses (only at this level, not nested)
        joins = select_node.args.get('joins') or []
        for join in joins:
            if hasattr(join, 'this') and join.this:
                self._unwrap_from_source(join.this, from_tables)

    def _unwrap_from_source(self, source: exp.Expression, from_tables: List[str]) -> None:
        """
        Unwrap a FROM source to find real table names.
        Handles Table, Subquery, and Alias wrapping.

        Args:
            source: FROM source expression
            from_tables: List to append table names to
        """
        if isinstance(source, exp.Table):
            name = self._get_full_table_name(source)
            if name:
                from_tables.append(self.add_schema_prefix(name))
        elif isinstance(source, exp.Subquery):
            inner = source.this
            if isinstance(inner, exp.Select):
                self._collect_from_tables(inner, from_tables)
            elif isinstance(inner, exp.Union):
                from_tables.extend(self._extract_primary_from_tables(inner))
        elif isinstance(source, exp.Alias):
            if hasattr(source, 'this'):
                self._unwrap_from_source(source.this, from_tables)

    def _extract_join_conditions(self, parsed: exp.Expression) -> str:
        """
        Extract JOIN conditions from the top-level SELECT only.
        Does not traverse into nested subqueries.
        """
        joins = []

        # Find the top-level SELECT
        select_node = parsed
        if isinstance(parsed, exp.Union):
            select_node = parsed.this  # Use first UNION branch
        if not isinstance(select_node, exp.Select):
            select_node = parsed.find(exp.Select)
        if not select_node:
            return ""

        # Only get JOINs at this level (not nested)
        join_list = select_node.args.get('joins') or []
        for join in join_list:
            # Build join type from both side (LEFT/RIGHT) and kind (OUTER/INNER)
            join_type_parts = []
            if hasattr(join, 'side') and join.side:
                join_type_parts.append(join.side.upper())
            if hasattr(join, 'kind') and join.kind:
                join_type_parts.append(join.kind.upper())
            join_type_parts.append("JOIN")
            join_type = " ".join(join_type_parts)

            # Get join table
            join_table = ""
            if hasattr(join, 'this') and join.this:
                if isinstance(join.this, exp.Table):
                    join_table = self._get_full_table_name(join.this)
                    if hasattr(join.this, 'alias') and join.this.alias:
                        join_table += f" {join.this.alias}"
                elif isinstance(join.this, exp.Subquery):
                    # Subquery JOIN — extract inner table names for readability
                    inner_tables = self._extract_primary_from_tables(join.this.this) if join.this.this else []
                    alias_str = ""
                    if hasattr(join.this, 'alias') and join.this.alias:
                        alias_str = f" {join.this.alias}" if isinstance(join.this.alias, str) else f" {str(join.this.alias)}"
                    if inner_tables:
                        join_table = f"({' UNION ALL '.join(inner_tables)}){alias_str}"
                    else:
                        join_table = f"(subquery){alias_str}"
                else:
                    join_table = join.this.sql(dialect=self.dialect)

            # Get ON condition
            on_condition = ""
            if hasattr(join, 'args'):
                on_expr = join.args.get('on')
                if on_expr:
                    on_condition = on_expr.sql(dialect=self.dialect)

            if join_table or on_condition:
                joins.append(f"{join_type} {join_table} ON {on_condition}")

        return " | ".join(joins)

    def _extract_where_conditions(self, parsed: exp.Expression) -> str:
        """
        Extract WHERE conditions from the top-level SELECT only.
        Does not traverse into nested subqueries.
        Does not include JOIN ON conditions.
        """
        # For UNION queries, the individual branches may have WHERE clauses
        # but the overall volatile table WHERE is on the wrapper SELECT (if any)
        if isinstance(parsed, exp.Union):
            # No top-level WHERE for bare UNION — the WHERE is on individual branches
            return ""

        select_node = parsed
        if not isinstance(select_node, exp.Select):
            # Try to find the outermost SELECT (not inside subqueries)
            select_node = parsed.find(exp.Select)
        if not select_node:
            return ""

        # Strictly use the WHERE clause from the args — this will NOT include
        # JOIN ON conditions because SQLGlot stores them separately in 'joins'
        where_clause = select_node.args.get('where')
        if where_clause and hasattr(where_clause, 'this') and where_clause.this:
            return where_clause.this.sql(dialect=self.dialect)
        return ""
    
    def _parse_volatile_table_regex(
        self, table_name: str, select_sql: str, full_sql: str
    ) -> Optional[VolatileTableDefinition]:
        """Fallback regex parsing for volatile table SELECT."""
        columns = []
        column_mappings = {}
        column_sources = {}
        source_tables = []
        
        # Extract column list from SELECT ... FROM
        select_match = re.search(r'SELECT\s+(.+?)\s+FROM\b', select_sql, re.IGNORECASE | re.DOTALL)
        if select_match:
            columns = self._parse_column_list_regex(select_match.group(1))
            for col in columns:
                column_mappings[col] = col
                column_sources[col] = col
        
        # Extract source tables from FROM clause
        from_match = re.search(r'\bFROM\s+(\S+)', select_sql, re.IGNORECASE)
        if from_match:
            source_tables.append(self.add_schema_prefix(from_match.group(1)))
        
        # Extract WHERE conditions
        where_match = re.search(r'\bWHERE\s+(.+?)(?:GROUP|ORDER|HAVING|$)', select_sql, re.IGNORECASE | re.DOTALL)
        where_conditions = where_match.group(1).strip() if where_match else ""
        
        # Extract JOIN conditions
        join_conditions = ""
        join_matches = re.findall(r'((?:INNER|LEFT|RIGHT|FULL|CROSS)?\s*JOIN\s+\S+\s+(?:AS\s+)?\w*\s+ON\s+[^)]+)', 
                                   select_sql, re.IGNORECASE)
        if join_matches:
            join_conditions = " | ".join(join_matches)
        
        return VolatileTableDefinition(
            table_name=table_name,
            dml_operation=DMLOperationType.CREATE_VOLATILE_TABLE,
            source_tables=source_tables,
            columns=columns,
            column_mappings=column_mappings,
            column_sources=column_sources,
            join_conditions=join_conditions,
            where_conditions=where_conditions,
            sttm=full_sql,
            raw_select=select_sql,
            depends_on=[]
        )
    
    def _parse_column_list_regex(self, column_str: str) -> List[str]:
        """Parse column list using regex."""
        columns = []
        parts = []
        current = ""
        paren_depth = 0
        
        for char in column_str:
            if char == '(':
                paren_depth += 1
            elif char == ')':
                paren_depth -= 1
            elif char == ',' and paren_depth == 0:
                parts.append(current.strip())
                current = ""
                continue
            current += char
        if current.strip():
            parts.append(current.strip())
        
        for part in parts:
            # Look for AS alias
            as_match = re.search(r'\bAS\s+(\w+)\s*$', part, re.IGNORECASE)
            if as_match:
                columns.append(as_match.group(1).upper())
            else:
                # Get last identifier
                ident_match = re.search(r'(?:[\w.]+\.)?(\w+)\s*$', part)
                if ident_match:
                    col_name = ident_match.group(1).upper()
                    if col_name not in ('DISTINCT', 'ALL'):
                        columns.append(col_name)
        
        return columns
    
    def _resolve_dependencies(self) -> None:
        """Resolve volatile table dependencies and determine processing order."""
        # Update dependencies now that all tables are parsed
        for table_name, definition in self.volatile_tables.items():
            depends_on = []
            for source in definition.source_tables:
                source_upper = source.upper().split('.')[-1]
                if source_upper in self.volatile_tables and source_upper != table_name:
                    depends_on.append(source_upper)
            definition.depends_on = depends_on
        
        # Topological sort
        visited = set()
        order = []
        
        def visit(name: str):
            if name in visited:
                return
            visited.add(name)
            if name in self.volatile_tables:
                for dep in self.volatile_tables[name].depends_on:
                    visit(dep)
            order.append(name)
        
        for name in self.volatile_tables:
            visit(name)
        
        self.processing_order = order

    def _find_union_node(self, parsed: exp.Expression) -> Optional[exp.Union]:
        """
        Find UNION node inside a parsed expression.
        Handles both direct UNION and SELECT * FROM (UNION) patterns.

        Args:
            parsed: Parsed SQL expression

        Returns:
            Union node or None
        """
        if isinstance(parsed, exp.Union):
            return parsed
        if isinstance(parsed, exp.Select):
            # Check if FROM clause contains a subquery with UNION
            from_arg = parsed.args.get('from_') or parsed.args.get('from')
            if from_arg and hasattr(from_arg, 'this'):
                source = from_arg.this
                if isinstance(source, exp.Subquery) and isinstance(source.this, exp.Union):
                    return source.this
                if isinstance(source, exp.Union):
                    return source
        return None

    def _flatten_union_branches(self, union_node: exp.Union) -> List[exp.Select]:
        """
        Flatten nested UNION ALL into a list of SELECT branches.

        Args:
            union_node: Union expression

        Returns:
            List of SELECT expressions (one per branch)
        """
        branches = []
        if isinstance(union_node.this, exp.Union):
            branches.extend(self._flatten_union_branches(union_node.this))
        elif isinstance(union_node.this, exp.Select):
            branches.append(union_node.this)
        if isinstance(union_node.expression, exp.Union):
            branches.extend(self._flatten_union_branches(union_node.expression))
        elif isinstance(union_node.expression, exp.Select):
            branches.append(union_node.expression)
        return branches

    def _build_table_alias_map_from_select(self, select_node: exp.Select) -> Dict[str, str]:
        """
        Build alias map from a single SELECT's FROM/JOIN clauses.

        Args:
            select_node: SELECT expression

        Returns:
            Dict mapping alias (uppercase) -> table name (uppercase)
        """
        alias_map: Dict[str, str] = {}
        if not isinstance(select_node, exp.Select):
            return alias_map
        # Process FROM clause
        from_arg = select_node.args.get('from_') or select_node.args.get('from')
        if from_arg and hasattr(from_arg, 'this'):
            self._collect_branch_aliases(from_arg.this, alias_map)
        # Process JOIN clauses
        joins = select_node.args.get('joins') or []
        for join in joins:
            if hasattr(join, 'this') and join.this:
                self._collect_branch_aliases(join.this, alias_map)
        return alias_map

    def _collect_branch_aliases(self, source: exp.Expression, alias_map: Dict[str, str]) -> None:
        """
        Collect table aliases from a FROM/JOIN source for a single branch.

        Args:
            source: Source expression
            alias_map: Dict to populate
        """
        if isinstance(source, exp.Table):
            table_name = self._get_full_table_name(source)
            table_upper = table_name.upper() if table_name else ""
            if hasattr(source, 'alias') and source.alias:
                alias_str = source.alias if isinstance(source.alias, str) else str(source.alias)
                if alias_str:
                    alias_map[alias_str.upper()] = table_upper
            # Map simple name to full name
            if table_upper:
                simple = table_upper.split('.')[-1] if '.' in table_upper else table_upper
                alias_map[simple] = table_upper
                alias_map[table_upper] = table_upper
        elif isinstance(source, exp.Subquery):
            if hasattr(source, 'alias') and source.alias:
                alias_str = source.alias if isinstance(source.alias, str) else str(source.alias)
                if alias_str and source.this:
                    inner_tables = self._extract_primary_from_tables(source.this)
                    if inner_tables:
                        alias_map[alias_str.upper()] = inner_tables[0].upper().split('.')[-1]
        elif isinstance(source, exp.Alias):
            if hasattr(source, 'this'):
                self._collect_branch_aliases(source.this, alias_map)

    def _extract_table_from_branch_expr(self, col_expr: exp.Expression,
                                         from_tables: List[str],
                                         alias_map: Dict[str, str]) -> str:
        """
        Extract source table from a column expression within a specific branch context.

        Args:
            col_expr: Column expression (may be Alias, Column, etc.)
            from_tables: FROM/JOIN tables for this branch
            alias_map: Alias map for this branch

        Returns:
            Source table name with schema prefix
        """
        # Unwrap alias
        inner = col_expr
        if isinstance(col_expr, exp.Alias):
            inner = col_expr.this

        # Find column references
        for col in inner.find_all(exp.Column):
            if col.table:
                qualifier = col.table.upper()
                # Resolve alias
                if qualifier in alias_map:
                    resolved = alias_map[qualifier]
                    return self.add_schema_prefix(resolved)
                # Try matching against from_tables
                for ft in from_tables:
                    ft_upper = ft.upper()
                    simple = ft_upper.split('.')[-1] if '.' in ft_upper else ft_upper
                    if qualifier == simple or qualifier == ft_upper:
                        return ft
                return self.add_schema_prefix(qualifier)

        # No table qualifier found — use first FROM table (the main source)
        if from_tables:
            return from_tables[0]
        return ""

    def _extract_source_col_name(self, col_expr: exp.Expression) -> str:
        """
        Get the simple source column name from an expression.

        Args:
            col_expr: Column expression

        Returns:
            Source column name
        """
        inner = col_expr
        if isinstance(col_expr, exp.Alias):
            inner = col_expr.this

        if isinstance(inner, exp.Column):
            return inner.name

        # For complex expressions, extract all column names
        columns = []
        for col in inner.find_all(exp.Column):
            if col.name and col.name.upper() not in [c.upper() for c in columns]:
                columns.append(col.name)
        if columns:
            return ', '.join(columns)

        # Fallback: use the expression SQL
        try:
            return inner.sql()
        except Exception:
            return str(inner)

    def _find_union_tables_for_source(self, source_expr: str, resolved_table: str,
                                       alias_map: Dict[str, str],
                                       union_alias_tables: Dict[str, List[str]]) -> Optional[List[str]]:
        """
        Check if a column's source expression references a UNION alias.
        If so, return all the UNION branch tables.

        This handles the case where a volatile table JOINs a UNION subquery:
        e.g., LEFT JOIN (SELECT ... FROM A UNION ALL SELECT ... FROM B) PCO_SINCE_SEED

        When a column references PCO_SINCE_SEED.COL, we need edges to both A and B.

        Args:
            source_expr: The source expression SQL string
            resolved_table: The table that was resolved by _extract_table_from_expr
            alias_map: Standard alias map
            union_alias_tables: Map of alias -> list of UNION branch tables

        Returns:
            List of all UNION branch tables, or None if not a UNION alias
        """
        if not union_alias_tables:
            return None
        try:
            parsed = sqlglot.parse_one(source_expr, dialect=self.dialect)
            if parsed:
                for col in parsed.find_all(exp.Column):
                    if col.table:
                        qualifier = col.table.upper()
                        if qualifier in union_alias_tables:
                            return union_alias_tables[qualifier]
        except Exception:
            pass
        return None

    def get_lineage_edges(self, table_name: str) -> List[VolatileLineageEdge]:
        """
        Get lineage edges for a volatile table.

        Args:
            table_name: Volatile table name

        Returns:
            List of lineage edges
        """
        edges = []

        if table_name not in self.volatile_tables:
            return edges

        definition = self.volatile_tables[table_name]

        # Build alias map from the raw SELECT for resolving table aliases
        # union_alias_tables tracks aliases that resolve to UNION subqueries (multiple tables)
        alias_map, union_alias_tables = self._build_table_alias_map(definition.raw_select)

        # Build subquery column map: resolves columns from JOIN subquery aliases
        # e.g., PCO_SINCE_SEED.PCO_36K -> {base columns: TR_TR, TR_AC_CODE, TC_AMT_FLDS}
        subquery_col_map = self._build_subquery_column_map(definition.raw_select)

        for col_name in definition.columns:
            source_expr = definition.column_mappings.get(col_name, col_name)
            source_col = definition.column_sources.get(col_name, col_name)

            # Check if it's a hardcoded value
            is_hardcoded = self._is_hardcoded_value(source_expr)
            hardcoded_value = ""
            if is_hardcoded:
                hardcoded_value = self._extract_hardcoded_value(source_expr)

            # Check for UNION-sourced columns (top-level UNION): emit one edge per branch
            if (not is_hardcoded
                    and col_name in definition.column_union_sources
                    and definition.column_union_sources[col_name]):
                for (branch_src_table, branch_src_col) in definition.column_union_sources[col_name]:
                    edges.append(VolatileLineageEdge(
                        source_table=branch_src_table,
                        source_column=branch_src_col,
                        target_table=table_name,
                        target_column=col_name,
                        transformation=source_expr,
                        dml_operation=definition.dml_operation.value,
                        join_conditions=definition.join_conditions,
                        where_conditions=definition.where_conditions,
                        is_hardcoded=False,
                        hardcoded_value="",
                        sttm=definition.sttm[:500] if len(definition.sttm) > 500 else definition.sttm
                    ))
            else:
                # Single-source column (original logic)
                primary_tables = definition.from_tables if definition.from_tables else definition.source_tables
                source_table = self._extract_table_from_expr(source_expr, primary_tables, alias_map)

                if is_hardcoded:
                    source_table = "[HARDCODED]"
                    source_col = hardcoded_value

                # Resolve subquery alias columns to actual base columns
                # e.g., PCO_SINCE_SEED.PCO_36K -> TR_TR, TR_AC_CODE, TC_AMT_FLDS
                resolved_base_cols = []
                if not is_hardcoded and subquery_col_map:
                    # Check if source_expr references a subquery alias (e.g., "PCO_SINCE_SEED.PCO_36K")
                    for sq_alias, col_map in subquery_col_map.items():
                        if sq_alias + '.' in source_expr.upper():
                            src_col_upper = source_col.upper()
                            if src_col_upper in col_map:
                                resolved_base_cols = col_map[src_col_upper]
                                break

                # Check if the resolved source table came through a UNION alias
                # If so, emit edges for ALL UNION branch tables
                union_tables = self._find_union_tables_for_source(
                    source_expr, source_table, alias_map, union_alias_tables
                )

                source_tables_list = union_tables if (union_tables and not is_hardcoded) else [source_table]

                if resolved_base_cols and not is_hardcoded:
                    # Emit one edge per base column per source table
                    for st in source_tables_list:
                        for base_col in resolved_base_cols:
                            edges.append(VolatileLineageEdge(
                                source_table=st,
                                source_column=base_col,
                                target_table=table_name,
                                target_column=col_name,
                                transformation=source_expr,
                                dml_operation=definition.dml_operation.value,
                                join_conditions=definition.join_conditions,
                                where_conditions=definition.where_conditions,
                                is_hardcoded=False,
                                hardcoded_value="",
                                sttm=definition.sttm[:500] if len(definition.sttm) > 500 else definition.sttm
                            ))
                else:
                    for st in source_tables_list:
                        edges.append(VolatileLineageEdge(
                            source_table=st,
                            source_column=source_col,
                            target_table=table_name,
                            target_column=col_name,
                            transformation=source_expr,
                            dml_operation=definition.dml_operation.value,
                            join_conditions=definition.join_conditions,
                            where_conditions=definition.where_conditions,
                            is_hardcoded=is_hardcoded,
                            hardcoded_value=hardcoded_value,
                            sttm=definition.sttm[:500] if len(definition.sttm) > 500 else definition.sttm
                        ))

        return edges

    def _build_subquery_column_map(self, raw_select: str) -> Dict[str, Dict[str, List[str]]]:
        """
        Build a map of subquery alias columns to their actual base columns.

        For JOIN subqueries like:
            LEFT JOIN (SELECT TR_BK, ..., SUM(CASE WHEN TR_TR=36 AND TR_AC_CODE='K'
                THEN CAST(SUBSTR(TC_AMT_FLDS,...)) END) AS PCO_36K
                FROM (...) ...) PCO_SINCE_SEED ON ...

        Returns:
            Dict mapping subquery_alias -> {column_alias -> [base_columns]}
            e.g., {"PCO_SINCE_SEED": {"PCO_36K": ["TR_TR", "TR_AC_CODE", "TC_AMT_FLDS"]}}
        """
        result: Dict[str, Dict[str, List[str]]] = {}
        try:
            parsed = sqlglot.parse_one(raw_select, read=self.dialect)
            select_node = parsed
            if not isinstance(select_node, exp.Select):
                for node in parsed.walk():
                    if isinstance(node, exp.Select):
                        select_node = node
                        break
            if not isinstance(select_node, exp.Select):
                return result

            # Find JOIN subqueries with aliases
            for join in select_node.find_all(exp.Join):
                join_source = join.this
                if isinstance(join_source, exp.Subquery):
                    alias_name = ""
                    if hasattr(join_source, 'alias') and join_source.alias:
                        alias_name = str(join_source.alias).upper()
                    if not alias_name:
                        continue

                    # Find the inner SELECT in the subquery
                    inner_select = join_source.this
                    if isinstance(inner_select, exp.Select):
                        col_map: Dict[str, List[str]] = {}
                        for expr in inner_select.expressions:
                            col_alias = ""
                            col_expr = expr
                            if isinstance(expr, exp.Alias):
                                col_alias = str(expr.alias).upper()
                                col_expr = expr.this
                            elif isinstance(expr, exp.Column):
                                col_alias = str(expr.name).upper()

                            if not col_alias:
                                continue

                            # Extract all leaf Column references from the expression
                            base_cols = []
                            for col_ref in col_expr.find_all(exp.Column):
                                col_name = str(col_ref.name).upper()
                                if col_name and col_name not in base_cols:
                                    base_cols.append(col_name)

                            if base_cols:
                                col_map[col_alias] = base_cols

                        if col_map:
                            result[alias_name] = col_map
        except Exception:
            pass
        return result

    def _build_table_alias_map(self, raw_select: str) -> Tuple[Dict[str, str], Dict[str, List[str]]]:
        """
        Build a map of table aliases to real table names from a SELECT statement.
        Also builds a map of aliases that resolve to UNION subqueries (multiple tables).

        E.g., "SELECT ... FROM DRIVING_SET DS JOIN ..." -> {"DS": "DRIVING_SET"}

        Args:
            raw_select: The raw SELECT SQL

        Returns:
            Tuple of:
              - alias_map: Dict mapping alias (uppercase) to table name
              - union_alias_tables: Dict mapping alias (uppercase) to list of all UNION branch tables
        """
        alias_map: Dict[str, str] = {}
        union_alias_tables: Dict[str, List[str]] = {}
        try:
            parsed = sqlglot.parse_one(raw_select, dialect=self.dialect)
            if not parsed:
                return alias_map, union_alias_tables

            # Find the top-level SELECT
            select_node = parsed
            if isinstance(parsed, exp.Union):
                select_node = parsed.this
            if not isinstance(select_node, exp.Select):
                select_node = parsed.find(exp.Select)
            if not select_node:
                return alias_map, union_alias_tables

            # Process FROM clause
            from_arg = select_node.args.get('from_') or select_node.args.get('from')
            if from_arg and hasattr(from_arg, 'this'):
                self._collect_table_aliases(from_arg.this, alias_map, union_alias_tables)

            # Process JOIN clauses
            joins = select_node.args.get('joins') or []
            for join in joins:
                if hasattr(join, 'this') and join.this:
                    self._collect_table_aliases(join.this, alias_map, union_alias_tables)

        except Exception:
            pass
        return alias_map, union_alias_tables

    def _collect_table_aliases(self, source: exp.Expression, alias_map: Dict[str, str],
                               union_alias_tables: Optional[Dict[str, List[str]]] = None) -> None:
        """
        Collect table alias from a FROM/JOIN source expression.

        Args:
            source: Source expression (Table, Subquery, Alias)
            alias_map: Dict to populate with alias -> table name
            union_alias_tables: Dict to populate with alias -> list of UNION branch tables
        """
        if isinstance(source, exp.Table):
            table_name = self._get_full_table_name(source)
            if hasattr(source, 'alias') and source.alias:
                alias_str = source.alias if isinstance(source.alias, str) else str(source.alias)
                if alias_str and alias_str.upper() != table_name.upper():
                    alias_map[alias_str.upper()] = table_name.upper()
        elif isinstance(source, exp.Subquery):
            # Derived table with alias — resolve alias to inner table(s)
            alias_str = None
            if hasattr(source, 'alias') and source.alias:
                alias_str = source.alias if isinstance(source.alias, str) else str(source.alias)
            if alias_str and source.this:
                inner_tables = self._extract_primary_from_tables(source.this)
                if inner_tables:
                    # Map alias to first table for standard resolution
                    first = inner_tables[0]
                    simple = first.split('.')[-1] if '.' in first else first
                    alias_map[alias_str.upper()] = simple.upper()
                    # If multiple tables (UNION), track all of them
                    if len(inner_tables) > 1 and union_alias_tables is not None:
                        union_alias_tables[alias_str.upper()] = [
                            self.add_schema_prefix(t) for t in inner_tables
                        ]
        elif isinstance(source, exp.Alias):
            if hasattr(source, 'this'):
                self._collect_table_aliases(source.this, alias_map, union_alias_tables)

    def _extract_table_from_expr(self, expr: str, source_tables: List[str],
                                alias_map: Optional[Dict[str, str]] = None) -> str:
        """
        Extract source table name from a column expression.

        Args:
            expr: Column expression (e.g., "SYS_CALENDAR.BUSINESSCALENDAR.CALENDAR_DATE")
            source_tables: List of primary source tables (FROM/JOIN tables)
            alias_map: Optional alias-to-table mapping (e.g., {"DS": "DRIVING_SET"})

        Returns:
            Source table name, or empty string if not found
        """
        # Try to parse the expression and extract table reference
        try:
            import sqlglot as sqlglot_import
            from sqlglot import exp as exp_import

            parsed = sqlglot_import.parse_one(expr, dialect=self.dialect)
            if parsed:
                # Find all column references
                for col in parsed.find_all(exp_import.Column):
                    if col.table:
                        # Found a column with table prefix
                        table_qualifier = col.table
                        # Check if there's a catalog/schema prefix
                        if hasattr(col, 'catalog') and col.catalog:
                            table_qualifier = f"{col.catalog}.{table_qualifier}"

                        # Resolve alias first
                        qualifier_upper = table_qualifier.upper()
                        if alias_map and qualifier_upper in alias_map:
                            table_qualifier = alias_map[qualifier_upper]
                            qualifier_upper = table_qualifier.upper()

                        # Try to match qualifier against source_tables (with schema)
                        for st in source_tables:
                            st_upper = st.upper()
                            # Match full name or just the table part
                            simple_name = st_upper.split('.')[-1] if '.' in st_upper else st_upper
                            if qualifier_upper == st_upper or qualifier_upper == simple_name:
                                return st  # Return with schema prefix
                        # If no match in source_tables, try adding schema prefix
                        prefixed = self.add_schema_prefix(table_qualifier)
                        return prefixed
        except Exception:
            pass

        # Fallback: Use first source table from the provided list
        return source_tables[0] if source_tables else ""

    def _is_hardcoded_value(self, expr: str) -> bool:
        """Check if expression is a hardcoded value.

        Note: CURRENT_DATE/CURRENT_TIMESTAMP are NOT hardcoded values - they are
        system functions that return dynamic values. These should be treated as
        source columns.

        Also, expressions containing arithmetic operations or function calls
        are NOT hardcoded - they derive values from other sources.
        """
        expr_clean = expr.strip()
        
        # CURRENT_DATE/TIMESTAMP are NOT hardcoded - they are system functions
        if re.match(r'^CURRENT_(?:DATE|TIMESTAMP)$', expr_clean, re.IGNORECASE):
            return False
        
        # Expressions with function calls (EXTRACT, ADD_MONTHS, COALESCE, etc.) are NOT hardcoded
        if re.search(r'\b(EXTRACT|ADD_MONTHS|COALESCE|CAST|DATE|LAST_DAY|CURRENT_DATE|CURRENT_TIMESTAMP)\s*\(', expr_clean, re.IGNORECASE):
            return False
        
        # Expressions with arithmetic operators are NOT hardcoded (they likely use columns)
        if re.search(r'[\+\-\*\/]', expr_clean):
            return False
        
        # String literal (simple)
        if re.match(r"^'[^']*'$", expr_clean):
            return True
        
        # Numeric literal (simple)
        if re.match(r'^-?\d+\.?\d*$', expr_clean):
            return True
        
        # CAST of literal date/string (but not expressions)
        if re.match(r"^CAST\s*\(\s*'[^']+'\s+AS\s+\w+\s*\)$", expr_clean, re.IGNORECASE):
            return True
        
        return False
    
    def _extract_hardcoded_value(self, expr: str) -> str:
        """Extract the hardcoded value from an expression."""
        expr_clean = expr.strip()
        
        # String literal
        match = re.match(r"^'([^']*)'$", expr_clean)
        if match:
            return f"STRING: {match.group(1)}"
        
        # Numeric literal
        if re.match(r'^-?\d+\.?\d*$', expr_clean):
            return f"NUMBER: {expr_clean}"
        
        # CURRENT_DATE/TIMESTAMP
        if re.match(r'^CURRENT_(?:DATE|TIMESTAMP)$', expr_clean, re.IGNORECASE):
            return expr_clean.upper()
        
        # CAST of literal
        match = re.match(r"^CAST\s*\(\s*'([^']+)'\s+AS\s+(\w+)\s*\)", expr_clean, re.IGNORECASE)
        if match:
            return f"{match.group(2).upper()}: {match.group(1)}"
        
        return expr_clean
    
    def get_all_lineage_edges(self) -> List[VolatileLineageEdge]:
        """
        Get all lineage edges for all volatile tables in processing order.
        
        Returns:
            List of all lineage edges
        """
        all_edges = []
        
        for table_name in self.processing_order:
            all_edges.extend(self.get_lineage_edges(table_name))
        
        return all_edges
    
    def to_csv_rows(self) -> List[Dict[str, Any]]:
        """
        Convert all lineage to CSV rows.
        
        Returns:
            List of dicts suitable for CSV output
        """
        rows = []
        
        for edge in self.get_all_lineage_edges():
            rows.append({
                'Source_Table': edge.source_table,
                'Source_Attribute': edge.source_column,
                'Transformation_Logic': edge.transformation,
                'Target_Table': edge.target_table,
                'Target_Attribute': edge.target_column,
                'DML_Operation': edge.dml_operation,
                'Join_Conditions': edge.join_conditions,
                'Where_Conditions': edge.where_conditions,
                'STTM': edge.sttm
            })
        
        return rows
    
    def get_volatile_table_schema(self) -> Dict[str, List[str]]:
        """
        Get schema dict for all volatile tables.
        
        Returns:
            Dict mapping table names to column lists
        """
        schema = {}
        for name, definition in self.volatile_tables.items():
            schema[name] = definition.columns
            # Also add lowercase version
            schema[name.lower()] = definition.columns
        return schema
    
    def to_lineage_graph(self):
        """
        Convert volatile table lineage to a LineageGraph.

        This allows the volatile table lineage to be merged with the main
        lineage graph for end-to-end lineage tracing.

        Returns:
            LineageGraph: Graph representation of volatile table lineage
        """
        from lineage.lineage_graph import LineageGraph
        from models.data_models import ColumnRef, LineageEdge, TransformationInfo, TransformationType, TransformationSubtype

        graph = LineageGraph()

        for edge in self.get_all_lineage_edges():
            # Keep full table name with schema for proper lineage tracing
            source_table = edge.source_table

            # Create ColumnRef for source
            source_ref = ColumnRef(
                table_name=source_table,
                column_name=edge.source_column,
                schema_name=None
            )

            # Create ColumnRef for target
            target_ref = ColumnRef(
                table_name=edge.target_table,
                column_name=edge.target_column,
                schema_name=None
            )

            # Determine transformation type
            if edge.is_hardcoded:
                trans_type = TransformationType.INDIRECT
                trans_subtype = TransformationSubtype.TRANSFORMATION
            elif edge.source_column == edge.target_column:
                trans_type = TransformationType.DIRECT
                trans_subtype = TransformationSubtype.IDENTITY
            else:
                trans_type = TransformationType.INDIRECT
                trans_subtype = TransformationSubtype.TRANSFORMATION

            # Create TransformationInfo
            transformation = TransformationInfo(
                type=trans_type,
                subtype=trans_subtype,
                description=f"Volatile table {edge.dml_operation}",
                sql_expression=edge.transformation,
                source_columns=[source_ref],
                complexity_score=2 if edge.is_hardcoded else 1
            )

            # Create LineageEdge with full metadata preserved
            lineage_edge = LineageEdge(
                source=source_ref,
                target=target_ref,
                transformation=transformation,
                dml_operation=edge.dml_operation,
                join_conditions=edge.join_conditions,
                where_conditions=edge.where_conditions
            )
            graph.add_edge(lineage_edge)

        return graph
