"""
CTE Resolver module.

Resolves CTE references to build complete lineage DAG.
Handles recursive CTEs and multi-level dependencies.
"""

import sqlglot
from sqlglot import exp
from typing import Dict, List, Set, Optional, Tuple
import sys
import os

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from models.data_models import ColumnRef


class ResolvedCTE:
    """Resolved CTE with column lineage information."""

    def __init__(self, name: str):
        self.name = name
        self.columns: List[str] = []
        self.column_lineage: Dict[str, List[ColumnRef]] = {}
        self.source_tables: List[str] = []
        self.is_recursive: bool = False

    def get_source_columns(self, column: str) -> List[ColumnRef]:
        """Get source columns for a specific output column."""
        return self.column_lineage.get(column.upper(), [])


class CTEResolver:
    """
    Resolve CTE references to build complete lineage DAG.
    Handles recursive CTEs and multi-level dependencies.
    """

    def __init__(self, dialect: str = "teradata"):
        """
        Initialize resolver.

        Args:
            dialect: SQL dialect
        """
        self.dialect = dialect

    def resolve(self, ast: exp.Expression) -> Dict[str, ResolvedCTE]:
        """
        Resolve all CTEs to their underlying source tables.

        Args:
            ast: Parsed SQL AST

        Returns:
            Dict mapping CTE name to ResolvedCTE
        """
        # Extract CTEs
        ctes = self._extract_ctes(ast)
        if not ctes:
            return {}

        # Build dependency graph
        cte_graph = self._build_cte_graph(ctes)

        # Detect recursive CTEs
        recursive_ctes = self._find_recursive_ctes(ctes)

        # Topological sort non-recursive CTEs
        sorted_ctes = self._topological_sort(cte_graph, recursive_ctes)

        # Resolve each CTE
        resolved = {}

        for cte_name in sorted_ctes:
            cte_def = ctes.get(cte_name)
            if cte_def:
                if cte_name in recursive_ctes:
                    resolved[cte_name] = self._resolve_recursive_cte(cte_def, cte_name, resolved)
                else:
                    resolved[cte_name] = self._resolve_single_cte(cte_def, cte_name, resolved)

        return resolved

    def _extract_ctes(self, ast: exp.Expression) -> Dict[str, exp.Expression]:
        """
        Extract CTEs from AST.

        Args:
            ast: Parsed SQL AST

        Returns:
            Dict mapping CTE name to CTE definition
        """
        ctes = {}

        with_clause = ast.find(exp.With)
        if not with_clause:
            return ctes

        for cte_expr in with_clause.expressions:
            cte_name = cte_expr.alias
            cte_query = cte_expr.this
            ctes[cte_name.upper()] = cte_query

        return ctes

    def _build_cte_graph(self, ctes: Dict[str, exp.Expression]) -> Dict[str, Set[str]]:
        """
        Build CTE dependency graph.

        Args:
            ctes: Dict of CTE definitions

        Returns:
            Dict mapping CTE name to set of dependencies
        """
        graph = {name: set() for name in ctes}
        cte_names = set(ctes.keys())

        for cte_name, cte_query in ctes.items():
            # Find all table references in this CTE
            for table in cte_query.find_all(exp.Table):
                table_name = table.name.upper()
                # Check if it references another CTE
                if table_name in cte_names and table_name != cte_name:
                    graph[cte_name].add(table_name)

        return graph

    def _find_recursive_ctes(self, ctes: Dict[str, exp.Expression]) -> Set[str]:
        """
        Find CTEs that reference themselves (recursive).

        Args:
            ctes: Dict of CTE definitions

        Returns:
            Set of recursive CTE names
        """
        recursive = set()

        for cte_name, cte_query in ctes.items():
            # Check if CTE references itself
            for table in cte_query.find_all(exp.Table):
                if table.name.upper() == cte_name:
                    recursive.add(cte_name)
                    break

        return recursive

    def _topological_sort(self, graph: Dict[str, Set[str]],
                          exclude: Set[str]) -> List[str]:
        """
        Topologically sort CTEs based on dependencies.

        Args:
            graph: Dependency graph
            exclude: CTEs to exclude (recursive)

        Returns:
            List of CTE names in dependency order
        """
        # Filter out excluded CTEs
        filtered_graph = {
            k: {v for v in deps if v not in exclude}
            for k, deps in graph.items()
            if k not in exclude
        }

        # Calculate in-degree
        in_degree = {name: 0 for name in filtered_graph}
        for deps in filtered_graph.values():
            for dep in deps:
                if dep in in_degree:
                    in_degree[dep] += 1

        # Kahn's algorithm
        queue = [name for name, degree in in_degree.items() if degree == 0]
        result = []

        while queue:
            node = queue.pop(0)
            result.append(node)

            for neighbor in list(filtered_graph.keys()):
                if node in filtered_graph[neighbor]:
                    in_degree[neighbor] -= 1
                    if in_degree[neighbor] == 0:
                        queue.append(neighbor)

        # Add recursive CTEs at the end
        result.extend(exclude)

        return result

    def _resolve_single_cte(self, cte_query: exp.Expression,
                            cte_name: str,
                            resolved: Dict[str, ResolvedCTE]) -> ResolvedCTE:
        """
        Resolve a single non-recursive CTE.

        Args:
            cte_query: CTE query expression
            cte_name: CTE name
            resolved: Already resolved CTEs

        Returns:
            ResolvedCTE object
        """
        result = ResolvedCTE(cte_name)
        result.is_recursive = False

        # Get output columns
        if isinstance(cte_query, exp.Select):
            result.columns = self._get_select_columns(cte_query)

        # Get source tables
        result.source_tables = self._get_source_tables(cte_query, resolved)

        # Build column lineage
        result.column_lineage = self._build_column_lineage(cte_query, resolved)

        return result

    def _resolve_recursive_cte(self, cte_query: exp.Expression,
                                cte_name: str,
                                resolved: Dict[str, ResolvedCTE]) -> ResolvedCTE:
        """
        Resolve a recursive CTE.

        Args:
            cte_query: CTE query expression
            cte_name: CTE name
            resolved: Already resolved CTEs

        Returns:
            ResolvedCTE object
        """
        result = ResolvedCTE(cte_name)
        result.is_recursive = True

        # Split UNION into anchor and recursive parts
        anchor_parts, recursive_parts = self._split_recursive_cte(cte_query, cte_name)

        # Get columns from anchor
        if anchor_parts and isinstance(anchor_parts[0], exp.Select):
            result.columns = self._get_select_columns(anchor_parts[0])

        # Build lineage from anchor parts only
        for anchor in anchor_parts:
            anchor_lineage = self._build_column_lineage(anchor, resolved)
            for col, sources in anchor_lineage.items():
                if col not in result.column_lineage:
                    result.column_lineage[col] = []
                result.column_lineage[col].extend(sources)

        # Get source tables (excluding self-reference)
        all_sources = []
        for part in anchor_parts + recursive_parts:
            for table in part.find_all(exp.Table):
                if table.name.upper() != cte_name:
                    name = table.name
                    if table.db:
                        name = f"{table.db}.{name}"
                    all_sources.append(name)

        result.source_tables = list(set(all_sources))

        return result

    def _split_recursive_cte(self, cte_query: exp.Expression,
                              cte_name: str) -> Tuple[List[exp.Expression], List[exp.Expression]]:
        """
        Split a recursive CTE into anchor and recursive parts.

        Args:
            cte_query: CTE query expression
            cte_name: CTE name

        Returns:
            Tuple of (anchor_parts, recursive_parts)
        """
        anchor_parts = []
        recursive_parts = []

        # Handle UNION/UNION ALL
        if isinstance(cte_query, exp.Union):
            for part in self._flatten_union(cte_query):
                if self._references_cte(part, cte_name):
                    recursive_parts.append(part)
                else:
                    anchor_parts.append(part)
        else:
            # Single query - check if it references itself
            if self._references_cte(cte_query, cte_name):
                recursive_parts.append(cte_query)
            else:
                anchor_parts.append(cte_query)

        return anchor_parts, recursive_parts

    def _flatten_union(self, union_expr: exp.Union) -> List[exp.Expression]:
        """
        Flatten nested UNION expressions.

        Args:
            union_expr: Union expression

        Returns:
            List of SELECT expressions
        """
        parts = []

        if isinstance(union_expr.this, exp.Union):
            parts.extend(self._flatten_union(union_expr.this))
        else:
            parts.append(union_expr.this)

        if isinstance(union_expr.expression, exp.Union):
            parts.extend(self._flatten_union(union_expr.expression))
        else:
            parts.append(union_expr.expression)

        return parts

    def _references_cte(self, expr: exp.Expression, cte_name: str) -> bool:
        """
        Check if expression references a specific CTE.

        Args:
            expr: Expression to check
            cte_name: CTE name

        Returns:
            True if references CTE
        """
        for table in expr.find_all(exp.Table):
            if table.name.upper() == cte_name.upper():
                return True
        return False

    def _get_select_columns(self, select_expr: exp.Select) -> List[str]:
        """
        Get column names from SELECT clause.

        Args:
            select_expr: Select expression

        Returns:
            List of column names
        """
        columns = []

        for expr in select_expr.expressions:
            if isinstance(expr, exp.Alias):
                columns.append(expr.alias.upper())
            elif isinstance(expr, exp.Column):
                columns.append(expr.name.upper())
            elif isinstance(expr, exp.Star):
                columns.append("*")
            else:
                columns.append(f"COL_{len(columns) + 1}")

        return columns

    def _get_source_tables(self, query: exp.Expression,
                           resolved: Dict[str, ResolvedCTE]) -> List[str]:
        """
        Get source tables, resolving CTEs to their base tables.

        Args:
            query: Query expression
            resolved: Already resolved CTEs

        Returns:
            List of source table names
        """
        tables = []

        for table in query.find_all(exp.Table):
            table_name = table.name.upper()

            # Check if it's a resolved CTE
            if table_name in resolved:
                tables.extend(resolved[table_name].source_tables)
            else:
                name = table.name
                if table.db:
                    name = f"{table.db}.{name}"
                tables.append(name)

        return list(set(tables))

    def _build_column_lineage(self, query: exp.Expression,
                               resolved: Dict[str, ResolvedCTE]) -> Dict[str, List[ColumnRef]]:
        """
        Build column-level lineage for a query.

        Args:
            query: Query expression
            resolved: Already resolved CTEs

        Returns:
            Dict mapping output column to source columns
        """
        lineage = {}

        if not isinstance(query, exp.Select):
            return lineage

        for expr in query.expressions:
            output_col = None
            source_expr = None

            if isinstance(expr, exp.Alias):
                output_col = expr.alias.upper()
                source_expr = expr.this
            elif isinstance(expr, exp.Column):
                output_col = expr.name.upper()
                source_expr = expr
            else:
                continue

            if output_col:
                sources = self._extract_source_columns(source_expr, resolved)
                lineage[output_col] = sources

        return lineage

    def _extract_source_columns(self, expr: exp.Expression,
                                 resolved: Dict[str, ResolvedCTE]) -> List[ColumnRef]:
        """
        Extract source columns from an expression.

        Args:
            expr: Expression to analyze
            resolved: Already resolved CTEs

        Returns:
            List of source ColumnRef objects
        """
        sources = []

        if expr is None:
            return sources

        for col in expr.find_all(exp.Column):
            table_name = col.table.upper() if col.table else ""
            col_name = col.name.upper()

            # Check if it references a CTE
            if table_name in resolved:
                # Resolve through CTE
                cte_sources = resolved[table_name].get_source_columns(col_name)
                if cte_sources:
                    sources.extend(cte_sources)
                else:
                    # Column not found in CTE lineage, add as-is
                    sources.append(ColumnRef(
                        table_name=table_name,
                        column_name=col_name
                    ))
            else:
                sources.append(ColumnRef(
                    table_name=col.table if col.table else "",
                    column_name=col.name
                ))

        return sources

    def get_cte_dependency_order(self, ast: exp.Expression) -> List[str]:
        """
        Get CTEs in dependency order (for processing).

        Args:
            ast: Parsed SQL AST

        Returns:
            List of CTE names in order
        """
        ctes = self._extract_ctes(ast)
        if not ctes:
            return []

        graph = self._build_cte_graph(ctes)
        recursive = self._find_recursive_ctes(ctes)

        return self._topological_sort(graph, recursive)
