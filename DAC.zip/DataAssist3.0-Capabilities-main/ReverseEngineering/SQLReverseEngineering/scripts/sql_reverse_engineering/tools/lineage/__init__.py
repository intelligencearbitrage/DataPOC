"""Lineage extraction module for tracing column-level data lineage."""

from .lineage_extractor import LineageExtractor, DynamicSQLAwareExtractor
from .lineage_graph import LineageGraph
from .transformation_classifier import TransformationClassifier
from .cte_resolver import CTEResolver
from .cross_file_stitcher import (
    CrossFileLineageStitcher,
    TableRegistry,
    TableRole,
    EndToEndLineage
)

__all__ = [
    "LineageExtractor",
    "DynamicSQLAwareExtractor",
    "LineageGraph",
    "TransformationClassifier",
    "CTEResolver",
    "CrossFileLineageStitcher",
    "TableRegistry",
    "TableRole",
    "EndToEndLineage"
]
