"""
Transformation Classifier module.

Classifies transformations according to lineage best practices,
distinguishing between DIRECT and INDIRECT transformations with subtypes.
"""

import sqlglot
from sqlglot import exp
from typing import Optional, Tuple
import sys
import os

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from models.data_models import (
    TransformationType, TransformationSubtype, TransformationInfo, ColumnRef
)


class TransformationClassifier:
    """
    Classify transformations according to OpenLineage facet model.
    Distinguishes between DIRECT and INDIRECT transformations with detailed subtypes.
    """

    # Function categories for classification
    AGGREGATE_FUNCTIONS = {
        'SUM', 'COUNT', 'AVG', 'MIN', 'MAX', 'STDDEV', 'VARIANCE',
        'LISTAGG', 'STRING_AGG', 'GROUP_CONCAT', 'ARRAY_AGG',
        'FIRST', 'LAST', 'MEDIAN', 'PERCENTILE'
    }

    STRING_FUNCTIONS = {
        'UPPER', 'LOWER', 'TRIM', 'LTRIM', 'RTRIM', 'SUBSTRING', 'SUBSTR',
        'CONCAT', 'REPLACE', 'LEFT', 'RIGHT', 'LEN', 'LENGTH', 'CHAR_LENGTH',
        'POSITION', 'LOCATE', 'INSTR', 'REVERSE', 'REPEAT', 'SPACE', 'LPAD', 'RPAD'
    }

    DATE_FUNCTIONS = {
        'DATEADD', 'DATEDIFF', 'DATEPART', 'YEAR', 'MONTH', 'DAY', 'HOUR',
        'MINUTE', 'SECOND', 'GETDATE', 'CURRENT_DATE', 'CURRENT_TIMESTAMP',
        'DATE_TRUNC', 'DATE_ADD', 'DATE_SUB', 'TO_DATE', 'TO_TIMESTAMP'
    }

    MATH_FUNCTIONS = {
        'ABS', 'ROUND', 'FLOOR', 'CEIL', 'CEILING', 'MOD', 'POWER', 'SQRT',
        'LOG', 'LOG10', 'EXP', 'SIGN', 'RAND', 'RANDOM'
    }

    COALESCE_FUNCTIONS = {
        'COALESCE', 'ISNULL', 'NVL', 'IFNULL', 'NULLIF', 'NVL2'
    }

    def __init__(self, dialect: str = "teradata"):
        """
        Initialize classifier.

        Args:
            dialect: SQL dialect
        """
        self.dialect = dialect

    def classify(self, source_expr: exp.Expression,
                 target_column: str = None) -> TransformationInfo:
        """
        Analyze source expression and classify the transformation type.

        Args:
            source_expr: Source expression
            target_column: Target column name

        Returns:
            TransformationInfo with classification
        """
        if source_expr is None:
            return self._make_info(
                TransformationType.INDIRECT,
                TransformationSubtype.UNKNOWN,
                "Unknown transformation",
                ""
            )

        sql_text = source_expr.sql(dialect=self.dialect) if hasattr(source_expr, 'sql') else str(source_expr)

        # Check for direct identity mapping
        if self._is_identity(source_expr, target_column):
            return self._make_info(
                TransformationType.DIRECT,
                TransformationSubtype.IDENTITY,
                "Direct column reference",
                sql_text
            )

        # Check for direct rename (simple column reference with different name)
        if self._is_rename(source_expr, target_column):
            return self._make_info(
                TransformationType.DIRECT,
                TransformationSubtype.RENAME,
                "Column rename",
                sql_text
            )

        # Check for type cast only
        if self._is_cast_only(source_expr):
            cast_type = self._get_cast_type(source_expr)
            return self._make_info(
                TransformationType.DIRECT,
                TransformationSubtype.CAST,
                f"Cast to {cast_type}",
                sql_text
            )

        # Check for CASE statement
        if self._has_case(source_expr):
            return self._make_info(
                TransformationType.INDIRECT,
                TransformationSubtype.CASE_LOGIC,
                "CASE statement transformation",
                sql_text,
                complexity=3
            )

        # Check for aggregate functions
        if self._has_aggregate(source_expr):
            agg_name = self._get_aggregate_name(source_expr)
            return self._make_info(
                TransformationType.INDIRECT,
                TransformationSubtype.AGGREGATION,
                f"Aggregate function: {agg_name}",
                sql_text,
                complexity=2
            )

        # Check for COALESCE/NULL handling
        if self._has_coalesce(source_expr):
            return self._make_info(
                TransformationType.INDIRECT,
                TransformationSubtype.COALESCE,
                "NULL handling transformation",
                sql_text,
                complexity=2
            )

        # Check for string manipulation
        if self._has_string_function(source_expr):
            func_name = self._get_string_function_name(source_expr)
            return self._make_info(
                TransformationType.INDIRECT,
                TransformationSubtype.STRING_MANIPULATION,
                f"String function: {func_name}",
                sql_text,
                complexity=2
            )

        # Check for date manipulation
        if self._has_date_function(source_expr):
            func_name = self._get_date_function_name(source_expr)
            return self._make_info(
                TransformationType.INDIRECT,
                TransformationSubtype.DATE_MANIPULATION,
                f"Date function: {func_name}",
                sql_text,
                complexity=2
            )

        # Check for mathematical operations
        if self._has_math_operation(source_expr):
            return self._make_info(
                TransformationType.INDIRECT,
                TransformationSubtype.MATHEMATICAL,
                "Mathematical computation",
                sql_text,
                complexity=2
            )

        # Check for window function
        if self._has_window_function(source_expr):
            return self._make_info(
                TransformationType.INDIRECT,
                TransformationSubtype.WINDOW,
                "Window function computation",
                sql_text,
                complexity=3
            )

        # Check for any function call
        if self._has_function(source_expr):
            func_name = self._get_function_name(source_expr)
            return self._make_info(
                TransformationType.INDIRECT,
                TransformationSubtype.TRANSFORMATION,
                f"Function: {func_name}",
                sql_text,
                complexity=2
            )

        # Default: complex transformation
        return self._make_info(
            TransformationType.INDIRECT,
            TransformationSubtype.TRANSFORMATION,
            "Complex transformation",
            sql_text,
            complexity=2
        )

    def _make_info(self, type_: TransformationType,
                   subtype: TransformationSubtype,
                   description: str,
                   sql_expression: str,
                   complexity: int = 1) -> TransformationInfo:
        """
        Create a TransformationInfo object.

        Args:
            type_: Transformation type
            subtype: Transformation subtype
            description: Human-readable description
            sql_expression: SQL text
            complexity: Complexity score (1-5)

        Returns:
            TransformationInfo object
        """
        return TransformationInfo(
            type=type_,
            subtype=subtype,
            description=description,
            sql_expression=sql_expression,
            complexity_score=complexity
        )

    def _is_identity(self, expr: exp.Expression, target_column: str = None) -> bool:
        """Check if expression is a direct column reference with same name."""
        if isinstance(expr, exp.Column):
            if target_column:
                return expr.name.upper() == target_column.upper()
            return True
        return False

    def _is_rename(self, expr: exp.Expression, target_column: str = None) -> bool:
        """Check if expression is a direct column reference with a different name."""
        if isinstance(expr, exp.Column) and target_column:
            return expr.name.upper() != target_column.upper()
        return False

    def _is_cast_only(self, expr: exp.Expression) -> bool:
        """Check if expression is only a type cast."""
        if isinstance(expr, exp.Cast):
            inner = expr.this
            return isinstance(inner, exp.Column)
        return False

    def _get_cast_type(self, expr: exp.Expression) -> str:
        """Get the target type of a cast."""
        if isinstance(expr, exp.Cast):
            return expr.to.sql(dialect=self.dialect) if expr.to else "UNKNOWN"
        return "UNKNOWN"

    def _has_case(self, expr: exp.Expression) -> bool:
        """Check if expression contains a CASE statement."""
        return bool(expr.find(exp.Case))

    def _has_aggregate(self, expr: exp.Expression) -> bool:
        """Check if expression contains an aggregate function."""
        for func in expr.find_all(exp.Func):
            func_name = self._get_func_name(func)
            if func_name in self.AGGREGATE_FUNCTIONS:
                return True
        return False

    def _get_aggregate_name(self, expr: exp.Expression) -> str:
        """Get the name of the aggregate function."""
        for func in expr.find_all(exp.Func):
            func_name = self._get_func_name(func)
            if func_name in self.AGGREGATE_FUNCTIONS:
                return func_name
        return "AGGREGATE"

    def _has_coalesce(self, expr: exp.Expression) -> bool:
        """Check if expression contains COALESCE or similar."""
        for func in expr.find_all(exp.Func):
            func_name = self._get_func_name(func)
            if func_name in self.COALESCE_FUNCTIONS:
                return True
        return bool(expr.find(exp.Coalesce))

    def _has_string_function(self, expr: exp.Expression) -> bool:
        """Check if expression contains string functions."""
        for func in expr.find_all(exp.Func):
            func_name = self._get_func_name(func)
            if func_name in self.STRING_FUNCTIONS:
                return True
        return False

    def _get_string_function_name(self, expr: exp.Expression) -> str:
        """Get the name of the string function."""
        for func in expr.find_all(exp.Func):
            func_name = self._get_func_name(func)
            if func_name in self.STRING_FUNCTIONS:
                return func_name
        return "STRING"

    def _has_date_function(self, expr: exp.Expression) -> bool:
        """Check if expression contains date functions."""
        for func in expr.find_all(exp.Func):
            func_name = self._get_func_name(func)
            if func_name in self.DATE_FUNCTIONS:
                return True
        return False

    def _get_date_function_name(self, expr: exp.Expression) -> str:
        """Get the name of the date function."""
        for func in expr.find_all(exp.Func):
            func_name = self._get_func_name(func)
            if func_name in self.DATE_FUNCTIONS:
                return func_name
        return "DATE"

    def _has_math_operation(self, expr: exp.Expression) -> bool:
        """Check if expression contains math operations."""
        # Check for arithmetic operators
        if expr.find(exp.Add) or expr.find(exp.Sub) or \
           expr.find(exp.Mul) or expr.find(exp.Div):
            return True

        # Check for math functions
        for func in expr.find_all(exp.Func):
            func_name = self._get_func_name(func)
            if func_name in self.MATH_FUNCTIONS:
                return True

        return False

    def _has_window_function(self, expr: exp.Expression) -> bool:
        """Check if expression contains a window function."""
        return bool(expr.find(exp.Window))

    def _has_function(self, expr: exp.Expression) -> bool:
        """Check if expression contains any function."""
        return bool(expr.find(exp.Func))

    def _get_function_name(self, expr: exp.Expression) -> str:
        """Get the name of the first function in expression."""
        func = expr.find(exp.Func)
        if func:
            return self._get_func_name(func)
        return "FUNCTION"

    def _get_func_name(self, func: exp.Func) -> str:
        """Get function name from a Func node."""
        if hasattr(func, 'sql_name'):
            try:
                return func.sql_name().upper()
            except Exception:
                pass
        return func.__class__.__name__.upper()

    def classify_for_filter(self) -> TransformationInfo:
        """
        Create classification for a WHERE clause filter.

        Returns:
            TransformationInfo for filter
        """
        return self._make_info(
            TransformationType.INDIRECT,
            TransformationSubtype.FILTER,
            "Filter condition",
            ""
        )

    def classify_for_join(self, join_type: str) -> TransformationInfo:
        """
        Create classification for a JOIN.

        Args:
            join_type: Type of join (INNER, LEFT, etc.)

        Returns:
            TransformationInfo for join
        """
        return self._make_info(
            TransformationType.INDIRECT,
            TransformationSubtype.JOIN,
            f"{join_type} JOIN relationship",
            ""
        )

    def classify_for_group_by(self) -> TransformationInfo:
        """
        Create classification for GROUP BY.

        Returns:
            TransformationInfo for group by
        """
        return self._make_info(
            TransformationType.INDIRECT,
            TransformationSubtype.GROUP_BY,
            "Grouped by this column",
            ""
        )
