"""
End-to-End Multi-Hop Lineage Extractor.

Traces column-level lineage across multiple SQL files through intermediate
tables, providing complete data flow from ultimate sources to final targets.

Example flow:
TDA_EXTR_RAW ->TDA_EXTR_RAW_VW ->TDA_EXTR_LND ->TDA_EXTR_STG ->TDA_AGREEMENT_WRK_1
"""

import os
import re
import sys
import json
import csv
from typing import Dict, List, Optional, Set, Tuple, Any
from dataclasses import dataclass, field
from collections import defaultdict
from enum import Enum
from pathlib import Path
from werkzeug.utils import safe_join, secure_filename

_PROJECT_ROOT = Path(__file__).resolve().parent.parent.parent.parent.parent


def _resolve_cli_path(raw: str, must_be_under: Optional[Path] = None) -> Path:
    resolved = Path(raw).resolve()
    if must_be_under is not None:
        base = must_be_under.resolve()
        try:
            resolved.relative_to(base)
        except ValueError:
            print(f"Error: '{raw}' resolves to '{resolved}', outside allowed directory '{base}'.", file=sys.stderr)
            sys.exit(1)
    return resolved
import sqlglot
from sqlglot import exp

import sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from lineage.lineage_extractor import LineageExtractor
from lineage.lineage_graph import LineageGraph
from models.data_models import ColumnRef, TransformationInfo
from ast_generator.parser import SQLASTGenerator
from file_handlers.sql_handler import SQLHandler


@dataclass
class FileLineageInfo:
    """Lineage information extracted from a single SQL file."""
    file_path: str
    file_name: str
    file_order: int  # Order based on filename prefix (00_, 01_, etc.)
    target_table: str
    source_tables: List[str]
    column_mappings: Dict[str, List[Dict[str, Any]]]  # target_col -> list of source mappings
    lineage_graph: LineageGraph
    ast: Optional[exp.Expression] = None
    sql_content: str = ""
    dml_operation: str = ""  # CREATE TABLE, INSERT, CREATE VIEW, etc.
    join_details: str = ""  # Join conditions from the query
    where_conditions: str = ""  # WHERE clause conditions


@dataclass
class ColumnHop:
    """Represents a single hop in a column's lineage chain."""
    table_name: str
    column_name: str
    transformation: str
    transformation_type: str
    source_file: str
    hop_number: int

    def to_dict(self) -> Dict[str, Any]:
        return {
            "table": self.table_name,
            "column": self.column_name,
            "transformation": self.transformation,
            "transformation_type": self.transformation_type,
            "source_file": self.source_file,
            "hop_number": self.hop_number
        }


@dataclass
class EndToEndColumnLineage:
    """Complete end-to-end lineage for a single target column."""
    target_table: str
    target_column: str
    ultimate_source_table: str
    ultimate_source_column: str
    hop_count: int
    hops: List[ColumnHop]
    full_transformation_chain: str
    lookup_tables: List[str] = field(default_factory=list)  # Lookup/reference tables contributing data
    dml_operation: str = ""  # CREATE TABLE, INSERT, CREATE VIEW, etc.
    join_details: str = ""  # Join conditions used in the query
    where_conditions: str = ""  # WHERE clause conditions

    def to_dict(self) -> Dict[str, Any]:
        return {
            "target_table": self.target_table,
            "target_column": self.target_column,
            "ultimate_source_table": self.ultimate_source_table,
            "ultimate_source_column": self.ultimate_source_column,
            "hop_count": self.hop_count,
            "hops": [h.to_dict() for h in self.hops],
            "full_transformation_chain": self.full_transformation_chain,
            "lookup_tables": self.lookup_tables,
            "dml_operation": self.dml_operation,
            "join_details": self.join_details,
            "where_conditions": self.where_conditions
        }

    def to_csv_row(self) -> Dict[str, Any]:
        """Format for CSV output - 13-column format matching legacy output."""
        intermediate_tables = " ->".join([h.table_name for h in self.hops[:-1]]) if len(self.hops) > 1 else ""
        intermediate_transformations = []
        for h in self.hops:
            if h.transformation and h.transformation != h.column_name:
                intermediate_transformations.append(f"[{h.table_name}] {h.transformation}")

        return {
            "Ultimate_Source_Table": self.ultimate_source_table,
            "Ultimate_Source_Column": self.ultimate_source_column,
            "Target_Table": self.target_table,
            "Target_Column": self.target_column,
            "DML_Operation": self.dml_operation,
            "Hop_Count": self.hop_count,
            "Intermediate_Tables": intermediate_tables,
            "Lookup_Tables": ", ".join(self.lookup_tables) if self.lookup_tables else "",
            "Full_Transformation_Chain": self.full_transformation_chain,
            "Transformation_At_Each_Hop": " | ".join(intermediate_transformations),
            "Join_Details": self.join_details,
            "Where_Conditions": self.where_conditions,
            "Data_Flow": f"{self.ultimate_source_table}.{self.ultimate_source_column} ->" +
                        " ->".join([f"{h.table_name}.{h.column_name}" for h in self.hops])
        }


class EndToEndLineageExtractor:
    """
    Extracts end-to-end column lineage across multiple SQL files.

    Processes files in order, builds a unified lineage graph,
    and traces columns from ultimate sources through all intermediate
    tables to final targets.
    """

    def __init__(self, dialect: str = "teradata"):
        """
        Initialize the extractor.

        Args:
            dialect: SQL dialect for parsing
        """
        self.dialect = dialect
        self.lineage_extractor = LineageExtractor(dialect=dialect)
        self.file_lineages: Dict[str, FileLineageInfo] = {}
        self.table_to_file: Dict[str, str] = {}  # Maps table name to file that creates it
        self.table_sources: Dict[str, Dict[str, List[Dict]]] = {}  # table -> column -> sources
        self.processing_order: List[str] = []
        # DDL column definitions: table -> list of column names
        self.table_columns: Dict[str, List[str]] = {}
        # Maps normalized table name to full name with schema
        self.table_full_names: Dict[str, str] = {}
        # Per-table metadata for DML, JOIN, WHERE (table_name -> metadata)
        self.table_metadata: Dict[str, Dict[str, str]] = {}  # table -> {dml_operation, join_details, where_conditions, sttm}

    def process_directory(self, input_dir: str) -> Dict[str, Any]:
        """
        Process all SQL files in a directory.

        Args:
            input_dir: Directory containing SQL files

        Returns:
            Processing results
        """
        # Find and sort SQL files
        sql_files = self._discover_sql_files(input_dir)

        # Process each file in order
        for file_path in sql_files:
            self._process_file(file_path)

        return {
            "files_processed": len(self.file_lineages),
            "processing_order": self.processing_order,
            "tables_discovered": list(self.table_to_file.keys())
        }

    def _discover_sql_files(self, input_dir: str) -> List[str]:
        """
        Discover and sort SQL files by their execution order.

        Files are sorted by:
        1. Numeric prefix (00_, 01_, etc.)
        2. File type priority (.vw, .sql, .ddl)
        3. Alphabetically
        """
        sql_files = []

        for fname in os.listdir(input_dir):
            if fname.endswith(('.sql', '.vw', '.ddl')):
                file_path = os.path.join(input_dir, fname)
                order = self._get_file_order(fname)
                sql_files.append((order, fname, file_path))

        # Sort by order, then by type priority, then alphabetically
        type_priority = {'.vw': 0, '.sql': 1, '.ddl': 2}
        sql_files.sort(key=lambda x: (
            x[0],  # numeric order
            type_priority.get(os.path.splitext(x[1])[1], 99),
            x[1]  # filename
        ))

        return [f[2] for f in sql_files]

    def _get_file_order(self, filename: str) -> int:
        """Extract numeric order from filename prefix."""
        match = re.match(r'^(\d+)', filename)
        if match:
            return int(match.group(1))
        return 999  # No prefix, process last

    def _process_file(self, file_path: str) -> None:
        """Process a single SQL file and extract lineage."""
        _abs = _resolve_cli_path(file_path, must_be_under=_PROJECT_ROOT)
        file_path = safe_join(str(_abs.parent), secure_filename(_abs.name))
        file_name = os.path.basename(file_path)

        with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
            sql_content = f.read()

        try:
            # Normalise line endings and strip Teradata export artifacts (split identifiers)
            sql_content = sql_content.replace('\r\n', '\n').replace('\r', '\n')
            sql_content = re.sub(r'"\s*\n\s*"', '', sql_content)

            # Stored procedure path — use SQLHandler which knows how to extract DML from SPs
            sp_handler = SQLHandler(dialect=self.dialect)
            if sp_handler._is_stored_procedure(sql_content):
                result = sp_handler.process_content(sql_content, file_path)

                merged_graph = LineageGraph()
                all_targets: List[str] = []
                all_sources: List[str] = []
                column_mappings: Dict[str, List[Dict[str, Any]]] = {}

                for stmt in result.statements:
                    if stmt.lineage:
                        merged_graph.merge(stmt.lineage)
                    if stmt.target_table:
                        all_targets.append(stmt.target_table)
                    all_sources.extend(stmt.source_tables or [])

                for edge in (merged_graph.edges if merged_graph else []):
                    tgt_col = getattr(edge, 'target_column', None)
                    if tgt_col:
                        if tgt_col not in column_mappings:
                            column_mappings[tgt_col] = []
                        column_mappings[tgt_col].append({
                            'source_table': getattr(edge, 'source_table', ''),
                            'source_column': getattr(edge, 'source_column', ''),
                            'transformation': getattr(edge, 'transformation', ''),
                        })

                # Filter out volatile/temp tables as the primary target
                non_volatile = [t for t in all_targets if not re.search(r'\bvolatile\b|^#', t, re.IGNORECASE)]
                target_table = (non_volatile or all_targets or [''])[0]
                source_tables = list(dict.fromkeys(all_sources))

                file_info = FileLineageInfo(
                    file_path=file_path,
                    file_name=file_name,
                    file_order=self._get_file_order(file_name),
                    target_table=target_table,
                    source_tables=source_tables,
                    column_mappings=column_mappings,
                    lineage_graph=merged_graph,
                    sql_content=sql_content,
                    dml_operation="INSERT",
                )
                self.file_lineages[file_name] = file_info
                self.processing_order.append(file_name)

                if target_table:
                    norm_target = self._normalize_table_name(target_table)
                    if norm_target not in self.table_to_file:
                        self.table_to_file[norm_target] = file_name
                        if column_mappings:
                            self.table_sources[norm_target] = column_mappings
                        elif source_tables:
                            self.table_sources[norm_target] = self._create_passthrough_mappings(source_tables)
                return

            # Preprocess SQL for Teradata-specific syntax
            preprocessor = SQLASTGenerator(dialect=self.dialect)

            # Determine if this is DDL or SQL
            is_ddl = re.search(r'^\s*CREATE\s+(?:SET\s+|MULTISET\s+)?TABLE', sql_content, re.IGNORECASE)
            is_view = re.search(r'^\s*(?:CREATE|REPLACE)\s+VIEW', sql_content, re.IGNORECASE)
            
            if is_ddl:
                sql_to_parse = preprocessor.preprocess_teradata_ddl(sql_content)
            elif is_view or self.dialect.lower() == 'teradata':
                sql_to_parse = preprocessor.preprocess_teradata_sql(sql_content)
            else:
                sql_to_parse = sql_content
            
            # Try parsing with primary dialect first, then fallback dialects
            ast = None
            dialects_to_try = [self.dialect]

            # Add fallback dialects if primary fails
            if self.dialect != 'tsql':
                dialects_to_try.append('tsql')
            if self.dialect != 'teradata':
                dialects_to_try.append('teradata')
            dialects_to_try.append('')  # Generic SQL as last resort

            parse_error = None
            used_dialect = self.dialect
            for dialect in dialects_to_try:
                try:
                    ast = sqlglot.parse_one(sql_to_parse, read=dialect if dialect else None)
                    used_dialect = dialect if dialect else self.dialect
                    break  # Success, exit loop
                except Exception as e:
                    parse_error = e
                    continue

            if ast is None:
                raise parse_error if parse_error else Exception("Failed to parse SQL")

            # Extract target table
            target_table = self._get_target_table(ast)

            # Extract DDL column definitions for CREATE TABLE statements
            self._extract_ddl_columns(ast, target_table)

            # Extract source tables
            source_tables = self._get_source_tables(ast, target_table)

            # Extract column-level lineage (try with fallback dialects)
            lineage_graph = None
            for dialect in dialects_to_try:
                try:
                    temp_extractor = LineageExtractor(dialect=dialect if dialect else self.dialect)
                    lineage_graph = temp_extractor.extract_lineage(sql_to_parse)
                    if lineage_graph and lineage_graph.edges:
                        break
                except Exception:
                    continue

            if lineage_graph is None:
                lineage_graph = self.lineage_extractor.extract_lineage(sql_to_parse)

            # Build column mappings
            column_mappings = self._build_column_mappings(ast, lineage_graph)

            # For views that may use SELECT *, expand columns using DDL definitions
            if not column_mappings and source_tables:
                column_mappings = self._expand_select_star(ast, source_tables, target_table)
            elif not column_mappings and source_tables and file_name.lower().endswith('.vw'):
                column_mappings = self._extract_view_mappings(ast, source_tables, used_dialect)

            # Extract DML operation, join details, and where conditions
            dml_operation = self._get_dml_operation(ast)
            join_details = self._get_join_details(ast)
            where_conditions = self._get_where_conditions(ast)

            # Store file lineage info
            file_info = FileLineageInfo(
                file_path=file_path,
                file_name=file_name,
                file_order=self._get_file_order(file_name),
                target_table=target_table or "",
                source_tables=source_tables,
                column_mappings=column_mappings,
                lineage_graph=lineage_graph,
                ast=ast,
                sql_content=sql_content,
                dml_operation=dml_operation,
                join_details=join_details,
                where_conditions=where_conditions
            )

            self.file_lineages[file_name] = file_info
            self.processing_order.append(file_name)

            # Register table creation - include views even with no explicit column mappings
            # Prioritize SQL/View files over DDL files
            is_view = file_name.lower().endswith('.vw')
            is_sql = file_name.lower().endswith('.sql')
            is_ddl = file_name.lower().endswith('.ddl')

            if target_table:
                norm_target = self._normalize_table_name(target_table)

                # Views and SQL files should always be registered if they have sources
                # DDL files only if nothing else exists
                existing_file = self.table_to_file.get(norm_target)

                should_register = False
                if existing_file is None:
                    should_register = True
                elif is_view or is_sql:
                    # SQL/View files take priority
                    if existing_file.lower().endswith('.ddl'):
                        should_register = True
                    elif column_mappings and len(column_mappings) > len(self.table_sources.get(norm_target, {})):
                        should_register = True

                if should_register:
                    self.table_to_file[norm_target] = file_name
                    if column_mappings:
                        self.table_sources[norm_target] = column_mappings
                    elif source_tables:
                        # For views without explicit column mappings, create passthrough mappings
                        self.table_sources[norm_target] = self._create_passthrough_mappings(source_tables)

                    # Also register with _VW suffix if this is a view
                    if is_view and not norm_target.endswith('_VW'):
                        view_name = norm_target + '_VW'
                        self.table_to_file[view_name] = file_name
                        self.table_sources[view_name] = self.table_sources.get(norm_target, {})

        except Exception as e:
            print(f"Warning: Error processing {file_name}: {e}")

    def add_external_lineage(self, file_path: str, lineage_graph: LineageGraph,
                             target_table: str = None, source_tables: List[str] = None,
                             dml_operation: str = "", join_details: str = "", 
                             where_conditions: str = "") -> None:
        """
        Add lineage data from external processing (e.g., CLI's SQLHandler).

        This method allows importing lineage that was extracted using different
        parsing methods (like SQLHandler for stored procedures) instead of
        re-parsing the file with sqlglot.

        Args:
            file_path: Path to the SQL file
            lineage_graph: Pre-extracted LineageGraph from external processing
            target_table: Optional explicit target table name
            source_tables: Optional explicit list of source tables
            dml_operation: DML operation type (INSERT, CREATE VIEW, etc.)
            join_details: Join conditions from the query
            where_conditions: WHERE clause conditions
        """
        file_name = os.path.basename(file_path)

        # Skip if already processed with same or more edges
        if file_name in self.file_lineages:
            existing = self.file_lineages[file_name]
            if existing.lineage_graph and len(existing.lineage_graph.edges) >= len(lineage_graph.edges):
                return

        # Extract ALL target and source tables from lineage_graph
        extracted_targets = set()
        extracted_sources = set()

        for edge in lineage_graph.edges:
            if edge.target and hasattr(edge.target, 'table_name') and edge.target.table_name:
                extracted_targets.add(edge.target.table_name)
            if edge.source and hasattr(edge.source, 'table_name') and edge.source.table_name:
                extracted_sources.add(edge.source.table_name)

        # Use provided target_table or pick the most common one for FileLineageInfo
        primary_target = target_table
        if not primary_target and extracted_targets:
            primary_target = max(extracted_targets, key=lambda t: sum(1 for e in lineage_graph.edges if e.target and e.target.table_name == t))

        if not source_tables:
            # All tables that are sources but not targets
            source_tables = [t for t in extracted_sources if t not in extracted_targets]

        # Build column mappings PER TARGET TABLE for multi-target files
        # This is critical for files with multiple INSERT statements
        all_target_mappings: Dict[str, Dict[str, List[Dict[str, Any]]]] = {}

        for edge in lineage_graph.edges:
            if not edge.target or not edge.source:
                continue

            # IMPORTANT: Normalize target table name to prevent case mismatches
            # This also records the full name with schema for later retrieval
            target_tbl = self._normalize_table_name(edge.target.table_name) if edge.target.table_name else ""
            target_col = edge.target.column_name
            source_table = edge.source.table_name or ""
            source_col = edge.source.column_name or ""
            
            # Record source table full name (with schema if available)
            if source_table:
                self._normalize_table_name(source_table)  # Records full name mapping

            # Skip passthrough markers
            if target_col == "__PASSTHROUGH__":
                continue
            
            # Skip if target table is empty
            if not target_tbl:
                continue

            # Initialize target table's mappings if not exists
            if target_tbl not in all_target_mappings:
                all_target_mappings[target_tbl] = {}

            if target_col not in all_target_mappings[target_tbl]:
                all_target_mappings[target_tbl][target_col] = []

            transformation = ""
            transformation_type = "DIRECT"
            if edge.transformation:
                # Handle different transformation attribute structures
                if hasattr(edge.transformation, 'sql_expression') and edge.transformation.sql_expression:
                    transformation = edge.transformation.sql_expression
                elif hasattr(edge.transformation, 'expression') and edge.transformation.expression:
                    transformation = edge.transformation.expression
                
                if hasattr(edge.transformation, 'type') and edge.transformation.type:
                    transformation_type = edge.transformation.type.value if hasattr(edge.transformation.type, 'value') else str(edge.transformation.type)
                elif hasattr(edge.transformation, 'transformation_type'):
                    transformation_type = edge.transformation.transformation_type

            all_target_mappings[target_tbl][target_col].append({
                'source_table': source_table,
                'source_column': source_col,
                'transformation': transformation,
                'transformation_type': transformation_type
            })

        # Get combined column mappings for the primary target (for FileLineageInfo)
        column_mappings = all_target_mappings.get(primary_target, {})

        # Create FileLineageInfo with primary target
        file_info = FileLineageInfo(
            file_path=file_path,
            file_name=file_name,
            file_order=self._get_file_order(file_name),
            target_table=primary_target or "",
            source_tables=source_tables or [],
            column_mappings=column_mappings,
            lineage_graph=lineage_graph,
            ast=None,  # No AST from external processing
            sql_content="",  # Can be loaded later if needed
            dml_operation=dml_operation,
            join_details=join_details,
            where_conditions=where_conditions
        )

        self.file_lineages[file_name] = file_info

        # Only add to processing order if not already there
        if file_name not in self.processing_order:
            self.processing_order.append(file_name)

        # Register ALL target tables for cross-file stitching
        # This is critical for files with multiple INSERT statements
        registered_targets = []
        for tgt_table, tgt_mappings in all_target_mappings.items():
            if tgt_table:
                norm_target = self._normalize_table_name(tgt_table)
                self.table_to_file[norm_target] = file_name
                if tgt_mappings:
                    # IMPORTANT: Don't merge mappings from different target tables
                    # Each target table should have its own distinct column mappings
                    # Only merge if this is from the SAME target table being updated multiple times
                    if norm_target in self.table_sources:
                        existing = self.table_sources[norm_target]
                        for col, sources in tgt_mappings.items():
                            if col in existing:
                                # Only extend if sources are from the same source tables
                                # This prevents cross-contamination between different INSERT statements
                                existing_source_tables = {s.get('source_table', '').upper() for s in existing[col]}
                                for new_source in sources:
                                    new_source_table = new_source.get('source_table', '').upper()
                                    # Only add if not a duplicate
                                    is_duplicate = any(
                                        s.get('source_table', '').upper() == new_source_table and
                                        s.get('source_column', '').upper() == new_source.get('source_column', '').upper()
                                        for s in existing[col]
                                    )
                                    if not is_duplicate:
                                        existing[col].append(new_source)
                            else:
                                existing[col] = sources
                    else:
                        self.table_sources[norm_target] = tgt_mappings.copy()
                registered_targets.append(norm_target)

        # Also register source tables that might be intermediate tables from other files
        # This helps with stitching when source table names include schema prefixes
        for src_table in extracted_sources:
            norm_src = self._normalize_table_name(src_table)
            # Don't overwrite if already registered as a target
            if norm_src not in self.table_to_file:
                # Check if this source might match a registered target (schema prefix difference)
                for registered in self.table_sources.keys():
                    if norm_src == registered or norm_src.endswith(registered) or registered.endswith(norm_src):
                        # Create alias mapping
                        if norm_src not in self.table_sources:
                            self.table_sources[norm_src] = self.table_sources[registered]
                        break

        targets_str = ", ".join(registered_targets) if registered_targets else str(primary_target)
        print(f"  [E2E] Imported external lineage for {file_name}: {len(lineage_graph.edges)} edges, targets=[{targets_str}]")

    def add_table_metadata(self, table_name: str, dml_operation: str = "",
                           join_conditions: str = "", where_conditions: str = "",
                           sttm: str = "") -> None:
        """
        Add per-table metadata for DML operations, join/where conditions.
        
        This allows each target table to have its own specific metadata
        instead of aggregating all operations from the entire file.
        
        Args:
            table_name: The target table name
            dml_operation: The specific DML operation (CREATE VOLATILE TABLE, INSERT, etc.)
            join_conditions: JOIN conditions specific to this table
            where_conditions: WHERE conditions specific to this table
            sttm: The full SQL statement (Source To Target Mapping)
        """
        norm_table = self._normalize_table_name(table_name, record_full_name=False)
        if not norm_table:
            return
        
        self.table_metadata[norm_table] = {
            'dml_operation': dml_operation,
            'join_conditions': join_conditions,
            'where_conditions': where_conditions,
            'sttm': sttm
        }

    def get_table_metadata(self, table_name: str) -> Dict[str, str]:
        """
        Get per-table metadata for a specific table.
        
        Args:
            table_name: The table name to look up
            
        Returns:
            Dict with dml_operation, join_conditions, where_conditions, sttm
        """
        norm_table = self._normalize_table_name(table_name, record_full_name=False)
        return self.table_metadata.get(norm_table, {
            'dml_operation': '',
            'join_conditions': '',
            'where_conditions': '',
            'sttm': ''
        })

    def _get_target_table(self, ast: exp.Expression) -> Optional[str]:
        """Get target table from AST."""
        if isinstance(ast, exp.Insert):
            table = ast.this
            if isinstance(table, exp.Table):
                return self._format_table_name(table)
            elif hasattr(table, 'this') and isinstance(table.this, exp.Table):
                return self._format_table_name(table.this)
        elif isinstance(ast, exp.Create):
            if hasattr(ast, 'this'):
                if isinstance(ast.this, exp.Table):
                    return self._format_table_name(ast.this)
                elif hasattr(ast.this, 'this') and isinstance(ast.this.this, exp.Table):
                    return self._format_table_name(ast.this.this)
        return None

    def _format_table_name(self, table: exp.Table) -> str:
        """Format table name with schema if present."""
        name = table.name
        if hasattr(table, 'db') and table.db:
            name = f"{table.db}.{name}"
        return name

    def _get_source_tables(self, ast: exp.Expression, target_table: Optional[str]) -> List[str]:
        """Get all source tables from AST."""
        tables = set()
        target_normalized = self._normalize_table_name(target_table) if target_table else ""

        for table in ast.find_all(exp.Table):
            name = self._format_table_name(table)
            # This call records the full name with schema
            norm_name = self._normalize_table_name(name)

            # Skip target table
            if norm_name != target_normalized:
                tables.add(name)
                # Also explicitly record the full name for this normalized name
                if name and '.' in name:
                    self.table_full_names[norm_name] = name.upper()

        return list(tables)

    def _get_dml_operation(self, ast: exp.Expression) -> str:
        """Extract DML operation type from AST."""
        if isinstance(ast, exp.Insert):
            return "INSERT"
        elif isinstance(ast, exp.Create):
            kind = getattr(ast, 'kind', None)
            if kind:
                return f"CREATE {kind.upper()}"
            elif ast.args.get('kind'):
                return f"CREATE {ast.args['kind'].upper()}"
            # Check for view
            if ast.find(exp.Select):
                return "CREATE VIEW"
            return "CREATE TABLE"
        elif isinstance(ast, exp.Update):
            return "UPDATE"
        elif isinstance(ast, exp.Delete):
            return "DELETE"
        elif isinstance(ast, exp.Merge):
            return "MERGE"
        elif isinstance(ast, exp.Select):
            return "SELECT"
        return ""

    def _get_join_details(self, ast: exp.Expression) -> str:
        """Extract join conditions from AST."""
        joins = []
        
        for join in ast.find_all(exp.Join):
            join_type = ""
            if hasattr(join, 'kind') and join.kind:
                join_type = join.kind.upper()
            elif hasattr(join, 'side') and join.side:
                join_type = join.side.upper()
            else:
                join_type = "INNER"
            
            # Get joined table
            table_name = ""
            if hasattr(join, 'this') and isinstance(join.this, exp.Table):
                table_name = self._format_table_name(join.this)
            elif hasattr(join, 'this'):
                table_name = str(join.this)[:50]
            
            # Get join condition
            on_clause = ""
            if hasattr(join, 'args') and 'on' in join.args and join.args['on']:
                on_clause = str(join.args['on'])[:100]
            
            if table_name:
                join_str = f"{join_type} JOIN: {table_name}"
                if on_clause:
                    join_str += f" ON {on_clause}"
                joins.append(join_str)
        
        return " | ".join(joins)

    def _get_where_conditions(self, ast: exp.Expression) -> str:
        """Extract WHERE clause conditions from AST."""
        wheres = []
        
        for where in ast.find_all(exp.Where):
            if hasattr(where, 'this') and where.this:
                condition = str(where.this)[:200]
                wheres.append(condition)
        
        return " AND ".join(wheres)

    def _normalize_table_name(self, name: str, record_full_name: bool = True) -> str:
        """Normalize table name for comparison (simple uppercase, no schema).
        
        Also records the full name with schema if provided.
        
        Args:
            name: The table name (possibly with schema prefix)
            record_full_name: If True, record mapping from normalized to full name
            
        Returns:
            Normalized table name (uppercase, no schema)
        """
        if not name:
            return ""
        # Remove schema prefix for comparison
        parts = name.split('.')
        normalized = parts[-1].upper().strip()
        
        # Record full name with schema if it's a new or better entry
        if record_full_name and '.' in name:
            full_name = name.upper().strip()
            # Prefer names with schema over names without
            if normalized not in self.table_full_names or '.' not in self.table_full_names[normalized]:
                self.table_full_names[normalized] = full_name
        
        return normalized

    def _get_full_table_name(self, normalized_name: str) -> str:
        """Get full table name with schema from normalized name.
        
        Args:
            normalized_name: The normalized table name (without schema)
            
        Returns:
            Full table name with schema if available, else normalized name
        """
        if not normalized_name:
            return ""
        normalized = normalized_name.upper().strip()
        return self.table_full_names.get(normalized, normalized)

    def _is_arithmetic_literal(self, source_column: str) -> bool:
        """
        Check if a hardcoded source column is an arithmetic literal.
        
        Arithmetic literals like 100, 2, -1 are often used in expressions
        like EXTRACT(YEAR FROM date) * 100 + EXTRACT(MONTH FROM date)
        and should not be treated as meaningful hardcoded sources.
        
        Args:
            source_column: The source column value (e.g., "NUMBER: 100")
            
        Returns:
            True if this is an arithmetic literal, False otherwise
        """
        if not source_column or not source_column.startswith('NUMBER:'):
            return False
        
        # Extract the number value
        try:
            num_str = source_column.replace('NUMBER:', '').strip()
            num = float(num_str)
            # Common arithmetic literals used in date calculations
            # 100, -1, -2, 2, 12, etc. are often used in expressions
            arithmetic_literals = {100, -100, 1, -1, 2, -2, 12, -12, 0, 10, -10}
            return num in arithmetic_literals or (abs(num) <= 12 and num == int(num))
        except (ValueError, TypeError):
            return False

    def _resolve_table_name(self, name: str) -> str:
        """
        Resolve table name to find matching entry in registry.
        Handles _VW suffix variations for views.

        Resolution priority:
        1. Exact match in table_sources
        2. Exact match in table_to_file (base tables from DDL)
        3. Without _VW suffix (views -> base tables)
        4. With _VW suffix ONLY if the base name doesn't exist anywhere
        """
        if not name:
            return ""

        # Get the base name without schema
        parts = name.split('.')
        base = parts[-1].upper().strip()

        # 1. Direct match in table_sources (highest priority)
        if base in self.table_sources:
            return base

        # 2. Check table_to_file (base tables defined by DDL)
        # This is important - if a table is known (even from DDL), return it
        if base in self.table_to_file:
            return base

        # 3. Try without _VW suffix (e.g., TDA_AGREEMENT_WRK_1_VW -> TDA_AGREEMENT_WRK_1)
        if base.endswith('_VW'):
            without_vw = base[:-3]
            if without_vw in self.table_sources:
                return without_vw
            if without_vw in self.table_to_file:
                return without_vw

        # 4. Try adding _VW suffix ONLY if the base name is completely unknown
        # This helps when code references a table but the actual definition is a view
        # BUT: only do this if the base table isn't registered anywhere
        if base not in self.table_to_file:
            with_vw = base + '_VW'
            if with_vw in self.table_sources:
                return with_vw
            if with_vw in self.table_to_file:
                return with_vw

        # Return the normalized name even if not found
        return base

    def _extract_ddl_columns(self, ast: exp.Expression, table_name: str) -> None:
        """Extract column definitions from CREATE TABLE DDL and store them."""
        if not table_name:
            return

        # Check if this is a CREATE statement with column definitions
        if isinstance(ast, exp.Create):
            columns = []
            # Look for column definitions in the schema
            schema = ast.this
            if schema and hasattr(schema, 'expressions'):
                for col_def in schema.expressions:
                    if isinstance(col_def, exp.ColumnDef):
                        col_name = col_def.name
                        if col_name:
                            columns.append(col_name.upper())

            if columns:
                norm_table = table_name.upper()
                self.table_columns[norm_table] = columns
                # Also store without database prefix
                parts = norm_table.split('.')
                if len(parts) > 1:
                    short_name = parts[-1]
                    self.table_columns[short_name] = columns

    def _expand_select_star(self, ast: exp.Expression, source_tables: List[str],
                            target_table: str) -> Dict[str, List[Dict[str, Any]]]:
        """Expand SELECT * by looking up source table column definitions."""
        mappings = {}

        # Check if this is a SELECT * statement
        select = ast.find(exp.Select)
        if not select:
            return mappings

        has_star = any(isinstance(expr, exp.Star) for expr in select.expressions)
        if not has_star:
            return mappings

        # Find columns for source tables
        for source_table in source_tables:
            norm_source = source_table.upper()
            columns = None

            # Try exact match
            if norm_source in self.table_columns:
                columns = self.table_columns[norm_source]
            else:
                # Try without database prefix
                source_parts = norm_source.split('.')
                short_name = source_parts[-1] if source_parts else norm_source
                if short_name in self.table_columns:
                    columns = self.table_columns[short_name]

            if columns:
                for col in columns:
                    if col not in mappings:
                        mappings[col] = []
                    mappings[col].append({
                        "source_table": source_table,
                        "source_column": col,
                        "transformation": "",
                        "transformation_type": "DIRECT"
                    })

        return mappings

    def _build_column_mappings(self, ast: exp.Expression,
                                lineage_graph: LineageGraph) -> Dict[str, List[Dict[str, Any]]]:
        """Build column-level mappings from AST and lineage graph."""
        mappings = defaultdict(list)

        # Build alias map to resolve table aliases to actual table names
        alias_map = self._build_alias_map(ast)

        # Get default source table (first table in FROM clause)
        default_source = self._get_default_source_table(ast)

        for edge in lineage_graph.edges:
            target_col = edge.target.column_name
            source_table = edge.source.table_name

            # Resolve alias to actual table name
            if source_table:
                norm_alias = source_table.upper()
                if norm_alias in alias_map:
                    source_table = alias_map[norm_alias]

            # If source table is empty, use default source
            if not source_table or source_table == '':
                source_table = default_source
            
            # Record source table full name (with schema if available)
            if source_table:
                self._normalize_table_name(source_table)  # Records full name mapping

            source_info = {
                "source_table": source_table,
                "source_column": edge.source.column_name,
                "transformation": edge.transformation.sql_expression if edge.transformation else "",
                "transformation_type": (edge.transformation.type.value if hasattr(edge.transformation.type, 'value') else str(edge.transformation.type)) if edge.transformation and edge.transformation.type else "UNKNOWN"
            }
            mappings[target_col].append(source_info)

        return dict(mappings)

    def _build_alias_map(self, ast: exp.Expression) -> Dict[str, str]:
        """Build map of table aliases to actual table names."""
        alias_map = {}

        # Find all table references with aliases
        for table in ast.find_all(exp.Table):
            table_name = self._format_table_name(table)
            alias = table.alias if hasattr(table, 'alias') and table.alias else None
            if alias:
                alias_map[alias.upper()] = table_name

        # Also check for subquery aliases that reference actual tables
        for subquery in ast.find_all(exp.Subquery):
            alias = subquery.alias if hasattr(subquery, 'alias') and subquery.alias else None
            if alias:
                # Try to find the main table in the subquery
                inner_tables = list(subquery.find_all(exp.Table))
                if inner_tables:
                    # Use the first table as the representative
                    main_table = self._format_table_name(inner_tables[0])
                    alias_map[alias.upper()] = main_table

        return alias_map

    def _get_default_source_table(self, ast: exp.Expression) -> str:
        """Get the default source table from FROM clause."""
        from_clause = ast.find(exp.From)
        if from_clause and from_clause.this:
            if isinstance(from_clause.this, exp.Table):
                return self._format_table_name(from_clause.this)
        return ""

    def _extract_view_mappings(self, ast: exp.Expression, source_tables: List[str],
                                dialect: str) -> Dict[str, List[Dict[str, Any]]]:
        """
        Extract column mappings from a view, including SELECT * expansion.

        Args:
            ast: Parsed AST of the view
            source_tables: List of source tables in the view
            dialect: SQL dialect used for parsing

        Returns:
            Column mappings dictionary
        """
        mappings = defaultdict(list)

        # Try to find SELECT expressions
        select = ast.find(exp.Select)
        if not select:
            return dict(mappings)

        # Get default source table
        default_source = source_tables[0] if source_tables else ""

        # Check for SELECT *
        for col in select.expressions:
            if isinstance(col, exp.Star):
                # SELECT * - try to get columns from source table info
                # For now, create a marker that indicates passthrough
                pass
            elif isinstance(col, exp.Column):
                col_name = col.name
                source_table = col.table if hasattr(col, 'table') and col.table else default_source
                mappings[col_name].append({
                    "source_table": source_table or default_source,
                    "source_column": col_name,
                    "transformation": col_name,
                    "transformation_type": "DIRECT"
                })
            elif hasattr(col, 'alias') and col.alias:
                # Aliased expression
                alias = col.alias
                # Try to extract the source column
                inner_cols = list(col.find_all(exp.Column))
                if inner_cols:
                    source_col = inner_cols[0]
                    source_table = source_col.table if hasattr(source_col, 'table') and source_col.table else default_source
                    mappings[alias].append({
                        "source_table": source_table or default_source,
                        "source_column": source_col.name,
                        "transformation": col.sql() if hasattr(col, 'sql') else alias,
                        "transformation_type": "TRANSFORMATION"
                    })

        return dict(mappings)

    def _create_passthrough_mappings(self, source_tables: List[str]) -> Dict[str, List[Dict[str, Any]]]:
        """
        Create passthrough mappings for views that reference source tables.
        This serves as a placeholder to mark that this view reads from source tables.

        Args:
            source_tables: List of source tables

        Returns:
            Column mappings with passthrough indicator
        """
        mappings = {}
        if source_tables:
            # Create a special marker entry to indicate this view/table reads from sources
            main_source = source_tables[0]
            mappings["__PASSTHROUGH__"] = [{
                "source_table": main_source,
                "source_column": "*",
                "transformation": f"SELECT * FROM {main_source}",
                "transformation_type": "PASSTHROUGH"
            }]
        return mappings

    def extract_end_to_end_lineage(self, target_table: str = None) -> List[EndToEndColumnLineage]:
        """
        Extract complete end-to-end lineage for all columns.

        Args:
            target_table: Optional specific target table (defaults to all target tables)

        Returns:
            List of EndToEndColumnLineage objects
        """
        end_to_end_lineages = []

        # Find target table(s)
        if target_table:
            target_tables = [self._normalize_table_name(target_table)]
        else:
            # Use ALL tables in the registry - this includes tables from both
            # the stored procedure (imported via add_external_lineage) and
            # schema files (processed via process_directory)
            target_tables = list(self.table_sources.keys())

        # For each target table, trace each column back to ultimate sources
        for norm_target in target_tables:
            if norm_target not in self.table_sources:
                continue

            column_mappings = self.table_sources[norm_target]

            for target_col, sources in column_mappings.items():
                # Skip passthrough marker columns - these are placeholders, not real columns
                if target_col == "__PASSTHROUGH__":
                    continue
                
                # Skip star (*) columns - these are not useful for column-level lineage
                if target_col == "*" or target_col.strip() == "":
                    continue
                
                # Deduplicate sources to prevent duplicate traces
                # Key: source_table.source_column
                seen_sources = set()
                unique_sources = []
                for source in sources:
                    src_key = f"{source.get('source_table', '')}.{source.get('source_column', '')}".upper()
                    if src_key not in seen_sources:
                        seen_sources.add(src_key)
                        unique_sources.append(source)
                
                # Trace each unique source back to its ultimate origin
                # FIXED: Filter out [HARDCODED] sources if there are real column sources
                has_real_columns = any(
                    s.get('source_table', '') not in ('[HARDCODED]', '', None)
                    for s in unique_sources
                )
                
                for source in unique_sources:
                    # Skip HARDCODED sources if we have real column sources
                    source_table = source.get('source_table', '')
                    if has_real_columns and source_table == '[HARDCODED]':
                        continue
                        
                    lineage = self._trace_column_to_source(
                        norm_target, target_col, source
                    )
                    if lineage:
                        end_to_end_lineages.append(lineage)

        return end_to_end_lineages

    def get_all_file_lineages(self) -> List[Dict[str, Any]]:
        """
        Get ALL lineage edges from all processed files.

        This provides complete per-file lineage data instead of just
        end-to-end traced paths. This is critical for getting the full
        picture of column-level transformations.

        Returns:
            List of dicts with source, target, file, and transformation info
        """
        all_edges = []

        for file_name in self.processing_order:
            if file_name not in self.file_lineages:
                continue

            file_info = self.file_lineages[file_name]
            lineage_graph = file_info.lineage_graph

            if not lineage_graph or not lineage_graph.edges:
                continue

            for edge in lineage_graph.edges:
                # Get transformation info
                transform = ""
                transform_type = "UNKNOWN"
                transform_subtype = "UNKNOWN"

                if edge.transformation:
                    transform = edge.transformation.sql_expression or ""
                    if edge.transformation.type:
                        transform_type = edge.transformation.type.value if hasattr(edge.transformation.type, 'value') else str(edge.transformation.type)
                    if edge.transformation.subtype:
                        transform_subtype = edge.transformation.subtype.value if hasattr(edge.transformation.subtype, 'value') else str(edge.transformation.subtype)

                # Record source table full name (with schema if available)
                source_tbl = edge.source.table_name or ""
                if source_tbl:
                    self._normalize_table_name(source_tbl)  # Records full name mapping

                all_edges.append({
                    "source_file": file_name,
                    "target_table": self._get_full_table_name(file_info.target_table) if file_info.target_table else "",
                    "source_table": self._get_full_table_name(source_tbl) if source_tbl else "",
                    "source_column": edge.source.column_name or "",
                    "target_column": edge.target.column_name or "",
                    "transformation": transform,
                    "transformation_type": transform_type,
                    "transformation_subtype": transform_subtype
                })

        return all_edges

    def _trace_column_to_source(self, target_table: str, target_col: str,
                                 initial_source: Dict[str, Any]) -> Optional[EndToEndColumnLineage]:
        """
        Trace a column back through all hops to its ultimate source.

        Args:
            target_table: Final target table name
            target_col: Target column name
            initial_source: Initial source mapping

        Returns:
            EndToEndColumnLineage or None
        """
        hops = []
        visited = set()
        transformations = []
        lookup_tables = set()  # Track lookup/reference tables that contribute data

        # Pattern to identify actual lookup/reference tables
        import re
        lookup_pattern = re.compile(r'^(LKP_|PM_[Aa]lkp_|CODE_TRANSLATION|SRC_STG_CTL|SRC_STG_INFO)', re.IGNORECASE)

        # Collect lookup tables that appear in each file's source_tables but aren't in main chain
        main_chain_tables = set()

        # Start from target
        current_table = target_table
        current_col = target_col
        current_transform = initial_source.get("transformation", "")
        current_transform_type = initial_source.get("transformation_type", "UNKNOWN")

        # Get the file that created this target
        source_file = self.table_to_file.get(current_table, "")

        # Add final hop (target)
        hops.append(ColumnHop(
            table_name=current_table,
            column_name=current_col,
            transformation=current_transform,
            transformation_type=current_transform_type,
            source_file=source_file,
            hop_number=0
        ))
        main_chain_tables.add(current_table)

        if current_transform and current_transform != current_col:
            transformations.append(current_transform)

        # Collect lookup/reference tables from the file that creates this target
        if source_file and source_file in self.file_lineages:
            all_sources = self.file_lineages[source_file].source_tables
            for src in all_sources:
                norm_src = self._normalize_table_name(src)
                # Only add if it matches lookup pattern and not in main chain
                if norm_src not in main_chain_tables and lookup_pattern.match(norm_src):
                    lookup_tables.add(norm_src)

        # Trace backwards through source tables
        source_table = self._resolve_table_name(initial_source.get("source_table", ""))
        source_col = initial_source.get("source_column", "")

        max_depth = 20  # Prevent infinite loops
        depth = 0

        while source_table and depth < max_depth:
            hop_key = f"{source_table}.{source_col}"
            if hop_key in visited:
                break
            visited.add(hop_key)

            depth += 1
            main_chain_tables.add(source_table)
            # Remove from lookup tables if it was added there
            lookup_tables.discard(source_table)

            # Check if this source table is an intermediate table we have lineage for
            resolved_table = self._resolve_table_name(source_table)
            if resolved_table in self.table_sources:
                # CRITICAL FIX: Verify the column actually exists in this table's mappings
                # This prevents false hops through tables that don't have this column
                table_columns = set(self.table_sources[resolved_table].keys())
                
                # Check if this column is actually a TARGET column in this table
                # (meaning it was written to this table, not just read from somewhere)
                column_is_target_in_table = source_col in table_columns or source_col.upper() in {c.upper() for c in table_columns}
                
                if not column_is_target_in_table:
                    # This column doesn't exist as a target in this table
                    # It might be a passthrough or a column from a different table with same name
                    # Don't add this as a hop, just try to trace further
                    # This is an ultimate source for this path
                    hops.append(ColumnHop(
                        table_name=source_table,
                        column_name=source_col,
                        transformation=source_col,
                        transformation_type="SOURCE",
                        source_file="",
                        hop_number=depth
                    ))
                    break
                
                # Get the lineage for this column in this table
                col_sources = self.table_sources[resolved_table].get(source_col, [])
                # Also try case-insensitive match
                if not col_sources:
                    for col_key in table_columns:
                        if col_key.upper() == source_col.upper():
                            col_sources = self.table_sources[resolved_table].get(col_key, [])
                            break
                
                source_table = resolved_table  # Use resolved name

                # Collect lookup/reference tables from this file
                file_for_table = self.table_to_file.get(resolved_table, "")
                if file_for_table and file_for_table in self.file_lineages:
                    all_sources = self.file_lineages[file_for_table].source_tables
                    for src in all_sources:
                        norm_src = self._normalize_table_name(src)
                        # Only add if it matches lookup pattern and not in main chain
                        if norm_src not in main_chain_tables and lookup_pattern.match(norm_src):
                            lookup_tables.add(norm_src)

                if col_sources:
                    # Use the first source mapping
                    prev_source = col_sources[0]
                    transform = prev_source.get("transformation", source_col)
                    transform_type = prev_source.get("transformation_type", "UNKNOWN")

                    # Add this hop
                    hops.append(ColumnHop(
                        table_name=source_table,
                        column_name=source_col,
                        transformation=transform,
                        transformation_type=transform_type,
                        source_file=self.table_to_file.get(source_table, ""),
                        hop_number=depth
                    ))

                    if transform and transform != source_col:
                        transformations.append(transform)

                    # Move to next source
                    source_table = self._resolve_table_name(prev_source.get("source_table", ""))
                    source_col = prev_source.get("source_column", "")
                else:
                    # No further lineage, this is an intermediate stop
                    hops.append(ColumnHop(
                        table_name=source_table,
                        column_name=source_col,
                        transformation=source_col,
                        transformation_type="DIRECT",
                        source_file=self.table_to_file.get(source_table, ""),
                        hop_number=depth
                    ))
                    break
            else:
                # This is an ultimate source (not created by any of our SQL files)
                hops.append(ColumnHop(
                    table_name=source_table,
                    column_name=source_col,
                    transformation=source_col,
                    transformation_type="SOURCE",
                    source_file="",
                    hop_number=depth
                ))
                break

        # Reverse hops so they go from source to target
        hops = list(reversed(hops))

        # Renumber hops
        for i, hop in enumerate(hops):
            hop.hop_number = i

        # Get ultimate source (first hop after reversal)
        if hops:
            ultimate_source = hops[0]

            # Filter out main chain tables from lookup tables (they might have been added incorrectly)
            # Use full table names with schema for lookup tables
            final_lookups = sorted([self._get_full_table_name(t) for t in lookup_tables if t not in main_chain_tables])

            # Get DML operation, join details, and where conditions
            # PRIORITY: Use per-table metadata first, then fall back to file-level metadata
            dml_operation = ""
            join_details = ""
            where_conditions = ""
            
            # First try per-table metadata (more specific)
            table_meta = self.get_table_metadata(target_table)
            if table_meta.get('dml_operation'):
                dml_operation = table_meta['dml_operation']
                join_details = table_meta.get('join_conditions', '')
                where_conditions = table_meta.get('where_conditions', '')
            else:
                # Fall back to file-level metadata
                target_source_file = self.table_to_file.get(target_table, "")
                if target_source_file and target_source_file in self.file_lineages:
                    file_info = self.file_lineages[target_source_file]
                    dml_operation = file_info.dml_operation
                    join_details = file_info.join_details
                    where_conditions = file_info.where_conditions
            
            # Also include lookup tables from file_info.source_tables
            target_source_file = self.table_to_file.get(target_table, "")
            if target_source_file and target_source_file in self.file_lineages:
                file_info = self.file_lineages[target_source_file]
                if file_info.source_tables:
                    for src in file_info.source_tables:
                        norm_src = self._normalize_table_name(src)
                        if norm_src not in main_chain_tables:
                            final_lookups.append(self._get_full_table_name(norm_src))
                    final_lookups = sorted(set(final_lookups))

            # Convert all table names in hops to full names with schema
            for hop in hops:
                hop.table_name = self._get_full_table_name(hop.table_name)

            return EndToEndColumnLineage(
                target_table=self._get_full_table_name(target_table),
                target_column=target_col,
                ultimate_source_table=self._get_full_table_name(ultimate_source.table_name),
                ultimate_source_column=ultimate_source.column_name,
                hop_count=len(hops) - 1,  # Exclude target itself
                hops=hops,
                full_transformation_chain=" ->".join(reversed(transformations)) if transformations else target_col,
                lookup_tables=final_lookups,
                dml_operation=dml_operation,
                join_details=join_details,
                where_conditions=where_conditions
            )

        return None

    def export_end_to_end_csv(self, output_path: str,
                               target_table: str = None) -> None:
        """
        Export end-to-end lineage to CSV.

        Args:
            output_path: Output CSV file path
            target_table: Optional specific target table
        """
        lineages = self.extract_end_to_end_lineage(target_table)

        if not lineages:
            print("No end-to-end lineage found to export")
            return

        # FIXED: Filter out rows with various issues:
        # 1. * source column
        # 2. Pure HARDCODED sources with * column
        # 3. Self-referencing rows (same source and target table/column with hop_count=0)
        # 4. Hardcoded arithmetic literals (NUMBER: followed by small integers used in expressions)
        filtered_lineages = [
            l for l in lineages 
            if l.ultimate_source_column != '*' 
            and not (l.ultimate_source_table == '[HARDCODED]' and l.ultimate_source_column == '*')
            # Filter self-referencing: same table and column with no transformation
            and not (l.hop_count == 0 
                     and self._normalize_table_name(l.ultimate_source_table, record_full_name=False) == self._normalize_table_name(l.target_table, record_full_name=False)
                     and l.ultimate_source_column.upper() == l.target_column.upper())
            # Filter arithmetic literals that are not meaningful hardcoded values
            and not (l.ultimate_source_table == '[HARDCODED]' 
                     and l.ultimate_source_column.startswith('NUMBER:') 
                     and self._is_arithmetic_literal(l.ultimate_source_column))
        ]
        
        rows = [l.to_csv_row() for l in filtered_lineages]

        with open(output_path, 'w', newline='', encoding='utf-8') as f:
            writer = csv.DictWriter(f, fieldnames=rows[0].keys())
            writer.writeheader()
            writer.writerows(rows)

        print(f"Exported {len(rows)} end-to-end lineage rows to {output_path}")

    def export_comprehensive_csv(self, output_path: str) -> None:
        """
        Export comprehensive lineage with all details to CSV.

        Includes all hops, transformations at each stage, and file sources.
        """
        lineages = self.extract_end_to_end_lineage()

        rows = []
        for lineage in lineages:
            # Create a row for each hop
            for i, hop in enumerate(lineage.hops):
                is_source = i == 0
                is_target = i == len(lineage.hops) - 1

                next_hop = lineage.hops[i + 1] if i < len(lineage.hops) - 1 else None

                rows.append({
                    "Target_Table": lineage.target_table,
                    "Target_Column": lineage.target_column,
                    "Ultimate_Source_Table": lineage.ultimate_source_table,
                    "Ultimate_Source_Column": lineage.ultimate_source_column,
                    "Hop_Number": hop.hop_number,
                    "Hop_Table": hop.table_name,
                    "Hop_Column": hop.column_name,
                    "Transformation_At_Hop": hop.transformation,
                    "Transformation_Type": hop.transformation_type,
                    "Source_File": hop.source_file,
                    "Is_Ultimate_Source": "Yes" if is_source else "No",
                    "Is_Final_Target": "Yes" if is_target else "No",
                    "Next_Table": next_hop.table_name if next_hop else "",
                    "Next_Column": next_hop.column_name if next_hop else "",
                    "Total_Hops": lineage.hop_count,
                    "Full_Data_Flow": " ->".join([f"{h.table_name}.{h.column_name}" for h in lineage.hops])
                })

        if rows:
            with open(output_path, 'w', newline='', encoding='utf-8') as f:
                writer = csv.DictWriter(f, fieldnames=rows[0].keys())
                writer.writeheader()
                writer.writerows(rows)

            print(f"Exported {len(rows)} comprehensive lineage rows to {output_path}")

    def export_json(self, output_path: str) -> None:
        """Export complete lineage analysis to JSON."""
        _abs = _resolve_cli_path(output_path, must_be_under=_PROJECT_ROOT)
        output_path = safe_join(str(_abs.parent), secure_filename(_abs.name))
        lineages = self.extract_end_to_end_lineage()

        output = {
            "processing_order": self.processing_order,
            "files_processed": [
                {
                    "file_name": info.file_name,
                    "target_table": info.target_table,
                    "source_tables": info.source_tables,
                    "column_count": len(info.column_mappings)
                }
                for info in self.file_lineages.values()
            ],
            "table_registry": {
                table: self.table_to_file.get(table, "")
                for table in self.table_sources.keys()
            },
            "end_to_end_lineage": [l.to_dict() for l in lineages],
            "statistics": {
                "total_columns_traced": len(lineages),
                "max_hop_count": max((l.hop_count for l in lineages), default=0),
                "avg_hop_count": sum(l.hop_count for l in lineages) / len(lineages) if lineages else 0,
                "unique_ultimate_sources": len(set(l.ultimate_source_table for l in lineages))
            }
        }

        with open(output_path, 'w', encoding='utf-8') as f:
            json.dump(output, f, indent=2)

        print(f"Exported lineage analysis to {output_path}")

    def export_html_tree(self, output_path: str, title: str = "End-to-End Data Lineage") -> None:
        """
        Export end-to-end lineage as an interactive HTML tree visualization.
        Shows full data flow from ultimate sources through all intermediate tables to targets.
        """
        lineages = self.extract_end_to_end_lineage()

        # Build tree structure: group by target column, show full path
        tree_data = self._build_tree_structure(lineages)

        html_content = self._generate_tree_html(tree_data, title)

        with open(output_path, 'w', encoding='utf-8') as f:
            f.write(html_content)

        print(f"Exported HTML tree visualization to {output_path}")

    def _build_tree_structure(self, lineages: List[EndToEndColumnLineage]) -> Dict[str, Any]:
        """Build hierarchical tree structure from lineages."""
        # Group by target table
        by_target = defaultdict(list)
        for lineage in lineages:
            by_target[lineage.target_table].append(lineage)

        # Build tree with tables as top level
        tree = {
            "name": "Data Lineage",
            "children": []
        }

        for target_table, target_lineages in by_target.items():
            table_node = {
                "name": target_table,
                "type": "target_table",
                "children": []
            }

            # Group by target column
            by_column = defaultdict(list)
            for lin in target_lineages:
                by_column[lin.target_column].append(lin)

            for target_col, col_lineages in by_column.items():
                # Pick the lineage with most hops (most complete path)
                best_lineage = max(col_lineages, key=lambda x: x.hop_count)

                col_node = {
                    "name": target_col,
                    "type": "target_column",
                    "hops": best_lineage.hop_count,
                    "children": []
                }

                # Build path from source to target
                if best_lineage.hops:
                    path_node = self._build_path_node(best_lineage)
                    col_node["children"].append(path_node)

                table_node["children"].append(col_node)

            tree["children"].append(table_node)

        return tree

    def _build_path_node(self, lineage: EndToEndColumnLineage) -> Dict[str, Any]:
        """Build a node representing the full data path."""
        # Create chain: source -> intermediate -> ... -> target
        if not lineage.hops:
            return {"name": "No path", "type": "empty"}

        # Start from source (first hop)
        root = None
        current = None

        for i, hop in enumerate(lineage.hops):
            node = {
                "name": f"{hop.table_name}.{hop.column_name}",
                "type": "source" if i == 0 else ("target" if i == len(lineage.hops) - 1 else "intermediate"),
                "transformation": hop.transformation if hop.transformation != hop.column_name else "",
                "source_file": hop.source_file,
                "children": []
            }

            if root is None:
                root = node
                current = node
            else:
                current["children"] = [node]
                current = node

        return root

    def _generate_tree_html(self, tree_data: Dict[str, Any], title: str) -> str:
        """Generate HTML with collapsible tree visualization."""
        # Convert tree to JSON for JavaScript
        tree_json = json.dumps(tree_data, indent=2)

        # Get statistics
        lineages = self.extract_end_to_end_lineage()
        stats = {
            "total_columns": len(lineages),
            "max_hops": max((l.hop_count for l in lineages), default=0),
            "tables": list(self.table_sources.keys()),
            "files": [f for f in self.processing_order if f.endswith(('.sql', '.vw'))]
        }

        html = f'''<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{title}</title>
    <style>
        * {{
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }}
        body {{
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #1a1a2e 0%, #16213e 100%);
            color: #eee;
            min-height: 100vh;
            padding: 20px;
        }}
        .container {{
            max-width: 1400px;
            margin: 0 auto;
        }}
        h1 {{
            text-align: center;
            margin-bottom: 10px;
            color: #4fc3f7;
            font-size: 2em;
        }}
        .subtitle {{
            text-align: center;
            color: #aaa;
            margin-bottom: 20px;
        }}
        .stats-bar {{
            display: flex;
            justify-content: center;
            gap: 30px;
            margin-bottom: 20px;
            flex-wrap: wrap;
        }}
        .stat {{
            background: rgba(79, 195, 247, 0.1);
            border: 1px solid #4fc3f7;
            border-radius: 8px;
            padding: 10px 20px;
            text-align: center;
        }}
        .stat-value {{
            font-size: 1.5em;
            font-weight: bold;
            color: #4fc3f7;
        }}
        .stat-label {{
            font-size: 0.85em;
            color: #aaa;
        }}
        .data-flow {{
            background: rgba(255,255,255,0.05);
            border-radius: 8px;
            padding: 15px;
            margin-bottom: 20px;
            text-align: center;
        }}
        .data-flow h3 {{
            color: #4fc3f7;
            margin-bottom: 10px;
        }}
        .flow-chain {{
            display: flex;
            align-items: center;
            justify-content: center;
            flex-wrap: wrap;
            gap: 10px;
        }}
        .flow-table {{
            background: linear-gradient(135deg, #2d5a7b, #1e3d5a);
            padding: 8px 16px;
            border-radius: 20px;
            font-weight: bold;
        }}
        .flow-arrow {{
            color: #4fc3f7;
            font-size: 1.5em;
        }}
        .tree-container {{
            background: rgba(255,255,255,0.03);
            border-radius: 12px;
            padding: 20px;
            overflow-x: auto;
        }}
        .tree {{
            list-style: none;
        }}
        .tree ul {{
            list-style: none;
            padding-left: 25px;
            border-left: 2px solid #333;
            margin-left: 10px;
        }}
        .tree li {{
            position: relative;
            padding: 5px 0;
        }}
        .tree li::before {{
            content: "";
            position: absolute;
            left: -25px;
            top: 15px;
            width: 20px;
            height: 2px;
            background: #333;
        }}
        .node {{
            display: inline-flex;
            align-items: center;
            gap: 8px;
            cursor: pointer;
            padding: 6px 12px;
            border-radius: 6px;
            transition: all 0.2s;
        }}
        .node:hover {{
            background: rgba(79, 195, 247, 0.2);
        }}
        .node.target_table {{
            background: linear-gradient(135deg, #e91e63, #c2185b);
            font-weight: bold;
            font-size: 1.1em;
        }}
        .node.target_column {{
            background: linear-gradient(135deg, #ff9800, #f57c00);
        }}
        .node.source {{
            background: linear-gradient(135deg, #4caf50, #388e3c);
        }}
        .node.intermediate {{
            background: linear-gradient(135deg, #2196f3, #1976d2);
        }}
        .node.target {{
            background: linear-gradient(135deg, #9c27b0, #7b1fa2);
        }}
        .toggle {{
            width: 18px;
            height: 18px;
            background: rgba(255,255,255,0.2);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 12px;
            font-weight: bold;
        }}
        .collapsed > ul {{
            display: none;
        }}
        .hop-badge {{
            background: rgba(0,0,0,0.3);
            padding: 2px 8px;
            border-radius: 10px;
            font-size: 0.75em;
        }}
        .transformation {{
            display: block;
            margin-left: 45px;
            font-size: 0.8em;
            color: #aaa;
            font-family: 'Consolas', monospace;
            max-width: 600px;
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
        }}
        .transformation:hover {{
            white-space: normal;
            background: rgba(0,0,0,0.5);
            padding: 5px;
            border-radius: 4px;
        }}
        .legend {{
            display: flex;
            justify-content: center;
            gap: 20px;
            margin-top: 20px;
            flex-wrap: wrap;
        }}
        .legend-item {{
            display: flex;
            align-items: center;
            gap: 8px;
        }}
        .legend-color {{
            width: 20px;
            height: 20px;
            border-radius: 4px;
        }}
        .source-color {{ background: linear-gradient(135deg, #4caf50, #388e3c); }}
        .intermediate-color {{ background: linear-gradient(135deg, #2196f3, #1976d2); }}
        .target-color {{ background: linear-gradient(135deg, #9c27b0, #7b1fa2); }}
    </style>
</head>
<body>
    <div class="container">
        <h1>{title}</h1>
        <p class="subtitle">End-to-End Column Lineage Across Multiple SQL Files</p>

        <div class="stats-bar">
            <div class="stat">
                <div class="stat-value">{stats['total_columns']}</div>
                <div class="stat-label">Columns Traced</div>
            </div>
            <div class="stat">
                <div class="stat-value">{stats['max_hops']}</div>
                <div class="stat-label">Max Hops</div>
            </div>
            <div class="stat">
                <div class="stat-value">{len(stats['tables'])}</div>
                <div class="stat-label">Tables</div>
            </div>
            <div class="stat">
                <div class="stat-value">{len(stats['files'])}</div>
                <div class="stat-label">SQL Files</div>
            </div>
        </div>

        <div class="data-flow">
            <h3>Data Flow Chain</h3>
            <div class="flow-chain">
                {"".join([f'<span class="flow-table">{t}</span><span class="flow-arrow">→</span>' for t in stats['tables'][:-1]])}
                <span class="flow-table">{stats['tables'][-1] if stats['tables'] else ''}</span>
            </div>
        </div>

        <div class="tree-container">
            <ul class="tree" id="lineageTree"></ul>
        </div>

        <div class="legend">
            <div class="legend-item">
                <div class="legend-color source-color"></div>
                <span>Ultimate Source</span>
            </div>
            <div class="legend-item">
                <div class="legend-color intermediate-color"></div>
                <span>Intermediate Table</span>
            </div>
            <div class="legend-item">
                <div class="legend-color target-color"></div>
                <span>Final Target</span>
            </div>
        </div>
    </div>

    <script>
        const treeData = {tree_json};

        function buildTree(node, parentEl) {{
            const li = document.createElement('li');

            const nodeDiv = document.createElement('div');
            nodeDiv.className = 'node ' + (node.type || '');

            if (node.children && node.children.length > 0) {{
                const toggle = document.createElement('span');
                toggle.className = 'toggle';
                toggle.textContent = '−';
                toggle.onclick = function(e) {{
                    e.stopPropagation();
                    li.classList.toggle('collapsed');
                    toggle.textContent = li.classList.contains('collapsed') ? '+' : '−';
                }};
                nodeDiv.appendChild(toggle);
            }}

            const nameSpan = document.createElement('span');
            nameSpan.textContent = node.name;
            nodeDiv.appendChild(nameSpan);

            if (node.hops !== undefined) {{
                const badge = document.createElement('span');
                badge.className = 'hop-badge';
                badge.textContent = node.hops + ' hops';
                nodeDiv.appendChild(badge);
            }}

            li.appendChild(nodeDiv);

            if (node.transformation && node.transformation.length > 0) {{
                const transDiv = document.createElement('div');
                transDiv.className = 'transformation';
                transDiv.textContent = '↳ ' + node.transformation;
                transDiv.title = node.transformation;
                li.appendChild(transDiv);
            }}

            if (node.children && node.children.length > 0) {{
                const ul = document.createElement('ul');
                node.children.forEach(child => buildTree(child, ul));
                li.appendChild(ul);
            }}

            parentEl.appendChild(li);
        }}

        const treeEl = document.getElementById('lineageTree');
        treeData.children.forEach(child => buildTree(child, treeEl));
    </script>
</body>
</html>'''
        return html

    def export_html_documentation(self, output_path: str, title: str = "End-to-End Lineage Documentation") -> None:
        """Export comprehensive HTML documentation with all lineage details."""
        lineages = self.extract_end_to_end_lineage()

        html = self._generate_documentation_html(lineages, title)

        with open(output_path, 'w', encoding='utf-8') as f:
            f.write(html)

        print(f"Exported HTML documentation to {output_path}")

    def _render_lookup_tables_html(self, all_lookup_tables) -> str:
        """Render lookup tables section HTML (extracted for Python 3.9 f-string compatibility)."""
        if not all_lookup_tables:
            return ''
        boxes = ''.join('<div class="lookup-box">' + lt + '</div>' for lt in all_lookup_tables)
        return (
            '<div class="lookup-tables-section">'
            '<h3>Lookup/Reference Tables Contributing Data</h3>'
            '<p class="lookup-connector">These tables provide reference data through JOINs during transformations:</p>'
            '<div>' + boxes + '</div>'
            '</div>'
        )

    def _generate_documentation_html(self, lineages: List[EndToEndColumnLineage], title: str) -> str:
        """Generate comprehensive HTML documentation."""
        # Group lineages by hop count for analysis
        by_hops = defaultdict(list)
        for l in lineages:
            by_hops[l.hop_count].append(l)

        # Collect all unique lookup tables (not in main flow)
        main_flow_tables = set(self.table_sources.keys())
        all_lookup_tables = set()
        for lineage in lineages:
            if lineage.lookup_tables:
                for lt in lineage.lookup_tables:
                    if lt not in main_flow_tables:
                        all_lookup_tables.add(lt)
        all_lookup_tables = sorted(all_lookup_tables)

        # ===== IMPROVED: Get ALL per-file lineage data =====
        all_file_lineages = self.get_all_file_lineages()

        # Group per-file lineages by file and target table
        lineages_by_file = defaultdict(list)
        lineages_by_target = defaultdict(list)
        all_tables = set()
        all_columns = set()

        for edge in all_file_lineages:
            lineages_by_file[edge["source_file"]].append(edge)
            lineages_by_target[edge["target_table"]].append(edge)
            if edge["source_table"]:
                all_tables.add(edge["source_table"])
            if edge["target_table"]:
                all_tables.add(edge["target_table"])
            if edge["source_column"]:
                all_columns.add(f"{edge['source_table']}.{edge['source_column']}")
            if edge["target_column"]:
                all_columns.add(f"{edge['target_table']}.{edge['target_column']}")

        # Build per-file lineage rows
        file_lineage_rows = []
        for edge in sorted(all_file_lineages, key=lambda x: (x["source_file"], x["target_column"])):
            transform_display = edge["transformation"][:80] + "..." if len(edge["transformation"]) > 80 else edge["transformation"]
            file_lineage_rows.append(f'''
            <tr>
                <td>{edge["source_file"]}</td>
                <td>{edge["source_table"]}.{edge["source_column"]}</td>
                <td>{edge["target_table"]}.{edge["target_column"]}</td>
                <td><code>{transform_display or 'DIRECT'}</code></td>
                <td><span class="type-badge">{edge["transformation_type"]}</span></td>
            </tr>''')

        # Build table rows for each lineage (end-to-end traced)
        table_rows = []
        for lineage in sorted(lineages, key=lambda x: (-x.hop_count, x.target_column)):
            flow = " → ".join([f"{h.table_name}.{h.column_name}" for h in lineage.hops])
            transformations = []
            for h in lineage.hops:
                if h.transformation and h.transformation != h.column_name:
                    transformations.append(f"<strong>{h.table_name}:</strong> <code>{h.transformation[:100]}{'...' if len(h.transformation) > 100 else ''}</code>")

            # Format lookup tables
            lookup_tables_html = ', '.join(lineage.lookup_tables) if lineage.lookup_tables else '<em>None</em>'

            table_rows.append(f'''
            <tr>
                <td>{lineage.target_column}</td>
                <td>{lineage.ultimate_source_table}.{lineage.ultimate_source_column}</td>
                <td><span class="hop-count">{lineage.hop_count}</span></td>
                <td class="flow-cell">{flow}</td>
                <td class="lookup-cell">{lookup_tables_html}</td>
                <td>{'<br>'.join(transformations) if transformations else '<em>Direct mapping</em>'}</td>
            </tr>''')

        html = f'''<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>{title}</title>
    <style>
        body {{ font-family: 'Segoe UI', sans-serif; margin: 20px; background: #f5f5f5; }}
        .container {{ max-width: 1600px; margin: 0 auto; background: white; padding: 30px; border-radius: 10px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }}
        h1 {{ color: #1976d2; border-bottom: 3px solid #1976d2; padding-bottom: 10px; }}
        h2 {{ color: #333; margin-top: 30px; }}
        .summary {{ display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 20px; margin: 20px 0; }}
        .summary-card {{ background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 20px; border-radius: 10px; text-align: center; }}
        .summary-card .value {{ font-size: 2em; font-weight: bold; }}
        .summary-card .label {{ opacity: 0.9; }}
        table {{ width: 100%; border-collapse: collapse; margin: 20px 0; }}
        th, td {{ padding: 12px; text-align: left; border-bottom: 1px solid #ddd; }}
        th {{ background: #1976d2; color: white; position: sticky; top: 0; }}
        tr:hover {{ background: #f5f5f5; }}
        .hop-count {{ background: #4caf50; color: white; padding: 4px 12px; border-radius: 20px; font-weight: bold; }}
        .flow-cell {{ font-family: monospace; font-size: 0.9em; max-width: 400px; }}
        .lookup-cell {{ font-size: 0.85em; color: #666; max-width: 250px; }}
        code {{ background: #f0f0f0; padding: 2px 6px; border-radius: 4px; font-size: 0.85em; }}
        .data-flow-section {{ background: #e3f2fd; padding: 20px; border-radius: 10px; margin: 20px 0; }}
        .flow-diagram {{ display: flex; align-items: center; justify-content: center; gap: 15px; flex-wrap: wrap; padding: 20px; }}
        .flow-box {{ background: linear-gradient(135deg, #42a5f5, #1976d2); color: white; padding: 15px 25px; border-radius: 10px; font-weight: bold; box-shadow: 0 2px 5px rgba(0,0,0,0.2); }}
        .flow-arrow {{ font-size: 2em; color: #1976d2; }}
        .lookup-tables-section {{ background: #fff3e0; padding: 20px; border-radius: 10px; margin: 20px 0; border-left: 5px solid #ff9800; }}
        .lookup-tables-section h3 {{ color: #e65100; margin-bottom: 15px; }}
        .lookup-box {{ display: inline-block; background: linear-gradient(135deg, #ff9800, #f57c00); color: white; padding: 10px 20px; border-radius: 8px; margin: 5px; font-weight: bold; box-shadow: 0 2px 4px rgba(0,0,0,0.15); }}
        .lookup-connector {{ color: #ff9800; font-size: 0.9em; margin: 10px 0; font-style: italic; }}
        .files-section {{ margin: 20px 0; }}
        .file-item {{ background: #fff3e0; padding: 10px 15px; margin: 5px 0; border-radius: 5px; border-left: 4px solid #ff9800; }}
        .type-badge {{ background: #9c27b0; color: white; padding: 2px 8px; border-radius: 10px; font-size: 0.8em; }}
        .per-file-section {{ background: #e8f5e9; padding: 20px; border-radius: 10px; margin: 20px 0; border-left: 5px solid #4caf50; }}
        .per-file-section h2 {{ color: #2e7d32; }}
        .table-container {{ max-height: 600px; overflow-y: auto; }}
        .highlight-card {{ background: linear-gradient(135deg, #4caf50 0%, #2e7d32 100%); }}
    </style>
</head>
<body>
    <div class="container">
        <h1>{title}</h1>

        <div class="summary">
            <div class="summary-card highlight-card">
                <div class="value">{len(all_file_lineages)}</div>
                <div class="label">Total Lineage Edges</div>
            </div>
            <div class="summary-card">
                <div class="value">{len(all_tables)}</div>
                <div class="label">Total Tables</div>
            </div>
            <div class="summary-card">
                <div class="value">{len(all_columns)}</div>
                <div class="label">Total Columns</div>
            </div>
            <div class="summary-card">
                <div class="value">{len([f for f in self.processing_order if f.endswith(('.sql', '.vw'))])}</div>
                <div class="label">SQL Files Processed</div>
            </div>
            <div class="summary-card">
                <div class="value">{len(lineages)}</div>
                <div class="label">End-to-End Paths</div>
            </div>
            <div class="summary-card">
                <div class="value">{max((l.hop_count for l in lineages), default=0)}</div>
                <div class="label">Maximum Hops</div>
            </div>
        </div>

        <div class="data-flow-section">
            <h2>Data Flow Chain</h2>
            <div class="flow-diagram">
                {"".join([f'<div class="flow-box">{t}</div><span class="flow-arrow">→</span>' for t in list(self.table_sources.keys())[:-1]])}
                <div class="flow-box">{list(self.table_sources.keys())[-1] if self.table_sources else ''}</div>
            </div>
        </div>

        {self._render_lookup_tables_html(all_lookup_tables)}

        <div class="files-section">
            <h2>SQL Files Processed (in order)</h2>
            {"".join([f'<div class="file-item"><strong>{i+1}.</strong> {f} → <em>{self.file_lineages[f].target_table if f in self.file_lineages else "N/A"}</em></div>' for i, f in enumerate(self.processing_order) if f.endswith(('.sql', '.vw'))])}
        </div>

        <div class="per-file-section">
            <h2>Complete Column-Level Lineage (All {len(all_file_lineages)} Edges)</h2>
            <p>This section shows ALL column-level lineage mappings extracted from each SQL file, including transformations.</p>
            <div class="table-container">
                <table>
                    <thead>
                        <tr>
                            <th>Source File</th>
                            <th>Source Column</th>
                            <th>Target Column</th>
                            <th>Transformation</th>
                            <th>Type</th>
                        </tr>
                    </thead>
                    <tbody>
                        {"".join(file_lineage_rows)}
                    </tbody>
                </table>
            </div>
        </div>

        <h2>End-to-End Traced Lineage Paths ({len(lineages)} paths)</h2>
        <p>These are column lineage paths traced across multiple files from ultimate source to final target.</p>
        <table>
            <thead>
                <tr>
                    <th>Target Column</th>
                    <th>Ultimate Source</th>
                    <th>Hops</th>
                    <th>Data Flow Path</th>
                    <th>Lookup Tables</th>
                    <th>Transformations</th>
                </tr>
            </thead>
            <tbody>
                {"".join(table_rows) if table_rows else '<tr><td colspan="6"><em>No end-to-end paths traced (cross-file lineage requires matching table names between files)</em></td></tr>'}
            </tbody>
        </table>
    </div>
</body>
</html>'''
        return html

    def get_data_flow_summary(self) -> str:
        """Get a human-readable summary of the data flow."""
        summary_lines = ["=" * 60, "DATA FLOW SUMMARY", "=" * 60, ""]

        # Show processing order
        summary_lines.append("Processing Order:")
        for i, fname in enumerate(self.processing_order):
            info = self.file_lineages.get(fname)
            if info:
                sources_str = ', '.join(info.source_tables[:2]) if info.source_tables else 'N/A'
                summary_lines.append(
                    f"  {i+1}. {fname}: {sources_str}... -> {info.target_table}"
                )

        summary_lines.append("")
        summary_lines.append("Table Creation Chain:")

        # Build and show table chain
        for table, file in self.table_to_file.items():
            info = self.file_lineages.get(file)
            if info:
                sources = ", ".join(info.source_tables[:3]) if info.source_tables else "N/A"
                summary_lines.append(f"  {sources} -> {table} (via {file})")

        summary_lines.append("")
        summary_lines.append("=" * 60)

        return "\n".join(summary_lines)

    def export_excel(self, output_path: str, title: str = "End-to-End Lineage Analysis") -> None:
        """
        Export comprehensive lineage analysis to a structured Excel workbook.

        Creates multiple worksheets:
        - Summary: Overview statistics and data flow chain
        - End-to-End Lineage: Column-level lineage from ultimate source to target
        - Comprehensive Hops: Detailed hop-by-hop breakdown
        - File Processing: SQL files processed in order
        - Table Registry: Tables and their source files
        - Transformations: All transformations by column

        Args:
            output_path: Path for the Excel file
            title: Title for the workbook
        """
        try:
            from openpyxl import Workbook
            from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
            from openpyxl.utils.dataframe import dataframe_to_rows
        except ImportError:
            print("Warning: openpyxl not installed. Run: pip install openpyxl")
            return

        lineages = self.extract_end_to_end_lineage()

        wb = Workbook()

        # Styles
        header_font = Font(bold=True, color="FFFFFF")
        header_fill = PatternFill(start_color="1976D2", end_color="1976D2", fill_type="solid")
        alt_fill = PatternFill(start_color="E3F2FD", end_color="E3F2FD", fill_type="solid")
        border = Border(
            left=Side(style='thin'),
            right=Side(style='thin'),
            top=Side(style='thin'),
            bottom=Side(style='thin')
        )

        def style_header(ws, row=1):
            for cell in ws[row]:
                cell.font = header_font
                cell.fill = header_fill
                cell.alignment = Alignment(horizontal='center', vertical='center')
                cell.border = border

        def auto_width(ws):
            for column in ws.columns:
                max_length = 0
                column_letter = None
                for cell in column:
                    # Skip merged cells
                    if hasattr(cell, 'column_letter'):
                        if column_letter is None:
                            column_letter = cell.column_letter
                        try:
                            if cell.value and len(str(cell.value)) > max_length:
                                max_length = min(len(str(cell.value)), 60)
                        except:
                            pass
                if column_letter:
                    ws.column_dimensions[column_letter].width = max(max_length + 2, 10)

        # ============ Sheet 1: Summary ============
        ws_summary = wb.active
        ws_summary.title = "Summary"

        ws_summary['A1'] = title
        ws_summary['A1'].font = Font(bold=True, size=16)
        ws_summary.merge_cells('A1:D1')

        ws_summary['A3'] = "Statistics"
        ws_summary['A3'].font = Font(bold=True, size=12)

        stats = [
            ("Files Processed", len([f for f in self.processing_order if f.endswith(('.sql', '.vw'))])),
            ("Total Tables", len(self.table_sources)),
            ("Columns Traced", len(lineages)),
            ("Maximum Hops", max((l.hop_count for l in lineages), default=0)),
            ("Average Hops", round(sum(l.hop_count for l in lineages) / len(lineages), 1) if lineages else 0),
            ("Unique Ultimate Sources", len(set(l.ultimate_source_table for l in lineages)))
        ]

        for i, (label, value) in enumerate(stats, start=4):
            ws_summary[f'A{i}'] = label
            ws_summary[f'B{i}'] = value

        ws_summary['A11'] = "Data Flow Chain"
        ws_summary['A11'].font = Font(bold=True, size=12)

        tables = list(self.table_sources.keys())
        flow_str = " -> ".join(tables)
        ws_summary['A12'] = flow_str
        ws_summary.merge_cells('A12:F12')

        auto_width(ws_summary)

        # ============ Sheet 2: End-to-End Lineage ============
        ws_e2e = wb.create_sheet("End-to-End Lineage")

        # Use 13-column format matching legacy output
        headers = ["Ultimate_Source_Table", "Ultimate_Source_Column", "Target_Table", "Target_Column",
                   "DML_Operation", "Hop_Count", "Intermediate_Tables", "Lookup_Tables",
                   "Full_Transformation_Chain", "Transformation_At_Each_Hop", "Join_Details",
                   "Where_Conditions", "Data_Flow"]
        ws_e2e.append(headers)
        style_header(ws_e2e)

        # FIXED: Filter out rows with * source column or pure HARDCODED sources
        filtered_lineages = [
            l for l in lineages 
            if l.ultimate_source_column != '*' 
            and not (l.ultimate_source_table == '[HARDCODED]' and l.ultimate_source_column == '*')
        ]
        
        for lin in sorted(filtered_lineages, key=lambda x: (x.target_table, x.target_column)):
            csv_row = lin.to_csv_row()
            ws_e2e.append([
                csv_row.get("Ultimate_Source_Table", ""),
                csv_row.get("Ultimate_Source_Column", ""),
                csv_row.get("Target_Table", ""),
                csv_row.get("Target_Column", ""),
                csv_row.get("DML_Operation", ""),
                csv_row.get("Hop_Count", 0),
                csv_row.get("Intermediate_Tables", ""),
                csv_row.get("Lookup_Tables", ""),
                csv_row.get("Full_Transformation_Chain", ""),
                csv_row.get("Transformation_At_Each_Hop", ""),
                csv_row.get("Join_Details", ""),
                csv_row.get("Where_Conditions", ""),
                csv_row.get("Data_Flow", "")
            ])

        auto_width(ws_e2e)

        # ============ Sheet 3: Comprehensive Hops ============
        ws_hops = wb.create_sheet("Comprehensive Hops")

        headers = ["Target Table", "Target Column", "Ultimate Source", "Hop #", "Hop Table",
                   "Hop Column", "Transformation", "Type", "Source File", "Is Source", "Is Target"]
        ws_hops.append(headers)
        style_header(ws_hops)

        for lin in lineages:
            for i, hop in enumerate(lin.hops):
                ws_hops.append([
                    lin.target_table,
                    lin.target_column,
                    f"{lin.ultimate_source_table}.{lin.ultimate_source_column}",
                    hop.hop_number,
                    hop.table_name,
                    hop.column_name,
                    hop.transformation[:200] if hop.transformation else "",
                    hop.transformation_type,
                    hop.source_file,
                    "Yes" if i == 0 else "No",
                    "Yes" if i == len(lin.hops) - 1 else "No"
                ])

        auto_width(ws_hops)

        # ============ Sheet 4: File Processing ============
        ws_files = wb.create_sheet("File Processing")

        headers = ["Order", "File Name", "File Type", "Target Table", "Source Tables", "Columns Mapped"]
        ws_files.append(headers)
        style_header(ws_files)

        for i, fname in enumerate(self.processing_order, start=1):
            info = self.file_lineages.get(fname)
            if info:
                file_ext = fname.split('.')[-1].upper()
                sources = ", ".join(info.source_tables[:5])
                if len(info.source_tables) > 5:
                    sources += f"... (+{len(info.source_tables) - 5} more)"
                ws_files.append([
                    i,
                    fname,
                    file_ext,
                    info.target_table,
                    sources,
                    len(info.column_mappings)
                ])

        auto_width(ws_files)

        # ============ Sheet 5: Table Registry ============
        ws_tables = wb.create_sheet("Table Registry")

        headers = ["Table Name", "Created By File", "Column Count", "Source Tables"]
        ws_tables.append(headers)
        style_header(ws_tables)

        for table_name, file_name in self.table_to_file.items():
            info = self.file_lineages.get(file_name)
            col_count = len(self.table_sources.get(table_name, {}))
            sources = ", ".join(info.source_tables[:3]) if info and info.source_tables else "N/A"
            ws_tables.append([
                table_name,
                file_name,
                col_count,
                sources
            ])

        auto_width(ws_tables)

        # ============ Sheet 6: Transformations ============
        ws_trans = wb.create_sheet("Transformations")

        headers = ["Target Table", "Target Column", "Source Table", "Source Column",
                   "Transformation Logic", "Type", "Source File"]
        ws_trans.append(headers)
        style_header(ws_trans)

        for table_name, col_mappings in self.table_sources.items():
            file_name = self.table_to_file.get(table_name, "")
            for col_name, sources in col_mappings.items():
                if col_name == "__PASSTHROUGH__":
                    continue
                for src in sources:
                    ws_trans.append([
                        table_name,
                        col_name,
                        src.get("source_table", ""),
                        src.get("source_column", ""),
                        src.get("transformation", "")[:500],
                        src.get("transformation_type", ""),
                        file_name
                    ])

        auto_width(ws_trans)

        # Save workbook
        wb.save(output_path)
        print(f"Exported structured Excel to {output_path}")

    def export_interactive_graph(self, output_path: str,
                                  title: str = "Interactive End-to-End Data Lineage") -> None:
        """
        Export end-to-end lineage as an interactive Cytoscape.js graph visualization.

        Features:
        - Table nodes with expandable columns
        - Click-through to transformation details
        - Hierarchical left-to-right layout (dagre)
        - Zoom, pan, and search capabilities
        - Color coding by table type (source/intermediate/target)

        Args:
            output_path: Output HTML file path
            title: Title for the visualization
        """
        lineages = self.extract_end_to_end_lineage()
        graph_data = self._build_graph_data(lineages)
        html_content = self._generate_cytoscape_html(graph_data, title)

        with open(output_path, 'w', encoding='utf-8') as f:
            f.write(html_content)

        print(f"Exported interactive graph to {output_path}")

    def _build_graph_data(self, lineages: List[EndToEndColumnLineage]) -> Dict[str, Any]:
        """
        Transform lineage data into Cytoscape.js-compatible graph structure.
        """
        # Collect all tables and their relationships
        tables = {}
        table_columns = defaultdict(set)
        edges = defaultdict(lambda: {"columns": []})

        # Determine table types based on position in the flow
        source_tables = set()
        target_tables = set()
        intermediate_tables = set()

        # Find the final target table (from last SQL file)
        final_target = None
        for file_name in reversed(self.processing_order):
            if file_name.lower().endswith(('.sql', '.vw')):
                if file_name in self.file_lineages:
                    info = self.file_lineages[file_name]
                    if info.target_table:
                        final_target = self._normalize_table_name(info.target_table)
                        break

        # Process lineages to build graph
        for lin in lineages:
            # Track all tables in the lineage chain
            for i, hop in enumerate(lin.hops):
                table_name = hop.table_name
                tables[table_name] = {
                    "id": table_name,
                    "name": table_name,
                    "file": hop.source_file or self.table_to_file.get(table_name, "")
                }
                table_columns[table_name].add(hop.column_name)

                # Determine table type
                if i == 0:  # First hop is ultimate source
                    source_tables.add(table_name)
                elif i == len(lin.hops) - 1:  # Last hop is target
                    target_tables.add(table_name)
                else:
                    intermediate_tables.add(table_name)

                # Create edges between consecutive hops
                if i > 0:
                    prev_hop = lin.hops[i - 1]
                    edge_key = f"{prev_hop.table_name}|{table_name}"
                    edges[edge_key]["source"] = prev_hop.table_name
                    edges[edge_key]["target"] = table_name
                    edges[edge_key]["columns"].append({
                        "source_column": prev_hop.column_name,
                        "target_column": hop.column_name,
                        "transformation": hop.transformation,
                        "transformation_type": hop.transformation_type
                    })

        # Assign types (source takes precedence, then target, then intermediate)
        for table_name in tables:
            if table_name in source_tables and table_name not in target_tables:
                tables[table_name]["type"] = "source"
            elif table_name == final_target or (table_name in target_tables and table_name not in source_tables):
                tables[table_name]["type"] = "target"
            else:
                tables[table_name]["type"] = "intermediate"

            tables[table_name]["columns"] = sorted(list(table_columns[table_name]))

        # Build column lineages for detail panel
        column_lineages = [lin.to_dict() for lin in lineages]

        return {
            "metadata": {
                "title": title if 'title' in dir() else "Data Lineage",
                "total_columns": len(lineages),
                "max_hops": max((lin.hop_count for lin in lineages), default=0),
                "total_tables": len(tables),
                "processing_order": [f for f in self.processing_order if f.endswith(('.sql', '.vw'))]
            },
            "tables": list(tables.values()),
            "edges": list(edges.values()),
            "column_lineages": column_lineages
        }

    def _generate_cytoscape_html(self, graph_data: Dict[str, Any], title: str) -> str:
        """Generate interactive HTML with Cytoscape.js visualization."""

        graph_json = json.dumps(graph_data, indent=2)

        html = f'''<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{title}</title>

    <!-- Cytoscape.js and dagre layout -->
    <script src="https://unpkg.com/cytoscape@3.28.1/dist/cytoscape.min.js"></script>
    <script src="https://unpkg.com/dagre@0.8.5/dist/dagre.min.js"></script>
    <script src="https://unpkg.com/cytoscape-dagre@2.5.0/cytoscape-dagre.js"></script>

    <style>
        * {{
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }}

        body {{
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #1a1a2e 0%, #16213e 100%);
            color: #eee;
            height: 100vh;
            overflow: hidden;
        }}

        .container {{
            display: flex;
            flex-direction: column;
            height: 100vh;
        }}

        /* Header */
        .header {{
            background: rgba(0, 0, 0, 0.3);
            padding: 15px 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            border-bottom: 1px solid #333;
        }}

        .header h1 {{
            color: #4fc3f7;
            font-size: 1.5em;
        }}

        .stats {{
            display: flex;
            gap: 20px;
        }}

        .stat {{
            text-align: center;
            padding: 5px 15px;
            background: rgba(79, 195, 247, 0.1);
            border-radius: 5px;
            border: 1px solid #4fc3f7;
        }}

        .stat-value {{
            font-size: 1.3em;
            font-weight: bold;
            color: #4fc3f7;
        }}

        .stat-label {{
            font-size: 0.75em;
            color: #aaa;
        }}

        /* Controls */
        .controls {{
            background: rgba(0, 0, 0, 0.2);
            padding: 10px 20px;
            display: flex;
            gap: 15px;
            align-items: center;
            flex-wrap: wrap;
        }}

        .control-group {{
            display: flex;
            align-items: center;
            gap: 8px;
        }}

        .control-group label {{
            font-size: 0.85em;
            color: #aaa;
        }}

        input[type="text"] {{
            padding: 8px 12px;
            border: 1px solid #444;
            border-radius: 5px;
            background: #2a2a4a;
            color: #fff;
            width: 200px;
        }}

        input[type="text"]:focus {{
            outline: none;
            border-color: #4fc3f7;
        }}

        button {{
            padding: 8px 16px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 0.85em;
            transition: all 0.2s;
        }}

        .btn-primary {{
            background: #4fc3f7;
            color: #000;
        }}

        .btn-primary:hover {{
            background: #81d4fa;
        }}

        .btn-secondary {{
            background: #444;
            color: #fff;
        }}

        .btn-secondary:hover {{
            background: #555;
        }}

        /* Main content */
        .main-content {{
            display: flex;
            flex: 1;
            overflow: hidden;
        }}

        /* Graph container */
        #cy {{
            flex: 1;
            background: linear-gradient(135deg, #0d1b2a 0%, #1b263b 100%);
        }}

        /* Side panel */
        .side-panel {{
            width: 400px;
            background: rgba(0, 0, 0, 0.4);
            border-left: 1px solid #333;
            overflow-y: auto;
            transition: transform 0.3s;
        }}

        .side-panel.hidden {{
            transform: translateX(100%);
            width: 0;
            border: none;
        }}

        .panel-header {{
            padding: 15px;
            background: rgba(79, 195, 247, 0.1);
            border-bottom: 1px solid #333;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }}

        .panel-header h3 {{
            color: #4fc3f7;
        }}

        .close-btn {{
            background: none;
            border: none;
            color: #aaa;
            font-size: 1.5em;
            cursor: pointer;
        }}

        .close-btn:hover {{
            color: #fff;
        }}

        .panel-content {{
            padding: 15px;
        }}

        /* Lineage path */
        .lineage-path {{
            margin: 15px 0;
        }}

        .hop {{
            display: flex;
            align-items: flex-start;
            margin-bottom: 10px;
        }}

        .hop-indicator {{
            width: 30px;
            display: flex;
            flex-direction: column;
            align-items: center;
        }}

        .hop-dot {{
            width: 12px;
            height: 12px;
            border-radius: 50%;
            background: #4fc3f7;
        }}

        .hop-line {{
            width: 2px;
            height: 30px;
            background: #4fc3f7;
        }}

        .hop.source .hop-dot {{ background: #4caf50; }}
        .hop.intermediate .hop-dot {{ background: #ff9800; }}
        .hop.target .hop-dot {{ background: #e91e63; }}

        .hop-content {{
            flex: 1;
            background: rgba(255, 255, 255, 0.05);
            padding: 10px;
            border-radius: 5px;
            margin-left: 10px;
        }}

        .hop-table {{
            font-weight: bold;
            color: #4fc3f7;
        }}

        .hop-column {{
            color: #fff;
            margin-top: 3px;
        }}

        .hop-transform {{
            font-size: 0.8em;
            color: #aaa;
            margin-top: 5px;
            font-family: 'Consolas', monospace;
            background: rgba(0, 0, 0, 0.3);
            padding: 5px;
            border-radius: 3px;
            max-height: 80px;
            overflow-y: auto;
            word-break: break-all;
        }}

        .hop-file {{
            font-size: 0.75em;
            color: #666;
            margin-top: 5px;
        }}

        /* Legend */
        .legend {{
            position: absolute;
            bottom: 20px;
            left: 20px;
            background: rgba(0, 0, 0, 0.7);
            padding: 15px;
            border-radius: 8px;
            border: 1px solid #333;
        }}

        .legend h4 {{
            color: #4fc3f7;
            margin-bottom: 10px;
            font-size: 0.9em;
        }}

        .legend-item {{
            display: flex;
            align-items: center;
            gap: 10px;
            margin: 5px 0;
            font-size: 0.85em;
        }}

        .legend-color {{
            width: 20px;
            height: 20px;
            border-radius: 4px;
        }}

        .source-color {{ background: linear-gradient(135deg, #4caf50, #388e3c); }}
        .intermediate-color {{ background: linear-gradient(135deg, #ff9800, #f57c00); }}
        .target-color {{ background: linear-gradient(135deg, #e91e63, #c2185b); }}

        /* Table info tooltip */
        .table-info {{
            margin-top: 15px;
        }}

        .table-info h4 {{
            color: #4fc3f7;
            margin-bottom: 10px;
        }}

        .column-list {{
            max-height: 200px;
            overflow-y: auto;
        }}

        .column-item {{
            padding: 5px 10px;
            background: rgba(255, 255, 255, 0.05);
            margin: 3px 0;
            border-radius: 3px;
            cursor: pointer;
            transition: background 0.2s;
        }}

        .column-item:hover {{
            background: rgba(79, 195, 247, 0.2);
        }}

        /* Flow diagram in header */
        .flow-chain {{
            display: flex;
            align-items: center;
            gap: 8px;
            flex-wrap: wrap;
            max-width: 600px;
        }}

        .flow-table {{
            background: linear-gradient(135deg, #2d5a7b, #1e3d5a);
            padding: 4px 10px;
            border-radius: 15px;
            font-size: 0.75em;
            white-space: nowrap;
        }}

        .flow-arrow {{
            color: #4fc3f7;
        }}

        /* Instructions */
        .instructions {{
            position: absolute;
            top: 150px;
            right: 20px;
            background: rgba(0, 0, 0, 0.7);
            padding: 15px;
            border-radius: 8px;
            border: 1px solid #333;
            font-size: 0.8em;
            max-width: 200px;
        }}

        .instructions h4 {{
            color: #4fc3f7;
            margin-bottom: 8px;
        }}

        .instructions ul {{
            list-style: none;
            color: #aaa;
        }}

        .instructions li {{
            margin: 5px 0;
        }}

        .instructions li::before {{
            content: ">";
            color: #4fc3f7;
            margin-right: 5px;
        }}
    </style>
</head>
<body>
    <div class="container">
        <!-- Header -->
        <div class="header">
            <div>
                <h1>{title}</h1>
                <div class="flow-chain" id="flowChain"></div>
            </div>
            <div class="stats">
                <div class="stat">
                    <div class="stat-value" id="statTables">0</div>
                    <div class="stat-label">Tables</div>
                </div>
                <div class="stat">
                    <div class="stat-value" id="statColumns">0</div>
                    <div class="stat-label">Columns</div>
                </div>
                <div class="stat">
                    <div class="stat-value" id="statHops">0</div>
                    <div class="stat-label">Max Hops</div>
                </div>
            </div>
        </div>

        <!-- Controls -->
        <div class="controls">
            <div class="control-group">
                <label>Search:</label>
                <input type="text" id="searchInput" placeholder="Search tables or columns...">
            </div>
            <div class="control-group">
                <button class="btn-primary" onclick="fitGraph()">Fit to Screen</button>
                <button class="btn-secondary" onclick="zoomIn()">Zoom +</button>
                <button class="btn-secondary" onclick="zoomOut()">Zoom -</button>
                <button class="btn-secondary" onclick="resetGraph()">Reset</button>
            </div>
            <div class="control-group">
                <button class="btn-secondary" onclick="togglePanel()">Toggle Details</button>
            </div>
        </div>

        <!-- Main content -->
        <div class="main-content">
            <!-- Cytoscape container -->
            <div id="cy"></div>

            <!-- Side panel for details -->
            <div class="side-panel hidden" id="sidePanel">
                <div class="panel-header">
                    <h3 id="panelTitle">Details</h3>
                    <button class="close-btn" onclick="closePanel()">&times;</button>
                </div>
                <div class="panel-content" id="panelContent">
                    <p>Click on a table or edge to see details</p>
                </div>
            </div>
        </div>
    </div>

    <!-- Legend -->
    <div class="legend">
        <h4>Legend</h4>
        <div class="legend-item">
            <div class="legend-color source-color"></div>
            <span>Source Table</span>
        </div>
        <div class="legend-item">
            <div class="legend-color intermediate-color"></div>
            <span>Intermediate Table</span>
        </div>
        <div class="legend-item">
            <div class="legend-color target-color"></div>
            <span>Target Table</span>
        </div>
    </div>

    <!-- Instructions -->
    <div class="instructions">
        <h4>Interactions</h4>
        <ul>
            <li>Click table for details</li>
            <li>Click edge for column flow</li>
            <li>Scroll to zoom</li>
            <li>Drag to pan</li>
            <li>Search to highlight</li>
        </ul>
    </div>

    <script>
        // Graph data from Python
        const graphData = {graph_json};

        // Color schemes
        const colors = {{
            source: {{ bg: '#4caf50', border: '#388e3c' }},
            intermediate: {{ bg: '#ff9800', border: '#f57c00' }},
            target: {{ bg: '#e91e63', border: '#c2185b' }}
        }};

        // Initialize Cytoscape
        let cy;

        function initGraph() {{
            // Build nodes and edges for Cytoscape
            const elements = [];

            // Add table nodes
            graphData.tables.forEach(table => {{
                const color = colors[table.type] || colors.intermediate;
                elements.push({{
                    data: {{
                        id: table.id,
                        label: table.name,
                        type: table.type,
                        columns: table.columns,
                        file: table.file,
                        columnCount: table.columns.length
                    }},
                    classes: table.type
                }});
            }});

            // Add edges
            graphData.edges.forEach((edge, idx) => {{
                if (edge.source && edge.target) {{
                    elements.push({{
                        data: {{
                            id: `edge_${{idx}}`,
                            source: edge.source,
                            target: edge.target,
                            columns: edge.columns,
                            columnCount: edge.columns.length,
                            label: `${{edge.columns.length}} cols`
                        }}
                    }});
                }}
            }});

            // Create Cytoscape instance
            cy = cytoscape({{
                container: document.getElementById('cy'),
                elements: elements,
                style: [
                    {{
                        selector: 'node',
                        style: {{
                            'label': 'data(label)',
                            'text-valign': 'center',
                            'text-halign': 'center',
                            'background-color': '#ff9800',
                            'border-width': 3,
                            'border-color': '#f57c00',
                            'color': '#fff',
                            'font-size': '12px',
                            'font-weight': 'bold',
                            'text-outline-width': 2,
                            'text-outline-color': '#000',
                            'width': 'label',
                            'height': 40,
                            'padding': '15px',
                            'shape': 'roundrectangle'
                        }}
                    }},
                    {{
                        selector: 'node.source',
                        style: {{
                            'background-color': '#4caf50',
                            'border-color': '#388e3c'
                        }}
                    }},
                    {{
                        selector: 'node.intermediate',
                        style: {{
                            'background-color': '#ff9800',
                            'border-color': '#f57c00'
                        }}
                    }},
                    {{
                        selector: 'node.target',
                        style: {{
                            'background-color': '#e91e63',
                            'border-color': '#c2185b'
                        }}
                    }},
                    {{
                        selector: 'node.lookup',
                        style: {{
                            'background-color': '#9c27b0',
                            'border-color': '#7b1fa2',
                            'shape': 'diamond',
                            'width': 'label',
                            'height': 35
                        }}
                    }},
                    {{
                        selector: 'edge[?is_lookup_edge]',
                        style: {{
                            'line-style': 'dashed',
                            'line-color': '#9c27b0',
                            'target-arrow-color': '#9c27b0'
                        }}
                    }},
                    {{
                        selector: 'node:selected',
                        style: {{
                            'border-width': 5,
                            'border-color': '#4fc3f7'
                        }}
                    }},
                    {{
                        selector: 'node.highlighted',
                        style: {{
                            'border-width': 5,
                            'border-color': '#ffeb3b',
                            'background-color': '#ffc107'
                        }}
                    }},
                    {{
                        selector: 'node.dimmed',
                        style: {{
                            'opacity': 0.3
                        }}
                    }},
                    {{
                        selector: 'edge',
                        style: {{
                            'width': 3,
                            'line-color': '#4fc3f7',
                            'target-arrow-color': '#4fc3f7',
                            'target-arrow-shape': 'triangle',
                            'curve-style': 'bezier',
                            'label': 'data(label)',
                            'font-size': '10px',
                            'color': '#aaa',
                            'text-background-color': '#1a1a2e',
                            'text-background-opacity': 0.8,
                            'text-background-padding': '3px'
                        }}
                    }},
                    {{
                        selector: 'edge:selected',
                        style: {{
                            'width': 5,
                            'line-color': '#ffeb3b',
                            'target-arrow-color': '#ffeb3b'
                        }}
                    }},
                    {{
                        selector: 'edge.dimmed',
                        style: {{
                            'opacity': 0.2
                        }}
                    }}
                ],
                layout: {{
                    name: 'dagre',
                    rankDir: 'LR',
                    nodeSep: 80,
                    rankSep: 150,
                    padding: 50
                }},
                minZoom: 0.1,
                maxZoom: 3,
                wheelSensitivity: 0.3
            }});

            // Event handlers
            cy.on('tap', 'node', function(evt) {{
                const node = evt.target;
                showTableDetails(node.data());
            }});

            cy.on('tap', 'edge', function(evt) {{
                const edge = evt.target;
                showEdgeDetails(edge.data());
            }});

            cy.on('tap', function(evt) {{
                if (evt.target === cy) {{
                    // Clicked on background
                    cy.elements().removeClass('highlighted dimmed');
                }}
            }});

            cy.on('mouseover', 'node', function(evt) {{
                const node = evt.target;
                highlightConnected(node);
            }});

            cy.on('mouseout', 'node', function() {{
                cy.elements().removeClass('highlighted dimmed');
            }});

            // Update stats
            document.getElementById('statTables').textContent = graphData.tables.length;
            document.getElementById('statColumns').textContent = graphData.metadata.total_columns;
            document.getElementById('statHops').textContent = graphData.metadata.max_hops;

            // Build flow chain
            buildFlowChain();
        }}

        function buildFlowChain() {{
            const flowChain = document.getElementById('flowChain');
            const tables = graphData.tables
                .sort((a, b) => {{
                    const order = {{ source: 0, intermediate: 1, target: 2 }};
                    return (order[a.type] || 1) - (order[b.type] || 1);
                }});

            // Get unique ordered tables from processing order
            const orderedTables = [];
            graphData.metadata.processing_order.forEach(file => {{
                const table = graphData.tables.find(t => t.file === file);
                if (table && !orderedTables.includes(table.name)) {{
                    orderedTables.push(table.name);
                }}
            }});

            // Use first few tables for display
            const displayTables = orderedTables.length > 0 ? orderedTables.slice(0, 6) :
                tables.slice(0, 6).map(t => t.name);

            flowChain.innerHTML = displayTables.map((t, i) =>
                `<span class="flow-table">${{t}}</span>${{i < displayTables.length - 1 ? '<span class="flow-arrow">&#8594;</span>' : ''}}`
            ).join('');
        }}

        function highlightConnected(node) {{
            const connectedEdges = node.connectedEdges();
            const connectedNodes = connectedEdges.connectedNodes();

            cy.elements().addClass('dimmed');
            node.removeClass('dimmed').addClass('highlighted');
            connectedEdges.removeClass('dimmed');
            connectedNodes.removeClass('dimmed');
        }}

        function showTableDetails(data) {{
            const panel = document.getElementById('sidePanel');
            const title = document.getElementById('panelTitle');
            const content = document.getElementById('panelContent');

            panel.classList.remove('hidden');
            title.textContent = data.label;

            // Find lineages that involve this table
            const relatedLineages = graphData.column_lineages.filter(lin =>
                lin.hops.some(h => h.table_name === data.id)
            );

            let html = `
                <div class="table-info">
                    <p><strong>Type:</strong> ${{data.type.charAt(0).toUpperCase() + data.type.slice(1)}} Table</p>
                    <p><strong>Source File:</strong> ${{data.file || 'N/A'}}</p>
                    <p><strong>Columns:</strong> ${{data.columns.length}}</p>
                </div>
                <div class="table-info">
                    <h4>Columns</h4>
                    <div class="column-list">
            `;

            data.columns.forEach(col => {{
                html += `<div class="column-item" onclick="showColumnLineage('${{data.id}}', '${{col}}')">${{col}}</div>`;
            }});

            html += `</div></div>`;

            content.innerHTML = html;
        }}

        function showEdgeDetails(data) {{
            const panel = document.getElementById('sidePanel');
            const title = document.getElementById('panelTitle');
            const content = document.getElementById('panelContent');

            panel.classList.remove('hidden');
            title.textContent = `${{data.source}} &#8594; ${{data.target}}`;

            let html = `
                <div class="table-info">
                    <p><strong>Column Mappings:</strong> ${{data.columns.length}}</p>
                </div>
                <div class="lineage-path">
            `;

            data.columns.forEach(col => {{
                html += `
                    <div class="hop intermediate">
                        <div class="hop-indicator">
                            <div class="hop-dot"></div>
                        </div>
                        <div class="hop-content">
                            <div class="hop-column">${{col.source_column}} &#8594; ${{col.target_column}}</div>
                            ${{col.transformation && col.transformation !== col.target_column ?
                                `<div class="hop-transform">${{col.transformation}}</div>` : ''}}
                            <div class="hop-file">Type: ${{col.transformation_type}}</div>
                        </div>
                    </div>
                `;
            }});

            html += `</div>`;
            content.innerHTML = html;
        }}

        function showColumnLineage(tableName, columnName) {{
            const lineage = graphData.column_lineages.find(lin =>
                lin.target_table === tableName && lin.target_column === columnName
            ) || graphData.column_lineages.find(lin =>
                lin.hops.some(h => h.table_name === tableName && h.column_name === columnName)
            );

            if (!lineage) {{
                return;
            }}

            const title = document.getElementById('panelTitle');
            const content = document.getElementById('panelContent');

            title.textContent = `${{tableName}}.${{columnName}}`;

            let html = `
                <div class="table-info">
                    <p><strong>Ultimate Source:</strong> ${{lineage.ultimate_source_table}}.${{lineage.ultimate_source_column}}</p>
                    <p><strong>Total Hops:</strong> ${{lineage.hop_count}}</p>
                    ${{lineage.lookup_tables && lineage.lookup_tables.length > 0 ?
                        `<p><strong>Lookup Tables:</strong> ${{lineage.lookup_tables.join(', ')}}</p>` : ''}}
                </div>
                <div class="lineage-path">
                    <h4>Data Flow Path</h4>
            `;

            lineage.hops.forEach((hop, idx) => {{
                const hopType = idx === 0 ? 'source' : (idx === lineage.hops.length - 1 ? 'target' : 'intermediate');
                html += `
                    <div class="hop ${{hopType}}">
                        <div class="hop-indicator">
                            <div class="hop-dot"></div>
                            ${{idx < lineage.hops.length - 1 ? '<div class="hop-line"></div>' : ''}}
                        </div>
                        <div class="hop-content">
                            <div class="hop-table">${{hop.table_name}}</div>
                            <div class="hop-column">${{hop.column_name}}</div>
                            ${{hop.transformation && hop.transformation !== hop.column_name ?
                                `<div class="hop-transform">${{hop.transformation}}</div>` : ''}}
                            ${{hop.source_file ? `<div class="hop-file">${{hop.source_file}}</div>` : ''}}
                        </div>
                    </div>
                `;
            }});

            html += `</div>`;
            content.innerHTML = html;
        }}

        // Control functions
        function fitGraph() {{
            cy.fit(50);
        }}

        function zoomIn() {{
            cy.zoom(cy.zoom() * 1.3);
            cy.center();
        }}

        function zoomOut() {{
            cy.zoom(cy.zoom() / 1.3);
            cy.center();
        }}

        function resetGraph() {{
            cy.reset();
            cy.fit(50);
        }}

        function togglePanel() {{
            document.getElementById('sidePanel').classList.toggle('hidden');
        }}

        function closePanel() {{
            document.getElementById('sidePanel').classList.add('hidden');
        }}

        // Search functionality
        document.getElementById('searchInput').addEventListener('input', function(e) {{
            const query = e.target.value.toLowerCase();

            if (!query) {{
                cy.elements().removeClass('highlighted dimmed');
                return;
            }}

            cy.elements().addClass('dimmed');

            cy.nodes().forEach(node => {{
                const data = node.data();
                const matches = data.label.toLowerCase().includes(query) ||
                    data.columns.some(c => c.toLowerCase().includes(query));

                if (matches) {{
                    node.removeClass('dimmed').addClass('highlighted');
                    node.connectedEdges().removeClass('dimmed');
                }}
            }});
        }});

        // Initialize on load
        document.addEventListener('DOMContentLoaded', initGraph);
    </script>
</body>
</html>'''

        return html

    def export_field_level_graph(self, output_path: str,
                                  title: str = "Field-Level Data Lineage") -> None:
        """
        Export end-to-end lineage as an interactive field-level graph visualization.

        Unlike the table-level graph, this shows individual columns as nodes with
        edges representing the data flow between specific fields.

        Features:
        - Individual column nodes grouped by parent table
        - Direct edges between source and target columns
        - Click on any column to see full lineage path
        - Transformation details shown on edges
        - Color coding by table type (source/intermediate/target)

        Args:
            output_path: Output HTML file path
            title: Title for the visualization
        """
        lineages = self.extract_end_to_end_lineage()
        graph_data = self._build_field_level_graph_data(lineages)
        html_content = self._generate_field_level_html(graph_data, title)

        with open(output_path, 'w', encoding='utf-8') as f:
            f.write(html_content)

        print(f"Exported field-level graph to {output_path}")

    def _build_field_level_graph_data(self, lineages: List[EndToEndColumnLineage]) -> Dict[str, Any]:
        """
        Transform lineage data into field-level Cytoscape.js-compatible graph structure.
        Creates individual nodes for each column with parent table grouping.

        IMPROVED: Uses per-file lineage data for complete coverage, and properly
        classifies tables based on their role in the data flow (not just hop position).
        """
        # Track tables and columns
        tables = {}
        columns = {}  # key: "table.column", value: node data
        edges = []  # list of column-to-column edges
        edge_set = set()  # To avoid duplicate edges

        # ===== IMPROVED: Collect ALL target tables from ALL processed files =====
        all_file_targets = set()  # Tables that are targets of any file
        all_file_sources = set()  # Tables that are sources in any file
        final_target = None

        for file_name in self.processing_order:
            if file_name.lower().endswith(('.sql', '.vw')):
                if file_name in self.file_lineages:
                    info = self.file_lineages[file_name]
                    if info.target_table:
                        norm_target = self._normalize_table_name(info.target_table)
                        all_file_targets.add(norm_target)
                        final_target = norm_target  # Last one becomes final
                    # Also collect source tables
                    for src in info.source_tables:
                        norm_src = self._normalize_table_name(src)
                        all_file_sources.add(norm_src)

        # Pure sources are tables that are sources but never targets of any file
        pure_source_tables = all_file_sources - all_file_targets

        # ===== IMPROVED: Build graph from ALL per-file lineage data =====
        # This ensures we capture all 572+ lineage edges, not just end-to-end traced paths
        for file_name in self.processing_order:
            if file_name not in self.file_lineages:
                continue

            file_info = self.file_lineages[file_name]
            lineage_graph = file_info.lineage_graph

            if not lineage_graph or not lineage_graph.edges:
                continue

            file_target = self._normalize_table_name(file_info.target_table) if file_info.target_table else None

            for edge in lineage_graph.edges:
                # Source column
                src_table = self._normalize_table_name(edge.source.table_name) if edge.source.table_name else "[UNKNOWN]"
                src_col = edge.source.column_name or "*"
                src_id = f"{src_table}.{src_col}"

                # Target column
                tgt_table = self._normalize_table_name(edge.target.table_name) if edge.target.table_name else file_target or "[UNKNOWN]"
                tgt_col = edge.target.column_name or "*"
                tgt_id = f"{tgt_table}.{tgt_col}"

                # Skip invalid entries
                if src_col == "*" and tgt_col == "*":
                    continue

                # Register source table
                if src_table and src_table not in tables:
                    tables[src_table] = {
                        "id": src_table,
                        "name": src_table,
                        "file": self.table_to_file.get(src_table, ""),
                        "columns": set()
                    }
                if src_table and src_col != "*":
                    tables[src_table]["columns"].add(src_col)

                # Register target table
                if tgt_table and tgt_table not in tables:
                    tables[tgt_table] = {
                        "id": tgt_table,
                        "name": tgt_table,
                        "file": file_name,
                        "columns": set()
                    }
                if tgt_table and tgt_col != "*":
                    tables[tgt_table]["columns"].add(tgt_col)

                # Register source column node
                if src_col != "*" and src_id not in columns:
                    columns[src_id] = {
                        "id": src_id,
                        "column_name": src_col,
                        "table_name": src_table,
                        "parent": src_table,
                        "hop_index": 0,
                        "lineages": []
                    }

                # Register target column node
                if tgt_col != "*" and tgt_id not in columns:
                    columns[tgt_id] = {
                        "id": tgt_id,
                        "column_name": tgt_col,
                        "table_name": tgt_table,
                        "parent": tgt_table,
                        "hop_index": 1,
                        "lineages": []
                    }
                if tgt_col != "*" and tgt_id in columns:
                    columns[tgt_id]["lineages"].append(tgt_col)

                # Create edge
                if src_col != "*" and tgt_col != "*":
                    edge_key = f"{src_id}|{tgt_id}"
                    if edge_key not in edge_set:
                        edge_set.add(edge_key)

                        # Get transformation info
                        transform = ""
                        transform_type = "DIRECT"
                        if edge.transformation:
                            transform = edge.transformation.sql_expression or ""
                            if edge.transformation.type:
                                transform_type = edge.transformation.type.value if hasattr(edge.transformation.type, 'value') else str(edge.transformation.type)

                        edges.append({
                            "source": src_id,
                            "target": tgt_id,
                            "source_table": src_table,
                            "target_table": tgt_table,
                            "source_column": src_col,
                            "target_column": tgt_col,
                            "transformation": transform,
                            "transformation_type": transform_type
                        })

        # Also process end-to-end lineages (for cross-file paths)
        for lin in lineages:
            for i, hop in enumerate(lin.hops):
                table_name = self._normalize_table_name(hop.table_name) if hop.table_name else "[UNKNOWN]"
                column_name = hop.column_name or "*"
                col_id = f"{table_name}.{column_name}"

                if column_name == "*":
                    continue

                # Register table if not exists
                if table_name not in tables:
                    tables[table_name] = {
                        "id": table_name,
                        "name": table_name,
                        "file": hop.source_file or self.table_to_file.get(table_name, ""),
                        "columns": set()
                    }
                tables[table_name]["columns"].add(column_name)

                # Register column node if not exists
                if col_id not in columns:
                    columns[col_id] = {
                        "id": col_id,
                        "column_name": column_name,
                        "table_name": table_name,
                        "parent": table_name,
                        "hop_index": i,
                        "lineages": []
                    }
                columns[col_id]["lineages"].append(lin.target_column)

                # Create edge to previous hop
                if i > 0:
                    prev_hop = lin.hops[i - 1]
                    prev_table = self._normalize_table_name(prev_hop.table_name) if prev_hop.table_name else "[UNKNOWN]"
                    prev_col_id = f"{prev_table}.{prev_hop.column_name}"
                    edge_key = f"{prev_col_id}|{col_id}"

                    if edge_key not in edge_set:
                        edge_set.add(edge_key)
                        edges.append({
                            "source": prev_col_id,
                            "target": col_id,
                            "source_table": prev_table,
                            "target_table": table_name,
                            "source_column": prev_hop.column_name,
                            "target_column": column_name,
                            "transformation": hop.transformation or "",
                            "transformation_type": hop.transformation_type or "DIRECT"
                        })

        # ===== IMPROVED: Assign table types based on GLOBAL data flow position =====
        # Intermediate tables are those that are BOTH a target of one file AND a source for another
        intermediate_tables = all_file_targets & all_file_sources

        for table_name in tables:
            if table_name in pure_source_tables:
                # Pure sources: only appear as sources, never as targets
                tables[table_name]["type"] = "source"
            elif table_name == final_target:
                # Only the FINAL target table gets purple color
                tables[table_name]["type"] = "target"
            elif table_name in intermediate_tables:
                # Tables that are both targets and sources are intermediate (gray)
                tables[table_name]["type"] = "intermediate"
            elif table_name in all_file_targets:
                # Other target tables that aren't the final one are also intermediate
                tables[table_name]["type"] = "intermediate"
            else:
                # Default to intermediate if can't determine
                tables[table_name]["type"] = "intermediate"
            tables[table_name]["columns"] = sorted(list(tables[table_name]["columns"]))

        # Assign column types based on parent table
        for col_id, col_data in columns.items():
            col_data["type"] = tables[col_data["table_name"]]["type"]

        # ===== IMPROVED: Extract lookup tables from transformation expressions =====
        all_lookup_tables = set()
        lookup_table_targets = {}  # Map lookup table to the tables it contributes to

        # Pattern to extract table names from transformation expressions (e.g., LKP_CD_TYPE, PM_Alkp_*)
        import re
        lookup_pattern = re.compile(r'^(LKP_[A-Z_0-9]+|PM_[Aa]lkp_[A-Z_0-9]+|CODE_TRANSLATION[A-Z_]*|SRC_STG_CTL|SRC_STG_INFO)', re.IGNORECASE)

        # First, collect lookup tables from lineage objects (only those matching lookup patterns)
        for lin in lineages:
            if lin.lookup_tables:
                for lookup_table in lin.lookup_tables:
                    norm_lookup = self._normalize_table_name(lookup_table)
                    # Only include if it matches lookup naming pattern
                    if lookup_pattern.match(norm_lookup):
                        all_lookup_tables.add(norm_lookup)
                        # If table already exists, mark it as lookup type
                        if norm_lookup in tables:
                            tables[norm_lookup]["type"] = "lookup"
                        # Connect to hops in this lineage
                        for hop in lin.hops:
                            hop_table = self._normalize_table_name(hop.table_name) if hop.table_name else None
                            if hop_table and (hop_table in intermediate_tables or hop_table in all_file_targets):
                                if norm_lookup not in lookup_table_targets:
                                    lookup_table_targets[norm_lookup] = set()
                                lookup_table_targets[norm_lookup].add(hop_table)

        # Also extract lookup tables from transformation expressions in edges
        for edge in edges:
            transform = edge.get("transformation", "")
            if transform:
                # Find lookup table references in transformation
                matches = lookup_pattern.findall(transform)
                for match in matches:
                    norm_lookup = self._normalize_table_name(match)
                    all_lookup_tables.add(norm_lookup)
                    # If table already exists, mark it as lookup type
                    if norm_lookup in tables:
                        tables[norm_lookup]["type"] = "lookup"
                    # Connect lookup to the target table of this edge
                    target_table = edge.get("target_table")
                    if target_table:
                        if norm_lookup not in lookup_table_targets:
                            lookup_table_targets[norm_lookup] = set()
                        lookup_table_targets[norm_lookup].add(target_table)

        # Also check if any existing tables match lookup naming patterns
        for table_name in list(tables.keys()):
            if lookup_pattern.match(table_name):
                tables[table_name]["type"] = "lookup"
                all_lookup_tables.add(table_name)
                # Update column types too
                for col_id, col_data in columns.items():
                    if col_data["table_name"] == table_name:
                        col_data["type"] = "lookup"

        # Scan file_lineages for source tables that match lookup patterns (even if not in column lineage)
        for file_name, file_info in self.file_lineages.items():
            if file_info.source_tables:
                for src_table in file_info.source_tables:
                    norm_src = self._normalize_table_name(src_table)
                    if lookup_pattern.match(norm_src) and norm_src not in all_lookup_tables:
                        all_lookup_tables.add(norm_src)
                        # Connect to the target table of this file
                        target_table = self._normalize_table_name(file_info.target_table) if file_info.target_table else None
                        if target_table:
                            if norm_src not in lookup_table_targets:
                                lookup_table_targets[norm_src] = set()
                            lookup_table_targets[norm_src].add(target_table)

            # Also scan SQL content for JOIN tables that match lookup patterns
            sql_content = file_info.sql_content
            # If sql_content is empty, try to read from file
            if not sql_content and file_info.file_path and os.path.exists(file_info.file_path):
                try:
                    with open(file_info.file_path, 'r', encoding='utf-8', errors='ignore') as f:
                        sql_content = f.read()
                except:
                    pass

            if sql_content:
                # Pattern to find table names after JOIN keywords
                join_table_pattern = re.compile(
                    r'(?:LEFT|RIGHT|INNER|OUTER|CROSS)?\s*(?:OUTER\s+)?JOIN\s+([A-Za-z_][A-Za-z0-9_]*\.)?([A-Za-z_][A-Za-z0-9_]*)',
                    re.IGNORECASE
                )
                for match in join_table_pattern.finditer(sql_content):
                    schema = match.group(1) or ""
                    table_name = match.group(2)
                    full_name = f"{schema}{table_name}" if schema else table_name
                    norm_table = self._normalize_table_name(full_name)

                    if lookup_pattern.match(norm_table) and norm_table not in all_lookup_tables:
                        all_lookup_tables.add(norm_table)
                        # Connect to the target table of this file
                        target_table = self._normalize_table_name(file_info.target_table) if file_info.target_table else None
                        if target_table:
                            if norm_table not in lookup_table_targets:
                                lookup_table_targets[norm_table] = set()
                            lookup_table_targets[norm_table].add(target_table)

        # Add lookup tables as nodes (or update existing ones)
        for lookup_table in all_lookup_tables:
            lookup_col_name = "[LOOKUP]"
            lookup_col_id = f"{lookup_table}.{lookup_col_name}"

            # If table already exists, just update its type
            if lookup_table in tables:
                tables[lookup_table]["type"] = "lookup"
                # Update all columns of this table to lookup type
                for col_id, col_data in columns.items():
                    if col_data["table_name"] == lookup_table:
                        col_data["type"] = "lookup"
                # Find an existing column to use as representative for edges
                existing_cols = [col_id for col_id, col_data in columns.items()
                                if col_data["table_name"] == lookup_table]
                if existing_cols:
                    lookup_col_id = existing_cols[0]
                    lookup_col_name = columns[lookup_col_id]["column_name"]
            else:
                # Add lookup table with a placeholder column for visualization
                tables[lookup_table] = {
                    "id": lookup_table,
                    "name": lookup_table,
                    "file": "",
                    "type": "lookup",
                    "columns": [lookup_col_name]
                }

                # Add the lookup column node
                columns[lookup_col_id] = {
                    "id": lookup_col_id,
                    "column_name": lookup_col_name,
                    "table_name": lookup_table,
                    "parent": lookup_table,
                    "hop_index": 0,
                    "type": "lookup",
                    "lineages": []
                }

            # Create edges from lookup column to target table columns
            if lookup_table in lookup_table_targets:
                for target_table in lookup_table_targets[lookup_table]:
                    # Find columns in target table to connect to
                    target_cols_in_table = [
                        col_id for col_id, col_data in columns.items()
                        if col_data["table_name"] == target_table and col_data["column_name"] != "[LOOKUP]"
                    ]

                    if target_cols_in_table:
                        # Connect to first column as representative (or could connect to all)
                        # For cleaner visualization, connect to one representative column
                        edge_key = f"{lookup_col_id}|{target_table}|lookup"
                        if edge_key not in edge_set:
                            edge_set.add(edge_key)
                            edges.append({
                                "source": lookup_col_id,
                                "target": target_cols_in_table[0],  # Connect to first column
                                "source_table": lookup_table,
                                "target_table": target_table,
                                "source_column": lookup_col_name,
                                "target_column": columns[target_cols_in_table[0]]["column_name"],
                                "transformation": "LOOKUP/JOIN",
                                "transformation_type": "LOOKUP",
                                "is_lookup_edge": True
                            })

        # Build column lineages for detail panel
        column_lineages = [lin.to_dict() for lin in lineages]

        return {
            "metadata": {
                "title": title if 'title' in dir() else "Field-Level Lineage",
                "total_columns": len(columns),
                "total_edges": len(edges),
                "total_tables": len(tables),
                "processing_order": [f for f in self.processing_order if f.endswith(('.sql', '.vw'))]
            },
            "tables": list(tables.values()),
            "columns": list(columns.values()),
            "edges": edges,
            "column_lineages": column_lineages
        }

    def _generate_field_level_html(self, graph_data: Dict[str, Any], title: str) -> str:
        """Generate interactive HTML with field-level Cytoscape.js visualization."""

        graph_json = json.dumps(graph_data, indent=2)

        html = f'''<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{title}</title>

    <!-- Cytoscape.js and layouts -->
    <script src="https://unpkg.com/cytoscape@3.28.1/dist/cytoscape.min.js"></script>
    <script src="https://unpkg.com/dagre@0.8.5/dist/dagre.min.js"></script>
    <script src="https://unpkg.com/cytoscape-dagre@2.5.0/cytoscape-dagre.js"></script>

    <style>
        * {{
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }}

        body {{
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #1a1a2e 0%, #16213e 100%);
            color: #eee;
            height: 100vh;
            overflow: hidden;
        }}

        .container {{
            display: flex;
            flex-direction: column;
            height: 100vh;
        }}

        /* Header */
        .header {{
            background: rgba(0, 0, 0, 0.3);
            padding: 15px 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            border-bottom: 1px solid #333;
        }}

        .header h1 {{
            color: #4fc3f7;
            font-size: 1.5em;
        }}

        .header-subtitle {{
            font-size: 0.85em;
            color: #aaa;
            margin-top: 5px;
        }}

        .stats {{
            display: flex;
            gap: 20px;
        }}

        .stat {{
            text-align: center;
            padding: 5px 15px;
            background: rgba(79, 195, 247, 0.1);
            border-radius: 5px;
            border: 1px solid #4fc3f7;
        }}

        .stat-value {{
            font-size: 1.3em;
            font-weight: bold;
            color: #4fc3f7;
        }}

        .stat-label {{
            font-size: 0.75em;
            color: #aaa;
        }}

        /* Controls */
        .controls {{
            background: rgba(0, 0, 0, 0.2);
            padding: 10px 20px;
            display: flex;
            gap: 15px;
            align-items: center;
            flex-wrap: wrap;
        }}

        .control-group {{
            display: flex;
            align-items: center;
            gap: 8px;
        }}

        .control-group label {{
            font-size: 0.85em;
            color: #aaa;
        }}

        input[type="text"] {{
            padding: 8px 12px;
            border: 1px solid #444;
            border-radius: 5px;
            background: #2a2a4a;
            color: #fff;
            width: 200px;
        }}

        input[type="text"]:focus {{
            outline: none;
            border-color: #4fc3f7;
        }}

        select {{
            padding: 8px 12px;
            border: 1px solid #444;
            border-radius: 5px;
            background: #2a2a4a;
            color: #fff;
        }}

        button {{
            padding: 8px 16px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 0.85em;
            transition: all 0.2s;
        }}

        .btn-primary {{
            background: #4fc3f7;
            color: #000;
        }}

        .btn-primary:hover {{
            background: #81d4fa;
        }}

        .btn-secondary {{
            background: #444;
            color: #fff;
        }}

        .btn-secondary:hover {{
            background: #555;
        }}

        .btn-active {{
            background: #ff9800;
            color: #000;
        }}

        /* Main content */
        .main-content {{
            display: flex;
            flex: 1;
            overflow: hidden;
        }}

        /* Graph container */
        #cy {{
            flex: 1;
            background: linear-gradient(135deg, #0d1b2a 0%, #1b263b 100%);
        }}

        /* Side panel */
        .side-panel {{
            width: 420px;
            background: rgba(0, 0, 0, 0.4);
            border-left: 1px solid #333;
            overflow-y: auto;
            transition: width 0.3s;
        }}

        .side-panel.hidden {{
            width: 0;
            border: none;
            overflow: hidden;
        }}

        .panel-header {{
            padding: 15px;
            background: rgba(79, 195, 247, 0.1);
            border-bottom: 1px solid #333;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }}

        .panel-header h3 {{
            color: #4fc3f7;
            word-break: break-all;
        }}

        .close-btn {{
            background: none;
            border: none;
            color: #aaa;
            font-size: 1.5em;
            cursor: pointer;
            padding: 0 10px;
        }}

        .close-btn:hover {{
            color: #fff;
        }}

        .panel-content {{
            padding: 15px;
        }}

        /* Lineage path */
        .lineage-path {{
            margin: 15px 0;
        }}

        .lineage-path h4 {{
            color: #4fc3f7;
            margin-bottom: 15px;
            font-size: 0.95em;
        }}

        .hop {{
            display: flex;
            align-items: flex-start;
            margin-bottom: 5px;
        }}

        .hop-indicator {{
            width: 30px;
            display: flex;
            flex-direction: column;
            align-items: center;
        }}

        .hop-dot {{
            width: 14px;
            height: 14px;
            border-radius: 50%;
            background: #4fc3f7;
            border: 2px solid #fff;
        }}

        .hop-line {{
            width: 2px;
            height: 40px;
            background: linear-gradient(to bottom, #4fc3f7, #4fc3f7);
        }}

        .hop.source .hop-dot {{ background: #2e7d32; }}
        .hop.intermediate .hop-dot {{ background: #546e7a; }}
        .hop.target .hop-dot {{ background: #7b1fa2; }}

        .hop-content {{
            flex: 1;
            background: rgba(255, 255, 255, 0.05);
            padding: 10px 12px;
            border-radius: 5px;
            margin-left: 10px;
            border-left: 3px solid #4fc3f7;
        }}

        .hop.source .hop-content {{ border-left-color: #2e7d32; }}
        .hop.intermediate .hop-content {{ border-left-color: #546e7a; }}
        .hop.target .hop-content {{ border-left-color: #7b1fa2; }}

        .hop-table {{
            font-weight: bold;
            color: #4fc3f7;
            font-size: 0.9em;
        }}

        .hop-column {{
            color: #fff;
            margin-top: 3px;
            font-size: 1em;
        }}

        .hop-transform {{
            font-size: 0.8em;
            color: #aaa;
            margin-top: 8px;
            font-family: 'Consolas', 'Monaco', monospace;
            background: rgba(0, 0, 0, 0.3);
            padding: 8px;
            border-radius: 3px;
            max-height: 100px;
            overflow-y: auto;
            word-break: break-all;
            white-space: pre-wrap;
        }}

        .hop-file {{
            font-size: 0.75em;
            color: #666;
            margin-top: 5px;
        }}

        .hop-type {{
            display: inline-block;
            font-size: 0.7em;
            padding: 2px 6px;
            border-radius: 3px;
            background: rgba(79, 195, 247, 0.2);
            color: #4fc3f7;
            margin-top: 5px;
        }}

        /* Legend */
        .legend {{
            position: absolute;
            bottom: 20px;
            left: 20px;
            background: rgba(0, 0, 0, 0.8);
            padding: 15px;
            border-radius: 8px;
            border: 1px solid #333;
            z-index: 100;
        }}

        .legend h4 {{
            color: #4fc3f7;
            margin-bottom: 10px;
            font-size: 0.9em;
        }}

        .legend-item {{
            display: flex;
            align-items: center;
            gap: 10px;
            margin: 5px 0;
            font-size: 0.85em;
        }}

        .legend-color {{
            width: 24px;
            height: 24px;
            border-radius: 4px;
            border: 2px solid rgba(255,255,255,0.3);
        }}

        .source-color {{ background: linear-gradient(135deg, #1b5e20, #2e7d32); }}
        .intermediate-color {{ background: linear-gradient(135deg, #37474f, #546e7a); }}
        .target-color {{ background: linear-gradient(135deg, #4a148c, #7b1fa2); }}
        .lookup-color {{ background: linear-gradient(135deg, #ff9800, #f57c00); border-style: dashed; }}

        /* Info section */
        .info-section {{
            margin: 15px 0;
            padding: 12px;
            background: rgba(255, 255, 255, 0.05);
            border-radius: 5px;
        }}

        .info-section h4 {{
            color: #4fc3f7;
            margin-bottom: 10px;
            font-size: 0.9em;
        }}

        .info-row {{
            display: flex;
            justify-content: space-between;
            padding: 5px 0;
            border-bottom: 1px solid rgba(255,255,255,0.1);
        }}

        .info-row:last-child {{
            border-bottom: none;
        }}

        .info-label {{
            color: #aaa;
            font-size: 0.85em;
        }}

        .info-value {{
            color: #fff;
            font-size: 0.85em;
            text-align: right;
            max-width: 200px;
            word-break: break-all;
        }}

        /* Lookup tables section */
        .lookup-section {{
            background: rgba(255, 152, 0, 0.1);
            border-left: 3px solid #ff9800;
        }}

        .lookup-section h4 {{
            color: #ffb74d;
        }}

        .lookup-table {{
            color: #ffcc80;
            font-family: monospace;
            text-align: left;
        }}

        /* Instructions */
        .instructions {{
            position: absolute;
            top: 150px;
            right: 20px;
            background: rgba(0, 0, 0, 0.8);
            padding: 15px;
            border-radius: 8px;
            border: 1px solid #333;
            font-size: 0.8em;
            max-width: 200px;
            z-index: 100;
        }}

        .instructions h4 {{
            color: #4fc3f7;
            margin-bottom: 8px;
        }}

        .instructions ul {{
            list-style: none;
            color: #aaa;
        }}

        .instructions li {{
            margin: 5px 0;
        }}

        .instructions li::before {{
            content: ">";
            color: #4fc3f7;
            margin-right: 5px;
        }}

        /* Edge tooltip */
        .edge-tooltip {{
            position: absolute;
            background: rgba(0, 0, 0, 0.9);
            border: 1px solid #4fc3f7;
            padding: 10px;
            border-radius: 5px;
            font-size: 0.8em;
            max-width: 300px;
            z-index: 1000;
            display: none;
        }}

        .edge-tooltip.visible {{
            display: block;
        }}

        .edge-tooltip h5 {{
            color: #4fc3f7;
            margin-bottom: 5px;
        }}

        .edge-tooltip p {{
            color: #ddd;
            margin: 3px 0;
        }}

        .edge-tooltip code {{
            display: block;
            background: rgba(255,255,255,0.1);
            padding: 5px;
            margin-top: 5px;
            border-radius: 3px;
            font-family: 'Consolas', monospace;
            font-size: 0.9em;
            max-height: 80px;
            overflow-y: auto;
            word-break: break-all;
        }}

        /* View mode toggle */
        .view-toggle {{
            display: flex;
            gap: 5px;
            background: rgba(0,0,0,0.3);
            padding: 3px;
            border-radius: 5px;
        }}

        .view-toggle button {{
            padding: 6px 12px;
            font-size: 0.8em;
        }}

        .view-toggle button.active {{
            background: #4fc3f7;
            color: #000;
        }}

        /* ===== NEW UI/UX IMPROVEMENTS ===== */

        /* Minimap */
        #minimap {{
            position: absolute;
            bottom: 20px;
            right: 20px;
            width: 200px;
            height: 150px;
            background: rgba(0, 0, 0, 0.85);
            border: 2px solid #4fc3f7;
            border-radius: 8px;
            z-index: 200;
            overflow: hidden;
            cursor: crosshair;
        }}

        #minimap-canvas {{
            width: 100%;
            height: 100%;
        }}

        #minimap-viewport {{
            position: absolute;
            border: 2px solid #ffeb3b;
            background: rgba(255, 235, 59, 0.15);
            pointer-events: none;
        }}

        .minimap-header {{
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            background: rgba(79, 195, 247, 0.2);
            padding: 3px 8px;
            font-size: 0.7em;
            color: #4fc3f7;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }}

        .minimap-toggle {{
            cursor: pointer;
            padding: 2px 6px;
            background: rgba(0,0,0,0.3);
            border-radius: 3px;
        }}

        .minimap-toggle:hover {{
            background: rgba(255,255,255,0.1);
        }}

        #minimap.collapsed {{
            height: 24px;
        }}

        #minimap.collapsed #minimap-canvas,
        #minimap.collapsed #minimap-viewport {{
            display: none;
        }}

        /* Quick Navigation Panel */
        .nav-panel {{
            position: absolute;
            left: 0;
            top: 0;
            bottom: 0;
            width: 280px;
            background: rgba(0, 0, 0, 0.9);
            border-right: 1px solid #333;
            z-index: 150;
            display: flex;
            flex-direction: column;
            transition: transform 0.3s ease;
        }}

        .nav-panel.collapsed {{
            transform: translateX(-250px);
        }}

        .nav-panel-header {{
            padding: 12px 15px;
            background: rgba(79, 195, 247, 0.1);
            border-bottom: 1px solid #333;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }}

        .nav-panel-header h4 {{
            color: #4fc3f7;
            font-size: 0.9em;
            margin: 0;
        }}

        .nav-panel-toggle {{
            position: absolute;
            right: -30px;
            top: 50%;
            transform: translateY(-50%);
            width: 30px;
            height: 60px;
            background: rgba(0, 0, 0, 0.9);
            border: 1px solid #333;
            border-left: none;
            border-radius: 0 5px 5px 0;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            color: #4fc3f7;
            font-size: 1.2em;
        }}

        .nav-panel-toggle:hover {{
            background: rgba(79, 195, 247, 0.2);
        }}

        .nav-panel-content {{
            flex: 1;
            overflow-y: auto;
            padding: 10px 0;
        }}

        .nav-group {{
            margin-bottom: 10px;
        }}

        .nav-group-header {{
            padding: 8px 15px;
            color: #888;
            font-size: 0.75em;
            text-transform: uppercase;
            letter-spacing: 1px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }}

        .nav-group-count {{
            background: rgba(255,255,255,0.1);
            padding: 2px 6px;
            border-radius: 10px;
            font-size: 0.9em;
        }}

        .nav-item {{
            padding: 8px 15px 8px 25px;
            cursor: pointer;
            display: flex;
            justify-content: space-between;
            align-items: center;
            font-size: 0.85em;
            color: #ccc;
            transition: background 0.2s;
        }}

        .nav-item:hover {{
            background: rgba(79, 195, 247, 0.15);
            color: #fff;
        }}

        .nav-item.active {{
            background: rgba(79, 195, 247, 0.25);
            color: #4fc3f7;
            border-left: 3px solid #4fc3f7;
            padding-left: 22px;
        }}

        .nav-item-badge {{
            background: rgba(255,255,255,0.1);
            padding: 2px 6px;
            border-radius: 10px;
            font-size: 0.8em;
            color: #888;
        }}

        .nav-item.source {{ border-left: 3px solid #2e7d32; padding-left: 22px; }}
        .nav-item.intermediate {{ border-left: 3px solid #546e7a; padding-left: 22px; }}
        .nav-item.target {{ border-left: 3px solid #7b1fa2; padding-left: 22px; }}
        .nav-item.lookup {{ border-left: 3px solid #ff9800; padding-left: 22px; }}

        /* Position/Progress Indicator */
        .position-indicator {{
            position: absolute;
            bottom: 180px;
            right: 20px;
            background: rgba(0, 0, 0, 0.85);
            border: 1px solid #333;
            border-radius: 8px;
            padding: 12px 15px;
            z-index: 100;
            min-width: 180px;
        }}

        .position-indicator h5 {{
            color: #4fc3f7;
            font-size: 0.8em;
            margin: 0 0 10px 0;
        }}

        .position-text {{
            font-size: 0.85em;
            color: #ccc;
            margin-bottom: 8px;
        }}

        .progress-bar-container {{
            height: 6px;
            background: rgba(255,255,255,0.1);
            border-radius: 3px;
            overflow: hidden;
        }}

        .progress-bar {{
            height: 100%;
            background: linear-gradient(90deg, #2e7d32, #4fc3f7, #7b1fa2);
            border-radius: 3px;
            transition: width 0.3s ease;
        }}

        .progress-markers {{
            display: flex;
            justify-content: space-between;
            margin-top: 5px;
            font-size: 0.7em;
            color: #666;
        }}

        /* Search Autocomplete */
        .search-container {{
            position: relative;
        }}

        .autocomplete-dropdown {{
            position: absolute;
            top: 100%;
            left: 0;
            right: 0;
            background: rgba(42, 42, 74, 0.98);
            border: 1px solid #4fc3f7;
            border-top: none;
            border-radius: 0 0 5px 5px;
            max-height: 300px;
            overflow-y: auto;
            z-index: 1000;
            display: none;
        }}

        .autocomplete-dropdown.visible {{
            display: block;
        }}

        .autocomplete-group {{
            padding: 5px 0;
            border-bottom: 1px solid rgba(255,255,255,0.1);
        }}

        .autocomplete-group:last-child {{
            border-bottom: none;
        }}

        .autocomplete-group-header {{
            padding: 5px 12px;
            font-size: 0.7em;
            color: #888;
            text-transform: uppercase;
        }}

        .autocomplete-item {{
            padding: 8px 12px;
            cursor: pointer;
            display: flex;
            justify-content: space-between;
            align-items: center;
            font-size: 0.85em;
        }}

        .autocomplete-item:hover,
        .autocomplete-item.selected {{
            background: rgba(79, 195, 247, 0.2);
        }}

        .autocomplete-item-name {{
            color: #fff;
        }}

        .autocomplete-item-type {{
            font-size: 0.75em;
            padding: 2px 6px;
            border-radius: 3px;
            background: rgba(255,255,255,0.1);
            color: #888;
        }}

        .search-match-count {{
            margin-left: 10px;
            font-size: 0.8em;
            color: #888;
            padding: 4px 8px;
            background: rgba(255,255,255,0.05);
            border-radius: 3px;
        }}

        /* Help Modal */
        .help-modal {{
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(0, 0, 0, 0.85);
            z-index: 2000;
            display: none;
            justify-content: center;
            align-items: center;
        }}

        .help-modal.visible {{
            display: flex;
        }}

        .help-content {{
            background: #1a1a2e;
            border: 2px solid #4fc3f7;
            border-radius: 12px;
            padding: 25px 35px;
            max-width: 700px;
            max-height: 80vh;
            overflow-y: auto;
        }}

        .help-content h2 {{
            color: #4fc3f7;
            margin: 0 0 20px 0;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }}

        .help-close {{
            cursor: pointer;
            font-size: 1.5em;
            color: #888;
            padding: 5px 10px;
        }}

        .help-close:hover {{
            color: #fff;
        }}

        .help-section {{
            margin-bottom: 20px;
        }}

        .help-section h3 {{
            color: #81d4fa;
            font-size: 1em;
            margin: 0 0 12px 0;
            padding-bottom: 5px;
            border-bottom: 1px solid #333;
        }}

        .shortcut-grid {{
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 8px 20px;
        }}

        .shortcut-item {{
            display: flex;
            align-items: center;
            gap: 10px;
            font-size: 0.85em;
        }}

        .shortcut-key {{
            background: #333;
            padding: 4px 10px;
            border-radius: 4px;
            font-family: 'Consolas', monospace;
            color: #4fc3f7;
            min-width: 60px;
            text-align: center;
            border: 1px solid #444;
        }}

        .shortcut-desc {{
            color: #ccc;
        }}

        /* Breadcrumb Trail */
        .breadcrumb-container {{
            background: rgba(0, 0, 0, 0.3);
            padding: 8px 20px;
            border-bottom: 1px solid #333;
            display: none;
            align-items: center;
            gap: 8px;
            font-size: 0.85em;
            overflow-x: auto;
            white-space: nowrap;
        }}

        .breadcrumb-container.visible {{
            display: flex;
        }}

        .breadcrumb-label {{
            color: #888;
            margin-right: 5px;
        }}

        .breadcrumb-item {{
            display: inline-flex;
            align-items: center;
            gap: 8px;
            color: #ccc;
            cursor: pointer;
            padding: 4px 8px;
            border-radius: 4px;
            transition: background 0.2s;
        }}

        .breadcrumb-item:hover {{
            background: rgba(79, 195, 247, 0.2);
            color: #fff;
        }}

        .breadcrumb-item.current {{
            background: rgba(79, 195, 247, 0.3);
            color: #4fc3f7;
        }}

        .breadcrumb-item.source {{ color: #81c784; }}
        .breadcrumb-item.target {{ color: #ce93d8; }}

        .breadcrumb-arrow {{
            color: #555;
            font-size: 0.8em;
        }}

        .breadcrumb-ellipsis {{
            color: #555;
            padding: 0 5px;
        }}

        /* Adjust main content for nav panel */
        .main-content {{
            position: relative;
        }}

        .main-content.with-nav-panel #cy {{
            margin-left: 30px;
        }}

        .main-content.with-nav-panel.nav-expanded #cy {{
            margin-left: 280px;
        }}

        /* Keyboard hint badges in controls */
        .kbd-hint {{
            font-size: 0.7em;
            color: #666;
            margin-left: 5px;
            background: rgba(255,255,255,0.05);
            padding: 2px 5px;
            border-radius: 3px;
            font-family: 'Consolas', monospace;
        }}
    </style>
</head>
<body>
    <div class="container">
        <!-- Header -->
        <div class="header">
            <div>
                <h1>{title}</h1>
                <div class="header-subtitle">Click on any column to trace its complete lineage</div>
            </div>
            <div class="stats">
                <div class="stat">
                    <div class="stat-value" id="statTables">0</div>
                    <div class="stat-label">Tables</div>
                </div>
                <div class="stat">
                    <div class="stat-value" id="statColumns">0</div>
                    <div class="stat-label">Columns</div>
                </div>
                <div class="stat">
                    <div class="stat-value" id="statEdges">0</div>
                    <div class="stat-label">Flows</div>
                </div>
            </div>
        </div>

        <!-- Controls -->
        <div class="controls">
            <div class="control-group search-container">
                <label>Search:</label>
                <input type="text" id="searchInput" placeholder="Search tables or columns... (/)">
                <span class="search-match-count" id="searchMatchCount" style="display: none;">0 matches</span>
                <div class="autocomplete-dropdown" id="autocompleteDropdown">
                    <!-- Populated by JavaScript -->
                </div>
            </div>
            <div class="control-group">
                <label>Filter Table:</label>
                <select id="tableFilter">
                    <option value="">All Tables</option>
                </select>
            </div>
            <div class="control-group">
                <button class="btn-primary" onclick="fitGraph()">Fit View<span class="kbd-hint">F</span></button>
                <button class="btn-secondary" onclick="zoomIn()">Zoom +</button>
                <button class="btn-secondary" onclick="zoomOut()">Zoom -</button>
                <button class="btn-secondary" onclick="resetGraph()">Reset<span class="kbd-hint">R</span></button>
            </div>
            <div class="control-group view-toggle">
                <button id="viewExpanded" class="active" onclick="setViewMode('expanded')">Expanded</button>
                <button id="viewCompact" onclick="setViewMode('compact')">Compact</button>
            </div>
            <div class="control-group">
                <button class="btn-secondary" onclick="collapseAllTables()">Collapse All<span class="kbd-hint">C</span></button>
                <button class="btn-secondary" onclick="expandAllTables()">Expand All<span class="kbd-hint">E</span></button>
            </div>
            <div class="control-group">
                <button class="btn-secondary" onclick="togglePanel()">Toggle Details<span class="kbd-hint">D</span></button>
                <button class="btn-secondary" onclick="toggleHelp()">Help<span class="kbd-hint">H</span></button>
            </div>
        </div>

        <!-- Breadcrumb Trail -->
        <div class="breadcrumb-container" id="breadcrumbContainer">
            <span class="breadcrumb-label">Lineage:</span>
            <div id="breadcrumbTrail">
                <!-- Populated by JavaScript when a column is selected -->
            </div>
        </div>

        <!-- Main content -->
        <div class="main-content">
            <!-- Cytoscape container -->
            <div id="cy"></div>

            <!-- Side panel for details -->
            <div class="side-panel" id="sidePanel">
                <div class="panel-header">
                    <h3 id="panelTitle">Select a Column</h3>
                    <button class="close-btn" onclick="closePanel()">&times;</button>
                </div>
                <div class="panel-content" id="panelContent">
                    <p style="color: #aaa;">Click on any column node in the graph to see its complete lineage path from source to target.</p>
                </div>
            </div>
        </div>
    </div>

    <!-- Legend -->
    <div class="legend">
        <h4>Legend</h4>
        <div class="legend-item">
            <div class="legend-color source-color"></div>
            <span>Source Column</span>
        </div>
        <div class="legend-item">
            <div class="legend-color intermediate-color"></div>
            <span>Intermediate Column</span>
        </div>
        <div class="legend-item">
            <div class="legend-color target-color"></div>
            <span>Target Column</span>
        </div>
        <div class="legend-item">
            <div class="legend-color lookup-color"></div>
            <span>Lookup/Reference Table</span>
        </div>
    </div>

    <!-- Instructions -->
    <div class="instructions">
        <h4>Quick Tips</h4>
        <ul>
            <li>Press <b>H</b> for help</li>
            <li>Arrow keys to pan</li>
            <li>Click column for lineage</li>
            <li>Double-click table to collapse</li>
            <li>Use minimap to navigate</li>
        </ul>
    </div>

    <!-- Edge tooltip -->
    <div class="edge-tooltip" id="edgeTooltip">
        <h5>Transformation</h5>
        <p id="tooltipSource"></p>
        <p id="tooltipTarget"></p>
        <code id="tooltipTransform"></code>
    </div>

    <!-- Quick Navigation Panel -->
    <div class="nav-panel collapsed" id="navPanel">
        <div class="nav-panel-header">
            <h4>Tables</h4>
        </div>
        <div class="nav-panel-content" id="navPanelContent">
            <!-- Populated by JavaScript -->
        </div>
        <div class="nav-panel-toggle" onclick="toggleNavPanel()" title="Toggle Navigation (N)">
            <span id="navToggleIcon">&#9654;</span>
        </div>
    </div>

    <!-- Minimap -->
    <div id="minimap">
        <div class="minimap-header">
            <span>Minimap</span>
            <span class="minimap-toggle" onclick="toggleMinimap()">_</span>
        </div>
        <canvas id="minimap-canvas"></canvas>
        <div id="minimap-viewport"></div>
    </div>

    <!-- Position Indicator -->
    <div class="position-indicator" id="positionIndicator">
        <h5>Position</h5>
        <div class="position-text" id="positionText">Viewing all tables</div>
        <div class="progress-bar-container">
            <div class="progress-bar" id="progressBar" style="width: 100%;"></div>
        </div>
        <div class="progress-markers">
            <span>Source</span>
            <span>Target</span>
        </div>
    </div>

    <!-- Help Modal -->
    <div class="help-modal" id="helpModal">
        <div class="help-content">
            <h2>
                <span>Keyboard Shortcuts & Help</span>
                <span class="help-close" onclick="toggleHelp()">&times;</span>
            </h2>
            <div class="help-section">
                <h3>Navigation</h3>
                <div class="shortcut-grid">
                    <div class="shortcut-item">
                        <span class="shortcut-key">Arrow/WASD</span>
                        <span class="shortcut-desc">Pan the graph</span>
                    </div>
                    <div class="shortcut-item">
                        <span class="shortcut-key">+ / -</span>
                        <span class="shortcut-desc">Zoom in/out</span>
                    </div>
                    <div class="shortcut-item">
                        <span class="shortcut-key">F</span>
                        <span class="shortcut-desc">Fit graph to view</span>
                    </div>
                    <div class="shortcut-item">
                        <span class="shortcut-key">R</span>
                        <span class="shortcut-desc">Reset view</span>
                    </div>
                    <div class="shortcut-item">
                        <span class="shortcut-key">Home</span>
                        <span class="shortcut-desc">Jump to first table</span>
                    </div>
                    <div class="shortcut-item">
                        <span class="shortcut-key">End</span>
                        <span class="shortcut-desc">Jump to last table</span>
                    </div>
                </div>
            </div>
            <div class="help-section">
                <h3>Tables & Columns</h3>
                <div class="shortcut-grid">
                    <div class="shortcut-item">
                        <span class="shortcut-key">N</span>
                        <span class="shortcut-desc">Toggle nav panel / Next table</span>
                    </div>
                    <div class="shortcut-item">
                        <span class="shortcut-key">P</span>
                        <span class="shortcut-desc">Previous table</span>
                    </div>
                    <div class="shortcut-item">
                        <span class="shortcut-key">C</span>
                        <span class="shortcut-desc">Collapse all tables</span>
                    </div>
                    <div class="shortcut-item">
                        <span class="shortcut-key">E</span>
                        <span class="shortcut-desc">Expand all tables</span>
                    </div>
                </div>
            </div>
            <div class="help-section">
                <h3>Search & Selection</h3>
                <div class="shortcut-grid">
                    <div class="shortcut-item">
                        <span class="shortcut-key">/ or Ctrl+F</span>
                        <span class="shortcut-desc">Focus search</span>
                    </div>
                    <div class="shortcut-item">
                        <span class="shortcut-key">Escape</span>
                        <span class="shortcut-desc">Clear selection/search</span>
                    </div>
                </div>
            </div>
            <div class="help-section">
                <h3>Interface</h3>
                <div class="shortcut-grid">
                    <div class="shortcut-item">
                        <span class="shortcut-key">H / ?</span>
                        <span class="shortcut-desc">Toggle this help</span>
                    </div>
                    <div class="shortcut-item">
                        <span class="shortcut-key">M</span>
                        <span class="shortcut-desc">Toggle minimap</span>
                    </div>
                    <div class="shortcut-item">
                        <span class="shortcut-key">D</span>
                        <span class="shortcut-desc">Toggle details panel</span>
                    </div>
                </div>
            </div>
            <div class="help-section">
                <h3>Mouse Interactions</h3>
                <div style="color: #ccc; font-size: 0.85em;">
                    <p style="margin: 5px 0;"><strong>Click column:</strong> View lineage path</p>
                    <p style="margin: 5px 0;"><strong>Click table:</strong> View table info</p>
                    <p style="margin: 5px 0;"><strong>Double-click table:</strong> Collapse/expand columns</p>
                    <p style="margin: 5px 0;"><strong>Hover edge:</strong> View transformation</p>
                    <p style="margin: 5px 0;"><strong>Scroll:</strong> Zoom in/out</p>
                    <p style="margin: 5px 0;"><strong>Drag:</strong> Pan the graph</p>
                    <p style="margin: 5px 0;"><strong>Click minimap:</strong> Navigate to location</p>
                </div>
            </div>
        </div>
    </div>

    <script>
        // Graph data from Python
        const graphData = {graph_json};

        // Color schemes for node types - darker, more readable colors
        const colors = {{
            source: {{ bg: '#1b5e20', border: '#2e7d32', text: '#e8f5e9' }},
            intermediate: {{ bg: '#37474f', border: '#546e7a', text: '#eceff1' }},
            target: {{ bg: '#4a148c', border: '#7b1fa2', text: '#f3e5f5' }},
            lookup: {{ bg: '#e65100', border: '#ff9800', text: '#fff3e0' }}
        }};

        let cy;
        let currentViewMode = 'expanded';

        function initGraph() {{
            const elements = [];

            // Add parent table nodes (compound nodes)
            graphData.tables.forEach(table => {{
                elements.push({{
                    data: {{
                        id: table.id,
                        label: table.name,
                        type: table.type,
                        isTable: true
                    }},
                    classes: `table ${{table.type}}`
                }});
            }});

            // Add column nodes with parent reference
            graphData.columns.forEach(col => {{
                const color = colors[col.type] || colors.intermediate;
                elements.push({{
                    data: {{
                        id: col.id,
                        label: col.column_name,
                        parent: col.parent,
                        table_name: col.table_name,
                        type: col.type,
                        isColumn: true
                    }},
                    classes: `column ${{col.type}}`
                }});
            }});

            // Add edges between columns
            graphData.edges.forEach((edge, idx) => {{
                elements.push({{
                    data: {{
                        id: `edge_${{idx}}`,
                        source: edge.source,
                        target: edge.target,
                        source_column: edge.source_column,
                        target_column: edge.target_column,
                        transformation: edge.transformation,
                        transformation_type: edge.transformation_type,
                        is_lookup_edge: edge.is_lookup_edge || false,
                        label: edge.transformation_type === 'DIRECT' ? '' : (edge.is_lookup_edge ? '◆' : '*')
                    }},
                    classes: edge.is_lookup_edge ? 'lookup' : (edge.transformation_type === 'DIRECT' ? 'direct' : 'transformed')
                }});
            }});

            // Create Cytoscape instance
            cy = cytoscape({{
                container: document.getElementById('cy'),
                elements: elements,
                style: [
                    // Parent table node styles
                    {{
                        selector: 'node.table',
                        style: {{
                            'shape': 'roundrectangle',
                            'background-color': 'rgba(255,255,255,0.05)',
                            'border-width': 2,
                            'border-color': '#555',
                            'label': 'data(label)',
                            'text-valign': 'top',
                            'text-halign': 'center',
                            'text-margin-y': -10,
                            'font-size': '14px',
                            'font-weight': 'bold',
                            'color': '#4fc3f7',
                            'text-outline-width': 0,
                            'padding': '20px',
                            'compound-sizing-wrt-labels': 'include'
                        }}
                    }},
                    {{
                        selector: 'node.table.source',
                        style: {{
                            'border-color': '#2e7d32',
                            'background-color': 'rgba(27, 94, 32, 0.15)'
                        }}
                    }},
                    {{
                        selector: 'node.table.intermediate',
                        style: {{
                            'border-color': '#546e7a',
                            'background-color': 'rgba(55, 71, 79, 0.15)'
                        }}
                    }},
                    {{
                        selector: 'node.table.target',
                        style: {{
                            'border-color': '#7b1fa2',
                            'background-color': 'rgba(74, 20, 140, 0.15)'
                        }}
                    }},
                    {{
                        selector: 'node.table.lookup',
                        style: {{
                            'border-color': '#ff9800',
                            'background-color': 'rgba(255, 152, 0, 0.2)',
                            'border-style': 'dashed',
                            'shape': 'diamond'
                        }}
                    }},
                    // Column node styles - darker colors with light text for readability
                    {{
                        selector: 'node.column',
                        style: {{
                            'shape': 'roundrectangle',
                            'width': 'label',
                            'height': 28,
                            'padding': '8px',
                            'background-color': '#37474f',
                            'border-width': 2,
                            'border-color': '#546e7a',
                            'label': 'data(label)',
                            'text-valign': 'center',
                            'text-halign': 'center',
                            'font-size': '11px',
                            'font-weight': 'bold',
                            'color': '#eceff1',
                            'text-outline-width': 0,
                            'cursor': 'pointer'
                        }}
                    }},
                    {{
                        selector: 'node.column.source',
                        style: {{
                            'background-color': '#1b5e20',
                            'border-color': '#2e7d32',
                            'color': '#e8f5e9'
                        }}
                    }},
                    {{
                        selector: 'node.column.intermediate',
                        style: {{
                            'background-color': '#37474f',
                            'border-color': '#546e7a',
                            'color': '#eceff1'
                        }}
                    }},
                    {{
                        selector: 'node.column.target',
                        style: {{
                            'background-color': '#4a148c',
                            'border-color': '#7b1fa2',
                            'color': '#f3e5f5'
                        }}
                    }},
                    {{
                        selector: 'node.column.lookup',
                        style: {{
                            'background-color': '#ff8f00',
                            'border-color': '#ff6f00',
                            'color': '#fff3e0',
                            'shape': 'diamond'
                        }}
                    }},
                    {{
                        selector: 'node.column:selected',
                        style: {{
                            'border-width': 4,
                            'border-color': '#ffeb3b',
                            'background-color': '#ffc107',
                            'color': '#000'
                        }}
                    }},
                    {{
                        selector: 'node.column.highlighted',
                        style: {{
                            'border-width': 4,
                            'border-color': '#00e5ff',
                            'z-index': 999
                        }}
                    }},
                    {{
                        selector: 'node.dimmed',
                        style: {{
                            'opacity': 0.2
                        }}
                    }},
                    // Edge styles
                    {{
                        selector: 'edge',
                        style: {{
                            'width': 2,
                            'line-color': '#4fc3f7',
                            'target-arrow-color': '#4fc3f7',
                            'target-arrow-shape': 'triangle',
                            'arrow-scale': 1.2,
                            'curve-style': 'bezier',
                            'opacity': 0.7
                        }}
                    }},
                    {{
                        selector: 'edge.transformed',
                        style: {{
                            'line-style': 'solid',
                            'line-color': '#ff9800',
                            'target-arrow-color': '#ff9800',
                            'width': 3
                        }}
                    }},
                    {{
                        selector: 'edge.lookup',
                        style: {{
                            'line-style': 'dashed',
                            'line-color': '#ff9800',
                            'target-arrow-color': '#ff9800',
                            'width': 2,
                            'opacity': 0.8
                        }}
                    }},
                    {{
                        selector: 'edge:selected',
                        style: {{
                            'width': 4,
                            'line-color': '#ffeb3b',
                            'target-arrow-color': '#ffeb3b',
                            'opacity': 1
                        }}
                    }},
                    {{
                        selector: 'edge.highlighted',
                        style: {{
                            'width': 4,
                            'line-color': '#00e5ff',
                            'target-arrow-color': '#00e5ff',
                            'opacity': 1,
                            'z-index': 999
                        }}
                    }},
                    {{
                        selector: 'edge.dimmed',
                        style: {{
                            'opacity': 0.1
                        }}
                    }}
                ],
                layout: {{
                    name: 'dagre',
                    rankDir: 'LR',
                    nodeSep: 15,
                    rankSep: 100,
                    edgeSep: 10,
                    padding: 30
                }},
                minZoom: 0.1,
                maxZoom: 4,
                wheelSensitivity: 0.3
            }});

            // Event handlers
            cy.on('tap', 'node.column', function(evt) {{
                const node = evt.target;
                showColumnLineage(node.data());
                highlightColumnPath(node);
            }});

            cy.on('tap', 'node.table', function(evt) {{
                const node = evt.target;
                showTableInfo(node.data());
            }});

            cy.on('tap', 'edge', function(evt) {{
                const edge = evt.target;
                showEdgeDetails(edge.data());
            }});

            cy.on('tap', function(evt) {{
                if (evt.target === cy) {{
                    cy.elements().removeClass('highlighted dimmed');
                }}
            }});

            // Edge hover for transformation tooltip
            const tooltip = document.getElementById('edgeTooltip');

            cy.on('mouseover', 'edge', function(evt) {{
                const edge = evt.target;
                const data = edge.data();

                if (data.transformation && data.transformation.trim()) {{
                    document.getElementById('tooltipSource').textContent = `From: ${{data.source_column}}`;
                    document.getElementById('tooltipTarget').textContent = `To: ${{data.target_column}}`;
                    document.getElementById('tooltipTransform').textContent = data.transformation;

                    const pos = evt.renderedPosition;
                    tooltip.style.left = (pos.x + 20) + 'px';
                    tooltip.style.top = (pos.y + 20) + 'px';
                    tooltip.classList.add('visible');
                }}
            }});

            cy.on('mouseout', 'edge', function() {{
                tooltip.classList.remove('visible');
            }});

            // Update stats
            document.getElementById('statTables').textContent = graphData.tables.length;
            document.getElementById('statColumns').textContent = graphData.columns.length;
            document.getElementById('statEdges').textContent = graphData.edges.length;

            // Populate table filter
            populateTableFilter();
        }}

        function populateTableFilter() {{
            const select = document.getElementById('tableFilter');
            graphData.tables.forEach(table => {{
                const option = document.createElement('option');
                option.value = table.id;
                option.textContent = `${{table.name}} (${{table.type}})`;
                select.appendChild(option);
            }});

            select.addEventListener('change', function() {{
                filterByTable(this.value);
            }});
        }}

        function filterByTable(tableName) {{
            if (!tableName) {{
                cy.elements().removeClass('dimmed');
                return;
            }}

            cy.elements().addClass('dimmed');

            // Highlight selected table and its columns
            const tableNode = cy.getElementById(tableName);
            tableNode.removeClass('dimmed');
            tableNode.children().removeClass('dimmed');

            // Highlight connected edges and their source/target columns
            tableNode.children().forEach(col => {{
                col.connectedEdges().removeClass('dimmed');
                col.connectedEdges().connectedNodes().removeClass('dimmed');
            }});
        }}

        function highlightColumnPath(node) {{
            // Highlight the entire lineage path for this column
            cy.elements().addClass('dimmed');

            const colId = node.id();

            // Helper to get table/column from hop (handles both key naming conventions)
            const getHopTable = (h) => h.table || h.table_name || '';
            const getHopColumn = (h) => h.column || h.column_name || '';

            // Find all lineages that include this column
            const relatedLineages = graphData.column_lineages.filter(lin =>
                lin.hops.some(h => `${{getHopTable(h)}}.${{getHopColumn(h)}}` === colId)
            );

            // Highlight all nodes and edges in those lineages
            relatedLineages.forEach(lin => {{
                lin.hops.forEach((hop, idx) => {{
                    const hopTable = getHopTable(hop);
                    const hopColumn = getHopColumn(hop);
                    const hopId = `${{hopTable}}.${{hopColumn}}`;
                    const hopNode = cy.getElementById(hopId);
                    if (hopNode.length) {{
                        hopNode.removeClass('dimmed').addClass('highlighted');
                        // Also highlight parent table
                        cy.getElementById(hopTable).removeClass('dimmed');
                    }}
                }});
            }});

            // Highlight connected edges
            cy.edges().forEach(edge => {{
                const src = edge.source();
                const tgt = edge.target();
                if (!src.hasClass('dimmed') && !tgt.hasClass('dimmed')) {{
                    edge.removeClass('dimmed').addClass('highlighted');
                }}
            }});

            node.removeClass('dimmed').addClass('highlighted');
        }}

        function showColumnLineage(data) {{
            const panel = document.getElementById('sidePanel');
            const title = document.getElementById('panelTitle');
            const content = document.getElementById('panelContent');

            panel.classList.remove('hidden');
            title.textContent = data.id;

            // Find the lineage that ends or contains this column
            const lineage = graphData.column_lineages.find(lin =>
                `${{lin.target_table}}.${{lin.target_column}}` === data.id
            ) || graphData.column_lineages.find(lin =>
                lin.hops.some(h => `${{h.table_name}}.${{h.column_name}}` === data.id)
            );

            if (!lineage) {{
                content.innerHTML = `
                    <div class="info-section">
                        <p>No lineage information found for this column.</p>
                    </div>
                `;
                return;
            }}

            let html = `
                <div class="info-section">
                    <h4>Column Information</h4>
                    <div class="info-row">
                        <span class="info-label">Table</span>
                        <span class="info-value">${{data.table_name}}</span>
                    </div>
                    <div class="info-row">
                        <span class="info-label">Column</span>
                        <span class="info-value">${{data.label}}</span>
                    </div>
                    <div class="info-row">
                        <span class="info-label">Type</span>
                        <span class="info-value">${{data.type.charAt(0).toUpperCase() + data.type.slice(1)}}</span>
                    </div>
                </div>
                <div class="info-section">
                    <h4>Ultimate Source</h4>
                    <div class="info-row">
                        <span class="info-label">Table</span>
                        <span class="info-value">${{lineage.ultimate_source_table}}</span>
                    </div>
                    <div class="info-row">
                        <span class="info-label">Column</span>
                        <span class="info-value">${{lineage.ultimate_source_column}}</span>
                    </div>
                    <div class="info-row">
                        <span class="info-label">Total Hops</span>
                        <span class="info-value">${{lineage.hop_count}}</span>
                    </div>
                </div>
                ${{lineage.lookup_tables && lineage.lookup_tables.length > 0 ? `
                <div class="info-section lookup-section">
                    <h4>Lookup/Reference Tables</h4>
                    ${{lineage.lookup_tables.map(table => `
                        <div class="info-row">
                            <span class="info-value lookup-table">${{table}}</span>
                        </div>
                    `).join('')}}
                </div>
                ` : ''}}
                <div class="lineage-path">
                    <h4>Complete Data Flow Path</h4>
            `;

            lineage.hops.forEach((hop, idx) => {{
                const hopType = idx === 0 ? 'source' : (idx === lineage.hops.length - 1 ? 'target' : 'intermediate');
                // Note: hop dict uses 'table' and 'column' keys (from to_dict method)
                const hopTable = hop.table || hop.table_name || '';
                const hopColumn = hop.column || hop.column_name || '';
                const hopId = `${{hopTable}}.${{hopColumn}}`;
                const isCurrent = hopId === data.id;

                html += `
                    <div class="hop ${{hopType}}" style="${{isCurrent ? 'transform: scale(1.02);' : ''}}">
                        <div class="hop-indicator">
                            <div class="hop-dot" style="${{isCurrent ? 'width: 18px; height: 18px;' : ''}}"></div>
                            ${{idx < lineage.hops.length - 1 ? '<div class="hop-line"></div>' : ''}}
                        </div>
                        <div class="hop-content" style="${{isCurrent ? 'background: rgba(79, 195, 247, 0.15);' : ''}}">
                            <div class="hop-table">${{hopTable}}</div>
                            <div class="hop-column">${{hopColumn}}</div>
                            ${{hop.transformation && hop.transformation !== hopColumn ?
                                `<div class="hop-transform">${{hop.transformation}}</div>` : ''}}
                            ${{hop.transformation_type ?
                                `<div class="hop-type">${{hop.transformation_type}}</div>` : ''}}
                            ${{hop.source_file ? `<div class="hop-file">${{hop.source_file}}</div>` : ''}}
                        </div>
                    </div>
                `;
            }});

            html += `</div>`;
            content.innerHTML = html;
        }}

        function showTableInfo(data) {{
            const panel = document.getElementById('sidePanel');
            const title = document.getElementById('panelTitle');
            const content = document.getElementById('panelContent');

            panel.classList.remove('hidden');
            title.textContent = data.label;

            const tableData = graphData.tables.find(t => t.id === data.id);
            const columns = tableData ? tableData.columns : [];

            let html = `
                <div class="info-section">
                    <h4>Table Information</h4>
                    <div class="info-row">
                        <span class="info-label">Name</span>
                        <span class="info-value">${{data.label}}</span>
                    </div>
                    <div class="info-row">
                        <span class="info-label">Type</span>
                        <span class="info-value">${{data.type.charAt(0).toUpperCase() + data.type.slice(1)}}</span>
                    </div>
                    <div class="info-row">
                        <span class="info-label">Columns</span>
                        <span class="info-value">${{columns.length}}</span>
                    </div>
                </div>
                <div class="info-section">
                    <h4>Columns (click to view lineage)</h4>
            `;

            columns.forEach(col => {{
                const colId = `${{data.id}}.${{col}}`;
                html += `<div class="column-item" onclick="selectColumnNode('${{colId}}')" style="padding: 8px 10px; margin: 3px 0; background: rgba(255,255,255,0.05); border-radius: 3px; cursor: pointer;">${{col}}</div>`;
            }});

            html += `</div>`;
            content.innerHTML = html;
        }}

        function selectColumnNode(colId) {{
            const node = cy.getElementById(colId);
            if (node.length) {{
                cy.elements().unselect();
                node.select();
                showColumnLineage(node.data());
                highlightColumnPath(node);
                cy.animate({{
                    center: {{ eles: node }},
                    zoom: 2
                }}, {{ duration: 300 }});
            }}
        }}

        function showEdgeDetails(data) {{
            const panel = document.getElementById('sidePanel');
            const title = document.getElementById('panelTitle');
            const content = document.getElementById('panelContent');

            panel.classList.remove('hidden');
            title.textContent = `${{data.source_column}} → ${{data.target_column}}`;

            let html = `
                <div class="info-section">
                    <h4>Flow Details</h4>
                    <div class="info-row">
                        <span class="info-label">Source</span>
                        <span class="info-value">${{data.source}}</span>
                    </div>
                    <div class="info-row">
                        <span class="info-label">Target</span>
                        <span class="info-value">${{data.target}}</span>
                    </div>
                    <div class="info-row">
                        <span class="info-label">Type</span>
                        <span class="info-value">${{data.transformation_type}}</span>
                    </div>
                </div>
            `;

            if (data.transformation && data.transformation.trim()) {{
                html += `
                    <div class="info-section">
                        <h4>Transformation Logic</h4>
                        <div class="hop-transform" style="margin: 0;">${{data.transformation}}</div>
                    </div>
                `;
            }}

            content.innerHTML = html;
        }}

        function setViewMode(mode) {{
            currentViewMode = mode;
            document.getElementById('viewExpanded').classList.toggle('active', mode === 'expanded');
            document.getElementById('viewCompact').classList.toggle('active', mode === 'compact');

            if (mode === 'compact') {{
                // Hide parent table boxes
                cy.nodes('.table').style('opacity', 0);
            }} else {{
                cy.nodes('.table').style('opacity', 1);
            }}

            cy.layout({{
                name: 'dagre',
                rankDir: 'LR',
                nodeSep: mode === 'compact' ? 10 : 15,
                rankSep: mode === 'compact' ? 80 : 100,
                padding: 30
            }}).run();
        }}

        // Control functions
        function fitGraph() {{
            cy.fit(50);
        }}

        function zoomIn() {{
            cy.zoom(cy.zoom() * 1.3);
            cy.center();
        }}

        function zoomOut() {{
            cy.zoom(cy.zoom() / 1.3);
            cy.center();
        }}

        function resetGraph() {{
            cy.elements().removeClass('highlighted dimmed');
            cy.reset();
            cy.fit(50);
        }}

        function togglePanel() {{
            document.getElementById('sidePanel').classList.toggle('hidden');
        }}

        function closePanel() {{
            document.getElementById('sidePanel').classList.add('hidden');
        }}

        // ===== NEW UI/UX FEATURES =====

        // State variables
        let collapsedTables = new Set();
        let currentTableIndex = 0;
        let sortedTables = [];
        let autocompleteSelectedIndex = -1;
        let edgePanningInterval = null;
        let minimapCollapsed = false;

        // ===== MINIMAP =====
        function initMinimap() {{
            const canvas = document.getElementById('minimap-canvas');
            const ctx = canvas.getContext('2d');
            const minimap = document.getElementById('minimap');
            const viewport = document.getElementById('minimap-viewport');

            // Set canvas size
            canvas.width = 196;
            canvas.height = 126;

            function renderMinimap() {{
                if (!cy || minimapCollapsed) return;

                ctx.clearRect(0, 0, canvas.width, canvas.height);

                const bb = cy.elements().boundingBox();
                if (bb.w === 0 || bb.h === 0) return;

                const scale = Math.min(canvas.width / bb.w, canvas.height / bb.h) * 0.9;
                const offsetX = (canvas.width - bb.w * scale) / 2 - bb.x1 * scale;
                const offsetY = (canvas.height - bb.h * scale) / 2 - bb.y1 * scale;

                // Draw nodes
                cy.nodes('.table').forEach(node => {{
                    const pos = node.position();
                    const bb = node.boundingBox();
                    const x = pos.x * scale + offsetX;
                    const y = pos.y * scale + offsetY;
                    const w = bb.w * scale;
                    const h = bb.h * scale;

                    ctx.fillStyle = node.hasClass('source') ? '#2e7d32' :
                                   node.hasClass('target') ? '#7b1fa2' :
                                   node.hasClass('lookup') ? '#ff9800' : '#546e7a';
                    ctx.fillRect(x - w/2, y - h/2, w, h);
                }});

                // Update viewport indicator
                const ext = cy.extent();
                const vx = ext.x1 * scale + offsetX;
                const vy = ext.y1 * scale + offsetY;
                const vw = ext.w * scale;
                const vh = ext.h * scale;

                viewport.style.left = Math.max(0, vx) + 'px';
                viewport.style.top = Math.max(24, vy + 24) + 'px';
                viewport.style.width = Math.min(canvas.width, vw) + 'px';
                viewport.style.height = Math.min(canvas.height, vh) + 'px';
            }}

            // Click/drag on minimap to navigate
            let isDragging = false;

            function navigateToMinimapPosition(e) {{
                const rect = canvas.getBoundingClientRect();
                const x = e.clientX - rect.left;
                const y = e.clientY - rect.top;

                const bb = cy.elements().boundingBox();
                const scale = Math.min(canvas.width / bb.w, canvas.height / bb.h) * 0.9;
                const offsetX = (canvas.width - bb.w * scale) / 2 - bb.x1 * scale;
                const offsetY = (canvas.height - bb.h * scale) / 2 - bb.y1 * scale;

                const targetX = (x - offsetX) / scale;
                const targetY = (y - offsetY) / scale;

                cy.animate({{
                    center: {{ eles: cy.nodes().filter(n => {{
                        const pos = n.position();
                        return Math.abs(pos.x - targetX) < 100 && Math.abs(pos.y - targetY) < 100;
                    }}) }},
                }}, {{ duration: 200 }});
            }}

            canvas.addEventListener('mousedown', (e) => {{
                isDragging = true;
                navigateToMinimapPosition(e);
            }});

            canvas.addEventListener('mousemove', (e) => {{
                if (isDragging) navigateToMinimapPosition(e);
            }});

            document.addEventListener('mouseup', () => {{ isDragging = false; }});

            // Update minimap on viewport changes
            cy.on('viewport', renderMinimap);
            cy.on('layoutstop', renderMinimap);
            renderMinimap();
        }}

        function toggleMinimap() {{
            const minimap = document.getElementById('minimap');
            minimapCollapsed = !minimapCollapsed;
            minimap.classList.toggle('collapsed', minimapCollapsed);
        }}

        // ===== NAVIGATION PANEL =====
        function initNavPanel() {{
            const content = document.getElementById('navPanelContent');

            // Group tables by type
            const groups = {{
                source: {{ label: 'Source Tables', items: [] }},
                intermediate: {{ label: 'Intermediate Tables', items: [] }},
                target: {{ label: 'Target Tables', items: [] }},
                lookup: {{ label: 'Lookup Tables', items: [] }}
            }};

            graphData.tables.forEach(table => {{
                const type = table.type || 'intermediate';
                if (groups[type]) {{
                    groups[type].items.push(table);
                }}
            }});

            // Build sorted tables list for navigation
            sortedTables = [
                ...groups.source.items,
                ...groups.intermediate.items,
                ...groups.target.items,
                ...groups.lookup.items
            ];

            let html = '';
            Object.entries(groups).forEach(([type, group]) => {{
                if (group.items.length === 0) return;

                html += `<div class="nav-group">
                    <div class="nav-group-header">
                        ${{group.label}}
                        <span class="nav-group-count">${{group.items.length}}</span>
                    </div>`;

                group.items.forEach(table => {{
                    const colCount = table.columns ? table.columns.length : 0;
                    html += `<div class="nav-item ${{type}}" data-table-id="${{table.id}}" onclick="navigateToTable('${{table.id}}')">
                        <span>${{table.name}}</span>
                        <span class="nav-item-badge">${{colCount}}</span>
                    </div>`;
                }});

                html += '</div>';
            }});

            content.innerHTML = html;
        }}

        function toggleNavPanel() {{
            const panel = document.getElementById('navPanel');
            const icon = document.getElementById('navToggleIcon');
            const mainContent = document.querySelector('.main-content');

            panel.classList.toggle('collapsed');
            icon.innerHTML = panel.classList.contains('collapsed') ? '&#9654;' : '&#9664;';
            mainContent.classList.toggle('nav-expanded', !panel.classList.contains('collapsed'));
        }}

        function navigateToTable(tableId) {{
            const tableNode = cy.getElementById(tableId);
            if (tableNode.length) {{
                cy.elements().removeClass('highlighted');
                tableNode.addClass('highlighted');
                tableNode.children().addClass('highlighted');

                cy.animate({{
                    center: {{ eles: tableNode }},
                    zoom: 1.5
                }}, {{ duration: 300 }});

                // Update active state in nav panel
                document.querySelectorAll('.nav-item').forEach(item => {{
                    item.classList.toggle('active', item.dataset.tableId === tableId);
                }});

                // Update current table index
                currentTableIndex = sortedTables.findIndex(t => t.id === tableId);

                updatePositionIndicator();
            }}
        }}

        function navigateToNextTable() {{
            if (sortedTables.length === 0) return;
            currentTableIndex = (currentTableIndex + 1) % sortedTables.length;
            navigateToTable(sortedTables[currentTableIndex].id);
        }}

        function navigateToPrevTable() {{
            if (sortedTables.length === 0) return;
            currentTableIndex = (currentTableIndex - 1 + sortedTables.length) % sortedTables.length;
            navigateToTable(sortedTables[currentTableIndex].id);
        }}

        function navigateToFirstTable() {{
            if (sortedTables.length === 0) return;
            currentTableIndex = 0;
            navigateToTable(sortedTables[0].id);
        }}

        function navigateToLastTable() {{
            if (sortedTables.length === 0) return;
            currentTableIndex = sortedTables.length - 1;
            navigateToTable(sortedTables[currentTableIndex].id);
        }}

        // ===== POSITION INDICATOR =====
        function updatePositionIndicator() {{
            const ext = cy.extent();
            const bb = cy.elements().boundingBox();

            if (bb.w === 0) return;

            // Calculate horizontal position as percentage
            const viewCenterX = ext.x1 + ext.w / 2;
            const progress = Math.max(0, Math.min(100, ((viewCenterX - bb.x1) / bb.w) * 100));

            // Count visible tables
            const visibleTables = cy.nodes('.table').filter(n => {{
                const pos = n.position();
                return pos.x >= ext.x1 && pos.x <= ext.x2 && pos.y >= ext.y1 && pos.y <= ext.y2;
            }});

            document.getElementById('positionText').textContent =
                `Viewing ${{visibleTables.length}} of ${{graphData.tables.length}} tables`;
            document.getElementById('progressBar').style.width = progress + '%';
        }}

        // ===== ENHANCED SEARCH WITH AUTOCOMPLETE =====
        function initAutocomplete() {{
            const searchInput = document.getElementById('searchInput');
            const dropdown = document.getElementById('autocompleteDropdown');
            const matchCount = document.getElementById('searchMatchCount');
            let currentResults = [];

            searchInput.addEventListener('input', function(e) {{
                const query = e.target.value.toLowerCase().trim();
                autocompleteSelectedIndex = -1;

                if (!query) {{
                    dropdown.classList.remove('visible');
                    matchCount.style.display = 'none';
                    cy.elements().removeClass('highlighted dimmed');
                    return;
                }}

                // Find matches
                const tableMatches = [];
                const columnMatches = [];

                graphData.tables.forEach(table => {{
                    if (table.name.toLowerCase().includes(query)) {{
                        tableMatches.push({{ type: 'table', id: table.id, name: table.name, tableType: table.type }});
                    }}
                }});

                graphData.columns.forEach(col => {{
                    if (col.column_name.toLowerCase().includes(query) ||
                        col.table_name.toLowerCase().includes(query) ||
                        col.id.toLowerCase().includes(query)) {{
                        columnMatches.push({{ type: 'column', id: col.id, name: col.column_name, table: col.table_name }});
                    }}
                }});

                currentResults = [...tableMatches, ...columnMatches];

                // Update match count
                const totalMatches = currentResults.length;
                matchCount.textContent = `${{totalMatches}} match${{totalMatches !== 1 ? 'es' : ''}}`;
                matchCount.style.display = 'inline';

                // Build dropdown
                let html = '';

                if (tableMatches.length > 0) {{
                    html += '<div class="autocomplete-group"><div class="autocomplete-group-header">Tables</div>';
                    tableMatches.slice(0, 5).forEach((item, idx) => {{
                        html += `<div class="autocomplete-item" data-index="${{idx}}" onclick="selectAutocompleteItem(${{idx}})">
                            <span class="autocomplete-item-name">${{item.name}}</span>
                            <span class="autocomplete-item-type">${{item.tableType}}</span>
                        </div>`;
                    }});
                    html += '</div>';
                }}

                if (columnMatches.length > 0) {{
                    html += '<div class="autocomplete-group"><div class="autocomplete-group-header">Columns</div>';
                    columnMatches.slice(0, 10).forEach((item, idx) => {{
                        const actualIdx = tableMatches.length + idx;
                        html += `<div class="autocomplete-item" data-index="${{actualIdx}}" onclick="selectAutocompleteItem(${{actualIdx}})">
                            <span class="autocomplete-item-name">${{item.name}}</span>
                            <span class="autocomplete-item-type">${{item.table}}</span>
                        </div>`;
                    }});
                    html += '</div>';
                }}

                dropdown.innerHTML = html;
                dropdown.classList.toggle('visible', currentResults.length > 0);

                // Highlight matching nodes in graph
                cy.elements().addClass('dimmed');
                currentResults.forEach(result => {{
                    const node = cy.getElementById(result.id);
                    if (node.length) {{
                        node.removeClass('dimmed').addClass('highlighted');
                        if (result.type === 'column') {{
                            cy.getElementById(result.table).removeClass('dimmed');
                        }}
                        node.connectedEdges().removeClass('dimmed');
                    }}
                }});
            }});

            // Keyboard navigation in autocomplete
            searchInput.addEventListener('keydown', function(e) {{
                const items = dropdown.querySelectorAll('.autocomplete-item');
                if (!dropdown.classList.contains('visible') || items.length === 0) return;

                if (e.key === 'ArrowDown') {{
                    e.preventDefault();
                    autocompleteSelectedIndex = Math.min(autocompleteSelectedIndex + 1, items.length - 1);
                    updateAutocompleteSelection(items);
                }} else if (e.key === 'ArrowUp') {{
                    e.preventDefault();
                    autocompleteSelectedIndex = Math.max(autocompleteSelectedIndex - 1, 0);
                    updateAutocompleteSelection(items);
                }} else if (e.key === 'Enter' && autocompleteSelectedIndex >= 0) {{
                    e.preventDefault();
                    selectAutocompleteItem(autocompleteSelectedIndex);
                }}
            }});

            // Close dropdown when clicking outside
            document.addEventListener('click', function(e) {{
                if (!e.target.closest('.search-container')) {{
                    dropdown.classList.remove('visible');
                }}
            }});

            window.selectAutocompleteItem = function(index) {{
                const item = currentResults[index];
                if (!item) return;

                dropdown.classList.remove('visible');

                if (item.type === 'table') {{
                    navigateToTable(item.id);
                }} else {{
                    selectColumnNode(item.id);
                }}
            }};
        }}

        function updateAutocompleteSelection(items) {{
            items.forEach((item, idx) => {{
                item.classList.toggle('selected', idx === autocompleteSelectedIndex);
            }});
        }}

        // ===== EDGE PANNING =====
        function initEdgePanning() {{
            const cyContainer = document.getElementById('cy');
            const edgeThreshold = 50;
            const panSpeed = 5;

            cyContainer.addEventListener('mousemove', function(e) {{
                const rect = cyContainer.getBoundingClientRect();
                const x = e.clientX - rect.left;
                const y = e.clientY - rect.top;

                let panX = 0, panY = 0;

                if (x < edgeThreshold) panX = -panSpeed;
                else if (x > rect.width - edgeThreshold) panX = panSpeed;

                if (y < edgeThreshold) panY = -panSpeed;
                else if (y > rect.height - edgeThreshold) panY = panSpeed;

                if (panX !== 0 || panY !== 0) {{
                    if (!edgePanningInterval) {{
                        edgePanningInterval = setInterval(() => {{
                            cy.panBy({{ x: -panX * 10, y: -panY * 10 }});
                        }}, 50);
                    }}
                }} else {{
                    if (edgePanningInterval) {{
                        clearInterval(edgePanningInterval);
                        edgePanningInterval = null;
                    }}
                }}
            }});

            cyContainer.addEventListener('mouseleave', function() {{
                if (edgePanningInterval) {{
                    clearInterval(edgePanningInterval);
                    edgePanningInterval = null;
                }}
            }});
        }}

        // ===== TABLE COLLAPSE/EXPAND =====
        function collapseTable(tableId) {{
            const tableNode = cy.getElementById(tableId);
            if (!tableNode.length) return;

            collapsedTables.add(tableId);

            // Hide child column nodes
            tableNode.children().style('display', 'none');

            // Adjust table node appearance
            tableNode.style({{
                'padding': '10px',
                'border-style': 'solid'
            }});
        }}

        function expandTable(tableId) {{
            const tableNode = cy.getElementById(tableId);
            if (!tableNode.length) return;

            collapsedTables.delete(tableId);

            // Show child column nodes
            tableNode.children().style('display', 'element');

            // Reset table node appearance
            tableNode.style({{
                'padding': '20px'
            }});
        }}

        function toggleTableCollapse(tableId) {{
            if (collapsedTables.has(tableId)) {{
                expandTable(tableId);
            }} else {{
                collapseTable(tableId);
            }}
        }}

        function collapseAllTables() {{
            graphData.tables.forEach(table => collapseTable(table.id));
        }}

        function expandAllTables() {{
            graphData.tables.forEach(table => expandTable(table.id));
        }}

        // ===== KEYBOARD NAVIGATION =====
        function initKeyboardShortcuts() {{
            const panAmount = 100;

            document.addEventListener('keydown', function(e) {{
                // Ignore if typing in input
                if (e.target.tagName === 'INPUT' || e.target.tagName === 'SELECT' || e.target.tagName === 'TEXTAREA') {{
                    if (e.key === 'Escape') {{
                        e.target.blur();
                        cy.elements().removeClass('highlighted dimmed');
                        document.getElementById('searchInput').value = '';
                        document.getElementById('autocompleteDropdown').classList.remove('visible');
                        document.getElementById('searchMatchCount').style.display = 'none';
                    }}
                    return;
                }}

                switch(e.key) {{
                    // Panning
                    case 'ArrowLeft':
                    case 'a':
                    case 'A':
                        e.preventDefault();
                        cy.panBy({{ x: panAmount, y: 0 }});
                        break;
                    case 'ArrowRight':
                    case 'd':
                    case 'D':
                        e.preventDefault();
                        cy.panBy({{ x: -panAmount, y: 0 }});
                        break;
                    case 'ArrowUp':
                    case 'w':
                    case 'W':
                        e.preventDefault();
                        cy.panBy({{ x: 0, y: panAmount }});
                        break;
                    case 'ArrowDown':
                    case 's':
                    case 'S':
                        e.preventDefault();
                        cy.panBy({{ x: 0, y: -panAmount }});
                        break;

                    // Zoom
                    case '+':
                    case '=':
                        e.preventDefault();
                        zoomIn();
                        break;
                    case '-':
                    case '_':
                        e.preventDefault();
                        zoomOut();
                        break;

                    // View controls
                    case 'f':
                    case 'F':
                        e.preventDefault();
                        fitGraph();
                        break;
                    case 'r':
                    case 'R':
                        e.preventDefault();
                        resetGraph();
                        break;

                    // Search
                    case '/':
                        e.preventDefault();
                        document.getElementById('searchInput').focus();
                        break;

                    // Help
                    case 'h':
                    case 'H':
                    case '?':
                        e.preventDefault();
                        toggleHelp();
                        break;

                    // Minimap
                    case 'm':
                    case 'M':
                        e.preventDefault();
                        toggleMinimap();
                        break;

                    // Details panel
                    // 'd' is used for panning, use 'D' for details toggle
                    // Actually let's keep 'd' for details since lowercase d for pan is unusual
                    // We'll use Shift+D for details

                    // Navigation
                    case 'n':
                    case 'N':
                        e.preventDefault();
                        if (e.shiftKey) {{
                            toggleNavPanel();
                        }} else {{
                            navigateToNextTable();
                        }}
                        break;
                    case 'p':
                    case 'P':
                        e.preventDefault();
                        navigateToPrevTable();
                        break;
                    case 'Home':
                        e.preventDefault();
                        navigateToFirstTable();
                        break;
                    case 'End':
                        e.preventDefault();
                        navigateToLastTable();
                        break;

                    // Collapse/Expand
                    case 'c':
                    case 'C':
                        e.preventDefault();
                        collapseAllTables();
                        break;
                    case 'e':
                    case 'E':
                        e.preventDefault();
                        expandAllTables();
                        break;

                    // Escape
                    case 'Escape':
                        e.preventDefault();
                        cy.elements().removeClass('highlighted dimmed');
                        document.getElementById('helpModal').classList.remove('visible');
                        document.getElementById('breadcrumbContainer').classList.remove('visible');
                        break;
                }}

                updatePositionIndicator();
            }});

            // Ctrl+F for search
            document.addEventListener('keydown', function(e) {{
                if ((e.ctrlKey || e.metaKey) && e.key === 'f') {{
                    e.preventDefault();
                    document.getElementById('searchInput').focus();
                }}
            }});
        }}

        // ===== HELP MODAL =====
        function toggleHelp() {{
            document.getElementById('helpModal').classList.toggle('visible');
        }}

        // ===== BREADCRUMB TRAIL =====
        function updateBreadcrumb(lineage) {{
            if (!lineage || !lineage.hops || lineage.hops.length === 0) {{
                document.getElementById('breadcrumbContainer').classList.remove('visible');
                return;
            }}

            const container = document.getElementById('breadcrumbTrail');
            const breadcrumbContainer = document.getElementById('breadcrumbContainer');

            const hops = lineage.hops;
            let html = '';

            // For long lineages, show: first > ... > current > ... > last
            if (hops.length <= 5) {{
                hops.forEach((hop, idx) => {{
                    const hopTable = hop.table || hop.table_name || '';
                    const hopColumn = hop.column || hop.column_name || '';
                    const hopId = `${{hopTable}}.${{hopColumn}}`;
                    const isFirst = idx === 0;
                    const isLast = idx === hops.length - 1;

                    html += `<span class="breadcrumb-item ${{isFirst ? 'source' : (isLast ? 'target' : '')}}"
                                  onclick="selectColumnNode('${{hopId}}')">
                        ${{hopTable}}.${{hopColumn}}
                    </span>`;

                    if (idx < hops.length - 1) {{
                        html += '<span class="breadcrumb-arrow">→</span>';
                    }}
                }});
            }} else {{
                // Abbreviated view
                const first = hops[0];
                const last = hops[hops.length - 1];
                const firstId = `${{first.table || first.table_name}}.${{first.column || first.column_name}}`;
                const lastId = `${{last.table || last.table_name}}.${{last.column || last.column_name}}`;

                html = `
                    <span class="breadcrumb-item source" onclick="selectColumnNode('${{firstId}}')">
                        ${{first.table || first.table_name}}.${{first.column || first.column_name}}
                    </span>
                    <span class="breadcrumb-arrow">→</span>
                    <span class="breadcrumb-ellipsis">... (${{hops.length - 2}} steps) ...</span>
                    <span class="breadcrumb-arrow">→</span>
                    <span class="breadcrumb-item target" onclick="selectColumnNode('${{lastId}}')">
                        ${{last.table || last.table_name}}.${{last.column || last.column_name}}
                    </span>
                `;
            }}

            container.innerHTML = html;
            breadcrumbContainer.classList.add('visible');
        }}

        // ===== MODIFIED EXISTING FUNCTIONS =====

        // Override showColumnLineage to also update breadcrumb
        const originalShowColumnLineage = showColumnLineage;
        showColumnLineage = function(data) {{
            originalShowColumnLineage(data);

            // Find lineage and update breadcrumb
            const lineage = graphData.column_lineages.find(lin =>
                `${{lin.target_table}}.${{lin.target_column}}` === data.id
            ) || graphData.column_lineages.find(lin =>
                lin.hops.some(h => `${{h.table_name || h.table}}.${{h.column_name || h.column}}` === data.id)
            );

            updateBreadcrumb(lineage);
        }};

        // ===== INITIALIZE ALL NEW FEATURES =====
        function initNewFeatures() {{
            initMinimap();
            initNavPanel();
            initAutocomplete();
            initEdgePanning();
            initKeyboardShortcuts();

            // Add double-click handler for table collapse/expand
            cy.on('dblclick', 'node.table', function(evt) {{
                toggleTableCollapse(evt.target.id());
            }});

            // Update position indicator on viewport change
            cy.on('viewport', updatePositionIndicator);
            cy.on('layoutstop', updatePositionIndicator);

            // Initial position update
            setTimeout(updatePositionIndicator, 500);
        }}

        // Modify the original initGraph to call our new features
        const originalInitGraph = initGraph;
        initGraph = function() {{
            originalInitGraph();
            initNewFeatures();
        }};

        // Initialize on load
        document.addEventListener('DOMContentLoaded', initGraph);
    </script>
</body>
</html>'''

        return html


def process_multi_file_lineage(input_dir: str, output_dir: str,
                                dialect: str = "teradata") -> Dict[str, Any]:
    """
    Process multiple SQL files and generate end-to-end lineage.

    Args:
        input_dir: Directory with SQL files
        output_dir: Directory for output files
        dialect: SQL dialect

    Returns:
        Processing results
    """
    os.makedirs(output_dir, exist_ok=True)

    extractor = EndToEndLineageExtractor(dialect=dialect)

    # Process all files
    result = extractor.process_directory(input_dir)

    # Print summary
    print(extractor.get_data_flow_summary())

    # Export outputs
    extractor.export_end_to_end_csv(
        os.path.join(output_dir, "end_to_end_lineage.csv")
    )
    extractor.export_comprehensive_csv(
        os.path.join(output_dir, "comprehensive_lineage_all_hops.csv")
    )
    extractor.export_json(
        os.path.join(output_dir, "lineage_analysis.json")
    )

    return result


if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(description="Extract end-to-end lineage across SQL files")
    parser.add_argument("--input", "-i", required=True, help="Input directory with SQL files")
    parser.add_argument("--output", "-o", required=True, help="Output directory")
    parser.add_argument("--dialect", "-d", default="teradata", help="SQL dialect")

    args = parser.parse_args()

    process_multi_file_lineage(args.input, args.output, args.dialect)
