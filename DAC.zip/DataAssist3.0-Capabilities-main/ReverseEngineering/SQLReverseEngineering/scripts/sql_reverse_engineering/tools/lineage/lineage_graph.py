"""
Lineage Graph module.

Graph representation of data lineage using NetworkX.
Provides methods for traversal, export, and analysis.
"""

import networkx as nx
from typing import List, Dict, Any, Optional, Set, Tuple
import json
import sys
import os

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from models.data_models import ColumnRef, LineageEdge, TransformationInfo


class LineageGraph:
    """
    Graph representation of data lineage.
    Uses NetworkX for efficient graph operations.
    """

    def __init__(self):
        """Initialize empty lineage graph."""
        self.graph = nx.DiGraph()
        self._edges: List[LineageEdge] = []

    def add_lineage(self, source: ColumnRef, target: ColumnRef,
                    transformation: TransformationInfo,
                    dml_operation: str = "",
                    join_conditions: str = "",
                    where_conditions: str = "",
                    **kwargs) -> None:
        """
        Add a lineage edge with transformation metadata.

        Args:
            source: Source column reference
            target: Target column reference
            transformation: Transformation information
            dml_operation: DML operation type (INSERT, CREATE, etc.)
            join_conditions: JOIN conditions for this edge
            where_conditions: WHERE/filter conditions for this edge
        """
        # Create node IDs
        source_id = self._node_id(source)
        target_id = self._node_id(target)

        # Add nodes if not exist
        if not self.graph.has_node(source_id):
            self.graph.add_node(source_id, **source.to_dict())

        if not self.graph.has_node(target_id):
            self.graph.add_node(target_id, **target.to_dict())

        # Add edge with full metadata
        self.graph.add_edge(
            source_id,
            target_id,
            transformation=transformation.to_dict(),
            dml_operation=dml_operation,
            join_conditions=join_conditions,
            where_conditions=where_conditions,
            subquery_alias=kwargs.get('subquery_alias', ''),
            union_type=kwargs.get('union_type', '')
        )

        # Store edge object
        self._edges.append(LineageEdge(
            source=source,
            target=target,
            transformation=transformation,
            dml_operation=dml_operation,
            join_conditions=join_conditions,
            where_conditions=where_conditions,
            subquery_alias=kwargs.get('subquery_alias', ''),
            union_type=kwargs.get('union_type', '')
        ))

    def add_edge(self, edge: LineageEdge) -> None:
        """
        Add a LineageEdge to the graph, preserving all fields (including statement_id).

        Args:
            edge: LineageEdge object
        """
        source_id = self._node_id(edge.source)
        target_id = self._node_id(edge.target)

        if not self.graph.has_node(source_id):
            self.graph.add_node(source_id, **edge.source.to_dict())
        if not self.graph.has_node(target_id):
            self.graph.add_node(target_id, **edge.target.to_dict())

        self.graph.add_edge(
            source_id, target_id,
            transformation=edge.transformation.to_dict(),
            dml_operation=edge.dml_operation,
            join_conditions=edge.join_conditions,
            where_conditions=edge.where_conditions,
            subquery_alias=getattr(edge, 'subquery_alias', ''),
            union_type=getattr(edge, 'union_type', '')
        )

        self._edges.append(edge)

    def _node_id(self, col_ref: ColumnRef) -> str:
        """
        Generate a unique node ID for a column reference.

        Args:
            col_ref: Column reference

        Returns:
            Node ID string
        """
        return col_ref.qualified_name()

    def get_sources(self, target: ColumnRef) -> List[ColumnRef]:
        """
        Get all source columns for a target column.

        Args:
            target: Target column reference

        Returns:
            List of source ColumnRef objects
        """
        target_id = self._node_id(target)
        sources = []

        if target_id in self.graph:
            for source_id in self.graph.predecessors(target_id):
                node_data = self.graph.nodes[source_id]
                sources.append(ColumnRef(
                    table_name=node_data.get('table_name', ''),
                    column_name=node_data.get('column_name', ''),
                    schema_name=node_data.get('schema_name')
                ))

        return sources

    def get_targets(self, source: ColumnRef) -> List[ColumnRef]:
        """
        Get all target columns for a source column.

        Args:
            source: Source column reference

        Returns:
            List of target ColumnRef objects
        """
        source_id = self._node_id(source)
        targets = []

        if source_id in self.graph:
            for target_id in self.graph.successors(source_id):
                node_data = self.graph.nodes[target_id]
                targets.append(ColumnRef(
                    table_name=node_data.get('table_name', ''),
                    column_name=node_data.get('column_name', ''),
                    schema_name=node_data.get('schema_name')
                ))

        return targets

    def get_lineage_path(self, source: ColumnRef, target: ColumnRef) -> List[ColumnRef]:
        """
        Get the lineage path between source and target.

        Args:
            source: Source column reference
            target: Target column reference

        Returns:
            List of ColumnRef objects in the path
        """
        source_id = self._node_id(source)
        target_id = self._node_id(target)

        try:
            path_ids = nx.shortest_path(self.graph, source_id, target_id)
            path = []
            for node_id in path_ids:
                node_data = self.graph.nodes[node_id]
                path.append(ColumnRef(
                    table_name=node_data.get('table_name', ''),
                    column_name=node_data.get('column_name', ''),
                    schema_name=node_data.get('schema_name')
                ))
            return path
        except nx.NetworkXNoPath:
            return []

    def get_all_sources_recursive(self, target: ColumnRef) -> List[ColumnRef]:
        """
        Get all upstream sources recursively.

        Args:
            target: Target column reference

        Returns:
            List of all upstream ColumnRef objects
        """
        target_id = self._node_id(target)
        sources = []

        if target_id in self.graph:
            for ancestor_id in nx.ancestors(self.graph, target_id):
                node_data = self.graph.nodes[ancestor_id]
                sources.append(ColumnRef(
                    table_name=node_data.get('table_name', ''),
                    column_name=node_data.get('column_name', ''),
                    schema_name=node_data.get('schema_name')
                ))

        return sources

    def get_all_targets_recursive(self, source: ColumnRef) -> List[ColumnRef]:
        """
        Get all downstream targets recursively.

        Args:
            source: Source column reference

        Returns:
            List of all downstream ColumnRef objects
        """
        source_id = self._node_id(source)
        targets = []

        if source_id in self.graph:
            for descendant_id in nx.descendants(self.graph, source_id):
                node_data = self.graph.nodes[descendant_id]
                targets.append(ColumnRef(
                    table_name=node_data.get('table_name', ''),
                    column_name=node_data.get('column_name', ''),
                    schema_name=node_data.get('schema_name')
                ))

        return targets

    def get_transformation(self, source: ColumnRef, target: ColumnRef) -> Optional[Dict]:
        """
        Get transformation metadata for an edge.

        Args:
            source: Source column reference
            target: Target column reference

        Returns:
            Transformation dict or None
        """
        source_id = self._node_id(source)
        target_id = self._node_id(target)

        if self.graph.has_edge(source_id, target_id):
            return self.graph.edges[source_id, target_id].get('transformation')

        return None

    def get_edge_data(self, source_id: str, target_id: str) -> Optional[Dict]:
        """
        Get full edge metadata from the NetworkX graph for a given edge.

        Args:
            source_id: Source node ID
            target_id: Target node ID

        Returns:
            Dict with edge metadata or None
        """
        if self.graph.has_edge(source_id, target_id):
            return dict(self.graph.edges[source_id, target_id])
        return None

    @property
    def edges(self) -> List[LineageEdge]:
        """Get all edges as LineageEdge objects."""
        return self._edges

    def get_source_tables(self) -> Set[str]:
        """
        Get all unique source tables (nodes with no predecessors).

        Returns:
            Set of source table names
        """
        tables = set()
        for node_id in self.graph.nodes():
            if self.graph.in_degree(node_id) == 0:
                node_data = self.graph.nodes[node_id]
                table_name = node_data.get('table_name', '')
                if table_name:
                    tables.add(table_name)
        return tables

    def get_target_tables(self) -> Set[str]:
        """
        Get all unique target tables (nodes with no successors).

        Returns:
            Set of target table names
        """
        tables = set()
        for node_id in self.graph.nodes():
            if self.graph.out_degree(node_id) == 0:
                node_data = self.graph.nodes[node_id]
                table_name = node_data.get('table_name', '')
                if table_name:
                    tables.add(table_name)
        return tables

    def to_json(self) -> str:
        """
        Export graph as JSON string.

        Returns:
            JSON string representation
        """
        data = {
            'nodes': [],
            'edges': []
        }

        for node_id in self.graph.nodes():
            node_data = self.graph.nodes[node_id]
            data['nodes'].append({
                'id': node_id,
                **node_data
            })

        for source_id, target_id in self.graph.edges():
            edge_data = self.graph.edges[source_id, target_id]
            data['edges'].append({
                'source': source_id,
                'target': target_id,
                **edge_data
            })

        return json.dumps(data, indent=2)

    def to_dict(self) -> Dict:
        """
        Export graph as dictionary.

        Returns:
            Dictionary representation
        """
        return json.loads(self.to_json())

    def to_lineage_output_dict(self, source_file: str = "",
                                dialect: str = "teradata") -> Dict:
        """
        Export as rich lineage_output format with metadata and structured edges.

        This is the intermediate JSON before STTM CSV generation. Each edge
        includes source/target as {table, column}, full transformation details,
        DML operation, and conditions.

        Args:
            source_file: Path to the source SQL file
            dialect: SQL dialect used

        Returns:
            Dictionary with metadata and edges list
        """
        from datetime import datetime

        tables = set()
        columns = set()
        for edge in self._edges:
            if edge.source.table_name:
                tables.add(edge.source.table_name)
            if edge.target.table_name:
                tables.add(edge.target.table_name)
            columns.add(edge.source.qualified_name())
            columns.add(edge.target.qualified_name())

        edges_list = []
        for edge in self._edges:
            edges_list.append({
                "source": {
                    "table": edge.source.table_name,
                    "column": edge.source.column_name
                },
                "target": {
                    "table": edge.target.table_name,
                    "column": edge.target.column_name
                },
                "transformation": edge.transformation.to_dict(),
                "dml_operation": edge.dml_operation,
                "join_conditions": edge.join_conditions,
                "where_conditions": edge.where_conditions
            })

        return {
            "metadata": {
                "source_file": source_file,
                "dialect": dialect,
                "timestamp": datetime.now().isoformat(),
                "edge_count": len(self._edges),
                "table_count": len(tables),
                "column_count": len(columns)
            },
            "edges": edges_list
        }

    def to_csv_rows(self) -> List[Dict[str, str]]:
        """
        Export as CSV rows in BDaaS format.

        Returns:
            List of row dictionaries
        """
        return [edge.to_csv_row() for edge in self._edges]

    def merge(self, other: 'LineageGraph') -> None:
        """
        Merge another LineageGraph into this one.

        Args:
            other: Another LineageGraph
        """
        for edge in other.edges:
            self.add_edge(edge)

    def get_statistics(self) -> Dict[str, Any]:
        """
        Get graph statistics.

        Returns:
            Dict with graph statistics
        """
        return {
            'node_count': self.graph.number_of_nodes(),
            'edge_count': self.graph.number_of_edges(),
            'source_tables': list(self.get_source_tables()),
            'target_tables': list(self.get_target_tables()),
            'is_dag': nx.is_directed_acyclic_graph(self.graph)
        }

    def to_mermaid(self) -> str:
        """
        Export graph as Mermaid diagram.

        Returns:
            Mermaid diagram string
        """
        import re

        def sanitize_id(node_id: str) -> str:
            """Sanitize node ID for Mermaid (alphanumeric and underscores only)."""
            # Ensure ID starts with a letter
            sanitized = re.sub(r'[^a-zA-Z0-9_]', '_', node_id)
            if sanitized and not sanitized[0].isalpha():
                sanitized = 'n_' + sanitized
            return sanitized

        def sanitize_label(label: str) -> str:
            """Sanitize label text for Mermaid (escape special chars)."""
            # Replace characters that break Mermaid syntax
            label = label.replace('[', '').replace(']', '')
            label = label.replace('{', '').replace('}', '')
            label = label.replace('(', '').replace(')', '')
            label = label.replace('"', '')
            label = label.replace("'", '')
            label = label.replace('<', 'LT').replace('>', 'GT')
            label = label.replace(':', '-')  # Colons break Mermaid
            label = label.replace('#', '')
            label = label.replace('&', 'and')
            label = label.replace('|', 'or')
            # Truncate very long labels
            if len(label) > 50:
                label = label[:47] + '...'
            return label

        lines = ["graph TD"]  # Use top-down for better readability

        for source_id, target_id in self.graph.edges():
            # Sanitize node IDs and labels for Mermaid
            s_id = sanitize_id(source_id)
            t_id = sanitize_id(target_id)
            s_label = sanitize_label(source_id)
            t_label = sanitize_label(target_id)
            # Use quoted labels to handle any remaining special chars
            lines.append(f'    {s_id}["{s_label}"] --> {t_id}["{t_label}"]')

        return '\n'.join(lines)
