"""
EnhancedCodeReviewer - Comprehensive verification with convergence detection.

Features:
- Column completeness verification across all subscripts
- Transformation logic verification against original SQL
- End-to-end lineage validation
- Cross-file verification
- Convergence detection for recursive correction
"""

import sqlglot
from sqlglot import exp
from typing import Dict, List, Optional, Any, Tuple, Set
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
import uuid
import sys
import os

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from .base_expert import BaseExpert, ExpertOutput


class VerificationSeverity(Enum):
    """Severity levels for verification issues."""
    CRITICAL = "CRITICAL"
    WARNING = "WARNING"
    INFO = "INFO"


class VerificationCategory(Enum):
    """Categories of verification checks."""
    COLUMN_COMPLETENESS = "COLUMN_COMPLETENESS"
    TRANSFORMATION_LOGIC = "TRANSFORMATION_LOGIC"
    END_TO_END_LINEAGE = "END_TO_END_LINEAGE"
    CROSS_FILE = "CROSS_FILE"
    CONVERGENCE = "CONVERGENCE"


@dataclass
class ColumnCompletenessIssue:
    """Issue related to column completeness."""
    issue_id: str
    category: VerificationCategory
    severity: VerificationSeverity
    target_column: str
    target_table: str
    context: str
    expected_sources: List[str]
    actual_sources: List[str]
    missing_sources: List[str]
    description: str
    suggested_fix: str = ""

    def to_dict(self) -> Dict[str, Any]:
        return {
            "issue_id": self.issue_id,
            "category": self.category.value,
            "severity": self.severity.value,
            "target_column": self.target_column,
            "target_table": self.target_table,
            "context": self.context,
            "expected_sources": self.expected_sources,
            "actual_sources": self.actual_sources,
            "missing_sources": self.missing_sources,
            "description": self.description,
            "suggested_fix": self.suggested_fix
        }


@dataclass
class TransformationMismatch:
    """Mismatch between documented and actual transformation."""
    issue_id: str
    target_column: str
    documented_expression: str
    actual_expression: str
    similarity_score: float
    mismatch_type: str
    description: str

    def to_dict(self) -> Dict[str, Any]:
        return {
            "issue_id": self.issue_id,
            "target_column": self.target_column,
            "documented_expression": self.documented_expression,
            "actual_expression": self.actual_expression,
            "similarity_score": self.similarity_score,
            "mismatch_type": self.mismatch_type,
            "description": self.description
        }


@dataclass
class LineagePathIssue:
    """Issue with end-to-end lineage path."""
    issue_id: str
    target_table: str
    target_column: str
    expected_path: List[str]
    actual_path: List[str]
    gap_location: str
    is_broken: bool
    description: str

    def to_dict(self) -> Dict[str, Any]:
        return {
            "issue_id": self.issue_id,
            "target_table": self.target_table,
            "target_column": self.target_column,
            "expected_path": self.expected_path,
            "actual_path": self.actual_path,
            "gap_location": self.gap_location,
            "is_broken": self.is_broken,
            "description": self.description
        }


@dataclass
class IterationSnapshot:
    """Snapshot of verification state at a specific iteration."""
    iteration_number: int
    timestamp: str
    total_issues: int
    critical_issues: int
    warning_issues: int
    info_issues: int
    corrections_attempted: int
    corrections_successful: int
    issue_delta: int
    issues_by_category: Dict[str, int]

    def to_dict(self) -> Dict[str, Any]:
        return {
            "iteration_number": self.iteration_number,
            "timestamp": self.timestamp,
            "total_issues": self.total_issues,
            "critical_issues": self.critical_issues,
            "warning_issues": self.warning_issues,
            "info_issues": self.info_issues,
            "corrections_attempted": self.corrections_attempted,
            "corrections_successful": self.corrections_successful,
            "issue_delta": self.issue_delta,
            "issues_by_category": self.issues_by_category
        }


@dataclass
class ConvergenceMetrics:
    """Metrics for tracking convergence."""
    is_converged: bool
    convergence_reason: str
    iterations_to_converge: int
    final_issue_count: int
    improvement_rate: float
    stagnation_count: int
    oscillation_detected: bool
    iteration_history: List[IterationSnapshot] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "is_converged": self.is_converged,
            "convergence_reason": self.convergence_reason,
            "iterations_to_converge": self.iterations_to_converge,
            "final_issue_count": self.final_issue_count,
            "improvement_rate": self.improvement_rate,
            "stagnation_count": self.stagnation_count,
            "oscillation_detected": self.oscillation_detected,
            "iteration_history": [i.to_dict() for i in self.iteration_history]
        }


@dataclass
class EnhancedVerificationResult:
    """Complete result of enhanced verification."""
    original_sql: str
    source_files: List[str]
    target_table: Optional[str]
    column_completeness_issues: List[ColumnCompletenessIssue] = field(default_factory=list)
    transformation_mismatches: List[TransformationMismatch] = field(default_factory=list)
    lineage_path_issues: List[LineagePathIssue] = field(default_factory=list)
    convergence_metrics: Optional[ConvergenceMetrics] = None
    is_valid: bool = False
    summary: str = ""

    def get_all_issues(self) -> List[Any]:
        return (self.column_completeness_issues +
                self.transformation_mismatches +
                self.lineage_path_issues)

    def get_issue_count_by_severity(self) -> Dict[str, int]:
        counts = {"CRITICAL": 0, "WARNING": 0, "INFO": 0}
        for issue in self.column_completeness_issues:
            counts[issue.severity.value] += 1
        return counts

    def to_dict(self) -> Dict[str, Any]:
        return {
            "source_files": self.source_files,
            "target_table": self.target_table,
            "column_completeness_issues": [i.to_dict() for i in self.column_completeness_issues],
            "transformation_mismatches": [i.to_dict() for i in self.transformation_mismatches],
            "lineage_path_issues": [i.to_dict() for i in self.lineage_path_issues],
            "convergence_metrics": self.convergence_metrics.to_dict() if self.convergence_metrics else None,
            "is_valid": self.is_valid,
            "summary": self.summary
        }


class ConvergenceDetector:
    """Detects convergence in iterative correction."""

    MAX_ITERATIONS = 10
    STAGNATION_THRESHOLD = 3
    OSCILLATION_WINDOW = 4

    def __init__(self):
        self.iteration_history: List[IterationSnapshot] = []
        self.issue_count_history: List[int] = []
        self.stagnation_count = 0

    def record_iteration(self, iteration_num: int, issues: List[Any],
                        corrections_attempted: int, corrections_successful: int) -> IterationSnapshot:
        """Record iteration results."""
        critical = sum(1 for i in issues
                      if hasattr(i, 'severity') and i.severity == VerificationSeverity.CRITICAL)
        warning = sum(1 for i in issues
                     if hasattr(i, 'severity') and i.severity == VerificationSeverity.WARNING)
        info = len(issues) - critical - warning

        prev_total = self.issue_count_history[-1] if self.issue_count_history else len(issues)
        delta = len(issues) - prev_total

        issues_by_category = {}
        for issue in issues:
            cat = getattr(issue, 'category', 'UNKNOWN')
            cat_name = cat.value if hasattr(cat, 'value') else str(cat)
            issues_by_category[cat_name] = issues_by_category.get(cat_name, 0) + 1

        snapshot = IterationSnapshot(
            iteration_number=iteration_num,
            timestamp=datetime.now().isoformat(),
            total_issues=len(issues),
            critical_issues=critical,
            warning_issues=warning,
            info_issues=info,
            corrections_attempted=corrections_attempted,
            corrections_successful=corrections_successful,
            issue_delta=delta,
            issues_by_category=issues_by_category
        )

        self.iteration_history.append(snapshot)
        self.issue_count_history.append(len(issues))

        if delta >= 0:
            self.stagnation_count += 1
        else:
            self.stagnation_count = 0

        return snapshot

    def check_convergence(self) -> Tuple[bool, str]:
        """Check if convergence has been reached."""
        if not self.iteration_history:
            return False, "no_iterations"

        latest = self.iteration_history[-1]

        if latest.critical_issues == 0:
            return True, "all_resolved"

        if len(self.iteration_history) >= self.MAX_ITERATIONS:
            return True, "max_iterations"

        if self.stagnation_count >= self.STAGNATION_THRESHOLD:
            return True, "no_improvement"

        if self._detect_oscillation():
            return True, "oscillation_detected"

        return False, "in_progress"

    def _detect_oscillation(self) -> bool:
        """Detect if issue counts are oscillating."""
        if len(self.issue_count_history) < self.OSCILLATION_WINDOW:
            return False

        recent = self.issue_count_history[-self.OSCILLATION_WINDOW:]

        if len(set(recent)) <= 2:
            odds = recent[1::2]
            evens = recent[::2]
            if len(set(odds)) == 1 and len(set(evens)) == 1:
                return True

        return False

    def get_metrics(self) -> ConvergenceMetrics:
        """Get convergence metrics."""
        is_converged, reason = self.check_convergence()

        if len(self.issue_count_history) >= 2:
            total_improvement = self.issue_count_history[0] - self.issue_count_history[-1]
            improvement_rate = total_improvement / len(self.iteration_history)
        else:
            improvement_rate = 0.0

        return ConvergenceMetrics(
            is_converged=is_converged,
            convergence_reason=reason,
            iterations_to_converge=len(self.iteration_history),
            final_issue_count=self.issue_count_history[-1] if self.issue_count_history else 0,
            improvement_rate=improvement_rate,
            stagnation_count=self.stagnation_count,
            oscillation_detected=self._detect_oscillation(),
            iteration_history=self.iteration_history
        )


class EnhancedCodeReviewer(BaseExpert):
    """
    Enhanced code reviewer with comprehensive verification.

    Features:
    - Column completeness verification
    - Transformation logic verification
    - End-to-end lineage validation
    - Convergence detection for iterative correction
    """

    MAX_ITERATIONS = 10

    def __init__(self, dialect: str = "teradata"):
        super().__init__(dialect)
        self._result: Optional[EnhancedVerificationResult] = None
        self._issue_counter = 0

    def analyze(self, sql: str, **kwargs) -> ExpertOutput:
        """Verify lineage with optional iterative correction."""
        if not self.validate_input(sql):
            return self._create_error_output("Invalid or empty SQL input")

        # Get lineage data if provided
        lineage_data = kwargs.get('lineage_data', {})
        iterations_enabled = kwargs.get('iterations_enabled', True)

        result = self._verify(sql, lineage_data, iterations_enabled)
        self._result = result

        self._last_output = ExpertOutput(
            expert_name=self.name,
            success=True,
            data=result.to_dict(),
            confidence=1.0 if result.is_valid else 0.7,
            metadata={
                "total_issues": len(result.get_all_issues()),
                "is_valid": result.is_valid,
                "iterations": result.convergence_metrics.iterations_to_converge if result.convergence_metrics else 1
            }
        )

        return self._last_output

    def get_confidence(self) -> float:
        if self._last_output:
            return self._last_output.confidence
        return 0.0

    def get_result(self) -> Optional[EnhancedVerificationResult]:
        """Get the verification result."""
        return self._result

    def _generate_issue_id(self, prefix: str) -> str:
        self._issue_counter += 1
        return f"{prefix}_{self._issue_counter:04d}"

    def _verify(self, sql: str, lineage_data: Dict,
                iterations_enabled: bool) -> EnhancedVerificationResult:
        """Perform verification."""
        result = EnhancedVerificationResult(
            original_sql=sql,
            source_files=["inline_sql"],
            target_table=lineage_data.get('target_table')
        )

        try:
            ast = sqlglot.parse_one(sql, read=self.dialect)
        except Exception as e:
            result.summary = f"Parse error: {str(e)}"
            return result

        # Get target table
        result.target_table = self._get_target_table(ast)

        convergence_detector = ConvergenceDetector()
        self._issue_counter = 0

        for iteration in range(1, self.MAX_ITERATIONS + 1 if iterations_enabled else 2):
            issues = []

            # Column completeness check
            completeness_issues = self._check_column_completeness(ast, lineage_data)
            issues.extend(completeness_issues)

            # Transformation verification
            transform_issues = self._verify_transformations(ast, lineage_data)
            issues.extend(transform_issues)

            # End-to-end lineage validation
            path_issues = self._validate_lineage_paths(ast, lineage_data)
            issues.extend(path_issues)

            # Record iteration
            corrections_attempted = len(issues)
            corrections_successful = 0

            convergence_detector.record_iteration(
                iteration, issues, corrections_attempted, corrections_successful
            )

            # Check convergence
            converged, reason = convergence_detector.check_convergence()
            if converged:
                break

        # Populate result
        result.column_completeness_issues = [i for i in issues if isinstance(i, ColumnCompletenessIssue)]
        result.transformation_mismatches = [i for i in issues if isinstance(i, TransformationMismatch)]
        result.lineage_path_issues = [i for i in issues if isinstance(i, LineagePathIssue)]
        result.convergence_metrics = convergence_detector.get_metrics()
        result.is_valid = result.convergence_metrics.final_issue_count == 0
        result.summary = self._generate_summary(result)

        return result

    def _get_target_table(self, ast: exp.Expression) -> Optional[str]:
        """Get target table."""
        if isinstance(ast, exp.Insert):
            return ast.this.name if ast.this else None
        if isinstance(ast, exp.Create):
            return ast.this.this.name if ast.this else None
        return None

    def _check_column_completeness(self, ast: exp.Expression,
                                   lineage_data: Dict) -> List[ColumnCompletenessIssue]:
        """Check column completeness."""
        issues = []
        target_table = self._get_target_table(ast) or "TARGET"

        select = ast.find(exp.Select)
        if not select:
            return issues

        documented_columns = set(lineage_data.get('columns', []))

        for i, sel_expr in enumerate(select.expressions):
            # Get column name
            if hasattr(sel_expr, 'alias') and sel_expr.alias:
                col_name = sel_expr.alias
            elif isinstance(sel_expr, exp.Column):
                col_name = sel_expr.name
            else:
                col_name = f"col_{i+1}"

            # Extract source columns from expression
            expected_sources = []
            for col in sel_expr.find_all(exp.Column):
                table = col.table or "SOURCE"
                expected_sources.append(f"{table}.{col.name}")

            # Get documented sources from lineage
            actual_sources = lineage_data.get('mappings', {}).get(col_name, [])

            # Compare
            missing = set(expected_sources) - set(actual_sources)

            if missing and expected_sources:
                issues.append(ColumnCompletenessIssue(
                    issue_id=self._generate_issue_id("CC"),
                    category=VerificationCategory.COLUMN_COMPLETENESS,
                    severity=VerificationSeverity.CRITICAL if len(missing) > 1 else VerificationSeverity.WARNING,
                    target_column=col_name,
                    target_table=target_table,
                    context="main_query",
                    expected_sources=expected_sources,
                    actual_sources=actual_sources,
                    missing_sources=list(missing),
                    description=f"Column {col_name} missing source lineage: {missing}",
                    suggested_fix=f"Add lineage for: {', '.join(missing)}"
                ))

        return issues

    def _verify_transformations(self, ast: exp.Expression,
                                lineage_data: Dict) -> List[TransformationMismatch]:
        """Verify transformation expressions."""
        issues = []

        select = ast.find(exp.Select)
        if not select:
            return issues

        documented_transforms = lineage_data.get('transformations', {})

        for i, sel_expr in enumerate(select.expressions):
            if hasattr(sel_expr, 'alias') and sel_expr.alias:
                col_name = sel_expr.alias
            elif isinstance(sel_expr, exp.Column):
                col_name = sel_expr.name
            else:
                col_name = f"col_{i+1}"

            actual_expr = sel_expr.sql(dialect=self.dialect)
            documented_expr = documented_transforms.get(col_name, "")

            if documented_expr:
                similarity = self._calculate_similarity(documented_expr, actual_expr)

                if similarity < 0.95:
                    issues.append(TransformationMismatch(
                        issue_id=self._generate_issue_id("TM"),
                        target_column=col_name,
                        documented_expression=documented_expr,
                        actual_expression=actual_expr,
                        similarity_score=similarity,
                        mismatch_type=self._classify_mismatch(documented_expr, actual_expr),
                        description=f"Transformation mismatch for {col_name}: similarity={similarity:.2f}"
                    ))

        return issues

    def _validate_lineage_paths(self, ast: exp.Expression,
                                lineage_data: Dict) -> List[LineagePathIssue]:
        """Validate end-to-end lineage paths."""
        issues = []

        target_table = self._get_target_table(ast) or "TARGET"
        paths = lineage_data.get('paths', {})

        for target_col, path in paths.items():
            if not path:
                issues.append(LineagePathIssue(
                    issue_id=self._generate_issue_id("LP"),
                    target_table=target_table,
                    target_column=target_col,
                    expected_path=[],
                    actual_path=path,
                    gap_location="No path defined",
                    is_broken=True,
                    description=f"No lineage path for {target_col}"
                ))

        return issues

    def _calculate_similarity(self, expr1: str, expr2: str) -> float:
        """Calculate similarity between expressions."""
        norm1 = ' '.join(expr1.upper().split())
        norm2 = ' '.join(expr2.upper().split())

        if norm1 == norm2:
            return 1.0

        tokens1 = set(norm1.split())
        tokens2 = set(norm2.split())

        if not tokens1 and not tokens2:
            return 1.0

        intersection = tokens1 & tokens2
        union = tokens1 | tokens2

        return len(intersection) / len(union) if union else 0.0

    def _classify_mismatch(self, documented: str, actual: str) -> str:
        """Classify mismatch type."""
        import re

        doc_funcs = set(re.findall(r'(\w+)\s*\(', documented.upper()))
        act_funcs = set(re.findall(r'(\w+)\s*\(', actual.upper()))

        if doc_funcs != act_funcs:
            return "missing_function"

        doc_cols = set(re.findall(r'(\w+\.\w+)', documented.upper()))
        act_cols = set(re.findall(r'(\w+\.\w+)', actual.upper()))

        if doc_cols != act_cols:
            return "wrong_operands"

        return "semantic_diff"

    def _generate_summary(self, result: EnhancedVerificationResult) -> str:
        """Generate summary."""
        lines = []
        lines.append("=" * 70)
        lines.append("ENHANCED CODE REVIEW SUMMARY")
        lines.append("=" * 70)

        if result.target_table:
            lines.append(f"Target table: {result.target_table}")

        lines.append(f"\nISSUES FOUND:")
        lines.append(f"  Column Completeness: {len(result.column_completeness_issues)}")
        lines.append(f"  Transformation Mismatches: {len(result.transformation_mismatches)}")
        lines.append(f"  Lineage Path Issues: {len(result.lineage_path_issues)}")

        if result.convergence_metrics:
            cm = result.convergence_metrics
            lines.append(f"\nCONVERGENCE:")
            lines.append(f"  Converged: {cm.is_converged}")
            lines.append(f"  Reason: {cm.convergence_reason}")
            lines.append(f"  Iterations: {cm.iterations_to_converge}")
            lines.append(f"  Final issues: {cm.final_issue_count}")

        lines.append("\n" + "=" * 70)
        if result.is_valid:
            lines.append("RESULT: VERIFICATION PASSED")
        else:
            lines.append("RESULT: ISSUES REMAIN - Review required")
        lines.append("=" * 70)

        return "\n".join(lines)
