"""
IntegrationExpert - Orchestrates multiple experts and combines results.

Features:
- Coordinates execution of specialized experts
- Combines and merges results with conflict resolution
- Calculates confidence scores
- Tracks provenance (which expert contributed what)
- Generates final integrated lineage output
"""

from typing import Dict, List, Optional, Any, Tuple
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime
import logging
import uuid
import sys
import os

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from .base_expert import BaseExpert, ExpertOutput
from .models.expert_result import (
    ExpertType, ConflictType, ResolutionStrategy,
    ProvenanceRecord, ConfidenceScore, ConflictRecord,
    IntegratedLineageEdge, IntegratedLineageResult
)
from .script_structure_parser import ScriptStructureParser
from .field_mapping_expert import FieldMappingExpert
from .operator_logic_expert import OperatorLogicExpert


class ConflictResolver:
    """Detects and resolves conflicts between expert outputs."""

    EXPERT_PRIORITY = {
        ExpertType.FIELD_MAPPING: 3,
        ExpertType.OPERATOR_LOGIC: 2,
        ExpertType.SCRIPT_STRUCTURE: 1
    }

    def detect_conflicts(self, expert_outputs: Dict[str, ExpertOutput]) -> List[ConflictRecord]:
        """Detect conflicts across expert outputs."""
        conflicts = []
        conflict_counter = 0

        field_data = expert_outputs.get('FieldMappingExpert', ExpertOutput(
            expert_name='FieldMappingExpert', success=False)).data
        operator_data = expert_outputs.get('OperatorLogicExpert', ExpertOutput(
            expert_name='OperatorLogicExpert', success=False)).data

        # Compare source columns for lineage edges
        field_mappings = field_data.get('field_mappings', [])
        for mapping in field_mappings:
            target_col = mapping.get('target_field', '')
            sources_field = mapping.get('source_fields', [])

            # Check if operator expert has different information about this column
            # (Would need more sophisticated logic in production)
            if not sources_field:
                conflict_counter += 1
                conflicts.append(ConflictRecord(
                    conflict_id=f"CONFLICT_{conflict_counter:04d}",
                    conflict_type=ConflictType.SOURCE_COLUMN_MISMATCH,
                    experts_involved=[ExpertType.FIELD_MAPPING],
                    conflicting_values={"FieldMappingExpert": sources_field},
                    context={"target_column": target_col}
                ))

        return conflicts

    def resolve_conflicts(self, conflicts: List[ConflictRecord],
                         strategy: ResolutionStrategy = ResolutionStrategy.EXPERT_PRIORITY
                         ) -> List[ConflictRecord]:
        """Resolve detected conflicts."""
        resolved = []

        for conflict in conflicts:
            if strategy == ResolutionStrategy.EXPERT_PRIORITY:
                resolved_conflict = self._resolve_by_priority(conflict)
            elif strategy == ResolutionStrategy.MAJORITY_VOTE:
                resolved_conflict = self._resolve_by_majority(conflict)
            elif strategy == ResolutionStrategy.UNION_ALL:
                resolved_conflict = self._resolve_by_union(conflict)
            else:
                resolved_conflict = self._resolve_by_priority(conflict)

            resolved.append(resolved_conflict)

        return resolved

    def _resolve_by_priority(self, conflict: ConflictRecord) -> ConflictRecord:
        """Resolve using expert priority."""
        if not conflict.experts_involved:
            return conflict

        highest_priority_expert = max(
            conflict.experts_involved,
            key=lambda e: self.EXPERT_PRIORITY.get(e, 0)
        )

        conflict.resolved_value = conflict.conflicting_values.get(
            highest_priority_expert.value
        )
        conflict.resolution_strategy = ResolutionStrategy.EXPERT_PRIORITY
        conflict.resolution = f"Resolved using {highest_priority_expert.value}"

        return conflict

    def _resolve_by_majority(self, conflict: ConflictRecord) -> ConflictRecord:
        """Resolve by majority vote."""
        # Count occurrences of each value
        value_counts = {}
        for expert, value in conflict.conflicting_values.items():
            val_str = str(value)
            value_counts[val_str] = value_counts.get(val_str, 0) + 1

        if value_counts:
            majority_value = max(value_counts.keys(), key=lambda k: value_counts[k])
            conflict.resolved_value = majority_value
            conflict.resolution_strategy = ResolutionStrategy.MAJORITY_VOTE
            conflict.resolution = "Resolved by majority vote"

        return conflict

    def _resolve_by_union(self, conflict: ConflictRecord) -> ConflictRecord:
        """Resolve by union of all values."""
        all_values = []
        for value in conflict.conflicting_values.values():
            if isinstance(value, list):
                all_values.extend(value)
            else:
                all_values.append(value)

        conflict.resolved_value = list(set(all_values))
        conflict.resolution_strategy = ResolutionStrategy.UNION_ALL
        conflict.resolution = "Union of all values"

        return conflict


class ConfidenceCalculator:
    """Calculates confidence scores for lineage results."""

    def calculate_edge_confidence(self, edge: IntegratedLineageEdge,
                                 expert_outputs: Dict[str, ExpertOutput],
                                 conflicts: List[ConflictRecord]) -> ConfidenceScore:
        """Calculate confidence for a lineage edge."""
        component_scores = {}
        factors = []
        penalties = []

        # Source identification score
        if edge.source_column and edge.source_table:
            component_scores["source_identification"] = 1.0
            factors.append("Source identified")
        else:
            component_scores["source_identification"] = 0.5
            penalties.append("Incomplete source")

        # Transformation accuracy
        if edge.transformation_sql:
            component_scores["transformation_accuracy"] = 0.9
            factors.append("Transformation documented")
        else:
            component_scores["transformation_accuracy"] = 0.6
            penalties.append("Missing transformation")

        # Expert agreement
        contributing_experts = len(edge.provenance)
        if contributing_experts >= 2:
            component_scores["expert_agreement"] = 1.0
            factors.append("Multiple experts agree")
        else:
            component_scores["expert_agreement"] = 0.7
            penalties.append("Single expert source")

        # Path completeness
        if edge.all_source_columns:
            component_scores["path_completeness"] = 0.9
        else:
            component_scores["path_completeness"] = 0.7
            penalties.append("Incomplete path")

        # Calculate overall
        overall = (
            0.4 * component_scores.get("source_identification", 0.5) +
            0.3 * component_scores.get("transformation_accuracy", 0.5) +
            0.2 * component_scores.get("expert_agreement", 0.5) +
            0.1 * component_scores.get("path_completeness", 0.5)
        )

        # Apply conflict penalty
        edge_conflicts = [c for c in conflicts
                        if c.context.get("target_column") == edge.target_column]
        if edge_conflicts:
            overall -= 0.1 * len(edge_conflicts)
            penalties.append(f"{len(edge_conflicts)} conflicts")

        return ConfidenceScore(
            overall_score=max(0.3, min(1.0, overall)),
            component_scores=component_scores,
            factors=factors,
            penalties=penalties
        )


class ProvenanceTracker:
    """Tracks which expert contributed what information."""

    def get_provenance_for_edge(self, edge: IntegratedLineageEdge,
                               expert_outputs: Dict[str, ExpertOutput]) -> List[ProvenanceRecord]:
        """Get provenance records for an edge."""
        provenance = []

        # Check FieldMappingExpert contribution
        field_output = expert_outputs.get('FieldMappingExpert')
        if field_output and field_output.success:
            for mapping in field_output.data.get('field_mappings', []):
                if mapping.get('target_field') == edge.target_column:
                    provenance.append(ProvenanceRecord(
                        expert_type=ExpertType.FIELD_MAPPING,
                        expert_name="FieldMappingExpert",
                        contribution_type="source_column",
                        contributed_data={
                            "source_fields": mapping.get('source_fields', []),
                            "transformation": mapping.get('transformation_sql', '')
                        },
                        confidence=field_output.confidence
                    ))
                    break

        # Check OperatorLogicExpert contribution
        operator_output = expert_outputs.get('OperatorLogicExpert')
        if operator_output and operator_output.success:
            # Check if this column is in any conditions
            columns_by_type = operator_output.data.get('columns_by_type', {})
            for condition_type, columns in columns_by_type.items():
                for col in columns:
                    if isinstance(col, str) and edge.target_column in col:
                        provenance.append(ProvenanceRecord(
                            expert_type=ExpertType.OPERATOR_LOGIC,
                            expert_name="OperatorLogicExpert",
                            contribution_type="condition_context",
                            contributed_data={
                                "condition_type": condition_type
                            },
                            confidence=operator_output.confidence
                        ))
                        break

        return provenance


class IntegrationExpert(BaseExpert):
    """
    Main orchestrator for multi-expert SQL lineage extraction.

    Coordinates:
    1. ScriptStructureParser - Script structure and decomposition
    2. FieldMappingExpert - Field-level lineage
    3. OperatorLogicExpert - Conditions and operators

    Then combines results with conflict resolution and confidence scoring.
    """

    def __init__(self, dialect: str = "teradata",
                 parallel_execution: bool = True,
                 resolution_strategy: ResolutionStrategy = ResolutionStrategy.EXPERT_PRIORITY):
        super().__init__(dialect)
        self.parallel_execution = parallel_execution
        self.resolution_strategy = resolution_strategy

        self.conflict_resolver = ConflictResolver()
        self.confidence_calculator = ConfidenceCalculator()
        self.provenance_tracker = ProvenanceTracker()

        self._script_parser: Optional[ScriptStructureParser] = None
        self._field_mapper: Optional[FieldMappingExpert] = None
        self._operator_expert: Optional[OperatorLogicExpert] = None

        self._expert_outputs: Dict[str, ExpertOutput] = {}
        self._integrated_result: Optional[IntegratedLineageResult] = None

        self.logger = logging.getLogger(__name__)

    @property
    def script_parser(self) -> ScriptStructureParser:
        if self._script_parser is None:
            self._script_parser = ScriptStructureParser(self.dialect)
        return self._script_parser

    @property
    def field_mapper(self) -> FieldMappingExpert:
        if self._field_mapper is None:
            self._field_mapper = FieldMappingExpert(self.dialect)
        return self._field_mapper

    @property
    def operator_expert(self) -> OperatorLogicExpert:
        if self._operator_expert is None:
            self._operator_expert = OperatorLogicExpert(self.dialect)
        return self._operator_expert

    def analyze(self, sql: str, **kwargs) -> ExpertOutput:
        """
        Main entry point - orchestrates full analysis pipeline.
        """
        if not self.validate_input(sql):
            return self._create_error_output("Invalid or empty SQL input")

        try:
            # Phase 1: Script Structure Analysis
            structure_output = self.script_parser.analyze(sql, **kwargs)
            self._expert_outputs['ScriptStructureParser'] = structure_output

            # Phase 2: Parallel Expert Analysis
            if self.parallel_execution:
                field_output, operator_output = self._run_parallel_experts(sql, **kwargs)
            else:
                field_output = self.field_mapper.analyze(sql, **kwargs)
                operator_output = self.operator_expert.analyze(sql, **kwargs)

            self._expert_outputs['FieldMappingExpert'] = field_output
            self._expert_outputs['OperatorLogicExpert'] = operator_output

            # Phase 3: Integration
            self._integrated_result = self._integrate_results()

            # Phase 4: Build output
            self._last_output = ExpertOutput(
                expert_name=self.name,
                success=True,
                data={
                    'integrated_lineage': self._integrated_result.to_dict(),
                    'expert_outputs': {k: v.data for k, v in self._expert_outputs.items()}
                },
                confidence=self._integrated_result.overall_confidence,
                metadata={
                    'total_edges': len(self._integrated_result.edges),
                    'total_conflicts': self._integrated_result.total_conflicts,
                    'resolved_conflicts': self._integrated_result.resolved_conflicts,
                    'expert_contributions': self._integrated_result.expert_contributions
                }
            )

            return self._last_output

        except Exception as e:
            self.logger.error(f"Integration failed: {str(e)}")
            return self._create_error_output(str(e))

    def get_confidence(self) -> float:
        if self._integrated_result:
            return self._integrated_result.overall_confidence
        return 0.0

    def get_integrated_result(self) -> Optional[IntegratedLineageResult]:
        """Get the integrated lineage result."""
        return self._integrated_result

    def _run_parallel_experts(self, sql: str, **kwargs) -> Tuple[ExpertOutput, ExpertOutput]:
        """Run experts in parallel."""
        with ThreadPoolExecutor(max_workers=2) as executor:
            field_future = executor.submit(self.field_mapper.analyze, sql, **kwargs)
            operator_future = executor.submit(self.operator_expert.analyze, sql, **kwargs)

            field_output = field_future.result()
            operator_output = operator_future.result()

        return field_output, operator_output

    def _integrate_results(self) -> IntegratedLineageResult:
        """Integrate results from all experts."""
        field_data = self._expert_outputs.get('FieldMappingExpert', ExpertOutput(
            expert_name='FieldMappingExpert', success=False)).data
        operator_data = self._expert_outputs.get('OperatorLogicExpert', ExpertOutput(
            expert_name='OperatorLogicExpert', success=False)).data

        # Build edges from field mapping
        edges = self._build_edges(field_data)

        # Detect and resolve conflicts
        conflicts = self.conflict_resolver.detect_conflicts(self._expert_outputs)
        resolved_conflicts = self.conflict_resolver.resolve_conflicts(
            conflicts, self.resolution_strategy
        )

        # Calculate confidence and add provenance
        for edge in edges:
            edge.confidence = self.confidence_calculator.calculate_edge_confidence(
                edge, self._expert_outputs, resolved_conflicts
            )
            edge.provenance = self.provenance_tracker.get_provenance_for_edge(
                edge, self._expert_outputs
            )
            # Add any conflicts related to this edge
            edge.conflicts = [c for c in resolved_conflicts
                            if c.context.get("target_column") == edge.target_column]

        # Get source and target tables
        target_table = field_data.get('target_table', '')
        source_tables = field_data.get('source_tables', [])

        # Get conditions from operator expert
        join_conditions = []
        filter_conditions = []
        if operator_data:
            join_analyses = operator_data.get('join_analyses', [])
            join_conditions = [j for j in join_analyses]

            where_analysis = operator_data.get('where_analysis')
            if where_analysis:
                filter_conditions = where_analysis.get('filter_conditions', [])

        # Calculate overall confidence
        overall_confidence = self._calculate_overall_confidence(edges)

        # Count expert contributions
        expert_contributions = self._count_contributions(edges)

        return IntegratedLineageResult(
            target_table=target_table,
            source_tables=source_tables,
            edges=edges,
            join_conditions=join_conditions,
            filter_conditions=filter_conditions,
            overall_confidence=overall_confidence,
            total_conflicts=len(conflicts),
            resolved_conflicts=len([c for c in resolved_conflicts if c.resolved_value]),
            expert_contributions=expert_contributions
        )

    def _build_edges(self, field_data: Dict) -> List[IntegratedLineageEdge]:
        """Build lineage edges from field mapping data."""
        edges = []
        target_table = field_data.get('target_table', 'TARGET')

        for mapping in field_data.get('field_mappings', []):
            source_fields = mapping.get('source_fields', [])
            source_tables = mapping.get('source_tables', [])

            # Create edge for primary source
            if source_fields:
                primary_source = source_fields[0]
                parts = primary_source.split('.') if '.' in primary_source else ['SOURCE', primary_source]
                source_table = parts[0]
                source_col = parts[-1]
            else:
                source_table = source_tables[0] if source_tables else 'SOURCE'
                source_col = mapping.get('target_field', '')

            edges.append(IntegratedLineageEdge(
                source_table=source_table,
                source_column=source_col,
                target_table=target_table,
                target_column=mapping.get('target_field', ''),
                transformation_sql=mapping.get('transformation_sql', ''),
                transformation_type=mapping.get('mapping_type', 'DIRECT'),
                transformation_subtype='',
                english_explanation=mapping.get('transformation_description', ''),
                all_source_columns=source_fields
            ))

        return edges

    def _calculate_overall_confidence(self, edges: List[IntegratedLineageEdge]) -> float:
        """Calculate overall confidence."""
        if not edges:
            return 0.5

        total = sum(e.confidence.overall_score if e.confidence else 0.7 for e in edges)
        return total / len(edges)

    def _count_contributions(self, edges: List[IntegratedLineageEdge]) -> Dict[str, int]:
        """Count contributions by expert."""
        counts = {}
        for edge in edges:
            for prov in edge.provenance:
                expert = prov.expert_name
                counts[expert] = counts.get(expert, 0) + 1
        return counts

    def export_csv(self, output_path: str) -> None:
        """Export to CSV."""
        if not self._integrated_result:
            raise ValueError("No integrated result available")

        import csv

        rows = [edge.to_csv_row() for edge in self._integrated_result.edges]

        if rows:
            fieldnames = list(rows[0].keys())
            with open(output_path, 'w', newline='', encoding='utf-8') as f:
                writer = csv.DictWriter(f, fieldnames=fieldnames)
                writer.writeheader()
                writer.writerows(rows)

    def export_json(self, output_path: str) -> None:
        """Export to JSON."""
        if not self._integrated_result:
            raise ValueError("No integrated result available")

        import json
        with open(output_path, 'w', encoding='utf-8') as f:
            json.dump(self._integrated_result.to_dict(), f, indent=2)
