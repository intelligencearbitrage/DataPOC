"""
Multi-Expert Architecture for SQL Reverse Engineering.

This module provides a coordinated set of specialized experts for comprehensive
SQL analysis:
- ScriptStructureParser: Analyzes syntactic structure, identifies subqueries and CTEs
- FieldMappingExpert: Traces field-level transformations and mappings
- OperatorLogicExpert: Analyzes conditions, operators, and filter logic
- IntegrationExpert: Orchestrates experts and combines results
- EnhancedCodeReviewer: Verifies completeness and correctness
"""

from .models.expert_result import (
    ExpertType,
    ConflictType,
    ResolutionStrategy,
    ProvenanceRecord,
    ConfidenceScore,
    ConflictRecord,
    IntegratedLineageEdge,
    IntegratedLineageResult
)

from .base_expert import BaseExpert, ExpertOutput

__all__ = [
    # Base classes
    "BaseExpert",
    "ExpertOutput",
    # Enums and types
    "ExpertType",
    "ConflictType",
    "ResolutionStrategy",
    # Result models
    "ProvenanceRecord",
    "ConfidenceScore",
    "ConflictRecord",
    "IntegratedLineageEdge",
    "IntegratedLineageResult",
]
