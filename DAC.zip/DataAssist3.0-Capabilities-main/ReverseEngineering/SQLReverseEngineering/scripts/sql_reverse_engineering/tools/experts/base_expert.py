"""
Base class for all expert modules in the multi-expert architecture.
"""

from abc import ABC, abstractmethod
from typing import Any, Dict, List, Optional
from dataclasses import dataclass, field


@dataclass
class ExpertOutput:
    """Base output structure for all experts."""
    expert_name: str
    success: bool
    data: Dict[str, Any] = field(default_factory=dict)
    confidence: float = 1.0
    errors: List[str] = field(default_factory=list)
    warnings: List[str] = field(default_factory=list)
    metadata: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "expert_name": self.expert_name,
            "success": self.success,
            "data": self.data,
            "confidence": self.confidence,
            "errors": self.errors,
            "warnings": self.warnings,
            "metadata": self.metadata
        }


class BaseExpert(ABC):
    """
    Abstract base class for all expert modules.

    Each expert specializes in a specific aspect of SQL analysis:
    - ScriptStructureParser: Script structure and decomposition
    - FieldMappingExpert: Field-level lineage and transformations
    - OperatorLogicExpert: Conditions and operators
    - IntegrationExpert: Orchestration and result combination
    """

    def __init__(self, dialect: str = "teradata"):
        self.dialect = dialect
        self.name: str = self.__class__.__name__
        self._last_output: Optional[ExpertOutput] = None

    @abstractmethod
    def analyze(self, sql: str, **kwargs) -> ExpertOutput:
        """
        Main analysis method - must be implemented by subclasses.

        Args:
            sql: SQL string to analyze
            **kwargs: Additional parameters specific to each expert

        Returns:
            ExpertOutput containing analysis results
        """
        pass

    @abstractmethod
    def get_confidence(self) -> float:
        """Return confidence score for last analysis."""
        pass

    def get_last_output(self) -> Optional[ExpertOutput]:
        """Get the output from the last analysis."""
        return self._last_output

    def validate_input(self, sql: str) -> bool:
        """Validate input SQL."""
        return sql is not None and len(sql.strip()) > 0

    def _create_error_output(self, error_message: str) -> ExpertOutput:
        """Create an error output."""
        return ExpertOutput(
            expert_name=self.name,
            success=False,
            errors=[error_message],
            confidence=0.0
        )
