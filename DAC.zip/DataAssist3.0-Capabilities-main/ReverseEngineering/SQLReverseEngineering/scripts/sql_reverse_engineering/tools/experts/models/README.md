# Expert Models

## Overview
This module contains data models and structures used by expert modules for analysis and output representation.

## Components

### `expert_result.py`
Standard result structure for all expert outputs.

**Main Class:**

#### `ExpertOutput`
Standardized output from any expert.

**Fields:**
- `expert_name` - Name of the expert that produced the output
- `success` - Whether analysis succeeded
- `data` - Expert-specific result data (dict)
- `confidence` - Confidence score (0.0 to 1.0)
- `errors` - List of errors encountered
- `warnings` - List of warnings
- `metadata` - Additional metadata

**Methods:**
- `to_dict()` - Convert to dictionary
- `from_dict()` - Create from dictionary
- `merge()` - Merge multiple expert outputs

**Usage:**
```python
output = ExpertOutput(
    expert_name="FieldMappingExpert",
    success=True,
    data={"mappings": [...]},
    confidence=0.9,
    errors=[],
    warnings=["Column type mismatch detected"]
)
```

### `field_models.py`
Models for field-level lineage and transformations.

**Classes:**

#### `FieldMapping`
Represents a source-to-target field mapping.

**Fields:**
- `source_table` - Source table name
- `source_column` - Source column name
- `target_table` - Target table name
- `target_column` - Target column name
- `transformation` - Transformation expression
- `transformation_type` - Type of transformation
- `data_type_source` - Source data type
- `data_type_target` - Target data type
- `business_rule` - Business rule description

**Example:**
```python
mapping = FieldMapping(
    source_table="customers",
    source_column="first_name",
    target_table="dim_customer",
    target_column="customer_first_name",
    transformation="UPPER(first_name)",
    transformation_type="string_manipulation"
)
```

#### `TransformationDetail`
Detailed transformation information.

**Fields:**
- `expression` - Full transformation expression
- `type` - Transformation type (DIRECT, INDIRECT)
- `subtype` - Detailed subtype (CAST, AGGREGATION, etc.)
- `functions_used` - List of functions
- `complexity_score` - Complexity rating
- `reversible` - Whether transformation is reversible

#### `FieldDependency`
Tracks field dependencies.

**Fields:**
- `target_field` - Target field
- `source_fields` - List of source fields
- `dependency_type` - Type of dependency
- `is_direct` - Whether direct or indirect

### `condition_models.py`
Models for conditional logic and operators.

**Classes:**

#### `Condition`
Represents a single condition.

**Fields:**
- `expression` - Full condition expression
- `operator` - Comparison operator (=, <, >, etc.)
- `left_operand` - Left side of condition
- `right_operand` - Right side of condition
- `condition_type` - Type (comparison, logical, etc.)
- `negated` - Whether condition is negated

**Example:**
```python
condition = Condition(
    expression="status = 'ACTIVE'",
    operator="=",
    left_operand="status",
    right_operand="'ACTIVE'",
    condition_type="comparison",
    negated=False
)
```

#### `LogicTree`
Boolean logic tree representation.

**Fields:**
- `root` - Root node of logic tree
- `operator` - Logical operator (AND, OR)
- `children` - Child nodes
- `complexity` - Tree complexity score

**Methods:**
- `evaluate()` - Evaluate tree with values
- `simplify()` - Simplify logic
- `to_sql()` - Convert to SQL WHERE clause

#### `CaseExpression`
Represents CASE WHEN logic.

**Fields:**
- `branches` - List of WHEN branches
- `else_value` - ELSE value
- `result_type` - Result data type
- `is_searched` - Searched vs simple CASE

### `structure_models.py`
Models for script structure and organization.

**Classes:**

#### `Statement`
Represents a single SQL statement.

**Fields:**
- `type` - Statement type (SELECT, INSERT, etc.)
- `text` - Full statement text
- `line_start` - Starting line number
- `line_end` - Ending line number
- `dependencies` - Other statements this depends on
- `affects` - What this statement affects

**Example:**
```python
statement = Statement(
    type="INSERT",
    text="INSERT INTO target SELECT * FROM source",
    line_start=10,
    line_end=12,
    dependencies=["source"],
    affects=["target"]
)
```

#### `CodeBlock`
Group of related statements.

**Fields:**
- `name` - Block name
- `statements` - List of statements
- `block_type` - Type (procedure, transaction, etc.)
- `variables` - Variables used
- `parameters` - Input parameters

#### `Dependency`
Dependency between statements or objects.

**Fields:**
- `source` - Source object
- `target` - Target object
- `dependency_type` - Type of dependency
- `strength` - Dependency strength (strong/weak)

#### `ScriptStructure`
Overall script structure.

**Fields:**
- `statements` - All statements
- `blocks` - Code blocks
- `dependencies` - All dependencies
- `execution_order` - Recommended execution order
- `complexity_score` - Overall complexity

**Methods:**
- `get_execution_plan()` - Get execution plan
- `find_circular_deps()` - Find circular dependencies
- `optimize_order()` - Optimize execution order

## Usage Example

```python
from experts.models.field_models import FieldMapping
from experts.models.condition_models import Condition
from experts.models.structure_models import Statement

# Create field mapping
mapping = FieldMapping(
    source_table="source_table",
    source_column="col1",
    target_table="target_table",
    target_column="col2",
    transformation="UPPER(col1)"
)

# Create condition
condition = Condition(
    expression="status = 'ACTIVE'",
    operator="=",
    left_operand="status",
    right_operand="'ACTIVE'"
)

# Create statement
statement = Statement(
    type="SELECT",
    text="SELECT * FROM table",
    line_start=1,
    line_end=1
)
```

## Integration Points
- Used by: All expert modules
- Provides: Standard data structures
- Ensures: Consistency across experts
- Enables: Easy merging and comparison of results
