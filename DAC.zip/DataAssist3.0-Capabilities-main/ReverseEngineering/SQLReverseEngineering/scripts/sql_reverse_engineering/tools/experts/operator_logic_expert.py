"""
OperatorLogicExpert - Analyzes conditions, operators, and filter logic.

Features:
- WHERE clause parsing with boolean logic trees
- HAVING/QUALIFY clause support
- JOIN condition analysis
- Operator classification and metadata
- Complex predicate analysis (nested AND/OR/NOT)
"""

import sqlglot
from sqlglot import exp
from typing import Dict, List, Optional, Tuple
import uuid
import sys
import os

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from .base_expert import BaseExpert, ExpertOutput
from .models.condition_models import (
    ConditionType, ComparisonOperator, LogicalOperator, LogicNodeType,
    OperatorMetadata, ConditionColumn, ConditionValue, AtomicCondition,
    LogicTreeNode, WhereClauseAnalysis, HavingClauseAnalysis,
    QualifyClauseAnalysis, JoinConditionAnalysis, GroupByAnalysis,
    OrderByAnalysis, OperatorLogicAnalysis
)


class OperatorLogicExpert(BaseExpert):
    """
    Expert for analyzing operator-level logic in SQL statements.

    Provides:
    1. WHERE clause analysis with boolean logic trees
    2. HAVING clause analysis for aggregate conditions
    3. QUALIFY clause analysis (Teradata/Snowflake)
    4. JOIN condition extraction
    5. GROUP BY and ORDER BY analysis
    """

    COMPARISON_MAP = {
        exp.EQ: ComparisonOperator.EQ,
        exp.NEQ: ComparisonOperator.NEQ,
        exp.GT: ComparisonOperator.GT,
        exp.GTE: ComparisonOperator.GTE,
        exp.LT: ComparisonOperator.LT,
        exp.LTE: ComparisonOperator.LTE,
        exp.Like: ComparisonOperator.LIKE,
        exp.ILike: ComparisonOperator.ILIKE,
        exp.In: ComparisonOperator.IN,
        exp.Between: ComparisonOperator.BETWEEN,
        exp.Is: ComparisonOperator.IS_NULL,
    }

    def __init__(self, dialect: str = "teradata"):
        super().__init__(dialect)
        self._condition_counter = 0
        self._result: Optional[OperatorLogicAnalysis] = None

    def analyze(self, sql: str, **kwargs) -> ExpertOutput:
        """
        Perform complete operator logic analysis.
        """
        if not self.validate_input(sql):
            return self._create_error_output("Invalid or empty SQL input")

        try:
            ast = sqlglot.parse_one(sql, read=self.dialect)
        except Exception as e:
            return self._create_error_output(f"Parse error: {str(e)}")

        self._condition_counter = 0
        statement_id = kwargs.get('statement_id', str(uuid.uuid4())[:8])
        statement_type = self._get_statement_type(ast)

        # Parse all clauses
        where_analysis = self._parse_where(ast)
        having_analysis = self._parse_having(ast)
        qualify_analysis = self._parse_qualify(ast)
        join_analyses = self._parse_joins(ast)
        group_by_analysis = self._parse_group_by(ast)
        order_by_analysis = self._parse_order_by(ast)

        # Aggregate all conditions
        all_conditions = []
        if where_analysis:
            all_conditions.extend(where_analysis.filter_conditions)
        if having_analysis:
            all_conditions.extend(having_analysis.aggregate_conditions)
        if qualify_analysis:
            all_conditions.extend(qualify_analysis.window_conditions)
        for join in join_analyses:
            all_conditions.extend(join.conditions)

        # Organize columns by type
        columns_by_type = self._organize_columns_by_type(
            where_analysis, having_analysis, qualify_analysis,
            join_analyses, group_by_analysis, order_by_analysis
        )

        # Summarize operators
        operator_summary = self._summarize_operators(all_conditions)

        # Calculate complexity
        max_depth = self._calculate_max_nesting_depth(
            where_analysis, having_analysis, qualify_analysis, join_analyses
        )
        complexity = self._calculate_overall_complexity(
            all_conditions, max_depth, join_analyses
        )

        self._result = OperatorLogicAnalysis(
            statement_id=statement_id,
            statement_type=statement_type,
            where_analysis=where_analysis,
            having_analysis=having_analysis,
            qualify_analysis=qualify_analysis,
            join_analyses=join_analyses,
            group_by_analysis=group_by_analysis,
            order_by_analysis=order_by_analysis,
            all_conditions=all_conditions,
            all_columns_by_type=columns_by_type,
            operator_summary=operator_summary,
            total_conditions=len(all_conditions),
            max_nesting_depth=max_depth,
            complexity_score=complexity
        )

        self._last_output = ExpertOutput(
            expert_name=self.name,
            success=True,
            data=self._result.to_dict(),
            confidence=self._calculate_confidence(),
            metadata={
                "total_conditions": len(all_conditions),
                "max_nesting_depth": max_depth,
                "join_count": len(join_analyses),
                "has_having": having_analysis is not None,
                "has_qualify": qualify_analysis is not None
            }
        )

        return self._last_output

    def get_confidence(self) -> float:
        if self._last_output:
            return self._last_output.confidence
        return 0.0

    def get_result(self) -> Optional[OperatorLogicAnalysis]:
        """Get the full operator logic analysis result."""
        return self._result

    def _get_statement_type(self, ast: exp.Expression) -> str:
        """Determine statement type."""
        # Check for SELECT INTO (Teradata SPL)
        if isinstance(ast, exp.Select) and ast.args.get('into'):
            return "SELECT INTO"

        type_map = {
            exp.Select: "SELECT",
            exp.Insert: "INSERT",
            exp.Update: "UPDATE",
            exp.Delete: "DELETE",
            exp.Merge: "MERGE",
            exp.Create: "CREATE"
        }
        for exp_type, name in type_map.items():
            if isinstance(ast, exp_type):
                return name
        return ast.__class__.__name__.upper()

    def _parse_where(self, ast: exp.Expression) -> Optional[WhereClauseAnalysis]:
        """Parse WHERE clause."""
        where = ast.find(exp.Where)
        if not where:
            return None

        logic_tree = self._parse_predicate(where.this)
        all_conditions = logic_tree.get_all_conditions()
        all_columns = logic_tree.get_all_columns()

        has_subquery = any(c.has_subquery for c in all_conditions)
        has_correlated = self._check_correlated_subqueries(where, ast)
        complexity = self._calculate_clause_complexity(logic_tree, all_conditions)

        return WhereClauseAnalysis(
            clause_type=ConditionType.WHERE_FILTER,
            sql_text=where.sql(dialect=self.dialect),
            logic_tree=logic_tree,
            columns_involved=all_columns,
            operators_used=self._extract_operators(all_conditions),
            filter_conditions=all_conditions,
            has_subquery=has_subquery,
            has_correlated_subquery=has_correlated,
            complexity_score=complexity,
            english_explanation=self._generate_where_explanation(logic_tree)
        )

    def _parse_having(self, ast: exp.Expression) -> Optional[HavingClauseAnalysis]:
        """Parse HAVING clause."""
        having = ast.find(exp.Having)
        if not having:
            return None

        logic_tree = self._parse_predicate(having.this)
        all_conditions = logic_tree.get_all_conditions()
        agg_functions = self._extract_aggregate_functions(having)

        return HavingClauseAnalysis(
            clause_type=ConditionType.HAVING_AGGREGATE,
            sql_text=having.sql(dialect=self.dialect),
            logic_tree=logic_tree,
            columns_involved=logic_tree.get_all_columns(),
            operators_used=self._extract_operators(all_conditions),
            aggregate_conditions=all_conditions,
            aggregate_functions=agg_functions,
            english_explanation=self._generate_having_explanation(logic_tree, agg_functions)
        )

    def _parse_qualify(self, ast: exp.Expression) -> Optional[QualifyClauseAnalysis]:
        """Parse QUALIFY clause (Teradata/Snowflake)."""
        qualify = ast.find(exp.Qualify)
        if not qualify:
            return None

        logic_tree = self._parse_predicate(qualify.this)
        all_conditions = logic_tree.get_all_conditions()
        window_functions = self._extract_window_functions(qualify)

        return QualifyClauseAnalysis(
            clause_type=ConditionType.QUALIFY_WINDOW,
            sql_text=qualify.sql(dialect=self.dialect),
            logic_tree=logic_tree,
            columns_involved=logic_tree.get_all_columns(),
            operators_used=self._extract_operators(all_conditions),
            window_conditions=all_conditions,
            window_functions=window_functions,
            english_explanation=self._generate_qualify_explanation(logic_tree, window_functions)
        )

    def _parse_joins(self, ast: exp.Expression) -> List[JoinConditionAnalysis]:
        """Parse all JOIN conditions."""
        join_analyses = []

        for i, join_node in enumerate(ast.find_all(exp.Join), 1):
            join_id = f"JOIN_{i:03d}"
            join_type = self._get_join_type(join_node)

            # Get right table
            right_table = join_node.this.name if isinstance(join_node.this, exp.Table) else "UNKNOWN"
            right_alias = join_node.this.alias if hasattr(join_node.this, 'alias') else None

            # Get ON condition
            on_expr = join_node.args.get("on")
            logic_tree = None
            conditions = []

            if on_expr:
                logic_tree = self._parse_predicate(on_expr)
                conditions = logic_tree.get_all_conditions()

            # Separate columns
            columns_left = []
            columns_right = []
            for cond in conditions:
                for col in cond.columns_involved:
                    if col.table_name.upper() == right_table.upper() or \
                       (right_alias and col.table_name.upper() == right_alias.upper()):
                        columns_right.append(col)
                    else:
                        columns_left.append(col)

            join_analyses.append(JoinConditionAnalysis(
                join_id=join_id,
                join_type=join_type,
                left_table="",  # Would need to track from context
                right_table=right_table,
                right_alias=right_alias,
                logic_tree=logic_tree,
                conditions=conditions,
                columns_left=columns_left,
                columns_right=columns_right,
                operators_used=self._extract_operators(conditions),
                english_explanation=self._generate_join_explanation(join_type, "", right_table, logic_tree)
            ))

        return join_analyses

    def _parse_group_by(self, ast: exp.Expression) -> Optional[GroupByAnalysis]:
        """Parse GROUP BY clause."""
        group = ast.find(exp.Group)
        if not group:
            return None

        columns = []
        expressions = []

        for group_expr in group.expressions:
            if isinstance(group_expr, exp.Column):
                columns.append(ConditionColumn(
                    table_name=group_expr.table if group_expr.table else "",
                    column_name=group_expr.name
                ))
            else:
                expressions.append(group_expr.sql(dialect=self.dialect))
                for col in group_expr.find_all(exp.Column):
                    columns.append(ConditionColumn(
                        table_name=col.table if col.table else "",
                        column_name=col.name
                    ))

        return GroupByAnalysis(
            columns=columns,
            expressions=expressions,
            sql_text=group.sql(dialect=self.dialect)
        )

    def _parse_order_by(self, ast: exp.Expression) -> Optional[OrderByAnalysis]:
        """Parse ORDER BY clause."""
        order = ast.find(exp.Order)
        if not order:
            return None

        columns = []
        directions = []
        nulls_handling = []

        for ordered in order.expressions:
            if isinstance(ordered, exp.Ordered):
                col = ordered.this
                direction = "DESC" if ordered.args.get("desc") else "ASC"
                nulls = ""
                if ordered.args.get("nulls_first"):
                    nulls = "NULLS FIRST"
                elif ordered.args.get("nulls_last"):
                    nulls = "NULLS LAST"
            else:
                col = ordered
                direction = "ASC"
                nulls = ""

            if isinstance(col, exp.Column):
                columns.append(ConditionColumn(
                    table_name=col.table if col.table else "",
                    column_name=col.name
                ))
                directions.append(direction)
                nulls_handling.append(nulls)

        return OrderByAnalysis(
            columns=columns,
            directions=directions,
            nulls_handling=nulls_handling,
            sql_text=order.sql(dialect=self.dialect)
        )

    def _parse_predicate(self, expr: exp.Expression) -> LogicTreeNode:
        """Parse predicate into logic tree."""
        if expr is None:
            return LogicTreeNode(node_type=LogicNodeType.LEAF)

        # Handle AND
        if isinstance(expr, exp.And):
            return LogicTreeNode(
                node_type=LogicNodeType.AND,
                children=[
                    self._parse_predicate(expr.this),
                    self._parse_predicate(expr.expression)
                ]
            )

        # Handle OR
        if isinstance(expr, exp.Or):
            return LogicTreeNode(
                node_type=LogicNodeType.OR,
                children=[
                    self._parse_predicate(expr.this),
                    self._parse_predicate(expr.expression)
                ]
            )

        # Handle NOT
        if isinstance(expr, exp.Not):
            child_node = self._parse_predicate(expr.this)
            child_node.negated = True
            return child_node

        # Handle comparison operators
        if isinstance(expr, tuple(self.COMPARISON_MAP.keys())):
            return self._create_leaf_node(expr)

        # Handle EXISTS
        if isinstance(expr, exp.Exists):
            return self._create_exists_leaf(expr)

        # Handle Paren
        if isinstance(expr, exp.Paren):
            return self._parse_predicate(expr.this)

        # Default: treat as atomic
        return self._create_generic_leaf(expr)

    def _create_leaf_node(self, comp_expr: exp.Expression) -> LogicTreeNode:
        """Create leaf node from comparison."""
        self._condition_counter += 1
        condition_id = f"COND_{self._condition_counter:04d}"

        left_value = self._extract_value(comp_expr.this)
        right_value = self._extract_value(comp_expr.expression) if hasattr(comp_expr, 'expression') else None

        operator_type = self.COMPARISON_MAP.get(type(comp_expr), ComparisonOperator.EQ)
        operator_meta = OperatorMetadata(
            operator_type=operator_type,
            operator_symbol=operator_type.value
        )

        columns = self._extract_columns(comp_expr)
        functions = self._extract_functions(comp_expr)
        has_subquery = bool(comp_expr.find(exp.Subquery))

        atomic = AtomicCondition(
            condition_id=condition_id,
            left_operand=left_value,
            operator=operator_meta,
            right_operand=right_value,
            sql_text=comp_expr.sql(dialect=self.dialect),
            columns_involved=columns,
            functions_used=functions,
            has_subquery=has_subquery
        )

        return LogicTreeNode(
            node_type=LogicNodeType.LEAF,
            atomic_condition=atomic
        )

    def _create_exists_leaf(self, exists_expr: exp.Exists) -> LogicTreeNode:
        """Create leaf node for EXISTS."""
        self._condition_counter += 1
        condition_id = f"COND_{self._condition_counter:04d}"

        operator_meta = OperatorMetadata(
            operator_type=ComparisonOperator.EXISTS,
            operator_symbol="EXISTS"
        )

        left_value = ConditionValue(value_type="SUBQUERY", raw_value="EXISTS")

        atomic = AtomicCondition(
            condition_id=condition_id,
            left_operand=left_value,
            operator=operator_meta,
            sql_text=exists_expr.sql(dialect=self.dialect),
            has_subquery=True
        )

        return LogicTreeNode(
            node_type=LogicNodeType.LEAF,
            atomic_condition=atomic
        )

    def _create_generic_leaf(self, expr: exp.Expression) -> LogicTreeNode:
        """Create generic leaf node."""
        self._condition_counter += 1
        condition_id = f"COND_{self._condition_counter:04d}"

        operator_meta = OperatorMetadata(
            operator_type=ComparisonOperator.EQ,
            operator_symbol="?"
        )

        left_value = ConditionValue(value_type="EXPRESSION", raw_value=expr.sql(dialect=self.dialect))

        atomic = AtomicCondition(
            condition_id=condition_id,
            left_operand=left_value,
            operator=operator_meta,
            sql_text=expr.sql(dialect=self.dialect),
            columns_involved=self._extract_columns(expr)
        )

        return LogicTreeNode(
            node_type=LogicNodeType.LEAF,
            atomic_condition=atomic
        )

    def _extract_value(self, expr: exp.Expression) -> ConditionValue:
        """Extract a ConditionValue from expression."""
        if expr is None:
            return ConditionValue(value_type="NULL", raw_value="NULL")

        if isinstance(expr, exp.Column):
            col_ref = ConditionColumn(
                table_name=expr.table if expr.table else "",
                column_name=expr.name
            )
            return ConditionValue(
                value_type="COLUMN",
                raw_value=expr.sql(dialect=self.dialect),
                column_ref=col_ref
            )

        if isinstance(expr, exp.Literal):
            data_type = "STRING" if expr.is_string else "NUMBER"
            return ConditionValue(
                value_type="LITERAL",
                raw_value=str(expr.this),
                data_type=data_type
            )

        if isinstance(expr, exp.Subquery):
            return ConditionValue(
                value_type="SUBQUERY",
                raw_value=expr.sql(dialect=self.dialect),
                subquery_sql=expr.sql(dialect=self.dialect)
            )

        return ConditionValue(
            value_type="EXPRESSION",
            raw_value=expr.sql(dialect=self.dialect)
        )

    def _extract_columns(self, expr: exp.Expression) -> List[ConditionColumn]:
        """Extract columns from expression."""
        columns = []
        for col in expr.find_all(exp.Column):
            is_agg = self._is_in_aggregate(col)
            is_window = self._is_in_window(col)

            columns.append(ConditionColumn(
                table_name=col.table if col.table else "",
                column_name=col.name,
                is_aggregate=is_agg,
                is_window_function=is_window
            ))
        return columns

    def _extract_functions(self, expr: exp.Expression) -> List[str]:
        """Extract function names."""
        functions = []
        for func in expr.find_all(exp.Func):
            try:
                functions.append(func.sql_name() if hasattr(func, 'sql_name') else func.__class__.__name__)
            except:
                functions.append(func.__class__.__name__)
        return list(set(functions))

    def _is_in_aggregate(self, col: exp.Column) -> bool:
        """Check if column is in aggregate function."""
        parent = col.parent
        while parent:
            if isinstance(parent, exp.Func):
                func_name = parent.__class__.__name__.upper()
                if func_name in {'SUM', 'COUNT', 'AVG', 'MIN', 'MAX', 'STDDEV', 'VARIANCE'}:
                    return True
            parent = parent.parent
        return False

    def _is_in_window(self, col: exp.Column) -> bool:
        """Check if column is in window function."""
        parent = col.parent
        while parent:
            if isinstance(parent, exp.Window):
                return True
            parent = parent.parent
        return False

    def _get_join_type(self, join_node: exp.Join) -> str:
        """Get JOIN type."""
        if join_node.args.get("side") == "LEFT":
            return "LEFT"
        if join_node.args.get("side") == "RIGHT":
            return "RIGHT"
        if join_node.args.get("kind") == "CROSS":
            return "CROSS"
        if join_node.args.get("kind") == "FULL":
            return "FULL"
        return "INNER"

    def _check_correlated_subqueries(self, where: exp.Where, ast: exp.Expression) -> bool:
        """Check for correlated subqueries."""
        for subq in where.find_all(exp.Subquery):
            # Check if subquery references outer tables
            outer_tables = set(t.name.upper() for t in ast.find_all(exp.Table)
                             if t not in subq.find_all(exp.Table))
            for col in subq.find_all(exp.Column):
                if col.table and col.table.upper() in outer_tables:
                    return True
        return False

    def _extract_aggregate_functions(self, expr: exp.Expression) -> List[str]:
        """Extract aggregate function names."""
        aggs = []
        for func in expr.find_all(exp.Func):
            name = func.__class__.__name__.upper()
            if name in {'SUM', 'COUNT', 'AVG', 'MIN', 'MAX', 'STDDEV', 'VARIANCE'}:
                aggs.append(name)
        return list(set(aggs))

    def _extract_window_functions(self, expr: exp.Expression) -> List[str]:
        """Extract window function names."""
        windows = []
        for func in expr.find_all(exp.Window):
            if func.this:
                windows.append(func.this.__class__.__name__.upper())
        return list(set(windows))

    def _extract_operators(self, conditions: List[AtomicCondition]) -> List[OperatorMetadata]:
        """Extract operators from conditions."""
        return [c.operator for c in conditions]

    def _organize_columns_by_type(self, where_analysis, having_analysis, qualify_analysis,
                                  join_analyses, group_by_analysis, order_by_analysis) -> Dict:
        """Organize columns by condition type."""
        columns_by_type = {}

        if where_analysis:
            columns_by_type[ConditionType.WHERE_FILTER.value] = where_analysis.columns_involved
        if having_analysis:
            columns_by_type[ConditionType.HAVING_AGGREGATE.value] = having_analysis.columns_involved
        if qualify_analysis:
            columns_by_type[ConditionType.QUALIFY_WINDOW.value] = qualify_analysis.columns_involved
        if join_analyses:
            join_columns = []
            for join in join_analyses:
                join_columns.extend(join.columns_left)
                join_columns.extend(join.columns_right)
            columns_by_type[ConditionType.JOIN_ASSOCIATION.value] = join_columns
        if group_by_analysis:
            columns_by_type[ConditionType.GROUP_BY_GROUPING.value] = group_by_analysis.columns
        if order_by_analysis:
            columns_by_type[ConditionType.ORDER_BY_SORT.value] = order_by_analysis.columns

        return columns_by_type

    def _summarize_operators(self, conditions: List[AtomicCondition]) -> Dict[str, int]:
        """Count operator usage."""
        summary = {}
        for cond in conditions:
            op = cond.operator.operator_symbol
            summary[op] = summary.get(op, 0) + 1
        return summary

    def _calculate_clause_complexity(self, tree: LogicTreeNode,
                                     conditions: List[AtomicCondition]) -> int:
        """Calculate clause complexity (1-5)."""
        score = 1
        depth = self._get_tree_depth(tree)

        if depth > 3:
            score += 2
        elif depth > 1:
            score += 1

        if len(conditions) > 10:
            score += 2
        elif len(conditions) > 5:
            score += 1

        if any(c.has_subquery for c in conditions):
            score += 1

        return min(score, 5)

    def _get_tree_depth(self, tree: LogicTreeNode) -> int:
        """Get maximum depth of logic tree."""
        if tree.is_leaf():
            return 1
        max_child_depth = 0
        for child in tree.children:
            if isinstance(child, LogicTreeNode):
                max_child_depth = max(max_child_depth, self._get_tree_depth(child))
        return max_child_depth + 1

    def _calculate_max_nesting_depth(self, where_analysis, having_analysis,
                                     qualify_analysis, join_analyses) -> int:
        """Calculate maximum nesting depth."""
        max_depth = 0

        for analysis in [where_analysis, having_analysis, qualify_analysis]:
            if analysis and analysis.logic_tree:
                depth = self._get_tree_depth(analysis.logic_tree)
                max_depth = max(max_depth, depth)

        for join in (join_analyses or []):
            if join.logic_tree:
                depth = self._get_tree_depth(join.logic_tree)
                max_depth = max(max_depth, depth)

        return max_depth

    def _calculate_overall_complexity(self, conditions: List[AtomicCondition],
                                      max_depth: int, join_analyses) -> int:
        """Calculate overall complexity (1-5)."""
        score = 1

        if len(conditions) > 15:
            score += 2
        elif len(conditions) > 7:
            score += 1

        if max_depth > 4:
            score += 2
        elif max_depth > 2:
            score += 1

        if len(join_analyses or []) > 5:
            score += 1

        if any(c.has_subquery for c in conditions):
            score += 1

        return min(score, 5)

    def _generate_where_explanation(self, tree: LogicTreeNode) -> str:
        """Generate English explanation for WHERE clause."""
        conditions = tree.get_all_conditions()
        if not conditions:
            return "No filter conditions"

        parts = []
        for cond in conditions[:3]:  # Limit to 3
            parts.append(cond.sql_text)

        if len(conditions) > 3:
            return f"Filter with {len(conditions)} conditions: {'; '.join(parts)}..."
        return f"Filter: {'; '.join(parts)}"

    def _generate_having_explanation(self, tree: LogicTreeNode, agg_funcs: List[str]) -> str:
        """Generate explanation for HAVING clause."""
        if not agg_funcs:
            return "HAVING clause filtering"
        return f"Filter on aggregates: {', '.join(agg_funcs)}"

    def _generate_qualify_explanation(self, tree: LogicTreeNode, window_funcs: List[str]) -> str:
        """Generate explanation for QUALIFY clause."""
        if not window_funcs:
            return "QUALIFY window filter"
        return f"Filter on window functions: {', '.join(window_funcs)}"

    def _generate_join_explanation(self, join_type: str, left_table: str,
                                   right_table: str, tree: Optional[LogicTreeNode]) -> str:
        """Generate explanation for JOIN."""
        return f"{join_type} JOIN with {right_table}"

    def _calculate_confidence(self) -> float:
        """Calculate confidence score."""
        if not self._result:
            return 0.0

        confidence = 1.0

        # Reduce for complex structures
        if self._result.max_nesting_depth > 5:
            confidence -= 0.2
        elif self._result.max_nesting_depth > 3:
            confidence -= 0.1

        return max(0.5, min(1.0, confidence))
