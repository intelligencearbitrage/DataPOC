"""
ScriptStructureParser Expert - Analyzes SQL syntactic structure.

Features:
- Nesting depth analysis for subqueries
- Parent-child subquery relationship tracking
- Script decomposition into subscripts (CTEs, subqueries, main query)
- Dependency graph building
- Complexity scoring
"""

import sqlglot
from sqlglot import exp
from typing import Dict, List, Optional, Tuple, Set
import uuid

from .base_expert import BaseExpert, ExpertOutput
from .models.structure_models import (
    Subscript, SubscriptType, SubscriptLocation, SubscriptRelationship,
    RelationshipType, DependencyEdge, DepthAnalysisResult,
    ComplexityMetrics, StructureAnalysisResult
)


class ScriptStructureParser(BaseExpert):
    """
    Expert module for analyzing SQL script syntactic structure.

    Provides:
    1. Nesting depth analysis for all subqueries
    2. Parent-child relationship tracking
    3. Script decomposition into logical subscripts
    4. Dependency graph between subscripts
    5. Complexity scoring per subscript and overall
    """

    def __init__(self, dialect: str = "teradata"):
        super().__init__(dialect)
        self._subscript_counter = 0
        self._result: Optional[StructureAnalysisResult] = None

    def analyze(self, sql: str, **kwargs) -> ExpertOutput:
        """
        Perform complete structure analysis on SQL script.
        """
        if not self.validate_input(sql):
            return self._create_error_output("Invalid or empty SQL input")

        try:
            ast = sqlglot.parse_one(sql, read=self.dialect)
        except Exception as e:
            return self._create_error_output(f"Parse error: {str(e)}")

        self._subscript_counter = 0
        result = StructureAnalysisResult()

        # Step 1: Decompose into subscripts
        subscripts = self._decompose_script(ast, sql)
        result.subscripts = subscripts

        # Build lookup maps
        result.subscript_map = {s.subscript_id: s for s in subscripts}
        result.children_map = self._build_children_map(subscripts)

        # Step 2: Analyze nesting depth
        result.depth_analysis = self._analyze_depth(subscripts)

        # Step 3: Build relationships
        result.relationships = self._build_relationships(subscripts, ast)

        # Step 4: Build dependency graph
        result.dependency_edges = self._build_dependency_graph(subscripts, result.relationships)

        # Step 5: Get execution order
        result.execution_order = self._get_topological_order(subscripts, result.dependency_edges)

        # Step 6: Calculate complexity
        result.complexity_metrics = self._calculate_complexity(subscripts, result.depth_analysis)

        # Step 7: Update individual subscript complexity
        for subscript in subscripts:
            subscript.complexity_score, subscript.complexity_breakdown = \
                self._calculate_subscript_complexity(subscript)

        # Step 8: Find root
        result.root_subscript_id = self._find_root_subscript(subscripts)

        self._result = result

        self._last_output = ExpertOutput(
            expert_name=self.name,
            success=True,
            data=result.to_dict(),
            confidence=self._calculate_confidence(result),
            metadata={
                "subscript_count": len(subscripts),
                "max_depth": result.depth_analysis.max_depth if result.depth_analysis else 0,
                "complexity_score": result.complexity_metrics.overall_score if result.complexity_metrics else 0
            }
        )

        return self._last_output

    def get_confidence(self) -> float:
        if self._last_output:
            return self._last_output.confidence
        return 0.0

    def get_result(self) -> Optional[StructureAnalysisResult]:
        """Get the full structure analysis result."""
        return self._result

    def _generate_id(self, prefix: str = "sub") -> str:
        """Generate unique subscript ID."""
        self._subscript_counter += 1
        return f"{prefix}_{self._subscript_counter:03d}"

    def _decompose_script(self, ast: exp.Expression, sql: str) -> List[Subscript]:
        """Decompose SQL into subscripts."""
        subscripts = []

        # Extract CTEs
        cte_subscripts = self._extract_ctes(ast)
        subscripts.extend(cte_subscripts)

        # Create main query subscript
        main_subscript = self._create_main_query_subscript(ast)
        subscripts.append(main_subscript)

        # Find all subqueries
        subquery_subscripts = self._extract_subqueries(ast, main_subscript, depth=1)
        subscripts.extend(subquery_subscripts)

        return subscripts

    def _extract_ctes(self, ast: exp.Expression) -> List[Subscript]:
        """Extract all CTEs as subscripts."""
        subscripts = []
        with_clause = ast.find(exp.With)

        if not with_clause:
            return subscripts

        for cte_expr in with_clause.expressions:
            cte_name = cte_expr.alias
            cte_body = cte_expr.this

            # Check for recursive CTE
            is_recursive = self._is_recursive_cte(cte_body, cte_name)

            subscript = Subscript(
                subscript_id=self._generate_id("cte"),
                subscript_type=SubscriptType.CTE,
                name=cte_name,
                sql_text=cte_body.sql(dialect=self.dialect),
                nesting_depth=0,
                source_tables=self._extract_tables(cte_body),
                output_columns=self._extract_output_columns(cte_body),
                context="WITH",
                has_aggregation=self._has_aggregation(cte_body),
                has_window_functions=self._has_window_functions(cte_body),
                has_case_statements=self._has_case_statements(cte_body),
                join_count=self._count_joins(cte_body)
            )

            subscripts.append(subscript)

        return subscripts

    def _create_main_query_subscript(self, ast: exp.Expression) -> Subscript:
        """Create subscript for the main query."""
        # Get the main SELECT (after WITH clause)
        main_select = None
        if isinstance(ast, (exp.Insert, exp.Create)):
            main_select = ast.find(exp.Select)
        elif isinstance(ast, exp.Select):
            main_select = ast
        else:
            main_select = ast

        target_table = self._get_target_table(ast)

        return Subscript(
            subscript_id=self._generate_id("main"),
            subscript_type=SubscriptType.MAIN_QUERY,
            name=target_table or "main_query",
            sql_text=main_select.sql(dialect=self.dialect) if main_select else "",
            nesting_depth=0,
            source_tables=self._extract_tables(main_select) if main_select else [],
            output_columns=self._extract_output_columns(main_select) if main_select else [],
            context="MAIN",
            has_aggregation=self._has_aggregation(main_select) if main_select else False,
            has_window_functions=self._has_window_functions(main_select) if main_select else False,
            has_case_statements=self._has_case_statements(main_select) if main_select else False,
            join_count=self._count_joins(main_select) if main_select else 0
        )

    def _extract_subqueries(self, ast: exp.Expression, parent: Subscript,
                            depth: int) -> List[Subscript]:
        """Recursively extract subqueries."""
        subscripts = []

        for subquery in ast.find_all(exp.Subquery):
            # Skip if already at this level (avoid double counting)
            if self._get_subquery_depth(subquery, ast) != depth:
                continue

            context = self._determine_subquery_context(subquery)
            is_correlated, correlation_cols = self._check_correlation(subquery, parent)
            subtype = self._determine_subquery_type(context, is_correlated)

            subscript = Subscript(
                subscript_id=self._generate_id("subq"),
                subscript_type=subtype,
                name=subquery.alias if hasattr(subquery, 'alias') and subquery.alias else None,
                sql_text=subquery.this.sql(dialect=self.dialect),
                nesting_depth=depth,
                parent_id=parent.subscript_id,
                source_tables=self._extract_tables(subquery.this),
                output_columns=self._extract_output_columns(subquery.this),
                is_correlated=is_correlated,
                correlation_columns=correlation_cols,
                context=context,
                has_aggregation=self._has_aggregation(subquery.this),
                has_window_functions=self._has_window_functions(subquery.this),
                has_case_statements=self._has_case_statements(subquery.this),
                join_count=self._count_joins(subquery.this)
            )

            parent.child_ids.append(subscript.subscript_id)
            subscripts.append(subscript)

            # Recurse for nested subqueries
            nested = self._extract_subqueries(subquery.this, subscript, depth + 1)
            subscripts.extend(nested)

        return subscripts

    def _determine_subquery_context(self, subquery: exp.Subquery) -> str:
        """Determine where subquery appears."""
        parent = subquery.parent
        while parent:
            if isinstance(parent, exp.From):
                return "FROM"
            if isinstance(parent, exp.Where):
                return "WHERE"
            if isinstance(parent, exp.Having):
                return "HAVING"
            if isinstance(parent, exp.Exists):
                return "EXISTS"
            if isinstance(parent, exp.In):
                return "IN"
            if isinstance(parent, exp.Select):
                return "SELECT"
            parent = parent.parent
        return "UNKNOWN"

    def _determine_subquery_type(self, context: str, is_correlated: bool) -> SubscriptType:
        """Map context and correlation to SubscriptType."""
        if is_correlated:
            return SubscriptType.CORRELATED_SUBQUERY

        type_map = {
            "SELECT": SubscriptType.SCALAR_SUBQUERY,
            "FROM": SubscriptType.TABLE_SUBQUERY,
            "WHERE": SubscriptType.PREDICATE_SUBQUERY,
            "IN": SubscriptType.PREDICATE_SUBQUERY,
            "EXISTS": SubscriptType.PREDICATE_SUBQUERY,
            "HAVING": SubscriptType.PREDICATE_SUBQUERY,
        }
        return type_map.get(context, SubscriptType.PREDICATE_SUBQUERY)

    def _check_correlation(self, subquery: exp.Subquery,
                           parent: Subscript) -> Tuple[bool, List[str]]:
        """Check if subquery is correlated with parent."""
        parent_tables = set(t.upper() for t in parent.source_tables)
        subquery_tables = set(t.name.upper() for t in subquery.this.find_all(exp.Table))

        correlation_columns = []

        for col in subquery.this.find_all(exp.Column):
            if col.table:
                table_upper = col.table.upper()
                if table_upper in parent_tables and table_upper not in subquery_tables:
                    correlation_columns.append(f"{col.table}.{col.name}")

        return len(correlation_columns) > 0, correlation_columns

    def _extract_tables(self, expr: exp.Expression) -> List[str]:
        """Extract table names from expression."""
        if expr is None:
            return []
        tables = []
        for table in expr.find_all(exp.Table):
            tables.append(table.name)
        return list(set(tables))

    def _extract_output_columns(self, expr: exp.Expression) -> List[str]:
        """Extract output column names."""
        if expr is None:
            return []
        columns = []
        select = expr.find(exp.Select) if not isinstance(expr, exp.Select) else expr
        if select:
            for i, e in enumerate(select.expressions):
                if hasattr(e, 'alias') and e.alias:
                    columns.append(e.alias)
                elif isinstance(e, exp.Column):
                    columns.append(e.name)
                else:
                    columns.append(f"col_{i+1}")
        return columns

    def _get_target_table(self, ast: exp.Expression) -> Optional[str]:
        """Get target table name from INSERT or CREATE."""
        if isinstance(ast, exp.Insert):
            return ast.this.name if ast.this else None
        if isinstance(ast, exp.Create):
            return ast.this.this.name if ast.this else None
        return None

    def _is_recursive_cte(self, cte_body: exp.Expression, cte_name: str) -> bool:
        """Check if CTE is recursive."""
        if isinstance(cte_body, exp.Union):
            for table in cte_body.find_all(exp.Table):
                if table.name.upper() == cte_name.upper():
                    return True
        return False

    def _get_subquery_depth(self, subquery: exp.Subquery, root: exp.Expression) -> int:
        """Calculate nesting depth of a subquery."""
        depth = 0
        current = subquery.parent
        while current and current is not root:
            if isinstance(current, exp.Subquery):
                depth += 1
            current = current.parent
        return depth

    def _has_aggregation(self, expr: exp.Expression) -> bool:
        """Check if expression has aggregate functions."""
        if expr is None:
            return False
        agg_types = (exp.Sum, exp.Count, exp.Avg, exp.Min, exp.Max)
        return any(expr.find_all(t) for t in agg_types)

    def _has_window_functions(self, expr: exp.Expression) -> bool:
        """Check if expression has window functions."""
        if expr is None:
            return False
        return bool(list(expr.find_all(exp.Window)))

    def _has_case_statements(self, expr: exp.Expression) -> bool:
        """Check if expression has CASE statements."""
        if expr is None:
            return False
        return bool(list(expr.find_all(exp.Case)))

    def _count_joins(self, expr: exp.Expression) -> int:
        """Count number of JOINs."""
        if expr is None:
            return 0
        return len(list(expr.find_all(exp.Join)))

    def _build_children_map(self, subscripts: List[Subscript]) -> Dict[str, List[str]]:
        """Build parent -> children mapping."""
        children_map = {}
        for subscript in subscripts:
            if subscript.parent_id:
                if subscript.parent_id not in children_map:
                    children_map[subscript.parent_id] = []
                children_map[subscript.parent_id].append(subscript.subscript_id)
        return children_map

    def _analyze_depth(self, subscripts: List[Subscript]) -> DepthAnalysisResult:
        """Analyze nesting depth distribution."""
        if not subscripts:
            return DepthAnalysisResult(max_depth=0, depth_distribution={}, deepest_subscripts=[])

        max_depth = max(s.nesting_depth for s in subscripts)
        depth_distribution = {}
        for s in subscripts:
            depth_distribution[s.nesting_depth] = depth_distribution.get(s.nesting_depth, 0) + 1

        deepest = [s.subscript_id for s in subscripts if s.nesting_depth == max_depth]

        return DepthAnalysisResult(
            max_depth=max_depth,
            depth_distribution=depth_distribution,
            deepest_subscripts=deepest
        )

    def _build_relationships(self, subscripts: List[Subscript],
                             ast: exp.Expression) -> List[SubscriptRelationship]:
        """Build relationships between subscripts."""
        relationships = []
        subscript_map = {s.subscript_id: s for s in subscripts}
        cte_names = {s.name.upper(): s.subscript_id for s in subscripts
                     if s.subscript_type == SubscriptType.CTE and s.name}

        for subscript in subscripts:
            # Parent-child containment
            if subscript.parent_id:
                relationships.append(SubscriptRelationship(
                    source_id=subscript.parent_id,
                    target_id=subscript.subscript_id,
                    relationship_type=RelationshipType.CONTAINS,
                    description=f"Contains nested subquery"
                ))

            # CTE references
            for ref_cte in subscript.source_tables:
                if ref_cte.upper() in cte_names:
                    cte_id = cte_names[ref_cte.upper()]
                    if cte_id != subscript.subscript_id:
                        relationships.append(SubscriptRelationship(
                            source_id=subscript.subscript_id,
                            target_id=cte_id,
                            relationship_type=RelationshipType.REFERENCES,
                            description=f"References CTE {ref_cte}"
                        ))

            # Correlation relationships
            if subscript.is_correlated and subscript.parent_id:
                relationships.append(SubscriptRelationship(
                    source_id=subscript.subscript_id,
                    target_id=subscript.parent_id,
                    relationship_type=RelationshipType.CORRELATES,
                    description="Correlated subquery",
                    correlation_columns=subscript.correlation_columns
                ))

        return relationships

    def _build_dependency_graph(self, subscripts: List[Subscript],
                                relationships: List[SubscriptRelationship]) -> List[DependencyEdge]:
        """Build dependency edges."""
        edges = []

        for rel in relationships:
            if rel.relationship_type == RelationshipType.REFERENCES:
                edges.append(DependencyEdge(
                    from_subscript=rel.target_id,
                    to_subscript=rel.source_id,
                    dependency_type="data"
                ))
            elif rel.relationship_type == RelationshipType.CONTAINS:
                edges.append(DependencyEdge(
                    from_subscript=rel.source_id,
                    to_subscript=rel.target_id,
                    dependency_type="execution_order"
                ))

        return edges

    def _get_topological_order(self, subscripts: List[Subscript],
                               edges: List[DependencyEdge]) -> List[str]:
        """Get topological order of subscripts."""
        # Build adjacency list
        adj = {s.subscript_id: [] for s in subscripts}
        in_degree = {s.subscript_id: 0 for s in subscripts}

        for edge in edges:
            if edge.dependency_type == "data":
                adj[edge.from_subscript].append(edge.to_subscript)
                in_degree[edge.to_subscript] += 1

        # Kahn's algorithm
        queue = [s for s in in_degree if in_degree[s] == 0]
        order = []

        while queue:
            node = queue.pop(0)
            order.append(node)
            for neighbor in adj[node]:
                in_degree[neighbor] -= 1
                if in_degree[neighbor] == 0:
                    queue.append(neighbor)

        return order

    def _calculate_complexity(self, subscripts: List[Subscript],
                              depth_analysis: DepthAnalysisResult) -> ComplexityMetrics:
        """Calculate overall complexity metrics."""
        subquery_count = sum(1 for s in subscripts if "SUBQUERY" in s.subscript_type.value)
        cte_count = sum(1 for s in subscripts if s.subscript_type == SubscriptType.CTE)
        total_joins = sum(s.join_count for s in subscripts)
        has_recursive = any(s.subscript_type in [SubscriptType.RECURSIVE_ANCHOR,
                                                  SubscriptType.RECURSIVE_MEMBER] for s in subscripts)
        has_correlated = any(s.is_correlated for s in subscripts)

        # Calculate component scores (0-100)
        structural = min(100,
            depth_analysis.max_depth * 15 +
            len(subscripts) * 5 +
            subquery_count * 8
        )

        logical = min(100,
            sum(1 for s in subscripts if s.has_case_statements) * 10 +
            (20 if has_recursive else 0) +
            (15 if has_correlated else 0) +
            cte_count * 5
        )

        data = min(100,
            total_joins * 8 +
            sum(len(s.source_tables) for s in subscripts) * 3 +
            sum(1 for s in subscripts if s.has_aggregation) * 5 +
            sum(1 for s in subscripts if s.has_window_functions) * 7
        )

        overall = structural * 0.4 + logical * 0.3 + data * 0.3

        # Cyclomatic complexity
        cyclomatic = 1 + sum(1 for s in subscripts if s.has_case_statements) * 2

        return ComplexityMetrics(
            overall_score=round(overall, 1),
            subscript_count=len(subscripts),
            max_nesting_depth=depth_analysis.max_depth,
            total_joins=total_joins,
            total_subqueries=subquery_count,
            total_ctes=cte_count,
            has_recursive_cte=has_recursive,
            has_correlated_subqueries=has_correlated,
            cyclomatic_complexity=cyclomatic,
            structural_complexity=round(structural, 1),
            logical_complexity=round(logical, 1),
            data_complexity=round(data, 1)
        )

    def _calculate_subscript_complexity(self, subscript: Subscript) -> Tuple[float, Dict[str, float]]:
        """Calculate complexity for a single subscript."""
        breakdown = {}

        breakdown["depth_penalty"] = subscript.nesting_depth * 10.0
        breakdown["children"] = len(subscript.child_ids) * 2.0
        breakdown["case"] = 3.0 if subscript.has_case_statements else 0
        breakdown["correlation"] = 8.0 if subscript.is_correlated else 0
        breakdown["tables"] = len(subscript.source_tables) * 1.5
        breakdown["joins"] = subscript.join_count * 4.0
        breakdown["aggregation"] = 2.0 if subscript.has_aggregation else 0
        breakdown["window"] = 4.0 if subscript.has_window_functions else 0

        total = sum(breakdown.values())
        return total, breakdown

    def _find_root_subscript(self, subscripts: List[Subscript]) -> Optional[str]:
        """Find the root subscript."""
        for subscript in subscripts:
            if subscript.parent_id is None and subscript.subscript_type == SubscriptType.MAIN_QUERY:
                return subscript.subscript_id

        for subscript in subscripts:
            if subscript.parent_id is None:
                return subscript.subscript_id

        return None

    def _calculate_confidence(self, result: StructureAnalysisResult) -> float:
        """Calculate confidence score for the analysis."""
        confidence = 1.0

        # Reduce confidence if there are warnings
        confidence -= len(result.analysis_warnings) * 0.05

        # Reduce confidence for very complex structures
        if result.complexity_metrics and result.complexity_metrics.overall_score > 80:
            confidence -= 0.1

        return max(0.5, min(1.0, confidence))
