"""
Data models for OperatorLogicExpert - conditions, operators, logic trees.
"""

from dataclasses import dataclass, field
from typing import List, Dict, Optional, Any, Union
from enum import Enum


class ConditionType(Enum):
    """Classification of SQL condition types."""
    WHERE_FILTER = "WHERE_FILTER"
    JOIN_ASSOCIATION = "JOIN_ASSOCIATION"
    GROUP_BY_GROUPING = "GROUP_BY_GROUPING"
    HAVING_AGGREGATE = "HAVING_AGGREGATE"
    QUALIFY_WINDOW = "QUALIFY_WINDOW"
    ORDER_BY_SORT = "ORDER_BY_SORT"


class ComparisonOperator(Enum):
    """Comparison operators."""
    EQ = "="
    NEQ = "<>"
    GT = ">"
    GTE = ">="
    LT = "<"
    LTE = "<="
    LIKE = "LIKE"
    ILIKE = "ILIKE"
    IN = "IN"
    NOT_IN = "NOT IN"
    BETWEEN = "BETWEEN"
    IS_NULL = "IS NULL"
    IS_NOT_NULL = "IS NOT NULL"
    EXISTS = "EXISTS"
    NOT_EXISTS = "NOT EXISTS"
    REGEXP = "REGEXP"


class LogicalOperator(Enum):
    """Logical operators for combining conditions."""
    AND = "AND"
    OR = "OR"
    NOT = "NOT"


class LogicNodeType(Enum):
    """Type of node in the boolean logic tree."""
    AND = "AND"
    OR = "OR"
    NOT = "NOT"
    LEAF = "LEAF"


@dataclass
class OperatorMetadata:
    """Metadata about an operator in a condition."""
    operator_type: Union[ComparisonOperator, LogicalOperator]
    operator_symbol: str
    is_negated: bool = False
    function_context: Optional[str] = None
    position: int = 0


@dataclass
class ConditionColumn:
    """Column reference within a condition."""
    table_name: str
    column_name: str
    alias: Optional[str] = None
    schema_name: Optional[str] = None
    is_aggregate: bool = False
    is_window_function: bool = False
    function_wrapper: Optional[str] = None

    def qualified_name(self) -> str:
        parts = [p for p in [self.schema_name, self.table_name, self.column_name] if p]
        return ".".join(parts)


@dataclass
class ConditionValue:
    """Value in a condition."""
    value_type: str
    raw_value: str
    data_type: Optional[str] = None
    column_ref: Optional[ConditionColumn] = None
    subquery_sql: Optional[str] = None


@dataclass
class AtomicCondition:
    """A single atomic condition (leaf node in the logic tree)."""
    condition_id: str
    left_operand: ConditionValue
    operator: OperatorMetadata
    right_operand: Optional[ConditionValue] = None
    sql_text: str = ""
    columns_involved: List[ConditionColumn] = field(default_factory=list)
    functions_used: List[str] = field(default_factory=list)
    has_subquery: bool = False
    is_correlated: bool = False

    def to_dict(self) -> dict:
        return {
            "condition_id": self.condition_id,
            "left_operand": self.left_operand.raw_value if self.left_operand else None,
            "operator": self.operator.operator_symbol,
            "right_operand": self.right_operand.raw_value if self.right_operand else None,
            "sql_text": self.sql_text,
            "columns_involved": [c.qualified_name() for c in self.columns_involved],
            "functions_used": self.functions_used,
            "has_subquery": self.has_subquery
        }


@dataclass
class LogicTreeNode:
    """Node in a boolean logic tree."""
    node_type: LogicNodeType
    children: List[Union['LogicTreeNode', AtomicCondition]] = field(default_factory=list)
    atomic_condition: Optional[AtomicCondition] = None
    negated: bool = False

    def is_leaf(self) -> bool:
        return self.node_type == LogicNodeType.LEAF

    def get_all_conditions(self) -> List[AtomicCondition]:
        conditions = []
        if self.is_leaf() and self.atomic_condition:
            conditions.append(self.atomic_condition)
        else:
            for child in self.children:
                if isinstance(child, LogicTreeNode):
                    conditions.extend(child.get_all_conditions())
                elif isinstance(child, AtomicCondition):
                    conditions.append(child)
        return conditions

    def get_all_columns(self) -> List[ConditionColumn]:
        columns = []
        for cond in self.get_all_conditions():
            columns.extend(cond.columns_involved)
        return columns

    def to_dict(self) -> dict:
        result = {
            "node_type": self.node_type.value,
            "negated": self.negated
        }
        if self.is_leaf() and self.atomic_condition:
            result["condition"] = self.atomic_condition.to_dict()
        else:
            result["children"] = [
                c.to_dict() if isinstance(c, (LogicTreeNode, AtomicCondition)) else str(c)
                for c in self.children
            ]
        return result


@dataclass
class WhereClauseAnalysis:
    """Detailed WHERE clause analysis."""
    clause_type: ConditionType
    sql_text: str
    logic_tree: Optional[LogicTreeNode] = None
    columns_involved: List[ConditionColumn] = field(default_factory=list)
    operators_used: List[OperatorMetadata] = field(default_factory=list)
    filter_conditions: List[AtomicCondition] = field(default_factory=list)
    has_subquery: bool = False
    has_correlated_subquery: bool = False
    complexity_score: int = 1
    english_explanation: str = ""

    def to_dict(self) -> dict:
        return {
            "clause_type": self.clause_type.value,
            "sql_text": self.sql_text,
            "logic_tree": self.logic_tree.to_dict() if self.logic_tree else None,
            "columns_involved": [c.qualified_name() for c in self.columns_involved],
            "filter_conditions": [c.to_dict() for c in self.filter_conditions],
            "has_subquery": self.has_subquery,
            "has_correlated_subquery": self.has_correlated_subquery,
            "complexity_score": self.complexity_score,
            "english_explanation": self.english_explanation
        }


@dataclass
class HavingClauseAnalysis:
    """Detailed HAVING clause analysis."""
    clause_type: ConditionType
    sql_text: str
    logic_tree: Optional[LogicTreeNode] = None
    columns_involved: List[ConditionColumn] = field(default_factory=list)
    operators_used: List[OperatorMetadata] = field(default_factory=list)
    aggregate_conditions: List[AtomicCondition] = field(default_factory=list)
    aggregate_functions: List[str] = field(default_factory=list)
    english_explanation: str = ""

    def to_dict(self) -> dict:
        return {
            "clause_type": self.clause_type.value,
            "sql_text": self.sql_text,
            "aggregate_conditions": [c.to_dict() for c in self.aggregate_conditions],
            "aggregate_functions": self.aggregate_functions,
            "english_explanation": self.english_explanation
        }


@dataclass
class QualifyClauseAnalysis:
    """Detailed QUALIFY clause analysis (Teradata/Snowflake)."""
    clause_type: ConditionType
    sql_text: str
    logic_tree: Optional[LogicTreeNode] = None
    columns_involved: List[ConditionColumn] = field(default_factory=list)
    operators_used: List[OperatorMetadata] = field(default_factory=list)
    window_conditions: List[AtomicCondition] = field(default_factory=list)
    window_functions: List[str] = field(default_factory=list)
    english_explanation: str = ""

    def to_dict(self) -> dict:
        return {
            "clause_type": self.clause_type.value,
            "sql_text": self.sql_text,
            "window_conditions": [c.to_dict() for c in self.window_conditions],
            "window_functions": self.window_functions,
            "english_explanation": self.english_explanation
        }


@dataclass
class JoinConditionAnalysis:
    """Detailed JOIN condition analysis."""
    join_id: str
    join_type: str
    left_table: str
    right_table: str
    left_alias: Optional[str] = None
    right_alias: Optional[str] = None
    logic_tree: Optional[LogicTreeNode] = None
    conditions: List[AtomicCondition] = field(default_factory=list)
    columns_left: List[ConditionColumn] = field(default_factory=list)
    columns_right: List[ConditionColumn] = field(default_factory=list)
    operators_used: List[OperatorMetadata] = field(default_factory=list)
    english_explanation: str = ""

    def to_dict(self) -> dict:
        return {
            "join_id": self.join_id,
            "join_type": self.join_type,
            "left_table": self.left_table,
            "right_table": self.right_table,
            "logic_tree": self.logic_tree.to_dict() if self.logic_tree else None,
            "conditions": [c.to_dict() for c in self.conditions],
            "english_explanation": self.english_explanation
        }


@dataclass
class GroupByAnalysis:
    """GROUP BY clause analysis."""
    columns: List[ConditionColumn] = field(default_factory=list)
    expressions: List[str] = field(default_factory=list)
    sql_text: str = ""

    def to_dict(self) -> dict:
        return {
            "columns": [c.qualified_name() for c in self.columns],
            "expressions": self.expressions,
            "sql_text": self.sql_text
        }


@dataclass
class OrderByAnalysis:
    """ORDER BY clause analysis."""
    columns: List[ConditionColumn] = field(default_factory=list)
    directions: List[str] = field(default_factory=list)
    nulls_handling: List[str] = field(default_factory=list)
    sql_text: str = ""

    def to_dict(self) -> dict:
        return {
            "columns": [c.qualified_name() for c in self.columns],
            "directions": self.directions,
            "nulls_handling": self.nulls_handling,
            "sql_text": self.sql_text
        }


@dataclass
class OperatorLogicAnalysis:
    """Complete operator logic analysis for a SQL statement."""
    statement_id: str
    statement_type: str
    where_analysis: Optional[WhereClauseAnalysis] = None
    having_analysis: Optional[HavingClauseAnalysis] = None
    qualify_analysis: Optional[QualifyClauseAnalysis] = None
    join_analyses: List[JoinConditionAnalysis] = field(default_factory=list)
    group_by_analysis: Optional[GroupByAnalysis] = None
    order_by_analysis: Optional[OrderByAnalysis] = None
    all_conditions: List[AtomicCondition] = field(default_factory=list)
    all_columns_by_type: Dict[str, List[ConditionColumn]] = field(default_factory=dict)
    operator_summary: Dict[str, int] = field(default_factory=dict)
    total_conditions: int = 0
    max_nesting_depth: int = 0
    complexity_score: int = 1

    def to_dict(self) -> dict:
        return {
            "statement_id": self.statement_id,
            "statement_type": self.statement_type,
            "where_analysis": self.where_analysis.to_dict() if self.where_analysis else None,
            "having_analysis": self.having_analysis.to_dict() if self.having_analysis else None,
            "qualify_analysis": self.qualify_analysis.to_dict() if self.qualify_analysis else None,
            "join_analyses": [j.to_dict() for j in self.join_analyses],
            "group_by_analysis": self.group_by_analysis.to_dict() if self.group_by_analysis else None,
            "order_by_analysis": self.order_by_analysis.to_dict() if self.order_by_analysis else None,
            "all_conditions": [c.to_dict() for c in self.all_conditions],
            "columns_by_type": {
                k: [c.qualified_name() for c in v]
                for k, v in self.all_columns_by_type.items()
            },
            "operator_summary": self.operator_summary,
            "total_conditions": self.total_conditions,
            "max_nesting_depth": self.max_nesting_depth,
            "complexity_score": self.complexity_score
        }
