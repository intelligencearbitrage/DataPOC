"""Data models for the multi-expert architecture."""

from .expert_result import (
    ExpertType,
    ConflictType,
    ResolutionStrategy,
    ProvenanceRecord,
    ConfidenceScore,
    ConflictRecord,
    IntegratedLineageEdge,
    IntegratedLineageResult,
    ExpertOutput
)

from .structure_models import (
    SubscriptType,
    RelationshipType,
    Subscript,
    SubscriptRelationship,
    StructureAnalysisResult,
    ComplexityMetrics
)

from .condition_models import (
    ConditionType,
    ComparisonOperator,
    LogicalOperator,
    AtomicCondition,
    LogicTreeNode,
    OperatorLogicAnalysis
)

from .field_models import (
    FieldAccessType,
    FieldMappingType,
    FieldAccessPattern,
    FieldMapping,
    FieldTransformationChain,
    FieldMappingResult
)

__all__ = [
    # Expert result models
    "ExpertType", "ConflictType", "ResolutionStrategy",
    "ProvenanceRecord", "ConfidenceScore", "ConflictRecord",
    "IntegratedLineageEdge", "IntegratedLineageResult", "ExpertOutput",
    # Structure models
    "SubscriptType", "RelationshipType", "Subscript",
    "SubscriptRelationship", "StructureAnalysisResult", "ComplexityMetrics",
    # Condition models
    "ConditionType", "ComparisonOperator", "LogicalOperator",
    "AtomicCondition", "LogicTreeNode", "OperatorLogicAnalysis",
    # Field models
    "FieldAccessType", "FieldMappingType", "FieldAccessPattern",
    "FieldMapping", "FieldTransformationChain", "FieldMappingResult",
]
