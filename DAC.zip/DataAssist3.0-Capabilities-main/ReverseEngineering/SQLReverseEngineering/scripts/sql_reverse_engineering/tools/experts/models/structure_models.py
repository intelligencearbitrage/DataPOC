"""
Data models for ScriptStructureParser - subscripts, dependencies, complexity.
"""

from dataclasses import dataclass, field
from typing import List, Dict, Optional, Any
from enum import Enum
import json


class SubscriptType(Enum):
    """Type classification for subscripts."""
    MAIN_QUERY = "MAIN_QUERY"
    CTE = "CTE"
    SCALAR_SUBQUERY = "SCALAR_SUBQUERY"
    TABLE_SUBQUERY = "TABLE_SUBQUERY"
    PREDICATE_SUBQUERY = "PREDICATE_SUBQUERY"
    CORRELATED_SUBQUERY = "CORRELATED_SUBQUERY"
    UNION_MEMBER = "UNION_MEMBER"
    INSERT_SOURCE = "INSERT_SOURCE"
    RECURSIVE_ANCHOR = "RECURSIVE_ANCHOR"
    RECURSIVE_MEMBER = "RECURSIVE_MEMBER"


class RelationshipType(Enum):
    """Type of relationship between subscripts."""
    CONTAINS = "CONTAINS"
    REFERENCES = "REFERENCES"
    PRECEDES = "PRECEDES"
    CORRELATES = "CORRELATES"


@dataclass
class SubscriptLocation:
    """Location information for a subscript."""
    start_position: int
    end_position: int
    start_line: int
    end_line: int
    depth_level: int


@dataclass
class Subscript:
    """Represents a logical unit within a SQL script."""
    subscript_id: str
    subscript_type: SubscriptType
    name: Optional[str] = None
    sql_text: str = ""
    location: Optional[SubscriptLocation] = None
    nesting_depth: int = 0
    parent_id: Optional[str] = None
    child_ids: List[str] = field(default_factory=list)
    source_tables: List[str] = field(default_factory=list)
    output_columns: List[str] = field(default_factory=list)
    referenced_ctes: List[str] = field(default_factory=list)
    is_correlated: bool = False
    correlation_columns: List[str] = field(default_factory=list)
    complexity_score: float = 0.0
    complexity_breakdown: Dict[str, float] = field(default_factory=dict)
    context: str = ""
    has_aggregation: bool = False
    has_window_functions: bool = False
    has_case_statements: bool = False
    join_count: int = 0

    def to_dict(self) -> dict:
        return {
            "subscript_id": self.subscript_id,
            "subscript_type": self.subscript_type.value,
            "name": self.name,
            "sql_text": self.sql_text,
            "location": {
                "start_position": self.location.start_position,
                "end_position": self.location.end_position,
                "start_line": self.location.start_line,
                "end_line": self.location.end_line,
                "depth_level": self.location.depth_level
            } if self.location else None,
            "nesting_depth": self.nesting_depth,
            "parent_id": self.parent_id,
            "child_ids": self.child_ids,
            "source_tables": self.source_tables,
            "output_columns": self.output_columns,
            "referenced_ctes": self.referenced_ctes,
            "is_correlated": self.is_correlated,
            "correlation_columns": self.correlation_columns,
            "complexity_score": self.complexity_score,
            "complexity_breakdown": self.complexity_breakdown,
            "context": self.context,
            "has_aggregation": self.has_aggregation,
            "has_window_functions": self.has_window_functions,
            "has_case_statements": self.has_case_statements,
            "join_count": self.join_count
        }


@dataclass
class SubscriptRelationship:
    """Represents a relationship between two subscripts."""
    source_id: str
    target_id: str
    relationship_type: RelationshipType
    description: str = ""
    correlation_columns: List[str] = field(default_factory=list)

    def to_dict(self) -> dict:
        return {
            "source_id": self.source_id,
            "target_id": self.target_id,
            "relationship_type": self.relationship_type.value,
            "description": self.description,
            "correlation_columns": self.correlation_columns
        }


@dataclass
class DependencyEdge:
    """Edge in the dependency graph."""
    from_subscript: str
    to_subscript: str
    dependency_type: str
    weight: float = 1.0

    def to_dict(self) -> dict:
        return {
            "from": self.from_subscript,
            "to": self.to_subscript,
            "type": self.dependency_type,
            "weight": self.weight
        }


@dataclass
class DepthAnalysisResult:
    """Result of nesting depth analysis."""
    max_depth: int
    depth_distribution: Dict[int, int]
    deepest_subscripts: List[str]

    def to_dict(self) -> dict:
        return {
            "max_depth": self.max_depth,
            "depth_distribution": self.depth_distribution,
            "deepest_subscripts": self.deepest_subscripts
        }


@dataclass
class ComplexityMetrics:
    """Overall complexity metrics for the script."""
    overall_score: float
    subscript_count: int
    max_nesting_depth: int
    total_joins: int
    total_subqueries: int
    total_ctes: int
    has_recursive_cte: bool
    has_correlated_subqueries: bool
    cyclomatic_complexity: int
    structural_complexity: float
    logical_complexity: float
    data_complexity: float

    def to_dict(self) -> dict:
        return {
            "overall_score": self.overall_score,
            "subscript_count": self.subscript_count,
            "max_nesting_depth": self.max_nesting_depth,
            "total_joins": self.total_joins,
            "total_subqueries": self.total_subqueries,
            "total_ctes": self.total_ctes,
            "has_recursive_cte": self.has_recursive_cte,
            "has_correlated_subqueries": self.has_correlated_subqueries,
            "cyclomatic_complexity": self.cyclomatic_complexity,
            "structural_complexity": self.structural_complexity,
            "logical_complexity": self.logical_complexity,
            "data_complexity": self.data_complexity
        }


@dataclass
class StructureAnalysisResult:
    """Complete result of script structure analysis."""
    subscripts: List[Subscript] = field(default_factory=list)
    relationships: List[SubscriptRelationship] = field(default_factory=list)
    dependency_edges: List[DependencyEdge] = field(default_factory=list)
    depth_analysis: Optional[DepthAnalysisResult] = None
    complexity_metrics: Optional[ComplexityMetrics] = None
    root_subscript_id: Optional[str] = None
    execution_order: List[str] = field(default_factory=list)
    subscript_map: Dict[str, Subscript] = field(default_factory=dict)
    children_map: Dict[str, List[str]] = field(default_factory=dict)
    analysis_warnings: List[str] = field(default_factory=list)

    def get_subscript(self, subscript_id: str) -> Optional[Subscript]:
        return self.subscript_map.get(subscript_id)

    def get_children(self, subscript_id: str) -> List[Subscript]:
        child_ids = self.children_map.get(subscript_id, [])
        return [self.subscript_map[cid] for cid in child_ids if cid in self.subscript_map]

    def get_subscripts_at_depth(self, depth: int) -> List[Subscript]:
        return [s for s in self.subscripts if s.nesting_depth == depth]

    def to_dict(self) -> dict:
        return {
            "subscripts": [s.to_dict() for s in self.subscripts],
            "relationships": [r.to_dict() for r in self.relationships],
            "dependency_edges": [e.to_dict() for e in self.dependency_edges],
            "depth_analysis": self.depth_analysis.to_dict() if self.depth_analysis else None,
            "complexity_metrics": self.complexity_metrics.to_dict() if self.complexity_metrics else None,
            "root_subscript_id": self.root_subscript_id,
            "execution_order": self.execution_order,
            "analysis_warnings": self.analysis_warnings
        }

    def to_json(self, indent: int = 2) -> str:
        return json.dumps(self.to_dict(), indent=indent)
