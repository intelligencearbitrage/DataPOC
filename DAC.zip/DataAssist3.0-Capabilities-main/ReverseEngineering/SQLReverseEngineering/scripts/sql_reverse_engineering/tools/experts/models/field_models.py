"""
Data models for FieldMappingExpert - field mappings, transformations, access patterns.
"""

from dataclasses import dataclass, field
from typing import List, Dict, Optional, Any, Union
from enum import Enum
import json


class FieldAccessType(Enum):
    """Type of field access pattern."""
    DIRECT = "DIRECT"
    SUBSCRIPT_INDEX = "SUBSCRIPT_INDEX"
    SUBSCRIPT_KEY = "SUBSCRIPT_KEY"
    DOT_ACCESS = "DOT_ACCESS"
    NESTED = "NESTED"


class FieldMappingType(Enum):
    """Type of field mapping."""
    DIRECT_COLUMN = "DIRECT_COLUMN"
    CALCULATED = "CALCULATED"
    DERIVED = "DERIVED"
    CONSTANT = "CONSTANT"
    AGGREGATED = "AGGREGATED"


@dataclass
class SubscriptAccess:
    """Represents a single subscript/bracket access."""
    access_id: str
    base_expression: str
    index_or_key: Union[int, str]
    is_numeric_index: bool
    position: int
    sql_text: str

    def to_dict(self) -> Dict[str, Any]:
        return {
            "access_id": self.access_id,
            "base_expression": self.base_expression,
            "index_or_key": self.index_or_key,
            "is_numeric_index": self.is_numeric_index,
            "position": self.position,
            "sql_text": self.sql_text
        }


@dataclass
class CompositeFieldAccess:
    """Represents composite type field access (struct.field)."""
    access_id: str
    base_type: str
    field_path: List[str]
    is_nested: bool
    sql_text: str

    def to_dict(self) -> Dict[str, Any]:
        return {
            "access_id": self.access_id,
            "base_type": self.base_type,
            "field_path": self.field_path,
            "is_nested": self.is_nested,
            "sql_text": self.sql_text
        }


@dataclass
class FieldAccessPattern:
    """Complete field access pattern."""
    pattern_id: str
    original_expression: str
    access_type: FieldAccessType
    subscript_accesses: List[SubscriptAccess] = field(default_factory=list)
    composite_accesses: List[CompositeFieldAccess] = field(default_factory=list)
    resolved_source_column: Optional[str] = None
    resolved_source_table: Optional[str] = None

    def to_dict(self) -> Dict[str, Any]:
        return {
            "pattern_id": self.pattern_id,
            "original_expression": self.original_expression,
            "access_type": self.access_type.value,
            "subscript_accesses": [s.to_dict() for s in self.subscript_accesses],
            "composite_accesses": [c.to_dict() for c in self.composite_accesses],
            "resolved_source_column": self.resolved_source_column,
            "resolved_source_table": self.resolved_source_table
        }


@dataclass
class FieldMapping:
    """Single field mapping from source to target."""
    mapping_id: str
    mapping_type: FieldMappingType
    target_field: str
    target_alias: Optional[str] = None
    source_expression: str = ""
    source_fields: List[str] = field(default_factory=list)
    source_tables: List[str] = field(default_factory=list)
    access_patterns: List[FieldAccessPattern] = field(default_factory=list)
    transformation_sql: str = ""
    transformation_description: str = ""
    subscript_context: Optional[str] = None
    is_calculated: bool = False
    calculation_components: List[str] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "mapping_id": self.mapping_id,
            "mapping_type": self.mapping_type.value,
            "target_field": self.target_field,
            "target_alias": self.target_alias,
            "source_expression": self.source_expression,
            "source_fields": self.source_fields,
            "source_tables": self.source_tables,
            "access_patterns": [a.to_dict() for a in self.access_patterns],
            "transformation_sql": self.transformation_sql,
            "transformation_description": self.transformation_description,
            "subscript_context": self.subscript_context,
            "is_calculated": self.is_calculated,
            "calculation_components": self.calculation_components
        }


@dataclass
class TransformationStep:
    """Single step in a field transformation chain."""
    step_id: str
    step_number: int
    input_fields: List[str]
    output_field: str
    transformation_type: str
    transformation_sql: str
    subscript_name: Optional[str] = None

    def to_dict(self) -> Dict[str, Any]:
        return {
            "step_id": self.step_id,
            "step_number": self.step_number,
            "input_fields": self.input_fields,
            "output_field": self.output_field,
            "transformation_type": self.transformation_type,
            "transformation_sql": self.transformation_sql,
            "subscript_name": self.subscript_name
        }


@dataclass
class FieldTransformationChain:
    """Complete transformation chain for a field."""
    chain_id: str
    target_table: str
    target_field: str
    ultimate_sources: List[Dict[str, str]]
    steps: List[TransformationStep] = field(default_factory=list)
    total_hops: int = 0
    involves_aggregation: bool = False
    involves_subscript_access: bool = False
    involves_composite_access: bool = False

    def to_dict(self) -> Dict[str, Any]:
        return {
            "chain_id": self.chain_id,
            "target_table": self.target_table,
            "target_field": self.target_field,
            "ultimate_sources": self.ultimate_sources,
            "steps": [s.to_dict() for s in self.steps],
            "total_hops": self.total_hops,
            "involves_aggregation": self.involves_aggregation,
            "involves_subscript_access": self.involves_subscript_access,
            "involves_composite_access": self.involves_composite_access
        }


@dataclass
class FieldAliasChain:
    """Tracks alias resolution chain for a field."""
    final_alias: str
    alias_chain: List[Dict[str, str]]
    original_source: str
    original_table: Optional[str] = None

    def to_dict(self) -> Dict[str, Any]:
        return {
            "final_alias": self.final_alias,
            "alias_chain": self.alias_chain,
            "original_source": self.original_source,
            "original_table": self.original_table
        }


@dataclass
class SubscriptFieldAnalysis:
    """Analysis of fields within a single subscript."""
    subscript_name: str
    subscript_type: str
    input_fields: List[FieldMapping] = field(default_factory=list)
    output_fields: List[FieldMapping] = field(default_factory=list)
    internal_transformations: List[str] = field(default_factory=list)
    dependencies: List[str] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "subscript_name": self.subscript_name,
            "subscript_type": self.subscript_type,
            "input_fields": [f.to_dict() for f in self.input_fields],
            "output_fields": [f.to_dict() for f in self.output_fields],
            "internal_transformations": self.internal_transformations,
            "dependencies": self.dependencies
        }


@dataclass
class ParameterVariation:
    """Tracks how a parameter varies across subscripts."""
    parameter_name: str
    variations: List[Dict[str, Any]]
    is_consistent: bool
    default_value: Optional[str] = None

    def to_dict(self) -> Dict[str, Any]:
        return {
            "parameter_name": self.parameter_name,
            "variations": self.variations,
            "is_consistent": self.is_consistent,
            "default_value": self.default_value
        }


@dataclass
class FieldMappingResult:
    """Complete result from FieldMappingExpert analysis."""
    analysis_id: str
    source_sql: str
    target_table: Optional[str] = None
    field_mappings: List[FieldMapping] = field(default_factory=list)
    transformation_chains: List[FieldTransformationChain] = field(default_factory=list)
    subscript_analyses: List[SubscriptFieldAnalysis] = field(default_factory=list)
    alias_chains: List[FieldAliasChain] = field(default_factory=list)
    parameter_variations: List[ParameterVariation] = field(default_factory=list)
    access_patterns: List[FieldAccessPattern] = field(default_factory=list)
    metadata: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "analysis_id": self.analysis_id,
            "source_sql": self.source_sql,
            "target_table": self.target_table,
            "field_mappings": [m.to_dict() for m in self.field_mappings],
            "transformation_chains": [c.to_dict() for c in self.transformation_chains],
            "subscript_analyses": [s.to_dict() for s in self.subscript_analyses],
            "alias_chains": [a.to_dict() for a in self.alias_chains],
            "parameter_variations": [p.to_dict() for p in self.parameter_variations],
            "access_patterns": [a.to_dict() for a in self.access_patterns],
            "metadata": self.metadata
        }

    def to_json(self, indent: int = 2) -> str:
        return json.dumps(self.to_dict(), indent=indent)

    def get_mappings_by_target(self, target_field: str) -> List[FieldMapping]:
        return [m for m in self.field_mappings if m.target_field == target_field]

    def get_chain_for_field(self, target_field: str) -> Optional[FieldTransformationChain]:
        for chain in self.transformation_chains:
            if chain.target_field == target_field:
                return chain
        return None

    def get_fields_with_array_access(self) -> List[FieldMapping]:
        return [
            m for m in self.field_mappings
            if any(
                ap.access_type in [FieldAccessType.SUBSCRIPT_INDEX,
                                   FieldAccessType.SUBSCRIPT_KEY,
                                   FieldAccessType.NESTED]
                for ap in m.access_patterns
            )
        ]
