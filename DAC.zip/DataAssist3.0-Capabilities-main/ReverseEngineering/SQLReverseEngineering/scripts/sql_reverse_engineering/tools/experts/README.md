# Experts

## Overview
The Experts module provides specialized analysis capabilities using a multi-expert architecture. Each expert focuses on a specific aspect of SQL analysis, and they collaborate to produce comprehensive results.

## Components

### `base_expert.py`
Abstract base class for all expert modules.

**Base Interface:**
```python
class BaseExpert(ABC):
    @abstractmethod
    def analyze(self, sql: str, **kwargs) -> ExpertOutput:
        pass
```

**Provides:**
- Standard interface for all experts
- Common output structure (`ExpertOutput`)
- Error handling framework
- Confidence scoring

### `script_structure_parser.py`
Expert for analyzing SQL script structure and organization.

**Analysis Capabilities:**
- Script decomposition
- Statement identification and classification
- Dependency detection
- Execution order analysis
- Block structure recognition

**Identifies:**
- DDL statements (CREATE, ALTER, DROP)
- DML statements (INSERT, UPDATE, DELETE, MERGE)
- DQL statements (SELECT)
- Stored procedures and functions
- Control flow statements
- Comments and documentation

**Output:**
```python
{
    "statements": [...],
    "structure": {
        "total_statements": 10,
        "ddl_count": 2,
        "dml_count": 5,
        "procedures": 1
    },
    "dependencies": [...],
    "execution_order": [...]
}
```

### `field_mapping_expert.py`
Expert for field-level lineage and transformation mapping.

**Analysis Capabilities:**
- Column-to-column mapping
- Source-to-target field relationships
- Transformation identification
- Data type mapping
- Business rule extraction

**Tracks:**
- Direct column mappings
- Transformation functions
- Aggregations
- CASE logic
- Complex expressions

**Output:**
```python
{
    "mappings": [
        {
            "source": "table1.col1",
            "target": "table2.col2",
            "transformation": "UPPER(col1)",
            "type": "string_manipulation"
        }
    ],
    "unmapped_sources": [...],
    "unmapped_targets": [...]
}
```

### `operator_logic_expert.py`
Expert for analyzing conditional logic and operators.

**Analysis Capabilities:**
- WHERE clause analysis
- JOIN condition analysis
- CASE expression analysis
- Boolean logic evaluation
- Operator precedence

**Analyzes:**
- Comparison operators (=, <>, <, >, <=, >=)
- Logical operators (AND, OR, NOT)
- Set operators (IN, NOT IN, EXISTS)
- Pattern matching (LIKE, REGEX)
- NULL handling (IS NULL, COALESCE)

**Output:**
```python
{
    "conditions": [
        {
            "expression": "status = 'ACTIVE'",
            "type": "comparison",
            "operator": "=",
            "left": "status",
            "right": "'ACTIVE'"
        }
    ],
    "complexity_score": 3.5,
    "boolean_logic": [...]
}
```

### `integration_expert.py`
Expert for orchestrating and combining results from other experts.

**Responsibilities:**
- Coordinate multiple experts
- Merge expert outputs
- Resolve conflicts
- Produce unified results
- Calculate overall confidence

**Integration Tasks:**
- Call experts in optimal order
- Pass context between experts
- Aggregate results
- Handle dependencies
- Error recovery

**Output:**
```python
{
    "combined_results": {...},
    "expert_contributions": {
        "script_structure": {...},
        "field_mapping": {...},
        "operator_logic": {...}
    },
    "confidence": 0.85,
    "conflicts_resolved": [...]
}
```

### `enhanced_code_reviewer.py`
Expert for SQL code quality and best practices review.

**Review Capabilities:**
- Code quality assessment
- Anti-pattern detection
- Performance optimization suggestions
- Best practice validation
- Style consistency checking

**Checks:**
- SELECT * usage
- Missing indexes
- Inefficient joins
- N+1 query patterns
- Transaction handling
- Error handling
- Naming conventions
- Code formatting

**Output:**
```python
{
    "issues": [
        {
            "type": "anti_pattern",
            "severity": "warning",
            "line": 5,
            "message": "SELECT * detected",
            "suggestion": "Specify explicit columns"
        }
    ],
    "quality_score": 7.5,
    "performance_issues": [...],
    "best_practices": [...]
}
```

### `models/`
Data models used by experts.

#### `expert_result.py`
Standard result structure for expert outputs.

#### `field_models.py`
Models for field mapping and lineage.

**Models:**
- `FieldMapping` - Source to target field mapping
- `TransformationInfo` - Transformation details

#### `condition_models.py`
Models for conditional logic.

**Models:**
- `Condition` - Single condition
- `LogicTree` - Boolean logic tree

#### `structure_models.py`
Models for script structure.

**Models:**
- `Statement` - SQL statement
- `CodeBlock` - Block of related statements
- `Dependency` - Dependency between statements

## Multi-Expert Architecture

### Collaboration Pattern
```
┌──────────────────────────────────────────────────┐
│          Integration Expert (Orchestrator)        │
└──────┬──────────┬──────────┬────────────────────┘
       │          │          │
       ▼          ▼          ▼
┌──────────┐ ┌──────────┐ ┌──────────┐
│ Script   │ │  Field   │ │ Operator │
│Structure │ │ Mapping  │ │  Logic   │
│  Expert  │ │  Expert  │ │  Expert  │
└──────────┘ └──────────┘ └──────────┘
```

### Expert Interaction
1. Integration Expert coordinates analysis
2. Experts run in parallel where possible
3. Results are merged and conflicts resolved
4. Final output combines all expert insights

## Usage Example

```python
from experts.integration_expert import IntegrationExpert

# Initialize integration expert
expert = IntegrationExpert(dialect="teradata")

# Analyze SQL
sql = """
SELECT 
    t1.customer_id,
    t1.customer_name,
    COUNT(t2.order_id) as order_count
FROM customers t1
LEFT JOIN orders t2 ON t1.customer_id = t2.customer_id
WHERE t1.status = 'ACTIVE'
GROUP BY t1.customer_id, t1.customer_name
"""

result = expert.analyze(sql)

# Access results
print(f"Success: {result.success}")
print(f"Confidence: {result.confidence}")
print(f"Structure: {result.data['structure']}")
print(f"Mappings: {result.data['mappings']}")
```

## Output Structure

All experts return `ExpertOutput`:
```python
ExpertOutput(
    expert_name="FieldMappingExpert",
    success=True,
    data={...},
    confidence=0.9,
    errors=[],
    warnings=[],
    metadata={}
)
```

## Integration Points
- Inputs: SQL text, AST, schema information
- Used by: Agent interface, CLI, API
- Outputs: ExpertOutput with specialized analysis
- Coordinates with: Other experts via IntegrationExpert
