"""
Core data models for expert results, conflict resolution, and provenance tracking.
"""

from dataclasses import dataclass, field
from typing import List, Dict, Optional, Any
from enum import Enum
from datetime import datetime


class ExpertType(Enum):
    """Types of experts in the system."""
    SCRIPT_STRUCTURE = "SCRIPT_STRUCTURE"
    FIELD_MAPPING = "FIELD_MAPPING"
    OPERATOR_LOGIC = "OPERATOR_LOGIC"
    INTEGRATION = "INTEGRATION"
    CODE_REVIEWER = "CODE_REVIEWER"


class ConflictType(Enum):
    """Types of conflicts between expert outputs."""
    SOURCE_COLUMN_MISMATCH = "SOURCE_COLUMN_MISMATCH"
    TRANSFORMATION_DISAGREEMENT = "TRANSFORMATION_DISAGREEMENT"
    TABLE_NAME_AMBIGUITY = "TABLE_NAME_AMBIGUITY"
    LINEAGE_PATH_CONFLICT = "LINEAGE_PATH_CONFLICT"
    OPERATOR_INTERPRETATION = "OPERATOR_INTERPRETATION"


class ResolutionStrategy(Enum):
    """Strategies for resolving conflicts."""
    MAJORITY_VOTE = "MAJORITY_VOTE"
    HIGHEST_CONFIDENCE = "HIGHEST_CONFIDENCE"
    EXPERT_PRIORITY = "EXPERT_PRIORITY"
    UNION_ALL = "UNION_ALL"
    INTERSECTION = "INTERSECTION"
    MANUAL_REVIEW = "MANUAL_REVIEW"


@dataclass
class ExpertOutput:
    """Base output structure for all experts."""
    expert_name: str
    success: bool
    data: Dict[str, Any] = field(default_factory=dict)
    confidence: float = 1.0
    errors: List[str] = field(default_factory=list)
    warnings: List[str] = field(default_factory=list)
    metadata: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "expert_name": self.expert_name,
            "success": self.success,
            "data": self.data,
            "confidence": self.confidence,
            "errors": self.errors,
            "warnings": self.warnings,
            "metadata": self.metadata
        }


@dataclass
class ProvenanceRecord:
    """Tracks which expert contributed what information."""
    expert_type: ExpertType
    expert_name: str
    contribution_type: str
    contributed_data: Dict[str, Any]
    confidence: float
    timestamp: str = field(default_factory=lambda: datetime.now().isoformat())
    metadata: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "expert_type": self.expert_type.value,
            "expert_name": self.expert_name,
            "contribution_type": self.contribution_type,
            "contributed_data": self.contributed_data,
            "confidence": self.confidence,
            "timestamp": self.timestamp,
            "metadata": self.metadata
        }


@dataclass
class ConfidenceScore:
    """Detailed confidence scoring for lineage results."""
    overall_score: float
    component_scores: Dict[str, float] = field(default_factory=dict)
    factors: List[str] = field(default_factory=list)
    penalties: List[str] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "overall_score": self.overall_score,
            "component_scores": self.component_scores,
            "factors": self.factors,
            "penalties": self.penalties
        }


@dataclass
class ConflictRecord:
    """Records a conflict between expert outputs."""
    conflict_id: str
    conflict_type: ConflictType
    experts_involved: List[ExpertType]
    conflicting_values: Dict[str, Any]
    context: Dict[str, Any]
    resolution: Optional[str] = None
    resolution_strategy: Optional[ResolutionStrategy] = None
    resolved_value: Optional[Any] = None

    def to_dict(self) -> Dict[str, Any]:
        return {
            "conflict_id": self.conflict_id,
            "conflict_type": self.conflict_type.value,
            "experts_involved": [e.value for e in self.experts_involved],
            "conflicting_values": self.conflicting_values,
            "context": self.context,
            "resolution": self.resolution,
            "resolution_strategy": self.resolution_strategy.value if self.resolution_strategy else None,
            "resolved_value": self.resolved_value
        }


@dataclass
class IntegratedLineageEdge:
    """Enhanced lineage edge with confidence and provenance."""
    source_table: str
    source_column: str
    target_table: str
    target_column: str
    transformation_sql: str
    transformation_type: str
    transformation_subtype: str
    confidence: Optional[ConfidenceScore] = None
    provenance: List[ProvenanceRecord] = field(default_factory=list)
    conflicts: List[ConflictRecord] = field(default_factory=list)
    english_explanation: str = ""
    all_source_columns: List[str] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "source_table": self.source_table,
            "source_column": self.source_column,
            "target_table": self.target_table,
            "target_column": self.target_column,
            "transformation_sql": self.transformation_sql,
            "transformation_type": self.transformation_type,
            "transformation_subtype": self.transformation_subtype,
            "confidence": self.confidence.to_dict() if self.confidence else None,
            "provenance": [p.to_dict() for p in self.provenance],
            "conflicts": [c.to_dict() for c in self.conflicts],
            "english_explanation": self.english_explanation,
            "all_source_columns": self.all_source_columns
        }

    def to_csv_row(self) -> Dict[str, str]:
        """BDaaS-compatible CSV row with extended fields."""
        return {
            "Source_Table": self.source_table,
            "Source_Attribute": self.source_column,
            "Transformation_Logic": self.transformation_sql,
            "Transformation_Explanation": self.english_explanation,
            "Target_Table": self.target_table,
            "Target_Attribute": self.target_column,
            "Transformation_Type": self.transformation_type,
            "Confidence_Score": str(self.confidence.overall_score if self.confidence else 1.0),
            "Contributing_Experts": ";".join([p.expert_name for p in self.provenance]),
            "Has_Conflicts": "Yes" if self.conflicts else "No",
            "All_Source_Columns": ";".join(self.all_source_columns)
        }


@dataclass
class IntegratedLineageResult:
    """Complete integrated lineage result from all experts."""
    target_table: str
    source_tables: List[str]
    edges: List[IntegratedLineageEdge] = field(default_factory=list)
    join_conditions: List[Dict[str, Any]] = field(default_factory=list)
    filter_conditions: List[Dict[str, Any]] = field(default_factory=list)
    overall_confidence: float = 1.0
    total_conflicts: int = 0
    resolved_conflicts: int = 0
    expert_contributions: Dict[str, int] = field(default_factory=dict)
    provenance_summary: List[ProvenanceRecord] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "target_table": self.target_table,
            "source_tables": self.source_tables,
            "edges": [e.to_dict() for e in self.edges],
            "join_conditions": self.join_conditions,
            "filter_conditions": self.filter_conditions,
            "overall_confidence": self.overall_confidence,
            "total_conflicts": self.total_conflicts,
            "resolved_conflicts": self.resolved_conflicts,
            "expert_contributions": self.expert_contributions,
            "provenance_summary": [p.to_dict() for p in self.provenance_summary]
        }
