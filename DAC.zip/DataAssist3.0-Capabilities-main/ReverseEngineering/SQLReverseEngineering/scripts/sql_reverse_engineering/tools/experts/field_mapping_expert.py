"""
FieldMappingExpert - Analyzes field-level transformations and mappings.

Features:
- Field relationship analysis within subscripts
- Array/subscript access pattern parsing
- Composite type field access (struct.field)
- Field transformation chain building
- Alias resolution
"""

import sqlglot
from sqlglot import exp
from typing import Dict, List, Optional, Tuple, Set
import uuid
import sys
import os

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from .base_expert import BaseExpert, ExpertOutput
from .models.field_models import (
    FieldMappingResult, FieldMapping, FieldMappingType,
    FieldAccessPattern, FieldAccessType, SubscriptAccess,
    CompositeFieldAccess, FieldTransformationChain, TransformationStep,
    SubscriptFieldAnalysis, FieldAliasChain, ParameterVariation
)


class FieldMappingExpert(BaseExpert):
    """
    Expert module for analyzing field mappings and transformations.

    Provides:
    1. Field relationship analysis within each subscript
    2. Array/subscript access pattern detection
    3. Composite type field access parsing
    4. Transformation chain building through CTEs/subqueries
    5. Alias resolution to original sources
    """

    def __init__(self, dialect: str = "teradata"):
        super().__init__(dialect)
        self._result: Optional[FieldMappingResult] = None
        self._mapping_counter = 0
        self._pattern_counter = 0

    def analyze(self, sql: str, **kwargs) -> ExpertOutput:
        """
        Perform complete field mapping analysis.
        """
        if not self.validate_input(sql):
            return self._create_error_output("Invalid or empty SQL input")

        try:
            ast = sqlglot.parse_one(sql, read=self.dialect)
        except Exception as e:
            return self._create_error_output(f"Parse error: {str(e)}")

        analysis_id = str(uuid.uuid4())[:12]
        self._mapping_counter = 0
        self._pattern_counter = 0

        # Extract target table
        target_table = self._get_target_table(ast)

        # Extract CTEs
        cte_info = self._extract_ctes(ast)

        # Phase 1: Analyze subscript fields
        subscript_analyses = self._analyze_subscript_fields(ast, cte_info)

        # Phase 2: Extract field mappings
        field_mappings = self._extract_field_mappings(ast, target_table, cte_info)

        # Phase 3: Parse access patterns
        access_patterns = self._extract_access_patterns(ast)

        # Phase 4: Build transformation chains
        chains = self._build_transformation_chains(field_mappings, subscript_analyses, cte_info)

        # Phase 5: Resolve aliases
        alias_chains = self._resolve_aliases(ast, field_mappings, cte_info)

        # Phase 6: Track parameter variations
        param_variations = self._track_parameters(ast, subscript_analyses)

        # Get source tables
        source_tables = list(set(self._extract_all_tables(ast)))

        # Build metadata
        metadata = {
            "dialect": self.dialect,
            "total_mappings": len(field_mappings),
            "subscript_count": len(subscript_analyses),
            "has_array_access": any(
                ap.access_type in [FieldAccessType.SUBSCRIPT_INDEX,
                                   FieldAccessType.SUBSCRIPT_KEY]
                for ap in access_patterns
            ),
            "has_composite_access": any(
                ap.access_type == FieldAccessType.DOT_ACCESS
                for ap in access_patterns
            )
        }

        self._result = FieldMappingResult(
            analysis_id=analysis_id,
            source_sql=sql,
            target_table=target_table,
            field_mappings=field_mappings,
            transformation_chains=chains,
            subscript_analyses=subscript_analyses,
            alias_chains=alias_chains,
            parameter_variations=param_variations,
            access_patterns=access_patterns,
            metadata=metadata
        )

        self._last_output = ExpertOutput(
            expert_name=self.name,
            success=True,
            data={
                "analysis_id": analysis_id,
                "target_table": target_table,
                "source_tables": source_tables,
                "field_mappings": [m.to_dict() for m in field_mappings],
                "transformation_chains": [c.to_dict() for c in chains],
                "subscript_analyses": [s.to_dict() for s in subscript_analyses],
                "alias_chains": [a.to_dict() for a in alias_chains],
                "access_patterns": [a.to_dict() for a in access_patterns]
            },
            confidence=self._calculate_confidence(),
            metadata=metadata
        )

        return self._last_output

    def get_confidence(self) -> float:
        if self._last_output:
            return self._last_output.confidence
        return 0.0

    def get_result(self) -> Optional[FieldMappingResult]:
        """Get the full field mapping result."""
        return self._result

    def _generate_mapping_id(self) -> str:
        self._mapping_counter += 1
        return f"FM_{self._mapping_counter:04d}"

    def _generate_pattern_id(self) -> str:
        self._pattern_counter += 1
        return f"AP_{self._pattern_counter:04d}"

    def _get_target_table(self, ast: exp.Expression) -> Optional[str]:
        """Get target table from INSERT or CREATE."""
        if isinstance(ast, exp.Insert):
            return ast.this.name if ast.this else None
        if isinstance(ast, exp.Create):
            return ast.this.this.name if ast.this else None
        return None

    def _extract_ctes(self, ast: exp.Expression) -> Dict[str, Dict]:
        """Extract CTE information."""
        cte_info = {}
        with_clause = ast.find(exp.With)

        if not with_clause:
            return cte_info

        for cte_expr in with_clause.expressions:
            cte_name = cte_expr.alias
            cte_body = cte_expr.this

            columns = self._extract_output_columns(cte_body)

            cte_info[cte_name.upper()] = {
                "name": cte_name,
                "columns": columns,
                "expression": cte_body,
                "source_tables": [t.name for t in cte_body.find_all(exp.Table)]
            }

        return cte_info

    def _extract_output_columns(self, expr: exp.Expression) -> List[str]:
        """Extract output column names from SELECT."""
        columns = []
        select = expr.find(exp.Select) if not isinstance(expr, exp.Select) else expr
        if select:
            for i, e in enumerate(select.expressions):
                if hasattr(e, 'alias') and e.alias:
                    columns.append(e.alias)
                elif isinstance(e, exp.Column):
                    columns.append(e.name)
                else:
                    columns.append(f"col_{i+1}")
        return columns

    def _analyze_subscript_fields(self, ast: exp.Expression,
                                  cte_info: Dict) -> List[SubscriptFieldAnalysis]:
        """Analyze fields within each subscript (CTE, subquery)."""
        analyses = []

        # Analyze each CTE
        for cte_name, info in cte_info.items():
            input_fields = self._get_input_fields(info["expression"])
            output_fields = self._get_output_fields(info["expression"], cte_name)

            analyses.append(SubscriptFieldAnalysis(
                subscript_name=cte_name,
                subscript_type="CTE",
                input_fields=input_fields,
                output_fields=output_fields,
                internal_transformations=self._get_internal_transformations(info["expression"]),
                dependencies=info["source_tables"]
            ))

        return analyses

    def _get_input_fields(self, expr: exp.Expression) -> List[FieldMapping]:
        """Get input fields (source columns) for an expression."""
        mappings = []
        for col in expr.find_all(exp.Column):
            table = col.table or "UNKNOWN"
            mappings.append(FieldMapping(
                mapping_id=self._generate_mapping_id(),
                mapping_type=FieldMappingType.DIRECT_COLUMN,
                target_field=col.name,
                source_fields=[f"{table}.{col.name}"],
                source_tables=[table] if table != "UNKNOWN" else [],
                transformation_sql=col.sql(dialect=self.dialect)
            ))
        return mappings

    def _get_output_fields(self, expr: exp.Expression,
                           context: str) -> List[FieldMapping]:
        """Get output fields from SELECT clause."""
        mappings = []
        select = expr.find(exp.Select) if not isinstance(expr, exp.Select) else expr

        if not select:
            return mappings

        for i, sel_expr in enumerate(select.expressions):
            # Get output name
            if hasattr(sel_expr, 'alias') and sel_expr.alias:
                output_name = sel_expr.alias
            elif isinstance(sel_expr, exp.Column):
                output_name = sel_expr.name
            else:
                output_name = f"col_{i+1}"

            # Get source columns
            source_cols = []
            source_tables = set()
            for col in sel_expr.find_all(exp.Column):
                table = col.table or "UNKNOWN"
                source_cols.append(f"{table}.{col.name}")
                if table != "UNKNOWN":
                    source_tables.add(table)

            # Determine mapping type
            mapping_type = self._classify_mapping_type(sel_expr)

            mappings.append(FieldMapping(
                mapping_id=self._generate_mapping_id(),
                mapping_type=mapping_type,
                target_field=output_name,
                source_expression=sel_expr.sql(dialect=self.dialect),
                source_fields=source_cols,
                source_tables=list(source_tables),
                transformation_sql=sel_expr.sql(dialect=self.dialect),
                subscript_context=context,
                is_calculated=mapping_type != FieldMappingType.DIRECT_COLUMN
            ))

        return mappings

    def _classify_mapping_type(self, expr: exp.Expression) -> FieldMappingType:
        """Classify the type of field mapping."""
        # Check for aggregation
        if expr.find(exp.Sum) or expr.find(exp.Count) or expr.find(exp.Avg) or \
           expr.find(exp.Min) or expr.find(exp.Max):
            return FieldMappingType.AGGREGATED

        # Check for direct column
        if isinstance(expr, exp.Column):
            return FieldMappingType.DIRECT_COLUMN

        if isinstance(expr, exp.Alias) and isinstance(expr.this, exp.Column):
            return FieldMappingType.DIRECT_COLUMN

        # Check for literal
        if isinstance(expr, exp.Literal):
            return FieldMappingType.CONSTANT

        # Default to calculated
        return FieldMappingType.CALCULATED

    def _get_internal_transformations(self, expr: exp.Expression) -> List[str]:
        """Get list of transformation operations within expression."""
        transformations = []

        if expr.find(exp.Case):
            transformations.append("CASE")
        if expr.find(exp.Cast):
            transformations.append("CAST")
        if expr.find(exp.Concat):
            transformations.append("CONCAT")

        # Check for functions
        for func in expr.find_all(exp.Func):
            func_name = func.__class__.__name__.upper()
            if func_name not in transformations:
                transformations.append(func_name)

        return transformations

    def _extract_field_mappings(self, ast: exp.Expression, target_table: Optional[str],
                                cte_info: Dict) -> List[FieldMapping]:
        """Extract field mappings from main SELECT."""
        mappings = []

        # Get main SELECT
        select = ast.find(exp.Select)
        if not select:
            return mappings

        for i, sel_expr in enumerate(select.expressions):
            # Get target column name
            if hasattr(sel_expr, 'alias') and sel_expr.alias:
                target_col = sel_expr.alias
            elif isinstance(sel_expr, exp.Column):
                target_col = sel_expr.name
            else:
                target_col = f"col_{i+1}"

            # Extract sources
            source_cols = []
            source_tables = set()
            access_patterns = []

            for col in sel_expr.find_all(exp.Column):
                table = col.table or "UNKNOWN"
                source_cols.append(f"{table}.{col.name}")
                if table != "UNKNOWN":
                    source_tables.add(table)

            # Check for bracket/subscript access
            for bracket in sel_expr.find_all(exp.Bracket):
                pattern = self._parse_bracket_access(bracket)
                if pattern:
                    access_patterns.append(pattern)

            # Check for dot access
            for dot in sel_expr.find_all(exp.Dot):
                pattern = self._parse_dot_access(dot)
                if pattern:
                    access_patterns.append(pattern)

            mapping_type = self._classify_mapping_type(sel_expr)

            mappings.append(FieldMapping(
                mapping_id=self._generate_mapping_id(),
                mapping_type=mapping_type,
                target_field=target_col,
                source_expression=sel_expr.sql(dialect=self.dialect),
                source_fields=source_cols,
                source_tables=list(source_tables),
                access_patterns=access_patterns,
                transformation_sql=sel_expr.sql(dialect=self.dialect),
                is_calculated=mapping_type != FieldMappingType.DIRECT_COLUMN
            ))

        return mappings

    def _extract_access_patterns(self, ast: exp.Expression) -> List[FieldAccessPattern]:
        """Extract all field access patterns from AST."""
        patterns = []

        # Find bracket accesses (array[0], json['key'])
        for bracket in ast.find_all(exp.Bracket):
            pattern = self._parse_bracket_access(bracket)
            if pattern:
                patterns.append(pattern)

        # Find dot accesses (struct.field)
        for dot in ast.find_all(exp.Dot):
            pattern = self._parse_dot_access(dot)
            if pattern:
                patterns.append(pattern)

        return patterns

    def _parse_bracket_access(self, bracket: exp.Bracket) -> Optional[FieldAccessPattern]:
        """Parse a bracket expression."""
        try:
            base_expr = bracket.this.sql(dialect=self.dialect)
            index_expr = bracket.expressions[0] if bracket.expressions else None

            if isinstance(index_expr, exp.Literal):
                if index_expr.is_number:
                    index_or_key = int(index_expr.this)
                    is_numeric = True
                else:
                    index_or_key = str(index_expr.this)
                    is_numeric = False
            else:
                index_or_key = index_expr.sql(dialect=self.dialect) if index_expr else "UNKNOWN"
                is_numeric = False

            access = SubscriptAccess(
                access_id=self._generate_pattern_id(),
                base_expression=base_expr,
                index_or_key=index_or_key,
                is_numeric_index=is_numeric,
                position=0,
                sql_text=bracket.sql(dialect=self.dialect)
            )

            return FieldAccessPattern(
                pattern_id=self._generate_pattern_id(),
                original_expression=bracket.sql(dialect=self.dialect),
                access_type=FieldAccessType.SUBSCRIPT_INDEX if is_numeric else FieldAccessType.SUBSCRIPT_KEY,
                subscript_accesses=[access]
            )
        except Exception:
            return None

    def _parse_dot_access(self, dot: exp.Dot) -> Optional[FieldAccessPattern]:
        """Parse a dot expression."""
        try:
            field_path = []
            current = dot

            while current:
                if isinstance(current, exp.Dot):
                    if hasattr(current, 'expression') and current.expression:
                        field_path.insert(0, current.expression.name)
                    current = current.this
                elif isinstance(current, exp.Column):
                    field_path.insert(0, current.name)
                    break
                else:
                    break

            if len(field_path) < 2:
                return None

            access = CompositeFieldAccess(
                access_id=self._generate_pattern_id(),
                base_type=field_path[0],
                field_path=field_path,
                is_nested=len(field_path) > 2,
                sql_text=dot.sql(dialect=self.dialect)
            )

            return FieldAccessPattern(
                pattern_id=self._generate_pattern_id(),
                original_expression=dot.sql(dialect=self.dialect),
                access_type=FieldAccessType.DOT_ACCESS,
                composite_accesses=[access]
            )
        except Exception:
            return None

    def _build_transformation_chains(self, mappings: List[FieldMapping],
                                      subscript_analyses: List[SubscriptFieldAnalysis],
                                      cte_info: Dict) -> List[FieldTransformationChain]:
        """Build transformation chains for each target field."""
        chains = []

        for mapping in mappings:
            steps = []
            step_number = 0

            # Trace through CTEs
            for source_table in mapping.source_tables:
                if source_table.upper() in cte_info:
                    step_number += 1
                    steps.append(TransformationStep(
                        step_id=f"STEP_{step_number:03d}",
                        step_number=step_number,
                        input_fields=mapping.source_fields,
                        output_field=mapping.target_field,
                        transformation_type="CTE_REFERENCE",
                        transformation_sql=mapping.transformation_sql,
                        subscript_name=source_table
                    ))

            # Final step
            step_number += 1
            steps.append(TransformationStep(
                step_id=f"STEP_{step_number:03d}",
                step_number=step_number,
                input_fields=mapping.source_fields,
                output_field=mapping.target_field,
                transformation_type=mapping.mapping_type.value,
                transformation_sql=mapping.transformation_sql
            ))

            ultimate_sources = [
                {"table": f.split('.')[0] if '.' in f else "UNKNOWN",
                 "column": f.split('.')[-1]}
                for f in mapping.source_fields
            ]

            chains.append(FieldTransformationChain(
                chain_id=f"CHAIN_{mapping.mapping_id}",
                target_table=mapping.source_tables[0] if mapping.source_tables else "",
                target_field=mapping.target_field,
                ultimate_sources=ultimate_sources,
                steps=steps,
                total_hops=len(steps),
                involves_aggregation=mapping.mapping_type == FieldMappingType.AGGREGATED,
                involves_subscript_access=len(mapping.access_patterns) > 0
            ))

        return chains

    def _resolve_aliases(self, ast: exp.Expression, mappings: List[FieldMapping],
                         cte_info: Dict) -> List[FieldAliasChain]:
        """Resolve field aliases to original sources."""
        chains = []

        for mapping in mappings:
            if mapping.target_alias or mapping.target_field != mapping.source_expression:
                chain = [{"alias": mapping.target_field, "resolves_to": mapping.source_expression}]

                original_source = mapping.source_fields[0] if mapping.source_fields else mapping.source_expression
                original_table = mapping.source_tables[0] if mapping.source_tables else None

                chains.append(FieldAliasChain(
                    final_alias=mapping.target_field,
                    alias_chain=chain,
                    original_source=original_source,
                    original_table=original_table
                ))

        return chains

    def _track_parameters(self, ast: exp.Expression,
                          subscript_analyses: List[SubscriptFieldAnalysis]) -> List[ParameterVariation]:
        """Track parameter variations across subscripts."""
        variations = []

        # Find all literal values in WHERE clauses and track variations
        literals_by_context = {}

        for analysis in subscript_analyses:
            for field in analysis.output_fields:
                for pattern in field.access_patterns:
                    if pattern.subscript_accesses:
                        for access in pattern.subscript_accesses:
                            param_name = f"subscript_{access.base_expression}"
                            if param_name not in literals_by_context:
                                literals_by_context[param_name] = []
                            literals_by_context[param_name].append({
                                "subscript": analysis.subscript_name,
                                "value": str(access.index_or_key)
                            })

        for param_name, var_list in literals_by_context.items():
            values = set(v["value"] for v in var_list)
            variations.append(ParameterVariation(
                parameter_name=param_name,
                variations=var_list,
                is_consistent=len(values) <= 1,
                default_value=var_list[0]["value"] if var_list else None
            ))

        return variations

    def _extract_all_tables(self, ast: exp.Expression) -> List[str]:
        """Extract all table names."""
        return [t.name for t in ast.find_all(exp.Table)]

    def _calculate_confidence(self) -> float:
        """Calculate confidence score."""
        if not self._result:
            return 0.0

        confidence = 1.0

        # Reduce for unmapped fields
        if len(self._result.field_mappings) == 0:
            confidence -= 0.3

        # Reduce for complex access patterns
        if self._result.metadata.get("has_array_access"):
            confidence -= 0.1

        return max(0.5, min(1.0, confidence))
