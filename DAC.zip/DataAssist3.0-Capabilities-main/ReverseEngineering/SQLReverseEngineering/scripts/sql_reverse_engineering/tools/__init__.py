"""
Tools package for SQL Reverse Engineering.

Subpackages:
    ast_generator/    - SQL parsing and AST generation
    deconstructor/    - SQL element extraction (joins, CTEs, functions, etc.)
    lineage/          - Field-level lineage extraction and graph building
    dynamic_sql/      - Dynamic SQL detection and reconstruction
    experts/          - Specialized analysis experts
    file_handlers/    - File type detection and multi-file processing
    documentation/    - Report and mapping document generation
    visualization/    - Interactive lineage graph visualization
    models/           - Shared data models and contracts
    agent_interface/  - CLI and API entry points
"""
