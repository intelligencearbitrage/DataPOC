"""
STTM Accuracy Validator — block-by-block comparison of structured XLSX vs original SQL.

Parses the source SQL into individual DML blocks, extracts the expected structure
(target table, source tables, joins, filters, column lists) for each block,
then compares against the STTM structured XLSX output to produce a detailed
accuracy report with per-block and aggregate scoring.

Scoring Dimensions (per block):
  1. Column Mapping Coverage  — INSERT/SELECT columns present in STTM
  2. Source Table Coverage     — FROM/JOIN tables present in STTM source tables
  3. Join Capture Accuracy     — JOINs in SQL block matched to Join Conditions
  4. Filter Capture Accuracy   — WHERE/QUALIFY in SQL block matched to Filter Conditions
  5. Join ID Assignment        — column mappings have join IDs assigned
  6. Filter ID Assignment      — column mappings have filter IDs assigned

Usage:
    from validation.sttm_accuracy_validator import STTMAccuracyValidator
    validator = STTMAccuracyValidator(sql_path, xlsx_path)
    report = validator.validate()
    report.print_report()
    report.to_dict()
"""

import re
import os
import sys
from dataclasses import dataclass, field
from typing import List, Dict, Optional, Tuple, Set
from pathlib import Path
from werkzeug.utils import safe_join, secure_filename

try:
    import openpyxl
except ImportError:
    openpyxl = None

# SQLReverseEngineering/ is 5 levels above this file
_PROJECT_ROOT = Path(__file__).resolve().parent.parent.parent.parent.parent


def _resolve_cli_path(raw: str, must_be_under: Optional[Path] = None) -> Path:
    resolved = Path(raw).resolve()
    if must_be_under is not None:
        base = must_be_under.resolve()
        try:
            resolved.relative_to(base)
        except ValueError:
            print(f"Error: '{raw}' resolves to '{resolved}', outside allowed directory '{base}'.", file=sys.stderr)
            sys.exit(1)
    return resolved


# ---------------------------------------------------------------------------
# Data structures
# ---------------------------------------------------------------------------

@dataclass
class SQLBlock:
    """A single DML block extracted from the source SQL."""
    block_index: int
    dml_type: str                # INSERT, UPDATE, DELETE, CREATE, SELECT INTO, REPLACE VIEW
    target_table: str            # fully qualified or short name
    target_table_short: str      # unqualified name
    source_tables: List[str] = field(default_factory=list)     # fully qualified
    source_tables_short: Set[str] = field(default_factory=set) # short names
    insert_columns: List[str] = field(default_factory=list)    # target column list
    join_count: int = 0
    join_types: List[str] = field(default_factory=list)        # e.g., ["LEFT OUTER JOIN", "INNER JOIN"]
    join_tables: List[str] = field(default_factory=list)       # tables in JOIN clauses
    join_on_clauses: List[str] = field(default_factory=list)   # ON clause text
    has_where: bool = False
    where_text: str = ""
    has_qualify: bool = False
    has_group_by: bool = False
    has_union: bool = False
    union_branch_count: int = 0
    has_case: bool = False
    raw_sql: str = ""
    line_start: int = 0
    line_end: int = 0


@dataclass
class STTMSequence:
    """STTM column lineage data grouped by sequence number."""
    sequence: Optional[int]
    operator_type: str
    target_table: str
    target_table_short: str
    source_tables: Set[str] = field(default_factory=set)
    source_tables_short: Set[str] = field(default_factory=set)
    target_columns: Set[str] = field(default_factory=set)
    row_count: int = 0
    rows_with_join_ids: int = 0
    rows_with_filter_ids: int = 0
    join_ids_used: Set[str] = field(default_factory=set)
    filter_ids_used: Set[str] = field(default_factory=set)


@dataclass
class STTMJoinCondition:
    """A single join condition from the Join Conditions sheet."""
    join_id: str
    join_type: str
    left_table: str
    right_table: str
    join_sql: str
    applies_to_sequence: Optional[str] = None


@dataclass
class STTMFilterCondition:
    """A single filter condition from the Filter Conditions sheet."""
    filter_id: str
    filter_type: str
    sql_expression: str
    columns_referenced: str
    applies_to_sequence: Optional[str] = None


@dataclass
class BlockComparisonResult:
    """Comparison result for one SQL block vs its STTM sequence."""
    block: SQLBlock
    matched_sequence: Optional[STTMSequence]
    # Scores (0.0 to 1.0)
    column_coverage: float = 0.0
    source_table_coverage: float = 0.0
    join_capture: float = 0.0
    filter_capture: float = 0.0
    join_id_assignment: float = 0.0
    filter_id_assignment: float = 0.0
    # Details
    missing_columns: List[str] = field(default_factory=list)
    extra_columns: List[str] = field(default_factory=list)
    missing_source_tables: List[str] = field(default_factory=list)
    missing_joins: List[str] = field(default_factory=list)
    matched_joins: List[str] = field(default_factory=list)
    notes: List[str] = field(default_factory=list)

    @property
    def overall_score(self) -> float:
        weights = {
            'column_coverage': 30,
            'source_table_coverage': 20,
            'join_capture': 15,
            'filter_capture': 15,
            'join_id_assignment': 10,
            'filter_id_assignment': 10,
        }
        total = sum(
            getattr(self, dim) * w for dim, w in weights.items()
        )
        return round(total / sum(weights.values()) * 100, 1)


@dataclass
class ValidationReport:
    """Full validation report: block-by-block + aggregate."""
    sql_file: str
    xlsx_file: str
    sql_blocks: List[SQLBlock] = field(default_factory=list)
    sttm_sequences: List[STTMSequence] = field(default_factory=list)
    sttm_joins: List[STTMJoinCondition] = field(default_factory=list)
    sttm_filters: List[STTMFilterCondition] = field(default_factory=list)
    block_results: List[BlockComparisonResult] = field(default_factory=list)
    unmatched_blocks: List[SQLBlock] = field(default_factory=list)
    unmatched_sequences: List[STTMSequence] = field(default_factory=list)
    # Aggregate
    overall_score: float = 0.0
    grade: str = ""
    # Summary counts
    total_sql_blocks: int = 0
    total_sttm_sequences: int = 0
    total_sql_joins: int = 0
    total_sttm_joins: int = 0
    total_sql_filters: int = 0
    total_sttm_filters: int = 0
    total_sql_columns: int = 0
    total_sttm_columns: int = 0

    def print_report(self):
        """Print a formatted validation report to stdout."""
        _print_report(self)

    def to_dict(self) -> dict:
        """Convert to a JSON-serializable dict."""
        return _report_to_dict(self)


# ---------------------------------------------------------------------------
# SQL Block Parser
# ---------------------------------------------------------------------------

def _remove_sql_comments(sql: str) -> str:
    """Remove block comments and line comments."""
    sql = re.sub(r'/\*.*?\*/', '', sql, flags=re.DOTALL)
    sql = re.sub(r'--[^\n]*', '', sql)
    return sql


def _extract_sql_blocks(sql: str) -> List[SQLBlock]:
    """
    Parse SQL into individual DML blocks.
    Handles stored procedures (multiple statements) and views (single statement).
    """
    clean = _remove_sql_comments(sql)
    blocks = []

    # Track line numbers in the original (commented) SQL
    original_lines = sql.split('\n')

    # Patterns for DML block starts
    patterns = [
        # INSERT INTO table (cols) SELECT ...
        (r'\bINSERT\s+INTO\s+([\w."]+)\s*\(([^)]*)\)\s*SELECT\b',
         'INSERT', True),
        # INSERT INTO table SELECT ... (no column list)
        (r'\bINSERT\s+INTO\s+([\w."]+)\s+SELECT\b',
         'INSERT', False),
        # UPDATE table SET ...
        (r'(?<!\bCOLLECT\s)\bUPDATE\s+([\w."]+)\s+(?:FROM\b|SET\b)',
         'UPDATE', False),
        # DELETE FROM table
        (r'\bDELETE\s+(?:FROM\s+)?([\w."]+)',
         'DELETE', False),
        # CREATE VOLATILE TABLE ... AS (SELECT ...)
        (r'\bCREATE\s+(?:SET\s+|MULTISET\s+)?VOLATILE\s+TABLE\s+([\w."]+)\s+AS\b',
         'CREATE', False),
        # REPLACE VIEW / CREATE VIEW
        (r'\b(?:REPLACE|CREATE(?:\s+OR\s+REPLACE)?)\s+VIEW\s+([\w."]+)\s+AS\b',
         'REPLACE VIEW', False),
    ]

    for pat, dml_type, has_col_list in patterns:
        for m in re.finditer(pat, clean, re.IGNORECASE):
            target_raw = m.group(1).strip().strip('"')
            target_short = target_raw.split('.')[-1].upper()

            # Find the statement boundaries (up to the next semicolon)
            start_pos = m.start()
            end_pos = clean.find(';', m.end())
            if end_pos == -1:
                end_pos = len(clean)
            stmt_sql = clean[start_pos:end_pos + 1]

            # Compute line numbers
            line_start = clean[:start_pos].count('\n') + 1
            line_end = clean[:end_pos].count('\n') + 1

            # Extract INSERT column list
            insert_columns = []
            if has_col_list:
                col_text = m.group(2)
                insert_columns = [c.strip().strip('"').upper()
                                  for c in col_text.split(',') if c.strip()]

            block = SQLBlock(
                block_index=len(blocks),
                dml_type=dml_type,
                target_table=target_raw.upper(),
                target_table_short=target_short,
                insert_columns=insert_columns,
                raw_sql=stmt_sql,
                line_start=line_start,
                line_end=line_end,
            )

            # Extract source tables
            _extract_block_sources(stmt_sql, block)
            # Extract joins
            _extract_block_joins(stmt_sql, block)
            # Extract WHERE
            _extract_block_where(stmt_sql, block)
            # Detect UNION, CASE, GROUP BY, QUALIFY
            _detect_block_features(stmt_sql, block)

            blocks.append(block)

    # Sort by position in source
    blocks.sort(key=lambda b: b.line_start)
    for i, b in enumerate(blocks):
        b.block_index = i

    return blocks


def _extract_block_sources(stmt_sql: str, block: SQLBlock):
    """Extract source tables from FROM and JOIN clauses."""
    # FROM table
    for m in re.finditer(r'\bFROM\s+([\w."]+)', stmt_sql, re.IGNORECASE):
        t = m.group(1).strip().strip('"').upper()
        if t not in ('SELECT', '(', ')', 'SET', 'ALL', 'DBC'):
            block.source_tables.append(t)
            block.source_tables_short.add(t.split('.')[-1])
    # JOIN table
    for m in re.finditer(r'\bJOIN\s+([\w."]+)', stmt_sql, re.IGNORECASE):
        t = m.group(1).strip().strip('"').upper()
        if t not in ('SELECT', '(', ')', 'SET', 'ALL'):
            block.source_tables.append(t)
            block.source_tables_short.add(t.split('.')[-1])


def _extract_block_joins(stmt_sql: str, block: SQLBlock):
    """Extract JOIN details from the statement."""
    join_pat = re.compile(
        r'((?:LEFT|RIGHT|FULL|CROSS|INNER)?\s*(?:OUTER\s+)?JOIN)\s+([\w."]+)\s+'
        r'(?:AS\s+\w+\s+)?(?:(\w+)\s+)?ON\s+(.+?)(?=(?:LEFT|RIGHT|FULL|CROSS|INNER)\s|JOIN\s|WHERE\b|GROUP\b|ORDER\b|QUALIFY\b|UNION\b|;\s*$|$)',
        re.IGNORECASE | re.DOTALL
    )
    for m in re.finditer(join_pat, stmt_sql):
        join_type = re.sub(r'\s+', ' ', m.group(1).strip()).upper()
        join_table = m.group(2).strip().strip('"').upper()
        on_clause = m.group(4).strip().rstrip(';').strip() if m.group(4) else ""
        block.join_types.append(join_type)
        block.join_tables.append(join_table)
        block.join_on_clauses.append(on_clause)

    # Simple count fallback
    block.join_count = len(re.findall(r'\bJOIN\b', stmt_sql, re.IGNORECASE))


def _extract_block_where(stmt_sql: str, block: SQLBlock):
    """Extract WHERE clause from the statement (outermost only)."""
    # Find WHERE that's not inside a subquery (approximate: first WHERE after FROM/JOIN)
    # More precise: look for WHERE at the top nesting level
    where_matches = list(re.finditer(r'\bWHERE\b', stmt_sql, re.IGNORECASE))
    if where_matches:
        block.has_where = True
        # Get the text after the first WHERE up to GROUP BY/ORDER BY/QUALIFY/UNION/;
        first_where = where_matches[0]
        rest = stmt_sql[first_where.end():]
        # Trim at the next top-level clause
        end_match = re.search(
            r'\b(?:GROUP\s+BY|ORDER\s+BY|QUALIFY|HAVING|UNION)\b|;\s*$',
            rest, re.IGNORECASE
        )
        if end_match:
            block.where_text = rest[:end_match.start()].strip()
        else:
            block.where_text = rest.strip().rstrip(';').strip()


def _detect_block_features(stmt_sql: str, block: SQLBlock):
    """Detect UNION, CASE, GROUP BY, QUALIFY in the statement."""
    upper = stmt_sql.upper()
    if re.search(r'\bUNION\s+ALL\b', upper):
        block.has_union = True
        block.union_branch_count = upper.count('UNION ALL') + 1
    elif re.search(r'\bUNION\b', upper):
        block.has_union = True
        block.union_branch_count = upper.count('UNION') + 1
    block.has_case = bool(re.search(r'\bCASE\b', upper))
    block.has_group_by = bool(re.search(r'\bGROUP\s+BY\b', upper))
    block.has_qualify = bool(re.search(r'\bQUALIFY\b', upper))


# ---------------------------------------------------------------------------
# STTM XLSX Reader
# ---------------------------------------------------------------------------

def _read_sttm_xlsx(xlsx_path: str) -> Tuple[
    List[STTMSequence], List[STTMJoinCondition], List[STTMFilterCondition]
]:
    """Read the structured xlsx and extract sequences, joins, and filters."""
    if openpyxl is None:
        raise ImportError("openpyxl is required: pip install openpyxl")

    wb = openpyxl.load_workbook(xlsx_path, read_only=True)
    sequences = _read_column_lineage(wb)
    joins = _read_join_conditions(wb)
    filters = _read_filter_conditions(wb)
    wb.close()
    return sequences, joins, filters


def _read_column_lineage(wb) -> List[STTMSequence]:
    """Read Column Lineage sheet and group by sequence."""
    if 'Column Lineage' not in wb.sheetnames:
        return []

    ws = wb['Column Lineage']
    headers = [c.value for c in next(ws.iter_rows(min_row=1, max_row=1))]
    idx = {h: i for i, h in enumerate(headers) if h}

    seq_map = {}  # seq_num -> STTMSequence

    for row in ws.iter_rows(min_row=2, values_only=True):
        seq = row[idx.get('Sequence', 0)]
        op = str(row[idx.get('Operator Type', 1)] or '').upper()
        src_t = str(row[idx.get('Source Table', 2)] or '')
        tgt_t = str(row[idx.get('Target Table', 5)] or '')
        tgt_c = str(row[idx.get('Target Column', 7)] or '').upper()
        join_ids = str(row[idx.get('Join IDs', -1)] or '') if 'Join IDs' in idx else ''
        filter_ids = str(row[idx.get('Filter IDs', -1)] or '') if 'Filter IDs' in idx else ''

        if seq not in seq_map:
            seq_map[seq] = STTMSequence(
                sequence=seq,
                operator_type=op,
                target_table=tgt_t.upper(),
                target_table_short=tgt_t.split('.')[-1].upper() if tgt_t else '',
            )

        s = seq_map[seq]
        s.row_count += 1
        if src_t:
            s.source_tables.add(src_t.upper())
            s.source_tables_short.add(src_t.split('.')[-1].upper())
        if tgt_c:
            s.target_columns.add(tgt_c)
        if join_ids.strip():
            s.rows_with_join_ids += 1
            for jid in join_ids.split(','):
                jid = jid.strip()
                if jid:
                    s.join_ids_used.add(jid)
        if filter_ids.strip():
            s.rows_with_filter_ids += 1
            for fid in filter_ids.split(','):
                fid = fid.strip()
                if fid:
                    s.filter_ids_used.add(fid)

    return list(seq_map.values())


def _read_join_conditions(wb) -> List[STTMJoinCondition]:
    """Read Join Conditions sheet."""
    if 'Join Conditions' not in wb.sheetnames:
        return []

    ws = wb['Join Conditions']
    headers = [c.value for c in next(ws.iter_rows(min_row=1, max_row=1))]
    idx = {h: i for i, h in enumerate(headers) if h}
    joins = []

    for row in ws.iter_rows(min_row=2, values_only=True):
        jid = str(row[idx.get('Join ID', 0)] or '')
        if not jid or jid.startswith('No '):
            continue
        joins.append(STTMJoinCondition(
            join_id=jid,
            join_type=str(row[idx.get('Join Type', 1)] or '').upper(),
            left_table=str(row[idx.get('Left Table', 2)] or '').upper(),
            right_table=str(row[idx.get('Right Table', 4)] or '').upper(),
            join_sql=str(row[idx.get('Join SQL', 6)] or ''),
            applies_to_sequence=str(row[idx.get('Applies To Sequence', 7)] or ''),
        ))

    return joins


def _read_filter_conditions(wb) -> List[STTMFilterCondition]:
    """Read Filter Conditions sheet."""
    if 'Filter Conditions' not in wb.sheetnames:
        return []

    ws = wb['Filter Conditions']
    headers = [c.value for c in next(ws.iter_rows(min_row=1, max_row=1))]
    idx = {h: i for i, h in enumerate(headers) if h}
    filters = []

    for row in ws.iter_rows(min_row=2, values_only=True):
        fid = str(row[idx.get('Filter ID', 0)] or '')
        if not fid or fid.startswith('No '):
            continue
        filters.append(STTMFilterCondition(
            filter_id=fid,
            filter_type=str(row[idx.get('Filter Type', 1)] or '').upper(),
            sql_expression=str(row[idx.get('SQL Expression', 2)] or ''),
            columns_referenced=str(row[idx.get('Columns Referenced', 3)] or ''),
            applies_to_sequence=str(row[idx.get('Applies To Sequence', 4)] or ''),
        ))

    return filters


# ---------------------------------------------------------------------------
# Block Matching & Comparison
# ---------------------------------------------------------------------------

def _match_blocks_to_sequences(
    blocks: List[SQLBlock],
    sequences: List[STTMSequence],
) -> List[Tuple[SQLBlock, Optional[STTMSequence]]]:
    """
    Match SQL blocks to STTM sequences by target table and DML type.
    Returns list of (block, matched_sequence_or_None) pairs.
    """
    # Build available sequences indexed by target table short name
    available = list(sequences)
    matches = []

    for block in blocks:
        best = None
        best_score = -1

        for seq in available:
            if not seq.target_table_short:
                continue
            # Target table match
            if seq.target_table_short != block.target_table_short:
                continue
            # DML type affinity
            type_score = 0
            if block.dml_type == 'INSERT' and seq.operator_type == 'INSERT':
                type_score = 10
            elif block.dml_type == 'UPDATE' and seq.operator_type == 'UPDATE':
                type_score = 10
            elif block.dml_type == 'DELETE' and seq.operator_type == 'DELETE':
                type_score = 10
            elif block.dml_type in ('CREATE', 'REPLACE VIEW') and seq.operator_type in ('CREATE', 'CREATE VIEW', 'CREATE VOLATILE TABLE AS SELECT'):
                type_score = 10
            elif block.dml_type == 'SELECT INTO' and seq.operator_type == 'SELECT INTO':
                type_score = 10
            else:
                type_score = 1  # target table matches but DML type doesn't

            # Source table overlap
            overlap = len(block.source_tables_short & seq.source_tables_short)
            score = type_score * 100 + overlap

            if score > best_score:
                best_score = score
                best = seq

        if best:
            available.remove(best)
        matches.append((block, best))

    return matches


def _compare_block(
    block: SQLBlock,
    seq: Optional[STTMSequence],
    sttm_joins: List[STTMJoinCondition],
    sttm_filters: List[STTMFilterCondition],
) -> BlockComparisonResult:
    """Compare a single SQL block against its matched STTM sequence."""
    result = BlockComparisonResult(block=block, matched_sequence=seq)

    if seq is None:
        result.notes.append("NO MATCHING STTM SEQUENCE FOUND")
        return result

    # 1. Column Mapping Coverage
    if block.insert_columns:
        expected = set(block.insert_columns)
        found = seq.target_columns
        matched = expected & found
        result.column_coverage = len(matched) / len(expected) if expected else 1.0
        result.missing_columns = sorted(expected - found)
        result.extra_columns = sorted(found - expected)
    else:
        # No explicit column list — score based on having any mappings
        result.column_coverage = 1.0 if seq.row_count > 0 else 0.0

    # 2. Source Table Coverage
    if block.source_tables_short:
        expected_src = block.source_tables_short
        found_src = seq.source_tables_short
        matched_src = expected_src & found_src
        result.source_table_coverage = len(matched_src) / len(expected_src) if expected_src else 1.0
        result.missing_source_tables = sorted(expected_src - found_src)
    else:
        result.source_table_coverage = 1.0 if seq.source_tables else 0.5

    # 3. Join Capture Accuracy
    if block.join_count > 0:
        # Find STTM joins that apply to this sequence
        seq_num = str(seq.sequence) if seq.sequence is not None else ''
        relevant_joins = [
            j for j in sttm_joins
            if not j.applies_to_sequence or j.applies_to_sequence == seq_num
               or j.join_id in seq.join_ids_used
        ]

        # Match by join table
        matched_join_tables = set()
        for jt in block.join_tables:
            jt_short = jt.split('.')[-1].upper()
            for sj in relevant_joins:
                sj_right_short = sj.right_table.split('.')[-1].upper()
                sj_left_short = sj.left_table.split('.')[-1].upper()
                if jt_short in (sj_right_short, sj_left_short):
                    matched_join_tables.add(jt_short)
                    result.matched_joins.append(f"{sj.join_id}: {jt_short}")
                    break

        result.join_capture = len(matched_join_tables) / block.join_count if block.join_count > 0 else 1.0
        unmatched = set(t.split('.')[-1] for t in block.join_tables) - matched_join_tables
        result.missing_joins = sorted(unmatched)
    else:
        result.join_capture = 1.0  # No joins expected

    # 4. Filter Capture Accuracy
    if block.has_where:
        seq_num = str(seq.sequence) if seq.sequence is not None else ''
        relevant_filters = [
            f for f in sttm_filters
            if not f.applies_to_sequence or f.applies_to_sequence == seq_num
               or f.filter_id in seq.filter_ids_used
        ]
        if relevant_filters:
            result.filter_capture = 1.0
        else:
            result.filter_capture = 0.0
            result.notes.append(f"WHERE not captured: {block.where_text[:80]}...")
    else:
        result.filter_capture = 1.0  # No filter expected

    # 5. Join ID Assignment
    if block.join_count > 0 and seq.row_count > 0:
        result.join_id_assignment = seq.rows_with_join_ids / seq.row_count
    elif block.join_count == 0:
        result.join_id_assignment = 1.0
    else:
        result.join_id_assignment = 0.0

    # 6. Filter ID Assignment
    if block.has_where and seq.row_count > 0:
        result.filter_id_assignment = seq.rows_with_filter_ids / seq.row_count
    elif not block.has_where:
        result.filter_id_assignment = 1.0
    else:
        result.filter_id_assignment = 0.0

    # Additional notes
    if block.has_union:
        result.notes.append(f"UNION with {block.union_branch_count} branches")
    if block.has_case:
        result.notes.append("Contains CASE expressions")
    if block.has_group_by:
        result.notes.append("Contains GROUP BY")

    return result


# ---------------------------------------------------------------------------
# Main Validator
# ---------------------------------------------------------------------------

class STTMAccuracyValidator:
    """
    Block-by-block accuracy validator for STTM structured XLSX vs source SQL.

    Usage:
        validator = STTMAccuracyValidator("path/to/proc.sql", "path/to/output_structured.xlsx")
        report = validator.validate()
        report.print_report()
    """

    def __init__(self, sql_path: str, xlsx_path: str):
        _sql_abs = _resolve_cli_path(sql_path, must_be_under=_PROJECT_ROOT)
        _xlsx_abs = _resolve_cli_path(xlsx_path, must_be_under=_PROJECT_ROOT)
        self.sql_path = safe_join(str(_sql_abs.parent), secure_filename(_sql_abs.name))
        self.xlsx_path = safe_join(str(_xlsx_abs.parent), secure_filename(_xlsx_abs.name))

    def validate(self) -> ValidationReport:
        """Run the full block-by-block validation and return a report."""
        # Read source SQL
        with open(self.sql_path, 'r', encoding='utf-8', errors='replace') as f:
            sql_text = f.read()

        # Strip banner headers (view files)
        sql_text_clean = re.sub(r'^[=]{3,}.*$', '', sql_text, flags=re.MULTILINE)
        sql_text_clean = re.sub(r'^\s*VIEW:\s+.*$', '', sql_text_clean, flags=re.MULTILINE)

        # Parse SQL blocks
        sql_blocks = _extract_sql_blocks(sql_text_clean)

        # Read STTM xlsx
        sequences, sttm_joins, sttm_filters = _read_sttm_xlsx(self.xlsx_path)

        # Match blocks to sequences
        matches = _match_blocks_to_sequences(sql_blocks, sequences)

        # Compare each matched pair
        block_results = []
        matched_seqs = set()
        for block, seq in matches:
            result = _compare_block(block, seq, sttm_joins, sttm_filters)
            block_results.append(result)
            if seq:
                matched_seqs.add(id(seq))

        # Unmatched
        unmatched_blocks = [b for b, s in matches if s is None]
        unmatched_seqs = [s for s in sequences if id(s) not in matched_seqs]

        # Compute aggregate score
        if block_results:
            scored = [r for r in block_results if r.matched_sequence is not None]
            if scored:
                overall = sum(r.overall_score for r in scored) / len(scored)
            else:
                overall = 0.0
            # Penalize unmatched blocks
            if unmatched_blocks:
                penalty = len(unmatched_blocks) / len(sql_blocks) * 20
                overall = max(overall - penalty, 0.0)
        else:
            overall = 0.0

        report = ValidationReport(
            sql_file=self.sql_path,
            xlsx_file=self.xlsx_path,
            sql_blocks=sql_blocks,
            sttm_sequences=sequences,
            sttm_joins=sttm_joins,
            sttm_filters=sttm_filters,
            block_results=block_results,
            unmatched_blocks=unmatched_blocks,
            unmatched_sequences=unmatched_seqs,
            overall_score=round(overall, 1),
            grade=_grade(overall),
            total_sql_blocks=len(sql_blocks),
            total_sttm_sequences=len(sequences),
            total_sql_joins=sum(b.join_count for b in sql_blocks),
            total_sttm_joins=len(sttm_joins),
            total_sql_filters=sum(1 for b in sql_blocks if b.has_where),
            total_sttm_filters=len(sttm_filters),
            total_sql_columns=sum(len(b.insert_columns) for b in sql_blocks),
            total_sttm_columns=sum(s.row_count for s in sequences),
        )

        return report


# ---------------------------------------------------------------------------
# Grading
# ---------------------------------------------------------------------------

def _grade(score: float) -> str:
    if score >= 95: return 'A+'
    if score >= 90: return 'A'
    if score >= 85: return 'A-'
    if score >= 80: return 'B+'
    if score >= 75: return 'B'
    if score >= 70: return 'B-'
    if score >= 65: return 'C+'
    if score >= 60: return 'C'
    if score >= 50: return 'D'
    return 'F'


# ---------------------------------------------------------------------------
# Report Printing
# ---------------------------------------------------------------------------

def _print_report(report: ValidationReport):
    """Print a formatted validation report."""
    w = 80
    print("=" * w)
    print("STTM ACCURACY VALIDATION REPORT")
    print("=" * w)
    print(f"  SQL File:  {report.sql_file}")
    print(f"  XLSX File: {report.xlsx_file}")
    print()

    # Summary
    print(f"  {'SQL Blocks:':<30} {report.total_sql_blocks}")
    print(f"  {'STTM Sequences:':<30} {report.total_sttm_sequences}")
    print(f"  {'SQL JOIN clauses:':<30} {report.total_sql_joins}")
    print(f"  {'STTM Join Conditions:':<30} {report.total_sttm_joins}")
    print(f"  {'SQL WHERE clauses:':<30} {report.total_sql_filters}")
    print(f"  {'STTM Filter Conditions:':<30} {report.total_sttm_filters}")
    print(f"  {'SQL Target Columns:':<30} {report.total_sql_columns}")
    print(f"  {'STTM Mapping Rows:':<30} {report.total_sttm_columns}")
    print()
    print(f"  OVERALL SCORE: {report.overall_score:.1f}  [{report.grade}]")
    print("=" * w)

    # Block-by-block detail
    print()
    print("BLOCK-BY-BLOCK ANALYSIS")
    print("-" * w)

    dim_labels = ['ColMap', 'SrcTbl', 'JoinCap', 'FiltCap', 'JoinID', 'FiltID', 'SCORE']
    header = f"  {'#':>2} {'DML':<8} {'Target Table':<35} " + " ".join(f"{d:>7}" for d in dim_labels)
    print(header)
    print("  " + "-" * (len(header) - 2))

    for result in report.block_results:
        b = result.block
        seq = result.matched_sequence
        seq_label = f"Seq {seq.sequence}" if seq and seq.sequence else "(unmatched)"
        target = b.target_table_short[:35]

        scores = [
            f"{result.column_coverage * 100:>5.0f}%",
            f"{result.source_table_coverage * 100:>5.0f}%",
            f"{result.join_capture * 100:>5.0f}%",
            f"{result.filter_capture * 100:>5.0f}%",
            f"{result.join_id_assignment * 100:>5.0f}%",
            f"{result.filter_id_assignment * 100:>5.0f}%",
            f"{result.overall_score:>5.1f}",
        ]
        line = f"  {b.block_index:>2} {b.dml_type:<8} {target:<35} " + " ".join(f"{s:>7}" for s in scores)
        print(line)

    # Detail on problems
    print()
    print("DETAILED FINDINGS")
    print("-" * w)

    for result in report.block_results:
        b = result.block
        issues = []
        if result.missing_columns:
            issues.append(f"Missing columns ({len(result.missing_columns)}): {', '.join(result.missing_columns[:10])}")
        if result.missing_source_tables:
            issues.append(f"Missing source tables: {', '.join(result.missing_source_tables[:5])}")
        if result.missing_joins:
            issues.append(f"Missing joins on: {', '.join(result.missing_joins[:5])}")
        if result.filter_capture < 1.0 and b.has_where:
            issues.append(f"WHERE not captured")
        if result.join_id_assignment < 1.0 and b.join_count > 0:
            pct = result.join_id_assignment * 100
            issues.append(f"Join IDs assigned to {pct:.0f}% of rows")
        if result.filter_id_assignment < 1.0 and b.has_where:
            pct = result.filter_id_assignment * 100
            issues.append(f"Filter IDs assigned to {pct:.0f}% of rows")
        for note in result.notes:
            issues.append(note)

        if issues:
            print(f"\n  Block {b.block_index} [{b.dml_type}] -> {b.target_table_short} (line {b.line_start}-{b.line_end}):")
            for issue in issues:
                flag = " <<<" if any(kw in issue.lower() for kw in ['missing', 'not captured', '0%']) else ""
                print(f"    - {issue}{flag}")

    if report.unmatched_blocks:
        print(f"\n  UNMATCHED SQL BLOCKS ({len(report.unmatched_blocks)}):")
        for b in report.unmatched_blocks:
            print(f"    - Block {b.block_index}: {b.dml_type} -> {b.target_table_short} (line {b.line_start})")

    if report.unmatched_sequences:
        print(f"\n  UNMATCHED STTM SEQUENCES ({len(report.unmatched_sequences)}):")
        for s in report.unmatched_sequences:
            print(f"    - Seq {s.sequence}: {s.operator_type} -> {s.target_table_short} ({s.row_count} rows)")

    print()
    print("=" * w)
    print(f"  FINAL SCORE: {report.overall_score:.1f} / 100  [{report.grade}]")
    print("=" * w)


def _report_to_dict(report: ValidationReport) -> dict:
    """Convert a ValidationReport to a JSON-serializable dict."""
    return {
        'sql_file': report.sql_file,
        'xlsx_file': report.xlsx_file,
        'overall_score': report.overall_score,
        'grade': report.grade,
        'summary': {
            'sql_blocks': report.total_sql_blocks,
            'sttm_sequences': report.total_sttm_sequences,
            'sql_joins': report.total_sql_joins,
            'sttm_joins': report.total_sttm_joins,
            'sql_filters': report.total_sql_filters,
            'sttm_filters': report.total_sttm_filters,
            'sql_columns': report.total_sql_columns,
            'sttm_mapping_rows': report.total_sttm_columns,
        },
        'blocks': [
            {
                'block_index': r.block.block_index,
                'dml_type': r.block.dml_type,
                'target_table': r.block.target_table,
                'line_range': f"{r.block.line_start}-{r.block.line_end}",
                'sql_join_count': r.block.join_count,
                'sql_has_where': r.block.has_where,
                'sql_column_count': len(r.block.insert_columns),
                'sql_source_tables': sorted(r.block.source_tables_short),
                'matched_sequence': r.matched_sequence.sequence if r.matched_sequence else None,
                'sttm_row_count': r.matched_sequence.row_count if r.matched_sequence else 0,
                'scores': {
                    'column_coverage': round(r.column_coverage * 100, 1),
                    'source_table_coverage': round(r.source_table_coverage * 100, 1),
                    'join_capture': round(r.join_capture * 100, 1),
                    'filter_capture': round(r.filter_capture * 100, 1),
                    'join_id_assignment': round(r.join_id_assignment * 100, 1),
                    'filter_id_assignment': round(r.filter_id_assignment * 100, 1),
                    'overall': r.overall_score,
                },
                'missing_columns': r.missing_columns,
                'missing_source_tables': r.missing_source_tables,
                'missing_joins': r.missing_joins,
                'notes': r.notes,
            }
            for r in report.block_results
        ],
        'unmatched_sql_blocks': [
            {'index': b.block_index, 'dml_type': b.dml_type, 'target': b.target_table_short}
            for b in report.unmatched_blocks
        ],
        'unmatched_sttm_sequences': [
            {'sequence': s.sequence, 'op': s.operator_type, 'target': s.target_table_short}
            for s in report.unmatched_sequences
        ],
    }


# ---------------------------------------------------------------------------
# CLI Entry Point
# ---------------------------------------------------------------------------

def main():
    """CLI entry point for standalone use."""
    import argparse
    import json

    parser = argparse.ArgumentParser(
        description="STTM Accuracy Validator — block-by-block comparison of XLSX vs SQL"
    )
    parser.add_argument('sql_file', help='Path to source SQL file')
    parser.add_argument('xlsx_file', help='Path to structured XLSX output')
    parser.add_argument('--json', dest='json_output', metavar='PATH',
                        help='Write JSON report to file')
    parser.add_argument('--quiet', '-q', action='store_true',
                        help='Only print the final score line')
    args = parser.parse_args()

    validator = STTMAccuracyValidator(args.sql_file, args.xlsx_file)
    report = validator.validate()

    if args.quiet:
        print(f"{Path(args.sql_file).stem}: {report.overall_score:.1f} [{report.grade}]")
    else:
        report.print_report()

    if args.json_output:
        _abs = _resolve_cli_path(args.json_output, must_be_under=_PROJECT_ROOT)
        args.json_output = safe_join(str(_abs.parent), secure_filename(_abs.name))
        with open(args.json_output, 'w', encoding='utf-8') as f:
            json.dump(report.to_dict(), f, indent=2)
        print(f"\nJSON report written to: {args.json_output}")


if __name__ == '__main__':
    main()
