"""
STTM Validator — validates structured XLSX/JSON output against source SQL.

Checks:
  1. DML Coverage       — are all INSERT/UPDATE/DELETE/SELECT INTO/CREATE VT captured?
  2. Target Tables      — do captured target tables match what's in the SQL?
  3. Source Tables      — do captured source tables match FROM/JOIN tables in SQL?
  4. Column Accuracy    — do UPDATE SET cols appear correctly as target columns?
  5. Join Coverage      — are all JOINs in SQL captured in Join Conditions?
  6. Filter Coverage    — are all WHERE clauses captured in Filter Conditions?
  7. Alias Integrity    — no raw aliases leak as source/target table names
  8. Control Flow       — are IF/ELSE blocks detected?
  9. CF Scope Accuracy  — control flow context only on statements inside IF blocks

Produces per-file validation results and a batch summary report.
"""

import json
import os
import re
from dataclasses import dataclass, field
from typing import List, Dict, Optional
from datetime import datetime


@dataclass
class CheckResult:
    """Result for a single validation check."""
    check_name: str
    score: float  # 0.0 to 1.0
    expected: int = 0
    found: int = 0
    missing: List[str] = field(default_factory=list)
    extra: List[str] = field(default_factory=list)
    details: str = ""


@dataclass
class FileValidationResult:
    """Validation results for one SP file."""
    file_name: str
    sql_path: str
    sttm_path: str
    checks: List[CheckResult] = field(default_factory=list)
    overall_score: float = 0.0
    timestamp: str = ""

    def to_dict(self) -> dict:
        return {
            "file_name": self.file_name,
            "sql_path": self.sql_path,
            "sttm_path": self.sttm_path,
            "overall_score": round(self.overall_score, 2),
            "checks": [
                {
                    "check_name": c.check_name,
                    "score": round(c.score, 2),
                    "expected": c.expected,
                    "found": c.found,
                    "missing": c.missing,
                    "extra": c.extra,
                    "details": c.details,
                }
                for c in self.checks
            ],
            "timestamp": self.timestamp,
        }


@dataclass
class BatchValidationReport:
    """Validation report for an entire batch run."""
    results: List[FileValidationResult] = field(default_factory=list)
    batch_score: float = 0.0
    timestamp: str = ""

    def to_dict(self) -> dict:
        return {
            "batch_score": round(self.batch_score, 2),
            "total_files": len(self.results),
            "timestamp": self.timestamp,
            "per_file": [r.to_dict() for r in self.results],
        }


class STTMValidator:
    """Validates STTM output against source SQL."""

    def __init__(self):
        self._results: List[FileValidationResult] = []

    def validate_file(self, sql_path: str, sttm_json_path: str) -> FileValidationResult:
        """Validate a single SP's STTM output against its source SQL."""
        with open(sql_path, 'r', encoding='utf-8', errors='replace') as f:
            raw_sql = f.read()
        with open(sttm_json_path, 'r', encoding='utf-8') as f:
            sttm = json.load(f)

        clean_sql = self._strip_comments(raw_sql)

        checks = []
        checks.append(self._check_dml_coverage(clean_sql, sttm))
        checks.append(self._check_target_tables(clean_sql, sttm))
        checks.append(self._check_source_tables(clean_sql, sttm))
        checks.append(self._check_update_set_columns(clean_sql, sttm))
        checks.append(self._check_join_coverage(clean_sql, sttm))
        checks.append(self._check_filter_coverage(clean_sql, sttm))
        checks.append(self._check_alias_integrity(sttm))
        checks.append(self._check_control_flow(clean_sql, sttm))
        checks.append(self._check_cf_scope_accuracy(raw_sql, sttm))

        weights = {
            "DML Coverage": 2.0,
            "Target Tables": 1.5,
            "Source Tables": 1.5,
            "UPDATE SET Columns": 1.5,
            "Join Coverage": 1.0,
            "Filter Coverage": 1.0,
            "Alias Integrity": 1.0,
            "Control Flow": 0.5,
            "CF Scope Accuracy": 1.5,
        }
        total_weight = sum(weights.get(c.check_name, 1.0) for c in checks)
        weighted_sum = sum(c.score * weights.get(c.check_name, 1.0) for c in checks)
        overall = weighted_sum / total_weight if total_weight > 0 else 0.0

        result = FileValidationResult(
            file_name=os.path.basename(sql_path),
            sql_path=sql_path,
            sttm_path=sttm_json_path,
            checks=checks,
            overall_score=overall,
            timestamp=datetime.now().isoformat(),
        )
        self._results.append(result)
        return result

    def get_batch_report(self) -> BatchValidationReport:
        """Generate batch validation report from all validated files."""
        if not self._results:
            return BatchValidationReport(timestamp=datetime.now().isoformat())
        batch_score = sum(r.overall_score for r in self._results) / len(self._results)
        return BatchValidationReport(
            results=self._results,
            batch_score=batch_score,
            timestamp=datetime.now().isoformat(),
        )

    def write_report(self, output_path: str) -> str:
        """Write batch validation report as JSON."""
        report = self.get_batch_report()
        report_path = os.path.join(output_path, "validation_report.json")
        with open(report_path, 'w', encoding='utf-8') as f:
            json.dump(report.to_dict(), f, indent=2)
        return report_path

    def print_summary(self):
        """Print a concise summary table to stdout."""
        report = self.get_batch_report()
        print(f"\n{'='*90}")
        print("VALIDATION REPORT")
        print(f"{'='*90}")
        print(f"{'File':<50} {'Score':>6} {'DML':>5} {'Tgt':>5} {'Src':>5} {'SET':>5} {'Join':>5} {'Fltr':>5} {'Alia':>5} {'CF':>5} {'CFS':>5}")
        print(f"{'-'*50} {'-':->6} {'-':->5} {'-':->5} {'-':->5} {'-':->5} {'-':->5} {'-':->5} {'-':->5} {'-':->5} {'-':->5}")

        for r in report.results:
            cs = {c.check_name: c.score for c in r.checks}
            name = r.file_name[:49]
            print(
                f"{name:<50} "
                f"{r.overall_score:>5.0%} "
                f"{cs.get('DML Coverage', 0):>4.0%} "
                f"{cs.get('Target Tables', 0):>4.0%} "
                f"{cs.get('Source Tables', 0):>4.0%} "
                f"{cs.get('UPDATE SET Columns', 0):>4.0%} "
                f"{cs.get('Join Coverage', 0):>4.0%} "
                f"{cs.get('Filter Coverage', 0):>4.0%} "
                f"{cs.get('Alias Integrity', 0):>4.0%} "
                f"{cs.get('Control Flow', 0):>4.0%} "
                f"{cs.get('CF Scope Accuracy', 0):>4.0%}"
            )

        print(f"{'-'*50} {'-':->6}")
        print(f"{'BATCH AVERAGE':<50} {report.batch_score:>5.0%}")
        print(f"{'='*90}\n")

    # -------------------------------------------------------------------------
    # Individual checks
    # -------------------------------------------------------------------------

    def _check_dml_coverage(self, sql: str, sttm: dict) -> CheckResult:
        """Check that all DML statement types in SQL are captured."""
        sql_dmls = set()
        for pat, dml_type in [
            (r'\bINSERT\s+INTO\s+([\w.]+)', 'INSERT'),
            (r'\bDELETE\s+FROM\s+([\w.]+)', 'DELETE'),
            (r'\bUPDATE\s+([\w.]+)', 'UPDATE'),
            (r'\bSELECT\b.+?\bINTO\s+(\w+)\s+FROM', 'SELECT INTO'),
            (r'\bCREATE\s+(?:MULTISET\s+)?VOLATILE\s+TABLE\s+([\w.#]+)', 'CREATE VT'),
        ]:
            for match in re.finditer(pat, sql, re.IGNORECASE | re.DOTALL):
                tbl = match.group(1).upper()
                if dml_type == 'UPDATE':
                    pre = sql[max(0, match.start() - 20):match.start()].strip().upper()
                    if pre.endswith('COLLECT'):
                        continue
                sql_dmls.add((dml_type, tbl.split('.')[-1]))

        captured = set()
        for m in sttm.get('column_mappings', []):
            op = (m.get('operator_type', '') or '').upper()
            tgt = (m.get('target_table', '') or '').upper()
            if op and tgt:
                norm_op = op
                if 'INSERT' in op: norm_op = 'INSERT'
                elif 'DELETE' in op: norm_op = 'DELETE'
                elif 'UPDATE' in op: norm_op = 'UPDATE'
                elif 'SELECT INTO' in op: norm_op = 'SELECT INTO'
                elif 'CREATE' in op: norm_op = 'CREATE VT'
                captured.add((norm_op, tgt.split('.')[-1]))

        found = len(sql_dmls & captured)
        expected = len(sql_dmls)
        missing = sorted([f"{d}→{t}" for d, t in sql_dmls - captured])
        score = found / expected if expected > 0 else 1.0
        return CheckResult("DML Coverage", score, expected, found, missing,
                           details=f"{found}/{expected} DML statements captured")

    def _check_target_tables(self, sql: str, sttm: dict) -> CheckResult:
        """Check that all target tables from DML are in the STTM."""
        sql_targets = set()
        for pat in [
            r'\bINSERT\s+INTO\s+([\w.]+)',
            r'\bDELETE\s+FROM\s+([\w.]+)',
            r'\bUPDATE\s+([\w.]+)',
            r'\bCREATE\s+(?:MULTISET\s+)?VOLATILE\s+TABLE\s+([\w.#]+)',
        ]:
            for m in re.finditer(pat, sql, re.IGNORECASE):
                tbl = m.group(1)
                if 'UPDATE' in pat:
                    pre = sql[max(0, m.start() - 20):m.start()].strip().upper()
                    if pre.endswith('COLLECT'):
                        continue
                sql_targets.add(tbl.split('.')[-1].upper())

        sttm_targets = set()
        for m in sttm.get('column_mappings', []):
            tgt = m.get('target_table', '')
            if tgt and not m.get('is_subquery_decomposition', False):
                sttm_targets.add(tgt.split('.')[-1].upper())

        found = len(sql_targets & sttm_targets)
        expected = len(sql_targets)
        missing = sorted(sql_targets - sttm_targets)
        score = found / expected if expected > 0 else 1.0
        return CheckResult("Target Tables", score, expected, found, missing,
                           details=f"{found}/{expected} target tables captured")

    def _check_source_tables(self, sql: str, sttm: dict) -> CheckResult:
        """Check that source tables from FROM/JOIN clauses appear in STTM."""
        sql_sources = set()
        skip_kw = {'SELECT', 'WHERE', 'SET', 'INTO', 'VALUES', 'UPDATE',
                    'DELETE', 'INSERT', 'CREATE', 'TABLE', 'AS', 'ON',
                    'AND', 'OR', 'NOT', 'NULL', 'THEN', 'WHEN', 'CASE',
                    'ELSE', 'END', 'GROUP', 'ORDER', 'HAVING', 'UNION',
                    'ALL', 'DISTINCT', 'EXISTS', 'IN', 'BETWEEN', 'LIKE'}
        for m in re.finditer(r'\b(?:FROM|JOIN)\s+([\w]+\.[\w]+|[\w]+)', sql, re.IGNORECASE):
            tbl = m.group(1).upper()
            if tbl not in skip_kw:
                sql_sources.add(tbl.split('.')[-1])

        sttm_sources = set()
        for m in sttm.get('column_mappings', []):
            src = m.get('source_table', '')
            if src and not m.get('is_subquery_decomposition', False):
                sttm_sources.add(src.split('.')[-1].upper())
        for st in sttm.get('metadata', {}).get('source_tables', []):
            sttm_sources.add(st.split('.')[-1].upper())

        found = len(sql_sources & sttm_sources)
        expected = len(sql_sources)
        missing = sorted(sql_sources - sttm_sources)
        score = found / expected if expected > 0 else 1.0
        return CheckResult("Source Tables", score, expected, found, missing,
                           details=f"{found}/{expected} source tables captured")

    def _check_update_set_columns(self, sql: str, sttm: dict) -> CheckResult:
        """Check that UPDATE SET clause columns appear as target columns."""
        expected_cols = set()
        for m in re.finditer(
            r'\bUPDATE\s+[\w.]+\s+.*?\bSET\s+(.+?)(?:\bWHERE\b|\bFROM\b|;)',
            sql, re.IGNORECASE | re.DOTALL
        ):
            for col_m in re.finditer(r'(\w+)\s*=', m.group(1)):
                expected_cols.add(col_m.group(1).upper())

        if not expected_cols:
            return CheckResult("UPDATE SET Columns", 1.0, details="No UPDATE statements — N/A")

        sttm_update_cols = set()
        for m in sttm.get('column_mappings', []):
            if (m.get('operator_type', '') or '').upper() == 'UPDATE':
                col = (m.get('target_column', '') or '').upper()
                if col and col != '*':
                    sttm_update_cols.add(col)

        found = len(expected_cols & sttm_update_cols)
        expected = len(expected_cols)
        missing = sorted(expected_cols - sttm_update_cols)
        score = found / expected if expected > 0 else 1.0
        return CheckResult("UPDATE SET Columns", score, expected, found, missing,
                           details=f"{found}/{expected} SET columns captured")

    def _check_join_coverage(self, sql: str, sttm: dict) -> CheckResult:
        """Check that JOINs in SQL are captured in STTM join_conditions."""
        join_count_sql = len(re.findall(
            r'\b(?:INNER|LEFT|RIGHT|FULL|CROSS)?\s*(?:OUTER\s+)?JOIN\b', sql, re.IGNORECASE))
        join_count_sttm = len(sttm.get('join_conditions', []))
        if join_count_sql == 0:
            return CheckResult("Join Coverage", 1.0, details="No JOINs — N/A")
        score = min(join_count_sttm / join_count_sql, 1.0)
        return CheckResult("Join Coverage", score, join_count_sql, join_count_sttm,
                           details=f"{join_count_sttm}/{join_count_sql} JOINs captured")

    def _check_filter_coverage(self, sql: str, sttm: dict) -> CheckResult:
        """Check that WHERE clauses in SQL are captured."""
        where_count_sql = len(re.findall(r'\bWHERE\b', sql, re.IGNORECASE))
        filter_count_sttm = len(sttm.get('filter_conditions', []))
        if where_count_sql == 0:
            return CheckResult("Filter Coverage", 1.0, details="No WHERE clauses — N/A")
        score = min(filter_count_sttm / where_count_sql, 1.0)
        return CheckResult("Filter Coverage", score, where_count_sql, filter_count_sttm,
                           details=f"{filter_count_sttm}/{where_count_sql} WHERE clauses captured")

    def _check_alias_integrity(self, sttm: dict) -> CheckResult:
        """Check that source/target tables are not raw aliases."""
        alias_pattern = re.compile(r'^[A-Z_]{1,3}$')
        alias_leaks = []
        for i, m in enumerate(sttm.get('column_mappings', [])):
            if m.get('is_subquery_decomposition', False):
                continue
            for label, key in [('SrcTbl', 'source_table'), ('TgtTbl', 'target_table')]:
                val = m.get(key, '') or ''
                if val and alias_pattern.match(val.upper()) and '.' not in val:
                    alias_leaks.append(f"Row {i+2}: {label}='{val}'")
        total = sum(1 for m in sttm.get('column_mappings', []) if not m.get('is_subquery_decomposition', False))
        score = max(0.0, 1.0 - (len(alias_leaks) / max(total, 1)))
        return CheckResult("Alias Integrity", score, 0, len(alias_leaks), alias_leaks[:10],
                           details=f"{len(alias_leaks)} alias leaks in {total} rows")

    def _check_control_flow(self, sql: str, sttm: dict) -> CheckResult:
        """Check that IF/ELSE blocks are detected."""
        if_count = len(re.findall(r'\bIF\b\s+', sql, re.IGNORECASE))
        cf_count = len(sttm.get('control_flow', []))
        if if_count == 0:
            return CheckResult("Control Flow", 1.0, details="No IF blocks — N/A")
        score = min(cf_count / if_count, 1.0)
        return CheckResult("Control Flow", score, if_count, cf_count,
                           details=f"{cf_count}/{if_count} control flow blocks captured")

    def _check_cf_scope_accuracy(self, raw_sql: str, sttm: dict) -> CheckResult:
        """
        Check that control flow context is only applied to DML statements
        that are actually inside the IF block, not to subsequent unconditional
        statements that share the same target table.

        Pattern: IF...THEN DELETE FROM T; END IF; INSERT INTO T;
        The INSERT should NOT have the IF's control flow context.
        """
        control_flow = sttm.get('control_flow', [])
        if not control_flow:
            return CheckResult("CF Scope Accuracy", 1.0, details="No control flow — N/A")

        # Parse IF block line ranges
        block_ranges = {}  # block_id -> (start_line, end_line)
        for block in control_flow:
            lr = block.get('line_range', '')
            m = re.match(r'L(\d+)-L(\d+)', lr)
            if m:
                block_ranges[block.get('block_id', '')] = (int(m.group(1)), int(m.group(2)))

        if not block_ranges:
            return CheckResult("CF Scope Accuracy", 1.0, details="No parseable line ranges — N/A")

        # Read source to find DML positions
        lines = raw_sql.split('\n')
        sql_upper = raw_sql.upper()

        # For each column mapping with CF context, verify its DML is inside the IF range
        over_applied = []
        total_cf_rows = 0
        mappings = sttm.get('column_mappings', [])

        # Group by sequence to check once per DML statement
        seq_cf = {}  # seq -> cf_context string
        seq_target = {}  # seq -> target_table
        seq_op = {}  # seq -> operator_type
        for m in mappings:
            seq = m.get('dml_sequence')
            if seq is None:
                continue
            cf = m.get('control_flow_context', '') or ''
            if cf:
                seq_cf[seq] = cf
                seq_target[seq] = m.get('target_table', '')
                seq_op[seq] = m.get('operator_type', '')

        total_cf_rows = sum(
            1 for m in mappings
            if (m.get('control_flow_context', '') or '') != ''
        )

        # For each CF-tagged sequence, extract the block_id from context
        # and verify the DML target+type can be found inside that block's line range
        for seq, cf_text in seq_cf.items():
            # Extract block_id(s) from CF text like "CF-1: IF ..."
            for bid_match in re.finditer(r'(CF-\d+)', cf_text):
                bid = bid_match.group(1)
                if bid not in block_ranges:
                    continue
                start_l, end_l = block_ranges[bid]
                block_text = '\n'.join(lines[start_l - 1:end_l]).upper()

                # Check if the target table + DML type appears in block text
                tgt = (seq_target.get(seq, '') or '').split('.')[-1].upper()
                op = (seq_op.get(seq, '') or '').upper()
                if not tgt:
                    continue

                found_in_block = False
                if 'INSERT' in op and re.search(r'INSERT\s+INTO\s+[\w.]*' + re.escape(tgt), block_text):
                    found_in_block = True
                elif 'DELETE' in op and re.search(r'DELETE\s+FROM\s+[\w.]*' + re.escape(tgt), block_text):
                    found_in_block = True
                elif 'UPDATE' in op and re.search(r'UPDATE\s+[\w.]*' + re.escape(tgt), block_text):
                    found_in_block = True
                elif 'SELECT' in op and re.search(r'INTO\s+' + re.escape(tgt), block_text):
                    found_in_block = True

                if not found_in_block:
                    count = sum(1 for m in mappings if m.get('dml_sequence') == seq)
                    over_applied.append(
                        f"Seq {seq} ({op}→{tgt}, {count} rows) tagged with {bid} but not inside {bid} range L{start_l}-L{end_l}"
                    )

        if not over_applied:
            score = 1.0
        else:
            # Score based on how many rows are incorrectly tagged
            bad_rows = 0
            for detail in over_applied:
                m = re.search(r'(\d+) rows\)', detail)
                if m:
                    bad_rows += int(m.group(1))
            total = len(mappings)
            score = max(0.0, 1.0 - (bad_rows / max(total, 1)))

        return CheckResult(
            "CF Scope Accuracy", score, 0, len(over_applied), over_applied,
            details=f"{len(over_applied)} over-applied CF blocks" if over_applied else "All CF contexts correctly scoped"
        )

    # -------------------------------------------------------------------------
    # Helpers
    # -------------------------------------------------------------------------

    def _strip_comments(self, sql: str) -> str:
        """Remove SQL comments (block and line)."""
        sql = re.sub(r'/\*.*?\*/', '', sql, flags=re.DOTALL)
        sql = re.sub(r'--[^\n]*', '', sql)
        return sql
