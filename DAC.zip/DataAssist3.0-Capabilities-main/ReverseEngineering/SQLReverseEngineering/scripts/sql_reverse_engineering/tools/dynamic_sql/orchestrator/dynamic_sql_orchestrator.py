"""
Dynamic SQL Orchestrator.

Main coordinator for multi-expert dynamic SQL analysis.
Manages expert execution, parallel processing, conflict resolution,
and collaborative refinement.
"""

from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import Any, Dict, List, Optional, Tuple
from dataclasses import dataclass, field
from datetime import datetime

import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

from dynamic_sql.expert_models.data_models import (
    DynamicSQLExpertType,
    DynamicSQLExpertOutput
)
from dynamic_sql.expert_models.context_models import DynamicSQLContext
from dynamic_sql.experts import (
    PatternDetectionExpert,
    VariableTrackingExpert,
    ControlFlowExpert,
    ReconstructionExpert,
    ValidationExpert
)
from dynamic_sql.orchestrator.conflict_resolver import ConflictResolver, ConflictResolutionStrategy
from dynamic_sql.orchestrator.confidence_calculator import ConfidenceCalculator
from dynamic_sql.orchestrator.provenance_tracker import ProvenanceTracker


@dataclass
class OrchestratorResult:
    """Result from the orchestrator."""
    success: bool
    reconstructed_statements: List[Dict[str, Any]]
    fully_resolved_sql: List[str]
    all_sql: List[str]
    combined_confidence: float
    expert_outputs: Dict[str, DynamicSQLExpertOutput]
    provenance: Dict[str, Any]
    conflicts: Dict[str, Any]
    warnings: List[str]
    errors: List[str]
    execution_time_ms: float
    iterations: int


class DynamicSQLOrchestrator:
    """
    Orchestrator for multi-expert dynamic SQL analysis.

    Coordinates:
    1. Sequential and parallel expert execution
    2. Shared context management
    3. Conflict detection and resolution
    4. Collaborative refinement
    5. Provenance tracking

    Execution Flow:
    1. PatternDetectionExpert (first, no dependencies)
    2. VariableTrackingExpert + ControlFlowExpert (parallel, both depend on patterns)
    3. ReconstructionExpert (depends on variable tracking + control flow)
    4. ValidationExpert (depends on reconstruction)
    5. Refinement loop if needed (up to max_iterations)
    """

    MAX_ITERATIONS = 3
    CONFIDENCE_THRESHOLD = 0.7

    def __init__(self, dialect: str = "tsql",
                 enable_parallel: bool = True,
                 enable_refinement: bool = True,
                 enable_provenance: bool = True):
        """
        Initialize the orchestrator.

        Args:
            dialect: SQL dialect (tsql, teradata, oracle)
            enable_parallel: Enable parallel expert execution
            enable_refinement: Enable collaborative refinement
            enable_provenance: Enable provenance tracking
        """
        self.dialect = dialect.lower()
        self.enable_parallel = enable_parallel
        self.enable_refinement = enable_refinement
        self.enable_provenance = enable_provenance

        # Initialize experts
        self._init_experts()

        # Initialize components
        self.conflict_resolver = ConflictResolver()
        self.confidence_calculator = ConfidenceCalculator()
        self.provenance_tracker: Optional[ProvenanceTracker] = None

        # Execution state
        self._context: Optional[DynamicSQLContext] = None
        self._outputs: Dict[str, DynamicSQLExpertOutput] = {}
        self._start_time: Optional[datetime] = None

    def _init_experts(self) -> None:
        """Initialize all expert agents."""
        self.pattern_expert = PatternDetectionExpert(self.dialect)
        self.variable_expert = VariableTrackingExpert(self.dialect)
        self.control_flow_expert = ControlFlowExpert(self.dialect)
        self.reconstruction_expert = ReconstructionExpert(self.dialect)
        self.validation_expert = ValidationExpert(self.dialect)

        self.experts = {
            'PatternDetectionExpert': self.pattern_expert,
            'VariableTrackingExpert': self.variable_expert,
            'ControlFlowExpert': self.control_flow_expert,
            'ReconstructionExpert': self.reconstruction_expert,
            'ValidationExpert': self.validation_expert
        }

    def analyze(self, sql: str, procedure_name: Optional[str] = None) -> OrchestratorResult:
        """
        Analyze dynamic SQL using the multi-expert architecture.

        Args:
            sql: SQL text to analyze (stored procedure body)
            procedure_name: Optional name for provenance tracking

        Returns:
            OrchestratorResult with all analysis results
        """
        self._start_time = datetime.now()
        self._outputs = {}

        # Initialize context
        self._context = DynamicSQLContext(
            sql_text=sql,
            dialect=self.dialect,
            procedure_name=procedure_name
        )

        # Initialize provenance tracking
        if self.enable_provenance:
            self.provenance_tracker = ProvenanceTracker(procedure_name)
            self.provenance_tracker.start_analysis(sql, self.dialect)

        warnings = []
        errors = []
        iteration = 0

        try:
            # Phase 1: Pattern Detection (runs first)
            self._run_pattern_detection()

            # Check if any patterns found
            if not self._context.detected_patterns:
                return self._create_result(
                    success=True,
                    warnings=["No dynamic SQL patterns detected"],
                    iteration=0
                )

            # Phase 2: Variable Tracking + Control Flow (parallel if enabled)
            self._run_parallel_experts()

            # Phase 3: Reconstruction
            self._run_reconstruction()

            # Phase 4: Validation
            self._run_validation()

            # Phase 5: Collaborative Refinement (if enabled)
            if self.enable_refinement:
                iteration = self._run_refinement_loop()

            # Resolve any conflicts
            conflicts = self.conflict_resolver.resolve_all_conflicts(self._outputs)

            # Calculate final confidence
            combined_confidence = self.confidence_calculator.calculate_combined_confidence(
                self._outputs
            )

            # Collect warnings from all experts
            for output in self._outputs.values():
                warnings.extend(output.warnings)
                errors.extend(output.errors)

            # Complete provenance tracking
            if self.enable_provenance and self.provenance_tracker:
                recon_output = self._outputs.get('ReconstructionExpert')
                total_stmts = recon_output.data.get('reconstructed_count', 0) if recon_output else 0
                fully_resolved = recon_output.data.get('fully_resolved_count', 0) if recon_output else 0
                self.provenance_tracker.complete_analysis(
                    combined_confidence, total_stmts, fully_resolved
                )

            return self._create_result(
                success=True,
                warnings=warnings,
                errors=errors,
                iteration=iteration,
                conflicts=conflicts
            )

        except Exception as e:
            errors.append(f"Orchestrator error: {str(e)}")
            return self._create_result(
                success=False,
                warnings=warnings,
                errors=errors,
                iteration=iteration
            )

    def _run_pattern_detection(self) -> None:
        """Run the pattern detection expert."""
        if self.enable_provenance and self.provenance_tracker:
            self.provenance_tracker.record_expert_start(
                'PatternDetectionExpert',
                DynamicSQLExpertType.PATTERN_DETECTION
            )

        output = self.pattern_expert.analyze(self._context.sql_text)
        self._outputs['PatternDetectionExpert'] = output

        if output.success:
            # Update context with detected patterns
            self._context.detected_patterns = output.context_updates.get(
                'detected_patterns', []
            )

        if self.enable_provenance and self.provenance_tracker:
            self.provenance_tracker.record_expert_output(output)

    def _run_parallel_experts(self) -> None:
        """Run variable tracking and control flow experts in parallel."""
        if self.enable_parallel:
            self._run_experts_parallel([
                ('VariableTrackingExpert', self.variable_expert),
                ('ControlFlowExpert', self.control_flow_expert)
            ])
        else:
            self._run_expert_with_context('VariableTrackingExpert', self.variable_expert)
            self._run_expert_with_context('ControlFlowExpert', self.control_flow_expert)

    def _run_experts_parallel(self, experts: List[Tuple[str, Any]]) -> None:
        """Run multiple experts in parallel using ThreadPoolExecutor."""
        with ThreadPoolExecutor(max_workers=len(experts)) as executor:
            futures = {}

            for name, expert in experts:
                if self.enable_provenance and self.provenance_tracker:
                    self.provenance_tracker.record_expert_start(
                        name, expert.expert_type
                    )

                future = executor.submit(
                    expert.analyze_with_context,
                    self._context
                )
                futures[future] = name

            for future in as_completed(futures):
                name = futures[future]
                try:
                    output = future.result()
                    self._outputs[name] = output

                    # Update context with output
                    self._apply_context_updates(output)

                    if self.enable_provenance and self.provenance_tracker:
                        self.provenance_tracker.record_expert_output(output)

                except Exception as e:
                    # Create error output
                    expert = self.experts[name]
                    error_output = DynamicSQLExpertOutput(
                        expert_name=name,
                        expert_type=expert.expert_type,
                        success=False,
                        data={},
                        errors=[str(e)],
                        confidence=0.0,
                        execution_time_ms=0.0
                    )
                    self._outputs[name] = error_output

    def _run_expert_with_context(self, name: str, expert: Any) -> None:
        """Run a single expert with context."""
        if self.enable_provenance and self.provenance_tracker:
            self.provenance_tracker.record_expert_start(name, expert.expert_type)

        output = expert.analyze_with_context(self._context)
        self._outputs[name] = output

        # Update context
        self._apply_context_updates(output)

        if self.enable_provenance and self.provenance_tracker:
            self.provenance_tracker.record_expert_output(output)

    def _run_reconstruction(self) -> None:
        """Run the reconstruction expert."""
        self._run_expert_with_context('ReconstructionExpert', self.reconstruction_expert)

    def _run_validation(self) -> None:
        """Run the validation expert."""
        self._run_expert_with_context('ValidationExpert', self.validation_expert)

    def _run_refinement_loop(self) -> int:
        """
        Run collaborative refinement loop.

        Returns:
            Number of iterations performed
        """
        iteration = 0

        while iteration < self.MAX_ITERATIONS:
            # Check if refinement is needed
            if not self.confidence_calculator.should_continue_refinement(
                self._outputs, self.CONFIDENCE_THRESHOLD
            ):
                break

            iteration += 1
            self._context.iteration = iteration

            if self.enable_provenance and self.provenance_tracker:
                # Determine trigger reason
                reasons = []
                for output in self._outputs.values():
                    if output.requires_refinement:
                        reasons.append(f"{output.expert_name} requires refinement")

                self.provenance_tracker.record_refinement_start(
                    iteration,
                    '; '.join(reasons) if reasons else 'Low confidence'
                )

            # Refine each expert that needs it
            prev_confidences = {
                name: output.confidence
                for name, output in self._outputs.items()
            }

            for name, expert in self.experts.items():
                output = self._outputs.get(name)
                if output and output.requires_refinement:
                    if self.enable_provenance and self.provenance_tracker:
                        self.provenance_tracker.record_expert_start(
                            name, expert.expert_type, iteration
                        )

                    refined = expert.refine(self._context, self._outputs)
                    self._outputs[name] = refined
                    self._apply_context_updates(refined)

                    if self.enable_provenance and self.provenance_tracker:
                        self.provenance_tracker.record_expert_output(refined, iteration)

            # Record improvements
            if self.enable_provenance and self.provenance_tracker:
                improvements = {}
                for name, prev_conf in prev_confidences.items():
                    new_conf = self._outputs[name].confidence
                    if new_conf > prev_conf:
                        improvements[name] = new_conf - prev_conf

                self.provenance_tracker.record_refinement_complete(iteration, improvements)

        return iteration

    def _apply_context_updates(self, output: DynamicSQLExpertOutput) -> None:
        """Apply context updates from an expert output."""
        if not output.success or not output.context_updates:
            return

        updates = output.context_updates

        if 'detected_patterns' in updates:
            self._context.detected_patterns = updates['detected_patterns']

        if 'variable_states' in updates:
            self._context.variable_states = updates['variable_states']

        if 'control_flow_graph' in updates:
            self._context.control_flow_graph = updates['control_flow_graph']

        if 'reconstructed_statements' in updates:
            self._context.reconstructed_statements = updates['reconstructed_statements']

    def _create_result(self, success: bool, warnings: List[str] = None,
                      errors: List[str] = None, iteration: int = 0,
                      conflicts: Dict[str, Any] = None) -> OrchestratorResult:
        """Create the orchestrator result."""
        # Get reconstruction output
        recon_output = self._outputs.get('ReconstructionExpert')

        reconstructed = []
        fully_resolved = []
        all_sql = []

        if recon_output and recon_output.success:
            reconstructed = recon_output.data.get('statements', [])
            fully_resolved = recon_output.data.get('fully_resolved_sql', [])
            all_sql = recon_output.data.get('all_sql', [])

        # Calculate execution time
        exec_time = 0.0
        if self._start_time:
            exec_time = (datetime.now() - self._start_time).total_seconds() * 1000

        # Get provenance data
        provenance_data = {}
        if self.enable_provenance and self.provenance_tracker:
            provenance_data = self.provenance_tracker.export_to_dict()

        # Calculate combined confidence
        combined_confidence = self.confidence_calculator.calculate_combined_confidence(
            self._outputs
        )

        return OrchestratorResult(
            success=success,
            reconstructed_statements=reconstructed,
            fully_resolved_sql=fully_resolved,
            all_sql=all_sql,
            combined_confidence=combined_confidence,
            expert_outputs=self._outputs,
            provenance=provenance_data,
            conflicts=conflicts or {},
            warnings=warnings or [],
            errors=errors or [],
            execution_time_ms=exec_time,
            iterations=iteration
        )

    def get_expert_output(self, expert_name: str) -> Optional[DynamicSQLExpertOutput]:
        """Get output from a specific expert."""
        return self._outputs.get(expert_name)

    def get_context(self) -> Optional[DynamicSQLContext]:
        """Get the current analysis context."""
        return self._context

    def get_confidence_breakdown(self) -> List[Dict[str, Any]]:
        """Get confidence breakdown by expert."""
        return self.confidence_calculator.get_breakdown()

    def set_confidence_threshold(self, threshold: float) -> None:
        """Set confidence threshold for refinement."""
        self.CONFIDENCE_THRESHOLD = max(0.0, min(1.0, threshold))

    def set_max_iterations(self, max_iterations: int) -> None:
        """Set maximum refinement iterations."""
        self.MAX_ITERATIONS = max(1, min(10, max_iterations))
