"""
Base class for Dynamic SQL Expert Agents.

Extends the BaseExpert class with dynamic SQL-specific functionality
including context-aware analysis and collaborative refinement.
"""

from abc import abstractmethod
from typing import Any, Dict, List, Optional
from datetime import datetime
import time

import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

from experts.base_expert import BaseExpert, ExpertOutput
from dynamic_sql.expert_models.data_models import (
    DynamicSQLExpertType,
    DynamicSQLExpertOutput
)
from dynamic_sql.expert_models.context_models import DynamicSQLContext, RefinementHint


class BaseDynamicSQLExpert(BaseExpert):
    """
    Base class for all Dynamic SQL expert agents.

    Extends BaseExpert with:
    - Context-aware analysis (analyze_with_context)
    - Collaborative refinement (refine)
    - Dependency specification
    - Parallel execution hints

    Subclasses must implement:
    - analyze(): Basic analysis without context
    - analyze_with_context(): Analysis using shared context
    - refine(): Refine analysis based on other experts' outputs
    - get_expert_type(): Return the expert type enum
    """

    def __init__(self, dialect: str = "tsql"):
        """
        Initialize the dynamic SQL expert.

        Args:
            dialect: SQL dialect (tsql, teradata, oracle)
        """
        super().__init__(dialect)
        self._context: Optional[DynamicSQLContext] = None
        self._start_time: Optional[float] = None

    @property
    @abstractmethod
    def expert_type(self) -> DynamicSQLExpertType:
        """Return the expert type for this agent."""
        pass

    @abstractmethod
    def analyze_with_context(self, context: DynamicSQLContext) -> DynamicSQLExpertOutput:
        """
        Analyze using shared context from previous experts.

        This method enables collaborative analysis where later experts
        can build on the work of earlier experts.

        Args:
            context: Shared context containing results from previous experts

        Returns:
            DynamicSQLExpertOutput with analysis results and context updates
        """
        pass

    @abstractmethod
    def refine(self, context: DynamicSQLContext,
               previous_outputs: Dict[str, DynamicSQLExpertOutput]) -> DynamicSQLExpertOutput:
        """
        Refine analysis based on outputs from other experts.

        Called during collaborative refinement passes when validation
        indicates improvements are needed.

        Args:
            context: Current shared context
            previous_outputs: Dict mapping expert names to their outputs

        Returns:
            DynamicSQLExpertOutput with refined analysis
        """
        pass

    def get_dependencies(self) -> List[DynamicSQLExpertType]:
        """
        Return list of expert types this expert depends on.

        Override in subclasses to specify dependencies.
        Default is no dependencies.

        Returns:
            List of DynamicSQLExpertType that must run before this expert
        """
        return []

    def can_execute_parallel(self, other_expert: 'BaseDynamicSQLExpert') -> bool:
        """
        Determine if this expert can run in parallel with another.

        Two experts can run in parallel if neither depends on the other.

        Args:
            other_expert: Another expert to check parallelism with

        Returns:
            True if experts can run in parallel
        """
        my_deps = set(self.get_dependencies())
        other_deps = set(other_expert.get_dependencies())

        # Can't run parallel if either depends on the other
        if self.expert_type in other_deps or other_expert.expert_type in my_deps:
            return False

        return True

    def get_confidence(self) -> float:
        """Return confidence score from last analysis."""
        if self._last_output:
            return self._last_output.confidence
        return 0.0

    def _start_timer(self) -> None:
        """Start execution timer."""
        self._start_time = time.time()

    def _get_elapsed_ms(self) -> float:
        """Get elapsed time in milliseconds."""
        if self._start_time:
            return (time.time() - self._start_time) * 1000
        return 0.0

    def _create_output(
        self,
        success: bool,
        data: Dict[str, Any],
        context_updates: Dict[str, Any] = None,
        confidence: float = 1.0,
        errors: List[str] = None,
        warnings: List[str] = None,
        requires_refinement: bool = False,
        refinement_suggestions: List[str] = None
    ) -> DynamicSQLExpertOutput:
        """
        Create a standardized expert output.

        Args:
            success: Whether analysis succeeded
            data: Analysis results data
            context_updates: Updates to apply to shared context
            confidence: Confidence score (0.0-1.0)
            errors: List of error messages
            warnings: List of warning messages
            requires_refinement: Whether another pass is needed
            refinement_suggestions: Hints for refinement

        Returns:
            DynamicSQLExpertOutput instance
        """
        output = DynamicSQLExpertOutput(
            expert_name=self.name,
            expert_type=self.expert_type,
            success=success,
            data=data,
            context_updates=context_updates or {},
            confidence=confidence,
            errors=errors or [],
            warnings=warnings or [],
            requires_refinement=requires_refinement,
            refinement_suggestions=refinement_suggestions or [],
            execution_time_ms=self._get_elapsed_ms()
        )

        self._last_output = output
        return output

    def _create_error_output(self, error_message: str) -> DynamicSQLExpertOutput:
        """
        Create an error output.

        Args:
            error_message: Description of the error

        Returns:
            DynamicSQLExpertOutput with error information
        """
        return self._create_output(
            success=False,
            data={},
            errors=[error_message],
            confidence=0.0
        )

    def _apply_hints(self, context: DynamicSQLContext) -> List[RefinementHint]:
        """
        Get and apply refinement hints targeted at this expert.

        Args:
            context: Current context with hints

        Returns:
            List of hints that were applied
        """
        hints = context.get_hints_for_expert(self.name)
        # Subclasses should override to actually apply hints
        return hints

    def _generate_hints(self, context: DynamicSQLContext,
                        output: DynamicSQLExpertOutput) -> List[RefinementHint]:
        """
        Generate refinement hints for other experts based on analysis.

        Override in subclasses to provide hints to other experts.

        Args:
            context: Current context
            output: This expert's output

        Returns:
            List of hints to add to context
        """
        return []

    def validate_context(self, context: DynamicSQLContext) -> bool:
        """
        Validate that the context has required data for this expert.

        Override in subclasses to add specific validation.

        Args:
            context: Context to validate

        Returns:
            True if context is valid for this expert
        """
        if not context.sql_text:
            return False
        return True
