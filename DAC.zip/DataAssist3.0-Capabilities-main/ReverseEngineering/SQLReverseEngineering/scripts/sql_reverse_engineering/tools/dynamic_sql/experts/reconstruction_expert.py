"""
Reconstruction Expert for Dynamic SQL Analysis.

Assembles dynamic SQL from tracked variable states and control flow information,
producing fully or partially resolved SQL statements.
"""

from typing import Any, Dict, List, Optional

import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

from dynamic_sql.experts.base_dynamic_expert import BaseDynamicSQLExpert
from dynamic_sql.expert_models.data_models import (
    DynamicSQLExpertType,
    DynamicSQLExpertOutput
)
from dynamic_sql.expert_models.context_models import DynamicSQLContext, RefinementHint
from dynamic_sql.reconstructor import SQLReconstructor, MultiStatementReconstructor
from dynamic_sql.variable_tracker import VariableTracker


class ReconstructionExpert(BaseDynamicSQLExpert):
    """
    Expert for reconstructing dynamic SQL from tracked fragments.

    Wraps the existing SQLReconstructor with the multi-expert interface.
    Depends on both VariableTrackingExpert and ControlFlowExpert to have
    complete variable state and execution path information.

    Produces:
    - Fully resolved SQL statements
    - Partially resolved SQL with placeholders
    - Conditional variants for different execution paths
    """

    def __init__(self, dialect: str = "tsql"):
        """
        Initialize the reconstruction expert.

        Args:
            dialect: SQL dialect (tsql, teradata, oracle)
        """
        super().__init__(dialect)

    @property
    def expert_type(self) -> DynamicSQLExpertType:
        """Return the expert type."""
        return DynamicSQLExpertType.RECONSTRUCTION

    def get_dependencies(self) -> List[DynamicSQLExpertType]:
        """Depends on variable tracking and control flow analysis."""
        return [
            DynamicSQLExpertType.VARIABLE_TRACKING,
            DynamicSQLExpertType.CONTROL_FLOW
        ]

    def analyze(self, sql: str, **kwargs) -> DynamicSQLExpertOutput:
        """
        Reconstruct dynamic SQL statements.

        Args:
            sql: SQL text to analyze
            **kwargs: Additional parameters including patterns and tracker

        Returns:
            DynamicSQLExpertOutput with reconstructed SQL
        """
        self._start_timer()

        if not self.validate_input(sql):
            return self._create_error_output("Invalid or empty SQL input")

        try:
            # Need patterns and tracker to reconstruct
            patterns = kwargs.get('patterns', [])
            tracker = kwargs.get('tracker')

            if not patterns:
                return self._create_output(
                    success=True,
                    data={'reconstructed_count': 0, 'statements': []},
                    confidence=0.5
                )

            if not tracker:
                # Create a new tracker if not provided
                tracker = VariableTracker(self.dialect)
                tracker.track_all(sql)

            # Reconstruct all patterns
            multi_reconstructor = MultiStatementReconstructor(self.dialect)
            results = multi_reconstructor.reconstruct_procedure(sql, patterns, tracker)

            # Build output data
            data = self._build_output_data(results)
            confidence = self._calculate_confidence(results)

            warnings = []
            for result in results:
                if result.unresolved_parts:
                    warnings.append(
                        f"Statement at line {result.original_pattern.start_line} has "
                        f"unresolved parts: {', '.join(result.unresolved_parts)}"
                    )

            return self._create_output(
                success=True,
                data=data,
                context_updates={'reconstructed_statements': results},
                confidence=confidence,
                warnings=warnings
            )

        except Exception as e:
            return self._create_error_output(f"SQL reconstruction failed: {str(e)}")

    def analyze_with_context(self, context: DynamicSQLContext) -> DynamicSQLExpertOutput:
        """
        Reconstruct SQL using shared context from previous experts.

        Uses detected patterns from PatternDetectionExpert and
        variable states from VariableTrackingExpert.

        Args:
            context: Shared context with patterns and variable states

        Returns:
            DynamicSQLExpertOutput with reconstructed SQL
        """
        self._start_timer()

        if not self.validate_context(context):
            return self._create_error_output("Invalid context")

        try:
            patterns = context.detected_patterns
            if not patterns:
                return self._create_output(
                    success=True,
                    data={'reconstructed_count': 0, 'statements': []},
                    confidence=0.5
                )

            # Create tracker with variable states from context
            tracker = VariableTracker(context.dialect)
            tracker.track_all(context.sql_text)

            # If we have variable states from context, update tracker
            if context.variable_states:
                for name, state in context.variable_states.items():
                    tracker.variables[name] = state

            # Use control flow information if available
            cfg = context.control_flow_graph
            execution_paths = []
            if cfg:
                execution_paths = cfg.execution_paths

            # Reconstruct all patterns
            multi_reconstructor = MultiStatementReconstructor(context.dialect)
            results = multi_reconstructor.reconstruct_procedure(
                context.sql_text, patterns, tracker
            )

            # Enhance results with control flow information
            if execution_paths:
                results = self._enhance_with_control_flow(results, cfg, execution_paths)

            # Build output data
            data = self._build_output_data(results)
            data['execution_paths_considered'] = len(execution_paths)

            confidence = self._calculate_confidence(results)

            # Determine if refinement is needed
            warnings = []
            requires_refinement = False

            unresolved_count = sum(1 for r in results if r.unresolved_parts)
            if unresolved_count > 0:
                warnings.append(f"{unresolved_count} statement(s) have unresolved parts")
                requires_refinement = True

            conditional_count = sum(1 for r in results if r.possible_variants)
            if conditional_count > 0:
                warnings.append(f"{conditional_count} statement(s) have conditional variants")

            return self._create_output(
                success=True,
                data=data,
                context_updates={'reconstructed_statements': results},
                confidence=confidence,
                warnings=warnings,
                requires_refinement=requires_refinement
            )

        except Exception as e:
            return self._create_error_output(f"SQL reconstruction failed: {str(e)}")

    def refine(self, context: DynamicSQLContext,
               previous_outputs: Dict[str, DynamicSQLExpertOutput]) -> DynamicSQLExpertOutput:
        """
        Refine reconstruction based on other experts' outputs.

        Can use validation feedback to improve reconstruction,
        and updated variable tracking to resolve more parts.

        Args:
            context: Current context
            previous_outputs: Outputs from other experts

        Returns:
            Refined DynamicSQLExpertOutput
        """
        self._start_timer()

        # Start with current reconstructed statements
        current_statements = list(context.reconstructed_statements)

        # Check for validation feedback
        validation_output = previous_outputs.get('ValidationExpert')
        if validation_output and validation_output.refinement_suggestions:
            for suggestion in validation_output.refinement_suggestions:
                self._apply_validation_suggestion(current_statements, suggestion, context)

        # Check for updated variable tracking
        variable_output = previous_outputs.get('VariableTrackingExpert')
        if variable_output and variable_output.success:
            # Re-reconstruct with better variable information
            updated_vars = variable_output.data.get('variables', {})
            if updated_vars:
                current_statements = self._re_reconstruct_with_variables(
                    context, updated_vars
                )

        # Build output data
        data = self._build_output_data(current_statements)
        data['refined'] = True
        data['iteration'] = context.iteration

        confidence = self._calculate_confidence(current_statements)

        return self._create_output(
            success=True,
            data=data,
            context_updates={'reconstructed_statements': current_statements},
            confidence=confidence
        )

    def _build_output_data(self, results: List) -> Dict[str, Any]:
        """Build output data dictionary from reconstruction results."""
        fully_resolved = [r for r in results if r.is_complete]
        partially_resolved = [r for r in results if not r.is_complete and r.reconstructed_sql]

        return {
            'reconstructed_count': len(results),
            'fully_resolved_count': len(fully_resolved),
            'partially_resolved_count': len(partially_resolved),
            'statements': [self._result_to_dict(r) for r in results],
            'fully_resolved_sql': [r.reconstructed_sql for r in fully_resolved],
            'all_sql': [r.reconstructed_sql for r in results if r.reconstructed_sql]
        }

    def _result_to_dict(self, result) -> Dict[str, Any]:
        """Convert a ReconstructedSQL to dictionary."""
        return {
            'pattern_line': result.original_pattern.start_line if result.original_pattern else None,
            'pattern_type': result.original_pattern.pattern_type.value if result.original_pattern else None,
            'reconstructed_sql': result.reconstructed_sql[:500] if result.reconstructed_sql else None,
            'is_complete': result.is_complete,
            'resolution_status': result.resolution_status.value if result.resolution_status else None,
            'confidence': result.confidence,
            'unresolved_parts': result.unresolved_parts,
            'variant_count': len(result.possible_variants) if result.possible_variants else 0,
            'notes': result.reconstruction_notes
        }

    def _calculate_confidence(self, results: List) -> float:
        """Calculate overall confidence for reconstruction."""
        if not results:
            return 0.5

        # Average confidence of all results
        avg_confidence = sum(r.confidence for r in results) / len(results)

        # Boost if all are fully resolved
        fully_resolved = sum(1 for r in results if r.is_complete)
        if fully_resolved == len(results):
            avg_confidence = min(avg_confidence + 0.1, 1.0)

        return avg_confidence

    def _enhance_with_control_flow(self, results: List, cfg, execution_paths: List) -> List:
        """Enhance reconstruction results with control flow information."""
        # For each result, check if its pattern is on a conditional path
        for result in results:
            if result.original_pattern:
                pattern_line = result.original_pattern.start_line

                # Check which execution paths include this pattern
                paths_including = []
                for i, path in enumerate(execution_paths):
                    for node_id in path:
                        node = cfg.nodes.get(node_id)
                        if node and node.line_number == pattern_line:
                            paths_including.append(i)
                            break

                if len(paths_including) < len(execution_paths):
                    result.reconstruction_notes.append(
                        f"Executed on {len(paths_including)} of {len(execution_paths)} paths"
                    )

        return results

    def _apply_validation_suggestion(self, statements: List, suggestion: str,
                                     context: DynamicSQLContext) -> None:
        """Apply a validation suggestion to improve reconstruction."""
        # Parse suggestion and try to improve reconstruction
        # This is a placeholder for more sophisticated handling
        pass

    def _re_reconstruct_with_variables(self, context: DynamicSQLContext,
                                       updated_vars: Dict) -> List:
        """Re-reconstruct with updated variable information."""
        # Create tracker with updated variables
        tracker = VariableTracker(context.dialect)
        tracker.track_all(context.sql_text)

        # Update with refined variable states
        for name, var_dict in updated_vars.items():
            if name in tracker.variables:
                state = tracker.variables[name]
                if var_dict.get('current_value'):
                    state.current_value = var_dict['current_value']

        # Reconstruct
        multi_reconstructor = MultiStatementReconstructor(context.dialect)
        return multi_reconstructor.reconstruct_procedure(
            context.sql_text, context.detected_patterns, tracker
        )

    def validate_context(self, context: DynamicSQLContext) -> bool:
        """Validate that context has required data."""
        if not super().validate_context(context):
            return False

        # Need patterns to reconstruct
        if not context.detected_patterns:
            return True  # Empty patterns is valid, just nothing to do

        return True

    def _generate_hints(self, context: DynamicSQLContext,
                        output: DynamicSQLExpertOutput) -> List[RefinementHint]:
        """Generate hints for other experts."""
        hints = []

        # If reconstruction found unresolved parts, hint to variable tracking
        statements = output.data.get('statements', [])
        unresolved_vars = set()
        for stmt in statements:
            unresolved_vars.update(stmt.get('unresolved_parts', []))

        if unresolved_vars:
            hints.append(RefinementHint(
                source_expert=self.name,
                target_expert='VariableTrackingExpert',
                hint_type='unresolved_variables',
                hint_data={'variables': list(unresolved_vars)},
                priority=2
            ))

        return hints
