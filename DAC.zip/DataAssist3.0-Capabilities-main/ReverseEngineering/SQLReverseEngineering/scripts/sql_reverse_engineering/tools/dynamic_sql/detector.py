"""
Dynamic SQL Detector module.

Detects dynamic SQL execution patterns in stored procedures:
- EXEC(@sql) / EXECUTE(@sql)
- sp_executesql @sql
- EXECUTE IMMEDIATE (Teradata/Oracle)
- PREPARE...EXECUTE patterns
"""

import re
from typing import List, Dict, Optional, Tuple
from dataclasses import dataclass

from dynamic_sql.models import DynamicSQLPattern, DynamicSQLType


class DynamicSQLDetector:
    """
    Detect dynamic SQL execution patterns in stored procedures.

    Supports multiple SQL dialects:
    - T-SQL (SQL Server): EXEC, sp_executesql
    - Teradata: EXECUTE IMMEDIATE
    - Oracle: EXECUTE IMMEDIATE
    """

    # Pattern definitions for different dialects
    PATTERNS = {
        'tsql': {
            # EXEC(@variable) or EXEC (@variable)
            'exec_var': re.compile(
                r'\bEXEC(?:UTE)?\s*\(\s*(@\w+)\s*\)',
                re.IGNORECASE
            ),
            # EXEC('literal string') or EXEC('...' + @var + '...')
            'exec_string': re.compile(
                r'\bEXEC(?:UTE)?\s*\(\s*([\'"].*?[\'"](?:\s*\+\s*[@\w]+)*|[@\w]+(?:\s*\+\s*[\'"].*?[\'"])*)\s*\)',
                re.IGNORECASE | re.DOTALL
            ),
            # EXEC sp_executesql @sql, N'@param INT', @param = @value
            # Also handles: EXECUTE [master]..sp_executesql, EXECUTE dbo.sp_executesql
            'sp_executesql': re.compile(
                r'\bEXEC(?:UTE)?\s+(?:\[?\w+\]?\.\.?)?(?:\[?\w+\]?\.)?sp_executesql\s+(@\w+|N?[\'"].*?[\'"])',
                re.IGNORECASE | re.DOTALL
            ),
            # xp_cmdshell with variable
            'xp_cmdshell': re.compile(
                r'\bEXEC(?:UTE)?\s+(?:\[?\w+\]?\.\.?)?(?:\[?\w+\]?\.)?xp_cmdshell\s+(@\w+)',
                re.IGNORECASE
            ),
        },
        'teradata': {
            # EXECUTE IMMEDIATE sql_variable
            'execute_immediate': re.compile(
                r'\bEXECUTE\s+IMMEDIATE\s+(\w+)',
                re.IGNORECASE
            ),
            # EXECUTE IMMEDIATE 'literal' or expression
            'execute_immediate_expr': re.compile(
                r'\bEXECUTE\s+IMMEDIATE\s+([\'"].*?[\'"]|[\w\s\|\|]+)',
                re.IGNORECASE | re.DOTALL
            ),
        },
        'oracle': {
            # EXECUTE IMMEDIATE variable
            'execute_immediate': re.compile(
                r'\bEXECUTE\s+IMMEDIATE\s+(\w+)',
                re.IGNORECASE
            ),
            # EXECUTE IMMEDIATE expression USING
            'execute_immediate_using': re.compile(
                r'\bEXECUTE\s+IMMEDIATE\s+(.*?)\s+USING',
                re.IGNORECASE | re.DOTALL
            ),
        }
    }

    def __init__(self, dialect: str = "tsql"):
        """
        Initialize detector.

        Args:
            dialect: SQL dialect (tsql, teradata, oracle)
        """
        self.dialect = dialect.lower()
        self.patterns = self.PATTERNS.get(self.dialect, self.PATTERNS['tsql'])

    def detect(self, sql: str) -> List[DynamicSQLPattern]:
        """
        Detect dynamic SQL patterns in SQL text.

        Args:
            sql: SQL text to analyze

        Returns:
            List of detected DynamicSQLPattern objects
        """
        patterns = []

        # Remove comments for cleaner detection
        clean_sql = self._remove_comments(sql)

        # Split into lines for line number tracking
        lines = clean_sql.split('\n')
        line_offsets = self._build_line_offsets(lines)

        if self.dialect == 'tsql':
            patterns.extend(self._detect_tsql_patterns(clean_sql, line_offsets))
        elif self.dialect == 'teradata':
            patterns.extend(self._detect_teradata_patterns(clean_sql, line_offsets))
        elif self.dialect == 'oracle':
            patterns.extend(self._detect_oracle_patterns(clean_sql, line_offsets))
        else:
            # Default to T-SQL patterns
            patterns.extend(self._detect_tsql_patterns(clean_sql, line_offsets))

        return patterns

    def _detect_tsql_patterns(self, sql: str, line_offsets: List[int]) -> List[DynamicSQLPattern]:
        """Detect T-SQL dynamic SQL patterns."""
        patterns = []

        # Detect EXEC(@variable)
        for match in self.patterns['exec_var'].finditer(sql):
            variable = match.group(1)
            line_num = self._get_line_number(match.start(), line_offsets)

            patterns.append(DynamicSQLPattern(
                pattern_type=DynamicSQLType.EXEC_STRING,
                start_line=line_num,
                end_line=line_num,
                variable_name=variable,
                execution_sql=match.group(0),
                dialect=self.dialect,
                confidence=0.95
            ))

        # Detect sp_executesql
        for match in self.patterns['sp_executesql'].finditer(sql):
            variable = match.group(1)
            line_num = self._get_line_number(match.start(), line_offsets)

            # Extract parameters if present
            params = self._extract_sp_executesql_params(sql, match.end())

            patterns.append(DynamicSQLPattern(
                pattern_type=DynamicSQLType.SP_EXECUTESQL,
                start_line=line_num,
                end_line=line_num,
                variable_name=variable.strip("N'\""),
                execution_sql=match.group(0),
                parameters=params,
                dialect=self.dialect,
                confidence=0.98
            ))

        # Detect EXEC with string concatenation
        for match in self.patterns['exec_string'].finditer(sql):
            expression = match.group(1)
            line_num = self._get_line_number(match.start(), line_offsets)

            # Check if already detected as exec_var
            already_detected = any(
                p.start_line == line_num and p.pattern_type == DynamicSQLType.EXEC_STRING
                for p in patterns
            )

            if not already_detected:
                # Extract variable name if it's a variable reference
                var_match = re.match(r'^(@\w+)', expression.strip())
                var_name = var_match.group(1) if var_match else expression[:50]

                patterns.append(DynamicSQLPattern(
                    pattern_type=DynamicSQLType.EXEC_STRING,
                    start_line=line_num,
                    end_line=line_num,
                    variable_name=var_name,
                    execution_sql=match.group(0),
                    dialect=self.dialect,
                    confidence=0.85
                ))

        # Detect xp_cmdshell (if pattern exists)
        if 'xp_cmdshell' in self.patterns:
            for match in self.patterns['xp_cmdshell'].finditer(sql):
                variable = match.group(1)
                line_num = self._get_line_number(match.start(), line_offsets)

                patterns.append(DynamicSQLPattern(
                    pattern_type=DynamicSQLType.XP_CMDSHELL,
                    start_line=line_num,
                    end_line=line_num,
                    variable_name=variable,
                    execution_sql=match.group(0),
                    dialect=self.dialect,
                    confidence=0.90
                ))

        return patterns

    def _detect_teradata_patterns(self, sql: str, line_offsets: List[int]) -> List[DynamicSQLPattern]:
        """Detect Teradata dynamic SQL patterns."""
        patterns = []

        # Detect EXECUTE IMMEDIATE variable
        for match in self.patterns['execute_immediate'].finditer(sql):
            variable = match.group(1)
            line_num = self._get_line_number(match.start(), line_offsets)

            patterns.append(DynamicSQLPattern(
                pattern_type=DynamicSQLType.EXECUTE_IMMEDIATE,
                start_line=line_num,
                end_line=line_num,
                variable_name=variable,
                execution_sql=match.group(0),
                dialect=self.dialect,
                confidence=0.95
            ))

        # Detect EXECUTE IMMEDIATE with expression
        for match in self.patterns['execute_immediate_expr'].finditer(sql):
            expression = match.group(1).strip()
            line_num = self._get_line_number(match.start(), line_offsets)

            # Skip if already detected as simple variable
            already_detected = any(
                p.start_line == line_num for p in patterns
            )

            if not already_detected:
                # Try to extract variable name from expression
                var_name = self._extract_variable_from_expression(expression)

                patterns.append(DynamicSQLPattern(
                    pattern_type=DynamicSQLType.EXECUTE_IMMEDIATE,
                    start_line=line_num,
                    end_line=line_num,
                    variable_name=var_name or expression[:50],
                    execution_sql=match.group(0),
                    dialect=self.dialect,
                    confidence=0.85
                ))

        return patterns

    def _detect_oracle_patterns(self, sql: str, line_offsets: List[int]) -> List[DynamicSQLPattern]:
        """Detect Oracle dynamic SQL patterns."""
        patterns = []

        # Detect EXECUTE IMMEDIATE variable
        for match in self.patterns['execute_immediate'].finditer(sql):
            variable = match.group(1)
            line_num = self._get_line_number(match.start(), line_offsets)

            patterns.append(DynamicSQLPattern(
                pattern_type=DynamicSQLType.EXECUTE_IMMEDIATE,
                start_line=line_num,
                end_line=line_num,
                variable_name=variable,
                execution_sql=match.group(0),
                dialect=self.dialect,
                confidence=0.95
            ))

        # Detect EXECUTE IMMEDIATE ... USING
        for match in self.patterns['execute_immediate_using'].finditer(sql):
            expression = match.group(1).strip()
            line_num = self._get_line_number(match.start(), line_offsets)

            patterns.append(DynamicSQLPattern(
                pattern_type=DynamicSQLType.EXECUTE_IMMEDIATE,
                start_line=line_num,
                end_line=line_num,
                variable_name=expression[:50],
                execution_sql=match.group(0),
                dialect=self.dialect,
                confidence=0.90
            ))

        return patterns

    def _extract_sp_executesql_params(self, sql: str, start_pos: int) -> List[str]:
        """Extract parameter names from sp_executesql call."""
        params = []

        # Look for parameter definition after the SQL variable
        remaining = sql[start_pos:start_pos + 500]  # Look ahead 500 chars

        # Pattern: N'@param1 INT, @param2 VARCHAR(100)'
        param_def_match = re.search(r",\s*N?'(@\w+[^']*)'", remaining)
        if param_def_match:
            param_str = param_def_match.group(1)
            # Extract individual parameter names
            for param_match in re.finditer(r'@\w+', param_str):
                params.append(param_match.group(0))

        return params

    def _extract_variable_from_expression(self, expression: str) -> Optional[str]:
        """Extract variable name from a concatenation expression."""
        # Look for variable patterns
        var_match = re.search(r'[@:]?\b(\w+)\b', expression)
        if var_match:
            return var_match.group(1)
        return None

    def _remove_comments(self, sql: str) -> str:
        """Remove SQL comments from text."""
        # Remove single-line comments
        sql = re.sub(r'--[^\n]*', '', sql)
        # Remove multi-line comments
        sql = re.sub(r'/\*.*?\*/', '', sql, flags=re.DOTALL)
        return sql

    def _build_line_offsets(self, lines: List[str]) -> List[int]:
        """Build list of character offsets for each line."""
        offsets = [0]
        for line in lines[:-1]:
            offsets.append(offsets[-1] + len(line) + 1)  # +1 for newline
        return offsets

    def _get_line_number(self, char_pos: int, line_offsets: List[int]) -> int:
        """Get line number for a character position."""
        for i, offset in enumerate(line_offsets):
            if i + 1 < len(line_offsets):
                if line_offsets[i] <= char_pos < line_offsets[i + 1]:
                    return i + 1
            else:
                return i + 1
        return 1

    def detect_variable_assignments(self, sql: str, variable_name: str) -> List[Tuple[int, str]]:
        """
        Find all assignments to a specific variable.

        Args:
            sql: SQL text
            variable_name: Variable to track (e.g., @sql)

        Returns:
            List of (line_number, assignment_statement) tuples
        """
        assignments = []
        lines = sql.split('\n')

        # Escape variable name for regex
        escaped_var = re.escape(variable_name)

        # Pattern for SET @var = ...
        set_pattern = re.compile(
            rf'\bSET\s+{escaped_var}\s*=\s*(.*?)(?:;|$)',
            re.IGNORECASE | re.DOTALL
        )

        # Pattern for SELECT @var = ...
        select_pattern = re.compile(
            rf'\bSELECT\s+{escaped_var}\s*=\s*(.*?)(?:;|$)',
            re.IGNORECASE | re.DOTALL
        )

        for i, line in enumerate(lines, 1):
            for pattern in [set_pattern, select_pattern]:
                match = pattern.search(line)
                if match:
                    assignments.append((i, line.strip()))

        return assignments
