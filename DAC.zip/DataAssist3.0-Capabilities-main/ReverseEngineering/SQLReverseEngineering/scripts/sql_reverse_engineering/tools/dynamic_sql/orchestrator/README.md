# Dynamic SQL Orchestrator

## Overview
The Orchestrator module coordinates multiple dynamic SQL experts, manages their execution, resolves conflicts, calculates confidence, and produces final results.

## Components

### `dynamic_sql_orchestrator.py`
Main coordinator for multi-expert dynamic SQL analysis.

**Responsibilities:**
- Execute experts in optimal order
- Manage parallel execution when possible
- Collect and merge expert outputs
- Coordinate iterative refinement
- Produce final consolidated results

**Key Features:**
- Parallel expert execution
- Dependency management
- Result aggregation
- Iterative improvement
- Timeout handling

**Workflow:**
1. Initialize experts
2. Execute Phase 1: Detection and Analysis (parallel)
   - Pattern Detection
   - Variable Tracking
   - Control Flow Analysis
3. Execute Phase 2: Reconstruction (sequential)
   - SQL Reconstruction
4. Execute Phase 3: Validation (parallel)
   - Validation
5. Resolve conflicts
6. Calculate confidence
7. Return results

**Usage:**
```python
from dynamic_sql.orchestrator import DynamicSQLOrchestrator

orchestrator = DynamicSQLOrchestrator(dialect="teradata")
result = orchestrator.analyze(sql_code, schema=schema_dict)
```

### `confidence_calculator.py`
Calculates confidence scores for reconstructed SQL.

**Calculation Factors:**
- Expert agreement level
- Pattern detection strength
- Variable resolution completeness
- Control flow complexity
- Validation success rate
- Schema compatibility

**Confidence Formula:**
```python
confidence = (
    pattern_confidence * 0.25 +
    variable_confidence * 0.25 +
    control_flow_confidence * 0.20 +
    reconstruction_confidence * 0.20 +
    validation_confidence * 0.10
)
```

**Methods:**
- `calculate_overall_confidence()` - Overall confidence
- `calculate_statement_confidence()` - Per-statement confidence
- `explain_confidence()` - Confidence breakdown

**Output:**
```python
{
    "overall": 0.85,
    "by_expert": {
        "pattern_detection": 0.9,
        "variable_tracking": 0.8,
        "reconstruction": 0.85
    },
    "by_statement": [
        {"sql": "...", "confidence": 0.9},
        {"sql": "...", "confidence": 0.7}
    ],
    "factors": {
        "expert_agreement": "high",
        "variable_resolution": "complete",
        "validation": "passed"
    }
}
```

### `conflict_resolver.py`
Resolves conflicts when experts produce contradictory results.

**Conflict Types:**
- Different SQL reconstructions
- Incompatible variable values
- Contradictory pattern detections
- Validation disagreements

**Resolution Strategies:**

#### `HighestConfidence`
Choose result with highest confidence score.

#### `MajorityVote`
Use result agreed upon by most experts.

#### `ExpertPriority`
Use predefined expert priority hierarchy.

#### `WeightedConsensus`
Combine results weighted by confidence.

**Usage:**
```python
resolver = ConflictResolver(strategy="highest_confidence")
resolved = resolver.resolve(expert_outputs)
```

**Methods:**
- `resolve()` - Resolve all conflicts
- `detect_conflicts()` - Identify conflicting results
- `apply_strategy()` - Apply resolution strategy
- `explain_resolution()` - Explain resolution decisions

### `provenance_tracker.py`
Tracks the origin and reasoning for all results.

**Tracked Information:**
- Expert contributions to each result
- Decision points and reasoning
- Confidence sources
- Conflict resolutions
- Transformation steps

**Provenance Record:**
```python
{
    "statement": "SELECT * FROM CUSTOMERS",
    "source": {
        "experts": ["pattern_detection", "reconstruction"],
        "confidence_sources": {
            "pattern": 0.9,
            "variables": 0.85
        },
        "decisions": [
            {
                "point": "table_name_resolution",
                "decision": "CUSTOMERS",
                "reason": "Variable tracking expert",
                "confidence": 0.85
            }
        ],
        "conflicts_resolved": [
            {
                "conflict": "Multiple table names",
                "resolution": "Used highest confidence",
                "winner": "CUSTOMERS"
            }
        ]
    }
}
```

**Methods:**
- `track_expert_contribution()` - Record expert input
- `track_decision()` - Record decision point
- `track_conflict_resolution()` - Record conflict resolution
- `get_provenance()` - Retrieve full provenance
- `explain_result()` - Explain how result was derived

**Benefits:**
- Auditability
- Debugging
- Result explanation
- Trust building
- Quality assurance

## Orchestration Flow

```
┌─────────────────────────────────────────────────────────┐
│                  Start Orchestration                     │
└─────────────────────┬───────────────────────────────────┘
                      │
                      ▼
┌─────────────────────────────────────────────────────────┐
│  Phase 1: Detection & Analysis (Parallel)               │
│  ├─ Pattern Detection Expert                            │
│  ├─ Variable Tracking Expert                            │
│  └─ Control Flow Expert                                 │
└─────────────────────┬───────────────────────────────────┘
                      │
                      ▼
┌─────────────────────────────────────────────────────────┐
│  Phase 2: Reconstruction (Sequential)                   │
│  └─ Reconstruction Expert                               │
└─────────────────────┬───────────────────────────────────┘
                      │
                      ▼
┌─────────────────────────────────────────────────────────┐
│  Phase 3: Validation (Parallel)                         │
│  └─ Validation Expert                                   │
└─────────────────────┬───────────────────────────────────┘
                      │
                      ▼
┌─────────────────────────────────────────────────────────┐
│  Conflict Resolution                                     │
│  └─ Resolve contradictory results                       │
└─────────────────────┬───────────────────────────────────┘
                      │
                      ▼
┌─────────────────────────────────────────────────────────┐
│  Confidence Calculation                                  │
│  └─ Calculate overall and per-statement confidence      │
└─────────────────────┬───────────────────────────────────┘
                      │
                      ▼
┌─────────────────────────────────────────────────────────┐
│  Return OrchestratorResult                              │
└─────────────────────────────────────────────────────────┘
```

## Output Structure

```python
OrchestratorResult(
    success=True,
    reconstructed_statements=[...],
    fully_resolved_sql=[...],
    all_sql=[...],
    combined_confidence=0.85,
    expert_outputs={...},
    provenance={...},
    conflicts={...},
    warnings=[],
    errors=[],
    execution_time_ms=250.5,
    iterations=1
)
```

## Configuration

### Expert Execution Order
Configurable execution order and dependencies.

### Parallel Execution
Control which experts run in parallel.

### Timeout Settings
Set timeouts for individual experts and overall orchestration.

### Conflict Resolution
Choose resolution strategy.

## Integration Points
- Inputs: Raw SQL/procedural code, schema context
- Coordinates: All dynamic SQL experts
- Outputs: Consolidated results with confidence and provenance
- Used by: Dynamic SQL analyzer, agent interface
