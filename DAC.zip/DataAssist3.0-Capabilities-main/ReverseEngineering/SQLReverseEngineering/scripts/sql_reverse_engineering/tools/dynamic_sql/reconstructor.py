"""
SQL Reconstructor module.

Assembles dynamic SQL from tracked variable states, producing
fully or partially resolved SQL statements.
"""

import re
import uuid
from typing import List, Dict, Optional, Tuple
from dataclasses import dataclass

from dynamic_sql.models import (
    DynamicSQLPattern, ReconstructedSQL, DynamicSQLFragment,
    ResolutionStatus, DynamicSQLType, VariableState
)
from dynamic_sql.variable_tracker import VariableTracker


class SQLReconstructor:
    """
    Reconstruct dynamic SQL from variable tracking results.

    Takes detected dynamic SQL patterns and variable states,
    produces fully assembled SQL where possible.
    """

    def __init__(self, variable_tracker: VariableTracker, dialect: str = "tsql"):
        """
        Initialize reconstructor.

        Args:
            variable_tracker: Tracker with variable states
            dialect: SQL dialect
        """
        self.tracker = variable_tracker
        self.dialect = dialect.lower()
        self._fragment_counter = 0

    def reconstruct(self, pattern: DynamicSQLPattern) -> ReconstructedSQL:
        """
        Reconstruct SQL for a detected dynamic SQL pattern.

        Args:
            pattern: Detected dynamic SQL pattern

        Returns:
            ReconstructedSQL with assembled SQL and metadata
        """
        result = ReconstructedSQL(
            original_pattern=pattern,
            reconstructed_sql="",
            is_complete=False,
            resolution_status=ResolutionStatus.UNRESOLVABLE
        )

        # Get the variable holding the SQL
        var_name = pattern.variable_name
        var_state = self.tracker.get_variable_value(var_name)

        if not var_state:
            result.reconstruction_notes.append(
                f"Variable {var_name} not found in tracked variables"
            )
            return result

        # Build fragments from variable history
        fragments = self._build_fragments(var_state)
        result.fragments = fragments

        # Assemble the SQL
        assembled, unresolved = self._assemble_sql(var_state)
        result.reconstructed_sql = assembled
        result.unresolved_parts = unresolved

        # Handle conditional variants
        variants = self._get_conditional_variants(var_state)
        result.possible_variants = variants

        # Determine resolution status
        result.resolution_status = self._determine_status(
            assembled, unresolved, variants
        )
        result.is_complete = (result.resolution_status == ResolutionStatus.FULLY_RESOLVED)

        # Calculate confidence
        result.confidence = self._calculate_confidence(result)

        # Add reconstruction notes
        self._add_reconstruction_notes(result, var_state)

        return result

    def reconstruct_all(self, patterns: List[DynamicSQLPattern]) -> List[ReconstructedSQL]:
        """
        Reconstruct SQL for all detected patterns.

        Args:
            patterns: List of detected patterns

        Returns:
            List of ReconstructedSQL objects
        """
        return [self.reconstruct(p) for p in patterns]

    def _build_fragments(self, var_state: VariableState) -> List[DynamicSQLFragment]:
        """Build list of SQL fragments from variable history."""
        fragments = []

        for assignment in var_state.value_history:
            fragment_id = f"frag_{self._fragment_counter}"
            self._fragment_counter += 1

            # Determine if it's a literal or variable-based
            is_literal = not assignment.assigned_value.startswith("${")

            fragment = DynamicSQLFragment(
                fragment_id=fragment_id,
                content=assignment.assigned_value,
                is_literal=is_literal,
                source_variable=assignment.variable_name,
                source_line=assignment.line_number
            )
            fragments.append(fragment)

        return fragments

    def _assemble_sql(self, var_state: VariableState) -> Tuple[str, List[str]]:
        """
        Assemble SQL from variable state.

        Returns:
            Tuple of (assembled_sql, unresolved_parts)
        """
        if not var_state.current_value:
            return "", [var_state.name]

        assembled = var_state.current_value
        unresolved = []

        # Find unresolved placeholders (${...})
        placeholder_pattern = r'\$\{([^}]+)\}'
        for match in re.finditer(placeholder_pattern, assembled):
            unresolved.append(match.group(1))

        # Also check for unresolved references from tracker
        unresolved.extend(var_state.unresolved_references)

        # Clean up the assembled SQL
        assembled = self._clean_assembled_sql(assembled)

        return assembled, list(set(unresolved))

    def _clean_assembled_sql(self, sql: str) -> str:
        """Clean up assembled SQL for readability."""
        # Remove double spaces
        sql = re.sub(r' +', ' ', sql)

        # Fix spacing around operators
        sql = re.sub(r'\s*\+\s*', ' + ', sql)

        # Normalize newlines
        sql = re.sub(r'\n\s*\n', '\n', sql)

        return sql.strip()

    def _get_conditional_variants(self, var_state: VariableState) -> List[str]:
        """Get possible SQL variants from conditional assignments."""
        variants = []

        for assignment in var_state.value_history:
            if assignment.condition:
                # Build variant with this conditional value
                variant_sql = self._build_variant_sql(var_state, assignment)
                if variant_sql:
                    variants.append(f"IF {assignment.condition}: {variant_sql}")

        return variants

    def _build_variant_sql(self, var_state: VariableState,
                          conditional_assignment) -> str:
        """Build SQL variant for a conditional branch."""
        # Start with non-conditional assignments
        parts = []

        for assignment in var_state.value_history:
            if not assignment.condition:
                parts.append(assignment.assigned_value)
            elif assignment == conditional_assignment:
                parts.append(assignment.assigned_value)

        return ''.join(parts)

    def _determine_status(self, assembled: str, unresolved: List[str],
                         variants: List[str]) -> ResolutionStatus:
        """Determine the resolution status."""
        if not assembled:
            return ResolutionStatus.UNRESOLVABLE

        if unresolved:
            return ResolutionStatus.PARTIALLY_RESOLVED

        if variants:
            return ResolutionStatus.CONDITIONAL

        # Check if assembled SQL looks complete
        if self._looks_like_valid_sql(assembled):
            return ResolutionStatus.FULLY_RESOLVED

        return ResolutionStatus.PARTIALLY_RESOLVED

    def _looks_like_valid_sql(self, sql: str) -> bool:
        """Check if SQL looks like a valid statement."""
        sql_upper = sql.upper().strip()

        # Check for common SQL statement starts
        valid_starts = ['SELECT', 'INSERT', 'UPDATE', 'DELETE', 'CREATE',
                       'ALTER', 'DROP', 'TRUNCATE', 'MERGE', 'EXEC', 'CALL']

        for start in valid_starts:
            if sql_upper.startswith(start):
                return True

        return False

    def _calculate_confidence(self, result: ReconstructedSQL) -> float:
        """Calculate confidence score for reconstruction."""
        base_confidence = 0.5

        # Boost for fully resolved
        if result.resolution_status == ResolutionStatus.FULLY_RESOLVED:
            base_confidence = 0.9
        elif result.resolution_status == ResolutionStatus.PARTIALLY_RESOLVED:
            base_confidence = 0.6
        elif result.resolution_status == ResolutionStatus.CONDITIONAL:
            base_confidence = 0.7

        # Reduce for unresolved parts
        if result.unresolved_parts:
            base_confidence -= 0.1 * min(len(result.unresolved_parts), 3)

        # Boost if SQL looks valid
        if self._looks_like_valid_sql(result.reconstructed_sql):
            base_confidence += 0.1

        # Clamp to 0-1
        return max(0.0, min(1.0, base_confidence))

    def _add_reconstruction_notes(self, result: ReconstructedSQL,
                                  var_state: VariableState) -> None:
        """Add helpful notes about the reconstruction."""
        # Note about data type
        if var_state.data_type:
            result.reconstruction_notes.append(
                f"Variable declared as {var_state.data_type}"
            )

        # Note about assignment count
        assignment_count = len(var_state.value_history)
        if assignment_count > 1:
            result.reconstruction_notes.append(
                f"SQL built through {assignment_count} assignments"
            )

        # Note about unresolved variables
        if result.unresolved_parts:
            result.reconstruction_notes.append(
                f"Unresolved: {', '.join(result.unresolved_parts)}"
            )

        # Note about conditional logic
        if result.possible_variants:
            result.reconstruction_notes.append(
                f"Contains {len(result.possible_variants)} conditional variants"
            )


class MultiStatementReconstructor:
    """
    Handle procedures with multiple dynamic SQL statements.

    Tracks dependencies between dynamic SQL statements and
    reconstructs them in the correct order.
    """

    def __init__(self, dialect: str = "tsql"):
        """Initialize multi-statement reconstructor."""
        self.dialect = dialect
        self.reconstructed_statements: List[ReconstructedSQL] = []

    def reconstruct_procedure(self, procedure_sql: str,
                             patterns: List[DynamicSQLPattern],
                             tracker: VariableTracker) -> List[ReconstructedSQL]:
        """
        Reconstruct all dynamic SQL in a procedure.

        Args:
            procedure_sql: Full procedure SQL
            patterns: Detected patterns
            tracker: Variable tracker with state

        Returns:
            List of reconstructed statements in execution order
        """
        # Sort patterns by line number
        sorted_patterns = sorted(patterns, key=lambda p: p.start_line)

        # Create reconstructor
        reconstructor = SQLReconstructor(tracker, self.dialect)

        # Reconstruct each pattern
        results = []
        for pattern in sorted_patterns:
            result = reconstructor.reconstruct(pattern)
            results.append(result)

        self.reconstructed_statements = results
        return results

    def get_fully_resolved(self) -> List[ReconstructedSQL]:
        """Get only fully resolved statements."""
        return [r for r in self.reconstructed_statements
                if r.resolution_status == ResolutionStatus.FULLY_RESOLVED]

    def get_partially_resolved(self) -> List[ReconstructedSQL]:
        """Get partially resolved statements."""
        return [r for r in self.reconstructed_statements
                if r.resolution_status == ResolutionStatus.PARTIALLY_RESOLVED]

    def get_all_resolved_sql(self) -> List[str]:
        """Get SQL text from all resolved statements."""
        sql_list = []
        for result in self.reconstructed_statements:
            if result.reconstructed_sql and result.resolution_status in [
                ResolutionStatus.FULLY_RESOLVED,
                ResolutionStatus.PARTIALLY_RESOLVED
            ]:
                sql_list.append(result.reconstructed_sql)
        return sql_list
