"""
Dynamic SQL Handling Package.

Provides functionality to detect, reconstruct, and extract lineage from
dynamic SQL patterns in stored procedures.

Key components:
- DynamicSQLDetector: Detect EXEC, sp_executesql, EXECUTE IMMEDIATE patterns
- VariableTracker: Track variable assignments and string concatenations
- SQLReconstructor: Reconstruct SQL from tracked fragments
- DynamicSQLAnalyzer: Main orchestrator for dynamic SQL analysis

Multi-Expert Architecture (new):
- DynamicSQLOrchestrator: Coordinates multiple expert agents
- PatternDetectionExpert: Detect dynamic SQL patterns
- VariableTrackingExpert: Track variable assignments
- ControlFlowExpert: Analyze control flow affecting dynamic SQL
- ReconstructionExpert: Assemble SQL from tracked fragments
- ValidationExpert: Validate reconstructed SQL

Usage:
    from dynamic_sql import DynamicSQLAnalyzer, analyze_dynamic_sql

    # Full analysis (sequential mode - backward compatible)
    analyzer = DynamicSQLAnalyzer(dialect="tsql")
    result = analyzer.analyze(procedure_sql)

    # Multi-expert mode (recommended for complex procedures)
    analyzer = DynamicSQLAnalyzer(dialect="tsql", use_multi_expert=True)
    result = analyzer.analyze(procedure_sql)

    # Get reconstructed SQL
    for stmt in result.fully_resolved:
        print(stmt.reconstructed_sql)

    # Or use convenience function
    result = analyze_dynamic_sql(procedure_sql, dialect="tsql")
"""

from .models import (
    DynamicSQLType,
    ResolutionStatus,
    AssignmentType,
    DynamicSQLPattern,
    VariableAssignment,
    VariableState,
    DynamicSQLFragment,
    ReconstructedSQL,
    DynamicSQLStatement,
    DynamicSQLAnalysisResult
)
from .detector import DynamicSQLDetector
from .variable_tracker import VariableTracker
from .reconstructor import SQLReconstructor, MultiStatementReconstructor
from .analyzer import (
    DynamicSQLAnalyzer,
    DynamicSQLLineageHelper,
    analyze_dynamic_sql,
    expand_dynamic_sql
)

# Multi-expert architecture components
from .orchestrator import (
    DynamicSQLOrchestrator,
    ConflictResolver,
    ConflictResolutionStrategy,
    ConfidenceCalculator,
    ProvenanceTracker
)
from .experts import (
    BaseDynamicSQLExpert,
    PatternDetectionExpert,
    VariableTrackingExpert,
    ControlFlowExpert,
    ReconstructionExpert,
    ValidationExpert
)
from .expert_models.data_models import (
    DynamicSQLExpertType,
    DynamicSQLExpertOutput
)
from .expert_models.context_models import DynamicSQLContext

__all__ = [
    # Enums
    'DynamicSQLType',
    'ResolutionStatus',
    'AssignmentType',
    'DynamicSQLExpertType',
    # Data Models
    'DynamicSQLPattern',
    'VariableAssignment',
    'VariableState',
    'DynamicSQLFragment',
    'ReconstructedSQL',
    'DynamicSQLStatement',
    'DynamicSQLAnalysisResult',
    'DynamicSQLExpertOutput',
    'DynamicSQLContext',
    # Core Classes
    'DynamicSQLDetector',
    'VariableTracker',
    'SQLReconstructor',
    'MultiStatementReconstructor',
    'DynamicSQLAnalyzer',
    'DynamicSQLLineageHelper',
    # Multi-Expert Architecture
    'DynamicSQLOrchestrator',
    'ConflictResolver',
    'ConflictResolutionStrategy',
    'ConfidenceCalculator',
    'ProvenanceTracker',
    'BaseDynamicSQLExpert',
    'PatternDetectionExpert',
    'VariableTrackingExpert',
    'ControlFlowExpert',
    'ReconstructionExpert',
    'ValidationExpert',
    # Convenience Functions
    'analyze_dynamic_sql',
    'expand_dynamic_sql',
]
