"""
Context Models for Dynamic SQL Multi-Expert Architecture.

Provides the shared context that flows between experts for collaborative analysis.
"""

from typing import Any, Dict, List, Optional, TYPE_CHECKING
from dataclasses import dataclass, field
from copy import deepcopy

# Use TYPE_CHECKING to avoid circular imports
if TYPE_CHECKING:
    from dynamic_sql.models import DynamicSQLPattern, VariableState, ReconstructedSQL


@dataclass
class RefinementHint:
    """Hint from one expert to another for refinement."""
    source_expert: str
    target_expert: str
    hint_type: str
    hint_data: Dict[str, Any]
    priority: int = 1

    def to_dict(self) -> Dict[str, Any]:
        return {
            "source_expert": self.source_expert,
            "target_expert": self.target_expert,
            "hint_type": self.hint_type,
            "hint_data": self.hint_data,
            "priority": self.priority
        }


@dataclass
class DynamicSQLContext:
    """
    Shared context passed between experts for collaborative analysis.

    This context accumulates results from each expert phase and allows
    later experts to build on earlier analysis.
    """
    # Input data
    sql_text: str
    dialect: str
    procedure_name: Optional[str] = None

    # Results from PatternDetectionExpert
    detected_patterns: List[Any] = field(default_factory=list)  # List[DynamicSQLPattern]

    # Results from VariableTrackingExpert
    variable_states: Dict[str, Any] = field(default_factory=dict)  # Dict[str, VariableState]

    # Results from ControlFlowExpert
    control_flow_graph: Optional[Any] = None  # ControlFlowGraph type

    # Results from ReconstructionExpert
    reconstructed_statements: List[Any] = field(default_factory=list)  # List[ReconstructedSQL]

    # Validation results
    validation_results: List[Any] = field(default_factory=list)

    # Refinement tracking
    iteration: int = 0
    max_iterations: int = 3
    refinement_hints: List[RefinementHint] = field(default_factory=list)
    refinement_history: List[Dict[str, Any]] = field(default_factory=list)

    # Metadata
    metadata: Dict[str, Any] = field(default_factory=dict)

    def clone(self) -> 'DynamicSQLContext':
        """Create a deep copy for refinement iterations."""
        return deepcopy(self)

    def add_refinement_hint(self, hint: RefinementHint) -> None:
        """Add a refinement hint."""
        self.refinement_hints.append(hint)

    def get_hints_for_expert(self, expert_name: str) -> List[RefinementHint]:
        """Get all hints targeted at a specific expert."""
        return [h for h in self.refinement_hints if h.target_expert == expert_name]

    def clear_hints(self) -> None:
        """Clear all refinement hints (after applying them)."""
        self.refinement_hints = []

    def record_refinement(self, expert_name: str, changes: Dict[str, Any]) -> None:
        """Record what changed during a refinement iteration."""
        self.refinement_history.append({
            "iteration": self.iteration,
            "expert": expert_name,
            "changes": changes
        })

    def has_dynamic_sql(self) -> bool:
        """Check if any dynamic SQL patterns were detected."""
        return len(self.detected_patterns) > 0

    def get_pattern_variables(self) -> List[str]:
        """Get all variables referenced in detected patterns."""
        return list(set(p.variable_name for p in self.detected_patterns))

    def get_sql_building_variables(self) -> List[str]:
        """Get all variables that are used to build SQL."""
        sql_vars = []
        for name, state in self.variable_states.items():
            if state.is_sql_fragment:
                sql_vars.append(name)
        return sql_vars

    def to_dict(self) -> Dict[str, Any]:
        """Convert context to dictionary for serialization."""
        return {
            "sql_text_length": len(self.sql_text),
            "dialect": self.dialect,
            "procedure_name": self.procedure_name,
            "detected_patterns_count": len(self.detected_patterns),
            "variable_states_count": len(self.variable_states),
            "has_control_flow_graph": self.control_flow_graph is not None,
            "reconstructed_statements_count": len(self.reconstructed_statements),
            "iteration": self.iteration,
            "refinement_hints_count": len(self.refinement_hints),
            "metadata": self.metadata
        }

    def get_summary(self) -> str:
        """Get a human-readable summary of the context."""
        lines = [
            f"Dynamic SQL Context Summary:",
            f"  Dialect: {self.dialect}",
            f"  Procedure: {self.procedure_name or 'Unknown'}",
            f"  Patterns detected: {len(self.detected_patterns)}",
            f"  Variables tracked: {len(self.variable_states)}",
            f"  Control flow analyzed: {self.control_flow_graph is not None}",
            f"  Statements reconstructed: {len(self.reconstructed_statements)}",
            f"  Current iteration: {self.iteration}",
        ]
        return "\n".join(lines)
