# Dynamic SQL

## Overview
The Dynamic SQL module handles analysis and reconstruction of dynamically generated SQL statements. It uses a multi-expert architecture to detect, analyze, and reconstruct SQL built at runtime.

## Architecture

### Multi-Expert System
The module employs specialized experts that work collaboratively:
- **Pattern Detection Expert** - Identifies dynamic SQL patterns
- **Variable Tracking Expert** - Tracks variable assignments and flow
- **Control Flow Expert** - Analyzes IF/ELSE, loops, and branching
- **Reconstruction Expert** - Rebuilds possible SQL statements
- **Validation Expert** - Validates reconstructed SQL

### Orchestration
The orchestrator coordinates expert execution, resolves conflicts, and produces final results with confidence scores.

## Module Structure

```
dynamic_sql/
├── analyzer.py              # Main analysis interface
├── detector.py              # Dynamic SQL detection
├── models.py                # Core data models
├── reconstructor.py         # SQL reconstruction
├── variable_tracker.py      # Variable tracking utilities
├── expert_models/           # Expert data models
│   ├── context_models.py
│   └── data_models.py
├── experts/                 # Individual expert implementations
│   ├── base_dynamic_expert.py
│   ├── pattern_detection_expert.py
│   ├── variable_tracking_expert.py
│   ├── control_flow_expert.py
│   ├── reconstruction_expert.py
│   └── validation_expert.py
└── orchestrator/            # Expert coordination
    ├── dynamic_sql_orchestrator.py
    ├── confidence_calculator.py
    ├── conflict_resolver.py
    └── provenance_tracker.py
```

## Components

### Core Modules

#### `analyzer.py`
Main interface for dynamic SQL analysis.

#### `detector.py`
Detects dynamic SQL patterns in code.

**Detection Patterns:**
- String concatenation for SQL building
- Variable-based table/column names
- Conditional SQL construction
- EXECUTE/EXEC statements
- Dynamic DDL

#### `reconstructor.py`
Reconstructs possible SQL statements from dynamic code.

#### `variable_tracker.py`
Tracks variable assignments and values throughout code flow.

### Expert Models (`expert_models/`)

#### `context_models.py`
Context data structures for expert analysis.

**Models:**
- `DynamicSQLContext` - Analysis context
- `VariableContext` - Variable state
- `ExecutionContext` - Runtime context

#### `data_models.py`
Expert output and result models.

**Models:**
- `DynamicSQLExpertType` - Expert type enumeration
- `DynamicSQLExpertOutput` - Expert result structure

### Experts (`experts/`)

#### `pattern_detection_expert.py`
Identifies dynamic SQL construction patterns.

**Detects:**
- String concatenation patterns
- Dynamic table/column references
- Conditional SQL building
- Parameter substitution

#### `variable_tracking_expert.py`
Tracks variable assignments and flow.

**Capabilities:**
- Variable lifecycle tracking
- Value propagation
- Scope analysis
- Assignment detection

#### `control_flow_expert.py`
Analyzes control flow impact on SQL.

**Analyzes:**
- IF/ELSE branches
- CASE statements
- Loop iterations
- Exception handling

#### `reconstruction_expert.py`
Reconstructs possible SQL statements.

**Produces:**
- Fully resolved SQL
- Partially resolved SQL with placeholders
- Confidence scores
- Multiple possible variations

#### `validation_expert.py`
Validates reconstructed SQL.

**Validates:**
- SQL syntax
- Semantic correctness
- Schema compatibility
- Logical consistency

### Orchestrator (`orchestrator/`)

#### `dynamic_sql_orchestrator.py`
Main coordinator for multi-expert analysis.

**Responsibilities:**
- Execute experts in parallel
- Collect and merge results
- Resolve conflicts
- Calculate confidence
- Track provenance

#### `confidence_calculator.py`
Calculates confidence scores for reconstructions.

**Factors:**
- Expert agreement
- Pattern strength
- Variable resolution
- Validation results

#### `conflict_resolver.py`
Resolves conflicts between expert outputs.

**Strategies:**
- Highest confidence
- Majority vote
- Expert priority
- Weighted consensus

#### `provenance_tracker.py`
Tracks the origin and reasoning for results.

**Tracks:**
- Expert contributions
- Decision points
- Confidence sources
- Conflict resolutions

## Usage Example

```python
from dynamic_sql.analyzer import DynamicSQLAnalyzer

# Initialize analyzer
analyzer = DynamicSQLAnalyzer(dialect="teradata")

# Analyze dynamic SQL
sql_code = """
SET @table_name = 'CUSTOMERS';
SET @sql = 'SELECT * FROM ' + @table_name + ' WHERE status = ''ACTIVE''';
EXECUTE(@sql);
"""

result = analyzer.analyze(sql_code)

# Access results
print(f"Detected dynamic SQL: {result.has_dynamic_sql}")
print(f"Reconstructed statements: {len(result.reconstructed_statements)}")
print(f"Confidence: {result.confidence}")

for statement in result.fully_resolved_sql:
    print(f"SQL: {statement}")
```

## Key Features

### Detection
- Automatic dynamic SQL detection
- Pattern recognition
- Multiple construction styles

### Analysis
- Multi-expert collaborative analysis
- Parallel processing
- Confidence scoring

### Reconstruction
- Generate possible SQL statements
- Handle variables and parameters
- Support complex control flow

### Validation
- Syntax validation
- Semantic checking
- Schema compatibility

## Output Structure

```python
{
    "success": true,
    "reconstructed_statements": [...],
    "fully_resolved_sql": [...],
    "all_sql": [...],
    "combined_confidence": 0.85,
    "expert_outputs": {...},
    "provenance": {...},
    "conflicts": {...},
    "warnings": [...],
    "errors": []
}
```

## Integration Points
- Inputs: SQL/Procedural code with dynamic SQL
- Used by: lineage, documentation, agent_interface
- Outputs: Reconstructed SQL, confidence scores, analysis results
