"""
Dynamic SQL Analyzer module.

Main orchestrator that coordinates detection, variable tracking,
and SQL reconstruction for comprehensive dynamic SQL analysis.

Supports two modes:
1. Sequential pipeline (original): Detector → Tracker → Reconstructor
2. Multi-expert architecture (new): Parallel experts with refinement
"""

import re
from typing import List, Dict, Optional, Tuple, Any
from dataclasses import dataclass, field

from dynamic_sql.models import (
    DynamicSQLPattern, DynamicSQLType, ReconstructedSQL,
    ResolutionStatus, DynamicSQLAnalysisResult, VariableState
)
from dynamic_sql.detector import DynamicSQLDetector
from dynamic_sql.variable_tracker import VariableTracker
from dynamic_sql.reconstructor import SQLReconstructor, MultiStatementReconstructor

# Import multi-expert components (lazy import to avoid circular dependencies)
_orchestrator_module = None


def _get_orchestrator_class():
    """Lazy import of orchestrator to avoid circular dependencies."""
    global _orchestrator_module
    if _orchestrator_module is None:
        from dynamic_sql.orchestrator import DynamicSQLOrchestrator
        _orchestrator_module = DynamicSQLOrchestrator
    return _orchestrator_module


class DynamicSQLAnalyzer:
    """
    Main analyzer for dynamic SQL in stored procedures.

    Orchestrates:
    1. Pattern detection (EXEC, sp_executesql, EXECUTE IMMEDIATE)
    2. Variable tracking (declarations, assignments, concatenations)
    3. SQL reconstruction (assembling final SQL)

    Supports two modes:
    - Sequential pipeline (use_multi_expert=False): Original implementation
    - Multi-expert architecture (use_multi_expert=True): Parallel experts with refinement

    Usage:
        # Original sequential mode
        analyzer = DynamicSQLAnalyzer(dialect="tsql")
        result = analyzer.analyze(procedure_sql)

        # New multi-expert mode (recommended)
        analyzer = DynamicSQLAnalyzer(dialect="tsql", use_multi_expert=True)
        result = analyzer.analyze(procedure_sql)

        for stmt in result.fully_resolved:
            print(stmt.reconstructed_sql)
    """

    def __init__(self, dialect: str = "tsql", use_multi_expert: bool = False):
        """
        Initialize the analyzer.

        Args:
            dialect: SQL dialect (tsql, teradata, oracle)
            use_multi_expert: Use multi-expert architecture (default: False for backward compatibility)
        """
        self.dialect = dialect.lower()
        self.use_multi_expert = use_multi_expert
        self._procedure_name: Optional[str] = None

        # Initialize orchestrator for multi-expert mode
        self._orchestrator = None
        self._last_orchestrator_result = None

        if use_multi_expert:
            OrchestratorClass = _get_orchestrator_class()
            self._orchestrator = OrchestratorClass(
                dialect=self.dialect,
                enable_parallel=True,
                enable_refinement=True,
                enable_provenance=True
            )
        else:
            # Original components for sequential mode
            self.detector = DynamicSQLDetector(dialect)
            self.tracker = VariableTracker(dialect)

    def analyze(self, sql: str, procedure_name: Optional[str] = None) -> DynamicSQLAnalysisResult:
        """
        Perform complete dynamic SQL analysis.

        Args:
            sql: SQL text (stored procedure or script)
            procedure_name: Optional procedure name for reporting

        Returns:
            DynamicSQLAnalysisResult with all findings
        """
        self._procedure_name = procedure_name or self._extract_procedure_name(sql)

        # Use multi-expert architecture if enabled
        if self.use_multi_expert and self._orchestrator:
            return self._analyze_multi_expert(sql)

        # Original sequential implementation
        return self._analyze_sequential(sql)

    def _analyze_sequential(self, sql: str) -> DynamicSQLAnalysisResult:
        """
        Perform analysis using original sequential pipeline.

        Args:
            sql: SQL text to analyze

        Returns:
            DynamicSQLAnalysisResult
        """
        result = DynamicSQLAnalysisResult(
            procedure_name=self._procedure_name
        )

        # Step 1: Detect dynamic SQL patterns
        patterns = self.detector.detect(sql)
        result.detected_patterns = patterns

        if not patterns:
            result.analysis_warnings.append("No dynamic SQL patterns detected")
            return result

        # Step 2: Track variable assignments
        self.tracker.track_all(sql)

        # Step 3: Reconstruct SQL for each pattern
        reconstructor = MultiStatementReconstructor(self.dialect)
        reconstructed = reconstructor.reconstruct_procedure(
            sql, patterns, self.tracker
        )
        result.reconstructed_statements = reconstructed

        # Step 4: Categorize results
        for stmt in reconstructed:
            if stmt.resolution_status == ResolutionStatus.FULLY_RESOLVED:
                result.fully_resolved.append(stmt)
            elif stmt.resolution_status == ResolutionStatus.PARTIALLY_RESOLVED:
                result.partially_resolved.append(stmt)
            elif stmt.resolution_status == ResolutionStatus.CONDITIONAL:
                result.partially_resolved.append(stmt)
            else:
                result.unresolvable.append(stmt.original_pattern)

        # Step 5: Add analysis warnings
        self._add_analysis_warnings(result, sql)

        return result

    def _analyze_multi_expert(self, sql: str) -> DynamicSQLAnalysisResult:
        """
        Perform analysis using multi-expert architecture.

        Args:
            sql: SQL text to analyze

        Returns:
            DynamicSQLAnalysisResult (converted from orchestrator result)
        """
        # Run orchestrator
        orchestrator_result = self._orchestrator.analyze(sql, self._procedure_name)
        self._last_orchestrator_result = orchestrator_result

        # Convert to DynamicSQLAnalysisResult for backward compatibility
        result = DynamicSQLAnalysisResult(
            procedure_name=self._procedure_name
        )

        if not orchestrator_result.success:
            result.analysis_warnings.extend(orchestrator_result.errors)
            return result

        # Get pattern detection output for detected_patterns
        pattern_output = orchestrator_result.expert_outputs.get('PatternDetectionExpert')
        if pattern_output and pattern_output.success:
            # The context should have the actual pattern objects
            context = self._orchestrator.get_context()
            if context:
                result.detected_patterns = list(context.detected_patterns)

        # Convert reconstructed statements
        recon_output = orchestrator_result.expert_outputs.get('ReconstructionExpert')
        if recon_output and recon_output.success:
            context = self._orchestrator.get_context()
            if context and context.reconstructed_statements:
                result.reconstructed_statements = list(context.reconstructed_statements)

                # Categorize statements
                for stmt in result.reconstructed_statements:
                    if stmt.resolution_status == ResolutionStatus.FULLY_RESOLVED:
                        result.fully_resolved.append(stmt)
                    elif stmt.resolution_status == ResolutionStatus.PARTIALLY_RESOLVED:
                        result.partially_resolved.append(stmt)
                    elif stmt.resolution_status == ResolutionStatus.CONDITIONAL:
                        result.partially_resolved.append(stmt)
                    else:
                        if stmt.original_pattern:
                            result.unresolvable.append(stmt.original_pattern)

        # Add warnings from orchestrator
        result.analysis_warnings.extend(orchestrator_result.warnings)

        # Add multi-expert specific metadata
        result.analysis_warnings.append(
            f"Multi-expert analysis: confidence={orchestrator_result.combined_confidence:.2f}, "
            f"iterations={orchestrator_result.iterations}"
        )

        return result

    def get_multi_expert_details(self) -> Optional[Dict[str, Any]]:
        """
        Get detailed results from multi-expert analysis.

        Only available when use_multi_expert=True and after calling analyze().

        Returns:
            Dict with provenance, confidence breakdown, and expert outputs
        """
        if not self.use_multi_expert or not self._last_orchestrator_result:
            return None

        return {
            'combined_confidence': self._last_orchestrator_result.combined_confidence,
            'execution_time_ms': self._last_orchestrator_result.execution_time_ms,
            'iterations': self._last_orchestrator_result.iterations,
            'provenance': self._last_orchestrator_result.provenance,
            'conflicts': self._last_orchestrator_result.conflicts,
            'confidence_breakdown': self._orchestrator.get_confidence_breakdown() if self._orchestrator else None,
            'expert_outputs': {
                name: {
                    'success': output.success,
                    'confidence': output.confidence,
                    'execution_time_ms': output.execution_time_ms,
                    'warnings': output.warnings,
                    'requires_refinement': output.requires_refinement
                }
                for name, output in self._last_orchestrator_result.expert_outputs.items()
            }
        }

    def analyze_and_expand(self, sql: str) -> Tuple[str, DynamicSQLAnalysisResult]:
        """
        Analyze dynamic SQL and return expanded SQL with dynamic parts inline.

        This method replaces EXEC(@sql) calls with the reconstructed SQL
        as comments, making the full logic visible.

        Args:
            sql: Original SQL text

        Returns:
            Tuple of (expanded_sql, analysis_result)
        """
        result = self.analyze(sql)

        if not result.has_dynamic_sql():
            return sql, result

        expanded = sql

        # Replace each dynamic SQL execution with expanded version
        for stmt in result.fully_resolved + result.partially_resolved:
            pattern = stmt.original_pattern
            reconstructed = stmt.reconstructed_sql

            # Create expansion comment
            status = "FULLY RESOLVED" if stmt.is_complete else "PARTIALLY RESOLVED"
            expansion = self._create_expansion_comment(
                pattern, reconstructed, status
            )

            # Insert expansion after the original EXEC statement
            expanded = self._insert_expansion(
                expanded, pattern.execution_sql, expansion
            )

        return expanded, result

    def get_expanded_statements(self, sql: str) -> List[Dict[str, Any]]:
        """
        Get list of expanded dynamic SQL statements for lineage extraction.

        Args:
            sql: Original SQL text

        Returns:
            List of dicts with original and expanded SQL info
        """
        result = self.analyze(sql)
        expanded_list = []

        for stmt in result.fully_resolved + result.partially_resolved:
            expanded_list.append({
                'original_exec': stmt.original_pattern.execution_sql,
                'variable_name': stmt.original_pattern.variable_name,
                'expanded_sql': stmt.reconstructed_sql,
                'is_complete': stmt.is_complete,
                'status': stmt.resolution_status.value,
                'confidence': stmt.confidence,
                'line_number': stmt.original_pattern.start_line,
                'unresolved_parts': stmt.unresolved_parts,
                'notes': stmt.reconstruction_notes
            })

        return expanded_list

    def _extract_procedure_name(self, sql: str) -> Optional[str]:
        """Extract procedure name from CREATE PROCEDURE statement."""
        patterns = [
            # T-SQL
            r'CREATE\s+(?:OR\s+(?:ALTER|REPLACE)\s+)?PROC(?:EDURE)?\s+(?:\[?\w+\]?\.)?(\[?\w+\]?)',
            # Teradata
            r'(?:CREATE|REPLACE)\s+PROCEDURE\s+(?:\w+\.)?(\w+)',
            # Oracle
            r'CREATE\s+(?:OR\s+REPLACE\s+)?PROCEDURE\s+(?:\w+\.)?(\w+)'
        ]

        for pattern in patterns:
            match = re.search(pattern, sql, re.IGNORECASE)
            if match:
                return match.group(1).strip('[]')

        return None

    def _create_expansion_comment(self, pattern: DynamicSQLPattern,
                                  reconstructed_sql: str,
                                  status: str) -> str:
        """Create a comment block showing the expanded SQL."""
        lines = [
            "/* ========== DYNAMIC SQL EXPANSION ==========",
            f"   Status: {status}",
            f"   Variable: {pattern.variable_name}",
            f"   Pattern Type: {pattern.pattern_type.value}",
            "   ---------- Expanded SQL ----------",
        ]

        # Add reconstructed SQL with indentation
        for line in reconstructed_sql.split('\n'):
            lines.append(f"   {line}")

        lines.append("   ============================================ */")

        return '\n'.join(lines)

    def _insert_expansion(self, sql: str, exec_statement: str,
                         expansion: str) -> str:
        """Insert expansion comment after the EXEC statement."""
        # Find the exec statement
        escaped = re.escape(exec_statement)
        pattern = rf'({escaped}[;\s]*)'

        def replacer(match):
            return match.group(1) + '\n' + expansion + '\n'

        return re.sub(pattern, replacer, sql, count=1, flags=re.IGNORECASE)

    def _add_analysis_warnings(self, result: DynamicSQLAnalysisResult,
                               sql: str) -> None:
        """Add warnings about potential issues."""
        # Warn about cursor-based dynamic SQL
        if re.search(r'\bCURSOR\b.*\bEXEC', sql, re.IGNORECASE | re.DOTALL):
            result.analysis_warnings.append(
                "Dynamic SQL inside cursor detected - may have multiple executions"
            )

        # Warn about loops
        if re.search(r'\bWHILE\b.*\bEXEC', sql, re.IGNORECASE | re.DOTALL):
            result.analysis_warnings.append(
                "Dynamic SQL inside WHILE loop detected - SQL may vary per iteration"
            )

        # Warn about unresolved runtime values
        for stmt in result.partially_resolved:
            if stmt.unresolved_parts:
                for unresolved in stmt.unresolved_parts:
                    if '@' in unresolved or ':' in unresolved:
                        result.analysis_warnings.append(
                            f"Runtime variable {unresolved} could not be resolved"
                        )

        # Warn about conditional SQL
        conditional_count = sum(
            1 for stmt in result.reconstructed_statements
            if stmt.resolution_status == ResolutionStatus.CONDITIONAL
        )
        if conditional_count > 0:
            result.analysis_warnings.append(
                f"{conditional_count} statement(s) have conditional variants"
            )


class DynamicSQLLineageHelper:
    """
    Helper class to integrate dynamic SQL analysis with lineage extraction.

    Provides methods to extract lineage from reconstructed dynamic SQL
    and merge it with the main lineage graph.
    """

    def __init__(self, analyzer: DynamicSQLAnalyzer):
        """
        Initialize helper.

        Args:
            analyzer: DynamicSQLAnalyzer instance
        """
        self.analyzer = analyzer

    def get_lineage_sql(self, procedure_sql: str) -> List[str]:
        """
        Get list of SQL statements for lineage extraction.

        Includes both static SQL and reconstructed dynamic SQL.

        Args:
            procedure_sql: Full procedure SQL

        Returns:
            List of SQL statements to analyze for lineage
        """
        result = self.analyzer.analyze(procedure_sql)
        sql_list = []

        # Get reconstructed dynamic SQL
        for stmt in result.fully_resolved:
            if stmt.reconstructed_sql:
                sql_list.append(stmt.reconstructed_sql)

        # Also include partially resolved with high confidence
        for stmt in result.partially_resolved:
            if stmt.confidence >= 0.7 and stmt.reconstructed_sql:
                sql_list.append(stmt.reconstructed_sql)

        return sql_list

    def get_dynamic_sql_metadata(self, procedure_sql: str) -> Dict[str, Any]:
        """
        Get metadata about dynamic SQL for documentation.

        Args:
            procedure_sql: Full procedure SQL

        Returns:
            Dictionary with dynamic SQL metadata
        """
        result = self.analyzer.analyze(procedure_sql)

        return {
            'has_dynamic_sql': result.has_dynamic_sql(),
            'total_patterns': len(result.detected_patterns),
            'fully_resolved_count': len(result.fully_resolved),
            'partially_resolved_count': len(result.partially_resolved),
            'unresolvable_count': len(result.unresolvable),
            'warnings': result.analysis_warnings,
            'patterns': [
                {
                    'type': p.pattern_type.value,
                    'variable': p.variable_name,
                    'line': p.start_line
                }
                for p in result.detected_patterns
            ]
        }


def analyze_dynamic_sql(sql: str, dialect: str = "tsql") -> DynamicSQLAnalysisResult:
    """
    Convenience function for one-off dynamic SQL analysis.

    Args:
        sql: SQL text to analyze
        dialect: SQL dialect

    Returns:
        DynamicSQLAnalysisResult
    """
    analyzer = DynamicSQLAnalyzer(dialect)
    return analyzer.analyze(sql)


def expand_dynamic_sql(sql: str, dialect: str = "tsql") -> str:
    """
    Convenience function to expand dynamic SQL in place.

    Args:
        sql: SQL text with dynamic SQL
        dialect: SQL dialect

    Returns:
        SQL with dynamic parts expanded as comments
    """
    analyzer = DynamicSQLAnalyzer(dialect)
    expanded, _ = analyzer.analyze_and_expand(sql)
    return expanded
