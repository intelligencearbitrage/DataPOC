"""
Control Flow Expert for Dynamic SQL Analysis.

Analyzes IF/WHILE/CURSOR control flow structures to understand
how they affect dynamic SQL execution.
"""

import re
from typing import Any, Dict, List, Optional, Tuple

import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

from dynamic_sql.experts.base_dynamic_expert import BaseDynamicSQLExpert
from dynamic_sql.expert_models.data_models import (
    DynamicSQLExpertType,
    DynamicSQLExpertOutput,
    ControlFlowNodeType,
    ControlFlowNode,
    ControlFlowEdge,
    ControlFlowGraph
)
from dynamic_sql.expert_models.context_models import DynamicSQLContext, RefinementHint


class ControlFlowExpert(BaseDynamicSQLExpert):
    """
    Expert for analyzing control flow in stored procedures.

    NEW implementation for the multi-expert architecture.
    Can run in parallel with VariableTrackingExpert.

    Analyzes:
    - IF/ELSE/ELSEIF blocks
    - WHILE loops
    - CURSOR declarations and FETCH loops
    - TRY/CATCH blocks
    - Dynamic SQL statements within control flow
    """

    def __init__(self, dialect: str = "tsql"):
        """
        Initialize the control flow expert.

        Args:
            dialect: SQL dialect (tsql, teradata, oracle)
        """
        super().__init__(dialect)
        self._node_counter = 0

    @property
    def expert_type(self) -> DynamicSQLExpertType:
        """Return the expert type."""
        return DynamicSQLExpertType.CONTROL_FLOW

    def get_dependencies(self) -> List[DynamicSQLExpertType]:
        """Depends on pattern detection."""
        return [DynamicSQLExpertType.PATTERN_DETECTION]

    def can_execute_parallel(self, other_expert: 'BaseDynamicSQLExpert') -> bool:
        """Can run parallel with variable tracking."""
        if other_expert.expert_type == DynamicSQLExpertType.VARIABLE_TRACKING:
            return True
        return super().can_execute_parallel(other_expert)

    def analyze(self, sql: str, **kwargs) -> DynamicSQLExpertOutput:
        """
        Build control flow graph from SQL.

        Args:
            sql: SQL text to analyze
            **kwargs: Additional parameters

        Returns:
            DynamicSQLExpertOutput with control flow graph
        """
        self._start_timer()
        self._node_counter = 0

        if not self.validate_input(sql):
            return self._create_error_output("Invalid or empty SQL input")

        try:
            cfg = self._build_control_flow_graph(sql)
            confidence = self._calculate_confidence(cfg)

            data = {
                'node_count': len(cfg.nodes),
                'edge_count': len(cfg.edges),
                'has_loops': cfg.has_loops,
                'has_cursors': cfg.has_cursors,
                'has_conditionals': cfg.has_conditionals,
                'dynamic_sql_nodes': cfg.dynamic_sql_nodes,
                'execution_path_count': len(cfg.execution_paths),
                'control_flow_graph': cfg.to_dict()
            }

            warnings = []
            if cfg.has_loops:
                warnings.append("Dynamic SQL inside loops detected - may execute multiple times")
            if cfg.has_cursors:
                warnings.append("Dynamic SQL with cursors detected - iterative execution")

            return self._create_output(
                success=True,
                data=data,
                context_updates={'control_flow_graph': cfg},
                confidence=confidence,
                warnings=warnings
            )

        except Exception as e:
            return self._create_error_output(f"Control flow analysis failed: {str(e)}")

    def analyze_with_context(self, context: DynamicSQLContext) -> DynamicSQLExpertOutput:
        """
        Analyze control flow with awareness of detected patterns.

        Args:
            context: Shared context with detected patterns

        Returns:
            DynamicSQLExpertOutput with control flow graph
        """
        self._start_timer()
        self._node_counter = 0

        if not self.validate_context(context):
            return self._create_error_output("Invalid context")

        try:
            # Build basic control flow graph
            cfg = self._build_control_flow_graph(context.sql_text)

            # Annotate with pattern information
            pattern_lines = {p.start_line for p in context.detected_patterns}
            for node_id, node in cfg.nodes.items():
                if node.line_number in pattern_lines:
                    node.is_dynamic_sql_related = True
                    if node_id not in cfg.dynamic_sql_nodes:
                        cfg.dynamic_sql_nodes.append(node_id)

            # Find execution paths that include dynamic SQL
            cfg.execution_paths = self._find_execution_paths(cfg)

            confidence = self._calculate_confidence(cfg)

            data = {
                'node_count': len(cfg.nodes),
                'edge_count': len(cfg.edges),
                'has_loops': cfg.has_loops,
                'has_cursors': cfg.has_cursors,
                'has_conditionals': cfg.has_conditionals,
                'dynamic_sql_nodes': cfg.dynamic_sql_nodes,
                'execution_path_count': len(cfg.execution_paths),
                'control_flow_graph': cfg.to_dict()
            }

            warnings = []
            requires_refinement = False

            if cfg.has_loops and cfg.dynamic_sql_nodes:
                warnings.append("Dynamic SQL inside loops - SQL may vary per iteration")
                requires_refinement = True

            if cfg.has_conditionals and cfg.dynamic_sql_nodes:
                warnings.append("Dynamic SQL in conditional blocks - multiple execution paths")

            return self._create_output(
                success=True,
                data=data,
                context_updates={'control_flow_graph': cfg},
                confidence=confidence,
                warnings=warnings,
                requires_refinement=requires_refinement
            )

        except Exception as e:
            return self._create_error_output(f"Control flow analysis failed: {str(e)}")

    def refine(self, context: DynamicSQLContext,
               previous_outputs: Dict[str, DynamicSQLExpertOutput]) -> DynamicSQLExpertOutput:
        """
        Refine control flow analysis based on variable tracking.

        Args:
            context: Current context
            previous_outputs: Outputs from other experts

        Returns:
            Refined DynamicSQLExpertOutput
        """
        self._start_timer()

        cfg = context.control_flow_graph
        if not cfg:
            return self.analyze_with_context(context)

        # Use variable tracking to annotate nodes
        variable_output = previous_outputs.get('VariableTrackingExpert')
        if variable_output and variable_output.success:
            variables = variable_output.data.get('variables', {})
            self._annotate_with_variables(cfg, variables)

        confidence = self._calculate_confidence(cfg)

        data = {
            'node_count': len(cfg.nodes),
            'edge_count': len(cfg.edges),
            'has_loops': cfg.has_loops,
            'has_cursors': cfg.has_cursors,
            'dynamic_sql_nodes': cfg.dynamic_sql_nodes,
            'refined': True,
            'iteration': context.iteration,
            'control_flow_graph': cfg.to_dict()
        }

        return self._create_output(
            success=True,
            data=data,
            context_updates={'control_flow_graph': cfg},
            confidence=confidence
        )

    def _build_control_flow_graph(self, sql: str) -> ControlFlowGraph:
        """Build a control flow graph from SQL."""
        cfg = ControlFlowGraph()

        # Create entry node
        entry_node = self._create_node(ControlFlowNodeType.ENTRY, 0)
        cfg.add_node(entry_node)
        cfg.entry_node_id = entry_node.node_id

        # Parse control flow structures
        lines = sql.split('\n')
        current_node = entry_node
        block_stack = []  # Track nested blocks

        for line_num, line in enumerate(lines, 1):
            stripped = line.strip().upper()

            # Skip empty lines and comments
            if not stripped or stripped.startswith('--') or stripped.startswith('/*'):
                continue

            # Detect control flow structures
            if self._is_if_start(stripped):
                cfg.has_conditionals = True
                condition = self._extract_condition(line)
                if_node = self._create_node(
                    ControlFlowNodeType.IF, line_num,
                    condition=condition, sql_text=line.strip()
                )
                cfg.add_node(if_node)
                cfg.add_edge(ControlFlowEdge(
                    edge_id=f"edge_{len(cfg.edges)}",
                    source_id=current_node.node_id,
                    target_id=if_node.node_id
                ))
                block_stack.append(('IF', if_node, current_node))
                current_node = if_node

            elif self._is_else(stripped):
                if block_stack and block_stack[-1][0] == 'IF':
                    else_node = self._create_node(
                        ControlFlowNodeType.ELSE, line_num, sql_text=line.strip()
                    )
                    cfg.add_node(else_node)
                    # Connect from IF node with false branch
                    if_node = block_stack[-1][1]
                    cfg.add_edge(ControlFlowEdge(
                        edge_id=f"edge_{len(cfg.edges)}",
                        source_id=if_node.node_id,
                        target_id=else_node.node_id,
                        edge_type="FALSE_BRANCH"
                    ))
                    block_stack[-1] = ('ELSE', else_node, block_stack[-1][2])
                    current_node = else_node

            elif self._is_while_start(stripped):
                cfg.has_loops = True
                condition = self._extract_condition(line)
                while_node = self._create_node(
                    ControlFlowNodeType.WHILE, line_num,
                    condition=condition, sql_text=line.strip()
                )
                cfg.add_node(while_node)
                cfg.add_edge(ControlFlowEdge(
                    edge_id=f"edge_{len(cfg.edges)}",
                    source_id=current_node.node_id,
                    target_id=while_node.node_id
                ))
                block_stack.append(('WHILE', while_node, current_node))
                current_node = while_node

            elif self._is_cursor_declare(stripped):
                cfg.has_cursors = True
                cursor_node = self._create_node(
                    ControlFlowNodeType.CURSOR_OPEN, line_num, sql_text=line.strip()
                )
                cfg.add_node(cursor_node)
                cfg.add_edge(ControlFlowEdge(
                    edge_id=f"edge_{len(cfg.edges)}",
                    source_id=current_node.node_id,
                    target_id=cursor_node.node_id
                ))
                current_node = cursor_node

            elif self._is_exec(stripped):
                exec_node = self._create_node(
                    ControlFlowNodeType.EXEC, line_num,
                    sql_text=line.strip(), is_dynamic=True
                )
                exec_node.is_dynamic_sql_related = True
                cfg.add_node(exec_node)
                cfg.add_edge(ControlFlowEdge(
                    edge_id=f"edge_{len(cfg.edges)}",
                    source_id=current_node.node_id,
                    target_id=exec_node.node_id
                ))
                current_node = exec_node

            elif self._is_end(stripped):
                if block_stack:
                    block_type, block_node, pre_block_node = block_stack.pop()
                    end_node = self._create_node(
                        ControlFlowNodeType.END, line_num, sql_text=line.strip()
                    )
                    cfg.add_node(end_node)

                    # Connect current to end
                    cfg.add_edge(ControlFlowEdge(
                        edge_id=f"edge_{len(cfg.edges)}",
                        source_id=current_node.node_id,
                        target_id=end_node.node_id
                    ))

                    # For WHILE, add loop back edge
                    if block_type == 'WHILE':
                        cfg.add_edge(ControlFlowEdge(
                            edge_id=f"edge_{len(cfg.edges)}",
                            source_id=end_node.node_id,
                            target_id=block_node.node_id,
                            edge_type="LOOP_BACK"
                        ))

                    current_node = end_node

        # Create exit node
        exit_node = self._create_node(ControlFlowNodeType.EXIT, len(lines))
        cfg.add_node(exit_node)
        cfg.add_edge(ControlFlowEdge(
            edge_id=f"edge_{len(cfg.edges)}",
            source_id=current_node.node_id,
            target_id=exit_node.node_id
        ))
        cfg.exit_node_ids.append(exit_node.node_id)

        return cfg

    def _create_node(self, node_type: ControlFlowNodeType, line_num: int,
                     condition: str = None, sql_text: str = None,
                     is_dynamic: bool = False) -> ControlFlowNode:
        """Create a control flow node."""
        self._node_counter += 1
        return ControlFlowNode(
            node_id=f"node_{self._node_counter}",
            node_type=node_type,
            line_number=line_num,
            condition=condition,
            sql_text=sql_text,
            is_dynamic_sql_related=is_dynamic
        )

    def _is_if_start(self, line: str) -> bool:
        """Check if line starts an IF block."""
        return line.startswith('IF ') or line.startswith('IF(')

    def _is_else(self, line: str) -> bool:
        """Check if line is ELSE."""
        return line.startswith('ELSE') and not line.startswith('ELSEIF')

    def _is_while_start(self, line: str) -> bool:
        """Check if line starts a WHILE loop."""
        return line.startswith('WHILE ')

    def _is_cursor_declare(self, line: str) -> bool:
        """Check if line declares a cursor."""
        return 'DECLARE' in line and 'CURSOR' in line

    def _is_exec(self, line: str) -> bool:
        """Check if line is an EXEC statement."""
        return line.startswith('EXEC ') or line.startswith('EXEC(') or \
               line.startswith('EXECUTE ')

    def _is_end(self, line: str) -> bool:
        """Check if line is END."""
        return line == 'END' or line.startswith('END;') or line.startswith('END ')

    def _extract_condition(self, line: str) -> Optional[str]:
        """Extract condition from IF or WHILE statement."""
        match = re.search(r'(?:IF|WHILE)\s+(.+?)(?:\s+BEGIN|\s*$)', line, re.IGNORECASE)
        if match:
            return match.group(1).strip()
        return None

    def _find_execution_paths(self, cfg: ControlFlowGraph) -> List[List[str]]:
        """Find all execution paths through the graph."""
        paths = []

        def dfs(node_id: str, current_path: List[str], visited: set):
            if node_id in visited:
                return  # Avoid infinite loops
            if len(paths) > 100:
                return  # Limit path explosion

            current_path.append(node_id)
            visited.add(node_id)

            if node_id in cfg.exit_node_ids:
                paths.append(list(current_path))
            else:
                successors = cfg.get_successors(node_id)
                for succ in successors:
                    dfs(succ, current_path, visited.copy())

            current_path.pop()

        if cfg.entry_node_id:
            dfs(cfg.entry_node_id, [], set())

        return paths[:20]  # Limit to 20 paths

    def _calculate_confidence(self, cfg: ControlFlowGraph) -> float:
        """Calculate confidence in control flow analysis."""
        if not cfg.nodes:
            return 0.5

        # Base confidence
        confidence = 0.8

        # Reduce if we have complex structures
        if cfg.has_loops:
            confidence -= 0.1
        if cfg.has_cursors:
            confidence -= 0.1
        if len(cfg.execution_paths) > 10:
            confidence -= 0.1

        return max(confidence, 0.5)

    def _annotate_with_variables(self, cfg: ControlFlowGraph, variables: Dict) -> None:
        """Annotate CFG nodes with variable usage information."""
        for node_id, node in cfg.nodes.items():
            if node.sql_text:
                for var_name in variables.keys():
                    if var_name in node.sql_text:
                        if var_name not in node.variables_read:
                            node.variables_read.append(var_name)
