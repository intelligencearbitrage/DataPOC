"""
Confidence Calculator for Dynamic SQL Multi-Expert Architecture.

Calculates combined confidence scores from multiple expert outputs.
"""

from typing import Any, Dict, List, Optional
from dataclasses import dataclass, field

import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

from dynamic_sql.expert_models.data_models import DynamicSQLExpertOutput, DynamicSQLExpertType


@dataclass
class ConfidenceBreakdown:
    """Breakdown of confidence calculation."""
    expert_name: str
    expert_type: DynamicSQLExpertType
    raw_confidence: float
    weight: float
    weighted_confidence: float
    factors: Dict[str, float] = field(default_factory=dict)


class ConfidenceCalculator:
    """
    Calculate combined confidence scores from multiple expert outputs.

    Features:
    - Weighted averaging based on expert importance
    - Dependency-aware confidence propagation
    - Penalty factors for unresolved issues
    - Bonus factors for high agreement between experts
    """

    # Default weights for each expert type
    DEFAULT_WEIGHTS = {
        DynamicSQLExpertType.PATTERN_DETECTION: 0.20,
        DynamicSQLExpertType.VARIABLE_TRACKING: 0.25,
        DynamicSQLExpertType.CONTROL_FLOW: 0.15,
        DynamicSQLExpertType.RECONSTRUCTION: 0.25,
        DynamicSQLExpertType.VALIDATION: 0.15
    }

    def __init__(self, weights: Optional[Dict[DynamicSQLExpertType, float]] = None):
        """
        Initialize the confidence calculator.

        Args:
            weights: Custom weights for expert types (must sum to 1.0)
        """
        self.weights = weights or self.DEFAULT_WEIGHTS.copy()
        self._normalize_weights()
        self.breakdowns: List[ConfidenceBreakdown] = []

    def _normalize_weights(self) -> None:
        """Normalize weights to sum to 1.0."""
        total = sum(self.weights.values())
        if total > 0:
            self.weights = {k: v / total for k, v in self.weights.items()}

    def set_weight(self, expert_type: DynamicSQLExpertType, weight: float) -> None:
        """
        Set weight for a specific expert type.

        Args:
            expert_type: Expert type to set weight for
            weight: Weight value (will be normalized)
        """
        self.weights[expert_type] = weight
        self._normalize_weights()

    def calculate_combined_confidence(self, outputs: Dict[str, DynamicSQLExpertOutput]) -> float:
        """
        Calculate combined confidence from all expert outputs.

        Args:
            outputs: Dict mapping expert names to their outputs

        Returns:
            Combined confidence score (0.0-1.0)
        """
        self.breakdowns = []

        if not outputs:
            return 0.0

        total_weighted = 0.0
        total_weight = 0.0

        for expert_name, output in outputs.items():
            if not output.success:
                continue

            weight = self.weights.get(output.expert_type, 0.1)

            # Apply adjustment factors
            adjusted_confidence = self._apply_factors(output)

            weighted_confidence = adjusted_confidence * weight

            breakdown = ConfidenceBreakdown(
                expert_name=expert_name,
                expert_type=output.expert_type,
                raw_confidence=output.confidence,
                weight=weight,
                weighted_confidence=weighted_confidence
            )
            self.breakdowns.append(breakdown)

            total_weighted += weighted_confidence
            total_weight += weight

        # Calculate base combined confidence
        if total_weight > 0:
            base_confidence = total_weighted / total_weight
        else:
            base_confidence = 0.0

        # Apply agreement bonus/penalty
        agreement_factor = self._calculate_agreement_factor(outputs)
        final_confidence = base_confidence * agreement_factor

        # Apply completeness bonus
        completeness_factor = self._calculate_completeness_factor(outputs)
        final_confidence *= completeness_factor

        return min(max(final_confidence, 0.0), 1.0)

    def _apply_factors(self, output: DynamicSQLExpertOutput) -> float:
        """
        Apply adjustment factors to an expert's confidence.

        Args:
            output: Expert output

        Returns:
            Adjusted confidence score
        """
        confidence = output.confidence
        factors = {}

        # Penalty for errors
        if output.errors:
            error_penalty = min(len(output.errors) * 0.1, 0.3)
            confidence -= error_penalty
            factors['error_penalty'] = -error_penalty

        # Penalty for warnings
        if output.warnings:
            warning_penalty = min(len(output.warnings) * 0.05, 0.15)
            confidence -= warning_penalty
            factors['warning_penalty'] = -warning_penalty

        # Penalty for requiring refinement
        if output.requires_refinement:
            refinement_penalty = 0.1
            confidence -= refinement_penalty
            factors['refinement_penalty'] = -refinement_penalty

        # Store factors for breakdown
        if self.breakdowns:
            self.breakdowns[-1].factors = factors

        return max(confidence, 0.0)

    def _calculate_agreement_factor(self, outputs: Dict[str, DynamicSQLExpertOutput]) -> float:
        """
        Calculate agreement factor between experts.

        High agreement = bonus, low agreement = penalty.

        Args:
            outputs: Expert outputs

        Returns:
            Agreement factor (0.8-1.2)
        """
        if len(outputs) < 2:
            return 1.0

        confidences = [o.confidence for o in outputs.values() if o.success]

        if not confidences:
            return 1.0

        # Calculate variance in confidence scores
        avg_confidence = sum(confidences) / len(confidences)
        variance = sum((c - avg_confidence) ** 2 for c in confidences) / len(confidences)

        # Low variance = high agreement = bonus
        # High variance = low agreement = penalty
        if variance < 0.01:
            return 1.1  # Strong agreement bonus
        elif variance < 0.05:
            return 1.0  # Normal
        elif variance < 0.1:
            return 0.95  # Slight penalty
        else:
            return 0.9  # Significant disagreement penalty

    def _calculate_completeness_factor(self, outputs: Dict[str, DynamicSQLExpertOutput]) -> float:
        """
        Calculate completeness factor based on all experts running.

        Args:
            outputs: Expert outputs

        Returns:
            Completeness factor (0.8-1.1)
        """
        expected_experts = len(self.weights)
        actual_experts = len([o for o in outputs.values() if o.success])

        completeness = actual_experts / expected_experts if expected_experts > 0 else 0

        if completeness >= 1.0:
            return 1.05  # Small bonus for full coverage
        elif completeness >= 0.8:
            return 1.0
        elif completeness >= 0.6:
            return 0.95
        else:
            return 0.85

    def get_confidence_by_expert(self, outputs: Dict[str, DynamicSQLExpertOutput]) -> Dict[str, float]:
        """
        Get confidence scores broken down by expert.

        Args:
            outputs: Expert outputs

        Returns:
            Dict mapping expert names to confidence scores
        """
        return {
            name: output.confidence
            for name, output in outputs.items()
            if output.success
        }

    def get_lowest_confidence_expert(self, outputs: Dict[str, DynamicSQLExpertOutput]) -> Optional[str]:
        """
        Get the expert with lowest confidence.

        Useful for targeted refinement.

        Args:
            outputs: Expert outputs

        Returns:
            Name of lowest confidence expert, or None
        """
        lowest_name = None
        lowest_confidence = float('inf')

        for name, output in outputs.items():
            if output.success and output.confidence < lowest_confidence:
                lowest_confidence = output.confidence
                lowest_name = name

        return lowest_name

    def get_breakdown(self) -> List[Dict[str, Any]]:
        """
        Get detailed breakdown of confidence calculation.

        Returns:
            List of breakdown dictionaries
        """
        return [
            {
                'expert_name': b.expert_name,
                'expert_type': b.expert_type.value,
                'raw_confidence': round(b.raw_confidence, 3),
                'weight': round(b.weight, 3),
                'weighted_confidence': round(b.weighted_confidence, 3),
                'factors': {k: round(v, 3) for k, v in b.factors.items()}
            }
            for b in self.breakdowns
        ]

    def calculate_incremental_confidence(self, previous_confidence: float,
                                        new_output: DynamicSQLExpertOutput) -> float:
        """
        Calculate updated confidence when a new expert output is added.

        Args:
            previous_confidence: Previous combined confidence
            new_output: New expert output to incorporate

        Returns:
            Updated confidence score
        """
        if not new_output.success:
            return previous_confidence

        weight = self.weights.get(new_output.expert_type, 0.1)
        adjusted = self._apply_factors(new_output)

        # Weighted average with new output
        # Assume previous was from (1 - weight) of total
        new_confidence = (previous_confidence * (1 - weight)) + (adjusted * weight)

        return min(max(new_confidence, 0.0), 1.0)

    def should_continue_refinement(self, outputs: Dict[str, DynamicSQLExpertOutput],
                                   threshold: float = 0.7) -> bool:
        """
        Determine if refinement should continue based on confidence.

        Args:
            outputs: Expert outputs
            threshold: Confidence threshold for "good enough"

        Returns:
            True if refinement should continue
        """
        combined = self.calculate_combined_confidence(outputs)

        if combined >= threshold:
            return False  # Good enough

        # Check if any expert requires refinement
        for output in outputs.values():
            if output.requires_refinement:
                return True

        # Check if improvement is possible
        lowest = self.get_lowest_confidence_expert(outputs)
        if lowest:
            lowest_conf = outputs[lowest].confidence
            if lowest_conf < 0.5:
                return True  # Room for improvement

        return False
