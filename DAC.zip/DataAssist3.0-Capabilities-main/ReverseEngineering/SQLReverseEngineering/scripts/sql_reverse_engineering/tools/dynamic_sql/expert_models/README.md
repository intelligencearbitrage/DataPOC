# Dynamic SQL Expert Models

## Overview
This module contains data models and structures used by the dynamic SQL experts for analysis and output.

## Components

### `context_models.py`
Context data structures passed to experts during analysis.

**Models:**

#### `DynamicSQLContext`
Complete context for dynamic SQL analysis.

**Fields:**
- `original_code` - Raw SQL/procedural code
- `variable_state` - Current variable values
- `control_flow_state` - Current execution path
- `schema_context` - Available schema information
- `execution_history` - Previous execution states
- `metadata` - Additional context information

**Usage:**
```python
context = DynamicSQLContext(
    original_code=sql_code,
    variable_state={},
    schema_context=schema_dict
)
```

#### `VariableContext`
State of variables during analysis.

**Fields:**
- `variables` - Dict of variable names to values
- `scope` - Current scope level
- `history` - Assignment history
- `data_types` - Inferred data types

#### `ExecutionContext`
Runtime execution context.

**Fields:**
- `current_line` - Current line number
- `call_stack` - Function call stack
- `branch_path` - Control flow path taken
- `iteration_count` - Loop iteration count

### `data_models.py`
Expert output and result data structures.

**Models:**

#### `DynamicSQLExpertType`
Enumeration of expert types.

**Values:**
```python
class DynamicSQLExpertType(Enum):
    PATTERN_DETECTION = "pattern_detection"
    VARIABLE_TRACKING = "variable_tracking"
    CONTROL_FLOW = "control_flow"
    RECONSTRUCTION = "reconstruction"
    VALIDATION = "validation"
```

#### `DynamicSQLExpertOutput`
Standard output structure from all experts.

**Fields:**
- `expert_type` - Type of expert (DynamicSQLExpertType)
- `success` - Whether analysis succeeded
- `data` - Expert-specific results
- `confidence` - Confidence score (0.0 to 1.0)
- `errors` - List of errors encountered
- `warnings` - List of warnings
- `metadata` - Additional metadata
- `execution_time_ms` - Processing time

**Usage:**
```python
output = DynamicSQLExpertOutput(
    expert_type=DynamicSQLExpertType.PATTERN_DETECTION,
    success=True,
    data={"patterns": patterns_found},
    confidence=0.9
)
```

#### `ReconstructedStatement`
A reconstructed SQL statement with metadata.

**Fields:**
- `sql` - Reconstructed SQL text
- `variables` - Variable values used
- `confidence` - Confidence score
- `is_complete` - Whether fully resolved
- `placeholders` - Unresolved placeholders
- `source_lines` - Original code lines
- `branch_path` - Control flow path

#### `DynamicSQLPattern`
Detected dynamic SQL pattern.

**Fields:**
- `pattern_type` - Type of pattern
- `location` - Code location
- `confidence` - Detection confidence
- `components` - Pattern components
- `variables_involved` - Variables used

## Usage Example

```python
from dynamic_sql.expert_models.context_models import DynamicSQLContext
from dynamic_sql.expert_models.data_models import DynamicSQLExpertOutput

# Create context
context = DynamicSQLContext(
    original_code=sql_code,
    variable_state={"table_name": "CUSTOMERS"},
    schema_context=schema
)

# Expert produces output
output = DynamicSQLExpertOutput(
    expert_type=DynamicSQLExpertType.RECONSTRUCTION,
    success=True,
    data={
        "reconstructed": ["SELECT * FROM CUSTOMERS"],
        "confidence": 0.85
    },
    confidence=0.85,
    errors=[],
    warnings=[]
)
```

## Integration Points
- Used by: All dynamic SQL experts
- Used by: Orchestrator for coordination
- Provides: Standard interfaces for expert communication
