"""
Variable Tracking Expert for Dynamic SQL Analysis.

Tracks variable declarations, assignments, and string concatenations
to resolve dynamic SQL values.
"""

from typing import Any, Dict, List, Optional

import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

from dynamic_sql.experts.base_dynamic_expert import BaseDynamicSQLExpert
from dynamic_sql.expert_models.data_models import (
    DynamicSQLExpertType,
    DynamicSQLExpertOutput
)
from dynamic_sql.expert_models.context_models import DynamicSQLContext, RefinementHint
from dynamic_sql.variable_tracker import VariableTracker


class VariableTrackingExpert(BaseDynamicSQLExpert):
    """
    Expert for tracking variable assignments and values.

    Wraps the existing VariableTracker with the multi-expert interface.
    Depends on PatternDetectionExpert to know which variables to focus on.

    Tracks:
    - Variable declarations (DECLARE)
    - Direct assignments (SET)
    - SELECT INTO assignments
    - String concatenations
    - Conditional assignments (inside IF blocks)
    """

    def __init__(self, dialect: str = "tsql"):
        """
        Initialize the variable tracking expert.

        Args:
            dialect: SQL dialect (tsql, teradata, oracle)
        """
        super().__init__(dialect)
        self._tracker = VariableTracker(dialect)

    @property
    def expert_type(self) -> DynamicSQLExpertType:
        """Return the expert type."""
        return DynamicSQLExpertType.VARIABLE_TRACKING

    def get_dependencies(self) -> List[DynamicSQLExpertType]:
        """Depends on pattern detection to know which variables matter."""
        return [DynamicSQLExpertType.PATTERN_DETECTION]

    def analyze(self, sql: str, **kwargs) -> DynamicSQLExpertOutput:
        """
        Track all variables in the SQL.

        Args:
            sql: SQL text to analyze
            **kwargs: Additional parameters

        Returns:
            DynamicSQLExpertOutput with variable states
        """
        self._start_timer()

        if not self.validate_input(sql):
            return self._create_error_output("Invalid or empty SQL input")

        try:
            # Reset and track
            self._tracker = VariableTracker(self.dialect)
            self._tracker.track_all(sql)

            # Get all variable states
            variable_states = dict(self._tracker.variables)

            # Find SQL-building variables
            sql_vars = [v.name for v in variable_states.values() if v.is_sql_fragment]

            # Calculate confidence
            confidence = self._calculate_confidence(variable_states)

            data = {
                'variable_count': len(variable_states),
                'sql_variables': sql_vars,
                'variables': {k: self._state_to_dict(v) for k, v in variable_states.items()},
                'unresolved_count': sum(1 for v in variable_states.values() if v.contains_unresolved),
            }

            warnings = []
            for name, state in variable_states.items():
                if state.contains_unresolved:
                    warnings.append(f"Variable {name} has unresolved references: {state.unresolved_references}")

            return self._create_output(
                success=True,
                data=data,
                context_updates={'variable_states': variable_states},
                confidence=confidence,
                warnings=warnings
            )

        except Exception as e:
            return self._create_error_output(f"Variable tracking failed: {str(e)}")

    def analyze_with_context(self, context: DynamicSQLContext) -> DynamicSQLExpertOutput:
        """
        Track variables with focus on those used in detected patterns.

        Args:
            context: Shared context with detected patterns

        Returns:
            DynamicSQLExpertOutput with variable states
        """
        self._start_timer()

        if not self.validate_context(context):
            return self._create_error_output("Invalid context")

        try:
            # Track all variables
            self._tracker = VariableTracker(self.dialect)
            self._tracker.track_all(context.sql_text)

            variable_states = dict(self._tracker.variables)

            # Get target variables from patterns
            target_variables = set()
            for pattern in context.detected_patterns:
                if pattern.variable_name:
                    target_variables.add(pattern.variable_name)

            # Mark which variables are relevant to dynamic SQL
            relevant_states = {}
            for name, state in variable_states.items():
                if name in target_variables or state.is_sql_fragment:
                    relevant_states[name] = state
                    # Note: VariableState doesn't have metadata, store info separately if needed

            # Calculate confidence
            confidence = self._calculate_confidence(relevant_states)

            # Check for unresolved variables
            unresolved_vars = [
                name for name, state in relevant_states.items()
                if state.contains_unresolved
            ]

            data = {
                'variable_count': len(variable_states),
                'relevant_variable_count': len(relevant_states),
                'sql_variables': [n for n, s in relevant_states.items() if s.is_sql_fragment],
                'target_variables': list(target_variables),
                'unresolved_variables': unresolved_vars,
                'variables': {k: self._state_to_dict(v) for k, v in relevant_states.items()},
            }

            # Generate warnings and refinement suggestions
            warnings = []
            refinement_suggestions = []
            requires_refinement = False

            for name in unresolved_vars:
                state = relevant_states[name]
                warnings.append(f"Variable {name} has unresolved references")
                if state.unresolved_references:
                    refinement_suggestions.append(
                        f"Try to resolve references: {', '.join(state.unresolved_references)}"
                    )
                    requires_refinement = True

            return self._create_output(
                success=True,
                data=data,
                context_updates={'variable_states': relevant_states},
                confidence=confidence,
                warnings=warnings,
                requires_refinement=requires_refinement,
                refinement_suggestions=refinement_suggestions
            )

        except Exception as e:
            return self._create_error_output(f"Variable tracking failed: {str(e)}")

    def refine(self, context: DynamicSQLContext,
               previous_outputs: Dict[str, DynamicSQLExpertOutput]) -> DynamicSQLExpertOutput:
        """
        Refine variable tracking based on other experts' outputs.

        Can use control flow information to better resolve conditional assignments.

        Args:
            context: Current context
            previous_outputs: Outputs from other experts

        Returns:
            Refined DynamicSQLExpertOutput
        """
        self._start_timer()

        # Start with current variable states
        variable_states = dict(context.variable_states)

        # Check control flow output for conditional information
        control_flow_output = previous_outputs.get('ControlFlowExpert')
        if control_flow_output and control_flow_output.success:
            cfg = control_flow_output.data.get('control_flow_graph')
            if cfg:
                # Use control flow to identify conditional assignments
                self._annotate_conditional_assignments(variable_states, cfg)

        # Check validation output for suggestions
        validation_output = previous_outputs.get('ValidationExpert')
        if validation_output and validation_output.refinement_suggestions:
            for suggestion in validation_output.refinement_suggestions:
                if 'variable' in suggestion.lower():
                    # Try to resolve based on suggestion
                    self._apply_resolution_hint(variable_states, suggestion)

        confidence = self._calculate_confidence(variable_states)

        data = {
            'variable_count': len(variable_states),
            'variables': {k: self._state_to_dict(v) for k, v in variable_states.items()},
            'refined': True,
            'iteration': context.iteration
        }

        return self._create_output(
            success=True,
            data=data,
            context_updates={'variable_states': variable_states},
            confidence=confidence
        )

    def _calculate_confidence(self, variable_states: Dict) -> float:
        """Calculate confidence based on variable resolution."""
        if not variable_states:
            return 0.5

        # Count resolved vs unresolved
        total = len(variable_states)
        resolved = sum(1 for v in variable_states.values() if not v.contains_unresolved)

        base_confidence = resolved / total if total > 0 else 0.5

        # Boost if we found SQL fragments
        sql_frags = sum(1 for v in variable_states.values() if v.is_sql_fragment)
        if sql_frags > 0:
            base_confidence = min(base_confidence + 0.1, 1.0)

        return base_confidence

    def _state_to_dict(self, state) -> Dict[str, Any]:
        """Convert a variable state to dictionary."""
        return {
            'name': state.name,
            'data_type': state.data_type,
            'current_value': state.current_value[:200] if state.current_value else None,
            'is_sql_fragment': state.is_sql_fragment,
            'contains_unresolved': state.contains_unresolved,
            'unresolved_references': state.unresolved_references,
            'assignment_count': len(state.value_history) if hasattr(state, 'value_history') else 0
        }

    def _annotate_conditional_assignments(self, variable_states: Dict, cfg: Dict) -> None:
        """Annotate variables with conditional assignment information."""
        # This would use the control flow graph to identify
        # which assignments are inside conditional blocks
        pass

    def _apply_resolution_hint(self, variable_states: Dict, hint: str) -> None:
        """Try to resolve a variable based on a hint."""
        # Parse hint and try to improve resolution
        pass

    def _generate_hints(self, context: DynamicSQLContext,
                        output: DynamicSQLExpertOutput) -> List[RefinementHint]:
        """Generate hints for other experts."""
        hints = []

        # If we found SQL variables, hint to reconstruction expert
        sql_vars = output.data.get('sql_variables', [])
        if sql_vars:
            hints.append(RefinementHint(
                source_expert=self.name,
                target_expert='ReconstructionExpert',
                hint_type='sql_variables',
                hint_data={'variables': sql_vars},
                priority=2
            ))

        return hints
