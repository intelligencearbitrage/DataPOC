"""
Provenance Tracker for Dynamic SQL Multi-Expert Architecture.

Tracks which expert contributed what data for audit trails and debugging.
"""

from typing import Any, Dict, List, Optional
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
import json

import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

from dynamic_sql.expert_models.data_models import DynamicSQLExpertOutput, DynamicSQLExpertType


class ProvenanceEventType(Enum):
    """Types of provenance events."""
    ANALYSIS_START = "analysis_start"
    EXPERT_START = "expert_start"
    EXPERT_COMPLETE = "expert_complete"
    EXPERT_ERROR = "expert_error"
    CONFLICT_DETECTED = "conflict_detected"
    CONFLICT_RESOLVED = "conflict_resolved"
    REFINEMENT_START = "refinement_start"
    REFINEMENT_COMPLETE = "refinement_complete"
    DATA_CONTRIBUTION = "data_contribution"
    ANALYSIS_COMPLETE = "analysis_complete"


@dataclass
class ProvenanceRecord:
    """Record of a provenance event."""
    record_id: str
    event_type: ProvenanceEventType
    expert_name: Optional[str]
    expert_type: Optional[DynamicSQLExpertType]
    timestamp: datetime
    data: Dict[str, Any]
    iteration: int = 0
    parent_record_id: Optional[str] = None
    confidence: Optional[float] = None


class ProvenanceTracker:
    """
    Track expert contributions for audit trails.

    Records:
    - Which expert contributed what data
    - When each contribution was made
    - Confidence scores at each step
    - Refinement iterations
    - Conflict resolutions
    """

    def __init__(self, procedure_name: Optional[str] = None):
        """
        Initialize the provenance tracker.

        Args:
            procedure_name: Name of procedure being analyzed (for context)
        """
        self.procedure_name = procedure_name
        self.records: List[ProvenanceRecord] = []
        self._record_counter = 0
        self._analysis_id = f"analysis_{datetime.now().strftime('%Y%m%d_%H%M%S')}"

    def start_analysis(self, sql_text: str, dialect: str) -> str:
        """
        Record the start of analysis.

        Args:
            sql_text: SQL being analyzed
            dialect: SQL dialect

        Returns:
            Record ID for this event
        """
        record = self._create_record(
            event_type=ProvenanceEventType.ANALYSIS_START,
            expert_name=None,
            expert_type=None,
            data={
                'analysis_id': self._analysis_id,
                'procedure_name': self.procedure_name,
                'sql_length': len(sql_text),
                'dialect': dialect
            }
        )
        return record.record_id

    def record_expert_start(self, expert_name: str, expert_type: DynamicSQLExpertType,
                           iteration: int = 0) -> str:
        """
        Record when an expert starts analysis.

        Args:
            expert_name: Name of the expert
            expert_type: Type of the expert
            iteration: Refinement iteration number

        Returns:
            Record ID for this event
        """
        record = self._create_record(
            event_type=ProvenanceEventType.EXPERT_START,
            expert_name=expert_name,
            expert_type=expert_type,
            data={'iteration': iteration},
            iteration=iteration
        )
        return record.record_id

    def record_expert_output(self, output: DynamicSQLExpertOutput,
                            iteration: int = 0) -> str:
        """
        Record an expert's output.

        Args:
            output: Expert output
            iteration: Refinement iteration number

        Returns:
            Record ID for this event
        """
        if output.success:
            event_type = ProvenanceEventType.EXPERT_COMPLETE
        else:
            event_type = ProvenanceEventType.EXPERT_ERROR

        # Extract key contributions
        contributions = self._extract_contributions(output)

        record = self._create_record(
            event_type=event_type,
            expert_name=output.expert_name,
            expert_type=output.expert_type,
            data={
                'success': output.success,
                'execution_time_ms': output.execution_time_ms,
                'warnings_count': len(output.warnings),
                'errors_count': len(output.errors),
                'requires_refinement': output.requires_refinement,
                'contributions': contributions
            },
            iteration=iteration,
            confidence=output.confidence
        )
        return record.record_id

    def record_data_contribution(self, expert_name: str, expert_type: DynamicSQLExpertType,
                                contribution_type: str, data: Any,
                                iteration: int = 0) -> str:
        """
        Record a specific data contribution from an expert.

        Args:
            expert_name: Name of the expert
            expert_type: Type of the expert
            contribution_type: Type of contribution (e.g., 'patterns', 'variables')
            data: The contributed data
            iteration: Refinement iteration number

        Returns:
            Record ID for this event
        """
        record = self._create_record(
            event_type=ProvenanceEventType.DATA_CONTRIBUTION,
            expert_name=expert_name,
            expert_type=expert_type,
            data={
                'contribution_type': contribution_type,
                'contribution_data': self._safe_serialize(data)
            },
            iteration=iteration
        )
        return record.record_id

    def record_conflict(self, conflict_type: str, experts_involved: List[str],
                       conflict_data: Dict[str, Any]) -> str:
        """
        Record a detected conflict.

        Args:
            conflict_type: Type of conflict
            experts_involved: Experts involved in conflict
            conflict_data: Data about the conflict

        Returns:
            Record ID for this event
        """
        record = self._create_record(
            event_type=ProvenanceEventType.CONFLICT_DETECTED,
            expert_name=None,
            expert_type=None,
            data={
                'conflict_type': conflict_type,
                'experts_involved': experts_involved,
                'conflict_data': self._safe_serialize(conflict_data)
            }
        )
        return record.record_id

    def record_conflict_resolution(self, conflict_type: str, resolution_strategy: str,
                                  resolved_value: Any, parent_conflict_id: str) -> str:
        """
        Record how a conflict was resolved.

        Args:
            conflict_type: Type of conflict
            resolution_strategy: Strategy used to resolve
            resolved_value: The resolved value
            parent_conflict_id: ID of the conflict record

        Returns:
            Record ID for this event
        """
        record = self._create_record(
            event_type=ProvenanceEventType.CONFLICT_RESOLVED,
            expert_name=None,
            expert_type=None,
            data={
                'conflict_type': conflict_type,
                'resolution_strategy': resolution_strategy,
                'resolved_value': self._safe_serialize(resolved_value)
            },
            parent_record_id=parent_conflict_id
        )
        return record.record_id

    def record_refinement_start(self, iteration: int, trigger_reason: str) -> str:
        """
        Record the start of a refinement iteration.

        Args:
            iteration: Iteration number
            trigger_reason: Why refinement was triggered

        Returns:
            Record ID for this event
        """
        record = self._create_record(
            event_type=ProvenanceEventType.REFINEMENT_START,
            expert_name=None,
            expert_type=None,
            data={'trigger_reason': trigger_reason},
            iteration=iteration
        )
        return record.record_id

    def record_refinement_complete(self, iteration: int, improvements: Dict[str, Any]) -> str:
        """
        Record completion of a refinement iteration.

        Args:
            iteration: Iteration number
            improvements: What improved in this iteration

        Returns:
            Record ID for this event
        """
        record = self._create_record(
            event_type=ProvenanceEventType.REFINEMENT_COMPLETE,
            expert_name=None,
            expert_type=None,
            data={'improvements': improvements},
            iteration=iteration
        )
        return record.record_id

    def complete_analysis(self, final_confidence: float,
                         total_statements: int,
                         fully_resolved: int) -> str:
        """
        Record completion of analysis.

        Args:
            final_confidence: Final combined confidence score
            total_statements: Total dynamic SQL statements found
            fully_resolved: Number of fully resolved statements

        Returns:
            Record ID for this event
        """
        record = self._create_record(
            event_type=ProvenanceEventType.ANALYSIS_COMPLETE,
            expert_name=None,
            expert_type=None,
            data={
                'final_confidence': final_confidence,
                'total_statements': total_statements,
                'fully_resolved': fully_resolved,
                'total_records': len(self.records)
            },
            confidence=final_confidence
        )
        return record.record_id

    def _create_record(self, event_type: ProvenanceEventType,
                      expert_name: Optional[str],
                      expert_type: Optional[DynamicSQLExpertType],
                      data: Dict[str, Any],
                      iteration: int = 0,
                      parent_record_id: Optional[str] = None,
                      confidence: Optional[float] = None) -> ProvenanceRecord:
        """Create and store a provenance record."""
        self._record_counter += 1
        record = ProvenanceRecord(
            record_id=f"prov_{self._record_counter}",
            event_type=event_type,
            expert_name=expert_name,
            expert_type=expert_type,
            timestamp=datetime.now(),
            data=data,
            iteration=iteration,
            parent_record_id=parent_record_id,
            confidence=confidence
        )
        self.records.append(record)
        return record

    def _extract_contributions(self, output: DynamicSQLExpertOutput) -> Dict[str, Any]:
        """Extract key contributions from an expert output."""
        contributions = {}

        if output.data:
            # Pattern detection contributions
            if 'pattern_count' in output.data:
                contributions['patterns_detected'] = output.data['pattern_count']

            # Variable tracking contributions
            if 'variable_count' in output.data:
                contributions['variables_tracked'] = output.data['variable_count']
            if 'sql_variables' in output.data:
                contributions['sql_building_variables'] = len(output.data['sql_variables'])

            # Control flow contributions
            if 'node_count' in output.data:
                contributions['control_flow_nodes'] = output.data['node_count']
            if 'has_loops' in output.data:
                contributions['has_loops'] = output.data['has_loops']

            # Reconstruction contributions
            if 'reconstructed_count' in output.data:
                contributions['statements_reconstructed'] = output.data['reconstructed_count']
            if 'fully_resolved_count' in output.data:
                contributions['fully_resolved'] = output.data['fully_resolved_count']

            # Validation contributions
            if 'valid_count' in output.data:
                contributions['valid_statements'] = output.data['valid_count']

        return contributions

    def _safe_serialize(self, data: Any) -> Any:
        """Safely serialize data for storage."""
        try:
            # Try to JSON serialize
            json.dumps(data)
            return data
        except (TypeError, ValueError):
            # Convert to string representation
            if isinstance(data, dict):
                return {k: str(v)[:100] for k, v in data.items()}
            elif isinstance(data, list):
                return [str(item)[:100] for item in data[:10]]
            else:
                return str(data)[:200]

    def get_expert_contributions(self, expert_name: str) -> List[ProvenanceRecord]:
        """Get all contributions from a specific expert."""
        return [r for r in self.records if r.expert_name == expert_name]

    def get_iteration_records(self, iteration: int) -> List[ProvenanceRecord]:
        """Get all records from a specific iteration."""
        return [r for r in self.records if r.iteration == iteration]

    def get_timeline(self) -> List[Dict[str, Any]]:
        """Get a timeline of all events."""
        return [
            {
                'record_id': r.record_id,
                'event_type': r.event_type.value,
                'expert_name': r.expert_name,
                'timestamp': r.timestamp.isoformat(),
                'iteration': r.iteration,
                'confidence': r.confidence
            }
            for r in self.records
        ]

    def get_summary(self) -> Dict[str, Any]:
        """Get a summary of provenance tracking."""
        experts_involved = set(r.expert_name for r in self.records if r.expert_name)
        iterations = max((r.iteration for r in self.records), default=0)

        events_by_type = {}
        for r in self.records:
            event_type = r.event_type.value
            if event_type not in events_by_type:
                events_by_type[event_type] = 0
            events_by_type[event_type] += 1

        return {
            'analysis_id': self._analysis_id,
            'procedure_name': self.procedure_name,
            'total_records': len(self.records),
            'experts_involved': list(experts_involved),
            'total_iterations': iterations + 1,
            'events_by_type': events_by_type,
            'start_time': self.records[0].timestamp.isoformat() if self.records else None,
            'end_time': self.records[-1].timestamp.isoformat() if self.records else None
        }

    def export_to_dict(self) -> Dict[str, Any]:
        """Export all provenance data to a dictionary."""
        return {
            'summary': self.get_summary(),
            'timeline': self.get_timeline(),
            'records': [
                {
                    'record_id': r.record_id,
                    'event_type': r.event_type.value,
                    'expert_name': r.expert_name,
                    'expert_type': r.expert_type.value if r.expert_type else None,
                    'timestamp': r.timestamp.isoformat(),
                    'data': r.data,
                    'iteration': r.iteration,
                    'parent_record_id': r.parent_record_id,
                    'confidence': r.confidence
                }
                for r in self.records
            ]
        }

    def export_to_json(self, filepath: str) -> None:
        """Export provenance data to a JSON file."""
        with open(filepath, 'w') as f:
            json.dump(self.export_to_dict(), f, indent=2)
