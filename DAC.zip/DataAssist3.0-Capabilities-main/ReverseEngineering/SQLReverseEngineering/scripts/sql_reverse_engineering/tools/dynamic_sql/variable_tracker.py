"""
Variable Tracker module.

Tracks variable assignments and string concatenations in stored procedures
to reconstruct dynamically built SQL statements.
"""

import re
from typing import Dict, List, Optional, Tuple, Set
from dataclasses import dataclass, field
from copy import deepcopy

from dynamic_sql.models import (
    VariableAssignment, VariableState, AssignmentType
)


class VariableTracker:
    """
    Track variable assignments through procedure execution.

    Handles:
    - DECLARE statements
    - SET assignments
    - SELECT INTO assignments
    - String concatenations
    - Conditional assignments (IF blocks)
    """

    def __init__(self, dialect: str = "tsql"):
        """
        Initialize tracker.

        Args:
            dialect: SQL dialect (tsql, teradata, oracle)
        """
        self.dialect = dialect.lower()
        self.variables: Dict[str, VariableState] = {}
        self.control_flow_stack: List[str] = []  # Track IF/WHILE conditions
        self._sql_keywords = self._get_sql_keywords()

    def track_all(self, sql: str) -> None:
        """
        Track all variable operations in SQL text.

        Args:
            sql: SQL text to analyze
        """
        # Remove comments
        clean_sql = self._remove_comments(sql)
        lines = clean_sql.split('\n')

        for line_num, line in enumerate(lines, 1):
            line = line.strip()
            if not line:
                continue

            # Track declarations
            self._track_declarations(line, line_num)

            # Track assignments
            self._track_assignments(line, line_num)

            # Track control flow
            self._track_control_flow(line)

    def track_declaration(self, statement: str, line_num: int = 0) -> None:
        """
        Track a variable declaration.

        Args:
            statement: DECLARE statement
            line_num: Line number
        """
        self._track_declarations(statement, line_num)

    def track_assignment(self, statement: str, line_num: int = 0) -> None:
        """
        Track a variable assignment.

        Args:
            statement: SET or SELECT statement
            line_num: Line number
        """
        self._track_assignments(statement, line_num)

    def get_variable_value(self, var_name: str) -> Optional[VariableState]:
        """
        Get the current state of a variable.

        Args:
            var_name: Variable name (with or without @)

        Returns:
            VariableState or None if not found
        """
        # Normalize variable name
        normalized = self._normalize_var_name(var_name)

        return self.variables.get(normalized)

    def get_all_possible_values(self, var_name: str) -> List[str]:
        """
        Get all possible values for a variable (handling conditionals).

        Args:
            var_name: Variable name

        Returns:
            List of possible values
        """
        state = self.get_variable_value(var_name)
        if not state:
            return []

        values = set()

        # Add current value
        if state.current_value:
            values.add(state.current_value)

        # Add values from conditional branches
        for assignment in state.value_history:
            if assignment.condition:
                values.add(assignment.assigned_value)

        return list(values)

    def resolve_expression(self, expression: str) -> Tuple[str, bool]:
        """
        Resolve an expression by substituting variable values.

        Args:
            expression: Expression to resolve

        Returns:
            Tuple of (resolved_string, is_complete)
        """
        resolved = expression
        is_complete = True
        unresolved = []

        # Find all variable references
        var_pattern = self._get_variable_pattern()

        for match in re.finditer(var_pattern, expression):
            var_name = match.group(0)
            state = self.get_variable_value(var_name)

            if state and state.current_value:
                # Substitute the value
                resolved = resolved.replace(var_name, state.current_value)
            else:
                # Mark as unresolved
                is_complete = False
                unresolved.append(var_name)
                resolved = resolved.replace(var_name, f"${{{var_name}}}")

        return resolved, is_complete

    def resolve_concatenation(self, expression: str) -> Tuple[str, bool]:
        """
        Resolve a string concatenation expression.

        Args:
            expression: Concatenation expression (e.g., @a + ' ' + @b)

        Returns:
            Tuple of (resolved_string, is_complete)
        """
        # Handle different concatenation operators
        if self.dialect == 'teradata':
            parts = re.split(r'\s*\|\|\s*', expression)
        else:
            parts = re.split(r'\s*\+\s*', expression)

        resolved_parts = []
        is_complete = True

        for part in parts:
            part = part.strip()

            if not part:
                continue

            # Check if it's a string literal
            if (part.startswith("'") and part.endswith("'")) or \
               (part.startswith('"') and part.endswith('"')) or \
               (part.startswith("N'") and part.endswith("'")):
                # Extract string content
                if part.startswith("N'"):
                    content = part[2:-1]
                else:
                    content = part[1:-1]
                resolved_parts.append(content)

            # Check if it's a variable
            elif self._is_variable(part):
                state = self.get_variable_value(part)
                if state and state.current_value:
                    resolved_parts.append(state.current_value)
                else:
                    is_complete = False
                    resolved_parts.append(f"${{{part}}}")

            else:
                # Unknown expression part
                is_complete = False
                resolved_parts.append(f"${{{part}}}")

        return ''.join(resolved_parts), is_complete

    def get_sql_variables(self) -> List[VariableState]:
        """
        Get all variables that appear to contain SQL fragments.

        Returns:
            List of VariableState objects for SQL variables
        """
        sql_vars = []

        for var_name, state in self.variables.items():
            if state.is_sql_fragment:
                sql_vars.append(state)

        return sql_vars

    def _track_declarations(self, line: str, line_num: int) -> None:
        """Track DECLARE statements."""
        # T-SQL: DECLARE @var TYPE [= value]
        # Teradata: DECLARE var TYPE
        if self.dialect == 'tsql':
            pattern = re.compile(
                r'\bDECLARE\s+(@\w+)\s+(\w+(?:\s*\([^)]+\))?)\s*(?:=\s*(.+?))?(?:;|,|$)',
                re.IGNORECASE
            )
        else:
            pattern = re.compile(
                r'\bDECLARE\s+(\w+)\s+(\w+(?:\s*\([^)]+\))?)\s*(?:DEFAULT\s+(.+?))?(?:;|$)',
                re.IGNORECASE
            )

        for match in pattern.finditer(line):
            var_name = self._normalize_var_name(match.group(1))
            data_type = match.group(2)
            default_value = match.group(3).strip() if match.group(3) else ""

            # Check if it's a SQL-related type
            is_sql_type = any(t in data_type.upper() for t in [
                'VARCHAR', 'NVARCHAR', 'TEXT', 'CLOB', 'STRING'
            ])

            state = VariableState(
                name=var_name,
                data_type=data_type,
                current_value=default_value,
                is_sql_fragment=is_sql_type
            )

            if default_value:
                state.value_history.append(VariableAssignment(
                    variable_name=var_name,
                    assigned_value=default_value,
                    assignment_type=AssignmentType.INITIAL,
                    line_number=line_num,
                    raw_statement=line
                ))

            self.variables[var_name] = state

    def _track_assignments(self, line: str, line_num: int) -> None:
        """Track SET and SELECT assignments."""
        # Determine current condition context
        current_condition = self.control_flow_stack[-1] if self.control_flow_stack else None

        # SET @var = expression
        set_pattern = re.compile(
            r'\bSET\s+(@?\w+)\s*=\s*(.+?)(?:;|$)',
            re.IGNORECASE | re.DOTALL
        )

        for match in set_pattern.finditer(line):
            var_name = self._normalize_var_name(match.group(1))
            expression = match.group(2).strip()

            self._process_assignment(var_name, expression, line_num, line, current_condition)

        # SELECT @var = expression
        select_pattern = re.compile(
            r'\bSELECT\s+(@?\w+)\s*=\s*(.+?)(?:;|$|FROM)',
            re.IGNORECASE | re.DOTALL
        )

        for match in select_pattern.finditer(line):
            var_name = self._normalize_var_name(match.group(1))
            expression = match.group(2).strip()

            self._process_assignment(var_name, expression, line_num, line, current_condition)

    def _process_assignment(self, var_name: str, expression: str,
                           line_num: int, raw_statement: str,
                           condition: Optional[str] = None) -> None:
        """Process a variable assignment."""
        # Get or create variable state
        if var_name not in self.variables:
            self.variables[var_name] = VariableState(
                name=var_name,
                is_sql_fragment=True  # Assume SQL if being assigned dynamically
            )

        state = self.variables[var_name]

        # Determine assignment type
        if self._is_concatenation_append(var_name, expression):
            assignment_type = AssignmentType.APPEND
        elif self._is_concatenation(expression):
            assignment_type = AssignmentType.CONCATENATE
        elif condition:
            assignment_type = AssignmentType.CONDITIONAL
        else:
            assignment_type = AssignmentType.INITIAL if not state.value_history else AssignmentType.INITIAL

        # Resolve the expression if possible
        resolved_value, is_complete = self._resolve_assignment_value(expression, var_name)

        # Check for SQL keywords to mark as SQL fragment
        if self._contains_sql_keywords(resolved_value):
            state.is_sql_fragment = True

        # Track unresolved references
        if not is_complete:
            state.contains_unresolved = True
            unresolved = self._find_unresolved_vars(expression)
            state.unresolved_references.extend(unresolved)

        # Create assignment record
        assignment = VariableAssignment(
            variable_name=var_name,
            assigned_value=resolved_value,
            assignment_type=assignment_type,
            line_number=line_num,
            condition=condition,
            raw_statement=raw_statement
        )

        state.value_history.append(assignment)

        # Update current value (for non-conditional assignments)
        if not condition:
            if assignment_type == AssignmentType.APPEND:
                # Append to existing value
                state.current_value = state.current_value + resolved_value
            else:
                state.current_value = resolved_value

    def _resolve_assignment_value(self, expression: str, target_var: str) -> Tuple[str, bool]:
        """Resolve the value of an assignment expression."""
        expression = expression.strip()

        # Check if it's an append operation
        if self._is_concatenation_append(target_var, expression):
            # Remove the self-reference
            pattern = re.escape(target_var) + r'\s*\+\s*'
            remaining = re.sub(pattern, '', expression, count=1, flags=re.IGNORECASE)
            return self.resolve_concatenation(remaining)

        # Check if it's a concatenation
        if self._is_concatenation(expression):
            return self.resolve_concatenation(expression)

        # Check if it's a string literal
        if self._is_string_literal(expression):
            return self._extract_string_content(expression), True

        # Check if it's a variable reference
        if self._is_variable(expression):
            state = self.get_variable_value(expression)
            if state and state.current_value:
                return state.current_value, True
            return f"${{{expression}}}", False

        return expression, True

    def _track_control_flow(self, line: str) -> None:
        """Track IF/WHILE control flow statements."""
        line_upper = line.upper()

        # IF condition
        if_match = re.match(r'\bIF\s+(.+?)\s*(?:THEN|BEGIN|$)', line, re.IGNORECASE)
        if if_match:
            condition = if_match.group(1).strip()
            self.control_flow_stack.append(condition)
            return

        # END IF or END
        if re.match(r'\bEND\s+IF\b', line_upper) or \
           (re.match(r'\bEND\b', line_upper) and self.control_flow_stack):
            if self.control_flow_stack:
                self.control_flow_stack.pop()
            return

        # ELSE - change condition context
        if re.match(r'\bELSE\b', line_upper) and self.control_flow_stack:
            current = self.control_flow_stack.pop()
            self.control_flow_stack.append(f"NOT ({current})")

    def _normalize_var_name(self, var_name: str) -> str:
        """Normalize variable name to consistent format."""
        var_name = var_name.strip()
        if self.dialect == 'tsql':
            if not var_name.startswith('@'):
                var_name = '@' + var_name
        return var_name.upper()

    def _get_variable_pattern(self) -> str:
        """Get regex pattern for variable references."""
        if self.dialect == 'tsql':
            return r'@\w+'
        else:
            return r':\w+|\b[a-zA-Z_]\w*\b'

    def _is_variable(self, text: str) -> bool:
        """Check if text is a variable reference."""
        text = text.strip()
        if self.dialect == 'tsql':
            return text.startswith('@') and re.match(r'^@\w+$', text)
        else:
            return re.match(r'^:\w+$|^[a-zA-Z_]\w*$', text) is not None

    def _is_string_literal(self, text: str) -> bool:
        """Check if text is a string literal."""
        text = text.strip()
        return (text.startswith("'") and text.endswith("'")) or \
               (text.startswith('"') and text.endswith('"')) or \
               (text.startswith("N'") and text.endswith("'"))

    def _extract_string_content(self, literal: str) -> str:
        """Extract content from string literal."""
        literal = literal.strip()
        if literal.startswith("N'"):
            return literal[2:-1]
        elif literal.startswith("'") or literal.startswith('"'):
            return literal[1:-1]
        return literal

    def _is_concatenation(self, expression: str) -> bool:
        """Check if expression is a concatenation."""
        if self.dialect == 'teradata':
            return '||' in expression
        else:
            return '+' in expression and ("'" in expression or '@' in expression)

    def _is_concatenation_append(self, var_name: str, expression: str) -> bool:
        """Check if expression appends to the same variable."""
        # Pattern: @var = @var + '...'
        pattern = re.escape(var_name) + r'\s*\+'
        return re.search(pattern, expression, re.IGNORECASE) is not None

    def _contains_sql_keywords(self, text: str) -> bool:
        """Check if text contains SQL keywords."""
        text_upper = text.upper()
        return any(kw in text_upper for kw in self._sql_keywords)

    def _find_unresolved_vars(self, expression: str) -> List[str]:
        """Find unresolved variable references in expression."""
        unresolved = []
        var_pattern = self._get_variable_pattern()

        for match in re.finditer(var_pattern, expression):
            var_name = match.group(0)
            normalized = self._normalize_var_name(var_name)
            state = self.variables.get(normalized)

            if not state or not state.current_value:
                unresolved.append(var_name)

        return unresolved

    def _get_sql_keywords(self) -> Set[str]:
        """Get set of SQL keywords that indicate SQL content."""
        return {
            'SELECT', 'INSERT', 'UPDATE', 'DELETE', 'CREATE', 'ALTER', 'DROP',
            'FROM', 'WHERE', 'JOIN', 'LEFT', 'RIGHT', 'INNER', 'OUTER',
            'GROUP BY', 'ORDER BY', 'HAVING', 'UNION', 'INTO', 'VALUES',
            'SET', 'BEGIN', 'END', 'IF', 'WHILE', 'CASE', 'WHEN', 'THEN'
        }

    def _remove_comments(self, sql: str) -> str:
        """Remove SQL comments from text."""
        sql = re.sub(r'--[^\n]*', '', sql)
        sql = re.sub(r'/\*.*?\*/', '', sql, flags=re.DOTALL)
        return sql
