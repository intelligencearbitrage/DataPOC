"""
Data Models for Dynamic SQL Handling.

Contains dataclasses and enums for representing dynamic SQL patterns,
variable states, and reconstruction results.
"""

from dataclasses import dataclass, field
from typing import List, Optional, Dict, Any
from enum import Enum


class DynamicSQLType(Enum):
    """Type of dynamic SQL execution."""
    EXEC_STRING = "EXEC_STRING"           # EXEC(@sql) or EXEC('...')
    SP_EXECUTESQL = "SP_EXECUTESQL"       # sp_executesql @sql
    EXECUTE_IMMEDIATE = "EXECUTE_IMMEDIATE"  # EXECUTE IMMEDIATE (Teradata/Oracle)
    PREPARE_EXECUTE = "PREPARE_EXECUTE"   # PREPARE...FROM...EXECUTE
    XP_CMDSHELL = "XP_CMDSHELL"           # xp_cmdshell @command
    UNKNOWN = "UNKNOWN"


class ResolutionStatus(Enum):
    """Status of dynamic SQL resolution."""
    FULLY_RESOLVED = "FULLY_RESOLVED"       # SQL completely reconstructed
    PARTIALLY_RESOLVED = "PARTIALLY_RESOLVED"  # Some parts unresolved
    UNRESOLVABLE = "UNRESOLVABLE"           # Cannot determine SQL
    CONDITIONAL = "CONDITIONAL"              # Multiple possible resolutions


class AssignmentType(Enum):
    """Type of variable assignment."""
    INITIAL = "INITIAL"           # First assignment (SET @x = '...')
    APPEND = "APPEND"             # Concatenation append (SET @x = @x + '...')
    CONCATENATE = "CONCATENATE"   # Full concatenation (SET @x = @a + @b)
    SELECT_INTO = "SELECT_INTO"   # SELECT @x = expression
    CONDITIONAL = "CONDITIONAL"   # Inside IF block


@dataclass
class DynamicSQLPattern:
    """Detected dynamic SQL pattern."""
    pattern_type: DynamicSQLType
    start_line: int
    end_line: int
    variable_name: str              # Variable holding the SQL (e.g., @sql)
    execution_sql: str              # The EXEC/EXECUTE statement itself
    parameters: List[str] = field(default_factory=list)  # For sp_executesql
    dialect: str = "tsql"
    confidence: float = 1.0         # 0.0-1.0 confidence in detection

    def to_dict(self) -> Dict[str, Any]:
        return {
            "pattern_type": self.pattern_type.value,
            "start_line": self.start_line,
            "end_line": self.end_line,
            "variable_name": self.variable_name,
            "execution_sql": self.execution_sql,
            "parameters": self.parameters,
            "dialect": self.dialect,
            "confidence": self.confidence
        }


@dataclass
class VariableAssignment:
    """Single variable assignment."""
    variable_name: str
    assigned_value: str
    assignment_type: AssignmentType
    line_number: int
    condition: Optional[str] = None  # For conditional assignments
    raw_statement: str = ""          # Original SQL statement

    def to_dict(self) -> Dict[str, Any]:
        return {
            "variable_name": self.variable_name,
            "assigned_value": self.assigned_value,
            "assignment_type": self.assignment_type.value,
            "line_number": self.line_number,
            "condition": self.condition,
            "raw_statement": self.raw_statement
        }


@dataclass
class VariableState:
    """Tracked state of a variable."""
    name: str
    data_type: Optional[str] = None
    current_value: str = ""
    value_history: List[VariableAssignment] = field(default_factory=list)
    is_sql_fragment: bool = False
    contains_unresolved: bool = False  # Has runtime-only values
    unresolved_references: List[str] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "name": self.name,
            "data_type": self.data_type,
            "current_value": self.current_value,
            "is_sql_fragment": self.is_sql_fragment,
            "contains_unresolved": self.contains_unresolved,
            "unresolved_references": self.unresolved_references,
            "assignment_count": len(self.value_history)
        }


@dataclass
class DynamicSQLFragment:
    """A fragment of dynamically constructed SQL."""
    fragment_id: str
    content: str
    is_literal: bool = True         # True if string literal, False if variable
    source_variable: Optional[str] = None
    source_line: int = 0

    def to_dict(self) -> Dict[str, Any]:
        return {
            "fragment_id": self.fragment_id,
            "content": self.content,
            "is_literal": self.is_literal,
            "source_variable": self.source_variable,
            "source_line": self.source_line
        }


@dataclass
class ReconstructedSQL:
    """Result of SQL reconstruction."""
    original_pattern: DynamicSQLPattern
    reconstructed_sql: str
    is_complete: bool = False       # False if contains unresolved parts
    resolution_status: ResolutionStatus = ResolutionStatus.UNRESOLVABLE
    unresolved_parts: List[str] = field(default_factory=list)
    possible_variants: List[str] = field(default_factory=list)  # For conditional branches
    fragments: List[DynamicSQLFragment] = field(default_factory=list)
    confidence: float = 0.0
    reconstruction_notes: List[str] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "original_pattern": self.original_pattern.to_dict(),
            "reconstructed_sql": self.reconstructed_sql,
            "is_complete": self.is_complete,
            "resolution_status": self.resolution_status.value,
            "unresolved_parts": self.unresolved_parts,
            "possible_variants": self.possible_variants,
            "confidence": self.confidence,
            "reconstruction_notes": self.reconstruction_notes
        }


@dataclass
class DynamicSQLStatement:
    """Complete dynamic SQL statement with metadata."""
    statement_id: str
    execution_type: DynamicSQLType
    fragments: List[DynamicSQLFragment] = field(default_factory=list)
    assembled_sql: str = ""
    resolution_status: ResolutionStatus = ResolutionStatus.UNRESOLVABLE
    unresolved_variables: List[str] = field(default_factory=list)
    conditional_variants: List[str] = field(default_factory=list)
    line_range: tuple = (0, 0)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "statement_id": self.statement_id,
            "execution_type": self.execution_type.value,
            "assembled_sql": self.assembled_sql,
            "resolution_status": self.resolution_status.value,
            "unresolved_variables": self.unresolved_variables,
            "conditional_variants": self.conditional_variants,
            "line_range": self.line_range,
            "fragments": [f.to_dict() for f in self.fragments]
        }


@dataclass
class DynamicSQLAnalysisResult:
    """Complete analysis result for dynamic SQL in a procedure."""
    procedure_name: Optional[str] = None
    detected_patterns: List[DynamicSQLPattern] = field(default_factory=list)
    reconstructed_statements: List[ReconstructedSQL] = field(default_factory=list)
    fully_resolved: List[ReconstructedSQL] = field(default_factory=list)
    partially_resolved: List[ReconstructedSQL] = field(default_factory=list)
    unresolvable: List[DynamicSQLPattern] = field(default_factory=list)
    analysis_warnings: List[str] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "procedure_name": self.procedure_name,
            "detected_patterns_count": len(self.detected_patterns),
            "fully_resolved_count": len(self.fully_resolved),
            "partially_resolved_count": len(self.partially_resolved),
            "unresolvable_count": len(self.unresolvable),
            "analysis_warnings": self.analysis_warnings,
            "detected_patterns": [p.to_dict() for p in self.detected_patterns],
            "fully_resolved": [r.to_dict() for r in self.fully_resolved],
            "partially_resolved": [r.to_dict() for r in self.partially_resolved]
        }

    def has_dynamic_sql(self) -> bool:
        """Check if any dynamic SQL was detected."""
        return len(self.detected_patterns) > 0

    def get_all_resolved_sql(self) -> List[str]:
        """Get all fully resolved SQL statements."""
        return [r.reconstructed_sql for r in self.fully_resolved if r.reconstructed_sql]
