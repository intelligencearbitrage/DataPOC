# Dynamic SQL Experts

## Overview
This module contains individual expert implementations for dynamic SQL analysis. Each expert specializes in a specific aspect of dynamic SQL detection and reconstruction.

## Expert Architecture

All experts inherit from `BaseDynamicExpert` and implement a common interface for consistency and orchestration.

## Components

### `base_dynamic_expert.py`
Abstract base class for all dynamic SQL experts.

**Interface:**
```python
class BaseDynamicExpert(ABC):
    @abstractmethod
    def analyze(self, context: DynamicSQLContext) -> DynamicSQLExpertOutput:
        pass
    
    @abstractmethod
    def get_confidence(self) -> float:
        pass
```

**Provides:**
- Standard interface for all experts
- Common utility methods
- Error handling framework
- Logging capabilities

### `pattern_detection_expert.py`
Identifies dynamic SQL construction patterns in code.

**Detection Capabilities:**
- String concatenation for SQL building
- Dynamic table/column names
- Variable-based SQL construction
- EXECUTE/EXEC statement detection
- Dynamic DDL patterns

**Patterns Detected:**
- `'SELECT * FROM ' + @table_name`
- `EXEC('SQL string')`
- `SET @sql = ... ; EXECUTE(@sql)`
- Conditional SQL building
- Parameter substitution

**Output:**
```python
{
    "patterns": [
        {
            "type": "string_concatenation",
            "location": {"line": 5, "column": 10},
            "confidence": 0.9,
            "components": ["SELECT", "FROM", "@table_name"]
        }
    ],
    "dynamic_sql_detected": true
}
```

### `variable_tracking_expert.py`
Tracks variable assignments, modifications, and usage throughout code.

**Tracking Capabilities:**
- Variable declarations and assignments
- Value propagation through code flow
- Variable scope analysis
- Data type inference
- Variable lifecycle management

**Tracked Information:**
- Variable name and value
- Assignment location
- Scope level
- Data type
- Usage locations
- Modification history

**Output:**
```python
{
    "variables": {
        "@table_name": {
            "value": "CUSTOMERS",
            "type": "string",
            "assignments": [{"line": 1, "value": "CUSTOMERS"}],
            "usages": [{"line": 5, "context": "SQL construction"}]
        }
    }
}
```

### `control_flow_expert.py`
Analyzes control flow structures and their impact on SQL generation.

**Analysis Capabilities:**
- IF/ELSE branch analysis
- CASE statement evaluation
- Loop iterations
- Exception handling
- Conditional execution paths

**Handles:**
- Multiple execution paths
- Nested control structures
- Loop unrolling
- Short-circuit evaluation

**Output:**
```python
{
    "branches": [
        {
            "type": "if_else",
            "condition": "@status = 'ACTIVE'",
            "paths": [
                {"branch": "true", "sql": "..."},
                {"branch": "false", "sql": "..."}
            ]
        }
    ],
    "possible_paths": 4
}
```

### `reconstruction_expert.py`
Reconstructs possible SQL statements from dynamic code analysis.

**Reconstruction Capabilities:**
- Combine pattern and variable information
- Generate fully resolved SQL
- Handle partially resolved SQL with placeholders
- Support multiple possible variations
- Apply variable substitutions

**Strategies:**
- Direct substitution (known values)
- Placeholder insertion (unknown values)
- Path enumeration (control flow branches)
- Template filling

**Output:**
```python
{
    "fully_resolved": [
        "SELECT * FROM CUSTOMERS WHERE status = 'ACTIVE'"
    ],
    "partially_resolved": [
        "SELECT * FROM {table_name} WHERE status = {status}"
    ],
    "confidence_scores": [0.9, 0.7],
    "variations": 2
}
```

### `validation_expert.py`
Validates reconstructed SQL for correctness.

**Validation Capabilities:**
- Syntax validation
- Semantic correctness
- Schema compatibility
- Referenced object existence
- Data type compatibility

**Checks:**
- SQL syntax is valid
- Tables exist in schema
- Columns exist in tables
- Joins are valid
- Data types match

**Output:**
```python
{
    "valid_statements": 3,
    "invalid_statements": 1,
    "validation_errors": [
        {
            "sql": "...",
            "error": "Table 'INVALID_TABLE' not found",
            "severity": "error"
        }
    ],
    "warnings": [
        {
            "sql": "...",
            "warning": "Column type mismatch",
            "severity": "warning"
        }
    ]
}
```

## Expert Workflow

1. **Pattern Detection** - Identifies dynamic SQL patterns
2. **Variable Tracking** - Tracks variable values
3. **Control Flow** - Analyzes execution paths
4. **Reconstruction** - Builds possible SQL statements
5. **Validation** - Validates reconstructed SQL

## Usage Example

```python
from dynamic_sql.experts import (
    PatternDetectionExpert,
    VariableTrackingExpert,
    ReconstructionExpert
)
from dynamic_sql.expert_models.context_models import DynamicSQLContext

# Create context
context = DynamicSQLContext(
    original_code=sql_code,
    variable_state={},
    schema_context=schema
)

# Run experts
pattern_expert = PatternDetectionExpert()
pattern_output = pattern_expert.analyze(context)

var_expert = VariableTrackingExpert()
var_output = var_expert.analyze(context)

recon_expert = ReconstructionExpert()
recon_output = recon_expert.analyze(context)

# Access results
for sql in recon_output.data["fully_resolved"]:
    print(f"Reconstructed: {sql}")
```

## Confidence Scoring

Each expert provides confidence scores based on:
- Pattern clarity
- Variable resolution completeness
- Control flow complexity
- Validation success rate

**Confidence Ranges:**
- 0.9 - 1.0: High confidence
- 0.7 - 0.9: Medium confidence
- 0.5 - 0.7: Low confidence
- < 0.5: Very uncertain

## Integration Points
- Inputs: DynamicSQLContext
- Outputs: DynamicSQLExpertOutput
- Coordinated by: DynamicSQLOrchestrator
- Used by: Dynamic SQL analyzer
