"""
Validation Expert for Dynamic SQL Analysis.

Validates reconstructed SQL statements for syntax correctness,
completeness, and provides refinement suggestions when issues are found.
"""

import re
from typing import Any, Dict, List, Optional, Tuple

import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

from dynamic_sql.experts.base_dynamic_expert import BaseDynamicSQLExpert
from dynamic_sql.expert_models.data_models import (
    DynamicSQLExpertType,
    DynamicSQLExpertOutput
)
from dynamic_sql.expert_models.context_models import DynamicSQLContext, RefinementHint


class ValidationExpert(BaseDynamicSQLExpert):
    """
    Expert for validating reconstructed dynamic SQL.

    NEW implementation for the multi-expert architecture.
    Runs after ReconstructionExpert to validate results and
    trigger collaborative refinement if needed.

    Validates:
    - SQL syntax structure
    - Statement completeness
    - Parameter placeholders
    - Table/column reference patterns
    """

    # SQL keywords for different statement types
    SQL_KEYWORDS = {
        'SELECT': ['SELECT', 'FROM', 'WHERE', 'GROUP BY', 'HAVING', 'ORDER BY'],
        'INSERT': ['INSERT', 'INTO', 'VALUES', 'SELECT'],
        'UPDATE': ['UPDATE', 'SET', 'WHERE'],
        'DELETE': ['DELETE', 'FROM', 'WHERE'],
        'CREATE': ['CREATE', 'TABLE', 'VIEW', 'PROCEDURE', 'FUNCTION'],
        'ALTER': ['ALTER', 'TABLE', 'ADD', 'DROP', 'MODIFY'],
        'DROP': ['DROP', 'TABLE', 'VIEW', 'PROCEDURE'],
        'EXEC': ['EXEC', 'EXECUTE', 'CALL'],
        'MERGE': ['MERGE', 'INTO', 'USING', 'WHEN', 'MATCHED']
    }

    def __init__(self, dialect: str = "tsql"):
        """
        Initialize the validation expert.

        Args:
            dialect: SQL dialect (tsql, teradata, oracle)
        """
        super().__init__(dialect)

    @property
    def expert_type(self) -> DynamicSQLExpertType:
        """Return the expert type."""
        return DynamicSQLExpertType.VALIDATION

    def get_dependencies(self) -> List[DynamicSQLExpertType]:
        """Depends on reconstruction to have SQL to validate."""
        return [DynamicSQLExpertType.RECONSTRUCTION]

    def analyze(self, sql: str, **kwargs) -> DynamicSQLExpertOutput:
        """
        Validate SQL statements.

        Args:
            sql: SQL text to validate (or reconstructed SQL)
            **kwargs: Additional parameters including statements

        Returns:
            DynamicSQLExpertOutput with validation results
        """
        self._start_timer()

        if not self.validate_input(sql):
            return self._create_error_output("Invalid or empty SQL input")

        try:
            statements = kwargs.get('statements', [sql])

            # Validate each statement
            validation_results = []
            for stmt in statements:
                result = self._validate_statement(stmt)
                validation_results.append(result)

            # Build output data
            data = self._build_output_data(validation_results)
            confidence = self._calculate_confidence(validation_results)

            warnings = []
            refinement_suggestions = []
            requires_refinement = False

            for result in validation_results:
                if result['issues']:
                    warnings.extend(result['issues'])
                if result['suggestions']:
                    refinement_suggestions.extend(result['suggestions'])
                    requires_refinement = True

            return self._create_output(
                success=True,
                data=data,
                confidence=confidence,
                warnings=warnings,
                requires_refinement=requires_refinement,
                refinement_suggestions=refinement_suggestions
            )

        except Exception as e:
            return self._create_error_output(f"Validation failed: {str(e)}")

    def analyze_with_context(self, context: DynamicSQLContext) -> DynamicSQLExpertOutput:
        """
        Validate reconstructed SQL from context.

        Uses reconstruction results and can cross-reference with
        variable tracking and control flow information.

        Args:
            context: Shared context with reconstructed statements

        Returns:
            DynamicSQLExpertOutput with validation results
        """
        self._start_timer()

        if not self.validate_context(context):
            return self._create_error_output("Invalid context")

        try:
            reconstructed = context.reconstructed_statements
            if not reconstructed:
                return self._create_output(
                    success=True,
                    data={'validation_count': 0, 'results': []},
                    confidence=0.5
                )

            # Validate each reconstructed statement
            validation_results = []
            for recon in reconstructed:
                sql = recon.reconstructed_sql if hasattr(recon, 'reconstructed_sql') else str(recon)
                result = self._validate_statement(sql)

                # Add reconstruction metadata
                result['pattern_line'] = getattr(recon, 'original_pattern', {})
                if hasattr(result['pattern_line'], 'start_line'):
                    result['pattern_line'] = result['pattern_line'].start_line
                result['resolution_status'] = getattr(recon, 'resolution_status', None)
                if result['resolution_status']:
                    result['resolution_status'] = result['resolution_status'].value

                # Cross-reference with variable states
                if context.variable_states and sql:
                    var_issues = self._check_variable_references(sql, context.variable_states)
                    result['issues'].extend(var_issues)

                # Cross-reference with control flow
                if context.control_flow_graph:
                    cfg_notes = self._check_control_flow_consistency(recon, context.control_flow_graph)
                    result['notes'].extend(cfg_notes)

                validation_results.append(result)

            # Build output data
            data = self._build_output_data(validation_results)
            confidence = self._calculate_confidence(validation_results)

            # Analyze for refinement needs
            warnings, suggestions, requires_refinement = self._analyze_refinement_needs(
                validation_results, context
            )

            return self._create_output(
                success=True,
                data=data,
                confidence=confidence,
                warnings=warnings,
                requires_refinement=requires_refinement,
                refinement_suggestions=suggestions
            )

        except Exception as e:
            return self._create_error_output(f"Validation failed: {str(e)}")

    def refine(self, context: DynamicSQLContext,
               previous_outputs: Dict[str, DynamicSQLExpertOutput]) -> DynamicSQLExpertOutput:
        """
        Re-validate after other experts have refined their outputs.

        Args:
            context: Current context with potentially updated reconstructions
            previous_outputs: Outputs from other experts

        Returns:
            Refined DynamicSQLExpertOutput
        """
        self._start_timer()

        # Re-run validation with updated context
        result = self.analyze_with_context(context)

        # Add refinement metadata
        result.data['refined'] = True
        result.data['iteration'] = context.iteration

        # Check if quality improved
        reconstruction_output = previous_outputs.get('ReconstructionExpert')
        if reconstruction_output:
            prev_confidence = reconstruction_output.confidence
            curr_confidence = result.confidence

            if curr_confidence > prev_confidence:
                result.data['improvement'] = curr_confidence - prev_confidence
            elif curr_confidence == prev_confidence and context.iteration > 1:
                # No improvement - stop refinement
                result.requires_refinement = False

        return result

    def _validate_statement(self, sql: str) -> Dict[str, Any]:
        """
        Validate a single SQL statement.

        Returns:
            Dict with validation results
        """
        result = {
            'sql': sql[:200] if sql else None,
            'is_valid': True,
            'statement_type': None,
            'completeness': 'unknown',
            'issues': [],
            'suggestions': [],
            'notes': []
        }

        if not sql or not sql.strip():
            result['is_valid'] = False
            result['issues'].append("Empty SQL statement")
            return result

        sql_upper = sql.upper().strip()

        # Detect statement type
        result['statement_type'] = self._detect_statement_type(sql_upper)

        # Check for unresolved placeholders
        placeholder_issues = self._check_placeholders(sql)
        result['issues'].extend(placeholder_issues)
        if placeholder_issues:
            result['is_valid'] = False
            result['completeness'] = 'incomplete'
            result['suggestions'].append("Resolve variable placeholders")

        # Check basic syntax structure
        syntax_issues = self._check_syntax_structure(sql_upper, result['statement_type'])
        result['issues'].extend(syntax_issues)
        if syntax_issues:
            result['is_valid'] = False

        # Check for common SQL problems
        problem_issues = self._check_common_problems(sql_upper)
        result['issues'].extend(problem_issues)

        # Determine completeness
        if result['is_valid'] and not result['issues']:
            result['completeness'] = 'complete'
        elif placeholder_issues:
            result['completeness'] = 'incomplete'
        else:
            result['completeness'] = 'partial'

        return result

    def _detect_statement_type(self, sql_upper: str) -> Optional[str]:
        """Detect the type of SQL statement."""
        for stmt_type in self.SQL_KEYWORDS.keys():
            if sql_upper.startswith(stmt_type):
                return stmt_type

        # Check for CTE
        if sql_upper.startswith('WITH'):
            return 'SELECT'  # CTE followed by SELECT

        return None

    def _check_placeholders(self, sql: str) -> List[str]:
        """Check for unresolved placeholders."""
        issues = []

        # Check for ${...} placeholders
        placeholder_pattern = r'\$\{([^}]+)\}'
        matches = re.findall(placeholder_pattern, sql)
        if matches:
            issues.append(f"Unresolved placeholders: {', '.join(matches)}")

        # Check for @variable patterns that might be unresolved
        var_pattern = r'@\w+(?:\s*\+|$)'
        var_matches = re.findall(var_pattern, sql)
        # Only flag if looks like concatenation
        for match in var_matches:
            if '+' in match:
                issues.append(f"Potential unresolved variable concatenation: {match.strip()}")

        return issues

    def _check_syntax_structure(self, sql_upper: str, stmt_type: Optional[str]) -> List[str]:
        """Check basic SQL syntax structure."""
        issues = []

        if not stmt_type:
            if not any(sql_upper.startswith(kw) for kw in ['WITH', 'SET', 'DECLARE', 'BEGIN']):
                issues.append("Unrecognized SQL statement type")
            return issues

        expected_keywords = self.SQL_KEYWORDS.get(stmt_type, [])

        # Check for required keywords
        if stmt_type == 'SELECT':
            if 'FROM' not in sql_upper and 'SELECT @@' not in sql_upper and 'SELECT GETDATE' not in sql_upper:
                # SELECT without FROM is often valid for system functions
                if not re.search(r'SELECT\s+\d+|SELECT\s+\'', sql_upper):
                    issues.append("SELECT statement may be missing FROM clause")

        elif stmt_type == 'INSERT':
            if 'INTO' not in sql_upper:
                issues.append("INSERT statement missing INTO clause")
            if 'VALUES' not in sql_upper and 'SELECT' not in sql_upper:
                issues.append("INSERT statement missing VALUES or SELECT clause")

        elif stmt_type == 'UPDATE':
            if 'SET' not in sql_upper:
                issues.append("UPDATE statement missing SET clause")

        elif stmt_type == 'DELETE':
            if 'FROM' not in sql_upper:
                # DELETE table_name is valid, but DELETE FROM is more common
                pass

        # Check for balanced parentheses
        open_parens = sql_upper.count('(')
        close_parens = sql_upper.count(')')
        if open_parens != close_parens:
            issues.append(f"Unbalanced parentheses: {open_parens} open, {close_parens} close")

        # Check for balanced quotes (basic check)
        single_quotes = sql_upper.count("'")
        if single_quotes % 2 != 0:
            issues.append("Unbalanced single quotes")

        return issues

    def _check_common_problems(self, sql_upper: str) -> List[str]:
        """Check for common SQL problems."""
        issues = []

        # Check for potential SQL injection patterns (in dynamic SQL this is important)
        if "' OR '" in sql_upper or "' AND '" in sql_upper:
            issues.append("Warning: Pattern resembles SQL injection")

        # Check for missing table references after keywords
        if re.search(r'\bFROM\s*$', sql_upper):
            issues.append("FROM clause is empty")
        if re.search(r'\bINTO\s*$', sql_upper):
            issues.append("INTO clause is empty")
        if re.search(r'\bUPDATE\s*SET\b', sql_upper):
            issues.append("UPDATE missing table name before SET")

        # Check for double commas
        if ',,' in sql_upper:
            issues.append("Double comma found - possible missing column/value")

        return issues

    def _check_variable_references(self, sql: str, variable_states: Dict) -> List[str]:
        """Check that variable references are valid."""
        issues = []

        # Find @variable references in SQL
        var_pattern = r'@(\w+)'
        referenced_vars = set(re.findall(var_pattern, sql))

        # Check against tracked variables
        for var in referenced_vars:
            full_name = f"@{var}"
            if full_name not in variable_states and var not in variable_states:
                # Could be a parameter, not necessarily an issue
                pass

        return issues

    def _check_control_flow_consistency(self, recon, cfg) -> List[str]:
        """Check consistency with control flow graph."""
        notes = []

        if not hasattr(recon, 'original_pattern') or not recon.original_pattern:
            return notes

        pattern_line = recon.original_pattern.start_line

        # Check if pattern is in a loop
        for node_id, node in cfg.nodes.items():
            if node.line_number == pattern_line:
                if node.is_dynamic_sql_related:
                    notes.append("Statement is part of tracked dynamic SQL flow")
                break

        if cfg.has_loops:
            notes.append("Note: Procedure contains loops - SQL may execute multiple times")

        return notes

    def _build_output_data(self, validation_results: List[Dict]) -> Dict[str, Any]:
        """Build output data from validation results."""
        valid_count = sum(1 for r in validation_results if r['is_valid'])
        complete_count = sum(1 for r in validation_results if r['completeness'] == 'complete')

        return {
            'validation_count': len(validation_results),
            'valid_count': valid_count,
            'invalid_count': len(validation_results) - valid_count,
            'complete_count': complete_count,
            'results': validation_results,
            'statement_types': list(set(r['statement_type'] for r in validation_results if r['statement_type']))
        }

    def _calculate_confidence(self, validation_results: List[Dict]) -> float:
        """Calculate overall confidence for validation."""
        if not validation_results:
            return 0.5

        # Base on validity and completeness
        valid_ratio = sum(1 for r in validation_results if r['is_valid']) / len(validation_results)
        complete_ratio = sum(1 for r in validation_results if r['completeness'] == 'complete') / len(validation_results)

        # Weight validity higher
        confidence = (valid_ratio * 0.6) + (complete_ratio * 0.4)

        # Ensure minimum confidence
        return max(0.3, confidence)

    def _analyze_refinement_needs(self, validation_results: List[Dict],
                                  context: DynamicSQLContext) -> Tuple[List[str], List[str], bool]:
        """Analyze validation results to determine refinement needs."""
        warnings = []
        suggestions = []
        requires_refinement = False

        for result in validation_results:
            if result['issues']:
                warnings.extend(result['issues'])
            if result['suggestions']:
                suggestions.extend(result['suggestions'])
                requires_refinement = True

        # Suggest refinement if too many incomplete statements
        incomplete_count = sum(1 for r in validation_results if r['completeness'] != 'complete')
        if incomplete_count > 0 and context.iteration < 3:
            requires_refinement = True
            if 'variable' in str(warnings).lower():
                suggestions.append("Variable tracking may need to resolve more references")
            if 'placeholder' in str(warnings).lower():
                suggestions.append("Pattern detection may have missed some dynamic SQL constructs")

        return warnings, list(set(suggestions)), requires_refinement

    def _generate_hints(self, context: DynamicSQLContext,
                        output: DynamicSQLExpertOutput) -> List[RefinementHint]:
        """Generate hints for other experts."""
        hints = []

        # If validation found unresolved variables, hint to variable tracking
        if 'Unresolved placeholders' in str(output.warnings):
            hints.append(RefinementHint(
                source_expert=self.name,
                target_expert='VariableTrackingExpert',
                hint_type='unresolved_variables',
                hint_data={'message': 'Validation found unresolved placeholders'},
                priority=3
            ))

        # If syntax issues, hint to reconstruction
        if 'syntax' in str(output.warnings).lower():
            hints.append(RefinementHint(
                source_expert=self.name,
                target_expert='ReconstructionExpert',
                hint_type='syntax_issues',
                hint_data={'message': 'Validation found syntax issues'},
                priority=2
            ))

        return hints
