"""
Conflict Resolver for Dynamic SQL Multi-Expert Architecture.

Handles conflicts between expert outputs using various resolution strategies.
"""

from enum import Enum
from typing import Any, Dict, List, Optional, Tuple
from dataclasses import dataclass, field
from datetime import datetime

import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

from dynamic_sql.expert_models.data_models import DynamicSQLExpertOutput


class ConflictResolutionStrategy(Enum):
    """Strategies for resolving conflicts between experts."""
    HIGHEST_CONFIDENCE = "highest_confidence"
    EXPERT_PRIORITY = "expert_priority"
    UNION_ALL = "union_all"
    MAJORITY_VOTE = "majority_vote"
    MOST_RECENT = "most_recent"


@dataclass
class Conflict:
    """Represents a conflict between expert outputs."""
    conflict_id: str
    conflict_type: str  # 'pattern_overlap', 'variable_mismatch', 'reconstruction_disagreement'
    experts_involved: List[str]
    conflicting_data: Dict[str, Any]
    resolution: Optional[str] = None
    resolution_strategy: Optional[ConflictResolutionStrategy] = None
    resolved_value: Optional[Any] = None
    timestamp: datetime = field(default_factory=datetime.now)


class ConflictResolver:
    """
    Resolves conflicts between expert outputs in multi-expert analysis.

    Supports multiple resolution strategies:
    - HIGHEST_CONFIDENCE: Use output with highest confidence score
    - EXPERT_PRIORITY: Use predefined expert priority order
    - UNION_ALL: Combine all outputs (for additive results)
    - MAJORITY_VOTE: Use most common output (for multiple experts)
    - MOST_RECENT: Use most recent output (for refinement iterations)
    """

    # Default expert priority order (higher index = higher priority)
    DEFAULT_PRIORITY = [
        'PatternDetectionExpert',
        'VariableTrackingExpert',
        'ControlFlowExpert',
        'ReconstructionExpert',
        'ValidationExpert'
    ]

    def __init__(self, default_strategy: ConflictResolutionStrategy = ConflictResolutionStrategy.HIGHEST_CONFIDENCE):
        """
        Initialize the conflict resolver.

        Args:
            default_strategy: Default strategy for conflict resolution
        """
        self.default_strategy = default_strategy
        self.expert_priority = self.DEFAULT_PRIORITY.copy()
        self.conflicts: List[Conflict] = []
        self._conflict_counter = 0

    def set_expert_priority(self, priority_order: List[str]) -> None:
        """
        Set custom expert priority order.

        Args:
            priority_order: List of expert names in priority order (last = highest)
        """
        self.expert_priority = priority_order

    def detect_conflicts(self, outputs: Dict[str, DynamicSQLExpertOutput]) -> List[Conflict]:
        """
        Detect conflicts between multiple expert outputs.

        Args:
            outputs: Dict mapping expert names to their outputs

        Returns:
            List of detected conflicts
        """
        conflicts = []

        # Check for pattern overlaps
        pattern_conflicts = self._detect_pattern_conflicts(outputs)
        conflicts.extend(pattern_conflicts)

        # Check for variable mismatches
        variable_conflicts = self._detect_variable_conflicts(outputs)
        conflicts.extend(variable_conflicts)

        # Check for reconstruction disagreements
        reconstruction_conflicts = self._detect_reconstruction_conflicts(outputs)
        conflicts.extend(reconstruction_conflicts)

        self.conflicts.extend(conflicts)
        return conflicts

    def resolve_conflict(self, conflict: Conflict,
                        outputs: Dict[str, DynamicSQLExpertOutput],
                        strategy: Optional[ConflictResolutionStrategy] = None) -> Any:
        """
        Resolve a specific conflict using the given strategy.

        Args:
            conflict: Conflict to resolve
            outputs: Expert outputs involved
            strategy: Resolution strategy (uses default if not provided)

        Returns:
            Resolved value
        """
        strategy = strategy or self.default_strategy
        conflict.resolution_strategy = strategy

        if strategy == ConflictResolutionStrategy.HIGHEST_CONFIDENCE:
            resolved = self._resolve_by_confidence(conflict, outputs)
        elif strategy == ConflictResolutionStrategy.EXPERT_PRIORITY:
            resolved = self._resolve_by_priority(conflict, outputs)
        elif strategy == ConflictResolutionStrategy.UNION_ALL:
            resolved = self._resolve_by_union(conflict, outputs)
        elif strategy == ConflictResolutionStrategy.MAJORITY_VOTE:
            resolved = self._resolve_by_majority(conflict, outputs)
        elif strategy == ConflictResolutionStrategy.MOST_RECENT:
            resolved = self._resolve_by_recency(conflict, outputs)
        else:
            resolved = self._resolve_by_confidence(conflict, outputs)

        conflict.resolved_value = resolved
        conflict.resolution = f"Resolved using {strategy.value}"
        return resolved

    def resolve_all_conflicts(self, outputs: Dict[str, DynamicSQLExpertOutput],
                             strategy: Optional[ConflictResolutionStrategy] = None) -> Dict[str, Any]:
        """
        Detect and resolve all conflicts between expert outputs.

        Args:
            outputs: Dict mapping expert names to their outputs
            strategy: Resolution strategy to use

        Returns:
            Dict of resolved values keyed by conflict type
        """
        conflicts = self.detect_conflicts(outputs)
        resolutions = {}

        for conflict in conflicts:
            resolved = self.resolve_conflict(conflict, outputs, strategy)
            if conflict.conflict_type not in resolutions:
                resolutions[conflict.conflict_type] = []
            resolutions[conflict.conflict_type].append({
                'conflict_id': conflict.conflict_id,
                'resolution': resolved,
                'strategy': conflict.resolution_strategy.value if conflict.resolution_strategy else None
            })

        return resolutions

    def _detect_pattern_conflicts(self, outputs: Dict[str, DynamicSQLExpertOutput]) -> List[Conflict]:
        """Detect conflicting pattern detections."""
        conflicts = []

        # Get pattern detection output
        pattern_output = outputs.get('PatternDetectionExpert')
        if not pattern_output or not pattern_output.success:
            return conflicts

        patterns = pattern_output.data.get('patterns', [])

        # Check for overlapping patterns (same line range)
        for i, p1 in enumerate(patterns):
            for p2 in patterns[i+1:]:
                if self._patterns_overlap(p1, p2):
                    self._conflict_counter += 1
                    conflicts.append(Conflict(
                        conflict_id=f"conflict_{self._conflict_counter}",
                        conflict_type='pattern_overlap',
                        experts_involved=['PatternDetectionExpert'],
                        conflicting_data={'pattern1': p1, 'pattern2': p2}
                    ))

        return conflicts

    def _detect_variable_conflicts(self, outputs: Dict[str, DynamicSQLExpertOutput]) -> List[Conflict]:
        """Detect conflicting variable states."""
        conflicts = []

        # Get variable tracking output
        var_output = outputs.get('VariableTrackingExpert')
        recon_output = outputs.get('ReconstructionExpert')

        if not var_output or not recon_output:
            return conflicts

        tracked_vars = var_output.data.get('variables', {})
        recon_statements = recon_output.data.get('statements', [])

        # Check for variables referenced in reconstruction but not tracked
        for stmt in recon_statements:
            unresolved = stmt.get('unresolved_parts', [])
            for var in unresolved:
                if var.startswith('@') or var.startswith('$'):
                    var_name = var.lstrip('@$')
                    if var_name and var_name not in tracked_vars:
                        self._conflict_counter += 1
                        conflicts.append(Conflict(
                            conflict_id=f"conflict_{self._conflict_counter}",
                            conflict_type='variable_mismatch',
                            experts_involved=['VariableTrackingExpert', 'ReconstructionExpert'],
                            conflicting_data={
                                'missing_variable': var,
                                'statement': stmt.get('reconstructed_sql', '')[:100]
                            }
                        ))

        return conflicts

    def _detect_reconstruction_conflicts(self, outputs: Dict[str, DynamicSQLExpertOutput]) -> List[Conflict]:
        """Detect reconstruction disagreements."""
        conflicts = []

        recon_output = outputs.get('ReconstructionExpert')
        validation_output = outputs.get('ValidationExpert')

        if not recon_output or not validation_output:
            return conflicts

        # Check for statements marked valid by reconstruction but invalid by validation
        recon_statements = recon_output.data.get('statements', [])
        validation_results = validation_output.data.get('results', [])

        for i, (recon, valid) in enumerate(zip(recon_statements, validation_results)):
            recon_complete = recon.get('is_complete', False)
            valid_complete = valid.get('completeness', '') == 'complete'

            if recon_complete and not valid_complete:
                self._conflict_counter += 1
                conflicts.append(Conflict(
                    conflict_id=f"conflict_{self._conflict_counter}",
                    conflict_type='reconstruction_disagreement',
                    experts_involved=['ReconstructionExpert', 'ValidationExpert'],
                    conflicting_data={
                        'reconstruction_says_complete': True,
                        'validation_says_complete': False,
                        'validation_issues': valid.get('issues', [])
                    }
                ))

        return conflicts

    def _patterns_overlap(self, p1: Dict, p2: Dict) -> bool:
        """Check if two patterns overlap in line range."""
        start1 = p1.get('start_line', 0)
        end1 = p1.get('end_line', start1)
        start2 = p2.get('start_line', 0)
        end2 = p2.get('end_line', start2)

        return not (end1 < start2 or end2 < start1)

    def _resolve_by_confidence(self, conflict: Conflict,
                               outputs: Dict[str, DynamicSQLExpertOutput]) -> Any:
        """Resolve conflict by choosing highest confidence output."""
        best_expert = None
        best_confidence = -1

        for expert_name in conflict.experts_involved:
            output = outputs.get(expert_name)
            if output and output.confidence > best_confidence:
                best_confidence = output.confidence
                best_expert = expert_name

        if best_expert:
            return {
                'winner': best_expert,
                'confidence': best_confidence,
                'data': conflict.conflicting_data
            }
        return conflict.conflicting_data

    def _resolve_by_priority(self, conflict: Conflict,
                             outputs: Dict[str, DynamicSQLExpertOutput]) -> Any:
        """Resolve conflict by expert priority."""
        best_expert = None
        best_priority = -1

        for expert_name in conflict.experts_involved:
            if expert_name in self.expert_priority:
                priority = self.expert_priority.index(expert_name)
                if priority > best_priority:
                    best_priority = priority
                    best_expert = expert_name

        if best_expert:
            return {
                'winner': best_expert,
                'priority': best_priority,
                'data': conflict.conflicting_data
            }
        return conflict.conflicting_data

    def _resolve_by_union(self, conflict: Conflict,
                          outputs: Dict[str, DynamicSQLExpertOutput]) -> Any:
        """Resolve conflict by combining all data."""
        combined = {
            'sources': conflict.experts_involved,
            'combined_data': conflict.conflicting_data
        }
        return combined

    def _resolve_by_majority(self, conflict: Conflict,
                             outputs: Dict[str, DynamicSQLExpertOutput]) -> Any:
        """Resolve conflict by majority vote (for 3+ experts)."""
        # For pattern conflicts, count similar patterns
        if conflict.conflict_type == 'pattern_overlap':
            # Since patterns are from same expert, use confidence
            return self._resolve_by_confidence(conflict, outputs)

        # For other conflicts, just return the data
        return conflict.conflicting_data

    def _resolve_by_recency(self, conflict: Conflict,
                            outputs: Dict[str, DynamicSQLExpertOutput]) -> Any:
        """Resolve conflict by most recent output."""
        # Use execution time as proxy for recency
        best_expert = None
        best_time = 0

        for expert_name in conflict.experts_involved:
            output = outputs.get(expert_name)
            if output and output.execution_time_ms > best_time:
                best_time = output.execution_time_ms
                best_expert = expert_name

        if best_expert:
            return {
                'winner': best_expert,
                'execution_time_ms': best_time,
                'data': conflict.conflicting_data
            }
        return conflict.conflicting_data

    def get_conflict_summary(self) -> Dict[str, Any]:
        """Get summary of all conflicts detected and resolved."""
        resolved = [c for c in self.conflicts if c.resolution]
        unresolved = [c for c in self.conflicts if not c.resolution]

        by_type = {}
        for conflict in self.conflicts:
            if conflict.conflict_type not in by_type:
                by_type[conflict.conflict_type] = 0
            by_type[conflict.conflict_type] += 1

        return {
            'total_conflicts': len(self.conflicts),
            'resolved_count': len(resolved),
            'unresolved_count': len(unresolved),
            'by_type': by_type,
            'strategies_used': list(set(
                c.resolution_strategy.value
                for c in resolved
                if c.resolution_strategy
            ))
        }

    def clear_conflicts(self) -> None:
        """Clear conflict history."""
        self.conflicts = []
        self._conflict_counter = 0
