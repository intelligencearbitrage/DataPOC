"""
Pattern Detection Expert for Dynamic SQL Analysis.

Detects dynamic SQL execution patterns like EXEC, sp_executesql,
and EXECUTE IMMEDIATE in stored procedures.
"""

from typing import Any, Dict, List, Optional

import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

from dynamic_sql.experts.base_dynamic_expert import BaseDynamicSQLExpert
from dynamic_sql.expert_models.data_models import (
    DynamicSQLExpertType,
    DynamicSQLExpertOutput
)
from dynamic_sql.expert_models.context_models import DynamicSQLContext, RefinementHint
from dynamic_sql.detector import DynamicSQLDetector


class PatternDetectionExpert(BaseDynamicSQLExpert):
    """
    Expert for detecting dynamic SQL execution patterns.

    Wraps the existing DynamicSQLDetector with the multi-expert interface.
    Runs first in the pipeline with no dependencies.

    Detects:
    - EXEC(@sql) patterns
    - sp_executesql calls
    - EXECUTE IMMEDIATE (Teradata/Oracle)
    - PREPARE/EXECUTE patterns
    """

    def __init__(self, dialect: str = "tsql"):
        """
        Initialize the pattern detection expert.

        Args:
            dialect: SQL dialect (tsql, teradata, oracle)
        """
        super().__init__(dialect)
        self._detector = DynamicSQLDetector(dialect)

    @property
    def expert_type(self) -> DynamicSQLExpertType:
        """Return the expert type."""
        return DynamicSQLExpertType.PATTERN_DETECTION

    def get_dependencies(self) -> List[DynamicSQLExpertType]:
        """No dependencies - runs first."""
        return []

    def analyze(self, sql: str, **kwargs) -> DynamicSQLExpertOutput:
        """
        Detect dynamic SQL patterns in the given SQL.

        Args:
            sql: SQL text to analyze
            **kwargs: Additional parameters (procedure_name, etc.)

        Returns:
            DynamicSQLExpertOutput with detected patterns
        """
        self._start_timer()

        if not self.validate_input(sql):
            return self._create_error_output("Invalid or empty SQL input")

        try:
            # Use existing detector
            patterns = self._detector.detect(sql)

            # Calculate confidence based on pattern characteristics
            confidence = self._calculate_confidence(patterns)

            # Build output data
            data = {
                'patterns': [self._pattern_to_dict(p) for p in patterns],
                'pattern_count': len(patterns),
                'pattern_types': list(set(p.pattern_type.value for p in patterns)),
                'variables_used': list(set(p.variable_name for p in patterns if p.variable_name)),
                'has_sp_executesql': any(p.pattern_type.value == 'SP_EXECUTESQL' for p in patterns),
                'has_exec_string': any(p.pattern_type.value == 'EXEC_STRING' for p in patterns),
            }

            # Warnings for complex patterns
            warnings = []
            for pattern in patterns:
                if pattern.confidence < 0.7:
                    warnings.append(f"Low confidence pattern at line {pattern.start_line}")

            return self._create_output(
                success=True,
                data=data,
                context_updates={'detected_patterns': patterns},
                confidence=confidence,
                warnings=warnings
            )

        except Exception as e:
            return self._create_error_output(f"Pattern detection failed: {str(e)}")

    def analyze_with_context(self, context: DynamicSQLContext) -> DynamicSQLExpertOutput:
        """
        Analyze using shared context.

        For pattern detection, this is similar to basic analysis but can
        use hints from previous refinement iterations.

        Args:
            context: Shared context

        Returns:
            DynamicSQLExpertOutput with detected patterns
        """
        self._start_timer()

        if not self.validate_context(context):
            return self._create_error_output("Invalid context")

        # Apply any refinement hints
        hints = self._apply_hints(context)

        # Perform detection
        patterns = self._detector.detect(context.sql_text)

        # If we have hints about missed patterns, try harder
        if hints:
            for hint in hints:
                if hint.hint_type == 'missed_pattern':
                    additional = self._search_for_pattern(
                        context.sql_text,
                        hint.hint_data.get('pattern_hint', '')
                    )
                    patterns.extend(additional)

        confidence = self._calculate_confidence(patterns)

        data = {
            'patterns': [self._pattern_to_dict(p) for p in patterns],
            'pattern_count': len(patterns),
            'pattern_types': list(set(p.pattern_type.value for p in patterns)),
            'variables_used': list(set(p.variable_name for p in patterns if p.variable_name)),
            'hints_applied': len(hints)
        }

        return self._create_output(
            success=True,
            data=data,
            context_updates={'detected_patterns': patterns},
            confidence=confidence
        )

    def refine(self, context: DynamicSQLContext,
               previous_outputs: Dict[str, DynamicSQLExpertOutput]) -> DynamicSQLExpertOutput:
        """
        Refine pattern detection based on other experts' outputs.

        Can use variable tracking information to find patterns that
        were missed in initial detection.

        Args:
            context: Current context
            previous_outputs: Outputs from other experts

        Returns:
            Refined DynamicSQLExpertOutput
        """
        self._start_timer()

        # Get current patterns
        current_patterns = list(context.detected_patterns)

        # Check if variable tracking found SQL-building variables we missed
        variable_output = previous_outputs.get('VariableTrackingExpert')
        if variable_output and variable_output.success:
            sql_vars = variable_output.data.get('sql_variables', [])
            detected_vars = set(p.variable_name for p in current_patterns)

            # Look for SQL variables that aren't in detected patterns
            missed_vars = set(sql_vars) - detected_vars
            if missed_vars:
                for var_name in missed_vars:
                    # Search for EXEC statements using this variable
                    additional = self._search_for_variable_exec(context.sql_text, var_name)
                    current_patterns.extend(additional)

        # Check validation output for suggestions
        validation_output = previous_outputs.get('ValidationExpert')
        if validation_output and validation_output.refinement_suggestions:
            for suggestion in validation_output.refinement_suggestions:
                if 'pattern' in suggestion.lower():
                    # Try to find additional patterns based on suggestion
                    pass

        confidence = self._calculate_confidence(current_patterns)

        data = {
            'patterns': [self._pattern_to_dict(p) for p in current_patterns],
            'pattern_count': len(current_patterns),
            'pattern_types': list(set(p.pattern_type.value for p in current_patterns)),
            'refined': True,
            'iteration': context.iteration
        }

        return self._create_output(
            success=True,
            data=data,
            context_updates={'detected_patterns': current_patterns},
            confidence=confidence
        )

    def _calculate_confidence(self, patterns: List) -> float:
        """Calculate overall confidence for detected patterns."""
        if not patterns:
            return 0.5  # No patterns found - uncertain

        # Average pattern confidence
        avg_confidence = sum(p.confidence for p in patterns) / len(patterns)

        # Boost if we found multiple pattern types (more thorough)
        pattern_types = set(p.pattern_type for p in patterns)
        type_bonus = min(0.1 * (len(pattern_types) - 1), 0.2)

        return min(avg_confidence + type_bonus, 1.0)

    def _pattern_to_dict(self, pattern) -> Dict[str, Any]:
        """Convert a pattern to dictionary."""
        return {
            'pattern_type': pattern.pattern_type.value,
            'variable_name': pattern.variable_name,
            'start_line': pattern.start_line,
            'end_line': pattern.end_line,
            'execution_sql': pattern.execution_sql[:100] if pattern.execution_sql else None,
            'confidence': pattern.confidence,
            'has_parameters': bool(pattern.parameters)
        }

    def _search_for_pattern(self, sql: str, hint: str) -> List:
        """Search for additional patterns based on a hint."""
        # Re-run detector with potentially different settings
        # This is a placeholder for more sophisticated search
        return []

    def _search_for_variable_exec(self, sql: str, var_name: str) -> List:
        """Search for EXEC statements using a specific variable."""
        import re
        additional = []

        # Simple search for EXEC @var patterns
        pattern = rf'\bEXEC(?:UTE)?\s*\(\s*{re.escape(var_name)}\s*\)'
        matches = re.finditer(pattern, sql, re.IGNORECASE)

        # This would need to create proper DynamicSQLPattern objects
        # For now, return empty - the detector should catch most cases
        return additional
