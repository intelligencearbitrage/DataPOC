"""
Expert Models for Dynamic SQL Multi-Expert Architecture.

Provides enums, data classes, and constants for the dynamic SQL expert system.
"""

from enum import Enum
from typing import Any, Dict, List, Optional, Set
from dataclasses import dataclass, field
from datetime import datetime

import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

from experts.base_expert import ExpertOutput


class DynamicSQLExpertType(Enum):
    """Types of dynamic SQL experts."""
    PATTERN_DETECTION = "PATTERN_DETECTION"
    VARIABLE_TRACKING = "VARIABLE_TRACKING"
    CONTROL_FLOW = "CONTROL_FLOW"
    RECONSTRUCTION = "RECONSTRUCTION"
    VALIDATION = "VALIDATION"


class DynamicSQLConflictType(Enum):
    """Types of conflicts specific to dynamic SQL analysis."""
    PATTERN_OVERLAP = "PATTERN_OVERLAP"
    VARIABLE_VALUE_MISMATCH = "VARIABLE_VALUE_MISMATCH"
    CONTROL_FLOW_AMBIGUITY = "CONTROL_FLOW_AMBIGUITY"
    RECONSTRUCTION_DISAGREEMENT = "RECONSTRUCTION_DISAGREEMENT"
    VALIDATION_FAILURE = "VALIDATION_FAILURE"


# Expert priority for conflict resolution (higher = more trusted)
EXPERT_PRIORITY = {
    DynamicSQLExpertType.PATTERN_DETECTION: 1,
    DynamicSQLExpertType.VARIABLE_TRACKING: 3,
    DynamicSQLExpertType.CONTROL_FLOW: 2,
    DynamicSQLExpertType.RECONSTRUCTION: 4,
    DynamicSQLExpertType.VALIDATION: 5,
}


@dataclass
class DynamicSQLExpertOutput(ExpertOutput):
    """
    Extended output for dynamic SQL experts.

    Adds context updates for shared state and refinement capabilities.
    """
    expert_type: DynamicSQLExpertType = DynamicSQLExpertType.PATTERN_DETECTION
    context_updates: Dict[str, Any] = field(default_factory=dict)
    requires_refinement: bool = False
    refinement_suggestions: List[str] = field(default_factory=list)
    execution_time_ms: float = 0.0

    def to_dict(self) -> Dict[str, Any]:
        base_dict = super().to_dict()
        base_dict.update({
            "expert_type": self.expert_type.value,
            "context_updates": {k: str(v)[:100] for k, v in self.context_updates.items()},
            "requires_refinement": self.requires_refinement,
            "refinement_suggestions": self.refinement_suggestions,
            "execution_time_ms": self.execution_time_ms
        })
        return base_dict


class ControlFlowNodeType(Enum):
    """Types of control flow nodes."""
    ENTRY = "ENTRY"
    EXIT = "EXIT"
    IF = "IF"
    ELSE = "ELSE"
    ELSEIF = "ELSEIF"
    WHILE = "WHILE"
    CURSOR_OPEN = "CURSOR_OPEN"
    CURSOR_FETCH = "CURSOR_FETCH"
    CURSOR_CLOSE = "CURSOR_CLOSE"
    EXEC = "EXEC"
    ASSIGN = "ASSIGN"
    DECLARE = "DECLARE"
    BEGIN = "BEGIN"
    END = "END"
    TRY = "TRY"
    CATCH = "CATCH"
    RETURN = "RETURN"


@dataclass
class ControlFlowNode:
    """Node in the control flow graph."""
    node_id: str
    node_type: ControlFlowNodeType
    line_number: int = 0
    end_line: int = 0
    condition: Optional[str] = None
    sql_text: Optional[str] = None
    variables_read: List[str] = field(default_factory=list)
    variables_written: List[str] = field(default_factory=list)
    is_dynamic_sql_related: bool = False
    metadata: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "node_id": self.node_id,
            "node_type": self.node_type.value,
            "line_number": self.line_number,
            "end_line": self.end_line,
            "condition": self.condition,
            "sql_text": self.sql_text[:100] if self.sql_text else None,
            "variables_read": self.variables_read,
            "variables_written": self.variables_written,
            "is_dynamic_sql_related": self.is_dynamic_sql_related,
            "metadata": self.metadata
        }


@dataclass
class ControlFlowEdge:
    """Edge in the control flow graph."""
    edge_id: str
    source_id: str
    target_id: str
    edge_type: str = "SEQUENTIAL"  # SEQUENTIAL, TRUE_BRANCH, FALSE_BRANCH, LOOP_BACK
    condition: Optional[str] = None

    def to_dict(self) -> Dict[str, Any]:
        return {
            "edge_id": self.edge_id,
            "source_id": self.source_id,
            "target_id": self.target_id,
            "edge_type": self.edge_type,
            "condition": self.condition
        }


@dataclass
class ControlFlowGraph:
    """Control flow graph for a stored procedure."""
    procedure_name: Optional[str] = None
    nodes: Dict[str, ControlFlowNode] = field(default_factory=dict)
    edges: List[ControlFlowEdge] = field(default_factory=list)
    entry_node_id: Optional[str] = None
    exit_node_ids: List[str] = field(default_factory=list)
    execution_paths: List[List[str]] = field(default_factory=list)
    has_loops: bool = False
    has_cursors: bool = False
    has_conditionals: bool = False
    dynamic_sql_nodes: List[str] = field(default_factory=list)

    def add_node(self, node: ControlFlowNode) -> None:
        """Add a node to the graph."""
        self.nodes[node.node_id] = node
        if node.node_type == ControlFlowNodeType.EXEC and node.is_dynamic_sql_related:
            self.dynamic_sql_nodes.append(node.node_id)

    def add_edge(self, edge: ControlFlowEdge) -> None:
        """Add an edge to the graph."""
        self.edges.append(edge)

    def get_node(self, node_id: str) -> Optional[ControlFlowNode]:
        """Get a node by ID."""
        return self.nodes.get(node_id)

    def get_predecessors(self, node_id: str) -> List[str]:
        """Get predecessor node IDs."""
        return [e.source_id for e in self.edges if e.target_id == node_id]

    def get_successors(self, node_id: str) -> List[str]:
        """Get successor node IDs."""
        return [e.target_id for e in self.edges if e.source_id == node_id]

    def to_dict(self) -> Dict[str, Any]:
        return {
            "procedure_name": self.procedure_name,
            "nodes": {k: v.to_dict() for k, v in self.nodes.items()},
            "edges": [e.to_dict() for e in self.edges],
            "entry_node_id": self.entry_node_id,
            "exit_node_ids": self.exit_node_ids,
            "execution_paths": self.execution_paths,
            "has_loops": self.has_loops,
            "has_cursors": self.has_cursors,
            "has_conditionals": self.has_conditionals,
            "dynamic_sql_nodes": self.dynamic_sql_nodes
        }


@dataclass
class ValidationResult:
    """Result of validating a reconstructed SQL statement."""
    statement_id: str
    is_valid: bool = True
    is_complete: bool = True
    syntax_error: Optional[str] = None
    completeness_score: float = 1.0
    issues: List[str] = field(default_factory=list)
    suggestions: List[str] = field(default_factory=list)
    parsed_statement_type: Optional[str] = None

    def to_dict(self) -> Dict[str, Any]:
        return {
            "statement_id": self.statement_id,
            "is_valid": self.is_valid,
            "is_complete": self.is_complete,
            "syntax_error": self.syntax_error,
            "completeness_score": self.completeness_score,
            "issues": self.issues,
            "suggestions": self.suggestions,
            "parsed_statement_type": self.parsed_statement_type
        }


@dataclass
class ConflictRecord:
    """Record of a conflict between expert outputs."""
    conflict_id: str
    conflict_type: DynamicSQLConflictType
    experts_involved: List[DynamicSQLExpertType]
    conflicting_values: Dict[str, Any]
    context: Dict[str, Any] = field(default_factory=dict)
    resolved_value: Optional[Any] = None
    resolution_strategy: Optional[str] = None
    resolution_notes: Optional[str] = None

    def to_dict(self) -> Dict[str, Any]:
        return {
            "conflict_id": self.conflict_id,
            "conflict_type": self.conflict_type.value,
            "experts_involved": [e.value for e in self.experts_involved],
            "conflicting_values": self.conflicting_values,
            "context": self.context,
            "resolved_value": str(self.resolved_value) if self.resolved_value else None,
            "resolution_strategy": self.resolution_strategy,
            "resolution_notes": self.resolution_notes
        }


@dataclass
class ProvenanceRecord:
    """Record of an expert's contribution to the final result."""
    expert_type: DynamicSQLExpertType
    expert_name: str
    contribution_type: str
    contributed_data: Dict[str, Any]
    confidence: float
    timestamp: datetime = field(default_factory=datetime.now)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "expert_type": self.expert_type.value,
            "expert_name": self.expert_name,
            "contribution_type": self.contribution_type,
            "contributed_data": {k: str(v)[:100] for k, v in self.contributed_data.items()},
            "confidence": self.confidence,
            "timestamp": self.timestamp.isoformat()
        }
