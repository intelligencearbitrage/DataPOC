"""
File Type Registry module.

Manages file type detection and handler registration for different SQL file types.
"""

from enum import Enum
from typing import Dict, List, Optional, Type, TYPE_CHECKING
from pathlib import Path
import re

if TYPE_CHECKING:
    from file_handlers.base_handler import BaseFileHandler


class FileType(Enum):
    """Enumeration of supported file types."""
    DDL = "DDL"           # Data Definition Language (CREATE TABLE)
    VIEW = "VIEW"         # View definitions (CREATE VIEW)
    SQL = "SQL"           # SQL statements (INSERT, SELECT, UPDATE, DELETE)
    PROCEDURE = "PROC"    # Stored procedures
    UNKNOWN = "UNKNOWN"   # Unknown file type


class FileTypeRegistry:
    """
    Registry for file type detection and handler management.

    Supports:
    - Extension-based detection (.ddl, .vw, .sql, .txt)
    - Content-based detection (CREATE TABLE, CREATE VIEW, INSERT, etc.)
    """

    # Extension to file type mapping
    EXTENSION_MAP = {
        '.ddl': FileType.DDL,
        '.vw': FileType.VIEW,
        '.view': FileType.VIEW,
        '.sql': FileType.SQL,
        '.txt': FileType.SQL,  # Default to SQL for .txt files
        '.proc': FileType.PROCEDURE,
        '.sp': FileType.PROCEDURE,
    }

    # Content patterns for detection
    CONTENT_PATTERNS = {
        FileType.DDL: [
            re.compile(r'^\s*CREATE\s+(OR\s+REPLACE\s+)?TABLE', re.IGNORECASE | re.MULTILINE),
            re.compile(r'^\s*CREATE\s+(MULTISET|SET)?\s*TABLE', re.IGNORECASE | re.MULTILINE),
            re.compile(r'^\s*ALTER\s+TABLE', re.IGNORECASE | re.MULTILINE),
            re.compile(r'^\s*DROP\s+TABLE', re.IGNORECASE | re.MULTILINE),
        ],
        FileType.VIEW: [
            re.compile(r'^\s*CREATE\s+(OR\s+REPLACE\s+)?VIEW', re.IGNORECASE | re.MULTILINE),
            re.compile(r'^\s*REPLACE\s+VIEW', re.IGNORECASE | re.MULTILINE),
        ],
        FileType.PROCEDURE: [
            re.compile(r'^\s*CREATE\s+(OR\s+REPLACE\s+)?PROCEDURE', re.IGNORECASE | re.MULTILINE),
            re.compile(r'^\s*CREATE\s+PROC', re.IGNORECASE | re.MULTILINE),
            re.compile(r'^\s*ALTER\s+PROCEDURE', re.IGNORECASE | re.MULTILINE),
        ],
        FileType.SQL: [
            re.compile(r'^\s*INSERT\s+INTO', re.IGNORECASE | re.MULTILINE),
            re.compile(r'^\s*SELECT\s+', re.IGNORECASE | re.MULTILINE),
            re.compile(r'^\s*UPDATE\s+', re.IGNORECASE | re.MULTILINE),
            re.compile(r'^\s*DELETE\s+', re.IGNORECASE | re.MULTILINE),
            re.compile(r'^\s*MERGE\s+', re.IGNORECASE | re.MULTILINE),
        ],
    }

    def __init__(self):
        """Initialize the registry."""
        self._handlers: Dict[FileType, Type['BaseFileHandler']] = {}

    def register_handler(self, file_type: FileType, handler_class: Type['BaseFileHandler']) -> None:
        """
        Register a handler for a file type.

        Args:
            file_type: The file type to register
            handler_class: The handler class to use
        """
        self._handlers[file_type] = handler_class

    def get_handler(self, file_type: FileType) -> Optional[Type['BaseFileHandler']]:
        """
        Get the handler for a file type.

        Args:
            file_type: The file type

        Returns:
            Handler class or None
        """
        return self._handlers.get(file_type)

    def detect_file_type(self, filepath: str, content: Optional[str] = None) -> FileType:
        """
        Detect the file type from path and optionally content.

        Args:
            filepath: Path to the file
            content: Optional file content for content-based detection

        Returns:
            Detected FileType
        """
        path = Path(filepath)
        extension = path.suffix.lower()

        # First try extension-based detection
        if extension in self.EXTENSION_MAP:
            ext_type = self.EXTENSION_MAP[extension]

            # For .sql and .txt files, use content detection if available
            if ext_type == FileType.SQL and content:
                content_type = self._detect_from_content(content)
                if content_type != FileType.UNKNOWN:
                    return content_type

            return ext_type

        # Fall back to content-based detection
        if content:
            return self._detect_from_content(content)

        # Try reading file for content detection
        try:
            with open(filepath, 'r', encoding='utf-8', errors='ignore') as f:
                content = f.read(4096)  # Read first 4KB for detection
            return self._detect_from_content(content)
        except Exception:
            pass

        return FileType.UNKNOWN

    def _detect_from_content(self, content: str) -> FileType:
        """
        Detect file type from content.

        Args:
            content: File content

        Returns:
            Detected FileType
        """
        # Check patterns in priority order
        for file_type in [FileType.DDL, FileType.VIEW, FileType.PROCEDURE, FileType.SQL]:
            patterns = self.CONTENT_PATTERNS.get(file_type, [])
            for pattern in patterns:
                if pattern.search(content):
                    return file_type

        return FileType.UNKNOWN

    def get_files_by_type(self, directory: str,
                          file_types: Optional[List[FileType]] = None,
                          patterns: Optional[List[str]] = None) -> Dict[FileType, List[str]]:
        """
        Get all files in a directory grouped by type.

        Args:
            directory: Directory to scan
            file_types: Optional filter for specific file types
            patterns: Optional glob patterns (default: *.ddl, *.vw, *.sql, *.txt)

        Returns:
            Dict mapping FileType to list of file paths
        """
        from pathlib import Path
        import glob

        if patterns is None:
            patterns = ['*.ddl', '*.vw', '*.view', '*.sql', '*.txt', '*.proc', '*.sp']

        result: Dict[FileType, List[str]] = {ft: [] for ft in FileType}

        dir_path = Path(directory)

        for pattern in patterns:
            for filepath in glob.glob(str(dir_path / '**' / pattern), recursive=True):
                file_type = self.detect_file_type(filepath)

                # Apply filter if specified
                if file_types is None or file_type in file_types:
                    result[file_type].append(filepath)

        return result

    def classify_files(self, filepaths: List[str]) -> Dict[FileType, List[str]]:
        """
        Classify a list of files by type.

        Args:
            filepaths: List of file paths

        Returns:
            Dict mapping FileType to list of file paths
        """
        result: Dict[FileType, List[str]] = {ft: [] for ft in FileType}

        for filepath in filepaths:
            file_type = self.detect_file_type(filepath)
            result[file_type].append(filepath)

        return result
