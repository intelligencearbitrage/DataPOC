"""
DDL File Handler module.

Handles Data Definition Language files (.ddl):
- CREATE TABLE statements
- ALTER TABLE statements
- DROP TABLE statements
"""

import sqlglot
from sqlglot import exp
from typing import List, Dict, Any, Optional
import sys
import os
import re

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from file_handlers.base_handler import (
    BaseFileHandler, FileProcessResult, TableSchema
)


class DDLHandler(BaseFileHandler):
    """
    Handler for DDL files containing table definitions.

    Extracts:
    - Table names and schemas
    - Column definitions with data types
    - Primary keys and constraints
    - Index definitions
    """

    def process_file(self, filepath: str) -> FileProcessResult:
        """
        Process a DDL file.

        Args:
            filepath: Path to the DDL file

        Returns:
            FileProcessResult with extracted table schemas
        """
        try:
            content = self.read_file(filepath)
            return self.process_content(content, filepath)
        except Exception as e:
            return FileProcessResult(
                filepath=filepath,
                file_type="DDL",
                success=False,
                errors=[f"Failed to read file: {str(e)}"]
            )

    def process_content(self, content: str, source_file: str = "") -> FileProcessResult:
        """
        Process DDL content.

        Args:
            content: DDL SQL content
            source_file: Source file name for reference

        Returns:
            FileProcessResult with extracted table schemas
        """
        result = FileProcessResult(
            filepath=source_file,
            file_type="DDL",
            success=True
        )

        try:
            # Parse all statements
            statements = sqlglot.parse(content, read=self.dialect)

            for stmt in statements:
                if stmt is None:
                    continue

                if isinstance(stmt, exp.Create):
                    table_schema = self._extract_table_schema(stmt, source_file)
                    if table_schema:
                        result.tables.append(table_schema)

                elif isinstance(stmt, exp.Alter):
                    # Handle ALTER TABLE to modify existing schema
                    self._handle_alter_table(stmt, result)

        except Exception as e:
            result.errors.append(f"Parse error: {str(e)}")
            # Try alternative parsing approach
            self._fallback_parse(content, source_file, result)

        return result

    def _extract_table_schema(self, stmt: exp.Create, source_file: str) -> Optional[TableSchema]:
        """
        Extract table schema from CREATE TABLE statement.

        Args:
            stmt: Parsed CREATE statement
            source_file: Source file name

        Returns:
            TableSchema or None
        """
        try:
            # Get table name
            table_expr = stmt.this
            if not isinstance(table_expr, exp.Table) and hasattr(table_expr, 'this'):
                table_expr = table_expr.this if isinstance(table_expr.this, exp.Table) else table_expr

            if not table_expr:
                return None

            table_name = table_expr.name if hasattr(table_expr, 'name') else str(table_expr)
            schema_name = table_expr.db if hasattr(table_expr, 'db') else None
            database_name = table_expr.catalog if hasattr(table_expr, 'catalog') else None

            # Extract columns
            columns = []
            column_defs = stmt.find_all(exp.ColumnDef)

            for col_def in column_defs:
                col_info = {
                    "name": col_def.name,
                    "data_type": self._extract_data_type(col_def),
                    "nullable": self._is_nullable(col_def),
                    "default": self._extract_default(col_def),
                }
                columns.append(col_info)

            # Extract primary key
            primary_key = self._extract_primary_key(stmt)

            return TableSchema(
                table_name=table_name,
                schema_name=schema_name,
                database_name=database_name,
                columns=columns,
                primary_key=primary_key,
                source_file=source_file,
                ddl_sql=stmt.sql(dialect=self.dialect)
            )

        except Exception as e:
            return None

    def _extract_data_type(self, col_def: exp.ColumnDef) -> str:
        """Extract data type from column definition."""
        try:
            if hasattr(col_def, 'args') and 'kind' in col_def.args:
                kind = col_def.args['kind']
                if kind:
                    return kind.sql(dialect=self.dialect)
            return "UNKNOWN"
        except Exception:
            return "UNKNOWN"

    def _is_nullable(self, col_def: exp.ColumnDef) -> bool:
        """Check if column is nullable."""
        try:
            constraints = col_def.find_all(exp.ColumnConstraint)
            for constraint in constraints:
                if isinstance(constraint.kind, exp.NotNullColumnConstraint):
                    return False
            return True
        except Exception:
            return True

    def _extract_default(self, col_def: exp.ColumnDef) -> Optional[str]:
        """Extract default value from column definition."""
        try:
            for constraint in col_def.find_all(exp.ColumnConstraint):
                if hasattr(constraint, 'kind') and isinstance(constraint.kind, exp.DefaultColumnConstraint):
                    if hasattr(constraint.kind, 'this'):
                        return constraint.kind.this.sql(dialect=self.dialect)
            return None
        except Exception:
            return None

    def _extract_primary_key(self, stmt: exp.Create) -> List[str]:
        """Extract primary key columns from CREATE TABLE."""
        pk_columns = []
        try:
            # Look for PRIMARY KEY constraint
            for constraint in stmt.find_all(exp.PrimaryKey):
                for col in constraint.expressions:
                    if isinstance(col, exp.Column):
                        pk_columns.append(col.name)
                    elif hasattr(col, 'name'):
                        pk_columns.append(col.name)
        except Exception:
            pass
        return pk_columns

    def _handle_alter_table(self, stmt: exp.Alter, result: FileProcessResult) -> None:
        """Handle ALTER TABLE statement."""
        result.warnings.append(f"ALTER TABLE found - schema modification not fully supported")

    def _fallback_parse(self, content: str, source_file: str, result: FileProcessResult) -> None:
        """
        Fallback parsing using regex for Teradata-specific syntax.

        Args:
            content: DDL content
            source_file: Source file name
            result: Result to update
        """
        # Regex pattern for CREATE TABLE
        create_pattern = re.compile(
            r'CREATE\s+(?:MULTISET\s+|SET\s+)?TABLE\s+([^\s(]+)\s*\((.*?)\)',
            re.IGNORECASE | re.DOTALL
        )

        for match in create_pattern.finditer(content):
            table_name = match.group(1).strip()
            columns_str = match.group(2)

            # Parse column definitions
            columns = []
            # Simple column parsing - split by comma outside parentheses
            col_defs = self._split_column_definitions(columns_str)

            for col_def in col_defs:
                col_def = col_def.strip()
                if not col_def or col_def.upper().startswith('PRIMARY KEY') or col_def.upper().startswith('CONSTRAINT'):
                    continue

                parts = col_def.split()
                if parts:
                    col_name = parts[0].strip('[]"\'')
                    col_type = parts[1] if len(parts) > 1 else "UNKNOWN"
                    columns.append({
                        "name": col_name,
                        "data_type": col_type,
                        "nullable": 'NOT NULL' not in col_def.upper(),
                        "default": None
                    })

            if columns:
                # Parse table name components
                name_parts = table_name.replace('[', '').replace(']', '').replace('"', '').split('.')
                tbl_name = name_parts[-1]
                schema_name = name_parts[-2] if len(name_parts) > 1 else None
                db_name = name_parts[-3] if len(name_parts) > 2 else None

                schema = TableSchema(
                    table_name=tbl_name,
                    schema_name=schema_name,
                    database_name=db_name,
                    columns=columns,
                    source_file=source_file,
                    ddl_sql=match.group(0)
                )
                result.tables.append(schema)

    def _split_column_definitions(self, columns_str: str) -> List[str]:
        """Split column definitions, respecting parentheses."""
        columns = []
        current = []
        paren_depth = 0

        for char in columns_str:
            if char == '(':
                paren_depth += 1
                current.append(char)
            elif char == ')':
                paren_depth -= 1
                current.append(char)
            elif char == ',' and paren_depth == 0:
                columns.append(''.join(current))
                current = []
            else:
                current.append(char)

        if current:
            columns.append(''.join(current))

        return columns
