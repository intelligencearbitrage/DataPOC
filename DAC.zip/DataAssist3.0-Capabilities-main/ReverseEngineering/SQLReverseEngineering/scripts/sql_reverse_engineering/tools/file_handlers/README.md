# File Handlers

## Overview
The File Handlers module provides specialized handlers for different SQL file types including DDL, DML, views, and stored procedures. It supports batch processing and multi-file analysis.

## Components

### `base_handler.py`
Abstract base class for all file type handlers.

**Provides:**
- Standard file handler interface
- Common file I/O operations
- Error handling framework
- File metadata extraction

**Base Classes:**

#### `TableSchema`
Schema information for a table.

**Fields:**
- `table_name` - Table name
- `schema_name` - Schema name
- `database_name` - Database name
- `columns` - List of columns with types
- `primary_key` - Primary key columns
- `indexes` - Index definitions
- `source_file` - Source DDL file

#### `ViewDefinition`
View definition information.

**Fields:**
- `view_name` - View name
- `view_sql` - View definition SQL
- `schema_name` - Schema name
- `columns` - View columns
- `dependencies` - Tables/views used

#### `BaseFileHandler`
Abstract handler for file types.

**Methods:**
- `can_handle()` - Check if handler can process file
- `parse()` - Parse file contents
- `extract_metadata()` - Extract file metadata
- `validate()` - Validate file content

### `ddl_handler.py`
Handler for DDL (Data Definition Language) files.

**Handles:**
- CREATE TABLE statements
- ALTER TABLE statements
- CREATE INDEX statements
- DROP statements
- Table constraints

**Extraction Capabilities:**
- Table definitions
- Column definitions with data types
- Primary keys
- Foreign keys
- Indexes
- Constraints

**Output:**
```python
{
    "tables": [
        {
            "table_name": "customers",
            "columns": [
                {"name": "id", "type": "INT", "nullable": False},
                {"name": "name", "type": "VARCHAR(100)", "nullable": True}
            ],
            "primary_key": ["id"],
            "indexes": [...]
        }
    ]
}
```

### `sql_handler.py`
Handler for SQL query files (DML).

**Handles:**
- SELECT statements
- INSERT statements
- UPDATE statements
- DELETE statements
- MERGE statements

**Extraction Capabilities:**
- Query structure
- Source tables
- Target tables
- Column usage
- Filters and joins

**Output:**
```python
{
    "statements": [...],
    "tables_read": ["customers", "orders"],
    "tables_written": ["fact_sales"],
    "columns_used": [...]
}
```

### `view_handler.py`
Handler for view definition files.

**Handles:**
- CREATE VIEW statements
- CREATE OR REPLACE VIEW statements
- Materialized views

**Extraction Capabilities:**
- View definition SQL
- View dependencies
- Column list
- View metadata

**Output:**
```python
{
    "views": [
        {
            "view_name": "vw_active_customers",
            "definition": "SELECT ...",
            "dependencies": ["customers", "orders"],
            "columns": ["customer_id", "customer_name"]
        }
    ]
}
```

### `file_type_registry.py`
Registry for mapping file types to handlers.

**Responsibilities:**
- Detect file type from extension/content
- Route files to appropriate handlers
- Manage handler instances
- Support custom handlers

**Supported File Types:**
- `.sql` - Generic SQL files
- `.ddl` - DDL files
- `.dml` - DML files
- `.view` - View definitions
- `.proc` - Stored procedures
- `.prc` - Stored procedures

**Usage:**
```python
from file_handlers.file_type_registry import FileTypeRegistry

registry = FileTypeRegistry()
handler = registry.get_handler("schema.ddl")
result = handler.parse("schema.ddl")
```

### `multi_file_processor.py`
Batch processor for multiple files.

**Capabilities:**
- Process entire directories
- Handle multiple file types
- Cross-file dependency resolution
- Schema building from DDL files
- End-to-end lineage across files

**Features:**
- Parallel file processing
- Dependency graph building
- Schema catalog generation
- Cross-file lineage stitching
- Progress tracking
- Error aggregation

**Workflow:**
1. Scan directory for SQL files
2. Classify files by type
3. Parse DDL files first (for schema)
4. Parse other files with schema context
5. Build cross-file dependencies
6. Generate comprehensive lineage

**Usage:**
```python
from file_handlers.multi_file_processor import MultiFileProcessor

processor = MultiFileProcessor(
    directory="sql_files/",
    dialect="teradata"
)

results = processor.process_all()

# Access results
schemas = results["schemas"]
lineage = results["lineage"]
dependencies = results["dependencies"]
```

## File Processing Workflow

```
┌─────────────────────────────────────────────────────┐
│         MultiFileProcessor.process_all()            │
└──────────────────────┬──────────────────────────────┘
                       │
                       ▼
┌─────────────────────────────────────────────────────┐
│  Step 1: Scan Directory and Classify Files         │
│  ├─ DDL files (.ddl)                                │
│  ├─ SQL files (.sql)                                │
│  ├─ View files (.view)                              │
│  └─ Procedure files (.proc)                         │
└──────────────────────┬──────────────────────────────┘
                       │
                       ▼
┌─────────────────────────────────────────────────────┐
│  Step 2: Process DDL Files (Build Schema)          │
│  └─ Create TableSchema objects                      │
└──────────────────────┬──────────────────────────────┘
                       │
                       ▼
┌─────────────────────────────────────────────────────┐
│  Step 3: Process SQL Files (Extract Lineage)       │
│  └─ Use schema context for accurate lineage         │
└──────────────────────┬──────────────────────────────┘
                       │
                       ▼
┌─────────────────────────────────────────────────────┐
│  Step 4: Process Views                              │
│  └─ Expand view definitions                         │
└──────────────────────┬──────────────────────────────┘
                       │
                       ▼
┌─────────────────────────────────────────────────────┐
│  Step 5: Build Cross-File Dependencies              │
│  └─ Stitch lineage across files                     │
└──────────────────────┬──────────────────────────────┘
                       │
                       ▼
┌─────────────────────────────────────────────────────┐
│  Return Comprehensive Results                       │
└─────────────────────────────────────────────────────┘
```

## Usage Example

```python
from file_handlers.multi_file_processor import MultiFileProcessor

# Process entire directory
processor = MultiFileProcessor(
    directory="etl_scripts/",
    dialect="teradata",
    recursive=True
)

results = processor.process_all()

# Access results
print(f"Tables found: {len(results['schemas'])}")
print(f"Views found: {len(results['views'])}")
print(f"Lineage edges: {len(results['lineage'].edges)}")
print(f"Dependencies: {len(results['dependencies'])}")

# Generate documentation
processor.generate_documentation("output/")
```

## Supported File Types

| Extension | Handler | Description |
|-----------|---------|-------------|
| `.ddl` | DDLHandler | Table definitions |
| `.sql` | SQLHandler | SQL queries |
| `.view` | ViewHandler | View definitions |
| `.proc`, `.prc` | ProcedureHandler | Stored procedures |

## Integration Points
- Inputs: SQL files of various types
- Outputs: TableSchema, ViewDefinition, lineage graphs
- Used by: CLI, API, batch processors
- Uses: ast_generator, lineage, schema modules
