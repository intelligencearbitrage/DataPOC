"""
Base File Handler module.

Abstract base class for all file type handlers.
"""

from abc import ABC, abstractmethod
from typing import Dict, List, Any, Optional
from dataclasses import dataclass, field
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))


@dataclass
class TableSchema:
    """Schema information for a table."""
    table_name: str
    schema_name: Optional[str] = None
    database_name: Optional[str] = None
    columns: List[Dict[str, Any]] = field(default_factory=list)
    primary_key: List[str] = field(default_factory=list)
    indexes: List[Dict[str, Any]] = field(default_factory=list)
    source_file: str = ""
    ddl_sql: str = ""

    def to_dict(self) -> Dict[str, Any]:
        return {
            "table_name": self.table_name,
            "schema_name": self.schema_name,
            "database_name": self.database_name,
            "columns": self.columns,
            "primary_key": self.primary_key,
            "indexes": self.indexes,
            "source_file": self.source_file,
        }

    def get_column_names(self) -> List[str]:
        """Get list of column names."""
        return [col.get('name', '') for col in self.columns]

    def qualified_name(self) -> str:
        """Get fully qualified table name."""
        parts = [p for p in [self.database_name, self.schema_name, self.table_name] if p]
        return ".".join(parts)


@dataclass
class ViewDefinition:
    """Definition of a SQL view."""
    view_name: str
    schema_name: Optional[str] = None
    database_name: Optional[str] = None
    select_sql: str = ""
    columns: List[str] = field(default_factory=list)
    source_tables: List[str] = field(default_factory=list)
    source_file: str = ""
    full_sql: str = ""
    ast: Any = None  # SQLGlot AST

    def to_dict(self) -> Dict[str, Any]:
        return {
            "view_name": self.view_name,
            "schema_name": self.schema_name,
            "database_name": self.database_name,
            "select_sql": self.select_sql,
            "columns": self.columns,
            "source_tables": self.source_tables,
            "source_file": self.source_file,
        }

    def qualified_name(self) -> str:
        """Get fully qualified view name."""
        parts = [p for p in [self.database_name, self.schema_name, self.view_name] if p]
        return ".".join(parts)


@dataclass
class SQLStatement:
    """Parsed SQL statement."""
    statement_id: str
    statement_type: str  # INSERT, SELECT, UPDATE, DELETE, MERGE
    target_table: Optional[str] = None
    source_tables: List[str] = field(default_factory=list)
    source_file: str = ""
    raw_sql: str = ""
    ast: Any = None  # SQLGlot AST
    elements: Any = None  # ElementCatalog
    lineage: Any = None  # LineageGraph

    def to_dict(self) -> Dict[str, Any]:
        return {
            "statement_id": self.statement_id,
            "statement_type": self.statement_type,
            "target_table": self.target_table,
            "source_tables": self.source_tables,
            "source_file": self.source_file,
            "raw_sql": self.raw_sql[:500] + "..." if len(self.raw_sql) > 500 else self.raw_sql,
        }


@dataclass
class FileProcessResult:
    """Result of processing a file."""
    filepath: str
    file_type: str
    success: bool
    tables: List[TableSchema] = field(default_factory=list)
    views: List[ViewDefinition] = field(default_factory=list)
    statements: List[SQLStatement] = field(default_factory=list)
    errors: List[str] = field(default_factory=list)
    warnings: List[str] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "filepath": self.filepath,
            "file_type": self.file_type,
            "success": self.success,
            "tables": [t.to_dict() for t in self.tables],
            "views": [v.to_dict() for v in self.views],
            "statements": [s.to_dict() for s in self.statements],
            "errors": self.errors,
            "warnings": self.warnings,
        }


class BaseFileHandler(ABC):
    """
    Abstract base class for file handlers.

    Each handler processes a specific type of SQL file and extracts
    relevant information for AST storage and lineage analysis.
    """

    def __init__(self, dialect: str = "teradata"):
        """
        Initialize the handler.

        Args:
            dialect: SQL dialect for parsing
        """
        self.dialect = dialect

    @abstractmethod
    def process_file(self, filepath: str) -> FileProcessResult:
        """
        Process a file and extract relevant information.

        Args:
            filepath: Path to the file

        Returns:
            FileProcessResult with extracted information
        """
        pass

    @abstractmethod
    def process_content(self, content: str, source_file: str = "") -> FileProcessResult:
        """
        Process SQL content directly.

        Args:
            content: SQL content
            source_file: Optional source file name for reference

        Returns:
            FileProcessResult with extracted information
        """
        pass

    def read_file(self, filepath: str) -> str:
        """
        Read file content with error handling.

        Args:
            filepath: Path to the file

        Returns:
            File content as string
        """
        with open(filepath, 'r', encoding='utf-8', errors='ignore') as f:
            return f.read()
