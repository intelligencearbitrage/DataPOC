"""
Multi-File Processor module.

Orchestrates processing of multiple SQL files of different types,
building a unified AST store and schema registry.
"""

import os
import sys
from typing import Dict, List, Optional, Any
from dataclasses import dataclass, field
import json

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from file_handlers.file_type_registry import FileTypeRegistry, FileType
from file_handlers.ddl_handler import DDLHandler
from file_handlers.view_handler import ViewHandler
from file_handlers.sql_handler import SQLHandler
from file_handlers.base_handler import (
    FileProcessResult, TableSchema, ViewDefinition, SQLStatement
)


@dataclass
class ASTRepository:
    """
    Central repository for all parsed AST information.

    Stores:
    - Table schemas from DDL files
    - View definitions from view files
    - SQL statements with lineage from SQL files
    """
    tables: Dict[str, TableSchema] = field(default_factory=dict)
    views: Dict[str, ViewDefinition] = field(default_factory=dict)
    statements: List[SQLStatement] = field(default_factory=list)
    file_results: List[FileProcessResult] = field(default_factory=list)

    def add_table(self, table: TableSchema) -> None:
        """Add a table schema to the repository."""
        key = table.qualified_name().upper()
        self.tables[key] = table

    def add_view(self, view: ViewDefinition) -> None:
        """Add a view definition to the repository."""
        key = view.qualified_name().upper()
        self.views[key] = view

    def add_statement(self, statement: SQLStatement) -> None:
        """Add a SQL statement to the repository."""
        self.statements.append(statement)

    def get_table(self, name: str) -> Optional[TableSchema]:
        """Get table schema by name (case-insensitive)."""
        return self.tables.get(name.upper())

    def get_view(self, name: str) -> Optional[ViewDefinition]:
        """Get view definition by name (case-insensitive)."""
        return self.views.get(name.upper())

    def get_table_or_view(self, name: str) -> Optional[Any]:
        """Get table or view by name."""
        result = self.get_table(name)
        if result:
            return result
        return self.get_view(name)

    def get_columns_for_table(self, table_name: str) -> List[str]:
        """Get column names for a table or view."""
        table = self.get_table(table_name)
        if table:
            return table.get_column_names()

        view = self.get_view(table_name)
        if view:
            return view.columns

        return []

    def build_schema_dict(self) -> Dict[str, List[str]]:
        """Build schema dict in SQLGlot format {table: [columns]}."""
        schema = {}

        for key, table in self.tables.items():
            schema[table.table_name] = table.get_column_names()
            # Also add with qualified name
            if table.qualified_name() != table.table_name:
                schema[table.qualified_name()] = table.get_column_names()

        for key, view in self.views.items():
            schema[view.view_name] = view.columns
            # Also add with qualified name
            if view.qualified_name() != view.view_name:
                schema[view.qualified_name()] = view.columns

        return schema

    def get_statements_for_target(self, target_table: str) -> List[SQLStatement]:
        """Get all statements that write to a specific target table."""
        target_upper = target_table.upper()
        return [
            stmt for stmt in self.statements
            if stmt.target_table and stmt.target_table.upper() == target_upper
        ]

    def get_statements_using_source(self, source_table: str) -> List[SQLStatement]:
        """Get all statements that read from a specific source table."""
        source_upper = source_table.upper()
        return [
            stmt for stmt in self.statements
            if any(s.upper() == source_upper for s in stmt.source_tables)
        ]

    def to_dict(self) -> Dict[str, Any]:
        """Export repository to dictionary."""
        return {
            "tables": {k: v.to_dict() for k, v in self.tables.items()},
            "views": {k: v.to_dict() for k, v in self.views.items()},
            "statements": [s.to_dict() for s in self.statements],
            "statistics": {
                "table_count": len(self.tables),
                "view_count": len(self.views),
                "statement_count": len(self.statements),
                "file_count": len(self.file_results)
            }
        }

    def save_to_json(self, filepath: str) -> None:
        """Save repository to JSON file."""
        with open(filepath, 'w', encoding='utf-8') as f:
            json.dump(self.to_dict(), f, indent=2)


class MultiFileProcessor:
    """
    Processor for handling multiple SQL files of different types.

    Usage:
        processor = MultiFileProcessor(dialect="teradata")
        repository = processor.process_directory("./input_files")

        # Access parsed information
        schema = repository.build_schema_dict()
        statements = repository.statements
    """

    def __init__(self, dialect: str = "teradata"):
        """
        Initialize the processor.

        Args:
            dialect: SQL dialect for parsing
        """
        self.dialect = dialect
        self.registry = FileTypeRegistry()
        self.repository = ASTRepository()

        # Initialize handlers
        self._handlers = {
            FileType.DDL: DDLHandler(dialect),
            FileType.VIEW: ViewHandler(dialect),
            FileType.SQL: SQLHandler(dialect),
            FileType.PROCEDURE: SQLHandler(dialect),  # Procedures handled as SQL
        }

    def process_directory(self, directory: str,
                          patterns: Optional[List[str]] = None,
                          process_order: Optional[List[FileType]] = None) -> ASTRepository:
        """
        Process all SQL files in a directory.

        Files are processed in order: DDL -> Views -> SQL
        This ensures schema information is available when processing SQL.

        Args:
            directory: Directory path
            patterns: File patterns to match (default: *.ddl, *.vw, *.sql, *.txt)
            process_order: Order to process file types (default: DDL, VIEW, SQL)

        Returns:
            ASTRepository with all parsed information
        """
        if process_order is None:
            process_order = [FileType.DDL, FileType.VIEW, FileType.SQL, FileType.PROCEDURE]

        # Reset repository
        self.repository = ASTRepository()

        # Classify files by type
        files_by_type = self.registry.get_files_by_type(directory, patterns=patterns)

        # Process files in specified order
        for file_type in process_order:
            files = files_by_type.get(file_type, [])
            for filepath in files:
                print(f"Processing [{file_type.value}]: {os.path.basename(filepath)}")
                self._process_file(filepath, file_type)

        # Update SQL handler with schema from DDL/Views
        schema = self.repository.build_schema_dict()
        if FileType.SQL in self._handlers:
            self._handlers[FileType.SQL].schema = schema

        return self.repository

    def process_files(self, filepaths: List[str]) -> ASTRepository:
        """
        Process a list of files.

        Files are automatically classified and processed in correct order.

        Args:
            filepaths: List of file paths

        Returns:
            ASTRepository with all parsed information
        """
        # Reset repository
        self.repository = ASTRepository()

        # Classify files
        files_by_type = self.registry.classify_files(filepaths)

        # Process in order: DDL -> Views -> SQL
        process_order = [FileType.DDL, FileType.VIEW, FileType.SQL, FileType.PROCEDURE]

        for file_type in process_order:
            files = files_by_type.get(file_type, [])
            for filepath in files:
                print(f"Processing [{file_type.value}]: {os.path.basename(filepath)}")
                self._process_file(filepath, file_type)

        return self.repository

    def process_file(self, filepath: str) -> FileProcessResult:
        """
        Process a single file.

        Args:
            filepath: Path to the file

        Returns:
            FileProcessResult
        """
        file_type = self.registry.detect_file_type(filepath)
        return self._process_file(filepath, file_type)

    def _process_file(self, filepath: str, file_type: FileType) -> FileProcessResult:
        """
        Internal method to process a file with known type.

        Args:
            filepath: Path to the file
            file_type: Detected file type

        Returns:
            FileProcessResult
        """
        handler = self._handlers.get(file_type)

        if not handler:
            result = FileProcessResult(
                filepath=filepath,
                file_type=file_type.value,
                success=False,
                errors=[f"No handler for file type: {file_type.value}"]
            )
            self.repository.file_results.append(result)
            return result

        # For SQL files, update schema with latest DDL/View info
        if file_type in (FileType.SQL, FileType.PROCEDURE):
            handler.schema = self.repository.build_schema_dict()

        # Process the file
        result = handler.process_file(filepath)

        # Add results to repository
        for table in result.tables:
            self.repository.add_table(table)

        for view in result.views:
            self.repository.add_view(view)

        for statement in result.statements:
            self.repository.add_statement(statement)

        self.repository.file_results.append(result)

        return result

    def get_processing_summary(self) -> Dict[str, Any]:
        """
        Get summary of processing results.

        Returns:
            Summary dictionary
        """
        success_count = sum(1 for r in self.repository.file_results if r.success)
        failed_count = len(self.repository.file_results) - success_count

        all_errors = []
        all_warnings = []

        for result in self.repository.file_results:
            for error in result.errors:
                all_errors.append(f"{result.filepath}: {error}")
            for warning in result.warnings:
                all_warnings.append(f"{result.filepath}: {warning}")

        return {
            "total_files": len(self.repository.file_results),
            "successful": success_count,
            "failed": failed_count,
            "tables_found": len(self.repository.tables),
            "views_found": len(self.repository.views),
            "statements_found": len(self.repository.statements),
            "errors": all_errors,
            "warnings": all_warnings
        }

    def print_summary(self) -> None:
        """Print processing summary to console."""
        summary = self.get_processing_summary()

        print("\n" + "=" * 60)
        print("MULTI-FILE PROCESSING SUMMARY")
        print("=" * 60)
        print(f"Total files processed: {summary['total_files']}")
        print(f"  Successful: {summary['successful']}")
        print(f"  Failed: {summary['failed']}")
        print(f"\nParsed objects:")
        print(f"  Tables (DDL): {summary['tables_found']}")
        print(f"  Views: {summary['views_found']}")
        print(f"  SQL Statements: {summary['statements_found']}")

        if summary['errors']:
            print(f"\nErrors ({len(summary['errors'])}):")
            for error in summary['errors'][:5]:
                print(f"  - {error}")
            if len(summary['errors']) > 5:
                print(f"  ... and {len(summary['errors']) - 5} more")

        if summary['warnings']:
            print(f"\nWarnings ({len(summary['warnings'])}):")
            for warning in summary['warnings'][:5]:
                print(f"  - {warning}")
            if len(summary['warnings']) > 5:
                print(f"  ... and {len(summary['warnings']) - 5} more")

        print("=" * 60)
