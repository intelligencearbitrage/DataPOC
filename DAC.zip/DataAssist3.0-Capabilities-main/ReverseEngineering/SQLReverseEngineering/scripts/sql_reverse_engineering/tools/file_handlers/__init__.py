"""
File Handlers module.

Provides handlers for different SQL file types:
- .ddl files: Data Definition Language (CREATE TABLE, etc.)
- .vw files: View definitions (CREATE VIEW)
- .sql files: SQL statements (INSERT, SELECT, etc.)
"""

from .file_type_registry import FileTypeRegistry, FileType
from .ddl_handler import DDLHandler
from .view_handler import ViewHandler
from .sql_handler import SQLHandler
from .multi_file_processor import MultiFileProcessor

__all__ = [
    'FileTypeRegistry',
    'FileType',
    'DDLHandler',
    'ViewHandler',
    'SQLHandler',
    'MultiFileProcessor'
]
