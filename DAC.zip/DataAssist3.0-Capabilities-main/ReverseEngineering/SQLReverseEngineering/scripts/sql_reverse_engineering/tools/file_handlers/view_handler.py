"""
View File Handler module.

Handles View definition files (.vw):
- CREATE VIEW statements
- REPLACE VIEW statements
"""

import sqlglot
from sqlglot import exp
from typing import List, Optional
import sys
import os
import re

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from file_handlers.base_handler import (
    BaseFileHandler, FileProcessResult, ViewDefinition
)


class ViewHandler(BaseFileHandler):
    """
    Handler for View definition files.

    Extracts:
    - View names and schemas
    - SELECT statement definition
    - Output column names
    - Source tables referenced
    """

    def process_file(self, filepath: str) -> FileProcessResult:
        """
        Process a view definition file.

        Args:
            filepath: Path to the view file

        Returns:
            FileProcessResult with extracted view definitions
        """
        try:
            content = self.read_file(filepath)
            return self.process_content(content, filepath)
        except Exception as e:
            return FileProcessResult(
                filepath=filepath,
                file_type="VIEW",
                success=False,
                errors=[f"Failed to read file: {str(e)}"]
            )

    def process_content(self, content: str, source_file: str = "") -> FileProcessResult:
        """
        Process view definition content.

        Args:
            content: View SQL content
            source_file: Source file name for reference

        Returns:
            FileProcessResult with extracted view definitions
        """
        result = FileProcessResult(
            filepath=source_file,
            file_type="VIEW",
            success=True
        )

        try:
            # Parse all statements
            statements = sqlglot.parse(content, read=self.dialect)

            for stmt in statements:
                if stmt is None:
                    continue

                if isinstance(stmt, exp.Create):
                    view_def = self._extract_view_definition(stmt, source_file)
                    if view_def:
                        result.views.append(view_def)

        except Exception as e:
            result.errors.append(f"Parse error: {str(e)}")
            # Try fallback parsing
            self._fallback_parse(content, source_file, result)

        return result

    def _extract_view_definition(self, stmt: exp.Create, source_file: str) -> Optional[ViewDefinition]:
        """
        Extract view definition from CREATE VIEW statement.

        Args:
            stmt: Parsed CREATE statement
            source_file: Source file name

        Returns:
            ViewDefinition or None
        """
        try:
            # Check if this is a view creation
            # SQLGlot uses exp.Create for both tables and views

            # Get view name
            view_expr = stmt.this
            if not view_expr:
                return None

            # Extract view name
            if isinstance(view_expr, exp.Table):
                view_name = view_expr.name
                schema_name = view_expr.db if hasattr(view_expr, 'db') else None
                database_name = view_expr.catalog if hasattr(view_expr, 'catalog') else None
            else:
                view_name = str(view_expr)
                schema_name = None
                database_name = None

            # Get the SELECT statement
            select_stmt = stmt.find(exp.Select)
            if not select_stmt:
                # This might be a table, not a view
                return None

            select_sql = select_stmt.sql(dialect=self.dialect)

            # Extract output columns
            columns = self._extract_view_columns(select_stmt)

            # Extract source tables
            source_tables = self._extract_source_tables(select_stmt)

            return ViewDefinition(
                view_name=view_name,
                schema_name=schema_name,
                database_name=database_name,
                select_sql=select_sql,
                columns=columns,
                source_tables=source_tables,
                source_file=source_file,
                full_sql=stmt.sql(dialect=self.dialect),
                ast=stmt
            )

        except Exception as e:
            return None

    def _extract_view_columns(self, select_stmt: exp.Select) -> List[str]:
        """Extract column names from SELECT statement."""
        columns = []

        if not hasattr(select_stmt, 'expressions'):
            return columns

        for i, expr in enumerate(select_stmt.expressions):
            if isinstance(expr, exp.Alias):
                columns.append(expr.alias)
            elif isinstance(expr, exp.Column):
                columns.append(expr.name)
            elif isinstance(expr, exp.Star):
                columns.append("*")
            else:
                columns.append(f"col_{i+1}")

        return columns

    def _extract_source_tables(self, select_stmt: exp.Select) -> List[str]:
        """Extract all source tables from SELECT statement."""
        tables = set()

        for table in select_stmt.find_all(exp.Table):
            name = table.name
            if hasattr(table, 'db') and table.db:
                name = f"{table.db}.{name}"
            tables.add(name)

        return list(tables)

    def _fallback_parse(self, content: str, source_file: str, result: FileProcessResult) -> None:
        """
        Fallback parsing using regex for Teradata/Oracle-specific syntax.

        Args:
            content: View content
            source_file: Source file name
            result: Result to update
        """
        # Pattern for CREATE VIEW or REPLACE VIEW
        view_pattern = re.compile(
            r'(?:CREATE\s+(?:OR\s+REPLACE\s+)?VIEW|REPLACE\s+VIEW)\s+([^\s(]+)\s*(?:\([^)]*\))?\s*AS\s+(SELECT\s+.*?)(?=;|\Z)',
            re.IGNORECASE | re.DOTALL
        )

        for match in view_pattern.finditer(content):
            view_name = match.group(1).strip()
            select_sql = match.group(2).strip()

            # Parse view name components
            name_parts = view_name.replace('[', '').replace(']', '').replace('"', '').split('.')
            v_name = name_parts[-1]
            schema_name = name_parts[-2] if len(name_parts) > 1 else None
            db_name = name_parts[-3] if len(name_parts) > 2 else None

            # Extract source tables using simple regex
            source_tables = self._extract_tables_regex(select_sql)

            # Extract columns using simple regex
            columns = self._extract_columns_regex(select_sql)

            view_def = ViewDefinition(
                view_name=v_name,
                schema_name=schema_name,
                database_name=db_name,
                select_sql=select_sql,
                columns=columns,
                source_tables=source_tables,
                source_file=source_file,
                full_sql=match.group(0)
            )
            result.views.append(view_def)

    def _extract_tables_regex(self, sql: str) -> List[str]:
        """Extract table names using regex."""
        tables = set()

        # FROM clause tables
        from_pattern = re.compile(r'\bFROM\s+([^\s,;(]+)', re.IGNORECASE)
        for match in from_pattern.finditer(sql):
            table = match.group(1).strip()
            if table.upper() not in ('SELECT', 'WHERE', 'AND', 'OR'):
                tables.add(table)

        # JOIN clause tables
        join_pattern = re.compile(r'\bJOIN\s+([^\s;(]+)', re.IGNORECASE)
        for match in join_pattern.finditer(sql):
            table = match.group(1).strip()
            if table.upper() not in ('SELECT', 'WHERE', 'AND', 'OR'):
                tables.add(table)

        return list(tables)

    def _extract_columns_regex(self, sql: str) -> List[str]:
        """Extract column names using regex (from SELECT clause)."""
        columns = []

        # Find SELECT clause
        select_match = re.match(r'SELECT\s+(.*?)\s+FROM', sql, re.IGNORECASE | re.DOTALL)
        if select_match:
            select_clause = select_match.group(1)

            # Split by comma (outside parentheses)
            col_parts = self._split_outside_parens(select_clause, ',')

            for part in col_parts:
                part = part.strip()
                if not part:
                    continue

                # Check for AS alias
                as_match = re.search(r'\bAS\s+(\w+)\s*$', part, re.IGNORECASE)
                if as_match:
                    columns.append(as_match.group(1))
                else:
                    # Use last word as column name
                    words = part.split()
                    if words:
                        col_name = words[-1].strip('[]"\'')
                        columns.append(col_name)

        return columns

    def _split_outside_parens(self, text: str, delimiter: str) -> List[str]:
        """Split text by delimiter, ignoring delimiters inside parentheses."""
        parts = []
        current = []
        paren_depth = 0

        for char in text:
            if char == '(':
                paren_depth += 1
                current.append(char)
            elif char == ')':
                paren_depth -= 1
                current.append(char)
            elif char == delimiter and paren_depth == 0:
                parts.append(''.join(current))
                current = []
            else:
                current.append(char)

        if current:
            parts.append(''.join(current))

        return parts
