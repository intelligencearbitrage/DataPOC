"""
SQL File Handler module.

Handles SQL files containing DML statements:
- INSERT statements
- SELECT statements
- UPDATE statements
- DELETE statements
- MERGE statements
- Stored procedures (extracts INSERT/SELECT statements from within)
"""

import sqlglot
from sqlglot import exp
from typing import List, Optional
import sys
import os
import uuid
import re

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from file_handlers.base_handler import (
    BaseFileHandler, FileProcessResult, SQLStatement
)
from ast_generator.parser import SQLASTGenerator
from deconstructor.element_extractor import SQLElementExtractor
from lineage.lineage_extractor import LineageExtractor
from lineage.lineage_graph import LineageGraph
from models.data_models import ColumnRef, TransformationInfo, TransformationType, TransformationSubtype
from ast_generator.stored_procedure_handler import StoredProcedureHandler


class SQLHandler(BaseFileHandler):
    """
    Handler for SQL files containing DML statements.

    Extracts:
    - SQL statements with AST
    - Target and source tables
    - Element catalogs (CASE, JOINs, functions)
    - Lineage graphs
    """

    def __init__(self, dialect: str = "teradata", schema: dict = None):
        """
        Initialize the handler.

        Args:
            dialect: SQL dialect for parsing
            schema: Optional schema dict for lineage extraction
        """
        super().__init__(dialect)
        self.schema = schema or {}
        self.parser = SQLASTGenerator(dialect=dialect)
        self.proc_handler = StoredProcedureHandler(dialect=dialect)

    def process_file(self, filepath: str) -> FileProcessResult:
        """
        Process a SQL file.

        Args:
            filepath: Path to the SQL file

        Returns:
            FileProcessResult with extracted SQL statements
        """
        try:
            content = self.read_file(filepath)
            return self.process_content(content, filepath)
        except Exception as e:
            return FileProcessResult(
                filepath=filepath,
                file_type="SQL",
                success=False,
                errors=[f"Failed to read file: {str(e)}"]
            )

    def _is_stored_procedure(self, content: str) -> bool:
        """Check if content is a stored procedure."""
        # Match REPLACE/CREATE PROCEDURE patterns
        proc_pattern = re.compile(
            r'(?:CREATE|REPLACE)\s+PROCEDURE',
            re.IGNORECASE
        )
        return bool(proc_pattern.search(content))

    def _preprocess_teradata_sp(self, content: str) -> str:
        """
        Preprocess Teradata stored procedure SQL to normalize syntax that
        SQLGlot cannot parse.

        This runs once on the raw SP content before any statement extraction.

        Handles:
        - Line-continuation double quotes from Teradata export tools:
          Lines ending with " and next line starting with " are rejoined.
          e.g., AF.AGM"\\n"T_FEATURE_AMT -> AF.AGMT_FEATURE_AMT
        - Trailing export garbage after END MAIN; (e.g., ====, "RequestText")
        - Interval qualifiers: (expr) MONTH(4), YEAR(4), DAY(4), etc.
          Strips the qualifier so (date1 - date2) MONTH(4) becomes (date1 - date2)
        - Double-double-quoted identifiers: ""COL_NAME"" becomes "COL_NAME"
          These appear in Teradata procedure exports where identifiers are escaped.

        Args:
            content: Raw stored procedure SQL content

        Returns:
            Preprocessed SQL content safe for SQLGlot parsing
        """
        # Strip line-continuation double quotes from export tools.
        # Pattern: a line ends with " and the next starts with " — rejoin without
        # whitespace so split tokens like AF.AGM"\n"T_FEATURE_AMT become
        # AF.AGMT_FEATURE_AMT.
        content = re.sub(r'"\s*\n\s*"', '', content)

        # Strip trailing export garbage after the procedure body ends.
        # Teradata export tools sometimes append separator lines (====...),
        # "RequestText", or stray quotes after END MAIN; or END <label>;
        # Use finditer to get the LAST match (END MAIN; not END IF;).
        last_end = None
        for m in re.finditer(r'END\s+\w+\s*;\s*', content, re.IGNORECASE):
            last_end = m
        if last_end:
            trailing = content[last_end.end():].strip()
            # Only truncate if what follows is garbage (non-SQL content)
            if not trailing or not re.match(r'(?:CREATE|REPLACE|ALTER|INSERT|SELECT|DELETE|UPDATE|MERGE)\b', trailing, re.IGNORECASE):
                content = content[:last_end.end()]

        # Strip Teradata interval qualifiers: ) MONTH(n), ) YEAR(n), ) DAY(n), etc.
        # e.g., CAST(((CAST(STRT_DT AS DATE) - CAST(NOTE_DTE AS DATE)) MONTH(4)) AS INTEGER)
        # becomes CAST(((CAST(STRT_DT AS DATE) - CAST(NOTE_DTE AS DATE))) AS INTEGER)
        content = re.sub(
            r'\)\s*(?:MONTH|YEAR|DAY|HOUR|MINUTE|SECOND)\s*\(\s*\d+\s*\)',
            ')',
            content,
            flags=re.IGNORECASE
        )

        # Normalize double-double-quoted identifiers: ""name"" -> "name"
        content = re.sub(r'""(\w+)""', r'"\1"', content)

        # Strip # prefix from temp table names (SQL Server convention
        # sometimes carried over into Teradata SPs, e.g. #tmpXref).
        # sqlglot's Teradata dialect tokenizes # as HASH and rejects it.
        content = re.sub(r'#(\w+)', r'\1', content)

        return content

    def extract_volatile_table_schema(self, content: str) -> dict:
        """
        Extract column names from CREATE VOLATILE TABLE statements and return as schema dict.
        
        This allows SELECT * to be expanded for volatile tables during lineage extraction.
        
        Args:
            content: Stored procedure SQL content
            
        Returns:
            Dict mapping table names to column lists
        """
        volatile_schema = {}
        
        # Remove comments first
        content = self.proc_handler.remove_comments(content)
        
        # Pattern to find CREATE VOLATILE TABLE ... AS
        # Allow optional DDL clauses (NO FALLBACK, NO JOURNAL, NO LOG, etc.)
        # between the table name and "AS ("
        create_volatile_pattern = re.compile(
            r'CREATE\s+(?:MULTISET\s+)?VOLATILE\s+(?:TABLE\s+)?([\w.#]+)[\s,]+'
            r'(?:(?:NO\s+(?:FALLBACK|JOURNAL|LOG)|FALLBACK|JOURNAL|LOG|CHECKSUM\s*=\s*\w+)\s*[,\s]*)*'
            r'AS\s*\(',
            re.IGNORECASE | re.DOTALL
        )

        for match in create_volatile_pattern.finditer(content):
            table_name = match.group(1).upper()
            start_paren = match.end() - 1
            
            # Find matching closing paren
            paren_count = 1
            pos = start_paren + 1
            in_string = False
            string_char = None
            
            while pos < len(content) and paren_count > 0:
                char = content[pos]
                if in_string:
                    if char == string_char:
                        in_string = False
                        string_char = None
                elif char in ("'", '"'):
                    in_string = True
                    string_char = char
                elif char == '(':
                    paren_count += 1
                elif char == ')':
                    paren_count -= 1
                pos += 1
            
            if paren_count != 0:
                continue
            
            # Extract the SELECT part
            select_sql = content[start_paren + 1:pos - 1].strip()
            
            # Convert SEL to SELECT
            if re.match(r'\s*SEL\b', select_sql, re.IGNORECASE) and not re.match(r'\s*SELECT\b', select_sql, re.IGNORECASE):
                select_sql = re.sub(r'^\s*SEL\b', 'SELECT', select_sql, flags=re.IGNORECASE)
            
            # Parse the SELECT to extract column names
            columns = self._extract_columns_from_select(select_sql)
            if columns:
                volatile_schema[table_name] = columns
                # Also add without schema prefix
                simple_name = table_name.split('.')[-1]
                if simple_name != table_name:
                    volatile_schema[simple_name] = columns
        
        return volatile_schema
    
    def _extract_columns_from_select(self, select_sql: str) -> List[str]:
        """
        Extract output column names from a SELECT statement.
        
        Args:
            select_sql: SELECT statement SQL
            
        Returns:
            List of column names
        """
        columns = []
        try:
            # Try to parse with sqlglot
            parsed = sqlglot.parse_one(select_sql, dialect=self.dialect)
            if parsed:
                # Get the SELECT expressions
                for expr in parsed.find_all(exp.Select):
                    for col_expr in expr.expressions:
                        col_name = None
                        
                        # Check for alias first
                        if isinstance(col_expr, exp.Alias):
                            col_name = col_expr.alias
                        elif hasattr(col_expr, 'alias') and col_expr.alias:
                            col_name = col_expr.alias
                        elif isinstance(col_expr, exp.Column):
                            col_name = col_expr.name
                        elif hasattr(col_expr, 'this') and isinstance(col_expr.this, exp.Column):
                            col_name = col_expr.this.name
                        elif hasattr(col_expr, 'name'):
                            col_name = col_expr.name
                        
                        if col_name and col_name != '*':
                            columns.append(col_name.upper())
                    break  # Only get columns from first SELECT
        except Exception:
            # If parsing fails, try regex extraction
            columns = self._extract_columns_from_select_regex(select_sql)
        
        return columns
    
    def _extract_columns_from_select_regex(self, select_sql: str) -> List[str]:
        """
        Fallback regex-based column extraction from SELECT statement.
        """
        columns = []
        
        # Find the SELECT ... FROM portion
        match = re.search(r'SELECT\s+(.+?)\s+FROM\b', select_sql, re.IGNORECASE | re.DOTALL)
        if not match:
            return columns
        
        select_list = match.group(1)
        
        # Split by comma (being careful of nested parens)
        parts = []
        current = ""
        paren_depth = 0
        
        for char in select_list:
            if char == '(':
                paren_depth += 1
            elif char == ')':
                paren_depth -= 1
            elif char == ',' and paren_depth == 0:
                parts.append(current.strip())
                current = ""
                continue
            current += char
        if current.strip():
            parts.append(current.strip())
        
        for part in parts:
            # Look for AS alias pattern
            as_match = re.search(r'\bAS\s+(\w+)\s*$', part, re.IGNORECASE)
            if as_match:
                columns.append(as_match.group(1).upper())
            else:
                # Get the last identifier (column name or alias)
                # Handle table.column and just column
                ident_match = re.search(r'(?:[\w.]+\.)?(\w+)\s*$', part)
                if ident_match:
                    col_name = ident_match.group(1).upper()
                    if col_name not in ('DISTINCT', 'ALL'):
                        columns.append(col_name)
        
        return columns

    def _extract_create_volatile_table_from_procedure(self, content: str) -> List[str]:
        """
        Extract CREATE VOLATILE TABLE AS (SELECT ...) statements from stored procedure.

        Handles Teradata stored procedure syntax including:
        - CREATE MULTISET VOLATILE TABLE name AS (SELECT ...)
        - CREATE VOLATILE TABLE name AS (SELECT ...)
        - WITH DATA ON COMMIT PRESERVE ROWS clauses

        Args:
            content: Stored procedure SQL content

        Returns:
            List of INSERT INTO target_table SELECT ... statements derived from
            the CREATE VOLATILE TABLE AS statements (converted for lineage extraction)
        """
        statements = []

        # Remove comments first
        content = self.proc_handler.remove_comments(content)

        # Pattern to find CREATE VOLATILE TABLE ... AS
        # Matches: CREATE [MULTISET] VOLATILE TABLE name [, NO FALLBACK, ...] AS (SELECT ...)
        # Note: Use re.DOTALL to allow \s to match newlines between AS and (
        # Allow optional DDL clauses (NO FALLBACK, NO JOURNAL, NO LOG, PRIMARY INDEX, etc.)
        # between the table name and "AS ("
        create_volatile_pattern = re.compile(
            r'CREATE\s+(?:MULTISET\s+)?VOLATILE\s+(?:TABLE\s+)?([\w.#]+)[\s,]+'
            r'(?:(?:NO\s+(?:FALLBACK|JOURNAL|LOG)|FALLBACK|JOURNAL|LOG|CHECKSUM\s*=\s*\w+)\s*[,\s]*)*'
            r'AS\s*\(',
            re.IGNORECASE | re.DOTALL
        )

        for match in create_volatile_pattern.finditer(content):
            table_name = match.group(1)
            start_paren = match.end() - 1  # Position of the opening paren

            # Find the matching closing paren for the AS (...) clause
            paren_count = 1
            pos = start_paren + 1
            in_string = False
            string_char = None

            while pos < len(content) and paren_count > 0:
                char = content[pos]
                if in_string:
                    if char == string_char:
                        in_string = False
                        string_char = None
                elif char in ("'", '"'):
                    in_string = True
                    string_char = char
                elif char == '(':
                    paren_count += 1
                elif char == ')':
                    paren_count -= 1
                pos += 1

            if paren_count != 0:
                continue  # Unmatched parens

            # Extract the SELECT part (inside the AS (...))
            select_sql = content[start_paren + 1:pos - 1].strip()

            # Check if it starts with SELECT or SEL (Teradata shorthand)
            if re.match(r'\s*(?:SELECT|SEL)\b', select_sql, re.IGNORECASE):
                # Convert SEL to SELECT for parser compatibility
                if re.match(r'\s*SEL\b', select_sql, re.IGNORECASE) and not re.match(r'\s*SELECT\b', select_sql, re.IGNORECASE):
                    select_sql = re.sub(r'^\s*SEL\b', 'SELECT', select_sql, flags=re.IGNORECASE)
                
                # Convert to INSERT INTO format for lineage extraction
                # This allows us to trace where the data in the volatile table comes from
                insert_sql = f"INSERT INTO {table_name} {select_sql}"
                insert_sql = self._normalize_sql(insert_sql)
                statements.append(insert_sql)

        return statements

    def _extract_insert_from_procedure(self, content: str) -> List[str]:
        """
        Extract INSERT...SELECT statements from stored procedure.

        Handles Teradata stored procedure syntax including:
        - REPLACE PROCEDURE / CREATE PROCEDURE
        - BEGIN...END blocks
        - Nested INSERT...SELECT statements with multi-line column lists
        - INSERT and INTO on separate lines (Teradata formatting)

        Args:
            content: Stored procedure SQL content

        Returns:
            List of INSERT...SELECT statements extracted from the procedure
        """
        statements = []

        # Remove comments first
        content = self.proc_handler.remove_comments(content)

        # Fix Teradata export line-continuation artifacts: "word"\n"continuation"
        # These appear when a long line is split across rows in the export format.
        # Pattern: identifier chars, then "\n", then more identifier chars
        content = re.sub(r'"\s*\n\s*"', '', content)

        # Find INSERT INTO with column list that spans multiple lines
        # Strategy: find INSERT INTO, then find the matching closing paren for the column list,
        # then capture everything until the end of the SELECT (marked by ;)

        # First, find all INSERT INTO positions
        # Use \s+ to handle newlines between INSERT and INTO (common in Teradata)
        insert_starts = []
        for match in re.finditer(r'INSERT\s+INTO\s+[\w.]+\s*\(', content, re.IGNORECASE | re.DOTALL):
            insert_starts.append(match.start())

        for start_pos in insert_starts:
            # Find the opening paren after table name
            paren_start = content.find('(', start_pos)
            if paren_start == -1:
                continue

            # Find matching closing paren (handle nested parens)
            paren_count = 1
            pos = paren_start + 1
            while pos < len(content) and paren_count > 0:
                if content[pos] == '(':
                    paren_count += 1
                elif content[pos] == ')':
                    paren_count -= 1
                pos += 1

            if paren_count != 0:
                continue  # Unmatched parens

            column_list_end = pos

            # Now look for SELECT after the column list
            remaining = content[column_list_end:]
            select_match = re.match(r'\s*(SELECT\s+)', remaining, re.IGNORECASE)
            if not select_match:
                continue

            # Find the end of the SELECT - look for semicolon that ends the statement
            # This is tricky because there might be semicolons in subqueries
            # Use a simpler approach: find the next top-level semicolon
            select_start = column_list_end + select_match.start()

            # Find ending semicolon or the start of another INSERT statement
            # (handles cases where first INSERT doesn't end with semicolon)
            paren_count = 0
            in_string = False
            string_char = None
            end_pos = column_list_end + select_match.end()

            while end_pos < len(content):
                char = content[end_pos]

                if in_string:
                    if char == string_char:
                        in_string = False
                        string_char = None
                elif char in ("'", '"'):
                    in_string = True
                    string_char = char
                elif char == '(':
                    paren_count += 1
                elif char == ')':
                    paren_count -= 1
                elif char == ';' and paren_count == 0:
                    break
                # Check for another INSERT at the top level (statement boundary)
                elif paren_count == 0 and not in_string:
                    # Look ahead for INSERT INTO pattern
                    remaining = content[end_pos:end_pos+20].upper()
                    if remaining.startswith('INSERT') and re.match(r'INSERT\s+INTO\s', remaining, re.IGNORECASE):
                        # Found another INSERT - end the current statement here
                        break

                end_pos += 1

            # Extract the INSERT...SELECT statement
            insert_sql = content[start_pos:end_pos].strip()

            # Remove trailing whitespace and empty lines
            insert_sql = insert_sql.rstrip()

            # Check if this is a real INSERT...SELECT (has SELECT keyword)
            if re.search(r'\bSELECT\b', insert_sql, re.IGNORECASE):
                # Normalize the SQL to fix multi-line operator issues
                insert_sql = self._normalize_sql(insert_sql)
                statements.append(insert_sql)

        # Track positions already captured to avoid duplicates
        captured_positions = set(insert_starts)

        # Second pass: find INSERT INTO table_name SELECT ... (without column list)
        # This handles cases like: INSERT INTO table_name\n SELECT col1, col2 FROM ...
        for match in re.finditer(
            r'INSERT\s+INTO\s+([\w.]+)\s*\n?\s*(SELECT\b)',
            content, re.IGNORECASE | re.DOTALL
        ):
            start_pos = match.start()
            # Skip if already captured in first pass
            if any(abs(start_pos - cp) < 5 for cp in captured_positions):
                continue

            # Check that the char before SELECT is not '(' — that would be a column list case
            # already handled above
            pre_select = content[match.start(2) - 1] if match.start(2) > 0 else ' '
            if pre_select == ')':
                continue  # This is after a column list — already handled

            # Find the end of this INSERT...SELECT statement
            select_start = match.start(2)
            paren_count = 0
            in_string = False
            string_char = None
            end_pos = select_start

            while end_pos < len(content):
                char = content[end_pos]

                if in_string:
                    if char == string_char:
                        in_string = False
                        string_char = None
                elif char in ("'", '"'):
                    in_string = True
                    string_char = char
                elif char == '(':
                    paren_count += 1
                elif char == ')':
                    paren_count -= 1
                elif char == ';' and paren_count == 0:
                    break
                # Check for ET (Teradata end-transaction) at top level
                elif paren_count == 0 and not in_string:
                    remaining_upper = content[end_pos:end_pos + 20].upper().lstrip()
                    if remaining_upper.startswith('ET') and (
                        len(remaining_upper) < 3 or not remaining_upper[2].isalnum()
                    ):
                        break
                    if remaining_upper.startswith('INSERT') and re.match(
                        r'INSERT\s+INTO\s', remaining_upper, re.IGNORECASE
                    ):
                        break
                    if remaining_upper.startswith('DELETE') and re.match(
                        r'DELETE\s+FROM\s', remaining_upper, re.IGNORECASE
                    ):
                        break

                end_pos += 1

            insert_sql = content[start_pos:end_pos].strip().rstrip(';').strip()

            if re.search(r'\bSELECT\b', insert_sql, re.IGNORECASE):
                insert_sql = self._normalize_sql(insert_sql)
                statements.append(insert_sql)
                captured_positions.add(start_pos)

        return statements

    def _extract_insert_values_from_procedure(self, content: str) -> List[str]:
        """
        Extract INSERT...VALUES statements from stored procedure.

        These are typically logging/audit INSERTs (e.g., PROCESS_LOG) with
        literal values, variables, and system functions instead of a SELECT.

        Args:
            content: Stored procedure SQL content

        Returns:
            List of INSERT...VALUES SQL statements
        """
        statements = []
        content_clean = self.proc_handler.remove_comments(content)
        content_clean = re.sub(r'"\s*\n\s*"', '', content_clean)

        for match in re.finditer(r'INSERT\s+INTO\s+[\w.]+\s*\(', content_clean, re.IGNORECASE | re.DOTALL):
            start_pos = match.start()

            # Find matching closing paren for column list
            paren_start = content_clean.find('(', start_pos)
            if paren_start == -1:
                continue
            paren_count = 1
            pos = paren_start + 1
            while pos < len(content_clean) and paren_count > 0:
                if content_clean[pos] == '(':
                    paren_count += 1
                elif content_clean[pos] == ')':
                    paren_count -= 1
                pos += 1
            if paren_count != 0:
                continue

            column_list_end = pos
            remaining = content_clean[column_list_end:]

            # Check for VALUES (not SELECT)
            values_match = re.match(r'\s*VALUES\s*\(', remaining, re.IGNORECASE)
            if not values_match:
                continue

            # Find the end of the VALUES clause (semicolon at top level)
            end_pos = column_list_end + values_match.end() - 1  # back to '('
            paren_count = 0
            in_string = False
            string_char = None
            while end_pos < len(content_clean):
                char = content_clean[end_pos]
                if in_string:
                    if char == string_char:
                        in_string = False
                elif char in ("'", '"'):
                    in_string = True
                    string_char = char
                elif char == '(':
                    paren_count += 1
                elif char == ')':
                    paren_count -= 1
                    if paren_count == 0:
                        end_pos += 1
                        break
                elif char == ';' and paren_count == 0:
                    break
                end_pos += 1

            insert_sql = content_clean[start_pos:end_pos].strip().rstrip(';').strip()
            if insert_sql and re.search(r'\bVALUES\b', insert_sql, re.IGNORECASE):
                # Fix Teradata export doubled-quote artifacts: ""col"" -> "col"
                insert_sql = re.sub(r'""(\w+)""', r'"\1"', insert_sql)
                insert_sql = self._normalize_sql(insert_sql)
                statements.append(insert_sql)

        return statements

    def _extract_delete_from_procedure(self, content: str) -> List[str]:
        """
        Extract DELETE statements from stored procedure.

        Handles Teradata DELETE patterns:
        - DELETE FROM table_name ALL;
        - DELETE FROM table_name WHERE ...;

        Args:
            content: Stored procedure SQL content (comments already removed)

        Returns:
            List of DELETE SQL statements
        """
        statements = []

        # Remove comments
        content_clean = self.proc_handler.remove_comments(content)
        # Fix Teradata export line-continuation artifacts
        content_clean = re.sub(r'"\s*\n\s*"', '', content_clean)

        for match in re.finditer(
            r'DELETE\s+FROM\s+',
            content_clean, re.IGNORECASE
        ):
            start_pos = match.start()

            # Find the end of the DELETE statement (semicolon at top level)
            paren_count = 0
            in_string = False
            string_char = None
            end_pos = match.end()

            while end_pos < len(content_clean):
                char = content_clean[end_pos]
                if in_string:
                    if char == string_char:
                        in_string = False
                        string_char = None
                elif char in ("'", '"'):
                    in_string = True
                    string_char = char
                elif char == '(':
                    paren_count += 1
                elif char == ')':
                    paren_count -= 1
                elif char == ';' and paren_count == 0:
                    break
                end_pos += 1

            delete_sql = content_clean[start_pos:end_pos].strip().rstrip(';').strip()
            if delete_sql:
                delete_sql = self._normalize_sql(delete_sql)
                statements.append(delete_sql)

        return statements

    def _extract_update_from_procedure(self, content: str) -> List[str]:
        """
        Extract UPDATE statements from stored procedure.

        Handles Teradata UPDATE patterns:
        - UPDATE table SET col = expr WHERE ...;
        - UPDATE table FROM (subquery) alias SET col = expr WHERE ...;
        - UPDATE table FROM table1, table2 SET col = expr WHERE ...;
        - UPDATE alias FROM table alias SET col = expr WHERE ...;

        Args:
            content: Stored procedure SQL content

        Returns:
            List of UPDATE SQL statements
        """
        statements = []

        # Remove comments
        content_clean = self.proc_handler.remove_comments(content)
        # Fix Teradata export line-continuation artifacts
        content_clean = re.sub(r'"\s*\n\s*"', '', content_clean)

        # Find UPDATE keyword at statement boundary (not inside INSERT or other statements)
        # Use a negative lookbehind to avoid matching inside strings
        for match in re.finditer(
            r'\bUPDATE\s+',
            content_clean, re.IGNORECASE
        ):
            start_pos = match.start()

            # Skip if this UPDATE is inside a string literal by checking
            # if we have an odd number of single quotes before this position
            preceding = content_clean[:start_pos]
            # Count unescaped single quotes (simple heuristic)
            quote_count = preceding.count("'") - preceding.count("\\'")
            if quote_count % 2 != 0:
                continue

            # Skip if preceded by COLLECT (COLLECT UPDATE STATISTICS)
            pre_text = content_clean[max(0, start_pos - 20):start_pos].strip().upper()
            if pre_text.endswith('COLLECT'):
                continue

            # Find the end of the UPDATE statement (semicolon at top level)
            paren_count = 0
            in_string = False
            string_char = None
            end_pos = match.end()

            while end_pos < len(content_clean):
                char = content_clean[end_pos]
                if in_string:
                    if char == string_char:
                        in_string = False
                        string_char = None
                elif char in ("'", '"'):
                    in_string = True
                    string_char = char
                elif char == '(':
                    paren_count += 1
                elif char == ')':
                    paren_count -= 1
                elif char == ';' and paren_count == 0:
                    break
                end_pos += 1

            update_sql = content_clean[start_pos:end_pos].strip().rstrip(';').strip()
            if update_sql and 'SET' in update_sql.upper():
                update_sql = self._normalize_sql(update_sql)
                statements.append(update_sql)

        return statements

    def _extract_select_into_from_procedure(self, content: str) -> List[str]:
        """
        Extract SELECT ... INTO variable ... FROM statements from stored procedure.

        These are Teradata SPL constructs that select values into local variables,
        e.g.: SELECT expr INTO var FROM table WHERE condition;

        Args:
            content: Stored procedure SQL content

        Returns:
            List of SELECT INTO SQL statements
        """
        statements = []

        # Remove comments
        content_clean = self.proc_handler.remove_comments(content)
        content_clean = re.sub(r'"\s*\n\s*"', '', content_clean)

        # Find SELECT ... INTO var ... FROM patterns
        # Must have INTO followed by a simple identifier (variable), then FROM
        # Use two-pass approach:
        # Pass 1: Match single-line SELECT ... INTO var FROM (e.g., SELECT COUNT(1) INTO V_MST_COUNT FROM ...)
        # Pass 2: Match multi-line SELECT ... INTO var FROM (e.g., SELECT expr \n INTO var \n FROM ...)
        # Both passes avoid crossing semicolons to prevent false matches from subqueries
        seen_starts = set()
        select_into_patterns = [
            # Single-line pattern (no DOTALL - does not cross newlines for .+?)
            (r'SELECT\s+.+?\s+INTO\s+(\w+)\s+FROM\s+', re.IGNORECASE),
            # Multi-line pattern (DOTALL) but uses [^;]+? to avoid crossing semicolons
            (r'SELECT\s+[^;]+?\s+INTO\s+(\w+)\s+FROM\s+', re.IGNORECASE | re.DOTALL),
        ]
        for pattern, flags in select_into_patterns:
            for match in re.finditer(pattern, content_clean, flags):
                start_pos = match.start()
                if start_pos in seen_starts:
                    continue
                seen_starts.add(start_pos)

                # Make sure this is not INSERT INTO (which is handled separately)
                # Check if INSERT precedes this SELECT
                pre_text = content_clean[max(0, start_pos - 20):start_pos].strip().upper()
                if pre_text.endswith('INSERT'):
                    continue

                # Find the end of the statement (semicolon at top level)
                paren_count = 0
                in_string = False
                string_char = None
                end_pos = match.end()

                while end_pos < len(content_clean):
                    char = content_clean[end_pos]
                    if in_string:
                        if char == string_char:
                            in_string = False
                            string_char = None
                    elif char in ("'", '"'):
                        in_string = True
                        string_char = char
                    elif char == '(':
                        paren_count += 1
                    elif char == ')':
                        paren_count -= 1
                    elif char == ';' and paren_count == 0:
                        break
                    end_pos += 1

                select_sql = content_clean[start_pos:end_pos].strip().rstrip(';').strip()
                if select_sql:
                    select_sql = self._normalize_sql(select_sql)
                    statements.append(select_sql)

        return statements

    def _normalize_sql(self, sql: str) -> str:
        """
        Normalize SQL to fix common parsing issues.

        Handles:
        - Multi-line operators (e.g., '||' split across lines)
        - Excess whitespace
        - Teradata-specific type literals (e.g., '9999-12-31' (DATE))

        Args:
            sql: SQL string to normalize

        Returns:
            Normalized SQL string
        """
        # Fix operators split across lines (e.g., '-'|\n |SUBSTR -> '-'||SUBSTR)
        # This handles the case where || is split as |\n | or |\n|
        sql = re.sub(r'\|\s*\n\s*\|', '||', sql)
        sql = re.sub(r'\|\s*\r?\n\s*\|', '||', sql)

        # Fix any other cases where | appears at end of line followed by | at start of next
        sql = re.sub(r'\|\s+\|', '||', sql)

        # Normalize Teradata-specific type literals to standard CAST syntax
        sql = self._normalize_teradata_literals(sql)

        # Normalize whitespace (but preserve newlines for readability)
        sql = re.sub(r'[ \t]+', ' ', sql)

        return sql

    def _normalize_teradata_literals(self, sql: str) -> str:
        """
        Convert Teradata-specific type literal syntax to standard CAST format.

        Handles:
        - '9999-12-31' (DATE) -> CAST('9999-12-31' AS DATE)
        - '9999-12-31 11:59:59' (TIMESTAMP(0)) -> CAST('9999-12-31 11:59:59' AS TIMESTAMP(0))
        - '0001-01-01 00:00:00' (TIMESTAMP(0)) -> CAST('0001-01-01 00:00:00' AS TIMESTAMP(0))

        Args:
            sql: SQL string with potential Teradata literals

        Returns:
            SQL string with normalized CAST syntax
        """
        # Pattern for Teradata type literal: 'value' (TYPE) or 'value'(TYPE)
        # where TYPE can be DATE, TIMESTAMP(n), INTEGER, VARCHAR(n), etc.
        # Match: 'literal_value' followed by optional whitespace and (TYPE_SPEC)

        # Pattern breakdown:
        # ('([^']*)')  - captures the quoted string including quotes
        # \s*          - optional whitespace
        # \(           - opening paren for type spec
        # ([A-Z][A-Z0-9_]*(?:\s*\(\s*\d+\s*\))?)  - type name with optional precision
        # \)           - closing paren for type spec

        teradata_literal_pattern = re.compile(
            r"(\('([^']+)'\s*\(([A-Z][A-Z0-9_]*(?:\s*\(\s*\d+\s*\))?)\)\))",
            re.IGNORECASE
        )

        def replace_teradata_literal(match):
            full_match = match.group(1)
            literal_value = match.group(2)
            type_spec = match.group(3)
            return f"CAST('{literal_value}' AS {type_spec})"

        sql = teradata_literal_pattern.sub(replace_teradata_literal, sql)

        # Also handle the pattern without outer parens: 'value'(TYPE)
        # This is less common but can appear in some Teradata SQL
        teradata_literal_pattern2 = re.compile(
            r"'([^']+)'\s*\(([A-Z][A-Z0-9_]*(?:\s*\(\s*\d+\s*\))?)\)",
            re.IGNORECASE
        )

        def replace_teradata_literal2(match):
            literal_value = match.group(1)
            type_spec = match.group(2)
            # Avoid matching things that are already CAST expressions
            return f"CAST('{literal_value}' AS {type_spec})"

        # Only apply if not already a CAST
        result = []
        last_end = 0
        for match in teradata_literal_pattern2.finditer(sql):
            # Check if this is already inside a CAST
            start = match.start()
            prefix = sql[max(0, start-5):start].upper()
            if 'CAST(' not in prefix and "AS " not in prefix:
                result.append(sql[last_end:start])
                result.append(replace_teradata_literal2(match))
                last_end = match.end()
        result.append(sql[last_end:])
        sql = ''.join(result) if result else sql

        return sql

    def _has_multiple_inserts(self, content: str) -> bool:
        """Check if content has multiple INSERT statements."""
        insert_count = len(re.findall(r'\bINSERT\s+INTO\b', content, re.IGNORECASE))
        return insert_count > 1

    def _clean_non_printable(self, content: str) -> str:
        """Remove non-printable characters that can cause encoding issues."""
        # Replace non-printable characters (except newlines, tabs) with space
        return re.sub(r'[^\x20-\x7E\n\r\t]', ' ', content)

    def process_content(self, content: str, source_file: str = "") -> FileProcessResult:
        """
        Process SQL content.

        Args:
            content: SQL content
            source_file: Source file name for reference

        Returns:
            FileProcessResult with extracted SQL statements
        """
        result = FileProcessResult(
            filepath=source_file,
            file_type="SQL",
            success=True
        )

        try:
            # Clean non-printable characters that may cause encoding issues
            content = self._clean_non_printable(content)
            # Check if this is a stored procedure
            if self._is_stored_procedure(content):
                 
                # Preprocess Teradata SP syntax before extraction
                content = self._preprocess_teradata_sp(content)
 
                # Extract INSERT statements from stored procedure
                insert_statements = self._extract_insert_from_procedure(content)

                # Extract DELETE statements from stored procedure
                delete_statements = self._extract_delete_from_procedure(content)

                # Extract UPDATE statements from stored procedure
                update_statements = self._extract_update_from_procedure(content)

                # Extract SELECT ... INTO variable statements from stored procedure
                select_into_statements = self._extract_select_into_from_procedure(content)

                # Extract INSERT...VALUES statements (e.g., PROCESS_LOG logging)
                insert_values_statements = self._extract_insert_values_from_procedure(content)

                # Also extract CREATE VOLATILE TABLE AS statements and convert to INSERT format
                volatile_table_statements = self._extract_create_volatile_table_from_procedure(content)

                # Track which SQL strings originated from CREATE VOLATILE TABLE
                # so we can override their statement_type after parsing
                volatile_sql_set = set(volatile_table_statements)

                # Combine all extracted statements, sorted by their position
                # in the original SQL to preserve execution order.
                # Each extraction method uses regex on comment-stripped content,
                # so we locate each statement's first distinctive keyword in
                # the same cleaned content to recover source order.
                all_statements_unsorted = (
                    insert_statements + delete_statements +
                    update_statements + select_into_statements +
                    volatile_table_statements + insert_values_statements
                )

                # Build a single cleaned copy for position lookup
                _clean = self.proc_handler.remove_comments(content)
                _clean = re.sub(r'"\s*\n\s*"', '', _clean)
                _clean_upper = _clean.upper()

                def _find_position(sql_str: str) -> int:
                    """Find the position of a statement in the cleaned content."""
                    sql_upper = sql_str.upper().strip()
                    # Build a regex pattern from the first keyword + table name
                    # that tolerates whitespace differences.
                    # Handles: INSERT INTO tbl, DELETE FROM tbl, SELECT...INTO var,
                    #          CREATE [VOLATILE] TABLE tbl
                    for pat_str in (
                        r'INSERT\s+INTO\s+([\w.]+)',
                        r'DELETE\s+FROM\s+([\w.]+)',
                        r'UPDATE\s+([\w.]+)',
                        r'SELECT\s+.*?\s+INTO\s+(\w+)\s+FROM',
                        r'CREATE\s+(?:VOLATILE\s+)?TABLE\s+([\w.]+)',
                    ):
                        m = re.match(pat_str, sql_upper, re.DOTALL)
                        if m:
                            table = m.group(1)
                            # Build a flexible search pattern with the
                            # keyword and table name
                            keyword = sql_upper[:m.start(1)].split()
                            # e.g. ["INSERT", "INTO"] or ["DELETE", "FROM"]
                            search_pat = r'\s+'.join(
                                re.escape(w) for w in keyword
                            ) + r'\s+' + re.escape(table)
                            sm = re.search(search_pat, _clean_upper)
                            if sm:
                                return sm.start()
                    # Last resort: try exact substring match on first line
                    first_line = sql_upper.split('\n')[0].strip()
                    idx = _clean_upper.find(first_line)
                    if idx >= 0:
                        return idx
                    return len(_clean)  # Unknown → put at end

                all_statements = sorted(
                    all_statements_unsorted,
                    key=_find_position
                )

                if all_statements:
                    # Process each extracted statement
                    for i, sql in enumerate(all_statements):
                        sql_stmt = self._process_raw_sql(sql, i, source_file)
                        if sql_stmt:
                            # Override statement_type for volatile table statements
                            if sql in volatile_sql_set:
                                sql_stmt.statement_type = "CREATE VOLATILE TABLE"
                                if sql_stmt.elements:
                                    sql_stmt.elements.statement_type = "CREATE VOLATILE TABLE"
                            result.statements.append(sql_stmt)

                    if result.statements:
                        return result
                    else:
                        result.warnings.append("Found stored procedure but could not extract valid DML statements")

            # Check if there are multiple INSERT statements (even if not a stored procedure)
            # This handles SQL files with multiple INSERTs that may not be properly separated
            if self._has_multiple_inserts(content):
                insert_statements = self._extract_insert_from_procedure(content)
                if insert_statements:
                    for i, insert_sql in enumerate(insert_statements):
                        sql_stmt = self._process_raw_sql(insert_sql, i, source_file)
                        if sql_stmt:
                            result.statements.append(sql_stmt)

                    if result.statements:
                        return result

            # Normalize the content for Teradata-specific syntax
            content = self._normalize_sql(content)

            # Parse using safe parser to handle partial failures
            parse_result = self.parser.parse_safe(content)

            if not parse_result.success and not parse_result.statements:
                result.success = False
                result.errors.extend(parse_result.metadata.error_messages)
                return result

            # Process each statement
            for i, stmt in enumerate(parse_result.statements):
                if stmt is None:
                    continue

                sql_stmt = self._process_statement(stmt, i, source_file)
                if sql_stmt:
                    result.statements.append(sql_stmt)

            # Add any parsing warnings
            if parse_result.metadata.has_errors:
                result.warnings.extend(parse_result.metadata.error_messages)

        except Exception as e:
            result.errors.append(f"Processing error: {str(e)}")
            result.success = False

        return result

    def _process_statement(self, stmt: exp.Expression, index: int,
                           source_file: str) -> Optional[SQLStatement]:
        """
        Process a single SQL statement.

        Args:
            stmt: Parsed statement
            index: Statement index
            source_file: Source file name

        Returns:
            SQLStatement or None
        """
        try:
            # Determine statement type
            stmt_type = self._get_statement_type(stmt)

            # Skip DDL statements - they should be handled by DDLHandler
            if stmt_type in ('CREATE', 'ALTER', 'DROP'):
                return None

            # Generate statement ID
            stmt_id = f"{os.path.basename(source_file)}_{index+1}"

            # Get raw SQL
            # For SELECT INTO, sqlglot regenerates as CREATE TABLE AS SELECT — preserve INTO syntax
            if stmt_type == "SELECT INTO" and isinstance(stmt, exp.Select):
                into_node = stmt.args.get('into')
                var_name = ''
                if into_node:
                    for tbl in into_node.find_all(exp.Table):
                        var_name = tbl.name
                        break
                # Regenerate without INTO, then re-inject INTO before FROM
                stmt_copy = stmt.copy()
                stmt_copy.args.pop('into', None)
                base_sql = stmt_copy.sql(dialect=self.dialect)
                if var_name and ' FROM ' in base_sql.upper():
                    from_idx = base_sql.upper().index(' FROM ')
                    raw_sql = base_sql[:from_idx] + f' INTO {var_name}' + base_sql[from_idx:]
                else:
                    raw_sql = stmt.sql(dialect=self.dialect)
            else:
                raw_sql = stmt.sql(dialect=self.dialect)

            # Extract target table
            target_table = self._get_target_table(stmt)

            # Extract source tables
            source_tables = self._get_source_tables(stmt, target_table)

            # Extract elements
            try:
                extractor = SQLElementExtractor(stmt, self.dialect)
                elements = extractor.extract_all()
            except Exception:
                elements = None

            # Extract lineage
            try:
                lineage_extractor = LineageExtractor(
                    schema=self.schema,
                    dialect=self.dialect
                )
                lineage = lineage_extractor.extract_lineage(raw_sql)
            except Exception:
                lineage = LineageGraph()

            # For INSERT...VALUES (no SELECT), build lineage from column list + values
            if (not lineage or not lineage.edges) and isinstance(stmt, exp.Insert):
                values_lineage = self._build_values_lineage(stmt, target_table)
                if values_lineage and values_lineage.edges:
                    lineage = values_lineage

            return SQLStatement(
                statement_id=stmt_id,
                statement_type=stmt_type,
                target_table=target_table,
                source_tables=source_tables,
                source_file=source_file,
                raw_sql=raw_sql,
                ast=stmt,
                elements=elements,
                lineage=lineage
            )

        except Exception as e:
            return None

    def _get_statement_type(self, stmt: exp.Expression) -> str:
        """Get the type of SQL statement."""
        type_map = {
            exp.Select: "SELECT",
            exp.Insert: "INSERT",
            exp.Update: "UPDATE",
            exp.Delete: "DELETE",
            exp.Merge: "MERGE",
            exp.Create: "CREATE",
            exp.Drop: "DROP",
            exp.Alter: "ALTER",
            exp.Union: "UNION",
        }

        for exp_type, name in type_map.items():
            if isinstance(stmt, exp_type):
                # Distinguish SELECT INTO from plain SELECT
                if exp_type == exp.Select and stmt.args.get('into'):
                    return "SELECT INTO"
                return name

        return "UNKNOWN"

    def _get_target_table(self, stmt: exp.Expression) -> Optional[str]:
        """Extract target table from statement."""
        try:
            if isinstance(stmt, exp.Insert):
                table_expr = stmt.this
                if isinstance(table_expr, exp.Table):
                    return self._format_table_name(table_expr)
                elif hasattr(table_expr, 'this') and isinstance(table_expr.this, exp.Table):
                    return self._format_table_name(table_expr.this)

            elif isinstance(stmt, exp.Update):
                table_expr = stmt.this
                if isinstance(table_expr, exp.Table):
                    return self._format_table_name(table_expr)

            elif isinstance(stmt, exp.Delete):
                table_expr = stmt.this
                if isinstance(table_expr, exp.Table):
                    return self._format_table_name(table_expr)

            elif isinstance(stmt, exp.Merge):
                table_expr = stmt.this
                if isinstance(table_expr, exp.Table):
                    return self._format_table_name(table_expr)

            elif isinstance(stmt, exp.Create):
                table_expr = stmt.this
                if isinstance(table_expr, exp.Table):
                    return self._format_table_name(table_expr)
                elif hasattr(table_expr, 'this'):
                    return self._format_table_name(table_expr.this)

            elif isinstance(stmt, exp.Select):
                # Handle SELECT ... INTO variable (Teradata SPL)
                into = stmt.args.get('into')
                if into:
                    for tbl in into.find_all(exp.Table):
                        return self._format_table_name(tbl)

        except Exception:
            pass

        return None

    def _get_source_tables(self, stmt: exp.Expression,
                           target_table: Optional[str]) -> List[str]:
        """Extract all source tables from statement."""
        tables = set()

        try:
            for table in stmt.find_all(exp.Table):
                table_name = self._format_table_name(table)
                # Exclude target table
                if table_name and table_name != target_table:
                    tables.add(table_name)
        except Exception:
            pass

        return list(tables)

    def _format_table_name(self, table: exp.Table) -> str:
        """Format table name with optional schema."""
        if not table:
            return ""

        name = table.name if hasattr(table, 'name') else str(table)

        if hasattr(table, 'db') and table.db:
            name = f"{table.db}.{name}"

        if hasattr(table, 'catalog') and table.catalog:
            name = f"{table.catalog}.{name}"

        return name

    def _build_values_lineage(self, stmt: exp.Insert, target_table: Optional[str]) -> Optional[LineageGraph]:
        """
        Build lineage for INSERT...VALUES statements.

        Maps each target column to its corresponding value expression
        (variable, literal, or system function).

        Args:
            stmt: Parsed INSERT expression
            target_table: Target table name

        Returns:
            LineageGraph with one edge per column, or None
        """
        try:
            # Get target columns from the INSERT column list
            schema_node = stmt.find(exp.Schema)
            if not schema_node:
                return None
            target_cols = [col.name for col in schema_node.find_all(exp.ColumnDef)
                          if hasattr(col, 'name')]
            if not target_cols:
                # Try Column nodes instead
                target_cols = [col.name for col in schema_node.find_all(exp.Column)
                              if hasattr(col, 'name')]
            if not target_cols:
                # Fallback: parse column identifiers from schema expressions
                target_cols = []
                for expr_node in schema_node.expressions:
                    if hasattr(expr_node, 'name'):
                        target_cols.append(expr_node.name)
                    elif hasattr(expr_node, 'this') and hasattr(expr_node.this, 'name'):
                        target_cols.append(expr_node.this.name)
                    else:
                        target_cols.append(str(expr_node))

            # Get values from the VALUES clause
            values_node = stmt.find(exp.Values)
            if not values_node:
                return None

            # Get the tuple of values
            value_exprs = []
            tuple_node = values_node.find(exp.Tuple)
            if tuple_node:
                value_exprs = list(tuple_node.expressions)
            else:
                value_exprs = list(values_node.expressions)

            if len(target_cols) != len(value_exprs):
                return None

            graph = LineageGraph()
            tgt_table = target_table or ""

            for col_name, val_expr in zip(target_cols, value_exprs):
                val_sql = val_expr.sql(dialect=self.dialect)

                # Classify the value expression
                if isinstance(val_expr, exp.Literal):
                    src_table = "LITERAL"
                    src_col = val_sql
                    tx_type = TransformationType.DIRECT
                    tx_subtype = TransformationSubtype.RENAME if src_col.upper() != col_name.upper() else TransformationSubtype.IDENTITY
                elif isinstance(val_expr, exp.CurrentTimestamp):
                    src_table = "SYSTEM"
                    src_col = "CURRENT_TIMESTAMP"
                    tx_type = TransformationType.INDIRECT
                    tx_subtype = TransformationSubtype.TRANSFORMATION
                elif isinstance(val_expr, (exp.Placeholder, exp.Parameter)) or val_sql.startswith(':'):
                    src_table = "VARIABLE"
                    src_col = val_sql.lstrip(':')
                    tx_type = TransformationType.DIRECT
                    tx_subtype = TransformationSubtype.RENAME if src_col.upper() != col_name.upper() else TransformationSubtype.IDENTITY
                elif isinstance(val_expr, (exp.Column, exp.Var)):
                    src_table = "VARIABLE"
                    src_col = val_expr.name if hasattr(val_expr, 'name') else val_sql
                    tx_type = TransformationType.DIRECT
                    tx_subtype = TransformationSubtype.RENAME if src_col.upper() != col_name.upper() else TransformationSubtype.IDENTITY
                else:
                    src_table = "EXPRESSION"
                    src_col = val_sql
                    tx_type = TransformationType.INDIRECT
                    tx_subtype = TransformationSubtype.TRANSFORMATION

                source = ColumnRef(table_name=src_table, column_name=src_col)
                target = ColumnRef(table_name=tgt_table, column_name=col_name)
                transformation = TransformationInfo(
                    type=tx_type,
                    subtype=tx_subtype,
                    description=val_sql,
                    sql_expression=val_sql
                )
                graph.add_lineage(source, target, transformation, dml_operation="INSERT")

            return graph
        except Exception:
            return None

    def _process_raw_sql(self, sql: str, index: int, source_file: str) -> Optional[SQLStatement]:
        """
        Process raw SQL string (used for extracted INSERT statements from procedures).

        Args:
            sql: SQL string to process
            index: Statement index
            source_file: Source file name

        Returns:
            SQLStatement or None
        """
        try:
            # Normalize the SQL first (handle Teradata-specific syntax)
            normalized_sql = self._normalize_sql(sql)

            # Try to parse the SQL
            stmt = sqlglot.parse_one(normalized_sql, read=self.dialect)
            if stmt:
                return self._process_statement(stmt, index, source_file)
        except Exception as e:
            # If parsing fails, still try to extract lineage with the raw SQL
            try:
                stmt_id = f"{os.path.basename(source_file)}_{index+1}"

                # Extract target table using regex
                target_match = re.search(
                    r'INSERT\s+INTO\s+([\w.]+)',
                    sql,
                    re.IGNORECASE
                )
                target_table = target_match.group(1) if target_match else None

                # Extract source tables using regex (from FROM and JOIN clauses)
                source_tables = []
                from_matches = re.findall(
                    r'(?:FROM|JOIN)\s+([\w.]+)',
                    sql,
                    re.IGNORECASE
                )
                for table in from_matches:
                    if table.upper() != (target_table or '').upper():
                        source_tables.append(table)

                # Try lineage extraction anyway
                try:
                    lineage_extractor = LineageExtractor(
                        schema=self.schema,
                        dialect=self.dialect
                    )
                    lineage = lineage_extractor.extract_lineage(sql)
                except Exception:
                    lineage = LineageGraph()

                return SQLStatement(
                    statement_id=stmt_id,
                    statement_type="INSERT",
                    target_table=target_table,
                    source_tables=list(set(source_tables)),
                    source_file=source_file,
                    raw_sql=sql,
                    ast=None,
                    elements=None,
                    lineage=lineage
                )
            except Exception:
                pass

        return None
