"""
Tree Renderer module.

Generates collapsible tree visualization showing data flow from source to target.
Structure: Source Tables → Intermediate Tables (CTEs/Subqueries) → Target Table
Expandable at table level to show column flows with transformation logic.
"""

from typing import Dict, List, Any, Optional, Set, Tuple
from collections import defaultdict
import html as html_escape
import json


class TreeRenderer:
    """
    Renders lineage as a flow-based collapsible tree structure.

    Structure:
    - DATA FLOW DIAGRAM
      - Source Tables → Target Table (with intermediate hops if present)
      - Each table expandable to show column-level flows
      - Each column shows transformation logic when clicked
    """

    def __init__(self):
        """Initialize the tree renderer."""
        pass

    def render(self, lineage_graph, output_path: str, title: str = "Data Lineage Flow",
               element_catalog=None) -> None:
        """
        Render lineage as flow-based collapsible tree HTML.

        Args:
            lineage_graph: LineageGraph object
            output_path: Path to output HTML file
            title: Title for the visualization
            element_catalog: Optional ElementCatalog for CTE/intermediate table info
        """
        # Build flow structure from lineage
        flow_data = self._build_flow_structure(lineage_graph, element_catalog)

        # Generate HTML
        html_content = self._generate_html(flow_data, title)

        with open(output_path, 'w', encoding='utf-8') as f:
            f.write(html_content)

    def _build_flow_structure(self, lineage_graph, element_catalog=None) -> Dict:
        """
        Build flow structure showing source → intermediate → target paths.

        Returns:
            Dict with flow paths, tables, and column mappings
        """
        # Identify source tables, target table, and intermediate tables
        source_tables: Set[str] = set()
        target_tables: Set[str] = set()
        intermediate_tables: Set[str] = set()

        # Column mappings: target_table -> target_col -> list of (source_table, source_col, transformation)
        column_flows = defaultdict(lambda: defaultdict(list))

        # Collect all edges
        all_edges = []

        for edge in lineage_graph.edges:
            source_table = edge.source.table_name or "[Unknown]"
            source_column = edge.source.column_name
            target_table = edge.target.table_name or "[Unknown]"
            target_column = edge.target.column_name

            source_tables.add(source_table)
            target_tables.add(target_table)

            flow_info = {
                'source_table': source_table,
                'source_column': source_column,
                'target_table': target_table,
                'target_column': target_column,
                'type': edge.transformation.type.value if hasattr(edge.transformation.type, 'value') else edge.transformation.type,
                'subtype': edge.transformation.subtype.value if hasattr(edge.transformation.subtype, 'value') else edge.transformation.subtype,
                'sql_expression': edge.transformation.sql_expression,
                'description': edge.transformation.description
            }

            column_flows[target_table][target_column].append(flow_info)
            all_edges.append(flow_info)

        # Identify CTEs as intermediate tables (from element_catalog if available)
        cte_tables: Set[str] = set()
        if element_catalog and hasattr(element_catalog, 'ctes') and element_catalog.ctes:
            for cte in element_catalog.ctes:
                cte_tables.add(cte.name.upper())

        # Determine which tables are intermediate (appear in both source and target)
        for table in source_tables.intersection(target_tables):
            intermediate_tables.add(table)

        # Also add CTE tables as intermediate if they appear
        for table in source_tables:
            table_upper = table.upper()
            # Check if table name matches a CTE
            for cte_name in cte_tables:
                if cte_name in table_upper or table_upper in cte_name:
                    intermediate_tables.add(table)

        # Pure source tables (not intermediate)
        pure_source_tables = source_tables - intermediate_tables
        # Pure target tables (not intermediate)
        pure_target_tables = target_tables - intermediate_tables

        # Build flow paths: groups of source → target with same transformation chain
        flow_paths = self._build_flow_paths(all_edges, pure_source_tables, intermediate_tables, pure_target_tables)

        # Build table summaries
        table_summaries = {}
        for table in source_tables.union(target_tables):
            table_summaries[table] = {
                'role': self._determine_table_role(table, pure_source_tables, intermediate_tables, pure_target_tables),
                'columns_as_source': set(),
                'columns_as_target': set()
            }

        for edge in all_edges:
            if edge['source_table'] in table_summaries:
                table_summaries[edge['source_table']]['columns_as_source'].add(edge['source_column'])
            if edge['target_table'] in table_summaries:
                table_summaries[edge['target_table']]['columns_as_target'].add(edge['target_column'])

        # Convert sets to lists for JSON serialization
        for table, summary in table_summaries.items():
            summary['columns_as_source'] = list(summary['columns_as_source'])
            summary['columns_as_target'] = list(summary['columns_as_target'])

        return {
            'source_tables': list(pure_source_tables),
            'target_tables': list(pure_target_tables),
            'intermediate_tables': list(intermediate_tables),
            'column_flows': {k: dict(v) for k, v in column_flows.items()},
            'flow_paths': flow_paths,
            'table_summaries': table_summaries,
            'stats': {
                'total_source_tables': len(pure_source_tables),
                'total_target_tables': len(pure_target_tables),
                'total_intermediate_tables': len(intermediate_tables),
                'total_mappings': len(all_edges)
            }
        }

    def _determine_table_role(self, table: str, source_tables: Set[str],
                              intermediate_tables: Set[str], target_tables: Set[str]) -> str:
        """Determine the role of a table in the data flow."""
        if table in intermediate_tables:
            return 'intermediate'
        elif table in target_tables:
            return 'target'
        elif table in source_tables:
            return 'source'
        return 'unknown'

    def _build_flow_paths(self, edges: List[Dict], source_tables: Set[str],
                          intermediate_tables: Set[str], target_tables: Set[str]) -> List[Dict]:
        """
        Build flow paths showing table-level data flow.

        Returns:
            List of flow path dictionaries
        """
        # Group edges by target table
        target_grouped = defaultdict(list)
        for edge in edges:
            target_grouped[edge['target_table']].append(edge)

        flow_paths = []

        for target_table in target_tables:
            if target_table not in target_grouped:
                continue

            # Get all unique source tables for this target
            sources_for_target = set()
            for edge in target_grouped.get(target_table, []):
                sources_for_target.add(edge['source_table'])

            # Determine path type
            has_hardcoded = "[HARDCODED]" in sources_for_target
            regular_sources = [s for s in sources_for_target if s != "[HARDCODED]"]

            flow_path = {
                'target_table': target_table,
                'source_tables': regular_sources,
                'has_hardcoded_values': has_hardcoded,
                'column_count': len(target_grouped.get(target_table, []))
            }
            flow_paths.append(flow_path)

        return flow_paths

    def _generate_html(self, flow_data: Dict, title: str) -> str:
        """Generate the complete HTML document with flow visualization."""

        # Build the flow diagram HTML
        flow_diagram_html = self._build_flow_diagram_html(flow_data)

        # Build the detailed lineage section
        lineage_detail_html = self._build_lineage_detail_html(flow_data)

        stats = flow_data['stats']

        return f'''<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{html_escape.escape(title)}</title>
    <style>
{self._get_css()}
    </style>
</head>
<body>
    <header class="main-header">
        <h1>{html_escape.escape(title)}</h1>
        <div class="stats">
            <span class="stat"><strong>{stats['total_source_tables']}</strong> Source Tables</span>
            <span class="stat"><strong>{stats['total_intermediate_tables']}</strong> Intermediate Tables</span>
            <span class="stat"><strong>{stats['total_target_tables']}</strong> Target Tables</span>
            <span class="stat"><strong>{stats['total_mappings']}</strong> Column Mappings</span>
        </div>
    </header>

    <div class="controls">
        <button onclick="expandAll()">Expand All</button>
        <button onclick="collapseAll()">Collapse All</button>
        <input type="text" id="searchBox" placeholder="Search tables or columns..." onkeyup="searchTree()">
    </div>

    <div class="container">
        <!-- Flow Diagram Section -->
        <section class="flow-section">
            <h2>Data Flow Overview</h2>
            <div class="flow-diagram">
                {flow_diagram_html}
            </div>
        </section>

        <!-- Detailed Lineage Section -->
        <section class="lineage-section">
            <h2>Column-Level Lineage <span class="subtitle">(click tables to expand column details)</span></h2>
            <div class="tree-container">
                {lineage_detail_html}
            </div>
        </section>
    </div>

    <div id="detailPanel" class="detail-panel hidden">
        <div class="detail-header">
            <h3 id="detailTitle">Transformation Details</h3>
            <button onclick="closeDetail()">&times;</button>
        </div>
        <div id="detailContent" class="detail-content"></div>
    </div>

    <script>
{self._get_javascript()}
    </script>
</body>
</html>'''

    def _build_flow_diagram_html(self, flow_data: Dict) -> str:
        """Build the visual flow diagram showing source → intermediate → target."""
        source_tables = flow_data['source_tables']
        intermediate_tables = flow_data['intermediate_tables']
        target_tables = flow_data['target_tables']
        table_summaries = flow_data['table_summaries']

        # Check if there are hardcoded values
        has_hardcoded = any(t.startswith('[HARDCODED]') for t in table_summaries.keys())

        html_parts = ['<div class="flow-container">']

        # Source Tables Column
        html_parts.append('<div class="flow-column source-column">')
        html_parts.append('<div class="column-header">Source Tables</div>')
        html_parts.append('<div class="column-content">')

        for table in sorted(source_tables):
            if table == "[HARDCODED]":
                continue
            safe_table = html_escape.escape(table)
            summary = table_summaries.get(table, {})
            col_count = len(summary.get('columns_as_source', []))
            html_parts.append(f'''
                <div class="flow-table source-table" onclick="scrollToTable('{self._make_id(table)}')">
                    <span class="table-icon">&#128451;</span>
                    <span class="table-name">{safe_table}</span>
                    <span class="col-count">{col_count} cols</span>
                </div>
            ''')

        # Add hardcoded values as a special source
        if "[HARDCODED]" in table_summaries:
            summary = table_summaries.get("[HARDCODED]", {})
            col_count = len(summary.get('columns_as_source', []))
            html_parts.append(f'''
                <div class="flow-table hardcoded-table" onclick="scrollToTable('{self._make_id('[HARDCODED]')}')">
                    <span class="table-icon">&#128273;</span>
                    <span class="table-name">Hardcoded Values</span>
                    <span class="col-count">{col_count} values</span>
                </div>
            ''')

        html_parts.append('</div></div>')

        # Intermediate Tables Column (if any)
        if intermediate_tables:
            html_parts.append('<div class="flow-arrow">&#10140;</div>')
            html_parts.append('<div class="flow-column intermediate-column">')
            html_parts.append('<div class="column-header">Intermediate Tables</div>')
            html_parts.append('<div class="column-content">')

            for table in sorted(intermediate_tables):
                safe_table = html_escape.escape(table)
                summary = table_summaries.get(table, {})
                col_count_src = len(summary.get('columns_as_source', []))
                col_count_tgt = len(summary.get('columns_as_target', []))
                html_parts.append(f'''
                    <div class="flow-table intermediate-table" onclick="scrollToTable('{self._make_id(table)}')">
                        <span class="table-icon">&#128260;</span>
                        <span class="table-name">{safe_table}</span>
                        <span class="col-count">{col_count_tgt}→{col_count_src}</span>
                    </div>
                ''')

            html_parts.append('</div></div>')

        # Arrow to target
        html_parts.append('<div class="flow-arrow">&#10140;</div>')

        # Target Tables Column
        html_parts.append('<div class="flow-column target-column">')
        html_parts.append('<div class="column-header">Target Tables</div>')
        html_parts.append('<div class="column-content">')

        for table in sorted(target_tables):
            safe_table = html_escape.escape(table)
            summary = table_summaries.get(table, {})
            col_count = len(summary.get('columns_as_target', []))
            html_parts.append(f'''
                <div class="flow-table target-table" onclick="scrollToTable('{self._make_id(table)}')">
                    <span class="table-icon">&#127919;</span>
                    <span class="table-name">{safe_table}</span>
                    <span class="col-count">{col_count} cols</span>
                </div>
            ''')

        html_parts.append('</div></div>')
        html_parts.append('</div>')

        return '\n'.join(html_parts)

    def _build_lineage_detail_html(self, flow_data: Dict) -> str:
        """Build the detailed lineage tree showing column-level flows."""
        html_parts = []

        target_tables = flow_data['target_tables']
        column_flows = flow_data['column_flows']
        table_summaries = flow_data['table_summaries']

        # Build tree for each target table
        for target_table in sorted(target_tables):
            if target_table not in column_flows:
                continue

            columns = column_flows[target_table]
            safe_table = html_escape.escape(target_table)
            table_id = self._make_id(target_table)

            html_parts.append(f'''
            <div class="tree-node target-table-node" id="{table_id}" data-name="{safe_table.lower()}">
                <div class="node-header target-header" onclick="toggleNode(this)">
                    <span class="toggle-icon">&#9658;</span>
                    <span class="table-icon">&#127919;</span>
                    <span class="node-name">TARGET: {safe_table}</span>
                    <span class="badge">{len(columns)} columns</span>
                </div>
                <div class="node-children" style="display: none;">
                    {self._build_target_columns_html(target_table, columns)}
                </div>
            </div>
            ''')

        # Build tree for source tables showing where their columns go
        source_tables = flow_data['source_tables']
        for source_table in sorted(source_tables):
            summary = table_summaries.get(source_table, {})
            source_cols = summary.get('columns_as_source', [])

            if not source_cols:
                continue

            safe_table = html_escape.escape(source_table)
            table_id = self._make_id(source_table)
            is_hardcoded = source_table == "[HARDCODED]"

            table_class = "hardcoded-table-node" if is_hardcoded else "source-table-node"
            icon = "&#128273;" if is_hardcoded else "&#128451;"
            label = "HARDCODED VALUES" if is_hardcoded else f"SOURCE: {safe_table}"

            # Get all flows from this source table
            source_flows = self._get_flows_from_source(source_table, column_flows)

            html_parts.append(f'''
            <div class="tree-node {table_class}" id="{table_id}" data-name="{safe_table.lower()}">
                <div class="node-header source-header" onclick="toggleNode(this)">
                    <span class="toggle-icon">&#9658;</span>
                    <span class="table-icon">{icon}</span>
                    <span class="node-name">{label}</span>
                    <span class="badge">{len(source_cols)} columns</span>
                </div>
                <div class="node-children" style="display: none;">
                    {self._build_source_flows_html(source_table, source_flows)}
                </div>
            </div>
            ''')

        return '\n'.join(html_parts)

    def _get_flows_from_source(self, source_table: str, column_flows: Dict) -> Dict:
        """Get all flows originating from a source table."""
        source_flows = defaultdict(list)

        for target_table, columns in column_flows.items():
            for target_col, flows in columns.items():
                for flow in flows:
                    if flow['source_table'] == source_table:
                        source_flows[flow['source_column']].append({
                            'target_table': target_table,
                            'target_column': target_col,
                            'type': flow['type'],
                            'subtype': flow['subtype'],
                            'sql_expression': flow['sql_expression'],
                            'description': flow['description']
                        })

        return dict(source_flows)

    def _build_target_columns_html(self, target_table: str, columns: Dict) -> str:
        """Build HTML for columns under a target table showing source flows."""
        html_parts = []

        for column_name in sorted(columns.keys()):
            flows = columns[column_name]
            source_count = len(flows)

            safe_column = html_escape.escape(column_name)

            # Get unique transformation types
            trans_types = set(f['subtype'] for f in flows)
            type_badges = ' '.join(
                f'<span class="type-badge type-{t.lower()}">{t}</span>'
                for t in trans_types
            )

            html_parts.append(f'''
            <div class="tree-node column-node" data-name="{safe_column.lower()}">
                <div class="node-header column-header" onclick="toggleNode(this)">
                    <span class="toggle-icon">&#9658;</span>
                    <span class="column-icon">&#9632;</span>
                    <span class="node-name">{safe_column}</span>
                    {type_badges}
                    <span class="badge source-badge">{source_count} source(s)</span>
                </div>
                <div class="node-children" style="display: none;">
                    {self._build_column_sources_html(flows)}
                </div>
            </div>
            ''')

        return '\n'.join(html_parts)

    def _build_column_sources_html(self, flows: List[Dict]) -> str:
        """Build HTML showing source columns for a target column."""
        html_parts = []

        for flow in flows:
            safe_source = html_escape.escape(f"{flow['source_table']}.{flow['source_column']}")
            safe_sql = html_escape.escape(flow['sql_expression'])
            safe_desc = html_escape.escape(flow['description'])
            subtype = flow['subtype']

            is_hardcoded = flow['source_table'] == "[HARDCODED]"
            source_class = "hardcoded-source" if is_hardcoded else ""

            html_parts.append(f'''
            <div class="flow-source-node {source_class}">
                <div class="flow-source-header">
                    <span class="flow-arrow-icon">&#8592;</span>
                    <span class="source-ref">{safe_source}</span>
                    <span class="type-badge type-{subtype.lower()}">{subtype}</span>
                </div>
                <div class="transformation-detail" onclick="showDetail(this)"
                     data-sql="{safe_sql}" data-desc="{safe_desc}"
                     data-source="{safe_source}">
                    <code>{safe_sql[:80]}{'...' if len(flow['sql_expression']) > 80 else ''}</code>
                    <span class="click-hint">Click for full SQL</span>
                </div>
            </div>
            ''')

        return '\n'.join(html_parts)

    def _build_source_flows_html(self, source_table: str, source_flows: Dict) -> str:
        """Build HTML showing where source columns flow to."""
        html_parts = []

        for source_column in sorted(source_flows.keys()):
            flows = source_flows[source_column]
            target_count = len(flows)

            safe_column = html_escape.escape(source_column)

            html_parts.append(f'''
            <div class="tree-node column-node" data-name="{safe_column.lower()}">
                <div class="node-header column-header" onclick="toggleNode(this)">
                    <span class="toggle-icon">&#9658;</span>
                    <span class="column-icon">&#9632;</span>
                    <span class="node-name">{safe_column}</span>
                    <span class="badge target-badge">{target_count} target(s)</span>
                </div>
                <div class="node-children" style="display: none;">
                    {self._build_column_targets_html(flows)}
                </div>
            </div>
            ''')

        return '\n'.join(html_parts)

    def _build_column_targets_html(self, flows: List[Dict]) -> str:
        """Build HTML showing target columns for a source column."""
        html_parts = []

        for flow in flows:
            safe_target = html_escape.escape(f"{flow['target_table']}.{flow['target_column']}")
            safe_sql = html_escape.escape(flow['sql_expression'])
            safe_desc = html_escape.escape(flow['description'])
            subtype = flow['subtype']

            html_parts.append(f'''
            <div class="flow-target-node">
                <div class="flow-target-header">
                    <span class="flow-arrow-icon">&#8594;</span>
                    <span class="target-ref">{safe_target}</span>
                    <span class="type-badge type-{subtype.lower()}">{subtype}</span>
                </div>
                <div class="transformation-detail" onclick="showDetail(this)"
                     data-sql="{safe_sql}" data-desc="{safe_desc}"
                     data-target="{safe_target}">
                    <code>{safe_sql[:80]}{'...' if len(flow['sql_expression']) > 80 else ''}</code>
                    <span class="click-hint">Click for full SQL</span>
                </div>
            </div>
            ''')

        return '\n'.join(html_parts)

    def _make_id(self, name: str) -> str:
        """Create a safe HTML ID from a name."""
        import re
        return re.sub(r'[^a-zA-Z0-9]', '_', name)

    def _get_css(self) -> str:
        """Return CSS styles."""
        return '''
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            background: #f5f7fa;
            color: #333;
        }

        .main-header {
            background: linear-gradient(135deg, #1a5276 0%, #2980b9 100%);
            color: white;
            padding: 1.5rem 2rem;
        }

        .main-header h1 {
            font-size: 1.5rem;
            margin-bottom: 0.5rem;
        }

        .stats {
            display: flex;
            gap: 2rem;
            flex-wrap: wrap;
        }

        .stat {
            font-size: 0.9rem;
            opacity: 0.9;
        }

        .stat strong {
            font-size: 1.1rem;
        }

        .controls {
            background: white;
            padding: 1rem 2rem;
            display: flex;
            gap: 1rem;
            align-items: center;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            flex-wrap: wrap;
        }

        .controls button {
            padding: 0.5rem 1rem;
            border: 1px solid #ddd;
            background: white;
            border-radius: 4px;
            cursor: pointer;
            transition: all 0.2s;
        }

        .controls button:hover {
            background: #f0f0f0;
        }

        .controls input {
            padding: 0.5rem 1rem;
            border: 1px solid #ddd;
            border-radius: 4px;
            width: 280px;
        }

        .container {
            padding: 2rem;
            max-width: 1600px;
            margin: 0 auto;
        }

        /* Flow Diagram Section */
        .flow-section {
            margin-bottom: 2rem;
        }

        .flow-section h2 {
            margin-bottom: 1rem;
            color: #1a5276;
        }

        .flow-diagram {
            background: white;
            border-radius: 8px;
            padding: 1.5rem;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
            overflow-x: auto;
        }

        .flow-container {
            display: flex;
            align-items: flex-start;
            justify-content: center;
            gap: 1rem;
            min-width: fit-content;
        }

        .flow-column {
            min-width: 250px;
            max-width: 350px;
        }

        .column-header {
            font-weight: 600;
            padding: 0.75rem 1rem;
            border-radius: 6px 6px 0 0;
            text-align: center;
            color: white;
        }

        .source-column .column-header {
            background: #27ae60;
        }

        .intermediate-column .column-header {
            background: #f39c12;
        }

        .target-column .column-header {
            background: #2980b9;
        }

        .column-content {
            background: #f8f9fa;
            border: 1px solid #e0e0e0;
            border-top: none;
            border-radius: 0 0 6px 6px;
            padding: 0.5rem;
            max-height: 300px;
            overflow-y: auto;
        }

        .flow-table {
            display: flex;
            align-items: center;
            gap: 0.5rem;
            padding: 0.6rem 0.8rem;
            margin: 0.3rem 0;
            background: white;
            border-radius: 4px;
            cursor: pointer;
            transition: all 0.2s;
            border-left: 3px solid transparent;
        }

        .flow-table:hover {
            background: #eef5fc;
            transform: translateX(2px);
        }

        .source-table {
            border-left-color: #27ae60;
        }

        .intermediate-table {
            border-left-color: #f39c12;
        }

        .target-table {
            border-left-color: #2980b9;
        }

        .hardcoded-table {
            border-left-color: #8e44ad;
            background: #faf5ff;
        }

        .flow-table .table-icon {
            font-size: 1rem;
        }

        .flow-table .table-name {
            flex: 1;
            font-size: 0.85rem;
            font-weight: 500;
            word-break: break-word;
        }

        .flow-table .col-count {
            font-size: 0.75rem;
            color: #666;
            background: #e9ecef;
            padding: 0.2rem 0.4rem;
            border-radius: 3px;
        }

        .flow-arrow {
            font-size: 2rem;
            color: #95a5a6;
            align-self: center;
            padding: 0 0.5rem;
        }

        /* Lineage Detail Section */
        .lineage-section {
            margin-top: 2rem;
        }

        .lineage-section h2 {
            margin-bottom: 1rem;
            color: #1a5276;
        }

        .lineage-section h2 .subtitle {
            font-size: 0.8rem;
            font-weight: normal;
            color: #666;
        }

        .tree-container {
            background: white;
            border-radius: 8px;
            padding: 1rem;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
        }

        .tree-node {
            margin: 0.3rem 0;
        }

        .node-header {
            display: flex;
            align-items: center;
            padding: 0.6rem 0.8rem;
            cursor: pointer;
            border-radius: 4px;
            transition: background 0.2s;
            gap: 0.5rem;
        }

        .node-header:hover {
            background: #f0f4f8;
        }

        .target-header {
            background: #ebf5fb;
            border-left: 4px solid #2980b9;
        }

        .source-header {
            background: #eafaf1;
            border-left: 4px solid #27ae60;
        }

        .toggle-icon {
            font-size: 0.7rem;
            color: #666;
            width: 1rem;
            transition: transform 0.2s;
        }

        .expanded > .node-header .toggle-icon {
            transform: rotate(90deg);
        }

        .table-icon {
            font-size: 1.1rem;
        }

        .column-icon {
            font-size: 0.8rem;
            color: #666;
        }

        .node-name {
            font-weight: 500;
            flex: 1;
        }

        .target-table-node > .node-header .node-name {
            color: #2980b9;
        }

        .source-table-node > .node-header .node-name {
            color: #27ae60;
        }

        .hardcoded-table-node > .node-header .node-name {
            color: #8e44ad;
        }

        .badge {
            font-size: 0.75rem;
            padding: 0.2rem 0.5rem;
            background: #e0e0e0;
            border-radius: 10px;
            color: #555;
        }

        .source-badge {
            background: #d4edda;
            color: #155724;
        }

        .target-badge {
            background: #cce5ff;
            color: #004085;
        }

        .type-badge {
            font-size: 0.65rem;
            padding: 0.15rem 0.4rem;
            border-radius: 3px;
            text-transform: uppercase;
            font-weight: 600;
        }

        .type-badge.type-identity { background: #d4edda; color: #155724; }
        .type-badge.type-cast { background: #fff3cd; color: #856404; }
        .type-badge.type-transformation { background: #cce5ff; color: #004085; }
        .type-badge.type-case_logic { background: #f8d7da; color: #721c24; }
        .type-badge.type-aggregation { background: #d1ecf1; color: #0c5460; }
        .type-badge.type-rename { background: #e2e3e5; color: #383d41; }
        .type-badge.type-constant { background: #e8daef; color: #6c3483; }

        .node-children {
            margin-left: 1.5rem;
            border-left: 1px dashed #ddd;
            padding-left: 0.5rem;
        }

        .column-header {
            background: #f8f9fa;
        }

        /* Flow source/target nodes */
        .flow-source-node, .flow-target-node {
            background: #f8f9fa;
            border-radius: 4px;
            margin: 0.5rem 0;
            padding: 0.75rem;
            border-left: 3px solid #27ae60;
        }

        .flow-target-node {
            border-left-color: #2980b9;
        }

        .hardcoded-source {
            border-left-color: #8e44ad;
            background: #faf5ff;
        }

        .flow-source-header, .flow-target-header {
            display: flex;
            align-items: center;
            gap: 0.5rem;
            margin-bottom: 0.5rem;
        }

        .flow-arrow-icon {
            font-size: 1rem;
            color: #666;
        }

        .source-ref {
            font-family: 'Consolas', monospace;
            font-size: 0.85rem;
            color: #27ae60;
            background: #eafaf1;
            padding: 0.2rem 0.5rem;
            border-radius: 3px;
        }

        .target-ref {
            font-family: 'Consolas', monospace;
            font-size: 0.85rem;
            color: #2980b9;
            background: #ebf5fb;
            padding: 0.2rem 0.5rem;
            border-radius: 3px;
        }

        .transformation-detail {
            background: white;
            padding: 0.5rem;
            border-radius: 4px;
            cursor: pointer;
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }

        .transformation-detail:hover {
            background: #f0f0f0;
        }

        .transformation-detail code {
            font-family: 'Consolas', monospace;
            font-size: 0.8rem;
            color: #333;
            flex: 1;
            word-break: break-all;
        }

        .click-hint {
            font-size: 0.7rem;
            color: #999;
            white-space: nowrap;
        }

        /* Detail Panel */
        .detail-panel {
            position: fixed;
            top: 0;
            right: 0;
            width: 500px;
            height: 100vh;
            background: white;
            box-shadow: -4px 0 20px rgba(0,0,0,0.2);
            z-index: 1000;
            display: flex;
            flex-direction: column;
            transform: translateX(100%);
            transition: transform 0.3s ease;
        }

        .detail-panel.visible {
            transform: translateX(0);
        }

        .detail-panel.hidden {
            transform: translateX(100%);
        }

        .detail-header {
            background: #1a5276;
            color: white;
            padding: 1rem;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .detail-header button {
            background: none;
            border: none;
            color: white;
            font-size: 1.5rem;
            cursor: pointer;
        }

        .detail-content {
            padding: 1.5rem;
            overflow-y: auto;
            flex: 1;
        }

        .detail-content h4 {
            margin: 1rem 0 0.5rem;
            color: #1a5276;
        }

        .detail-content h4:first-child {
            margin-top: 0;
        }

        .detail-content pre {
            background: #f4f4f4;
            padding: 1rem;
            border-radius: 4px;
            overflow-x: auto;
            font-family: 'Consolas', monospace;
            font-size: 0.85rem;
            white-space: pre-wrap;
            word-break: break-all;
        }

        .highlight {
            background: yellow !important;
        }

        @media (max-width: 900px) {
            .flow-container {
                flex-direction: column;
                align-items: stretch;
            }

            .flow-arrow {
                transform: rotate(90deg);
                text-align: center;
            }

            .flow-column {
                max-width: none;
            }

            .controls {
                flex-direction: column;
                align-items: stretch;
            }

            .detail-panel {
                width: 100%;
            }
        }
        '''

    def _get_javascript(self) -> str:
        """Return JavaScript code."""
        return '''
        function toggleNode(header) {
            const node = header.parentElement;
            const children = node.querySelector('.node-children');

            if (children) {
                const isExpanded = children.style.display !== 'none';
                children.style.display = isExpanded ? 'none' : 'block';
                node.classList.toggle('expanded', !isExpanded);
            }
        }

        function expandAll() {
            document.querySelectorAll('.node-children').forEach(el => {
                el.style.display = 'block';
                el.parentElement.classList.add('expanded');
            });
        }

        function collapseAll() {
            document.querySelectorAll('.node-children').forEach(el => {
                el.style.display = 'none';
                el.parentElement.classList.remove('expanded');
            });
        }

        function scrollToTable(tableId) {
            const element = document.getElementById(tableId);
            if (element) {
                element.scrollIntoView({ behavior: 'smooth', block: 'start' });
                // Expand the table
                const header = element.querySelector('.node-header');
                const children = element.querySelector('.node-children');
                if (children && children.style.display === 'none') {
                    children.style.display = 'block';
                    element.classList.add('expanded');
                }
                // Highlight briefly
                element.classList.add('highlight');
                setTimeout(() => element.classList.remove('highlight'), 2000);
            }
        }

        function searchTree() {
            const searchTerm = document.getElementById('searchBox').value.toLowerCase();
            const nodes = document.querySelectorAll('.tree-node');

            // Remove all highlights first
            document.querySelectorAll('.highlight').forEach(el => {
                el.classList.remove('highlight');
            });

            if (searchTerm.length < 2) {
                // Show all nodes
                nodes.forEach(node => {
                    node.style.display = 'block';
                });
                return;
            }

            nodes.forEach(node => {
                const name = node.getAttribute('data-name') || '';
                const matches = name.includes(searchTerm);

                if (matches) {
                    node.style.display = 'block';
                    // Highlight matching node
                    const header = node.querySelector('.node-header');
                    if (header) header.classList.add('highlight');
                    // Expand parent nodes
                    let parent = node.parentElement;
                    while (parent) {
                        if (parent.classList.contains('node-children')) {
                            parent.style.display = 'block';
                            parent.parentElement.classList.add('expanded');
                        }
                        parent = parent.parentElement;
                    }
                } else {
                    // Check if any children match
                    const childMatches = node.querySelectorAll('[data-name*="' + searchTerm + '"]');
                    if (childMatches.length > 0) {
                        node.style.display = 'block';
                    }
                }
            });
        }

        function showDetail(element) {
            const sql = element.getAttribute('data-sql');
            const desc = element.getAttribute('data-desc');
            const source = element.getAttribute('data-source');
            const target = element.getAttribute('data-target');

            const panel = document.getElementById('detailPanel');
            const content = document.getElementById('detailContent');

            let flowInfo = '';
            if (source) {
                flowInfo = '<h4>Source</h4><p>' + source + '</p>';
            }
            if (target) {
                flowInfo = '<h4>Target</h4><p>' + target + '</p>';
            }

            content.innerHTML = `
                ${flowInfo}
                <h4>Transformation SQL</h4>
                <pre>${sql}</pre>
                <h4>Description</h4>
                <p>${desc || 'No description available'}</p>
            `;

            panel.classList.remove('hidden');
            panel.classList.add('visible');
        }

        function closeDetail() {
            const panel = document.getElementById('detailPanel');
            panel.classList.remove('visible');
            panel.classList.add('hidden');
        }

        // Close detail panel on escape key
        document.addEventListener('keydown', function(e) {
            if (e.key === 'Escape') {
                closeDetail();
            }
        });
        '''
