"""
PyVis Renderer for interactive HTML visualization.

Uses pyvis library to create interactive, zoomable lineage diagrams.
"""

import sys
import os
from typing import Dict, Any, Optional

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

from visualization.visual_models import VisualLineageGraph, VisualConfig


class PyVisRenderer:
    """Render visual lineage to interactive HTML using pyvis."""

    def __init__(self, visual_graph: VisualLineageGraph, theme: str = 'default'):
        """
        Initialize renderer.

        Args:
            visual_graph: Visual lineage graph to render
            theme: Visual theme (default, dark, print)
        """
        self.graph = visual_graph
        self.theme = theme

    def render(self, output_path: str,
               height: str = "800px",
               width: str = "100%",
               notebook: bool = False) -> str:
        """
        Render to interactive HTML file.

        Args:
            output_path: Path to save HTML file
            height: Visualization height
            width: Visualization width
            notebook: If True, optimize for Jupyter notebooks

        Returns:
            Path to generated HTML file
        """
        try:
            from pyvis.network import Network
        except ImportError:
            raise ImportError(
                "pyvis is required for interactive visualization. "
                "Install with: pip install pyvis"
            )

        # Create network with hierarchical layout
        net = Network(
            height=height,
            width=width,
            directed=True,
            notebook=notebook,
            heading=self.graph.title,
            bgcolor=self._get_background_color(),
            font_color=self._get_font_color()
        )

        # Configure options
        net.set_options(self._get_options())

        # Add nodes grouped by table
        for table, columns in self.graph.get_tables_grouped().items():
            for node in columns:
                net.add_node(
                    node.id,
                    label=node.label,
                    title=node._build_tooltip(),
                    color=node.color,
                    size=node.size,
                    shape=node.shape,
                    group=node.group,
                    level=node.level
                )

        # Add edges
        for edge in self.graph.edges:
            net.add_edge(
                edge.source_id,
                edge.target_id,
                title=edge._build_tooltip(),
                color=edge.color,
                width=edge.width,
                dashes=edge.style == "dashed",
                arrows={'to': {'enabled': True}}
            )

        # Save and return path
        net.save_graph(output_path)

        # Enhance the generated HTML with custom features
        self._enhance_html(output_path)

        return output_path

    def _get_options(self) -> str:
        """Get pyvis options for hierarchical layout."""
        direction = self.graph.direction or "LR"

        return f"""
{{
    "layout": {{
        "hierarchical": {{
            "enabled": true,
            "direction": "{direction}",
            "sortMethod": "directed",
            "levelSeparation": 250,
            "nodeSpacing": 150,
            "treeSpacing": 200,
            "blockShifting": true,
            "edgeMinimization": true,
            "parentCentralization": true
        }}
    }},
    "physics": {{
        "enabled": false
    }},
    "nodes": {{
        "font": {{
            "size": 14,
            "face": "Arial"
        }},
        "borderWidth": 2,
        "shadow": true
    }},
    "edges": {{
        "smooth": {{
            "type": "cubicBezier",
            "forceDirection": "horizontal",
            "roundness": 0.4
        }},
        "font": {{
            "size": 10,
            "align": "middle"
        }}
    }},
    "interaction": {{
        "hover": true,
        "tooltipDelay": 200,
        "navigationButtons": true,
        "keyboard": {{
            "enabled": true,
            "bindToWindow": false
        }},
        "zoomView": true,
        "dragView": true
    }}
}}
        """

    def _get_background_color(self) -> str:
        """Get background color based on theme."""
        if self.theme == 'dark':
            return '#1a1a2e'
        return '#ffffff'

    def _get_font_color(self) -> str:
        """Get font color based on theme."""
        if self.theme == 'dark':
            return '#ffffff'
        return '#000000'

    def _enhance_html(self, output_path: str) -> None:
        """Enhance generated HTML with legend and controls."""
        try:
            with open(output_path, 'r', encoding='utf-8') as f:
                html = f.read()

            # Add legend
            legend_html = self._generate_legend()

            # Insert legend before closing body tag
            html = html.replace('</body>', f'{legend_html}</body>')

            # Add title styling
            title_style = """
<style>
    h1 { font-family: Arial, sans-serif; color: #333; padding: 10px; }
    .legend {
        position: fixed;
        top: 10px;
        right: 10px;
        background: white;
        border: 1px solid #ccc;
        border-radius: 5px;
        padding: 10px;
        font-family: Arial, sans-serif;
        font-size: 12px;
        box-shadow: 2px 2px 5px rgba(0,0,0,0.2);
        z-index: 1000;
    }
    .legend-item { margin: 5px 0; }
    .legend-color {
        display: inline-block;
        width: 15px;
        height: 15px;
        margin-right: 8px;
        border-radius: 3px;
        vertical-align: middle;
    }
    .legend-title { font-weight: bold; margin-bottom: 10px; }
</style>
            """
            html = html.replace('</head>', f'{title_style}</head>')

            with open(output_path, 'w', encoding='utf-8') as f:
                f.write(html)

        except Exception:
            pass  # Don't fail if enhancement fails

    def _generate_legend(self) -> str:
        """Generate HTML legend for the visualization."""
        return f"""
<div class="legend">
    <div class="legend-title">Legend</div>
    <div class="legend-item">
        <span class="legend-color" style="background: {VisualConfig.NODE_COLORS['source_column']}"></span>
        Source Column
    </div>
    <div class="legend-item">
        <span class="legend-color" style="background: {VisualConfig.NODE_COLORS['target_column']}"></span>
        Target Column
    </div>
    <div class="legend-item">
        <span class="legend-color" style="background: {VisualConfig.NODE_COLORS['intermediate']}"></span>
        Intermediate
    </div>
    <div class="legend-title" style="margin-top: 15px;">Transformations</div>
    <div class="legend-item">
        <span class="legend-color" style="background: {VisualConfig.EDGE_COLORS['DIRECT']}"></span>
        Direct Mapping
    </div>
    <div class="legend-item">
        <span class="legend-color" style="background: {VisualConfig.EDGE_COLORS['INDIRECT']}"></span>
        Transformation
    </div>
</div>
        """
