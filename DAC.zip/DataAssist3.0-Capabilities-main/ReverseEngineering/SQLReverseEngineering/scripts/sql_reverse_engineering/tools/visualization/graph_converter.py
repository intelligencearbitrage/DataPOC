"""
Graph Converter module.

Converts LineageGraph to VisualLineageGraph for rendering.
"""

import sys
import os
from typing import List, Dict, Optional, Set

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from visualization.visual_models import (
    VisualNode, VisualEdge, VisualLineageGraph, VisualConfig
)
from lineage.lineage_graph import LineageGraph
from models.data_models import ElementCatalog


class LineageToVisualConverter:
    """Convert LineageGraph to VisualLineageGraph for rendering."""

    def __init__(self, lineage_graph: LineageGraph,
                 element_catalog: ElementCatalog = None,
                 config: VisualConfig = None):
        """
        Initialize converter.

        Args:
            lineage_graph: Source lineage graph
            element_catalog: Optional element catalog for metadata
            config: Visual configuration
        """
        self.lineage = lineage_graph
        self.elements = element_catalog
        self.config = config or VisualConfig()
        self._table_color_map = {}

    def convert(self) -> VisualLineageGraph:
        """
        Convert LineageGraph to visual representation.

        Returns:
            VisualLineageGraph ready for rendering
        """
        visual_nodes = self._convert_nodes()
        visual_edges = self._convert_edges()

        # Calculate hierarchical levels
        self._calculate_levels(visual_nodes, visual_edges)

        # Assign colors and groups
        self._assign_visual_properties(visual_nodes, visual_edges)

        # Get statistics
        source_tables = self._get_source_tables()
        target_tables = self._get_target_tables()

        return VisualLineageGraph(
            nodes=visual_nodes,
            edges=visual_edges,
            title=self._generate_title(),
            source_tables=source_tables,
            target_tables=target_tables,
            total_columns=len(visual_nodes),
            total_transformations=len(visual_edges)
        )

    def _convert_nodes(self) -> List[VisualNode]:
        """Convert graph nodes to visual nodes."""
        visual_nodes = []

        for node_id in self.lineage.graph.nodes():
            node_data = self.lineage.graph.nodes[node_id]

            table_name = node_data.get('table_name', '')
            column_name = node_data.get('column_name', node_id)

            # Determine node type based on in/out degree
            node_type = self._determine_node_type(node_id)

            visual_nodes.append(VisualNode(
                id=node_id,
                label=column_name,
                node_type=node_type,
                table_name=table_name,
                column_name=column_name,
                schema_name=node_data.get('schema_name'),
                group=table_name,
                level=0  # Calculated later
            ))

        return visual_nodes

    def _convert_edges(self) -> List[VisualEdge]:
        """Convert graph edges to visual edges."""
        visual_edges = []

        for edge in self.lineage.edges:
            source_id = self.lineage._node_id(edge.source)
            target_id = self.lineage._node_id(edge.target)

            _t = edge.transformation.type
            trans_type = (_t.value if hasattr(_t, 'value') else _t) if _t else "INDIRECT"
            _s = edge.transformation.subtype
            trans_subtype = (_s.value if hasattr(_s, 'value') else _s) if _s else "TRANSFORMATION"

            visual_edges.append(VisualEdge(
                source_id=source_id,
                target_id=target_id,
                transformation_type=trans_type,
                transformation_subtype=trans_subtype,
                transformation_sql=edge.transformation.sql_expression or "",
                description=self._get_transformation_description(edge),
                complexity_score=self._calculate_complexity(edge)
            ))

        return visual_edges

    def _determine_node_type(self, node_id: str) -> str:
        """Determine if node is source, intermediate, or target."""
        in_degree = self.lineage.graph.in_degree(node_id)
        out_degree = self.lineage.graph.out_degree(node_id)

        if in_degree == 0:
            return 'source_column'
        elif out_degree == 0:
            return 'target_column'
        else:
            return 'intermediate'

    def _calculate_levels(self, nodes: List[VisualNode],
                         edges: List[VisualEdge]) -> None:
        """Calculate hierarchical levels using longest path from sources."""
        node_map = {n.id: n for n in nodes}

        # Build adjacency list
        adjacency = {}
        for edge in edges:
            if edge.source_id not in adjacency:
                adjacency[edge.source_id] = []
            adjacency[edge.source_id].append(edge.target_id)

        # Find sources (no incoming edges)
        targets_set = {e.target_id for e in edges}
        sources_set = {e.source_id for e in edges}
        pure_sources = sources_set - targets_set

        # BFS to calculate levels
        visited = set()
        queue = [(src, 0) for src in pure_sources]

        while queue:
            node_id, level = queue.pop(0)

            if node_id in node_map:
                # Update level to max seen
                if node_map[node_id].level < level:
                    node_map[node_id].level = level

            if node_id in visited:
                continue
            visited.add(node_id)

            # Add children
            for child in adjacency.get(node_id, []):
                queue.append((child, level + 1))

    def _assign_visual_properties(self, nodes: List[VisualNode],
                                   edges: List[VisualEdge]) -> None:
        """Assign colors and other visual properties."""
        # Get unique tables
        tables = list(set(n.table_name for n in nodes if n.table_name))

        # Assign table colors
        for i, table in enumerate(tables):
            self._table_color_map[table] = VisualConfig.get_table_color(i)

        # Update node colors based on type
        for node in nodes:
            node.color = VisualConfig.get_node_color(node.node_type)

        # Update edge colors based on transformation type
        for edge in edges:
            edge.color = VisualConfig.get_edge_color(edge.transformation_type)

    def _get_source_tables(self) -> List[str]:
        """Get list of source tables."""
        sources = set()
        for node_id in self.lineage.graph.nodes():
            if self.lineage.graph.in_degree(node_id) == 0:
                node_data = self.lineage.graph.nodes[node_id]
                table = node_data.get('table_name', '')
                if table:
                    sources.add(table)
        return list(sources)

    def _get_target_tables(self) -> List[str]:
        """Get list of target tables."""
        targets = set()
        for node_id in self.lineage.graph.nodes():
            if self.lineage.graph.out_degree(node_id) == 0:
                node_data = self.lineage.graph.nodes[node_id]
                table = node_data.get('table_name', '')
                if table:
                    targets.add(table)
        return list(targets)

    def _generate_title(self) -> str:
        """Generate title for the visualization."""
        if self.elements and self.elements.target_table:
            return f"Column Lineage: {self.elements.target_table}"

        target_tables = self._get_target_tables()
        if target_tables:
            return f"Column Lineage: {target_tables[0]}"

        return "Column Lineage Visualization"

    def _get_transformation_description(self, edge) -> str:
        """Get human-readable transformation description."""
        _sb = edge.transformation.subtype
        subtype = (_sb.value if hasattr(_sb, 'value') else _sb) if _sb else "transformation"
        return f"{subtype.replace('_', ' ').title()} applied"

    def _calculate_complexity(self, edge) -> int:
        """Calculate complexity score for transformation."""
        sql = edge.transformation.sql_expression or ""

        score = 1
        if 'CASE' in sql.upper():
            score += 2
        if 'COALESCE' in sql.upper() or 'NVL' in sql.upper():
            score += 1
        if sql.upper().count('(') > 2:
            score += 1
        if 'OVER' in sql.upper():
            score += 2

        return min(score, 5)
