# Visualization Renderers

## Overview
This module contains different rendering engines for visualizing lineage data. Each renderer specializes in a specific output format or visualization style.

## Renderers

### `pyvis_renderer.py`
Interactive network graph renderer using PyVis library.

**Technology:** PyVis (Python library wrapping vis.js)

**Output Format:** Interactive HTML with embedded JavaScript

**Key Features:**
- **Interactive Navigation**
  - Pan and zoom
  - Click and drag nodes
  - Hover for tooltips
  - Search functionality
  
- **Physics Simulation**
  - Force-directed layout
  - Node repulsion
  - Edge attraction
  - Stabilization

- **Customization**
  - Node colors, shapes, sizes
  - Edge colors, widths, styles
  - Layout algorithms
  - Interactive controls

**Configuration Options:**
```python
{
    "height": "800px",
    "width": "100%",
    "bgcolor": "#ffffff",
    "font_color": "#000000",
    "physics": True,
    "hierarchical": False,
    "smooth_edges": True,
    "directed": True,
    "select_menu": True,
    "filter_menu": True
}
```

**Layout Algorithms:**
- **Force-directed**: Natural clustering
- **Hierarchical**: Top-down or left-right
- **Barnes-Hut**: Fast for large graphs
- **Repulsion**: Spread nodes apart

**Usage:**
```python
from visualization.renderers.pyvis_renderer import PyVisRenderer

renderer = PyVisRenderer()

# Basic rendering
html = renderer.render(
    visual_graph=graph,
    output_path="network.html"
)

# Custom configuration
html = renderer.render(
    visual_graph=graph,
    output_path="network.html",
    height="900px",
    physics=True,
    hierarchical=True,
    hierarchical_direction="UD",  # Up-Down
    show_buttons=True
)
```

**Interactive Features:**
- Click node: Show details panel
- Double-click node: Focus on node
- Drag node: Reposition manually
- Hover edge: Show transformation
- Search box: Find nodes by name
- Filter buttons: Toggle node types
- Export image: Save current view

**Best For:**
- Complex graphs with many nodes
- Interactive exploration
- Presentations and demos
- Ad-hoc analysis
- Large datasets (100+ nodes)

### `tree_renderer.py`
Hierarchical tree diagram renderer.

**Technology:** D3.js tree layout

**Output Format:** HTML with embedded D3.js

**Key Features:**
- **Hierarchical Layout**
  - Clear parent-child relationships
  - Top-down or left-right
  - Automatic spacing
  - Collision avoidance

- **Collapsible Branches**
  - Click to collapse/expand
  - Focus on specific branches
  - Reduce visual complexity

- **Clean Design**
  - Professional appearance
  - Clear flow direction
  - Minimal clutter

**Configuration Options:**
```python
{
    "direction": "top-to-bottom",  # or "left-to-right"
    "node_size": 10,
    "vertical_spacing": 100,
    "horizontal_spacing": 150,
    "show_labels": True,
    "collapsible": True
}
```

**Usage:**
```python
from visualization.renderers.tree_renderer import TreeRenderer

renderer = TreeRenderer()

html = renderer.render(
    visual_graph=graph,
    output_path="tree.html",
    direction="top-to-bottom",
    collapsible=True
)
```

**Tree Structure:**
```
                    Source Tables
                         |
            +------------+------------+
            |                         |
       customers.id            customers.name
            |                         |
            |                    +----+----+
            |                    |         |
            |                  UPPER     TRIM
            |                    |         |
            |                    +---------+
            |                         |
            +-------------------------+
                                      |
                          dim_customer.full_name
```

**Best For:**
- Simple lineage flows
- Source-to-target paths
- Documentation
- Reports
- Small to medium datasets (< 50 nodes)

### `graphviz_renderer.py`
Professional graph renderer using Graphviz.

**Technology:** Graphviz DOT language

**Output Formats:** DOT, PDF, PNG, SVG, PS

**Key Features:**
- **Professional Quality**
  - Publication-ready
  - High resolution
  - Precise layout control
  - Print-friendly

- **Multiple Layouts**
  - dot: Hierarchical
  - neato: Spring model
  - fdp: Force-directed
  - circo: Circular
  - twopi: Radial

- **Advanced Styling**
  - Custom shapes
  - Colors and gradients
  - Line styles
  - Font control

**Layout Descriptions:**

#### `dot` Layout
Hierarchical top-down or left-right layout.
- Best for: DAGs, hierarchies
- Flow: Clear direction
- Use case: Most lineage diagrams

#### `neato` Layout
Spring model layout.
- Best for: Small symmetric graphs
- Flow: Minimize edge crossings
- Use case: Relationship visualization

#### `fdp` Layout
Force-directed placement.
- Best for: Large graphs
- Flow: Natural clustering
- Use case: Complex networks

#### `circo` Layout
Circular layout.
- Best for: Cyclic structures
- Flow: Circular arrangement
- Use case: Cycle visualization

#### `twopi` Layout
Radial layout with central node.
- Best for: Star topologies
- Flow: From center outward
- Use case: Hub-and-spoke patterns

**Configuration Options:**
```python
{
    "layout": "dot",
    "rankdir": "TB",  # TB, BT, LR, RL
    "node_shape": "box",
    "node_style": "filled",
    "edge_style": "solid",
    "font_name": "Arial",
    "font_size": 12,
    "dpi": 300
}
```

**Usage:**
```python
from visualization.renderers.graphviz_renderer import GraphvizRenderer

renderer = GraphvizRenderer()

# Generate DOT file
dot_content = renderer.render(
    visual_graph=graph,
    output_path="lineage.dot",
    layout="dot",
    rankdir="TB"
)

# Export to PDF
renderer.export_pdf(
    dot_file="lineage.dot",
    output_path="lineage.pdf",
    dpi=300
)

# Export to PNG
renderer.export_png(
    dot_file="lineage.dot",
    output_path="lineage.png",
    dpi=300
)

# Export to SVG (scalable)
renderer.export_svg(
    dot_file="lineage.dot",
    output_path="lineage.svg"
)
```

**DOT Format Example:**
```dot
digraph lineage {
    rankdir=TB;
    node [shape=box, style=filled];
    
    // Nodes
    "customers.name" [fillcolor="#4CAF50"];
    "dim_customer.customer_name" [fillcolor="#2196F3"];
    
    // Edges
    "customers.name" -> "dim_customer.customer_name" [label="UPPER()"];
}
```

**Best For:**
- Publication-quality diagrams
- Reports and presentations
- Print output
- PDF documentation
- High-resolution requirements

### Mermaid Renderer
Text-based diagram generator.

**Technology:** Mermaid markdown

**Output Format:** Mermaid markdown (.mmd)

**Key Features:**
- **Text-Based**
  - Easy to edit
  - Version control friendly
  - Diff-able
  - Human-readable

- **Widely Supported**
  - GitHub/GitLab rendering
  - Markdown editors
  - Documentation platforms
  - Wiki systems

- **Simple Syntax**
  - Quick to write
  - Easy to learn
  - Clear structure

**Mermaid Syntax:**
```mermaid
graph LR
    A[customers.name] -->|UPPER| B[dim_customer.customer_name]
    C[customers.email] -->|LOWER| D[dim_customer.email]
    A --> E{Transformation}
    E -->|CONCAT| F[dim_customer.full_name]
```

**Node Shapes:**
- `[text]` - Rectangle
- `(text)` - Rounded rectangle
- `{text}` - Diamond (decision)
- `((text))` - Circle
- `>text]` - Asymmetric shape

**Usage:**
```python
# Usually called via visual_exporter
exporter.export_mermaid("lineage.mmd")
```

**Best For:**
- Documentation in Markdown
- README files
- GitHub/GitLab
- Wikis
- Version-controlled docs
- Simple diagrams

## Renderer Comparison

| Feature | PyVis | Tree | Graphviz | Mermaid |
|---------|-------|------|----------|---------|
| Interactive | ✓✓✓ | ✓✓ | ✗ | ✗ |
| Print Quality | ✓ | ✓✓ | ✓✓✓ | ✓✓ |
| Large Graphs | ✓✓✓ | ✓ | ✓✓ | ✓ |
| Easy to Edit | ✗ | ✗ | ✓ | ✓✓✓ |
| Version Control | ✗ | ✗ | ✓✓ | ✓✓✓ |
| Documentation | ✓ | ✓✓ | ✓✓✓ | ✓✓✓ |
| Exploration | ✓✓✓ | ✓✓ | ✗ | ✗ |

## Usage Guidelines

### Choose PyVis when:
- You need interactive exploration
- Working with complex graphs
- Presenting to stakeholders
- Need search/filter capabilities
- Dataset has 50+ nodes

### Choose Tree when:
- Lineage is hierarchical
- Need clear parent-child flow
- Simple source-to-target paths
- Documentation purposes
- Dataset has < 50 nodes

### Choose Graphviz when:
- Need publication quality
- Exporting to PDF/PNG
- Professional reports
- Print documentation
- Precise layout control needed

### Choose Mermaid when:
- Documentation in Markdown
- Version control is important
- Collaborating on GitHub/GitLab
- Simple diagrams
- Quick iteration needed

## Integration Points
- Used by: visual_exporter
- Inputs: VisualLineageGraph
- Outputs: HTML, PDF, PNG, SVG, DOT, Mermaid
- Customizable: Colors, shapes, layouts, interactivity
