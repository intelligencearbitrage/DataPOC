# Visualization

## Overview
The Visualization module exports lineage data into visual formats including interactive HTML network graphs, tree diagrams, and Mermaid flowcharts.

## Components

### `visual_exporter.py`
Main interface for exporting visual lineage.

**Export Formats:**
- Interactive HTML (network graph)
- Tree HTML (hierarchical tree)
- Mermaid diagram
- Graphviz DOT
- JSON (for custom visualization)

**Key Features:**
- Multiple rendering engines
- Customizable styling
- Interactive features
- Export to various formats

**Usage:**
```python
from visualization.visual_exporter import VisualLineageExporter

exporter = VisualLineageExporter(
    lineage_graph=lineage_graph,
    element_catalog=catalog
)

# Export HTML network
exporter.export_html("lineage_network.html")

# Export tree diagram
exporter.export_tree("lineage_tree.html")

# Export Mermaid
exporter.export_mermaid("lineage.mmd")
```

### `visual_models.py`
Data models for visual representation.

**Models:**

#### `VisualNode`
Node in visual graph.

**Fields:**
- `id` - Unique node ID
- `label` - Display label
- `type` - Node type (source, target, transformation)
- `table` - Table name
- `column` - Column name
- `color` - Node color
- `shape` - Node shape
- `size` - Node size
- `metadata` - Additional metadata

#### `VisualEdge`
Edge in visual graph.

**Fields:**
- `from_node` - Source node ID
- `to_node` - Target node ID
- `label` - Edge label (transformation)
- `type` - Edge type
- `color` - Edge color
- `width` - Edge width
- `arrows` - Arrow style
- `metadata` - Additional metadata

#### `VisualLineageGraph`
Complete visual graph structure.

**Fields:**
- `nodes` - List of VisualNode
- `edges` - List of VisualEdge
- `metadata` - Graph metadata
- `layout` - Layout algorithm

**Methods:**
- `add_node()` - Add node
- `add_edge()` - Add edge
- `to_dict()` - Convert to dictionary
- `to_json()` - Serialize to JSON

### `graph_converter.py`
Converts lineage graphs to visual graphs.

**Conversion Process:**
1. Create visual nodes from lineage columns
2. Create visual edges from lineage edges
3. Apply styling based on types
4. Add metadata and labels
5. Optimize layout

**Styling Rules:**
- **Source tables**: Green nodes
- **Target tables**: Blue nodes
- **Intermediate**: Yellow nodes
- **Direct transformations**: Solid lines
- **Indirect transformations**: Dashed lines
- **Aggregations**: Thick lines

**Usage:**
```python
from visualization.graph_converter import LineageToVisualConverter

converter = LineageToVisualConverter(
    lineage_graph=lineage_graph,
    element_catalog=catalog
)

visual_graph = converter.convert()
```

### `renderers/`
Different rendering engines for visual output.

#### `pyvis_renderer.py`
PyVis-based interactive network graph renderer.

**Features:**
- Interactive HTML output
- Pan and zoom
- Node dragging
- Hover tooltips
- Search and filter
- Physics simulation
- Clustering

**Customization:**
- Node colors, shapes, sizes
- Edge colors, widths, styles
- Layout algorithms (hierarchical, force-directed)
- Physics settings
- Interactive controls

**Usage:**
```python
from visualization.renderers.pyvis_renderer import PyVisRenderer

renderer = PyVisRenderer()
html_output = renderer.render(
    visual_graph,
    output_path="network.html",
    height="800px",
    width="100%",
    physics=True
)
```

**Output Features:**
- Click nodes to see details
- Drag nodes to rearrange
- Zoom in/out
- Search for nodes
- Filter by type
- Export as image

#### `tree_renderer.py`
Hierarchical tree diagram renderer.

**Features:**
- Top-down tree layout
- Collapsible branches
- Source-to-target flow
- Clean hierarchical view

**Layout:**
```
┌─────────────┐
│  Source.col │
└──────┬──────┘
       │
   ┌───┴───┐
   │ UPPER │
   └───┬───┘
       │
┌──────┴────────┐
│  Target.col   │
└───────────────┘
```

**Usage:**
```python
from visualization.renderers.tree_renderer import TreeRenderer

renderer = TreeRenderer()
html_output = renderer.render(
    visual_graph,
    output_path="tree.html",
    direction="top-to-bottom"
)
```

#### `graphviz_renderer.py`
Graphviz DOT format renderer.

**Features:**
- Professional graph layouts
- Multiple layout algorithms (dot, neato, fdp, circo)
- Export to PDF, PNG, SVG
- High-quality output

**Layouts:**
- **dot**: Hierarchical top-down
- **neato**: Spring model
- **fdp**: Force-directed
- **circo**: Circular layout
- **twopi**: Radial layout

**Usage:**
```python
from visualization.renderers.graphviz_renderer import GraphvizRenderer

renderer = GraphvizRenderer()
dot_output = renderer.render(
    visual_graph,
    output_path="lineage.dot",
    layout="dot"
)

# Can export to multiple formats
renderer.export_pdf("lineage.pdf")
renderer.export_png("lineage.png")
renderer.export_svg("lineage.svg")
```

#### Mermaid Diagram Renderer
Generates Mermaid markdown diagrams.

**Features:**
- Text-based diagrams
- Flowchart format
- Easy to embed in documentation
- Version control friendly

**Output Example:**
```mermaid
graph LR
    A[customers.name] -->|UPPER| B[dim_customer.customer_name]
    C[customers.email] -->|LOWER| D[dim_customer.email]
    A --> E[Full Name Calculation]
    E -->|CONCAT| F[dim_customer.full_name]
```

## Visualization Types

### 1. Network Graph (Interactive)
Best for exploring complex lineage with many relationships.

**Features:**
- Interactive exploration
- Pan, zoom, drag
- Search and filter
- Physics-based layout
- Hover details

**Use Cases:**
- Complex multi-table lineage
- Exploration and discovery
- Interactive presentations
- Ad-hoc analysis

### 2. Tree Diagram
Best for hierarchical source-to-target flow.

**Features:**
- Clean hierarchy
- Collapsible branches
- Top-down or left-right
- Clear parent-child relationships

**Use Cases:**
- Simple lineage paths
- Documentation
- Reports
- Understanding flow direction

### 3. Mermaid Diagram
Best for documentation and version control.

**Features:**
- Text-based
- Easy to edit
- Renders in Markdown
- Version control friendly

**Use Cases:**
- Documentation
- README files
- Wiki pages
- Code reviews

### 4. Graphviz
Best for publication-quality output.

**Features:**
- Professional quality
- Multiple export formats
- Precise layout control
- Print-ready output

**Use Cases:**
- Reports
- Presentations
- Publications
- High-quality documentation

## Usage Example

```python
from lineage.lineage_graph import LineageGraph
from visualization.visual_exporter import VisualLineageExporter

# Create or extract lineage graph
lineage_graph = LineageGraph()
# ... add edges ...

# Initialize exporter
exporter = VisualLineageExporter(
    lineage_graph=lineage_graph,
    element_catalog=element_catalog
)

# Export in multiple formats
exporter.export_html(
    "lineage_network.html",
    height="900px",
    physics=True,
    show_buttons=True
)

exporter.export_tree(
    "lineage_tree.html",
    direction="top-to-bottom"
)

exporter.export_mermaid("lineage.mmd")

exporter.export_graphviz(
    "lineage.dot",
    layout="dot"
)

# Export to PDF via Graphviz
exporter.export_pdf("lineage.pdf")
```

## Styling Customization

```python
# Custom node styling
node_styles = {
    "source": {"color": "#4CAF50", "shape": "box"},
    "target": {"color": "#2196F3", "shape": "ellipse"},
    "transformation": {"color": "#FF9800", "shape": "diamond"}
}

# Custom edge styling
edge_styles = {
    "DIRECT": {"color": "#000000", "width": 2, "style": "solid"},
    "INDIRECT": {"color": "#666666", "width": 1, "style": "dashed"}
}

exporter.export_html(
    "lineage.html",
    node_styles=node_styles,
    edge_styles=edge_styles
)
```

## Integration Points
- Inputs: LineageGraph, ElementCatalog
- Uses: PyVis, Graphviz, Mermaid
- Outputs: HTML, SVG, PDF, PNG, DOT, Mermaid
- Used by: documentation, agent_interface, CLI
