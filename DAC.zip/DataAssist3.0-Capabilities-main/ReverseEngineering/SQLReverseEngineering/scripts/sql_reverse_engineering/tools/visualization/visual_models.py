"""
Visual Models for lineage visualization.

Contains data classes for visual representation of lineage graphs.
"""

from dataclasses import dataclass, field, asdict
from typing import List, Dict, Optional, Any
from enum import Enum


class NodeType(Enum):
    """Types of nodes in visual lineage."""
    SOURCE_COLUMN = "source_column"
    TARGET_COLUMN = "target_column"
    INTERMEDIATE = "intermediate"
    CTE_COLUMN = "cte_column"


class VisualConfig:
    """Configuration for visual styling."""

    # Node colors by type
    NODE_COLORS = {
        'source_column': '#4CAF50',      # Green
        'intermediate': '#FFC107',        # Amber
        'target_column': '#2196F3',       # Blue
        'cte_column': '#9C27B0',          # Purple
        'default': '#757575'              # Gray
    }

    # Table group colors (for distinct tables)
    TABLE_COLORS = [
        '#E3F2FD', '#E8F5E9', '#FFF3E0', '#F3E5F5',
        '#E0F7FA', '#FBE9E7', '#F1F8E9', '#FCE4EC',
        '#ECEFF1', '#FFF8E1', '#E8EAF6', '#EFEBE9'
    ]

    # Edge colors by transformation type
    EDGE_COLORS = {
        'DIRECT': '#4CAF50',              # Green - direct mapping
        'INDIRECT': '#FF9800',            # Orange - transformation
        'AGGREGATION': '#F44336',         # Red - aggregation
        'CASE_LOGIC': '#9C27B0',          # Purple - conditional
        'WINDOW': '#2196F3',              # Blue - window function
        'default': '#9E9E9E'              # Gray
    }

    # Edge styles by transformation subtype
    EDGE_STYLES = {
        'IDENTITY': 'solid',
        'CAST': 'solid',
        'TRANSFORMATION': 'solid',
        'AGGREGATION': 'dashed',
        'CASE_LOGIC': 'dotted',
        'default': 'solid'
    }

    # Node shapes
    NODE_SHAPES = {
        'source_column': 'box',
        'target_column': 'box',
        'intermediate': 'ellipse',
        'cte_column': 'diamond',
        'default': 'box'
    }

    @classmethod
    def get_node_color(cls, node_type: str) -> str:
        """Get color for node type."""
        return cls.NODE_COLORS.get(node_type, cls.NODE_COLORS['default'])

    @classmethod
    def get_edge_color(cls, trans_type: str) -> str:
        """Get color for transformation type."""
        return cls.EDGE_COLORS.get(trans_type.upper(), cls.EDGE_COLORS['default'])

    @classmethod
    def get_table_color(cls, index: int) -> str:
        """Get color for table grouping."""
        return cls.TABLE_COLORS[index % len(cls.TABLE_COLORS)]


@dataclass
class VisualNode:
    """Node for visual lineage representation."""
    id: str                               # Unique node identifier
    label: str                            # Display label
    node_type: str                        # source_column, intermediate, target_column
    table_name: str                       # Parent table
    column_name: str                      # Column name
    schema_name: Optional[str] = None     # Schema/database

    # Visual properties
    color: str = ""
    size: int = 25
    shape: str = "box"
    group: str = ""
    level: int = 0                        # Hierarchical level (0=source, n=target)

    # Metadata
    data_type: Optional[str] = None
    transformation_count: int = 0

    def __post_init__(self):
        """Set defaults after initialization."""
        if not self.color:
            self.color = VisualConfig.get_node_color(self.node_type)
        if not self.shape:
            self.shape = VisualConfig.NODE_SHAPES.get(
                self.node_type, VisualConfig.NODE_SHAPES['default']
            )
        if not self.group:
            self.group = self.table_name

    def to_pyvis_dict(self) -> Dict[str, Any]:
        """Convert to pyvis node attributes."""
        return {
            'label': self.label,
            'title': self._build_tooltip(),
            'color': self.color,
            'size': self.size,
            'shape': self.shape,
            'group': self.group,
            'level': self.level
        }

    def _build_tooltip(self) -> str:
        """Build HTML tooltip for node."""
        return f"""
<b>{self.table_name}.{self.column_name}</b><br>
Type: {self.node_type}<br>
Schema: {self.schema_name or 'N/A'}<br>
Data Type: {self.data_type or 'Unknown'}
        """.strip()

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return asdict(self)


@dataclass
class VisualEdge:
    """Edge for visual lineage representation."""
    source_id: str                        # Source node ID
    target_id: str                        # Target node ID
    transformation_type: str              # DIRECT, INDIRECT
    transformation_subtype: str           # IDENTITY, CAST, AGGREGATION, etc.
    transformation_sql: str               # SQL expression
    description: str = ""                 # Human-readable description

    # Visual properties
    color: str = ""
    width: int = 2
    style: str = "solid"
    arrow_type: str = "arrow"

    # Metadata
    complexity_score: int = 1             # 1-5 complexity rating

    def __post_init__(self):
        """Set defaults after initialization."""
        if not self.color:
            self.color = VisualConfig.get_edge_color(self.transformation_type)
        if not self.style:
            self.style = VisualConfig.EDGE_STYLES.get(
                self.transformation_subtype, VisualConfig.EDGE_STYLES['default']
            )

    def to_pyvis_dict(self) -> Dict[str, Any]:
        """Convert to pyvis edge attributes."""
        return {
            'title': self._build_tooltip(),
            'color': self.color,
            'width': self.width,
            'dashes': self.style == "dashed",
            'arrows': {'to': {'enabled': True, 'type': self.arrow_type}}
        }

    def _build_tooltip(self) -> str:
        """Build HTML tooltip for edge."""
        sql_display = self.transformation_sql[:100]
        if len(self.transformation_sql) > 100:
            sql_display += "..."
        return f"""
<b>Transformation: {self.transformation_subtype}</b><br>
Type: {self.transformation_type}<br>
SQL: <code>{sql_display}</code><br>
{self.description}
        """.strip()

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return asdict(self)


@dataclass
class VisualLineageGraph:
    """Container for visual lineage data."""
    nodes: List[VisualNode] = field(default_factory=list)
    edges: List[VisualEdge] = field(default_factory=list)

    # Graph metadata
    title: str = ""
    source_tables: List[str] = field(default_factory=list)
    target_tables: List[str] = field(default_factory=list)
    total_columns: int = 0
    total_transformations: int = 0

    # Layout configuration
    layout_type: str = "hierarchical"     # hierarchical, force, circular
    direction: str = "LR"                 # LR (left-right) or TB (top-bottom)

    # Visual theme
    theme: str = "default"                # default, dark, print

    def get_tables_grouped(self) -> Dict[str, List[VisualNode]]:
        """Group nodes by table for clustered visualization."""
        groups = {}
        for node in self.nodes:
            table = node.table_name or "unknown"
            if table not in groups:
                groups[table] = []
            groups[table].append(node)
        return groups

    def get_node_by_id(self, node_id: str) -> Optional[VisualNode]:
        """Get node by ID."""
        for node in self.nodes:
            if node.id == node_id:
                return node
        return None

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            'metadata': {
                'title': self.title,
                'source_tables': self.source_tables,
                'target_tables': self.target_tables,
                'total_columns': self.total_columns,
                'total_transformations': self.total_transformations,
                'layout_type': self.layout_type,
                'direction': self.direction,
                'theme': self.theme
            },
            'nodes': [n.to_dict() for n in self.nodes],
            'edges': [e.to_dict() for e in self.edges]
        }
