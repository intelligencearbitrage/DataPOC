"""
Visual Lineage Exporter module.

Main interface for exporting visual lineage in various formats.
"""

import json
import sys
import os
from typing import Dict, Any, Optional

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from visualization.visual_models import VisualLineageGraph
from visualization.graph_converter import LineageToVisualConverter
from lineage.lineage_graph import LineageGraph
from models.data_models import ElementCatalog


class VisualLineageExporter:
    """Main interface for exporting visual lineage."""

    def __init__(self, lineage_graph: LineageGraph,
                 element_catalog: ElementCatalog = None):
        """
        Initialize exporter.

        Args:
            lineage_graph: Lineage graph to visualize
            element_catalog: Optional element catalog for metadata
        """
        self.lineage = lineage_graph
        self.elements = element_catalog
        self.converter = LineageToVisualConverter(lineage_graph, element_catalog)
        self.visual_graph = None

    def _ensure_converted(self) -> VisualLineageGraph:
        """Ensure visual graph is converted."""
        if not self.visual_graph:
            self.visual_graph = self.converter.convert()
        return self.visual_graph

    def export_html(self, output_path: str, **kwargs) -> str:
        """
        Export interactive HTML visualization (network graph).

        Args:
            output_path: Path to save HTML file
            **kwargs: Additional options for PyVis renderer

        Returns:
            Path to generated HTML file
        """
        from visualization.renderers.pyvis_renderer import PyVisRenderer

        visual_graph = self._ensure_converted()
        renderer = PyVisRenderer(visual_graph, theme=kwargs.get('theme', 'default'))
        return renderer.render(output_path, **kwargs)

    def export_tree(self, output_path: str, title: str = "Data Lineage Tree") -> str:
        """
        Export collapsible tree visualization at table level.

        This is the recommended visualization - shows:
        - Tables as expandable top-level nodes
        - Columns nested under tables
        - Transformation logic at field level

        Args:
            output_path: Path to save HTML file
            title: Title for the visualization

        Returns:
            Path to generated HTML file
        """
        from visualization.renderers.tree_renderer import TreeRenderer

        renderer = TreeRenderer()
        renderer.render(self.lineage, output_path, title)
        return output_path

    def export_svg(self, output_path: str, **kwargs) -> str:
        """
        Export static SVG visualization.

        Args:
            output_path: Path to save SVG file
            **kwargs: Additional options for Graphviz renderer

        Returns:
            Path to generated SVG file
        """
        from visualization.renderers.graphviz_renderer import GraphvizRenderer

        visual_graph = self._ensure_converted()
        renderer = GraphvizRenderer(visual_graph)
        return renderer.render(output_path, format='svg', **kwargs)

    def export_pdf(self, output_path: str, **kwargs) -> str:
        """
        Export static PDF visualization.

        Args:
            output_path: Path to save PDF file
            **kwargs: Additional options for Graphviz renderer

        Returns:
            Path to generated PDF file
        """
        from visualization.renderers.graphviz_renderer import GraphvizRenderer

        visual_graph = self._ensure_converted()
        renderer = GraphvizRenderer(visual_graph)
        return renderer.render(output_path, format='pdf', **kwargs)

    def export_png(self, output_path: str, **kwargs) -> str:
        """
        Export static PNG visualization.

        Args:
            output_path: Path to save PNG file
            **kwargs: Additional options for Graphviz renderer

        Returns:
            Path to generated PNG file
        """
        from visualization.renderers.graphviz_renderer import GraphvizRenderer

        visual_graph = self._ensure_converted()
        renderer = GraphvizRenderer(visual_graph)
        return renderer.render(output_path, format='png', **kwargs)

    def export_json(self, output_path: str = None) -> Dict[str, Any]:
        """
        Export visual graph as JSON for external tools.

        Args:
            output_path: Optional path to save JSON file

        Returns:
            Visual graph data as dictionary
        """
        visual_graph = self._ensure_converted()
        data = visual_graph.to_dict()

        if output_path:
            with open(output_path, 'w', encoding='utf-8') as f:
                json.dump(data, f, indent=2)

        return data

    def export_mermaid(self, output_path: str = None) -> str:
        """
        Export enhanced Mermaid diagram.

        Args:
            output_path: Optional path to save Mermaid file

        Returns:
            Mermaid diagram source
        """
        visual_graph = self._ensure_converted()

        lines = ['flowchart LR']

        # Add subgraphs for tables
        for table_name, columns in visual_graph.get_tables_grouped().items():
            safe_table = self._sanitize_mermaid_id(table_name)
            display_name = table_name.replace('"', '\\"')
            lines.append(f'    subgraph {safe_table}["{display_name}"]')

            for node in columns:
                safe_id = self._sanitize_mermaid_id(node.id)
                display_col = node.column_name.replace('"', '\\"')
                lines.append(f'        {safe_id}["{display_col}"]')

            lines.append('    end')

        lines.append('')

        # Add edges with styling
        for edge in visual_graph.edges:
            src = self._sanitize_mermaid_id(edge.source_id)
            tgt = self._sanitize_mermaid_id(edge.target_id)

            # Use different arrow styles based on transformation
            if edge.transformation_type == 'DIRECT':
                arrow = '-->'
            else:
                label = edge.transformation_subtype[:10] if edge.transformation_subtype else 'xform'
                arrow = f'-.->|{label}|'

            lines.append(f'    {src} {arrow} {tgt}')

        mermaid_source = '\n'.join(lines)

        if output_path:
            with open(output_path, 'w', encoding='utf-8') as f:
                f.write(mermaid_source)

        return mermaid_source

    def _sanitize_mermaid_id(self, name: str) -> str:
        """Sanitize name for Mermaid node IDs."""
        if not name:
            return "unknown"
        # Replace problematic characters
        sanitized = name.replace('.', '_').replace(' ', '_').replace('-', '_')
        sanitized = sanitized.replace('(', '').replace(')', '')
        sanitized = sanitized.replace('[', '').replace(']', '')
        sanitized = sanitized.replace('"', '').replace("'", '')
        return sanitized

    def get_visual_graph(self) -> VisualLineageGraph:
        """
        Get the visual graph object.

        Returns:
            VisualLineageGraph
        """
        return self._ensure_converted()
