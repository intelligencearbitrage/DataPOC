"""
Graphviz Renderer for static SVG/PDF visualization.

Uses Graphviz to create publication-quality static diagrams.
"""

import sys
import os
from typing import Dict, Any, Optional

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

from visualization.visual_models import VisualLineageGraph, VisualConfig


class GraphvizRenderer:
    """Render visual lineage to static SVG/PDF using Graphviz."""

    def __init__(self, visual_graph: VisualLineageGraph):
        """
        Initialize renderer.

        Args:
            visual_graph: Visual lineage graph to render
        """
        self.graph = visual_graph

    def render(self, output_path: str,
               format: str = 'svg',
               rankdir: str = 'LR') -> str:
        """
        Render to static image file.

        Args:
            output_path: Output file path (without extension)
            format: Output format ('svg', 'pdf', 'png')
            rankdir: Direction ('LR', 'TB', 'RL', 'BT')

        Returns:
            Path to generated file
        """
        try:
            from graphviz import Digraph
        except ImportError:
            raise ImportError(
                "graphviz Python library is required for static visualization. "
                "Install with: pip install graphviz\n"
                "Note: Graphviz binary must also be installed on the system."
            )

        dot = Digraph(
            comment=self.graph.title,
            format=format,
            graph_attr={
                'rankdir': rankdir,
                'splines': 'ortho',
                'nodesep': '0.5',
                'ranksep': '1.5',
                'label': self.graph.title,
                'labelloc': 't',
                'fontsize': '16',
                'fontname': 'Arial'
            },
            node_attr={
                'fontname': 'Arial',
                'fontsize': '10'
            },
            edge_attr={
                'fontname': 'Arial',
                'fontsize': '8'
            }
        )

        # Create subgraphs for table clustering
        table_groups = self.graph.get_tables_grouped()
        table_colors = {}

        for i, (table_name, columns) in enumerate(table_groups.items()):
            # Sanitize table name for cluster naming
            safe_name = self._sanitize_name(table_name)
            table_colors[table_name] = VisualConfig.get_table_color(i)

            with dot.subgraph(name=f'cluster_{safe_name}') as c:
                c.attr(
                    label=self._truncate_label(table_name, 40),
                    style='rounded,filled',
                    color='lightgray',
                    fillcolor=table_colors[table_name]
                )

                for node in columns:
                    c.node(
                        self._sanitize_name(node.id),
                        label=self._truncate_label(node.column_name, 25),
                        shape=node.shape,
                        style='filled',
                        fillcolor=node.color,
                        tooltip=f"{node.table_name}.{node.column_name}"
                    )

        # Add edges
        for edge in self.graph.edges:
            # Get short label for transformation
            label = self._get_edge_label(edge)

            dot.edge(
                self._sanitize_name(edge.source_id),
                self._sanitize_name(edge.target_id),
                label=label,
                color=edge.color,
                style='solid' if edge.style == 'solid' else 'dashed',
                penwidth=str(edge.width),
                tooltip=edge.transformation_sql[:100] if edge.transformation_sql else ""
            )

        # Render and return path
        # Remove extension from output_path if present
        base_path = output_path
        if output_path.endswith(f'.{format}'):
            base_path = output_path[:-len(format)-1]

        output_file = dot.render(base_path, cleanup=True)
        return output_file

    def render_dot_source(self) -> str:
        """
        Get the DOT source code for the graph.

        Returns:
            DOT source code as string
        """
        try:
            from graphviz import Digraph
        except ImportError:
            return ""

        dot = Digraph(comment=self.graph.title)

        dot.attr(rankdir='LR', splines='ortho')

        # Add nodes
        for node in self.graph.nodes:
            dot.node(
                self._sanitize_name(node.id),
                label=node.column_name,
                shape=node.shape
            )

        # Add edges
        for edge in self.graph.edges:
            dot.edge(
                self._sanitize_name(edge.source_id),
                self._sanitize_name(edge.target_id)
            )

        return dot.source

    def _sanitize_name(self, name: str) -> str:
        """Sanitize name for Graphviz node IDs."""
        if not name:
            return "unknown"
        # Replace problematic characters
        sanitized = name.replace('.', '_').replace(' ', '_').replace('-', '_')
        sanitized = sanitized.replace('(', '').replace(')', '')
        sanitized = sanitized.replace('[', '').replace(']', '')
        return sanitized

    def _truncate_label(self, label: str, max_len: int = 30) -> str:
        """Truncate label for display."""
        if not label:
            return ""
        if len(label) <= max_len:
            return label
        return label[:max_len-3] + "..."

    def _get_edge_label(self, edge) -> str:
        """Get short label for edge."""
        subtype = edge.transformation_subtype or ""
        # Shorten common transformation types
        short_labels = {
            'IDENTITY': '',
            'TRANSFORMATION': 'XFORM',
            'CAST': 'CAST',
            'AGGREGATION': 'AGG',
            'CASE_LOGIC': 'CASE',
            'STRING_MANIPULATION': 'STR',
            'DATE_MANIPULATION': 'DATE',
            'NULL_HANDLING': 'NULL',
            'CONCATENATION': 'CONCAT',
            'ARITHMETIC': 'CALC'
        }
        return short_labels.get(subtype.upper(), subtype[:8])
