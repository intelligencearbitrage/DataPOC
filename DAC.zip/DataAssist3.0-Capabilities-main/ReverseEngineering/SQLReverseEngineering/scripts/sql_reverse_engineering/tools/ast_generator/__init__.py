"""AST Generator module for parsing SQL and generating Abstract Syntax Trees."""

from .parser import SQLASTGenerator

__all__ = ["SQLASTGenerator"]
