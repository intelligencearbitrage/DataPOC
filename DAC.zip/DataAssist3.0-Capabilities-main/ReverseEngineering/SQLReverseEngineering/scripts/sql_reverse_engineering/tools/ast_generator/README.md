# AST Generator

## Overview
The AST (Abstract Syntax Tree) Generator module parses SQL statements and generates structured AST representations that can be consumed by other analysis tools.

## Components

### `parser.py`
Main SQL parser using SQLGlot for multi-dialect support.

**Key Features:**
- Multi-dialect SQL parsing (Teradata, SQL Server, PostgreSQL, MySQL, Oracle, etc.)
- AST generation and serialization
- Error handling and validation
- Support for complex SQL constructs (CTEs, subqueries, stored procedures)

**Supported Dialects:**
- Teradata
- T-SQL / SQL Server
- Snowflake
- BigQuery
- PostgreSQL
- MySQL
- Oracle
- Redshift
- Spark/Hive
- DuckDB

### `stored_procedure_handler.py`
Specialized handler for stored procedures and procedural SQL.

**Key Features:**
- Parse stored procedure definitions
- Extract control flow logic
- Handle procedural constructs (IF, WHILE, CURSOR, etc.)
- Variable tracking and scope analysis

## Classes

### `SQLASTGenerator`
Main parser class that converts SQL text into structured AST.

**Methods:**
- `parse(sql: str)` - Parse SQL and return AST
- `parse_batch(sql_list: List[str])` - Parse multiple statements
- `to_json()` - Serialize AST to JSON
- `validate()` - Validate parsed SQL

## Usage Example

```python
from ast_generator.parser import SQLASTGenerator

# Initialize parser
parser = SQLASTGenerator(dialect="teradata")

# Parse SQL
sql = """
SELECT t1.col1, t2.col2
FROM table1 t1
JOIN table2 t2 ON t1.id = t2.id
WHERE t1.status = 'ACTIVE'
"""

result = parser.parse(sql)

# Get AST as JSON
ast_json = result.to_json()
```

## Data Models
Returns `ParseResult` containing:
- `ast` - Parsed AST structure
- `metadata` - Parsing metadata (dialect, timestamp, etc.)
- `errors` - Any parsing errors
- `warnings` - Warnings about potential issues

## Integration Points
- Used by: deconstructor, lineage, documentation modules
- Inputs: Raw SQL text
- Outputs: Structured AST, JSON serialization

## Error Handling
- Syntax error detection
- Dialect-specific validation
- Detailed error messages with line numbers
- Graceful degradation for partial parsing Module

## Overview

The AST (Abstract Syntax Tree) Generator module provides comprehensive functionality for parsing SQL statements across multiple dialects and generating structured AST representations. This module leverages SQLGlot for multi-dialect SQL parsing and includes specialized handling for stored procedures with procedural extensions.

## Features

- **Multi-Dialect SQL Parsing**: Support for 13+ SQL dialects including Teradata, T-SQL, Snowflake, BigQuery, PostgreSQL, MySQL, Oracle, and more
- **AST Generation**: Convert SQL statements into structured Abstract Syntax Trees
- **Stored Procedure Handling**: Extract and normalize stored procedure-specific constructs (variables, cursors, control flow)
- **SQL Transpilation**: Convert SQL between different dialects
- **Metadata Extraction**: Extract tables, columns, and statement types from parsed SQL
- **Serialization**: Export ASTs to JSON and YAML formats
- **Error Handling**: Graceful parsing with partial result recovery

## Components

### 1. SQLASTGenerator (`parser.py`)

The main entry point for SQL parsing and AST generation.

#### Key Features:
- Parse single or multiple SQL statements
- File-based parsing with metadata tracking
- Safe parsing with error recovery
- AST serialization (JSON/YAML)
- SQL formatting and transpilation
- Table and column extraction

#### Supported Dialects:
- Teradata
- T-SQL / SQL Server
- Snowflake
- BigQuery
- PostgreSQL
- MySQL
- Oracle
- Redshift
- Spark
- Hive
- DuckDB

### 2. StoredProcedureHandler (`stored_procedure_handler.py`)

Specialized handler for stored procedure constructs that standard SQL parsers may not fully support.

#### Capabilities:
- **Variable Extraction**: Parse DECLARE statements (Teradata and T-SQL styles)
- **Control Flow Analysis**: Extract IF/ELSE, WHILE loops, and other control structures
- **Cursor Management**: Identify cursor declarations and operations
- **Temporary Tables**: Parse temp table definitions with column schemas
- **Procedure Metadata**: Extract procedure names and parameters
- **Query Block Extraction**: Isolate parseable SQL blocks from procedural code
- **Preprocessing**: Clean SQL for standard parsing by removing procedural elements

## Installation

This module requires the following dependencies:

```bash
pip install sqlglot
pip install pyyaml  # Optional, for YAML serialization
```

## Usage

### Basic SQL Parsing

```python
from tools.ast_generator import SQLASTGenerator

# Initialize with a specific dialect
parser = SQLASTGenerator(dialect="teradata")

# Parse a single SQL statement
sql = "SELECT customer_id, name FROM customers WHERE status = 'ACTIVE'"
ast = parser.parse(sql)

# Get statement type
stmt_type = parser.get_statement_type(ast)  # Returns: "SELECT"

# Extract tables
tables = parser.get_tables(ast)  # Returns: ["customers"]

# Extract columns
columns = parser.get_columns(ast)  # Returns: [{"table": "customers", "column": "customer_id"}, ...]
```

### Parsing Multiple Statements

```python
# Parse multiple statements from a string
sql = """
    SELECT * FROM users;
    INSERT INTO logs (message) VALUES ('Started');
    UPDATE config SET value = 'enabled';
"""

statements = parser.parse_multiple(sql)
print(f"Found {len(statements)} statements")
```

### Parsing SQL Files

```python
# Parse a SQL file with metadata
result = parser.parse_file("path/to/script.sql")

if result.success:
    print(f"Parsed {result.metadata.statement_count} statements")
    for stmt in result.statements:
        print(parser.get_statement_type(stmt))
else:
    print("Errors:", result.metadata.error_messages)
```

### Safe Parsing with Error Recovery

```python
# Parse SQL with error handling and partial results
result = parser.parse_safe(sql)

if result.success:
    print(f"Successfully parsed {len(result.statements)} statements")
else:
    print("Partial results available:", len(result.statements))
    print("Errors:", result.metadata.error_messages)
```

### AST Serialization

```python
# Convert AST to JSON
ast = parser.parse("SELECT * FROM orders WHERE total > 100")
json_ast = parser.to_json(ast, include_sql=True)

# Convert AST to YAML
yaml_ast = parser.to_yaml(ast)
```

### SQL Transpilation

```python
# Convert from Teradata to Snowflake
teradata_sql = "SELECT TOP 10 * FROM customers"
snowflake_sql = parser.transpile(teradata_sql, target_dialect="snowflake")
# Result: "SELECT * FROM customers LIMIT 10"
```

### SQL Formatting

```python
# Format SQL with consistent styling
messy_sql = "select id,name,email from users where status='active'"
formatted = parser.format_sql(messy_sql, pretty=True)
# Result: Nicely formatted SQL with proper indentation
```

### Stored Procedure Processing

```python
from tools.ast_generator.stored_procedure_handler import StoredProcedureHandler

# Initialize handler
sp_handler = StoredProcedureHandler(dialect="teradata")

# Example stored procedure SQL
proc_sql = """
CREATE PROCEDURE update_customer_status(
    IN customer_id INT,
    IN new_status VARCHAR(20)
)
BEGIN
    DECLARE old_status VARCHAR(20);
    DECLARE affected_rows INT DEFAULT 0;
    
    -- Get current status
    SELECT status INTO old_status 
    FROM customers 
    WHERE id = customer_id;
    
    -- Update status
    UPDATE customers 
    SET status = new_status,
        updated_at = CURRENT_TIMESTAMP
    WHERE id = customer_id;
    
    SET affected_rows = ROW_COUNT();
    
    -- Log the change
    INSERT INTO audit_log (customer_id, old_value, new_value)
    VALUES (customer_id, old_status, new_status);
END;
"""

# Normalize procedure into components
normalized = sp_handler.normalize_procedure(proc_sql)

print(f"Procedure: {normalized.procedure_name}")
print(f"Parameters: {len(normalized.parameters)}")
print(f"Variables: {len(normalized.variables)}")
print(f"Query Blocks: {len(normalized.query_blocks)}")
```

### Extracting Procedure Components

```python
# Extract variables
variables = sp_handler.extract_variables(proc_sql)
for var in variables:
    print(f"Variable: {var.name}, Type: {var.data_type}, Default: {var.default_value}")

# Extract cursors
cursors = sp_handler.extract_cursors(proc_sql)
for cursor in cursors:
    print(f"Cursor: {cursor.name}, Query: {cursor.query}")

# Extract temporary tables
temp_tables = sp_handler.extract_temp_tables(proc_sql)
for table in temp_tables:
    print(f"Temp Table: {table.name}, Columns: {table.columns}")

# Extract control flow
control_flow = sp_handler.extract_control_flow(proc_sql)
for cf in control_flow:
    print(f"Type: {cf.element_type}, Condition: {cf.condition}")

# Extract query blocks for parsing
query_blocks = sp_handler.extract_query_blocks(proc_sql)
for i, block in enumerate(query_blocks):
    # Each block can now be parsed independently
    ast = parser.parse(block)
    print(f"Block {i}: {parser.get_statement_type(ast)}")
```

### Preprocessing Stored Procedures

```python
# Remove procedural elements for standard parsing
cleaned_sql = sp_handler.preprocess_for_parsing(proc_sql)

# Now parse with standard parser
statements = parser.parse_multiple(cleaned_sql)
```

## Data Models

### ParseResult

```python
@dataclass
class ParseResult:
    success: bool
    metadata: ASTMetadata
    statements: List[Expression] = field(default_factory=list)
```

### ASTMetadata

```python
@dataclass
class ASTMetadata:
    source_file: Optional[str]
    dialect: str
    parse_timestamp: str
    statement_count: int
    has_errors: bool
    error_messages: List[str]
```

### NormalizedProcedure

```python
@dataclass
class NormalizedProcedure:
    original_sql: str
    variables: List[Variable]
    cursors: List[Cursor]
    temp_tables: List[TempTable]
    control_flow: List[ControlFlowElement]
    query_blocks: List[str]
    procedure_name: Optional[str]
    parameters: List[Dict[str, str]]
```

### Variable

```python
@dataclass
class Variable:
    name: str
    data_type: str
    default_value: Optional[str]
    line_number: Optional[int]
```

### Cursor

```python
@dataclass
class Cursor:
    name: str
    query: str
    line_number: Optional[int]
```

### TempTable

```python
@dataclass
class TempTable:
    name: str
    definition_sql: str
    columns: List[Dict[str, str]]
    line_number: Optional[int]
```

### ControlFlowElement

```python
@dataclass
class ControlFlowElement:
    element_type: str  # IF, WHILE, LOOP, CASE, BEGIN/END
    condition: Optional[str]
    body_start_line: Optional[int]
    body_end_line: Optional[int]
    body_sql: Optional[str]
```

## Advanced Usage

### Combining Parser and Stored Procedure Handler

```python
# Full workflow for stored procedure analysis
parser = SQLASTGenerator(dialect="teradata")
sp_handler = StoredProcedureHandler(dialect="teradata")

# 1. Normalize the procedure
normalized = sp_handler.normalize_procedure(proc_sql)

# 2. Parse individual query blocks
parsed_blocks = []
for block in normalized.query_blocks:
    try:
        ast = parser.parse(block)
        parsed_blocks.append({
            'ast': ast,
            'type': parser.get_statement_type(ast),
            'tables': parser.get_tables(ast),
            'columns': parser.get_columns(ast)
        })
    except Exception as e:
        print(f"Could not parse block: {e}")

# 3. Generate comprehensive metadata
metadata = {
    'procedure': normalized.procedure_name,
    'parameters': normalized.parameters,
    'variables': normalized.variables,
    'cursors': normalized.cursors,
    'temp_tables': normalized.temp_tables,
    'control_flow': normalized.control_flow,
    'parsed_queries': parsed_blocks
}
```

## Error Handling

The module provides robust error handling:

```python
# Use parse_safe for production code
result = parser.parse_safe(potentially_invalid_sql)

if result.success:
    # Full parsing succeeded
    process_statements(result.statements)
else:
    # Check for partial results
    if result.statements:
        print(f"Parsed {len(result.statements)} out of {result.metadata.statement_count} statements")
        process_statements(result.statements)
    
    # Log errors
    for error in result.metadata.error_messages:
        logger.error(error)
```

## Best Practices

1. **Choose the Right Dialect**: Always specify the correct source dialect for accurate parsing
2. **Use Safe Parsing**: For production code, use `parse_safe()` to handle errors gracefully
3. **Handle Stored Procedures Separately**: Use `StoredProcedureHandler` first to normalize procedural code
4. **Serialize ASTs Carefully**: Set `include_sql=False` in `to_json()` for large ASTs to reduce size
5. **Validate Before Transpiling**: Always parse and validate before attempting transpilation
6. **Clean Procedural Code**: Use `preprocess_for_parsing()` to clean stored procedures before standard parsing

## Limitations

- Complex nested stored procedures may require manual preprocessing
- Some dialect-specific extensions may not be fully supported
- Very large SQL files may require streaming processing
- Certain proprietary SQL extensions (UDFs, custom operators) may not parse correctly

## Dependencies

- **SQLGlot**: Core SQL parsing and transpilation engine
- **PyYAML**: (Optional) For YAML serialization

## Contributing

When extending this module:
1. Add new dialect mappings to `DIALECT_MAP` in `SQLASTGenerator`
2. Add new procedural patterns to `PATTERNS` in `StoredProcedureHandler`
3. Ensure backward compatibility with existing parse results
4. Add unit tests for new features

## Related Modules

- **models/data_models**: Core data models (ASTMetadata, ParseResult)
- **tools/lineage**: Uses ASTs for lineage analysis
- **tools/documentation**: Generates documentation from ASTs
- **tools/deconstructor**: Extracts elements from ASTs

## License

Part of the SQL Reverse Engineering project.

## Support

For issues or questions, refer to the main project documentation or raise an issue in the project repository.
