"""
SQL AST Generator module.

This module provides functionality to parse SQL statements and generate
Abstract Syntax Trees (ASTs) that can be serialized and consumed by other tools.
"""

import sqlglot
from sqlglot import exp
from typing import List, Dict, Any, Optional, Union
from datetime import datetime
import json
import sys
import os

# Add parent directory to path for imports
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from models.data_models import ASTMetadata, ParseResult


class SQLASTGenerator:
    """
    Main entry point for parsing SQL and generating ASTs.
    Uses SQLGlot for multi-dialect parsing.
    """

    # Mapping of common dialect names to SQLGlot dialect names
    DIALECT_MAP = {
        "teradata": "teradata",
        "tsql": "tsql",
        "sqlserver": "tsql",
        "sql_server": "tsql",
        "snowflake": "snowflake",
        "bigquery": "bigquery",
        "postgres": "postgres",
        "postgresql": "postgres",
        "mysql": "mysql",
        "oracle": "oracle",
        "redshift": "redshift",
        "spark": "spark",
        "hive": "hive",
        "duckdb": "duckdb",
    }

    def __init__(self, dialect: str = "teradata"):
        """
        Initialize parser with specified dialect.

        Args:
            dialect: SQL dialect to use for parsing.
                     Supported: teradata, tsql, snowflake, bigquery, postgres, mysql, oracle
        """
        self.dialect = self._normalize_dialect(dialect)

    def _normalize_dialect(self, dialect: str) -> str:
        """Normalize dialect name to SQLGlot format."""
        dialect_lower = dialect.lower().strip()
        return self.DIALECT_MAP.get(dialect_lower, dialect_lower)

    def preprocess_teradata_ddl(self, sql: str) -> str:
        """
        Preprocess Teradata DDL to remove unsupported syntax before parsing.
        
        Handles:
        - CREATE SET TABLE -> CREATE TABLE
        - CREATE MULTISET TABLE -> CREATE TABLE
        - FALLBACK/NO FALLBACK
        - BEFORE/AFTER JOURNAL clauses
        - CHECKSUM clause
        - MERGEBLOCKRATIO clause
        - MAP clause
        - CHARACTER SET LATIN
        - NOT CASESPECIFIC
        - COMPRESS clauses
        - WITH DATA / WITH NO DATA
        - PRIMARY INDEX / UNIQUE PRIMARY INDEX
        - Line breaks within identifiers
        
        Args:
            sql: Original Teradata DDL
            
        Returns:
            Cleaned DDL that sqlglot can parse
        """
        import re
        
        cleaned = sql
        
        # First, fix line breaks within identifiers (e.g., column names split across lines)
        # Pattern: identifier followed by line break and continuation
        cleaned = re.sub(r'(\w+_)\s*\n\s*(\d+)\s+', r'\1\2 ', cleaned)
        
        # Fix line breaks within keywords (e.g., CASESPECIFIC split as "C\n ASESPECIFIC")
        # This commonly happens with Teradata exports
        cleaned = re.sub(r'\bC\s*\n\s*ASESPECIFIC\b', 'CASESPECIFIC', cleaned, flags=re.IGNORECASE)
        cleaned = re.sub(r'\bCASE\s*\n\s*SPECIFIC\b', 'CASESPECIFIC', cleaned, flags=re.IGNORECASE)
        
        # Replace CREATE SET TABLE / CREATE MULTISET TABLE with CREATE TABLE
        cleaned = re.sub(r'CREATE\s+(?:SET|MULTISET)\s+TABLE', 'CREATE TABLE', cleaned, flags=re.IGNORECASE)
        
        # Remove FALLBACK / NO FALLBACK clause (with optional comma)
        cleaned = re.sub(r',?\s*(?:NO\s+)?FALLBACK\s*,?', ' ', cleaned, flags=re.IGNORECASE)
        
        # Remove BEFORE/AFTER JOURNAL clauses
        cleaned = re.sub(r',?\s*NO\s+BEFORE\s+JOURNAL\s*,?', ' ', cleaned, flags=re.IGNORECASE)
        cleaned = re.sub(r',?\s*NO\s+AFTER\s+JOURNAL\s*,?', ' ', cleaned, flags=re.IGNORECASE)
        cleaned = re.sub(r',?\s*(?:DUAL\s+)?(?:LOCAL\s+)?(?:NOT\s+LOCAL\s+)?AFTER\s+JOURNAL\s*,?', ' ', cleaned, flags=re.IGNORECASE)
        cleaned = re.sub(r',?\s*(?:DUAL\s+)?(?:LOCAL\s+)?(?:NOT\s+LOCAL\s+)?BEFORE\s+JOURNAL\s*,?', ' ', cleaned, flags=re.IGNORECASE)
        
        # Remove CHECKSUM clause
        cleaned = re.sub(r',?\s*CHECKSUM\s*=\s*\w+\s*,?', ' ', cleaned, flags=re.IGNORECASE)
        
        # Remove MERGEBLOCKRATIO clause
        cleaned = re.sub(r',?\s*(?:DEFAULT\s+)?MERGEBLOCKRATIO\s*(?:=\s*\d+(?:\s*PERCENT)?)?\s*,?', ' ', cleaned, flags=re.IGNORECASE)
        
        # Remove MAP clause
        cleaned = re.sub(r',?\s*MAP\s*=\s*\w+\s*,?', ' ', cleaned, flags=re.IGNORECASE)
        
        # Remove CHARACTER SET LATIN/UNICODE
        cleaned = re.sub(r'\s+CHARACTER\s+SET\s+(?:LATIN|UNICODE|GRAPHIC)\s*', ' ', cleaned, flags=re.IGNORECASE)
        
        # Remove NOT CASESPECIFIC / CASESPECIFIC
        cleaned = re.sub(r'\s+(?:NOT\s+)?CASESPECIFIC\s*', ' ', cleaned, flags=re.IGNORECASE)
        
        # Remove FORMAT clause
        cleaned = re.sub(r"\s+FORMAT\s+'[^']*'\s*", ' ', cleaned, flags=re.IGNORECASE)
        
        # Remove TITLE clause
        cleaned = re.sub(r"\s+TITLE\s+'[^']*'\s*", ' ', cleaned, flags=re.IGNORECASE)
        
        # Remove COMPRESS clause (including value lists)
        cleaned = re.sub(r'\s+COMPRESS\s*(?:\([^)]*\))?\s*', ' ', cleaned, flags=re.IGNORECASE)
        
        # Remove WITH DATA / WITH NO DATA
        cleaned = re.sub(r'\s+WITH\s+(?:NO\s+)?DATA\s*', ' ', cleaned, flags=re.IGNORECASE)
        
        # Remove UNIQUE PRIMARY INDEX / PRIMARY INDEX (entire clause until next major keyword or semicolon)
        cleaned = re.sub(r'\s*(?:UNIQUE\s+)?PRIMARY\s+INDEX\s*\([^)]*\)\s*', ' ', cleaned, flags=re.IGNORECASE)
        
        # Remove PARTITION BY clause (can be complex)
        cleaned = re.sub(r'\s+PARTITION\s+BY\s+[^;]+(?=;|$)', ' ', cleaned, flags=re.IGNORECASE)
        
        # Remove INDEX clauses at end
        cleaned = re.sub(r'\s+INDEX\s+\w+\s*\([^)]*\)\s*', ' ', cleaned, flags=re.IGNORECASE)
        
        # Clean up multiple spaces and commas
        cleaned = re.sub(r'\s+', ' ', cleaned)
        cleaned = re.sub(r',\s*,', ',', cleaned)
        cleaned = re.sub(r'\(\s*,', '(', cleaned)
        cleaned = re.sub(r',\s*\)', ')', cleaned)
        
        return cleaned.strip()

    def preprocess_teradata_sql(self, sql: str) -> str:
        """
        Preprocess Teradata SQL (views, queries) to handle unsupported syntax.

        Handles:
        - MONTH(n), YEAR(n), DAY(n) interval precision syntax
        - REPLACE VIEW -> CREATE VIEW
        - 'value' (TIMESTAMP(0)) -> CAST('value' AS TIMESTAMP(0))
        - 'value' (DATE) -> CAST('value' AS DATE)

        Args:
            sql: Original Teradata SQL

        Returns:
            Cleaned SQL that sqlglot can parse
        """
        import re

        cleaned = sql

        # Replace REPLACE VIEW with CREATE OR REPLACE VIEW
        cleaned = re.sub(r'\bREPLACE\s+VIEW\b', 'CREATE OR REPLACE VIEW', cleaned, flags=re.IGNORECASE)

        # Handle MONTH(n), YEAR(n), DAY(n) interval precision - remove the precision
        # e.g., MONTH(4) -> MONTH, YEAR(4) -> YEAR
        cleaned = re.sub(r'\b(MONTH|YEAR|DAY|HOUR|MINUTE|SECOND)\s*\(\s*\d+\s*\)', r'\1', cleaned, flags=re.IGNORECASE)

        # Convert Teradata inline type casts: 'value' (TYPE) -> CAST('value' AS TYPE)
        # Pattern 1: wrapped in outer parens
        cleaned = re.sub(
            r"\('([^']+)'\s*\(([A-Z][A-Z0-9_]*(?:\s*\(\s*\d+\s*\))?)\)\)",
            r"CAST('\1' AS \2)",
            cleaned, flags=re.IGNORECASE
        )
        # Pattern 2: bare (skip if preceded by CAST( or AS)
        _p2 = re.compile(
            r"'([^']+)'\s*\(([A-Z][A-Z0-9_]*(?:\s*\(\s*\d+\s*\))?)\)",
            re.IGNORECASE
        )
        _parts = []
        _last = 0
        for _m in _p2.finditer(cleaned):
            _pfx = cleaned[max(0, _m.start() - 5):_m.start()].upper()
            if 'CAST(' not in _pfx and 'AS ' not in _pfx:
                _parts.append(cleaned[_last:_m.start()])
                _parts.append(f"CAST('{_m.group(1)}' AS {_m.group(2)})")
                _last = _m.end()
        if _parts:
            _parts.append(cleaned[_last:])
            cleaned = ''.join(_parts)

        return cleaned

    def _looks_like_teradata_ddl(self, sql: str) -> bool:
        """
        Check if SQL looks like Teradata DDL with specific syntax.
        
        Args:
            sql: SQL string to check
            
        Returns:
            True if it appears to be Teradata-specific DDL
        """
        import re
        sql_upper = sql.upper()
        
        # Check for Teradata-specific DDL markers
        teradata_markers = [
            r'CREATE\s+(?:SET|MULTISET)\s+TABLE',
            r'\bFALLBACK\b',
            r'\bNO\s+(?:BEFORE|AFTER)\s+JOURNAL\b',
            r'\bCHECKSUM\s*=',
            r'\bMERGEBLOCKRATIO\b',
            r'\bMAP\s*=\s*TD_MAP',
            r'\bCHARACTER\s+SET\s+LATIN\b',
            r'\bNOT\s+CASESPECIFIC\b',
        ]
        
        for pattern in teradata_markers:
            if re.search(pattern, sql_upper):
                return True
        
        return False

    def parse(self, sql: str) -> exp.Expression:
        """
        Parse a single SQL statement into AST.

        Args:
            sql: SQL string to parse

        Returns:
            sqlglot.Expression: Parsed AST

        Raises:
            sqlglot.errors.ParseError: If SQL cannot be parsed
        """
        return sqlglot.parse_one(sql, read=self.dialect)

    def parse_multiple(self, sql: str) -> List[exp.Expression]:
        """
        Parse multiple SQL statements.

        Args:
            sql: SQL string containing one or more statements

        Returns:
            List of parsed AST expressions
        """
        return sqlglot.parse(sql, read=self.dialect)

    def parse_file(self, filepath: str) -> ParseResult:
        """
        Parse SQL file, handling multiple statements.

        Args:
            filepath: Path to SQL file

        Returns:
            ParseResult with metadata and parsed statements
        """
        metadata = ASTMetadata(
            source_file=filepath,
            dialect=self.dialect,
            parse_timestamp=datetime.now().isoformat()
        )

        try:
            with open(filepath, 'r', encoding='utf-8') as f:
                sql = f.read()

            statements = self.parse_multiple(sql)
            metadata.statement_count = len(statements)

            return ParseResult(
                success=True,
                metadata=metadata,
                statements=statements
            )

        except Exception as e:
            metadata.has_errors = True
            metadata.error_messages.append(str(e))
            return ParseResult(
                success=False,
                metadata=metadata
            )

    def parse_safe(self, sql: str, preprocess_ddl: bool = True) -> ParseResult:
        """
        Parse SQL with error handling, returning partial results on failure.

        Args:
            sql: SQL string to parse
            preprocess_ddl: Whether to preprocess Teradata DDL to remove unsupported syntax

        Returns:
            ParseResult with success status and any parsed statements
        """
        metadata = ASTMetadata(
            dialect=self.dialect,
            parse_timestamp=datetime.now().isoformat()
        )

        # Strip line-continuation double quotes from source exports.
        # Pattern: '"\n"' where a line ends with " and the next starts with "
        # These are artefacts from Teradata export/extract tools.
        # Rejoin without inserting whitespace so split tokens like SELE"<nl>"CT become SELECT.
        import re
        sql = re.sub(r'"\s*\n\s*"', '', sql)

        # Strip Teradata inline type annotations: `expr (DECIMAL(N,M))` → `expr`
        # These appear after expressions, e.g.:
        #   COALESCE(SUM(X), 0) (DECIMAL(16,6)) AS Y
        #   A.RATE *100 (DECIMAL(20,8))
        # SQLGlot can't parse these when applied to complex expressions.
        # Negative lookbehind preserves CAST(X AS DECIMAL(N,M)).
        sql = re.sub(
            r'(?<!\bAS)\s*\(DECIMAL\s*\(\s*\d+\s*,\s*\d+\s*\)\)',
            '',
            sql, flags=re.IGNORECASE
        )

        # Strip # prefix from temp table names (SQL Server convention
        # sometimes carried over into Teradata SPs, e.g. #tmpXref).
        # sqlglot's Teradata dialect tokenizes # as HASH and rejects it.
        sql = re.sub(r'#(\w+)', r'\1', sql)

        # Convert Teradata inline type casts to standard CAST syntax.
        # Teradata uses: 'value' (TIMESTAMP(0)), 'value' (DATE), etc.
        # sqlglot can't parse this — convert to CAST('value' AS TYPE).
        # Pattern 1: wrapped in outer parens — ('value' (TYPE))
        sql = re.sub(
            r"\('([^']+)'\s*\(([A-Z][A-Z0-9_]*(?:\s*\(\s*\d+\s*\))?)\)\)",
            r"CAST('\1' AS \2)",
            sql, flags=re.IGNORECASE
        )
        # Pattern 2: bare — 'value' (TYPE)
        # Iterate to skip matches already inside CAST() or after AS.
        _cast_p2 = re.compile(
            r"'([^']+)'\s*\(([A-Z][A-Z0-9_]*(?:\s*\(\s*\d+\s*\))?)\)",
            re.IGNORECASE
        )
        _cast_parts = []
        _cast_last = 0
        for _cm in _cast_p2.finditer(sql):
            _prefix = sql[max(0, _cm.start() - 5):_cm.start()].upper()
            if 'CAST(' not in _prefix and 'AS ' not in _prefix:
                _cast_parts.append(sql[_cast_last:_cm.start()])
                _cast_parts.append(f"CAST('{_cm.group(1)}' AS {_cm.group(2)})")
                _cast_last = _cm.end()
        if _cast_parts:
            _cast_parts.append(sql[_cast_last:])
            sql = ''.join(_cast_parts)

        # Try original SQL first
        original_sql = sql

        try:
            statements = self.parse_multiple(sql)
            metadata.statement_count = len(statements)

            return ParseResult(
                success=True,
                metadata=metadata,
                statements=statements
            )

        except sqlglot.errors.ParseError as e:
            # If it's Teradata and looks like DDL, try preprocessing
            if preprocess_ddl and self.dialect == 'teradata' and self._looks_like_teradata_ddl(sql):
                try:
                    cleaned_sql = self.preprocess_teradata_ddl(sql)
                    statements = self.parse_multiple(cleaned_sql)
                    metadata.statement_count = len(statements)
                    metadata.notes = ["Preprocessed Teradata DDL to remove unsupported syntax"]
                    return ParseResult(
                        success=True,
                        metadata=metadata,
                        statements=statements
                    )
                except Exception:
                    pass  # Fall through to SQL preprocessing
            
            # Try Teradata SQL preprocessing (for views, queries with MONTH(n) etc.)
            if preprocess_ddl and self.dialect == 'teradata':
                try:
                    cleaned_sql = self.preprocess_teradata_sql(sql)
                    statements = self.parse_multiple(cleaned_sql)
                    metadata.statement_count = len(statements)
                    metadata.notes = ["Preprocessed Teradata SQL to handle interval syntax"]
                    return ParseResult(
                        success=True,
                        metadata=metadata,
                        statements=statements
                    )
                except Exception:
                    pass  # Fall through to normal error handling
            
            metadata.has_errors = True
            metadata.error_messages.append(f"Parse error: {str(e)}")

            # Try to parse statement by statement
            partial_statements = []
            for i, stmt_sql in enumerate(self._split_statements(sql)):
                try:
                    stmt = sqlglot.parse_one(stmt_sql.strip(), read=self.dialect)
                    partial_statements.append(stmt)
                except Exception as stmt_error:
                    metadata.error_messages.append(
                        f"Statement {i + 1} error: {str(stmt_error)}"
                    )

            metadata.statement_count = len(partial_statements)
            return ParseResult(
                success=len(partial_statements) > 0,
                metadata=metadata,
                statements=partial_statements
            )

        except Exception as e:
            metadata.has_errors = True
            metadata.error_messages.append(f"Unexpected error: {str(e)}")
            return ParseResult(
                success=False,
                metadata=metadata
            )

    def _split_statements(self, sql: str) -> List[str]:
        """Split SQL into individual statements by semicolon."""
        # Simple split - may need enhancement for complex cases
        statements = []
        current = []
        in_string = False
        string_char = None

        for char in sql:
            if char in ("'", '"') and not in_string:
                in_string = True
                string_char = char
            elif char == string_char and in_string:
                in_string = False
                string_char = None

            if char == ';' and not in_string:
                stmt = ''.join(current).strip()
                if stmt:
                    statements.append(stmt)
                current = []
            else:
                current.append(char)

        # Add final statement if any
        stmt = ''.join(current).strip()
        if stmt:
            statements.append(stmt)

        return statements

    def to_json(self, ast: exp.Expression, include_sql: bool = True) -> dict:
        """
        Serialize AST to JSON format.

        Args:
            ast: Parsed AST expression
            include_sql: Whether to include SQL text for each node

        Returns:
            Dictionary representation of AST
        """
        return self._serialize_node(ast, include_sql)

    def _serialize_node(self, node: exp.Expression, include_sql: bool = True) -> dict:
        """
        Recursively serialize an AST node to dictionary.

        Args:
            node: AST node to serialize
            include_sql: Whether to include SQL text

        Returns:
            Dictionary representation of the node
        """
        if node is None:
            return None

        result = {
            "type": node.__class__.__name__,
            "key": node.key if hasattr(node, 'key') else None,
        }

        if include_sql:
            try:
                result["sql"] = node.sql(dialect=self.dialect)
            except Exception:
                result["sql"] = str(node)

        # Serialize arguments (child nodes)
        if hasattr(node, 'args') and node.args:
            result["args"] = {}
            for key, value in node.args.items():
                if value is None:
                    continue
                elif isinstance(value, list):
                    result["args"][key] = [
                        self._serialize_node(v, include_sql) if isinstance(v, exp.Expression) else v
                        for v in value
                    ]
                elif isinstance(value, exp.Expression):
                    result["args"][key] = self._serialize_node(value, include_sql)
                else:
                    # Convert non-serializable objects (e.g. sqlglot Type enums) to strings
                    try:
                        json.dumps(value)
                        result["args"][key] = value
                    except (TypeError, ValueError):
                        result["args"][key] = str(value)

        return result

    def to_yaml(self, ast: exp.Expression) -> str:
        """
        Serialize AST to YAML format.

        Args:
            ast: Parsed AST expression

        Returns:
            YAML string representation
        """
        try:
            import yaml
            return yaml.dump(self.to_json(ast), default_flow_style=False, sort_keys=False)
        except ImportError:
            raise ImportError("PyYAML is required for YAML serialization. Install with: pip install pyyaml")

    def get_statement_type(self, ast: exp.Expression) -> str:
        """
        Identify the type of SQL statement.

        Args:
            ast: Parsed AST expression

        Returns:
            Statement type: SELECT, INSERT, UPDATE, DELETE, CREATE, etc.
        """
        type_map = {
            exp.Select: "SELECT",
            exp.Insert: "INSERT",
            exp.Update: "UPDATE",
            exp.Delete: "DELETE",
            exp.Create: "CREATE",
            exp.Drop: "DROP",
            exp.Alter: "ALTER",
            exp.Merge: "MERGE",
            exp.Union: "UNION",
            exp.Intersect: "INTERSECT",
            exp.Except: "EXCEPT",
        }

        for exp_type, name in type_map.items():
            if isinstance(ast, exp_type):
                return name

        return ast.__class__.__name__.upper()

    def get_tables(self, ast: exp.Expression) -> List[str]:
        """
        Extract all table names referenced in the AST.

        Args:
            ast: Parsed AST expression

        Returns:
            List of table names
        """
        tables = []
        for table in ast.find_all(exp.Table):
            name = table.name
            if table.db:
                name = f"{table.db}.{name}"
            if table.catalog:
                name = f"{table.catalog}.{name}"
            tables.append(name)
        return list(set(tables))

    def get_columns(self, ast: exp.Expression) -> List[Dict[str, str]]:
        """
        Extract all column references in the AST.

        Args:
            ast: Parsed AST expression

        Returns:
            List of column info dicts with table and column names
        """
        columns = []
        for col in ast.find_all(exp.Column):
            columns.append({
                "table": col.table if col.table else None,
                "column": col.name
            })
        return columns

    def transpile(self, sql: str, target_dialect: str) -> str:
        """
        Transpile SQL from current dialect to target dialect.

        Args:
            sql: SQL string to transpile
            target_dialect: Target SQL dialect

        Returns:
            Transpiled SQL string
        """
        target = self._normalize_dialect(target_dialect)
        return sqlglot.transpile(sql, read=self.dialect, write=target)[0]

    def format_sql(self, sql: str, pretty: bool = True) -> str:
        """
        Format SQL with consistent styling.

        Args:
            sql: SQL string to format
            pretty: Whether to use pretty formatting

        Returns:
            Formatted SQL string
        """
        ast = self.parse(sql)
        return ast.sql(dialect=self.dialect, pretty=pretty)
