"""
Stored Procedure Handler module.

Handles stored procedure-specific syntax that standard SQL parsers
may not fully support, including variables, control flow, and cursors.
"""

import re
from typing import List, Dict, Any, Optional, Tuple
from dataclasses import dataclass, field


@dataclass
class Variable:
    """SQL variable declaration."""
    name: str
    data_type: str
    default_value: Optional[str] = None
    line_number: Optional[int] = None


@dataclass
class ControlFlowElement:
    """Control flow statement (IF, WHILE, LOOP, etc.)."""
    element_type: str  # IF, WHILE, LOOP, CASE, BEGIN/END
    condition: Optional[str] = None
    body_start_line: Optional[int] = None
    body_end_line: Optional[int] = None
    body_sql: Optional[str] = None


@dataclass
class Cursor:
    """Cursor declaration."""
    name: str
    query: str
    line_number: Optional[int] = None


@dataclass
class TempTable:
    """Temporary table definition."""
    name: str
    definition_sql: str
    columns: List[Dict[str, str]] = field(default_factory=list)
    line_number: Optional[int] = None


@dataclass
class NormalizedProcedure:
    """Normalized stored procedure structure."""
    original_sql: str
    variables: List[Variable] = field(default_factory=list)
    cursors: List[Cursor] = field(default_factory=list)
    temp_tables: List[TempTable] = field(default_factory=list)
    control_flow: List[ControlFlowElement] = field(default_factory=list)
    query_blocks: List[str] = field(default_factory=list)  # Main parseable SQL blocks
    procedure_name: Optional[str] = None
    parameters: List[Dict[str, str]] = field(default_factory=list)


class StoredProcedureHandler:
    """
    Handle stored procedure-specific syntax that SQLGlot may not fully support.
    Pre-processes SQL to extract procedural elements.
    """

    # Patterns for Teradata and SQL Server procedural elements
    PATTERNS = {
        # Variable declarations
        'teradata_declare': re.compile(
            r'DECLARE\s+(\w+)\s+(\w+(?:\s*\([^)]+\))?)\s*(?:DEFAULT\s+(.+?))?;',
            re.IGNORECASE | re.DOTALL
        ),
        'tsql_declare': re.compile(
            r'DECLARE\s+@(\w+)\s+(\w+(?:\s*\([^)]+\))?)\s*(?:=\s*(.+?))?(?:;|$)',
            re.IGNORECASE | re.DOTALL
        ),

        # Cursor declarations
        'cursor': re.compile(
            r'DECLARE\s+(\w+)\s+CURSOR\s+FOR\s+(.+?)(?:;|$)',
            re.IGNORECASE | re.DOTALL
        ),

        # Temp table creation
        'temp_table': re.compile(
            r'CREATE\s+(?:VOLATILE\s+|TEMP(?:ORARY)?\s+)?TABLE\s+(#?\w+)\s*\(([^)]+)\)',
            re.IGNORECASE | re.DOTALL
        ),

        # Procedure definition
        'procedure_def': re.compile(
            r'CREATE\s+(?:OR\s+REPLACE\s+)?PROCEDURE\s+(\w+(?:\.\w+)*)\s*\(([^)]*)\)',
            re.IGNORECASE | re.DOTALL
        ),

        # IF statements
        'if_stmt': re.compile(
            r'IF\s+(.+?)\s+THEN\s+(.+?)(?:ELSE\s+(.+?))?END\s+IF',
            re.IGNORECASE | re.DOTALL
        ),

        # WHILE loops
        'while_stmt': re.compile(
            r'WHILE\s+(.+?)\s+DO\s+(.+?)END\s+WHILE',
            re.IGNORECASE | re.DOTALL
        ),

        # SET statements
        'set_stmt': re.compile(
            r'SET\s+@?(\w+)\s*=\s*(.+?)(?:;|$)',
            re.IGNORECASE
        ),
    }

    def __init__(self, dialect: str = "teradata"):
        """
        Initialize handler with dialect.

        Args:
            dialect: SQL dialect (teradata, tsql, etc.)
        """
        self.dialect = dialect.lower()

    def extract_variables(self, sql: str) -> List[Variable]:
        """
        Extract DECLARE statements and variable definitions.

        Args:
            sql: SQL string to analyze

        Returns:
            List of Variable objects
        """
        variables = []

        # Try Teradata-style DECLARE
        for match in self.PATTERNS['teradata_declare'].finditer(sql):
            variables.append(Variable(
                name=match.group(1),
                data_type=match.group(2),
                default_value=match.group(3).strip() if match.group(3) else None,
                line_number=sql[:match.start()].count('\n') + 1
            ))

        # Try T-SQL style DECLARE
        for match in self.PATTERNS['tsql_declare'].finditer(sql):
            variables.append(Variable(
                name=match.group(1),
                data_type=match.group(2),
                default_value=match.group(3).strip() if match.group(3) else None,
                line_number=sql[:match.start()].count('\n') + 1
            ))

        return variables

    def extract_control_flow(self, sql: str) -> List[ControlFlowElement]:
        """
        Extract IF/ELSE, WHILE, LOOP control structures.

        Args:
            sql: SQL string to analyze

        Returns:
            List of ControlFlowElement objects
        """
        control_flow = []

        # Extract IF statements
        for match in self.PATTERNS['if_stmt'].finditer(sql):
            control_flow.append(ControlFlowElement(
                element_type='IF',
                condition=match.group(1).strip(),
                body_sql=match.group(2).strip()
            ))

        # Extract WHILE loops
        for match in self.PATTERNS['while_stmt'].finditer(sql):
            control_flow.append(ControlFlowElement(
                element_type='WHILE',
                condition=match.group(1).strip(),
                body_sql=match.group(2).strip()
            ))

        return control_flow

    def extract_cursors(self, sql: str) -> List[Cursor]:
        """
        Extract cursor declarations and fetch operations.

        Args:
            sql: SQL string to analyze

        Returns:
            List of Cursor objects
        """
        cursors = []

        for match in self.PATTERNS['cursor'].finditer(sql):
            cursors.append(Cursor(
                name=match.group(1),
                query=match.group(2).strip(),
                line_number=sql[:match.start()].count('\n') + 1
            ))

        return cursors

    def extract_temp_tables(self, sql: str) -> List[TempTable]:
        """
        Extract temporary table definitions.

        Args:
            sql: SQL string to analyze

        Returns:
            List of TempTable objects
        """
        temp_tables = []

        for match in self.PATTERNS['temp_table'].finditer(sql):
            table_name = match.group(1)
            columns_def = match.group(2)

            # Parse column definitions
            columns = []
            for col_def in columns_def.split(','):
                col_def = col_def.strip()
                if col_def:
                    parts = col_def.split()
                    if len(parts) >= 2:
                        columns.append({
                            'name': parts[0],
                            'type': ' '.join(parts[1:])
                        })

            temp_tables.append(TempTable(
                name=table_name,
                definition_sql=match.group(0),
                columns=columns,
                line_number=sql[:match.start()].count('\n') + 1
            ))

        return temp_tables

    def extract_procedure_info(self, sql: str) -> Tuple[Optional[str], List[Dict[str, str]]]:
        """
        Extract procedure name and parameters.

        Args:
            sql: SQL string to analyze

        Returns:
            Tuple of (procedure_name, parameters_list)
        """
        match = self.PATTERNS['procedure_def'].search(sql)
        if not match:
            return None, []

        proc_name = match.group(1)
        params_str = match.group(2)

        # Parse parameters
        parameters = []
        if params_str.strip():
            for param in params_str.split(','):
                param = param.strip()
                if param:
                    parts = param.split()
                    if len(parts) >= 2:
                        # Handle IN/OUT/INOUT modifiers
                        mode = 'IN'
                        name_idx = 0
                        if parts[0].upper() in ('IN', 'OUT', 'INOUT'):
                            mode = parts[0].upper()
                            name_idx = 1

                        if len(parts) > name_idx + 1:
                            parameters.append({
                                'name': parts[name_idx],
                                'type': ' '.join(parts[name_idx + 1:]),
                                'mode': mode
                            })

        return proc_name, parameters

    def extract_query_blocks(self, sql: str) -> List[str]:
        """
        Extract main SQL query blocks (SELECT, INSERT, UPDATE, DELETE)
        that can be parsed by standard SQL parsers.

        Args:
            sql: SQL string to analyze

        Returns:
            List of SQL query strings
        """
        # Remove procedural elements
        cleaned_sql = sql

        # Remove variable declarations
        cleaned_sql = re.sub(
            r'DECLARE\s+@?\w+\s+\w+(?:\s*\([^)]+\))?(?:\s*(?:DEFAULT|=)\s+[^;]+)?;?',
            '',
            cleaned_sql,
            flags=re.IGNORECASE
        )

        # Remove SET statements
        cleaned_sql = re.sub(
            r'SET\s+@?\w+\s*=\s*[^;]+;?',
            '',
            cleaned_sql,
            flags=re.IGNORECASE
        )

        # Remove cursor operations
        cleaned_sql = re.sub(
            r'(?:OPEN|CLOSE|FETCH|DEALLOCATE)\s+\w+\s*;?',
            '',
            cleaned_sql,
            flags=re.IGNORECASE
        )

        # Find main query blocks
        query_blocks = []
        query_pattern = re.compile(
            r'((?:WITH\s+.+?\s+AS\s*\(.+?\)\s*,?\s*)*'
            r'(?:SELECT|INSERT|UPDATE|DELETE|MERGE)\s+.+?)(?=(?:SELECT|INSERT|UPDATE|DELETE|MERGE|$))',
            re.IGNORECASE | re.DOTALL
        )

        for match in query_pattern.finditer(cleaned_sql):
            block = match.group(1).strip()
            if block:
                # Clean up the block
                block = re.sub(r'\s+', ' ', block)
                block = block.rstrip(';').strip()
                if block:
                    query_blocks.append(block)

        return query_blocks

    def normalize_procedure(self, sql: str) -> NormalizedProcedure:
        """
        Normalize stored procedure into structured components.

        Args:
            sql: SQL string to normalize

        Returns:
            NormalizedProcedure with separated components
        """
        proc_name, parameters = self.extract_procedure_info(sql)

        return NormalizedProcedure(
            original_sql=sql,
            variables=self.extract_variables(sql),
            cursors=self.extract_cursors(sql),
            temp_tables=self.extract_temp_tables(sql),
            control_flow=self.extract_control_flow(sql),
            query_blocks=self.extract_query_blocks(sql),
            procedure_name=proc_name,
            parameters=parameters
        )

    def remove_comments(self, sql: str) -> str:
        """
        Remove SQL comments from the code using a single-pass state machine.

        Handles tricky cases like:
        - ``--`` line comments inside ``/* */`` block comments (ignored)
        - ``*/`` on a line starting with dashes (e.g. ``---- */``)
        - Nested or overlapping comment markers inside string literals

        Args:
            sql: SQL string

        Returns:
            SQL with comments removed
        """
        result = []
        i = 0
        length = len(sql)
        in_string = False
        string_char = None

        while i < length:
            # --- Inside a string literal: pass through until closing quote ---
            if in_string:
                ch = sql[i]
                result.append(ch)
                if ch == string_char:
                    # Check for escaped quote (doubled quote)
                    if i + 1 < length and sql[i + 1] == string_char:
                        result.append(sql[i + 1])
                        i += 2
                        continue
                    in_string = False
                    string_char = None
                i += 1
                continue

            # --- Block comment: /* ... */ ---
            if sql[i:i + 2] == '/*':
                # Skip everything until */
                end = sql.find('*/', i + 2)
                if end == -1:
                    # Unclosed block comment — drop the rest
                    break
                i = end + 2
                continue

            # --- Line comment: -- ... \n ---
            if sql[i:i + 2] == '--':
                # Skip to end of line
                newline = sql.find('\n', i + 2)
                if newline == -1:
                    break
                result.append('\n')
                i = newline + 1
                continue

            # --- Start of string literal ---
            ch = sql[i]
            if ch in ("'",):
                in_string = True
                string_char = ch

            result.append(ch)
            i += 1

        return ''.join(result)

    def preprocess_for_parsing(self, sql: str) -> str:
        """
        Preprocess SQL for standard parsing by removing procedural elements.

        Args:
            sql: Original SQL string

        Returns:
            Cleaned SQL suitable for standard parsing
        """
        # Remove comments
        sql = self.remove_comments(sql)

        # Remove GO statements (T-SQL batch separator)
        sql = re.sub(r'\bGO\b', '', sql, flags=re.IGNORECASE)

        # Remove SET statements that are not assignments
        sql = re.sub(
            r'SET\s+(?:NOCOUNT|ANSI_NULLS|QUOTED_IDENTIFIER|XACT_ABORT)\s+(?:ON|OFF)\s*;?',
            '',
            sql,
            flags=re.IGNORECASE
        )

        # Remove USE database statements
        sql = re.sub(r'USE\s+\w+\s*;?', '', sql, flags=re.IGNORECASE)

        # Remove PRINT statements
        sql = re.sub(r'PRINT\s+[^;]+;?', '', sql, flags=re.IGNORECASE)

        # Clean up whitespace
        sql = re.sub(r'\n\s*\n', '\n', sql)
        sql = sql.strip()

        return sql
