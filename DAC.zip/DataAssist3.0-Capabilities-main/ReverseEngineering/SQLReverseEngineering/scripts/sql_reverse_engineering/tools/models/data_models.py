"""
Data models for SQL reverse engineering system.

This module defines all the core data structures used throughout the system
for representing SQL elements, lineage information, and transformations.
"""

from dataclasses import dataclass, field
from typing import List, Optional, Dict, Any, Union
from enum import Enum
import json


class TransformationType(Enum):
    """Top-level transformation type classification."""
    DIRECT = "DIRECT"
    INDIRECT = "INDIRECT"


class TransformationSubtype(Enum):
    """Detailed transformation subtype classification."""
    # Direct subtypes
    IDENTITY = "IDENTITY"
    RENAME = "RENAME"
    CAST = "CAST"

    # Indirect subtypes
    TRANSFORMATION = "TRANSFORMATION"
    AGGREGATION = "AGGREGATION"
    JOIN = "JOIN"
    FILTER = "FILTER"
    GROUP_BY = "GROUP_BY"
    WINDOW = "WINDOW"
    CASE_LOGIC = "CASE_LOGIC"
    COALESCE = "COALESCE"
    STRING_MANIPULATION = "STRING_MANIPULATION"
    DATE_MANIPULATION = "DATE_MANIPULATION"
    MATHEMATICAL = "MATHEMATICAL"
    UNKNOWN = "UNKNOWN"


@dataclass
class ColumnRef:
    """Reference to a column in a table."""
    table_name: str
    column_name: str
    schema_name: Optional[str] = None
    alias: Optional[str] = None

    def qualified_name(self) -> str:
        """Return fully qualified column name."""
        parts = [p for p in [self.schema_name, self.table_name, self.column_name] if p]
        return ".".join(parts)

    def to_dict(self) -> dict:
        return {
            "schema_name": self.schema_name,
            "table_name": self.table_name,
            "column_name": self.column_name,
            "alias": self.alias,
            "qualified_name": self.qualified_name()
        }

    def __hash__(self):
        return hash((self.schema_name, self.table_name, self.column_name))

    def __eq__(self, other):
        if not isinstance(other, ColumnRef):
            return False
        return (self.schema_name == other.schema_name and
                self.table_name == other.table_name and
                self.column_name == other.column_name)


@dataclass
class CaseBranch:
    """Single WHEN/THEN branch in a CASE statement."""
    condition: str
    result: str
    condition_columns: List[ColumnRef] = field(default_factory=list)
    result_columns: List[ColumnRef] = field(default_factory=list)

    def to_dict(self) -> dict:
        return {
            "condition": self.condition,
            "result": self.result,
            "condition_columns": [c.to_dict() for c in self.condition_columns],
            "result_columns": [c.to_dict() for c in self.result_columns]
        }


@dataclass
class CaseStatement:
    """Complete CASE statement with all branches."""
    expression_id: str
    sql_text: str
    branches: List[CaseBranch] = field(default_factory=list)
    else_result: Optional[str] = None
    else_columns: List[ColumnRef] = field(default_factory=list)
    output_alias: Optional[str] = None

    def get_all_source_columns(self) -> List[ColumnRef]:
        """Return all columns referenced in this CASE statement."""
        columns = []
        for branch in self.branches:
            columns.extend(branch.condition_columns)
            columns.extend(branch.result_columns)
        columns.extend(self.else_columns)
        return list(set(columns))

    def to_dict(self) -> dict:
        return {
            "expression_id": self.expression_id,
            "sql_text": self.sql_text,
            "branches": [b.to_dict() for b in self.branches],
            "else_result": self.else_result,
            "else_columns": [c.to_dict() for c in self.else_columns],
            "output_alias": self.output_alias,
            "all_source_columns": [c.to_dict() for c in self.get_all_source_columns()]
        }


@dataclass
class JoinCondition:
    """Single condition in a JOIN ON clause."""
    left_column: ColumnRef
    operator: str
    right_column: Optional[ColumnRef] = None
    right_literal: Optional[str] = None

    def to_dict(self) -> dict:
        return {
            "left_column": self.left_column.to_dict(),
            "operator": self.operator,
            "right_column": self.right_column.to_dict() if self.right_column else None,
            "right_literal": self.right_literal
        }


@dataclass
class JoinInfo:
    """Complete JOIN information."""
    join_type: str  # INNER, LEFT, RIGHT, FULL, CROSS
    left_table: str
    right_table: str
    left_alias: Optional[str] = None
    right_alias: Optional[str] = None
    conditions: List[JoinCondition] = field(default_factory=list)
    predicate_sql: Optional[str] = None

    def get_all_columns(self) -> List[ColumnRef]:
        """Return all columns involved in join conditions."""
        columns = []
        for cond in self.conditions:
            columns.append(cond.left_column)
            if cond.right_column:
                columns.append(cond.right_column)
        return columns

    def to_dict(self) -> dict:
        return {
            "join_type": self.join_type,
            "left_table": self.left_table,
            "right_table": self.right_table,
            "left_alias": self.left_alias,
            "right_alias": self.right_alias,
            "conditions": [c.to_dict() for c in self.conditions],
            "predicate_sql": self.predicate_sql
        }


@dataclass
class FunctionParameter:
    """Parameter to a function call."""
    position: int
    expression: str
    columns_referenced: List[ColumnRef] = field(default_factory=list)
    is_literal: bool = False
    literal_value: Optional[str] = None

    def to_dict(self) -> dict:
        return {
            "position": self.position,
            "expression": self.expression,
            "columns_referenced": [c.to_dict() for c in self.columns_referenced],
            "is_literal": self.is_literal,
            "literal_value": self.literal_value
        }


@dataclass
class FunctionCall:
    """Function call with parameters."""
    function_name: str
    sql_text: str
    parameters: List[FunctionParameter] = field(default_factory=list)
    nested_functions: List['FunctionCall'] = field(default_factory=list)
    return_type: Optional[str] = None
    is_aggregate: bool = False
    is_window: bool = False
    window_partition_by: List[ColumnRef] = field(default_factory=list)
    window_order_by: List[ColumnRef] = field(default_factory=list)

    def get_all_columns(self) -> List[ColumnRef]:
        """Return all columns referenced in this function call."""
        columns = []
        for param in self.parameters:
            columns.extend(param.columns_referenced)
        for nested in self.nested_functions:
            columns.extend(nested.get_all_columns())
        columns.extend(self.window_partition_by)
        columns.extend(self.window_order_by)
        return list(set(columns))

    def to_dict(self) -> dict:
        return {
            "function_name": self.function_name,
            "sql_text": self.sql_text,
            "parameters": [p.to_dict() for p in self.parameters],
            "nested_functions": [f.to_dict() for f in self.nested_functions],
            "return_type": self.return_type,
            "is_aggregate": self.is_aggregate,
            "is_window": self.is_window,
            "window_partition_by": [c.to_dict() for c in self.window_partition_by],
            "window_order_by": [c.to_dict() for c in self.window_order_by]
        }


@dataclass
class CTEDefinition:
    """Common Table Expression definition."""
    name: str
    definition_sql: str
    columns: List[str] = field(default_factory=list)
    is_recursive: bool = False
    dependencies: List[str] = field(default_factory=list)  # Other CTEs referenced
    source_tables: List[str] = field(default_factory=list)
    column_lineage: Dict[str, List[ColumnRef]] = field(default_factory=dict)
    is_volatile_table: bool = False  # True for Teradata volatile tables acting as CTEs

    def to_dict(self) -> dict:
        return {
            "name": self.name,
            "definition_sql": self.definition_sql,
            "columns": self.columns,
            "is_recursive": self.is_recursive,
            "dependencies": self.dependencies,
            "source_tables": self.source_tables,
            "column_lineage": {
                col: [c.to_dict() for c in refs]
                for col, refs in self.column_lineage.items()
            } if self.column_lineage else {}
        }


@dataclass
class Subquery:
    """Subquery with context."""
    alias: str
    query_sql: str
    context: str  # SELECT, WHERE, FROM, HAVING, EXISTS, IN
    is_correlated: bool = False
    correlation_columns: List[ColumnRef] = field(default_factory=list)
    output_columns: List[str] = field(default_factory=list)
    source_tables: List[str] = field(default_factory=list)

    def to_dict(self) -> dict:
        return {
            "alias": self.alias,
            "query_sql": self.query_sql,
            "context": self.context,
            "is_correlated": self.is_correlated,
            "correlation_columns": [c.to_dict() for c in self.correlation_columns],
            "output_columns": self.output_columns,
            "source_tables": self.source_tables
        }


@dataclass
class WhereCondition:
    """Single condition in a WHERE clause."""
    expression: str
    columns_referenced: List[ColumnRef] = field(default_factory=list)
    operator: Optional[str] = None
    has_subquery: bool = False

    def to_dict(self) -> dict:
        return {
            "expression": self.expression,
            "columns_referenced": [c.to_dict() for c in self.columns_referenced],
            "operator": self.operator,
            "has_subquery": self.has_subquery
        }


@dataclass
class WhereClause:
    """WHERE clause with all conditions."""
    sql_text: str
    conditions: List[WhereCondition] = field(default_factory=list)

    def get_all_columns(self) -> List[ColumnRef]:
        """Return all columns referenced in WHERE clause."""
        columns = []
        for cond in self.conditions:
            columns.extend(cond.columns_referenced)
        return list(set(columns))

    def to_dict(self) -> dict:
        return {
            "sql_text": self.sql_text,
            "conditions": [c.to_dict() for c in self.conditions],
            "all_columns": [c.to_dict() for c in self.get_all_columns()]
        }


@dataclass
class GroupByClause:
    """GROUP BY clause."""
    columns: List[ColumnRef] = field(default_factory=list)
    sql_text: Optional[str] = None

    def to_dict(self) -> dict:
        return {
            "columns": [c.to_dict() for c in self.columns],
            "sql_text": self.sql_text
        }


@dataclass
class OrderByClause:
    """ORDER BY clause."""
    columns: List[ColumnRef] = field(default_factory=list)
    directions: List[str] = field(default_factory=list)  # ASC/DESC
    sql_text: Optional[str] = None

    def to_dict(self) -> dict:
        return {
            "columns": [c.to_dict() for c in self.columns],
            "directions": self.directions,
            "sql_text": self.sql_text
        }


@dataclass
class TransformationInfo:
    """Transformation metadata for lineage edge."""
    type: TransformationType
    subtype: TransformationSubtype
    description: str
    sql_expression: str
    source_columns: List[ColumnRef] = field(default_factory=list)
    complexity_score: int = 1  # 1=simple, 5=complex

    def to_dict(self) -> dict:
        return {
            "type": self.type.value if hasattr(self.type, 'value') else self.type,
            "subtype": self.subtype.value if hasattr(self.subtype, 'value') else self.subtype,
            "description": self.description,
            "sql_expression": self.sql_expression,
            "source_columns": [c.to_dict() for c in self.source_columns],
            "complexity_score": self.complexity_score
        }


@dataclass
class LineageEdge:
    """Edge in lineage graph."""
    source: ColumnRef
    target: ColumnRef
    transformation: TransformationInfo
    statement_id: Optional[str] = None
    dml_operation: str = ""
    join_conditions: str = ""
    where_conditions: str = ""
    subquery_alias: str = ""   # e.g. "PCO_SINCE_SEED", "TMP", "RES"
    union_type: str = ""       # "UNION" or "UNION ALL" or ""

    def to_dict(self) -> dict:
        return {
            "source": self.source.to_dict(),
            "target": self.target.to_dict(),
            "transformation": self.transformation.to_dict(),
            "statement_id": self.statement_id,
            "dml_operation": self.dml_operation,
            "join_conditions": self.join_conditions,
            "where_conditions": self.where_conditions,
            "subquery_alias": self.subquery_alias,
            "union_type": self.union_type
        }

    def to_csv_row(self) -> dict:
        """Return row in BDaaS CSV format."""
        return {
            "Source_Table": self.source.table_name,
            "Source_Attribute": self.source.column_name,
            "Transformation_Logic": self.transformation.sql_expression,
            "Target_Table": self.target.table_name,
            "Target_Attribute": self.target.column_name,
            "DML_Operation": self.dml_operation,
            "Join_Conditions": self.join_conditions,
            "Filter_Conditions": self.where_conditions,
            "Subquery_Alias": self.subquery_alias,
            "Union_Type": self.union_type
        }


@dataclass
class ElementCatalog:
    """Complete catalog of all SQL elements in a statement."""
    statement_id: str
    statement_type: str  # SELECT, INSERT, UPDATE, DELETE, CREATE, etc.
    raw_sql: str
    case_statements: List[CaseStatement] = field(default_factory=list)
    functions: List[FunctionCall] = field(default_factory=list)
    joins: List[JoinInfo] = field(default_factory=list)
    where_clause: Optional[WhereClause] = None
    ctes: List[CTEDefinition] = field(default_factory=list)
    subqueries: List[Subquery] = field(default_factory=list)
    group_by: Optional[GroupByClause] = None
    order_by: Optional[OrderByClause] = None
    source_tables: List[str] = field(default_factory=list)
    target_table: Optional[str] = None

    def to_dict(self) -> dict:
        return {
            "statement_id": self.statement_id,
            "statement_type": self.statement_type,
            "raw_sql": self.raw_sql,
            "case_statements": [c.to_dict() for c in self.case_statements],
            "functions": [f.to_dict() for f in self.functions],
            "joins": [j.to_dict() for j in self.joins],
            "where_clause": self.where_clause.to_dict() if self.where_clause else None,
            "ctes": [c.to_dict() for c in self.ctes],
            "subqueries": [s.to_dict() for s in self.subqueries],
            "group_by": self.group_by.to_dict() if self.group_by else None,
            "order_by": self.order_by.to_dict() if self.order_by else None,
            "source_tables": self.source_tables,
            "target_table": self.target_table
        }

    def to_json(self, indent: int = 2) -> str:
        return json.dumps(self.to_dict(), indent=indent)


@dataclass
class ASTMetadata:
    """Metadata about the parsed AST."""
    source_file: Optional[str] = None
    dialect: str = "teradata"
    parse_timestamp: Optional[str] = None
    statement_count: int = 0
    has_errors: bool = False
    error_messages: List[str] = field(default_factory=list)
    notes: List[str] = field(default_factory=list)

    def to_dict(self) -> dict:
        return {
            "source_file": self.source_file,
            "dialect": self.dialect,
            "parse_timestamp": self.parse_timestamp,
            "statement_count": self.statement_count,
            "has_errors": self.has_errors,
            "error_messages": self.error_messages,
            "notes": self.notes
        }


@dataclass
class ParseResult:
    """Result of parsing a SQL statement or file."""
    success: bool
    metadata: ASTMetadata
    statements: List[Any] = field(default_factory=list)  # sqlglot.Expression objects
    element_catalogs: List[ElementCatalog] = field(default_factory=list)

    def to_dict(self) -> dict:
        return {
            "success": self.success,
            "metadata": self.metadata.to_dict(),
            "element_catalogs": [e.to_dict() for e in self.element_catalogs]
        }

    def to_json(self, indent: int = 2) -> str:
        return json.dumps(self.to_dict(), indent=indent)


# ============================================================================
# Structured Lineage Output Models
# ============================================================================
# These models support the enhanced output format that separates conditions
# from column mappings to avoid repetition.

@dataclass
class FilterConditionDetail:
    """Detailed filter/WHERE condition with English explanation."""
    filter_id: str
    filter_type: str  # WHERE, HAVING, QUALIFY
    sql_expression: str
    columns_referenced: List[ColumnRef] = field(default_factory=list)
    english_explanation: str = ""
    applies_to_table: Optional[str] = None
    dml_sequence: Optional[int] = None
    source_table: Optional[str] = None
    exists_tables: List[str] = field(default_factory=list)

    def to_dict(self) -> dict:
        return {
            "filter_id": self.filter_id,
            "filter_type": self.filter_type,
            "sql_expression": self.sql_expression,
            "columns_referenced": [c.to_dict() for c in self.columns_referenced],
            "english_explanation": self.english_explanation,
            "applies_to_table": self.applies_to_table,
            "dml_sequence": self.dml_sequence,
            "source_table": self.source_table,
            "exists_tables": self.exists_tables
        }


@dataclass
class JoinConditionDetail:
    """Detailed JOIN condition with English explanation."""
    join_id: str
    join_type: str  # INNER, LEFT, RIGHT, FULL, CROSS
    left_table: str
    right_table: str
    left_alias: Optional[str] = None
    right_alias: Optional[str] = None
    on_condition_sql: str = ""
    columns_left: List[ColumnRef] = field(default_factory=list)
    columns_right: List[ColumnRef] = field(default_factory=list)
    english_explanation: str = ""
    dml_sequence: Optional[int] = None

    def to_dict(self) -> dict:
        return {
            "join_id": self.join_id,
            "join_type": self.join_type,
            "left_table": self.left_table,
            "right_table": self.right_table,
            "left_alias": self.left_alias,
            "right_alias": self.right_alias,
            "on_condition_sql": self.on_condition_sql,
            "columns_left": [c.to_dict() for c in self.columns_left],
            "columns_right": [c.to_dict() for c in self.columns_right],
            "english_explanation": self.english_explanation,
            "dml_sequence": self.dml_sequence
        }


@dataclass
class TableAliasDetail:
    """Detailed table alias information with columns and transformations."""
    alias: str  # The alias (e.g., A, B, C)
    full_table_name: str  # Full table name the alias refers to
    english_explanation: str  # English description of what this table represents
    columns_used: List[str] = field(default_factory=list)  # Columns used from this table
    column_transformations: Dict[str, str] = field(default_factory=dict)  # column -> transformation applied
    join_context: str = ""  # How this table is joined (e.g., "INNER JOIN on X = Y")
    role_in_query: str = ""  # source, target, lookup, etc.

    def to_dict(self) -> dict:
        return {
            "alias": self.alias,
            "full_table_name": self.full_table_name,
            "english_explanation": self.english_explanation,
            "columns_used": self.columns_used,
            "column_transformations": self.column_transformations,
            "join_context": self.join_context,
            "role_in_query": self.role_in_query
        }


@dataclass
class LineageOutputMetadata:
    """Metadata for structured lineage output."""
    target_table: str = ""
    target_tables: List[str] = field(default_factory=list)
    target_schema: Optional[str] = None
    source_tables: List[str] = field(default_factory=list)
    statement_type: str = "INSERT"
    total_column_mappings: int = 0
    total_join_conditions: int = 0
    total_filter_conditions: int = 0
    source_file: Optional[str] = None
    generated_timestamp: Optional[str] = None
    dialect: str = "teradata"
    edge_count: int = 0
    table_count: int = 0
    column_count: int = 0

    def to_dict(self) -> dict:
        return {
            "target_tables": self.target_tables,
            "target_schema": self.target_schema,
            "source_tables": self.source_tables,
            "statement_type": self.statement_type,
            "total_column_mappings": self.total_column_mappings,
            "total_join_conditions": self.total_join_conditions,
            "total_filter_conditions": self.total_filter_conditions,
            "source_file": self.source_file,
            "generated_timestamp": self.generated_timestamp,
            "dialect": self.dialect,
            "edge_count": self.edge_count,
            "table_count": self.table_count,
            "column_count": self.column_count
        }


@dataclass
class ColumnMappingRecord:
    """Single column mapping record for structured output."""
    source_table: str
    source_column: str
    target_table: str
    target_column: str
    transformation_type: str
    transformation_subtype: str
    transformation_sql: str
    english_explanation: str = ""
    source_columns_involved: List[str] = field(default_factory=list)
    dml_sequence: Optional[int] = None
    operator_type: str = ""
    join_ids: List[str] = field(default_factory=list)
    filter_ids: List[str] = field(default_factory=list)
    source_alias: str = ""
    target_alias: str = ""
    subquery_alias: str = ""
    union_type: str = ""
    subquery_sql: str = ""
    group_by: str = ""
    # Subquery decomposition fields
    hops: Optional[int] = None
    hop_detail: str = ""
    source_subquery_relation: str = ""
    target_subquery_relation: str = ""
    notes: str = ""
    control_flow_context: str = ""
    is_subquery_decomposition: bool = False
    # Fields from lineage_output.json edges
    join_conditions_sql: str = ""
    where_conditions_sql: str = ""
    transformation_description: str = ""
    complexity_score: int = 0

    def to_dict(self) -> dict:
        return {
            "source_table": self.source_table,
            "source_column": self.source_column,
            "target_table": self.target_table,
            "target_column": self.target_column,
            "transformation_type": self.transformation_type,
            "transformation_subtype": self.transformation_subtype,
            "transformation_sql": self.transformation_sql,
            "transformation_description": self.transformation_description,
            "complexity_score": self.complexity_score,
            "english_explanation": self.english_explanation,
            "source_columns_involved": self.source_columns_involved,
            "dml_sequence": self.dml_sequence,
            "operator_type": self.operator_type,
            "join_ids": self.join_ids,
            "filter_ids": self.filter_ids,
            "join_conditions_sql": self.join_conditions_sql,
            "where_conditions_sql": self.where_conditions_sql,
            "source_alias": self.source_alias,
            "target_alias": self.target_alias,
            "subquery_alias": self.subquery_alias,
            "union_type": self.union_type,
            "subquery_sql": self.subquery_sql,
            "group_by": self.group_by,
            "hops": self.hops,
            "hop_detail": self.hop_detail,
            "source_subquery_relation": self.source_subquery_relation,
            "target_subquery_relation": self.target_subquery_relation,
            "notes": self.notes,
            "control_flow_context": self.control_flow_context,
            "is_subquery_decomposition": self.is_subquery_decomposition
        }


@dataclass
class SubqueryDetail:
    """Subquery detail for structured output."""
    subquery_id: str
    alias: str
    context: str  # FROM, WHERE, IN, EXISTS, SELECT
    source_tables: List[str] = field(default_factory=list)
    query_sql: str = ""
    dml_sequence: Optional[int] = None
    target_table: Optional[str] = None

    def to_dict(self) -> dict:
        return {
            "subquery_id": self.subquery_id,
            "alias": self.alias,
            "context": self.context,
            "source_tables": self.source_tables,
            "query_sql": self.query_sql,
            "dml_sequence": self.dml_sequence,
            "target_table": self.target_table
        }


@dataclass
class StructuredLineageOutput:
    """Complete structured lineage output with separated conditions."""
    metadata: LineageOutputMetadata
    column_mappings: List[ColumnMappingRecord] = field(default_factory=list)
    join_conditions: List[JoinConditionDetail] = field(default_factory=list)
    filter_conditions: List[FilterConditionDetail] = field(default_factory=list)
    table_aliases: List[TableAliasDetail] = field(default_factory=list)
    subqueries: List[SubqueryDetail] = field(default_factory=list)
    control_flow: List[Dict] = field(default_factory=list)

    def to_dict(self) -> dict:
        return {
            "metadata": self.metadata.to_dict(),
            "column_mappings": [m.to_dict() for m in self.column_mappings],
            "join_conditions": [j.to_dict() for j in self.join_conditions],
            "filter_conditions": [f.to_dict() for f in self.filter_conditions],
            "table_aliases": [a.to_dict() for a in self.table_aliases],
            "subqueries": [s.to_dict() for s in self.subqueries],
            "control_flow": self.control_flow
        }

    def to_json(self, indent: int = 2) -> str:
        return json.dumps(self.to_dict(), indent=indent)
