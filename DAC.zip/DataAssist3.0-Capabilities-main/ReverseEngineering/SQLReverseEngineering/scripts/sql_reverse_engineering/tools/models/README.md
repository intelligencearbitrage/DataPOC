# Models

## Overview
The Models module defines core data structures and models used throughout the SQL reverse engineering system for representing SQL elements, lineage, transformations, and metadata.

## Components

### `data_models.py`
Core data models for the entire system.

**Key Model Categories:**
1. SQL Elements (columns, tables, joins, etc.)
2. Lineage structures (edges, graphs, paths)
3. Transformations (types, classifications)
4. Metadata (parsing info, execution context)

## Data Models

### Enumerations

#### `TransformationType`
Top-level transformation classification.

```python
class TransformationType(Enum):
    DIRECT = "DIRECT"        # No transformation
    INDIRECT = "INDIRECT"     # With transformation
```

#### `TransformationSubtype`
Detailed transformation classification.

```python
class TransformationSubtype(Enum):
    # Direct subtypes
    IDENTITY = "IDENTITY"                     # Exact copy
    RENAME = "RENAME"                         # Simple rename
    CAST = "CAST"                            # Type conversion
    
    # Indirect subtypes
    TRANSFORMATION = "TRANSFORMATION"         # General
    AGGREGATION = "AGGREGATION"              # SUM, AVG, COUNT
    JOIN = "JOIN"                            # From join
    FILTER = "FILTER"                        # Filtered
    GROUP_BY = "GROUP_BY"                    # Grouped
    WINDOW = "WINDOW"                        # Window function
    CASE_LOGIC = "CASE_LOGIC"               # CASE expression
    COALESCE = "COALESCE"                   # NULL handling
    STRING_MANIPULATION = "STRING_MANIPULATION"  # String ops
    DATE_MANIPULATION = "DATE_MANIPULATION"      # Date ops
    MATHEMATICAL = "MATHEMATICAL"                # Math ops
    UNKNOWN = "UNKNOWN"                          # Unknown
```

### SQL Element Models

#### `ColumnRef`
Reference to a column.

**Fields:**
- `table_name` - Table name
- `column_name` - Column name
- `schema_name` - Optional schema
- `alias` - Optional alias

**Methods:**
- `qualified_name()` - Get fully qualified name

**Example:**
```python
col = ColumnRef(
    table_name="customers",
    column_name="name",
    schema_name="sales",
    alias="customer_name"
)
print(col.qualified_name())  # "sales.customers.name"
```

#### `TableRef`
Reference to a table.

**Fields:**
- `table_name` - Table name
- `schema_name` - Schema name
- `database_name` - Database name
- `alias` - Table alias

#### `SelectColumn`
A column in SELECT list.

**Fields:**
- `expression` - Column expression
- `alias` - Column alias
- `source_columns` - Source columns used
- `functions` - Functions applied

#### `WhereClause`
WHERE clause representation.

**Fields:**
- `conditions` - List of conditions
- `raw_sql` - Raw WHERE SQL

#### `WhereCondition`
Individual condition in WHERE.

**Fields:**
- `expression` - Condition expression
- `operator` - Comparison operator
- `left` - Left operand
- `right` - Right operand

#### `JoinClause`
JOIN operation.

**Fields:**
- `join_type` - INNER, LEFT, RIGHT, FULL, CROSS
- `left_table` - Left table
- `right_table` - Right table
- `on_condition` - Join condition
- `columns_used` - Columns in condition

#### `CaseExpression`
CASE WHEN expression.

**Fields:**
- `branches` - List of WHEN branches
- `else_value` - ELSE value
- `result_column` - Result column

#### `FunctionCall`
Function call.

**Fields:**
- `function_name` - Function name
- `arguments` - Function arguments
- `is_aggregate` - Whether aggregate function
- `is_window` - Whether window function

#### `CTE`
Common Table Expression.

**Fields:**
- `name` - CTE name
- `columns` - CTE columns
- `query` - CTE query SQL
- `is_recursive` - Whether recursive

#### `Subquery`
Subquery expression.

**Fields:**
- `query` - Subquery SQL
- `alias` - Subquery alias
- `location` - Where used (SELECT, FROM, WHERE)
- `is_correlated` - Whether correlated

### Lineage Models

#### `TransformationInfo`
Detailed transformation information.

**Fields:**
- `type` - TransformationType
- `subtype` - TransformationSubtype
- `expression` - Transformation expression
- `functions_used` - List of functions
- `complexity_score` - Complexity rating
- `is_reversible` - Can it be reversed?

**Example:**
```python
transform = TransformationInfo(
    type=TransformationType.INDIRECT,
    subtype=TransformationSubtype.STRING_MANIPULATION,
    expression="UPPER(TRIM(name))",
    functions_used=["UPPER", "TRIM"],
    complexity_score=2.0,
    is_reversible=False
)
```

#### `LineageEdge`
Edge in lineage graph (source → target).

**Fields:**
- `source` - Source ColumnRef
- `target` - Target ColumnRef
- `transformation` - Transformation expression
- `transformation_info` - TransformationInfo object
- `confidence` - Confidence score

**Example:**
```python
edge = LineageEdge(
    source=ColumnRef("customers", "name"),
    target=ColumnRef("dim_customer", "customer_name"),
    transformation="UPPER(name)",
    transformation_info=transform_info,
    confidence=0.95
)
```

#### `LineagePath`
Complete path from source to target.

**Fields:**
- `source` - Starting column
- `target` - Ending column
- `edges` - List of edges in path
- `total_hops` - Number of hops
- `cumulative_transformation` - Combined transformation

### Metadata Models

#### `ASTMetadata`
Metadata about parsed AST.

**Fields:**
- `dialect` - SQL dialect
- `parse_timestamp` - When parsed
- `parser_version` - Parser version
- `file_name` - Source file name
- `has_errors` - Whether errors occurred

#### `ParseResult`
Result of parsing SQL.

**Fields:**
- `ast` - Parsed AST
- `metadata` - ASTMetadata
- `errors` - Parse errors
- `warnings` - Parse warnings

#### `ElementCatalog`
Complete catalog of SQL elements.

**Fields:**
- `columns` - All SELECT columns
- `tables` - All tables referenced
- `joins` - All JOIN operations
- `where_clauses` - All WHERE conditions
- `group_by` - GROUP BY columns
- `order_by` - ORDER BY columns
- `functions` - All functions
- `case_expressions` - All CASE expressions
- `ctes` - All CTEs
- `subqueries` - All subqueries

**Methods:**
- `to_dict()` - Convert to dictionary
- `to_json()` - Serialize to JSON

#### `StructuredLineageOutput`
Complete lineage output structure.

**Fields:**
- `metadata` - Lineage metadata
- `source_tables` - Source tables
- `target_tables` - Target tables
- `lineage` - List of LineageEdge
- `transformations` - Transformation summary
- `statistics` - Lineage statistics

## Usage Example

```python
from models.data_models import (
    ColumnRef, LineageEdge, TransformationType,
    TransformationInfo, ElementCatalog
)

# Create column reference
source_col = ColumnRef(
    table_name="customers",
    column_name="first_name"
)

target_col = ColumnRef(
    table_name="dim_customer",
    column_name="customer_first_name"
)

# Create transformation info
transform = TransformationInfo(
    type=TransformationType.INDIRECT,
    subtype=TransformationSubtype.STRING_MANIPULATION,
    expression="UPPER(first_name)",
    functions_used=["UPPER"]
)

# Create lineage edge
edge = LineageEdge(
    source=source_col,
    target=target_col,
    transformation="UPPER(first_name)",
    transformation_info=transform
)

# Create element catalog
catalog = ElementCatalog(
    columns=[...],
    tables=[...],
    joins=[...]
)

# Serialize to JSON
json_output = catalog.to_json()
```

## Design Principles

1. **Immutability**: Models are designed to be immutable where possible
2. **Type Safety**: Strong typing with Python dataclasses
3. **Serialization**: All models can be serialized to JSON/dict
4. **Validation**: Input validation in constructors
5. **Consistency**: Consistent naming and structure across models

## Integration Points
- Used by: All modules in the system
- Provides: Core data structures
- Ensures: Type safety and consistency
- Enables: Easy serialization and deserialization
