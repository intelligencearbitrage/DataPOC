"""Data models for SQL reverse engineering system."""

from .data_models import (
    ColumnRef,
    CaseBranch,
    CaseStatement,
    JoinInfo,
    JoinCondition,
    FunctionParameter,
    FunctionCall,
    CTEDefinition,
    Subquery,
    WhereClause,
    WhereCondition,
    GroupByClause,
    OrderByClause,
    TransformationType,
    TransformationSubtype,
    TransformationInfo,
    LineageEdge,
    ElementCatalog,
    ASTMetadata,
    ParseResult,
    # Structured lineage output models
    FilterConditionDetail,
    JoinConditionDetail,
    LineageOutputMetadata,
    ColumnMappingRecord,
    StructuredLineageOutput
)

__all__ = [
    "ColumnRef",
    "CaseBranch",
    "CaseStatement",
    "JoinInfo",
    "JoinCondition",
    "FunctionParameter",
    "FunctionCall",
    "CTEDefinition",
    "Subquery",
    "WhereClause",
    "WhereCondition",
    "GroupByClause",
    "OrderByClause",
    "TransformationType",
    "TransformationSubtype",
    "TransformationInfo",
    "LineageEdge",
    "ElementCatalog",
    "ASTMetadata",
    "ParseResult",
    # Structured lineage output models
    "FilterConditionDetail",
    "JoinConditionDetail",
    "LineageOutputMetadata",
    "ColumnMappingRecord",
    "StructuredLineageOutput"
]
