"""
HTML Help Generator module.

Generates comprehensive standalone HTML documentation similar to .CHM help files.
Includes all lineage information, diagrams, and search functionality.
"""

import json
import os
from typing import List, Dict, Optional, Any
from datetime import datetime
import html as html_escape
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from models.data_models import (
    ElementCatalog,
    StructuredLineageOutput,
    LineageOutputMetadata
)
from lineage.lineage_graph import LineageGraph


class HTMLHelpGenerator:
    """
    Generate standalone HTML help documentation.

    Produces a single HTML file with:
    - Embedded CSS and JavaScript
    - Table of contents with navigation
    - Search functionality
    - Collapsible sections
    - Lineage diagrams (Mermaid)
    - All transformation details
    """

    def __init__(self):
        """Initialize the help generator."""
        self.sections = []

    def generate_help(
        self,
        output_path: str,
        lineage_graph: LineageGraph = None,
        element_catalog: ElementCatalog = None,
        structured_output: StructuredLineageOutput = None,
        source_file: str = None,
        title: str = "SQL Lineage Documentation"
    ) -> None:
        """
        Generate comprehensive HTML help file.

        Args:
            output_path: Path to output HTML file
            lineage_graph: Lineage graph with column mappings
            element_catalog: Element catalog with SQL details
            structured_output: Structured lineage output
            source_file: Source SQL file name
            title: Title for the documentation
        """
        html_content = self._build_html(
            lineage_graph,
            element_catalog,
            structured_output,
            source_file,
            title
        )

        with open(output_path, 'w', encoding='utf-8') as f:
            f.write(html_content)

    def _build_html(
        self,
        lineage_graph: LineageGraph,
        element_catalog: ElementCatalog,
        structured_output: StructuredLineageOutput,
        source_file: str,
        title: str
    ) -> str:
        """Build the complete HTML document."""

        # Build sections
        toc_items = []
        content_sections = []

        # Overview section
        overview = self._build_overview_section(
            lineage_graph, element_catalog, structured_output, source_file
        )
        toc_items.append(('overview', 'Overview'))
        content_sections.append(overview)

        # Column Lineage section
        if lineage_graph and lineage_graph.edges:
            lineage_section = self._build_lineage_section(lineage_graph)
            toc_items.append(('column-lineage', 'Column Lineage'))
            content_sections.append(lineage_section)

        # Join Conditions section
        if structured_output and structured_output.join_conditions:
            joins_section = self._build_joins_section(structured_output)
            toc_items.append(('join-conditions', 'Join Conditions'))
            content_sections.append(joins_section)

        # Filter Conditions section
        if structured_output and structured_output.filter_conditions:
            filters_section = self._build_filters_section(structured_output)
            toc_items.append(('filter-conditions', 'Filter Conditions'))
            content_sections.append(filters_section)

        # CASE Statements section
        if element_catalog and element_catalog.case_statements:
            case_section = self._build_case_section(element_catalog)
            toc_items.append(('case-statements', 'CASE Statements'))
            content_sections.append(case_section)

        # Functions section
        if element_catalog and element_catalog.functions:
            func_section = self._build_functions_section(element_catalog)
            toc_items.append(('functions', 'Functions'))
            content_sections.append(func_section)

        # CTEs section
        if element_catalog and element_catalog.ctes:
            cte_section = self._build_cte_section(element_catalog)
            toc_items.append(('ctes', 'Common Table Expressions'))
            content_sections.append(cte_section)

        # Lineage Diagram section
        if lineage_graph:
            diagram_section = self._build_diagram_section(lineage_graph)
            toc_items.append(('lineage-diagram', 'Lineage Diagram'))
            content_sections.append(diagram_section)

        # Source SQL section
        if element_catalog and element_catalog.raw_sql:
            sql_section = self._build_sql_section(element_catalog)
            toc_items.append(('source-sql', 'Source SQL'))
            content_sections.append(sql_section)

        # Build TOC
        toc_html = self._build_toc(toc_items)

        # Combine all content
        content_html = '\n'.join(content_sections)

        return self._wrap_in_template(title, toc_html, content_html, source_file)

    def _build_overview_section(
        self,
        lineage_graph: LineageGraph,
        element_catalog: ElementCatalog,
        structured_output: StructuredLineageOutput,
        source_file: str
    ) -> str:
        """Build the overview section."""
        stats = {}

        if lineage_graph:
            graph_stats = lineage_graph.get_statistics()
            stats['columns_traced'] = graph_stats.get('node_count', 0)
            stats['transformations'] = graph_stats.get('edge_count', 0)
            stats['source_tables'] = graph_stats.get('source_tables', [])
            stats['target_tables'] = graph_stats.get('target_tables', [])

        if element_catalog:
            stats['statement_type'] = element_catalog.statement_type
            stats['case_count'] = len(element_catalog.case_statements)
            stats['function_count'] = len(element_catalog.functions)
            stats['join_count'] = len(element_catalog.joins)
            stats['cte_count'] = len(element_catalog.ctes)

        if structured_output:
            meta = structured_output.metadata
            stats['target_table'] = meta.target_table

        return f'''
        <section id="overview" class="content-section">
            <h2>Overview</h2>

            <div class="info-card">
                <h3>Document Information</h3>
                <table class="info-table">
                    <tr><td>Source File</td><td>{html_escape.escape(source_file or 'N/A')}</td></tr>
                    <tr><td>Generated</td><td>{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}</td></tr>
                    <tr><td>Statement Type</td><td>{stats.get('statement_type', 'N/A')}</td></tr>
                    <tr><td>Target Table</td><td>{stats.get('target_table', 'N/A')}</td></tr>
                </table>
            </div>

            <div class="info-card">
                <h3>Statistics</h3>
                <div class="stats-grid">
                    <div class="stat-box">
                        <span class="stat-number">{stats.get('columns_traced', 0)}</span>
                        <span class="stat-label">Columns Traced</span>
                    </div>
                    <div class="stat-box">
                        <span class="stat-number">{stats.get('transformations', 0)}</span>
                        <span class="stat-label">Transformations</span>
                    </div>
                    <div class="stat-box">
                        <span class="stat-number">{stats.get('join_count', 0)}</span>
                        <span class="stat-label">Joins</span>
                    </div>
                    <div class="stat-box">
                        <span class="stat-number">{stats.get('case_count', 0)}</span>
                        <span class="stat-label">CASE Statements</span>
                    </div>
                    <div class="stat-box">
                        <span class="stat-number">{stats.get('function_count', 0)}</span>
                        <span class="stat-label">Functions</span>
                    </div>
                    <div class="stat-box">
                        <span class="stat-number">{stats.get('cte_count', 0)}</span>
                        <span class="stat-label">CTEs</span>
                    </div>
                </div>
            </div>

            <div class="info-card">
                <h3>Source Tables</h3>
                <ul class="table-list">
                    {''.join(f'<li>{html_escape.escape(t)}</li>' for t in stats.get('source_tables', []))}
                </ul>
            </div>

            <div class="info-card">
                <h3>Target Tables</h3>
                <ul class="table-list">
                    {''.join(f'<li>{html_escape.escape(t)}</li>' for t in stats.get('target_tables', []))}
                </ul>
            </div>
        </section>
        '''

    def _build_lineage_section(self, lineage_graph: LineageGraph) -> str:
        """Build the column lineage section."""
        rows = []
        for edge in lineage_graph.edges:
            row = f'''
            <tr>
                <td>{html_escape.escape(edge.source.table_name)}</td>
                <td>{html_escape.escape(edge.source.column_name)}</td>
                <td>{html_escape.escape(edge.target.table_name)}</td>
                <td>{html_escape.escape(edge.target.column_name)}</td>
                <td><span class="badge badge-{(edge.transformation.type.value if hasattr(edge.transformation.type, 'value') else edge.transformation.type).lower()}">{edge.transformation.type.value if hasattr(edge.transformation.type, 'value') else edge.transformation.type}</span></td>
                <td><span class="badge badge-subtype">{edge.transformation.subtype.value if hasattr(edge.transformation.subtype, 'value') else edge.transformation.subtype}</span></td>
                <td><code class="sql-snippet">{html_escape.escape(edge.transformation.sql_expression[:100])}{'...' if len(edge.transformation.sql_expression) > 100 else ''}</code></td>
            </tr>
            '''
            rows.append(row)

        return f'''
        <section id="column-lineage" class="content-section">
            <h2>Column Lineage</h2>
            <p>Complete source-to-target column mappings with transformation details.</p>

            <div class="table-container">
                <table class="data-table searchable" id="lineage-table">
                    <thead>
                        <tr>
                            <th>Source Table</th>
                            <th>Source Column</th>
                            <th>Target Table</th>
                            <th>Target Column</th>
                            <th>Type</th>
                            <th>Subtype</th>
                            <th>Transformation SQL</th>
                        </tr>
                    </thead>
                    <tbody>
                        {''.join(rows)}
                    </tbody>
                </table>
            </div>
        </section>
        '''

    def _build_joins_section(self, structured_output: StructuredLineageOutput) -> str:
        """Build the join conditions section."""
        cards = []
        for join in structured_output.join_conditions:
            card = f'''
            <div class="condition-card">
                <div class="condition-header">
                    <span class="condition-id">{html_escape.escape(join.join_id)}</span>
                    <span class="badge badge-join">{html_escape.escape(join.join_type)} JOIN</span>
                </div>
                <div class="condition-body">
                    <div class="condition-tables">
                        <span class="table-badge left">{html_escape.escape(join.left_table)}</span>
                        <span class="join-arrow">&#8594;</span>
                        <span class="table-badge right">{html_escape.escape(join.right_table)}</span>
                    </div>
                    <div class="condition-sql">
                        <strong>ON Condition:</strong>
                        <code>{html_escape.escape(join.on_condition_sql)}</code>
                    </div>
                    <div class="condition-explanation">
                        <strong>English Explanation:</strong>
                        <p>{html_escape.escape(join.english_explanation)}</p>
                    </div>
                </div>
            </div>
            '''
            cards.append(card)

        return f'''
        <section id="join-conditions" class="content-section">
            <h2>Join Conditions</h2>
            <p>All JOIN operations with their conditions and English explanations.</p>

            <div class="conditions-grid">
                {''.join(cards)}
            </div>
        </section>
        '''

    def _build_filters_section(self, structured_output: StructuredLineageOutput) -> str:
        """Build the filter conditions section."""
        cards = []
        for filter_cond in structured_output.filter_conditions:
            columns_html = ', '.join([
                f"{c.table_name}.{c.column_name}"
                for c in filter_cond.columns_referenced
            ])

            card = f'''
            <div class="condition-card filter-card">
                <div class="condition-header">
                    <span class="condition-id">{html_escape.escape(filter_cond.filter_id)}</span>
                    <span class="badge badge-filter">{html_escape.escape(filter_cond.filter_type)}</span>
                </div>
                <div class="condition-body">
                    <div class="condition-sql">
                        <strong>SQL Expression:</strong>
                        <code>{html_escape.escape(filter_cond.sql_expression)}</code>
                    </div>
                    <div class="columns-referenced">
                        <strong>Columns Referenced:</strong>
                        <span>{html_escape.escape(columns_html) if columns_html else 'None'}</span>
                    </div>
                    <div class="condition-explanation">
                        <strong>English Explanation:</strong>
                        <p>{html_escape.escape(filter_cond.english_explanation)}</p>
                    </div>
                </div>
            </div>
            '''
            cards.append(card)

        return f'''
        <section id="filter-conditions" class="content-section">
            <h2>Filter Conditions</h2>
            <p>WHERE, HAVING, and other filter conditions with English explanations.</p>

            <div class="conditions-grid">
                {''.join(cards)}
            </div>
        </section>
        '''

    def _build_case_section(self, element_catalog: ElementCatalog) -> str:
        """Build the CASE statements section."""
        cards = []
        for i, case in enumerate(element_catalog.case_statements, 1):
            branches_html = ''
            for j, branch in enumerate(case.branches, 1):
                branches_html += f'''
                <div class="case-branch">
                    <span class="branch-num">Branch {j}</span>
                    <div class="branch-condition">
                        <strong>WHEN:</strong> <code>{html_escape.escape(branch.condition)}</code>
                    </div>
                    <div class="branch-result">
                        <strong>THEN:</strong> <code>{html_escape.escape(branch.result)}</code>
                    </div>
                </div>
                '''

            if case.else_result:
                branches_html += f'''
                <div class="case-branch else-branch">
                    <span class="branch-num">ELSE</span>
                    <div class="branch-result">
                        <code>{html_escape.escape(case.else_result)}</code>
                    </div>
                </div>
                '''

            card = f'''
            <div class="case-card collapsible">
                <div class="case-header" onclick="toggleCollapsible(this)">
                    <span class="case-id">CASE {i}</span>
                    {f'<span class="output-alias">Output: {html_escape.escape(case.output_alias)}</span>' if case.output_alias else ''}
                    <span class="collapse-icon">&#9660;</span>
                </div>
                <div class="case-body collapsible-content">
                    <div class="case-sql">
                        <pre><code>{html_escape.escape(case.sql_text)}</code></pre>
                    </div>
                    <div class="case-branches">
                        <h4>Branches</h4>
                        {branches_html}
                    </div>
                </div>
            </div>
            '''
            cards.append(card)

        return f'''
        <section id="case-statements" class="content-section">
            <h2>CASE Statements</h2>
            <p>All CASE expressions with their branches and conditions.</p>

            <div class="case-list">
                {''.join(cards)}
            </div>
        </section>
        '''

    def _build_functions_section(self, element_catalog: ElementCatalog) -> str:
        """Build the functions section."""
        rows = []
        for func in element_catalog.functions:
            badges = []
            if func.is_aggregate:
                badges.append('<span class="badge badge-aggregate">Aggregate</span>')
            if func.is_window:
                badges.append('<span class="badge badge-window">Window</span>')

            row = f'''
            <tr>
                <td><strong>{html_escape.escape(func.function_name)}</strong></td>
                <td>{' '.join(badges) if badges else '<span class="badge badge-scalar">Scalar</span>'}</td>
                <td><code class="sql-snippet">{html_escape.escape(func.sql_text[:80])}{'...' if len(func.sql_text) > 80 else ''}</code></td>
            </tr>
            '''
            rows.append(row)

        return f'''
        <section id="functions" class="content-section">
            <h2>Functions</h2>
            <p>All function calls used in the SQL statement.</p>

            <div class="table-container">
                <table class="data-table" id="functions-table">
                    <thead>
                        <tr>
                            <th>Function Name</th>
                            <th>Type</th>
                            <th>SQL</th>
                        </tr>
                    </thead>
                    <tbody>
                        {''.join(rows)}
                    </tbody>
                </table>
            </div>
        </section>
        '''

    def _build_cte_section(self, element_catalog: ElementCatalog) -> str:
        """Build the CTEs section."""
        cards = []
        for cte in element_catalog.ctes:
            deps_html = ', '.join(cte.dependencies) if cte.dependencies else 'None'
            cols_html = ', '.join(cte.columns) if cte.columns else 'Inferred'

            card = f'''
            <div class="cte-card collapsible">
                <div class="cte-header" onclick="toggleCollapsible(this)">
                    <span class="cte-name">{html_escape.escape(cte.name)}</span>
                    {'<span class="badge badge-recursive">Recursive</span>' if cte.is_recursive else ''}
                    <span class="collapse-icon">&#9660;</span>
                </div>
                <div class="cte-body collapsible-content">
                    <div class="cte-info">
                        <p><strong>Columns:</strong> {html_escape.escape(cols_html)}</p>
                        <p><strong>Dependencies:</strong> {html_escape.escape(deps_html)}</p>
                    </div>
                    <div class="cte-sql">
                        <h4>Definition</h4>
                        <pre><code>{html_escape.escape(cte.definition_sql)}</code></pre>
                    </div>
                </div>
            </div>
            '''
            cards.append(card)

        return f'''
        <section id="ctes" class="content-section">
            <h2>Common Table Expressions (CTEs)</h2>
            <p>All CTE definitions with their dependencies and SQL.</p>

            <div class="cte-list">
                {''.join(cards)}
            </div>
        </section>
        '''

    def _build_diagram_section(self, lineage_graph: LineageGraph) -> str:
        """Build the lineage diagram section using Mermaid."""
        mermaid_code = lineage_graph.to_mermaid()

        return f'''
        <section id="lineage-diagram" class="content-section">
            <h2>Lineage Diagram</h2>
            <p>Visual representation of the data flow from source to target.</p>

            <div class="diagram-container">
                <div class="mermaid">
{mermaid_code}
                </div>
            </div>

            <div class="diagram-legend">
                <h4>Legend</h4>
                <div class="legend-items">
                    <span class="legend-item"><span class="legend-color source"></span> Source Column</span>
                    <span class="legend-item"><span class="legend-color target"></span> Target Column</span>
                    <span class="legend-item"><span class="legend-color intermediate"></span> Intermediate</span>
                </div>
            </div>
        </section>
        '''

    def _build_sql_section(self, element_catalog: ElementCatalog) -> str:
        """Build the source SQL section."""
        return f'''
        <section id="source-sql" class="content-section">
            <h2>Source SQL</h2>
            <p>Original SQL statement being analyzed.</p>

            <div class="sql-container">
                <pre><code class="language-sql">{html_escape.escape(element_catalog.raw_sql)}</code></pre>
            </div>
        </section>
        '''

    def _build_toc(self, toc_items: List[tuple]) -> str:
        """Build the table of contents."""
        items = []
        for id, label in toc_items:
            items.append(f'<a href="#{id}" class="toc-item">{label}</a>')

        return f'''
        <nav class="toc">
            <h3>Contents</h3>
            {''.join(items)}
        </nav>
        '''

    def _wrap_in_template(
        self,
        title: str,
        toc_html: str,
        content_html: str,
        source_file: str
    ) -> str:
        """Wrap content in the HTML template with embedded CSS and JS."""
        return f'''<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{html_escape.escape(title)}</title>
    <style>
{self._get_css()}
    </style>
    <script src="https://cdn.jsdelivr.net/npm/mermaid/dist/mermaid.min.js"></script>
</head>
<body>
    <header class="main-header">
        <h1>{html_escape.escape(title)}</h1>
        <div class="header-meta">
            <span>Source: {html_escape.escape(source_file or 'N/A')}</span>
            <span>Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}</span>
        </div>
    </header>

    <div class="search-bar">
        <input type="text" id="search-input" placeholder="Search documentation..." onkeyup="searchContent()">
    </div>

    <div class="main-container">
        <aside class="sidebar">
            {toc_html}
        </aside>

        <main class="content">
            {content_html}
        </main>
    </div>

    <footer class="main-footer">
        <p>Generated by SQL Reverse Engineering System</p>
    </footer>

    <script>
{self._get_javascript()}
    </script>
</body>
</html>'''

    def _get_css(self) -> str:
        """Return embedded CSS styles."""
        return '''
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, sans-serif;
            line-height: 1.6;
            color: #333;
            background: #f5f7fa;
        }

        .main-header {
            background: linear-gradient(135deg, #1e3c72 0%, #2a5298 100%);
            color: white;
            padding: 2rem;
            text-align: center;
        }

        .main-header h1 {
            font-size: 1.8rem;
            margin-bottom: 0.5rem;
        }

        .header-meta {
            font-size: 0.9rem;
            opacity: 0.9;
        }

        .header-meta span {
            margin: 0 1rem;
        }

        .search-bar {
            background: white;
            padding: 1rem;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            position: sticky;
            top: 0;
            z-index: 100;
        }

        .search-bar input {
            width: 100%;
            max-width: 500px;
            padding: 0.75rem 1rem;
            font-size: 1rem;
            border: 2px solid #e0e0e0;
            border-radius: 8px;
            outline: none;
            transition: border-color 0.2s;
        }

        .search-bar input:focus {
            border-color: #2a5298;
        }

        .main-container {
            display: flex;
            max-width: 1400px;
            margin: 0 auto;
            padding: 2rem;
            gap: 2rem;
        }

        .sidebar {
            width: 250px;
            flex-shrink: 0;
            position: sticky;
            top: 80px;
            height: fit-content;
        }

        .toc {
            background: white;
            border-radius: 8px;
            padding: 1.5rem;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
        }

        .toc h3 {
            font-size: 1rem;
            color: #666;
            margin-bottom: 1rem;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        .toc-item {
            display: block;
            padding: 0.5rem 0;
            color: #333;
            text-decoration: none;
            border-bottom: 1px solid #eee;
            transition: color 0.2s;
        }

        .toc-item:hover {
            color: #2a5298;
        }

        .toc-item:last-child {
            border-bottom: none;
        }

        .content {
            flex: 1;
            min-width: 0;
        }

        .content-section {
            background: white;
            border-radius: 8px;
            padding: 2rem;
            margin-bottom: 2rem;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
        }

        .content-section h2 {
            color: #1e3c72;
            margin-bottom: 1rem;
            padding-bottom: 0.5rem;
            border-bottom: 2px solid #e0e0e0;
        }

        .content-section p {
            color: #666;
            margin-bottom: 1.5rem;
        }

        .info-card {
            background: #f8f9fa;
            border-radius: 6px;
            padding: 1.5rem;
            margin-bottom: 1.5rem;
        }

        .info-card h3 {
            font-size: 1rem;
            color: #2a5298;
            margin-bottom: 1rem;
        }

        .info-table {
            width: 100%;
        }

        .info-table td {
            padding: 0.5rem 0;
            border-bottom: 1px solid #e0e0e0;
        }

        .info-table td:first-child {
            font-weight: 600;
            width: 40%;
            color: #555;
        }

        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(120px, 1fr));
            gap: 1rem;
        }

        .stat-box {
            background: white;
            border-radius: 6px;
            padding: 1rem;
            text-align: center;
            box-shadow: 0 1px 3px rgba(0,0,0,0.1);
        }

        .stat-number {
            display: block;
            font-size: 2rem;
            font-weight: 700;
            color: #2a5298;
        }

        .stat-label {
            font-size: 0.85rem;
            color: #666;
        }

        .table-list {
            list-style: none;
            padding: 0;
        }

        .table-list li {
            padding: 0.25rem 0;
            color: #555;
        }

        .table-container {
            overflow-x: auto;
        }

        .data-table {
            width: 100%;
            border-collapse: collapse;
            font-size: 0.9rem;
        }

        .data-table th,
        .data-table td {
            padding: 0.75rem;
            text-align: left;
            border-bottom: 1px solid #e0e0e0;
        }

        .data-table th {
            background: #f8f9fa;
            font-weight: 600;
            color: #333;
            position: sticky;
            top: 0;
        }

        .data-table tbody tr:hover {
            background: #f8f9fa;
        }

        .badge {
            display: inline-block;
            padding: 0.25rem 0.5rem;
            font-size: 0.75rem;
            font-weight: 600;
            border-radius: 4px;
            text-transform: uppercase;
        }

        .badge-direct { background: #d4edda; color: #155724; }
        .badge-indirect { background: #fff3cd; color: #856404; }
        .badge-subtype { background: #e2e3e5; color: #383d41; }
        .badge-join { background: #cce5ff; color: #004085; }
        .badge-filter { background: #f8d7da; color: #721c24; }
        .badge-aggregate { background: #d4edda; color: #155724; }
        .badge-window { background: #d1ecf1; color: #0c5460; }
        .badge-scalar { background: #e2e3e5; color: #383d41; }
        .badge-recursive { background: #fff3cd; color: #856404; }

        .sql-snippet {
            background: #f4f4f4;
            padding: 0.2rem 0.4rem;
            border-radius: 4px;
            font-family: 'Fira Code', Consolas, monospace;
            font-size: 0.85rem;
            word-break: break-all;
        }

        .conditions-grid {
            display: grid;
            gap: 1.5rem;
        }

        .condition-card {
            background: #f8f9fa;
            border-radius: 8px;
            border-left: 4px solid #2a5298;
            overflow: hidden;
        }

        .filter-card {
            border-left-color: #dc3545;
        }

        .condition-header {
            background: white;
            padding: 1rem 1.5rem;
            display: flex;
            align-items: center;
            gap: 1rem;
            border-bottom: 1px solid #e0e0e0;
        }

        .condition-id {
            font-weight: 600;
            color: #333;
        }

        .condition-body {
            padding: 1.5rem;
        }

        .condition-tables {
            display: flex;
            align-items: center;
            gap: 1rem;
            margin-bottom: 1rem;
        }

        .table-badge {
            background: #e9ecef;
            padding: 0.5rem 1rem;
            border-radius: 4px;
            font-weight: 500;
        }

        .table-badge.left { border-left: 3px solid #28a745; }
        .table-badge.right { border-left: 3px solid #007bff; }

        .join-arrow {
            font-size: 1.5rem;
            color: #666;
        }

        .condition-sql {
            margin-bottom: 1rem;
        }

        .condition-sql code {
            display: block;
            background: white;
            padding: 1rem;
            border-radius: 4px;
            margin-top: 0.5rem;
            font-family: 'Fira Code', Consolas, monospace;
            font-size: 0.9rem;
            overflow-x: auto;
        }

        .condition-explanation {
            background: white;
            padding: 1rem;
            border-radius: 4px;
            border-left: 3px solid #17a2b8;
        }

        .condition-explanation p {
            margin: 0.5rem 0 0 0;
            color: #333;
            font-style: italic;
        }

        .collapsible .collapsible-content {
            display: none;
        }

        .collapsible.open .collapsible-content {
            display: block;
        }

        .case-card, .cte-card {
            background: #f8f9fa;
            border-radius: 8px;
            margin-bottom: 1rem;
            overflow: hidden;
        }

        .case-header, .cte-header {
            background: white;
            padding: 1rem 1.5rem;
            display: flex;
            align-items: center;
            gap: 1rem;
            cursor: pointer;
            border-bottom: 1px solid #e0e0e0;
        }

        .case-header:hover, .cte-header:hover {
            background: #f8f9fa;
        }

        .case-id, .cte-name {
            font-weight: 600;
            color: #2a5298;
        }

        .output-alias {
            color: #666;
            font-size: 0.9rem;
        }

        .collapse-icon {
            margin-left: auto;
            transition: transform 0.2s;
        }

        .collapsible.open .collapse-icon {
            transform: rotate(180deg);
        }

        .case-body, .cte-body {
            padding: 1.5rem;
        }

        .case-sql pre, .cte-sql pre, .sql-container pre {
            background: #2d2d2d;
            color: #f8f8f2;
            padding: 1rem;
            border-radius: 4px;
            overflow-x: auto;
            font-family: 'Fira Code', Consolas, monospace;
            font-size: 0.85rem;
        }

        .case-branches {
            margin-top: 1.5rem;
        }

        .case-branches h4 {
            margin-bottom: 1rem;
            color: #333;
        }

        .case-branch {
            background: white;
            padding: 1rem;
            border-radius: 4px;
            margin-bottom: 0.5rem;
            border-left: 3px solid #28a745;
        }

        .else-branch {
            border-left-color: #ffc107;
        }

        .branch-num {
            font-weight: 600;
            color: #2a5298;
            font-size: 0.85rem;
        }

        .branch-condition, .branch-result {
            margin-top: 0.5rem;
        }

        .diagram-container {
            background: white;
            padding: 2rem;
            border-radius: 8px;
            overflow-x: auto;
        }

        .diagram-legend {
            margin-top: 1.5rem;
            padding: 1rem;
            background: #f8f9fa;
            border-radius: 4px;
        }

        .diagram-legend h4 {
            margin-bottom: 0.75rem;
            color: #333;
        }

        .legend-items {
            display: flex;
            gap: 2rem;
            flex-wrap: wrap;
        }

        .legend-item {
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }

        .legend-color {
            width: 16px;
            height: 16px;
            border-radius: 4px;
        }

        .legend-color.source { background: #d4edda; border: 1px solid #28a745; }
        .legend-color.target { background: #cce5ff; border: 1px solid #007bff; }
        .legend-color.intermediate { background: #fff3cd; border: 1px solid #ffc107; }

        .main-footer {
            text-align: center;
            padding: 2rem;
            color: #666;
            background: #f8f9fa;
        }

        .highlight {
            background: yellow;
        }

        @media (max-width: 900px) {
            .main-container {
                flex-direction: column;
            }

            .sidebar {
                width: 100%;
                position: static;
            }

            .toc {
                display: flex;
                flex-wrap: wrap;
                gap: 0.5rem;
            }

            .toc h3 {
                width: 100%;
            }

            .toc-item {
                border: 1px solid #e0e0e0;
                border-radius: 4px;
                padding: 0.5rem 1rem;
            }
        }

        @media print {
            .sidebar, .search-bar {
                display: none;
            }

            .content-section {
                break-inside: avoid;
            }
        }
        '''

    def _get_javascript(self) -> str:
        """Return embedded JavaScript."""
        return '''
        // Initialize Mermaid with error handling
        mermaid.initialize({
            startOnLoad: true,
            theme: 'default',
            securityLevel: 'loose',
            flowchart: {
                useMaxWidth: true,
                htmlLabels: true,
                curve: 'basis'
            }
        });

        // Handle Mermaid rendering errors
        mermaid.parseError = function(err, hash) {
            console.error('Mermaid parsing error:', err);
            const diagramDiv = document.querySelector('.mermaid');
            if (diagramDiv) {
                diagramDiv.innerHTML = '<div style="padding: 20px; background: #fff3cd; border: 1px solid #ffc107; border-radius: 4px;">' +
                    '<strong>Diagram rendering notice:</strong><br>' +
                    'The lineage diagram could not be rendered. Please view the Column Lineage table above for complete lineage information.' +
                    '</div>';
            }
        };

        // Toggle collapsible sections
        function toggleCollapsible(header) {
            const card = header.parentElement;
            card.classList.toggle('open');
        }

        // Open all collapsibles by default
        document.addEventListener('DOMContentLoaded', function() {
            document.querySelectorAll('.collapsible').forEach(function(el) {
                el.classList.add('open');
            });
        });

        // Search functionality
        function searchContent() {
            const searchTerm = document.getElementById('search-input').value.toLowerCase();
            const sections = document.querySelectorAll('.content-section');

            // Remove previous highlights
            document.querySelectorAll('.highlight').forEach(function(el) {
                el.outerHTML = el.innerHTML;
            });

            if (searchTerm.length < 2) {
                sections.forEach(function(section) {
                    section.style.display = 'block';
                });
                return;
            }

            sections.forEach(function(section) {
                const text = section.textContent.toLowerCase();
                if (text.includes(searchTerm)) {
                    section.style.display = 'block';
                    // Highlight matches
                    highlightText(section, searchTerm);
                } else {
                    section.style.display = 'none';
                }
            });
        }

        function highlightText(element, term) {
            const walker = document.createTreeWalker(
                element,
                NodeFilter.SHOW_TEXT,
                null,
                false
            );

            let node;
            const nodesToHighlight = [];

            while (node = walker.nextNode()) {
                if (node.nodeValue.toLowerCase().includes(term)) {
                    nodesToHighlight.push(node);
                }
            }

            nodesToHighlight.forEach(function(textNode) {
                const text = textNode.nodeValue;
                const regex = new RegExp('(' + term + ')', 'gi');
                const parts = text.split(regex);

                if (parts.length > 1) {
                    const fragment = document.createDocumentFragment();
                    parts.forEach(function(part) {
                        if (part.toLowerCase() === term) {
                            const span = document.createElement('span');
                            span.className = 'highlight';
                            span.textContent = part;
                            fragment.appendChild(span);
                        } else {
                            fragment.appendChild(document.createTextNode(part));
                        }
                    });
                    textNode.parentNode.replaceChild(fragment, textNode);
                }
            });
        }

        // Smooth scrolling for TOC links
        document.querySelectorAll('.toc-item').forEach(function(link) {
            link.addEventListener('click', function(e) {
                e.preventDefault();
                const targetId = this.getAttribute('href').substring(1);
                const target = document.getElementById(targetId);
                if (target) {
                    target.scrollIntoView({ behavior: 'smooth', block: 'start' });
                }
            });
        });
        '''
