"""
Transformation Explainer module.

Generates human-readable English explanations for SQL transformation logic.
"""

import re
from typing import List, Dict, Optional, Tuple
from dataclasses import dataclass


@dataclass
class TransformationExplanation:
    """Holds transformation explanation details."""
    sql_expression: str
    english_explanation: str
    transformation_type: str
    complexity: str  # 'simple', 'moderate', 'complex'


class TransformationExplainer:
    """
    Generate English explanations for SQL transformations.
    """

    # Common SQL function patterns and their explanations
    FUNCTION_EXPLANATIONS = {
        'CAST': 'Convert {arg} to {type} data type',
        'COALESCE': 'Use first non-null value from: {args}',
        'NVL': 'If {arg1} is null, use {arg2} instead',
        'ISNULL': 'If {arg1} is null, use {arg2} instead',
        'NULLIF': 'Return null if {arg1} equals {arg2}, otherwise return {arg1}',
        'TRIM': 'Remove leading and trailing spaces from {arg}',
        'LTRIM': 'Remove leading spaces from {arg}',
        'RTRIM': 'Remove trailing spaces from {arg}',
        'UPPER': 'Convert {arg} to uppercase',
        'LOWER': 'Convert {arg} to lowercase',
        'SUBSTRING': 'Extract characters from position {start} for {length} characters from {arg}',
        'SUBSTR': 'Extract characters from position {start} for {length} characters from {arg}',
        'LEFT': 'Take first {length} characters from {arg}',
        'RIGHT': 'Take last {length} characters from {arg}',
        'LEN': 'Get length of {arg}',
        'LENGTH': 'Get length of {arg}',
        'REPLACE': 'Replace {old} with {new} in {arg}',
        'CONCAT': 'Concatenate values: {args}',
        'MAX': 'Get maximum value of {arg}',
        'MIN': 'Get minimum value of {arg}',
        'SUM': 'Sum all values of {arg}',
        'AVG': 'Calculate average of {arg}',
        'COUNT': 'Count occurrences of {arg}',
        'ROW_NUMBER': 'Assign sequential row number',
        'RANK': 'Assign rank with gaps for ties',
        'DENSE_RANK': 'Assign rank without gaps for ties',
        'LEAD': 'Get value from {offset} rows after current row',
        'LAG': 'Get value from {offset} rows before current row',
        'FIRST_VALUE': 'Get first value in the window',
        'LAST_VALUE': 'Get last value in the window',
        'GETDATE': 'Get current date and time',
        'CURRENT_DATE': 'Get current date',
        'CURRENT_TIMESTAMP': 'Get current timestamp',
        'DATEADD': 'Add {interval} {unit} to {date}',
        'DATEDIFF': 'Calculate difference in {unit} between {date1} and {date2}',
        'YEAR': 'Extract year from {arg}',
        'MONTH': 'Extract month from {arg}',
        'DAY': 'Extract day from {arg}',
        'ROUND': 'Round {arg} to {precision} decimal places',
        'FLOOR': 'Round {arg} down to nearest integer',
        'CEILING': 'Round {arg} up to nearest integer',
        'ABS': 'Get absolute value of {arg}',
    }

    # Join type explanations
    JOIN_EXPLANATIONS = {
        'INNER': 'Returns only matching rows from both tables',
        'LEFT': 'Returns all rows from left table, matching rows from right (null if no match)',
        'LEFT OUTER': 'Returns all rows from left table, matching rows from right (null if no match)',
        'RIGHT': 'Returns all rows from right table, matching rows from left (null if no match)',
        'RIGHT OUTER': 'Returns all rows from right table, matching rows from left (null if no match)',
        'FULL': 'Returns all rows from both tables (null where no match)',
        'FULL OUTER': 'Returns all rows from both tables (null where no match)',
        'CROSS': 'Returns Cartesian product of both tables (all combinations)',
    }

    def __init__(self):
        pass

    def explain_transformation(self, sql_expression: str) -> TransformationExplanation:
        """
        Generate English explanation for a SQL transformation.

        Args:
            sql_expression: SQL expression to explain

        Returns:
            TransformationExplanation with English description
        """
        sql_upper = sql_expression.upper().strip()

        # Determine transformation type and complexity
        trans_type, complexity = self._classify_transformation(sql_expression)

        # Generate explanation
        explanation = self._generate_explanation(sql_expression)

        return TransformationExplanation(
            sql_expression=sql_expression,
            english_explanation=explanation,
            transformation_type=trans_type,
            complexity=complexity
        )

    def explain_case_statement(self, case_sql: str, branches: List[Dict]) -> str:
        """
        Generate English explanation for a CASE statement.

        Args:
            case_sql: Full CASE SQL
            branches: List of branch dictionaries with 'condition' and 'result'

        Returns:
            English explanation
        """
        explanations = []
        explanations.append("Conditional logic that:")

        for i, branch in enumerate(branches, 1):
            condition = branch.get('condition', '')
            result = branch.get('result', '')
            condition_explain = self._explain_condition(condition)
            explanations.append(f"  - If {condition_explain}, then use {self._simplify_expression(result)}")

        if 'else_result' in branches[-1] if branches else False:
            explanations.append(f"  - Otherwise, use {branches[-1].get('else_result', 'NULL')}")

        return '\n'.join(explanations)

    def explain_join_condition(self, join_type: str, left_table: str,
                                right_table: str, condition: str) -> str:
        """
        Generate English explanation for a JOIN.

        Args:
            join_type: Type of join (INNER, LEFT, etc.)
            left_table: Left table name
            right_table: Right table name
            condition: JOIN condition

        Returns:
            English explanation
        """
        join_desc = self.JOIN_EXPLANATIONS.get(
            join_type.upper(),
            f'{join_type} join between tables'
        )

        condition_explain = self._explain_condition(condition)

        return (
            f"{join_type} JOIN: {join_desc}. "
            f"Joins {self._simplify_table_name(left_table)} with "
            f"{self._simplify_table_name(right_table)} "
            f"where {condition_explain}"
        )

    def explain_filter_condition(self, where_sql: str) -> str:
        """
        Generate English explanation for a WHERE clause.

        Args:
            where_sql: WHERE clause SQL

        Returns:
            English explanation
        """
        conditions = self._parse_conditions(where_sql)
        explanations = []

        for cond in conditions:
            explanations.append(self._explain_condition(cond))

        if len(explanations) == 1:
            return f"Filter: {explanations[0]}"
        else:
            return "Filter conditions:\n  - " + "\n  - ".join(explanations)

    def _classify_transformation(self, sql: str) -> Tuple[str, str]:
        """Classify transformation type and complexity."""
        sql_upper = sql.upper()

        # Check for CASE
        if 'CASE' in sql_upper:
            nested_count = sql_upper.count('CASE')
            if nested_count > 1:
                return 'CONDITIONAL', 'complex'
            return 'CONDITIONAL', 'moderate'

        # Check for window functions
        if 'OVER' in sql_upper and '(' in sql_upper:
            return 'WINDOW_FUNCTION', 'complex'

        # Check for aggregates
        agg_funcs = ['SUM', 'COUNT', 'AVG', 'MAX', 'MIN']
        for func in agg_funcs:
            if func + '(' in sql_upper:
                return 'AGGREGATION', 'moderate'

        # Check for type conversion
        if 'CAST' in sql_upper or 'CONVERT' in sql_upper:
            return 'TYPE_CONVERSION', 'simple'

        # Check for string functions
        str_funcs = ['TRIM', 'LTRIM', 'RTRIM', 'UPPER', 'LOWER', 'SUBSTRING', 'REPLACE', 'CONCAT']
        for func in str_funcs:
            if func + '(' in sql_upper:
                return 'STRING_MANIPULATION', 'simple'

        # Check for null handling
        if 'COALESCE' in sql_upper or 'NVL' in sql_upper or 'ISNULL' in sql_upper:
            return 'NULL_HANDLING', 'simple'

        # Check for date functions
        date_funcs = ['DATEADD', 'DATEDIFF', 'GETDATE', 'YEAR', 'MONTH', 'DAY']
        for func in date_funcs:
            if func + '(' in sql_upper or func in sql_upper:
                return 'DATE_MANIPULATION', 'simple'

        # Check for arithmetic
        if any(op in sql for op in ['+', '-', '*', '/']):
            return 'ARITHMETIC', 'simple'

        # Check for concatenation
        if '||' in sql or 'CONCAT' in sql_upper:
            return 'CONCATENATION', 'simple'

        # Direct column reference
        if re.match(r'^[\w\.]+$', sql.strip()):
            return 'DIRECT_MAPPING', 'simple'

        return 'TRANSFORMATION', 'moderate'

    def _generate_explanation(self, sql: str) -> str:
        """Generate English explanation for SQL expression."""
        sql_upper = sql.upper().strip()

        # Direct column reference
        if re.match(r'^[\w\.]+$', sql.strip()):
            return f"Direct mapping from {sql.strip()}"

        # CASE statement
        if 'CASE' in sql_upper:
            return self._explain_case_inline(sql)

        # Type conversion
        cast_match = re.search(r'CAST\s*\(\s*(.+?)\s+AS\s+(\w+)', sql, re.IGNORECASE)
        if cast_match:
            expr = cast_match.group(1).strip()
            dtype = cast_match.group(2).strip()
            return f"Convert {self._simplify_expression(expr)} to {dtype} data type"

        # COALESCE
        coalesce_match = re.search(r'COALESCE\s*\((.+?)\)', sql, re.IGNORECASE)
        if coalesce_match:
            args = coalesce_match.group(1).split(',')
            args_clean = [self._simplify_expression(a) for a in args]
            return f"Use first non-null value from: {', '.join(args_clean)}"

        # String functions
        for func, template in self.FUNCTION_EXPLANATIONS.items():
            pattern = rf'{func}\s*\('
            if re.search(pattern, sql_upper):
                return self._explain_function(func, sql)

        # Concatenation
        if '||' in sql:
            parts = sql.split('||')
            parts_clean = [self._simplify_expression(p) for p in parts]
            return f"Concatenate: {' + '.join(parts_clean)}"

        # Arithmetic operations
        if re.search(r'[\+\-\*/]', sql):
            return f"Calculate: {self._simplify_expression(sql)}"

        # Default
        return f"Transform using: {sql[:100]}{'...' if len(sql) > 100 else ''}"

    def _explain_case_inline(self, sql: str) -> str:
        """Generate inline explanation for CASE statement."""
        # Count WHEN clauses
        when_count = sql.upper().count('WHEN')

        if when_count == 1:
            # Simple CASE
            when_match = re.search(r'WHEN\s+(.+?)\s+THEN', sql, re.IGNORECASE)
            else_match = re.search(r'ELSE\s+(.+?)\s+END', sql, re.IGNORECASE)

            if when_match:
                condition = when_match.group(1).strip()
                condition_explain = self._explain_condition(condition)

                if else_match:
                    return f"If {condition_explain}, apply transformation; otherwise use default value"
                return f"Conditional: If {condition_explain}, apply transformation"

        # Multi-branch CASE
        return f"Conditional logic with {when_count} branches determining the output value"

    def _explain_function(self, func_name: str, sql: str) -> str:
        """Explain a specific function call."""
        func_upper = func_name.upper()

        # Extract function arguments
        pattern = rf'{func_name}\s*\((.+?)\)'
        match = re.search(pattern, sql, re.IGNORECASE)

        if not match:
            return f"Apply {func_name} function"

        args = match.group(1)

        # Handle specific functions
        if func_upper in ['TRIM', 'LTRIM', 'RTRIM', 'UPPER', 'LOWER']:
            return f"{func_name}: {self._simplify_expression(args)}"

        if func_upper in ['SUBSTRING', 'SUBSTR']:
            parts = args.split(',')
            if len(parts) >= 3:
                return f"Extract substring from {self._simplify_expression(parts[0])} starting at position {parts[1].strip()} for {parts[2].strip()} characters"
            return f"Extract substring from {self._simplify_expression(args)}"

        if func_upper in ['MAX', 'MIN', 'SUM', 'AVG', 'COUNT']:
            return f"Calculate {func_name.lower()} of {self._simplify_expression(args)}"

        if func_upper == 'ROW_NUMBER':
            return "Assign sequential row number within partition"

        return f"Apply {func_name} to {self._simplify_expression(args)}"

    def _explain_condition(self, condition: str) -> str:
        """Generate English explanation for a condition."""
        condition = condition.strip()

        # NULL checks
        if re.search(r'IS\s+NULL', condition, re.IGNORECASE):
            col = re.sub(r'\s+IS\s+NULL.*', '', condition, flags=re.IGNORECASE)
            return f"{self._simplify_expression(col)} is null"

        if re.search(r'IS\s+NOT\s+NULL', condition, re.IGNORECASE):
            col = re.sub(r'\s+IS\s+NOT\s+NULL.*', '', condition, flags=re.IGNORECASE)
            return f"{self._simplify_expression(col)} is not null"

        # Equality
        eq_match = re.match(r'(.+?)\s*=\s*(.+)', condition)
        if eq_match:
            left = self._simplify_expression(eq_match.group(1))
            right = self._simplify_expression(eq_match.group(2))
            return f"{left} equals {right}"

        # Not equal
        neq_match = re.match(r'(.+?)\s*(<>|!=)\s*(.+)', condition)
        if neq_match:
            left = self._simplify_expression(neq_match.group(1))
            right = self._simplify_expression(neq_match.group(3))
            return f"{left} does not equal {right}"

        # Comparison operators
        comp_match = re.match(r'(.+?)\s*(>=|<=|>|<)\s*(.+)', condition)
        if comp_match:
            left = self._simplify_expression(comp_match.group(1))
            op = comp_match.group(2)
            right = self._simplify_expression(comp_match.group(3))
            op_text = {'>': 'greater than', '<': 'less than',
                       '>=': 'greater than or equal to', '<=': 'less than or equal to'}
            return f"{left} is {op_text.get(op, op)} {right}"

        # IN clause
        in_match = re.match(r'(.+?)\s+IN\s*\((.+?)\)', condition, re.IGNORECASE)
        if in_match:
            col = self._simplify_expression(in_match.group(1))
            values = in_match.group(2)
            return f"{col} is one of ({values})"

        # LIKE
        like_match = re.match(r'(.+?)\s+LIKE\s+(.+)', condition, re.IGNORECASE)
        if like_match:
            col = self._simplify_expression(like_match.group(1))
            pattern = like_match.group(2).strip()
            return f"{col} matches pattern {pattern}"

        # BETWEEN
        between_match = re.match(r'(.+?)\s+BETWEEN\s+(.+?)\s+AND\s+(.+)', condition, re.IGNORECASE)
        if between_match:
            col = self._simplify_expression(between_match.group(1))
            low = between_match.group(2).strip()
            high = between_match.group(3).strip()
            return f"{col} is between {low} and {high}"

        return condition

    def _parse_conditions(self, where_sql: str) -> List[str]:
        """Parse WHERE clause into individual conditions."""
        # Remove WHERE keyword
        sql = re.sub(r'^\s*WHERE\s+', '', where_sql, flags=re.IGNORECASE)

        # Split by AND/OR (simplified - doesn't handle nested parentheses perfectly)
        conditions = re.split(r'\s+AND\s+|\s+OR\s+', sql, flags=re.IGNORECASE)

        return [c.strip() for c in conditions if c.strip()]

    def _simplify_expression(self, expr: str) -> str:
        """Simplify expression for readability."""
        expr = expr.strip()

        # Remove table alias prefix for readability in explanations
        # e.g., "STG.COLUMN_NAME" -> "COLUMN_NAME"
        if '.' in expr and not expr.startswith("'"):
            parts = expr.split('.')
            if len(parts) == 2 and parts[0].upper() == parts[0]:
                # Likely a table.column reference
                return parts[-1]

        return expr

    def _simplify_table_name(self, table_name: str) -> str:
        """Simplify table name for readability."""
        if not table_name:
            return "unknown table"

        # If it's a subquery, truncate
        if table_name.startswith('('):
            return "(subquery)"

        # Get just the table name from schema.table
        if '.' in table_name:
            return table_name.split('.')[-1]

        return table_name
