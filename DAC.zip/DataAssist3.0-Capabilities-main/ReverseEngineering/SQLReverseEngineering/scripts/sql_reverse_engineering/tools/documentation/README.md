# Documentation

## Overview
The Documentation module generates comprehensive documentation for SQL scripts including HTML help files, field mappings, and transformation explanations.

## Components

### `help_generator.py`
Generates standalone HTML documentation similar to .CHM help files.

**Key Features:**
- Single-file HTML with embedded CSS/JavaScript
- Table of contents with navigation
- Search functionality
- Collapsible sections
- Embedded Mermaid diagrams
- Complete lineage information
- Transformation details

**Output Includes:**
- Script overview and metadata
- Column-level lineage
- Transformation classifications
- Join relationships
- Function usage
- Visual lineage diagrams
- Searchable content

### `mapping_generator.py`
Generates source-to-target field mappings.

**Key Features:**
- Create mapping tables (CSV, Excel, JSON)
- Source and target column relationships
- Transformation descriptions
- Data type information
- Business rule documentation

**Mapping Fields:**
- Source table and column
- Target table and column
- Transformation type
- Transformation logic
- Data type mapping
- Business rules

### `transformation_explainer.py`
Generates human-readable explanations of transformations.

**Key Features:**
- Natural language descriptions
- Explain complex logic
- Document business rules
- Describe data flow
- Clarify transformation intent

**Explanation Types:**
- Aggregations (SUM, AVG, COUNT, etc.)
- CASE logic
- String manipulations
- Date operations
- Mathematical calculations
- Join relationships

### `templates/`
HTML and documentation templates.

**Contains:**
- HTML templates
- CSS stylesheets
- JavaScript for interactivity
- Mermaid diagram templates

## Classes

### `HTMLHelpGenerator`
Main class for generating HTML documentation.

**Methods:**
- `generate_help()` - Generate complete HTML documentation
- Embed CSS, JavaScript, and diagrams
- Create navigation and search

### `SourceTargetMappingGenerator`
Generate field-level mappings.

**Methods:**
- `generate_mapping()` - Create mapping documentation
- Multiple output formats (CSV, Excel, JSON)

## Usage Example

```python
from documentation.help_generator import HTMLHelpGenerator
from lineage.lineage_graph import LineageGraph

# Generate HTML documentation
generator = HTMLHelpGenerator()
generator.generate_help(
    output_path="output/documentation.html",
    lineage_graph=lineage_graph,
    element_catalog=catalog,
    title="ETL Job Documentation"
)

# Generate mapping
from documentation.mapping_generator import SourceTargetMappingGenerator
mapping_gen = SourceTargetMappingGenerator(lineage_graph)
mapping_gen.generate_csv("output/field_mapping.csv")
```

## Output Formats

### HTML Documentation
- Interactive HTML file
- Embedded search
- Collapsible sections
- Visual diagrams

### Field Mappings
- CSV tables
- Excel spreadsheets
- JSON structured data

### Transformation Explanations
- Plain text descriptions
- Markdown format
- Embedded in HTML

## Features

### Search Functionality
- Full-text search
- Filter by element type
- Quick navigation

### Visual Elements
- Mermaid flowcharts
- Lineage diagrams
- Tree structures
- Network graphs

### Export Options
- Single HTML file
- Multiple CSV files
- JSON exports
- Mermaid diagrams

## Integration Points
- Inputs: LineageGraph, ElementCatalog
- Used by: CLI, API, agent_interface
- Outputs: HTML, CSV, JSON, Markdown files
