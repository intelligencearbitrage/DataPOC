"""
Source-to-Target Mapping Generator module.

Generates documentation in CSV, Excel, and other formats
compatible with existing BDaaS lineage outputs.

Enhanced to include:
- Filter conditions (WHERE clauses)
- Join conditions
- English explanations of transformation logic
"""

import csv
import json
import networkx as nx
from typing import List, Dict, Optional, Any
from io import StringIO
import sys
import os

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from models.data_models import (
    ElementCatalog,
    FilterConditionDetail,
    JoinConditionDetail,
    LineageOutputMetadata,
    ColumnMappingRecord,
    StructuredLineageOutput,
    SubqueryDetail,
    ColumnRef,
    TableAliasDetail
)
from lineage.lineage_graph import LineageGraph
from documentation.transformation_explainer import TransformationExplainer
from deconstructor.join_extractor import JoinExtractor
import sqlglot
from deconstructor.subquery_decomposer import SubqueryDecomposer
from datetime import datetime


import re as _re


def _restore_teradata_syntax(sql: str) -> str:
    """
    Reverse sqlglot normalizations to restore original Teradata syntax.

    sqlglot normalizes:
    - CHAR_LENGTH(x) -> LENGTH(x)
    - SUBSTRING(x FROM y FOR z) -> SUBSTRING(x, y, z)
    - TRIM(BOTH y FROM x) -> TRIM(x, y)

    This function reverses those so the STTM output matches the source SQL.
    """
    if not sql:
        return sql

    result = sql

    # 1. LENGTH(x) -> CHAR_LENGTH(x)
    # Avoid matching CHAR_LENGTH already present
    result = _re.sub(r'\bLENGTH\(', 'CHAR_LENGTH(', result)
    # Fix double-replacement: CHAR_CHAR_LENGTH -> CHAR_LENGTH
    result = result.replace('CHAR_CHAR_LENGTH', 'CHAR_LENGTH')

    # 2. SUBSTRING(x, y, z) -> SUBSTRING(x FROM y FOR z)
    # Need paren-balanced parsing for the first argument
    pos = 0
    while True:
        idx = result.upper().find('SUBSTRING(', pos)
        if idx == -1:
            break
        paren_start = idx + len('SUBSTRING')
        # Find matching closing paren
        depth = 0
        i = paren_start
        while i < len(result):
            if result[i] == '(':
                depth += 1
            elif result[i] == ')':
                depth -= 1
                if depth == 0:
                    break
            i += 1
        if depth != 0:
            pos = paren_start + 1
            continue
        inner = result[paren_start + 1:i]
        # Split inner on top-level commas (depth=0)
        args = []
        arg_start = 0
        d = 0
        in_str = False
        str_ch = None
        for j, ch in enumerate(inner):
            if in_str:
                if ch == str_ch:
                    in_str = False
            elif ch in ("'", '"'):
                in_str = True
                str_ch = ch
            elif ch == '(':
                d += 1
            elif ch == ')':
                d -= 1
            elif ch == ',' and d == 0:
                args.append(inner[arg_start:j].strip())
                arg_start = j + 1
        args.append(inner[arg_start:].strip())

        if len(args) == 3:
            # SUBSTRING(x, y, z) -> SUBSTRING(x FROM y FOR z)
            replacement = f"SUBSTRING({args[0]} FROM {args[1]} FOR {args[2]})"
            result = result[:idx] + replacement + result[i + 1:]
            pos = idx + len(replacement)
        else:
            pos = paren_start + 1

    # 3. TRIM(x, y) -> TRIM(BOTH y FROM x)
    # Only apply when TRIM has exactly 2 args (sqlglot's normalization)
    pos = 0
    while True:
        idx = result.upper().find('TRIM(', pos)
        if idx == -1:
            break
        paren_start = idx + len('TRIM')
        depth = 0
        i = paren_start
        while i < len(result):
            if result[i] == '(':
                depth += 1
            elif result[i] == ')':
                depth -= 1
                if depth == 0:
                    break
            i += 1
        if depth != 0:
            pos = paren_start + 1
            continue
        inner = result[paren_start + 1:i]
        # Split on top-level commas
        args = []
        arg_start = 0
        d = 0
        in_str = False
        str_ch = None
        for j, ch in enumerate(inner):
            if in_str:
                if ch == str_ch:
                    in_str = False
            elif ch in ("'", '"'):
                in_str = True
                str_ch = ch
            elif ch == '(':
                d += 1
            elif ch == ')':
                d -= 1
            elif ch == ',' and d == 0:
                args.append(inner[arg_start:j].strip())
                arg_start = j + 1
        args.append(inner[arg_start:].strip())

        if len(args) == 2:
            replacement = f"TRIM(BOTH {args[1]} FROM {args[0]})"
            result = result[:idx] + replacement + result[i + 1:]
            pos = idx + len(replacement)
        else:
            pos = paren_start + 1

    # 4. INSTR(x, y) -> POSITION(y IN x)
    # sqlglot normalizes POSITION('str' IN col) -> INSTR(col, 'str')
    pos = 0
    while True:
        idx = result.upper().find('INSTR(', pos)
        if idx == -1:
            break
        paren_start = idx + len('INSTR')
        depth = 0
        i = paren_start
        while i < len(result):
            if result[i] == '(':
                depth += 1
            elif result[i] == ')':
                depth -= 1
                if depth == 0:
                    break
            i += 1
        if depth != 0:
            pos = paren_start + 1
            continue
        inner = result[paren_start + 1:i]
        args = []
        arg_start = 0
        d = 0
        in_str = False
        str_ch = None
        for j, ch in enumerate(inner):
            if in_str:
                if ch == str_ch:
                    in_str = False
            elif ch in ("'", '"'):
                in_str = True
                str_ch = ch
            elif ch == '(':
                d += 1
            elif ch == ')':
                d -= 1
            elif ch == ',' and d == 0:
                args.append(inner[arg_start:j].strip())
                arg_start = j + 1
        args.append(inner[arg_start:].strip())

        if len(args) == 2:
            replacement = f"POSITION({args[1]} IN {args[0]})"
            result = result[:idx] + replacement + result[i + 1:]
            pos = idx + len(replacement)
        else:
            pos = paren_start + 1

    return result


class SourceTargetMappingGenerator:
    """
    Generate source-to-target mapping documents.
    Output format compatible with existing BDaaS lineage CSVs.
    """

    def __init__(self, lineage_graph: LineageGraph = None,
                 element_catalog: ElementCatalog = None,
                 all_element_catalogs: List[ElementCatalog] = None):
        """
        Initialize generator.

        Args:
            lineage_graph: Lineage graph with column mappings
            element_catalog: Element catalog with SQL details (primary/first)
            all_element_catalogs: All element catalogs across statements.
                When provided, joins/filters/aliases are aggregated from all catalogs.
        """
        self.lineage = lineage_graph
        self.elements = element_catalog
        self._all_elements = all_element_catalogs or ([element_catalog] if element_catalog else [])
        self.explainer = TransformationExplainer()

    def generate_csv(self, output_path: str) -> None:
        """
        Generate CSV with BDaaS-compatible format.

        Output columns:
        - Source_Table
        - Source_Attribute
        - Transformation_Logic
        - Target_Table
        - Target_Attribute

        Args:
            output_path: Path to output CSV file
        """
        rows = self._build_rows()

        with open(output_path, 'w', newline='', encoding='utf-8') as f:
            writer = csv.DictWriter(f, fieldnames=[
                'Source_Table', 'Source_Attribute',
                'Transformation_Logic',
                'Target_Table', 'Target_Attribute',
                'DML_Operation',
                'Join_Conditions', 'Filter_Conditions'
            ], extrasaction='ignore')
            writer.writeheader()
            writer.writerows(rows)

    def generate_csv_string(self) -> str:
        """
        Generate CSV as string.

        Returns:
            CSV content as string
        """
        rows = self._build_rows()

        output = StringIO()
        writer = csv.DictWriter(output, fieldnames=[
            'Source_Table', 'Source_Attribute',
            'Transformation_Logic',
            'Target_Table', 'Target_Attribute',
            'DML_Operation'
        ], extrasaction='ignore')
        writer.writeheader()
        writer.writerows(rows)

        return output.getvalue()

    def generate_comprehensive_csv(self, output_path: str) -> None:
        """
        Generate comprehensive CSV with filter conditions, join conditions,
        and English explanations.

        Output columns:
        - Source_Table
        - Source_Attribute
        - Transformation_Logic
        - Transformation_Explanation (English)
        - Target_Table
        - Target_Attribute
        - Filter_Conditions
        - Join_Conditions

        Args:
            output_path: Path to output CSV file
        """
        rows = self._build_comprehensive_rows()

        fieldnames = [
            'Source_Table', 'Source_Attribute',
            'Transformation_Logic', 'Transformation_Explanation',
            'Target_Table', 'Target_Attribute',
            'DML_Operation', 'Filter_Conditions', 'Join_Conditions',
            'STTM', 'Volatile_Table_Name'
        ]

        with open(output_path, 'w', newline='', encoding='utf-8') as f:
            writer = csv.DictWriter(f, fieldnames=fieldnames)
            writer.writeheader()
            writer.writerows(rows)

    def generate_comprehensive_json(self, output_path: str) -> None:
        """Generate STTM data as JSON."""
        rows = self._build_comprehensive_rows()
        with open(output_path, 'w', encoding='utf-8') as f:
            json.dump(rows, f, indent=2)

    # =========================================================================
    # Hop-Based STTM Methods
    # =========================================================================

    def _build_hop_rows(self) -> List[Dict[str, Any]]:
        """
        Build hop-based STTM rows by walking multi-hop paths through the
        lineage graph from leaf sources to final targets.

        Each chain (source -> ... -> final_target) is emitted as multiple
        rows, one per hop, with EDGE_ID grouping the chain, HOP_NUMBER
        indicating position, and HOP_COUNT the total hops.

        Returns:
            List of row dicts with hop-based STTM columns
        """
        import hashlib

        if not self.lineage:
            return []

        graph = self.lineage.graph
        rows = []
        edge_counter = 0

        # Identify final target columns: nodes with out_degree == 0
        final_targets = [
            node_id for node_id in graph.nodes()
            if graph.out_degree(node_id) == 0
        ]

        # Identify leaf sources: nodes with in_degree == 0
        leaf_sources = set(
            node_id for node_id in graph.nodes()
            if graph.in_degree(node_id) == 0
        )

        for target_id in final_targets:
            target_data = graph.nodes[target_id]
            target_table = target_data.get('table_name', '')
            target_column = target_data.get('column_name', '')

            # Find all ancestors (upstream nodes) of this target
            try:
                ancestors = nx.ancestors(graph, target_id)
            except nx.NetworkXError:
                continue

            # Filter to leaf sources only (ultimate sources)
            source_nodes = ancestors & leaf_sources
            if not source_nodes:
                # If no leaf sources, the target itself might be a direct edge
                # Check immediate predecessors
                for pred in graph.predecessors(target_id):
                    source_nodes.add(pred)

            for source_id in source_nodes:
                # Find shortest path from source to target
                try:
                    path_ids = nx.shortest_path(graph, source_id, target_id)
                except nx.NetworkXNoPath:
                    continue

                if len(path_ids) < 2:
                    continue

                hop_count = len(path_ids) - 1
                edge_counter += 1
                # Create a stable EDGE_ID from the path
                path_key = "->".join(path_ids)
                edge_id = f"E{edge_counter:04d}"

                for hop_idx in range(hop_count):
                    hop_source_id = path_ids[hop_idx]
                    hop_target_id = path_ids[hop_idx + 1]
                    hop_number = hop_idx + 1

                    src_data = graph.nodes[hop_source_id]
                    tgt_data = graph.nodes[hop_target_id]

                    # Get edge metadata from graph
                    edge_data = self.lineage.get_edge_data(hop_source_id, hop_target_id)

                    transformation_subtype = ""
                    transformation_expression = ""
                    subquery_alias = ""
                    union_type = ""

                    if edge_data:
                        transform = edge_data.get('transformation', {})
                        if isinstance(transform, dict):
                            transformation_subtype = transform.get('subtype', '')
                            transformation_expression = transform.get('sql_expression', '')
                        subquery_alias = edge_data.get('subquery_alias', '')
                        union_type = edge_data.get('union_type', '')

                    rows.append({
                        'EDGE_ID': edge_id,
                        'HOP_NUMBER': hop_number,
                        'HOP_COUNT': hop_count,
                        'SOURCE_TABLE': src_data.get('table_name', ''),
                        'SOURCE_COLUMN': src_data.get('column_name', ''),
                        'TARGET_TABLE': tgt_data.get('table_name', ''),
                        'TARGET_COLUMN': tgt_data.get('column_name', ''),
                        'TRANSFORMATION_SUBTYPE': transformation_subtype,
                        'TRANSFORMATION_EXPRESSION': transformation_expression,
                        'SUBQUERY_ALIAS': subquery_alias,
                        'UNION_TYPE': union_type
                    })

        return rows

    def generate_hop_csv(self, output_path: str) -> None:
        """
        Generate hop-based STTM CSV file.

        Args:
            output_path: Path to output CSV file
        """
        rows = self._build_hop_rows()

        fieldnames = [
            'EDGE_ID', 'HOP_NUMBER', 'HOP_COUNT',
            'SOURCE_TABLE', 'SOURCE_COLUMN',
            'TARGET_TABLE', 'TARGET_COLUMN',
            'TRANSFORMATION_SUBTYPE', 'TRANSFORMATION_EXPRESSION',
            'SUBQUERY_ALIAS', 'UNION_TYPE'
        ]

        with open(output_path, 'w', newline='', encoding='utf-8') as f:
            writer = csv.DictWriter(f, fieldnames=fieldnames)
            writer.writeheader()
            writer.writerows(rows)

    def generate_hop_json(self, output_path: str) -> None:
        """
        Generate hop-based STTM JSON file.

        Args:
            output_path: Path to output JSON file
        """
        rows = self._build_hop_rows()
        with open(output_path, 'w', encoding='utf-8') as f:
            json.dump(rows, f, indent=2)

    def generate_comprehensive_csv_string(self) -> str:
        """
        Generate comprehensive CSV as string.

        Returns:
            CSV content as string
        """
        rows = self._build_comprehensive_rows()

        fieldnames = [
            'Source_Table', 'Source_Attribute',
            'Transformation_Logic', 'Transformation_Explanation',
            'Target_Table', 'Target_Attribute',
            'DML_Operation', 'Filter_Conditions', 'Join_Conditions',
            'STTM', 'Volatile_Table_Name'
        ]

        output = StringIO()
        writer = csv.DictWriter(output, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)

        return output.getvalue()

    def _build_comprehensive_rows(self) -> List[Dict[str, str]]:
        """
        Build comprehensive CSV rows with explanations and conditions.

        Returns:
            List of row dictionaries
        """
        rows = []

        if not self.lineage:
            return rows

        # Get filter and join conditions from elements
        filter_conditions = self._get_filter_conditions()
        join_conditions = self._get_join_conditions()

        for edge in self.lineage.edges:
            # Generate English explanation
            explanation = self.explainer.explain_transformation(
                edge.transformation.sql_expression
            )

            # Prefer edge-level metadata over element-level (more specific)
            edge_dml = getattr(edge, 'dml_operation', '') or ''
            edge_join = getattr(edge, 'join_conditions', '') or join_conditions
            edge_where = getattr(edge, 'where_conditions', '') or filter_conditions

            rows.append({
                'Source_Table': edge.source.table_name,
                'Source_Attribute': edge.source.column_name,
                'Transformation_Logic': edge.transformation.sql_expression,
                'Transformation_Explanation': explanation.english_explanation,
                'Target_Table': edge.target.table_name,
                'Target_Attribute': edge.target.column_name,
                'DML_Operation': edge_dml,
                'Filter_Conditions': edge_where,
                'Join_Conditions': edge_join
            })

        return rows

    def _get_filter_conditions(self) -> str:
        """Extract filter conditions from elements."""
        if not self.elements or not self.elements.where_clause:
            return ""

        where = self.elements.where_clause
        explanation = self.explainer.explain_filter_condition(where.sql_text)
        return f"{where.sql_text}\n[{explanation}]"

    def _get_join_conditions(self) -> str:
        """Extract join conditions from elements."""
        if not self.elements or not self.elements.joins:
            return ""

        join_texts = []
        for join in self.elements.joins:
            explanation = self.explainer.explain_join_condition(
                join.join_type,
                join.left_table or "",
                join.right_table or "",
                join.predicate_sql or ""
            )
            join_texts.append(f"{join.join_type} JOIN {join.right_table} ON {join.predicate_sql}\n[{explanation}]")

        return "\n\n".join(join_texts)

    def generate_extended_csv(self, output_path: str,
                               job_name: str = "",
                               procedure_name: str = "") -> None:
        """
        Generate extended CSV with DCC format columns.

        Args:
            output_path: Path to output CSV file
            job_name: Job name for metadata
            procedure_name: Procedure/view name
        """
        rows = self._build_extended_rows(job_name, procedure_name)

        fieldnames = [
            'Job', 'Procedure/View Name', 'SQL Type', 'Script Type',
            'Source Entity', 'Source Schema Name', 'Source Attribute',
            'Source Business Rule',
            'Target Entity', 'Target Schema Name', 'Target Attribute',
            'Target Business Rule',
            'TransformationType'
        ]

        with open(output_path, 'w', newline='', encoding='utf-8') as f:
            writer = csv.DictWriter(f, fieldnames=fieldnames)
            writer.writeheader()
            writer.writerows(rows)

    def generate_excel(self, output_path: str) -> None:
        """
        Generate Excel with multiple worksheets.

        Worksheets:
        - Column Mapping: Full source-to-target mapping
        - CASE Statements: All CASE logic with branches
        - JOINs: All join conditions
        - Functions: All function calls
        - CTEs: CTE definitions and lineage

        Args:
            output_path: Path to output Excel file
        """
        try:
            import openpyxl
            from openpyxl import Workbook
        except ImportError:
            raise ImportError("openpyxl is required for Excel output. Install with: pip install openpyxl")

        wb = Workbook()

        # Column Mapping sheet
        ws_mapping = wb.active
        ws_mapping.title = "Column Mapping"
        self._write_mapping_sheet(ws_mapping)

        # CASE Statements sheet
        if self.elements and self.elements.case_statements:
            ws_case = wb.create_sheet("CASE Statements")
            self._write_case_sheet(ws_case)

        # JOINs sheet
        if self.elements and self.elements.joins:
            ws_joins = wb.create_sheet("JOINs")
            self._write_joins_sheet(ws_joins)

        # Functions sheet
        if self.elements and self.elements.functions:
            ws_func = wb.create_sheet("Functions")
            self._write_functions_sheet(ws_func)

        # CTEs sheet
        if self.elements and self.elements.ctes:
            ws_cte = wb.create_sheet("CTEs")
            self._write_ctes_sheet(ws_cte)

        wb.save(output_path)

    def generate_json(self) -> str:
        """
        Generate JSON output.

        Returns:
            JSON string
        """
        data = {
            'lineage': self.lineage.to_dict() if self.lineage else {},
            'elements': self.elements.to_dict() if self.elements else {},
            'mapping': self._build_rows()
        }
        return json.dumps(data, indent=2)

    def generate_markdown_report(self, output_path: str = None) -> str:
        """
        Generate comprehensive Markdown report.

        Args:
            output_path: Optional path to save report

        Returns:
            Markdown content as string
        """
        lines = []
        lines.append("# SQL Lineage Report\n")

        # Summary
        lines.append("## Summary\n")
        if self.lineage:
            stats = self.lineage.get_statistics()
            lines.append(f"- **Total Columns Traced**: {stats['node_count']}")
            lines.append(f"- **Total Transformations**: {stats['edge_count']}")
            lines.append(f"- **Source Tables**: {', '.join(stats['source_tables'])}")
            lines.append(f"- **Target Tables**: {', '.join(stats['target_tables'])}")
        lines.append("")

        # Column Mapping
        lines.append("## Column Mapping\n")
        lines.append("| Source Table | Source Column | Transformation | Target Table | Target Column |")
        lines.append("|--------------|---------------|----------------|--------------|---------------|")

        for row in self._build_rows():
            lines.append(
                f"| {row['Source_Table']} | {row['Source_Attribute']} | "
                f"{row['Transformation_Logic'][:50]}... | "
                f"{row['Target_Table']} | {row['Target_Attribute']} |"
            )
        lines.append("")

        # CASE Statements
        if self.elements and self.elements.case_statements:
            lines.append("## CASE Statements\n")
            for i, case in enumerate(self.elements.case_statements, 1):
                lines.append(f"### CASE {i}")
                if case.output_alias:
                    lines.append(f"**Output Column**: {case.output_alias}\n")
                lines.append("```sql")
                lines.append(case.sql_text)
                lines.append("```\n")

                lines.append("**Branches**:")
                for j, branch in enumerate(case.branches, 1):
                    lines.append(f"- Branch {j}: WHEN `{branch.condition}` THEN `{branch.result}`")
                if case.else_result:
                    lines.append(f"- ELSE: `{case.else_result}`")
                lines.append("")

        # JOINs
        if self.elements and self.elements.joins:
            lines.append("## JOINs\n")
            for join in self.elements.joins:
                lines.append(f"### {join.join_type} JOIN")
                lines.append(f"- **Left Table**: {join.left_table}")
                lines.append(f"- **Right Table**: {join.right_table}")
                if join.predicate_sql:
                    lines.append(f"- **ON**: `{join.predicate_sql}`")
                lines.append("")

        # Lineage Diagram
        if self.lineage:
            lines.append("## Lineage Diagram\n")
            lines.append("```mermaid")
            lines.append(self.lineage.to_mermaid())
            lines.append("```\n")

        content = '\n'.join(lines)

        if output_path:
            with open(output_path, 'w', encoding='utf-8') as f:
                f.write(content)

        return content

    def _build_rows(self) -> List[Dict[str, str]]:
        """
        Build CSV rows from lineage graph.

        Returns:
            List of row dictionaries
        """
        if not self.lineage:
            return []

        return self.lineage.to_csv_rows()

    def _build_extended_rows(self, job_name: str,
                              procedure_name: str) -> List[Dict[str, str]]:
        """
        Build extended CSV rows with DCC format.

        Args:
            job_name: Job name
            procedure_name: Procedure name

        Returns:
            List of row dictionaries
        """
        rows = []

        if not self.lineage:
            return rows

        for edge in self.lineage.edges:
            # Parse schema from table name
            source_schema = ""
            source_table = edge.source.table_name
            if '.' in source_table:
                parts = source_table.split('.')
                if len(parts) >= 2:
                    source_schema = parts[-2]
                    source_table = parts[-1]

            target_schema = ""
            target_table = edge.target.table_name
            if '.' in target_table:
                parts = target_table.split('.')
                if len(parts) >= 2:
                    target_schema = parts[-2]
                    target_table = parts[-1]

            rows.append({
                'Job': job_name,
                'Procedure/View Name': procedure_name,
                'SQL Type': self.elements.statement_type if self.elements else 'SELECT',
                'Script Type': 'DML',
                'Source Entity': source_table,
                'Source Schema Name': source_schema,
                'Source Attribute': edge.source.column_name,
                'Source Business Rule': edge.transformation.sql_expression,
                'Target Entity': target_table,
                'Target Schema Name': target_schema,
                'Target Attribute': edge.target.column_name,
                'Target Business Rule': edge.transformation.sql_expression,
                'TransformationType': edge.transformation.subtype.value if hasattr(edge.transformation.subtype, 'value') else edge.transformation.subtype
            })

        return rows

    def _write_mapping_sheet(self, ws) -> None:
        """Write column mapping to Excel worksheet."""
        headers = ['Source_Table', 'Source_Attribute', 'Transformation_Logic',
                   'Target_Table', 'Target_Attribute']
        ws.append(headers)

        for row in self._build_rows():
            ws.append([
                row['Source_Table'],
                row['Source_Attribute'],
                row['Transformation_Logic'],
                row['Target_Table'],
                row['Target_Attribute']
            ])

    def _write_case_sheet(self, ws) -> None:
        """Write CASE statements to Excel worksheet."""
        headers = ['Expression ID', 'Output Alias', 'Branch #', 'Condition',
                   'Result', 'Full SQL']
        ws.append(headers)

        for case in self.elements.case_statements:
            for i, branch in enumerate(case.branches, 1):
                ws.append([
                    case.expression_id,
                    case.output_alias or '',
                    i,
                    branch.condition,
                    branch.result,
                    case.sql_text if i == 1 else ''
                ])
            if case.else_result:
                ws.append([
                    case.expression_id,
                    case.output_alias or '',
                    'ELSE',
                    '',
                    case.else_result,
                    ''
                ])

    def _write_joins_sheet(self, ws) -> None:
        """Write JOINs to Excel worksheet."""
        headers = ['Join Type', 'Left Table', 'Right Table', 'ON Condition']
        ws.append(headers)

        for join in self.elements.joins:
            ws.append([
                join.join_type,
                join.left_table,
                join.right_table,
                join.predicate_sql or ''
            ])

    def _write_functions_sheet(self, ws) -> None:
        """Write functions to Excel worksheet."""
        headers = ['Function Name', 'Is Aggregate', 'Is Window', 'SQL Text']
        ws.append(headers)

        for func in self.elements.functions:
            ws.append([
                func.function_name,
                'Yes' if func.is_aggregate else 'No',
                'Yes' if func.is_window else 'No',
                func.sql_text
            ])

    def _write_ctes_sheet(self, ws) -> None:
        """Write CTEs to Excel worksheet."""
        headers = ['CTE Name', 'Columns', 'Is Recursive', 'Dependencies', 'SQL']
        ws.append(headers)

        for cte in self.elements.ctes:
            ws.append([
                cte.name,
                ', '.join(cte.columns),
                'Yes' if cte.is_recursive else 'No',
                ', '.join(cte.dependencies),
                cte.definition_sql[:500]  # Truncate long SQL
            ])

    # =========================================================================
    # Structured Excel Output Methods
    # =========================================================================
    # These methods generate a structured Excel output with separate sheets
    # for column mappings, join conditions, and filter conditions to avoid
    # repetition of conditions for every column.

    def generate_structured_excel(self, output_path: str, source_file: str = None) -> StructuredLineageOutput:
        """
        Generate structured Excel with separate sheets for:
        - Summary: Overview of the lineage
        - Column Lineage: Source-to-target column mappings
        - Join Conditions: All joins with English explanations (documented once)
        - Filter Conditions: WHERE/HAVING clauses with English explanations

        Args:
            output_path: Path to output Excel file
            source_file: Optional source file name for metadata

        Returns:
            StructuredLineageOutput object with all structured data
        """
        try:
            import openpyxl
            from openpyxl import Workbook
            from openpyxl.styles import Font, Alignment, PatternFill, Border, Side
            from openpyxl.utils import get_column_letter
        except ImportError:
            raise ImportError("openpyxl is required for Excel output. Install with: pip install openpyxl")

        # Build structured output
        structured_output = self._build_structured_output(source_file)

        # Associate control flow context with column mappings
        # Only tag DML statements that are actually INSIDE the IF block,
        # NOT statements that happen to share the same target table.
        control_blocks = self._extract_control_flow_blocks(source_file)
        if control_blocks and structured_output.column_mappings:
            import re as _cf_re

            # Read source to find line positions of each element's raw SQL
            source_lines = []
            if source_file:
                try:
                    with open(source_file, 'r', encoding='utf-8', errors='replace') as _sf:
                        source_lines = _sf.read().split('\n')
                except Exception:
                    pass
            source_text_upper = '\n'.join(source_lines).upper() if source_lines else ""

            # Parse IF block line ranges
            # block['line_range'] = 'L53-L58'
            block_ranges = []  # [(start_line, end_line, block_id, condition, block_type)]
            for block in control_blocks:
                lr = block.get('line_range', '')
                lr_match = _cf_re.match(r'L(\d+)-L(\d+)', lr)
                if lr_match:
                    block_ranges.append((
                        int(lr_match.group(1)),
                        int(lr_match.group(2)),
                        block.get('block_id', ''),
                        block.get('condition', ''),
                        block.get('block_type', ''),
                    ))

            # For each element, find its start line in the source
            elem_start_lines = {}  # elem_index -> start_line_number
            if source_text_upper:
                # Track positions already matched to avoid duplicate assignment
                used_positions = set()
                for idx, elem in enumerate(self._all_elements):
                    if not hasattr(elem, 'raw_sql') or not elem.raw_sql:
                        continue
                    pos = -1
                    # Strategy 1: Match by DML type + target table name pattern
                    tgt = (elem.target_table or '').upper()
                    stype = (elem.statement_type or '').upper()
                    if tgt and stype:
                        if stype == 'CREATE VOLATILE TABLE':
                            pat = r'CREATE\s+(?:MULTISET\s+)?VOLATILE\s+TABLE\s+' + _cf_re.escape(tgt)
                        elif stype in ('INSERT', 'INSERT INTO'):
                            pat = r'INSERT\s+INTO\s+' + _cf_re.escape(tgt)
                        elif stype == 'DELETE':
                            pat = r'DELETE\s+(?:FROM\s+)?' + _cf_re.escape(tgt)
                        elif stype == 'UPDATE':
                            pat = r'UPDATE\s+' + _cf_re.escape(tgt)
                        elif stype in ('SELECT INTO', 'SELECT'):
                            # SELECT INTO var FROM table
                            pat = r'SELECT\s+.{0,200}?\s+INTO\s+' + _cf_re.escape(tgt)
                        else:
                            pat = None
                        if pat:
                            for m in _cf_re.finditer(pat, source_text_upper, _cf_re.DOTALL):
                                if m.start() not in used_positions:
                                    pos = m.start()
                                    used_positions.add(pos)
                                    break
                    # Strategy 2: Fallback to first 60 chars of normalized SQL
                    if pos < 0:
                        raw_upper = _cf_re.sub(r'\s+', ' ', elem.raw_sql.strip().upper())
                        search_key = raw_upper[:60]
                        pos = source_text_upper.find(search_key)
                    if pos >= 0:
                        # Convert char position to line number
                        line_num = source_text_upper[:pos].count('\n') + 1
                        elem_start_lines[idx] = line_num

            # Build DML sequence -> element index map using stored dml_sequence_map
            # (elem_index -> seq) => invert to (seq -> elem_index)
            seq_to_elem_idx = {}
            if hasattr(self, '_dml_sequence_map'):
                for elem_idx, seq in self._dml_sequence_map.items():
                    seq_to_elem_idx[seq] = elem_idx

            # Determine which DML sequences fall inside IF blocks
            seq_to_cf = {}  # dml_sequence -> list of (block_id, condition, block_type)
            for seq, elem_idx in seq_to_elem_idx.items():
                elem_line = elem_start_lines.get(elem_idx)
                if elem_line is None:
                    continue
                for (start_l, end_l, bid, cond, btype) in block_ranges:
                    if start_l <= elem_line <= end_l:
                        if seq not in seq_to_cf:
                            seq_to_cf[seq] = []
                        seq_to_cf[seq].append((bid, cond, btype))

            # Apply control flow context only to mappings whose DML sequence
            # is actually inside the IF block
            for m in structured_output.column_mappings:
                if m.dml_sequence is None:
                    continue
                cf_entries = seq_to_cf.get(m.dml_sequence, [])
                if cf_entries:
                    cf_parts = []
                    seen = set()
                    for bid, cond, btype in cf_entries:
                        key = (bid, cond)
                        if key not in seen:
                            seen.add(key)
                            cf_parts.append("{0}: {1} {2}".format(bid, btype, cond))
                    m.control_flow_context = "; ".join(cf_parts)

        # Extract target tables from control flow enclosed DML so
        # they appear in the Summary even though they lack column mappings
        self._cf_target_tables = set()
        if control_blocks:
            import re as _cf_tgt_re
            for block in control_blocks:
                enclosed = block.get('enclosed_dml', '') or ''
                for m in _cf_tgt_re.finditer(r'INSERT\s+INTO\s+(\S+)', enclosed, _cf_tgt_re.IGNORECASE):
                    tbl = m.group(1).rstrip('(')
                    if tbl:
                        self._cf_target_tables.add(tbl)

        wb = Workbook()

        # Summary sheet
        ws_summary = wb.active
        ws_summary.title = "Summary"
        self._write_summary_sheet(ws_summary, structured_output)

        # Column Lineage sheet
        ws_lineage = wb.create_sheet("Column Lineage")
        self._write_column_lineage_sheet(ws_lineage, structured_output)

        # Join Conditions sheet
        ws_joins = wb.create_sheet("Join Conditions")
        self._write_structured_joins_sheet(ws_joins, structured_output)

        # Filter Conditions sheet
        ws_filters = wb.create_sheet("Filter Conditions")
        self._write_structured_filters_sheet(ws_filters, structured_output)

        # Control Flow sheet
        ws_control = wb.create_sheet("Control Flow")
        control_blocks = self._extract_control_flow_blocks(source_file)
        structured_output.control_flow = control_blocks
        self._write_control_flow_sheet_from_blocks(ws_control, control_blocks)

        # Update Summary sheet's Control Flow Blocks count
        cf_count = ws_control.max_row - 1  # exclude header
        for row in ws_summary.iter_rows(min_row=1, max_row=ws_summary.max_row, max_col=2):
            if row[0].value == "Control Flow Blocks":
                row[1].value = str(cf_count)
                break

        # Apply styling (including green highlight for subquery decomposition rows)
        self._apply_excel_styling(wb)

        wb.save(output_path)

        # Write structured JSON alongside the XLSX
        json_path = output_path.replace('_structured.xlsx', '_sttm.json')
        if json_path == output_path:
            json_path = output_path.rsplit('.', 1)[0] + '_sttm.json'
        try:
            import json as _json
            with open(json_path, 'w', encoding='utf-8') as jf:
                _json.dump(structured_output.to_dict(), jf, indent=2, default=str)
        except Exception as e:
            print(f"Warning: Could not write JSON output to {json_path}: {e}")

        return structured_output

    def _build_structured_output(self, source_file: str = None) -> StructuredLineageOutput:
        """
        Build the structured lineage output with all components.

        Args:
            source_file: Optional source file path

        Returns:
            StructuredLineageOutput object
        """
        # Build metadata — aggregate from all element catalogs
        target_tables_set = set()
        source_tables_set = set()
        statement_type = "SELECT"

        if self.elements:
            statement_type = self.elements.statement_type or "SELECT"
            if self.elements.target_table:
                target_tables_set.add(self.elements.target_table)

        for elem in self._all_elements:
            if elem.source_tables:
                source_tables_set.update(elem.source_tables)
            if elem.target_table:
                target_tables_set.add(elem.target_table)
        source_tables = sorted(source_tables_set)
        target_tables = sorted(target_tables_set)

        # Build DML sequence index: map element catalogs to sequence numbers
        # Only DML statements (INSERT/DELETE/SELECT/UPDATE/MERGE) get a sequence
        DML_TYPES = {"INSERT", "DELETE", "SELECT", "SELECT INTO", "UPDATE", "MERGE", "CREATE", "CREATE VOLATILE TABLE"}

        # Sort elements by their position in the source file to get procedure execution order
        # This ensures SELECT INTOs, INSERT/DELETE pairs appear in the correct sequence
        source_sql = ""
        if source_file:
            try:
                with open(source_file, 'r', encoding='utf-8', errors='replace') as f:
                    source_sql = f.read().upper()
            except Exception:
                pass

        if source_sql:
            import re as _re_sort
            # Find position of each element's raw SQL in the source
            elem_positions = []
            for idx, elem in enumerate(self._all_elements):
                pos = -1
                if elem.raw_sql:
                    # Find position using first significant tokens
                    raw_upper = elem.raw_sql.strip().upper()
                    # Try first 50 chars for matching
                    search_key = raw_upper[:80].replace('\n', ' ').strip()
                    pos = source_sql.find(search_key[:50])
                    if pos == -1:
                        # Fallback: search by target table + statement type
                        # Use regex with \s+ to handle variable whitespace
                        if elem.target_table and elem.statement_type:
                            tbl = _re_sort.escape(elem.target_table.upper())
                            if elem.statement_type == "CREATE VOLATILE TABLE":
                                pat = r'CREATE\s+(?:MULTISET\s+)?VOLATILE\s+TABLE\s+' + tbl
                            elif elem.statement_type in ("INSERT",):
                                pat = r'INSERT\s+INTO\s+' + tbl
                            elif elem.statement_type == "DELETE":
                                pat = r'DELETE\s+FROM\s+' + tbl
                            elif elem.statement_type == "SELECT INTO":
                                pat = r'INTO\s+' + tbl
                            elif elem.statement_type == "UPDATE":
                                pat = r'UPDATE\s+' + tbl
                            elif elem.statement_type == "MERGE":
                                pat = r'MERGE\s+INTO\s+' + tbl
                            else:
                                pat = None
                            if pat:
                                m = _re_sort.search(pat, source_sql)
                                if m:
                                    pos = m.start()
                elem_positions.append((idx, pos if pos >= 0 else 999999))

            # Sort by position, but keep original indices for reference
            sorted_elems = sorted(elem_positions, key=lambda x: x[1])
            # Build mapping: original_idx -> sorted_position
            elem_sort_order = {}
            for sort_pos, (orig_idx, _) in enumerate(sorted_elems):
                elem_sort_order[orig_idx] = sort_pos
        else:
            elem_sort_order = {idx: idx for idx in range(len(self._all_elements))}

        # Assign sequence numbers in sorted (procedure execution) order
        dml_sequence_map = {}  # elem index -> sequence number
        dml_seq = 0
        # Process elements in sorted order
        sorted_indices = sorted(range(len(self._all_elements)), key=lambda i: elem_sort_order.get(i, i))
        for idx in sorted_indices:
            elem = self._all_elements[idx]
            if elem.statement_type in DML_TYPES and (elem.target_table or elem.source_tables):
                dml_seq += 1
                dml_sequence_map[idx] = dml_seq
        # Store for use in control flow scope assignment
        self._dml_sequence_map = dml_sequence_map

        # Build join conditions with English explanations, tracking elem->IDs
        join_conditions, elem_join_ids, scalar_join_map = self._build_join_condition_details_indexed(dml_sequence_map)

        # Build filter conditions with English explanations, tracking elem->IDs
        filter_conditions, elem_filter_ids = self._build_filter_condition_details_indexed(dml_sequence_map)

        # Build target_table -> element index lookup for matching edges to statements
        # For each target table, collect all element indices (in order) that write to it
        target_to_elems = {}  # target_table -> list of (elem_idx, elem)
        for idx, elem in enumerate(self._all_elements):
            if elem.target_table and elem.statement_type in DML_TYPES:
                key = elem.target_table
                if key not in target_to_elems:
                    target_to_elems[key] = []
                target_to_elems[key].append(idx)

        # Build group_by map from element catalogs
        elem_group_by = {}  # elem_idx -> group_by sql text
        for idx, elem in enumerate(self._all_elements):
            if hasattr(elem, 'group_by') and elem.group_by:
                gb = elem.group_by
                if hasattr(gb, 'sql_text') and gb.sql_text:
                    elem_group_by[idx] = gb.sql_text
                elif isinstance(gb, dict) and gb.get('sql_text'):
                    elem_group_by[idx] = gb['sql_text']

        # Build per-element alias map from all element catalogs
        # Maps elem_idx -> {table_name_upper -> alias}
        # This prevents alias "leaking" across different DML statements
        elem_alias_map = {}  # elem_idx -> {table_upper -> alias}
        import re as _re
        for idx, elem in enumerate(self._all_elements):
            alias_map = {}
            # Extract aliases from joins
            for join in elem.joins:
                if join.left_alias and join.left_table:
                    alias_map[join.left_table.upper()] = join.left_alias
                if join.right_alias and join.right_table:
                    alias_map[join.right_table.upper()] = join.right_alias
            # Extract aliases from subqueries
            for subq in elem.subqueries:
                if hasattr(subq, 'alias') and subq.alias and hasattr(subq, 'source_tables'):
                    for st in (subq.source_tables or []):
                        alias_map[st.upper()] = subq.alias
            # Extract aliases from raw SQL (FROM table alias, JOIN table alias)
            if elem.raw_sql:
                for match in _re.finditer(
                    r'\bFROM\s+([A-Za-z_][A-Za-z0-9_]*(?:\.[A-Za-z_][A-Za-z0-9_]*)*)(?:\s+(?:AS\s+)?([A-Z][A-Za-z0-9_]*))?',
                    elem.raw_sql, _re.IGNORECASE
                ):
                    tbl = match.group(1)
                    alias = match.group(2)
                    if alias and tbl and alias.upper() not in ('WHERE', 'SET', 'ON', 'AND', 'OR', 'INTO', 'JOIN', 'LEFT', 'RIGHT', 'INNER', 'OUTER', 'CROSS', 'FULL', 'SELECT', 'INSERT', 'UPDATE', 'DELETE', 'VALUES', 'GROUP', 'ORDER', 'HAVING', 'UNION', 'ALL', 'AS', 'WITH', 'DATA', 'VOLATILE', 'MULTISET'):
                        alias_map[tbl.upper()] = alias
            elem_alias_map[idx] = alias_map
        # Also build a global fallback for edges that don't match any element
        table_to_alias = {}
        for idx in sorted(elem_alias_map.keys()):
            table_to_alias.update(elem_alias_map[idx])

        # Extract sub-query source tables from WHERE clauses and element subqueries
        subquery_source_tables = set()
        import re as _re
        for elem in self._all_elements:
            # From structured subquery objects in element catalog
            for subq in elem.subqueries:
                if subq.context in ('WHERE', 'IN', 'EXISTS') and subq.source_tables:
                    for st in subq.source_tables:
                        subquery_source_tables.add(st)
                    if subq.alias:
                        for st in subq.source_tables:
                            table_to_alias[st.upper()] = subq.alias
            # From WHERE clause SQL text (regex fallback)
            if elem.where_clause and elem.where_clause.sql_text:
                for match in _re.finditer(
                    r'\bSELECT\b[^)]*?\bFROM\s+([A-Za-z_][A-Za-z0-9_]*(?:\.[A-Za-z_][A-Za-z0-9_]*)*)(?:\s+(?:AS\s+)?([A-Za-z_]\w*))?',
                    elem.where_clause.sql_text, _re.IGNORECASE
                ):
                    subq_table = match.group(1)
                    subq_alias = match.group(2) or ""
                    subquery_source_tables.add(subq_table)
                    if subq_alias and subq_table:
                        table_to_alias[subq_table.upper()] = subq_alias

        # Build subquery alias -> SQL map from all element catalogs
        # Used to populate subquery_sql on column mappings
        alias_to_subquery_sql = {}  # (target_table, alias_upper) -> query_sql
        for elem in self._all_elements:
            for subq in elem.subqueries:
                if subq.alias and subq.query_sql:
                    key = (elem.target_table or "", subq.alias.upper())
                    alias_to_subquery_sql[key] = subq.query_sql

        # Build column mappings with English explanations + sequence/operator/IDs
        column_mappings = []
        if self.lineage:
            # Track how many edges we've assigned per target to handle multiple
            # DML statements targeting the same table (e.g., DELETE then INSERT)
            target_edge_counter = {}  # target_table -> count of edges seen

            for edge in self.lineage.edges:
                # Generate English explanation for the transformation
                explanation = self.explainer.explain_transformation(
                    edge.transformation.sql_expression
                )

                # Match edge to element catalog for sequence/operator/IDs
                edge_target = edge.target.table_name or ""
                edge_dml = getattr(edge, 'dml_operation', '') or ''
                matched_seq = None
                matched_op = edge_dml
                matched_join_ids = []
                matched_filter_ids = []
                matched_idx = None

                # Try to find the matching element catalog
                elem_indices = target_to_elems.get(edge_target, [])
                if elem_indices:
                    matched_idx = None

                    # Direct match via statement_id tag (e.g. "elem_3" → index 3)
                    edge_stmt_id = getattr(edge, 'statement_id', None) or ''
                    if edge_stmt_id.startswith('elem_'):
                        try:
                            tagged_idx = int(edge_stmt_id.split('_', 1)[1])
                            if tagged_idx < len(self._all_elements):
                                matched_idx = tagged_idx
                        except (ValueError, IndexError):
                            pass

                    # Fallback: heuristic matching by DML type + source table overlap
                    if matched_idx is None:
                        edge_source_tbl = (edge.source.table_name or "").upper()
                        dml_matched = [eidx for eidx in elem_indices
                                       if edge_dml and self._all_elements[eidx].statement_type == edge_dml]
                        if len(dml_matched) > 1 and edge_source_tbl:
                            for eidx in dml_matched:
                                elem = self._all_elements[eidx]
                                elem_src_upper = {s.upper() for s in (elem.source_tables or [])}
                                if edge_source_tbl in elem_src_upper:
                                    matched_idx = eidx
                                    break
                        if matched_idx is None and dml_matched:
                            matched_idx = dml_matched[0]
                        if matched_idx is None:
                            matched_idx = elem_indices[0]

                    matched_seq = dml_sequence_map.get(matched_idx)
                    matched_op = self._all_elements[matched_idx].statement_type
                    matched_join_ids = list(dict.fromkeys(elem_join_ids.get(matched_idx, [])))
                    # Add scalar subquery join IDs for this specific target column
                    tgt_col_upper = edge.target.column_name.upper() if edge.target.column_name else ""
                    sq_jids = scalar_join_map.get((matched_idx, tgt_col_upper), [])
                    for sjid in sq_jids:
                        if sjid not in matched_join_ids:
                            matched_join_ids.append(sjid)
                    matched_filter_ids = list(dict.fromkeys(elem_filter_ids.get(matched_idx, [])))

                # Look up group_by for matched element
                matched_group_by = ""
                if matched_idx is not None:
                    matched_group_by = elem_group_by.get(matched_idx, "")

                # Look up aliases for source and target tables (per-element to avoid alias leaking).
                # When the edge already has a subquery_alias (set by the lineage extractor
                # from the expression AST), prefer it for src_alias. This is critical when
                # the same physical table has multiple aliases (e.g., GM and GP both alias
                # LKLPSGLSTAGE) — the flat table->alias map only stores one.
                edge_sq_alias = getattr(edge, 'subquery_alias', '') or ''
                if matched_idx is not None and matched_idx in elem_alias_map:
                    local_aliases = elem_alias_map[matched_idx]
                    src_alias = local_aliases.get(edge.source.table_name.upper(), "")
                    tgt_alias = local_aliases.get(edge.target.table_name.upper(), "")
                else:
                    src_alias = table_to_alias.get(edge.source.table_name.upper(), "")
                    tgt_alias = table_to_alias.get(edge.target.table_name.upper(), "")
                # Override src_alias with edge's subquery_alias when it's more specific
                if edge_sq_alias and edge_sq_alias != src_alias:
                    src_alias = edge_sq_alias

                # For INSERT/DELETE, the target table is the DML destination — it has no alias.
                # The alias map may incorrectly map the target table to a source subquery alias
                # (e.g., RPTADJUSTMENTS -> B where B is a JOINed subquery reading from RPTADJUSTMENTS).
                if edge_dml in ('INSERT', 'DELETE') and tgt_alias:
                    tgt_alias = ""

                mapping = ColumnMappingRecord(
                    source_table=edge.source.table_name,
                    source_column=edge.source.column_name,
                    target_table=edge.target.table_name,
                    target_column=edge.target.column_name,
                    transformation_type=edge.transformation.type.value if hasattr(edge.transformation.type, 'value') else edge.transformation.type,
                    transformation_subtype=edge.transformation.subtype.value if hasattr(edge.transformation.subtype, 'value') else edge.transformation.subtype,
                    transformation_sql=edge.transformation.sql_expression,
                    transformation_description=edge.transformation.description or "",
                    complexity_score=edge.transformation.complexity_score or 0,
                    english_explanation=explanation.english_explanation if explanation else "",
                    source_columns_involved=[
                        f"{c.table_name}.{c.column_name}"
                        for c in edge.transformation.source_columns
                    ],
                    dml_sequence=matched_seq,
                    operator_type=matched_op,
                    join_ids=matched_join_ids,
                    filter_ids=matched_filter_ids,
                    join_conditions_sql=edge.join_conditions or "",
                    where_conditions_sql=edge.where_conditions or "",
                    source_alias=src_alias,
                    target_alias=tgt_alias,
                    subquery_alias=getattr(edge, 'subquery_alias', '') or '',
                    union_type=getattr(edge, 'union_type', '') or '',
                    subquery_sql=alias_to_subquery_sql.get(
                        (edge_target, (getattr(edge, 'subquery_alias', '') or '').upper()), ""
                    ),
                    group_by=matched_group_by,
                )
                column_mappings.append(mapping)

        # Add rows for DML statements that produce no lineage edges (e.g., DELETE)
        # These still need to appear in the Column Lineage sheet with their sequence/operator
        edge_targets = {m.target_table for m in column_mappings}
        for idx, elem in enumerate(self._all_elements):
            if elem.statement_type in DML_TYPES and elem.statement_type != "INSERT":
                seq = dml_sequence_map.get(idx)
                if seq is None:
                    continue
                # Check if this element already produced edges
                tgt = elem.target_table or ""
                # For DELETE, check if any mapping row already has this seq number
                has_rows = any(m.dml_sequence == seq for m in column_mappings)
                if not has_rows:
                    # Build filter condition text from WHERE clause
                    where_text = ""
                    if elem.where_clause and hasattr(elem.where_clause, 'sql_text'):
                        where_text = elem.where_clause.sql_text or ""
                    filter_ids_for_elem = elem_filter_ids.get(idx, [])

                    mapping = ColumnMappingRecord(
                        source_table=tgt,
                        source_column="*",
                        target_table=tgt,
                        target_column="*",
                        transformation_type=elem.statement_type,
                        transformation_subtype="",
                        transformation_sql=elem.raw_sql if hasattr(elem, 'raw_sql') else "",
                        english_explanation=f"{elem.statement_type} all rows from {tgt}" + (f" where {where_text}" if where_text else ""),
                        source_columns_involved=[],
                        dml_sequence=seq,
                        operator_type=elem.statement_type,
                        join_ids=[],
                        filter_ids=filter_ids_for_elem,
                        source_alias="",
                        target_alias="",
                    )
                    column_mappings.append(mapping)

        # Sort column mappings by DML sequence so DELETE appears before its INSERT
        column_mappings.sort(key=lambda m: (m.dml_sequence or 999999, 0 if m.operator_type == 'DELETE' else 1))

        # --- Subquery Decomposition ---
        # Run the SubqueryDecomposer on each element's raw_sql to produce
        # per-level intermediate mapping rows for nested subqueries.
        decomposer = SubqueryDecomposer(dialect="teradata")
        decomposed_rows = []
        decomposed_elem_indices = set()  # Track elements that produced decomposed rows
        for idx, elem in enumerate(self._all_elements):
            if not elem.raw_sql or elem.statement_type not in DML_TYPES:
                continue
            dml_seq = dml_sequence_map.get(idx)
            tgt = elem.target_table or ""
            if not tgt:
                continue
            try:
                extra_rows = decomposer.decompose_from_raw_sql(
                    elem.raw_sql, tgt, dml_seq, elem.statement_type
                )
                if extra_rows:
                    decomposed_rows.extend(extra_rows)
                    decomposed_elem_indices.add(idx)
            except Exception as e:
                print(f"  WARNING: SubqueryDecomposer failed for element {idx}: {e}")

        # For elements with subquery decomposition, clear union_type on base
        # rows (UNION info belongs in decomposition rows, not at parent level).
        # However, preserve join_ids and filter_ids on base rows — these come
        # from the outer-level joins/filters extracted by the element parser
        # (e.g. CROSS JOIN between two FROM tables). The decomposed rows
        # independently get their own inner join/filter IDs via Pass 3 below.
        if decomposed_elem_indices:
            for m in column_mappings:
                if m.is_subquery_decomposition:
                    continue
                if m.dml_sequence is None:
                    continue
                for eidx in decomposed_elem_indices:
                    if dml_sequence_map.get(eidx) == m.dml_sequence:
                        m.union_type = ""
                        break

        # Append decomposed rows after the base rows
        if decomposed_rows:
            # --- Disambiguate subquery aliases reused across different DML statements ---
            # e.g., alias "A" used in both INSERT INTO X and INSERT INTO Y
            # becomes "A_1" for X and "A_2" for Y.
            # Scans ALL decomposed rows (any hop level), not just hops=1.
            import re as _re_disambig

            # Collect every alias that appears as source or target in decomposed rows,
            # grouped by dml_sequence. An alias is "ambiguous" if it appears under
            # multiple dml_sequences that ultimately target different physical tables.
            alias_dml_targets = {}  # alias -> {dml_seq: final_target}

            # First, build a dml_seq -> final_target map from hops=1 rows
            seq_to_final = {}
            for dr in decomposed_rows:
                if dr.hops == 1 and dr.target_table:
                    seq_to_final[dr.dml_sequence] = dr.target_table

            # Now scan all aliases at every hop level
            for dr in decomposed_rows:
                seq = dr.dml_sequence
                final_tgt = seq_to_final.get(seq, "")
                if not final_tgt:
                    continue
                # Check source_table as a potential alias (skip physical tables with ".")
                src = dr.source_table or ""
                if src and "." not in src and src not in ("*",):
                    if src not in alias_dml_targets:
                        alias_dml_targets[src] = {}
                    alias_dml_targets[src][seq] = final_tgt
                # Check target_table as a potential alias
                tgt = dr.target_table or ""
                if tgt and "." not in tgt and tgt not in ("*",):
                    if tgt not in alias_dml_targets:
                        alias_dml_targets[tgt] = {}
                    alias_dml_targets[tgt][seq] = final_tgt

            # Find ambiguous aliases (same alias, different final targets)
            ambiguous_aliases = {}  # alias -> {dml_seq: suffix}
            for alias, seq_targets in alias_dml_targets.items():
                unique_targets = set(seq_targets.values())
                if len(unique_targets) > 1:
                    # Assign sequential suffixes per dml_sequence
                    sorted_seqs = sorted(seq_targets.keys())
                    for suffix_idx, seq in enumerate(sorted_seqs, 1):
                        if alias not in ambiguous_aliases:
                            ambiguous_aliases[alias] = {}
                        ambiguous_aliases[alias][seq] = suffix_idx

            # Apply disambiguation to decomposed rows
            if ambiguous_aliases:
                for dr in decomposed_rows:
                    seq = dr.dml_sequence
                    # Rename source_table if ambiguous
                    if dr.source_table in ambiguous_aliases:
                        suffix_map = ambiguous_aliases[dr.source_table]
                        if seq in suffix_map:
                            old_alias = dr.source_table
                            new_alias = "{0}_{1}".format(old_alias, suffix_map[seq])
                            dr.source_table = new_alias
                            if dr.source_alias == old_alias:
                                dr.source_alias = new_alias
                            if dr.source_subquery_relation == old_alias:
                                dr.source_subquery_relation = new_alias
                            if dr.subquery_alias == old_alias:
                                dr.subquery_alias = new_alias
                    # Rename target_table if ambiguous (for child rows targeting this alias)
                    if dr.target_table in ambiguous_aliases:
                        suffix_map = ambiguous_aliases[dr.target_table]
                        if seq in suffix_map:
                            old_alias = dr.target_table
                            new_alias = "{0}_{1}".format(old_alias, suffix_map[seq])
                            dr.target_table = new_alias
                            if dr.target_alias == old_alias:
                                dr.target_alias = new_alias
                            if dr.target_subquery_relation == old_alias:
                                dr.target_subquery_relation = new_alias
                    # Update hop_detail string
                    if dr.hop_detail:
                        for amb_alias, suffix_map in ambiguous_aliases.items():
                            if seq in suffix_map and amb_alias in dr.hop_detail:
                                new_alias = "{0}_{1}".format(amb_alias, suffix_map[seq])
                                # Replace whole-word only
                                dr.hop_detail = _re_disambig.sub(
                                    r'\b' + _re_disambig.escape(amb_alias) + r'\b',
                                    new_alias, dr.hop_detail
                                )

            # Build outermost alias map from hops=1 rows BEFORE filtering them out.
            # Keyed by (target_table, dml_sequence) so aliases from one DML
            # statement don't leak into another targeting the same table.
            outermost_alias_map = {}  # (target_table, dml_seq) -> outermost subquery alias
            for dr in decomposed_rows:
                if dr.target_subquery_relation and dr.target_table:
                    key = (dr.target_table, dr.dml_sequence)
                    if dr.hops == 1 and dr.source_subquery_relation:
                        if key not in outermost_alias_map:
                            outermost_alias_map[key] = dr.source_subquery_relation

            # Build set of physical tables that are leaf sources INSIDE subqueries
            # for each (target, dml_sequence). Only these should be replaced.
            subquery_inner_sources = {}  # (target_table, dml_seq) -> set of physical source tables
            for dr in decomposed_rows:
                if not dr.is_subquery_decomposition:
                    continue
                tgt = dr.target_table or ""
                # Find the final target from hops=1 rows
                final_tgt = None
                for dr2 in decomposed_rows:
                    if dr2.hops == 1 and dr2.dml_sequence == dr.dml_sequence and dr2.target_table:
                        final_tgt = dr2.target_table
                        break
                if not final_tgt:
                    continue
                src = dr.source_table or ""
                if src and "." in src:
                    key = (final_tgt, dr.dml_sequence)
                    if key not in subquery_inner_sources:
                        subquery_inner_sources[key] = set()
                    subquery_inner_sources[key].add(src)

            # Remove hops=1 rows (outermost subquery -> target) since the base
            # lineage rows already cover that mapping with full transformations.
            decomposed_rows = [dr for dr in decomposed_rows if dr.hops != 1]

            column_mappings.extend(decomposed_rows)

            # Propagate alias disambiguation to base (non-decomposed) rows.
            # When E is disambiguated to E_1 / E_2 in decomposed rows,
            # the base rows' subquery_alias and source_alias should match.
            if ambiguous_aliases:
                for m in column_mappings:
                    if m.is_subquery_decomposition:
                        continue
                    seq = m.dml_sequence
                    sq = m.subquery_alias or ""
                    if sq in ambiguous_aliases:
                        suffix_map = ambiguous_aliases[sq]
                        if seq in suffix_map:
                            new_alias = "{0}_{1}".format(sq, suffix_map[seq])
                            m.subquery_alias = new_alias
                            if m.source_alias == sq:
                                m.source_alias = new_alias

            for m in column_mappings:
                if m.is_subquery_decomposition:
                    continue
                tgt = m.target_table or ""
                seq = m.dml_sequence
                key = (tgt, seq)
                if key in outermost_alias_map:
                    alias = outermost_alias_map[key]
                    # Replace physical source tables that exist INSIDE a subquery
                    # with the outermost subquery alias. For UNION-derived tables,
                    # multiple physical sources (CUR, HIST) collapse to the same
                    # alias — duplicates are removed below.
                    # Guard: when the mapping already has a subquery_alias that
                    # differs from the outermost alias, the source belongs to a
                    # different JOINed subquery and must NOT be replaced.
                    # (e.g., FROM (... ) A JOIN (... ) B — source from B should
                    #  not be overwritten with alias A.)
                    if m.source_table and "." in m.source_table:
                        inner_sources = subquery_inner_sources.get(key, set())
                        if m.source_table in inner_sources:
                            m_sq_alias = (m.subquery_alias or "").upper()
                            alias_upper = alias.upper() if alias else ""
                            if not m_sq_alias or m_sq_alias == alias_upper:
                                m.source_table = alias
                                m.source_alias = alias

            # Deduplicate base rows that became identical after alias collapse.
            # This happens with UNION-derived tables: edges from CUR and HIST
            # both collapse to alias A_1, creating duplicate base rows.
            seen_base_keys = set()
            deduped_mappings = []
            for m in column_mappings:
                if m.is_subquery_decomposition:
                    deduped_mappings.append(m)
                    continue
                key = (m.source_table or "", m.source_column or "",
                       m.target_table or "", m.target_column or "",
                       m.dml_sequence)
                if key in seen_base_keys:
                    continue
                seen_base_keys.add(key)
                deduped_mappings.append(m)
            column_mappings = deduped_mappings

        # Extract WHERE filters and JOIN conditions from decomposed row notes,
        # create FilterConditionDetail / JoinConditionDetail entries,
        # and assign filter_ids / join_ids back to all matching decomposed rows.
        import re as _re

        # --- Pass 1: Create FilterConditionDetail entries and build lookup ---
        seen_branch_filters = set()  # (dml_sequence, where_text) -> filter_id
        branch_filter_counter = len(filter_conditions)
        filter_id_lookup = {}  # (dml_sequence, where_text) -> filter_id

        for row in decomposed_rows:
            if not row.notes:
                continue
            where_match = _re.search(r'WHERE:\s*(.+?)(?:;\s*(?:JOIN:|GROUP BY:)|$)', row.notes)
            if not where_match:
                continue
            where_text = where_match.group(1).strip()
            if not where_text:
                continue
            # Include source_table so each union branch gets its own
            # filter entry even when the WHERE text is identical.
            dedup_key = (row.dml_sequence, row.source_table or "", where_text)
            if dedup_key in seen_branch_filters:
                continue
            seen_branch_filters.add(dedup_key)

            branch_filter_counter += 1
            filter_id = "WHERE_{0:03d}".format(branch_filter_counter)
            filter_id_lookup[dedup_key] = filter_id

            col_refs = []
            for col_match in _re.finditer(r'\b([A-Z][A-Z0-9_]*\.[A-Z][A-Z0-9_]*)\b', where_text, _re.IGNORECASE):
                parts = col_match.group(1).split('.')
                if len(parts) == 2:
                    col_refs.append(ColumnRef(table_name=parts[0], column_name=parts[1]))
            clean_text = _re.sub(r"'[^']*'", '', where_text)
            for col_match in _re.finditer(r'\b([A-Z][A-Z_][A-Z0-9_]*)\b', clean_text, _re.IGNORECASE):
                name = col_match.group(1)
                if name.upper() not in ('AND', 'OR', 'NOT', 'IN', 'IS', 'NULL', 'BETWEEN', 'LIKE',
                                         'SELECT', 'FROM', 'WHERE', 'CURRENT', 'TYPE'):
                    if not any(c.column_name == name for c in col_refs):
                        col_refs.append(ColumnRef(table_name="", column_name=name))

            branch_alias = row.subquery_alias or ""
            branch_num = ""
            if "_" in branch_alias:
                branch_num = branch_alias.rsplit("_", 1)[-1]
            explanation = "Branch {0} filter".format(branch_num) if branch_num else "Subquery filter"
            if row.target_table:
                tgt_short = row.target_table.split(".")[-1] if "." in row.target_table else row.target_table
                explanation += " for {0} UNION".format(tgt_short)

            detail = FilterConditionDetail(
                filter_id=filter_id,
                filter_type="WHERE",
                sql_expression=where_text,
                columns_referenced=col_refs,
                english_explanation=explanation,
                applies_to_table=row.target_table,
                dml_sequence=row.dml_sequence,
                source_table=row.source_table
            )
            filter_conditions.append(detail)

        # --- Pass 2: Create JoinConditionDetail entries from decomposed row notes ---
        # Sort by hops ascending so outer-level joins get lower IDs,
        # matching the top-down hierarchy order.
        seen_branch_joins = set()  # (dml_sequence, join_text) -> join_id
        branch_join_counter = len(join_conditions)
        join_id_lookup = {}  # (dml_sequence, join_text) -> join_id

        for row in sorted(decomposed_rows, key=lambda r: (r.dml_sequence or 0, r.hops or 0)):
            if not row.notes:
                continue
            join_match = _re.search(r'JOIN:\s*(.+?)(?:;\s*(?:WHERE:|GROUP BY:)|$)', row.notes)
            if not join_match:
                continue
            join_text = join_match.group(1).strip()
            if not join_text:
                continue
            # Split multiple joins separated by "; "
            individual_joins = _re.split(r';\s*(?=(?:INNER|LEFT|RIGHT|FULL|CROSS)\s+JOIN)', join_text, flags=_re.IGNORECASE)
            for single_join in individual_joins:
                single_join = single_join.strip()
                # Strip spurious trailing " ON" from CROSS JOIN text
                single_join = _re.sub(r'\s+ON\s*$', '', single_join)
                if not single_join:
                    continue
                # Include source_table in the dedup key so that each
                # union branch (U3, U4, …) gets its own join entry even
                # when the join SQL text is identical across branches.
                dedup_key = (row.dml_sequence, row.source_table or "", single_join)
                if dedup_key in seen_branch_joins:
                    continue
                seen_branch_joins.add(dedup_key)

                branch_join_counter += 1
                join_id = "JOIN_{0:03d}".format(branch_join_counter)
                join_id_lookup[dedup_key] = join_id

                # Parse join type, right table, and ON condition.
                # Handle both ON-based joins and CROSS JOIN (no ON clause).
                jm = _re.match(
                    r'(INNER|LEFT|RIGHT|FULL|CROSS)\s+JOIN\s+(\S+?)(?:\s+(?:AS\s+)?(\S+))?\s+ON\s+(.*)',
                    single_join, _re.IGNORECASE | _re.DOTALL
                )
                if jm:
                    j_type = jm.group(1).upper()
                    j_right = jm.group(2)
                    j_right_alias = jm.group(3) or ""
                    j_on = jm.group(4).strip()
                else:
                    # Try CROSS JOIN (no ON clause)
                    cm = _re.match(
                        r'(CROSS)\s+JOIN\s+(\S+?)(?:\s+(?:AS\s+)?(\S+))?\s*$',
                        single_join, _re.IGNORECASE
                    )
                    if cm:
                        j_type = "CROSS"
                        j_right = cm.group(2)
                        j_right_alias = cm.group(3) or ""
                        j_on = ""
                    else:
                        j_type = "INNER"
                        j_right = single_join
                        j_right_alias = ""
                        j_on = ""

                left_cols = []
                right_cols = []
                for cmat in _re.finditer(r'\b([A-Z][A-Z0-9_]*\.[A-Z][A-Z0-9_]*)\b', j_on, _re.IGNORECASE):
                    parts = cmat.group(1).split('.')
                    if len(parts) == 2:
                        cr = ColumnRef(table_name=parts[0], column_name=parts[1])
                        if parts[0].upper() == j_right.split('.')[-1].upper() or parts[0].upper() == j_right_alias.upper():
                            right_cols.append(cr)
                        else:
                            left_cols.append(cr)

                # The left table of the join is the child subquery (one hop
                # deeper) — the source that participates in this join.
                # E.g. for CROSS JOIN at hops=2 (src=U3), the child at hops=3
                # has src=AF1_1, which represents the AF1 subquery in the SQL.
                join_left_table = row.source_table or ""
                child_hops_j = (row.hops or 0) + 1
                parent_src_j = row.source_table or ""
                for cr in decomposed_rows:
                    if (cr.dml_sequence == row.dml_sequence
                            and (cr.hops or 0) == child_hops_j
                            and cr.target_table == parent_src_j):
                        join_left_table = cr.source_table or join_left_table
                        break

                # Derive the SQL alias for the left table by stripping
                # the decomposer's _N suffix (e.g. AF1_1 -> AF1).
                raw_left_alias = join_left_table or row.source_table or ""
                if raw_left_alias and "_" in raw_left_alias:
                    base, suffix = raw_left_alias.rsplit("_", 1)
                    if suffix.isdigit():
                        raw_left_alias = base

                jd = JoinConditionDetail(
                    join_id=join_id,
                    join_type=j_type,
                    left_table=join_left_table,
                    right_table=j_right,
                    left_alias=raw_left_alias,
                    right_alias=j_right_alias,
                    on_condition_sql=j_on,
                    columns_left=left_cols,
                    columns_right=right_cols,
                    english_explanation="Subquery {0} joins {1} on {2}".format(
                        row.subquery_alias or row.target_table, j_right, j_on[:80]
                    ),
                    dml_sequence=row.dml_sequence,
                )
                join_conditions.append(jd)

        # --- Pass 3: Assign filter_ids and join_ids back to decomposed rows ---
        # Join IDs are assigned to SOURCE rows (one hop deeper), not the
        # RESULT row that contains the JOIN note. E.g. if U3 (hops=2) has
        # "JOIN: CROSS JOIN CONSL_STRT_DT", the join ID goes to AF1_1 (hops=3),
        # because AF1_1 is the table that PARTICIPATES in that join.
        for row in decomposed_rows:
            if not row.notes:
                continue
            # Assign filter_ids to CHILD rows (hops + 1) where the union block
            # is the target table, not to this row where it's the source.
            # For leaf rows (deepest level with no children), fall back to
            # assigning the filter to the row itself.
            where_match = _re.search(r'WHERE:\s*(.+?)(?:;\s*(?:JOIN:|GROUP BY:)|$)', row.notes)
            if where_match:
                where_text = where_match.group(1).strip()
                if where_text:
                    fkey = (row.dml_sequence, row.source_table or "", where_text)
                    fid = filter_id_lookup.get(fkey)
                    if fid:
                        child_hops_f = (row.hops or 0) + 1
                        parent_src_f = row.source_table or ""
                        assigned_any = False
                        for child_row in decomposed_rows:
                            if (child_row.dml_sequence == row.dml_sequence
                                    and (child_row.hops or 0) == child_hops_f
                                    and child_row.target_table == parent_src_f
                                    and fid not in child_row.filter_ids):
                                child_row.filter_ids.append(fid)
                                assigned_any = True
                        # If no child rows found (leaf level), assign to this row itself
                        if not assigned_any and fid not in row.filter_ids:
                            row.filter_ids.append(fid)
            # Assign join_ids to CHILD rows (hops + 1) instead of this row
            join_match = _re.search(r'JOIN:\s*(.+?)(?:;\s*(?:WHERE:|GROUP BY:)|$)', row.notes)
            if join_match:
                join_text = join_match.group(1).strip()
                if join_text:
                    individual_joins = _re.split(r';\s*(?=(?:INNER|LEFT|RIGHT|FULL|CROSS)\s+JOIN)', join_text, flags=_re.IGNORECASE)
                    for single_join in individual_joins:
                        single_join = single_join.strip()
                        # Strip spurious trailing " ON" (must match Pass 2)
                        single_join = _re.sub(r'\s+ON\s*$', '', single_join)
                        if not single_join:
                            continue
                        jkey = (row.dml_sequence, row.source_table or "", single_join)
                        jid = join_id_lookup.get(jkey)
                        if not jid:
                            continue
                        # Find child rows: same dml_sequence, hops = row.hops + 1,
                        # AND target_table matches this row's source_table (parent-child link).
                        # E.g. if row is (tgt=AF2, src=U3, hops=2), children are
                        # rows with (tgt=U3, src=AF1_1, hops=3).
                        child_hops = (row.hops or 0) + 1
                        parent_src = row.source_table or ""
                        for child_row in decomposed_rows:
                            if (child_row.dml_sequence == row.dml_sequence
                                    and (child_row.hops or 0) == child_hops
                                    and child_row.target_table == parent_src
                                    and jid not in child_row.join_ids):
                                child_row.join_ids.append(jid)

        # Also set hops=0 for original (non-decomposed) rows
        for m in column_mappings:
            if not m.is_subquery_decomposition and m.hops is None:
                m.hops = 0

        # Add sub-query source tables (from WHERE clauses) to the source_tables list
        source_tables_set.update(subquery_source_tables)

        # Build table alias details
        table_aliases = self._build_table_alias_details(column_mappings)

        # Compute graph stats for metadata
        all_tables = set()
        all_columns = set()
        for m in column_mappings:
            if m.source_table:
                all_tables.add(m.source_table.upper())
            if m.target_table:
                all_tables.add(m.target_table.upper())
            if m.source_table and m.source_column:
                all_columns.add((m.source_table.upper(), m.source_column.upper()))
            if m.target_table and m.target_column:
                all_columns.add((m.target_table.upper(), m.target_column.upper()))

        # Create metadata
        metadata = LineageOutputMetadata(
            target_table=target_tables[0] if target_tables else "",
            target_tables=target_tables,
            target_schema=target_tables[0].split('.')[0] if target_tables and '.' in target_tables[0] else None,
            source_tables=source_tables,
            statement_type=statement_type,
            total_column_mappings=len(column_mappings),
            total_join_conditions=len(join_conditions),
            total_filter_conditions=len(filter_conditions),
            source_file=source_file,
            generated_timestamp=datetime.now().isoformat(),
            dialect="teradata",
            edge_count=len(column_mappings),
            table_count=len(all_tables),
            column_count=len(all_columns),
        )

        # Build subqueries list from all element catalogs
        subquery_details = []
        subq_counter = 0
        for idx, elem in enumerate(self._all_elements):
            dml_seq = dml_sequence_map.get(idx)
            for subq in elem.subqueries:
                subq_counter += 1
                subquery_details.append(SubqueryDetail(
                    subquery_id=f"SUBQ_{subq_counter:03d}",
                    alias=subq.alias or "",
                    context=subq.context or "",
                    source_tables=list(subq.source_tables) if subq.source_tables else [],
                    query_sql=subq.query_sql or "",
                    dml_sequence=dml_seq,
                    target_table=elem.target_table
                ))

        return StructuredLineageOutput(
            metadata=metadata,
            column_mappings=column_mappings,
            join_conditions=join_conditions,
            filter_conditions=filter_conditions,
            table_aliases=table_aliases,
            subqueries=subquery_details
        )

    def _build_join_condition_details(self) -> List[JoinConditionDetail]:
        """Build detailed join conditions (without index tracking)."""
        details, _, _ = self._build_join_condition_details_indexed()
        return details

    def _build_join_condition_details_indexed(self, dml_sequence_map: Dict = None):
        """
        Build detailed join conditions with English explanations.
        Aggregates joins from all element catalogs.

        Args:
            dml_sequence_map: Optional mapping of element index -> DML sequence number

        Returns:
            Tuple of (List[JoinConditionDetail], Dict[int, List[str]])
            where the dict maps element catalog index -> list of join IDs
        """
        join_details = []
        elem_join_ids = {}  # elem index -> list of join IDs from that elem
        join_counter = 0
        dml_sequence_map = dml_sequence_map or {}
        # Deduplication: (join_type, right_table, on_condition, dml_seq) -> existing join_id
        seen_joins = {}

        for idx, elem in enumerate(self._all_elements):
            if not elem.joins:
                continue

            dml_seq = dml_sequence_map.get(idx)

            for join in elem.joins:
                # Deduplicate by join signature within same DML sequence
                right_tbl = join.right_table or ""
                # Normalize right table for dedup (strip subquery prefixes)
                right_tbl_short = right_tbl.split(".")[-1] if "." in right_tbl else right_tbl
                on_cond = join.predicate_sql or ""
                dedup_key = (join.join_type, right_tbl_short, on_cond, dml_seq)

                if dedup_key in seen_joins:
                    # Reuse existing join ID
                    existing_id = seen_joins[dedup_key]
                    if idx not in elem_join_ids:
                        elem_join_ids[idx] = []
                    elem_join_ids[idx].append(existing_id)
                    continue

                join_counter += 1
                join_id = f"JOIN_{join_counter:03d}"
                seen_joins[dedup_key] = join_id

                explanation = self.explainer.explain_join_condition(
                    join.join_type,
                    join.left_table or "",
                    join.right_table or "",
                    join.predicate_sql or ""
                )

                columns_left = []
                columns_right = []
                for cond in join.conditions:
                    if cond.left_column:
                        columns_left.append(cond.left_column)
                    if cond.right_column:
                        columns_right.append(cond.right_column)

                detail = JoinConditionDetail(
                    join_id=join_id,
                    join_type=join.join_type,
                    left_table=join.left_table or "",
                    right_table=join.right_table or "",
                    left_alias=join.left_alias,
                    right_alias=join.right_alias,
                    on_condition_sql=join.predicate_sql or "",
                    columns_left=columns_left,
                    columns_right=columns_right,
                    english_explanation=explanation,
                    dml_sequence=dml_seq
                )
                join_details.append(detail)

                if idx not in elem_join_ids:
                    elem_join_ids[idx] = []
                elem_join_ids[idx].append(join_id)

        # --- Extract scalar subquery joins (e.g. GL1 INNER JOIN GLS inside CASE/COALESCE) ---
        scalar_join_map = {}  # (elem_idx, target_column_upper) -> [join_ids]
        sq_join_extractor = JoinExtractor(dialect="teradata")

        for idx, elem in enumerate(self._all_elements):
            if not elem.raw_sql:
                continue
            dml_seq = dml_sequence_map.get(idx)
            try:
                parsed = sqlglot.parse(elem.raw_sql, read="teradata")
                if not parsed:
                    continue
                ast = parsed[0]

                # Build SELECT-alias → INSERT-column mapping for INSERT statements
                # e.g. GLCOMPANY (SELECT alias) → GL_COMPANY (INSERT column)
                select_to_insert_col = {}
                if isinstance(ast, sqlglot.exp.Insert):
                    insert_cols = []
                    schema_node = ast.args.get("this")
                    if schema_node:
                        for expr in (schema_node.args.get("expressions") or []):
                            insert_cols.append(expr.name.upper() if hasattr(expr, 'name') else str(expr).upper())
                    inner_select = ast.find(sqlglot.exp.Select)
                    if inner_select:
                        select_exprs = inner_select.args.get("expressions") or []
                        for pos, sel_expr in enumerate(select_exprs):
                            sel_alias = ""
                            if isinstance(sel_expr, sqlglot.exp.Alias):
                                sel_alias = sel_expr.alias or ""
                            if sel_alias and pos < len(insert_cols):
                                select_to_insert_col[sel_alias.upper()] = insert_cols[pos]

                sq_joins = sq_join_extractor.extract_scalar_subquery_joins(ast)
                for join_info, col_aliases in sq_joins:
                    right_tbl = join_info.right_table or ""
                    right_tbl_short = right_tbl.split(".")[-1] if "." in right_tbl else right_tbl
                    left_tbl = join_info.left_table or ""
                    on_cond = join_info.predicate_sql or ""
                    # Include left_table to distinguish scalar subquery
                    # joins that share the same right table and ON
                    # condition but originate from different left tables
                    # (e.g. CATGRY1 vs LOC_CATGRY1).
                    dedup_key = (join_info.join_type, left_tbl, right_tbl_short, on_cond, dml_seq)

                    if dedup_key in seen_joins:
                        jid = seen_joins[dedup_key]
                    else:
                        join_counter += 1
                        jid = f"JOIN_{join_counter:03d}"
                        seen_joins[dedup_key] = jid

                        explanation = self.explainer.explain_join_condition(
                            join_info.join_type,
                            join_info.left_table or "",
                            join_info.right_table or "",
                            join_info.predicate_sql or ""
                        )

                        columns_left = []
                        columns_right = []
                        for cond in join_info.conditions:
                            if cond.left_column:
                                columns_left.append(cond.left_column)
                            if cond.right_column:
                                columns_right.append(cond.right_column)

                        detail = JoinConditionDetail(
                            join_id=jid,
                            join_type=join_info.join_type,
                            left_table=join_info.left_table or "",
                            right_table=join_info.right_table or "",
                            left_alias=join_info.left_alias,
                            right_alias=join_info.right_alias,
                            on_condition_sql=join_info.predicate_sql or "",
                            columns_left=columns_left,
                            columns_right=columns_right,
                            english_explanation=f"Scalar subquery join: {explanation}",
                            dml_sequence=dml_seq
                        )
                        join_details.append(detail)

                    # Map this join ID to ALL target columns that use it
                    for col_alias in col_aliases:
                        # Map SELECT alias to INSERT column name if available
                        tgt_col = select_to_insert_col.get(col_alias.upper(), col_alias.upper())
                        key = (idx, tgt_col)
                        if key not in scalar_join_map:
                            scalar_join_map[key] = []
                        if jid not in scalar_join_map[key]:
                            scalar_join_map[key].append(jid)
            except Exception:
                continue

        return join_details, elem_join_ids, scalar_join_map

    def _build_filter_condition_details(self) -> List[FilterConditionDetail]:
        """Build detailed filter conditions (without index tracking)."""
        details, _ = self._build_filter_condition_details_indexed()
        return details

    def _build_filter_condition_details_indexed(self, dml_sequence_map: Dict = None):
        """
        Build detailed filter conditions with English explanations.
        Aggregates WHERE clauses from all element catalogs.

        Args:
            dml_sequence_map: Optional mapping of element index -> DML sequence number

        Returns:
            Tuple of (List[FilterConditionDetail], Dict[int, List[str]])
            where the dict maps element catalog index -> list of filter IDs
        """
        filter_details = []
        elem_filter_ids = {}  # elem index -> list of filter IDs
        seen_sql = set()
        where_counter = 0
        cond_counter = 0
        dml_sequence_map = dml_sequence_map or {}

        for idx, elem in enumerate(self._all_elements):
            if not elem.where_clause:
                continue

            where = elem.where_clause
            dml_seq = dml_sequence_map.get(idx)
            # Primary source table(s) for this statement
            source_tbl = ', '.join(elem.source_tables) if elem.source_tables else None

            # Deduplicate by SQL text
            if where.sql_text in seen_sql:
                # Still map this element to the existing filter ID
                for prev_idx, prev_ids in elem_filter_ids.items():
                    prev_elem = self._all_elements[prev_idx]
                    if prev_elem.where_clause and prev_elem.where_clause.sql_text == where.sql_text:
                        elem_filter_ids[idx] = list(prev_ids)
                        break
                continue
            seen_sql.add(where.sql_text)

            where_counter += 1
            filter_id = f"WHERE_{where_counter:03d}"

            # Strip leading "WHERE " prefix for clean SQL expression
            import re as _re
            clean_sql = where.sql_text
            # Handle concatenated WHERE clauses (from multi-UNION extraction)
            # Split on "; WHERE " and take the first unique clause
            if '; WHERE ' in clean_sql:
                parts = [p.strip() for p in clean_sql.split('; WHERE ')]
                # Deduplicate parts
                seen_parts = []
                for p in parts:
                    p_clean = _re.sub(r'^\s*WHERE\s+', '', p, flags=_re.IGNORECASE).strip()
                    if p_clean not in seen_parts:
                        seen_parts.append(p_clean)
                clean_sql = seen_parts[0] if seen_parts else clean_sql
            clean_sql = _re.sub(r'^\s*WHERE\s+', '', clean_sql, flags=_re.IGNORECASE).strip()

            explanation = self.explainer.explain_filter_condition(clean_sql)

            # Extract columns from the cleaned main WHERE text only,
            # NOT from nested scalar subqueries whose columns leak via
            # where.get_all_columns().  Strip any (SELECT ...) blocks
            # first so only the outer WHERE column references remain.
            # Remove nested scalar subqueries and string literals
            # so only the outer WHERE column references remain.
            # Use a nested-paren-aware approach to strip subqueries properly.
            def _strip_subqueries(sql_text):
                """Strip (SELECT ...) blocks respecting nested parentheses."""
                result = []
                i = 0
                while i < len(sql_text):
                    # Look for "(SELECT" pattern
                    if (sql_text[i] == '(' and i + 7 < len(sql_text)
                            and sql_text[i+1:i+7].upper().startswith('SELECT')
                            or sql_text[i] == '(' and i + 4 < len(sql_text)
                            and sql_text[i+1:i+4].upper().startswith('SEL')
                            and _re.match(r'\(SEL(?:ECT)?\s', sql_text[i:], _re.IGNORECASE)):
                        # Skip the entire (SELECT ...) block
                        depth = 1
                        i += 1
                        while i < len(sql_text) and depth > 0:
                            if sql_text[i] == '(':
                                depth += 1
                            elif sql_text[i] == ')':
                                depth -= 1
                            i += 1
                    else:
                        result.append(sql_text[i])
                        i += 1
                return ''.join(result)

            main_where_sql = _strip_subqueries(clean_sql)
            main_where_sql = _re.sub(r"'[^']*'", '', main_where_sql)
            main_col_refs = []
            table_aliases_seen = set()
            for cmatch in _re.finditer(r'\b([A-Z][A-Z0-9_]*\.[A-Z][A-Z0-9_]*)\b', main_where_sql, _re.IGNORECASE):
                parts = cmatch.group(1).split('.')
                if len(parts) == 2:
                    table_aliases_seen.add(parts[0].upper())
                    cr = ColumnRef(table_name=parts[0], column_name=parts[1])
                    if cr not in main_col_refs:
                        main_col_refs.append(cr)
            # Also pick up bare column names (no table qualifier),
            # excluding SQL keywords, table aliases, and function names.
            _SQL_KW = {'AND', 'OR', 'NOT', 'IN', 'IS', 'NULL', 'BETWEEN', 'LIKE', 'EXISTS',
                        'WHERE', 'SELECT', 'FROM', 'CASE', 'WHEN', 'THEN', 'ELSE', 'END',
                        'AS', 'ON', 'TRUE', 'FALSE', 'CAST', 'TRIM', 'COALESCE', 'VARCHAR',
                        'INTEGER', 'INT', 'DATE', 'TIMESTAMP', 'CHAR', 'DECIMAL', 'CURRENT_DATE',
                        'EXTRACT', 'EXTRAC', 'YEAR', 'MONTH', 'DAY', 'HOUR', 'MINUTE', 'SECOND',
                        'MAX', 'MIN', 'SUM', 'COUNT', 'AVG', 'LENGTH', 'SUBSTR',
                        'SYS_CALENDAR', 'DBC', 'SYSLIB'}
            for cmatch in _re.finditer(r'(?<![.\w])([A-Z][A-Z0-9_]+)(?!\s*\()', main_where_sql, _re.IGNORECASE):
                name = cmatch.group(1)
                if (name.upper() not in _SQL_KW
                        and name.upper() not in table_aliases_seen
                        and not any(c.column_name.upper() == name.upper() for c in main_col_refs)):
                    main_col_refs.append(ColumnRef(table_name="", column_name=name))
            # Also scan the full WHERE text (including subqueries) for SP variable
            # references (V_*, Prev*, Period* etc.) that act as filter parameters.
            # These are meaningful even when inside subqueries.
            full_where_no_strings = _re.sub(r"'[^']*'", '', clean_sql)
            for cmatch in _re.finditer(r'(?<![.\w])([A-Z][A-Z0-9_]+)(?!\s*\()', full_where_no_strings, _re.IGNORECASE):
                name = cmatch.group(1)
                if (name.upper() not in _SQL_KW
                        and name.upper() not in table_aliases_seen
                        and not any(c.column_name.upper() == name.upper() for c in main_col_refs)):
                    main_col_refs.append(ColumnRef(table_name="", column_name=name))

            # Extract tables from EXISTS / NOT EXISTS subqueries.
            # These tables participate in row filtering but don't contribute
            # columns to the target — they should still be documented.
            # Search the FULL WHERE text (before '; WHERE ' dedup) so that
            # EXISTS tables from all UNION branches are captured.
            _exists_tables = []
            _full_where = where.sql_text or ""
            for _em in _re.finditer(
                r'(?:NOT\s+)?EXISTS\s*\(\s*SELECT\b.*?\bFROM\s+([\w.]+)',
                _full_where, _re.IGNORECASE | _re.DOTALL
            ):
                _et = _em.group(1).strip()
                if _et.upper() not in ('SELECT', 'SET', 'VALUES', 'TABLE'):
                    if _et not in _exists_tables:
                        _exists_tables.append(_et)

            detail = FilterConditionDetail(
                filter_id=filter_id,
                filter_type="WHERE",
                sql_expression=clean_sql,
                columns_referenced=main_col_refs if main_col_refs else where.get_all_columns(),
                english_explanation=explanation,
                applies_to_table=elem.target_table,
                dml_sequence=dml_seq,
                source_table=source_tbl,
                exists_tables=_exists_tables
            )
            filter_details.append(detail)

            if idx not in elem_filter_ids:
                elem_filter_ids[idx] = []
            elem_filter_ids[idx].append(filter_id)

        return filter_details, elem_filter_ids

    def _build_table_alias_details(self, column_mappings: List[ColumnMappingRecord]) -> List[TableAliasDetail]:
        """
        Build detailed table alias information.

        Extracts all table aliases used in the SQL, maps them to their full table names,
        and documents the columns used and transformations applied.

        Args:
            column_mappings: List of column mappings to extract alias information from

        Returns:
            List of TableAliasDetail objects
        """
        alias_details = []
        alias_map = {}  # alias -> {table_name, columns, transformations, join_context, role}

        # Extract aliases from joins across all element catalogs
        all_joins = []
        for elem in self._all_elements:
            if elem.joins:
                all_joins.extend(elem.joins)

        for join in all_joins:
                # Left table alias
                if join.left_alias:
                    if join.left_alias not in alias_map:
                        alias_map[join.left_alias] = {
                            'table_name': join.left_table,
                            'columns': set(),
                            'transformations': {},
                            'join_context': '',
                            'role': 'source'
                        }
                    # Add join context
                    join_desc = f"{join.join_type} JOIN with {join.right_table or join.right_alias}"
                    if join.predicate_sql:
                        join_desc += f" ON {join.predicate_sql[:100]}"
                    alias_map[join.left_alias]['join_context'] = join_desc

                # Right table alias
                if join.right_alias:
                    if join.right_alias not in alias_map:
                        alias_map[join.right_alias] = {
                            'table_name': join.right_table,
                            'columns': set(),
                            'transformations': {},
                            'join_context': '',
                            'role': 'source'
                        }
                    join_desc = f"{join.join_type} JOIN with {join.left_table or join.left_alias}"
                    if join.predicate_sql:
                        join_desc += f" ON {join.predicate_sql[:100]}"
                    alias_map[join.right_alias]['join_context'] = join_desc

        # Extract aliases from lineage edges
        if self.lineage:
            for edge in self.lineage.edges:
                src_table = edge.source.table_name or ""
                src_col = edge.source.column_name or ""
                tgt_table = edge.target.table_name or ""

                # Check if source table looks like an alias (short, uppercase, single letters or common patterns)
                potential_alias = self._extract_potential_alias(src_table)
                if potential_alias:
                    if potential_alias not in alias_map:
                        alias_map[potential_alias] = {
                            'table_name': src_table,
                            'columns': set(),
                            'transformations': {},
                            'join_context': '',
                            'role': 'source'
                        }
                    alias_map[potential_alias]['columns'].add(src_col)

                    # Record transformation
                    if edge.transformation and edge.transformation.sql_expression:
                        transform_str = edge.transformation.sql_expression[:200]
                        alias_map[potential_alias]['transformations'][src_col] = transform_str

        # Also check column mappings for alias patterns in source tables
        for mapping in column_mappings:
            src_table = mapping.source_table or ""
            potential_alias = self._extract_potential_alias(src_table)

            if potential_alias:
                if potential_alias not in alias_map:
                    alias_map[potential_alias] = {
                        'table_name': src_table,
                        'columns': set(),
                        'transformations': {},
                        'join_context': '',
                        'role': 'source'
                    }
                alias_map[potential_alias]['columns'].add(mapping.source_column)

                if mapping.transformation_sql:
                    alias_map[potential_alias]['transformations'][mapping.source_column] = mapping.transformation_sql[:200]

        # Build TableAliasDetail objects
        for alias, info in sorted(alias_map.items()):
            # Generate English explanation
            table_name = info['table_name']
            explanation = self._generate_alias_explanation(alias, table_name, info['role'])

            # Format column transformations
            col_transforms = {}
            for col, transform in info['transformations'].items():
                col_transforms[col] = transform

            detail = TableAliasDetail(
                alias=alias,
                full_table_name=table_name,
                english_explanation=explanation,
                columns_used=sorted(list(info['columns'])),
                column_transformations=col_transforms,
                join_context=info['join_context'],
                role_in_query=info['role']
            )
            alias_details.append(detail)

        return alias_details

    def _extract_potential_alias(self, table_ref: str) -> Optional[str]:
        """
        Extract potential alias from a table reference.

        Identifies common alias patterns like single letters (A, B, C),
        short abbreviations, or explicit alias references.

        Args:
            table_ref: Table reference string

        Returns:
            Alias string if identified, None otherwise
        """
        if not table_ref:
            return None

        # If it contains a dot, it might be schema.table, try to get table part
        if '.' in table_ref:
            parts = table_ref.split('.')
            table_ref = parts[-1]

        # Common alias patterns: single uppercase letters, 2-3 letter abbreviations
        # Check if it's a short identifier that looks like an alias
        if len(table_ref) <= 3 and table_ref.isupper():
            return table_ref

        # Check for common alias patterns with numbers (A1, T1, etc.)
        if len(table_ref) <= 3 and table_ref[0].isupper() and (len(table_ref) == 1 or table_ref[1:].isdigit()):
            return table_ref

        return None

    def _generate_alias_explanation(self, alias: str, table_name: str, role: str) -> str:
        """
        Generate English explanation for a table alias.

        Args:
            alias: The alias (e.g., A, B, C)
            table_name: Full table name
            role: Role in query (source, target, lookup)

        Returns:
            English explanation string
        """
        if not table_name or table_name == alias:
            return f"Alias '{alias}' refers to an unresolved table reference"

        # Extract meaningful table name parts
        clean_name = table_name.replace('_', ' ').replace('.', ' > ')

        role_desc = "source table" if role == "source" else "target table" if role == "target" else "lookup/reference table"

        return f"Alias '{alias}' represents the {role_desc} '{table_name}'. This table provides data for the transformation."

    def _write_table_aliases_sheet(self, ws, structured_output: StructuredLineageOutput) -> None:
        """
        Write table aliases sheet with alias documentation.

        Includes:
        - Alias identifier (A, B, C, etc.)
        - Full table name
        - English explanation
        - Columns used from this table
        - Transformations applied to columns
        - Join context
        """
        headers = [
            'Alias',
            'Full Table Name',
            'English Explanation',
            'Role in Query',
            'Join Context',
            'Columns Used',
            'Column Transformations'
        ]
        ws.append(headers)

        for alias_detail in structured_output.table_aliases:
            # Format columns used as comma-separated list
            columns_str = ', '.join(alias_detail.columns_used) if alias_detail.columns_used else 'N/A'

            # Format column transformations
            transforms_list = []
            for col, transform in alias_detail.column_transformations.items():
                transforms_list.append(f"{col}: {transform}")
            transforms_str = '\n'.join(transforms_list) if transforms_list else 'Direct mapping (no transformation)'

            ws.append([
                alias_detail.alias,
                alias_detail.full_table_name,
                alias_detail.english_explanation,
                alias_detail.role_in_query,
                alias_detail.join_context or 'Primary table / No join',
                columns_str,
                transforms_str
            ])

        # Add a note row if no aliases found
        if not structured_output.table_aliases:
            ws.append(['No table aliases detected in this SQL'])

    def _write_summary_sheet(self, ws, structured_output: StructuredLineageOutput) -> None:
        """Write summary sheet with metadata overview matching target format."""
        meta = structured_output.metadata

        # Extract procedure name from source file
        proc_name = ""
        if meta.source_file:
            import os
            proc_name = os.path.splitext(os.path.basename(meta.source_file))[0]

        # Count total DML statements
        total_statements = len(self._all_elements)

        # Count subqueries
        total_subqueries = sum(len(elem.subqueries) for elem in self._all_elements)

        # Collect all target tables, excluding SELECT INTO variable targets
        # (e.g. MSG_ERROR, STRT_DT are local variables, not tables)
        target_tables = []
        seen_targets = set()
        for elem in self._all_elements:
            tgt = elem.target_table
            if not tgt or tgt in seen_targets:
                continue
            # SELECT INTO local variables are not real tables
            if elem.statement_type in ("SELECT INTO",):
                continue
            seen_targets.add(tgt)
            target_tables.append(tgt)
        # Also include targets from column mappings (catches additional
        # targets that may not be in _all_elements)
        for cm in structured_output.column_mappings:
            tgt = cm.target_table
            if (tgt and tgt not in seen_targets
                    and not cm.is_subquery_decomposition
                    and cm.operator_type not in ("SELECT INTO",)):
                seen_targets.add(tgt)
                target_tables.append(tgt)
        # Include targets from control flow enclosed DML (e.g. PROCESS_LOG)
        for cf_tgt in sorted(getattr(self, '_cf_target_tables', set())):
            if cf_tgt not in seen_targets:
                seen_targets.add(cf_tgt)
                target_tables.append(cf_tgt)

        summary_data = [
            ("Source-to-Target Mapping Document", None),
            (None, None),
            ("Title", proc_name or meta.target_table),
            ("Source File", meta.source_file or "N/A"),
            ("Total Statements", str(total_statements)),
            ("Subqueries", f"~{total_subqueries}"),
            ("Total Joins", str(meta.total_join_conditions)),
            ("Total WHERE Clauses", str(meta.total_filter_conditions)),
            ("Control Flow Blocks", ""),  # Will be filled by control flow extraction
            ("Mapping Rows", f"~{meta.total_column_mappings}"),
            ("Target Tables", ", ".join(target_tables)),
        ]

        for row in summary_data:
            ws.append(row)

    def _write_column_lineage_sheet(self, ws, structured_output: StructuredLineageOutput) -> None:
        """Write column lineage sheet with all mappings including English explanations."""
        headers = [
            'Sequence', 'Operator Type',
            'Source Table', 'Source Alias', 'Source Column',
            'Target Table', 'Target Alias', 'Target Column',
            'Transformation Type', 'Transformation Subtype',
            'Transformation SQL', 'English Explanation',
            'All Source Columns Involved',
            'Join IDs', 'Filter IDs',
            'Group By',
            'Subquery Alias', 'Union Type',
            'Subquery SQL',
            'Hops', 'Hop Detail',
            'Source Subquery Relation', 'Target Subquery Relation',
            'Notes', 'Control Flow Context'
        ]
        ws.append(headers)

        for mapping in structured_output.column_mappings:
            ws.append([
                mapping.dml_sequence or "",
                mapping.operator_type,
                mapping.source_table,
                mapping.source_alias or "",
                mapping.source_column,
                mapping.target_table,
                mapping.target_alias or "",
                mapping.target_column,
                mapping.transformation_type,
                mapping.transformation_subtype,
                _restore_teradata_syntax(mapping.transformation_sql) if mapping.transformation_sql else "",
                _restore_teradata_syntax(mapping.english_explanation) if mapping.english_explanation else "",
                _restore_teradata_syntax('; '.join(mapping.source_columns_involved)) if mapping.source_columns_involved else "",
                ', '.join(mapping.join_ids) if mapping.join_ids else "",
                ', '.join(mapping.filter_ids) if mapping.filter_ids else "",
                mapping.group_by or "",
                mapping.subquery_alias or "",
                mapping.union_type or "",
                _restore_teradata_syntax(mapping.subquery_sql) if mapping.subquery_sql else "",
                mapping.hops if mapping.hops is not None else "",
                mapping.hop_detail or "",
                mapping.source_subquery_relation or "",
                mapping.target_subquery_relation or "",
                _restore_teradata_syntax(mapping.notes) if mapping.notes else "",
                mapping.control_flow_context or "",
            ])

    def _write_structured_joins_sheet(self, ws, structured_output: StructuredLineageOutput) -> None:
        """Write join conditions sheet matching target format."""
        headers = [
            'Join ID', 'Join Type',
            'Left Table', 'Left Alias',
            'Right Table', 'Right Alias',
            'Join SQL',
            'Applies To Sequence'
        ]
        ws.append(headers)

        for join in structured_output.join_conditions:
            # Ensure join type has "JOIN" suffix
            join_type = join.join_type or ""
            if join_type and "JOIN" not in join_type.upper():
                join_type = f"{join_type} JOIN"

            # Build full Join SQL clause
            join_sql = ""
            right_table = join.right_table or ""
            right_alias = join.right_alias or ""
            on_sql = join.on_condition_sql or ""

            if "CROSS" in join_type.upper():
                # For CROSS JOIN, include the subquery/table directly
                join_sql = f"{join_type} {right_table}"
                if right_alias and right_alias not in right_table:
                    join_sql += f" {right_alias}"
            else:
                join_sql = f"{join_type} {right_table}"
                if right_alias and right_alias not in right_table:
                    join_sql += f" {right_alias}"
                if on_sql:
                    join_sql += f" ON {on_sql}"

            # Applies To Sequence
            applies_to = str(join.dml_sequence) if hasattr(join, 'dml_sequence') and join.dml_sequence else ""

            ws.append([
                join.join_id,
                join_type,
                join.left_table,
                join.left_alias or "",
                join.right_table,
                join.right_alias or "",
                _restore_teradata_syntax(join_sql),
                applies_to
            ])

        if not structured_output.join_conditions:
            ws.append(["No join conditions found in this SQL statement."])

    def _write_structured_filters_sheet(self, ws, structured_output: StructuredLineageOutput) -> None:
        """Write filter conditions sheet matching target format."""
        headers = [
            'Filter ID', 'Filter Type',
            'SQL Expression',
            'Columns Referenced',
            'Applies To Sequence',
            'English Explanation',
            'EXISTS/NOT EXISTS Tables'
        ]
        ws.append(headers)

        for filter_cond in structured_output.filter_conditions:
            # Use simple column names without table prefix dots
            columns_str = '; '.join([
                c.column_name
                for c in filter_cond.columns_referenced
            ])
            # Applies To Sequence
            applies_to = str(filter_cond.dml_sequence) if filter_cond.dml_sequence else ""
            # EXISTS tables
            exists_str = '; '.join(filter_cond.exists_tables) if filter_cond.exists_tables else ""
            ws.append([
                filter_cond.filter_id,
                filter_cond.filter_type,
                _restore_teradata_syntax(filter_cond.sql_expression),
                columns_str,
                applies_to,
                filter_cond.english_explanation,
                exists_str
            ])

        if not structured_output.filter_conditions:
            ws.append(["No filter conditions found in this SQL statement."])

    def _write_subqueries_sheet(self, ws, structured_output: StructuredLineageOutput) -> None:
        """Write subqueries sheet with details about derived tables and sub-selects."""
        headers = [
            'Subquery ID', 'DML Sequence', 'Alias', 'Context',
            'Source Tables', 'Target Table', 'Subquery SQL'
        ]
        ws.append(headers)

        for subq in structured_output.subqueries:
            ws.append([
                subq.subquery_id,
                subq.dml_sequence,
                subq.alias or "",
                subq.context or "",
                '; '.join(subq.source_tables) if subq.source_tables else "",
                subq.target_table or "",
                subq.query_sql[:500] if subq.query_sql else ""
            ])

        if not structured_output.subqueries:
            ws.append(["No subqueries found in this SQL statement."])

    def _write_control_flow_sheet(self, ws, structured_output: StructuredLineageOutput,
                                   source_file: str = None) -> None:
        """Write control flow sheet matching target format."""
        headers = [
            'Control_Flow_Id', 'Type', 'Condition',
            'Line Range', 'Enclosed DML', 'Variables', 'Nesting Level'
        ]
        ws.append(headers)

        control_blocks = self._extract_control_flow_blocks(source_file)
        for block in control_blocks:
            ws.append([
                block.get('block_id', ''),
                block.get('block_type', ''),
                block.get('condition', ''),
                block.get('line_range', ''),
                block.get('enclosed_dml', ''),
                block.get('variables', ''),
                block.get('nesting_level', 0),
            ])

        if not control_blocks:
            ws.append(["No control flow blocks detected in this procedure."])

    def _write_control_flow_sheet_from_blocks(self, ws, control_blocks: List[Dict]) -> None:
        """Write control flow sheet from pre-extracted blocks."""
        headers = [
            'Control_Flow_Id', 'Type', 'Condition',
            'Line Range', 'Enclosed DML', 'Variables', 'Nesting Level'
        ]
        ws.append(headers)

        for block in control_blocks:
            ws.append([
                block.get('block_id', ''),
                block.get('block_type', ''),
                block.get('condition', ''),
                block.get('line_range', ''),
                block.get('enclosed_dml', ''),
                block.get('variables', ''),
                block.get('nesting_level', 0),
            ])

        if not control_blocks:
            ws.append(["No control flow blocks detected in this procedure."])

    def _extract_control_flow_blocks(self, source_file: str = None) -> List[Dict]:
        """
        Extract IF/ELSE/EXCEPTION control flow blocks from the stored procedure.

        Produces blocks with line ranges, enclosed DML, variables, and nesting level.
        """
        import re as _re
        blocks = []
        block_counter = 0

        # Read full source file
        all_sql = ""
        if source_file:
            try:
                with open(source_file, 'r', encoding='utf-8', errors='replace') as f:
                    all_sql = f.read()
            except Exception:
                pass

        if not all_sql:
            for elem in self._all_elements:
                if hasattr(elem, 'raw_sql') and elem.raw_sql:
                    all_sql += "\n" + elem.raw_sql

        if not all_sql:
            return blocks

        lines = all_sql.split('\n')

        # Find IF...THEN...END IF blocks with line ranges
        # Track the line numbers for each IF
        if_starts = []
        for i, line in enumerate(lines, 1):
            stripped = line.strip().upper()
            if _re.match(r'\bIF\b\s+', stripped):
                if_starts.append(i)

        # For each IF start, find the matching END IF
        for if_line in if_starts:
            # Extract condition from the IF line(s) up to THEN
            condition_lines = []
            j = if_line - 1  # 0-indexed
            found_then = False
            while j < len(lines):
                condition_lines.append(lines[j].strip())
                if 'THEN' in lines[j].upper():
                    found_then = True
                    break
                j += 1
            if not found_then:
                continue

            condition_text = ' '.join(condition_lines)
            # Extract just the condition between IF and THEN
            cond_match = _re.search(r'\bIF\s+(.+?)\s+THEN\b', condition_text, _re.IGNORECASE)
            if not cond_match:
                continue
            condition = cond_match.group(1).strip()
            condition = _re.sub(r'\s+', ' ', condition)

            # Find the END IF for this block
            nesting = 1
            end_line = if_line
            has_else = False
            for k in range(j + 1, len(lines)):
                stripped = lines[k].strip().upper()
                if _re.match(r'\bIF\b\s+', stripped):
                    nesting += 1
                if _re.match(r'\bEND\s+IF\b', stripped):
                    nesting -= 1
                    if nesting == 0:
                        end_line = k + 1  # 1-indexed
                        break
                if nesting == 1 and _re.match(r'\bELSE\b', stripped):
                    has_else = True

            # Extract enclosed DML statements — capture full statement text
            enclosed_dml = []
            block_text = '\n'.join(lines[if_line:end_line])
            for dml_match in _re.finditer(
                r'\b(INSERT\s+INTO|DELETE\s+FROM|SELECT\s+.+?\s+INTO)\s+',
                block_text, _re.IGNORECASE
            ):
                # Capture from the DML keyword to the next semicolon
                start = dml_match.start()
                rest = block_text[start:]
                semi_pos = rest.find(';')
                if semi_pos > 0:
                    stmt_text = rest[:semi_pos].strip()
                else:
                    stmt_text = rest.strip()
                # Normalise whitespace for compact display
                stmt_text = _re.sub(r'\s+', ' ', stmt_text)
                enclosed_dml.append(stmt_text)

            # Extract variables
            var_pattern = _re.compile(r'\b(V_\w+|VAR_\w+|WSQL\w+|MSG_\w+)\b', _re.IGNORECASE)
            variables = sorted(set(var_pattern.findall(condition)))

            block_counter += 1
            block_type = 'IF_ELSE' if has_else else 'IF'
            blocks.append({
                'block_id': f'CF-{block_counter}',
                'block_type': block_type,
                'condition': condition,
                'line_range': f'L{if_line}-L{end_line}',
                'enclosed_dml': ', '.join(enclosed_dml) if enclosed_dml else '',
                'variables': ', '.join(variables) if variables else None,
                'nesting_level': 0
            })

        # Find EXCEPTION HANDLER patterns
        handler_pattern = _re.compile(
            r'\bDECLARE\s+(EXIT|CONTINUE)\s+HANDLER\s+FOR\s+(\w+)\b',
            _re.IGNORECASE
        )
        for match in handler_pattern.finditer(all_sql):
            handler_type = match.group(1).upper()
            handler_for = match.group(2).upper()

            # Find line number of handler declaration
            handler_start = all_sql[:match.start()].count('\n') + 1

            # Find the handler body - look for BEGIN...END after handler declaration
            after_handler = all_sql[match.end():]
            begin_match = _re.search(r'\bBEGIN\b', after_handler, _re.IGNORECASE)
            handler_end = handler_start
            if begin_match:
                # Absolute position right after the BEGIN keyword
                abs_after_begin = match.end() + begin_match.end()
                nesting = 1
                # Search for BEGIN/END only in the text after BEGIN, but match only
                # standalone END (not END IF which is part of IF blocks)
                for end_match in _re.finditer(r'\b(BEGIN|END)\b', all_sql[abs_after_begin:], _re.IGNORECASE):
                    word = end_match.group(1).upper()
                    # Check if this END is followed by IF (part of END IF, not a block END)
                    pos_after = abs_after_begin + end_match.end()
                    rest = all_sql[pos_after:pos_after + 10].strip().upper()
                    if word == 'END' and rest.startswith('IF'):
                        continue  # Skip END IF
                    if word == 'BEGIN':
                        nesting += 1
                    elif word == 'END':
                        nesting -= 1
                        if nesting == 0:
                            handler_end = all_sql[:abs_after_begin + end_match.end()].count('\n') + 1
                            break

            # Extract enclosed DML and variables from handler body
            handler_text = '\n'.join(lines[handler_start - 1:handler_end])
            enclosed_dml = []
            for dml_match in _re.finditer(
                r'\b(INSERT\s+INTO|DELETE\s+FROM|SELECT\s+.+?\s+INTO)\s+',
                handler_text, _re.IGNORECASE
            ):
                start_pos = dml_match.start()
                rest = handler_text[start_pos:]
                semi_pos = rest.find(';')
                if semi_pos > 0:
                    stmt_text = rest[:semi_pos].strip()
                else:
                    stmt_text = rest.strip()
                stmt_text = _re.sub(r'\s+', ' ', stmt_text)
                enclosed_dml.append(stmt_text)

            handler_vars = sorted(set(var_pattern.findall(handler_text)))

            block_counter += 1
            blocks.append({
                'block_id': f'CF-{block_counter}',
                'block_type': 'EXCEPTION_HANDLER',
                'condition': handler_for,
                'line_range': f'L{handler_start}-L{handler_end}',
                'enclosed_dml': ', '.join(enclosed_dml) if enclosed_dml else '',
                'variables': ', '.join(handler_vars) if handler_vars else None,
                'nesting_level': 0
            })

        # --- SET Statement Tracking ---
        # SET variable = expression; (Teradata SPL variable assignment)
        set_pattern = _re.compile(
            r'^\s*SET\s+(\w+)\s*=\s*(.+?)\s*;',
            _re.IGNORECASE | _re.MULTILINE
        )
        for match in set_pattern.finditer(all_sql):
            var_name = match.group(1)
            expr = match.group(2).strip()
            line_num = all_sql[:match.start()].count('\n') + 1
            block_counter += 1
            blocks.append({
                'block_id': f'CF-{block_counter}',
                'block_type': 'SET',
                'condition': f'{var_name} = {_re.sub(chr(10), " ", expr)[:120]}',
                'line_range': f'L{line_num}-L{line_num}',
                'enclosed_dml': '',
                'variables': var_name,
                'nesting_level': 0
            })

        # --- WHILE Loop Tracking ---
        while_pattern = _re.compile(r'^\s*WHILE\b\s+(.+?)\s*$', _re.IGNORECASE | _re.MULTILINE)
        for match in while_pattern.finditer(all_sql):
            cond = match.group(1).strip()
            start_line = all_sql[:match.start()].count('\n') + 1
            # Find END WHILE
            end_line = start_line
            nesting_w = 1
            for k in range(start_line, len(lines)):
                stripped = lines[k].strip().upper()
                if _re.match(r'\bWHILE\b\s+', stripped):
                    nesting_w += 1
                if _re.match(r'\bEND\s+WHILE\b', stripped):
                    nesting_w -= 1
                    if nesting_w == 0:
                        end_line = k + 1
                        break
            # Extract enclosed DML
            loop_text = '\n'.join(lines[start_line - 1:end_line])
            loop_dml = []
            for dml_match in _re.finditer(
                r'\b(INSERT\s+INTO|DELETE\s+FROM|UPDATE\s+[\w.]+\s+SET|SELECT\s+.+?\s+INTO)\s+',
                loop_text, _re.IGNORECASE
            ):
                rest = loop_text[dml_match.start():]
                semi_pos = rest.find(';')
                stmt_text = rest[:semi_pos].strip() if semi_pos > 0 else rest.strip()
                stmt_text = _re.sub(r'\s+', ' ', stmt_text)
                loop_dml.append(stmt_text[:200])
            block_counter += 1
            blocks.append({
                'block_id': f'CF-{block_counter}',
                'block_type': 'WHILE',
                'condition': _re.sub(r'\s+', ' ', cond)[:200],
                'line_range': f'L{start_line}-L{end_line}',
                'enclosed_dml': ', '.join(loop_dml) if loop_dml else '',
                'variables': ', '.join(sorted(set(var_pattern.findall(cond)))) or None,
                'nesting_level': 0
            })

        # --- CALL Statement Tracking ---
        call_pattern = _re.compile(
            r'^\s*CALL\s+([\w.]+)\s*\(([^)]*)\)\s*;',
            _re.IGNORECASE | _re.MULTILINE
        )
        for match in call_pattern.finditer(all_sql):
            proc_name = match.group(1)
            params = match.group(2).strip()
            line_num = all_sql[:match.start()].count('\n') + 1
            block_counter += 1
            blocks.append({
                'block_id': f'CF-{block_counter}',
                'block_type': 'CALL',
                'condition': f'CALL {proc_name}({params[:100]})',
                'line_range': f'L{line_num}-L{line_num}',
                'enclosed_dml': '',
                'variables': ', '.join(sorted(set(var_pattern.findall(params)))) or None,
                'nesting_level': 0
            })

        # --- Dynamic SQL (CALL DBC.SYSEXECSQL) Tracking ---
        dynsql_pattern = _re.compile(
            r'CALL\s+DBC\.SYSEXECSQL\s*\(\s*(.+?)\s*\)\s*;',
            _re.IGNORECASE | _re.DOTALL
        )
        for match in dynsql_pattern.finditer(all_sql):
            sql_expr = _re.sub(r'\s+', ' ', match.group(1))[:200]
            line_num = all_sql[:match.start()].count('\n') + 1
            block_counter += 1
            blocks.append({
                'block_id': f'CF-{block_counter}',
                'block_type': 'DYNAMIC_SQL',
                'condition': f'DBC.SYSEXECSQL({sql_expr})',
                'line_range': f'L{line_num}-L{line_num}',
                'enclosed_dml': sql_expr,
                'variables': ', '.join(sorted(set(var_pattern.findall(sql_expr)))) or None,
                'nesting_level': 0
            })

        # --- BT/ET Transaction Control ---
        bt_pattern = _re.compile(r'^\s*BT\s*;', _re.IGNORECASE | _re.MULTILINE)
        et_pattern = _re.compile(r'^\s*ET\s*;', _re.IGNORECASE | _re.MULTILINE)
        bt_lines = [(all_sql[:m.start()].count('\n') + 1) for m in bt_pattern.finditer(all_sql)]
        et_lines = [(all_sql[:m.start()].count('\n') + 1) for m in et_pattern.finditer(all_sql)]
        # Pair BT with corresponding ET
        for i, bt_line in enumerate(bt_lines):
            et_line = et_lines[i] if i < len(et_lines) else bt_line
            # Extract enclosed DML between BT and ET
            bt_et_text = '\n'.join(lines[bt_line - 1:et_line])
            bt_dml = []
            for dml_match in _re.finditer(
                r'\b(INSERT\s+INTO|DELETE\s+FROM|UPDATE\s+[\w.]+\s+SET|SELECT\s+.+?\s+INTO)\s+',
                bt_et_text, _re.IGNORECASE
            ):
                rest = bt_et_text[dml_match.start():]
                semi_pos = rest.find(';')
                stmt_text = rest[:semi_pos].strip() if semi_pos > 0 else rest.strip()
                stmt_text = _re.sub(r'\s+', ' ', stmt_text)[:200]
                bt_dml.append(stmt_text)
            block_counter += 1
            blocks.append({
                'block_id': f'CF-{block_counter}',
                'block_type': 'TRANSACTION',
                'condition': f'BT (Begin Transaction)',
                'line_range': f'L{bt_line}-L{et_line}',
                'enclosed_dml': ', '.join(bt_dml) if bt_dml else '',
                'variables': None,
                'nesting_level': 0
            })

        # --- COLLECT STATISTICS Tracking ---
        collect_pattern = _re.compile(
            r'^\s*COLLECT\s+(?:STATISTICS|STATS)\s+(?:ON\s+)?([\w.]+)(?:\s+COLUMN\s*\(([^)]+)\))?\s*;',
            _re.IGNORECASE | _re.MULTILINE
        )
        for match in collect_pattern.finditer(all_sql):
            table_name = match.group(1)
            columns = match.group(2).strip() if match.group(2) else ''
            line_num = all_sql[:match.start()].count('\n') + 1
            block_counter += 1
            cond = f'COLLECT STATISTICS ON {table_name}'
            if columns:
                cond += f' COLUMN ({columns})'
            blocks.append({
                'block_id': f'CF-{block_counter}',
                'block_type': 'COLLECT_STATS',
                'condition': cond,
                'line_range': f'L{line_num}-L{line_num}',
                'enclosed_dml': '',
                'variables': None,
                'nesting_level': 0
            })

        # --- RESIGNAL Statement Tracking ---
        resignal_pattern = _re.compile(r'^\s*RESIGNAL\s*;', _re.IGNORECASE | _re.MULTILINE)
        for match in resignal_pattern.finditer(all_sql):
            line_num = all_sql[:match.start()].count('\n') + 1
            block_counter += 1
            blocks.append({
                'block_id': f'CF-{block_counter}',
                'block_type': 'RESIGNAL',
                'condition': 'RESIGNAL (re-raise current exception)',
                'line_range': f'L{line_num}-L{line_num}',
                'enclosed_dml': '',
                'variables': None,
                'nesting_level': 0
            })

        # --- CREATE/DROP VOLATILE TABLE DDL Tracking ---
        create_vol_pattern = _re.compile(
            r'^\s*CREATE\s+(?:MULTISET\s+)?VOLATILE\s+TABLE\s+([\w.]+)',
            _re.IGNORECASE | _re.MULTILINE
        )
        for match in create_vol_pattern.finditer(all_sql):
            table_name = match.group(1)
            line_num = all_sql[:match.start()].count('\n') + 1
            # Find end of CREATE statement (semicolon or WITH DATA)
            rest = all_sql[match.end():]
            semi_pos = rest.find(';')
            end_line = line_num
            if semi_pos >= 0:
                end_line = all_sql[:match.end() + semi_pos].count('\n') + 1
            block_counter += 1
            blocks.append({
                'block_id': f'CF-{block_counter}',
                'block_type': 'CREATE_VOLATILE_TABLE',
                'condition': f'CREATE VOLATILE TABLE {table_name}',
                'line_range': f'L{line_num}-L{end_line}',
                'enclosed_dml': '',
                'variables': None,
                'nesting_level': 0
            })

        drop_table_pattern = _re.compile(
            r'^\s*DROP\s+TABLE\s+([\w.]+)\s*;',
            _re.IGNORECASE | _re.MULTILINE
        )
        for match in drop_table_pattern.finditer(all_sql):
            table_name = match.group(1)
            line_num = all_sql[:match.start()].count('\n') + 1
            block_counter += 1
            blocks.append({
                'block_id': f'CF-{block_counter}',
                'block_type': 'DROP_TABLE',
                'condition': f'DROP TABLE {table_name}',
                'line_range': f'L{line_num}-L{line_num}',
                'enclosed_dml': '',
                'variables': None,
                'nesting_level': 0
            })

        return blocks

    def _apply_excel_styling(self, wb) -> None:
        """Apply consistent styling to all worksheets."""
        try:
            from openpyxl.styles import Font, Alignment, PatternFill, Border, Side
            from openpyxl.utils import get_column_letter
        except ImportError:
            return  # Skip styling if openpyxl styles unavailable

        header_font = Font(bold=True, color="FFFFFF")
        header_fill = PatternFill(start_color="4472C4", end_color="4472C4", fill_type="solid")
        header_alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)

        thin_border = Border(
            left=Side(style='thin'),
            right=Side(style='thin'),
            top=Side(style='thin'),
            bottom=Side(style='thin')
        )

        for ws in wb.worksheets:
            if ws.title == "Summary":
                # Style summary sheet differently
                ws.column_dimensions['A'].width = 25
                ws.column_dimensions['B'].width = 60
                # Bold the title
                if ws['A1'].value:
                    ws['A1'].font = Font(bold=True, size=14)
                continue

            # Style header row for data sheets
            if ws.max_row > 0:
                for col in range(1, ws.max_column + 1):
                    cell = ws.cell(row=1, column=col)
                    cell.font = header_font
                    cell.fill = header_fill
                    cell.alignment = header_alignment
                    cell.border = thin_border

            # Auto-size columns (approximate)
            for col in range(1, ws.max_column + 1):
                max_length = 0
                column_letter = get_column_letter(col)
                for row in range(1, min(ws.max_row + 1, 50)):  # Sample first 50 rows
                    cell_value = ws.cell(row=row, column=col).value
                    if cell_value:
                        max_length = max(max_length, len(str(cell_value)))
                adjusted_width = min(max(max_length + 2, 10), 60)  # Between 10 and 60
                ws.column_dimensions[column_letter].width = adjusted_width

            # Green highlight for subquery decomposition rows in Column Lineage
            if ws.title == "Column Lineage":
                green_fill = PatternFill(start_color="C6EFCE", end_color="C6EFCE", fill_type="solid")
                # Find the "Hops" column index to identify decomposition rows (hops > 0)
                hops_col = None
                for col in range(1, ws.max_column + 1):
                    if ws.cell(row=1, column=col).value == "Hops":
                        hops_col = col
                        break
                if hops_col:
                    for row in range(2, ws.max_row + 1):
                        hops_val = ws.cell(row=row, column=hops_col).value
                        if hops_val and isinstance(hops_val, (int, float)) and hops_val > 0:
                            for col in range(1, ws.max_column + 1):
                                ws.cell(row=row, column=col).fill = green_fill

    def get_structured_output(self, source_file: str = None) -> StructuredLineageOutput:
        """
        Get structured lineage output without writing to file.

        Args:
            source_file: Optional source file path

        Returns:
            StructuredLineageOutput object
        """
        return self._build_structured_output(source_file)
