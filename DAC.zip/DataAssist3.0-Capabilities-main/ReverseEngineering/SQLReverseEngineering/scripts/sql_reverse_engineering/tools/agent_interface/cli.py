﻿"""
Command-Line Interface module.

Provides CLI for batch processing SQL files and generating documentation.
"""

import argparse
import sys
import os
import glob
import json
import re
from werkzeug.utils import safe_join, secure_filename

# Add both tools directory and project root to sys.path
TOOLS_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
PROJECT_ROOT = os.path.dirname(TOOLS_DIR)
sys.path.insert(0, PROJECT_ROOT)
sys.path.insert(0, TOOLS_DIR)

from ast_generator.parser import SQLASTGenerator
from deconstructor.element_extractor import SQLElementExtractor
from lineage.lineage_extractor import LineageExtractor
from lineage.volatile_table_handler import VolatileTableHandler
from documentation.mapping_generator import SourceTargetMappingGenerator
from documentation.help_generator import HTMLHelpGenerator
from schema.ddl_parser import DDLSchemaLoader
from agent_interface.code_reviewer import CodeReviewerAgent, review_sql_file
from file_handlers.sql_handler import SQLHandler


# ---------------------------------------------------------------------------
# Per-target extraction helpers (fixes Issues #2, #4, #5, #6)
# Previously in cli_enhancement_v2.py — inlined here for single-file clarity.
# ---------------------------------------------------------------------------

def extract_dml_operation_for_target(statements: list, target_table: str) -> str:
    """Return the DML operation specific to target_table (Issue #2: per-target, not file-level)."""
    from sqlglot import exp as _exp
    target_normalized = target_table.upper().split('.')[-1] if target_table else ""
    for stmt in statements:
        if isinstance(stmt, _exp.Insert):
            insert_table = None
            if hasattr(stmt, 'this') and stmt.this:
                if isinstance(stmt.this, _exp.Table):
                    insert_table = stmt.this.name
                elif hasattr(stmt.this, 'this') and isinstance(stmt.this.this, _exp.Table):
                    insert_table = stmt.this.this.name
            if insert_table and insert_table.upper() == target_normalized:
                return "INSERT"
        elif isinstance(stmt, _exp.Create):
            create_table = None
            is_volatile = False
            is_view = False
            if hasattr(stmt, 'this'):
                if isinstance(stmt.this, _exp.Table):
                    create_table = stmt.this.name
                elif hasattr(stmt.this, 'this') and isinstance(stmt.this.this, _exp.Table):
                    create_table = stmt.this.this.name
            if hasattr(stmt, 'args') and stmt.args.get('temporary'):
                is_volatile = True
            if hasattr(stmt, 'kind') and stmt.kind and 'VIEW' in str(stmt.kind).upper():
                is_view = True
            if create_table and create_table.upper() == target_normalized:
                if is_volatile:
                    return "CREATE VOLATILE TABLE"
                elif is_view:
                    return "CREATE VIEW"
                else:
                    return "CREATE TABLE"
        elif isinstance(stmt, _exp.Update):
            update_table = None
            if hasattr(stmt, 'this') and isinstance(stmt.this, _exp.Table):
                update_table = stmt.this.name
            if update_table and update_table.upper() == target_normalized:
                return "UPDATE"
        elif isinstance(stmt, _exp.Delete):
            delete_table = None
            if hasattr(stmt, 'this') and isinstance(stmt.this, _exp.Table):
                delete_table = stmt.this.name
            if delete_table and delete_table.upper() == target_normalized:
                return "DELETE"
    return "UNKNOWN"


def extract_join_details_for_target(statements: list, target_table: str = None) -> str:
    """Extract join conditions scoped to the statement targeting target_table (Issue #4)."""
    from sqlglot import exp as _exp
    target_normalized = target_table.upper().split('.')[-1] if target_table else ""
    for stmt in statements:
        stmt_target = None
        if isinstance(stmt, _exp.Insert):
            if hasattr(stmt, 'this') and stmt.this:
                if isinstance(stmt.this, _exp.Table):
                    stmt_target = stmt.this.name
        elif isinstance(stmt, _exp.Create):
            if hasattr(stmt, 'this'):
                if isinstance(stmt.this, _exp.Table):
                    stmt_target = stmt.this.name
                elif hasattr(stmt.this, 'this'):
                    stmt_target = getattr(stmt.this.this, 'name', None)
        if target_normalized and stmt_target and stmt_target.upper() != target_normalized:
            continue
        join_parts = []
        for join in stmt.find_all(_exp.Join):
            join_type = ""
            if hasattr(join, 'kind') and join.kind:
                join_type = str(join.kind).upper()
            elif hasattr(join, 'side') and join.side:
                join_type = str(join.side).upper()
            else:
                join_type = "INNER"
            table_name = ""
            alias = ""
            if hasattr(join, 'this'):
                if isinstance(join.this, _exp.Table):
                    table_name = join.this.name
                    if join.this.db:
                        table_name = f"{join.this.db}.{table_name}"
                    if hasattr(join.this, 'alias') and join.this.alias:
                        alias = str(join.this.alias)
            on_condition = ""
            if hasattr(join, 'args') and join.args.get('on'):
                on_condition = str(join.args['on'])[:200]
            join_str = f"{join_type} JOIN: {table_name}"
            if alias:
                join_str += f" AS {alias}"
            if on_condition:
                join_str += f" ON {on_condition}"
            join_parts.append(join_str)
        if join_parts:
            return " | ".join(join_parts)
    return ""


def extract_where_conditions_for_target(statements: list, target_table: str = None) -> str:
    """Extract WHERE conditions scoped to the statement targeting target_table (Issue #5)."""
    from sqlglot import exp as _exp
    target_normalized = target_table.upper().split('.')[-1] if target_table else ""
    for stmt in statements:
        stmt_target = None
        if isinstance(stmt, _exp.Insert):
            if hasattr(stmt, 'this') and stmt.this:
                if isinstance(stmt.this, _exp.Table):
                    stmt_target = stmt.this.name
        elif isinstance(stmt, _exp.Create):
            if hasattr(stmt, 'this'):
                if isinstance(stmt.this, _exp.Table):
                    stmt_target = stmt.this.name
                elif hasattr(stmt.this, 'this'):
                    stmt_target = getattr(stmt.this.this, 'name', None)
        if target_normalized and stmt_target and stmt_target.upper() != target_normalized:
            continue
        where_parts = []
        for where in stmt.find_all(_exp.Where):
            if hasattr(where, 'this') and where.this:
                condition = str(where.this)[:300]
                if condition and condition not in where_parts:
                    where_parts.append(condition)
        if where_parts:
            return " AND ".join(where_parts)
    return ""



def extract_procedure_body_statements(sql: str, dialect: str = "tsql") -> list:
    """
    Extract DML statements from stored procedure body for lineage analysis.

    Args:
        sql: SQL containing CREATE PROCEDURE
        dialect: SQL dialect

    Returns:
        List of DML statement strings found in the procedure body
    """
    statements = []

    # Check if this is a stored procedure
    # Support multiple Teradata/SQL Server/other syntax variants:
    # - CREATE PROCEDURE
    # - CREATE OR REPLACE PROCEDURE
    # - REPLACE PROCEDURE (Teradata)
    proc_match = re.search(
        r'(?:CREATE\s+(?:OR\s+(?:ALTER|REPLACE)\s+)?|REPLACE\s+)(?:PROC(?:EDURE)?)\s+[^\s(]+\s*'
        r'(?:\([^)]*\))?\s*(?:SQL\s+SECURITY\s+\w+\s+)?(?:\w+:)?\s*(?:AS\s+)?(?:\s*BEGIN\s*)?',
        sql,
        re.IGNORECASE | re.DOTALL
    )

    if not proc_match:
        return statements

    # Get the procedure body (everything after the procedure header)
    body_start = proc_match.end()
    body = sql[body_start:]

    # Remove BEGIN/END blocks markers but keep content
    # Also handle TRY/CATCH blocks
    body = re.sub(r'\bBEGIN\s+TRY\b', '', body, flags=re.IGNORECASE)
    body = re.sub(r'\bEND\s+TRY\b', '', body, flags=re.IGNORECASE)
    body = re.sub(r'\bBEGIN\s+CATCH\b', '', body, flags=re.IGNORECASE)
    body = re.sub(r'\bEND\s+CATCH\b', '', body, flags=re.IGNORECASE)

    # Find INSERT statements with their SELECT
    insert_pattern = re.compile(
        r'(INSERT\s+INTO\s+[\w\.\[\]]+\s*'  # INSERT INTO table
        r'(?:\([^)]*\))?\s*'  # Optional column list
        r'SELECT\s+.+?'  # SELECT clause
        r'(?:FROM\s+.+?)?'  # FROM clause
        r'(?:(?:LEFT|RIGHT|INNER|OUTER|CROSS|FULL)?\s*(?:OUTER\s+)?JOIN\s+.+?)*'  # JOINs
        r'(?:WHERE\s+.+?)?'  # WHERE clause
        r'(?:GROUP\s+BY\s+.+?)?'  # GROUP BY
        r'(?:HAVING\s+.+?)?'  # HAVING
        r'(?:ORDER\s+BY\s+.+?)?'  # ORDER BY
        r')',
        re.IGNORECASE | re.DOTALL
    )

    # Find INSERT...SELECT statements more precisely
    # Split by common statement terminators
    lines = body.split('\n')
    current_stmt = []
    in_insert = False
    paren_depth = 0

    for line in lines:
        stripped = line.strip()

        # Skip comments and empty lines
        if not stripped or stripped.startswith('--'):
            continue

        # Track parentheses depth
        paren_depth += stripped.count('(') - stripped.count(')')

        # Check for INSERT INTO start
        if re.search(r'\bINSERT\s+INTO\b', stripped, re.IGNORECASE) and not in_insert:
            in_insert = True
            current_stmt = [line]
        elif in_insert:
            current_stmt.append(line)

            # Check for statement end (GROUP BY complete, new statement, etc.)
            # Statement ends when we see certain keywords at start of line
            # or when parentheses are balanced and we hit a non-continuation
            if paren_depth <= 0:
                # Check if next meaningful content is a new statement
                if re.search(r'^\s*(INSERT|UPDATE|DELETE|TRUNCATE|SET|DECLARE|IF|WHILE|EXEC|SELECT\s+@|PRINT|RAISERROR|GOTO)\b',
                           stripped, re.IGNORECASE) and len(current_stmt) > 1:
                    # End of current INSERT statement
                    stmt_text = '\n'.join(current_stmt[:-1])  # Exclude current line
                    if re.search(r'\bFROM\b', stmt_text, re.IGNORECASE):
                        statements.append(stmt_text)
                    in_insert = False
                    current_stmt = []
                    paren_depth = 0
                    # Check if current line starts a new INSERT
                    if re.search(r'\bINSERT\s+INTO\b', stripped, re.IGNORECASE):
                        in_insert = True
                        current_stmt = [line]

    # Capture last INSERT if still in progress
    if in_insert and current_stmt:
        stmt_text = '\n'.join(current_stmt)
        if re.search(r'\bFROM\b', stmt_text, re.IGNORECASE):
            statements.append(stmt_text)

    # Also find UPDATE statements with FROM clause (for lineage)
    update_pattern = re.compile(
        r'(UPDATE\s+[\w\.\[\]]+\s+SET\s+.+?FROM\s+.+?)(?=\bINSERT\b|\bUPDATE\b|\bDELETE\b|\bTRUNCATE\b|\bEXEC\b|\bSET\s+@|\bDECLARE\b|\bIF\b|\bWHILE\b|\bBEGIN\b|\bEND\b|$)',
        re.IGNORECASE | re.DOTALL
    )
    for match in update_pattern.finditer(body):
        statements.append(match.group(1).strip())

    # Find CREATE VOLATILE TABLE ... AS SELECT statements (Teradata volatile tables)
    # These are critical for tracking intermediate table lineage in stored procedures
    # Note: Teradata uses both SELECT and SEL (shorthand) keywords
    create_volatile_pattern = re.compile(
        r'CREATE\s+(?:MULTISET\s+)?VOLATILE\s+TABLE\s+([\w\.]+)'
        r'[\s,]+(?:(?:NO\s+(?:FALLBACK|JOURNAL|LOG)|FALLBACK|JOURNAL|LOG|CHECKSUM\s*=\s*\w+)\s*[,\s]*)*'
        r'AS\s*\(\s*(SEL(?:ECT)?\s+.+?)\)\s*(?:WITH\s+(?:NO\s+)?DATA)?',
        re.IGNORECASE | re.DOTALL
    )
    
    # More robust extraction of CREATE VOLATILE TABLE statements
    volatile_stmt_start = None
    volatile_table_name = None
    in_volatile_create = False
    volatile_paren_depth = 0
    volatile_lines = []
    
    for line_idx, line in enumerate(lines):
        stripped = line.strip()
        
        # Skip comments
        if stripped.startswith('--'):
            continue
            
        # Check for CREATE VOLATILE TABLE start
        create_match = re.search(r'CREATE\s+(?:MULTISET\s+)?VOLATILE\s+TABLE\s+([\w\.]+)', stripped, re.IGNORECASE)
        if create_match and not in_volatile_create:
            in_volatile_create = True
            volatile_table_name = create_match.group(1)
            volatile_lines = [line]
            volatile_paren_depth = stripped.count('(') - stripped.count(')')
        elif in_volatile_create:
            volatile_lines.append(line)
            volatile_paren_depth += stripped.count('(') - stripped.count(')')
            
            # Check for end of statement - WITH DATA (ignore parens in this clause) or semicolon
            # The WITH DATA line may contain additional INDEX clauses with parens, so we check
            # for the keyword specifically rather than relying on balanced parens
            is_end = False
            if re.search(r'\bWITH\s+(?:NO\s+)?DATA\b', stripped, re.IGNORECASE):
                is_end = True
            elif volatile_paren_depth <= 0 and stripped.endswith(';'):
                is_end = True
                
            if is_end:
                # Complete CREATE VOLATILE TABLE statement
                full_stmt = '\n'.join(volatile_lines)
                # Convert to INSERT INTO format for lineage extraction
                # Extract the SELECT part - note: Teradata uses SEL as shorthand for SELECT
                # Find everything between AS ( and the ending ) WITH DATA (or ) ; for simpler cases)
                as_match = re.search(r'AS\s*\(', full_stmt, re.IGNORECASE)
                if as_match:
                    as_pos = as_match.end()
                    # Find the content inside the parentheses
                    content_part = full_stmt[as_pos:]
                    # Find where WITH DATA or semicolon is
                    end_match = re.search(r'\)\s*(?:WITH\s+(?:NO\s+)?DATA|;)', content_part, re.IGNORECASE)
                    if end_match:
                        # Extract everything up to the closing paren
                        # But we need to handle nested parens - find the position of the closing paren
                        paren_count = 1
                        end_pos = 0
                        for char_idx, ch in enumerate(content_part):
                            if ch == '(':
                                paren_count += 1
                            elif ch == ')':
                                paren_count -= 1
                                if paren_count == 0:
                                    end_pos = char_idx
                                    break
                        if end_pos > 0:
                            select_part = content_part[:end_pos].strip()
                            # Convert SEL to SELECT for parser compatibility
                            if re.match(r'^SEL\s+', select_part, re.IGNORECASE) and not re.match(r'^SELECT\s+', select_part, re.IGNORECASE):
                                select_part = re.sub(r'^SEL\s+', 'SELECT ', select_part, flags=re.IGNORECASE)
                            # Create an INSERT INTO statement for lineage extraction
                            insert_stmt = f"INSERT INTO {volatile_table_name}\n{select_part}"
                            statements.append(insert_stmt)
                
                in_volatile_create = False
                volatile_lines = []
                volatile_table_name = None

    # Extract SELECT ... INTO variable statements (Teradata variable assignments)
    # These are single-line or multi-line statements like:
    #   SELECT CAST(MAX(COL) AS DATE) INTO ENDDATE FROM SCHEMA.TABLE;
    #   SELECT CAST(ADD_MONTHS(...)) INTO STARTDATE;  (no FROM - pure computation)
    # Convert them to INSERT INTO format so the lineage extractor can process them.
    select_into_pattern = re.compile(
        r'(SELECT\s+.+?\s+INTO\s+(\w+)\s*(?:FROM\s+.+?)?)\s*;',
        re.IGNORECASE | re.DOTALL
    )
    for match in select_into_pattern.finditer(body):
        full_match = match.group(1).strip()
        var_name = match.group(2).strip()
        # Skip if this is already captured as part of an INSERT INTO statement
        # (i.e., "INSERT INTO" contains "INTO" but starts with INSERT)
        if re.match(r'\s*INSERT\s+', full_match, re.IGNORECASE):
            continue
        # Split into the SELECT expr and the FROM clause
        into_match = re.search(r'\bINTO\s+\w+\b', full_match, re.IGNORECASE)
        if into_match:
            select_part = full_match[:into_match.start()].strip()
            after_into = full_match[into_match.end():].strip()
            # Reconstruct as: INSERT INTO VARIABLE.<varname> SELECT expr FROM ...
            if after_into:
                reconstructed = f"INSERT INTO VARIABLE.{var_name}\n{select_part}\n{after_into}"
            else:
                reconstructed = f"INSERT INTO VARIABLE.{var_name}\n{select_part}"
            statements.append(reconstructed)

    # Extract CALL DBC.SYSEXECSQL('...') dynamic SQL statements.
    # These wrap DML inside a string literal and the lineage extractor
    # has a handler that unwraps them automatically.
    sysexec_pattern = re.compile(
        r"(CALL\s+DBC\.SYSEXECSQL\s*\(\s*'.*?'\s*\))\s*;",
        re.IGNORECASE | re.DOTALL
    )
    for match in sysexec_pattern.finditer(body):
        statements.append(match.group(1).strip())

    # Clean up statements
    cleaned = []
    for stmt in statements:
        # Remove trailing incomplete parts - use word boundary \b to avoid matching MULTISET, SUBSET, etc.
        stmt_cleaned = re.sub(r'\s*\b(SET|DECLARE|IF|WHILE|PRINT|RAISERROR|EXEC|GOTO)\s+.*$', '', stmt, flags=re.IGNORECASE | re.DOTALL)
        stmt_cleaned = stmt_cleaned.strip()
        if stmt_cleaned and len(stmt_cleaned) > 20:  # Minimum viable statement length
            cleaned.append(stmt_cleaned)

    return cleaned


def extract_dml_operation_from_ast(statements: list) -> str:
    """
    Extract DML operation type from a list of AST statements.
    
    Args:
        statements: List of sqlglot Expression objects
    
    Returns:
        DML operation string (INSERT, CREATE VIEW, CREATE TABLE, etc.)
    """
    try:
        from sqlglot import exp
        
        operations = []
        for stmt in statements:
            if isinstance(stmt, exp.Insert):
                operations.append("INSERT")
            elif isinstance(stmt, exp.Create):
                kind = getattr(stmt, 'kind', None)
                if kind:
                    operations.append(f"CREATE {kind.upper()}")
                elif stmt.args.get('kind'):
                    operations.append(f"CREATE {stmt.args['kind'].upper()}")
                elif stmt.find(exp.Select):
                    operations.append("CREATE VIEW")
                else:
                    operations.append("CREATE TABLE")
            elif isinstance(stmt, exp.Update):
                operations.append("UPDATE")
            elif isinstance(stmt, exp.Delete):
                operations.append("DELETE")
            elif isinstance(stmt, exp.Merge):
                operations.append("MERGE")
            elif isinstance(stmt, exp.Select):
                operations.append("SELECT")
        
        # Return unique operations separated by comma
        unique_ops = list(dict.fromkeys(operations))  # Preserve order, remove duplicates
        return ", ".join(unique_ops) if unique_ops else ""
    except Exception:
        return ""


def extract_join_details_from_ast(statements: list) -> str:
    """
    Extract join conditions from a list of AST statements.
    
    Args:
        statements: List of sqlglot Expression objects
    
    Returns:
        Join details string
    """
    try:
        from sqlglot import exp
        
        joins = []
        for stmt in statements:
            for join in stmt.find_all(exp.Join):
                join_type = ""
                if hasattr(join, 'kind') and join.kind:
                    join_type = join.kind.upper()
                elif hasattr(join, 'side') and join.side:
                    join_type = join.side.upper()
                else:
                    join_type = "INNER"
                
                # Get joined table
                table_name = ""
                if hasattr(join, 'this') and isinstance(join.this, exp.Table):
                    table_parts = []
                    if hasattr(join.this, 'db') and join.this.db:
                        table_parts.append(str(join.this.db))
                    if hasattr(join.this, 'this') and join.this.this:
                        table_parts.append(str(join.this.this))
                    table_name = ".".join(table_parts) if table_parts else str(join.this)[:50]
                elif hasattr(join, 'this'):
                    table_name = str(join.this)[:50]
                
                # Get join condition
                on_clause = ""
                if hasattr(join, 'args') and 'on' in join.args and join.args['on']:
                    on_clause = str(join.args['on'])[:100]
                
                if table_name:
                    join_str = f"{join_type} JOIN: {table_name}"
                    if on_clause:
                        join_str += f" ON {on_clause}"
                    joins.append(join_str)
        
        return " | ".join(joins)
    except Exception:
        return ""


def extract_where_conditions_from_ast(statements: list) -> str:
    """
    Extract WHERE clause conditions from a list of AST statements.
    
    Args:
        statements: List of sqlglot Expression objects
    
    Returns:
        WHERE conditions string
    """
    try:
        from sqlglot import exp
        
        wheres = []
        for stmt in statements:
            for where in stmt.find_all(exp.Where):
                if hasattr(where, 'this') and where.this:
                    condition = str(where.this)[:200]
                    wheres.append(condition)
        
        # Return unique conditions
        unique_wheres = list(dict.fromkeys(wheres))
        return " AND ".join(unique_wheres)
    except Exception:
        return ""


def _generate_field_level_graph_from_lineage(lineage_graph, output_path: str, title: str) -> None:
    """
    Generate a field-level lineage graph HTML from a LineageGraph with enhanced UI/UX.

    Features:
    - Navigation minimap
    - Keyboard navigation (arrows, WASD, +/-, F, R, H, etc.)
    - Quick navigation panel
    - Position/progress indicator
    - Enhanced search with autocomplete
    - Table collapse/expand
    - Help modal

    Args:
        lineage_graph: LineageGraph with edges
        output_path: Path to output HTML file
        title: Title for the visualization
    """
    output_path = _resolve_output_dir(output_path)
    import json as json_module

    # Build graph data structure
    tables = {}
    columns = {}
    edges_list = []
    edge_set = set()

    for edge in lineage_graph.edges:
        # Source column
        src_table = edge.source.table_name or "[HARDCODED]"
        src_col = edge.source.column_name or "value"
        src_id = f"{src_table}.{src_col}"

        if src_table not in tables:
            tables[src_table] = {"id": src_table, "name": src_table, "columns": set(), "type": "source"}
        tables[src_table]["columns"].add(src_col)

        if src_id not in columns:
            columns[src_id] = {"id": src_id, "column_name": src_col, "table_name": src_table, "parent": src_table}

        # Target column
        tgt_table = edge.target.table_name or "UNKNOWN"
        tgt_col = edge.target.column_name or "column"
        tgt_id = f"{tgt_table}.{tgt_col}"

        if tgt_table not in tables:
            tables[tgt_table] = {"id": tgt_table, "name": tgt_table, "columns": set(), "type": "target"}
        tables[tgt_table]["columns"].add(tgt_col)

        if tgt_id not in columns:
            columns[tgt_id] = {"id": tgt_id, "column_name": tgt_col, "table_name": tgt_table, "parent": tgt_table}

        # Edge
        edge_key = f"{src_id}|{tgt_id}"
        if edge_key not in edge_set:
            edge_set.add(edge_key)
            transform = ""
            transform_type = "DIRECT"
            if edge.transformation:
                transform = edge.transformation.sql_expression[:500] if edge.transformation.sql_expression else ""
                transform_type = edge.transformation.transformation_type if hasattr(edge.transformation, 'transformation_type') else "DIRECT"
            edges_list.append({
                "source": src_id,
                "target": tgt_id,
                "source_column": src_col,
                "target_column": tgt_col,
                "transformation": transform,
                "transformation_type": transform_type
            })

    # Determine table types
    source_tables = set()
    target_tables = set()
    for edge in lineage_graph.edges:
        src_table = edge.source.table_name or "[HARDCODED]"
        tgt_table = edge.target.table_name or "UNKNOWN"
        source_tables.add(src_table)
        target_tables.add(tgt_table)

    final_targets = target_tables - source_tables
    ultimate_sources = source_tables - target_tables

    for table_name in tables:
        if table_name in final_targets:
            tables[table_name]["type"] = "target"
        elif table_name in ultimate_sources:
            tables[table_name]["type"] = "source"
        else:
            tables[table_name]["type"] = "intermediate"

    # Assign column types based on table types
    for col_id, col_info in columns.items():
        col_info["type"] = tables[col_info["table_name"]]["type"]

    # Build graph_data structure
    graph_data = {
        "tables": [{"id": t["id"], "name": t["name"], "type": t["type"], "columns": list(t["columns"])} for t in tables.values()],
        "columns": [{"id": c["id"], "column_name": c["column_name"], "table_name": c["table_name"], "parent": c["parent"], "type": c["type"]} for c in columns.values()],
        "edges": edges_list,
        "column_lineages": []  # Simple lineage from edges
    }

    # Build simple column lineages from edges
    for edge in edges_list:
        graph_data["column_lineages"].append({
            "target_table": edge["target"].rsplit(".", 1)[0],
            "target_column": edge["target_column"],
            "ultimate_source_table": edge["source"].rsplit(".", 1)[0],
            "ultimate_source_column": edge["source_column"],
            "hop_count": 1,
            "lookup_tables": [],
            "hops": [
                {"table_name": edge["source"].rsplit(".", 1)[0], "column_name": edge["source_column"], "transformation": edge["source_column"], "transformation_type": "SOURCE"},
                {"table_name": edge["target"].rsplit(".", 1)[0], "column_name": edge["target_column"], "transformation": edge["transformation"] or edge["target_column"], "transformation_type": edge["transformation_type"]}
            ]
        })

    graph_json = json_module.dumps(graph_data, indent=2)

    html = f'''<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{title}</title>
    <script src="https://unpkg.com/cytoscape@3.28.1/dist/cytoscape.min.js"></script>
    <script src="https://unpkg.com/dagre@0.8.5/dist/dagre.min.js"></script>
    <script src="https://unpkg.com/cytoscape-dagre@2.5.0/cytoscape-dagre.js"></script>
    <style>
        * {{ margin: 0; padding: 0; box-sizing: border-box; }}
        body {{ font-family: 'Segoe UI', Tahoma, sans-serif; background: linear-gradient(135deg, #1a1a2e 0%, #16213e 100%); color: #eee; height: 100vh; overflow: hidden; }}
        .container {{ display: flex; flex-direction: column; height: 100vh; }}
        .header {{ background: rgba(0,0,0,0.3); padding: 15px 20px; display: flex; justify-content: space-between; align-items: center; border-bottom: 1px solid #333; }}
        .header h1 {{ color: #4fc3f7; font-size: 1.5em; }}
        .stats {{ display: flex; gap: 20px; }}
        .stat {{ text-align: center; padding: 5px 15px; background: rgba(79,195,247,0.1); border-radius: 5px; border: 1px solid #4fc3f7; }}
        .stat-value {{ font-size: 1.3em; font-weight: bold; color: #4fc3f7; }}
        .stat-label {{ font-size: 0.75em; color: #aaa; }}
        .controls {{ background: rgba(0,0,0,0.2); padding: 10px 20px; display: flex; gap: 15px; align-items: center; flex-wrap: wrap; }}
        .control-group {{ display: flex; align-items: center; gap: 8px; }}
        .control-group label {{ font-size: 0.85em; color: #aaa; }}
        input[type="text"] {{ padding: 8px 12px; border: 1px solid #444; border-radius: 5px; background: #2a2a4a; color: #fff; width: 200px; }}
        input[type="text"]:focus {{ outline: none; border-color: #4fc3f7; }}
        select {{ padding: 8px 12px; border: 1px solid #444; border-radius: 5px; background: #2a2a4a; color: #fff; }}
        button {{ padding: 8px 16px; border: none; border-radius: 5px; cursor: pointer; font-size: 0.85em; transition: all 0.2s; }}
        .btn-primary {{ background: #4fc3f7; color: #000; }}
        .btn-primary:hover {{ background: #81d4fa; }}
        .btn-secondary {{ background: #444; color: #fff; }}
        .btn-secondary:hover {{ background: #555; }}
        .main-content {{ display: flex; flex: 1; overflow: hidden; position: relative; }}
        #cy {{ flex: 1; background: linear-gradient(135deg, #0d1b2a 0%, #1b263b 100%); }}
        .side-panel {{ width: 420px; background: rgba(0,0,0,0.4); border-left: 1px solid #333; overflow-y: auto; transition: width 0.3s; }}
        .side-panel.hidden {{ width: 0; border: none; overflow: hidden; }}
        .panel-header {{ padding: 15px; background: rgba(79,195,247,0.1); border-bottom: 1px solid #333; display: flex; justify-content: space-between; align-items: center; }}
        .panel-header h3 {{ color: #4fc3f7; word-break: break-all; }}
        .close-btn {{ background: none; border: none; color: #aaa; font-size: 1.5em; cursor: pointer; padding: 0 10px; }}
        .close-btn:hover {{ color: #fff; }}
        .panel-content {{ padding: 15px; }}
        .legend {{ position: absolute; bottom: 20px; left: 20px; background: rgba(0,0,0,0.8); padding: 15px; border-radius: 8px; border: 1px solid #333; z-index: 100; }}
        .legend h4 {{ color: #4fc3f7; margin-bottom: 10px; font-size: 0.9em; }}
        .legend-item {{ display: flex; align-items: center; gap: 10px; margin: 5px 0; font-size: 0.85em; }}
        .legend-color {{ width: 24px; height: 24px; border-radius: 4px; border: 2px solid rgba(255,255,255,0.3); }}
        .source-color {{ background: linear-gradient(135deg, #1b5e20, #2e7d32); }}
        .intermediate-color {{ background: linear-gradient(135deg, #37474f, #546e7a); }}
        .target-color {{ background: linear-gradient(135deg, #4a148c, #7b1fa2); }}
        .info-section {{ margin: 15px 0; padding: 12px; background: rgba(255,255,255,0.05); border-radius: 5px; }}
        .info-section h4 {{ color: #4fc3f7; margin-bottom: 10px; font-size: 0.9em; }}
        .info-row {{ display: flex; justify-content: space-between; padding: 5px 0; border-bottom: 1px solid rgba(255,255,255,0.1); }}
        .info-row:last-child {{ border-bottom: none; }}
        .info-label {{ color: #aaa; font-size: 0.85em; }}
        .info-value {{ color: #fff; font-size: 0.85em; text-align: right; max-width: 200px; word-break: break-all; }}
        .hop {{ display: flex; align-items: flex-start; margin-bottom: 5px; }}
        .hop-indicator {{ width: 30px; display: flex; flex-direction: column; align-items: center; }}
        .hop-dot {{ width: 14px; height: 14px; border-radius: 50%; background: #4fc3f7; border: 2px solid #fff; }}
        .hop-line {{ width: 2px; height: 40px; background: #4fc3f7; }}
        .hop.source .hop-dot {{ background: #2e7d32; }}
        .hop.intermediate .hop-dot {{ background: #546e7a; }}
        .hop.target .hop-dot {{ background: #7b1fa2; }}
        .hop-content {{ flex: 1; background: rgba(255,255,255,0.05); padding: 10px 12px; border-radius: 5px; margin-left: 10px; border-left: 3px solid #4fc3f7; }}
        .hop.source .hop-content {{ border-left-color: #2e7d32; }}
        .hop.target .hop-content {{ border-left-color: #7b1fa2; }}
        .hop-table {{ font-weight: bold; color: #4fc3f7; font-size: 0.9em; }}
        .hop-column {{ color: #fff; margin-top: 3px; font-size: 1em; }}
        .hop-transform {{ font-size: 0.8em; color: #aaa; margin-top: 8px; font-family: 'Consolas', monospace; background: rgba(0,0,0,0.3); padding: 8px; border-radius: 3px; max-height: 100px; overflow-y: auto; word-break: break-all; }}
        #minimap {{ position: absolute; bottom: 20px; right: 20px; width: 200px; height: 150px; background: rgba(0,0,0,0.85); border: 2px solid #4fc3f7; border-radius: 8px; z-index: 200; overflow: hidden; cursor: crosshair; }}
        #minimap-canvas {{ width: 100%; height: 100%; }}
        #minimap-viewport {{ position: absolute; border: 2px solid #ffeb3b; background: rgba(255,235,59,0.15); pointer-events: none; }}
        .minimap-header {{ position: absolute; top: 0; left: 0; right: 0; background: rgba(79,195,247,0.2); padding: 3px 8px; font-size: 0.7em; color: #4fc3f7; display: flex; justify-content: space-between; }}
        .minimap-toggle {{ cursor: pointer; padding: 2px 6px; background: rgba(0,0,0,0.3); border-radius: 3px; }}
        #minimap.collapsed {{ height: 24px; }}
        #minimap.collapsed #minimap-canvas, #minimap.collapsed #minimap-viewport {{ display: none; }}
        .nav-panel {{ position: absolute; left: 0; top: 0; bottom: 0; width: 280px; background: rgba(0,0,0,0.9); border-right: 1px solid #333; z-index: 150; display: flex; flex-direction: column; transition: transform 0.3s; }}
        .nav-panel.collapsed {{ transform: translateX(-250px); }}
        .nav-panel-header {{ padding: 12px 15px; background: rgba(79,195,247,0.1); border-bottom: 1px solid #333; display: flex; justify-content: space-between; align-items: center; }}
        .nav-panel-header h4 {{ color: #4fc3f7; font-size: 0.9em; margin: 0; }}
        .nav-panel-toggle {{ position: absolute; right: -30px; top: 50%; transform: translateY(-50%); width: 30px; height: 60px; background: rgba(0,0,0,0.9); border: 1px solid #333; border-left: none; border-radius: 0 5px 5px 0; cursor: pointer; display: flex; align-items: center; justify-content: center; color: #4fc3f7; font-size: 1.2em; }}
        .nav-panel-content {{ flex: 1; overflow-y: auto; padding: 10px 0; }}
        .nav-group {{ margin-bottom: 10px; }}
        .nav-group-header {{ padding: 8px 15px; color: #888; font-size: 0.75em; text-transform: uppercase; display: flex; justify-content: space-between; }}
        .nav-group-count {{ background: rgba(255,255,255,0.1); padding: 2px 6px; border-radius: 10px; }}
        .nav-item {{ padding: 8px 15px 8px 25px; cursor: pointer; display: flex; justify-content: space-between; font-size: 0.85em; color: #ccc; transition: background 0.2s; }}
        .nav-item:hover {{ background: rgba(79,195,247,0.15); color: #fff; }}
        .nav-item.active {{ background: rgba(79,195,247,0.25); color: #4fc3f7; border-left: 3px solid #4fc3f7; padding-left: 22px; }}
        .nav-item-badge {{ background: rgba(255,255,255,0.1); padding: 2px 6px; border-radius: 10px; font-size: 0.8em; color: #888; }}
        .nav-item.source {{ border-left: 3px solid #2e7d32; padding-left: 22px; }}
        .nav-item.intermediate {{ border-left: 3px solid #546e7a; padding-left: 22px; }}
        .nav-item.target {{ border-left: 3px solid #7b1fa2; padding-left: 22px; }}
        .position-indicator {{ position: absolute; bottom: 180px; right: 20px; background: rgba(0,0,0,0.85); border: 1px solid #333; border-radius: 8px; padding: 12px 15px; z-index: 100; min-width: 180px; }}
        .position-indicator h5 {{ color: #4fc3f7; font-size: 0.8em; margin: 0 0 10px 0; }}
        .position-text {{ font-size: 0.85em; color: #ccc; margin-bottom: 8px; }}
        .progress-bar-container {{ height: 6px; background: rgba(255,255,255,0.1); border-radius: 3px; overflow: hidden; }}
        .progress-bar {{ height: 100%; background: linear-gradient(90deg, #2e7d32, #4fc3f7, #7b1fa2); border-radius: 3px; transition: width 0.3s; }}
        .progress-markers {{ display: flex; justify-content: space-between; margin-top: 5px; font-size: 0.7em; color: #666; }}
        .search-container {{ position: relative; }}
        .autocomplete-dropdown {{ position: absolute; top: 100%; left: 0; right: 0; background: rgba(42,42,74,0.98); border: 1px solid #4fc3f7; border-top: none; border-radius: 0 0 5px 5px; max-height: 300px; overflow-y: auto; z-index: 1000; display: none; }}
        .autocomplete-dropdown.visible {{ display: block; }}
        .autocomplete-group {{ padding: 5px 0; border-bottom: 1px solid rgba(255,255,255,0.1); }}
        .autocomplete-group-header {{ padding: 5px 12px; font-size: 0.7em; color: #888; text-transform: uppercase; }}
        .autocomplete-item {{ padding: 8px 12px; cursor: pointer; display: flex; justify-content: space-between; font-size: 0.85em; }}
        .autocomplete-item:hover {{ background: rgba(79,195,247,0.2); }}
        .autocomplete-item-name {{ color: #fff; }}
        .autocomplete-item-type {{ font-size: 0.75em; padding: 2px 6px; border-radius: 3px; background: rgba(255,255,255,0.1); color: #888; }}
        .search-match-count {{ margin-left: 10px; font-size: 0.8em; color: #888; }}
        .help-modal {{ position: fixed; top: 0; left: 0; right: 0; bottom: 0; background: rgba(0,0,0,0.85); z-index: 2000; display: none; justify-content: center; align-items: center; }}
        .help-modal.visible {{ display: flex; }}
        .help-content {{ background: #1a1a2e; border: 2px solid #4fc3f7; border-radius: 12px; padding: 25px 35px; max-width: 700px; max-height: 80vh; overflow-y: auto; }}
        .help-content h2 {{ color: #4fc3f7; margin: 0 0 20px 0; display: flex; justify-content: space-between; }}
        .help-close {{ cursor: pointer; font-size: 1.5em; color: #888; padding: 5px 10px; }}
        .help-section {{ margin-bottom: 20px; }}
        .help-section h3 {{ color: #81d4fa; font-size: 1em; margin: 0 0 12px 0; padding-bottom: 5px; border-bottom: 1px solid #333; }}
        .shortcut-grid {{ display: grid; grid-template-columns: repeat(2, 1fr); gap: 8px 20px; }}
        .shortcut-item {{ display: flex; align-items: center; gap: 10px; font-size: 0.85em; }}
        .shortcut-key {{ background: #333; padding: 4px 10px; border-radius: 4px; font-family: 'Consolas', monospace; color: #4fc3f7; min-width: 60px; text-align: center; border: 1px solid #444; }}
        .shortcut-desc {{ color: #ccc; }}
        .kbd-hint {{ font-size: 0.7em; color: #666; margin-left: 5px; background: rgba(255,255,255,0.05); padding: 2px 5px; border-radius: 3px; font-family: 'Consolas', monospace; }}
        .instructions {{ position: absolute; top: 150px; right: 20px; background: rgba(0,0,0,0.8); padding: 15px; border-radius: 8px; border: 1px solid #333; font-size: 0.8em; max-width: 200px; z-index: 100; }}
        .instructions h4 {{ color: #4fc3f7; margin-bottom: 8px; }}
        .instructions ul {{ list-style: none; color: #aaa; }}
        .instructions li {{ margin: 5px 0; }}
        .instructions li::before {{ content: ">"; color: #4fc3f7; margin-right: 5px; }}
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <div><h1>{title}</h1></div>
            <div class="stats">
                <div class="stat"><div class="stat-value" id="statTables">0</div><div class="stat-label">Tables</div></div>
                <div class="stat"><div class="stat-value" id="statColumns">0</div><div class="stat-label">Columns</div></div>
                <div class="stat"><div class="stat-value" id="statEdges">0</div><div class="stat-label">Flows</div></div>
            </div>
        </div>
        <div class="controls">
            <div class="control-group search-container">
                <label>Search:</label>
                <input type="text" id="searchInput" placeholder="Search tables or columns... (/)">
                <span class="search-match-count" id="searchMatchCount" style="display:none;">0 matches</span>
                <div class="autocomplete-dropdown" id="autocompleteDropdown"></div>
            </div>
            <div class="control-group">
                <label>Filter:</label>
                <select id="tableFilter"><option value="">All Tables</option></select>
            </div>
            <div class="control-group">
                <button class="btn-primary" onclick="fitGraph()">Fit<span class="kbd-hint">F</span></button>
                <button class="btn-secondary" onclick="zoomIn()">+</button>
                <button class="btn-secondary" onclick="zoomOut()">-</button>
                <button class="btn-secondary" onclick="resetGraph()">Reset<span class="kbd-hint">R</span></button>
            </div>
            <div class="control-group">
                <button class="btn-secondary" onclick="collapseAllTables()">Collapse<span class="kbd-hint">C</span></button>
                <button class="btn-secondary" onclick="expandAllTables()">Expand<span class="kbd-hint">E</span></button>
            </div>
            <div class="control-group">
                <button class="btn-secondary" onclick="togglePanel()">Details<span class="kbd-hint">D</span></button>
                <button class="btn-secondary" onclick="toggleHelp()">Help<span class="kbd-hint">H</span></button>
            </div>
        </div>
        <div class="main-content">
            <div id="cy"></div>
            <div class="side-panel" id="sidePanel">
                <div class="panel-header"><h3 id="panelTitle">Select a Column</h3><button class="close-btn" onclick="closePanel()">&times;</button></div>
                <div class="panel-content" id="panelContent"><p style="color:#aaa;">Click on any column node to see its lineage.</p></div>
            </div>
        </div>
    </div>
    <div class="legend"><h4>Legend</h4>
        <div class="legend-item"><div class="legend-color source-color"></div><span>Source</span></div>
        <div class="legend-item"><div class="legend-color intermediate-color"></div><span>Intermediate</span></div>
        <div class="legend-item"><div class="legend-color target-color"></div><span>Target</span></div>
    </div>
    <div class="instructions"><h4>Quick Tips</h4><ul><li>Press <b>H</b> for help</li><li>Arrow keys to pan</li><li>Click column for lineage</li><li>Use minimap to navigate</li></ul></div>
    <div class="nav-panel collapsed" id="navPanel">
        <div class="nav-panel-header"><h4>Tables</h4></div>
        <div class="nav-panel-content" id="navPanelContent"></div>
        <div class="nav-panel-toggle" onclick="toggleNavPanel()"><span id="navToggleIcon">&#9654;</span></div>
    </div>
    <div id="minimap"><div class="minimap-header"><span>Minimap</span><span class="minimap-toggle" onclick="toggleMinimap()">_</span></div><canvas id="minimap-canvas"></canvas><div id="minimap-viewport"></div></div>
    <div class="position-indicator" id="positionIndicator"><h5>Position</h5><div class="position-text" id="positionText">Viewing all tables</div><div class="progress-bar-container"><div class="progress-bar" id="progressBar" style="width:100%;"></div></div><div class="progress-markers"><span>Source</span><span>Target</span></div></div>
    <div class="help-modal" id="helpModal">
        <div class="help-content">
            <h2><span>Keyboard Shortcuts</span><span class="help-close" onclick="toggleHelp()">&times;</span></h2>
            <div class="help-section"><h3>Navigation</h3><div class="shortcut-grid">
                <div class="shortcut-item"><span class="shortcut-key">Arrow/WASD</span><span class="shortcut-desc">Pan</span></div>
                <div class="shortcut-item"><span class="shortcut-key">+ / -</span><span class="shortcut-desc">Zoom</span></div>
                <div class="shortcut-item"><span class="shortcut-key">F</span><span class="shortcut-desc">Fit view</span></div>
                <div class="shortcut-item"><span class="shortcut-key">R</span><span class="shortcut-desc">Reset</span></div>
                <div class="shortcut-item"><span class="shortcut-key">Home/End</span><span class="shortcut-desc">First/Last table</span></div>
            </div></div>
            <div class="help-section"><h3>Tables</h3><div class="shortcut-grid">
                <div class="shortcut-item"><span class="shortcut-key">N</span><span class="shortcut-desc">Toggle nav / Next</span></div>
                <div class="shortcut-item"><span class="shortcut-key">P</span><span class="shortcut-desc">Previous table</span></div>
                <div class="shortcut-item"><span class="shortcut-key">C / E</span><span class="shortcut-desc">Collapse/Expand</span></div>
            </div></div>
            <div class="help-section"><h3>Interface</h3><div class="shortcut-grid">
                <div class="shortcut-item"><span class="shortcut-key">/ or Ctrl+F</span><span class="shortcut-desc">Search</span></div>
                <div class="shortcut-item"><span class="shortcut-key">Escape</span><span class="shortcut-desc">Clear</span></div>
                <div class="shortcut-item"><span class="shortcut-key">H / ?</span><span class="shortcut-desc">Help</span></div>
                <div class="shortcut-item"><span class="shortcut-key">M / D</span><span class="shortcut-desc">Minimap/Details</span></div>
            </div></div>
        </div>
    </div>
    <script>
        const graphData = {graph_json};
        let cy, sortedTables = [], currentTableIndex = 0, minimapCollapsed = false, collapsedTables = new Set();

        function initGraph() {{
            const elements = [];
            graphData.tables.forEach(t => elements.push({{ data: {{ id: t.id, label: t.name, type: t.type, isTable: true }}, classes: `table ${{t.type}}` }}));
            graphData.columns.forEach(c => elements.push({{ data: {{ id: c.id, label: c.column_name, parent: c.parent, table_name: c.table_name, type: c.type, isColumn: true }}, classes: `column ${{c.type}}` }}));
            graphData.edges.forEach((e, i) => elements.push({{ data: {{ id: `edge_${{i}}`, source: e.source, target: e.target, source_column: e.source_column, target_column: e.target_column, transformation: e.transformation, transformation_type: e.transformation_type }}, classes: e.transformation_type === 'DIRECT' ? 'direct' : 'transformed' }}));

            cy = cytoscape({{
                container: document.getElementById('cy'),
                elements: elements,
                style: [
                    {{ selector: 'node.table', style: {{ 'background-opacity': 0.15, 'border-width': 2, 'border-color': '#555', 'label': 'data(label)', 'text-valign': 'top', 'text-halign': 'center', 'font-size': '14px', 'font-weight': 'bold', 'color': '#4fc3f7', 'padding': '20px' }} }},
                    {{ selector: 'node.table.source', style: {{ 'border-color': '#2e7d32', 'background-color': 'rgba(27,94,32,0.15)' }} }},
                    {{ selector: 'node.table.intermediate', style: {{ 'border-color': '#546e7a', 'background-color': 'rgba(55,71,79,0.15)' }} }},
                    {{ selector: 'node.table.target', style: {{ 'border-color': '#7b1fa2', 'background-color': 'rgba(74,20,140,0.15)' }} }},
                    {{ selector: 'node.column', style: {{ 'shape': 'roundrectangle', 'width': 'label', 'height': 28, 'padding': '8px', 'background-color': '#37474f', 'border-width': 2, 'border-color': '#546e7a', 'label': 'data(label)', 'text-valign': 'center', 'text-halign': 'center', 'font-size': '11px', 'font-weight': 'bold', 'color': '#eceff1', 'cursor': 'pointer' }} }},
                    {{ selector: 'node.column.source', style: {{ 'background-color': '#1b5e20', 'border-color': '#2e7d32', 'color': '#e8f5e9' }} }},
                    {{ selector: 'node.column.target', style: {{ 'background-color': '#4a148c', 'border-color': '#7b1fa2', 'color': '#f3e5f5' }} }},
                    {{ selector: 'node.column:selected', style: {{ 'border-width': 4, 'border-color': '#ffeb3b', 'background-color': '#ffc107', 'color': '#000' }} }},
                    {{ selector: 'node.column.highlighted', style: {{ 'border-width': 4, 'border-color': '#00e5ff', 'z-index': 999 }} }},
                    {{ selector: 'node.dimmed', style: {{ 'opacity': 0.2 }} }},
                    {{ selector: 'edge', style: {{ 'width': 2, 'line-color': '#4fc3f7', 'target-arrow-color': '#4fc3f7', 'target-arrow-shape': 'triangle', 'arrow-scale': 1.2, 'curve-style': 'bezier', 'opacity': 0.7 }} }},
                    {{ selector: 'edge.transformed', style: {{ 'line-color': '#ff9800', 'target-arrow-color': '#ff9800', 'width': 3 }} }},
                    {{ selector: 'edge:selected', style: {{ 'width': 4, 'line-color': '#ffeb3b', 'target-arrow-color': '#ffeb3b', 'opacity': 1 }} }},
                    {{ selector: 'edge.highlighted', style: {{ 'width': 4, 'line-color': '#00e5ff', 'target-arrow-color': '#00e5ff', 'opacity': 1, 'z-index': 999 }} }},
                    {{ selector: 'edge.dimmed', style: {{ 'opacity': 0.1 }} }}
                ],
                layout: {{ name: 'dagre', rankDir: 'LR', nodeSep: 15, rankSep: 100, padding: 30 }},
                minZoom: 0.1, maxZoom: 4, wheelSensitivity: 0.3
            }});

            cy.on('tap', 'node.column', e => {{ showColumnLineage(e.target.data()); highlightColumnPath(e.target); }});
            cy.on('tap', 'node.table', e => showTableInfo(e.target.data()));
            cy.on('tap', e => {{ if (e.target === cy) cy.elements().removeClass('highlighted dimmed'); }});
            cy.on('viewport', updatePositionIndicator);

            document.getElementById('statTables').textContent = graphData.tables.length;
            document.getElementById('statColumns').textContent = graphData.columns.length;
            document.getElementById('statEdges').textContent = graphData.edges.length;
            populateTableFilter();
            initNavPanel();
            initMinimap();
            initAutocomplete();
            initKeyboardNav();
        }}

        function populateTableFilter() {{
            const select = document.getElementById('tableFilter');
            graphData.tables.forEach(t => {{ const o = document.createElement('option'); o.value = t.id; o.textContent = `${{t.name}} (${{t.type}})`; select.appendChild(o); }});
            select.addEventListener('change', function() {{ filterByTable(this.value); }});
        }}

        function filterByTable(tableName) {{
            if (!tableName) {{ cy.elements().removeClass('dimmed'); return; }}
            cy.elements().addClass('dimmed');
            const tableNode = cy.getElementById(tableName);
            tableNode.removeClass('dimmed');
            tableNode.children().removeClass('dimmed');
            tableNode.children().forEach(col => {{ col.connectedEdges().removeClass('dimmed'); col.connectedEdges().connectedNodes().removeClass('dimmed'); }});
        }}

        function highlightColumnPath(node) {{
            cy.elements().addClass('dimmed');
            node.removeClass('dimmed').addClass('highlighted');
            cy.getElementById(node.data('parent')).removeClass('dimmed');
            node.connectedEdges().forEach(edge => {{
                edge.removeClass('dimmed').addClass('highlighted');
                edge.connectedNodes().forEach(n => {{ n.removeClass('dimmed').addClass('highlighted'); cy.getElementById(n.data('parent') || n.id()).removeClass('dimmed'); }});
            }});
        }}

        function showColumnLineage(data) {{
            document.getElementById('sidePanel').classList.remove('hidden');
            document.getElementById('panelTitle').textContent = data.id;
            const lineage = graphData.column_lineages.find(l => `${{l.target_table}}.${{l.target_column}}` === data.id) || graphData.column_lineages.find(l => l.hops.some(h => `${{h.table_name}}.${{h.column_name}}` === data.id));
            if (!lineage) {{ document.getElementById('panelContent').innerHTML = '<div class="info-section"><p>No lineage found.</p></div>'; return; }}
            let html = `<div class="info-section"><h4>Column Info</h4><div class="info-row"><span class="info-label">Table</span><span class="info-value">${{data.table_name}}</span></div><div class="info-row"><span class="info-label">Column</span><span class="info-value">${{data.label}}</span></div><div class="info-row"><span class="info-label">Type</span><span class="info-value">${{data.type}}</span></div></div>`;
            html += `<div class="info-section"><h4>Source</h4><div class="info-row"><span class="info-label">Table</span><span class="info-value">${{lineage.ultimate_source_table}}</span></div><div class="info-row"><span class="info-label">Column</span><span class="info-value">${{lineage.ultimate_source_column}}</span></div></div>`;
            html += '<div class="lineage-path"><h4 style="color:#4fc3f7;margin-bottom:15px;">Data Flow</h4>';
            lineage.hops.forEach((hop, idx) => {{
                const hopType = idx === 0 ? 'source' : (idx === lineage.hops.length - 1 ? 'target' : 'intermediate');
                html += `<div class="hop ${{hopType}}"><div class="hop-indicator"><div class="hop-dot"></div>${{idx < lineage.hops.length - 1 ? '<div class="hop-line"></div>' : ''}}</div><div class="hop-content"><div class="hop-table">${{hop.table_name}}</div><div class="hop-column">${{hop.column_name}}</div>${{hop.transformation && hop.transformation !== hop.column_name ? `<div class="hop-transform">${{hop.transformation}}</div>` : ''}}</div></div>`;
            }});
            html += '</div>';
            document.getElementById('panelContent').innerHTML = html;
        }}

        function showTableInfo(data) {{
            document.getElementById('sidePanel').classList.remove('hidden');
            document.getElementById('panelTitle').textContent = data.label;
            const tableData = graphData.tables.find(t => t.id === data.id);
            const cols = tableData ? tableData.columns : [];
            let html = `<div class="info-section"><h4>Table Info</h4><div class="info-row"><span class="info-label">Name</span><span class="info-value">${{data.label}}</span></div><div class="info-row"><span class="info-label">Type</span><span class="info-value">${{data.type}}</span></div><div class="info-row"><span class="info-label">Columns</span><span class="info-value">${{cols.length}}</span></div></div>`;
            html += '<div class="info-section"><h4>Columns</h4>';
            cols.forEach(col => html += `<div style="padding:5px 10px;margin:3px 0;background:rgba(255,255,255,0.05);border-radius:3px;cursor:pointer;" onclick="selectColumnNode('${{data.id}}.${{col}}')">${{col}}</div>`);
            html += '</div>';
            document.getElementById('panelContent').innerHTML = html;
        }}

        function selectColumnNode(colId) {{ const node = cy.getElementById(colId); if (node.length) {{ cy.elements().unselect(); node.select(); showColumnLineage(node.data()); highlightColumnPath(node); cy.animate({{ center: {{ eles: node }}, zoom: 2 }}, {{ duration: 300 }}); }} }}

        function fitGraph() {{ cy.fit(50); }}
        function zoomIn() {{ cy.zoom(cy.zoom() * 1.3); cy.center(); }}
        function zoomOut() {{ cy.zoom(cy.zoom() / 1.3); cy.center(); }}
        function resetGraph() {{ cy.elements().removeClass('highlighted dimmed'); cy.reset(); cy.fit(50); }}
        function togglePanel() {{ document.getElementById('sidePanel').classList.toggle('hidden'); }}
        function closePanel() {{ document.getElementById('sidePanel').classList.add('hidden'); }}
        function toggleHelp() {{ document.getElementById('helpModal').classList.toggle('visible'); }}

        function initMinimap() {{
            const canvas = document.getElementById('minimap-canvas');
            const ctx = canvas.getContext('2d');
            const viewport = document.getElementById('minimap-viewport');
            canvas.width = 196; canvas.height = 126;
            function renderMinimap() {{
                if (!cy || minimapCollapsed) return;
                ctx.clearRect(0, 0, canvas.width, canvas.height);
                const bb = cy.elements().boundingBox();
                if (bb.w === 0) return;
                const scale = Math.min(canvas.width / bb.w, canvas.height / bb.h) * 0.9;
                const offsetX = (canvas.width - bb.w * scale) / 2 - bb.x1 * scale;
                const offsetY = (canvas.height - bb.h * scale) / 2 - bb.y1 * scale;
                cy.nodes('.table').forEach(node => {{
                    const pos = node.position();
                    const nbb = node.boundingBox();
                    ctx.fillStyle = node.hasClass('source') ? '#2e7d32' : node.hasClass('target') ? '#7b1fa2' : '#546e7a';
                    ctx.fillRect(pos.x * scale + offsetX - nbb.w * scale / 2, pos.y * scale + offsetY - nbb.h * scale / 2, nbb.w * scale, nbb.h * scale);
                }});
                const ext = cy.extent();
                viewport.style.left = Math.max(0, ext.x1 * scale + offsetX) + 'px';
                viewport.style.top = Math.max(24, ext.y1 * scale + offsetY + 24) + 'px';
                viewport.style.width = Math.min(canvas.width, ext.w * scale) + 'px';
                viewport.style.height = Math.min(canvas.height, ext.h * scale) + 'px';
            }}
            let isDragging = false;
            function navigateTo(e) {{
                const rect = canvas.getBoundingClientRect();
                const x = e.clientX - rect.left, y = e.clientY - rect.top;
                const bb = cy.elements().boundingBox();
                const scale = Math.min(canvas.width / bb.w, canvas.height / bb.h) * 0.9;
                const offsetX = (canvas.width - bb.w * scale) / 2 - bb.x1 * scale;
                const offsetY = (canvas.height - bb.h * scale) / 2 - bb.y1 * scale;
                cy.animate({{ center: {{ eles: cy.nodes().filter(n => Math.abs(n.position().x - (x - offsetX) / scale) < 100) }} }}, {{ duration: 200 }});
            }}
            canvas.addEventListener('mousedown', e => {{ isDragging = true; navigateTo(e); }});
            canvas.addEventListener('mousemove', e => {{ if (isDragging) navigateTo(e); }});
            document.addEventListener('mouseup', () => isDragging = false);
            cy.on('viewport layoutstop', renderMinimap);
            renderMinimap();
        }}

        function toggleMinimap() {{ minimapCollapsed = !minimapCollapsed; document.getElementById('minimap').classList.toggle('collapsed', minimapCollapsed); }}

        function initNavPanel() {{
            const groups = {{ source: [], intermediate: [], target: [] }};
            graphData.tables.forEach(t => groups[t.type] && groups[t.type].push(t));
            sortedTables = [...groups.source, ...groups.intermediate, ...groups.target];
            let html = '';
            [['source', 'Source Tables'], ['intermediate', 'Intermediate'], ['target', 'Target Tables']].forEach(([type, label]) => {{
                if (groups[type].length === 0) return;
                html += `<div class="nav-group"><div class="nav-group-header">${{label}}<span class="nav-group-count">${{groups[type].length}}</span></div>`;
                groups[type].forEach(t => html += `<div class="nav-item ${{type}}" data-table-id="${{t.id}}" onclick="navigateToTable('${{t.id}}')">${{t.name}}<span class="nav-item-badge">${{t.columns.length}}</span></div>`);
                html += '</div>';
            }});
            document.getElementById('navPanelContent').innerHTML = html;
        }}

        function toggleNavPanel() {{
            const panel = document.getElementById('navPanel');
            panel.classList.toggle('collapsed');
            document.getElementById('navToggleIcon').innerHTML = panel.classList.contains('collapsed') ? '&#9654;' : '&#9664;';
        }}

        function navigateToTable(tableId) {{
            const tableNode = cy.getElementById(tableId);
            if (tableNode.length) {{
                cy.elements().removeClass('highlighted');
                tableNode.addClass('highlighted');
                tableNode.children().addClass('highlighted');
                cy.animate({{ center: {{ eles: tableNode }}, zoom: 1.5 }}, {{ duration: 300 }});
                document.querySelectorAll('.nav-item').forEach(item => item.classList.toggle('active', item.dataset.tableId === tableId));
                currentTableIndex = sortedTables.findIndex(t => t.id === tableId);
                updatePositionIndicator();
            }}
        }}

        function navigateToNextTable() {{ if (sortedTables.length === 0) return; currentTableIndex = (currentTableIndex + 1) % sortedTables.length; navigateToTable(sortedTables[currentTableIndex].id); }}
        function navigateToPrevTable() {{ if (sortedTables.length === 0) return; currentTableIndex = (currentTableIndex - 1 + sortedTables.length) % sortedTables.length; navigateToTable(sortedTables[currentTableIndex].id); }}
        function navigateToFirstTable() {{ if (sortedTables.length > 0) {{ currentTableIndex = 0; navigateToTable(sortedTables[0].id); }} }}
        function navigateToLastTable() {{ if (sortedTables.length > 0) {{ currentTableIndex = sortedTables.length - 1; navigateToTable(sortedTables[currentTableIndex].id); }} }}

        function updatePositionIndicator() {{
            const ext = cy.extent(), bb = cy.elements().boundingBox();
            if (bb.w === 0) return;
            const progress = Math.max(0, Math.min(100, ((ext.x1 + ext.w / 2 - bb.x1) / bb.w) * 100));
            const visible = cy.nodes('.table').filter(n => n.position().x >= ext.x1 && n.position().x <= ext.x2);
            document.getElementById('positionText').textContent = `Viewing ${{visible.length}} of ${{graphData.tables.length}} tables`;
            document.getElementById('progressBar').style.width = progress + '%';
        }}

        function initAutocomplete() {{
            const input = document.getElementById('searchInput');
            const dropdown = document.getElementById('autocompleteDropdown');
            const matchCount = document.getElementById('searchMatchCount');
            input.addEventListener('input', function(e) {{
                const q = e.target.value.toLowerCase().trim();
                if (!q) {{ dropdown.classList.remove('visible'); matchCount.style.display = 'none'; cy.elements().removeClass('highlighted dimmed'); return; }}
                const tableMatches = graphData.tables.filter(t => t.name.toLowerCase().includes(q));
                const colMatches = graphData.columns.filter(c => c.column_name.toLowerCase().includes(q) || c.id.toLowerCase().includes(q));
                const total = tableMatches.length + colMatches.length;
                matchCount.textContent = `${{total}} match${{total !== 1 ? 'es' : ''}}`;
                matchCount.style.display = 'inline';
                let html = '';
                if (tableMatches.length > 0) {{ html += '<div class="autocomplete-group"><div class="autocomplete-group-header">Tables</div>'; tableMatches.slice(0, 5).forEach((t, i) => html += `<div class="autocomplete-item" onclick="navigateToTable('${{t.id}}')">${{t.name}}<span class="autocomplete-item-type">${{t.type}}</span></div>`); html += '</div>'; }}
                if (colMatches.length > 0) {{ html += '<div class="autocomplete-group"><div class="autocomplete-group-header">Columns</div>'; colMatches.slice(0, 10).forEach(c => html += `<div class="autocomplete-item" onclick="selectColumnNode('${{c.id}}')">${{c.column_name}}<span class="autocomplete-item-type">${{c.table_name}}</span></div>`); html += '</div>'; }}
                dropdown.innerHTML = html;
                dropdown.classList.toggle('visible', total > 0);
                cy.elements().addClass('dimmed');
                tableMatches.forEach(t => {{ cy.getElementById(t.id).removeClass('dimmed').addClass('highlighted'); cy.getElementById(t.id).children().removeClass('dimmed'); }});
                colMatches.forEach(c => {{ cy.getElementById(c.id).removeClass('dimmed').addClass('highlighted'); cy.getElementById(c.parent).removeClass('dimmed'); }});
            }});
            input.addEventListener('blur', () => setTimeout(() => dropdown.classList.remove('visible'), 200));
        }}

        function collapseAllTables() {{ cy.nodes('.table').forEach(t => {{ t.children().forEach(c => c.style('display', 'none')); collapsedTables.add(t.id()); }}); cy.layout({{ name: 'dagre', rankDir: 'LR', nodeSep: 15, rankSep: 100, padding: 30 }}).run(); }}
        function expandAllTables() {{ cy.nodes('.column').style('display', 'element'); collapsedTables.clear(); cy.layout({{ name: 'dagre', rankDir: 'LR', nodeSep: 15, rankSep: 100, padding: 30 }}).run(); }}

        function initKeyboardNav() {{
            document.addEventListener('keydown', function(e) {{
                if (e.target.tagName === 'INPUT') return;
                const panAmount = 50;
                switch(e.key) {{
                    case 'ArrowLeft': case 'a': case 'A': cy.panBy({{ x: panAmount, y: 0 }}); break;
                    case 'ArrowRight': case 'd': case 'D': cy.panBy({{ x: -panAmount, y: 0 }}); break;
                    case 'ArrowUp': case 'w': case 'W': cy.panBy({{ x: 0, y: panAmount }}); break;
                    case 'ArrowDown': case 's': case 'S': cy.panBy({{ x: 0, y: -panAmount }}); break;
                    case '+': case '=': zoomIn(); break;
                    case '-': case '_': zoomOut(); break;
                    case 'f': case 'F': fitGraph(); break;
                    case 'r': case 'R': resetGraph(); break;
                    case 'h': case 'H': case '?': toggleHelp(); break;
                    case 'n': case 'N': if (e.shiftKey) navigateToNextTable(); else toggleNavPanel(); break;
                    case 'p': case 'P': navigateToPrevTable(); break;
                    case 'c': case 'C': collapseAllTables(); break;
                    case 'e': case 'E': expandAllTables(); break;
                    case 'm': case 'M': toggleMinimap(); break;
                    case '/': e.preventDefault(); document.getElementById('searchInput').focus(); break;
                    case 'Escape': cy.elements().removeClass('highlighted dimmed'); document.getElementById('searchInput').value = ''; document.getElementById('autocompleteDropdown').classList.remove('visible'); document.getElementById('searchMatchCount').style.display = 'none'; document.getElementById('helpModal').classList.remove('visible'); break;
                    case 'Home': navigateToFirstTable(); break;
                    case 'End': navigateToLastTable(); break;
                }}
            }});
            document.addEventListener('keydown', function(e) {{ if ((e.ctrlKey || e.metaKey) && e.key === 'f') {{ e.preventDefault(); document.getElementById('searchInput').focus(); }} }});
        }}

        window.addEventListener('load', initGraph);
    </script>
</body>
</html>'''

    with open(output_path, 'w', encoding='utf-8') as f:
        f.write(html)

    print(f"  [FIELD GRAPH] Generated {output_path}")


def _load_relevant_schema(sql_filepath: str, combined_schema_dir: str, dialect: str) -> dict:
    """
    Load only the DDL files from _combined_schema that are relevant to the
    source tables referenced in the SQL file.  This avoids loading hundreds
    of DDL files when only a handful are needed.

    Matches database prefixes from the SQL (e.g., P_CCARDM_01, P_EDW_BASE_01)
    to files like P_CCARDM_01_DDLs.txt.
    """
    sql_filepath = _resolve_input_path(sql_filepath)
    if combined_schema_dir:
        combined_schema_dir = _resolve_input_path(combined_schema_dir)
    with open(sql_filepath, 'r', encoding='utf-8', errors='ignore') as f:
        sql_text = f.read().upper()

    # Extract database prefixes (schema.table patterns)
    db_prefixes = set()
    for m in re.finditer(r'(?:FROM|JOIN)\s+(\w+)\.(\w+)', sql_text, re.IGNORECASE):
        db_prefixes.add(m.group(1).upper())
    # Also check for SELECT * FROM schema.table
    for m in re.finditer(r'(\w+)\.(\w+)', sql_text):
        prefix = m.group(1).upper()
        # Heuristic: Teradata database prefixes typically start with P_
        if prefix.startswith('P_'):
            db_prefixes.add(prefix)

    if not db_prefixes:
        return None

    loader = DDLSchemaLoader(dialect=dialect)
    import glob as glob_module
    loaded_any = False
    for ddl_file in glob_module.glob(os.path.join(combined_schema_dir, '*.txt')):
        basename = os.path.basename(ddl_file).upper()
        for prefix in db_prefixes:
            if basename.startswith(prefix):
                try:
                    loader.load_from_file(ddl_file)
                    loaded_any = True
                except Exception:
                    pass
                break

    return loader.get_simple_schema() if loaded_any else None


def process_sql_file(filepath: str, dialect: str, schema: dict = None,
                      output_dir: str = None) -> dict:
    """
    Process a single SQL file.

    Args:
        filepath: Path to SQL file
        dialect: SQL dialect
        schema: Optional schema dict
        output_dir: Output directory

    Returns:
        Processing result dict
    """
    filepath = _resolve_input_path(filepath)
    if output_dir:
        output_dir = _resolve_output_dir(output_dir)
    with open(filepath, 'r', encoding='utf-8', errors='ignore') as f:
        sql = f.read()

    base_name = os.path.splitext(os.path.basename(filepath))[0]

    # Preprocessing: strip Teradata export artifacts before parsing.
    # Strip bare banner lines (e.g. standalone ====...====) that cause tokenizer errors.
    # Lines that contain block-comment markers are left intact.
    sql = re.sub(r'^[=]{3,}(?!.*(?:/\*|\*/)).*$', '', sql, flags=re.MULTILINE)
    # Strip line-continuation double quotes inserted by Teradata export tools
    # (procedure names split across lines as  P_SCHEMA."  \n  "PROC_NAME").
    sql = re.sub(r'"\s*\n\s*"', '', sql)

    try:
        # Detect stored procedures — they use SQLHandler instead of parse_safe
        # (same approach as the `full` command).
        sql_handler = SQLHandler(dialect=dialect, schema=schema or {})
        is_stored_procedure = sql_handler._is_stored_procedure(sql)

        if is_stored_procedure:
            # Extract volatile table schema for lineage resolution
            volatile_schema = sql_handler.extract_volatile_table_schema(sql)
            if volatile_schema:
                sql_handler = SQLHandler(dialect=dialect, schema={**(schema or {}), **volatile_schema})

            handler_result = sql_handler.process_content(sql, filepath)
            all_elements = [stmt.elements for stmt in handler_result.statements if stmt.elements]
            all_lineage = [stmt.lineage for stmt in handler_result.statements if stmt.lineage]
            statement_count = len(handler_result.statements)
        else:
            # Regular SQL: use parse_safe
            generator = SQLASTGenerator(dialect=dialect)
            result = generator.parse_safe(sql)

            if not result.success:
                return {
                    'file': filepath,
                    'success': False,
                    'errors': result.metadata.error_messages
                }

            all_elements = []
            all_lineage = []
            for stmt in result.statements:
                extractor = SQLElementExtractor(stmt, dialect)
                all_elements.append(extractor.extract_all())
                lineage_extractor = LineageExtractor(schema=schema, dialect=dialect)
                all_lineage.append(lineage_extractor.extract_lineage(stmt.sql(dialect=dialect)))
            statement_count = len(result.statements)

        # Generate outputs
        if output_dir:
            os.makedirs(output_dir, exist_ok=True)

            # Save AST JSON (only for regular SQL — SP handler doesn't expose raw AST)
            if not is_stored_procedure:
                ast_path = safe_join(str(output_dir), f"{base_name}_ast.json")
                try:
                    with open(ast_path, 'w', encoding='utf-8') as f:
                        json.dump({
                            'metadata': result.metadata.to_dict(),
                            'statements': [generator.to_json(stmt) for stmt in result.statements]
                        }, f, indent=2, default=str)
                except Exception:
                    pass  # Skip AST if serialization fails

            # Save elements JSON
            elements_path = safe_join(str(output_dir), f"{base_name}_elements.json")
            with open(elements_path, 'w', encoding='utf-8') as f:
                json.dump([e.to_dict() for e in all_elements], f, indent=2)

            # Save lineage CSV
            if all_lineage:
                from lineage.lineage_graph import LineageGraph
                merged_graph = LineageGraph()
                for graph in all_lineage:
                    merged_graph.merge(graph)

                csv_path = safe_join(str(output_dir), f"{base_name}_lineage.csv")
                doc_gen = SourceTargetMappingGenerator(merged_graph, all_elements[0] if all_elements else None, all_element_catalogs=all_elements)
                doc_gen.generate_csv(csv_path)

        return {
            'file': filepath,
            'success': True,
            'statement_count': statement_count,
            'elements_count': sum(
                len(e.case_statements) + len(e.joins) + len(e.functions) + len(e.ctes)
                for e in all_elements
            )
        }

    except Exception as e:
        return {
            'file': filepath,
            'success': False,
            'errors': [str(e)]
        }


def process_directory(input_dir: str, output_dir: str, dialect: str,
                       schema_dir: str = None, patterns: list = None) -> list:
    """
    Process all SQL files in a directory.

    Args:
        input_dir: Input directory
        output_dir: Output directory
        dialect: SQL dialect
        schema_dir: Optional directory with DDL files
        patterns: File patterns to match

    Returns:
        List of processing results
    """
    input_dir = _resolve_input_path(input_dir)
    output_dir = _resolve_output_dir(output_dir)
    if schema_dir:
        schema_dir = _resolve_input_path(schema_dir)
    if patterns is None:
        patterns = ['*.sql', '*.txt']

    # Load schema if provided
    schema = None
    if schema_dir:
        loader = DDLSchemaLoader(dialect=dialect)
        schema = loader.load_from_directory(schema_dir)

    # Find files
    files = []
    for pattern in patterns:
        files.extend(glob.glob(os.path.join(input_dir, '**', pattern), recursive=True))

    # Process each file
    results = []
    for filepath in files:
        print(f"Processing: {filepath}")
        result = process_sql_file(filepath, dialect, schema, output_dir)
        results.append(result)

        if result['success']:
            print(f"  Success: {result['statement_count']} statements")
        else:
            print(f"  Failed: {result.get('errors', ['Unknown error'])}")

    return results


def process_with_review(filepath: str, dialect: str, schema: dict = None,
                        output_dir: str = None) -> dict:
    """
    Process SQL file with code review and comprehensive output.

    Args:
        filepath: Path to SQL file
        dialect: SQL dialect
        schema: Optional schema dict
        output_dir: Output directory

    Returns:
        Processing result dict with review info
    """
    filepath = _resolve_input_path(filepath)
    if output_dir:
        output_dir = _resolve_output_dir(output_dir)
    with open(filepath, 'r', encoding='utf-8', errors='ignore') as f:
        sql = f.read()

    base_name = os.path.splitext(os.path.basename(filepath))[0]

    try:
        # Parse
        generator = SQLASTGenerator(dialect=dialect)
        result = generator.parse_safe(sql)

        if not result.success:
            return {
                'file': filepath,
                'success': False,
                'errors': result.metadata.error_messages
            }

        # Process each statement
        all_elements = []
        all_lineage = []

        for stmt in result.statements:
            # Extract elements
            extractor = SQLElementExtractor(stmt, dialect)
            elements = extractor.extract_all()
            all_elements.append(elements)

            # Extract lineage
            lineage_extractor = LineageExtractor(schema=schema, dialect=dialect)
            lineage = lineage_extractor.extract_lineage(stmt.sql(dialect=dialect))
            all_lineage.append(lineage)

        # Review with CodeReviewerAgent
        reviewer = CodeReviewerAgent(dialect=dialect)
        review_results = []

        for i, (stmt, elements, lineage) in enumerate(zip(result.statements, all_elements, all_lineage)):
            stmt_sql = stmt.sql(dialect=dialect)
            review = reviewer.review_lineage(stmt_sql, lineage, elements)
            review_results.append(review)

            # If issues found, attempt correction
            if not review.is_valid or review.missing_columns:
                corrected_lineage, corrected_elements = reviewer._attempt_corrections(
                    stmt_sql, stmt, lineage, elements, review
                )
                all_lineage[i] = corrected_lineage
                all_elements[i] = corrected_elements

        # Generate outputs
        if output_dir:
            os.makedirs(output_dir, exist_ok=True)

            # Save AST JSON
            ast_path = safe_join(str(output_dir), f"{base_name}_ast.json")
            try:
                with open(ast_path, 'w', encoding='utf-8') as f:
                    json.dump({
                        'metadata': result.metadata.to_dict(),
                        'statements': [generator.to_json(stmt) for stmt in result.statements]
                    }, f, indent=2, default=str)
            except Exception:
                pass

            # Save elements JSON
            elements_path = safe_join(str(output_dir), f"{base_name}_elements.json")
            with open(elements_path, 'w', encoding='utf-8') as f:
                json.dump([e.to_dict() for e in all_elements], f, indent=2)

            # Save comprehensive lineage CSV (with English explanations)
            if all_lineage:
                from lineage.lineage_graph import LineageGraph
                merged_graph = LineageGraph()
                for graph in all_lineage:
                    merged_graph.merge(graph)

                csv_path = safe_join(str(output_dir), f"{base_name}_lineage_comprehensive.csv")
                doc_gen = SourceTargetMappingGenerator(merged_graph, all_elements[0] if all_elements else None, all_element_catalogs=all_elements)
                doc_gen.generate_comprehensive_csv(csv_path)

                # Also save standard lineage CSV
                std_csv_path = safe_join(str(output_dir), f"{base_name}_lineage.csv")
                doc_gen.generate_csv(std_csv_path)

            # Save review report
            review_path = safe_join(str(output_dir), f"{base_name}_review.txt")
            with open(review_path, 'w', encoding='utf-8') as f:
                for i, review in enumerate(review_results):
                    f.write(f"\n{'='*60}\n")
                    f.write(f"STATEMENT {i+1} REVIEW\n")
                    f.write(f"{'='*60}\n")
                    f.write(review.summary)

        # Aggregate review stats
        total_issues = sum(len(r.issues) for r in review_results)
        all_valid = all(r.is_valid for r in review_results)

        return {
            'file': filepath,
            'success': True,
            'statement_count': len(result.statements),
            'elements_count': sum(
                len(e.case_statements) + len(e.joins) + len(e.functions) + len(e.ctes)
                for e in all_elements
            ),
            'review_passed': all_valid,
            'review_issues': total_issues,
            'missing_columns': sum(len(r.missing_columns) for r in review_results)
        }

    except Exception as e:
        return {
            'file': filepath,
            'success': False,
            'errors': [str(e)]
        }


def batch_with_review(input_dir: str, output_dir: str, dialect: str,
                      schema_dir: str = None, patterns: list = None) -> list:
    """
    Process all SQL files with review and comprehensive output.

    Args:
        input_dir: Input directory
        output_dir: Output directory
        dialect: SQL dialect
        schema_dir: Optional directory with DDL files
        patterns: File patterns to match

    Returns:
        List of processing results
    """
    input_dir = _resolve_input_path(input_dir)
    output_dir = _resolve_output_dir(output_dir)
    if schema_dir:
        schema_dir = _resolve_input_path(schema_dir)
    if patterns is None:
        patterns = ['*.sql', '*.txt']

    # Load schema if provided
    schema = None
    if schema_dir:
        loader = DDLSchemaLoader(dialect=dialect)
        schema = loader.load_from_directory(schema_dir)

    # Find files
    files = []
    for pattern in patterns:
        files.extend(glob.glob(os.path.join(input_dir, '**', pattern), recursive=True))

    # Process each file
    results = []
    for filepath in files:
        print(f"\nProcessing with review: {filepath}")
        result = process_with_review(filepath, dialect, schema, output_dir)
        results.append(result)

        if result['success']:
            print(f"  Success: {result['statement_count']} statements")
            print(f"  Review: {'PASSED' if result.get('review_passed') else 'ISSUES FOUND'}")
            if result.get('review_issues', 0) > 0:
                print(f"  Issues: {result['review_issues']}")
            if result.get('missing_columns', 0) > 0:
                print(f"  Missing columns corrected: {result['missing_columns']}")
        else:
            print(f"  Failed: {result.get('errors', ['Unknown error'])}")

    return results


def _resolve_project_path(raw: str, label: str = "path") -> str:
    """Resolve a CLI-supplied path and reject traversal outside the project root.

    Canonicalises the path (collapsing ``..``) then verifies it remains within
    the SQLReverseEngineering project boundary so that CLI arguments cannot be
    used to read or write files at arbitrary filesystem locations.
    """
    from pathlib import Path
    resolved = Path(raw).resolve()
    project_root = Path(TOOLS_DIR).resolve().parent.parent.parent
    try:
        resolved.relative_to(project_root)
    except ValueError:
        print(
            f"Error: {label} '{raw}' resolves to '{resolved}', which is outside "
            f"the allowed project directory '{project_root}'.",
            file=sys.stderr,
        )
        sys.exit(1)
    return str(resolved)


def _resolve_output_dir(raw: str) -> str:
    return _resolve_project_path(raw, label="output path")


def _resolve_input_path(raw: str) -> str:
    from pathlib import Path
    resolved = Path(raw).resolve()
    return safe_join(str(resolved.parent), secure_filename(resolved.name))


def main():
    """Main CLI entry point."""
    parser = argparse.ArgumentParser(
        description='SQL Reverse Engineering CLI',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # Process single file
  python cli.py process --input query.sql --dialect teradata --output lineage.csv

  # Process directory
  python cli.py batch --input ./sql_files --output ./output --dialect teradata

  # Process with code review (comprehensive output with English explanations)
  python cli.py review --input query.sql --dialect teradata --output ./output

  # Batch process with review
  python cli.py batch-review --input ./sql_files --output ./output --dialect teradata

  # Generate visual lineage diagram (interactive HTML)
  python cli.py visualize --input query.sql --output lineage.html --format html

  # Generate visual lineage as SVG
  python cli.py visualize --input query.sql --output lineage.svg --format svg

  # Generate comprehensive HTML documentation (like .CHM)
  python cli.py docs --input query.sql --output documentation.html --title "My SQL Lineage"

  # Generate structured multi-sheet Excel (with join/filter conditions in separate tabs)
  python cli.py excel --input query.sql --output lineage.xlsx

  # Generate ALL outputs at once (CSV, Excel, HTML docs, visualization)
  python cli.py full --input query.sql --output ./output --dialect teradata

  # Generate ALL outputs with dynamic SQL analysis
  python cli.py full --input stored_proc.sql --output ./output --dialect tsql --dynamic-sql

  # Analyze dynamic SQL in a stored procedure
  python cli.py dynamic-sql --input stored_proc.sql --output ./output --dialect tsql

  # Analyze dynamic SQL and extract lineage from expanded SQL
  python cli.py dynamic-sql --input stored_proc.sql --output ./output --dialect tsql --expand --lineage

  # Parse and show AST
  python cli.py parse --input query.sql --dialect teradata

  # Extract CASE statements
  python cli.py cases --input query.sql --dialect teradata

  # Process multiple files (DDL, Views, SQL) and build AST repository
  python cli.py multi-file --input ./input_files --output ./output --dialect teradata

  # Build cross-file end-to-end lineage
  python cli.py cross-file --input ./input_files --output ./output --dialect teradata

  # Recursively verify and correct lineage extraction
  python cli.py verify --input query.sql --output ./output --dialect teradata
        """
    )

    subparsers = parser.add_subparsers(dest='command', help='Command')

    # Process command
    process_parser = subparsers.add_parser('process', help='Process a single SQL file')
    process_parser.add_argument('--input', '-i', required=True, help='Input SQL file')
    process_parser.add_argument('--output', '-o', required=True, help='Output CSV file')
    process_parser.add_argument('--dialect', '-d', default='teradata', help='SQL dialect')
    process_parser.add_argument('--schema-dir', help='Directory with DDL files for schema')

    # Batch command
    batch_parser = subparsers.add_parser('batch', help='Process multiple SQL files')
    batch_parser.add_argument('--input', '-i', required=True, help='Input directory')
    batch_parser.add_argument('--output', '-o', required=True, help='Output directory')
    batch_parser.add_argument('--dialect', '-d', default='teradata', help='SQL dialect')
    batch_parser.add_argument('--schema-dir', help='Directory with DDL files')
    batch_parser.add_argument('--pattern', nargs='+', default=['*.sql', '*.txt'], help='File patterns')
    batch_parser.add_argument('--dynamic-sql', action='store_true', help='Enable dynamic SQL analysis')
    batch_parser.add_argument('--multi-expert', action='store_true', help='Use multi-expert architecture for dynamic SQL')

    # Parse command
    parse_parser = subparsers.add_parser('parse', help='Parse SQL and show AST')
    parse_parser.add_argument('--input', '-i', required=True, help='Input SQL file')
    parse_parser.add_argument('--dialect', '-d', default='teradata', help='SQL dialect')
    parse_parser.add_argument('--format', '-f', choices=['json', 'yaml'], default='json', help='Output format')

    # Cases command
    cases_parser = subparsers.add_parser('cases', help='Extract CASE statements')
    cases_parser.add_argument('--input', '-i', required=True, help='Input SQL file')
    cases_parser.add_argument('--dialect', '-d', default='teradata', help='SQL dialect')

    # Lineage command
    lineage_parser = subparsers.add_parser('lineage', help='Extract lineage for specific column')
    lineage_parser.add_argument('--input', '-i', required=True, help='Input SQL file')
    lineage_parser.add_argument('--column', '-c', required=True, help='Column name')
    lineage_parser.add_argument('--dialect', '-d', default='teradata', help='SQL dialect')

    # Server command
    server_parser = subparsers.add_parser('server', help='Start REST API server')
    server_parser.add_argument('--host', default='0.0.0.0', help='Host to bind')
    server_parser.add_argument('--port', '-p', type=int, default=8000, help='Port')

    # Review command - single file with comprehensive output
    review_parser = subparsers.add_parser('review', help='Process with code review and comprehensive output')
    review_parser.add_argument('--input', '-i', required=True, help='Input SQL file')
    review_parser.add_argument('--output', '-o', required=True, help='Output directory')
    review_parser.add_argument('--dialect', '-d', default='teradata', help='SQL dialect')
    review_parser.add_argument('--schema-dir', help='Directory with DDL files for schema')

    # Batch-review command - multiple files with review
    batch_review_parser = subparsers.add_parser('batch-review', help='Batch process with code review')
    batch_review_parser.add_argument('--input', '-i', required=True, help='Input directory')
    batch_review_parser.add_argument('--output', '-o', required=True, help='Output directory')
    batch_review_parser.add_argument('--dialect', '-d', default='teradata', help='SQL dialect')
    batch_review_parser.add_argument('--schema-dir', help='Directory with DDL files')
    batch_review_parser.add_argument('--pattern', nargs='+', default=['*.sql', '*.txt'], help='File patterns')

    # Visualize command - generate visual lineage
    visualize_parser = subparsers.add_parser('visualize', help='Generate visual lineage diagram')
    visualize_parser.add_argument('--input', '-i', required=True, help='Input SQL file')
    visualize_parser.add_argument('--output', '-o', required=True, help='Output file path')
    visualize_parser.add_argument('--dialect', '-d', default='teradata', help='SQL dialect')
    visualize_parser.add_argument('--format', '-f', choices=['tree', 'html', 'svg', 'pdf', 'png', 'mermaid'],
                                   default='tree', help='Output format (tree=collapsible table tree, html=network graph)')
    visualize_parser.add_argument('--schema-dir', help='Directory with DDL files for schema')
    visualize_parser.add_argument('--title', '-t', default='Data Lineage Tree', help='Title for visualization')

    # Docs command - generate comprehensive HTML documentation
    docs_parser = subparsers.add_parser('docs', help='Generate comprehensive HTML help documentation')
    docs_parser.add_argument('--input', '-i', required=True, help='Input SQL file')
    docs_parser.add_argument('--output', '-o', required=True, help='Output HTML file')
    docs_parser.add_argument('--dialect', '-d', default='teradata', help='SQL dialect')
    docs_parser.add_argument('--title', '-t', default='SQL Lineage Documentation', help='Document title')
    docs_parser.add_argument('--schema-dir', help='Directory with DDL files for schema')

    # Excel command - generate structured multi-sheet Excel
    excel_parser = subparsers.add_parser('excel', help='Generate structured multi-sheet Excel output')
    excel_parser.add_argument('--input', '-i', required=True, help='Input SQL file')
    excel_parser.add_argument('--output', '-o', required=True, help='Output Excel file')
    excel_parser.add_argument('--dialect', '-d', default='teradata', help='SQL dialect')
    excel_parser.add_argument('--schema-dir', help='Directory with DDL files for schema')

    # Batch-full command - generate ALL outputs for multiple files
    batch_full_parser = subparsers.add_parser('batch-full',
        help='Process multiple SQL files with FULL output (CSV, Excel, HTML, graphs, dynamic SQL)')
    batch_full_parser.add_argument('--input', '-i', required=True, help='Input directory')
    batch_full_parser.add_argument('--output', '-o', required=True, help='Output directory')
    batch_full_parser.add_argument('--dialect', '-d', default='teradata', help='SQL dialect')
    batch_full_parser.add_argument('--schema-dir', help='Directory with DDL files')
    batch_full_parser.add_argument('--pattern', nargs='+', default=['*.sql', '*.txt'], help='File patterns')
    batch_full_parser.add_argument('--dynamic-sql', action='store_true', help='Enable dynamic SQL analysis')
    batch_full_parser.add_argument('--multi-expert', action='store_true', help='Use multi-expert architecture for dynamic SQL')
    batch_full_parser.add_argument('--title', '-t', default=None, help='Title prefix for documentation')
    batch_full_parser.add_argument('--review', action='store_true', help='After generation, run AI accuracy review and interactive refinement on each STTM')

    # Full command - generate ALL outputs at once
    full_parser = subparsers.add_parser('full', help='Generate ALL outputs (CSV, Excel, HTML docs, visualization)')
    full_parser.add_argument('--input', '-i', required=True, help='Input SQL file')
    full_parser.add_argument('--output', '-o', required=True, help='Output directory')
    full_parser.add_argument('--dialect', '-d', default='teradata', help='SQL dialect')
    full_parser.add_argument('--schema-dir', help='Directory with DDL files for schema')
    full_parser.add_argument('--title', '-t', default=None, help='Title for HTML documentation')
    full_parser.add_argument('--dynamic-sql', action='store_true', help='Enable dynamic SQL detection and expansion')
    full_parser.add_argument('--multi-expert', action='store_true', help='Use multi-expert architecture for dynamic SQL')
    full_parser.add_argument('--review', action='store_true', help='After generation, run AI accuracy review and interactive refinement on the STTM')

    # Dynamic SQL command - analyze and expand dynamic SQL
    dynamic_sql_parser = subparsers.add_parser('dynamic-sql', help='Analyze and expand dynamic SQL in stored procedures')
    dynamic_sql_parser.add_argument('--input', '-i', required=True, help='Input SQL file')
    dynamic_sql_parser.add_argument('--output', '-o', required=True, help='Output directory')
    dynamic_sql_parser.add_argument('--dialect', '-d', default='teradata', help='SQL dialect')
    dynamic_sql_parser.add_argument('--expand', action='store_true', help='Output expanded SQL with dynamic parts inline')
    dynamic_sql_parser.add_argument('--lineage', action='store_true', help='Extract lineage from reconstructed dynamic SQL')
    dynamic_sql_parser.add_argument('--multi-expert', action='store_true', help='Use multi-expert architecture with parallel execution and refinement')
    dynamic_sql_parser.add_argument('--verbose', '-v', action='store_true', help='Show detailed expert outputs and provenance')

    # Multi-file processing command
    multi_parser = subparsers.add_parser('multi-file',
        help='Process multiple files (DDL, Views, SQL) and build AST repository')
    multi_parser.add_argument('--input', '-i', required=True,
        help='Input directory containing DDL, View, and SQL files')
    multi_parser.add_argument('--output', '-o', required=True,
        help='Output directory for AST repository and schema')
    multi_parser.add_argument('--dialect', '-d', default='teradata',
        help='SQL dialect')
    multi_parser.add_argument('--pattern', nargs='+',
        default=['*.ddl', '*.vw', '*.sql', '*.txt'],
        help='File patterns to process')

    # Cross-file lineage command
    cross_parser = subparsers.add_parser('cross-file',
        help='Build cross-file end-to-end lineage from multiple SQL files')
    cross_parser.add_argument('--input', '-i', required=True,
        help='Input directory containing SQL files')
    cross_parser.add_argument('--output', '-o', required=True,
        help='Output directory for lineage outputs')
    cross_parser.add_argument('--dialect', '-d', default='teradata',
        help='SQL dialect')
    cross_parser.add_argument('--pattern', nargs='+',
        default=['*.ddl', '*.vw', '*.sql', '*.txt'],
        help='File patterns to process')

    # Recursive verification command
    verify_parser = subparsers.add_parser('verify',
        help='Recursively verify and correct lineage extraction')
    verify_parser.add_argument('--input', '-i', required=True,
        help='Input SQL file')
    verify_parser.add_argument('--output', '-o',
        help='Output directory for verification report')
    verify_parser.add_argument('--dialect', '-d', default='teradata',
        help='SQL dialect')
    verify_parser.add_argument('--schema-dir',
        help='Directory with DDL files for schema')

    # Expert-analyze command - Multi-expert architecture
    expert_parser = subparsers.add_parser('expert-analyze',
        help='Analyze SQL using multi-expert architecture (structure, field mapping, operators)')
    expert_parser.add_argument('--input', '-i', required=True,
        help='Input SQL file')
    expert_parser.add_argument('--output', '-o', required=True,
        help='Output directory')
    expert_parser.add_argument('--dialect', '-d', default='teradata',
        help='SQL dialect')
    expert_parser.add_argument('--experts', nargs='+',
        default=['all'],
        choices=['all', 'structure', 'field', 'operator', 'integration', 'review'],
        help='Which experts to run')
    expert_parser.add_argument('--parallel', action='store_true', default=True,
        help='Run experts in parallel')
    expert_parser.add_argument('--verify', action='store_true',
        help='Run enhanced verification after analysis')

    args = parser.parse_args()

    # Resolve all CLI-supplied paths to canonical absolute forms so that every
    # subcommand is protected against path traversal via `..` sequences or
    # absolute-path overrides, without needing per-command fixes.
    if getattr(args, 'input', None):
        args.input = _resolve_input_path(args.input)
    if getattr(args, 'output', None):
        args.output = _resolve_output_dir(args.output)
    if getattr(args, 'schema_dir', None):
        args.schema_dir = _resolve_input_path(args.schema_dir)

    if not args.command:
        parser.print_help()
        return

    if args.command == 'process':
        # Load schema if provided
        schema = None
        if args.schema_dir:
            loader = DDLSchemaLoader(dialect=args.dialect)
            schema = loader.load_from_directory(args.schema_dir)

        with open(args.input, 'r', encoding='utf-8', errors='ignore') as f:
            sql = f.read()

        # Parse
        generator = SQLASTGenerator(dialect=args.dialect)
        ast = generator.parse(sql)

        # Extract elements
        extractor = SQLElementExtractor(ast, args.dialect)
        elements = extractor.extract_all()

        # Extract lineage
        lineage_extractor = LineageExtractor(schema=schema, dialect=args.dialect)
        lineage = lineage_extractor.extract_lineage(sql)

        # Generate CSV
        doc_gen = SourceTargetMappingGenerator(lineage, elements)
        doc_gen.generate_csv(args.output)

        print(f"Generated: {args.output}")
        print(f"Lineage edges: {len(lineage.edges)}")
        print(f"CASE statements: {len(elements.case_statements)}")
        print(f"JOINs: {len(elements.joins)}")
        print(f"CTEs: {len(elements.ctes)}")

    elif args.command == 'batch':
        args.input = _resolve_input_path(args.input)
        args.output = _resolve_output_dir(args.output)
        results = process_directory(
            args.input, args.output, args.dialect,
            args.schema_dir, args.pattern
        )

        success = sum(1 for r in results if r['success'])
        print(f"\nProcessed {len(results)} files: {success} success, {len(results) - success} failed")

        # Dynamic SQL analysis if enabled
        if getattr(args, 'dynamic_sql', False):
            use_multi_expert = getattr(args, 'multi_expert', False)
            mode_str = "Multi-Expert" if use_multi_expert else "Sequential"
            print(f"\n{'='*60}")
            print(f"DYNAMIC SQL ANALYSIS ({mode_str} mode)")
            print(f"{'='*60}")

            try:
                from dynamic_sql import DynamicSQLAnalyzer
                import glob as glob_module

                # Find all SQL files
                all_files = []
                for pattern in args.pattern:
                    all_files.extend(glob_module.glob(os.path.join(args.input, '**', pattern), recursive=True))

                dynamic_results = []
                for filepath in all_files:
                    _fp_abs = os.path.abspath(filepath)
                    filepath = safe_join(os.path.dirname(_fp_abs) or ".", secure_filename(os.path.basename(_fp_abs)))
                    base_name = os.path.splitext(os.path.basename(filepath))[0]
                    try:
                        with open(filepath, 'r', encoding='utf-8', errors='ignore') as f:
                            sql = f.read()

                        analyzer = DynamicSQLAnalyzer(dialect=args.dialect, use_multi_expert=use_multi_expert)
                        result = analyzer.analyze(sql)

                        if result.has_dynamic_sql():
                            # Save analysis
                            analysis_path = safe_join(str(args.output), f"{base_name}_dynamic_sql.json")
                            with open(analysis_path, 'w', encoding='utf-8') as f:
                                json.dump(result.to_dict(), f, indent=2)

                            # Save multi-expert details
                            if use_multi_expert:
                                details = analyzer.get_multi_expert_details()
                                if details:
                                    expert_path = safe_join(str(args.output), f"{base_name}_multi_expert.json")
                                    with open(expert_path, 'w', encoding='utf-8') as f:
                                        json.dump(details, f, indent=2)

                            dynamic_results.append({
                                'file': filepath,
                                'patterns': len(result.detected_patterns),
                                'fully_resolved': len(result.fully_resolved),
                                'partially_resolved': len(result.partially_resolved),
                                'confidence': details['combined_confidence'] if use_multi_expert and details else None
                            })
                            print(f"  [DYNAMIC] {base_name}: {len(result.detected_patterns)} patterns found")

                    except Exception as e:
                        print(f"  [ERROR] {base_name}: {e}")

                # Summary
                if dynamic_results:
                    print(f"\nDynamic SQL Summary:")
                    print(f"  Files with dynamic SQL: {len(dynamic_results)}")
                    total_patterns = sum(r['patterns'] for r in dynamic_results)
                    total_resolved = sum(r['fully_resolved'] for r in dynamic_results)
                    print(f"  Total patterns: {total_patterns}")
                    print(f"  Fully resolved: {total_resolved}")
                else:
                    print("\nNo dynamic SQL patterns found in any files.")

            except ImportError as e:
                print(f"Error: Dynamic SQL module not available: {e}")

    elif args.command == 'parse':
        with open(args.input, 'r', encoding='utf-8', errors='ignore') as f:
            sql = f.read()

        generator = SQLASTGenerator(dialect=args.dialect)
        ast = generator.parse(sql)

        if args.format == 'json':
            print(json.dumps(generator.to_json(ast), indent=2))
        else:
            print(generator.to_yaml(ast))

    elif args.command == 'cases':
        with open(args.input, 'r', encoding='utf-8', errors='ignore') as f:
            sql = f.read()

        generator = SQLASTGenerator(dialect=args.dialect)
        ast = generator.parse(sql)
        extractor = SQLElementExtractor(ast, args.dialect)
        elements = extractor.extract_all()

        for i, case in enumerate(elements.case_statements, 1):
            print(f"\n=== CASE Statement {i} ===")
            if case.output_alias:
                print(f"Output: {case.output_alias}")
            print(f"SQL: {case.sql_text}")
            print("\nBranches:")
            for j, branch in enumerate(case.branches, 1):
                print(f"  {j}. WHEN {branch.condition}")
                print(f"     THEN {branch.result}")
            if case.else_result:
                print(f"  ELSE {case.else_result}")

    elif args.command == 'lineage':
        with open(args.input, 'r', encoding='utf-8', errors='ignore') as f:
            sql = f.read()

        extractor = LineageExtractor(dialect=args.dialect)
        sources = extractor.extract_lineage_for_column(sql, args.column)

        print(f"Lineage for column: {args.column}")
        print("Sources:")
        for source in sources:
            print(f"  - {source.qualified_name()}")

    elif args.command == 'server':
        from agent_interface.api import run_server
        print(f"Starting server on {args.host}:{args.port}")
        run_server(args.host, args.port)

    elif args.command == 'review':
        # Load schema if provided
        args.input = _resolve_input_path(args.input)
        args.output = _resolve_output_dir(args.output)
        schema = None
        if args.schema_dir:
            loader = DDLSchemaLoader(dialect=args.dialect)
            schema = loader.load_from_directory(args.schema_dir)

        result = process_with_review(args.input, args.dialect, schema, args.output)

        if result['success']:
            print(f"\nProcessed: {args.input}")
            print(f"Statements: {result['statement_count']}")
            print(f"Elements: {result['elements_count']}")
            print(f"Review: {'PASSED' if result.get('review_passed') else 'ISSUES FOUND'}")
            if result.get('review_issues', 0) > 0:
                print(f"Issues found: {result['review_issues']}")
            if result.get('missing_columns', 0) > 0:
                print(f"Missing columns corrected: {result['missing_columns']}")
            print(f"\nOutput files in: {args.output}")
            print("  - *_lineage_comprehensive.csv (with English explanations)")
            print("  - *_lineage.csv (standard format)")
            print("  - *_review.txt (review report)")
            print("  - *_elements.json")
            print("  - *_ast.json")
        else:
            print(f"Failed: {result.get('errors', ['Unknown error'])}")

    elif args.command == 'batch-review':
        results = batch_with_review(
            args.input, args.output, args.dialect,
            args.schema_dir, args.pattern
        )

        success = sum(1 for r in results if r['success'])
        reviewed = sum(1 for r in results if r.get('review_passed'))
        total_issues = sum(r.get('review_issues', 0) for r in results)

        print(f"\n{'='*60}")
        print("BATCH REVIEW SUMMARY")
        print(f"{'='*60}")
        print(f"Total files processed: {len(results)}")
        print(f"Successful: {success}")
        print(f"Failed: {len(results) - success}")
        print(f"Review passed: {reviewed}")
        print(f"Total issues found: {total_issues}")
        print(f"\nOutput files in: {args.output}")

    elif args.command == 'batch-full':
        # Comprehensive batch processing with ALL outputs
        import glob as glob_module

        use_multi_expert = getattr(args, 'multi_expert', False)
        use_dynamic_sql = getattr(args, 'dynamic_sql', False)

        print(f"\n{'='*70}")
        print("BATCH FULL OUTPUT GENERATION")
        if use_dynamic_sql:
            mode_str = "Multi-Expert" if use_multi_expert else "Sequential"
            print(f"(Dynamic SQL: {mode_str} mode)")
        print(f"{'='*70}")

        # Load schema if provided or auto-detect from Schema folder
        schema = None
        schema_source = None
        if args.schema_dir:
            loader = DDLSchemaLoader(dialect=args.dialect)
            schema = loader.load_from_directory(args.schema_dir)
            schema_source = args.schema_dir
        else:
            loader = DDLSchemaLoader(dialect=args.dialect)
            # Auto-detect Schema folder within input directory
            auto_schema_dir = os.path.join(args.input, "Schema")
            if os.path.isdir(auto_schema_dir):
                schema = loader.load_from_directory(auto_schema_dir)
                schema_source = auto_schema_dir

        if schema_source:
            print(f"Loaded schema from: {schema_source} ({len(schema)} tables)")

        # Create output directory
        args.output = _resolve_output_dir(args.output)
        os.makedirs(args.output, exist_ok=True)

        # Find all SQL files
        all_files = []
        for pattern in args.pattern:
            all_files.extend(glob_module.glob(os.path.join(args.input, '**', pattern), recursive=True))

        print(f"Found {len(all_files)} files to process\n")

        results_summary = []

        # Collect per-file lineage data for end-to-end processing
        per_file_lineage_data = {}  # filepath -> (merged_graph, target_table, source_tables)
        
        # Collect per-table metadata for volatile tables (DML, JOIN, WHERE specific to each table)
        volatile_table_metadata = {}  # table_name -> {dml_operation, join_conditions, where_conditions, sttm}

        for file_idx, filepath in enumerate(all_files, 1):
            _fp_abs = os.path.abspath(filepath)
            filepath = safe_join(os.path.dirname(_fp_abs) or ".", secure_filename(os.path.basename(_fp_abs)))
            base_name = os.path.splitext(os.path.basename(filepath))[0]
            title = f"{args.title or base_name} Lineage Documentation"

            print(f"\n[{file_idx}/{len(all_files)}] Processing: {os.path.basename(filepath)}")
            print("-" * 50)

            try:
                with open(filepath, 'r', encoding='utf-8', errors='ignore') as f:
                    sql = f.read()

                # Strip banner/header lines (e.g., ====... VIEW: name ====...)
                # Preserve lines containing comment markers (/* or */) so block
                # comments like /*====...====*/ are not broken.
                sql = re.sub(r'^[=]{3,}(?!.*(?:/\*|\*/)).*$', '', sql, flags=re.MULTILINE)
                sql = re.sub(r'^\s*VIEW:\s+.*$', '', sql, flags=re.MULTILINE)

                # Strip line-continuation double quotes from Teradata export tools.
                # Lines ending with " and the next starting with " are rejoined so
                # split tokens like AF.AGM"\n"T_FEATURE_AMT become AF.AGMT_FEATURE_AMT.
                sql = re.sub(r'"\s*\n\s*"', '', sql)

                # Preprocess: Handle GO batch separators for T-SQL
                sql_batches = []
                if args.dialect.lower() == 'tsql' and re.search(r'\nGO\s*\n', sql, re.IGNORECASE):
                    # Split by GO and find procedure/query batches
                    batches = re.split(r'\nGO\s*\n', sql, flags=re.IGNORECASE)
                    for batch in batches:
                        batch = batch.strip()
                        # Keep batches with procedures, functions, or significant queries
                        if (re.search(r'CREATE\s+(?:PROC|FUNCTION|VIEW|TRIGGER)', batch, re.IGNORECASE) or
                            re.search(r'ALTER\s+(?:PROC|FUNCTION|VIEW|TRIGGER)', batch, re.IGNORECASE) or
                            (re.search(r'\b(?:SELECT|INSERT|UPDATE|DELETE|MERGE)\b', batch, re.IGNORECASE) and
                             len(batch) > 200)):
                            sql_batches.append(batch)
                    if sql_batches:
                        print(f"  [PREPROCESS] Split into {len(sql_batches)} batches (GO separators)")
                        sql = sql_batches[0]  # Use first significant batch for main processing
                else:
                    sql_batches = [sql]

                # Check if this is a stored procedure and use SQLHandler
                sql_handler = SQLHandler(dialect=args.dialect, schema=schema)
                is_stored_procedure = sql_handler._is_stored_procedure(sql)

                if is_stored_procedure:
                    # Extract volatile table schema and merge with existing schema
                    volatile_schema = sql_handler.extract_volatile_table_schema(sql)
                    if volatile_schema:
                        # Merge volatile schema into the main schema for lineage extraction
                        merged_schema = {**schema, **volatile_schema} if schema else volatile_schema
                        sql_handler = SQLHandler(dialect=args.dialect, schema=merged_schema)
                    
                    # Use enhanced VolatileTableHandler for detailed volatile table lineage
                    volatile_lineage_rows = []
                    try:
                        volatile_handler = VolatileTableHandler(dialect=args.dialect)
                        volatile_definitions = volatile_handler.extract_volatile_tables(sql)
                        if volatile_definitions:
                            print(f"  [VOLATILE] Extracted {len(volatile_definitions)} volatile tables: {list(volatile_definitions.keys())}")
                            # Store volatile lineage for later merging into comprehensive CSV
                            volatile_lineage_rows = volatile_handler.to_csv_rows()
                            # Update volatile schema with handler's schema
                            merged_schema = {**merged_schema, **volatile_handler.get_volatile_table_schema()}
                            sql_handler = SQLHandler(dialect=args.dialect, schema=merged_schema)
                            
                            # Collect per-table metadata for end-to-end lineage
                            for vol_name, vol_def in volatile_definitions.items():
                                volatile_table_metadata[vol_name] = {
                                    'dml_operation': vol_def.dml_operation.value if hasattr(vol_def.dml_operation, 'value') else str(vol_def.dml_operation),
                                    'join_conditions': vol_def.join_conditions,
                                    'where_conditions': vol_def.where_conditions,
                                    'sttm': vol_def.sttm
                                }
                    except Exception as e:
                        print(f"  [VOLATILE] Warning: Enhanced volatile extraction failed: {e}")
                        volatile_lineage_rows = []
                    
                    # Use SQLHandler for stored procedures - it handles INSERT extraction
                    handler_result = sql_handler.process_content(sql, filepath)
                    if handler_result.statements:
                        print(f"  [PROC] Extracted {len(handler_result.statements)} statements from stored procedure")

                        all_elements = []
                        all_lineage = []

                        for stmt in handler_result.statements:
                            if stmt.elements:
                                all_elements.append(stmt.elements)
                            if stmt.lineage:
                                all_lineage.append(stmt.lineage)

                        # Use the first statement's elements as primary
                        elements = all_elements[0] if all_elements else None

                        # Merge lineage graphs, tagging each edge with its element index
                        # so that structurally identical DML blocks (e.g., 10 INSERTs into
                        # the same target) can be matched to the correct element later.
                        from lineage.lineage_graph import LineageGraph
                        merged_graph = LineageGraph()
                        elem_idx = 0
                        for stmt in handler_result.statements:
                            has_elem = stmt.elements is not None
                            if stmt.lineage:
                                if has_elem:
                                    for edge in stmt.lineage.edges:
                                        edge.statement_id = f"elem_{elem_idx}"
                                merged_graph.merge(stmt.lineage)
                            if has_elem:
                                elem_idx += 1
                        
                        # Merge volatile table lineage into main graph
                        # This ensures end-to-end lineage properly traces through volatile tables
                        try:
                            if volatile_handler:
                                volatile_graph = volatile_handler.to_lineage_graph()
                                if volatile_graph and volatile_graph.edges:
                                    merged_graph.merge(volatile_graph)
                                    print(f"  [VOLATILE] Merged {len(volatile_graph.edges)} volatile lineage edges into main graph")
                        except NameError:
                            pass  # volatile_handler not defined
                        except Exception as e:
                            print(f"  [VOLATILE] Warning: Could not merge volatile lineage: {e}")

                        # Still need parse result for AST output
                        generator = SQLASTGenerator(dialect=args.dialect)
                        result = generator.parse_safe(sql)

                        # Generate all outputs (AST, CSV, Excel, HTML, etc.)
                        # Code continues below after if/else
                    else:
                        print(f"  [WARNING] Could not extract statements from stored procedure")
                        results_summary.append({'file': base_name, 'success': False, 'error': 'No statements extracted'})
                        continue
                else:
                    # Initialize volatile_lineage_rows for non-stored procedures
                    volatile_lineage_rows = []
                    
                    # Parse and extract for regular SQL
                    generator = SQLASTGenerator(dialect=args.dialect)
                    result = generator.parse_safe(sql)

                    if not result.success:
                        # Try other batches if first one fails
                        for alt_sql in sql_batches[1:]:
                            alt_result = generator.parse_safe(alt_sql)
                            if alt_result.success:
                                sql = alt_sql
                                result = alt_result
                                print(f"  [PREPROCESS] Using alternative batch")
                                break

                    if not result.success:
                        print(f"  [ERROR] Parse failed: {result.metadata.error_messages[:100]}")
                        results_summary.append({'file': base_name, 'success': False, 'error': 'Parse error'})
                        continue

                    # Process statements
                    all_elements = []
                    all_lineage = []

                    for stmt in result.statements:
                        extractor = SQLElementExtractor(stmt, args.dialect)
                        elements = extractor.extract_all()
                        all_elements.append(elements)

                        lineage_extractor = LineageExtractor(schema=schema, dialect=args.dialect)
                        lineage = lineage_extractor.extract_lineage(stmt.sql(dialect=args.dialect))
                        all_lineage.append(lineage)

                    # Extract DML statements from stored procedure bodies for additional lineage
                    proc_body_stmts = extract_procedure_body_statements(sql, args.dialect)
                    if proc_body_stmts:
                        print(f"  [PROC BODY] Found {len(proc_body_stmts)} DML statements in procedure body")
                        for body_stmt in proc_body_stmts:
                            try:
                                body_lineage_extractor = LineageExtractor(schema=schema, dialect=args.dialect)
                                body_lineage = body_lineage_extractor.extract_lineage(body_stmt)
                                if body_lineage and body_lineage.edges:
                                    all_lineage.append(body_lineage)
                            except Exception as e:
                                # Skip statements that fail to parse
                                pass

                    elements = all_elements[0] if all_elements else None

                    # Merge lineage graphs (for non-stored procedures)
                    from lineage.lineage_graph import LineageGraph
                    merged_graph = LineageGraph()
                    for graph in all_lineage:
                        merged_graph.merge(graph)

                # 1. AST JSON
                ast_path = safe_join(str(args.output), f"{base_name}_ast.json")
                with open(ast_path, 'w', encoding='utf-8') as f:
                    json.dump({
                        'metadata': result.metadata.to_dict(),
                        'statements': [generator.to_json(stmt) for stmt in result.statements]
                    }, f, indent=2, default=str)

                # 2. Elements JSON
                elements_path = safe_join(str(args.output), f"{base_name}_elements.json")
                with open(elements_path, 'w', encoding='utf-8') as f:
                    json.dump([e.to_dict() for e in all_elements], f, indent=2)

                # 3. Standard Lineage CSV
                csv_path = safe_join(str(args.output), f"{base_name}_lineage.csv")
                doc_gen = SourceTargetMappingGenerator(merged_graph, elements, all_element_catalogs=all_elements)
                doc_gen.generate_csv(csv_path)

                # 3b. Volatile Table Lineage CSV (with DML_Operation, STTM)
                if is_stored_procedure and volatile_lineage_rows:
                    import csv as csv_module
                    volatile_csv_path = safe_join(str(args.output), f"{base_name}_volatile_lineage.csv")
                    fieldnames = ['Source_Table', 'Source_Attribute', 'Transformation_Logic',
                                  'Target_Table', 'Target_Attribute', 'DML_Operation',
                                  'Join_Conditions', 'Where_Conditions', 'STTM']
                    with open(volatile_csv_path, 'w', newline='', encoding='utf-8') as f:
                        writer = csv_module.DictWriter(f, fieldnames=fieldnames, extrasaction='ignore')
                        writer.writeheader()
                        writer.writerows(volatile_lineage_rows)
                    print(f"  [VOLATILE CSV] {len(volatile_lineage_rows)} rows to {os.path.basename(volatile_csv_path)}")

                # 4. Comprehensive CSV
                comp_csv_path = safe_join(str(args.output), f"{base_name}_lineage_comprehensive.csv")
                doc_gen.generate_comprehensive_csv(comp_csv_path)

                # 5. Structured Excel
                excel_path = safe_join(str(args.output), f"{base_name}_structured.xlsx")
                structured_output = doc_gen.generate_structured_excel(excel_path, filepath)

                # 6. Collapsible Tree Visualization
                try:
                    from visualization.visual_exporter import VisualLineageExporter
                    tree_path = safe_join(str(args.output), f"{base_name}_lineage_tree.html")
                    exporter = VisualLineageExporter(merged_graph)
                    exporter.export_tree(tree_path, title=title)
                except Exception as e:
                    pass

                # 7. Network Graph
                try:
                    network_path = safe_join(str(args.output), f"{base_name}_lineage_network.html")
                    exporter.export_html(network_path)
                except Exception:
                    pass

                # 8. Field-Level Lineage Graph (using merged_graph directly)
                try:
                    field_graph_path = safe_join(str(args.output), f"{base_name}_field_level_graph.html")
                    if merged_graph and merged_graph.edges:
                        _generate_field_level_graph_from_lineage(merged_graph, field_graph_path, f"{base_name} Field-Level Lineage")
                    else:
                        print(f"  [WARN] No lineage edges for field-level graph")
                except Exception as e:
                    print(f"  [WARN] Field-level graph generation failed: {str(e)[:50]}")

                # 9. Mermaid Diagram
                mermaid_path = safe_join(str(args.output), f"{base_name}_lineage.mmd")
                mermaid_code = merged_graph.to_mermaid()
                with open(mermaid_path, 'w', encoding='utf-8') as f:
                    f.write(mermaid_code)

                # 10. Lineage JSON (raw graph format)
                json_lineage_path = safe_join(str(args.output), f"{base_name}_lineage.json")
                with open(json_lineage_path, 'w', encoding='utf-8') as f:
                    json.dump(merged_graph.to_dict(), f, indent=2, default=str)

                # 10b. Lineage Output JSON (rich format - intermediate for STTM)
                lineage_output_path = safe_join(str(args.output), f"{base_name}_lineage_output.json")
                lineage_output_data = merged_graph.to_lineage_output_dict(
                    source_file=filepath, dialect=args.dialect
                )
                with open(lineage_output_path, 'w', encoding='utf-8') as f:
                    json.dump(lineage_output_data, f, indent=2, default=str)
                print(f"  [LINEAGE OUTPUT] {lineage_output_data['metadata']['edge_count']} edges to {os.path.basename(lineage_output_path)}")

                # 11. Comprehensive HTML Documentation
                docs_path = safe_join(str(args.output), f"{base_name}_documentation.html")
                help_gen = HTMLHelpGenerator()
                help_gen.generate_help(
                    output_path=docs_path,
                    lineage_graph=merged_graph,
                    element_catalog=elements,
                    structured_output=structured_output,
                    source_file=filepath,
                    title=title
                )

                file_result = {
                    'file': base_name,
                    'success': True,
                    'statements': len(result.statements),
                    'lineage_edges': len(merged_graph.edges),
                    'has_dynamic_sql': False
                }

                # 11. Dynamic SQL Analysis (if enabled)
                if use_dynamic_sql:
                    try:
                        from dynamic_sql import DynamicSQLAnalyzer
                        analyzer = DynamicSQLAnalyzer(dialect=args.dialect, use_multi_expert=use_multi_expert)
                        dynamic_result = analyzer.analyze(sql)

                        if dynamic_result.has_dynamic_sql():
                            # Save dynamic SQL analysis
                            dynamic_path = safe_join(str(args.output), f"{base_name}_dynamic_sql.json")
                            with open(dynamic_path, 'w', encoding='utf-8') as f:
                                json.dump(dynamic_result.to_dict(), f, indent=2)

                            # Save multi-expert details
                            if use_multi_expert:
                                details = analyzer.get_multi_expert_details()
                                if details:
                                    expert_path = safe_join(str(args.output), f"{base_name}_multi_expert.json")
                                    with open(expert_path, 'w', encoding='utf-8') as f:
                                        json.dump(details, f, indent=2)

                            # Save expanded SQL
                            expanded_sql, _ = analyzer.analyze_and_expand(sql)
                            expanded_path = safe_join(str(args.output), f"{base_name}_expanded.sql")
                            with open(expanded_path, 'w', encoding='utf-8') as f:
                                f.write(expanded_sql)

                            file_result['has_dynamic_sql'] = True
                            file_result['dynamic_patterns'] = len(dynamic_result.detected_patterns)
                            file_result['fully_resolved'] = len(dynamic_result.fully_resolved)
                            print(f"  [DYNAMIC] {len(dynamic_result.detected_patterns)} patterns found")

                    except Exception as e:
                        print(f"  [WARN] Dynamic SQL analysis failed: {e}")

                # AI review per-file (analysis only — no interactive loop in batch)
                if getattr(args, 'review', False):
                    try:
                        from agent_interface.ai_code_reviewer import AICodeReviewer
                        from agent_interface.llm_client import LLMClientFactory
                        if not hasattr(args, '_llm_client_cache'):
                            args._llm_client_cache = LLMClientFactory.get_or_prompt()
                        reviewer = AICodeReviewer(args._llm_client_cache, dialect=args.dialect)
                        reviewer.run(
                            sql_path=filepath,
                            sttm_path=excel_path,
                            output_dir=args.output,
                            interactive=False,
                        )
                    except Exception as e:
                        print(f"  [AI Review] Error: {e}")

                results_summary.append(file_result)
                stats = merged_graph.get_statistics()
                print(f"  [OK] {len(result.statements)} statements, {stats['edge_count']} lineage edges")

                # Store per-file lineage data for end-to-end processing
                if merged_graph and merged_graph.edges:
                    # Extract target and source tables from lineage edges
                    targets = set()
                    sources = set()
                    for edge in merged_graph.edges:
                        if edge.target and hasattr(edge.target, 'table_name') and edge.target.table_name:
                            targets.add(edge.target.table_name)
                        if edge.source and hasattr(edge.source, 'table_name') and edge.source.table_name:
                            sources.add(edge.source.table_name)

                    # Determine the main target (most frequently targeted table)
                    main_target = None
                    if targets:
                        main_target = max(targets, key=lambda t: sum(1 for e in merged_graph.edges if e.target and e.target.table_name == t))

                    # Sources are all tables except the main target
                    source_tables_list = [t for t in sources if t != main_target]

                    # Extract DML/join/WHERE scoped to the main target table (Issues #2, #4, #5)
                    dml_operation = extract_dml_operation_for_target(result.statements, main_target)
                    join_details = extract_join_details_for_target(result.statements, main_target)
                    where_conditions = extract_where_conditions_for_target(result.statements, main_target)

                    # For volatile tables already parsed by VolatileTableHandler, use
                    # their richer per-table metadata (Issue #8, #9)
                    if main_target and main_target.upper() in volatile_table_metadata:
                        vol_info = volatile_table_metadata[main_target.upper()]
                        dml_operation = vol_info.get('dml_operation', dml_operation) or dml_operation
                        join_details = vol_info.get('join_conditions', join_details) or join_details
                        where_conditions = vol_info.get('where_conditions', where_conditions) or where_conditions

                    per_file_lineage_data[filepath] = (merged_graph, main_target, source_tables_list, 
                                                       dml_operation, join_details, where_conditions)

            except Exception as e:
                print(f"  [ERROR] {e}")
                results_summary.append({'file': base_name, 'success': False, 'error': str(e)})

        # Generate END-TO-END lineage across all files
        print(f"\n{'-'*50}")
        print("Generating END-TO-END cross-file lineage...")
        print(f"{'-'*50}")
        try:
            from lineage.end_to_end_lineage import EndToEndLineageExtractor

            e2e_extractor = EndToEndLineageExtractor(dialect=args.dialect)

            # Import per-file lineage data collected during individual file processing
            # This is critical for stored procedures where sqlglot re-parsing fails
            if per_file_lineage_data:
                print(f"  [E2E] Importing {len(per_file_lineage_data)} pre-extracted lineage files...")
                for fpath, file_data in per_file_lineage_data.items():
                    # Unpack: (lineage_graph, target_table, source_tables, dml_operation, join_details, where_conditions)
                    lineage_graph = file_data[0]
                    target_table = file_data[1]
                    source_tables = file_data[2]
                    dml_operation = file_data[3] if len(file_data) > 3 else ""
                    join_details = file_data[4] if len(file_data) > 4 else ""
                    where_conditions = file_data[5] if len(file_data) > 5 else ""
                    
                    e2e_extractor.add_external_lineage(
                        file_path=fpath,
                        lineage_graph=lineage_graph,
                        target_table=target_table,
                        source_tables=source_tables,
                        dml_operation=dml_operation,
                        join_details=join_details,
                        where_conditions=where_conditions
                    )

            # Add per-table metadata from volatile tables (for specific DML, JOIN, WHERE per table)
            if volatile_table_metadata:
                for vol_table_name, vol_meta in volatile_table_metadata.items():
                    e2e_extractor.add_table_metadata(
                        table_name=vol_table_name,
                        dml_operation=vol_meta.get('dml_operation', ''),
                        join_conditions=vol_meta.get('join_conditions', ''),
                        where_conditions=vol_meta.get('where_conditions', ''),
                        sttm=vol_meta.get('sttm', '')
                    )

            # Check for Schema directory (sibling to input directory) and process it first
            # This ensures view definitions are processed before the SQL files that reference them
            parent_dir = os.path.dirname(args.input.rstrip(os.sep))
            schema_dir = os.path.join(parent_dir, "Schema")

            if os.path.isdir(schema_dir) and os.path.normpath(schema_dir) != os.path.normpath(args.input):
                print(f"  [E2E] Processing Schema directory first: {schema_dir}")
                e2e_extractor.process_directory(schema_dir)
                print(f"  [E2E] Schema directory processed: {len(e2e_extractor.processing_order)} files")

            # Process the main input directory (may re-parse files but won't overwrite imported lineage with fewer edges)
            e2e_result = e2e_extractor.process_directory(args.input)

            if e2e_result:
                # Generate end-to-end field-level graph (combined across all files)
                e2e_title = args.title or "End-to-End"
                e2e_field_graph_path = safe_join(str(args.output), "end_to_end_field_level_graph.html")
                e2e_extractor.export_field_level_graph(e2e_field_graph_path, f"{e2e_title} Field-Level Lineage")

                # Generate end-to-end CSV
                e2e_csv_path = safe_join(str(args.output), "end_to_end_lineage.csv")
                e2e_extractor.export_end_to_end_csv(e2e_csv_path)

                # Generate comprehensive CSV with all hops
                e2e_comp_csv_path = safe_join(str(args.output), "end_to_end_comprehensive.csv")
                e2e_extractor.export_comprehensive_csv(e2e_comp_csv_path)

                # Generate end-to-end tree visualization
                e2e_tree_path = safe_join(str(args.output), "end_to_end_lineage_tree.html")
                e2e_extractor.export_html_tree(e2e_tree_path, f"{e2e_title} End-to-End Lineage")

                # Generate end-to-end documentation
                e2e_docs_path = safe_join(str(args.output), "end_to_end_documentation.html")
                e2e_extractor.export_html_documentation(e2e_docs_path, f"{e2e_title} Lineage Documentation")

                # Generate JSON export
                e2e_json_path = safe_join(str(args.output), "end_to_end_lineage.json")
                e2e_extractor.export_json(e2e_json_path)

                # Generate structured Excel workbook (like old lineage_analysis.xlsx format)
                e2e_excel_path = safe_join(str(args.output), "lineage_analysis.xlsx")
                e2e_extractor.export_excel(e2e_excel_path, f"{e2e_title} End-to-End Lineage Analysis")

                lineages = e2e_extractor.extract_end_to_end_lineage()
                print(f"  [E2E] Generated end-to-end lineage: {len(lineages)} column paths traced")
                print(f"  [E2E] Files in processing order: {len(e2e_extractor.processing_order)}")
                print(f"  [E2E] Tables tracked: {len(e2e_extractor.table_to_file)}")

        except Exception as e:
            print(f"  [WARN] End-to-end lineage generation failed: {e}")

        # Print summary
        success_count = sum(1 for r in results_summary if r.get('success'))
        dynamic_count = sum(1 for r in results_summary if r.get('has_dynamic_sql'))
        total_edges = sum(r.get('lineage_edges', 0) for r in results_summary)

        print(f"\n{'='*70}")
        print("BATCH PROCESSING COMPLETE")
        print(f"{'='*70}")
        print(f"Total files: {len(all_files)}")
        print(f"Successful: {success_count}")
        print(f"Failed: {len(all_files) - success_count}")
        print(f"Total lineage edges: {total_edges}")
        if use_dynamic_sql:
            print(f"Files with dynamic SQL: {dynamic_count}")
        print(f"\nOutput directory: {args.output}")
        print(f"\nFiles generated per SQL file:")
        print(f"  - *_ast.json")
        print(f"  - *_elements.json")
        print(f"  - *_lineage.csv")
        print(f"  - *_lineage_comprehensive.csv")
        print(f"  - *_structured.xlsx")
        print(f"  - *_lineage_tree.html")
        print(f"  - *_lineage_network.html")
        print(f"  - *_field_level_graph.html")
        print(f"  - *_lineage.json")
        print(f"  - *_lineage_output.json")
        print(f"  - *_lineage.mmd")
        print(f"  - *_documentation.html")
        if use_dynamic_sql:
            print(f"  - *_dynamic_sql.json (if dynamic SQL found)")
            print(f"  - *_expanded.sql (if dynamic SQL found)")
            if use_multi_expert:
                print(f"  - *_multi_expert.json (if dynamic SQL found)")
        print(f"\nEnd-to-End cross-file outputs:")
        print(f"  - end_to_end_field_level_graph.html (full lineage chain)")
        print(f"  - end_to_end_lineage.csv")
        print(f"  - end_to_end_comprehensive.csv")
        print(f"  - end_to_end_lineage_tree.html")
        print(f"  - end_to_end_documentation.html")
        print(f"  - end_to_end_lineage.json")

    elif args.command == 'visualize':
        args.input = _resolve_input_path(args.input)
        args.output = _resolve_output_dir(args.output)
        # Load schema if provided
        schema = None
        if args.schema_dir:
            loader = DDLSchemaLoader(dialect=args.dialect)
            schema = loader.load_from_directory(args.schema_dir)

        with open(args.input, 'r', encoding='utf-8', errors='ignore') as f:
            sql = f.read()

        # Parse and extract
        generator = SQLASTGenerator(dialect=args.dialect)
        ast = generator.parse(sql)

        extractor = SQLElementExtractor(ast, args.dialect)
        elements = extractor.extract_all()

        lineage_extractor = LineageExtractor(schema=schema, dialect=args.dialect)
        lineage = lineage_extractor.extract_lineage(sql)

        # Generate visual output
        try:
            from visualization.visual_exporter import VisualLineageExporter

            exporter = VisualLineageExporter(lineage)

            if args.format == 'tree':
                # Collapsible tree visualization (recommended)
                exporter.export_tree(args.output, title=args.title)
                print(f"Generated collapsible tree visualization: {args.output}")
            elif args.format == 'html':
                exporter.export_html(args.output)
                print(f"Generated network graph HTML visualization: {args.output}")
            elif args.format == 'svg':
                exporter.export_svg(args.output)
                print(f"Generated SVG visualization: {args.output}")
            elif args.format == 'pdf':
                exporter.export_pdf(args.output)
                print(f"Generated PDF visualization: {args.output}")
            elif args.format == 'png':
                exporter.export_png(args.output)
                print(f"Generated PNG visualization: {args.output}")
            elif args.format == 'mermaid':
                mermaid_code = exporter.export_mermaid()
                _mermaid_out = safe_join(os.path.dirname(args.output) or ".", secure_filename(os.path.basename(args.output)))
                with open(_mermaid_out, 'w', encoding='utf-8') as f:
                    f.write(mermaid_code)
                print(f"Generated Mermaid diagram code: {args.output}")

            stats = lineage.get_statistics()
            print(f"Nodes: {stats['node_count']}")
            print(f"Edges: {stats['edge_count']}")

        except ImportError as e:
            print(f"Error: {e}")
            print("Install required dependencies: pip install pyvis graphviz")

    elif args.command == 'docs':
        # Load schema if provided
        schema = None
        if args.schema_dir:
            loader = DDLSchemaLoader(dialect=args.dialect)
            schema = loader.load_from_directory(args.schema_dir)

        with open(args.input, 'r', encoding='utf-8', errors='ignore') as f:
            sql = f.read()

        # Parse and extract
        generator = SQLASTGenerator(dialect=args.dialect)
        ast = generator.parse(sql)

        extractor = SQLElementExtractor(ast, args.dialect)
        elements = extractor.extract_all()

        lineage_extractor = LineageExtractor(schema=schema, dialect=args.dialect)
        lineage = lineage_extractor.extract_lineage(sql)

        # Build structured output
        doc_gen = SourceTargetMappingGenerator(lineage, elements)
        structured_output = doc_gen.get_structured_output(args.input)

        # Generate HTML help
        help_gen = HTMLHelpGenerator()
        help_gen.generate_help(
            output_path=args.output,
            lineage_graph=lineage,
            element_catalog=elements,
            structured_output=structured_output,
            source_file=args.input,
            title=args.title
        )

        print(f"Generated HTML documentation: {args.output}")
        print(f"Column mappings: {structured_output.metadata.total_column_mappings}")
        print(f"Join conditions: {structured_output.metadata.total_join_conditions}")
        print(f"Filter conditions: {structured_output.metadata.total_filter_conditions}")

    elif args.command == 'excel':
        # Load schema if provided
        schema = None
        if args.schema_dir:
            loader = DDLSchemaLoader(dialect=args.dialect)
            schema = loader.load_from_directory(args.schema_dir)

        with open(args.input, 'r', encoding='utf-8', errors='ignore') as f:
            sql = f.read()

        # Parse and extract
        generator = SQLASTGenerator(dialect=args.dialect)
        ast = generator.parse(sql)

        extractor = SQLElementExtractor(ast, args.dialect)
        elements = extractor.extract_all()

        lineage_extractor = LineageExtractor(schema=schema, dialect=args.dialect)
        lineage = lineage_extractor.extract_lineage(sql)

        # Generate structured Excel
        doc_gen = SourceTargetMappingGenerator(lineage, elements)
        structured_output = doc_gen.generate_structured_excel(args.output, args.input)

        print(f"Generated structured Excel: {args.output}")
        print(f"Sheets: Summary, Column Lineage, Join Conditions, Filter Conditions")
        print(f"Column mappings: {structured_output.metadata.total_column_mappings}")
        print(f"Join conditions: {structured_output.metadata.total_join_conditions}")
        print(f"Filter conditions: {structured_output.metadata.total_filter_conditions}")

    elif args.command == 'full':
        # Generate ALL outputs at once
        print(f"\n{'='*60}")
        print("FULL OUTPUT GENERATION")
        print(f"{'='*60}")

        # Load schema if provided or auto-detect DDL directories
        schema = None
        if args.schema_dir:
            loader = DDLSchemaLoader(dialect=args.dialect)
            schema = loader.load_from_directory(args.schema_dir)
        else:
            # Auto-detect DDL schema for column resolution (e.g., in views)
            loader = DDLSchemaLoader(dialect=args.dialect)
            input_dir = os.path.dirname(os.path.abspath(args.input))
            # Check for Schema subdirectory first
            schema_subdir = os.path.join(input_dir, "Schema")
            if os.path.isdir(schema_subdir):
                schema = loader.load_from_directory(schema_subdir)
                if schema:
                    print(f"Auto-loaded schema from: {schema_subdir} ({len(schema)} tables)")
            else:
                # Try _combined_schema — load only relevant DDL files based on
                # source table prefixes found in the SQL to avoid loading all schemas
                for candidate in [
                    os.path.join(os.path.dirname(input_dir), "_combined_schema"),
                    os.path.join(os.path.dirname(input_dir), "Complex", "_combined_schema"),
                ]:
                    if os.path.isdir(candidate):
                        schema = _load_relevant_schema(args.input, candidate, args.dialect)
                        if schema:
                            print(f"Auto-loaded schema from: {candidate} ({len(schema)} tables)")
                        break

        # Create output directory
        args.output = _resolve_output_dir(args.output)
        os.makedirs(args.output, exist_ok=True)

        # Get base name from input file
        base_name = os.path.splitext(os.path.basename(args.input))[0]
        title = args.title or f"{base_name} Lineage Documentation"

        with open(args.input, 'r', encoding='utf-8', errors='ignore') as f:
            sql = f.read()

        # Strip banner/header lines (e.g., ====... VIEW: name ====...)
        # Preserve lines containing comment markers (/* or */) so block
        # comments like /*====...====*/ are not broken.
        sql = re.sub(r'^[=]{3,}(?!.*(?:/\*|\*/)).*$', '', sql, flags=re.MULTILINE)
        sql = re.sub(r'^\s*VIEW:\s+.*$', '', sql, flags=re.MULTILINE)

        # Strip line-continuation double quotes from Teradata export tools.
        sql = re.sub(r'"\s*\n\s*"', '', sql)

        print(f"\nProcessing: {args.input}")

        # Check if this is a stored procedure first — SP parsing uses a
        # different path (SQLHandler) and should not be blocked by parse_safe.
        sql_handler = SQLHandler(dialect=args.dialect, schema=schema)
        is_stored_procedure = sql_handler._is_stored_procedure(sql)

        # Parse for AST output
        generator = SQLASTGenerator(dialect=args.dialect)
        result = generator.parse_safe(sql)

        if not result.success and not is_stored_procedure:
            print(f"Parse error: {result.metadata.error_messages}")
            return

        if is_stored_procedure:
            # Extract volatile table schema for lineage resolution
            volatile_schema = sql_handler.extract_volatile_table_schema(sql)
            if volatile_schema:
                merged_schema = {**(schema or {}), **volatile_schema}
                sql_handler = SQLHandler(dialect=args.dialect, schema=merged_schema)

            handler_result = sql_handler.process_content(sql, args.input)
            all_elements = []
            all_lineage = []
            for stmt in handler_result.statements:
                if stmt.elements:
                    all_elements.append(stmt.elements)
                if stmt.lineage:
                    all_lineage.append(stmt.lineage)

            from lineage.lineage_graph import LineageGraph
            merged_graph = LineageGraph()
            for graph in all_lineage:
                merged_graph.merge(graph)
            elements = all_elements[0] if all_elements else None
            print(f"  [PROC] Extracted {len(handler_result.statements)} statements ({sum(1 for s in handler_result.statements if s.statement_type == 'INSERT')} INSERT, {sum(1 for s in handler_result.statements if s.statement_type == 'DELETE')} DELETE)")
        else:
            # Process statements for regular SQL
            all_elements = []
            all_lineage = []

            for stmt in result.statements:
                extractor = SQLElementExtractor(stmt, args.dialect)
                elements_item = extractor.extract_all()
                all_elements.append(elements_item)

                lineage_extractor = LineageExtractor(schema=schema, dialect=args.dialect)
                lineage = lineage_extractor.extract_lineage(stmt.sql(dialect=args.dialect))
                all_lineage.append(lineage)

            from lineage.lineage_graph import LineageGraph
            merged_graph = LineageGraph()
            for graph in all_lineage:
                merged_graph.merge(graph)
            elements = all_elements[0] if all_elements else None

        # 1. AST JSON
        print("\n1. Generating AST JSON...")
        ast_path = safe_join(str(args.output), f"{base_name}_ast.json")
        try:
            with open(ast_path, 'w', encoding='utf-8') as f:
                json.dump({
                    'metadata': result.metadata.to_dict(),
                    'statements': [generator.to_json(stmt) for stmt in result.statements]
                }, f, indent=2, default=str)
            print(f"   -> {ast_path}")
        except Exception as e:
            print(f"   -> Error: {e}")

        # 2. Elements JSON
        print("2. Generating Elements JSON...")
        elements_path = safe_join(str(args.output), f"{base_name}_elements.json")
        with open(elements_path, 'w', encoding='utf-8') as f:
            json.dump([e.to_dict() for e in all_elements], f, indent=2)
        print(f"   -> {elements_path}")

        # 3. Standard Lineage CSV
        print("3. Generating Standard Lineage CSV...")
        csv_path = safe_join(str(args.output), f"{base_name}_lineage.csv")
        doc_gen = SourceTargetMappingGenerator(merged_graph, elements, all_element_catalogs=all_elements)
        doc_gen.generate_csv(csv_path)
        print(f"   -> {csv_path}")

        # 4. Comprehensive CSV (with English explanations)
        print("4. Generating Comprehensive CSV...")
        comp_csv_path = safe_join(str(args.output), f"{base_name}_lineage_comprehensive.csv")
        doc_gen.generate_comprehensive_csv(comp_csv_path)
        print(f"   -> {comp_csv_path}")

        # 5. Structured Excel
        print("5. Generating Structured Excel...")
        excel_path = safe_join(str(args.output), f"{base_name}_structured.xlsx")
        structured_output = doc_gen.generate_structured_excel(excel_path, args.input)
        print(f"   -> {excel_path}")
        print(f"      Sheets: Summary, Column Lineage, Join Conditions, Filter Conditions")

        # 6. Collapsible Tree Visualization (primary visualization)
        print("6. Generating Collapsible Tree Visualization...")
        try:
            from visualization.visual_exporter import VisualLineageExporter
            tree_path = safe_join(str(args.output), f"{base_name}_lineage_tree.html")
            exporter = VisualLineageExporter(merged_graph)
            exporter.export_tree(tree_path, title=title)
            print(f"   -> {tree_path}")
        except Exception as e:
            print(f"   -> Error: {e}")

        # 6b. Network Graph Visualization (optional)
        print("6b. Generating Network Graph Visualization...")
        try:
            network_path = safe_join(str(args.output), f"{base_name}_lineage_network.html")
            exporter.export_html(network_path)
            print(f"   -> {network_path}")
        except ImportError as e:
            print(f"   -> Skipped (pyvis not installed): {e}")

        # 7. Mermaid Diagram
        print("7. Generating Mermaid Diagram...")
        mermaid_path = safe_join(str(args.output), f"{base_name}_lineage.mmd")
        mermaid_code = merged_graph.to_mermaid()
        with open(mermaid_path, 'w', encoding='utf-8') as f:
            f.write(mermaid_code)
        print(f"   -> {mermaid_path}")

        # 8. Comprehensive HTML Documentation
        print("8. Generating Comprehensive HTML Documentation...")
        docs_path = safe_join(str(args.output), f"{base_name}_documentation.html")
        help_gen = HTMLHelpGenerator()
        help_gen.generate_help(
            output_path=docs_path,
            lineage_graph=merged_graph,
            element_catalog=elements,
            structured_output=structured_output,
            source_file=args.input,
            title=title
        )
        print(f"   -> {docs_path}")

        # Summary
        stats = merged_graph.get_statistics()
        print(f"\n{'='*60}")
        print("GENERATION COMPLETE")
        print(f"{'='*60}")
        print(f"Output directory: {args.output}")
        print(f"\nStatistics:")
        print(f"  - Statements parsed: {len(result.statements)}")
        print(f"  - Column mappings: {stats['edge_count']}")
        print(f"  - Nodes in lineage: {stats['node_count']}")
        print(f"  - Join conditions: {structured_output.metadata.total_join_conditions}")
        print(f"  - Filter conditions: {structured_output.metadata.total_filter_conditions}")
        print(f"\nGenerated files:")
        print(f"  - {base_name}_ast.json")
        print(f"  - {base_name}_elements.json")
        print(f"  - {base_name}_lineage.csv")
        print(f"  - {base_name}_lineage_comprehensive.csv")
        print(f"  - {base_name}_structured.xlsx")
        print(f"  - {base_name}_lineage_tree.html (collapsible tree - recommended)")
        print(f"  - {base_name}_lineage_network.html (network graph)")
        print(f"  - {base_name}_lineage.mmd")
        print(f"  - {base_name}_documentation.html")

        # 9. Dynamic SQL Analysis (if enabled)
        if getattr(args, 'dynamic_sql', False):
            use_multi_expert = getattr(args, 'multi_expert', False)
            mode_str = "Multi-Expert" if use_multi_expert else "Sequential"
            print(f"\n9. Analyzing Dynamic SQL ({mode_str} mode)...")
            try:
                from dynamic_sql import DynamicSQLAnalyzer

                analyzer = DynamicSQLAnalyzer(dialect=args.dialect, use_multi_expert=use_multi_expert)
                dynamic_result = analyzer.analyze(sql)

                if dynamic_result.has_dynamic_sql():
                    # Save dynamic SQL analysis report
                    dynamic_report_path = safe_join(str(args.output), f"{base_name}_dynamic_sql.json")
                    with open(dynamic_report_path, 'w', encoding='utf-8') as f:
                        json.dump(dynamic_result.to_dict(), f, indent=2)
                    print(f"   -> {dynamic_report_path}")

                    # Save multi-expert details if enabled
                    if use_multi_expert:
                        details = analyzer.get_multi_expert_details()
                        if details:
                            expert_path = safe_join(str(args.output), f"{base_name}_multi_expert.json")
                            with open(expert_path, 'w', encoding='utf-8') as f:
                                json.dump(details, f, indent=2)
                            print(f"   -> {expert_path}")

                    # Save expanded SQL
                    expanded_sql, _ = analyzer.analyze_and_expand(sql)
                    expanded_path = safe_join(str(args.output), f"{base_name}_expanded.sql")
                    with open(expanded_path, 'w', encoding='utf-8') as f:
                        f.write(expanded_sql)
                    print(f"   -> {expanded_path}")

                    # Extract lineage from reconstructed dynamic SQL
                    dynamic_lineage_path = safe_join(str(args.output), f"{base_name}_dynamic_lineage.csv")
                    dynamic_extractor = DynamicSQLAwareExtractor(schema=schema, dialect=args.dialect)
                    dynamic_graph = dynamic_extractor.extract_lineage(sql)

                    if dynamic_graph.edges:
                        dynamic_doc_gen = SourceTargetMappingGenerator(dynamic_graph, elements)
                        dynamic_doc_gen.generate_csv(dynamic_lineage_path)
                        print(f"   -> {dynamic_lineage_path}")

                    print(f"\n   Dynamic SQL Summary:")
                    print(f"     - Patterns detected: {len(dynamic_result.detected_patterns)}")
                    print(f"     - Fully resolved: {len(dynamic_result.fully_resolved)}")
                    print(f"     - Partially resolved: {len(dynamic_result.partially_resolved)}")
                    print(f"     - Unresolvable: {len(dynamic_result.unresolvable)}")
                    if use_multi_expert and details:
                        print(f"     - Combined confidence: {details['combined_confidence']:.2f}")
                        print(f"     - Refinement iterations: {details['iterations']}")
                    if dynamic_result.analysis_warnings:
                        print(f"     - Warnings: {len(dynamic_result.analysis_warnings)}")
                        for warning in dynamic_result.analysis_warnings[:3]:
                            print(f"       * {warning}")
                else:
                    print("   -> No dynamic SQL detected")

            except ImportError as e:
                print(f"   -> Error: Dynamic SQL module not available: {e}")
            except Exception as e:
                print(f"   -> Error analyzing dynamic SQL: {e}")

        # AI accuracy review (--review flag)
        if getattr(args, 'review', False):
            try:
                from agent_interface.ai_code_reviewer import AICodeReviewer
                from agent_interface.llm_client import LLMClientFactory
                llm = LLMClientFactory.get_or_prompt()
                reviewer = AICodeReviewer(llm, dialect=args.dialect)
                reviewer.run(
                    sql_path=args.input,
                    sttm_path=excel_path,
                    output_dir=args.output,
                )
            except Exception as e:
                print(f"\n[AI Review] Error: {e}")

    elif args.command == 'dynamic-sql':
        # Dedicated dynamic SQL analysis command
        use_multi_expert = getattr(args, 'multi_expert', False)
        verbose = getattr(args, 'verbose', False)

        print(f"\n{'='*60}")
        print("DYNAMIC SQL ANALYSIS")
        if use_multi_expert:
            print("(Multi-Expert Architecture)")
        print(f"{'='*60}")

        try:
            from dynamic_sql import DynamicSQLAnalyzer, DynamicSQLLineageHelper

            # Create output directory
            args.output = _resolve_output_dir(args.output)
            os.makedirs(args.output, exist_ok=True)

            # Get base name from input file
            base_name = os.path.splitext(os.path.basename(args.input))[0]

            with open(args.input, 'r', encoding='utf-8', errors='ignore') as f:
                sql = f.read()

            print(f"\nAnalyzing: {args.input}")
            if use_multi_expert:
                print("Mode: Multi-Expert (parallel execution, refinement, provenance)")
            else:
                print("Mode: Sequential (original)")

            # Analyze dynamic SQL
            analyzer = DynamicSQLAnalyzer(dialect=args.dialect, use_multi_expert=use_multi_expert)
            result = analyzer.analyze(sql)

            # Show multi-expert details if enabled
            if use_multi_expert:
                details = analyzer.get_multi_expert_details()
                if details:
                    print(f"\n{'='*40}")
                    print("MULTI-EXPERT SUMMARY")
                    print(f"{'='*40}")
                    print(f"Combined confidence: {details['combined_confidence']:.2f}")
                    print(f"Refinement iterations: {details['iterations']}")
                    print(f"Execution time: {details['execution_time_ms']:.2f}ms")

                    if verbose:
                        print(f"\nExpert Contributions:")
                        for name, info in details['expert_outputs'].items():
                            status = "OK" if info['success'] else "FAIL"
                            print(f"  {name}: [{status}] confidence={info['confidence']:.2f}")
                            if info.get('warnings'):
                                for w in info['warnings'][:2]:
                                    print(f"    - {w[:60]}...")

                        # Save provenance if available
                        if details.get('provenance'):
                            provenance_path = safe_join(str(args.output), f"{base_name}_provenance.json")
                            with open(provenance_path, 'w', encoding='utf-8') as f:
                                json.dump(details['provenance'], f, indent=2)
                            print(f"\nSaved provenance to: {provenance_path}")

            if not result.has_dynamic_sql():
                print("\nNo dynamic SQL patterns detected in this file.")
                print("The file contains only static SQL statements.")
                return

            # Print detection summary
            print(f"\n{'='*40}")
            print("DETECTION RESULTS")
            print(f"{'='*40}")
            print(f"Total patterns detected: {len(result.detected_patterns)}")

            for i, pattern in enumerate(result.detected_patterns, 1):
                print(f"\n  {i}. {pattern.pattern_type.value}")
                print(f"     Variable: {pattern.variable_name}")
                print(f"     Line: {pattern.start_line}")
                print(f"     Confidence: {pattern.confidence:.0%}")

            # Print reconstruction results
            print(f"\n{'='*40}")
            print("RECONSTRUCTION RESULTS")
            print(f"{'='*40}")
            print(f"Fully resolved: {len(result.fully_resolved)}")
            print(f"Partially resolved: {len(result.partially_resolved)}")
            print(f"Unresolvable: {len(result.unresolvable)}")

            # Save analysis JSON
            analysis_path = safe_join(str(args.output), f"{base_name}_dynamic_analysis.json")
            with open(analysis_path, 'w', encoding='utf-8') as f:
                json.dump(result.to_dict(), f, indent=2)
            print(f"\nSaved analysis to: {analysis_path}")

            # Save expanded SQL if requested
            if args.expand:
                expanded_sql, _ = analyzer.analyze_and_expand(sql)
                expanded_path = safe_join(str(args.output), f"{base_name}_expanded.sql")
                with open(expanded_path, 'w', encoding='utf-8') as f:
                    f.write(expanded_sql)
                print(f"Saved expanded SQL to: {expanded_path}")

            # Extract lineage if requested
            if args.lineage:
                print(f"\n{'='*40}")
                print("LINEAGE EXTRACTION")
                print(f"{'='*40}")

                helper = DynamicSQLLineageHelper(analyzer)
                dynamic_sql_list = helper.get_lineage_sql(sql)

                if dynamic_sql_list:
                    lineage_extractor = LineageExtractor(dialect=args.dialect)
                    from lineage.lineage_graph import LineageGraph
                    merged_graph = LineageGraph()

                    for i, dsql in enumerate(dynamic_sql_list, 1):
                        print(f"\n  Extracting lineage from dynamic SQL {i}...")
                        try:
                            graph = lineage_extractor.extract_lineage(dsql)
                            merged_graph.merge(graph)
                            print(f"    Edges found: {len(graph.edges)}")
                        except Exception as e:
                            print(f"    Error: {e}")

                    if merged_graph.edges:
                        csv_path = safe_join(str(args.output), f"{base_name}_dynamic_lineage.csv")
                        doc_gen = SourceTargetMappingGenerator(merged_graph, None)
                        doc_gen.generate_csv(csv_path)
                        print(f"\nSaved lineage to: {csv_path}")
                        print(f"Total lineage edges: {len(merged_graph.edges)}")
                else:
                    print("No reconstructed SQL available for lineage extraction.")

            # Print warnings
            if result.analysis_warnings:
                print(f"\n{'='*40}")
                print("WARNINGS")
                print(f"{'='*40}")
                for warning in result.analysis_warnings:
                    print(f"  * {warning}")

            # Print reconstructed SQL
            print(f"\n{'='*40}")
            print("RECONSTRUCTED SQL")
            print(f"{'='*40}")

            for i, stmt in enumerate(result.fully_resolved + result.partially_resolved, 1):
                status = "FULLY RESOLVED" if stmt.is_complete else "PARTIALLY RESOLVED"
                print(f"\n--- Statement {i} ({status}) ---")
                print(f"Variable: {stmt.original_pattern.variable_name}")
                print(f"Confidence: {stmt.confidence:.0%}")
                if stmt.reconstruction_notes:
                    print(f"Notes: {', '.join(stmt.reconstruction_notes)}")
                print(f"\nSQL:\n{stmt.reconstructed_sql[:500]}{'...' if len(stmt.reconstructed_sql) > 500 else ''}")

        except ImportError as e:
            print(f"Error: Dynamic SQL module not available: {e}")
        except Exception as e:
            print(f"Error: {e}")
            import traceback
            traceback.print_exc()

    elif args.command == 'multi-file':
        # Multi-file processing with AST repository
        print(f"\n{'='*60}")
        print("MULTI-FILE PROCESSING")
        print(f"{'='*60}")

        try:
            from file_handlers import MultiFileProcessor

            # Create output directory
            args.output = _resolve_output_dir(args.output)
            os.makedirs(args.output, exist_ok=True)

            # Process files
            processor = MultiFileProcessor(dialect=args.dialect)
            repository = processor.process_directory(args.input)

            # Print summary
            processor.print_summary()

            # Save repository
            repo_path = safe_join(str(args.output), "ast_repository.json")
            repository.save_to_json(repo_path)
            print(f"\nAST Repository saved to: {repo_path}")

            # Save schema
            schema = repository.build_schema_dict()
            schema_path = safe_join(str(args.output), "schema.json")
            with open(schema_path, 'w', encoding='utf-8') as f:
                json.dump(schema, f, indent=2)
            print(f"Schema saved to: {schema_path}")

        except ImportError as e:
            print(f"Error: Required module not found: {e}")
        except Exception as e:
            print(f"Error: {e}")
            import traceback
            traceback.print_exc()

    elif args.command == 'cross-file':
        # Cross-file end-to-end lineage extraction
        print(f"\n{'='*60}")
        print("CROSS-FILE END-TO-END LINEAGE")
        print(f"{'='*60}")

        try:
            from lineage.end_to_end_lineage import EndToEndLineageExtractor

            # Create output directory
            args.output = _resolve_output_dir(args.output)
            os.makedirs(args.output, exist_ok=True)

            # Process files
            print(f"\nProcessing SQL files from: {args.input}")
            extractor = EndToEndLineageExtractor(dialect=args.dialect)
            result = extractor.process_directory(args.input)

            # Print data flow summary
            print(extractor.get_data_flow_summary())

            # Export all outputs
            print("\nGenerating outputs...")

            # 1. End-to-end lineage (summary - one row per target column)
            e2e_csv = safe_join(str(args.output), "end_to_end_lineage.csv")
            extractor.export_end_to_end_csv(e2e_csv)

            # 2. Comprehensive lineage (all hops - multiple rows per target column)
            comp_csv = safe_join(str(args.output), "comprehensive_lineage_all_hops.csv")
            extractor.export_comprehensive_csv(comp_csv)

            # 3. Full JSON analysis
            json_path = safe_join(str(args.output), "lineage_analysis.json")
            extractor.export_json(json_path)

            # 4. HTML Tree Visualization (shows full data flow with all tables)
            tree_html = safe_join(str(args.output), "end_to_end_lineage_tree.html")
            extractor.export_html_tree(tree_html, "End-to-End Data Lineage Tree")

            # 5. HTML Documentation (comprehensive docs with all details)
            docs_html = safe_join(str(args.output), "end_to_end_documentation.html")
            extractor.export_html_documentation(docs_html, "End-to-End Lineage Documentation")

            # 6. Structured Excel workbook (multiple worksheets)
            excel_path = safe_join(str(args.output), "lineage_analysis.xlsx")
            extractor.export_excel(excel_path, "End-to-End Lineage Analysis")

            # 7. Interactive Graph Visualization (Cytoscape.js) - Table level
            graph_html = safe_join(str(args.output), "lineage_interactive_graph.html")
            extractor.export_interactive_graph(graph_html, "Interactive End-to-End Data Lineage")

            # 8. Field-Level Graph Visualization (Cytoscape.js) - Column level
            field_graph_html = safe_join(str(args.output), "lineage_field_level_graph.html")
            extractor.export_field_level_graph(field_graph_html, "Field-Level Data Lineage")

            # Print statistics
            lineages = extractor.extract_end_to_end_lineage()
            print(f"\n{'='*60}")
            print("CROSS-FILE LINEAGE COMPLETE")
            print(f"{'='*60}")
            print(f"\nStatistics:")
            print(f"  Files processed: {result['files_processed']}")
            print(f"  Columns traced: {len(lineages)}")
            if lineages:
                print(f"  Max hop count: {max(l.hop_count for l in lineages)}")
                print(f"  Avg hop count: {sum(l.hop_count for l in lineages) / len(lineages):.1f}")
                print(f"  Unique sources: {len(set(l.ultimate_source_table for l in lineages))}")

            print(f"\nOutput files:")
            print(f"  - end_to_end_lineage.csv (summary)")
            print(f"  - comprehensive_lineage_all_hops.csv (detailed with all hops)")
            print(f"  - lineage_analysis.json (full analysis)")
            print(f"  - lineage_analysis.xlsx (structured Excel workbook)")
            print(f"  - end_to_end_lineage_tree.html (collapsible tree visualization)")
            print(f"  - end_to_end_documentation.html (comprehensive HTML documentation)")
            print(f"  - lineage_interactive_graph.html (interactive table-level DAG)")
            print(f"  - lineage_field_level_graph.html (interactive field-level DAG - click columns!)")

        except ImportError as e:
            print(f"Error: Required module not found: {e}")
            import traceback
            traceback.print_exc()
        except Exception as e:
            print(f"Error: {e}")
            import traceback
            traceback.print_exc()

    elif args.command == 'verify':
        # Recursive verification
        print(f"\n{'='*60}")
        print("RECURSIVE LINEAGE VERIFICATION")
        print(f"{'='*60}")

        try:
            from agent_interface.recursive_verifier import RecursiveVerifier

            # Load schema if provided
            schema = None
            if args.schema_dir:
                loader = DDLSchemaLoader(dialect=args.dialect)
                schema = loader.load_from_directory(args.schema_dir)

            with open(args.input, 'r', encoding='utf-8', errors='ignore') as f:
                sql = f.read()

            print(f"\nVerifying: {args.input}")

            # Run verification
            verifier = RecursiveVerifier(dialect=args.dialect)
            result = verifier.verify_and_correct(sql, schema)

            # Print result
            verifier.print_result(result)

            # Save report if output specified
            if args.output:
                args.output = _resolve_output_dir(args.output)
                os.makedirs(args.output, exist_ok=True)
                base_name = os.path.splitext(os.path.basename(args.input))[0]

                # Save verification report
                report_path = safe_join(str(args.output), f"{base_name}_verification.txt")
                with open(report_path, 'w', encoding='utf-8') as f:
                    f.write(result.summary)
                print(f"\nVerification report saved to: {report_path}")

                # Save corrected lineage if available
                if result.final_lineage:
                    csv_path = safe_join(str(args.output), f"{base_name}_corrected_lineage.csv")
                    doc_gen = SourceTargetMappingGenerator(result.final_lineage, result.final_elements)
                    doc_gen.generate_csv(csv_path)
                    print(f"Corrected lineage saved to: {csv_path}")

        except ImportError as e:
            print(f"Error: Required module not found: {e}")
        except Exception as e:
            print(f"Error: {e}")
            import traceback
            traceback.print_exc()

    elif args.command == 'expert-analyze':
        # Multi-expert architecture analysis
        print(f"\n{'='*60}")
        print("MULTI-EXPERT SQL ANALYSIS")
        print(f"{'='*60}")

        try:
            from experts.script_structure_parser import ScriptStructureParser
            from experts.field_mapping_expert import FieldMappingExpert
            from experts.operator_logic_expert import OperatorLogicExpert
            from experts.integration_expert import IntegrationExpert
            from experts.enhanced_code_reviewer import EnhancedCodeReviewer

            with open(args.input, 'r', encoding='utf-8', errors='ignore') as f:
                sql = f.read()

            args.output = _resolve_output_dir(args.output)
            os.makedirs(args.output, exist_ok=True)
            base_name = os.path.splitext(os.path.basename(args.input))[0]

            experts_to_run = args.experts if 'all' not in args.experts else ['structure', 'field', 'operator', 'integration']
            results = {}

            # Run individual experts or integration expert
            if 'integration' in experts_to_run or 'all' in args.experts:
                print("\nRunning IntegrationExpert (orchestrates all experts)...")
                integration = IntegrationExpert(
                    dialect=args.dialect,
                    parallel_execution=args.parallel
                )
                result = integration.analyze(sql)
                results['integration'] = result

                if result.success:
                    # Save integrated lineage CSV
                    csv_path = safe_join(str(args.output), f"{base_name}_expert_lineage.csv")
                    integration.export_csv(csv_path)
                    print(f"  Integrated lineage: {csv_path}")

                    # Save JSON output
                    json_path = safe_join(str(args.output), f"{base_name}_expert_analysis.json")
                    integration.export_json(json_path)
                    print(f"  Full analysis JSON: {json_path}")

                    # Print summary
                    integrated = integration.get_integrated_result()
                    if integrated:
                        print(f"\n  Results:")
                        print(f"    Lineage edges: {len(integrated.edges)}")
                        print(f"    Overall confidence: {integrated.overall_confidence:.2f}")
                        print(f"    Conflicts detected: {integrated.total_conflicts}")
                        print(f"    Conflicts resolved: {integrated.resolved_conflicts}")
                else:
                    print(f"  Error: {result.errors}")

            else:
                # Run individual experts
                if 'structure' in experts_to_run:
                    print("\nRunning ScriptStructureParser...")
                    parser = ScriptStructureParser(dialect=args.dialect)
                    result = parser.analyze(sql)
                    results['structure'] = result

                    if result.success:
                        structure_path = safe_join(str(args.output), f"{base_name}_structure.json")
                        with open(structure_path, 'w', encoding='utf-8') as f:
                            json.dump(result.data, f, indent=2)
                        print(f"  Structure analysis: {structure_path}")
                        print(f"  Subscripts: {result.metadata.get('subscript_count', 0)}")
                        print(f"  Max depth: {result.metadata.get('max_depth', 0)}")

                if 'field' in experts_to_run:
                    print("\nRunning FieldMappingExpert...")
                    field_expert = FieldMappingExpert(dialect=args.dialect)
                    result = field_expert.analyze(sql)
                    results['field'] = result

                    if result.success:
                        field_path = safe_join(str(args.output), f"{base_name}_field_mapping.json")
                        with open(field_path, 'w', encoding='utf-8') as f:
                            json.dump(result.data, f, indent=2)
                        print(f"  Field mapping: {field_path}")
                        print(f"  Mappings: {result.metadata.get('total_mappings', 0)}")

                if 'operator' in experts_to_run:
                    print("\nRunning OperatorLogicExpert...")
                    operator_expert = OperatorLogicExpert(dialect=args.dialect)
                    result = operator_expert.analyze(sql)
                    results['operator'] = result

                    if result.success:
                        operator_path = safe_join(str(args.output), f"{base_name}_operator_logic.json")
                        with open(operator_path, 'w', encoding='utf-8') as f:
                            json.dump(result.data, f, indent=2)
                        print(f"  Operator logic: {operator_path}")
                        print(f"  Conditions: {result.metadata.get('total_conditions', 0)}")
                        print(f"  Joins: {result.metadata.get('join_count', 0)}")

            # Run enhanced verification if requested
            if args.verify or 'review' in experts_to_run:
                print("\nRunning EnhancedCodeReviewer...")
                reviewer = EnhancedCodeReviewer(dialect=args.dialect)
                review_result = reviewer.analyze(sql)
                results['review'] = review_result

                if review_result.success:
                    review_path = safe_join(str(args.output), f"{base_name}_verification.json")
                    with open(review_path, 'w', encoding='utf-8') as f:
                        json.dump(review_result.data, f, indent=2)
                    print(f"  Verification report: {review_path}")

                    review_data = reviewer.get_result()
                    if review_data:
                        print(f"  Valid: {review_data.is_valid}")
                        print(f"  Issues: {len(review_data.get_all_issues())}")
                        if review_data.convergence_metrics:
                            print(f"  Iterations: {review_data.convergence_metrics.iterations_to_converge}")

            print(f"\n{'='*60}")
            print("MULTI-EXPERT ANALYSIS COMPLETE")
            print(f"{'='*60}")
            print(f"Output directory: {args.output}")

        except ImportError as e:
            print(f"Error: Required module not found: {e}")
            import traceback
            traceback.print_exc()
        except Exception as e:
            print(f"Error: {e}")
            import traceback
            traceback.print_exc()



def setup_additional_parsers(subparsers):
    """Setup additional command parsers for new functionality."""
    # Multi-file processing command
    multi_parser = subparsers.add_parser('multi-file',
        help='Process multiple files (DDL, Views, SQL) and build AST repository')
    multi_parser.add_argument('--input', '-i', required=True,
        help='Input directory containing DDL, View, and SQL files')
    multi_parser.add_argument('--output', '-o', required=True,
        help='Output directory for AST repository and schema')
    multi_parser.add_argument('--dialect', '-d', default='teradata',
        help='SQL dialect')
    multi_parser.add_argument('--pattern', nargs='+',
        default=['*.ddl', '*.vw', '*.sql', '*.txt'],
        help='File patterns to process')

    # Cross-file lineage command
    cross_parser = subparsers.add_parser('cross-file',
        help='Build cross-file end-to-end lineage from multiple SQL files')
    cross_parser.add_argument('--input', '-i', required=True,
        help='Input directory containing SQL files')
    cross_parser.add_argument('--output', '-o', required=True,
        help='Output directory for lineage outputs')
    cross_parser.add_argument('--dialect', '-d', default='teradata',
        help='SQL dialect')
    cross_parser.add_argument('--pattern', nargs='+',
        default=['*.ddl', '*.vw', '*.sql', '*.txt'],
        help='File patterns to process')

    # Recursive verification command
    verify_parser = subparsers.add_parser('verify',
        help='Recursively verify and correct lineage extraction')
    verify_parser.add_argument('--input', '-i', required=True,
        help='Input SQL file')
    verify_parser.add_argument('--output', '-o',
        help='Output directory for verification report')
    verify_parser.add_argument('--dialect', '-d', default='teradata',
        help='SQL dialect')
    verify_parser.add_argument('--schema-dir',
        help='Directory with DDL files for schema')

    return subparsers


if __name__ == '__main__':
    main()

