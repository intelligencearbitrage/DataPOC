"""
Recursive Verifier module.

Reconstructs SQL from lineage documentation, compares with original SQL,
detects discrepancies, and iteratively corrects issues until convergence.
"""

import sys
import os
import re
from typing import List, Dict, Optional, Tuple, Set, Any
from dataclasses import dataclass, field
from enum import Enum

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from ast_generator.parser import SQLASTGenerator
from deconstructor.element_extractor import SQLElementExtractor
from lineage.lineage_extractor import LineageExtractor
from lineage.lineage_graph import LineageGraph
from models.data_models import (
    ElementCatalog, ColumnRef, LineageEdge, TransformationInfo,
    TransformationType, TransformationSubtype
)
import sqlglot
from sqlglot import exp


class DiscrepancyType(Enum):
    """Types of discrepancies that can be detected."""
    MISSING_COLUMN = "MISSING_COLUMN"
    EXTRA_COLUMN = "EXTRA_COLUMN"
    WRONG_TRANSFORMATION = "WRONG_TRANSFORMATION"
    MISSING_SOURCE = "MISSING_SOURCE"
    WRONG_SOURCE = "WRONG_SOURCE"
    MISSING_JOIN = "MISSING_JOIN"
    MISSING_FILTER = "MISSING_FILTER"
    CASE_BRANCH_MISSING = "CASE_BRANCH_MISSING"
    AGGREGATION_MISSING = "AGGREGATION_MISSING"


@dataclass
class Discrepancy:
    """Represents a discrepancy between original and reconstructed SQL."""
    type: DiscrepancyType
    severity: str  # 'critical', 'warning', 'info'
    target_column: Optional[str] = None
    source_column: Optional[str] = None
    expected: str = ""
    actual: str = ""
    description: str = ""
    correction_applied: bool = False


@dataclass
class CorrectionAction:
    """Action taken to correct a discrepancy."""
    discrepancy: Discrepancy
    action_type: str  # 'add_edge', 'modify_transformation', 'add_source'
    details: str = ""
    success: bool = False


@dataclass
class VerificationIteration:
    """Results of a single verification iteration."""
    iteration_number: int
    discrepancies_found: List[Discrepancy] = field(default_factory=list)
    corrections_made: List[CorrectionAction] = field(default_factory=list)
    remaining_issues: int = 0
    converged: bool = False


@dataclass
class VerificationResult:
    """Complete verification result."""
    original_sql: str
    target_table: Optional[str] = None
    iterations: List[VerificationIteration] = field(default_factory=list)
    final_lineage: Optional[LineageGraph] = None
    final_elements: Optional[ElementCatalog] = None
    converged: bool = False
    total_discrepancies: int = 0
    total_corrections: int = 0
    summary: str = ""

    def to_dict(self) -> Dict[str, Any]:
        return {
            "target_table": self.target_table,
            "converged": self.converged,
            "iterations_count": len(self.iterations),
            "total_discrepancies": self.total_discrepancies,
            "total_corrections": self.total_corrections,
            "summary": self.summary
        }


class SQLReconstructor:
    """
    Reconstructs SQL SELECT clause from lineage documentation.

    Used to verify that lineage captures all transformations correctly
    by comparing reconstructed SQL with original.
    """

    def __init__(self, dialect: str = "teradata"):
        """Initialize reconstructor."""
        self.dialect = dialect

    def reconstruct_select_clause(self, lineage: LineageGraph,
                                   target_table: str) -> str:
        """
        Reconstruct SELECT clause from lineage edges.

        Args:
            lineage: LineageGraph
            target_table: Target table name

        Returns:
            Reconstructed SELECT clause
        """
        select_items = []
        target_upper = target_table.upper()

        # Group edges by target column
        by_target: Dict[str, List[LineageEdge]] = {}
        for edge in lineage.edges:
            if edge.target.table_name.upper() == target_upper:
                col_name = edge.target.column_name
                if col_name not in by_target:
                    by_target[col_name] = []
                by_target[col_name].append(edge)

        # Build SELECT items
        for target_col, edges in by_target.items():
            if len(edges) == 1:
                edge = edges[0]
                if edge.transformation and edge.transformation.sql_expression:
                    expr = edge.transformation.sql_expression
                    # Add alias if expression differs from column name
                    if not self._is_simple_column(expr, target_col):
                        select_items.append(f"{expr} AS {target_col}")
                    else:
                        select_items.append(target_col)
                else:
                    # Direct column reference
                    source = edge.source
                    if source.table_name and source.table_name != "[HARDCODED]":
                        select_items.append(f"{source.table_name}.{source.column_name} AS {target_col}")
                    else:
                        select_items.append(f"{source.column_name} AS {target_col}")
            else:
                # Multiple sources - likely a complex expression
                exprs = [e.transformation.sql_expression for e in edges
                         if e.transformation and e.transformation.sql_expression]
                if exprs:
                    select_items.append(f"{exprs[0]} AS {target_col}")
                else:
                    sources = [f"{e.source.table_name}.{e.source.column_name}" for e in edges]
                    select_items.append(f"/* multiple: {', '.join(sources)} */ AS {target_col}")

        return "SELECT\n    " + ",\n    ".join(select_items)

    def _is_simple_column(self, expr: str, col_name: str) -> bool:
        """Check if expression is a simple column reference."""
        # Simple if it's just the column name or table.column
        expr_clean = expr.strip().upper()
        col_clean = col_name.strip().upper()

        if expr_clean == col_clean:
            return True
        if expr_clean.endswith(f".{col_clean}"):
            return True
        return False

    def reconstruct_from_clause(self, lineage: LineageGraph,
                                 elements: Optional[ElementCatalog]) -> str:
        """
        Reconstruct FROM clause from lineage and elements.

        Args:
            lineage: LineageGraph
            elements: Optional ElementCatalog with join info

        Returns:
            Reconstructed FROM clause
        """
        # Get all source tables from lineage
        source_tables = lineage.get_source_tables()

        if not source_tables:
            return "FROM /* unknown source */"

        from_parts = []
        processed_tables = set()

        # Add primary table
        primary = list(source_tables)[0]
        from_parts.append(f"FROM {primary}")
        processed_tables.add(primary)

        # Add joins from elements if available
        if elements and elements.joins:
            for join in elements.joins:
                if join.right_table not in processed_tables:
                    join_sql = f"{join.join_type} JOIN {join.right_table}"
                    if join.predicate_sql:
                        join_sql += f" ON {join.predicate_sql}"
                    from_parts.append(join_sql)
                    processed_tables.add(join.right_table)
        else:
            # Add remaining tables as cross joins (incomplete info)
            for table in source_tables:
                if table not in processed_tables:
                    from_parts.append(f"/* JOIN */ {table}")
                    processed_tables.add(table)

        return "\n".join(from_parts)

    def reconstruct_where_clause(self, elements: Optional[ElementCatalog]) -> str:
        """Reconstruct WHERE clause from elements."""
        if elements and elements.where_clause:
            return f"WHERE {elements.where_clause.sql_text}"
        return ""


class DiscrepancyDetector:
    """
    Detects discrepancies between original SQL and reconstructed SQL from lineage.
    """

    def __init__(self, dialect: str = "teradata"):
        """Initialize detector."""
        self.dialect = dialect
        self.parser = SQLASTGenerator(dialect=dialect)

    def detect_discrepancies(self, original_sql: str, lineage: LineageGraph,
                             elements: ElementCatalog,
                             ast: Optional[exp.Expression] = None) -> List[Discrepancy]:
        """
        Detect discrepancies between original SQL and lineage documentation.

        Args:
            original_sql: Original SQL statement
            lineage: Generated lineage
            elements: Extracted elements
            ast: Optional pre-parsed AST to avoid redundant parsing

        Returns:
            List of detected discrepancies
        """
        discrepancies = []

        try:
            if ast is None:
                ast = self.parser.parse(original_sql)
        except Exception as e:
            discrepancies.append(Discrepancy(
                type=DiscrepancyType.MISSING_COLUMN,
                severity='critical',
                description=f"Failed to parse original SQL: {str(e)}"
            ))
            return discrepancies

        # Check target columns
        discrepancies.extend(self._check_target_columns(ast, lineage))

        # Check source columns
        discrepancies.extend(self._check_source_columns(ast, lineage))

        # Check transformations
        discrepancies.extend(self._check_transformations(ast, lineage, elements))

        # Check CASE statements
        discrepancies.extend(self._check_case_statements(ast, elements))

        # Check JOINs
        discrepancies.extend(self._check_joins(ast, elements))

        return discrepancies

    def _check_target_columns(self, ast: exp.Expression,
                               lineage: LineageGraph) -> List[Discrepancy]:
        """Check that all target columns are captured in lineage."""
        discrepancies = []

        # Get expected target columns from SQL
        expected_cols = self._extract_target_columns(ast)

        # Get captured columns from lineage
        captured_cols = set()
        for edge in lineage.edges:
            if edge.target.column_name:
                captured_cols.add(edge.target.column_name.upper())

        # Check for missing columns
        for col in expected_cols:
            if col.upper() not in captured_cols:
                discrepancies.append(Discrepancy(
                    type=DiscrepancyType.MISSING_COLUMN,
                    severity='critical',
                    target_column=col,
                    expected=col,
                    actual="Not found in lineage",
                    description=f"Target column '{col}' not captured in lineage"
                ))

        # Check for extra columns
        expected_upper = {c.upper() for c in expected_cols}
        for col in captured_cols:
            if col not in expected_upper:
                discrepancies.append(Discrepancy(
                    type=DiscrepancyType.EXTRA_COLUMN,
                    severity='warning',
                    target_column=col,
                    expected="Not in original SQL",
                    actual=col,
                    description=f"Extra column '{col}' in lineage not found in original SQL"
                ))

        return discrepancies

    def _extract_target_columns(self, ast: exp.Expression) -> List[str]:
        """Extract target column names from SQL."""
        columns = []

        # Check INSERT column list
        insert = ast.find(exp.Insert)
        if insert:
            schema = insert.find(exp.Schema)
            if schema and schema.expressions:
                for expr in schema.expressions:
                    if isinstance(expr, exp.Column):
                        columns.append(expr.name)
                    elif hasattr(expr, 'name'):
                        columns.append(expr.name)

        # If no INSERT columns, use SELECT aliases
        if not columns:
            select = ast.find(exp.Select)
            if select:
                for i, expr in enumerate(select.expressions):
                    if isinstance(expr, exp.Alias):
                        columns.append(expr.alias)
                    elif isinstance(expr, exp.Column):
                        columns.append(expr.name)
                    else:
                        columns.append(f"col_{i+1}")

        return columns

    def _check_source_columns(self, ast: exp.Expression,
                               lineage: LineageGraph) -> List[Discrepancy]:
        """Check that source columns are correctly traced."""
        discrepancies = []

        # Get all column references from SQL
        sql_columns = set()
        for col in ast.find_all(exp.Column):
            col_name = col.name
            if col_name:
                sql_columns.add(col_name.upper())

        # Get traced source columns
        traced_columns = set()
        for edge in lineage.edges:
            if edge.source.column_name and edge.source.table_name != "[HARDCODED]":
                traced_columns.add(edge.source.column_name.upper())

        # Note: Not all SQL columns need to be in lineage (e.g., WHERE clause columns)
        # Only flag if significant percentage missing
        missing_ratio = len(sql_columns - traced_columns) / max(len(sql_columns), 1)
        if missing_ratio > 0.5:  # More than 50% missing
            discrepancies.append(Discrepancy(
                type=DiscrepancyType.MISSING_SOURCE,
                severity='warning',
                description=f"Many source columns not traced: {sql_columns - traced_columns}"
            ))

        return discrepancies

    def _check_transformations(self, ast: exp.Expression, lineage: LineageGraph,
                                elements: ElementCatalog) -> List[Discrepancy]:
        """Check transformation accuracy."""
        discrepancies = []

        # Check for complex expressions that should have transformations
        select = ast.find(exp.Select)
        if not select:
            return discrepancies

        for edge in lineage.edges:
            if not edge.transformation.sql_expression:
                discrepancies.append(Discrepancy(
                    type=DiscrepancyType.WRONG_TRANSFORMATION,
                    severity='info',
                    target_column=edge.target.column_name,
                    description=f"Missing transformation expression for {edge.target.column_name}"
                ))

        return discrepancies

    def _check_case_statements(self, ast: exp.Expression,
                                elements: ElementCatalog) -> List[Discrepancy]:
        """Check CASE statement capture."""
        discrepancies = []

        ast_cases = list(ast.find_all(exp.Case))
        extracted_cases = elements.case_statements if elements else []

        if len(ast_cases) != len(extracted_cases):
            discrepancies.append(Discrepancy(
                type=DiscrepancyType.CASE_BRANCH_MISSING,
                severity='warning',
                expected=str(len(ast_cases)),
                actual=str(len(extracted_cases)),
                description=f"CASE statement count mismatch: SQL has {len(ast_cases)}, extracted {len(extracted_cases)}"
            ))

        return discrepancies

    def _check_joins(self, ast: exp.Expression,
                      elements: ElementCatalog) -> List[Discrepancy]:
        """Check JOIN capture."""
        discrepancies = []

        ast_joins = list(ast.find_all(exp.Join))
        extracted_joins = elements.joins if elements else []

        if len(ast_joins) != len(extracted_joins):
            discrepancies.append(Discrepancy(
                type=DiscrepancyType.MISSING_JOIN,
                severity='warning',
                expected=str(len(ast_joins)),
                actual=str(len(extracted_joins)),
                description=f"JOIN count mismatch: SQL has {len(ast_joins)}, extracted {len(extracted_joins)}"
            ))

        return discrepancies


class CorrectionEngine:
    """
    Applies corrections to lineage based on detected discrepancies.
    """

    def __init__(self, dialect: str = "teradata"):
        """Initialize correction engine."""
        self.dialect = dialect
        self.parser = SQLASTGenerator(dialect=dialect)

    def apply_corrections(self, original_sql: str, lineage: LineageGraph,
                          elements: ElementCatalog,
                          discrepancies: List[Discrepancy],
                          ast: Optional[exp.Expression] = None) -> Tuple[LineageGraph, ElementCatalog, List[CorrectionAction]]:
        """
        Apply corrections to lineage based on discrepancies.

        Args:
            original_sql: Original SQL
            lineage: Current lineage graph
            elements: Current elements catalog
            discrepancies: Detected discrepancies
            ast: Optional pre-parsed AST to avoid redundant parsing

        Returns:
            Tuple of (corrected_lineage, corrected_elements, actions_taken)
        """
        actions = []

        try:
            if ast is None:
                ast = self.parser.parse(original_sql)
        except Exception:
            return lineage, elements, actions

        # Get target table
        target_table = self._get_target_table(ast) or "TARGET"

        for discrepancy in discrepancies:
            if discrepancy.type == DiscrepancyType.MISSING_COLUMN:
                action = self._correct_missing_column(
                    ast, lineage, target_table, discrepancy.target_column
                )
                if action:
                    actions.append(action)
                    discrepancy.correction_applied = True

            elif discrepancy.type == DiscrepancyType.WRONG_TRANSFORMATION:
                action = self._correct_transformation(
                    ast, lineage, target_table, discrepancy.target_column
                )
                if action:
                    actions.append(action)
                    discrepancy.correction_applied = True

        return lineage, elements, actions

    def _get_target_table(self, ast: exp.Expression) -> Optional[str]:
        """Extract target table from AST."""
        if isinstance(ast, exp.Insert):
            table = ast.this
            if isinstance(table, exp.Table):
                return table.name
            elif hasattr(table, 'this') and isinstance(table.this, exp.Table):
                return table.this.name
        return None

    def _correct_missing_column(self, ast: exp.Expression, lineage: LineageGraph,
                                  target_table: str, column_name: str) -> Optional[CorrectionAction]:
        """Attempt to correct a missing column."""
        select = ast.find(exp.Select)
        if not select:
            return None

        # Find the expression for this column
        for expr in select.expressions:
            alias = None
            inner_expr = expr

            if isinstance(expr, exp.Alias):
                alias = expr.alias
                inner_expr = expr.this
            elif isinstance(expr, exp.Column):
                alias = expr.name

            if alias == column_name or (not alias and isinstance(inner_expr, exp.Column)
                                         and inner_expr.name == column_name):
                # Found the expression
                sql_text = inner_expr.sql(dialect=self.dialect) if hasattr(inner_expr, 'sql') else str(inner_expr)

                # Extract source column
                source_cols = list(inner_expr.find_all(exp.Column)) if hasattr(inner_expr, 'find_all') else []

                if source_cols:
                    source_col = source_cols[0]
                    source_table = source_col.table if hasattr(source_col, 'table') and source_col.table else "SOURCE"

                    source_ref = ColumnRef(
                        table_name=source_table,
                        column_name=source_col.name
                    )
                    target_ref = ColumnRef(
                        table_name=target_table,
                        column_name=column_name
                    )

                    transformation = TransformationInfo(
                        type=TransformationType.INDIRECT,
                        subtype=TransformationSubtype.TRANSFORMATION,
                        description="Auto-corrected from original SQL",
                        sql_expression=sql_text
                    )

                    lineage.add_lineage(source_ref, target_ref, transformation)

                    return CorrectionAction(
                        discrepancy=Discrepancy(
                            type=DiscrepancyType.MISSING_COLUMN,
                            severity='critical',
                            target_column=column_name
                        ),
                        action_type='add_edge',
                        details=f"Added lineage for {column_name} from {source_table}.{source_col.name}",
                        success=True
                    )

        return None

    def _correct_transformation(self, ast: exp.Expression, lineage: LineageGraph,
                                 target_table: str, column_name: str) -> Optional[CorrectionAction]:
        """Attempt to correct a transformation."""
        # Find existing edge and update transformation
        for edge in lineage.edges:
            if (edge.target.table_name.upper() == target_table.upper() and
                edge.target.column_name.upper() == column_name.upper()):

                # Find expression in original SQL
                select = ast.find(exp.Select)
                if select:
                    for expr in select.expressions:
                        alias = None
                        if isinstance(expr, exp.Alias):
                            alias = expr.alias
                            inner = expr.this
                        elif isinstance(expr, exp.Column):
                            alias = expr.name
                            inner = expr
                        else:
                            continue

                        if alias and alias.upper() == column_name.upper():
                            sql_text = inner.sql(dialect=self.dialect) if hasattr(inner, 'sql') else str(inner)
                            edge.transformation.sql_expression = sql_text

                            return CorrectionAction(
                                discrepancy=Discrepancy(
                                    type=DiscrepancyType.WRONG_TRANSFORMATION,
                                    severity='warning',
                                    target_column=column_name
                                ),
                                action_type='modify_transformation',
                                details=f"Updated transformation for {column_name}",
                                success=True
                            )

        return None


class RecursiveVerifier:
    """
    Recursively verifies and corrects lineage until convergence.

    Process:
    1. Extract lineage from original SQL
    2. Reconstruct SQL from lineage
    3. Detect discrepancies
    4. Apply corrections
    5. Repeat until converged or max iterations reached
    """

    MAX_ITERATIONS = 5

    def __init__(self, dialect: str = "teradata"):
        """Initialize verifier."""
        self.dialect = dialect
        self.parser = SQLASTGenerator(dialect=dialect)
        self.reconstructor = SQLReconstructor(dialect=dialect)
        self.detector = DiscrepancyDetector(dialect=dialect)
        self.corrector = CorrectionEngine(dialect=dialect)

    def verify_and_correct(self, sql: str, schema: dict = None,
                           ast: Optional[exp.Expression] = None,
                           lineage: Optional[LineageGraph] = None,
                           elements: Optional[ElementCatalog] = None) -> VerificationResult:
        """
        Verify lineage and apply corrections until convergence.

        Args:
            sql: Original SQL statement
            schema: Optional schema dict
            ast: Optional pre-parsed AST to avoid redundant parsing
            lineage: Optional pre-built LineageGraph to avoid re-extraction
            elements: Optional pre-built ElementCatalog to avoid re-extraction

        Returns:
            VerificationResult with all iterations and final state
        """
        result = VerificationResult(original_sql=sql)

        # Initial extraction (skip if pre-parsed objects provided)
        try:
            if ast is None:
                ast = self.parser.parse(sql)
            if elements is None:
                extractor = SQLElementExtractor(ast, self.dialect)
                elements = extractor.extract_all()
            if lineage is None:
                lineage_extractor = LineageExtractor(schema=schema, dialect=self.dialect)
                lineage = lineage_extractor.extract_lineage(sql)

            result.target_table = elements.target_table
        except Exception as e:
            result.summary = f"Initial extraction failed: {str(e)}"
            return result

        # Iterative verification and correction
        for iteration in range(1, self.MAX_ITERATIONS + 1):
            iter_result = VerificationIteration(iteration_number=iteration)

            # Detect discrepancies (pass pre-parsed AST to avoid re-parsing)
            discrepancies = self.detector.detect_discrepancies(
                sql, lineage, elements, ast=ast
            )
            iter_result.discrepancies_found = discrepancies

            # Count critical issues
            critical_count = sum(1 for d in discrepancies if d.severity == 'critical')
            iter_result.remaining_issues = critical_count

            if critical_count == 0:
                # No critical issues - converged
                iter_result.converged = True
                result.iterations.append(iter_result)
                result.converged = True
                break

            # Apply corrections (pass pre-parsed AST to avoid re-parsing)
            lineage, elements, actions = self.corrector.apply_corrections(
                sql, lineage, elements, discrepancies, ast=ast
            )
            iter_result.corrections_made = actions

            result.iterations.append(iter_result)

            # Check if any corrections were made
            if not actions:
                # No corrections possible - stop iterating
                break

        # Final state
        result.final_lineage = lineage
        result.final_elements = elements
        result.total_discrepancies = sum(
            len(i.discrepancies_found) for i in result.iterations
        )
        result.total_corrections = sum(
            len(i.corrections_made) for i in result.iterations
        )

        # Generate summary
        result.summary = self._generate_summary(result)

        return result

    def _generate_summary(self, result: VerificationResult) -> str:
        """Generate verification summary."""
        lines = []
        lines.append("=" * 60)
        lines.append("RECURSIVE VERIFICATION SUMMARY")
        lines.append("=" * 60)

        if result.target_table:
            lines.append(f"Target Table: {result.target_table}")

        lines.append(f"Total Iterations: {len(result.iterations)}")
        lines.append(f"Converged: {'Yes' if result.converged else 'No'}")
        lines.append(f"Total Discrepancies Found: {result.total_discrepancies}")
        lines.append(f"Total Corrections Applied: {result.total_corrections}")

        lines.append("\nIteration Details:")
        for iter_result in result.iterations:
            lines.append(f"\n  Iteration {iter_result.iteration_number}:")
            lines.append(f"    Discrepancies: {len(iter_result.discrepancies_found)}")
            lines.append(f"    Corrections: {len(iter_result.corrections_made)}")
            lines.append(f"    Remaining Critical: {iter_result.remaining_issues}")

            if iter_result.converged:
                lines.append("    Status: CONVERGED")

        lines.append("\n" + "=" * 60)
        if result.converged:
            lines.append("RESULT: VERIFICATION PASSED - Lineage is complete and accurate")
        else:
            lines.append("RESULT: VERIFICATION INCOMPLETE - Some issues remain unresolved")
        lines.append("=" * 60)

        return "\n".join(lines)

    def print_result(self, result: VerificationResult) -> None:
        """Print verification result to console."""
        print(result.summary)
