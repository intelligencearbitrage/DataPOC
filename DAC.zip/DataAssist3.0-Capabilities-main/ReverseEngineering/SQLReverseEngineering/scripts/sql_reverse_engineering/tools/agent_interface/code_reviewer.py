"""
Code Reviewer Agent module.

Reviews generated lineage output against original SQL to:
- Verify all target columns are captured
- Confirm transformation logic accuracy
- Identify any omissions
- Suggest corrections and regenerate if needed
"""

import re
import sys
import os
from typing import List, Dict, Optional, Tuple, Set
from dataclasses import dataclass, field

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from ast_generator.parser import SQLASTGenerator
from deconstructor.element_extractor import SQLElementExtractor
from lineage.lineage_extractor import LineageExtractor
from lineage.lineage_graph import LineageGraph
from documentation.mapping_generator import SourceTargetMappingGenerator
from models.data_models import ElementCatalog, ColumnRef, LineageEdge, TransformationInfo, TransformationType
import sqlglot
from sqlglot import exp


@dataclass
class ReviewIssue:
    """Represents an issue found during review."""
    issue_type: str  # 'missing_column', 'missing_transformation', 'incorrect_logic', 'missing_join', 'missing_filter'
    severity: str  # 'error', 'warning', 'info'
    description: str
    expected: str = ""
    actual: str = ""
    suggestion: str = ""


@dataclass
class ReviewResult:
    """Results of the code review."""
    sql_file: str
    is_valid: bool
    issues: List[ReviewIssue] = field(default_factory=list)
    target_table: str = ""
    expected_columns: List[str] = field(default_factory=list)
    captured_columns: List[str] = field(default_factory=list)
    missing_columns: List[str] = field(default_factory=list)
    extra_columns: List[str] = field(default_factory=list)
    summary: str = ""


class CodeReviewerAgent:
    """
    Agent that reviews generated lineage to ensure accuracy and completeness.
    """

    def __init__(self, dialect: str = "teradata"):
        """
        Initialize the reviewer agent.

        Args:
            dialect: SQL dialect for parsing
        """
        self.dialect = dialect
        self.parser = SQLASTGenerator(dialect=dialect)

    def review_lineage(self, sql: str, lineage_graph: LineageGraph,
                       elements: ElementCatalog,
                       ast: Optional[exp.Expression] = None) -> ReviewResult:
        """
        Review lineage output against original SQL.

        Args:
            sql: Original SQL statement
            lineage_graph: Generated lineage graph
            elements: Extracted SQL elements
            ast: Optional pre-parsed AST to avoid redundant parsing

        Returns:
            ReviewResult with findings
        """
        result = ReviewResult(sql_file="", is_valid=True, issues=[])

        try:
            # Parse SQL to extract expected structure (skip if pre-parsed AST provided)
            if ast is None:
                ast = self.parser.parse(sql)

            # 1. Review target table and columns
            self._review_target_columns(ast, lineage_graph, elements, result)

            # 2. Review source columns coverage
            self._review_source_columns(ast, lineage_graph, result)

            # 3. Review transformation logic
            self._review_transformations(ast, lineage_graph, elements, result)

            # 4. Review JOIN conditions
            self._review_joins(ast, elements, result)

            # 5. Review WHERE conditions
            self._review_filters(ast, elements, result)

            # 6. Review CASE statements
            self._review_case_statements(ast, elements, result)

            # Determine overall validity
            error_count = sum(1 for i in result.issues if i.severity == 'error')
            result.is_valid = error_count == 0

            # Generate summary
            result.summary = self._generate_summary(result)

        except Exception as e:
            result.is_valid = False
            result.issues.append(ReviewIssue(
                issue_type='parse_error',
                severity='error',
                description=f"Failed to parse SQL for review: {str(e)}"
            ))

        return result

    def review_and_regenerate(self, sql: str, schema: dict = None,
                               output_path: str = None,
                               ast: Optional[exp.Expression] = None,
                               lineage: Optional[LineageGraph] = None,
                               elements: Optional[ElementCatalog] = None) -> Tuple[ReviewResult, Optional[str]]:
        """
        Review SQL, identify issues, and regenerate corrected output.

        Args:
            sql: Original SQL statement
            schema: Optional schema dict
            output_path: Path for regenerated output
            ast: Optional pre-parsed AST to avoid redundant parsing
            lineage: Optional pre-built LineageGraph to avoid re-extraction
            elements: Optional pre-built ElementCatalog to avoid re-extraction

        Returns:
            Tuple of (ReviewResult, regenerated CSV path or None)
        """
        # Initial extraction (skip if pre-parsed objects provided)
        if ast is None:
            ast = self.parser.parse(sql)
        if elements is None:
            extractor = SQLElementExtractor(ast, self.dialect)
            elements = extractor.extract_all()
        if lineage is None:
            lineage_extractor = LineageExtractor(schema=schema, dialect=self.dialect)
            lineage = lineage_extractor.extract_lineage(sql)

        # Review
        result = self.review_lineage(sql, lineage, elements, ast=ast)

        # If issues found, attempt to fix and regenerate
        if not result.is_valid or result.missing_columns:
            # Attempt corrections
            corrected_lineage, corrected_elements = self._attempt_corrections(
                sql, ast, lineage, elements, result
            )

            # Regenerate with corrected data
            if output_path:
                doc_gen = SourceTargetMappingGenerator(corrected_lineage, corrected_elements)
                doc_gen.generate_comprehensive_csv(output_path)

                # Re-review
                result = self.review_lineage(sql, corrected_lineage, corrected_elements, ast=ast)
                return result, output_path

        # Generate output if path provided
        if output_path:
            doc_gen = SourceTargetMappingGenerator(lineage, elements)
            doc_gen.generate_comprehensive_csv(output_path)

        return result, output_path

    def _review_target_columns(self, ast: exp.Expression, lineage: LineageGraph,
                                elements: ElementCatalog, result: ReviewResult) -> None:
        """Review that all target columns are captured."""
        # Get expected target columns from SQL
        expected_cols = self._extract_target_columns(ast)
        result.expected_columns = expected_cols

        # Get target table
        result.target_table = elements.target_table or ""

        # Get captured columns from lineage
        captured_cols = set()
        for edge in lineage.edges:
            if edge.target.column_name:
                captured_cols.add(edge.target.column_name)

        result.captured_columns = list(captured_cols)

        # Find missing columns
        expected_set = set(expected_cols)
        result.missing_columns = list(expected_set - captured_cols)
        result.extra_columns = list(captured_cols - expected_set)

        # Report issues
        for col in result.missing_columns:
            result.issues.append(ReviewIssue(
                issue_type='missing_column',
                severity='error',
                description=f"Target column '{col}' not captured in lineage",
                expected=col,
                actual="",
                suggestion=f"Add lineage mapping for column: {col}"
            ))

    def _review_source_columns(self, ast: exp.Expression, lineage: LineageGraph,
                                result: ReviewResult) -> None:
        """Review that all source columns are properly traced."""
        # Get all column references from SQL
        sql_columns = set()
        for col in ast.find_all(exp.Column):
            col_name = col.name
            table = col.table if hasattr(col, 'table') else None
            if table:
                sql_columns.add(f"{table}.{col_name}")
            else:
                sql_columns.add(col_name)

        # Get traced source columns
        traced_columns = set()
        for edge in lineage.edges:
            if edge.source.column_name:
                if edge.source.table_name:
                    traced_columns.add(f"{edge.source.table_name}.{edge.source.column_name}")
                traced_columns.add(edge.source.column_name)

        # Check for untraced columns (warning, not error - some may be literals)
        # This is informational since not all column refs need lineage
        pass

    def _review_transformations(self, ast: exp.Expression, lineage: LineageGraph,
                                 elements: ElementCatalog, result: ReviewResult) -> None:
        """Review transformation logic accuracy."""
        # Check that transformations in lineage match SQL expressions
        for edge in lineage.edges:
            if not edge.transformation.sql_expression:
                result.issues.append(ReviewIssue(
                    issue_type='missing_transformation',
                    severity='warning',
                    description=f"Missing transformation logic for {edge.target.column_name}",
                    expected="Transformation expression",
                    actual="",
                    suggestion="Extract transformation expression from SELECT clause"
                ))

    def _review_joins(self, ast: exp.Expression, elements: ElementCatalog,
                      result: ReviewResult) -> None:
        """Review that all JOIN conditions are captured."""
        # Count JOINs in AST
        ast_joins = list(ast.find_all(exp.Join))
        extracted_joins = elements.joins if elements else []

        if len(ast_joins) != len(extracted_joins):
            result.issues.append(ReviewIssue(
                issue_type='missing_join',
                severity='warning',
                description=f"JOIN count mismatch: SQL has {len(ast_joins)}, extracted {len(extracted_joins)}",
                expected=str(len(ast_joins)),
                actual=str(len(extracted_joins)),
                suggestion="Review JOIN extraction logic"
            ))

        # Verify each JOIN has ON condition documented
        for join in extracted_joins:
            if not join.predicate_sql:
                result.issues.append(ReviewIssue(
                    issue_type='missing_join',
                    severity='warning',
                    description=f"JOIN to {join.right_table} missing ON condition",
                    suggestion="Extract ON condition for this JOIN"
                ))

    def _review_filters(self, ast: exp.Expression, elements: ElementCatalog,
                        result: ReviewResult) -> None:
        """Review that WHERE conditions are captured."""
        # Check for WHERE clause in AST
        where_clause = ast.find(exp.Where)

        if where_clause and (not elements or not elements.where_clause):
            result.issues.append(ReviewIssue(
                issue_type='missing_filter',
                severity='warning',
                description="WHERE clause exists in SQL but not captured",
                expected=where_clause.sql(dialect=self.dialect) if where_clause else "",
                actual="",
                suggestion="Extract WHERE clause conditions"
            ))

    def _review_case_statements(self, ast: exp.Expression, elements: ElementCatalog,
                                 result: ReviewResult) -> None:
        """Review that all CASE statements are captured."""
        # Count CASE statements in AST
        ast_cases = list(ast.find_all(exp.Case))
        extracted_cases = elements.case_statements if elements else []

        if len(ast_cases) != len(extracted_cases):
            result.issues.append(ReviewIssue(
                issue_type='missing_case',
                severity='warning',
                description=f"CASE statement count mismatch: SQL has {len(ast_cases)}, extracted {len(extracted_cases)}",
                expected=str(len(ast_cases)),
                actual=str(len(extracted_cases)),
                suggestion="Review CASE statement extraction"
            ))

        # Verify each CASE has all branches documented
        for case in extracted_cases:
            if not case.branches:
                result.issues.append(ReviewIssue(
                    issue_type='incomplete_case',
                    severity='warning',
                    description=f"CASE statement missing branches",
                    suggestion="Extract all WHEN/THEN branches"
                ))

    def _extract_target_columns(self, ast: exp.Expression) -> List[str]:
        """Extract expected target column names from SQL."""
        columns = []

        # Check for INSERT statement with column list
        insert = ast.find(exp.Insert)
        if insert:
            # Try to get column list from INSERT
            schema = insert.find(exp.Schema)
            if schema:
                for expr in schema.expressions:
                    if isinstance(expr, exp.Column):
                        columns.append(expr.name)
                    elif hasattr(expr, 'name'):
                        columns.append(expr.name)

        # If no INSERT column list, get from SELECT
        if not columns:
            select = ast.find(exp.Select)
            if select:
                for i, expr in enumerate(select.expressions):
                    if isinstance(expr, exp.Alias):
                        columns.append(expr.alias)
                    elif isinstance(expr, exp.Column):
                        columns.append(expr.name)
                    else:
                        columns.append(f"col_{i+1}")

        return columns

    def _attempt_corrections(self, sql: str, ast: exp.Expression,
                              lineage: LineageGraph, elements: ElementCatalog,
                              result: ReviewResult) -> Tuple[LineageGraph, ElementCatalog]:
        """
        Attempt to correct identified issues.

        Returns:
            Tuple of corrected (LineageGraph, ElementCatalog)
        """
        corrected_lineage = lineage

        # If missing columns, try to extract them from SELECT clause
        if result.missing_columns:
            select = ast.find(exp.Select)
            if select:
                target_table = result.target_table or "TARGET"

                for col_name in result.missing_columns:
                    # Try to find corresponding expression in SELECT
                    for expr in select.expressions:
                        alias = None
                        if isinstance(expr, exp.Alias):
                            alias = expr.alias
                            inner_expr = expr.this
                        else:
                            inner_expr = expr
                            if isinstance(expr, exp.Column):
                                alias = expr.name

                        if alias == col_name or (not alias and isinstance(inner_expr, exp.Column) and inner_expr.name == col_name):
                            # Found the expression, create lineage edge
                            sql_text = inner_expr.sql(dialect=self.dialect) if hasattr(inner_expr, 'sql') else str(inner_expr)

                            # Extract source column
                            source_cols = list(inner_expr.find_all(exp.Column)) if hasattr(inner_expr, 'find_all') else []
                            if source_cols:
                                source_col = source_cols[0]
                                source_table = source_col.table if hasattr(source_col, 'table') and source_col.table else "SOURCE"

                                source_ref = ColumnRef(
                                    table_name=source_table,
                                    column_name=source_col.name
                                )
                                target_ref = ColumnRef(
                                    table_name=target_table,
                                    column_name=col_name
                                )

                                edge = LineageEdge(
                                    source=source_ref,
                                    target=target_ref,
                                    transformation=TransformationInfo(
                                        type=TransformationType.INDIRECT,
                                        subtype=TransformationType.TRANSFORMATION,
                                        sql_expression=sql_text
                                    )
                                )
                                corrected_lineage.add_edge(edge)
                            break

        return corrected_lineage, elements

    def _generate_summary(self, result: ReviewResult) -> str:
        """Generate human-readable summary of review."""
        lines = []
        lines.append("=" * 60)
        lines.append("CODE REVIEW SUMMARY")
        lines.append("=" * 60)

        if result.target_table:
            lines.append(f"Target Table: {result.target_table}")

        lines.append(f"Expected Columns: {len(result.expected_columns)}")
        lines.append(f"Captured Columns: {len(result.captured_columns)}")

        if result.missing_columns:
            lines.append(f"\nMISSING COLUMNS ({len(result.missing_columns)}):")
            for col in result.missing_columns:
                lines.append(f"  - {col}")

        if result.extra_columns:
            lines.append(f"\nEXTRA COLUMNS ({len(result.extra_columns)}):")
            for col in result.extra_columns:
                lines.append(f"  - {col}")

        # Group issues by type
        issues_by_type = {}
        for issue in result.issues:
            if issue.issue_type not in issues_by_type:
                issues_by_type[issue.issue_type] = []
            issues_by_type[issue.issue_type].append(issue)

        if issues_by_type:
            lines.append(f"\nISSUES FOUND ({len(result.issues)} total):")
            for issue_type, issues in issues_by_type.items():
                lines.append(f"\n  {issue_type.upper()} ({len(issues)}):")
                for issue in issues[:5]:  # Show first 5 of each type
                    lines.append(f"    [{issue.severity.upper()}] {issue.description}")
                    if issue.suggestion:
                        lines.append(f"      Suggestion: {issue.suggestion}")
                if len(issues) > 5:
                    lines.append(f"    ... and {len(issues) - 5} more")

        lines.append("\n" + "=" * 60)
        if result.is_valid:
            lines.append("RESULT: PASSED - All target columns captured correctly")
        else:
            lines.append("RESULT: ISSUES FOUND - Review and corrections needed")
        lines.append("=" * 60)

        return "\n".join(lines)

    def print_review(self, result: ReviewResult) -> None:
        """Print review results to console."""
        print(result.summary)


def review_sql_file(filepath: str, dialect: str = "teradata",
                    schema: dict = None, output_path: str = None) -> ReviewResult:
    """
    Convenience function to review a SQL file.

    Args:
        filepath: Path to SQL file
        dialect: SQL dialect
        schema: Optional schema dict
        output_path: Optional path for regenerated output

    Returns:
        ReviewResult
    """
    with open(filepath, 'r', encoding='utf-8', errors='ignore') as f:
        sql = f.read()

    reviewer = CodeReviewerAgent(dialect=dialect)
    result, _ = reviewer.review_and_regenerate(sql, schema, output_path)
    result.sql_file = filepath

    return result
