"""
REST API module using FastAPI.

Exposes SQL reverse engineering capabilities via HTTP endpoints
for external tools and agents.
"""

from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from typing import Optional, Dict, List, Any
import sys
import os

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from ast_generator.parser import SQLASTGenerator
from deconstructor.element_extractor import SQLElementExtractor
from lineage.lineage_extractor import LineageExtractor
from lineage.lineage_graph import LineageGraph
from documentation.mapping_generator import SourceTargetMappingGenerator
from schema.ddl_parser import DDLSchemaLoader


app = FastAPI(
    title="SQL Reverse Engineering API",
    description="API for parsing SQL, extracting lineage, and generating documentation",
    version="1.0.0"
)


# Request/Response Models
class ParseRequest(BaseModel):
    """Request model for parsing SQL."""
    sql: str
    dialect: str = "teradata"


class LineageRequest(BaseModel):
    """Request model for lineage extraction."""
    sql: str
    dialect: str = "teradata"
    schema: Optional[Dict[str, List[str]]] = None


class DocumentRequest(BaseModel):
    """Request model for documentation generation."""
    sql: str
    dialect: str = "teradata"
    schema: Optional[Dict[str, List[str]]] = None
    job_name: Optional[str] = ""
    procedure_name: Optional[str] = ""


class SchemaLoadRequest(BaseModel):
    """Request model for loading schemas."""
    ddl_content: str
    dialect: str = "teradata"


# API Endpoints
@app.get("/")
async def root():
    """API root - health check."""
    return {"status": "ok", "service": "SQL Reverse Engineering API"}


@app.post("/parse")
async def parse_sql(request: ParseRequest) -> Dict[str, Any]:
    """
    Parse SQL and return complete AST in JSON format.

    Args:
        request: ParseRequest with SQL and dialect

    Returns:
        JSON representation of the AST
    """
    try:
        generator = SQLASTGenerator(dialect=request.dialect)
        ast = generator.parse(request.sql)
        return {
            "success": True,
            "ast": generator.to_json(ast),
            "statement_type": generator.get_statement_type(ast),
            "tables": generator.get_tables(ast)
        }
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))


@app.post("/deconstruct")
async def deconstruct_sql(request: ParseRequest) -> Dict[str, Any]:
    """
    Parse and deconstruct SQL into element catalog.

    Returns:
        - case_statements: All CASE statements with branches
        - functions: All function calls
        - joins: All JOINs with conditions
        - ctes: All CTEs
        - subqueries: All subqueries
        - where_clause: WHERE clause details
    """
    try:
        generator = SQLASTGenerator(dialect=request.dialect)
        ast = generator.parse(request.sql)
        extractor = SQLElementExtractor(ast, request.dialect)
        elements = extractor.extract_all()
        return {
            "success": True,
            "elements": elements.to_dict()
        }
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))


@app.post("/lineage")
async def extract_lineage(request: LineageRequest) -> Dict[str, Any]:
    """
    Extract column-level lineage from SQL.

    Returns:
        - nodes: All columns in lineage graph
        - edges: All lineage relationships with transformations
        - statistics: Graph statistics
    """
    try:
        extractor = LineageExtractor(schema=request.schema, dialect=request.dialect)
        graph = extractor.extract_lineage(request.sql)
        return {
            "success": True,
            "lineage": graph.to_dict(),
            "statistics": graph.get_statistics()
        }
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))


@app.post("/document")
async def generate_documentation(request: DocumentRequest) -> Dict[str, Any]:
    """
    Generate complete source-to-target mapping.

    Returns:
        - mapping: CSV-style rows with Source_Table, Source_Attribute, etc.
        - elements: Full element catalog
        - lineage: Lineage graph
    """
    try:
        # Parse and extract
        generator = SQLASTGenerator(dialect=request.dialect)
        ast = generator.parse(request.sql)
        extractor = SQLElementExtractor(ast, request.dialect)
        elements = extractor.extract_all()

        # Extract lineage
        lineage_extractor = LineageExtractor(schema=request.schema, dialect=request.dialect)
        lineage = lineage_extractor.extract_lineage(request.sql)

        # Generate documentation
        doc_generator = SourceTargetMappingGenerator(lineage, elements)

        return {
            "success": True,
            "mapping": doc_generator._build_rows(),
            "elements": elements.to_dict(),
            "lineage": lineage.to_dict()
        }
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))


@app.post("/document/csv")
async def generate_csv(request: DocumentRequest) -> Dict[str, Any]:
    """
    Generate CSV output as string.

    Returns:
        - csv: CSV content as string
    """
    try:
        generator = SQLASTGenerator(dialect=request.dialect)
        ast = generator.parse(request.sql)
        extractor = SQLElementExtractor(ast, request.dialect)
        elements = extractor.extract_all()

        lineage_extractor = LineageExtractor(schema=request.schema, dialect=request.dialect)
        lineage = lineage_extractor.extract_lineage(request.sql)

        doc_generator = SourceTargetMappingGenerator(lineage, elements)

        return {
            "success": True,
            "csv": doc_generator.generate_csv_string()
        }
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))


@app.post("/document/markdown")
async def generate_markdown(request: DocumentRequest) -> Dict[str, Any]:
    """
    Generate Markdown report.

    Returns:
        - markdown: Markdown content as string
    """
    try:
        generator = SQLASTGenerator(dialect=request.dialect)
        ast = generator.parse(request.sql)
        extractor = SQLElementExtractor(ast, request.dialect)
        elements = extractor.extract_all()

        lineage_extractor = LineageExtractor(schema=request.schema, dialect=request.dialect)
        lineage = lineage_extractor.extract_lineage(request.sql)

        doc_generator = SourceTargetMappingGenerator(lineage, elements)

        return {
            "success": True,
            "markdown": doc_generator.generate_markdown_report()
        }
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))


@app.post("/schema/load")
async def load_schema(request: SchemaLoadRequest) -> Dict[str, Any]:
    """
    Load table schemas from DDL content.

    Returns:
        - schema: Dict mapping table names to column lists
        - tables: List of table names
    """
    try:
        loader = DDLSchemaLoader(dialect=request.dialect)
        loader.load_from_string(request.ddl_content)

        return {
            "success": True,
            "schema": loader.get_simple_schema(),
            "tables": loader.get_all_tables(),
            "detailed": loader.to_dict()
        }
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))


@app.post("/case-statements")
async def get_case_statements(request: ParseRequest) -> Dict[str, Any]:
    """
    Extract all CASE statements with branches.

    Returns:
        - case_statements: List of CASE statements with complete branch details
    """
    try:
        generator = SQLASTGenerator(dialect=request.dialect)
        ast = generator.parse(request.sql)
        extractor = SQLElementExtractor(ast, request.dialect)
        elements = extractor.extract_all()

        return {
            "success": True,
            "case_statements": [cs.to_dict() for cs in elements.case_statements]
        }
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))


@app.post("/joins")
async def get_joins(request: ParseRequest) -> Dict[str, Any]:
    """
    Extract all JOINs with conditions.

    Returns:
        - joins: List of JOINs with type and conditions
    """
    try:
        generator = SQLASTGenerator(dialect=request.dialect)
        ast = generator.parse(request.sql)
        extractor = SQLElementExtractor(ast, request.dialect)
        elements = extractor.extract_all()

        return {
            "success": True,
            "joins": [j.to_dict() for j in elements.joins]
        }
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))


@app.post("/ctes")
async def get_ctes(request: ParseRequest) -> Dict[str, Any]:
    """
    Extract all CTEs with definitions.

    Returns:
        - ctes: List of CTEs with columns and dependencies
    """
    try:
        generator = SQLASTGenerator(dialect=request.dialect)
        ast = generator.parse(request.sql)
        extractor = SQLElementExtractor(ast, request.dialect)
        elements = extractor.extract_all()

        return {
            "success": True,
            "ctes": [c.to_dict() for c in elements.ctes]
        }
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))


@app.post("/column-lineage/{column_name}")
async def get_column_lineage(column_name: str, request: LineageRequest) -> Dict[str, Any]:
    """
    Get lineage for a specific output column.

    Args:
        column_name: Target column name
        request: LineageRequest with SQL

    Returns:
        - sources: List of source columns
    """
    try:
        extractor = LineageExtractor(schema=request.schema, dialect=request.dialect)
        sources = extractor.extract_lineage_for_column(request.sql, column_name)

        return {
            "success": True,
            "column": column_name,
            "sources": [s.to_dict() for s in sources]
        }
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))


def run_server(host: str = "0.0.0.0", port: int = 8000):
    """
    Run the API server.

    Args:
        host: Host to bind to
        port: Port to listen on
    """
    import uvicorn
    uvicorn.run(app, host=host, port=port)


if __name__ == "__main__":
    run_server()
