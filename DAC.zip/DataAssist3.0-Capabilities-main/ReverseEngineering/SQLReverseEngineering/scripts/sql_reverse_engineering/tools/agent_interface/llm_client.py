"""
Multi-provider LLM client for AI code review.

Supported providers (controlled by LLM_PROVIDER in .env):
    claude_foundry  — Claude via Azure AI Foundry  (AnthropicFoundry)
    anthropic       — Claude via direct Anthropic API
    openai          — GPT models via OpenAI API
    azure_openai    — GPT models via Azure OpenAI

Usage:
    from agent_interface.llm_client import LLMClientFactory

    # Auto-detect from .env, fall back to interactive prompt
    client = LLMClientFactory.get_or_prompt()
    text = client.complete(system="You are an expert.", messages=[{"role": "user", "content": "Hello"}])
"""

import os
from abc import ABC, abstractmethod
from enum import Enum
from typing import Dict, List, Optional

try:
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:
    pass  # python-dotenv is in requirements.txt, but be safe


# ---------------------------------------------------------------------------
# Provider enum
# ---------------------------------------------------------------------------

class LLMProvider(Enum):
    CLAUDE_FOUNDRY = "claude_foundry"
    ANTHROPIC = "anthropic"
    OPENAI = "openai"
    AZURE_OPENAI = "azure_openai"


# ---------------------------------------------------------------------------
# Abstract base
# ---------------------------------------------------------------------------

class BaseLLMClient(ABC):
    @abstractmethod
    def complete(self, system: str, messages: List[Dict], max_tokens: int = 4096) -> str:
        """Send messages and return the text response."""

    @property
    @abstractmethod
    def provider_name(self) -> str:
        """Human-readable provider label."""


# ---------------------------------------------------------------------------
# Provider implementations
# ---------------------------------------------------------------------------

class AnthropicFoundryClient(BaseLLMClient):
    """Claude via Azure AI Foundry (AnthropicFoundry)."""

    def __init__(self, api_key: str, resource: str, model: str = "claude-sonnet-4-6"):
        try:
            import anthropic
        except ImportError:
            raise ImportError("anthropic package not installed. Run: pip install anthropic")
        self._client = anthropic.AnthropicFoundry(resource=resource, api_key=api_key)
        self._model = model

    def complete(self, system: str, messages: List[Dict], max_tokens: int = 4096) -> str:
        response = self._client.messages.create(
            model=self._model,
            max_tokens=max_tokens,
            system=system,
            messages=messages,
        )
        return response.content[0].text

    @property
    def provider_name(self) -> str:
        return f"Claude via Azure AI Foundry ({self._model})"


class AnthropicClient(BaseLLMClient):
    """Claude via direct Anthropic API."""

    def __init__(self, api_key: str, model: str = "claude-sonnet-4-6"):
        try:
            import anthropic
        except ImportError:
            raise ImportError("anthropic package not installed. Run: pip install anthropic")
        self._client = anthropic.Anthropic(api_key=api_key)
        self._model = model

    def complete(self, system: str, messages: List[Dict], max_tokens: int = 4096) -> str:
        response = self._client.messages.create(
            model=self._model,
            max_tokens=max_tokens,
            system=system,
            messages=messages,
        )
        return response.content[0].text

    @property
    def provider_name(self) -> str:
        return f"Claude via Anthropic ({self._model})"


class OpenAIClient(BaseLLMClient):
    """GPT models via OpenAI API."""

    def __init__(self, api_key: str, model: str = "gpt-4o"):
        try:
            from openai import OpenAI
            self._client = OpenAI(api_key=api_key)
        except ImportError:
            raise ImportError("openai package not installed. Run: pip install openai")
        self._model = model

    def complete(self, system: str, messages: List[Dict], max_tokens: int = 4096) -> str:
        full_messages = [{"role": "system", "content": system}] + messages
        response = self._client.chat.completions.create(
            model=self._model,
            messages=full_messages,
            max_tokens=max_tokens,
        )
        return response.choices[0].message.content

    @property
    def provider_name(self) -> str:
        return f"OpenAI ({self._model})"


class AzureOpenAIClient(BaseLLMClient):
    """GPT models via Azure OpenAI."""

    def __init__(self, api_key: str, endpoint: str, deployment: str,
                 api_version: str = "2024-02-01"):
        try:
            from openai import AzureOpenAI
            self._client = AzureOpenAI(
                api_key=api_key,
                azure_endpoint=endpoint,
                api_version=api_version,
            )
        except ImportError:
            raise ImportError("openai package not installed. Run: pip install openai")
        self._deployment = deployment

    def complete(self, system: str, messages: List[Dict], max_tokens: int = 4096) -> str:
        full_messages = [{"role": "system", "content": system}] + messages
        response = self._client.chat.completions.create(
            model=self._deployment,
            messages=full_messages,
            max_tokens=max_tokens,
        )
        return response.choices[0].message.content

    @property
    def provider_name(self) -> str:
        return f"Azure OpenAI ({self._deployment})"


# ---------------------------------------------------------------------------
# Factory
# ---------------------------------------------------------------------------

class LLMClientFactory:
    """
    Creates LLM clients from environment variables or an interactive CLI prompt.

    Priority:
        1. LLM_PROVIDER env var + matching credential vars (loaded from .env)
        2. Interactive prompt (if .env missing or LLM_PROVIDER not set)
    """

    _PROVIDER_KEYS = {
        "claude_foundry": LLMProvider.CLAUDE_FOUNDRY,
        "anthropic": LLMProvider.ANTHROPIC,
        "openai": LLMProvider.OPENAI,
        "azure_openai": LLMProvider.AZURE_OPENAI,
    }

    @classmethod
    def from_env(cls) -> Optional[BaseLLMClient]:
        """Build client from environment. Returns None if not configured."""
        provider_str = os.getenv("LLM_PROVIDER", "").strip().lower()
        provider = cls._PROVIDER_KEYS.get(provider_str)
        if not provider:
            return None
        try:
            return cls._build(provider)
        except (ValueError, ImportError):
            return None

    @classmethod
    def from_cli_prompt(cls) -> BaseLLMClient:
        """Interactively collect provider choice and credentials from the terminal."""
        print()
        print("=" * 62)
        print("  AI Code Review — LLM Setup")
        print("=" * 62)
        print("  No .env found or LLM_PROVIDER not configured.")
        print()
        print("  Available providers:")
        print("    1. claude_foundry  — Claude via Azure AI Foundry")
        print("    2. anthropic       — Claude via Anthropic API")
        print("    3. openai          — GPT via OpenAI API")
        print("    4. azure_openai    — GPT via Azure OpenAI")
        print()

        choices = {
            "1": LLMProvider.CLAUDE_FOUNDRY,
            "2": LLMProvider.ANTHROPIC,
            "3": LLMProvider.OPENAI,
            "4": LLMProvider.AZURE_OPENAI,
        }
        while True:
            raw = input("  Select provider [1-4]: ").strip()
            if raw in choices:
                provider = choices[raw]
                break
            print("  Invalid — enter 1, 2, 3, or 4.")

        print()
        if provider == LLMProvider.CLAUDE_FOUNDRY:
            api_key = cls._ask("Azure Foundry API Key")
            resource = cls._ask("Azure Foundry Resource (e.g. az-msf-mt-npd-001)")
            model = cls._ask("Model", default="claude-sonnet-4-6")
            return AnthropicFoundryClient(api_key=api_key, resource=resource, model=model)

        if provider == LLMProvider.ANTHROPIC:
            api_key = cls._ask("Anthropic API Key (sk-ant-...)")
            model = cls._ask("Model", default="claude-sonnet-4-6")
            return AnthropicClient(api_key=api_key, model=model)

        if provider == LLMProvider.OPENAI:
            api_key = cls._ask("OpenAI API Key (sk-...)")
            model = cls._ask("Model", default="gpt-4o")
            return OpenAIClient(api_key=api_key, model=model)

        # azure_openai
        api_key = cls._ask("Azure OpenAI API Key")
        endpoint = cls._ask("Azure OpenAI Endpoint (https://...openai.azure.com/)")
        deployment = cls._ask("Deployment name")
        api_version = cls._ask("API Version", default="2024-02-01")
        return AzureOpenAIClient(api_key=api_key, endpoint=endpoint,
                                 deployment=deployment, api_version=api_version)

    @classmethod
    def get_or_prompt(cls) -> BaseLLMClient:
        """Get client from env; fall back to interactive prompt if unconfigured."""
        client = cls.from_env()
        if client is not None:
            return client
        return cls.from_cli_prompt()

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    @classmethod
    def _build(cls, provider: LLMProvider) -> BaseLLMClient:
        if provider == LLMProvider.CLAUDE_FOUNDRY:
            return AnthropicFoundryClient(
                api_key=cls._env("ANTHROPIC_API_KEY"),
                resource=cls._env("AZURE_FOUNDRY_RESOURCE"),
                model=os.getenv("LLM_MODEL", "claude-sonnet-4-6"),
            )
        if provider == LLMProvider.ANTHROPIC:
            return AnthropicClient(
                api_key=cls._env("ANTHROPIC_API_KEY"),
                model=os.getenv("LLM_MODEL", "claude-sonnet-4-6"),
            )
        if provider == LLMProvider.OPENAI:
            return OpenAIClient(
                api_key=cls._env("OPENAI_API_KEY"),
                model=os.getenv("LLM_MODEL", "gpt-4o"),
            )
        if provider == LLMProvider.AZURE_OPENAI:
            return AzureOpenAIClient(
                api_key=cls._env("AZURE_OPENAI_API_KEY"),
                endpoint=cls._env("AZURE_OPENAI_ENDPOINT"),
                deployment=cls._env("AZURE_OPENAI_DEPLOYMENT"),
                api_version=os.getenv("AZURE_OPENAI_API_VERSION", "2024-02-01"),
            )
        raise ValueError(f"Unsupported provider: {provider}")

    @staticmethod
    def _env(name: str) -> str:
        val = os.getenv(name, "").strip()
        if not val:
            raise ValueError(f"Environment variable '{name}' is not set")
        return val

    @staticmethod
    def _ask(label: str, default: str = "") -> str:
        suffix = f" [{default}]" if default else ""
        val = input(f"  {label}{suffix}: ").strip()
        return val if val else default
