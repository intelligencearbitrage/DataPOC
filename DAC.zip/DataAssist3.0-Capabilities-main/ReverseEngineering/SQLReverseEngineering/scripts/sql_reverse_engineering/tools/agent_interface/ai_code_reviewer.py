"""
AI-powered code reviewer.

Reads a SQL file block-by-block, loads the corresponding STTM structured xlsx,
asks an LLM to evaluate accuracy per block, then offers an interactive refinement
loop where the user can have the LLM correct the STTM and write back a new xlsx.

Standalone usage:
    python ai_code_reviewer.py \\
        --sql  inputs/Complex/FRY_14/Schema/sp_example.sql \\
        --sttm output/SP_batch/sp_example_structured.xlsx \\
        --dialect teradata

Programmatic usage:
    from agent_interface.ai_code_reviewer import AICodeReviewer
    from agent_interface.llm_client import LLMClientFactory

    client = LLMClientFactory.get_or_prompt()
    reviewer = AICodeReviewer(client, dialect="teradata")
    reviewer.run(sql_path="input.sql", sttm_path="output.xlsx")
"""

import argparse
import copy
import json
import re
import sys
import os
from dataclasses import dataclass, field
from pathlib import Path
from werkzeug.utils import safe_join, secure_filename
from typing import Any, Dict, List, Optional, Tuple

# ---------------------------------------------------------------------------
# Path bootstrap (allows running as a script or via the CLI entry point)
# ---------------------------------------------------------------------------
_HERE = Path(__file__).resolve().parent
_TOOLS = _HERE.parent
_PKG = _TOOLS.parent
_SCRIPTS = _PKG.parent
for _p in [str(_SCRIPTS), str(_PKG)]:
    if _p not in sys.path:
        sys.path.insert(0, _p)

try:
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:
    pass

try:
    import openpyxl
    from openpyxl import load_workbook
    from openpyxl.styles import Font, PatternFill, Alignment
    from openpyxl.utils import get_column_letter
    _HAS_OPENPYXL = True
except ImportError:
    _HAS_OPENPYXL = False

from agent_interface.llm_client import BaseLLMClient, LLMClientFactory


# ---------------------------------------------------------------------------
# Data models
# ---------------------------------------------------------------------------

@dataclass
class SQLBlock:
    index: int          # 1-based
    dml_type: str       # INSERT, SELECT, UPDATE, DELETE, MERGE, SELECT INTO
    target_table: str
    raw_sql: str
    line_start: int = 0
    line_end: int = 0


@dataclass
class STTMRows:
    """STTM data for one sequence number."""
    sequence: str
    lineage_rows: List[Dict[str, Any]] = field(default_factory=list)
    join_rows: List[Dict[str, Any]] = field(default_factory=list)
    filter_rows: List[Dict[str, Any]] = field(default_factory=list)


@dataclass
class BlockAnalysis:
    block: SQLBlock
    sttm: Optional[STTMRows]
    accuracy_score: float           # 0-100
    dimensions: Dict[str, Any] = field(default_factory=dict)
    issues: List[str] = field(default_factory=list)
    corrections_needed: List[Dict] = field(default_factory=list)
    llm_summary: str = ""
    raw_response: str = ""


@dataclass
class RefinementResult:
    patches: List[Dict[str, Any]] = field(default_factory=list)  # field-level patches
    new_rows: List[Dict[str, Any]] = field(default_factory=list)
    change_summary: str = ""


# ---------------------------------------------------------------------------
# Prompts
# ---------------------------------------------------------------------------

_SYSTEM_PROMPT = """\
You are an accuracy validation agent for Teradata SQL reverse engineering output.
Your job is to compare the structured STTM XLSX output against the original source
SQL file, block by block, and produce a detailed accuracy report.

You validate across 12 dimensions per DML block:
1. DML Coverage              — every DML statement in SQL has a matching STTM sequence
2. Column Mappings           — INSERT/SELECT columns present in STTM Column Lineage
3. Source Tables             — FROM/JOIN tables captured in STTM source tables
4. Join Capture              — JOIN clauses captured in Join Conditions sheet
5. Filter Capture            — WHERE/QUALIFY captured in Filter Conditions sheet
6. Join ID Assignment        — column mappings have join IDs tagged
7. Filter ID Assignment      — column mappings have filter IDs tagged
8. Transformation SQL        — transformation expressions match source SQL
9. Sequence Ordering         — STTM sequences match SQL source-file order, correct operator types
10. Structural Completeness  — UNION branches, MERGE branches, row count sanity
11. Alias & Lineage Accuracy — source tables resolved to physical names, no unresolved aliases
12. Cross-Sheet Integrity    — Join/Filter IDs reference valid entries, sequence consistency

You must cite specific SQL text for every finding.
Always respond with valid JSON only — no markdown fences, no prose outside the JSON object.
"""

# ---------------------------------------------------------------------------
# Agent-team dimension groups
#
# Each group is scored by a separate LLM call with a small, focused prompt.
# This avoids the output-token limit that truncates monolithic 12-dim responses.
# The final accuracy_score is computed in Python from the merged group results.
# ---------------------------------------------------------------------------

# Lineage rows per column_mappings page call
_COL_PAGE_SIZE = 60

# Dimension name → weight (must sum to 100)
_WEIGHTS: Dict[str, int] = {
    "dml_coverage":            5,
    "column_mappings":        20,
    "source_tables":          12,
    "join_capture":           12,
    "filter_capture":         12,
    "join_id_assignment":      8,
    "filter_id_assignment":    8,
    "transformation_sql":      8,
    "sequence_ordering":       5,
    "structural_completeness": 5,
    "alias_lineage_accuracy":  3,
    "cross_sheet_integrity":   2,
}

# ---------------------------------------------------------------------------
# Dimension groups — LLM only (6 structural dims computed in Python instead)
#
# Python-computed (instant, no LLM):
#   dml_coverage, join_id_assignment, filter_id_assignment,
#   sequence_ordering, structural_completeness, cross_sheet_integrity
#
# Paginated LLM (one call per 60 lineage rows):
#   column_mappings
#
# LLM groups (2 small focused calls):
#   source_joins_filters  → source_tables, join_capture, filter_capture
#   transforms_aliases    → transformation_sql, alias_lineage_accuracy
# ---------------------------------------------------------------------------

_DIMENSION_GROUPS = [
    {
        "name": "source_joins_filters",
        "dimensions": [
            (
                "source_tables", 12,
                "Count physical source tables in FROM/JOIN clauses (ignore aliases "
                "and volatile/temp tables defined upstream in the procedure). "
                "matched / sql_source_tables * 100.",
            ),
            (
                "join_capture", 12,
                "documented_joins / sql_explicit_joins * 100. "
                "No explicit JOINs in SQL → 100.",
            ),
            (
                "filter_capture", 12,
                "documented_filters / sql_WHERE_QUALIFY_clauses * 100. "
                "No WHERE / QUALIFY / HAVING → 100.",
            ),
        ],
    },
    {
        "name": "transforms_and_aliases",
        "dimensions": [
            (
                "transformation_sql", 8,
                "For STTM rows that have a Transformation SQL value, verify it matches "
                "the SQL expression for that target column. "
                "Semantically equivalent expressions (different alias, case, minor "
                "rewrite) → 90-100. Only deduct for genuinely wrong expressions.",
            ),
            (
                "alias_lineage_accuracy", 3,
                "Source table aliases in STTM resolve to real physical table names. "
                "Volatile table names match their upstream CREATE definitions. "
                "All resolved → 100.",
            ),
        ],
    },
]

_GROUP_PROMPT_TMPL = """\
Score ONLY the {group_name} dimensions for the STTM block below.
Apply all rules and false-positive checks internally.
Output ONLY the JSON object — no prose, no explanation, no markdown fences.

## SQL Block #{idx} ({dml_type} → {target_table})
```sql
{sql}
```

## STTM Column Lineage rows (sequence {seq})
{lineage_table}

## STTM Join Conditions rows
{join_table}

## STTM Filter Conditions rows
{filter_table}

---
FALSE-POSITIVE CHECKS (verify before deducting on any dimension):
  • A "missing" column is present under a different alias in the STTM → not missing
  • A "missing" table is a volatile temp table defined upstream → not missing
  • A "missing" join is inside a subquery, not the main SELECT → not missing
  • Block is DDL (DROP TABLE, COLLECT STATS), not DML → all dimensions score 100

DIMENSIONS TO SCORE (name | weight% | rule):
{dimension_rules}

Rules:
  • Only deduct for GENUINE errors (wrong value, clearly incorrect entry).
  • A dimension with nothing to check → 100, not 0.
  • Limit issues to 2 per dimension, under 80 characters each.
  • corrections_needed: at most 4 items, most impactful only.

Output ONLY this JSON:
{{
  "dimensions": {{
{dimension_schema}
  }},
  "corrections_needed": [
    {{"type": "update"|"add"|"delete", "sheet": "Column Lineage"|"Join Conditions"|"Filter Conditions",
      "match_on": {{}}, "updates": {{}}, "reason": "<string>"}}
  ]
}}
"""

_COLUMN_PAGE_PROMPT_TMPL = """\
Score column mapping correctness for STTM rows {row_start}–{row_end} of {total_rows} \
(page {page_num}/{total_pages}, block {seq}).
Apply rules internally. Output ONLY the JSON — no prose, no fences.

## SQL Block #{idx} ({dml_type} → {target_table})
```sql
{sql}
```

## STTM Column Lineage — this page ({rows_on_page} rows)
{lineage_table}

---
For each row on this page, verify:
  • Source Table is present in SQL FROM/JOIN (check aliases too)
  • Source Column is referenced in SQL for that target column
  • Target Column exists in the SQL INSERT list or SELECT output

Score: correctly_mapped_rows / rows_on_this_page * 100.

False-positive checks before deducting:
  • Source Table under an alias → find the alias in SQL, treat as correct
  • Volatile / temp table defined upstream → treat as valid source
  • Pass-through column (same name, no transform) → alias resolution applies

Only deduct for rows that are GENUINELY wrong (wrong table, wrong column, non-existent).
At most 2 issue strings (under 80 chars each).

Output ONLY:
{{"score": <int 0-100>, "issues": [<string>, ...]}}
"""

_REFINEMENT_PROMPT_TMPL = """\
The STTM documentation for SQL block #{idx} ({dml_type} → {target_table}) has accuracy issues.
Apply the corrections below and return an updated STTM patch set.

## Issues & corrections needed
{corrections_json}

## Current STTM Column Lineage rows (sequence {seq})
{lineage_table}

## Current STTM Join Conditions rows
{join_table}

## Current STTM Filter Conditions rows
{filter_table}

## Human feedback (if any)
{user_feedback}

Validate each feedback item before applying:
1. Is it relevant to the accuracy findings?
2. Does it reference specific blocks or dimensions?
3. Is it actionable (accept/dismiss specific findings)?
Apply accepted feedback: dismiss false positives, adjust affected rows, re-calculate impact.

Return a single JSON object:
{{
  "patches": [
    {{
      "sheet": "Column Lineage"|"Join Conditions"|"Filter Conditions",
      "action": "update"|"add"|"delete",
      "match_on": {{"<col>": "<val>", ...}},
      "updates":  {{"<col>": "<new_val>", ...}}
    }}
  ],
  "change_summary": "<brief description of all changes made>"
}}

Rules:
- For "update": match_on identifies the existing row, updates contains only the fields to change.
- For "add": updates contains all fields for the new row (Sequence must match {seq}).
- For "delete": match_on identifies the row to remove; updates is empty.
- Preserve all fields not mentioned in updates exactly as they are.
- Only fix what the issues actually require — do not change unrelated fields.
"""


# ---------------------------------------------------------------------------
# Core reviewer class
# ---------------------------------------------------------------------------

class AICodeReviewer:
    """
    Block-by-block LLM reviewer with interactive refinement loop.
    """

    LINEAGE_HEADERS = [
        'Sequence', 'Operator Type',
        'Source Table', 'Source Alias', 'Source Column',
        'Target Table', 'Target Alias', 'Target Column',
        'Transformation Type', 'Transformation Subtype',
        'Transformation SQL', 'English Explanation',
        'All Source Columns Involved',
        'Join IDs', 'Filter IDs',
        'Group By', 'Subquery Alias', 'Union Type', 'Subquery SQL',
        'Hops', 'Hop Detail',
        'Source Subquery Relation', 'Target Subquery Relation',
        'Notes', 'Control Flow Context',
    ]

    JOIN_HEADERS = [
        'Join ID', 'Join Type',
        'Left Table', 'Left Alias',
        'Right Table', 'Right Alias',
        'Join SQL', 'Applies To Sequence',
    ]

    FILTER_HEADERS = [
        'Filter ID', 'Filter Type',
        'SQL Expression', 'Columns Referenced', 'Applies To Sequence',
    ]

    # DML keywords that start a new block
    _DML_RE = re.compile(
        r'^\s*(INSERT\s+INTO|INSERT\s+OVERWRITE|SEL\s+|SELECT\s+INTO\s+|'
        r'SELECT\s+|UPDATE\s+|DELETE\s+FROM|DELETE\s+|MERGE\s+INTO|MERGE\s+)',
        re.IGNORECASE | re.MULTILINE,
    )

    def __init__(self, llm: BaseLLMClient, dialect: str = "teradata"):
        self.llm = llm
        self.dialect = dialect

    # ------------------------------------------------------------------
    # Public entry point
    # ------------------------------------------------------------------

    def run(self, sql_path: str, sttm_path: str,
            output_dir: Optional[str] = None,
            interactive: bool = True) -> List[BlockAnalysis]:
        """
        Full review + optional interactive refinement.

        Args:
            sql_path:    Path to source SQL file.
            sttm_path:   Path to generated structured xlsx.
            output_dir:  Where to write refined xlsx (defaults to sttm dir).
            interactive: When True (default), prompt for refinement after analysis.
                         Set False for batch/non-interactive use — analysis only.

        Returns list of BlockAnalysis (one per SQL block).
        """
        _sql_abs = Path(sql_path).resolve()
        _sttm_abs = Path(sttm_path).resolve()
        sql_path = safe_join(str(_sql_abs.parent), secure_filename(_sql_abs.name))
        sttm_path = safe_join(str(_sttm_abs.parent), secure_filename(_sttm_abs.name))
        output_dir = output_dir or str(Path(sttm_path).parent)

        print(f"\n{'='*62}")
        print(f"  AI Code Review")
        print(f"  LLM: {self.llm.provider_name}")
        print(f"  SQL:  {Path(sql_path).name}")
        print(f"  STTM: {Path(sttm_path).name}")
        print(f"{'='*62}\n")

        # Load inputs
        sql = Path(sql_path).read_text(encoding="utf-8", errors="ignore")
        blocks = self._split_sql(sql)
        sttm_data = self._load_sttm(sttm_path)

        if not blocks:
            print("  WARNING: No DML blocks found in SQL file.")
            return []

        # Filter out procedural variable assignments (SELECT INTO :var, SET var = ...)
        table_blocks = [b for b in blocks if not self._is_variable_assignment(b)]
        skipped = len(blocks) - len(table_blocks)

        print(f"  Found {len(blocks)} SQL block(s) "
              f"({skipped} skipped — procedural variable assignments)  |  "
              f"{sum(len(v.lineage_rows) for v in sttm_data.values())} STTM lineage row(s)\n")

        if not table_blocks:
            print("  WARNING: No table-level DML blocks found after filtering.")
            return []

        # Match blocks to STTM sequences by target table name, not fragile sequential index
        block_to_seq = self._match_blocks_to_sttm(table_blocks, sttm_data)

        # Analyse each block — skip blocks with no STTM sequence match
        # (variable assignments, error-handler selects, etc.)
        analyses: List[BlockAnalysis] = []
        for block in table_blocks:
            seq_key = block_to_seq.get(block.index)
            if seq_key is None:
                print(f"  [Block {block.index}/{len(table_blocks)}] {block.dml_type} → "
                      f"{block.target_table or '?'}  (skipped — no STTM sequence match)")
                continue
            sttm_rows = sttm_data.get(seq_key)
            print(f"  [Block {block.index}/{len(table_blocks)}] {block.dml_type} → "
                  f"{block.target_table or '?'}  (seq={seq_key})")
            analysis = self._analyse_block(block, sttm_rows)
            analyses.append(analysis)
            self._print_block_summary(analysis)

        self._print_overall_summary(analyses)

        # Offer interactive refinement (skipped in non-interactive / batch mode)
        has_issues = any(a.accuracy_score < 100 or a.issues for a in analyses)
        if has_issues and interactive:
            self._refinement_loop(analyses, sttm_path, sttm_data, output_dir, sql_path)
        elif has_issues and not interactive:
            print("  Issues found. Re-run with --review on 'full' command for interactive refinement.")

        return analyses

    # ------------------------------------------------------------------
    # SQL splitting
    # ------------------------------------------------------------------

    def _split_sql(self, sql: str) -> List[SQLBlock]:
        """Split a stored-procedure body into individual DML blocks."""
        # Try sqlglot first for clean AST-based splitting
        try:
            import sqlglot
            statements = sqlglot.parse(sql, dialect=self.dialect, error_level=sqlglot.ErrorLevel.IGNORE)
            blocks = []
            for i, stmt in enumerate(statements, 1):
                if stmt is None:
                    continue
                stmt_sql = stmt.sql(dialect=self.dialect)
                dml_type, target = self._classify_stmt(stmt_sql)
                if dml_type:
                    blocks.append(SQLBlock(
                        index=len(blocks) + 1,
                        dml_type=dml_type,
                        target_table=target,
                        raw_sql=stmt_sql,
                    ))
            if blocks:
                return blocks
        except Exception:
            pass

        # Fallback: regex split on DML keywords
        return self._regex_split_sql(sql)

    def _regex_split_sql(self, sql: str) -> List[SQLBlock]:
        lines = sql.splitlines()
        blocks: List[SQLBlock] = []
        current_lines: List[str] = []
        current_start = 0

        def flush(start: int, end: int):
            raw = "\n".join(current_lines).strip()
            if raw:
                dml_type, target = self._classify_stmt(raw)
                if dml_type:
                    blocks.append(SQLBlock(
                        index=len(blocks) + 1,
                        dml_type=dml_type,
                        target_table=target,
                        raw_sql=raw,
                        line_start=start,
                        line_end=end,
                    ))

        for i, line in enumerate(lines):
            if self._DML_RE.match(line) and current_lines:
                flush(current_start, i - 1)
                current_lines = [line]
                current_start = i
            else:
                current_lines.append(line)

        flush(current_start, len(lines) - 1)
        return blocks

    def _classify_stmt(self, sql: str) -> Tuple[str, str]:
        """Return (dml_type, target_table) for a SQL string."""
        s = sql.strip().upper()
        target = ""

        if s.startswith("INSERT INTO") or s.startswith("INSERT OVERWRITE"):
            dml_type = "INSERT"
            m = re.search(r'INSERT\s+(?:INTO|OVERWRITE)\s+(\S+)', sql, re.IGNORECASE)
            target = m.group(1).strip(';') if m else ""
        elif "SELECT" in s and "INTO" in s:
            dml_type = "SELECT INTO"
            m = re.search(r'INTO\s+(\S+)', sql, re.IGNORECASE)
            target = m.group(1).strip(';') if m else ""
        elif s.startswith("UPDATE"):
            dml_type = "UPDATE"
            m = re.search(r'UPDATE\s+(\S+)', sql, re.IGNORECASE)
            target = m.group(1).strip(';') if m else ""
        elif s.startswith("DELETE"):
            dml_type = "DELETE"
            m = re.search(r'DELETE\s+FROM\s+(\S+)', sql, re.IGNORECASE)
            if not m:
                m = re.search(r'DELETE\s+(\S+)', sql, re.IGNORECASE)
            target = m.group(1).strip(';') if m else ""
        elif s.startswith("MERGE"):
            dml_type = "MERGE"
            m = re.search(r'MERGE\s+INTO\s+(\S+)', sql, re.IGNORECASE)
            if not m:
                m = re.search(r'MERGE\s+(\S+)', sql, re.IGNORECASE)
            target = m.group(1).strip(';') if m else ""
        elif s.startswith("SELECT") or s.startswith("SEL "):
            dml_type = "SELECT"
            target = ""
        else:
            return "", ""

        # Strip database qualifier for display
        if "." in target:
            target = target.split(".")[-1]

        return dml_type, target

    # ------------------------------------------------------------------
    # Block filtering and STTM matching
    # ------------------------------------------------------------------

    @staticmethod
    def _is_variable_assignment(block: "SQLBlock") -> bool:
        """Return True if the block is a procedural variable assignment, not real DML.

        Teradata SPL uses  SELECT expr INTO :var_name  and  SET var = expr
        to assign values to local variables. These produce no lineage and
        have no corresponding STTM sequence.

        Heuristics:
        - SELECT INTO whose target looks like a variable name (no schema dot,
          all-caps single token starting with V_ / MSG / W / P_ typical SPL vars)
        - Target contains no dot separator (real tables are usually schema.table)
        - Very short target name (< 20 chars, no underscore between words typical
          of real table names)
        """
        if block.dml_type != "SELECT INTO":
            return False
        t = block.target_table.upper()
        if not t:
            return False
        # Real tables almost always have a schema qualifier in Teradata SPs;
        # variable names never do (the dot was already stripped in _classify_stmt,
        # but the raw SQL still shows it).  Check raw SQL for schema.table pattern.
        raw_upper = block.raw_sql.upper()
        # Look for  INTO <schema>.<table>  — two-part name = real table
        if re.search(r'\bINTO\s+\w+\.\w+', raw_upper):
            return False
        # Common SPL variable prefixes / patterns
        if re.match(r'^(V_|MSG|W_|P_|I_|L_|ERR|RC|COUNT|FLAG|STR|NUM|DT)', t):
            return True
        # Single short token with no digits → likely a variable
        if re.match(r'^[A-Z_]{1,30}$', t) and '_' not in t[1:]:
            return True
        return False

    def _match_blocks_to_sttm(self, blocks: List["SQLBlock"],
                               sttm_data: Dict[str, "STTMRows"]) -> Dict[int, str]:
        """Match each SQL block to its best STTM sequence key.

        Matching priority:
          1. Target table name match (case-insensitive, schema-stripped)
          2. DML type match as tiebreaker when multiple sequences share a table
          3. Sequential index fallback if name matching fails

        Returns dict mapping block.index → sttm sequence key string.
        """
        # Build (seq_key, target_table_short, operator_type) for every sequence
        seq_info: List[Tuple[str, str, str]] = []
        for seq_key, sttm in sttm_data.items():
            # Derive target table from lineage rows
            target = ""
            op = ""
            for row in sttm.lineage_rows:
                t = row.get("Target Table", "").strip().upper()
                if t:
                    target = t.split(".")[-1]  # strip schema
                    op = row.get("Operator Type", "").strip().upper()
                    break
            seq_info.append((seq_key, target, op))

        assigned: Dict[int, str] = {}
        used_seqs: set = set()

        for block in blocks:
            block_target = block.target_table.upper()
            block_dml = block.dml_type.upper()

            # Score each candidate sequence
            best_key: Optional[str] = None
            best_score = -1

            for seq_key, seq_target, seq_op in seq_info:
                if seq_key in used_seqs:
                    continue
                score = 0
                if block_target and seq_target and block_target == seq_target:
                    score += 100
                # DML / operator type bonus
                if block_dml in seq_op or seq_op in block_dml:
                    score += 10
                # Prefer sequence numbers numerically close to block index
                try:
                    distance = abs(int(seq_key) - block.index)
                    score += max(0, 5 - distance)
                except ValueError:
                    pass

                if score > best_score:
                    best_score = score
                    best_key = seq_key

            if best_key is not None and best_score >= 100:
                # Confirmed name-based match
                assigned[block.index] = best_key
                used_seqs.add(best_key)
            # else: no target-table match → block has no STTM sequence.
            # Do NOT fall back to sequential index — a wrong match is worse
            # than no match (wrong STTM rows make the LLM score 0).

        return assigned

    # ------------------------------------------------------------------
    # STTM xlsx loading
    # ------------------------------------------------------------------

    @staticmethod
    def _norm_seq(val) -> str:
        """Normalise a sequence value to a plain integer string.

        openpyxl returns numeric cells as floats (e.g. 1.0, 2.0).
        str(1.0) == "1.0" which never matches str(block.index) == "1".
        This strips the trailing ".0" so all lookups use "1", "2", etc.
        """
        if val is None:
            return ""
        s = str(val).strip()
        # "1.0" -> "1", "2.0" -> "2"; leave "1a" or "N/A" untouched
        if s.endswith(".0"):
            try:
                return str(int(float(s)))
            except ValueError:
                pass
        return s

    def _load_sttm(self, sttm_path: str) -> Dict[str, STTMRows]:
        """Load structured xlsx and group rows by sequence number."""
        if not _HAS_OPENPYXL:
            raise RuntimeError("openpyxl not installed. Run: pip install openpyxl")

        wb = load_workbook(sttm_path, data_only=True)
        result: Dict[str, STTMRows] = {}

        def sheet_to_dicts(sheet_name: str) -> List[Dict]:
            if sheet_name not in wb.sheetnames:
                return []
            ws = wb[sheet_name]
            rows = list(ws.iter_rows(values_only=True))
            if not rows:
                return []
            headers = [str(h).strip() if h is not None else "" for h in rows[0]]
            return [
                {headers[j]: self._norm_seq(cell) if headers[j] in ("Sequence", "Applies To Sequence")
                              else (str(cell) if cell is not None else "")
                 for j, cell in enumerate(row) if j < len(headers)}
                for row in rows[1:]
                if any(cell is not None for cell in row)
            ]

        lineage_rows = sheet_to_dicts("Column Lineage")
        join_rows = sheet_to_dicts("Join Conditions")
        filter_rows = sheet_to_dicts("Filter Conditions")

        # Group by Sequence
        for row in lineage_rows:
            seq = self._norm_seq(row.get("Sequence", ""))
            if seq not in result:
                result[seq] = STTMRows(sequence=seq)
            result[seq].lineage_rows.append(row)

        for row in join_rows:
            seq = self._norm_seq(row.get("Applies To Sequence", ""))
            for s in seq.split(","):
                s = s.strip()
                if s in result:
                    result[s].join_rows.append(row)

        for row in filter_rows:
            seq = self._norm_seq(row.get("Applies To Sequence", ""))
            for s in seq.split(","):
                s = s.strip()
                if s in result:
                    result[s].filter_rows.append(row)

        return result

    # ------------------------------------------------------------------
    # LLM analysis
    # ------------------------------------------------------------------

    def _analyse_block(self, block: SQLBlock,
                       sttm: Optional[STTMRows]) -> BlockAnalysis:
        """Analyse one SQL block using a layered agent-team approach.

        Layer 1 — Python (instant, no LLM):
            dml_coverage, join_id_assignment, filter_id_assignment,
            sequence_ordering, structural_completeness, cross_sheet_integrity

        Layer 2 — Paginated LLM (60 lineage rows per call):
            column_mappings — handles 800-row STTMs without hitting token limits

        Layer 3 — Two small focused LLM calls:
            source_tables / join_capture / filter_capture
            transformation_sql / alias_lineage_accuracy
        """
        if sttm is None:
            sttm = STTMRows(sequence=str(block.index))
        seq = sttm.sequence or str(block.index)

        sql_snippet  = block.raw_sql[:40000]
        join_table   = self._rows_to_text(
            sttm.join_rows,
            ["Join ID", "Join Type", "Left Table", "Right Table", "Join SQL"])
        filter_table = self._rows_to_text(
            sttm.filter_rows,
            ["Filter ID", "Filter Type", "SQL Expression"])

        all_dimensions: Dict[str, Any] = {}
        all_corrections: List[Dict]    = []

        # --- Layer 1: Python-computed structural dimensions ---
        all_dimensions.update(
            self._compute_instant_dimensions(block, sttm, seq))

        # --- Layer 2: Paginated column_mappings ---
        n_rows   = len(sttm.lineage_rows)
        n_pages  = max(1, -(-n_rows // _COL_PAGE_SIZE))   # ceiling division
        print(f"      column_mappings: {n_rows} rows → {n_pages} page(s)")
        col_score, col_issues, col_corrections = \
            self._analyse_column_mappings_paged(block, seq, sql_snippet,
                                                sttm.lineage_rows)
        all_dimensions["column_mappings"] = {"score": col_score,
                                              "issues": col_issues}
        all_corrections.extend(col_corrections)

        # --- Layer 3: LLM groups (small focused prompts) ---
        # For transforms group, show only rows that have non-trivial transforms
        transform_rows = [r for r in sttm.lineage_rows
                          if r.get("Transformation SQL", "").strip()]
        transform_lineage = self._rows_to_text(
            transform_rows[:40],
            ["Sequence", "Source Table", "Source Column",
             "Target Table", "Target Column", "Transformation SQL"])

        # source_joins_filters: doesn't need full lineage, just a small summary
        src_lineage = self._rows_to_text(
            sttm.lineage_rows[:30],
            ["Sequence", "Source Table", "Source Alias",
             "Target Table", "Operator Type"])

        for group in _DIMENSION_GROUPS:
            ctx_lineage = (transform_lineage
                           if group["name"] == "transforms_and_aliases"
                           else src_lineage)
            g_dims, g_corrections = self._analyse_group(
                block, seq, sql_snippet,
                ctx_lineage, join_table, filter_table,
                group,
            )
            all_dimensions.update(g_dims)
            all_corrections.extend(g_corrections)

        accuracy_score = self._compute_accuracy(all_dimensions)
        all_issues = [
            iss
            for dim in all_dimensions.values()
            for iss in dim.get("issues", [])
        ]
        return BlockAnalysis(
            block=block, sttm=sttm,
            accuracy_score=accuracy_score,
            dimensions=all_dimensions,
            issues=all_issues,
            corrections_needed=all_corrections,
            llm_summary="",
        )

    @staticmethod
    def _compute_instant_dimensions(block: "SQLBlock",
                                    sttm: "STTMRows",
                                    seq: str) -> Dict[str, Any]:
        """Score 6 structural dimensions in pure Python — no LLM call needed."""
        rows    = sttm.lineage_rows
        n_rows  = len(rows)
        dims: Dict[str, Any] = {}

        # dml_coverage
        dims["dml_coverage"] = {
            "score": 100 if rows else 0,
            "issues": [] if rows else ["No STTM lineage rows for this sequence"],
        }

        # join_id_assignment — score 100 if IDs style is not used at all
        join_ids = [r.get("Join IDs", "").strip() for r in rows]
        any_join_id = any(join_ids)
        if not any_join_id:
            dims["join_id_assignment"] = {"score": 100, "issues": []}
        else:
            filled = sum(1 for j in join_ids if j)
            score  = int(filled / n_rows * 100) if n_rows else 100
            dims["join_id_assignment"] = {
                "score": score,
                "issues": ([f"{n_rows - filled} rows missing Join ID"] if score < 100
                           else []),
            }

        # filter_id_assignment
        filter_ids = [r.get("Filter IDs", "").strip() for r in rows]
        any_filter_id = any(filter_ids)
        if not any_filter_id:
            dims["filter_id_assignment"] = {"score": 100, "issues": []}
        else:
            filled = sum(1 for f in filter_ids if f)
            score  = int(filled / n_rows * 100) if n_rows else 100
            dims["filter_id_assignment"] = {
                "score": score,
                "issues": ([f"{n_rows - filled} rows missing Filter ID"]
                           if score < 100 else []),
            }

        # sequence_ordering — check seq number and operator type
        seq_issues: List[str] = []
        if rows:
            row_seqs = {r.get("Sequence", "").strip() for r in rows}
            if seq not in row_seqs:
                seq_issues.append(
                    f"STTM sequences {row_seqs} do not include block {seq}")
            op_types = {r.get("Operator Type", "").strip()
                        for r in rows if r.get("Operator Type", "").strip()}
            if not op_types:
                seq_issues.append("Operator Type is blank in all STTM rows")
        dims["sequence_ordering"] = {
            "score": 100 if not seq_issues else 50,
            "issues": seq_issues,
        }

        # structural_completeness
        struct_issues: List[str] = []
        if not rows:
            struct_issues.append("No lineage rows")
        else:
            op_types = [r.get("Operator Type", "").strip() for r in rows]
            if not any(op_types):
                struct_issues.append("Operator Type not populated")
        dims["structural_completeness"] = {
            "score": 100 if not struct_issues else (70 if rows else 0),
            "issues": struct_issues,
        }

        # cross_sheet_integrity — check ID cross-references in Python
        valid_join_ids   = {r.get("Join ID",    "").strip()
                            for r in sttm.join_rows
                            if r.get("Join ID", "").strip()}
        valid_filter_ids = {r.get("Filter ID",  "").strip()
                            for r in sttm.filter_rows
                            if r.get("Filter ID", "").strip()}

        orphan_joins   = set()
        orphan_filters = set()
        for r in rows:
            for jid in r.get("Join IDs", "").split(","):
                jid = jid.strip()
                if jid and jid not in valid_join_ids:
                    orphan_joins.add(jid)
            for fid in r.get("Filter IDs", "").split(","):
                fid = fid.strip()
                if fid and fid not in valid_filter_ids:
                    orphan_filters.add(fid)

        integrity_issues: List[str] = []
        if orphan_joins:
            integrity_issues.append(
                f"Join IDs not in Join Conditions: {', '.join(sorted(orphan_joins)[:5])}")
        if orphan_filters:
            integrity_issues.append(
                f"Filter IDs not in Filter Conditions: {', '.join(sorted(orphan_filters)[:5])}")
        dims["cross_sheet_integrity"] = {
            "score": 100 if not integrity_issues else 70,
            "issues": integrity_issues,
        }

        return dims

    def _analyse_column_mappings_paged(
        self,
        block: "SQLBlock",
        seq: str,
        sql_snippet: str,
        lineage_rows: List[Dict],
    ) -> Tuple[int, List[str], List[Dict]]:
        """Score column_mappings by paging through lineage rows in batches.

        Each page gets a dedicated LLM call with a compact JSON response.
        The final score is the average across all pages.
        Large blocks (e.g. 400 rows) are handled as ~7 calls of 60 rows each.
        """
        if not lineage_rows:
            return 100, [], []

        total = len(lineage_rows)
        batches = [lineage_rows[i:i + _COL_PAGE_SIZE]
                   for i in range(0, total, _COL_PAGE_SIZE)]
        page_scores: List[int] = []
        all_issues:  List[str] = []

        for page_num, batch in enumerate(batches, 1):
            row_start = (page_num - 1) * _COL_PAGE_SIZE + 1
            row_end   = min(page_num * _COL_PAGE_SIZE, total)
            prompt = _COLUMN_PAGE_PROMPT_TMPL.format(
                idx=block.index,
                dml_type=block.dml_type,
                target_table=block.target_table or "UNKNOWN",
                sql=sql_snippet,
                seq=seq,
                page_num=page_num,
                total_pages=len(batches),
                row_start=row_start,
                row_end=row_end,
                total_rows=total,
                rows_on_page=len(batch),
                lineage_table=self._rows_to_text(
                    batch,
                    ["Sequence", "Source Table", "Source Column",
                     "Target Table", "Target Column", "Transformation SQL"],
                    limit=_COL_PAGE_SIZE,
                ),
            )
            try:
                raw    = self.llm.complete(
                    system=_SYSTEM_PROMPT,
                    messages=[{"role": "user", "content": prompt}],
                    max_tokens=800,
                )
                parsed = self._parse_json(raw)
                score  = int(parsed.get("score", 100)) if parsed else 100
                issues = parsed.get("issues", []) if parsed else []
            except Exception as e:
                print(f"      ⚠  column_mappings page {page_num} failed: {e}")
                score, issues = 100, []   # benefit of the doubt on error

            page_scores.append(score)
            all_issues.extend(issues)

        avg = int(sum(page_scores) / len(page_scores)) if page_scores else 100
        return avg, all_issues[:4], []

    def _analyse_group(
        self,
        block: "SQLBlock",
        seq: str,
        sql_snippet: str,
        lineage_table: str,
        join_table: str,
        filter_table: str,
        group: Dict,
    ) -> Tuple[Dict[str, Any], List[Dict]]:
        """Run one LLM call for a single dimension group.

        Returns (dimensions_dict, corrections_list).
        On parse failure the group dimensions default to 100 (benefit of the doubt
        — we failed to verify, not failed to pass).
        """
        dims = group["dimensions"]   # list of (name, weight, rule)

        dim_rules = "\n".join(
            f"  {name:<26} | {w:>2}% | {rule}"
            for name, w, rule in dims
        )
        dim_schema = "\n".join(
            f'    "{name}": {{"score": <int 0-100>, "issues": [<string>, ...]}}'
            for name, _, _ in dims
        )

        prompt = _GROUP_PROMPT_TMPL.format(
            group_name=group["name"],
            idx=block.index,
            dml_type=block.dml_type,
            target_table=block.target_table or "UNKNOWN",
            sql=sql_snippet,
            seq=seq,
            lineage_table=lineage_table,
            join_table=join_table,
            filter_table=filter_table,
            dimension_rules=dim_rules,
            dimension_schema=dim_schema,
        )

        fallback_dims = {
            name: {"score": 100, "issues": ["Group parse failed — could not verify"]}
            for name, _, _ in dims
        }

        try:
            raw = self.llm.complete(
                system=_SYSTEM_PROMPT,
                messages=[{"role": "user", "content": prompt}],
                max_tokens=3000,
            )
            parsed = self._parse_json(raw)
        except Exception as e:
            print(f"    ⚠  Group '{group['name']}' LLM call failed: {e}")
            return fallback_dims, []

        if not parsed:
            snippet = (raw or "")[:200].replace("\n", " ")
            print(f"    ⚠  Group '{group['name']}' parse failed "
                  f"(block {block.index}). Response: {snippet}")
            return fallback_dims, []

        return (
            parsed.get("dimensions", fallback_dims),
            parsed.get("corrections_needed", []),
        )

    @staticmethod
    def _compute_accuracy(dimensions: Dict[str, Any]) -> float:
        """Weighted accuracy score computed in Python from merged group results.

        Dimensions absent from the merged dict (group call failed entirely) are
        excluded from the denominator so they don't drag down the score.
        """
        weighted_sum = 0.0
        denominator  = 0
        for dim_name, weight in _WEIGHTS.items():
            dim_data = dimensions.get(dim_name)
            if dim_data is None:
                continue
            score = dim_data.get("score")
            if isinstance(score, (int, float)):
                weighted_sum += float(score) * weight
                denominator  += weight
        return weighted_sum / denominator if denominator > 0 else 0.0

    def _generate_refinement(self, analysis: BlockAnalysis,
                             sttm: STTMRows,
                             user_feedback: str = "") -> RefinementResult:
        seq = (sttm.sequence or str(analysis.block.index))
        prompt = _REFINEMENT_PROMPT_TMPL.format(
            idx=analysis.block.index,
            dml_type=analysis.block.dml_type,
            target_table=analysis.block.target_table or "UNKNOWN",
            seq=seq,
            corrections_json=json.dumps(analysis.corrections_needed, indent=2),
            lineage_table=self._rows_to_text(sttm.lineage_rows,
                                              ["Sequence", "Source Table", "Source Column",
                                               "Target Table", "Target Column",
                                               "Transformation SQL"]),
            join_table=self._rows_to_text(sttm.join_rows,
                                          ["Join ID", "Join Type", "Left Table",
                                           "Right Table", "Join SQL"]),
            filter_table=self._rows_to_text(sttm.filter_rows,
                                            ["Filter ID", "Filter Type", "SQL Expression"]),
            user_feedback=user_feedback or "(none)",
        )

        raw = self.llm.complete(
            system=_SYSTEM_PROMPT,
            messages=[{"role": "user", "content": prompt}],
            max_tokens=4000,
        )
        parsed = self._parse_json(raw)
        return RefinementResult(
            patches=parsed.get("patches", []),
            change_summary=parsed.get("change_summary", ""),
        )

    # ------------------------------------------------------------------
    # Issue selection (false-positive triage)
    # ------------------------------------------------------------------

    def _select_corrections(self, analysis: BlockAnalysis) -> BlockAnalysis:
        """Show issues and proposed corrections for one block; let the user
        choose which corrections to apply.  Dismissed items are treated as
        false positives and excluded from the refinement call.

        Returns a copy of the analysis with only the user-selected corrections.
        """
        b = analysis.block
        print(f"\n  {'─'*58}")
        print(f"  Block {b.index}  {b.dml_type} → {b.target_table or '?'}"
              f"  (score: {analysis.accuracy_score:.0f}/100)")
        print(f"  {'─'*58}")

        # Show per-dimension issues (only dims with real problems)
        shown_dims = {
            dim: data
            for dim, data in analysis.dimensions.items()
            if data.get("issues") and data.get("score", 100) < 100
        }
        if shown_dims:
            print("  Issues by dimension:")
            for dim, data in shown_dims.items():
                print(f"    [{data.get('score', '?'):>3}/100] {dim}")
                for iss in data.get("issues", []):
                    print(f"           • {iss}")

        corrections = analysis.corrections_needed
        if not corrections:
            print("  (No specific corrections generated — issues noted for reference only)")
            return analysis

        # Number and display each proposed correction
        print(f"\n  Proposed corrections ({len(corrections)} total):")
        for i, corr in enumerate(corrections, 1):
            action  = corr.get("type", "update").upper()
            sheet   = corr.get("sheet", "?")
            reason  = corr.get("reason", "")
            match   = corr.get("match_on", {})
            updates = corr.get("updates", {})
            print(f"    [{i}] {action} — {sheet}")
            if reason:
                print(f"         Reason : {reason}")
            if match:
                print(f"         Match  : {match}")
            if updates:
                print(f"         Updates: {updates}")

        print()
        raw = input(
            "  Select corrections to apply  "
            "(number(s) e.g. '1,3', 'all', 'none'): "
        ).strip().lower()

        if raw in ("none", ""):
            print("  → All corrections dismissed.")
            return self._with_corrections(analysis, [])

        if raw == "all":
            print("  → Applying all corrections.")
            return analysis

        # Parse individual numbers
        selected: List[Dict] = []
        dismissed: List[int] = []
        for part in raw.split(","):
            part = part.strip()
            if part.isdigit():
                idx = int(part) - 1
                if 0 <= idx < len(corrections):
                    selected.append(corrections[idx])
                else:
                    print(f"  ⚠  Index {part} out of range — ignored.")
            else:
                print(f"  ⚠  Could not parse '{part}' — ignored.")

        dismissed_count = len(corrections) - len(selected)
        print(f"  → {len(selected)} correction(s) selected, "
              f"{dismissed_count} dismissed as false positive(s).")
        return self._with_corrections(analysis, selected)

    @staticmethod
    def _with_corrections(analysis: BlockAnalysis,
                          corrections: List[Dict]) -> BlockAnalysis:
        """Return a shallow copy of analysis with a replaced corrections list."""
        return BlockAnalysis(
            block=analysis.block,
            sttm=analysis.sttm,
            accuracy_score=analysis.accuracy_score,
            dimensions=analysis.dimensions,
            issues=analysis.issues,
            corrections_needed=corrections,
            llm_summary=analysis.llm_summary,
            raw_response=analysis.raw_response,
        )

    # ------------------------------------------------------------------
    # Interactive refinement loop
    # ------------------------------------------------------------------

    def _refinement_loop(self, analyses: List[BlockAnalysis],
                         sttm_path: str,
                         sttm_data: Dict[str, STTMRows],
                         output_dir: str,
                         sql_path: str) -> None:
        print("\n" + "-" * 62)
        ans = self._ask("\nWould you like to refine the STTM with AI corrections? [y/N]",
                        valid=("y", "n", "yes", "no"), default="n")
        if ans.lower() not in ("y", "yes"):
            print("  Skipping refinement. Review complete.")
            return

        # Pick which blocks to refine (those with issues)
        problematic = [a for a in analyses
                       if a.accuracy_score < 100 or a.corrections_needed]
        if not problematic:
            print("  No issues found — nothing to refine.")
            return

        initial_avg = sum(a.accuracy_score for a in analyses) / len(analyses)
        print(f"\n  Pre-refinement accuracy:  {initial_avg:.1f}/100")

        # --- Issue triage: let user dismiss false positives per block ---
        print(f"\n  Review issues and select which corrections to apply.")
        print(f"  (Dismissed corrections are treated as false positives.)\n")
        triaged: List[BlockAnalysis] = []
        for analysis in problematic:
            triaged.append(self._select_corrections(analysis))

        # Only keep blocks where the user kept at least one correction
        to_refine = [a for a in triaged if a.corrections_needed]
        if not to_refine:
            print("\n  All corrections dismissed — nothing to refine.")
            return

        print(f"\n  {len(to_refine)} block(s) queued for refinement.\n")
        user_feedback = ""
        iteration = 0

        while True:
            iteration += 1
            print(f"\n  --- Refinement iteration {iteration} ---")

            # Load current xlsx (fresh each iteration)
            wb = load_workbook(sttm_path, data_only=True)
            all_changes: List[str] = []

            for analysis in to_refine:
                seq  = analysis.sttm.sequence if analysis.sttm else str(analysis.block.index)
                sttm = sttm_data.get(seq) or STTMRows(sequence=seq)
                print(f"  Refining block {analysis.block.index} "
                      f"({analysis.block.dml_type} → {analysis.block.target_table or '?'}) "
                      f"[{len(analysis.corrections_needed)} correction(s)] ...")

                ref = self._generate_refinement(analysis, sttm, user_feedback)

                # Apply patches to workbook
                changes = self._apply_patches(wb, ref.patches)
                all_changes.extend(changes)
                if ref.change_summary:
                    all_changes.append(f"Block {analysis.block.index}: {ref.change_summary}")

                # Update in-memory sttm_data for next iteration
                sttm_data[seq] = self._reload_sttm_rows_from_wb(wb, seq)

            # Save refined xlsx
            stem = Path(sttm_path).stem
            if "_ai_refined" in stem:
                out_path = sttm_path
            else:
                out_path = str(Path(output_dir) / f"{stem}_ai_refined.xlsx")
            wb.save(out_path)
            sttm_path = out_path

            print(f"\n  Saved refined STTM → {out_path}")
            print("\n  Changes made:")
            for c in all_changes:
                print(f"    • {c}")

            # Re-score refined blocks against the updated STTM
            print("\n  Re-scoring after refinement ...")
            for i, analysis in enumerate(to_refine):
                seq  = analysis.sttm.sequence if analysis.sttm else str(analysis.block.index)
                sttm = sttm_data.get(seq) or STTMRows(sequence=seq)
                new_analysis = self._analyse_block(analysis.block, sttm)
                to_refine[i] = new_analysis
                for j, a in enumerate(analyses):
                    if a.block.index == new_analysis.block.index:
                        analyses[j] = new_analysis
                        break

            # Print updated accuracy table
            self._print_accuracy_table(analyses,
                                       label=f"Post-refinement (iteration {iteration})")

            # Ask user
            print()
            ans = self._ask(
                "Are you satisfied? [y=yes / n=refine again / f=give feedback / s=select corrections]",
                valid=("y", "n", "f", "s", "yes", "no", "feedback", "select"),
                default="y",
            ).lower()

            if ans in ("y", "yes"):
                final_avg = sum(a.accuracy_score for a in analyses) / len(analyses)
                improvement = final_avg - initial_avg
                sign = "+" if improvement >= 0 else ""
                print(f"\n{'='*62}")
                print(f"  FINAL ACCURACY: {final_avg:.1f}/100  "
                      f"({sign}{improvement:.1f} vs pre-refinement)")
                print(f"  Refined STTM saved → {out_path}")
                print(f"{'='*62}")
                break

            if ans in ("f", "feedback"):
                user_feedback = input("  Your feedback: ").strip()
            elif ans in ("s", "select"):
                # Re-triage: let user pick corrections from the re-scored results
                remaining_issues = [a for a in to_refine
                                    if a.accuracy_score < 100 or a.corrections_needed]
                if remaining_issues:
                    print("\n  Re-selecting corrections from remaining issues ...")
                    to_refine = [self._select_corrections(a) for a in remaining_issues]
                    to_refine = [a for a in to_refine if a.corrections_needed]
                    if not to_refine:
                        print("  All remaining corrections dismissed. Review complete.")
                        break
                else:
                    print("  No remaining issues to select from.")
                    break
                continue
            else:
                user_feedback = ""

            # Check if still any issues
            remaining = [a for a in to_refine
                         if a.accuracy_score < 100 or a.corrections_needed]
            if not remaining:
                final_avg = sum(a.accuracy_score for a in analyses) / len(analyses)
                improvement = final_avg - initial_avg
                sign = "+" if improvement >= 0 else ""
                print(f"\n{'='*62}")
                print(f"  FINAL ACCURACY: {final_avg:.1f}/100  "
                      f"({sign}{improvement:.1f} vs pre-refinement) — all issues resolved")
                print(f"  Refined STTM saved → {out_path}")
                print(f"{'='*62}")
                break

            ans2 = self._ask(
                f"  {len(remaining)} block(s) still have issues. "
                "Refine again? [y/N]",
                valid=("y", "n", "yes", "no"), default="n",
            )
            if ans2.lower() not in ("y", "yes"):
                final_avg = sum(a.accuracy_score for a in analyses) / len(analyses)
                improvement = final_avg - initial_avg
                sign = "+" if improvement >= 0 else ""
                print(f"\n{'='*62}")
                print(f"  FINAL ACCURACY: {final_avg:.1f}/100  "
                      f"({sign}{improvement:.1f} vs pre-refinement)")
                print(f"  Refined STTM saved → {out_path}")
                print(f"{'='*62}")
                break
            to_refine = remaining

    # ------------------------------------------------------------------
    # xlsx patch application
    # ------------------------------------------------------------------

    def _apply_patches(self, wb, patches: List[Dict]) -> List[str]:
        """Apply LLM-generated patches to an open workbook. Returns change log."""
        changes: List[str] = []

        sheet_alias = {
            "Column Lineage": "Column Lineage",
            "Join Conditions": "Join Conditions",
            "Filter Conditions": "Filter Conditions",
        }

        for patch in patches:
            sheet_name = sheet_alias.get(patch.get("sheet", ""), "")
            if not sheet_name or sheet_name not in wb.sheetnames:
                continue

            ws = wb[sheet_name]
            action = patch.get("action", "update").lower()
            match_on: Dict = patch.get("match_on", {})
            updates: Dict = patch.get("updates", {})

            # Build header index
            header_row = [c.value for c in next(ws.iter_rows(min_row=1, max_row=1))]
            col_idx = {str(h).strip(): i + 1 for i, h in enumerate(header_row) if h}

            if action in ("update", "delete"):
                for row in ws.iter_rows(min_row=2):
                    row_vals = {
                        str(header_row[c.column - 1]).strip(): str(c.value or "")
                        for c in row
                        if c.column - 1 < len(header_row)
                    }
                    if all(row_vals.get(k, "") == str(v) for k, v in match_on.items()):
                        if action == "delete":
                            ws.delete_rows(row[0].row)
                            changes.append(f"Deleted row in {sheet_name}: {match_on}")
                        else:
                            for field_name, new_val in updates.items():
                                if field_name in col_idx:
                                    ws.cell(row=row[0].row, column=col_idx[field_name],
                                            value=new_val)
                            changes.append(
                                f"Updated {sheet_name} row {match_on}: "
                                + ", ".join(f"{k}='{v}'" for k, v in updates.items())
                            )
                        break

            elif action == "add":
                new_row = [""] * len(header_row)
                for field_name, val in updates.items():
                    if field_name in col_idx:
                        new_row[col_idx[field_name] - 1] = val
                ws.append(new_row)
                changes.append(f"Added row to {sheet_name}: {updates}")

        return changes

    def _reload_sttm_rows_from_wb(self, wb, seq: str) -> STTMRows:
        """Re-read one sequence's rows from an in-memory workbook after patching."""
        result = STTMRows(sequence=seq)

        def ws_rows(sheet_name: str, seq_col: str) -> List[Dict]:
            if sheet_name not in wb.sheetnames:
                return []
            ws = wb[sheet_name]
            headers = [str(c.value).strip() if c.value else "" for c in next(ws.iter_rows(min_row=1, max_row=1))]
            out = []
            for row in ws.iter_rows(min_row=2, values_only=True):
                d = {headers[i]: self._norm_seq(v) if headers[i] == seq_col
                                  else (str(v) if v is not None else "")
                     for i, v in enumerate(row)}
                s = d.get(seq_col, "")
                for part in s.split(","):
                    if part.strip() == seq:
                        out.append(d)
                        break
            return out

        result.lineage_rows = ws_rows("Column Lineage", "Sequence")
        result.join_rows = ws_rows("Join Conditions", "Applies To Sequence")
        result.filter_rows = ws_rows("Filter Conditions", "Applies To Sequence")
        return result

    # ------------------------------------------------------------------
    # Output helpers
    # ------------------------------------------------------------------

    def _print_block_summary(self, analysis: BlockAnalysis) -> None:
        score = analysis.accuracy_score
        grade = "A" if score >= 90 else ("B" if score >= 75 else ("C" if score >= 60 else "F"))
        status = "PASS" if score >= 75 else "ISSUES"
        print(f"    Score: {score:.0f}/100 [{grade}] — {status}")
        if analysis.llm_summary:
            # Print first sentence only for brevity
            first_sent = analysis.llm_summary.split(".")[0] + "."
            print(f"    {first_sent}")
        if analysis.issues:
            for iss in analysis.issues[:3]:
                print(f"    ⚠  {iss}")
            if len(analysis.issues) > 3:
                print(f"    ⚠  ... and {len(analysis.issues) - 3} more issue(s)")
        print()

    def _print_overall_summary(self, analyses: List[BlockAnalysis]) -> None:
        if not analyses:
            return
        avg = sum(a.accuracy_score for a in analyses) / len(analyses)
        total_issues = sum(len(a.issues) for a in analyses)
        print("=" * 62)
        print(f"  OVERALL ACCURACY: {avg:.1f}/100")
        print(f"  Blocks reviewed:  {len(analyses)}")
        print(f"  Total issues:     {total_issues}")
        print("=" * 62)

    def _print_accuracy_table(self, analyses: List[BlockAnalysis],
                               label: str = "Accuracy") -> None:
        """Print a per-block accuracy table with an overall average."""
        if not analyses:
            return
        avg = sum(a.accuracy_score for a in analyses) / len(analyses)
        grade = "A" if avg >= 90 else ("B" if avg >= 75 else ("C" if avg >= 60 else "F"))
        print(f"\n  {label}")
        print(f"  {'─'*58}")
        print(f"  {'Block':<8} {'Type':<14} {'Target':<22} {'Score':>7}  Grade")
        print(f"  {'─'*58}")
        for a in analyses:
            g = "A" if a.accuracy_score >= 90 else ("B" if a.accuracy_score >= 75 else ("C" if a.accuracy_score >= 60 else "F"))
            target = (a.block.target_table or "?")[:20]
            print(f"  {a.block.index:<8} {a.block.dml_type:<14} {target:<22} {a.accuracy_score:>6.1f}%  [{g}]")
        print(f"  {'─'*58}")
        print(f"  {'OVERALL':<44} {avg:>6.1f}%  [{grade}]")

    # ------------------------------------------------------------------
    # Utility helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _rows_to_text(rows: List[Dict], columns: List[str],
                      limit: int = 50) -> str:
        """Format a list of dicts as a compact pipe-delimited table.

        Args:
            limit: max rows to render (caller controls pagination).
        """
        if not rows:
            return "  (no rows)"
        header = " | ".join(columns)
        sep    = "-" * len(header)
        lines  = [header, sep]
        for row in rows[:limit]:
            lines.append(" | ".join(str(row.get(c, ""))[:80] for c in columns))
        if len(rows) > limit:
            lines.append(f"... ({len(rows) - limit} more rows)")
        return "\n".join(lines)

    @staticmethod
    def _parse_json(text: str) -> Dict:
        """Extract and parse JSON from an LLM response (strip markdown fences).

        Falls back to regex extraction of accuracy_score + per-dimension scores
        when the response is truncated and full JSON parse fails.
        """
        text = text.strip()
        # Remove ```json ... ``` fences if present
        text = re.sub(r'^```(?:json)?\s*', '', text, flags=re.MULTILINE)
        text = re.sub(r'\s*```\s*$', '', text, flags=re.MULTILINE)

        # --- Full JSON parse (best case) ---
        start = text.find("{")
        end = text.rfind("}")
        if start != -1 and end != -1:
            try:
                return json.loads(text[start:end + 1])
            except json.JSONDecodeError:
                pass

        # --- Partial-response recovery: extract what we can via regex ---
        # This handles responses truncated before the closing "}" of the root object.
        recovered: Dict = {}

        score_m = re.search(r'"accuracy_score"\s*:\s*([0-9]+(?:\.[0-9]+)?)', text)
        if score_m:
            recovered["accuracy_score"] = float(score_m.group(1))

        # Extract per-dimension scores
        dims: Dict = {}
        for m in re.finditer(
            r'"([\w_]+)"\s*:\s*\{\s*"score"\s*:\s*([0-9]+)', text
        ):
            dims[m.group(1)] = {"score": int(m.group(2)), "issues": []}
        if dims:
            recovered["dimensions"] = dims

        # Extract summary if present
        summ_m = re.search(r'"summary"\s*:\s*"([^"]{0,500})', text)
        if summ_m:
            recovered["summary"] = summ_m.group(1)

        return recovered

    @staticmethod
    def _ask(prompt: str, valid: Tuple = (), default: str = "") -> str:
        suffix = f" (default: {default})" if default else ""
        while True:
            ans = input(f"  {prompt}{suffix}: ").strip()
            if not ans and default:
                return default
            if not valid or ans.lower() in [v.lower() for v in valid]:
                return ans
            print(f"  Please enter one of: {', '.join(valid)}")


# ---------------------------------------------------------------------------
# Standalone CLI
# ---------------------------------------------------------------------------

def main():
    parser = argparse.ArgumentParser(
        description="AI-powered STTM accuracy reviewer with interactive refinement"
    )
    parser.add_argument("--sql",     required=True, help="Path to the SQL stored procedure file")
    parser.add_argument("--sttm",    required=True, help="Path to the structured STTM xlsx file")
    parser.add_argument("--dialect", default="teradata",
                        help="SQL dialect (default: teradata)")
    parser.add_argument("--output",  help="Output directory for refined xlsx (default: same as sttm)")
    args = parser.parse_args()

    if not _HAS_OPENPYXL:
        print("ERROR: openpyxl is required. Run: pip install openpyxl", file=sys.stderr)
        sys.exit(1)

    llm = LLMClientFactory.get_or_prompt()
    reviewer = AICodeReviewer(llm, dialect=args.dialect)
    reviewer.run(
        sql_path=args.sql,
        sttm_path=args.sttm,
        output_dir=args.output,
    )


if __name__ == "__main__":
    main()
