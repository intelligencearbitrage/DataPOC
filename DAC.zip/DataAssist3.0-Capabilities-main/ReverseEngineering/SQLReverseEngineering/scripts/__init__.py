"""
Scripts Package

Entry point:
- cli.py                   : Main CLI entry point for the SQL RE toolkit
- sql_reverse_engineering/ : SQL RE pipeline (tools, agents, schema)
"""
