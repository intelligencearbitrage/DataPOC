# SQL Reverse Engineering Toolkit

Reverse-engineers Teradata stored procedures into structured deliverables.
The primary output is an **STTM (Source-to-Target Mapping) CSV** with column-level lineage for every DML statement.

---

## What it does

1. Parses Teradata stored procedures (`.sql`, `.ddl`, `.vw`, `.bteq`) using `sqlglot`.
2. Extracts column-level lineage, JOIN conditions, WHERE predicates, and CASE/function transformations.
3. Handles volatile/temporary tables, CTEs, subqueries, and dynamic SQL.
4. Produces:
   - `*_lineage.csv` — one row per column-level source-to-target mapping
   - `*_structured.xlsx` — multi-sheet structured Excel version
   - `*_lineage_tree.html` — collapsible lineage tree (recommended)
   - `*_lineage_network.html` — interactive network graph
   - `*_documentation.html` — human-readable documentation generated from the SQL
   - `gaps_and_unknowns.yaml` — unresolved columns and ambiguities flagged for review
5. Optionally runs an **AI code review** of the generated STTM against the source SQL (see [AI Code Review](#ai-code-review) below).

---

## Folder layout

```
scripts/
├── cli.py                  ← Entry point (this folder)
├── requirements.txt
├── README.md
├── .env.example            ← LLM provider config template (copy to .env)
└── sql_reverse_engineering/
    ├── agents/             ← Agentic pipeline refinement
    │   ├── sttm_accuracy_refiner.py  ← Re-runs generation pipeline to fix root causes
    │   └── sttm_output_patcher.py   ← Patches XLSX output directly
    ├── schema/
    │   └── ddl_parser.py   ← Loads DDL schema for type resolution
    └── tools/
        ├── agent_interface/
        │   ├── cli.py             ← Full CLI implementation (all subcommands)
        │   ├── api.py             ← FastAPI REST server
        │   ├── ai_code_reviewer.py ← AI-powered STTM accuracy reviewer
        │   └── llm_client.py      ← Multi-provider LLM abstraction
        ├── ast_generator/  ← sqlglot-based SQL parser
        ├── deconstructor/  ← CASE, function, subquery, JOIN extractors
        ├── documentation/  ← STTM CSV/Excel + HTML help generators
        ├── dynamic_sql/    ← Dynamic SQL detection and expansion
        ├── experts/        ← Code reviewer and field-mapping expert agents
        ├── file_handlers/  ← SQL/DDL/view file loaders
        ├── lineage/        ← Core lineage extraction engine
        ├── models/         ← Data models (LineageGraph, LineageEdge, ColumnRef)
        ├── validation/     ← Quality guardrail checks
        └── visualization/  ← pyvis + graphviz renderers
```

---

## Setup

### Prerequisites

- Python 3.10 or later

### Install Python dependencies

```bash
pip install -r scripts/requirements.txt
```

---

## Usage

All commands are exposed through a single entry point:

```bash
# From the project root
python scripts/cli.py <command> [options]

# Or as a module
python -m sql_reverse_engineering.cli <command> [options]
```

### Available commands

| Command | Description |
|---------|-------------|
| `full` | Generate ALL outputs for a single file (CSV, Excel, HTML, visualization) |
| `batch` | Process a directory of SQL files recursively |
| `batch-full` | `full` output for every file in a directory |
| `lineage` | Extract lineage for a specific target column |
| `dynamic-sql` | Detect and expand dynamic SQL constructs |
| `multi-file` | Cross-file lineage across multiple stored procedures |
| `cross-file` | Cross-file lineage with shared volatile table context |
| `verify` | Recursively verify all SQL files in a directory |
| `expert-analyze` | Deep expert analysis of a SQL file |

### Common examples

```bash
# Single file — all outputs
python scripts/cli.py full \
    --input inputs/Complex/FRY_14/Schema/sp_example.sql \
    --output output/sp_example/ \
    --dialect teradata

# Single file — all outputs + AI code review
python scripts/cli.py full \
    --input inputs/Complex/FRY_14/Schema/sp_example.sql \
    --output output/sp_example/ \
    --dialect teradata \
    --review

# Batch — whole directory, recursive
python scripts/cli.py batch-full \
    --input inputs/Complex/FRY_14/Schema/ \
    --output output/SP_batch/ \
    --dialect teradata

# Lineage for a specific target column
python scripts/cli.py lineage \
    --input inputs/Complex/FRY_14/Schema/sp_example.sql \
    --column target_table.some_column
```

---

## AI Code Review

The `--review` flag on `full` and `batch-full` runs an AI-powered accuracy check
of the generated STTM against the original SQL after generation completes.

### How it works

- **SQL-to-STTM matching** — Splits the source SQL into individual DML blocks and matches each one to its STTM sequence by target table name.
- **Agent-team scoring** — Each block is evaluated by multiple focused LLM sub-agents: one for coverage and column correctness (paginated across all rows), one for join and filter capture, and one for transformation quality and alias resolution.
- **12-dimension accuracy** — Covers column mappings, source tables, join/filter capture, ID assignment, transformation SQL, sequence ordering, structural completeness, alias resolution, and cross-sheet integrity — weighted to sum to 100%.
- **Python-controlled score** — The final accuracy score is computed in Python from merged agent results; structural dimensions (sequence ordering, ID assignment, cross-sheet integrity) are verified deterministically without LLM calls.
- **Interactive refinement loop** — After scoring, the user can review each issue, dismiss false positives, apply AI-generated corrections to the STTM, re-score, and iterate until satisfied.

### LLM configuration

#### Step 1 — Create your `.env` file

```bash
cp scripts/.env.example scripts/.env
```

#### Step 2 — Pick a provider and fill in credentials

Open `scripts/.env` and set `LLM_PROVIDER` to one of the four options below,
then uncomment and fill in the matching credential block.

---

**Option A — Claude via Azure AI Foundry** *(default)*

```env
LLM_PROVIDER=claude_foundry

ANTHROPIC_API_KEY=<your-azure-foundry-api-key>
AZURE_FOUNDRY_RESOURCE=<your-resource-name>
# e.g. AZURE_FOUNDRY_RESOURCE=az-msf-mt-npd-001
```

---

**Option B — Claude via direct Anthropic API**

Get a key at [console.anthropic.com](https://console.anthropic.com/).

```env
LLM_PROVIDER=anthropic

ANTHROPIC_API_KEY=sk-ant-<your-key-here>
```

---

**Option C — OpenAI GPT**

Requires `pip install openai`. Get a key at [platform.openai.com](https://platform.openai.com/api-keys).

```env
LLM_PROVIDER=openai

OPENAI_API_KEY=sk-<your-key-here>
# LLM_MODEL=gpt-4o   # optional — gpt-4o is the default
```

---

**Option D — Azure OpenAI**

Requires `pip install openai`.

```env
LLM_PROVIDER=azure_openai

AZURE_OPENAI_API_KEY=<your-azure-openai-key>
AZURE_OPENAI_ENDPOINT=https://<your-resource>.openai.azure.com/
AZURE_OPENAI_DEPLOYMENT=<your-deployment-name>
AZURE_OPENAI_API_VERSION=2024-02-01
```

---

#### Optional — override the model

Any provider's default model can be overridden:

```env
LLM_MODEL=claude-opus-4-7
```

#### No `.env` file?

If `.env` is missing or `LLM_PROVIDER` is not set, the CLI will interactively
prompt you to choose a provider and enter credentials at runtime — no file needed.

```
No .env found. Which LLM provider would you like to use?
  [1] claude_foundry  (Claude via Azure AI Foundry)
  [2] anthropic       (Claude via Anthropic API)
  [3] openai          (OpenAI GPT)
  [4] azure_openai    (Azure OpenAI)
Choice: _
```

#### Quick reference

| Provider | `LLM_PROVIDER` | Required vars |
|----------|----------------|---------------|
| Claude via Azure AI Foundry | `claude_foundry` | `ANTHROPIC_API_KEY`, `AZURE_FOUNDRY_RESOURCE` |
| Claude via Anthropic API | `anthropic` | `ANTHROPIC_API_KEY` |
| OpenAI GPT | `openai` | `OPENAI_API_KEY` |
| Azure OpenAI | `azure_openai` | `AZURE_OPENAI_API_KEY`, `AZURE_OPENAI_ENDPOINT`, `AZURE_OPENAI_DEPLOYMENT` |

The full template with all options is in [`scripts/.env.example`](scripts/.env.example).

---

The reviewer can also be run standalone without the generation step:

```bash
python scripts/sql_reverse_engineering/tools/agent_interface/ai_code_reviewer.py \
    --sql  inputs/Complex/FRY_14/Schema/sp_example.sql \
    --sttm output/sp_example/sp_example_structured.xlsx
```

### Important disclaimer

> **AI-generated accuracy scores and corrections are indicative, not definitive.**
> The review and refinement outputs are produced by a large language model and
> may contain false positives, missed issues, or incorrect corrections — especially
> for complex SQL patterns, heavily aliased queries, or volatile table chains.
> Scores should be treated as a directional signal rather than a precise measurement.
> Always validate AI-suggested STTM corrections against the original SQL before
> accepting them. The refinement loop includes an issue-selection step so you can
> dismiss suspected false positives before any changes are written.

---

## Assumptions and known limitations

- **Teradata dialect only.** The parser is tuned for Teradata SPL. Standard SQL and SQL Server dialects have partial support but are not the primary target.
- **No external SQL parser.** `sqlglot` is used for AST generation; the lineage engine implements its own walk on top. The `sqlparse` or `antlr` packages are not used.
- **Volatile tables resolved by name only.** Volatile tables are matched to their `CREATE VOLATILE TABLE` DDL by name (case-insensitive). Cross-session volatile tables are not supported.
- **Dynamic SQL is detected but not fully expanded.** Statements built from `EXECUTE IMMEDIATE` or string concatenation are flagged in `gaps_and_unknowns.yaml`; their column-level lineage is not guaranteed.
- **Literal sources show `[DIRECT LITERAL]`.** When the right-hand side of an assignment is a constant (string, number, NULL), the source_table is recorded as `[DIRECT LITERAL]` to indicate no real source table.
- **`knowledgebase/` and `inputs/` are read-only.** Scripts must never write to these directories; all output goes to `output/`.
