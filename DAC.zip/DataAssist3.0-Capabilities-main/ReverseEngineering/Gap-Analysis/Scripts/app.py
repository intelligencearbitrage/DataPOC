"""
Gap Analysis for Remediation — Standalone Flask Application.

Routes:
  GET  /                     → Landing page with gap analysis UI.
  POST /extract              → Accepts .twbx/.pbix, extracts metadata, returns Excel.
  POST /compare              → Accepts Report Metadata + CDH Metadata, returns gap analysis Excel.
  GET  /download/<filename>  → Streams the generated file.
"""

import logging
import os
import io
import re
import shutil
import uuid
from datetime import datetime

from flask import (
    Flask,
    jsonify,
    render_template,
    request,
    send_file,
)
from werkzeug.utils import secure_filename

from extractors import pbix_extractor, twbx_extractor
from utils.excel_writer import generate_excel
from utils.compare_lineage import compare_lineage
from utils.glossary_generator import generate_description

# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
UPLOAD_FOLDER = os.path.join(BASE_DIR, "uploads")
OUTPUT_FOLDER = os.path.join(BASE_DIR, "outputs")
ALLOWED_EXTENSIONS = {"pbix", "twbx"}
MAX_CONTENT_LENGTH = 500 * 1024 * 1024  # 500 MB

os.makedirs(UPLOAD_FOLDER, exist_ok=True)
os.makedirs(OUTPUT_FOLDER, exist_ok=True)

# ---------------------------------------------------------------------------
# App factory
# ---------------------------------------------------------------------------
app = Flask(__name__, template_folder="templates", static_folder="static")
app.config["MAX_CONTENT_LENGTH"] = MAX_CONTENT_LENGTH
app.config["UPLOAD_FOLDER"] = UPLOAD_FOLDER
app.config["OUTPUT_FOLDER"] = OUTPUT_FOLDER

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s – %(message)s",
)
logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------
def _allowed_file(filename: str) -> bool:
    return "." in filename and filename.rsplit(".", 1)[1].lower() in ALLOWED_EXTENSIONS


def _build_glossary(lineage_rows):
    """Build a deduplicated Report_Lineage_Glossary from Data_Lineage rows."""
    seen = set()
    table_desc_cache = {}
    glossary = []
    for row in lineage_rows:
        src_table = row.get("Source Table", "") or row.get("Data Source Name", "")
        src_col = row.get("Source Column", "")
        display = row.get("Field Display Name", src_col)
        data_type = row.get("Data Type", "")
        key = (src_table, src_col)
        if key in seen or not src_col:
            continue
        seen.add(key)
        if src_table and src_table not in table_desc_cache:
            table_desc_cache[src_table] = generate_description(src_table)
        table_description = table_desc_cache.get(src_table, "")
        description = generate_description(src_col, src_table)
        glossary.append({
            "Source Table": src_table,
            "Source Table Description": table_description,
            "Column Name": src_col,
            "Display Name": display,
            "Data Type": data_type,
            "Business Description": description,
        })
    glossary.sort(key=lambda r: (r["Source Table"].lower(), r["Column Name"].lower()))
    return glossary


# ---------------------------------------------------------------------------
# Routes
# ---------------------------------------------------------------------------
@app.route("/")
def index():
    """Serve the single-page gap analysis UI."""
    return render_template("index.html")


@app.route("/download/<filename>")
def download(filename):
    """Read file into memory, delete from outputs/, then stream to browser."""
    safe_name = secure_filename(filename)
    output_dir = app.config["OUTPUT_FOLDER"]
    file_path = os.path.join(output_dir, safe_name)

    if not os.path.isfile(file_path):
        return jsonify({"error": "File not found."}), 404

    with open(file_path, "rb") as fh:
        data = io.BytesIO(fh.read())

    try:
        os.remove(file_path)
        logger.info("Cleaned up output file: %s", safe_name)
    except OSError:
        logger.warning("Could not delete output file: %s", safe_name)

    if safe_name.endswith(".xlsx"):
        mimetype = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
    elif safe_name.endswith(".zip"):
        mimetype = "application/zip"
    else:
        mimetype = "application/octet-stream"

    return send_file(data, mimetype=mimetype, as_attachment=True, download_name=safe_name)


# ---------------------------------------------------------------------------
# Route: Report Lineage Extraction
# ---------------------------------------------------------------------------
@app.route("/extract", methods=["POST"])
def extract():
    """Accept a .twbx or .pbix file, extract metadata, return download link."""
    if "report_file" not in request.files:
        return jsonify({"error": "No report file provided."}), 400

    report_file = request.files["report_file"]
    if not report_file.filename:
        return jsonify({"error": "No file selected."}), 400

    file_ext = report_file.filename.rsplit(".", 1)[-1].lower() if "." in report_file.filename else ""
    if file_ext not in {"twbx", "pbix"}:
        return jsonify({"error": "Unsupported file type. Please upload a .twbx or .pbix file."}), 400

    original_name = secure_filename(report_file.filename)
    logger.info("Extract: file=%s", original_name)

    try:
        file_bytes = report_file.read()
        logger.info("File size: %d bytes", len(file_bytes))

        if file_ext == "twbx":
            metadata = twbx_extractor.extract(file_bytes, filename=original_name)
        else:
            metadata = pbix_extractor.extract(file_bytes, filename=original_name)

        # Build Report_Lineage_Glossary from Data_Lineage rows
        metadata["Report_Lineage_Glossary"] = _build_glossary(metadata.get("Data_Lineage", []))

        extraction_excel_bytes = generate_excel(metadata)

        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        base_name = os.path.splitext(original_name)[0]
        platform_tag = "Tableau" if file_ext == "twbx" else "PowerBI"
        extraction_filename = f"{base_name}_{platform_tag}_Metadata_{timestamp}_{uuid.uuid4().hex[:6]}.xlsx"
        extraction_path = os.path.join(OUTPUT_FOLDER, extraction_filename)
        with open(extraction_path, "wb") as f:
            f.write(extraction_excel_bytes)
        logger.info("Extraction report saved: %s", extraction_path)

        extraction_summary = {
            sheet: len(rows) for sheet, rows in metadata.items()
        }

        return jsonify({
            "success": True,
            "extraction_filename": extraction_filename,
            "extraction_download_url": f"/download/{extraction_filename}",
            "extraction_summary": extraction_summary,
        })

    except ValueError as ve:
        logger.warning("Extract validation error: %s", ve)
        return jsonify({"error": str(ve)}), 400
    except Exception:
        logger.exception("Error during metadata extraction.")
        return jsonify({"error": "An unexpected error occurred during extraction."}), 500


# ---------------------------------------------------------------------------
# Route: Gap Analysis for Remediation (Compare)
# ---------------------------------------------------------------------------
@app.route("/compare", methods=["POST"])
def compare():
    """Accept Report Metadata + CDH Metadata Excel files, return gap analysis."""
    if "asis_file" not in request.files or "tobe_file" not in request.files:
        return jsonify({"error": "Both 'asis_file' and 'tobe_file' are required."}), 400

    asis_file = request.files["asis_file"]
    tobe_file = request.files["tobe_file"]

    if not asis_file.filename or not tobe_file.filename:
        return jsonify({"error": "Please select both files."}), 400

    for f in (asis_file, tobe_file):
        if not f.filename.lower().endswith((".xlsx", ".xls")):
            return jsonify({
                "error": f"'{f.filename}' is not an Excel file. Please upload .xlsx files."
            }), 400

    try:
        asis_bytes = asis_file.read()
        tobe_bytes = tobe_file.read()

        logger.info("Compare: asis=%s (%d B), tobe=%s (%d B)",
                     asis_file.filename, len(asis_bytes),
                     tobe_file.filename, len(tobe_bytes))

        comparison_bytes = compare_lineage(
            asis_bytes, tobe_bytes,
            asis_name=asis_file.filename,
            tobe_name=tobe_file.filename,
        )

        # Quick sanity check — re-open the generated Excel
        import io as _io2
        from openpyxl import load_workbook as _load_wb2
        _wb = _load_wb2(filename=_io2.BytesIO(comparison_bytes), read_only=True)
        _ws = _wb["Overall Metadata Match Details"]
        _headers = [c.value for c in next(_ws.iter_rows(min_row=1, max_row=1))]
        _match_col = _headers.index("Match Found") if "Match Found" in _headers else None
        _matched = 0
        _total = 0
        for r in _ws.iter_rows(min_row=2, values_only=True):
            _total += 1
            if _match_col is not None and r[_match_col] == "Yes":
                _matched += 1
        _wb.close()
        logger.info("Compare result: %d/%d matched", _matched, _total)

        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        import re as _re
        _asis_base = _re.split(r"_Metadata_", asis_file.filename.rsplit(".", 1)[0], maxsplit=1)[0]
        output_filename = f"{_asis_base}_Field_Gap_Analysis_{timestamp}_{uuid.uuid4().hex[:6]}.xlsx"
        output_path = os.path.join(OUTPUT_FOLDER, output_filename)

        with open(output_path, "wb") as f:
            f.write(comparison_bytes)

        logger.info("Gap analysis report saved: %s", output_path)

        return jsonify({
            "success": True,
            "filename": output_filename,
            "download_url": f"/download/{output_filename}",
        })

    except ValueError as ve:
        logger.warning("Comparison validation error: %s", ve)
        return jsonify({"error": str(ve)}), 400
    except Exception:
        logger.exception("Error during gap analysis.")
        return jsonify({"error": "An unexpected error occurred during comparison."}), 500


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------
if __name__ == "__main__":
    app.run(
        debug=True,
        host="127.0.0.1",
        port=5003,
    )
