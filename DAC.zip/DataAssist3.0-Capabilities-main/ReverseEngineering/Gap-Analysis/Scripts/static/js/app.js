/**
 * Gap Analysis for Remediation — Frontend Logic
 * Standalone version (Report Lineage Extraction + Gap Analysis only).
 */
(function () {
    "use strict";

    /* ========================================================
       Utility helpers
       ======================================================== */
    function hideAll(...elements) {
        elements.forEach(el => { if (el) el.classList.add("hidden"); });
    }

    function hideAllSteps() {
        document.querySelectorAll(".wizard-step").forEach(s => s.classList.add("hidden"));
    }

    function goToStep(n) {
        hideAllSteps();
        const id = n === 0 ? "step-landing" : "step-" + n;
        const el = document.getElementById(id);
        if (el) el.classList.remove("hidden");
    }

    function resetAll() {
        resetMeUI();
        resetGaUI();
        // Reset sub-tabs to default (Report Lineage Extraction)
        gaSubTabs.forEach(t => t.classList.remove("active"));
        const extractTab = document.getElementById("ga-subtab-extract");
        if (extractTab) extractTab.classList.add("active");
        Object.values(gaSubPanels).forEach(p => { if (p) p.classList.add("hidden"); });
        const extractPanel = document.getElementById("panel-ga-extract");
        if (extractPanel) extractPanel.classList.remove("hidden");
        goToStep(0);
    }

    /* ========================================================
       Landing card → open Step 1b
       ======================================================== */
    const cardGapAnalysis = document.getElementById("card-gap-analysis");
    if (cardGapAnalysis) {
        cardGapAnalysis.addEventListener("click", () => {
            hideAllSteps();
            const step1b = document.getElementById("step-1b");
            if (step1b) step1b.classList.remove("hidden");
        });
    }

    /* ========================================================
       GAP ANALYSIS SUB-TAB NAVIGATION
       ======================================================== */
    const gaSubTabs = document.querySelectorAll("#ga-sub-tabs .sub-tab");
    const gaSubPanels = {
        "panel-ga-extract": document.getElementById("panel-ga-extract"),
        "panel-ga-compare": document.getElementById("panel-ga-compare"),
    };

    gaSubTabs.forEach(tab => {
        tab.addEventListener("click", () => {
            gaSubTabs.forEach(t => t.classList.remove("active"));
            tab.classList.add("active");
            Object.values(gaSubPanels).forEach(p => { if (p) p.classList.add("hidden"); });
            const target = tab.dataset.target;
            if (gaSubPanels[target]) gaSubPanels[target].classList.remove("hidden");
        });
    });

    /* ========================================================
       Home button
       ======================================================== */
    const gaHomeBtn = document.getElementById("ga-home-btn");
    if (gaHomeBtn) gaHomeBtn.addEventListener("click", resetAll);

    /* ========================================================
       STEP 1 – REPORT LINEAGE EXTRACTION
       ======================================================== */
    const meTableauZone   = document.getElementById("me-tableau-zone");
    const meTableauInput  = document.getElementById("me-tableau-input");
    const meTableauLabel  = document.getElementById("me-tableau-label");
    const meRunBtn        = document.getElementById("me-run-btn");
    const meProgress      = document.getElementById("me-progress");
    const meProgressText  = document.getElementById("me-progress-text");
    const meProgressBar   = document.getElementById("me-progress-bar");
    const meResult        = document.getElementById("me-result");
    const meResultSummary = document.getElementById("me-result-summary");
    const meExtractionDL  = document.getElementById("me-extraction-download");
    const meError         = document.getElementById("me-error");
    const meErrorMsg      = document.getElementById("me-error-message");
    const meErrorReset    = document.getElementById("me-error-reset");

    let meTableauFile = null;

    // Event listeners
    if (meTableauZone) {
        meTableauZone.addEventListener("click", () => meTableauInput.click());
        meTableauZone.addEventListener("dragover", e => { e.preventDefault(); meTableauZone.classList.add("drag-over"); });
        meTableauZone.addEventListener("dragleave", () => meTableauZone.classList.remove("drag-over"));
        meTableauZone.addEventListener("drop", e => {
            e.preventDefault(); meTableauZone.classList.remove("drag-over");
            if (e.dataTransfer.files.length) pickMeFile(e.dataTransfer.files[0]);
        });
    }
    if (meTableauInput) meTableauInput.addEventListener("change", e => {
        if (e.target.files.length) pickMeFile(e.target.files[0]);
    });
    if (meRunBtn) meRunBtn.addEventListener("click", startExtraction);
    if (meErrorReset) meErrorReset.addEventListener("click", resetMeUI);

    function pickMeFile(file) {
        const ext = file.name.split(".").pop().toLowerCase();
        if (ext !== "twbx" && ext !== "pbix") {
            showMeError("Please select a .twbx or .pbix file.");
            return;
        }
        meTableauFile = file;
        meTableauLabel.textContent = file.name;
        meTableauZone.classList.add("file-selected");
        meRunBtn.disabled = false;
    }

    function startExtraction() {
        if (!meTableauFile) return;
        hideAll(meResult, meError);
        meProgress.classList.remove("hidden");
        meProgressText.textContent = "Uploading file…";
        meProgressBar.style.width = "0%";
        meRunBtn.disabled = true;

        const formData = new FormData();
        formData.append("report_file", meTableauFile);

        const xhr = new XMLHttpRequest();
        xhr.open("POST", "/extract");

        xhr.upload.addEventListener("progress", e => {
            if (e.lengthComputable) {
                const pct = Math.round((e.loaded / e.total) * 30);
                meProgressBar.style.width = pct + "%";
                if (pct >= 30) meProgressText.textContent = "Extracting metadata…";
            }
        });

        xhr.upload.addEventListener("load", () => {
            meProgressText.textContent = "Extracting metadata…";
            animateProgress(meProgressBar, meProgress, 30, 90, 10000);
        });

        xhr.addEventListener("load", () => {
            meProgressBar.style.width = "100%";
            try {
                const resp = JSON.parse(xhr.responseText);
                if (xhr.status === 200 && resp.success) {
                    hideAll(meProgress, meError);
                    meResult.classList.remove("hidden");
                    const summary = resp.extraction_summary || {};
                    const lines = Object.entries(summary)
                        .filter(([, count]) => count > 0)
                        .map(([sheet, count]) => `${sheet}: ${count}`);
                    meResultSummary.textContent = lines.length ? lines.join(" · ") : "Extraction complete.";
                    meExtractionDL.href = resp.extraction_download_url;
                    meExtractionDL.setAttribute("download", resp.extraction_filename);
                } else {
                    showMeError(resp.error || "Unknown error occurred.");
                }
            } catch { showMeError("Failed to parse server response."); }
            meRunBtn.disabled = false;
        });

        xhr.addEventListener("error", () => {
            showMeError("Network error. Please check that the server is running.");
            meRunBtn.disabled = false;
        });

        xhr.timeout = 300000;
        xhr.send(formData);
    }

    function showMeError(msg) {
        hideAll(meProgress, meResult);
        meError.classList.remove("hidden");
        meErrorMsg.textContent = msg;
    }

    function resetMeUI() {
        meTableauFile = null;
        if (meTableauInput) meTableauInput.value = "";
        if (meTableauLabel) meTableauLabel.textContent = "Click or drop .twbx or .pbix file";
        if (meTableauZone) meTableauZone.classList.remove("file-selected");
        if (meRunBtn) meRunBtn.disabled = true;
        hideAll(meProgress, meResult, meError);
        if (meProgressBar) meProgressBar.style.width = "0%";
    }

    /* ========================================================
       STEP 1B – GAP ANALYSIS (COMPARE)
       ======================================================== */
    const gaAsisZone    = document.getElementById("ga-asis-zone");
    const gaAsisInput   = document.getElementById("ga-asis-input");
    const gaAsisLabel   = document.getElementById("ga-asis-label");
    const gaCdhZone     = document.getElementById("ga-cdh-zone");
    const gaCdhInput    = document.getElementById("ga-cdh-input");
    const gaCdhLabel    = document.getElementById("ga-cdh-label");
    const gaRunBtn      = document.getElementById("ga-run-btn");
    const gaProgress    = document.getElementById("ga-progress");
    const gaProgressTxt = document.getElementById("ga-progress-text");
    const gaProgressBar = document.getElementById("ga-progress-bar");
    const gaResult      = document.getElementById("ga-result");
    const gaResultSum   = document.getElementById("ga-result-summary");
    const gaDownload    = document.getElementById("ga-download");
    const gaError       = document.getElementById("ga-error");
    const gaErrorMsg    = document.getElementById("ga-error-message");
    const gaErrorReset  = document.getElementById("ga-error-reset");

    let gaAsisFile = null;
    let gaCdhFile = null;

    // Report Metadata zone
    if (gaAsisZone) {
        gaAsisZone.addEventListener("click", () => gaAsisInput.click());
        gaAsisZone.addEventListener("dragover", e => { e.preventDefault(); gaAsisZone.classList.add("drag-over"); });
        gaAsisZone.addEventListener("dragleave", () => gaAsisZone.classList.remove("drag-over"));
        gaAsisZone.addEventListener("drop", e => {
            e.preventDefault(); gaAsisZone.classList.remove("drag-over");
            if (e.dataTransfer.files.length) pickGaFile(e.dataTransfer.files[0], "asis");
        });
    }
    if (gaAsisInput) gaAsisInput.addEventListener("change", e => {
        if (e.target.files.length) pickGaFile(e.target.files[0], "asis");
    });

    // CDH Metadata zone
    if (gaCdhZone) {
        gaCdhZone.addEventListener("click", () => gaCdhInput.click());
        gaCdhZone.addEventListener("dragover", e => { e.preventDefault(); gaCdhZone.classList.add("drag-over"); });
        gaCdhZone.addEventListener("dragleave", () => gaCdhZone.classList.remove("drag-over"));
        gaCdhZone.addEventListener("drop", e => {
            e.preventDefault(); gaCdhZone.classList.remove("drag-over");
            if (e.dataTransfer.files.length) pickGaFile(e.dataTransfer.files[0], "cdh");
        });
    }
    if (gaCdhInput) gaCdhInput.addEventListener("change", e => {
        if (e.target.files.length) pickGaFile(e.target.files[0], "cdh");
    });

    if (gaRunBtn) gaRunBtn.addEventListener("click", startGapAnalysis);
    if (gaErrorReset) gaErrorReset.addEventListener("click", resetGaUI);

    function pickGaFile(file, which) {
        if (!file.name.toLowerCase().endsWith(".xlsx") && !file.name.toLowerCase().endsWith(".xls")) {
            showGaError("Please select an Excel (.xlsx) file.");
            return;
        }
        if (which === "asis") {
            gaAsisFile = file;
            gaAsisLabel.textContent = file.name;
            gaAsisZone.classList.add("file-selected");
        } else {
            gaCdhFile = file;
            gaCdhLabel.textContent = file.name;
            gaCdhZone.classList.add("file-selected");
        }
        gaRunBtn.disabled = !(gaAsisFile && gaCdhFile);
    }

    function startGapAnalysis() {
        if (!gaAsisFile || !gaCdhFile) return;
        hideAll(gaResult, gaError);
        gaProgress.classList.remove("hidden");
        gaProgressTxt.textContent = "Uploading files…";
        gaProgressBar.style.width = "0%";
        gaRunBtn.disabled = true;

        const formData = new FormData();
        formData.append("asis_file", gaAsisFile);
        formData.append("tobe_file", gaCdhFile);

        const xhr = new XMLHttpRequest();
        xhr.open("POST", "/compare");

        xhr.upload.addEventListener("progress", e => {
            if (e.lengthComputable) {
                const pct = Math.round((e.loaded / e.total) * 30);
                gaProgressBar.style.width = pct + "%";
                if (pct >= 30) gaProgressTxt.textContent = "Comparing metadata…";
            }
        });

        xhr.upload.addEventListener("load", () => {
            gaProgressTxt.textContent = "Comparing metadata and identifying gaps…";
            animateProgress(gaProgressBar, gaProgress, 30, 90, 15000);
        });

        xhr.addEventListener("load", () => {
            gaProgressBar.style.width = "100%";
            try {
                const resp = JSON.parse(xhr.responseText);
                if (xhr.status === 200 && resp.success) {
                    hideAll(gaProgress, gaError);
                    gaResult.classList.remove("hidden");
                    gaResultSum.textContent = "Gap analysis complete.";
                    gaDownload.href = resp.download_url;
                    gaDownload.setAttribute("download", resp.filename);
                } else {
                    showGaError(resp.error || "Unknown error occurred.");
                }
            } catch { showGaError("Failed to parse server response."); }
            gaRunBtn.disabled = false;
        });

        xhr.addEventListener("error", () => {
            showGaError("Network error. Please check that the server is running.");
            gaRunBtn.disabled = false;
        });

        xhr.timeout = 300000;
        xhr.send(formData);
    }

    function showGaError(msg) {
        hideAll(gaProgress, gaResult);
        gaError.classList.remove("hidden");
        gaErrorMsg.textContent = msg;
    }

    function resetGaUI() {
        gaAsisFile = null;
        gaCdhFile = null;
        if (gaAsisInput) gaAsisInput.value = "";
        if (gaCdhInput) gaCdhInput.value = "";
        if (gaAsisLabel) gaAsisLabel.textContent = "Click or drop Report Metadata .xlsx file";
        if (gaCdhLabel) gaCdhLabel.textContent = "Click or drop CDH Metadata .xlsx file";
        if (gaAsisZone) gaAsisZone.classList.remove("file-selected");
        if (gaCdhZone) gaCdhZone.classList.remove("file-selected");
        if (gaRunBtn) gaRunBtn.disabled = true;
        hideAll(gaProgress, gaResult, gaError);
        if (gaProgressBar) gaProgressBar.style.width = "0%";
    }

    /* ========================================================
       Shared progress animation helper
       ======================================================== */
    function animateProgress(bar, container, from, to, duration) {
        const startTime = Date.now();
        function tick() {
            const elapsed = Date.now() - startTime;
            const pct = Math.min(from + ((to - from) * elapsed) / duration, to);
            bar.style.width = pct + "%";
            if (pct < to && container && !container.classList.contains("hidden")) {
                requestAnimationFrame(tick);
            }
        }
        requestAnimationFrame(tick);
    }

})();
