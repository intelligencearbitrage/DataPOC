"""
Power BI (.pbix) metadata extractor.

A .pbix file is a ZIP archive containing:
  - DataModelSchema     : JSON with tables, columns, relationships, measures
  - Report/Layout       : JSON with report pages and visual definitions
  - Connections         : JSON with data source connection info
  - DataMashup          : Binary blob containing a nested ZIP with Power Query M code
  - [Content_Types].xml : Standard OPC content types
"""

import io
import json
import logging
import os
import re
import subprocess
import tempfile
import zipfile
from pathlib import Path
from typing import Any, Dict, List

logger = logging.getLogger(__name__)

# Path to the local Python 3.13 with xpress9/pbixray installed
_PYTHON313_DIR = Path(__file__).resolve().parent.parent / "python313"
_PYTHON313_EXE = _PYTHON313_DIR / "python.exe"
_BRIDGE_SCRIPT = Path(__file__).resolve().parent / "pbixray_bridge.py"


def extract(file_bytes: bytes, filename: str = "") -> Dict[str, List[Dict[str, Any]]]:
    """Extract metadata from a .pbix file.

    Args:
        file_bytes: Raw bytes of the uploaded .pbix file.
        filename: Original filename of the uploaded file.

    Returns:
        Dictionary with keys matching the Excel sheet names and list-of-dict
        values representing the rows for each sheet.
    """
    result: Dict[str, List[Dict[str, Any]]] = {
        "Summary": [],
        "Data_Sources": [],
        "Data_Lineage": [],
        "Relationships": [],
        "Calculated_Fields": [],
        "Worksheets_Dashboards": [],
        "Visual_Layout": [],
        "Custom_SQL": [],
        "Report_Sample_Data": [],
    }

    try:
        with zipfile.ZipFile(io.BytesIO(file_bytes)) as zf:
            file_list = zf.namelist()
            logger.info("PBIX archive contents: %s", file_list)

            # --- DataModelSchema (tables, columns, relationships, measures) ---
            model_json = _read_json(zf, "DataModelSchema")
            has_model_schema = bool(model_json)
            if model_json:
                _parse_data_model(model_json, result)

            # --- Connections (data sources) ---
            conn_json = _read_json(zf, "Connections")
            if conn_json:
                _parse_connections(conn_json, result)

            # --- Report/Layout (pages, visuals, fields) ---
            layout_json = _read_json(zf, "Report/Layout")
            if layout_json:
                _parse_report_layout(layout_json, result)

            # --- DataMashup (Power Query M transformations) ---
            _parse_data_mashup(zf, file_list, result)

        # For newer PBIX format without DataModelSchema, try pbixray
        pbixray_data = _run_pbixray_bridge(file_bytes)
        if not has_model_schema:
            if pbixray_data:
                _parse_pbixray_model(pbixray_data, result)
                if layout_json:
                    _enrich_lineage_from_layout(layout_json, result)
            elif layout_json:
                _extract_model_from_layout(layout_json, result)

        # Extract sample data from pbixray bridge output
        if pbixray_data and pbixray_data.get("sample_data"):
            result["Report_Sample_Data"] = pbixray_data["sample_data"]

    except zipfile.BadZipFile:
        logger.error("The uploaded file is not a valid ZIP / PBIX archive.")
        raise ValueError("The uploaded file is not a valid .pbix archive.")
    except Exception:
        logger.exception("Unexpected error while extracting PBIX metadata.")
        raise

    # --- Post-processing: explode Data_Lineage per-visual rows ---
    _explode_lineage_per_visual(result)

    # --- Post-processing: number Worksheets_Dashboards display order ---
    _number_display_order(result)

    # Build Summary sheet (aligned to Tableau format)
    from datetime import datetime as _dt
    from collections import Counter as _Counter
    conn_counts = _Counter(
        ds.get("Connection Type", "") for ds in result["Data_Sources"]
    )
    ws_count = sum(1 for x in result["Worksheets_Dashboards"] if x.get("Sheet Type") == "Worksheet")
    db_count = sum(1 for x in result["Worksheets_Dashboards"] if x.get("Sheet Type") in ("Dashboard", "Page"))
    summary_rows = [
        {"Property": "Source Platform", "Value": "Power BI (.pbix)"},
        {"Property": "File Name", "Value": filename or "(unknown)"},
        {"Property": "Extraction Datetime", "Value": _dt.now().strftime("%Y-%m-%d %H:%M:%S")},
        {"Property": "Total Worksheets", "Value": ws_count},
        {"Property": "Total Dashboards", "Value": db_count},
        {"Property": "Total Data Sources", "Value": len(result["Data_Sources"])},
    ]
    for ctype, count in sorted(conn_counts.items()):
        label = ctype if ctype else "(no connection type)"
        summary_rows.append({
            "Property": f"Connection Type: {label}",
            "Value": f"{count} data source{'s' if count != 1 else ''}",
        })
    result["Summary"] = summary_rows

    return result


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

def _read_json(zf: zipfile.ZipFile, name: str) -> Any | None:
    """Read and decode a JSON entry from the ZIP, handling BOM."""
    try:
        raw = zf.read(name)
        # Power BI files often have a UTF-16-LE BOM
        for encoding in ("utf-16-le", "utf-8-sig", "utf-8"):
            try:
                text = raw.decode(encoding)
                break
            except (UnicodeDecodeError, UnicodeError):
                continue
        else:
            text = raw.decode("latin-1")
        # Strip null bytes that sometimes trail in PBI files
        text = text.strip().rstrip("\x00")
        return json.loads(text)
    except KeyError:
        return None
    except json.JSONDecodeError:
        logger.warning("Failed to parse JSON from %s", name)
        return None


def _parse_data_model(model: dict, result: dict) -> None:
    """Extract tables, columns, relationships, and measures from DataModelSchema."""
    db = model.get("model", model)

    # Build a set of measure names per table for is-calculated detection
    measures_by_table: dict[str, set[str]] = {}
    for table in db.get("tables", []):
        tname = table.get("name", "Unknown")
        measures_by_table[tname] = {
            m.get("name", "") for m in table.get("measures", [])
        }

    # Tables & Columns
    for table in db.get("tables", []):
        table_name = table.get("name", "Unknown")
        for col in table.get("columns", []):
            col_name = col.get("name", "")
            source_col = col.get("sourceColumn", "")
            result["Data_Lineage"].append({
                "Dashboard Name(s)": "",
                "Worksheet Name(s)": "",
                "Field Display Name": col_name,
                "Field Internal Name": col_name,
                "Field Description": "",
                "Data Source Name": table_name,
                "Source Column": source_col or col_name,
                "Source Table": table_name,
                "Source Schema": "",
                "Source Database": "",
                "Source Server": "",
                "Source Filename": "",
                "Connection Type": "Power BI Model",
                "Data Type": col.get("dataType", ""),
                "Field Role": col.get("dataCategory", ""),
                "Field Classification": "",
                "Default Aggregation": col.get("summarizeBy", ""),
                "Contains Nulls": "",
                "Is Hidden": str(col.get("isHidden", "")).lower() if col.get("isHidden") else "",
                "Is Calculated Field": "No",
                "Calculation Formula": "",
            })

        # Measures (DAX)
        for measure in table.get("measures", []):
            expression = measure.get("expression", "")
            if isinstance(expression, list):
                expression = "\n".join(expression)
            result["Calculated_Fields"].append({
                "Data Source Name": table_name,
                "Measure Name": measure.get("name", ""),
                "Calculation Formula": expression,
                "Calculation Class": "DAX Measure",
                "Field Role": "measure",
                "Format String": measure.get("formatString", ""),
                "Description": measure.get("description", ""),
                "Is Hidden": str(measure.get("isHidden", "")).lower() if measure.get("isHidden") else "",
            })

        # Calculated columns (columns with an expression property)
        for col in table.get("columns", []):
            expr = col.get("expression")
            if expr:
                if isinstance(expr, list):
                    expr = "\n".join(expr)
                result["Calculated_Fields"].append({
                    "Data Source Name": table_name,
                    "Measure Name": col.get("name", ""),
                    "Calculation Formula": expr,
                    "Calculation Class": "Calculated Column",
                    "Field Role": "dimension",
                    "Format String": col.get("formatString", ""),
                    "Description": "",
                    "Is Hidden": str(col.get("isHidden", "")).lower() if col.get("isHidden") else "",
                })
                # Mark this column as calculated in Data_Lineage
                for row in result["Data_Lineage"]:
                    if (row["Data Source Name"] == table_name
                            and row["Field Internal Name"] == col.get("name", "")):
                        row["Is Calculated Field"] = "Yes"
                        row["Calculation Formula"] = expr
                        break

        # Partitions (may surface Power Query M expressions inline)
        for partition in table.get("partitions", []):
            source = partition.get("source", {})
            expr = source.get("expression")
            if expr:
                # Join list expressions into a single string
                if isinstance(expr, list):
                    expr = "\n".join(expr)
                # Record the partition's M expression as a custom SQL entry
                result["Custom_SQL"].append({
                    "Data Source Name": table_name,
                    "Partition": partition.get("name", ""),
                    "Type": source.get("type", ""),
                    "Custom SQL": expr,
                })

    # Relationships
    for rel in db.get("relationships", []):
        # Read join endpoints and cardinality metadata
        from_table = rel.get("fromTable", "")
        from_col = rel.get("fromColumn", "")
        to_table = rel.get("toTable", "")
        to_col = rel.get("toColumn", "")
        from_card = rel.get("fromCardinality", "")
        to_card = rel.get("toCardinality", "")
        cross = rel.get("crossFilteringBehavior", "")
        is_active = rel.get("isActive", True)

        # Build cardinality string
        cardinality = ""
        if from_card or to_card:
            cardinality = f"{from_card or 'many'}-to-{to_card or 'many'}"

        # Build a human-readable join expression
        join_type = _pbi_cardinality_label(from_card or to_card)
        join_expr = (
            f"{from_table} {join_type} JOIN {to_table} "
            f"ON {from_table}.{from_col} = {to_table}.{to_col}"
        )

        # Append the resolved relationship with both endpoints and properties
        result["Relationships"].append({
            "Relationship Expression": join_expr,
            "Relationship Type": join_type,
            "Left Table": from_table,
            "Left Column(s)": from_col,
            "Right Table": to_table,
            "Right Column(s)": to_col,
            "Data Source Name": f"{from_table} ↔ {to_table}",
            "Cardinality": cardinality,
            "Referential Integrity": cross,
            "Is Active": is_active,
        })

    # Data sources embedded in the model
    for ds in db.get("dataSources", []):
        # Parse connection string to extract server and database details
        conn_str = ds.get("connectionString", "")
        result["Data_Sources"].append({
            "Data Source Name": ds.get("name", ""),
            "Connection Type": ds.get("type", ""),
            "Server": _extract_from_conn_string(conn_str, "data source|server"),
            "Port": "",
            "Database": _extract_from_conn_string(conn_str, "initial catalog|database"),
            "Schema": "",
            "Warehouse": "",
            "Filename": "",
            "Authentication": "",
            "Connection String": conn_str,
        })


def _parse_connections(conn_json: dict, result: dict) -> None:
    """Extract data source info from the Connections file."""
    # Normalize connections to a list (may be a dict or list in the JSON)
    connections = conn_json.get("Connections", conn_json.get("connections", []))
    if isinstance(connections, dict):
        connections = [connections]
    for conn in connections:
        # Extract connection string and parse server/database from it
        conn_str = conn.get("ConnectionString", conn.get("connectionString", ""))
        result["Data_Sources"].append({
            "Data Source Name": conn.get("Name", conn.get("name", "")),
            "Connection Type": conn.get("ConnectionType", conn.get("connectionType", "")),
            "Server": _extract_from_conn_string(conn_str, "data source|server"),
            "Port": "",
            "Database": _extract_from_conn_string(conn_str, "initial catalog|database"),
            "Schema": "",
            "Warehouse": "",
            "Filename": "",
            "Authentication": "",
            "Connection String": conn_str,
        })


def _parse_report_layout(layout: dict, result: dict) -> None:
    """Extract report pages, visuals, and field bindings from Report/Layout."""
    # Iterate over each report page section and record layout properties
    sections = layout.get("sections", [])
    for idx, section in enumerate(sections):
        page_name = section.get("displayName", section.get("name", f"Page {idx + 1}"))
        page_width = section.get("width", "")
        page_height = section.get("height", "")
        # Append page-level metadata (name, dimensions, filters)
        result["Worksheets_Dashboards"].append({
            "Sheet Name": page_name,
            "Sheet Type": "Page",
            "Display Order": section.get("ordinal", idx),
            "Width": page_width,
            "Height": page_height,
            "Filters": _safe_json_str(section.get("filters", "")),
        })

        # Visuals within the page
        visual_containers = section.get("visualContainers", [])
        for vc in visual_containers:
            # Parse the visual config JSON to extract type and title
            config = _safe_parse_json(vc.get("config", "{}"))
            single_visual = config.get("singleVisual", config.get("visual", {}))
            visual_type = single_visual.get("visualType", "Unknown")
            visual_title = _get_visual_title(single_visual)
            objects = single_visual.get("objects", {})

            # Extract field projections; fall back to prototypeQuery if empty
            projections = single_visual.get("projections", {})
            protoypes = single_visual.get("prototypeQuery", {})
            field_list = _extract_fields_from_projections(projections)
            if not field_list:
                field_list = _extract_fields_from_prototype(protoypes)

            # Map PBI visual types to mark-type equivalents
            mark_type = _pbi_visual_to_mark(visual_type)

            # Record visual layout details (type, position, dimensions, fields)
            result["Visual_Layout"].append({
                "Sheet Name": page_name,
                "Visual Type": visual_type,
                "Mark Type": mark_type,
                "Title": visual_title,
                "Fields": "; ".join(field_list) if field_list else "",
                "X Position": vc.get("x", ""),
                "Y Position": vc.get("y", ""),
                "Width": vc.get("width", ""),
                "Height": vc.get("height", ""),
            })


def _run_pbixray_bridge(file_bytes: bytes) -> dict | None:
    """Call the pbixray bridge script via local Python 3.13 subprocess.

    Returns the parsed JSON dict on success, or None if the bridge is
    unavailable or fails.
    """
    if not _PYTHON313_EXE.exists() or not _BRIDGE_SCRIPT.exists():
        logger.info("pbixray bridge not available (Python 3.13 not installed locally)")
        return None

    tmp_fd, tmp_path = tempfile.mkstemp(suffix=".pbix")
    try:
        with os.fdopen(tmp_fd, "wb") as f:
            f.write(file_bytes)

        proc = subprocess.run(
            [str(_PYTHON313_EXE), str(_BRIDGE_SCRIPT), tmp_path],
            capture_output=True,
            text=True,
            timeout=120,
        )

        if proc.returncode != 0:
            logger.warning("pbixray bridge failed: %s", proc.stderr[:500])
            return None

        data = json.loads(proc.stdout)
        if "error" in data:
            logger.warning("pbixray bridge error: %s", data["error"])
            return None

        logger.info("pbixray bridge extracted: tables=%s", data.get("tables", []))
        return data

    except (subprocess.TimeoutExpired, json.JSONDecodeError, OSError) as e:
        logger.warning("pbixray bridge exception: %s", e)
        return None
    finally:
        try:
            os.unlink(tmp_path)
        except OSError:
            pass


# Tables whose names look like auto-generated internal PBI objects
_INTERNAL_TABLE_PREFIXES = ("DateTableTemplate_", "LocalDateTable_")


def _is_internal_table(name: str) -> bool:
    return any(name.startswith(p) for p in _INTERNAL_TABLE_PREFIXES)


def _parse_pbixray_model(data: dict, result: dict) -> None:
    """Populate extraction result from pbixray bridge JSON output."""

    # --- Schema → Data_Lineage ---
    for row in data.get("schema", []):
        table_name = row.get("TableName", "")
        if _is_internal_table(table_name):
            continue
        col_name = row.get("ColumnName", "")
        result["Data_Lineage"].append({
            "Dashboard Name(s)": "",
            "Worksheet Name(s)": "",
            "Field Display Name": col_name,
            "Field Internal Name": col_name,
            "Field Description": "",
            "Data Source Name": table_name,
            "Source Column": col_name,
            "Source Table": table_name,
            "Source Schema": "",
            "Source Database": "",
            "Source Server": "",
            "Source Filename": "",
            "Connection Type": "Power BI Model",
            "Data Type": row.get("PandasDataType", ""),
            "Field Role": "dimension",
            "Field Classification": "",
            "Default Aggregation": "",
            "Contains Nulls": "",
            "Is Hidden": "",
            "Is Calculated Field": "No",
            "Calculation Formula": "",
        })

    # --- DAX Measures → Calculated_Fields + Data_Lineage ---
    for row in data.get("dax_measures", []):
        table_name = row.get("TableName", "")
        if _is_internal_table(table_name):
            continue
        measure_name = row.get("Name", "")
        expression = row.get("Expression", "")
        description = row.get("Description", "")
        result["Calculated_Fields"].append({
            "Data Source Name": table_name,
            "Measure Name": measure_name,
            "Calculation Formula": expression,
            "Calculation Class": "DAX Measure",
            "Field Role": "measure",
            "Format String": "",
            "Description": description if description else "",
            "Is Hidden": "",
        })

    # --- DAX Calculated Columns → Calculated_Fields + mark in Data_Lineage ---
    for row in data.get("dax_columns", []):
        table_name = row.get("TableName", "")
        if _is_internal_table(table_name):
            continue
        col_name = row.get("ColumnName", "")
        expression = row.get("Expression", "")
        result["Calculated_Fields"].append({
            "Data Source Name": table_name,
            "Measure Name": col_name,
            "Calculation Formula": expression,
            "Calculation Class": "Calculated Column",
            "Field Role": "dimension",
            "Format String": "",
            "Description": "",
            "Is Hidden": "",
        })
        # Mark the corresponding Data_Lineage row
        for lr in result["Data_Lineage"]:
            if lr["Data Source Name"] == table_name and lr["Field Internal Name"] == col_name:
                lr["Is Calculated Field"] = "Yes"
                lr["Calculation Formula"] = expression
                break

    # --- Relationships ---
    for row in data.get("relationships", []):
        from_table = row.get("FromTableName", "")
        from_col = row.get("FromColumnName", "")
        to_table = row.get("ToTableName", "")
        to_col = row.get("ToColumnName", "")
        if _is_internal_table(from_table) or _is_internal_table(to_table or ""):
            continue
        # Skip auto-date relationships (no real target table)
        if not to_table or not to_col:
            continue
        is_active = bool(row.get("IsActive", 1))
        cardinality = row.get("Cardinality", "")
        cross = row.get("CrossFilteringBehavior", "")
        join_type = _pbi_cardinality_label(cardinality)
        join_expr = (
            f"{from_table} {join_type} JOIN {to_table} "
            f"ON {from_table}.{from_col} = {to_table}.{to_col}"
        )
        result["Relationships"].append({
            "Relationship Expression": join_expr,
            "Relationship Type": join_type,
            "Left Table": from_table,
            "Left Column(s)": from_col,
            "Right Table": to_table,
            "Right Column(s)": to_col,
            "Data Source Name": f"{from_table} ↔ {to_table}",
            "Cardinality": cardinality,
            "Referential Integrity": cross,
            "Is Active": is_active,
        })

    # --- Power Query M → Custom_SQL ---
    for row in data.get("power_query", []):
        table_name = row.get("TableName", "")
        expression = row.get("Expression", "")
        if expression:
            result["Custom_SQL"].append({
                "Data Source Name": table_name,
                "Partition": "DataModel",
                "Type": "M (Power Query)",
                "Custom SQL": expression,
            })

    # --- Data Sources from discovered tables ---
    user_tables = [t for t in data.get("tables", []) if not _is_internal_table(t)]

    # Parse Power Query M to detect actual connection type and filename
    pq_conn_info = _parse_m_connection_info(data.get("power_query", []))
    default_conn = pq_conn_info.get("_default", {})
    global_conn_type = default_conn.get("connection_type", "Power BI Model")
    global_filename = default_conn.get("filename", "")

    # Backfill connection type and filename into Data_Lineage rows
    for row in result["Data_Lineage"]:
        tbl = row["Data Source Name"]
        tbl_info = pq_conn_info.get(tbl, default_conn)
        row["Connection Type"] = tbl_info.get("connection_type", global_conn_type)
        row["Source Filename"] = tbl_info.get("filename", global_filename)

    if not result["Data_Sources"]:
        for table_name in sorted(user_tables):
            tbl_info = pq_conn_info.get(table_name, default_conn)
            result["Data_Sources"].append({
                "Data Source Name": table_name,
                "Connection Type": tbl_info.get("connection_type", global_conn_type),
                "Server": tbl_info.get("server", ""),
                "Port": "",
                "Database": tbl_info.get("database", ""),
                "Schema": "",
                "Warehouse": "",
                "Filename": tbl_info.get("filename", global_filename),
                "Authentication": "",
                "Connection String": "",
            })


def _enrich_lineage_from_layout(layout: dict, result: dict) -> None:
    """Enrich Data_Lineage with visual/worksheet usage info from Report/Layout.

    After pbixray populates the base lineage from the DataModel, this
    function scans the visuals to fill in Worksheet Name(s) and
    Dashboard Name(s) columns, and adds Worksheet entries.
    """
    agg_func_map = {0: "Sum", 1: "Avg", 2: "Count", 3: "Min", 4: "Max", 5: "CountDistinct"}

    # Build lookup: (table, column) → lineage row indices
    lineage_index: dict[tuple[str, str], list[int]] = {}
    for idx, row in enumerate(result["Data_Lineage"]):
        key = (row["Data Source Name"], row["Field Internal Name"])
        lineage_index.setdefault(key, []).append(idx)

    # Build measure lookup: (table, measure_name) → Calculated_Fields entry
    measure_index: dict[tuple[str, str], dict] = {}
    for cf in result["Calculated_Fields"]:
        key = (cf["Data Source Name"], cf["Measure Name"])
        measure_index[key] = cf

    # Track field→visual mappings
    field_visuals: dict[tuple[str, str], list[tuple[str, str]]] = {}  # (table, col) → [(page, visual)]

    for section in layout.get("sections", []):
        page_name = section.get("displayName", section.get("name", ""))
        for vc in section.get("visualContainers", []):
            config = _safe_parse_json(vc.get("config", "{}"))
            sv = config.get("singleVisual", config.get("visual", {}))
            visual_type = sv.get("visualType", "")
            visual_title = _get_visual_title(sv)
            if visual_type in ("textbox", "shape", "image", "actionButton"):
                continue
            visual_label = visual_title or visual_type

            # Extract fields from dataTransforms
            dt = _safe_parse_json(vc.get("dataTransforms", "{}"))
            for sel in dt.get("selects", []):
                expr = sel.get("expr", {})
                entity, prop, _, _ = _resolve_expr(expr, agg_func_map)
                if entity and prop:
                    field_visuals.setdefault((entity, prop), []).append((page_name, visual_label))

            # Also check prototypeQuery
            proto = sv.get("prototypeQuery", {})
            alias_map = {f.get("Name", ""): f.get("Entity", "") for f in proto.get("From", [])}
            for sel in proto.get("Select", []):
                expr = {}
                for expr_key in ("Column", "Measure", "Aggregation"):
                    if expr_key in sel:
                        expr = {expr_key: sel[expr_key]}
                        break
                if expr:
                    entity, prop, _, _ = _resolve_expr(expr, agg_func_map, alias_map=alias_map)
                    if entity and prop:
                        field_visuals.setdefault((entity, prop), []).append((page_name, visual_label))

    # Enrich Data_Lineage rows with worksheet/dashboard usage
    # Also create new lineage rows for measures that aren't in the schema
    pq_conn_info = _parse_m_connection_info(
        [{"TableName": r.get("Data Source Name", ""), "Expression": r.get("Custom SQL", "")}
         for r in result.get("Custom_SQL", [])]
    )
    default_conn = pq_conn_info.get("_default", {})
    global_conn_type = default_conn.get("connection_type", "excel-direct")
    global_filename = default_conn.get("filename", "")

    for (table, col), usages in field_visuals.items():
        indices = lineage_index.get((table, col), [])
        visual_names = sorted(set(v for _, v in usages))
        page_names = sorted(set(p for p, _ in usages))

        if indices:
            for idx in indices:
                result["Data_Lineage"][idx]["Worksheet Name(s)"] = "; ".join(visual_names)
                result["Data_Lineage"][idx]["Dashboard Name(s)"] = "; ".join(page_names)
        else:
            # This field is a measure not in the schema — add a lineage row
            cf = measure_index.get((table, col), {})
            tbl_info = pq_conn_info.get(table, default_conn)
            result["Data_Lineage"].append({
                "Dashboard Name(s)": "; ".join(page_names),
                "Worksheet Name(s)": "; ".join(visual_names),
                "Field Display Name": col,
                "Field Internal Name": col,
                "Field Description": cf.get("Description", ""),
                "Data Source Name": table,
                "Source Column": col,
                "Source Table": table,
                "Source Schema": "",
                "Source Database": "",
                "Source Server": "",
                "Source Filename": tbl_info.get("filename", global_filename),
                "Connection Type": tbl_info.get("connection_type", global_conn_type),
                "Data Type": "",
                "Field Role": "measure",
                "Field Classification": "",
                "Default Aggregation": "",
                "Contains Nulls": "",
                "Is Hidden": "",
                "Is Calculated Field": "Yes",
                "Calculation Formula": cf.get("Calculation Formula", ""),
            })

    # Sort Data_Lineage: used fields first, then by worksheet name
    result["Data_Lineage"].sort(
        key=lambda r: (
            0 if r.get("Worksheet Name(s)", "").strip() else 1,
            r.get("Worksheet Name(s)", "").lower(),
            r.get("Field Display Name", "").lower(),
        )
    )

    # Add visual titles as Worksheet entries
    all_visuals = set()
    for usages in field_visuals.values():
        for page, visual in usages:
            all_visuals.add((page, visual))

    for page_name, visual_name in sorted(all_visuals):
        result["Worksheets_Dashboards"].append({
            "Sheet Name": visual_name,
            "Sheet Type": "Worksheet",
            "Display Order": "",
            "Width": "",
            "Height": "",
            "Filters": "",
        })

    # Change existing Page entries to Dashboard
    for ws in result["Worksheets_Dashboards"]:
        if ws["Sheet Type"] == "Page":
            ws["Sheet Type"] = "Dashboard"


def _extract_model_from_layout(layout: dict, result: dict) -> None:
    """Extract data model info from Report/Layout for newer PBIX files.

    When DataModelSchema is not available (newer format with binary DataModel),
    this function parses visual dataTransforms to recover table, column,
    measure, and data source information from the report visuals.

    Produces one Data_Lineage row per field per visual (matching Tableau's
    per-worksheet style), and also registers each named visual as a
    Worksheet entry under the page's Dashboard entry.
    """
    agg_func_map = {0: "Sum", 1: "Avg", 2: "Count", 3: "Min", 4: "Max", 5: "CountDistinct"}

    # Collect per-visual field usage: list of (page, visual_title, entity, prop, info)
    visual_field_rows: list[dict] = []
    # Track unique fields globally for calculated fields detection
    global_measures: dict[tuple[str, str], dict] = {}
    # Track pages → visual titles for Worksheets_Dashboards
    page_visuals: dict[str, list[str]] = {}
    all_tables: set[str] = set()

    for section in layout.get("sections", []):
        page_name = section.get("displayName", section.get("name", ""))
        page_visuals.setdefault(page_name, [])

        for vc in section.get("visualContainers", []):
            config = _safe_parse_json(vc.get("config", "{}"))
            sv = config.get("singleVisual", config.get("visual", {}))
            visual_type = sv.get("visualType", "")
            visual_title = _get_visual_title(sv)

            # Skip non-data visuals (text boxes, shapes, images)
            if visual_type in ("textbox", "shape", "image", "actionButton"):
                continue

            visual_label = visual_title or visual_type
            page_visuals[page_name].append(visual_label)

            # Collect fields for this visual from dataTransforms.selects
            dt = _safe_parse_json(vc.get("dataTransforms", "{}"))
            visual_fields: list[tuple[str, str, dict]] = []  # (entity, prop, info)

            for sel in dt.get("selects", []):
                display_name = sel.get("displayName", "")
                query_name = sel.get("queryName", "")
                expr = sel.get("expr", {})
                data_type_info = sel.get("type", {})
                underlying_type = data_type_info.get("underlyingType", 0)

                entity, prop, is_measure, agg_func = _resolve_expr(expr, agg_func_map)
                if not entity or not prop:
                    continue

                all_tables.add(entity)
                info = {
                    "display_name": display_name,
                    "query_name": query_name,
                    "underlying_type": underlying_type,
                    "is_measure": is_measure,
                    "agg_func": agg_func,
                }
                visual_fields.append((entity, prop, info))

                if is_measure and (entity, prop) not in global_measures:
                    global_measures[(entity, prop)] = info

            # Also parse prototypeQuery for additional fields
            proto = sv.get("prototypeQuery", {})
            alias_map = {f.get("Name", ""): f.get("Entity", "") for f in proto.get("From", [])}
            for sel in proto.get("Select", []):
                expr = {}
                name = sel.get("Name", "")
                for expr_key in ("Column", "Measure", "Aggregation"):
                    if expr_key in sel:
                        expr = {expr_key: sel[expr_key]}
                        break
                if not expr:
                    continue
                entity, prop, is_measure, agg_func = _resolve_expr(
                    expr, agg_func_map, alias_map=alias_map
                )
                if not entity or not prop:
                    continue
                # Skip if already captured from dataTransforms
                if any(e == entity and p == prop for e, p, _ in visual_fields):
                    continue
                all_tables.add(entity)
                info = {
                    "display_name": prop,
                    "query_name": name,
                    "underlying_type": 0,
                    "is_measure": is_measure,
                    "agg_func": agg_func,
                }
                visual_fields.append((entity, prop, info))
                if is_measure and (entity, prop) not in global_measures:
                    global_measures[(entity, prop)] = info

            # Emit one Data_Lineage row per field per visual
            for entity, prop, info in visual_fields:
                is_measure = info["is_measure"]
                agg_func = info.get("agg_func", "")
                result["Data_Lineage"].append({
                    "Dashboard Name(s)": page_name,
                    "Worksheet Name(s)": visual_label,
                    "Field Display Name": info["display_name"],
                    "Field Internal Name": prop,
                    "Field Description": "",
                    "Data Source Name": entity,
                    "Source Column": prop,
                    "Source Table": entity,
                    "Source Schema": "",
                    "Source Database": "",
                    "Source Server": "",
                    "Source Filename": "",
                    "Connection Type": "Power BI Model",
                    "Data Type": _pbi_type_name(info.get("underlying_type", 0)),
                    "Field Role": "measure" if is_measure else "dimension",
                    "Field Classification": "",
                    "Default Aggregation": agg_func,
                    "Contains Nulls": "",
                    "Is Hidden": "",
                    "Is Calculated Field": "Yes" if is_measure else "No",
                    "Calculation Formula": f"{agg_func}({entity}[{prop}])" if agg_func else "",
                })

    # Sort Data_Lineage by Worksheet Name then Field Display Name
    result["Data_Lineage"].sort(
        key=lambda r: (r.get("Worksheet Name(s)", "").lower(), r.get("Field Display Name", "").lower())
    )

    # Add individual visuals as Worksheet entries (matching Tableau style)
    for page_name, visual_names in page_visuals.items():
        for vname in visual_names:
            result["Worksheets_Dashboards"].append({
                "Sheet Name": vname,
                "Sheet Type": "Worksheet",
                "Display Order": "",
                "Width": "",
                "Height": "",
                "Filters": "",
            })
        # Mark the page itself as a Dashboard
        for ws in result["Worksheets_Dashboards"]:
            if ws["Sheet Name"] == page_name and ws["Sheet Type"] == "Page":
                ws["Sheet Type"] = "Dashboard"
                break

    # Populate Calculated_Fields from collected measures
    for (entity, prop), info in sorted(global_measures.items()):
        agg_func = info.get("agg_func", "")
        result["Calculated_Fields"].append({
            "Data Source Name": entity,
            "Measure Name": info["display_name"],
            "Calculation Formula": f"{agg_func}({entity}[{prop}])" if agg_func else "",
            "Calculation Class": "Aggregation" if agg_func else "DAX Measure",
            "Field Role": "measure",
            "Format String": "",
            "Description": "",
            "Is Hidden": "",
        })

    # Populate Data_Sources from discovered tables (when no Connections found)
    if not result["Data_Sources"]:
        for table_name in sorted(all_tables):
            result["Data_Sources"].append({
                "Data Source Name": table_name,
                "Connection Type": "Power BI Model",
                "Server": "",
                "Port": "",
                "Database": "",
                "Schema": "",
                "Warehouse": "",
                "Filename": "",
                "Authentication": "",
                "Connection String": "",
            })


def _resolve_expr(
    expr: dict,
    agg_func_map: dict,
    alias_map: dict | None = None,
) -> tuple[str, str, bool, str]:
    """Resolve a dataTransform select expression to (entity, property, is_measure, agg_func).

    Handles Column, Measure, Aggregation, and HierarchyLevel expression types.
    """
    entity = ""
    prop = ""
    is_measure = False
    agg_func = ""

    def _resolve_entity(source_ref: dict) -> str:
        """Get entity name from SourceRef, resolving aliases if needed."""
        ent = source_ref.get("Entity", "")
        if ent:
            return ent
        src = source_ref.get("Source", "")
        if src and alias_map:
            return alias_map.get(src, src)
        return src

    # Column expression: expr.Column.Expression.SourceRef + Property
    col = expr.get("Column", {})
    if col:
        inner_expr = col.get("Expression", {})
        source_ref = inner_expr.get("SourceRef", {})
        entity = _resolve_entity(source_ref)
        prop = col.get("Property", "")
        return entity, prop, False, ""

    # Measure expression: expr.Measure.Expression.SourceRef + Property
    meas = expr.get("Measure", {})
    if meas:
        inner_expr = meas.get("Expression", {})
        source_ref = inner_expr.get("SourceRef", {})
        entity = _resolve_entity(source_ref)
        prop = meas.get("Property", "")
        return entity, prop, True, ""

    # Aggregation expression: expr.Aggregation.Expression.Column.Expression.SourceRef + Property
    agg = expr.get("Aggregation", {})
    if agg:
        inner = agg.get("Expression", {})
        col_in_agg = inner.get("Column", {})
        if col_in_agg:
            col_expr = col_in_agg.get("Expression", {})
            source_ref = col_expr.get("SourceRef", {})
            entity = _resolve_entity(source_ref)
            prop = col_in_agg.get("Property", "")
            func_id = agg.get("Function", -1)
            agg_func = agg_func_map.get(func_id, str(func_id))
            return entity, prop, True, agg_func

    # HierarchyLevel: dig into PropertyVariationSource
    hier = expr.get("HierarchyLevel", {})
    if hier:
        h_expr = hier.get("Expression", {})
        hh = h_expr.get("Hierarchy", {})
        pvs = hh.get("Expression", {}).get("PropertyVariationSource", {})
        inner_expr = pvs.get("Expression", {})
        source_ref = inner_expr.get("SourceRef", {})
        entity = _resolve_entity(source_ref)
        prop = pvs.get("Property", hier.get("Level", ""))
        return entity, prop, False, ""

    return entity, prop, is_measure, agg_func


def _pbi_type_name(type_code: int) -> str:
    """Map Power BI underlying type codes to human-readable names."""
    type_map = {
        0: "",
        1: "String",
        259: "Decimal",
        260: "Double",
        517: "DateTime",
        518: "Date",
        519: "Time",
        2048: "String",
        66308: "Integer",
        66564: "Integer",
    }
    return type_map.get(type_code, str(type_code) if type_code else "")


def _parse_data_mashup(zf: zipfile.ZipFile, file_list: list, result: dict) -> None:
    """Extract Power Query M code from DataMashup (nested ZIP)."""
    # Locate the DataMashup entry in the archive (case-insensitive)
    mashup_name = None
    for name in file_list:
        if name.lower() == "datamashup":
            mashup_name = name
            break
    if not mashup_name:
        return

    try:
        mashup_raw = zf.read(mashup_name)
        # DataMashup is a binary blob; the inner ZIP starts at the PK signature
        pk_offset = mashup_raw.find(b"PK")
        if pk_offset == -1:
            logger.warning("No nested ZIP found within DataMashup")
            return

        # Open the nested ZIP from the PK offset to extract M query files
        inner_zip_bytes = mashup_raw[pk_offset:]
        with zipfile.ZipFile(io.BytesIO(inner_zip_bytes)) as inner_zf:
            inner_names = inner_zf.namelist()
            logger.info("DataMashup inner contents: %s", inner_names)

            for inner_name in inner_names:
                # Read .m/.pq files containing Power Query M expressions
                if inner_name.lower().endswith((".m", ".pq", "section1.m")):
                    m_code = inner_zf.read(inner_name).decode("utf-8", errors="replace")
                    # Split section files by shared/let blocks
                    queries = _split_m_queries(m_code)
                    for qname, qexpr in queries:
                        result["Custom_SQL"].append({
                            "Data Source Name": qname,
                            "Partition": "DataMashup",
                            "Type": "M (Power Query)",
                            "Custom SQL": qexpr,
                        })
                elif "formulas" in inner_name.lower() and inner_name.lower().endswith(".xml"):
                    # Some PBI versions store M in Formulas/Section1.m or Formulas XML
                    try:
                        import xml.etree.ElementTree as ET
                        xml_text = inner_zf.read(inner_name).decode("utf-8", errors="replace")
                        root = ET.fromstring(xml_text)
                        # Walk XML tree to find ItemExpression elements with M code
                        for item in root.iter():
                            if "ItemExpression" in (item.tag.split("}")[-1] if "}" in item.tag else item.tag):
                                expr_text = item.text or ""
                                name_elem = item.find(".//{*}ItemName") if item.find(".//{*}ItemName") is not None else None
                                result["Custom_SQL"].append({
                                    "Data Source Name": name_elem.text if name_elem is not None else "Unknown",
                                    "Partition": "DataMashup/Formulas",
                                    "Type": "M (Power Query)",
                                    "Custom SQL": expr_text.strip(),
                                })
                    except Exception:
                        logger.warning("Could not parse M formulas XML: %s", inner_name)
    except Exception:
        logger.warning("Failed to extract DataMashup contents", exc_info=True)


# ---------------------------------------------------------------------------
# Post-processing helpers
# ---------------------------------------------------------------------------

def _explode_lineage_per_visual(result: dict) -> None:
    """Expand Data_Lineage rows so each visual usage becomes a separate row.

    Tableau emits one row per field per worksheet. This function replicates
    that behaviour for PBI by splitting semicolon-separated Worksheet Name(s)
    into individual rows.
    """
    exploded: list[dict] = []
    for row in result["Data_Lineage"]:
        ws_str = row.get("Worksheet Name(s)", "").strip()
        if ws_str and ";" in ws_str:
            for ws_name in ws_str.split(";"):
                ws_name = ws_name.strip()
                if ws_name:
                    new_row = dict(row)
                    new_row["Worksheet Name(s)"] = ws_name
                    exploded.append(new_row)
        else:
            exploded.append(row)

    # Sort: used fields first, then by worksheet name then field name
    exploded.sort(
        key=lambda r: (
            0 if r.get("Worksheet Name(s)", "").strip() else 1,
            r.get("Worksheet Name(s)", "").lower(),
            r.get("Field Display Name", "").lower(),
        )
    )
    result["Data_Lineage"] = exploded


def _number_display_order(result: dict) -> None:
    """Assign sequential Display Order numbers to Worksheets_Dashboards.

    Worksheets get 0-based order; Dashboards get 1000+ (matching Tableau).
    """
    ws_idx = 0
    db_idx = 0
    for entry in result["Worksheets_Dashboards"]:
        if entry.get("Sheet Type") in ("Dashboard", "Page"):
            entry["Display Order"] = 1000 + db_idx
            db_idx += 1
        else:
            entry["Display Order"] = ws_idx
            ws_idx += 1


def _pbi_visual_to_mark(visual_type: str) -> str:
    """Map Power BI visual types to Tableau-style mark types."""
    mapping = {
        "barChart": "Bar",
        "clusteredBarChart": "Bar",
        "stackedBarChart": "Bar",
        "hundredPercentStackedBarChart": "Bar",
        "columnChart": "Bar",
        "clusteredColumnChart": "Bar",
        "stackedColumnChart": "Bar",
        "hundredPercentStackedColumnChart": "Bar",
        "lineChart": "Line",
        "areaChart": "Area",
        "stackedAreaChart": "Area",
        "lineStackedColumnComboChart": "Line",
        "lineClusteredColumnComboChart": "Line",
        "pieChart": "Pie",
        "donutChart": "Pie",
        "treemap": "Square",
        "map": "Map",
        "filledMap": "Map",
        "shapeMap": "Map",
        "scatterChart": "Circle",
        "bubbleChart": "Circle",
        "table": "Text",
        "matrix": "Text",
        "card": "Text",
        "multiRowCard": "Text",
        "kpi": "Text",
        "gauge": "Circle",
        "funnel": "Bar",
        "waterfallChart": "Bar",
        "ribbonChart": "Bar",
        "slicer": "Automatic",
        "textbox": "Text",
    }
    return mapping.get(visual_type, "Automatic")


def _parse_m_connection_info(power_query_rows: list[dict]) -> dict[str, dict]:
    """Parse Power Query M expressions to detect actual connection types.

    Returns a dict keyed by table name with connection details:
      {table: {"connection_type": ..., "filename": ..., "server": ..., "database": ...}}
    Also sets a "_default" key if all tables share the same source.
    """
    # M function → connection type mapping
    _M_SOURCE_PATTERNS = [
        (r"Excel\.Workbook\s*\(", "excel-direct"),
        (r"Csv\.Document\s*\(", "csv"),
        (r"Sql\.Database\s*\(", "sqlserver"),
        (r"Sql\.Databases\s*\(", "sqlserver"),
        (r"Oracle\.Database\s*\(", "oracle"),
        (r"Odbc\.DataSource\s*\(", "odbc"),
        (r"OleDb\.DataSource\s*\(", "oledb"),
        (r"Snowflake\.Databases\s*\(", "snowflake"),
        (r"GoogleBigQuery\.Database\s*\(", "bigquery"),
        (r"AmazonRedshift\.Database\s*\(", "redshift"),
        (r"PostgreSQL\.Database\s*\(", "postgres"),
        (r"MySQL\.Database\s*\(", "mysql"),
        (r"Folder\.Files\s*\(", "folder"),
        (r"SharePoint\.", "sharepoint"),
        (r"Web\.Contents\s*\(", "web"),
        (r"OData\.Feed\s*\(", "odata"),
        (r"Json\.Document\s*\(", "json"),
        (r"Xml\.Document\s*\(", "xml"),
    ]

    result: dict[str, dict] = {}

    for row in power_query_rows:
        table_name = row.get("TableName", "")
        expr = row.get("Expression", "")
        if not expr:
            continue

        info: dict[str, str] = {"connection_type": "Power BI Model", "filename": "", "server": "", "database": ""}

        # Detect connection type from M function calls
        for pattern, conn_type in _M_SOURCE_PATTERNS:
            if re.search(pattern, expr):
                info["connection_type"] = conn_type
                break

        # Extract filename from File.Contents("path") or parameter references
        file_match = re.search(r'File\.Contents\s*\(\s*"([^"]+)"', expr)
        if file_match:
            info["filename"] = file_match.group(1)
        else:
            # Parameter-based path: File.Contents(SomePath)
            param_match = re.search(r'File\.Contents\s*\(\s*(\w+)\s*\)', expr)
            if param_match:
                info["filename"] = f"(parameter: {param_match.group(1)})"

        # Extract server from Sql.Database("server", "db")
        sql_match = re.search(r'Sql\.Database\s*\(\s*"([^"]+)"\s*,\s*"([^"]+)"', expr)
        if sql_match:
            info["server"] = sql_match.group(1)
            info["database"] = sql_match.group(2)

        result[table_name] = info

    # Set a default if all tables share the same connection type
    if result:
        conn_types = set(v["connection_type"] for v in result.values())
        filenames = set(v["filename"] for v in result.values())
        first = next(iter(result.values()))
        if len(conn_types) == 1:
            result["_default"] = dict(first)
        else:
            result["_default"] = {"connection_type": "Power BI Model", "filename": "", "server": "", "database": ""}

    return result


# ---------------------------------------------------------------------------
# Utility helpers
# ---------------------------------------------------------------------------

def _pbi_cardinality_label(cardinality: str) -> str:
    """Map Power BI cardinality values to a SQL-style join keyword."""
    mapping = {
        "many":         "INNER",
        "one":          "INNER",
        "manyToMany":   "MANY-TO-MANY",
        "manyToOne":    "MANY-TO-ONE",
        "oneToMany":    "ONE-TO-MANY",
        "oneToOne":     "ONE-TO-ONE",
    }
    return mapping.get(cardinality, "INNER")

def _extract_from_conn_string(conn_str: str, keys: str) -> str:
    """Pull a value from a semicolon-delimited connection string by key alternatives."""
    if not conn_str:
        return ""
    for key in keys.split("|"):
        pattern = rf"{re.escape(key)}\s*=\s*([^;]+)"
        match = re.search(pattern, conn_str, re.IGNORECASE)
        if match:
            return match.group(1).strip()
    return ""


def _safe_parse_json(text: str | dict) -> dict:
    """Parse JSON text that might already be a dict or might be a string."""
    if isinstance(text, dict):
        return text
    if isinstance(text, list):
        return {"items": text}
    try:
        return json.loads(text) if text else {}
    except (json.JSONDecodeError, TypeError):
        return {}


def _safe_json_str(obj: Any) -> str:
    """Serialize an object to a JSON string for display, handling pre-serialized strings."""
    if isinstance(obj, str):
        return obj
    try:
        return json.dumps(obj, ensure_ascii=False, default=str)
    except Exception:
        return str(obj)


def _get_visual_title(single_visual: dict) -> str:
    """Try to extract a human-readable title from the visual config."""
    try:
        # Traverse the nested config hierarchy to reach the title literal value
        title_obj = (
            single_visual
            .get("vcObjects", {})
            .get("title", [{}])[0]
            .get("properties", {})
            .get("text", {})
            .get("expr", {})
            .get("Literal", {})
            .get("Value", "")
        )
        # Strip surrounding quotes from the resolved title string
        if title_obj:
            return str(title_obj).strip("'\"")
    except (IndexError, KeyError, TypeError):
        pass
    return ""


def _extract_fields_from_projections(projections: dict) -> List[str]:
    """Extract field names from the projections dict of a visual."""
    fields = []
    if not projections:
        return fields
    # Each role (e.g. Category, Values) maps to a list of field bindings
    for _role, bindings in projections.items():
        if isinstance(bindings, list):
            for binding in bindings:
                # Bindings can be dicts with queryRef or plain strings
                if isinstance(binding, dict):
                    qref = binding.get("queryRef", "")
                    if qref:
                        fields.append(qref)
                elif isinstance(binding, str):
                    fields.append(binding)
    return fields


def _extract_fields_from_prototype(proto: dict) -> List[str]:
    """Fallback field extraction from prototypeQuery Select items."""
    fields = []
    if not proto:
        return fields
    # Iterate over Select items to extract field names or column references
    for sel in proto.get("Select", []):
        name = sel.get("Name", "")
        if name:
            fields.append(name)
        # Nested column reference: resolve Entity.Property from SourceRef
        col = sel.get("Column", {})
        if col:
            src = col.get("Expression", {}).get("SourceRef", {}).get("Entity", "")
            prop = col.get("Property", "")
            if src and prop:
                fields.append(f"{src}.{prop}")
    return fields


def _split_m_queries(m_code: str) -> List[tuple]:
    """Split a combined Section1.m file into individual named queries."""
    queries = []
    # Pattern: shared <Name> = <expression>;
    # M language uses #"Name With Spaces" for identifiers with special chars
    pattern = r'shared\s+(#"[^"]+"|[\w.]+)\s*=\s*'
    # Split on shared definitions; result alternates between names and bodies
    parts = re.split(pattern, m_code)
    if len(parts) >= 3:
        # parts[0] = preamble, then alternating name/expression
        for i in range(1, len(parts), 2):
            qname = parts[i].strip().strip('"').lstrip('#')
            qexpr = parts[i + 1].rstrip(";").strip() if i + 1 < len(parts) else ""
            queries.append((qname, qexpr))
    else:
        # Fallback: try let...in blocks when no shared definitions exist
        let_blocks = re.findall(r"(let\b.*?in\b.*?)(?=\blet\b|$)", m_code, re.DOTALL | re.IGNORECASE)
        for idx, block in enumerate(let_blocks):
            queries.append((f"Query_{idx + 1}", block.strip()))

    # If no queries were parsed, treat the entire script as one query
    if not queries and m_code.strip():
        queries.append(("Full M Script", m_code.strip()))

    return queries
