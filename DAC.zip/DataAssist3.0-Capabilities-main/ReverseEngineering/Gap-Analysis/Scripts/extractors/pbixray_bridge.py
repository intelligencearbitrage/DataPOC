"""Bridge script: Extract DataModel from a PBIX file using pbixray.

Called by the main PBIX extractor via subprocess when the DataModel is in
the newer binary XPress9 compressed format.  Requires Python 3.13 with
xpress9 and pbixray installed.

Usage:
    python313/python.exe extractors/pbixray_bridge.py <pbix_file_path>

Outputs JSON to stdout with keys: schema, relationships, dax_measures,
dax_columns, power_query, tables, metadata.
"""
import json
import sys

import pandas as pd


def _df_to_records(df: pd.DataFrame) -> list[dict]:
    """Convert a DataFrame to a list of dicts, handling NaN/NaT."""
    if df is None or df.empty:
        return []
    # Replace NaN/NaT with None for clean JSON serialization
    return json.loads(df.fillna("").to_json(orient="records", date_format="iso"))


def main():
    if len(sys.argv) < 2:
        print(json.dumps({"error": "Usage: pbixray_bridge.py <pbix_path>"}))
        sys.exit(1)

    pbix_path = sys.argv[1]

    try:
        from pbixray import PBIXRay

        model = PBIXRay(pbix_path)

        result = {
            "tables": list(model.tables) if model.tables is not None else [],
            "schema": _df_to_records(model.schema),
            "relationships": _df_to_records(model.relationships),
            "dax_measures": _df_to_records(model.dax_measures),
            "dax_columns": _df_to_records(model.dax_columns),
            "power_query": _df_to_records(model.power_query),
            "metadata": _df_to_records(model.metadata),
        }

        # Extract sample data (first 100 rows) from each user table
        MAX_SAMPLE_ROWS = 100
        sample_rows: list[dict] = []
        for tbl_name in result["tables"]:
            if tbl_name.startswith(("DateTableTemplate_", "LocalDateTable_")):
                continue
            try:
                df = model.get_table(tbl_name)
                if df is not None and not df.empty:
                    chunk = df.head(MAX_SAMPLE_ROWS)
                    for rec in _df_to_records(chunk):
                        rec["__source_table__"] = tbl_name
                        sample_rows.append(rec)
            except Exception:
                pass
        result["sample_data"] = sample_rows

        print(json.dumps(result, ensure_ascii=False))

    except Exception as e:
        print(json.dumps({"error": str(e)}))
        sys.exit(1)


if __name__ == "__main__":
    main()
