"""
Tableau Packaged Workbook (.twbx) metadata extractor.

A .twbx file is a ZIP archive containing:
  - A .twb file (Tableau Workbook): XML with all metadata
  - Optional .hyper / .tde data extract files
  - Optional external files (images, etc.)

The .twb XML structure includes:
  <datasources>   – data source and connection definitions
  <worksheets>    – individual sheet definitions
  <dashboards>    – dashboard layouts
  <windows>       – window ordering
  Calculated fields live inside <column> elements with a <calculation> child.
  Column-level data lineage traces each Tableau field back to its source.
"""

import io
import logging
import re


# Patterns for Tableau system/internal identifiers – skip entire row
_INTERNAL_JUNK_RE = re.compile(
    r"^__tableau_.*__$"           # e.g. __tableau_internal_object_id__
    r"|_[0-9A-Fa-f]{20,}$"       # e.g.  Commission.csv_4F66D485F1F148A299B285539B88B015
    r"|^:",                       # e.g. :Measure Names, :Measure Values
)


def _is_tableau_system_name(value: str) -> bool:
    """Return True if *value* looks like a Tableau system identifier."""
    return bool(_INTERNAL_JUNK_RE.search(value))
import xml.etree.ElementTree as ET
import zipfile
from typing import Any, Dict, List

logger = logging.getLogger(__name__)

# Ensure debug output is visible even when running under Flask
if not logger.handlers:
    logging.basicConfig(level=logging.WARNING)

# Tableau internal field name prefixes that should be excluded from data lineage
_EXCLUDED_FIELD_PREFIXES = ("Action (", "Tooltip (")

# Auto-generated calculation names (e.g. "Calculation_5144658905056067585")
_CALC_PREFIX = "Calculation_"


def _is_excluded_field(name: str, caption: str = "") -> bool:
    """Return True if the field should be excluded from data lineage.

    Excludes Tableau Action/Tooltip set fields and unnamed ad-hoc
    calculations (Calculation_NNNNN) that are not real data columns.
    Named calculated fields (those with a user-assigned caption) are kept.
    """
    if name.startswith(_EXCLUDED_FIELD_PREFIXES):
        return True
    if name.startswith(_CALC_PREFIX) and name[len(_CALC_PREFIX):].isdigit():
        # Keep the field if it has a meaningful user-assigned caption
        if caption and caption != name:
            return False
        return True
    return False


def extract(file_bytes: bytes, filename: str = "") -> Dict[str, List[Dict[str, Any]]]:
    """Extract metadata from a .twbx file.

    Args:
        file_bytes: Raw bytes of the uploaded .twbx file.
        filename: Original filename of the uploaded file.

    Returns:
        Dictionary keyed by Excel sheet name with list-of-dict row values.
    """
    result: Dict[str, List[Dict[str, Any]]] = {
        "Summary": [],
        "Data_Sources": [],
        "Data_Lineage": [],
        "Relationships": [],
        "Calculated_Fields": [],
        "Worksheets_Dashboards": [],
        "Visual_Layout": [],
        "Custom_SQL": [],
        "Report_Sample_Data": [],
    }

    try:
        with zipfile.ZipFile(io.BytesIO(file_bytes)) as zf:
            file_list = zf.namelist()
            logger.info("TWBX archive contents: %s", file_list)

            # Locate the .twb file inside the archive
            twb_name = _find_twb(file_list)
            if not twb_name:
                raise ValueError("No .twb workbook file found inside the .twbx archive.")

            twb_xml = zf.read(twb_name).decode("utf-8", errors="replace")
            root = ET.fromstring(twb_xml)

            # Pre-scan worksheets to know where each field is used
            field_usage_map = _build_field_usage_map(root)

            _parse_datasources(root, result, field_usage_map)
            _parse_worksheets(root, result)
            _parse_dashboards(root, result)

            # Build worksheet → dashboard(s) mapping from parsed data
            ws_to_dashboards: dict[str, set[str]] = {}
            dashboards_node = root.find(".//dashboards")
            if dashboards_node is not None:
                for db in dashboards_node.findall("dashboard"):
                    db_name = db.get("name", "")
                    if not db_name:
                        continue
                    # Scan each zone for sheet references to map worksheets to dashboards
                    for zone in db.findall(".//zone"):
                        zone_param = zone.get("param", "")
                        zone_name = zone.get("name", "")
                        sheet_ref = zone_param or zone_name
                        if sheet_ref and not sheet_ref.startswith("[") and sheet_ref not in ("horz", "vert"):
                            ws_to_dashboards.setdefault(sheet_ref, set()).add(db_name)

            # Explode Data_Lineage rows: one row per worksheet name instead of
            # semicolon-separated "Worksheet Name(s)".
            exploded: list[dict] = []
            for row in result["Data_Lineage"]:
                ws_str = row.get("Worksheet Name(s)", "").strip()
                if ws_str:
                    # Split semicolon-separated worksheet names into individual rows
                    for ws_name in ws_str.split(";"):
                        ws_name = ws_name.strip()
                        if ws_name:
                            # Look up which dashboards contain this worksheet
                            dbs = ws_to_dashboards.get(ws_name, set())
                            exploded.append({
                                **row,
                                "Worksheet Name(s)": ws_name,
                                "Dashboard Name(s)": "; ".join(sorted(dbs)) if dbs else "",
                            })
                else:
                    exploded.append({**row, "Dashboard Name(s)": ""})
            result["Data_Lineage"] = exploded

            # Sort by Worksheet Name(s) then Field Display Name;
            # blank worksheet names go to the end.
            result["Data_Lineage"].sort(
                key=lambda r: (
                    0 if r.get("Worksheet Name(s)", "").strip() else 1,
                    r.get("Worksheet Name(s)", "").lower(),
                    r.get("Field Display Name", "").lower(),
                )
            )

            # Build Summary sheet with high-level workbook statistics
            from datetime import datetime as _dt
            from collections import Counter as _Counter
            # Count data sources by connection type for the summary breakdown
            conn_counts = _Counter(
                ds.get("Connection Type", "") for ds in result["Data_Sources"]
            )
            # Assemble summary rows: file info, timestamp, and object counts
            summary_rows = [
                {"Property": "Source Platform", "Value": "Tableau (.twbx)"},
                {"Property": "File Name", "Value": filename or "(unknown)"},
                {"Property": "Internal Workbook", "Value": twb_name},
                {"Property": "Extraction Datetime", "Value": _dt.now().strftime("%Y-%m-%d %H:%M:%S")},
                {"Property": "Total Worksheets", "Value": sum(1 for x in result["Worksheets_Dashboards"] if x.get("Sheet Type") == "Worksheet")},
                {"Property": "Total Dashboards", "Value": sum(1 for x in result["Worksheets_Dashboards"] if x.get("Sheet Type") == "Dashboard")},
                {"Property": "Total Data Sources", "Value": len(result["Data_Sources"])},
            ]
            for ctype, count in sorted(conn_counts.items()):
                label = ctype if ctype else "(no connection type)"
                summary_rows.append({
                    "Property": f"Connection Type: {label}",
                    "Value": f"{count} data source{'s' if count != 1 else ''}",
                })
            result["Summary"] = summary_rows

            # --- Extract sample data from embedded data files ---
            result["Report_Sample_Data"] = _extract_sample_data(zf, file_list)

    except zipfile.BadZipFile:
        logger.error("The uploaded file is not a valid ZIP / TWBX archive.")
        raise ValueError("The uploaded file is not a valid .twbx archive.")
    except ET.ParseError:
        logger.error("Failed to parse the .twb XML inside the archive.")
        raise ValueError("The .twb file inside the archive contains invalid XML.")
    except Exception:
        logger.exception("Unexpected error while extracting TWBX metadata.")
        raise

    return result


# ---------------------------------------------------------------------------
# Internal parsers
# ---------------------------------------------------------------------------

def _find_twb(file_list: List[str]) -> str | None:
    """Return the first .twb filename found in the archive listing."""
    for name in file_list:
        if name.lower().endswith(".twb"):
            return name
    return None


# Supported data file extensions inside a TWBX (ordered by preference)
_DATA_EXTENSIONS = (".xlsx", ".xls", ".csv")
_MAX_SAMPLE_ROWS = 100


def _extract_sample_data(zf: zipfile.ZipFile, file_list: List[str]) -> List[Dict[str, Any]]:
    """Extract sample data (first N rows) from embedded data files in the TWBX.

    Supports .xlsx, .xls, and .csv files packaged inside the archive.
    Returns a flat list of row dicts suitable for the Sample_Data sheet.
    """
    import pandas as pd

    sample_rows: List[Dict[str, Any]] = []

    # Collect candidate data files (skip the .twb itself)
    data_files = [
        name for name in file_list
        if any(name.lower().endswith(ext) for ext in _DATA_EXTENSIONS)
    ]

    if not data_files:
        logger.info("No embedded data files found in TWBX for sample extraction.")
        return sample_rows

    for data_file in data_files:
        try:
            raw = zf.read(data_file)
            file_lower = data_file.lower()
            source_label = data_file.rsplit("/", 1)[-1] if "/" in data_file else data_file
            dfs: Dict[str, Any] = {}

            if file_lower.endswith(".xlsx"):
                dfs = pd.read_excel(
                    io.BytesIO(raw), sheet_name=None, engine="openpyxl",
                    nrows=_MAX_SAMPLE_ROWS,
                )
            elif file_lower.endswith(".xls"):
                dfs = pd.read_excel(
                    io.BytesIO(raw), sheet_name=None, engine="xlrd",
                    nrows=_MAX_SAMPLE_ROWS,
                )
            elif file_lower.endswith(".csv"):
                df = pd.read_csv(io.BytesIO(raw), nrows=_MAX_SAMPLE_ROWS)
                dfs = {source_label: df}

            for sheet_name, df in dfs.items():
                # Convert timestamps to strings for Excel safety
                for col in df.select_dtypes(include=["datetime", "datetimetz"]).columns:
                    df[col] = df[col].dt.strftime("%Y-%m-%d %H:%M:%S")
                df = df.fillna("")
                for rec in df.to_dict(orient="records"):
                    rec["__source_file__"] = source_label
                    rec["__sheet_name__"] = str(sheet_name)
                    sample_rows.append(rec)

        except Exception as exc:
            logger.warning("Could not read data file '%s': %s", data_file, exc)
            continue

    logger.info("Extracted %d sample data rows from TWBX embedded files.", len(sample_rows))
    return sample_rows


def _build_field_usage_map(root: ET.Element) -> dict:
    """Pre-scan worksheets to build a map: datasource_name → col_name → {sheets, shelves, caption}.

    This tells us *where* each field is used and *how* it is displayed in
    the Tableau report (e.g. Rows shelf, Columns shelf, Color encoding,
    Detail, Filter, etc.).
    """
    usage: dict[str, dict[str, dict]] = {}  # ds_name → col_name → info

    worksheets = root.find(".//worksheets")
    if worksheets is None:
        return usage

    for ws in worksheets.findall("worksheet"):
        ws_name = ws.get("name", "")

        # --- Fields from <datasource-dependencies> in each worksheet ---
        for dep in ws.findall(".//datasource-dependencies"):
            ds_ref = dep.get("datasource", "")
            if ds_ref not in usage:
                usage[ds_ref] = {}
            # Register each column's usage in this worksheet
            for col in dep.findall("column"):
                col_name = col.get("name", "").strip("[]")
                if not col_name:
                    continue
                if _is_excluded_field(col_name, col.get("caption", "")):
                    continue
                # Initialize usage entry if this is the first occurrence
                if col_name not in usage[ds_ref]:
                    usage[ds_ref][col_name] = {
                        "sheets": set(),
                        "shelves": set(),
                        "caption": col.get("caption", col_name),
                    }
                usage[ds_ref][col_name]["sheets"].add(ws_name)
            # Also capture <column-instance> elements which reference fields
            # Track column-instance references (aggregated field usages)
            for ci in dep.findall("column-instance"):
                ci_col = ci.get("column", "").strip("[]")
                if not ci_col:
                    continue
                if _is_excluded_field(ci_col):
                    continue
                if ci_col not in usage[ds_ref]:
                    usage[ds_ref][ci_col] = {
                        "sheets": set(),
                        "shelves": set(),
                        "caption": ci_col,
                    }
                usage[ds_ref][ci_col]["sheets"].add(ws_name)

        # --- Fields used on specific shelves (rows, columns, pages) ---
        for shelf_name in ("rows", "columns", "pages"):
            shelf = ws.find(f"./table/view/{shelf_name}")
            if shelf is None:
                shelf = ws.find(f"./{shelf_name}")
            if shelf is not None and shelf.text:
                # e.g. "[datasource].[field:col:ok]" or "[col]"
                refs = re.findall(r'\[([^\]]+)\]\.\[([^\]]+)\]', shelf.text)
                for ds_ref, field_ref in refs:
                    # Normalize field reference (strip "field:" prefix etc.)
                    field_name = re.sub(r'^[a-z]+:', '', field_ref).rstrip(":ok").rstrip(":qk").rstrip(":nk")
                    if ds_ref not in usage:
                        usage[ds_ref] = {}
                    # Initialize usage entry and record which shelf uses this field
                    if field_name not in usage[ds_ref]:
                        usage[ds_ref][field_name] = {
                            "sheets": set(),
                            "shelves": set(),
                            "caption": field_name,
                        }
                    usage[ds_ref][field_name]["sheets"].add(ws_name)
                    usage[ds_ref][field_name]["shelves"].add(f"{shelf_name.capitalize()} shelf")

        # --- Encoding shelves (color, size, shape, label, detail, tooltip, etc.)
        for enc in ws.findall(".//encoding"):
            enc_attr = enc.get("attr", "")  # e.g. "color", "size"
            enc_col = enc.get("column", "")
            enc_type = enc.get("type", "")
            if enc_col:
                # Parse the field reference and register its encoding shelf usage
                ds_ref, field_name = _parse_field_ref(enc_col)
                if ds_ref and field_name:
                    if ds_ref not in usage:
                        usage[ds_ref] = {}
                    if field_name not in usage[ds_ref]:
                        usage[ds_ref][field_name] = {
                            "sheets": set(),
                            "shelves": set(),
                            "caption": field_name,
                        }
                    usage[ds_ref][field_name]["sheets"].add(ws_name)
                    shelf_label = f"{enc_attr.capitalize()} encoding" if enc_attr else "Encoding"
                    usage[ds_ref][field_name]["shelves"].add(shelf_label)

        # --- Filters ---
        for filt in ws.findall(".//filter"):
            filt_col = filt.get("column", "")
            if filt_col:
                # Parse the filter field reference and mark it as used in a filter
                ds_ref, field_name = _parse_field_ref(filt_col)
                if ds_ref and field_name:
                    if ds_ref not in usage:
                        usage[ds_ref] = {}
                    if field_name not in usage[ds_ref]:
                        usage[ds_ref][field_name] = {
                            "sheets": set(),
                            "shelves": set(),
                            "caption": field_name,
                        }
                    usage[ds_ref][field_name]["sheets"].add(ws_name)
                    usage[ds_ref][field_name]["shelves"].add("Filter")

    return usage


def _parse_datasources(root: ET.Element, result: dict,
                       field_usage_map: dict) -> None:
    """Extract data sources, tables, columns, relationships, calcs, and custom SQL."""
    datasources = root.find(".//datasources")
    if datasources is None:
        return

    for ds in datasources.findall("datasource"):
        ds_name = ds.get("name", "") or ds.get("caption", "Unknown")
        ds_caption = ds.get("caption", ds_name)

        # --- Connections ---
        # A datasource may have a top-level <connection> that wraps
        # <named-connection> children containing the real connection.
        # Only parse named-connections when they exist; fall back to the
        # top-level <connection> otherwise, to avoid duplicate rows.
        connection = ds.find("connection")
        named_conns = ds.findall(".//named-connection")
        if named_conns:
            for nc in named_conns:
                nc_conn = nc.find("connection")
                if nc_conn is not None:
                    _parse_connection_element(nc_conn, ds_caption, result)
        else:
            if connection is not None:
                _parse_connection_element(connection, ds_caption, result)

        # --- Build metadata lookup: local-name → (remote-name, source-table, ...) ---
        # Real Tableau files use compound keys like "[Extract].[OrderID]" or
        # "[TableName].[ColumnName]".  We build both the raw-key map AND a
        # column-only lookup so that columns defined with simple names like
        # "[OrderID]" still resolve.
        metadata_map: dict[str, dict] = {}      # raw local-name → info
        metadata_col_map: dict[str, dict] = {}   # column-name-only → info (fallback)
        for mr in ds.findall(".//metadata-record"):
            if mr.get("class") == "column":
                # Extract all metadata fields for this column record
                local_name = mr.findtext("local-name", "")
                remote_name = mr.findtext("remote-name", "")
                parent = mr.findtext("parent-name", "")
                local_type = mr.findtext("local-type", "")
                remote_type = mr.findtext("remote-type", "")
                remote_alias = mr.findtext("remote-alias", "")
                contains_null = mr.findtext("contains-null", "")
                ordinal = mr.findtext("ordinal", "")
                agg = mr.findtext("aggregation", "")
                approx_count = mr.findtext("approx-count", "")
                # Build a metadata dict for this column's physical mapping
                rec = {
                    "remote_name": remote_name,
                    "remote_alias": remote_alias,
                    "source_table": _strip_brackets(parent) if parent else "",
                    "local_type": local_type,
                    "remote_type": remote_type,
                    "contains_null": contains_null,
                    "ordinal": ordinal,
                    "aggregation": agg,
                    "approx_count": approx_count,
                }
                metadata_map[local_name] = rec
                # Secondary lookup by column-name-only part:
                # "[Extract].[OrderID]" → key "OrderID"
                # "[OrderID]"           → key "OrderID"
                col_only = _extract_col_part(local_name)
                if col_only:
                    metadata_col_map[col_only] = rec

        # --- Build column-description lookup from ALL <column> elements ---
        col_desc_map: dict[str, str] = {}
        for col in ds.findall(".//column"):
            col_name = col.get("name", "").strip("[]")
            # Check both the attribute and child <desc> element for descriptions
            desc = col.get("description", "")
            if not desc:
                desc_elem = col.find("desc")
                if desc_elem is not None:
                    desc = _element_text(desc_elem)
            if desc:
                col_desc_map[col_name] = desc.strip()

        # --- Collect relation/table names from nested <relation> elements ---
        source_tables: dict[str, str] = {}  # relation name → table attr (brackets stripped)
        for relation in ds.findall(".//relation"):
            rname = relation.get("name", "")
            rtable = relation.get("table", "")
            if rname and rtable:
                # Strip all bracket pairs to normalize table identifiers
                source_tables[rname] = rtable.replace("[", "").replace("]", "")

        # --- Build a caption map from <object-graph> objects ---
        # In the new logical model, each <object> has a human-friendly
        # caption (e.g. "Orders", "Sales Target") and an inner <relation>
        # whose name is the raw table reference (e.g. "Sheet1").  We map
        # both the relation name and the raw table value to the caption
        # so that "Sheet1$" becomes "Sales Target" in the output.
        table_caption_map: dict[str, str] = {}  # raw name/table → caption
        for obj in ds.findall(".//{*}object"):
            obj_caption = obj.get("caption", "")
            if not obj_caption:
                continue
            # Map both the inner relation name and table value to the friendly caption
            for inner_rel in obj.findall(".//{*}relation"):
                rel_name = inner_rel.get("name", "")
                rel_table = inner_rel.get("table", "").replace("[", "").replace("]", "")
                if rel_name:
                    table_caption_map[rel_name] = obj_caption
                if rel_table:
                    table_caption_map[rel_table] = obj_caption

        # --- Parse <cols> map from inside <connection> ---
        # The <cols> map is the authoritative logical→physical column
        # mapping.  Each entry is:
        #   <map key="[LogicalName]" value="[PhysicalTable].[PhysicalCol]" />
        # This gives us:
        #  1. Columns that have NO <column> element (physical-only fields)
        #  2. Correct source table for EVERY column (not just join columns)
        cols_map: dict[str, dict] = {}  # logical_col_name → {table, column}
        cols_elem = ds.find(".//cols")
        if cols_elem is not None:
            # Parse each <map> entry to extract logical-to-physical column mappings
            for m in cols_elem.findall("map"):
                key = _strip_brackets(m.get("key", ""))
                value = m.get("value", "")
                # value is like "[TableName].[ColumnName]"
                parts = re.findall(r'\[([^\]]+)\]', value)
                if len(parts) == 2:
                    cols_map[key] = {"table": parts[0], "column": parts[1]}
                elif len(parts) == 1:
                    cols_map[key] = {"table": "", "column": parts[0]}

        # --- Build column → table mapping from join clauses ---
        # For datasources without metadata records (e.g. MS Access), this
        # is the only way to know which table a column belongs to.
        col_to_table: dict[str, str] = {}
        # Get default table from <connection tablename="..."> or first table relation
        default_table = ""
        if connection is not None:
            default_table = connection.get("tablename", "")
        if not default_table:
            # Use the first table relation as default
            for relation in ds.findall(".//relation"):
                if (relation.get("type", "") == "table" and relation.get("name", "")):
                    default_table = relation.get("name", "")
                    break
        # Walk join clauses to map column names to their table
        for join_rel in ds.findall(".//relation"):
            if (join_rel.get("type") or "").lower() != "join":
                continue
            # Resolve left and right table names from child relation elements
            children = join_rel.findall("relation")
            left_name = _resolve_relation_name(children[0]) if len(children) >= 1 else ""
            right_name = _resolve_relation_name(children[1]) if len(children) >= 2 else ""
            # Extract column names from each clause and assign to their table
            for clause in join_rel.findall("clause"):
                lc, rc = _parse_clause(clause)
                if lc and left_name:
                    col_to_table[lc] = left_name
                if rc and right_name:
                    col_to_table[rc] = right_name

        # --- Build connection info for lineage context ---
        conn_info = _get_connection_info(ds)

        # For file-based connections, server and database hold the file path
        # which is already captured in the Data_Sources "Filename" column.
        # Blank them out so they don't appear misleadingly in Data_Lineage.
        _FILE_CONN_CLASSES = {
            "textscan", "excel-direct", "msaccess", "dataengine",
            "hyper", "firebird", "textclean", "csv", "excel",
        }
        if conn_info.get("class", "").lower() in _FILE_CONN_CLASSES:
            conn_info["_filename"] = conn_info["server"] or conn_info["database"]
            conn_info["server"] = ""
            conn_info["database"] = ""
        else:
            conn_info["_filename"] = ""

        # === DEBUG: dump what we found ===
        logger.warning("[DEBUG] datasource name=%r  caption=%r", ds_name, ds_caption)
        logger.warning("[DEBUG] metadata_map keys (%d): %s", len(metadata_map), list(metadata_map.keys())[:30])
        logger.warning("[DEBUG] metadata_col_map keys (%d): %s", len(metadata_col_map), list(metadata_col_map.keys())[:30])
        logger.warning("[DEBUG] source_tables map (%d): %s", len(source_tables), dict(list(source_tables.items())[:15]))
        logger.warning("[DEBUG] cols_map (%d): %s", len(cols_map), dict(list(cols_map.items())[:30]))
        logger.warning("[DEBUG] conn_info: %s", conn_info)
        logger.warning("[DEBUG] .//column count: %d", len(ds.findall('.//column')))
        logger.warning("[DEBUG] direct column count: %d", len(ds.findall('column')))

        # Track already-emitted columns to avoid duplicates
        seen_columns: set[tuple[str, str]] = set()

        # --- ALL Columns / Fields (search recursively with .//column) ---
        # This captures columns inside <_.fcp...> wrappers, <cols>, and
        # any other nested container – not just direct <datasource> children.
        for col in ds.findall(".//column"):
            col_name = col.get("name", "").strip("[]")
            if not col_name:
                continue
            col_caption = col.get("caption", col_name)
            # Skip Tableau Action / Tooltip set fields
            if _is_excluded_field(col_name, col_caption):
                continue
            # Skip duplicates (same datasource + column name)
            if (ds_caption, col_name) in seen_columns:
                continue
            col_datatype = col.get("datatype", "")
            col_role = col.get("role", "")
            col_type = col.get("type", "")
            col_hidden = col.get("hidden", "")
            col_desc = col_desc_map.get(col_name, "")

            # Resolve source mapping from metadata records
            # Try multiple key variants: [col], col, [Table].[col], or col-only fallback
            meta = _lookup_metadata(col_name, metadata_map, metadata_col_map)
            # Unpack metadata fields for source column resolution
            remote_name = meta.get("remote_name", "")
            source_table = meta.get("source_table", "")
            remote_alias = meta.get("remote_alias", "")
            contains_null = meta.get("contains_null", "")
            aggregation = meta.get("aggregation", "")

            # DEBUG: trace each column lookup
            if not remote_name and not source_table:
                logger.warning("[DEBUG] MISS col=%r  → no metadata match found", col_name)

            # Resolve the physical source table if we have a relation→table map
            physical_table = source_tables.get(source_table, source_table)

            # --- Fallbacks for datasources without metadata records ---
            # (e.g. MS Access, Excel, CSV where Tableau stores no metadata-record)
            # Source Column Name: use the Tableau internal name (which IS the
            # physical column name for file-based connections)
            effective_source_col = remote_name or remote_alias or col_name
            # Source Table: prefer <cols> map (authoritative) → metadata →
            #              join-clause map → default table
            effective_source_table = physical_table or source_table
            if not effective_source_table and col_name in cols_map:
                # Use the authoritative <cols> map as a secondary source table lookup
                effective_source_table = cols_map[col_name].get("table", "")
                # Also prefer the <cols> source column when available
                if not remote_name and not remote_alias:
                    effective_source_col = cols_map[col_name].get("column", col_name)
            if not effective_source_table:
                # Fall back to join-clause-derived column-to-table mapping
                effective_source_table = col_to_table.get(col_name, "")
            if not effective_source_table:
                effective_source_table = source_tables.get(default_table, default_table)
            # Resolve raw table name to friendly caption (e.g. Sheet1$ → Sales Target)
            effective_source_table = table_caption_map.get(effective_source_table, effective_source_table)

            # Detect if this column is calculated
            calc = col.find("calculation")
            formula = ""
            is_calculated = False
            if calc is not None:
                formula = calc.get("formula", "")
                is_calculated = True
                calc_class = calc.get("class", "")
                # Record the calculated field with its formula and properties
                result["Calculated_Fields"].append({
                    "Data Source Name": ds_caption,
                    "Measure Name": col_caption,
                    "Calculation Formula": formula,
                    "Calculation Class": calc_class,
                    "Field Role": col_role,
                    "Format String": col.get("default-format", ""),
                    "Description": col_desc,
                    "Is Hidden": col_hidden or "false",
                })

            # Look up worksheet usage for this field
            usage = field_usage_map.get(ds_name, {}).get(col_name, {})
            used_in_sheets = "; ".join(sorted(usage.get("sheets", set())))

            if _is_tableau_system_name(col_name):
                seen_columns.add((ds_caption, col_name))
                continue

            # Append the fully resolved column to the data lineage output
            result["Data_Lineage"].append({
                "Dashboard Name(s)": "",
                "Worksheet Name(s)": used_in_sheets,
                "Field Display Name": col_caption,
                "Field Internal Name": col_name,
                "Field Description": col_desc,
                "Data Source Name": ds_caption,
                "Source Column": effective_source_col,
                "Source Table": effective_source_table,
                "Source Schema": conn_info.get("schema", ""),
                "Source Database": conn_info.get("database", ""),
                "Source Server": conn_info.get("server", ""),
                "Source Filename": conn_info.get("_filename", ""),
                "Connection Type": conn_info.get("class", ""),
                "Data Type": col_datatype,
                "Field Role": col_role,
                "Field Classification": col_type,
                "Default Aggregation": aggregation,
                "Contains Nulls": contains_null,
                "Is Hidden": col_hidden,
                "Is Calculated Field": "Yes" if is_calculated else "No",
                "Calculation Formula": formula,
            })
            seen_columns.add((ds_caption, col_name))

        # --- Remaining metadata-record columns not already captured ---
        for local_name, meta in metadata_map.items():
            # Normalize the column name from its compound or bracketed form
            norm_name = _extract_col_part(local_name)
            if not norm_name:
                norm_name = local_name.strip("[]")
            if (ds_caption, norm_name) in seen_columns:
                continue
            # Resolve physical table from the metadata source table mapping
            source_table = meta["source_table"]
            physical_table = source_tables.get(source_table, source_table)
            col_desc = col_desc_map.get(norm_name, "")

            usage = field_usage_map.get(ds_name, {}).get(norm_name, {})
            used_in_sheets = "; ".join(sorted(usage.get("sheets", set())))

            if _is_tableau_system_name(norm_name):
                seen_columns.add((ds_caption, norm_name))
                continue

            # Emit remaining metadata-only column as a data lineage row
            result["Data_Lineage"].append({
                "Dashboard Name(s)": "",
                "Worksheet Name(s)": used_in_sheets,
                "Field Display Name": meta["remote_alias"] or meta["remote_name"] or norm_name,
                "Field Internal Name": norm_name,
                "Field Description": col_desc,
                "Data Source Name": ds_caption,
                "Source Column": meta["remote_name"] or norm_name,
                "Source Table": table_caption_map.get(physical_table or source_table or cols_map.get(norm_name, {}).get("table", "") or col_to_table.get(norm_name, "") or source_tables.get(default_table, default_table), physical_table or source_table or cols_map.get(norm_name, {}).get("table", "") or col_to_table.get(norm_name, "") or source_tables.get(default_table, default_table)),
                "Source Schema": conn_info.get("schema", ""),
                "Source Database": conn_info.get("database", ""),
                "Source Server": conn_info.get("server", ""),
                "Source Filename": conn_info.get("_filename", ""),
                "Connection Type": conn_info.get("class", ""),
                "Data Type": meta["local_type"],
                "Field Role": "metadata",
                "Field Classification": "",
                "Default Aggregation": meta["aggregation"],
                "Contains Nulls": meta["contains_null"],
                "Is Hidden": "",
                "Is Calculated Field": "No",
                "Calculation Formula": "",
            })
            seen_columns.add((ds_caption, norm_name))

        # --- Capture columns from folder members not yet seen ---
        for folder in ds.findall(".//folder"):
            for fi in folder.findall("folder-item"):
                fi_name = fi.get("name", "").strip("[]")
                if not fi_name or (ds_caption, fi_name) in seen_columns:
                    continue
                if _is_excluded_field(fi_name):
                    continue
                # Look up metadata and resolve physical table for this folder item
                meta = _lookup_metadata(fi_name, metadata_map, metadata_col_map)
                remote_name = meta.get("remote_name", "")
                source_table = meta.get("source_table", "")
                physical_table = source_tables.get(source_table, source_table) if source_table else ""
                usage = field_usage_map.get(ds_name, {}).get(fi_name, {})
                used_in_sheets = "; ".join(sorted(usage.get("sheets", set())))
                if _is_tableau_system_name(fi_name):
                    seen_columns.add((ds_caption, fi_name))
                    continue
                # Emit the folder member as a data lineage row
                result["Data_Lineage"].append({
                    "Dashboard Name(s)": "",
                    "Worksheet Name(s)": used_in_sheets,
                    "Field Display Name": fi_name,
                    "Field Internal Name": fi_name,
                    "Field Description": col_desc_map.get(fi_name, ""),
                    "Data Source Name": ds_caption,
                    "Source Column": remote_name or meta.get("remote_alias", "") or fi_name,
                    "Source Table": table_caption_map.get(physical_table or source_table or cols_map.get(fi_name, {}).get("table", "") or col_to_table.get(fi_name, "") or source_tables.get(default_table, default_table), physical_table or source_table or cols_map.get(fi_name, {}).get("table", "") or col_to_table.get(fi_name, "") or source_tables.get(default_table, default_table)),
                    "Source Schema": conn_info.get("schema", ""),
                    "Source Database": conn_info.get("database", ""),
                    "Source Server": conn_info.get("server", ""),
                    "Source Filename": conn_info.get("_filename", ""),
                    "Connection Type": conn_info.get("class", ""),
                    "Data Type": meta.get("local_type", ""),
                    "Field Role": "folder-item",
                    "Field Classification": "",
                    "Default Aggregation": meta.get("aggregation", ""),
                    "Contains Nulls": meta.get("contains_null", ""),
                    "Is Hidden": "",
                    "Is Calculated Field": "No",
                    "Calculation Formula": "",
                })
                seen_columns.add((ds_caption, fi_name))

        # --- Capture columns from <column-instance> in datasource itself ---
        for ci in ds.findall(".//column-instance"):
            ci_col = ci.get("column", "").strip("[]")
            if not ci_col or (ds_caption, ci_col) in seen_columns:
                continue
            if _is_excluded_field(ci_col):
                continue
            # Resolve metadata and physical table for the column-instance
            meta = _lookup_metadata(ci_col, metadata_map, metadata_col_map)
            remote_name = meta.get("remote_name", "")
            source_table = meta.get("source_table", "")
            physical_table = source_tables.get(source_table, source_table) if source_table else ""
            usage = field_usage_map.get(ds_name, {}).get(ci_col, {})
            used_in_sheets = "; ".join(sorted(usage.get("sheets", set())))
            if _is_tableau_system_name(ci_col):
                seen_columns.add((ds_caption, ci_col))
                continue
            # Emit column-instance as a data lineage row with derivation info
            result["Data_Lineage"].append({
                "Dashboard Name(s)": "",
                "Worksheet Name(s)": used_in_sheets,
                "Field Display Name": ci_col,
                "Field Internal Name": ci_col,
                "Field Description": "",
                "Data Source Name": ds_caption,
                "Source Column": remote_name or meta.get("remote_alias", "") or ci_col,
                "Source Table": table_caption_map.get(physical_table or source_table or cols_map.get(ci_col, {}).get("table", "") or col_to_table.get(ci_col, "") or source_tables.get(default_table, default_table), physical_table or source_table or cols_map.get(ci_col, {}).get("table", "") or col_to_table.get(ci_col, "") or source_tables.get(default_table, default_table)),
                "Source Schema": conn_info.get("schema", ""),
                "Source Database": conn_info.get("database", ""),
                "Source Server": conn_info.get("server", ""),
                "Source Filename": conn_info.get("_filename", ""),
                "Connection Type": conn_info.get("class", ""),
                "Data Type": meta.get("local_type", ""),
                "Field Role": ci.get("derivation", ""),
                "Field Classification": ci.get("type", ""),
                "Default Aggregation": meta.get("aggregation", ""),
                "Contains Nulls": meta.get("contains_null", ""),
                "Is Hidden": "",
                "Is Calculated Field": "No",
                "Calculation Formula": "",
            })
            seen_columns.add((ds_caption, ci_col))

        # --- Capture columns from <cols> map not already seen ---
        # These are physical-table-only columns that have no <column>,
        # <column-instance>, or <folder-item> element (e.g. Inventory,
        # Market, Market Size, Product, Product Type, Type).
        for logical_name, mapping in cols_map.items():
            if (ds_caption, logical_name) in seen_columns:
                continue
            if _is_excluded_field(logical_name):
                continue
            # Extract the physical table and column from the <cols> mapping
            phys_table = mapping.get("table", "")
            phys_col = mapping.get("column", logical_name)
            meta = _lookup_metadata(logical_name, metadata_map, metadata_col_map)
            usage = field_usage_map.get(ds_name, {}).get(logical_name, {})
            used_in_sheets = "; ".join(sorted(usage.get("sheets", set())))
            if _is_tableau_system_name(logical_name):
                seen_columns.add((ds_caption, logical_name))
                continue
            # Emit physical-only column as a data lineage row
            result["Data_Lineage"].append({
                "Dashboard Name(s)": "",
                "Worksheet Name(s)": used_in_sheets,
                "Field Display Name": logical_name,
                "Field Internal Name": logical_name,
                "Field Description": col_desc_map.get(logical_name, ""),
                "Data Source Name": ds_caption,
                "Source Column": meta.get("remote_name", "") or phys_col,
                "Source Table": table_caption_map.get(phys_table, phys_table),
                "Source Schema": conn_info.get("schema", ""),
                "Source Database": conn_info.get("database", ""),
                "Source Server": conn_info.get("server", ""),
                "Source Filename": conn_info.get("_filename", ""),
                "Connection Type": conn_info.get("class", ""),
                "Data Type": meta.get("local_type", ""),
                "Field Role": "",
                "Field Classification": "",
                "Default Aggregation": meta.get("aggregation", ""),
                "Contains Nulls": meta.get("contains_null", ""),
                "Is Hidden": "",
                "Is Calculated Field": "No",
                "Calculation Formula": "",
            })
            seen_columns.add((ds_caption, logical_name))

        # Also capture columns that only appear in worksheet dependencies
        # but not in the datasource definition itself
        ws_cols = field_usage_map.get(ds_name, {})
        for col_name, usage in ws_cols.items():
            if (ds_caption, col_name) in seen_columns:
                continue
            if _is_excluded_field(col_name, usage.get("caption", "")):
                continue
            # Resolve metadata for worksheet-only columns not in datasource definition
            meta = _lookup_metadata(col_name, metadata_map, metadata_col_map)
            remote_name = meta.get("remote_name", "") if meta else ""
            source_table = meta.get("source_table", "") if meta else ""
            remote_alias = meta.get("remote_alias", "") if meta else ""
            physical_table = source_tables.get(source_table, source_table) if source_table else ""
            used_in_sheets = "; ".join(sorted(usage.get("sheets", set())))

            if _is_tableau_system_name(col_name):
                seen_columns.add((ds_caption, col_name))
                continue

            # Emit worksheet-referenced column as a data lineage row
            result["Data_Lineage"].append({
                "Dashboard Name(s)": "",
                "Worksheet Name(s)": used_in_sheets,
                "Field Display Name": usage.get("caption", col_name),
                "Field Internal Name": col_name,
                "Field Description": "",
                "Data Source Name": ds_caption,
                "Source Column": remote_name or remote_alias or col_name,
                "Source Table": table_caption_map.get(physical_table or source_table or cols_map.get(col_name, {}).get("table", "") or col_to_table.get(col_name, "") or source_tables.get(default_table, default_table), physical_table or source_table or cols_map.get(col_name, {}).get("table", "") or col_to_table.get(col_name, "") or source_tables.get(default_table, default_table)),
                "Source Schema": conn_info.get("schema", ""),
                "Source Database": conn_info.get("database", ""),
                "Source Server": conn_info.get("server", ""),
                "Source Filename": conn_info.get("_filename", ""),
                "Connection Type": conn_info.get("class", ""),
                "Data Type": meta.get("local_type", "") if meta else "",
                "Field Role": "",
                "Field Classification": "",
                "Default Aggregation": "",
                "Contains Nulls": "",
                "Is Hidden": "",
                "Is Calculated Field": "No",
                "Calculation Formula": "",
            })
            seen_columns.add((ds_caption, col_name))

        # --- Relationships / Joins ---
        _parse_relations_recursive(ds, ds_caption, result)
        _parse_object_graph_relationships(ds, ds_caption, result)

        # --- Custom SQL ---
        # Capture any inline SQL text embedded in relation elements
        for relation in ds.findall(".//relation"):
            rel_type = relation.get("type", "")
            if rel_type and rel_type.lower() == "text":
                custom_sql = relation.text or ""
                if custom_sql.strip():
                    result["Custom_SQL"].append({
                        "Data Source Name": ds_caption,
                        "Partition": relation.get("name", "CustomSQL"),
                        "Type": "Custom SQL",
                        "Custom SQL": custom_sql.strip(),
                    })


def _parse_relations_recursive(parent_elem: ET.Element, ds_caption: str,
                                result: dict) -> None:
    """Walk all <relation type='join'> elements and extract readable join info.

    Handles nested joins where a child relation is itself a join (multi-table).
    Only processes top-level join elements to avoid double-counting nested ones.
    """
    # Collect only direct top-level join relations to avoid duplicates
    seen_join_elems: set[int] = set()
    for relation in parent_elem.findall(".//relation"):
        rel_type = (relation.get("type") or "").lower()
        if rel_type != "join":
            continue
        elem_id = id(relation)
        if elem_id in seen_join_elems:
            continue
        seen_join_elems.add(elem_id)

        join_type = (relation.get("join") or "inner").upper()

        # Child relations are the left and right sides of the join.
        # A child can be a table relation or itself a nested join.
        children = relation.findall("relation")
        left_table = _resolve_relation_name(children[0]) if len(children) >= 1 else ""
        right_table = _resolve_relation_name(children[1]) if len(children) >= 2 else ""

        # Parse ALL join clauses (there can be multiple <clause> elements)
        on_parts: list[str] = []
        left_cols: list[str] = []
        right_cols: list[str] = []
        for clause in relation.findall("clause"):
            lc, rc = _parse_clause(clause)
            if lc and rc:
                left_cols.append(lc)
                right_cols.append(rc)
                on_parts.append(f"{left_table}.[{lc}] = {right_table}.[{rc}]")

        # Build the readable join expression
        on_clause = " AND ".join(on_parts) if on_parts else "(columns not resolved)"
        join_expr = f"{left_table} {join_type} JOIN {right_table} ON {on_clause}"

        # Append the resolved join relationship with all column pairs
        result["Relationships"].append({
            "Relationship Expression": join_expr,
            "Relationship Type": join_type,
            "Left Table": left_table,
            "Left Column(s)": ", ".join(f"[{c}]" for c in left_cols),
            "Right Table": right_table,
            "Right Column(s)": ", ".join(f"[{c}]" for c in right_cols),
            "Data Source Name": ds_caption,
            "Cardinality": "",
            "Referential Integrity": "",
            "Is Active": True,
        })


def _parse_object_graph_relationships(ds: ET.Element, ds_caption: str,
                                       result: dict) -> None:
    """Parse Tableau's new logical-model relationships from <object-graph>.

    Newer Tableau workbooks (2020.2+) store table relationships in an
    <object-graph> element with <relationships> → <relationship> children
    instead of the legacy <relation type="join">.

    Structure:
      <object-graph>
        <objects>
          <object caption="Orders" id="Orders_ABC123">...</object>
          <object caption="People" id="People_DEF456">...</object>
        </objects>
        <relationships>
          <relationship>
            <expression op="=">
              <expression op="[Region]" />
              <expression op="[Region (People)]" />
            </expression>
            <first-end-point object-id="Orders_ABC123" />
            <second-end-point object-id="People_DEF456" />
          </relationship>
        </relationships>
      </object-graph>
    """
    # Build object-id → caption mapping for readable table names
    obj_map: dict[str, str] = {}  # object id → caption
    for obj in ds.findall(".//{*}object"):
        obj_id = obj.get("id", "")
        obj_caption = obj.get("caption", "")
        if obj_id:
            obj_map[obj_id] = obj_caption or obj_id

    for rel in ds.findall(".//{*}relationships/{*}relationship"):
        # Child <expression op="="> contains the key columns
        eq_expr = rel.find("{*}expression[@op='=']")
        if eq_expr is None:
            eq_expr = rel.find("expression[@op='=']")
        if eq_expr is None:
            continue

        col_exprs = eq_expr.findall("{*}expression") or eq_expr.findall("expression")
        if len(col_exprs) < 2:
            continue

        # Extract left and right key column names from the equality expression
        left_col = _strip_brackets(col_exprs[0].get("op", ""))
        right_col = _strip_brackets(col_exprs[1].get("op", ""))

        # Resolve table names from <first-end-point> / <second-end-point> child elements
        left_table = ""
        right_table = ""
        first_ep = rel.find("{*}first-end-point") or rel.find("first-end-point")
        second_ep = rel.find("{*}second-end-point") or rel.find("second-end-point")
        if first_ep is not None:
            left_table = obj_map.get(first_ep.get("object-id", ""), "")
        if second_ep is not None:
            right_table = obj_map.get(second_ep.get("object-id", ""), "")

        if not left_table and not right_table:
            continue

        on_clause = f"{left_table}.[{left_col}] = {right_table}.[{right_col}]"
        join_expr = f"{left_table} RELATIONSHIP {right_table} ON {on_clause}"

        # Extract cardinality and referential integrity from endpoint attributes
        cardinality = ""
        ref_integrity = ""
        if first_ep is not None:
            cardinality_parts = []
            first_card = first_ep.get("cardinality", "")
            second_card = second_ep.get("cardinality", "") if second_ep is not None else ""
            if first_card or second_card:
                cardinality = f"{first_card or 'many'}-to-{second_card or 'many'}"
            first_ri = first_ep.get("referential-integrity", "")
            second_ri = second_ep.get("referential-integrity", "") if second_ep is not None else ""
            if first_ri or second_ri:
                ref_integrity = f"{first_ri}; {second_ri}".strip("; ")

        # Append the logical-model relationship with cardinality details
        result["Relationships"].append({
            "Relationship Expression": join_expr,
            "Relationship Type": "RELATIONSHIP",
            "Left Table": left_table,
            "Left Column(s)": f"[{left_col}]",
            "Right Table": right_table,
            "Right Column(s)": f"[{right_col}]",
            "Data Source Name": ds_caption,
            "Cardinality": cardinality,
            "Referential Integrity": ref_integrity,
            "Is Active": True,
        })


def _resolve_relation_name(rel_elem: ET.Element) -> str:
    """Get a human-readable name for a <relation> element.

    If it is a table relation, return its name or table attribute.
    If it is a nested join, return the name of its first child table.
    """
    rel_type = (rel_elem.get("type") or "").lower()
    name = rel_elem.get("name", "")
    table = rel_elem.get("table", "")

    if rel_type == "table" or (not rel_type and (name or table)):
        return name or table
    if rel_type == "join":
        # For a nested join, return the rightmost child table name
        children = rel_elem.findall("relation")
        for child in reversed(children):
            resolved = _resolve_relation_name(child)
            if resolved:
                return resolved
    return name


def _parse_clause(clause: ET.Element) -> tuple[str, str]:
    """Extract left-col and right-col from a single <clause> element.

    Tableau XML clause structure:
      <clause type="join">
        <expression op="=">
          <expression op="[left_col]" />
          <expression op="[right_col]" />
        </expression>
      </clause>

    The op value may be a simple bracketed name like ``[ProductId]``
    or a compound reference like ``[factTable].[ProductId]``.
    We always return just the column-name part.
    """
    expr = clause.find("expression")
    if expr is None:
        return "", ""
    col_exprs = expr.findall("expression")
    left_col, right_col = "", ""
    if len(col_exprs) >= 2:
        left_col = _extract_col_part(col_exprs[0].get("op", ""))
        right_col = _extract_col_part(col_exprs[1].get("op", ""))
    return left_col, right_col


def _strip_brackets(value: str) -> str:
    """Remove enclosing square brackets from a value like '[column_name]'.

    Unlike str.strip('[]') which removes *all* leading/trailing bracket chars
    (mangling values like '[dbo].[table]'), this only removes a single
    enclosing pair.
    """
    if value.startswith("[") and value.endswith("]"):
        return value[1:-1]
    return value


def _element_text(elem: ET.Element) -> str:
    """Recursively extract all text content from an element."""
    parts = []
    if elem.text:
        parts.append(elem.text)
    for child in elem:
        parts.append(_element_text(child))
        if child.tail:
            parts.append(child.tail)
    return " ".join(parts)


# Regex to match Tableau field references like "[ds1].[CustName]" or "[ds1].[sum:Amount:qk]"
_FIELD_REF_RE = re.compile(r'^\[([^\]]+)\]\.\[([^\]]+)\]$')


def _parse_field_ref(raw: str) -> tuple[str, str]:
    """Parse a Tableau field reference into (datasource_name, field_name).

    Handles formats like:
      [ds1].[CustName]         → ('ds1', 'CustName')
      [ds1].[sum:Amount:qk]    → ('ds1', 'Amount')
      ds1.CustName             → ('ds1', 'CustName')
    """
    m = _FIELD_REF_RE.match(raw)
    if m:
        ds_ref = m.group(1)
        field_raw = m.group(2)
    else:
        # Fallback: strip outer brackets and split on '.'
        stripped = _strip_brackets(raw)
        parts = stripped.split(".", 1)
        if len(parts) == 2:
            ds_ref = parts[0]
            field_raw = _strip_brackets(parts[1])
        else:
            return "", stripped
    # Normalize Tableau qualifiers like "sum:", ":qk", ":ok", ":nk"
    field_name = re.sub(r'^[a-z]+:', '', field_raw)
    field_name = re.sub(r':[a-z]+$', '', field_name)
    return ds_ref, field_name


def _extract_col_part(local_name: str) -> str:
    """Extract the column-name-only part from a Tableau local-name.

    Examples:
        '[Extract].[OrderID]' → 'OrderID'
        '[OrderID]'           → 'OrderID'
        'OrderID'             → 'OrderID'
    """
    # Two-part compound key: [Table].[Column]
    m = re.match(r'^\[([^\]]+)\]\.\[([^\]]+)\]$', local_name)
    if m:
        return m.group(2)
    # Single bracketed key: [Column]
    if local_name.startswith('[') and local_name.endswith(']') and '].['  not in local_name:
        return local_name[1:-1]
    return local_name


def _lookup_metadata(col_name: str, metadata_map: dict,
                     metadata_col_map: dict) -> dict:
    """Look up metadata for a column trying multiple key variants.

    Tableau metadata records use local-name keys like:
      [Extract].[OrderID]   (compound)
      [OrderID]             (simple bracket)
      OrderID               (bare)
    We try all plausible variants to maximise hit rate.
    """
    # 1. Direct match on [col_name] or col_name
    meta = metadata_map.get(f"[{col_name}]") or metadata_map.get(col_name)
    if meta:
        return meta
    # 2. Scan for any compound key ending with .[col_name]
    bracket_suffix = f".[{col_name}]"
    for key, val in metadata_map.items():
        if key.endswith(bracket_suffix):
            return val
    # 3. Column-only fallback lookup
    meta = metadata_col_map.get(col_name)
    if meta:
        return meta
    return {}


def _get_connection_info(ds: ET.Element) -> dict:
    """Extract connection-level info (server, database, schema, class) for lineage.

    Always traverses named-connections so that federated wrappers don't
    hide the real database / server attributes.
    """
    info: dict[str, str] = {"server": "", "database": "", "schema": "", "class": ""}
    conn = ds.find("connection")
    if conn is not None:
        info["server"] = conn.get("server", "") or conn.get("filename", "") or conn.get("directory", "")
        info["database"] = conn.get("dbname", "")
        info["schema"] = conn.get("schema", "")
        info["class"] = conn.get("class", "")

    # Always check named-connections — the top-level connection is often a
    # "federated" wrapper with empty server/dbname fields.
    for nc in ds.findall(".//named-connection"):
        nc_conn = nc.find("connection")
        if nc_conn is None:
            continue
        # Extract connection properties from the named connection element
        nc_server = nc_conn.get("server", "") or nc_conn.get("filename", "")
        nc_db = nc_conn.get("dbname", "")
        nc_schema = nc_conn.get("schema", "")
        nc_class = nc_conn.get("class", "")
        # Prefer non-empty values from named connections
        if nc_server and not info["server"]:
            info["server"] = nc_server
        if nc_db and not info["database"]:
            info["database"] = nc_db
        if nc_schema and not info["schema"]:
            info["schema"] = nc_schema
        if nc_class and (not info["class"] or info["class"] == "federated"):
            info["class"] = nc_class

    # Also scan all nested <connection> elements (some Tableau versions nest
    # the real connection deeper)
    if not info["database"]:
        for inner_conn in ds.findall(".//connection"):
            db = inner_conn.get("dbname", "")
            if db:
                info["database"] = db
                if not info["server"]:
                    info["server"] = inner_conn.get("server", "") or inner_conn.get("filename", "")
                if not info["schema"]:
                    info["schema"] = inner_conn.get("schema", "")
                if not info["class"] or info["class"] == "federated":
                    info["class"] = inner_conn.get("class", "") or info["class"]
                break

    # For file-based connections (msaccess, excel, csv, etc.) that have no
    # dbname, use filename as the database identifier.
    if not info["database"]:
        for any_conn in ds.findall(".//connection"):
            fn = any_conn.get("filename", "")
            if fn:
                info["database"] = fn
                if not info["server"]:
                    info["server"] = fn
                break
    return info


def _parse_connection_element(conn: ET.Element, ds_caption: str, result: dict) -> None:
    """Parse a single <connection> element for data source information."""
    # Build a data source record from connection attributes
    result["Data_Sources"].append({
        "Data Source Name": ds_caption,
        "Connection Type": conn.get("class", ""),
        "Server": conn.get("server", ""),
        "Port": conn.get("port", ""),
        "Database": conn.get("dbname", ""),
        "Schema": conn.get("schema", ""),
        "Warehouse": conn.get("warehouse", ""),
        "Filename": conn.get("filename", "") or conn.get("directory", ""),
        "Authentication": conn.get("authentication", ""),
        "Connection String": _build_conn_string(conn),
    })


def _build_conn_string(conn: ET.Element) -> str:
    """Reconstruct a human-readable connection string from attributes."""
    parts = []
    # Concatenate all non-empty connection attributes into a semicolon-delimited string
    for key in ("class", "server", "port", "dbname", "filename", "directory",
                "authentication", "schema", "warehouse", "service"):
        val = conn.get(key, "")
        if val:
            parts.append(f"{key}={val}")
    return "; ".join(parts)


def _parse_worksheets(root: ET.Element, result: dict) -> None:
    """Extract worksheet (page) information and the fields used in each."""
    worksheets = root.find(".//worksheets")
    if worksheets is None:
        return

    for idx, ws in enumerate(worksheets.findall("worksheet")):
        ws_name = ws.get("name", f"Sheet {idx + 1}")
        # Record worksheet basic properties (name, type, filters)
        result["Worksheets_Dashboards"].append({
            "Sheet Name": ws_name,
            "Sheet Type": "Worksheet",
            "Display Order": idx,
            "Width": "",
            "Height": "",
            "Filters": _extract_filters(ws),
        })

        # Fields referenced in the worksheet
        fields = set()
        # Collect fields from datasource-dependency column definitions
        for datasource_dep in ws.findall(".//datasource-dependencies"):
            ds_ref = datasource_dep.get("datasource", "")
            for col in datasource_dep.findall("column"):
                col_name = col.get("name", "").strip("[]")
                col_caption = col.get("caption", col_name)
                fields.add(f"{ds_ref}.{col_caption}")

        # Rows/Columns shelves
        # Scan row, column, and encoding shelves for additional field references
        for shelf_tag in ("rows", "columns", "encodings"):
            shelf = ws.find(f"./table/view/{shelf_tag}")
            if shelf is None:
                shelf = ws.find(f"./{shelf_tag}")
            if shelf is not None and shelf.text:
                # Field references in bracket notation
                refs = re.findall(r'\[([^\]]+)\]', shelf.text)
                fields.update(refs)

        # Mark the worksheet visual entry
        # Determine the mark type (bar, line, etc.) from the pane definition
        table = ws.find(".//table")
        mark_type = ""
        visual_type = "Worksheet"
        if table is not None:
            mark = table.find(".//pane/mark")
            if mark is not None:
                mark_type = mark.get("class", "auto")
                visual_type = f"Worksheet ({mark_type})"

        # Record the worksheet visual layout entry with mark and field info
        result["Visual_Layout"].append({
            "Sheet Name": ws_name,
            "Visual Type": visual_type,
            "Mark Type": mark_type,
            "Title": ws_name,
            "Fields": "; ".join(sorted(fields)) if fields else "",
            "X Position": "",
            "Y Position": "",
            "Width": "",
            "Height": "",
        })


def _parse_dashboards(root: ET.Element, result: dict) -> None:
    """Extract dashboard definitions and their sheet zone references."""
    dashboards = root.find(".//dashboards")
    if dashboards is None:
        return

    for idx, db in enumerate(dashboards.findall("dashboard")):
        db_name = db.get("name", f"Dashboard {idx + 1}")
        # Record dashboard-level metadata (name, dimensions, filters)
        result["Worksheets_Dashboards"].append({
            "Sheet Name": db_name,
            "Sheet Type": "Dashboard",
            "Display Order": 1000 + idx,  # After worksheets
            "Width": db.get("width", ""),
            "Height": db.get("height", ""),
            "Filters": _extract_filters(db),
        })

        # Zones represent embedded sheets / objects on the dashboard
        for zone in db.findall(".//zone"):
            # Extract zone identity and type for the visual layout output
            zone_name = zone.get("name", "")
            zone_type = zone.get("type", zone.get("type-v2", ""))
            zone_param = zone.get("param", "")  # Often the sheet name

            if zone_name or zone_param:
                # Record each dashboard zone with its position and dimensions
                result["Visual_Layout"].append({
                    "Sheet Name": db_name,
                    "Visual Type": f"Dashboard Zone ({zone_type})" if zone_type else "Dashboard Zone",
                    "Mark Type": "",
                    "Title": zone_param or zone_name,
                    "Fields": "",
                    "X Position": zone.get("x", ""),
                    "Y Position": zone.get("y", ""),
                    "Width": zone.get("w", ""),
                    "Height": zone.get("h", ""),
                })


def _extract_filters(element: ET.Element) -> str:
    """Extract filter text from an element's filter shelf."""
    filters = []
    for f in element.findall(".//filter"):
        col = f.get("column", "")
        cls = f.get("class", "")
        if col:
            filters.append(f"{col} ({cls})" if cls else col)
    return "; ".join(filters)
