"""
AI-powered table matching using OpenAI.

Uses OpenAI to infer table descriptions from table names and match
Tableau tables to CDH tables based on semantic similarity.

Activated only when the OPENAI_API_KEY environment variable is set.
"""

import json
import logging
import os
from typing import Dict, List, Tuple

logger = logging.getLogger(__name__)

# Minimum confidence for AI-based table description matching
AI_CONFIDENCE_THRESHOLD = 0.80

# Model can be overridden via environment variable
OPENAI_MODEL = os.environ.get("OPENAI_MODEL", "gpt-4o-mini")


def _get_openai_client():
    """Return an OpenAI client, or None if unavailable."""
    api_key = os.environ.get("OPENAI_API_KEY")
    if not api_key:
        logger.info("OPENAI_API_KEY not set – AI matching disabled")
        return None
    # Attempt dynamic import so the package is only required when AI is enabled
    try:
        from openai import OpenAI
        return OpenAI(api_key=api_key)
    except ImportError:
        logger.warning("openai package not installed – AI matching disabled")
        return None


def build_ai_table_mapping(
    asis_tables: List[str],
    tobe_tables: List[str],
) -> Dict[str, Tuple[str, float]]:
    """Use OpenAI to match Tableau table names to CDH table names
    based on inferred table descriptions.

    Returns:
        Dict mapping Tableau table name -> (CDH table name, confidence).
        Only includes matches with confidence >= AI_CONFIDENCE_THRESHOLD.
    """
    client = _get_openai_client()
    if client is None:
        return {}

    if not asis_tables or not tobe_tables:
        return {}

    prompt = (
        "You are a data engineering expert. Given two lists of database/report "
        "table names from different systems (Tableau and CDH), do the following:\n\n"
        "1. Infer what each table likely contains based on its name, common naming "
        "conventions, and domain knowledge.\n"
        "2. Match each Tableau table to the most likely corresponding CDH table "
        "based on their inferred descriptions and purposes.\n"
        "3. Provide a confidence score (0.0 to 1.0) for each match.\n\n"
        f"Tableau Tables:\n{json.dumps(asis_tables)}\n\n"
        f"CDH Tables:\n{json.dumps(tobe_tables)}\n\n"
        "Return a JSON object with a \"matches\" key containing an array. "
        "Each element must have:\n"
        "  - \"asis_table\": the Tableau table name exactly as provided\n"
        "  - \"tobe_table\": the matching CDH table name exactly as provided\n"
        "  - \"confidence\": float 0.0 to 1.0\n"
        "  - \"asis_description\": brief inferred description of the Tableau table\n"
        "  - \"tobe_description\": brief inferred description of the CDH table\n"
        "  - \"reasoning\": one-sentence explanation of why they match\n\n"
        "Only include matches where confidence >= 0.5. "
        "If no good match exists for a table, omit it."
    )

    try:
        # Send prompt to AI model with low temperature for deterministic matching
        response = client.chat.completions.create(
            model=OPENAI_MODEL,
            messages=[
                {
                    "role": "system",
                    "content": "You are a data engineering expert. Respond with JSON only.",
                },
                {"role": "user", "content": prompt},
            ],
            temperature=0.1,
            response_format={"type": "json_object"},
        )

        # Parse the JSON response and extract the matches array
        raw = response.choices[0].message.content
        parsed = json.loads(raw)
        matches = parsed.get("matches", [])

        if not isinstance(matches, list):
            logger.warning("AI table matching: unexpected 'matches' type %s", type(matches))
            return {}

        # Filter matches by confidence threshold and collect qualifying pairs
        result: Dict[str, Tuple[str, float]] = {}
        for m in matches:
            asis_t = m.get("asis_table", "")
            tobe_t = m.get("tobe_table", "")
            conf = float(m.get("confidence", 0.0))

            if asis_t and tobe_t and conf >= AI_CONFIDENCE_THRESHOLD:
                result[asis_t] = (tobe_t, conf)
                logger.info(
                    "AI match: '%s' -> '%s' (%.0f%%) — %s",
                    asis_t,
                    tobe_t,
                    conf * 100,
                    m.get("reasoning", ""),
                )

        logger.info(
            "AI table mapping: %d matches above %.0f%% threshold (of %d as-is tables)",
            len(result),
            AI_CONFIDENCE_THRESHOLD * 100,
            len(asis_tables),
        )
        return result

    except Exception:
        logger.exception("OpenAI API call failed during table matching")
        return {}
