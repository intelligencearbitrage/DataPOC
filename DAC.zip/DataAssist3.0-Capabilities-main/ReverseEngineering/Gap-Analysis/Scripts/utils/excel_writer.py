"""
Excel writer utility.

Compiles extracted BI metadata into a well-structured .xlsx workbook with
separate sheets for each category:
  - Data_Sources
  - Data_Lineage
  - Relationships
  - Calculated_Fields
  - Worksheets_Dashboards
  - Visual_Layout
  - Custom_SQL
"""

import io
import logging
from typing import Any, Dict, List

from openpyxl import Workbook
from openpyxl.comments import Comment
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter

logger = logging.getLogger(__name__)

# Styling constants
HEADER_FONT = Font(bold=True, color="FFFFFF", size=11, name="Calibri")
HEADER_FILL = PatternFill(start_color="2F5496", end_color="2F5496", fill_type="solid")
HEADER_ALIGNMENT = Alignment(horizontal="center", vertical="center", wrap_text=True)
CELL_ALIGNMENT = Alignment(vertical="top", wrap_text=True)
THIN_BORDER = Border(
    left=Side(style="thin"),
    right=Side(style="thin"),
    top=Side(style="thin"),
    bottom=Side(style="thin"),
)

# Ordered list of sheet names to emit
SHEET_ORDER = [
    "Summary",
    "Data_Sources",
    "Data_Lineage",
    "Relationships",
    "Calculated_Fields",
    "Worksheets_Dashboards",
    "Visual_Layout",
    "Custom_SQL",
    "Report_Lineage_Glossary",
    "Report_Sample_Data",
]

# Internal → friendly header renames for the Sample_Data sheet
_SAMPLE_META_RENAME = {
    "__source_file__": "Source File",
    "__sheet_name__": "Source Sheet",
    "__source_table__": "Source Table",
}

# Keys that are promoted to the front of the Sample_Data columns
_SAMPLE_META_KEYS = set(_SAMPLE_META_RENAME.keys())


def _normalise_sample_data(
    rows: List[Dict[str, Any]],
) -> List[Dict[str, Any]]:
    """Reorder and rename Sample_Data rows for a clean, industry-standard layout.

    1. Rename internal metadata keys to friendly names.
    2. Place source-context columns first (Source File, Source Sheet/Table).
    3. Sort remaining data columns alphabetically for easy scanning.
    """
    if not rows:
        return rows

    # --- Pass 1: rename internal keys and collect all column names ----------
    renamed_rows: List[Dict[str, Any]] = []
    meta_cols: list[str] = []   # friendly names, insertion-ordered
    data_cols_set: set[str] = set()

    for rd in rows:
        new_rd: Dict[str, Any] = {}
        for k, v in rd.items():
            friendly = _SAMPLE_META_RENAME.get(k, k)
            new_rd[friendly] = v
            if k in _SAMPLE_META_KEYS:
                if friendly not in meta_cols:
                    meta_cols.append(friendly)
            else:
                data_cols_set.add(friendly)
        renamed_rows.append(new_rd)

    # --- Pass 2: build final column order --------------------------------
    data_cols = sorted(data_cols_set, key=str.lower)
    ordered_keys = meta_cols + data_cols

    # --- Pass 3: re-key each row in the canonical order -------------------
    result: List[Dict[str, Any]] = []
    for rd in renamed_rows:
        result.append({k: rd.get(k, "") for k in ordered_keys})

    return result


def generate_excel(data: Dict[str, List[Dict[str, Any]]]) -> bytes:
    """Generate an Excel workbook from extracted metadata.

    Args:
        data: Dictionary mapping sheet names to lists of row dicts.

    Returns:
        Bytes of the .xlsx file ready to be saved or sent over HTTP.
    """
    wb = Workbook()
    # Remove the default sheet created by openpyxl
    wb.remove(wb.active)

    for sheet_name in SHEET_ORDER:
        rows = data.get(sheet_name, [])
        ws = wb.create_sheet(title=sheet_name[:31])  # Excel sheet name max 31 chars

        if not rows:
            ws.append(["No data extracted for this category."])
            _auto_width(ws)
            continue

        # Build header list.  For sheets with heterogeneous rows (e.g.
        # Sample_Data where different source tables have different columns)
        # we need to collect keys from ALL rows to produce a complete set.
        if sheet_name == "Report_Sample_Data":
            rows = _normalise_sample_data(rows)
            seen = set()
            headers: list[str] = []
            for rd in rows:
                for k in rd.keys():
                    if k not in seen:
                        seen.add(k)
                        headers.append(k)
        else:
            headers = list(rows[0].keys())
        ws.append(headers)
        for col_idx, _header in enumerate(headers, start=1):
            cell = ws.cell(row=1, column=col_idx)
            cell.font = HEADER_FONT
            cell.fill = HEADER_FILL
            cell.alignment = HEADER_ALIGNMENT
            cell.border = THIN_BORDER

        # Write data rows, coercing each value to an Excel-safe representation
        for row_dict in rows:
            row_values = [_cell_value(row_dict.get(h, "")) for h in headers]
            ws.append(row_values)

        # Apply consistent alignment and border to every data cell
        for row in ws.iter_rows(min_row=2, max_row=ws.max_row, max_col=len(headers)):
            for cell in row:
                cell.alignment = CELL_ALIGNMENT
                cell.border = THIN_BORDER

        # Auto-fit column widths
        _auto_width(ws)

        # Freeze header row
        ws.freeze_panes = "A2"

        # Auto-filter
        ws.auto_filter.ref = ws.dimensions

        # Add explanatory comment on Worksheet Name(s) header in Data_Lineage
        if sheet_name == "Data_Lineage" and "Worksheet Name(s)" in headers:
            ri = headers.index("Worksheet Name(s)") + 1
            ws.cell(row=1, column=ri).comment = Comment(
                "Blank values indicate fields that exist in the data source "
                "connection but are not placed on any worksheet or visual. "
                "These fields are included to provide complete source-to-target "
                "lineage for migration and remediation purposes.",
                "System",
            )

    # Serialize to bytes
    buffer = io.BytesIO()
    wb.save(buffer)
    buffer.seek(0)
    return buffer.read()


def _cell_value(val: Any) -> Any:
    """Coerce a value to something Excel-friendly."""
    if val is None:
        return ""
    # Booleans must be checked before int (bool is a subclass of int)
    if isinstance(val, bool):
        return "Yes" if val else "No"
    # Serialize complex types to JSON strings so Excel can display them
    if isinstance(val, (list, dict)):
        import json
        return json.dumps(val, ensure_ascii=False, default=str)
    return val


def _auto_width(ws) -> None:
    """Set each column width based on content length (capped)."""
    # Iterate every column, find the longest cell value, then set width
    for col in ws.columns:
        max_len = 0
        col_letter = get_column_letter(col[0].column)
        for cell in col:
            try:
                cell_len = len(str(cell.value or ""))
                if cell_len > max_len:
                    max_len = cell_len
            except Exception:
                pass
        # Cap width to something reasonable; min 12 for readability
        adjusted = min(max_len + 4, 60)
        ws.column_dimensions[col_letter].width = max(adjusted, 12)
