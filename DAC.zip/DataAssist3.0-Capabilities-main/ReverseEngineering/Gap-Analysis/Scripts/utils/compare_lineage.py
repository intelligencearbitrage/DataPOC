"""
Data Metadata Mapping Engine.

Accepts two Excel workbooks (Tableau and CDH), reads the
*Data_Lineage* sheet from each, and produces a comparison Excel report
that shows:

  - Tableau Dashboard Name(s), Tableau Worksheet Name(s), Tableau Field Name, Source Column, Source Table
  - Match Found?  (Yes / No)
  - CDH Column Name, CDH Table Name

Matching strategy (in order of precedence):
  1. Exact match on *(Source Column + Table Name)* — both must match
     (case-insensitive)
  2. Table Description match — fuzzy Tableau table name vs CDH
     Table Description (>= 80 %) + exact Source Column name
  3. Glossary Description match — matches Report field display names
     and descriptions against CDH column descriptions via normalised
     token overlap and keyword similarity
  4. Sample Data match — compares distinct sample data values between
     Report and CDH columns using Jaccard similarity (>= 30 %).
     If the CDH file lacks sample data, synthetic values are
     auto-generated from column names, data types, and glossary
     descriptions.
  5. Fuzzy match on *(Source Column + Table Name)* — weighted composite
     score >= 80 %
  6. (Optional) AI-powered table matching via OpenAI
"""

import io
import logging
import os
import re as _re_module
from difflib import SequenceMatcher
from typing import Any, Dict, List, Set, Tuple

from openpyxl import Workbook, load_workbook
from openpyxl.comments import Comment
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Styling (reuse the project palette)
# ---------------------------------------------------------------------------
HEADER_FONT = Font(bold=True, color="FFFFFF", size=11, name="Calibri")
HEADER_FILL = PatternFill(start_color="2F5496", end_color="2F5496", fill_type="solid")
HEADER_ALIGNMENT = Alignment(horizontal="center", vertical="center", wrap_text=True)
CELL_ALIGNMENT = Alignment(vertical="top", wrap_text=True)
MATCH_FILL = PatternFill(start_color="E8F8EF", end_color="E8F8EF", fill_type="solid")
NO_MATCH_FILL = PatternFill(start_color="FDF0EF", end_color="FDF0EF", fill_type="solid")
THIN_BORDER = Border(
    left=Side(style="thin"),
    right=Side(style="thin"),
    top=Side(style="thin"),
    bottom=Side(style="thin"),
)

# Minimum similarity ratio (0.0–1.0) for fuzzy matching
FUZZY_THRESHOLD = 0.50

# Minimum similarity for glossary-description-based matching
GLOSSARY_MATCH_THRESHOLD = 0.55

# Minimum Jaccard similarity for sample-data-based matching
SAMPLE_DATA_MATCH_THRESHOLD = 0.30


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def compare_lineage(
    asis_bytes: bytes,
    tobe_bytes: bytes,
    asis_name: str = "",
    tobe_name: str = "",
    asis_workbook: str = "",
) -> bytes:
    """Compare two Data_Lineage Excel files and return comparison workbook bytes.

    Args:
        asis_bytes: Raw bytes of the Tableau Metadata Excel file.
        tobe_bytes: Raw bytes of the CDH Metadata Excel file.
        asis_name:  Display name for the Tableau report.
        tobe_name:  Display name for the CDH report.
        asis_workbook: Original Tableau workbook filename (e.g. MyWorkbook.twbx).

    Returns:
        Bytes of the comparison .xlsx file.

    Raises:
        ValueError: When Data_Lineage sheet is missing from either file.
    """
    asis_rows = _read_lineage_sheet(asis_bytes, label="Tableau")
    tobe_rows = _read_lineage_sheet(tobe_bytes, label="CDH")

    # Auto-generate business glossary descriptions for CDH columns that
    # are missing descriptions — ensures the Glossary Description Match
    # step has data to work with even if the user didn't supply a glossary.
    tobe_rows = _auto_enrich_glossary(tobe_rows, label="CDH")

    # Read Sample_Data sheets (if present) for sample-data matching
    asis_sample_rows = _read_sample_data_sheet(asis_bytes, label="Tableau")
    tobe_sample_rows = _read_sample_data_sheet(tobe_bytes, label="CDH")

    # If CDH has no sample data, auto-generate synthetic values from column
    # names + glossary descriptions so Sample Data Match can still operate.
    if not tobe_sample_rows:
        tobe_headers = list(tobe_rows[0].keys()) if tobe_rows else []
        _col_hdr = _find_header(tobe_headers, _COL_CANDIDATES["source_column"])
        _desc_hdr = _find_header(tobe_headers, _COL_CANDIDATES["description"])
        _tbl_hdr = _find_header(tobe_headers, _COL_CANDIDATES["source_table"])
        if _col_hdr:
            from utils.sample_data_generator import generate_cdh_sample_data
            tobe_sample_rows = generate_cdh_sample_data(
                tobe_rows, col_hdr=_col_hdr, desc_hdr=_desc_hdr, table_hdr=_tbl_hdr,
            )

    # Build lookup indices from the CDH lineage
    tobe_index = _build_index(tobe_rows)

    # Step 1: Exact match (Source Column + Table Name)
    comparison_rows = _match_columns(asis_rows, tobe_index)

    # Step 2: Table Description match for remaining unmatched rows
    comparison_rows = _apply_description_matching(asis_rows, tobe_rows, comparison_rows)

    # Step 3: Glossary Description match for remaining unmatched rows
    comparison_rows = _apply_glossary_matching(asis_rows, tobe_rows, comparison_rows)

    # Step 4: Sample Data match for remaining unmatched rows
    comparison_rows = _apply_sample_data_matching(
        asis_rows, tobe_rows, comparison_rows,
        asis_sample_rows, tobe_sample_rows,
    )

    # Step 5: Fuzzy match (Source Column + Table Name) for remaining unmatched rows
    comparison_rows = _apply_fuzzy_matching(asis_rows, tobe_index, comparison_rows)

    # Generate output workbook
    return _write_comparison_excel(
        comparison_rows,
        asis_name=asis_name,
        tobe_name=tobe_name,
        asis_workbook=asis_workbook,
        tobe_rows=tobe_rows,
        asis_rows=asis_rows,
        asis_sample_rows=asis_sample_rows,
        tobe_sample_rows=tobe_sample_rows,
    )


# ---------------------------------------------------------------------------
# Internals
# ---------------------------------------------------------------------------

# Column-name constants we look for (case-insensitive search)
_COL_CANDIDATES = {
    "source_column": ["Source Column", "Source Column Name", "New Column Name", "Column Name"],
    "field_name": ["Field Display Name", "Tableau Field Name", "Field Name"],
    "source_table": ["Source Table", "Table Name", "Source Table Name", "New Table Name"],
    "data_source": ["Data Source Name", "Data Source (Tableau)", "Data Source", "Data Product"],
    "internal_name": ["Field Internal Name", "Tableau Internal Name", "Internal Name"],
    "used_in_worksheets": ["Worksheet Name(s)", "Report Name(s)", "Used In Worksheets", "Used In Sheets", "Worksheets", "Report Name"],
    "description": ["Description", "Column Description", "Field Description"],
    "table_description": ["Table Description", "Table Desc", "Entity Description", "Object Description"],
    "dashboard_name": ["Dashboard Name(s)", "Dashboard Name", "Dashboard"],
}

# Minimum similarity for table-description-based matching
DESCRIPTION_MATCH_THRESHOLD = 0.50

# Table-name keywords → domain context for auto-generated table descriptions
_TABLE_DOMAIN_MAP = {
    "SUPPLY_CHAIN": "supply chain management",
    "COST": "cost accounting and financial analysis",
    "LOGISTICS": "logistics and transportation operations",
    "FINANCE": "financial reporting and accounting",
    "SALES": "sales transactions and revenue",
    "INVENTORY": "inventory management and stock control",
    "PROCUREMENT": "procurement and purchasing",
    "MATERIAL": "material master and product management",
    "CUSTOMER": "customer master data and relationships",
    "VENDOR": "vendor/supplier master data and relationships",
    "PLANT": "manufacturing plant and production facility",
    "ASSET": "fixed asset management and depreciation",
    "GL": "general ledger accounting",
    "AP": "accounts payable",
    "AR": "accounts receivable",
    "HR": "human resources and personnel",
    "ORDER": "order processing and fulfillment",
    "SHIPMENT": "shipment and delivery tracking",
    "TRANSPORT": "transportation planning and execution",
    "WAREHOUSE": "warehouse management and storage",
    "PROFIT": "profitability analysis and profit center accounting",
    "PROJECT": "project management and work breakdown",
    "BUDGET": "budgeting and financial planning",
    "TAX": "tax calculation and reporting",
    "CURRENCY": "currency conversion and exchange rates",
}


def _generate_table_description(table_name: str) -> str:
    """Generate a human-readable table description from a technical table name."""
    upper = table_name.upper().replace("-", "_")
    # Collect matching domain contexts
    domains = []
    for keyword, context in _TABLE_DOMAIN_MAP.items():
        if keyword in upper:
            domains.append(context)
    # Build human-readable name from tokens
    tokens = upper.split("_")
    readable = " ".join(t.capitalize() for t in tokens if t)
    if domains:
        domain_str = ", ".join(domains[:3])
        return f"{readable} — data table supporting {domain_str}."
    return f"{readable} — reference or transactional data table."


def _find_header(headers: List[str], candidates: List[str]) -> str | None:
    """Return the first header that matches any candidate (case-insensitive)."""
    lower_map = {h.lower().strip(): h for h in headers}
    for c in candidates:
        if c.lower().strip() in lower_map:
            return lower_map[c.lower().strip()]
    return None


def _read_lineage_sheet(file_bytes: bytes, *, label: str) -> List[Dict[str, str]]:
    """Read the Data_Lineage sheet from an Excel workbook.

    Returns a list of row-dicts with original header names as keys.
    """
    wb = load_workbook(filename=io.BytesIO(file_bytes), read_only=True, data_only=True)

    # Find the Data_Lineage sheet (flexible naming)
    target_ws = None
    for ws_name in wb.sheetnames:
        if ws_name.lower().replace(" ", "_").replace("-", "_") in (
            "data_lineage", "datalineage", "data lineage"
        ):
            target_ws = wb[ws_name]
            break

    if target_ws is None:
        wb.close()
        raise ValueError(
            f"The {label} file does not contain a 'Data_Lineage' sheet. "
            f"Available sheets: {', '.join(wb.sheetnames)}"
        )

    rows: List[Dict[str, str]] = []
    headers: List[str] = []
    for i, row in enumerate(target_ws.iter_rows(values_only=True)):
        if i == 0:
            headers = [str(h).strip() if h else f"Col_{j}" for j, h in enumerate(row)]
            continue
        row_dict = {}
        for j, val in enumerate(row):
            if j < len(headers):
                row_dict[headers[j]] = str(val).strip() if val is not None else ""
        if any(row_dict.values()):
            rows.append(row_dict)

    wb.close()
    logger.info("%s lineage: %d rows, headers=%s", label, len(rows), headers)
    if rows:
        logger.info("%s first row sample: %s", label, rows[0])
    return rows


def _auto_enrich_glossary(
    rows: List[Dict[str, str]],
    *,
    label: str = "CDH",
) -> List[Dict[str, str]]:
    """Auto-generate business glossary descriptions for rows missing them.

    If the rows already have a populated 'Column Description' (or equivalent)
    field for most entries, they are returned as-is.  Otherwise, the built-in
    glossary generator fills in missing descriptions from column/table names.

    Also ensures a description header exists in every row-dict (adds one if
    the CDH file had no description column at all).
    """
    if not rows:
        return rows

    from utils.glossary_generator import enrich_glossary

    headers = list(rows[0].keys())
    desc_hdr = _find_header(headers, _COL_CANDIDATES["description"])
    col_hdr = _find_header(headers, _COL_CANDIDATES["source_column"])
    table_hdr = _find_header(headers, _COL_CANDIDATES["source_table"])

    # If there's no description column at all, inject one
    if not desc_hdr:
        desc_hdr = "Column Description"
        for row in rows:
            row[desc_hdr] = ""
        logger.info("%s: no description column found — injecting '%s'", label, desc_hdr)

    if not col_hdr:
        logger.info("%s: no source-column header found — skipping glossary enrichment", label)
        return rows

    # Count how many already have descriptions
    total = len(rows)
    existing = sum(1 for r in rows if r.get(desc_hdr, "").strip())
    pct_filled = (existing / total * 100) if total else 0

    logger.info(
        "%s glossary: %d/%d rows (%.0f%%) already have descriptions",
        label, existing, total, pct_filled,
    )

    # Always try to fill gaps (even if most are filled, some may be missing)
    generated = enrich_glossary(rows, col_hdr, desc_hdr, table_hdr)
    logger.info(
        "%s glossary: auto-generated %d new descriptions (total now: %d/%d)",
        label, generated, existing + generated, total,
    )

    # --- Auto-generate Table Description when missing ---
    tbl_desc_hdr = _find_header(headers, _COL_CANDIDATES["table_description"])
    if not tbl_desc_hdr:
        tbl_desc_hdr = "Table Description"
        for row in rows:
            row[tbl_desc_hdr] = ""
    # Fill empty table descriptions from table names
    if table_hdr:
        filled_count = 0
        for row in rows:
            if not row.get(tbl_desc_hdr, "").strip():
                tbl_name = row.get(table_hdr, "").strip()
                if tbl_name:
                    row[tbl_desc_hdr] = _generate_table_description(tbl_name)
                    filled_count += 1
        if filled_count:
            logger.info("%s: auto-generated %d table descriptions", label, filled_count)

    return rows


def _read_sample_data_sheet(
    file_bytes: bytes, *, label: str
) -> List[Dict[str, str]]:
    """Read the Sample_Data sheet from an Excel workbook.

    Returns a list of row-dicts (same format as _read_lineage_sheet).
    Returns an empty list if the sheet does not exist.
    """
    wb = load_workbook(filename=io.BytesIO(file_bytes), read_only=True, data_only=True)

    target_ws = None
    for ws_name in wb.sheetnames:
        normalised = ws_name.lower().replace(" ", "_").replace("-", "_")
        if normalised in ("sample_data", "sampledata", "report_sample_data"):
            target_ws = wb[ws_name]
            break

    if target_ws is None:
        wb.close()
        logger.info("%s: no Sample_Data sheet found — sample data matching will be skipped", label)
        return []

    rows: List[Dict[str, str]] = []
    headers: List[str] = []
    for i, row in enumerate(target_ws.iter_rows(values_only=True)):
        if i == 0:
            headers = [str(h).strip() if h else f"Col_{j}" for j, h in enumerate(row)]
            continue
        row_dict = {}
        for j, val in enumerate(row):
            if j < len(headers):
                row_dict[headers[j]] = str(val).strip() if val is not None else ""
        if any(row_dict.values()):
            rows.append(row_dict)

    wb.close()
    logger.info("%s sample data: %d rows, %d columns", label, len(rows), len(headers))
    return rows


def _build_value_fingerprints(
    sample_rows: List[Dict[str, str]],
) -> Dict[str, set]:
    """Build a mapping of column_name → set of distinct non-empty values.

    Skips internal metadata columns (__source_file__, __source_table__, etc.).
    All values are lowercased and stripped for comparison robustness.
    """
    _SKIP_COLS = {
        "__source_file__", "__source_table__", "__sheet_name__",
        "Source File", "Source Table", "Source Sheet",
    }
    fingerprints: Dict[str, set] = {}

    for row in sample_rows:
        for col, val in row.items():
            if col in _SKIP_COLS or not val:
                continue
            normalised_val = val.lower().strip()
            if not normalised_val or normalised_val == "none":
                continue
            fingerprints.setdefault(col, set()).add(normalised_val)

    logger.info("Value fingerprints: %d columns with data", len(fingerprints))
    return fingerprints


def _apply_sample_data_matching(
    asis_rows: List[Dict[str, str]],
    tobe_rows: List[Dict[str, str]],
    comparison_rows: List[Dict[str, str]],
    asis_sample_rows: List[Dict[str, str]],
    tobe_sample_rows: List[Dict[str, str]],
) -> List[Dict[str, str]]:
    """Match unmatched rows by comparing sample data value overlap.

    For each unmatched Report column, computes the Jaccard similarity
    between its distinct sample values and every CDH column's distinct
    sample values.  Requires both files to have a Sample_Data sheet.
    """
    if not asis_sample_rows or not tobe_sample_rows:
        logger.info("Sample data matching skipped: one or both files lack Sample_Data")
        return comparison_rows

    unmatched = [(i, r) for i, r in enumerate(comparison_rows) if r["Match Found"] == "No"]
    if not unmatched:
        return comparison_rows

    # Build fingerprints
    asis_fps = _build_value_fingerprints(asis_sample_rows)
    tobe_fps = _build_value_fingerprints(tobe_sample_rows)

    if not asis_fps or not tobe_fps:
        logger.info("Sample data matching skipped: empty fingerprints")
        return comparison_rows

    # Resolve CDH header names so we can populate match results
    tobe_headers = list(tobe_rows[0].keys()) if tobe_rows else []
    tobe_src_col_hdr = _find_header(tobe_headers, _COL_CANDIDATES["source_column"])
    tobe_table_hdr = _find_header(tobe_headers, _COL_CANDIDATES["source_table"])

    # Build CDH column-name → row lookup for result population
    tobe_by_col_lower: Dict[str, Dict] = {}
    for row in tobe_rows:
        c = row.get(tobe_src_col_hdr, "") if tobe_src_col_hdr else ""
        if c:
            tobe_by_col_lower.setdefault(c.lower(), row)

    # Resolve as-is header names
    asis_headers = list(asis_rows[0].keys()) if asis_rows else []
    asis_src_col_hdr = _find_header(asis_headers, _COL_CANDIDATES["source_column"])
    asis_field_hdr = _find_header(asis_headers, _COL_CANDIDATES["field_name"])

    logger.info(
        "Sample data matching: %d report columns, %d CDH columns, %d unmatched",
        len(asis_fps), len(tobe_fps), len(unmatched),
    )

    matched_count = 0
    for idx, _comp_row in unmatched:
        asis_row = asis_rows[idx]
        src_col = asis_row.get(asis_src_col_hdr, "") if asis_src_col_hdr else ""
        field_name = asis_row.get(asis_field_hdr, "") if asis_field_hdr else ""
        search_name = src_col or field_name
        if not search_name:
            continue

        # Find the report column's value fingerprint (try exact, then case-insensitive)
        asis_vals = asis_fps.get(search_name)
        if asis_vals is None:
            # Try matching by field display name or case-insensitive column name
            for fp_col, fp_vals in asis_fps.items():
                if fp_col.lower() == search_name.lower():
                    asis_vals = fp_vals
                    break
        if not asis_vals:
            continue

        # Score against every CDH column's fingerprint
        best_jaccard = 0.0
        best_cdh_col = None
        for cdh_col, cdh_vals in tobe_fps.items():
            intersection = asis_vals & cdh_vals
            union = asis_vals | cdh_vals
            jaccard = len(intersection) / len(union) if union else 0.0
            if jaccard > best_jaccard:
                best_jaccard = jaccard
                best_cdh_col = cdh_col

        if best_jaccard >= SAMPLE_DATA_MATCH_THRESHOLD and best_cdh_col:
            # Resolve the CDH row for the matched column
            cdh_row = tobe_by_col_lower.get(best_cdh_col.lower())
            comparison_rows[idx]["Match Found"] = "Yes"
            comparison_rows[idx]["Match Method"] = "Sample Data Match"
            comparison_rows[idx]["Match %"] = f"{best_jaccard * 100:.0f}"
            comparison_rows[idx]["CDH Column Name"] = (
                cdh_row.get(tobe_src_col_hdr, "") if cdh_row and tobe_src_col_hdr else best_cdh_col
            )
            comparison_rows[idx]["CDH Table Name"] = (
                cdh_row.get(tobe_table_hdr, "") if cdh_row and tobe_table_hdr else ""
            )
            matched_count += 1
            logger.info(
                "Sample data match: '%s' -> CDH '%s' (Jaccard=%.0f%%)",
                search_name, best_cdh_col, best_jaccard * 100,
            )

    logger.info(
        "Sample data matching: %d new matches from %d unmatched rows",
        matched_count, len(unmatched),
    )
    return comparison_rows


def _build_index(rows: List[Dict[str, str]]) -> Dict[str, Dict[str, Any]]:
    """Build lookup dictionaries from the NEW lineage rows.

    Returns a dict with keys:
      - 'by_col_table':       (source_col, source_table) → row-dict
      - 'by_col_table_lower': (source_col.lower(), source_table.lower()) → row
      - 'by_source_col':      source_col → row (fallback, column-only)
      - 'by_source_col_lower': source_col.lower() → row (fallback)
    """
    if not rows:
        logger.warning("_build_index: no rows to index")
        return {"by_col_table": {}, "by_col_table_lower": {},
                "by_source_col": {}, "by_source_col_lower": {},
                "fuzzy_col_list": [], "fuzzy_ct_list": []}

    headers = list(rows[0].keys())
    src_col_hdr = _find_header(headers, _COL_CANDIDATES["source_column"])
    table_hdr = _find_header(headers, _COL_CANDIDATES["source_table"])
    logger.info("_build_index: headers=%s, src_col_hdr=%r, table_hdr=%r",
                headers, src_col_hdr, table_hdr)

    by_col_table: Dict[Tuple[str, str], Dict] = {}
    by_col_table_lower: Dict[Tuple[str, str], Dict] = {}
    by_source_col: Dict[str, Dict] = {}
    by_source_col_lower: Dict[str, Dict] = {}

    for row in rows:
        sc = row.get(src_col_hdr, "") if src_col_hdr else ""
        st = row.get(table_hdr, "") if table_hdr else ""

        # Composite key: (source column, source table) for exact lookups
        if sc and st:
            key = (sc, st)
            if key not in by_col_table:
                by_col_table[key] = row
            # Case-insensitive variant for fallback matching
            lower_key = (sc.lower(), st.lower())
            by_col_table_lower.setdefault(lower_key, row)

        # Column-only fallback for when table name is missing
        if sc and sc not in by_source_col:
            by_source_col[sc] = row
        if sc:
            by_source_col_lower.setdefault(sc.lower(), row)

    # Build flat lists for fuzzy matching (deduplicated by lowercase key)
    fuzzy_col_list = []   # [(source_col_lower, row), ...]
    fuzzy_ct_list = []    # [(source_col_lower, source_table_lower, row), ...]
    seen_fuzzy_col = set()
    seen_fuzzy_ct = set()
    for row in rows:
        sc = row.get(src_col_hdr, "") if src_col_hdr else ""
        st = row.get(table_hdr, "") if table_hdr else ""
        if sc:
            sc_low = sc.lower()
            if sc_low not in seen_fuzzy_col:
                seen_fuzzy_col.add(sc_low)
                fuzzy_col_list.append((sc_low, row))
            # Combined column+table key for weighted fuzzy comparison
            if st:
                ct_key = (sc_low, st.lower())
                if ct_key not in seen_fuzzy_ct:
                    seen_fuzzy_ct.add(ct_key)
                    fuzzy_ct_list.append((sc_low, st.lower(), row))

    logger.info("_build_index: by_col_table=%d keys, by_source_col=%d keys, fuzzy_col=%d, fuzzy_ct=%d",
                len(by_col_table), len(by_source_col), len(fuzzy_col_list), len(fuzzy_ct_list))
    if by_col_table:
        sample_keys = list(by_col_table.keys())[:5]
        logger.info("_build_index: sample composite keys: %s", sample_keys)
    if by_source_col:
        sample_cols = list(by_source_col.keys())[:5]
        logger.info("_build_index: sample source cols: %s", sample_cols)

    return {
        "by_col_table": by_col_table,
        "by_col_table_lower": by_col_table_lower,
        "by_source_col": by_source_col,
        "by_source_col_lower": by_source_col_lower,
        "fuzzy_col_list": fuzzy_col_list,
        "fuzzy_ct_list": fuzzy_ct_list,
    }


def _match_columns(
    asis_rows: List[Dict[str, str]],
    tobe_index: Dict[str, Dict],
) -> List[Dict[str, str]]:
    """Match each Tableau column to the CDH lineage, return comparison rows.

    Step 1: Exact (Source Column + Table Name) — case-insensitive.
    """
    if not asis_rows:
        return []

    headers = list(asis_rows[0].keys())
    leg_src_col_hdr = _find_header(headers, _COL_CANDIDATES["source_column"])
    leg_field_hdr = _find_header(headers, _COL_CANDIDATES["field_name"])
    leg_table_hdr = _find_header(headers, _COL_CANDIDATES["source_table"])
    leg_ds_hdr = _find_header(headers, _COL_CANDIDATES["data_source"])
    leg_ws_hdr = _find_header(headers, _COL_CANDIDATES["used_in_worksheets"])
    leg_db_hdr = _find_header(headers, _COL_CANDIDATES["dashboard_name"])
    logger.info("_match_columns: as-is headers=%s", headers)
    logger.info("_match_columns: resolved – src_col=%r, field=%r, table=%r, ds=%r, ws=%r, db=%r",
                leg_src_col_hdr, leg_field_hdr, leg_table_hdr, leg_ds_hdr, leg_ws_hdr, leg_db_hdr)

    # Determine CDH header names from the first available indexed row
    sample_tobe_row = None
    for bucket in ("by_col_table", "by_source_col"):
        if tobe_index[bucket]:
            sample_tobe_row = next(iter(tobe_index[bucket].values()))
            break
    tobe_headers = list(sample_tobe_row.keys()) if sample_tobe_row else []
    # Resolve the CDH-side header names using candidate matching
    tobe_src_col_hdr = _find_header(tobe_headers, _COL_CANDIDATES["source_column"])
    tobe_table_hdr = _find_header(tobe_headers, _COL_CANDIDATES["source_table"])
    tobe_ds_hdr = _find_header(tobe_headers, _COL_CANDIDATES["data_source"])
    tobe_desc_hdr = _find_header(tobe_headers, _COL_CANDIDATES["description"])

    results: List[Dict[str, str]] = []

    for leg_row in asis_rows:
        leg_src_col = leg_row.get(leg_src_col_hdr, "") if leg_src_col_hdr else ""
        leg_field = leg_row.get(leg_field_hdr, "") if leg_field_hdr else ""
        leg_table = leg_row.get(leg_table_hdr, "") if leg_table_hdr else ""
        leg_ds = leg_row.get(leg_ds_hdr, "") if leg_ds_hdr else ""
        leg_ws = leg_row.get(leg_ws_hdr, "") if leg_ws_hdr else ""
        leg_db = leg_row.get(leg_db_hdr, "") if leg_db_hdr else ""

        match_row = None
        match_method = "No Match"
        match_pct = "0"

        # --- Step 1: Exact (Source Column + Table Name) case-insensitive ---
        if leg_src_col and leg_table:
            # Try exact case first
            key = (leg_src_col, leg_table)
            if key in tobe_index["by_col_table"]:
                match_row = tobe_index["by_col_table"][key]
                match_method = "Exact (Column + Table)"
                match_pct = "100"
            else:
                # Case-insensitive fallback
                lower_key = (leg_src_col.lower(), leg_table.lower())
                if lower_key in tobe_index["by_col_table_lower"]:
                    match_row = tobe_index["by_col_table_lower"][lower_key]
                    match_method = "Exact (Column + Table)"
                    match_pct = "100"

        # Populate CDH fields
        if match_row:
            tobe_col = match_row.get(tobe_src_col_hdr, "") if tobe_src_col_hdr else ""
            tobe_table = match_row.get(tobe_table_hdr, "") if tobe_table_hdr else ""
            tobe_ds = match_row.get(tobe_ds_hdr, "") if tobe_ds_hdr else ""
            tobe_desc = match_row.get(tobe_desc_hdr, "") if tobe_desc_hdr else ""
        else:
            tobe_col = tobe_table = tobe_ds = tobe_desc = ""

        results.append({
            "Tableau Dashboard Name(s)": leg_db,
            "Tableau Worksheet Name(s)": leg_ws,
            "Tableau Field Name": leg_field or leg_src_col,
            "Tableau Source Column": leg_src_col,
            "Tableau Source Table": leg_table,
            "Tableau Data Source Name": leg_ds,
            "Match Found": "Yes" if match_row else "No",
            "Match Method": match_method,
            "Match %": match_pct,
            "CDH Column Name": tobe_col,
            "CDH Table Name": tobe_table,
        })

    return results


def _apply_fuzzy_matching(
    asis_rows: List[Dict[str, str]],
    tobe_index: Dict[str, Dict],
    comparison_rows: List[Dict[str, str]],
) -> List[Dict[str, str]]:
    """Step 3: Fuzzy match unmatched rows on (Source Column + Table Name).

    Weighted score: 70% column similarity + 30% table similarity.
    Requires >= 80% to qualify.
    """
    if not asis_rows or not tobe_index.get("fuzzy_ct_list"):
        return comparison_rows

    unmatched = [(i, r) for i, r in enumerate(comparison_rows) if r["Match Found"] == "No"]
    if not unmatched:
        return comparison_rows

    asis_headers = list(asis_rows[0].keys())
    asis_src_col_hdr = _find_header(asis_headers, _COL_CANDIDATES["source_column"])
    asis_table_hdr = _find_header(asis_headers, _COL_CANDIDATES["source_table"])

    # Resolve CDH headers from index
    sample_tobe_row = None
    for bucket in ("by_col_table", "by_source_col"):
        if tobe_index[bucket]:
            sample_tobe_row = next(iter(tobe_index[bucket].values()))
            break
    tobe_headers = list(sample_tobe_row.keys()) if sample_tobe_row else []
    tobe_src_col_hdr = _find_header(tobe_headers, _COL_CANDIDATES["source_column"])
    tobe_table_hdr = _find_header(tobe_headers, _COL_CANDIDATES["source_table"])
    tobe_ds_hdr = _find_header(tobe_headers, _COL_CANDIDATES["data_source"])
    tobe_desc_hdr = _find_header(tobe_headers, _COL_CANDIDATES["description"])

    matched_count = 0
    for idx, _comp_row in unmatched:
        asis_row = asis_rows[idx]
        leg_src_col = asis_row.get(asis_src_col_hdr, "") if asis_src_col_hdr else ""
        leg_table = asis_row.get(asis_table_hdr, "") if asis_table_hdr else ""

        if not leg_src_col or not leg_table:
            continue

        leg_col_low = leg_src_col.lower()
        leg_tbl_low = leg_table.lower()

        best_ratio = 0.0
        best_row = None
        for tobe_col_low, tobe_tbl_low, row in tobe_index["fuzzy_ct_list"]:
            col_ratio = SequenceMatcher(None, leg_col_low, tobe_col_low).ratio()
            tbl_ratio = SequenceMatcher(None, leg_tbl_low, tobe_tbl_low).ratio()
            combined = col_ratio * 0.7 + tbl_ratio * 0.3
            if combined > best_ratio:
                best_ratio = combined
                best_row = row

        if best_ratio >= FUZZY_THRESHOLD and best_row:
            comparison_rows[idx]["Match Found"] = "Yes"
            comparison_rows[idx]["Match Method"] = "Fuzzy (Column + Table)"
            comparison_rows[idx]["Match %"] = f"{best_ratio * 100:.0f}"
            comparison_rows[idx]["CDH Column Name"] = (
                best_row.get(tobe_src_col_hdr, "") if tobe_src_col_hdr else ""
            )
            comparison_rows[idx]["CDH Table Name"] = (
                best_row.get(tobe_table_hdr, "") if tobe_table_hdr else ""
            )
            matched_count += 1

    logger.info("Fuzzy matching: %d new matches from %d unmatched rows",
                matched_count, len(unmatched))
    return comparison_rows


def _apply_description_matching(
    asis_rows: List[Dict[str, str]],
    tobe_rows: List[Dict[str, str]],
    comparison_rows: List[Dict[str, str]],
) -> List[Dict[str, str]]:
    """Match unmatched rows using CDH table descriptions + exact column names.

    Strategy:
      1. From the CDH file, collect each table's description (from the
         "Table Description" column).
      2. For each unmatched Tableau row, compare the Tableau table name
         against every CDH table description using:
           a) Substring containment (Tableau name found within description)
           b) Token-overlap (Jaccard similarity of words)
           c) Fuzzy SequenceMatcher on name vs description keywords
      3. If the best score >= 80%, consider the tables matched.
      4. Within matched tables, require an **exact** column-name match
         (case-insensitive).
    """
    if not asis_rows or not tobe_rows:
        return comparison_rows

    # Identify unmatched rows
    unmatched = [(i, r) for i, r in enumerate(comparison_rows) if r["Match Found"] == "No"]
    if not unmatched:
        return comparison_rows

    # Resolve headers
    asis_headers = list(asis_rows[0].keys())
    tobe_headers = list(tobe_rows[0].keys())

    asis_src_col_hdr = _find_header(asis_headers, _COL_CANDIDATES["source_column"])
    asis_table_hdr = _find_header(asis_headers, _COL_CANDIDATES["source_table"])
    tobe_src_col_hdr = _find_header(tobe_headers, _COL_CANDIDATES["source_column"])
    tobe_table_hdr = _find_header(tobe_headers, _COL_CANDIDATES["source_table"])
    tobe_ds_hdr = _find_header(tobe_headers, _COL_CANDIDATES["data_source"])
    tobe_field_desc_hdr = _find_header(tobe_headers, _COL_CANDIDATES["description"])
    tobe_table_desc_hdr = _find_header(tobe_headers, _COL_CANDIDATES["table_description"])

    # If CDH has no table description column, skip this step
    if not tobe_table_desc_hdr:
        logger.info("Description matching skipped: no 'Table Description' column in CDH")
        return comparison_rows

    # Build CDH lookup: table_name -> table_description
    tobe_table_descs: Dict[str, str] = {}
    for row in tobe_rows:
        t_name = row.get(tobe_table_hdr, "") if tobe_table_hdr else ""
        t_desc = row.get(tobe_table_desc_hdr, "") if tobe_table_desc_hdr else ""
        if t_name and t_desc and t_name not in tobe_table_descs:
            tobe_table_descs[t_name] = t_desc

    if not tobe_table_descs:
        logger.info("Description matching skipped: CDH table descriptions are all empty")
        return comparison_rows

    logger.info("Description matching: %d CDH tables with descriptions", len(tobe_table_descs))

    # Build CDH lookup: (table_name, column_lower) -> row
    tobe_by_table_col: Dict[Tuple[str, str], Dict] = {}
    for row in tobe_rows:
        t = row.get(tobe_table_hdr, "") if tobe_table_hdr else ""
        c = row.get(tobe_src_col_hdr, "") if tobe_src_col_hdr else ""
        if t and c:
            tobe_by_table_col.setdefault((t, c.lower()), row)

    matched_count = 0
    for idx, _comp_row in unmatched:
        asis_row = asis_rows[idx]
        asis_table = asis_row.get(asis_table_hdr, "") if asis_table_hdr else ""
        asis_col = asis_row.get(asis_src_col_hdr, "") if asis_src_col_hdr else ""

        if not asis_table or not asis_col:
            continue

        # Score each CDH table description against the source table name
        best_tobe_table = None
        best_score = 0.0

        asis_name_lower = asis_table.lower()
        # Tokenize the table name for Jaccard overlap comparison
        asis_tokens = set(asis_name_lower.replace("_", " ").replace("-", " ").split())

        for tobe_tbl, tobe_desc in tobe_table_descs.items():
            desc_lower = tobe_desc.lower()
            desc_tokens = set(desc_lower.replace("_", " ").replace("-", " ").split())

            # (a) Substring: source table name appears directly in description
            if asis_name_lower in desc_lower:
                score = 0.95
            # (b) Token overlap (Jaccard) + SequenceMatcher fallback
            elif asis_tokens and desc_tokens:
                intersection = asis_tokens & desc_tokens
                union = asis_tokens | desc_tokens
                jaccard = len(intersection) / len(union) if union else 0.0
                # Also check SequenceMatcher for partial-word matches
                seq_ratio = SequenceMatcher(None, asis_name_lower, desc_lower).ratio()
                score = max(jaccard, seq_ratio)
            else:
                score = SequenceMatcher(None, asis_name_lower, desc_lower).ratio()

            if score > best_score:
                best_score = score
                best_tobe_table = tobe_tbl

        if best_score < DESCRIPTION_MATCH_THRESHOLD or best_tobe_table is None:
            continue

        # Exact column-name match within the description-matched table
        key = (best_tobe_table, asis_col.lower())
        if key in tobe_by_table_col:
            tobe_row = tobe_by_table_col[key]
            comparison_rows[idx]["Match Found"] = "Yes"
            comparison_rows[idx]["Match Method"] = (
                "Table Description + Exact Column"
            )
            comparison_rows[idx]["Match %"] = f"{best_score * 100:.0f}"
            comparison_rows[idx]["CDH Column Name"] = (
                tobe_row.get(tobe_src_col_hdr, "") if tobe_src_col_hdr else ""
            )
            comparison_rows[idx]["CDH Table Name"] = (
                tobe_row.get(tobe_table_hdr, "") if tobe_table_hdr else ""
            )
            matched_count += 1
            logger.info(
                "Description match: '%s' -> '%s' (%.0f%%) col='%s'",
                asis_table, best_tobe_table, best_score * 100, asis_col,
            )

    logger.info("Description matching: %d new matches from %d unmatched rows",
                matched_count, len(unmatched))
    return comparison_rows


# ---------------------------------------------------------------------------
# Glossary-based matching helpers
# ---------------------------------------------------------------------------
_STOP_WORDS: Set[str] = {
    "a", "an", "the", "of", "in", "for", "to", "and", "or", "is", "it",
    "on", "at", "by", "as", "with", "from", "that", "this", "be", "are",
    "was", "were", "not", "no", "but", "its", "has", "have", "had", "do",
    "does", "did", "will", "can", "may", "each", "per", "used", "within",
    "which", "into", "such", "e.g.", "eg", "etc", "vs",
}


def _tokenize(text: str) -> Set[str]:
    """Normalise and tokenise a text string into meaningful lowercase words.

    Splits on underscores, hyphens, spaces, punctuation; drops stop-words
    and single-character tokens.
    """
    words = _re_module.split(r"[_\-\s/,;:.()]+", text.lower())
    return {w for w in words if len(w) > 1 and w not in _STOP_WORDS}


def _normalise_name(name: str) -> str:
    """Turn a technical name like FISCAL_YEAR_PERIOD into 'fiscal year period'."""
    return _re_module.sub(r"[_\-]+", " ", name).lower().strip()


def _glossary_score(
    field_name: str,
    field_desc: str,
    cdh_col_name: str,
    cdh_col_desc: str,
) -> float:
    """Compute a similarity score between a report field and a CDH glossary entry.

    Scoring components (best of several signals, 0.0–1.0):
      1. Normalised name match:  report field display name ↔ CDH column name
         (e.g. "Fiscal Year" vs "FISCAL_YEAR" → both become "fiscal year").
      2. Field-name-in-description: tokens of the report field name appear
         in the CDH column description.
      3. Description-to-description: token overlap between the report
         field description and the CDH column description (Jaccard).
      4. Column-name-in-field: CDH column name tokens appear within
         the report field display name.
    """
    norm_field = _normalise_name(field_name)
    norm_cdh = _normalise_name(cdh_col_name)

    scores: List[float] = []

    # 1. Direct normalised-name similarity (SequenceMatcher)
    if norm_field and norm_cdh:
        scores.append(SequenceMatcher(None, norm_field, norm_cdh).ratio())

    # 2. Field-name tokens found within CDH column description
    if field_name and cdh_col_desc:
        field_tokens = _tokenize(field_name)
        desc_tokens = _tokenize(cdh_col_desc)
        if field_tokens and desc_tokens:
            overlap = field_tokens & desc_tokens
            # Weighted towards recall on the field-name side
            precision = len(overlap) / len(field_tokens) if field_tokens else 0
            scores.append(precision * 0.9)  # cap slightly below 1.0

    # 3. Description-to-description (Jaccard) when both sides have descriptions
    if field_desc and cdh_col_desc:
        fd_tokens = _tokenize(field_desc)
        cd_tokens = _tokenize(cdh_col_desc)
        if fd_tokens and cd_tokens:
            intersection = fd_tokens & cd_tokens
            union = fd_tokens | cd_tokens
            jaccard = len(intersection) / len(union) if union else 0
            scores.append(jaccard)

    # 4. CDH column-name tokens in the field display name
    if norm_cdh and norm_field:
        cdh_tokens = set(norm_cdh.split())
        field_tokens_2 = set(norm_field.split())
        if cdh_tokens and field_tokens_2:
            overlap2 = cdh_tokens & field_tokens_2
            scores.append(len(overlap2) / len(cdh_tokens) if cdh_tokens else 0)

    return max(scores) if scores else 0.0


def _apply_glossary_matching(
    asis_rows: List[Dict[str, str]],
    tobe_rows: List[Dict[str, str]],
    comparison_rows: List[Dict[str, str]],
) -> List[Dict[str, str]]:
    """Match unmatched rows using CDH business-glossary column descriptions.

    For each unmatched report field, the function compares:
      - Report Field Display Name and Field Description
      - Against every CDH Column Name and Column Description

    Uses normalised-name matching, token overlap, and description-to-
    description Jaccard similarity.  Requires a combined score >=
    GLOSSARY_MATCH_THRESHOLD.
    """
    if not asis_rows or not tobe_rows:
        return comparison_rows

    unmatched = [(i, r) for i, r in enumerate(comparison_rows) if r["Match Found"] == "No"]
    if not unmatched:
        return comparison_rows

    # Resolve headers for both sides
    asis_headers = list(asis_rows[0].keys())
    tobe_headers = list(tobe_rows[0].keys())

    asis_field_hdr = _find_header(asis_headers, _COL_CANDIDATES["field_name"])
    asis_src_col_hdr = _find_header(asis_headers, _COL_CANDIDATES["source_column"])
    asis_desc_hdr = _find_header(asis_headers, _COL_CANDIDATES["description"])
    tobe_src_col_hdr = _find_header(tobe_headers, _COL_CANDIDATES["source_column"])
    tobe_table_hdr = _find_header(tobe_headers, _COL_CANDIDATES["source_table"])
    tobe_desc_hdr = _find_header(tobe_headers, _COL_CANDIDATES["description"])

    # CDH must have a column description column for glossary matching
    if not tobe_desc_hdr:
        logger.info("Glossary matching skipped: no Column Description column in CDH")
        return comparison_rows

    # Pre-build CDH glossary entries: list of (col_name, col_desc, table_name, row)
    glossary_entries: List[Tuple[str, str, str, Dict]] = []
    for row in tobe_rows:
        col = row.get(tobe_src_col_hdr, "") if tobe_src_col_hdr else ""
        desc = row.get(tobe_desc_hdr, "") if tobe_desc_hdr else ""
        tbl = row.get(tobe_table_hdr, "") if tobe_table_hdr else ""
        if col and desc:
            glossary_entries.append((col, desc, tbl, row))

    if not glossary_entries:
        logger.info("Glossary matching skipped: CDH column descriptions are all empty")
        return comparison_rows

    logger.info("Glossary matching: %d CDH entries with descriptions, %d unmatched rows",
                len(glossary_entries), len(unmatched))

    matched_count = 0
    for idx, _comp_row in unmatched:
        asis_row = asis_rows[idx]
        field_name = asis_row.get(asis_field_hdr, "") if asis_field_hdr else ""
        src_col = asis_row.get(asis_src_col_hdr, "") if asis_src_col_hdr else ""
        field_desc = asis_row.get(asis_desc_hdr, "") if asis_desc_hdr else ""

        # Use field display name primarily; fall back to source column name
        search_name = field_name or src_col
        if not search_name:
            continue

        best_score = 0.0
        best_entry = None
        for cdh_col, cdh_desc, cdh_tbl, cdh_row in glossary_entries:
            score = _glossary_score(search_name, field_desc, cdh_col, cdh_desc)
            if score > best_score:
                best_score = score
                best_entry = (cdh_col, cdh_tbl, cdh_row)

        if best_score >= GLOSSARY_MATCH_THRESHOLD and best_entry:
            _col, _tbl, _row = best_entry
            comparison_rows[idx]["Match Found"] = "Yes"
            comparison_rows[idx]["Match Method"] = "Glossary Description Match"
            comparison_rows[idx]["Match %"] = f"{best_score * 100:.0f}"
            comparison_rows[idx]["CDH Column Name"] = (
                _row.get(tobe_src_col_hdr, "") if tobe_src_col_hdr else ""
            )
            comparison_rows[idx]["CDH Table Name"] = (
                _row.get(tobe_table_hdr, "") if tobe_table_hdr else ""
            )
            matched_count += 1
            logger.info(
                "Glossary match: field='%s' -> CDH col='%s' table='%s' (%.0f%%)",
                search_name, _col, _tbl, best_score * 100,
            )

    logger.info("Glossary matching: %d new matches from %d unmatched rows",
                matched_count, len(unmatched))
    return comparison_rows


def _apply_ai_matching(
    asis_rows: List[Dict[str, str]],
    tobe_rows: List[Dict[str, str]],
    comparison_rows: List[Dict[str, str]],
) -> List[Dict[str, str]]:
    """Post-process unmatched rows using AI-based table description matching.

    Uses OpenAI to infer table descriptions, match Tableau tables to CDH
    tables (>= 80% confidence), then applies exact column-name matching
    within the mapped tables.

    Requires OPENAI_API_KEY environment variable. Gracefully skips if
    the key is not set or the openai package is missing.
    """
    if not os.environ.get("OPENAI_API_KEY"):
        return comparison_rows

    # Identify unmatched rows
    unmatched = [(i, r) for i, r in enumerate(comparison_rows) if r["Match Found"] == "No"]
    if not unmatched:
        return comparison_rows

    if not asis_rows or not tobe_rows:
        return comparison_rows

    # Resolve headers for both sides
    asis_headers = list(asis_rows[0].keys())
    tobe_headers = list(tobe_rows[0].keys())

    asis_src_col_hdr = _find_header(asis_headers, _COL_CANDIDATES["source_column"])
    asis_table_hdr = _find_header(asis_headers, _COL_CANDIDATES["source_table"])
    tobe_src_col_hdr = _find_header(tobe_headers, _COL_CANDIDATES["source_column"])
    tobe_table_hdr = _find_header(tobe_headers, _COL_CANDIDATES["source_table"])
    tobe_ds_hdr = _find_header(tobe_headers, _COL_CANDIDATES["data_source"])
    tobe_desc_hdr = _find_header(tobe_headers, _COL_CANDIDATES["description"])

    # Collect unique table names from *unmatched* Tableau rows
    unmatched_asis_tables = list({
        asis_rows[i].get(asis_table_hdr, "")
        for i, _ in unmatched
        if asis_table_hdr and asis_rows[i].get(asis_table_hdr, "")
    })
    tobe_tables_unique = list({
        row.get(tobe_table_hdr, "")
        for row in tobe_rows
        if tobe_table_hdr and row.get(tobe_table_hdr, "")
    })

    if not unmatched_asis_tables or not tobe_tables_unique:
        return comparison_rows

    # Call AI to build table-description-based mapping
    try:
        from utils.ai_matcher import build_ai_table_mapping
    except ImportError:
        logger.warning("Could not import ai_matcher – skipping AI matching")
        return comparison_rows

    table_mapping = build_ai_table_mapping(unmatched_asis_tables, tobe_tables_unique)
    if not table_mapping:
        return comparison_rows

    # Build lookup: (tobe_table, column_name_lower) -> tobe row for fast join
    tobe_by_table_col: Dict[Tuple[str, str], Dict] = {}
    for row in tobe_rows:
        t = row.get(tobe_table_hdr, "") if tobe_table_hdr else ""
        c = row.get(tobe_src_col_hdr, "") if tobe_src_col_hdr else ""
        if t and c:
            tobe_by_table_col.setdefault((t, c.lower()), row)

    # Iterate unmatched rows and apply AI table mapping + exact column match
    matched_count = 0
    for idx, _comp_row in unmatched:
        asis_row = asis_rows[idx]
        asis_table = asis_row.get(asis_table_hdr, "") if asis_table_hdr else ""
        asis_col = asis_row.get(asis_src_col_hdr, "") if asis_src_col_hdr else ""

        if not asis_table or not asis_col:
            continue
        if asis_table not in table_mapping:
            continue

        mapped_tobe_table, confidence = table_mapping[asis_table]

        # Exact column name match (case-insensitive) within AI-mapped table
        key = (mapped_tobe_table, asis_col.lower())
        if key in tobe_by_table_col:
            tobe_row = tobe_by_table_col[key]
            comparison_rows[idx]["Match Found"] = "Yes"
            comparison_rows[idx]["Match Method"] = (
                "AI Table Match + Exact Column"
            )
            comparison_rows[idx]["Match %"] = f"{confidence * 100:.0f}"
            comparison_rows[idx]["CDH Column Name"] = (
                tobe_row.get(tobe_src_col_hdr, "") if tobe_src_col_hdr else ""
            )
            comparison_rows[idx]["CDH Table Name"] = (
                tobe_row.get(tobe_table_hdr, "") if tobe_table_hdr else ""
            )
            matched_count += 1

    logger.info("AI matching: %d new matches from %d unmatched rows", matched_count, len(unmatched))
    return comparison_rows


def _derive_workbook_name(filename: str) -> str:
    """Derive clean workbook name from a metadata extraction filename.

    E.g. 'MyReport_Metadata_20260309_abc123.xlsx' → 'MyReport'
    """
    import re
    base = filename.rsplit(".", 1)[0] if "." in filename else filename
    return re.split(r"_Metadata_", base, maxsplit=1)[0] or base


def _write_comparison_excel(
    rows: List[Dict[str, str]],
    asis_name: str = "",
    tobe_name: str = "",
    asis_workbook: str = "",
    tobe_rows: List[Dict[str, str]] | None = None,
    asis_rows: List[Dict[str, str]] | None = None,
    asis_sample_rows: List[Dict[str, str]] | None = None,
    tobe_sample_rows: List[Dict[str, str]] | None = None,
) -> bytes:
    """Write comparison rows to a styled Excel workbook and return bytes."""
    wb = Workbook()
    ws = wb.active
    ws.title = "Overall Metadata Match Details"

    if not rows:
        ws.append(["No Tableau columns to compare."])
        buf = io.BytesIO()
        wb.save(buf)
        buf.seek(0)
        return buf.read()

    # No To-Be report name column needed

    headers = list(rows[0].keys())
    ws.append(headers)

    # Style header row with branded colours and centered alignment
    for col_idx in range(1, len(headers) + 1):
        cell = ws.cell(row=1, column=col_idx)
        cell.font = HEADER_FONT
        cell.fill = HEADER_FILL
        cell.alignment = HEADER_ALIGNMENT
        cell.border = THIN_BORDER

    # Add explanatory comment on the "Tableau Worksheet Name(s)" header
    if "Tableau Worksheet Name(s)" in headers:
        hdr_col = headers.index("Tableau Worksheet Name(s)") + 1
        ws.cell(row=1, column=hdr_col).comment = Comment(
            "Blank values indicate the column exists in the data source "
            "but is not used in any worksheet/report.",
            "System",
        )

    # Write data rows with conditional colour-coding (green/red fill)
    for row_idx, row_dict in enumerate(rows, start=2):
        for col_idx, hdr in enumerate(headers, start=1):
            cell = ws.cell(row=row_idx, column=col_idx)
            val = row_dict.get(hdr, "")
            cell.value = val if val is not None else ""
            cell.alignment = CELL_ALIGNMENT
            cell.border = THIN_BORDER

        # Colour-code the entire row based on match status
        is_match = row_dict.get("Match Found", "") == "Yes"
        fill = MATCH_FILL if is_match else NO_MATCH_FILL
        for col_idx in range(1, len(headers) + 1):
            ws.cell(row=row_idx, column=col_idx).fill = fill

    # Auto-width
    for col in ws.columns:
        max_len = 0
        col_letter = get_column_letter(col[0].column)
        for cell in col:
            try:
                cell_len = len(str(cell.value or ""))
                if cell_len > max_len:
                    max_len = cell_len
            except Exception:
                pass
        ws.column_dimensions[col_letter].width = max(min(max_len + 4, 60), 14)

    # Freeze header & auto-filter
    ws.freeze_panes = "A2"
    ws.auto_filter.ref = ws.dimensions

    # --- Summary sheet (one row per Tableau report/worksheet) ---
    ws_sum = wb.create_sheet(title="Summary")

    # Collect all unique report names from "Tableau Report Name(s)" (semicolon-separated)
    # Collect match statistics per worksheet for the summary sheet
    from collections import defaultdict
    report_stats: Dict[str, Dict[str, int]] = defaultdict(
        lambda: {"exact": 0, "table_desc": 0, "glossary": 0, "sample_data": 0, "fuzzy": 0, "not_matched": 0}
    )
    # Track which dashboards are associated with each worksheet
    ws_dashboards: Dict[str, set] = defaultdict(set)

    # Categorise each comparison row by match method and worksheet
    for r in rows:
        ws_list = r.get("Tableau Worksheet Name(s)", "").strip()
        db_list = r.get("Tableau Dashboard Name(s)", "").strip()
        method = r.get("Match Method", "")
        matched = r["Match Found"] == "Yes"

        if matched and method.startswith("Exact"):
            category = "exact"
        elif matched and method.startswith("Table Description"):
            category = "table_desc"
        elif matched and method.startswith("Glossary"):
            category = "glossary"
        elif matched and method.startswith("Sample Data"):
            category = "sample_data"
        elif matched and method.startswith("Fuzzy"):
            category = "fuzzy"
        else:
            category = "not_matched"

        # A column can appear in multiple worksheets; count it in each
        if ws_list:
            report_names = [s.strip() for s in ws_list.split(";") if s.strip()]
        else:
            report_names = ["(No Worksheet)"]

        # Collect dashboard names associated with each worksheet
        db_names = [s.strip() for s in db_list.split(";") if s.strip()] if db_list else []

        for rpt in report_names:
            report_stats[rpt][category] += 1
            for db in db_names:
                ws_dashboards[rpt].add(db)

    # --- Row 1: merged headers ---
    # Merge the first 4 column headers across rows 1-2
    for col, hdr in [(1, "Tableau File Name"), (2, "Tableau Dashboard Name"),
                     (3, "Tableau Worksheet Name"),
                     (4, "Total Number of Fields in the Report")]:
        ws_sum.merge_cells(start_row=1, start_column=col, end_row=2, end_column=col)
        cell = ws_sum.cell(row=1, column=col, value=hdr)
        cell.font = HEADER_FONT
        cell.fill = HEADER_FILL
        cell.alignment = HEADER_ALIGNMENT
        cell.border = THIN_BORDER
        # Style the hidden row-2 cell so the border extends
        c2 = ws_sum.cell(row=2, column=col)
        c2.font = HEADER_FONT
        c2.fill = HEADER_FILL
        c2.alignment = HEADER_ALIGNMENT
        c2.border = THIN_BORDER

    # Merge E1:J1 for the match-% banner
    ws_sum.merge_cells(start_row=1, start_column=5, end_row=1, end_column=10)
    merged_cell = ws_sum.cell(row=1, column=5, value="Match % - Tableau vs CDH")
    merged_cell.font = HEADER_FONT
    merged_cell.fill = HEADER_FILL
    merged_cell.alignment = HEADER_ALIGNMENT
    merged_cell.border = THIN_BORDER
    # Style the remaining merged cells so the fill/border extends visually
    for col in range(6, 11):
        c = ws_sum.cell(row=1, column=col)
        c.font = HEADER_FONT
        c.fill = HEADER_FILL
        c.alignment = HEADER_ALIGNMENT
        c.border = THIN_BORDER

    # --- Row 2: match-% sub-headers (columns E-J only; A-D already merged) ---
    match_sub_headers = {
        5: "Exact Match % (Column + Table)",
        6: "Table Description + Exact Column Match %",
        7: "Glossary Description Match %",
        8: "Sample Data Match %",
        9: "Fuzzy Match % (Column + Table)",
        10: "No Match %",
    }
    for c_idx, hdr in match_sub_headers.items():
        cell = ws_sum.cell(row=2, column=c_idx, value=hdr)
        cell.font = HEADER_FONT
        cell.fill = HEADER_FILL
        cell.alignment = HEADER_ALIGNMENT
        cell.border = THIN_BORDER

    # Sort reports alphabetically but push "(No Worksheet)" to the end
    sorted_reports = sorted(
        report_stats.keys(),
        key=lambda n: (n == "(No Worksheet)", n),
    )

    # Derive workbook display name
    workbook_display = asis_workbook or _derive_workbook_name(asis_name)

    for r_idx, rpt_name in enumerate(sorted_reports, start=3):
        stats = report_stats[rpt_name]
        rpt_total = (
            stats["exact"] + stats["table_desc"] + stats["glossary"]
            + stats["sample_data"] + stats["fuzzy"] + stats["not_matched"]
        )

        if rpt_total:
            # Use largest-remainder method so percentages always sum to 100.0
            raw = [
                stats["exact"] / rpt_total * 100,
                stats["table_desc"] / rpt_total * 100,
                stats["glossary"] / rpt_total * 100,
                stats["sample_data"] / rpt_total * 100,
                stats["fuzzy"] / rpt_total * 100,
                stats["not_matched"] / rpt_total * 100,
            ]
            # Floor each value to 1 decimal place, then redistribute remainder
            floored = [int(v * 10) / 10 for v in raw]          # floor to 1 decimal
            remainder = round(100.0 - sum(floored), 1)
            # Distribute the leftover 0.1 increments to items with largest fractional parts
            fracs = [(round(r - f, 4), i) for i, (r, f) in enumerate(zip(raw, floored))]
            fracs.sort(key=lambda x: -x[0])
            steps = round(remainder * 10)                       # how many 0.1 increments to hand out
            for k in range(int(steps)):
                floored[fracs[k][1]] = round(floored[fracs[k][1]] + 0.1, 1)
            pct_exact, pct_desc, pct_glossary, pct_sample, pct_fuzzy, pct_no_match = floored
        else:
            pct_exact = pct_desc = pct_glossary = pct_sample = pct_fuzzy = pct_no_match = 0.0

        # Derive dashboard names for this worksheet
        dashboard_display = "; ".join(sorted(ws_dashboards.get(rpt_name, set())))

        row_data = [
            workbook_display,
            dashboard_display,
            rpt_name,
            rpt_total,
            pct_exact,
            pct_desc,
            pct_glossary,
            pct_sample,
            pct_fuzzy,
            pct_no_match,
        ]
        for c_idx, val in enumerate(row_data, start=1):
            cell = ws_sum.cell(row=r_idx, column=c_idx, value=val)
            cell.alignment = CELL_ALIGNMENT
            cell.border = THIN_BORDER

        # Add comment on "(No Worksheet)" row
        if rpt_name == "(No Worksheet)":
            ws_sum.cell(row=r_idx, column=3).comment = Comment(
                "These columns exist in the data source but are not placed on any worksheet or report. "
                "They are available in the Tableau model but not visually used.",
                "System",
            )

    ws_sum.column_dimensions["A"].width = 30
    ws_sum.column_dimensions["B"].width = 30
    ws_sum.column_dimensions["C"].width = 30
    ws_sum.column_dimensions["D"].width = 32
    ws_sum.column_dimensions["E"].width = 28
    ws_sum.column_dimensions["F"].width = 40
    ws_sum.column_dimensions["G"].width = 32
    ws_sum.column_dimensions["H"].width = 28
    ws_sum.column_dimensions["I"].width = 28
    ws_sum.column_dimensions["J"].width = 16
    ws_sum.freeze_panes = "A3"

    # Move Summary sheet to second position (after Info)
    wb.move_sheet(ws_sum, offset=-1)

    # --- Info sheet: matching strategy descriptions ---
    ws_info = wb.create_sheet(title="Info")

    INFO_SUBHEADER_FILL = PatternFill(start_color="D6E4D2", end_color="D6E4D2", fill_type="solid")
    INFO_SUBHEADER_FONT = Font(bold=True, size=11, name="Calibri")

    info_headers = ["Strategy Name", "Strategy Method"]
    for c_idx, hdr in enumerate(info_headers, start=1):
        cell = ws_info.cell(row=1, column=c_idx, value=hdr)
        cell.font = HEADER_FONT
        cell.fill = HEADER_FILL
        cell.alignment = HEADER_ALIGNMENT
        cell.border = THIN_BORDER

    strategies = [
        (
            "Exact Match (Column + Table)",
            "Compares the Tableau Source Column name and Source Table name "
            "against every CDH row. Both values must match exactly "
            "(case-insensitive). If both the column name and table name are "
            "identical, the row is marked as an Exact Match.",
        ),
        (
            "Table Description + Exact Column Match",
            "For rows that did not match in the Exact step, the Tableau "
            "table name is compared against the CDH Table Description "
            "field using substring containment, token-overlap (Jaccard similarity), "
            "and SequenceMatcher fuzzy scoring. If the best description score meets "
            "the 50% threshold, the tables are considered matched. Within that "
            "matched table, the Tableau column name must still match a "
            "CDH column name exactly (case-insensitive).",
        ),
        (
            "Glossary Description Match",
            "For rows still unmatched after the first two steps, the Report "
            "field display name (and field description, if available) is compared "
            "against CDH column descriptions from the business glossary. "
            "If the CDH Metadata does not contain column descriptions, the system "
            "auto-generates a business glossary for every CDH column using built-in "
            "domain knowledge (180+ exact matches, 30+ suffix/pattern rules, and "
            "token-based inference from SAP, ERP, and supply-chain naming conventions). "
            "Uses four scoring signals: (1) Normalised name similarity — "
            "e.g. \"Fiscal Year\" matches \"FISCAL_YEAR\"; (2) Field-name token "
            "overlap with CDH column descriptions; (3) Description-to-description "
            "Jaccard similarity when both sides have descriptions; (4) CDH "
            "column-name token containment within the report field name. "
            "The best signal score must meet the 55% threshold.",
        ),
        (
            "Sample Data Match",
            "For rows still unmatched after the first three steps, actual sample "
            "data values are compared between the Report and CDH files. The Report "
            "must contain a Sample_Data sheet. If the CDH file also has a "
            "Sample_Data sheet, those values are used directly; otherwise, "
            "synthetic representative values are auto-generated for each CDH "
            "column using domain knowledge (industry value sets, data-type "
            "conventions, and glossary description heuristics). For each column, "
            "a fingerprint of distinct (non-empty, case-insensitive) values is "
            "built. The Jaccard similarity (intersection-over-union of values) is "
            "computed between the unmatched Report column and every CDH column. "
            "The best-scoring CDH column is selected if the Jaccard score meets "
            "the 30% threshold. This catches columns that were renamed or placed "
            "in different tables but still contain the same underlying data.",
        ),
        (
            "Fuzzy Match (Column + Table)",
            "For rows still unmatched after the first four steps, a weighted fuzzy "
            "score is computed: 70% from column-name similarity and 30% from "
            "table-name similarity (using Python's SequenceMatcher). The best-"
            "scoring CDH candidate is selected if the combined score "
            "meets the 50% threshold.",
        ),
        (
            "No Match",
            "The Tableau field could not be matched to any CDH "
            "field using any of the above strategies. This may indicate a new "
            "field, a retired field, or a naming discrepancy that requires "
            "manual review.",
        ),
    ]

    for r_idx, (name, method) in enumerate(strategies, start=2):
        name_cell = ws_info.cell(row=r_idx, column=1, value=name)
        name_cell.font = INFO_SUBHEADER_FONT
        name_cell.fill = INFO_SUBHEADER_FILL
        name_cell.alignment = CELL_ALIGNMENT
        name_cell.border = THIN_BORDER

        method_cell = ws_info.cell(row=r_idx, column=2, value=method)
        method_cell.alignment = CELL_ALIGNMENT
        method_cell.border = THIN_BORDER

    ws_info.column_dimensions["A"].width = 42
    ws_info.column_dimensions["B"].width = 90
    # Set row heights for wrapped text
    for r_idx in range(2, 2 + len(strategies)):
        ws_info.row_dimensions[r_idx].height = 45

    # Move Info sheet to the very first position
    wb.move_sheet(ws_info, offset=-(len(wb.sheetnames) - 1))

    # --- Per-match-type breakdown sheets (one sheet per strategy) ---
    _FILTER_HEADERS = [
        "Tableau Dashboard Name(s)", "Tableau Worksheet Name(s)", "Tableau Field Name",
        "Tableau Source Column", "Tableau Source Table",
        "Match Found", "Match %",
        "CDH Column Name", "CDH Table Name",
    ]
    _MATCH_SHEETS = [
        ("Exact Match (Column + Table)", lambda m: m.startswith("Exact")),
        ("Table Desc + Exact Column Match", lambda m: m.startswith("Table Description")),
        ("Glossary Description Match", lambda m: m.startswith("Glossary")),
        ("Sample Data Match", lambda m: m.startswith("Sample Data")),
        ("Fuzzy Match (Column + Table)", lambda m: m.startswith("Fuzzy")),
        ("No Match", lambda m: m == "No Match"),
    ]
    for sheet_title, method_filter in _MATCH_SHEETS:
        ws_m = wb.create_sheet(title=sheet_title)
        # Write header row for this match-type sheet
        for c_idx, hdr in enumerate(_FILTER_HEADERS, start=1):
            cell = ws_m.cell(row=1, column=c_idx, value=hdr)
            cell.font = HEADER_FONT
            cell.fill = HEADER_FILL
            cell.alignment = HEADER_ALIGNMENT
            cell.border = THIN_BORDER
        # Populate data rows filtered to this match method
        data_row = 2
        for r in rows:
            if method_filter(r.get("Match Method", "")):
                for c_idx, hdr in enumerate(_FILTER_HEADERS, start=1):
                    cell = ws_m.cell(row=data_row, column=c_idx)
                    val = r.get(hdr, "")
                    cell.value = val if val is not None else ""
                    cell.alignment = CELL_ALIGNMENT
                    cell.border = THIN_BORDER
                is_match = r.get("Match Found", "") == "Yes"
                fill = MATCH_FILL if is_match else NO_MATCH_FILL
                for c_idx in range(1, len(_FILTER_HEADERS) + 1):
                    ws_m.cell(row=data_row, column=c_idx).fill = fill
                data_row += 1
        # Auto-width
        for col in ws_m.columns:
            max_len = 0
            col_letter = get_column_letter(col[0].column)
            for cell in col:
                try:
                    cell_len = len(str(cell.value or ""))
                    if cell_len > max_len:
                        max_len = cell_len
                except Exception:
                    pass
            ws_m.column_dimensions[col_letter].width = max(min(max_len + 4, 60), 14)
        ws_m.freeze_panes = "A2"
        ws_m.auto_filter.ref = ws_m.dimensions

    # --- CDH Metadata Glossary sheet (reference snapshot of the CDH catalog) ---
    if tobe_rows:
        ws_cdh = wb.create_sheet(title="CDH_Metadata_Glossary")
        # Determine which headers to include
        all_hdrs = list(tobe_rows[0].keys())
        tbl_hdr = _find_header(all_hdrs, _COL_CANDIDATES["source_table"])
        col_hdr = _find_header(all_hdrs, _COL_CANDIDATES["source_column"])
        desc_hdr = _find_header(all_hdrs, _COL_CANDIDATES["description"])
        tbl_desc_hdr = _find_header(all_hdrs, _COL_CANDIDATES["table_description"])
        cdh_headers = [h for h in [tbl_hdr, col_hdr, desc_hdr, tbl_desc_hdr] if h]
        # Write header row
        for c_idx, hdr in enumerate(cdh_headers, start=1):
            cell = ws_cdh.cell(row=1, column=c_idx, value=hdr)
            cell.font = HEADER_FONT
            cell.fill = HEADER_FILL
            cell.alignment = HEADER_ALIGNMENT
            cell.border = THIN_BORDER
        # Write data rows
        for r_idx, row in enumerate(tobe_rows, start=2):
            for c_idx, hdr in enumerate(cdh_headers, start=1):
                cell = ws_cdh.cell(row=r_idx, column=c_idx)
                cell.value = row.get(hdr, "")
                cell.alignment = CELL_ALIGNMENT
                cell.border = THIN_BORDER
        # Auto-width
        for col in ws_cdh.columns:
            max_len = 0
            col_letter = get_column_letter(col[0].column)
            for cell in col:
                try:
                    cell_len = len(str(cell.value or ""))
                    if cell_len > max_len:
                        max_len = cell_len
                except Exception:
                    pass
            ws_cdh.column_dimensions[col_letter].width = max(min(max_len + 4, 60), 14)
        ws_cdh.freeze_panes = "A2"
        ws_cdh.auto_filter.ref = ws_cdh.dimensions

    # --- Report_Lineage_Glossary sheet ---
    if asis_rows:
        from utils.glossary_generator import generate_description
        ws_gloss = wb.create_sheet(title="Report_Lineage_Glossary")
        asis_hdrs = list(asis_rows[0].keys())
        a_tbl_hdr = _find_header(asis_hdrs, _COL_CANDIDATES["source_table"])
        a_col_hdr = _find_header(asis_hdrs, _COL_CANDIDATES["source_column"])
        a_fld_hdr = _find_header(asis_hdrs, _COL_CANDIDATES["field_name"])
        a_dtype_hdr = next((h for h in asis_hdrs if h.lower() in ("data type", "datatype")), None)
        gloss_headers = ["Source Table", "Source Table Description", "Column Name", "Display Name", "Data Type", "Business Description"]
        for c_idx, hdr in enumerate(gloss_headers, start=1):
            cell = ws_gloss.cell(row=1, column=c_idx, value=hdr)
            cell.font = HEADER_FONT
            cell.fill = HEADER_FILL
            cell.alignment = HEADER_ALIGNMENT
            cell.border = THIN_BORDER
        seen_keys = set()
        tbl_desc_cache = {}
        g_row = 2
        for r in asis_rows:
            src_tbl = r.get(a_tbl_hdr, "") if a_tbl_hdr else ""
            src_col = r.get(a_col_hdr, "") if a_col_hdr else ""
            if not src_col or (src_tbl, src_col) in seen_keys:
                continue
            seen_keys.add((src_tbl, src_col))
            display = r.get(a_fld_hdr, src_col) if a_fld_hdr else src_col
            dtype = r.get(a_dtype_hdr, "") if a_dtype_hdr else ""
            if src_tbl and src_tbl not in tbl_desc_cache:
                tbl_desc_cache[src_tbl] = generate_description(src_tbl)
            vals = [src_tbl, tbl_desc_cache.get(src_tbl, ""), src_col, display, dtype, generate_description(src_col, src_tbl)]
            for c_idx, v in enumerate(vals, start=1):
                cell = ws_gloss.cell(row=g_row, column=c_idx, value=v)
                cell.alignment = CELL_ALIGNMENT
                cell.border = THIN_BORDER
            g_row += 1
        for col in ws_gloss.columns:
            max_len = 0
            col_letter = get_column_letter(col[0].column)
            for cell in col:
                try:
                    cell_len = len(str(cell.value or ""))
                    if cell_len > max_len:
                        max_len = cell_len
                except Exception:
                    pass
            ws_gloss.column_dimensions[col_letter].width = max(min(max_len + 4, 60), 14)
        ws_gloss.freeze_panes = "A2"
        ws_gloss.auto_filter.ref = ws_gloss.dimensions

    # --- Report_Sample_Data sheet ---
    ws_rsample = wb.create_sheet(title="Report_Sample_Data")
    if asis_sample_rows:
        s_headers = list(asis_sample_rows[0].keys())
        for c_idx, hdr in enumerate(s_headers, start=1):
            cell = ws_rsample.cell(row=1, column=c_idx, value=hdr)
            cell.font = HEADER_FONT
            cell.fill = HEADER_FILL
            cell.alignment = HEADER_ALIGNMENT
            cell.border = THIN_BORDER
        for r_idx, row in enumerate(asis_sample_rows, start=2):
            for c_idx, hdr in enumerate(s_headers, start=1):
                cell = ws_rsample.cell(row=r_idx, column=c_idx)
                cell.value = row.get(hdr, "")
                cell.alignment = CELL_ALIGNMENT
                cell.border = THIN_BORDER
        for col in ws_rsample.columns:
            max_len = 0
            col_letter = get_column_letter(col[0].column)
            for cell in col:
                try:
                    cell_len = len(str(cell.value or ""))
                    if cell_len > max_len:
                        max_len = cell_len
                except Exception:
                    pass
            ws_rsample.column_dimensions[col_letter].width = max(min(max_len + 4, 60), 14)
        ws_rsample.freeze_panes = "A2"
        ws_rsample.auto_filter.ref = ws_rsample.dimensions
    else:
        ws_rsample.append(["No sample data available \u2014 source report uses live database connections."])
        ws_rsample.column_dimensions["A"].width = 70

    # --- CDH_Synthetic_Data sheet ---
    ws_synth = wb.create_sheet(title="CDH_Synthetic_Data")
    if tobe_sample_rows:
        s_headers = list(tobe_sample_rows[0].keys())
        for c_idx, hdr in enumerate(s_headers, start=1):
            cell = ws_synth.cell(row=1, column=c_idx, value=hdr)
            cell.font = HEADER_FONT
            cell.fill = HEADER_FILL
            cell.alignment = HEADER_ALIGNMENT
            cell.border = THIN_BORDER
        for r_idx, row in enumerate(tobe_sample_rows, start=2):
            for c_idx, hdr in enumerate(s_headers, start=1):
                cell = ws_synth.cell(row=r_idx, column=c_idx)
                cell.value = row.get(hdr, "")
                cell.alignment = CELL_ALIGNMENT
                cell.border = THIN_BORDER
        for col in ws_synth.columns:
            max_len = 0
            col_letter = get_column_letter(col[0].column)
            for cell in col:
                try:
                    cell_len = len(str(cell.value or ""))
                    if cell_len > max_len:
                        max_len = cell_len
                except Exception:
                    pass
            ws_synth.column_dimensions[col_letter].width = max(min(max_len + 4, 60), 14)
        ws_synth.freeze_panes = "A2"
        ws_synth.auto_filter.ref = ws_synth.dimensions
    else:
        ws_synth.append(["No sample data available \u2014 CDH metadata file does not contain sample data."])
        ws_synth.column_dimensions["A"].width = 70

    buf = io.BytesIO()
    wb.save(buf)
    buf.seek(0)
    return buf.read()
