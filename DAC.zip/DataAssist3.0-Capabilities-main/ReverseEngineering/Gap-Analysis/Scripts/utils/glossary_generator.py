"""
Business Glossary Auto-Generator.

Generates human-readable column descriptions from technical column names
using a built-in knowledge base of common SAP / ERP / supply-chain / oil-&-gas
naming patterns.  No external API calls — all generation is deterministic.

Public API
----------
generate_description(column_name, table_name="") -> str
    Return a business glossary description for the given column name.

enrich_glossary(rows, col_hdr, desc_hdr, table_hdr=None) -> List[Dict]
    In-place populate empty description fields on a list of row-dicts.
"""

from __future__ import annotations

import re
from typing import Dict, List, Optional

# ---------------------------------------------------------------------------
# 1. Exact-match glossary  (column_name.upper() -> description)
# ---------------------------------------------------------------------------
_EXACT: Dict[str, str] = {
    # -- System / ETL --
    "DP_TIMESTAMP": "System-generated timestamp indicating when the record was loaded or last refreshed in the data platform.",
    "SOURCE_SYSTEM": "Identifier of the originating ERP or upstream system instance from which the record was extracted.",
    "CLIENT": "SAP client (Mandant) number representing the highest organizational level in the SAP system.",
    "MANDT": "SAP client (Mandant) number representing the highest organizational level in the SAP system.",

    # -- Organisation --
    "COMPANY_CODE": "SAP company code representing the smallest organizational unit for which a complete set of financial accounts can be drawn up.",
    "COMPANY_CODE_NAME": "Descriptive name of the company code entity.",
    "COMPANY_CODE_NAME_CONCAT": "Concatenated company code and descriptive name for display purposes.",
    "COMPANY_NAME": "Legal or common business name of the company.",
    "COMPANY_NAME_CONCAT": "Concatenated company code and company name for display purposes.",
    "COMPANY_COUNTRY_NAME": "Country where the company code entity is legally registered or operates.",
    "COMPANY_COUNTRY_CODE": "ISO country code of the company code entity.",
    "COMPANY_REGION": "Geographic region classification of the company (e.g., Americas, Europe, Asia Pacific).",
    "COUNTRY_OF_INCORPORATION": "Country where the company code entity is legally incorporated.",
    "COUNTRY_NAME": "Name of the country.",
    "CONTROLLING_AREA": "SAP Controlling Area code that defines the organizational boundary for cost accounting.",

    # -- Fiscal / Period --
    "FISCAL_YEAR": "Fiscal year in which the financial posting was recorded.",
    "POSTING_PERIOD": "Accounting period (typically calendar month) within the fiscal year.",
    "FISCAL_YEAR_PERIOD": "Concatenated fiscal year and posting period providing a single sortable key for period-based analysis.",
    "POSTING_YEAR": "Calendar or fiscal year of the posting date.",
    "POSTING_PERIOD_D": "Posting period expressed as a date value for time-series analysis.",

    # -- Document --
    "DOCUMENT_NUMBER": "Unique identifier for the accounting or controlling document.",
    "DOCUMENT_ITEM_NUMBER": "Line item number within the accounting document.",
    "DOCUMENT_TYPE": "Classification code for the type of SAP document (e.g., invoice, credit memo, goods receipt).",

    # -- Cost / Charge --
    "CHARGE_TYPE": "Granular classification code for the type of cost or charge incurred.",
    "CHARGE_TYPE_DESC": "Descriptive label for the charge type.",
    "CHARGE_SUBCATEGORY": "Intermediate grouping code that rolls up related charge types.",
    "CHARGE_SUBCATEGORY_DESC": "Descriptive label for the charge subcategory.",
    "CHARGE_CATEGORY": "High-level classification code that groups charge subcategories into broad cost categories.",
    "CHARGE_CATEGORY_DESC": "Descriptive label for the charge category.",
    "COST_TYPE": "Classification of the cost entry (e.g., Actual, Plan, Forecast, Budget).",
    "COST_OBJECT": "Target object (cost center, internal order, WBS element) to which the cost is assigned.",
    "COST_CENTER": "SAP cost center code representing the organizational unit responsible for the cost.",
    "COST_CENTER_LONG_DESC": "Full descriptive name of the cost center.",
    "COST_CATEGORIES": "Broad classification of supply chain costs (e.g., Transportation, Warehousing, Handling).",

    # -- GL / Account --
    "GL_ACCOUNT": "General Ledger account number representing the nature of the expense.",
    "PNS_ACCOUNT_CODE": "P&L / Net Income Statement account code in the proprietary PNS reporting framework.",
    "PNS_ACCOUNT_NAME": "Descriptive name of the PNS account.",

    # -- Profit Center --
    "PROFIT_CENTER": "SAP profit center code for internal profit and loss reporting.",
    "PROFIT_CENTER_DESC": "Descriptive name of the profit center.",
    "PROFIT_CENTER_DESC_CONCAT": "Concatenated profit center code and description for display purposes.",
    "PROFIT_CENTER_BU": "Business unit associated with the profit center.",

    # -- Customer --
    "CUSTOMER_NUMBER": "Unique SAP customer master record number.",
    "CUSTOMER_NAME": "Primary business name of the customer.",
    "CUSTOMER_GROUP": "Classification group assigned to the customer for pricing or segmentation.",
    "COUNTRY_KEY_CUSTOMER": "Country code of the customer master record.",

    # -- Material / Product --
    "MATERIAL": "SAP material master number uniquely identifying the product or commodity.",
    "MATERIAL_NUM": "SAP material master number.",
    "MATERIAL_NUMBER": "SAP material master number.",
    "MATERIAL_DESC": "Descriptive name of the material.",
    "MATERIAL_DESC_CONCAT": "Concatenated material number and description for display purposes.",
    "MATERIAL_TYPE": "Material type code classifying the material (e.g., finished goods, raw material).",
    "MATERIAL_TYPE_DESC": "Descriptive name of the material type.",
    "MATERIAL_GROUP": "Material group code for grouping similar materials.",
    "MATERIAL_GROUP_DESC": "Descriptive name of the material group.",
    "MATERIAL_CATEGORY": "Broad category classification of the material (e.g., crude, refined, chemicals).",
    "MATERIAL_BU": "Business unit associated with the material.",
    "MATERIAL_NAME": "Display name of the material.",
    "MATERIAL_VALUATION_CLASS": "Valuation class code linking the material to G/L accounts for inventory valuation.",
    "MATERIAL_BUSINESS_UNIT_LONG_NAME": "Full business unit name associated with the material.",
    "FINISHED_PRODUCT": "Indicator or identifier for the finished product resulting from manufacturing.",

    # -- Plant --
    "PLANT": "SAP plant code for the logistics or manufacturing site.",
    "PLANT_NAME": "Descriptive name of the plant.",
    "PLANT_NAME_CONCAT": "Concatenated plant code and name for display purposes.",
    "PLANT_CATEGORY": "Classification category of the plant (e.g., refinery, terminal, depot).",
    "PLANT_CITY": "City where the plant is located.",
    "PLANT_COUNTRY_CODE": "ISO country code of the plant location.",
    "PLANT_COUNTRY_NAME": "Country where the plant is located.",
    "PLANT_REGION": "Geographic region of the plant.",
    "PLANT_REGION_NAME": "Descriptive name of the plant's geographic region.",
    "PLANT_SUPER_REGION": "Super-region grouping for the plant (e.g., Americas, EMEA, APAC).",
    "PLANT_TYPE_NAME": "Type classification name for the plant.",
    "PLANT_LOC_TYPE": "Location type code for the plant within the supply chain network.",
    "MM_PLANT": "SAP plant code (sending/issuing plant) for the materials management transaction.",
    "MM_PLANT_NAME": "Descriptive name of the sending/issuing plant.",
    "DELIVERY_PLANT": "SAP plant code for the delivery/shipping plant.",
    "DELIVERY_PLANT_NAME": "Descriptive name of the delivery plant.",
    "DELIVERY_PLANT_NAME_CONCAT": "Concatenated delivery plant code and name for display purposes.",

    # -- Partner Plant --
    "PARTNER_PLANT": "SAP plant code for the partner/receiving plant in intercompany or stock transfer scenarios.",
    "PARTNER_PLANT_NAME": "Descriptive name of the partner plant.",
    "PARTNER_PLANT_NAME_CONCAT": "Concatenated partner plant code and name for display purposes.",
    "PARTNER_PLANT_TYPE_NAME": "Type classification of the partner plant.",
    "PARTNER_PLANT_COUNTRY_NAME": "Country where the partner plant is located.",
    "PARTNER_PLANT_LOC_TYPE": "Location type of the partner plant.",
    "PARTNER_PLANT_REGION_NAME": "Geographic region name of the partner plant.",

    # -- Ship-to / Sold-to --
    "SHIPTO": "Ship-to party customer number indicating the delivery destination.",
    "SHIPTO_NAME": "Name of the ship-to party.",
    "SHIPTO_NAME_CONCAT": "Concatenated ship-to party number and name.",
    "SHIPTO_COUNTRY": "Country code of the ship-to party.",
    "SHIPTO_COUNTRY_NAME": "Country name of the ship-to party.",
    "SHIP_TO_COUNTRY_NAME": "Country name of the ship-to party.",
    "SOLDTO": "Sold-to party customer number who placed the order.",
    "SOLDTO_NAME": "Name of the sold-to party.",
    "SOLDTO_NAME_CONCAT": "Concatenated sold-to party number and name.",
    "SOLDTO_COUNTRY": "Country code of the sold-to party.",
    "SOLDTO_COUNTRY_NAME": "Country name of the sold-to party.",
    "SOLD_TO_COUNTRY_NAME": "Country name of the sold-to party.",
    "GOODS_RECIPIENT": "Party receiving the goods at the delivery destination.",

    # -- Logistics / Transport --
    "MODE_OF_TRANSPORT": "Code indicating the transportation mode (e.g., pipeline, vessel, rail, truck, barge).",
    "MOT_DESC": "Description of the mode of transport.",
    "MOT_FLAG": "Flag indicating the mode of transport classification.",
    "MOT_GROUP": "Grouping of modes of transport for reporting purposes.",
    "FVC_MOT": "Full value chain mode of transport classification.",
    "LOAD_LOCATION": "Code identifying the physical loading point.",
    "LOAD_LOCATION_NAME": "Descriptive name of the loading location.",
    "LOAD_LOCATION_TYPE_DESC": "Description of the loading location type.",
    "SHIPPING_CONDITION": "Shipping condition code determining the logistics execution method.",
    "SHIPPING_CONDITION_NAME": "Descriptive name of the shipping condition.",
    "SHIPPING_CONDITION_TYPE": "Type classification of the shipping condition.",
    "INCO_TERMS": "International Commercial Terms (Incoterms) code defining delivery obligations.",
    "INCO_TERM_DESC": "Description of the Incoterms.",

    # -- Volume --
    "VOLUME_KG": "Volume or weight quantity measured in kilograms.",
    "VOLUME_T": "Volume or weight quantity measured in metric tons.",
    "VOLUME_BBL": "Volume quantity measured in barrels.",
    "VOLUME_TYPE": "Classification of the volume measurement (e.g., Delivery, Sales, Production, Transfer).",

    # -- Movement --
    "MOVEMENT": "SAP inventory management movement type code.",
    "MOVEMENT_DESC": "Description of the inventory movement type.",
    "MOVEMENT_CATEGORY": "Category grouping of movement types.",
    "MOVEMENT_GROUP": "Higher-level grouping of movement types for reporting.",
    "FREE_NONFREE_MOVEMENT": "Indicator classifying the movement as free-of-charge or standard commercial.",

    # -- Value Chain / P&L --
    "VALUE_CHAIN": "Value chain segment classification (e.g., Downstream Fuels, Chemical, Upstream).",
    "P&L LEVEL 1": "Level 1 (top) category in the Profit & Loss reporting hierarchy.",
    "P&L LEVEL 2": "Level 2 category in the Profit & Loss reporting hierarchy.",
    "P&L LEVEL 3": "Level 3 (granular) category in the Profit & Loss reporting hierarchy.",
    "P&L LEVEL3": "Level 3 (granular) category in the Profit & Loss reporting hierarchy.",

    # -- Flags / Indicators --
    "SO_STO_IND": "Indicator distinguishing Sales Orders (SO) from Stock Transfer Orders (STO).",
    "SO_STO_INB_INDICATOR": "Indicator classifying the transaction as Sales Order (SO), Stock Transfer (STO), or Inbound (INB).",
    "TRIP_NON_TRIP_IND": "Indicator flagging whether the cost is trip-related or non-trip overhead.",
    "LCR_FLAG": "Flag indicating whether the transaction is classified as Logistics Cost Reporting (LCR).",
    "WH_LOBP_FLAG": "Flag classifying the transaction as Warehouse (WH), Line of Business Product (LOBP), or N/A.",
    "FLAG_DRAYAGE": "Flag indicating whether the shipment involves drayage (short-distance transport).",
    "INCO_TERM_FLAG": "Flag for Incoterms-based classification.",
    "TRADE_NUM_FLAG": "Flag indicating whether a trade number is associated with the transaction.",
    "MOT_FLAG": "Flag for mode of transport classification.",
    "INFIELD_FLAG": "Flag indicating in-field vs. non-field operations.",
    "EMOP_OBO_FLAG": "Flag for ExxonMobil Operated Property / On Behalf Of classification.",
    "EXXONMOBIL_PAID": "Flag indicating whether the cost was paid by ExxonMobil.",
    "CONSOLIDATED_EQUITY": "Indicator for consolidated vs. equity-method accounting treatment.",

    # -- Record --
    "RECORD_VERSION": "Version indicator for the data record (e.g., Current, Prior Period, Restated).",
    "DATA_SOURCE": "Identifier of the data source or feed that supplied the record.",
    "TECHNICAL_SOURCE": "Technical name or identifier of the source system or ETL pipeline.",

    # -- Region / Geography --
    "REGION": "Geographic region classification for reporting purposes.",
    "ORIGIN_COUNTRY": "Country of origin for the shipment.",
    "ORIGIN_REGION": "Region of origin for the shipment.",
    "DESTINATION_COUNTRY": "Country of destination for the shipment.",
    "DESTINATION_REGION": "Region of destination for the shipment.",
    "DESTINATION_SUPER_REGION": "Super-region grouping for the shipment destination.",
    "ISSUING_COUNTRY": "Country from which the document or shipment was issued.",
    "ISSUING_REGION": "Region from which the document or shipment was issued.",
    "ISSUING_SUPER_REGION": "Super-region classification of the issuing location.",

    # -- Vendor --
    "VENDOR": "SAP vendor master number identifying the supplier or service provider.",
    "VENDOR_NAME": "Descriptive name of the vendor.",
    "VENDOR_NAME_CONCAT": "Concatenated vendor number and name for display purposes.",

    # -- Trade / Vessel --
    "TRADE_NUM": "Trade deal or cargo identification number.",
    "TRADE_PARTNER": "Name or code of the trading counterparty.",
    "NOMINATION_NUMBER": "Nomination or lifting schedule reference number.",

    # -- Division --
    "DIVISION": "SAP product division code.",
    "DIVISION_DESC": "Descriptive name of the product division.",

    # -- Amounts / Currency --
    "AMOUNT_BALANCE_IN_TC": "Cumulative balance amount in transaction currency.",
    "BALANCE_IN_TC": "Period balance amount in transaction currency.",
    "AMOUNT_IN_COC": "Amount in controlling object currency.",
    "AMOUNT_COMPANY_CURR": "Amount in company code local currency.",
    "AMOUNT_FUNCTIONAL_CURR": "Amount in functional (reporting) currency.",
    "AMOUNT_GLOBAL_CURR": "Amount in global/group reporting currency.",
    "AMOUNT_TRANSACTION_CURR": "Amount in original transaction currency.",
    "AMOUNT_POSTED": "Total amount posted to the cost object.",
    "COMPANY_CURRENCY_KEY": "ISO currency code for the company code local currency.",
    "FUNCTIONAL_CURRENCY_KEY": "ISO currency code for the functional currency.",
    "GLOBAL_CURRENCY_KEY": "ISO currency code for the global reporting currency.",
    "TRANSACTION_CURRENCY_KEY": "ISO currency code for the transaction currency.",

    # -- Sales Org --
    "SALES_ORGANIZATION": "SAP sales organization code responsible for the sales transaction.",

    # -- Business Area / Unit --
    "BUSINESS_AREA": "SAP business area code for segmented financial reporting.",
    "GBU": "Global Business Unit classification.",
    "BU": "Business Unit code.",
    "MBU": "Major Business Unit classification.",
    "LINE_OF_BUSINESS": "Line of business classification for the transaction.",

    # -- Reference Documents --
    "REFERENCE_DOCUMENT_TYPE": "Type code of the reference document linked to the transaction.",
    "REFERENCE_DOCUMENT_TYPE_DESCRIPTION": "Descriptive name of the reference document type.",
    "SHIPMENT_NUMBER": "SAP shipment document number for transportation planning.",
    "BATCH_NUMBER": "Batch or lot number for inventory tracking.",

    # -- Miscellaneous --
    "REFRESH_DATE_UTC": "UTC timestamp of the last data refresh.",
    "_EXTRACT_DATE": "Date when the data was extracted from the source system.",
    "PERIOD": "Reporting period identifier.",
    "FILTER": "General-purpose filter or flag column.",
    "CAT_MAPPING": "Category mapping code used for cross-reference or reclassification.",
    "SPEND_TYPE": "Classification of the spend type for procurement analytics.",
}

# ---------------------------------------------------------------------------
# 2. Suffix / pattern rules  (regex, template)
#    The template may use {name} for the normalised column name and
#    {prefix} for the portion before the matched suffix.
# ---------------------------------------------------------------------------
_SUFFIX_RULES: List[tuple] = [
    # Descriptions
    (r"_DESC$", "Descriptive text or label for {prefix}."),
    (r"_DESC_CONCAT$", "Concatenated code and description of {prefix} for display purposes."),
    (r"_DESCRIPTION$", "Full description of {prefix}."),
    (r"_LONG_DESC$", "Long-form description of {prefix}."),
    (r"_LONG_NAME$", "Full long name of {prefix}."),
    (r"_NAME$", "Descriptive name of {prefix}."),
    (r"_NAME_CONCAT$", "Concatenated identifier and name of {prefix} for display purposes."),

    # Codes / Keys
    (r"_CODE$", "Code or identifier for {prefix}."),
    (r"_KEY$", "Key identifier for {prefix}."),
    (r"_ID$", "Unique identifier for {prefix}."),
    (r"_NUM$", "Number assigned to {prefix}."),
    (r"_NUMBER$", "Number assigned to {prefix}."),
    (r"_SID$", "Surrogate/system ID key for {prefix}."),

    # Flags / Indicators
    (r"_FLAG$", "Flag indicator for {prefix} classification."),
    (r"_IND$", "Indicator for {prefix}."),
    (r"_INDICATOR$", "Indicator classifying {prefix}."),
    (r"_IND_NAME$", "Descriptive indicator name for {prefix}."),
    (r"_TAG_CODE$", "Tag code for {prefix}."),
    (r"_TYPE$", "Type classification for {prefix}."),
    (r"_TYPE_DESC$", "Description of the type classification for {prefix}."),
    (r"_TYPE_NAME$", "Name of the type classification for {prefix}."),
    (r"_CATEGORY$", "Category classification for {prefix}."),

    # Amounts / Currency
    (r"_AMOUNT.*CURR$", "Monetary amount for {prefix} expressed in the specified currency."),
    (r"_CURRENCY_KEY$", "ISO currency code for {prefix}."),
    (r"_CURR$", "Currency key for {prefix}."),
    (r"_VALUE.*CURR$", "Monetary value for {prefix} in the document currency."),

    # Quantities / Volume
    (r"_QTY.*$", "Quantity for {prefix} in the applicable unit of measure."),
    (r"_QUANTITY.*$", "Quantity measurement for {prefix}."),
    (r"_VOLUME$", "Volume measurement for {prefix}."),
    (r"_VOLUME_UOM$", "Unit of measure for {prefix} volume."),
    (r"_UOM$", "Unit of measure for {prefix}."),
    (r"_UNIT$", "Unit of measure for {prefix}."),

    # Dates
    (r"_DATE$", "Date associated with {prefix}."),
    (r"_DATE_UTC$", "UTC date/timestamp for {prefix}."),
    (r"_TIMESTAMP$", "Timestamp indicating when {prefix} occurred or was recorded."),

    # Hierarchy levels
    (r"_LEVEL_?\d+$", "Hierarchy level value for {prefix}."),
    (r"_LEVEL_?\d+_DESC(?:RIPTION)?$", "Description of the hierarchy level for {prefix}."),
    (r"_LEVEL_?\d+_NAME$", "Name of the hierarchy level for {prefix}."),
    (r"_LVL_?\d+$", "Hierarchy level value for {prefix}."),
    (r"_LVL_?\d+_DESC$", "Description of the hierarchy level for {prefix}."),
    (r"_HIER(?:ARCHY)?$", "Full hierarchy path or code for {prefix}."),

    # Documents
    (r"_DOC(?:UMENT)?$", "Document number for {prefix}."),
    (r"_DOC_ITEM$", "Line item within the {prefix} document."),
    (r"_DOC_NUM$", "Document number for {prefix}."),
    (r"_DOC_HEADER_TEXT$", "Header text of the {prefix} document."),

    # Geography
    (r"_COUNTRY$", "Country associated with {prefix}."),
    (r"_COUNTRY_CODE$", "ISO country code for {prefix}."),
    (r"_COUNTRY_NAME$", "Country name for {prefix}."),
    (r"_REGION$", "Geographic region for {prefix}."),
    (r"_REGION_NAME$", "Geographic region name for {prefix}."),
    (r"_SUPER_REGION$", "Super-region grouping for {prefix}."),
    (r"_CITY$", "City associated with {prefix}."),
    (r"_POSTAL_CODE$", "Postal or ZIP code for {prefix}."),

    # Organisation
    (r"_ORG$", "Organization code for {prefix}."),
    (r"_ORG_DESC$", "Description of the {prefix} organization."),
    (r"_ORG_NAME$", "Name of the {prefix} organization."),
]

# ---------------------------------------------------------------------------
# 3. Prefix rules — common SAP module prefixes
# ---------------------------------------------------------------------------
_PREFIX_MAP: Dict[str, str] = {
    "MM_": "Materials Management: ",
    "MM_SO_": "Sales Order: ",
    "MM_STO_": "Stock Transfer Order: ",
    "MM_PO_": "Purchase Order: ",
    "MM_REC_": "Receiving plant: ",
    "MM_FO_": "Freight Order: ",
    "MM_DELIVERY_": "Delivery document: ",
    "FDF_": "Financial Document Flow: ",
    "SRV_": "Service: ",
    "PNS_": "P&L Net-income Statement: ",
    "VM_": "Vessel/Voyage Management: ",
    "R_": "Rail: ",
    "P_": "Packaging: ",
    "LS_": "Logistics Services: ",
    "IBT_": "Intercompany/Business Transfer: ",
    "VR_": "Vessel/Route: ",
    "CAL_": "Calendar/Nomination: ",
}

# ---------------------------------------------------------------------------
# 4. Domain keyword expansions
# ---------------------------------------------------------------------------
_KEYWORD_MAP: Dict[str, str] = {
    "acct": "account",
    "agrmt": "agreement",
    "amt": "amount",
    "bbl": "barrels",
    "bp": "business partner",
    "bu": "business unit",
    "cal": "calendar",
    "cat": "category",
    "cf": "cash flow",
    "chng": "channel",
    "coc": "controlling object currency",
    "cogs": "cost of goods sold",
    "concat": "concatenated",
    "curr": "currency",
    "cust": "customer",
    "dc": "distribution channel",
    "desc": "description",
    "dest": "destination",
    "dfx": "downstream fuels and chemicals",
    "dist": "distribution",
    "dlry": "delivery",
    "doc": "document",
    "ebd": "Earnings Before Depreciation",
    "emop": "ExxonMobil Operated Property",
    "fi": "Financial Accounting",
    "fm": "Financial Management",
    "fo": "freight order",
    "func": "functional",
    "gbu": "Global Business Unit",
    "gl": "General Ledger",
    "glc": "global currency",
    "glob": "global",
    "gom": "Gulf of Mexico",
    "grp": "group",
    "hier": "hierarchy",
    "ibt": "Intercompany Business Transfer",
    "inb": "inbound",
    "ind": "indicator",
    "inv": "inventory",
    "kg": "kilograms",
    "lcr": "Logistics Cost Reporting",
    "lobp": "Line of Business Product",
    "loc": "location",
    "ls": "Logistics Services",
    "lvl": "level",
    "mat": "material",
    "mbu": "Major Business Unit",
    "mm": "Materials Management",
    "mngmt": "management",
    "mot": "mode of transport",
    "mvmt": "movement",
    "num": "number",
    "obo": "On Behalf Of",
    "org": "organization",
    "orig": "origin",
    "pc": "profit center",
    "pl": "profit and loss",
    "pns": "P&L Net-income Statement",
    "po": "purchase order",
    "posid": "position ID",
    "prctr": "profit center",
    "prod": "product",
    "psp": "project structure plan",
    "qty": "quantity",
    "rec": "receiving",
    "ref": "reference",
    "ru": "reporting unit",
    "scac": "Standard Carrier Alpha Code",
    "sid": "surrogate ID",
    "so": "sales order",
    "srv": "service",
    "stcc": "Standard Transportation Commodity Code",
    "sto": "stock transfer order",
    "tc": "transaction currency",
    "tg": "trading/global",
    "ufo": "Upstream Functional Organization",
    "uom": "unit of measure",
    "vm": "Vessel Management",
    "vol": "volume",
    "vr": "vessel/route",
    "wbs": "Work Breakdown Structure",
    "wh": "warehouse",
}


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def generate_description(column_name: str, table_name: str = "") -> str:
    """Return a business glossary description for *column_name*.

    Resolution order:
      1. Exact match in the known glossary.
      2. Suffix/pattern rule match.
      3. Token-based inference from domain keywords.
    """
    if not column_name:
        return ""

    upper = column_name.strip().upper()

    # --- 1. Exact lookup ---
    if upper in _EXACT:
        return _EXACT[upper]

    # Also try without leading module prefix (e.g. MM_PLANT_NAME -> PLANT_NAME)
    for pfx in sorted(_PREFIX_MAP, key=len, reverse=True):
        if upper.startswith(pfx.upper()):
            stripped = upper[len(pfx):]
            if stripped in _EXACT:
                ctx = _PREFIX_MAP[pfx].rstrip(": ")
                return f"{_EXACT[stripped]} (Context: {ctx})"
            break

    # --- 2. Suffix / pattern rules ---
    for pattern, template in _SUFFIX_RULES:
        m = re.search(pattern, upper)
        if m:
            prefix_part = upper[: m.start()]
            # Humanise the prefix: replace underscores, title-case
            human_prefix = _humanise(prefix_part)
            if human_prefix:
                return template.format(name=_humanise(upper), prefix=human_prefix)

    # --- 3. Token-based inference ---
    return _infer_from_tokens(column_name, table_name)


def enrich_glossary(
    rows: List[Dict[str, str]],
    col_hdr: str,
    desc_hdr: str,
    table_hdr: Optional[str] = None,
) -> int:
    """Populate empty *desc_hdr* fields using auto-generated descriptions.

    Modifies *rows* in-place and returns the count of newly generated
    descriptions.
    """
    generated = 0
    for row in rows:
        existing = row.get(desc_hdr, "").strip()
        if existing:
            continue  # already has a description
        col_name = row.get(col_hdr, "").strip()
        tbl_name = row.get(table_hdr, "").strip() if table_hdr else ""
        if not col_name:
            continue
        desc = generate_description(col_name, tbl_name)
        if desc:
            row[desc_hdr] = desc
            generated += 1
    return generated


# ---------------------------------------------------------------------------
# Internals
# ---------------------------------------------------------------------------

def _humanise(token_str: str) -> str:
    """Convert 'MM_PLANT_COUNTRY_NAME' → 'Plant Country Name'."""
    # Strip common prefixes
    s = token_str
    for pfx in sorted(_PREFIX_MAP, key=len, reverse=True):
        if s.upper().startswith(pfx.upper()):
            s = s[len(pfx):]
            break
    parts = re.split(r"[_\-\s]+", s)
    expanded = []
    for p in parts:
        low = p.lower()
        if low in _KEYWORD_MAP:
            expanded.append(_KEYWORD_MAP[low].title())
        elif p:
            expanded.append(p.capitalize())
    return " ".join(expanded)


def _infer_from_tokens(column_name: str, table_name: str = "") -> str:
    """Build a best-effort description by expanding tokens."""
    tokens = re.split(r"[_\-\s]+", column_name.strip())
    if not tokens:
        return ""

    expanded: List[str] = []
    for t in tokens:
        low = t.lower()
        if low in _KEYWORD_MAP:
            expanded.append(_KEYWORD_MAP[low])
        elif t:
            expanded.append(t.lower())

    # Compose a readable sentence
    phrase = " ".join(expanded)

    # Determine a context prefix from the module indicator
    context = ""
    upper = column_name.upper()
    for pfx in sorted(_PREFIX_MAP, key=len, reverse=True):
        if upper.startswith(pfx.upper()):
            context = _PREFIX_MAP[pfx].rstrip(": ")
            break

    if context:
        return f"{context} field representing the {phrase}."
    elif table_name:
        return f"Field representing the {phrase} in the {table_name} table."
    else:
        return f"Field representing the {phrase}."
