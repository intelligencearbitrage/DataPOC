"""
CDH Sample Data Generator.

When the CDH Metadata file has no Sample_Data sheet, this module generates
synthetic representative values for each column using three tiers:

  Tier 1 — Domain dictionary: regex patterns → curated value sets.
  Tier 2 — Data-type / suffix inference: naming conventions → typed generators.
  Tier 3 — Glossary description heuristics: keyword scanning → best-effort values.

All generation is deterministic (seeded random) and requires no external APIs.

Public API
----------
generate_cdh_sample_data(tobe_rows, col_hdr, desc_hdr=None, table_hdr=None)
    → List[Dict[str, str]]
"""

from __future__ import annotations

import hashlib
import logging
import random
import re
from typing import Dict, List, Optional, Sequence, Tuple

logger = logging.getLogger(__name__)

# Number of synthetic rows to produce per column
_NUM_ROWS = 30

# ---------------------------------------------------------------------------
# Tier 1 — Domain dictionary
# Each entry: (compiled regex matched against column_name.upper(), value list)
# ---------------------------------------------------------------------------
_DOMAIN_RULES: List[Tuple[re.Pattern, List[str]]] = [
    # Customer / market
    (re.compile(r"SEGMENT|CUST.*SEG|MARKET.*SEG", re.I), [
        "Consumer", "Corporate", "Home Office", "Small Business",
    ]),
    (re.compile(r"^REGION$|SALES.*REGION|GEO.*REGION|COMPANY.*REGION|ORIGIN.*REGION|DEST.*REGION|_REGION$", re.I), [
        "North America", "Europe", "Asia Pacific", "Latin America",
        "Middle East & Africa", "Africa", "Americas", "Middle East",
    ]),
    (re.compile(r"COUNTRY.*REGION|COUNTRY.*NAME|^COUNTRY$", re.I), [
        "United States", "Canada", "United Kingdom", "Germany", "France",
        "Australia", "Japan", "Brazil", "India", "Mexico",
        "China", "Italy", "Netherlands", "Belgium", "Norway",
        "Singapore", "South Korea", "Thailand", "Saudi Arabia",
        "Nigeria", "United Arab Emirates",
    ]),
    (re.compile(r"COUNTRY.*CODE|ISO.*COUNTRY", re.I), [
        "US", "CA", "GB", "DE", "FR", "AU", "JP", "BR", "IN", "MX",
    ]),
    (re.compile(r"^STATE$|STATE.*PROVINCE|^PROVINCE$", re.I), [
        "Texas", "California", "New York", "Illinois", "Florida",
        "Pennsylvania", "Ohio", "Georgia", "Virginia", "Washington",
    ]),
    (re.compile(r"^CITY$|CITY.*NAME", re.I), [
        "Houston", "Los Angeles", "New York", "Chicago", "Miami",
        "Philadelphia", "Columbus", "Atlanta", "Seattle", "Dallas",
    ]),
    (re.compile(r"POSTAL.*CODE|ZIP.*CODE|^ZIP$|^POSTCODE$", re.I), [
        "77095", "90032", "10001", "60601", "33101",
        "19103", "43201", "30301", "98101", "75201",
    ]),

    # Shipping / Logistics
    (re.compile(r"SHIP.*MODE|SHIPPING.*MODE|DELIVERY.*MODE", re.I), [
        "Standard Class", "Second Class", "First Class", "Same Day",
    ]),
    (re.compile(r"SHIP.*METHOD|DELIVERY.*METHOD|CARRIER", re.I), [
        "Ground", "Express", "Overnight", "Freight", "LTL",
    ]),
    (re.compile(r"ORDER.*STATUS|^STATUS$|SHIPMENT.*STATUS", re.I), [
        "Pending", "Processing", "Shipped", "Delivered", "Cancelled", "Returned",
    ]),
    (re.compile(r"ORDER.*PRIORITY|^PRIORITY$", re.I), [
        "Critical", "High", "Medium", "Low", "Not Specified",
    ]),

    # Product
    (re.compile(r"^CATEGORY$|PRODUCT.*CATEGORY|PROD.*CAT", re.I), [
        "Technology", "Furniture", "Office Supplies",
    ]),
    (re.compile(r"SUB.*CATEGORY|SUB.*CAT|SUBCATEGORY", re.I), [
        "Phones", "Chairs", "Storage", "Tables", "Accessories",
        "Paper", "Binders", "Art", "Copiers", "Labels",
    ]),
    (re.compile(r"PRODUCT.*NAME|PROD.*NAME|ITEM.*NAME", re.I), [
        "Xerox Copier Paper", "Staples Binders", "Hon Executive Chair",
        "Samsung Galaxy Tab", "Logitech MX Mouse", "Brother Printer",
        "Cisco IP Phone", "Safco Desk Organizer", "3M Tape Dispenser",
        "Fellowes Shredder",
    ]),
    (re.compile(r"BRAND|MANUFACTURER", re.I), [
        "Samsung", "Apple", "Dell", "HP", "Lenovo",
        "Cisco", "3M", "Fellowes", "Logitech", "Brother",
    ]),

    # Customer
    (re.compile(r"CUSTOMER.*NAME|CUST.*NAME|BUYER.*NAME|CLIENT.*NAME", re.I), [
        "Darren Powers", "Phillina Ober", "Sean O'Donnell",
        "Brosina Hoffman", "Andrew Allen", "Irene Maddox",
        "Harold Pawlan", "Pete Kriz", "Maria Etezadi", "Gene Hale",
    ]),
    (re.compile(r"CUSTOMER.*ID|CUST.*ID|BUYER.*ID|CLIENT.*ID", re.I), [
        "DP-13000", "PO-19195", "SO-20335", "BH-11710", "AA-10315",
        "IM-15070", "HP-14815", "PK-19075", "ME-17320", "GH-14410",
    ]),

    # Currency
    (re.compile(r"CURRENCY|CURR.*CODE|CURR.*KEY", re.I), [
        "USD", "EUR", "GBP", "JPY", "CAD", "AUD", "CHF", "CNY",
    ]),

    # SAP / ERP organisation
    (re.compile(r"COMPANY.*CODE|COMP.*CODE|BUKRS", re.I), [
        "1000", "2000", "3000", "4000", "5000",
    ]),
    (re.compile(r"PLANT|^WERKS$", re.I), [
        "1000", "1100", "1200", "2000", "2100", "3000",
    ]),
    (re.compile(r"COST.*CENTER|KOSTL", re.I), [
        "CC1000", "CC2000", "CC3000", "CC4000", "CC5000",
    ]),
    (re.compile(r"PROFIT.*CENTER", re.I), [
        "PC100", "PC200", "PC300", "PC400", "PC500",
    ]),
    (re.compile(r"MATERIAL.*GROUP|MATL.*GRP|MATKL", re.I), [
        "MG001", "MG002", "MG003", "MG004", "MG005",
    ]),
    (re.compile(r"MATERIAL$|^MATNR$|MATERIAL.*NUM", re.I), [
        "MAT-10001", "MAT-10002", "MAT-10003", "MAT-10004", "MAT-10005",
    ]),
    (re.compile(r"^VENDOR$|VENDOR.*NAME|SUPPLIER.*NAME", re.I), [
        "Acme Corp", "Global Logistics Inc", "Tech Parts LLC",
        "Industrial Supply Co", "Prime Wholesale",
    ]),
    (re.compile(r"VENDOR.*ID|VENDOR.*NUM|SUPPLIER.*ID|LIFNR", re.I), [
        "V-1001", "V-1002", "V-1003", "V-1004", "V-1005",
    ]),

    # Document types
    (re.compile(r"DOCUMENT.*TYPE|DOC.*TYPE|BSART|BLART", re.I), [
        "RE", "SA", "KR", "AB", "WE", "ZP",
    ]),

    # Unit of measure
    (re.compile(r"UNIT.*MEASURE|^UOM$|_UOM$|MEINS", re.I), [
        "EA", "KG", "LB", "GAL", "L", "MT", "BBL",
    ]),

    # Charge / cost type / cost categories
    (re.compile(r"CHARGE.*TYPE|CHARGE.*CATEG|COST.*CATEG|COST.*ELEMENT|KSTAR", re.I), [
        "Freight - Ocean", "Freight - Truck", "Freight - Rail",
        "Freight - Pipeline", "Handling & Loading", "Insurance",
        "Demurrage", "Warehousing & Storage", "Port Charges",
        "Taxes & Duties", "Inspection & Testing", "Transportation",
    ]),

    # Cost type (Actual / Budget / Forecast) — must be before generic flag rule
    (re.compile(r"COST.*TYPE|^COST_TYPE$", re.I), [
        "Actual", "Budget", "Forecast", "Plan", "Prior Year Actual",
    ]),

    # Volume type
    (re.compile(r"VOLUME.*TYPE|VOL.*TYPE", re.I), [
        "Delivery Volume", "Production Volume", "Sales Volume",
        "Throughput Volume", "Transfer Volume",
    ]),

    # Value chain (energy / chemicals)
    (re.compile(r"VALUE.*CHAIN|BUS.*SEGMENT", re.I), [
        "Chemical", "Downstream Fuels", "Downstream Lubricants",
        "Global Supply Chain", "Upstream",
    ]),

    # Mode of transport
    (re.compile(r"MODE.*TRANSPORT|TRANSPORT.*MODE", re.I), [
        "Ocean", "Truck", "Rail", "Pipeline", "Barge", "Air",
    ]),

    # SO / STO / Inbound indicator — must be before generic flag rule
    (re.compile(r"SO_STO|STO_IND|INB.*IND", re.I), [
        "SO", "STO", "INB",
    ]),

    # Record version
    (re.compile(r"RECORD.*VERSION|DATA.*VERSION", re.I), [
        "V1 - Current", "V2 - Prior Period", "V3 - Restated",
    ]),

    # P&L hierarchy levels
    (re.compile(r"P.*L.*LEVEL|PNL.*LEVEL|ACCOUNT.*HIER.*LEVEL.*NAME", re.I), [
        "Gross Margin", "Net Revenue", "Cost of Goods Sold",
        "Operating Expense", "Transportation Costs", "Warehousing",
        "Truck Freight", "Ocean Freight", "Pipeline Tariff",
    ]),

    # Incoterms
    (re.compile(r"INCOTERM", re.I), [
        "CIF", "FOB", "DAP", "DDP", "FCA", "EXW", "CPT", "CIP",
    ]),

    # Shipping condition
    (re.compile(r"SHIPPING.*COND|SHIP.*COND", re.I), [
        "Standard", "Express", "Bulk", "Tank", "Refrigerated",
    ]),

    # Yes / No / Y / N flags — MUST be last among specific-value rules
    # so that more specific patterns (SO_STO, COST_TYPE) match first
    (re.compile(r"RETURNED|IS_.*|.*_FLAG$|.*_IND$|.*_INDICATOR$", re.I), [
        "Yes", "No", "Y", "N",
    ]),
]

# ---------------------------------------------------------------------------
# Tier 2 — Data-type / naming-convention inference
# ---------------------------------------------------------------------------
_TIER2_RULES: List[Tuple[re.Pattern, str]] = [
    # Date columns
    (re.compile(r"DATE|_DT$|TIMESTAMP|_TS$", re.I), "date"),
    # Monetary amounts
    (re.compile(r"AMOUNT|_AMT$|PRICE|COST|REVENUE|SALES|PROFIT|VALUE|TOTAL|BUDGET|SPEND", re.I), "money"),
    # Quantities
    (re.compile(r"QTY|QUANTITY|COUNT|VOLUME|WEIGHT|_KG$|_LBS$|_MT$", re.I), "quantity"),
    # Percentages
    (re.compile(r"PCT|PERCENT|RATIO|RATE|MARGIN", re.I), "percent"),
    # ID / key columns
    (re.compile(r"_ID$|_KEY$|_NUM$|_NUMBER$|_SID$|_NO$", re.I), "id"),
    # Code columns
    (re.compile(r"_CODE$|_CD$", re.I), "code"),
    # Name columns
    (re.compile(r"_NAME$|_DESC$|_DESCRIPTION$|_LABEL$|_TEXT$", re.I), "text"),
]

# ---------------------------------------------------------------------------
# Tier 3 — Glossary description keyword mapping
# ---------------------------------------------------------------------------
_DESCRIPTION_KEYWORDS: List[Tuple[re.Pattern, str]] = [
    (re.compile(r"\bflag\b|\bindicator\b|\bboolean\b", re.I), "flag"),
    (re.compile(r"\bdate\b|\btimestamp\b|\bwhen\b", re.I), "date"),
    (re.compile(r"\bamount\b|\bcost\b|\bprice\b|\bmonetary\b|\bcurrency\b", re.I), "money"),
    (re.compile(r"\bquantity\b|\bvolume\b|\bweight\b|\bcount\b|\bnumber of\b", re.I), "quantity"),
    (re.compile(r"\bpercent\b|\bratio\b|\brate\b|\bmargin\b", re.I), "percent"),
    (re.compile(r"\bidentifier\b|\bunique\b|\bkey\b|\bsurrogate\b", re.I), "id"),
    (re.compile(r"\bcode\b|\bclassification\b", re.I), "code"),
    (re.compile(r"\bname\b|\bdescription\b|\blabel\b|\btext\b", re.I), "text"),
]


# ---------------------------------------------------------------------------
# Typed generators — seeded per column for determinism
# ---------------------------------------------------------------------------

def _seeded_rng(column_name: str) -> random.Random:
    """Return a deterministic Random instance seeded from the column name."""
    seed = int(hashlib.md5(column_name.encode()).hexdigest()[:8], 16)
    return random.Random(seed)


def _gen_date(rng: random.Random, n: int) -> List[str]:
    base_year = 2023
    vals = []
    for _ in range(n):
        y = rng.randint(base_year, base_year + 2)
        m = rng.randint(1, 12)
        d = rng.randint(1, 28)
        vals.append(f"{y}-{m:02d}-{d:02d}")
    return vals


def _gen_money(rng: random.Random, n: int) -> List[str]:
    return [f"{rng.uniform(10, 9999):.2f}" for _ in range(n)]


def _gen_quantity(rng: random.Random, n: int) -> List[str]:
    return [str(rng.randint(1, 500)) for _ in range(n)]


def _gen_percent(rng: random.Random, n: int) -> List[str]:
    return [f"{rng.uniform(0.01, 99.99):.2f}" for _ in range(n)]


def _gen_id(rng: random.Random, n: int) -> List[str]:
    return [str(rng.randint(100001, 999999)) for _ in range(n)]


def _gen_code(rng: random.Random, n: int) -> List[str]:
    letters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
    return [
        f"{rng.choice(letters)}{rng.choice(letters)}-{rng.randint(100, 999)}"
        for _ in range(n)
    ]


def _gen_text(rng: random.Random, n: int) -> List[str]:
    words = [
        "Alpha", "Beta", "Gamma", "Delta", "Epsilon",
        "Omega", "Sigma", "Theta", "Lambda", "Kappa",
    ]
    return [f"{rng.choice(words)} {rng.choice(words)} {rng.randint(1, 99)}" for _ in range(n)]


def _gen_flag(rng: random.Random, n: int) -> List[str]:
    return [rng.choice(["Yes", "No"]) for _ in range(n)]


_TYPE_GENERATORS = {
    "date": _gen_date,
    "money": _gen_money,
    "quantity": _gen_quantity,
    "percent": _gen_percent,
    "id": _gen_id,
    "code": _gen_code,
    "text": _gen_text,
    "flag": _gen_flag,
}


# ---------------------------------------------------------------------------
# Core generation logic
# ---------------------------------------------------------------------------

def _generate_column_values(
    column_name: str,
    description: str = "",
) -> List[str]:
    """Generate a list of representative sample values for a single column."""
    upper = column_name.upper()
    rng = _seeded_rng(upper)

    # Tier 1: domain dictionary lookup
    for pattern, values in _DOMAIN_RULES:
        if pattern.search(upper):
            return [rng.choice(values) for _ in range(_NUM_ROWS)]

    # Tier 2: naming convention inference
    for pattern, dtype in _TIER2_RULES:
        if pattern.search(upper):
            gen = _TYPE_GENERATORS[dtype]
            return gen(rng, _NUM_ROWS)

    # Tier 3: glossary description heuristics
    if description:
        for pattern, dtype in _DESCRIPTION_KEYWORDS:
            if pattern.search(description):
                gen = _TYPE_GENERATORS[dtype]
                return gen(rng, _NUM_ROWS)

    # Fallback: generic alphanumeric codes
    return _gen_code(rng, _NUM_ROWS)


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def generate_cdh_sample_data(
    tobe_rows: List[Dict[str, str]],
    col_hdr: str,
    desc_hdr: Optional[str] = None,
    table_hdr: Optional[str] = None,
) -> List[Dict[str, str]]:
    """Generate synthetic sample data for CDH columns that lack a Sample_Data sheet.

    Args:
        tobe_rows: CDH lineage rows (list of dicts).
        col_hdr:   Header key for "Column Name" in tobe_rows.
        desc_hdr:  Header key for "Column Description" (optional).
        table_hdr: Header key for "Table Name" (optional).

    Returns:
        List of row-dicts in the same format as _read_sample_data_sheet output,
        suitable for _build_value_fingerprints().
    """
    if not tobe_rows or not col_hdr:
        return []

    # Collect unique column names
    columns: List[Tuple[str, str]] = []  # (col_name, description)
    seen: set = set()
    for row in tobe_rows:
        col = row.get(col_hdr, "").strip()
        if not col or col.lower() in seen:
            continue
        seen.add(col.lower())
        desc = row.get(desc_hdr, "") if desc_hdr else ""
        columns.append((col, desc))

    if not columns:
        return []

    # Generate values per column
    col_values: Dict[str, List[str]] = {}
    for col_name, description in columns:
        col_values[col_name] = _generate_column_values(col_name, description)

    # Assemble into row-dicts
    sample_rows: List[Dict[str, str]] = []
    for i in range(_NUM_ROWS):
        row: Dict[str, str] = {}
        for col_name, values in col_values.items():
            row[col_name] = values[i] if i < len(values) else ""
        sample_rows.append(row)

    logger.info(
        "Generated %d synthetic sample rows for %d CDH columns",
        len(sample_rows), len(columns),
    )
    return sample_rows
