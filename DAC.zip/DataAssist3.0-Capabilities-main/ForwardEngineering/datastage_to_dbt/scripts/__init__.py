"""
Scripts Package

Developer feature scripts are organized into subfolders under scripts/.

Subfolders:
- datastage-to-dbt/ : DataStage XML to dbt model converter
    - generate_dbt_models.py : Parses XML and generates three-layer dbt project
    - validator.py           : Validates output against source XML
    - refiner.py             : Auto-patches output based on validation reports
    - prompts.py             : Centralized prompt templates for agentic layer
    - build_all.py           : Master script that runs all generators
    - base_parser.py         : Abstract base class for input parsers
    - base_generator.py      : Abstract base class for output generators
    - base_validator.py      : Abstract base class for output validators
    - utils.py               : Shared utility functions
    - cli.py                 : Single CLI entry point
    - requirements.txt       : Python dependencies
    - README.md              : Documentation
"""
