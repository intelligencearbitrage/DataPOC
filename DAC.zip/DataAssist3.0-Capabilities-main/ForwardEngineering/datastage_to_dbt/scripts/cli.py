#!/usr/bin/env python3
"""
CLI entry point for the DataStage-to-dbt converter.

Provides a single command-line interface to trigger generation, validation,
and refinement of dbt models from IBM DataStage XML job exports.

Usage:
    python scripts/datastage-to-dbt/cli.py generate
    python scripts/datastage-to-dbt/cli.py validate
    python scripts/datastage-to-dbt/cli.py refine --report PATH
    python scripts/datastage-to-dbt/cli.py run
"""

import argparse
import shutil
import sys
import time
from pathlib import Path

SCRIPT_DIR = Path(__file__).resolve().parent
PROJECT_ROOT = SCRIPT_DIR.parent.parent
sys.path.insert(0, str(SCRIPT_DIR))

from utils import setup_logging, get_timestamp


def cmd_generate(args, logger):
    """Generate dbt models from DataStage XML files."""
    from generate_dbt_models import DbtModelGenerator, DataStageParser

    input_dir = args.input_dir or str(PROJECT_ROOT / "inputs")
    output_dir = args.output_dir or str(PROJECT_ROOT / "output")

    if args.clean:
        for d in (Path(output_dir), PROJECT_ROOT / "plans"):
            if d.exists():
                shutil.rmtree(d)
                d.mkdir(parents=True, exist_ok=True)
                logger.info(f"Cleaned: {d}")

    parser = DataStageParser(input_dir=input_dir, output_dir=output_dir)
    generator = DbtModelGenerator(
        parser=parser,
        plans_dir=str(PROJECT_ROOT / "plans"),
        output_dir=output_dir,
    )
    generator.generate()
    logger.info("Generation complete.")


def cmd_validate(args, logger):
    """Validate generated dbt models against source XML."""
    from validator import DbtOutputValidator

    input_dir = args.input_dir or str(PROJECT_ROOT / "inputs")
    output_dir = args.output_dir or str(PROJECT_ROOT / "output")

    validator = DbtOutputValidator(
        input_dir=input_dir,
        output_dir=output_dir,
        report_dir=args.report_dir,
    )
    report, report_path = validator.run(job_name=args.job)

    vr = report.get("validation_report", {})
    accuracy = vr.get("overall_accuracy", 0)
    go_no_go = vr.get("go_no_go", {})
    logger.info(f"Accuracy: {accuracy}%")
    logger.info(f"Go/No-Go: {go_no_go.get('recommendation', 'N/A')} -- {go_no_go.get('reason', '')}")
    logger.info(f"Report: {report_path}")
    return report, str(report_path)


def cmd_refine(args, logger):
    """Refine dbt output based on a validation report."""
    from refiner import DbtOutputRefiner

    if not args.report:
        logger.error("--report is required for the refine command")
        sys.exit(1)

    input_dir = args.input_dir or str(PROJECT_ROOT / "inputs")
    output_dir = args.output_dir or str(PROJECT_ROOT / "output")

    human_feedback = None
    if args.feedback:
        fb_file = Path(args.feedback)
        if fb_file.exists():
            human_feedback = fb_file.read_text(encoding="utf-8").strip()
            logger.info(f"Loaded feedback from: {fb_file}")
        else:
            logger.warning(f"Feedback file not found: {fb_file}")

    refiner = DbtOutputRefiner(input_dir=input_dir, output_dir=output_dir)
    summary = refiner.refine(
        report_path=args.report,
        human_feedback=human_feedback,
        max_iterations=args.max_iterations,
    )

    logger.info(f"Accuracy: {summary.get('initial_accuracy', 'N/A')}% -> {summary.get('final_accuracy', 'N/A')}%")
    logger.info(f"Go/No-Go: {summary.get('final_go_no_go', 'N/A')}")
    return summary


def cmd_run(args, logger):
    """Run the full pipeline: generate -> validate -> refine."""
    logger.info("=" * 60)
    logger.info("STEP 1: Generating dbt models")
    logger.info("=" * 60)
    cmd_generate(args, logger)

    logger.info("")
    logger.info("=" * 60)
    logger.info("STEP 2: Validating output")
    logger.info("=" * 60)
    report, report_path = cmd_validate(args, logger)

    issues = report.get("validation_report", {}).get("issues", [])
    if issues:
        logger.info(f"\n{len(issues)} issue(s) found. Running refinement...")
        logger.info("=" * 60)
        logger.info("STEP 3: Refining output")
        logger.info("=" * 60)
        args.report = report_path
        cmd_refine(args, logger)
    else:
        logger.info("No issues found. Skipping refinement.")

    _print_summary(logger)


def _print_summary(logger):
    """Print a summary of generated output files."""
    output_dir = PROJECT_ROOT / "output"
    sql_files = list(output_dir.rglob("*.sql"))
    yml_files = list(output_dir.rglob("*.yml"))

    logger.info("")
    logger.info("=" * 60)
    logger.info("CONVERSION COMPLETE")
    logger.info("=" * 60)
    logger.info(f"  SQL models: {len(sql_files)}")
    logger.info(f"  YAML configs: {len(yml_files)}")

    staging = [f for f in sql_files if "staging" in str(f)]
    intermediate = [f for f in sql_files if "intermediate" in str(f)]
    marts = [f for f in sql_files if "marts" in str(f)]
    logger.info(f"  Staging: {len(staging)}  Intermediate: {len(intermediate)}  Marts: {len(marts)}")
    logger.info(f"  Output: {output_dir}")
    logger.info("=" * 60)


def main():
    parser = argparse.ArgumentParser(
        prog="datastage-to-dbt",
        description="DataStage XML to dbt model converter",
    )
    parser.add_argument("--verbose", action="store_true", help="Enable debug logging")

    subparsers = parser.add_subparsers(dest="command", help="Available commands")

    # --- generate ---
    gen_parser = subparsers.add_parser("generate", help="Generate dbt models from DataStage XML")
    gen_parser.add_argument("--input-dir", type=str, default=None, help="Input directory with XML files")
    gen_parser.add_argument("--output-dir", type=str, default=None, help="Output directory for dbt project")
    gen_parser.add_argument("--clean", action="store_true", help="Clean output before generating")

    # --- validate ---
    val_parser = subparsers.add_parser("validate", help="Validate generated dbt models")
    val_parser.add_argument("--input-dir", type=str, default=None, help="Input directory with XML files")
    val_parser.add_argument("--output-dir", type=str, default=None, help="Output directory to validate")
    val_parser.add_argument("--report-dir", type=str, default=None, help="Custom report output directory")
    val_parser.add_argument("--job", type=str, default=None, help="Validate a specific job name")

    # --- refine ---
    ref_parser = subparsers.add_parser("refine", help="Refine dbt output from a validation report")
    ref_parser.add_argument("--report", type=str, required=True, help="Path to validation report YAML")
    ref_parser.add_argument("--input-dir", type=str, default=None, help="Input directory with XML files")
    ref_parser.add_argument("--output-dir", type=str, default=None, help="Output directory to refine")
    ref_parser.add_argument("--feedback", type=str, default=None, help="Path to human feedback file")
    ref_parser.add_argument("--max-iterations", type=int, default=3, help="Max refinement iterations")

    # --- run (full pipeline) ---
    run_parser = subparsers.add_parser("run", help="Run full pipeline: generate + validate + refine")
    run_parser.add_argument("--input-dir", type=str, default=None, help="Input directory with XML files")
    run_parser.add_argument("--output-dir", type=str, default=None, help="Output directory for dbt project")
    run_parser.add_argument("--clean", action="store_true", help="Clean output before generating")
    run_parser.add_argument("--report-dir", type=str, default=None, help="Custom report output directory")
    run_parser.add_argument("--job", type=str, default=None, help="Validate a specific job name")
    run_parser.add_argument("--feedback", type=str, default=None, help="Path to human feedback file")
    run_parser.add_argument("--max-iterations", type=int, default=3, help="Max refinement iterations")
    run_parser.add_argument("--report", type=str, default=None, help="(auto-set by pipeline)")

    args = parser.parse_args()

    if not args.command:
        parser.print_help()
        sys.exit(1)

    import logging
    log_level = logging.DEBUG if args.verbose else logging.INFO
    logger = setup_logging("datastage-to-dbt", log_dir=PROJECT_ROOT / "logs", level=log_level)

    logger.info(f"datastage-to-dbt: {args.command}")
    logger.info(f"Started at: {get_timestamp()}")

    start_time = time.time()

    commands = {
        "generate": cmd_generate,
        "validate": cmd_validate,
        "refine": cmd_refine,
        "run": cmd_run,
    }
    try:
        commands[args.command](args, logger)
    except Exception as e:
        logger.error(f"Failed: {e}", exc_info=True)
        sys.exit(1)

    elapsed = time.time() - start_time
    logger.info(f"Total time: {elapsed:.1f}s")


if __name__ == "__main__":
    main()
