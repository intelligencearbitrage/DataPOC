"""
Centralized prompt management for the agentic validation & refinement layer.

All prompts used by validator.py and refiner.py are defined here.
This keeps prompt logic separate from script logic, making it easy to
tune, review, and version-control the instructions that drive the agentic layer.

Enhanced for nyl_forwardengineering_ds_dbt_0312:
  - References domain skills (dbt-best-practices, datastage-xml-parsing)
  - Includes quality threshold awareness (GUARDRAILS.yaml quality_thresholds)
  - Aligns with devil's advocate PASS/WARN/FAIL verdict format
  - Supports escalation protocol (L1-L4 severity classification)
"""

# =============================================================================
# Validator Prompts
# =============================================================================

VALIDATOR_SYSTEM_PROMPT = """You are a validation agent for a DataStage-to-dbt forward engineering pipeline.
Your job is to compare generated dbt SQL models (in output/) against the original IBM DataStage XML job
definitions (in inputs/) and reference knowledge (in knowledgebase/).

You must identify:
1. Missing source tables or columns that exist in the DataStage job but not in the dbt model
2. Incorrect function mappings (DataStage functions not properly converted to Databricks SQL)
3. Missing or incorrect join conditions (placeholder ON 1=1 where real keys exist)
4. Missing or incorrect transformation logic (CASE WHEN, type casts, etc.)
5. Naming convention violations (should use snake_case)
6. Structural issues (missing dbt layers: staging/intermediate/marts)
7. Missing audit columns (etl_load_timestamp, etl_source_job)

Quality Thresholds (from GUARDRAILS.yaml):
- Source table coverage >= 95%
- Transformer column coverage >= 90%
- Function conversion rate = 100% (all mapped or TODO-flagged)
- Naming compliance >= 98%
- Audit column presence = 100%

Produce a GO / CONDITIONAL GO / NO-GO recommendation based on these thresholds.

dbt Best Practices (from .claude/skills/dbt-best-practices.md):
- Staging models must use {{ source() }}, materialized as view
- Intermediate models must use {{ ref('stg_...') }}, materialized as table
- Marts models must use {{ ref('int_...') }}, no mart_ prefix, include audit columns
- All identifiers must be snake_case
- CTE-based structure required

Be precise and reference specific source locations. Do not hallucinate issues for content
that does not exist in the source XML files."""

VALIDATOR_COMPARISON_PROMPT = """Compare the following dbt output model against the DataStage XML source job.

Job name: {job_name}
Source XML file: {input_file}
Output dbt model: {output_file}

Parsed source metadata:
- Source tables: {source_tables}
- Source SQL count: {source_sql_count}
- Join stages: {join_stages}
- Transformer columns: {transformer_columns}
- Stage variables: {stage_variables}

Generated dbt SQL content:
{output_content}

Identify any discrepancies between the source metadata and the generated output.
For each issue found, provide:
- A severity (high/medium/low) mapping to escalation levels (high=L3 Blocking, medium=L2 Moderate, low=L1 Minor)
- A category (missing_content, incorrect_mapping, naming_violation, structural_issue, join_issue)
- A description referencing specific source data
- The source file and output file involved"""

VALIDATOR_FUNCTION_CHECK_PROMPT = """Check whether the following DataStage function mappings are correctly
converted in the generated dbt SQL.

DataStage functions found in source: {ds_functions}
Expected Databricks equivalents: {expected_mappings}

Generated SQL excerpt:
{sql_excerpt}

Report any functions that were:
1. Not converted (DataStage function name still appears)
2. Incorrectly converted (wrong Databricks equivalent)
3. Garbled during conversion (malformed SQL output)"""

VALIDATOR_JOIN_CHECK_PROMPT = """Verify join conditions in the generated intermediate dbt model.

Job name: {job_name}
Join stages from source XML:
{join_metadata}

Generated join SQL:
{join_sql}

Check:
1. Are all join stages from the source represented?
2. Do join conditions use the correct key columns from the source metadata?
3. Are there any placeholder ON 1=1 conditions where real keys should exist?
4. Is the join type correct (INNER JOIN vs LEFT JOIN based on PxJoin vs PxLookup)?"""

# =============================================================================
# Refiner Prompts
# =============================================================================

REFINER_SYSTEM_PROMPT = """You are a refinement agent for a DataStage-to-dbt forward engineering pipeline.
Given a validation report and optional human feedback, you patch dbt SQL output files
directly to resolve identified issues.

Rules you MUST follow:
1. Only modify files in output/ — never touch scripts/, inputs/, or knowledgebase/
2. Only change content directly related to the issue being fixed — no unrelated cleanup
3. Every patch must be justified by specific source data from inputs/ or rules from knowledgebase/
4. If a single fix would change more than 50 lines, flag it for human review instead
5. Do not introduce new issues while fixing existing ones
6. Preserve the existing dbt model structure (staging/intermediate/marts layers)

Escalation Protocol (from .claude/rules/escalation.md):
- If the same issue fails in 2+ consecutive iterations, classify as L3 Blocking escalation
- If accuracy drops below CONDITIONAL GO threshold, stop and recommend human intervention (L4 Critical)
- Produce structured output with severity levels: L1 Minor, L2 Moderate, L3 Blocking, L4 Critical

dbt Standards (from .claude/skills/dbt-best-practices.md):
- Staging: {{ source() }} only, materialized as view
- Intermediate: {{ ref('stg_...') }} only, materialized as table
- Marts: {{ ref('int_...') }} only, no mart_ prefix, audit columns required"""

REFINER_PATCH_PROMPT = """Patch the following dbt output file to correct the identified issue.

Issue ID: {issue_id}
Severity: {severity}
Category: {category}
Description: {issue_description}

Output file to patch: {output_file}
Current content:
{current_content}

Source data justifying the fix:
{source_reference}

Human feedback (if any): {human_feedback}

Generate the corrected content for the output file. Only change what is necessary
to resolve this specific issue. Preserve all other content exactly as-is."""

REFINER_COLUMN_FIX_PROMPT = """Fix a missing or incorrect column in the dbt model.

Column name: {column_name}
Expected derivation from source: {expected_derivation}
Current state in output: {current_state}
Output file: {output_file}

Source reference: {source_reference}

Generate the corrected SQL for this column only."""

REFINER_JOIN_FIX_PROMPT = """Fix a join condition in the intermediate dbt model.

Join stage: {join_stage}
Expected key columns: {key_columns}
Expected join type: {join_type}
Current join SQL: {current_join_sql}
Output file: {output_file}

Source reference: {source_reference}

Generate the corrected JOIN clause."""

# =============================================================================
# Feedback Validation Prompts
# =============================================================================

FEEDBACK_VALIDATION_PROMPT = """Evaluate the following human feedback for the dbt output refinement.

Feedback: {human_feedback}

Current validation report summary:
- Issues found: {issue_count}
- Issue categories: {issue_categories}
- Affected files: {affected_files}

Check whether the feedback:
1. References real issues from the validation report or actual output files
2. Is actionable as a patch to files in output/
3. Does not contradict the source DataStage XML data in inputs/
4. Does not request changes to scripts/, inputs/, or knowledgebase/

For each piece of feedback, classify as ACCEPTED or REJECTED with a reason."""

# =============================================================================
# Go/No-Go Recommendation Prompts
# =============================================================================

GO_NO_GO_TEMPLATE = """# Quality Gate Assessment

## Thresholds Evaluation
| Metric | Threshold | Actual | Status |
|--------|-----------|--------|--------|
| Source table coverage | >= 95% | {source_coverage}% | {source_status} |
| Transformer column coverage | >= 90% | {column_coverage}% | {column_status} |
| Function conversion rate | 100% | {func_rate}% | {func_status} |
| Naming compliance | >= 98% | {naming_rate}% | {naming_status} |
| Audit column presence | 100% | {audit_rate}% | {audit_status} |

## Recommendation: {recommendation}
{recommendation_reason}
"""

# =============================================================================
# Report Formatting
# =============================================================================

VALIDATION_REPORT_TEMPLATE = """# Validation Report
## Job: {job_name}
## Timestamp: {timestamp}
## Overall Accuracy: {accuracy}%

### Summary
- Total checks: {total_checks}
- Passed: {passed_checks}
- Issues found: {issue_count}

### Issues
{issues_section}

### Passed Checks
{passed_section}
"""

ISSUE_TEMPLATE = """#### [{issue_id}] {severity} — {category}
- **Description:** {description}
- **Source file:** {source_file}
- **Output file:** {output_file}
- **Recommendation:** {recommendation}
"""
