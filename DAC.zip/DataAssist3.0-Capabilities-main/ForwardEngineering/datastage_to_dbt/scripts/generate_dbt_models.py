"""
Generate dbt models from IBM DataStage XML job files.

Parses DataStage XML exports from inputs/, applies transformation rules
from knowledgebase/, and produces a complete dbt project structure in output/.
Extends BaseParser for XML parsing and BaseGenerator for dbt SQL generation.

The script handles:
  - Double-encoded XMLProperties and raw XML Value properties
  - Source table extraction from 5 locations (FROM, JOIN, subqueries, <Table>, <TableName>)
  - DataStage IF/THEN/ELSE to SQL CASE WHEN conversion (including nested chains)
  - Function mapping (NullToValue->COALESCE, IsNull, string/date/type functions)
  - Oracle (+) outer join syntax to ANSI LEFT OUTER JOIN
  - Parameter conversion (#paramName# -> {{ var('...') }})
  - Stage variable inlining as intermediate CTEs
  - Three-layer dbt model generation (staging, intermediate, marts)
  - Per-layer schema files, cumulative source.yml, dbt_project.yml

Usage:
    python scripts/generate_dbt_models.py
    python scripts/build_all.py  (auto-discovers this script)
"""

import html
import re
from defusedxml import ElementTree as ET
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from base_parser import BaseParser
from base_generator import BaseGenerator
from utils import save_yaml, get_project_root, get_timestamp


# =============================================================================
# Constants: Function Mapping & Type Mapping
# =============================================================================

# DataStage function -> Databricks SQL equivalent
# Functions with {0} placeholders use special formatting; others are simple renames
FUNCTION_MAP: Dict[str, str] = {
    # Null handling
    'NullToValue': 'COALESCE',
    'NullToEmpty': 'COALESCE',
    'NVL': 'COALESCE',
    'IsNull': '{0} IS NULL',
    'IsNotNull': '{0} IS NOT NULL',
    'SetNull': 'NULL',
    # String functions
    'Trim': 'TRIM',
    'TrimLeading': 'LTRIM',
    'TrimTrailing': 'RTRIM',
    'Left': 'LEFT',
    'Right': 'RIGHT',
    'Len': 'LENGTH',
    'Upcase': 'UPPER',
    'Downcase': 'LOWER',
    'Index': 'LOCATE',
    'Field': 'SPLIT_PART',
    'PadString': 'LPAD',
    'StripWhiteSpace': 'TRIM',
    'Concatenate': 'CONCAT',
    # Type conversion
    'Convert': 'CAST',
    'DecimalToString': 'CAST({0} AS STRING)',
    'StringToDecimal': 'CAST({0} AS DECIMAL)',
    'StringToDate': 'TO_DATE',
    'DateToString': 'DATE_FORMAT',
    'TimestampToString': 'DATE_FORMAT',
    'StringToTimestamp': 'TO_TIMESTAMP',
    # Date/time
    'CurrentDate': 'CURRENT_DATE()',
    'CurrentTimestamp': 'CURRENT_TIMESTAMP()',
    'CurrentTime': 'CURRENT_TIMESTAMP()',
    'YearFromDate': 'YEAR',
    'MonthFromDate': 'MONTH',
    'DayFromDate': 'DAY',
    'DateFromComponents': 'MAKE_DATE',
    'DateOffsetByComponents': 'DATE_ADD',
    # Oracle compatibility (found in source SQL)
    'TO_CHAR': 'DATE_FORMAT',
    'TO_DATE': 'TO_DATE',
    'TO_NUMBER': 'CAST({0} AS DECIMAL)',
    'DECODE': 'CASE',
    'SUBSTR': 'SUBSTRING',
    'INSTR': 'LOCATE',
    'LPAD': 'LPAD',
    'RPAD': 'RPAD',
    'REPLACE': 'REPLACE',
    'TRUNC': 'TRUNC',
}

# DataStage SQL types -> Databricks SQL types
TYPE_MAP: Dict[str, str] = {
    'VarChar': 'STRING',
    'Char': 'STRING',
    'LongVarChar': 'STRING',
    'NVarChar': 'STRING',
    'NChar': 'STRING',
    'Integer': 'INT',
    'SmallInt': 'SMALLINT',
    'BigInt': 'BIGINT',
    'TinyInt': 'TINYINT',
    'Decimal': 'DECIMAL',
    'Numeric': 'DECIMAL',
    'Float': 'FLOAT',
    'Double': 'DOUBLE',
    'Real': 'FLOAT',
    'Date': 'DATE',
    'Timestamp': 'TIMESTAMP',
    'Time': 'STRING',
    'Binary': 'BINARY',
    'VarBinary': 'BINARY',
    'Bit': 'BOOLEAN',
    'Boolean': 'BOOLEAN',
}

# SQL type codes (SqlType numeric values) -> Databricks types
SQL_TYPE_CODE_MAP: Dict[str, str] = {
    '1': 'STRING',     # CHAR
    '4': 'INT',        # INTEGER
    '5': 'SMALLINT',   # SMALLINT
    '7': 'FLOAT',      # REAL
    '8': 'DOUBLE',     # DOUBLE
    '12': 'STRING',    # VARCHAR
    '-5': 'BIGINT',    # BIGINT
    '3': 'DECIMAL',    # DECIMAL
    '2': 'DECIMAL',    # NUMERIC
    '91': 'DATE',      # DATE
    '93': 'TIMESTAMP', # TIMESTAMP
    '-1': 'STRING',    # LONGVARCHAR
    '-4': 'BINARY',    # LONGVARBINARY
}

# Regex pattern for parameterized table references
TBL_PATTERN = r'[A-Za-z_#$][\w.#$]*'


# =============================================================================
# Helper Functions
# =============================================================================

def _to_snake(name: str) -> str:
    """Convert a name to snake_case, handling CamelCase and ALL_CAPS correctly.

    Examples:
        'CamelCase'    -> 'camel_case'
        'CREATED_TS'   -> 'created_ts'
        'PolicyID'     -> 'policy_id'
        'HTTPSHandler' -> 'https_handler'
    """
    s = re.sub(r'([A-Z]+)([A-Z][a-z])', r'\1_\2', name)
    s = re.sub(r'([a-z0-9])([A-Z])', r'\1_\2', s)
    s = re.sub(r'[^a-zA-Z0-9]', '_', s).lower()
    return re.sub(r'_+', '_', s).strip('_')


def _extract_select_columns(sql_text: str) -> List[str]:
    """Extract projected column names/aliases from a SQL SELECT statement.

    Parses the SELECT clause to find output column names, handling:
      - Simple columns: COL_NAME
      - Aliased columns: expr AS ALIAS, expr ALIAS
      - Table-qualified: TABLE.COL
      - TRIM(TABLE.COL) ALIAS patterns
      - Expressions with AS: CASE ... END AS ALIAS

    Returns uppercase column names for case-insensitive matching.
    """
    # Strip leading comments and whitespace
    cleaned = re.sub(r'/\*.*?\*/', '', sql_text, flags=re.DOTALL).strip()

    # Find the SELECT ... FROM boundary (first top-level FROM)
    # Handle nested subqueries by tracking parentheses
    upper = cleaned.upper()
    select_start = upper.find('SELECT')
    if select_start < 0:
        return []
    # Skip past SELECT [DISTINCT] [/*+ hints */]
    pos = select_start + 6
    rest = cleaned[pos:].lstrip()
    if rest.upper().startswith('DISTINCT'):
        rest = rest[8:].lstrip()
    # Skip optimizer hints like /*+ PARALLEL(...) */
    if rest.startswith('/*'):
        hint_end = rest.find('*/')
        if hint_end >= 0:
            rest = rest[hint_end + 2:].lstrip()

    # Find top-level FROM (not inside parentheses)
    depth = 0
    from_pos = None
    for i, ch in enumerate(rest):
        if ch == '(':
            depth += 1
        elif ch == ')':
            depth -= 1
        elif depth == 0 and rest[i:i + 5].upper() == '\nFROM':
            from_pos = i
            break
        elif depth == 0 and rest[i:i + 5].upper() == ' FROM':
            # Check it's a keyword boundary
            before = rest[i - 1] if i > 0 else ' '
            after = rest[i + 5] if i + 5 < len(rest) else ' '
            if not before.isalnum() and before != '_':
                if not after.isalnum() and after != '_':
                    from_pos = i
                    break

    select_clause = rest[:from_pos].strip() if from_pos else rest.strip()

    # Split by top-level commas
    cols: List[str] = []
    depth = 0
    current = []
    for ch in select_clause:
        if ch == '(':
            depth += 1
            current.append(ch)
        elif ch == ')':
            depth -= 1
            current.append(ch)
        elif ch == ',' and depth == 0:
            cols.append(''.join(current).strip())
            current = []
        else:
            current.append(ch)
    if current:
        cols.append(''.join(current).strip())

    # Extract the output name from each column expression
    result: List[str] = []
    for col_expr in cols:
        col_expr = col_expr.strip()
        if not col_expr:
            continue
        # Check for AS alias (last occurrence at top level)
        as_match = re.search(r'\bAS\s+(\w+)\s*$', col_expr, re.IGNORECASE)
        if as_match:
            result.append(as_match.group(1).upper())
            continue
        # Check for implicit alias: expr ALIAS (word at end after space)
        # e.g., TRIM(X.COL) ALIAS or TABLE.COL ALIAS
        tokens = col_expr.split()
        if len(tokens) >= 2:
            last_token = tokens[-1].strip()
            # If last token is a simple identifier (not a keyword/operator)
            if re.match(r'^[A-Za-z_]\w*$', last_token) and last_token.upper() not in (
                'FROM', 'WHERE', 'AND', 'OR', 'ON', 'AS', 'NULL',
                'THEN', 'ELSE', 'END', 'WHEN', 'CASE', 'ASC', 'DESC',
            ):
                # Check it's not the same as a function or part of expression
                prev_char = col_expr[-(len(last_token) + 1)] if len(col_expr) > len(last_token) else ' '
                if prev_char in (' ', '\t', '\n', ')'):
                    result.append(last_token.upper())
                    continue
        # Simple column reference: TABLE.COL or just COL
        simple = re.match(r'^(?:\w+\.)?(\w+)$', col_expr.strip())
        if simple:
            result.append(simple.group(1).upper())
            continue
        # Fallback: try to get last identifier
        last_id = re.findall(r'(\w+)', col_expr)
        if last_id:
            result.append(last_id[-1].upper())

    return result


def _resolve_databricks_type(sql_type: str, precision: str = '', scale: str = '') -> str:
    """Resolve a DataStage SQL type to its Databricks equivalent.

    Handles both named types ('VarChar') and numeric type codes ('12').
    Includes precision/scale for DECIMAL types.
    """
    # Try named type first
    db_type = TYPE_MAP.get(sql_type)
    if not db_type:
        # Try numeric code
        db_type = SQL_TYPE_CODE_MAP.get(sql_type, 'STRING')

    if db_type == 'DECIMAL' and precision:
        sc = scale if scale else '0'
        return f'DECIMAL({precision}, {sc})'
    return db_type


def _convert_if_then_else(expr: str) -> str:
    """Recursively convert DataStage IF/THEN/ELSE to SQL CASE WHEN.

    Handles:
      - Simple:   If cond Then a Else b  ->  CASE WHEN cond THEN a ELSE b END
      - Chained:  If c1 Then a Else If c2 Then b Else c  ->  CASE WHEN c1 THEN a WHEN c2 THEN b ELSE c END
      - Nested:   If c1 Then (If c2 Then a Else b) Else c  ->  CASE WHEN c1 THEN CASE WHEN c2 THEN a ELSE b END ELSE c END
    """
    if not re.search(r'\bIf\b', expr, re.IGNORECASE):
        return expr

    result = expr

    # Convert outermost IF/THEN/ELSE structure
    # Step 1: Convert 'Else If' to a placeholder to avoid double-processing
    result = re.sub(r'\bElse\s+If\b', 'ELSEIF', result, flags=re.IGNORECASE)

    # Step 2: Convert first 'If' to 'CASE WHEN'
    result = re.sub(r'\bIf\b\s+', 'CASE WHEN ', result, count=1, flags=re.IGNORECASE)

    # Step 3: Convert 'Then' to 'THEN'
    result = re.sub(r'\bThen\b', 'THEN', result, flags=re.IGNORECASE)

    # Step 4: Convert 'ELSEIF' to 'WHEN'
    result = re.sub(r'\bELSEIF\b\s+', 'WHEN ', result, flags=re.IGNORECASE)

    # Step 5: Convert remaining 'Else' to 'ELSE'
    result = re.sub(r'\bElse\b', 'ELSE', result, flags=re.IGNORECASE)

    # Step 6: Add END if CASE WHEN was added but END is missing
    # Count CASE vs END to handle nesting
    case_count = len(re.findall(r'\bCASE\b', result, re.IGNORECASE))
    end_count = len(re.findall(r'\bEND\b', result, re.IGNORECASE))
    for _ in range(case_count - end_count):
        result += ' END'

    return result


def _convert_bracket_substring(expr: str) -> str:
    """Convert DataStage bracket substring syntax to SQL SUBSTRING.

    DataStage: expr[start,length]
    SQL:       SUBSTRING(expr, start, length)
    """
    pattern = r'(\w+(?:\.\w+)?)\[(\d+),(\d+)\]'
    return re.sub(pattern, r'SUBSTRING(\1, \2, \3)', expr)


def _convert_oracle_plus_joins(sql: str) -> Tuple[str, List[Dict[str, str]]]:
    """Detect Oracle (+) outer join syntax in WHERE clauses and extract join info.

    Oracle:  WHERE A.COL = B.COL (+)
    ANSI:    LEFT OUTER JOIN B ON A.COL = B.COL

    Returns the modified SQL and a list of detected join conditions.
    """
    joins_found: List[Dict[str, str]] = []
    # Pattern: column = column (+) or column (+) = column
    oracle_join_pat = re.compile(
        r'(\w+\.\w+)\s*=\s*(\w+\.\w+)\s*\(\+\)',
        re.IGNORECASE
    )
    for match in oracle_join_pat.finditer(sql):
        left_col = match.group(1)
        right_col = match.group(2)
        # The table with (+) is the optional side
        right_table = right_col.split('.')[0]
        joins_found.append({
            'join_type': 'LEFT OUTER JOIN',
            'right_table': right_table,
            'condition': f'{left_col} = {right_col}',
        })

    # Remove (+) markers from SQL
    cleaned = re.sub(r'\s*\(\+\)', '', sql)
    return cleaned, joins_found


def _extract_func_arg(text: str, start: int) -> Tuple[str, int]:
    """Extract the first argument of a function call starting at the open paren.

    Returns (argument_text, end_position) where end_position is after the closing paren.
    Handles nested parentheses correctly.
    """
    depth = 0
    i = start
    arg_start = None
    first_comma_at_depth1 = None
    while i < len(text):
        ch = text[i]
        if ch == '(':
            depth += 1
            if depth == 1:
                arg_start = i + 1
        elif ch == ')':
            depth -= 1
            if depth == 0:
                if first_comma_at_depth1 is not None:
                    arg_text = text[arg_start:first_comma_at_depth1].strip()
                else:
                    arg_text = text[arg_start:i].strip()
                return arg_text, i + 1
        elif ch == ',' and depth == 1 and first_comma_at_depth1 is None:
            first_comma_at_depth1 = i
        i += 1
    # Fallback: couldn't find balanced parens
    return text[start:], len(text)


def _apply_template_func(text: str, ds_func: str, template: str) -> str:
    """Apply a template function mapping like IsNull -> '{0} IS NULL'.

    Finds each call to ds_func(...) in text, extracts the first argument,
    and replaces with the template filled in.
    """
    pattern = re.compile(rf'\b{re.escape(ds_func)}\s*\(', re.IGNORECASE)
    result = text
    # Process from right to left to preserve positions
    matches = list(pattern.finditer(result))
    for m in reversed(matches):
        func_start = m.start()
        paren_pos = m.end() - 1  # position of the '('
        arg, end_pos = _extract_func_arg(result, paren_pos)
        replacement = template.replace('{0}', arg)
        result = result[:func_start] + replacement + result[end_pos:]
    return result


def _convert_derivation(expr: str) -> str:
    """Convert a DataStage derivation expression to Databricks-compatible SQL.

    Applies all transformations in order:
      1. IF/THEN/ELSE -> CASE WHEN
      2. Bracket substring -> SUBSTRING()
      3. Function name mappings
      4. Parameter conversion (#param# -> {{ var() }})
      5. Input link prefix stripping
      6. Oracle (+) removal
    """
    if not expr:
        return expr

    result = expr

    # 1. IF/THEN/ELSE conversion
    result = _convert_if_then_else(result)

    # 2. Bracket substring syntax
    result = _convert_bracket_substring(result)

    # 3. Function mappings
    for ds_func, db_func in FUNCTION_MAP.items():
        pattern = re.compile(rf'\b{re.escape(ds_func)}\s*\(', re.IGNORECASE)
        if not pattern.search(result):
            continue

        if '{0}' in db_func:
            # Template pattern: extract first arg and substitute into template
            # e.g. IsNull(expr) -> expr IS NULL, CAST({0} AS DECIMAL)(expr) -> CAST(expr AS DECIMAL)
            result = _apply_template_func(result, ds_func, db_func)
        elif db_func in ('NULL',):
            # Constant replacement: SetNull() -> NULL
            result = re.sub(rf'\b{re.escape(ds_func)}\s*\(\s*\)', db_func, result, flags=re.IGNORECASE)
        elif db_func.endswith('()'):
            # Zero-arg function: CurrentTimestamp() -> CURRENT_TIMESTAMP()
            result = re.sub(rf'\b{re.escape(ds_func)}\s*\(\s*\)', db_func, result, flags=re.IGNORECASE)
        else:
            # Simple name swap: NullToValue( -> COALESCE(
            result = pattern.sub(f'{db_func}(', result)

    # 4. Parameter conversion: #paramName# -> {{ var('param_name') }}
    result = re.sub(
        r'#([^#]+)#',
        lambda m: "{{ var('" + _to_snake(m.group(1)) + "') }}",
        result
    )

    # 5. Strip DataStage input link prefixes (e.g., DSLink2.COL, toTrfParty.COL)
    # Matches: *Link*, toTrf*, DSLink*, lnk*, Lnk* followed by .COLUMN
    result = re.sub(r'\b(?:\w*Link\w*|toTrf\w*|lnk\w*|Lnk\w*|DSLink\w*)\.', '', result)

    # 6. Remove Oracle (+) markers if still present
    result = re.sub(r'\s*\(\+\)', '', result)

    return result


def _extract_unmapped_functions(expr: str) -> List[str]:
    """Find DataStage function calls that have no mapping in FUNCTION_MAP.

    Returns list of unmapped function names for TODO annotation.
    """
    # Find all function-call patterns: FunctionName(
    all_funcs = set(re.findall(r'\b([A-Za-z_]\w+)\s*\(', expr))

    # Known SQL functions that don't need mapping
    sql_builtins = {
        'SELECT', 'FROM', 'WHERE', 'AND', 'OR', 'NOT', 'IN', 'EXISTS',
        'CASE', 'WHEN', 'THEN', 'ELSE', 'END', 'AS', 'ON', 'JOIN',
        'COALESCE', 'CAST', 'TRIM', 'UPPER', 'LOWER', 'LENGTH',
        'SUBSTRING', 'LEFT', 'RIGHT', 'CONCAT', 'REPLACE',
        'TO_DATE', 'DATE_FORMAT', 'TO_TIMESTAMP', 'YEAR', 'MONTH', 'DAY',
        'SUM', 'COUNT', 'AVG', 'MIN', 'MAX', 'ROW_NUMBER', 'RANK',
        'FIRST_VALUE', 'LAST_VALUE', 'LEAD', 'LAG', 'OVER', 'PARTITION',
        'DISTINCT', 'UNION', 'ALL', 'GROUP', 'ORDER', 'BY', 'HAVING',
        'LPAD', 'RPAD', 'LOCATE', 'SPLIT_PART', 'MAKE_DATE',
        'CURRENT_DATE', 'CURRENT_TIMESTAMP', 'TRUNC',
        'NVL', 'DECODE', 'INSTR', 'SUBSTR',  # Oracle builtins handled
    }

    known_funcs = set(k.upper() for k in FUNCTION_MAP.keys()) | sql_builtins
    unmapped = [f for f in all_funcs if f.upper() not in known_funcs]
    return unmapped


# =============================================================================
# DataStage XML Parser
# =============================================================================

class DataStageParser(BaseParser):
    """Parse DataStage XML job exports into structured metadata.

    Navigates the DSExport > Job > Record hierarchy, extracting:
      - Job parameters from JobDefn records
      - Stage names and types from ContainerView records
      - Source SQL from CustomStage records (XMLProperties or Value properties)
      - Transformer derivations from TrxOutput records
      - Stage variables from TransformerStage and StageVar records
      - Target table and column definitions from CustomInput records
      - Source tables from SQL FROM/JOIN clauses and XML Table/TableName elements
      - Join conditions from PxJoin/PxLookup stage properties
      - Load type inference from transformation metadata
    """

    def discover_files(self) -> List[Path]:
        """Find all XML files in the inputs/ directory."""
        return sorted(self.input_dir.glob('*.xml'))

    def parse_file(self, file_path: Path) -> Dict[str, Any]:
        """Parse a single DataStage XML file into structured metadata."""
        tree = ET.parse(file_path)
        root = tree.getroot()
        job = root.find('.//Job')
        job_name = (
            job.get('Identifier', file_path.stem)
            if job is not None
            else file_path.stem
        )

        records = job.findall('Record') if job is not None else []

        result: Dict[str, Any] = {
            'job_name': job_name,
            'source_tables': [],
            'target_table': {},
            'target_columns': [],
            'stages': [],
            'transformations': [],
            'stage_variables': [],
            'joins': [],
            'filters': [],
            'parameters': {},
            'load_type': 'full_load',
            'source_sql_statements': [],
        }

        # Dispatch each record to the appropriate handler
        handlers = {
            'JobDefn': self._extract_parameters,
            'ContainerView': self._extract_stages,
            'CustomStage': self._extract_custom_stage,
            'TransformerStage': self._extract_transformer,
            'TrxOutput': self._extract_trx_output,
            'StageVar': self._extract_stage_var,
        }

        # Build record index for cross-referencing (e.g., join key extraction)
        record_index: Dict[str, ET.Element] = {}
        for rec in records:
            rid = rec.get('Identifier', '')
            if rid:
                record_index[rid] = rec

        for rec in records:
            rtype = rec.get('Type', '')
            if rtype in handlers:
                handlers[rtype](rec, result)
            elif rtype in ('CustomInput', 'CustomOutput'):
                self._extract_custom_io(rec, result, rtype)

        # Post-processing
        self._enrich_join_keys(result, record_index)
        self._extract_oracle_joins(result)
        self._detect_load_type(result)

        self.logger.info(
            f"  Parsed {job_name}: {len(result['source_tables'])} sources, "
            f"{len(result['transformations'])} derivations, "
            f"{len(result['stage_variables'])} stage vars, "
            f"load_type={result['load_type']}"
        )
        return result

    # ---- Property access helpers ----

    def _prop(self, record: ET.Element, name: str) -> str:
        """Get a named property value from a Record element."""
        for p in record.iter('Property'):
            if p.get('Name') == name:
                return (p.text or '').strip()
        return ''

    def _all_props(self, record: ET.Element, name: str) -> List[str]:
        """Get all values for a named property (some properties repeat)."""
        values = []
        for p in record.iter('Property'):
            if p.get('Name') == name:
                val = (p.text or '').strip()
                if val:
                    values.append(val)
        return values

    # ---- Record-type extraction methods ----

    def _extract_parameters(self, rec: ET.Element, result: Dict) -> None:
        """Extract job parameters from JobDefn record.

        Parameters are in Collection[Name='Parameters'] > SubRecord elements,
        each with Name, Type, Default, and HelpText properties.
        """
        for coll in rec.findall('.//Collection'):
            if coll.get('Name') == 'Parameters':
                for sub in coll.findall('SubRecord'):
                    pname = self._prop(sub, 'Name')
                    if pname:
                        result['parameters'][pname] = self._prop(sub, 'Default')

    def _extract_stages(self, rec: ET.Element, result: Dict) -> None:
        """Extract stage names and types from ContainerView record.

        StageList and StageTypes are pipe-delimited and positionally aligned.
        """
        names_str = self._prop(rec, 'StageList')
        types_str = self._prop(rec, 'StageTypes')
        if names_str and types_str:
            names = names_str.split('|')
            types = types_str.split('|')
            for i, name in enumerate(names):
                stage_type = types[i].strip() if i < len(types) else 'Unknown'
                result['stages'].append({
                    'name': name.strip(),
                    'type': stage_type,
                })

    def _parse_inner_xml(self, text: str) -> Optional[ET.Element]:
        """Parse inner XML from XMLProperties (entity-encoded) or Value (raw) properties.

        Handles both:
          - Raw XML starting with <?xml or <Properties
          - Double-encoded XML where entities must be unescaped twice
        """
        if not text:
            return None
        try:
            t = text.strip()
            # Try raw XML first
            if t.startswith('<?xml') or t.startswith('<Properties') or t.startswith('<'):
                return ET.fromstring(t)
            # Try double-entity decoding
            decoded = html.unescape(html.unescape(t)).strip()
            if decoded.startswith('<'):
                return ET.fromstring(decoded)
            return None
        except ET.ParseError:
            return None

    def _extract_custom_stage(self, rec: ET.Element, result: Dict) -> None:
        """Extract SQL, source tables, target table, and join info from CustomStage records.

        CustomStage records include source connectors (OracleConnectorPX), join stages
        (PxJoin, PxLookup), and target connectors. The inner XML containing SQL is stored
        in either an XMLProperties property (entity-encoded) or a Value property (raw XML).
        """
        stage_name = self._prop(rec, 'Name') or rec.get('Identifier', '')
        stage_type = self._prop(rec, 'StageType')

        # Find the inner XML from XMLProperties or Value property
        inner = None
        for p in rec.iter('Property'):
            pn = p.get('Name', '')
            pt = (p.text or '').strip()
            if pn == 'XMLProperties' and pt:
                inner = self._parse_inner_xml(pt)
                if inner is not None:
                    break
            elif pn == 'Value' and pt.startswith('<?xml'):
                inner = self._parse_inner_xml(pt)
                if inner is not None:
                    break

        if inner is None:
            # Even without XML, we can extract join info from stage properties
            if stage_type in ('PxJoin', 'PxLookup'):
                self._extract_join_stage(rec, result, stage_name, stage_type)
            return

        # Determine if this is a source or target connector using Context element
        context = ''
        for ctx_el in inner.iter('Context'):
            context = (ctx_el.text or '').strip()
            break

        # Extract SQL from SelectStatement elements
        for sel in inner.iter('SelectStatement'):
            sql_text = html.unescape((sel.text or '').strip())
            if sql_text:
                result['source_sql_statements'].append({
                    'stage_name': stage_name,
                    'sql_text': sql_text,
                    'context': context,
                })
                self._extract_tables_from_sql(sql_text, result)
                self._extract_filters_from_sql(sql_text, result)

        # Extract table references from XML <Table> and <TableName> elements
        for tbl_el in inner.iter('Table'):
            tbl_text = (tbl_el.text or '').strip()
            if tbl_text and '.' in tbl_text:
                schema, table = tbl_text.rsplit('.', 1)
                self._add_source_table(result, schema, table, stage_name)

        for tbl_el in inner.iter('TableName'):
            tbl_text = (tbl_el.text or '').strip()
            if tbl_text and '.' in tbl_text:
                schema, table = tbl_text.rsplit('.', 1)
                # Context=2 means target connector
                if context == '2':
                    result['target_table'] = {
                        'schema': schema,
                        'table_name': table,
                    }
                else:
                    self._add_source_table(result, schema, table, stage_name)

        # Extract join info from PxJoin/PxLookup stages
        if stage_type in ('PxJoin', 'PxLookup'):
            self._extract_join_stage(rec, result, stage_name, stage_type)

    def _extract_join_stage(self, rec: ET.Element, result: Dict,
                            stage_name: str, stage_type: str) -> None:
        """Extract join type and key columns from PxJoin/PxLookup stage properties."""
        join_type = 'INNER JOIN'
        if stage_type == 'PxLookup':
            join_type = 'LEFT JOIN'
        else:
            operator = self._prop(rec, 'operator')
            if 'leftouterjoin' in operator.lower():
                join_type = 'LEFT OUTER JOIN'
            elif 'fullouterjoin' in operator.lower():
                join_type = 'FULL OUTER JOIN'

        # Get key expression
        key_expr = self._prop(rec, 'key')

        # Get connected link names from InputPins
        input_pins = self._prop(rec, 'InputPins')
        links = input_pins.split('|') if input_pins else []

        result['joins'].append({
            'stage_name': stage_name,
            'stage_type': stage_type,
            'join_type': join_type,
            'key_expression': key_expr,
            'input_links': [l.strip() for l in links],
        })

    def _enrich_join_keys(self, result: Dict,
                          record_index: Dict[str, ET.Element]) -> None:
        """Post-processing: extract key columns and reference source for each join stage.

        For PxLookup: reads output pin columns with KeyPosition > 0.
        For PxJoin: decodes the encoded key property.
        Also identifies the reference input's source connector name.
        """
        for join_info in result['joins']:
            stage_name = join_info['stage_name']
            stage_type = join_info['stage_type']
            key_columns: List[str] = []

            # Find the stage record by matching Name property
            stage_rec = None
            for rid, rec in record_index.items():
                if self._prop(rec, 'Name') == stage_name:
                    if rec.get('Type') == 'CustomStage':
                        stage_rec = rec
                        break

            if not stage_rec:
                continue

            if stage_type == 'PxJoin':
                # Extract key from CustomProperty SubRecords:
                # <Collection Name="Properties"><SubRecord>
                #   <Property Name="Name">key</Property>
                #   <Property Name="Value">\(2)...\(3)key\(2)COL_NAME\(2)0...</Property>
                # </SubRecord></Collection>
                raw_key = ''
                for coll in stage_rec.findall('.//Collection'):
                    if coll.get('Name') == 'Properties':
                        for sub in coll.findall('SubRecord'):
                            if self._prop(sub, 'Name') == 'key':
                                raw_key = self._prop(sub, 'Value')
                                break
                if raw_key:
                    key_columns = re.findall(r'key\\?\(2\)(\w+)', raw_key)
                    if not key_columns:
                        key_columns = re.findall(r'key\(2\)(\w+)', raw_key)

            elif stage_type == 'PxLookup':
                # Find output pin record and extract columns with KeyPosition > 0
                output_pins_str = self._prop(stage_rec, 'OutputPins')
                if output_pins_str:
                    for pin_id in output_pins_str.split('|'):
                        pin_id = pin_id.strip()
                        pin_rec = record_index.get(pin_id)
                        if pin_rec is None:
                            continue
                        for coll in pin_rec.findall('.//Collection'):
                            coll_type = coll.get('Type', '')
                            if coll_type in ('OutputColumn', 'Column'):
                                for sub in coll.findall('SubRecord'):
                                    kp = self._prop(sub, 'KeyPosition')
                                    if kp and kp != '0':
                                        col_name = self._prop(sub, 'Name')
                                        if col_name and col_name not in key_columns:
                                            key_columns.append(col_name)

            join_info['key_columns'] = key_columns

            # Identify the reference input's source connector stage name
            # For PxLookup: reference input has LinkType=2
            # Trace Partner link back to the source stage to get its actual name
            ref_source = ''
            ref_stage_name = ''
            input_pins_str = self._prop(stage_rec, 'InputPins')
            if input_pins_str:
                for pin_id in input_pins_str.split('|'):
                    pin_id = pin_id.strip()
                    pin_rec = record_index.get(pin_id)
                    if pin_rec is None:
                        continue
                    link_type = self._prop(pin_rec, 'LinkType')
                    pin_name = self._prop(pin_rec, 'Name')
                    is_ref = (stage_type == 'PxLookup' and link_type == '2')
                    is_join_peer = (stage_type == 'PxJoin')
                    if is_ref or is_join_peer:
                        ref_source = pin_name
                        # Trace Partner to find the source stage name
                        partner = self._prop(pin_rec, 'Partner')
                        if partner:
                            # Partner format: "V25S0|V25S0P1" - first part is stage ID
                            partner_stage_id = partner.split('|')[0].strip()
                            partner_rec = record_index.get(partner_stage_id)
                            if partner_rec:
                                ref_stage_name = self._prop(partner_rec, 'Name')
                        if is_ref:
                            break

            join_info['reference_input'] = ref_source
            join_info['reference_stage_name'] = ref_stage_name

    def _extract_tables_from_sql(self, sql: str, result: Dict) -> None:
        """Extract source table references from all FROM and JOIN clauses in SQL.

        Scans the entire SQL text including subqueries. Finds qualified
        SCHEMA.TABLE references (schema 2+ chars to skip alias.column).
        Handles Oracle-style comma joins with aliases.
        """
        # Find all FROM blocks and extract qualified table names
        for m in re.finditer(r'\bFROM\b', sql, re.IGNORECASE):
            remaining = sql[m.end():]
            end = re.search(
                r'\b(?:WHERE|GROUP\s+BY|ORDER\s+BY|HAVING|UNION|'
                r'(?:INNER|LEFT|RIGHT|FULL|CROSS)\s+(?:OUTER\s+)?JOIN)\b',
                remaining, re.IGNORECASE
            )
            block = remaining[:end.start()] if end else remaining[:500]
            self._extract_qualified_tables(block, result, 'sql_from')

        # Find tables after explicit JOIN keywords (first qualified ref only)
        for m in re.finditer(r'\bJOIN\s+', sql, re.IGNORECASE):
            join_text = sql[m.end():m.end() + 100]
            # Stop at ON/WHERE/USING to avoid matching ON-clause column refs
            on_match = re.search(r'\b(?:ON|WHERE|USING)\b', join_text, re.IGNORECASE)
            if on_match:
                join_text = join_text[:on_match.start()]
            self._extract_qualified_tables(join_text, result, 'sql_join')

    def _extract_qualified_tables(self, text: str, result: Dict,
                                   source: str) -> None:
        """Find SCHEMA.TABLE patterns in a SQL text fragment.

        Only matches qualified references where the schema part contains
        a digit or special char (e.g., ESDA01OD, #Conn.$SCHEMA#) to
        distinguish real schemas from CTE/alias references.
        """
        skip = {'GROUP', 'ORDER', 'PARTITION', 'SELECT', 'INSERT',
                'UPDATE', 'DELETE', 'HAVING', 'UNION', 'WHERE'}
        for m in re.finditer(r'\b([A-Za-z_#$][\w#$]+)\.([A-Za-z_]\w*)\b', text):
            schema, table = m.group(1), m.group(2)
            if len(schema) < 2 or schema.upper() in skip:
                continue
            # Require schema to contain a digit, #, or $ to distinguish
            # real schemas (ESDA01OD, #Conn.$SCHEMA#) from CTE names
            if not re.search(r'[\d#$]', schema):
                continue
            self._add_source_table(result, schema, table, source)

    @staticmethod
    def _normalize_schema(schema: str) -> str:
        """Normalize DataStage schema references.

        Handles multiple forms:
          '#TargetDWConnectionString.$TARGET_DW_DB_SCHEMA#' -> '$TARGET_DW_DB_SCHEMA'
          'TARGET_DW_DB_SCHEMA#' -> '$TARGET_DW_DB_SCHEMA'
          '$TARGET_DW_DB_SCHEMA' -> '$TARGET_DW_DB_SCHEMA'
        """
        # Extract $VARIABLE portion if present
        m = re.search(r'(\$[A-Za-z_]\w+)', schema)
        if m:
            return m.group(1)
        # Strip trailing # and add $ prefix for bare schema variable names
        stripped = schema.rstrip('#')
        if stripped and re.match(r'^[A-Z_]+$', stripped, re.IGNORECASE):
            return '$' + stripped
        return schema

    def _add_source_table(self, result: Dict, schema: str, table: str,
                          source: str) -> None:
        """Add a source table entry if not already present (deduplication by name)."""
        schema = self._normalize_schema(schema)
        for existing in result['source_tables']:
            if (existing['table_name'].upper() == table.upper()
                    and existing['schema'].upper() == schema.upper()):
                return
        result['source_tables'].append({
            'schema': schema,
            'table_name': table,
            'source': source,
        })

    def _extract_filters_from_sql(self, sql: str, result: Dict) -> None:
        """Extract WHERE and HAVING conditions from SQL."""
        # WHERE clauses
        where_matches = re.findall(
            r'\bWHERE\s+(.*?)(?:\bGROUP\b|\bORDER\b|\bHAVING\b|\bUNION\b|$)',
            sql, re.IGNORECASE | re.DOTALL
        )
        for condition in where_matches:
            cond = condition.strip().rstrip(')')
            if cond and len(cond) > 2:
                result['filters'].append(cond)

        # HAVING clauses
        having_matches = re.findall(
            r'\bHAVING\s+(.*?)(?:\bORDER\b|\bUNION\b|$)',
            sql, re.IGNORECASE | re.DOTALL
        )
        for condition in having_matches:
            cond = condition.strip().rstrip(')')
            if cond and len(cond) > 2:
                result['filters'].append(cond)

    def _extract_custom_io(self, rec: ET.Element, result: Dict,
                           rtype: str) -> None:
        """Extract column definitions from CustomInput/CustomOutput records.

        CustomInput columns represent target table columns.
        CustomOutput columns represent source table columns.
        """
        columns: List[Dict[str, str]] = []
        for coll in rec.findall('.//Collection'):
            coll_type = coll.get('Type', '')
            if coll_type in ('Column', 'OutputColumn', 'InputColumn'):
                for sub in coll.findall('SubRecord'):
                    col_name = self._prop(sub, 'Name')
                    if col_name:
                        sql_type = self._prop(sub, 'SqlType')
                        precision = self._prop(sub, 'Precision')
                        scale = self._prop(sub, 'Scale')
                        columns.append({
                            'name': col_name,
                            'sql_type': sql_type,
                            'precision': precision,
                            'scale': scale,
                            'nullable': self._prop(sub, 'Nullable'),
                            'databricks_type': _resolve_databricks_type(
                                sql_type, precision, scale
                            ),
                        })

        # CustomInput columns are the target write schema
        if rtype == 'CustomInput' and columns:
            # Only overwrite if we find a richer set of columns
            if not result['target_columns'] or len(columns) > len(result['target_columns']):
                result['target_columns'] = columns

    def _extract_transformer(self, rec: ET.Element, result: Dict) -> None:
        """Extract stage variables from TransformerStage records.

        Stage variables are intermediate computed values defined in
        Collection[Type='StageVar'] that get referenced by output derivations.
        """
        for coll in rec.findall('.//Collection'):
            if coll.get('Type') == 'StageVar':
                for sub in coll.findall('SubRecord'):
                    sv_name = self._prop(sub, 'Name')
                    if sv_name:
                        result['stage_variables'].append({
                            'name': sv_name,
                            'expression': self._prop(sub, 'Expression'),
                            'parsed_expression': self._prop(sub, 'ParsedExpression'),
                            'sql_type': self._prop(sub, 'SqlType'),
                        })

    def _extract_trx_output(self, rec: ET.Element, result: Dict) -> None:
        """Extract column derivations from TrxOutput records.

        Each output column has a Name, Derivation (original expression),
        and optionally ParsedDerivation (normalized form).
        """
        link_name = self._prop(rec, 'Name')
        for coll in rec.findall('.//Collection'):
            coll_type = coll.get('Type', '')
            if coll_type in ('OutputColumn', 'Column'):
                for sub in coll.findall('SubRecord'):
                    col_name = self._prop(sub, 'Name')
                    derivation = self._prop(sub, 'Derivation')
                    if col_name and derivation:
                        result['transformations'].append({
                            'column_name': col_name,
                            'derivation': derivation,
                            'parsed_derivation': self._prop(sub, 'ParsedDerivation'),
                            'sql_type': self._prop(sub, 'SqlType'),
                            'precision': self._prop(sub, 'Precision'),
                            'scale': self._prop(sub, 'Scale'),
                            'output_link': link_name,
                        })

    def _extract_stage_var(self, rec: ET.Element, result: Dict) -> None:
        """Extract a standalone stage variable record."""
        sv_name = self._prop(rec, 'Name')
        if sv_name:
            sv = {
                'name': sv_name,
                'expression': self._prop(rec, 'Expression'),
                'parsed_expression': self._prop(rec, 'ParsedExpression'),
                'sql_type': self._prop(rec, 'SqlType'),
            }
            # Avoid duplicates
            existing_names = {s['name'] for s in result['stage_variables']}
            if sv_name not in existing_names:
                result['stage_variables'].append(sv)

    # ---- Post-processing methods ----

    def _extract_oracle_joins(self, result: Dict) -> None:
        """Scan all source SQL for Oracle (+) join syntax and add to joins list."""
        for sql_entry in result['source_sql_statements']:
            _, oracle_joins = _convert_oracle_plus_joins(sql_entry['sql_text'])
            for oj in oracle_joins:
                oj['stage_name'] = sql_entry['stage_name']
                result['joins'].append(oj)

    def _detect_load_type(self, result: Dict) -> None:
        """Determine load type from stage properties, filters, and transformation metadata.

        Checks for CDC, incremental, or full load indicators.
        Default is full_load if no evidence of incremental/CDC.
        """
        # Combine all text for pattern matching
        all_text = ' '.join(result.get('filters', []))
        all_text += ' ' + ' '.join(
            t.get('derivation', '') for t in result.get('transformations', [])
        )
        all_text += ' ' + ' '.join(
            sv.get('expression', '') for sv in result.get('stage_variables', [])
        )
        all_text += ' ' + ' '.join(p for p in result.get('parameters', {}).keys())

        if re.search(
            r'CDC|CHANGE_DATA_CAPTURE|before_image|after_image|SCD_TYPE',
            all_text, re.IGNORECASE
        ):
            result['load_type'] = 'cdc_load'
        elif re.search(
            r'INCREMENTAL|LAST_MODIFIED|UPDATED_AT|BATCH_KEY|WATERMARK',
            all_text, re.IGNORECASE
        ):
            result['load_type'] = 'incremental_load'
        # else: stays as 'full_load' (default)


# =============================================================================
# dbt Model Generator
# =============================================================================

class DbtModelGenerator(BaseGenerator):
    """Generate a complete dbt project from parsed DataStage XML metadata.

    Produces:
      - Staging models (one per source table, materialized='view', uses source())
      - Intermediate models (one per job, materialized='table', uses ref())
      - Marts models (one per job, no mart_ prefix, uses ref())
      - Per-layer schema files
      - Cumulative source.yml
      - dbt_project.yml with all vars
      - Reusable macros
      - Conversion plans in plans/
      - Visualization files in thoughts/
    """

    def __init__(self, parser: DataStageParser,
                 plans_dir: str = 'plans', output_dir: str = 'output'):
        super().__init__(plans_dir=plans_dir, output_dir=output_dir)
        self.parser = parser
        self.all_sources: List[Dict] = []
        self.all_vars: Dict[str, str] = {}
        # Build metrics tracking for quality threshold evaluation
        self._build_metrics: Dict[str, Any] = {
            'jobs_processed': 0,
            'staging_models_generated': 0,
            'intermediate_models_generated': 0,
            'marts_models_generated': 0,
            'total_source_tables': 0,
            'total_transformer_columns': 0,
            'functions_mapped': 0,
            'functions_todo_flagged': 0,
            'per_job_metrics': [],
        }
        self._generation_issues: List[Dict[str, str]] = []

    def generate(self) -> None:
        """Main generation entry point. Parses all XML and generates all artifacts."""
        parsed = self.parser.parse_all()
        if not parsed:
            self.logger.warning("No XML files found in inputs/. Nothing to generate.")
            return

        for job_key, job_data in parsed.items():
            self.logger.info(f"Generating dbt models for: {job_data['job_name']}")
            self._save_conversion_plan(job_data)
            self._generate_staging_models(job_data)
            self._generate_intermediate_model(job_data)
            self._generate_marts_model(job_data)
            self._collect_sources(job_data)
            self._collect_vars(job_data)
            self._collect_build_metrics(job_data)

        # Cross-job artifacts
        self._generate_source_yml()
        self._generate_schema_files(parsed)
        self._generate_dbt_project_yml()
        self._generate_macros()
        self._generate_visualizations(parsed)
        self._save_build_metrics(parsed)
        self._save_generation_issues()
        self.logger.info("dbt model generation complete.")

    # ---- Name helpers ----

    def _target_name(self, job: Dict) -> str:
        """Get the snake_case target table name for a job."""
        return _to_snake(job['target_table'].get('table_name', job['job_name']))

    def _staging_model_name(self, src: Dict) -> str:
        """Get the staging model name for a source table."""
        ts = _to_snake(src['table_name'])
        ss = _to_snake(src['schema'])
        return f"stg_{ss}_{ts}"

    # ---- Conversion Plan ----

    def _save_conversion_plan(self, job: Dict) -> None:
        """Save a detailed conversion plan markdown for the job."""
        name = job['job_name']

        # Source tables section
        src_lines = []
        for s in job['source_tables']:
            src_lines.append(f"  - `{s['schema']}.{s['table_name']}` (found via: {s['source']})")
        sources_text = '\n'.join(src_lines) or '  - (none discovered)'

        # Target table
        tgt_schema = job['target_table'].get('schema', 'unknown')
        tgt_table = job['target_table'].get('table_name', 'unknown')

        # Target columns with types
        col_lines = []
        for c in job['target_columns']:
            db_type = c.get('databricks_type', 'STRING')
            col_lines.append(f"  - `{c['name']}` : {db_type}")
        cols_text = '\n'.join(col_lines) or '  - (columns extracted at runtime)'

        # Joins
        join_lines = []
        for j in job['joins']:
            join_lines.append(
                f"  - {j.get('join_type', 'JOIN')} via `{j.get('stage_name', '?')}`"
                f" ({j.get('stage_type', '?')})"
            )
        joins_text = '\n'.join(join_lines) or '  - (no explicit join stages)'

        # Stage variables
        sv_lines = []
        for sv in job['stage_variables']:
            converted = _convert_derivation(sv['expression'])
            sv_lines.append(f"  - `{sv['name']}` = `{converted}`")
        sv_text = '\n'.join(sv_lines) or '  - (none)'

        # Parameters
        param_lines = []
        for pn, pv in job['parameters'].items():
            param_lines.append(f"  - `{pn}` -> `{{{{ var('{_to_snake(pn)}') }}}}` (default: {pv or 'N/A'})")
        params_text = '\n'.join(param_lines) or '  - (none)'

        # Proposed CTE structure
        cte_lines = ["  ```"]
        for src in job['source_tables']:
            cte_lines.append(f"  src_{_to_snake(src['table_name'])} AS (SELECT * FROM ref('stg_...'))")
        if job['stage_variables']:
            cte_lines.append("  -- Stage variables inlined as computed columns")
        cte_lines.append("  -- Transformation derivations applied in SELECT")
        cte_lines.append("  ```")
        cte_text = '\n'.join(cte_lines)

        plan = f"""# Conversion Plan: {name}

Generated: {get_timestamp()}

## Source Tables
{sources_text}

## Target Table
  - `{tgt_schema}.{tgt_table}`

## Target Columns
{cols_text}

## Load Type
  - **{job['load_type']}**

## Join Stages
{joins_text}

## Stage Variables
{sv_text}

## Parameters
{params_text}

## Transformations
  - {len(job['transformations'])} column derivations found
  - {len(job['source_sql_statements'])} source SQL statements extracted

## Proposed CTE Structure (Intermediate Model)
{cte_text}

## Generated Models
  - Staging: {len(job['source_tables'])} models (one per source table)
  - Intermediate: 1 model (`int_{_to_snake(tgt_table)}.sql`)
  - Marts: 1 model (`{_to_snake(tgt_table)}.sql`)
"""
        plan_path = get_project_root() / 'plans' / f"{name}_conversion_plan.md"
        plan_path.parent.mkdir(parents=True, exist_ok=True)
        plan_path.write_text(plan, encoding='utf-8')
        self.logger.info(f"  Conversion plan: {plan_path.name}")

    # ---- Staging Models ----

    def _generate_staging_models(self, job: Dict) -> None:
        """Generate one staging model per source table.

        Staging models:
          - Use {{ config(materialized='view') }}
          - Reference raw sources via {{ source('schema', 'table') }}
          - Contain minimal transformation (SELECT columns)
          - Include traceability comments
        """
        for src in job['source_tables']:
            model_name = self._staging_model_name(src)
            schema_snake = _to_snake(src['schema'])

            lines = [
                "{{ config(materialized='view') }}",
                f"-- Source: {src['source']} | Job: {job['job_name']}",
                f"-- Raw source table: {src['schema']}.{src['table_name']}",
                f"-- Materialization: view (per dbt-best-practices — staging layer)",
                f"-- Extraction method: {src['source']}",
                "",
                "WITH source_data AS (",
                "    SELECT",
                "        *",
                f"    FROM {{{{ source('{schema_snake}', '{src['table_name']}') }}}}",
                ")",
                "",
                "SELECT",
                "    *",
                "FROM source_data",
            ]

            sql = '\n'.join(lines) + '\n'
            self.save_output(sql, f"models/staging/{model_name}.sql")

    # ---- SQL Conversion Helpers ----

    def _convert_source_sql(self, sql: str, table_ref_map: Dict[str, str]) -> str:
        """Convert DataStage source SQL to dbt-compatible SQL.

        Replaces SCHEMA.TABLE references with staging CTE aliases,
        converts Oracle functions, removes (+) markers, converts parameters.
        """
        result = sql
        # Strip connection string prefixes from parameterized refs:
        # #ConnString.$SCHEMA#.TABLE -> $SCHEMA.TABLE
        result = re.sub(
            r'#\w+\.(\$\w+)#',
            r'\1',
            result
        )
        # Replace table references (longest first to avoid partial matches)
        for full_ref, alias in sorted(table_ref_map.items(), key=lambda x: -len(x[0])):
            result = re.sub(re.escape(full_ref), alias, result, flags=re.IGNORECASE)

        # Oracle function conversions
        result = re.sub(r'\bNVL\s*\(', 'COALESCE(', result, flags=re.IGNORECASE)
        result = re.sub(r'\bTO_CHAR\s*\(', 'DATE_FORMAT(', result, flags=re.IGNORECASE)

        # Oracle (+) outer join: remove marker, add comment
        if '(+)' in result:
            result = ('-- NOTE: Oracle (+) outer join syntax removed. '
                      'Verify LEFT JOIN semantics.\n' + result)
            result = re.sub(r'\s*\(\+\)', '', result)

        # Convert parameters: #paramName# -> {{ var('...') }}
        result = re.sub(
            r'#([^#]+)#',
            lambda m: "{{ var('" + _to_snake(m.group(1)) + "') }}",
            result
        )
        return result

    def _split_with_select(self, sql: str) -> Tuple[Optional[str], str]:
        """Split WITH...CTE SQL into (cte_definitions, final_select).

        Returns (None, sql) if no WITH clause found.
        Returns (cte_block, final_select) for WITH queries.
        Handles leading SQL comments (e.g. Oracle (+) removal notes).
        """
        stripped = sql.strip()

        # Separate leading comment lines from SQL body
        leading_comments: List[str] = []
        body_lines: List[str] = []
        in_comments = True
        for line in stripped.split('\n'):
            if in_comments and line.strip().startswith('--'):
                leading_comments.append(line)
            else:
                in_comments = False
                body_lines.append(line)
        body = '\n'.join(body_lines).strip()

        if not re.match(r'(?i)\s*WITH\b', body):
            return None, stripped

        # Find the last SELECT at parenthesis depth 0
        depth = 0
        last_select_pos = -1
        upper = body.upper()
        for i in range(len(body)):
            if body[i] == '(':
                depth += 1
            elif body[i] == ')':
                depth -= 1
            elif depth == 0 and upper[i:i + 6] == 'SELECT':
                # Check word boundaries
                before_ok = (i == 0 or not upper[i - 1:i].isalnum())
                after_ok = (i + 6 >= len(upper) or not upper[i + 6:i + 7].isalnum())
                if before_ok and after_ok:
                    last_select_pos = i

        if last_select_pos <= 0:
            return None, stripped

        cte_block = re.sub(
            r'(?i)^\s*WITH\s+', '', body[:last_select_pos]
        ).strip().rstrip(',').strip()

        # Prepend any leading comments to the CTE block
        if leading_comments:
            cte_block = '\n'.join(leading_comments) + '\n' + cte_block

        final_select = body[last_select_pos:].strip()
        return cte_block, final_select

    def _build_transformer_select(self, job: Dict) -> str:
        """Build final SELECT column list from transformer derivations.

        Handles:
          - DataStage system vars (DSJobStartDate -> CURRENT_TIMESTAMP())
          - Job parameter refs (jpCreatedNm -> {{ var('jp_created_nm') }})
          - Simple pass-throughs (linkName.COLUMN -> source_data.COLUMN)
          - Complex derivations (converted via _convert_derivation)

        When multiple transformer stages exist, deduplicates by column name
        keeping the last occurrence (the stage closest to the target).
        """
        # Deduplicate: last occurrence wins
        seen: Dict[str, Dict] = {}
        for t in job['transformations']:
            seen[t['column_name']] = t
        unique_transforms = list(seen.values())

        # Build stage variable resolution map: svName -> converted expression
        sv_map: Dict[str, str] = {}
        for sv in job.get('stage_variables', []):
            sv_map[sv['name']] = _convert_derivation(sv['expression'])

        cols: List[str] = []
        for t in unique_transforms:
            col_name = _to_snake(t['column_name'])
            deriv = t['derivation']

            # Resolve stage variable references in derivation
            for sv_name, sv_expr in sv_map.items():
                if sv_name in deriv:
                    deriv = deriv.replace(sv_name, f'({sv_expr})')

            if deriv == 'DSJobStartDate':
                cols.append(f"    CURRENT_TIMESTAMP() AS {col_name}")
            elif re.match(r'^jp\w+$', deriv, re.IGNORECASE):
                cols.append(
                    f"    {{{{ var('{_to_snake(deriv)}') }}}} AS {col_name}"
                )
            elif re.match(r'^[a-zA-Z]\w*\.[A-Za-z_]\w*$', deriv):
                # Simple pass-through: linkName.COLUMN -> source_data.COLUMN
                src_col = deriv.split('.', 1)[1]
                cols.append(f"    source_data.{src_col} AS {col_name}")
            else:
                converted = _convert_derivation(deriv)
                cols.append(f"    {converted} AS {col_name}")

        return ',\n'.join(cols) if cols else "    *"

    # ---- Intermediate Model ----

    def _generate_intermediate_model(self, job: Dict) -> None:
        """Generate intermediate model. Uses source SQL when available, else derivations.

        Two generation paths:
          1. SQL-based: When source connector has complex SQL (CTEs, JOINs, aggregations),
             embed the full converted SQL preserving all business logic.
          2. Derivation-based: When transformer has simple derivations, build from
             column-level expressions (fallback for simple jobs).
        """
        target_name = self._target_name(job)
        model_name = f"int_{target_name}"

        # Check for source SQL with complex logic
        source_sqls = [
            s for s in job['source_sql_statements']
            if s.get('context') in ('1', '')
        ]
        has_complex_sql = source_sqls and any(
            re.search(
                r'\b(WITH|JOIN|GROUP\s+BY|HAVING|SUM\s*\(|COUNT\s*\(|CASE\s+WHEN)\b',
                s['sql_text'], re.IGNORECASE
            )
            for s in source_sqls
        )
        # Multi-source jobs need the SQL path for join assembly even if
        # individual SQL statements are simple (e.g. SELECT with TRIM).
        has_multi_source = len(source_sqls) > 1

        if has_complex_sql or has_multi_source:
            self._gen_intermediate_from_sql(job, model_name, source_sqls)
        else:
            self._gen_intermediate_from_derivations(job, model_name)

    def _gen_intermediate_from_sql(self, job: Dict, model_name: str,
                                    source_sqls: List[Dict]) -> None:
        """Generate intermediate model by embedding converted source SQL(s).

        Handles both single-source and multi-source connector jobs:
          1. Creates staging CTEs referencing staging models
          2. Converts table references in each source SQL
          3. For multi-source: each source SQL becomes a named CTE
          4. Join stages are annotated with their join type
          5. Assembles everything with transformer derivations as the column list
        """
        # Build SCHEMA.TABLE -> cte_alias mapping
        table_ref_map: Dict[str, str] = {}
        for src in job['source_tables']:
            full_ref = f"{src['schema']}.{src['table_name']}"
            table_ref_map[full_ref] = _to_snake(src['table_name'])

        # Build staging reference CTEs
        staging_ctes: List[str] = []
        seen_aliases: set = set()
        for src in job['source_tables']:
            stg_model = self._staging_model_name(src)
            alias = _to_snake(src['table_name'])
            if alias in seen_aliases:
                continue
            seen_aliases.add(alias)
            staging_ctes.append(
                f"{alias} AS (\n"
                f"    SELECT * FROM {{{{ ref('{stg_model}') }}}}\n"
                f")"
            )

        all_ctes = staging_ctes[:]

        if len(source_sqls) == 1:
            # Single source SQL: embed directly as source_data CTE
            stage_name = source_sqls[0]['stage_name']
            converted_sql = self._convert_source_sql(source_sqls[0]['sql_text'], table_ref_map)
            cte_defs, final_select = self._split_with_select(converted_sql)
            if cte_defs:
                all_ctes.append(cte_defs)
            indented = '\n'.join(
                '    ' + line if line.strip() else line
                for line in final_select.split('\n')
            )
            all_ctes.append(
                f"-- Source connector: {stage_name}\n"
                f"source_data AS (\n{indented}\n)"
            )
        else:
            # Multi-source: each source SQL becomes a named CTE
            source_cte_names: List[str] = []
            for sql_entry in source_sqls:
                stage_name = sql_entry['stage_name']
                cte_name = _to_snake(re.sub(r'^Orcl', '', stage_name))
                # Avoid collision with staging CTEs
                if cte_name in seen_aliases:
                    cte_name = f"src_{cte_name}"
                source_cte_names.append(cte_name)

                converted_sql = self._convert_source_sql(sql_entry['sql_text'], table_ref_map)
                cte_defs, final_select = self._split_with_select(converted_sql)
                if cte_defs:
                    all_ctes.append(cte_defs)

                indented = '\n'.join(
                    '    ' + line if line.strip() else line
                    for line in final_select.split('\n')
                )
                all_ctes.append(
                    f"-- Source connector: {stage_name}\n"
                    f"{cte_name} AS (\n{indented}\n)"
                )

            # Build source_data by joining source CTEs using parsed join metadata
            primary = source_cte_names[0]
            join_lines = [f"    SELECT {primary}.*"]
            # Add columns from lookup CTEs
            for cte_name in source_cte_names[1:]:
                join_lines.append(f"        , {cte_name}.*")
            join_lines.append(f"    FROM {primary}")

            # Build mapping: source connector stage name -> CTE name
            stage_to_cte: Dict[str, str] = {}
            for sql_entry, cte_name in zip(source_sqls, source_cte_names):
                stage_to_cte[sql_entry['stage_name']] = cte_name

            # Build mapping: CTE name -> projected column names (uppercase)
            # Used to validate that join keys actually exist in the CTE
            cte_columns: Dict[str, List[str]] = {}
            for sql_entry, cte_name in zip(source_sqls, source_cte_names):
                cte_columns[cte_name] = _extract_select_columns(
                    sql_entry['sql_text']
                )

            # Build mapping: source stage name -> join info
            # Uses reference_stage_name (traced via Partner link) for reliable matching
            stage_name_to_join: Dict[str, Dict] = {}
            for j in job.get('joins', []):
                ref_stage = j.get('reference_stage_name', '')
                if ref_stage:
                    stage_name_to_join[ref_stage] = j
                # Also index by cleaned reference_input as fallback
                ref_input = j.get('reference_input', '')
                if ref_input:
                    ref_clean = re.sub(r'^from', '', ref_input, flags=re.IGNORECASE)
                    stage_name_to_join[ref_clean] = j

            for cte_name in source_cte_names[1:]:
                join_type = 'LEFT JOIN'
                key_columns: List[str] = []

                # Find matching join stage for this CTE's source connector
                matched_join = None
                matched_sql_entry = None
                for sql_entry, cn in zip(source_sqls, source_cte_names):
                    if cn != cte_name:
                        continue
                    matched_sql_entry = sql_entry
                    stage = sql_entry['stage_name']
                    # Try exact match on reference_stage_name first
                    if stage in stage_name_to_join:
                        matched_join = stage_name_to_join[stage]
                    break

                if matched_join:
                    join_type = matched_join['join_type']
                    key_columns = matched_join.get('key_columns', [])

                # Filter key columns: only keep keys that exist in the
                # reference CTE's projection. PxLookup key_columns come
                # from the output pin (streaming input schema), not from
                # the lookup source SQL — so many may not exist in the CTE.
                if key_columns:
                    ref_cols = cte_columns.get(cte_name, [])
                    if ref_cols:
                        ref_col_set = set(ref_cols)
                        valid_keys: List[Tuple[str, str]] = []
                        for col in key_columns:
                            col_up = col.upper()
                            if col_up in ref_col_set:
                                # Exact match
                                valid_keys.append((col, col))
                            else:
                                # Fuzzy: CTE may alias the column
                                # e.g., key=CL_ID_NK, CTE has CL_ID
                                # or key=CNT_ID_NK, CTE has CNT_ID
                                for rc in ref_cols:
                                    # CTE col is prefix of key (CL_ID matches CL_ID_NK)
                                    if col_up.startswith(rc) or rc.startswith(col_up):
                                        valid_keys.append((col, rc))
                                        break
                        if valid_keys:
                            key_columns_pairs = valid_keys
                        else:
                            key_columns_pairs = None
                    else:
                        key_columns_pairs = None
                else:
                    key_columns_pairs = None

                if key_columns_pairs:
                    on_clause = ' AND '.join(
                        f"{primary}.{pk} = {cte_name}.{rk}"
                        for pk, rk in key_columns_pairs
                    )
                    join_lines.append(
                        f"    {join_type} {cte_name}\n"
                        f"        ON {on_clause}"
                    )
                elif key_columns:
                    # Fallback: use all keys as-is (no CTE column info)
                    on_clause = ' AND '.join(
                        f"{primary}.{col} = {cte_name}.{col}"
                        for col in key_columns
                    )
                    join_lines.append(
                        f"    {join_type} {cte_name}\n"
                        f"        ON {on_clause}"
                    )
                else:
                    join_lines.append(
                        f"    {join_type} {cte_name}\n"
                        f"        -- TODO: Verify join keys from DataStage link metadata\n"
                        f"        ON 1=1"
                    )

            source_data_sql = '\n'.join(join_lines)
            all_ctes.append(f"source_data AS (\n{source_data_sql}\n)")

        cte_block = ',\n\n'.join(all_ctes)
        select_block = self._build_transformer_select(job)

        lines = [
            "{{ config(materialized='table') }}",
            f"-- Intermediate model for {job['job_name']}",
            "-- Source SQL from DataStage source connector, converted to dbt",
            "",
            f"WITH {cte_block}",
            "",
            "SELECT",
            select_block,
            "FROM source_data",
        ]

        self.save_output('\n'.join(lines) + '\n', f"models/intermediate/{model_name}.sql")

    def _gen_intermediate_from_derivations(self, job: Dict,
                                            model_name: str) -> None:
        """Generate intermediate model from transformer derivation expressions.

        Fallback path for jobs without complex source SQL. Uses column-level
        derivation expressions from the transformer stage.
        """
        target_name = self._target_name(job)

        # Build source CTEs
        cte_parts: List[str] = []
        ref_aliases: List[Tuple[str, str]] = []
        for src in job['source_tables']:
            ref_name = self._staging_model_name(src)
            alias = f"src_{_to_snake(src['table_name'])}"
            ref_aliases.append((ref_name, alias))
            cte_parts.append(
                f"-- Source: {src['schema']}.{src['table_name']}\n"
                f"{alias} AS (\n"
                f"    SELECT * FROM {{{{ ref('{ref_name}') }}}}\n"
                f")"
            )

        # Stage variable annotations
        if job['stage_variables']:
            sv_lines = ["-- Stage Variables (inlined into derivation expressions)"]
            for sv in job['stage_variables']:
                sv_lines.append(f"-- {sv['name']} = {_convert_derivation(sv['expression'])}")
            cte_parts.append('\n'.join(sv_lines))

        # Build SELECT from derivations
        select_columns: List[str] = []
        for t in job['transformations']:
            col_name = _to_snake(t['column_name'])
            deriv = t['derivation']

            if deriv == 'DSJobStartDate':
                select_columns.append(f"    CURRENT_TIMESTAMP() AS {col_name}")
            elif re.match(r'^jp\w+$', deriv, re.IGNORECASE):
                select_columns.append(
                    f"    {{{{ var('{_to_snake(deriv)}') }}}} AS {col_name}"
                )
            else:
                converted = _convert_derivation(deriv)
                if converted.strip().upper() == col_name.upper():
                    select_columns.append(f"    {col_name}")
                else:
                    select_columns.append(f"    {converted} AS {col_name}")

        if not select_columns:
            select_columns = ["    *"]

        cte_block = (
            ',\n\n'.join(cte_parts) if cte_parts
            else f"source AS (\n    SELECT * FROM {{{{ ref('stg_{target_name}') }}}}\n)"
        )
        from_alias = ref_aliases[0][1] if ref_aliases else 'source'

        lines = [
            "{{ config(materialized='table') }}",
            f"-- Intermediate model for {job['job_name']}",
            "-- Contains all transformation logic: joins, CASE statements, derivations",
            "",
            f"WITH {cte_block}",
            "",
            "SELECT",
            ',\n'.join(select_columns),
            f"FROM {from_alias}",
        ]

        self.save_output('\n'.join(lines) + '\n', f"models/intermediate/{model_name}.sql")

    # ---- Marts Model ----

    def _generate_marts_model(self, job: Dict) -> None:
        """Generate one marts model per job with final column projection.

        Marts models:
          - File name is target_name.sql (NO mart_ prefix)
          - Folder is models/marts/ (plural)
          - Use {{ ref('int_...') }} to reference intermediate
          - Materialized as 'table' (full) or 'incremental' (incremental/CDC)
          - Include audit columns (etl_load_timestamp, etl_source_job)
        """
        target_name = self._target_name(job)
        int_ref = f"int_{target_name}"
        load_type = job['load_type']

        # Config block based on load type
        if load_type == 'incremental_load':
            config_block = (
                "{{ config(\n"
                "    materialized='incremental',\n"
                "    unique_key='id'\n"
                ") }}"
            )
        elif load_type == 'cdc_load':
            config_block = (
                "{{ config(\n"
                "    materialized='incremental',\n"
                "    unique_key='id',\n"
                "    incremental_strategy='merge'\n"
                ") }}"
            )
        else:
            config_block = "{{ config(materialized='table') }}"

        # Target columns with proper snake_case
        column_lines: List[str] = []
        for c in job['target_columns']:
            col_snake = _to_snake(c['name'])
            column_lines.append(f"    {col_snake}")

        if not column_lines:
            column_lines = ["    *"]

        column_block = ',\n'.join(column_lines)

        # Incremental filter
        incremental_block = ""
        if load_type in ('incremental_load', 'cdc_load'):
            incremental_block = (
                "\n{% if is_incremental() %}\n"
                "WHERE etl_load_timestamp > (\n"
                "    SELECT MAX(etl_load_timestamp) FROM {{ this }}\n"
                ")\n"
                "{% endif %}"
            )

        lines = [
            config_block,
            f"-- Marts model for {job['job_name']}",
            f"-- Source: {job['target_table'].get('schema', '?')}.{job['target_table'].get('table_name', '?')}",
            "",
            "WITH intermediate_data AS (",
            "    SELECT",
            "        *",
            f"    FROM {{{{ ref('{int_ref}') }}}}",
            ")",
            "",
            "SELECT",
            f"{column_block},",
            "    CURRENT_TIMESTAMP() AS etl_load_timestamp,",
            f"    '{job['job_name']}' AS etl_source_job",
            f"FROM intermediate_data{incremental_block}",
        ]

        sql = '\n'.join(lines) + '\n'
        self.save_output(sql, f"models/marts/{target_name}.sql")

    # ---- Cross-job collection ----

    def _collect_sources(self, job: Dict) -> None:
        """Collect source tables across all jobs for cumulative source.yml."""
        for src in job['source_tables']:
            already_exists = any(
                e['schema'].upper() == src['schema'].upper()
                and e['table_name'].upper() == src['table_name'].upper()
                for e in self.all_sources
            )
            if not already_exists:
                self.all_sources.append(src)

    def _collect_vars(self, job: Dict) -> None:
        """Collect job parameters for dbt_project.yml vars section."""
        for param_name, param_default in job['parameters'].items():
            var_name = _to_snake(param_name)
            if var_name not in self.all_vars:
                self.all_vars[var_name] = param_default or ''

    # ---- source.yml ----

    def _generate_source_yml(self) -> None:
        """Generate cumulative source.yml with all discovered sources.

        Groups tables by schema. Each source entry includes database via var().
        """
        sources_by_schema: Dict[str, List[str]] = {}
        for src in self.all_sources:
            schema_key = _to_snake(src['schema'])
            sources_by_schema.setdefault(schema_key, []).append(src['table_name'])

        source_entries = []
        for schema_key, tables in sources_by_schema.items():
            unique_tables = sorted(set(tables))
            source_entries.append({
                'name': schema_key,
                'database': "{{ var('source_database') }}",
                'schema': schema_key,
                'tables': [{'name': t} for t in unique_tables],
            })

        data = {'version': 2, 'sources': source_entries}
        self.save_output_yaml(data, 'models/source.yml')

    # ---- Schema files ----

    def _generate_schema_files(self, parsed: Dict) -> None:
        """Generate per-layer schema YAML files with model and column definitions."""
        stg_models: List[Dict] = []
        int_models: List[Dict] = []
        mart_models: List[Dict] = []

        for job_data in parsed.values():
            target_name = self._target_name(job_data)

            # Staging schema entries
            for src in job_data['source_tables']:
                model_name = self._staging_model_name(src)
                stg_models.append({
                    'name': model_name,
                    'description': f"Staging view for {src['schema']}.{src['table_name']}",
                })

            # Intermediate schema entry with column definitions
            int_entry: Dict[str, Any] = {
                'name': f"int_{target_name}",
                'description': (
                    f"Intermediate transformation model for {job_data['job_name']}. "
                    f"Contains joins, CASE logic, and derivation expressions."
                ),
            }
            if job_data['transformations']:
                int_columns = []
                for t in job_data['transformations'][:50]:  # Limit for readability
                    int_columns.append({
                        'name': _to_snake(t['column_name']),
                        'description': f"Derived from: {t['derivation'][:80]}",
                    })
                int_entry['columns'] = int_columns
            int_models.append(int_entry)

            # Marts schema entry with column definitions
            mart_entry: Dict[str, Any] = {
                'name': target_name,
                'description': (
                    f"Business-ready model for {job_data['job_name']}. "
                    f"Load type: {job_data['load_type']}."
                ),
            }
            if job_data['target_columns']:
                mart_columns = []
                for c in job_data['target_columns']:
                    col_entry: Dict[str, Any] = {
                        'name': _to_snake(c['name']),
                        'description': f"Type: {c.get('databricks_type', 'STRING')}",
                    }
                    mart_columns.append(col_entry)
                # Add audit columns
                mart_columns.append({
                    'name': 'etl_load_timestamp',
                    'description': 'ETL processing timestamp',
                })
                mart_columns.append({
                    'name': 'etl_source_job',
                    'description': 'Source DataStage job name',
                })
                mart_entry['columns'] = mart_columns
            mart_models.append(mart_entry)

        self.save_output_yaml(
            {'version': 2, 'models': stg_models},
            'models/staging/stg_schema.yml'
        )
        self.save_output_yaml(
            {'version': 2, 'models': int_models},
            'models/intermediate/int_schema.yml'
        )
        self.save_output_yaml(
            {'version': 2, 'models': mart_models},
            'models/marts/mart_schema.yml'
        )

    # ---- dbt_project.yml ----

    def _generate_dbt_project_yml(self) -> None:
        """Generate dbt_project.yml with all vars, materializations, and paths."""
        # Base vars (always present)
        vars_dict: Dict[str, str] = {
            'source_database': 'edm',
            'target_database': 'edm',
            'ro_role': 'readonlyrole',
            'rw_role': 'readwriterole',
            'edmetl': 'edmetl',
        }
        # Add all parameters discovered from XML jobs
        vars_dict.update(self.all_vars)

        project = {
            'name': 'nyl_forwardengineering_ds_dbt_0312',
            'version': '1.0.0',
            'profile': 'nyl_forwardengineering_ds_dbt_0312',
            'model-paths': ['models'],
            'macro-paths': ['macros'],
            'snapshot-paths': ['snapshots'],
            'vars': vars_dict,
            'models': {
                'nyl_forwardengineering_ds_dbt_0312': {
                    'staging': {
                        'schema': 'staging',
                        'materialized': 'view',
                    },
                    'intermediate': {
                        'schema': 'intermediate',
                        'materialized': 'table',
                    },
                    'marts': {
                        'schema': 'marts',
                        'materialized': 'table',
                    },
                }
            },
        }
        self.save_output_yaml(project, 'dbt_project.yml')

    # ---- Macros ----

    def _generate_macros(self) -> None:
        """Generate reusable dbt macros."""
        # Audit columns macro
        audit_macro = """{% macro generate_audit_columns() %}
    CURRENT_TIMESTAMP() AS etl_load_timestamp,
    '{{ this.name }}' AS etl_source_model
{% endmacro %}
"""
        self.save_output(audit_macro, 'macros/generate_audit_columns.sql')

        # Safe cast macro for type conversions
        safe_cast_macro = """{% macro safe_cast(column_name, target_type, default_value='NULL') %}
    CASE
        WHEN {{ column_name }} IS NULL THEN {{ default_value }}
        ELSE CAST({{ column_name }} AS {{ target_type }})
    END
{% endmacro %}
"""
        self.save_output(safe_cast_macro, 'macros/safe_cast.sql')

    # ---- Visualizations ----

    def _generate_visualizations(self, parsed: Dict) -> None:
        """Generate post-execution visualization files in thoughts/."""
        thoughts_dir = get_project_root() / 'thoughts'
        thoughts_dir.mkdir(parents=True, exist_ok=True)

        # Count totals
        total_staging = sum(len(jd['source_tables']) for jd in parsed.values())
        total_intermediate = len(parsed)
        total_marts = len(parsed)
        total_sources = len(self.all_sources)
        total_vars = len(self.all_vars)

        # Conversion workflow diagram
        workflow = f"""# Conversion Workflow

Generated: {get_timestamp()}

## Pipeline Flow

```
inputs/*.xml
    |
    v
[DataStageParser]
    |  - Parses XML hierarchy (DSExport > Job > Record)
    |  - Extracts source SQL from XMLProperties / Value
    |  - Decodes double-encoded XML entities
    |  - Extracts tables from FROM, JOIN, <Table>, <TableName>
    |  - Extracts transformer derivations and stage variables
    |  - Converts IF/THEN/ELSE, function names, parameters
    |  - Detects load type (full/incremental/CDC)
    |
    v
[Conversion Plans] --> plans/*_conversion_plan.md
    |
    v
[DbtModelGenerator]
    |
    +---> output/models/staging/stg_*.sql        ({total_staging} models)
    +---> output/models/intermediate/int_*.sql   ({total_intermediate} models)
    +---> output/models/marts/*.sql              ({total_marts} models)
    +---> output/models/source.yml               ({total_sources} source tables)
    +---> output/models/staging/stg_schema.yml
    +---> output/models/intermediate/int_schema.yml
    +---> output/models/marts/mart_schema.yml
    +---> output/dbt_project.yml                 ({total_vars} vars)
    +---> output/macros/
```

## Jobs Processed: {len(parsed)}
"""
        for job_key, jd in parsed.items():
            workflow += f"  - {jd['job_name']}: {len(jd['source_tables'])} sources, {len(jd['transformations'])} derivations, load_type={jd['load_type']}\n"

        (thoughts_dir / 'conversion_workflow.md').write_text(workflow, encoding='utf-8')

        # Output structure diagram
        structure = f"""# Output Structure

Generated: {get_timestamp()}

## Generated dbt Project Tree

```
output/
  dbt_project.yml
  macros/
    generate_audit_columns.sql
    safe_cast.sql
  models/
    source.yml
    staging/
      stg_schema.yml
      stg_*.sql            <-- {{{{ source('schema', 'table') }}}}
    intermediate/
      int_schema.yml
      int_*.sql             <-- {{{{ ref('stg_...') }}}}
    marts/
      mart_schema.yml
      *.sql                 <-- {{{{ ref('int_...') }}}}
```

## Model Dependency Flow

```
source.yml
    |  (defines raw source tables with database/schema)
    v
stg_*.sql  [materialized='view']
    |  uses: {{{{ source('schema', 'table') }}}}
    v
int_*.sql  [materialized='table']
    |  uses: {{{{ ref('stg_...') }}}}
    |  contains: JOINs, CASE WHEN, derivations, filters
    v
*.sql (marts)  [materialized='table' or 'incremental']
    |  uses: {{{{ ref('int_...') }}}}
    |  contains: final projection + audit columns
```

## Summary
  - Staging models: {total_staging}
  - Intermediate models: {total_intermediate}
  - Marts models: {total_marts}
  - Source tables: {total_sources}
  - dbt vars: {total_vars}
"""
        (thoughts_dir / 'output_structure.md').write_text(structure, encoding='utf-8')
        self.logger.info("Visualization files written to thoughts/")


    # ---- Build Metrics & Generation Issues ----

    def _collect_build_metrics(self, job: Dict) -> None:
        """Collect per-job metrics for quality threshold evaluation.

        Tracks source table count, transformer column count, function mappings,
        and TODO-flagged functions for each job. These metrics feed into the
        go/no-go quality gate defined in GUARDRAILS.yaml.
        """
        self._build_metrics['jobs_processed'] += 1
        num_sources = len(job['source_tables'])
        num_staging = num_sources
        num_transforms = len(job['transformations'])

        self._build_metrics['staging_models_generated'] += num_staging
        self._build_metrics['intermediate_models_generated'] += 1
        self._build_metrics['marts_models_generated'] += 1
        self._build_metrics['total_source_tables'] += num_sources
        self._build_metrics['total_transformer_columns'] += num_transforms

        # Count function mappings applied and TODO-flagged
        functions_mapped = 0
        functions_flagged = 0
        all_exprs = [t.get('derivation', '') for t in job['transformations']]
        all_exprs += [sv.get('expression', '') for sv in job.get('stage_variables', [])]
        for expr in all_exprs:
            for ds_func in FUNCTION_MAP:
                if re.search(rf'\b{re.escape(ds_func)}\s*\(', expr, re.IGNORECASE):
                    functions_mapped += 1
            unmapped = _extract_unmapped_functions(expr)
            functions_flagged += len(unmapped)

        self._build_metrics['functions_mapped'] += functions_mapped
        self._build_metrics['functions_todo_flagged'] += functions_flagged

        self._build_metrics['per_job_metrics'].append({
            'job_name': job['job_name'],
            'source_tables': num_sources,
            'transformer_columns': num_transforms,
            'stage_variables': len(job.get('stage_variables', [])),
            'joins': len(job.get('joins', [])),
            'source_sql_statements': len(job.get('source_sql_statements', [])),
            'load_type': job.get('load_type', 'unknown'),
            'functions_mapped': functions_mapped,
            'functions_todo_flagged': functions_flagged,
        })

        # Track issues for this job
        if not job['source_tables']:
            self._generation_issues.append({
                'severity': 'high',
                'job': job['job_name'],
                'category': 'missing_sources',
                'description': 'No source tables discovered from XML',
            })
        if not job['target_table'].get('table_name'):
            self._generation_issues.append({
                'severity': 'high',
                'job': job['job_name'],
                'category': 'missing_target',
                'description': 'No target table identified in XML',
            })
        if not job['transformations']:
            self._generation_issues.append({
                'severity': 'medium',
                'job': job['job_name'],
                'category': 'no_transformations',
                'description': 'No transformer derivations found — intermediate model will use SELECT *',
            })

    def _save_build_metrics(self, parsed: Dict) -> None:
        """Save build metrics YAML for quality threshold evaluation.

        The validator and devil's advocate agent use this file to assess
        whether the generation meets the go/no-go thresholds defined
        in GUARDRAILS.yaml quality_thresholds section.
        """
        total_funcs = (self._build_metrics['functions_mapped']
                       + self._build_metrics['functions_todo_flagged'])
        func_conversion_rate = (
            self._build_metrics['functions_mapped'] / total_funcs
            if total_funcs > 0 else 1.0
        )

        metrics = {
            'build_metrics': {
                'timestamp': get_timestamp(),
                'summary': {
                    'jobs_processed': self._build_metrics['jobs_processed'],
                    'staging_models': self._build_metrics['staging_models_generated'],
                    'intermediate_models': self._build_metrics['intermediate_models_generated'],
                    'marts_models': self._build_metrics['marts_models_generated'],
                    'total_source_tables': self._build_metrics['total_source_tables'],
                    'total_transformer_columns': self._build_metrics['total_transformer_columns'],
                    'functions_mapped': self._build_metrics['functions_mapped'],
                    'functions_todo_flagged': self._build_metrics['functions_todo_flagged'],
                    'function_conversion_rate': round(func_conversion_rate, 4),
                },
                'per_job': self._build_metrics['per_job_metrics'],
                'issues_count': len(self._generation_issues),
            }
        }
        metrics_path = get_project_root() / 'thoughts' / 'build_metrics.yaml'
        metrics_path.parent.mkdir(parents=True, exist_ok=True)
        save_yaml(metrics, metrics_path)
        self.logger.info(
            f"Build metrics saved: {self._build_metrics['jobs_processed']} jobs, "
            f"function conversion rate: {func_conversion_rate:.1%}"
        )

    def _save_generation_issues(self) -> None:
        """Save structured generation issues for escalation protocol.

        Issues are categorized by severity (high/medium/low) to support
        the L1-L4 escalation protocol defined in .claude/rules/escalation.md.
        High-severity issues may trigger L3 (blocking) or L4 (critical) escalation.
        """
        if not self._generation_issues:
            return
        issues_data = {
            'generation_issues': {
                'timestamp': get_timestamp(),
                'total_issues': len(self._generation_issues),
                'high_severity': len([i for i in self._generation_issues if i['severity'] == 'high']),
                'medium_severity': len([i for i in self._generation_issues if i['severity'] == 'medium']),
                'issues': self._generation_issues,
            }
        }
        issues_path = get_project_root() / 'thoughts' / 'generation_issues.yaml'
        issues_path.parent.mkdir(parents=True, exist_ok=True)
        save_yaml(issues_data, issues_path)
        self.logger.info(
            f"Generation issues saved: {len(self._generation_issues)} issues "
            f"({issues_data['generation_issues']['high_severity']} high)"
        )


# =============================================================================
# Entry Point
# =============================================================================

def main() -> None:
    """Entry point for dbt model generation from DataStage XML.

    Called by build_all.py (auto-discovers generate_*.py scripts)
    or directly: python scripts/generate_dbt_models.py
    """
    root = get_project_root()
    parser = DataStageParser(
        input_dir=str(root / 'inputs'),
        output_dir=str(root / 'output'),
    )
    generator = DbtModelGenerator(
        parser=parser,
        plans_dir=str(root / 'plans'),
        output_dir=str(root / 'output'),
    )
    generator.generate()


if __name__ == '__main__':
    main()
