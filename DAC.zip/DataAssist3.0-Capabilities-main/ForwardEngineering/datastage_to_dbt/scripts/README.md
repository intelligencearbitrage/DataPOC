# DataStage-to-dbt Converter

Converts IBM DataStage XML job exports into a complete dbt project (staging, intermediate, marts) for Databricks. Runs entirely with Python — no Claude or LLM dependency.

## What it does

- Parses DataStage `.xml` job files from `inputs/`
- Applies built-in transformation rules and function mappings
- Generates a three-layer dbt project (staging, intermediate, marts) in `output/`
- Validates generated models against source XML for correctness and completeness
- Automatically refines output by patching issues (missing columns, placeholder joins, etc.)
- Produces go/no-go quality gate recommendations based on configurable thresholds

## Setup

### Prerequisites

- Python 3.8+

### Install dependencies

```bash
pip install -r requirements.txt
```

### Prepare inputs

Place your DataStage XML export files in the `inputs/` directory at the converter root:

```
nyl_dbt_local_converter_0312/
├── inputs/          <-- place .xml files here
├── output/          <-- generated dbt project
├── plans/           <-- conversion plans
├── thoughts/        <-- build logs and metrics
├── scripts/
│   └── datastage-to-dbt/   <-- this directory
```

## How to run

All commands are executed via `cli.py`:

```bash
# Run the full pipeline (generate + validate + refine)
python scripts/datastage-to-dbt/cli.py run

# Generate dbt models only
python scripts/datastage-to-dbt/cli.py generate

# Validate existing output only
python scripts/datastage-to-dbt/cli.py validate

# Validate a specific job
python scripts/datastage-to-dbt/cli.py validate --job MyJobName

# Refine output using a validation report
python scripts/datastage-to-dbt/cli.py refine --report path/to/report.yaml

# Refine with human feedback
python scripts/datastage-to-dbt/cli.py refine --report path/to/report.yaml --feedback feedback.txt

# Clean output and regenerate
python scripts/datastage-to-dbt/cli.py generate --clean

# Custom input/output directories
python scripts/datastage-to-dbt/cli.py run --input-dir ./my_xmls --output-dir ./my_output

# Enable verbose (debug) logging
python scripts/datastage-to-dbt/cli.py run --verbose
```

## Scripts overview

| File | Purpose |
|------|---------|
| `cli.py` | Single CLI entry point exposing all commands via argparse |
| `generate_dbt_models.py` | Parses DataStage XML and generates the three-layer dbt project |
| `validator.py` | Validates generated dbt models against source XML, produces go/no-go |
| `refiner.py` | Auto-patches dbt output based on validation reports |
| `prompts.py` | Centralized prompt templates for the agentic validation/refinement layer |
| `build_all.py` | Discovers and runs all `generate_*.py` scripts |
| `base_parser.py` | Abstract base class for input parsers |
| `base_generator.py` | Abstract base class for output generators |
| `base_validator.py` | Abstract base class for output validators |
| `utils.py` | Shared utilities (YAML I/O, logging, path helpers) |

## Assumptions and limitations

- Input files must be IBM DataStage XML job exports (`.xml` extension)
- The converter handles Oracle-style SQL syntax found in DataStage source queries (e.g., `(+)` outer joins, `TO_CHAR`, `DECODE`)
- Function mappings cover the most common DataStage-to-Databricks conversions; unmapped functions are flagged with `TODO` comments
- Quality thresholds are configured in `GUARDRAILS.yaml` bundled in this directory
- The refinement loop stops after 3 iterations by default (configurable via `--max-iterations`)
- The refiner only modifies files in `output/` — it never touches `inputs/`, `knowledgebase/`, or `scripts/`

## Environment requirements

- Python 3.8 or later
- `pyyaml` >= 5.0 (the only external dependency)
- No network access required — everything runs locally
