"""
Agentic Layer — Refiner Script.

Takes a validation report and optional human feedback, then patches dbt output
files directly to resolve identified issues. Only writes to output/ — never
modifies scripts/, inputs/, or knowledgebase/.

Enhanced for nyl_forwardengineering_ds_dbt_0312:
  - Escalation protocol integration (L1-L4 detection)
  - Quality threshold awareness (stops on NO-GO regression)
  - Stale issue detection with escalation
  - Build metrics integration

Usage:
    python scripts/refiner.py --report PATH_TO_REPORT.yaml
    python scripts/refiner.py --report PATH --feedback "your feedback here"
    python scripts/refiner.py --report PATH --max-iterations 3
"""

import argparse
import copy
import difflib
import re
import sys
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from generate_dbt_models import (
    DataStageParser,
    FUNCTION_MAP,
    _to_snake,
    _convert_derivation,
)
from utils import load_yaml, save_yaml, setup_logging, get_project_root, get_timestamp, sanitize_path

from prompts import (
    REFINER_SYSTEM_PROMPT,
    REFINER_PATCH_PROMPT,
    REFINER_JOIN_FIX_PROMPT,
    REFINER_COLUMN_FIX_PROMPT,
)

# =============================================================================
# Constants from GUARDRAILS.yaml
# =============================================================================

MAX_LINES_PER_FIX = 50
MAX_ITERATIONS_DEFAULT = 3
ALLOWED_WRITE_DIR = 'output'
BLOCKED_DIRS = {'inputs', 'knowledgebase', 'scripts'}


class DbtOutputRefiner:
    """Patches dbt output files based on validation reports and human feedback.

    Enhanced with escalation protocol detection and quality threshold awareness.
    """

    def __init__(
        self,
        input_dir: str = 'inputs',
        output_dir: str = 'output',
        kb_dir: str = 'knowledgebase',
        report_dir: Optional[str] = None,
    ):
        self.input_dir = sanitize_path(input_dir, 'input_dir')
        self.output_dir = sanitize_path(output_dir, 'output_dir')
        self.kb_dir = sanitize_path(kb_dir, 'kb_dir')
        self.report_dir = sanitize_path(report_dir, 'report_dir') if report_dir else (
            get_project_root() / 'thoughts' / 'logs' / 'agentic'
        )
        self.parser = DataStageParser(
            input_dir=input_dir, output_dir=output_dir
        )
        self.logger = setup_logging('DbtOutputRefiner')
        self.actions_log: List[Dict[str, Any]] = []

    # -------------------------------------------------------------------------
    # Guardrail checks
    # -------------------------------------------------------------------------

    def _is_allowed_write(self, file_path: Path) -> bool:
        resolved = file_path.resolve()
        output_resolved = self.output_dir.resolve()
        return str(resolved).startswith(str(output_resolved))

    def _check_diff_size(self, original: str, patched: str) -> Tuple[bool, int]:
        orig_lines = original.splitlines(keepends=True)
        patch_lines = patched.splitlines(keepends=True)
        diff = list(difflib.unified_diff(orig_lines, patch_lines))
        changed = sum(1 for line in diff if line.startswith('+') or line.startswith('-'))
        changed = max(0, changed - 2)
        return changed <= MAX_LINES_PER_FIX, changed

    # -------------------------------------------------------------------------
    # Feedback validation
    # -------------------------------------------------------------------------

    def validate_feedback(self, feedback: str, report: Dict[str, Any]) -> Dict[str, Any]:
        result = {
            'timestamp': get_timestamp(),
            'human_feedback_raw': feedback,
            'validation_results': [],
            'accepted_feedback': '',
            'rejected_feedback': [],
        }
        issues = report.get('validation_report', {}).get('issues', [])
        issue_ids = {i.get('id', '') for i in issues}
        output_files = {i.get('output_file', '') for i in issues}

        feedback_items = [s.strip() for s in feedback.split(';') if s.strip()]
        accepted_items = []
        for item in feedback_items:
            checks = []
            references_issue = any(iid in item for iid in issue_ids if iid)
            references_output = any('output' in item.lower() or Path(of).name.lower() in item.lower() for of in output_files if of)
            references_general = any(kw in item.lower() for kw in ['join', 'column', 'function', 'mapping', 'missing', 'incorrect', 'fix', 'add'])
            relevant = references_issue or references_output or references_general
            checks.append({'check': 'relevance', 'item': item, 'result': 'PASS' if relevant else 'FAIL', 'reason': 'References validation issue or output content' if relevant else 'Does not relate to any validation issue'})

            not_actionable_markers = ['change database', 'modify script', 'update pipeline', 'change architecture', 'refactor']
            actionable = not any(m in item.lower() for m in not_actionable_markers)
            checks.append({'check': 'actionability', 'item': item, 'result': 'PASS' if actionable else 'FAIL', 'reason': 'Can be applied as an output patch' if actionable else 'Requires changes outside output/'})

            modifies_blocked = any(d in item.lower() for d in ['inputs/', 'knowledgebase/', 'scripts/'])
            consistent = not modifies_blocked
            checks.append({'check': 'source_consistency', 'item': item, 'result': 'PASS' if consistent else 'FAIL', 'reason': 'Consistent with source data' if consistent else 'Contradicts immutable directory constraints'})

            result['validation_results'].extend(checks)
            if relevant and actionable and consistent:
                accepted_items.append(item)
            else:
                failed_checks = [c['check'] for c in checks if c['result'] == 'FAIL']
                result['rejected_feedback'].append({'item': item, 'reason': f'Failed checks: {", ".join(failed_checks)}'})

        result['accepted_feedback'] = '; '.join(accepted_items)
        return result

    # -------------------------------------------------------------------------
    # Issue-specific fixers
    # -------------------------------------------------------------------------

    def _fix_placeholder_joins(self, issue, parsed_jobs):
        output_file = issue.get('output_file', '')
        if not output_file:
            return None
        try:
            file_path = sanitize_path(output_file, 'output_file')
        except ValueError:
            self.logger.error(f'Path traversal blocked in output_file: {output_file}')
            return None
        if not file_path.exists() or not self._is_allowed_write(file_path):
            return None

        original = file_path.read_text(encoding='utf-8')
        job_data = None
        for job_name, parsed in parsed_jobs.items():
            target = parsed.get('target_table', {}).get('table_name', '')
            model_base = _to_snake(target) if target else ''
            if model_base and model_base in file_path.name:
                job_data = parsed
                break
        if not job_data:
            return None

        patched = original
        for join_info in job_data.get('joins', []):
            key_columns = join_info.get('key_columns', [])
            ref_stage = join_info.get('reference_stage_name', '')
            if not key_columns or not ref_stage:
                continue
            cte_name = _to_snake(re.sub(r'^Orcl', '', ref_stage))
            pattern = re.compile(
                rf'((?:LEFT|INNER|FULL)\s+JOIN\s+{re.escape(cte_name)}\b.*?)ON\s+1\s*=\s*1',
                re.IGNORECASE | re.DOTALL
            )
            match = pattern.search(patched)
            if match:
                on_clause = ' AND '.join(f'source_data.{col} = {cte_name}.{col}' for col in key_columns)
                replacement = match.group(1) + f'ON {on_clause}'
                patched = patched[:match.start()] + replacement + patched[match.end():]

        if patched == original:
            return None

        within_limit, lines_changed = self._check_diff_size(original, patched)
        action = {
            'issue_id': issue.get('id', ''),
            'description': issue.get('description', ''),
            'output_file_patched': str(file_path),
            'lines_changed': lines_changed,
            'approach': 'Replaced ON 1=1 with real join keys from source XML',
            'source_reference': f'inputs/ XML join metadata for {ref_stage}',
        }
        if not within_limit:
            action['status'] = 'flagged_for_review'
            action['reason'] = f'Diff exceeds {MAX_LINES_PER_FIX} line cap'
            return action
        file_path.write_text(patched, encoding='utf-8')
        action['status'] = 'applied'
        return action

    def _fix_missing_columns(self, issue, parsed_jobs):
        output_file = issue.get('output_file', '')
        if not output_file:
            return None
        try:
            file_path = sanitize_path(output_file, 'output_file')
        except ValueError:
            self.logger.error(f'Path traversal blocked in output_file: {output_file}')
            return None
        if not file_path.exists() or not self._is_allowed_write(file_path):
            return None

        desc = issue.get('description', '')
        col_match = re.search(r'columns not found.*?:\s*(.+)', desc)
        if not col_match:
            return None
        missing_cols = [c.strip() for c in col_match.group(1).split(',')]
        missing_cols = [re.sub(r'\s*\(and \d+ more\)$', '', c) for c in missing_cols]

        job_data = None
        for job_name, parsed in parsed_jobs.items():
            target = parsed.get('target_table', {}).get('table_name', '')
            model_base = _to_snake(target) if target else ''
            if model_base and model_base in file_path.name:
                job_data = parsed
                break
        if not job_data:
            return None

        col_map = {t['column_name']: t.get('derivation', t['column_name']) for t in job_data.get('transformations', [])}
        original = file_path.read_text(encoding='utf-8')
        patched = original
        added = []
        for col_name in missing_cols:
            if col_name not in col_map:
                continue
            snake_col = _to_snake(col_name)
            deriv = col_map[col_name]
            try:
                converted = _convert_derivation(deriv)
            except Exception:
                converted = deriv
            col_line = f'        {converted} AS {snake_col}'
            if snake_col.lower() in patched.lower():
                continue
            insert_pattern = re.compile(r'(transformer_data\s+AS\s*\(\s*SELECT\b.*?)(\n\s+FROM\b)', re.IGNORECASE | re.DOTALL)
            m = insert_pattern.search(patched)
            if m:
                patched = patched[:m.end(1)] + f',\n{col_line}' + patched[m.start(2):]
                added.append(col_name)

        if not added:
            return None
        within_limit, lines_changed = self._check_diff_size(original, patched)
        action = {
            'issue_id': issue.get('id', ''),
            'description': f'Added {len(added)} missing columns: {", ".join(added)}',
            'output_file_patched': str(file_path),
            'lines_changed': lines_changed,
            'approach': 'Added missing transformer columns from source derivations',
            'source_reference': 'inputs/ XML transformer metadata',
        }
        if not within_limit:
            action['status'] = 'flagged_for_review'
            action['reason'] = f'Diff exceeds {MAX_LINES_PER_FIX} line cap'
            return action
        file_path.write_text(patched, encoding='utf-8')
        action['status'] = 'applied'
        return action

    # -------------------------------------------------------------------------
    # Main refinement loop
    # -------------------------------------------------------------------------

    def refine(self, report_path: str, human_feedback: Optional[str] = None, max_iterations: int = MAX_ITERATIONS_DEFAULT) -> Dict[str, Any]:
        """Run the refinement loop with escalation protocol awareness."""
        from validator import DbtOutputValidator

        clean_report = re.sub(r'[^\w.\-/\\ ]', '', report_path)
        if clean_report != report_path:
            self.logger.error(f'Report path contains disallowed characters: {report_path}')
            return {'status': 'error', 'message': 'Invalid report path'}
        safe_report_path = sanitize_path(clean_report, 'report')
        report = load_yaml(safe_report_path)
        if not report:
            self.logger.error(f'Could not load report: {report_path}')
            return {'status': 'error', 'message': 'Report not found'}

        raw_run_id = report.get('validation_report', {}).get('run_id', '')
        run_id = re.sub(r'[^a-zA-Z0-9_\-]', '_', raw_run_id) if raw_run_id else datetime.now().strftime('run_%Y-%m-%d_%H%M%S')
        run_dir = self.report_dir / run_id
        run_dir.mkdir(parents=True, exist_ok=True)

        # Validate feedback
        accepted_feedback = ''
        if human_feedback:
            fb_result = self.validate_feedback(human_feedback, report)
            save_yaml(fb_result, run_dir / 'feedback_validation_1.yaml')
            accepted_feedback = fb_result.get('accepted_feedback', '')
            if not accepted_feedback:
                self.logger.warning('All feedback was rejected')

        # Parse all input XML files
        parsed_jobs: Dict[str, Dict] = {}
        for xml_file in self.parser.discover_files():
            try:
                parsed = self.parser.parse_file(xml_file)
                parsed_jobs[xml_file.stem] = parsed
            except Exception as e:
                self.logger.error(f'Failed to parse {xml_file}: {e}')

        # Track accuracy and escalation
        accuracy_progression = [{
            'stage': 'initial_validation',
            'accuracy': report['validation_report']['overall_accuracy'],
            'issues_found': report['validation_report']['summary']['issues_found'],
            'go_no_go': report['validation_report'].get('go_no_go', {}).get('recommendation', 'N/A'),
        }]

        prev_accuracy = report['validation_report']['overall_accuracy']
        stale_issues: Dict[str, int] = {}
        escalations: List[Dict] = []

        for iteration in range(1, max_iterations + 1):
            self.logger.info(f'--- Iteration {iteration}/{max_iterations} ---')
            issues = report.get('validation_report', {}).get('issues', [])

            if not issues:
                self.logger.info('No issues remaining — loop complete')
                break

            iteration_actions: List[Dict] = []

            for issue in issues:
                issue_id = issue.get('id', '')
                category = issue.get('category', '')

                # Escalation: skip stale issues (failed 2+ consecutive iterations)
                if stale_issues.get(issue_id, 0) >= 2:
                    self.logger.info(f'Skipping stale issue {issue_id} — escalating to L3')
                    escalations.append({
                        'issue_id': issue_id,
                        'level': 'L3',
                        'reason': f'Issue failed to improve in {stale_issues[issue_id]} consecutive iterations',
                        'iteration': iteration,
                    })
                    continue

                action = None
                if category == 'join_issue':
                    action = self._fix_placeholder_joins(issue, parsed_jobs)
                elif category == 'missing_content':
                    if 'column' in issue.get('description', '').lower():
                        action = self._fix_missing_columns(issue, parsed_jobs)

                if action:
                    iteration_actions.append(action)
                    if action.get('status') == 'applied':
                        stale_issues.pop(issue_id, None)
                    else:
                        stale_issues[issue_id] = stale_issues.get(issue_id, 0) + 1
                else:
                    stale_issues[issue_id] = stale_issues.get(issue_id, 0) + 1

            # Save iteration refiner log
            iter_log = {
                'iteration': iteration,
                'timestamp': get_timestamp(),
                'trigger': 'validation_errors + human_feedback' if accepted_feedback else 'validation_errors',
                'issues_attempted': iteration_actions,
                'human_feedback_applied': accepted_feedback or None,
                'escalations': escalations if escalations else None,
            }
            save_yaml(iter_log, run_dir / f'iteration_{iteration}_refiner.yaml')

            # Re-validate
            validator = DbtOutputValidator(
                input_dir=str(self.input_dir),
                output_dir=str(self.output_dir),
                report_dir=str(self.report_dir),
            )
            new_issues = []
            new_passed = []
            for xml_file in validator.parser.discover_files():
                validator.issue_counter = 0
                job_issues, job_passed = validator._validate_job(xml_file)
                new_issues.extend(job_issues)
                new_passed.extend(job_passed)

            new_report = validator.generate_report(new_issues, new_passed, run_id)
            save_yaml(new_report, run_dir / f'iteration_{iteration}_validation.yaml')

            new_accuracy = new_report['validation_report']['overall_accuracy']
            new_issue_count = new_report['validation_report']['summary']['issues_found']
            new_go_no_go = new_report['validation_report'].get('go_no_go', {}).get('recommendation', 'N/A')
            applied_count = sum(1 for a in iteration_actions if a.get('status') == 'applied')

            accuracy_progression.append({
                'stage': f'iteration_{iteration}',
                'accuracy': new_accuracy,
                'issues_patched': applied_count,
                'issues_remaining': new_issue_count,
                'go_no_go': new_go_no_go,
            })

            self.logger.info(
                f'Iteration {iteration}: accuracy {prev_accuracy}% -> {new_accuracy}%, '
                f'{applied_count} fixes applied, {new_issue_count} issues remaining, '
                f'go/no-go: {new_go_no_go}'
            )

            # Check for accuracy regression — escalate to L4
            if new_accuracy < prev_accuracy:
                self.logger.warning('Accuracy regression detected — L4 escalation, stopping loop')
                escalations.append({
                    'level': 'L4',
                    'reason': f'Accuracy regressed from {prev_accuracy}% to {new_accuracy}%',
                    'iteration': iteration,
                })
                break

            if new_issue_count == 0:
                self.logger.info('All issues resolved — loop complete')
                break

            prev_accuracy = new_accuracy
            report = new_report

        # Save accuracy progression
        save_yaml({
            'run_id': run_id,
            'progression': accuracy_progression,
            'trend': self._compute_trend(accuracy_progression),
            'escalations': escalations if escalations else None,
        }, run_dir / 'accuracy_progression.yaml')

        # Save run summary
        summary = {
            'run_id': run_id,
            'timestamp': get_timestamp(),
            'iterations_run': len(accuracy_progression) - 1,
            'initial_accuracy': accuracy_progression[0]['accuracy'],
            'final_accuracy': accuracy_progression[-1]['accuracy'],
            'initial_go_no_go': accuracy_progression[0].get('go_no_go', 'N/A'),
            'final_go_no_go': accuracy_progression[-1].get('go_no_go', 'N/A'),
            'human_feedback_provided': bool(human_feedback),
            'human_feedback_accepted': bool(accepted_feedback),
            'stale_issues': [iid for iid, count in stale_issues.items() if count >= 2],
            'escalations': escalations if escalations else None,
        }
        save_yaml(summary, run_dir / 'run_summary.yaml')

        self.logger.info(
            f'Refinement complete. '
            f'Accuracy: {accuracy_progression[0]["accuracy"]}% -> '
            f'{accuracy_progression[-1]["accuracy"]}%'
        )

        return summary

    def _compute_trend(self, progression):
        if len(progression) < 2:
            return 'insufficient_data'
        accuracies = [p['accuracy'] for p in progression]
        if all(a >= b for a, b in zip(accuracies[1:], accuracies)):
            return 'improving'
        if all(a <= b for a, b in zip(accuracies[1:], accuracies)):
            return 'regressing'
        return 'mixed'


# =============================================================================
# CLI
# =============================================================================

def main():
    arg_parser = argparse.ArgumentParser(description='Refine dbt output files based on validation reports')
    arg_parser.add_argument('--report', type=str, required=True, help='Path to validation report YAML')
    arg_parser.add_argument('--feedback', type=str, default=None, help='Human feedback (semicolon-separated)')
    arg_parser.add_argument('--max-iterations', type=int, default=MAX_ITERATIONS_DEFAULT, help='Max iterations')
    arg_parser.add_argument('--input-dir', type=str, default='inputs', help='Input directory')
    arg_parser.add_argument('--output-dir', type=str, default='output', help='Output directory')
    args = arg_parser.parse_args()

    refiner = DbtOutputRefiner(input_dir=args.input_dir, output_dir=args.output_dir)
    summary = refiner.refine(report_path=args.report, human_feedback=args.feedback, max_iterations=args.max_iterations)

    print(f'\nRefinement summary:')
    print(f'  Iterations: {summary.get("iterations_run", 0)}')
    print(f'  Initial accuracy: {summary.get("initial_accuracy", "N/A")}%')
    print(f'  Final accuracy: {summary.get("final_accuracy", "N/A")}%')
    print(f'  Go/No-Go: {summary.get("final_go_no_go", "N/A")}')
    if summary.get('escalations'):
        print(f'  Escalations: {len(summary["escalations"])}')


if __name__ == '__main__':
    main()
