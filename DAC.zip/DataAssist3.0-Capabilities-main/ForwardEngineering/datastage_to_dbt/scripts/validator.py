"""
Agentic Layer — Validator Script.

Compares generated dbt models in output/ against source DataStage XML jobs
in inputs/ and reference knowledge in knowledgebase/. Produces structured
YAML validation reports with go/no-go recommendations. This script is
strictly read-only — it does not modify any files.

Enhanced for nyl_forwardengineering_ds_dbt_0312:
  - Quality threshold evaluation from GUARDRAILS.yaml
  - Go/no-go recommendation (GO / CONDITIONAL GO / NO-GO)
  - Build metrics integration from thoughts/build_metrics.yaml
  - Escalation severity classification (L1-L4)
  - Devil's advocate aligned verdict format (PASS/WARN/FAIL)

Usage:
    python scripts/validator.py                   # Validate all jobs
    python scripts/validator.py --job JobName     # Validate a single job
    python scripts/validator.py --report-dir DIR  # Custom report output dir
"""

import argparse
import re
import sys
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional, Set, Tuple

import yaml

from base_validator import BaseValidator
from generate_dbt_models import (
    DataStageParser,
    FUNCTION_MAP,
    _to_snake,
)
from utils import save_yaml, load_yaml, setup_logging, get_project_root, get_timestamp, sanitize_path

from prompts import (
    VALIDATOR_SYSTEM_PROMPT,
    VALIDATOR_COMPARISON_PROMPT,
    VALIDATOR_JOIN_CHECK_PROMPT,
    GO_NO_GO_TEMPLATE,
)

# =============================================================================
# Constants
# =============================================================================

REQUIRED_DBT_LAYERS = ['staging', 'intermediate', 'marts']
AUDIT_COLUMNS = ['etl_load_timestamp', 'etl_source_job']


class DbtOutputValidator(BaseValidator):
    """Validates generated dbt models against source DataStage XML jobs.

    Enhanced with quality threshold evaluation and go/no-go recommendations.
    """

    def __init__(
        self,
        input_dir: str = 'inputs',
        output_dir: str = 'output',
        kb_dir: str = 'knowledgebase',
        report_dir: Optional[str] = None,
    ):
        super().__init__(target_dir=output_dir)
        clean_input = re.sub(r'[^\w.\-/\\ ]', '', input_dir)
        if clean_input != input_dir:
            raise ValueError(f'input_dir contains disallowed characters: {input_dir}')
        clean_output = re.sub(r'[^\w.\-/\\ ]', '', output_dir)
        if clean_output != output_dir:
            raise ValueError(f'output_dir contains disallowed characters: {output_dir}')
        clean_kb = re.sub(r'[^\w.\-/\\ ]', '', kb_dir)
        if clean_kb != kb_dir:
            raise ValueError(f'kb_dir contains disallowed characters: {kb_dir}')
        self.input_dir = sanitize_path(clean_input, 'input_dir')
        self.output_dir = sanitize_path(clean_output, 'output_dir')
        self.kb_dir = sanitize_path(clean_kb, 'kb_dir')
        if report_dir:
            clean_rd = re.sub(r'[^\w.\-/\\ ]', '', report_dir)
            if clean_rd != report_dir:
                raise ValueError(f'report_dir contains disallowed characters: {report_dir}')
            self.report_dir = sanitize_path(clean_rd, 'report_dir')
        else:
            self.report_dir = get_project_root() / 'thoughts' / 'logs' / 'agentic'
        self.parser = DataStageParser(
            input_dir=input_dir, output_dir=output_dir
        )
        self.issue_counter = 0
        self._quality_thresholds = self._load_quality_thresholds()

    def _load_quality_thresholds(self) -> Dict[str, Any]:
        """Load quality thresholds from GUARDRAILS.yaml."""
        local_path = Path(__file__).resolve().parent / 'GUARDRAILS.yaml'
        fallback_path = get_project_root() / 'GUARDRAILS.yaml'
        guardrails_path = local_path if local_path.exists() else fallback_path
        if guardrails_path.exists():
            with open(guardrails_path, 'r') as f:
                data = yaml.safe_load(f)
            return data.get('quality_thresholds', {})
        return {}

    def _next_issue_id(self) -> str:
        """Generate the next sequential issue ID."""
        self.issue_counter += 1
        return f'V-{self.issue_counter:03d}'

    # -------------------------------------------------------------------------
    # Core validation entry point
    # -------------------------------------------------------------------------

    def validate(self) -> List[Dict[str, str]]:
        """Run all validation checks across all jobs. Returns list of issues."""
        all_issues: List[Dict[str, str]] = []
        all_passed: List[str] = []

        xml_files = self.parser.discover_files()
        if not xml_files:
            all_issues.append({
                'id': self._next_issue_id(),
                'severity': 'high',
                'escalation_level': 'L3',
                'category': 'structural_issue',
                'description': 'No XML input files found in inputs/',
                'source_file': str(self.input_dir),
                'output_file': '',
            })
            return all_issues

        for xml_file in xml_files:
            job_issues, job_passed = self._validate_job(xml_file)
            all_issues.extend(job_issues)
            all_passed.extend(job_passed)

        return all_issues

    def validate_job(self, job_name: str) -> Tuple[List[Dict], List[str]]:
        """Validate a single job by name. Returns (issues, passed_checks)."""
        xml_path = self.input_dir / f'{job_name}.xml'
        if not xml_path.exists():
            return ([{
                'id': self._next_issue_id(),
                'severity': 'high',
                'escalation_level': 'L3',
                'category': 'structural_issue',
                'description': f'Input XML file not found: {job_name}.xml',
                'source_file': str(xml_path),
                'output_file': '',
            }], [])
        return self._validate_job(xml_path)

    # -------------------------------------------------------------------------
    # Per-job validation
    # -------------------------------------------------------------------------

    def _validate_job(
        self, xml_path: Path
    ) -> Tuple[List[Dict[str, str]], List[str]]:
        """Validate all dbt models generated from a single DataStage XML job."""
        issues: List[Dict[str, str]] = []
        passed: List[str] = []

        # Parse source XML
        try:
            parsed = self.parser.parse_file(xml_path)
        except Exception as e:
            issues.append({
                'id': self._next_issue_id(),
                'severity': 'high',
                'escalation_level': 'L3',
                'category': 'structural_issue',
                'description': f'Failed to parse source XML: {e}',
                'source_file': str(xml_path),
                'output_file': '',
            })
            return issues, passed

        job_name = parsed.get('job_name', xml_path.stem)
        target_table = parsed.get('target_table', {}).get('table_name', '')
        model_base = _to_snake(target_table) if target_table else _to_snake(
            job_name.replace('DwhTo', '').replace('StgTo', '').replace('Ins', '')
        )

        # Determine expected output file paths
        stg_dir = self.output_dir / 'models' / 'staging'
        int_dir = self.output_dir / 'models' / 'intermediate'
        mart_dir = self.output_dir / 'models' / 'marts'

        stg_file = stg_dir / f'stg_{model_base}.sql'
        int_file = int_dir / f'int_{model_base}.sql'
        mart_file = mart_dir / f'{model_base}.sql'

        # --- Check 1: File existence ---
        i, p = self._check_file_existence(
            xml_path, stg_file, int_file, mart_file, parsed
        )
        issues.extend(i)
        passed.extend(p)

        # --- Check 2: Source table coverage ---
        if int_file.exists():
            i, p = self._check_source_tables(parsed, int_file, xml_path)
            issues.extend(i)
            passed.extend(p)

        # --- Check 3: Join conditions ---
        if int_file.exists():
            i, p = self._check_join_conditions(parsed, int_file, xml_path)
            issues.extend(i)
            passed.extend(p)

        # --- Check 4: Transformer columns ---
        if int_file.exists():
            i, p = self._check_transformer_columns(parsed, int_file, xml_path)
            issues.extend(i)
            passed.extend(p)

        # --- Check 5: Function conversion ---
        if int_file.exists():
            i, p = self._check_function_conversion(parsed, int_file, xml_path)
            issues.extend(i)
            passed.extend(p)

        # --- Check 6: Audit columns in marts ---
        if mart_file.exists():
            i, p = self._check_audit_columns(mart_file, xml_path)
            issues.extend(i)
            passed.extend(p)

        # --- Check 7: Naming conventions ---
        if int_file.exists():
            i, p = self._check_naming_conventions(int_file, xml_path)
            issues.extend(i)
            passed.extend(p)

        return issues, passed

    # -------------------------------------------------------------------------
    # Individual checks (same as working project)
    # -------------------------------------------------------------------------

    def _check_file_existence(self, xml_path, stg_file, int_file, mart_file, parsed):
        issues, passed = [], []
        stg_dir = stg_file.parent
        if stg_dir.exists():
            stg_files = list(stg_dir.glob('stg_*.sql'))
            if stg_files:
                passed.append(f'Staging models exist ({len(stg_files)} files)')
            else:
                issues.append({'id': self._next_issue_id(), 'severity': 'medium', 'escalation_level': 'L2', 'category': 'structural_issue', 'description': 'No staging models found in output/models/staging/', 'source_file': str(xml_path), 'output_file': str(stg_dir)})
        if int_file.exists():
            passed.append(f'Intermediate model exists: {int_file.name}')
        else:
            issues.append({'id': self._next_issue_id(), 'severity': 'high', 'escalation_level': 'L3', 'category': 'missing_content', 'description': f'Intermediate model missing: {int_file.name}', 'source_file': str(xml_path), 'output_file': str(int_file)})
        if mart_file.exists():
            passed.append(f'Marts model exists: {mart_file.name}')
        else:
            issues.append({'id': self._next_issue_id(), 'severity': 'high', 'escalation_level': 'L3', 'category': 'missing_content', 'description': f'Marts model missing: {mart_file.name}', 'source_file': str(xml_path), 'output_file': str(mart_file)})
        return issues, passed

    def _check_source_tables(self, parsed, int_file, xml_path):
        issues, passed = [], []
        int_content = int_file.read_text(encoding='utf-8').upper()
        source_sqls = parsed.get('source_sql_statements', [])
        found_count = 0
        total = len(source_sqls)
        for sql_entry in source_sqls:
            stage_name = sql_entry.get('stage_name', '')
            cte_name = _to_snake(re.sub(r'^Orcl', '', stage_name)).upper()
            src_cte_name = f'SRC_{cte_name}'
            if cte_name in int_content or src_cte_name in int_content or stage_name.upper() in int_content:
                found_count += 1
            else:
                issues.append({'id': self._next_issue_id(), 'severity': 'high', 'escalation_level': 'L2', 'category': 'missing_content', 'description': f'Source SQL from stage "{stage_name}" not found in intermediate model', 'source_file': str(xml_path), 'output_file': str(int_file)})
        if found_count == total and total > 0:
            passed.append(f'All {total} source SQL stages present in intermediate model')
        elif found_count > 0:
            passed.append(f'{found_count}/{total} source SQL stages present')
        return issues, passed

    def _check_join_conditions(self, parsed, int_file, xml_path):
        issues, passed = [], []
        int_content = int_file.read_text(encoding='utf-8')
        joins = parsed.get('joins', [])
        placeholder_count = int_content.count('ON 1=1')
        real_join_count = 0
        for join_info in joins:
            key_columns = join_info.get('key_columns', [])
            stage_name = join_info.get('stage_name', '')
            if key_columns:
                keys_found = any(
                    re.search(rf'ON\b.*\b{re.escape(col)}\b', int_content, re.IGNORECASE | re.DOTALL)
                    for col in key_columns
                )
                if keys_found:
                    real_join_count += 1
                else:
                    issues.append({'id': self._next_issue_id(), 'severity': 'high', 'escalation_level': 'L2', 'category': 'join_issue', 'description': f'Join stage "{stage_name}" has key columns {key_columns} in source but not in ON clause', 'source_file': str(xml_path), 'output_file': str(int_file)})
        if placeholder_count > 0:
            issues.append({'id': self._next_issue_id(), 'severity': 'medium', 'escalation_level': 'L2', 'category': 'join_issue', 'description': f'{placeholder_count} placeholder ON 1=1 join(s) found', 'source_file': str(xml_path), 'output_file': str(int_file)})
        total_with_keys = sum(1 for j in joins if j.get('key_columns'))
        if real_join_count == total_with_keys and total_with_keys > 0:
            passed.append(f'All {total_with_keys} join stages with keys have proper ON conditions')
        return issues, passed

    def _check_transformer_columns(self, parsed, int_file, xml_path):
        issues, passed = [], []
        int_content = int_file.read_text(encoding='utf-8').upper()
        transformations = parsed.get('transformations', [])
        seen: Dict[str, Dict] = {}
        for t in transformations:
            seen[t['column_name']] = t
        unique_cols = list(seen.values())
        found, missing_cols = 0, []
        for col_info in unique_cols:
            col_name = col_info['column_name']
            snake_name = _to_snake(col_name).upper()
            if col_name.upper() in int_content or snake_name in int_content:
                found += 1
            else:
                missing_cols.append(col_name)
        if missing_cols:
            sample = missing_cols[:10]
            suffix = f' (and {len(missing_cols) - 10} more)' if len(missing_cols) > 10 else ''
            issues.append({'id': self._next_issue_id(), 'severity': 'medium', 'escalation_level': 'L2', 'category': 'missing_content', 'description': f'{len(missing_cols)} transformer columns not found in intermediate model: {", ".join(sample)}{suffix}', 'source_file': str(xml_path), 'output_file': str(int_file)})
        total = len(unique_cols)
        if found == total and total > 0:
            passed.append(f'All {total} transformer columns present in intermediate model')
        elif found > 0:
            passed.append(f'{found}/{total} transformer columns present')
        return issues, passed

    def _check_function_conversion(self, parsed, int_file, xml_path):
        issues, passed = [], []
        int_content = int_file.read_text(encoding='utf-8')
        ds_funcs_used: Set[str] = set()
        for t in parsed.get('transformations', []):
            deriv = t.get('derivation', '') or ''
            for ds_func in FUNCTION_MAP:
                if re.search(rf'\b{re.escape(ds_func)}\s*\(', deriv, re.IGNORECASE):
                    ds_funcs_used.add(ds_func)
        for sv in parsed.get('stage_variables', []):
            expr = sv.get('expression', '') or ''
            for ds_func in FUNCTION_MAP:
                if re.search(rf'\b{re.escape(ds_func)}\s*\(', expr, re.IGNORECASE):
                    ds_funcs_used.add(ds_func)
        unconverted = []
        for ds_func in ds_funcs_used:
            db_func = FUNCTION_MAP[ds_func]
            if '{0}' in db_func or db_func.endswith('()') or db_func in ('NULL',):
                continue
            if re.search(rf'\b{re.escape(ds_func)}\s*\(', int_content):
                unconverted.append(ds_func)
        if unconverted:
            issues.append({'id': self._next_issue_id(), 'severity': 'medium', 'escalation_level': 'L2', 'category': 'incorrect_mapping', 'description': f'Unconverted DataStage functions: {", ".join(unconverted)}', 'source_file': str(xml_path), 'output_file': str(int_file)})
        else:
            passed.append(f'All {len(ds_funcs_used)} DataStage functions correctly converted')
        return issues, passed

    def _check_audit_columns(self, mart_file, xml_path):
        issues, passed = [], []
        content = mart_file.read_text(encoding='utf-8').lower()
        missing = [col for col in AUDIT_COLUMNS if col not in content]
        if missing:
            issues.append({'id': self._next_issue_id(), 'severity': 'medium', 'escalation_level': 'L2', 'category': 'missing_content', 'description': f'Mart model missing audit columns: {", ".join(missing)}', 'source_file': str(xml_path), 'output_file': str(mart_file)})
        else:
            passed.append('Mart model includes all audit columns')
        return issues, passed

    def _check_naming_conventions(self, int_file, xml_path):
        issues, passed = [], []
        content = int_file.read_text(encoding='utf-8')
        alias_pattern = re.compile(r'\bAS\s+(\w+)', re.IGNORECASE)
        aliases = alias_pattern.findall(content)
        non_snake = []
        skip_words = {'SELECT', 'FROM', 'WHERE', 'JOIN', 'LEFT', 'INNER', 'STRING', 'INT', 'DATE', 'DECIMAL', 'BOOLEAN', 'FLOAT', 'TIMESTAMP', 'BIGINT', 'NULL'}
        for alias in aliases:
            if alias.upper() in skip_words:
                continue
            expected = _to_snake(alias)
            if alias != expected and alias != alias.lower():
                non_snake.append(alias)
        if non_snake:
            sample = non_snake[:5]
            issues.append({'id': self._next_issue_id(), 'severity': 'low', 'escalation_level': 'L1', 'category': 'naming_violation', 'description': f'{len(non_snake)} column aliases not in snake_case: {", ".join(sample)}', 'source_file': str(xml_path), 'output_file': str(int_file)})
        else:
            passed.append('All column aliases follow snake_case convention')
        return issues, passed

    # -------------------------------------------------------------------------
    # Go/No-Go Evaluation
    # -------------------------------------------------------------------------

    def _evaluate_go_no_go(
        self,
        issues: List[Dict],
        passed: List[str],
        build_metrics: Optional[Dict] = None,
    ) -> Dict[str, Any]:
        """Evaluate quality thresholds and produce go/no-go recommendation."""
        total_checks = len(issues) + len(passed)
        accuracy = (len(passed) / total_checks * 100) if total_checks > 0 else 100.0

        # Calculate individual metrics
        high_issues = [i for i in issues if i.get('severity') == 'high']
        join_issues = [i for i in issues if i.get('category') == 'join_issue']
        naming_issues = [i for i in issues if i.get('category') == 'naming_violation']
        audit_issues = [i for i in issues if 'audit' in i.get('description', '').lower()]

        # Get function conversion rate from build metrics if available
        func_rate = 100.0
        if build_metrics:
            bm = build_metrics.get('build_metrics', {}).get('summary', {})
            func_rate = bm.get('function_conversion_rate', 1.0) * 100

        # Calculate naming compliance
        naming_rate = 100.0
        if naming_issues:
            # Approximate from issue description
            naming_rate = 95.0  # Below threshold if issues exist

        # Calculate audit compliance
        audit_rate = 100.0 if not audit_issues else 0.0

        # Evaluate against thresholds
        thresholds = self._quality_thresholds
        results = {
            'source_coverage': {'threshold': 95.0, 'actual': accuracy, 'pass': accuracy >= 95.0},
            'func_conversion': {'threshold': 100.0, 'actual': round(func_rate, 1), 'pass': func_rate >= 100.0},
            'naming_compliance': {'threshold': 98.0, 'actual': round(naming_rate, 1), 'pass': naming_rate >= 98.0},
            'audit_presence': {'threshold': 100.0, 'actual': round(audit_rate, 1), 'pass': audit_rate >= 100.0},
        }

        # Determine recommendation
        all_pass = all(r['pass'] for r in results.values())
        conditional_pass = (
            accuracy >= 90.0
            and func_rate >= 95.0
            and audit_rate >= 100.0
        )

        if all_pass:
            recommendation = 'GO'
            reason = 'All quality thresholds met.'
        elif conditional_pass:
            recommendation = 'CONDITIONAL GO'
            failed = [k for k, v in results.items() if not v['pass']]
            reason = f'Core thresholds met. Minor gaps in: {", ".join(failed)}'
        else:
            recommendation = 'NO-GO'
            failed = [k for k, v in results.items() if not v['pass']]
            reason = f'Thresholds not met: {", ".join(failed)}. Refinement required.'

        return {
            'thresholds': results,
            'recommendation': recommendation,
            'reason': reason,
        }

    # -------------------------------------------------------------------------
    # Report generation
    # -------------------------------------------------------------------------

    def generate_report(self, issues, passed_checks, run_id=None, build_metrics=None):
        """Generate a structured validation report with go/no-go recommendation."""
        total_checks = len(issues) + len(passed_checks)
        accuracy = (len(passed_checks) / total_checks * 100) if total_checks > 0 else 100.0

        go_no_go = self._evaluate_go_no_go(issues, passed_checks, build_metrics)

        report = {
            'validation_report': {
                'timestamp': get_timestamp(),
                'run_id': run_id or datetime.now().strftime('run_%Y-%m-%d_%H%M%S'),
                'overall_accuracy': round(accuracy, 1),
                'summary': {
                    'total_checks': total_checks,
                    'passed': len(passed_checks),
                    'issues_found': len(issues),
                    'high_severity': len([i for i in issues if i.get('severity') == 'high']),
                    'medium_severity': len([i for i in issues if i.get('severity') == 'medium']),
                    'low_severity': len([i for i in issues if i.get('severity') == 'low']),
                },
                'go_no_go': go_no_go,
                'issues': issues,
                'passed_checks': passed_checks,
            }
        }
        return report

    def save_report(self, report, run_id=None):
        """Save the validation report to the agentic log directory."""
        raw_rid = run_id or report['validation_report'].get('run_id', '')
        rid = re.sub(r'[^a-zA-Z0-9_\-]', '_', raw_rid) if raw_rid else datetime.now().strftime('run_%Y-%m-%d_%H%M%S')
        run_dir = self.report_dir / rid
        run_dir.mkdir(parents=True, exist_ok=True)
        report_path = run_dir / 'iteration_0_validation.yaml'
        save_yaml(report, report_path)
        self.logger.info(f'Validation report saved: {report_path}')
        return report_path

    # -------------------------------------------------------------------------
    # Full run
    # -------------------------------------------------------------------------

    def run(self, job_name=None):
        """Run validation and save report. Returns (report_dict, report_path)."""
        run_id = datetime.now().strftime('run_%Y-%m-%d_%H%M%S')
        self.issue_counter = 0

        # Load build metrics if available
        build_metrics_path = get_project_root() / 'thoughts' / 'build_metrics.yaml'
        build_metrics = load_yaml(build_metrics_path) if build_metrics_path.exists() else None

        if job_name:
            issues, passed = self.validate_job(job_name)
        else:
            issues = []
            passed = []
            for xml_file in self.parser.discover_files():
                self.issue_counter = 0
                job_issues, job_passed = self._validate_job(xml_file)
                issues.extend(job_issues)
                passed.extend(job_passed)

        report = self.generate_report(issues, passed, run_id, build_metrics)
        report_path = self.save_report(report, run_id)

        # Print summary
        summary = report['validation_report']['summary']
        accuracy = report['validation_report']['overall_accuracy']
        go_no_go = report['validation_report']['go_no_go']
        self.logger.info(
            f"Validation complete: {accuracy}% accuracy, "
            f"{summary['issues_found']} issues, "
            f"{summary['passed']} passed checks"
        )
        self.logger.info(f"Go/No-Go: {go_no_go['recommendation']} — {go_no_go['reason']}")

        return report, report_path


# =============================================================================
# CLI
# =============================================================================

def main():
    """CLI entry point for the validator."""
    arg_parser = argparse.ArgumentParser(
        description='Validate dbt models against DataStage XML sources'
    )
    arg_parser.add_argument('--job', type=str, default=None, help='Validate a specific job')
    arg_parser.add_argument('--report-dir', type=str, default=None, help='Custom report directory')
    arg_parser.add_argument('--input-dir', type=str, default='inputs', help='Input directory')
    arg_parser.add_argument('--output-dir', type=str, default='output', help='Output directory')
    args = arg_parser.parse_args()

    validator = DbtOutputValidator(
        input_dir=args.input_dir,
        output_dir=args.output_dir,
        report_dir=args.report_dir,
    )

    report, report_path = validator.run(job_name=args.job)
    print(f'\nReport saved to: {report_path}')

    high_count = report['validation_report']['summary']['high_severity']
    sys.exit(1 if high_count > 0 else 0)


if __name__ == '__main__':
    main()
