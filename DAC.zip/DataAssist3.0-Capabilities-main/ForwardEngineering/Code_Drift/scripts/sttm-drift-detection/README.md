# STTM Drift Detection Framework

Automated validation framework that compares Source-to-Target Mapping (STTM) Excel documents against ETL code to detect where the implementation deviates from the specification.

## What It Does

- Parses STTM Excel files and ETL code side-by-side
- Compares every column mapping — direct pulls, lookups, derivations, date conversions, hardcoded values
- Supports 7 ETL technologies: PySpark, DBT SQL, AWS Glue, ADF, Synapse, Databricks SQL, Scala Spark
- Handles project-specific STTM header naming conventions via fuzzy keyword matching
- Runs compliance checks: security vulnerabilities, PII governance, code standards, performance anti-patterns, CI/CD gates
- Generates structured Excel drift reports with Summary, Matched Columns, and Drifted Columns tabs
- Generates updated JSON configs / code files with missing columns added

## Execution Modes

| Mode | Description |
|------|-------------|
| **Standalone** | Fully deterministic, rule-based comparison using 148+ transformation rules. No external dependencies. |
| **Agentic** | LLM-enhanced review (Claude) on top of deterministic baseline. Catches nuanced mismatches. All overrides are auditable. |

## Setup

```bash
cd scripts/sttm-drift-detection
pip install -r requirements.txt
```

**Required:** `openpyxl`, `pyyaml`
**Optional:** `boto3` (for S3 input/output), `anthropic` (for agentic mode)

## Usage

All commands are accessed through `cli.py`.

### Drift Detection

```bash
# Basic — PySpark code against STTM
python cli.py detect-drift \
    --sttm ../../knowledgebase/STTM.xlsx \
    --code ../../knowledgebase/SALESIQ_REF_VAL.py

# With output directory and standalone mode
python cli.py detect-drift \
    --sttm ../../knowledgebase/STTM.xlsx \
    --code ../../knowledgebase/SALESIQ_REF_VAL.py \
    --output-dir ../../output/salesiq_ref_val \
    --execution-mode standalone

# Glue job with JSON config
python cli.py detect-drift \
    --sttm ../../knowledgebase/Terr_STTM.xlsx \
    --code ../../knowledgebase/glue_terr_job.py \
    --json-config ../../knowledgebase/Terr.json \
    --technology glue

# DBT SQL
python cli.py detect-drift \
    --sttm ../../knowledgebase/STTM.xlsx \
    --code ../../knowledgebase/my_model.sql \
    --technology dbt

# S3 inputs/outputs (AWS EC2)
python cli.py detect-drift \
    --sttm s3://my-bucket/sttm/STTM.xlsx \
    --code s3://my-bucket/code/etl_job.py \
    --s3-output s3://my-bucket/drift-results/

# With compliance checks
python cli.py detect-drift \
    --sttm ../../knowledgebase/STTM.xlsx \
    --code ../../knowledgebase/SALESIQ_REF_VAL.py \
    --checks all
```

### CLI Options Reference

| Option | Default | Description |
|--------|---------|-------------|
| `--sttm` | *(required)* | Path to STTM Excel file (.xlsx) |
| `--code` | *(required)* | Path to ETL code file (.py, .sql, .json, .scala) |
| `--sheet` | `STTM` | Excel sheet name with mappings |
| `--output-dir` | `output/` | Local output directory |
| `--target-table` | auto-detect | Override target table name |
| `--mode` | `auto` | `auto` or `standard` |
| `--config` | auto-resolve | Path to transform_config.yaml |
| `--json-config` | auto-detect | JSON config with SQL queries |
| `--execution-mode` | `auto` | `standalone`, `agentic`, or `auto` |
| `--checks` | `sttm_only` | `sttm_only`, `all`, or comma-separated modules |
| `--technology` | `auto` | `pyspark`, `dbt`, `adf`, `synapse`, `databricks_sql`, `glue`, `scala_spark` |
| `--s3-output` | none | S3 URI for uploading results |
| `--repo-root` | auto-detect | Repo root for CI/CD scanning |

## Outputs

| File | Description |
|------|-------------|
| `drift_report.xlsx` | Structured Excel report with Summary, Matched, and Drifted tabs |
| `drift_report.yaml` | Machine-readable YAML report |
| `updated_<config>.json` | Updated JSON config with missing columns added (when JSON config is used) |
| `updated_<code>.py` | Updated code file with missing transformations (when applicable) |

## Files in This Directory

| File | Purpose |
|------|---------|
| `cli.py` | Unified CLI entry point |
| `detect_drift.py` | Core drift detection engine |
| `transform_config.yaml` | Transformation rules, equivalence pairs, compliance checks |
| `requirements.txt` | Python dependencies |

## Assumptions and Limitations

- STTM Excel must have identifiable column headers (target column, source column, transformation rule). The framework handles common naming variants via fuzzy matching.
- Audit columns (CRTD_DT, MDFD_DT, EFF_FROM_DT, SRC_EFF_TO_DT, BTCH_ID, etc.) are checked for presence only — transformation logic is not validated since it varies by use case.
- Agentic mode requires an Anthropic API key set in the environment (`ANTHROPIC_API_KEY`).
- S3 integration requires `boto3` and valid AWS credentials configured on the machine.
- The framework assumes one target table per STTM sheet.
