#!/usr/bin/env python3
"""
STTM Drift Detection Framework — Unified CLI Entry Point

Provides a single command-line interface for STTM drift detection.

Usage:
    python cli.py detect-drift --sttm <path> --code <path> [options]
    python cli.py --help
"""

import argparse
import os
import sys
from pathlib import Path


def _resolve(path: str) -> str:
    """Resolve a local path to absolute. Leave S3 URIs unchanged."""
    if not path or path.startswith("s3://"):
        return path
    return str(Path(path).resolve())


def cmd_detect_drift(args):
    """Run STTM drift detection by delegating to detect_drift.main()."""
    # Build sys.argv for detect_drift's own argparse
    argv = ["detect_drift.py"]
    argv += ["--sttm", _resolve(args.sttm)]
    argv += ["--pyspark", _resolve(args.code)]

    if args.sheet:
        argv += ["--sheet", args.sheet]
    if args.output_dir:
        argv += ["--output-dir", _resolve(args.output_dir)]
    if args.target_table:
        argv += ["--target-table", args.target_table]
    if args.mode:
        argv += ["--mode", args.mode]
    if args.config:
        argv += ["--config", _resolve(args.config)]
    if args.json_config:
        argv += ["--json-config", _resolve(args.json_config)]
    if args.execution_mode:
        argv += ["--execution-mode", args.execution_mode]
    if args.checks:
        argv += ["--checks", args.checks]
    if args.repo_root:
        argv += ["--repo-root", _resolve(args.repo_root)]
    if args.technology:
        argv += ["--technology", args.technology]
    if args.s3_output:
        argv += ["--s3-output", args.s3_output]

    # Ensure detect_drift.py's directory is on the Python path
    script_dir = str(Path(__file__).resolve().parent)
    if script_dir not in sys.path:
        sys.path.insert(0, script_dir)

    # Patch sys.argv so detect_drift's argparse picks up the args
    original_argv = sys.argv
    sys.argv = argv
    try:
        from detect_drift import main as drift_main
        drift_main()
    finally:
        sys.argv = original_argv


def build_parser():
    parser = argparse.ArgumentParser(
        prog="cli.py",
        description="STTM Drift Detection Framework — Unified CLI",
    )
    subparsers = parser.add_subparsers(dest="command", help="Available commands")

    # ---- detect-drift ----
    drift = subparsers.add_parser(
        "detect-drift",
        help="Run STTM vs ETL code drift detection",
        description="Compare an STTM Excel document against ETL code and generate a drift report.",
    )
    drift.add_argument(
        "--sttm", required=True,
        help="Path to the STTM Excel file (.xlsx). Supports S3 URIs.",
    )
    drift.add_argument(
        "--code", required=True,
        help="Path to the ETL code file (.py, .sql, .json, .scala). Supports S3 URIs.",
    )
    drift.add_argument(
        "--sheet", default="STTM",
        help="Sheet name containing the mappings (default: STTM)",
    )
    drift.add_argument(
        "--output-dir", default="output/",
        help="Local output directory (default: output/)",
    )
    drift.add_argument(
        "--target-table", default=None,
        help="Override target table name (auto-detected from STTM)",
    )
    drift.add_argument(
        "--mode", choices=["auto", "standard"], default="auto",
        help="Detection mode: 'auto' or 'standard' (default: auto)",
    )
    drift.add_argument(
        "--config", default=None,
        help="Path to transform_config.yaml (auto-resolved if not specified)",
    )
    drift.add_argument(
        "--json-config", default=None,
        help="Path to JSON config file with SQL transformation queries",
    )
    drift.add_argument(
        "--execution-mode", choices=["auto", "standalone", "agentic"], default="auto",
        help="Execution mode: 'standalone', 'agentic', or 'auto' (default: auto)",
    )
    drift.add_argument(
        "--checks", default="sttm_only",
        help="Compliance checks: 'sttm_only', 'all', or comma-separated module names",
    )
    drift.add_argument(
        "--repo-root", default=None,
        help="Repository root for CI/CD pipeline scanning",
    )
    drift.add_argument(
        "--technology", default="auto",
        choices=["auto", "pyspark", "dbt", "adf", "synapse", "databricks_sql", "glue", "scala_spark"],
        help="ETL technology (default: auto-detect)",
    )
    drift.add_argument(
        "--s3-output", default=None,
        help="S3 URI for uploading outputs (e.g. s3://my-bucket/output/)",
    )
    drift.set_defaults(func=cmd_detect_drift)

    return parser


def main():
    parser = build_parser()
    args = parser.parse_args()

    if not args.command:
        parser.print_help()
        sys.exit(1)

    args.func(args)


if __name__ == "__main__":
    main()
