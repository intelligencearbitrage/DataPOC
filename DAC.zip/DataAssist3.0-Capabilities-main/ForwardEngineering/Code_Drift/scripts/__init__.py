"""
Toolkit Template - Scripts Package

This package contains:
- base_parser.py    : Abstract base class for input parsers
- base_generator.py : Abstract base class for output generators
- base_validator.py : Abstract base class for output validators
- utils.py          : Shared utility functions
- build_all.py      : Master script that runs all generators
"""
