#!/usr/bin/env python3
"""
STTM-PySpark Drift Detection Framework

Compares any STTM (Source-to-Target Mapping) Excel document against its
corresponding PySpark ETL job to identify where the code deviates from the spec.

The STTM is the single source of truth. For every mapping defined in the STTM,
the script checks whether the PySpark code implements it correctly.

Supports two modes (auto-detected):
  - Framework mode (e.g. CodETL): columns mapped dynamically via config are
    treated as matches; only explicit code deviations are flagged.
  - Standard mode: every STTM mapping must have an explicit .withColumn /
    .withColumnRenamed in the PySpark code.

All framework-specific knowledge, transformation categories, and PySpark
patterns are loaded from transform_config.yaml — no code changes needed
to support new frameworks or transformation types.

Usage:
    python scripts/detect_drift.py \\
        --sttm knowledgebase/STTM.xlsx \\
        --pyspark knowledgebase/SALESIQ_REF_VAL.py

    python scripts/detect_drift.py \\
        --sttm knowledgebase/STTM.xlsx \\
        --pyspark knowledgebase/SALESIQ_REF_VAL.py \\
        --output-dir output/ \\
        --sheet STTM

    # Force standard mode (skip framework auto-detection)
    python scripts/detect_drift.py \\
        --sttm inputs/MY_TABLE_STTM.xlsx \\
        --pyspark inputs/my_table_etl.py \\
        --mode standard

    # PySpark job that reads from a JSON config (auto-detected)
    python scripts/detect_drift.py \\
        --sttm knowledgebase/Policy_STTM.xlsx \\
        --pyspark knowledgebase/Plcy_updated_pyspark.py

    # Explicit JSON config path
    python scripts/detect_drift.py \\
        --sttm knowledgebase/Policy_STTM.xlsx \\
        --pyspark knowledgebase/Plcy_updated_pyspark.py \\
        --json-config knowledgebase/PLCY.json

    # S3 inputs (AWS EC2) — reads from S3, writes output to S3
    python scripts/detect_drift.py \\
        --sttm s3://my-input-bucket/sttm/STTM.xlsx \\
        --pyspark s3://my-input-bucket/code/my_etl.py \\
        --config s3://my-input-bucket/config/transform_config.yaml \\
        --s3-output s3://my-output-bucket/drift-results/
"""

import argparse
import json
import logging
import re
import sys
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional, Set, Tuple

import os
import tempfile

import openpyxl
import yaml


# ---------------------------------------------------------------------------
# S3 Helpers (boto3 imported lazily — no error if not installed)
# ---------------------------------------------------------------------------

def _is_s3_path(path: str) -> bool:
    """Return True if *path* looks like an S3 URI (s3://bucket/key)."""
    return path.startswith("s3://") if path else False


def _parse_s3_uri(uri: str) -> Tuple[str, str]:
    """Split 's3://bucket/key/path' → ('bucket', 'key/path')."""
    without_scheme = uri[5:]  # strip "s3://"
    bucket, _, key = without_scheme.partition("/")
    return bucket, key


def _s3_download(s3_uri: str, local_dir: Optional[str] = None) -> str:
    """Download an S3 object to a local temp file and return the local path.

    If *local_dir* is given the file is placed there (preserving the basename);
    otherwise a new tempfile is created.
    """
    try:
        import boto3
    except ImportError:
        raise RuntimeError(
            "boto3 is required for S3 support. Install it with: pip install boto3"
        )

    bucket, key = _parse_s3_uri(s3_uri)
    basename = key.rsplit("/", 1)[-1] if "/" in key else key

    if local_dir:
        os.makedirs(local_dir, exist_ok=True)
        local_path = os.path.join(local_dir, basename)
    else:
        suffix = "." + basename.rsplit(".", 1)[-1] if "." in basename else ""
        fd, local_path = tempfile.mkstemp(suffix=suffix, prefix="drift_")
        os.close(fd)

    s3 = boto3.client("s3")
    logger_name = logging.getLogger(__name__)
    logger_name.info(f"Downloading s3://{bucket}/{key} → {local_path}")
    s3.download_file(bucket, key, local_path)
    return local_path


def _s3_upload(local_path: str, s3_uri: str) -> None:
    """Upload a local file to an S3 location."""
    try:
        import boto3
    except ImportError:
        raise RuntimeError(
            "boto3 is required for S3 support. Install it with: pip install boto3"
        )

    bucket, key = _parse_s3_uri(s3_uri)
    s3 = boto3.client("s3")
    logger_name = logging.getLogger(__name__)
    logger_name.info(f"Uploading {local_path} → s3://{bucket}/{key}")
    s3.upload_file(local_path, bucket, key)


def _s3_upload_directory(local_dir: str, s3_base_uri: str) -> None:
    """Upload all files in a local directory to S3, preserving relative paths."""
    try:
        import boto3
    except ImportError:
        raise RuntimeError(
            "boto3 is required for S3 support. Install it with: pip install boto3"
        )

    bucket, base_key = _parse_s3_uri(s3_base_uri)
    # Ensure base_key ends with /
    if base_key and not base_key.endswith("/"):
        base_key += "/"

    s3 = boto3.client("s3")
    logger_name = logging.getLogger(__name__)

    for root, _dirs, files in os.walk(local_dir):
        for fname in files:
            local_path = os.path.join(root, fname)
            rel_path = os.path.relpath(local_path, local_dir)
            s3_key = base_key + rel_path.replace(os.sep, "/")
            logger_name.info(f"Uploading {local_path} → s3://{bucket}/{s3_key}")
            s3.upload_file(local_path, bucket, s3_key)


# ---------------------------------------------------------------------------
# Logging
# ---------------------------------------------------------------------------

def setup_logging(name: str = "detect_drift") -> logging.Logger:
    logger = logging.getLogger(name)
    if not logger.handlers:
        logger.setLevel(logging.INFO)
        handler = logging.StreamHandler(sys.stdout)
        handler.setFormatter(logging.Formatter(
            "%(asctime)s | %(name)s | %(levelname)s | %(message)s",
            datefmt="%Y-%m-%d %H:%M:%S",
        ))
        logger.addHandler(handler)
    return logger


logger = setup_logging()


# ---------------------------------------------------------------------------
# Configuration Loader
# ---------------------------------------------------------------------------

class DriftConfig:
    """Holds all externalized configuration loaded from transform_config.yaml."""

    def __init__(self):
        self.frameworks: Dict[str, Dict] = {}
        self.sttm_categories: Dict[str, str] = {}
        self.pyspark_patterns: Dict[str, str] = {}
        self.equivalent_categories: Set[Tuple[str, str]] = set()
        self.llm_config: Dict[str, Any] = {}
        self.compliance_checks: Dict[str, Any] = {}
        # Active framework state (set after detection)
        self.active_framework: Optional[str] = None
        self.framework_contexts: Set[str] = set()
        self.framework_class_prefixes: Set[str] = set()

    @classmethod
    def load(cls, config_path: str) -> "DriftConfig":
        """Load config from YAML file."""
        cfg = cls()
        path = Path(config_path)
        if not path.exists():
            logger.warning(f"Config file not found at {config_path} — using built-in defaults")
            cfg._load_defaults()
            return cfg

        with open(path, "r", encoding="utf-8") as f:
            raw = yaml.safe_load(f)

        cfg.frameworks = raw.get("frameworks", {})
        cfg.sttm_categories = raw.get("sttm_categories", {})
        cfg.pyspark_patterns = raw.get("pyspark_patterns", {})

        for pair in raw.get("equivalent_categories", []):
            if len(pair) == 2:
                cfg.equivalent_categories.add((pair[0], pair[1]))

        cfg.llm_config = raw.get("llm_config", {})
        cfg.compliance_checks = raw.get("compliance_checks", {})

        # Count compliance rules
        compliance_count = 0
        for module_cfg in cfg.compliance_checks.values():
            if isinstance(module_cfg, dict):
                compliance_count += len(module_cfg.get("rules", []))
                compliance_count += len(module_cfg.get("pii_column_patterns", []))

        logger.info(f"Loaded config: {len(cfg.sttm_categories)} STTM categories, "
                     f"{len(cfg.pyspark_patterns)} PySpark patterns, "
                     f"{len(cfg.frameworks)} framework(s), "
                     f"{compliance_count} compliance rules")
        return cfg

    def _load_defaults(self):
        """Fallback defaults if no config file is found."""
        self.sttm_categories = {
            "direct pull": "DIRECT_PULL",
            "sequence generated id": "SEQUENCE_ID",
            "current date": "CURRENT_DATE",
            "custom/default": "LITERAL",
            "etl audit field": "ETL_AUDIT",
            "convert date format": "DATE_CONVERT",
            "lookup": "LOOKUP",
            "trim": "TRIM",
            "count": "COUNT",
            "md5": "MD5_HASH",
        }
        self.pyspark_patterns = {
            r"F\.lit\(": "LITERAL",
            r"F\.current_date\(\)|crtd_dt\(\)": "CURRENT_DATE",
            r"F\.monotonically_increasing_id\(\)": "SEQUENCE_ID",
            r"F\.md5\(": "MD5_HASH",
            r"withColumnRenamed|\.alias\(": "DIRECT_PULL",
            r"F\.to_date\(|custom_to_date\(": "DATE_CONVERT",
            r"F\.trim\(": "TRIM",
            r"F\.when\(": "CASE_WHEN",
        }

    def detect_framework(self, pyspark_code: str) -> Optional[str]:
        """Auto-detect which framework (if any) the PySpark job uses.

        Scans the code against each framework's detection_signatures.
        Returns the framework name or None (standard mode).
        """
        for fw_name, fw_config in self.frameworks.items():
            signatures = fw_config.get("detection_signatures", [])
            for sig in signatures:
                if re.search(sig, pyspark_code):
                    return fw_name
        return None

    def activate_framework(self, fw_name: Optional[str]):
        """Set the active framework and load its contexts/prefixes."""
        self.active_framework = fw_name
        self.framework_contexts = set()
        self.framework_class_prefixes = set()

        if fw_name and fw_name in self.frameworks:
            fw = self.frameworks[fw_name]
            self.framework_contexts = set(fw.get("framework_contexts", []))
            self.framework_class_prefixes = set(fw.get("framework_class_prefixes", []))

    @property
    def is_framework_mode(self) -> bool:
        return self.active_framework is not None


# Global config — initialized in main()
config = DriftConfig()


# ---------------------------------------------------------------------------
# LLM Provider (Agentic Mode)
# ---------------------------------------------------------------------------

_LLM_REVIEW_PROMPT = """\
You are a data engineering expert comparing STTM (Source-to-Target Mapping) specifications against PySpark ETL code implementations.

## STTM Specification (Source of Truth)
- Target Column: {target_column}
- Source Column: {source_column}
- Transformation: {transformation}
- Transformation Rule: {transformation_rule}

## PySpark Implementation
- Source Reference: {source_reference}
- Code: {transformation_code}
- Canonical Form: {canonical_form}

## Baseline Verdict (from deterministic rules)
- Status: {baseline_status}
- Severity: {baseline_severity}
- Explanation: {baseline_explanation}

## Your Task
Review whether the PySpark implementation correctly implements the STTM specification.
Consider semantic equivalence — different syntax can represent the same logic.

Key rules:
- STTM is the single source of truth
- "Field not applicable" means the column is NOT required — always MATCH
- Name aliases (NVL=COALESCE, crtd_dt=current_date) are acceptable variations
- Framework utility code filtered out is expected behavior
- Column renames (source != target name) with Direct Pull are valid

Respond with ONLY a JSON object (no markdown, no extra text):
{{"status": "MATCH" or "DRIFT", "severity": "CRITICAL|HIGH|MEDIUM|LOW|INFO", "override": true or false, "reasoning": "brief explanation of your analysis", "explanation": "human-readable verdict"}}
"""


class LLMProvider:
    """Abstraction over LLM providers for agentic mode.

    Supports Anthropic (Claude) and OpenAI-compatible providers.
    Imports are lazy — no errors if SDKs are not installed.
    """

    def __init__(self, provider: str, model: str, api_key: str, **kwargs):
        self.provider = provider
        self.model = model
        self.api_key = api_key
        self.base_url = kwargs.get("base_url")
        self.temperature = kwargs.get("temperature", 0.0)
        self.max_tokens = kwargs.get("max_tokens", 1024)
        self.timeout = kwargs.get("timeout", 30)
        self._client = None

    @classmethod
    def from_config(cls, llm_config: Dict) -> Optional["LLMProvider"]:
        """Create provider from config dict. Returns None if not available."""
        if not llm_config:
            return None

        provider = llm_config.get("provider", "anthropic")
        model = llm_config.get("model", "claude-sonnet-4-20250514")
        api_key_env = llm_config.get("api_key_env", "ANTHROPIC_API_KEY")
        api_key = os.environ.get(api_key_env, "")

        if not api_key:
            logger.info(f"LLM provider '{provider}': no API key found in ${api_key_env}")
            return None

        # Check if the required SDK is installed
        if provider == "anthropic":
            try:
                import anthropic  # noqa: F401
            except ImportError:
                logger.info("Anthropic SDK not installed. Install with: pip install anthropic")
                return None
        elif provider in ("openai", "openai_compatible"):
            try:
                import openai  # noqa: F401
            except ImportError:
                logger.info("OpenAI SDK not installed. Install with: pip install openai")
                return None
        else:
            logger.warning(f"Unknown LLM provider: {provider}")
            return None

        return cls(
            provider=provider,
            model=model,
            api_key=api_key,
            base_url=llm_config.get("base_url"),
            temperature=llm_config.get("temperature", 0.0),
            max_tokens=llm_config.get("max_tokens", 1024),
            timeout=llm_config.get("timeout", 30),
        )

    def _get_client(self):
        """Lazily initialize the API client."""
        if self._client is not None:
            return self._client

        if self.provider == "anthropic":
            import anthropic
            self._client = anthropic.Anthropic(api_key=self.api_key)
        elif self.provider in ("openai", "openai_compatible"):
            import openai
            kwargs = {"api_key": self.api_key}
            if self.base_url:
                kwargs["base_url"] = self.base_url
            self._client = openai.OpenAI(**kwargs)

        return self._client

    def review_comparison(
        self,
        target_column: str,
        sttm_info: Dict[str, Any],
        pyspark_info: Dict[str, Any],
        baseline_result: Dict[str, Any],
    ) -> Dict[str, Any]:
        """Ask LLM to review a single STTM<->PySpark comparison.

        Returns dict with: status, severity, override, reasoning, explanation.
        On failure, returns a fallback dict that preserves the baseline.
        """
        prompt = _LLM_REVIEW_PROMPT.format(
            target_column=target_column,
            source_column=sttm_info.get("source_column", ""),
            transformation=sttm_info.get("transformation", ""),
            transformation_rule=sttm_info.get("transformation_rule", ""),
            source_reference=pyspark_info.get("source_reference", ""),
            transformation_code=pyspark_info.get("transformation_code", ""),
            canonical_form=pyspark_info.get("canonical_form", ""),
            baseline_status=baseline_result.get("status", ""),
            baseline_severity=baseline_result.get("severity", ""),
            baseline_explanation=baseline_result.get("explanation", ""),
        )

        try:
            response_text = self._call_llm(prompt)
            return self._parse_llm_response(response_text)
        except Exception as e:
            logger.warning(f"LLM review failed for '{target_column}': {e}")
            return {
                "status": baseline_result.get("status", "MATCH"),
                "severity": baseline_result.get("severity", "INFO"),
                "override": False,
                "reasoning": f"LLM call failed: {e}",
                "explanation": baseline_result.get("explanation", ""),
                "fallback": True,
            }

    def _call_llm(self, prompt: str) -> str:
        """Call the LLM and return the raw response text."""
        client = self._get_client()

        if self.provider == "anthropic":
            response = client.messages.create(
                model=self.model,
                max_tokens=self.max_tokens,
                temperature=self.temperature,
                messages=[{"role": "user", "content": prompt}],
            )
            return response.content[0].text

        elif self.provider in ("openai", "openai_compatible"):
            response = client.chat.completions.create(
                model=self.model,
                max_tokens=self.max_tokens,
                temperature=self.temperature,
                messages=[{"role": "user", "content": prompt}],
            )
            return response.choices[0].message.content

        raise ValueError(f"Unsupported provider: {self.provider}")

    def _parse_llm_response(self, response_text: str) -> Dict[str, Any]:
        """Parse JSON from LLM response, handling markdown code blocks."""
        text = response_text.strip()
        # Strip markdown code fences if present
        if text.startswith("```"):
            lines = text.split("\n")
            lines = [l for l in lines if not l.strip().startswith("```")]
            text = "\n".join(lines).strip()

        parsed = json.loads(text)

        # Validate required fields
        status = parsed.get("status", "MATCH")
        if status not in ("MATCH", "DRIFT"):
            status = "MATCH"

        severity = parsed.get("severity", "INFO")
        valid_severities = {"CRITICAL", "HIGH", "MEDIUM", "LOW", "INFO"}
        if severity not in valid_severities:
            severity = "INFO"

        return {
            "status": status,
            "severity": severity,
            "override": bool(parsed.get("override", False)),
            "reasoning": str(parsed.get("reasoning", "")),
            "explanation": str(parsed.get("explanation", "")),
        }


# ---------------------------------------------------------------------------
# 1. STTM Parser
# ---------------------------------------------------------------------------

HEADER_ALIASES = {
    "ver": ["ver", "version"],
    "source": ["source", "source_table", "source_table_name",
               "stage_file_name", "stage_file", "source_file_name",
               "source_entity", "source_system"],
    "source_column": ["source_column", "source_col", "source_column_name",
                      "source_attribute", "source_field", "source_field_name",
                      "stage_file_attribute_name", "stage_attribute_name",
                      "stage_column", "stage_field",
                      "source_attribute_name", "source_col_name"],
    "source_data_type": ["source_data_type", "source_datatype", "source_column_type",
                         "source_attribute_data_type", "stage_data_type"],
    "source_nullability": ["source_nullability", "source_nullable"],
    "transformation": ["transformation", "transform", "transformation_type"],
    "transformation_rule": [
        "transformation_rule", "transform_rule",
        "source_transformational_rule/logic",
        "source_transformational_rule_logic",
        "transformational_rule",
        "transformation_logic", "transform_logic", "rule/logic", "rule_logic",
        "transformation_rules", "transform_rules",
        "transformational_rules", "rule", "rules",
        "mapping_rule", "mapping_logic", "etl_rule", "etl_logic",
        "business_rule", "conversion_rule", "conversion_logic",
    ],
    "target": ["target", "target_table", "target_table_name",
               "ods_table_physical_name", "ods_table", "ods_physical_name",
               "target_entity", "target_entity_name",
               "destination_table", "dest_table",
               "edw_table", "edw_table_name", "edw_physical_name",
               "dwh_table", "dwh_table_name"],
    "target_column": ["target_column", "target_col", "target_col_name", "target_col_name_",
                       "target_column_name", "target_attribute", "target_field",
                       "target_attribute_name", "target_field_name",
                       "ods_attribute_physical_name", "ods_attribute", "ods_physical_col",
                       "ods_column", "ods_field", "ods_col_name",
                       "edw_column", "edw_col", "edw_attribute", "edw_field",
                       "dwh_column", "dwh_col", "dwh_attribute",
                       "destination_column", "dest_column", "dest_col"],
    "target_logical_name": ["target_logical_name", "target_attribute_logical_name",
                            "ods_attribute_logical_name", "ods_logical_name",
                            "edw_logical_name", "business_name"],
    "nk": ["nk", "natural_key", "primary_key", "pk/nk", "pk_nk", "pk",
            "key_type", "key_indicator"],
    "target_data_type": ["target_data_type", "target_datatype",
                         "ods_attribute_data_type", "ods_data_type", "ods_datatype",
                         "edw_data_type", "edw_datatype",
                         "data_type", "datatype", "column_type"],
    "target_length": ["target_length", "length", "column_length"],
    "target_scale": ["target_scale", "scale", "column_scale"],
    "target_nullability": ["target_nullability", "nullability", "nullable",
                           "null_indicator", "not_null", "null_allowed"],
    "dq_category": ["dqcategory", "dq_category"],
    "dq_subcategory": ["dqsubcategory", "dq_subcategory", "dq_sub_category"],
    "notes": ["notes", "note", "comments", "observation", "pending_questions/queries",
              "pending_questions_queries", "remarks"],
    "business_definition": ["business_definition", "business_desc", "description",
                            "ods_table_logical_name", "logical_name"],
    "subject_area": ["subject_area"],
    "source_bucket": ["source_bucket", "stage_s3_bucket_name", "s3_bucket",
                      "source_s3_bucket", "source_path"],
}

# Keywords used for fuzzy header matching when exact alias lookup fails.
# Each canonical name maps to a set of keywords — if ALL keywords in a set
# appear in the normalized header, it's a match. Multiple keyword-sets are
# tried (OR logic across sets, AND logic within a set).
_HEADER_KEYWORD_RULES: Dict[str, List[Set[str]]] = {
    "source_column": [{"source", "attribute"}, {"source", "field"}, {"stage", "attribute"},
                      {"source", "col"}, {"stage", "col"}, {"stage", "field"}],
    "target_column": [{"target", "attribute", "physical"}, {"target", "col"},
                      {"ods", "attribute", "physical"}, {"ods", "col"},
                      {"edw", "attribute"}, {"edw", "col"}, {"dwh", "col"},
                      {"dest", "col"}, {"target", "field"}],
    "target": [{"target", "table"}, {"ods", "table", "physical"}, {"ods", "physical"},
               {"edw", "table"}, {"dwh", "table"}, {"dest", "table"}],
    "transformation_rule": [{"transformation"}, {"transform", "rule"}, {"transform", "logic"},
                            {"mapping", "rule"}, {"etl", "rule"}, {"business", "rule"},
                            {"conversion", "rule"}],
    "target_data_type": [{"target", "data", "type"}, {"ods", "data", "type"},
                         {"edw", "data", "type"}, {"data", "type"}],
    "nk": [{"pk", "nk"}, {"primary", "key"}, {"natural", "key"}, {"key", "type"}],
    "target_nullability": [{"nullab"}, {"null", "indicator"}, {"not", "null"}],
    "source": [{"source", "table"}, {"stage", "file"}, {"source", "file"},
               {"source", "entity"}],
    "business_definition": [{"logical", "name"}, {"business", "definition"},
                            {"business", "desc"}],
    "source_bucket": [{"s3", "bucket"}, {"source", "bucket"}, {"stage", "bucket"}],
}


def _resolve_header(raw_header: str) -> Optional[str]:
    """Map a raw Excel header to our canonical name.

    1. Exact alias match (after normalizing spaces → _ , / → _)
    2. Fuzzy keyword match using _HEADER_KEYWORD_RULES
    """
    normalized = raw_header.strip().lower().replace(" ", "_")
    # Also handle slash variants: "rule/logic" -> "rule_logic"
    normalized_slash = normalized.replace("/", "_")
    # Handle non-breaking spaces and other unicode whitespace
    normalized = normalized.replace("\xa0", "_")
    normalized_slash = normalized_slash.replace("\xa0", "_")

    # --- Pass 1: exact alias lookup ---
    for canonical, aliases in HEADER_ALIASES.items():
        if normalized in aliases or normalized_slash in aliases:
            return canonical

    # --- Pass 2: fuzzy keyword match ---
    # Tokenize the header into words
    header_words = set(re.split(r'[_\s/\-]+', normalized))
    for canonical, keyword_sets in _HEADER_KEYWORD_RULES.items():
        for kw_set in keyword_sets:
            # Check if ALL keywords in this set appear as substrings in any word
            if all(
                any(kw in word for word in header_words)
                for kw in kw_set
            ):
                return canonical

    return None


def _detect_header_row(ws, max_scan: int = 15) -> Tuple[int, List]:
    """Scan first N rows to find the one that looks like column headers.

    Returns (header_row_index_0based, raw_headers).
    A row is considered the header row if it resolves at least 2 canonical
    columns including 'target_column'.
    """
    candidate_rows = []
    for i, row in enumerate(ws.iter_rows(min_row=1, max_row=max_scan, values_only=True)):
        resolved = {}
        for idx, h in enumerate(row):
            if h is None:
                continue
            canonical = _resolve_header(str(h))
            if canonical:
                resolved[canonical] = idx
        # Good header row: has target_column and at least one other key column
        has_target = "target_column" in resolved
        key_count = sum(1 for k in resolved if k in (
            "target_column", "source_column", "transformation",
            "transformation_rule", "target", "source",
        ))
        if has_target and key_count >= 2:
            candidate_rows.append((i, row, key_count, resolved))

    if candidate_rows:
        # Pick the row with most key columns resolved
        best = max(candidate_rows, key=lambda x: x[2])
        return best[0], best[1]

    # Fallback: row 0
    first_row = next(ws.iter_rows(min_row=1, max_row=1, values_only=True))
    return 0, first_row


def _infer_transformation_category(rule_text: str, source_col: str) -> str:
    """Infer the STTM transformation category from the rule/logic text.

    Used when the STTM has no explicit 'transformation' column (e.g., the new
    format that only has 'Source Transformational Rule/Logic').
    """
    rule_lower = rule_text.strip().lower()

    if not rule_text.strip():
        # No rule and has source column = Direct Pull
        if source_col.strip():
            return "Direct Pull"
        return ""

    # Hardcode patterns
    if re.match(r"(?i)^hardcode\s*:", rule_lower):
        return "Custom/Default"

    # Sequence / surrogate key / system-generated ID
    if re.search(r"(?i)increment\s+by\s+1|surrogate\s+key|sequence\s+generat|system\s+generat|auto.?generat|identity\s+col", rule_lower):
        return "Sequence Generated ID"

    # Lookup patterns
    if re.search(r"(?i)lookup\s+on|perform\s+a\s+lookup|populate\s+\w+|left\s+join", rule_lower):
        return "Lookup"

    # CASE WHEN logic
    if re.search(r"(?i)^case\s+when|case\s*\n\s*when", rule_lower):
        return "Derivation"

    # Date conversion
    if re.search(r"(?i)convert\s+to\s+timestamp|to_date|to_timestamp|date\s+convert", rule_lower):
        return "Date Convert"

    # LPAD / padding
    if re.search(r"(?i)lpad|rpad|padding", rule_lower):
        return "Derivation"

    # NULL assignment
    if re.match(r"(?i)^null$|^populate\s+null$", rule_lower):
        return "Custom/Default"

    # Concat
    if re.search(r"(?i)concat|concatenat", rule_lower):
        return "Concatenation"

    # Trim
    if re.search(r"(?i)^trim|ltrim|rtrim", rule_lower):
        return "Trim"

    # Current date / timestamp
    if re.search(r"(?i)current[_\s]?date|current[_\s]?timestamp|getdate|sysdate|now\(\)", rule_lower):
        return "Current date"

    # Coalesce
    if re.search(r"(?i)^coalesce", rule_lower):
        return "Coalesce"

    # Has source column but also a rule = likely derivation
    if source_col.strip():
        return "Direct Pull"

    return "Custom/Default"


def parse_sttm(
    sttm_path: str,
    sheet_name: str = "STTM",
    target_table: Optional[str] = None,
) -> Tuple[List[Dict[str, Any]], Dict[str, Any]]:
    """Parse STTM Excel into a list of mapping dicts."""
    wb = openpyxl.load_workbook(sttm_path, read_only=True, data_only=True)
    if sheet_name not in wb.sheetnames:
        raise ValueError(
            f"Sheet '{sheet_name}' not found in {sttm_path}. "
            f"Available sheets: {wb.sheetnames}"
        )
    ws = wb[sheet_name]

    # Auto-detect header row (may not be row 1 — some STTMs have metadata rows)
    header_row_idx, raw_headers = _detect_header_row(ws)
    if header_row_idx > 0:
        logger.info(f"STTM header row detected at row {header_row_idx + 1} (skipped {header_row_idx} metadata rows)")

    col_map: Dict[int, str] = {}
    unresolved_headers: List[str] = []
    for idx, h in enumerate(raw_headers):
        if h is None:
            continue
        canonical = _resolve_header(str(h))
        if canonical:
            col_map[idx] = canonical
            logger.debug(f"STTM header '{h}' → '{canonical}'")
        else:
            unresolved_headers.append(str(h))
            logger.info(f"STTM header '{h}' not recognized — skipping column")

    # --- Header validation: ensure minimum required columns were resolved ---
    resolved_names = set(col_map.values())
    # target_column is the absolute minimum; without it we can't do anything
    _REQUIRED = {"target_column"}
    _RECOMMENDED = {"source_column", "transformation_rule", "target"}
    missing_required = _REQUIRED - resolved_names
    missing_recommended = _RECOMMENDED - resolved_names

    if missing_required:
        all_headers_str = ", ".join(f"'{h}'" for h in raw_headers if h is not None)
        raise ValueError(
            f"STTM header mismatch — could not find required column(s): "
            f"{', '.join(missing_required)}.\n"
            f"  Headers found in '{sheet_name}' (row {header_row_idx + 1}): [{all_headers_str}]\n"
            f"  Resolved columns: {sorted(resolved_names) if resolved_names else '(none)'}\n"
            f"  Unresolved headers: {unresolved_headers}\n"
            f"\n"
            f"  To fix: add the unrecognized header names as aliases in HEADER_ALIASES \n"
            f"  in detect_drift.py, or rename the Excel headers to match expected names.\n"
            f"  Expected header patterns for target_column: 'Target Column', 'Target Col', \n"
            f"  'Target Attribute', 'ODS Attribute Physical Name', 'EDW Column', etc."
        )

    if missing_recommended:
        logger.warning(
            f"STTM is missing recommended columns: {', '.join(missing_recommended)}. "
            f"Drift detection may be limited. Resolved: {sorted(resolved_names)}"
        )

    if not resolved_names:
        all_headers_str = ", ".join(f"'{h}'" for h in raw_headers if h is not None)
        raise ValueError(
            f"STTM header mismatch — none of the headers could be resolved to known columns.\n"
            f"  Headers found: [{all_headers_str}]\n"
            f"  This usually means the STTM uses project-specific header names.\n"
            f"  Add aliases to HEADER_ALIASES in detect_drift.py to map them."
        )

    logger.info(f"STTM headers resolved: {sorted(resolved_names)} "
                f"({len(unresolved_headers)} unrecognized headers skipped)")

    mappings: List[Dict[str, Any]] = []
    # Data rows start after the header row (1-indexed for openpyxl)
    data_start_row = header_row_idx + 2  # +1 for 0->1 index, +1 to skip header
    for row in ws.iter_rows(min_row=data_start_row, values_only=True):
        record: Dict[str, Any] = {}
        for idx, canonical in col_map.items():
            val = row[idx] if idx < len(row) else None
            record[canonical] = val if val is not None else ""
        if not any(str(v).strip() for v in record.values()):
            continue

        # If no explicit 'transformation' column, infer from transformation_rule
        if not record.get("transformation") and record.get("transformation_rule"):
            record["transformation"] = _infer_transformation_category(
                str(record["transformation_rule"]),
                str(record.get("source_column", "")),
            )

        mappings.append(record)
    wb.close()

    # Filter to target table
    all_targets = set(m.get("target", "") for m in mappings if m.get("target"))
    if target_table:
        mappings = [m for m in mappings if m.get("target", "").upper() == target_table.upper()]
    elif len(all_targets) == 1:
        target_table = all_targets.pop()
    elif len(all_targets) > 1:
        logger.warning(
            f"Multiple target tables found in STTM: {all_targets}. "
            "Use --target-table to select one. Using first found."
        )
        target_table = mappings[0].get("target", "")
        mappings = [m for m in mappings if m.get("target", "") == target_table]

    source_tables = set(m.get("source", "") for m in mappings if m.get("source"))
    source_table = (source_tables.pop() if len(source_tables) == 1
                    else ", ".join(sorted(source_tables)) if source_tables else "")

    metadata = {
        "sttm_file": str(sttm_path),
        "sttm_sheet": sheet_name,
        "target_table": target_table or "",
        "source_table": source_table,
        "total_sttm_mappings": len(mappings),
    }

    logger.info(f"Parsed {len(mappings)} STTM mappings for target '{target_table}'")
    return mappings, metadata


# ---------------------------------------------------------------------------
# 2. PySpark Parser
# ---------------------------------------------------------------------------

class CodeExtraction:
    """Represents a single column mapping extracted from PySpark code."""
    def __init__(
        self,
        target_column: str,
        source_reference: str = "",
        transformation_code: str = "",
        line_number: int = 0,
        context: str = "",
    ):
        self.target_column = target_column
        self.source_reference = source_reference
        self.transformation_code = transformation_code
        self.line_number = line_number
        self.context = context

    def __repr__(self):
        return (f"CodeExtraction({self.target_column}, "
                f"src={self.source_reference}, code={self.transformation_code!r})")


def _find_enclosing_context(lines: List[str], line_idx: int) -> str:
    """Find the class/function context for a given line number (1-indexed)."""
    current_class = ""
    current_func = ""
    for i in range(line_idx - 1, -1, -1):
        line = lines[i]
        stripped = line.lstrip()
        if stripped.startswith("class "):
            match = re.match(r'class\s+(\w+)', stripped)
            if match:
                current_class = match.group(1)
            break
        elif stripped.startswith("def "):
            if not current_func:
                match = re.match(r'def\s+(\w+)', stripped)
                if match:
                    current_func = match.group(1)
    if current_class and current_func:
        return f"{current_class}.{current_func}"
    return current_func or current_class or "module"


def _is_framework_context(context: str) -> bool:
    """Check if a context string represents framework utility code (config-driven)."""
    if context in config.framework_contexts:
        return True
    for prefix in config.framework_class_prefixes:
        if context.startswith(prefix):
            return True
    if "." in context:
        func_name = context.split(".", 1)[1]
        if func_name in ("create_reject_df", "create_err_df"):
            return True
    return False


def _extract_with_column_balanced(line: str) -> List[Tuple[str, str]]:
    """Extract (target_col, expr) from .withColumn calls using balanced paren matching."""
    results = []
    for match in re.finditer(r'\.withColumn\s*\(', line):
        start = match.end()
        rest = line[start:]
        col_match = re.match(r'\s*\(?\s*["\']([^"\']+)["\']\s*\)?\s*,\s*', rest)
        if not col_match:
            continue
        target_col = col_match.group(1)
        expr_start = col_match.end()
        expr_rest = rest[expr_start:]
        depth = 1
        expr_chars = []
        for ch in expr_rest:
            if ch == '(':
                depth += 1
            elif ch == ')':
                depth -= 1
                if depth == 0:
                    break
            expr_chars.append(ch)
        expr_text = ''.join(expr_chars).strip()
        results.append((target_col, expr_text))
    return results


def _extract_source_from_expr(expr_text: str) -> str:
    """Try to extract source column reference from a PySpark expression."""
    col_match = re.search(r'(?:F\.)?col\s*\(\s*["\'](\w+)["\']\s*\)', expr_text)
    if col_match:
        return col_match.group(1)
    bracket_match = re.search(r'\["\s*(\w+)\s*"\]', expr_text)
    if bracket_match:
        return bracket_match.group(1)
    return ""


def _classify_pyspark_expr(expr: str, source_ref: str, target_col: str) -> Tuple[str, str]:
    """Classify a PySpark expression and return (normalized_code, source_ref).

    Uses pattern matching to identify the transformation type and produce
    a clean normalized expression.
    """
    # Order matters — check specific patterns before generic ones
    patterns = [
        (r'(?:F\.)?current_date\s*\(\)|crtd_dt\s*\(\)', lambda: "F.current_date()"),
        (r'(?:F\.)?lit\s*\(', lambda: expr),
        (r'(?:F\.)?md5\s*\(', lambda: "F.md5(F.concat_ws(...))"),
        (r'custom_to_date\s*\(', lambda: f'custom_to_date(F.col("{target_col}"))'),
        (r'(?:F\.)?monotonically_increasing_id\s*\(\)', lambda: "F.monotonically_increasing_id()"),
        (r'(?:F\.)?initcap\s*\(', lambda: f'F.initcap(F.col("{source_ref}"))'),
        (r'(?:F\.)?upper\s*\(', lambda: f'F.upper(F.col("{source_ref}"))'),
        (r'(?:F\.)?lower\s*\(', lambda: f'F.lower(F.col("{source_ref}"))'),
        (r'(?:F\.)?trim\s*\(|(?:F\.)?ltrim\s*\(|(?:F\.)?rtrim\s*\(', lambda: f'F.trim(F.col("{source_ref}"))'),
        (r'(?:F\.)?coalesce\s*\(', lambda: expr),
        (r'(?:F\.)?when\s*\(', lambda: expr),
        (r'(?:F\.)?concat_ws\s*\(|(?:F\.)?concat\s*\(', lambda: expr),
        (r'(?:F\.)?regexp_replace\s*\(', lambda: expr),
        (r'(?:F\.)?substring\s*\(|(?:F\.)?substr\s*\(', lambda: expr),
        (r'(?:F\.)?to_date\s*\(|(?:F\.)?date_format\s*\(', lambda: expr),
    ]

    for pattern, normalizer in patterns:
        if re.search(pattern, expr):
            return normalizer(), source_ref

    return expr, source_ref


def _extract_lit_assignments(code: str, lines: List[str]) -> Dict[str, Tuple[str, int]]:
    """Extract variable assignments that use F.lit() — helps resolve dynamic literals."""
    results = {}
    lit_assign = re.compile(r'(\w+)\s*=\s*(?:F\.)?lit\s*\(\s*(.+?)\s*\)')
    for i, line in enumerate(lines, 1):
        stripped = line.lstrip()
        if stripped.startswith("#"):
            continue
        for match in lit_assign.finditer(line):
            var_name = match.group(1)
            lit_value = match.group(2).strip().strip("'\"")
            results[var_name] = (lit_value, i)
    return results


def _extract_string_assignments(code: str, lines: List[str]) -> Dict[str, str]:
    """Extract simple string variable assignments for resolving F.lit(var_name).

    Looks for patterns like: job_nm = "ref-val-job" or job_name = 'my_job'
    """
    results = {}
    str_assign = re.compile(r'(\w+)\s*=\s*["\']([^"\']+)["\']\s*$')
    for line in lines:
        stripped = line.strip()
        if stripped.startswith("#"):
            continue
        match = str_assign.match(stripped)
        if match:
            results[match.group(1)] = match.group(2)
    return results


def _detect_json_config_reference(pyspark_code: str) -> Optional[str]:
    """Detect if PySpark code references a JSON config file.

    Scans for patterns like:
      open('some_file.json', 'r')
      json.load(open('file.json'))
      with open("config.json") as f:
    Returns the JSON filename if found, None otherwise.
    """
    patterns = [
        r"""open\s*\(\s*['"]([^'"]+\.json)['"]""",
        r"""json_(?:file|path|config)\s*=\s*['"]([^'"]+\.json)['"]""",
        r"""load_config\s*\(\s*['"]([^'"]+\.json)['"]""",
    ]
    for pattern in patterns:
        match = re.search(pattern, pyspark_code)
        if match:
            return match.group(1)
    return None


def _extract_sql_column_mappings(sql_query: str) -> List[CodeExtraction]:
    """Extract column mappings from a SQL SELECT query.

    Parses patterns like:
      stg."Column Name" AS TARGET_COL
      TO_DATE(stg."Col", 'fmt') AS TARGET_COL
      COALESCE(ref.COL, -99) AS TARGET_COL
      'literal' AS TARGET_COL
      current_date() AS TARGET_COL
      function(args) AS TARGET_COL
    """
    extractions: List[CodeExtraction] = []
    seen: set = set()

    # Remove everything from FROM onward for the SELECT clause parsing
    select_match = re.search(r'SELECT\s+(.*?)\s+FROM\s+', sql_query, re.IGNORECASE | re.DOTALL)
    if not select_match:
        return extractions

    select_clause = select_match.group(1)

    # Split by comma, respecting parentheses nesting
    items: List[str] = []
    depth = 0
    current: List[str] = []
    for ch in select_clause:
        if ch == '(':
            depth += 1
            current.append(ch)
        elif ch == ')':
            depth -= 1
            current.append(ch)
        elif ch == ',' and depth == 0:
            items.append(''.join(current).strip())
            current = []
        else:
            current.append(ch)
    if current:
        items.append(''.join(current).strip())

    for item in items:
        item = item.strip()
        if not item:
            continue

        # Extract alias: ... AS alias_name
        alias_match = re.search(r'\bAS\s+(\w+)\s*$', item, re.IGNORECASE)
        if not alias_match:
            continue
        target_col = alias_match.group(1)
        expr_part = item[:alias_match.start()].strip()

        key = target_col.upper()
        if key in seen:
            continue
        seen.add(key)

        # Classify the SQL expression
        source_ref = ""
        transformation_code = expr_part

        # Direct column reference: stg."Col Name" or stg.col or `Col Name` or just col
        direct_match = re.match(
            r'^(?:\w+\.)?(?:"([^"]+)"|`([^`]+)`|(\w+))$', expr_part
        )
        if direct_match:
            source_ref = direct_match.group(1) or direct_match.group(2) or direct_match.group(3)
            transformation_code = f"DIRECT_PULL({source_ref})"

        # Literal string: 'value'
        elif re.match(r"^'[^']*'$", expr_part):
            transformation_code = f"F.lit({expr_part})"

        # current_date()
        elif re.match(r'^current_date\s*\(\)', expr_part, re.IGNORECASE):
            transformation_code = "F.current_date()"

        # current_timestamp()
        elif re.match(r'^current_timestamp\s*\(\)', expr_part, re.IGNORECASE):
            transformation_code = "F.current_timestamp()"

        # TO_DATE(...)
        elif re.match(r'^TO_DATE\s*\(', expr_part, re.IGNORECASE):
            col_ref = re.search(r'TO_DATE\s*\(\s*(?:\w+\.)?(?:"([^"]+)"|(\w+))', expr_part, re.IGNORECASE)
            if col_ref:
                source_ref = col_ref.group(1) or col_ref.group(2)
            transformation_code = f"F.to_date(F.col(\"{source_ref}\"))"

        # COALESCE(...)
        elif re.match(r'^COALESCE\s*\(', expr_part, re.IGNORECASE):
            col_ref = re.search(r'COALESCE\s*\(\s*(?:\w+\.)?(?:"?(\w+)"?|"([^"]+)")', expr_part, re.IGNORECASE)
            if col_ref:
                source_ref = col_ref.group(1) or col_ref.group(2)
            transformation_code = expr_part

        # TRIM(...)
        elif re.match(r'^(?:TRIM|LTRIM|RTRIM)\s*\(', expr_part, re.IGNORECASE):
            col_ref = re.search(r'(?:TRIM|LTRIM|RTRIM)\s*\(\s*(?:\w+\.)?(?:"([^"]+)"|(\w+))', expr_part, re.IGNORECASE)
            if col_ref:
                source_ref = col_ref.group(1) or col_ref.group(2)
            transformation_code = f"F.trim(F.col(\"{source_ref}\"))"

        # COUNT(...)
        elif re.match(r'^COUNT\s*\(', expr_part, re.IGNORECASE):
            transformation_code = "F.count()"

        extractions.append(CodeExtraction(
            target_column=target_col,
            source_reference=source_ref,
            transformation_code=transformation_code,
            line_number=0,
            context="json_sql_query",
        ))

    return extractions


def _parse_json_config(json_path: str) -> Tuple[List[CodeExtraction], str]:
    """Parse a JSON config file to extract SQL queries and their column mappings.

    Looks for SQL queries in the JSON structure (nested search) and extracts
    column mappings from SELECT statements.

    Returns (extractions, sql_query_used).
    """
    with open(json_path, "r", encoding="utf-8") as f:
        data = json.load(f)

    # Recursively find all SQL queries in the JSON
    sql_queries: List[str] = []

    def _find_queries(obj, path=""):
        if isinstance(obj, dict):
            for key, val in obj.items():
                if isinstance(val, str) and re.search(r'\bSELECT\b', val, re.IGNORECASE):
                    sql_queries.append(val)
                else:
                    _find_queries(val, f"{path}.{key}")
        elif isinstance(obj, list):
            for i, item in enumerate(obj):
                _find_queries(item, f"{path}[{i}]")

    _find_queries(data)

    if not sql_queries:
        logger.warning(f"No SQL queries found in JSON config: {json_path}")
        return [], ""

    # Use the core transformation query (longest SELECT with AS clauses — most likely the main transform)
    best_query = ""
    best_count = 0
    for q in sql_queries:
        alias_count = len(re.findall(r'\bAS\s+\w+', q, re.IGNORECASE))
        if alias_count > best_count:
            best_count = alias_count
            best_query = q

    if not best_query:
        best_query = sql_queries[0]

    logger.info(f"Found {len(sql_queries)} SQL queries in JSON config, using query with {best_count} column aliases")

    extractions = _extract_sql_column_mappings(best_query)

    # Also try to extract global params (job_name, etc.) for variable resolution
    global_params = {}

    def _find_params(obj):
        if isinstance(obj, dict):
            if "global_params" in obj:
                params = obj["global_params"]
                if isinstance(params, dict):
                    for section_val in params.values():
                        if isinstance(section_val, dict):
                            global_params.update(section_val)
            for val in obj.values():
                _find_params(val)

    _find_params(data)

    # Resolve job_name in extractions
    job_name = global_params.get("job_name", "")
    if job_name:
        for ext in extractions:
            if ext.transformation_code and "F.lit(" in ext.transformation_code:
                # Check if the literal matches job_name pattern
                lit_match = re.search(r"F\.lit\('([^']+)'\)", ext.transformation_code)
                if lit_match and lit_match.group(1) == job_name:
                    pass  # Already resolved

    return extractions, best_query


def parse_pyspark(pyspark_path: str, json_config_path: Optional[str] = None) -> Tuple[List[CodeExtraction], Dict[str, Any]]:
    """Parse a PySpark .py file to extract column mappings and transformations.

    If the PySpark code references a JSON config file, the JSON is parsed
    for SQL queries and column mappings are extracted from those queries.

    If json_config_path is provided explicitly, it is used directly.
    If the PySpark code references a JSON file but none is provided, an error is raised.
    If no JSON reference exists, the PySpark code itself is parsed for mappings.

    Filtering of framework utility code is driven by transform_config.yaml.
    In standard mode (no framework detected), all contexts are included.
    """
    code = Path(pyspark_path).read_text(encoding="utf-8")
    lines = code.split("\n")

    # --- JSON Config Detection ---
    # Check if PySpark code references a JSON config file
    json_ref = _detect_json_config_reference(code)

    if json_config_path:
        # Explicit JSON config provided via CLI
        json_path = Path(json_config_path)
        if not json_path.exists():
            raise FileNotFoundError(
                f"JSON config file not found: {json_config_path}"
            )
        logger.info(f"Using explicitly provided JSON config: {json_config_path}")
        json_extractions, sql_query = _parse_json_config(str(json_path))
        if json_extractions:
            metadata = {
                "pyspark_file": str(pyspark_path),
                "json_config_file": str(json_config_path),
                "total_pyspark_columns": len(json_extractions),
                "source_type": "json_sql_query",
            }
            logger.info(f"Extracted {len(json_extractions)} column mappings from JSON config SQL query")
            return json_extractions, metadata

    elif json_ref:
        # PySpark code references a JSON file — try to find it
        pyspark_dir = Path(pyspark_path).parent
        json_candidates = [
            pyspark_dir / json_ref,
            pyspark_dir / Path(json_ref).name,
            Path(json_ref),
        ]
        json_found = None
        for candidate in json_candidates:
            if candidate.exists():
                json_found = candidate
                break

        if json_found is None:
            raise FileNotFoundError(
                f"PySpark job references JSON config file '{json_ref}' but it was not found. "
                f"Provide it via --json-config <path> or place it alongside the PySpark file."
            )

        logger.info(f"Auto-detected JSON config from PySpark code: {json_found}")
        json_extractions, sql_query = _parse_json_config(str(json_found))
        if json_extractions:
            metadata = {
                "pyspark_file": str(pyspark_path),
                "json_config_file": str(json_found),
                "total_pyspark_columns": len(json_extractions),
                "source_type": "json_sql_query",
            }
            logger.info(f"Extracted {len(json_extractions)} column mappings from JSON config SQL query")
            return json_extractions, metadata
        else:
            logger.warning(f"JSON config found but no column mappings extracted — falling back to PySpark parsing")

    # --- No JSON config — parse PySpark code directly ---
    extractions: List[CodeExtraction] = []
    seen_targets: set = set()

    def _add(target, source="", code_snippet="", lineno=0, context=""):
        key = target.upper()
        if key not in seen_targets:
            seen_targets.add(key)
            extractions.append(CodeExtraction(target, source, code_snippet, lineno, context))

    # --- Pass 1: Extract withColumn calls ---
    for i, line in enumerate(lines, 1):
        if ".withColumn" not in line:
            continue
        stripped = line.lstrip()
        if stripped.startswith("#"):
            continue

        context = _find_enclosing_context(lines, i)

        # Only filter framework contexts if a framework is active
        if config.is_framework_mode and _is_framework_context(context):
            continue

        for target_col, expr_text in _extract_with_column_balanced(line):
            source_ref = _extract_source_from_expr(expr_text)
            normalized_code, source_ref = _classify_pyspark_expr(expr_text, source_ref, target_col)
            _add(target_col, source_ref, normalized_code, i, context)

    # --- Pass 2: Extract withColumnRenamed calls ---
    wcr_pattern = re.compile(
        r'\.withColumnRenamed\s*\(\s*["\'](\w+)["\']\s*,\s*["\'](\w+)["\']\s*\)',
    )
    for i, line in enumerate(lines, 1):
        stripped = line.lstrip()
        if stripped.startswith("#"):
            continue
        context = _find_enclosing_context(lines, i)
        if config.is_framework_mode and _is_framework_context(context):
            continue
        for match in wcr_pattern.finditer(line):
            old_col, new_col = match.group(1), match.group(2)
            _add(new_col, old_col, f"withColumnRenamed({old_col}, {new_col})", i, context)

    # --- Pass 3: Extract .alias() renames ---
    alias_pattern = re.compile(
        r'((?:F\.)?(?:col|trim|upper|lower|coalesce|when|to_date|initcap)\s*\([^)]*\))'
        r'\.alias\s*\(\s*["\'](\w+)["\']\s*\)'
    )
    for i, line in enumerate(lines, 1):
        if ".alias(" not in line:
            continue
        stripped = line.lstrip()
        if stripped.startswith("#"):
            continue
        context = _find_enclosing_context(lines, i)
        if config.is_framework_mode and _is_framework_context(context):
            continue
        for match in alias_pattern.finditer(line):
            full_expr = match.group(1)
            target_col = match.group(2)
            source_ref = _extract_source_from_expr(full_expr)
            _add(target_col, source_ref, full_expr, i, context)

    # --- Pass 4: Resolve variable-based literals ---
    string_vars = _extract_string_assignments(code, lines)
    lit_vars = _extract_lit_assignments(code, lines)

    for ext in extractions:
        if ext.transformation_code:
            lit_match = re.search(r'(?:F\.)?lit\s*\(\s*(\w+)\s*\)', ext.transformation_code)
            if lit_match:
                var_name = lit_match.group(1)
                if var_name in ("None", "True", "False"):
                    continue
                # Try to resolve from string assignments first, then lit assignments
                if var_name in string_vars:
                    ext.transformation_code = f"F.lit('{string_vars[var_name]}')"
                elif var_name in lit_vars:
                    resolved_val, _ = lit_vars[var_name]
                    ext.transformation_code = f"F.lit('{resolved_val}')"

    metadata = {
        "pyspark_file": str(pyspark_path),
        "total_pyspark_columns": len(extractions),
    }

    logger.info(f"Extracted {len(extractions)} column mappings from PySpark code")
    return extractions, metadata


# ---------------------------------------------------------------------------
# 3. Transformation Normalizer
# ---------------------------------------------------------------------------

def normalize_sttm_transformation(
    transformation: str, transformation_rule: str, source_column: str, target_column: str,
) -> Dict[str, str]:
    """Normalize an STTM mapping to canonical form (config-driven)."""
    tf_lower = str(transformation).strip().lower()
    rule = str(transformation_rule).strip()

    category = config.sttm_categories.get(tf_lower, "UNKNOWN")

    # Build canonical expression based on category
    src_or_tgt = source_column or target_column
    canonical_builders = {
        # Core
        "DIRECT_PULL": lambda: f"DIRECT_PULL({src_or_tgt})",
        "SEQUENCE_ID": lambda: "SEQUENCE_ID()",
        "CURRENT_DATE": lambda: "CURRENT_DATE()",
        "LITERAL": lambda: f"LIT({rule})" if rule else "LIT()",
        "DATE_CONVERT": lambda: f"TO_DATE({src_or_tgt})",
        "DATATYPE_CAST": lambda: f"CAST({src_or_tgt})" if not rule else f"CAST({rule})",
        "LOOKUP": lambda: f"LOOKUP({rule})" if rule else "LOOKUP()",
        "TRIM": lambda: f"TRIM({src_or_tgt})",
        "MD5_HASH": lambda: f"MD5({rule})" if rule else "MD5()",
        "COUNT": lambda: "COUNT()",
        # String
        "UPPER": lambda: f"UPPER({src_or_tgt})",
        "LOWER": lambda: f"LOWER({src_or_tgt})",
        "INITCAP": lambda: f"INITCAP({src_or_tgt})",
        "COALESCE": lambda: f"COALESCE({rule})" if rule else "COALESCE()",
        "CONCAT": lambda: f"CONCAT({rule})" if rule else "CONCAT()",
        "SUBSTRING": lambda: f"SUBSTRING({src_or_tgt})",
        "REPLACE": lambda: f"REPLACE({rule})" if rule else f"REPLACE({src_or_tgt})",
        "REGEX_REPLACE": lambda: f"REGEX_REPLACE({src_or_tgt})",
        # Conditional
        "CASE_WHEN": lambda: f"CASE_WHEN({rule})" if rule else "CASE_WHEN()",
        "IF_ELSE": lambda: f"IF_ELSE({rule})" if rule else "IF_ELSE()",
        "EMAIL_VALIDATION": lambda: f"EMAIL_VALIDATION({src_or_tgt})",
        # Arithmetic
        "AVERAGE": lambda: f"AVERAGE({rule})" if rule else f"AVERAGE({src_or_tgt})",
        "SUM": lambda: f"SUM({rule})" if rule else f"SUM({src_or_tgt})",
        "MIN": lambda: f"MIN({rule})" if rule else f"MIN({src_or_tgt})",
        "MAX": lambda: f"MAX({rule})" if rule else f"MAX({src_or_tgt})",
        "ABS": lambda: f"ABS({src_or_tgt})",
        "MULTIPLY": lambda: f"MULTIPLY({rule})" if rule else "MULTIPLY()",
        "DIVIDE": lambda: f"DIVIDE({rule})" if rule else "DIVIDE()",
        "SUBTRACT": lambda: f"SUBTRACT({rule})" if rule else "SUBTRACT()",
        "PERCENTAGE": lambda: f"PERCENTAGE({rule})" if rule else "PERCENTAGE()",
        # Specialized
        "ROW_NUMBER": lambda: "ROW_NUMBER()",
        "PARAM_BATCH_DATE": lambda: "PARAM_BATCH_DATE()",
        "TIMEZONE_CONVERT": lambda: f"TIMEZONE_CONVERT({rule})" if rule else f"TIMEZONE_CONVERT({src_or_tgt})",
        "NLQ": lambda: f"NLQ({rule})" if rule else "NLQ()",
    }

    # Handle ETL_AUDIT specially — it resolves to sub-categories
    if category == "ETL_AUDIT":
        rule_lower = rule.lower()
        if "job name" in rule_lower or "job_name" in rule_lower:
            category = "LITERAL"
            canonical_expr = "LIT(job_name)"
        elif "current date" in rule_lower or "new version" in rule_lower:
            category = "CURRENT_DATE"
            canonical_expr = "CURRENT_DATE()"
        elif "field not applicable" in rule_lower:
            # "Field not applicable" = this audit column is not required
            # for this table. Whether code has it or not, it's not a drift.
            category = "NOT_APPLICABLE"
            canonical_expr = f"NOT_APPLICABLE({target_column})"
        elif not rule:
            canonical_expr = f"ETL_AUDIT({target_column})"
        else:
            canonical_expr = f"ETL_AUDIT({rule})"
    elif category == "UNKNOWN":
        if tf_lower:
            canonical_expr = f"UNKNOWN({transformation})"
            logger.warning(f"Unknown STTM transformation type: '{transformation}' for column '{target_column}'. "
                          f"Add it to transform_config.yaml → sttm_categories")
        else:
            # Blank STTM transformation = "just pull the column" (Direct Pull)
            if source_column:
                canonical_expr = f"DIRECT_PULL({source_column})"
                category = "DIRECT_PULL"
            else:
                canonical_expr = f"DIRECT_PULL({target_column})"
                category = "DIRECT_PULL"
    else:
        builder = canonical_builders.get(category)
        canonical_expr = builder() if builder else f"{category}()"

    return {
        "category": category,
        "canonical_expr": canonical_expr,
        "original_transformation": str(transformation),
        "original_rule": rule,
    }


def _normalize_json_sql_extraction(extraction: CodeExtraction) -> Dict[str, str]:
    """Normalize a JSON SQL extraction to canonical form.

    JSON SQL extractions have transformation_code already partially classified
    by _extract_sql_column_mappings. Map them to the same canonical categories
    used by the STTM normalizer.
    """
    code = extraction.transformation_code
    source = extraction.source_reference

    # Direct pull: DIRECT_PULL(col) or simple column ref
    if code.startswith("DIRECT_PULL("):
        return {"category": "DIRECT_PULL", "canonical_expr": f"DIRECT_PULL({source})", "original_code": code}

    # F.lit(...) — literal
    lit_match = re.search(r'F\.lit\((.+?)\)', code)
    if lit_match:
        val = lit_match.group(1)
        if val in ("None", "null"):
            return {"category": "PLACEHOLDER", "canonical_expr": "LIT(None)", "original_code": code}
        return {"category": "LITERAL", "canonical_expr": f"LIT({val})", "original_code": code}

    # F.current_date()
    if "current_date" in code.lower():
        return {"category": "CURRENT_DATE", "canonical_expr": "CURRENT_DATE()", "original_code": code}

    # F.current_timestamp()
    if "current_timestamp" in code.lower():
        return {"category": "CURRENT_DATE", "canonical_expr": "CURRENT_TIMESTAMP()", "original_code": code}

    # F.to_date(...)
    if "to_date" in code.lower():
        return {"category": "DATE_CONVERT", "canonical_expr": f"TO_DATE({source})" if source else "TO_DATE()", "original_code": code}

    # F.trim(...)
    if "trim" in code.lower():
        return {"category": "TRIM", "canonical_expr": f"TRIM({source})" if source else "TRIM()", "original_code": code}

    # F.count(...)
    if "count" in code.lower():
        return {"category": "COUNT", "canonical_expr": "COUNT()", "original_code": code}

    # COALESCE(...) — could be a lookup pattern
    if re.match(r'^COALESCE\s*\(', code, re.IGNORECASE):
        # Check for lookup pattern: COALESCE(ref.COL, default)
        lookup_match = re.search(r'COALESCE\s*\(\s*(\w+)\.(\w+)\s*,\s*(.+?)\s*\)', code, re.IGNORECASE)
        if lookup_match:
            ref_table = lookup_match.group(1)
            ref_col = lookup_match.group(2)
            default = lookup_match.group(3)
            return {"category": "LOOKUP", "canonical_expr": f"LOOKUP({ref_table}.{ref_col}, default={default})", "original_code": code}
        return {"category": "COALESCE", "canonical_expr": f"COALESCE({source})" if source else "COALESCE()", "original_code": code}

    # Fallback
    if source:
        return {"category": "DIRECT_PULL", "canonical_expr": f"DIRECT_PULL({source})", "original_code": code}
    return {"category": "UNKNOWN", "canonical_expr": f"UNKNOWN({code[:80]})", "original_code": code}


def normalize_pyspark_transformation(extraction: CodeExtraction) -> Dict[str, str]:
    """Normalize a PySpark extraction to canonical form."""
    code = extraction.transformation_code
    source = extraction.source_reference

    # JSON SQL query extractions are already in canonical form
    if extraction.context == "json_sql_query":
        return _normalize_json_sql_extraction(extraction)

    if not code:
        if source:
            return {"category": "DIRECT_PULL", "canonical_expr": f"DIRECT_PULL({source})", "original_code": code}
        return {"category": "UNKNOWN", "canonical_expr": "UNKNOWN()", "original_code": code}

    code_check = code.strip()

    # --- DBT / raw SQL expression normalization ---
    # For dbt_model context, the transformation_code is raw SQL (not PySpark).
    # Detect SQL-native patterns before falling through to PySpark regex.
    if extraction.context == "dbt_model":
        sql_upper = code_check.upper()

        # CASE WHEN ... (may be wrapped in CAST)
        if re.search(r'\bCASE\s+WHEN\b', sql_upper):
            return {"category": "CASE_WHEN", "canonical_expr": f"CASE_WHEN({source})" if source else "CASE_WHEN()", "original_code": code}

        # LPAD / RPAD (including dbt macro lpad_char)
        if re.search(r'\bL?R?PAD\b|lpad_char', code_check, re.IGNORECASE):
            return {"category": "DERIVATION", "canonical_expr": f"LPAD({source})" if source else "LPAD()", "original_code": code}

        # UPPER(...)
        if re.match(r'(?i)^(?:cast\s*\(\s*)?upper\s*\(', code_check):
            return {"category": "UPPER", "canonical_expr": f"UPPER({source})" if source else "UPPER()", "original_code": code}

        # LOWER(...)
        if re.match(r'(?i)^(?:cast\s*\(\s*)?lower\s*\(', code_check):
            return {"category": "LOWER", "canonical_expr": f"LOWER({source})" if source else "LOWER()", "original_code": code}

        # TRIM / LTRIM / RTRIM
        if re.match(r'(?i)^(?:cast\s*\(\s*)?(?:l|r)?trim\s*\(', code_check):
            return {"category": "TRIM", "canonical_expr": f"TRIM({source})" if source else "TRIM()", "original_code": code}

        # COALESCE / NVL / IFNULL / NULLIF
        if re.match(r'(?i)^(?:cast\s*\(\s*)?(?:coalesce|nvl|ifnull)\s*\(', code_check):
            return {"category": "COALESCE", "canonical_expr": f"COALESCE({source})" if source else "COALESCE()", "original_code": code}

        # CONCAT / || operator
        if re.match(r'(?i)^(?:cast\s*\(\s*)?concat\s*\(', code_check) or '||' in code_check:
            return {"category": "CONCAT", "canonical_expr": f"CONCAT({source})" if source else "CONCAT()", "original_code": code}

        # TO_DATE / TO_TIMESTAMP
        if re.match(r'(?i)^(?:cast\s*\(\s*)?to_(?:date|timestamp)\s*\(', code_check):
            return {"category": "DATE_CONVERT", "canonical_expr": f"TO_DATE({source})" if source else "TO_DATE()", "original_code": code}

        # SUBSTRING / SUBSTR
        if re.match(r'(?i)^(?:cast\s*\(\s*)?substr(?:ing)?\s*\(', code_check):
            return {"category": "SUBSTRING", "canonical_expr": f"SUBSTRING({source})" if source else "SUBSTRING()", "original_code": code}

        # ROW_NUMBER() / RANK() / DENSE_RANK()
        if re.search(r'(?i)\brow_number\s*\(\)', code_check):
            return {"category": "SEQUENCE_ID", "canonical_expr": "SEQUENCE_ID()", "original_code": code}

        # MD5 / SHA2 hash
        if re.match(r'(?i)^(?:cast\s*\(\s*)?(?:md5|sha2?)\s*\(', code_check):
            return {"category": "MD5_HASH", "canonical_expr": "MD5()", "original_code": code}

        # CURRENT_DATE / CURRENT_TIMESTAMP / NOW()
        if re.match(r'(?i)^(?:cast\s*\(\s*)?(?:current_date|current_timestamp|now|getdate)\s*\(?\)?', code_check):
            return {"category": "CURRENT_DATE", "canonical_expr": "CURRENT_DATE()", "original_code": code}

        # Literal: 'value' or cast('value' as ...)
        if re.match(r"^(?:cast\s*\(\s*)?'[^']*'", code_check, re.IGNORECASE):
            lit_match = re.search(r"'([^']*)'", code_check)
            val = lit_match.group(1) if lit_match else code_check
            return {"category": "LITERAL", "canonical_expr": f"LIT('{val}')", "original_code": code}

        # cast(null as ...) — placeholder
        if re.match(r'(?i)^cast\s*\(\s*null\b', code_check):
            return {"category": "PLACEHOLDER", "canonical_expr": "LIT(None)", "original_code": code}

        # CAST(col as type) — datatype cast of a direct column
        if re.match(r'(?i)^cast\s*\(\s*(?:\w+\.)?(\w+)\s+as\s+', code_check):
            return {"category": "DIRECT_PULL", "canonical_expr": f"DIRECT_PULL({source})" if source else "DIRECT_PULL()", "original_code": code}

        # Simple column reference: table.col or just col
        if re.match(r'^(?:\w+\.)?(\w+)$', code_check):
            ref = source or code_check.split('.')[-1]
            return {"category": "DIRECT_PULL", "canonical_expr": f"DIRECT_PULL({ref})", "original_code": code}


    # Ordered checks — specific patterns first, then generic fallback
    checks = [
        # (regex, category, canonical_expr_builder)
        (r'(?:F\.)?lit\s*\(\s*(.+?)\s*\)', None, None),  # Special handling below
        (r'F\.current_date\(\)|crtd_dt\(\)', "CURRENT_DATE", lambda: "CURRENT_DATE()"),
        (r'monotonically_increasing_id|row_number', "SEQUENCE_ID", lambda: "SEQUENCE_ID()"),
        (r'F\.md5\(|\.md5\(', "MD5_HASH", lambda: "MD5()"),
        (r'custom_to_date\(|F\.to_date\(|to_date\(|F\.date_format\(', "DATE_CONVERT",
         lambda: f"TO_DATE({source})" if source else "TO_DATE()"),
        (r'F\.initcap\(|initcap\(', "INITCAP", lambda: f"INITCAP({source})" if source else "INITCAP()"),
        (r'F\.upper\(|\.upper\(\)', "UPPER", lambda: f"UPPER({source})" if source else "UPPER()"),
        (r'F\.lower\(|\.lower\(\)', "LOWER", lambda: f"LOWER({source})" if source else "LOWER()"),
        (r'F\.trim\(|F\.ltrim\(|F\.rtrim\(', "TRIM", lambda: f"TRIM({source})" if source else "TRIM()"),
        (r'F\.coalesce\(', "COALESCE", lambda: f"COALESCE({source})" if source else "COALESCE()"),
        (r'F\.concat_ws\(|F\.concat\(', "CONCAT", lambda: f"CONCAT({source})" if source else "CONCAT()"),
        (r'F\.substring\(|F\.substr\(', "SUBSTRING", lambda: f"SUBSTRING({source})" if source else "SUBSTRING()"),
        (r'F\.regexp_replace\(', "REGEX_REPLACE", lambda: f"REGEX_REPLACE({source})" if source else "REGEX_REPLACE()"),
        (r'F\.when\(', "CASE_WHEN", lambda: f"CASE_WHEN({source})" if source else "CASE_WHEN()"),
        (r'withColumnRenamed\((\w+),\s*(\w+)\)', "DIRECT_PULL", None),  # Special handling
        (r'^(?:F\.)?col\s*\(\s*["\'](\w+)["\']\s*\)$', "DIRECT_PULL",
         lambda: f"DIRECT_PULL({source})"),
    ]

    # Special: F.lit() handling
    lit_match = re.search(r'(?:F\.)?lit\s*\(\s*(.+?)\s*\)', code_check)
    if lit_match and "md5" not in code_check.lower() and "current_date" not in code_check.lower():
        val = lit_match.group(1)
        if val in ("None", "null", "'None'"):
            return {"category": "PLACEHOLDER", "canonical_expr": "LIT(None)", "original_code": code}
        return {"category": "LITERAL", "canonical_expr": f"LIT({val})", "original_code": code}

    # Run through ordered checks
    for pattern, cat, builder in checks:
        if cat is None:
            continue  # Skip special-handled patterns
        if re.search(pattern, code_check):
            # Special: withColumnRenamed
            if cat == "DIRECT_PULL" and "withColumnRenamed" in pattern:
                rename_match = re.search(pattern, code_check)
                if rename_match:
                    return {"category": "DIRECT_PULL",
                            "canonical_expr": f"DIRECT_PULL({rename_match.group(1)})",
                            "original_code": code}
            canonical = builder() if builder else f"{cat}()"
            return {"category": cat, "canonical_expr": canonical, "original_code": code}

    # Final fallback: check config-driven patterns
    for pattern, cat in config.pyspark_patterns.items():
        if re.search(pattern, code_check):
            return {"category": cat,
                    "canonical_expr": f"{cat}({source})" if source else f"{cat}()",
                    "original_code": code}

    return {"category": "UNKNOWN", "canonical_expr": f"UNKNOWN({code_check[:80]})", "original_code": code}


# ---------------------------------------------------------------------------
# 4. Drift Comparator (STTM → Code)
# ---------------------------------------------------------------------------

def _bump_severity(severity: str) -> str:
    """Bump severity one level higher for natural key columns."""
    order = {"INFO": "LOW", "LOW": "MEDIUM", "MEDIUM": "HIGH", "HIGH": "CRITICAL", "CRITICAL": "CRITICAL"}
    return order.get(severity, severity)


def _categories_equivalent(sttm_cat: str, pyspark_cat: str) -> bool:
    """Check if two canonical categories are semantically equivalent (config-driven)."""
    if sttm_cat == pyspark_cat:
        return True
    # "Field not applicable" means the column is not required — matches anything
    if sttm_cat == "NOT_APPLICABLE":
        return True
    if (sttm_cat, pyspark_cat) in config.equivalent_categories:
        return True
    if (pyspark_cat, sttm_cat) in config.equivalent_categories:
        return True
    if pyspark_cat == "PLACEHOLDER":
        return True
    return False


def _compare_literal_values(sttm_rule: str, pyspark_code: str) -> bool:
    """Compare literal values between STTM rule and PySpark F.lit() value."""
    if not sttm_rule:
        return True

    sttm_val = sttm_rule.strip().strip("'\"").lower()

    lit_match = re.search(r'(?:F\.)?lit\s*\(\s*["\']?([^"\')\s]+)["\']?\s*\)', pyspark_code)
    if lit_match:
        pyspark_val = lit_match.group(1).strip().lower()
        return sttm_val == pyspark_val

    return True


def compare_mappings(
    sttm_mappings: List[Dict[str, Any]],
    pyspark_extractions: List[CodeExtraction],
    technology: str = "pyspark",
) -> List[Dict[str, Any]]:
    """Compare each STTM mapping against code extractions.

    Behavior depends on the detected mode:
    - Framework mode: columns not found in code are checked against the
      framework's dynamic mapping capability. If the framework handles them
      at runtime, they're treated as matches.
    - Standard mode: every STTM mapping MUST have an explicit implementation
      in the PySpark code. Missing = CRITICAL drift.
    """
    results: List[Dict[str, Any]] = []

    # Resolve technology-aware fix generator
    _fix_gen = TECH_FIX_GENERATORS.get(technology, _generate_pyspark_fix)

    pyspark_by_target: Dict[str, CodeExtraction] = {}
    for ext in pyspark_extractions:
        pyspark_by_target[ext.target_column.upper()] = ext

    for mapping in sttm_mappings:
        target_col = str(mapping.get("target_column", "")).strip()
        if not target_col:
            continue
        target_col_upper = target_col.upper()

        source_col = str(mapping.get("source_column", "")).strip()
        transformation = str(mapping.get("transformation", "")).strip()
        transformation_rule = str(mapping.get("transformation_rule", "")).strip()
        is_nk = str(mapping.get("nk", "")).strip().upper() == "Y"
        data_type = str(mapping.get("target_data_type", "")).strip()

        sttm_norm = normalize_sttm_transformation(
            transformation, transformation_rule, source_col, target_col,
        )

        pyspark_ext = pyspark_by_target.get(target_col_upper)

        result = {
            "target_column": target_col,
            "is_natural_key": is_nk,
            "sttm": {
                "source_column": source_col,
                "transformation": transformation,
                "transformation_rule": transformation_rule,
                "data_type": data_type,
            },
        }

        # --- Audit / ETL framework columns — presence check only, skip transformation ---
        _edh_prefixes = ("EDH_", "ETL_", "DW_", "AUDIT_", "META_")
        _audit_suffixes = ("_SK", "_SURROGATE_KEY", "_HASH_KEY")
        _audit_column_names = (
            "CRTD_DT", "CRTD_BY", "MDFD_DT", "MDFD_BY", "MODFD_DT", "MODFD_BY",
            "CREATED_DATE", "CREATED_BY", "MODIFIED_DATE", "MODIFIED_BY",
            "EFF_FROM_DT", "EFF_TO_DT", "EFF_RO_DT",
            "SRC_EFF_FROM_DT", "SRC_EFF_TO_DT",
            "EFF_START_DT", "EFF_END_DT", "EFF_START_DATE", "EFF_END_DATE",
            "EFFECTIVE_FROM", "EFFECTIVE_TO",
            "BTCH_ID", "BATCH_ID", "JOB_ID", "LOAD_DT", "LOAD_DATE", "RUN_ID",
            "SRC_SYS_CD", "SRC_SYSTEM", "ACTV_IND", "ACTIVE_IND",
        )
        is_audit_col = (
            target_col_upper.startswith(_edh_prefixes)
            or target_col_upper.endswith(_audit_suffixes)
            or target_col_upper in _audit_column_names
            or sttm_norm["category"] == "ETL_AUDIT"
            or sttm_norm["category"] == "SEQUENCE_ID"
            or sttm_norm["category"] == "CURRENT_DATE"
        )
        if is_audit_col:
            found_in_code = pyspark_ext is not None
            result["status"] = "MATCH"
            result["drift_type"] = "none"
            result["severity"] = "INFO"
            result["pyspark"] = {
                "source_reference": pyspark_ext.source_reference if pyspark_ext else "",
                "transformation_code": pyspark_ext.transformation_code if pyspark_ext else "",
                "canonical_form": sttm_norm["canonical_expr"],
            }
            result["explanation"] = (
                f"Column '{target_col}' is an ETL audit / framework column. "
                f"{'Present in code.' if found_in_code else 'Not in code — managed by ETL framework.'} "
                f"Transformation logic is not checked as it varies by table type and use case."
            )
            result["recommended_fix"] = ""
            results.append(result)
            continue

        if pyspark_ext is None:
            # Column not found in PySpark code

            # "Field not applicable" = column not required for this table
            if sttm_norm["category"] == "NOT_APPLICABLE":
                result["status"] = "MATCH"
                result["drift_type"] = "none"
                result["severity"] = "INFO"
                result["pyspark"] = {
                    "source_reference": "",
                    "transformation_code": "",
                    "canonical_form": sttm_norm["canonical_expr"],
                }
                result["explanation"] = (
                    f"Column '{target_col}' is marked as 'Field not applicable' in STTM — "
                    f"not required for this table. Absence in code is correct."
                )
                result["recommended_fix"] = ""
                results.append(result)
                continue

            if config.is_framework_mode:
                # Framework handles it dynamically at runtime
                result["status"] = "MATCH"
                result["drift_type"] = "none"
                result["severity"] = "INFO"
                result["pyspark"] = {
                    "source_reference": "",
                    "transformation_code": f"Mapped dynamically via {config.active_framework} "
                                           f"framework at runtime",
                    "canonical_form": sttm_norm["canonical_expr"],
                }
                result["explanation"] = (
                    f"Column '{target_col}' is mapped via {config.active_framework} "
                    f"framework's dynamic config at runtime. "
                    f"STTM transformation: {transformation}"
                )
                result["recommended_fix"] = ""
            else:
                # Standard mode — missing column is a real drift
                severity = "CRITICAL"
                if is_nk:
                    severity = _bump_severity(severity)
                result["status"] = "DRIFT"
                result["drift_type"] = "missing_in_code"
                result["severity"] = severity
                result["pyspark"] = {
                    "source_reference": "",
                    "transformation_code": "",
                    "canonical_form": "",
                }
                tech_label = "code"
                if technology and technology != "pyspark":
                    tech_label = technology.upper().replace("_", " ") + " code"
                result["explanation"] = (
                    f"Column '{target_col}' is defined in STTM ({transformation}) "
                    f"but has no implementation in {tech_label}"
                )
                result["recommended_fix"] = _fix_gen(
                    target_col, transformation, transformation_rule, source_col
                )
        else:
            # Found in both — compare transformations
            pyspark_norm = normalize_pyspark_transformation(pyspark_ext)
            result["pyspark"] = {
                "source_reference": pyspark_ext.source_reference,
                "transformation_code": pyspark_ext.transformation_code,
                "canonical_form": pyspark_norm["canonical_expr"],
                "line_number": pyspark_ext.line_number,
            }

            if _categories_equivalent(sttm_norm["category"], pyspark_norm["category"]):
                drift = _deep_compare(
                    target_col, source_col, transformation, transformation_rule,
                    is_nk, sttm_norm, pyspark_norm, pyspark_ext,
                )
                result.update(drift)
            else:
                if pyspark_norm["category"] == "PLACEHOLDER":
                    result["status"] = "MATCH"
                    result["drift_type"] = "none"
                    result["severity"] = "INFO"
                    result["explanation"] = (
                        f"Column '{target_col}': PySpark uses placeholder (F.lit(None)) "
                        f"that framework fills at runtime with '{transformation}' logic"
                    )
                    result["recommended_fix"] = ""
                else:
                    severity = "HIGH"
                    if is_nk:
                        severity = _bump_severity(severity)
                    result["status"] = "DRIFT"
                    result["drift_type"] = "transformation_mismatch"
                    result["severity"] = severity
                    result["explanation"] = (
                        f"Column '{target_col}': STTM specifies '{transformation}' "
                        f"({sttm_norm['category']}) but code implements "
                        f"'{pyspark_norm['category']}' — {pyspark_ext.transformation_code}"
                    )
                    result["recommended_fix"] = _fix_gen(
                        target_col, transformation, transformation_rule, source_col
                    )

        results.append(result)

    return results


def _deep_compare(
    target_col: str,
    source_col: str,
    transformation: str,
    transformation_rule: str,
    is_nk: bool,
    sttm_norm: Dict,
    pyspark_norm: Dict,
    pyspark_ext: CodeExtraction,
) -> Dict[str, Any]:
    """Perform deep comparison when categories match — check values and sources."""

    # Literal value comparison
    if sttm_norm["category"] == "LITERAL" and transformation_rule:
        if _compare_literal_values(transformation_rule, pyspark_ext.transformation_code):
            return {
                "status": "MATCH",
                "drift_type": "none",
                "severity": "INFO",
                "explanation": (f"Column '{target_col}': STTM and PySpark match — "
                               f"{sttm_norm['category']} ({transformation_rule})"),
                "recommended_fix": "",
            }
        else:
            severity = "HIGH"
            if is_nk:
                severity = _bump_severity(severity)
            return {
                "status": "DRIFT",
                "drift_type": "rule_mismatch",
                "severity": severity,
                "explanation": (
                    f"Column '{target_col}': Literal value differs. "
                    f"STTM says {transformation_rule}, PySpark uses {pyspark_ext.transformation_code}"
                ),
                "recommended_fix": f"Update PySpark to use F.lit({transformation_rule}) for '{target_col}'",
            }

    # Source column comparison for Direct Pull
    if sttm_norm["category"] == "DIRECT_PULL" and source_col:
        pyspark_src = pyspark_ext.source_reference.upper()
        sttm_src = source_col.upper()
        if pyspark_src and pyspark_src != sttm_src:
            severity = "MEDIUM"
            if is_nk:
                severity = _bump_severity(severity)
            return {
                "status": "DRIFT",
                "drift_type": "rename_mismatch",
                "severity": severity,
                "explanation": (
                    f"Column '{target_col}': Source column mismatch. "
                    f"STTM maps from '{source_col}' but PySpark reads from '{pyspark_ext.source_reference}'"
                ),
                "recommended_fix": (f"Verify source column for '{target_col}': "
                                    f"STTM says '{source_col}', code uses '{pyspark_ext.source_reference}'"),
            }

    # Default: match
    return {
        "status": "MATCH",
        "drift_type": "none",
        "severity": "INFO",
        "explanation": f"Column '{target_col}': STTM ({sttm_norm['category']}) matches PySpark ({pyspark_norm['category']})",
        "recommended_fix": "",
    }


# ---------------------------------------------------------------------------
# 5. Report & Fix Generator
# ---------------------------------------------------------------------------

def generate_drift_report(
    results: List[Dict[str, Any]],
    sttm_metadata: Dict[str, Any],
    pyspark_metadata: Dict[str, Any],
    llm_provider: Optional[LLMProvider] = None,
) -> Dict[str, Any]:
    """Generate the structured drift report YAML."""
    total_checked = len(results)
    matches = sum(1 for r in results if r["status"] == "MATCH")
    drifts = sum(1 for r in results if r["status"] == "DRIFT")

    by_severity = {"CRITICAL": 0, "HIGH": 0, "MEDIUM": 0, "LOW": 0, "INFO": 0}
    for r in results:
        if r["status"] == "DRIFT":
            sev = r.get("severity", "INFO")
            by_severity[sev] = by_severity.get(sev, 0) + 1

    metadata = {
        "sttm_file": sttm_metadata.get("sttm_file", ""),
        "sttm_sheet": sttm_metadata.get("sttm_sheet", ""),
        "pyspark_file": pyspark_metadata.get("pyspark_file", ""),
        "target_table": sttm_metadata.get("target_table", ""),
        "source_table": sttm_metadata.get("source_table", ""),
        "run_date": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "total_sttm_mappings": sttm_metadata.get("total_sttm_mappings", 0),
        "total_pyspark_columns": pyspark_metadata.get("total_pyspark_columns", 0),
        "framework_mode": config.active_framework or "standard",
        "technology": pyspark_metadata.get("technology", "pyspark"),
        "execution_mode": "agentic" if llm_provider else "standalone",
    }

    if llm_provider:
        metadata["llm_provider"] = llm_provider.provider
        metadata["llm_model"] = llm_provider.model

    # Build matched / drifted column lists
    matched_columns = [r["target_column"] for r in results if r["status"] == "MATCH"]
    drifted_columns = [r["target_column"] for r in results if r["status"] == "DRIFT"]

    summary = {
        "total_checked": total_checked,
        "matches": matches,
        "drifts": drifts,
        "by_severity": by_severity,
        "matched_columns": matched_columns,
        "drifted_columns": drifted_columns,
    }

    if llm_provider:
        summary["llm_overrides"] = sum(1 for r in results if r.get("llm_override"))

    report = {
        "drift_report": {
            "metadata": metadata,
            "summary": summary,
            "mappings": results,
        }
    }
    return report


def save_drift_report(report: Dict, output_dir: str) -> Path:
    """Save drift report as YAML."""
    out = Path(output_dir)
    out.mkdir(parents=True, exist_ok=True)
    report_path = out / "drift_report.yaml"
    with open(report_path, "w", encoding="utf-8") as f:
        yaml.dump(report, f, default_flow_style=False, sort_keys=False, allow_unicode=True)
    logger.info(f"Drift report saved to: {report_path}")

    # Also generate structured Excel report
    _save_drift_report_excel(report, out)

    return report_path


def _save_drift_report_excel(report: Dict, output_dir: Path) -> Path:
    """Generate an Excel drift report with 3 tabs: Summary, Matched, Drifted."""
    from openpyxl.styles import Font, PatternFill, Alignment, Border, Side

    wb = openpyxl.Workbook()

    dr = report["drift_report"]
    metadata = dr["metadata"]
    summary = dr["summary"]
    mappings = dr["mappings"]

    # --- Styling ---
    header_font = Font(bold=True, color="FFFFFF", size=11)
    header_fill = PatternFill(start_color="2F5496", end_color="2F5496", fill_type="solid")
    match_fill = PatternFill(start_color="C6EFCE", end_color="C6EFCE", fill_type="solid")
    drift_fill = PatternFill(start_color="FFC7CE", end_color="FFC7CE", fill_type="solid")
    info_fill = PatternFill(start_color="BDD7EE", end_color="BDD7EE", fill_type="solid")
    label_font = Font(bold=True, size=11)
    thin_border = Border(
        left=Side(style="thin"), right=Side(style="thin"),
        top=Side(style="thin"), bottom=Side(style="thin"),
    )
    wrap_align = Alignment(wrap_text=True, vertical="top")

    def _style_header(ws, row_num, max_col):
        for col in range(1, max_col + 1):
            cell = ws.cell(row=row_num, column=col)
            cell.font = header_font
            cell.fill = header_fill
            cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
            cell.border = thin_border

    def _auto_width(ws, min_width=12, max_width=50):
        for col in ws.columns:
            col_letter = col[0].column_letter
            max_len = 0
            for cell in col:
                if cell.value:
                    max_len = max(max_len, min(len(str(cell.value)), max_width))
            ws.column_dimensions[col_letter].width = max(min_width, max_len + 2)

    # =====================================================================
    # TAB 1: Summary
    # =====================================================================
    ws_summary = wb.active
    ws_summary.title = "Summary"

    section_font = Font(bold=True, size=12, color="2F5496")
    table_header_font = Font(bold=True, color="FFFFFF", size=10)
    table_header_fill = PatternFill(start_color="2F5496", end_color="2F5496", fill_type="solid")
    gray_fill = PatternFill(start_color="F2F2F2", end_color="F2F2F2", fill_type="solid")

    def _write_table(ws, start_row, headers, rows, col_fills=None):
        """Write a bordered table with styled header row."""
        # Header
        for c, h in enumerate(headers, 1):
            cell = ws.cell(row=start_row, column=c, value=h)
            cell.font = table_header_font
            cell.fill = table_header_fill
            cell.alignment = Alignment(horizontal="center", vertical="center")
            cell.border = thin_border
        # Data rows
        for r_idx, row_data in enumerate(rows):
            row_num = start_row + 1 + r_idx
            for c, val in enumerate(row_data, 1):
                cell = ws.cell(row=row_num, column=c, value=val)
                cell.border = thin_border
                cell.alignment = Alignment(vertical="top", wrap_text=True)
                # Alternate row shading
                if r_idx % 2 == 1:
                    cell.fill = gray_fill
                # Apply custom fill if specified
                if col_fills and c in col_fills:
                    fill_fn = col_fills[c]
                    if callable(fill_fn):
                        custom_fill = fill_fn(val)
                        if custom_fill:
                            cell.fill = custom_fill
        return start_row + 1 + len(rows)

    # --- Title ---
    ws_summary.merge_cells("A1:C1")
    title_cell = ws_summary.cell(row=1, column=1, value="STTM Drift Detection Report")
    title_cell.font = Font(bold=True, size=16, color="2F5496")
    title_cell.alignment = Alignment(horizontal="center")

    # --- Table 1: Run Metadata ---
    ws_summary.cell(row=3, column=1, value="Run Details").font = section_font
    meta_rows = [
        ["Target Table", metadata.get("target_table", "")],
        ["STTM File", metadata.get("sttm_file", "")],
        ["Code File", metadata.get("pyspark_file", "")],
        ["Technology", metadata.get("technology", "")],
        ["Run Date", metadata.get("run_date", "")],
        ["Execution Mode", metadata.get("execution_mode", "")],
    ]
    next_row = _write_table(ws_summary, 4, ["Parameter", "Value"], meta_rows)

    # --- Table 2: Drift Summary ---
    ws_summary.cell(row=next_row + 1, column=1, value="Drift Summary").font = section_font
    total_checked = summary.get("total_checked", 0)
    matches_count = summary.get("matches", 0)
    drifts_count = summary.get("drifts", 0)
    match_pct = f"{matches_count / total_checked * 100:.1f}%" if total_checked else "0%"
    drift_pct = f"{drifts_count / total_checked * 100:.1f}%" if total_checked else "0%"
    summary_rows = [
        ["Total STTM Mappings", metadata.get("total_sttm_mappings", 0), ""],
        ["Total Code Extractions", metadata.get("total_pyspark_columns", 0), ""],
        ["Columns Checked", total_checked, ""],
        ["Matched", matches_count, match_pct],
        ["Drifted", drifts_count, drift_pct],
    ]

    def _status_fill(val):
        if val == "Matched":
            return match_fill
        if val == "Drifted" and drifts_count > 0:
            return drift_fill
        return None

    next_row = _write_table(
        ws_summary, next_row + 2, ["Metric", "Count", "%"],
        summary_rows,
        col_fills={1: _status_fill},
    )
    # Color the Matched/Drifted count cells
    for r in range(next_row - 2, next_row):
        cell_a = ws_summary.cell(row=r, column=1)
        cell_b = ws_summary.cell(row=r, column=2)
        if cell_a.value == "Matched":
            cell_b.fill = match_fill
        elif cell_a.value == "Drifted" and drifts_count > 0:
            cell_b.fill = drift_fill

    # --- Table 3: Severity Breakdown ---
    by_sev = summary.get("by_severity", {})
    if any(v > 0 for v in by_sev.values()):
        ws_summary.cell(row=next_row + 1, column=1, value="Severity Breakdown").font = section_font
        sev_rows = [[sev, count] for sev, count in by_sev.items() if count > 0]

        sev_fill_map = {
            "CRITICAL": PatternFill(start_color="FF0000", end_color="FF0000", fill_type="solid"),
            "HIGH": PatternFill(start_color="FFC000", end_color="FFC000", fill_type="solid"),
            "MEDIUM": PatternFill(start_color="FFFF00", end_color="FFFF00", fill_type="solid"),
            "LOW": PatternFill(start_color="BDD7EE", end_color="BDD7EE", fill_type="solid"),
        }

        next_row = _write_table(
            ws_summary, next_row + 2, ["Severity", "Count"], sev_rows,
        )
        # Color severity cells
        for r_idx, (sev, _) in enumerate(sev_rows):
            cell = ws_summary.cell(row=next_row - len(sev_rows) + r_idx, column=1)
            if sev in sev_fill_map:
                cell.fill = sev_fill_map[sev]
                if sev == "CRITICAL":
                    cell.font = Font(bold=True, color="FFFFFF")

    # --- Table 4: Matched Columns (names only) ---
    matched = summary.get("matched_columns", [])
    if matched:
        ws_summary.cell(row=next_row + 1, column=1, value="Matched Columns").font = section_font
        matched_rows = [[col_name] for col_name in matched]
        next_row = _write_table(
            ws_summary, next_row + 2, ["Column Name"], matched_rows,
        )
        for r_idx in range(len(matched_rows)):
            ws_summary.cell(row=next_row - len(matched_rows) + r_idx, column=1).fill = match_fill

    # --- Table 5: Drifted Columns (names only) ---
    drifted = summary.get("drifted_columns", [])
    if drifted:
        ws_summary.cell(row=next_row + 1, column=1, value="Drifted Columns").font = section_font
        drift_rows = [[col_name] for col_name in drifted]
        next_row = _write_table(
            ws_summary, next_row + 2, ["Column Name"], drift_rows,
        )
        for r_idx in range(len(drift_rows)):
            ws_summary.cell(row=next_row - len(drift_rows) + r_idx, column=1).fill = drift_fill

    # Set column widths
    ws_summary.column_dimensions["A"].width = 30
    ws_summary.column_dimensions["B"].width = 25
    ws_summary.column_dimensions["C"].width = 55
    ws_summary.column_dimensions["D"].width = 55

    # =====================================================================
    # TAB 2: Matched Columns
    # =====================================================================
    ws_matched = wb.create_sheet("Matched Columns")
    matched_headers = [
        "Target Column", "Source Column", "STTM Transformation",
        "Code Transformation", "Explanation",
    ]
    ws_matched.append(matched_headers)
    _style_header(ws_matched, 1, len(matched_headers))

    for m in mappings:
        if m.get("status") != "MATCH":
            continue
        sttm = m.get("sttm", {})
        pyspark = m.get("pyspark", {})
        ws_matched.append([
            m.get("target_column", ""),
            sttm.get("source_column", ""),
            sttm.get("transformation", "") or sttm.get("transformation_rule", ""),
            pyspark.get("canonical_form", "") or pyspark.get("transformation_code", ""),
            m.get("explanation", ""),
        ])
        row = ws_matched.max_row
        for col in range(1, len(matched_headers) + 1):
            ws_matched.cell(row=row, column=col).fill = match_fill
            ws_matched.cell(row=row, column=col).border = thin_border
            ws_matched.cell(row=row, column=col).alignment = wrap_align

    _auto_width(ws_matched)

    # =====================================================================
    # TAB 3: Drifted Columns
    # =====================================================================
    ws_drifted = wb.create_sheet("Drifted Columns")
    drift_headers = [
        "Target Column", "Severity", "Drift Type", "Source Column",
        "STTM Transformation", "STTM Rule",
        "Code Found", "Code Transformation",
        "Issue", "Recommended Fix",
    ]
    ws_drifted.append(drift_headers)
    _style_header(ws_drifted, 1, len(drift_headers))

    sev_colors = {
        "CRITICAL": PatternFill(start_color="FF0000", end_color="FF0000", fill_type="solid"),
        "HIGH": PatternFill(start_color="FFC000", end_color="FFC000", fill_type="solid"),
        "MEDIUM": PatternFill(start_color="FFFF00", end_color="FFFF00", fill_type="solid"),
        "LOW": PatternFill(start_color="BDD7EE", end_color="BDD7EE", fill_type="solid"),
    }

    for m in mappings:
        if m.get("status") != "DRIFT":
            continue
        sttm = m.get("sttm", {})
        pyspark = m.get("pyspark", {})
        severity = m.get("severity", "")
        code_found = "Yes" if pyspark.get("transformation_code") else "No"
        code_transform = pyspark.get("canonical_form", "") or pyspark.get("transformation_code", "")

        ws_drifted.append([
            m.get("target_column", ""),
            severity,
            m.get("drift_type", ""),
            sttm.get("source_column", ""),
            sttm.get("transformation", ""),
            sttm.get("transformation_rule", ""),
            code_found,
            code_transform,
            m.get("explanation", ""),
            m.get("recommended_fix", ""),
        ])
        row = ws_drifted.max_row
        for col in range(1, len(drift_headers) + 1):
            cell = ws_drifted.cell(row=row, column=col)
            cell.border = thin_border
            cell.alignment = wrap_align
        # Color the severity cell
        sev_cell = ws_drifted.cell(row=row, column=2)
        if severity in sev_colors:
            sev_cell.fill = sev_colors[severity]
            if severity == "CRITICAL":
                sev_cell.font = Font(bold=True, color="FFFFFF")

    _auto_width(ws_drifted)

    # Save
    excel_path = output_dir / "drift_report.xlsx"
    wb.save(str(excel_path))
    logger.info(f"Excel drift report saved to: {excel_path}")
    return excel_path


def generate_updated_pyspark(
    pyspark_path: str,
    results: List[Dict[str, Any]],
    output_dir: str,
) -> Optional[Path]:
    """Generate updated PySpark job with corrections for drifts found."""
    drift_results = [r for r in results if r["status"] == "DRIFT"]
    if not drift_results:
        logger.info("No drifts found — PySpark code is aligned with STTM spec")
        return None

    code = Path(pyspark_path).read_text(encoding="utf-8")

    patch_lines = [
        "",
        "# " + "=" * 70,
        "# DRIFT PATCHES — Auto-generated by detect_drift.py",
        "# STTM is the source of truth. The following patches align code with spec.",
        "# Review each patch and apply to the correct location.",
        "# " + "=" * 70,
    ]

    for drift in drift_results:
        target_col = drift["target_column"]
        sttm_info = drift.get("sttm", {})
        transformation = sttm_info.get("transformation", "")
        rule = sttm_info.get("transformation_rule", "")
        source_col = sttm_info.get("source_column", "")
        pyspark_info = drift.get("pyspark", {})
        line_num = pyspark_info.get("line_number", "")

        patch_lines.append("")
        patch_lines.append(f"# DRIFT [{drift['severity']}]: {drift['drift_type']} for column '{target_col}'")
        patch_lines.append(f"# STTM spec: {transformation}" + (f" — rule: {rule}" if rule else ""))
        if line_num:
            patch_lines.append(f"# Current code at line {line_num}: {pyspark_info.get('transformation_code', '')}")
        patch_lines.append(f"# Explanation: {drift.get('explanation', '')}")

        pyspark_fix = _generate_pyspark_fix(target_col, transformation, rule, source_col)
        if pyspark_fix:
            patch_lines.append(f"# Fix:")
            patch_lines.append(f"# {pyspark_fix}")

    patched_code = code + "\n".join(patch_lines) + "\n"

    out_path = Path(output_dir) / "updated_pyspark_job.py"
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(patched_code, encoding="utf-8")
    logger.info(f"Updated PySpark job saved to: {out_path}")
    return out_path


def _generate_pyspark_fix(
    target_col: str, transformation: str, rule: str, source_col: str,
) -> str:
    """Generate a PySpark code fix for a given STTM transformation."""
    tf_lower = transformation.lower()
    src = source_col or "SOURCE_COL"
    fixes = {
        # Core
        "direct pull": (f'df = df.withColumnRenamed("{source_col}", "{target_col}")'
                        if source_col else f'# Direct Pull for {target_col} — verify source column'),
        "current date": f'df = df.withColumn("{target_col}", F.current_date())',
        "sysdate": f'df = df.withColumn("{target_col}", F.current_date())',
        "custom/default": f'df = df.withColumn("{target_col}", F.lit({rule}))',
        "sequence generated id": f'df = df.withColumn("{target_col}", F.monotonically_increasing_id())',
        "etl audit field": f'# ETL Audit Field for {target_col}: {rule}',
        "convert date format": f'df = df.withColumn("{target_col}", F.to_date(F.col("{src}")))',
        "convert datatype": f'df = df.withColumn("{target_col}", F.col("{src}").cast({rule or "StringType()"}))',
        "md5": f'df = df.withColumn("{target_col}", F.md5(F.concat_ws("", *key_cols)))',
        "lookup": f'# Lookup for {target_col}: {rule} — implement join logic',
        "trim": f'df = df.withColumn("{target_col}", F.trim(F.col("{src}")))',
        "count": f'df = df.withColumn("{target_col}", F.lit(df.count()))',
        # String
        "upper case": f'df = df.withColumn("{target_col}", F.upper(F.col("{src}")))',
        "lower case": f'df = df.withColumn("{target_col}", F.lower(F.col("{src}")))',
        "initcap": f'df = df.withColumn("{target_col}", F.initcap(F.col("{src}")))',
        "coalesce": f'df = df.withColumn("{target_col}", F.coalesce(F.col("{src}"), F.lit({rule})))',
        "concatenate": f'df = df.withColumn("{target_col}", F.concat_ws("", {rule}))',
        "substring": f'df = df.withColumn("{target_col}", F.substring(F.col("{src}"), 1, {rule or "N"}))',
        "replace": f'df = df.withColumn("{target_col}", F.when(F.col("{src}") == old_val, new_val).otherwise(F.col("{src}")))',
        "regex": f'df = df.withColumn("{target_col}", F.regexp_replace(F.col("{src}"), {rule}))',
        "regex replace": f'df = df.withColumn("{target_col}", F.regexp_replace(F.col("{src}"), {rule}))',
        # Conditional
        "case/when": f'df = df.withColumn("{target_col}", F.when({rule}))',
        "if else": f'df = df.withColumn("{target_col}", F.when({rule}, true_val).otherwise(false_val))',
        "email validation": f'df = df.withColumn("{target_col}", F.when(F.col("{src}").rlike(email_pattern), F.col("{src}")).otherwise(None))',
        # Arithmetic
        "average": f'df = df.withColumn("{target_col}", F.lit(df.agg({{"{src}": "avg"}}).collect()[0][0]))',
        "sum": f'df = df.withColumn("{target_col}", F.lit(df.agg({{"{src}": "sum"}}).collect()[0][0]))',
        "min": f'df = df.withColumn("{target_col}", F.lit(df.agg({{"{src}": "min"}}).collect()[0][0]))',
        "max": f'df = df.withColumn("{target_col}", F.lit(df.agg({{"{src}": "max"}}).collect()[0][0]))',
        "abs": f'df = df.withColumn("{target_col}", F.abs(F.col("{src}")))',
        "multiply": f'df = df.withColumn("{target_col}", F.col("col_1") * F.col("col_2"))  # {rule}',
        "divide": f'df = df.withColumn("{target_col}", F.col("col_1") / F.col("col_2"))  # {rule}',
        "subtract": f'df = df.withColumn("{target_col}", F.col("col_1") - F.col("col_2"))  # {rule}',
        "percentage": f'df = df.withColumn("{target_col}", (F.col("col_1") / F.col("col_2")) * 100)  # {rule}',
        # Specialized
        "rownum": f'df = df.withColumn("{target_col}", F.row_number().over(Window.orderBy(...)))',
        "parametrized batch date": f'df = df.withColumn("{target_col}", F.lit(batch_date))',
        "timezone conversion": f'# Timezone conversion for {target_col}: {rule}',
        "nlq": f'# NLQ transformation for {target_col}: {rule}',
    }
    return fixes.get(tf_lower, f'# {transformation}: {rule}')


# ---------------------------------------------------------------------------
# 5b. Multi-Technology Parsers & Fix Generators
# ---------------------------------------------------------------------------
# Each technology provides:
#   parse_<tech>()  -> Tuple[List[CodeExtraction], Dict metadata]
#   generate_<tech>_fix() -> str (corrective code snippet)

TECHNOLOGY_LABELS = {
    "pyspark": "PySpark",
    "dbt": "DBT (SQL)",
    "adf": "Azure Data Factory",
    "synapse": "Azure Synapse SQL",
    "databricks_sql": "Databricks SQL",
    "glue": "AWS Glue (Python)",
    "scala_spark": "Scala Spark",
}


def detect_technology(code_path: str, code_content: str) -> str:
    """Auto-detect technology from file extension and content."""
    ext = Path(code_path).suffix.lower()
    name = Path(code_path).name.lower()

    # File extension checks
    if ext == ".scala":
        return "scala_spark"
    if ext == ".json" and ('"pipeline"' in code_content or '"activities"' in code_content):
        return "adf"

    # SQL files — determine which SQL flavor
    if ext == ".sql":
        content_lower = code_content.lower()
        if "{{" in code_content and ("ref(" in content_lower or "source(" in content_lower):
            return "dbt"
        if "create or alter procedure" in content_lower or "nvarchar" in content_lower:
            return "synapse"
        if "create widget" in content_lower or "dbutils" in content_lower:
            return "databricks_sql"
        # Default SQL → dbt (most common)
        return "dbt"

    # Python files — detect variant
    if ext == ".py":
        content_lower = code_content.lower()
        if "dynamicframe" in content_lower or "gluecontext" in content_lower or "from awsglue" in content_lower:
            return "glue"
        return "pyspark"

    # YAML/YML → check for ADF ARM template
    if ext in (".yml", ".yaml"):
        if '"Microsoft.DataFactory"' in code_content or "type: Pipeline" in code_content:
            return "adf"

    return "pyspark"  # default fallback


# ---- DBT SQL Parser ----

def _find_final_select(code: str) -> str:
    """Find the final (outermost) SELECT statement in SQL with CTEs.

    In DBT models the pattern is: WITH cte1 AS (...), cte2 AS (...) SELECT ...
    We want the last SELECT that isn't inside a CTE.
    """
    # Remove Jinja comments
    cleaned = re.sub(r'\{#.*?#\}', '', code, flags=re.DOTALL)
    # Remove SQL block comments
    cleaned = re.sub(r'/\*.*?\*/', '', cleaned, flags=re.DOTALL)
    # Remove single-line comments
    cleaned = re.sub(r'--[^\n]*', '', cleaned)

    # Find all SELECT positions, tracking parenthesis depth
    # The final SELECT at depth 0 is our target
    upper = cleaned.upper()
    depth = 0
    last_select_at_depth0 = -1
    i = 0
    while i < len(upper):
        if upper[i] == '(':
            depth += 1
        elif upper[i] == ')':
            depth = max(0, depth - 1)
        elif upper[i:i+6] == 'SELECT' and depth == 0:
            # Verify it's a keyword (not part of a word)
            before_ok = (i == 0 or not upper[i-1].isalnum())
            after_ok = (i + 6 >= len(upper) or not upper[i+6].isalnum())
            if before_ok and after_ok:
                last_select_at_depth0 = i
        i += 1

    if last_select_at_depth0 >= 0:
        return cleaned[last_select_at_depth0:]
    return cleaned


def _parse_dbt_sql(code: str, lines: List[str]) -> List[CodeExtraction]:
    """Parse a DBT .sql model file and extract column mappings from SELECT statements."""
    extractions: List[CodeExtraction] = []
    seen: set = set()

    # Focus on the final SELECT (skip CTE definitions)
    final_select = _find_final_select(code)

    # Split the final SELECT into individual column expressions.
    # Strategy: find the column list between SELECT and FROM, then split by
    # top-level commas (not inside parentheses).
    upper_fs = final_select.upper()
    from_pos = -1
    depth = 0
    for i, ch in enumerate(upper_fs):
        if ch == '(':
            depth += 1
        elif ch == ')':
            depth = max(0, depth - 1)
        elif depth == 0 and upper_fs[i:i+4] == 'FROM' and (i == 0 or not upper_fs[i-1].isalnum()):
            if i + 4 >= len(upper_fs) or not upper_fs[i+4].isalnum():
                from_pos = i
                break

    if from_pos < 0:
        return extractions

    select_body = final_select[6:from_pos].strip()  # Skip "SELECT"

    # Split by top-level commas
    col_exprs: List[str] = []
    depth = 0
    current = []
    for ch in select_body:
        if ch == '(':
            depth += 1
            current.append(ch)
        elif ch == ')':
            depth = max(0, depth - 1)
            current.append(ch)
        elif ch == ',' and depth == 0:
            col_exprs.append(''.join(current).strip())
            current = []
        else:
            current.append(ch)
    if current:
        col_exprs.append(''.join(current).strip())

    # Now parse each column expression for the final AS alias
    for expr_raw in col_exprs:
        expr = expr_raw.strip()
        if not expr:
            continue

        # Normalize whitespace
        expr_clean = re.sub(r'\s+', ' ', expr)

        # Find the LAST top-level AS (not inside parens/cast)
        # We search right-to-left for " AS " at depth 0
        tokens = expr_clean
        alias = None
        expr_part = expr_clean
        depth = 0
        for i in range(len(tokens) - 1, 2, -1):
            if tokens[i] == ')':
                depth += 1
            elif tokens[i] == '(':
                depth = max(0, depth - 1)
            elif depth == 0 and tokens[i-3:i+1].upper() == ' AS ':
                rest = tokens[i+1:].strip()
                # The alias should be a simple identifier
                alias_match = re.match(r'^([A-Za-z_]\w*)', rest)
                if alias_match:
                    alias = alias_match.group(1)
                    expr_part = tokens[:i-3].strip()
                    break

        if not alias:
            # Try simpler pattern: last word after last top-level AS
            as_match = re.search(r'\bAS\s+([A-Za-z_]\w*)\s*$', expr_clean, re.IGNORECASE)
            if as_match:
                alias = as_match.group(1)
                expr_part = expr_clean[:as_match.start()].strip()

        if not alias:
            continue

        key = alias.upper()
        skip_keywords = {"SELECT", "FROM", "WHERE", "GROUP", "ORDER", "HAVING",
                         "LIMIT", "JOIN", "LEFT", "RIGHT", "INNER", "OUTER",
                         "CROSS", "ON", "AND", "OR", "INTO", "BY", "SET",
                         "VARCHAR", "INT", "BIGINT", "TIMESTAMP", "DATE",
                         "BOOLEAN", "FLOAT", "DOUBLE", "DECIMAL", "NUMERIC"}
        if key in seen or key in skip_keywords:
            continue
        seen.add(key)

        # Determine line number (search original code for the alias)
        line_num = 0
        alias_pattern = re.compile(r'\bAS\s+' + re.escape(alias) + r'\b', re.IGNORECASE)
        for li, line in enumerate(lines, 1):
            if alias_pattern.search(line):
                line_num = li
                break

        # Extract source reference from expression
        source_ref = ""
        # Simple column: table.column or just column
        col_match = re.match(r'^(?:\w+\.)?(\w+)$', expr_part)
        if col_match:
            source_ref = col_match.group(1)
        else:
            # Inside cast(): cast(table.column as type)
            cast_match = re.match(r"(?i)cast\s*\(\s*(?:\w+\.)?(\w+)\s+as\s+", expr_part)
            if cast_match:
                source_ref = cast_match.group(1)

        extractions.append(CodeExtraction(
            target_column=alias,
            source_reference=source_ref,
            transformation_code=expr_part,
            line_number=line_num,
            context="dbt_model",
        ))

    return extractions


def parse_dbt(code_path: str) -> Tuple[List[CodeExtraction], Dict[str, Any]]:
    """Parse a DBT SQL model file."""
    code = Path(code_path).read_text(encoding="utf-8")
    lines = code.split("\n")
    extractions = _parse_dbt_sql(code, lines)
    metadata = {
        "pyspark_file": str(code_path),
        "total_pyspark_columns": len(extractions),
        "source_type": "dbt_sql",
        "technology": "dbt",
    }
    logger.info(f"Extracted {len(extractions)} column mappings from DBT model")
    return extractions, metadata


def _generate_dbt_fix(
    target_col: str, transformation: str, rule: str, source_col: str,
) -> str:
    """Generate a DBT SQL fix for a given STTM transformation."""
    tf_lower = transformation.lower()
    src = source_col or "SOURCE_COL"
    fixes = {
        "direct pull": f'{src} AS {target_col}' if source_col else f'-- Direct Pull for {target_col}: verify source column',
        "current date": f'CURRENT_DATE() AS {target_col}',
        "sysdate": f'CURRENT_DATE() AS {target_col}',
        "custom/default": f"'{rule}' AS {target_col}" if rule else f"-- Custom/Default for {target_col}",
        "sequence generated id": f'ROW_NUMBER() OVER (ORDER BY 1) AS {target_col}',
        "convert date format": f'TO_DATE({src}) AS {target_col}',
        "convert datatype": f'CAST({src} AS {rule or "VARCHAR"}) AS {target_col}',
        "md5": f'MD5(CONCAT_WS("", key_cols)) AS {target_col}',
        "lookup": f'-- Lookup JOIN for {target_col}: {rule}',
        "trim": f'TRIM({src}) AS {target_col}',
        "upper case": f'UPPER({src}) AS {target_col}',
        "lower case": f'LOWER({src}) AS {target_col}',
        "initcap": f'INITCAP({src}) AS {target_col}',
        "coalesce": f'COALESCE({src}, {rule}) AS {target_col}',
        "concatenate": f'CONCAT({rule}) AS {target_col}',
        "substring": f'SUBSTRING({src}, 1, {rule or "N"}) AS {target_col}',
        "case/when": f'CASE WHEN {rule} END AS {target_col}',
        "if else": f'CASE WHEN condition THEN true_val ELSE false_val END AS {target_col}',
        "count": f'COUNT(*) AS {target_col}',
        "sum": f'SUM({src}) AS {target_col}',
        "average": f'AVG({src}) AS {target_col}',
        "min": f'MIN({src}) AS {target_col}',
        "max": f'MAX({src}) AS {target_col}',
        "abs": f'ABS({src}) AS {target_col}',
        "replace": f"REPLACE({src}, old_val, new_val) AS {target_col}",
        "regex replace": f'REGEXP_REPLACE({src}, {rule}) AS {target_col}',
    }
    return fixes.get(tf_lower, f'-- {transformation}: {rule} AS {target_col}')


# ---- Azure Data Factory Parser ----

def _parse_adf_json(code: str) -> List[CodeExtraction]:
    """Parse an Azure Data Factory pipeline JSON and extract column mappings."""
    import json as json_mod
    extractions: List[CodeExtraction] = []
    seen: set = set()

    try:
        pipeline = json_mod.loads(code)
    except json_mod.JSONDecodeError:
        logger.warning("Could not parse ADF pipeline JSON")
        return extractions

    def _walk_mappings(obj, path=""):
        """Recursively find column mappings in ADF pipeline JSON."""
        if isinstance(obj, dict):
            # Copy Activity / Data Flow column mappings
            if "source" in obj and "sink" in obj:
                src_name = ""
                tgt_name = ""
                if isinstance(obj["source"], dict):
                    src_name = obj["source"].get("name", obj["source"].get("physicalName", ""))
                if isinstance(obj["sink"], dict):
                    tgt_name = obj["sink"].get("name", obj["sink"].get("physicalName", ""))
                if tgt_name:
                    key = tgt_name.upper()
                    if key not in seen:
                        seen.add(key)
                        extractions.append(CodeExtraction(
                            target_column=tgt_name,
                            source_reference=src_name,
                            transformation_code=f"source: {src_name} -> sink: {tgt_name}",
                            line_number=0,
                            context=path or "adf_mapping",
                        ))
            # Data Flow transformations with script
            if "script" in obj and isinstance(obj["script"], str):
                _parse_adf_dataflow_script(obj["script"], extractions, seen)
            # Translator mappings
            if "translator" in obj and isinstance(obj["translator"], dict):
                mappings = obj["translator"].get("mappings", [])
                for m in mappings:
                    src = m.get("source", {})
                    sink = m.get("sink", {})
                    src_name = src.get("name", "") if isinstance(src, dict) else ""
                    tgt_name = sink.get("name", "") if isinstance(sink, dict) else ""
                    if tgt_name:
                        key = tgt_name.upper()
                        if key not in seen:
                            seen.add(key)
                            extractions.append(CodeExtraction(
                                target_column=tgt_name,
                                source_reference=src_name,
                                transformation_code=f"translator: {src_name} -> {tgt_name}",
                                line_number=0,
                                context="adf_translator",
                            ))
            for k, v in obj.items():
                _walk_mappings(v, f"{path}.{k}" if path else k)
        elif isinstance(obj, list):
            for i, item in enumerate(obj):
                _walk_mappings(item, f"{path}[{i}]")

    _walk_mappings(pipeline)
    return extractions


def _parse_adf_dataflow_script(script: str, extractions: List[CodeExtraction], seen: set):
    """Parse ADF Data Flow script expressions for column mappings."""
    # Pattern: column = expression in derive/select transformations
    derive_pattern = re.compile(r'(\w+)\s*=\s*(.+?)(?:,\s*$|\s*$)', re.MULTILINE)
    for m in derive_pattern.finditer(script):
        tgt = m.group(1).strip()
        expr = m.group(2).strip()
        key = tgt.upper()
        if key not in seen and key not in ("TRUE", "FALSE", "NULL"):
            seen.add(key)
            source_ref = ""
            col_match = re.match(r'^(\w+)$', expr)
            if col_match:
                source_ref = col_match.group(1)
            extractions.append(CodeExtraction(
                target_column=tgt,
                source_reference=source_ref,
                transformation_code=expr,
                line_number=0,
                context="adf_dataflow",
            ))


def parse_adf(code_path: str) -> Tuple[List[CodeExtraction], Dict[str, Any]]:
    """Parse an Azure Data Factory pipeline JSON."""
    code = Path(code_path).read_text(encoding="utf-8")
    extractions = _parse_adf_json(code)
    metadata = {
        "pyspark_file": str(code_path),
        "total_pyspark_columns": len(extractions),
        "source_type": "adf_pipeline",
        "technology": "adf",
    }
    logger.info(f"Extracted {len(extractions)} column mappings from ADF pipeline")
    return extractions, metadata


def _generate_adf_fix(
    target_col: str, transformation: str, rule: str, source_col: str,
) -> str:
    """Generate an ADF mapping fix for a given STTM transformation."""
    tf_lower = transformation.lower()
    src = source_col or "SOURCE_COL"
    fixes = {
        "direct pull": f'{{"source": {{"name": "{src}"}}, "sink": {{"name": "{target_col}"}}}}',
        "current date": f'{{"sink": {{"name": "{target_col}"}}, "expression": "currentDate()"}}',
        "custom/default": f'{{"sink": {{"name": "{target_col}"}}, "expression": "\'{rule}\'"}}',
        "convert date format": f'{{"sink": {{"name": "{target_col}"}}, "expression": "toDate({src})"}}',
        "convert datatype": f'{{"sink": {{"name": "{target_col}"}}, "expression": "toString({src})"}}',
        "trim": f'{{"sink": {{"name": "{target_col}"}}, "expression": "trim({src})"}}',
        "upper case": f'{{"sink": {{"name": "{target_col}"}}, "expression": "upper({src})"}}',
        "lower case": f'{{"sink": {{"name": "{target_col}"}}, "expression": "lower({src})"}}',
        "coalesce": f'{{"sink": {{"name": "{target_col}"}}, "expression": "coalesce({src}, {rule})"}}',
        "lookup": f'# Lookup activity needed for {target_col}: {rule}',
    }
    return fixes.get(tf_lower, f'# ADF mapping for {target_col}: {transformation} — {rule}')


# ---- Azure Synapse SQL Parser ----

def _parse_synapse_sql(code: str, lines: List[str]) -> List[CodeExtraction]:
    """Parse Azure Synapse SQL (T-SQL) stored procedures/scripts for column mappings."""
    extractions: List[CodeExtraction] = []
    seen: set = set()

    # Same SQL extraction patterns as DBT but also handle T-SQL specifics
    # Pattern: expression AS [alias] or expression AS alias
    select_pattern = re.compile(
        r"""
        (?:^|,)\s*
        ([^,\n]+?)                          # expression
        \s+[Aa][Ss]\s+
        \[?([A-Za-z_]\w*)\]?               # alias (may be bracketed [col])
        """,
        re.VERBOSE | re.MULTILINE,
    )

    for m in select_pattern.finditer(code):
        expr = m.group(1).strip()
        alias = m.group(2).strip()
        key = alias.upper()
        if key in seen or key in ("SELECT", "FROM", "WHERE", "GROUP", "ORDER", "HAVING", "BEGIN", "END", "SET"):
            continue
        seen.add(key)
        pos = m.start()
        line_num = code[:pos].count('\n') + 1
        source_ref = ""
        col_match = re.match(r'^(?:\[?\w+\]?\.)?(\[?\w+\]?)$', expr)
        if col_match:
            source_ref = col_match.group(1).strip("[]")
        extractions.append(CodeExtraction(
            target_column=alias,
            source_reference=source_ref,
            transformation_code=expr,
            line_number=line_num,
            context="synapse_sql",
        ))

    # Also handle INSERT INTO ... SELECT patterns
    # and MERGE ... WHEN MATCHED THEN UPDATE SET target = source patterns
    merge_pattern = re.compile(
        r'(?:SET|THEN\s+UPDATE\s+SET)\s+\[?(\w+)\]?\s*=\s*(?:source\.)?\[?(\w+)\]?',
        re.IGNORECASE,
    )
    for m in merge_pattern.finditer(code):
        tgt = m.group(1).strip()
        src = m.group(2).strip()
        key = tgt.upper()
        if key not in seen:
            seen.add(key)
            pos = m.start()
            line_num = code[:pos].count('\n') + 1
            extractions.append(CodeExtraction(
                target_column=tgt,
                source_reference=src,
                transformation_code=f"{src} -> {tgt} (MERGE SET)",
                line_number=line_num,
                context="synapse_merge",
            ))

    return extractions


def parse_synapse(code_path: str) -> Tuple[List[CodeExtraction], Dict[str, Any]]:
    """Parse an Azure Synapse SQL file."""
    code = Path(code_path).read_text(encoding="utf-8")
    lines = code.split("\n")
    extractions = _parse_synapse_sql(code, lines)
    metadata = {
        "pyspark_file": str(code_path),
        "total_pyspark_columns": len(extractions),
        "source_type": "synapse_sql",
        "technology": "synapse",
    }
    logger.info(f"Extracted {len(extractions)} column mappings from Synapse SQL")
    return extractions, metadata


def _generate_synapse_fix(
    target_col: str, transformation: str, rule: str, source_col: str,
) -> str:
    """Generate Azure Synapse T-SQL fix."""
    tf_lower = transformation.lower()
    src = source_col or "SOURCE_COL"
    fixes = {
        "direct pull": f'[{src}] AS [{target_col}]',
        "current date": f'GETDATE() AS [{target_col}]',
        "sysdate": f'GETDATE() AS [{target_col}]',
        "custom/default": f"'{rule}' AS [{target_col}]",
        "sequence generated id": f'ROW_NUMBER() OVER (ORDER BY (SELECT NULL)) AS [{target_col}]',
        "convert date format": f'CONVERT(DATE, [{src}]) AS [{target_col}]',
        "convert datatype": f'CAST([{src}] AS {rule or "NVARCHAR(MAX)"}) AS [{target_col}]',
        "md5": f'HASHBYTES(\'MD5\', CONCAT(key_cols)) AS [{target_col}]',
        "trim": f'LTRIM(RTRIM([{src}])) AS [{target_col}]',
        "upper case": f'UPPER([{src}]) AS [{target_col}]',
        "lower case": f'LOWER([{src}]) AS [{target_col}]',
        "coalesce": f'COALESCE([{src}], {rule}) AS [{target_col}]',
        "case/when": f'CASE WHEN {rule} END AS [{target_col}]',
        "substring": f'SUBSTRING([{src}], 1, {rule or "N"}) AS [{target_col}]',
        "replace": f"REPLACE([{src}], old_val, new_val) AS [{target_col}]",
        "count": f'COUNT(*) AS [{target_col}]',
        "sum": f'SUM([{src}]) AS [{target_col}]',
        "average": f'AVG([{src}]) AS [{target_col}]',
        "lookup": f'-- Lookup JOIN for [{target_col}]: {rule}',
    }
    return fixes.get(tf_lower, f'-- Synapse: {transformation} for [{target_col}] — {rule}')


# ---- Databricks SQL Parser ----

def parse_databricks_sql(code_path: str) -> Tuple[List[CodeExtraction], Dict[str, Any]]:
    """Parse a Databricks SQL notebook/script file.
    Reuses DBT SQL parser since Databricks SQL uses standard Spark SQL syntax.
    """
    code = Path(code_path).read_text(encoding="utf-8")
    lines = code.split("\n")
    extractions = _parse_dbt_sql(code, lines)  # Same SQL parsing logic
    metadata = {
        "pyspark_file": str(code_path),
        "total_pyspark_columns": len(extractions),
        "source_type": "databricks_sql",
        "technology": "databricks_sql",
    }
    logger.info(f"Extracted {len(extractions)} column mappings from Databricks SQL")
    return extractions, metadata


def _generate_databricks_sql_fix(
    target_col: str, transformation: str, rule: str, source_col: str,
) -> str:
    """Generate Databricks SQL fix — uses Spark SQL syntax (same as DBT)."""
    return _generate_dbt_fix(target_col, transformation, rule, source_col)


# ---- AWS Glue Parser ----

def _parse_glue_python(code: str, lines: List[str]) -> List[CodeExtraction]:
    """Parse an AWS Glue Python ETL script for column mappings."""
    extractions: List[CodeExtraction] = []
    seen: set = set()

    # Pattern 1: apply_mapping — ApplyMapping.apply(frame, mappings=[("src", "type", "tgt", "type")])
    apply_mapping_pattern = re.compile(
        r"""\(\s*["'](\w+)["']\s*,\s*["']\w+["']\s*,\s*["'](\w+)["']\s*,\s*["']\w+["']\s*\)""",
    )
    # Find apply_mapping blocks
    mapping_block = re.compile(r'(?:apply_mapping|ApplyMapping\.apply)\s*\(.*?mappings\s*=\s*\[(.*?)\]', re.DOTALL)
    for block_match in mapping_block.finditer(code):
        block = block_match.group(1)
        pos = block_match.start()
        line_num = code[:pos].count('\n') + 1
        for m in apply_mapping_pattern.finditer(block):
            src_col = m.group(1)
            tgt_col = m.group(2)
            key = tgt_col.upper()
            if key not in seen:
                seen.add(key)
                extractions.append(CodeExtraction(
                    target_column=tgt_col,
                    source_reference=src_col,
                    transformation_code=f"ApplyMapping: {src_col} -> {tgt_col}",
                    line_number=line_num,
                    context="glue_apply_mapping",
                ))

    # Pattern 2: resolveChoice — .resolveChoice(specs=[("col", "cast:type")])
    resolve_pattern = re.compile(
        r"""\(\s*["'](\w+)["']\s*,\s*["']cast:(\w+)["']\s*\)""",
    )
    resolve_block = re.compile(r'resolveChoice\s*\(.*?specs\s*=\s*\[(.*?)\]', re.DOTALL)
    for block_match in resolve_block.finditer(code):
        block = block_match.group(1)
        pos = block_match.start()
        line_num = code[:pos].count('\n') + 1
        for m in resolve_pattern.finditer(block):
            col = m.group(1)
            cast_type = m.group(2)
            key = col.upper()
            if key not in seen:
                seen.add(key)
                extractions.append(CodeExtraction(
                    target_column=col,
                    source_reference=col,
                    transformation_code=f"resolveChoice: cast:{cast_type}",
                    line_number=line_num,
                    context="glue_resolve_choice",
                ))

    # Pattern 3: rename_field — .rename_field("old", "new")
    rename_pattern = re.compile(r'\.rename_field\s*\(\s*["\'](\w+)["\']\s*,\s*["\'](\w+)["\']\s*\)')
    for m in rename_pattern.finditer(code):
        src = m.group(1)
        tgt = m.group(2)
        key = tgt.upper()
        if key not in seen:
            seen.add(key)
            pos = m.start()
            line_num = code[:pos].count('\n') + 1
            extractions.append(CodeExtraction(
                target_column=tgt,
                source_reference=src,
                transformation_code=f"rename_field: {src} -> {tgt}",
                line_number=line_num,
                context="glue_rename",
            ))

    # Pattern 4: Spark SQL within Glue (spark.sql / sparkSqlQuery)
    sql_pattern = re.compile(r'(?:spark\.sql|sqlContext\.sql)\s*\(\s*(?:f?"""|\"|f?\'\'\'|\')(.*?)(?:"""|"|\'\'\' |\')\s*\)', re.DOTALL)
    for sql_match in sql_pattern.finditer(code):
        sql = sql_match.group(1)
        from_dbt = _parse_dbt_sql(sql, sql.split("\n"))
        for ext in from_dbt:
            key = ext.target_column.upper()
            if key not in seen:
                seen.add(key)
                ext.context = "glue_spark_sql"
                extractions.append(ext)

    # Pattern 5: Standard PySpark .withColumn inside Glue scripts
    for i, line in enumerate(lines, 1):
        if '.withColumn(' in line or '.withColumnRenamed(' in line:
            from_wc = _extract_with_column_balanced(line)
            for tgt, expr in from_wc:
                key = tgt.upper()
                if key not in seen:
                    seen.add(key)
                    src = _extract_source_from_expr(expr)
                    ctx = _find_enclosing_context(lines, i)
                    extractions.append(CodeExtraction(
                        target_column=tgt,
                        source_reference=src,
                        transformation_code=expr,
                        line_number=i,
                        context=ctx,
                    ))

    return extractions


def parse_glue(code_path: str, json_config_path: Optional[str] = None) -> Tuple[List[CodeExtraction], Dict[str, Any]]:
    """Parse an AWS Glue ETL script.

    If the Glue job reads transformations from a JSON config file (common
    pattern: ``spark.sql(query)`` where the query lives in a JSON config),
    pass the JSON path via *json_config_path* so the SQL column mappings are
    extracted from the JSON as well.
    """
    code = Path(code_path).read_text(encoding="utf-8")
    lines = code.split("\n")
    extractions = _parse_glue_python(code, lines)

    # --- Also parse JSON config if provided or auto-detected ---
    json_path = json_config_path
    if not json_path:
        # Auto-detect: check if the Glue script references a JSON config
        json_ref = _detect_json_config_reference(code)
        if json_ref:
            pyspark_dir = Path(code_path).parent
            for candidate in [pyspark_dir / json_ref, pyspark_dir / Path(json_ref).name, Path(json_ref)]:
                if candidate.exists():
                    json_path = str(candidate)
                    break

    if json_path:
        logger.info(f"Parsing JSON config for Glue job: {json_path}")
        json_extractions, sql_query = _parse_json_config(json_path)
        # Merge — JSON extractions fill gaps not already found in the .py
        seen = {e.target_column.upper() for e in extractions}
        added = 0
        for ext in json_extractions:
            if ext.target_column.upper() not in seen:
                seen.add(ext.target_column.upper())
                ext.context = ext.context or "glue_json_config"
                extractions.append(ext)
                added += 1
        if added:
            logger.info(f"Added {added} column mappings from JSON config SQL query")

    metadata = {
        "pyspark_file": str(code_path),
        "total_pyspark_columns": len(extractions),
        "source_type": "glue_python",
        "technology": "glue",
    }
    logger.info(f"Extracted {len(extractions)} column mappings from AWS Glue script")
    return extractions, metadata


def _generate_glue_fix(
    target_col: str, transformation: str, rule: str, source_col: str,
) -> str:
    """Generate an AWS Glue Python fix."""
    tf_lower = transformation.lower()
    src = source_col or "SOURCE_COL"
    fixes = {
        "direct pull": f'("{src}", "string", "{target_col}", "string")  # in ApplyMapping',
        "current date": f'df = df.withColumn("{target_col}", F.current_date())  # Spark API',
        "custom/default": f'df = df.withColumn("{target_col}", F.lit({rule}))  # Spark API',
        "convert datatype": f'("{src}", "string", "{target_col}", "{rule or "string"}")  # in ApplyMapping',
        "trim": f'df = df.withColumn("{target_col}", F.trim(F.col("{src}")))',
        "upper case": f'df = df.withColumn("{target_col}", F.upper(F.col("{src}")))',
        "lookup": f'# Lookup JOIN for {target_col}: {rule}',
    }
    return fixes.get(tf_lower, _generate_pyspark_fix(target_col, transformation, rule, source_col))


# ---- Scala Spark Parser ----

def _parse_scala_spark(code: str, lines: List[str]) -> List[CodeExtraction]:
    """Parse a Scala Spark file for column mappings."""
    extractions: List[CodeExtraction] = []
    seen: set = set()

    for i, line in enumerate(lines, 1):
        stripped = line.strip()

        # Pattern 1: .withColumn("col", expr)
        wc_pattern = re.compile(r'\.withColumn\s*\(\s*"(\w+)"\s*,\s*(.+?)\s*\)')
        for m in wc_pattern.finditer(stripped):
            tgt = m.group(1)
            expr = m.group(2)
            key = tgt.upper()
            if key not in seen:
                seen.add(key)
                source_ref = ""
                col_match = re.search(r'col\("(\w+)"\)', expr)
                if col_match:
                    source_ref = col_match.group(1)
                dollar_match = re.search(r'\$"(\w+)"', expr)
                if not source_ref and dollar_match:
                    source_ref = dollar_match.group(1)
                extractions.append(CodeExtraction(
                    target_column=tgt,
                    source_reference=source_ref,
                    transformation_code=expr,
                    line_number=i,
                    context="scala_withColumn",
                ))

        # Pattern 2: .withColumnRenamed("old", "new")
        wcr_pattern = re.compile(r'\.withColumnRenamed\s*\(\s*"(\w+)"\s*,\s*"(\w+)"\s*\)')
        for m in wcr_pattern.finditer(stripped):
            src = m.group(1)
            tgt = m.group(2)
            key = tgt.upper()
            if key not in seen:
                seen.add(key)
                extractions.append(CodeExtraction(
                    target_column=tgt,
                    source_reference=src,
                    transformation_code=f'withColumnRenamed("{src}", "{tgt}")',
                    line_number=i,
                    context="scala_rename",
                ))

        # Pattern 3: col("x").as("alias") or col("x").alias("alias")
        alias_pattern = re.compile(r'(?:col\("(\w+)"\)|(\$"\w+"))\.(?:as|alias)\s*\(\s*"(\w+)"\s*\)')
        for m in alias_pattern.finditer(stripped):
            src = m.group(1) or m.group(2).strip('$"')
            tgt = m.group(3)
            key = tgt.upper()
            if key not in seen:
                seen.add(key)
                extractions.append(CodeExtraction(
                    target_column=tgt,
                    source_reference=src,
                    transformation_code=f'{src}.as("{tgt}")',
                    line_number=i,
                    context="scala_alias",
                ))

        # Pattern 4: $"col" as "alias" or $"col" alias "alias"
        dollar_as_pattern = re.compile(r'\$"(\w+)"\s+(?:as|alias)\s+"(\w+)"')
        for m in dollar_as_pattern.finditer(stripped):
            src = m.group(1)
            tgt = m.group(2)
            key = tgt.upper()
            if key not in seen:
                seen.add(key)
                extractions.append(CodeExtraction(
                    target_column=tgt,
                    source_reference=src,
                    transformation_code=f'$"{src}" as "{tgt}"',
                    line_number=i,
                    context="scala_dollar_as",
                ))

    # Also parse SQL strings inside spark.sql("...")
    sql_pattern = re.compile(r'spark\.sql\s*\(\s*(?:s?"""|\"|s?\'\'\'|\')(.*?)(?:"""|"|\'\'\' |\')\s*\)', re.DOTALL)
    for sql_match in sql_pattern.finditer(code):
        sql = sql_match.group(1)
        from_sql = _parse_dbt_sql(sql, sql.split("\n"))
        for ext in from_sql:
            key = ext.target_column.upper()
            if key not in seen:
                seen.add(key)
                ext.context = "scala_spark_sql"
                extractions.append(ext)

    return extractions


def parse_scala_spark(code_path: str) -> Tuple[List[CodeExtraction], Dict[str, Any]]:
    """Parse a Scala Spark file."""
    code = Path(code_path).read_text(encoding="utf-8")
    lines = code.split("\n")
    extractions = _parse_scala_spark(code, lines)
    metadata = {
        "pyspark_file": str(code_path),
        "total_pyspark_columns": len(extractions),
        "source_type": "scala_spark",
        "technology": "scala_spark",
    }
    logger.info(f"Extracted {len(extractions)} column mappings from Scala Spark")
    return extractions, metadata


def _generate_scala_spark_fix(
    target_col: str, transformation: str, rule: str, source_col: str,
) -> str:
    """Generate Scala Spark fix."""
    tf_lower = transformation.lower()
    src = source_col or "SOURCE_COL"
    fixes = {
        "direct pull": f'.withColumnRenamed("{src}", "{target_col}")' if source_col else f'// Direct Pull for {target_col}',
        "current date": f'.withColumn("{target_col}", current_date())',
        "sysdate": f'.withColumn("{target_col}", current_date())',
        "custom/default": f'.withColumn("{target_col}", lit({rule}))',
        "sequence generated id": f'.withColumn("{target_col}", monotonically_increasing_id())',
        "convert date format": f'.withColumn("{target_col}", to_date(col("{src}")))',
        "convert datatype": f'.withColumn("{target_col}", col("{src}").cast({rule or "StringType"}))',
        "md5": f'.withColumn("{target_col}", md5(concat_ws("", key_cols: _*)))',
        "trim": f'.withColumn("{target_col}", trim(col("{src}")))',
        "upper case": f'.withColumn("{target_col}", upper(col("{src}")))',
        "lower case": f'.withColumn("{target_col}", lower(col("{src}")))',
        "coalesce": f'.withColumn("{target_col}", coalesce(col("{src}"), lit({rule})))',
        "case/when": f'.withColumn("{target_col}", when({rule}))',
        "lookup": f'// Lookup JOIN for {target_col}: {rule}',
    }
    return fixes.get(tf_lower, f'// {transformation} for {target_col}: {rule}')


# ---- Technology Dispatcher ----

TECH_PARSERS = {
    "pyspark": None,  # uses existing parse_pyspark()
    "dbt": parse_dbt,
    "adf": parse_adf,
    "synapse": parse_synapse,
    "databricks_sql": parse_databricks_sql,
    "glue": parse_glue,
    "scala_spark": parse_scala_spark,
}

TECH_FIX_GENERATORS = {
    "pyspark": _generate_pyspark_fix,
    "dbt": _generate_dbt_fix,
    "adf": _generate_adf_fix,
    "synapse": _generate_synapse_fix,
    "databricks_sql": _generate_databricks_sql_fix,
    "glue": _generate_glue_fix,
    "scala_spark": _generate_scala_spark_fix,
}


def generate_updated_code(
    code_path: str,
    results: List[Dict[str, Any]],
    output_dir: str,
    technology: str = "pyspark",
) -> Optional[Path]:
    """Generate updated code with corrections for drifts found — technology-aware."""
    drift_results = [r for r in results if r["status"] == "DRIFT"]
    if not drift_results:
        logger.info("No drifts found — code is aligned with STTM spec")
        return None

    code = Path(code_path).read_text(encoding="utf-8")
    tech_label = TECHNOLOGY_LABELS.get(technology, technology)
    fix_gen = TECH_FIX_GENERATORS.get(technology, _generate_pyspark_fix)

    # Determine file extension and comment style
    ext = Path(code_path).suffix.lower()
    if ext in (".sql",):
        comment = "--"
        sep_line = "-- " + "=" * 67
    elif ext in (".scala",):
        comment = "//"
        sep_line = "// " + "=" * 67
    elif ext == ".json":
        # JSON doesn't support comments — use a separate .fix file
        comment = "//"
        sep_line = "// " + "=" * 67
    else:
        comment = "#"
        sep_line = "# " + "=" * 70

    patch_lines = [
        "",
        sep_line,
        f"{comment} DRIFT PATCHES — Auto-generated by detect_drift.py ({tech_label})",
        f"{comment} STTM is the source of truth. Review each patch and apply to the correct location.",
        sep_line,
    ]

    for drift in drift_results:
        target_col = drift["target_column"]
        sttm_info = drift.get("sttm", {})
        transformation = sttm_info.get("transformation", "")
        rule = sttm_info.get("transformation_rule", "")
        source_col = sttm_info.get("source_column", "")
        pyspark_info = drift.get("pyspark", {})
        line_num = pyspark_info.get("line_number", "")

        patch_lines.append("")
        patch_lines.append(f"{comment} DRIFT [{drift['severity']}]: {drift['drift_type']} for column '{target_col}'")
        patch_lines.append(f"{comment} STTM spec: {transformation}" + (f" — rule: {rule}" if rule else ""))
        if line_num:
            patch_lines.append(f"{comment} Current code at line {line_num}: {pyspark_info.get('transformation_code', '')}")
        patch_lines.append(f"{comment} Explanation: {drift.get('explanation', '')}")

        fix_code = fix_gen(target_col, transformation, rule, source_col)
        if fix_code:
            patch_lines.append(f"{comment} Fix:")
            patch_lines.append(f"{comment} {fix_code}")

    # Determine output filename
    if ext == ".json":
        out_name = "updated_code.fix.txt"
    else:
        out_name = f"updated_{Path(code_path).stem}{ext}"

    patched_code = code + "\n".join(patch_lines) + "\n"
    out_path = Path(output_dir) / out_name
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(patched_code, encoding="utf-8")
    logger.info(f"Updated {tech_label} code saved to: {out_path}")
    return out_path


def _sql_col_ref(col_name: str) -> str:
    """Return a clean SQL column reference — no unnecessary quotes."""
    if not col_name:
        return "NULL"
    # Strip any existing quotes (single, double, backtick) that may come from STTM
    cleaned = col_name.strip().strip("'\"`").strip()
    if not cleaned:
        return "NULL"
    # Simple identifier (letters, digits, underscores) — no quoting needed
    if re.match(r'^\w+$', cleaned):
        return cleaned
    # Has spaces or special chars — needs backtick quoting
    return f"`{cleaned}`"


def _sttm_drift_to_sql_expr(drift: Dict[str, Any]) -> str:
    """Convert a single STTM drift result into a SQL SELECT expression.

    Examples:
        Direct Pull:  Source_System AS SRC  (or `Territory ID` AS TERR_ID if spaces)
        Lookup:       NULL AS TERR_TYPE_ID  -- Lookup: <rule>
        Current date: current_date() AS CRTD_DT
        Custom/Default with literal:  'value' AS COL
        Derivation:   NULL AS COL  -- Derivation: <rule>
    """
    target_col = drift["target_column"]
    sttm = drift.get("sttm", {})
    source_col = sttm.get("source_column", "")
    transformation = sttm.get("transformation", "")
    rule = sttm.get("transformation_rule", "")
    tf_lower = transformation.lower()
    src_ref = _sql_col_ref(source_col)

    # Direct Pull — source column rename
    if tf_lower in ("direct pull", "straight pull"):
        if source_col:
            return f"{src_ref} AS {target_col}"
        return f"NULL AS {target_col}  /* TODO: source column unknown */"

    # Current date / timestamp
    if tf_lower in ("current date", "sysdate", "current timestamp"):
        return f"current_date() AS {target_col}"

    # Hardcode / literal / custom default
    if tf_lower in ("custom/default", "hardcode", "literal"):
        # Try to extract the literal value from the rule
        lit_match = re.search(r"(?i)(?:hardcode|default|populate|load.*with)\s*[:\-]?\s*['\"]?(\S+)", rule)
        if lit_match:
            val = lit_match.group(1).strip("'\"")
            # Check if value is numeric or keyword — no quotes needed
            if re.match(r'^-?\d+(\.\d+)?$', val) or val.upper() in ("NULL", "TRUE", "FALSE"):
                return f"{val} AS {target_col}"
            return f"'{val}' AS {target_col}"
        short_rule = rule[:60] + "..." if len(rule) > 60 else rule
        return f"NULL AS {target_col}  /* {transformation}: {short_rule} */"

    # Lookup — use source column reference with lookup comment
    if tf_lower == "lookup":
        short_rule = rule[:80] + "..." if len(rule) > 80 else rule
        if source_col:
            return f"{src_ref} AS {target_col}  /* Lookup: {short_rule} */"
        return f"NULL AS {target_col}  /* TODO Lookup: {short_rule} */"

    # Date conversion
    if tf_lower in ("date convert", "convert date format"):
        if source_col:
            return f"TO_DATE({src_ref}, 'yyyy-MM-dd') AS {target_col}"
        return f"TO_DATE(NULL) AS {target_col}"

    # Trim
    if tf_lower == "trim":
        if source_col:
            return f"TRIM({src_ref}) AS {target_col}"
        return f"TRIM(NULL) AS {target_col}"

    # Upper / Lower
    if tf_lower == "upper case":
        return f"UPPER({src_ref}) AS {target_col}"
    if tf_lower == "lower case":
        return f"LOWER({src_ref}) AS {target_col}"

    # Coalesce
    if tf_lower == "coalesce":
        return f"COALESCE({src_ref}, NULL) AS {target_col}  /* {rule} */"

    # Concatenation
    if tf_lower in ("concatenation", "concat"):
        return f"CONCAT({src_ref}) AS {target_col}  /* {rule} */"

    # Derivation / Case-When / anything else
    if source_col:
        short_rule = rule[:60] + "..." if len(rule) > 60 else rule
        return f"{src_ref} AS {target_col}  /* {transformation}: {short_rule} */"

    short_rule = rule[:60] + "..." if len(rule) > 60 else rule
    return f"NULL AS {target_col}  /* TODO {transformation}: {short_rule} */"


def generate_updated_json_config(
    json_config_path: str,
    results: List[Dict[str, Any]],
    output_dir: str,
) -> Optional[Path]:
    """Generate an updated JSON config file with missing column mappings added to the SQL query.

    For JSON-config-driven jobs (e.g., Glue reading SQL from JSON), the
    transformations live in the SQL query inside the JSON — not in the .py file.
    This function:
      1. Reads the original JSON config
      2. Finds the core SQL query
      3. Adds missing columns (from drift results) to the SELECT clause
      4. Writes the updated JSON to the output directory
    """
    drift_results = [r for r in results if r["status"] == "DRIFT"]
    if not drift_results:
        logger.info("No drifts found — JSON config is aligned with STTM spec")
        return None

    with open(json_config_path, "r", encoding="utf-8") as f:
        data = json.load(f)

    # Find the SQL query in the JSON (same logic as _parse_json_config)
    sql_queries: List[Tuple[str, list]] = []  # (query_text, json_path_to_key)

    def _find_queries(obj, path=None):
        if path is None:
            path = []
        if isinstance(obj, dict):
            for key, val in obj.items():
                if isinstance(val, str) and re.search(r'\bSELECT\b', val, re.IGNORECASE):
                    sql_queries.append((val, path + [key]))
                else:
                    _find_queries(val, path + [key])
        elif isinstance(obj, list):
            for i, item in enumerate(obj):
                _find_queries(item, path + [i])

    _find_queries(data)

    if not sql_queries:
        logger.warning("No SQL queries found in JSON config — cannot generate updated JSON")
        return None

    # Pick the main query (most AS aliases)
    best_query, best_path = sql_queries[0]
    best_count = 0
    for q, p in sql_queries:
        alias_count = len(re.findall(r'\bAS\s+\w+', q, re.IGNORECASE))
        if alias_count > best_count:
            best_count = alias_count
            best_query = q
            best_path = p

    # Build SQL expressions for each drifted column
    new_columns = []
    for drift in drift_results:
        sql_expr = _sttm_drift_to_sql_expr(drift)
        new_columns.append(sql_expr)

    # Insert new columns into the SELECT clause
    # Find the FROM keyword to insert before it
    from_match = re.search(r'\bFROM\b', best_query, re.IGNORECASE)
    if from_match:
        insert_pos = from_match.start()
        # Add the new columns before FROM
        new_cols_str = ", ".join(new_columns)
        updated_query = (
            best_query[:insert_pos].rstrip().rstrip(",")
            + ", "
            + new_cols_str
            + " "
            + best_query[insert_pos:]
        )
    else:
        # No FROM found — append to end
        new_cols_str = ", ".join(new_columns)
        updated_query = best_query.rstrip() + ", " + new_cols_str

    # Update the JSON structure at the correct path
    obj = data
    for key in best_path[:-1]:
        obj = obj[key]
    obj[best_path[-1]] = updated_query

    # Write updated JSON
    out_name = f"updated_{Path(json_config_path).name}"
    out_path = Path(output_dir) / out_name
    out_path.parent.mkdir(parents=True, exist_ok=True)
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=4, ensure_ascii=False)

    logger.info(f"Updated JSON config saved to: {out_path} ({len(new_columns)} columns added to SQL query)")
    return out_path


# ---------------------------------------------------------------------------
# 6. Compliance Checks Engine
# ---------------------------------------------------------------------------

def _run_regex_rules(
    rules: List[Dict],
    code: str,
    lines: List[str],
    module_name: str,
) -> List[Dict[str, Any]]:
    """Run a list of regex-based compliance rules against PySpark code.

    Each rule can have:
      - pattern: regex to search for (finding = potential issue)
      - exclude_pattern: if this also matches the same line, suppress the finding
      - absent_pattern: if this is NOT found anywhere in the file, flag the issue
                        (only checked when 'pattern' matches, for context)
    """
    findings: List[Dict[str, Any]] = []

    for rule in rules:
        name = rule.get("name", "unnamed")
        severity = rule.get("severity", "MEDIUM")
        message = rule.get("message", "")
        fix = rule.get("fix", "")
        pattern = rule.get("pattern", "")
        exclude = rule.get("exclude_pattern", "")
        absent = rule.get("absent_pattern", "")

        if not pattern:
            continue

        try:
            compiled = re.compile(pattern)
        except re.error:
            logger.warning(f"Invalid regex in rule '{name}': {pattern}")
            continue

        for i, line in enumerate(lines, 1):
            stripped = line.strip()
            if stripped.startswith("#"):
                continue

            match = compiled.search(line)
            if not match:
                continue

            # Check exclusion
            if exclude and re.search(exclude, line):
                continue

            # Check absent_pattern: if the rule requires something to be
            # present in the file and it IS present, skip this finding
            if absent and re.search(absent, code, re.DOTALL):
                continue

            findings.append({
                "module": module_name,
                "rule": name,
                "severity": severity,
                "line_number": i,
                "line_content": stripped[:200],
                "message": message,
                "fix": fix,
            })

    return findings


def _run_pii_checks(
    gov_config: Dict,
    code: str,
    lines: List[str],
    pyspark_extractions: List[CodeExtraction],
) -> List[Dict[str, Any]]:
    """Check for PII columns that may not be properly masked/hashed."""
    findings: List[Dict[str, Any]] = []
    pii_patterns = gov_config.get("pii_column_patterns", [])
    masking_funcs = gov_config.get("masking_functions", [])

    # Collect all column names referenced in the code
    all_columns: Set[str] = set()
    for ext in pyspark_extractions:
        if ext.target_column:
            all_columns.add(ext.target_column)
        if ext.source_reference:
            all_columns.add(ext.source_reference)

    # Also find column names from withColumn / col() calls in raw code
    for m in re.finditer(r'(?:col|withColumn|withColumnRenamed)\s*\(\s*["\'](\w+)["\']', code):
        all_columns.add(m.group(1))

    for col_name in all_columns:
        for pii_rule in pii_patterns:
            pii_pat = pii_rule.get("pattern", "")
            if not pii_pat:
                continue
            if not re.search(pii_pat, col_name):
                continue

            # This column name matches a PII pattern — check if it's masked
            is_masked = False
            for mask_fn in masking_funcs:
                # Check if any masking function is applied to this column
                mask_context = f"{mask_fn}.*{re.escape(col_name)}|{re.escape(col_name)}.*{mask_fn}"
                if re.search(mask_context, code, re.IGNORECASE):
                    is_masked = True
                    break

            if not is_masked:
                # Find the line where this column is referenced
                line_num = 0
                for i, line in enumerate(lines, 1):
                    if col_name in line:
                        line_num = i
                        break

                findings.append({
                    "module": "data_governance",
                    "rule": "unmasked_pii_column",
                    "severity": pii_rule.get("severity", "HIGH"),
                    "line_number": line_num,
                    "line_content": f"Column '{col_name}' matches PII pattern: {pii_rule.get('category', 'PII')}",
                    "message": f"PII column '{col_name}' ({pii_rule.get('category', 'PII')}) found without masking/hashing",
                    "fix": f"Apply masking: F.sha2(F.col('{col_name}'), 256) or use a tokenization UDF",
                })
            break  # Only flag once per column

    return findings


def _run_cicd_pipeline_checks(
    cicd_config: Dict[str, Any],
    repo_root: str,
) -> List[Dict[str, Any]]:
    """Scan repository for CI/CD pipeline configs and verify required gates.

    Unlike other compliance modules that scan PySpark code, this module scans
    the Git repository for pipeline definition files (Jenkinsfile, GitHub Actions,
    GitLab CI, etc.) and checks that required quality gates exist.
    """
    import glob as globmod

    findings: List[Dict[str, Any]] = []
    pipeline_file_patterns = cicd_config.get("pipeline_files", [])
    required_gates = cicd_config.get("required_gates", [])

    if not required_gates:
        return findings

    # --- Step 1: Discover pipeline config files in the repo ---
    discovered_files: List[str] = []
    for pattern in pipeline_file_patterns:
        full_pattern = os.path.join(repo_root, pattern)
        matches = globmod.glob(full_pattern, recursive=False)
        discovered_files.extend(matches)

    # De-duplicate and sort
    discovered_files = sorted(set(discovered_files))

    if not discovered_files:
        # No pipeline files found at all — raise a single CRITICAL finding
        findings.append({
            "module": "cicd_pipeline",
            "rule": "no_pipeline_config",
            "severity": "CRITICAL",
            "line_number": 0,
            "line_content": "",
            "message": f"No CI/CD pipeline configuration found in repository ({repo_root})",
            "fix": "Add a Jenkinsfile, GitHub Actions workflow, GitLab CI config, "
                   "or equivalent pipeline definition to the repository",
            "scanned_patterns": pipeline_file_patterns,
        })
        # Also flag every required gate as missing since there's no pipeline
        for gate in required_gates:
            findings.append({
                "module": "cicd_pipeline",
                "rule": gate["name"],
                "severity": gate.get("severity", "HIGH"),
                "line_number": 0,
                "line_content": "",
                "message": gate.get("message", f"Missing gate: {gate['name']}"),
                "fix": gate.get("fix", ""),
                "pipeline_files": [],
            })
        return findings

    # --- Step 2: Read all pipeline file contents ---
    combined_content = ""
    file_contents: Dict[str, str] = {}
    for fpath in discovered_files:
        try:
            with open(fpath, "r", errors="replace") as fh:
                content = fh.read()
                file_contents[fpath] = content
                combined_content += f"\n# --- {fpath} ---\n{content}\n"
        except OSError as e:
            logger.warning(f"Could not read pipeline file {fpath}: {e}")

    logger.info(f"  Found {len(discovered_files)} pipeline config file(s): "
                f"{[os.path.basename(f) for f in discovered_files]}")

    # --- Step 3: Check each required gate ---
    for gate in required_gates:
        gate_name = gate["name"]
        indicators = gate.get("indicators", [])
        gate_found = False

        for indicator_pattern in indicators:
            try:
                if re.search(indicator_pattern, combined_content):
                    gate_found = True
                    break
            except re.error:
                logger.warning(f"Invalid regex in cicd gate '{gate_name}': {indicator_pattern}")

        if not gate_found:
            findings.append({
                "module": "cicd_pipeline",
                "rule": gate_name,
                "severity": gate.get("severity", "HIGH"),
                "line_number": 0,
                "line_content": "",
                "message": gate.get("message", f"Missing gate: {gate_name}"),
                "fix": gate.get("fix", ""),
                "pipeline_files": [os.path.relpath(f, repo_root) for f in discovered_files],
            })

    return findings


def run_compliance_checks(
    code: str,
    lines: List[str],
    pyspark_extractions: List[CodeExtraction],
    enabled_modules: Optional[Set[str]] = None,
    repo_root: Optional[str] = None,
) -> Dict[str, Any]:
    """Run all enabled compliance check modules against PySpark code.

    Returns a dict with:
      - findings: list of all compliance findings
      - summary: per-module pass/fail counts
      - gate_status: overall PASS/FAIL/WARN
    """
    all_findings: List[Dict[str, Any]] = []
    summary: Dict[str, Dict] = {}

    for module_name, module_cfg in config.compliance_checks.items():
        if not isinstance(module_cfg, dict):
            continue
        if not module_cfg.get("enabled", False):
            continue
        if enabled_modules and module_name not in enabled_modules:
            continue

        logger.info(f"  Running compliance check: {module_name}")

        module_findings: List[Dict[str, Any]] = []

        # Standard regex rules
        rules = module_cfg.get("rules", [])
        if rules:
            module_findings.extend(_run_regex_rules(rules, code, lines, module_name))

        # PII-specific checks (data_governance module)
        if module_name == "data_governance":
            module_findings.extend(
                _run_pii_checks(module_cfg, code, lines, pyspark_extractions)
            )

        # CI/CD pipeline checks (scans repo, not PySpark code)
        if module_name == "cicd_pipeline":
            scan_root = repo_root or os.getcwd()
            module_findings.extend(
                _run_cicd_pipeline_checks(module_cfg, scan_root)
            )

        all_findings.extend(module_findings)

        # Per-module summary
        severity_counts = {"CRITICAL": 0, "HIGH": 0, "MEDIUM": 0, "LOW": 0}
        for f in module_findings:
            sev = f.get("severity", "MEDIUM")
            severity_counts[sev] = severity_counts.get(sev, 0) + 1

        total_issues = len(module_findings)
        max_sev = "NONE"
        for sev in ["CRITICAL", "HIGH", "MEDIUM", "LOW"]:
            if severity_counts.get(sev, 0) > 0:
                max_sev = sev
                break

        summary[module_name] = {
            "total_findings": total_issues,
            "by_severity": severity_counts,
            "max_severity": max_sev,
        }

    # Overall gate status
    has_critical = any(
        f.get("severity") == "CRITICAL" for f in all_findings
    )
    has_high = any(
        f.get("severity") == "HIGH" for f in all_findings
    )
    if has_critical:
        gate_status = "FAIL"
    elif has_high:
        gate_status = "WARN"
    elif all_findings:
        gate_status = "WARN"
    else:
        gate_status = "PASS"

    return {
        "findings": all_findings,
        "summary": summary,
        "gate_status": gate_status,
        "total_findings": len(all_findings),
    }


# ---------------------------------------------------------------------------
# 7. CLI Entry Point
# ---------------------------------------------------------------------------

def _resolve_config_path(explicit_path: Optional[str]) -> str:
    """Resolve the config file path — check explicit, then same dir as script, then cwd."""
    if explicit_path:
        return explicit_path

    # Check next to the script itself
    script_dir = Path(__file__).parent
    candidate = script_dir / "transform_config.yaml"
    if candidate.exists():
        return str(candidate)

    # Check current working directory
    cwd_candidate = Path("transform_config.yaml")
    if cwd_candidate.exists():
        return str(cwd_candidate)

    # Check project root (one level up from scripts/)
    project_candidate = script_dir.parent / "transform_config.yaml"
    if project_candidate.exists():
        return str(project_candidate)

    return str(candidate)  # Default to scripts/ dir even if not found


def main():
    global config

    parser = argparse.ArgumentParser(
        description="STTM-PySpark Drift Detection — STTM is the source of truth",
    )
    parser.add_argument(
        "--sttm", required=True, help="Path to the STTM Excel file (.xlsx)",
    )
    parser.add_argument(
        "--sheet", default="STTM", help="Sheet name containing the mappings (default: STTM)",
    )
    parser.add_argument(
        "--pyspark", "--code", dest="pyspark", required=True,
        help="Path to the ETL code file (.py, .sql, .json, .scala). "
             "Use --code for non-PySpark technologies.",
    )
    parser.add_argument(
        "--output-dir", default="output/", help="Output directory (default: output/)",
    )
    parser.add_argument(
        "--target-table", default=None, help="Override target table name (auto-detected from STTM)",
    )
    parser.add_argument(
        "--mode", choices=["auto", "standard"], default="auto",
        help="Detection mode: 'auto' (detect framework from code) or "
             "'standard' (no framework — every mapping must be explicit in code). Default: auto",
    )
    parser.add_argument(
        "--config", default=None,
        help="Path to transform_config.yaml (auto-resolved if not specified)",
    )
    parser.add_argument(
        "--json-config", default=None,
        help="Path to JSON config file containing SQL transformation queries. "
             "If not provided, auto-detected from PySpark code references.",
    )
    parser.add_argument(
        "--execution-mode", choices=["auto", "standalone", "agentic"],
        default="auto",
        help="Execution mode: 'standalone' (deterministic only), "
             "'agentic' (LLM-enhanced review of all comparisons), "
             "'auto' (use LLM if available, else standalone). Default: auto",
    )
    parser.add_argument(
        "--checks", default="sttm_only",
        help="Compliance checks to run: 'sttm_only' (default — only STTM drift), "
             "'all' (STTM + all enabled compliance modules), or comma-separated "
             "module names (e.g. 'security,code_standards,data_governance,performance'). "
             "Modules are defined in transform_config.yaml under compliance_checks.",
    )
    parser.add_argument(
        "--repo-root", default=None,
        help="Repository root directory for CI/CD pipeline scanning. "
             "Defaults to the parent directory of the PySpark file, or cwd if not found.",
    )
    parser.add_argument(
        "--technology", default="auto",
        choices=["auto", "pyspark", "dbt", "adf", "synapse", "databricks_sql", "glue", "scala_spark"],
        help="ETL technology: 'auto' (detect from file extension/content), 'pyspark', 'dbt', "
             "'adf' (Azure Data Factory), 'synapse' (Azure Synapse SQL), 'databricks_sql', "
             "'glue' (AWS Glue), 'scala_spark'. Default: auto",
    )
    parser.add_argument(
        "--s3-output", default=None,
        help="S3 URI for uploading outputs (e.g. s3://my-bucket/output/). "
             "If provided, drift report and updated code are uploaded here after local generation.",
    )

    args = parser.parse_args()

    # --- S3 input handling: download S3 paths to local temp directory ---
    s3_tmp_dir = None
    if any(_is_s3_path(p) for p in [args.sttm, args.pyspark, args.config or "", args.json_config or ""]):
        s3_tmp_dir = tempfile.mkdtemp(prefix="drift_s3_")
        logger.info(f"S3 mode detected — downloading inputs to {s3_tmp_dir}")

        if _is_s3_path(args.sttm):
            args.sttm = _s3_download(args.sttm, local_dir=s3_tmp_dir)

        if _is_s3_path(args.pyspark):
            args.pyspark = _s3_download(args.pyspark, local_dir=s3_tmp_dir)

        if args.config and _is_s3_path(args.config):
            args.config = _s3_download(args.config, local_dir=s3_tmp_dir)

        if args.json_config and _is_s3_path(args.json_config):
            args.json_config = _s3_download(args.json_config, local_dir=s3_tmp_dir)

    # Load configuration
    config_path = _resolve_config_path(args.config)
    config = DriftConfig.load(config_path)

    # --- Resolve execution mode (standalone vs agentic) ---
    llm_provider: Optional[LLMProvider] = None
    execution_mode = args.execution_mode

    if execution_mode == "standalone":
        logger.info("Execution mode: STANDALONE (deterministic only)")
    elif execution_mode == "agentic":
        llm_provider = LLMProvider.from_config(config.llm_config)
        if llm_provider is None:
            raise RuntimeError(
                "Agentic mode requires an LLM provider but none is available. "
                "Set the API key environment variable (e.g. ANTHROPIC_API_KEY) "
                "or configure llm_config in transform_config.yaml. "
                "Use --execution-mode standalone for deterministic-only mode."
            )
        logger.info(f"Execution mode: AGENTIC (LLM: {llm_provider.provider}/{llm_provider.model})")
    else:  # auto
        llm_provider = LLMProvider.from_config(config.llm_config)
        if llm_provider:
            logger.info(f"Execution mode: AGENTIC (auto-detected LLM: {llm_provider.provider}/{llm_provider.model})")
        else:
            logger.info("Execution mode: STANDALONE (no LLM provider available — auto-detected)")

    # Read code file
    pyspark_code = Path(args.pyspark).read_text(encoding="utf-8")

    # --- Resolve technology ---
    technology = args.technology
    if technology == "auto":
        technology = detect_technology(args.pyspark, pyspark_code)
    tech_label = TECHNOLOGY_LABELS.get(technology, technology)
    logger.info(f"Technology: {tech_label}")

    # Detect or set framework mode (only relevant for PySpark/Glue)
    if technology in ("pyspark", "glue"):
        if args.mode == "standard":
            config.activate_framework(None)
            logger.info("Mode: STANDARD (no framework — all mappings must be explicit in code)")
        else:
            detected_fw = config.detect_framework(pyspark_code)
            config.activate_framework(detected_fw)
            if detected_fw:
                logger.info(f"Mode: FRAMEWORK — auto-detected '{detected_fw}' "
                           f"({len(config.framework_contexts)} filtered contexts, "
                           f"{len(config.framework_class_prefixes)} class prefixes)")
            else:
                logger.info("Mode: STANDARD (no framework signatures detected in code)")
    else:
        config.activate_framework(None)

    logger.info("=" * 60)
    logger.info("STTM Drift Detection — STTM is the source of truth")
    logger.info("=" * 60)
    logger.info(f"STTM: {args.sttm}")
    logger.info(f"Code: {args.pyspark} ({tech_label})")
    logger.info(f"Output: {args.output_dir}")
    logger.info(f"Execution: {'agentic (LLM-enhanced)' if llm_provider else 'standalone (deterministic)'}")

    # Step 1: Parse STTM (source of truth)
    sttm_mappings, sttm_metadata = parse_sttm(args.sttm, args.sheet, args.target_table)

    # Step 2: Parse code — dispatch to technology-specific parser
    tech_parser = TECH_PARSERS.get(technology)
    if tech_parser is not None:
        # Glue parser also accepts json_config
        if technology == "glue":
            pyspark_extractions, pyspark_metadata = tech_parser(args.pyspark, args.json_config)
        else:
            pyspark_extractions, pyspark_metadata = tech_parser(args.pyspark)
    else:
        # Default: PySpark parser
        pyspark_extractions, pyspark_metadata = parse_pyspark(args.pyspark, args.json_config)
    pyspark_metadata["technology"] = technology

    # Step 3: Compare — check each STTM mapping against the code (deterministic baseline)
    sttm_metadata["pyspark_file"] = args.pyspark
    results = compare_mappings(sttm_mappings, pyspark_extractions, technology=technology)

    # Step 3b: LLM review (agentic mode only)
    if llm_provider:
        logger.info(f"Agentic mode: LLM reviewing {len(results)} comparisons...")
        llm_overrides = 0
        llm_failures = 0
        for i, result in enumerate(results, 1):
            logger.info(f"  LLM review [{i}/{len(results)}]: {result['target_column']}")
            llm_verdict = llm_provider.review_comparison(
                target_column=result["target_column"],
                sttm_info=result.get("sttm", {}),
                pyspark_info=result.get("pyspark", {}),
                baseline_result={
                    "status": result["status"],
                    "severity": result.get("severity", "INFO"),
                    "explanation": result.get("explanation", ""),
                },
            )

            if llm_verdict.get("fallback"):
                result["verdict_source"] = "deterministic_fallback"
                result["llm_reasoning"] = llm_verdict.get("reasoning", "")
                result["llm_override"] = False
                llm_failures += 1
            elif llm_verdict.get("override"):
                result["verdict_source"] = "llm"
                result["llm_reasoning"] = llm_verdict.get("reasoning", "")
                result["llm_override"] = True
                result["baseline_status"] = result["status"]
                result["baseline_severity"] = result.get("severity", "INFO")
                result["status"] = llm_verdict["status"]
                result["severity"] = llm_verdict.get("severity", result.get("severity", "INFO"))
                result["explanation"] = llm_verdict.get("explanation", result.get("explanation", ""))
                llm_overrides += 1
            else:
                result["verdict_source"] = "llm"
                result["llm_reasoning"] = llm_verdict.get("reasoning", "")
                result["llm_override"] = False

        logger.info(f"LLM review complete: {llm_overrides} overrides, {llm_failures} fallbacks")
    else:
        for result in results:
            result["verdict_source"] = "deterministic"

    # Step 4: Run compliance checks (if requested)
    compliance_results = None
    checks_arg = args.checks.strip().lower()
    if checks_arg != "sttm_only":
        pyspark_lines = pyspark_code.splitlines()
        if checks_arg == "all":
            enabled_modules = None  # All enabled modules
        else:
            enabled_modules = {m.strip() for m in checks_arg.split(",") if m.strip()}

        # Resolve repo root for CI/CD pipeline scanning
        repo_root = getattr(args, "repo_root", None)
        if not repo_root:
            # Default: parent directory of the PySpark file
            repo_root = str(Path(args.pyspark).resolve().parent)

        logger.info("-" * 60)
        logger.info("Running compliance checks...")
        compliance_results = run_compliance_checks(
            pyspark_code, pyspark_lines, pyspark_extractions, enabled_modules,
            repo_root=repo_root,
        )
        logger.info(f"Compliance: {compliance_results['total_findings']} findings, "
                    f"gate: {compliance_results['gate_status']}")

    # Step 5: Generate drift report
    report = generate_drift_report(results, sttm_metadata, pyspark_metadata, llm_provider)

    # Attach compliance results to report if present
    if compliance_results:
        report["drift_report"]["compliance"] = {
            "gate_status": compliance_results["gate_status"],
            "summary": compliance_results["summary"],
            "findings": compliance_results["findings"],
        }

    save_drift_report(report, args.output_dir)

    # Step 6: Generate corrective code if drifts found (technology-aware)
    # Determine the effective JSON config path used during parsing
    _json_config_used = args.json_config
    if not _json_config_used and technology == "glue":
        # Check if auto-detection found a JSON config
        code_for_detect = Path(args.pyspark).read_text(encoding="utf-8")
        json_ref = _detect_json_config_reference(code_for_detect)
        if json_ref:
            pyspark_dir = Path(args.pyspark).parent
            for candidate in [pyspark_dir / json_ref, pyspark_dir / Path(json_ref).name, Path(json_ref)]:
                if candidate.exists():
                    _json_config_used = str(candidate)
                    break

    if _json_config_used:
        # JSON-config-driven job: update the JSON with missing columns in SQL
        generate_updated_json_config(_json_config_used, results, args.output_dir)
    # Always also generate updated code file (PySpark patches for non-JSON parts)
    generate_updated_code(args.pyspark, results, args.output_dir, technology)

    # Summary
    summary = report["drift_report"]["summary"]
    logger.info("=" * 60)
    logger.info(f"STTM Drift: {summary['matches']} matches, {summary['drifts']} drifts "
                f"out of {summary['total_checked']} mappings checked")
    if summary["drifts"] > 0:
        logger.info(f"By severity: {summary['by_severity']}")
    else:
        logger.info("PySpark code is fully aligned with the STTM spec")
    if llm_provider:
        logger.info(f"LLM overrides: {summary.get('llm_overrides', 0)}")

    if compliance_results:
        logger.info("-" * 60)
        logger.info(f"Compliance gate: {compliance_results['gate_status']}")
        for mod, mod_summary in compliance_results["summary"].items():
            count = mod_summary["total_findings"]
            max_sev = mod_summary["max_severity"]
            if count > 0:
                logger.info(f"  {mod}: {count} finding(s), max severity: {max_sev}")
            else:
                logger.info(f"  {mod}: CLEAN")

    logger.info("=" * 60)

    # --- S3 output upload ---
    s3_output = getattr(args, "s3_output", None)
    if s3_output:
        logger.info(f"Uploading outputs to S3: {s3_output}")
        _s3_upload_directory(args.output_dir, s3_output)
        logger.info("S3 upload complete")

    # Clean up temp directory if we downloaded S3 inputs
    if s3_tmp_dir and os.path.isdir(s3_tmp_dir):
        import shutil
        shutil.rmtree(s3_tmp_dir, ignore_errors=True)
        logger.info(f"Cleaned up temp directory: {s3_tmp_dir}")

    # Exit code: non-zero if drifts OR critical compliance findings
    has_drifts = summary["drifts"] > 0
    has_compliance_fail = (
        compliance_results is not None
        and compliance_results["gate_status"] == "FAIL"
    )
    return 0 if (not has_drifts and not has_compliance_fail) else 1


if __name__ == "__main__":
    sys.exit(main())
