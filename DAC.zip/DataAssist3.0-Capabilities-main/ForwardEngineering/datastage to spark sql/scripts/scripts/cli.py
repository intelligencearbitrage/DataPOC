"""
cli.py
======
CLI entry point for the datastage-spark-sql-conversion pipeline scripts.

Registers and dispatches all generated scripts for the project.

Usage:
    python cli.py all                    # Run all scripts in dependency order
    python cli.py parse_datastage_xml <xml_file> [--output <yaml>]
    python cli.py generate_spark_sql_ins [--output <path>] [--validate-only]
    python cli.py generate_spark_sql_upd [--output <path>] [--validate-only]
    python cli.py validate               # Validate all output SQL files

Part of: datastage-spark-sql-conversion pipeline
"""

from __future__ import annotations

import argparse
import subprocess
import sys
from pathlib import Path

SCRIPTS_DIR = Path(__file__).resolve().parent
PROJECT_ROOT = SCRIPTS_DIR.parent.parent

SCRIPTS = {
    "parse_datastage_xml": {
        "module": SCRIPTS_DIR / "parse_datastage_xml.py",
        "description": "Parse DataStage XML to extract stage DAG, schemas, SQL",
        "required_args": ["<xml_file>"],
        "optional_args": ["--output <yaml_file>"],
    },
    "generate_spark_sql_ins": {
        "module": SCRIPTS_DIR / "generate_spark_sql_ins.py",
        "description": "Generate Spark SQL for INSERT job (SCD Type 2 inserts)",
        "required_args": [],
        "optional_args": ["--output <sql_file>", "--validate-only"],
        "output": PROJECT_ROOT / "scripts-output" / "output" / "j_org_case_odw_dim_case_ins.sql",
    },
    "generate_spark_sql_upd": {
        "module": SCRIPTS_DIR / "generate_spark_sql_upd.py",
        "description": "Generate Spark SQL for UPDATE job (SCD Type 2 close/expire)",
        "required_args": [],
        "optional_args": ["--output <sql_file>", "--validate-only"],
        "output": PROJECT_ROOT / "scripts-output" / "output" / "j_org_case_odw_dim_case_upd.sql",
    },
}

DEPENDENCY_ORDER = [
    "parse_datastage_xml",
    "generate_spark_sql_ins",
    "generate_spark_sql_upd",
]


def run_script(script_name: str, extra_args: list[str]) -> int:
    """Run a named script with extra arguments. Returns exit code."""
    script_info = SCRIPTS.get(script_name)
    if script_info is None:
        print(f"ERROR: Unknown script: {script_name}", file=sys.stderr)
        return 1
    module = script_info["module"]
    if not module.exists():
        print(f"ERROR: Script not found: {module}", file=sys.stderr)
        return 1
    cmd = [sys.executable, str(module)] + extra_args
    print(f"\n--- Running: {script_name} ---")
    print(f"    Command: {' '.join(cmd)}")
    result = subprocess.run(cmd, capture_output=False)
    return result.returncode


def run_all() -> int:
    """Run all generator scripts in dependency order."""
    print("Running all datastage-spark-sql-conversion scripts...")
    overall_rc = 0
    # parse_datastage_xml requires xml_file argument - run on both inputs
    ins_xml = (
        PROJECT_ROOT
        / "user-config" / "inputs" / "J_ORG_CASE_ODW_DIM_CASE_INS.xml"
    )
    upd_xml = (
        PROJECT_ROOT
        / "user-config" / "inputs" / "J_ORG_CASE_ODW_DIM_CASE_UPD.xml"
    )
    if ins_xml.exists():
        rc = run_script(
            "parse_datastage_xml",
            [str(ins_xml), "--output",
             str(PROJECT_ROOT / "agent-output" / "research" / "ins_parsed.yaml")]
        )
        overall_rc = max(overall_rc, rc)
    if upd_xml.exists():
        rc = run_script(
            "parse_datastage_xml",
            [str(upd_xml), "--output",
             str(PROJECT_ROOT / "agent-output" / "research" / "upd_parsed.yaml")]
        )
        overall_rc = max(overall_rc, rc)

    for script_name in ["generate_spark_sql_ins", "generate_spark_sql_upd"]:
        rc = run_script(script_name, [])
        overall_rc = max(overall_rc, rc)

    if overall_rc == 0:
        print("\n[PASS] All scripts completed successfully.")
        print("\nOutput files:")
        for name, info in SCRIPTS.items():
            out = info.get("output")
            if out and Path(out).exists():
                size_kb = Path(out).stat().st_size / 1024
                print(f"  {out}  ({size_kb:.1f} KB)")
    else:
        print(f"\n[FAIL] One or more scripts returned non-zero exit code: {overall_rc}")
    return overall_rc


def validate_all() -> int:
    """Validate all generated SQL output files."""
    print("Validating all output SQL files...")
    rc = 0
    for script_name in ["generate_spark_sql_ins", "generate_spark_sql_upd"]:
        result = run_script(script_name, ["--validate-only"])
        rc = max(rc, result)
    return rc


def main() -> None:
    parser = argparse.ArgumentParser(
        description="CLI for datastage-spark-sql-conversion pipeline scripts",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=_build_help(),
    )
    parser.add_argument(
        "command",
        choices=list(SCRIPTS.keys()) + ["all", "validate"],
        help="Script to run or 'all' to run all scripts",
    )
    parser.add_argument(
        "extra_args",
        nargs=argparse.REMAINDER,
        help="Additional arguments passed to the script",
    )
    args = parser.parse_args()

    if args.command == "all":
        sys.exit(run_all())
    elif args.command == "validate":
        sys.exit(validate_all())
    else:
        sys.exit(run_script(args.command, args.extra_args))


def _build_help() -> str:
    lines = ["\nAvailable scripts:"]
    for name, info in SCRIPTS.items():
        lines.append(f"  {name}")
        lines.append(f"    {info['description']}")
        if info["required_args"]:
            lines.append(f"    Required: {' '.join(info['required_args'])}")
        if info["optional_args"]:
            lines.append(f"    Optional: {' '.join(info['optional_args'])}")
    return "\n".join(lines)


if __name__ == "__main__":
    main()
