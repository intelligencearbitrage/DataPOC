"""Comprehensive check — all fixes and all previously correct things."""
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent.parent
script = (ROOT / "agent-output/scripts/generate_spark_sql_ins.py").read_text(encoding="utf-8")
output = (ROOT / "scripts-output/output/j_org_case_odw_dim_case_ins.sql").read_text(encoding="utf-8")
upd    = (ROOT / "scripts-output/output/j_org_case_odw_dim_case_upd.sql").read_text(encoding="utf-8")

results = []

def chk(label, pattern, text, should_exist=True):
    found = pattern in text
    ok = found if should_exist else not found
    results.append((ok, label))

# ── ISSUE 1: columns present in src_case source query ────────────────────────
chk("ROW_VERS_ID selected from CA in src_case",        "CA.row_vers_id",       script)
chk("ROW_CREAT_USER selected from CA in src_case",     "CA.row_creat_user",    script)
chk("ROW_CREAT_TS aliased from csh11 in src_case",     "csh11.eff_ts                            AS row_creat_ts", script)
chk("ROW_UPDATE_USER selected from CA in src_case",    "CA.row_update_user",   script)
chk("ROW_UPDATE_TS selected from CA in src_case",      "CA.row_update_ts",     script)
chk("ROW_VERS_ID in INSERT column list",               "    ROW_VERS_ID,",     script)
chk("ROW_CREAT_USER in INSERT column list",            "    ROW_CREAT_USER,",  script)
chk("ROW_CREAT_TS in INSERT column list",              "    ROW_CREAT_TS,",    script)
chk("ROW_UPDATE_USER in INSERT column list",           "    ROW_UPDATE_USER,", script)
chk("ROW_UPDATE_TS in INSERT column list",             "    ROW_UPDATE_TS,",   script)
chk("ROW_VERS_ID in final SELECT",                     "    xi.row_vers_id,",  script)
chk("ROW_CREAT_USER in final SELECT",                  "    xi.row_creat_user,", script)
chk("ROW_CREAT_TS in final SELECT",                    "    xi.row_creat_ts,", script)
chk("ROW_UPDATE_USER in final SELECT",                 "    xi.row_update_user,", script)
chk("ROW_UPDATE_TS in final SELECT",                   "    xi.row_update_ts,", script)
chk("CASE_REOPENED_IND derivation in xfrm_ins",        "CASE WHEN jd.CASE_REOPEN_DT IS NULL THEN", script)
chk("CASE_REOPENED_IND in INSERT column list",         "    CASE_REOPENED_IND\n)", script)
chk("CASE_REOPENED_IND in final SELECT",               "xi.CASE_REOPENED_IND", script)
issue1_end = len(results)

# ── ISSUE 2: Correct new cat_names ───────────────────────────────────────────
chk("GLOBALOREGONCOUNTYFIPS (MNG_CNTY_FIPS)",              "cat_name = 'GLOBALOREGONCOUNTYFIPS'",                               script)
chk("DISPLAYCASECLOSUREREASONCODE (PND_CLS_RSN)",          "cat_name = 'DISPLAYCASECLOSUREREASONCODE'",                         script)
chk("DISPLAYCASESTATUS (CRNT_STAT)",                       "cat_name = 'DISPLAYCASESTATUS'",                                    script)
chk("DISPLAYCASEFUNCTION (CRNT_CASE_FUNC)",                "cat_name = 'DISPLAYCASEFUNCTION'",                                  script)
chk("DISPLAYCASENONCOOPERATIONSTATUSCODE (NON_COOP_STAT)", "cat_name = 'DISPLAYCASENONCOOPERATIONSTATUSCODE'",                  script)
chk("DISPLAYCASENONCOOPERATIONREASONCODE (NON_COOP_RSN)",  "cat_name = 'DISPLAYCASENONCOOPERATIONREASONCODE'",                  script)
chk("DISPLAYCASENONCOOPERATIONPUBLICASSISTANCESTATUSCODE (NONCOOP_PUBASST)", "cat_name = 'DISPLAYCASENONCOOPERATIONPUBLICASSISTANCESTATUSCODE'", script)
chk("DISPLAYINTERSTATEPERSPECTIVETYPE (INTRSTE)",          "cat_name = 'DISPLAYINTERSTATEPERSPECTIVETYPE'",                     script)
chk("DISPLAYGOODCAUSESTATUS (GOOD_CAUSE)",                 "cat_name = 'DISPLAYGOODCAUSESTATUS'",                               script)
issue2_new_end = len(results)

# ── ISSUE 2: Old wrong cat_names must be ABSENT ───────────────────────────────
chk("OLD GLOBALCALIFORNIACOUNTYFIPS absent",               "cat_name = 'GLOBALCALIFORNIACOUNTYFIPS'",                           script, False)
chk("OLD DISPLAYCASEPENDINGCLOSURETYPECODE for PND_CLS_RSN absent", "lkp_pnd_cls_rsn.cat_name = 'DISPLAYCASEPENDINGCLOSURETYPECODE'",  script, False)
chk("OLD DISPLAYCASEPENDINGCLOSURESTATUSCODE for CRNT_STAT absent", "lkp_crnt_stat.cat_name = 'DISPLAYCASEPENDINGCLOSURESTATUSCODE'", script, False)
chk("OLD DISPLAYCASESUBTYPE for CASE_FUNC absent",         "lkp_case_func.cat_name = 'DISPLAYCASESUBTYPE'",                     script, False)
chk("OLD DISPLAYCASEPENDINGCLOSURESTATUSCODE for NON_COOP_STAT absent", "lkp_non_coop_stat.cat_name = 'DISPLAYCASEPENDINGCLOSURESTATUSCODE'", script, False)
chk("OLD DISPLAYCASEPENDINGCLOSURESTATUSCODE for NON_COOP_RSN absent",  "lkp_non_coop_rsn.cat_name = 'DISPLAYCASEPENDINGCLOSURESTATUSCODE'",  script, False)
chk("OLD DISPLAYCASEASSISTANCESTATUS for NONCOOP_PUBASST absent","lkp_noncoop_pubasst.cat_name = 'DISPLAYCASEASSISTANCESTATUS'",   script, False)
chk("OLD DISPLAYCASEPENDINGCLOSURESTATUSCODE for INTRSTE absent","lkp_intrste.cat_name = 'DISPLAYCASEPENDINGCLOSURESTATUSCODE'",  script, False)
chk("OLD DISPLAYCASEPENDINGCLOSURESTATUSCODE for GOOD_CAUSE absent","lkp_good_cause.cat_name = 'DISPLAYCASEPENDINGCLOSURESTATUSCODE'",script, False)
issue2_old_end = len(results)

# ── Previously correct cat_names still intact ────────────────────────────────
chk("DISPLAYCASEASSISTANCESTATUS (FED_AID)",           "lkp_fed_aid.cat_name = 'DISPLAYCASEASSISTANCESTATUS'",     script)
chk("DISPLAYCASEASSISTANCESTATUS (STAT_AID)",          "lkp_stat_aid.cat_name = 'DISPLAYCASEASSISTANCESTATUS'",    script)
chk("DISPLAYCASEPENDINGCLOSURESTATUSCODE (PND_CLS_STAT)","lkp_pnd_cls_stat.cat_name = 'DISPLAYCASEPENDINGCLOSURESTATUSCODE'",script)
chk("DISPLAYCASEPENDINGCLOSURETYPECODE (PND_CLS_TYPE)","lkp_pnd_cls_type.cat_name = 'DISPLAYCASEPENDINGCLOSURETYPECODE'",  script)
chk("DISPLAYCASEASSISTANCESTATUS (PUB_ASST)",          "lkp_pub_asst.cat_name = 'DISPLAYCASEASSISTANCESTATUS'",    script)
chk("CASE_REGISTR_NM passthrough (no lkp_case_registr JOIN)", "lkp_case_registr.cat_name", script, False)
chk("DISPLAYIVDSERVICESREQUESTED (CRNT_TYPE)",         "lkp_crnt_type.cat_name = 'DISPLAYIVDSERVICESREQUESTED'",   script)
chk("DISPLAYCASENONIVDSOURCEDOCUMENTTYPE",             "lkp_non_ivd_doc.cat_name = 'DISPLAYCASENONIVDSOURCEDOCUMENTTYPE'", script)
chk("RSTRN_ORDR_NM CASE expr (no lkp_rstrn_ordr JOIN)", "lkp_rstrn_ordr.cat_name", script, False)
chk("DISPLAYCASEPROCESS (CASE_PROC)",                  "lkp_case_proc.cat_name = 'DISPLAYCASEPROCESS'",            script)
chk("DISPLAYCASEAUTOMATICREASSIGNMENTRULECODE",        "lkp_auto_reasm.cat_name = 'DISPLAYCASEAUTOMATICREASSIGNMENTRULECODE'", script)
chk("DISPLAYIVDSERVICESREQUESTED (SERV_REQ)",          "lkp_serv_req.cat_name = 'DISPLAYIVDSERVICESREQUESTED'",    script)
chk("GLOBALCOUNTRYISO (CNTRY)",                        "lkp_cntry.cat_name = 'GLOBALCOUNTRYISO'",                  script)
chk("DISPLAYCASESUBTYPE (CASE_SUB)",                   "lkp_case_sub.cat_name = 'DISPLAYCASESUBTYPE'",             script)
intact_cat_end = len(results)

# ── BUG A & B: RSTRN_ORDR_NM and CASE_REGISTR_NM must NOT use code lookups ──
chk("BUG A: RSTRN_ORDR_NM uses CASE expression (not lookup)",
    "WHEN src.rstrn_ordr_cd = 'NAP'            THEN 'N/A'", script)
chk("BUG A: RSTRN_ORDR_NM lookup JOIN absent",
    "LEFT JOIN src_code lkp_rstrn_ordr", script, False)
chk("BUG B: CASE_REGISTR_NM uses passthrough (not lookup)",
    "ELSE src.case_registr_cd", script)
chk("BUG B: CASE_REGISTR_NM lookup JOIN absent",
    "LEFT JOIN src_code lkp_case_registr", script, False)
bugab_end = len(results)

# ── Previously correct SQL constructs still intact ───────────────────────────
chk("last_pmt alias (not CAST)",                       ") last_pmt ON cas.case_acct_sum_id = last_pmt", script)
chk("CAST alias absent",                               ") CAST ON",                                     script, False)
chk("INSERT OVERWRITE DIRECTORY syntax",               "INSERT OVERWRITE DIRECTORY '${JP_DIMCASE_UPD_DS}'", script)
chk("USING PARQUET",                                   "USING PARQUET",                                 script)
chk("Section 8 old-row BTCH_RUN_ID <>",               "dc_old.BTCH_RUN_ID <> CAST",                    script)
chk("Section 8 new-row subquery BTCH_RUN_ID =",       "dc_new.BTCH_RUN_ID    = CAST",                  script)
chk("CASE_CAT_FINAL COALESCE override",                "COALESCE(dc_cat.Case_Category, src.CASE_CAT)   AS CASE_CAT_FINAL", script)
chk("DSHostName comment on UPDATED_BY",                "DataStage derivation: DSHostName",              script)
chk("SCD2 EFFECTIVE_END_TS 9999-12-31",                "CAST('9999-12-31 23:59:59' AS TIMESTAMP)",      script)
chk("SCD2 CURRENT_RECORD_INDICATOR Y on insert",       "'Y'                                                 AS CURRENT_RECORD_INDICATOR", script)
chk("xfrm_upd CHECKSUM IS DISTINCT FROM",             "CHECKSUM_FROM_SRC IS DISTINCT FROM CHECKSUM_FROM_TGT", script)
chk("xfrm_ins DIM_CASE_KEY IS NULL routing",          "jd.DIM_CASE_KEY IS NULL",                       script)
chk("MD5 checksum present",                           "MD5(CONCAT_WS(",                                script)
chk("INSERT INTO ODW.DIM_CASE present",               "INSERT INTO ODW.DIM_CASE",                      script)
chk("dim_case_current CURRENT_RECORD_INDICATOR=Y",    "WHERE DC.CURRENT_RECORD_INDICATOR = 'Y'",       script)
chk("All 7 SET parameters (JP_DIMCASE_UPD_DS)",       "SET JP_DIMCASE_UPD_DS",                         script)
intact_sql_end = len(results)

# ── UPD job intact ────────────────────────────────────────────────────────────
chk("UPD: MERGE INTO ODW.DIM_CASE",                   "MERGE INTO ODW.DIM_CASE AS tgt",                upd)
chk("UPD: match CURRENT_RECORD_INDICATOR=Y",          "AND tgt.CURRENT_RECORD_INDICATOR = 'Y'",        upd)
chk("UPD: UPDATE SET EFFECTIVE_END_TS",               "tgt.EFFECTIVE_END_TS         = src.EFFECTIVE_END_TS", upd)
chk("UPD: UPDATE SET CURRENT_RECORD_INDICATOR",       "tgt.CURRENT_RECORD_INDICATOR = src.CURRENT_RECORD_INDICATOR", upd)
chk("UPD: UPDATE SET UPDATED_BY",                     "tgt.UPDATED_BY               = src.UPDATED_BY", upd)
chk("UPD: UPDATE SET BTCH_RUN_ID",                    "tgt.BTCH_RUN_ID              = src.BTCH_RUN_ID", upd)
chk("UPD: CREATE OR REPLACE TEMP VIEW ds_dim_case_upd","CREATE OR REPLACE TEMP VIEW ds_dim_case_upd",  upd)
upd_end = len(results)

# ── Print ─────────────────────────────────────────────────────────────────────
groups = [
    ("ISSUE 1  — Missing columns (source + INSERT + SELECT)", 0, issue1_end),
    ("ISSUE 2  — Correct new cat_names", issue1_end, issue2_new_end),
    ("ISSUE 2  — Old wrong cat_names ABSENT", issue2_new_end, issue2_old_end),
    ("SAFE     — Previously correct cat_names still intact", issue2_old_end, intact_cat_end),
    ("BUG A+B  — RSTRN_ORDR_NM and CASE_REGISTR_NM no code lookup", intact_cat_end, bugab_end),
    ("SAFE     — Previously correct SQL constructs intact", bugab_end, intact_sql_end),
    ("SAFE     — UPD job still intact", intact_sql_end, upd_end),
]

fail_count = 0
for title, start, end in groups:
    print(f"\n-- {title} --")
    for ok, label in results[start:end]:
        print(f"  [{'PASS' if ok else 'FAIL'}] {label}")
        if not ok:
            fail_count += 1

total = len(results)
print(f"\n" + "="*60)
print(f"RESULT: {'ALL ' + str(total) + ' CHECKS PASS' if fail_count == 0 else str(fail_count) + ' FAILURE(S) out of ' + str(total)}")
