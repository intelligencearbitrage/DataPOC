# datastage-spark-sql-conversion — Scripts

Generated scripts for converting IBM InfoSphere DataStage v11.7 XML exports
to Apache Spark SQL.

## Quick Start

```bash
cd datastage-spark-sql-conversion

# Run all scripts (parse XML + generate both SQL files)
python agent-output/scripts/cli.py all

# Validate existing output files
python agent-output/scripts/cli.py validate
```

## Scripts

### parse_datastage_xml.py

Parses a DataStage XML export file and outputs a YAML summary of stages,
links, parameters, and SQL.

```bash
python agent-output/scripts/parse_datastage_xml.py \
    user-config/inputs/J_ORG_CASE_ODW_DIM_CASE_INS.xml \
    --output agent-output/research/ins_parsed.yaml

python agent-output/scripts/parse_datastage_xml.py \
    user-config/inputs/J_ORG_CASE_ODW_DIM_CASE_UPD.xml \
    --output agent-output/research/upd_parsed.yaml
```

**Output:** YAML files in `agent-output/research/`

---

### generate_spark_sql_ins.py

Generates/validates the Spark SQL for the INSERT job.

```bash
python agent-output/scripts/generate_spark_sql_ins.py
python agent-output/scripts/generate_spark_sql_ins.py --validate-only
```

**Output:** `scripts-output/output/j_org_case_odw_dim_case_ins.sql`

---

### generate_spark_sql_upd.py

Generates/validates the Spark SQL for the UPDATE job.

```bash
python agent-output/scripts/generate_spark_sql_upd.py
python agent-output/scripts/generate_spark_sql_upd.py --validate-only
```

**Output:** `scripts-output/output/j_org_case_odw_dim_case_upd.sql`

---

## Output Files

| File | Description |
|------|-------------|
| `scripts-output/output/j_org_case_odw_dim_case_ins.sql` | Spark SQL INSERT job — SCD Type 2 inserts with multi-lookup joins, checksums, ~114 columns |
| `scripts-output/output/j_org_case_odw_dim_case_upd.sql` | Spark SQL UPDATE job — SCD Type 2 close/expire via MERGE INTO |

## Requirements

- Python 3.8+ (standard library only, no pip installs needed)

## SQL Script Details

### j_org_case_odw_dim_case_ins.sql

Implements the full INSERT job logic:

1. **Parameters** — SET variables for schemas, date windows, batch ID
2. **src_case** — Source read from `ORIGIN.case` with 15+ LEFT JOINs (public assistance, court cases, status history, interstate perspective, etc.)
3. **src_code / src_code_long / src_code_short2** — Code table reads for decode lookups
4. **src_data_relab / src_out_compliance / src_court_case** — Task indicator lookups
5. **src_dim_cat** — Category aggregation (SUM of aid code indicators)
6. **dim_case_current** — Current DIM_CASE records for SCD2 comparison
7. **enriched_src** — Source enriched with all code decodes (23 LEFT JOINs to code CTEs)
8. **src_with_checksum** — MD5 fingerprint of source record (Checksum_163)
9. **tgt_with_checksum** — MD5 fingerprint of target record (Checksum_168)
10. **joined_data** — LEFT OUTER JOIN source + target on CASE_ID (JN_CASEID)
11. **xfrm_upd** — Update candidates: existing records with checksum change
12. **xfrm_ins** — Insert candidates: new + changed records (Transformer_174)
13. **INSERT INTO ODW.DIM_CASE** — Final insert with SCD2 columns

### j_org_case_odw_dim_case_upd.sql

Implements the UPDATE job (close old SCD2 records):

1. **Parameters** — SET variables for schema and dataset path
2. **ds_dim_case_upd** — Dataset source as parquet TEMP VIEW (DS_DIM_CASE_UPD)
3. **MERGE INTO ODW.DIM_CASE** — Update 4 columns on matched current records

## Domain

Government Child Support Enforcement (IV-D program)
