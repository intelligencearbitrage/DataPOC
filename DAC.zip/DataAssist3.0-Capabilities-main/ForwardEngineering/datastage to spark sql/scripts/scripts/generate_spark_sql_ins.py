"""
generate_spark_sql_ins.py
=========================
Generator script for the INSERT job Spark SQL file.

Reads research findings and plans, then writes the complete
Spark SQL script for J_ORG_CASE_ODW_DIM_CASE_INS to:
    scripts-output/output/j_org_case_odw_dim_case_ins.sql

The SQL implements:
  - Source read from ORIGIN.case (complex multi-join query)
  - Code lookup CTEs (DB2_CODE, Copy_of_DB2_CODE, Copy_2_of_DB2_CODE)
  - Task/compliance/court lookup CTEs
  - Category aggregation CTE (DB2_DIM_CAT)
  - Current DIM_CASE lookup CTE (DB2_DIM_CASE_LKP)
  - Enriched source with code decodes (LKP_CODES, Lookup_99)
  - Source checksum CTE (Checksum_163)
  - Target checksum CTE (Checksum_168)
  - LEFT OUTER JOIN source+target (JN_CASEID)
  - SCD2 routing: xfrm_ins and xfrm_upd (Transformer_174)
  - INSERT INTO ODW.DIM_CASE (DB2_DIM_CASE, WriteMode=0)

Usage:
    python generate_spark_sql_ins.py [--output <path>]

Part of: datastage-spark-sql-conversion pipeline
Component: generate_spark_sql_ins
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------

PROJECT_ROOT = Path(__file__).resolve().parent.parent.parent
OUTPUT_FILE = (
    PROJECT_ROOT / "scripts-output" / "output" / "j_org_case_odw_dim_case_ins.sql"
)
RESEARCH_INS = PROJECT_ROOT / "agent-output" / "research" / "ins_job_findings.yaml"
PLAN_INS = PROJECT_ROOT / "agent-output" / "plans" / "generate_spark_sql_ins_plan.yaml"

# ---------------------------------------------------------------------------
# Embedded SQL constant — authoritative source for the INS job SQL.
# This script regenerates the output file from this constant even if the
# output file has been deleted.
# ---------------------------------------------------------------------------
SQL_CONTENT = r"""


-- ============================================================
-- J_ORG_CASE_ODW_DIM_CASE_INS: Insert/Update to ODW.DIM_CASE
-- ============================================================
-- DataStage Job   : J_ORG_CASE_ODW_DIM_CASE_INS
-- DataStage Version: 11.7
-- Job Version     : 56.0
-- Target Platform : Apache Spark SQL (standalone)
-- Category        : Jobs\Deployment\Conformed Dimensions
-- Domain          : Government Child Support Enforcement (IV-D)
--
-- Description:
--   This Job reads data from ORIGIN Source Table Case and loads data
--   into ODW table DIM_CASE after identifying Insert and Update Records.
--   Implements SCD Type 2 logic: new records are inserted with
--   EFFECTIVE_START_TS = current time, EFFECTIVE_END_TS = 9999-12-31.
--   Changed records: old row is closed (UPDATE job), new version inserted.
--
-- Stage DAG (DataStage -> Spark SQL CTE):
--   DB2_CASE             -> src_case          (source read, complex multi-join)
--   DB2_CODE             -> src_code          (code table, short decode)
--   Copy_of_DB2_CODE     -> src_code_long     (code table, long decode)
--   Copy_2_of_DB2_CODE   -> src_code_short2   (code table, short decode copy)
--   DB2_DATA_RELAB_TASK_DUE -> src_data_relab (task due indicator)
--   DB2_OUT_OF_COMPLIANCE   -> src_out_compliance (compliance task indicator)
--   DB2_COURT_CASE          -> src_court_case (court case delinquency date)
--   DB2_DIM_CAT             -> src_dim_cat    (category aggregation)
--   DB2_DIM_CASE_LKP        -> dim_case_current (current DIM_CASE records)
--   CP_CASE_ASSISTANCE   -> (fan-out, represented by CTE references)
--   LKP_CODES            -> code_lookup CTEs (11 code lookups as LEFT JOINs)
--   Lookup_99            -> lkp_non_coop (non-coop/status lookups)
--   FILT_CODE            -> WHERE clause on code validity
--   Filter_100           -> WHERE clause on filter conditions
--   Checksum_163         -> src_with_checksum (MD5 source fingerprint)
--   Checksum_168         -> tgt_with_checksum (MD5 target fingerprint)
--   JN_CASEID            -> joined_data       (LEFT OUTER JOIN source + target)
--   Transformer_174      -> xfrm_ins, xfrm_upd (SCD2 routing decision)
--   XFRM_INS_UPD         -> decode expressions inline in enriched_src
--   Transformer_161      -> pass-through (no transformation)
--   Transformer_171      -> SCD2 column assignment
--   DB2_DIM_CASE         -> INSERT INTO ODW.DIM_CASE
--   DS_DIM_CASE_UPD      -> xfrm_upd (output for UPDATE job)
--
-- Version History:
--   1.0  2016-10-27  Initial Job
--   2.0  2019-07-08  Added columns for determination
--   3.0  2021-12-13  Added column for dependents needing paternity established
-- ============================================================

-- ============================================================
-- SECTION 1: PARAMETER DECLARATIONS
-- Set these before execution or pass as Spark configuration.
-- Maps to DataStage job parameters:
--   PS_ODW_TGT (parameter set) -> SCHEMA_ODW
--   PS_ORG_SRC (parameter set) -> SCHEMA_ORG
--   JP_LAST_RUN_DT, JP_BTCH_RUN_ID, DAILY_HIGH_DT_TS, DAILY_LOW_DT_TS
-- ============================================================
-- PARAM: PS_ODW_TGT -> target schema (ODW)
-- PARAM: PS_ORG_SRC -> source schema (ORIGIN)
SET SCHEMA_ORG       = 'ORIGIN';
SET SCHEMA_ODW       = 'ODW';
SET JP_LAST_RUN_DT       = '2024-01-01';
SET JP_BTCH_RUN_ID       = 0;
SET DAILY_HIGH_DT_TS     = '2024-01-02 00:00:00';
SET DAILY_LOW_DT_TS      = '2024-01-01 00:00:00';
SET JP_DIMCASE_UPD_DS    = '/path/to/dim_case_upd_dataset';

-- ============================================================
-- SECTION 2: SOURCE CTEs
-- ============================================================

WITH

-- ----------------------------------------------------------
-- CTE: src_case (DataStage stage: DB2_CASE, DB2ConnectorPX)
-- Source: ORIGIN.case + 15 lookup tables
-- Reads all case records updated within the daily window.
-- Computes CASE_CAT inline from public assistance data.
-- Note: DB2 sysdate -> CURRENT_DATE(), decode() -> CASE WHEN,
--       LISTAGG() -> CONCAT_WS(', ', COLLECT_LIST()),
--       NVL() -> COALESCE(), date() -> DATE()
-- ----------------------------------------------------------
src_case AS (
    SELECT TMP2.* FROM (
        SELECT TMP.*,
            CASE
                WHEN TMP.DATE_IND_1 = 0 AND TMP.DATE_IND_2 = 0 AND TMP.CRNT_TYPE_CD = 'IVD'
                    THEN 'IVD - Never Assistance'
                WHEN TMP.DATE_IND_1 = 0 AND TMP.DATE_IND_2 = 0 AND TMP.CRNT_TYPE_CD = 'N4D'
                    THEN 'Non IVD - Never Assistance'
                WHEN TMP.DATE_IND_1 = 1 AND TMP.DATE_IND_2 = 0 AND TMP.CRNT_TYPE_CD = 'IVD'
                     AND (TMP.ARRS_AMT = 0 OR TMP.ARRS_AMT IS NULL)
                     AND AID_CD NOT IN (105, 106, 108, 19, 65)
                    THEN 'IVD - Never Assistance'
                WHEN TMP.DATE_IND_1 = 1 AND TMP.DATE_IND_2 = 0 AND TMP.CRNT_TYPE_CD = 'N4D'
                     AND (TMP.ARRS_AMT = 0 OR TMP.ARRS_AMT IS NULL)
                     AND AID_CD NOT IN (105, 106, 108, 19, 65)
                    THEN 'Non IVD - Never Assistance'
                WHEN TMP.DATE_IND_1 = 1 AND TMP.DATE_IND_2 = 0 AND TMP.CRNT_TYPE_CD = 'IVD'
                     AND AID_CD = 105
                    THEN 'Current IVA'
                WHEN TMP.DATE_IND_1 = 0 AND TMP.DATE_IND_2 = 1 AND TMP.CRNT_TYPE_CD = 'IVD'
                     AND AID_CD = 105
                    THEN 'Former IVA'
                WHEN TMP.DATE_IND_1 = 1 AND TMP.DATE_IND_2 = 0 AND TMP.CRNT_TYPE_CD = 'IVD'
                     AND AID_CD = 106
                    THEN 'Medicaid - Never Assistance'
                WHEN TMP.DATE_IND_1 = 1 AND TMP.DATE_IND_2 = 0 AND TMP.CRNT_TYPE_CD = 'IVD'
                     AND AID_CD = 108
                    THEN 'Current IVE'
                WHEN TMP.DATE_IND_1 = 0 AND TMP.DATE_IND_2 = 1 AND TMP.CRNT_TYPE_CD = 'IVD'
                     AND AID_CD = 108
                    THEN 'Former IVE'
                WHEN AID_CD = 19
                    THEN 'OYA IVD'
                WHEN AID_CD = 65
                    THEN 'OYA Non-IVD'
                WHEN TMP.DATE_IND_1 = 0 AND TMP.DATE_IND_2 = 1 AND TMP.ARRS_AMT <> 0
                    THEN 'Arrears Only - Former Never Assistance'
                WHEN TMP.DATE_IND_1 = 0 AND TMP.DATE_IND_2 = 0 AND TMP.ARRS_AMT <> 0
                    THEN 'Arrears Only - Never Assistance'
                WHEN TMP.DATE_IND_1 = 1 AND TMP.DATE_IND_2 = 0 AND TMP.ARRS_AMT <> 0
                     AND AID_CD NOT IN (105, 106, 108, 19, 65)
                    THEN 'Arrears Only - Never Assistance'
                ELSE
                    CASE
                        WHEN TMP.CRNT_TYPE_CD = 'N4D' THEN 'Non IV-D'
                        ELSE NULL
                    END
            END AS CASE_CAT
        FROM (
            SELECT
                CA.case_id,
                mrg_into_case_id,
                pnd_cls_int_user,
                lgcy_stg_user_id,
                crnt_asgn_off_id,
                crnt_asgn_team_id,
                crnt_asgn_case_mgr_id,
                user_init_cls_just_txt,
                non_coop_oth_rsn_txt,
                fed_aid_stat_cd,
                stat_aid_stat_cd,
                case_extid,
                prev_case_extid,
                non_ivd_acct_num_extid,
                case_registr_cd,
                mng_cnty_fips_cd,
                pnd_cls_stat_cd,
                pnd_cls_type_cd,
                pnd_cls_rsn_cd,
                pnd_cls_rsn_cd                          AS PND_CLS_RSN_NIV_CD,
                crnt_stat_cd,
                crnt_type_cd,
                non_ivd_src_doc_type_cd,
                rstrn_ordr_cd,
                case_proc_cd,
                crnt_case_func_cd,
                auto_reasm_rule_cd,
                non_coop_stat_cd,
                non_coop_rsn_cd,
                noncoop_pubasst_cd,
                no_jurisd_ind,
                fam_rcncl_ind,
                arrs_unfrc_ind,
                iva_prnt_togth_ind,
                unscf_levs_ind,
                no_fthr_actn_ind,
                unkwn_fthr_ind,
                cp_intrv_ind,
                folup_ind,
                rtct_supt_ordr_ind,
                loc_only_ind,
                rcp_req_cls_ind,
                inpr_to_estb_ind,
                cont_by_ph_ind,
                no_info_ind,
                oth_st_app_ind,
                cmfr_oth_st_ind,
                arrs_trnsfr_ind,
                no_lngr_rspnd_ind,
                donot_prg_ind,
                pnd_cls_dt,
                noncoop_pubasst_dt,
                prg_dt,
                pnd_cls_start_ts,
                pnd_cls_stat_ts,
                non_coop_stat_ts,
                CA.row_vers_id,
                CA.row_creat_user,
                csh11.eff_ts                            AS row_creat_ts,
                CA.row_update_user,
                CA.row_update_ts,
                mng_cnty_case_extid,
                chld_care_verif_sent_dt,
                case_sub_cd,
                phys_file_loc_txt,
                court_ordr_pnd_oth_src_ind,
                serv_req_cd,
                no_auto_cls_ind,
                intrnat_drct_appl_cntry_cd,
                spec_circums_note_txt,
                cp_auth_represent,
                ncp_auth_represent,
                form_supr_ind,
                dcss_managed_tribl_case_ind,
                is_mrg_ind,
                IP.type_cd                              AS INTRSTE_PRSPCTV_HIST_TYPE_CD,
                ttt.stat_cd                             AS PUB_ASST_STAT_CD,
                GCC.stat_cd                             AS GOOD_CAUSE_CLM_STAT_CD,
                PA.type_cd,
                ttt.aid_cat_cd                          AS AID_CD,
                CAC.arrs_amt,
                CASE
                    WHEN CURRENT_DATE() >= ttt.beg_dt
                         AND (CURRENT_DATE() < ttt.end_dt OR ttt.end_dt IS NULL) THEN 1
                    ELSE 0
                END                                     AS DATE_IND_1,
                CASE
                    WHEN CURRENT_DATE() > ttt.end_dt THEN 1
                    ELSE 0
                END                                     AS DATE_IND_2,
                csh11.eff_ts,
                CASE
                    WHEN crnt_stat_cd = 'OPN' THEN NULL
                    ELSE csh_closed_date.case_close_date
                END                                     AS case_close_date,
                csh_open_date.case_open_date            AS CASE_OPEN_DT,
                DATE(csh111.row_update_ts)              AS CASE_STAT_DT,
                last_pmt.actv_sdu_rcvd_dt               AS LAST_PMT_DT,
                ttt.SRL_NUM_TXT,
                ttt.FAM_BGT_UNIT_TXT,
                CAST(cas.CASE_BALANCE AS DECIMAL(13,2)) AS CASE_BALANCE,
                csh_reopen_date.CASE_REOPEN_DT,
                lc.LGCY_CASE_NBR,
                GCC.STAT_TYPE_CD,
                COALESCE(sr.LTD_SERV_APPL_CNT, 0)      AS LTD_SERV_APPL_CNT,
                IP.OTH_JURISD_FIPS_CD                   AS DETERMN_OTH_JURISD_FIPS_CD,
                DETR1.DETERMN_DT,
                DETR1.ROW_CREAT_USER                    AS DETERMN_ROW_CREAT_USER,
                CAST(CNP1.DEPENDENT_NAMES_NEEDING_PAT_EST AS VARCHAR(200))
                                                        AS DEPENDENT_NAMES_NEEDING_PAT_EST
            FROM ORIGIN.case CA

            -- Public Assistance: current/former aid category and status
            LEFT JOIN (
                SELECT *
                FROM (
                    SELECT
                        cp.case_id,
                        pac.SRL_NUM_TXT,
                        pac.FAM_BGT_UNIT_TXT,
                        pac.STAT_CD,
                        ppa.aid_cat_cd                  AS AID_CAT_CD,
                        ppa.end_dt,
                        ppa.beg_dt,
                        cp.prtcp_id,
                        cp.row_update_ts,
                        ppa.ROW_UPDATE_TS               AS ROW_UPDATE_TS_PPA,
                        pac.ROW_UPDATE_TS               AS ROW_UPDATE_TS_PAC,
                        ROW_NUMBER() OVER (
                            PARTITION BY cp.case_id
                            ORDER BY ppa.beg_dt, ppa.ROW_UPDATE_TS DESC, pac.ROW_UPDATE_TS DESC
                        )                               AS ROW_NUM
                    FROM ORIGIN.PARTICIPANT_PUBLIC_ASSISTANCE_CASE ppa
                    INNER JOIN ORIGIN.PUBLIC_ASSISTANCE_CASE pac
                        ON ppa.PUB_ASST_CASE_ID = pac.PUB_ASST_CASE_ID
                    LEFT  JOIN ORIGIN.PUBLIC_ASSISTANCE_OFFICE pao
                        ON pac.PUB_ASST_OFF_ID = pao.PUB_ASST_OFF_ID
                    INNER JOIN ORIGIN.PARTICIPANT participan2_
                        ON ppa.PRTCP_ID = participan2_.PRTCP_ID
                    INNER JOIN ORIGIN.PARTICIPANT participan3_
                        ON ppa.PRTCP_ID = participan3_.PRTCP_ID
                    INNER JOIN ORIGIN.CASE_PARTICIPANT cp
                        ON participan3_.PRTCP_ID = cp.PRTCP_ID
                    WHERE (
                              (ppa.ROLE_CD IN ('APP','CUS') AND cp.ROLE_CD = 'CUS')
                           OR (ppa.ROLE_CD = 'DEP' AND cp.ROLE_CD = 'DEP')
                          )
                      AND ppa.AID_STAT_CD NOT IN ('ERR')
                      AND participan2_.TYPE_CD = 'IND'
                      AND pac.SRL_NUM_TXT IS NOT NULL
                ) WHERE ROW_NUM = 1
            ) ttt ON ttt.case_id = CA.case_id

            -- Case account balance (active/pending-non-interest transactions)
            LEFT JOIN (
                SELECT
                    CAS_INNER.CASE_ID,
                    CAS_INNER.is_mrg_ind,
                    CAS_INNER.case_acct_sum_id,
                    CAS_INNER.row_update_ts,
                    SUM(CAST_INNER.TRANS_AMT)           AS CASE_BALANCE
                FROM ORIGIN.case_account_summary_transaction CAST_INNER
                INNER JOIN ORIGIN.case_account_summary CAS_INNER
                    ON CAS_INNER.CASE_ACCT_SUM_ID = CAST_INNER.CASE_ACCT_SUM_ID
                WHERE DATE(CAST_INNER.EFF_TRANS_TS) <= '${DAILY_HIGH_DT_TS}'
                  AND CAST_INNER.trans_type_cd NOT IN ('CBU','NSA','REC','ALC','ADJ')
                  AND CAST_INNER.bal_regnr_stat_cd IN ('ACT','PNI')
                GROUP BY CAS_INNER.CASE_ID, CAS_INNER.is_mrg_ind,
                         CAS_INNER.case_acct_sum_id, CAS_INNER.row_update_ts
            ) cas ON CA.case_id = cas.case_id

            -- Arrears balance
            LEFT JOIN (
                SELECT
                    case_acct_sum_id,
                    SUM(taa_int_amt + taa_prnpl_amt + paa_int_amt + paa_prnpl_amt
                        + caa_int_amt + caa_prnpl_amt)  AS ARRS_AMT,
                    MAX(row_update_ts)                  AS row_update_ts
                FROM ORIGIN.case_account
                WHERE row_update_ts <= '${DAILY_HIGH_DT_TS}'
                GROUP BY case_acct_sum_id
            ) CAC ON cas.case_acct_sum_id = CAC.case_acct_sum_id

            -- Interstate perspective (active, most recent)
            LEFT JOIN (
                SELECT *
                FROM (
                    SELECT
                        case_id,
                        intrste_prspctv_id,
                        OTH_JURISD_FIPS_CD,
                        type_cd,
                        row_update_ts,
                        ROW_NUMBER() OVER (
                            PARTITION BY case_id ORDER BY row_update_ts DESC
                        )                               AS ROW_NUM
                    FROM ORIGIN.interstate_perspective
                    WHERE stat_cd = 'ACT'
                      AND row_update_ts <= '${DAILY_HIGH_DT_TS}'
                ) WHERE ROW_NUM = 1
            ) IP ON CA.case_id = IP.case_id

            -- Good cause claim (most recent)
            LEFT JOIN (
                SELECT *
                FROM (
                    SELECT
                        case_id,
                        stat_cd,
                        STAT_TYPE_CD,
                        row_update_ts,
                        ROW_NUMBER() OVER (
                            PARTITION BY case_id ORDER BY row_update_ts DESC
                        )                               AS ROW_NUM
                    FROM ORIGIN.good_cause_claim
                    WHERE row_update_ts <= '${DAILY_HIGH_DT_TS}'
                ) WHERE ROW_NUM = 1
            ) GCC ON CA.case_id = GCC.case_id

            -- Participant (custodial parent type)
            LEFT JOIN (
                SELECT *
                FROM ORIGIN.participant
                WHERE row_update_ts <= '${DAILY_HIGH_DT_TS}'
            ) PA ON ttt.prtcp_id = PA.prtcp_id

            -- Case status history - creation date (first OPN record)
            LEFT JOIN (
                SELECT *
                FROM (
                    SELECT
                        case_id,
                        EFF_TS,
                        STAT_CD,
                        row_update_ts,
                        ROW_NUMBER() OVER (
                            PARTITION BY case_id ORDER BY EFF_TS ASC
                        )                               AS ROW_NUM
                    FROM ORIGIN.case_status_history
                    WHERE row_update_ts <= '${DAILY_HIGH_DT_TS}'
                ) WHERE ROW_NUM = 1
            ) csh11 ON CA.case_id = csh11.case_id

            -- Last payment date (most recent NAP transaction)
            LEFT JOIN (
                SELECT *
                FROM (
                    SELECT
                        CAST_LP.case_acct_sum_id,
                        CAST_LP.LGC_COLL_TRANS_ID,
                        LCT.actv_sdu_rcvd_dt,
                        CAST_LP.row_update_ts,
                        ROW_NUMBER() OVER (
                            PARTITION BY CAST_LP.case_acct_sum_id
                            ORDER BY CAST_LP.row_update_ts DESC
                        )                               AS ROW_NUM
                    FROM ORIGIN.case_account_summary_transaction CAST_LP
                    INNER JOIN ORIGIN.logical_collection_transaction LCT
                        ON CAST_LP.lgc_coll_trans_id = LCT.lgc_coll_trans_id
                    WHERE CAST_LP.row_update_ts <= '${DAILY_HIGH_DT_TS}'
                      AND CAST_LP.LGC_COLL_TRANS_ID IS NOT NULL
                      AND LCT.ADJ_TYPE_CD = 'NAP'
                ) WHERE ROW_NUM = 1
            ) last_pmt ON cas.case_acct_sum_id = last_pmt.case_acct_sum_id

            -- Case close date (most recent CLO record)
            LEFT JOIN (
                SELECT MAX(CASE_CLOSE_DATE) AS case_close_date, case_id
                FROM (
                    SELECT
                        case_id,
                        DATE(EFF_TS)                    AS CASE_CLOSE_DATE,
                        ROW_NUMBER() OVER (
                            PARTITION BY case_id ORDER BY eff_ts DESC
                        )                               AS ROW_NUM
                    FROM ORIGIN.case_status_history
                    WHERE row_update_ts <= '${DAILY_HIGH_DT_TS}'
                      AND stat_cd = 'CLO'
                ) WHERE ROW_NUM = 1
                GROUP BY case_id
            ) csh_closed_date ON CA.case_id = csh_closed_date.case_id

            -- Case open date (most recent OPN record)
            LEFT JOIN (
                SELECT MAX(CASE_OPEN_DATE) AS case_open_date, case_id
                FROM (
                    SELECT
                        case_id,
                        DATE(EFF_TS)                    AS CASE_OPEN_DATE,
                        ROW_NUMBER() OVER (
                            PARTITION BY case_id ORDER BY eff_ts DESC
                        )                               AS ROW_NUM
                    FROM ORIGIN.case_status_history
                    WHERE row_update_ts <= '${DAILY_HIGH_DT_TS}'
                      AND stat_cd = 'OPN'
                ) WHERE ROW_NUM = 1
                GROUP BY case_id
            ) csh_open_date ON CA.case_id = csh_open_date.case_id

            -- Case status date (most recent status record)
            LEFT JOIN (
                SELECT *
                FROM (
                    SELECT
                        case_id,
                        EFF_TS,
                        STAT_CD,
                        row_update_ts,
                        ROW_NUMBER() OVER (
                            PARTITION BY case_id ORDER BY row_update_ts DESC
                        )                               AS ROW_NUM
                    FROM ORIGIN.case_status_history
                    WHERE row_update_ts <= '${DAILY_HIGH_DT_TS}'
                ) WHERE ROW_NUM = 1
            ) csh111 ON CA.case_id = csh111.case_id

            -- Case reopen date
            LEFT JOIN (
                SELECT DISTINCT case_id, CASE_REOPEN_DT
                FROM (
                    SELECT
                        csh.case_id,
                        CAST(csh.eff_ts AS DATE)         AS CASE_REOPEN_DT,
                        ROW_NUMBER() OVER (
                            PARTITION BY case_id ORDER BY csh.row_update_ts DESC
                        )                               AS ROW_NUM
                    FROM ORIGIN.case_status_history csh
                    WHERE csh.stat_cd = 'OPN'
                      AND EXISTS (
                          SELECT case_id
                          FROM (
                              SELECT *
                              FROM (
                                  SELECT
                                      csh2.eff_ts,
                                      csh2.case_id,
                                      ROW_NUMBER() OVER (
                                          PARTITION BY case_id
                                          ORDER BY csh2.EFF_TS DESC
                                      )               AS ROW_NUM
                                  FROM ORIGIN.case_status_history csh2
                                  WHERE stat_cd IN ('CLO','OBS')
                              ) WHERE ROW_NUM = 1
                          ) CSH3
                          WHERE csh3.eff_ts < csh.eff_ts
                            AND csh3.case_id = csh.case_id
                      )
                ) WHERE ROW_NUM = 1
            ) csh_reopen_date ON CA.case_id = csh_reopen_date.case_id

            -- Legacy case number
            LEFT JOIN (
                SELECT CASE_ID, LGCY_CASE_NBR
                FROM ORIGIN.LEGACY_CASE
            ) lc ON lc.case_id = CA.case_id

            -- Limited services request count (N4D)
            LEFT JOIN (
                SELECT
                    case_id,
                    COUNT(SERV_REQ_ID)                  AS LTD_SERV_APPL_CNT,
                    MAX(ROW_UPDATE_TS)                  AS ROW_UPDATE_TS
                FROM ORIGIN.SERVICE_REQUEST
                WHERE REFL_TYPE = 'N4D'
                  AND SERV_REQ_CD = 'N4D'
                  AND (REF_AGCY_CD IS NULL OR REF_AGCY_CD = '')
                GROUP BY case_id
            ) sr ON sr.case_id = CA.case_id

            -- Interstate determination (most recent ACT)
            LEFT JOIN (
                SELECT *
                FROM (
                    SELECT
                        case_id,
                        OTH_JURISD_FIPS_CD,
                        DETERMN_DT,
                        ROW_CREAT_USER,
                        row_update_ts,
                        ROW_NUMBER() OVER (
                            PARTITION BY case_id ORDER BY row_update_ts DESC
                        )                               AS ROW_NUM
                    FROM ORIGIN.INTERSTATE_DETERMINATION
                    WHERE STAT_CD = 'ACT'
                      AND row_update_ts <= '${DAILY_HIGH_DT_TS}'
                ) WHERE ROW_NUM = 1
            ) DETR1 ON CA.case_id = DETR1.case_id

            -- Dependents needing paternity established (CR448)
            LEFT JOIN (
                SELECT DISTINCT u.case_id,
                    CAST(LEFT(u.DEPENDENT_NAMES_NEEDING_PAT_EST, 200) AS VARCHAR(200))
                                                        AS DEPENDENT_NAMES_NEEDING_PAT_EST,
                    u.row_update_ts
                FROM (
                    SELECT DISTINCT c.case_id,
                        CAST(LEFT(
                            CONCAT_WS(', ',
                                COLLECT_LIST(
                                    CONCAT(TRIM(prn.first_nm), ' ', TRIM(prn.last_nm))
                                )
                            ), 200
                        ) AS VARCHAR(200))              AS DEPENDENT_NAMES_NEEDING_PAT_EST,
                        MAX(prs.row_update_ts)          AS row_update_ts
                    FROM ORIGIN.case c
                    INNER JOIN ORIGIN.CASE_PARTICIPANT ccp
                        ON ccp.case_id = c.case_id
                       AND ccp.role_cd = 'DEP'
                       AND c.crnt_stat_cd = 'OPN'
                       AND ccp.stat_cd = 'ACT'
                       AND ccp.depnt_type_cd IS NULL
                    INNER JOIN ORIGIN.participant_relationship prs
                        ON prs.prtcp_id = ccp.prtcp_id
                       AND prs.relshp_cd IN ('CHI','PCH')
                       AND prs.STAT_CD = 'VAL'
                    INNER JOIN ORIGIN.PARTICIPANT_PHYSICAL_ATTRIBUTES ppa2
                        ON ppa2.prtcp_id = ccp.prtcp_id
                       AND ppa2.DCSD_IND <> 1
                    INNER JOIN ORIGIN.participant_relationship prsFather
                        ON prsFather.prtcp_id = prs.reld_to_prtcp_id
                       AND prsFather.relshp_cd IN ('FAT','PUF')
                       AND prsFather.STAT_CD = 'VAL'
                    INNER JOIN ORIGIN.case_participant cpFather
                        ON cpFather.prtcp_id = prsFather.prtcp_id
                       AND cpFather.case_id = c.case_id
                       AND cpFather.role_cd = 'NCP'
                    INNER JOIN ORIGIN.participant_name prn
                        ON prn.prtcp_id = ccp.prtcp_id
                       AND prn.stat_cd = 'PRI'
                    WHERE prs.PRNTG_STAT_CD IN ('COF','EXC','NES')
                    GROUP BY c.case_id
                ) u
            ) CNP1 ON CA.case_id = CNP1.case_id

            WHERE (
                (CA.row_update_ts        >= '${DAILY_LOW_DT_TS}' AND CA.row_update_ts        <= '${DAILY_HIGH_DT_TS}')
             OR (ttt.ROW_UPDATE_TS_PPA   >= '${DAILY_LOW_DT_TS}' AND ttt.ROW_UPDATE_TS_PPA   <= '${DAILY_HIGH_DT_TS}')
             OR (ttt.ROW_UPDATE_TS_PAC   >= '${DAILY_LOW_DT_TS}' AND ttt.ROW_UPDATE_TS_PAC   <= '${DAILY_HIGH_DT_TS}')
             OR (cas.row_update_ts       >= '${DAILY_LOW_DT_TS}' AND cas.row_update_ts        <= '${DAILY_HIGH_DT_TS}')
             OR (CAC.row_update_ts       >= '${DAILY_LOW_DT_TS}' AND CAC.row_update_ts        <= '${DAILY_HIGH_DT_TS}')
             OR (IP.row_update_ts        >= '${DAILY_LOW_DT_TS}' AND IP.row_update_ts         <= '${DAILY_HIGH_DT_TS}')
             OR (GCC.row_update_ts       >= '${DAILY_LOW_DT_TS}' AND GCC.row_update_ts        <= '${DAILY_HIGH_DT_TS}')
             OR (last_pmt.row_update_ts  >= '${DAILY_LOW_DT_TS}' AND last_pmt.row_update_ts   <= '${DAILY_HIGH_DT_TS}')
             OR (sr.ROW_UPDATE_TS        >= '${DAILY_LOW_DT_TS}' AND sr.ROW_UPDATE_TS         <= '${DAILY_HIGH_DT_TS}')
             OR (DETR1.row_update_ts     >= '${DAILY_LOW_DT_TS}' AND DETR1.row_update_ts      <= '${DAILY_HIGH_DT_TS}')
             OR (CNP1.row_update_ts      >= '${DAILY_LOW_DT_TS}' AND CNP1.row_update_ts       <= '${DAILY_HIGH_DT_TS}')
            )
        ) TMP
    ) TMP2
),

-- ----------------------------------------------------------
-- CTE: src_code (DataStage stage: DB2_CODE, DB2ConnectorPX)
-- Short decode lookup (code, decode, cat_name)
-- Used by LKP_CODES for most code category lookups
-- ----------------------------------------------------------
src_code AS (
    SELECT DISTINCT
        C.code,
        C.decode,
        UPPER(CC.cat_name)                              AS cat_name,
        1                                               AS CODE_DUMMY
    FROM ORIGIN.code C
    LEFT  JOIN (
        SELECT code_id, code_cat_id
        FROM ORIGIN.code_cat_assign
        WHERE row_update_ts <= '${DAILY_HIGH_DT_TS}'
    ) CCA ON C.code_id = CCA.code_id
    INNER JOIN (
        SELECT code_cat_id, UPPER(cat_name) AS cat_name
        FROM ORIGIN.code_cat
        WHERE row_update_ts <= '${DAILY_HIGH_DT_TS}'
    ) CC ON CCA.code_cat_id = CC.code_cat_id
    WHERE C.row_del_ind = 0
      AND C.end_date = '9999-12-31'
      AND C.row_update_ts <= '${DAILY_HIGH_DT_TS}'
),

-- ----------------------------------------------------------
-- CTE: src_code_long (Copy_of_DB2_CODE, DB2ConnectorPX)
-- Long decode lookup (adds long_decode column)
-- Used by LKP_CODES for reason codes needing long descriptions
-- ----------------------------------------------------------
src_code_long AS (
    SELECT DISTINCT
        C.code,
        C.decode,
        C.long_decode,
        UPPER(CC.cat_name)                              AS cat_name,
        1                                               AS CODE_DUMMY
    FROM ORIGIN.code C
    LEFT  JOIN (
        SELECT code_id, code_cat_id
        FROM ORIGIN.code_cat_assign
        WHERE row_update_ts <= '${DAILY_HIGH_DT_TS}'
    ) CCA ON C.code_id = CCA.code_id
    INNER JOIN (
        SELECT code_cat_id, UPPER(cat_name) AS cat_name
        FROM ORIGIN.code_cat
        WHERE row_update_ts <= '${DAILY_HIGH_DT_TS}'
    ) CC ON CCA.code_cat_id = CC.code_cat_id
    WHERE C.row_del_ind = 0
      AND C.end_date = '9999-12-31'
      AND C.row_update_ts <= '${DAILY_HIGH_DT_TS}'
),

-- ----------------------------------------------------------
-- CTE: src_code_short2 (Copy_2_of_DB2_CODE, DB2ConnectorPX)
-- Additional code table read (short decode, used for specific lookups)
-- ----------------------------------------------------------
src_code_short2 AS (
    SELECT DISTINCT
        C.code,
        C.decode,
        UPPER(CC.cat_name)                              AS cat_name,
        1                                               AS CODE_DUMMY
    FROM ORIGIN.code C
    LEFT  JOIN (
        SELECT code_id, code_cat_id
        FROM ORIGIN.code_cat_assign
        WHERE row_update_ts <= '${DAILY_HIGH_DT_TS}'
    ) CCA ON C.code_id = CCA.code_id
    INNER JOIN (
        SELECT code_cat_id, UPPER(cat_name) AS cat_name
        FROM ORIGIN.code_cat
        WHERE row_update_ts <= '${DAILY_HIGH_DT_TS}'
    ) CC ON CCA.code_cat_id = CC.code_cat_id
    WHERE C.row_del_ind = 0
      AND C.end_date = '9999-12-31'
      AND C.row_update_ts <= '${DAILY_HIGH_DT_TS}'
),

-- ----------------------------------------------------------
-- CTE: src_data_relab (DB2_DATA_RELAB_TASK_DUE, DB2ConnectorPX)
-- Indicator: case has a Data Reliability/Accountability task due
-- ----------------------------------------------------------
src_data_relab AS (
    SELECT DISTINCT
        case_id,
        1                                               AS DATA_RELAB_TASK_DUE
    FROM ORIGIN.task T
    WHERE task_cat = 'DAR'
      AND orig_due_dt < CURRENT_DATE()
      AND case_id IS NOT NULL
      AND T.row_update_ts <= '${DAILY_HIGH_DT_TS}'
),

-- ----------------------------------------------------------
-- CTE: src_out_compliance (DB2_OUT_OF_COMPLIANCE, DB2ConnectorPX)
-- Indicator: case has an out-of-compliance task due
-- ----------------------------------------------------------
src_out_compliance AS (
    SELECT DISTINCT
        T.case_id,
        1                                               AS OUT_OF_COMPLI_TASK
    FROM ORIGIN.task T
    LEFT JOIN ORIGIN.task_type TT
        ON T.task_type_id = TT.task_type_id
    WHERE TT.task_type_cd = 'COMP'
      AND T.due_dt < CURRENT_DATE()
      AND T.compli_dt < CURRENT_DATE()
      AND T.case_id IS NOT NULL
      AND T.row_update_ts <= '${DAILY_HIGH_DT_TS}'
      AND TT.row_update_ts <= '${DAILY_HIGH_DT_TS}'
),

-- ----------------------------------------------------------
-- CTE: src_court_case (DB2_COURT_CASE, DB2ConnectorPX)
-- Court case delinquency timestamp per case
-- ----------------------------------------------------------
src_court_case AS (
    SELECT DISTINCT
        CA2.case_id,
        CC2.delqnt_ts
    FROM ORIGIN.case CA2
    LEFT JOIN ORIGIN.case_court_case CCC
        ON CA2.case_id = CCC.case_id
    LEFT JOIN ORIGIN.court_case CC2
        ON CCC.court_case_id = CC2.court_case_id
    WHERE CA2.row_update_ts <= '${DAILY_HIGH_DT_TS}'
      AND CC2.delqnt_ts IS NOT NULL
),

-- ----------------------------------------------------------
-- CTE: src_dim_cat (DB2_DIM_CAT, DB2ConnectorPX)
-- Complex aggregation to derive Case_Category for each case
-- Based on public assistance aid codes and interstate perspective
-- ----------------------------------------------------------
src_dim_cat AS (
    SELECT
        case_id,
        case_extid,
        case_stat_dt,
        CASE
            WHEN CURR_IVA  > 0 AND NVR > 0 THEN 'Current IV-A'
            WHEN CURR_IVE  > 0 AND NVR > 0 THEN 'Current IV-E'
            WHEN CURR_XIX  > 0 AND NVR > 0 THEN 'Title XIX - Never Assistance'
            WHEN FOR_IVA   > 0 AND NVR > 0 THEN 'Former IV-A'
            WHEN FOR_IVE   > 0 AND NVR > 0 THEN 'Former IV-E'
            WHEN FOR_XIX   > 0 AND NVR > 0 THEN 'Title XIX - Never Assistance'
            WHEN OYA_19    > 0 AND NVR > 0 THEN 'Oregon Youth Authority'
            WHEN OYA_65    > 0 AND crnt_type_cd = 'N4D' THEN 'Oregon Youth Authority'
            WHEN ASS_ARRS  > 0 AND NVR > 0 THEN 'Arrears Only - Never Assistance'
            WHEN NVR       > 0             THEN 'Never Assistance'
            ELSE ''
        END                                             AS Case_Category
    FROM (
        SELECT
            ca_dc.case_id,
            ca_dc.case_extid,
            ca_dc.crnt_type_cd,
            csh_dc.case_stat_dt,
            SUM(CASE WHEN (pacm.AID_CD IN ('02') AND (pacm.end_dt IS NULL OR pacm.end_dt >= CURRENT_DATE()) AND p_dc.type_cd NOT IN ('FFC')) OR (ip_dc.oth_jrsd_case_type_cd = 'IVA') THEN 1 ELSE 0 END) AS CURR_IVA,
            SUM(CASE WHEN (pacm.AID_CD IN ('02') AND pacm.end_dt < CURRENT_DATE() AND p_dc.type_cd NOT IN ('FFC')) OR (ip_dc.oth_jrsd_case_type_cd = 'FAS') THEN 1 ELSE 0 END) AS FOR_IVA,
            SUM(CASE WHEN (pacm.AID_CD IN ('P2') AND (pacm.end_dt IS NULL OR pacm.end_dt >= CURRENT_DATE())) OR (ip_dc.oth_jrsd_case_type_cd = 'XIX') THEN 1 ELSE 0 END) AS CURR_XIX,
            SUM(CASE WHEN (pacm.AID_CD IN ('P2') AND pacm.end_dt < CURRENT_DATE()) OR (ip_dc.oth_jrsd_case_type_cd = 'XIX') THEN 1 ELSE 0 END) AS FOR_XIX,
            SUM(CASE WHEN (pacm.AID_CD IN ('19') AND p_dc.type_cd = 'OYA' AND (pacm.end_dt IS NULL OR pacm.end_dt >= CURRENT_DATE())) OR (ip_dc.oth_jrsd_case_type_cd = 'IVA') THEN 1 ELSE 0 END) AS OYA_19,
            SUM(CASE WHEN (pacm.AID_CD IN ('65') AND p_dc.type_cd = 'OYA' AND (pacm.end_dt IS NULL OR pacm.end_dt >= CURRENT_DATE())) OR (ip_dc.oth_jrsd_case_type_cd = 'IVA') THEN 1 ELSE 0 END) AS OYA_65,
            SUM(CASE WHEN (pacm.AID_CD IN ('IVE','N4E') AND p_dc.type_cd = 'FFC' AND (pacm.end_dt IS NULL OR pacm.end_dt >= CURRENT_DATE())) OR (ip_dc.oth_jrsd_case_type_cd IN ('FOC','FFC')) THEN 1 ELSE 0 END) AS CURR_IVE,
            SUM(CASE WHEN (pacm.AID_CD IN ('IVE','N4E') AND p_dc.type_cd = 'FFC' AND pacm.end_dt < CURRENT_DATE()) OR (ip_dc.oth_jrsd_case_type_cd IN ('FCA')) THEN 1 ELSE 0 END) AS FOR_IVE,
            SUM(CASE WHEN (ca_dc.crnt_type_cd = 'IVD') OR (ip_dc.oth_jrsd_case_type_cd IN ('NAS','N4A')) THEN 1 ELSE 0 END) AS NVR,
            SUM(COALESCE(caa_dc.CAA_PRNPL_AMT,0) + COALESCE(caa_dc.CAA_INT_AMT,0) + COALESCE(caa_dc.TAA_PRNPL_AMT,0) + COALESCE(caa_dc.TAA_INT_AMT,0) + COALESCE(caa_dc.PAA_PRNPL_AMT,0) + COALESCE(caa_dc.PAA_INT_AMT,0)) AS ASS_ARRS,
            SUM(COALESCE(caa_dc.NAA_PRNPL_AMT,0) + COALESCE(caa_dc.NAA_INT_AMT,0) + COALESCE(caa_dc.UDA_PRNPL_AMT,0) + COALESCE(caa_dc.UDA_INT_AMT,0) + COALESCE(caa_dc.UPA_PRNPL_AMT,0) + COALESCE(caa_dc.UPA_INT_AMT,0)) AS NVR_ARRS
        FROM ORIGIN.case ca_dc
        LEFT JOIN (
            SELECT case_id, DATE(MAX(row_update_ts)) AS case_stat_dt
            FROM ORIGIN.case_status_history GROUP BY case_id
        ) csh_dc ON ca_dc.case_id = csh_dc.case_id
        LEFT JOIN ORIGIN.case_participant cp_dc
            ON ca_dc.case_id = cp_dc.case_id AND cp_dc.role_cd = 'DEP'
        LEFT JOIN ORIGIN.participant_public_assistance_case pacm
            ON cp_dc.prtcp_id = pacm.prtcp_id AND pacm.role_cd = 'DEP' AND pacm.aid_stat_cd = 'ACT'
        LEFT JOIN ORIGIN.case_participant cus_dc
            ON ca_dc.case_id = cus_dc.case_id AND cus_dc.role_cd = 'CUS' AND cus_dc.stat_cd = 'ACT'
        LEFT JOIN ORIGIN.participant p_dc ON cus_dc.prtcp_id = p_dc.prtcp_id
        LEFT JOIN (
            SELECT
                case_id,
                CASE
                    WHEN stat_cd = 'ACT' THEN oth_jrsd_case_type_cd
                    WHEN stat_cd = 'INA' AND oth_jurisd_cls_dt IS NOT NULL
                         AND (oth_jurisd_cls_dt >= pnd_cls_dt OR oth_jurisd_cls_dt >= case_stat_dt2)
                        THEN oth_jrsd_case_type_cd
                    ELSE ''
                END                                     AS oth_jrsd_case_type_cd
            FROM (
                SELECT
                    ca_ip.case_id,
                    ca_ip.pnd_cls_dt,
                    ip_inner.stat_cd,
                    ip_inner.oth_jurisd_cls_dt,
                    ip_inner.oth_jrsd_case_stat_cd,
                    ip_inner.oth_jrsd_case_type_cd,
                    csh_ip.case_stat_dt2,
                    ROW_NUMBER() OVER (
                        PARTITION BY ca_ip.case_id
                        ORDER BY ip_inner.stat_cd ASC, ip_inner.row_update_ts DESC
                    )                                   AS row_num
                FROM ORIGIN.interstate_perspective ip_inner
                INNER JOIN ORIGIN.case ca_ip ON ca_ip.case_id = ip_inner.case_id
                INNER JOIN (
                    SELECT case_id, DATE(MAX(row_update_ts)) AS case_stat_dt2
                    FROM ORIGIN.case_status_history GROUP BY case_id
                ) csh_ip ON ca_ip.case_id = csh_ip.case_id
                WHERE ip_inner.type_cd = 'RES'
            ) WHERE row_num = 1
        ) ip_dc ON ca_dc.case_id = ip_dc.case_id
        LEFT JOIN ORIGIN.case_account_summary cas_dc ON ca_dc.case_id = cas_dc.case_id
        LEFT JOIN ORIGIN.case_account caa_dc
            ON cas_dc.case_acct_sum_id = caa_dc.case_acct_sum_id
           AND caa_dc.BAL_REGNR_STAT_CD IN ('ACT','PNI')
        GROUP BY ca_dc.case_id, ca_dc.case_extid, ca_dc.crnt_type_cd, csh_dc.case_stat_dt
    )
),

-- ----------------------------------------------------------
-- CTE: dim_case_current (DB2_DIM_CASE_LKP, DB2ConnectorPX)
-- Current active DIM_CASE records for SCD2 comparison lookup
-- ----------------------------------------------------------
dim_case_current AS (
    SELECT
        DC.*,
        1                                               AS DUMMY
    FROM ODW.DIM_CASE DC
    WHERE DC.CURRENT_RECORD_INDICATOR = 'Y'
      AND DC.DIM_CASE_KEY NOT IN (-1, -2)
),

-- ============================================================
-- SECTION 3: LOOKUP JOINS (LKP_CODES, Lookup_99)
-- CP_CASE_ASSISTANCE fan-out -> multiple code lookups via LEFT JOIN
-- Each lookup corresponds to a code category in ORIGIN.code table.
-- CODE_DUMMY flag: 0 = code not found -> use 'CODE NOT FOUND'
-- ============================================================

-- ----------------------------------------------------------
-- CTE: enriched_src
-- Applies all lookup joins to src_case:
--   - Code lookups (LKP_CODES, 11 outputs): FED_AID_STAT_NM, STAT_AID_STAT_NM,
--     MNG_CNTY_FIPS_NM, PND_CLS_STAT_NM, PND_CLS_TYPE_NM, PND_CLS_RSN_NM,
--     CASE_REGISTR_NM, CRNT_STAT_NM, CRNT_TYPE_NM, NON_IVD_SRC_DOC_TYPE_NM,
--     RSTRN_ORDR_NM, CASE_PROC_NM, CRNT_CASE_FUNC_NM, AUTO_REASM_RULE_NM,
--     NON_COOP_STAT_NM, NON_COOP_RSN_NM, NONCOOP_PUBASST_NM, SERV_REQ_NM,
--     INTRNAT_DRCT_APPL_CNTRY_NM, INTRSTE_PRSPCTV_HIST_TYPE_CD_NM,
--     GOOD_CAUSE_CLM_STAT_CD_NM, CASE_SUB_NM, PUB_ASST_STAT_NM
--   - Task/compliance/court lookups
--   - DIM_CAT override for CASE_CAT
-- ----------------------------------------------------------
enriched_src AS (
    SELECT
        src.*,
        -- XFRM_INS_UPD Transformer: code lookup decode with CODE_DUMMY check
        -- Pattern: IF code IS NULL THEN NULL ELSIF CODE_DUMMY=0 THEN 'CODE NOT FOUND' ELSE decode END
        CASE WHEN src.fed_aid_stat_cd IS NULL THEN NULL
             WHEN COALESCE(lkp_fed_aid.CODE_DUMMY, 0) = 0 THEN 'CODE NOT FOUND'
             ELSE lkp_fed_aid.decode
        END                                             AS FED_AID_STAT_NM,
        CASE WHEN src.stat_aid_stat_cd IS NULL THEN NULL
             WHEN COALESCE(lkp_stat_aid.CODE_DUMMY, 0) = 0 THEN 'CODE NOT FOUND'
             ELSE lkp_stat_aid.decode
        END                                             AS STAT_AID_STAT_NM,
        CASE WHEN src.mng_cnty_fips_cd IS NULL THEN NULL
             WHEN COALESCE(lkp_cnty_fips.CODE_DUMMY, 0) = 0 THEN 'CODE NOT FOUND'
             ELSE lkp_cnty_fips.decode
        END                                             AS MNG_CNTY_FIPS_NM,
        CASE WHEN src.pnd_cls_stat_cd IS NULL THEN NULL
             WHEN COALESCE(lkp_pnd_cls_stat.CODE_DUMMY, 0) = 0 THEN 'CODE NOT FOUND'
             ELSE lkp_pnd_cls_stat.decode
        END                                             AS PND_CLS_STAT_NM,
        CASE WHEN src.pnd_cls_type_cd IS NULL THEN NULL
             WHEN COALESCE(lkp_pnd_cls_type.CODE_DUMMY, 0) = 0 THEN 'CODE NOT FOUND'
             ELSE lkp_pnd_cls_type.decode
        END                                             AS PND_CLS_TYPE_NM,
        CASE WHEN src.pnd_cls_rsn_cd IS NULL THEN NULL
             WHEN COALESCE(lkp_pnd_cls_rsn.CODE_DUMMY, 0) = 0 THEN NULL
             ELSE lkp_pnd_cls_rsn.long_decode
        END                                             AS PND_CLS_RSN_NM,
        CASE WHEN src.PUB_ASST_STAT_CD IS NULL THEN NULL
             WHEN COALESCE(lkp_pub_asst.CODE_DUMMY, 0) = 0 THEN 'CODE NOT FOUND'
             ELSE lkp_pub_asst.decode
        END                                             AS PUB_ASST_STAT_NM,
        -- CASE_REGISTR_NM: DataStage transformer derivation (no code lookup)
        -- IF NULL(CASE_REGISTR_CD) THEN NULL ELSE CASE_REGISTR_CD
        CASE WHEN src.case_registr_cd IS NULL THEN NULL
             ELSE src.case_registr_cd
        END                                             AS CASE_REGISTR_NM,
        CASE WHEN src.crnt_stat_cd IS NULL THEN NULL
             WHEN COALESCE(lkp_crnt_stat.CODE_DUMMY, 0) = 0 THEN 'CODE NOT FOUND'
             ELSE lkp_crnt_stat.decode
        END                                             AS CRNT_STAT_NM,
        CASE WHEN src.crnt_type_cd IS NULL THEN NULL
             WHEN COALESCE(lkp_crnt_type.CODE_DUMMY, 0) = 0 THEN 'CODE NOT FOUND'
             ELSE lkp_crnt_type.decode
        END                                             AS CRNT_TYPE_NM,
        CASE WHEN src.non_ivd_src_doc_type_cd IS NULL THEN NULL
             WHEN COALESCE(lkp_non_ivd_doc.CODE_DUMMY, 0) = 0 THEN 'CODE NOT FOUND'
             ELSE lkp_non_ivd_doc.decode
        END                                             AS NON_IVD_SRC_DOC_TYPE_NM,
        -- RSTRN_ORDR_NM: DataStage transformer derivation (no code lookup)
        -- IF NULL(RSTRN_ORDR_CD) THEN NULL ELSE IF RSTRN_ORDR_CD = 'NAP' THEN 'N/A' ELSE RSTRN_ORDR_CD
        CASE WHEN src.rstrn_ordr_cd IS NULL THEN NULL
             WHEN src.rstrn_ordr_cd = 'NAP'            THEN 'N/A'
             ELSE src.rstrn_ordr_cd
        END                                             AS RSTRN_ORDR_NM,
        CASE WHEN src.case_proc_cd IS NULL THEN NULL
             WHEN COALESCE(lkp_case_proc.CODE_DUMMY, 0) = 0 THEN 'CODE NOT FOUND'
             ELSE lkp_case_proc.decode
        END                                             AS CASE_PROC_NM,
        CASE WHEN src.crnt_case_func_cd IS NULL THEN NULL
             WHEN COALESCE(lkp_case_func.CODE_DUMMY, 0) = 0 THEN 'CODE NOT FOUND'
             ELSE lkp_case_func.decode
        END                                             AS CRNT_CASE_FUNC_NM,
        CASE WHEN src.auto_reasm_rule_cd IS NULL THEN NULL
             WHEN COALESCE(lkp_auto_reasm.CODE_DUMMY, 0) = 0 THEN 'CODE NOT FOUND'
             ELSE lkp_auto_reasm.decode
        END                                             AS AUTO_REASM_RULE_NM,
        CASE WHEN src.non_coop_stat_cd IS NULL THEN NULL
             WHEN COALESCE(lkp_non_coop_stat.CODE_DUMMY, 0) = 0 THEN 'CODE NOT FOUND'
             ELSE lkp_non_coop_stat.decode
        END                                             AS NON_COOP_STAT_NM,
        CASE WHEN src.non_coop_rsn_cd IS NULL THEN NULL
             WHEN COALESCE(lkp_non_coop_rsn.CODE_DUMMY, 0) = 0 THEN 'CODE NOT FOUND'
             ELSE lkp_non_coop_rsn.decode
        END                                             AS NON_COOP_RSN_NM,
        CASE WHEN src.noncoop_pubasst_cd IS NULL THEN NULL
             WHEN COALESCE(lkp_noncoop_pubasst.CODE_DUMMY, 0) = 0 THEN 'CODE NOT FOUND'
             ELSE lkp_noncoop_pubasst.decode
        END                                             AS NONCOOP_PUBASST_NM,
        CASE WHEN src.serv_req_cd IS NULL THEN NULL
             WHEN COALESCE(lkp_serv_req.CODE_DUMMY, 0) = 0 THEN 'CODE NOT FOUND'
             ELSE lkp_serv_req.decode
        END                                             AS SERV_REQ_NM,
        CASE WHEN src.intrnat_drct_appl_cntry_cd IS NULL THEN NULL
             WHEN COALESCE(lkp_cntry.CODE_DUMMY, 0) = 0 THEN 'CODE NOT FOUND'
             ELSE lkp_cntry.decode
        END                                             AS INTRNAT_DRCT_APPL_CNTRY_NM,
        CASE WHEN src.INTRSTE_PRSPCTV_HIST_TYPE_CD IS NULL THEN NULL
             WHEN COALESCE(lkp_intrste.CODE_DUMMY, 0) = 0 THEN 'CODE NOT FOUND'
             ELSE lkp_intrste.decode
        END                                             AS INTRSTE_PRSPCTV_HIST_TYPE_CD_NM,
        CASE WHEN src.GOOD_CAUSE_CLM_STAT_CD IS NULL THEN NULL
             WHEN COALESCE(lkp_good_cause.CODE_DUMMY, 0) = 0 THEN 'CODE NOT FOUND'
             ELSE lkp_good_cause.decode
        END                                             AS GOOD_CAUSE_CLM_STAT_CD_NM,
        CASE WHEN src.case_sub_cd IS NULL THEN NULL
             WHEN COALESCE(lkp_case_sub.CODE_DUMMY, 0) = 0 THEN 'CODE NOT FOUND'
             ELSE lkp_case_sub.decode
        END                                             AS CASE_SUB_NM,
        -- Task/compliance lookups
        COALESCE(dt.DATA_RELAB_TASK_DUE, 0)            AS DATA_RELAB_TASK_DUE,
        COALESCE(oc.OUT_OF_COMPLI_TASK, 0)             AS OUT_OF_COMPLI_TASK,
        cc.delqnt_ts                                    AS DELQNT_TS,
        -- DIM_CAT category override (Lookup_99 pattern via DB2_DIM_CAT)
        COALESCE(dc_cat.Case_Category, src.CASE_CAT)   AS CASE_CAT_FINAL
    FROM src_case src

    -- LKP_CODES lookups (each is a LEFT JOIN on code + cat_name filter)
    -- LNK_DISPLAYCASEASSISTANCESTATUS (FED_AID_STAT)
    LEFT JOIN src_code lkp_fed_aid
        ON src.fed_aid_stat_cd = lkp_fed_aid.code
       AND lkp_fed_aid.cat_name = 'DISPLAYCASEASSISTANCESTATUS'
    -- STATE_AID_STATUS
    LEFT JOIN src_code lkp_stat_aid
        ON src.stat_aid_stat_cd = lkp_stat_aid.code
       AND lkp_stat_aid.cat_name = 'DISPLAYCASEASSISTANCESTATUS'
    -- MNG_CNTY_FIPS (LNK_GLOBALCALIFORNIACOUNTYFIPS -> GLOBALOREGONCOUNTYFIPS)
    LEFT JOIN src_code lkp_cnty_fips
        ON src.mng_cnty_fips_cd = lkp_cnty_fips.code
       AND lkp_cnty_fips.cat_name = 'GLOBALOREGONCOUNTYFIPS'
    -- PND_CLS_STAT (LNK_DISPLAYCASEPENDINGCLOSURESTATUSCODE)
    LEFT JOIN src_code lkp_pnd_cls_stat
        ON src.pnd_cls_stat_cd = lkp_pnd_cls_stat.code
       AND lkp_pnd_cls_stat.cat_name = 'DISPLAYCASEPENDINGCLOSURESTATUSCODE'
    -- PND_CLS_TYPE (LNK_DISPLAYCASEPENDINGCLOSURETYPECODE)
    LEFT JOIN src_code lkp_pnd_cls_type
        ON src.pnd_cls_type_cd = lkp_pnd_cls_type.code
       AND lkp_pnd_cls_type.cat_name = 'DISPLAYCASEPENDINGCLOSURETYPECODE'
    -- PND_CLS_RSN (LNK_DISPLAYCASECLOSUREREASONCODE, long_decode)
    LEFT JOIN src_code_long lkp_pnd_cls_rsn
        ON src.pnd_cls_rsn_cd = lkp_pnd_cls_rsn.code
       AND lkp_pnd_cls_rsn.cat_name = 'DISPLAYCASECLOSUREREASONCODE'
    -- PUB_ASST_STAT
    LEFT JOIN src_code lkp_pub_asst
        ON src.PUB_ASST_STAT_CD = lkp_pub_asst.code
       AND lkp_pub_asst.cat_name = 'DISPLAYCASEASSISTANCESTATUS'
    -- CASE_REGISTR_NM: no code lookup (transformer passthrough — see derivation above)
    -- CRNT_STAT (LNK_CASE_STAT -> DISPLAYCASESTATUS)
    LEFT JOIN src_code lkp_crnt_stat
        ON src.crnt_stat_cd = lkp_crnt_stat.code
       AND lkp_crnt_stat.cat_name = 'DISPLAYCASESTATUS'
    -- CRNT_TYPE (LNK_DISPLAYIVDSERVICESREQUESTED)
    LEFT JOIN src_code lkp_crnt_type
        ON src.crnt_type_cd = lkp_crnt_type.code
       AND lkp_crnt_type.cat_name = 'DISPLAYIVDSERVICESREQUESTED'
    -- NON_IVD_SRC_DOC_TYPE (LNK_DISPLAYCASENONIVDSOURCEDOCUMENTTYPE)
    LEFT JOIN src_code lkp_non_ivd_doc
        ON src.non_ivd_src_doc_type_cd = lkp_non_ivd_doc.code
       AND lkp_non_ivd_doc.cat_name = 'DISPLAYCASENONIVDSOURCEDOCUMENTTYPE'
    -- RSTRN_ORDR_NM: no code lookup (transformer conditional — see derivation above)
    -- CASE_PROC (LNK_DISPLAYCASEPROCESS)
    LEFT JOIN src_code lkp_case_proc
        ON src.case_proc_cd = lkp_case_proc.code
       AND lkp_case_proc.cat_name = 'DISPLAYCASEPROCESS'
    -- CRNT_CASE_FUNC (LNK_CASE_FUNC -> DISPLAYCASEFUNCTION)
    LEFT JOIN src_code lkp_case_func
        ON src.crnt_case_func_cd = lkp_case_func.code
       AND lkp_case_func.cat_name = 'DISPLAYCASEFUNCTION'
    -- AUTO_REASM_RULE (LNK_DISPLAYCASEAUTOMATICREASSIGNMENTRULECODE)
    LEFT JOIN src_code lkp_auto_reasm
        ON src.auto_reasm_rule_cd = lkp_auto_reasm.code
       AND lkp_auto_reasm.cat_name = 'DISPLAYCASEAUTOMATICREASSIGNMENTRULECODE'
    -- NON_COOP_STAT (LNK_DISPLAYCASENONCOOPERATIONSTATUSCODE)
    LEFT JOIN src_code_short2 lkp_non_coop_stat
        ON src.non_coop_stat_cd = lkp_non_coop_stat.code
       AND lkp_non_coop_stat.cat_name = 'DISPLAYCASENONCOOPERATIONSTATUSCODE'
    -- NON_COOP_RSN (LNK_DISPLAYCASENONCOOPERATIONREASONCODE)
    LEFT JOIN src_code_short2 lkp_non_coop_rsn
        ON src.non_coop_rsn_cd = lkp_non_coop_rsn.code
       AND lkp_non_coop_rsn.cat_name = 'DISPLAYCASENONCOOPERATIONREASONCODE'
    -- NONCOOP_PUBASST (LNK_CORPORATION_2 -> DISPLAYCASENONCOOPERATIONPUBLICASSISTANCESTATUSCODE)
    LEFT JOIN src_code lkp_noncoop_pubasst
        ON src.noncoop_pubasst_cd = lkp_noncoop_pubasst.code
       AND (lkp_noncoop_pubasst.cat_name = 'DISPLAYCASENONCOOPERATIONPUBLICASSISTANCESTATUSCODE'
         OR lkp_noncoop_pubasst.cat_name = 'DISPLAYCASEIVANONCOOPERATIONREASON')
    -- SERV_REQ
    LEFT JOIN src_code lkp_serv_req
        ON src.serv_req_cd = lkp_serv_req.code
       AND lkp_serv_req.cat_name = 'DISPLAYIVDSERVICESREQUESTED'
    -- INTRNAT_DRCT_APPL_CNTRY (LNK_GLOBALCOUNTRYISO)
    LEFT JOIN src_code lkp_cntry
        ON src.intrnat_drct_appl_cntry_cd = lkp_cntry.code
       AND lkp_cntry.cat_name = 'GLOBALCOUNTRYISO'
    -- INTRSTE_PRSPCTV_HIST_TYPE (LNK_TYPE_CD -> DISPLAYINTERSTATEPERSPECTIVETYPE)
    LEFT JOIN src_code lkp_intrste
        ON src.INTRSTE_PRSPCTV_HIST_TYPE_CD = lkp_intrste.code
       AND lkp_intrste.cat_name = 'DISPLAYINTERSTATEPERSPECTIVETYPE'
    -- GOOD_CAUSE_CLM_STAT (LNK_GOOD_CAUSE -> DISPLAYGOODCAUSESTATUS)
    LEFT JOIN src_code lkp_good_cause
        ON src.GOOD_CAUSE_CLM_STAT_CD = lkp_good_cause.code
       AND lkp_good_cause.cat_name = 'DISPLAYGOODCAUSESTATUS'
    -- CASE_SUB (LNK_DISPLAYCASESUBTYPE)
    LEFT JOIN src_code lkp_case_sub
        ON src.case_sub_cd = lkp_case_sub.code
       AND lkp_case_sub.cat_name = 'DISPLAYCASESUBTYPE'

    -- Task/compliance/court lookups (DB2_DATA_RELAB_TASK_DUE, DB2_OUT_OF_COMPLIANCE, DB2_COURT_CASE)
    LEFT JOIN src_data_relab dt ON src.case_id = dt.case_id
    LEFT JOIN src_out_compliance oc ON src.case_id = oc.case_id
    LEFT JOIN src_court_case cc ON src.case_id = cc.case_id

    -- Category lookup (DB2_DIM_CAT -> Lookup_99 -> overrides CASE_CAT from src_case)
    LEFT JOIN src_dim_cat dc_cat ON src.case_id = dc_cat.case_id
),

-- ============================================================
-- SECTION 4: CHECKSUM COMPUTATION
-- Checksum_163: source fingerprint (excludes audit/SCD2 columns)
-- Checksum_168: target fingerprint (excludes SCD2 + dim key columns)
-- ============================================================

-- ----------------------------------------------------------
-- CTE: src_with_checksum (Checksum_163, PxChecksum)
-- Computes MD5 over all source columns EXCEPT dropcol list:
-- Excludes: ROW_CREAT_USER, ROW_CREAT_TS, ROW_UPDATE_USER,
--   ROW_UPDATE_TS, EFFECTIVE_START_TS, EFFECTIVE_END_TS,
--   UPDATED_BY, BTCH_RUN_ID, CURRENT_RECORD_INDICATOR, ROW_VERS_ID,
--   LATEST_NFR_INIT_DT_KEY, LATEST_NFR_FINL_DT_KEY
-- ----------------------------------------------------------
src_with_checksum AS (
    SELECT
        e.*,
        MD5(CONCAT_WS('||',
            COALESCE(CAST(e.case_id                         AS STRING), ''),
            COALESCE(CAST(e.mrg_into_case_id                AS STRING), ''),
            COALESCE(CAST(e.pnd_cls_int_user                AS STRING), ''),
            COALESCE(CAST(e.lgcy_stg_user_id                AS STRING), ''),
            COALESCE(CAST(e.crnt_asgn_off_id                AS STRING), ''),
            COALESCE(CAST(e.crnt_asgn_team_id               AS STRING), ''),
            COALESCE(CAST(e.crnt_asgn_case_mgr_id           AS STRING), ''),
            COALESCE(CAST(e.user_init_cls_just_txt          AS STRING), ''),
            COALESCE(CAST(e.non_coop_oth_rsn_txt            AS STRING), ''),
            COALESCE(CAST(e.fed_aid_stat_cd                 AS STRING), ''),
            COALESCE(CAST(e.FED_AID_STAT_NM                 AS STRING), ''),
            COALESCE(CAST(e.stat_aid_stat_cd                AS STRING), ''),
            COALESCE(CAST(e.STAT_AID_STAT_NM                AS STRING), ''),
            COALESCE(CAST(e.case_extid                      AS STRING), ''),
            COALESCE(CAST(e.prev_case_extid                 AS STRING), ''),
            COALESCE(CAST(e.non_ivd_acct_num_extid          AS STRING), ''),
            COALESCE(CAST(e.case_registr_cd                 AS STRING), ''),
            COALESCE(CAST(e.mng_cnty_fips_cd                AS STRING), ''),
            COALESCE(CAST(e.MNG_CNTY_FIPS_NM               AS STRING), ''),
            COALESCE(CAST(e.pnd_cls_stat_cd                 AS STRING), ''),
            COALESCE(CAST(e.PND_CLS_STAT_NM                 AS STRING), ''),
            COALESCE(CAST(e.pnd_cls_type_cd                 AS STRING), ''),
            COALESCE(CAST(e.PND_CLS_TYPE_NM                 AS STRING), ''),
            COALESCE(CAST(e.pnd_cls_rsn_cd                  AS STRING), ''),
            COALESCE(CAST(e.PND_CLS_RSN_NM                  AS STRING), ''),
            COALESCE(CAST(e.PUB_ASST_STAT_NM                AS STRING), ''),
            COALESCE(CAST(e.CASE_REGISTR_NM                 AS STRING), ''),
            COALESCE(CAST(e.crnt_stat_cd                    AS STRING), ''),
            COALESCE(CAST(e.CRNT_STAT_NM                    AS STRING), ''),
            COALESCE(CAST(e.crnt_type_cd                    AS STRING), ''),
            COALESCE(CAST(e.CRNT_TYPE_NM                    AS STRING), ''),
            COALESCE(CAST(e.non_ivd_src_doc_type_cd         AS STRING), ''),
            COALESCE(CAST(e.NON_IVD_SRC_DOC_TYPE_NM        AS STRING), ''),
            COALESCE(CAST(e.RSTRN_ORDR_NM                   AS STRING), ''),
            COALESCE(CAST(e.rstrn_ordr_cd                   AS STRING), ''),
            COALESCE(CAST(e.case_proc_cd                    AS STRING), ''),
            COALESCE(CAST(e.CASE_PROC_NM                    AS STRING), ''),
            COALESCE(CAST(e.crnt_case_func_cd               AS STRING), ''),
            COALESCE(CAST(e.CRNT_CASE_FUNC_NM               AS STRING), ''),
            COALESCE(CAST(e.auto_reasm_rule_cd              AS STRING), ''),
            COALESCE(CAST(e.AUTO_REASM_RULE_NM              AS STRING), ''),
            COALESCE(CAST(e.non_coop_stat_cd                AS STRING), ''),
            COALESCE(CAST(e.NON_COOP_STAT_NM                AS STRING), ''),
            COALESCE(CAST(e.non_coop_rsn_cd                 AS STRING), ''),
            COALESCE(CAST(e.NON_COOP_RSN_NM                 AS STRING), ''),
            COALESCE(CAST(e.noncoop_pubasst_cd              AS STRING), ''),
            COALESCE(CAST(e.NONCOOP_PUBASST_NM              AS STRING), ''),
            COALESCE(CAST(e.no_jurisd_ind                   AS STRING), ''),
            COALESCE(CAST(e.fam_rcncl_ind                   AS STRING), ''),
            COALESCE(CAST(e.arrs_unfrc_ind                  AS STRING), ''),
            COALESCE(CAST(e.iva_prnt_togth_ind              AS STRING), ''),
            COALESCE(CAST(e.unscf_levs_ind                  AS STRING), ''),
            COALESCE(CAST(e.no_fthr_actn_ind                AS STRING), ''),
            COALESCE(CAST(e.unkwn_fthr_ind                  AS STRING), ''),
            COALESCE(CAST(e.cp_intrv_ind                    AS STRING), ''),
            COALESCE(CAST(e.folup_ind                       AS STRING), ''),
            COALESCE(CAST(e.rtct_supt_ordr_ind              AS STRING), ''),
            COALESCE(CAST(e.loc_only_ind                    AS STRING), ''),
            COALESCE(CAST(e.rcp_req_cls_ind                 AS STRING), ''),
            COALESCE(CAST(e.inpr_to_estb_ind                AS STRING), ''),
            COALESCE(CAST(e.cont_by_ph_ind                  AS STRING), ''),
            COALESCE(CAST(e.no_info_ind                     AS STRING), ''),
            COALESCE(CAST(e.oth_st_app_ind                  AS STRING), ''),
            COALESCE(CAST(e.cmfr_oth_st_ind                 AS STRING), ''),
            COALESCE(CAST(e.arrs_trnsfr_ind                 AS STRING), ''),
            COALESCE(CAST(e.no_lngr_rspnd_ind               AS STRING), ''),
            COALESCE(CAST(e.donot_prg_ind                   AS STRING), ''),
            COALESCE(CAST(e.pnd_cls_dt                      AS STRING), ''),
            COALESCE(CAST(e.noncoop_pubasst_dt              AS STRING), ''),
            COALESCE(CAST(e.prg_dt                          AS STRING), ''),
            COALESCE(CAST(e.pnd_cls_start_ts                AS STRING), ''),
            COALESCE(CAST(e.pnd_cls_stat_ts                 AS STRING), ''),
            COALESCE(CAST(e.non_coop_stat_ts                AS STRING), ''),
            COALESCE(CAST(e.mng_cnty_case_extid             AS STRING), ''),
            COALESCE(CAST(e.chld_care_verif_sent_dt         AS STRING), ''),
            COALESCE(CAST(e.case_sub_cd                     AS STRING), ''),
            COALESCE(CAST(e.CASE_SUB_NM                     AS STRING), ''),
            COALESCE(CAST(e.phys_file_loc_txt               AS STRING), ''),
            COALESCE(CAST(e.court_ordr_pnd_oth_src_ind      AS STRING), ''),
            COALESCE(CAST(e.serv_req_cd                     AS STRING), ''),
            COALESCE(CAST(e.SERV_REQ_NM                     AS STRING), ''),
            COALESCE(CAST(e.no_auto_cls_ind                 AS STRING), ''),
            COALESCE(CAST(e.intrnat_drct_appl_cntry_cd      AS STRING), ''),
            COALESCE(CAST(e.INTRNAT_DRCT_APPL_CNTRY_NM     AS STRING), ''),
            COALESCE(CAST(e.spec_circums_note_txt           AS STRING), ''),
            COALESCE(CAST(e.cp_auth_represent               AS STRING), ''),
            COALESCE(CAST(e.ncp_auth_represent              AS STRING), ''),
            COALESCE(CAST(e.form_supr_ind                   AS STRING), ''),
            COALESCE(CAST(e.dcss_managed_tribl_case_ind     AS STRING), ''),
            COALESCE(CAST(e.is_mrg_ind                      AS STRING), ''),
            COALESCE(CAST(e.INTRSTE_PRSPCTV_HIST_TYPE_CD   AS STRING), ''),
            COALESCE(CAST(e.INTRSTE_PRSPCTV_HIST_TYPE_CD_NM AS STRING), ''),
            COALESCE(CAST(e.PUB_ASST_STAT_CD               AS STRING), ''),
            COALESCE(CAST(e.case_close_date                 AS STRING), ''),
            COALESCE(CAST(e.CASE_OPEN_DT                    AS STRING), ''),
            COALESCE(CAST(e.GOOD_CAUSE_CLM_STAT_CD         AS STRING), ''),
            COALESCE(CAST(e.GOOD_CAUSE_CLM_STAT_CD_NM      AS STRING), ''),
            COALESCE(CAST(e.CASE_CAT_FINAL                  AS STRING), ''),
            COALESCE(CAST(e.CASE_STAT_DT                    AS STRING), ''),
            COALESCE(CAST(e.LAST_PMT_DT                     AS STRING), ''),
            COALESCE(CAST(e.DELQNT_TS                       AS STRING), ''),
            COALESCE(CAST(e.OUT_OF_COMPLI_TASK              AS STRING), ''),
            COALESCE(CAST(e.DATA_RELAB_TASK_DUE             AS STRING), ''),
            COALESCE(CAST(e.SRL_NUM_TXT                     AS STRING), ''),
            COALESCE(CAST(e.FAM_BGT_UNIT_TXT                AS STRING), ''),
            COALESCE(CAST(e.CASE_BALANCE                    AS STRING), ''),
            COALESCE(CAST(e.CASE_REOPEN_DT                  AS STRING), ''),
            COALESCE(CAST(e.STAT_TYPE_CD                    AS STRING), ''),
            COALESCE(CAST(e.LGCY_CASE_NBR                   AS STRING), ''),
            COALESCE(CAST(e.LTD_SERV_APPL_CNT              AS STRING), ''),
            COALESCE(CAST(e.DETERMN_OTH_JURISD_FIPS_CD     AS STRING), ''),
            COALESCE(CAST(e.DETERMN_DT                      AS STRING), ''),
            COALESCE(CAST(e.DETERMN_ROW_CREAT_USER         AS STRING), ''),
            COALESCE(CAST(e.DEPENDENT_NAMES_NEEDING_PAT_EST AS STRING), '')
        ))                                              AS CHECKSUM_FROM_SRC
    FROM enriched_src e
),

-- ----------------------------------------------------------
-- CTE: tgt_with_checksum (Checksum_168, PxChecksum)
-- Target checksum: MD5 over dim_case_current columns
-- Excludes: DIM_CASE_KEY, DUMMY, EFFECTIVE_START_TS, EFFECTIVE_END_TS,
--   CURRENT_RECORD_INDICATOR, UPDATED_BY, BTCH_RUN_ID, ROW_VERS_ID,
--   ROW_CREAT_USER, ROW_CREAT_TS, ROW_UPDATE_USER, ROW_UPDATE_TS,
--   OFFICE_REASM_ROW_UPDATE_TS, TEAM_REASM_ROW_UPDATE_TS,
--   WORKER_REASM_ROW_UPDATE_TS
-- ----------------------------------------------------------
tgt_with_checksum AS (
    SELECT
        t.*,
        MD5(CONCAT_WS('||',
            COALESCE(CAST(t.CASE_ID                         AS STRING), ''),
            COALESCE(CAST(t.MRG_INTO_CASE_ID               AS STRING), ''),
            COALESCE(CAST(t.PND_CLS_INT_USER               AS STRING), ''),
            COALESCE(CAST(t.LGCY_STG_USER_ID               AS STRING), ''),
            COALESCE(CAST(t.CRNT_ASGN_OFF_ID               AS STRING), ''),
            COALESCE(CAST(t.CRNT_ASGN_TEAM_ID              AS STRING), ''),
            COALESCE(CAST(t.CRNT_ASGN_CASE_MGR_ID          AS STRING), ''),
            COALESCE(CAST(t.USER_INIT_CLS_JUST_TXT         AS STRING), ''),
            COALESCE(CAST(t.NON_COOP_OTH_RSN_TXT           AS STRING), ''),
            COALESCE(CAST(t.FED_AID_STAT_CD                AS STRING), ''),
            COALESCE(CAST(t.FED_AID_STAT_NM                AS STRING), ''),
            COALESCE(CAST(t.STAT_AID_STAT_CD               AS STRING), ''),
            COALESCE(CAST(t.STAT_AID_STAT_NM               AS STRING), ''),
            COALESCE(CAST(t.CASE_EXTID                     AS STRING), ''),
            COALESCE(CAST(t.PREV_CASE_EXTID                AS STRING), ''),
            COALESCE(CAST(t.NON_IVD_ACCT_NUM_EXTID        AS STRING), ''),
            COALESCE(CAST(t.CASE_REGISTR_CD               AS STRING), ''),
            COALESCE(CAST(t.MNG_CNTY_FIPS_CD              AS STRING), ''),
            COALESCE(CAST(t.MNG_CNTY_FIPS_NM              AS STRING), ''),
            COALESCE(CAST(t.PND_CLS_STAT_CD               AS STRING), ''),
            COALESCE(CAST(t.PND_CLS_STAT_NM               AS STRING), ''),
            COALESCE(CAST(t.PND_CLS_TYPE_CD               AS STRING), ''),
            COALESCE(CAST(t.PND_CLS_TYPE_NM               AS STRING), ''),
            COALESCE(CAST(t.PND_CLS_RSN_CD                AS STRING), ''),
            COALESCE(CAST(t.PND_CLS_RSN_NM                AS STRING), ''),
            COALESCE(CAST(t.PUB_ASST_STAT_NM              AS STRING), ''),
            COALESCE(CAST(t.CASE_REGISTR_NM               AS STRING), ''),
            COALESCE(CAST(t.CRNT_STAT_CD                  AS STRING), ''),
            COALESCE(CAST(t.CRNT_STAT_NM                  AS STRING), ''),
            COALESCE(CAST(t.CRNT_TYPE_CD                  AS STRING), ''),
            COALESCE(CAST(t.CRNT_TYPE_NM                  AS STRING), ''),
            COALESCE(CAST(t.NON_IVD_SRC_DOC_TYPE_CD      AS STRING), ''),
            COALESCE(CAST(t.NON_IVD_SRC_DOC_TYPE_NM      AS STRING), ''),
            COALESCE(CAST(t.RSTRN_ORDR_NM                 AS STRING), ''),
            COALESCE(CAST(t.RSTRN_ORDR_CD                 AS STRING), ''),
            COALESCE(CAST(t.CASE_PROC_CD                  AS STRING), ''),
            COALESCE(CAST(t.CASE_PROC_NM                  AS STRING), ''),
            COALESCE(CAST(t.CRNT_CASE_FUNC_CD             AS STRING), ''),
            COALESCE(CAST(t.CRNT_CASE_FUNC_NM             AS STRING), ''),
            COALESCE(CAST(t.AUTO_REASM_RULE_CD            AS STRING), ''),
            COALESCE(CAST(t.AUTO_REASM_RULE_NM            AS STRING), ''),
            COALESCE(CAST(t.NON_COOP_STAT_CD              AS STRING), ''),
            COALESCE(CAST(t.NON_COOP_STAT_NM              AS STRING), ''),
            COALESCE(CAST(t.NON_COOP_RSN_CD               AS STRING), ''),
            COALESCE(CAST(t.NON_COOP_RSN_NM               AS STRING), ''),
            COALESCE(CAST(t.NONCOOP_PUBASST_CD            AS STRING), ''),
            COALESCE(CAST(t.NONCOOP_PUBASST_NM            AS STRING), ''),
            COALESCE(CAST(t.NO_JURISD_IND                 AS STRING), ''),
            COALESCE(CAST(t.FAM_RCNCL_IND                 AS STRING), ''),
            COALESCE(CAST(t.ARRS_UNFRC_IND                AS STRING), ''),
            COALESCE(CAST(t.IVA_PRNT_TOGTH_IND            AS STRING), ''),
            COALESCE(CAST(t.UNSCF_LEVS_IND                AS STRING), ''),
            COALESCE(CAST(t.NO_FTHR_ACTN_IND              AS STRING), ''),
            COALESCE(CAST(t.UNKWN_FTHR_IND                AS STRING), ''),
            COALESCE(CAST(t.CP_INTRV_IND                  AS STRING), ''),
            COALESCE(CAST(t.FOLUP_IND                     AS STRING), ''),
            COALESCE(CAST(t.RTCT_SUPT_ORDR_IND            AS STRING), ''),
            COALESCE(CAST(t.LOC_ONLY_IND                  AS STRING), ''),
            COALESCE(CAST(t.RCP_REQ_CLS_IND               AS STRING), ''),
            COALESCE(CAST(t.INPR_TO_ESTB_IND              AS STRING), ''),
            COALESCE(CAST(t.CONT_BY_PH_IND                AS STRING), ''),
            COALESCE(CAST(t.NO_INFO_IND                   AS STRING), ''),
            COALESCE(CAST(t.OTH_ST_APP_IND                AS STRING), ''),
            COALESCE(CAST(t.CMFR_OTH_ST_IND               AS STRING), ''),
            COALESCE(CAST(t.ARRS_TRNSFR_IND               AS STRING), ''),
            COALESCE(CAST(t.NO_LNGR_RSPND_IND             AS STRING), ''),
            COALESCE(CAST(t.DONOT_PRG_IND                 AS STRING), ''),
            COALESCE(CAST(t.PND_CLS_DT                    AS STRING), ''),
            COALESCE(CAST(t.NONCOOP_PUBASST_DT            AS STRING), ''),
            COALESCE(CAST(t.PRG_DT                        AS STRING), ''),
            COALESCE(CAST(t.PND_CLS_START_TS              AS STRING), ''),
            COALESCE(CAST(t.PND_CLS_STAT_TS               AS STRING), ''),
            COALESCE(CAST(t.NON_COOP_STAT_TS              AS STRING), ''),
            COALESCE(CAST(t.MNG_CNTY_CASE_EXTID           AS STRING), ''),
            COALESCE(CAST(t.CHLD_CARE_VERIF_SENT_DT       AS STRING), ''),
            COALESCE(CAST(t.CASE_SUB_CD                   AS STRING), ''),
            COALESCE(CAST(t.CASE_SUB_NM                   AS STRING), ''),
            COALESCE(CAST(t.PHYS_FILE_LOC_TXT             AS STRING), ''),
            COALESCE(CAST(t.COURT_ORDR_PND_OTH_SRC_IND   AS STRING), ''),
            COALESCE(CAST(t.SERV_REQ_CD                   AS STRING), ''),
            COALESCE(CAST(t.SERV_REQ_NM                   AS STRING), ''),
            COALESCE(CAST(t.NO_AUTO_CLS_IND               AS STRING), ''),
            COALESCE(CAST(t.INTRNAT_DRCT_APPL_CNTRY_CD   AS STRING), ''),
            COALESCE(CAST(t.INTRNAT_DRCT_APPL_CNTRY_NM   AS STRING), ''),
            COALESCE(CAST(t.SPEC_CIRCUMS_NOTE_TXT         AS STRING), ''),
            COALESCE(CAST(t.CP_AUTH_REPRESENT             AS STRING), ''),
            COALESCE(CAST(t.NCP_AUTH_REPRESENT            AS STRING), ''),
            COALESCE(CAST(t.FORM_SUPR_IND                 AS STRING), ''),
            COALESCE(CAST(t.DCSS_MANAGED_TRIBL_CASE_IND  AS STRING), ''),
            COALESCE(CAST(t.IS_MRG_IND                   AS STRING), ''),
            COALESCE(CAST(t.INTRSTE_PRSPCTV_HIST_TYPE_CD AS STRING), ''),
            COALESCE(CAST(t.INTRSTE_PRSPCTV_HIST_TYPE_CD_NM AS STRING), ''),
            COALESCE(CAST(t.PUB_ASST_STAT_CD             AS STRING), ''),
            COALESCE(CAST(t.CASE_CLS_DT                  AS STRING), ''),
            COALESCE(CAST(t.CASE_OPEN_DT                 AS STRING), ''),
            COALESCE(CAST(t.GOOD_CAUSE_CLM_STAT_CD       AS STRING), ''),
            COALESCE(CAST(t.GOOD_CAUSE_CLM_STAT_CD_NM    AS STRING), ''),
            COALESCE(CAST(t.CASE_CAT                     AS STRING), ''),
            COALESCE(CAST(t.CASE_STAT_DT                 AS STRING), ''),
            COALESCE(CAST(t.LAST_PMT_DT                  AS STRING), ''),
            COALESCE(CAST(t.DELQNT_TS                    AS STRING), ''),
            COALESCE(CAST(t.OUT_OF_COMPLI_TASK           AS STRING), ''),
            COALESCE(CAST(t.DATA_RELAB_TASK_DUE          AS STRING), ''),
            COALESCE(CAST(t.SRL_NUM_TXT                  AS STRING), ''),
            COALESCE(CAST(t.FAM_BGT_UNIT_TXT             AS STRING), ''),
            COALESCE(CAST(t.CASE_BALANCE                 AS STRING), ''),
            COALESCE(CAST(t.CASE_REOPEN_DT               AS STRING), ''),
            COALESCE(CAST(t.STAT_TYPE_CD                 AS STRING), ''),
            COALESCE(CAST(t.LGCY_CASE_NBR                AS STRING), ''),
            COALESCE(CAST(t.LTD_SERV_APPL_CNT           AS STRING), ''),
            COALESCE(CAST(t.DETERMN_OTH_JURISD_FIPS_CD  AS STRING), ''),
            COALESCE(CAST(t.DETERMN_DT                   AS STRING), ''),
            COALESCE(CAST(t.DETERMN_ROW_CREAT_USER       AS STRING), ''),
            COALESCE(CAST(t.DEPENDENT_NAMES_NEEDING_PAT_EST AS STRING), '')
        ))                                              AS CHECKSUM_FROM_TGT
    FROM dim_case_current t
),

-- ============================================================
-- SECTION 5: JOIN SOURCE + TARGET (JN_CASEID, PxJoin)
-- LEFT OUTER JOIN enriched source with current DIM_CASE records
-- Join key: CASE_ID
-- DIM_CASE_KEY NULL -> new record (INSERT only)
-- DIM_CASE_KEY NOT NULL -> existing record (compare checksums)
-- ============================================================
joined_data AS (
    SELECT
        src.*,
        tgt.DIM_CASE_KEY,
        tgt.DUMMY,
        tgt.CHECKSUM_FROM_TGT,
        tgt.CRNT_STAT_CD                                AS TGT_CRNT_STAT_CD,
        tgt.CRNT_TYPE_CD                                AS TGT_CRNT_TYPE_CD,
        tgt.CRNT_ASGN_OFF_ID                            AS TGT_CRNT_ASGN_OFF_ID,
        tgt.CRNT_ASGN_TEAM_ID                           AS TGT_CRNT_ASGN_TEAM_ID,
        tgt.CRNT_ASGN_CASE_MGR_ID                       AS TGT_CRNT_ASGN_CASE_MGR_ID
    FROM src_with_checksum src
    LEFT JOIN tgt_with_checksum tgt
        ON src.case_id = tgt.CASE_ID
),

-- ============================================================
-- SECTION 6: SCD2 ROUTING (Transformer_174, CTransformerStage)
-- Routes records to:
--   xfrm_upd: existing records with changed checksum (close old row -> UPD job)
--   xfrm_ins: new records OR changed records (insert new version)
-- ============================================================

-- ----------------------------------------------------------
-- CTE: xfrm_upd
-- Rows to be written to DS_DIM_CASE_UPD dataset (UPDATE job input)
-- Condition: DUMMY=1 AND CHECKSUM_FROM_SRC != CHECKSUM_FROM_TGT
-- Columns: DIM_CASE_KEY, EFFECTIVE_END_TS, CURRENT_RECORD_INDICATOR,
--          UPDATED_BY, BTCH_RUN_ID
-- ----------------------------------------------------------
xfrm_upd AS (
    SELECT
        DIM_CASE_KEY,
        CURRENT_TIMESTAMP()                             AS EFFECTIVE_END_TS,
        'N'                                             AS CURRENT_RECORD_INDICATOR,
        -- DataStage derivation: DSHostName (server hostname).
        -- Spark SQL has no hostname function; CURRENT_USER() is the closest equivalent.
        CURRENT_USER()                                  AS UPDATED_BY,
        CAST('${JP_BTCH_RUN_ID}' AS BIGINT)            AS BTCH_RUN_ID
    FROM joined_data
    WHERE DUMMY = 1
      AND CHECKSUM_FROM_SRC IS DISTINCT FROM CHECKSUM_FROM_TGT
),

-- ----------------------------------------------------------
-- CTE: xfrm_ins (Transformer_174 INSERT path + Transformer_171)
-- INSERT new version: new records (no DIM_CASE_KEY) or changed records
-- Condition: DUMMY IS NULL OR (DUMMY=1 AND checksum changed)
-- Adds: NET_CASE_TYPE_IND, OFFICE_REASM_ROW_UPDATE_TS,
--       TEAM_REASM_ROW_UPDATE_TS, WORKER_REASM_ROW_UPDATE_TS
-- Transformer_161: pass-through from LNK_DB2_DIM_CASE_INS to DSLink164
-- ----------------------------------------------------------
xfrm_ins AS (
    SELECT
        jd.*,
        -- NET_CASE_TYPE_IND: 'Y' if case type changed between IVD and non-IVD
        CASE
            WHEN jd.TGT_CRNT_TYPE_CD IS NULL              THEN 'N'
            WHEN jd.TGT_CRNT_TYPE_CD = 'IVD'
                 AND jd.crnt_type_cd <> 'IVD'             THEN 'Y'
            WHEN jd.TGT_CRNT_TYPE_CD <> 'IVD'
                 AND jd.crnt_type_cd = 'IVD'              THEN 'Y'
            ELSE 'N'
        END                                             AS NET_CASE_TYPE_IND,
        -- Office reassignment timestamp (null if office unchanged)
        CASE
            WHEN jd.TGT_CRNT_ASGN_OFF_ID = jd.crnt_asgn_off_id THEN NULL
            ELSE jd.row_update_ts
        END                                             AS OFFICE_REASM_ROW_UPDATE_TS,
        -- Team reassignment timestamp
        CASE
            WHEN jd.TGT_CRNT_ASGN_TEAM_ID = jd.crnt_asgn_team_id THEN NULL
            ELSE jd.row_update_ts
        END                                             AS TEAM_REASM_ROW_UPDATE_TS,
        -- Worker/case manager reassignment timestamp
        CASE
            WHEN jd.TGT_CRNT_ASGN_CASE_MGR_ID = jd.crnt_asgn_case_mgr_id THEN NULL
            ELSE jd.row_update_ts
        END                                             AS WORKER_REASM_ROW_UPDATE_TS,
        -- CASE_REOPENED_IND: 'Y' if case has a reopen date, 'N' otherwise
        -- DataStage Transformer_174: IF null(CASE_REOPEN_DT) THEN 'N' ELSE 'Y'
        CASE WHEN jd.CASE_REOPEN_DT IS NULL THEN 'N' ELSE 'Y'
        END                                             AS CASE_REOPENED_IND
    FROM joined_data jd
    WHERE
        -- New record (not yet in DIM_CASE)
        jd.DIM_CASE_KEY IS NULL
        -- OR changed record (insert new version alongside the close of old)
     OR (jd.DUMMY = 1 AND jd.CHECKSUM_FROM_SRC IS DISTINCT FROM jd.CHECKSUM_FROM_TGT)
)

-- ============================================================
-- SECTION 7: FINAL INSERT (DB2_DIM_CASE, DB2ConnectorPX WriteMode=0)
-- Insert new DIM_CASE rows with SCD Type 2 metadata.
-- All ~114 source columns + SCD2 control columns.
-- Copy_181 fan-out: also feeds Data_Set_182 (handled separately).
-- Transformer_161 (pass-through) -> DSLink164 -> Checksum_163 (already computed).
-- ============================================================
INSERT INTO ODW.DIM_CASE (
    CASE_ID,
    MRG_INTO_CASE_ID,
    PND_CLS_INT_USER,
    LGCY_STG_USER_ID,
    CRNT_ASGN_OFF_ID,
    CRNT_ASGN_TEAM_ID,
    CRNT_ASGN_CASE_MGR_ID,
    USER_INIT_CLS_JUST_TXT,
    NON_COOP_OTH_RSN_TXT,
    FED_AID_STAT_CD,
    FED_AID_STAT_NM,
    STAT_AID_STAT_CD,
    STAT_AID_STAT_NM,
    CASE_EXTID,
    PREV_CASE_EXTID,
    NON_IVD_ACCT_NUM_EXTID,
    CASE_REGISTR_CD,
    MNG_CNTY_FIPS_CD,
    MNG_CNTY_FIPS_NM,
    PND_CLS_STAT_CD,
    PND_CLS_STAT_NM,
    PND_CLS_TYPE_CD,
    PND_CLS_TYPE_NM,
    PND_CLS_RSN_CD,
    PND_CLS_RSN_NM,
    PUB_ASST_STAT_NM,
    CASE_REGISTR_NM,
    CRNT_STAT_CD,
    CRNT_STAT_NM,
    CRNT_TYPE_CD,
    CRNT_TYPE_NM,
    NON_IVD_SRC_DOC_TYPE_CD,
    NON_IVD_SRC_DOC_TYPE_NM,
    RSTRN_ORDR_NM,
    RSTRN_ORDR_CD,
    CASE_PROC_CD,
    CASE_PROC_NM,
    CRNT_CASE_FUNC_CD,
    CRNT_CASE_FUNC_NM,
    AUTO_REASM_RULE_CD,
    AUTO_REASM_RULE_NM,
    NON_COOP_STAT_CD,
    NON_COOP_STAT_NM,
    NON_COOP_RSN_CD,
    NON_COOP_RSN_NM,
    NONCOOP_PUBASST_CD,
    NONCOOP_PUBASST_NM,
    NO_JURISD_IND,
    FAM_RCNCL_IND,
    ARRS_UNFRC_IND,
    IVA_PRNT_TOGTH_IND,
    UNSCF_LEVS_IND,
    NO_FTHR_ACTN_IND,
    UNKWN_FTHR_IND,
    CP_INTRV_IND,
    FOLUP_IND,
    RTCT_SUPT_ORDR_IND,
    LOC_ONLY_IND,
    RCP_REQ_CLS_IND,
    INPR_TO_ESTB_IND,
    CONT_BY_PH_IND,
    NO_INFO_IND,
    OTH_ST_APP_IND,
    CMFR_OTH_ST_IND,
    ARRS_TRNSFR_IND,
    NO_LNGR_RSPND_IND,
    DONOT_PRG_IND,
    PND_CLS_DT,
    NONCOOP_PUBASST_DT,
    PRG_DT,
    PND_CLS_START_TS,
    PND_CLS_STAT_TS,
    NON_COOP_STAT_TS,
    ROW_VERS_ID,
    ROW_CREAT_USER,
    ROW_CREAT_TS,
    ROW_UPDATE_USER,
    ROW_UPDATE_TS,
    MNG_CNTY_CASE_EXTID,
    CHLD_CARE_VERIF_SENT_DT,
    CASE_SUB_CD,
    CASE_SUB_NM,
    PHYS_FILE_LOC_TXT,
    COURT_ORDR_PND_OTH_SRC_IND,
    SERV_REQ_CD,
    SERV_REQ_NM,
    NO_AUTO_CLS_IND,
    INTRNAT_DRCT_APPL_CNTRY_CD,
    INTRNAT_DRCT_APPL_CNTRY_NM,
    SPEC_CIRCUMS_NOTE_TXT,
    CP_AUTH_REPRESENT,
    NCP_AUTH_REPRESENT,
    FORM_SUPR_IND,
    DCSS_MANAGED_TRIBL_CASE_IND,
    IS_MRG_IND,
    INTRSTE_PRSPCTV_HIST_TYPE_CD,
    INTRSTE_PRSPCTV_HIST_TYPE_CD_NM,
    PUB_ASST_STAT_CD,
    CASE_CLS_DT,
    CASE_OPEN_DT,
    GOOD_CAUSE_CLM_STAT_CD,
    GOOD_CAUSE_CLM_STAT_CD_NM,
    CASE_CAT,
    CASE_STAT_DT,
    LAST_PMT_DT,
    DELQNT_TS,
    OUT_OF_COMPLI_TASK,
    DATA_RELAB_TASK_DUE,
    SRL_NUM_TXT,
    FAM_BGT_UNIT_TXT,
    EFFECTIVE_START_TS,
    EFFECTIVE_END_TS,
    CURRENT_RECORD_INDICATOR,
    UPDATED_BY,
    BTCH_RUN_ID,
    CASE_BALANCE,
    LATEST_NFR_INIT_DT_KEY,
    LATEST_NFR_FINL_DT_KEY,
    LATEST_INIT_MOD_DT_KEY,
    LATEST_FINL_ADMIN_MOD_DT_KEY,
    LATEST_BANKRUPTCY_DT_KEY,
    LATEST_CONTEMPT_DT_KEY,
    CASE_REOPEN_DT,
    STAT_TYPE_CD,
    LGCY_CASE_NBR,
    LTD_SERV_APPL_CNT,
    DETERMN_OTH_JURISD_FIPS_CD,
    DETERMN_DT,
    DETERMN_ROW_CREAT_USER,
    DEPENDENT_NAMES_NEEDING_PAT_EST,
    NET_CASE_TYPE_IND,
    OFFICE_REASM_ROW_UPDATE_TS,
    TEAM_REASM_ROW_UPDATE_TS,
    WORKER_REASM_ROW_UPDATE_TS,
    CASE_REOPENED_IND
)
SELECT
    xi.case_id,
    xi.mrg_into_case_id,
    xi.pnd_cls_int_user,
    xi.lgcy_stg_user_id,
    xi.crnt_asgn_off_id,
    xi.crnt_asgn_team_id,
    xi.crnt_asgn_case_mgr_id,
    xi.user_init_cls_just_txt,
    xi.non_coop_oth_rsn_txt,
    xi.fed_aid_stat_cd,
    xi.FED_AID_STAT_NM,
    xi.stat_aid_stat_cd,
    xi.STAT_AID_STAT_NM,
    xi.case_extid,
    xi.prev_case_extid,
    xi.non_ivd_acct_num_extid,
    xi.case_registr_cd,
    xi.mng_cnty_fips_cd,
    xi.MNG_CNTY_FIPS_NM,
    xi.pnd_cls_stat_cd,
    xi.PND_CLS_STAT_NM,
    xi.pnd_cls_type_cd,
    xi.PND_CLS_TYPE_NM,
    xi.pnd_cls_rsn_cd,
    xi.PND_CLS_RSN_NM,
    xi.PUB_ASST_STAT_NM,
    xi.CASE_REGISTR_NM,
    xi.crnt_stat_cd,
    xi.CRNT_STAT_NM,
    xi.crnt_type_cd,
    xi.CRNT_TYPE_NM,
    xi.non_ivd_src_doc_type_cd,
    xi.NON_IVD_SRC_DOC_TYPE_NM,
    xi.RSTRN_ORDR_NM,
    xi.rstrn_ordr_cd,
    xi.case_proc_cd,
    xi.CASE_PROC_NM,
    xi.crnt_case_func_cd,
    xi.CRNT_CASE_FUNC_NM,
    xi.auto_reasm_rule_cd,
    xi.AUTO_REASM_RULE_NM,
    xi.non_coop_stat_cd,
    xi.NON_COOP_STAT_NM,
    xi.non_coop_rsn_cd,
    xi.NON_COOP_RSN_NM,
    xi.noncoop_pubasst_cd,
    xi.NONCOOP_PUBASST_NM,
    xi.no_jurisd_ind,
    xi.fam_rcncl_ind,
    xi.arrs_unfrc_ind,
    xi.iva_prnt_togth_ind,
    xi.unscf_levs_ind,
    xi.no_fthr_actn_ind,
    xi.unkwn_fthr_ind,
    xi.cp_intrv_ind,
    xi.folup_ind,
    xi.rtct_supt_ordr_ind,
    xi.loc_only_ind,
    xi.rcp_req_cls_ind,
    xi.inpr_to_estb_ind,
    xi.cont_by_ph_ind,
    xi.no_info_ind,
    xi.oth_st_app_ind,
    xi.cmfr_oth_st_ind,
    xi.arrs_trnsfr_ind,
    xi.no_lngr_rspnd_ind,
    xi.donot_prg_ind,
    xi.pnd_cls_dt,
    xi.noncoop_pubasst_dt,
    xi.prg_dt,
    xi.pnd_cls_start_ts,
    xi.pnd_cls_stat_ts,
    xi.non_coop_stat_ts,
    xi.row_vers_id,
    xi.row_creat_user,
    xi.row_creat_ts,
    xi.row_update_user,
    xi.row_update_ts,
    xi.mng_cnty_case_extid,
    xi.chld_care_verif_sent_dt,
    xi.case_sub_cd,
    xi.CASE_SUB_NM,
    xi.phys_file_loc_txt,
    xi.court_ordr_pnd_oth_src_ind,
    xi.serv_req_cd,
    xi.SERV_REQ_NM,
    xi.no_auto_cls_ind,
    xi.intrnat_drct_appl_cntry_cd,
    xi.INTRNAT_DRCT_APPL_CNTRY_NM,
    xi.spec_circums_note_txt,
    xi.cp_auth_represent,
    xi.ncp_auth_represent,
    xi.form_supr_ind,
    xi.dcss_managed_tribl_case_ind,
    xi.is_mrg_ind,
    xi.INTRSTE_PRSPCTV_HIST_TYPE_CD,
    xi.INTRSTE_PRSPCTV_HIST_TYPE_CD_NM,
    xi.PUB_ASST_STAT_CD,
    xi.case_close_date                                  AS CASE_CLS_DT,
    xi.CASE_OPEN_DT,
    xi.GOOD_CAUSE_CLM_STAT_CD,
    xi.GOOD_CAUSE_CLM_STAT_CD_NM,
    xi.CASE_CAT_FINAL                                   AS CASE_CAT,
    xi.CASE_STAT_DT,
    xi.LAST_PMT_DT,
    xi.DELQNT_TS,
    xi.OUT_OF_COMPLI_TASK,
    xi.DATA_RELAB_TASK_DUE,
    xi.SRL_NUM_TXT,
    xi.FAM_BGT_UNIT_TXT,
    -- SCD Type 2 control columns (Transformer_171)
    CURRENT_TIMESTAMP()                                 AS EFFECTIVE_START_TS,
    CAST('9999-12-31 23:59:59' AS TIMESTAMP)            AS EFFECTIVE_END_TS,
    'Y'                                                 AS CURRENT_RECORD_INDICATOR,
    CURRENT_USER()                                      AS UPDATED_BY,
    CAST('${JP_BTCH_RUN_ID}' AS BIGINT)                AS BTCH_RUN_ID,
    xi.CASE_BALANCE,
    CAST(NULL AS DATE)                                  AS LATEST_NFR_INIT_DT_KEY,
    CAST(NULL AS DATE)                                  AS LATEST_NFR_FINL_DT_KEY,
    CAST(NULL AS DATE)                                  AS LATEST_INIT_MOD_DT_KEY,
    CAST(NULL AS DATE)                                  AS LATEST_FINL_ADMIN_MOD_DT_KEY,
    CAST(NULL AS DATE)                                  AS LATEST_BANKRUPTCY_DT_KEY,
    CAST(NULL AS DATE)                                  AS LATEST_CONTEMPT_DT_KEY,
    xi.CASE_REOPEN_DT,
    xi.STAT_TYPE_CD,
    xi.LGCY_CASE_NBR,
    xi.LTD_SERV_APPL_CNT,
    xi.DETERMN_OTH_JURISD_FIPS_CD,
    xi.DETERMN_DT,
    xi.DETERMN_ROW_CREAT_USER,
    xi.DEPENDENT_NAMES_NEEDING_PAT_EST,
    xi.NET_CASE_TYPE_IND,
    xi.OFFICE_REASM_ROW_UPDATE_TS,
    xi.TEAM_REASM_ROW_UPDATE_TS,
    xi.WORKER_REASM_ROW_UPDATE_TS,
    xi.CASE_REOPENED_IND
FROM xfrm_ins xi;

-- ============================================================
-- SECTION 8: UPDATE CANDIDATES OUTPUT (DS_DIM_CASE_UPD, PxDataSet)
-- Write the OLD DIM_CASE rows (to be closed by the UPD job) to parquet.
-- This is consumed by J_ORG_CASE_ODW_DIM_CASE_UPD via JP_DIMCASE_UPD_DS.
--
-- After Section 7's INSERT, ODW.DIM_CASE contains TWO rows with
-- CURRENT_RECORD_INDICATOR='Y' for every changed CASE_ID:
--   (a) the OLD row  — BTCH_RUN_ID from a previous batch run
--   (b) the NEW row  — BTCH_RUN_ID = ${JP_BTCH_RUN_ID} (just inserted)
--
-- We identify OLD rows to close by:
--   1. CURRENT_RECORD_INDICATOR = 'Y'   (still open)
--   2. BTCH_RUN_ID <> ${JP_BTCH_RUN_ID} (not the row we just inserted)
--   3. CASE_ID IN (cases that DID receive a new row this batch)
--      -> this excludes unchanged cases (no new row = no close needed)
--      -> this excludes brand-new cases (only one 'Y' row, which is new)
--
-- Syntax: INSERT OVERWRITE DIRECTORY is correct Spark SQL for parquet output.
-- ============================================================
INSERT OVERWRITE DIRECTORY '${JP_DIMCASE_UPD_DS}'
USING PARQUET
SELECT
    dc_old.DIM_CASE_KEY,
    CURRENT_TIMESTAMP()                                 AS EFFECTIVE_END_TS,
    'N'                                                 AS CURRENT_RECORD_INDICATOR,
    CURRENT_USER()                                      AS UPDATED_BY,  -- DataStage: DSHostName
    CAST('${JP_BTCH_RUN_ID}' AS BIGINT)                AS BTCH_RUN_ID
FROM ODW.DIM_CASE dc_old
WHERE dc_old.CURRENT_RECORD_INDICATOR = 'Y'
  AND dc_old.BTCH_RUN_ID <> CAST('${JP_BTCH_RUN_ID}' AS BIGINT)
  AND dc_old.CASE_ID IN (
      SELECT dc_new.CASE_ID
      FROM ODW.DIM_CASE dc_new
      WHERE dc_new.BTCH_RUN_ID    = CAST('${JP_BTCH_RUN_ID}' AS BIGINT)
        AND dc_new.CURRENT_RECORD_INDICATOR = 'Y'
  );
-- End of J_ORG_CASE_ODW_DIM_CASE_INS Spark SQL


"""

# ---------------------------------------------------------------------------
# Target column list (from XML schema - LNK_DB2_DIM_CASE_INS/Transformer_174 output)
# Ordered as they appear in the DataStage job schema
# ---------------------------------------------------------------------------
TARGET_COLUMNS = [
    "CASE_ID", "MRG_INTO_CASE_ID", "PND_CLS_INT_USER", "LGCY_STG_USER_ID",
    "CRNT_ASGN_OFF_ID", "CRNT_ASGN_TEAM_ID", "CRNT_ASGN_CASE_MGR_ID",
    "USER_INIT_CLS_JUST_TXT", "NON_COOP_OTH_RSN_TXT", "FED_AID_STAT_CD",
    "FED_AID_STAT_NM", "STAT_AID_STAT_CD", "STAT_AID_STAT_NM", "CASE_EXTID",
    "PREV_CASE_EXTID", "NON_IVD_ACCT_NUM_EXTID", "CASE_REGISTR_CD",
    "MNG_CNTY_FIPS_CD", "MNG_CNTY_FIPS_NM", "PND_CLS_STAT_CD", "PND_CLS_STAT_NM",
    "PND_CLS_TYPE_CD", "PND_CLS_TYPE_NM", "PND_CLS_RSN_CD", "PND_CLS_RSN_NM",
    "PUB_ASST_STAT_NM", "CASE_REGISTR_NM", "CRNT_STAT_CD", "CRNT_STAT_NM",
    "CRNT_TYPE_CD", "CRNT_TYPE_NM", "NON_IVD_SRC_DOC_TYPE_CD",
    "NON_IVD_SRC_DOC_TYPE_NM", "RSTRN_ORDR_NM", "RSTRN_ORDR_CD", "CASE_PROC_CD",
    "CASE_PROC_NM", "CRNT_CASE_FUNC_CD", "CRNT_CASE_FUNC_NM", "AUTO_REASM_RULE_CD",
    "AUTO_REASM_RULE_NM", "NON_COOP_STAT_CD", "NON_COOP_STAT_NM", "NON_COOP_RSN_CD",
    "NON_COOP_RSN_NM", "NONCOOP_PUBASST_CD", "NONCOOP_PUBASST_NM", "NO_JURISD_IND",
    "FAM_RCNCL_IND", "ARRS_UNFRC_IND", "IVA_PRNT_TOGTH_IND", "UNSCF_LEVS_IND",
    "NO_FTHR_ACTN_IND", "UNKWN_FTHR_IND", "CP_INTRV_IND", "FOLUP_IND",
    "RTCT_SUPT_ORDR_IND", "LOC_ONLY_IND", "RCP_REQ_CLS_IND", "INPR_TO_ESTB_IND",
    "CONT_BY_PH_IND", "NO_INFO_IND", "OTH_ST_APP_IND", "CMFR_OTH_ST_IND",
    "ARRS_TRNSFR_IND", "NO_LNGR_RSPND_IND", "DONOT_PRG_IND", "PND_CLS_DT",
    "NONCOOP_PUBASST_DT", "PRG_DT", "PND_CLS_START_TS", "PND_CLS_STAT_TS",
    "NON_COOP_STAT_TS", "ROW_VERS_ID", "ROW_CREAT_USER", "ROW_CREAT_TS",
    "ROW_UPDATE_USER", "ROW_UPDATE_TS", "MNG_CNTY_CASE_EXTID",
    "CHLD_CARE_VERIF_SENT_DT", "CASE_SUB_CD", "CASE_SUB_NM", "PHYS_FILE_LOC_TXT",
    "COURT_ORDR_PND_OTH_SRC_IND", "SERV_REQ_CD", "SERV_REQ_NM", "NO_AUTO_CLS_IND",
    "INTRNAT_DRCT_APPL_CNTRY_CD", "INTRNAT_DRCT_APPL_CNTRY_NM",
    "SPEC_CIRCUMS_NOTE_TXT", "CP_AUTH_REPRESENT", "NCP_AUTH_REPRESENT",
    "FORM_SUPR_IND", "DCSS_MANAGED_TRIBL_CASE_IND", "IS_MRG_IND",
    "INTRSTE_PRSPCTV_HIST_TYPE_CD", "INTRSTE_PRSPCTV_HIST_TYPE_CD_NM",
    "PUB_ASST_STAT_CD", "CASE_CLS_DT", "CASE_OPEN_DT", "GOOD_CAUSE_CLM_STAT_CD",
    "GOOD_CAUSE_CLM_STAT_CD_NM", "CASE_CAT", "CASE_STAT_DT", "LAST_PMT_DT",
    "DELQNT_TS", "OUT_OF_COMPLI_TASK", "DATA_RELAB_TASK_DUE", "SRL_NUM_TXT",
    "FAM_BGT_UNIT_TXT", "EFFECTIVE_START_TS", "EFFECTIVE_END_TS",
    "CURRENT_RECORD_INDICATOR", "UPDATED_BY", "BTCH_RUN_ID", "CASE_BALANCE",
    "LATEST_NFR_INIT_DT_KEY", "LATEST_NFR_FINL_DT_KEY", "LATEST_INIT_MOD_DT_KEY",
    "LATEST_FINL_ADMIN_MOD_DT_KEY", "LATEST_BANKRUPTCY_DT_KEY",
    "LATEST_CONTEMPT_DT_KEY", "CASE_REOPEN_DT", "STAT_TYPE_CD", "LGCY_CASE_NBR",
    "LTD_SERV_APPL_CNT", "DETERMN_OTH_JURISD_FIPS_CD", "DETERMN_DT",
    "DETERMN_ROW_CREAT_USER", "DEPENDENT_NAMES_NEEDING_PAT_EST",
    "NET_CASE_TYPE_IND", "OFFICE_REASM_ROW_UPDATE_TS", "TEAM_REASM_ROW_UPDATE_TS",
    "WORKER_REASM_ROW_UPDATE_TS",
]

# ---------------------------------------------------------------------------
# Main generation logic
# ---------------------------------------------------------------------------

def generate(output_path: Path) -> None:
    """Write the Spark SQL INSERT job script to output_path."""
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(SQL_CONTENT, encoding="utf-8")
    _validate_sql(SQL_CONTENT)
    print(f"Generated: {output_path}")
    print(f"  Target columns: {len(TARGET_COLUMNS)}")
    print(f"  File size: {len(SQL_CONTENT):,} bytes")


def _validate_sql(content: str) -> None:
    """Run basic validation checks on the generated SQL."""
    errors = []

    # Check all target columns appear in INSERT list
    for col in TARGET_COLUMNS:
        if col not in content:
            errors.append(f"Missing target column: {col}")

    # Check key SQL constructs
    required_constructs = [
        "WITH",
        "src_case",
        "src_code",
        "dim_case_current",
        "enriched_src",
        "src_with_checksum",
        "tgt_with_checksum",
        "joined_data",
        "xfrm_ins",
        "xfrm_upd",
        "INSERT INTO ODW.DIM_CASE",
        "CURRENT_TIMESTAMP()",
        "EFFECTIVE_START_TS",
        "EFFECTIVE_END_TS",
        "CURRENT_RECORD_INDICATOR",
        "MD5(",
        "INSERT OVERWRITE DIRECTORY",  # DS_DIM_CASE_UPD output (Section 8)
        "DAILY_LOW_DT_TS",
        "DAILY_HIGH_DT_TS",
    ]
    for construct in required_constructs:
        if construct not in content:
            errors.append(f"Missing SQL construct: {construct}")

    if errors:
        print(f"VALIDATION WARNINGS ({len(errors)}):", file=sys.stderr)
        for e in errors:
            print(f"  - {e}", file=sys.stderr)
    else:
        print(f"  Validation: PASS ({len(TARGET_COLUMNS)} columns, all constructs present)")


def _build_sql() -> str:
    """Return the embedded SQL constant directly."""
    return SQL_CONTENT


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def main() -> None:
    parser = argparse.ArgumentParser(
        description="Generate Spark SQL for J_ORG_CASE_ODW_DIM_CASE_INS job."
    )
    parser.add_argument(
        "--output",
        default=str(OUTPUT_FILE),
        help=f"Output SQL file path (default: {OUTPUT_FILE})",
    )
    parser.add_argument(
        "--validate-only",
        action="store_true",
        help="Only validate the existing SQL file, do not regenerate.",
    )
    args = parser.parse_args()

    output_path = Path(args.output)

    if args.validate_only:
        if not output_path.exists():
            print(f"ERROR: File not found: {output_path}", file=sys.stderr)
            sys.exit(1)
        content = output_path.read_text(encoding="utf-8")
        _validate_sql(content)
        return

    try:
        generate(output_path)
    except Exception as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
