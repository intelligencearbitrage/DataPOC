"""
parse_datastage_xml.py
======================
Utility parser for IBM InfoSphere DataStage v11.7 XML export files.

Extracts:
- Job parameters
- Stage inventory (name, type, identifier)
- DB2ConnectorPX SQL (from XMLProperties SelectStatement)
- TransformerStage code (from TrxGenCode MetaBag)
- Link/pin schemas (APT notation from Schema MetaBag)

Usage:
    python parse_datastage_xml.py <xml_file> [--output <yaml_file>]

Output:
    YAML document with job_name, parameters, stages, links

Part of: datastage-spark-sql-conversion pipeline
Component: parse_datastage_xml
"""

from __future__ import annotations

import argparse
import html
import re
import sys
import xml.etree.ElementTree as ET
from pathlib import Path
from typing import Optional


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _strip_xml_decl(text: str) -> str:
    """Remove <?xml ...?> declaration so inner XML can be wrapped in a root element."""
    return re.sub(r"<\?xml[^?]*\?>", "", text)


def _parse_xmlprops(val_text: str) -> Optional[ET.Element]:
    """Parse the HTML-encoded XMLProperties value into an ElementTree element."""
    try:
        inner = _strip_xml_decl(html.unescape(val_text))
        return ET.fromstring(f"<root>{inner}</root>")
    except ET.ParseError:
        return None


def _get_text(elem: ET.Element, tag: str) -> Optional[str]:
    """Return text of first matching child tag, or None."""
    child = elem.find(f".//{tag}")
    return child.text if child is not None else None


def _get_schema(record: ET.Element) -> Optional[str]:
    """Extract APT Schema from MetaBag."""
    for sb in record.findall("./Collection[@Name='MetaBag']/SubRecord"):
        n = sb.find("./Property[@Name='Name']")
        if n is not None and n.text == "Schema":
            v = sb.find("./Property[@Name='Value']")
            if v is not None:
                return v.text
    return None


def _get_metabag_val(record: ET.Element, name: str) -> Optional[str]:
    """Return MetaBag property value by name."""
    for sb in record.findall("./Collection[@Name='MetaBag']/SubRecord"):
        n = sb.find("./Property[@Name='Name']")
        if n is not None and n.text == name:
            v = sb.find("./Property[@Name='Value']")
            if v is not None:
                return v.text
    return None


def _indent(text: str, spaces: int = 4) -> str:
    pad = " " * spaces
    return "\n".join(pad + line for line in text.splitlines())


# ---------------------------------------------------------------------------
# Parsers
# ---------------------------------------------------------------------------

def parse_parameters(job: ET.Element) -> list[dict]:
    """Extract job parameters from Parameters collection."""
    params = []
    for sb in job.findall("./Record[@Identifier='ROOT']/Collection[@Name='Parameters']/SubRecord"):
        name = sb.findtext("./Property[@Name='Name']", "")
        prompt = sb.findtext("./Property[@Name='Prompt']", "")
        param_type = sb.findtext("./Property[@Name='ParamType']", "0")
        default = sb.findtext("./Property[@Name='Default']", "")
        params.append({
            "name": name,
            "prompt": prompt,
            "param_type": "ParameterSet" if param_type == "13" else "Scalar",
            "default": default,
        })
    return params


def parse_stage_inventory(job: ET.Element) -> list[dict]:
    """Parse ContainerView for the stage inventory."""
    v0 = job.find("./Record[@Identifier='V0']")
    if v0 is None:
        return []
    names_text = v0.findtext("./Property[@Name='StageNames']", "")
    types_text = v0.findtext("./Property[@Name='StageTypeIDs']", "")
    names = names_text.split("|")
    types = types_text.split("|")
    stages = []
    for name, stage_type in zip(names, types):
        name = name.strip()
        stage_type = stage_type.strip()
        if name:
            stages.append({"name": name, "type": stage_type})
    return stages


def parse_db2_stage(record: ET.Element) -> dict:
    """Extract SQL/table info from a DB2ConnectorPX stage."""
    result: dict = {
        "stage_type": "DB2ConnectorPX",
        "table_name": None,
        "write_mode": None,
        "sql": None,
    }
    for sb in record.findall("./Collection[@Name='Properties']/SubRecord"):
        pname = sb.findtext("./Property[@Name='Name']", "")
        if pname == "XMLProperties":
            val_elem = sb.find("./Property[@Name='Value']")
            if val_elem is not None and val_elem.text:
                itree = _parse_xmlprops(val_elem.text)
                if itree is not None:
                    result["table_name"] = _get_text(itree, "TableName")
                    result["write_mode"] = _get_text(itree, "WriteMode")
                    sql = _get_text(itree, "SelectStatement")
                    if sql is None:
                        sql = _get_text(itree, "UpdateStatement")
                    if sql:
                        result["sql"] = sql.strip()[:500] + ("..." if len(sql) > 500 else "")
    return result


def parse_transformer_stage(record: ET.Element) -> dict:
    """Extract TrxGenCode from a CTransformerStage."""
    code = _get_metabag_val(record, "TrxGenCode")
    return {
        "stage_type": "CTransformerStage",
        "trx_gen_code_snippet": (code[:300] + "..." if code and len(code) > 300 else code),
    }


def parse_all_stages(job: ET.Element) -> list[dict]:
    """Parse all stage records and return structured info."""
    stages = []
    for record in job.findall("Record"):
        rec_type = record.get("Type", "")
        name_elem = record.find("./Property[@Name='Name']")
        stage_type_elem = record.find("./Property[@Name='StageType']")
        if name_elem is None or stage_type_elem is None:
            continue
        name = name_elem.text or ""
        stage_type = stage_type_elem.text or ""
        entry: dict = {"name": name, "datastage_type": stage_type}
        if stage_type == "DB2ConnectorPX":
            entry.update(parse_db2_stage(record))
        elif stage_type == "CTransformerStage" and rec_type == "TransformerStage":
            entry.update(parse_transformer_stage(record))
        elif stage_type in ("PxJoin", "PxLookup", "PxFilter", "PxCopy",
                            "PxChecksum", "PxDataSet"):
            # Get operator/mode from XMLProperties if present
            for sb in record.findall("./Collection[@Name='Properties']/SubRecord"):
                n = sb.findtext("./Property[@Name='Name']", "")
                v = sb.findtext("./Property[@Name='Value']", "")
                if n in ("operator", "comp_mode", "key"):
                    entry[n] = v[:100]
        if name:
            stages.append(entry)
    return stages


def parse_links(job: ET.Element) -> list[dict]:
    """Parse link schemas from pin records."""
    links = []
    pin_types = {"TrxInput", "TrxOutput", "CustomInput", "CustomOutput"}
    for record in job.findall("Record"):
        rec_type = record.get("Type", "")
        if rec_type not in pin_types:
            continue
        name_elem = record.find("./Property[@Name='Name']")
        name = name_elem.text if name_elem is not None else ""
        schema = _get_schema(record)
        columns: list[str] = []
        for col in record.findall("./Collection[@Name='Columns']/SubRecord"):
            col_name = col.findtext("./Property[@Name='Name']", "")
            derivation = col.findtext("./Property[@Name='Derivation']", "")
            if col_name:
                columns.append(f"{col_name} <- {derivation}" if derivation else col_name)
        if name and (schema or columns):
            links.append({
                "link_name": name,
                "pin_type": rec_type,
                "schema_snippet": schema[:300] if schema else None,
                "column_count": len(columns),
                "columns_sample": columns[:5],
            })
    return links


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def parse_datastage_xml(xml_path: Path) -> dict:
    """Parse a DataStage XML export file and return structured findings."""
    tree = ET.parse(xml_path)
    root = tree.getroot()
    job = root.find("Job")
    if job is None:
        raise ValueError(f"No <Job> element found in {xml_path}")

    job_id = job.get("Identifier", "UNKNOWN")
    date_mod = job.get("DateModified", "")
    description = job.findtext("./Record[@Identifier='ROOT']/Property[@Name='Description']", "")

    return {
        "job_identifier": job_id,
        "date_modified": date_mod,
        "description": description.strip(),
        "parameters": parse_parameters(job),
        "stage_inventory": parse_stage_inventory(job),
        "stage_details": parse_all_stages(job),
        "links": parse_links(job),
    }


def findings_to_yaml(findings: dict) -> str:
    """Render findings as YAML (simple hand-built, no dependency on PyYAML)."""
    lines = [
        f"job_identifier: \"{findings['job_identifier']}\"",
        f"date_modified: \"{findings['date_modified']}\"",
        f"description: |",
        _indent(findings["description"], 2),
        "",
        "parameters:",
    ]
    for p in findings["parameters"]:
        lines.append(f"  - name: {p['name']}")
        lines.append(f"    type: {p['param_type']}")
        if p["default"]:
            lines.append(f"    default: \"{p['default']}\"")
    lines.append("")
    lines.append("stage_inventory:")
    for s in findings["stage_inventory"]:
        lines.append(f"  - name: {s['name']}")
        lines.append(f"    type: {s['type']}")
    lines.append("")
    lines.append("stage_details:")
    for s in findings["stage_details"]:
        lines.append(f"  - name: {s.get('name', '')}")
        lines.append(f"    datastage_type: {s.get('datastage_type', '')}")
        if s.get("table_name"):
            lines.append(f"    table_name: \"{s['table_name']}\"")
        if s.get("write_mode") is not None:
            lines.append(f"    write_mode: {s['write_mode']}")
        if s.get("sql"):
            lines.append("    sql_snippet: |")
            lines.append(_indent(s["sql"], 6))
    lines.append("")
    lines.append("links:")
    for lk in findings["links"]:
        lines.append(f"  - link_name: {lk['link_name']}")
        lines.append(f"    pin_type: {lk['pin_type']}")
        lines.append(f"    column_count: {lk['column_count']}")
        if lk["columns_sample"]:
            lines.append("    columns_sample:")
            for c in lk["columns_sample"]:
                lines.append(f"      - \"{c}\"")
    return "\n".join(lines)


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Parse DataStage v11.7 XML export and extract stage DAG info."
    )
    parser.add_argument("xml_file", help="Path to DataStage XML export file")
    parser.add_argument(
        "--output",
        help="Output YAML file path (default: stdout)",
        default=None,
    )
    args = parser.parse_args()

    xml_path = Path(args.xml_file)
    if not xml_path.exists():
        print(f"ERROR: File not found: {xml_path}", file=sys.stderr)
        sys.exit(1)

    try:
        findings = parse_datastage_xml(xml_path)
        yaml_text = findings_to_yaml(findings)
    except Exception as exc:
        print(f"ERROR parsing {xml_path}: {exc}", file=sys.stderr)
        sys.exit(1)

    if args.output:
        output_path = Path(args.output)
        output_path.parent.mkdir(parents=True, exist_ok=True)
        output_path.write_text(yaml_text, encoding="utf-8")
        print(f"Written to {output_path}")
    else:
        print(yaml_text)


if __name__ == "__main__":
    main()
