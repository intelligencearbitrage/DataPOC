"""
generate_spark_sql_upd.py
=========================
Generator script for the UPDATE job Spark SQL file.

Reads research findings and plans, then writes the complete
Spark SQL script for J_ORG_CASE_ODW_DIM_CASE_UPD to:
    scripts-output/output/j_org_case_odw_dim_case_upd.sql

The SQL implements:
  - Dataset source read (DS_DIM_CASE_UPD as parquet TEMP VIEW)
  - Pass-through (CP_DIMCASE_UPD, PxCopy)
  - MERGE INTO ODW.DIM_CASE (DB2_DIM_CASE, WriteMode=1 Update)
    to close/expire existing SCD Type 2 records

Usage:
    python generate_spark_sql_upd.py [--output <path>]

Part of: datastage-spark-sql-conversion pipeline
Component: generate_spark_sql_upd
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------

PROJECT_ROOT = Path(__file__).resolve().parent.parent.parent
OUTPUT_FILE = (
    PROJECT_ROOT / "scripts-output" / "output" / "j_org_case_odw_dim_case_upd.sql"
)
RESEARCH_UPD = PROJECT_ROOT / "agent-output" / "research" / "upd_job_findings.yaml"
PLAN_UPD = PROJECT_ROOT / "agent-output" / "plans" / "generate_spark_sql_upd_plan.yaml"

# ---------------------------------------------------------------------------
# Embedded SQL constant — authoritative source for the UPD job SQL.
# This script regenerates the output file from this constant even if the
# output file has been deleted.
# ---------------------------------------------------------------------------
SQL_CONTENT = r"""
-- ============================================================
-- J_ORG_CASE_ODW_DIM_CASE_UPD: SCD Type 2 Close/Expire
-- ============================================================
-- DataStage Job   : J_ORG_CASE_ODW_DIM_CASE_UPD
-- DataStage Version: 11.7
-- Job Version     : 56.0
-- Target Platform : Apache Spark SQL (standalone)
-- Category        : Jobs\Deployment\Conformed Dimensions
-- Domain          : Government Child Support Enforcement (IV-D)
--
-- Description:
--   This Job reads update data from a pre-staged DataStage Dataset
--   and updates the corresponding SCD Type 2 columns in DIM_CASE table.
--   Specifically, it CLOSES/EXPIRES existing current DIM_CASE records
--   by setting EFFECTIVE_END_TS, CURRENT_RECORD_INDICATOR='N',
--   UPDATED_BY, and BTCH_RUN_ID.
--
--   This job is always executed AFTER J_ORG_CASE_ODW_DIM_CASE_INS,
--   which identifies changed records and writes update candidates to
--   the dataset referenced by JP_DIMCASE_UPD_DS.
--
-- Stage DAG (DataStage -> Spark SQL):
--   DS_DIM_CASE_UPD (PxDataSet)  -> ds_dim_case_upd (TEMP VIEW from parquet)
--   CP_DIMCASE_UPD  (PxCopy)     -> pass-through (no transformation)
--   DB2_DIM_CASE    (DB2ConnectorPX, WriteMode=1 Update) -> MERGE INTO ODW.DIM_CASE
--
-- Version History:
--   1.0  2016-10-27  Initial Job
-- ============================================================

-- ============================================================
-- SECTION 1: PARAMETER DECLARATIONS
-- Maps to DataStage job parameters:
--   PS_ODW_TGT (parameter set) -> SCHEMA_ODW
--   JP_DIMCASE_UPD_DS           -> path to update candidates dataset
-- ============================================================
-- PARAM: PS_ODW_TGT -> target schema (ODW)
-- PARAM: JP_DIMCASE_UPD_DS -> dataset path populated by INS job
SET SCHEMA_ODW         = 'ODW';
SET JP_DIMCASE_UPD_DS  = '/path/to/dim_case_upd_dataset';
SET JP_BTCH_RUN_ID     = 0;

-- ============================================================
-- SECTION 2: SOURCE DATASET (DS_DIM_CASE_UPD, PxDataSet)
-- Load update candidates from parquet dataset written by INS job.
-- The dataset contains 5 columns: DIM_CASE_KEY, EFFECTIVE_END_TS,
-- CURRENT_RECORD_INDICATOR, UPDATED_BY, BTCH_RUN_ID.
-- In DataStage: DS_DIM_CASE_UPD -> LNK_DS_DIM_CASE_UPD link output.
-- ============================================================
CREATE OR REPLACE TEMP VIEW ds_dim_case_upd AS
SELECT
    CAST(DIM_CASE_KEY            AS BIGINT)         AS DIM_CASE_KEY,
    CAST(EFFECTIVE_END_TS        AS TIMESTAMP)      AS EFFECTIVE_END_TS,
    CAST(CURRENT_RECORD_INDICATOR AS CHAR(1))       AS CURRENT_RECORD_INDICATOR,
    CAST(UPDATED_BY              AS VARCHAR(50))    AS UPDATED_BY,
    CAST(BTCH_RUN_ID             AS BIGINT)         AS BTCH_RUN_ID
FROM parquet.`${JP_DIMCASE_UPD_DS}`;

-- ============================================================
-- SECTION 3: PASS-THROUGH (CP_DIMCASE_UPD, PxCopy)
-- PxCopy stage passes all columns through unchanged.
-- LNK_DS_DIM_CASE_UPD -> LNK_DB2_DIM_CASE_UPD
-- In Spark SQL: referenced directly in the MERGE below.
-- No separate CTE required for pass-through.
-- ============================================================
-- (CP_DIMCASE_UPD: no transformation applied, same view used downstream)

-- ============================================================
-- SECTION 4: SCD TYPE 2 CLOSE (DB2_DIM_CASE, DB2ConnectorPX)
-- WriteMode=1 (Update/Upsert) on ODW.DIM_CASE.
-- Target table: #PS_ODW_TGT.pSCHEMA_ODW#.DIM_CASE -> ODW.DIM_CASE
-- Match key: DIM_CASE_KEY AND CURRENT_RECORD_INDICATOR = 'Y'
--   -> only targets current (active) DIM_CASE records.
-- Updated columns:
--   EFFECTIVE_END_TS         (set to close timestamp from INS job)
--   CURRENT_RECORD_INDICATOR (set to 'N' to mark as historical)
--   UPDATED_BY               (system/hostname)
--   BTCH_RUN_ID              (batch identifier)
-- ============================================================
MERGE INTO ODW.DIM_CASE AS tgt
USING ds_dim_case_upd AS src
ON  tgt.DIM_CASE_KEY            = src.DIM_CASE_KEY
AND tgt.CURRENT_RECORD_INDICATOR = 'Y'
WHEN MATCHED THEN
    UPDATE SET
        tgt.EFFECTIVE_END_TS         = src.EFFECTIVE_END_TS,
        tgt.CURRENT_RECORD_INDICATOR = src.CURRENT_RECORD_INDICATOR,
        tgt.UPDATED_BY               = src.UPDATED_BY,
        tgt.BTCH_RUN_ID              = src.BTCH_RUN_ID;

-- ============================================================
-- END OF J_ORG_CASE_ODW_DIM_CASE_UPD
-- ============================================================
-- NOTES:
-- 1. This job must run AFTER J_ORG_CASE_ODW_DIM_CASE_INS completes,
--    because the INS job populates the JP_DIMCASE_UPD_DS dataset.
--
-- 2. The execution order for a full SCD2 load is:
--    Step 1: Run J_ORG_CASE_ODW_DIM_CASE_INS.sql
--            -> Inserts new/changed records into DIM_CASE
--            -> Writes update candidates to JP_DIMCASE_UPD_DS parquet
--    Step 2: Run J_ORG_CASE_ODW_DIM_CASE_UPD.sql  (this script)
--            -> Reads JP_DIMCASE_UPD_DS
--            -> Closes old DIM_CASE records (sets EFFECTIVE_END_TS, CURRENT_RECORD_INDICATOR='N')
--
-- 3. In a production Spark environment, replace parquet.`${JP_DIMCASE_UPD_DS}`
--    with the actual path or Delta table reference as appropriate.
--
-- 4. If using Delta Lake tables, the MERGE INTO syntax above is fully supported.
--    For non-Delta Spark SQL, use a two-step UPDATE workaround:
--
--    -- Alternative for non-Delta Spark SQL:
--    CREATE OR REPLACE TEMP VIEW dim_case_to_close AS
--    SELECT tgt.*
--    FROM ODW.DIM_CASE tgt
--    INNER JOIN ds_dim_case_upd src
--        ON tgt.DIM_CASE_KEY = src.DIM_CASE_KEY
--       AND tgt.CURRENT_RECORD_INDICATOR = 'Y';
--
--    INSERT OVERWRITE ODW.DIM_CASE
--    SELECT
--        CASE WHEN dc.DIM_CASE_KEY IN (SELECT DIM_CASE_KEY FROM ds_dim_case_upd)
--                  AND dc.CURRENT_RECORD_INDICATOR = 'Y'
--             THEN src.EFFECTIVE_END_TS
--             ELSE dc.EFFECTIVE_END_TS
--        END AS EFFECTIVE_END_TS,
--        CASE WHEN dc.DIM_CASE_KEY IN (SELECT DIM_CASE_KEY FROM ds_dim_case_upd)
--                  AND dc.CURRENT_RECORD_INDICATOR = 'Y'
--             THEN src.CURRENT_RECORD_INDICATOR
--             ELSE dc.CURRENT_RECORD_INDICATOR
--        END AS CURRENT_RECORD_INDICATOR,
--        ... (all other columns unchanged)
--    FROM ODW.DIM_CASE dc
--    LEFT JOIN ds_dim_case_upd src ON dc.DIM_CASE_KEY = src.DIM_CASE_KEY;
"""

# Update columns (from LNK_DB2_DIM_CASE_UPD link schema in XML)
UPDATE_COLUMNS = [
    "DIM_CASE_KEY",           # match key
    "EFFECTIVE_END_TS",       # SCD2 close timestamp
    "CURRENT_RECORD_INDICATOR",  # set to 'N'
    "UPDATED_BY",             # system/hostname
    "BTCH_RUN_ID",            # batch identifier
]

# ---------------------------------------------------------------------------
# Main generation logic
# ---------------------------------------------------------------------------

def generate(output_path: Path) -> None:
    """Write the Spark SQL UPDATE job script to output_path."""
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(SQL_CONTENT, encoding="utf-8")
    _validate_sql(SQL_CONTENT)
    print(f"Generated: {output_path}")
    print(f"  Update columns: {len(UPDATE_COLUMNS)}")
    print(f"  File size: {len(SQL_CONTENT):,} bytes")


def _validate_sql(content: str) -> None:
    """Run basic validation checks on the generated SQL."""
    errors = []

    # Check all update columns appear
    for col in UPDATE_COLUMNS:
        if col not in content:
            errors.append(f"Missing update column: {col}")

    # Check key SQL constructs
    required_constructs = [
        "CREATE OR REPLACE TEMP VIEW ds_dim_case_upd",
        "MERGE INTO ODW.DIM_CASE",
        "USING ds_dim_case_upd",
        "CURRENT_RECORD_INDICATOR = 'Y'",
        "WHEN MATCHED THEN",
        "UPDATE SET",
        "EFFECTIVE_END_TS",
        "CURRENT_RECORD_INDICATOR",
        "JP_DIMCASE_UPD_DS",
        "parquet.",
    ]
    for construct in required_constructs:
        if construct not in content:
            errors.append(f"Missing SQL construct: {construct}")

    if errors:
        print(f"VALIDATION WARNINGS ({len(errors)}):", file=sys.stderr)
        for e in errors:
            print(f"  - {e}", file=sys.stderr)
    else:
        print(f"  Validation: PASS ({len(UPDATE_COLUMNS)} update columns, all constructs present)")


def _build_sql() -> str:
    """Return the embedded SQL constant directly."""
    return SQL_CONTENT


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def main() -> None:
    parser = argparse.ArgumentParser(
        description="Generate Spark SQL for J_ORG_CASE_ODW_DIM_CASE_UPD job."
    )
    parser.add_argument(
        "--output",
        default=str(OUTPUT_FILE),
        help=f"Output SQL file path (default: {OUTPUT_FILE})",
    )
    parser.add_argument(
        "--validate-only",
        action="store_true",
        help="Only validate the existing SQL file, do not regenerate.",
    )
    args = parser.parse_args()

    output_path = Path(args.output)

    if args.validate_only:
        if not output_path.exists():
            print(f"ERROR: File not found: {output_path}", file=sys.stderr)
            sys.exit(1)
        content = output_path.read_text(encoding="utf-8")
        _validate_sql(content)
        return

    try:
        generate(output_path)
    except Exception as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
