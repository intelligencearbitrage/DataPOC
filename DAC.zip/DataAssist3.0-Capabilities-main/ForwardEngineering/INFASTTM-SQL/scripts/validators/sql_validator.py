"""
SQL Validator — Validates generated SnowSQL artifacts.

Checks for common issues: missing semicolons, unresolved parameters,
empty SELECT lists, invalid syntax patterns, etc.
"""

import re
import sys
from pathlib import Path
from typing import Dict, List

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from base.base_validator import BaseValidator
from utils import save_yaml


class SqlValidator(BaseValidator):
    """Validates generated Snowflake SQL files."""

    def validate(self) -> List[Dict[str, str]]:
        issues = []
        sql_files = sorted(self.target_dir.rglob("*.sql"))

        if not sql_files:
            issues.append({
                "severity": "ERROR",
                "file": str(self.target_dir),
                "message": "No SQL files found in output directory",
            })
            return issues

        for sql_file in sql_files:
            content = sql_file.read_text(encoding="utf-8")
            issues.extend(self._check_file(sql_file, content))

        return issues

    def _check_file(self, file_path: Path, content: str) -> List[Dict[str, str]]:
        issues = []
        fname = str(file_path)

        # Check for unresolved Informatica parameters
        unresolved = re.findall(r"\$\$\w+", content)
        if unresolved:
            issues.append({
                "severity": "WARNING",
                "file": fname,
                "message": f"Unresolved Informatica parameters: {unresolved[:5]}",
            })

        # Check for bare 'Not Mapped' identifiers
        if re.search(r"\bNot Mapped\b", content, re.IGNORECASE):
            issues.append({
                "severity": "ERROR",
                "file": fname,
                "message": "Contains bare 'Not Mapped' identifier — should be NULL",
            })

        # Check for empty SELECT
        if "SELECT\nFROM" in content or "SELECT\n    FROM" in content:
            issues.append({
                "severity": "ERROR",
                "file": fname,
                "message": "Empty SELECT list detected",
            })

        # Check for missing FROM clause in INSERT...SELECT
        if "INSERT INTO" in content.upper() and "SELECT" in content.upper():
            if "FROM" not in content.upper():
                issues.append({
                    "severity": "ERROR",
                    "file": fname,
                    "message": "INSERT...SELECT without FROM clause",
                })

        return issues


def main():
    validator = SqlValidator(target_dir="output")
    issues = validator.validate()
    report = validator.report(issues)
    save_yaml(report, Path("testscripts") / "sql_validation_report.yaml")


if __name__ == "__main__":
    main()
