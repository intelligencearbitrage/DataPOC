"""
Procedure Generator — Generates Snowflake stored procedures wrapping DML.
"""

import sys
from pathlib import Path
from typing import Any, Dict, List

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from converter.sttm_to_model import GenerationModel
from templates.template_engine import TemplateEngine


class ProcedureGenerator:
    """Generates SP_LOAD_* stored procedures from DML artifacts."""

    SKIP_KEYWORDS = ("INTERMEDIATE", "TEMP", "WORK", "STAGING", "TMP")

    def __init__(self, template_engine: TemplateEngine):
        self.engine = template_engine

    def generate(
        self,
        model: GenerationModel,
        dml_artifacts: List[Dict[str, str]],
        table_strategies: Dict[str, Dict[str, str]],
    ) -> List[Dict[str, str]]:
        """Generate stored procedure artifacts.

        Args:
            model: Internal generation model
            dml_artifacts: DML artifacts from DmlGenerator
            table_strategies: {table_name: {dml_strategy, schema}}

        Returns list of {name, type, schema, sql} dicts.
        """
        dml_lookup = {a["name"]: a["sql"] for a in dml_artifacts}
        artifacts = []

        for table_name, table_info in model.table_registry.items():
            if any(kw in table_name.upper() for kw in self.SKIP_KEYWORDS):
                continue
            if table_info.get("table_type") == "SOURCE":
                continue

            schema = table_info.get("owner", "PUBLIC")
            proc_name = f"SP_LOAD_{table_name}"

            dml_sql = dml_lookup.get(f"{table_name}_LOAD", "")
            if not dml_sql:
                continue

            sql = self.engine.render_procedure(
                proc_name=proc_name,
                schema=schema,
                main_sql=dml_sql,
                description=f"Load procedure for {table_name}",
            )

            artifacts.append({
                "name": proc_name,
                "type": "PROCEDURE",
                "schema": schema,
                "sql": sql,
            })

        return artifacts
