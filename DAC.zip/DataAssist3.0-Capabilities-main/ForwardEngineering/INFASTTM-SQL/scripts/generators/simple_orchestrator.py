"""
Simple Orchestrator — Preserves original schema names (no medallion layers).

Scenario 1: JSON STTM → Simple conversion
Scenario 3: Excel STTM → Uses schema from Excel (BRONZE_RCC, SILVER_CDC_RCC, etc.)

Detects DML strategy (INSERT vs MERGE) from DML operations in the model,
then orchestrates DDL → DML → Procedure generation.
"""

import sys
from pathlib import Path
from typing import Any, Dict, List

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from converter.sttm_to_model import GenerationModel
from generators.ddl_generator import DdlGenerator
from generators.dml_generator import DmlGenerator
from generators.procedure_generator import ProcedureGenerator
from templates.template_engine import TemplateEngine
from utils import save_sql, setup_logging


class SimpleOrchestrator:
    """Orchestrates Simple (non-medallion) code generation.

    Preserves original schema names from the STTM data.
    Auto-detects INSERT vs MERGE strategy per table.
    """

    def __init__(self, database: str, warehouse: str = "", output_dir: str = "output"):
        self.database = database
        self.warehouse = warehouse
        self.output_dir = Path(output_dir)
        self.logger = setup_logging("SimpleOrchestrator")

        self.template_engine = TemplateEngine(database, warehouse)
        self.ddl_gen = DdlGenerator(self.template_engine)
        self.dml_gen = DmlGenerator(self.template_engine, database)
        self.proc_gen = ProcedureGenerator(self.template_engine)

    def run(self, model: GenerationModel) -> Dict[str, Any]:
        """Run the full generation pipeline for a single model.

        Returns summary dict with counts and file paths.
        """
        proc_name = model.proc_name or "CONVERSION"
        self.logger.info(f"Generating: {proc_name}")

        # Phase 1: Detect strategies
        strategies = self._detect_strategies(model)

        # Phase 2: Generate DDL
        ddl_artifacts = self.ddl_gen.generate(model)
        self.logger.info(f"  DDL: {len(ddl_artifacts)} tables")

        # Phase 3: Generate DML
        dml_artifacts = self.dml_gen.generate(model, strategies)
        self.logger.info(f"  DML: {len(dml_artifacts)} statements")

        # Phase 4: Generate Stored Procedures
        proc_artifacts = self.proc_gen.generate(model, dml_artifacts, strategies)
        self.logger.info(f"  SPs: {len(proc_artifacts)} procedures")

        # Phase 5: Generate infrastructure
        infra_sql = self.template_engine.render_log_table()

        # Export
        base_dir = self.output_dir / proc_name
        files = self._export(base_dir, ddl_artifacts, dml_artifacts, proc_artifacts, infra_sql)

        return {
            "proc_name": proc_name,
            "status": "SUCCESS",
            "ddl_count": len(ddl_artifacts),
            "dml_count": len(dml_artifacts),
            "procedure_count": len(proc_artifacts),
            "output_dir": str(base_dir),
            "files": files,
        }

    def _detect_strategies(self, model: GenerationModel) -> Dict[str, Dict[str, str]]:
        """Detect DML strategy (INSERT or MERGE) for each target table.

        Priority: explicit dml_operations from parser > primary key heuristic > INSERT default.
        """
        strategies = {}
        for table_name, table_info in model.table_registry.items():
            schema = table_info.get("owner", "PUBLIC")
            dml_strategy = "INSERT"

            # Use dml_operations propagated from parser (e.g. Update Strategy → MERGE)
            dml_ops = {op.upper() for op in table_info.get("dml_operations", [])}
            if "MERGE" in dml_ops:
                dml_strategy = "MERGE"
            elif table_info.get("primary_keys"):
                # Fallback: tables with primary keys default to MERGE
                dml_strategy = "MERGE"

            strategies[table_name] = {
                "dml_strategy": dml_strategy,
                "schema": schema,
            }

        return strategies

    def _export(
        self,
        base_dir: Path,
        ddl_artifacts: List[Dict],
        dml_artifacts: List[Dict],
        proc_artifacts: List[Dict],
        infra_sql: str,
    ) -> List[str]:
        """Export all artifacts to files."""
        files = []

        for a in ddl_artifacts:
            p = save_sql(a["sql"], base_dir / "ddl" / f"{a['name'].lower()}.sql")
            files.append(str(p))

        for a in dml_artifacts:
            p = save_sql(a["sql"], base_dir / "dml" / f"{a['name'].lower()}.sql")
            files.append(str(p))

        for a in proc_artifacts:
            p = save_sql(a["sql"], base_dir / "procedures" / f"{a['name'].lower()}.sql")
            files.append(str(p))

        p = save_sql(infra_sql, base_dir / "infrastructure" / "procedure_log.sql")
        files.append(str(p))

        self.logger.info(f"  Exported {len(files)} files to {base_dir}")
        return files
