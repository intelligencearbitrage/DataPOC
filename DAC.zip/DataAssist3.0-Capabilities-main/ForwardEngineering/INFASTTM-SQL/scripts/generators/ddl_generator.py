"""
DDL Generator — Generates CREATE TABLE statements for target tables.
"""

import sys
from pathlib import Path
from typing import Any, Dict, List

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from converter.sttm_to_model import GenerationModel
from translation.datatype_mapper import DatatypeMapper
from templates.template_engine import TemplateEngine


class DdlGenerator:
    """Generates Snowflake DDL (CREATE TABLE) from a GenerationModel."""

    SKIP_KEYWORDS = ("INTERMEDIATE", "TEMP", "WORK", "STAGING", "TMP")

    def __init__(self, template_engine: TemplateEngine):
        self.engine = template_engine

    def generate(self, model: GenerationModel) -> List[Dict[str, str]]:
        """Generate DDL artifacts for all tables in the model.

        Returns list of {name, type, schema, sql} dicts.
        """
        artifacts = []

        for table_name, table_info in model.table_registry.items():
            if any(kw in table_name.upper() for kw in self.SKIP_KEYWORDS):
                continue

            schema = table_info.get("owner", "PUBLIC")
            columns = []

            for col_name, col_info in table_info.get("columns", {}).items():
                # Fix 1: Strip schema.table prefix from column names
                # e.g. "P_EDW_STG_01_E0.TABLE.COL" → "COL"
                clean_col = col_name.rsplit(".", 1)[-1] if "." in col_name else col_name
                # Fix 2: Strip trailing dots from column names
                clean_col = clean_col.rstrip(".")
                if not clean_col:
                    continue

                if isinstance(col_info, dict):
                    dt = col_info.get("datatype", "VARCHAR")
                    prec = col_info.get("precision")
                    scale = col_info.get("scale")
                    mapped = DatatypeMapper.format_column_type(dt, prec, scale)
                    nullable = col_info.get("nullable", True)
                else:
                    mapped = DatatypeMapper.map(str(col_info) if col_info else "VARCHAR(255)")
                    nullable = True

                columns.append({
                    "name": clean_col,
                    "datatype": mapped,
                    "nullable": nullable,
                })

            if not columns:
                continue  # Skip tables with no valid columns

            sql = self.engine.render_ddl(table_name, columns, schema)
            artifacts.append({
                "name": table_name,
                "type": "DDL",
                "schema": schema,
                "sql": sql,
            })

        return artifacts
