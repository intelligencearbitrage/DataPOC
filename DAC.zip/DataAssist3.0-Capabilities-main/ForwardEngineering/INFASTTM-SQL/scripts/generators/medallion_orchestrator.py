"""
Medallion Orchestrator — Routes tables to Bronze/Silver/Gold layers.

Scenario 2: JSON STTM → Medallion conversion
Uses classification data to assign tables to medallion layers,
then delegates to the shared DDL/DML/Procedure generators.
"""

import sys
from pathlib import Path
from typing import Any, Dict, List

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from converter.sttm_to_model import GenerationModel
from generators.ddl_generator import DdlGenerator
from generators.dml_generator import DmlGenerator
from generators.procedure_generator import ProcedureGenerator
from templates.template_engine import TemplateEngine
from utils import save_sql, setup_logging


LAYER_SCHEMA_DEFAULTS = {
    "BRONZE": "BRONZE_SCHEMA",
    "SILVER": "SILVER_SCHEMA",
    "GOLD": "GOLD_SCHEMA",
    "COMMON": "COMMON",
}


class MedallionOrchestrator:
    """Orchestrates Medallion (Bronze/Silver/Gold) code generation.

    Classifies tables into layers and routes them to the appropriate
    schema, then generates DDL, DML, and Stored Procedures.
    """

    def __init__(
        self,
        database: str,
        warehouse: str = "",
        output_dir: str = "output",
        layer_schemas: Dict[str, str] = None,
    ):
        self.database = database
        self.warehouse = warehouse
        self.output_dir = Path(output_dir)
        self.layer_schemas = layer_schemas or LAYER_SCHEMA_DEFAULTS
        self.logger = setup_logging("MedallionOrchestrator")

        self.template_engine = TemplateEngine(database, warehouse)
        self.ddl_gen = DdlGenerator(self.template_engine)
        self.dml_gen = DmlGenerator(self.template_engine, database)
        self.proc_gen = ProcedureGenerator(self.template_engine)

    def run(
        self,
        model: GenerationModel,
        classifications: Dict[str, str] = None,
    ) -> Dict[str, Any]:
        """Run medallion generation pipeline.

        Args:
            model: Internal generation model
            classifications: {table_name: 'BRONZE'|'SILVER'|'GOLD'} mapping.
                If None, auto-classifies based on table name patterns.

        Returns summary dict.
        """
        proc_name = model.proc_name or "MEDALLION"
        self.logger.info(f"Generating (Medallion): {proc_name}")

        # Phase 1: Classify tables into layers
        # Skip classification if schemas are already explicit (e.g. RCC Excel
        # with BRONZE_RCC, SILVER_CDC_RCC etc.) — only reclassify when schemas
        # are generic defaults like PUBLIC.
        if classifications is None:
            if self._has_explicit_schemas(model):
                self.logger.info("  Schemas already defined in source — skipping layer classification")
                classifications = {}
            else:
                classifications = self._auto_classify(model)
        if classifications:
            self._apply_classifications(model, classifications)

        # Phase 2-4: Same pipeline as Simple
        strategies = self._detect_strategies(model, classifications)

        ddl_artifacts = self.ddl_gen.generate(model)
        dml_artifacts = self.dml_gen.generate(model, strategies)
        proc_artifacts = self.proc_gen.generate(model, dml_artifacts, strategies)
        infra_sql = self.template_engine.render_log_table()

        base_dir = self.output_dir / proc_name
        files = self._export(base_dir, ddl_artifacts, dml_artifacts, proc_artifacts, infra_sql)

        return {
            "proc_name": proc_name,
            "status": "SUCCESS",
            "mode": "medallion",
            "ddl_count": len(ddl_artifacts),
            "dml_count": len(dml_artifacts),
            "procedure_count": len(proc_artifacts),
            "layer_counts": self._count_by_layer(ddl_artifacts),
            "output_dir": str(base_dir),
            "files": files,
        }

    def _has_explicit_schemas(self, model: GenerationModel) -> bool:
        """Check if the model already has meaningful (non-default) schemas.

        Returns True when most target tables have schemas that are not
        generic defaults like 'PUBLIC', meaning the input data already
        carries its own schema structure (e.g. RCC Excel with BRONZE_RCC,
        SILVER_CLEANSED_RCC, etc.).
        """
        generic = {"PUBLIC", "DEFAULT", ""}
        targets = [
            info for info in model.table_registry.values()
            if info.get("table_type") == "TARGET"
        ]
        if not targets:
            return False
        explicit = sum(
            1 for t in targets if t.get("owner", "PUBLIC").upper() not in generic
        )
        return explicit > len(targets) * 0.5

    def _auto_classify(self, model: GenerationModel) -> Dict[str, str]:
        """Auto-classify tables into medallion layers based on naming patterns."""
        classifications = {}
        for table_name, table_info in model.table_registry.items():
            upper = table_name.upper()
            schema = table_info.get("owner", "").upper()

            # Check schema-based hints
            if "BRONZE" in schema or "RAW" in schema:
                classifications[table_name] = "BRONZE"
            elif "SILVER" in schema or "CLEANSED" in schema or "CDC" in schema:
                classifications[table_name] = "SILVER"
            elif "GOLD" in schema or "CONFORMED" in schema or "CURATED" in schema:
                classifications[table_name] = "GOLD"
            # Check table name patterns
            elif upper.startswith(("RAW_", "SRC_", "STG_")):
                classifications[table_name] = "BRONZE"
            elif upper.startswith(("LND_", "CDC_", "CLN_")):
                classifications[table_name] = "SILVER"
            elif upper.startswith(("DIM_", "FACT_", "RPT_", "C_")):
                classifications[table_name] = "GOLD"
            else:
                # Default: SOURCE tables → BRONZE, TARGET tables → SILVER
                if table_info.get("table_type") == "SOURCE":
                    classifications[table_name] = "BRONZE"
                else:
                    classifications[table_name] = "SILVER"

        return classifications

    def _apply_classifications(
        self, model: GenerationModel, classifications: Dict[str, str]
    ):
        """Apply layer classifications to the model's table registry."""
        for table_name, layer in classifications.items():
            if table_name in model.table_registry:
                schema = self.layer_schemas.get(layer.upper(), layer)
                model.table_registry[table_name]["owner"] = schema
                model.table_registry[table_name]["qualified_name"] = f"{schema}.{table_name}"
                model.table_registry[table_name]["medallion_layer"] = layer

    def _detect_strategies(
        self, model: GenerationModel, classifications: Dict[str, str]
    ) -> Dict[str, Dict[str, str]]:
        """Detect DML strategies based on layer and table info."""
        strategies = {}
        for table_name, table_info in model.table_registry.items():
            schema = table_info.get("owner", "PUBLIC")
            layer = classifications.get(table_name, "")

            if layer:
                # Explicit classification — use layer-based strategy
                # Bronze → INSERT, Silver → MERGE if PK, Gold → MERGE
                if layer == "BRONZE":
                    dml_strategy = "INSERT"
                elif layer == "GOLD":
                    dml_strategy = "MERGE"
                else:
                    dml_strategy = "MERGE" if table_info.get("primary_keys") else "INSERT"
            else:
                # No classification (schemas preserved) — infer from schema name and PKs
                schema_upper = schema.upper()
                if "BRONZE" in schema_upper or "RAW" in schema_upper:
                    dml_strategy = "INSERT"
                elif table_info.get("primary_keys"):
                    dml_strategy = "MERGE"
                else:
                    dml_strategy = "INSERT"

            strategies[table_name] = {
                "dml_strategy": dml_strategy,
                "schema": schema,
            }

        return strategies

    def _export(self, base_dir, ddl, dml, procs, infra_sql):
        files = []
        for a in ddl:
            p = save_sql(a["sql"], base_dir / "ddl" / f"{a['name'].lower()}.sql")
            files.append(str(p))
        for a in dml:
            p = save_sql(a["sql"], base_dir / "dml" / f"{a['name'].lower()}.sql")
            files.append(str(p))
        for a in procs:
            p = save_sql(a["sql"], base_dir / "procedures" / f"{a['name'].lower()}.sql")
            files.append(str(p))
        p = save_sql(infra_sql, base_dir / "infrastructure" / "procedure_log.sql")
        files.append(str(p))
        self.logger.info(f"  Exported {len(files)} files to {base_dir}")
        return files

    @staticmethod
    def _count_by_layer(artifacts):
        counts = {}
        for a in artifacts:
            layer = a.get("schema", "UNKNOWN")
            counts[layer] = counts.get(layer, 0) + 1
        return counts
