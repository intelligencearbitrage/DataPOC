"""
DML Generator — Generates INSERT and MERGE statements for target tables.
"""

import sys
from pathlib import Path
from typing import Any, Dict, List

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from converter.sttm_to_model import GenerationModel
from translation.field_mapper import FieldMapper
from templates.template_engine import TemplateEngine


class DmlGenerator:
    """Generates Snowflake DML (INSERT/MERGE) from a GenerationModel."""

    SKIP_KEYWORDS = ("INTERMEDIATE", "TEMP", "WORK", "STAGING", "TMP")

    def __init__(self, template_engine: TemplateEngine, database: str = "TARGET_DB"):
        self.engine = template_engine
        self.database = database
        self.field_mapper = FieldMapper(database=database)

    def generate(
        self,
        model: GenerationModel,
        table_strategies: Dict[str, Dict[str, str]],
    ) -> List[Dict[str, str]]:
        """Generate DML artifacts for all target tables.

        Args:
            model: Internal generation model
            table_strategies: {table_name: {dml_strategy, schema}}

        Returns list of {name, type, schema, sql} dicts.
        """
        artifacts = []

        for table_name, table_info in model.table_registry.items():
            if any(kw in table_name.upper() for kw in self.SKIP_KEYWORDS):
                continue
            if table_info.get("table_type") == "SOURCE":
                continue

            schema = table_info.get("owner", "PUBLIC")
            strategy = table_strategies.get(table_name, {})
            dml_strategy = strategy.get("dml_strategy", "INSERT")

            field_mappings, primary_source, from_clause = self.field_mapper.build_field_mappings(
                table_name, table_info, model.field_lineage, model.table_registry
            )

            if not primary_source:
                continue

            select_list = self.field_mapper.build_select_list(field_mappings)
            final_from = from_clause if from_clause else primary_source
            where_clause = table_info.get("where_clause", "")

            columns = list(table_info.get("columns", {}).keys())

            if dml_strategy == "MERGE":
                # Determine key columns
                key_cols = table_info.get("primary_keys", [])
                if not key_cols:
                    key_cols = [c for c in columns if "ID" in c.upper() or "KEY" in c.upper()]
                if not key_cols and columns:
                    key_cols = [columns[0]]
                update_cols = [c for c in columns if c not in key_cols]

                sql = self.engine.render_merge(
                    table_name, schema, select_list, final_from,
                    key_cols, update_cols, columns, where_clause,
                )
            else:
                sql = self.engine.render_insert(
                    table_name, schema, select_list, final_from, where_clause,
                )

            artifacts.append({
                "name": f"{table_name}_LOAD",
                "type": "DML",
                "schema": schema,
                "sql": sql,
            })

        return artifacts
