"""
Informatica XML Parser — Loads Informatica PowerMart workflow XML exports.

Parses SOURCE, TARGET, MAPPING, TRANSFORMATION, and CONNECTOR elements
from Informatica XML workflow files to extract source-to-target field mappings.

Handles:
  - Router transformations (output group suffix stripping: ADDR_ID1 -> ADDR_ID)
  - Mapplet instances (treated as passthrough transformations)
  - Joiner/Filter/Expression transformations (traced via connectors)
  - Update Strategy (sets DML to MERGE)
  - Source Qualifier passthrough

Each XML file produces one STTMSheet per MAPPING element found.
"""

import re
import sys
import defusedxml.ElementTree as ET
from pathlib import Path
from typing import Dict, List, Optional, Set, Tuple

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from base.base_parser import BaseParser
from parsers.sttm_model import STTMRow, STTMSheet, STTMInput


_INFA_DTYPE_MAP = {
    "bigint": "bigint",
    "integer": "integer",
    "int": "integer",
    "smallint": "smallint",
    "decimal": "decimal",
    "number": "number",
    "float": "float",
    "double": "double",
    "char": "char",
    "varchar": "varchar",
    "string": "varchar",
    "nchar": "nchar",
    "nvarchar": "nvarchar",
    "nstring": "nvarchar",
    "text": "varchar",
    "date": "date",
    "date/time": "timestamp",
    "timestamp": "timestamp",
    "binary": "binary",
    "long": "bigint",
    "short": "smallint",
}


def _normalize_dtype(raw: str) -> str:
    return _INFA_DTYPE_MAP.get(raw.lower().strip(), raw.upper().strip() or "VARCHAR")


class InformaticaXmlParser(BaseParser):
    """Parser for Informatica PowerMart XML workflow exports."""

    def discover_files(self) -> List[Path]:
        return sorted(self.input_dir.glob("*.xml"))

    def parse_file(self, file_path: Path) -> Dict:
        sttm_input = self.parse_to_sttm_input(file_path)
        return {
            "sheets": {s.name: s.row_count for s in sttm_input.sheets},
            "total_rows": sttm_input.total_rows,
        }

    def parse_to_sttm_input(self, file_path: Path) -> STTMInput:
        file_path = Path(file_path)
        tree = ET.parse(file_path)
        root = tree.getroot()

        sources = {}
        targets = {}

        for src in root.iter("SOURCE"):
            name = src.attrib.get("NAME", "")
            owner = src.attrib.get("OWNERNAME", "")
            dbtype = src.attrib.get("DATABASETYPE", "")
            fields = []
            for sf in src.findall("SOURCEFIELD"):
                fields.append({
                    "name": sf.attrib.get("NAME", ""),
                    "datatype": sf.attrib.get("DATATYPE", ""),
                    "precision": sf.attrib.get("PRECISION", ""),
                    "scale": sf.attrib.get("SCALE", "0"),
                })
            sources[name] = {"owner": owner, "db": dbtype, "fields": fields}

        for tgt in root.iter("TARGET"):
            name = tgt.attrib.get("NAME", "")
            owner = tgt.attrib.get("OWNERNAME", "")
            dbtype = tgt.attrib.get("DATABASETYPE", "")
            fields = []
            for tf in tgt.findall("TARGETFIELD"):
                fields.append({
                    "name": tf.attrib.get("NAME", ""),
                    "datatype": tf.attrib.get("DATATYPE", ""),
                    "precision": tf.attrib.get("PRECISION", ""),
                    "scale": tf.attrib.get("SCALE", "0"),
                    "pk": tf.attrib.get("KEYTYPE", "") == "PRIMARY KEY",
                    "nullable": tf.attrib.get("NULLABLE", "NULL") == "NULL",
                })
            targets[name] = {"owner": owner, "db": dbtype, "fields": fields}

        sheets: List[STTMSheet] = []

        for mapping in root.iter("MAPPING"):
            mapping_name = mapping.attrib.get("NAME", file_path.stem)
            rows = self._extract_mapping_rows(mapping, sources, targets)
            if rows:
                sheets.append(STTMSheet(name=mapping_name, rows=rows))

        if not sheets:
            rows = self._fallback_source_target_match(sources, targets, file_path.stem)
            if rows:
                sheets.append(STTMSheet(name=file_path.stem, rows=rows))

        return STTMInput(source_file=str(file_path), sheets=sheets)

    def _extract_mapping_rows(
        self, mapping, sources: Dict, targets: Dict,
    ) -> List[STTMRow]:
        """Extract STTMRows from a single MAPPING element by tracing connectors."""

        instances = {}
        for inst in mapping.findall("INSTANCE"):
            iname = inst.attrib.get("NAME", "")
            itype = inst.attrib.get("TRANSFORMATIONTYPE", inst.attrib.get("TYPE", ""))
            tname = inst.attrib.get("TRANSFORMATIONNAME", "")
            instances[iname] = {"type": itype, "tname": tname}

        transforms = {}
        router_field_map: Dict[str, Dict[str, str]] = {}

        for tx in mapping.findall("TRANSFORMATION"):
            tname = tx.attrib.get("NAME", "")
            ttype = tx.attrib.get("TYPE", "")
            fields = {}
            input_fields = []
            output_fields = []
            for tf in tx.findall("TRANSFORMFIELD"):
                fname = tf.attrib.get("NAME", "")
                expr = tf.attrib.get("EXPRESSION", "")
                porttype = tf.attrib.get("PORTTYPE", "")
                datatype = tf.attrib.get("DATATYPE", "")
                fields[fname] = {
                    "expression": expr,
                    "porttype": porttype,
                    "datatype": datatype,
                }
                pt = porttype.upper()
                if "INPUT" in pt and "OUTPUT" not in pt:
                    input_fields.append(fname)
                elif "OUTPUT" in pt and "INPUT" not in pt:
                    output_fields.append(fname)
            transforms[tname] = {"type": ttype, "fields": fields}

            # Router: map output fields (with group suffix) to input fields
            if ttype == "Router" and input_fields:
                rmap = {}
                input_set = set(input_fields)
                for ofield in output_fields:
                    base = re.sub(r"\d+$", "", ofield)
                    if base in input_set:
                        rmap[ofield] = base
                router_field_map[tname] = rmap

        conn_backward = {}
        for conn in mapping.findall("CONNECTOR"):
            fi = conn.attrib.get("FROMINSTANCE", "")
            ff = conn.attrib.get("FROMFIELD", "")
            ti = conn.attrib.get("TOINSTANCE", "")
            tf = conn.attrib.get("TOFIELD", "")
            conn_backward[(ti, tf)] = (fi, ff)

        target_instances = {}
        source_instances = {}

        for iname, info in instances.items():
            itype = info["type"].upper()
            ref_name = info["tname"] or iname

            if itype in ("TARGET", "TARGET DEFINITION"):
                resolved = self._resolve_instance_name(ref_name, targets, "Flat File")
                if resolved:
                    target_instances[iname] = resolved
            elif itype in ("SOURCE", "SOURCE DEFINITION"):
                resolved = self._resolve_instance_name(ref_name, sources, "Flat File")
                if resolved:
                    source_instances[iname] = resolved

        # Collect all target table names for self-reference detection
        all_target_tables = set(target_instances.values())

        # Identify alternative (non-target) source tables available in this mapping
        alt_sources: Dict[str, Tuple[str, str]] = {}  # src_name -> (name, schema)
        for src_inst_name, src_tbl_name in source_instances.items():
            if src_tbl_name not in all_target_tables:
                src_def = sources.get(src_tbl_name, {})
                alt_sources[src_tbl_name] = (src_tbl_name, src_def.get("owner", ""))

        rows: List[STTMRow] = []

        for tgt_inst, tgt_table_name in target_instances.items():
            tgt_def = targets[tgt_table_name]
            tgt_owner = tgt_def["owner"]
            pk_fields = {f["name"] for f in tgt_def["fields"] if f["pk"]}

            for tgt_field_def in tgt_def["fields"]:
                tgt_field_name = tgt_field_def["name"]

                source_info = self._trace_to_source(
                    tgt_inst, tgt_field_name,
                    conn_backward, instances, transforms,
                    source_instances, sources,
                    router_field_map,
                )

                src_table = source_info.get("source_table", "")
                src_field = source_info.get("source_field", "")
                src_schema = source_info.get("source_schema", "")
                src_datatype = source_info.get("source_datatype", "")
                src_precision = source_info.get("source_precision", "")
                transformation = source_info.get("expression", "")
                dml_op = source_info.get("dml_operation", "INSERT")

                # Fix 3: When source datatype is empty (dead-end trace), use
                # the target field's own XML datatype instead of defaulting to VARCHAR
                if not src_datatype:
                    src_datatype = tgt_field_def.get("datatype", "")
                    src_precision = tgt_field_def.get("precision", "")

                if not transformation or transformation == src_field:
                    transformation_logic = src_field or tgt_field_name
                else:
                    transformation_logic = transformation

                rows.append(STTMRow(
                    source_table=src_table,
                    source_schema=src_schema,
                    source_attribute=src_field or tgt_field_name,
                    source_datatype=_normalize_dtype(src_datatype),
                    source_datatype_length=src_precision,
                    target_table=tgt_table_name,
                    target_schema=tgt_owner,
                    target_attribute=tgt_field_name,
                    target_datatype=_normalize_dtype(tgt_field_def["datatype"]),
                    target_datatype_length=tgt_field_def.get("precision", ""),
                    transformation_logic=transformation_logic,
                    transformation_explanation=f"Informatica mapping: {source_info.get('path', '')}",
                    dml_operation=dml_op,
                    is_primary_key=tgt_field_name in pk_fields,
                ))

        # Fix 1: Resolve self-referencing DMLs
        # When source_table == target_table (e.g. SCD-2 patterns where the mapping
        # reads from and writes to the same table), replace with an alternative
        # source from this mapping that is NOT a target table.
        if alt_sources:
            for i, row in enumerate(rows):
                if row.source_table and row.source_table == row.target_table:
                    best = self._pick_alt_source(
                        row.target_table, row.source_attribute, alt_sources, sources
                    )
                    if best:
                        stg_name, stg_schema, stg_dtype, stg_prec = best
                        rows[i] = STTMRow(
                            source_table=stg_name,
                            source_schema=stg_schema,
                            source_attribute=row.source_attribute,
                            source_datatype=stg_dtype or row.source_datatype,
                            source_datatype_length=stg_prec or row.source_datatype_length,
                            target_table=row.target_table,
                            target_schema=row.target_schema,
                            target_attribute=row.target_attribute,
                            target_datatype=row.target_datatype,
                            target_datatype_length=row.target_datatype_length,
                            transformation_logic=row.transformation_logic,
                            transformation_explanation=row.transformation_explanation,
                            dml_operation=row.dml_operation,
                            is_primary_key=row.is_primary_key,
                        )

        return rows

    @staticmethod
    def _pick_alt_source(
        target_table: str,
        field_name: str,
        alt_sources: Dict[str, Tuple[str, str]],
        sources: Dict,
    ) -> Optional[Tuple[str, str, str, str]]:
        """Pick the best alternative source for a self-referencing row.

        Returns (source_name, schema, datatype, precision) or None.
        Prefers a source whose name contains the target table name (substring match),
        falling back to the first available alternative source.
        """
        target_upper = target_table.upper()

        # Score candidates: prefer sources whose name contains the target name
        scored: List[Tuple[int, str, str]] = []
        for src_name, (name, schema) in alt_sources.items():
            score = 2 if target_upper in src_name.upper() else 1
            scored.append((score, name, schema))
        scored.sort(key=lambda x: -x[0])

        if not scored:
            return None

        _, best_name, best_schema = scored[0]
        # Look up field datatype in the chosen source
        src_def = sources.get(best_name, {})
        dtype, prec = "", ""
        for sf in src_def.get("fields", []):
            if sf["name"] == field_name:
                dtype = _normalize_dtype(sf["datatype"])
                prec = sf.get("precision", "")
                break
        return (best_name, best_schema, dtype, prec)

    @staticmethod
    def _resolve_instance_name(
        inst_name: str, definitions: Dict, exclude_db: str,
    ) -> Optional[str]:
        candidates = [inst_name]
        stripped = inst_name
        # Strip common Informatica shortcut prefixes: sc_, sc_to_, to_
        for prefix in ["sc_to_", "sc_", "to_"]:
            if stripped.lower().startswith(prefix):
                stripped = stripped[len(prefix):]
                candidates.append(stripped)
                break

        for suffix_re in [r"_HIST$", r"_CURR$", r"_DEL$", r"\d+$"]:
            cleaned = re.sub(suffix_re, "", stripped)
            if cleaned != stripped:
                candidates.append(cleaned)

        for cand in candidates:
            if cand in definitions and definitions[cand].get("db", "") != exclude_db:
                return cand
        return None

    def _trace_to_source(
        self,
        instance: str,
        field: str,
        conn_backward: Dict,
        instances: Dict,
        transforms: Dict,
        source_instances: Dict,
        sources: Dict,
        router_field_map: Dict,
        depth: int = 0,
    ) -> Dict:
        """Trace a field backward through connectors to find its source."""
        if depth > 25:
            return self._dead_end(field)

        # Check if this instance is a source
        if instance in source_instances:
            src_name = source_instances[instance]
            src_def = sources.get(src_name, {})
            src_owner = src_def.get("owner", "")
            src_dtype = ""
            src_prec = ""
            for sf in src_def.get("fields", []):
                if sf["name"] == field:
                    src_dtype = sf["datatype"]
                    src_prec = sf.get("precision", "")
                    break
            return {
                "source_table": src_name,
                "source_field": field,
                "source_schema": src_owner,
                "source_datatype": src_dtype,
                "source_precision": src_prec,
                "expression": field,
                "path": f"{instance}.{field}",
                "dml_operation": "INSERT",
            }

        inst_info = instances.get(instance, {})
        inst_type_raw = inst_info.get("type", "")
        tname = inst_info.get("tname", "") or instance
        tx_def = transforms.get(tname, transforms.get(instance, {}))
        tx_type = tx_def.get("type", inst_type_raw)

        expression = ""
        dml_op = "INSERT"

        if tx_def and "fields" in tx_def:
            tx_fields = tx_def["fields"]
            if field in tx_fields:
                expression = tx_fields[field].get("expression", "")

        if tx_type in ("Update Strategy", "Router"):
            dml_op = "MERGE"

        # Router: resolve output field to input field name
        lookup_field = field
        rmap = router_field_map.get(tname, router_field_map.get(instance, {}))
        if rmap and field in rmap:
            lookup_field = rmap[field]

        # Try backward connector (exact field, then Router-resolved field)
        key = (instance, field)
        alt_key = (instance, lookup_field) if lookup_field != field else None

        prev = conn_backward.get(key)
        if prev is None and alt_key:
            prev = conn_backward.get(alt_key)

        if prev is not None:
            prev_inst, prev_field = prev
            result = self._trace_to_source(
                prev_inst, prev_field,
                conn_backward, instances, transforms,
                source_instances, sources,
                router_field_map,
                depth + 1,
            )
            if expression and expression != field and expression != lookup_field and expression != prev_field:
                result["expression"] = expression
            result["path"] = f"{instance}.{field} <- {result.get('path', '')}"
            if dml_op == "MERGE":
                result["dml_operation"] = "MERGE"
            return result

        # Mapplet handling: opaque subflows
        if inst_type_raw.upper() == "MAPPLET":
            for out_prefix in ["o_", "out_"]:
                if field.startswith(out_prefix):
                    base = field[len(out_prefix):]
                    for in_prefix in ["in_", ""]:
                        in_key = (instance, in_prefix + base)
                        prev = conn_backward.get(in_key)
                        if prev:
                            result = self._trace_to_source(
                                prev[0], prev[1],
                                conn_backward, instances, transforms,
                                source_instances, sources,
                                router_field_map,
                                depth + 1,
                            )
                            result["path"] = f"{instance}.{field}(mapplet) <- {result.get('path', '')}"
                            return result

            # Last resort: use any input connector for this mapplet
            for (ti, tf_name), (fi, ff) in conn_backward.items():
                if ti == instance:
                    result = self._trace_to_source(
                        fi, ff,
                        conn_backward, instances, transforms,
                        source_instances, sources,
                        router_field_map,
                        depth + 1,
                    )
                    result["path"] = f"{instance}.{field}(mapplet) <- {result.get('path', '')}"
                    return result

        return self._dead_end(field, expression, instance, dml_op)

    @staticmethod
    def _dead_end(
        field: str,
        expression: str = "",
        instance: str = "",
        dml_op: str = "INSERT",
    ) -> Dict:
        return {
            "source_table": "",
            "source_field": field,
            "source_schema": "",
            "source_datatype": "",
            "source_precision": "",
            "expression": expression or field,
            "path": f"{instance}.{field}" if instance else field,
            "dml_operation": dml_op,
        }

    def _fallback_source_target_match(
        self, sources: Dict, targets: Dict, file_stem: str,
    ) -> List[STTMRow]:
        rows = []
        real_sources = {k: v for k, v in sources.items() if v["db"] != "Flat File"}
        real_targets = {k: v for k, v in targets.items() if v["db"] != "Flat File"}

        for tgt_name, tgt_def in real_targets.items():
            tgt_owner = tgt_def["owner"]
            pk_fields = {f["name"] for f in tgt_def["fields"] if f["pk"]}

            best_src_name = ""
            best_src_def = None
            for src_name, src_def in real_sources.items():
                if best_src_def is None:
                    best_src_name = src_name
                    best_src_def = src_def

            if not best_src_def:
                continue

            src_field_names = {f["name"] for f in best_src_def["fields"]}

            for tgt_field in tgt_def["fields"]:
                fname = tgt_field["name"]
                src_field = fname if fname in src_field_names else ""

                rows.append(STTMRow(
                    source_table=best_src_name,
                    source_schema=best_src_def.get("owner", ""),
                    source_attribute=src_field or fname,
                    target_table=tgt_name,
                    target_schema=tgt_owner,
                    target_attribute=fname,
                    target_datatype=_normalize_dtype(tgt_field["datatype"]),
                    target_datatype_length=tgt_field.get("precision", ""),
                    transformation_logic=src_field or "NULL",
                    dml_operation="INSERT",
                    is_primary_key=fname in pk_fields,
                ))

        return rows


def main():
    parser = InformaticaXmlParser(input_dir="inputs", output_dir="output")
    files = parser.discover_files()
    if not files:
        print("No XML files found in inputs/")
        return
    for f in files:
        sttm_input = parser.parse_to_sttm_input(f)
        print(f"{f.name}: {sttm_input.total_rows} rows across {sttm_input.sheet_names}")
        for sheet in sttm_input.sheets:
            print(f"  {sheet.name}: {sheet.row_count} rows, targets: {sheet.target_tables}")


if __name__ == "__main__":
    main()
