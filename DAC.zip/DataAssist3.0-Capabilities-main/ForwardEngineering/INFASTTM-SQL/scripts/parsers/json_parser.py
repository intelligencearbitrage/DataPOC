"""
JSON/CSV STTM Parser — Loads standard STTM files in JSON or CSV format.

Expected JSON format: Array of objects with keys:
    Source_Table, Source_Attribute, Transformation_Logic,
    Transformation_Explanation, Target_Table, Target_Attribute,
    DML_Operation, Filter_Conditions, Join_Conditions

Expected CSV format: Same column headers as JSON keys.
"""

import csv
import json
import sys
from pathlib import Path
from typing import Dict, List

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from base.base_parser import BaseParser
from parsers.sttm_model import STTMRow, STTMSheet, STTMInput

EXPECTED_COLS = [
    "Source_Table", "Source_Attribute", "Transformation_Logic",
    "Transformation_Explanation", "Target_Table", "Target_Attribute",
    "DML_Operation", "Filter_Conditions", "Join_Conditions",
]


class JsonSttmParser(BaseParser):
    """Parser for JSON and CSV STTM files."""

    def discover_files(self) -> List[Path]:
        json_files = sorted(self.input_dir.glob("*.json"))
        csv_files = sorted(self.input_dir.glob("*.csv"))
        return json_files + csv_files

    def parse_file(self, file_path: Path) -> Dict:
        suffix = file_path.suffix.lower()
        if suffix == ".json":
            rows = self._load_json(file_path)
        elif suffix == ".csv":
            rows = self._load_csv(file_path)
        else:
            raise ValueError(f"Unsupported format: {suffix}")

        sttm_rows = [self._to_sttm_row(r) for r in rows]
        return {"rows": sttm_rows, "count": len(sttm_rows)}

    def parse_to_sttm_input(self, file_path: Path) -> STTMInput:
        """Parse file into STTMInput model."""
        file_path = Path(file_path)
        result = self.parse_file(file_path)
        sheet = STTMSheet(
            name=file_path.stem.replace("_STTM", ""),
            rows=result["rows"],
        )
        return STTMInput(source_file=str(file_path), sheets=[sheet])

    def _load_json(self, file_path: Path) -> List[Dict]:
        with open(file_path, "r", encoding="utf-8") as f:
            return json.load(f)

    def _load_csv(self, file_path: Path) -> List[Dict]:
        rows = []
        with open(file_path, "r", encoding="utf-8-sig") as f:
            reader = csv.DictReader(f)
            for row in reader:
                normalized = {}
                for col in EXPECTED_COLS:
                    if col in row:
                        normalized[col] = row[col] or ""
                    else:
                        for k, v in row.items():
                            if k.strip().replace(" ", "_").lower() == col.lower():
                                normalized[col] = v or ""
                                break
                        else:
                            normalized[col] = ""
                rows.append(normalized)
        return rows

    def _to_sttm_row(self, raw: Dict) -> STTMRow:
        """Convert a raw dict to a normalized STTMRow."""
        src_full = raw.get("Source_Table", "").strip()
        tgt_full = raw.get("Target_Table", "").strip()

        src_schema, src_table = self._split_qualified(src_full)
        tgt_schema, tgt_table = self._split_qualified(tgt_full)

        return STTMRow(
            source_table=src_table,
            source_schema=src_schema,
            source_attribute=raw.get("Source_Attribute", "").strip(),
            target_table=tgt_table,
            target_schema=tgt_schema,
            target_attribute=raw.get("Target_Attribute", "").strip(),
            transformation_logic=raw.get("Transformation_Logic", "").strip(),
            transformation_explanation=raw.get("Transformation_Explanation", "").strip(),
            dml_operation=raw.get("DML_Operation", "INSERT").strip() or "INSERT",
            filter_conditions=raw.get("Filter_Conditions", "").strip(),
            join_conditions=raw.get("Join_Conditions", "").strip(),
        )

    @staticmethod
    def _split_qualified(name: str):
        """Split 'SCHEMA.TABLE' into (schema, table). Returns ('', name) if no dot."""
        if "." in name:
            parts = name.split(".", 1)
            return parts[0], parts[1]
        return "", name


def main():
    parser = JsonSttmParser(input_dir="inputs", output_dir="output")
    files = parser.discover_files()
    if not files:
        print("No JSON/CSV files found in inputs/")
        return
    for f in files:
        sttm_input = parser.parse_to_sttm_input(f)
        for sheet in sttm_input.sheets:
            print(f"  {sheet.name}: {sheet.row_count} rows, targets: {sheet.target_tables}")


if __name__ == "__main__":
    main()
