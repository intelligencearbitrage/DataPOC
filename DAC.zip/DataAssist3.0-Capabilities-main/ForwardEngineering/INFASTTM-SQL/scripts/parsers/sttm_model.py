"""
STTM Data Model — Common contract between parsers and the converter.

All parsers (JSON, Excel, CSV) normalize their input into these dataclasses.
The converter then transforms STTMInput into the internal generation model.
"""

from dataclasses import dataclass, field
from typing import List, Optional


@dataclass
class STTMRow:
    """A single row of Source-To-Target Mapping data.

    This is the universal format that all parsers must produce,
    regardless of whether the input is JSON, CSV, or Excel.
    """

    source_table: str = ""
    source_attribute: str = ""
    source_schema: str = ""
    source_database: str = ""
    source_datatype: str = ""
    source_datatype_length: str = ""

    target_table: str = ""
    target_attribute: str = ""
    target_schema: str = ""
    target_database: str = ""
    target_datatype: str = ""
    target_datatype_length: str = ""

    transformation_logic: str = ""
    transformation_explanation: str = ""
    mapping_name: str = ""

    dml_operation: str = "INSERT"
    filter_conditions: str = ""
    join_conditions: str = ""

    is_primary_key: bool = False

    @property
    def source_qualified(self) -> str:
        """Fully qualified source: SCHEMA.TABLE or just TABLE."""
        if self.source_schema and self.source_table:
            return f"{self.source_schema}.{self.source_table}"
        return self.source_table

    @property
    def target_qualified(self) -> str:
        """Fully qualified target: SCHEMA.TABLE or just TABLE."""
        if self.target_schema and self.target_table:
            return f"{self.target_schema}.{self.target_table}"
        return self.target_table

    def is_unmapped(self) -> bool:
        """Check if this row represents an unmapped/null field."""
        _unmapped = {"not mapped", "unmapped", "n/a", "null", "none", ""}
        return self.transformation_logic.lower().strip() in _unmapped


@dataclass
class STTMSheet:
    """A named group of STTM rows (one Excel sheet or one JSON file)."""

    name: str
    rows: List[STTMRow] = field(default_factory=list)

    @property
    def row_count(self) -> int:
        return len(self.rows)

    @property
    def target_tables(self) -> List[str]:
        """Unique target tables in this sheet."""
        seen = []
        for r in self.rows:
            tgt = r.target_qualified
            if tgt and tgt not in seen:
                seen.append(tgt)
        return seen


@dataclass
class STTMInput:
    """Top-level container for all parsed STTM data.

    One STTMInput per input file. May contain multiple sheets
    (Excel tabs) or a single sheet (JSON/CSV).
    """

    source_file: str
    sheets: List[STTMSheet] = field(default_factory=list)

    @property
    def total_rows(self) -> int:
        return sum(s.row_count for s in self.sheets)

    @property
    def sheet_names(self) -> List[str]:
        return [s.name for s in self.sheets]
