"""
Excel STTM Parser — Loads STTM files in Excel format.

Supports two formats:
  1. Standard STTM: Single-row header with Source_Table, Target_Table, etc.
  2. RCC (Future State): Two-row merged header with group headers
     (SOR | Source{Database,Schema,Table,Field,...} | Transformation | Target{...})

The parser auto-detects the format by inspecting the first two rows.
"""

import re
import sys
from pathlib import Path
from typing import Dict, List, Optional, Tuple

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from base.base_parser import BaseParser
from parsers.sttm_model import STTMRow, STTMSheet, STTMInput


class ExcelSttmParser(BaseParser):
    """Parser for Excel STTM files (standard and RCC formats)."""

    EXPECTED_COLS = [
        "Source_Table", "Source_Attribute", "Transformation_Logic",
        "Transformation_Explanation", "Target_Table", "Target_Attribute",
        "DML_Operation", "Filter_Conditions", "Join_Conditions",
    ]

    def discover_files(self) -> List[Path]:
        xlsx = sorted(self.input_dir.glob("*.xlsx"))
        xls = sorted(self.input_dir.glob("*.xls"))
        return xlsx + xls

    def parse_file(self, file_path: Path) -> Dict:
        sttm_input = self.parse_to_sttm_input(file_path)
        return {
            "sheets": {s.name: s.row_count for s in sttm_input.sheets},
            "total_rows": sttm_input.total_rows,
        }

    def parse_to_sttm_input(self, file_path: Path) -> STTMInput:
        """Parse Excel file into STTMInput model."""
        import openpyxl

        file_path = Path(file_path)
        wb = openpyxl.load_workbook(file_path, read_only=True, data_only=True)
        sheets: List[STTMSheet] = []

        for sheet_name in wb.sheetnames:
            ws = wb[sheet_name]
            rows_iter = ws.iter_rows(values_only=True)

            try:
                row1 = next(rows_iter)
            except StopIteration:
                continue
            try:
                row2 = next(rows_iter)
            except StopIteration:
                continue

            if self._detect_rcc_format(row1, row2):
                sttm_rows = self._parse_rcc_sheet(row1, row2, rows_iter)
            else:
                sttm_rows = self._parse_standard_sheet(row1, row2, rows_iter)

            if sttm_rows:
                sheets.append(STTMSheet(name=sheet_name, rows=sttm_rows))

        wb.close()
        return STTMInput(source_file=str(file_path), sheets=sheets)

    # ── Format detection ──────────────────────────────────────────────

    @staticmethod
    def _detect_rcc_format(row1, row2) -> bool:
        """Detect RCC-style two-row merged header format."""
        r1 = [str(c).strip().lower() if c else "" for c in row1]
        r2 = [str(c).strip().lower() if c else "" for c in row2]
        return (
            "source" in r1
            and "target" in r1
            and r2.count("database") >= 2
            and r2.count("table") >= 2
            and r2.count("field") >= 2
        )

    # ── RCC format parsing ────────────────────────────────────────────

    def _parse_rcc_sheet(self, row1, row2, rows_iter) -> List[STTMRow]:
        """Parse a sheet in RCC two-row header format."""
        r1 = [str(c).strip().lower() if c else "" for c in row1]

        src_start = r1.index("source") if "source" in r1 else 1
        trans_start = next(
            (i for i, v in enumerate(r1) if v == "transformation" and i > src_start),
            None,
        )
        tgt_start = next(
            (i for i, v in enumerate(r1) if v == "target" and i > (trans_start or src_start)),
            None,
        )
        if trans_start is None or tgt_start is None:
            return []

        ci = {
            "src_database": src_start,
            "src_schema": src_start + 1,
            "src_table": src_start + 2,
            "src_field": src_start + 3,
            "src_datatype": src_start + 4,
            "src_datatype_len": src_start + 5,
            "mapping_name": trans_start,
            "transformation": trans_start + 1,
            "tgt_database": tgt_start,
            "tgt_schema": tgt_start + 1,
            "tgt_table": tgt_start + 2,
            "tgt_field": tgt_start + 3,
            "tgt_datatype": tgt_start + 4,
            "tgt_datatype_len": tgt_start + 5,
        }

        # Detect Is_Primary_Key column from row 2
        r2_lower = [str(c).strip().lower() if c else "" for c in row2]
        pk_idx = None
        for i, h in enumerate(r2_lower):
            if h.replace(" ", "_") in ("is_primary_key", "isprimarykey", "primary_key"):
                pk_idx = i
                break

        def _cell(row, key):
            idx = ci.get(key, -1)
            if 0 <= idx < len(row) and row[idx] is not None:
                return str(row[idx]).strip()
            return ""

        rows: List[STTMRow] = []
        for row in rows_iter:
            tgt_table = _cell(row, "tgt_table")
            tgt_field = _cell(row, "tgt_field")
            src_table = _cell(row, "src_table")
            src_field = _cell(row, "src_field")

            if not tgt_table and not tgt_field and not src_table:
                continue

            # Clean multi-line cells
            if "\n" in src_table:
                src_table = src_table.split("\n")[0].strip()
            if "\n" in tgt_table:
                tgt_table = tgt_table.split("\n")[0].strip()

            # Multiple comma-separated source tables — use first
            if "," in src_table:
                src_table = src_table.split(",")[0].strip()

            # Parse transformation for embedded JOIN / FILTER
            raw_transform = _cell(row, "transformation")
            logic, join_cond, filter_cond = self._parse_rcc_transformation(raw_transform)

            # Detect CDC Router pattern
            dml_op = "INSERT"
            if "Router Condition" in raw_transform:
                logic, dml_op = self._normalize_cdc_router(raw_transform, src_field)

            # Primary key detection
            is_pk = False
            if pk_idx is not None and pk_idx < len(row) and row[pk_idx] is not None:
                is_pk = str(row[pk_idx]).strip().upper() in ("TRUE", "YES", "1", "Y")

            rows.append(STTMRow(
                source_table=src_table,
                source_schema=_cell(row, "src_schema"),
                source_database=_cell(row, "src_database"),
                source_attribute=src_field,
                source_datatype=_cell(row, "src_datatype"),
                source_datatype_length=_cell(row, "src_datatype_len"),
                target_table=tgt_table,
                target_schema=_cell(row, "tgt_schema"),
                target_database=_cell(row, "tgt_database"),
                target_attribute=tgt_field,
                target_datatype=_cell(row, "tgt_datatype"),
                target_datatype_length=_cell(row, "tgt_datatype_len"),
                transformation_logic=logic or raw_transform,
                transformation_explanation=_cell(row, "mapping_name"),
                mapping_name=_cell(row, "mapping_name"),
                dml_operation=dml_op,
                filter_conditions=filter_cond,
                join_conditions=join_cond,
                is_primary_key=is_pk,
            ))

        return rows

    # ── Standard format parsing ───────────────────────────────────────

    def _parse_standard_sheet(self, row1, row2, rows_iter) -> List[STTMRow]:
        """Parse a sheet with standard single-row STTM headers."""
        header = [str(h).strip() if h else "" for h in row1]

        col_map = {}
        for idx, h in enumerate(header):
            for col in self.EXPECTED_COLS:
                if h.replace(" ", "_").lower() == col.lower() or h.lower() == col.lower():
                    col_map[idx] = col
                    break

        if not col_map:
            return []

        rows: List[STTMRow] = []
        # row2 was consumed for detection — include as data
        for data_row in [row2] + list(rows_iter):
            raw = {col: "" for col in self.EXPECTED_COLS}
            for idx, col_name in col_map.items():
                if idx < len(data_row) and data_row[idx] is not None:
                    raw[col_name] = str(data_row[idx]).strip()
            if not any(raw[c] for c in ["Source_Table", "Target_Table", "Target_Attribute"]):
                continue

            src_full = raw.get("Source_Table", "")
            tgt_full = raw.get("Target_Table", "")
            src_schema, src_table = self._split_qualified(src_full)
            tgt_schema, tgt_table = self._split_qualified(tgt_full)

            rows.append(STTMRow(
                source_table=src_table,
                source_schema=src_schema,
                source_attribute=raw.get("Source_Attribute", ""),
                target_table=tgt_table,
                target_schema=tgt_schema,
                target_attribute=raw.get("Target_Attribute", ""),
                transformation_logic=raw.get("Transformation_Logic", ""),
                transformation_explanation=raw.get("Transformation_Explanation", ""),
                dml_operation=raw.get("DML_Operation", "INSERT") or "INSERT",
                filter_conditions=raw.get("Filter_Conditions", ""),
                join_conditions=raw.get("Join_Conditions", ""),
            ))

        return rows

    # ── RCC transformation helpers ────────────────────────────────────

    @staticmethod
    def _parse_rcc_transformation(text: str) -> Tuple[str, str, str]:
        """Parse RCC transformation text, extracting logic, join, and filter.

        Splits on '| JOIN:' and '| FILTER:' markers.
        Returns (logic, join_conditions, filter_conditions).
        """
        if not text:
            return "", "", ""

        logic, join_cond, filter_cond = text, "", ""
        ji = text.find("| JOIN:")
        fi = text.find("| FILTER:")

        if ji >= 0 and fi >= 0:
            if ji < fi:
                logic = text[:ji].strip()
                join_cond = text[ji + 7 : fi].strip().rstrip("|").strip()
                filter_cond = text[fi + 9 :].strip()
            else:
                logic = text[:fi].strip()
                filter_cond = text[fi + 9 : ji].strip().rstrip("|").strip()
                join_cond = text[ji + 7 :].strip()
        elif ji >= 0:
            logic = text[:ji].strip()
            join_cond = text[ji + 7 :].strip()
        elif fi >= 0:
            logic = text[:fi].strip()
            filter_cond = text[fi + 9 :].strip()

        if logic.startswith("[RESOLVED]"):
            logic = logic[len("[RESOLVED]") :].strip()

        return logic, join_cond, filter_cond

    @staticmethod
    def _normalize_cdc_router(text: str, src_field: str) -> Tuple[str, str]:
        """Parse CDC Router transformation and extract actual source field.

        Returns (normalized_expression, dml_operation).
        """
        # Direct Passthrough of L_FIELDNAME in the I/U block
        iu_match = re.search(
            r"Router Condition.*?IN\s*\(\s*FLAG\s*,.*?'[IU]'.*?\).*?"
            r"Direct Passthrough of\s+(\w+)",
            text,
            re.DOTALL | re.IGNORECASE,
        )
        if iu_match:
            field_name = iu_match.group(1)
            if field_name.upper().startswith("L_"):
                field_name = field_name[2:]
            if field_name.upper() == src_field.upper():
                return src_field, "MERGE"
            return field_name, "MERGE"

        # Non-passthrough patterns (Defaulted, Unmapped)
        default_match = re.search(
            r"Router Condition.*?IN\s*\(\s*FLAG\s*,.*?'[IU]'.*?\).*?"
            r"Logic:\s*\n?\s*(\w+)",
            text,
            re.DOTALL | re.IGNORECASE,
        )
        if default_match:
            word = default_match.group(1).strip()
            if word.upper() in ("DEFAULTED", "UNMAPPED", "NOT"):
                return "NULL", "MERGE"

        return src_field, "MERGE"

    @staticmethod
    def _split_qualified(name: str) -> Tuple[str, str]:
        if "." in name:
            parts = name.split(".", 1)
            return parts[0], parts[1]
        return "", name


def main():
    parser = ExcelSttmParser(input_dir="inputs", output_dir="output")
    files = parser.discover_files()
    if not files:
        print("No Excel files found in inputs/")
        return
    for f in files:
        sttm_input = parser.parse_to_sttm_input(f)
        print(f"{f.name}: {sttm_input.total_rows} rows across {sttm_input.sheet_names}")
        for sheet in sttm_input.sheets:
            print(f"  {sheet.name}: {sheet.row_count} rows")


if __name__ == "__main__":
    main()
