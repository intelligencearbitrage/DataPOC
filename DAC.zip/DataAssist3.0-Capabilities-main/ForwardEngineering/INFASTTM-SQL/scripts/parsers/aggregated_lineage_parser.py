"""
Aggregated Lineage Parser — Loads _aggregated_lineage.json files produced by the
Informatica Reverse Engineering agent.

Each JSON file contains:
  - metadata, table_registry, field_lineage[], transformation_metadata, etc.

The field_lineage array is the STTM: each entry maps one source field to one
target field, with transformation chain, update strategy, filter/join/router info.
"""

import json
import os
import re
import sys
from collections import defaultdict
from pathlib import Path
from typing import Dict, List, Optional, Tuple

from werkzeug.utils import safe_join

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from base.base_parser import BaseParser
from parsers.sttm_model import STTMRow, STTMSheet, STTMInput

_PARSER_ROOT = str(Path(__file__).resolve().parent.parent)


# Update strategy mapping: Informatica → DML operation
_STRATEGY_MAP = {
    "DD_INSERT": "INSERT",
    "DD_UPDATE": "MERGE",
    "DD_DELETE": "DELETE",
    "DD_REJECT": "INSERT",
    "0": "INSERT",
    "": "INSERT",
}

# Skip these mapping names — utility/dummy mappings, not real data flows
_SKIP_MAPPINGS = {"m_DUMMY", "m_ERROR_LOG_TYPE_2_CHECK"}

# Skip target paths that are file outputs, not database tables
_SKIP_TARGET_PREFIXES = ("$PM", "/opt/", "/tmp/")

# Source table names that are NOT real tables — markers for hardcoded expressions
_HARDCODED_SOURCES = {"HARD CODED VALUE", "HARDCODED", "CONSTANT"}


def _split_qualified(name: str) -> Tuple[str, str]:
    """Split 'SCHEMA.TABLE' into (schema, table). Returns ('', name) if no dot."""
    if "." in name:
        parts = name.rsplit(".", 1)
        return parts[0], parts[1]
    return "", name


def _parse_datatype(raw: str) -> Tuple[str, str]:
    """Parse 'bigint(19)' into ('bigint', '19') or 'varchar' into ('varchar', '')."""
    if not raw:
        return "", ""
    m = re.match(r"^(\w+)\(([^)]+)\)$", raw.strip())
    if m:
        return m.group(1), m.group(2)
    return raw.strip(), ""


def _clean_router_condition(cond: str) -> str:
    """Strip router group name prefix and clean multi-line conditions.

    Input: 'DELETE_CURR: LTRIM(RTRIM(X))=''U''\\r\\n OR \\r\\nLTRIM(RTRIM(X))=''D'''
    Output: 'LTRIM(RTRIM(X))=''U'' OR LTRIM(RTRIM(X))=''D'''
    """
    if not cond:
        return ""
    # Strip "GROUP_NAME: " prefix at the start
    cleaned = re.sub(r"^[A-Z_]+\d*\s*:\s*", "", cond.strip(), flags=re.IGNORECASE)

    # Strip SQL comment lines BEFORE normalizing newlines
    # A "--" comments out everything until the next newline
    lines = re.split(r"\r?\n", cleaned)
    clean_lines = []
    for line in lines:
        stripped = line.strip()
        if stripped.startswith("--"):
            continue  # Drop entire commented-out line
        if stripped:
            clean_lines.append(stripped)
    cleaned = " ".join(clean_lines)

    # Normalize whitespace
    cleaned = re.sub(r"\s+", " ", cleaned).strip()

    # If entirely empty after comment stripping, return empty
    if not cleaned:
        return ""

    # Strip "DEFAULT" keyword (Informatica router default group marker, not valid SQL)
    cleaned = re.sub(r"^\s*DEFAULT\s*$", "", cleaned, flags=re.IGNORECASE).strip()
    cleaned = re.sub(r"^\s*DEFAULT\s+AND\s+", "", cleaned, flags=re.IGNORECASE).strip()

    # Fix "OR OR" → "OR" (broken concatenation from multiple router groups)
    cleaned = re.sub(r"\bOR\s+OR\b", "OR", cleaned, flags=re.IGNORECASE)

    # Fix missing operator between adjacent conditions: "X='A' Y='B'" → "X='A' OR Y='B'"
    # Only insert OR when there's no existing OR/AND between the conditions
    # Use lookbehind to ensure we're after a quoted value, not after OR/AND
    cleaned = re.sub(
        r"(?<=['\"])\s+(?!OR\b|AND\b)((?:DW_ACTION_IND|TGT_STG_DW_ACTION_IND)\s*=)",
        r" OR \1",
        cleaned,
        flags=re.IGNORECASE,
    )

    # Strip leading/trailing OR/AND left dangling after cleanup
    cleaned = re.sub(r"^\s*(?:OR|AND)\s+", "", cleaned, flags=re.IGNORECASE).strip()
    cleaned = re.sub(r"\s+(?:OR|AND)\s*$", "", cleaned, flags=re.IGNORECASE).strip()

    # Translate Informatica IN(col,val,...) → col IN (val,...)
    cleaned = re.sub(
        r"\bIN\s*\(\s*(\w+)\s*,\s*",
        r"\1 IN (",
        cleaned,
        flags=re.IGNORECASE,
    )

    return cleaned


def _clean_filter_condition(cond: str) -> str:
    """Clean filter_condition values from aggregated lineage.

    Handles multi-line conditions with embedded comments and TRUE placeholders.
    """
    if not cond:
        return ""

    # Strip SQL comment lines BEFORE normalizing newlines
    lines = re.split(r"\r?\n", cond.strip())
    clean_lines = []
    for line in lines:
        stripped = line.strip()
        if stripped.startswith("--"):
            continue
        if stripped:
            clean_lines.append(stripped)
    cleaned = " ".join(clean_lines)
    cleaned = re.sub(r"\s+", " ", cleaned).strip()

    # Strip "TRUE" placeholder followed by commented-out real condition
    cleaned = re.sub(r"^\s*TRUE\s+--.*$", "", cleaned, flags=re.IGNORECASE).strip()

    if not cleaned:
        return ""

    # Fix "OR OR" → "OR"
    cleaned = re.sub(r"\bOR\s+OR\b", "OR", cleaned, flags=re.IGNORECASE)

    # Translate Informatica IN(col,val,...) → col IN (val,...)
    cleaned = re.sub(
        r"\bIN\s*\(\s*(\w+)\s*,\s*",
        r"\1 IN (",
        cleaned,
        flags=re.IGNORECASE,
    )

    return cleaned


def _resolve_transformation(entry: dict) -> str:
    """Extract the best transformation logic from a field_lineage entry.

    Priority:
    1. If all steps are direct mapping → use source field name (passthrough)
    2. If there's a non-trivial expression in intermediate_steps → use it
    3. Fall back to source field name
    """
    sources = entry.get("ultimate_sources", [])
    src_field = sources[0].get("field", "") if sources else ""

    # Check if it's a simple direct mapping
    if not entry.get("has_transformation", False):
        return src_field or entry.get("target_field", "")

    # Look for actual expressions in intermediate steps
    # Walk from target back toward source; take first non-trivial expression
    for step in entry.get("intermediate_steps", []):
        expr = step.get("expression", "")
        src_type = step.get("source_type", "")
        if not expr or step.get("is_direct_mapping", True):
            continue
        # Skip "Update Strategy [DD_*]" markers — not real expressions
        if expr.startswith("Update Strategy"):
            continue
        # Skip router/joiner passthrough copies (e.g. FIELD_ID1 → FIELD_ID13)
        if src_type in ("Router", "Joiner"):
            continue
        return expr

    # Fall back to source field
    return src_field or entry.get("target_field", "")


class AggregatedLineageParser(BaseParser):
    """Parser for _aggregated_lineage.json files from the RE agent."""

    def discover_files(self) -> List[Path]:
        """Find all _aggregated_lineage.json files in subdirectories."""
        pattern = "**/*_aggregated_lineage.json"
        return sorted(self.input_dir.glob(pattern))

    def parse_file(self, file_path: Path) -> Dict:
        _raw = str(file_path)
        if os.path.isabs(_raw):
            _raw = os.path.relpath(os.path.abspath(_raw), _PARSER_ROOT)
        safe_path = safe_join(_PARSER_ROOT, _raw)
        if safe_path is None:
            raise ValueError(f"Path '{file_path}' escapes the allowed directory.")
        with open(safe_path, "r", encoding="utf-8") as f:
            data = json.load(f)

        field_lineage = data.get("field_lineage", [])
        table_registry = data.get("table_registry", {})

        # Group lineage entries by mapping_name
        by_mapping: Dict[str, List[dict]] = defaultdict(list)
        for entry in field_lineage:
            mapping = entry.get("mapping_name", "")
            if mapping in _SKIP_MAPPINGS:
                continue
            target = entry.get("target_table", "")
            if any(target.startswith(p) for p in _SKIP_TARGET_PREFIXES):
                continue
            by_mapping[mapping].append(entry)

        sheets = []
        for mapping_name, entries in by_mapping.items():
            rows = self._entries_to_rows(entries, table_registry)
            if rows:
                sheets.append(STTMSheet(name=mapping_name, rows=rows))

        return {"sheets": sheets, "count": sum(s.row_count for s in sheets)}

    def parse_to_sttm_input(self, file_path: Path) -> STTMInput:
        """Parse file into STTMInput model."""
        _raw = str(file_path)
        if os.path.isabs(_raw):
            _raw = os.path.relpath(os.path.abspath(_raw), _PARSER_ROOT)
        safe_path = safe_join(_PARSER_ROOT, _raw)
        if safe_path is None:
            raise ValueError(f"Path '{file_path}' escapes the allowed directory.")
        result = self.parse_file(Path(safe_path))
        return STTMInput(source_file=safe_path, sheets=result["sheets"])

    def _entries_to_rows(
        self, entries: List[dict], table_registry: Dict
    ) -> List[STTMRow]:
        """Convert field_lineage entries to STTMRows."""
        rows = []
        seen_pks = self._collect_primary_keys(table_registry)

        for entry in entries:
            target_full = entry.get("target_table", "")
            target_field = entry.get("target_field", "")
            if not target_full or not target_field:
                continue

            tgt_schema, tgt_table = _split_qualified(target_full)
            tgt_dtype, tgt_prec = _parse_datatype(entry.get("target_datatype", ""))

            # Resolve source table — prefer source_tables[] (actual DB tables),
            # fall back to ultimate_sources[].table
            src_table, src_schema, src_field, src_dtype, src_prec = "", "", "", "", ""
            generated_expr = ""
            source_tables_list = entry.get("source_tables", [])
            sources = entry.get("ultimate_sources", [])

            if sources:
                src_field = sources[0].get("field", "")
                # Strip Informatica port prefixes: in_ColumnName → ColumnName
                if src_field and re.match(r"^(?:in|out)_", src_field):
                    src_field = re.sub(r"^(?:in|out)_", "", src_field)
                src_raw_dtype = sources[0].get("datatype", "")
                src_dtype, src_prec = _parse_datatype(src_raw_dtype)
                generated_expr = sources[0].get("generated_expression", "")

            # Resolve source table name
            def _is_hardcoded(name: str) -> bool:
                return name.upper() in {s.upper() for s in _HARDCODED_SOURCES}

            def _is_file_path(name: str) -> bool:
                return any(name.startswith(p) for p in _SKIP_TARGET_PREFIXES)

            def _resolve_file_path_source(
                path: str, registry: Dict
            ) -> str:
                """Map a file path source to a table_registry name."""
                # Extract filename without extension: /opt/.../LKUP_SBMN_CNTL.csv → LKUP_SBMN_CNTL
                import os
                basename = os.path.splitext(os.path.basename(path))[0].upper()
                # Find matching table in registry (may have FF_ prefix)
                for tname in registry:
                    clean = tname.upper().replace("FF_", "").replace("SC_", "")
                    if clean == basename or tname.upper() == basename:
                        return tname
                return basename  # Fall back to filename

            # Use source_tables for the actual FROM table
            src_full = ""
            if source_tables_list:
                for st in source_tables_list:
                    if _is_hardcoded(st):
                        continue
                    if _is_file_path(st):
                        # Map file path to table registry name
                        resolved = _resolve_file_path_source(st, table_registry)
                        src_full = resolved
                        break
                    src_full = st
                    break
            if not src_full and sources:
                candidate = sources[0].get("table", "")
                if _is_hardcoded(candidate):
                    pass  # Skip hardcoded
                elif _is_file_path(candidate):
                    src_full = _resolve_file_path_source(candidate, table_registry)
                else:
                    src_full = candidate

            # Strip SQL Server bracket notation: [CCAR].[dbo].[Table] → CCAR.dbo.Table
            if src_full and "[" in src_full:
                src_full = src_full.replace("[", "").replace("]", "")
                # Drop intermediate [dbo] segment: CCAR.dbo.Table → CCAR.Table
                parts = src_full.split(".")
                parts = [p for p in parts if p.lower() != "dbo"]
                src_full = ".".join(parts)

            if src_full:
                src_schema, src_table = _split_qualified(src_full)

            # Resolve transformation logic
            # If source is hardcoded, use the generated_expression (e.g. SYSDATE, NULL, 'Y')
            if not src_table and generated_expr:
                transform = generated_expr
            else:
                transform = _resolve_transformation(entry)

            # DML operation from update_strategy
            strategy = entry.get("update_strategy", "")
            dml_op = _STRATEGY_MAP.get(strategy, "INSERT")

            # If DD_DELETE and there's also DD_INSERT for same target, it's a MERGE pattern
            # (handled at sheet level below)

            # Filter conditions (from SQL override WHERE, filter transformations)
            filter_cond = _clean_filter_condition(entry.get("filter_condition", ""))
            router_cond = _clean_router_condition(entry.get("router_condition", ""))
            # Note: joiner_condition is Informatica internal join metadata,
            # not a SQL clause — do NOT pass it as join_conditions

            # Combine filter + router for filter_conditions
            filters = []
            if filter_cond:
                filters.append(filter_cond)
            if router_cond:
                filters.append(router_cond)

            # Primary key check
            is_pk = target_field in seen_pks.get(tgt_table, set())

            rows.append(STTMRow(
                source_table=src_table,
                source_schema=src_schema,
                source_attribute=src_field,
                source_datatype=src_dtype,
                source_datatype_length=src_prec,
                target_table=tgt_table,
                target_schema=tgt_schema,
                target_attribute=target_field,
                target_datatype=tgt_dtype,
                target_datatype_length=tgt_prec,
                transformation_logic=transform or src_field or target_field,
                transformation_explanation=entry.get("transformation_explanation", ""),
                mapping_name=entry.get("mapping_name", ""),
                dml_operation=dml_op,
                filter_conditions="; ".join(filters),
                join_conditions="",
                is_primary_key=is_pk,
            ))

        # Post-process: if a target table has both INSERT and DELETE rows,
        # upgrade all to MERGE (SCD-2 pattern)
        self._upgrade_to_merge(rows)

        return rows

    def _upgrade_to_merge(self, rows: List[STTMRow]) -> None:
        """If a target has both INSERT and DELETE operations, it's a MERGE/SCD pattern."""
        ops_by_target: Dict[str, set] = defaultdict(set)
        for row in rows:
            ops_by_target[row.target_table].add(row.dml_operation)

        merge_targets = {
            tgt for tgt, ops in ops_by_target.items()
            if len(ops) > 1 or "DELETE" in ops or "MERGE" in ops
        }

        for row in rows:
            if row.target_table in merge_targets:
                row.dml_operation = "MERGE"

    def _collect_primary_keys(self, table_registry: Dict) -> Dict[str, set]:
        """Extract primary keys from table_registry."""
        pks: Dict[str, set] = defaultdict(set)
        for tbl_name, tbl_info in table_registry.items():
            pk_list = tbl_info.get("primary_keys", [])
            if pk_list:
                pks[tbl_name] = set(pk_list)
        return pks


def main():
    import sys
    input_dir = sys.argv[1] if len(sys.argv) > 1 else "inputs/Auto_Loans_All_with_bteq"

    _raw = input_dir
    if os.path.isabs(_raw):
        _raw = os.path.relpath(os.path.abspath(_raw), _PARSER_ROOT)
    safe_input = safe_join(_PARSER_ROOT, _raw)
    if safe_input is None:
        raise SystemExit(f"Error: path '{input_dir}' escapes the allowed directory.")

    parser = AggregatedLineageParser(input_dir=safe_input, output_dir="output")
    files = parser.discover_files()
    print(f"Found {len(files)} aggregated lineage files")
    for f in files[:5]:
        _f_raw = str(f)
        if os.path.isabs(_f_raw):
            _f_raw = os.path.relpath(os.path.abspath(_f_raw), _PARSER_ROOT)
        safe_f = safe_join(_PARSER_ROOT, _f_raw)
        if safe_f is None:
            continue
        sttm_input = parser.parse_to_sttm_input(Path(safe_f))
        for sheet in sttm_input.sheets:
            print(f"  {sheet.name}: {sheet.row_count} rows, targets: {sheet.target_tables}")


if __name__ == "__main__":
    main()
