"""
Datatype Mapper — Maps source datatypes (Teradata, Oracle, etc.) to Snowflake.

Ported from CodeGenerator._map_datatype() with added support for
precision/scale parsing and inline type formats.
"""

import re
from typing import Optional, Tuple


class DatatypeMapper:
    """Maps source database datatypes to Snowflake equivalents."""

    @staticmethod
    def map(source_type: str) -> str:
        """Map a source datatype string to its Snowflake equivalent.

        Handles Oracle (NVARCHAR2, NUMBER, CLOB), Teradata (BYTEINT, INTERVAL),
        and standard SQL types. Preserves precision/scale when present.
        """
        type_upper = source_type.upper().strip()
        if not type_upper:
            return "VARCHAR(255)"

        precision_match = re.match(r"^[\w\s]+\((.+)\)$", source_type.strip())
        precision_suffix = f"({precision_match.group(1)})" if precision_match else ""
        base_type = re.sub(r"\(.*\)", "", type_upper).strip()

        # Oracle NVARCHAR2 / NCHAR / NCLOB / Informatica NSTRING
        if base_type in ("NVARCHAR2", "NVARCHAR", "VARCHAR2", "NCHAR", "NSTRING"):
            return f"VARCHAR{precision_suffix}" if precision_suffix else "VARCHAR"
        if base_type == "NCLOB":
            return "VARCHAR(16777216)"

        # Standard VARCHAR/CHAR
        if "VARCHAR" in base_type or base_type == "CHAR":
            return source_type

        # Numeric types
        if base_type in ("NUMBER", "NUMERIC", "DECIMAL"):
            return f"NUMBER{precision_suffix}" if precision_suffix else "NUMBER"
        if base_type == "BIGINT":
            return "BIGINT"
        if base_type == "BYTEINT":
            return "SMALLINT"
        if "INT" in base_type:
            return "INTEGER"

        # Date/Time types
        if base_type == "DATE":
            if precision_suffix:
                nums = [p.strip() for p in precision_suffix.strip("()").split(",") if p.strip().isdigit()]
                if any(int(n) > 10 for n in nums):
                    return "TIMESTAMP_NTZ"
            return "DATE"
        if "TIMESTAMP" in base_type or base_type in ("DATETIME", "DATE/TIME"):
            return "TIMESTAMP_NTZ"
        if base_type == "TIME":
            return "TIME"

        # Boolean
        if "BOOL" in base_type:
            return "BOOLEAN"

        # Float/Double
        if base_type in ("FLOAT", "DOUBLE", "BINARY_FLOAT", "BINARY_DOUBLE", "REAL"):
            return "FLOAT"

        # Binary/LOB
        if base_type in ("BLOB", "RAW", "LONG RAW"):
            return "BINARY"
        if base_type in ("CLOB", "LONG", "TEXT"):
            return "VARCHAR(16777216)"

        # Teradata INTERVAL
        if base_type.startswith("INTERVAL"):
            return "VARCHAR(50)"

        return source_type

    # Types that never accept precision/scale in Snowflake
    _NO_PRECISION_TYPES = {
        "BIGINT", "INTEGER", "INT", "SMALLINT", "TINYINT",  # Integer types
        "DATE", "BOOLEAN", "FLOAT",                          # No-arg types
    }
    # Types that accept only fractional seconds precision (0-9) in Snowflake
    _TIMESTAMP_TYPES = {"TIMESTAMP_NTZ", "TIMESTAMP_LTZ", "TIMESTAMP_TZ", "TIME"}

    @staticmethod
    def format_column_type(datatype: str, precision: Optional[int], scale: Optional[int]) -> str:
        """Format a column type with precision and scale.

        Examples:
            ('VARCHAR', 255, None) -> 'VARCHAR(255)'
            ('NUMBER', 38, 0) -> 'NUMBER(38,0)'
            ('BIGINT', 19, None) -> 'BIGINT'
            ('DATE', 10, None) -> 'DATE'
            ('TIMESTAMP_NTZ', 26, None) -> 'TIMESTAMP_NTZ'
        """
        mapped = DatatypeMapper.map(datatype)

        # If already has parentheses, return as-is
        if "(" in mapped:
            return mapped

        mapped_upper = mapped.upper()

        # Types that never accept precision
        if mapped_upper in DatatypeMapper._NO_PRECISION_TYPES:
            return mapped

        # Timestamp/time types: only accept fractional seconds (0-9)
        if mapped_upper in DatatypeMapper._TIMESTAMP_TYPES:
            if precision is not None and 0 <= precision <= 9:
                return f"{mapped}({precision})"
            return mapped

        if precision is not None and scale is not None:
            return f"{mapped}({precision},{scale})"
        elif precision is not None:
            return f"{mapped}({precision})"
        return mapped

    @staticmethod
    def infer_from_expression(expression: str) -> Optional[str]:
        """Infer Snowflake datatype from a CAST/TRY_CAST/TO_* expression."""
        if not expression:
            return None
        expr_upper = expression.upper().strip()
        cast_match = re.search(
            r"(?:TRY_)?CAST\s*\(.+?\s+AS\s+(\w+(?:\([^)]*\))?)\s*\)", expr_upper
        )
        if cast_match:
            return cast_match.group(1)
        to_match = re.search(
            r"\bTO_(BIGINT|INTEGER|NUMBER|VARCHAR|DATE|TIMESTAMP|FLOAT|BOOLEAN)\s*\(",
            expr_upper,
        )
        if to_match:
            return to_match.group(1)
        return None
