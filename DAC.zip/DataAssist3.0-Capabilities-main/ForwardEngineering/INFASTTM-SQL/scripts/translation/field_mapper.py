"""
Field Mapper — Maps field lineage to SELECT column expressions.

Builds the column list for INSERT/MERGE SELECT statements from
the field lineage data and table registry.
"""

import re
from typing import Any, Dict, List, Optional, Tuple

from translation.datatype_mapper import DatatypeMapper
from translation.expression_engine import ExpressionEngine


class FieldMapper:
    """Builds SELECT column expressions from field lineage."""

    def __init__(self, database: str = "TARGET_DB"):
        self.database = database

    def build_field_mappings(
        self,
        table_name: str,
        table_info: Dict[str, Any],
        field_lineage: List[Dict[str, Any]],
        table_registry: Dict[str, Any],
    ) -> Tuple[List[Dict[str, str]], str, str]:
        """Build field mappings, primary source, and FROM clause for a target table.

        Returns:
            (field_mappings, primary_source, from_clause)

        field_mappings: [{target_column, expression}, ...]
        primary_source: Fully qualified main source table
        from_clause: FROM clause string (may include JOINs), or empty
        """
        columns = list(table_info.get("columns", {}).keys())
        schema = table_info.get("owner", "PUBLIC")

        # Get lineage for this table
        table_lineage = [
            fl for fl in field_lineage
            if fl.get("target_table", "").upper() == table_name.upper()
        ]

        # Find primary source table
        primary_source = self._find_primary_source(
            table_lineage, table_registry, schema
        )

        # Build FROM clause (may include JOINs from STTM)
        from_clause = ""
        sttm_join = table_info.get("join_clause", "")
        if sttm_join:
            from_clause = ExpressionEngine.qualify_join_clause(
                sttm_join, table_registry, self.database
            )

        # Build column mappings
        lineage_by_field = {
            fl.get("target_field", "").upper(): fl for fl in table_lineage
        }

        field_mappings = []
        for target_col in columns:
            col_upper = target_col.upper()
            if col_upper in lineage_by_field:
                fl = lineage_by_field[col_upper]
                expression = ExpressionEngine.extract_expression(fl)
                expression = ExpressionEngine.translate_teradata(expression)
                expression = ExpressionEngine.resolve_informatica_params(expression)
                if not expression:
                    expression = fl.get("source_field", target_col)
            else:
                expression = target_col

            field_mappings.append({
                "target_column": target_col,
                "expression": expression,
            })

        return field_mappings, primary_source, from_clause

    def _find_primary_source(
        self,
        table_lineage: List[Dict[str, Any]],
        table_registry: Dict[str, Any],
        default_schema: str,
    ) -> str:
        """Find the primary (most-referenced) source table."""
        source_counts: Dict[str, int] = {}
        for fl in table_lineage:
            src = fl.get("source_table", "")
            if src and src != "[HARDCODED]":
                source_counts[src] = source_counts.get(src, 0) + 1

        if not source_counts:
            return ""

        primary = max(source_counts, key=source_counts.get)
        src_info = table_registry.get(primary, {})
        src_owner = src_info.get("owner", default_schema)
        return f"{self.database}.{src_owner}.{primary}"

    def build_select_list(self, field_mappings: List[Dict[str, str]]) -> str:
        """Build the SELECT column list text from field mappings."""
        items = []
        for fm in field_mappings:
            items.append(f"    {fm['expression']} AS {fm['target_column']}")
        return ",\n".join(items)
