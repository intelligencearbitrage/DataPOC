"""
Expression Engine — Translates Teradata/Informatica expressions to Snowflake SQL.

Ported from CodeGenerator._translate_teradata_syntax(),
_resolve_informatica_parameters(), and related methods.
"""

import re
from typing import Dict, List, Optional


class ExpressionEngine:
    """Translates source expressions to Snowflake-compatible SQL."""

    @staticmethod
    def translate_teradata(expr: str) -> str:
        """Translate Teradata-specific SQL syntax to Snowflake.

        Handles: SEL→SELECT, TIMESTAMP(0), INTERVAL, TRIM, CAST, QUALIFY, etc.
        """
        if not expr:
            return expr

        result = expr

        # SEL → SELECT (standalone keyword)
        result = re.sub(r"\bSEL\b(?!\w)", "SELECT", result, flags=re.IGNORECASE)

        # TIMESTAMP(0) → TIMESTAMP_NTZ
        result = re.sub(
            r"\bTIMESTAMP\s*\(\s*0\s*\)", "TIMESTAMP_NTZ", result, flags=re.IGNORECASE
        )

        # INTERVAL 'N' DAY → DATEADD(DAY, N, ...)
        def _replace_simple_interval(m):
            prefix = m.group(1)
            value = m.group(2)
            unit = m.group(3).upper()
            return f"DATEADD({unit}, {value}, {prefix})"

        result = re.sub(
            r"(\w+)\s*-\s*INTERVAL\s+'(\d+)'\s+(DAY|HOUR|MINUTE|SECOND|MONTH|YEAR)",
            _replace_simple_interval,
            result,
            flags=re.IGNORECASE,
        )

        # Compound interval: expr - INTERVAL 'H:MM:SS' HOUR TO SECOND
        def _replace_compound_interval(m):
            prefix = m.group(1)
            time_val = m.group(2)
            parts = time_val.split(":")
            total_seconds = 0
            if len(parts) == 3:
                total_seconds = int(parts[0]) * 3600 + int(parts[1]) * 60 + int(parts[2])
            elif len(parts) == 2:
                total_seconds = int(parts[0]) * 60 + int(parts[1])
            return f"DATEADD(SECOND, -{total_seconds}, {prefix})"

        result = re.sub(
            r"(\w+)\s*-\s*INTERVAL\s+'([\d:]+)'\s+HOUR\s+TO\s+SECOND",
            _replace_compound_interval,
            result,
            flags=re.IGNORECASE,
        )

        # QUALIFY ROW_NUMBER() → Snowflake supports QUALIFY natively
        # No translation needed

        # TRIM(BOTH ... FROM ...) → TRIM(...)
        result = re.sub(
            r"\bTRIM\s*\(\s*BOTH\s+(.+?)\s+FROM\s+(.+?)\s*\)",
            r"TRIM(\2, \1)",
            result,
            flags=re.IGNORECASE,
        )

        # COALESCE / NVL / ZEROIFNULL
        result = re.sub(r"\bZEROIFNULL\s*\(", "ZEROIFNULL(", result, flags=re.IGNORECASE)

        # CAST(x AS FORMAT 'format') → TO_CHAR(x, 'format')
        def _replace_cast_format(m):
            expr_inner = m.group(1)
            fmt = m.group(2)
            return f"TO_CHAR({expr_inner}, '{fmt}')"

        result = re.sub(
            r"\bCAST\s*\((.+?)\s+AS\s+FORMAT\s+'([^']+)'\s*\)",
            _replace_cast_format,
            result,
            flags=re.IGNORECASE,
        )

        # IIF() → IFF() (Informatica uses IIF; Snowflake uses IFF)
        result = re.sub(r"\bIIF\s*\(", "IFF(", result, flags=re.IGNORECASE)

        # IN(col,val,...) → col IN (val,...) (Informatica function syntax → standard SQL)
        result = re.sub(
            r"\bIN\s*\(\s*(\w+)\s*,\s*",
            r"\1 IN (",
            result,
            flags=re.IGNORECASE,
        )

        # ISNULL(x) → (x IS NULL) (Informatica single-arg boolean; Snowflake has no equivalent)
        result = re.sub(
            r"\bISNULL\s*\(\s*(\w+)\s*\)",
            r"(\1 IS NULL)",
            result,
            flags=re.IGNORECASE,
        )

        # SYSDATE → CURRENT_DATE (bare Oracle/Informatica SYSDATE)
        result = re.sub(r"\bSYSDATE\b", "CURRENT_DATE", result, flags=re.IGNORECASE)

        # SYSTIMESTAMP → CURRENT_TIMESTAMP()
        result = re.sub(r"\bSYSTIMESTAMP\b", "CURRENT_TIMESTAMP()", result, flags=re.IGNORECASE)

        # SESSSTARTTIME → CURRENT_TIMESTAMP() (Informatica session variable)
        result = re.sub(r"\bSESSSTARTTIME\b", "CURRENT_TIMESTAMP()", result, flags=re.IGNORECASE)

        # Strip Informatica port prefixes: in_ColumnName → ColumnName, out_ColumnName → ColumnName
        result = re.sub(r"\bin_(\w+)", r"\1", result)
        result = re.sub(r"\bout_(\w+)", r"\1", result)

        return result

    @staticmethod
    def resolve_informatica_params(expr: str, source_tables: List[str] = None) -> str:
        """Resolve Informatica mapping parameters ($$param, $Param_*).

        Replaces $$-prefixed parameters with Snowflake session variables
        or sensible defaults.
        """
        if not expr:
            return expr

        result = expr

        # $$SYS_DATE, $$SYSDATE → CURRENT_DATE
        result = re.sub(r"\$\$SYS_?DATE", "CURRENT_DATE", result, flags=re.IGNORECASE)
        result = re.sub(r"\$\$SYSTIMESTAMP", "CURRENT_TIMESTAMP()", result, flags=re.IGNORECASE)

        # Generic $$PARAM → :P_PARAM (Snowflake bind variable)
        def _replace_param(m):
            param_name = m.group(1)
            return f":P_{param_name.upper()}"

        result = re.sub(r"\$\$(\w+)", _replace_param, result)

        # $Param_xxx → :P_xxx
        result = re.sub(r"\$Param_(\w+)", r":P_\1", result, flags=re.IGNORECASE)

        return result

    @staticmethod
    def extract_expression(lineage_entry: Dict) -> str:
        """Extract the transformation expression from a field lineage entry.

        Checks 'expression', 'transformation_chain', and 'intermediate_steps'.
        Falls back to source_field for DIRECT mappings.
        """
        xform_type = lineage_entry.get("transformation_type", "DIRECT")

        if xform_type == "DIRECT":
            return lineage_entry.get("source_field", "")

        # Check explicit expression
        expression = lineage_entry.get("expression", "")
        if expression:
            return expression

        # Check transformation chain
        chain = lineage_entry.get("transformation_chain", [])
        if chain:
            last = chain[-1] if isinstance(chain[-1], str) else chain[-1].get("expression", "")
            if last:
                return last

        return lineage_entry.get("source_field", "")

    @staticmethod
    def qualify_join_clause(
        join_clause: str,
        table_registry: Dict,
        database: str,
    ) -> str:
        """Qualify bare table names in a JOIN clause with DATABASE.SCHEMA prefix.

        Pass 1: Qualify tables found in registry.
        Pass 2: Infer schema for remaining bare tables from context.
        """
        result = join_clause

        # Pass 1: qualify known tables
        for tbl_name in sorted(table_registry.keys(), key=len, reverse=True):
            tbl_info = table_registry.get(tbl_name, {})
            owner = tbl_info.get("owner", "")
            if owner and re.search(rf"(?<!\.)(?<!\w){re.escape(tbl_name)}(?!\w)", result):
                qualified = f"{database}.{owner}.{tbl_name}"
                result = re.sub(
                    rf"(?<!\.)(?<!\w){re.escape(tbl_name)}(?!\w)",
                    qualified,
                    result,
                )

        # Pass 2: infer schema for remaining bare names after JOIN
        schema_match = re.search(rf"{re.escape(database)}\.(\w+)\.", result)
        if schema_match:
            inferred_schema = schema_match.group(1)

            def _qualify(m):
                join_kw, tbl, alias = m.group(1), m.group(2), m.group(3)
                if "." not in tbl:
                    return f"{join_kw} {database}.{inferred_schema}.{tbl} {alias}"
                return m.group(0)

            result = re.sub(
                r"((?:LEFT\s+|RIGHT\s+|INNER\s+|FULL\s+|CROSS\s+)?(?:OUTER\s+)?JOIN)\s+(\S+)\s+(\w+)",
                _qualify,
                result,
                flags=re.IGNORECASE,
            )

        return result
