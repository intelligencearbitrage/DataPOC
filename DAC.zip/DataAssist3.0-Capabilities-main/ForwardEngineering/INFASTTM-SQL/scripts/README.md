# INFASTTM-SQL — STTM-to-SnowSQL Converter

## Overview

INFASTTM-SQL is a rules-based pipeline that converts **Source-To-Target Mapping (STTM)** documents from Informatica into production-ready **Snowflake SQL** artifacts (DDL, DML, Stored Procedures). It supports multiple input formats and two output modes.

## Architecture

```
inputs/                          output/
  wf_*/                            m_MAPPING_NAME/
    *_aggregated_lineage.json        ddl/*.sql         (CREATE TABLE)
    *.json / *.csv / *.xlsx          dml/*.sql         (INSERT/MERGE)
    *.xml                            procedures/*.sql  (SP_LOAD_*)
                                     infrastructure/*.sql (PROCEDURE_LOG)
        |                                  ^
        v                                  |
  +-----------+    +-----------+    +-------------+    +-----------+
  |  Parsers  | -> | Converter | -> | Generators  | -> |  Output   |
  +-----------+    +-----------+    +-------------+    +-----------+
  aggregated_      sttm_to_model    ddl_generator      SQL files
  lineage_parser   (STTMRow ->      dml_generator      per mapping
  json_parser       GenerationModel) procedure_gen
  excel_parser                      template_engine
  xml_parser
```

## Pipeline Steps

| Step | Module | Input | Output |
|------|--------|-------|--------|
| 1. Parse | `parsers/` | STTM files (JSON/CSV/Excel/XML/Aggregated Lineage) | `STTMInput` (list of `STTMSheet` with `STTMRow[]`) |
| 2. Convert | `converter/sttm_to_model.py` | `STTMInput` | `GenerationModel` (table_registry, field_lineage, PKs) |
| 3. Map Types | `translation/datatype_mapper.py` | Source types (Teradata/Oracle/Informatica) | Snowflake types (VARCHAR, NUMBER, TIMESTAMP_NTZ, etc.) |
| 4. Translate | `translation/expression_engine.py` | Teradata/Informatica expressions | Snowflake SQL expressions |
| 5. Map Fields | `translation/field_mapper.py` | Field lineage + table registry | SELECT column list with expressions |
| 6. Generate DDL | `generators/ddl_generator.py` | `GenerationModel` | CREATE TABLE statements |
| 7. Generate DML | `generators/dml_generator.py` | `GenerationModel` + strategies | INSERT/MERGE statements |
| 8. Generate SP | `generators/procedure_generator.py` | `GenerationModel` | Stored Procedure wrappers |
| 9. Orchestrate | `generators/simple_orchestrator.py` | `GenerationModel` | All SQL files per mapping |

## Supported Input Formats

| Format | Parser | Description |
|--------|--------|-------------|
| Aggregated Lineage JSON | `aggregated_lineage_parser.py` | RE agent output with `field_lineage[]`, `table_registry{}` |
| JSON STTM | `json_parser.py` | Flat JSON with Source_Table, Target_Table, Transformation_Logic |
| CSV STTM | `json_parser.py` | Same schema as JSON |
| Excel STTM | `excel_parser.py` | RCC Future State format with merged headers |
| XML | `xml_parser.py` | Informatica PowerCenter XML exports |

## Usage

```bash
# Convert a single file
python cli.py --input inputs/sttm.json --mode simple

# Convert a directory (auto-discovers files)
python cli.py --input inputs/Auto_Loans/ --mode simple

# Specify database and warehouse
python cli.py --input inputs/ --mode simple --database MY_DB --warehouse MY_WH

# Medallion mode
python cli.py --input inputs/sttm.xlsx --mode medallion
```

## Output Structure

```
output/
  m_MAPPING_NAME/
    ddl/
      target_table_1.sql       # CREATE TABLE IF NOT EXISTS
      target_table_2.sql
      procedure_log.sql        # Audit table DDL
    dml/
      target_table_1_load.sql  # INSERT INTO ... SELECT or MERGE INTO
    procedures/
      sp_load_mapping_name.sql # Stored procedure with TRY/CATCH, GRANT, logging
    infrastructure/
      procedure_log.sql        # Infrastructure DDL
  conversion_summary.json      # Batch results (success/fail counts)
```

## Folder Structure

| Folder | Purpose | Access |
|--------|---------|--------|
| `inputs/` | Source STTM files | Read-only |
| `knowledgebase/` | Reference materials (datatype mappings, conventions) | Read-only |
| `scripts/` | Pipeline Python code (parsers, generators, CLI) | Builder |
| `config/` | Converter configuration | Read-only |
| `output/` | Generated Snowflake SQL | Scripts output |
| `research/` | Phase 1 analysis findings | Researcher |
| `plans/` | Phase 2 conversion plans | Analyzer |
| `testscripts/` | Phase 4 validation reports | Reviewer |
| `thoughts/` | Logs and progress tracking | Agents |
| `guardrails/` | Quality gate enforcement scripts | Read-only |

## Key Features

- **Zero HARD CODED VALUE** — all source references resolved
- **Expression translation** — ISNULL, IIF, SYSDATE, IN(), INTERVAL all converted
- **Port prefix stripping** — `in_`/`out_` Informatica prefixes removed
- **Data type mapping** — Teradata/Oracle/Informatica types to Snowflake
- **MERGE key fallback** — automatic key detection for update-strategy mappings
- **Description text detection** — natural-language prose filtered from SQL output
- **Deterministic output** — stable WHERE clause ordering across runs
