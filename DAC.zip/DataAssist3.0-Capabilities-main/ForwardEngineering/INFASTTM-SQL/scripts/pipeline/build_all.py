"""
Master Build Script — Discovers and runs all generate_*.py scripts,
or runs the CLI for standard conversions.

Usage:
    python scripts/build_all.py                          # Run all generators
    python scripts/build_all.py --cli --input data.xlsx  # Run CLI mode
"""

import importlib
import sys
from pathlib import Path

SCRIPTS_DIR = Path(__file__).resolve().parent.parent
PROJECT_ROOT = SCRIPTS_DIR.parent
sys.path.insert(0, str(SCRIPTS_DIR))

from utils import setup_logging, get_timestamp, save_yaml


def discover_generators() -> list:
    return sorted(SCRIPTS_DIR.glob("generate_*.py"))


def run_generator(script_path: Path, logger) -> dict:
    module_name = script_path.stem
    logger.info(f"Running: {module_name}")
    result = {"script": module_name, "status": "unknown", "error": None}
    try:
        module = importlib.import_module(module_name)
        if hasattr(module, "main"):
            module.main()
            result["status"] = "success"
        else:
            result["status"] = "skipped"
            result["error"] = f"{module_name} has no main() function"
    except Exception as e:
        result["status"] = "failed"
        result["error"] = str(e)
        logger.error(f"{module_name} failed: {e}")
    return result


def main():
    # Check if running in CLI mode
    if "--cli" in sys.argv:
        sys.argv.remove("--cli")
        from cli import main as cli_main
        cli_main()
        return

    logger = setup_logging("build_all", log_dir=PROJECT_ROOT / "thoughts" / "logs")
    logger.info("=" * 60)
    logger.info("Build All - Starting")
    logger.info("=" * 60)

    generators = discover_generators()
    if not generators:
        logger.info("No generate_*.py scripts found. Use --cli for direct conversion.")
        logger.info("  Example: python scripts/build_all.py --cli --input inputs/data.xlsx --mode simple")
        return

    logger.info(f"Found {len(generators)} generator(s): {[g.stem for g in generators]}")

    results = []
    for gen_path in generators:
        results.append(run_generator(gen_path, logger))

    succeeded = sum(1 for r in results if r["status"] == "success")
    failed = sum(1 for r in results if r["status"] == "failed")

    logger.info("=" * 60)
    logger.info(f"Build Complete: {succeeded} succeeded, {failed} failed")
    logger.info("=" * 60)

    save_yaml(
        {"build_report": {"timestamp": get_timestamp(), "results": results}},
        PROJECT_ROOT / "thoughts" / "build_report.yaml",
    )

    if failed > 0:
        sys.exit(1)


if __name__ == "__main__":
    main()
