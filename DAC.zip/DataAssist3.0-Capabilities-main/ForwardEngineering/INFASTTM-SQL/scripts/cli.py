"""
INFASTTM-SQL CLI — Unified command-line interface for STTM-to-SnowSQL conversion.

Supports all 3 scenarios:
  1. JSON STTM  → Simple conversion (preserve schemas)
  2. JSON STTM  → Medallion conversion (Bronze/Silver/Gold)
  3. Excel STTM → Medallion conversion (RCC Future State format)

Usage:
    python scripts/cli.py --input inputs/sttm.xlsx --mode medallion
    python scripts/cli.py --input inputs/sttm.json --mode simple
    python scripts/cli.py --input inputs/ --mode simple --database MY_DB
"""

import argparse
import json
import os
import sys
import time
from pathlib import Path

from werkzeug.utils import safe_join

PROJECT_ROOT = Path(__file__).resolve().parent
SCRIPTS_DIR = PROJECT_ROOT / "scripts"
SAFE_ROOT = str(PROJECT_ROOT)
sys.path.insert(0, str(SCRIPTS_DIR))

from parsers.json_parser import JsonSttmParser
from parsers.excel_parser import ExcelSttmParser
from parsers.xml_parser import InformaticaXmlParser
from parsers.aggregated_lineage_parser import AggregatedLineageParser
from parsers.sttm_model import STTMInput
from converter.sttm_to_model import SttmConverter
from generators.simple_orchestrator import SimpleOrchestrator
from generators.medallion_orchestrator import MedallionOrchestrator
from utils import setup_logging, save_json


def detect_parser(file_path: Path):
    """Auto-detect the appropriate parser based on file extension."""
    suffix = file_path.suffix.lower()
    if suffix in (".json", ".csv"):
        return JsonSttmParser(input_dir=str(file_path.parent), output_dir="output")
    elif suffix in (".xlsx", ".xls"):
        return ExcelSttmParser(input_dir=str(file_path.parent), output_dir="output")
    elif suffix == ".xml":
        return InformaticaXmlParser(input_dir=str(file_path.parent), output_dir="output")
    else:
        raise ValueError(f"Unsupported file format: {suffix}")


def collect_inputs(input_path: Path) -> list:
    """Collect STTMInput objects from a file or directory."""
    _raw = str(input_path)
    if os.path.isabs(_raw):
        _raw = os.path.relpath(os.path.abspath(_raw), SAFE_ROOT)
    _safe = safe_join(SAFE_ROOT, _raw)
    if _safe is None:
        raise SystemExit(f"Error: input path '{input_path}' escapes the allowed directory.")
    input_path = Path(_safe)

    inputs = []

    if input_path.is_file():
        parser = detect_parser(input_path)
        sttm_input = parser.parse_to_sttm_input(input_path)
        inputs.append(sttm_input)

    elif input_path.is_dir():
        agg_parser = AggregatedLineageParser(input_dir=_safe, output_dir="output")
        agg_files = agg_parser.discover_files()
        if agg_files:
            for f in agg_files:
                _f_raw = str(f)
                if os.path.isabs(_f_raw):
                    _f_raw = os.path.relpath(os.path.abspath(_f_raw), SAFE_ROOT)
                _f_safe = safe_join(SAFE_ROOT, _f_raw)
                if _f_safe is None:
                    continue
                inputs.append(agg_parser.parse_to_sttm_input(Path(_f_safe)))
        else:
            json_parser = JsonSttmParser(input_dir=_safe, output_dir="output")
            excel_parser = ExcelSttmParser(input_dir=_safe, output_dir="output")
            xml_parser = InformaticaXmlParser(input_dir=_safe, output_dir="output")

            for f in json_parser.discover_files():
                _f_raw = str(f)
                if os.path.isabs(_f_raw):
                    _f_raw = os.path.relpath(os.path.abspath(_f_raw), SAFE_ROOT)
                _f_safe = safe_join(SAFE_ROOT, _f_raw)
                if _f_safe is None:
                    continue
                inputs.append(json_parser.parse_to_sttm_input(Path(_f_safe)))
            for f in excel_parser.discover_files():
                _f_raw = str(f)
                if os.path.isabs(_f_raw):
                    _f_raw = os.path.relpath(os.path.abspath(_f_raw), SAFE_ROOT)
                _f_safe = safe_join(SAFE_ROOT, _f_raw)
                if _f_safe is None:
                    continue
                inputs.append(excel_parser.parse_to_sttm_input(Path(_f_safe)))
            for f in xml_parser.discover_files():
                _f_raw = str(f)
                if os.path.isabs(_f_raw):
                    _f_raw = os.path.relpath(os.path.abspath(_f_raw), SAFE_ROOT)
                _f_safe = safe_join(SAFE_ROOT, _f_raw)
                if _f_safe is None:
                    continue
                inputs.append(xml_parser.parse_to_sttm_input(Path(_f_safe)))
    else:
        raise FileNotFoundError(f"Input not found: {input_path}")

    return inputs


def run_conversion(args):
    """Run the STTM-to-SnowSQL conversion pipeline."""
    logger = setup_logging("CLI", log_dir=PROJECT_ROOT / "thoughts" / "logs")

    _input_raw = args.input
    if os.path.isabs(_input_raw):
        _input_raw = os.path.relpath(os.path.abspath(_input_raw), SAFE_ROOT)
    safe_input = safe_join(SAFE_ROOT, _input_raw)
    if safe_input is None:
        raise SystemExit(f"Error: input path '{args.input}' escapes the allowed directory.")
    input_path = Path(safe_input)

    if args.output:
        _output_raw = args.output
        if os.path.isabs(_output_raw):
            _output_raw = os.path.relpath(os.path.abspath(_output_raw), SAFE_ROOT)
        safe_output = safe_join(SAFE_ROOT, _output_raw)
        if safe_output is None:
            raise SystemExit(f"Error: output path '{args.output}' escapes the allowed directory.")
        output_dir = Path(safe_output)
    else:
        output_dir = PROJECT_ROOT / "output"

    database = args.database
    warehouse = args.warehouse
    mode = args.mode

    logger.info("=" * 70)
    logger.info("INFASTTM-SQL Conversion")
    logger.info("=" * 70)
    logger.info(f"  Input:     {input_path}")
    logger.info(f"  Output:    {output_dir}")
    logger.info(f"  Mode:      {mode}")
    logger.info(f"  Database:  {database}")
    logger.info("=" * 70)

    sttm_inputs = collect_inputs(input_path)
    if not sttm_inputs:
        logger.error("No STTM files found to process.")
        sys.exit(1)

    total_sheets = sum(len(si.sheets) for si in sttm_inputs)
    logger.info(f"Parsed {len(sttm_inputs)} file(s), {total_sheets} sheet(s)")

    converter = SttmConverter(database=database)

    if mode == "simple":
        orchestrator = SimpleOrchestrator(database, warehouse, str(output_dir))
    else:
        orchestrator = MedallionOrchestrator(database, warehouse, str(output_dir))

    results = []
    for sttm_input in sttm_inputs:
        models = converter.convert_input(sttm_input)
        for model in models:
            start = time.time()
            try:
                result = orchestrator.run(model)
                result["elapsed"] = round(time.time() - start, 1)
                results.append(result)
                logger.info(
                    f"  {result['proc_name']}: {result['status']} "
                    f"({result['ddl_count']} DDL, {result['dml_count']} DML, "
                    f"{result['procedure_count']} SPs) [{result['elapsed']}s]"
                )
            except Exception as e:
                elapsed = round(time.time() - start, 1)
                results.append({
                    "proc_name": model.proc_name,
                    "status": "ERROR",
                    "error": str(e),
                    "elapsed": elapsed,
                })
                logger.error(f"  {model.proc_name}: ERROR - {e}")

    succeeded = sum(1 for r in results if r["status"] == "SUCCESS")
    failed = sum(1 for r in results if r["status"] != "SUCCESS")
    total_ddl = sum(r.get("ddl_count", 0) for r in results)
    total_dml = sum(r.get("dml_count", 0) for r in results)
    total_procs = sum(r.get("procedure_count", 0) for r in results)

    logger.info("=" * 70)
    logger.info("CONVERSION COMPLETE")
    logger.info("=" * 70)
    logger.info(f"  Jobs:      {len(results)}")
    logger.info(f"  Succeeded: {succeeded}")
    logger.info(f"  Failed:    {failed}")
    logger.info(f"  DDL:       {total_ddl}")
    logger.info(f"  DML:       {total_dml}")
    logger.info(f"  SPs:       {total_procs}")
    logger.info(f"  Output:    {output_dir}")
    logger.info("=" * 70)

    _summary_raw = str(output_dir / "conversion_summary.json")
    if os.path.isabs(_summary_raw):
        _summary_raw = os.path.relpath(os.path.abspath(_summary_raw), SAFE_ROOT)
    safe_summary = safe_join(SAFE_ROOT, _summary_raw)
    if safe_summary is None:
        raise SystemExit("Error: summary path escapes the allowed directory.")
    save_json(
        {"total": len(results), "succeeded": succeeded, "failed": failed, "results": results},
        Path(safe_summary),
    )

    if failed > 0:
        sys.exit(1)


def main():
    parser = argparse.ArgumentParser(
        description="INFASTTM-SQL: STTM-to-SnowSQL Converter",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  python scripts/cli.py --input inputs/sttm.xlsx --mode medallion
  python scripts/cli.py --input inputs/sttm.json --mode simple
  python scripts/cli.py --input inputs/ --mode simple --database MY_DB
        """,
    )
    parser.add_argument(
        "--input", required=True,
        help="Input file (.xlsx, .json, .csv) or directory",
    )
    parser.add_argument(
        "--mode", choices=["simple", "medallion"], default="simple",
        help="Conversion mode: 'simple' (preserve schemas) or 'medallion' (Bronze/Silver/Gold)",
    )
    parser.add_argument(
        "--output", default=None,
        help="Output directory (default: output/)",
    )
    parser.add_argument(
        "--database", default="TARGET_DB",
        help="Snowflake database name (default: TARGET_DB)",
    )
    parser.add_argument(
        "--warehouse", default="TARGET_WH",
        help="Snowflake warehouse name (default: TARGET_WH)",
    )

    args = parser.parse_args()
    run_conversion(args)


if __name__ == "__main__":
    main()
