"""
Template Engine — Renders DDL, DML, MERGE, and Stored Procedure SQL.

Uses string formatting (no Jinja2 dependency) to generate Snowflake SQL
from structured context data.
"""

from datetime import datetime
from typing import Any, Dict, List, Optional


class TemplateEngine:
    """Renders SQL artifacts from structured context."""

    def __init__(self, database: str, warehouse: str = "", environment: str = "DEV"):
        self.database = database
        self.warehouse = warehouse
        self.environment = environment

    def render_ddl(
        self,
        table_name: str,
        columns: List[Dict[str, str]],
        schema: str,
    ) -> str:
        """Render CREATE TABLE DDL."""
        fqn = f"{self.database}.{schema}.{table_name}"
        col_lines = []
        for col in columns:
            nullable = "" if col.get("nullable", True) else " NOT NULL"
            col_lines.append(f"    {col['name']} {col['datatype']}{nullable}")

        cols_sql = ",\n".join(col_lines)
        return (
            f"-- =============================================================================\n"
            f"-- DDL for {schema}.{table_name}\n"
            f"-- Generated: {datetime.now().isoformat()}\n"
            f"-- =============================================================================\n"
            f"CREATE TABLE IF NOT EXISTS {fqn} (\n"
            f"{cols_sql}\n"
            f");\n\n"
            f"COMMENT ON TABLE {fqn} IS 'Migrated table - {schema} layer';\n"
        )

    def render_insert(
        self,
        table_name: str,
        schema: str,
        select_list: str,
        from_clause: str,
        where_clause: str = "",
    ) -> str:
        """Render INSERT INTO ... SELECT ... FROM ... statement."""
        fqn = f"{self.database}.{schema}.{table_name}"
        # Extract column names from select list
        col_names = []
        for line in select_list.strip().split("\n"):
            line = line.strip().rstrip(",")
            if " AS " in line.upper():
                col_names.append(line.split(" AS ")[-1].strip())
            elif line:
                col_names.append(line.strip())

        cols_sql = ",\n    ".join(col_names)
        where_sql = f"\nWHERE {where_clause}" if where_clause else ""

        return (
            f"-- =============================================================================\n"
            f"-- INSERT for {table_name}\n"
            f"-- Source: {from_clause.split()[0] if from_clause else 'N/A'}\n"
            f"-- Generated: {datetime.now().isoformat()}\n"
            f"-- =============================================================================\n"
            f"INSERT INTO {fqn} (\n"
            f"    {cols_sql}\n"
            f")\n"
            f"SELECT\n"
            f"{select_list}\n"
            f"FROM {from_clause}{where_sql};\n"
        )

    def render_merge(
        self,
        table_name: str,
        schema: str,
        select_list: str,
        from_clause: str,
        key_columns: List[str],
        update_columns: List[str],
        all_columns: List[str],
        where_clause: str = "",
    ) -> str:
        """Render MERGE INTO ... USING ... ON ... WHEN MATCHED/NOT MATCHED."""
        fqn = f"{self.database}.{schema}.{table_name}"
        where_sql = f"\n    WHERE {where_clause}" if where_clause else ""

        on_clause = " AND ".join(f"tgt.{k} = src.{k}" for k in key_columns)
        update_set = ",\n        ".join(f"tgt.{c} = src.{c}" for c in update_columns)
        insert_cols = ",\n        ".join(all_columns)
        insert_vals = ",\n        ".join(f"src.{c}" for c in all_columns)

        return (
            f"-- =============================================================================\n"
            f"-- MERGE for {table_name}\n"
            f"-- Source: {from_clause.split()[0] if from_clause else 'N/A'}\n"
            f"-- Generated: {datetime.now().isoformat()}\n"
            f"-- =============================================================================\n"
            f"MERGE INTO {fqn} AS tgt\n"
            f"USING (\n"
            f"    SELECT\n"
            f"{select_list}\n"
            f"    FROM {from_clause}{where_sql}\n"
            f") AS src\n"
            f"ON {on_clause}\n"
            f"WHEN MATCHED THEN\n"
            f"    UPDATE SET\n"
            f"        {update_set}\n"
            f"WHEN NOT MATCHED THEN\n"
            f"    INSERT (\n"
            f"        {insert_cols}\n"
            f"    )\n"
            f"    VALUES (\n"
            f"        {insert_vals}\n"
            f"    );\n"
        )

    def render_procedure(
        self,
        proc_name: str,
        schema: str,
        main_sql: str,
        description: str = "",
        pre_sql: str = "",
        post_sql: str = "",
        delete_sql: str = "",
    ) -> str:
        """Render a Snowflake stored procedure wrapping DML with logging."""
        fqn = f"{self.database}.{schema}.{proc_name}"
        desc = description or f"Load procedure for {proc_name}"

        pre_block = f"    {pre_sql}\n" if pre_sql else "    -- No pre-load SQL\n"
        delete_block = f"\n    -- Delete existing records\n    V_STEP := 'DELETE';\n    {delete_sql}\n" if delete_sql else ""
        post_block = f"    {post_sql}\n" if post_sql else "    -- No post-load SQL\n"

        # Indent main SQL
        indented_sql = "\n".join(f"    {line}" for line in main_sql.strip().split("\n"))

        return f"""\
/*******************************************************************************
 * Procedure: {proc_name}
 * Layer: {schema}
 * Description: {desc}
 * Generated: {datetime.now().isoformat()}
 ******************************************************************************/
CREATE OR REPLACE PROCEDURE {fqn}(
    P_BATCH_ID VARCHAR DEFAULT NULL
)
RETURNS VARCHAR
LANGUAGE SQL
EXECUTE AS CALLER
COMMENT = '{desc}'
AS
$$
DECLARE
    V_PROC_NAME VARCHAR := '{proc_name}';
    V_BATCH_ID VARCHAR := COALESCE(P_BATCH_ID, UUID_STRING());
    V_START_TIME TIMESTAMP_NTZ := CURRENT_TIMESTAMP();
    V_ROWS_AFFECTED INTEGER := 0;
    V_STEP VARCHAR := 'INIT';
    V_ERROR_MESSAGE VARCHAR;
BEGIN
    -- Log start
    INSERT INTO {self.database}.COMMON.PROCEDURE_LOG (
        PROC_NAME, BATCH_ID, STATUS, STEP, START_TIME, MESSAGE
    ) VALUES (
        :V_PROC_NAME, :V_BATCH_ID, 'RUNNING', 'START', :V_START_TIME, 'Procedure started'
    );

    -- Pre-load
    V_STEP := 'PRE_LOAD';
{pre_block}
{delete_block}
    -- Main load
    V_STEP := 'MAIN_LOAD';
{indented_sql}

    GET DIAGNOSTICS V_ROWS_AFFECTED := ROW_COUNT;

    -- Post-load
    V_STEP := 'POST_LOAD';
{post_block}
    -- Log success
    INSERT INTO {self.database}.COMMON.PROCEDURE_LOG (
        PROC_NAME, BATCH_ID, STATUS, STEP, START_TIME, END_TIME, ROWS_AFFECTED, MESSAGE
    ) VALUES (
        :V_PROC_NAME, :V_BATCH_ID, 'SUCCESS', 'COMPLETE', :V_START_TIME,
        CURRENT_TIMESTAMP(), :V_ROWS_AFFECTED, 'Procedure completed successfully'
    );

    RETURN 'SUCCESS: ' || V_ROWS_AFFECTED || ' rows loaded';

EXCEPTION
    WHEN OTHER THEN
        V_ERROR_MESSAGE := SQLERRM;
        INSERT INTO {self.database}.COMMON.PROCEDURE_LOG (
            PROC_NAME, BATCH_ID, STATUS, STEP, START_TIME, END_TIME, ERROR_MESSAGE, MESSAGE
        ) VALUES (
            :V_PROC_NAME, :V_BATCH_ID, 'FAILED', :V_STEP, :V_START_TIME,
            CURRENT_TIMESTAMP(), :V_ERROR_MESSAGE, 'Procedure failed at step: ' || :V_STEP
        );
        RAISE;
END;
$$;

GRANT EXECUTE ON PROCEDURE {fqn}(VARCHAR) TO ROLE DATA_ENGINEER;
"""

    def render_log_table(self, schema: str = "COMMON") -> str:
        """Render the PROCEDURE_LOG infrastructure table DDL."""
        fqn = f"{self.database}.{schema}.PROCEDURE_LOG"
        return (
            f"CREATE TABLE IF NOT EXISTS {fqn} (\n"
            f"    LOG_ID NUMBER AUTOINCREMENT,\n"
            f"    PROC_NAME VARCHAR(200),\n"
            f"    BATCH_ID VARCHAR(100),\n"
            f"    STATUS VARCHAR(20),\n"
            f"    STEP VARCHAR(50),\n"
            f"    START_TIME TIMESTAMP_NTZ,\n"
            f"    END_TIME TIMESTAMP_NTZ,\n"
            f"    ROWS_AFFECTED NUMBER,\n"
            f"    ERROR_MESSAGE VARCHAR(4000),\n"
            f"    MESSAGE VARCHAR(2000),\n"
            f"    CREATED_AT TIMESTAMP_NTZ DEFAULT CURRENT_TIMESTAMP()\n"
            f");\n"
        )
