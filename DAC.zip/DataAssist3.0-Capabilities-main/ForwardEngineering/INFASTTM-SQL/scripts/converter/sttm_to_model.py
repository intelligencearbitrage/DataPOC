"""
STTM Converter — Transforms parsed STTM rows into the internal generation model.

Takes format-agnostic STTMInput (from any parser) and produces a GenerationModel
that the DDL/DML/Procedure generators consume.
"""

import re
import sys
from collections import defaultdict
from pathlib import Path
from typing import Any, Dict, List, Optional, Set, Tuple

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from parsers.sttm_model import STTMRow, STTMSheet, STTMInput
from utils import setup_logging


def parse_datatype(raw_type: str, raw_length: str) -> Tuple[str, Optional[int], Optional[int]]:
    """Parse datatype and length into (datatype, precision, scale).

    Handles: 'VARCHAR'+'30', 'NUMBER'+'38,0', 'VARCHAR 10'+'', ''+''.
    """
    if not raw_type:
        return "VARCHAR", 255, None

    datatype = raw_type.upper().strip()
    precision, scale = None, None

    inline = re.match(r"^(\w+)\s+(\d+)$", datatype)
    if inline:
        return inline.group(1), int(inline.group(2)), None

    if raw_length:
        if "," in raw_length:
            parts = raw_length.split(",", 1)
            try:
                precision = int(parts[0].strip())
                scale = int(parts[1].strip())
            except ValueError:
                pass
        else:
            try:
                precision = int(raw_length.strip())
            except ValueError:
                pass

    return datatype, precision, scale


class GenerationModel:
    """Internal model consumed by generators.

    Attributes:
        table_registry: {table_name: {columns, owner, table_type, ...}}
        field_lineage: [{target_table, target_field, source_table, source_field, ...}]
        source_qualifiers: [{sql_query, source_tables, ...}]
        primary_keys: {table_name: [pk_columns]}
    """

    def __init__(self):
        self.table_registry: Dict[str, Dict[str, Any]] = {}
        self.field_lineage: List[Dict[str, Any]] = []
        self.source_qualifiers: List[Dict[str, Any]] = []
        self.primary_keys: Dict[str, List[str]] = {}
        self.proc_name: str = ""
        self.source_file: str = ""

    def target_tables(self) -> List[str]:
        return [
            name for name, info in self.table_registry.items()
            if info.get("table_type") == "TARGET"
        ]


class SttmConverter:
    """Converts STTMSheet rows into a GenerationModel."""

    _UNMAPPED_EXACT = {"not mapped", "unmapped", "n/a", "null", "none", ""}
    _UNMAPPED_CONTAINS = {"not mapped", "unmapped"}
    _PASSTHROUGH_RE = re.compile(
        r"^\s*(?:\[(?:llm[^\]]*|resolved)\]\s*)?"
        r"direct\s+(?:pass[\s-]*through|passthrough|mapping)"
        r"(?:\s+from\s+\S+(?:\s+\S+)*)?"
        r"\s*$",
        re.IGNORECASE,
    )
    # Phrases that indicate natural-language process descriptions, NOT executable SQL
    _DESCRIPTION_PHRASES = re.compile(
        r"(?:"
        r"joining\s+\w+\s+and\s+\w+\s+data\s+on"        # "joining prelanding and landing data on ..."
        r"|(?:full|left|right|inner|cross)\s+outer\s+join\)\s+followed\s+by"  # "...full outer join) followed by router"
        r"|router\s+condition\s*\d*\s*:"                  # "Router Condition1: IN(FLAG,'I','U')"
        r"|pre\s+router\s*:"                              # "Pre Router: Flag =DECODE(..."
        r"|post\s+join\s*:"                               # "Post Join: ..."
        r"|direct\s+passthrough\s+of\s+L_"                # "Direct Passthrough of L_FIELDNAME"
        r"|get\s+the\s+\w+\s+from\s+\w+"                  # "Get the SOURCE_EXECUTION_TS from CNTL_SYSTEM_MASTER"
        r"|default(?:ed)?\s+(?:to|value)\s+['\"]"         # "Defaulted to '1'" / "Default Value '1'"
        r"|no\s+CDC\s+source"                             # "no CDC source"
        r"|to\s+be\s+defined"                             # "to be defined"
        r"|(?:followed|preceded)\s+by\s+(?:router|filter|aggregator|joiner|lookup)"
        r"|informatica\s+(?:mapping|workflow|session)"
        r"|(?:source|target)\s+qualifier"
        r"|SQL\s+Query\s+\d+\s*:"                        # "SQL Query 1: Direct passthrough..."
        r"|Hardcoded\s+to\s+['\"]"                        # "Hardcoded to 'RCC'"
        r"|then\s+UNION\b"                                # "...then UNION"
        r")",
        re.IGNORECASE,
    )

    def __init__(self, database: str = "TARGET_DB", default_schema: str = "PUBLIC"):
        self.database = database
        self.default_schema = default_schema
        self.logger = setup_logging("SttmConverter")

    @classmethod
    def _is_unmapped(cls, text: str) -> bool:
        """Check if a transformation/attribute value represents an unmapped field."""
        lower = text.lower().strip()
        if lower in cls._UNMAPPED_EXACT:
            return True
        return any(kw in lower for kw in cls._UNMAPPED_CONTAINS)

    @classmethod
    def _is_description(cls, text: str) -> bool:
        """Detect natural-language process descriptions that are NOT executable SQL.

        Returns True for Informatica workflow narratives, CDC process descriptions,
        router conditions embedded in prose, and similar non-SQL text that should
        NOT appear in generated SELECT statements.
        """
        if not text or len(text) < 10:
            return False
        # Multi-line text with newlines is almost always a description
        if "\n" in text and len(text) > 60:
            return True
        # Check for known description phrases
        if cls._DESCRIPTION_PHRASES.search(text):
            return True
        return False

    def convert_sheet(self, sheet: STTMSheet) -> GenerationModel:
        """Convert a single STTMSheet to a GenerationModel."""
        model = GenerationModel()
        model.proc_name = sheet.name
        rows = sheet.rows

        tables_columns: Dict[str, Dict[str, Dict]] = defaultdict(dict)
        tables_meta: Dict[str, Dict] = defaultdict(lambda: {
            "dml_operations": set(),
            "filter_conditions": [],
            "join_conditions": [],
            "source_tables": set(),
        })
        primary_keys: Dict[str, Set[str]] = defaultdict(set)

        for row in rows:
            src_attr = row.source_attribute
            transform = row.transformation_logic
            tgt_table = row.target_table
            tgt_attr = row.target_attribute
            tgt_schema = row.target_schema or self.default_schema
            dml_op = row.dml_operation or "INSERT"

            # Normalize unmapped (handles variants: "Not Mapped (NULL)", "Unmapped - NULL value", etc.)
            if self._is_unmapped(transform):
                transform = "NULL"
            if self._is_unmapped(src_attr):
                src_attr = ""

            # Sanitize multi-line/multi-value source attributes
            # Some STTM rows list multiple table.column refs separated by newlines/semicolons
            # (e.g. CDC Action_Ind logic), or contain parenthetical descriptions.
            # Extract just the bare column name or fall back to tgt_attr.
            if src_attr and ("\n" in src_attr or ";" in src_attr):
                src_attr = tgt_attr
            elif src_attr and ("(" in src_attr and ")" in src_attr):
                # "SRC_SYS_NM (SQL Query 1 - hardcoded to 'RCC'), N/A (...)" → "SRC_SYS_NM"
                clean = re.sub(r"\s*\([^)]*\)", "", src_attr).strip()
                clean = re.split(r"\s*,\s*", clean)[0].strip()
                src_attr = clean if clean and clean.upper() != "N/A" else tgt_attr

            # Skip volatile/temp
            if dml_op.upper().startswith(("CREATE VOLATILE", "CREATE TEMP")):
                continue
            if not tgt_table or not tgt_attr:
                continue

            # Primary keys
            if row.is_primary_key and tgt_attr:
                primary_keys[tgt_table].add(tgt_attr)

            # Target column info
            col_dt, col_prec, col_scale = parse_datatype(
                row.target_datatype, row.target_datatype_length
            )
            tables_columns[tgt_table][tgt_attr] = {
                "datatype": col_dt,
                "precision": col_prec,
                "scale": col_scale,
                "nullable": True,
            }

            # Metadata
            meta = tables_meta[tgt_table]
            meta["dml_operations"].add(dml_op.upper())
            meta["schema"] = tgt_schema
            if row.filter_conditions:
                # Strip "SQL Query N:" prefixes from filter conditions
                fc = re.sub(r"SQL\s+Query\s+\d+\s*:\s*", "", row.filter_conditions).strip()
                # Remove duplicate conditions separated by semicolons
                fc_parts = [p.strip() for p in fc.split(";") if p.strip()]
                if fc_parts and fc_parts[0] not in meta["filter_conditions"]:
                    meta["filter_conditions"].append(fc_parts[0])
            if row.join_conditions:
                # Strip "SQL Query N:" prefixes from join conditions
                jc = re.sub(r"SQL\s+Query\s+\d+\s*:\s*", "", row.join_conditions).strip()
                # Take only the first join clause (before any semicolons)
                jc_parts = [p.strip() for p in jc.split(";") if p.strip()]
                if jc_parts and jc_parts[0] not in meta["join_conditions"]:
                    meta["join_conditions"].append(jc_parts[0])
            if row.source_qualified:
                meta["source_tables"].add(row.source_qualified)

            # Source table registry
            src_table = row.source_table
            src_schema = row.source_schema
            if src_table and src_table not in tables_columns:
                tables_columns[src_table] = {}
            if src_attr and src_table:
                # Use source datatype from the row if available; fall back to VARCHAR(255)
                src_dt, src_prec, src_scale = parse_datatype(
                    row.source_datatype, row.source_datatype_length
                ) if row.source_datatype else ("VARCHAR", 255, None)
                # Don't overwrite an existing column definition with a weaker type
                existing = tables_columns[src_table].get(src_attr)
                if not existing or existing.get("datatype") == "VARCHAR":
                    tables_columns[src_table][src_attr] = {
                        "datatype": src_dt,
                        "precision": src_prec,
                        "scale": src_scale,
                        "nullable": True,
                    }
                if "schema" not in tables_meta[src_table]:
                    tables_meta[src_table]["schema"] = src_schema or self.default_schema

            # Strip inline "Filter Criteria:" that the Excel parser didn't split
            if "\nFilter Criteria:" in transform or "\nfilter criteria:" in transform.lower():
                parts = re.split(r"\n\s*Filter\s+Criteria\s*:", transform, maxsplit=1, flags=re.IGNORECASE)
                transform = parts[0].strip()

            # Normalize passthrough descriptions to DIRECT mapping
            if self._PASSTHROUGH_RE.match(transform):
                transform = src_attr or tgt_attr

            # Strip inline "(Direct passthrough ...)" annotations from expressions
            # e.g. "CM01.CM01_ADDRESS_CODE (Direct passthrough)" → "CM01.CM01_ADDRESS_CODE"
            transform = re.sub(
                r"\s*\((?:[Dd]irect\s+(?:passthrough|pass[\s-]*through)[^)]*)\)",
                "", transform,
            ).strip()

            # "Direct passthrough - COLUMN_NAME" → "COLUMN_NAME"
            transform = re.sub(
                r"^(?:\[?[Rr][Ee][Ss][Oo][Ll][Vv][Ee][Dd]\]?\s*)?[Dd]irect\s+(?:passthrough|pass[\s-]*through)\s*[-–—]\s*",
                "", transform,
            ).strip()

            # Normalize STTM annotation tags
            # [SK] MD5(...) → keep the expression (valid SQL after the tag)
            transform = re.sub(r"^\[SK\]\s*", "", transform).strip()
            # [FK_SK], [SCD-2], [LLM-*] → NULL (descriptions, not executable SQL)
            if re.match(r"^\[(?:FK_SK|SCD-2|LLM-[^\]]*)\]\s", transform):
                transform = "NULL"
            # "New column - no CDC source ..." → NULL
            if re.match(r"^New column\b", transform, re.IGNORECASE):
                transform = "NULL"

            # Catch-all: detect natural-language descriptions that slipped through
            # For rows with a source column, use the source column (DIRECT mapping).
            # For rows without a source, use NULL.
            if transform != "NULL" and self._is_description(transform):
                transform = src_attr or "NULL"

            # Field lineage
            if src_attr and src_table:
                xform_type = "DIRECT" if transform == src_attr else "EXPRESSION"
                entry = {
                    "target_table": tgt_table,
                    "target_field": tgt_attr,
                    "source_table": src_table,
                    "source_field": src_attr,
                    "transformation_type": xform_type,
                }
                if xform_type == "EXPRESSION":
                    entry["expression"] = transform
                model.field_lineage.append(entry)
            elif not src_attr and transform == "NULL":
                model.field_lineage.append({
                    "target_table": tgt_table,
                    "target_field": tgt_attr,
                    "source_table": "[HARDCODED]",
                    "source_field": "NULL",
                    "transformation_type": "EXPRESSION",
                    "expression": "NULL",
                })
            elif not src_table:
                # If transform is a passthrough description with no source, use target col name
                expr = tgt_attr if self._PASSTHROUGH_RE.match(transform) else transform
                xtype = "DIRECT" if expr == tgt_attr else "EXPRESSION"
                model.field_lineage.append({
                    "target_table": tgt_table,
                    "target_field": tgt_attr,
                    "source_table": "[HARDCODED]",
                    "source_field": expr,
                    "transformation_type": xtype,
                    **({"expression": expr} if xtype == "EXPRESSION" else {}),
                })

        # Build table_registry
        for tbl_name, columns in tables_columns.items():
            if not columns:
                continue
            meta = tables_meta.get(tbl_name, {})
            dml_ops = meta.get("dml_operations", set())
            schema = meta.get("schema", self.default_schema)
            is_target = bool(dml_ops & {"INSERT", "UPDATE", "MERGE", "DELETE"})

            model.table_registry[tbl_name] = {
                "table_name": tbl_name,
                "qualified_name": f"{schema}.{tbl_name}",
                "owner": schema,
                "table_type": "TARGET" if is_target else "SOURCE",
                "columns": columns,
                "mapping_name": sheet.name,
            }

            if is_target:
                filter_conds = meta.get("filter_conditions", set())
                if filter_conds:
                    where = " AND ".join(filter_conds)
                    # Translate ISNULL(x) → (x IS NULL) for Snowflake compatibility
                    where = re.sub(
                        r"\bISNULL\s*\(\s*(\w+)\s*\)",
                        r"(\1 IS NULL)",
                        where,
                        flags=re.IGNORECASE,
                    )
                    # Translate NOT ISNULL(x) → (x IS NOT NULL)
                    where = re.sub(
                        r"\bNOT\s*\(\s*(\w+)\s+IS\s+NULL\s*\)",
                        r"(\1 IS NOT NULL)",
                        where,
                        flags=re.IGNORECASE,
                    )
                    model.table_registry[tbl_name]["where_clause"] = where
                join_conds = meta.get("join_conditions", [])
                if join_conds:
                    model.table_registry[tbl_name]["join_clause"] = join_conds[0]
                pks = primary_keys.get(tbl_name, set())
                if pks:
                    model.table_registry[tbl_name]["primary_keys"] = list(pks)
                    model.primary_keys[tbl_name] = list(pks)
                # Store DML operations so strategy detection can use them
                model.table_registry[tbl_name]["dml_operations"] = list(dml_ops)

        return model

    def convert_input(self, sttm_input: STTMInput) -> List[GenerationModel]:
        """Convert all sheets in an STTMInput to GenerationModels."""
        models = []
        for sheet in sttm_input.sheets:
            model = self.convert_sheet(sheet)
            model.source_file = sttm_input.source_file
            if model.target_tables():
                models.append(model)
            else:
                self.logger.warning(f"Sheet '{sheet.name}': no target tables found, skipping")
        return models
