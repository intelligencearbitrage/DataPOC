from .sttm_to_model import SttmConverter
