"""
Base Validator - Abstract base class for validating output artifacts.

Subclass this to create validators for specific quality checks.
"""

from abc import ABC, abstractmethod
from pathlib import Path
from typing import Any, Dict, List

from utils import setup_logging, get_timestamp


class BaseValidator(ABC):
    """Abstract base class for output validators."""

    def __init__(self, target_dir: str = "output"):
        self.target_dir = Path(target_dir)
        self.logger = setup_logging(self.__class__.__name__)

    @abstractmethod
    def validate(self) -> List[Dict[str, str]]:
        """Run validation checks. Return list of issues found."""
        ...

    def check_files_exist(self, expected_files: List[str]) -> List[Dict[str, str]]:
        issues = []
        for file_path in expected_files:
            if not Path(file_path).exists():
                issues.append({
                    "severity": "ERROR",
                    "file": file_path,
                    "message": f"Expected file not found: {file_path}",
                })
        return issues

    def report(self, issues: List[Dict[str, str]]) -> Dict[str, Any]:
        errors = [i for i in issues if i.get("severity") == "ERROR"]
        warnings = [i for i in issues if i.get("severity") == "WARNING"]
        report = {
            "validation_report": {
                "timestamp": get_timestamp(),
                "validator": self.__class__.__name__,
                "summary": {
                    "total_issues": len(issues),
                    "errors": len(errors),
                    "warnings": len(warnings),
                    "passed": len(errors) == 0,
                },
                "issues": issues,
            }
        }
        status = "PASSED" if len(errors) == 0 else "FAILED"
        self.logger.info(f"Validation {status}: {len(errors)} errors, {len(warnings)} warnings")
        return report
