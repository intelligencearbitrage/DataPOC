"""
Base Parser - Abstract base class for parsing input files.

Subclass this to create parsers for specific formats (Excel, JSON, CSV).
"""

from abc import ABC, abstractmethod
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List

from utils import save_yaml, setup_logging


class BaseParser(ABC):
    """Abstract base class for input file parsers."""

    def __init__(self, input_dir: str = "inputs", output_dir: str = "output"):
        self.input_dir = Path(input_dir)
        self.output_dir = Path(output_dir)
        self.parsed_data: Dict[str, Any] = {}
        self.gaps: List[Dict[str, str]] = []
        self.logger = setup_logging(self.__class__.__name__)

    @abstractmethod
    def discover_files(self) -> List[Path]:
        """Find input files to parse. Override per format."""
        ...

    @abstractmethod
    def parse_file(self, file_path: Path) -> Dict[str, Any]:
        """Parse a single input file. Override per format."""
        ...

    def parse_all(self) -> Dict[str, Any]:
        """Parse all discovered files."""
        files = self.discover_files()
        self.logger.info(f"Discovered {len(files)} file(s) to parse")
        for f in files:
            self.logger.info(f"Parsing: {f.name}")
            try:
                self.parsed_data[f.stem] = self.parse_file(f)
            except Exception as e:
                self.logger.error(f"Failed to parse {f.name}: {e}")
                self.gaps.append({
                    "description": f"Failed to parse {f.name}: {e}",
                    "recommendation": "Check file format and retry",
                })
        return self.parsed_data

    def generate_analysis(self) -> Dict[str, Any]:
        return {
            "findings": {
                "metadata": {
                    "source_directory": str(self.input_dir),
                    "date": datetime.now().strftime("%Y-%m-%d"),
                    "files_processed": len(self.parsed_data),
                },
                "summary": {"sources": list(self.parsed_data.keys())},
                "findings": self.parsed_data,
                "gaps": self.gaps,
            }
        }

    def save_analysis(self, filename: str = "analysis.yaml") -> Path:
        analysis = self.generate_analysis()
        output_path = save_yaml(analysis, self.output_dir / filename)
        self.logger.info(f"Analysis saved to: {output_path}")
        return output_path
