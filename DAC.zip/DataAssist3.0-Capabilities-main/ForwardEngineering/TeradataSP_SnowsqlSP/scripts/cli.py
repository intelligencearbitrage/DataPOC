"""
CLI entry point for the Hybrid Teradata-to-Snowflake conversion toolkit.

Combines rule-based conversion with optional LLM review.

Subcommands:
    convert     Run the full pipeline on a single file
    batch       Run batch conversion on a directory
    validate    Run validation only
    audit       Audit previously converted output
    guardrails  Run quality / guardrail checks
"""

import argparse
import os
import subprocess
import sys
from pathlib import Path

from werkzeug.utils import safe_join

SCRIPTS_DIR = Path(__file__).resolve().parent
CONVERSION_PKG = SCRIPTS_DIR / "teradata_to_snowflake_conversion"
PROJECT_ROOT = CONVERSION_PKG
SAFE_ROOT = str(PROJECT_ROOT)
sys.path.insert(0, str(CONVERSION_PKG))


def _safe_path(raw: str, label: str) -> Path:
    """Resolve a user-supplied path, blocking directory traversal."""
    if os.path.isabs(raw):
        raw = os.path.relpath(os.path.abspath(raw), SAFE_ROOT)
    result = safe_join(SAFE_ROOT, raw)
    if result is None:
        raise SystemExit(f"Error: {label} path '{raw}' escapes the allowed directory.")
    return Path(result)


def _run_convert(args):
    """Execute single-file conversion pipeline."""
    from pipeline.analyze_complexity import main as analyze_main
    from pipeline.plan_conversion import main as plan_main
    from pipeline.convert_sql import main as convert_main
    from pipeline.validate_sql import main as validate_main
    from pipeline.correct_sql import main as correct_main
    from pipeline.generate_reports import main as reports_main
    from utils import setup_logging

    logger = setup_logging("CLI", log_dir=PROJECT_ROOT / "thoughts" / "logs")

    input_path = _safe_path(args.input, "input")
    output_path = _safe_path(args.output, "output")
    output_path.mkdir(parents=True, exist_ok=True)

    logger.info("=" * 60)
    logger.info("Hybrid Teradata -> Snowflake Conversion")
    logger.info("=" * 60)
    logger.info(f"  Input:      {input_path}")
    logger.info(f"  Output:     {output_path}")
    logger.info(f"  LLM Review: {not args.no_llm}")
    logger.info("=" * 60)

    phases = [
        ("Analyzing complexity", analyze_main),
        ("Planning conversion", plan_main),
        ("Converting SQL", convert_main),
        ("Validating SQL", validate_main),
        ("Correcting SQL", correct_main),
        ("Generating reports", reports_main),
    ]

    for label, fn in phases:
        logger.info(f"  {label} ...")
        try:
            fn()
        except Exception as e:
            logger.error(f"  FAILED during '{label}': {e}")
            sys.exit(1)

    if not args.no_llm:
        logger.info("  Running LLM review ...")
        try:
            from reviewer.review_converter import ReviewTeradataConverter
            from utils import load_json

            config_path = PROJECT_ROOT / "config" / "converter_config.json"
            config = load_json(config_path) if config_path.exists() else {}
            reviewer = ReviewTeradataConverter(config=config, logger=logger)

            source_sql = input_path.read_text(encoding="utf-8")
            result = reviewer.convert(source_sql)

            if result.success:
                reviewed_out = output_path / input_path.name
                reviewed_out.write_text(result.converted, encoding="utf-8")
                logger.info(f"  LLM review applied {result.fixes_accepted} fix(es).")
            else:
                logger.warning("  LLM review returned unsuccessful result; keeping rules-only output.")
        except Exception as e:
            logger.warning(f"  LLM review failed (non-fatal): {e}")

    logger.info("Pipeline complete.")


def _run_batch(args):
    """Execute batch conversion."""
    try:
        from converter import BatchProcessor
    except ImportError:
        raise SystemExit("Error: batch conversion module not found.")

    config_path = PROJECT_ROOT / "config" / "converter_config.json"
    processor = BatchProcessor(config_file=str(config_path) if config_path.exists() else None)
    processor.process_batch()


def _run_validate(args):
    """Run validation only."""
    from pipeline.validate_sql import main as validate_main

    validate_main()


def _run_audit(args):
    """Run output audit."""
    raise SystemExit(
        "Error: audit_outputs module is not yet implemented. "
        "Use 'validate' to check converted SQL."
    )


def _run_guardrails(args):
    """Run guardrails quality checks."""
    guardrails_script = CONVERSION_PKG / "guardrails" / "run_guardrails.py"
    if not guardrails_script.exists():
        print(f"Error: {guardrails_script} not found", file=sys.stderr)
        sys.exit(1)
    result = subprocess.run([sys.executable, str(guardrails_script)])
    sys.exit(result.returncode)


def main():
    parser = argparse.ArgumentParser(
        prog="hybrid-td-snowsql",
        description="Hybrid Teradata-to-Snowflake conversion (rules + LLM review).",
    )
    subparsers = parser.add_subparsers(dest="command")

    # convert
    cp = subparsers.add_parser("convert", help="Run conversion on a single file.")
    cp.add_argument("--input", required=True, help="Path to a .sql file.")
    cp.add_argument("--output", default=str(PROJECT_ROOT / "output"),
                    help="Output directory.")
    cp.add_argument("--config", default=None, help="Path to converter_config.json.")
    cp.add_argument("--no-llm", action="store_true", help="Skip LLM review step.")

    # batch
    bp = subparsers.add_parser("batch", help="Run batch conversion on a directory.")
    bp.add_argument("--input", required=True, help="Directory of .sql files.")
    bp.add_argument("--output", default=str(PROJECT_ROOT / "output"),
                    help="Output directory.")
    bp.add_argument("--no-llm", action="store_true", help="Skip LLM review step.")

    # validate
    vp = subparsers.add_parser("validate", help="Run validation only.")
    vp.add_argument("--input", required=True, help="Converted .sql file or directory.")

    # audit
    ap = subparsers.add_parser("audit", help="Audit converted output.")
    ap.add_argument("--output", default=str(PROJECT_ROOT / "output"),
                    help="Output directory to audit.")

    # guardrails
    subparsers.add_parser("guardrails", help="Run guardrail quality checks.")

    args = parser.parse_args()

    if args.command == "convert":
        _run_convert(args)
    elif args.command == "batch":
        _run_batch(args)
    elif args.command == "validate":
        _run_validate(args)
    elif args.command == "audit":
        _run_audit(args)
    elif args.command == "guardrails":
        _run_guardrails(args)
    else:
        parser.print_help()
        sys.exit(1)


if __name__ == "__main__":
    main()
