"""
Review Converter — Rules-First with LLM Review
=================================================

Orchestrates the conversion of Teradata SQL to Snowflake SQL using:
  1. Full rules-based conversion (TeradataToSnowflakeConverter)
  2. Validation of rules output
  3. LLM review of the conversion (sends both original + converted)
  4. Per-fix validation gating (each fix must not degrade score)

The rules engine output is ALWAYS the baseline. The LLM can only improve
it — each fix is applied individually and re-validated. If a fix degrades
the validation score, it is rejected.

Usage:
    from review_converter import ReviewTeradataConverter
    converter = ReviewTeradataConverter(config=config)
    result = converter.convert(teradata_sql)
"""

import logging
import re
from typing import Optional, Dict, List
from dataclasses import dataclass, field

from converter import TeradataToSnowflakeConverter, ConversionResult
from validators import ConversionValidator
from .llm_reviewer import LLMReviewer, ReviewFix, ReviewResult


@dataclass
class ReviewConversionResult:
    """Result of a review-based conversion."""
    original: str
    converted: str
    rules_applied: List[str] = field(default_factory=list)
    warnings: List[str] = field(default_factory=list)
    errors: List[str] = field(default_factory=list)
    success: bool = True
    # Review-specific metadata
    review_applied: bool = False
    review_available: bool = False
    fixes_suggested: int = 0
    fixes_accepted: int = 0
    fixes_rejected: int = 0
    accepted_fix_details: List[Dict] = field(default_factory=list)
    rejected_fix_details: List[Dict] = field(default_factory=list)
    review_summary: str = ""
    llm_input_tokens: int = 0
    llm_output_tokens: int = 0
    llm_latency_seconds: float = 0.0
    rules_validation_score: float = 0.0
    final_validation_score: float = 0.0


class ReviewTeradataConverter:
    """
    Rules-first converter with LLM review layer.

    Pipeline:
    1. Convert with rules engine (TeradataToSnowflakeConverter)
    2. Validate the rules output
    3. Send original + converted + validation issues to LLM reviewer
    4. Apply LLM fixes (filtered by confidence)
    5. Re-validate after each fix
    6. Accept/reject each fix based on validation improvement
    """

    def __init__(
        self,
        config: Optional[Dict] = None,
        logger: Optional[logging.Logger] = None
    ):
        self.config = config or {}
        self.logger = logger or logging.getLogger(__name__)

        # Initialize rule-based converter
        self.rule_converter = TeradataToSnowflakeConverter(
            config=self.config,
            logger=self.logger
        )

        # Initialize LLM reviewer
        self.llm_reviewer = LLMReviewer(
            config=self.config,
            logger=self.logger
        )

        # Initialize validator
        self.validator = ConversionValidator()

        # Review settings
        review_config = self.config.get('llm_review', {})
        self.review_enabled = review_config.get('enabled', True)
        self.force_review = review_config.get('force_review', False)

    def convert(self, sql: str) -> ReviewConversionResult:
        """
        Convert Teradata SQL to Snowflake using rules-first + LLM review.

        Args:
            sql: Full Teradata SQL (typically a stored procedure).

        Returns:
            ReviewConversionResult with converted SQL and metadata.
        """
        self.logger.info("=" * 50)
        self.logger.info("Review converter: starting conversion")
        self.logger.info("=" * 50)

        # Step 1: Full rules-based conversion
        self.logger.info("Step 1: Rules-based conversion")
        rules_result = self.rule_converter.convert(sql)

        self.logger.info(
            f"  Rules applied: {len(rules_result.rules_applied)}, "
            f"Warnings: {len(rules_result.warnings)}"
        )

        # Step 2: Validate the rules output
        self.logger.info("Step 2: Validating rules output")
        validation = self.validator.validate(rules_result.converted)
        rules_score = validation.score

        self.logger.info(
            f"  Validation: score={rules_score}%, "
            f"errors={validation.errors}, "
            f"warnings={validation.warnings}"
        )

        # Step 3: Decide whether to run LLM review
        review_available = (
            self.review_enabled and self.llm_reviewer.is_available()
        )

        should_review = False
        if review_available:
            if self.force_review:
                should_review = True
                self.logger.info("Step 3: LLM review (forced by config)")
            elif not validation.is_valid:
                should_review = True
                self.logger.info(
                    "Step 3: LLM review (validation has issues)"
                )
            else:
                self.logger.info(
                    "Step 3: Skipping LLM review (validation passed)"
                )
        else:
            if not self.review_enabled:
                self.logger.info(
                    "Step 3: LLM review disabled in config"
                )
            else:
                self.logger.warning(
                    "Step 3: LLM review not available (no credentials)"
                )

        # If no review, return rules-only result
        if not should_review:
            # Post-process: ensure flat Snowflake EXCEPTION structure
            final_converted = self._restructure_flat_exception(
                rules_result.converted
            )
            return ReviewConversionResult(
                original=sql,
                converted=final_converted,
                rules_applied=rules_result.rules_applied,
                warnings=rules_result.warnings,
                errors=rules_result.errors,
                success=rules_result.success,
                review_applied=False,
                review_available=review_available,
                rules_validation_score=rules_score,
                final_validation_score=rules_score,
            )

        # Step 4: LLM review
        # Format validation issues for the reviewer
        formatted_issues = self._format_validation_issues(validation)

        review_result = self.llm_reviewer.review(
            original_sql=sql,
            converted_sql=rules_result.converted,
            validation_issues=formatted_issues if formatted_issues else None,
        )

        if not review_result.success:
            self.logger.warning(
                f"  LLM review failed: {review_result.error}. "
                f"Using rules-only output."
            )
            return ReviewConversionResult(
                original=sql,
                converted=rules_result.converted,
                rules_applied=rules_result.rules_applied,
                warnings=rules_result.warnings + [
                    f"LLM review failed: {review_result.error}"
                ],
                errors=rules_result.errors,
                success=rules_result.success,
                review_applied=False,
                review_available=True,
                rules_validation_score=rules_score,
                final_validation_score=rules_score,
                llm_input_tokens=review_result.input_tokens,
                llm_output_tokens=review_result.output_tokens,
                llm_latency_seconds=review_result.latency_seconds,
            )

        self.logger.info(
            f"  LLM suggested {len(review_result.fixes)} fix(es)"
        )

        # Step 5: Apply fixes one at a time with validation gating
        final_sql = rules_result.converted
        current_score = rules_score
        accepted_fixes = []
        rejected_fixes = []

        for fix in review_result.fixes:
            # Check confidence threshold
            if not self.llm_reviewer.meets_confidence_threshold(fix):
                reason = (
                    f"below confidence threshold "
                    f"({fix.confidence} < {self.llm_reviewer.min_confidence})"
                )
                rejected_fixes.append({
                    'fix_id': fix.fix_id,
                    'description': fix.description,
                    'confidence': fix.confidence,
                    'category': fix.category,
                    'reason': reason,
                })
                self.logger.info(
                    f"  Fix #{fix.fix_id} rejected: {reason}"
                )
                continue

            # Check that original_text exists in the SQL
            if fix.original_text not in final_sql:
                reason = "original_text not found in converted SQL"
                rejected_fixes.append({
                    'fix_id': fix.fix_id,
                    'description': fix.description,
                    'confidence': fix.confidence,
                    'category': fix.category,
                    'reason': reason,
                })
                self.logger.info(
                    f"  Fix #{fix.fix_id} rejected: {reason}"
                )
                continue

            # Apply the fix
            candidate = final_sql.replace(
                fix.original_text, fix.replacement_text, 1
            )

            # Safety check: reject fixes that delete too much code.
            # If the fix reduces the overall SQL size by >30%, the LLM
            # is likely replacing the procedure body rather than fixing it.
            size_ratio = len(candidate) / max(len(final_sql), 1)
            if size_ratio < 0.70:
                reason = (
                    f"fix deletes too much code "
                    f"({len(final_sql)} → {len(candidate)} chars, "
                    f"{100 - size_ratio * 100:.0f}% reduction)"
                )
                rejected_fixes.append({
                    'fix_id': fix.fix_id,
                    'description': fix.description,
                    'confidence': fix.confidence,
                    'category': fix.category,
                    'reason': reason,
                })
                self.logger.info(
                    f"  Fix #{fix.fix_id} rejected: {reason}"
                )
                continue

            # Re-validate
            new_validation = self.validator.validate(candidate)
            new_score = new_validation.score

            # Accept if validation score didn't decrease
            if new_score >= current_score:
                final_sql = candidate
                current_score = new_score
                accepted_fixes.append({
                    'fix_id': fix.fix_id,
                    'description': fix.description,
                    'confidence': fix.confidence,
                    'category': fix.category,
                    'score_before': rules_score,
                    'score_after': new_score,
                })
                self.logger.info(
                    f"  Fix #{fix.fix_id} accepted: {fix.description} "
                    f"(score: {current_score}%)"
                )
            else:
                reason = (
                    f"validation score decreased "
                    f"({current_score}% → {new_score}%)"
                )
                rejected_fixes.append({
                    'fix_id': fix.fix_id,
                    'description': fix.description,
                    'confidence': fix.confidence,
                    'category': fix.category,
                    'reason': reason,
                })
                self.logger.info(
                    f"  Fix #{fix.fix_id} rejected: {reason}"
                )

        self.logger.info(
            f"  Review complete: {len(accepted_fixes)} accepted, "
            f"{len(rejected_fixes)} rejected"
        )

        # Build combined rules list
        all_rules = list(rules_result.rules_applied)
        for fix in accepted_fixes:
            all_rules.append(
                f"llm_review_fix: {fix['description']} "
                f"[{fix['confidence']}/{fix['category']}]"
            )

        # Build combined warnings
        all_warnings = list(rules_result.warnings)
        for fix in rejected_fixes:
            all_warnings.append(
                f"LLM fix #{fix['fix_id']} rejected: "
                f"{fix['description']} ({fix['reason']})"
            )

        # Post-process: ensure flat Snowflake EXCEPTION structure
        final_sql = self._restructure_flat_exception(final_sql)

        # Post-process: strip : prefix from scripting contexts that LLM may
        # have (re-)introduced.  The rules engine already does this, but the
        # LLM review can add `:var` inside assignments / IF / RETURN.
        final_sql = self._strip_colon_from_scripting_contexts(final_sql)

        return ReviewConversionResult(
            original=sql,
            converted=final_sql,
            rules_applied=all_rules,
            warnings=all_warnings,
            errors=rules_result.errors,
            success=rules_result.success,
            review_applied=True,
            review_available=True,
            fixes_suggested=len(review_result.fixes),
            fixes_accepted=len(accepted_fixes),
            fixes_rejected=len(rejected_fixes),
            accepted_fix_details=accepted_fixes,
            rejected_fix_details=rejected_fixes,
            review_summary=review_result.summary,
            llm_input_tokens=review_result.input_tokens,
            llm_output_tokens=review_result.output_tokens,
            llm_latency_seconds=review_result.latency_seconds,
            rules_validation_score=rules_score,
            final_validation_score=current_score,
        )

    def _strip_colon_from_scripting_contexts(self, sql: str) -> str:
        """Remove : prefix from variables in Snowflake scripting contexts.

        In Snowflake SQL Scripting the : prefix is only valid inside
        embedded SQL statements (INSERT/SELECT/DELETE/UPDATE/MERGE).
        Variables in assignments (:=), IF/ELSEIF conditions, WHILE
        conditions, and RETURN statements must NOT have the : prefix.

        The rules engine already performs this cleanup, but the LLM
        review layer can reintroduce incorrect : prefixes, so we
        run this as a final post-processing pass.
        """
        # Collect declared variable names from the DECLARE block
        var_names = set()
        declare_match = re.search(
            r'DECLARE\s*\n([\s\S]*?)\nBEGIN',
            sql, re.IGNORECASE
        )
        if declare_match:
            for line in declare_match.group(1).split('\n'):
                m = re.match(r'\s*(\w+)\s+\w', line)
                if m:
                    var_names.add(m.group(1).upper())

        # Also extract procedure parameter names from the signature
        param_match = re.search(
            r'CREATE\s+OR\s+REPLACE\s+PROCEDURE\s+[\w.\s]+?\(([\s\S]*?)\)\s*\n\s*RETURNS',
            sql, re.IGNORECASE
        )
        if param_match:
            for line in param_match.group(1).split('\n'):
                m = re.match(r'\s*,?\s*(?:IN\s+|OUT\s+|INOUT\s+)?(\w+)\s+\w', line, re.IGNORECASE)
                if m:
                    var_names.add(m.group(1).upper())

        if not var_names:
            return sql

        var_pattern = '|'.join(re.escape(v) for v in var_names)
        var_re = re.compile(rf':({var_pattern})\b', re.IGNORECASE)

        # C1: Assignments — strip : from right side of :=
        def _strip_assign_rhs(m):
            lhs = m.group(1)
            rhs = m.group(2)
            # Don't strip inside embedded SQL (SELECT/INSERT inside assignment)
            if re.search(r'\b(SELECT|INSERT|DELETE|UPDATE|MERGE)\b', rhs, re.IGNORECASE):
                return m.group(0)
            return lhs + var_re.sub(r'\1', rhs)

        sql = re.sub(r'(\w+\s*:=\s*)([^;]*;)', _strip_assign_rhs, sql)

        # C2: IF/ELSEIF conditions — strip : between IF/ELSEIF and THEN
        # but NOT for IF EXISTS or IF with embedded SQL subquery
        def _strip_if_cond(m):
            text = m.group(0)
            if re.search(r'\bSELECT\b', text, re.IGNORECASE):
                return text
            return var_re.sub(r'\1', text)

        sql = re.sub(
            r'\b(?:IF|ELSEIF)\b(?!\s+EXISTS)\s.*?\bTHEN\b',
            _strip_if_cond,
            sql, flags=re.IGNORECASE
        )

        # C3: WHILE conditions — strip : in WHILE ... DO/LOOP
        def _strip_while_cond(m):
            text = m.group(0)
            if re.search(r'\bSELECT\b', text, re.IGNORECASE):
                return text
            return var_re.sub(r'\1', text)

        sql = re.sub(
            r'\bWHILE\b\s.*?(?:\bDO\b|\bLOOP\b|\n)',
            _strip_while_cond,
            sql, flags=re.IGNORECASE
        )

        # C4: RETURN statements — strip : from RETURN expression
        def _strip_return_expr(m):
            return var_re.sub(r'\1', m.group(0))

        sql = re.sub(
            r'\bRETURN\b\s[^;]*;',
            _strip_return_expr,
            sql, flags=re.IGNORECASE
        )

        return sql

    def _restructure_flat_exception(self, sql: str) -> str:
        """Restructure nested BEGIN/EXCEPTION/END into flat Snowflake SP structure.

        Snowflake requires: DECLARE -> BEGIN -> statements -> EXCEPTION -> END
          - Single BEGIN/END pair per block
          - EXCEPTION must be the last section before END
          - No statements after EXCEPTION...END

        Detects the double-BEGIN pattern left over from Teradata labeled blocks
        (MAIN: BEGIN ... INNER: BEGIN ... END INNER; END MAIN;) and
        restructures it so that:
          1. Post-exception code (success logging / IF-ELSE) moves before EXCEPTION
          2. The redundant inner BEGIN and extra END are removed
          3. EXCEPTION is the last section before the single END;

        This runs as a final structural pass after both rules and LLM review,
        catching cases where the LLM added an EXCEPTION block to an
        already-nested structure.
        """
        if '$$' not in sql:
            return sql

        dollar_parts = sql.split('$$')
        if len(dollar_parts) < 3:
            return sql

        body = dollar_parts[1]

        # Strip comments for structural analysis.
        # IMPORTANT: strip /* */ FIRST, then -- comments.
        # Reversing this order causes -- to eat */ closers on lines like
        # "---...--- */" inside block comments.
        cleaned = re.sub(r'/\*[\s\S]*?\*/', '', body)
        cleaned = re.sub(r'--[^\n]*', '', cleaned)

        # Detect double BEGIN (only whitespace between first two)
        begins = list(re.finditer(r'\bBEGIN\b', cleaned, re.IGNORECASE))
        if len(begins) < 2:
            return sql

        between = cleaned[begins[0].end():begins[1].start()].strip()
        if between:
            return sql  # Real code between BEGINs — not a simple double

        # Find EXCEPTION in the original body
        exception_match = re.search(
            r'^\s*EXCEPTION\b', body, re.IGNORECASE | re.MULTILINE
        )
        if not exception_match:
            return sql  # No EXCEPTION — nothing to restructure

        # Find all bare END; positions (not END IF, END LOOP, etc.)
        bare_end_re = re.compile(
            r'\bEND\b(?!\s+(?:IF|LOOP|FOR|WHILE)\b)\s*;',
            re.IGNORECASE
        )
        bare_ends = list(bare_end_re.finditer(body))
        if len(bare_ends) < 2:
            return sql

        inner_end = bare_ends[-2]
        outer_end = bare_ends[-1]

        # Verify EXCEPTION is before inner_end (inside the inner block)
        if exception_match.start() > inner_end.start():
            return sql

        # Get code between inner END and outer END
        between_ends = body[inner_end.end():outer_end.start()].strip()

        # Extract exception handler (from EXCEPTION to inner END, excluding inner END)
        exception_handler = body[exception_match.start():inner_end.start()].rstrip()

        # Build the before-exception part (everything up to EXCEPTION keyword)
        before_exception = body[:exception_match.start()].rstrip()

        # After outer END
        after_outer = body[outer_end.end():]

        # Reconstruct body:
        #   before_exception (work code, minus second BEGIN)
        #   + between_ends code (success/IF-ELSE code, moved here)
        #   + exception_handler (EXCEPTION ... handler body)
        #   + outer END;
        new_body = before_exception + '\n\n'
        if between_ends:
            new_body += between_ends + '\n\n'
        new_body += exception_handler + '\n'
        new_body += body[outer_end.start():outer_end.end()]
        new_body += after_outer

        # Remove the second BEGIN line (redundant inner BEGIN)
        actual_begins = list(re.finditer(r'\bBEGIN\b', new_body, re.IGNORECASE))
        if len(actual_begins) >= 2:
            second = actual_begins[1]
            line_start = new_body.rfind('\n', 0, second.start())
            line_end = new_body.find('\n', second.end())
            if line_start == -1:
                line_start = 0
            if line_end == -1:
                line_end = len(new_body)
            begin_line = new_body[line_start:line_end].strip()
            if begin_line.upper() == 'BEGIN':
                new_body = new_body[:line_start] + new_body[line_end:]

        dollar_parts[1] = new_body
        result = '$$'.join(dollar_parts)

        self.logger.info(
            "  Post-process: Restructured to flat Snowflake "
            "EXCEPTION pattern (single BEGIN/END)"
        )
        return result

    def _format_validation_issues(self, validation) -> List[Dict]:
        """Format validation issues for the LLM reviewer."""
        formatted = []
        for issue in validation.issues:
            formatted.append({
                'rule_name': issue.rule_name,
                'severity': issue.severity.value,
                'message': issue.message,
                'line_number': issue.line_number,
                'matched_text': issue.matched_text[:200] if issue.matched_text else '',
            })
        return formatted
