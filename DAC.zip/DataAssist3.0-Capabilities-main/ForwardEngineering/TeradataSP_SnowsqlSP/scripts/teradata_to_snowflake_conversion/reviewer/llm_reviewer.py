"""
LLM Reviewer — Review-Based SQL Conversion Enhancement
=========================================================

Reviews rules-converted Snowflake SQL using an LLM and suggests targeted fixes.
Unlike the block-router approach (HybridConversion), this client:
  - Receives BOTH original Teradata SQL AND rules-converted Snowflake SQL
  - Asks the LLM to review the conversion and suggest targeted fixes as JSON
  - Returns structured ReviewFix objects (not full SQL rewrites)

This ensures:
  - Full cross-block context (LLM sees the entire procedure)
  - Minimal token usage (LLM outputs only small JSON fixes, not full SQL)
  - No truncation risk (max_tokens is for a small JSON array)
  - Rules engine output is always the baseline fallback

Configuration via environment variables:
  - ANTHROPIC_FOUNDRY_API_KEY: API key for Foundry authentication
  - ANTHROPIC_FOUNDRY_RESOURCE: Foundry resource name
  - ANTHROPIC_MODEL: Model to use (default: claude-sonnet-4-6)

Falls back to:
  - ANTHROPIC_API_KEY + ANTHROPIC_BASE_URL for direct Anthropic API

Usage:
    from llm_reviewer import LLMReviewer
    reviewer = LLMReviewer(config=config)
    result = reviewer.review(original_sql, converted_sql)
"""

import os
import re
import json
import logging
import time
from typing import Optional, Dict, List
from pathlib import Path
from dataclasses import dataclass, field

try:
    import anthropic
    HAS_ANTHROPIC = True
    HAS_FOUNDRY = hasattr(anthropic, 'AnthropicFoundry')
except ImportError:
    HAS_ANTHROPIC = False
    HAS_FOUNDRY = False

try:
    from dotenv import load_dotenv
    _project_root = Path(__file__).resolve().parent.parent
    load_dotenv(_project_root / '.env')
except ImportError:
    pass


REVIEW_SYSTEM_PROMPT = """You are an expert SQL migration reviewer specializing in Teradata to Snowflake conversions.

You receive:
1. **Original Teradata SQL** — the source stored procedure
2. **Machine-converted Snowflake SQL** — output from a rules-based conversion engine
3. **Validation issues** (if any) — problems detected by automated validation

Your job is to review the conversion and suggest TARGETED FIXES only where the rules engine made errors or missed conversions.

## Important Guidelines

- Do NOT rewrite the entire SQL. Only suggest specific, minimal fixes.
- Each fix must identify the EXACT text in the converted SQL that needs to change.
- The `original_text` field must be an exact substring of the converted Snowflake SQL.
- Only suggest fixes where you are CONFIDENT the conversion is wrong or incomplete.
- Do NOT suggest cosmetic changes (formatting, indentation, comments, whitespace).
- If the conversion looks correct, return an empty fixes array.

## Common Issues to Look For

1. **Teradata syntax not converted**: BT/ET, VOLATILE TABLE, SEL, SAMPLE, etc.
2. **Function mismatches**: ADD_MONTHS, OREPLACE, NULLIFZERO, ZEROIFNULL, etc.
3. **Date/interval patterns**: CAST((d1-d2) MONTH(n) AS INTEGER) should be DATEDIFF
4. **Missing variable colon prefixes**: Snowflake SQL Scripting requires `:var` in SQL contexts
5. **Schema mapping errors**: Teradata schema names not mapped to Snowflake equivalents
6. **Procedure structure issues**: Missing $$ delimiters, RETURNS clause, etc.
7. **UPDATE FROM patterns**: Should become MERGE INTO in Snowflake
8. **Data type conversions**: BYTEINT→TINYINT, LONG VARCHAR→VARCHAR(16777216), etc.

## Response Format

You MUST respond with valid JSON in exactly this format:
```json
{
    "fixes": [
        {
            "fix_id": 1,
            "description": "Brief description of what this fix corrects",
            "original_text": "exact text from converted SQL to find",
            "replacement_text": "the corrected replacement text",
            "confidence": "high",
            "category": "syntax"
        }
    ],
    "summary": "Brief overall assessment of the conversion quality"
}
```

Confidence levels:
- **high**: Certain this is a bug in the conversion
- **medium**: Likely a bug, but edge cases possible
- **low**: Possible improvement, but might be intentional

Categories: syntax, function, semantic, missing_conversion, data_type, procedure_structure

If no fixes needed, return: {"fixes": [], "summary": "Conversion looks correct."}
"""


@dataclass
class ReviewFix:
    """A single fix suggested by the LLM reviewer."""
    fix_id: int
    description: str
    original_text: str
    replacement_text: str
    confidence: str  # "high", "medium", "low"
    category: str    # "syntax", "function", "semantic", "missing_conversion", etc.


@dataclass
class ReviewResult:
    """Result of an LLM review."""
    fixes: List[ReviewFix] = field(default_factory=list)
    summary: str = ""
    model: str = ""
    input_tokens: int = 0
    output_tokens: int = 0
    latency_seconds: float = 0.0
    success: bool = True
    error: Optional[str] = None


class LLMReviewer:
    """
    Reviews rules-converted SQL using an LLM and suggests targeted fixes.
    """

    def __init__(
        self,
        config: Optional[Dict] = None,
        logger: Optional[logging.Logger] = None
    ):
        self.config = config or {}
        self.logger = logger or logging.getLogger(__name__)

        # LLM review settings from config
        review_config = self.config.get('llm_review', {})

        # Foundry credentials (preferred)
        self.foundry_api_key = (
            review_config.get('foundry_api_key')
            or os.environ.get('ANTHROPIC_FOUNDRY_API_KEY', '')
        )
        self.foundry_resource = (
            review_config.get('foundry_resource')
            or os.environ.get('ANTHROPIC_FOUNDRY_RESOURCE', '')
        )

        # Fallback: direct Anthropic API
        self.api_key = (
            review_config.get('api_key')
            or os.environ.get('ANTHROPIC_API_KEY', '')
        )
        self.base_url = (
            review_config.get('base_url')
            or os.environ.get('ANTHROPIC_BASE_URL', '')
        )

        # Model and params
        self.model = (
            review_config.get('model')
            or os.environ.get('ANTHROPIC_MODEL', 'claude-opus-4-6')
        )
        self.max_tokens = review_config.get('max_tokens', 4096)
        self.temperature = review_config.get('temperature', 0.0)
        self.max_retries = review_config.get('max_retries', 2)
        self.retry_delay = review_config.get('retry_delay', 2)
        self.min_confidence = review_config.get('min_confidence', 'medium')

        # Determine client mode
        self._use_foundry = bool(self.foundry_api_key and self.foundry_resource)
        self._client = None
        self._validate_config()

    def _validate_config(self):
        """Validate LLM configuration."""
        if not HAS_ANTHROPIC:
            self.logger.error(
                "anthropic package not installed. Run: pip install anthropic"
            )
            return

        if self._use_foundry:
            if not HAS_FOUNDRY:
                self.logger.error(
                    "anthropic package too old for Foundry. "
                    "Run: pip install --upgrade anthropic"
                )
            else:
                self.logger.info(
                    f"LLM Reviewer (Foundry): resource={self.foundry_resource}, "
                    f"model={self.model}"
                )
        elif self.api_key:
            self.logger.info(
                f"LLM Reviewer (Direct API): model={self.model}"
            )
        else:
            self.logger.warning(
                "No LLM credentials found. Set ANTHROPIC_FOUNDRY_API_KEY + "
                "ANTHROPIC_FOUNDRY_RESOURCE in .env, or "
                "ANTHROPIC_API_KEY for direct API access."
            )

    def _get_client(self):
        """Get or create the appropriate Anthropic client."""
        if self._client is None:
            if not HAS_ANTHROPIC:
                raise ImportError(
                    "anthropic package is required. Install with: pip install anthropic"
                )

            if self._use_foundry and HAS_FOUNDRY:
                self._client = anthropic.AnthropicFoundry(
                    resource=self.foundry_resource,
                    api_key=self.foundry_api_key,
                )
                self.logger.debug("Created AnthropicFoundry client for review")
            else:
                client_kwargs = {'api_key': self.api_key}
                if self.base_url:
                    client_kwargs['base_url'] = self.base_url
                self._client = anthropic.Anthropic(**client_kwargs)
                self.logger.debug("Created Anthropic client for review")

        return self._client

    def review(
        self,
        original_sql: str,
        converted_sql: str,
        validation_issues: Optional[List[Dict]] = None
    ) -> ReviewResult:
        """
        Review a rules-converted SQL and suggest targeted fixes.

        Args:
            original_sql: The original Teradata SQL.
            converted_sql: The rules-converted Snowflake SQL.
            validation_issues: Optional list of validation issues from the validator.

        Returns:
            ReviewResult with suggested fixes and metadata.
        """
        user_message = self._build_review_prompt(
            original_sql, converted_sql, validation_issues
        )

        for attempt in range(1, self.max_retries + 1):
            try:
                start_time = time.time()
                client = self._get_client()

                response = client.messages.create(
                    model=self.model,
                    max_tokens=self.max_tokens,
                    temperature=self.temperature,
                    system=REVIEW_SYSTEM_PROMPT,
                    messages=[
                        {"role": "user", "content": user_message}
                    ]
                )

                latency = time.time() - start_time

                # Extract text content
                response_text = ""
                for block in response.content:
                    if block.type == "text":
                        response_text += block.text

                # Parse the JSON response
                fixes = self._parse_review_response(response_text)

                result = ReviewResult(
                    fixes=fixes,
                    summary=self._extract_summary(response_text),
                    model=self.model,
                    input_tokens=response.usage.input_tokens,
                    output_tokens=response.usage.output_tokens,
                    latency_seconds=round(latency, 2),
                    success=True,
                )

                self.logger.info(
                    f"LLM review: {len(fixes)} fixes suggested, "
                    f"{response.usage.input_tokens} in, "
                    f"{response.usage.output_tokens} out, "
                    f"{latency:.1f}s"
                )

                return result

            except Exception as e:
                self.logger.warning(
                    f"LLM review attempt {attempt}/{self.max_retries} failed: {e}"
                )
                if attempt < self.max_retries:
                    time.sleep(self.retry_delay * attempt)
                else:
                    return ReviewResult(
                        success=False,
                        error=str(e),
                        model=self.model,
                    )

    def _build_review_prompt(
        self,
        original_sql: str,
        converted_sql: str,
        validation_issues: Optional[List[Dict]] = None
    ) -> str:
        """Build the user message for the LLM reviewer."""
        parts = []

        parts.append("## Original Teradata SQL\n")
        parts.append(original_sql)
        parts.append("\n\n## Machine-Converted Snowflake SQL\n")
        parts.append(converted_sql)

        if validation_issues:
            parts.append("\n\n## Validation Issues Found\n")
            for issue in validation_issues:
                line = issue.get('line_number', '?')
                rule = issue.get('rule_name', '?')
                msg = issue.get('message', '?')
                matched = issue.get('matched_text', '')
                parts.append(f"- Line {line}: [{rule}] {msg}")
                if matched:
                    parts.append(f"  Matched: `{matched}`")

        parts.append(
            "\n\nReview the conversion above and return a JSON object with "
            "targeted fixes. Return ONLY the JSON, no other text."
        )

        return '\n'.join(parts)

    def _parse_review_response(self, response_text: str) -> List[ReviewFix]:
        """Parse structured JSON fixes from the LLM response."""
        # Clean response — strip markdown fences if present
        cleaned = response_text.strip()
        cleaned = re.sub(r'^```(?:json)?\s*\n?', '', cleaned, flags=re.MULTILINE)
        cleaned = re.sub(r'\n?```\s*$', '', cleaned, flags=re.MULTILINE)
        cleaned = cleaned.strip()

        try:
            data = json.loads(cleaned)
        except json.JSONDecodeError as e:
            self.logger.warning(f"Failed to parse LLM review response as JSON: {e}")
            # Try to extract JSON from the response
            json_match = re.search(r'\{[\s\S]*\}', cleaned)
            if json_match:
                try:
                    data = json.loads(json_match.group(0))
                except json.JSONDecodeError:
                    self.logger.error("Could not extract valid JSON from LLM response")
                    return []
            else:
                return []

        fixes = []
        fix_list = data.get('fixes', []) if isinstance(data, dict) else data

        for fix_data in fix_list:
            if not isinstance(fix_data, dict):
                continue

            original_text = fix_data.get('original_text', '')
            replacement_text = fix_data.get('replacement_text', '')

            # Skip empty or identical fixes
            if not original_text or original_text == replacement_text:
                continue

            fix = ReviewFix(
                fix_id=fix_data.get('fix_id', len(fixes) + 1),
                description=fix_data.get('description', ''),
                original_text=original_text,
                replacement_text=replacement_text,
                confidence=fix_data.get('confidence', 'low'),
                category=fix_data.get('category', 'unknown'),
            )
            fixes.append(fix)

        return fixes

    def _extract_summary(self, response_text: str) -> str:
        """Extract the summary field from the JSON response."""
        cleaned = response_text.strip()
        cleaned = re.sub(r'^```(?:json)?\s*\n?', '', cleaned, flags=re.MULTILINE)
        cleaned = re.sub(r'\n?```\s*$', '', cleaned, flags=re.MULTILINE)

        try:
            data = json.loads(cleaned.strip())
            if isinstance(data, dict):
                return data.get('summary', '')
        except json.JSONDecodeError:
            json_match = re.search(r'\{[\s\S]*\}', cleaned)
            if json_match:
                try:
                    data = json.loads(json_match.group(0))
                    return data.get('summary', '')
                except json.JSONDecodeError:
                    pass
        return ''

    def is_available(self) -> bool:
        """Check if the LLM reviewer is configured and available."""
        if not HAS_ANTHROPIC:
            return False
        if self._use_foundry:
            return HAS_FOUNDRY
        return bool(self.api_key)

    def meets_confidence_threshold(self, fix: ReviewFix) -> bool:
        """Check if a fix meets the minimum confidence threshold."""
        confidence_order = {'high': 3, 'medium': 2, 'low': 1}
        fix_level = confidence_order.get(fix.confidence, 0)
        min_level = confidence_order.get(self.min_confidence, 2)
        return fix_level >= min_level
