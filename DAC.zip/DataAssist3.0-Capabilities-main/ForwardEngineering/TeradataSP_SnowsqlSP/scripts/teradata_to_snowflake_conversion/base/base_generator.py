"""
Base Generator - Abstract base class for generating output artifacts.

Subclass this to create generators for specific deliverable types.
The builder agent creates subclasses based on the deliverables defined in prompts.md.

Usage:
    class SQLGenerator(BaseGenerator):
        def generate(self):
            plans = self.load_plans()
            for name, plan in plans.items():
                output = self.process_component(plan)
                self.save_output(output, f'{name}/deliverable.sql')

    generator = SQLGenerator(plans_dir='plans', output_dir='output')
    generator.generate()
"""

from abc import ABC, abstractmethod
from pathlib import Path
from typing import Any, Dict

from utils import load_yaml, load_all_yaml, save_yaml, setup_logging


class BaseGenerator(ABC):
    """Abstract base class for output generators."""

    def __init__(self, plans_dir: str = 'plans', output_dir: str = 'output'):
        self.plans_dir = Path(plans_dir)
        self.output_dir = Path(output_dir)
        self.logger = setup_logging(self.__class__.__name__)

    def load_master_plan(self) -> Dict[str, Any]:
        """Load the MASTER_PLAN.yaml file."""
        master_plan_path = self.plans_dir / 'MASTER_PLAN.yaml'
        plan = load_yaml(master_plan_path)
        if not plan:
            self.logger.warning("MASTER_PLAN.yaml not found or empty")
        return plan

    def load_plans(self) -> Dict[str, Dict]:
        """Load all plan YAML files from plans/ directory."""
        plans = load_all_yaml(self.plans_dir)
        self.logger.info(f"Loaded {len(plans)} plan file(s)")
        return plans

    @abstractmethod
    def generate(self) -> None:
        """Generate output artifacts from plans. Override in subclass."""
        ...

    def save_output(self, content: str, relative_path: str) -> Path:
        """Save generated content to output directory."""
        output_path = self.output_dir / relative_path
        output_path.parent.mkdir(parents=True, exist_ok=True)
        output_path.write_text(content, encoding='utf-8')
        self.logger.info(f"Output saved: {output_path}")
        return output_path

    def save_output_yaml(self, data: Dict[str, Any], relative_path: str) -> Path:
        """Save generated data as YAML to output directory."""
        output_path = self.output_dir / relative_path
        save_yaml(data, output_path)
        self.logger.info(f"YAML output saved: {output_path}")
        return output_path


def main():
    """Example usage - override this in your subclass module."""
    print("BaseGenerator is abstract. Create a subclass for your specific deliverable.")
    print("See .claude/skills/generate-output.md for patterns.")


if __name__ == '__main__':
    main()
