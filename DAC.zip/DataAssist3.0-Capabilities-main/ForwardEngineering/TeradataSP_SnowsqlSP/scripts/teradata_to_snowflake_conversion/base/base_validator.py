"""
Base Validator - Abstract base class for validating output artifacts.

Subclass this to create validators for specific quality checks.
The reviewer agent uses these to verify correctness and completeness.

Usage:
    class SQLValidator(BaseValidator):
        def validate(self):
            issues = []
            issues.extend(self.check_files_exist())
            issues.extend(self.check_content_quality())
            return issues

    validator = SQLValidator(target_dir='output')
    issues = validator.validate()
    validator.report(issues)
"""

from abc import ABC, abstractmethod
from pathlib import Path
from typing import Any, Dict, List

import yaml

from utils import setup_logging, get_timestamp


class BaseValidator(ABC):
    """Abstract base class for output validators."""

    def __init__(self, target_dir: str = 'output'):
        self.target_dir = Path(target_dir)
        self.logger = setup_logging(self.__class__.__name__)

    @abstractmethod
    def validate(self) -> List[Dict[str, str]]:
        """Run validation checks. Return list of issues found. Override in subclass."""
        ...

    def check_files_exist(self, expected_files: List[str]) -> List[Dict[str, str]]:
        """Check that expected files exist."""
        issues = []
        for file_path in expected_files:
            if not Path(file_path).exists():
                issues.append({
                    'severity': 'ERROR',
                    'file': file_path,
                    'message': f'Expected file not found: {file_path}',
                    'suggestion': f'Ensure the generator script produces {file_path}'
                })
        return issues

    def check_yaml_valid(self, file_path: Path) -> List[Dict[str, str]]:
        """Check that a YAML file is valid and non-empty."""
        issues = []
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                data = yaml.safe_load(f)
            if data is None:
                issues.append({
                    'severity': 'ERROR',
                    'file': str(file_path),
                    'message': 'YAML file is empty',
                    'suggestion': 'Check the generator that produces this file'
                })
        except yaml.YAMLError as e:
            issues.append({
                'severity': 'ERROR',
                'file': str(file_path),
                'message': f'Invalid YAML syntax: {e}',
                'suggestion': 'Fix YAML formatting errors'
            })
        except FileNotFoundError:
            issues.append({
                'severity': 'ERROR',
                'file': str(file_path),
                'message': 'File not found',
                'suggestion': 'Ensure the file was generated'
            })
        return issues

    def check_required_fields(
        self,
        data: Dict[str, Any],
        required_fields: List[str],
        file_path: str
    ) -> List[Dict[str, str]]:
        """Check that required fields exist in a data dictionary."""
        issues = []
        for field in required_fields:
            if field not in data:
                issues.append({
                    'severity': 'ERROR',
                    'file': file_path,
                    'message': f'Missing required field: {field}',
                    'suggestion': f'Add "{field}" to the output'
                })
        return issues

    def report(self, issues: List[Dict[str, str]]) -> Dict[str, Any]:
        """Generate a validation report from issues found."""
        errors = [i for i in issues if i.get('severity') == 'ERROR']
        warnings = [i for i in issues if i.get('severity') == 'WARNING']
        infos = [i for i in issues if i.get('severity') == 'INFO']

        report = {
            'validation_report': {
                'timestamp': get_timestamp(),
                'validator': self.__class__.__name__,
                'summary': {
                    'total_issues': len(issues),
                    'errors': len(errors),
                    'warnings': len(warnings),
                    'info': len(infos),
                    'passed': len(errors) == 0,
                },
                'issues': issues,
            }
        }

        status = "PASSED" if len(errors) == 0 else "FAILED"
        self.logger.info(
            f"Validation {status}: {len(errors)} errors, "
            f"{len(warnings)} warnings, {len(infos)} info"
        )

        for issue in errors:
            self.logger.error(f"[{issue['file']}] {issue['message']}")
        for issue in warnings:
            self.logger.warning(f"[{issue['file']}] {issue['message']}")

        return report


def main():
    """Example usage - override this in your subclass module."""
    print("BaseValidator is abstract. Create a subclass for your specific checks.")
    print("See .claude/skills/validate-quality.md for patterns.")


if __name__ == '__main__':
    main()
