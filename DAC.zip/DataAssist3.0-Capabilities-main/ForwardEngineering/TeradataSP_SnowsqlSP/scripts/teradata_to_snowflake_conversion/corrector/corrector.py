"""
Core Corrector class for automatically fixing validation issues.
"""

import re
import logging
from dataclasses import dataclass, field
from typing import List, Dict, Optional, Tuple
from datetime import datetime

from .rules import (
    CorrectionRule,
    CorrectionCategory,
    get_all_corrections,
    get_corrections_by_validator_rule
)


@dataclass
class CorrectionMatch:
    """Represents a single correction match."""
    rule_name: str
    line_number: int
    original_text: str
    corrected_text: str
    description: str


@dataclass
class CorrectionResult:
    """Result of a correction operation."""
    original: str
    corrected: str
    corrections_applied: List[CorrectionMatch] = field(default_factory=list)
    corrections_skipped: List[str] = field(default_factory=list)
    warnings: List[str] = field(default_factory=list)
    success: bool = True

    @property
    def total_corrections(self) -> int:
        return len(self.corrections_applied)

    @property
    def has_changes(self) -> bool:
        return self.original != self.corrected

    def get_summary(self) -> str:
        """Generate a summary of corrections."""
        lines = [
            f"Corrections Applied: {self.total_corrections}",
            f"Corrections Skipped: {len(self.corrections_skipped)}",
            f"Warnings: {len(self.warnings)}",
            ""
        ]

        if self.corrections_applied:
            lines.append("Applied Corrections:")
            for corr in self.corrections_applied:
                lines.append(f"  - Line {corr.line_number}: {corr.description}")

        if self.corrections_skipped:
            lines.append("\nSkipped Corrections:")
            for skip in self.corrections_skipped:
                lines.append(f"  - {skip}")

        if self.warnings:
            lines.append("\nWarnings:")
            for warn in self.warnings:
                lines.append(f"  - {warn}")

        return "\n".join(lines)


class ValidationIssue:
    """Represents a validation issue to be corrected."""
    def __init__(self, rule_name: str, line_number: int,
                 message: str, matched_text: str = ""):
        self.rule_name = rule_name
        self.line_number = line_number
        self.message = message
        self.matched_text = matched_text


class SQLCorrector:
    """
    Automatically corrects SQL based on validation issues.
    Can work with validator results or apply all possible corrections.
    """

    def __init__(self, config: Optional[Dict] = None,
                 logger: Optional[logging.Logger] = None):
        """
        Initialize the corrector.

        Args:
            config: Configuration dictionary
            logger: Optional logger instance
        """
        self.config = config or {}
        self.logger = logger or logging.getLogger(__name__)
        self.rules = get_all_corrections()

        # Build lookup for validator rules
        self._validator_rule_map: Dict[str, List[CorrectionRule]] = {}
        for rule in self.rules:
            if rule.validator_rule not in self._validator_rule_map:
                self._validator_rule_map[rule.validator_rule] = []
            self._validator_rule_map[rule.validator_rule].append(rule)

    def add_rule(self, rule: CorrectionRule):
        """Add a custom correction rule."""
        self.rules.append(rule)
        if rule.validator_rule not in self._validator_rule_map:
            self._validator_rule_map[rule.validator_rule] = []
        self._validator_rule_map[rule.validator_rule].append(rule)
        self.logger.debug(f"Added rule: {rule.name}")

    def remove_rule(self, rule_name: str):
        """Remove a rule by name."""
        self.rules = [r for r in self.rules if r.name != rule_name]
        # Rebuild map
        self._validator_rule_map = {}
        for rule in self.rules:
            if rule.validator_rule not in self._validator_rule_map:
                self._validator_rule_map[rule.validator_rule] = []
            self._validator_rule_map[rule.validator_rule].append(rule)
        self.logger.debug(f"Removed rule: {rule_name}")

    def correct_from_validation(self, sql: str,
                                validation_issues: List[ValidationIssue]) -> CorrectionResult:
        """
        Apply corrections based on validation issues.

        Args:
            sql: The SQL to correct
            validation_issues: List of validation issues to fix

        Returns:
            CorrectionResult with corrected SQL and metadata
        """
        corrections_applied = []
        corrections_skipped = []
        warnings = []

        corrected_sql = sql
        lines = sql.split('\n')

        for issue in validation_issues:
            # Find correction rules for this validator rule
            correction_rules = self._validator_rule_map.get(issue.rule_name, [])

            if not correction_rules:
                corrections_skipped.append(
                    f"No correction rule for validator rule: {issue.rule_name}"
                )
                continue

            for rule in correction_rules:
                if not rule.enabled:
                    continue

                try:
                    # Apply correction
                    new_sql = re.sub(
                        rule.pattern,
                        rule.replacement,
                        corrected_sql,
                        flags=rule.flags
                    )

                    if new_sql != corrected_sql:
                        # Find what changed
                        match = re.search(rule.pattern, corrected_sql, flags=rule.flags)
                        if match:
                            corrections_applied.append(CorrectionMatch(
                                rule_name=rule.name,
                                line_number=issue.line_number,
                                original_text=match.group(0)[:50] + "..." if len(match.group(0)) > 50 else match.group(0),
                                corrected_text=re.sub(rule.pattern, rule.replacement, match.group(0), flags=rule.flags),
                                description=rule.description
                            ))
                        corrected_sql = new_sql
                        self.logger.debug(f"Applied correction: {rule.name}")

                except re.error as e:
                    warnings.append(f"Regex error in rule {rule.name}: {e}")
                    self.logger.warning(f"Regex error in rule {rule.name}: {e}")

        return CorrectionResult(
            original=sql,
            corrected=corrected_sql,
            corrections_applied=corrections_applied,
            corrections_skipped=corrections_skipped,
            warnings=warnings,
            success=True
        )

    def correct_all(self, sql: str,
                    categories: Optional[List[CorrectionCategory]] = None) -> CorrectionResult:
        """
        Apply all possible corrections to SQL.

        Args:
            sql: The SQL to correct
            categories: Optional list of categories to apply (None = all)

        Returns:
            CorrectionResult with corrected SQL and metadata
        """
        corrections_applied = []
        corrections_skipped = []
        warnings = []

        corrected_sql = sql

        for rule in self.rules:
            if not rule.enabled:
                continue

            if categories and rule.category not in categories:
                continue

            try:
                # Count matches before applying
                matches = list(re.finditer(rule.pattern, corrected_sql, flags=rule.flags))

                if matches:
                    # Apply correction
                    new_sql = re.sub(
                        rule.pattern,
                        rule.replacement,
                        corrected_sql,
                        flags=rule.flags
                    )

                    if new_sql != corrected_sql:
                        for match in matches:
                            # Find line number
                            line_num = corrected_sql[:match.start()].count('\n') + 1

                            corrections_applied.append(CorrectionMatch(
                                rule_name=rule.name,
                                line_number=line_num,
                                original_text=match.group(0)[:50] + "..." if len(match.group(0)) > 50 else match.group(0),
                                corrected_text=re.sub(rule.pattern, rule.replacement, match.group(0), flags=rule.flags),
                                description=rule.description
                            ))

                        corrected_sql = new_sql
                        self.logger.debug(f"Applied {len(matches)} corrections for: {rule.name}")

            except re.error as e:
                warnings.append(f"Regex error in rule {rule.name}: {e}")
                self.logger.warning(f"Regex error in rule {rule.name}: {e}")

        # Apply complex corrections that need special handling
        corrected_sql, complex_corrections = self._apply_complex_corrections(corrected_sql)
        corrections_applied.extend(complex_corrections)

        # Cleanup
        corrected_sql = self._cleanup(corrected_sql)

        return CorrectionResult(
            original=sql,
            corrected=corrected_sql,
            corrections_applied=corrections_applied,
            corrections_skipped=corrections_skipped,
            warnings=warnings,
            success=True
        )

    def _apply_complex_corrections(self, sql: str) -> Tuple[str, List[CorrectionMatch]]:
        """Apply corrections that need special handling."""
        corrections = []

        # Fix UPDATE FROM → MERGE (complex pattern)
        sql, update_corrections = self._fix_update_from(sql)
        corrections.extend(update_corrections)

        # Fix EXIT HANDLER → EXCEPTION
        sql, handler_corrections = self._fix_exit_handler(sql)
        corrections.extend(handler_corrections)

        # Fix UPDATE SET that was incorrectly converted to LET
        sql, let_corrections = self._fix_update_let(sql)
        corrections.extend(let_corrections)

        return sql, corrections

    def _fix_update_from(self, sql: str) -> Tuple[str, List[CorrectionMatch]]:
        """Convert UPDATE FROM to MERGE."""
        corrections = []

        # Pattern 1: UPDATE table FROM (subquery) AS alias SET ... WHERE ...
        pattern1 = r"""
            UPDATE\s+(\w+)\s+
            FROM\s*\(\s*([\s\S]+?)\s*\)\s*AS\s+(\w+)\s*
            SET\s+([\s\S]+?)
            WHERE\s+([\s\S]+?)
            (?=;|$)
        """

        def replace_update1(match: re.Match) -> str:
            target = match.group(1)
            subquery = match.group(2).strip()
            alias = match.group(3)
            set_clause = match.group(4).strip()
            where_clause = match.group(5).strip()

            # Convert SET clause
            set_parts = []
            for part in set_clause.split(','):
                part = part.strip()
                if '=' in part:
                    col, val = part.split('=', 1)
                    col = col.strip()
                    val = val.strip()
                    val = re.sub(rf'\b{alias}\.', 'src.', val, flags=re.IGNORECASE)
                    set_parts.append(f"{col} = {val}")

            # Convert WHERE to ON
            on_clause = where_clause
            on_clause = re.sub(rf'\b{alias}\.', 'src.', on_clause, flags=re.IGNORECASE)
            on_clause = re.sub(rf'\b{target}\.', 'tgt.', on_clause, flags=re.IGNORECASE)

            return f"""MERGE INTO {target} tgt
USING (
    {subquery}
) src
ON {on_clause}
WHEN MATCHED THEN UPDATE SET {', '.join(set_parts)}"""

        matches = list(re.finditer(pattern1, sql, flags=re.VERBOSE | re.IGNORECASE))
        if matches:
            new_sql = re.sub(pattern1, replace_update1, sql, flags=re.VERBOSE | re.IGNORECASE)
            if new_sql != sql:
                for match in matches:
                    line_num = sql[:match.start()].count('\n') + 1
                    corrections.append(CorrectionMatch(
                        rule_name="fix_update_from_subquery",
                        line_number=line_num,
                        original_text="UPDATE ... FROM (subquery) ...",
                        corrected_text="MERGE INTO ... USING ...",
                        description="UPDATE FROM (subquery) → MERGE"
                    ))
                sql = new_sql

        return sql, corrections

    def _fix_exit_handler(self, sql: str) -> Tuple[str, List[CorrectionMatch]]:
        """Convert EXIT HANDLER to EXCEPTION block."""
        corrections = []

        pattern = r"DECLARE\s+EXIT\s+HANDLER\s+FOR\s+SQLEXCEPTION\s*BEGIN\s*([\s\S]*?)END\s*;"

        matches = list(re.finditer(pattern, sql, flags=re.IGNORECASE))
        if matches:
            new_sql = re.sub(
                pattern,
                "-- Exception handler converted to EXCEPTION block at end of procedure",
                sql,
                flags=re.IGNORECASE
            )
            if new_sql != sql:
                for match in matches:
                    line_num = sql[:match.start()].count('\n') + 1
                    corrections.append(CorrectionMatch(
                        rule_name="fix_exit_handler",
                        line_number=line_num,
                        original_text="DECLARE EXIT HANDLER FOR SQLEXCEPTION...",
                        corrected_text="EXCEPTION WHEN OTHER THEN...",
                        description="EXIT HANDLER → EXCEPTION block"
                    ))
                sql = new_sql

        return sql, corrections

    def _fix_update_let(self, sql: str) -> Tuple[str, List[CorrectionMatch]]:
        """Fix UPDATE statements where SET was incorrectly converted to LET."""
        corrections = []

        def fix_update(match: re.Match) -> str:
            content = match.group(0)
            # Replace LET with SET within UPDATE
            fixed = re.sub(r'\bLET\s+(\w+)\s*:=', r'SET \1 =', content)
            return fixed

        # Match UPDATE statements
        pattern = r'UPDATE\s+\w+[\s\S]*?(?=;|\bUPDATE\b|\bINSERT\b|\bDELETE\b|\bSELECT\b|\bMERGE\b|\bCREATE\b|\bDROP\b|$)'

        matches = list(re.finditer(pattern, sql, flags=re.IGNORECASE))
        new_sql = re.sub(pattern, fix_update, sql, flags=re.IGNORECASE)

        if new_sql != sql:
            corrections.append(CorrectionMatch(
                rule_name="fix_update_let",
                line_number=0,
                original_text="UPDATE ... LET col :=",
                corrected_text="UPDATE ... SET col =",
                description="Fix LET in UPDATE → SET"
            ))
            sql = new_sql

        return sql, corrections

    def _cleanup(self, sql: str) -> str:
        """Final cleanup of corrected SQL."""
        # Remove multiple blank lines
        sql = re.sub(r'\n{3,}', '\n\n', sql)

        # Remove trailing whitespace
        sql = '\n'.join(line.rstrip() for line in sql.split('\n'))

        # Remove multiple spaces (but preserve indentation)
        lines = []
        for line in sql.split('\n'):
            # Preserve leading whitespace
            leading = len(line) - len(line.lstrip())
            content = re.sub(r'  +', ' ', line.strip())
            lines.append(' ' * leading + content)
        sql = '\n'.join(lines)

        return sql.strip() + '\n'

    def correct_string(self, sql: str) -> str:
        """Simple correction that returns just the corrected SQL."""
        result = self.correct_all(sql)
        return result.corrected


def create_corrector(config: Optional[Dict] = None) -> SQLCorrector:
    """Factory function to create a corrector instance."""
    return SQLCorrector(config)
