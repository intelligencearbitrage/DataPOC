"""
Corrector package for automatically fixing validation issues.

This package provides tools to automatically correct SQL files
based on validation results from the validator package.

Usage:
    from corrector import SQLCorrector, BatchCorrector

    # Single file correction - apply all corrections
    corrector = SQLCorrector()
    result = corrector.correct_all(sql)
    print(result.corrected)

    # Correct based on validation issues
    issues = [ValidationIssue('add_months_remaining', 10, 'ADD_MONTHS found')]
    result = corrector.correct_from_validation(sql, issues)

    # Batch correction
    batch = BatchCorrector()
    report = batch.correct_folder('./input', './corrected')
    print(report.get_summary())
"""

from .corrector import (
    SQLCorrector,
    CorrectionResult,
    CorrectionMatch,
    ValidationIssue,
    create_corrector
)

from .batch_processor import (
    BatchCorrector,
    BatchCorrectionReport,
    FileCorrectionResult,
    create_batch_corrector
)

from .rules import (
    CorrectionRule,
    CorrectionCategory,
    get_all_corrections,
    get_syntax_corrections,
    get_function_corrections,
    get_date_corrections,
    get_statement_corrections,
    get_datatype_corrections,
    get_corrections_by_validator_rule,
    get_corrections_by_category
)

__all__ = [
    # Main classes
    'SQLCorrector',
    'BatchCorrector',

    # Result classes
    'CorrectionResult',
    'CorrectionMatch',
    'ValidationIssue',
    'BatchCorrectionReport',
    'FileCorrectionResult',

    # Rule classes
    'CorrectionRule',
    'CorrectionCategory',

    # Factory functions
    'create_corrector',
    'create_batch_corrector',

    # Rule getters
    'get_all_corrections',
    'get_syntax_corrections',
    'get_function_corrections',
    'get_date_corrections',
    'get_statement_corrections',
    'get_datatype_corrections',
    'get_corrections_by_validator_rule',
    'get_corrections_by_category'
]

__version__ = '1.0.0'
