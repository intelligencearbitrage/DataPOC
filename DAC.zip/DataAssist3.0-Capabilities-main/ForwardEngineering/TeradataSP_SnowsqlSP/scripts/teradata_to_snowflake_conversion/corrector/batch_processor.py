"""
Batch processor for corrector - integrates with validator results.
"""

import os
import json
import logging
from pathlib import Path
from dataclasses import dataclass, field
from typing import List, Dict, Optional
from datetime import datetime
from concurrent.futures import ThreadPoolExecutor, as_completed

from .corrector import SQLCorrector, CorrectionResult, ValidationIssue
from .rules import CorrectionCategory


@dataclass
class FileCorrectionResult:
    """Result for a single file correction."""
    input_path: str
    output_path: str
    correction_result: CorrectionResult
    success: bool
    error: Optional[str] = None


@dataclass
class BatchCorrectionReport:
    """Report for batch correction operation."""
    total_files: int
    successful: int
    failed: int
    total_corrections: int
    file_results: List[FileCorrectionResult] = field(default_factory=list)
    start_time: datetime = field(default_factory=datetime.now)
    end_time: Optional[datetime] = None

    def get_summary(self) -> str:
        """Generate summary text."""
        duration = (self.end_time - self.start_time).total_seconds() if self.end_time else 0

        lines = [
            "=" * 60,
            "BATCH CORRECTION REPORT",
            "=" * 60,
            f"Total Files: {self.total_files}",
            f"Successful: {self.successful}",
            f"Failed: {self.failed}",
            f"Total Corrections: {self.total_corrections}",
            f"Duration: {duration:.2f} seconds",
            "",
        ]

        if self.file_results:
            lines.append("File Details:")
            for result in self.file_results:
                status = "✓" if result.success else "✗"
                lines.append(f"  {status} {os.path.basename(result.input_path)}: "
                           f"{result.correction_result.total_corrections} corrections")
                if result.error:
                    lines.append(f"      Error: {result.error}")

        return "\n".join(lines)

    def to_dict(self) -> Dict:
        """Convert to dictionary for JSON serialization."""
        return {
            "total_files": self.total_files,
            "successful": self.successful,
            "failed": self.failed,
            "total_corrections": self.total_corrections,
            "start_time": self.start_time.isoformat(),
            "end_time": self.end_time.isoformat() if self.end_time else None,
            "files": [
                {
                    "input": r.input_path,
                    "output": r.output_path,
                    "corrections": r.correction_result.total_corrections,
                    "success": r.success,
                    "error": r.error,
                    "changes": [
                        {
                            "rule": c.rule_name,
                            "line": c.line_number,
                            "description": c.description
                        }
                        for c in r.correction_result.corrections_applied
                    ]
                }
                for r in self.file_results
            ]
        }


class BatchCorrector:
    """
    Batch processor for correcting multiple SQL files.
    Integrates with validator results for targeted corrections.
    """

    def __init__(self, config: Optional[Dict] = None,
                 logger: Optional[logging.Logger] = None):
        """
        Initialize batch corrector.

        Args:
            config: Configuration dictionary
            logger: Optional logger instance
        """
        self.config = config or {}
        self.logger = logger or logging.getLogger(__name__)
        self.corrector = SQLCorrector(config, logger)

    def correct_file(self, input_path: str, output_path: str,
                     validation_issues: Optional[List[ValidationIssue]] = None) -> FileCorrectionResult:
        """
        Correct a single file.

        Args:
            input_path: Path to input SQL file
            output_path: Path to output corrected file
            validation_issues: Optional validation issues to fix

        Returns:
            FileCorrectionResult
        """
        try:
            # Read input file
            with open(input_path, 'r', encoding='utf-8', errors='replace') as f:
                sql = f.read()

            # Apply corrections
            if validation_issues:
                result = self.corrector.correct_from_validation(sql, validation_issues)
            else:
                result = self.corrector.correct_all(sql)

            # Ensure output directory exists
            os.makedirs(os.path.dirname(output_path) or '.', exist_ok=True)

            # Write output
            with open(output_path, 'w', encoding='utf-8') as f:
                # Add header
                f.write(f"/*\n")
                f.write(f"{'=' * 70}\n")
                f.write(f"-- Corrected by SQLCorrector\n")
                f.write(f"-- Source: {os.path.basename(input_path)}\n")
                f.write(f"-- Corrected: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
                f.write(f"-- Corrections Applied: {result.total_corrections}\n")
                f.write(f"{'=' * 70}\n")
                f.write(f"*/\n\n")
                f.write(result.corrected)

            self.logger.info(f"Corrected: {input_path} → {output_path} "
                           f"({result.total_corrections} corrections)")

            return FileCorrectionResult(
                input_path=input_path,
                output_path=output_path,
                correction_result=result,
                success=True
            )

        except Exception as e:
            self.logger.error(f"Error correcting {input_path}: {e}")
            return FileCorrectionResult(
                input_path=input_path,
                output_path=output_path,
                correction_result=CorrectionResult(
                    original="",
                    corrected="",
                    success=False
                ),
                success=False,
                error=str(e)
            )

    def correct_with_validation_report(self, input_path: str, output_path: str,
                                       validation_report_path: str) -> FileCorrectionResult:
        """
        Correct a file using a validation report JSON.

        Args:
            input_path: Path to input SQL file
            output_path: Path to output corrected file
            validation_report_path: Path to validation report JSON

        Returns:
            FileCorrectionResult
        """
        try:
            # Load validation report
            with open(validation_report_path, 'r', encoding='utf-8') as f:
                report = json.load(f)

            # Extract issues
            issues = []
            for issue in report.get('issues', []):
                issues.append(ValidationIssue(
                    rule_name=issue.get('rule', ''),
                    line_number=issue.get('line', 0),
                    message=issue.get('message', ''),
                    matched_text=issue.get('matched_text', '')
                ))

            return self.correct_file(input_path, output_path, issues)

        except Exception as e:
            self.logger.error(f"Error loading validation report: {e}")
            return FileCorrectionResult(
                input_path=input_path,
                output_path=output_path,
                correction_result=CorrectionResult(
                    original="",
                    corrected="",
                    success=False
                ),
                success=False,
                error=str(e)
            )

    def correct_folder(self, input_folder: str, output_folder: str,
                       file_extensions: List[str] = None,
                       preserve_structure: bool = True,
                       max_workers: int = 1) -> BatchCorrectionReport:
        """
        Correct all SQL files in a folder.

        Args:
            input_folder: Input folder path
            output_folder: Output folder path
            file_extensions: File extensions to process
            preserve_structure: Preserve subfolder structure
            max_workers: Number of parallel workers

        Returns:
            BatchCorrectionReport
        """
        if file_extensions is None:
            file_extensions = ['.sql', '.bteq', '.txt']

        report = BatchCorrectionReport(
            total_files=0,
            successful=0,
            failed=0,
            total_corrections=0
        )

        # Collect files
        files_to_process = []
        input_path = Path(input_folder)

        for ext in file_extensions:
            for file_path in input_path.rglob(f'*{ext}'):
                if preserve_structure:
                    rel_path = file_path.relative_to(input_path)
                    output_path = Path(output_folder) / rel_path.with_suffix(f'_corrected{ext}')
                else:
                    output_path = Path(output_folder) / f"{file_path.stem}_corrected{ext}"

                files_to_process.append((str(file_path), str(output_path)))

        report.total_files = len(files_to_process)

        if not files_to_process:
            self.logger.warning(f"No files found in {input_folder}")
            report.end_time = datetime.now()
            return report

        # Process files
        if max_workers == 1:
            for input_path, output_path in files_to_process:
                result = self.correct_file(input_path, output_path)
                report.file_results.append(result)
                if result.success:
                    report.successful += 1
                    report.total_corrections += result.correction_result.total_corrections
                else:
                    report.failed += 1
        else:
            with ThreadPoolExecutor(max_workers=max_workers) as executor:
                futures = {
                    executor.submit(self.correct_file, inp, out): (inp, out)
                    for inp, out in files_to_process
                }

                for future in as_completed(futures):
                    result = future.result()
                    report.file_results.append(result)
                    if result.success:
                        report.successful += 1
                        report.total_corrections += result.correction_result.total_corrections
                    else:
                        report.failed += 1

        report.end_time = datetime.now()
        return report

    def correct_from_validator_output(self, validator_output_folder: str,
                                       corrected_output_folder: str) -> BatchCorrectionReport:
        """
        Correct files based on validator output.
        Expects validation reports named {filename}_validation.json

        Args:
            validator_output_folder: Folder with validation reports
            corrected_output_folder: Output folder for corrected files

        Returns:
            BatchCorrectionReport
        """
        report = BatchCorrectionReport(
            total_files=0,
            successful=0,
            failed=0,
            total_corrections=0
        )

        validator_path = Path(validator_output_folder)

        # Find validation reports
        for report_file in validator_path.glob('*_validation.json'):
            # Derive SQL file name
            base_name = report_file.stem.replace('_validation', '')

            # Find corresponding SQL file
            sql_file = None
            for ext in ['.sql', '.bteq', '.txt']:
                potential = validator_path / f"{base_name}{ext}"
                if potential.exists():
                    sql_file = potential
                    break

            if not sql_file:
                self.logger.warning(f"No SQL file found for {report_file}")
                continue

            output_path = Path(corrected_output_folder) / f"{base_name}_corrected.sql"

            result = self.correct_with_validation_report(
                str(sql_file),
                str(output_path),
                str(report_file)
            )

            report.file_results.append(result)
            report.total_files += 1

            if result.success:
                report.successful += 1
                report.total_corrections += result.correction_result.total_corrections
            else:
                report.failed += 1

        report.end_time = datetime.now()
        return report


def create_batch_corrector(config: Optional[Dict] = None) -> BatchCorrector:
    """Factory function to create a batch corrector."""
    return BatchCorrector(config)
