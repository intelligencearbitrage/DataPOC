"""
Correction rules for automatically fixing validation issues.
Maps validator rule names to correction patterns.
"""

import re
from dataclasses import dataclass, field
from typing import Callable, Optional, List
from enum import Enum


class CorrectionCategory(Enum):
    """Categories for correction rules."""
    SYNTAX = "syntax"
    FUNCTION = "function"
    DATE = "date"
    TABLE = "table"
    PROCEDURE = "procedure"
    STATEMENT = "statement"


@dataclass
class CorrectionRule:
    """Defines a correction rule."""
    name: str
    validator_rule: str  # The validator rule this corrects
    category: CorrectionCategory
    pattern: str
    replacement: str
    description: str
    flags: int = re.IGNORECASE
    enabled: bool = True
    custom_handler: Optional[Callable[[str, re.Match], str]] = None


def get_syntax_corrections() -> List[CorrectionRule]:
    """Returns syntax correction rules."""
    return [
        CorrectionRule(
            name="fix_volatile_table",
            validator_rule="volatile_table_remaining",
            category=CorrectionCategory.TABLE,
            pattern=r"CREATE\s+(?:MULTISET\s+)?VOLATILE\s+TABLE",
            replacement="CREATE OR REPLACE TEMPORARY TABLE",
            description="VOLATILE TABLE → TEMPORARY TABLE"
        ),
        CorrectionRule(
            name="fix_multiset",
            validator_rule="multiset_remaining",
            category=CorrectionCategory.TABLE,
            pattern=r"\bMULTISET\b",
            replacement="",
            description="Remove MULTISET keyword"
        ),
        CorrectionRule(
            name="fix_primary_index",
            validator_rule="primary_index_remaining",
            category=CorrectionCategory.TABLE,
            pattern=r"\s*(?:UNIQUE\s+)?PRIMARY\s+INDEX\s*(?:\([^)]*\))?\s*",
            replacement=" ",
            description="Remove PRIMARY INDEX clause"
        ),
        CorrectionRule(
            name="fix_on_commit",
            validator_rule="on_commit_remaining",
            category=CorrectionCategory.TABLE,
            pattern=r"\s*ON\s+COMMIT\s+(?:PRESERVE|DELETE)\s+ROWS\s*",
            replacement=" ",
            description="Remove ON COMMIT clause"
        ),
        CorrectionRule(
            name="fix_with_data",
            validator_rule="with_data_remaining",
            category=CorrectionCategory.TABLE,
            pattern=r"\s*WITH\s+DATA\s*",
            replacement=" ",
            description="Remove WITH DATA clause"
        ),
        CorrectionRule(
            name="fix_replace_procedure",
            validator_rule="replace_procedure_remaining",
            category=CorrectionCategory.PROCEDURE,
            pattern=r"(?<!\bOR\s)REPLACE\s+PROCEDURE",
            replacement="CREATE OR REPLACE PROCEDURE",
            description="REPLACE PROCEDURE → CREATE OR REPLACE PROCEDURE"
        ),
        CorrectionRule(
            name="fix_activity_count",
            validator_rule="activity_count_remaining",
            category=CorrectionCategory.SYNTAX,
            pattern=r"\bACTIVITY_COUNT\b",
            replacement="SQLROWCOUNT",
            description="ACTIVITY_COUNT → SQLROWCOUNT"
        ),
        CorrectionRule(
            name="fix_resignal",
            validator_rule="resignal_remaining",
            category=CorrectionCategory.SYNTAX,
            pattern=r"\bRESIGNAL\b",
            replacement="RAISE",
            description="RESIGNAL → RAISE"
        ),
        CorrectionRule(
            name="fix_sel_keyword",
            validator_rule="sel_remaining",
            category=CorrectionCategory.SYNTAX,
            pattern=r"\bSEL\s+",
            replacement="SELECT ",
            description="SEL → SELECT"
        ),
        CorrectionRule(
            name="fix_double_semicolon",
            validator_rule="double_semicolon",
            category=CorrectionCategory.SYNTAX,
            pattern=r";\s*;",
            replacement=";",
            description="Remove duplicate semicolons"
        ),
    ]


def get_function_corrections() -> List[CorrectionRule]:
    """Returns function correction rules."""
    return [
        CorrectionRule(
            name="fix_add_months",
            validator_rule="add_months_remaining",
            category=CorrectionCategory.FUNCTION,
            pattern=r"\bADD_MONTHS\s*\(\s*([^,]+?)\s*,\s*([^)]+?)\s*\)",
            replacement=r"DATEADD(MONTH, \2, \1)",
            description="ADD_MONTHS(date, n) → DATEADD(MONTH, n, date)"
        ),
        CorrectionRule(
            name="fix_oreplace",
            validator_rule="oreplace_remaining",
            category=CorrectionCategory.FUNCTION,
            pattern=r"\bOREPLACE\s*\(",
            replacement="REPLACE(",
            description="OREPLACE → REPLACE"
        ),
        CorrectionRule(
            name="fix_otranslate",
            validator_rule="otranslate_remaining",
            category=CorrectionCategory.FUNCTION,
            pattern=r"\bOTRANSLATE\s*\(",
            replacement="TRANSLATE(",
            description="OTRANSLATE → TRANSLATE"
        ),
        CorrectionRule(
            name="fix_characters",
            validator_rule="characters_remaining",
            category=CorrectionCategory.FUNCTION,
            pattern=r"\bCHARACTERS\s*\(",
            replacement="LENGTH(",
            description="CHARACTERS → LENGTH"
        ),
        CorrectionRule(
            name="fix_nullifzero",
            validator_rule="nullifzero_remaining",
            category=CorrectionCategory.FUNCTION,
            pattern=r"\bNULLIFZERO\s*\(\s*([^)]+?)\s*\)",
            replacement=r"NULLIF(\1, 0)",
            description="NULLIFZERO(x) → NULLIF(x, 0)"
        ),
        CorrectionRule(
            name="fix_zeroifnull",
            validator_rule="zeroifnull_remaining",
            category=CorrectionCategory.FUNCTION,
            pattern=r"\bZEROIFNULL\s*\(\s*([^)]+?)\s*\)",
            replacement=r"COALESCE(\1, 0)",
            description="ZEROIFNULL(x) → COALESCE(x, 0)"
        ),
        CorrectionRule(
            name="fix_index_function",
            validator_rule="index_function_remaining",
            category=CorrectionCategory.FUNCTION,
            pattern=r"\bINDEX\s*\(\s*([^,]+?)\s*,\s*([^)]+?)\s*\)",
            replacement=r"POSITION(\2 IN \1)",
            description="INDEX(str, substr) → POSITION(substr IN str)"
        ),
    ]


def get_date_corrections() -> List[CorrectionRule]:
    """Returns date-related correction rules."""
    return [
        # Complex interval patterns
        CorrectionRule(
            name="fix_interval_month_cast",
            validator_rule="interval_month_remaining",
            category=CorrectionCategory.DATE,
            pattern=r"CAST\s*\(\s*\(\s*([^-()]+?)\s*-\s*([^)]+?)\s*\)\s*MONTH\s*\(\s*\d+\s*\)\s*AS\s+INTEGER\s*\)",
            replacement=r"DATEDIFF(MONTH, \2, \1)",
            description="CAST((d1-d2) MONTH(n) AS INTEGER) → DATEDIFF"
        ),
        CorrectionRule(
            name="fix_interval_month_casted_dates",
            validator_rule="interval_month_remaining",
            category=CorrectionCategory.DATE,
            pattern=r"CAST\s*\(\s*\(\s*([^:]+?)::DATE\s*-\s*([^:]+?)::DATE\s*\)\s*MONTH\s*\(\s*\d+\s*\)\s*AS\s+INTEGER\s*\)",
            replacement=r"DATEDIFF(MONTH, \2::DATE, \1::DATE)",
            description="CAST((d1::DATE-d2::DATE) MONTH(n) AS INTEGER) → DATEDIFF"
        ),
        CorrectionRule(
            name="fix_interval_month_simple",
            validator_rule="interval_month_remaining",
            category=CorrectionCategory.DATE,
            pattern=r"\(\s*([\w.]+)\s*-\s*([\w.]+)\s*\)\s*MONTH\s*\(\s*\d+\s*\)",
            replacement=r"DATEDIFF(MONTH, \2, \1)",
            description="(d1 - d2) MONTH(n) → DATEDIFF"
        ),
        CorrectionRule(
            name="fix_interval_day",
            validator_rule="interval_day_remaining",
            category=CorrectionCategory.DATE,
            pattern=r"CAST\s*\(\s*\(\s*([^-]+?)\s*-\s*([^)]+?)\s*\)\s*DAY\s*\(\s*\d+\s*\)\s*AS\s+INTEGER\s*\)",
            replacement=r"DATEDIFF(DAY, \2, \1)",
            description="CAST((d1-d2) DAY(n) AS INTEGER) → DATEDIFF"
        ),
        CorrectionRule(
            name="fix_date_literal",
            validator_rule="date_literal_remaining",
            category=CorrectionCategory.DATE,
            pattern=r"\bDATE\s*'(\d{4}-\d{2}-\d{2})'",
            replacement=r"'\1'::DATE",
            description="DATE 'YYYY-MM-DD' → 'YYYY-MM-DD'::DATE"
        ),
        CorrectionRule(
            name="fix_timestamp_literal",
            validator_rule="timestamp_literal_remaining",
            category=CorrectionCategory.DATE,
            pattern=r"\bTIMESTAMP\s*'([^']+)'",
            replacement=r"'\1'::TIMESTAMP",
            description="TIMESTAMP 'value' → 'value'::TIMESTAMP"
        ),
        CorrectionRule(
            name="fix_interval_add",
            validator_rule="interval_add_remaining",
            category=CorrectionCategory.DATE,
            pattern=r"(\w+(?:\.\w+)?)\s*\+\s*INTERVAL\s*'(\d+)'\s*MONTH",
            replacement=r"DATEADD(MONTH, \2, \1)",
            description="date + INTERVAL 'n' MONTH → DATEADD"
        ),
        CorrectionRule(
            name="fix_interval_subtract",
            validator_rule="interval_subtract_remaining",
            category=CorrectionCategory.DATE,
            pattern=r"(\w+(?:\.\w+)?)\s*-\s*INTERVAL\s*'(\d+)'\s*MONTH",
            replacement=r"DATEADD(MONTH, -\2, \1)",
            description="date - INTERVAL 'n' MONTH → DATEADD"
        ),
    ]


def get_statement_corrections() -> List[CorrectionRule]:
    """Returns statement-level correction rules."""
    return [
        CorrectionRule(
            name="fix_sample_to_limit",
            validator_rule="sample_remaining",
            category=CorrectionCategory.STATEMENT,
            pattern=r"\bSAMPLE\s+(\d+)\b",
            replacement=r"LIMIT \1",
            description="SAMPLE n → LIMIT n"
        ),
        CorrectionRule(
            name="fix_format_clause",
            validator_rule="format_clause_remaining",
            category=CorrectionCategory.STATEMENT,
            pattern=r"CAST\s*\(\s*([^)]+?)\s+AS\s+(?:DATE|VARCHAR\([^)]+\))\s+FORMAT\s+'([^']+)'\s*\)",
            replacement=r"TO_CHAR(\1, '\2')",
            description="CAST(x AS type FORMAT 'fmt') → TO_CHAR"
        ),
        CorrectionRule(
            name="fix_title_clause",
            validator_rule="title_clause_remaining",
            category=CorrectionCategory.STATEMENT,
            pattern=r"\s*\(TITLE\s+'[^']*'\s*\)",
            replacement="",
            description="Remove TITLE clause"
        ),
        CorrectionRule(
            name="fix_named_clause",
            validator_rule="named_clause_remaining",
            category=CorrectionCategory.STATEMENT,
            pattern=r"\s*\(NAMED\s+'[^']*'\s*\)",
            replacement="",
            description="Remove NAMED clause"
        ),
    ]


def get_datatype_corrections() -> List[CorrectionRule]:
    """Returns datatype correction rules."""
    return [
        CorrectionRule(
            name="fix_byteint",
            validator_rule="byteint_remaining",
            category=CorrectionCategory.SYNTAX,
            pattern=r"\bBYTEINT\b",
            replacement="TINYINT",
            description="BYTEINT → TINYINT"
        ),
        CorrectionRule(
            name="fix_byte",
            validator_rule="byte_remaining",
            category=CorrectionCategory.SYNTAX,
            pattern=r"\bBYTE\s*\(\s*(\d+)\s*\)",
            replacement=r"BINARY(\1)",
            description="BYTE(n) → BINARY(n)"
        ),
        CorrectionRule(
            name="fix_varbyte",
            validator_rule="varbyte_remaining",
            category=CorrectionCategory.SYNTAX,
            pattern=r"\bVARBYTE\s*\(\s*(\d+)\s*\)",
            replacement=r"VARBINARY(\1)",
            description="VARBYTE(n) → VARBINARY(n)"
        ),
    ]


def get_conversion_residual_corrections() -> List[CorrectionRule]:
    """Returns correction rules for residual conversion patterns."""
    return [
        CorrectionRule(
            name="fix_on_commit_residual",
            validator_rule="on_commit_remaining",
            category=CorrectionCategory.TABLE,
            pattern=r"\s*ON\s+COMMIT\s+PRESERVE\s+ROWS\s*",
            replacement="",
            description="Remove residual ON COMMIT PRESERVE ROWS"
        ),
        CorrectionRule(
            name="fix_volatile_remaining",
            validator_rule="volatile_table_remaining",
            category=CorrectionCategory.TABLE,
            pattern=r"\bVOLATILE\s+TABLE\b",
            replacement="TEMPORARY TABLE",
            description="VOLATILE TABLE → TEMPORARY TABLE"
        ),
        CorrectionRule(
            name="fix_double_quotes",
            validator_rule="double_double_quote",
            category=CorrectionCategory.SYNTAX,
            pattern=r'""(\w+)""',
            replacement=r'"\1"',
            description='""identifier"" → "identifier"'
        ),
        CorrectionRule(
            name="fix_cast_varchar_fill",
            validator_rule="cast_varchar_fill_remaining",
            category=CorrectionCategory.SYNTAX,
            pattern=r"CAST\s*\(\s*(.+?)\s+AS\s+VARCHAR\s*\(\s*(\d+)\s*,\s*'([^']+)'\s*\)\s*\)",
            replacement=r"LPAD(\1::VARCHAR(\2), \2, '\3')",
            description="CAST(x AS VARCHAR(n,'fill')) → LPAD"
        ),
        CorrectionRule(
            name="fix_update_let_to_set",
            validator_rule="update_let_remaining",
            category=CorrectionCategory.SYNTAX,
            pattern=r'(\bUPDATE\b[^;]*?)\bLET\s+(\w+)\s*:=',
            replacement=r'\1SET \2 =',
            description="UPDATE...LET x := → UPDATE...SET x ="
        ),
    ]


def get_all_corrections() -> List[CorrectionRule]:
    """Returns all correction rules."""
    all_rules = []
    all_rules.extend(get_syntax_corrections())
    all_rules.extend(get_function_corrections())
    all_rules.extend(get_date_corrections())
    all_rules.extend(get_statement_corrections())
    all_rules.extend(get_datatype_corrections())
    all_rules.extend(get_conversion_residual_corrections())
    return all_rules


def get_corrections_by_validator_rule(validator_rule: str) -> List[CorrectionRule]:
    """Get correction rules that fix a specific validator rule."""
    return [r for r in get_all_corrections() if r.validator_rule == validator_rule]


def get_corrections_by_category(category: CorrectionCategory) -> List[CorrectionRule]:
    """Get correction rules by category."""
    return [r for r in get_all_corrections() if r.category == category]
