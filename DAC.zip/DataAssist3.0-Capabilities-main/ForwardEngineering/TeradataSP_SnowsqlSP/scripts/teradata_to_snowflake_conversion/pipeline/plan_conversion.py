"""
Phase 2: Plan Conversion
=========================

Reads all *_complexity.json files from research/ and creates a
categorized conversion plan in plans/conversion_plan.yaml.

Files are categorized by confidence score:
    - high (>=0.95): Fully automated conversion
    - medium (0.85-0.94): Automated with post-review
    - low (<0.85): Requires manual review after conversion

Usage:
    python scripts/plan_conversion.py
"""

import json
import sys
from pathlib import Path
from typing import Dict, List, Tuple

# Resolve paths
SCRIPTS_DIR = Path(__file__).resolve().parent.parent
PROJECT_ROOT = SCRIPTS_DIR
sys.path.insert(0, str(SCRIPTS_DIR))

from utils import setup_logging, get_iso_timestamp, load_json, save_yaml


# Confidence thresholds
HIGH_THRESHOLD = 0.95
MEDIUM_THRESHOLD = 0.85


def load_complexity_reports(research_dir: Path, logger) -> List[dict]:
    """
    Load all *_complexity.json files from the research directory.

    Args:
        research_dir: Path to the research/ directory.
        logger: Logger instance.

    Returns:
        List of complexity report dicts.
    """
    reports = []
    json_files = sorted(research_dir.glob('*_complexity.json'))

    if not json_files:
        logger.warning(f"No complexity reports found in {research_dir}")
        return reports

    for json_file in json_files:
        try:
            data = load_json(json_file)
            if data:
                reports.append(data)
                logger.info(f"Loaded: {json_file.name}")
        except Exception as e:
            logger.error(f"Failed to load {json_file.name}: {e}")

    return reports


def categorize_files(
    reports: List[dict],
    logger
) -> Tuple[List[dict], List[dict], List[dict]]:
    """
    Categorize files by confidence score.

    Args:
        reports: List of complexity report dicts.
        logger: Logger instance.

    Returns:
        Tuple of (high_confidence, medium_confidence, low_confidence) lists.
    """
    high = []
    medium = []
    low = []

    for report in reports:
        confidence = report.get('confidence', 0.0)
        file_name = report.get('file', 'unknown')

        entry = {
            'file': file_name,
            'confidence': confidence,
            'flags': report.get('flags', {}),
        }

        if confidence >= HIGH_THRESHOLD:
            high.append(entry)
            logger.info(f"  HIGH   ({confidence:.4f}): {file_name}")
        elif confidence >= MEDIUM_THRESHOLD:
            medium.append(entry)
            logger.info(f"  MEDIUM ({confidence:.4f}): {file_name}")
        else:
            low.append(entry)
            logger.info(f"  LOW    ({confidence:.4f}): {file_name}")

    return high, medium, low


def build_conversion_plan(
    high: List[dict],
    medium: List[dict],
    low: List[dict],
    reports: List[dict]
) -> dict:
    """
    Build the conversion plan YAML structure.

    Args:
        high: High confidence file entries.
        medium: Medium confidence file entries.
        low: Low confidence file entries.
        reports: Original complexity reports for detail.

    Returns:
        Conversion plan dict suitable for YAML serialization.
    """
    # Collect summary statistics
    total_files = len(high) + len(medium) + len(low)
    avg_confidence = 0.0
    if total_files > 0:
        all_confs = [r.get('confidence', 0.0) for r in reports]
        avg_confidence = round(sum(all_confs) / len(all_confs), 4)

    # Identify special cases
    files_with_macros = [
        r.get('file', 'unknown') for r in reports
        if r.get('flags', {}).get('has_macros', False)
    ]
    files_with_sys_calendar = [
        r.get('file', 'unknown') for r in reports
        if r.get('flags', {}).get('has_sys_calendar', False)
    ]
    files_with_update_from = [
        r.get('file', 'unknown') for r in reports
        if r.get('flags', {}).get('has_update_from', False)
    ]
    deeply_nested = [
        r.get('file', 'unknown') for r in reports
        if r.get('flags', {}).get('deeply_nested', False)
    ]

    plan = {
        'objective': 'Convert all Teradata SQL files to Snowflake-compatible SQL',
        'created': get_iso_timestamp(),
        'summary': {
            'total_files': total_files,
            'high_confidence': len(high),
            'medium_confidence': len(medium),
            'low_confidence': len(low),
            'average_confidence': avg_confidence,
        },
        'components': {
            'high_confidence_files': {
                'description': 'Files suitable for fully automated conversion (confidence >= 0.95)',
                'count': len(high),
                'strategy': 'automated',
                'files': [entry['file'] for entry in high],
            },
            'medium_confidence_files': {
                'description': 'Files for automated conversion with post-review (confidence 0.85-0.94)',
                'count': len(medium),
                'strategy': 'automated_with_review',
                'files': [entry['file'] for entry in medium],
            },
            'low_confidence_files': {
                'description': 'Files requiring manual review after conversion (confidence < 0.85)',
                'count': len(low),
                'strategy': 'manual_review_required',
                'files': [entry['file'] for entry in low],
            },
        },
        'special_cases': {
            'macros': {
                'description': 'Files containing MACRO definitions (no Snowflake equivalent)',
                'count': len(files_with_macros),
                'files': files_with_macros,
                'action': 'Manual conversion required',
            },
            'sys_calendar': {
                'description': 'Files referencing SYS_CALENDAR (Teradata system table)',
                'count': len(files_with_sys_calendar),
                'files': files_with_sys_calendar,
                'action': 'Replace with Snowflake date functions or custom calendar table',
            },
            'update_from': {
                'description': 'Files with UPDATE FROM syntax (converted to MERGE)',
                'count': len(files_with_update_from),
                'files': files_with_update_from,
                'action': 'Automatic conversion to MERGE; verify logic',
            },
            'deeply_nested': {
                'description': 'Files with deeply nested subqueries (depth > 3)',
                'count': len(deeply_nested),
                'files': deeply_nested,
                'action': 'Review for CTE refactoring opportunities',
            },
        },
        'execution_order': [
            {
                'step': 1,
                'action': 'Convert high-confidence files',
                'files': [entry['file'] for entry in high],
            },
            {
                'step': 2,
                'action': 'Convert medium-confidence files',
                'files': [entry['file'] for entry in medium],
            },
            {
                'step': 3,
                'action': 'Convert low-confidence files',
                'files': [entry['file'] for entry in low],
            },
            {
                'step': 4,
                'action': 'Validate all converted files',
                'files': 'all',
            },
            {
                'step': 5,
                'action': 'Auto-correct validation issues',
                'files': 'files_with_errors',
            },
            {
                'step': 6,
                'action': 'Generate conversion report',
                'files': 'all',
            },
        ],
    }

    return plan


def main():
    """
    Read complexity reports and create the conversion plan.

    Entry point for Phase 2 of the conversion pipeline.
    """
    logger = setup_logging('plan_conversion', log_dir=PROJECT_ROOT / 'thoughts' / 'logs')
    logger.info("=" * 60)
    logger.info("Phase 2: Plan Conversion")
    logger.info("=" * 60)

    research_dir = PROJECT_ROOT / 'research'
    plans_dir = PROJECT_ROOT / 'plans'

    # Load complexity reports
    reports = load_complexity_reports(research_dir, logger)

    if not reports:
        logger.warning("No complexity reports found. Run Phase 1 first.")
        return

    logger.info(f"Loaded {len(reports)} complexity report(s)")

    # Categorize files
    logger.info("")
    logger.info("--- File Categorization ---")
    high, medium, low = categorize_files(reports, logger)

    # Build conversion plan
    plan = build_conversion_plan(high, medium, low, reports)

    # Save plan
    plan_path = plans_dir / 'conversion_plan.yaml'
    save_yaml(plan, plan_path)
    logger.info(f"Conversion plan saved to: {plan_path}")

    # Summary
    logger.info("")
    logger.info("=" * 60)
    logger.info("Conversion Plan Summary")
    logger.info("=" * 60)
    logger.info(f"Total files: {plan['summary']['total_files']}")
    logger.info(f"High confidence:   {plan['summary']['high_confidence']}")
    logger.info(f"Medium confidence:  {plan['summary']['medium_confidence']}")
    logger.info(f"Low confidence:     {plan['summary']['low_confidence']}")
    logger.info(f"Average confidence: {plan['summary']['average_confidence']}")
    logger.info("=" * 60)


if __name__ == '__main__':
    main()
