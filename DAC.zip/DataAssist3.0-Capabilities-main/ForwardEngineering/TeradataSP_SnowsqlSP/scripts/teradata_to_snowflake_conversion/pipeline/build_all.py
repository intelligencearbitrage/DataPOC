"""
Master Build Script - Runs the full SQL conversion pipeline.

Discovers and runs all generate_*.py scripts in scripts/, OR runs
the full convert-validate-correct pipeline for batch SQL conversion.

Usage:
    python scripts/build_all.py              # Run all generators
    python scripts/build_all.py --pipeline   # Run full conversion pipeline
"""

import importlib
import sys
from pathlib import Path

SCRIPTS_DIR = Path(__file__).resolve().parent.parent
PROJECT_ROOT = SCRIPTS_DIR
sys.path.insert(0, str(SCRIPTS_DIR))

from utils import setup_logging, get_timestamp, save_yaml


def discover_generators() -> list:
    """Find all generate_*.py scripts in the scripts/pipeline/ directory."""
    pipeline_dir = SCRIPTS_DIR / 'pipeline'
    generators = sorted(pipeline_dir.glob('generate_*.py'))
    return generators


def run_generator(script_path: Path, logger) -> dict:
    """Import and run a single generator script."""
    module_name = script_path.stem
    logger.info(f"Running: {module_name}")

    result = {'script': module_name, 'status': 'unknown', 'error': None}

    try:
        module = importlib.import_module(f"pipeline.{module_name}")
        if hasattr(module, 'main'):
            module.main()
            result['status'] = 'success'
        else:
            result['status'] = 'skipped'
            result['error'] = f'{module_name} has no main() function'
            logger.warning(result['error'])
    except Exception as e:
        result['status'] = 'failed'
        result['error'] = str(e)
        logger.error(f"{module_name} failed: {e}")

    return result


def run_pipeline(logger):
    """Run the full conversion pipeline: analyze -> convert -> validate -> correct."""
    logger.info("Running full conversion pipeline...")

    pipeline_scripts = [
        'analyze_complexity',
        'convert_sql',
        'validate_sql',
        'correct_sql',
        'generate_reports',
    ]

    results = []
    for script_name in pipeline_scripts:
        logger.info(f"Pipeline step: {script_name}")
        try:
            module = importlib.import_module(f"pipeline.{script_name}")
            if hasattr(module, 'main'):
                module.main()
                results.append({'script': script_name, 'status': 'success', 'error': None})
            else:
                results.append({'script': script_name, 'status': 'skipped', 'error': 'no main()'})
        except Exception as e:
            logger.error(f"{script_name} failed: {e}")
            results.append({'script': script_name, 'status': 'failed', 'error': str(e)})

    return results


def main():
    """Discover and run all generator scripts."""
    logger = setup_logging('build_all', log_dir=PROJECT_ROOT / 'thoughts' / 'logs')
    logger.info("=" * 60)
    logger.info("Build All - Starting")
    logger.info("=" * 60)

    # Check for --pipeline flag
    if '--pipeline' in sys.argv:
        results = run_pipeline(logger)
    else:
        generators = discover_generators()

        if not generators:
            logger.info("No generate_*.py scripts found. Running pipeline instead.")
            results = run_pipeline(logger)
        else:
            logger.info(f"Found {len(generators)} generator(s): "
                        f"{[g.stem for g in generators]}")
            results = []
            for gen_path in generators:
                result = run_generator(gen_path, logger)
                results.append(result)

    # Summary
    succeeded = sum(1 for r in results if r['status'] == 'success')
    failed = sum(1 for r in results if r['status'] == 'failed')
    skipped = sum(1 for r in results if r['status'] == 'skipped')

    logger.info("=" * 60)
    logger.info(f"Build Complete: {succeeded} succeeded, {failed} failed, {skipped} skipped")
    logger.info("=" * 60)

    # Save build report
    report = {
        'build_report': {
            'timestamp': get_timestamp(),
            'generators_found': len(results),
            'succeeded': succeeded,
            'failed': failed,
            'skipped': skipped,
            'results': results,
        }
    }
    save_yaml(report, PROJECT_ROOT / 'thoughts' / 'build_report.yaml')

    if failed > 0:
        logger.error(f"{failed} step(s) failed. Check logs for details.")
        sys.exit(1)


if __name__ == '__main__':
    main()
