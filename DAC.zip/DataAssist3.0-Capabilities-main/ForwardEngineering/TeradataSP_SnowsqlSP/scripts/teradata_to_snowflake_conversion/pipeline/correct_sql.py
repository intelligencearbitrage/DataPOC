"""
Phase 4b: Correct SQL
======================

Reads converted files from output/ and their validation reports from
testscripts/. For files with validation errors, uses the SQLCorrector
to apply automatic corrections and writes corrected SQL back to output/
(in-place replacement).

Usage:
    python scripts/correct_sql.py
"""

import sys
from pathlib import Path
from typing import Dict, List, Optional

# Resolve paths
SCRIPTS_DIR = Path(__file__).resolve().parent.parent
PROJECT_ROOT = SCRIPTS_DIR
sys.path.insert(0, str(SCRIPTS_DIR))

from utils import setup_logging, load_json, save_json, get_iso_timestamp
from corrector import SQLCorrector, ValidationIssue


def load_validation_report(testscripts_dir: Path, file_stem: str) -> Optional[dict]:
    """
    Load the validation report for a given file.

    Args:
        testscripts_dir: Path to testscripts/ directory.
        file_stem: Stem of the file (without extension).

    Returns:
        Validation report dict, or None if not found.
    """
    report_path = testscripts_dir / f'{file_stem}_validation.json'
    if not report_path.exists():
        return None
    return load_json(report_path)


def extract_validation_issues(report: dict) -> List[ValidationIssue]:
    """
    Convert validation report issues to ValidationIssue objects
    that the SQLCorrector can work with.

    Args:
        report: Validation report dict from testscripts/.

    Returns:
        List of ValidationIssue instances.
    """
    issues = []
    for issue_data in report.get('issues', []):
        issue = ValidationIssue(
            rule_name=issue_data.get('rule_name', ''),
            line_number=issue_data.get('line_number', 0),
            message=issue_data.get('message', ''),
            matched_text=issue_data.get('matched_text', ''),
        )
        issues.append(issue)
    return issues


def correct_file(
    file_path: Path,
    corrector: SQLCorrector,
    validation_issues: List[ValidationIssue],
    logger
) -> dict:
    """
    Apply corrections to a single converted SQL file.

    Args:
        file_path: Path to the converted SQL file in output/.
        corrector: Initialized SQLCorrector instance.
        validation_issues: List of validation issues for this file.
        logger: Logger instance.

    Returns:
        Dict with correction result metadata.
    """
    logger.info(f"Correcting: {file_path.name} ({len(validation_issues)} issues)")

    result_meta = {
        'file': file_path.name,
        'status': 'unknown',
        'corrections_applied': 0,
        'corrections_skipped': 0,
        'has_changes': False,
    }

    try:
        # Read current SQL
        sql = file_path.read_text(encoding='utf-8')

        if not sql.strip():
            logger.warning(f"  Skipping empty file: {file_path.name}")
            result_meta['status'] = 'skipped'
            return result_meta

        # Apply corrections based on validation issues
        if validation_issues:
            result = corrector.correct_from_validation(sql, validation_issues)
        else:
            # Apply all corrections if no specific issues
            result = corrector.correct_all(sql)

        result_meta['corrections_applied'] = result.total_corrections
        result_meta['corrections_skipped'] = len(result.corrections_skipped)
        result_meta['has_changes'] = result.has_changes

        if result.has_changes:
            # Write corrected SQL back to the same file (in-place)
            file_path.write_text(result.corrected, encoding='utf-8')
            result_meta['status'] = 'corrected'
            logger.info(
                f"  Corrected: {result.total_corrections} correction(s) applied"
            )
        else:
            result_meta['status'] = 'unchanged'
            logger.info(f"  No changes needed")

        if result.corrections_skipped:
            logger.info(
                f"  Skipped: {len(result.corrections_skipped)} correction(s)"
            )

        if result.warnings:
            for warning in result.warnings:
                logger.warning(f"  Warning: {warning}")

    except Exception as e:
        result_meta['status'] = 'failed'
        result_meta['error'] = str(e)
        logger.error(f"  FAILED: {e}")

    return result_meta


def main():
    """
    Correct all converted SQL files that have validation errors.

    Entry point for Phase 4b of the conversion pipeline.
    """
    logger = setup_logging('correct_sql', log_dir=PROJECT_ROOT / 'thoughts' / 'logs')
    logger.info("=" * 60)
    logger.info("Phase 4b: Correct SQL")
    logger.info("=" * 60)

    output_dir = PROJECT_ROOT / 'output'
    testscripts_dir = PROJECT_ROOT / 'testscripts'

    # Initialize corrector
    corrector = SQLCorrector(logger=logger)

    # Collect converted files
    converted_files = sorted(output_dir.glob('*.sql'))

    if not converted_files:
        logger.warning(f"No converted SQL files found in {output_dir}")
        return

    logger.info(f"Found {len(converted_files)} file(s) to check")
    logger.info("")

    # Process each file
    results = []
    files_needing_correction = 0

    for converted_file in converted_files:
        try:
            # Load validation report
            report = load_validation_report(testscripts_dir, converted_file.stem)

            if report is None:
                logger.info(
                    f"No validation report for {converted_file.name}. "
                    f"Applying all corrections."
                )
                validation_issues = []
            else:
                is_valid = report.get('is_valid', True)
                total_issues = report.get('summary', {}).get('total_issues', 0)

                if is_valid and total_issues == 0:
                    logger.info(f"Skipping {converted_file.name}: Already valid")
                    results.append({
                        'file': converted_file.name,
                        'status': 'already_valid',
                    })
                    continue

                validation_issues = extract_validation_issues(report)
                files_needing_correction += 1

            result = correct_file(
                converted_file, corrector, validation_issues, logger
            )
            results.append(result)

        except Exception as e:
            logger.error(f"Unexpected error correcting {converted_file.name}: {e}")
            results.append({
                'file': converted_file.name,
                'status': 'failed',
                'error': str(e),
            })

    # Summary
    logger.info("")
    logger.info("=" * 60)
    logger.info("Correction Summary")
    logger.info("=" * 60)

    total = len(results)
    corrected = sum(1 for r in results if r.get('status') == 'corrected')
    unchanged = sum(1 for r in results if r.get('status') == 'unchanged')
    already_valid = sum(1 for r in results if r.get('status') == 'already_valid')
    failed = sum(1 for r in results if r.get('status') == 'failed')
    total_corrections = sum(r.get('corrections_applied', 0) for r in results)

    logger.info(f"Total files:          {total}")
    logger.info(f"Files corrected:      {corrected}")
    logger.info(f"Files unchanged:      {unchanged}")
    logger.info(f"Already valid:        {already_valid}")
    logger.info(f"Failed:               {failed}")
    logger.info(f"Total corrections:    {total_corrections}")
    logger.info("=" * 60)


if __name__ == '__main__':
    main()
