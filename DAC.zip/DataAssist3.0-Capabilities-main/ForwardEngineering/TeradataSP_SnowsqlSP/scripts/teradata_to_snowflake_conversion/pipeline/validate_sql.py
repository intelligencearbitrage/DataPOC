"""
Phase 4a: Validate SQL
=======================

Reads converted SQL files from output/ and validates each using the
ConversionValidator. Produces per-file validation JSON reports in
testscripts/.

Usage:
    python scripts/validate_sql.py
"""

import json
import sys
from pathlib import Path
from typing import Dict, List

# Resolve paths
SCRIPTS_DIR = Path(__file__).resolve().parent.parent
PROJECT_ROOT = SCRIPTS_DIR
sys.path.insert(0, str(SCRIPTS_DIR))

from utils import setup_logging, save_json, get_iso_timestamp
from validators import ConversionValidator


# File extensions to validate in output/
VALIDATE_EXTENSIONS = ['.sql']


def validate_file(
    file_path: Path,
    validator: ConversionValidator,
    testscripts_dir: Path,
    logger
) -> dict:
    """
    Validate a single converted SQL file and save the validation report.

    Args:
        file_path: Path to the converted SQL file.
        validator: Initialized validator instance.
        testscripts_dir: Path to testscripts/ directory for reports.
        logger: Logger instance.

    Returns:
        Dict with validation summary.
    """
    logger.info(f"Validating: {file_path.name}")

    summary = {
        'file': file_path.name,
        'status': 'unknown',
        'is_valid': False,
        'errors': 0,
        'warnings': 0,
        'info': 0,
        'total_issues': 0,
    }

    try:
        # Read the converted SQL
        sql = file_path.read_text(encoding='utf-8')

        if not sql.strip():
            logger.warning(f"  Skipping empty file: {file_path.name}")
            summary['status'] = 'skipped'
            return summary

        # Validate
        result = validator.validate(sql, file_path=str(file_path))

        # Build validation report
        report = {
            'file': file_path.name,
            'file_path': str(file_path),
            'timestamp': get_iso_timestamp(),
            'is_valid': result.is_valid,
            'score': result.score,
            'summary': {
                'total_issues': result.total_issues,
                'errors': result.errors,
                'warnings': result.warnings,
                'info': result.info,
                'lines_checked': result.lines_checked,
                'score': result.score,
                'validation_time_seconds': round(result.validation_time, 4),
            },
            'issues': [
                {
                    'rule_name': issue.rule_name,
                    'category': issue.category.value,
                    'severity': issue.severity.value,
                    'message': issue.message,
                    'description': issue.description,
                    'suggestion': issue.suggestion,
                    'line_number': issue.line_number,
                    'column': issue.column,
                    'matched_text': issue.matched_text,
                    'line_content': issue.line_content[:200],  # Truncate long lines
                }
                for issue in result.issues
            ],
        }

        # Save validation report
        report_path = testscripts_dir / f'{file_path.stem}_validation.json'
        save_json(report, report_path)

        # Update summary
        summary['status'] = 'valid' if result.is_valid else 'invalid'
        summary['is_valid'] = result.is_valid
        summary['errors'] = result.errors
        summary['warnings'] = result.warnings
        summary['info'] = result.info
        summary['total_issues'] = result.total_issues
        summary['score'] = result.score

        logger.info(
            f"  Score: {result.score}% | {result.errors} errors, "
            f"{result.warnings} warnings, {result.info} info"
        )

    except Exception as e:
        summary['status'] = 'error'
        summary['error'] = str(e)
        logger.error(f"  ERROR validating {file_path.name}: {e}")

    return summary


def main():
    """
    Validate all converted SQL files from output/.

    Entry point for Phase 4a of the conversion pipeline.
    """
    logger = setup_logging('validate_sql', log_dir=PROJECT_ROOT / 'thoughts' / 'logs')
    logger.info("=" * 60)
    logger.info("Phase 4a: Validate SQL")
    logger.info("=" * 60)

    output_dir = PROJECT_ROOT / 'output'
    testscripts_dir = PROJECT_ROOT / 'testscripts'

    # Ensure testscripts directory exists
    testscripts_dir.mkdir(parents=True, exist_ok=True)

    # Initialize validator
    validator = ConversionValidator()

    # Collect converted files
    converted_files = []
    for ext in VALIDATE_EXTENSIONS:
        converted_files.extend(sorted(output_dir.glob(f'*{ext}')))

    if not converted_files:
        logger.warning(f"No converted SQL files found in {output_dir}")
        return

    logger.info(f"Found {len(converted_files)} file(s) to validate")
    logger.info("")

    # Validate each file
    results = []
    for converted_file in converted_files:
        try:
            summary = validate_file(
                converted_file, validator, testscripts_dir, logger
            )
            results.append(summary)
        except Exception as e:
            logger.error(f"Unexpected error validating {converted_file.name}: {e}")
            results.append({
                'file': converted_file.name,
                'status': 'error',
                'error': str(e),
            })

    # Summary
    logger.info("")
    logger.info("=" * 60)
    logger.info("Validation Summary")
    logger.info("=" * 60)

    total = len(results)
    errored = sum(1 for r in results if r.get('status') == 'error')
    skipped = sum(1 for r in results if r.get('status') == 'skipped')
    total_errors = sum(r.get('errors', 0) for r in results)
    total_warnings = sum(r.get('warnings', 0) for r in results)
    scores = [r.get('score', 0) for r in results if r.get('score') is not None]
    avg_score = round(sum(scores) / len(scores), 1) if scores else 0.0

    logger.info(f"Total files:      {total}")
    logger.info(f"Average score:    {avg_score}%")
    logger.info(f"Total errors:     {total_errors}")
    logger.info(f"Total warnings:   {total_warnings}")
    logger.info(f"Skipped:          {skipped}")
    logger.info("=" * 60)


if __name__ == '__main__':
    main()
