"""
Phase 1: Analyze Complexity
============================

Scans knowledgebase/ for .sql, .bteq, and .txt files and produces
a per-file complexity analysis report as JSON in research/.

Complexity factors detected:
    - Nested subquery depth (SELECT within SELECT)
    - UPDATE FROM patterns (Teradata-specific)
    - SYS_CALENDAR references
    - TRUNC / MACRO patterns

Each factor applies a penalty to a starting confidence score of 1.0.
Files with lower confidence scores require more careful conversion review.

Usage:
    python scripts/analyze_complexity.py
"""

import json
import re
import sys
from pathlib import Path
from typing import Dict, List, Tuple

# Resolve paths
SCRIPTS_DIR = Path(__file__).resolve().parent.parent
PROJECT_ROOT = SCRIPTS_DIR
sys.path.insert(0, str(SCRIPTS_DIR))

from utils import setup_logging, get_iso_timestamp, save_json


# File extensions to scan
SCAN_EXTENSIONS = ['.sql', '.bteq', '.txt']


def count_nested_subquery_depth(sql: str) -> int:
    """
    Count the maximum nested subquery depth in SQL content.

    Uses a simple approach: finds all SELECT keywords and tracks
    the nesting depth by counting open/close parentheses context.

    Args:
        sql: The SQL content to analyze.

    Returns:
        Maximum nesting depth of SELECT statements (0 = no nesting).
    """
    max_depth = 0
    current_depth = 0

    # Normalize whitespace for easier regex
    normalized = re.sub(r'--[^\n]*', '', sql)  # Remove single-line comments
    normalized = re.sub(r'/\*[\s\S]*?\*/', '', normalized)  # Remove block comments

    # Track parenthesis depth and SELECT occurrences
    paren_depth = 0
    select_depths = []

    i = 0
    upper = normalized.upper()
    while i < len(normalized):
        if normalized[i] == '(':
            paren_depth += 1
        elif normalized[i] == ')':
            paren_depth = max(0, paren_depth - 1)
        elif upper[i:i+6] == 'SELECT' and (i == 0 or not upper[i-1].isalpha()):
            # Check it's a standalone SELECT keyword
            end_pos = i + 6
            if end_pos >= len(upper) or not upper[end_pos].isalpha():
                select_depths.append(paren_depth)
        i += 1

    if select_depths:
        max_depth = max(select_depths)

    return max_depth


def detect_update_from(sql: str) -> List[dict]:
    """
    Detect UPDATE FROM patterns (Teradata-specific syntax).

    Args:
        sql: The SQL content to analyze.

    Returns:
        List of dicts with 'line' and 'match' for each occurrence.
    """
    occurrences = []
    pattern = re.compile(
        r'\bUPDATE\s+\w+\s+(?:\w+\s+)?FROM\b',
        re.IGNORECASE
    )

    for i, line in enumerate(sql.split('\n'), start=1):
        match = pattern.search(line)
        if match:
            occurrences.append({
                'line': i,
                'match': match.group(0).strip(),
            })

    return occurrences


def detect_sys_calendar(sql: str) -> List[dict]:
    """
    Detect references to SYS_CALENDAR (Teradata system table).

    Args:
        sql: The SQL content to analyze.

    Returns:
        List of dicts with 'line' and 'match' for each occurrence.
    """
    occurrences = []
    pattern = re.compile(r'\bSYS_CALENDAR\b', re.IGNORECASE)

    for i, line in enumerate(sql.split('\n'), start=1):
        match = pattern.search(line)
        if match:
            occurrences.append({
                'line': i,
                'match': match.group(0),
            })

    return occurrences


def detect_trunc_patterns(sql: str) -> List[dict]:
    """
    Detect TRUNC function usage (needs conversion to DATE_TRUNC in Snowflake).

    Args:
        sql: The SQL content to analyze.

    Returns:
        List of dicts with 'line' and 'match' for each occurrence.
    """
    occurrences = []
    pattern = re.compile(r'\bTRUNC\s*\(', re.IGNORECASE)

    for i, line in enumerate(sql.split('\n'), start=1):
        match = pattern.search(line)
        if match:
            occurrences.append({
                'line': i,
                'match': match.group(0).strip(),
            })

    return occurrences


def detect_macro_patterns(sql: str) -> List[dict]:
    """
    Detect MACRO definitions (Teradata-specific, no Snowflake equivalent).

    Args:
        sql: The SQL content to analyze.

    Returns:
        List of dicts with 'line' and 'match' for each occurrence.
    """
    occurrences = []
    pattern = re.compile(
        r'\b(?:CREATE|REPLACE)\s+MACRO\b',
        re.IGNORECASE
    )

    for i, line in enumerate(sql.split('\n'), start=1):
        match = pattern.search(line)
        if match:
            occurrences.append({
                'line': i,
                'match': match.group(0).strip(),
            })

    return occurrences


def calculate_confidence(
    subquery_depth: int,
    update_from_count: int,
    sys_calendar_count: int,
    trunc_count: int,
    macro_count: int
) -> float:
    """
    Calculate a confidence score for automated conversion.

    Starts at 1.0 and applies penalties for complexity factors.

    Args:
        subquery_depth: Maximum nested subquery depth.
        update_from_count: Number of UPDATE FROM occurrences.
        sys_calendar_count: Number of SYS_CALENDAR references.
        trunc_count: Number of TRUNC patterns.
        macro_count: Number of MACRO definitions.

    Returns:
        Confidence score between 0.0 and 1.0.
    """
    score = 1.0

    # Subquery depth penalty: -0.02 per level beyond 1
    if subquery_depth > 1:
        score -= (subquery_depth - 1) * 0.02

    # UPDATE FROM penalty: -0.03 per occurrence
    score -= update_from_count * 0.03

    # SYS_CALENDAR penalty: -0.05 per occurrence (needs manual review)
    score -= sys_calendar_count * 0.05

    # TRUNC penalty: -0.01 per occurrence (usually auto-convertible)
    score -= trunc_count * 0.01

    # MACRO penalty: -0.10 per occurrence (cannot be auto-converted)
    score -= macro_count * 0.10

    # Clamp to [0.0, 1.0]
    return max(0.0, min(1.0, round(score, 4)))


def analyze_file(file_path: Path, logger) -> dict:
    """
    Analyze a single SQL file for complexity factors.

    Args:
        file_path: Path to the SQL file.
        logger: Logger instance.

    Returns:
        Dict with analysis results.
    """
    logger.info(f"Analyzing: {file_path.name}")

    try:
        content = file_path.read_text(encoding='utf-8', errors='replace')
    except Exception as e:
        logger.error(f"Failed to read {file_path.name}: {e}")
        return {
            'file': file_path.name,
            'error': str(e),
            'confidence': 0.0,
        }

    line_count = len(content.split('\n'))

    # Detect complexity factors
    subquery_depth = count_nested_subquery_depth(content)
    update_from = detect_update_from(content)
    sys_calendar = detect_sys_calendar(content)
    trunc_patterns = detect_trunc_patterns(content)
    macro_patterns = detect_macro_patterns(content)

    # Calculate confidence
    confidence = calculate_confidence(
        subquery_depth=subquery_depth,
        update_from_count=len(update_from),
        sys_calendar_count=len(sys_calendar),
        trunc_count=len(trunc_patterns),
        macro_count=len(macro_patterns),
    )

    logger.info(
        f"  {file_path.name}: depth={subquery_depth}, "
        f"update_from={len(update_from)}, sys_cal={len(sys_calendar)}, "
        f"trunc={len(trunc_patterns)}, macro={len(macro_patterns)}, "
        f"confidence={confidence}"
    )

    return {
        'file': file_path.name,
        'file_path': str(file_path),
        'line_count': line_count,
        'size_bytes': file_path.stat().st_size,
        'analysis_timestamp': get_iso_timestamp(),
        'complexity_factors': {
            'nested_subquery_depth': subquery_depth,
            'update_from_patterns': {
                'count': len(update_from),
                'occurrences': update_from,
            },
            'sys_calendar_references': {
                'count': len(sys_calendar),
                'occurrences': sys_calendar,
            },
            'trunc_patterns': {
                'count': len(trunc_patterns),
                'occurrences': trunc_patterns,
            },
            'macro_patterns': {
                'count': len(macro_patterns),
                'occurrences': macro_patterns,
            },
        },
        'confidence': confidence,
        'flags': {
            'needs_manual_review': confidence < 0.85,
            'has_macros': len(macro_patterns) > 0,
            'has_sys_calendar': len(sys_calendar) > 0,
            'has_update_from': len(update_from) > 0,
            'deeply_nested': subquery_depth > 3,
        },
    }


def main():
    """
    Scan knowledgebase/ and produce complexity analysis reports in research/.

    Entry point for Phase 1 of the conversion pipeline.
    """
    logger = setup_logging('analyze_complexity', log_dir=PROJECT_ROOT / 'thoughts' / 'logs')
    logger.info("=" * 60)
    logger.info("Phase 1: Analyze Complexity")
    logger.info("=" * 60)

    input_dir = PROJECT_ROOT / 'inputs'
    research_dir = PROJECT_ROOT / 'research'

    if not input_dir.exists():
        logger.error(f"Input directory not found: {input_dir}")
        return

    # Collect all SQL files (recursive to include subdirectories)
    sql_files = []
    for ext in SCAN_EXTENSIONS:
        sql_files.extend(sorted(input_dir.rglob(f'*{ext}')))

    if not sql_files:
        logger.warning(f"No SQL files found in {input_dir}")
        return

    logger.info(f"Found {len(sql_files)} file(s) to analyze")

    # Analyze each file
    results = []
    for sql_file in sql_files:
        try:
            report = analyze_file(sql_file, logger)
            results.append(report)

            # Save individual report
            report_path = research_dir / f'{sql_file.stem}_complexity.json'
            save_json(report, report_path)
            logger.info(f"  Saved: {report_path.name}")

        except Exception as e:
            logger.error(f"Error analyzing {sql_file.name}: {e}")
            results.append({
                'file': sql_file.name,
                'error': str(e),
                'confidence': 0.0,
            })

    # Summary
    logger.info("")
    logger.info("=" * 60)
    logger.info("Analysis Summary")
    logger.info("=" * 60)

    total = len(results)
    high_conf = sum(1 for r in results if r.get('confidence', 0) >= 0.95)
    med_conf = sum(1 for r in results if 0.85 <= r.get('confidence', 0) < 0.95)
    low_conf = sum(1 for r in results if r.get('confidence', 0) < 0.85)
    errors = sum(1 for r in results if 'error' in r)

    logger.info(f"Total files analyzed: {total}")
    logger.info(f"High confidence (>=0.95): {high_conf}")
    logger.info(f"Medium confidence (0.85-0.94): {med_conf}")
    logger.info(f"Low confidence (<0.85): {low_conf}")
    logger.info(f"Errors: {errors}")
    logger.info("=" * 60)


if __name__ == '__main__':
    main()
