"""
Phase 4c: Generate Reports
============================

Reads all validation reports from testscripts/ and generates a
comprehensive conversion report at output/conversion_report.md.

The report includes:
    - Overall statistics (files processed, pass/fail rates)
    - Per-file summaries
    - Issue breakdown by category and severity
    - Recommendations for manual review

Usage:
    python scripts/generate_reports.py
"""

import sys
from datetime import datetime
from pathlib import Path
from typing import Dict, List

# Resolve paths
SCRIPTS_DIR = Path(__file__).resolve().parent.parent
PROJECT_ROOT = SCRIPTS_DIR
sys.path.insert(0, str(SCRIPTS_DIR))

from utils import setup_logging, load_json, get_iso_timestamp


def load_all_validation_reports(testscripts_dir: Path, logger) -> List[dict]:
    """
    Load all *_validation.json files from testscripts/.

    Args:
        testscripts_dir: Path to testscripts/ directory.
        logger: Logger instance.

    Returns:
        List of validation report dicts.
    """
    reports = []
    json_files = sorted(testscripts_dir.glob('*_validation.json'))

    if not json_files:
        logger.warning(f"No validation reports found in {testscripts_dir}")
        return reports

    for json_file in json_files:
        try:
            data = load_json(json_file)
            if data:
                reports.append(data)
        except Exception as e:
            logger.error(f"Failed to load {json_file.name}: {e}")

    logger.info(f"Loaded {len(reports)} validation report(s)")
    return reports


def compute_statistics(reports: List[dict]) -> dict:
    """
    Compute aggregate statistics from all validation reports.

    Args:
        reports: List of validation report dicts.

    Returns:
        Dict with computed statistics.
    """
    total_files = len(reports)

    total_errors = 0
    total_warnings = 0
    total_info = 0
    total_lines = 0
    file_scores = []

    issue_categories: Dict[str, int] = {}
    issue_rules: Dict[str, int] = {}

    for report in reports:
        summary = report.get('summary', {})
        total_errors += summary.get('errors', 0)
        total_warnings += summary.get('warnings', 0)
        total_info += summary.get('info', 0)
        total_lines += summary.get('lines_checked', 0)

        # Per-file score: percentage based on errors vs lines checked
        lines = summary.get('lines_checked', 0)
        errors = summary.get('errors', 0)
        if lines > 0:
            file_score = round(max(0.0, (1 - errors / lines) * 100), 1)
        else:
            file_score = 0.0
        file_scores.append(file_score)

        for issue in report.get('issues', []):
            cat = issue.get('category', 'unknown')
            rule = issue.get('rule_name', 'unknown')
            issue_categories[cat] = issue_categories.get(cat, 0) + 1
            issue_rules[rule] = issue_rules.get(rule, 0) + 1

    avg_score = round(sum(file_scores) / len(file_scores), 1) if file_scores else 0.0

    return {
        'total_files': total_files,
        'avg_score': avg_score,
        'file_scores': file_scores,
        'total_errors': total_errors,
        'total_warnings': total_warnings,
        'total_info': total_info,
        'total_lines': total_lines,
        'issue_categories': dict(sorted(
            issue_categories.items(), key=lambda x: x[1], reverse=True
        )),
        'issue_rules': dict(sorted(
            issue_rules.items(), key=lambda x: x[1], reverse=True
        )),
    }


def generate_markdown_report(reports: List[dict], stats: dict) -> str:
    """
    Generate a Markdown conversion report.

    Args:
        reports: List of validation report dicts.
        stats: Computed statistics dict.

    Returns:
        Markdown report string.
    """
    timestamp = datetime.now().strftime('%Y-%m-%d %H:%M:%S')

    lines = [
        "# TD to SnowSQL Conversion Report",
        "",
        f"**Generated:** {timestamp}",
        "",
        "---",
        "",
        "## Overall Statistics",
        "",
        "| Metric | Value |",
        "|--------|-------|",
        f"| Total files processed | {stats['total_files']} |",
        f"| **Conversion accuracy** | **{stats['avg_score']}%** |",
        f"| Total errors | {stats['total_errors']} |",
        f"| Total warnings | {stats['total_warnings']} |",
        f"| Total info | {stats['total_info']} |",
        f"| Total lines checked | {stats['total_lines']} |",
        "",
    ]

    # Issue breakdown by category
    if stats['issue_categories']:
        lines.extend([
            "## Issues by Category",
            "",
            "| Category | Count |",
            "|----------|-------|",
        ])
        for category, count in stats['issue_categories'].items():
            lines.append(f"| {category} | {count} |")
        lines.append("")

    # Top rules triggered
    if stats['issue_rules']:
        lines.extend([
            "## Top Validation Rules Triggered",
            "",
            "| Rule | Count |",
            "|------|-------|",
        ])
        for rule, count in list(stats['issue_rules'].items())[:15]:
            lines.append(f"| {rule} | {count} |")
        if len(stats['issue_rules']) > 15:
            lines.append(f"| ... | ({len(stats['issue_rules']) - 15} more rules) |")
        lines.append("")

    # Per-file results
    lines.extend([
        "## Per-File Results",
        "",
        "| File | Score | Errors | Warnings | Info |",
        "|------|-------|--------|----------|------|",
    ])

    for report in reports:
        file_name = report.get('file', 'unknown')
        summary = report.get('summary', {})
        file_lines = summary.get('lines_checked', 0)
        errors = summary.get('errors', 0)
        warnings = summary.get('warnings', 0)
        info = summary.get('info', 0)
        file_score = summary.get('score', round(max(0.0, (1 - errors / max(file_lines, 1)) * 100), 1))
        lines.append(f"| {file_name} | **{file_score}%** | {errors} | {warnings} | {info} |")

    lines.append("")

    # Files needing manual review
    invalid_reports = [r for r in reports if not r.get('is_valid', False)]
    if invalid_reports:
        lines.extend([
            "## Files Requiring Manual Review",
            "",
        ])
        for report in invalid_reports:
            file_name = report.get('file', 'unknown')
            lines.append(f"### {file_name}")
            lines.append("")

            error_issues = [
                i for i in report.get('issues', [])
                if i.get('severity') == 'error'
            ]

            if error_issues:
                lines.append("| Line | Rule | Message | Suggestion |")
                lines.append("|------|------|---------|------------|")
                for issue in error_issues[:20]:  # Limit per file
                    line_num = issue.get('line_number', '-')
                    rule = issue.get('rule_name', '-')
                    msg = issue.get('message', '-')
                    suggestion = issue.get('suggestion', '-') or '-'
                    lines.append(f"| {line_num} | {rule} | {msg} | {suggestion} |")
                if len(error_issues) > 20:
                    lines.append(
                        f"| ... | | ({len(error_issues) - 20} more errors) | |"
                    )
                lines.append("")

    # Recommendations
    lines.extend([
        "---",
        "",
        "## Recommendations",
        "",
    ])

    if stats['avg_score'] >= 99:
        lines.append(
            "- Conversion quality is excellent. Review any remaining "
            "warnings before deploying."
        )
    elif stats['avg_score'] >= 95:
        lines.append(
            "- Conversion quality is good. Focus manual review on files "
            "with errors listed above."
        )
    elif stats['avg_score'] >= 90:
        lines.append(
            "- Conversion quality is solid. A few constructs need manual "
            "review as listed above."
        )
    else:
        lines.append(
            "- Conversion has significant issues. Review the error details "
            "and consider adding new rules for the flagged patterns."
        )

    if stats['total_warnings'] > 0:
        lines.append(
            f"- {stats['total_warnings']} warning(s) should be reviewed "
            f"for potential semantic changes."
        )

    lines.extend([
        "",
        "---",
        f"*Report generated by TD-SnowSQL-Toolkit at {timestamp}*",
        "",
    ])

    return '\n'.join(lines)


def main():
    """
    Generate the conversion report from validation results.

    Entry point for Phase 4c of the conversion pipeline.
    """
    logger = setup_logging(
        'generate_reports', log_dir=PROJECT_ROOT / 'thoughts' / 'logs'
    )
    logger.info("=" * 60)
    logger.info("Phase 4c: Generate Reports")
    logger.info("=" * 60)

    testscripts_dir = PROJECT_ROOT / 'testscripts'
    output_dir = PROJECT_ROOT / 'output'

    # Load all validation reports
    reports = load_all_validation_reports(testscripts_dir, logger)

    if not reports:
        logger.warning("No validation reports found. Run Phase 4a first.")
        return

    # Compute statistics
    stats = compute_statistics(reports)
    logger.info(f"Statistics computed for {stats['total_files']} file(s)")

    # Generate Markdown report
    md_report = generate_markdown_report(reports, stats)

    # Write report
    report_path = output_dir / 'conversion_report.md'
    output_dir.mkdir(parents=True, exist_ok=True)
    report_path.write_text(md_report, encoding='utf-8')
    logger.info(f"Report saved to: {report_path}")

    # Summary to console
    logger.info("")
    logger.info("=" * 60)
    logger.info("Report Summary")
    logger.info("=" * 60)
    logger.info(f"Total files:  {stats['total_files']}")
    logger.info(f"Accuracy:     {stats['avg_score']}%")
    logger.info(f"Errors:       {stats['total_errors']}")
    logger.info(f"Warnings:     {stats['total_warnings']}")
    logger.info(f"Report:       {report_path}")
    logger.info("=" * 60)


if __name__ == '__main__':
    main()
