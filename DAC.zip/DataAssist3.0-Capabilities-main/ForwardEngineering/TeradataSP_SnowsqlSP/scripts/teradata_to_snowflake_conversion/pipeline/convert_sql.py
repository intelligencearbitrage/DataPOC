"""
Phase 2: Convert SQL (Rules + LLM Review)
===========================================

Reads Teradata SQL files from knowledgebase/, loads configuration,
and uses the ReviewTeradataConverter to convert each file:
  1. Rules engine converts everything first
  2. Validates the rules output
  3. If validation has issues and LLM is available, sends to LLM for review
  4. LLM suggests targeted fixes (not full rewrites)
  5. Each fix is validated individually — only accepted if score doesn't drop

Each output file receives a header comment with conversion + review metadata.

Usage:
    python scripts/convert_sql.py
"""

import sys
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional

# Resolve paths
SCRIPTS_DIR = Path(__file__).resolve().parent.parent
PROJECT_ROOT = SCRIPTS_DIR
sys.path.insert(0, str(SCRIPTS_DIR))

from utils import setup_logging, load_json, get_iso_timestamp
from reviewer.review_converter import ReviewTeradataConverter, ReviewConversionResult


# File extensions to process
FILE_EXTENSIONS = ['.sql', '.bteq', '.txt']


def build_header_comment(
    source_file: str,
    result: ReviewConversionResult,
    timestamp: str
) -> str:
    """
    Build a header comment block for the converted SQL file.
    Includes both rules and LLM review metadata.
    """
    lines = [
        "-- ============================================================",
        f"-- Converted from Teradata: {source_file}",
        f"-- Conversion timestamp:    {timestamp}",
        f"-- Conversion mode:         rules + LLM review",
        f"-- Rules applied:           {len(result.rules_applied)}",
    ]

    if result.review_applied:
        lines.append(f"-- LLM review:              applied")
        lines.append(f"-- LLM fixes suggested:     {result.fixes_suggested}")
        lines.append(f"-- LLM fixes accepted:      {result.fixes_accepted}")
        lines.append(f"-- LLM fixes rejected:      {result.fixes_rejected}")
        lines.append(f"-- LLM tokens used:         {result.llm_input_tokens} in / {result.llm_output_tokens} out")
        lines.append(f"-- Rules validation score:  {result.rules_validation_score}%")
        lines.append(f"-- Final validation score:  {result.final_validation_score}%")
    elif result.review_available:
        lines.append(f"-- LLM review:              skipped (validation passed)")
    else:
        lines.append(f"-- LLM review:              not available")

    if result.warnings:
        lines.append(f"-- Warnings:                {len(result.warnings)}")

    lines.append("-- ============================================================")

    if result.rules_applied:
        lines.append("-- Rules applied:")
        for rule in result.rules_applied[:20]:
            lines.append(f"--   - {rule}")
        if len(result.rules_applied) > 20:
            lines.append(f"--   ... and {len(result.rules_applied) - 20} more")

    if result.accepted_fix_details:
        lines.append("-- LLM fixes accepted:")
        for fix in result.accepted_fix_details:
            lines.append(
                f"--   - #{fix['fix_id']}: {fix['description']} "
                f"[{fix['confidence']}/{fix['category']}]"
            )

    if result.warnings:
        lines.append("-- Warnings:")
        for warning in result.warnings[:15]:
            lines.append(f"--   - {warning}")
        if len(result.warnings) > 15:
            lines.append(f"--   ... and {len(result.warnings) - 15} more")

    lines.append("-- ============================================================")
    lines.append("")

    return '\n'.join(lines)


def convert_file(
    file_path: Path,
    converter: ReviewTeradataConverter,
    output_dir: Path,
    logger
) -> dict:
    """
    Convert a single Teradata SQL file using the review converter.
    """
    logger.info(f"Converting: {file_path.name}")

    result_meta = {
        'source_file': file_path.name,
        'status': 'unknown',
        'rules_applied': 0,
        'warnings': 0,
        'errors': [],
        'review_applied': False,
        'fixes_suggested': 0,
        'fixes_accepted': 0,
        'fixes_rejected': 0,
    }

    try:
        # Read source file
        source_sql = file_path.read_text(encoding='utf-8', errors='replace')

        if not source_sql.strip():
            logger.warning(f"  Skipping empty file: {file_path.name}")
            result_meta['status'] = 'skipped'
            result_meta['errors'] = ['File is empty']
            return result_meta

        # Convert using review converter
        result = converter.convert(source_sql)

        timestamp = get_iso_timestamp()

        # Build header
        header = build_header_comment(
            source_file=file_path.name,
            result=result,
            timestamp=timestamp,
        )

        # Combine header and converted SQL
        output_sql = header + result.converted

        # Determine output filename
        output_name = file_path.stem + '.sql'
        output_path = output_dir / output_name

        # Write output
        output_dir.mkdir(parents=True, exist_ok=True)
        output_path.write_text(output_sql, encoding='utf-8')

        result_meta['status'] = 'success' if result.success else 'partial'
        result_meta['output_file'] = output_name
        result_meta['rules_applied'] = len(result.rules_applied)
        result_meta['warnings'] = len(result.warnings)
        result_meta['errors'] = result.errors
        result_meta['review_applied'] = result.review_applied
        result_meta['fixes_suggested'] = result.fixes_suggested
        result_meta['fixes_accepted'] = result.fixes_accepted
        result_meta['fixes_rejected'] = result.fixes_rejected

        review_info = ""
        if result.review_applied:
            review_info = (
                f", LLM review: {result.fixes_accepted} accepted/"
                f"{result.fixes_rejected} rejected"
            )

        logger.info(
            f"  -> {output_name} "
            f"({len(result.rules_applied)} rules, "
            f"{len(result.warnings)} warnings{review_info})"
        )

    except Exception as e:
        result_meta['status'] = 'failed'
        result_meta['errors'] = [str(e)]
        logger.error(f"  FAILED: {file_path.name}: {e}")

    return result_meta


def main():
    """
    Convert all SQL files from knowledgebase/ to output/ using review converter.
    """
    logger = setup_logging('convert_sql', log_dir=PROJECT_ROOT / 'thoughts' / 'logs')
    logger.info("=" * 60)
    logger.info("Phase 2: Convert SQL (Rules + LLM Review)")
    logger.info("=" * 60)

    input_dir = PROJECT_ROOT / 'inputs'
    output_dir = PROJECT_ROOT / 'output'
    config_path = PROJECT_ROOT / 'config' / 'converter_config.json'

    # Load config
    config = load_json(config_path)
    if not config:
        logger.warning("No converter config found. Using defaults.")
        config = {}

    # Log review settings
    review_config = config.get('llm_review', {})
    review_enabled = review_config.get('enabled', True)
    logger.info(f"Config loaded: {len(config)} settings")
    logger.info(f"LLM review: {'enabled' if review_enabled else 'disabled'}")

    # Initialize review converter
    converter = ReviewTeradataConverter(config=config, logger=logger)

    # Check LLM availability
    if review_enabled:
        if converter.llm_reviewer.is_available():
            logger.info("LLM reviewer: available")
        else:
            logger.warning(
                "LLM reviewer: NOT available. "
                "Set ANTHROPIC_FOUNDRY_API_KEY in .env file. "
                "Conversion will proceed with rules only."
            )

    # Collect source files (recursive to include subdirectories)
    source_files = []
    extensions = config.get('file_extensions', FILE_EXTENSIONS)
    for ext in extensions:
        source_files.extend(sorted(input_dir.rglob(f'*{ext}')))

    if not source_files:
        logger.warning(f"No source files found in {input_dir}")
        return

    logger.info(f"Found {len(source_files)} file(s) to convert")
    logger.info("")

    # Convert each file
    results = []
    for source_file in source_files:
        try:
            result = convert_file(source_file, converter, output_dir, logger)
            results.append(result)
        except Exception as e:
            logger.error(f"Unexpected error converting {source_file.name}: {e}")
            results.append({
                'source_file': source_file.name,
                'status': 'failed',
                'errors': [str(e)],
            })

    # Summary
    logger.info("")
    logger.info("=" * 60)
    logger.info("Conversion Summary")
    logger.info("=" * 60)

    total = len(results)
    succeeded = sum(1 for r in results if r['status'] == 'success')
    partial = sum(1 for r in results if r['status'] == 'partial')
    failed = sum(1 for r in results if r['status'] == 'failed')
    skipped = sum(1 for r in results if r['status'] == 'skipped')
    total_rules = sum(r.get('rules_applied', 0) for r in results)
    total_reviewed = sum(1 for r in results if r.get('review_applied'))
    total_fixes_accepted = sum(r.get('fixes_accepted', 0) for r in results)
    total_fixes_rejected = sum(r.get('fixes_rejected', 0) for r in results)

    logger.info(f"Total files:         {total}")
    logger.info(f"Succeeded:           {succeeded}")
    logger.info(f"Partial:             {partial}")
    logger.info(f"Failed:              {failed}")
    logger.info(f"Skipped:             {skipped}")
    logger.info(f"Total rules applied: {total_rules}")
    logger.info(f"Files LLM-reviewed:  {total_reviewed}")
    logger.info(f"LLM fixes accepted:  {total_fixes_accepted}")
    logger.info(f"LLM fixes rejected:  {total_fixes_rejected}")
    logger.info("=" * 60)


if __name__ == '__main__':
    main()
