"""
Conversion Validator
====================

Validates converted Snowflake SQL for proper conversion.
"""

import re
from dataclasses import dataclass, field
from typing import List, Dict, Optional, Tuple
from pathlib import Path
from datetime import datetime

from .rules import (
    ValidationRule,
    ValidationCategory,
    Severity,
    get_all_validation_rules,
    get_rules_by_category,
    get_rules_by_severity,
)


@dataclass
class ValidationIssue:
    """Represents a single validation issue found."""
    rule_name: str
    category: ValidationCategory
    severity: Severity
    message: str
    description: str
    suggestion: Optional[str]
    line_number: int
    column: int
    matched_text: str
    line_content: str


@dataclass
class ValidationResult:
    """Result of validating a converted SQL file."""
    file_path: Optional[str] = None
    is_valid: bool = True
    total_issues: int = 0
    errors: int = 0
    warnings: int = 0
    info: int = 0
    issues: List[ValidationIssue] = field(default_factory=list)
    issues_by_category: Dict[str, List[ValidationIssue]] = field(default_factory=dict)
    issues_by_severity: Dict[str, List[ValidationIssue]] = field(default_factory=dict)
    validation_time: float = 0.0
    lines_checked: int = 0

    @property
    def score(self) -> float:
        """Conversion accuracy score as percentage (0-100).
        Based on error density relative to lines checked.
        0 errors = 100%, more errors = lower score.
        """
        if self.lines_checked == 0:
            return 0.0
        return round(max(0.0, (1 - self.errors / self.lines_checked) * 100), 1)

    def add_issue(self, issue: ValidationIssue):
        """Add an issue to the result."""
        self.issues.append(issue)
        self.total_issues += 1

        # Count by severity
        if issue.severity == Severity.ERROR:
            self.errors += 1
            self.is_valid = False
        elif issue.severity == Severity.WARNING:
            self.warnings += 1
        else:
            self.info += 1

        # Group by category
        cat_name = issue.category.value
        if cat_name not in self.issues_by_category:
            self.issues_by_category[cat_name] = []
        self.issues_by_category[cat_name].append(issue)

        # Group by severity
        sev_name = issue.severity.value
        if sev_name not in self.issues_by_severity:
            self.issues_by_severity[sev_name] = []
        self.issues_by_severity[sev_name].append(issue)

    def get_summary(self) -> str:
        """Get a summary of validation results."""
        lines = [
            f"Validation Score: {self.score}%",
            f"  Total Issues: {self.total_issues}",
            f"  Errors:       {self.errors}",
            f"  Warnings:     {self.warnings}",
            f"  Info:         {self.info}",
        ]
        return "\n".join(lines)


class ConversionValidator:
    """
    Validates converted Snowflake SQL files.

    Checks for:
    - Unconverted Teradata syntax
    - Potential syntax errors
    - Incomplete conversions
    - Best practice violations
    """

    def __init__(self, config: Optional[Dict] = None):
        """
        Initialize the validator.

        Args:
            config: Optional configuration dict with:
                - ignore_rules: List of rule names to skip
                - ignore_categories: List of categories to skip
                - ignore_severities: List of severities to skip
                - min_severity: Minimum severity to report ('error', 'warning', 'info')
        """
        self.config = config or {}
        self.rules = get_all_validation_rules()
        self._apply_config()

    def _apply_config(self):
        """Apply configuration to filter rules."""
        ignore_rules = set(self.config.get('ignore_rules', []))
        ignore_categories = set(self.config.get('ignore_categories', []))
        ignore_severities = set(self.config.get('ignore_severities', []))
        min_severity = self.config.get('min_severity', 'info')

        severity_levels = {'error': 3, 'warning': 2, 'info': 1}
        min_level = severity_levels.get(min_severity.lower(), 1)

        filtered_rules = []
        for rule in self.rules:
            # Skip by name
            if rule.name in ignore_rules:
                continue
            # Skip by category
            if rule.category.value in ignore_categories:
                continue
            # Skip by severity
            if rule.severity.value in ignore_severities:
                continue
            # Skip below minimum severity
            if severity_levels.get(rule.severity.value, 1) < min_level:
                continue
            filtered_rules.append(rule)

        self.rules = filtered_rules

    def validate(self, sql: str, file_path: Optional[str] = None) -> ValidationResult:
        """
        Validate converted SQL.

        Args:
            sql: The converted Snowflake SQL to validate
            file_path: Optional path to the file being validated

        Returns:
            ValidationResult with all issues found
        """
        import time
        start_time = time.time()

        result = ValidationResult(file_path=file_path)
        result.lines_checked = len(sql.split('\n'))

        # Run each rule
        for rule in self.rules:
            matches = rule.check(sql)
            for match in matches:
                issue = ValidationIssue(
                    rule_name=rule.name,
                    category=rule.category,
                    severity=rule.severity,
                    message=rule.message,
                    description=rule.description,
                    suggestion=rule.suggestion,
                    line_number=match['line'],
                    column=match['column'],
                    matched_text=match['matched_text'],
                    line_content=match['line_content']
                )
                result.add_issue(issue)

        result.validation_time = time.time() - start_time
        return result

    def validate_file(self, file_path: str) -> ValidationResult:
        """
        Validate a converted SQL file.

        Args:
            file_path: Path to the SQL file

        Returns:
            ValidationResult
        """
        path = Path(file_path)
        if not path.exists():
            result = ValidationResult(file_path=file_path, is_valid=False)
            result.issues.append(ValidationIssue(
                rule_name='file_not_found',
                category=ValidationCategory.SYNTAX_ERROR,
                severity=Severity.ERROR,
                message=f'File not found: {file_path}',
                description='The specified file does not exist',
                suggestion='Check the file path',
                line_number=0,
                column=0,
                matched_text='',
                line_content=''
            ))
            return result

        sql = path.read_text(encoding='utf-8')
        return self.validate(sql, file_path=file_path)

    def validate_folder(self, folder_path: str,
                       extensions: List[str] = None) -> Dict[str, ValidationResult]:
        """
        Validate all SQL files in a folder.

        Args:
            folder_path: Path to the folder
            extensions: File extensions to check (default: ['.sql'])

        Returns:
            Dict mapping file paths to ValidationResults
        """
        extensions = extensions or ['.sql']
        folder = Path(folder_path)
        results = {}

        for ext in extensions:
            for file_path in folder.rglob(f'*{ext}'):
                results[str(file_path)] = self.validate_file(str(file_path))

        return results

    def generate_report(self, result: ValidationResult,
                       format: str = 'text') -> str:
        """
        Generate a validation report.

        Args:
            result: ValidationResult to report on
            format: Output format ('text', 'json', 'html')

        Returns:
            Formatted report string
        """
        if format == 'json':
            return self._generate_json_report(result)
        elif format == 'html':
            return self._generate_html_report(result)
        else:
            return self._generate_text_report(result)

    def _generate_text_report(self, result: ValidationResult) -> str:
        """Generate a text report."""
        lines = [
            "=" * 70,
            "CONVERSION VALIDATION REPORT",
            "=" * 70,
            f"File: {result.file_path or 'N/A'}",
            f"Time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}",
            f"Lines Checked: {result.lines_checked}",
            f"Validation Time: {result.validation_time:.3f}s",
            "",
            result.get_summary(),
            ""
        ]

        if result.total_issues > 0:
            lines.append("-" * 70)
            lines.append("ISSUES FOUND")
            lines.append("-" * 70)

            # Group by severity for display
            for severity in [Severity.ERROR, Severity.WARNING, Severity.INFO]:
                sev_issues = [i for i in result.issues if i.severity == severity]
                if sev_issues:
                    lines.append(f"\n[{severity.value.upper()}S]")
                    for issue in sev_issues:
                        lines.append(f"\n  Line {issue.line_number}: {issue.message}")
                        lines.append(f"    Rule: {issue.rule_name}")
                        lines.append(f"    Found: {issue.matched_text}")
                        lines.append(f"    Context: {issue.line_content[:60]}...")
                        if issue.suggestion:
                            lines.append(f"    Suggestion: {issue.suggestion}")

        lines.append("")
        lines.append("=" * 70)

        return "\n".join(lines)

    def _generate_json_report(self, result: ValidationResult) -> str:
        """Generate a JSON report."""
        import json

        report = {
            'file_path': result.file_path,
            'timestamp': datetime.now().isoformat(),
            'is_valid': result.is_valid,
            'summary': {
                'total_issues': result.total_issues,
                'errors': result.errors,
                'warnings': result.warnings,
                'info': result.info,
                'lines_checked': result.lines_checked,
                'validation_time_seconds': result.validation_time
            },
            'issues': [
                {
                    'rule_name': i.rule_name,
                    'category': i.category.value,
                    'severity': i.severity.value,
                    'message': i.message,
                    'description': i.description,
                    'suggestion': i.suggestion,
                    'line_number': i.line_number,
                    'column': i.column,
                    'matched_text': i.matched_text,
                    'line_content': i.line_content
                }
                for i in result.issues
            ]
        }

        return json.dumps(report, indent=2)

    def _generate_html_report(self, result: ValidationResult) -> str:
        """Generate an HTML report."""
        severity_colors = {
            'error': '#dc3545',
            'warning': '#ffc107',
            'info': '#17a2b8'
        }

        issues_html = ""
        for issue in result.issues:
            color = severity_colors.get(issue.severity.value, '#6c757d')
            issues_html += f"""
            <tr>
                <td>{issue.line_number}</td>
                <td><span style="color: {color}; font-weight: bold;">{issue.severity.value.upper()}</span></td>
                <td>{issue.message}</td>
                <td><code>{issue.matched_text}</code></td>
                <td>{issue.suggestion or '-'}</td>
            </tr>
            """

        status_color = '#28a745' if result.is_valid else '#dc3545'
        status_text = 'PASSED' if result.is_valid else 'FAILED'

        html = f"""
<!DOCTYPE html>
<html>
<head>
    <title>Conversion Validation Report</title>
    <style>
        body {{ font-family: Arial, sans-serif; margin: 20px; }}
        h1 {{ color: #333; }}
        .summary {{ background: #f8f9fa; padding: 15px; border-radius: 5px; margin: 20px 0; }}
        .status {{ font-size: 24px; color: {status_color}; font-weight: bold; }}
        table {{ border-collapse: collapse; width: 100%; margin-top: 20px; }}
        th, td {{ border: 1px solid #ddd; padding: 8px; text-align: left; }}
        th {{ background-color: #333; color: white; }}
        tr:nth-child(even) {{ background-color: #f2f2f2; }}
        code {{ background: #e9ecef; padding: 2px 5px; border-radius: 3px; }}
    </style>
</head>
<body>
    <h1>Conversion Validation Report</h1>

    <div class="summary">
        <p><strong>File:</strong> {result.file_path or 'N/A'}</p>
        <p><strong>Generated:</strong> {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}</p>
        <p class="status">Status: {status_text}</p>
        <p><strong>Summary:</strong> {result.errors} errors, {result.warnings} warnings, {result.info} info</p>
        <p><strong>Lines Checked:</strong> {result.lines_checked}</p>
    </div>

    <h2>Issues ({result.total_issues})</h2>
    <table>
        <tr>
            <th>Line</th>
            <th>Severity</th>
            <th>Message</th>
            <th>Found</th>
            <th>Suggestion</th>
        </tr>
        {issues_html if issues_html else '<tr><td colspan="5">No issues found</td></tr>'}
    </table>
</body>
</html>
        """

        return html


def validate_conversion(sql: str, config: Optional[Dict] = None) -> ValidationResult:
    """
    Convenience function to validate converted SQL.

    Args:
        sql: The converted Snowflake SQL
        config: Optional configuration

    Returns:
        ValidationResult
    """
    validator = ConversionValidator(config=config)
    return validator.validate(sql)
