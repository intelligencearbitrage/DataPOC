"""
Source-Target Comparator
========================

Compares original Teradata SQL with converted Snowflake SQL
to ensure completeness and correctness of conversion.
"""

import re
from dataclasses import dataclass, field
from typing import List, Dict, Set, Optional, Tuple
from pathlib import Path


@dataclass
class ComparisonMetric:
    """A single comparison metric."""
    name: str
    source_count: int
    target_count: int
    difference: int
    status: str  # 'match', 'converted', 'missing', 'extra'
    details: List[str] = field(default_factory=list)


@dataclass
class ComparisonResult:
    """Result of comparing source and target SQL."""
    source_file: Optional[str] = None
    target_file: Optional[str] = None
    is_complete: bool = True
    metrics: List[ComparisonMetric] = field(default_factory=list)
    missing_elements: List[str] = field(default_factory=list)
    extra_elements: List[str] = field(default_factory=list)
    conversion_notes: List[str] = field(default_factory=list)

    def get_summary(self) -> str:
        """Get a summary of the comparison."""
        status = "✓ COMPLETE" if self.is_complete else "⚠ INCOMPLETE"
        lines = [
            f"Comparison {status}",
            f"Missing elements: {len(self.missing_elements)}",
            f"Extra elements: {len(self.extra_elements)}",
        ]
        return "\n".join(lines)


class SourceTargetComparator:
    """
    Compares Teradata source with Snowflake target to ensure
    all elements were properly converted.
    """

    def __init__(self, config: Optional[Dict] = None):
        """Initialize the comparator."""
        self.config = config or {}

    def compare(self, source_sql: str, target_sql: str,
                source_file: str = None, target_file: str = None) -> ComparisonResult:
        """
        Compare source Teradata SQL with target Snowflake SQL.

        Args:
            source_sql: Original Teradata SQL
            target_sql: Converted Snowflake SQL
            source_file: Optional source file path
            target_file: Optional target file path

        Returns:
            ComparisonResult with metrics and issues
        """
        result = ComparisonResult(
            source_file=source_file,
            target_file=target_file
        )

        # Run all comparison checks
        self._compare_tables(source_sql, target_sql, result)
        self._compare_procedures(source_sql, target_sql, result)
        self._compare_columns(source_sql, target_sql, result)
        self._compare_joins(source_sql, target_sql, result)
        self._compare_functions(source_sql, target_sql, result)
        self._compare_dml(source_sql, target_sql, result)
        self._compare_variables(source_sql, target_sql, result)
        self._compare_qualify(source_sql, target_sql, result)
        self._check_conversion_patterns(source_sql, target_sql, result)

        # Determine overall completeness
        result.is_complete = len(result.missing_elements) == 0

        return result

    def compare_files(self, source_path: str, target_path: str) -> ComparisonResult:
        """
        Compare source and target SQL files.

        Args:
            source_path: Path to Teradata SQL file
            target_path: Path to Snowflake SQL file

        Returns:
            ComparisonResult
        """
        source_sql = Path(source_path).read_text(encoding='utf-8')
        target_sql = Path(target_path).read_text(encoding='utf-8')
        return self.compare(source_sql, target_sql, source_path, target_path)

    def _extract_identifiers(self, sql: str, pattern: str) -> Set[str]:
        """Extract identifiers matching a pattern."""
        matches = re.findall(pattern, sql, re.IGNORECASE)
        return set(m.upper() if isinstance(m, str) else m[0].upper() for m in matches)

    def _compare_tables(self, source: str, target: str, result: ComparisonResult):
        """Compare table references."""
        # Extract table names from CREATE TABLE statements
        create_pattern = r'CREATE\s+(?:MULTISET\s+)?(?:VOLATILE\s+)?(?:TEMPORARY\s+)?TABLE\s+(\w+)'
        source_tables = self._extract_identifiers(source, create_pattern)
        target_tables = self._extract_identifiers(target, create_pattern)

        # Check for volatile -> temporary conversion
        volatile_pattern = r'VOLATILE\s+TABLE\s+(\w+)'
        temp_pattern = r'TEMPORARY\s+TABLE\s+(\w+)'
        source_volatile = self._extract_identifiers(source, volatile_pattern)
        target_temp = self._extract_identifiers(target, temp_pattern)

        # Tables should match
        missing = source_tables - target_tables
        extra = target_tables - source_tables

        metric = ComparisonMetric(
            name='Tables',
            source_count=len(source_tables),
            target_count=len(target_tables),
            difference=len(missing) + len(extra),
            status='match' if not missing and not extra else 'mismatch'
        )

        if missing:
            metric.details.append(f"Missing tables: {', '.join(missing)}")
            result.missing_elements.extend([f"Table: {t}" for t in missing])

        result.metrics.append(metric)

        # Check volatile conversion
        if source_volatile:
            converted = source_volatile & target_temp
            not_converted = source_volatile - target_temp
            if converted:
                result.conversion_notes.append(
                    f"✓ Volatile tables converted to temporary: {', '.join(converted)}"
                )
            if not_converted:
                result.missing_elements.extend(
                    [f"Volatile table not converted: {t}" for t in not_converted]
                )

    def _compare_procedures(self, source: str, target: str, result: ComparisonResult):
        """Compare procedure definitions."""
        # Source: REPLACE PROCEDURE
        source_pattern = r'(?:REPLACE|CREATE)\s+PROCEDURE\s+([\w.]+)'
        target_pattern = r'CREATE\s+(?:OR\s+REPLACE\s+)?PROCEDURE\s+([\w.]+)'

        source_procs = self._extract_identifiers(source, source_pattern)
        target_procs = self._extract_identifiers(target, target_pattern)

        # Extract just procedure names (without schema)
        source_names = {p.split('.')[-1] for p in source_procs}
        target_names = {p.split('.')[-1] for p in target_procs}

        missing = source_names - target_names

        metric = ComparisonMetric(
            name='Procedures',
            source_count=len(source_names),
            target_count=len(target_names),
            difference=len(missing),
            status='match' if not missing else 'missing'
        )

        if missing:
            metric.details.append(f"Missing procedures: {', '.join(missing)}")
            result.missing_elements.extend([f"Procedure: {p}" for p in missing])

        result.metrics.append(metric)

    def _compare_columns(self, source: str, target: str, result: ComparisonResult):
        """Compare column references in SELECT statements."""
        # This is a simplified check - just count SELECT columns
        select_pattern = r'SELECT\s+(.*?)\s+FROM'

        source_selects = re.findall(select_pattern, source, re.IGNORECASE | re.DOTALL)
        target_selects = re.findall(select_pattern, target, re.IGNORECASE | re.DOTALL)

        metric = ComparisonMetric(
            name='SELECT statements',
            source_count=len(source_selects),
            target_count=len(target_selects),
            difference=abs(len(source_selects) - len(target_selects)),
            status='match' if len(source_selects) == len(target_selects) else 'mismatch'
        )
        result.metrics.append(metric)

    def _compare_joins(self, source: str, target: str, result: ComparisonResult):
        """Compare JOIN clauses."""
        join_pattern = r'\b(INNER|LEFT|RIGHT|FULL|CROSS)\s+(?:OUTER\s+)?JOIN\b'

        source_joins = re.findall(join_pattern, source, re.IGNORECASE)
        target_joins = re.findall(join_pattern, target, re.IGNORECASE)

        metric = ComparisonMetric(
            name='JOINs',
            source_count=len(source_joins),
            target_count=len(target_joins),
            difference=abs(len(source_joins) - len(target_joins)),
            status='match' if len(source_joins) == len(target_joins) else 'mismatch'
        )

        if metric.difference > 0:
            metric.details.append(f"Source has {len(source_joins)} joins, target has {len(target_joins)}")

        result.metrics.append(metric)

    def _compare_functions(self, source: str, target: str, result: ComparisonResult):
        """Compare function usage and conversions."""
        # Track Teradata functions and their Snowflake equivalents
        function_mappings = {
            'ADD_MONTHS': 'DATEADD',
            'OREPLACE': 'REPLACE',
            'OTRANSLATE': 'TRANSLATE',
            'CHARACTERS': 'LENGTH',
            'NULLIFZERO': 'NULLIF',
            'ZEROIFNULL': 'COALESCE',
        }

        conversions = []
        missing_conversions = []

        for td_func, sf_func in function_mappings.items():
            source_count = len(re.findall(rf'\b{td_func}\s*\(', source, re.IGNORECASE))
            target_td_count = len(re.findall(rf'\b{td_func}\s*\(', target, re.IGNORECASE))
            target_sf_count = len(re.findall(rf'\b{sf_func}\s*\(', target, re.IGNORECASE))

            if source_count > 0:
                if target_td_count > 0:
                    missing_conversions.append(f"{td_func} ({target_td_count} remaining)")
                    result.missing_elements.append(f"Function not converted: {td_func}")
                elif target_sf_count >= source_count:
                    conversions.append(f"{td_func} → {sf_func} ({source_count})")

        metric = ComparisonMetric(
            name='Function conversions',
            source_count=len([m for m in function_mappings if re.search(rf'\b{m}\s*\(', source, re.IGNORECASE)]),
            target_count=len(conversions),
            difference=len(missing_conversions),
            status='converted' if not missing_conversions else 'incomplete'
        )

        metric.details.extend(conversions)
        if missing_conversions:
            metric.details.append(f"Not converted: {', '.join(missing_conversions)}")

        result.metrics.append(metric)

        if conversions:
            result.conversion_notes.append(f"✓ Functions converted: {', '.join(conversions)}")

    def _compare_dml(self, source: str, target: str, result: ComparisonResult):
        """Compare DML statements."""
        dml_types = ['INSERT', 'UPDATE', 'DELETE', 'MERGE']

        for dml in dml_types:
            source_count = len(re.findall(rf'\b{dml}\b', source, re.IGNORECASE))
            target_count = len(re.findall(rf'\b{dml}\b', target, re.IGNORECASE))

            # UPDATE FROM should become MERGE
            if dml == 'UPDATE':
                source_update_from = len(re.findall(r'\bUPDATE\s+\w+\s+FROM\b', source, re.IGNORECASE))
                target_merge = len(re.findall(r'\bMERGE\b', target, re.IGNORECASE))
                if source_update_from > 0:
                    result.conversion_notes.append(
                        f"✓ UPDATE FROM statements ({source_update_from}) → MERGE ({target_merge})"
                    )

            metric = ComparisonMetric(
                name=f'{dml} statements',
                source_count=source_count,
                target_count=target_count,
                difference=abs(source_count - target_count),
                status='match' if source_count <= target_count else 'check'
            )
            result.metrics.append(metric)

    def _compare_variables(self, source: str, target: str, result: ComparisonResult):
        """Compare variable declarations."""
        # Source: DECLARE var TYPE
        source_pattern = r'DECLARE\s+(\w+)'
        target_pattern = r'(?:DECLARE|LET)\s+(\w+)'

        source_vars = self._extract_identifiers(source, source_pattern)
        target_vars = self._extract_identifiers(target, target_pattern)

        missing = source_vars - target_vars

        metric = ComparisonMetric(
            name='Variables',
            source_count=len(source_vars),
            target_count=len(target_vars),
            difference=len(missing),
            status='match' if not missing else 'missing'
        )

        if missing:
            metric.details.append(f"Missing variables: {', '.join(missing)}")

        result.metrics.append(metric)

    def _compare_qualify(self, source: str, target: str, result: ComparisonResult):
        """Compare QUALIFY clauses."""
        source_qualify = len(re.findall(r'\bQUALIFY\b', source, re.IGNORECASE))
        target_qualify = len(re.findall(r'\bQUALIFY\b', target, re.IGNORECASE))

        metric = ComparisonMetric(
            name='QUALIFY clauses',
            source_count=source_qualify,
            target_count=target_qualify,
            difference=abs(source_qualify - target_qualify),
            status='match' if source_qualify == target_qualify else 'check'
        )

        if source_qualify == target_qualify and source_qualify > 0:
            result.conversion_notes.append(
                f"✓ QUALIFY clauses preserved ({source_qualify} - Snowflake native support)"
            )

        result.metrics.append(metric)

    def _check_conversion_patterns(self, source: str, target: str, result: ComparisonResult):
        """Check specific conversion patterns."""
        # Check EXIT HANDLER → EXCEPTION
        source_handlers = len(re.findall(r'\bEXIT\s+HANDLER\b', source, re.IGNORECASE))
        target_exceptions = len(re.findall(r'\bEXCEPTION\b', target, re.IGNORECASE))

        if source_handlers > 0:
            if target_exceptions > 0:
                result.conversion_notes.append(
                    f"✓ EXIT HANDLER converted to EXCEPTION block"
                )
            else:
                result.missing_elements.append("Exception handler not converted")

        # Check RESIGNAL → RAISE
        source_resignal = len(re.findall(r'\bRESIGNAL\b', source, re.IGNORECASE))
        target_raise = len(re.findall(r'\bRAISE\b', target, re.IGNORECASE))

        if source_resignal > 0 and target_raise > 0:
            result.conversion_notes.append(f"✓ RESIGNAL converted to RAISE")

        # Check PRIMARY INDEX removed
        source_primary_index = len(re.findall(r'\bPRIMARY\s+INDEX\b', source, re.IGNORECASE))
        target_primary_index = len(re.findall(r'\bPRIMARY\s+INDEX\b', target, re.IGNORECASE))

        if source_primary_index > 0 and target_primary_index == 0:
            result.conversion_notes.append(
                f"✓ PRIMARY INDEX clauses removed ({source_primary_index})"
            )
        elif target_primary_index > 0:
            result.missing_elements.append(
                f"PRIMARY INDEX not fully removed ({target_primary_index} remaining)"
            )

    def generate_report(self, result: ComparisonResult, format: str = 'text') -> str:
        """
        Generate a comparison report.

        Args:
            result: ComparisonResult to report
            format: Output format ('text', 'json')

        Returns:
            Formatted report string
        """
        if format == 'json':
            return self._generate_json_report(result)
        return self._generate_text_report(result)

    def _generate_text_report(self, result: ComparisonResult) -> str:
        """Generate text report."""
        lines = [
            "=" * 70,
            "SOURCE-TARGET COMPARISON REPORT",
            "=" * 70,
            f"Source: {result.source_file or 'N/A'}",
            f"Target: {result.target_file or 'N/A'}",
            "",
            result.get_summary(),
            "",
            "-" * 70,
            "METRICS",
            "-" * 70,
        ]

        for metric in result.metrics:
            status_icon = "✓" if metric.status in ['match', 'converted'] else "⚠"
            lines.append(f"\n{status_icon} {metric.name}:")
            lines.append(f"   Source: {metric.source_count}, Target: {metric.target_count}")
            if metric.details:
                for detail in metric.details:
                    lines.append(f"   - {detail}")

        if result.conversion_notes:
            lines.append("")
            lines.append("-" * 70)
            lines.append("CONVERSION NOTES")
            lines.append("-" * 70)
            for note in result.conversion_notes:
                lines.append(f"  {note}")

        if result.missing_elements:
            lines.append("")
            lines.append("-" * 70)
            lines.append("MISSING/INCOMPLETE ELEMENTS")
            lines.append("-" * 70)
            for elem in result.missing_elements:
                lines.append(f"  ⚠ {elem}")

        lines.append("")
        lines.append("=" * 70)

        return "\n".join(lines)

    def _generate_json_report(self, result: ComparisonResult) -> str:
        """Generate JSON report."""
        import json
        from datetime import datetime

        report = {
            'source_file': result.source_file,
            'target_file': result.target_file,
            'timestamp': datetime.now().isoformat(),
            'is_complete': result.is_complete,
            'metrics': [
                {
                    'name': m.name,
                    'source_count': m.source_count,
                    'target_count': m.target_count,
                    'difference': m.difference,
                    'status': m.status,
                    'details': m.details
                }
                for m in result.metrics
            ],
            'conversion_notes': result.conversion_notes,
            'missing_elements': result.missing_elements,
            'extra_elements': result.extra_elements
        }

        return json.dumps(report, indent=2)
