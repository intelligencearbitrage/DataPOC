"""
Teradata to Snowflake Conversion Validator
==========================================

Validates converted SQL files to ensure proper conversion.
"""

from .rules import ValidationRule, ValidationCategory, get_all_validation_rules
from .validator import ConversionValidator, ValidationResult, ValidationIssue
from .comparator import SourceTargetComparator, ComparisonResult

__all__ = [
    'ValidationRule',
    'ValidationCategory',
    'get_all_validation_rules',
    'ConversionValidator',
    'ValidationResult',
    'ValidationIssue',
    'SourceTargetComparator',
    'ComparisonResult',
]
