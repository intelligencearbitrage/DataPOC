"""
Validation Rules for Teradata to Snowflake Conversion
=====================================================

Defines rules to validate that SQL was properly converted.
"""

import re
from dataclasses import dataclass
from enum import Enum
from typing import List, Optional, Callable


class ValidationCategory(Enum):
    """Categories of validation checks."""
    UNCONVERTED = "unconverted"      # Teradata syntax that wasn't converted
    SYNTAX_ERROR = "syntax_error"    # Potential syntax errors
    INCOMPLETE = "incomplete"         # Incomplete conversions
    WARNING = "warning"               # Non-critical issues
    BEST_PRACTICE = "best_practice"  # Snowflake best practices


class Severity(Enum):
    """Severity levels for validation issues."""
    ERROR = "error"
    WARNING = "warning"
    INFO = "info"


@dataclass
class ValidationRule:
    """A validation rule to check converted SQL."""
    name: str
    category: ValidationCategory
    severity: Severity
    pattern: str
    message: str
    description: str
    suggestion: Optional[str] = None

    def check(self, sql: str) -> List[dict]:
        """
        Check SQL for this rule violation.
        Returns list of matches with line numbers.
        Skips lines that are SQL comments (-- or /* ... */) to avoid false positives.
        """
        issues = []
        lines = sql.split('\n')
        regex = re.compile(self.pattern, re.IGNORECASE | re.MULTILINE)
        in_block_comment = False

        for i, line in enumerate(lines, 1):
            stripped = line.strip()

            # Track block comments
            if in_block_comment:
                if '*/' in stripped:
                    in_block_comment = False
                continue
            if stripped.startswith('/*'):
                if '*/' not in stripped:
                    in_block_comment = True
                continue

            # Skip single-line comments
            if stripped.startswith('--'):
                continue

            # Strip trailing inline comments before checking
            # But preserve the original line for context
            code_part = re.sub(r'--.*$', '', line)

            for match in regex.finditer(code_part):
                issues.append({
                    'line': i,
                    'column': match.start() + 1,
                    'matched_text': match.group(0),
                    'line_content': line.strip()
                })

        return issues


# =============================================================================
# UNCONVERTED TERADATA SYNTAX
# =============================================================================

UNCONVERTED_RULES = [
    ValidationRule(
        name='volatile_table_remaining',
        category=ValidationCategory.UNCONVERTED,
        severity=Severity.ERROR,
        pattern=r'\bVOLATILE\s+TABLE\b',
        message='VOLATILE TABLE not converted to TEMPORARY TABLE',
        description='Teradata VOLATILE TABLE should be TEMPORARY TABLE in Snowflake',
        suggestion='Change to CREATE TEMPORARY TABLE'
    ),
    ValidationRule(
        name='multiset_remaining',
        category=ValidationCategory.UNCONVERTED,
        severity=Severity.ERROR,
        pattern=r'\bMULTISET\s+(?:VOLATILE\s+)?TABLE\b',
        message='MULTISET keyword not removed',
        description='Snowflake does not use MULTISET keyword',
        suggestion='Remove MULTISET keyword'
    ),
    ValidationRule(
        name='add_months_remaining',
        category=ValidationCategory.UNCONVERTED,
        severity=Severity.ERROR,
        pattern=r'\bADD_MONTHS\s*\(',
        message='ADD_MONTHS function not converted',
        description='Should be converted to DATEADD(MONTH, n, date)',
        suggestion='Use DATEADD(MONTH, n, date) instead'
    ),
    ValidationRule(
        name='primary_index_remaining',
        category=ValidationCategory.UNCONVERTED,
        severity=Severity.ERROR,
        pattern=r'\bPRIMARY\s+INDEX\b',
        message='PRIMARY INDEX not removed',
        description='Snowflake does not support PRIMARY INDEX',
        suggestion='Remove PRIMARY INDEX clause'
    ),
    ValidationRule(
        name='on_commit_remaining',
        category=ValidationCategory.UNCONVERTED,
        severity=Severity.ERROR,
        pattern=r'\bON\s+COMMIT\s+PRESERVE\s+ROWS\b',
        message='ON COMMIT PRESERVE ROWS not removed',
        description='Snowflake temporary tables preserve rows by default',
        suggestion='Remove ON COMMIT PRESERVE ROWS clause'
    ),
    ValidationRule(
        name='with_data_remaining',
        category=ValidationCategory.UNCONVERTED,
        severity=Severity.ERROR,
        pattern=r'\bWITH\s+DATA\b(?!\s+AS)',
        message='WITH DATA clause not removed',
        description='Snowflake does not use WITH DATA syntax for CTAS',
        suggestion='Remove WITH DATA clause'
    ),
    ValidationRule(
        name='replace_procedure_remaining',
        category=ValidationCategory.UNCONVERTED,
        severity=Severity.ERROR,
        pattern=r'(?<!\bOR\s)\bREPLACE\s+PROCEDURE\b',
        message='REPLACE PROCEDURE not converted',
        description='Should be CREATE OR REPLACE PROCEDURE',
        suggestion='Use CREATE OR REPLACE PROCEDURE'
    ),
    ValidationRule(
        name='oreplace_remaining',
        category=ValidationCategory.UNCONVERTED,
        severity=Severity.ERROR,
        pattern=r'\bOREPLACE\s*\(',
        message='OREPLACE function not converted',
        description='Should be REPLACE() in Snowflake',
        suggestion='Use REPLACE() function'
    ),
    ValidationRule(
        name='otranslate_remaining',
        category=ValidationCategory.UNCONVERTED,
        severity=Severity.ERROR,
        pattern=r'\bOTRANSLATE\s*\(',
        message='OTRANSLATE function not converted',
        description='Should be TRANSLATE() in Snowflake',
        suggestion='Use TRANSLATE() function'
    ),
    ValidationRule(
        name='characters_remaining',
        category=ValidationCategory.UNCONVERTED,
        severity=Severity.ERROR,
        pattern=r'\bCHARACTERS\s*\(',
        message='CHARACTERS function not converted',
        description='Should be LENGTH() in Snowflake',
        suggestion='Use LENGTH() function'
    ),
    ValidationRule(
        name='translate_chk_remaining',
        category=ValidationCategory.UNCONVERTED,
        severity=Severity.ERROR,
        pattern=r'\bTRANSLATE_CHK\s*\(',
        message='TRANSLATE_CHK function not converted',
        description='Requires TRY_TO_NUMBER or REGEXP pattern',
        suggestion='Use TRY_TO_NUMBER() or REGEXP_LIKE() patterns'
    ),
    ValidationRule(
        name='sel_remaining',
        category=ValidationCategory.UNCONVERTED,
        severity=Severity.WARNING,
        pattern=r'(?<![A-Za-z_])\bSEL\s+(?!ECT)',
        message='SEL abbreviation not converted to SELECT',
        description='Teradata SEL shorthand should be SELECT',
        suggestion='Use full SELECT keyword'
    ),
    ValidationRule(
        name='activity_count_remaining',
        category=ValidationCategory.UNCONVERTED,
        severity=Severity.ERROR,
        pattern=r'\bACTIVITY_COUNT\b',
        message='ACTIVITY_COUNT not converted',
        description='Should be SQLROWCOUNT in Snowflake',
        suggestion='Use SQLROWCOUNT'
    ),
    ValidationRule(
        name='exit_handler_remaining',
        category=ValidationCategory.UNCONVERTED,
        severity=Severity.ERROR,
        pattern=r'\bEXIT\s+HANDLER\b',
        message='EXIT HANDLER not converted',
        description='Should be EXCEPTION block in Snowflake',
        suggestion='Use EXCEPTION WHEN OTHER THEN block'
    ),
    ValidationRule(
        name='resignal_remaining',
        category=ValidationCategory.UNCONVERTED,
        severity=Severity.ERROR,
        pattern=r'\bRESIGNAL\b',
        message='RESIGNAL not converted',
        description='Should be RAISE in Snowflake',
        suggestion='Use RAISE statement'
    ),
    ValidationRule(
        name='cast_format_remaining',
        category=ValidationCategory.UNCONVERTED,
        severity=Severity.ERROR,
        pattern=r'\bCAST\s*\([^)]+\s+FORMAT\s+',
        message='CAST with FORMAT not converted',
        description='Snowflake uses TO_CHAR/TO_DATE for formatting',
        suggestion='Use TO_CHAR() or TO_DATE() with format string'
    ),
    ValidationRule(
        name='if_exists_remaining',
        category=ValidationCategory.UNCONVERTED,
        severity=Severity.ERROR,
        pattern=r'\bIF\s+EXISTS\s*\(',
        message='IF EXISTS (subquery) not converted',
        description='Snowflake Scripting does not support IF EXISTS (SELECT ...)',
        suggestion='Use LET var := (SELECT COUNT(*) ...); IF (var > 0) THEN'
    ),
    ValidationRule(
        name='if_subquery_remaining',
        category=ValidationCategory.UNCONVERTED,
        severity=Severity.ERROR,
        pattern=r'\bIF\s*\(\s*SELECT\b',
        message='IF (SELECT ...) not converted',
        description='Snowflake Scripting does not support subqueries in IF conditions',
        suggestion='Use LET var := (subquery); IF (var ...) THEN'
    ),
    ValidationRule(
        name='select_into_no_from',
        category=ValidationCategory.SYNTAX_ERROR,
        severity=Severity.ERROR,
        pattern=r'\bSELECT\s+[^;]*\bINTO\s+\w+\s*;',
        message='SELECT ... INTO without FROM clause',
        description='SELECT INTO without FROM is invalid in Snowflake',
        suggestion='Use LET var := expr; instead'
    ),
    ValidationRule(
        name='insert_missing_values',
        category=ValidationCategory.SYNTAX_ERROR,
        severity=Severity.ERROR,
        pattern=r'\bINSERT\s+INTO\s+\w+\s*\(\s*\d',
        message='INSERT INTO without VALUES keyword',
        description='INSERT INTO table (values...) is missing VALUES keyword',
        suggestion='Add VALUES keyword: INSERT INTO table VALUES (...)'
    ),
    ValidationRule(
        name='interval_month_remaining',
        category=ValidationCategory.UNCONVERTED,
        severity=Severity.ERROR,
        pattern=r'\)\s*MONTH\s*\(\d+\)\s*\)',
        message='INTERVAL MONTH syntax not converted',
        description='Should use DATEDIFF for date differences',
        suggestion='Use DATEDIFF(MONTH, date1, date2)'
    ),
    ValidationRule(
        name='cast_varchar_fill_remaining',
        category=ValidationCategory.UNCONVERTED,
        severity=Severity.ERROR,
        pattern=r"\bCAST\s*\([^)]+AS\s+VARCHAR\s*\(\s*\d+\s*,\s*'[^']+'\s*\)",
        message="CAST(x AS VARCHAR(n, 'fill')) not converted",
        description="Snowflake does not support fill char in VARCHAR cast",
        suggestion="Use LPAD(x::VARCHAR(n), n, 'fill') instead"
    ),
    ValidationRule(
        name='update_let_remaining',
        category=ValidationCategory.SYNTAX_ERROR,
        severity=Severity.ERROR,
        pattern=r'\bUPDATE\b[^;]*\bLET\s+\w+\s*:=',
        message='UPDATE statement uses LET instead of SET',
        description='SQL UPDATE requires SET col = val, not LET col := val',
        suggestion='Replace LET x := with SET x = inside UPDATE statements'
    ),
    ValidationRule(
        name='stray_where_clause',
        category=ValidationCategory.SYNTAX_ERROR,
        severity=Severity.ERROR,
        pattern=r'^\s*WHERE\s+\w+\s*=\s*\w+\s*;\s*$',
        message='Stray WHERE clause (not part of a statement)',
        description='A standalone WHERE clause is invalid SQL',
        suggestion='Remove this line or merge with the preceding statement'
    ),
    ValidationRule(
        name='byteint_remaining',
        category=ValidationCategory.UNCONVERTED,
        severity=Severity.WARNING,
        pattern=r'\bBYTEINT\b',
        message='BYTEINT not converted to TINYINT',
        description='Snowflake uses TINYINT instead of BYTEINT',
        suggestion='Use TINYINT data type'
    ),
    ValidationRule(
        name='nullifzero_remaining',
        category=ValidationCategory.UNCONVERTED,
        severity=Severity.ERROR,
        pattern=r'\bNULLIFZERO\s*\(',
        message='NULLIFZERO function not converted',
        description='Should be NULLIF(x, 0) in Snowflake',
        suggestion='Use NULLIF(column, 0)'
    ),
    ValidationRule(
        name='zeroifnull_remaining',
        category=ValidationCategory.UNCONVERTED,
        severity=Severity.ERROR,
        pattern=r'\bZEROIFNULL\s*\(',
        message='ZEROIFNULL function not converted',
        description='Should be COALESCE(x, 0) in Snowflake',
        suggestion='Use COALESCE(column, 0)'
    ),
    ValidationRule(
        name='bt_et_remaining',
        category=ValidationCategory.UNCONVERTED,
        severity=Severity.ERROR,
        pattern=r'^\s*(?:BT|ET)\s*;',
        message='BT/ET transaction control not converted',
        description='Teradata BT/ET should be removed or commented out',
        suggestion='Remove or replace with Snowflake transaction control'
    ),
    ValidationRule(
        name='delete_all_remaining',
        category=ValidationCategory.UNCONVERTED,
        severity=Severity.ERROR,
        pattern=r'\bDELETE\s+[\w.]+\s+ALL\s*;',
        message='DELETE table ALL not converted',
        description='Should be DELETE FROM table in Snowflake',
        suggestion='Use DELETE FROM table'
    ),
    ValidationRule(
        name='substring_from_for_remaining',
        category=ValidationCategory.UNCONVERTED,
        severity=Severity.WARNING,
        pattern=r'\bSUBSTRING\s*\([^)]*\sFROM\s',
        message='SUBSTRING ... FROM ... FOR not converted to SUBSTR',
        description='Teradata SUBSTRING(x FROM n FOR m) should be SUBSTR(x, n, m)',
        suggestion='Use SUBSTR(string, start, length)'
    ),
    ValidationRule(
        name='byte_remaining',
        category=ValidationCategory.UNCONVERTED,
        severity=Severity.WARNING,
        pattern=r'\bBYTE\s*\(\d+\)',
        message='BYTE data type not converted',
        description='Should be BINARY in Snowflake',
        suggestion='Use BINARY(n) data type'
    ),
    ValidationRule(
        name='varbyte_remaining',
        category=ValidationCategory.UNCONVERTED,
        severity=Severity.WARNING,
        pattern=r'\bVARBYTE\s*\(\d+\)',
        message='VARBYTE data type not converted',
        description='Should be VARBINARY in Snowflake',
        suggestion='Use VARBINARY(n) data type'
    ),
    ValidationRule(
        name='index_function_remaining',
        category=ValidationCategory.UNCONVERTED,
        severity=Severity.ERROR,
        pattern=r'\bINDEX\s*\(\s*[^)]+,\s*[^)]+\)',
        message='INDEX function not converted',
        description='Should be POSITION(substr IN str) in Snowflake',
        suggestion='Use POSITION(substr IN str)'
    ),
    ValidationRule(
        name='sample_remaining',
        category=ValidationCategory.UNCONVERTED,
        severity=Severity.WARNING,
        pattern=r'\bSAMPLE\s+\d+\b',
        message='SAMPLE not converted to LIMIT',
        description='Teradata SAMPLE should be LIMIT in Snowflake',
        suggestion='Use LIMIT n'
    ),
    ValidationRule(
        name='format_clause_remaining',
        category=ValidationCategory.UNCONVERTED,
        severity=Severity.WARNING,
        pattern=r"\(FORMAT\s+'[^']+'\)",
        message='FORMAT clause not removed',
        description='Teradata FORMAT clause not supported in Snowflake',
        suggestion='Remove FORMAT clause or use TO_CHAR'
    ),
    ValidationRule(
        name='title_clause_remaining',
        category=ValidationCategory.UNCONVERTED,
        severity=Severity.WARNING,
        pattern=r"\(TITLE\s+'[^']+'\)",
        message='TITLE clause not removed',
        description='Teradata TITLE clause not supported in Snowflake',
        suggestion='Remove TITLE clause'
    ),
    ValidationRule(
        name='named_clause_remaining',
        category=ValidationCategory.UNCONVERTED,
        severity=Severity.WARNING,
        pattern=r"\(NAMED\s+'[^']+'\)",
        message='NAMED clause not removed',
        description='Teradata NAMED clause not supported in Snowflake',
        suggestion='Remove NAMED clause'
    ),
    ValidationRule(
        name='interval_day_remaining',
        category=ValidationCategory.UNCONVERTED,
        severity=Severity.ERROR,
        pattern=r'\)\s*DAY\s*\(\d+\)',
        message='INTERVAL DAY syntax not converted',
        description='Should use DATEDIFF for date differences',
        suggestion='Use DATEDIFF(DAY, date1, date2)'
    ),
    ValidationRule(
        name='date_literal_remaining',
        category=ValidationCategory.UNCONVERTED,
        severity=Severity.WARNING,
        pattern=r"\bDATE\s+'\d{4}-\d{2}-\d{2}'",
        message='DATE literal not converted',
        description="DATE 'YYYY-MM-DD' should be 'YYYY-MM-DD'::DATE",
        suggestion="Use 'YYYY-MM-DD'::DATE syntax"
    ),
    ValidationRule(
        name='timestamp_literal_remaining',
        category=ValidationCategory.UNCONVERTED,
        severity=Severity.WARNING,
        pattern=r"\bTIMESTAMP\s+'[^']+'",
        message='TIMESTAMP literal not converted',
        description="TIMESTAMP 'value' should be 'value'::TIMESTAMP",
        suggestion="Use 'value'::TIMESTAMP syntax"
    ),
    ValidationRule(
        name='interval_add_remaining',
        category=ValidationCategory.UNCONVERTED,
        severity=Severity.ERROR,
        pattern=r"\+\s*INTERVAL\s+'\d+'\s+MONTH",
        message='INTERVAL addition not converted',
        description='Should use DATEADD for interval arithmetic',
        suggestion='Use DATEADD(MONTH, n, date)'
    ),
    ValidationRule(
        name='interval_subtract_remaining',
        category=ValidationCategory.UNCONVERTED,
        severity=Severity.ERROR,
        pattern=r"-\s*INTERVAL\s+'\d+'\s+MONTH",
        message='INTERVAL subtraction not converted',
        description='Should use DATEADD for interval arithmetic',
        suggestion='Use DATEADD(MONTH, -n, date)'
    ),
]


# =============================================================================
# SYNTAX ERROR CHECKS
# =============================================================================

class StructuralBeginEndRule(ValidationRule):
    """Counts BEGIN/END pairs structurally instead of per-line regex."""

    @staticmethod
    def _count_block_ends(cleaned: str) -> int:
        """Count block-level END; tokens, excluding CASE expression ENDs.

        Uses a stack-based approach: CASE and BEGIN push onto a stack,
        bare END pops.  Only ENDs that close a BEGIN are counted.
        Compound keywords like END IF, END LOOP, END FOR, END WHILE
        are skipped — they close their own control blocks, not BEGIN blocks.
        """
        # Match compound END keywords first (longer patterns), then
        # bare CASE/BEGIN/END.  Order matters: longer patterns checked first.
        token_re = re.compile(
            r'\bEND\s+(?:IF|LOOP|FOR|WHILE)\b'   # compound — skip these
            r'|\b(CASE|BEGIN|END)\b',              # trackable keywords
            re.IGNORECASE
        )
        stack = []
        block_ends = 0
        for m in token_re.finditer(cleaned):
            kw = m.group(1)
            if kw is None:
                # Matched the compound END IF/LOOP/FOR/WHILE — skip
                continue
            kw = kw.upper()
            if kw in ('CASE', 'BEGIN'):
                stack.append(kw)
            elif kw == 'END':
                if stack:
                    top = stack.pop()
                    if top == 'BEGIN':
                        block_ends += 1
                    # top == 'CASE' → CASE expression END, not counted
                else:
                    # Unmatched END — count it as block END
                    block_ends += 1
        return block_ends

    def check(self, sql: str) -> List[dict]:
        """Only report if BEGIN/END counts are unbalanced."""
        # IMPORTANT: Block comments MUST be stripped BEFORE line comments.
        # Block comments can contain lines of dashes (--------) that match
        # --[^\n]*, which would destroy the closing */ and cause the block
        # comment regex to swallow subsequent SQL including BEGIN keywords.
        cleaned = re.sub(r'/\*[\s\S]*?\*/', '', sql)
        cleaned = re.sub(r'--[^\n]*', '', cleaned)

        begin_count = len(re.findall(r'\bBEGIN\b', cleaned, re.IGNORECASE))
        end_count = self._count_block_ends(cleaned)

        if begin_count == end_count:
            return []

        return [{
            'line': 1,
            'column': 1,
            'matched_text': f'BEGIN({begin_count}) vs END({end_count})',
            'line_content': f'Found {begin_count} BEGIN and {end_count} END statements'
        }]


class CommentSwallowedKeywordRule(ValidationRule):
    """Detects SQL keywords that were swallowed by inline comments.

    This catches the dangerous pattern where a SQL keyword (WHERE, SELECT, etc.)
    appears inside a -- comment, meaning the keyword and its clause are lost.
    Example: `-- TODO: some text.WHERE col = val` (WHERE is part of comment)
    """

    SQL_KEYWORDS = (
        'WHERE', 'SELECT', 'FROM', 'INSERT', 'UPDATE', 'DELETE', 'MERGE',
        'CREATE', 'DROP', 'ALTER', 'QUALIFY', 'HAVING', 'GROUP', 'ORDER',
        'UNION', 'INTO', 'VALUES', 'SET', 'ON', 'JOIN', 'LEFT', 'RIGHT',
        'INNER', 'OUTER', 'CROSS', 'BEGIN', 'DECLARE', 'RETURN'
    )

    def check(self, sql: str) -> List[dict]:
        """Check for SQL keywords embedded inside -- comments.

        Skips file-header metadata lines (lines before the first non-comment
        line) since those describe conversion actions and frequently contain
        keywords like FROM, INTO as part of descriptions.
        """
        issues = []
        kw_pattern = re.compile(
            r'--[^\n]*?\.\s*\b(' + '|'.join(self.SQL_KEYWORDS) + r')\b',
            re.IGNORECASE
        )

        # Determine where the header ends: first non-comment, non-blank line.
        lines = sql.split('\n')
        header_end_line = 0
        for i, line in enumerate(lines, 1):
            stripped = line.strip()
            if stripped and not stripped.startswith('--') and not stripped.startswith('/*'):
                header_end_line = i
                break

        for i, line in enumerate(lines, 1):
            # Skip header metadata lines
            if i < header_end_line:
                continue

            for match in kw_pattern.finditer(line):
                keyword = match.group(1)
                issues.append({
                    'line': i,
                    'column': match.start() + 1,
                    'matched_text': match.group(0),
                    'line_content': line.strip()
                })

        return issues


class MergeAliasMismatchRule(ValidationRule):
    """Detects MERGE statements where ON/SET clauses reference an alias
    that doesn't match the USING alias or target alias."""

    def check(self, sql: str) -> List[dict]:
        """Check for alias mismatches in MERGE statements.

        Uses balanced-parenthesis tracking to find the true USING alias
        (the word after the outermost closing paren of the USING subquery),
        instead of regex lazy/greedy matching which fails on nested parens.
        """
        issues = []
        # Find each MERGE INTO ... <tgt_alias>
        merge_header_re = re.compile(
            r'MERGE\s+INTO\s+[\w.]+\s+(\w+)\s*\n\s*USING\s*\(',
            re.IGNORECASE
        )

        for header_m in merge_header_re.finditer(sql):
            tgt_alias = header_m.group(1).upper()
            # Track balanced parentheses from the opening ( of USING
            paren_start = header_m.end() - 1  # position of '('
            depth = 1
            pos = paren_start + 1
            while pos < len(sql) and depth > 0:
                if sql[pos] == '(':
                    depth += 1
                elif sql[pos] == ')':
                    depth -= 1
                pos += 1
            if depth != 0:
                continue  # unbalanced parens, skip

            # pos is now right after the closing ')'. Extract the alias word.
            after_close = sql[pos:pos + 50].strip()
            alias_m = re.match(r'(\w+)', after_close)
            if not alias_m:
                continue
            src_alias = alias_m.group(1).upper()

            # Find ON clause: from after the alias to WHEN MATCHED
            on_start = pos + after_close.index(alias_m.group(0)) + len(alias_m.group(0))
            when_m = re.search(r'WHEN\s+MATCHED', sql[on_start:], re.IGNORECASE)
            if not when_m:
                continue
            on_clause = sql[on_start:on_start + when_m.start()]

            # Bound the ON clause to the first semicolon if it appears before
            # WHEN MATCHED. This prevents scanning commented-out SQL that lies
            # between a MERGE's terminating ; and a distant WHEN MATCHED.
            semi_pos = on_clause.find(';')
            if semi_pos >= 0:
                on_clause = on_clause[:semi_pos]

            # Strip comments before scanning for alias references.
            on_clause = re.sub(r'/\*[\s\S]*?\*/', '', on_clause)
            on_clause = re.sub(r'--[^\n]*', '', on_clause)

            # Find all alias.column references in ON clause
            ref_re = re.compile(r'\b(\w+)\.(\w+)', re.IGNORECASE)
            for ref_m in ref_re.finditer(on_clause):
                alias = ref_m.group(1).upper()
                # Skip schema-qualified names (typically have underscores like P_SCHEMA_01)
                if '_' in alias and len(alias) > 5:
                    continue
                if alias not in (tgt_alias, src_alias):
                    abs_pos = on_start + ref_m.start()
                    line_num = sql[:abs_pos].count('\n') + 1
                    issues.append({
                        'line': line_num,
                        'column': 1,
                        'matched_text': ref_m.group(0),
                        'line_content': f'MERGE ON clause references alias "{ref_m.group(1)}" but USING alias is "{src_alias.lower()}"'
                    })

        return issues


SYNTAX_RULES = [
    StructuralBeginEndRule(
        name='unmatched_begin',
        category=ValidationCategory.SYNTAX_ERROR,
        severity=Severity.ERROR,
        pattern=r'unused',
        message='Unbalanced BEGIN/END blocks',
        description='BEGIN and END counts do not match',
        suggestion='Ensure every BEGIN has a matching END'
    ),
    CommentSwallowedKeywordRule(
        name='comment_swallowed_keyword',
        category=ValidationCategory.SYNTAX_ERROR,
        severity=Severity.ERROR,
        pattern=r'unused',
        message='SQL keyword embedded inside a comment — clause is silently lost',
        description='A SQL keyword (WHERE, SELECT, etc.) appears inside a -- comment, causing the entire clause to be ignored',
        suggestion='Move the SQL keyword to a new line so it is not part of the comment'
    ),
    MergeAliasMismatchRule(
        name='merge_alias_mismatch',
        category=ValidationCategory.SYNTAX_ERROR,
        severity=Severity.ERROR,
        pattern=r'unused',
        message='MERGE ON/SET clause references an alias not matching USING or target',
        description='MERGE alias mismatch — ON or SET clause uses a different alias than the USING source alias',
        suggestion='Replace the old alias with the USING alias (src) in ON and SET clauses'
    ),
    ValidationRule(
        name='double_semicolon',
        category=ValidationCategory.SYNTAX_ERROR,
        severity=Severity.WARNING,
        pattern=r';\s*;',
        message='Double semicolon detected',
        description='Consecutive semicolons may cause issues',
        suggestion='Remove duplicate semicolon'
    ),
    ValidationRule(
        name='empty_set',
        category=ValidationCategory.SYNTAX_ERROR,
        severity=Severity.ERROR,
        pattern=r'\bSET\s*;',
        message='Empty SET statement',
        description='SET statement has no assignment',
        suggestion='Add variable assignment or remove statement'
    ),
    ValidationRule(
        name='missing_into',
        category=ValidationCategory.SYNTAX_ERROR,
        severity=Severity.WARNING,
        pattern=r'\bSELECT\s+[^;]+\s+:=\s*\(',
        message='Possible missing INTO clause',
        description='Variable assignment may need SELECT INTO',
        suggestion='Use SELECT ... INTO variable syntax'
    ),
    ValidationRule(
        name='update_from_unconverted',
        category=ValidationCategory.SYNTAX_ERROR,
        severity=Severity.ERROR,
        pattern=r'\bUPDATE\s+[\w.]+\s+FROM\s+',
        message='UPDATE FROM syntax not converted (Teradata clause order)',
        description='Snowflake requires UPDATE SET FROM or MERGE for UPDATE FROM pattern',
        suggestion='Reorder to UPDATE table SET ... FROM ... WHERE ... or convert to MERGE'
    ),
    ValidationRule(
        name='standalone_set_not_let',
        category=ValidationCategory.SYNTAX_ERROR,
        severity=Severity.ERROR,
        pattern=r'^\s*SET\s+\w+\s*=\s*(?:SQLROWCOUNT|SQLERRM|SQLCODE)\s*;',
        message='Standalone SET var = value should be LET in Snowflake Scripting',
        description='SET is only valid inside SQL UPDATE; use LET for variable assignment',
        suggestion='Change to LET var := value;'
    ),
]


# =============================================================================
# INCOMPLETE CONVERSION CHECKS
# =============================================================================

INCOMPLETE_RULES = [
    ValidationRule(
        name='todo_comment',
        category=ValidationCategory.INCOMPLETE,
        severity=Severity.WARNING,
        pattern=r'--\s*TODO[:\s]',
        message='TODO comment found - may need attention',
        description='Code contains TODO marker requiring review',
        suggestion='Review and address TODO items'
    ),
    ValidationRule(
        name='fixme_comment',
        category=ValidationCategory.INCOMPLETE,
        severity=Severity.WARNING,
        pattern=r'--\s*FIXME[:\s]',
        message='FIXME comment found',
        description='Code contains FIXME marker',
        suggestion='Review and fix marked issues'
    ),
    ValidationRule(
        name='manual_review_needed',
        category=ValidationCategory.INCOMPLETE,
        severity=Severity.INFO,
        pattern=r'--\s*(?:REVIEW|MANUAL|CHECK)[:\s]',
        message='Manual review marker found',
        description='Code marked for manual review',
        suggestion='Perform manual review of flagged section'
    ),
    ValidationRule(
        name='partial_merge',
        category=ValidationCategory.INCOMPLETE,
        severity=Severity.ERROR,
        pattern=r'\bMERGE\s+INTO[^;]*(?:WHEN\s+MATCHED|WHEN\s+NOT\s+MATCHED)[^;]*$',
        message='Possibly incomplete MERGE statement',
        description='MERGE statement may be missing clauses',
        suggestion='Ensure MERGE has all required clauses'
    ),
]


# =============================================================================
# WARNING CHECKS
# =============================================================================

WARNING_RULES = [
    ValidationRule(
        name='select_star',
        category=ValidationCategory.WARNING,
        severity=Severity.INFO,
        pattern=r'\bSELECT\s+\*\s+FROM\b',
        message='SELECT * detected',
        description='Explicit column list preferred over SELECT *',
        suggestion='Consider specifying column names explicitly'
    ),
    ValidationRule(
        name='cross_join',
        category=ValidationCategory.WARNING,
        severity=Severity.INFO,
        pattern=r'\bCROSS\s+JOIN\b',
        message='CROSS JOIN detected',
        description='Cross joins can produce large result sets',
        suggestion='Verify CROSS JOIN is intentional'
    ),
    ValidationRule(
        name='cartesian_product',
        category=ValidationCategory.WARNING,
        severity=Severity.WARNING,
        pattern=r'\bFROM\s+\w+\s*,\s*\w+\b(?![^WHERE]*WHERE)',
        message='Possible Cartesian product',
        description='Multiple tables without WHERE may produce cross join',
        suggestion='Add WHERE clause or use explicit JOIN'
    ),
    ValidationRule(
        name='hardcoded_date',
        category=ValidationCategory.WARNING,
        severity=Severity.INFO,
        pattern=r"'[12]\d{3}-[01]\d-[0-3]\d'",
        message='Hardcoded date literal found',
        description='Hardcoded dates may need parameterization',
        suggestion='Consider using date parameters or variables'
    ),
    ValidationRule(
        name='implicit_date_cast',
        category=ValidationCategory.WARNING,
        severity=Severity.WARNING,
        pattern=r"DATE\s+'[^']+'\s*[-+]",
        message='Date arithmetic with literals',
        description='Date arithmetic may behave differently in Snowflake',
        suggestion='Use DATEADD for date arithmetic'
    ),
    ValidationRule(
        name='double_double_quote',
        category=ValidationCategory.WARNING,
        severity=Severity.WARNING,
        pattern=r'""[A-Za-z_]\w*""',
        message='Double-double-quoted identifier found',
        description='""identifier"" inside procedure body should be "identifier"',
        suggestion='Replace "" with " around identifiers inside $$ blocks'
    ),
]


# =============================================================================
# BEST PRACTICE CHECKS
# =============================================================================

BEST_PRACTICE_RULES = [
    ValidationRule(
        name='missing_schema',
        category=ValidationCategory.BEST_PRACTICE,
        severity=Severity.INFO,
        pattern=r'\b(?:FROM|JOIN|INTO|UPDATE|DELETE\s+FROM)\s+(?![\w]+\.)[\w]+\b',
        message='Table reference without schema prefix',
        description='Best practice to fully qualify table names',
        suggestion='Use fully qualified table names (schema.table)'
    ),
    ValidationRule(
        name='missing_alias',
        category=ValidationCategory.BEST_PRACTICE,
        severity=Severity.INFO,
        pattern=r'\bJOIN\s+[\w.]+\s+ON\b',
        message='JOIN without table alias',
        description='Table aliases improve readability',
        suggestion='Add alias for joined tables'
    ),
    ValidationRule(
        name='long_procedure',
        category=ValidationCategory.BEST_PRACTICE,
        severity=Severity.INFO,
        pattern=r'(?:CREATE\s+(?:OR\s+REPLACE\s+)?PROCEDURE)',
        message='Large procedure detected',
        description='Consider breaking into smaller procedures',
        suggestion='Break complex procedures into smaller units'
    ),
    ValidationRule(
        name='no_transaction_control',
        category=ValidationCategory.BEST_PRACTICE,
        severity=Severity.INFO,
        pattern=r'(?:INSERT|UPDATE|DELETE|MERGE)',
        message='DML without explicit transaction control',
        description='Consider adding explicit BEGIN TRANSACTION/COMMIT',
        suggestion='Add transaction control for data consistency'
    ),
]


# =============================================================================
# SNOWFLAKE-SPECIFIC CHECKS
# =============================================================================

SNOWFLAKE_RULES = [
    ValidationRule(
        name='qualify_supported',
        category=ValidationCategory.BEST_PRACTICE,
        severity=Severity.INFO,
        pattern=r'\bQUALIFY\b',
        message='QUALIFY clause used (Snowflake native)',
        description='QUALIFY is natively supported in Snowflake',
        suggestion='No change needed - QUALIFY works in Snowflake'
    ),
    ValidationRule(
        name='temp_table_naming',
        category=ValidationCategory.BEST_PRACTICE,
        severity=Severity.INFO,
        pattern=r'\bCREATE\s+(?:OR\s+REPLACE\s+)?TEMPORARY\s+TABLE\s+(?!TEMP_|TMP_)\w+',
        message='Temporary table without TEMP/TMP prefix',
        description='Consider naming convention for temp tables',
        suggestion='Consider TEMP_ or TMP_ prefix for clarity'
    ),
    ValidationRule(
        name='missing_returns',
        category=ValidationCategory.SYNTAX_ERROR,
        severity=Severity.ERROR,
        pattern=r'CREATE\s+(?:OR\s+REPLACE\s+)?PROCEDURE[^;]*\)[\s\n]*(?:LANGUAGE|AS|BEGIN)',
        message='Procedure may be missing RETURNS clause',
        description='Snowflake procedures need RETURNS clause',
        suggestion='Add RETURNS VARCHAR or appropriate return type'
    ),
]


def get_all_validation_rules() -> List[ValidationRule]:
    """Get all validation rules."""
    return (
        UNCONVERTED_RULES +
        SYNTAX_RULES +
        INCOMPLETE_RULES +
        WARNING_RULES +
        BEST_PRACTICE_RULES +
        SNOWFLAKE_RULES
    )


def get_rules_by_category(category: ValidationCategory) -> List[ValidationRule]:
    """Get validation rules for a specific category."""
    return [r for r in get_all_validation_rules() if r.category == category]


def get_rules_by_severity(severity: Severity) -> List[ValidationRule]:
    """Get validation rules for a specific severity."""
    return [r for r in get_all_validation_rules() if r.severity == severity]
