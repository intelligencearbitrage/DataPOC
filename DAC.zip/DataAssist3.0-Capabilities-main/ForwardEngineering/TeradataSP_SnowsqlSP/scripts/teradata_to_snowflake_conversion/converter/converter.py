"""
Converter Module
================
Core conversion engine for Teradata to Snowflake SQL transformation.
"""

import re
import logging
from typing import List, Dict, Optional, Callable
from dataclasses import dataclass, field

from .rules import (
    ConversionRule,
    RuleCategories,
    get_procedure_rules,
    get_table_rules,
    get_datatype_rules,
    get_date_rules,
    get_string_rules,
    get_cast_rules,
    get_syntax_rules,
    get_all_rules,
)


@dataclass
class ConversionResult:
    """Result of a conversion operation."""
    original: str
    converted: str
    rules_applied: List[str] = field(default_factory=list)
    warnings: List[str] = field(default_factory=list)
    errors: List[str] = field(default_factory=list)
    success: bool = True


class TeradataToSnowflakeConverter:
    """
    Converts Teradata SQL to Snowflake SQL using pattern-based transformations.
    """

    def __init__(
        self,
        config: Optional[Dict] = None,
        logger: Optional[logging.Logger] = None
    ):
        """
        Initialize the converter.

        Args:
            config: Configuration dictionary
            logger: Optional logger instance
        """
        self.config = config or {}
        self.logger = logger or logging.getLogger(__name__)
        self.rules_applied: List[str] = []
        self.warnings: List[str] = []
        self._out_params: List[Dict[str, str]] = []  # Tracks removed OUT parameters

        # Initialize rules based on config
        self._init_rules()

        # Schema mapping from config
        self.schema_mapping = self.config.get('custom_schema_mapping', {})

    def _init_rules(self):
        """Initialize rules based on configuration."""
        rules_config = self.config.get('rules', {})

        self.rules: List[ConversionRule] = []

        # Add rules based on config flags
        if rules_config.get('convert_procedures', True):
            self.rules.extend(get_procedure_rules())

        if rules_config.get('convert_tables', True):
            self.rules.extend(get_table_rules())

        if rules_config.get('convert_dates', True):
            self.rules.extend(get_date_rules())

        if rules_config.get('convert_strings', True):
            self.rules.extend(get_string_rules())

        if rules_config.get('convert_casts', True):
            self.rules.extend(get_cast_rules())

        # Always include datatype and syntax rules
        self.rules.extend(get_datatype_rules())
        self.rules.extend(get_syntax_rules())

    def add_custom_rule(self, rule: ConversionRule):
        """Add a custom conversion rule."""
        self.rules.append(rule)
        self.logger.debug(f"Added custom rule: {rule.name}")

    def remove_rule(self, rule_name: str):
        """Remove a rule by name."""
        self.rules = [r for r in self.rules if r.name != rule_name]
        self.logger.debug(f"Removed rule: {rule_name}")

    def _extract_out_params(self, sql: str):
        """Extract OUT parameter names and types before they are removed by rules.

        Teradata procedures can have OUT/INOUT parameters that Snowflake
        doesn't support. This method captures them so they can be:
        - Added to the DECLARE block as local variables
        - Used as the RETURN value
        """
        self._out_params = []
        # Match OUT or INOUT parameters: (OUT name TYPE, INOUT name TYPE, ...)
        # Handles single or multiple OUT params
        param_pattern = re.compile(
            r'\b(?:OUT|INOUT)\s+(\w+)\s+(\w+(?:\s*\([^)]*\))?)',
            re.IGNORECASE
        )
        for match in param_pattern.finditer(sql):
            self._out_params.append({
                'name': match.group(1),
                'type': match.group(2),
            })

    def _strip_param_direction_keywords(self, sql: str) -> str:
        """Strip IN/OUT/INOUT keywords from procedure parameter declarations.

        Snowflake SQL Scripting does not support IN/OUT/INOUT keywords
        in procedure parameter lists. This removes them while preserving
        parameter names and types.

        Only operates on the CREATE OR REPLACE PROCEDURE header, not
        on other SQL (e.g., INSERT INTO ... VALUES).
        """
        # Match the procedure header's parameter list
        # Use [\s\S]*? to handle multi-line procedure names (e.g., schema.\nname)
        proc_match = re.search(
            r'(CREATE\s+OR\s+REPLACE\s+PROCEDURE\b[\s\S]*?)\(([^)]*)\)',
            sql, re.IGNORECASE
        )
        if not proc_match:
            return sql

        param_block = proc_match.group(2)
        original_param_block = param_block

        # Strip IN, OUT, INOUT keywords from each parameter
        # Match: IN/OUT/INOUT followed by whitespace and a name
        param_block = re.sub(
            r'\b(?:IN\s*OUT|INOUT|OUT|IN)\s+',
            '', param_block, flags=re.IGNORECASE
        )

        if param_block != original_param_block:
            new_header = proc_match.group(1) + '(' + param_block + ')'
            sql = sql[:proc_match.start()] + new_header + sql[proc_match.end():]
            self.rules_applied.append(
                "strip_param_direction: Removed IN/OUT/INOUT keywords from parameters"
            )

        return sql

    def _apply_rules(self, sql: str, rules: List[ConversionRule]) -> str:
        """Apply a list of conversion rules to SQL."""
        for rule in rules:
            if not rule.enabled:
                continue

            try:
                if callable(rule.replacement):
                    new_sql = re.sub(rule.pattern, rule.replacement, sql, flags=rule.flags)
                else:
                    new_sql = re.sub(rule.pattern, rule.replacement, sql, flags=rule.flags)

                if new_sql != sql:
                    self.rules_applied.append(f"{rule.name}: {rule.description}")
                    self.logger.debug(f"Applied rule: {rule.name}")
                    sql = new_sql
            except re.error as e:
                self.warnings.append(f"Regex error in rule {rule.name}: {e}")
                self.logger.warning(f"Regex error in rule {rule.name}: {e}")

        return sql

    def _convert_update_from_to_merge(self, sql: str) -> str:
        """
        Convert Teradata UPDATE FROM syntax to Snowflake MERGE.

        Uses structural parsing with balanced parenthesis extraction to
        handle ALL complexity levels — simple tables, aliased tables,
        and deeply nested subqueries.

        Teradata variants handled:
            1. UPDATE table FROM (subquery) AS alias SET ... WHERE ...
            2. UPDATE table SET ... FROM table2 WHERE ...
            3. UPDATE table a FROM table2 b SET ... WHERE ...
            4. UPDATE alias FROM schema.table alias, (subquery) alias SET ... WHERE ...
        """
        if not self.config.get('rules', {}).get('convert_updates_to_merge', True):
            return sql

        def _extract_balanced(text, start):
            """Extract balanced parenthesized content starting at `(`."""
            if start >= len(text) or text[start] != '(':
                return None, start
            depth = 0
            pos = start
            while pos < len(text):
                if text[pos] == '(':
                    depth += 1
                elif text[pos] == ')':
                    depth -= 1
                    if depth == 0:
                        return text[start + 1:pos], pos + 1
                pos += 1
            return None, start

        def _find_stmt_end(text, start):
            """Find statement end (;) respecting parenthesis depth."""
            depth = 0
            pos = start
            while pos < len(text):
                if text[pos] == '(':
                    depth += 1
                elif text[pos] == ')':
                    depth -= 1
                elif text[pos] == ';' and depth == 0:
                    return pos
                pos += 1
            return len(text)

        # Find all UPDATE ... FROM patterns and convert structurally
        # Handles both simple names (HLC_MAIN) and dotted names (SCHEMA.TABLE)
        update_from_re = re.compile(
            r'\bUPDATE\s+([\w.]+)\s+FROM\s+',
            re.IGNORECASE
        )

        result_parts = []
        search_start = 0

        while search_start < len(sql):
            match = update_from_re.search(sql, search_start)
            if not match:
                result_parts.append(sql[search_start:])
                break

            # Add everything before this UPDATE
            result_parts.append(sql[search_start:match.start()])

            target_alias = match.group(1)
            after_from = match.end()

            # Find the end of the full UPDATE statement
            stmt_end = _find_stmt_end(sql, after_from)
            full_stmt = sql[match.start():stmt_end + 1] if stmt_end < len(sql) else sql[match.start():]
            remaining = sql[after_from:stmt_end]

            # Parse what comes after FROM:
            # Could be: schema.table alias, (subquery) alias SET/LET ... WHERE ...
            # Or:       (subquery) AS alias SET ... WHERE ...
            # Or:       schema.table alias SET ... WHERE ...

            target_table = None
            source_alias = None
            subquery = None
            source_table = None
            set_clause = None
            where_clause = None

            pos = after_from
            text_after = sql[pos:stmt_end]

            # Check if source starts with ( — it's a subquery
            stripped_after = text_after.lstrip()
            paren_offset = len(text_after) - len(stripped_after)

            if stripped_after.startswith('('):
                # Pattern 1: FROM (subquery) AS alias SET ... WHERE ...
                subquery, after_paren = _extract_balanced(sql, pos + paren_offset)
                if subquery is not None:
                    rest = sql[after_paren:stmt_end].strip()
                    alias_match = re.match(r'\s*(?:AS\s+)?(\w+)\s+', rest, re.IGNORECASE)
                    if alias_match:
                        source_alias = alias_match.group(1)
                        rest = rest[alias_match.end():]
                    target_table = target_alias  # target_alias IS the table name here
            else:
                # Pattern 3/4: FROM schema.table alias [, (subquery) alias] SET/LET ... WHERE ...
                table_match = re.match(r'([\w.]+)\s+(\w+)', text_after, re.IGNORECASE)
                if table_match:
                    target_table = table_match.group(1)
                    tgt_alias_check = table_match.group(2)
                    rest = text_after[table_match.end():].strip()

                    # Check for comma-join: , (subquery) source_alias
                    if rest.startswith(','):
                        # Use pos (start of text_after in sql) + match end offset
                        # instead of stmt_end - len(rest) which is wrong after .strip()
                        comma_pos = pos + table_match.end()
                        # Advance to the actual comma character
                        while comma_pos < stmt_end and sql[comma_pos] in ' \t\n\r':
                            comma_pos += 1
                        scan_pos = comma_pos + 1
                        # Skip whitespace and comments between comma and (
                        while scan_pos < stmt_end:
                            while scan_pos < stmt_end and sql[scan_pos] in ' \t\n\r':
                                scan_pos += 1
                            if scan_pos >= stmt_end:
                                break
                            if sql[scan_pos:scan_pos+2] == '--':
                                nl = sql.find('\n', scan_pos)
                                scan_pos = nl + 1 if nl >= 0 else stmt_end
                                continue
                            if sql[scan_pos:scan_pos+2] == '/*':
                                close = sql.find('*/', scan_pos)
                                scan_pos = close + 2 if close >= 0 else stmt_end
                                continue
                            break
                        if scan_pos < stmt_end and sql[scan_pos] == '(':
                            subquery, after_paren = _extract_balanced(sql, scan_pos)
                            if subquery is not None:
                                rest_after = sql[after_paren:stmt_end].strip()
                                src_match = re.match(r'(\w+)\s+', rest_after, re.IGNORECASE)
                                if src_match:
                                    source_alias = src_match.group(1)
                                    rest = rest_after[src_match.end():]
                                else:
                                    # source alias might be glued: )src
                                    src_match2 = re.match(r'(\w+)', rest_after, re.IGNORECASE)
                                    if src_match2:
                                        source_alias = src_match2.group(1)
                                        rest = rest_after[src_match2.end():]
                        else:
                            # Check for a table reference at scan_pos
                            rest_at_scan = sql[scan_pos:stmt_end]
                            src_table_match = re.match(r'([\w.]+)\s+(\w+)', rest_at_scan, re.IGNORECASE)
                            if src_table_match:
                                source_table = src_table_match.group(1)
                                source_alias = src_table_match.group(2)
                                rest = rest_at_scan[src_table_match.end():].strip()
                        if not source_alias:
                            # Comma-join with table: , table alias
                            src_table_match = re.match(r'([\w.]+)\s+(\w+)', rest, re.IGNORECASE)
                            if src_table_match:
                                source_table = src_table_match.group(1)
                                source_alias = src_table_match.group(2)
                                rest = rest[src_table_match.end():].strip()
                    else:
                        # No comma — Pattern 3: FROM table alias SET ... WHERE ...
                        source_table = target_table
                        source_alias = tgt_alias_check
                        target_table = target_alias

            if rest is None:
                # Couldn't parse — leave as-is
                result_parts.append(full_stmt)
                search_start = stmt_end + 1
                continue

            # Extract SET/LET clause and WHERE clause from rest
            # Also handle bare assignment (var := val) when set_to_let rule already ran
            set_match = re.search(r'\b(?:SET|LET)\s+', rest, re.IGNORECASE)
            if not set_match:
                # Look for bare assignment: COLNAME := value (produced by set_to_let rule)
                set_match = re.search(r'(?:^|\n)\s*(\w+)\s*:=', rest)
            where_match = re.search(r'\bWHERE\s+', rest, re.IGNORECASE)

            if set_match and where_match:
                set_clause = rest[set_match.end():where_match.start()].strip()
                where_clause = rest[where_match.end():].strip()
            elif set_match:
                set_clause = rest[set_match.end():].strip()
                where_clause = None
            else:
                # No SET found — can't convert
                result_parts.append(full_stmt)
                search_start = stmt_end + 1
                continue

            # Fix LET → SET in the extracted clause
            set_clause = re.sub(r'\bLET\s+', '', set_clause, flags=re.IGNORECASE)
            set_clause = re.sub(r':=', '=', set_clause)

            # Build SET parts
            src_alias = source_alias or 'src'
            set_parts = self._parse_set_clause(set_clause, src_alias, 'src')

            # Build ON clause from WHERE
            on_clause = where_clause or ''
            if source_alias:
                on_clause = re.sub(rf'\b{re.escape(source_alias)}\.', 'src.', on_clause, flags=re.IGNORECASE)
            on_clause = re.sub(rf'\b{re.escape(target_alias)}\.', 'tgt.', on_clause, flags=re.IGNORECASE)

            # Build the MERGE statement
            if subquery:
                using_clause = f"(\n    {subquery}\n) src"
            elif source_table:
                using_clause = f"{source_table} src"
            else:
                # Can't determine source — leave as-is
                result_parts.append(full_stmt)
                search_start = stmt_end + 1
                continue

            if not target_table:
                target_table = target_alias

            merge = f"MERGE INTO {target_table} tgt\nUSING {using_clause}"
            if on_clause:
                merge += f"\nON {on_clause}"
            merge += f"\nWHEN MATCHED THEN UPDATE SET {', '.join(set_parts)};"

            result_parts.append(merge)
            self.rules_applied.append("update_from_to_merge: Converted UPDATE FROM to MERGE (structural)")
            search_start = stmt_end + 1

        # Also handle Pattern 2: UPDATE table SET ... FROM table2 WHERE ...
        joined = ''.join(result_parts)
        # IMPORTANT: Use [^;]+? instead of [\s\S]+? to prevent matching across
        # semicolons (statement boundaries).
        update_set_from = re.compile(
            r"""UPDATE\s+([\w.]+)\s+SET\s+([^;]+?)FROM\s+([\w.]+)\s+WHERE\s+([^;]+?)(?=;|$)""",
            re.VERBOSE | re.IGNORECASE
        )

        def replace_set_from(m):
            target = m.group(1)
            set_clause = m.group(2).strip()
            source = m.group(3)
            where_clause = m.group(4).strip()
            set_parts = self._parse_set_clause(set_clause, source, 'src')
            on_clause = where_clause
            on_clause = re.sub(rf'\b{re.escape(source)}\.', 'src.', on_clause, flags=re.IGNORECASE)
            on_clause = re.sub(rf'\b{re.escape(target)}\.', 'tgt.', on_clause, flags=re.IGNORECASE)
            self.rules_applied.append("update_from_to_merge: Converted UPDATE SET FROM to MERGE")
            return f"MERGE INTO {target} tgt\nUSING {source} src\nON {on_clause}\nWHEN MATCHED THEN UPDATE SET {', '.join(set_parts)};"

        joined = update_set_from.sub(replace_set_from, joined)

        # Handle Teradata UPDATE...FROM clause ordering for Snowflake.
        # Teradata: UPDATE table FROM (subquery) AS alias SET ... WHERE ...
        # Snowflake: UPDATE table SET ... FROM (subquery) AS alias WHERE ...
        # This catches remaining UPDATE...FROM patterns that weren't converted
        # to MERGE (e.g., self-join UPDATE or simple FROM reorder cases).
        joined = self._reorder_update_from_clauses(joined)

        return joined

    def _reorder_update_from_clauses(self, sql: str) -> str:
        """Reorder remaining UPDATE...FROM statements for Snowflake syntax.

        Teradata allows: UPDATE table FROM (...) AS alias SET col = ... WHERE ...
        Snowflake requires: UPDATE table SET col = ... FROM (...) AS alias WHERE ...

        This handles all remaining UPDATE...FROM patterns that weren't converted
        to MERGE, by simply reordering the clauses.
        """
        # Match UPDATE <table> [inline comment]\nFROM ... SET ... WHERE ...
        # Uses balanced paren tracking since FROM source can contain subqueries
        update_re = re.compile(
            r'\bUPDATE\s+([\w.]+)\s*([^\n]*?)\s*\n\s*FROM\s+',
            re.IGNORECASE
        )

        result_parts = []
        search_start = 0

        while search_start < len(sql):
            match = update_re.search(sql, search_start)
            if not match:
                result_parts.append(sql[search_start:])
                break

            result_parts.append(sql[search_start:match.start()])

            table_name = match.group(1)
            inline_comment = match.group(2).strip()
            from_start = match.end()

            # Find the full FROM clause (may contain subqueries with parens)
            # Then find SET and WHERE
            depth = 0
            pos = from_start
            from_end = None
            set_pos = None
            where_pos = None

            # Walk through character by character tracking paren depth
            while pos < len(sql):
                ch = sql[pos]
                if ch == '(':
                    depth += 1
                elif ch == ')':
                    depth -= 1
                elif ch == ';' and depth == 0:
                    break
                elif depth == 0:
                    rest = sql[pos:]
                    if set_pos is None and re.match(r'\bSET\b', rest, re.IGNORECASE):
                        set_pos = pos
                    elif where_pos is None and set_pos is not None and re.match(r'\bWHERE\b', rest, re.IGNORECASE):
                        where_pos = pos
                pos += 1

            stmt_end = pos  # position of ; or end

            if set_pos is None:
                # Can't reorder without SET — leave as-is
                result_parts.append(sql[match.start():stmt_end])
                search_start = stmt_end
                continue

            from_clause = sql[from_start:set_pos].strip()
            if where_pos:
                set_clause = sql[set_pos:where_pos].strip()
                where_clause = sql[where_pos:stmt_end].rstrip().rstrip(';').strip()
                terminator = ';' if sql[stmt_end - 1:stmt_end] == ';' or stmt_end < len(sql) and sql[stmt_end:stmt_end + 1] == ';' else ';'
            else:
                set_clause = sql[set_pos:stmt_end].rstrip().rstrip(';').strip()
                where_clause = None
                terminator = ';'

            # Rebuild in Snowflake order: UPDATE table SET ... FROM ... WHERE ...
            comment = f' {inline_comment}' if inline_comment else ''
            reordered = f"UPDATE {table_name}{comment}\n{set_clause}\n FROM {from_clause}"
            if where_clause:
                reordered += f"\n {where_clause}"
            reordered += terminator

            result_parts.append(reordered)
            self.rules_applied.append(
                "reorder_update_from: Reordered UPDATE...FROM to Snowflake clause order"
            )
            search_start = stmt_end + 1 if stmt_end < len(sql) and sql[stmt_end:stmt_end + 1] == ';' else stmt_end

        return ''.join(result_parts)

    def _fix_merge_alias_references(self, sql: str) -> str:
        """Fix alias references in MERGE ON/WHEN clauses only.

        When converting UPDATE...FROM to MERGE, old alias references in the
        ON and WHEN MATCHED clauses need to use the USING alias (src/tgt).

        IMPORTANT: This method must NOT touch anything inside the USING
        subquery — only the ON and WHEN MATCHED clauses that follow it.
        Uses balanced parenthesis tracking to correctly find where the
        USING subquery ends.
        """
        merge_start_re = re.compile(
            r'\bMERGE\s+INTO\s+([\w.]+)\s+(\w+)\s*\n\s*USING\s*\(',
            re.IGNORECASE
        )

        result_parts = []
        search_pos = 0
        changed = False

        while search_pos < len(sql):
            match = merge_start_re.search(sql, search_pos)
            if not match:
                result_parts.append(sql[search_pos:])
                break

            # Add everything before this MERGE
            result_parts.append(sql[search_pos:match.start()])

            tgt_table_full = match.group(1)
            tgt_alias = match.group(2)
            # Extract bare target table name (last segment after .)
            tgt_table_bare = tgt_table_full.rsplit('.', 1)[-1]
            # Find the end of the USING subquery using balanced parens
            paren_start = match.end() - 1  # position of the opening (
            depth = 1
            pos = paren_start + 1
            while pos < len(sql) and depth > 0:
                if sql[pos] == '(':
                    depth += 1
                elif sql[pos] == ')':
                    depth -= 1
                pos += 1

            if depth != 0:
                # Unbalanced — leave as-is
                result_parts.append(sql[match.start():pos])
                search_pos = pos
                continue

            # pos is now right after the closing ) of USING subquery
            # Find the src alias after )
            after_paren = sql[pos:].lstrip()
            alias_m = re.match(r'(\w+)', after_paren)
            if not alias_m:
                result_parts.append(sql[match.start():pos])
                search_pos = pos
                continue

            src_alias = alias_m.group(1)
            after_alias_pos = pos + (len(sql[pos:]) - len(after_paren)) + alias_m.end()

            # Everything from MERGE start through USING (...) src is the HEADER — keep untouched
            header = sql[match.start():after_alias_pos]

            # Find the end of this MERGE statement (;)
            stmt_end = after_alias_pos
            while stmt_end < len(sql) and sql[stmt_end] != ';':
                stmt_end += 1
            if stmt_end < len(sql):
                stmt_end += 1  # include the ;

            # The ON/WHEN part is after the header, before the ;
            on_when_part = sql[after_alias_pos:stmt_end]

            # Only replace aliases in ON/WHEN — NOT in the header/subquery
            ref_pattern = re.compile(r'\b(\w+)\.', re.IGNORECASE)
            src_refs = set()
            tgt_refs = set()
            for ref_m in ref_pattern.finditer(on_when_part):
                ref = ref_m.group(1)
                if ref.upper() in (src_alias.upper(), tgt_alias.upper()):
                    continue
                # Skip schema-qualified refs (P_SCHEMA_01_V0 etc.)
                if re.match(r'^P_', ref, re.IGNORECASE):
                    continue
                # Check if this reference matches the target table name
                if ref.upper() == tgt_table_bare.upper():
                    tgt_refs.add(ref)
                else:
                    src_refs.add(ref)

            for old_ref in tgt_refs:
                on_when_part = re.sub(
                    rf'\b{re.escape(old_ref)}\.',
                    f'{tgt_alias}.',
                    on_when_part,
                    flags=re.IGNORECASE
                )
                changed = True

            for old_ref in src_refs:
                on_when_part = re.sub(
                    rf'\b{re.escape(old_ref)}\.',
                    f'src.',
                    on_when_part,
                    flags=re.IGNORECASE
                )
                changed = True

            result_parts.append(header + on_when_part)
            search_pos = stmt_end

        if changed:
            self.rules_applied.append(
                "fix_merge_alias_references: Fixed alias references in MERGE ON/WHEN clauses"
            )

        return ''.join(result_parts)

    def _parse_set_clause(self, set_clause: str, old_alias: str, new_alias: str) -> List[str]:
        """Parse SET clause and replace alias references."""
        set_parts = []
        # Handle nested parentheses in SET clause
        depth = 0
        current_part = ""

        for char in set_clause:
            if char == '(':
                depth += 1
                current_part += char
            elif char == ')':
                depth -= 1
                current_part += char
            elif char == ',' and depth == 0:
                if current_part.strip():
                    set_parts.append(current_part.strip())
                current_part = ""
            else:
                current_part += char

        if current_part.strip():
            set_parts.append(current_part.strip())

        result = []
        for part in set_parts:
            if '=' in part:
                col, val = part.split('=', 1)
                col = col.strip()
                val = val.strip()
                # Replace alias references
                val = re.sub(rf'\b{old_alias}\.', f'{new_alias}.', val, flags=re.IGNORECASE)
                result.append(f"{col} = {val}")
            else:
                result.append(part)

        return result

    def _convert_exception_handler(self, sql: str) -> str:
        """Convert Teradata EXIT HANDLER to Snowflake EXCEPTION block.

        Extracts the handler body and reconstructs it as a Snowflake
        EXCEPTION WHEN OTHER THEN block placed at the end of the
        inner BEGIN...END block.
        """
        if not self.config.get('rules', {}).get('convert_exception_handlers', True):
            return sql

        # Pattern for Teradata exception handler
        handler_pattern = r"DECLARE\s+EXIT\s+HANDLER\s+FOR\s+\w+\s*(?:\n\s*)?BEGIN\s*([\s\S]*?)END\s*;"

        match = re.search(handler_pattern, sql, re.IGNORECASE)
        if not match:
            return sql

        handler_body = match.group(1).strip()

        # Convert handler body to Snowflake syntax
        # Replace SQLCODE with Snowflake's SQLCODE (same name in exception)
        # Replace SQLSTATE with SQLERRM
        exception_lines = []
        exception_lines.append("    EXCEPTION")
        exception_lines.append("        WHEN OTHER THEN")

        # First: join multi-line statements into single logical lines.
        # A line that doesn't end with ; is continued on the next line.
        raw_lines = handler_body.split('\n')
        logical_lines = []
        current = ""
        for line in raw_lines:
            stripped = line.strip()
            if not stripped:
                continue
            if current:
                current += " " + stripped
            else:
                current = stripped
            if current.endswith(';'):
                logical_lines.append(current)
                current = ""
        if current:
            logical_lines.append(current)

        # Track whether we're inside a DBC.ERRORMSGS multi-line removal
        skip_dbc_continuation = False

        for converted_line in logical_lines:
            # Preserve SQLSTATE as-is (Snowflake supports SQLSTATE in EXCEPTION blocks)
            # The original Teradata SET WSQLMSG = SQLSTATE captures the 5-char state code
            # converted_line = re.sub(r'\bSQLSTATE\b', 'SQLSTATE', converted_line, flags=re.IGNORECASE)

            # If previous line was a DBC.ERRORMSGS SELECT, skip continuation
            # lines like standalone WHERE clauses that belonged to that SELECT
            if skip_dbc_continuation:
                stripped_check = converted_line.strip().upper()
                if stripped_check.startswith('WHERE') or stripped_check.startswith('AND'):
                    continue  # Skip this stray WHERE/AND from the removed SELECT
                skip_dbc_continuation = False

            # Convert DBC.ERRORMSGS lookups - Teradata-specific error table has no
            # Snowflake equivalent. Replace entire SELECT...INTO with SQLERRM assignment.
            # Pattern: SELECT ... INTO var FROM DBC.ERRORMSGS ...
            dbc_match = re.search(
                r'SELECT\s+[\s\S]*?\bINTO\s+(\w+)\s+FROM\s+DBC\.ERRORMSGS\b[\s\S]*',
                converted_line, re.IGNORECASE
            )
            if dbc_match:
                target_var = dbc_match.group(1)
                converted_line = f"LET {target_var} := SQLERRM;"
                skip_dbc_continuation = True
            elif re.search(r'\bDBC\.ERRORMSGS\b', converted_line, re.IGNORECASE):
                # Fallback: if DBC.ERRORMSGS is referenced but not in a SELECT INTO,
                # comment it out and add SQLERRM equivalent
                converted_line = f"-- Replaced DBC.ERRORMSGS lookup with SQLERRM"
                skip_dbc_continuation = True

            # Fix INSERT column list: if an INSERT INTO ... ("")  has fewer
            # columns than VALUES, preserve the original full column list.
            # Detect truncated column lists: only one column but multiple values
            insert_match = re.search(
                r'(INSERT\s+INTO\s+[\w.]+\s*)\(([^)]+)\)(\s*VALUES\s*\()([^)]+)\)',
                converted_line, re.IGNORECASE
            )
            if insert_match:
                col_list = [c.strip() for c in insert_match.group(2).split(',')]
                val_list = [v.strip() for v in insert_match.group(4).split(',')]
                if len(col_list) < len(val_list) and len(col_list) == 1:
                    # Column list was truncated — this is a known issue where
                    # double-quote stripping ate the column separator.
                    # Leave it as-is for now; _fix_double_quoted_identifiers
                    # will clean up the quotes, then corrector can handle it.
                    pass

            exception_lines.append(f"            {converted_line}")

        # Remove the handler from the original SQL
        sql = re.sub(handler_pattern, "", sql, flags=re.IGNORECASE)

        # Store handler for later insertion
        self._exception_block = '\n'.join(exception_lines)
        self.rules_applied.append("exception_handler: Converted EXIT HANDLER to EXCEPTION WHEN OTHER THEN block")

        return sql

    def _apply_schema_mapping(self, sql: str) -> str:
        """Apply schema name mappings from configuration.

        Handles both unquoted and quoted schema references:
        - P_CCARDM_01_E0.TABLE → CCARDM_DB.E0_SCHEMA.TABLE
        - "P_CCARDM_01_E0"."TABLE" → CCARDM_DB.E0_SCHEMA."TABLE"
        """
        if not self.schema_mapping:
            return sql

        for td_schema, sf_schema in self.schema_mapping.items():
            # 1. Unquoted schema references: P_CCARDM_01_E0.table
            pattern = rf'\b{re.escape(td_schema)}\.'
            replacement = f'{sf_schema}.'
            new_sql = re.sub(pattern, replacement, sql, flags=re.IGNORECASE)
            if new_sql != sql:
                self.rules_applied.append(f"schema_mapping: {td_schema} → {sf_schema}")
                sql = new_sql

            # 2. Quoted schema references: "P_CCARDM_01_E0"."table"
            quoted_pattern = rf'"{re.escape(td_schema)}"\s*\.\s*'
            quoted_replacement = f'{sf_schema}.'
            new_sql = re.sub(quoted_pattern, quoted_replacement, sql, flags=re.IGNORECASE)
            if new_sql != sql:
                self.rules_applied.append(f"schema_mapping_quoted: \"{td_schema}\" → {sf_schema}")
                sql = new_sql

        return sql

    def _generate_declare_block(self, sql: str) -> str:
        """Wrap orphaned variable declarations in a proper DECLARE block.

        Scans the entire procedure body for orphaned variable declarations
        (lines matching WORD TYPE; or WORD TYPE DEFAULT expr;) and
        consolidates them into a single DECLARE block at the first BEGIN.
        """
        if '$$' not in sql:
            return sql

        # Split at $$ to find the procedure body
        parts = sql.split('$$', 2)
        if len(parts) < 2:
            return sql

        before_body = parts[0] + '$$'
        body = parts[1]
        after_body = '$$' + parts[2] if len(parts) > 2 else ''

        # Variable declaration pattern: WORD TYPE; or WORD TYPE DEFAULT expr;
        var_pattern = re.compile(
            r'^\s*(\w+)\s+(SMALLINT|INTEGER|INT|BIGINT|FLOAT|DOUBLE|'
            r'NUMBER\s*(?:\([^)]*\))?|DECIMAL\s*(?:\([^)]*\))?|'
            r'VARCHAR\s*(?:\([^)]*\))?|CHAR\s*(?:\([^)]*\))?|'
            r'DATE|TIMESTAMP\s*(?:\([^)]*\))?|BOOLEAN|VARIANT)'
            r'(\s+DEFAULT\s+[^;]+)?;\s*$',
            re.IGNORECASE
        )

        body_lines = body.split('\n')

        # Scan ALL lines in the body for orphan variable declarations.
        # A line is a declaration if it matches var_pattern AND is not
        # inside a SQL statement (CREATE TABLE column defs, etc.).
        # Strategy: Track whether we're inside a CREATE TABLE or similar
        # multi-line statement using parenthesis depth.
        all_declarations = []
        lines_to_remove = set()
        paren_depth = 0
        found_first_begin = False

        for i, line in enumerate(body_lines):
            normalized = line.replace('\t', '    ')
            stripped = normalized.strip()

            # Track parenthesis depth to avoid matching column definitions
            paren_depth += stripped.count('(') - stripped.count(')')

            if not stripped or stripped.startswith('--'):
                continue

            # Track if we've passed the first BEGIN
            if re.match(r'^\s*BEGIN\b', stripped, re.IGNORECASE):
                found_first_begin = True
                continue

            # Only collect declarations when not inside parenthesized blocks
            # (to avoid matching column defs in CREATE TABLE)
            if paren_depth > 0:
                continue

            m = var_pattern.match(stripped)
            if m:
                var_name = m.group(1).upper()
                # Skip if var_name is a SQL keyword (false positive)
                sql_keywords = {'SELECT', 'INSERT', 'UPDATE', 'DELETE', 'CREATE',
                                'DROP', 'IF', 'BEGIN', 'END', 'MERGE', 'FOR',
                                'WHILE', 'CALL', 'LET', 'RETURN', 'WHEN', 'CASE',
                                'FROM', 'WHERE', 'AND', 'OR', 'SET', 'INTO',
                                'EXCEPTION', 'DECLARE', 'ELSE', 'THEN', 'ON',
                                'AS', 'JOIN', 'LEFT', 'RIGHT', 'INNER', 'OUTER',
                                'CROSS', 'UNION', 'GROUP', 'ORDER', 'HAVING',
                                'LIMIT', 'VALUES', 'NOT', 'NULL', 'LIKE',
                                'BETWEEN', 'EXISTS', 'IN', 'WITH', 'QUALIFY'}
                if var_name in sql_keywords:
                    continue
                existing_names = {d.split()[0].upper() for d in all_declarations}
                if var_name not in existing_names:
                    all_declarations.append(stripped)
                lines_to_remove.add(i)

        if not all_declarations and not self._out_params:
            return sql

        # Build DECLARE block
        declare_block = '\nDECLARE\n'
        for decl in all_declarations:
            declare_block += f'    {decl}\n'
        # Add OUT parameters as local variables
        existing_names = {d.split()[0].upper() for d in all_declarations}
        for param in self._out_params:
            if param['name'].upper() not in existing_names:
                declare_block += f"    {param['name']} {param['type']};\n"
        declare_block += 'BEGIN\n'

        # Remove collected declaration lines and replace first BEGIN
        new_body_lines = []
        first_begin_replaced = False
        for i, line in enumerate(body_lines):
            if i in lines_to_remove:
                continue
            if not first_begin_replaced and re.match(r'^\s*BEGIN\b', line, re.IGNORECASE):
                new_body_lines.append(declare_block)
                first_begin_replaced = True
                continue
            new_body_lines.append(line)

        new_body = '\n'.join(new_body_lines)
        sql = before_body + new_body + after_body
        self.rules_applied.append("declare_block: Generated DECLARE block for variable declarations")
        return sql

    def _demote_let_declarations(self, sql: str) -> str:
        """Remove ALL LET keywords in the procedure body.

        In Snowflake Scripting, LET declares a *new* variable inline.
        Our convention is to declare all variables in the DECLARE block
        and use plain assignment (var := value;) in the body.

        This method:
          1. Removes LET for variables already in the DECLARE block.
          2. For LET-introduced variables NOT in DECLARE (e.g. v_subq_N,
             v_exists_N from _convert_if_subquery), adds them to DECLARE
             and removes the LET prefix.

        Fixes reported issues:
          - "Declaration of out variable"
          - "LET not needed"
          - Incorrect colon placement tied to LET prefix
        """
        declare_match = re.search(
            r'\bDECLARE\b\s*\n([\s\S]*?)\nBEGIN\b',
            sql, re.IGNORECASE
        )
        if not declare_match:
            return sql

        # Collect all variable names already in DECLARE block
        declared_vars = set()
        for line in declare_match.group(1).split('\n'):
            m = re.match(r'\s*(\w+)\s+\w', line)
            if m:
                declared_vars.add(m.group(1).upper())

        # Phase 1: Remove LET for variables already in DECLARE
        original = sql
        for var_name in declared_vars:
            esc = re.escape(var_name)
            sql = re.sub(
                rf'^(\s*)LET\s+({esc})\s*:=',
                rf'\1\2 :=',
                sql,
                flags=re.IGNORECASE | re.MULTILINE
            )

        # Phase 2: Find ALL remaining LET usages in the body and promote
        # their variables to the DECLARE block
        remaining_lets = re.findall(
            r'^\s*LET\s+(\w+)\s*:=',
            sql,
            flags=re.IGNORECASE | re.MULTILINE
        )
        new_vars_to_declare = []
        for var_name in remaining_lets:
            if var_name.upper() not in declared_vars:
                new_vars_to_declare.append(var_name)
                declared_vars.add(var_name.upper())

        # Remove LET prefix from these remaining occurrences
        if remaining_lets:
            sql = re.sub(
                r'^(\s*)LET\s+(\w+)\s*:=',
                r'\1\2 :=',
                sql,
                flags=re.IGNORECASE | re.MULTILINE
            )

        # Add undeclared variables to the DECLARE block
        if new_vars_to_declare and declare_match:
            # Determine appropriate type based on variable name pattern
            new_decl_lines = []
            for var in new_vars_to_declare:
                vl = var.lower()
                if vl.startswith('v_subq') or vl.startswith('v_exists'):
                    new_decl_lines.append(f"    {var} INTEGER;")
                elif vl.startswith('signal_msg'):
                    new_decl_lines.append(f"    {var} VARCHAR(1000);")
                elif vl.startswith('signal_exc'):
                    new_decl_lines.append(f"    {var} EXCEPTION (-20001, 'Signal');")
                else:
                    new_decl_lines.append(f"    {var} VARCHAR(1000);")
            new_decl_text = '\n'.join(new_decl_lines)

            # Insert just before BEGIN
            begin_match = re.search(r'\n(BEGIN\b)', sql, re.IGNORECASE)
            if begin_match:
                insert_pos = begin_match.start()
                sql = sql[:insert_pos] + '\n' + new_decl_text + sql[insert_pos:]

        if sql != original:
            self.rules_applied.append(
                "demote_let_declarations: Removed LET keywords; promoted undeclared variables to DECLARE block"
            )
        return sql

    def _add_variable_colon_prefix(self, sql: str) -> str:
        """Add : prefix for variable references in SQL statements.

        In Snowflake SQL Scripting, procedure variables referenced inside
        SQL statements (INSERT VALUES, SELECT, WHERE, etc.) need the
        : prefix to distinguish them from column names.
        """
        if '$$' not in sql:
            return sql

        # Extract declared variable names from the DECLARE block
        var_names = set()
        declare_match = re.search(
            r'DECLARE\s*\n([\s\S]*?)\nBEGIN',
            sql, re.IGNORECASE
        )
        if declare_match:
            for line in declare_match.group(1).split('\n'):
                m = re.match(r'\s*(\w+)\s+(?:SMALLINT|INTEGER|INT|BIGINT|FLOAT|VARCHAR|CHAR|DATE|TIMESTAMP|BOOLEAN|NUMBER|DECIMAL)',
                             line, re.IGNORECASE)
                if m:
                    var_names.add(m.group(1).upper())

        # Also extract procedure parameter names from the signature
        # Format: CREATE OR REPLACE PROCEDURE name(param1 type, param2 type)
        param_match = re.search(
            r'CREATE\s+OR\s+REPLACE\s+PROCEDURE\s+[\w.\s]+?\(([\s\S]*?)\)\s*\n\s*RETURNS',
            sql, re.IGNORECASE
        )
        if param_match:
            for line in param_match.group(1).split('\n'):
                m = re.match(r'\s*,?\s*(?:IN\s+|OUT\s+|INOUT\s+)?(\w+)\s+\w', line, re.IGNORECASE)
                if m:
                    var_names.add(m.group(1).upper())

        if not var_names:
            return sql

        # --- Temporarily replace comments/strings with placeholders ---
        # This prevents false matches on SQL keywords (AND/OR/WHERE) inside comments,
        # which can cause patterns to span from comments into column lists.
        comment_placeholders = {}
        counter = [0]

        def _replace_block_comment(m):
            key = f'__BLOCK_CMT_{counter[0]}__'
            comment_placeholders[key] = m.group(0)
            counter[0] += 1
            return key

        def _replace_line_comment(m):
            key = f'__LINE_CMT_{counter[0]}__'
            comment_placeholders[key] = m.group(0)
            counter[0] += 1
            return key

        # Also protect string literals from pattern matching
        string_placeholders = {}

        def _replace_string_literal(m):
            key = f'__STR_{counter[0]}__'
            string_placeholders[key] = m.group(0)
            counter[0] += 1
            return key

        # Match BOTH comment types in a SINGLE PASS using regex alternation.
        # This prevents nesting issues:
        #   - `--/*...*/` : the `--` starts first → captured as line comment
        #   - `/* ... -- ... */` : the `/*` starts first → captured as block comment
        # Sequential replacement (either order) fails because one type can
        # contain syntax of the other, creating nested placeholders that
        # aren't restored correctly.
        def _replace_any_comment(m):
            if m.group(1) is not None:
                # Block comment matched (group 1)
                key = f'__BLOCK_CMT_{counter[0]}__'
                comment_placeholders[key] = m.group(1)
                counter[0] += 1
                return key
            else:
                # Line comment matched (group 2)
                key = f'__LINE_CMT_{counter[0]}__'
                comment_placeholders[key] = m.group(2)
                counter[0] += 1
                # If the char before the match is a word char, prepend a space
                # so \b word boundaries work (e.g., "enddate--Issue")
                start = m.start()
                if start > 0 and sql[start - 1].isalnum():
                    return ' ' + key
                return key
        # Block comment pattern first in alternation so `/*` at start of line
        # beats `--` inside a block comment, but position-based matching means
        # whichever starts first at a given position wins.
        sql = re.sub(r'(/\*[\s\S]*?\*/)|(--[^\n]*)', _replace_any_comment, sql)
        sql = re.sub(r"'[^']*'", _replace_string_literal, sql)

        # Add : prefix in SQL statement contexts
        # Process line by line to apply context-sensitive prefixing
        applied = False

        for var_name in var_names:
            esc = re.escape(var_name)

            # In VALUES clauses: prefix bare variable references
            pattern_values = rf'(VALUES\s*\([^)]*)\b(?<!:)({esc})\b'
            new_sql = re.sub(pattern_values, rf'\1:\2', sql, flags=re.IGNORECASE)
            if new_sql != sql:
                applied = True
                sql = new_sql

            # In COALESCE/IF referencing variables
            pattern_coalesce = rf'(COALESCE\s*\([^)]*)\b(?<!:)({esc})\b'
            new_sql = re.sub(pattern_coalesce, rf'\1:\2', sql, flags=re.IGNORECASE)
            if new_sql != sql:
                applied = True
                sql = new_sql

            # SELECT ... INTO :varname — prefix the target variable
            pattern_into = rf'(\bINTO\s+)(?<!:)({esc})\b'
            new_sql = re.sub(pattern_into, rf'\1:\2', sql, flags=re.IGNORECASE)
            if new_sql != sql:
                applied = True
                sql = new_sql

            # WHERE/AND/OR clauses: prefix bare variable references after operators
            # Match var when preceded by comparison operator, AND, OR, WHERE, or comma
            pattern_where = rf'((?:WHERE|AND|OR)\s+[^;]*?(?:=|<>|!=|>=|<=|>|<|,)\s*)(?<!:)\b({esc})\b'
            new_sql = re.sub(pattern_where, rf'\1:\2', sql, flags=re.IGNORECASE)
            if new_sql != sql:
                applied = True
                sql = new_sql

            # Also prefix var on the right side of = in WHERE/AND/OR (without preceding operator)
            pattern_where2 = rf'((?:WHERE|AND|OR)\s+\w+[\w.]*\s*=\s*)(?<!:)\b({esc})\b'
            new_sql = re.sub(pattern_where2, rf'\1:\2', sql, flags=re.IGNORECASE)
            if new_sql != sql:
                applied = True
                sql = new_sql

            # In INSERT ... VALUES (...) - prefix bare vars (not preceded by :, not a string literal context)
            # More aggressive: find VALUES (...) blocks and prefix any bare variable inside
            pattern_values_bare = rf'(VALUES\s*\([^)]*?(?:,|\()\s*)(?<!:)\b({esc})\b'
            new_sql = re.sub(pattern_values_bare, rf'\1:\2', sql, flags=re.IGNORECASE)
            if new_sql != sql:
                applied = True
                sql = new_sql

            # In standalone assignments: prefix after || concatenation
            pattern_concat = rf'(\|\|\s*)(?<!:)\b({esc})\b'
            new_sql = re.sub(pattern_concat, rf'\1:\2', sql, flags=re.IGNORECASE)
            if new_sql != sql:
                applied = True
                sql = new_sql

            # In IF conditions: prefix bare vars after comparison operators
            pattern_if = rf'(\bIF\s+[^;]*?(?:=|<>|!=|>=|<=|>|<)\s*)(?<!:)\b({esc})\b'
            new_sql = re.sub(pattern_if, rf'\1:\2', sql, flags=re.IGNORECASE)
            if new_sql != sql:
                applied = True
                sql = new_sql

            # In UPDATE SET value position: SET col = VAR → SET col = :VAR
            pattern_set = rf'(\bSET\s+\w+\s*=\s*)(?<!:)\b({esc})\b'
            new_sql = re.sub(pattern_set, rf'\1:\2', sql, flags=re.IGNORECASE)
            if new_sql != sql:
                applied = True
                sql = new_sql

            # After arithmetic operators (+, -, *, /): e.g. + m_seq AS SEQ_NUM
            pattern_arith = rf'([+\-*/]\s*)(?<!:)\b({esc})\b'
            new_sql = re.sub(pattern_arith, rf'\1:\2', sql, flags=re.IGNORECASE)
            if new_sql != sql:
                applied = True
                sql = new_sql

            # Variable before :: cast: STRT_DT_T::DATE → :STRT_DT_T::DATE
            # Only match when preceded by comma, space, or paren (SQL context)
            pattern_cast = rf'([,(\s])(?<!:)\b({esc})(::)'
            new_sql = re.sub(pattern_cast, rf'\1:\2\3', sql, flags=re.IGNORECASE)
            if new_sql != sql:
                applied = True
                sql = new_sql

            # In BETWEEN ... AND VAR: upper bound of BETWEEN clause
            # Use .+? to handle complex expressions like LAST_DAY(...)+1
            pattern_between = rf'(\bBETWEEN\s+.+?\s+AND\s+)(?<!:)\b({esc})\b'
            new_sql = re.sub(pattern_between, rf'\1:\2', sql, flags=re.IGNORECASE)
            if new_sql != sql:
                applied = True
                sql = new_sql

            # Function argument: variable after comma, before comma or close-paren
            # e.g., DATEADD(MONTH, -3, STARTDATE) → DATEADD(MONTH, -3, :STARTDATE)
            pattern_func_arg = rf'(,\s*)(?<!:)\b({esc})\b(?=\s*[,)])'
            new_sql = re.sub(pattern_func_arg, rf'\1:\2', sql, flags=re.IGNORECASE)
            if new_sql != sql:
                applied = True
                sql = new_sql

        if applied:
            self.rules_applied.append("variable_colon_prefix: Added : prefix for variable references in SQL contexts")

        # --- Restore string literals, then comments ---
        for key, value in string_placeholders.items():
            sql = sql.replace(key, value)
        for key, value in comment_placeholders.items():
            sql = sql.replace(key, value)

        # --- Post-fixes to remove incorrectly added colons ---

        # Post-fix A: remove : prefix from column definitions in CREATE TABLE.
        # Column definitions have the pattern: [,]<name> <type> where <type>
        # is a SQL data type keyword.
        type_keywords = (
            r'(?:SMALL)?INT(?:EGER)?|BIGINT|TINYINT|FLOAT|DOUBLE|REAL|'
            r'NUMBER|NUMERIC|DECIMAL|'
            r'VARCHAR|CHAR|NCHAR|NVARCHAR|STRING|TEXT|CLOB|'
            r'DATE|TIME(?:STAMP)?|BOOLEAN|BINARY|VARBINARY|VARIANT|OBJECT|ARRAY'
        )
        col_def_pattern = re.compile(
            rf'([,(]\s*):(\w+)(\s+(?:{type_keywords})\b)',
            re.IGNORECASE
        )
        sql = col_def_pattern.sub(r'\1\2\3', sql)

        # Post-fix B: remove : prefix from INSERT column lists.
        # INSERT INTO table (col1, :col2, col3) → INSERT INTO table (col1, col2, col3)
        # The column list is between INSERT INTO <table> ( ... ) before SELECT/VALUES.
        def _strip_insert_col_colons(m):
            prefix = m.group(1)
            col_list = m.group(2)
            suffix = m.group(3)
            cleaned = re.sub(r':(\w+)', r'\1', col_list)
            return prefix + cleaned + suffix

        insert_col_pattern = re.compile(
            r'(INSERT\s+INTO\s+[\w.]+\s*\()(.*?)(\)\s*(?:\n\s*)?(?:SELECT|VALUES))',
            re.IGNORECASE | re.DOTALL
        )
        sql = insert_col_pattern.sub(_strip_insert_col_colons, sql)

        # Post-fix C: remove : prefix from scripting contexts.
        # In Snowflake SQL Scripting, the : prefix is ONLY needed inside
        # embedded SQL statements (INSERT/SELECT/DELETE/UPDATE/MERGE).
        # Variables in scripting expressions — assignments (:=), IF/ELSEIF
        # conditions, WHILE conditions, RETURN — must NOT have the : prefix.
        var_pattern = '|'.join(re.escape(v) for v in var_names)
        if var_pattern:
            var_re = re.compile(rf':({var_pattern})\b', re.IGNORECASE)

            # C1: Assignments — strip : from right side of :=
            # Protect embedded SQL inside assignments (LET v := (SELECT ...))
            def _strip_assign_rhs(m):
                lhs = m.group(1)
                rhs = m.group(2)
                if re.search(r'\b(SELECT|INSERT|DELETE|UPDATE|MERGE)\b', rhs, re.IGNORECASE):
                    return m.group(0)
                return lhs + var_re.sub(r'\1', rhs)

            sql = re.sub(
                r'(\w+\s*:=\s*)([^;]*;)',
                _strip_assign_rhs,
                sql
            )

            # C2: IF/ELSEIF conditions — strip : between IF/ELSEIF and THEN
            # Protect IF EXISTS and IF with embedded SQL subquery
            def _strip_if_cond(m):
                text = m.group(0)
                if re.search(r'\bSELECT\b', text, re.IGNORECASE):
                    return text
                return var_re.sub(r'\1', text)

            sql = re.sub(
                r'\b(?:IF|ELSEIF)\b(?!\s+EXISTS)\s.*?\bTHEN\b',
                _strip_if_cond,
                sql, flags=re.IGNORECASE
            )

            # C3: WHILE conditions — strip : in WHILE ... DO/LOOP
            def _strip_while_cond(m):
                text = m.group(0)
                if re.search(r'\bSELECT\b', text, re.IGNORECASE):
                    return text
                return var_re.sub(r'\1', text)

            sql = re.sub(
                r'\bWHILE\b\s.*?(?:\bDO\b|\bLOOP\b|\n)',
                _strip_while_cond,
                sql, flags=re.IGNORECASE
            )

            # C4: RETURN statements — strip : from RETURN expression
            def _strip_return_expr(m):
                return var_re.sub(r'\1', m.group(0))

            sql = re.sub(
                r'\bRETURN\b\s[^;]*;',
                _strip_return_expr,
                sql, flags=re.IGNORECASE
            )

        return sql

    def _insert_exception_block(self, sql: str) -> str:
        """Insert the extracted exception block before the inner END.

        Uses a generic approach: finds the inner BEGIN...END block inside
        the procedure body and inserts EXCEPTION before its closing END.
        Works by counting BEGIN/END nesting depth.
        """
        if not hasattr(self, '_exception_block') or not self._exception_block:
            return sql

        # Strategy: find the inner BEGIN block (the second BEGIN after $$)
        # and insert EXCEPTION before its matching END.
        # Split at $$ to isolate the procedure body
        dollar_parts = sql.split('$$')
        if len(dollar_parts) < 2:
            self.warnings.append("Could not find procedure body for EXCEPTION block insertion")
            self._exception_block = None
            return sql

        body = dollar_parts[1]

        # Strip comments for structural analysis to avoid matching
        # BEGIN/END inside comments (e.g. "--Ver 1.5 Begin").
        # Replace comment content with spaces to preserve character positions.
        cleaned_body = re.sub(r'/\*[\s\S]*?\*/', lambda m: ' ' * len(m.group()), body)
        cleaned_body = re.sub(r'--[^\n]*', lambda m: ' ' * len(m.group()), cleaned_body)

        # Find all BEGIN and END positions using cleaned text
        # (positions map directly to original body since we preserved length)
        begin_positions = [(m.start(), m.end()) for m in re.finditer(r'\bBEGIN\b', cleaned_body, re.IGNORECASE)]
        end_positions = [(m.start(), m.end()) for m in re.finditer(r'\bEND\s*;', cleaned_body, re.IGNORECASE)]

        if len(begin_positions) < 2 or not end_positions:
            # No inner block found - insert before the first END
            if end_positions:
                insert_pos = end_positions[0][0]
                body = body[:insert_pos] + '\n' + self._exception_block + '\n    ' + body[insert_pos:]
                dollar_parts[1] = body
                sql = '$$'.join(dollar_parts)
                self.rules_applied.append("exception_block_insert: Inserted EXCEPTION block before END")
            else:
                self.warnings.append("Could not find END statement for EXCEPTION block insertion")
            self._exception_block = None
            return sql

        # Find the END that matches the second (inner) BEGIN
        # by tracking nesting depth from the inner BEGIN position
        inner_begin_end = begin_positions[1][1]
        depth = 1
        target_end_pos = None

        # Collect all BEGIN/END after the inner BEGIN, sorted by position
        events = []
        for pos_start, pos_end in begin_positions[2:]:
            if pos_start > inner_begin_end:
                events.append((pos_start, 'begin'))
        for pos_start, pos_end in end_positions:
            if pos_start > inner_begin_end:
                events.append((pos_start, 'end', pos_end))
        events.sort(key=lambda x: x[0])

        for event in events:
            if event[1] == 'begin':
                depth += 1
            elif event[1] == 'end':
                depth -= 1
                if depth == 0:
                    target_end_pos = event[0]
                    break

        if target_end_pos is not None:
            new_body = body[:target_end_pos] + '\n' + self._exception_block + '\n    ' + body[target_end_pos:]

            # Safety net: verify BEGIN/END balance after insertion.
            # If unbalanced, fall back to inserting before the LAST END;
            # in the procedure body, which is always the outermost END.
            cleaned_check = re.sub(r'/\*[\s\S]*?\*/', '', new_body)
            cleaned_check = re.sub(r'--[^\n]*', '', cleaned_check)
            begin_cnt = len(re.findall(r'\bBEGIN\b', cleaned_check, re.IGNORECASE))
            end_cnt = len(re.findall(r'\bEND\s*;', cleaned_check, re.IGNORECASE))

            if begin_cnt != end_cnt:
                # Fallback: insert before the LAST END; in the original body
                self.warnings.append(
                    f"Exception block insertion caused BEGIN/END imbalance "
                    f"({begin_cnt} vs {end_cnt}), falling back to last END"
                )
                last_end = list(re.finditer(r'\bEND\s*;', body, re.IGNORECASE))
                if last_end:
                    fallback_pos = last_end[-1].start()
                    new_body = body[:fallback_pos] + '\n' + self._exception_block + '\n    ' + body[fallback_pos:]
                else:
                    new_body = body  # no END found at all; don't insert

            dollar_parts[1] = new_body
            sql = '$$'.join(dollar_parts)
            self.rules_applied.append("exception_block_insert: Inserted EXCEPTION block before inner END")
        else:
            self.warnings.append("Could not find matching END for inner BEGIN block")

        self._exception_block = None
        return sql

    def _strip_dead_teradata_code(self, sql: str) -> str:
        """Remove dead Teradata-specific code that has no Snowflake equivalent.

        Removes:
        - ERROR_CONDITION CONDITION; (Teradata condition declaration)
        - -- ET; comments (Teradata end-transaction markers)
        - ALL keyword from DELETE statements (Teradata-specific)
        """
        original = sql

        # Remove ERROR_CONDITION CONDITION; (dead Teradata code)
        sql = re.sub(
            r'^\s*ERROR_CONDITION\s+CONDITION\s*;\s*$',
            '', sql, flags=re.MULTILINE | re.IGNORECASE
        )

        # Remove -- ET; comments (Teradata end-transaction marker)
        sql = re.sub(
            r'^\s*--\s*ET\s*;\s*$',
            '', sql, flags=re.MULTILINE | re.IGNORECASE
        )

        # Remove ALL keyword from DELETE statements
        # Teradata: DELETE FROM table ALL; → Snowflake: DELETE FROM table;
        sql = re.sub(
            r'(DELETE\s+FROM\s+[\w.]+)\s+ALL\s*;',
            r'\1;',
            sql, flags=re.IGNORECASE
        )

        # Convert CAST(x AS DATE FORMAT 'fmt') inside dynamic SQL strings
        # where quotes are doubled: CAST(x AS DATE FORMAT ''fmt'') → TO_DATE(x, ''fmt'')
        sql = re.sub(
            r"CAST\s*\(\s*(\w+)\s+AS\s+DATE\s+FORMAT\s+''([^']+)''\s*\)",
            r"TO_DATE(\1, ''\2'')",
            sql, flags=re.IGNORECASE
        )

        if sql != original:
            self.rules_applied.append(
                "strip_dead_teradata: Removed dead Teradata code (ERROR_CONDITION, ET, DELETE ALL, DATE FORMAT in dynamic SQL)"
            )

        return sql

    def _flatten_nested_begin_end(self, sql: str) -> str:
        """Flatten redundant nested BEGIN/END blocks and relocate post-exception code.

        Teradata labeled blocks (MAIN: BEGIN ... INNER: BEGIN ... END INNER;
        END MAIN;) become redundant double BEGIN/END after label removal.
        This method:
        1. Detects the double BEGIN pattern (only whitespace between them)
        2. Moves any code between inner END and outer END to before EXCEPTION
        3. Removes the redundant inner BEGIN and outer END
        """
        if '$$' not in sql:
            return sql

        dollar_parts = sql.split('$$')
        if len(dollar_parts) < 3:
            return sql

        body = dollar_parts[1]

        # Strip comments for structural analysis
        # IMPORTANT: strip /* */ FIRST, then -- comments.
        # Reversing this order causes -- to eat */ closers on lines like
        # "---...--- */" inside block comments, making the /* */ strip
        # consume DECLARE/BEGIN blocks.
        cleaned = re.sub(r'/\*[\s\S]*?\*/', '', body)
        cleaned = re.sub(r'--[^\n]*', '', cleaned)

        # Find BEGINs in cleaned body
        begin_matches = list(re.finditer(r'\bBEGIN\b', cleaned, re.IGNORECASE))
        if len(begin_matches) < 2:
            return sql

        # Check if content between first two BEGINs is only whitespace
        between = cleaned[begin_matches[0].end():begin_matches[1].start()].strip()
        if between:
            return sql  # Real code between BEGINs, don't flatten

        # Work with the real body — find bare END; positions
        # (not END IF, END LOOP, END FOR, END WHILE)
        bare_end_re = re.compile(
            r'\bEND\b(?!\s+(?:IF|LOOP|FOR|WHILE)\b)\s*;',
            re.IGNORECASE
        )
        bare_ends = list(bare_end_re.finditer(body))
        if len(bare_ends) < 2:
            return sql

        inner_end = bare_ends[-2]
        outer_end = bare_ends[-1]

        # Get code between inner END and outer END
        between_ends = body[inner_end.end():outer_end.start()].strip()

        # Find the EXCEPTION keyword position
        exception_match = re.search(
            r'^\s*EXCEPTION\b', body, re.IGNORECASE | re.MULTILINE
        )

        # Reconstruct the body
        if exception_match and between_ends:
            # Move between-ends code to before EXCEPTION,
            # remove inner END, keep outer END
            before_exception = body[:exception_match.start()]
            exception_to_inner_end = body[exception_match.start():inner_end.start()]
            after_outer = body[outer_end.end():]

            body = (
                before_exception
                + between_ends + '\n\n'
                + exception_to_inner_end.rstrip() + '\n'
                + body[outer_end.start():outer_end.end()]
                + after_outer
            )
        elif between_ends:
            # No EXCEPTION block — remove outer END, keep code before inner END
            after_outer = body[outer_end.end():]
            body = (
                body[:inner_end.end()] + '\n'
                + between_ends + '\n'
                + after_outer
            )
        else:
            # No code between ends — just remove inner END
            body = body[:inner_end.start()] + body[inner_end.end():]

        # Now remove the second BEGIN line
        actual_begins = list(re.finditer(r'\bBEGIN\b', body, re.IGNORECASE))
        if len(actual_begins) >= 2:
            second = actual_begins[1]
            # Find the full line containing the second BEGIN
            line_start = body.rfind('\n', 0, second.start())
            line_end = body.find('\n', second.end())
            if line_start == -1:
                line_start = 0
            if line_end == -1:
                line_end = len(body)

            begin_line = body[line_start:line_end].strip()
            if begin_line.upper() == 'BEGIN':
                body = body[:line_start] + body[line_end:]

        dollar_parts[1] = body
        sql = '$$'.join(dollar_parts)
        self.rules_applied.append(
            "flatten_nested_begin_end: Flattened redundant nested BEGIN/END blocks"
        )
        return sql

    def _strip_export_footer(self, sql: str) -> str:
        """Strip Teradata export metadata/footer from inside procedure body.

        Removes content after the last END; inside the $$ body —
        typically export metadata like ======, ---Show procedure, etc.
        """
        if '$$' not in sql:
            return sql

        dollar_parts = sql.split('$$')
        if len(dollar_parts) < 3:
            return sql

        body = dollar_parts[1]

        # Find the last bare END; in the body
        bare_end_re = re.compile(
            r'\bEND\b(?!\s+(?:IF|LOOP|FOR|WHILE)\b)\s*;',
            re.IGNORECASE
        )
        bare_ends = list(bare_end_re.finditer(body))
        if not bare_ends:
            return sql

        last_end = bare_ends[-1]
        after_end = body[last_end.end():]

        # If there's non-whitespace content after the last END;,
        # it's export metadata that should be removed
        if after_end.strip():
            body = body[:last_end.end()] + '\n'
            dollar_parts[1] = body
            sql = '$$'.join(dollar_parts)
            self.rules_applied.append(
                "strip_export_footer: Removed Teradata export metadata from output"
            )

        return sql

    def _convert_cursor_operations(self, sql: str) -> str:
        """Convert Teradata cursor operations to Snowflake SQL Scripting syntax.

        Handles:
        1. DECLARE cursor_name CURSOR FOR SELECT ... → LET cursor_name CURSOR FOR SELECT ...
           (Snowflake uses DECLARE c1 CURSOR FOR in DECLARE block, or LET in body)
        2. OPEN cursor_name → OPEN cursor_name (same syntax)
        3. FETCH cursor_name INTO var1, var2 → FETCH cursor_name INTO var1, var2 (same syntax)
        4. CLOSE cursor_name → CLOSE cursor_name (same syntax)
        5. FOR loop_var AS cursor_name CURSOR FOR SELECT ...
           → FOR loop_var IN (SELECT ...) DO ... END FOR;
        6. Teradata-style cursor WHILE loop with SQLCODE check
        """
        original = sql

        # 1. Convert DECLARE CURSOR outside of DECLARE block
        # Teradata: DECLARE cursor_name CURSOR FOR SELECT ...
        # In Snowflake procedure body (after BEGIN), this becomes:
        # LET cursor_name CURSOR FOR (SELECT ...);
        # But if inside DECLARE block, keep as: cursor_name CURSOR FOR (SELECT ...);
        # The _generate_declare_block method handles placement.

        # Convert FOR record_name AS cursor_name CURSOR FOR SELECT ...
        # Teradata:
        #   FOR record AS cursor1 CURSOR FOR SELECT col FROM table
        #   DO
        #     ... record.col ...
        #   END FOR;
        #
        # Snowflake:
        #   FOR record IN (SELECT col FROM table)
        #   DO
        #     ... record.col ...
        #   END FOR;
        sql = re.sub(
            r'\bFOR\s+(\w+)\s+AS\s+\w+\s+CURSOR\s+FOR\s+',
            r'FOR \1 IN (',
            sql, flags=re.IGNORECASE
        )

        # If we converted a FOR ... IN ( SELECT, we need to close with ) DO
        # Find "FOR var IN (SELECT ... DO" patterns and add closing paren
        # This needs care — the SELECT can be multi-line with WHERE, JOIN, etc.
        # Pattern: FOR var IN (SELECT ... <newline>DO → FOR var IN (SELECT ...)<newline>DO
        lines = sql.split('\n')
        in_for_cursor = False
        paren_depth = 0
        result_lines = []

        for i, line in enumerate(lines):
            stripped = line.strip().upper()

            if re.match(r'\s*FOR\s+\w+\s+IN\s+\(', line, re.IGNORECASE):
                in_for_cursor = True
                paren_depth = line.count('(') - line.count(')')

            elif in_for_cursor:
                if stripped.startswith('DO') and paren_depth <= 1:
                    # Close the cursor SELECT before DO
                    if result_lines and paren_depth == 1:
                        # Add closing paren to previous line
                        result_lines[-1] = result_lines[-1].rstrip() + ')'
                        paren_depth = 0
                    in_for_cursor = False
                else:
                    paren_depth += line.count('(') - line.count(')')

            result_lines.append(line)

        sql = '\n'.join(result_lines)

        # 2. Convert standalone DECLARE CURSOR in procedure body to Snowflake syntax
        # Teradata: DECLARE c1 CURSOR FOR SELECT ...;
        # Snowflake (in DECLARE block): c1 CURSOR FOR (SELECT ...);
        # The DECLARE keyword is handled by declare_simple/declare_default rules
        # but CURSOR FOR needs the SELECT wrapped in parens
        sql = re.sub(
            r'(\w+\s+CURSOR\s+FOR)\s+(SELECT\b)',
            r'\1 (\2',
            sql, flags=re.IGNORECASE
        )

        # Close cursor SELECT paren if it ends with ;
        # Find "CURSOR FOR (SELECT ...;" and ensure closing paren
        # Use line-by-line approach to handle multi-line SELECTs
        lines = sql.split('\n')
        in_cursor_decl = False
        cursor_start = -1
        result_lines = []

        for i, line in enumerate(lines):
            if re.search(r'CURSOR\s+FOR\s+\(SELECT', line, re.IGNORECASE):
                in_cursor_decl = True
                cursor_start = i
                if line.rstrip().endswith(';'):
                    # Single-line cursor — add closing paren
                    line = line.rstrip().rstrip(';') + ');'
                    in_cursor_decl = False
            elif in_cursor_decl:
                if line.rstrip().endswith(';'):
                    line = line.rstrip().rstrip(';') + ');'
                    in_cursor_decl = False

            result_lines.append(line)

        sql = '\n'.join(result_lines)

        # 3. Convert Teradata WHILE loop with SQLCODE cursor pattern
        # Teradata:
        #   OPEN c1;
        #   FETCH c1 INTO :var1, :var2;
        #   WHILE (SQLCODE = 0) DO
        #     ... process ...
        #     FETCH c1 INTO :var1, :var2;
        #   END WHILE;
        #   CLOSE c1;
        #
        # Snowflake: Same syntax works! OPEN, FETCH, CLOSE, WHILE SQLCODE=0
        # are all valid in Snowflake SQL Scripting. No conversion needed.
        # Just ensure SQLCODE checks use = not <>

        if sql != original:
            self.rules_applied.append(
                "cursor_operations: Converted Teradata cursor syntax to Snowflake"
            )

        return sql

    def _convert_execute_immediate(self, sql: str) -> str:
        """Convert Teradata dynamic SQL patterns to Snowflake EXECUTE IMMEDIATE.

        Handles:
        1. CALL DBC.SYSEXECSQL(:var) → EXECUTE IMMEDIATE :var
        2. CALL DBC.SYSEXECSQL('multi-line SQL') → EXECUTE IMMEDIATE 'SQL'
        3. CALL DBC.SYSEXECSQL(expr || var) → EXECUTE IMMEDIATE expr || :var
        """
        if 'DBC.SYSEXECSQL' not in sql.upper():
            return sql

        original = sql

        # Strategy: find each CALL DBC.SYSEXECSQL( and use paren-depth tracking
        # to find the matching ), since the argument can contain nested parens
        pattern = re.compile(r'\bCALL\s+DBC\.SYSEXECSQL\s*\(', re.IGNORECASE)
        result = []
        pos = 0

        for match in pattern.finditer(sql):
            result.append(sql[pos:match.start()])

            # Find matching closing paren using depth tracking
            start = match.end()
            depth = 1
            i = start
            in_string = False

            while i < len(sql) and depth > 0:
                ch = sql[i]
                if ch == "'" and not in_string:
                    in_string = True
                elif ch == "'" and in_string:
                    # Check for escaped quote ''
                    if i + 1 < len(sql) and sql[i + 1] == "'":
                        i += 1  # Skip escaped quote
                    else:
                        in_string = False
                elif not in_string:
                    if ch == '(':
                        depth += 1
                    elif ch == ')':
                        depth -= 1
                i += 1

            if depth == 0:
                # Extract the argument (everything between SYSEXECSQL( and ))
                arg = sql[start:i - 1].strip()

                # Skip the trailing ; if present
                end_pos = i
                remaining = sql[i:i + 5].lstrip()
                if remaining.startswith(';'):
                    end_pos = i + sql[i:].index(';') + 1

                # Convert to EXECUTE IMMEDIATE
                # If arg is a simple variable, add colon prefix
                if re.match(r'^:?\w+$', arg):
                    if not arg.startswith(':'):
                        arg = ':' + arg
                    result.append(f'EXECUTE IMMEDIATE {arg};')
                else:
                    result.append(f'EXECUTE IMMEDIATE {arg};')

                pos = end_pos
            else:
                # Unbalanced parens — leave as-is
                result.append(sql[match.start():match.end()])
                pos = match.end()

        result.append(sql[pos:])
        sql = ''.join(result)

        if sql != original:
            self.rules_applied.append(
                "execute_immediate: Converted CALL DBC.SYSEXECSQL to EXECUTE IMMEDIATE"
            )

        return sql

    def _convert_signal_to_raise(self, sql: str) -> str:
        """Convert Teradata SIGNAL to Snowflake RAISE.

        Handles:
        1. SIGNAL condition_name → RAISE using custom exception
        2. SIGNAL condition SET MESSAGE_TEXT = 'msg'
           → RAISE USING MESSAGE = 'msg' (via EXCEPTION ... WHEN)
        """
        original = sql

        # Convert SIGNAL with SET MESSAGE_TEXT
        # Teradata: SIGNAL condition_name SET MESSAGE_TEXT = 'error message';
        # Snowflake: No direct equivalent. Use RAISE with custom exception message.
        # We'll convert to: RAISE EXCEPTION USING MESSAGE = 'error message';
        # Note: In Snowflake, RAISE without args re-raises current exception.
        # For custom exceptions, use: LET exc EXCEPTION (-20001, 'message');
        # and then RAISE exc;
        sql = re.sub(
            r"\bSIGNAL\s+(\w+)\s+SET\s+MESSAGE_TEXT\s*=\s*('[^']*')\s*;",
            lambda m: f"-- Original: SIGNAL {m.group(1)} SET MESSAGE_TEXT = {m.group(2)}\n"
                       f"    LET signal_msg VARCHAR := {m.group(2)};\n"
                       f"    LET signal_exc EXCEPTION (-20001, {m.group(2)});\n"
                       f"    RAISE signal_exc;",
            sql, flags=re.IGNORECASE
        )

        # Convert simple SIGNAL condition_name (no SET MESSAGE_TEXT)
        # Teradata: SIGNAL ERROR_CONDITION;
        # Snowflake: RAISE; (re-raise) or custom exception
        sql = re.sub(
            r'\bSIGNAL\s+(\w+)\s*;',
            lambda m: f"-- Original: SIGNAL {m.group(1)}\n"
                       f"    RAISE;",
            sql, flags=re.IGNORECASE
        )

        if sql != original:
            self.rules_applied.append(
                "signal_to_raise: Converted SIGNAL to Snowflake RAISE/EXCEPTION"
            )

        return sql

    def _handle_multiple_out_params(self, sql: str) -> str:
        """Handle procedures with multiple OUT parameters.

        Teradata allows multiple OUT params. Snowflake procedures can only
        have a single RETURNS. For multiple OUT params, we:
        1. Remove all OUT/INOUT params from the signature
        2. Set RETURNS VARIANT (to return an object with all values)
        3. Add all OUT vars to DECLARE block
        4. Build RETURN OBJECT_CONSTRUCT('param1', :param1, ...) at the end

        Only activates when 2+ OUT params are detected.
        """
        if not self._out_params or len(self._out_params) < 2:
            return sql

        # Build RETURNS VARIANT instead of the single-type RETURNS
        sql = re.sub(
            r'RETURNS\s+\w+(?:\([^)]*\))?',
            'RETURNS VARIANT',
            sql, flags=re.IGNORECASE, count=1
        )

        # Build OBJECT_CONSTRUCT for the RETURN statement
        obj_parts = []
        for param in self._out_params:
            obj_parts.append(f"'{param['name']}', :{param['name']}")
        obj_construct = f"OBJECT_CONSTRUCT({', '.join(obj_parts)})"

        # Replace existing RETURN statement if any, or the logic
        # in _add_return_statement will add one
        if re.search(r'^\s*RETURN\b', sql, re.IGNORECASE | re.MULTILINE):
            sql = re.sub(
                r'(^\s*RETURN\s+)[^;]+;',
                rf'\g<1>{obj_construct};',
                sql, flags=re.IGNORECASE | re.MULTILINE
            )
        else:
            # Store for _add_return_statement to use
            self._multi_out_return_expr = obj_construct

        self.rules_applied.append(
            f"multiple_out_params: Converted {len(self._out_params)} OUT params to RETURNS VARIANT + OBJECT_CONSTRUCT"
        )

        return sql

    def _add_procedure_wrapper(self, sql: str) -> str:
        """Add Snowflake procedure wrapper and closing delimiter.

        Handles three cases:
        1. $$ already present (from sql_security_creator/owner rules) → just
           ensure closing $$; exists.
        2. Has EXECUTE AS but no $$ → add AS/$$/BEGIN and closing $$.
        3. No $$ AND no EXECUTE AS (input lacked SQL SECURITY keyword) →
           inject full RETURNS/LANGUAGE SQL/EXECUTE AS CALLER/AS/$$ after
           the parameter list, and add closing $$ after the LAST END;.
        """
        # Check if this looks like a procedure
        if not re.search(r'CREATE\s+OR\s+REPLACE\s+PROCEDURE', sql, re.IGNORECASE):
            return sql

        # Case 1: $$ already present
        if '$$' in sql:
            # Just ensure closing $$; exists
            if not re.search(r'\$\$\s*;?\s*$', sql):
                sql = sql.rstrip() + '\n$$;\n'
            return sql

        # Case 2: Has EXECUTE AS but no $$
        if re.search(r'EXECUTE\s+AS\s+(?:OWNER|CALLER)', sql, re.IGNORECASE):
            sql = re.sub(
                r'(EXECUTE\s+AS\s+(?:OWNER|CALLER))\s*\n',
                r'\1\nAS\n$$\n',
                sql,
                count=1,
                flags=re.IGNORECASE
            )
        else:
            # Case 3: No SQL SECURITY / EXECUTE AS at all.
            # Find the closing ) of the parameter list by counting
            # nested parens (handles types like VARCHAR(100)).
            proc_match = re.search(
                r'CREATE\s+OR\s+REPLACE\s+PROCEDURE\s+[\w.\s]+?\(',
                sql, re.IGNORECASE
            )
            insert_pos = None
            if proc_match:
                depth = 1
                i = proc_match.end()
                while i < len(sql) and depth > 0:
                    if sql[i] == '(':
                        depth += 1
                    elif sql[i] == ')':
                        depth -= 1
                    i += 1
                if depth == 0:
                    insert_pos = i  # right after the matching )
            if insert_pos:
                wrapper = (
                    '\nRETURNS VARCHAR(1000)'
                    '\nLANGUAGE SQL'
                    '\nEXECUTE AS CALLER'
                    '\nAS'
                    '\n$$'
                )
                sql = sql[:insert_pos] + wrapper + sql[insert_pos:]
                self.rules_applied.append(
                    "add_procedure_wrapper: Injected missing "
                    "RETURNS/LANGUAGE SQL/AS $$ (no SQL SECURITY in input)"
                )

        # Add closing $$; after the LAST bare END; only (not every END;).
        # Use a reverse search to find the last END; that isn't END IF/LOOP.
        bare_end_re = re.compile(
            r'\bEND\b(?!\s+(?:IF|LOOP|FOR|WHILE|CASE)\b)\s*;',
            re.IGNORECASE
        )
        bare_ends = list(bare_end_re.finditer(sql))
        if bare_ends and '$$;' not in sql:
            last_end = bare_ends[-1]
            sql = sql[:last_end.end()] + '\n$$;' + sql[last_end.end():]

        return sql

    def _add_return_statement(self, sql: str) -> str:
        """Add RETURN statement for procedures that had OUT parameters.

        Ensures RETURN appears:
        1. Before the EXCEPTION block (success path)
        2. Inside the EXCEPTION handler (error path, after logging)

        Discovers the return variable by examining the DECLARE block for
        variables that are assigned in the procedure body via LET, picking
        the last one assigned before the final END as the most likely
        return candidate. Falls back to a generic 'Success' return.
        """
        if '$$' not in sql:
            return sql

        # Check if procedure has RETURNS clause
        if not re.search(r'\bRETURNS\b', sql, re.IGNORECASE):
            return sql

        # Discover the return variable
        return_var = None

        # 1. First choice: use the tracked OUT parameter name
        if self._out_params:
            return_var = self._out_params[0]['name']

        # 2. Fallback: discover from DECLARE block and LET assignments
        if not return_var:
            declared_vars = []
            declare_match = re.search(
                r'DECLARE\s*\n([\s\S]*?)\nBEGIN',
                sql, re.IGNORECASE
            )
            if declare_match:
                for line in declare_match.group(1).split('\n'):
                    m = re.match(r'\s*(\w+)\s+(?:SMALLINT|INTEGER|INT|BIGINT|FLOAT|VARCHAR|CHAR|DATE|TIMESTAMP|BOOLEAN|NUMBER|DECIMAL)',
                                 line, re.IGNORECASE)
                    if m:
                        declared_vars.append(m.group(1))

            if declared_vars:
                let_assignments = re.findall(
                    r'LET\s+(\w+)\s*:=',
                    sql, re.IGNORECASE
                )
                declared_set = {v.upper() for v in declared_vars}
                assigned_declared = [v for v in let_assignments if v.upper() in declared_set]
                if assigned_declared:
                    return_var = assigned_declared[-1]

        if not return_var:
            return_expr = "'Procedure completed successfully'"
        else:
            return_expr = f':{return_var}'

        # Check if there's already a RETURN on the success path (before EXCEPTION)
        has_return = re.search(r'^\s*RETURN\b', sql, re.IGNORECASE | re.MULTILINE)
        exception_match = re.search(r'^\s*EXCEPTION\b', sql, re.IGNORECASE | re.MULTILINE)

        if has_return and exception_match:
            # RETURN exists — check if it's BEFORE the EXCEPTION block
            return_pos = has_return.start()
            exception_pos = exception_match.start()
            if return_pos < exception_pos:
                # Already has RETURN before EXCEPTION — ensure RETURN in exception handler too
                sql = self._ensure_return_in_exception_handler(sql, return_expr)
                return sql
            # else: RETURN only exists after EXCEPTION (inside handler) — need to add one before

        if not has_return or (exception_match and has_return and has_return.start() > exception_match.start()):
            # Need to add RETURN before EXCEPTION (or before final END if no EXCEPTION)
            if exception_match:
                # Insert RETURN right before the EXCEPTION keyword
                indent = '    '
                return_line = f'{indent}RETURN {return_expr};\n\n'
                sql = sql[:exception_match.start()] + return_line + sql[exception_match.start():]
                self.rules_applied.append(f"add_return: Added RETURN {return_expr} before EXCEPTION")
            else:
                # No EXCEPTION block — add RETURN before the final END; $$;
                pattern = re.compile(
                    r'(\n)([ \t]*END\s*;?\s*"?\s*)\n(\$\$)',
                    re.IGNORECASE
                )
                matches = list(pattern.finditer(sql))
                if matches:
                    match = matches[-1]
                    end_text = match.group(2).rstrip().rstrip('"').rstrip()
                    if not end_text.endswith(';'):
                        end_text += ';'
                    replacement = f"{match.group(1)}    RETURN {return_expr};\n{end_text}\n{match.group(3)}"
                    sql = sql[:match.start()] + replacement + sql[match.end():]
                    self.rules_applied.append(f"add_return: Added RETURN {return_expr} statement")

        # Ensure RETURN also exists inside the EXCEPTION handler
        sql = self._ensure_return_in_exception_handler(sql, return_expr)

        return sql

    def _ensure_return_in_exception_handler(self, sql: str, return_expr: str) -> str:
        """Ensure there's a RETURN statement inside the EXCEPTION handler.

        If the exception handler has RAISE followed by RETURN, that's fine
        (RETURN is unreachable but harmless). If no RETURN in handler at all,
        add one after the last statement before END.
        """
        # Find the EXCEPTION block
        exception_match = re.search(r'^\s*EXCEPTION\b', sql, re.IGNORECASE | re.MULTILINE)
        if not exception_match:
            return sql

        # Get the text after EXCEPTION up to the final END
        after_exception = sql[exception_match.start():]

        # Check if there's already a RETURN in the exception handler
        if re.search(r'^\s*RETURN\b', after_exception, re.IGNORECASE | re.MULTILINE):
            return sql

        # No RETURN in exception handler — add one before the final END;
        bare_end_re = re.compile(
            r'\bEND\b(?!\s+(?:IF|LOOP|FOR|WHILE)\b)\s*;',
            re.IGNORECASE
        )
        ends_in_handler = list(bare_end_re.finditer(after_exception))
        if ends_in_handler:
            last_end = ends_in_handler[-1]
            insert_pos = exception_match.start() + last_end.start()
            sql = sql[:insert_pos] + f'    RETURN {return_expr};\n' + sql[insert_pos:]
            self.rules_applied.append(
                f"add_return_exception: Added RETURN {return_expr} in EXCEPTION handler"
            )

        return sql

    def _validate_dateadd_args(self, sql: str) -> str:
        """Validate and fix DATEADD calls to ensure exactly 3 arguments.

        After ADD_MONTHS and interval conversions, some DATEADD calls may
        end up with malformed arguments like:
            DATEADD(MONTH, (NUMCYC1 - USEDCYC1, DP.MonthBegin) + 1)
        which should be:
            DATEADD(MONTH, (NUMCYC1 - USEDCYC1) + 1, DP.MonthBegin)

        This is caused by Teradata's ADD_MONTHS(date_expr, offset) where
        date_expr itself contains a comma-separated tuple from an interval
        calculation.
        """
        dateadd_pattern = re.compile(r'\bDATEADD\s*\(', re.IGNORECASE)
        offset = 0

        while True:
            match = dateadd_pattern.search(sql, offset)
            if not match:
                break

            func_start = match.start()
            paren_start = match.end() - 1  # The opening (

            # Extract balanced content
            depth = 0
            pos = paren_start
            while pos < len(sql):
                if sql[pos] == '(':
                    depth += 1
                elif sql[pos] == ')':
                    depth -= 1
                    if depth == 0:
                        break
                pos += 1

            if depth != 0:
                offset = match.end()
                continue

            inner = sql[paren_start + 1:pos].strip()
            func_end = pos + 1  # After closing )

            # Split by top-level commas (respecting parenthesis depth)
            args = []
            current_arg = ""
            arg_depth = 0
            for ch in inner:
                if ch == '(':
                    arg_depth += 1
                    current_arg += ch
                elif ch == ')':
                    arg_depth -= 1
                    current_arg += ch
                elif ch == ',' and arg_depth == 0:
                    args.append(current_arg.strip())
                    current_arg = ""
                else:
                    current_arg += ch
            if current_arg.strip():
                args.append(current_arg.strip())

            if len(args) == 2:
                # Only 2 args found — the second arg likely contains
                # a date expression merged with the offset.
                # Pattern: DATEADD(MONTH, (expr, date_expr) + offset)
                # Try to split the second arg at the last comma inside parens
                part = args[1]
                # Look for pattern like (A - B, date_expr) + offset
                tuple_match = re.match(
                    r'\(([^,]+),\s*([^)]+)\)\s*(.*)',
                    part
                )
                if tuple_match:
                    offset_expr = tuple_match.group(1).strip()
                    date_expr = tuple_match.group(2).strip()
                    trailing = tuple_match.group(3).strip()
                    # trailing might be "+ 1" etc.
                    if trailing:
                        offset_expr = f"({offset_expr}){trailing}"
                    replacement = f"DATEADD({args[0]}, {offset_expr}, {date_expr})"
                    sql = sql[:func_start] + replacement + sql[func_end:]
                    self.rules_applied.append("validate_dateadd: Fixed malformed DATEADD arguments")
                    # Don't advance offset — re-scan from same position
                    continue

            offset = func_end

        return sql

    def _convert_trim_functions(self, sql: str) -> str:
        """Convert TRIM(LEADING/TRAILING/BOTH 'char' FROM expr) to LTRIM/RTRIM/TRIM.

        Uses parenthesis depth tracking to correctly handle nested
        expressions like TRIM(LEADING '0' FROM CAST(x AS VARCHAR(10))).
        """
        trim_map = {
            'LEADING': 'LTRIM',
            'TRAILING': 'RTRIM',
            'BOTH': 'TRIM',
        }

        for direction, func in trim_map.items():
            pattern = re.compile(
                rf"TRIM\s*\(\s*{direction}\s+'([^']+)'\s+FROM\s+",
                re.IGNORECASE
            )

            while True:
                match = pattern.search(sql)
                if not match:
                    break

                char = match.group(1)
                start_pos = match.end()  # Right after 'FROM '

                # Find balanced closing ) by counting depth
                depth = 1  # Inside the outer TRIM(
                pos = start_pos
                while pos < len(sql) and depth > 0:
                    if sql[pos] == '(':
                        depth += 1
                    elif sql[pos] == ')':
                        depth -= 1
                    pos += 1

                # pos is now right after the closing )
                expr = sql[start_pos:pos - 1].strip()
                replacement = f"{func}({expr}, '{char}')"
                sql = sql[:match.start()] + replacement + sql[pos:]
                self.rules_applied.append(f"trim_{direction.lower()}: TRIM {direction} → {func}")

        return sql

    def _cleanup(self, sql: str) -> str:
        """Final cleanup of converted SQL."""
        # Fix 1: Remove duplicate $$; delimiter
        # After LLM review or wrapper insertion, two consecutive $$; can appear
        original = sql
        sql = re.sub(r'(\$\$\s*;\s*\n)\s*\$\$\s*;', r'\1', sql)
        if sql != original:
            self.rules_applied.append(
                "fix_duplicate_dollar: Removed duplicate $$; delimiter"
            )

        # Remove redundant variable assignments where a var is set then
        # immediately overwritten (e.g., X := ' '; X := SQLERRM;)
        sql = re.sub(
            r"((?:LET\s+)?(\w+)\s*:=\s*'[^']*'\s*;\s*\n\s*)((?:LET\s+)?\2\s*:=)",
            r'\3',
            sql,
            flags=re.IGNORECASE
        )

        # Fix spurious spaces in dotted names from quote preprocessing
        # e.g. "SCHEMA. PROC_NAME" → "SCHEMA.PROC_NAME"
        # Handles both single-dot and multi-dot qualified names
        sql = re.sub(r'(\w)\.[ \t]+(\w)', r'\1.\2', sql)

        # Fix SQL keywords swallowed by inline comments.
        # When a line has `-- comment text.WHERE ...` or `-- comment.SELECT ...`,
        # the SQL keyword after the comment is lost. Split them onto a new line.
        sql = self._fix_comment_swallowed_keywords(sql)

        # Ensure MERGE statements end with semicolons (must run BEFORE
        # _fix_standalone_set_to_let so the DML tracker can find the `;`)
        sql = self._fix_missing_merge_semicolons(sql)

        # Fix standalone SET var = value → LET var := value
        # (SET is only valid inside SQL UPDATE; in Snowflake Scripting use LET)
        sql = self._fix_standalone_set_to_let(sql)

        # Remove multiple blank lines
        sql = re.sub(r'\n{3,}', '\n\n', sql)

        # Remove trailing whitespace
        sql = '\n'.join(line.rstrip() for line in sql.split('\n'))

        # Ensure single newline at end
        sql = sql.strip() + '\n'

        return sql

    def _fix_comment_swallowed_keywords(self, sql: str) -> str:
        """Fix SQL keywords that got merged into inline comments.

        Detects patterns like:
            `-- TODO: some text.WHERE column =`
            `-- comment.SELECT DISTINCT *`
            `-- comment.QUALIFY ROW_NUMBER()`
        and splits them so the SQL keyword starts on a new line.

        This is generic: it handles ANY inline comment that ends with a
        period/space followed by a SQL keyword.
        """
        # SQL keywords that should never be part of a comment
        sql_keywords = (
            r'WHERE|SELECT|FROM|INSERT|UPDATE|DELETE|MERGE|CREATE|DROP|'
            r'ALTER|QUALIFY|HAVING|GROUP|ORDER|UNION|EXCEPT|INTERSECT|'
            r'WITH|INTO|VALUES|SET|ON|AND|JOIN|LEFT|RIGHT|INNER|OUTER|'
            r'CROSS|FULL|BEGIN|END|DECLARE|LET|IF|ELSE|THEN|WHEN|CASE|'
            r'RETURN|RAISE|EXCEPTION|COMMIT|ROLLBACK'
        )

        # Pattern: inside a -- comment, a SQL keyword appears after . or whitespace
        # The keyword and everything after it should be on a new line
        pattern = re.compile(
            rf'(--[^\n]*?)\.\s*\b({sql_keywords})\b([^\n]*)',
            re.IGNORECASE
        )

        lines = sql.split('\n')
        fixed_lines = []
        changed = False

        for line in lines:
            match = pattern.search(line)
            if match:
                # Split: keep comment part, put keyword on new line
                before_comment = line[:match.start()]
                comment_part = match.group(1)
                keyword = match.group(2)
                after_keyword = match.group(3)

                # Preserve indentation from the original line
                indent = re.match(r'^(\s*)', line).group(1)

                fixed_lines.append(before_comment + comment_part)
                fixed_lines.append(indent + keyword + after_keyword)
                changed = True
            else:
                fixed_lines.append(line)

        if changed:
            self.rules_applied.append(
                "fix_comment_swallowed_keywords: Split SQL keywords out of inline comments"
            )

        return '\n'.join(fixed_lines)

    def _fix_standalone_set_to_let(self, sql: str) -> str:
        """Convert standalone SET var = value to LET var := value.

        In Snowflake Scripting, SET is only valid inside SQL UPDATE statements.
        Standalone variable assignment must use LET var := value.

        This only targets SET statements that are NOT inside an UPDATE/MERGE block.
        """
        lines = sql.split('\n')
        fixed_lines = []
        changed = False

        # Track whether we're inside an UPDATE/MERGE statement
        in_dml = False
        paren_depth = 0

        for line in lines:
            stripped = line.strip()

            # Track UPDATE/MERGE statement context
            if re.match(r'\b(UPDATE|MERGE)\b', stripped, re.IGNORECASE) and not in_dml:
                in_dml = True
                paren_depth = 0

            if in_dml:
                paren_depth += stripped.count('(') - stripped.count(')')
                if ';' in stripped and paren_depth <= 0:
                    in_dml = False
                    paren_depth = 0
                fixed_lines.append(line)
                continue

            # Outside UPDATE/MERGE: convert SET var = value to LET var := value
            # Match: SET <identifier> = <value>;
            set_match = re.match(
                r'^(\s*)SET\s+(\w+)\s*=\s*(.+?)\s*;\s*$',
                line,
                re.IGNORECASE
            )
            if set_match:
                indent = set_match.group(1)
                var_name = set_match.group(2)
                value = set_match.group(3)
                # Don't convert if this looks like it's part of WHEN MATCHED THEN UPDATE SET
                if not re.search(r'\bUPDATE\s+SET\b', line, re.IGNORECASE):
                    fixed_lines.append(f'{indent}{var_name} := {value};')
                    changed = True
                else:
                    fixed_lines.append(line)
            else:
                fixed_lines.append(line)

        if changed:
            self.rules_applied.append(
                "fix_standalone_set_to_let: Converted standalone SET to LET"
            )

        return '\n'.join(fixed_lines)

    def _fix_missing_merge_semicolons(self, sql: str) -> str:
        """Ensure MERGE statements end with semicolons.

        Finds MERGE...WHEN MATCHED THEN UPDATE SET ... blocks and ensures
        they are terminated with a semicolon.
        """
        # Find MERGE statements that end without ; before the next statement
        # or before a comment line
        pattern = re.compile(
            r'(WHEN\s+MATCHED\s+THEN\s+UPDATE\s+SET\s+[^\n;]+)'
            r'(\s*\n)'
            r'(?=\s*(?:--|MERGE|UPDATE|DELETE|INSERT|CREATE|DROP|SET|LET|IF|END|EXCEPTION|\n\s*\n))',
            re.IGNORECASE
        )

        new_sql = pattern.sub(r'\1;\2', sql)
        if new_sql != sql:
            self.rules_applied.append(
                "fix_missing_merge_semicolons: Added missing semicolons after MERGE"
            )
        return new_sql

    def _fix_update_set_let(self, sql: str) -> str:
        """
        Fix LET that was incorrectly converted within UPDATE statements.
        UPDATE SET should remain as SET, not LET.

        Uses semicolon-delimited statement extraction with parenthesis depth
        tracking to avoid stopping at SELECT subqueries inside FROM clauses.
        """
        result = []
        pos = 0
        update_re = re.compile(r'\bUPDATE\b', re.IGNORECASE)

        while pos < len(sql):
            match = update_re.search(sql, pos)
            if not match:
                result.append(sql[pos:])
                break

            # Add everything before this UPDATE
            result.append(sql[pos:match.start()])

            # Find the end of this UPDATE statement by tracking parenthesis depth
            # so we don't stop at ; inside subqueries
            stmt_start = match.start()
            depth = 0
            i = match.end()
            while i < len(sql):
                ch = sql[i]
                if ch == '(':
                    depth += 1
                elif ch == ')':
                    depth -= 1
                elif ch == ';' and depth == 0:
                    i += 1  # include the ;
                    break
                i += 1

            update_stmt = sql[stmt_start:i]
            # Replace LET x := with SET x = within this UPDATE statement
            update_stmt = re.sub(r'\bLET\s+(\w+)\s*:=', r'SET \1 =', update_stmt)
            # Also fix bare assignment (no LET) produced by set_to_let rule inside UPDATE
            # Pattern: after )alias\n  COL := val  →  )alias\n  SET COL = val
            update_stmt = re.sub(r'(?<=\n)(\s*)(\w+)\s*:=\s*', r'\1SET \2 = ', update_stmt)
            result.append(update_stmt)
            pos = i

        return ''.join(result)

    def _convert_complex_intervals(self, sql: str) -> str:
        """
        Convert complex Teradata interval expressions to Snowflake DATEDIFF.
        Handles patterns that may not be caught by simple regex rules.
        """
        # Pattern for: CAST(((expr1 - expr2) MONTH(n)) AS INTEGER)
        # This handles nested parentheses better
        interval_patterns = [
            # CAST(((date1 - date2) MONTH(4)) AS INTEGER) -> DATEDIFF(MONTH, date2, date1)
            (
                r'CAST\s*\(\s*\(\s*\(([^()]+)\s*-\s*([^()]+)\)\s*MONTH\s*\(\s*\d+\s*\)\s*\)\s*AS\s+INTEGER\s*\)',
                r'DATEDIFF(MONTH, \2, \1)'
            ),
            # Handle with explicit ::DATE casts
            (
                r'CAST\s*\(\s*\(\s*([^:]+)::DATE\s*-\s*([^:]+)::DATE\s*\)\s*MONTH\s*\(\s*\d+\s*\)\s*AS\s+INTEGER\s*\)',
                r'DATEDIFF(MONTH, \2::DATE, \1::DATE)'
            ),
            # Simple form: (date1 - date2) MONTH(n)
            (
                r'\(\s*([^\s()]+)\s*-\s*([^\s()]+)\s*\)\s*MONTH\s*\(\s*\d+\s*\)',
                r'DATEDIFF(MONTH, \2, \1)'
            ),
            # DAY interval
            (
                r'CAST\s*\(\s*\(\s*\(([^()]+)\s*-\s*([^()]+)\)\s*DAY\s*\(\s*\d+\s*\)\s*\)\s*AS\s+INTEGER\s*\)',
                r'DATEDIFF(DAY, \2, \1)'
            ),
        ]

        for pattern, replacement in interval_patterns:
            new_sql = re.sub(pattern, replacement, sql, flags=re.IGNORECASE)
            if new_sql != sql:
                self.rules_applied.append(f"complex_interval: Converted interval expression to DATEDIFF")
                sql = new_sql

        return sql

    def _preprocess_quoted_input(self, sql: str) -> str:
        """Strip quoted string wrappers from input.

        Teradata export files (SHOW PROCEDURE, DBC.TABLES extracts) wrap
        procedure text in double-quotes. Common formats:
        1. Each line wrapped: `"REPLACE PROCEDURE ..."` / `"END MAIN;"`
        2. Procedure name split: `REPLACE PROCEDURE SCHEMA."` / `"PROC_NAME"`
        3. Column header: `"RequestText"` followed by quoted body

        This method detects ANY of these patterns and strips the wrapper
        quotes, then joins lines that were split mid-statement.
        """
        lines = sql.split('\n')

        # Detect if file has Teradata export quoting by checking first 5
        # non-empty lines for `"` as a string wrapper (not SQL identifier)
        has_quote_wrapping = False
        check_count = 0
        for line in lines:
            stripped = line.strip()
            if not stripped:
                continue
            check_count += 1
            if check_count > 5:
                break
            # Line starts or ends with " (wrapper), or has "" inside (escaped quotes)
            if stripped.startswith('"') or stripped.endswith('"') or '""' in stripped:
                has_quote_wrapping = True
                break

        if not has_quote_wrapping:
            return sql

        # Phase 1: Strip leading/trailing " from each line and skip
        # pure header lines like "RequestText"
        new_lines = []
        quoted_line_count = 0
        non_empty_line_count = 0
        for line in lines:
            stripped = line.strip()
            if stripped:
                non_empty_line_count += 1
            # Skip column header lines (e.g., "RequestText")
            if re.match(r'^"?\w+"?\s*$', stripped) and stripped.replace('"', '').isalpha():
                if stripped.startswith('"') and stripped.endswith('"'):
                    continue  # Skip header like "RequestText"

            had_quote = False
            if stripped.startswith('"') and stripped.endswith('"') and len(stripped) > 1:
                line = stripped[1:-1]
                had_quote = True
            elif stripped.startswith('"'):
                line = stripped[1:]
                had_quote = True
            elif stripped.endswith('"'):
                line = stripped[:-1]
                had_quote = True
            if had_quote:
                quoted_line_count += 1
            new_lines.append(line)

        # Phase 1a: Rejoin comment lines split by quote boundaries.
        # When a -- comment line had its trailing " stripped and the next
        # line had its leading " stripped, they were originally one comment
        # line split by the Teradata export tool. Rejoin them to prevent
        # orphaned text fragments that would be treated as executable SQL.
        rejoined = []
        i = 0
        while i < len(new_lines):
            line = new_lines[i]
            stripped = line.strip()
            # Detect: current line is a -- comment, and the ORIGINAL line
            # ended with " (quote was stripped in Phase 1). We check by
            # looking at the original lines array at the same index.
            if (stripped.startswith('--') and i < len(lines) and
                    lines[i].strip().endswith('"')):
                # Check if next non-empty line starts with " in original
                # (meaning it's the continuation of this split comment)
                if (i + 1 < len(new_lines) and i + 1 < len(lines) and
                        lines[i + 1].strip().startswith('"')):
                    # Rejoin: append next line's content to this comment
                    next_content = new_lines[i + 1].strip()
                    rejoined.append(line + next_content)
                    i += 2
                    continue
            rejoined.append(line)
            i += 1
        new_lines = rejoined

        # Phase 1b: Replace remaining Teradata escaped double-quotes ""
        # with single " (inside $$ blocks this is correct; outside it
        # will be handled by _fix_double_quoted_identifiers later)
        # Only replace "" that look like identifier quoting, not empty strings
        joined = '\n'.join(new_lines)
        # Replace ""identifier"" with "identifier" (Teradata quote escaping)
        joined = re.sub(r'""(\w+)""', r'"\1"', joined)
        new_lines = joined.split('\n')

        # Phase 2: Join lines that were split mid-statement by the
        # quoting tool. If a line doesn't end with a statement terminator
        # or block keyword, merge it with the next line.
        #
        # THRESHOLD: Only apply Phase 2 joining when a significant fraction
        # of lines actually had wrapper quotes stripped (>30%). If only a
        # few lines had quotes (e.g., just the procedure name header), the
        # file is NOT a true Teradata export with split lines — joining
        # would collapse 900+ lines into ~130 lines.
        quote_ratio = quoted_line_count / max(non_empty_line_count, 1)
        if quote_ratio > 0.30:
            # IMPORTANT: Lines with inline -- comments must NOT be joined with
            # the next line, otherwise the comment swallows the joined SQL.
            joined_lines = []
            current = ""
            block_endings = re.compile(
                r'(?:;|--|/\*|\*/|BEGIN|END|THEN|ELSE|LOOP|AS|DO)\s*$',
                re.IGNORECASE
            )
            # Also detect lines that contain an inline comment (-- not at start)
            inline_comment = re.compile(r'^[^-]*\S.*--')

            for line in new_lines:
                stripped = line.strip()
                if not stripped:
                    if current:
                        joined_lines.append(current)
                        current = ""
                    joined_lines.append(line)
                    continue
                if current:
                    current += " " + stripped
                else:
                    current = line
                # Check if this looks like a complete line
                # Also treat lines with inline comments as complete (don't join
                # the next line, which would become part of the comment)
                # Lines starting with -- are full-line comments and MUST be
                # treated as complete, otherwise the next line gets swallowed.
                if (block_endings.search(stripped) or
                        stripped.endswith(',') or
                        stripped.startswith('--') or
                        inline_comment.search(stripped)):
                    joined_lines.append(current)
                    current = ""
            if current:
                joined_lines.append(current)

            sql = '\n'.join(joined_lines)
        else:
            sql = '\n'.join(new_lines)
        self.rules_applied.append("preprocess_quoted_input: Stripped wrapper quotes from input")
        return sql

    def _convert_teradata_shorthand_cast(self, sql: str) -> str:
        """Convert Teradata shorthand CAST syntax: expr (TYPE) → expr::TYPE.

        Teradata allows `column_expr (DECIMAL(24,12))` as shorthand for
        CAST(column_expr AS DECIMAL(24,12)). Snowflake does not support
        this syntax.

        Targets patterns like:
        - A.COLUMN (DECIMAL(24,12))
        - ) (DECIMAL(16,6))
        - expression (INTEGER)

        Only matches when the (TYPE) pattern follows a column reference,
        closing paren, or numeric literal — NOT after keywords like
        CREATE, INSERT, TABLE, etc.
        """
        original = sql

        # Pattern: (closing_paren_or_column_ref) SPACE (TYPE_NAME(precision))
        # Teradata types that can appear in shorthand cast
        td_types = r'DECIMAL|NUMERIC|INTEGER|INT|SMALLINT|BIGINT|FLOAT|REAL|' \
                   r'VARCHAR|CHAR|CHARACTER|DATE|TIMESTAMP|BYTEINT|NUMBER'

        # Match: identifier.column or ) followed by space and (TYPE...)
        # Use negative lookbehind for keywords that legitimately precede (...)
        pattern = re.compile(
            r'(\w+(?:\.\w+)*|\))\s*\(((?:' + td_types + r')(?:\s*\([^)]*\))?)\)',
            re.IGNORECASE
        )

        # Keywords that legitimately precede (...) — don't convert these
        no_convert_keywords = {
            'TABLE', 'INTO', 'FROM', 'JOIN', 'VALUES', 'SET', 'ON',
            'INDEX', 'BEGIN', 'END', 'PROCEDURE', 'FUNCTION', 'AS',
            'RETURNS', 'DECLARE', 'CONDITION', 'HANDLER', 'IN', 'EXISTS',
            'CREATE', 'INSERT', 'DELETE', 'UPDATE', 'SELECT', 'WHERE',
            'AND', 'OR', 'NOT', 'WHEN', 'THEN', 'ELSE', 'CASE',
            'TEMPORARY', 'VOLATILE', 'REPLACE', 'IF', 'WHILE', 'FOR',
            'EXCEPTION', 'DEFAULT', 'MULTISET'
        }

        def replace_shorthand(match):
            prefix = match.group(1)
            type_spec = match.group(2)

            # Don't convert if prefix is a SQL keyword
            word = prefix.upper().split('.')[-1] if '.' in prefix else prefix.upper()
            if word in no_convert_keywords:
                return match.group(0)

            # Don't convert if prefix is just a closing paren that looks like
            # it could be part of a column definition (e.g., VARCHAR(10))
            return f'{prefix}::{type_spec}'

        new_sql = pattern.sub(replace_shorthand, sql)

        if new_sql != original:
            sql = new_sql
            self.rules_applied.append(
                "teradata_shorthand_cast: Converted Teradata shorthand CAST expr (TYPE) to expr::TYPE"
            )

        return sql

    def _convert_complex_casts(self, sql: str) -> str:
        """Convert CAST expressions with complex inner expressions.

        Uses parenthesis depth tracking to correctly find the matching
        closing paren, handling cases like CAST(COALESCE(x,0) AS DECIMAL(18,2)).
        Converts to Snowflake :: cast syntax.
        """
        type_map = {
            'DECIMAL': True, 'VARCHAR': True, 'INTEGER': False,
            'FLOAT': False, 'DATE': False, 'TIMESTAMP': True,
            'BIGINT': False, 'SMALLINT': False, 'NUMBER': True,
            'CHAR': True, 'TINYINT': False, 'INT': False,
            'BOOLEAN': False, 'DOUBLE': False,
        }

        cast_pattern = re.compile(r'\bCAST\s*\(', re.IGNORECASE)
        iterations = 0
        max_iterations = 200

        while iterations < max_iterations:
            iterations += 1
            match = cast_pattern.search(sql)
            if not match:
                break

            start = match.start()
            inner_start = match.end()  # Right after CAST(

            # Track parenthesis depth to find matching )
            depth = 1
            pos = inner_start
            while pos < len(sql) and depth > 0:
                if sql[pos] == '(':
                    depth += 1
                elif sql[pos] == ')':
                    depth -= 1
                pos += 1

            if depth != 0:
                break  # Unbalanced parens

            cast_end = pos  # Position right after closing )
            inner = sql[inner_start:cast_end - 1].strip()

            # Skip CASTs with FORMAT clause (handled elsewhere)
            if re.search(r'\bFORMAT\s+', inner, re.IGNORECASE):
                # Move past this CAST to avoid infinite loop
                sql = sql[:start] + '/*CAST_SKIP*/' + sql[start:]
                continue

            # Parse: inner should be "expr AS TYPE" or "expr AS TYPE(precision)"
            as_match = re.search(
                r'\bAS\s+(DECIMAL|VARCHAR|INTEGER|INT|FLOAT|DATE|TIMESTAMP|BIGINT|SMALLINT|NUMBER|CHAR|TINYINT|BOOLEAN|DOUBLE)'
                r'(\s*\([^)]*\))?\s*$',
                inner, re.IGNORECASE
            )
            if not as_match:
                # Not a simple type cast — skip
                sql = sql[:start] + '/*CAST_SKIP*/' + sql[start:]
                continue

            expr = inner[:as_match.start()].strip()
            target_type = as_match.group(1).upper()
            precision = as_match.group(2) or ''

            # If expression contains arithmetic operators (+, -, *, /) at the
            # top level (not inside function calls), wrap in parentheses so
            # :: binds to the entire expression, not just the last operand.
            # e.g. YEAR(x)*100 + MONTH(x)::VARCHAR → (YEAR(x)*100 + MONTH(x))::VARCHAR
            needs_parens = False
            paren_depth = 0
            for ch in expr:
                if ch == '(':
                    paren_depth += 1
                elif ch == ')':
                    paren_depth -= 1
                elif ch in '+-*/' and paren_depth == 0:
                    needs_parens = True
                    break

            if needs_parens:
                replacement = f"({expr})::{target_type}{precision}"
            else:
                replacement = f"{expr}::{target_type}{precision}"
            sql = sql[:start] + replacement + sql[cast_end:]
            self.rules_applied.append(f"complex_cast: CAST({expr[:30]}... AS {target_type}) → ::{target_type}")

        # Remove skip markers
        sql = sql.replace('/*CAST_SKIP*/', '')

        return sql

    def _fix_insert_values(self, sql: str) -> str:
        """Fix INSERT statements missing the VALUES keyword.

        Teradata allows `INSERT INTO table (1, 'x')` as shorthand for
        `INSERT INTO table VALUES (1, 'x')`. This detects such patterns
        and adds the missing VALUES keyword.
        """
        # Type keywords that would indicate column definitions, not values
        type_keywords = r'\b(?:VARCHAR|INTEGER|INT|DECIMAL|NUMBER|FLOAT|DATE|TIMESTAMP|BIGINT|SMALLINT|CHAR|BOOLEAN|TINYINT|DOUBLE|DEFAULT|NOT\s+NULL|PRIMARY\s+KEY)\b'

        # Pattern: INSERT INTO tablename (...) where parens contain value-like content
        pattern = re.compile(
            r'(INSERT\s+INTO\s+[\w.]+)\s*(\([^)]+\))\s*(;)',
            re.IGNORECASE
        )

        def check_and_fix(match):
            prefix = match.group(1)
            paren_content = match.group(2)
            semicolon = match.group(3)
            inner = paren_content[1:-1].strip()

            # If inner content has type keywords, it's a column definition, not values
            if re.search(type_keywords, inner, re.IGNORECASE):
                return match.group(0)

            # If it contains at least one numeric literal or quoted string, it's values
            has_values = (
                re.search(r'\b\d+\.?\d*\b', inner) or
                re.search(r"'[^']*'", inner)
            )

            if has_values:
                self.rules_applied.append("fix_insert_values: Added missing VALUES keyword")
                return f"{prefix} VALUES {paren_content}{semicolon}"

            return match.group(0)

        sql = pattern.sub(check_and_fix, sql)
        return sql

    def _convert_if_subquery(self, sql: str) -> str:
        """Convert IF EXISTS (SELECT ...) and IF (SELECT ...) patterns.

        Snowflake Scripting doesn't support subqueries directly in IF
        conditions. This extracts the subquery into a LET variable and
        rewrites the IF condition.
        """
        counter = [0]  # Mutable counter for unique variable names

        def _is_inside_comment(text, pos):
            """Check if position is inside a -- line comment or /* */ block comment."""
            # Check for -- line comment: find start of line, look for --
            line_start = text.rfind('\n', 0, pos)
            line_start = line_start + 1 if line_start != -1 else 0
            line_prefix = text[line_start:pos]
            if '--' in line_prefix:
                return True
            # Check for /* */ block comment
            last_open = text.rfind('/*', 0, pos)
            if last_open != -1:
                last_close = text.rfind('*/', 0, pos)
                if last_close < last_open:
                    return True
            return False

        def _extract_balanced_paren(text, start):
            """Extract content within balanced parentheses starting at start (which should be '(')."""
            if start >= len(text) or text[start] != '(':
                return None, start
            depth = 0
            pos = start
            while pos < len(text):
                if text[pos] == '(':
                    depth += 1
                elif text[pos] == ')':
                    depth -= 1
                    if depth == 0:
                        return text[start + 1:pos], pos + 1
                pos += 1
            return None, start

        # Pattern 1: IF EXISTS (SELECT ...)
        exists_pattern = re.compile(r'\bIF\s+EXISTS\s*\(', re.IGNORECASE)
        iterations = 0
        search_start = 0
        while iterations < 50:
            iterations += 1
            match = exists_pattern.search(sql, search_start)
            if not match:
                break

            # Skip matches inside comments
            if _is_inside_comment(sql, match.start()):
                search_start = match.end()
                continue

            # Find the opening ( of the subquery
            paren_start = match.end() - 1  # Back up to the (
            subquery, after_pos = _extract_balanced_paren(sql, paren_start)
            if subquery is None:
                break

            # Convert SELECT * or SELECT columns to SELECT COUNT(*)
            subquery_count = re.sub(
                r'^\s*SELECT\s+(?:\*|(?:(?!FROM\b).)+?)\s+FROM\b',
                'SELECT COUNT(*) FROM',
                subquery.strip(),
                count=1,
                flags=re.IGNORECASE | re.DOTALL
            )

            counter[0] += 1
            var_name = f"v_exists_{counter[0]}"

            # Find THEN after the closing paren
            after_text = sql[after_pos:]
            then_match = re.match(r'\s*THEN\b', after_text, re.IGNORECASE)
            then_end = after_pos + then_match.end() if then_match else after_pos

            replacement = f"LET {var_name} := ({subquery_count});\n    IF ({var_name} > 0) THEN"
            sql = sql[:match.start()] + replacement + sql[then_end:]
            self.rules_applied.append(f"if_exists_to_let: IF EXISTS (SELECT) → LET {var_name}")

        # Pattern 2: IF (SELECT ...) comparison
        if_select_pattern = re.compile(r'\bIF\s*\(\s*SELECT\b', re.IGNORECASE)
        iterations = 0
        search_start = 0
        while iterations < 50:
            iterations += 1
            match = if_select_pattern.search(sql, search_start)
            if not match:
                break

            # Skip matches inside comments
            if _is_inside_comment(sql, match.start()):
                search_start = match.end()
                continue

            # Find the outer IF( paren
            # First find the ( that wraps the whole IF condition
            if_start = match.start()
            paren_pos = sql.index('(', match.start() + 2)
            subquery_content, after_paren = _extract_balanced_paren(sql, paren_pos)
            if subquery_content is None:
                break

            # Check for comparison operator after the closing paren
            after_text = sql[after_paren:]
            comp_match = re.match(r'\s*(>|<|>=|<=|=|!=|<>)\s*(\d+)\s*\)?\s*THEN\b', after_text, re.IGNORECASE)

            counter[0] += 1
            var_name = f"v_subq_{counter[0]}"

            if comp_match:
                operator = comp_match.group(1)
                value = comp_match.group(2)
                end_pos = after_paren + comp_match.end()
                replacement = f"LET {var_name} := ({subquery_content});\n    IF ({var_name} {operator} {value}) THEN"
            else:
                # No explicit comparison — assume > 0
                then_match = re.search(r'\)?\s*THEN\b', after_text, re.IGNORECASE)
                end_pos = after_paren + (then_match.end() if then_match else 0)
                replacement = f"LET {var_name} := ({subquery_content});\n    IF ({var_name} > 0) THEN"

            sql = sql[:if_start] + replacement + sql[end_pos:]
            self.rules_applied.append(f"if_subquery_to_let: IF (SELECT ...) → LET {var_name}")

        return sql

    def _convert_select_into_no_from(self, sql: str) -> str:
        """Convert SELECT expr INTO var; (without FROM) to LET var := expr;

        In Snowflake, SELECT ... INTO without a FROM clause is invalid.
        These are typically variable assignments using expressions.
        """
        # Pattern: SELECT expr INTO varname ; where there's no FROM between INTO and ;
        # Use [^;\n]+? to avoid matching across statement AND line boundaries.
        # Excluding \n prevents matching a comment like "--select enddate"
        # on one line and spanning into a real "SELECT ... INTO var;" on the next.
        pattern = re.compile(
            r'\bSELECT\s+([^;\n]+?)\s+INTO\s+(\w+)\s*;',
            re.IGNORECASE
        )

        def replace_if_no_from(match):
            expr = match.group(1).strip()
            var = match.group(2)
            full = match.group(0)

            # Skip if match starts inside a -- comment
            line_start = sql.rfind('\n', 0, match.start()) + 1
            line_prefix = sql[line_start:match.start()]
            if '--' in line_prefix:
                return full

            # Check if there's a FROM keyword in the expression
            # If FROM exists between SELECT and INTO, this is a proper query
            if re.search(r'\bFROM\b', expr, re.IGNORECASE):
                return full

            self.rules_applied.append(f"select_into_no_from: SELECT {expr[:30]}... INTO {var} → LET")
            return f"LET {var} := {expr};"

        sql = pattern.sub(replace_if_no_from, sql)
        return sql

    def _fix_double_quoted_identifiers(self, sql: str) -> str:
        """Fix double-double-quoted identifiers inside $$ blocks.

        `""_SOURCE""` inside procedure body should be `"_SOURCE"`.
        Only operates within $$ delimited procedure bodies.
        """
        if '$$' not in sql:
            return sql

        parts = sql.split('$$')
        if len(parts) < 3:
            return sql

        # Parts[1] is the procedure body between $$ delimiters
        body = parts[1]

        # Replace ""identifier"" with "identifier"
        new_body = re.sub(r'""(\w+)""', r'"\1"', body)

        # Also handle any remaining adjacent "" that aren't part of identifiers
        # Replace all "" with " (this handles cases like standalone "")
        new_body = new_body.replace('""', '"')

        if new_body != body:
            parts[1] = new_body
            sql = '$$'.join(parts)
            self.rules_applied.append("fix_double_quotes: Fixed double-double-quoted identifiers in procedure body")

        return sql

    def _convert_substring_from_for(self, sql: str) -> str:
        """Convert SUBSTRING(expr FROM expr FOR expr) to SUBSTR(expr, expr, expr).

        The simple regex rule handles SUBSTRING(col FROM n FOR m) with literal
        numbers. This method handles expressions like:
            SUBSTRING(GLCACCOUNT FROM (CHAR_LENGTH(GLCACCOUNT)-4) FOR 5)
        where FROM argument can be a parenthesized expression.
        """
        pattern = re.compile(r'\bSUBSTRING\s*\(', re.IGNORECASE)
        result = []
        pos = 0
        applied = False

        while pos < len(sql):
            m = pattern.search(sql, pos)
            if not m:
                result.append(sql[pos:])
                break

            result.append(sql[pos:m.start()])
            # Find balanced closing paren for SUBSTRING(
            start = m.end()  # position after '('
            depth = 1
            i = start
            while i < len(sql) and depth > 0:
                if sql[i] == '(':
                    depth += 1
                elif sql[i] == ')':
                    depth -= 1
                i += 1

            if depth != 0:
                # Unbalanced, skip
                result.append(sql[m.start():m.end()])
                pos = m.end()
                continue

            inner = sql[start:i - 1]  # content between SUBSTRING( and )
            # Parse: expr FROM expr FOR expr
            from_match = re.search(r'\sFROM\s', inner, re.IGNORECASE)
            for_match = re.search(r'\sFOR\s', inner, re.IGNORECASE)

            if from_match and for_match and for_match.start() > from_match.start():
                str_expr = inner[:from_match.start()].strip()
                from_expr = inner[from_match.end():for_match.start()].strip()
                for_expr = inner[for_match.end():].strip()
                result.append(f'SUBSTR({str_expr}, {from_expr}, {for_expr})')
                applied = True
            else:
                # Not a FROM...FOR pattern, keep original
                result.append(sql[m.start():i])
            pos = i

        if applied:
            self.rules_applied.append("substring_from_for_expr: SUBSTRING(x FROM expr FOR expr) → SUBSTR")

        return ''.join(result)

    def convert(self, teradata_sql: str) -> ConversionResult:
        """
        Convert Teradata SQL to Snowflake SQL.

        Args:
            teradata_sql: The Teradata SQL code to convert

        Returns:
            ConversionResult with converted SQL and metadata
        """
        self.rules_applied = []
        self.warnings = []
        self._exception_block = None
        self._multi_out_return_expr = None

        sql = teradata_sql

        try:
            # 0. Preprocess: strip quoted string wrappers
            sql = self._preprocess_quoted_input(sql)

            # 1. Extract OUT params before rules remove them
            self._extract_out_params(sql)

            # 2. Apply basic regex rules
            sql = self._apply_rules(sql, self.rules)

            # 2a. Strip IN/OUT/INOUT keywords from procedure parameters
            sql = self._strip_param_direction_keywords(sql)

            # 2a2. Convert SIGNAL to RAISE with custom exception
            sql = self._convert_signal_to_raise(sql)

            # 2a3. Convert CALL DBC.SYSEXECSQL to EXECUTE IMMEDIATE
            sql = self._convert_execute_immediate(sql)

            # 2b. Convert TRIM LEADING/TRAILING/BOTH (needs paren depth tracking)
            sql = self._convert_trim_functions(sql)

            # 2c. Convert SUBSTRING(expr FROM expr FOR expr) with complex args
            sql = self._convert_substring_from_for(sql)

            # 3. Convert complex interval expressions
            sql = self._convert_complex_intervals(sql)

            # 3b. Validate and fix DATEADD argument counts
            sql = self._validate_dateadd_args(sql)

            # 3c. Convert complex CAST expressions (depth-tracking)
            sql = self._convert_complex_casts(sql)

            # 3d. Convert Teradata shorthand CAST: expr (TYPE) → expr::TYPE
            sql = self._convert_teradata_shorthand_cast(sql)

            # 3e. Convert Teradata cursor operations (FOR AS CURSOR, DECLARE CURSOR)
            sql = self._convert_cursor_operations(sql)

            # 4. Convert UPDATE FROM to MERGE
            sql = self._convert_update_from_to_merge(sql)

            # 4b. Fix MERGE alias references (old alias → src)
            sql = self._fix_merge_alias_references(sql)

            # 5. Fix UPDATE SET that was incorrectly converted to LET
            sql = self._fix_update_set_let(sql)

            # 5b. Fix INSERT missing VALUES keyword
            sql = self._fix_insert_values(sql)

            # 5c. Convert IF (SELECT ...) and IF EXISTS (SELECT ...)
            sql = self._convert_if_subquery(sql)

            # 5d. Convert SELECT ... INTO without FROM clause
            sql = self._convert_select_into_no_from(sql)

            # 6. Convert exception handlers (extracts body for later insertion)
            sql = self._convert_exception_handler(sql)

            # 7. Add procedure wrapper if needed
            sql = self._add_procedure_wrapper(sql)

            # 8. Generate DECLARE block from orphaned variable declarations
            sql = self._generate_declare_block(sql)

            # 9. Insert exception block before inner END
            sql = self._insert_exception_block(sql)

            # 9b. Remove LET keyword for variables already declared in DECLARE block.
            # Must run AFTER exception block insertion so it covers LET assignments
            # inside the EXCEPTION handler body as well.
            # Fixes: "Declaration of out variable", "LET not needed"
            sql = self._demote_let_declarations(sql)

            # 9c. Fix double-double-quoted identifiers inside $$ blocks
            # (must run after exception block insertion since handler body may contain "")
            sql = self._fix_double_quoted_identifiers(sql)

            # 9d. Strip dead Teradata code (ERROR_CONDITION, ET)
            sql = self._strip_dead_teradata_code(sql)

            # 9d. Flatten redundant nested BEGIN/END blocks
            sql = self._flatten_nested_begin_end(sql)

            # 9e. Strip export metadata/footer
            sql = self._strip_export_footer(sql)

            # 10. Apply schema mapping (after exception block insertion so
            #     schema names inside the exception handler are also mapped)
            sql = self._apply_schema_mapping(sql)

            # 11. Add RETURN statement for procedures with RETURNS clause
            sql = self._add_return_statement(sql)

            # 11b. Handle multiple OUT parameters (RETURNS VARIANT + OBJECT_CONSTRUCT)
            sql = self._handle_multiple_out_params(sql)

            # 12. Add variable colon prefix for SQL contexts
            sql = self._add_variable_colon_prefix(sql)

            # 13. Final cleanup
            sql = self._cleanup(sql)

            return ConversionResult(
                original=teradata_sql,
                converted=sql,
                rules_applied=self.rules_applied.copy(),
                warnings=self.warnings.copy(),
                success=True
            )

        except Exception as e:
            self.logger.error(f"Conversion error: {e}")
            return ConversionResult(
                original=teradata_sql,
                converted=sql,
                rules_applied=self.rules_applied.copy(),
                warnings=self.warnings.copy(),
                errors=[str(e)],
                success=False
            )

    def convert_string(self, teradata_sql: str) -> str:
        """
        Simple conversion that returns just the converted SQL string.

        Args:
            teradata_sql: The Teradata SQL code to convert

        Returns:
            The converted Snowflake SQL string
        """
        result = self.convert(teradata_sql)
        return result.converted
