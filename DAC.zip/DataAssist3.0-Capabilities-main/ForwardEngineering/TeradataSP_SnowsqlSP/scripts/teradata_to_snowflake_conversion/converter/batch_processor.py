"""
Batch Processor Module
======================
Handles batch conversion of multiple files from input folder to output folder.
"""

import os
import json
import logging
import shutil
from pathlib import Path
from datetime import datetime
from typing import List, Dict, Optional
from dataclasses import dataclass, field
from concurrent.futures import ThreadPoolExecutor, as_completed

from .converter import TeradataToSnowflakeConverter, ConversionResult


@dataclass
class FileConversionResult:
    """Result of converting a single file."""
    input_path: str
    output_path: str
    success: bool
    rules_applied: int = 0
    warnings: List[str] = field(default_factory=list)
    errors: List[str] = field(default_factory=list)
    processing_time_ms: float = 0


@dataclass
class BatchConversionResult:
    """Result of a batch conversion operation."""
    total_files: int = 0
    successful: int = 0
    failed: int = 0
    skipped: int = 0
    file_results: List[FileConversionResult] = field(default_factory=list)
    start_time: Optional[datetime] = None
    end_time: Optional[datetime] = None

    @property
    def duration_seconds(self) -> float:
        if self.start_time and self.end_time:
            return (self.end_time - self.start_time).total_seconds()
        return 0


class BatchProcessor:
    """
    Processes multiple SQL files for conversion from Teradata to Snowflake.
    """

    def __init__(
        self,
        config: Optional[Dict] = None,
        config_file: Optional[str] = None,
        logger: Optional[logging.Logger] = None
    ):
        """
        Initialize the batch processor.

        Args:
            config: Configuration dictionary
            config_file: Path to JSON configuration file
            logger: Optional logger instance
        """
        # Load config from file if provided
        if config_file and os.path.exists(config_file):
            with open(config_file, 'r', encoding='utf-8') as f:
                self.config = json.load(f)
        else:
            self.config = config or {}

        # Setup logger
        self.logger = logger or self._setup_logger()

        # Initialize converter with config
        self.converter = TeradataToSnowflakeConverter(
            config=self.config,
            logger=self.logger
        )

        # Extract config values
        self.input_folder = Path(self.config.get('input_folder', './input'))
        self.output_folder = Path(self.config.get('output_folder', './output'))
        self.file_extensions = self.config.get('file_extensions', ['.sql', '.bteq', '.txt'])
        self.verbose = self.config.get('verbose', False)
        self.generate_report = self.config.get('generate_report', True)
        self.preserve_folder_structure = self.config.get('preserve_folder_structure', True)
        self.backup_originals = self.config.get('backup_originals', False)
        self.skip_files = self.config.get('skip_files', [])
        self.output_suffix = self.config.get('output_suffix', '_snowflake')
        self.parallel_workers = self.config.get('parallel_workers', 1)

    def _setup_logger(self) -> logging.Logger:
        """Setup logging configuration."""
        logger = logging.getLogger('teradata_converter')
        logger.setLevel(logging.DEBUG if self.config.get('verbose') else logging.INFO)

        # Console handler
        console_handler = logging.StreamHandler()
        console_handler.setLevel(logging.DEBUG if self.config.get('verbose') else logging.INFO)
        console_format = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
        console_handler.setFormatter(console_format)
        logger.addHandler(console_handler)

        # File handler if log_file specified
        log_file = self.config.get('log_file')
        if log_file:
            file_handler = logging.FileHandler(log_file, encoding='utf-8')
            file_handler.setLevel(logging.DEBUG)
            file_format = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
            file_handler.setFormatter(file_format)
            logger.addHandler(file_handler)

        return logger

    def _get_input_files(self) -> List[Path]:
        """Get list of input files to process."""
        files = []

        if not self.input_folder.exists():
            self.logger.error(f"Input folder does not exist: {self.input_folder}")
            return files

        for ext in self.file_extensions:
            # Normalize extension
            if not ext.startswith('.'):
                ext = '.' + ext

            # Find all matching files
            for file_path in self.input_folder.rglob(f'*{ext}'):
                # Check skip list
                if file_path.name in self.skip_files:
                    self.logger.info(f"Skipping file (in skip list): {file_path}")
                    continue

                files.append(file_path)

        return sorted(files)

    def _get_output_path(self, input_path: Path) -> Path:
        """Determine output path for a given input file."""
        if self.preserve_folder_structure:
            # Preserve relative folder structure
            relative_path = input_path.relative_to(self.input_folder)
            output_path = self.output_folder / relative_path
        else:
            # Flat output structure
            output_path = self.output_folder / input_path.name

        # Add suffix before extension
        stem = output_path.stem
        suffix = output_path.suffix
        output_path = output_path.with_name(f"{stem}{self.output_suffix}{suffix}")

        return output_path

    def _backup_file(self, file_path: Path) -> Optional[Path]:
        """Create a backup of the original file."""
        backup_path = file_path.with_suffix(file_path.suffix + '.bak')
        try:
            shutil.copy2(file_path, backup_path)
            return backup_path
        except Exception as e:
            self.logger.warning(f"Failed to backup file {file_path}: {e}")
            return None

    def _add_file_header(self, sql: str, input_path: Path, output_path: Path) -> str:
        """Add a header comment to the converted file."""
        header = f"""/*
================================================================================
-- Converted from Teradata to Snowflake
-- Source File: {input_path.name}
-- Output File: {output_path.name}
-- Conversion Date: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
--
-- NOTE: This is an automated conversion. Please review and test thoroughly.
================================================================================
*/

"""
        return header + sql

    def convert_file(self, input_path: Path) -> FileConversionResult:
        """
        Convert a single file.

        Args:
            input_path: Path to the input file

        Returns:
            FileConversionResult with conversion details
        """
        start_time = datetime.now()
        output_path = self._get_output_path(input_path)

        try:
            # Read input file
            self.logger.info(f"Converting: {input_path}")
            teradata_sql = input_path.read_text(encoding='utf-8')

            # Convert
            result = self.converter.convert(teradata_sql)

            if not result.success:
                return FileConversionResult(
                    input_path=str(input_path),
                    output_path=str(output_path),
                    success=False,
                    errors=result.errors,
                    processing_time_ms=(datetime.now() - start_time).total_seconds() * 1000
                )

            # Add header
            converted_sql = self._add_file_header(result.converted, input_path, output_path)

            # Create output directory if needed
            output_path.parent.mkdir(parents=True, exist_ok=True)

            # Write output file
            output_path.write_text(converted_sql, encoding='utf-8')

            # Backup original if configured
            if self.backup_originals:
                self._backup_file(input_path)

            end_time = datetime.now()

            return FileConversionResult(
                input_path=str(input_path),
                output_path=str(output_path),
                success=True,
                rules_applied=len(result.rules_applied),
                warnings=result.warnings,
                processing_time_ms=(end_time - start_time).total_seconds() * 1000
            )

        except Exception as e:
            self.logger.error(f"Error converting {input_path}: {e}")
            return FileConversionResult(
                input_path=str(input_path),
                output_path=str(output_path),
                success=False,
                errors=[str(e)],
                processing_time_ms=(datetime.now() - start_time).total_seconds() * 1000
            )

    def process_batch(self) -> BatchConversionResult:
        """
        Process all files in the input folder.

        Returns:
            BatchConversionResult with overall statistics
        """
        result = BatchConversionResult()
        result.start_time = datetime.now()

        # Get input files
        input_files = self._get_input_files()
        result.total_files = len(input_files)

        if result.total_files == 0:
            self.logger.warning(f"No files found in {self.input_folder} with extensions {self.file_extensions}")
            result.end_time = datetime.now()
            return result

        self.logger.info(f"Found {result.total_files} files to convert")

        # Create output folder
        self.output_folder.mkdir(parents=True, exist_ok=True)

        # Process files
        if self.parallel_workers > 1:
            # Parallel processing
            with ThreadPoolExecutor(max_workers=self.parallel_workers) as executor:
                futures = {executor.submit(self.convert_file, f): f for f in input_files}
                for future in as_completed(futures):
                    file_result = future.result()
                    result.file_results.append(file_result)
                    if file_result.success:
                        result.successful += 1
                    else:
                        result.failed += 1
        else:
            # Sequential processing
            for input_file in input_files:
                file_result = self.convert_file(input_file)
                result.file_results.append(file_result)
                if file_result.success:
                    result.successful += 1
                else:
                    result.failed += 1

        result.end_time = datetime.now()

        # Generate report if configured
        if self.generate_report:
            self._generate_report(result)

        # Log summary
        self.logger.info(f"Conversion complete: {result.successful}/{result.total_files} successful")
        if result.failed > 0:
            self.logger.warning(f"Failed conversions: {result.failed}")

        return result

    def _generate_report(self, result: BatchConversionResult):
        """Generate a markdown report of the conversion."""
        report_path = self.output_folder / 'conversion_report.md'

        report_lines = [
            "# Teradata to Snowflake Conversion Report",
            "",
            f"**Generated:** {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}",
            "",
            "## Summary",
            "",
            f"| Metric | Value |",
            f"|--------|-------|",
            f"| Total Files | {result.total_files} |",
            f"| Successful | {result.successful} |",
            f"| Failed | {result.failed} |",
            f"| Skipped | {result.skipped} |",
            f"| Duration | {result.duration_seconds:.2f}s |",
            "",
            "## File Details",
            "",
        ]

        # Successful files
        successful_files = [f for f in result.file_results if f.success]
        if successful_files:
            report_lines.append("### Successful Conversions")
            report_lines.append("")
            report_lines.append("| Input File | Output File | Rules Applied | Time (ms) |")
            report_lines.append("|------------|-------------|---------------|-----------|")
            for f in successful_files:
                input_name = Path(f.input_path).name
                output_name = Path(f.output_path).name
                report_lines.append(f"| {input_name} | {output_name} | {f.rules_applied} | {f.processing_time_ms:.2f} |")
            report_lines.append("")

        # Failed files
        failed_files = [f for f in result.file_results if not f.success]
        if failed_files:
            report_lines.append("### Failed Conversions")
            report_lines.append("")
            for f in failed_files:
                input_name = Path(f.input_path).name
                report_lines.append(f"#### {input_name}")
                report_lines.append("")
                for error in f.errors:
                    report_lines.append(f"- **Error:** {error}")
                report_lines.append("")

        # Warnings
        files_with_warnings = [f for f in result.file_results if f.warnings]
        if files_with_warnings:
            report_lines.append("### Warnings")
            report_lines.append("")
            for f in files_with_warnings:
                input_name = Path(f.input_path).name
                report_lines.append(f"#### {input_name}")
                for warning in f.warnings:
                    report_lines.append(f"- {warning}")
                report_lines.append("")

        # Write report
        report_path.write_text('\n'.join(report_lines), encoding='utf-8')
        self.logger.info(f"Report generated: {report_path}")


def process_folder(
    input_folder: str,
    output_folder: str,
    config_file: Optional[str] = None,
    **kwargs
) -> BatchConversionResult:
    """
    Convenience function to process a folder.

    Args:
        input_folder: Path to input folder
        output_folder: Path to output folder
        config_file: Optional path to configuration file
        **kwargs: Additional configuration options

    Returns:
        BatchConversionResult
    """
    config = {
        'input_folder': input_folder,
        'output_folder': output_folder,
        **kwargs
    }

    processor = BatchProcessor(config=config, config_file=config_file)
    return processor.process_batch()
