"""
Conversion Rules Module
=======================
Contains all Teradata to Snowflake conversion rules organized by category.
"""

import re
from dataclasses import dataclass, field
from typing import List, Callable, Optional, Union


@dataclass
class ConversionRule:
    """Represents a single conversion rule."""
    name: str
    pattern: str
    replacement: Union[str, Callable]
    flags: int = re.IGNORECASE | re.MULTILINE
    description: str = ""
    category: str = "general"
    enabled: bool = True


class RuleCategories:
    """Constants for rule categories."""
    PROCEDURE = "procedure"
    TABLE = "table"
    DATATYPE = "datatype"
    DATE = "date"
    STRING = "string"
    CAST = "cast"
    SYNTAX = "syntax"


def get_procedure_rules() -> List[ConversionRule]:
    """Get procedure structure conversion rules."""
    return [
        ConversionRule(
            name="replace_procedure_basic",
            pattern=r"REPLACE\s+PROCEDURE",
            replacement="CREATE OR REPLACE PROCEDURE",
            description="REPLACE PROCEDURE → CREATE OR REPLACE PROCEDURE",
            category=RuleCategories.PROCEDURE
        ),
        ConversionRule(
            name="sql_security_owner",
            pattern=r"\)\s*SQL\s+SECURITY\s+OWNER",
            replacement=")\nRETURNS VARCHAR(1000)\nLANGUAGE SQL\nEXECUTE AS OWNER\nAS\n$$",
            description="Add Snowflake procedure attributes (OWNER)",
            category=RuleCategories.PROCEDURE
        ),
        ConversionRule(
            name="sql_security_creator",
            pattern=r"\)\s*SQL\s+SECURITY\s+CREATOR",
            replacement=")\nRETURNS VARCHAR(1000)\nLANGUAGE SQL\nEXECUTE AS CALLER\nAS\n$$",
            description="Add Snowflake procedure attributes (CREATOR → CALLER)",
            category=RuleCategories.PROCEDURE
        ),
        ConversionRule(
            name="bt_transaction",
            pattern=r"^\s*BT\s*;",
            replacement="-- BT; (Teradata transaction control removed)",
            flags=re.IGNORECASE | re.MULTILINE,
            description="Comment out BT (Begin Transaction)",
            category=RuleCategories.PROCEDURE
        ),
        ConversionRule(
            name="et_transaction",
            pattern=r"^\s*ET\s*;",
            replacement="-- ET; (Teradata transaction control removed)",
            flags=re.IGNORECASE | re.MULTILINE,
            description="Comment out ET (End Transaction)",
            category=RuleCategories.PROCEDURE
        ),
    ]


def get_table_rules() -> List[ConversionRule]:
    """Get table operation conversion rules.

    IMPORTANT: Rule order matters. More specific rules (with_data_on_commit_unique)
    must fire BEFORE less specific rules (on_commit_preserve_rows, primary_index_only)
    to prevent partial matches that destroy the patterns needed by specific rules.
    """
    return [
        # no_fallback_journal_log MUST run BEFORE volatile table rules.
        # Input often has: CREATE MULTISET VOLATILE TABLE name\n, NO FALLBACK, NO JOURNAL, NO LOG\n(
        # If those clauses aren't stripped first, the volatile_table_coldef pattern can't match.
        ConversionRule(
            name="no_fallback_journal_log",
            pattern=r",\s*NO\s+(?:FALLBACK|JOURNAL|LOG)\b",
            replacement="",
            description="Remove NO FALLBACK, NO JOURNAL, NO LOG",
            category=RuleCategories.TABLE
        ),
        ConversionRule(
            name="volatile_table_multiset",
            pattern=r"CREATE\s+MULTISET\s+VOLATILE\s+TABLE\s+(\S+)\s+AS\s*\(",
            replacement=r"CREATE OR REPLACE TEMPORARY TABLE \1 AS (",
            description="CREATE MULTISET VOLATILE TABLE → CREATE TEMPORARY TABLE",
            category=RuleCategories.TABLE
        ),
        ConversionRule(
            name="volatile_table",
            pattern=r"CREATE\s+VOLATILE\s+TABLE\s+(\S+)\s+AS\s*\(",
            replacement=r"CREATE OR REPLACE TEMPORARY TABLE \1 AS (",
            description="CREATE VOLATILE TABLE → CREATE TEMPORARY TABLE",
            category=RuleCategories.TABLE
        ),
        ConversionRule(
            name="volatile_table_coldef",
            pattern=r"CREATE\s+(?:MULTISET\s+)?VOLATILE\s+TABLE\s+(\S+)\s*\(",
            replacement=r"CREATE OR REPLACE TEMPORARY TABLE \1 (",
            description="CREATE [MULTISET] VOLATILE TABLE name (col_defs) → CREATE TEMPORARY TABLE",
            category=RuleCategories.TABLE
        ),
        ConversionRule(
            name="set_table",
            pattern=r"CREATE\s+(?:MULTISET|SET)\s+TABLE",
            replacement="CREATE TABLE",
            description="Remove MULTISET/SET from CREATE TABLE",
            category=RuleCategories.TABLE
        ),
        # Most specific WITH DATA rules first (they include PRIMARY INDEX + ON COMMIT)
        ConversionRule(
            name="with_data_on_commit_unique",
            pattern=r"\)\s*WITH\s+DATA\s+UNIQUE\s+PRIMARY\s+INDEX\s*\([^)]*\)\s*ON\s+COMMIT\s+PRESERVE\s+ROWS\s*;",
            replacement=");",
            description="Remove WITH DATA UNIQUE PRIMARY INDEX ON COMMIT PRESERVE ROWS",
            category=RuleCategories.TABLE
        ),
        ConversionRule(
            name="with_data_on_commit",
            pattern=r"\)\s*WITH\s+DATA\s+(?:PRIMARY\s+INDEX\s*\([^)]*\)\s*)?ON\s+COMMIT\s+PRESERVE\s+ROWS\s*;",
            replacement=");",
            description="Remove WITH DATA ON COMMIT PRESERVE ROWS",
            category=RuleCategories.TABLE
        ),
        ConversionRule(
            name="with_data_primary_index",
            pattern=r"\)\s*WITH\s+DATA\s+PRIMARY\s+INDEX\s*\([^)]*\)\s*;",
            replacement=");",
            description="Remove WITH DATA PRIMARY INDEX",
            category=RuleCategories.TABLE
        ),
        # Less specific rules last — these catch standalone clauses not part of WITH DATA
        ConversionRule(
            name="on_commit_preserve_rows",
            pattern=r"\)\s*ON\s+COMMIT\s+PRESERVE\s+ROWS\s*;",
            replacement=");",
            description="Remove standalone ON COMMIT PRESERVE ROWS",
            category=RuleCategories.TABLE
        ),
        ConversionRule(
            name="primary_index_only",
            pattern=r"\bPRIMARY\s+INDEX\s*\([^)]*\)",
            replacement="",
            description="Remove PRIMARY INDEX clause",
            category=RuleCategories.TABLE
        ),
        ConversionRule(
            name="no_primary_index",
            pattern=r"\bNO\s+PRIMARY\s+INDEX\b",
            replacement="",
            description="Remove NO PRIMARY INDEX",
            category=RuleCategories.TABLE
        ),
        ConversionRule(
            name="compress_column",
            pattern=r"\s+COMPRESS\s*(?:\([^)]*\))?",
            replacement="",
            description="Remove COMPRESS column attribute",
            category=RuleCategories.TABLE
        ),
        ConversionRule(
            name="casespecific",
            pattern=r"\s*(?:NOT\s+)?CASESPECIFIC\b",
            replacement="",
            description="Remove (NOT) CASESPECIFIC",
            category=RuleCategories.TABLE
        ),
    ]


def get_datatype_rules() -> List[ConversionRule]:
    """Get data type conversion rules."""
    return [
        ConversionRule(
            name="byteint_to_tinyint",
            pattern=r"\bBYTEINT\b",
            replacement="TINYINT",
            description="BYTEINT → TINYINT",
            category=RuleCategories.DATATYPE
        ),
        ConversionRule(
            name="number_star",
            pattern=r"\bNUMBER\s*\(\s*\*\s*\)",
            replacement="NUMBER(38,0)",
            description="NUMBER(*) → NUMBER(38,0)",
            category=RuleCategories.DATATYPE
        ),
        ConversionRule(
            name="long_varchar",
            pattern=r"\bLONG\s+VARCHAR\b",
            replacement="VARCHAR(16777216)",
            description="LONG VARCHAR → VARCHAR(max)",
            category=RuleCategories.DATATYPE
        ),
        ConversionRule(
            name="clob",
            pattern=r"\bCLOB\b",
            replacement="VARCHAR(16777216)",
            description="CLOB → VARCHAR(max)",
            category=RuleCategories.DATATYPE
        ),
    ]


def get_date_rules() -> List[ConversionRule]:
    """Get date/time function conversion rules."""
    return [
        ConversionRule(
            name="add_months_simple",
            pattern=r"ADD_MONTHS\s*\(\s*([^,()]+?)\s*,\s*(-?\d+)\s*\)",
            replacement=r"DATEADD(MONTH, \2, \1)",
            description="ADD_MONTHS(d, n) → DATEADD(MONTH, n, d)",
            category=RuleCategories.DATE
        ),
        ConversionRule(
            name="add_months_complex",
            pattern=r"ADD_MONTHS\s*\(\s*([^,\n]+?)\s*,\s*([^)\n]+?)\s*\)",
            replacement=r"DATEADD(MONTH, \2, \1)",
            description="ADD_MONTHS with expression → DATEADD",
            category=RuleCategories.DATE
        ),
        ConversionRule(
            name="interval_month_cast",
            pattern=r"CAST\s*\(\s*\(\s*([^-()]+?)\s*-\s*([^)]+?)\s*\)\s*MONTH\s*\(\s*\d+\s*\)\s*AS\s+INTEGER\s*\)",
            replacement=r"DATEDIFF(MONTH, \2, \1)",
            description="Date interval MONTH → DATEDIFF",
            category=RuleCategories.DATE
        ),
        ConversionRule(
            name="interval_month_cast_casted_dates",
            pattern=r"CAST\s*\(\s*\(\s*([^:]+?)::DATE\s*-\s*([^:]+?)::DATE\s*\)\s*MONTH\s*\(\s*\d+\s*\)\s*AS\s+INTEGER\s*\)",
            replacement=r"DATEDIFF(MONTH, \2::DATE, \1::DATE)",
            description="Date interval MONTH with ::DATE casts → DATEDIFF",
            category=RuleCategories.DATE
        ),
        ConversionRule(
            name="interval_month_nested_cast",
            pattern=r"CAST\s*\(\s*\(\s*CAST\s*\(\s*([^)]+?)\s+AS\s+DATE\s*\)\s*-\s*CAST\s*\(\s*([^)]+?)\s+AS\s+DATE\s*\)\s*\)\s*MONTH\s*\(\s*\d+\s*\)\s*AS\s+INTEGER\s*\)",
            replacement=r"DATEDIFF(MONTH, CAST(\2 AS DATE), CAST(\1 AS DATE))",
            description="Date interval MONTH with nested CAST → DATEDIFF",
            category=RuleCategories.DATE
        ),
        ConversionRule(
            name="interval_month_mixed_cast",
            pattern=r"CAST\s*\(\s*\(\s*\(\s*CAST\s*\(\s*([\w.]+)\s+AS\s+DATE\s*\)\s*-\s*([\w.]+)::DATE\s*\)\s*MONTH\s*\(\s*\d+\s*\)\s*\)\s*AS\s+INTEGER\s*\)",
            replacement=r"DATEDIFF(MONTH, \2::DATE, CAST(\1 AS DATE))",
            description="Date interval MONTH with CAST/::DATE mix → DATEDIFF",
            category=RuleCategories.DATE
        ),
        ConversionRule(
            name="interval_month_mixed_cast_reverse",
            pattern=r"CAST\s*\(\s*\(\s*\(\s*([\w.]+)::DATE\s*-\s*CAST\s*\(\s*([\w.]+)\s+AS\s+DATE\s*\)\s*\)\s*MONTH\s*\(\s*\d+\s*\)\s*\)\s*AS\s+INTEGER\s*\)",
            replacement=r"DATEDIFF(MONTH, CAST(\2 AS DATE), \1::DATE)",
            description="Date interval MONTH with ::DATE/CAST mix → DATEDIFF",
            category=RuleCategories.DATE
        ),
        ConversionRule(
            name="interval_month_simple",
            pattern=r"\(\s*([\w.]+)\s*-\s*([\w.]+)\s*\)\s*MONTH\s*\(\s*\d+\s*\)",
            replacement=r"DATEDIFF(MONTH, \2, \1)",
            description="Simple date interval MONTH → DATEDIFF",
            category=RuleCategories.DATE
        ),
        ConversionRule(
            name="interval_day",
            pattern=r"CAST\s*\(\s*\(\s*([^-]+?)\s*-\s*([^)]+?)\s*\)\s*DAY\s*\(\s*\d+\s*\)\s*AS\s+INTEGER\s*\)",
            replacement=r"DATEDIFF(DAY, \2, \1)",
            description="Date interval DAY → DATEDIFF",
            category=RuleCategories.DATE
        ),
        ConversionRule(
            name="current_date_no_parens",
            pattern=r"\bCURRENT_DATE\b(?!\s*\()",
            replacement="CURRENT_DATE()",
            description="CURRENT_DATE → CURRENT_DATE()",
            category=RuleCategories.DATE
        ),
        ConversionRule(
            name="current_timestamp_no_parens",
            pattern=r"\bCURRENT_TIMESTAMP\b(?!\s*\()",
            replacement="CURRENT_TIMESTAMP()",
            description="CURRENT_TIMESTAMP → CURRENT_TIMESTAMP()",
            category=RuleCategories.DATE
        ),
        ConversionRule(
            name="date_format_cast_nested",
            pattern=r"CAST\s*\(\s*(CAST\s*\([^)]*(?:\([^)]*\))[^)]*\))\s+AS\s+DATE\s+FORMAT\s+'([^']+)'\s*\)",
            replacement=r"TO_DATE(\1, '\2')",
            description="Nested CAST AS DATE FORMAT → TO_DATE (handles VARCHAR(n) inside)",
            category=RuleCategories.DATE
        ),
        ConversionRule(
            name="date_format_cast_varchar",
            pattern=r"CAST\s*\(\s*([^:]+?::VARCHAR\s*\(\s*\d+\s*\))\s+AS\s+DATE\s+FORMAT\s+'([^']+)'\s*\)",
            replacement=r"TO_DATE(\1, '\2')",
            description="CAST(expr::VARCHAR(n) AS DATE FORMAT) → TO_DATE",
            category=RuleCategories.DATE
        ),
        ConversionRule(
            name="date_format_cast",
            pattern=r"CAST\s*\(\s*([^\s]+)\s+AS\s+DATE\s+FORMAT\s+'([^']+)'\s*\)",
            replacement=r"TO_DATE(\1, '\2')",
            description="CAST AS DATE FORMAT → TO_DATE",
            category=RuleCategories.DATE
        ),
        ConversionRule(
            name="date_literal",
            pattern=r"\bDATE\s+'(\d{4}-\d{2}-\d{2})'",
            replacement=r"'\1'::DATE",
            description="DATE literal → ::DATE cast",
            category=RuleCategories.DATE
        ),
        ConversionRule(
            name="timestamp_literal",
            pattern=r"\bTIMESTAMP\s+'([^']+)'",
            replacement=r"'\1'::TIMESTAMP",
            description="TIMESTAMP literal → ::TIMESTAMP cast",
            category=RuleCategories.DATE
        ),
        ConversionRule(
            name="extract_year",
            pattern=r"EXTRACT\s*\(\s*YEAR\s+FROM\s+([^)]+?)\s*\)",
            replacement=r"YEAR(\1)",
            description="EXTRACT YEAR → YEAR()",
            category=RuleCategories.DATE
        ),
        ConversionRule(
            name="extract_month",
            pattern=r"EXTRACT\s*\(\s*MONTH\s+FROM\s+([^)]+?)\s*\)",
            replacement=r"MONTH(\1)",
            description="EXTRACT MONTH → MONTH()",
            category=RuleCategories.DATE
        ),
        ConversionRule(
            name="extract_day",
            pattern=r"EXTRACT\s*\(\s*DAY\s+FROM\s+([^)]+?)\s*\)",
            replacement=r"DAY(\1)",
            description="EXTRACT DAY → DAY()",
            category=RuleCategories.DATE
        ),
        ConversionRule(
            name="extract_hour",
            pattern=r"EXTRACT\s*\(\s*HOUR\s+FROM\s+([^)]+?)\s*\)",
            replacement=r"HOUR(\1)",
            description="EXTRACT HOUR → HOUR()",
            category=RuleCategories.DATE
        ),
        ConversionRule(
            name="last_day",
            pattern=r"\bLAST_DAY\s*\(",
            replacement="LAST_DAY(",
            description="LAST_DAY (compatible)",
            category=RuleCategories.DATE
        ),
    ]


def get_string_rules() -> List[ConversionRule]:
    """Get string function conversion rules."""
    return [
        ConversionRule(
            name="oreplace",
            pattern=r"\bOREPLACE\s*\(",
            replacement="REPLACE(",
            description="OREPLACE → REPLACE",
            category=RuleCategories.STRING
        ),
        ConversionRule(
            name="otranslate",
            pattern=r"\bOTRANSLATE\s*\(",
            replacement="TRANSLATE(",
            description="OTRANSLATE → TRANSLATE",
            category=RuleCategories.STRING
        ),
        ConversionRule(
            name="characters",
            pattern=r"\bCHARACTERS\s*\(",
            replacement="LENGTH(",
            description="CHARACTERS → LENGTH",
            category=RuleCategories.STRING
        ),
        ConversionRule(
            name="chars_function",
            pattern=r"\bCHARS\s*\(",
            replacement="LENGTH(",
            description="CHARS → LENGTH (Teradata abbreviation)",
            category=RuleCategories.STRING
        ),
        # TRIM LEADING/TRAILING/BOTH rules are handled by
        # _convert_trim_functions in converter.py (needs parenthesis
        # depth tracking that simple regex cannot provide)
        ConversionRule(
            name="index_function",
            pattern=r"\bINDEX\s*\(\s*([^,]+?)\s*,\s*'([^']+)'\s*\)",
            replacement=r"POSITION('\2' IN \1)",
            description="INDEX → POSITION",
            category=RuleCategories.STRING
        ),
        ConversionRule(
            name="translate_chk_latin",
            pattern=r"TRANSLATE_CHK\s*\(\s*([^)]+?)\s+USING\s+LATIN_TO_UNICODE\s*\)\s*=\s*0",
            replacement=r"TRY_TO_NUMBER(REGEXP_REPLACE(\1, '[^0-9]', '')) IS NOT NULL",
            description="TRANSLATE_CHK LATIN_TO_UNICODE → TRY_TO_NUMBER with REGEXP",
            category=RuleCategories.STRING
        ),
        ConversionRule(
            name="substring_from_for",
            pattern=r"SUBSTRING\s*\(\s*([^\s]+)\s+FROM\s+(\d+)\s+FOR\s+(\d+)\s*\)",
            replacement=r"SUBSTR(\1, \2, \3)",
            description="SUBSTRING FROM FOR → SUBSTR",
            category=RuleCategories.STRING
        ),
        ConversionRule(
            name="strtok",
            pattern=r"\bSTRTOK\s*\(",
            replacement="SPLIT_PART(",
            description="STRTOK → SPLIT_PART",
            category=RuleCategories.STRING
        ),
    ]


def get_cast_rules() -> List[ConversionRule]:
    """Get cast operation conversion rules."""
    return [
        ConversionRule(
            name="cast_decimal_simple",
            pattern=r"CAST\s*\(\s*([\w.]+)\s+AS\s+DECIMAL\s*\(\s*(\d+)\s*,\s*(\d+)\s*\)\s*\)",
            replacement=r"\1::DECIMAL(\2,\3)",
            description="CAST AS DECIMAL → ::DECIMAL",
            category=RuleCategories.CAST
        ),
        ConversionRule(
            name="cast_integer_simple",
            pattern=r"CAST\s*\(\s*([\w.]+)\s+AS\s+INTEGER\s*\)",
            replacement=r"\1::INTEGER",
            description="CAST AS INTEGER → ::INTEGER",
            category=RuleCategories.CAST
        ),
        ConversionRule(
            name="cast_varchar_simple",
            pattern=r"CAST\s*\(\s*([\w.]+)\s+AS\s+VARCHAR\s*\(\s*(\d+)\s*\)\s*\)",
            replacement=r"\1::VARCHAR(\2)",
            description="CAST AS VARCHAR → ::VARCHAR",
            category=RuleCategories.CAST
        ),
        ConversionRule(
            name="cast_float_simple",
            pattern=r"CAST\s*\(\s*([\w.]+)\s+AS\s+FLOAT\s*\)",
            replacement=r"\1::FLOAT",
            description="CAST AS FLOAT → ::FLOAT",
            category=RuleCategories.CAST
        ),
        ConversionRule(
            name="cast_date_simple",
            pattern=r"CAST\s*\(\s*([\w.]+)\s+AS\s+DATE\s*\)",
            replacement=r"\1::DATE",
            description="CAST AS DATE → ::DATE",
            category=RuleCategories.CAST
        ),
        ConversionRule(
            name="cast_date_literal",
            pattern=r"CAST\s*\(\s*'([^']+)'\s+AS\s+DATE\s*\)",
            replacement=r"'\1'::DATE",
            description="CAST('literal' AS DATE) → 'literal'::DATE",
            category=RuleCategories.CAST
        ),
        ConversionRule(
            name="cast_timestamp_literal",
            pattern=r"CAST\s*\(\s*'([^']+)'\s+AS\s+TIMESTAMP\s*(?:\(\d+\))?\s*\)",
            replacement=r"'\1'::TIMESTAMP",
            description="CAST('literal' AS TIMESTAMP) → 'literal'::TIMESTAMP",
            category=RuleCategories.CAST
        ),
        ConversionRule(
            name="cast_varchar_fill_char",
            pattern=r"CAST\s*\(\s*(.+?)\s+AS\s+VARCHAR\s*\(\s*(\d+)\s*,\s*'([^']+)'\s*\)\s*\)",
            replacement=r"LPAD(\1::VARCHAR(\2), \2, '\3')",
            description="CAST(x AS VARCHAR(n, 'fill')) → LPAD(x::VARCHAR(n), n, 'fill')",
            category=RuleCategories.CAST
        ),
    ]


def get_syntax_rules() -> List[ConversionRule]:
    """Get miscellaneous syntax conversion rules."""
    return [
        ConversionRule(
            name="delete_all",
            pattern=r"\bDELETE\s+([\w.]+)\s+ALL\s*;",
            replacement=r"DELETE FROM \1;",
            description="DELETE table ALL → DELETE FROM table",
            category=RuleCategories.SYNTAX
        ),
        ConversionRule(
            name="sel_to_select_line_start",
            pattern=r"(?m)^(\s*)SEL\s+",
            replacement=r"\1SELECT ",
            flags=re.IGNORECASE | re.MULTILINE,
            description="Line-start SEL → SELECT",
            category=RuleCategories.SYNTAX
        ),
        ConversionRule(
            name="sel_to_select_inline",
            pattern=r"\(\s*SEL\s+",
            replacement="(SELECT ",
            flags=re.IGNORECASE,
            description="Inline (SEL → (SELECT",
            category=RuleCategories.SYNTAX
        ),
        ConversionRule(
            name="nullifzero",
            pattern=r"\bNULLIFZERO\s*\(\s*([^)]+?)\s*\)",
            replacement=r"NULLIF(\1, 0)",
            description="NULLIFZERO → NULLIF(x, 0)",
            category=RuleCategories.SYNTAX
        ),
        ConversionRule(
            name="zeroifnull",
            pattern=r"\bZEROIFNULL\s*\(\s*([^)]+?)\s*\)",
            replacement=r"COALESCE(\1, 0)",
            description="ZEROIFNULL → COALESCE(x, 0)",
            category=RuleCategories.SYNTAX
        ),
        ConversionRule(
            name="sample_to_limit",
            pattern=r"\bSAMPLE\s+(\d+)\b",
            replacement=r"LIMIT \1",
            description="SAMPLE n → LIMIT n",
            category=RuleCategories.SYNTAX
        ),
        ConversionRule(
            name="top_to_limit",
            pattern=r"\bTOP\s+(\d+)\b",
            replacement=r"LIMIT \1",
            description="TOP n → LIMIT n",
            category=RuleCategories.SYNTAX
        ),
        ConversionRule(
            name="format_clause",
            pattern=r"\s*\(FORMAT\s+'[^']+'\)",
            replacement="",
            description="Remove FORMAT clause",
            category=RuleCategories.SYNTAX
        ),
        ConversionRule(
            name="title_clause",
            pattern=r"\s*\(TITLE\s+'[^']+'\)",
            replacement="",
            description="Remove TITLE clause",
            category=RuleCategories.SYNTAX
        ),
        ConversionRule(
            name="named_clause",
            pattern=r"\s*\(NAMED\s+'[^']+'\)",
            replacement="",
            description="Remove NAMED clause",
            category=RuleCategories.SYNTAX
        ),
        ConversionRule(
            name="activity_count",
            pattern=r"\bACTIVITY_COUNT\b",
            replacement="SQLROWCOUNT",
            description="ACTIVITY_COUNT → SQLROWCOUNT",
            category=RuleCategories.SYNTAX
        ),
        ConversionRule(
            name="resignal",
            pattern=r"\bRESIGNAL\b",
            replacement="RAISE",
            description="RESIGNAL → RAISE",
            category=RuleCategories.SYNTAX
        ),
        ConversionRule(
            name="begin_label",
            pattern=r"(\w+):\s*BEGIN\b",
            replacement="BEGIN",
            description="Remove labeled BEGIN",
            category=RuleCategories.SYNTAX
        ),
        ConversionRule(
            name="end_label",
            pattern=r"\bEND\s+(?!IF\b|LOOP\b|WHILE\b|FOR\b|CASE\b)(\w+)\s*;",
            replacement="END;",
            description="Remove labeled END (preserves END IF, END LOOP, etc.)",
            category=RuleCategories.SYNTAX
        ),
        ConversionRule(
            name="set_to_let",
            pattern=r"^\s*SET\s+(\w+)\s*=\s*",
            replacement=r"\1 := ",
            flags=re.IGNORECASE | re.MULTILINE,
            description="SET var = → var := (in procedures)",
            category=RuleCategories.SYNTAX
        ),
        ConversionRule(
            name="declare_default",
            pattern=r"DECLARE\s+(\w+)\s+(\w+(?:\([^)]*\))?)\s+DEFAULT\s+([^;]+);",
            replacement=r"\1 \2 DEFAULT \3;",
            description="DECLARE with DEFAULT",
            category=RuleCategories.SYNTAX
        ),
        ConversionRule(
            name="declare_simple",
            pattern=r"DECLARE\s+(\w+)\s+(\w+(?:\([^)]*\))?)\s*;",
            replacement=r"\1 \2;",
            description="DECLARE variable",
            category=RuleCategories.SYNTAX
        ),
        ConversionRule(
            name="interval_quoted_unit",
            pattern=r"INTERVAL\s+'(\d+)'\s+(SECOND|MINUTE|HOUR|DAY|MONTH|YEAR)",
            replacement=r"INTERVAL '\1 \2'",
            flags=re.IGNORECASE,
            description="INTERVAL 'n' UNIT → INTERVAL 'n UNIT'",
            category=RuleCategories.SYNTAX
        ),
        ConversionRule(
            name="drop_table_if_exists",
            pattern=r"\bDROP\s+TABLE\s+(?!IF\s+EXISTS\b)(\w+)\s*;",
            replacement=r"DROP TABLE IF EXISTS \1;",
            flags=re.IGNORECASE,
            description="DROP TABLE → DROP TABLE IF EXISTS",
            category=RuleCategories.SYNTAX
        ),
        ConversionRule(
            name="sys_calendar_warning",
            pattern=r"\bSYS_CALENDAR\.(\w+)",
            replacement=r"/* TODO: Replace SYS_CALENDAR.\1 with custom calendar table */ SYS_CALENDAR.\1",
            flags=re.IGNORECASE,
            description="Flag SYS_CALENDAR for manual review",
            category=RuleCategories.SYNTAX
        ),
        ConversionRule(
            name="out_param_to_return",
            pattern=r"\(OUT\s+(\w+)\s+(\w+(?:\([^)]*\))?)\s*\)",
            replacement=r"()",
            flags=re.IGNORECASE,
            description="Remove OUT parameter (use RETURN instead)",
            category=RuleCategories.PROCEDURE
        ),
        ConversionRule(
            name="locking_for_access",
            pattern=r"LOCKING\s+(?:ROW|TABLE|[\w.]+)\s+FOR\s+ACCESS\s*\n?",
            replacement="",
            description="Remove LOCKING ... FOR ACCESS",
            category=RuleCategories.SYNTAX
        ),
        ConversionRule(
            name="collect_statistics",
            pattern=r"COLLECT\s+STAT(?:ISTIC)?S\b(?:(?!\*/)[^;])*;",
            replacement="-- COLLECT STATISTICS removed (Snowflake auto-manages statistics)",
            description="Remove COLLECT STATISTICS",
            category=RuleCategories.SYNTAX
        ),
        ConversionRule(
            name="database_to_use",
            pattern=r"^\s*DATABASE\s+([\w.]+)\s*;",
            replacement=r"USE DATABASE \1;",
            flags=re.IGNORECASE | re.MULTILINE,
            description="DATABASE dbname → USE DATABASE dbname",
            category=RuleCategories.SYNTAX
        ),
        ConversionRule(
            name="dot_date",
            pattern=r"(?<!\w)\.DATE\b",
            replacement="CURRENT_DATE",
            description=".DATE → CURRENT_DATE",
            category=RuleCategories.SYNTAX
        ),
    ]


def get_all_rules() -> List[ConversionRule]:
    """Get all conversion rules."""
    return (
        get_procedure_rules() +
        get_table_rules() +
        get_datatype_rules() +
        get_date_rules() +
        get_string_rules() +
        get_cast_rules() +
        get_syntax_rules()
    )


def get_rules_by_category(category: str) -> List[ConversionRule]:
    """Get rules filtered by category."""
    return [r for r in get_all_rules() if r.category == category]
