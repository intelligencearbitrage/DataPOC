"""
Teradata to Snowflake SQL Converter
===================================

A modular, configurable converter for transforming Teradata SQL to Snowflake SQL.

Usage:
    # Single file conversion
    from converter import TeradataToSnowflakeConverter
    converter = TeradataToSnowflakeConverter()
    result = converter.convert(teradata_sql)

    # Batch folder conversion
    from converter import BatchProcessor
    processor = BatchProcessor(config_file='converter_config.json')
    result = processor.process_batch()

    # Quick folder conversion
    from converter import process_folder
    result = process_folder('./input', './output')
"""

from .rules import (
    ConversionRule,
    RuleCategories,
    get_all_rules,
    get_procedure_rules,
    get_table_rules,
    get_date_rules,
    get_string_rules,
    get_cast_rules,
    get_syntax_rules,
    get_datatype_rules,
)

from .converter import (
    TeradataToSnowflakeConverter,
    ConversionResult,
)

from .batch_processor import (
    BatchProcessor,
    BatchConversionResult,
    FileConversionResult,
    process_folder,
)

__version__ = '1.0.0'
__author__ = 'M&T Bank'

__all__ = [
    # Rules
    'ConversionRule',
    'RuleCategories',
    'get_all_rules',
    'get_procedure_rules',
    'get_table_rules',
    'get_date_rules',
    'get_string_rules',
    'get_cast_rules',
    'get_syntax_rules',
    'get_datatype_rules',
    # Converter
    'TeradataToSnowflakeConverter',
    'ConversionResult',
    # Batch
    'BatchProcessor',
    'BatchConversionResult',
    'FileConversionResult',
    'process_folder',
]
