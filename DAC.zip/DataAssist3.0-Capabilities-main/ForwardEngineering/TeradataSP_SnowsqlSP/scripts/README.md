# TD to SnowSQL Hybrid Conversion Toolkit

A toolkit-template-based system for converting Teradata SQL to Snowflake SQL using a **rules-first + LLM review** approach with agent team orchestration.

> **How it works:** The rules engine (62+ regex/structural rules) converts everything first. Then an LLM reviewer checks the output and suggests targeted fixes — each fix is validated individually and only accepted if it doesn't degrade the score. The rules output is always the baseline fallback.

> **New here?** Start with `SETUP_GUIDE.md` — it walks you through everything from install to first run.

---

## Architecture Overview

```
┌─────────────────────────────────────────────────────────────────────────┐
│                          DEVELOPER INPUTS                              │
│                                                                        │
│   prompts.md              knowledgebase/            GUARDRAILS.yaml    │
│   (your requirements)     (reference materials)     (quality rules)    │
└──────────┬──────────────────────┬──────────────────────────┬───────────┘
           │                      │                          │
           ▼                      ▼                          ▼
┌─────────────────────────────────────────────────────────────────────────┐
│                        LEAD ORCHESTRATOR                               │
│         Reads prompts.md → Consults experts → Creates tasks            │
└──────────┬──────────────────────────────────────────────────────────────┘
           │
           │ creates tasks with dependencies
           ▼
┌─────────────────────────────────────────────────────────────────────────┐
│                        SHARED TASK LIST                                 │
│    TaskCreate / TaskUpdate / TaskList / TaskGet                         │
│    (all agents communicate through here — no direct messaging)         │
└──┬──────────┬──────────────┬──────────────┬──────────────┬─────────────┘
   │          │              │              │              │
   ▼          ▼              ▼              ▼              ▼
┌────────┐ ┌───────────┐ ┌───────────┐ ┌───────────┐ ┌───────────────────┐
│RESEARCH│ │ PLANNING  │ │  BUILD    │ │  REVIEW   │ │  DOMAIN EXPERTS   │
│  er    │ │ Analyz er │ │  Build er │ │ Review er │ │                   │
│        │ │           │ │           │ │           │ │ Snowflake Expert   │
│ Writes │ │ Writes    │ │ Writes    │ │ Writes    │ │ Teradata Expert    │
│  to:   │ │  to:      │ │  to:      │ │  to:      │ │ Quality Expert    │
│research│ │ plans/    │ │ scripts/  │ │testscripts│ │                   │
│  /     │ │           │ │           │ │  /        │ │ Write to:         │
│        │ │           │ │           │ │           │ │ research/expert/  │
└───┬────┘ └─────┬─────┘ └─────┬─────┘ └─────┬─────┘ └───────────────────┘
    │            │              │              │
    ▼            ▼              ▼              ▼
┌────────┐ ┌─────────┐  ┌───────────┐  ┌───────────┐
│ GATE 1 │ │ GATE 2  │  │  GATE 3   │  │  FINAL    │
│validate│ │validate │  │ validate  │  │ guardrails│
│research│ │ plans   │  │  scripts  │  │  check    │
└────────┘ └─────────┘  └─────┬─────┘  └───────────┘
                               │
                               ▼
                       ┌──────────────┐
                       │   output/    │
                       │  (converted  │
                       │  Snowflake   │
                       │    SQL)      │
                       └──────────────┘
```

**Key concepts:**
- **Developer provides** 3 things: `prompts.md` (what to build), `knowledgebase/` (reference materials), and `inputs/` (source Teradata SQL to convert)
- **11 agents** work autonomously — 1 lead, 7 teammates, 3 domain experts
- **4 phases** run sequentially with **quality gates** between each
- **Two-layer architecture**: scripts-only mode for quick runs, or agentic mode (validator + refiner) for automated quality loops — run `setup agentic layer` after the pipeline completes. See `SOLUTION_APPROACH.md`
- **Agents never talk directly** — all coordination happens through the shared task list
- **Each agent writes to its own folder** — folder boundaries are enforced by guardrails

---

## Quick Start

```bash
# 1. Install dependencies
pip install -r requirements.txt
pip install anthropic python-dotenv   # for LLM review

# 2. Set up LLM credentials (for the review layer)
cp .env.example .env
# Edit .env with your API credentials:
#   ANTHROPIC_FOUNDRY_API_KEY=your-key
#   ANTHROPIC_FOUNDRY_RESOURCE=your-resource

# 3. Place Teradata SQL files
cp /path/to/teradata/*.sql knowledgebase/

# 4. Update schema mappings
# Edit config/converter_config.json with your schema mappings

# 5. Run conversion (choose one method)

# Method A: Agent team (recommended)
# Set CLAUDE_CODE_EXPERIMENTAL_AGENT_TEAMS=1
# Then: claude "start project"

# Method B: CLI with LLM review (single file)
python run_convert.py input.sql                # auto-detect review mode
python run_convert.py input.sql --review       # force LLM review on
python run_convert.py input.sql --no-review    # pure rules only
python run_convert.py input.sql --force-review # LLM review even if validation passes

# Method C: Pipeline script
python scripts/pipeline/build_all.py --pipeline

# Method D: Step by step
python scripts/pipeline/analyze_complexity.py
python scripts/pipeline/convert_sql.py
python scripts/pipeline/validate_sql.py
python scripts/pipeline/correct_sql.py
python scripts/pipeline/generate_reports.py

# 6. (Optional) Set up the agentic validation & refinement layer
# After pipeline completes and output/ has been generated:
# claude "setup agentic layer"
# Then:
# python scripts/validator.py        # validate output against source
# python scripts/refiner.py          # patch output based on validation errors
```

## Architecture

This toolkit follows the **toolkit-template** pattern with 4 phases:

### Phase 1: Research & Analysis
- **Agent:** researcher-agent
- **Script:** `scripts/pipeline/analyze_complexity.py`
- Analyzes SQL complexity, calculates confidence scores
- Output: `research/{filename}_complexity.json`

### Phase 2: Planning
- **Agent:** analyzer-agent
- **Script:** `scripts/plan_conversion.py`
- Creates conversion plan from complexity reports
- Output: `plans/conversion_plan.yaml`

### Phase 3: Implementation (Rules + LLM Review)
- **Agent:** builder-agent
- **Scripts:** `scripts/pipeline/convert_sql.py` (uses `ReviewTeradataConverter`)
- **Step 1:** Rules engine applies 62+ conversion rules
- **Step 2:** Validates the rules output
- **Step 3:** If issues found and LLM available, sends to LLM for review
- **Step 4:** LLM suggests targeted JSON fixes (not full rewrites)
- **Step 5:** Each fix validated individually — only accepted if score doesn't drop
- Output: `output/{filename}.sql`

### Phase 4: Review & Validation
- **Agent:** reviewer-agent
- **Scripts:** `scripts/pipeline/validate_sql.py`, `scripts/pipeline/correct_sql.py`, `scripts/pipeline/generate_reports.py`
- Validates with 54+ rules, corrects with 55+ rules
- Output: `testscripts/`, `output/conversion_report.md`

### Optional: Agentic Validation & Refinement
After the pipeline completes, optionally add automated validation and refinement:
```
setup agentic layer
```
This generates `validator.py`, `refiner.py`, and `prompts.py` in `scripts/`, tailored to your project. See `SOLUTION_APPROACH.md` for the full agentic architecture.

## Directory Structure

```
TD-SnowSQL-Toolkit/
├── .claude/                    # Agent team configuration
│   ├── settings.json           # 11 agents, 5 skills, 4 phases
│   ├── agents/                 # Agent definitions (11 agents)
│   │   ├── lead-orchestrator.md
│   │   ├── researcher-agent.md
│   │   ├── analyzer-agent.md
│   │   ├── builder-agent.md
│   │   ├── reviewer-agent.md
│   │   ├── peer-reviewer-agent.md
│   │   ├── devils-advocate-agent.md
│   │   ├── devils-advocate-soul.md
│   │   ├── expert-snowflake.md
│   │   ├── expert-teradata.md
│   │   ├── expert-quality.md
│   │   └── agentic-setup-agent.md
│   ├── skills/                 # Skill definitions (5 skills)
│   └── rules/                  # Auto-loaded rules
│       └── escalation.md       # Escalation protocol for stuck agents
├── scripts/                    # Python modules
│   ├── converter/              # 62+ conversion rules
│   ├── validator/              # 54+ validation rules
│   ├── corrector/              # 55+ correction rules
│   ├── base_parser.py          # Abstract parser base
│   ├── base_generator.py       # Abstract generator base
│   ├── base_validator.py       # Abstract validator base
│   ├── utils.py                # Shared utilities
│   ├── build_all.py            # Master pipeline runner
│   ├── llm_reviewer.py         # LLM review client (Anthropic API / Foundry)
│   ├── review_converter.py     # Rules-first + LLM review orchestrator
│   ├── prompts.py              # Centralized prompts for validator/refiner  (generated by "setup agentic layer")
│   ├── validator.py            # Validates output/ vs inputs/              (generated by "setup agentic layer")
│   └── refiner.py              # Patches output/ based on validation errors (generated by "setup agentic layer")
├── guardrails/                 # Quality enforcement
├── knowledgebase/              # Reference materials (conversion rules, SQL reference)
├── inputs/                     # Source Teradata SQL files to convert
├── research/                   # Phase 1: Complexity reports
│   └── expert/                 # Expert assessments
├── plans/                      # Phase 2: Conversion plans
├── output/                     # Phase 3-4: Converted SQL + reports
├── testscripts/                # Phase 4: Validation reports
├── thoughts/logs/              # Execution logs
├── config/                     # Configuration files
├── guidelines/                 # Authoring guides and rules references
│   ├── AGENT_AUTHORING.md
│   ├── KNOWLEDGE_ORGANIZATION.md
│   ├── SKILL_AUTHORING.md
│   └── rules-reference/        # Domain-specific rule templates
├── CLAUDE.md                   # Project instructions for all agents
├── CLAUDE_guidelines.md        # LLM behavioral guidelines
├── GUARDRAILS.yaml             # Quality rules and boundaries
├── SOLUTION_APPROACH.md        # Two-layer architecture documentation
├── SETUP_GUIDE.md              # Step-by-step setup instructions
├── PROMPT_TEMPLATE.md          # How to write grounded prompts
├── prompts.md                  # Project requirements
├── .env.example                # API credentials template
└── .env                        # Your API credentials (not committed)
```

## The 11 Agents

### Core Teammates (do the work)

| Agent | Role | Owns Folder | What It Does |
|-------|------|-------------|--------------|
| **Lead Orchestrator** | lead | thoughts/ | Reads prompts.md, consults experts, creates tasks with dependencies and phase gates, monitors progress |
| **Researcher** | teammate | research/ | Analyzes SQL complexity and calculates confidence scores |
| **Analyzer** | teammate | plans/ | Synthesizes complexity reports into conversion plans |
| **Builder** | teammate | scripts/ | Creates and runs the conversion pipeline (rules + LLM review) |
| **Reviewer** | teammate | testscripts/ | Validates converted SQL and applies corrections |
| **Peer Reviewer** | teammate | testscripts/ | Reviews individual scripts asynchronously during Phase 3. Creates fix tasks for issues. |
| **Devil's Advocate** | teammate | testscripts/ | Challenges plans (Phase 2) and script assumptions (Phase 3). FAIL verdict is a hard block. |
| **Agentic Setup** | teammate | scripts/ | Generates validator.py, refiner.py, prompts.py for the agentic layer |

### Domain Experts (consulted on demand)

| Expert | Specialty | Owns Folder | When Consulted |
|--------|-----------|-------------|----------------|
| **Snowflake Expert** | Snowflake SQL optimization and best practices | research/expert/ | When optimizing converted SQL for Snowflake |
| **Teradata Expert** | Teradata SQL semantics and migration patterns | research/expert/ | When verifying source SQL interpretation |
| **Quality Expert** | Testing strategy, validation, phase gates | research/expert/ | When defining what "done" means |

## Core Modules

### Converter (62+ rules)
Transforms Teradata SQL to Snowflake using regex-based rules across 7 categories: procedures, tables, data types, date functions, string functions, casts, and syntax.

### LLM Reviewer (`scripts/llm_reviewer.py`)
Reviews rules-converted SQL using an LLM (Claude) and suggests targeted fixes as structured JSON. Supports both Anthropic Foundry and direct API. Each fix includes confidence level and category. Only fixes meeting the minimum confidence threshold are considered.

### Review Converter (`scripts/review_converter.py`)
Orchestrates the hybrid pipeline: rules conversion → validation → LLM review → per-fix validation gating. Each LLM fix is applied individually and re-validated — a fix that degrades the validation score is automatically rejected.

### Validator (54+ rules)
Checks converted SQL for unconverted patterns, syntax errors, incomplete conversions, warnings, and best practice violations.

### Corrector (55+ rules)
Auto-fixes validation issues with targeted corrections mapped to validator rules.

## Configuration

### Schema Mapping
Edit `config/converter_config.json`:
```json
{
    "custom_schema_mapping": {
        "P_CUSTOMER_01": "PROD_DB.CUSTOMER_SCHEMA",
        "P_EDW_STG_01": "EDW_DB.STAGING_SCHEMA"
    }
}
```

### Rule Categories (toggle on/off)
```json
{
    "rules": {
        "convert_procedures": true,
        "convert_tables": true,
        "convert_dates": true,
        "convert_strings": true,
        "convert_casts": true,
        "convert_updates_to_merge": true,
        "convert_exception_handlers": true
    }
}
```

### LLM Review Settings
```json
{
    "llm_review": {
        "enabled": true,
        "model": "claude-opus-4-6",
        "max_tokens": 4096,
        "temperature": 0.0,
        "max_retries": 2,
        "min_confidence": "medium",
        "force_review": false
    }
}
```

Set `enabled: false` to run in pure rules-only mode. Set `force_review: true` to run LLM review even when validation passes.

## Guardrails

Run quality checks:
```bash
python guardrails/run_guardrails.py
```

Checks: input validation, folder boundaries, phase dependencies, content standards, agentic layer constraints.

## Prerequisites

- Python 3.8+
- `pip install pyyaml pandas openpyxl` (install as needed based on your input formats)
- `pip install anthropic python-dotenv` (for LLM review layer)
- API credentials in `.env` file (copy from `.env.example`)
