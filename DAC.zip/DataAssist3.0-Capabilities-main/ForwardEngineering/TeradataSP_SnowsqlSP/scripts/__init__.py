"""
TD to SnowSQL Toolkit - Scripts Package
========================================

Provides converter, validator, and corrector modules for
Teradata to Snowflake SQL conversion.
"""
