"""
End-to-end IDMC-to-dbt Conversion Pipeline.

Chains all pipeline stages in sequence:
  Stage 1: BUILD   — Parse IDMC JSON inputs + generate dbt project
  Stage 2: VALIDATE — Validate output against inputs (ground truth)
  Stage 3: REFINE  — Auto-fix validation issues + re-validate (optional)

Usage:
    python scripts/run_conversion.py                    # Full pipeline
    python scripts/run_conversion.py --skip-refine      # Build + validate only
    python scripts/run_conversion.py --max-iterations 5 # Custom refine iterations
"""

from __future__ import annotations

import argparse
import sys
import time
from pathlib import Path

# Ensure scripts/ is on the Python path
SCRIPTS_DIR = Path(__file__).resolve().parent
PROJECT_ROOT = SCRIPTS_DIR.parent
sys.path.insert(0, str(SCRIPTS_DIR))

from utils import setup_logging, get_timestamp, save_yaml


def _banner(text: str) -> str:
    """Return a formatted stage banner."""
    return f"\n{'=' * 60}\n  {text}\n{'=' * 60}"


def stage_build(logger) -> bool:
    """Stage 1: Run build_all to parse inputs and generate dbt project."""
    logger.info(_banner("STAGE 1: BUILD"))
    try:
        import build_all
        build_all.main()
        logger.info("BUILD completed successfully.")
        return True
    except SystemExit as e:
        if e.code and e.code != 0:
            logger.error(f"BUILD failed with exit code {e.code}.")
            return False
        return True
    except Exception as e:
        logger.error(f"BUILD failed: {e}")
        return False


def stage_validate(logger) -> dict:
    """Stage 2: Run validator and return results.

    Returns:
        Dict with keys: passed (bool), total, num_passed, num_issues,
        accuracy (float), report_path (str).
    """
    logger.info(_banner("STAGE 2: VALIDATE"))
    try:
        from validator import IDMCValidator

        v = IDMCValidator(target_dir="output")
        v.validate()
        report = v.generate_report()
        v.save_report(report)
        v.print_summary()

        vr = report.get("validation_report", report)
        total = vr.get("total_checks", 0)
        num_passed = vr.get("passed_checks_count", 0)
        num_issues = vr.get("issues_count", 0)
        accuracy = vr.get("overall_accuracy", (num_passed / total * 100) if total else 0.0)
        report_path = str(v._report_path) if hasattr(v, "_report_path") else ""

        return {
            "passed": num_issues == 0,
            "total": total,
            "num_passed": num_passed,
            "num_issues": num_issues,
            "accuracy": accuracy,
            "report_path": report_path,
        }
    except Exception as e:
        logger.error(f"VALIDATE failed: {e}")
        return {
            "passed": False,
            "total": 0,
            "num_passed": 0,
            "num_issues": -1,
            "accuracy": 0.0,
            "report_path": "",
            "error": str(e),
        }


def stage_refine(logger, max_iterations: int, report_path: str = "") -> dict:
    """Stage 3: Run refiner to auto-fix validation issues.

    Returns:
        Dict with keys: iterations_run, final_accuracy, final_issues.
    """
    logger.info(_banner("STAGE 3: REFINE"))
    try:
        from refiner import Refiner

        rp = Path(report_path) if report_path else None
        refiner = Refiner(
            validation_report_path=rp,
            max_iterations=max_iterations,
        )
        refiner.run()

        # Re-validate after refinement
        logger.info("Re-validating after refinement...")
        from validator import IDMCValidator

        v = IDMCValidator(target_dir="output")
        v.validate()
        report = v.generate_report()
        v.save_report(report)
        v.print_summary()

        vr = report.get("validation_report", report)
        total = vr.get("total_checks", 0)
        num_passed = vr.get("passed_checks_count", 0)
        num_issues = vr.get("issues_count", 0)
        accuracy = vr.get("overall_accuracy", (num_passed / total * 100) if total else 0.0)

        return {
            "final_accuracy": accuracy,
            "final_issues": num_issues,
            "final_total": total,
            "final_passed": num_passed,
        }
    except Exception as e:
        logger.error(f"REFINE failed: {e}")
        return {
            "final_accuracy": 0.0,
            "final_issues": -1,
            "error": str(e),
        }


def _count_output_files() -> dict:
    """Count generated output files by layer."""
    output_dir = PROJECT_ROOT / "output"
    stg = len(list((output_dir / "models" / "staging").glob("stg_*.sql"))) if (output_dir / "models" / "staging").exists() else 0
    interm = len(list((output_dir / "models" / "intermediate").rglob("int_*.sql"))) if (output_dir / "models" / "intermediate").exists() else 0
    marts = len(list((output_dir / "models" / "marts").glob("*.sql"))) if (output_dir / "models" / "marts").exists() else 0
    snaps = len(list((output_dir / "snapshots").glob("snapshot_*.sql"))) if (output_dir / "snapshots").exists() else 0
    macros = len(list((output_dir / "macros").glob("*.sql"))) if (output_dir / "macros").exists() else 0
    return {
        "staging": stg,
        "intermediate": interm,
        "marts": marts,
        "snapshots": snaps,
        "macros": macros,
        "total_sql": stg + interm + marts + snaps + macros,
    }


def main() -> None:
    """Run the full IDMC-to-dbt conversion pipeline."""
    parser = argparse.ArgumentParser(
        description="End-to-end IDMC-to-dbt conversion pipeline"
    )
    parser.add_argument(
        "--skip-refine",
        action="store_true",
        help="Skip the refinement stage (build + validate only)",
    )
    parser.add_argument(
        "--max-iterations",
        type=int,
        default=3,
        help="Maximum refinement iterations (default: 3)",
    )
    args = parser.parse_args()

    logger = setup_logging(
        "run_conversion",
        log_dir=PROJECT_ROOT / "thoughts" / "logs",
    )
    pipeline_start = time.time()

    logger.info(_banner("IDMC-to-dbt CONVERSION PIPELINE"))
    logger.info(f"Started: {get_timestamp()}")

    # ── Stage 1: BUILD ──
    build_start = time.time()
    build_ok = stage_build(logger)
    build_elapsed = time.time() - build_start

    if not build_ok:
        logger.error("Pipeline aborted — BUILD stage failed.")
        sys.exit(1)

    # ── Stage 2: VALIDATE ──
    validate_start = time.time()
    val_result = stage_validate(logger)
    validate_elapsed = time.time() - validate_start

    # ── Stage 3: REFINE (conditional) ──
    refine_result = {}
    refine_elapsed = 0.0
    if val_result["passed"]:
        logger.info("\nValidation passed at 100% — skipping refinement.")
    elif args.skip_refine:
        logger.info("\n--skip-refine specified — skipping refinement.")
    else:
        refine_start = time.time()
        refine_result = stage_refine(
            logger,
            max_iterations=args.max_iterations,
            report_path=val_result.get("report_path", ""),
        )
        refine_elapsed = time.time() - refine_start

    # ── Final Summary ──
    pipeline_elapsed = time.time() - pipeline_start
    file_counts = _count_output_files()

    final_accuracy = refine_result.get("final_accuracy") if refine_result else val_result["accuracy"]
    final_issues = refine_result.get("final_issues") if refine_result else val_result["num_issues"]

    logger.info(_banner("PIPELINE COMPLETE"))
    logger.info(f"  Build time:    {build_elapsed:.1f}s")
    logger.info(f"  Validate time: {validate_elapsed:.1f}s")
    if refine_elapsed:
        logger.info(f"  Refine time:   {refine_elapsed:.1f}s")
    logger.info(f"  Total time:    {pipeline_elapsed:.1f}s")
    logger.info("")
    logger.info(f"  Files generated:")
    logger.info(f"    Staging:      {file_counts['staging']}")
    logger.info(f"    Intermediate: {file_counts['intermediate']}")
    logger.info(f"    Marts:        {file_counts['marts']}")
    logger.info(f"    Snapshots:    {file_counts['snapshots']}")
    logger.info(f"    Macros:       {file_counts['macros']}")
    logger.info(f"    Total SQL:    {file_counts['total_sql']}")
    logger.info("")
    logger.info(f"  Validation: {final_accuracy:.2f}% accuracy, {final_issues} issue(s)")
    logger.info("=" * 60)

    # Save combined run report
    run_report = {
        "conversion_run_report": {
            "timestamp": get_timestamp(),
            "stages": {
                "build": {
                    "status": "success" if build_ok else "failed",
                    "elapsed_seconds": round(build_elapsed, 1),
                },
                "validate": {
                    "total_checks": val_result["total"],
                    "passed": val_result["num_passed"],
                    "issues": val_result["num_issues"],
                    "accuracy": round(val_result["accuracy"], 2),
                    "elapsed_seconds": round(validate_elapsed, 1),
                },
                "refine": {
                    "ran": bool(refine_result),
                    "final_accuracy": round(final_accuracy, 2),
                    "final_issues": final_issues,
                    "elapsed_seconds": round(refine_elapsed, 1),
                } if refine_result else {"ran": False},
            },
            "output_files": file_counts,
            "total_elapsed_seconds": round(pipeline_elapsed, 1),
        }
    }
    report_dir = PROJECT_ROOT / "thoughts" / "logs"
    report_dir.mkdir(parents=True, exist_ok=True)
    save_yaml(run_report, report_dir / "conversion_run_report.yaml")

    if final_issues > 0:
        sys.exit(1)


if __name__ == "__main__":
    main()
