# IDMC-to-dbt Forward Engineering Scripts

## What This Does

Converts IDMC (Informatica Data Management Cloud) JSON mapping exports into a complete dbt project for Databricks. The pipeline has three stages:

1. **Build** — Parses IDMC JSON inputs and generates a four-layer dbt project (staging, source intermediate, mapping intermediate, marts), plus optional snapshots, macros, and config files.
2. **Validate** — Compares generated output against IDMC JSON inputs (ground truth) and reports discrepancies.
3. **Refine** — Auto-patches validation issues and re-validates in a loop.

## Prerequisites

- Python 3.9+
- Install dependencies:
  ```bash
  pip install -r scripts/requirements.txt
  ```

## How to Run

All commands are executed from the **project root** directory.

### Using the CLI (recommended)

```bash
# Generate dbt models from IDMC JSON inputs
python scripts/cli.py build

# Validate generated output against inputs
python scripts/cli.py validate

# Validate specific files only
python scripts/cli.py validate --files output/models/marts/docusign_transaction.sql

# Dry run (list checks without running)
python scripts/cli.py validate --dry-run

# Auto-fix validation issues
python scripts/cli.py refine
python scripts/cli.py refine --max-iterations 5

# Run the full pipeline (build -> validate -> refine)
python scripts/cli.py run

# Build + validate only (skip refinement)
python scripts/cli.py run --skip-refine
```

### Running individual scripts directly

```bash
python scripts/build_all.py          # Build only
python scripts/validator.py          # Validate only
python scripts/refiner.py            # Refine only
python scripts/run_conversion.py     # Full pipeline
```

## Script Inventory

| Script | Purpose |
|--------|---------|
| `cli.py` | Single CLI entry point exposing all commands |
| `generate_dbt_models.py` | Core generator (~5500 lines) — translates IDMC JSON to dbt SQL |
| `build_all.py` | Discovers and runs all `generate_*.py` scripts |
| `run_conversion.py` | End-to-end pipeline orchestrator (build -> validate -> refine) |
| `validator.py` | Validates output against IDMC inputs (read-only) |
| `refiner.py` | Auto-patches output files based on validation errors |
| `prompts.py` | Centralized prompt definitions for validator and refiner |
| `base_generator.py` | Abstract base class for generators |
| `base_parser.py` | Abstract base class for input parsers |
| `base_validator.py` | Abstract base class for validators |
| `utils.py` | Shared utilities (YAML I/O, logging, path helpers) |

## Input / Output

- **Input**: IDMC JSON mapping exports in `inputs/*.json`
- **Knowledgebase**: Reference materials in `knowledgebase/` (read-only)
- **Output**: Complete dbt project in `output/` (models, snapshots, macros, config)
- **Logs**: Build and validation reports in `thoughts/logs/`

## Assumptions and Limitations

- The generator expects IDMC JSON exports in the format produced by Informatica Data Management Cloud.
- Field mapping between intermediate column names and target column names may require manual review (look for `-- TODO: MANUAL REVIEW REQUIRED` in generated SQL).
- CDC/SCD Type 2 detection is automatic but should be verified for edge cases.
- The refiner operates only on `output/` — it never modifies inputs, scripts, or knowledgebase files.
