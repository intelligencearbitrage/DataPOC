"""
IDMC-to-dbt Output Refiner.

Patches output files based on validation errors and optional human feedback.
Implements the refinement loop: patch -> re-validate -> patch again (up to
max iterations).

This script ONLY writes to output/ -- it never modifies scripts, inputs,
or knowledgebase.

Usage:
    python scripts/refiner.py
    python scripts/refiner.py --report thoughts/logs/agentic/validation_report_*.yaml
    python scripts/refiner.py --feedback feedback.txt
    python scripts/refiner.py --max-iterations 5
"""

from __future__ import annotations

import argparse
import copy
import json
import re
import sys
import time
from pathlib import Path
from typing import Any, Dict, List, Optional, Set, Tuple

# Ensure scripts/ is on the path
SCRIPTS_DIR = Path(__file__).resolve().parent
PROJECT_ROOT = SCRIPTS_DIR.parent
sys.path.insert(0, str(SCRIPTS_DIR))

from utils import get_project_root, get_timestamp, load_yaml, save_yaml, setup_logging
from prompts import (
    REFINER_SYSTEM_PROMPT,
    REFINER_PATCH_PROMPT,
    FEEDBACK_VALIDATION_PROMPT,
)

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

INPUTS_DIR = PROJECT_ROOT / "inputs"
OUTPUT_DIR = PROJECT_ROOT / "output"
KB_DIR = PROJECT_ROOT / "knowledgebase"
LOG_DIR = PROJECT_ROOT / "thoughts" / "logs" / "agentic"

# Guardrail limits from GUARDRAILS.yaml
DEFAULT_MAX_ITERATIONS = 3
MAX_LINES_PER_FIX = 50

# Directories that the refiner must NEVER write to
FORBIDDEN_WRITE_DIRS: Set[Path] = {
    PROJECT_ROOT / "scripts",
    PROJECT_ROOT / "inputs",
    PROJECT_ROOT / "knowledgebase",
}

EDH_AUDIT_COLUMNS_TEMPLATE = """\
    -- EDH audit columns
    CASE
        WHEN dbt_valid_to IS NULL THEN cast('A' AS string)
        WHEN dbt_valid_to IS NOT NULL AND next_valid_from <> dbt_valid_to THEN cast('D' AS string)
        ELSE cast('I' AS string)
    END AS edh_record_status_in,

    cast(dbt_valid_from AS timestamp) AS edh_record_start_ts,

    CASE
        WHEN dbt_valid_to IS NULL THEN cast('9999-12-31' AS timestamp)
        ELSE cast(dbt_valid_to AS timestamp)
    END AS edh_record_end_ts,

    edh_created_batch_key,
    edh_created_ts,
    edh_created_nm,
    edh_updated_batch_key,
    edh_updated_ts,
    edh_updated_nm"""


# ---------------------------------------------------------------------------
# Guardrail Enforcement
# ---------------------------------------------------------------------------

def is_safe_write_path(file_path: Path) -> bool:
    """Check if a file path is within the allowed output/ directory.

    Guardrail: output_only_writes -- refiner can only write to output/.
    """
    resolved = file_path.resolve()
    output_resolved = OUTPUT_DIR.resolve()

    # Must be inside output/
    if not str(resolved).startswith(str(output_resolved)):
        return False

    # Must not be in any forbidden directory
    for forbidden in FORBIDDEN_WRITE_DIRS:
        if str(resolved).startswith(str(forbidden.resolve())):
            return False

    return True


def check_diff_size(original: str, patched: str) -> int:
    """Count the number of lines changed between original and patched content."""
    orig_lines = original.splitlines()
    patch_lines = patched.splitlines()

    # Simple line-level diff count
    changed = 0
    max_len = max(len(orig_lines), len(patch_lines))
    for i in range(max_len):
        orig_line = orig_lines[i] if i < len(orig_lines) else ""
        patch_line = patch_lines[i] if i < len(patch_lines) else ""
        if orig_line != patch_line:
            changed += 1

    return changed


# ---------------------------------------------------------------------------
# Feedback Validation
# ---------------------------------------------------------------------------

def validate_feedback(
    feedback_text: str,
    validation_report: Dict[str, Any],
    logger: Any,
) -> Dict[str, Any]:
    """Validate human feedback before accepting it for refinement.

    Checks:
    1. Relevance -- feedback relates to validation issues or output files
    2. Actionability -- feedback can be applied as an output patch
    3. Source consistency -- feedback does not contradict inputs/knowledgebase

    Returns a dict with accepted_items, rejected_items, and the validation log.
    """
    result: Dict[str, Any] = {
        "timestamp": get_timestamp(),
        "human_feedback_raw": feedback_text,
        "validation_results": [],
        "accepted_feedback": [],
        "rejected_feedback": [],
    }

    # Split feedback into individual items (by line or sentence)
    items = [line.strip() for line in feedback_text.strip().split("\n") if line.strip()]

    # Get known issue IDs and output files from the report
    report_data = validation_report.get("validation_report", {})
    issue_ids = {i.get("id", "") for i in report_data.get("issues", [])}
    issue_descriptions = {
        i.get("description", "").lower() for i in report_data.get("issues", [])
    }
    output_files = {
        i.get("output_file", "") for i in report_data.get("issues", [])
    }

    # Get actual output file list
    actual_output_files = {
        str(f.relative_to(PROJECT_ROOT))
        for f in OUTPUT_DIR.rglob("*")
        if f.is_file()
    }

    for item in items:
        item_lower = item.lower()
        check_result = {
            "item": item,
            "relevance": "PASS",
            "actionability": "PASS",
            "source_consistency": "PASS",
            "accepted": True,
            "reason": "",
        }

        # Relevance check: does it relate to known issues or output files?
        is_relevant = False
        for issue_id in issue_ids:
            if issue_id.lower() in item_lower:
                is_relevant = True
                break
        if not is_relevant:
            for desc_fragment in issue_descriptions:
                if any(word in item_lower for word in desc_fragment.split() if len(word) > 4):
                    is_relevant = True
                    break
        if not is_relevant:
            for of in output_files | actual_output_files:
                if of.lower() in item_lower or Path(of).stem.lower() in item_lower:
                    is_relevant = True
                    break
        # Generic references to output types
        if not is_relevant:
            relevant_keywords = [
                "staging", "intermediate", "marts", "snapshot", "source.yml",
                "schema.yml", "dbt_project", "macro", "edh", "audit",
                "chksum", "ref(", "source(", "todo", "order by",
            ]
            if any(kw in item_lower for kw in relevant_keywords):
                is_relevant = True

        if not is_relevant:
            check_result["relevance"] = "FAIL"
            check_result["accepted"] = False
            check_result["reason"] = "Feedback does not relate to any validation issue or output file"

        # Actionability check: can it be applied as a file patch?
        non_actionable_phrases = [
            "change the database",
            "modify the script",
            "update generate_",
            "rewrite the generator",
            "change the pipeline",
            "modify scripts/",
        ]
        for phrase in non_actionable_phrases:
            if phrase in item_lower:
                check_result["actionability"] = "FAIL"
                check_result["accepted"] = False
                check_result["reason"] = (
                    f"Feedback asks to '{phrase}' which is not an output patch"
                )
                break

        # Source consistency check: does it contradict known rules?
        contradiction_phrases = [
            "remove edh audit columns",
            "remove edh columns",
            "use order by instead of comment",
            "staging should use ref(",
            "marts should use source(",
            "add mart_ prefix",
        ]
        for phrase in contradiction_phrases:
            if phrase in item_lower:
                check_result["source_consistency"] = "FAIL"
                check_result["accepted"] = False
                check_result["reason"] = (
                    f"Feedback contradicts project rules: '{phrase}'"
                )
                break

        result["validation_results"].append(check_result)
        if check_result["accepted"]:
            result["accepted_feedback"].append(item)
        else:
            result["rejected_feedback"].append({
                "item": item,
                "reason": check_result["reason"],
            })

    logger.info(
        f"Feedback validation: {len(result['accepted_feedback'])} accepted, "
        f"{len(result['rejected_feedback'])} rejected"
    )
    return result


# ---------------------------------------------------------------------------
# Patch Application Functions
# ---------------------------------------------------------------------------

def apply_missing_source_yml_entry(
    issue: Dict[str, Any],
    logger: Any,
) -> Optional[Dict[str, Any]]:
    """Patch source.yml to add a missing source table entry."""
    source_yml_path = OUTPUT_DIR / "models" / "source.yml"
    if not source_yml_path.exists():
        logger.warning("source.yml not found -- cannot patch")
        return None

    # Extract table name from issue description
    match = re.search(r"table '(\w+)'", issue.get("description", ""))
    if not match:
        return None
    table_name = match.group(1)

    original = source_yml_path.read_text(encoding="utf-8")
    data = load_yaml(source_yml_path)

    # Check if already present
    for source_def in data.get("sources", []):
        for table in source_def.get("tables", []):
            if table.get("name", "").lower() == table_name.lower():
                return None  # Already exists

    # Add to the first source (best effort)
    if data.get("sources"):
        data["sources"][0].setdefault("tables", []).append({
            "name": table_name,
            "description": f"Source table for {table_name}",
        })

    patched = save_yaml(data, source_yml_path)
    new_content = source_yml_path.read_text(encoding="utf-8")
    lines_changed = check_diff_size(original, new_content)

    return {
        "issue_id": issue["id"],
        "output_file_patched": str(source_yml_path.relative_to(PROJECT_ROOT)),
        "lines_changed": lines_changed,
        "approach": f"Added missing table '{table_name}' to source.yml",
        "source_reference": issue.get("source_file", ""),
    }


def apply_naming_fix(
    issue: Dict[str, Any],
    logger: Any,
) -> Optional[Dict[str, Any]]:
    """Fix naming convention violations (e.g., mart_ prefix removal)."""
    output_file = issue.get("output_file", "")
    if not output_file:
        return None

    file_path = PROJECT_ROOT / output_file
    if not file_path.exists():
        return None

    if not is_safe_write_path(file_path):
        logger.error(f"GUARDRAIL: Refusing to write to {file_path}")
        return None

    description = issue.get("description", "")

    # Handle mart_ prefix removal
    if "mart_" in description and "prefix" in description:
        new_name = file_path.name.replace("mart_", "")
        new_path = file_path.parent / new_name

        if not is_safe_write_path(new_path):
            logger.error(f"GUARDRAIL: Refusing to write to {new_path}")
            return None

        content = file_path.read_text(encoding="utf-8")
        new_path.write_text(content, encoding="utf-8")
        file_path.unlink()

        return {
            "issue_id": issue["id"],
            "output_file_patched": str(new_path.relative_to(PROJECT_ROOT)),
            "lines_changed": 0,
            "approach": f"Renamed {file_path.name} -> {new_name} (removed mart_ prefix)",
            "source_reference": "knowledgebase/idmc_to_dbt_forward_engineering_reference.md",
        }

    return None


def apply_ref_source_fix(
    issue: Dict[str, Any],
    logger: Any,
) -> Optional[Dict[str, Any]]:
    """Fix wrong ref/source usage in SQL files."""
    output_file = issue.get("output_file", "")
    if not output_file:
        return None

    file_path = PROJECT_ROOT / output_file
    if not file_path.exists():
        return None

    if not is_safe_write_path(file_path):
        logger.error(f"GUARDRAIL: Refusing to write to {file_path}")
        return None

    original = file_path.read_text(encoding="utf-8")
    patched = original
    description = issue.get("description", "").lower()

    if "staging" in description and "ref() instead of source()" in description:
        # Replace ref() with source() in staging files -- complex, flag for review
        logger.warning(
            f"Issue {issue['id']}: ref->source fix in staging requires "
            f"manual review (need schema/table context)"
        )
        return None

    if ("intermediate" in description or "marts" in description) and "source() instead of ref()" in description:
        # Replace source() with ref() -- need to map to the correct staging model
        logger.warning(
            f"Issue {issue['id']}: source->ref fix requires manual review "
            f"(need correct model name)"
        )
        return None

    return None


def attempt_fix(
    issue: Dict[str, Any],
    human_feedback: Optional[str],
    logger: Any,
) -> Optional[Dict[str, Any]]:
    """Attempt to fix a single validation issue.

    Returns a patch result dict if successful, None if the fix cannot be
    applied automatically.
    """
    category = issue.get("category", "")

    if category == "schema_mismatch" and "source.yml" in issue.get("output_file", ""):
        return apply_missing_source_yml_entry(issue, logger)

    if category == "naming_violation":
        return apply_naming_fix(issue, logger)

    if category == "wrong_ref":
        return apply_ref_source_fix(issue, logger)

    # For categories that require complex changes (missing_model, missing_field,
    # missing_edh_columns, function_mapping, snapshot_issue), we flag for
    # human review rather than attempting risky auto-patches
    logger.info(
        f"Issue {issue['id']} ({category}): Requires manual review -- "
        f"auto-patch not available for this category"
    )
    return None


# ---------------------------------------------------------------------------
# Refinement Loop
# ---------------------------------------------------------------------------

class Refiner:
    """Orchestrates the refinement loop: patch -> re-validate -> repeat."""

    def __init__(
        self,
        validation_report_path: Optional[Path] = None,
        feedback_path: Optional[Path] = None,
        max_iterations: int = DEFAULT_MAX_ITERATIONS,
    ):
        self.logger = setup_logging("Refiner", log_dir=LOG_DIR)
        self.max_iterations = max_iterations
        self.validation_report_path = validation_report_path
        self.feedback_path = feedback_path
        self.iteration_history: List[Dict[str, Any]] = []
        self.stale_issues: Dict[str, int] = {}  # issue_id -> consecutive failure count
        self.accuracy_history: List[float] = []

    def _load_latest_report(self) -> Dict[str, Any]:
        """Load the most recent validation report."""
        if self.validation_report_path and self.validation_report_path.exists():
            resolved = self.validation_report_path.resolve()
            if not resolved.is_relative_to(PROJECT_ROOT.resolve()):
                raise ValueError(f"Report path resolves outside project root: {resolved}")
            return load_yaml(resolved)

        # Find the latest report in the log directory
        if not LOG_DIR.exists():
            return {}
        reports = sorted(LOG_DIR.glob("validation_report_*.yaml"), reverse=True)
        if reports:
            self.validation_report_path = reports[0]
            self.logger.info(f"Using latest report: {reports[0].name}")
            return load_yaml(reports[0])

        self.logger.warning("No validation report found")
        return {}

    def _load_feedback(self) -> Optional[str]:
        """Load human feedback from file if provided."""
        if self.feedback_path and self.feedback_path.exists():
            return self.feedback_path.read_text(encoding="utf-8").strip()
        return None

    def _run_validator(self) -> Dict[str, Any]:
        """Re-run the validator and return the new report."""
        from validator import IDMCValidator

        validator = IDMCValidator(target_dir="output")
        validator.validate()
        report = validator.generate_report()
        report_path = validator.save_report(report)
        self.validation_report_path = report_path
        validator.print_summary()
        return report

    def _should_stop(
        self,
        iteration: int,
        current_report: Dict[str, Any],
    ) -> Tuple[bool, str]:
        """Check if the refinement loop should stop.

        Returns (should_stop, reason).
        """
        report_data = current_report.get("validation_report", {})
        current_accuracy = report_data.get("overall_accuracy", 0.0)
        current_issues = report_data.get("issues_count", 0)

        # Max iterations reached
        if iteration >= self.max_iterations:
            return True, f"Max iterations reached ({self.max_iterations})"

        # All issues fixed
        if current_issues == 0:
            return True, "All issues resolved"

        # Accuracy regression
        if len(self.accuracy_history) >= 1:
            prev_accuracy = self.accuracy_history[-1]
            if current_accuracy < prev_accuracy:
                return True, (
                    f"Accuracy regression detected: {prev_accuracy}% -> "
                    f"{current_accuracy}%"
                )

        # No improvement (same accuracy for 2 consecutive iterations)
        if len(self.accuracy_history) >= 2:
            if (
                self.accuracy_history[-1] == current_accuracy
                and self.accuracy_history[-2] == current_accuracy
            ):
                return True, "No improvement in 2 consecutive iterations"

        self.accuracy_history.append(current_accuracy)
        return False, ""

    def run(self) -> None:
        """Execute the refinement loop."""
        self.logger.info("=" * 60)
        self.logger.info("IDMC-to-dbt Refiner Starting")
        self.logger.info(f"Max iterations: {self.max_iterations}")
        self.logger.info("=" * 60)

        # Load initial validation report
        report = self._load_latest_report()
        if not report:
            self.logger.error("No validation report available. Run validator first.")
            return

        report_data = report.get("validation_report", {})
        initial_accuracy = report_data.get("overall_accuracy", 0.0)
        self.accuracy_history.append(initial_accuracy)

        self.logger.info(f"Initial accuracy: {initial_accuracy}%")
        self.logger.info(
            f"Issues to address: {report_data.get('issues_count', 0)}"
        )

        # Load and validate human feedback if provided
        feedback_text = self._load_feedback()
        accepted_feedback: Optional[str] = None

        if feedback_text:
            self.logger.info("Validating human feedback...")
            fb_result = validate_feedback(feedback_text, report, self.logger)

            # Save feedback validation log
            LOG_DIR.mkdir(parents=True, exist_ok=True)
            fb_log_path = LOG_DIR / f"feedback_validation_{get_timestamp().replace(' ', '_').replace(':', '')}.yaml"
            save_yaml(fb_result, fb_log_path)

            if fb_result["accepted_feedback"]:
                accepted_feedback = "\n".join(fb_result["accepted_feedback"])
                self.logger.info(
                    f"Accepted {len(fb_result['accepted_feedback'])} feedback items"
                )
            if fb_result["rejected_feedback"]:
                for rej in fb_result["rejected_feedback"]:
                    self.logger.warning(
                        f"Rejected feedback: '{rej['item']}' -- {rej['reason']}"
                    )

        # Refinement loop
        for iteration in range(1, self.max_iterations + 1):
            self.logger.info(f"\n--- Iteration {iteration}/{self.max_iterations} ---")

            issues = report_data.get("issues", [])
            if not issues:
                self.logger.info("No issues to fix -- exiting loop")
                break

            iteration_log: Dict[str, Any] = {
                "iteration": iteration,
                "timestamp": get_timestamp(),
                "trigger": (
                    "validation_errors + human_feedback"
                    if accepted_feedback
                    else "validation_errors"
                ),
                "issues_attempted": [],
                "issues_skipped": [],
                "human_feedback_applied": accepted_feedback,
            }

            patches_applied = 0

            for issue in issues:
                issue_id = issue.get("id", "")

                # Stale loop detection: skip issues that failed twice in a row
                if self.stale_issues.get(issue_id, 0) >= 2:
                    self.logger.info(
                        f"Skipping stale issue {issue_id} (failed {self.stale_issues[issue_id]} times)"
                    )
                    iteration_log["issues_skipped"].append({
                        "issue_id": issue_id,
                        "reason": "stale_loop_detection",
                    })
                    continue

                # Attempt to fix
                patch_result = attempt_fix(issue, accepted_feedback, self.logger)

                if patch_result:
                    # Check diff size guardrail
                    lines_changed = patch_result.get("lines_changed", 0)
                    if lines_changed > MAX_LINES_PER_FIX:
                        self.logger.warning(
                            f"Issue {issue_id}: Patch changes {lines_changed} "
                            f"lines (> {MAX_LINES_PER_FIX}) -- flagged for review"
                        )
                        patch_result["flagged"] = True
                        patch_result["flag_reason"] = (
                            f"Diff size cap exceeded: {lines_changed} lines"
                        )

                    iteration_log["issues_attempted"].append(patch_result)
                    patches_applied += 1
                    self.stale_issues.pop(issue_id, None)
                    self.logger.info(
                        f"Patched: {issue_id} -> "
                        f"{patch_result.get('output_file_patched', '?')}"
                    )
                else:
                    # Track failure for stale detection
                    self.stale_issues[issue_id] = (
                        self.stale_issues.get(issue_id, 0) + 1
                    )
                    iteration_log["issues_attempted"].append({
                        "issue_id": issue_id,
                        "result": "no_auto_fix_available",
                        "description": issue.get("description", ""),
                    })

            # Save iteration log
            LOG_DIR.mkdir(parents=True, exist_ok=True)
            iter_log_path = LOG_DIR / f"iteration_{iteration}_refiner_{get_timestamp().replace(' ', '_').replace(':', '')}.yaml"
            save_yaml(iteration_log, iter_log_path)

            self.iteration_history.append(iteration_log)

            self.logger.info(
                f"Iteration {iteration}: {patches_applied} patches applied"
            )

            # Re-validate
            self.logger.info("Re-running validator...")
            report = self._run_validator()
            report_data = report.get("validation_report", {})

            # Check stopping conditions
            should_stop, reason = self._should_stop(iteration, report)
            if should_stop:
                self.logger.info(f"Stopping refinement loop: {reason}")
                break

            # After first iteration, clear the human feedback (don't re-apply)
            accepted_feedback = None

        # Save accuracy progression
        self._save_accuracy_progression()

        # Print final summary
        self._print_final_summary(report)

    def _save_accuracy_progression(self) -> None:
        """Save accuracy scores across all iterations."""
        progression = []
        for i, acc in enumerate(self.accuracy_history):
            if i == 0:
                stage = "initial_validation"
            else:
                stage = f"iteration_{i}"
            progression.append({
                "stage": stage,
                "accuracy": acc,
            })

        trend = "stable"
        if len(self.accuracy_history) >= 2:
            if self.accuracy_history[-1] > self.accuracy_history[0]:
                trend = "improving"
            elif self.accuracy_history[-1] < self.accuracy_history[0]:
                trend = "regressing"

        data = {
            "run_id": f"run_{get_timestamp().replace(' ', '_').replace(':', '')}",
            "progression": progression,
            "trend": trend,
        }

        LOG_DIR.mkdir(parents=True, exist_ok=True)
        save_yaml(
            data,
            LOG_DIR / f"accuracy_progression_{get_timestamp().replace(' ', '_').replace(':', '')}.yaml",
        )

    def _print_final_summary(self, final_report: Dict[str, Any]) -> None:
        """Print the final refinement summary."""
        report_data = final_report.get("validation_report", {})

        print("\n" + "=" * 60)
        print("REFINEMENT SUMMARY")
        print("=" * 60)
        print(f"Iterations completed: {len(self.iteration_history)}")
        print(f"Max iterations:       {self.max_iterations}")
        print("-" * 60)

        if self.accuracy_history:
            print(f"Initial accuracy:     {self.accuracy_history[0]}%")
            print(f"Final accuracy:       {self.accuracy_history[-1]}%")
            improvement = self.accuracy_history[-1] - self.accuracy_history[0]
            print(f"Improvement:          {improvement:+.2f}%")

        print("-" * 60)

        remaining_issues = report_data.get("issues_count", 0)
        print(f"Remaining issues:     {remaining_issues}")

        if remaining_issues > 0:
            print("\nUnresolved issues:")
            for issue in report_data.get("issues", []):
                sev = issue.get("severity", "?").upper()
                print(
                    f"  [{issue.get('id', '?')}] [{sev}] "
                    f"{issue.get('category', '?')}: "
                    f"{issue.get('description', '?')}"
                )

        stale_count = sum(1 for v in self.stale_issues.values() if v >= 2)
        if stale_count > 0:
            print(f"\nStale issues (skipped): {stale_count}")

        total_patches = sum(
            len([
                a for a in it.get("issues_attempted", [])
                if a.get("output_file_patched")
            ])
            for it in self.iteration_history
        )
        print(f"\nTotal patches applied: {total_patches}")
        print("=" * 60)


# ---------------------------------------------------------------------------
# CLI Entry Point
# ---------------------------------------------------------------------------

def _sanitize_path(raw: str) -> Path:
    """Resolve a user-supplied path, anchored to project root, rejecting traversal."""
    if not raw:
        raise ValueError("Empty path")
    safe = re.sub(r'[^\w.\-/\\ ]', '', raw)
    if safe != raw:
        raise ValueError(f"Path contains disallowed characters: {raw!r}")
    if '..' in safe.replace('\\', '/').split('/'):
        raise ValueError(f"Path traversal blocked: {raw!r}")
    candidate = (PROJECT_ROOT / safe).resolve()
    if not candidate.is_relative_to(PROJECT_ROOT.resolve()):
        raise ValueError(
            f"Path must be within project directory ({PROJECT_ROOT}): {raw}"
        )
    return candidate


def main() -> None:
    """Run the IDMC-to-dbt refiner from the command line."""
    parser = argparse.ArgumentParser(
        description="Refine IDMC-to-dbt output based on validation errors"
    )
    parser.add_argument(
        "--report",
        type=str,
        default=None,
        help="Path to a specific validation report YAML file",
    )
    parser.add_argument(
        "--feedback",
        type=str,
        default=None,
        help="Path to a human feedback text file",
    )
    parser.add_argument(
        "--max-iterations",
        type=int,
        default=DEFAULT_MAX_ITERATIONS,
        help=f"Maximum refinement iterations (default: {DEFAULT_MAX_ITERATIONS})",
    )
    args = parser.parse_args()

    report_path = _sanitize_path(args.report) if args.report else None
    feedback_path = _sanitize_path(args.feedback) if args.feedback else None

    refiner = Refiner(
        validation_report_path=report_path,
        feedback_path=feedback_path,
        max_iterations=args.max_iterations,
    )
    refiner.run()


if __name__ == "__main__":
    main()
