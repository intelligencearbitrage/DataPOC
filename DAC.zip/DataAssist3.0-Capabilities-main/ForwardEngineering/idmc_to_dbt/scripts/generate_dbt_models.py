"""
IDMC-to-dbt Forward Engineering Generator.

Converts IDMC (Informatica Data Management Cloud) JSON mapping exports
into a complete dbt project for Databricks.

Classes:
    FunctionTranslator  – Translates IDMC expressions to Databricks SQL.
    IDMCParser          – Parses IDMC JSON mapping exports.
    ConfigGenerator     – Generates dbt configuration files.
    IDMCGenerator       – Orchestrates dbt project generation.
    ConversionPlanGenerator – Generates conversion plan documents.
"""

from __future__ import annotations

import copy
import hashlib
import json
import logging
import re
from collections import OrderedDict, defaultdict, deque
from pathlib import Path
from typing import Any, Dict, List, Optional, Set, Tuple

from base_generator import BaseGenerator
from base_parser import BaseParser
from utils import (
    EDH_EXCLUDE_COLUMNS,
    _SingleQuotedStr,
    get_project_root,
    load_yaml,
    safe_name,
    save_yaml,
    setup_logging,
)

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

IDMC_CLASS_MAP = {
    "TmplSource": "Source",
    "TmplTarget": "Target",
    "TmplExpression": "Expression",
    "TmplJoiner": "Joiner",
    "TmplFilter": "Filter",
    "TmplLookup": "Lookup",
    "TmplRouter": "Router",
    "TmplAggregator": "Aggregator",
    "TmplSorter": "Sorter",
    "TmplUnion": "Union",
    "TmplNormalizer": "Normalizer",
    "TmplRank": "Rank",
    "TmplGenerator": "Sequence Generator",
    "TmplMapplet": "Mapplet",
    "TmplSql": "SQL",
    "TmplJava": "Java",
    "TmplStoredProcedure": "Stored Procedure",
    "TmplWebServiceConsumer": "Web Services",
    "TmplUpdateStrategy": "Update Strategy",
    "TmplTransactionControl": "Transaction Control",
    "TmplDataMasking": "Data Masking",
    "TmplHierarchyParser": "Hierarchy Parser",
    "TmplHierarchyBuilder": "Hierarchy Builder",
    "TmplStructureParser": "Structure Parser",
    "TmplVelocity": "Velocity",
}

UNSUPPORTED_TX_TYPES = {
    "Java", "Stored Procedure", "Web Services",
    "Update Strategy", "Transaction Control", "Data Masking",
    "Hierarchy Parser", "Hierarchy Builder", "Structure Parser", "Velocity",
}

PLATFORM_TYPE_MAP = {
    "string": "STRING",
    "bigint": "BIGINT",
    "integer": "INT",
    "int": "INT",
    "date/time": "TIMESTAMP",
    "date": "DATE",
    "decimal": "DECIMAL",
    "double": "DOUBLE",
    "float": "FLOAT",
    "binary": "BINARY",
    "text": "STRING",
    "boolean": "BOOLEAN",
    "short": "SMALLINT",
    "long": "BIGINT",
    "byte": "TINYINT",
}

DATE_PART_MAP = {
    "SS": "SECOND", "MI": "MINUTE", "HH": "HOUR", "HH24": "HOUR",
    "DD": "DAY", "DDD": "DAY", "D": "DAY", "MM": "MONTH", "MON": "MONTH",
    "YYYY": "YEAR", "YY": "YEAR", "Y": "YEAR", "Q": "QUARTER",
    "WK": "WEEK", "WW": "WEEK", "W": "WEEK",
}

DATE_FORMAT_MAP = {
    "YYYY": "yyyy", "YY": "yy", "MM": "MM", "MON": "MMM",
    "DD": "dd", "DY": "EEE", "HH24": "HH", "HH12": "hh", "HH": "HH",
    "MI": "mm", "SS": "ss", "MS": "SSS", "US": "SSSSSS",
    "AM": "a", "PM": "a",
}

_DATE_FORMAT_INDICATORS = re.compile(
    r'YYYY|HH24|HH12|MI:|:MI|:SS|\.US|\.MS|DY|MON|DD.MM|MM.DD|YYYY.MM',
    re.IGNORECASE,
)

FUNCTION_MAP = {
    "NVL": "COALESCE",
    "NVL2": "NVL2",
    "SUBSTR": "SUBSTRING",
    "LTRIM": "LTRIM",
    "RTRIM": "RTRIM",
    "LOWER": "LOWER",
    "UPPER": "UPPER",
    "LENGTH": "LENGTH",
    "LPAD": "LPAD",
    "RPAD": "RPAD",
    # REPLACESTR, REPLACECHR, INSTR handled by dedicated translators (Steps 11b-11d)
    "REVERSE": "REVERSE",
    "INITCAP": "INITCAP",
    "CHR": "CHR",
    "ASCII": "ASCII",
    "CONCAT": "CONCAT",
    "MD5": "md5",
    "CRC32": "crc32",
    # DECODE handled separately by _translate_decode (not a simple rename)
    "ABS": "ABS",
    "CEIL": "CEIL",
    "FLOOR": "FLOOR",
    "ROUND": "ROUND",
    "TRUNC": "TRUNC",
    "POWER": "POWER",
    "MOD": "MOD",
    "SIGN": "SIGN",
    "SQRT": "SQRT",
    "LOG": "LOG",
    "EXP": "EXP",
    "GREATEST": "GREATEST",
    "LEAST": "LEAST",
    "REG_EXTRACT": "REGEXP_EXTRACT",
    "REG_MATCH": "RLIKE",
    "REG_REPLACE": "REGEXP_REPLACE",
    "TO_DATE": "TO_DATE",
    "TO_TIMESTAMP": "TO_TIMESTAMP",
    "LAST_DAY": "LAST_DAY",
    "MONTHS_BETWEEN": "MONTHS_BETWEEN",
    "MAKE_DATE_TIME": "MAKE_TIMESTAMP",
    "DENSE_RANK": "DENSE_RANK",
    "FIRST_VALUE": "FIRST_VALUE",
    "LAST_VALUE": "LAST_VALUE",
    "LAG": "LAG",
    "LEAD": "LEAD",
    "NTILE": "NTILE",
    "PERCENTILE": "PERCENTILE",
    "STDDEV": "STDDEV",
    "VARIANCE": "VARIANCE",
    # Additional string functions
    "SOUNDEX": "SOUNDEX",
    "TRIM": "TRIM",
    "SPACE": "SPACE",
    "REPEAT": "REPEAT",
    "LEFT": "LEFT",
    "RIGHT": "RIGHT",
    # Additional date/time functions
    "CURRENT_DATE": "CURRENT_DATE",
    "DATE_COMPARE": "DATEDIFF",
    # Additional math functions
    "RAND": "RAND",
    "LN": "LN",
    "SINH": "SINH",
    "COSH": "COSH",
    "TANH": "TANH",
}

UNSUPPORTED_FUNCTIONS = {
    "METAPHONE", "COMPRESS", "DECOMPRESS", "SET_DATE_PART",
    "ERROR", "ABORT", "CUME",
    "MOVINGSUM", "MOVINGAVG", "MEDIAN",
    "FIRST", "LAST",
}

WINDOW_FUNCTIONS = {
    "LAG", "LEAD", "ROW_NUMBER", "RANK", "DENSE_RANK",
    "NTILE", "FIRST_VALUE", "LAST_VALUE", "SUM", "COUNT",
    "AVG", "MIN", "MAX",
}


# ===================================================================
# FunctionTranslator
# ===================================================================

class FunctionTranslator:
    """Translates IDMC expressions to Databricks SQL.

    Uses parenthesis-balanced argument parsing (not regex) for nested
    function calls. Applies a 16-step translation pipeline in strict order.
    """

    # Types treated as numeric/boolean — var() NOT wrapped in SQL quotes.
    _NUMERIC_VAR_TYPES = frozenset({
        "integer", "int", "bigint", "smallint", "tinyint",
        "float", "double", "decimal", "number", "numeric",
        "boolean", "bool",
        "java.lang.integer", "java.lang.long", "java.math.bigdecimal",
        "java.lang.double", "java.lang.float", "java.lang.boolean",
    })

    def __init__(self) -> None:
        self.logger = setup_logging("FunctionTranslator")
        # Registry for unconnected lookups: { lookup_name: { return_port, ref, conditions } }
        self.lookup_registry: Dict[str, Dict] = {}
        # Variable types: { var_name: type_string } — set by generator before translation.
        self.variable_types: Dict[str, str] = {}

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def translate(self, expr: str, mapping_name: str = "") -> str:
        """Translate an IDMC expression string to Databricks SQL.

        Args:
            expr: The raw IDMC expression string.
            mapping_name: Current mapping name for $CurrentMappingName.

        Returns:
            Translated Databricks SQL expression string.
        """
        if not expr or not expr.strip():
            return expr
        result = expr.strip()

        # Step 0: Strip IDMC partitioning hints
        result = re.sub(r'/\*.*?node-(?:count|number).*?\*/', '', result, flags=re.DOTALL)

        # Step 1: Built-in variables (case-insensitive)
        result = re.sub(r'\bSYSDATE\b', 'CURRENT_TIMESTAMP()', result, flags=re.IGNORECASE)
        result = re.sub(r'\bSESSSTARTTIME\b', 'CURRENT_TIMESTAMP()', result, flags=re.IGNORECASE)
        result = re.sub(r'\bSystimestamp\s*\(\s*\)', 'CURRENT_TIMESTAMP()', result, flags=re.IGNORECASE)
        result = re.sub(r'\bWORKFLOWSTARTTIME\b', 'CURRENT_TIMESTAMP()', result, flags=re.IGNORECASE)
        if mapping_name:
            result = result.replace('$CurrentMappingName', mapping_name)

        # Step 2: Temporarily mark $$variable references.  Actual var()
        # replacement happens in Step 17, after all function translations
        # (e.g. TO_BIGINT -> CAST) so context detection sees final SQL.
        result = re.sub(
            r'\$\$([A-Za-z_][A-Za-z0-9_]*)',
            lambda m: "__DBTVAR_" + m.group(1) + "__",
            result
        )

        # Step 3: ISNULL(x) -> x IS NULL
        result = self._translate_function_call(
            result, 'ISNULL', self._translate_isnull
        )

        # Step 4: TO_CHAR
        result = self._translate_function_call(
            result, 'TO_CHAR', self._translate_to_char
        )

        # Step 5: Type conversion functions
        for func, cast_type in [
            ('TO_INTEGER', 'INT'), ('TO_BIGINT', 'BIGINT'),
            ('TO_FLOAT', 'FLOAT'),
        ]:
            result = self._translate_function_call(
                result, func,
                lambda args, ct=cast_type: f"CAST({args[0].strip()} AS {ct})"
            )
        result = self._translate_function_call(
            result, 'TO_DECIMAL', self._translate_to_decimal
        )

        # Step 6: IIF -> CASE WHEN (multi-pass for nesting)
        for _ in range(10):
            new_result = self._translate_function_call(
                result, 'IIF', self._translate_iif
            )
            if new_result == result:
                break
            result = new_result

        # Step 6b: DECODE -> CASE WHEN (multi-pass for nesting)
        for _ in range(10):
            new_result = self._translate_function_call(
                result, 'DECODE', self._translate_decode
            )
            if new_result == result:
                break
            result = new_result

        # Step 7: ADD_TO_DATE
        result = self._translate_function_call(
            result, 'ADD_TO_DATE', self._translate_add_to_date
        )

        # Step 8: DATE_DIFF -> DATEDIFF
        result = self._translate_function_call(
            result, 'DATE_DIFF', self._translate_date_diff
        )

        # Step 9: GET_DATE_PART
        result = self._translate_function_call(
            result, 'GET_DATE_PART', self._translate_get_date_part
        )

        # Step 10: TRUNC_DATE
        result = self._translate_function_call(
            result, 'TRUNC_DATE', self._translate_trunc_date
        )

        # Step 11: NEXTVAL
        result = re.sub(
            r'\bNEXTVAL\b', 'ROW_NUMBER() OVER(ORDER BY 1)', result
        )

        # Step 11b: REPLACESTR — dedicated handler (strips case-flag arg)
        for fname in ('REPLACESTR', 'REPLACE_STR'):
            result = self._translate_function_call(
                result, fname, self._translate_replacestr
            )

        # Step 11c: REPLACECHR — dedicated handler (strips case-flag arg)
        for fname in ('REPLACECHR', 'REPLACE_CHR'):
            result = self._translate_function_call(
                result, fname, self._translate_replacechr
            )

        # Step 11d: INSTR — dedicated handler (supports 2/3/4 args)
        result = self._translate_function_call(
            result, 'INSTR', self._translate_instr
        )

        # Step 11e: IDMC substring notation — (expr)N means SUBSTRING(expr, 1, N)
        # Matches patterns like (svKeyConcat)4, (some_var)12
        result = re.sub(
            r'\(([A-Za-z_][A-Za-z0-9_]*)\)(\d+)',
            lambda m: f"SUBSTRING({m.group(1)}, 1, {m.group(2)})",
            result
        )

        # Step 11f: IS_DATE -> TRY_TO_TIMESTAMP(...) IS NOT NULL
        result = self._translate_function_call(
            result, 'IS_DATE', self._translate_is_date
        )

        # Step 11g: IS_NUMBER -> TRY_CAST(... AS DOUBLE) IS NOT NULL
        result = self._translate_function_call(
            result, 'IS_NUMBER', self._translate_is_number
        )

        # Step 11h: IS_SPACES -> TRIM(...) = ''
        result = self._translate_function_call(
            result, 'IS_SPACES', self._translate_is_spaces
        )

        # Step 11i: INDEXOF -> LOCATE (synonym for INSTR, always 2-arg)
        result = self._translate_function_call(
            result, 'INDEXOF', self._translate_indexof
        )

        # Step 11j: IN(val, list...) -> val IN (list...)
        result = self._translate_function_call(
            result, 'IN', self._translate_in
        )

        # Step 11k: SETVARIABLE / SET_VARIABLE / SETCOUNTVARIABLE — flag as TODO
        for sv_fn in ('SETVARIABLE', 'SET_VARIABLE', 'SETCOUNTVARIABLE'):
            result = self._translate_function_call(
                result, sv_fn,
                lambda args, fn=sv_fn: f"-- TODO: {fn}({', '.join(a.strip() for a in args)})"
            )

        # Step 12: :LKP references — translate to scalar subquery if lookup is registered
        def _translate_lkp(m):
            lkp_name = m.group(1)
            lkp_info = self.lookup_registry.get(lkp_name)
            if lkp_info:
                ret_col = lkp_info.get("return_port", "")
                ref = lkp_info.get("ref", "")
                where_parts = lkp_info.get("where_parts", [])
                if ret_col and ref and where_parts:
                    where_clause = " AND ".join(where_parts)
                    return f"(SELECT {ret_col} FROM {{{{ ref('{ref}') }}}} WHERE {where_clause})"
            return f"-- TODO: Replace :LKP.{lkp_name}(...) with JOIN or subquery"
        result = re.sub(r':LKP\.(\w+)\([^)]*\)', _translate_lkp, result)

        # Step 13: Simple function name substitutions (case-insensitive)
        for idmc_fn, dbx_fn in FUNCTION_MAP.items():
            pattern = r'\b' + re.escape(idmc_fn) + r'\b'
            result = re.sub(pattern, dbx_fn, result, flags=re.IGNORECASE)

        # Step 14: Date format string substitutions (only inside quoted strings)
        result = self._replace_date_formats_in_strings(result)

        # Step 15: Flag unsupported functions (only match actual function calls with '(')
        for fn in UNSUPPORTED_FUNCTIONS:
            if re.search(r'\b' + re.escape(fn) + r'\s*\(', result, re.IGNORECASE):
                result = f"-- TODO: Unsupported IDMC function {fn}\n{result}"
                break

        # Step 16: Databricks adaptations
        result = re.sub(r'\bgetdate\s*\(\s*\)', 'current_timestamp()', result, flags=re.IGNORECASE)
        result = result.replace('::string', '::string')
        result = re.sub(r'cast\((.+?)\s+as\s+varchar\b', r'cast(\1 as STRING', result, flags=re.IGNORECASE)

        # Step 17: Replace __DBTVAR_name__ placeholders with dbt var().
        # Quoting is driven by the variable's IDMC type:
        #   Numeric/boolean → {{ var("name") }}       (no SQL quotes)
        #   String/date/other → '{{ var("name") }}'   (SQL single quotes)
        # First strip existing SQL quotes around __DBTVAR__ placeholders
        # e.g. '__DBTVAR_var__' → __DBTVAR_var__  (remove wrapping quotes)
        result = re.sub(r"'(__DBTVAR_\w+__)'", r'\1', result)

        def _var_replacer(m: re.Match) -> str:
            var_name = m.group(1)
            var_type = self.variable_types.get(var_name, "string")
            bare_var = '{{ var("' + var_name + '") }}'
            if var_type in self._NUMERIC_VAR_TYPES:
                return bare_var
            return "'{{ var(\"" + var_name + "\") }}'"
        result = re.sub(
            r'__DBTVAR_(\w+)__',
            _var_replacer,
            result
        )

        # Step 18: Cast bare NULL AS <column> → CAST(NULL AS STRING) AS <column>.
        # Skips NULLs already typed (e.g. cast(null as date)).
        # Matches NULL AS <word> only when <word> is NOT a SQL type keyword.
        _SQL_TYPES = r'BIGINT|INT|INTEGER|SMALLINT|TINYINT|FLOAT|DOUBLE|DECIMAL|NUMERIC|NUMBER|STRING|VARCHAR|DATE|TIMESTAMP|BOOLEAN|BINARY|LONG|SHORT'
        result = re.sub(
            r'\bNULL\s+AS\s+(?!' + _SQL_TYPES + r'\b)(\w+)',
            r'CAST(NULL AS STRING) AS \1',
            result,
            flags=re.IGNORECASE,
        )

        return result

    # ------------------------------------------------------------------
    # Balanced-parenthesis argument parsing
    # ------------------------------------------------------------------

    def _extract_balanced_args(self, expr: str, start: int) -> Tuple[List[str], int]:
        """Extract balanced parenthesized arguments starting at opening '('.

        Args:
            expr: Full expression string.
            start: Index of the opening parenthesis.

        Returns:
            Tuple of (list of argument strings, index of closing parenthesis).
        """
        if start >= len(expr) or expr[start] != '(':
            return [], start
        depth = 0
        current_arg = []
        args: List[str] = []
        i = start
        in_string = False
        string_char = ''
        while i < len(expr):
            ch = expr[i]
            if in_string:
                current_arg.append(ch)
                if ch == string_char:
                    in_string = False
                i += 1
                continue
            if ch in ("'", '"'):
                in_string = True
                string_char = ch
                current_arg.append(ch)
                i += 1
                continue
            if ch == '(':
                if depth == 0:
                    depth = 1
                    i += 1
                    continue
                depth += 1
                current_arg.append(ch)
            elif ch == ')':
                depth -= 1
                if depth == 0:
                    args.append(''.join(current_arg))
                    return args, i
                current_arg.append(ch)
            elif ch == ',' and depth == 1:
                args.append(''.join(current_arg))
                current_arg = []
            else:
                current_arg.append(ch)
            i += 1
        args.append(''.join(current_arg))
        return args, i

    def _translate_function_call(
        self, expr: str, func_name: str, translator_fn
    ) -> str:
        """Find all occurrences of func_name(...) right-to-left and apply translator.

        Args:
            expr: The expression string.
            func_name: IDMC function name to find.
            translator_fn: Callable that takes list of args and returns translated string.

        Returns:
            Expression with all occurrences translated.
        """
        pattern = re.compile(r'\b' + re.escape(func_name) + r'\s*\(', re.IGNORECASE)
        matches = list(pattern.finditer(expr))
        for m in reversed(matches):
            # For the IN function: skip if preceded by an identifier, closing
            # paren, or quote — that indicates SQL "column IN (...)" syntax,
            # not the IDMC IN(value, list...) function.
            if func_name.upper() == "IN" and m.start() > 0:
                preceding = expr[:m.start()].rstrip()
                if preceding and (preceding[-1].isalnum() or preceding[-1] in ('_', ')', "'", '"')):
                    # But allow if preceded by SQL keywords like WHEN, AND, OR, NOT, THEN
                    last_word = re.search(r'(\w+)\s*$', preceding)
                    if not last_word or last_word.group(1).upper() not in (
                        'WHEN', 'AND', 'OR', 'NOT', 'THEN', 'ELSE', 'SELECT', 'WHERE', 'SET', 'CASE',
                    ):
                        continue
            paren_start = m.end() - 1
            args, close_pos = self._extract_balanced_args(expr, paren_start)
            try:
                replacement = translator_fn(args)
            except Exception:
                continue
            expr = expr[:m.start()] + replacement + expr[close_pos + 1:]
        return expr

    # ------------------------------------------------------------------
    # Individual function translators
    # ------------------------------------------------------------------

    @staticmethod
    def _translate_isnull(args: List[str]) -> str:
        if len(args) >= 1:
            return f"({args[0].strip()} IS NULL)"
        return "IS NULL"

    @staticmethod
    def _translate_to_char(args: List[str]) -> str:
        if len(args) >= 2:
            fmt = args[1].strip().strip("'\"")
            return f"DATE_FORMAT({args[0].strip()}, '{fmt}')"
        return f"CAST({args[0].strip()} AS STRING)"

    @staticmethod
    def _translate_to_decimal(args: List[str]) -> str:
        val = args[0].strip()
        if len(args) >= 3:
            return f"CAST({val} AS DECIMAL({args[1].strip()},{args[2].strip()}))"
        if len(args) >= 2:
            return f"CAST({val} AS DECIMAL({args[1].strip()}))"
        return f"CAST({val} AS DECIMAL)"

    @staticmethod
    def _translate_iif(args: List[str]) -> str:
        if len(args) >= 3:
            cond = args[0].strip()
            then_val = args[1].strip()
            else_val = args[2].strip()
            return f"CASE WHEN {cond} THEN {then_val} ELSE {else_val} END"
        if len(args) >= 2:
            return f"CASE WHEN {args[0].strip()} THEN {args[1].strip()} END"
        return f"CASE WHEN {args[0].strip()} END"

    @staticmethod
    def _translate_decode(args: List[str]) -> str:
        """DECODE(value, search1, result1, search2, result2, ..., default) -> CASE WHEN."""
        if len(args) < 3:
            return f"DECODE({', '.join(a.strip() for a in args)})"
        value = args[0].strip()
        pairs = [a.strip() for a in args[1:]]
        clauses = []
        i = 0
        while i + 1 < len(pairs):
            clauses.append(f"WHEN {value} = {pairs[i]} THEN {pairs[i + 1]}")
            i += 2
        default = pairs[-1] if len(pairs) % 2 == 1 else "NULL"
        return "CASE " + " ".join(clauses) + f" ELSE {default} END"

    @staticmethod
    def _translate_add_to_date(args: List[str]) -> str:
        if len(args) >= 3:
            date_expr = args[0].strip()
            part = args[1].strip().strip("'\"").upper()
            amount = args[2].strip()
            mapped_part = DATE_PART_MAP.get(part, part)
            return f"DATEADD({mapped_part}, {amount}, {date_expr})"
        return f"DATEADD({', '.join(a.strip() for a in args)})"

    @staticmethod
    def _translate_date_diff(args: List[str]) -> str:
        if len(args) >= 3:
            date1 = args[0].strip()
            date2 = args[1].strip()
            part = args[2].strip().strip("'\"").upper()
            mapped_part = DATE_PART_MAP.get(part, part)
            return f"DATEDIFF({mapped_part}, {date2}, {date1})"
        return f"DATEDIFF({', '.join(a.strip() for a in args)})"

    @staticmethod
    def _translate_get_date_part(args: List[str]) -> str:
        if len(args) >= 2:
            date_expr = args[0].strip()
            part = args[1].strip().strip("'\"").upper()
            mapped_part = DATE_PART_MAP.get(part, part)
            return f"EXTRACT({mapped_part} FROM {date_expr})"
        return f"EXTRACT({args[0].strip()})"

    @staticmethod
    def _translate_trunc_date(args: List[str]) -> str:
        if len(args) >= 2:
            date_expr = args[0].strip()
            part = args[1].strip().strip("'\"").upper()
            mapped_part = DATE_PART_MAP.get(part, part)
            return f"DATE_TRUNC('{mapped_part}', {date_expr})"
        return f"DATE_TRUNC({args[0].strip()})"

    @staticmethod
    def _translate_replacestr(args: List[str]) -> str:
        """REPLACESTR(caseflag, str, search, replacement) -> REPLACE(str, search, replacement).

        The first arg is a case-sensitivity flag (1=case-sensitive) — strip it.
        If only 3 args, assume no flag: REPLACESTR(str, search, replacement).
        """
        if len(args) >= 4:
            # 4-arg form: flag, str, search, replacement
            return f"REPLACE({args[1].strip()}, {args[2].strip()}, {args[3].strip()})"
        if len(args) == 3:
            first = args[0].strip()
            if first in ('0', '1'):
                # 3-arg with flag but missing replacement → REPLACE(str, search, '')
                return f"REPLACE({args[1].strip()}, {args[2].strip()}, '')"
            return f"REPLACE({args[0].strip()}, {args[1].strip()}, {args[2].strip()})"
        if len(args) == 2:
            return f"REPLACE({args[0].strip()}, {args[1].strip()}, '')"
        return f"REPLACE({', '.join(a.strip() for a in args)})"

    @staticmethod
    def _translate_replacechr(args: List[str]) -> str:
        """REPLACECHR(caseflag, str, chars, replacement) -> TRANSLATE(str, chars, replacement).

        The first arg is a case-sensitivity flag — strip it.
        If replacement is empty/missing, use '' to remove chars.
        """
        if len(args) >= 4:
            return f"TRANSLATE({args[1].strip()}, {args[2].strip()}, {args[3].strip()})"
        if len(args) == 3:
            first = args[0].strip()
            if first in ('0', '1'):
                # 3-arg with flag but missing replacement → TRANSLATE(str, chars, '')
                return f"TRANSLATE({args[1].strip()}, {args[2].strip()}, '')"
            return f"TRANSLATE({args[0].strip()}, {args[1].strip()}, {args[2].strip()})"
        return f"TRANSLATE({', '.join(a.strip() for a in args)})"

    @staticmethod
    def _translate_instr(args: List[str]) -> str:
        """INSTR(str, search [, start [, occurrence]]) -> Databricks equivalent.

        2-arg: INSTR(str, search) -> LOCATE(search, str)
        3-arg: INSTR(str, search, start) -> LOCATE(search, str, start)
        4-arg: INSTR(str, search, start, occurrence) -> uses recursive CTE-free approach:
               Find the Nth occurrence by nesting LOCATE calls.
        """
        if len(args) < 2:
            return f"LOCATE({', '.join(a.strip() for a in args)})"
        string = args[0].strip()
        search = args[1].strip()
        if len(args) == 2:
            return f"LOCATE({search}, {string})"
        start = args[2].strip()
        if len(args) == 3:
            return f"LOCATE({search}, {string}, {start})"
        # 4-arg: INSTR(str, search, start, occurrence)
        occurrence = args[3].strip()
        try:
            n = int(occurrence)
        except ValueError:
            n = 0
        if n <= 1:
            return f"LOCATE({search}, {string}, {start})"
        # Build nested LOCATE for Nth occurrence:
        # For N=2: LOCATE(search, str, LOCATE(search, str, start) + 1)
        # For N=3: LOCATE(search, str, LOCATE(search, str, LOCATE(search, str, start) + 1) + 1)
        inner = f"LOCATE({search}, {string}, {start})"
        for _ in range(n - 1):
            inner = f"LOCATE({search}, {string}, {inner} + 1)"
        return inner

    @staticmethod
    def _translate_is_date(args: List[str]) -> str:
        """IS_DATE(str [, fmt]) -> TRY_TO_TIMESTAMP(str [, fmt]) IS NOT NULL."""
        val = args[0].strip()
        if len(args) >= 2:
            fmt = args[1].strip()
            return f"(TRY_TO_TIMESTAMP({val}, {fmt}) IS NOT NULL)"
        return f"(TRY_TO_TIMESTAMP({val}) IS NOT NULL)"

    @staticmethod
    def _translate_is_number(args: List[str]) -> str:
        """IS_NUMBER(str) -> TRY_CAST(str AS DOUBLE) IS NOT NULL."""
        val = args[0].strip()
        return f"(TRY_CAST({val} AS DOUBLE) IS NOT NULL)"

    @staticmethod
    def _translate_is_spaces(args: List[str]) -> str:
        """IS_SPACES(str) -> TRIM(str) = ''."""
        val = args[0].strip()
        return f"(TRIM({val}) = '')"

    @staticmethod
    def _translate_indexof(args: List[str]) -> str:
        """INDEXOF(str, search) -> LOCATE(search, str).

        Same semantics as INSTR but always 2-arg.
        """
        if len(args) >= 2:
            return f"LOCATE({args[1].strip()}, {args[0].strip()})"
        return f"LOCATE({', '.join(a.strip() for a in args)})"

    @staticmethod
    def _translate_in(args: List[str]) -> str:
        """IN(value, list1, list2, ...) -> value IN (list1, list2, ...)."""
        if len(args) >= 2:
            val = args[0].strip()
            items = ", ".join(a.strip() for a in args[1:])
            return f"({val} IN ({items}))"
        return f"({args[0].strip()})"

    @staticmethod
    def _translate_lookup(args: List[str]) -> str:
        """LOOKUP(result_port, condition) -> subquery placeholder.

        Standalone LOOKUP() calls (not :LKP) get flagged.
        """
        return f"-- TODO: Translate LOOKUP({', '.join(a.strip() for a in args)})"

    @staticmethod
    def _replace_date_formats_in_strings(expr: str) -> str:
        """Replace IDMC date format tokens only inside quoted strings."""
        result: List[str] = []
        i = 0
        while i < len(expr):
            ch = expr[i]
            if ch in ("'", '"'):
                # Collect the entire quoted string
                quote_char = ch
                j = i + 1
                while j < len(expr) and expr[j] != quote_char:
                    j += 1
                # j is now at closing quote or end
                inner = expr[i + 1:j]
                # Only apply date format replacements if string looks like a date format
                if _DATE_FORMAT_INDICATORS.search(inner):
                    for idmc_fmt, dbx_fmt in DATE_FORMAT_MAP.items():
                        inner = inner.replace(idmc_fmt, dbx_fmt)
                result.append(quote_char)
                result.append(inner)
                if j < len(expr):
                    result.append(expr[j])
                    i = j + 1
                else:
                    i = j
            else:
                result.append(ch)
                i += 1
        return "".join(result)


# ===================================================================
# IDMCParser
# ===================================================================

class IDMCParser(BaseParser):
    """Parses IDMC JSON mapping exports into structured dicts.

    Extends BaseParser. Reads ``inputs/*.json`` and returns one parsed
    dict per mapping with sources, targets, expressions, joiners, etc.
    """

    def __init__(self, input_dir: str = "inputs", output_dir: str = "output") -> None:
        super().__init__(input_dir=input_dir, output_dir=output_dir)

    # ------------------------------------------------------------------
    # BaseParser overrides
    # ------------------------------------------------------------------

    def discover_files(self) -> List[Path]:
        """Find all IDMC JSON files in the input directory."""
        input_path = Path(self.input_dir)
        if not input_path.exists():
            self.logger.warning(f"Input directory not found: {input_path}")
            return []
        files = sorted(input_path.glob("*.json"))
        self.logger.info(f"Discovered {len(files)} JSON file(s)")
        return files

    def parse_file(self, file_path: Path) -> Dict[str, Any]:
        """Parse a single IDMC JSON mapping export.

        Returns a structured dict with all transformation objects,
        DAG, variables, and load type information.
        """
        with open(file_path, "r", encoding="utf-8") as f:
            data = json.load(f)

        metadata = data.get("metadata", {})
        content = data.get("content", {})

        # Step 1: Build class map from $$classInfo
        class_info = metadata.get("$$classInfo", {})
        class_map = self._build_class_map(class_info)

        mapping_name = content.get("name", file_path.stem)
        description = self._extract_description(content)

        # Step 2: Classify transformations
        transformations = content.get("transformations", [])
        tx_by_type: Dict[str, list] = defaultdict(list)
        tx_by_id: Dict[int, Dict[str, Any]] = {}

        for tx in transformations:
            tx_class = tx.get("$$class")
            friendly = class_map.get(tx_class, f"unknown_{tx_class}")
            tx_entry = {"type": friendly, "raw": tx, "name": tx.get("name", ""), "id": tx.get("$$ID")}
            tx_by_type[friendly].append(tx_entry)
            tx_by_id[tx.get("$$ID")] = tx_entry

        # Step 3: Content-based reclassification
        self._reclassify_by_content(tx_by_type, tx_by_id)

        # Step 4: Build DAG
        links = content.get("links", [])
        dag, reverse_dag, link_to_group_map, from_group_map, multi_link_map = self._build_dag(links)

        # Step 5: Build router group maps
        router_group_map, link_from_group_map = self._build_router_group_maps(
            links, tx_by_type.get("Router", [])
        )

        # Step 5b: Collect all transformation names for CR validation
        all_tx_names = {tx.get("name", "") for tx in transformations if tx.get("name")}

        # Step 6: Extract per-type structured dicts
        sources = [self._extract_source(t["raw"]) for t in tx_by_type.get("Source", [])]
        targets = [self._extract_target(t["raw"]) for t in tx_by_type.get("Target", [])]
        expressions = [self._extract_expression(t["raw"], all_tx_names) for t in tx_by_type.get("Expression", [])]
        joiners = [self._extract_joiner(t["raw"], all_tx_names) for t in tx_by_type.get("Joiner", [])]
        filters = [self._extract_filter(t["raw"]) for t in tx_by_type.get("Filter", [])]
        lookups = [self._extract_lookup(t["raw"], all_tx_names) for t in tx_by_type.get("Lookup", [])]
        routers = [self._extract_router(t["raw"]) for t in tx_by_type.get("Router", [])]
        aggregators = [self._extract_aggregator(t["raw"]) for t in tx_by_type.get("Aggregator", [])]
        sorters = [self._extract_sorter(t["raw"]) for t in tx_by_type.get("Sorter", [])]
        unions = [self._extract_union(t["raw"]) for t in tx_by_type.get("Union", [])]
        normalizers = [self._extract_normalizer(t["raw"]) for t in tx_by_type.get("Normalizer", [])]
        ranks = [self._extract_rank(t["raw"]) for t in tx_by_type.get("Rank", [])]
        sequences = [self._extract_sequence(t["raw"]) for t in tx_by_type.get("Sequence Generator", [])]
        mapplets = [self._extract_mapplet(t["raw"]) for t in tx_by_type.get("Mapplet", [])]
        sql_transformations = [self._extract_sql_transformation(t["raw"]) for t in tx_by_type.get("SQL", [])]

        # Step 7: Extract variables
        variables = self._extract_variables(content.get("variables", []))

        # Step 8: Determine load type
        load_type = self._determine_load_type(targets, routers, joiners)

        return {
            "mapping_name": mapping_name,
            "description": description,
            "sources": sources,
            "targets": targets,
            "expressions": expressions,
            "joiners": joiners,
            "filters": filters,
            "lookups": lookups,
            "routers": routers,
            "aggregators": aggregators,
            "sorters": sorters,
            "unions": unions,
            "normalizers": normalizers,
            "ranks": ranks,
            "sequences": sequences,
            "mapplets": mapplets,
            "sql_transformations": sql_transformations,
            "variables": variables,
            "load_type": load_type,
            "dag": dag,
            "reverse_dag": reverse_dag,
            "tx_by_id": tx_by_id,
            "router_group_map": router_group_map,
            "link_from_group_map": link_from_group_map,
            "link_to_group_map": link_to_group_map,
            "from_group_map": from_group_map,
            "multi_link_map": multi_link_map,
        }

    # ------------------------------------------------------------------
    # Class map
    # ------------------------------------------------------------------

    def _build_class_map(self, class_info: Dict) -> Dict[int, str]:
        """Map class numbers to friendly names from $$classInfo."""
        cmap: Dict[int, str] = {}
        for num_str, fqn in class_info.items():
            try:
                num = int(num_str)
            except (ValueError, TypeError):
                continue
            short = fqn.rsplit(".", 1)[-1] if "." in fqn else fqn
            friendly = IDMC_CLASS_MAP.get(short, None)
            if friendly:
                cmap[num] = friendly
        return cmap

    # ------------------------------------------------------------------
    # Content-based reclassification
    # ------------------------------------------------------------------

    def _reclassify_by_content(self, tx_by_type: Dict, tx_by_id: Dict) -> None:
        """Safety net: reclassify TXs based on content signals."""
        for tx_id, entry in list(tx_by_id.items()):
            raw = entry.get("raw", {})
            current_type = entry["type"]
            new_type = None

            if "lookupConditions" in raw and "dataAdapter" in raw and current_type != "Lookup":
                new_type = "Lookup"
            elif "dataAdapter" in raw and current_type not in ("Source", "Target", "Lookup"):
                adapter = raw.get("dataAdapter", {})
                obj = adapter.get("object", adapter.get("objects", [{}]))
                if isinstance(obj, list):
                    obj = obj[0] if obj else {}
                ot = obj.get("objectType", "")
                if ot == "QUERY":
                    new_type = "Source"
                elif ot == "SINGLE":
                    new_type = "Target"
            elif "joinConditions" in raw and current_type != "Joiner":
                new_type = "Joiner"
            elif "groupFilterConditions" in raw and current_type != "Router":
                new_type = "Router"

            if new_type and new_type != current_type:
                self.logger.info(f"Reclassifying TX {entry['name']} from {current_type} to {new_type}")
                if current_type in tx_by_type:
                    tx_by_type[current_type] = [t for t in tx_by_type[current_type] if t["id"] != tx_id]
                entry["type"] = new_type
                tx_by_type[new_type].append(entry)

    # ------------------------------------------------------------------
    # DAG construction
    # ------------------------------------------------------------------

    def _build_dag(self, links: List[Dict]) -> Tuple[Dict, Dict, Dict, Dict]:
        """Build forward and reverse DAG from links, plus link-to-group map."""
        dag: Dict[int, List[int]] = defaultdict(list)
        reverse_dag: Dict[int, List[int]] = defaultdict(list)
        # Maps (from_tx, to_tx) -> toGroup ##ID (for union input group resolution)
        # Uses last-write-wins for single-link cases; multi_link variants below
        link_to_group_map: Dict[Tuple[int, int], int] = {}
        # Maps (from_tx, to_tx) -> fromGroup ##ID (for router output group resolution)
        from_group_map: Dict[Tuple[int, int], int] = {}
        # Multi-link variants: (from_tx, to_tx) -> list of (from_grp_id, to_grp_id)
        # Needed when a router sends multiple groups to the same union
        multi_link_map: Dict[Tuple[int, int], List[Tuple[int, int]]] = defaultdict(list)
        for link in links:
            from_tx = link.get("fromTransformation", {}).get("##ID")
            to_tx = link.get("toTransformation", {}).get("##ID")
            if from_tx is not None and to_tx is not None:
                if to_tx not in dag[from_tx]:
                    dag[from_tx].append(to_tx)
                if from_tx not in reverse_dag[to_tx]:
                    reverse_dag[to_tx].append(from_tx)
                to_grp_id = None
                to_grp = link.get("toGroup", {})
                if isinstance(to_grp, dict):
                    to_grp_id = to_grp.get("##ID")
                    if to_grp_id is not None:
                        link_to_group_map[(from_tx, to_tx)] = to_grp_id
                from_grp_id = None
                from_grp = link.get("fromGroup", {})
                if isinstance(from_grp, dict):
                    from_grp_id = from_grp.get("##ID")
                    if from_grp_id is not None:
                        from_group_map[(from_tx, to_tx)] = from_grp_id
                if from_grp_id is not None or to_grp_id is not None:
                    multi_link_map[(from_tx, to_tx)].append(
                        (from_grp_id, to_grp_id)
                    )
        return dict(dag), dict(reverse_dag), link_to_group_map, from_group_map, dict(multi_link_map)

    # ------------------------------------------------------------------
    # Router group maps
    # ------------------------------------------------------------------

    def _build_router_group_maps(
        self, links: List[Dict], routers: List[Dict]
    ) -> Tuple[Dict, Dict]:
        """Build router_group_map and link_from_group_map."""
        router_group_map: Dict[int, Tuple[int, str]] = {}
        for r_entry in routers:
            raw = r_entry["raw"]
            router_id = raw.get("$$ID")
            for gfc in raw.get("groupFilterConditions", []):
                gid = gfc.get("$$ID")
                gname = gfc.get("name", "")
                if gid is not None:
                    router_group_map[gid] = (router_id, gname)
            for grp in raw.get("groups", []):
                gid = grp.get("$$ID")
                gname = grp.get("name", "")
                if gid is not None and gid not in router_group_map:
                    router_group_map[gid] = (router_id, gname)

        link_from_group_map: Dict[Tuple[int, int], int] = {}
        for link in links:
            from_tx = link.get("fromTransformation", {}).get("##ID")
            to_tx = link.get("toTransformation", {}).get("##ID")
            from_grp = link.get("fromGroup", {}).get("##ID")
            if from_tx is not None and to_tx is not None and from_grp is not None:
                link_from_group_map[(from_tx, to_tx)] = from_grp
        return router_group_map, link_from_group_map

    # ------------------------------------------------------------------
    # Description extraction
    # ------------------------------------------------------------------

    def _extract_description(self, content: Dict) -> str:
        """Extract mapping description from annotations."""
        for ann in content.get("annotations", []):
            body = ann.get("body", "")
            if body:
                return body
        return ""

    # ------------------------------------------------------------------
    # Platform type extraction
    # ------------------------------------------------------------------

    @staticmethod
    def _get_platform_type(field: Dict) -> str:
        """Extract Databricks type from a field's platformType."""
        pt = field.get("platformType", {})
        sid = pt.get("##SID", "")
        if "typesystem/" in sid:
            raw_type = sid.split("typesystem/")[-1].lower()
            return PLATFORM_TYPE_MAP.get(raw_type, raw_type.upper())
        return "STRING"

    @staticmethod
    def _extract_excluded_fields(raw: Dict) -> List[str]:
        """Extract excluded field names from groups' rules.

        Only ``include=false`` rules produce excludes. An ``include=true``
        rule with ``outputName == ''`` means "include with original name",
        NOT exclude.
        """
        excluded: List[str] = []
        for g in raw.get("groups", []):
            for r in g.get("rules", []):
                is_exclude_rule = str(r.get("include", "true")).lower() == "false"
                if not is_exclude_rule:
                    continue
                for n in r.get("names", []):
                    if isinstance(n, dict):
                        inp = n.get("inputName", "")
                        if inp:
                            excluded.append(inp)
        return excluded

    @staticmethod
    def _extract_field_renames(raw: Dict) -> Dict[str, str]:
        """Extract field renames from groups' rules.

        In IDMC, a rule entry with a non-empty ``outputName`` that differs
        from ``inputName`` means the field is renamed in the output.

        Returns:
            Dict mapping inputName -> outputName.
        """
        renames: Dict[str, str] = {}
        for g in raw.get("groups", []):
            for r in g.get("rules", []):
                for n in r.get("names", []):
                    if isinstance(n, dict):
                        inp = n.get("inputName", "")
                        out = n.get("outputName", "")
                        if inp and out and inp != out:
                            renames[inp] = out
        return renames

    @staticmethod
    def _extract_included_fields(raw: Dict) -> List[str]:
        """Extract explicit include-only field list from groups' rules.

        Only applies when ALL include=true rules have named fields.
        If any include=true rule has NO names (catch-all), return empty
        list meaning "include all" — the named rules are just renames.

        Returns:
            List of field names to include. Empty list means include all.
        """
        has_catch_all = False
        included: List[str] = []
        for g in raw.get("groups", []):
            for r in g.get("rules", []):
                is_include = str(r.get("include", "true")).lower() == "true"
                names = r.get("names", [])
                if is_include and not names:
                    has_catch_all = True
                elif is_include and names:
                    for n in names:
                        if isinstance(n, dict):
                            inp = n.get("inputName", "")
                            out = n.get("outputName", "")
                            if inp:
                                included.append(out if out else inp)
        # If there's a catch-all include, the named fields are just
        # renames/passthrough markers, not an include-only filter
        if has_catch_all:
            return []
        return included

    # --- BEGIN CHANGE 2026-04-16: adding source filters to staging ---
    @staticmethod
    def _extract_source_filters(cq: str) -> List[str]:
        """Extract EDH and date filter conditions from a custom query's WHERE clause.

        Returns a deduplicated list of canonical condition strings.
        """
        if not cq:
            return []
        where_match = re.search(r'\bWHERE\b\s+(.+)', cq, re.IGNORECASE | re.DOTALL)
        if not where_match:
            return []
        where_body = where_match.group(1)
        parts = re.split(r'\bAND\b', where_body, flags=re.IGNORECASE)
        results: List[str] = []
        seen: Set[str] = set()
        for cond in parts:
            # Strip trailing SQL line comments
            cond = re.sub(r'\s*--[^\r\n]*', '', cond).strip()
            # Skip CTE/subquery bleed
            if '\r' in cond or '\n' in cond:
                continue
            # Strip leading table alias prefix
            cond_clean = re.sub(r'^\w+\.', '', cond)
            # Strip trailing IDMC $$variable placeholders
            cond_clean = re.sub(r'\s*\$\$\w+\s*$', '', cond_clean).strip()
            # Skip single-line CTE bleed (closing paren followed by non-whitespace)
            if re.search(r'\)\s*\S', cond_clean):
                continue
            is_edh = bool(re.search(r'\bedh_record_status_in\s*(=|in\b)', cond_clean, re.IGNORECASE))
            is_date = bool(re.search(r'\b\w*(date|dt|ts|timestamp)\w*\s*(=|>|<|>=|<=|!=|between)', cond_clean, re.IGNORECASE))
            if is_edh or is_date:
                norm_key = re.sub(r'\s+', '', cond_clean.lower())
                if norm_key not in seen:
                    seen.add(norm_key)
                    results.append(cond_clean)
        return results
    # --- END CHANGE 2026-04-16: adding source filters to staging ---

    # ------------------------------------------------------------------
    # Per-type extraction methods
    # ------------------------------------------------------------------

    def _extract_source(self, raw: Dict) -> Dict[str, Any]:
        """Extract structured Source dict."""
        adapter = raw.get("dataAdapter", {})
        obj = adapter.get("object", {})
        if isinstance(obj, list):
            obj = obj[0] if obj else {}
        cq = obj.get("customQuery", "")
        fields = []
        for f in raw.get("fields", []):
            fields.append({
                "name": f.get("name", ""),
                "type": self._get_platform_type(f),
                "precision": f.get("precision", 0),
                "scale": f.get("scale", 0),
            })
        connection_id = adapter.get("connectionRef", {}).get("connectionId", "")
        opr_attrs = adapter.get("oprRuntimeAttributes", {})
        schema_var = opr_attrs.get("schemaName", "")
        return {
            "name": raw.get("name", ""),
            "id": raw.get("$$ID"),
            "fields": fields,
            "custom_query": cq,
            "object_name": obj.get("objectName", obj.get("name", "")),
            "connection_id": connection_id,
            "schema_var": schema_var,
            # --- BEGIN CHANGE 2026-04-16: adding source filters to staging ---
            "source_filters": self._extract_source_filters(cq),
            # --- END CHANGE 2026-04-16: adding source filters to staging ---
        }

    def _extract_target(self, raw: Dict) -> Dict[str, Any]:
        """Extract structured Target dict."""
        adapter = raw.get("dataAdapter", {})
        obj = adapter.get("object", {})
        if isinstance(obj, list):
            obj = obj[0] if obj else {}

        write_opts = raw.get("writeOptions", {})
        operations = []
        if isinstance(write_opts, dict):
            for k, v in write_opts.items():
                if isinstance(v, bool) and v:
                    operations.append(k)
                elif isinstance(v, str) and v.lower() == "true":
                    operations.append(k)

        update_cols = []
        for uc in raw.get("updateColumns", raw.get("updateKeyColumns", [])):
            if isinstance(uc, str):
                update_cols.append(uc)
            elif isinstance(uc, dict):
                update_cols.append(uc.get("name", uc.get("fieldName", "")))

        manual_mappings = []
        mm_data = raw.get("manualMappings", {})
        if isinstance(mm_data, dict):
            for ml in mm_data.get("mappingList", []):
                manual_mappings.append(ml)
        elif isinstance(mm_data, list):
            manual_mappings = mm_data

        fields = []
        for f in raw.get("fields", []):
            fields.append({
                "name": f.get("name", ""),
                "type": self._get_platform_type(f),
                "precision": f.get("precision", 0),
                "scale": f.get("scale", 0),
            })

        opr_attrs = adapter.get("oprRuntimeAttributes", {})
        schema_var = opr_attrs.get("schemaName", "")
        write_operation = raw.get("writeOperation", "")
        truncate = raw.get("truncateTarget", raw.get("truncate", False))
        if isinstance(truncate, str):
            truncate = truncate.lower() == "true"

        return {
            "name": raw.get("name", ""),
            "id": raw.get("$$ID"),
            "fields": fields,
            "object_name": obj.get("objectName", obj.get("name", "")),
            "operations": operations,
            "write_operation": write_operation,
            "truncate": truncate,
            "update_columns": update_cols,
            "manual_mappings": manual_mappings,
            "schema_var": schema_var,
            "excluded_fields": self._extract_excluded_fields(raw),
            "field_renames": self._extract_field_renames(raw),
            "included_fields": self._extract_included_fields(raw),
        }

    def _extract_expression(self, raw: Dict, all_tx_names: Set[str] = None) -> Dict[str, Any]:
        """Extract structured Expression dict."""
        fields = []
        for f in raw.get("fields", []):
            exp_type = f.get("expFieldType", f.get("fieldType", ""))
            is_var = f.get("variable", False)
            if isinstance(is_var, str):
                is_var = is_var.lower() == "true"
            fields.append({
                "name": f.get("name", ""),
                "expression": f.get("expression", ""),
                "exp_field_type": exp_type,
                "variable": is_var,
                "type": self._get_platform_type(f),
            })

        window_enabled = raw.get("windowConfigurationEnabled", False)
        if isinstance(window_enabled, str):
            window_enabled = window_enabled.lower() == "true"

        window_spec = {}
        ws_raw = raw.get("windowSpec", {})
        if ws_raw:
            partition_keys = []
            for pk in ws_raw.get("partitionKeys", ws_raw.get("partitionByFields", [])):
                if isinstance(pk, str):
                    partition_keys.append(pk)
                elif isinstance(pk, dict):
                    partition_keys.append(pk.get("fieldName", pk.get("name", "")))
            order_keys = []
            for ok in ws_raw.get("orderKeys", ws_raw.get("orderByFields", [])):
                if isinstance(ok, dict):
                    order_keys.append({
                        "field_name": ok.get("fieldName", ok.get("name", "")),
                        "ascending": ok.get("ascending", ok.get("sortOrder", "ASC")) != "DESC",
                    })
                elif isinstance(ok, str):
                    order_keys.append({"field_name": ok, "ascending": True})
            window_spec = {"partition_keys": partition_keys, "order_keys": order_keys}

        conflict_resolutions = []
        for grp in raw.get("groups", []):
            # Only honour conflictResolutions when the referenced upstream
            # transform actually exists. Phantom references (from deleted
            # sorters etc.) are stale IICS UI artifacts — ignore them.
            for cr in grp.get("conflictResolutions", []):
                rule = cr.get("rule", {})
                preceding_tx = cr.get("precedingTxName", "")
                is_phantom = all_tx_names is not None and preceding_tx and preceding_tx not in all_tx_names
                bulk_rename = False
                rename_prefix = ""
                is_sfx = False
                if not is_phantom:
                    bulk_rename = (
                        cr.get("bulkRename")
                        or rule.get("bulkRename")
                        or cr.get("bulkRenameOption", {}).get("enabled", False)
                    )
                    if isinstance(bulk_rename, str):
                        bulk_rename = bulk_rename.lower() == "true"
                    bro = cr.get("bulkRenameOption") or rule.get("bulkRenameOption") or {}
                    if isinstance(bro, dict):
                        rename_prefix = bro.get("literal", bro.get("prefix", ""))
                        is_sfx = str(bro.get("suffix", "false")).lower() == "true"
                conflict_resolutions.append({
                    "bulk_rename": bulk_rename,
                    "rename_prefix": rename_prefix,
                    "is_suffix": is_sfx,
                })
            # Also check rules for bulkRename with prefix (some expressions store it here)
            if not conflict_resolutions:
                for r in grp.get("rules", []):
                    br = r.get("bulkRename", "")
                    if isinstance(br, str) and br.lower() == "true":
                        bro = r.get("bulkRenameOption", {})
                        if isinstance(bro, dict):
                            prefix = bro.get("literal", bro.get("prefix", ""))
                            is_sfx = str(bro.get("suffix", "false")).lower() == "true"
                            if prefix:
                                conflict_resolutions.append({
                                    "bulk_rename": True,
                                    "rename_prefix": prefix,
                                    "is_suffix": is_sfx,
                                })

        return {
            "name": raw.get("name", ""),
            "id": raw.get("$$ID"),
            "fields": fields,
            "window_enabled": window_enabled,
            "window_spec": window_spec,
            "conflict_resolutions": conflict_resolutions,
            "excluded_fields": self._extract_excluded_fields(raw),
            "field_renames": self._extract_field_renames(raw),
            "included_fields": self._extract_included_fields(raw),
        }

    def _extract_sql_transformation(self, raw: Dict) -> Dict[str, Any]:
        """Extract structured SQL Transformation dict."""
        sql_query = raw.get("sqlQuery", "")
        fields = []
        for f in raw.get("fields", []):
            exp_type = f.get("expFieldType", f.get("fieldType", ""))
            fields.append({
                "name": f.get("name", ""),
                "expression": f.get("expression", ""),
                "exp_field_type": exp_type,
                "type": self._get_platform_type(f),
            })
        return {
            "name": raw.get("name", ""),
            "id": raw.get("$$ID"),
            "sql_query": sql_query,
            "fields": fields,
        }

    def _extract_joiner(self, raw: Dict, all_tx_names: Set[str] = None) -> Dict[str, Any]:
        """Extract structured Joiner dict."""
        join_type = raw.get("joinType", "Normal Join")
        conditions = []
        for jc in raw.get("joinConditions", []):
            conditions.append({
                "left": jc.get("leftOperand", ""),
                "operator": jc.get("operator", "="),
                "right": jc.get("rightOperand", ""),
            })
        groups = []
        all_excluded = self._extract_excluded_fields(raw)
        for g in raw.get("groups", []):
            prefix = ""
            is_suffix = False
            grp_excluded: List[str] = []
            grp_renames: Dict[str, str] = {}
            grp_included: List[str] = []
            has_catch_all = False
            # Check conflictResolutions — only honour if precedingTxName exists
            # and is NOT a sorter (sorter CTE handles its own column naming)
            for cr in g.get("conflictResolutions", []):
                rule = cr.get("rule", {})
                preceding_tx = cr.get("precedingTxName", "")
                is_phantom = all_tx_names is not None and preceding_tx and preceding_tx not in all_tx_names
                is_sorter_upstream = preceding_tx.lower().startswith("srt_") or preceding_tx.lower().startswith("sorter")
                if not is_phantom and not is_sorter_upstream:
                    br = cr.get("bulkRename", rule.get("bulkRename", ""))
                    if isinstance(br, str) and br.lower() == "true":
                        bro = cr.get("bulkRenameOption", rule.get("bulkRenameOption", {}))
                        if isinstance(bro, dict) and not prefix:
                            prefix = bro.get("literal", bro.get("prefix", ""))
                            sfx = bro.get("suffix", "false")
                            is_suffix = str(sfx).lower() == "true"
            for r in g.get("rules", []):
                bro = r.get("bulkRenameOption", {})
                has_bulk_rename = isinstance(bro, dict) and r.get("bulkRename") == "true"
                if has_bulk_rename and not prefix:
                    prefix = bro.get("literal", "")
                    sfx = bro.get("suffix", "false")
                    is_suffix = str(sfx).lower() == "true"
                is_exclude_rule = str(r.get("include", "true")).lower() == "false"
                is_include_rule = str(r.get("include", "true")).lower() == "true"
                names = r.get("names", [])
                for n in names:
                    if isinstance(n, dict):
                        inp = n.get("inputName", "")
                        out = n.get("outputName", "")
                        if inp and is_exclude_rule:
                            grp_excluded.append(inp)
                        elif inp and out and inp != out:
                            grp_renames[inp] = out
                # Track catch-all vs include-only
                if is_include_rule and not names:
                    has_catch_all = True
                elif is_include_rule and names:
                    for n in names:
                        if isinstance(n, dict):
                            inp = n.get("inputName", "")
                            out = n.get("outputName", "")
                            if inp:
                                grp_included.append(out if out else inp)
            # If catch-all exists, named includes are just renames
            if has_catch_all:
                grp_included = []
            groups.append({
                "name": g.get("name", ""),
                "id": g.get("$$ID"),
                "input": g.get("input", "false") == "true",
                "output": g.get("output", "false") == "true",
                "prefix": prefix,
                "is_suffix": is_suffix,
                "excluded_fields": grp_excluded,
                "field_renames": grp_renames,
                "included_fields": grp_included,
            })
        return {
            "name": raw.get("name", ""),
            "id": raw.get("$$ID"),
            "join_type": join_type,
            "join_conditions": conditions,
            "groups": groups,
        }

    def _extract_filter(self, raw: Dict) -> Dict[str, Any]:
        """Extract structured Filter dict."""
        adv_cond = raw.get("advancedFilterCondition", "")
        structured = []
        for fc in raw.get("filterConditions", []):
            structured.append({
                "field_name": fc.get("fieldName", ""),
                "operator": fc.get("operator", "="),
                "filter_value": fc.get("filterValue", ""),
            })
        condition = adv_cond
        if not condition and structured:
            parts = []
            for sc in structured:
                parts.append(f"{sc['field_name']} {sc['operator']} {sc['filter_value']}")
            condition = " AND ".join(parts)
        return {
            "name": raw.get("name", ""),
            "id": raw.get("$$ID"),
            "condition": condition,
            "structured_conditions": structured,
            "excluded_fields": self._extract_excluded_fields(raw),
            "field_renames": self._extract_field_renames(raw),
            "included_fields": self._extract_included_fields(raw),
        }

    def _extract_lookup(self, raw: Dict, all_tx_names: Set[str] = None) -> Dict[str, Any]:
        """Extract structured Lookup dict."""
        adapter = raw.get("dataAdapter", {})
        obj = adapter.get("object", {})
        if isinstance(obj, list):
            obj = obj[0] if obj else {}
        cq = obj.get("customQuery", "")
        unconnected = raw.get("unconnected", False)
        if isinstance(unconnected, str):
            unconnected = unconnected.lower() == "true"

        conditions = []
        for lc in raw.get("lookupConditions", []):
            conditions.append({
                "left": lc.get("leftOperand", lc.get("fieldName", "")),
                "operator": lc.get("operator", "="),
                "right": lc.get("rightOperand", lc.get("lookupFieldName", "")),
            })

        fields = []
        for f in raw.get("fields", []):
            fname = f.get("name", "")
            fields.append({
                "name": fname,
                "type": self._get_platform_type(f),
                "expression": f.get("expression", ""),
            })

        # returnPortName is at transformation level, not on individual fields
        return_port = raw.get("returnPortName", "")
        if not return_port:
            # Fallback: check field-level attributes
            for f in raw.get("fields", []):
                if f.get("returnPort", f.get("isReturnPort", "")) in (True, "true"):
                    return_port = f.get("name", "")
                    break
        input_port_names = raw.get("inputPortNames", [])

        # Only honour CR prefix if the referenced upstream transform exists.
        upstream_prefix = ""
        for g in raw.get("groups", []):
            for cr in g.get("conflictResolutions", []):
                preceding_tx = cr.get("precedingTxName", "")
                is_phantom = all_tx_names is not None and preceding_tx and preceding_tx not in all_tx_names
                is_sorter_upstream = preceding_tx.lower().startswith("srt_") or preceding_tx.lower().startswith("sorter")
                if not is_phantom and not is_sorter_upstream:
                    rule = cr.get("rule", {})
                    if rule.get("bulkRename") == "true":
                        bro = rule.get("bulkRenameOption", {})
                        if isinstance(bro, dict):
                            upstream_prefix = bro.get("literal", "")

        return {
            "name": raw.get("name", ""),
            "id": raw.get("$$ID"),
            "unconnected": unconnected,
            "custom_query": cq,
            "lookup_conditions": conditions,
            "fields": fields,
            "return_port": return_port,
            "input_port_names": input_port_names,
            "upstream_prefix": upstream_prefix,
            "object_name": obj.get("objectName", obj.get("name", "")),
            "excluded_fields": self._extract_excluded_fields(raw),
            "field_renames": self._extract_field_renames(raw),
            "included_fields": self._extract_included_fields(raw),
        }

    def _extract_router(self, raw: Dict) -> Dict[str, Any]:
        """Extract structured Router dict."""
        gfc_list = []
        for gfc in raw.get("groupFilterConditions", []):
            cond = gfc.get("advancedFilterCondition", "").strip()
            # Fall back to simpleFilterConditions when advanced is empty
            if not cond:
                simple_parts = []
                for sc in gfc.get("simpleFilterConditions", []):
                    fname = sc.get("fieldName", "")
                    op = sc.get("operator", "=")
                    val = sc.get("filterValue", "")
                    if fname and val:
                        simple_parts.append(f"{fname} {op} '{val}'")
                cond = " AND ".join(simple_parts)
            gfc_list.append({
                "name": gfc.get("name", ""),
                "condition": cond,
                "id": gfc.get("$$ID"),
            })
        # Build condition lookup by group name
        gfc_by_name = {g["name"]: g["condition"] for g in gfc_list}
        groups = []
        for g in raw.get("groups", []):
            gname = g.get("name", "")
            groups.append({
                "name": gname,
                "id": g.get("$$ID"),
                "filter_condition": gfc_by_name.get(gname, ""),
                "is_input": str(g.get("input", "false")).lower() == "true",
                "is_output": str(g.get("output", "false")).lower() == "true",
            })
        return {
            "name": raw.get("name", ""),
            "id": raw.get("$$ID"),
            "group_filter_conditions": gfc_list,
            "groups": groups,
            "excluded_fields": self._extract_excluded_fields(raw),
            "field_renames": self._extract_field_renames(raw),
            "included_fields": self._extract_included_fields(raw),
        }

    def _extract_aggregator(self, raw: Dict) -> Dict[str, Any]:
        """Extract structured Aggregator dict."""
        fields = []
        for f in raw.get("fields", []):
            fields.append({
                "name": f.get("name", ""),
                "expression": f.get("expression", ""),
                "type": self._get_platform_type(f),
            })
        group_by = []
        gbl = raw.get("groupByFieldsList", raw.get("groupByFields", []))
        # groupByFieldsList can be a dict wrapping {$$ID, $$class, fields:[...]}
        if isinstance(gbl, dict):
            gbl = gbl.get("fields", [])
        for gb in gbl:
            if isinstance(gb, str):
                group_by.append(gb)
            elif isinstance(gb, dict):
                group_by.append(gb.get("fieldName", gb.get("name", "")))

        input_fields = []
        bulk_include = False
        for grp in raw.get("groups", []):
            for rule in grp.get("rules", []):
                if str(rule.get("include", "")).lower() == "true" and not rule.get("names"):
                    bulk_include = True
                for nm in rule.get("names", []):
                    inp = nm.get("inputName", "")
                    if inp:
                        input_fields.append(inp)

        return {
            "name": raw.get("name", ""),
            "id": raw.get("$$ID"),
            "fields": fields,
            "group_by_fields": group_by,
            "input_fields": input_fields,
            "bulk_include": bulk_include,
            "excluded_fields": self._extract_excluded_fields(raw),
            "field_renames": self._extract_field_renames(raw),
            "included_fields": self._extract_included_fields(raw),
        }

    def _extract_sorter(self, raw: Dict) -> Dict[str, Any]:
        """Extract structured Sorter dict."""
        entries = []
        for se in raw.get("sortEntries", raw.get("sortFields", [])):
            if isinstance(se, dict):
                entries.append({
                    "field": se.get("fieldName", se.get("name", se.get("field", ""))),
                    "ascending": se.get("ascending", se.get("sortOrder", "ASC")) != "DESC",
                })
            elif isinstance(se, str):
                entries.append({"field": se, "ascending": True})

        distinct = False
        for ap in raw.get("advancedProperties", []):
            if isinstance(ap, dict):
                if ap.get("name", "").lower() in ("distinct", "select distinct"):
                    val = ap.get("value", "false")
                    distinct = str(val).lower() == "true"
        return {
            "name": raw.get("name", ""),
            "id": raw.get("$$ID"),
            "sort_entries": entries,
            "distinct": distinct,
            "excluded_fields": self._extract_excluded_fields(raw),
            "field_renames": self._extract_field_renames(raw),
            "included_fields": self._extract_included_fields(raw),
        }

    def _extract_union(self, raw: Dict) -> Dict[str, Any]:
        """Extract structured Union dict."""
        input_groups = []
        output_group = None
        group_id_to_name: Dict[int, str] = {}
        for g in raw.get("groups", []):
            gdata = {"name": g.get("name", ""), "id": g.get("$$ID")}
            gid = g.get("$$ID")
            gname = g.get("name", "")
            if gid is not None and gname:
                group_id_to_name[gid] = gname
            if g.get("output", "false") == "true":
                output_group = gdata
            else:
                input_groups.append(gdata)
        fields = []
        # Build output field ID -> name map for inputGroup field mapping resolution
        field_id_to_name: Dict[int, str] = {}
        for f in raw.get("fields", []):
            fields.append({"name": f.get("name", ""), "type": self._get_platform_type(f)})
            fid = f.get("$$ID")
            if fid is not None:
                field_id_to_name[fid] = f.get("name", "")

        # Parse inputGroups to build per-group field mappings:
        #   { group_name: { union_output_field_lower: branch_field_name } }
        # Keyed by union output so duplicate branch fields (e.g., ownr_id mapping
        # to both workflow_assignee_nm and assignee_id) are preserved.
        input_group_field_maps: Dict[str, Dict[str, str]] = {}
        for ig in raw.get("inputGroups", []):
            ig_name = ig.get("name", "")
            fm = ig.get("fieldMapping", {})
            mapping: Dict[str, str] = {}
            for mf in fm.get("fields", []):
                branch_field = mf.get("name", "")
                tx_ref = mf.get("txField", {})
                ref_id = tx_ref.get("##ID") if isinstance(tx_ref, dict) else None
                if ref_id is not None and ref_id in field_id_to_name:
                    union_out = field_id_to_name[ref_id]
                    mapping[union_out.lower()] = branch_field
            if mapping:
                input_group_field_maps[ig_name] = mapping

        return {
            "name": raw.get("name", ""),
            "id": raw.get("$$ID"),
            "input_groups": input_groups,
            "output_group": output_group,
            "fields": fields,
            "input_group_field_maps": input_group_field_maps,
            "group_id_to_name": group_id_to_name,
            "excluded_fields": self._extract_excluded_fields(raw),
            "field_renames": self._extract_field_renames(raw),
            "included_fields": self._extract_included_fields(raw),
        }

    def _extract_normalizer(self, raw: Dict) -> Dict[str, Any]:
        """Extract structured Normalizer dict."""
        normalized = []
        pass_through = []
        auto_generated = []
        for f in raw.get("fields", []):
            occurs = f.get("occurs", f.get("numberOfOccurrences", 1))
            if isinstance(occurs, str):
                try:
                    occurs = int(occurs)
                except ValueError:
                    occurs = 1
            fname = f.get("name", "")
            if occurs > 1:
                normalized.append({"name": fname, "occurs": occurs})
            elif fname.upper() in ("GCID", "GK"):
                auto_generated.append(fname)
            else:
                pass_through.append(fname)
        return {
            "name": raw.get("name", ""),
            "id": raw.get("$$ID"),
            "normalized_fields": normalized,
            "pass_through_fields": pass_through,
            "auto_generated_fields": auto_generated,
        }

    def _extract_rank(self, raw: Dict) -> Dict[str, Any]:
        """Extract structured Rank dict."""
        num_ranks = raw.get("numRanks", raw.get("numberOfRanks", 1))
        if isinstance(num_ranks, str):
            try:
                num_ranks = int(num_ranks)
            except ValueError:
                num_ranks = 1
        top_bottom = raw.get("topBottom", raw.get("rankType", "Top"))
        group_by = []
        for gb in raw.get("groupByFields", raw.get("groupByFieldsList", [])):
            if isinstance(gb, str):
                group_by.append(gb)
            elif isinstance(gb, dict):
                group_by.append(gb.get("fieldName", gb.get("name", "")))
        order_field = raw.get("orderByField", raw.get("rankField", ""))
        if isinstance(order_field, dict):
            order_field = order_field.get("fieldName", order_field.get("name", ""))
        rank_port = "RANKINDEX"
        fields = []
        for f in raw.get("fields", []):
            fname = f.get("name", "")
            fields.append({"name": fname, "type": self._get_platform_type(f)})
            if fname.upper() == "RANKINDEX":
                rank_port = fname
        return {
            "name": raw.get("name", ""),
            "id": raw.get("$$ID"),
            "num_ranks": num_ranks,
            "top_bottom": top_bottom,
            "group_by_fields": group_by,
            "order_by_field": order_field,
            "rank_port": rank_port,
            "fields": fields,
            "excluded_fields": self._extract_excluded_fields(raw),
            "field_renames": self._extract_field_renames(raw),
            "included_fields": self._extract_included_fields(raw),
        }

    def _extract_sequence(self, raw: Dict) -> Dict[str, Any]:
        """Extract structured Sequence Generator dict."""
        start_val = raw.get("startValue", raw.get("start", 1))
        inc = raw.get("incrementBy", raw.get("increment", 1))
        return {
            "name": raw.get("name", ""),
            "id": raw.get("$$ID"),
            "start_value": start_val,
            "increment_by": inc,
            "excluded_fields": self._extract_excluded_fields(raw),
            "field_renames": self._extract_field_renames(raw),
            "included_fields": self._extract_included_fields(raw),
        }

    def _extract_mapplet(self, raw: Dict) -> Dict[str, Any]:
        """Extract structured Mapplet dict."""
        is_ref = raw.get("isReferenced", raw.get("referenced", False))
        if isinstance(is_ref, str):
            is_ref = is_ref.lower() == "true"
        ref_name = raw.get("referencedMappletName", raw.get("mappletName", ""))
        input_ports = []
        output_ports = []
        for f in raw.get("fields", []):
            port_type = f.get("portType", f.get("fieldType", ""))
            entry = {"name": f.get("name", ""), "expression": f.get("expression", "")}
            if port_type in ("INPUT", "INPUT/OUTPUT"):
                input_ports.append(entry)
            if port_type in ("OUTPUT", "INPUT/OUTPUT"):
                output_ports.append(entry)
        return {
            "name": raw.get("name", ""),
            "id": raw.get("$$ID"),
            "is_referenced": is_ref,
            "referenced_mapplet_name": ref_name,
            "input_ports": input_ports,
            "output_ports": output_ports,
        }

    # ------------------------------------------------------------------
    # Variables
    # ------------------------------------------------------------------

    def _extract_variables(self, variables_raw: List[Dict]) -> Dict[str, Dict]:
        """Extract mapping-level variables."""
        result: Dict[str, Dict] = {}
        for v in variables_raw:
            name = v.get("name", "")
            if name:
                result[name] = {
                    "default": v.get("defaultValue", ""),
                    "type": self._get_platform_type(v),
                    "description": v.get("description", ""),
                }
        return result

    # ------------------------------------------------------------------
    # Load type determination
    # ------------------------------------------------------------------

    def _determine_load_type(self, targets: List[Dict], routers: List[Dict], joiners: List[Dict] = None) -> str:
        """Determine CDC vs FULL load type."""
        # Check router groups for insert/update pattern (name-based)
        # Requires SEPARATE groups for insert and update — a single combined
        # group name like "lnkInsUpdRecs" does not indicate CDC.
        for r in routers:
            group_names = {g.get("name", "").lower() for g in r.get("group_filter_conditions", [])}
            group_names.update(g.get("name", "").lower() for g in r.get("groups", []))
            insert_groups = {gn for gn in group_names if "insert" in gn or "insrt" in gn or "ins" in gn}
            update_groups = {gn for gn in group_names if "update" in gn or "updt" in gn or "upd" in gn}
            # Exclude groups that match BOTH — they're combined, not separate
            insert_only = insert_groups - update_groups
            update_only = update_groups - insert_groups
            if insert_only and update_only:
                return "CDC"

        # Check router conditions for change_code pattern (condition-based)
        for r in routers:
            conditions = [g.get("condition", "").lower() for g in r.get("group_filter_conditions", [])]
            has_changecode = any("change_code" in c or "changecode" in c for c in conditions)
            if has_changecode:
                has_ins_code = any("= '1'" in c or "=1" in c.replace(" ", "") for c in conditions)
                has_upd_del = any("= '3'" in c or "= '2'" in c or "=3" in c.replace(" ", "") or "=2" in c.replace(" ", "") or "!= '1'" in c for c in conditions)
                if has_ins_code and has_upd_del:
                    return "CDC"

        # Check targets
        for t in targets:
            wo = t.get("write_operation", "").upper()
            if wo in ("DATA_DRIVEN", "UPSERT"):
                return "CDC"
            ops = [o.lower() for o in t.get("operations", [])]
            has_ins = any("insert" in o for o in ops)
            has_upd = any("update" in o for o in ops)
            if has_ins and has_upd:
                return "CDC"

        # Check target names for insert/update pattern
        target_names = [t.get("name", "").lower() for t in targets]
        has_insrt = any("insrt" in n or "insert" in n or "ins" in n for n in target_names)
        has_updt = any("updt" in n or "update" in n or "upd" in n for n in target_names)
        if has_insrt and has_updt:
            return "CDC"

        # SCD Type 2 pattern: Full Outer Join + Active/Inactive target pair
        if joiners:
            has_full_outer = any(
                "full" in j.get("join_type", "").lower() for j in joiners
            )
            has_active_tgt = any(
                "active" in n and "inactive" not in n for n in target_names
            )
            has_inactive_tgt = any("inactive" in n for n in target_names)
            if has_full_outer and has_active_tgt and has_inactive_tgt:
                return "CDC"

        return "FULL"

    @staticmethod
    def _detect_scd_subtype(mapping: Dict) -> str:
        """Detect SCD Type 1 vs Type 2 for CDC mappings.

        Classification based on target audit columns:
        - Type 2: targets have edh_record_start_ts + edh_record_end_ts
                  (history tracking with record validity window).
        - Type 1: targets lack these columns — updates overwrite in place.
        """
        if mapping.get("load_type") != "CDC":
            return ""
        for t in mapping.get("targets", []):
            tname = t.get("name", "").lower()
            # Skip non-business targets
            if any(kw in tname for kw in ("error", "reject", "batchkey", "historysk", "lastsk")):
                continue
            field_names = {
                f.get("name", "").lower()
                for f in t.get("fields", [])
                if isinstance(f, dict)
            }
            if "edh_record_start_ts" in field_names and "edh_record_end_ts" in field_names:
                return "SCD_TYPE2"
        return "SCD_TYPE1"

    @staticmethod
    def _compute_cdc_skip_ids(mapping: Dict) -> Set[int]:
        """Compute the set of node IDs that are CDC-infrastructure and should
        be skipped when building the intermediate model for CDC mappings.

        For Full-Outer-Join CDC: skips the FOJ + all downstream + the
        reference-only pipeline feeding the Detail side.
        For Lookup-based CDC: skips the CDC lookup + all downstream.
        """
        if mapping.get("load_type") != "CDC":
            return set()

        dag = mapping.get("dag", {})
        reverse_dag = mapping.get("reverse_dag", {})
        link_to_group_map = mapping.get("link_to_group_map", {})
        joiners = mapping.get("joiners", [])
        lookups = mapping.get("lookups", [])
        targets = mapping.get("targets", [])

        skip: Set[int] = set()

        # ---- Full Outer Join boundary ----
        foj_ids: Set[int] = set()
        for j in joiners:
            if "full" in j.get("join_type", "").lower():
                foj_ids.add(j["id"])

        if foj_ids:
            # 1) Forward-walk from each FOJ to collect all downstream CDC nodes
            queue = list(foj_ids)
            while queue:
                nid = queue.pop()
                if nid in skip:
                    continue
                skip.add(nid)
                for succ in dag.get(nid, []):
                    if succ not in skip:
                        queue.append(succ)

            # 2) Identify Detail-side predecessors of each FOJ
            detail_preds: Set[int] = set()
            for foj_id in foj_ids:
                joiner = next((j for j in joiners if j["id"] == foj_id), None)
                if not joiner:
                    continue
                for pred_id in reverse_dag.get(foj_id, []):
                    to_grp_id = link_to_group_map.get((pred_id, foj_id))
                    if to_grp_id is None:
                        continue
                    for grp in joiner.get("groups", []):
                        if grp.get("id") == to_grp_id and grp.get("name", "").lower() == "detail":
                            detail_preds.add(pred_id)

            # 3) Strip detail-side reference source nodes only.
            #    The detail side *may* be a small reference pipeline (just
            #    a source reading the target table) OR the full business
            #    pipeline (master/detail swapped).  Only strip source
            #    nodes here to avoid cascading into the business pipeline.
            source_ids = {s["id"] for s in mapping.get("sources", []) if "id" in s}
            for dp in detail_preds:
                if dp in source_ids and dp not in skip:
                    successors = dag.get(dp, [])
                    if successors and all(s in skip for s in successors):
                        skip.add(dp)

        # ---- Lookup-based CDC (no FOJ found) ----
        if not foj_ids:
            # Build set of target table names (last component of object_name)
            target_tables: Set[str] = set()
            for tgt in targets:
                obj_name = tgt.get("object_name", "")
                if obj_name:
                    table = obj_name.split("/")[-1].lower()
                    if table:
                        target_tables.add(table)

            # Find connected lookups whose CQ references a target table
            for lkp in lookups:
                if lkp.get("unconnected"):
                    continue
                cq = lkp.get("custom_query", "").lower()
                if not cq:
                    continue
                if any(tbl in cq for tbl in target_tables):
                    # This is a CDC lookup — skip it + all downstream
                    lkp_id = lkp["id"]
                    queue = [lkp_id]
                    while queue:
                        nid = queue.pop()
                        if nid in skip:
                            continue
                        skip.add(nid)
                        for succ in dag.get(nid, []):
                            if succ not in skip:
                                queue.append(succ)

        # ---- Backward cascade: strip orphaned CDC-prep nodes ----
        # Only cascade when at least one target is NOT in the skip set
        # (an "anchor" like a reject/error target). Without an anchor the
        # cascade would propagate all the way back through the business
        # pipeline for mappings with no reject branching.
        target_ids = {t["id"] for t in targets if "id" in t}
        has_anchor = any(tid not in skip for tid in target_ids)
        if has_anchor:
            source_ids = {s["id"] for s in mapping.get("sources", []) if "id" in s}
            # Protect merge/convergence nodes (multiple predecessors feeding in)
            # — these are business pipeline nodes (unions, joiners), not CDC prep.
            merge_ids: Set[int] = set()
            for nid in reverse_dag:
                if len(reverse_dag.get(nid, [])) > 1:
                    merge_ids.add(nid)
            changed = True
            while changed:
                changed = False
                for nid in list(dag.keys()):
                    if nid in skip or nid in source_ids or nid in merge_ids:
                        continue
                    successors = dag.get(nid, [])
                    if successors and all(s in skip for s in successors):
                        skip.add(nid)
                        changed = True

        return skip


# ===================================================================
# ConfigGenerator
# ===================================================================

class ConfigGenerator:
    """Generates dbt configuration files (source.yml, schema.yml, dbt_project.yml, macros)."""

    def __init__(self, output_dir: Path, param_overrides: Dict[str, str] = None) -> None:
        self.output_dir = Path(output_dir)
        self.param_overrides = param_overrides or {}
        self.logger = setup_logging("ConfigGenerator")

    # ------------------------------------------------------------------
    # source.yml
    # ------------------------------------------------------------------

    def write_source_yml(self, all_entries: List[Dict[str, str]]) -> Path:
        """Write source.yml grouped by schema, deduped by schema.table.

        Args:
            all_entries: List of dicts with source_name, schema, table, description.

        Returns:
            Path to the written source.yml file.
        """
        # Group by schema, dedup by (schema, table)
        seen: Set[str] = set()
        grouped: Dict[str, Dict] = OrderedDict()
        for entry in all_entries:
            schema = entry.get("schema", "unknown_schema")
            table = entry.get("table", "")
            key = f"{schema}.{table}"
            if key in seen or not table:
                continue
            seen.add(key)
            source_name = entry.get("source_name", schema)
            if schema not in grouped:
                grouped[schema] = {
                    "name": source_name,
                    "database": "edm",
                    "schema": schema,
                    "tables": [],
                }
            grouped[schema]["tables"].append({
                "name": table,
                "description": entry.get("description", f"Source table {table}"),
            })

        sources_list = list(grouped.values())
        data = {"version": "2", "sources": sources_list}

        output_path = self.output_dir / "models" / "source.yml"
        output_path.parent.mkdir(parents=True, exist_ok=True)
        save_yaml(data, output_path)
        self.logger.info(f"source.yml written with {len(sources_list)} source group(s)")
        return output_path

    # ------------------------------------------------------------------
    # schema.yml (per-layer)
    # ------------------------------------------------------------------

    def write_schema_yml(self, models: List[Dict], path: Path) -> Path:
        """Write a schema.yml for a specific dbt layer.

        Args:
            models: List of model dicts with name, description, columns.
            path: Output path for the schema file.

        Returns:
            Path to the written schema.yml file.
        """
        model_entries = []
        for m in models:
            entry: Dict[str, Any] = {
                "name": m.get("name", ""),
                "description": m.get("description", ""),
            }
            cols = m.get("columns", [])
            if cols:
                entry["columns"] = [
                    {"name": c["name"], "description": c.get("description", "")}
                    for c in cols[:30]
                ]
            model_entries.append(entry)

        data = {"version": 2, "models": model_entries}
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        save_yaml(data, path)
        self.logger.info(f"schema.yml written: {path} ({len(model_entries)} models)")
        return path

    # ------------------------------------------------------------------
    # dbt_project.yml
    # ------------------------------------------------------------------

    def write_dbt_project_yml(
        self,
        mapping_schemas: Dict[str, str],
        all_variables: Dict[str, Any],
    ) -> Path:
        """Write dbt_project.yml with vars and model config.

        Args:
            mapping_schemas: Dict of safe_mapping_name -> target_schema.
            all_variables: Dict of variable_name -> default_value.

        Returns:
            Path to the written dbt_project.yml.
        """
        # Determine project name
        mapping_names = list(mapping_schemas.keys())
        if len(mapping_names) == 1:
            project_name = mapping_names[0]
        else:
            project_name = "edm_dbt_project"

        # Build vars block — all values single-quoted in YAML.
        vars_block: Dict[str, Any] = {}
        for var_name, var_entry in all_variables.items():
            if isinstance(var_entry, dict):
                val = var_entry.get("value", "")
                var_type = var_entry.get("type", "string").lower()
            else:
                val = var_entry
                var_type = "string"
            # Numeric/integer types: bare number in YAML; everything else: single-quoted.
            if var_type in FunctionTranslator._NUMERIC_VAR_TYPES and val:
                try:
                    vars_block[var_name] = int(val)
                except (ValueError, TypeError):
                    try:
                        vars_block[var_name] = float(val)
                    except (ValueError, TypeError):
                        vars_block[var_name] = _SingleQuotedStr(val)
            else:
                vars_block[var_name] = _SingleQuotedStr(val) if val else _SingleQuotedStr("")

        # Build models config
        models_config: Dict[str, Any] = {
            project_name: {
                "staging": {
                    "+materialized": "view",
                },
                "intermediate": {
                    "+materialized": "table",
                },
                "marts": {
                    "+materialized": "table",
                },
                "+post_hook": ["{{ grant_privileges() }}"],
            }
        }

        # Add per-mapping schema config to marts
        for safe_name_key, schema in mapping_schemas.items():
            if schema:
                models_config[project_name]["marts"][safe_name_key] = {
                    "+schema": schema,
                    "+materialized": "table",
                }

        project_data = {
            "name": project_name,
            "version": "1.0.0",
            "profile": project_name,
            "model-paths": ["models"],
            "analysis-paths": ["analyses"],
            "test-paths": ["tests"],
            "seed-paths": ["seeds"],
            "macro-paths": ["macros"],
            "snapshot-paths": ["snapshots"],
            "clean-targets": ["target", "dbt_packages"],
            "vars": vars_block,
            "models": models_config,
            "snapshots": {
                project_name: {
                    "+post_hook": ["{{ grant_privileges() }}"],
                }
            },
        }

        output_path = self.output_dir / "dbt_project.yml"
        output_path.parent.mkdir(parents=True, exist_ok=True)
        save_yaml(project_data, output_path)
        self.logger.info(f"dbt_project.yml written")
        return output_path

    # ------------------------------------------------------------------
    # Macros
    # ------------------------------------------------------------------

    def generate_macros(self, mapplets: List[Dict] = None) -> None:
        """Generate standard macros and mapplet-derived macros.

        Args:
            mapplets: Optional list of mapplet dicts to generate macros for.
        """
        macros_dir = self.output_dir / "macros"
        macros_dir.mkdir(parents=True, exist_ok=True)

        # generate_sk.sql
        sk_macro = """\
{% macro generate_sk(sk, target_table=none) %}
{%- if target_table is not none -%}
  {%- set lookup_table = ref(target_table) -%}
{%- else -%}
  {%- set lookup_table = this -%}
{%- endif -%}
{%- set source_relation = adapter.get_relation(
    database=lookup_table.database,
    schema=lookup_table.schema,
    identifier=lookup_table.identifier) -%}

{% set table_exists = source_relation is not none %}

{% if table_exists %}
(SELECT COALESCE(MAX({{ sk }}), 0) FROM {{ lookup_table }}) +
CAST(ROW_NUMBER() OVER (ORDER BY 1) AS BIGINT)
{% else %}
CAST(ROW_NUMBER() OVER (ORDER BY 1) AS BIGINT)
{% endif %}
{% endmacro %}
"""
        (macros_dir / "generate_sk.sql").write_text(sk_macro, encoding="utf-8")
        self.logger.info("Macro written: generate_sk.sql")

        # generate_chksum.sql
        chksum_macro = """\
{% macro generate_chksum(columns) %}
{#
    Generate an MD5 checksum from a list of column names.
    Args:
        columns: List of column name strings.
#}
cast(md5(
    {% for col in columns %}
    coalesce(cast({{ col }} as string), '')
    {%- if not loop.last %} || '|' || {% endif %}
    {% endfor %}
) as string)
{% endmacro %}
"""
        (macros_dir / "generate_chksum.sql").write_text(chksum_macro, encoding="utf-8")
        self.logger.info("Macro written: generate_chksum.sql")

        # generate_snapshot_key.sql
        snap_key_macro = """\
{% macro generate_snapshot_key(columns) %}
{#
    Generate a snapshot key by concatenating column values with '|' delimiter.
    Args:
        columns: List of column name strings.
#}
{% for col in columns %}
coalesce(cast({{ col }} as string), '')
{%- if not loop.last %} || '|' || {% endif %}
{% endfor %}
{% endmacro %}
"""
        (macros_dir / "generate_snapshot_key.sql").write_text(snap_key_macro, encoding="utf-8")
        self.logger.info("Macro written: generate_snapshot_key.sql")

        # grant_privileges.sql
        grant_macro = """\
{% macro grant_privileges() %}
-- TODO: Configure environment-specific row-level grants
-- Example:
--   GRANT SELECT ON {{ this }} TO ROLE {{ var('ro_role') }};
--   GRANT ALL ON {{ this }} TO ROLE {{ var('rw_role') }};
{% endmacro %}
"""
        (macros_dir / "grant_privileges.sql").write_text(grant_macro, encoding="utf-8")
        self.logger.info("Macro written: grant_privileges.sql")


        # Mapplet-derived macros
        if mapplets:
            translator = FunctionTranslator()
            for mpl in mapplets:
                if not mpl.get("is_referenced"):
                    continue
                mpl_name = safe_name(mpl.get("name", "mapplet"))
                input_ports = mpl.get("input_ports", [])
                output_ports = mpl.get("output_ports", [])

                params = ", ".join(p["name"] for p in input_ports)
                lines = [f"{{% macro {mpl_name}({params}) %}}"]
                lines.append("SELECT")
                for idx, op in enumerate(output_ports):
                    expr = op.get("expression", "")
                    if expr:
                        translated = translator.translate(expr)
                        col_line = f"    {translated} AS {op['name']}"
                    else:
                        col_line = f"    {op['name']}"
                    if idx < len(output_ports) - 1:
                        col_line += ","
                    lines.append(col_line)
                lines.append("{% endmacro %}")

                macro_path = macros_dir / f"{mpl_name}.sql"
                macro_path.write_text("\n".join(lines), encoding="utf-8")
                self.logger.info(f"Mapplet macro written: {mpl_name}.sql")


# ===================================================================
# IDMCGenerator
# ===================================================================

def _cast_null(translated: str) -> str:
    """If translated expression is bare NULL, wrap as CAST(NULL AS STRING)."""
    if translated.strip().upper() == "NULL":
        return "CAST(NULL AS STRING)"
    return translated


class IDMCGenerator(BaseGenerator):
    """Orchestrates dbt project generation from parsed IDMC mappings.

    Extends BaseGenerator. Two-phase generation:
      Phase 1 — per-mapping (intermediate, snapshot, marts)
      Phase 2 — cross-mapping (staging, source intermediate, configs)
    """

    def __init__(
        self,
        parsed_results: Dict[str, Any],
        plans_dir: str = "plans",
        output_dir: str = "output",
    ) -> None:
        super().__init__(plans_dir=plans_dir, output_dir=output_dir)
        self.parsed = parsed_results
        self.translator = FunctionTranslator()
        self.param_overrides = self._load_param_files()

        # Cross-mapping registries
        self.stg_registry: Dict[Tuple[str, str], List[str]] = OrderedDict()
        self.stg_schema_map: Dict[Tuple[str, str], str] = {}
        # --- BEGIN CHANGE 2026-04-16: adding source filters to staging ---
        self.stg_filters: Dict[Tuple[str, str], Dict[str, str]] = {}
        # --- END CHANGE 2026-04-16: adding source filters to staging ---
        self._cq_table_schemas: Dict[Tuple[str, str], str] = {}
        # Key: (source_name, table_name, mapping_safe_name, sq_safe_name) — per-SQ source intermediates
        self.src_int_registry: Dict[Tuple[str, str, str, str], Dict] = OrderedDict()
        # Resolved model names: (source_name, table_name, mapping_safe, sq_safe) → model_name
        self.src_int_model_names: Dict[Tuple[str, str, str, str], str] = {}

        # Accumulators for Phase 2
        self.all_source_entries: List[Dict[str, str]] = []
        self.all_stg_models: List[Dict] = []
        self.all_int_models: List[Dict] = []
        self.all_mart_models: List[Dict] = []
        self.mapping_schemas: Dict[str, str] = {}
        self.all_variables: Dict[str, Any] = {}
        self.all_mapplets: List[Dict] = []
        # Track source intermediate keys that only feed CDC-stripped nodes
        self._cdc_only_src_int_keys: Set[Tuple[str, str, str, str]] = set()

        # Track columns produced by each intermediate (for mart generation)
        self._intermediate_columns: Dict[str, Set[str]] = {}

    # ------------------------------------------------------------------
    # Param file loading
    # ------------------------------------------------------------------

    def _load_param_files(self) -> Dict[str, str]:
        """Load knowledgebase/*.param files into a dict."""
        overrides: Dict[str, str] = {}
        kb_dir = get_project_root() / "knowledgebase"
        if not kb_dir.exists():
            return overrides
        for pf in sorted(kb_dir.glob("*.param")):
            try:
                text = pf.read_text(encoding="utf-8")
                for line in text.splitlines():
                    line = line.strip()
                    if not line or line.startswith("#") or line.startswith("["):
                        continue
                    if "=" in line and line.startswith("$$"):
                        key, _, val = line.partition("=")
                        key = key.lstrip("$").strip()
                        val = val.strip()
                        if key and val:
                            overrides[key] = val
            except Exception as e:
                self.logger.warning(f"Failed to parse param file {pf.name}: {e}")
        self.logger.info(f"Loaded {len(overrides)} param overrides from knowledgebase")
        return overrides

    # ------------------------------------------------------------------
    # Main generate() orchestrator
    # ------------------------------------------------------------------

    def generate(self) -> None:
        """Generate the complete dbt project.

        Phase 1: Per-mapping processing.
        Phase 2: Cross-mapping outputs (staging, source int, configs).
        """
        if not self.parsed:
            self.logger.warning("No parsed data to generate from")
            return

        # ---- Phase 1: Per-mapping ----
        for mapping_key, mapping in self.parsed.items():
            self.logger.info(f"=== Phase 1: Processing mapping '{mapping.get('mapping_name', mapping_key)}' ===")
            mapping_name = mapping.get("mapping_name", mapping_key)
            safe_mapping = safe_name(mapping_name)

            # Accumulate variables (preserve type for dbt_project.yml and SQL quoting)
            for var_name, var_info in mapping.get("variables", {}).items():
                resolved = self._resolve_variable(var_name, var_info.get("default", ""))
                var_type = var_info.get("type", "string")
                self.all_variables[var_name] = {
                    "value": resolved,
                    "type": var_type,
                }
                self.translator.variable_types[var_name] = var_type.lower()

            # Classify targets
            main_targets, ops_targets = self._classify_targets(mapping)

            # Register staging columns (Phase 1 step 3)
            for src in mapping.get("sources", []):
                self._register_staging_columns(src, mapping)

            # Register connected lookup sources for staging (they reference external tables)
            for lkp in mapping.get("lookups", []):
                if not lkp.get("unconnected") and lkp.get("custom_query"):
                    lkp_cq = lkp.get("custom_query", "")
                    lkp_as_source = {
                        "name": lkp.get("name", ""),
                        "fields": lkp.get("fields", []),
                        "custom_query": lkp_cq,
                        "object_name": lkp.get("object_name", ""),
                        "schema_var": "",
                        # --- BEGIN CHANGE 2026-04-16: adding source filters to staging ---
                        "source_filters": IDMCParser._extract_source_filters(lkp_cq),
                        # --- END CHANGE 2026-04-16: adding source filters to staging ---
                    }
                    self._register_staging_columns(lkp_as_source, mapping)
                    self._register_source_intermediate(lkp_as_source, mapping)

            # Register source intermediates (Phase 1 step 4)
            for src in mapping.get("sources", []):
                self._register_source_intermediate(src, mapping)

            # Register unconnected lookups for :LKP translation
            self._register_lookup_translations(mapping)

            # Resolve source intermediate model names (detect SQ collisions)
            self._resolve_source_int_model_names()
            self._resolve_lookup_refs()

            # Compute and store SCD subtype for downstream use
            if mapping.get("load_type") == "CDC":
                mapping["scd_subtype"] = IDMCParser._detect_scd_subtype(mapping)

            # Generate mapping intermediate (Phase 1 step 5)
            self._generate_intermediate_sql(mapping, main_targets, ops_targets)

            # Generate snapshot for CDC (Phase 1 step 6)
            if mapping.get("load_type") == "CDC":
                insert_target = self._find_insert_target(main_targets)
                if insert_target:
                    target_table = insert_target.get("object_name", "").split("/")[-1].lower()
                    self._generate_snapshot_sql(mapping, insert_target, target_table)

            # Generate marts (Phase 1 step 7)
            if mapping.get("load_type") == "CDC":
                # CDC: generate one mart using the insert/active target
                cdc_tgt = self._find_insert_target(main_targets)
                if cdc_tgt:
                    target_table = cdc_tgt.get("object_name", "").split("/")[-1].lower()
                    scd_sub = IDMCParser._detect_scd_subtype(mapping)
                    if scd_sub == "SCD_TYPE1":
                        self._generate_marts_sql_type1(mapping, cdc_tgt, target_table)
                    else:
                        self._generate_marts_sql(mapping, cdc_tgt, target_table)
            else:
                for tgt in main_targets:
                    target_table = tgt.get("object_name", "").split("/")[-1].lower()
                    self._generate_marts_sql_full(mapping, tgt, target_table)

            # Accumulate mapping schemas (keyed by target table name for dbt_project.yml)
            mart_target = self._find_insert_target(main_targets) if mapping.get("load_type") == "CDC" else (main_targets[0] if main_targets else None)
            mart_table = mart_target.get("object_name", "").split("/")[-1].lower() if mart_target else safe_mapping
            target_schema = self._get_target_schema(mapping)
            self.mapping_schemas[mart_table] = target_schema

            # Collect mapplets
            self.all_mapplets.extend(mapping.get("mapplets", []))

        # ---- Phase 2: Cross-mapping ----
        self.logger.info("=== Phase 2: Cross-mapping outputs ===")

        # Step 9: Write staging files
        self._write_all_staging_files()

        # Step 10: Write source intermediate files
        self._write_all_source_intermediate_files()

        # Step 11: Write configs
        self._collect_source_entries()
        config_gen = ConfigGenerator(self.output_dir, self.param_overrides)
        config_gen.write_source_yml(self.all_source_entries)
        config_gen.write_schema_yml(
            self.all_stg_models,
            self.output_dir / "models" / "staging" / "schema.yml",
        )
        config_gen.write_schema_yml(
            self.all_int_models,
            self.output_dir / "models" / "intermediate" / "schema.yml",
        )
        config_gen.write_schema_yml(
            self.all_mart_models,
            self.output_dir / "models" / "marts" / "schema.yml",
        )
        config_gen.write_dbt_project_yml(self.mapping_schemas, self.all_variables)
        config_gen.generate_macros(self.all_mapplets)

        self.logger.info("=== Generation complete ===")

    # ------------------------------------------------------------------
    # Helper: resolve variables
    # ------------------------------------------------------------------

    def _resolve_variable(self, var_name: str, default: str = "") -> str:
        """Resolve a variable name to its value using param overrides."""
        return self.param_overrides.get(var_name, default).strip()

    # ------------------------------------------------------------------
    # Helper: classify targets
    # ------------------------------------------------------------------

    @staticmethod
    def _classify_targets(mapping: Dict) -> Tuple[List[Dict], List[Dict]]:
        """Separate main business targets from infrastructure/reject targets.

        Uses structural signals — no name matching:
        - EDH count = 2 (edh_insert_ts + edh_insert_job_nm only) → reject/error table
        - EDH count = 0 AND no surrogate key (_sk) → infrastructure table (ops/config)
        - Everything else → main business target
        - When multiple targets share the same object_name, keep only one (first)
        """
        main: List[Dict] = []
        ops: List[Dict] = []
        seen_objects: set = set()

        for t in mapping.get("targets", []):
            fields = [f for f in t.get("fields", []) if isinstance(f, dict) and f.get("name")]
            edh_fields = [f.get("name", "") for f in fields if "edh_" in f.get("name", "").lower()]
            edh_count = len(edh_fields)
            has_sk = any("_sk" in f.get("name", "").lower() for f in fields)
            has_only_insert_edh = (
                edh_count == 2
                and any("insert_ts" in e.lower() for e in edh_fields)
                and any("insert_job" in e.lower() or "insert_nm" in e.lower() for e in edh_fields)
            )

            # Reject/error tables: exactly 2 EDH fields (edh_insert_ts + edh_insert_job_nm)
            if has_only_insert_edh:
                ops.append(t)
                continue

            # Infrastructure tables: 0 EDH and no surrogate key
            if edh_count == 0 and not has_sk:
                # Could be a simple FULL load target (gmad, pdds) — check if it's the
                # only non-infra target by deferring: if object_name is unique, keep it
                obj = t.get("object_name", "").split("/")[-1].lower()
                # Check if any OTHER target in this mapping writes to a different
                # object with more EDH columns (meaning this one is infra)
                other_has_edh = any(
                    len([f for f in ot.get("fields", [])
                         if isinstance(f, dict) and "edh_" in f.get("name", "").lower()]) >= 6
                    for ot in mapping.get("targets", [])
                    if ot.get("object_name", "") != t.get("object_name", "")
                )
                if other_has_edh:
                    ops.append(t)
                    continue
                # No other target has EDH — this is a simple FULL load, keep it

            # De-duplicate by object_name: keep first target per object
            obj = t.get("object_name", "").split("/")[-1].lower()
            if obj in seen_objects:
                continue  # Same table, different operation — already captured
            seen_objects.add(obj)
            main.append(t)

        return main, ops

    # ------------------------------------------------------------------
    # Helper: find insert target
    # ------------------------------------------------------------------

    @staticmethod
    def _find_insert_target(targets: List[Dict]) -> Optional[Dict]:
        """Find the primary business target from a list of main targets.

        Uses structural signals — no name matching:
        - Target with most business fields (non-EDH, non-SK) wins
        - Tie-breaker: first target in list
        """
        if not targets:
            return None
        if len(targets) == 1:
            return targets[0]

        # Score by business field count (total - EDH - SK)
        def biz_score(t: Dict) -> int:
            fields = [f for f in t.get("fields", []) if isinstance(f, dict) and f.get("name")]
            edh = sum(1 for f in fields if "edh_" in f.get("name", "").lower())
            sk = sum(1 for f in fields if "_sk" in f.get("name", "").lower())
            return len(fields) - edh - sk

        return max(targets, key=biz_score)

    # ------------------------------------------------------------------
    # Source info derivation
    # ------------------------------------------------------------------

    def _derive_source_info(
        self, source: Dict, mapping: Dict
    ) -> Tuple[str, str, str]:
        """Derive (source_name, schema_name, table_name) for a source.

        Resolution chain:
        1. Table: from CQ pattern or object_name
        2. Schema: from $$var in CQ -> param overrides -> JSON variables
        3. Source name: from schema via _schema_to_source_name()
        """
        cq = source.get("custom_query", "")
        obj_name = source.get("object_name", "")
        table_name = ""
        schema_name = ""

        if cq:
            # Try to extract $$VAR.table or $$VAR.$$table from CQ
            var_table_match = re.search(
                r'\$\$([A-Za-z_][A-Za-z0-9_]*)\.((?:\$\$)?[A-Za-z_]\w*)', cq
            )
            if var_table_match:
                var_name = var_table_match.group(1)
                raw_table_ref = var_table_match.group(2)
                # If table part starts with $$, it's a variable — resolve it
                if raw_table_ref.startswith("$$"):
                    tbl_var = raw_table_ref[2:]  # Strip $$
                    table_name = self._resolve_variable(
                        tbl_var, mapping.get("variables", {}).get(tbl_var, {}).get("default", "")
                    ).lower()
                    if not table_name:
                        table_name = tbl_var.lower()
                else:
                    table_name = raw_table_ref.lower()
                schema_name = self._resolve_variable(
                    var_name, mapping.get("variables", {}).get(var_name, {}).get("default", "")
                )

        if not table_name:
            if cq:
                # CQ exists but regex couldn't parse it — warn, don't silently guess
                self.logger.warning(
                    f"Source '{source.get('name', '')}': could not extract table name "
                    f"from customQuery. CQ starts with: {cq[:80]!r}"
                )
            table_name = obj_name.lower() if obj_name else safe_name(source.get("name", ""))
        if not schema_name:
            # Try schema_var from the data adapter
            schema_var = source.get("schema_var", "")
            if schema_var:
                clean_var = schema_var.lstrip("$")
                schema_name = self._resolve_variable(
                    clean_var,
                    mapping.get("variables", {}).get(clean_var, {}).get("default", ""),
                )
            if not schema_name:
                if cq:
                    # CQ exists but schema couldn't be resolved — use unknown_schema.
                    # Do NOT scan all variables for any random schema — that causes
                    # unrelated sources to inherit the wrong schema.
                    self.logger.warning(
                        f"Source '{source.get('name', '')}': could not resolve schema "
                        f"from customQuery variable or param files. Using unknown_schema."
                    )
            if not schema_name:
                schema_name = "unknown_schema"

        schema_name = schema_name.strip()
        table_name = table_name.strip()
        source_name = self._schema_to_source_name(schema_name)
        return source_name, schema_name, table_name

    @staticmethod
    def _schema_to_source_name(schema: str) -> str:
        """Convert schema to dbt source name: strip ext_lake_, prepend dl_."""
        s = schema
        if s.startswith("ext_lake_"):
            s = s[len("ext_lake_"):]
        return f"dl_{s}"

    @staticmethod
    def _short_schema(schema: str) -> str:
        """Get short schema: last two underscore-separated words."""
        parts = schema.split("_")
        if len(parts) <= 2:
            return schema
        return "_".join(parts[-2:])

    # ------------------------------------------------------------------
    # Target schema
    # ------------------------------------------------------------------

    def _get_target_schema(self, mapping: Dict) -> str:
        """Get target schema from variables or param overrides."""
        # Look for schema variable in targets
        for tgt in mapping.get("targets", []):
            sv = tgt.get("schema_var", "")
            if sv:
                clean = sv.lstrip("$")
                resolved = self._resolve_variable(
                    clean, mapping.get("variables", {}).get(clean, {}).get("default", "")
                )
                if resolved:
                    return resolved

        # Scan variables for target schema patterns
        for vname, vinfo in mapping.get("variables", {}).items():
            vname_upper = vname.upper()
            if "TARGET" in vname_upper or "TGT" in vname_upper or (
                "SCHEMA" in vname_upper and "SRC" not in vname_upper and "CZ" not in vname_upper
            ):
                resolved = self._resolve_variable(vname, vinfo.get("default", ""))
                if resolved and "ext_lake" not in resolved:
                    return resolved

        # Fallback: use the PZ schema
        for vname, vinfo in mapping.get("variables", {}).items():
            if "_PZ_" in vname.upper() or "HUB_PZ" in vname.upper():
                resolved = self._resolve_variable(vname, vinfo.get("default", ""))
                if resolved:
                    return resolved
        return "unknown_schema"

    # ------------------------------------------------------------------
    # Staging: register columns
    # ------------------------------------------------------------------

    def _register_staging_columns(self, source: Dict, mapping: Dict) -> None:
        """Register real DB column names for a source into stg_registry."""
        source_name, schema_name, table_name = self._derive_source_info(source, mapping)
        cq = source.get("custom_query", "")

        if cq:
            # Parse CQ for real column names and possibly multiple tables
            tables_columns = self._parse_cq_for_staging(cq, source, mapping)
            for (sn, tn), cols in tables_columns.items():
                key = (sn, tn)
                if key not in self.stg_registry:
                    self.stg_registry[key] = []
                    # Use per-table schema resolved in _parse_cq_for_staging
                    per_table_schema = self._cq_table_schemas.get(key, schema_name)
                    self.stg_schema_map[key] = per_table_schema
                # If CQ returned 0 columns (e.g. SELECT *), fall back to source fields
                if not cols:
                    cols = [f.get("name", "") for f in source.get("fields", []) if f.get("name")]
                existing_lower = {c.lower() for c in self.stg_registry[key]}
                for col in cols:
                    if col.lower() not in existing_lower:
                        self.stg_registry[key].append(col)
                        existing_lower.add(col.lower())
            # --- BEGIN CHANGE 2026-04-16: adding source filters to staging ---
            src_filters = source.get("source_filters", [])
            if src_filters:
                for (sn, tn) in tables_columns:
                    fkey = (sn, tn)
                    bucket = self.stg_filters.setdefault(fkey, {})
                    for f in src_filters:
                        norm = re.sub(r'\s+', '', f.lower())
                        if norm not in bucket:
                            bucket[norm] = f
            # --- END CHANGE 2026-04-16: adding source filters to staging ---
        else:
            # No CQ: use field names directly
            key = (source_name, table_name)
            if key not in self.stg_registry:
                self.stg_registry[key] = []
                self.stg_schema_map[key] = schema_name
            existing_lower = {c.lower() for c in self.stg_registry[key]}
            for f in source.get("fields", []):
                fname = f.get("name", "")
                if fname and fname.lower() not in existing_lower:
                    self.stg_registry[key].append(fname)
                    existing_lower.add(fname.lower())

    def _parse_cq_for_staging(
        self, cq: str, source: Dict, mapping: Dict
    ) -> Dict[Tuple[str, str], List[str]]:
        """Parse a custom query to extract real DB columns per table.

        Returns dict of (source_name, table_name) -> [column_names].
        Also populates self._cq_table_schemas with per-table schema info.
        """
        result: Dict[Tuple[str, str], List[str]] = {}

        # Build alias-to-table map from FROM/JOIN clauses
        alias_map = self._build_alias_to_table_map(cq, mapping)

        if not alias_map:
            # Primary table
            src_name, schema, tbl = self._derive_source_info(source, mapping)
            cols = self._extract_cq_select_columns(cq)
            key = (src_name, tbl)

            # If outer SELECT returned no columns (e.g. SELECT * FROM (subquery)),
            # scan inner subqueries for raw column names from $$var.table references.
            if not cols:
                cols = self._extract_subquery_columns(cq, tbl)

            result[key] = cols
            self._cq_table_schemas[key] = schema

            # Also register any additional $$var.table references
            # (catches UNION branch tables inside subqueries like
            #  FROM (SELECT * FROM $$var.t1 UNION SELECT * FROM $$var.t2 ...) alias )
            all_var_tables = re.findall(r'\$\$([A-Za-z_]\w*)\.(\w+)', cq)
            for var_name, tbl_raw in all_var_tables:
                union_tbl = tbl_raw.lower()
                if union_tbl == tbl:
                    continue  # Already registered as primary
                union_schema = self._resolve_variable(
                    var_name,
                    mapping.get("variables", {}).get(var_name, {}).get("default", ""),
                )
                if not union_schema:
                    union_schema = self._resolve_cq_table_schema(
                        cq, union_tbl, mapping
                    )
                union_src = self._schema_to_source_name(union_schema)
                union_key = (union_src, union_tbl)
                if union_key not in result:
                    result[union_key] = list(cols)
                    self._cq_table_schemas[union_key] = union_schema

            return result

        # Multiple tables: tag each column to its table
        select_columns = self._extract_cq_select_columns_with_alias(cq)

        # Initialize result for each table found via alias map
        table_to_key: Dict[str, Tuple[str, str]] = {}
        for alias, table_name in alias_map.items():
            # Resolve schema for this table
            schema_name = self._resolve_cq_table_schema(cq, table_name, mapping)
            src_name = self._schema_to_source_name(schema_name)
            key = (src_name, table_name)
            table_to_key[table_name] = key
            if key not in result:
                result[key] = []
            self._cq_table_schemas[key] = schema_name

        # Also scan for ALL $$var.table references (catches subqueries and UNIONs)
        all_var_tables = re.findall(r'\$\$([A-Za-z_]\w*)\.(\w+)', cq)
        for var_name, tbl_raw in all_var_tables:
            tbl = tbl_raw.lower()
            if tbl not in table_to_key:
                schema_name = self._resolve_variable(
                    var_name, mapping.get("variables", {}).get(var_name, {}).get("default", "")
                )
                if not schema_name:
                    schema_name = self._resolve_cq_table_schema(cq, tbl, mapping)
                src_name = self._schema_to_source_name(schema_name)
                key = (src_name, tbl)
                table_to_key[tbl] = key
                if key not in result:
                    result[key] = []
                self._cq_table_schemas[key] = schema_name

        # Tag columns
        for col_info in select_columns:
            col_name = col_info["name"]
            alias_prefix = col_info.get("alias", "")
            if alias_prefix and alias_prefix in alias_map:
                tbl = alias_map[alias_prefix]
                key = table_to_key.get(tbl, list(table_to_key.values())[0] if table_to_key else None)
                if key:
                    if col_name.lower() not in {c.lower() for c in result[key]}:
                        result[key].append(col_name)
            else:
                # Unprefixed: add to all tables
                for key in result:
                    if col_name.lower() not in {c.lower() for c in result[key]}:
                        result[key].append(col_name)

        # Add JOIN condition columns to both tables
        join_cols = self._extract_join_columns(cq, alias_map)
        for col_name, tables in join_cols.items():
            for tbl in tables:
                key = table_to_key.get(tbl)
                if key and col_name.lower() not in {c.lower() for c in result[key]}:
                    result[key].append(col_name)

        # Full scan: capture ALL alias.column references across the entire CQ
        # (catches WHERE, GROUP BY, SELECT in subqueries, etc.)
        for ref_match in re.finditer(r'(\w+)\.(\w+)', cq):
            alias_ref = ref_match.group(1).lower()
            col_ref = ref_match.group(2)
            # Skip $$variable references (already handled above)
            if alias_ref.startswith('$'):
                continue
            tbl = alias_map.get(alias_ref)
            if tbl:
                key = table_to_key.get(tbl)
                if key and col_ref.lower() not in {c.lower() for c in result[key]}:
                    result[key].append(col_ref)

        # Subquery extraction: for each $$var.TABLE reference, find the
        # enclosing subquery's SELECT body and WHERE clause to capture
        # raw column names (bare, no alias prefix).
        # Runs for ALL tables, not just those with 0 columns.
        def _is_valid_col(tok: str) -> bool:
            """Check if a token is a valid column name (not keyword/literal)."""
            tok = tok.strip()
            if not tok:
                return False
            if tok.startswith("'") or tok.startswith('"'):  # string literal
                return False
            if re.match(r'^\d', tok):                       # numeric literal
                return False
            if tok.upper() in self._SQL_KEYWORDS:
                return False
            if not re.match(r'^[A-Za-z_]\w*$', tok):       # not valid identifier
                return False
            return True

        for tbl, key in table_to_key.items():
            existing_lower = {c.lower() for c in result[key]}
            from_pat = re.compile(
                r'from\s+\$\$\w+\.' + re.escape(tbl), re.IGNORECASE
            )
            for fm in from_pat.finditer(cq):
                # ── SELECT body: look backwards for nearest SELECT ──
                before = cq[:fm.start()]
                sel_matches = list(re.finditer(r'\bselect\b', before, re.IGNORECASE))
                if sel_matches:
                    select_body = cq[sel_matches[-1].end():fm.start()].strip()
                    # Strip leading DISTINCT
                    select_body = re.sub(r'^\s*DISTINCT\s+', '', select_body, flags=re.IGNORECASE)
                    for item in select_body.split(','):
                        item = item.strip()
                        if not item:
                            continue
                        # Handle "raw_col alias" or "raw_col AS alias"
                        parts = re.split(r'\s+AS\s+|\s+', item, maxsplit=1, flags=re.IGNORECASE)
                        raw_col = parts[0].strip()
                        # Skip * and expressions with parens
                        if raw_col == '*' or '(' in raw_col or ')' in raw_col:
                            continue
                        # Handle qualified name: alias.col → extract col
                        if '.' in raw_col:
                            raw_col = raw_col.split('.')[-1]
                        if _is_valid_col(raw_col) and raw_col.lower() not in existing_lower:
                            result[key].append(raw_col)
                            existing_lower.add(raw_col.lower())

                # ── WHERE / AND / ON clause: scan forward from the ref
                # until we hit a closing ) to capture bare column names ──
                after_ref = cq[fm.end():]
                # Find the closing paren of the enclosing subquery
                depth, boundary = 0, len(after_ref)
                for i, ch in enumerate(after_ref):
                    if ch == '(':
                        depth += 1
                    elif ch == ')':
                        if depth == 0:
                            boundary = i
                            break
                        depth -= 1
                where_region = after_ref[:boundary]
                # Extract bare column names from conditions:
                #   column = 'value'  /  column > expr  /  column BETWEEN ...
                for wm in re.finditer(
                    r'\b([A-Za-z_]\w*)\s*(?:=|!=|<>|>=|<=|>|<|BETWEEN|IN\b|IS\b)',
                    where_region, re.IGNORECASE,
                ):
                    col = wm.group(1)
                    if _is_valid_col(col) and col.lower() not in existing_lower:
                        result[key].append(col)
                        existing_lower.add(col.lower())
                        existing_lower.add(col.lower())

        return result

    def _extract_subquery_columns(self, cq: str, table_name: str) -> List[str]:
        """Extract raw column names from inner subqueries referencing $$var.table.

        Used when the outer SELECT is a pass-through (e.g., SELECT * FROM (subquery)).
        Scans the inner SELECT and WHERE clauses for raw DB column names.
        """
        cols: List[str] = []
        seen: Set[str] = set()

        from_pat = re.compile(
            r'from\s+\$\$\w+\.' + re.escape(table_name), re.IGNORECASE
        )
        for fm in from_pat.finditer(cq):
            # ── Inner SELECT body: look backwards for nearest SELECT ──
            before = cq[:fm.start()]
            sel_matches = list(re.finditer(r'\bselect\b', before, re.IGNORECASE))
            if sel_matches:
                select_body = cq[sel_matches[-1].end():fm.start()].strip()
                select_body = re.sub(r'^\s*DISTINCT\s+', '', select_body, flags=re.IGNORECASE)
                # Strip single-line SQL comments
                select_body = re.sub(r'--[^\n]*', '', select_body)
                for item in select_body.split(','):
                    item = item.strip()
                    if not item:
                        continue
                    parts = re.split(r'\s+AS\s+|\s+', item, maxsplit=1, flags=re.IGNORECASE)
                    raw_col = parts[0].strip()
                    if raw_col == '*' or '(' in raw_col or ')' in raw_col:
                        # For function calls, extract column refs from inside
                        if '(' in raw_col or ')' in raw_col:
                            inner_tokens = re.findall(r'\b([a-zA-Z_]\w*)\b', item.split(' AS ')[0] if ' AS ' in item.upper() else item)
                            for token in inner_tokens:
                                if (token.upper() not in self._SQL_KEYWORDS
                                        and not token.isdigit()
                                        and re.match(r'^[A-Za-z_]\w*$', token)):
                                    clean = token.split('.')[-1] if '.' in token else token
                                    if clean.lower() not in seen:
                                        cols.append(clean)
                                        seen.add(clean.lower())
                        continue
                    if '.' in raw_col:
                        raw_col = raw_col.split('.')[-1]
                    if (re.match(r'^[A-Za-z_]\w*$', raw_col)
                            and raw_col.upper() not in self._SQL_KEYWORDS
                            and raw_col.lower() not in seen):
                        cols.append(raw_col)
                        seen.add(raw_col.lower())

            # ── WHERE clause: scan forward for bare column names ──
            after_ref = cq[fm.end():]
            depth, boundary = 0, len(after_ref)
            for i, ch in enumerate(after_ref):
                if ch == '(':
                    depth += 1
                elif ch == ')':
                    if depth == 0:
                        boundary = i
                        break
                    depth -= 1
            where_region = after_ref[:boundary]
            # Match bare "column OP value" patterns
            for wm in re.finditer(
                r'\b([A-Za-z_]\w*)\s*(?:=|!=|<>|>=|<=|>|<|BETWEEN|IN\b|IS\b|LIKE\b)',
                where_region, re.IGNORECASE,
            ):
                col = wm.group(1)
                if (re.match(r'^[A-Za-z_]\w*$', col)
                        and col.upper() not in self._SQL_KEYWORDS
                        and col.lower() not in seen):
                    cols.append(col)
                    seen.add(col.lower())
            # Also extract column names from inside function calls
            # e.g. lower(STS_DESC), NVL(CALL_GUID_ID, '')
            for func_match in re.finditer(r'\w+\(([^)]*)\)', where_region):
                for token in re.findall(r'\b([A-Za-z_]\w*)\b', func_match.group(1)):
                    if (token.upper() not in self._SQL_KEYWORDS
                            and not token.isdigit()
                            and re.match(r'^[A-Za-z_]\w*$', token)
                            and token.lower() not in seen):
                        cols.append(token)
                        seen.add(token.lower())

        return cols

    _ALIAS_SKIP = frozenset({
        "ON", "WHERE", "AND", "OR", "JOIN", "LEFT", "RIGHT", "INNER",
        "FULL", "CROSS", "SELECT", "GROUP", "ORDER", "HAVING", "UNION",
        "LIMIT", "SET", "INTO", "VALUES",
    })

    def _build_alias_to_table_map(
        self, cq: str, mapping: Dict
    ) -> Dict[str, str]:
        """Build {alias: table_name} from CQ FROM/JOIN clauses.

        Handles two patterns:
          1. Direct:  FROM $$var.TABLE alias
          2. Subquery: FROM (SELECT ... FROM $$var.TABLE WHERE ...) alias
        """
        alias_map: Dict[str, str] = {}

        # Collect CTE names so we can exclude them from the alias map.
        # Matches both first CTE (WITH <name> AS () and siblings (, <name> AS ().
        cte_names = {
            m.group(1).lower()
            for m in re.finditer(r'(?:WITH|,)\s*(\w+)\s+AS\s*\(', cq, re.IGNORECASE)
        }

        # Pattern 1: direct alias after FROM/JOIN $$var.table
        pattern = r'(?:FROM|JOIN)\s+(?:\$\$\w+\.)?(\w+)\s+(?:AS\s+)?(\w+)'
        for m in re.finditer(pattern, cq, re.IGNORECASE):
            tbl = m.group(1).lower()
            alias = m.group(2).lower()
            if tbl in cte_names:
                continue
            if alias.upper() not in self._ALIAS_SKIP:
                alias_map[alias] = tbl

        # Pattern 1b: comma-separated tables in FROM clause
        # e.g. FROM $$var.table1 AS a, $$var.table2 b
        # Require $$var. prefix to avoid matching column aliases in SELECT
        comma_pattern = r',\s*\$\$\w+\.(\w+)\s+(?:AS\s+)?(\w+)'
        for m in re.finditer(comma_pattern, cq, re.IGNORECASE):
            tbl = m.group(1).lower()
            alias = m.group(2).lower()
            if alias.upper() not in self._ALIAS_SKIP:
                alias_map[alias] = tbl

        # Pattern 2: subquery outer alias — (SELECT ... FROM $$var.TABLE ...) alias
        # For each $$var.TABLE, if no direct alias was found, scan forward
        # past the closing ) to find the outer alias.
        for vm in re.finditer(r'\$\$\w+\.(\w+)', cq):
            tbl = vm.group(1).lower()
            # Check if this table already has a direct alias
            if tbl in {v for v in alias_map.values()}:
                continue
            # Walk forward from the table reference to find unmatched )
            depth, close_pos = 0, None
            for i in range(vm.end(), len(cq)):
                if cq[i] == '(':
                    depth += 1
                elif cq[i] == ')':
                    if depth == 0:
                        close_pos = i
                        break
                    depth -= 1
            if close_pos is not None:
                after = cq[close_pos + 1 : close_pos + 60]
                am = re.match(r'\s+(\w+)', after)
                if am and am.group(1).upper() not in self._ALIAS_SKIP:
                    alias_map[am.group(1).lower()] = tbl

        return alias_map

    # Keywords to exclude when extracting column names from expressions
    _SQL_KEYWORDS = frozenset({
        "CASE", "WHEN", "THEN", "ELSE", "END", "AS",
        "AND", "OR", "NOT", "NULL", "TRUE", "FALSE",
        "UPPER", "LOWER", "COALESCE", "CAST", "TRIM", "LTRIM", "RTRIM",
        "SELECT", "FROM", "DISTINCT", "IS", "IN", "BETWEEN", "LIKE",
        "VARCHAR", "INT", "STRING", "DATE", "TIMESTAMP", "DECIMAL", "BIGINT", "FLOAT", "DOUBLE",
        "REGEXP_REPLACE", "MAX", "MIN", "SUM", "COUNT", "AVG",
        "CONCAT", "SUBSTR", "SUBSTRING", "LENGTH", "LEN", "REPLACE", "NVL", "ISNULL", "IFNULL", "IF",
        "LPAD", "RPAD", "POSITION", "CHARINDEX", "INSTR", "REVERSE",
        "MD5", "SHA1", "SHA2", "ABS", "CEIL", "FLOOR", "ROUND", "MOD", "POWER", "SIGN",
        "TO_DATE", "TO_TIMESTAMP", "TO_CHAR", "TO_NUMBER", "DATE_FORMAT", "DATEADD", "DATEDIFF",
        "CURRENT_TIMESTAMP", "CURRENT_DATE", "NOW", "GETDATE", "SYSDATE",
        "OVER", "PARTITION", "BY", "ROW_NUMBER", "RANK", "DENSE_RANK", "ORDER", "ASC", "DESC",
        "GROUP", "HAVING", "UNION", "ALL", "EXISTS",
        "LEFT", "RIGHT", "INNER", "OUTER", "FULL", "CROSS", "JOIN", "ON", "WHERE", "WITH",
    })

    def _extract_cq_select_columns(self, cq: str) -> List[str]:
        """Extract real DB column names from CQ SELECT (raw names, not aliases).

        For staging models, we need the actual table column names, not the
        aliased names. E.g., 'clientid AS cl_id' → we need 'clientid',
        and 'upper(envelopeid) AS envelope_id' → we need 'envelopeid'.
        """
        cols: List[str] = []
        seen: Set[str] = set()
        # Find SELECT ... FROM
        match = re.search(r'SELECT\s+(.*?)\s+FROM\b', cq, re.IGNORECASE | re.DOTALL)
        if not match:
            return cols
        select_part = match.group(1)
        # Strip DISTINCT keyword
        select_part = re.sub(r'^\s*DISTINCT\s+', '', select_part, flags=re.IGNORECASE)
        # Strip single-line SQL comments
        select_part = re.sub(r'--[^\n]*', '', select_part)
        for item in self._split_select_items(select_part):
            item = item.strip()
            if not item or item == "*":
                continue
            # Split on AS to separate expression from alias
            as_parts = re.split(r'\s+AS\s+', item, flags=re.IGNORECASE)
            expr_part = as_parts[0].strip()

            # Extract raw column names from the expression (before AS)
            self._extract_raw_columns(expr_part, cols, seen)
        return cols

    def _extract_raw_columns(
        self, expr: str, cols: List[str], seen: Set[str]
    ) -> None:
        """Extract raw DB column names from a SQL expression for staging."""
        expr = expr.strip()
        # Check for trailing implicit alias: "table.col alias_name"
        trailing = re.search(r'\s+([a-zA-Z_]\w*)\s*$', expr)
        if trailing and trailing.group(1).upper() not in self._SQL_KEYWORDS:
            # Strip the trailing alias to get the real expression
            expr = expr[:trailing.start()].strip()

        if "(" in expr or re.match(r'\s*CASE\b', expr, re.IGNORECASE):
            # Function call or CASE: extract column references from inside
            quoted_tokens = set()
            for ql in re.findall(r"'([^']*)'", expr):
                for word in re.findall(r'\b([a-zA-Z_]\w*)\b', ql):
                    quoted_tokens.add(word.upper())
            inner_tokens = re.findall(r'\b([a-zA-Z_]\w*)\b', expr)
            for token in inner_tokens:
                if (token.upper() not in self._SQL_KEYWORDS
                        and token.upper() not in quoted_tokens
                        and not token.isdigit()):
                    clean = token.split(".")[-1] if "." in token else token
                    if clean.lower() not in seen:
                        cols.append(clean)
                        seen.add(clean.lower())
        else:
            # Simple column reference (possibly with table prefix)
            col_clean = expr.split(".")[-1] if "." in expr else expr
            col_clean = col_clean.strip()
            if re.match(r'^[a-zA-Z_]\w*$', col_clean) and col_clean.lower() not in seen:
                cols.append(col_clean)
                seen.add(col_clean.lower())

    def _extract_cq_select_columns_with_alias(self, cq: str) -> List[Dict[str, str]]:
        """Extract raw DB columns with their table alias prefix."""
        result: List[Dict[str, str]] = []
        match = re.search(r'SELECT\s+(.*?)\s+FROM\b', cq, re.IGNORECASE | re.DOTALL)
        if not match:
            return result
        select_part = match.group(1)
        # Strip DISTINCT keyword
        select_part = re.sub(r'^\s*DISTINCT\s+', '', select_part, flags=re.IGNORECASE)
        # Strip single-line SQL comments
        select_part = re.sub(r'--[^\n]*', '', select_part)
        for item in self._split_select_items(select_part):
            item = item.strip()
            if not item or item == "*":
                continue
            # Split on AS — use the expression part (before AS), not the alias
            as_match = re.split(r'\s+AS\s+', item, flags=re.IGNORECASE)
            col_part = as_match[0].strip()
            trailing_alias = re.search(r'\s+([a-zA-Z_]\w*)\s*$', col_part)
            if trailing_alias and trailing_alias.group(1).upper() not in self._SQL_KEYWORDS:
                result.append({"name": trailing_alias.group(1), "alias": ""})
                continue
            if "(" in col_part or re.match(r'\s*CASE\b', col_part, re.IGNORECASE):
                # Function or CASE expression — extract referenced columns
                # Collect string literal tokens to exclude
                quoted_tokens = set()
                for ql in re.findall(r"'([^']*)'", col_part):
                    for word in re.findall(r'\b([a-zA-Z_]\w*)\b', ql):
                        quoted_tokens.add(word.upper())
                # Extract alias.column references
                inner_cols = re.findall(r'\b(\w+)\.(\w+)\b', col_part)
                for alias, col in inner_cols:
                    if alias.upper() not in self._SQL_KEYWORDS and col.upper() not in self._SQL_KEYWORDS:
                        result.append({"name": col, "alias": alias.lower()})
                # Also find unprefixed column names
                simple_cols = re.findall(r'(?<!\.)(\b[a-zA-Z_]\w*\b)(?!\.)', col_part)
                for sc in simple_cols:
                    if (sc.upper() not in self._SQL_KEYWORDS
                            and sc.upper() not in quoted_tokens
                            and not sc.isdigit()):
                        result.append({"name": sc, "alias": ""})
            elif "." in col_part:
                parts = col_part.split(".", 1)
                col_name = parts[1].strip()
                # Handle "alias.col implicit_alias" pattern
                space_parts = col_name.split()
                if len(space_parts) > 1 and space_parts[-1].upper() not in self._SQL_KEYWORDS:
                    result.append({"name": space_parts[-1], "alias": parts[0].strip().lower()})
                else:
                    result.append({"name": space_parts[0], "alias": parts[0].strip().lower()})
            else:
                # Simple column name — skip if it looks like a SQL keyword or fragment
                if col_part.upper() not in self._SQL_KEYWORDS and re.match(r'^[a-zA-Z_]\w*$', col_part):
                    result.append({"name": col_part, "alias": ""})
        return result

    def _extract_join_columns(
        self, cq: str, alias_map: Dict[str, str]
    ) -> Dict[str, Set[str]]:
        """Extract join condition columns mapped to table names."""
        result: Dict[str, Set[str]] = defaultdict(set)
        on_pattern = r'ON\s+(.+?)(?=\s+(?:LEFT|RIGHT|INNER|FULL|CROSS|JOIN|WHERE|GROUP|ORDER|HAVING|LIMIT|$))'
        for m in re.finditer(on_pattern, cq, re.IGNORECASE | re.DOTALL):
            condition = m.group(1)
            col_refs = re.findall(r'(\w+)\.(\w+)', condition)
            for alias, col in col_refs:
                tbl = alias_map.get(alias.lower())
                if tbl:
                    result[col].add(tbl)
        return result

    def _resolve_cq_table_schema(
        self, cq: str, table_name: str, mapping: Dict
    ) -> str:
        """Resolve the schema for a table referenced in a CQ."""
        # Find $$VAR.table_name pattern
        pattern = re.compile(
            r'\$\$([A-Za-z_]\w*)\.' + re.escape(table_name), re.IGNORECASE
        )
        m = pattern.search(cq)
        if m:
            var_name = m.group(1)
            resolved = self._resolve_variable(
                var_name, mapping.get("variables", {}).get(var_name, {}).get("default", "")
            )
            if resolved:
                return resolved
        return "unknown_schema"

    @staticmethod
    def _split_select_items(select_part: str) -> List[str]:
        """Split SELECT items respecting parentheses depth and CASE...END blocks."""
        items: List[str] = []
        paren_depth = 0
        case_depth = 0
        current: List[str] = []
        # Tokenize: words, numbers, parens, commas, whitespace+other
        tokens = re.findall(r"[A-Za-z_]\w*|\d+|[(),]|[^\w\s(),]+|\s+", select_part)
        for tok in tokens:
            upper = tok.strip().upper()
            if tok == '(':
                paren_depth += 1
                current.append(tok)
            elif tok == ')':
                paren_depth = max(0, paren_depth - 1)
                current.append(tok)
            elif upper == 'CASE':
                case_depth += 1
                current.append(tok)
            elif upper == 'END' and case_depth > 0:
                case_depth -= 1
                current.append(tok)
            elif tok == ',' and paren_depth == 0 and case_depth == 0:
                items.append(''.join(current))
                current = []
            else:
                current.append(tok)
        if current:
            items.append(''.join(current))
        return items

    # ------------------------------------------------------------------
    # Source intermediate: register
    # ------------------------------------------------------------------

    def _register_source_intermediate(self, source: Dict, mapping: Dict) -> None:
        """Register source intermediate spec for later writing.

        Each Source Qualifier (SQ) gets its own source intermediate, even when
        multiple SQs reference the same underlying table — they may have
        different custom queries with distinct filters, joins, or projections.
        """
        source_name, schema_name, table_name = self._derive_source_info(source, mapping)
        mapping_name = mapping.get("mapping_name", "")
        safe_mapping = safe_name(mapping_name)
        sq_safe = safe_name(source.get("name", ""))
        key = (source_name, table_name, safe_mapping, sq_safe)
        cq = source.get("custom_query", "")

        if key not in self.src_int_registry:
            self.src_int_registry[key] = {
                "source_name": source_name,
                "schema_name": schema_name,
                "table_name": table_name,
                "mapping_safe_name": safe_mapping,
                "sq_safe_name": sq_safe,
                "custom_query": cq,
                "source": source,
                "mapping": mapping,
            }

    def _resolve_source_int_model_names(self) -> None:
        """Compute model names for all registered source intermediates.

        When multiple SQs within the same mapping reference the same table,
        their model names are disambiguated by appending the SQ name.
        Non-colliding entries keep the original naming convention.
        """
        # Group by (source_name, table_name, mapping_safe) to detect collisions
        groups: Dict[Tuple[str, str, str], List[Tuple[str, str, str, str]]] = defaultdict(list)
        for key in self.src_int_registry:
            source_name, table_name, mapping_safe, sq_safe = key
            groups[(source_name, table_name, mapping_safe)].append(key)

        for group_key, keys in groups.items():
            source_name, table_name, mapping_safe = group_key
            schema = self.src_int_registry[keys[0]].get("schema_name", "unknown_schema")
            short = self._short_schema(schema)
            if len(keys) == 1:
                # No collision — use original naming
                model_name = f"int_{short}_{table_name}_{mapping_safe}"
                self.src_int_model_names[keys[0]] = model_name
            else:
                # Collision — disambiguate with SQ name
                for key in keys:
                    _, _, _, sq_safe = key
                    model_name = f"int_{short}_{table_name}_{sq_safe}_{mapping_safe}"
                    self.src_int_model_names[key] = model_name

    def _resolve_lookup_refs(self) -> None:
        """Resolve deferred lookup refs using computed model names."""
        for lkp_name, info in self.translator.lookup_registry.items():
            resolve_key = info.get("_resolve_key")
            if resolve_key and info.get("ref") is None:
                model_name = self.src_int_model_names.get(resolve_key)
                if model_name:
                    info["ref"] = model_name
                else:
                    # Fallback
                    src_name, table_name, mapping_safe, sq_safe = resolve_key
                    info["ref"] = f"int_{table_name}_{mapping_safe}"

    def _register_lookup_translations(self, mapping: Dict) -> None:
        """Register unconnected lookups for :LKP scalar subquery translation."""
        for lkp in mapping.get("lookups", []):
            if not lkp.get("unconnected"):
                continue
            lkp_name = lkp.get("name", "")
            return_port = lkp.get("return_port", "")
            if not lkp_name or not return_port:
                continue
            # Derive the dbt ref for the lookup source
            lkp_cq = lkp.get("custom_query", "")
            lkp_as_source = {
                "name": lkp_name,
                "fields": lkp.get("fields", []),
                "custom_query": lkp_cq,
                "object_name": lkp.get("object_name", ""),
                "schema_var": "",
                # --- BEGIN CHANGE 2026-04-16: adding source filters to staging ---
                "source_filters": IDMCParser._extract_source_filters(lkp_cq),
                # --- END CHANGE 2026-04-16: adding source filters to staging ---
            }
            lkp_src_name, lkp_schema, lkp_table = self._derive_source_info(lkp_as_source, mapping)
            mapping_safe = safe_name(mapping.get("mapping_name", ""))
            lkp_sq_safe = safe_name(lkp_name)
            # Build WHERE parts from lookup conditions
            # leftOperand is the lookup table field, rightOperand is the input arg
            where_parts = []
            for lc in lkp.get("lookup_conditions", []):
                left = lc.get("left", "")
                right = lc.get("right", "")
                op = lc.get("operator", "=")
                where_parts.append(f"{left} {op} {right}")
            # Also register staging for the lookup source
            self._register_staging_columns(lkp_as_source, mapping)
            self._register_source_intermediate(lkp_as_source, mapping)
            # Store lookup key for deferred ref resolution after model names are computed
            self.translator.lookup_registry[lkp_name] = {
                "return_port": return_port,
                "ref": None,  # resolved later by _resolve_lookup_refs
                "_resolve_key": (lkp_src_name, lkp_table, mapping_safe, lkp_sq_safe),
                "where_parts": where_parts,
            }

    # ------------------------------------------------------------------
    # Phase 2: Write all staging files
    # ------------------------------------------------------------------

    def _write_all_staging_files(self) -> None:
        """Write staging SQL files from stg_registry."""
        stg_dir = self.output_dir / "models" / "staging"
        stg_dir.mkdir(parents=True, exist_ok=True)

        for (source_name, table_name), columns in self.stg_registry.items():
            schema = self.stg_schema_map.get((source_name, table_name), "unknown_schema")
            short = self._short_schema(schema)
            filename = f"stg_{short}_{table_name}.sql"

            lines = ["SELECT *"]
            lines.append(f"FROM {{{{ source('{source_name}', '{table_name}') }}}}")
            # --- BEGIN CHANGE 2026-04-16: adding source filters to staging ---
            stg_filter_conditions = sorted(self.stg_filters.get((source_name, table_name), {}).values())
            if stg_filter_conditions:
                lines.append(f"WHERE {' AND '.join(stg_filter_conditions)}")
            else:
                lines.append("-- No EDH or date filter detected from source qualifier")
            # --- END CHANGE 2026-04-16: adding source filters to staging ---

            content = "\n".join(lines) + "\n"
            (stg_dir / filename).write_text(content, encoding="utf-8")
            self.logger.info(f"Staging: {filename}")

            # Schema entry
            self.all_stg_models.append({
                "name": f"stg_{short}_{table_name}",
                "description": f"Staging model for {table_name}",
                "columns": [],
            })

    # ------------------------------------------------------------------
    # Phase 2: Write all source intermediate files
    # ------------------------------------------------------------------

    def _write_all_source_intermediate_files(self) -> None:
        """Write source intermediate SQL files from src_int_registry.

        Each SQ gets its own source intermediate. When multiple SQs share the
        same table within a mapping, file names are disambiguated with the SQ name.
        """
        int_base = self.output_dir / "models" / "intermediate"
        int_base.mkdir(parents=True, exist_ok=True)

        for key, spec in self.src_int_registry.items():
            source_name, table_name, mapping_safe, sq_safe = key
            model_name = self.src_int_model_names.get(key)
            if not model_name:
                # Fallback — should not happen if _resolve was called
                schema = spec.get("schema_name", "unknown_schema")
                short = self._short_schema(schema)
                model_name = f"int_{short}_{table_name}_{mapping_safe}"
            filename = f"{model_name}.sql"
            # Write into mapping-specific subfolder
            int_dir = int_base / mapping_safe
            int_dir.mkdir(parents=True, exist_ok=True)
            schema = spec.get("schema_name", "unknown_schema")
            short = self._short_schema(schema)
            stg_ref = f"stg_{short}_{table_name}"
            cq = spec.get("custom_query", "")

            # Check if this source intermediate only feeds CDC-stripped nodes
            is_cdc_orphan = key in self._cdc_only_src_int_keys
            orphan_comment = ""
            if is_cdc_orphan:
                orphan_comment = (
                    "/* NOTE: This source intermediate is orphaned — it was used by\n"
                    "   CDC-infrastructure nodes that have been stripped and replaced\n"
                    "   by dbt snapshots. Retained here for reference; the commented-out\n"
                    "   CDC CTEs in the mapping intermediate reference this model. */\n\n"
                )

            config_line = "{{ config(materialized='table') }}\n\n"
            if not cq:
                # Passthrough
                content = config_line + orphan_comment + f"SELECT * FROM {{{{ ref('{stg_ref}') }}}}\n"
            else:
                content = config_line + orphan_comment + self._translate_cq_to_source_int(
                    cq, stg_ref, spec.get("source", {}), spec.get("mapping", {}), short,
                    primary_table=table_name,
                )

            (int_dir / filename).write_text(content, encoding="utf-8")
            self.logger.info(f"Source intermediate: {filename}")

            self.all_int_models.append({
                "name": model_name,
                "description": f"Source intermediate for {table_name} ({mapping_safe})",
            })

    def _find_stg_ref(self, table_name: str, schema: str = "") -> str:
        """Find the correct stg_ model name from stg_registry for a table.

        Args:
            table_name: The table name to look up.
            schema: Full resolved schema name to match exactly.
        """
        table_lower = table_name.lower()
        schema_lower = schema.lower() if schema else ""
        # First pass: exact match on schema + table
        if schema_lower:
            for (src_name, tbl_name) in self.stg_registry:
                if tbl_name.lower() == table_lower:
                    reg_schema = self.stg_schema_map.get((src_name, tbl_name), "unknown_schema")
                    if schema_lower == reg_schema.lower():
                        short = self._short_schema(reg_schema)
                        return f"stg_{short}_{tbl_name}"
        # Second pass: match table name only (first match)
        for (src_name, tbl_name) in self.stg_registry:
            if tbl_name.lower() == table_lower:
                reg_schema = self.stg_schema_map.get((src_name, tbl_name), "unknown_schema")
                short = self._short_schema(reg_schema)
                return f"stg_{short}_{tbl_name}"
        # Fallback
        return f"stg_{table_name}"

    def _translate_cq_to_source_int(
        self, cq: str, stg_ref: str, source: Dict, mapping: Dict, short_schema: str,
        primary_table: str = "",
    ) -> str:
        """Translate a custom query into a source intermediate SQL file.

        Performs inline replacement of $$schema.table references with
        {{ ref('stg_...') }} and translates IDMC functions.  The CQ's own
        structure (CTEs, sub-queries, JOINs, UNIONs) is preserved as-is.
        """
        body = cq

        # 0. Strip IDMC partitioning hints: /*...[[node-count]]...[[node-number]]...*/
        body = re.sub(r'/\*.*?node-(?:count|number).*?\*/', '', body, flags=re.DOTALL)

        # 1. Handle $$schema.$$variable patterns (variable table names)
        #    Resolve the variable to get the actual table name first.
        for m in re.finditer(r'\$\$\w+\.\$\$(\w+)', body, flags=re.IGNORECASE):
            var_name = m.group(1)
            var_default = mapping.get("variables", {}).get(var_name, {}).get("default", "")
            resolved = self._resolve_variable(var_name, var_default)
            if resolved:
                tbl_stg_ref = self._find_stg_ref(resolved)
                body = re.sub(
                    r'\$\$\w+\.\$\$' + re.escape(var_name) + r'\b',
                    f"{{{{ ref('{tbl_stg_ref}') }}}}",
                    body, flags=re.IGNORECASE,
                )

        # 2. Handle $$schema.table patterns (literal table names)
        for m in re.finditer(r'\$\$(\w+)\.(\w+)', body, flags=re.IGNORECASE):
            schema_var = m.group(1)
            tbl = m.group(2)
            # Resolve schema variable to get schema hint for disambiguation
            schema_default = mapping.get("variables", {}).get(schema_var, {}).get("default", "")
            schema_resolved = self._resolve_variable(schema_var, schema_default)
            tbl_stg_ref = self._find_stg_ref(tbl, schema=schema_resolved)
            body = re.sub(
                r'\$\$' + re.escape(schema_var) + r'\.' + re.escape(tbl) + r'\b',
                f"{{{{ ref('{tbl_stg_ref}') }}}}",
                body, flags=re.IGNORECASE,
            )

        # 3. Translate IDMC functions to Databricks SQL
        body = self.translator.translate(body, mapping.get("mapping_name", ""))
        return body.strip() + "\n"

    # ------------------------------------------------------------------
    # Phase 2: Collect source entries for source.yml
    # ------------------------------------------------------------------

    def _collect_source_entries(self) -> None:
        """Collect source entries from stg_registry for source.yml."""
        for (source_name, table_name) in self.stg_registry:
            schema = self.stg_schema_map.get((source_name, table_name), "unknown_schema")
            self.all_source_entries.append({
                "source_name": source_name,
                "schema": schema,
                "table": table_name,
                "description": f"Source table for {table_name}",
            })

    # ------------------------------------------------------------------
    # Mapping Intermediate Generation
    # ------------------------------------------------------------------

    def _generate_intermediate_sql(
        self, mapping: Dict, main_targets: List[Dict], ops_targets: List[Dict]
    ) -> None:
        """Generate mapping intermediate SQL file using DAG-walking approach."""
        mapping_name = mapping.get("mapping_name", "")
        safe_mapping = safe_name(mapping_name)
        int_dir = self.output_dir / "models" / "intermediate" / safe_mapping
        int_dir.mkdir(parents=True, exist_ok=True)
        filename = f"int_{safe_mapping}.sql"

        if not main_targets:
            self.logger.warning(f"No target found for intermediate: {mapping_name}")
            return

        # Build SQL
        lines: List[str] = []
        lines.append("{{ config(materialized='table') }}")
        lines.append("")
        lines.append("WITH")

        # Walk DAG, emit one CTE per transformation node
        last_cte = self._walk_dag_to_ctes(lines, mapping, main_targets)

        if not last_cte:
            self.logger.warning(f"No CTEs generated for {mapping_name}")
            return

        # Final SELECT
        lines.append("")
        has_distinct = any(s.get("distinct", False) for s in mapping.get("sorters", []))
        select_kw = "SELECT DISTINCT" if has_distinct else "SELECT"

        # Sorter — ORDER BY is not meaningful in dbt materializations;
        # preserve original IDMC sort intent as a SQL comment.
        sorter_comments = []
        seen_sort_fields: Set[str] = set()
        for s in mapping.get("sorters", []):
            sorter_name = s.get("name", "")
            entry_strs = []
            for se in s.get("sort_entries", []):
                field = se.get("field", "")
                if field.lower() in seen_sort_fields:
                    continue
                seen_sort_fields.add(field.lower())
                direction = "ASC" if se.get("ascending", True) else "DESC"
                entry_strs.append(f"{field} {direction}")
            if entry_strs:
                label = f"IDMC Sorter '{sorter_name}'" if sorter_name else "IDMC Sorter"
                sorter_comments.append(f"/* {label}: {', '.join(entry_strs)} */")

        lines.append("-- TODO: Replace SELECT * with explicit column list mapped to target table columns")
        # For CDC Type 1 mappings, add SK generation in final SELECT
        scd_sub = mapping.get("scd_subtype", "")
        if scd_sub == "SCD_TYPE1":
            insert_target = self._find_insert_target(main_targets)
            if insert_target:
                tgt_table = insert_target.get("object_name", "")
                if tgt_table:
                    sk_col = f"{tgt_table}_sk"
                    lines.append(f"{select_kw}")
                    lines.append(f"    {{{{ generate_sk('{sk_col}', '{tgt_table}') }}}} AS {sk_col},")
                    lines.append(f"    *")
                    lines.append(f"FROM {last_cte}")
                else:
                    lines.append(f"{select_kw} *")
                    lines.append(f"FROM {last_cte}")
            else:
                lines.append(f"{select_kw} *")
                lines.append(f"FROM {last_cte}")
        else:
            lines.append(f"{select_kw} *")
            lines.append(f"FROM {last_cte}")

        for sc in sorter_comments:
            lines.append(sc)

        # CDC comment block is now emitted inline by _walk_dag_to_ctes

        content = "\n".join(lines) + "\n"
        (int_dir / filename).write_text(content, encoding="utf-8")
        self.logger.info(f"Mapping intermediate: {filename}")

        self.all_int_models.append({
            "name": f"int_{safe_mapping}",
            "description": f"Mapping intermediate for {mapping_name}",
        })

    # ==================================================================
    # DAG-walking intermediate generation
    # ==================================================================

    def _topo_sort_pipeline(
        self, mapping: Dict, main_target_ids: Set[int]
    ) -> List[int]:
        """Topological sort of nodes that reach main targets (excluding targets)."""
        dag = mapping.get("dag", {})
        reverse_dag = mapping.get("reverse_dag", {})
        tx_by_id = mapping.get("tx_by_id", {})

        # Filter to relevant nodes: not a Target, reaches a main target
        relevant: Set[int] = set()
        for node_id, tx in tx_by_id.items():
            if tx.get("type") == "Target":
                continue
            if self._reaches_main_pipeline(node_id, mapping, main_target_ids):
                relevant.add(node_id)

        # Kahn's algorithm
        in_degree: Dict[int, int] = {nid: 0 for nid in relevant}
        for nid in relevant:
            for pred in reverse_dag.get(nid, []):
                if pred in relevant:
                    in_degree[nid] += 1

        queue = deque([nid for nid, deg in in_degree.items() if deg == 0])
        order: List[int] = []
        while queue:
            nid = queue.popleft()
            order.append(nid)
            for succ in dag.get(nid, []):
                if succ in relevant:
                    in_degree[succ] -= 1
                    if in_degree[succ] == 0:
                        queue.append(succ)
        return order

    def _resolve_upstream_cte(
        self, node_id: int, cte_registry: Dict[int, str],
        router_group_ctes: Dict[Tuple[int, int], str],
        reverse_dag: Dict, from_group_map: Dict,
    ) -> Optional[str]:
        """Find the CTE name that feeds this node."""
        preds = reverse_dag.get(node_id, [])
        for pred_id in preds:
            # Check router group CTEs first (keyed by (router_id, group_$$ID))
            from_grp_id = from_group_map.get((pred_id, node_id))
            if from_grp_id is not None and (pred_id, from_grp_id) in router_group_ctes:
                return router_group_ctes[(pred_id, from_grp_id)]
            # Fall back to regular CTE
            if pred_id in cte_registry:
                return cte_registry[pred_id]
        return None

    def _resolve_joiner_inputs(
        self, joiner: Dict, cte_registry: Dict[int, str],
        router_group_ctes: Dict[Tuple[int, int], str],
        reverse_dag: Dict, link_to_group_map: Dict, from_group_map: Dict,
    ) -> Tuple[Optional[str], Optional[str]]:
        """Returns (master_cte_name, detail_cte_name) for a joiner."""
        jnr_id = joiner.get("id")
        preds = reverse_dag.get(jnr_id, [])
        master_cte = detail_cte = None
        for pred_id in preds:
            to_grp_id = link_to_group_map.get((pred_id, jnr_id))
            if to_grp_id is None:
                continue
            # Determine if this feeds Master or Detail
            for jg in joiner.get("groups", []):
                if jg.get("id") != to_grp_id:
                    continue
                gname = jg.get("name", "").lower()
                # Resolve the CTE for this predecessor
                from_grp_id = from_group_map.get((pred_id, jnr_id))
                if from_grp_id is not None and (pred_id, from_grp_id) in router_group_ctes:
                    cte_name = router_group_ctes[(pred_id, from_grp_id)]
                elif pred_id in cte_registry:
                    cte_name = cte_registry[pred_id]
                else:
                    cte_name = None
                if gname == "master":
                    master_cte = cte_name
                elif gname == "detail":
                    detail_cte = cte_name
        return master_cte, detail_cte

    # ------------------------------------------------------------------
    # Reusable: 3-layer subquery builder (CR → Field Rules → Operations)
    # ------------------------------------------------------------------

    @staticmethod
    def _build_layered_from(
        upstream_ref: str,
        upstream_cols: List[str],
        cr_prefix: str = "",
        cr_is_suffix: bool = False,
        excluded: Set[str] = None,
        included: Set[str] = None,
        renames: Dict[str, str] = None,
    ) -> Tuple[str, List[str]]:
        """Build nested FROM clause applying CR prefix then field rules.

        Returns (from_clause, final_column_list) where from_clause is a
        potentially nested subquery string and final_column_list is the
        column names available to the outer SELECT.

        Layer 1 (innermost): CR prefix/suffix on all upstream columns
        Layer 2 (middle):    Field rules — exclude, include-only, rename
        Layer 3 (outer):     Caller adds expression outputs / join / etc.
        """
        excluded = excluded or set()
        included = included or set()
        renames = renames or {}
        has_cr = bool(cr_prefix)
        has_field_rules = bool(excluded or included or renames)

        if not upstream_cols:
            # No columns known — can't build layers
            return upstream_ref, []

        # --- Layer 1: CR prefix ---
        if has_cr:
            layer1_items = []
            layer1_cols = []  # column names after CR
            for c in upstream_cols:
                alias = f"{c}{cr_prefix}" if cr_is_suffix else f"{cr_prefix}{c}"
                layer1_items.append(f"            {c} AS {alias}")
                layer1_cols.append(alias)
            layer1_select = ",\n".join(layer1_items)
            layer1_sql = f"(\n        SELECT\n{layer1_select}\n        FROM {upstream_ref}\n    )"
        else:
            layer1_sql = upstream_ref
            layer1_cols = list(upstream_cols)

        # --- Layer 2: Field rules ---
        # Build reverse map: CR-prefixed name → original name for include matching
        cr_reverse = {}
        if has_cr:
            for i, c in enumerate(upstream_cols):
                cr_reverse[layer1_cols[i].lower()] = c.lower()

        if has_field_rules:
            layer2_cols = []
            layer2_items = []
            for c in layer1_cols:
                # Exclude check (case-insensitive) — check both prefixed and original
                original = cr_reverse.get(c.lower(), c.lower())
                if c.lower() in excluded or original in excluded:
                    continue
                # Include-only check — match prefixed name, original name, or rename target
                if included:
                    renamed_target = renames.get(c.lower(), "").lower()
                    original_renamed = renames.get(original, "").lower()
                    if (c.lower() not in included
                            and original not in included
                            and renamed_target not in included
                            and original_renamed not in included):
                        continue
                # Rename check — check both prefixed and original name keys
                alias = renames.get(c.lower(), None) or renames.get(original, None) or c
                if alias != c:
                    layer2_items.append(f"            {c} AS {alias}")
                    layer2_cols.append(alias)
                else:
                    layer2_items.append(f"            {c}")
                    layer2_cols.append(c)
            if layer2_items:
                has_renames_in_layer2 = any(" AS " in item for item in layer2_items)
                if has_renames_in_layer2 or has_cr:
                    # Renames or CR — subquery needed so downstream sees renamed names
                    layer2_select = ",\n".join(layer2_items)
                    layer2_sql = f"(\n        SELECT\n{layer2_select}\n        FROM {layer1_sql}\n    )"
                else:
                    # Just include/exclude — no subquery needed
                    layer2_sql = layer1_sql
            else:
                layer2_sql = layer1_sql
                layer2_cols = layer1_cols
        else:
            layer2_sql = layer1_sql
            layer2_cols = layer1_cols

        return layer2_sql, layer2_cols

    # ------------------------------------------------------------------
    # Per-node CTE emitters
    # ------------------------------------------------------------------

    def _emit_source_cte(
        self, src: Dict, mapping: Dict
    ) -> Tuple[str, List[str]]:
        """Return the ref expression for a source node (no wrapper CTE needed).

        Downstream CTEs reference the mapping-specific source intermediate
        via {{ ref('int_{schema}_{table}_{mapping}') }}, with SQ-name
        disambiguation when multiple SQs share the same table.
        """
        src_name, src_schema, src_table = self._derive_source_info(src, mapping)
        mapping_safe = safe_name(mapping.get("mapping_name", ""))
        sq_safe = safe_name(src.get("name", ""))
        key = (src_name, src_table, mapping_safe, sq_safe)
        ref_name = self.src_int_model_names.get(key)
        if not ref_name:
            # Fallback for safety
            short = self._short_schema(src_schema)
            ref_name = f"int_{short}_{src_table}_{mapping_safe}"
        cte_name = f"{{{{ ref('{ref_name}') }}}}"
        return cte_name, []

    def _emit_router_ctes(
        self, router: Dict, upstream_cte: str, mapping: Dict,
        upstream_cols: List[str] = None,
    ) -> List[Tuple[str, List[str], int]]:
        """Emit one CTE per output group. Returns [(cte_name, lines, group_$$ID), ...].

        Groups with no filter condition are passed through — downstream
        nodes reference the upstream CTE directly instead of a pointless
        SELECT * wrapper.
        """
        results = []
        rtr_name = safe_name(router.get("name", "router"))
        mapping_name = mapping.get("mapping_name", "")

        # Router-level field rules (from input group) — apply to all output groups
        rtr_excluded = {e.lower() for e in router.get("excluded_fields", [])}
        rtr_renames = {k.lower(): v for k, v in router.get("field_renames", {}).items()}
        rtr_included = {e.lower() for e in router.get("included_fields", [])}
        has_field_rules = bool(rtr_excluded or rtr_renames or rtr_included)

        # Build layered FROM once — shared across all output groups
        if has_field_rules and upstream_cols:
            layered_from, layered_cols = self._build_layered_from(
                upstream_ref=upstream_cte,
                upstream_cols=upstream_cols,
                excluded=rtr_excluded,
                included=rtr_included,
                renames=rtr_renames,
            )
        else:
            layered_from = upstream_cte
            layered_cols = list(upstream_cols) if upstream_cols else []

        for grp in router.get("groups", []):
            if grp.get("is_input"):
                continue  # Skip input groups
            grp_name = safe_name(grp.get("name", "group"))
            grp_id = grp.get("id")
            cond = grp.get("filter_condition", "")

            # Check if layered_from has renames/CR (needs subquery)
            # vs just exclude/include (can flatten into direct SELECT)
            needs_subquery = layered_from != upstream_cte

            if cond and cond.strip().lower() not in ("true", "1=1", ""):
                cte_name = f"rtr_{rtr_name}_{grp_name}"
                translated = self.translator.translate(cond, mapping_name)
                if needs_subquery:
                    # CR/rename requires subquery — WHERE on top
                    lines = [
                        f"{cte_name} AS (",
                        f"    SELECT * FROM {layered_from}",
                        f"    WHERE {translated}",
                        "),",
                    ]
                elif layered_cols:
                    # Just exclude/include — flatten into one SELECT
                    col_list = ",\n".join(f"        {c}" for c in layered_cols)
                    lines = [
                        f"{cte_name} AS (",
                        f"    SELECT\n{col_list}",
                        f"    FROM {upstream_cte}",
                        f"    WHERE {translated}",
                        "),",
                    ]
                else:
                    lines = [
                        f"{cte_name} AS (",
                        f"    SELECT * FROM {upstream_cte}",
                        f"    WHERE {translated}",
                        "),",
                    ]
                results.append((cte_name, lines, grp_id))
            elif has_field_rules and upstream_cols:
                # No filter but has field rules
                cte_name = f"rtr_{rtr_name}_{grp_name}"
                if needs_subquery:
                    lines = [
                        f"{cte_name} AS (",
                        f"    SELECT * FROM {layered_from}",
                        "),",
                    ]
                else:
                    col_list = ",\n".join(f"        {c}" for c in layered_cols)
                    lines = [
                        f"{cte_name} AS (",
                        f"    SELECT\n{col_list}",
                        f"    FROM {upstream_cte}",
                        "),",
                    ]
                results.append((cte_name, lines, grp_id))
            else:
                # No filter, no field rules — pass through upstream directly
                results.append((upstream_cte, [], grp_id))
        return results

    def _emit_joiner_cte(
        self, joiner: Dict, master_cte: str, detail_cte: str, mapping: Dict,
        detail_cols: List[str] = None,
        master_cols: List[str] = None,
    ) -> Tuple[str, List[str]]:
        """Emit CTE for a joiner node."""
        jnr_name = safe_name(joiner.get("name", "joiner"))
        cte_name = f"jnr_{jnr_name}"
        join_kw = self._map_join_type(joiner.get("join_type", "Normal Join"))

        # Get master and detail prefixes/suffixes, excluded and included fields from joiner groups
        master_prefix = ""
        detail_prefix = ""
        master_is_suffix = False
        detail_is_suffix = False
        master_excluded: Set[str] = set()
        detail_excluded: Set[str] = set()
        master_included: Set[str] = set()
        detail_included: Set[str] = set()
        master_renames: Dict[str, str] = {}
        detail_renames: Dict[str, str] = {}
        for g in joiner.get("groups", []):
            gname = g.get("name", "").lower()
            grp_excl = {e.lower() for e in g.get("excluded_fields", [])}
            grp_incl = {e.lower() for e in g.get("included_fields", [])}
            grp_renames = {k.lower(): v for k, v in g.get("field_renames", {}).items()}
            if gname == "master":
                if g.get("prefix"):
                    master_prefix = g["prefix"]
                    master_is_suffix = g.get("is_suffix", False)
                master_excluded = grp_excl
                master_included = grp_incl
                master_renames = grp_renames
            elif gname == "detail":
                if g.get("prefix"):
                    detail_prefix = g["prefix"]
                    detail_is_suffix = g.get("is_suffix", False)
                detail_excluded = grp_excl
                detail_included = grp_incl
                detail_renames = grp_renames

        # --- Build layered subqueries for master and detail ---
        master_from, master_final_cols = self._build_layered_from(
            upstream_ref=master_cte,
            upstream_cols=master_cols or [],
            cr_prefix=master_prefix,
            cr_is_suffix=master_is_suffix,
            excluded=master_excluded,
            included=master_included,
            renames=master_renames,
        )
        detail_from, detail_final_cols = self._build_layered_from(
            upstream_ref=detail_cte,
            upstream_cols=detail_cols or [],
            cr_prefix=detail_prefix,
            cr_is_suffix=detail_is_suffix,
            excluded=detail_excluded,
            included=detail_included,
            renames=detail_renames,
        )

        # Dedup: remove detail columns that collide with master output names
        master_output_names = {c.lower() for c in master_final_cols}
        deduped_detail = [c for c in detail_final_cols if c.lower() not in master_output_names]

        lines = [f"{cte_name} AS ("]
        lines.append("    SELECT")

        select_items = []

        # --- Master side ---
        if master_final_cols:
            for c in master_final_cols:
                select_items.append(f"        m.{c}")
        else:
            select_items.append("        m.*")

        # --- Detail side (deduped against master) ---
        if deduped_detail:
            for c in deduped_detail:
                select_items.append(f"        d.{c}")

        for i, item in enumerate(select_items):
            comma = "," if i < len(select_items) - 1 else ""
            lines.append(f"{item}{comma}")

        # FROM uses layered subqueries — CR + field rules already applied inside
        lines.append(f"    FROM {master_from} m")
        lines.append(f"    {join_kw} {detail_from} d")

        # JOIN condition — uses post-CR, post-rename names directly from JSON
        # because the subqueries produce those names
        on_parts = []
        for jc in joiner.get("join_conditions", []):
            left_col = jc.get("left", "")
            right_col = jc.get("right", "")
            op = jc.get("operator", "=")
            on_parts.append(f"m.{left_col} {op} d.{right_col}")
        if on_parts:
            lines.append(f"        ON {' AND '.join(on_parts)}")
        lines.append("),")
        return cte_name, lines

    def _emit_lookup_cte(
        self, lookup: Dict, upstream_cte: str, mapping: Dict,
        upstream_cols: List[str] = None,
    ) -> Tuple[str, List[str]]:
        """Emit CTE for a connected lookup node (LEFT JOIN against lookup table)."""
        lkp_name = safe_name(lookup.get("name", "lookup"))
        cte_name = f"lkp_{lkp_name}"
        up_prefix = lookup.get("upstream_prefix", "")

        # Derive the lookup table's dbt ref from its customQuery
        lkp_as_source = {
            "name": lookup.get("name", ""),
            "fields": lookup.get("fields", []),
            "custom_query": lookup.get("custom_query", ""),
            "object_name": lookup.get("object_name", ""),
            "schema_var": "",
        }
        lkp_src_name, lkp_schema, lkp_table = self._derive_source_info(lkp_as_source, mapping)
        short = self._short_schema(lkp_schema)
        mapping_safe = safe_name(mapping.get("mapping_name", ""))
        lkp_sq_safe = safe_name(lookup.get("name", ""))
        lkp_key = (lkp_src_name, lkp_table, mapping_safe, lkp_sq_safe)
        lkp_ref = self.src_int_model_names.get(lkp_key, f"int_{short}_{lkp_table}_{mapping_safe}")

        # Extract WHERE clause from customQuery if present
        cq = lookup.get("custom_query", "")
        # Strip IDMC partitioning hints before extracting WHERE
        cq = re.sub(r'/\*.*?node-(?:count|number).*?\*/', '', cq, flags=re.DOTALL)
        where_clause = ""
        where_match = re.search(r'\bWHERE\b\s+(.+)', cq, re.IGNORECASE | re.DOTALL)
        if where_match:
            where_clause = where_match.group(1).strip().rstrip(";")

        # Build layered FROM for upstream: CR prefix → field rules
        lkp_fields = [f.get("name", "") for f in lookup.get("fields", []) if f.get("name")]
        lkp_fields_lower = {lf.lower() for lf in lkp_fields}
        lkp_excluded = {e.lower() for e in lookup.get("excluded_fields", [])}
        lkp_included = {e.lower() for e in lookup.get("included_fields", [])}
        lkp_renames = {k.lower(): v for k, v in lookup.get("field_renames", {}).items()}

        upstream_from, upstream_final_cols = self._build_layered_from(
            upstream_ref=upstream_cte,
            upstream_cols=upstream_cols or [],
            cr_prefix=up_prefix,
            cr_is_suffix=False,
            excluded=lkp_excluded,
            included=lkp_included,
            renames=lkp_renames,
        )

        # Dedup: remove upstream cols that collide with lookup field names
        deduped_upstream = [c for c in upstream_final_cols if c.lower() not in lkp_fields_lower]

        lines = [f"{cte_name} AS ("]
        lines.append("    SELECT")
        select_items = []

        # Upstream passthrough (post-CR, post-field-rules, deduped)
        if deduped_upstream:
            for c in deduped_upstream:
                select_items.append(f"        u.{c}")
        else:
            select_items.append("        u.*")

        # Lookup return columns
        for lf in lkp_fields:
            select_items.append(f"        l.{lf}")

        for i, item in enumerate(select_items):
            comma = "," if i < len(select_items) - 1 else ""
            lines.append(f"{item}{comma}")

        # FROM uses layered subquery for upstream, direct ref for lookup
        lines.append(f"    FROM {upstream_from} u")
        lines.append(f"    LEFT JOIN {{{{ ref('{lkp_ref}') }}}} l")

        # ON conditions — uses post-CR, post-rename names directly
        on_parts = []
        for lc in lookup.get("lookup_conditions", []):
            lkp_col = lc.get("left", "")
            right_col = lc.get("right", "")
            op = lc.get("operator", "=")
            on_parts.append(f"l.{lkp_col} {op} u.{right_col}")
        if on_parts:
            lines.append(f"        ON {' AND '.join(on_parts)}")
        lines.append("),")
        return cte_name, lines

    def _emit_expression_cte(
        self, expr: Dict, upstream_cte: str, mapping: Dict,
        upstream_cols: List[str] = None,
        downstream_expected_fields: set = None,
    ) -> Tuple[str, List[str]]:
        """Emit CTE for an expression node.

        When the expression contains VARIABLE ports, this method emits
        a preliminary ``_vars`` CTE that materialises those variables
        as real columns, then a final CTE that references them.  The
        extra CTE lines are returned together with the final CTE lines.
        """
        expr_name = safe_name(expr.get("name", "expression"))
        cte_name = f"exp_{expr_name}"
        mapping_name = mapping.get("mapping_name", "")

        # Collect VARIABLE fields for inlining
        variable_map: Dict[str, str] = {}
        for f in expr.get("fields", []):
            is_var = f.get("variable", False)
            if is_var or f.get("exp_field_type", "").upper() == "VARIABLE":
                vname = f.get("name", "")
                vexpr = f.get("expression", "")
                if vname and vexpr:
                    variable_map[vname] = vexpr

        # -----------------------------------------------------------------
        # Classify variable ports into inlinable vs materialise-as-CTE
        # -----------------------------------------------------------------
        # Self-referencing vars (v = v+1, prev = curr) cannot be inlined.
        # Vars that reference other vars in a chain can be materialised.
        self_ref_vars: Dict[str, str] = {}   # accumulator / LAG patterns
        chain_vars: Dict[str, str] = {}      # safe chained vars
        for vname, vexpr in variable_map.items():
            if re.search(r'\b' + re.escape(vname) + r'\b', vexpr):
                self_ref_vars[vname] = vexpr
            else:
                chain_vars[vname] = vexpr

        # Resolve chain vars: iteratively expand references to other chain vars
        for _ in range(10):
            resolved_any = False
            for vname in list(chain_vars.keys()):
                vexpr = chain_vars[vname]
                for other in sorted(chain_vars.keys(), key=len, reverse=True):
                    if other != vname and re.search(r'\b' + re.escape(other) + r'\b', vexpr):
                        chain_vars[vname] = re.sub(r'\b' + re.escape(other) + r'\b', f"({chain_vars[other]})", vexpr)
                        vexpr = chain_vars[vname]
                        resolved_any = True
            if not resolved_any:
                break

        # Detect LAG pattern: varA = varB where varB is defined in the same
        # expression — varA holds the previous row's value of varB.
        # This appears as a simple assignment (prevNk = currNk) and another
        # field compares them (IIF(currNk = prevNk, ...)).
        # IMPORTANT: Use the ORIGINAL expression from variable_map, not the
        # resolved chain_vars expression, because resolution expands varB refs.
        lag_vars: Dict[str, Tuple[str, str]] = {}  # varName -> (source_expr, sort_hint)
        for source_dict in [self_ref_vars, chain_vars]:
            for vname in list(source_dict.keys()):
                original_expr = variable_map.get(vname, "").strip()
                # Pattern: prev = curr (simple assignment to another variable)
                if original_expr in variable_map and original_expr != vname:
                    # Check if another field compares both vname and original_expr
                    # (confirms this is a LAG pattern, not just an alias)
                    is_lag = False
                    for f in expr.get("fields", []):
                        fexpr = f.get("expression", "")
                        if f.get("name", "") == vname:
                            continue
                        if vname in fexpr and original_expr in fexpr:
                            is_lag = True
                            break
                    if is_lag:
                        source_var = original_expr
                        lag_vars[vname] = (variable_map.get(source_var, source_var), source_var)
                        if vname in source_dict:
                            del source_dict[vname]

        # Detect accumulator: v = v + N
        accum_vars: Dict[str, str] = {}  # varName -> increment expr
        for vname, vexpr in list(self_ref_vars.items()):
            # Match patterns like "v_vcnt+1" or "v_vcnt + 1"
            pattern = re.escape(vname) + r'\s*\+\s*(\d+)'
            m = re.match(pattern, vexpr.strip())
            if m:
                accum_vars[vname] = m.group(1)
                del self_ref_vars[vname]

        # Build the variable_map for inlining into output fields.
        # Chain vars are fully resolved and can be inlined directly.
        # LAG/accumulator vars will be materialised in a _vars CTE.
        inline_map = dict(chain_vars)

        # -----------------------------------------------------------------
        # If we have LAG, accumulator, or chain vars that other output fields
        # reference, emit a preliminary _vars CTE
        # -----------------------------------------------------------------
        needs_vars_cte = bool(lag_vars or accum_vars or chain_vars)
        # Only emit vars CTE if output fields actually reference these vars
        if needs_vars_cte:
            all_var_names = set(chain_vars.keys()) | set(lag_vars.keys()) | set(accum_vars.keys())
            output_fields = [f for f in expr.get("fields", [])
                           if not f.get("variable", False)
                           and f.get("exp_field_type", "").upper() in ("OUTPUT", "")
                           and f.get("name", "") and f.get("expression", "")]
            # Check if any output field references any variable
            refs_any = False
            for f in output_fields:
                fexpr = f.get("expression", "")
                for vn in all_var_names:
                    if vn in fexpr:
                        refs_any = True
                        break
                if refs_any:
                    break
            if not refs_any:
                needs_vars_cte = False

        vars_cte_lines: List[str] = []
        vars_col_names: List[str] = []  # columns added by _vars CTEs

        if needs_vars_cte:
            # Get sort key from upstream Sorter if available
            sort_key = self._get_upstream_sort_key(expr, mapping)

            # Collect all var definitions with their SQL and dependencies
            all_var_defs: Dict[str, Tuple[str, str]] = {}  # vname -> (sql_line, "chain"|"lag"|"accum"|"todo")

            # Chain vars — use ORIGINAL expression (not recursively resolved)
            # so that references to other vars become column refs in tiered CTEs
            for vname in chain_vars:
                original_expr = variable_map[vname]  # use original, not resolved
                translated_v = self.translator.translate(original_expr, mapping_name)
                for cr in expr.get("conflict_resolutions", []):
                    p = cr.get("rename_prefix", "")
                    if p:
                        translated_v = re.sub(r'\b' + re.escape(p) + r'(\w+)\b', r'\1', translated_v)
                all_var_defs[vname] = (f"        {_cast_null(translated_v)} AS {vname}", "chain")

            # LAG vars — reference the source variable column name directly
            # since it's materialised in an earlier tier CTE
            for vname, (source_expr, source_var) in lag_vars.items():
                # If source_var is a chain var (will be a real column), use the column name
                if source_var in chain_vars or source_var in variable_map:
                    lag_ref = source_var
                else:
                    # Fallback: translate the full expression
                    lag_ref = self.translator.translate(source_expr, mapping_name)
                    for cr in expr.get("conflict_resolutions", []):
                        p = cr.get("rename_prefix", "")
                        if p:
                            lag_ref = re.sub(r'\b' + re.escape(p) + r'(\w+)\b', r'\1', lag_ref)
                order_clause = f"ORDER BY {sort_key}" if sort_key else "ORDER BY 1"
                all_var_defs[vname] = (f"        LAG({lag_ref}, 1, NULL) OVER ({order_clause}) AS {vname}", "lag")

            # Accumulator vars
            for vname, incr in accum_vars.items():
                order_clause = f"ORDER BY {sort_key}" if sort_key else "ORDER BY 1"
                all_var_defs[vname] = (f"        ROW_NUMBER() OVER ({order_clause}) AS {vname}", "accum")

            # Remaining self-ref vars as TODO
            for vname, vexpr in self_ref_vars.items():
                all_var_defs[vname] = (f"        CAST(NULL AS STRING) AS {vname}", "todo")

            # Topological sort: assign each var a tier based on dependencies
            all_var_names_set = set(all_var_defs.keys())
            var_tier: Dict[str, int] = {}
            for _ in range(10):  # max depth
                progress = False
                for vname in all_var_names_set:
                    if vname in var_tier:
                        continue
                    vexpr_raw = variable_map.get(vname, "")
                    deps = {other for other in all_var_names_set
                            if other != vname and re.search(r'\b' + re.escape(other) + r'\b', vexpr_raw)}
                    if not deps:
                        var_tier[vname] = 0
                        progress = True
                    elif all(d in var_tier for d in deps):
                        var_tier[vname] = max(var_tier[d] for d in deps) + 1
                        progress = True
                if not progress:
                    break
            # Assign unresolved to max tier + 1
            max_tier = max(var_tier.values()) if var_tier else 0
            for vname in all_var_names_set:
                if vname not in var_tier:
                    var_tier[vname] = max_tier + 1

            # Group vars by tier
            tiers: Dict[int, List[str]] = {}
            for vname, tier in sorted(var_tier.items(), key=lambda x: x[1]):
                tiers.setdefault(tier, []).append(vname)

            # Emit one CTE per tier
            current_upstream = upstream_cte
            for tier_num in sorted(tiers.keys()):
                tier_vars = tiers[tier_num]
                suffix = "" if tier_num == 0 else str(tier_num)
                tier_cte_name = f"{cte_name}_vars{suffix}"

                tier_lines = [f"{tier_cte_name} AS ("]
                tier_lines.append("    SELECT")
                # Check for variable names that overlap with upstream columns
                vars_except = []
                if upstream_cols:
                    upstream_lower = {c.lower() for c in upstream_cols}
                    vars_except = [v for v in tier_vars if v.lower() in upstream_lower]
                if vars_except:
                    except_list = ", ".join(vars_except)
                    tier_lines.append(f"        * EXCEPT({except_list}),")
                else:
                    tier_lines.append("        *,")
                vcols = []
                for vname in tier_vars:
                    sql_line, vtype = all_var_defs[vname]
                    if vtype == "todo":
                        vcols.append(f"        -- TODO: MANUAL REVIEW REQUIRED — self-referencing variable '{vname} = {variable_map.get(vname, '')}'")
                    vcols.append(sql_line)
                    vars_col_names.append(vname)
                for i, vc in enumerate(vcols):
                    # Skip comment lines for comma logic
                    is_comment = vc.strip().startswith("--")
                    remaining_non_comments = any(not vcols[j].strip().startswith("--") for j in range(i+1, len(vcols)))
                    comma = "," if not is_comment and remaining_non_comments else ""
                    tier_lines.append(f"    {vc}{comma}")
                tier_lines.append(f"    FROM {current_upstream}")
                tier_lines.append("),")
                vars_cte_lines.extend(tier_lines)
                current_upstream = tier_cte_name

            # The final CTE now reads from the last tier
            upstream_cte = current_upstream

            # For output fields, all vars are now real columns —
            # no inlining needed
            inline_map = {}  # vars are real columns in upstream CTEs

        # Collect OUTPUT fields with expressions
        output_cols: List[str] = []
        output_field_names: List[str] = []  # Track actual field names for overlap detection
        for f in expr.get("fields", []):
            if f.get("variable", False):
                continue
            if f.get("exp_field_type", "").upper() not in ("OUTPUT", ""):
                continue
            fname = f.get("name", "")
            expr_str = f.get("expression", "")
            if not fname or not expr_str:
                continue

            # Inline variable references (only chain vars when no _vars CTE)
            for vname in sorted(inline_map.keys(), key=len, reverse=True):
                if re.search(r'\b' + re.escape(vname) + r'\b', expr_str):
                    expr_str = re.sub(r'\b' + re.escape(vname) + r'\b', f"({inline_map[vname]})", expr_str)

            # Translate IDMC expression to SQL
            translated = self.translator.translate(expr_str, mapping_name)

            # Window OVER clause
            if expr.get("window_enabled") and expr.get("window_spec"):
                translated = self._append_window_over(translated, expr["window_spec"])

            # Strip bulk-rename prefixes from IDMC input port references AFTER
            # translation.  IDMC expressions reference upstream columns with the
            # conflict-resolution prefix (e.g. o_col, a_col).
            #
            # When this expression has its OWN CR prefix AND upstream_cols is
            # available, _build_layered_from will apply the prefix via inner
            # subquery — so expressions should reference prefixed names as-is.
            # Otherwise, strip as before (upstream CTE emits unprefixed names).
            explicit_prefixes: List[str] = []
            for cr in expr.get("conflict_resolutions", []):
                p = cr.get("rename_prefix", "")
                if p and p not in explicit_prefixes:
                    explicit_prefixes.append(p)
            # Skip stripping ONLY when this expression's own CR prefix will be
            # applied via _build_layered_from (has prefix AND has upstream_cols)
            has_own_cr_with_layers = bool(explicit_prefixes) and bool(upstream_cols)
            if not has_own_cr_with_layers:
                # Strip explicit CR prefixes (old behavior)
                for prefix in explicit_prefixes:
                    pfx_escaped = re.escape(prefix)
                    translated = re.sub(r'\b' + pfx_escaped + r'(\w+)\b', r'\1', translated)
                # For the default o_ prefix (when no explicit CR prefix covers it),
                # only strip when the stripped name exists upstream.
                if "o_" not in explicit_prefixes:
                    if upstream_cols:
                        upstream_lower = {c.lower() for c in upstream_cols}
                        for token in re.findall(r'\b(o_\w+)\b', translated):
                            stripped = token[2:]
                            if stripped.lower() in upstream_lower:
                                translated = re.sub(r'\b' + re.escape(token) + r'\b', stripped, translated)
                    else:
                        translated = re.sub(r'\bo_(\w+)\b', r'\1', translated)

            # Handle multiline translated expressions: separate comment lines
            # from actual expression, ensure alias lands on the expression line
            if "\n" in translated:
                expr_parts = translated.split("\n")
                comment_lines = [p for p in expr_parts if p.strip().startswith("--") or not p.strip()]
                code_lines = [p for p in expr_parts if p.strip() and not p.strip().startswith("--")]
                translated = " ".join(code_lines) if code_lines else translated.replace("\n", " ")
                for cl in comment_lines:
                    if cl.strip():
                        output_cols.append(f"    {cl.strip()}")

            has_var_ref = "{{ var(" in translated
            if has_var_ref:
                output_cols.append(f"    -- TODO: Verify dbt variable mapping for {fname}")
            if translated.strip().startswith("-- TODO:"):
                output_cols.append(f"    {translated}")
                output_cols.append(f"    -- {fname}: needs manual mapping")
            else:
                output_cols.append(f"    {_cast_null(translated)} AS {fname}")
                output_field_names.append(fname)

        # Filter out excluded fields from upstream pass-through
        expr_excluded = {e.lower() for e in expr.get("excluded_fields", [])}
        if expr_excluded and upstream_cols:
            upstream_cols = [c for c in upstream_cols if c.lower() not in expr_excluded]

        # Apply field renames from rules (inputName -> outputName)
        expr_renames = expr.get("field_renames", {})
        expr_renames_lower = {k.lower(): v for k, v in expr_renames.items()}

        # --- BEGIN: Build inner subquery for field rule renames ---
        # When field rules have renames, wrap upstream in an inner subquery
        # that applies excludes + renames. The outer SELECT then operates
        # on the renamed columns (expression body can reference them).
        has_field_rule_renames = bool(expr_renames_lower)

        def _build_inner_subquery() -> str:
            """Build inner SELECT with field rule renames applied."""
            inner_cols = []
            for c in upstream_cols:
                renamed = expr_renames_lower.get(c.lower())
                if renamed:
                    inner_cols.append(f"{c} AS {renamed}")
                else:
                    inner_cols.append(c)
            col_list = ",\n            ".join(inner_cols)
            return f"(SELECT\n            {col_list}\n        FROM {upstream_cte})"

        # After field rule renames, upstream_cols should reflect renamed names
        # --- END: Build inner subquery for field rule renames ---

        # Extract CR prefix
        cr_prefix_emit = ""
        cr_is_suffix_emit = False
        for cr in expr.get("conflict_resolutions", []):
            if cr.get("bulk_rename") and cr.get("rename_prefix"):
                cr_prefix_emit = cr["rename_prefix"]
                cr_is_suffix_emit = cr.get("is_suffix", False)
                break

        # Build layered FROM: CR → field rules → (outer gets expression outputs)
        expr_excl = {e.lower() for e in expr.get("excluded_fields", [])}
        expr_incl = {e.lower() for e in expr.get("included_fields", [])}
        has_layers = bool(cr_prefix_emit or has_field_rule_renames or expr_excl or expr_incl)

        if has_layers and upstream_cols:
            layered_from, layered_cols = self._build_layered_from(
                upstream_ref=upstream_cte,
                upstream_cols=upstream_cols,
                cr_prefix=cr_prefix_emit,
                cr_is_suffix=cr_is_suffix_emit,
                excluded=expr_excl,
                included=expr_incl,
                renames=expr_renames_lower if has_field_rule_renames else {},
            )
            from_clause = layered_from
            # layered_cols are the final column names after CR + field rules
        elif has_field_rule_renames and upstream_cols:
            from_clause = _build_inner_subquery()
            layered_cols = [expr_renames_lower.get(c.lower(), c) for c in upstream_cols]
        else:
            from_clause = upstream_cte
            layered_cols = list(upstream_cols) if upstream_cols else []

        lines = [f"{cte_name} AS ("]
        if output_cols:
            if layered_cols:
                # Emit layered passthrough columns + expression outputs
                lines.append("    SELECT")
                for c in layered_cols:
                    lines.append(f"        {c},")
                for i, col in enumerate(output_cols):
                    comma = "," if i < len(output_cols) - 1 else ""
                    lines.append(f"    {col}{comma}")
            else:
                # No upstream_cols available — fallback to SELECT *
                lines.append("    SELECT")
                lines.append("        *,")
                for i, col in enumerate(output_cols):
                    comma = "," if i < len(output_cols) - 1 else ""
                    lines.append(f"    {col}{comma}")
        else:
            # No expression outputs — pure passthrough
            if layered_cols:
                lines.append("    SELECT")
                for i, c in enumerate(layered_cols):
                    comma = "," if i < len(layered_cols) - 1 else ""
                    lines.append(f"        {c}{comma}")
            else:
                lines.append("    SELECT *")
            # Passthrough-only case is already handled above by layered_cols
        lines.append(f"    FROM {from_clause}")
        lines.append("),")
        # Prepend _vars CTE lines if we emitted one
        all_lines = vars_cte_lines + lines if vars_cte_lines else lines
        return cte_name, all_lines

    def _get_upstream_sort_key(self, expr: Dict, mapping: Dict) -> str:
        """Try to find the sort key from an upstream Sorter for LAG/ROW_NUMBER ORDER BY."""
        expr_id = expr.get("id")
        reverse_dag = mapping.get("reverse_dag", {})
        tx_by_id = mapping.get("tx_by_id", {})
        # Walk upstream to find a Sorter
        visited: Set[int] = set()
        queue = list(reverse_dag.get(expr_id, []))
        while queue:
            nid = queue.pop(0)
            if nid in visited:
                continue
            visited.add(nid)
            tx = tx_by_id.get(nid, {})
            if tx.get("type") == "Sorter":
                sorters = mapping.get("sorters", [])
                for s in sorters:
                    if s.get("id") == nid:
                        entries = s.get("sort_entries", [])
                        parts = []
                        for se in entries:
                            field = se.get("field", "")
                            direction = "ASC" if se.get("ascending", True) else "DESC"
                            if field:
                                parts.append(f"{field} {direction}")
                        if parts:
                            return ", ".join(parts)
            queue.extend(reverse_dag.get(nid, []))
        return ""

    def _emit_sql_transformation_cte(
        self, sql_tx: Dict, upstream_cte: str, mapping: Dict,
        upstream_cols: List[str] = None,
    ) -> Tuple[str, List[str]]:
        """Emit CTE for a SQL Transformation node."""
        tx_name = safe_name(sql_tx.get("name", "sql"))
        cte_name = f"sql_{tx_name}"
        mapping_name = mapping.get("mapping_name", "")
        sql_query = sql_tx.get("sql_query", "")

        # Separate input and output fields
        input_fields = []
        output_fields = []
        for f in sql_tx.get("fields", []):
            ft = f.get("exp_field_type", "").upper()
            fname = f.get("name", "")
            if not fname:
                continue
            if ft == "INPUT":
                input_fields.append(f)
            elif ft in ("OUTPUT", "INPUT/OUTPUT", ""):
                output_fields.append(f)

        if not sql_query:
            # Empty query: passthrough
            lines = [
                f"{cte_name} AS (",
                f"    SELECT * FROM {upstream_cte}",
                "),",
            ]
            return cte_name, lines

        # Translate table references: $$SCHEMA.table or $$SCHEMA.$$table → dbt ref
        translated = sql_query
        var_table_refs = re.findall(r'\$\$\w+\.(?:\$\$)?(\w+)', translated, flags=re.IGNORECASE)
        unique_tables = list(dict.fromkeys(t.lower() for t in var_table_refs))
        for tbl in unique_tables:
            tbl_stg_ref = self._find_stg_ref(tbl)
            translated = re.sub(
                r'\$\$\w+\.(?:\$\$)?' + re.escape(tbl) + r'\b',
                f"{{{{ ref('{tbl_stg_ref}') }}}}",
                translated,
                flags=re.IGNORECASE,
            )

        # Translate IDMC functions and variables
        translated = self.translator.translate(translated, mapping_name)

        # Check if the SQL has its own FROM clause
        has_from = bool(re.search(r'\bFROM\b', translated, re.IGNORECASE))

        lines = [f"{cte_name} AS ("]
        if has_from:
            # SQL has its own FROM — use the translated SQL directly
            for sql_line in translated.strip().splitlines():
                lines.append(f"    {sql_line.strip()}")
        else:
            # No FROM — build SELECT with output columns over the upstream CTE
            lines.append("    SELECT")
            if output_fields:
                for i, f in enumerate(output_fields):
                    fname = f.get("name", "")
                    expr_str = f.get("expression", "")
                    comma = "," if i < len(output_fields) - 1 else ""
                    if expr_str:
                        texpr = self.translator.translate(expr_str, mapping_name)
                        lines.append(f"        {_cast_null(texpr)} AS {fname}{comma}")
                    else:
                        lines.append(f"        {fname}{comma}")
            else:
                # Fallback: use the raw translated SQL
                lines.append(f"        {translated.strip()}")
            lines.append(f"    FROM {upstream_cte}")
        lines.append("),")
        return cte_name, lines

    def _emit_union_cte(
        self, union: Dict, branch_ctes: List[str], mapping: Dict,
        branch_group_names: List[str] = None,
    ) -> Tuple[str, List[str]]:
        """Emit CTE for a union node with column-aligned UNION ALL."""
        union_name = safe_name(union.get("name", "union"))
        cte_name = f"union_{union_name}"

        union_out_fields = [f.get("name", "") for f in union.get("fields", []) if f.get("name")]
        input_group_field_maps = union.get("input_group_field_maps", {})

        lines = [f"{cte_name} AS ("]
        for i, branch_cte in enumerate(branch_ctes):
            if i > 0:
                lines.append("    UNION ALL")
            # Try column-aligned select if we know the group and have field mappings
            group_name = branch_group_names[i] if branch_group_names and i < len(branch_group_names) else None
            field_map = input_group_field_maps.get(group_name, {}) if group_name else {}
            if union_out_fields and field_map:
                select_items = []
                for uf in union_out_fields:
                    branch_col = field_map.get(uf.lower())
                    if branch_col is None:
                        # Field not mapped in this input group — emit NULL
                        select_items.append(f"CAST(NULL AS STRING) AS {uf}")
                    elif branch_col != uf:
                        select_items.append(f"{branch_col} AS {uf}")
                    else:
                        select_items.append(uf)
                lines.append(f"    SELECT {', '.join(select_items)} FROM {branch_cte}")
            else:
                lines.append(f"    SELECT * FROM {branch_cte}")
        lines.append("),")
        return cte_name, lines

    def _emit_sequence_cte(
        self, seq: Dict, upstream_cte: str
    ) -> Tuple[str, List[str]]:
        """Emit CTE for a sequence generator node."""
        seq_name = safe_name(seq.get("name", "sequence"))
        cte_name = f"seq_{seq_name}"
        # Sequence generators in IDMC produce an auto-incrementing column
        # named NEXTVAL. In dbt SQL, we use ROW_NUMBER().
        lines = [
            f"{cte_name} AS (",
            "    SELECT",
            "        *,",
            "        ROW_NUMBER() OVER(ORDER BY 1) AS NEXTVAL",
            f"    FROM {upstream_cte}",
            "),",
        ]
        return cte_name, lines

    # ------------------------------------------------------------------
    # DAG walker orchestrator
    # ------------------------------------------------------------------

    def _walk_dag_to_ctes(
        self, lines: List[str], mapping: Dict, main_targets: List[Dict],
    ) -> str:
        """Walk the DAG in topological order, emitting one CTE per node.

        Returns the name of the last CTE emitted.
        """
        main_target_ids = {t.get("id") for t in main_targets}
        tx_by_id = mapping.get("tx_by_id", {})
        reverse_dag = mapping.get("reverse_dag", {})
        link_to_group_map = mapping.get("link_to_group_map", {})
        from_group_map = mapping.get("from_group_map", {})
        multi_link_map = mapping.get("multi_link_map", {})
        mapping_name = mapping.get("mapping_name", "")

        # Build lookup dicts by ID for each extracted type
        sources_by_id = {s.get("id"): s for s in mapping.get("sources", [])}
        expressions_by_id = {e.get("id"): e for e in mapping.get("expressions", [])}
        joiners_by_id = {j.get("id"): j for j in mapping.get("joiners", [])}
        routers_by_id = {r.get("id"): r for r in mapping.get("routers", [])}
        filters_by_id = {f.get("id"): f for f in mapping.get("filters", [])}
        aggregators_by_id = {a.get("id"): a for a in mapping.get("aggregators", [])}
        unions_by_id = {u.get("id"): u for u in mapping.get("unions", [])}
        ranks_by_id = {r.get("id"): r for r in mapping.get("ranks", [])}
        normalizers_by_id = {n.get("id"): n for n in mapping.get("normalizers", [])}
        sequences_by_id = {s.get("id"): s for s in mapping.get("sequences", [])}
        sorters_by_id = {s.get("id"): s for s in mapping.get("sorters", [])}
        lookups_by_id = {l.get("id"): l for l in mapping.get("lookups", [])}
        sql_txs_by_id = {s.get("id"): s for s in mapping.get("sql_transformations", [])}
        targets_by_id = {t.get("id"): t for t in mapping.get("targets", [])}
        dag = mapping.get("dag", {})

        # Topological sort
        order = self._topo_sort_pipeline(mapping, main_target_ids)

        # CDC stripping: skip CDC-infrastructure nodes for CDC mappings
        cdc_skip_ids = IDMCParser._compute_cdc_skip_ids(mapping)
        if cdc_skip_ids:
            self.logger.info(
                f"CDC stripping: skipping {len(cdc_skip_ids)} CDC nodes "
                f"from intermediate for '{mapping_name}'"
            )

        # CTE tracking
        cte_registry: Dict[int, str] = {}  # node_id → CTE name
        router_group_ctes: Dict[Tuple[int, int], str] = {}  # (router_id, group_$$ID) → CTE name
        cte_columns: Dict[str, List[str]] = {}  # cte_name → column names
        last_cte = ""
        last_business_cte = ""
        all_cte_lines: List[List[str]] = []
        cdc_cte_indices: Set[int] = set()  # indices into all_cte_lines that are CDC nodes

        for node_id in order:
            is_cdc_node = node_id in cdc_skip_ids
            cdc_mark_start = len(all_cte_lines) if is_cdc_node else -1
            tx = tx_by_id.get(node_id, {})
            tx_type = tx.get("type", "")

            if tx_type == "Source":
                src = sources_by_id.get(node_id)
                if not src:
                    continue
                cte_name, cte_lines = self._emit_source_cte(src, mapping)
                cte_registry[node_id] = cte_name
                cte_columns[cte_name] = [f.get("name", "") for f in src.get("fields", []) if f.get("name")]
                all_cte_lines.append(cte_lines)
                last_cte = cte_name
                # Track CDC-only source intermediates for orphan comments:
                # A source is orphaned if it is CDC-skipped OR if all its
                # successors are CDC-skipped (e.g. master-side of FOJ).
                successors = dag.get(node_id, [])
                is_cdc_orphan = is_cdc_node or (
                    cdc_skip_ids and successors
                    and all(s in cdc_skip_ids for s in successors)
                )
                if is_cdc_orphan:
                    source_name_i, _, table_name_i = self._derive_source_info(src, mapping)
                    sq_safe_i = safe_name(src.get("name", ""))
                    src_int_key = (source_name_i, table_name_i, safe_name(mapping_name), sq_safe_i)
                    self._cdc_only_src_int_keys.add(src_int_key)

            elif tx_type == "Router":
                rtr = routers_by_id.get(node_id)
                if not rtr:
                    continue
                upstream = self._resolve_upstream_cte(
                    node_id, cte_registry, router_group_ctes,
                    reverse_dag, from_group_map,
                )
                if not upstream:
                    self.logger.warning(f"Router {rtr.get('name')}: no upstream CTE found")
                    continue
                upstream_cols = cte_columns.get(upstream, [])
                results = self._emit_router_ctes(rtr, upstream, mapping, upstream_cols=upstream_cols)
                # Register each group CTE and update cte_columns
                rtr_excluded = {e.lower() for e in rtr.get("excluded_fields", [])}
                rtr_renames = {k.lower(): v for k, v in rtr.get("field_renames", {}).items()}
                rtr_included = {e.lower() for e in rtr.get("included_fields", [])}
                # Unified tracking: use _build_layered_from (same as emission)
                _, rtr_layered_cols = self._build_layered_from(
                    upstream, upstream_cols,
                    excluded=rtr_excluded, included=rtr_included, renames=rtr_renames,
                ) if upstream_cols and (rtr_excluded or rtr_renames or rtr_included) else (upstream, list(upstream_cols))
                for cte_name, cte_lines, grp_id in results:
                    router_group_ctes[(node_id, grp_id)] = cte_name
                    cte_columns[cte_name] = rtr_layered_cols if rtr_layered_cols else upstream_cols
                    all_cte_lines.append(cte_lines)
                    last_cte = cte_name
                # Also register the router itself (last group as fallback)
                if results:
                    cte_registry[node_id] = results[-1][0]

            elif tx_type == "Joiner":
                jnr = joiners_by_id.get(node_id)
                if not jnr:
                    continue
                master_cte, detail_cte = self._resolve_joiner_inputs(
                    jnr, cte_registry, router_group_ctes,
                    reverse_dag, link_to_group_map, from_group_map,
                )
                if not master_cte or not detail_cte:
                    self.logger.warning(
                        f"Joiner {jnr.get('name')}: missing master={master_cte} detail={detail_cte}"
                    )
                    # Still register so downstream can find something
                    if master_cte:
                        cte_registry[node_id] = master_cte
                    continue
                master_cols = cte_columns.get(master_cte, [])
                detail_cols = cte_columns.get(detail_cte, [])
                cte_name, cte_lines = self._emit_joiner_cte(
                    jnr, master_cte, detail_cte, mapping,
                    detail_cols=detail_cols,
                    master_cols=master_cols,
                )
                cte_registry[node_id] = cte_name
                # Unified tracking: use same _build_layered_from as emission
                # Extract per-group CR + field rules
                m_prefix = m_suffix = d_prefix = d_suffix = ""
                m_excl = d_excl = set()
                m_incl = d_incl = set()
                m_ren = d_ren = {}
                for g in jnr.get("groups", []):
                    gn = g.get("name", "").lower()
                    if gn == "master":
                        m_prefix = g.get("prefix", "")
                        m_suffix = g.get("is_suffix", False)
                        m_excl = {e.lower() for e in g.get("excluded_fields", [])}
                        m_incl = {e.lower() for e in g.get("included_fields", [])}
                        m_ren = {k.lower(): v for k, v in g.get("field_renames", {}).items()}
                    elif gn == "detail":
                        d_prefix = g.get("prefix", "")
                        d_suffix = g.get("is_suffix", False)
                        d_excl = {e.lower() for e in g.get("excluded_fields", [])}
                        d_incl = {e.lower() for e in g.get("included_fields", [])}
                        d_ren = {k.lower(): v for k, v in g.get("field_renames", {}).items()}
                _, master_final = self._build_layered_from(
                    master_cte, master_cols or [], m_prefix, m_suffix, m_excl, m_incl, m_ren)
                _, detail_final = self._build_layered_from(
                    detail_cte, detail_cols or [], d_prefix, d_suffix, d_excl, d_incl, d_ren)
                master_out_names = {c.lower() for c in master_final}
                deduped_detail = [c for c in detail_final if c.lower() not in master_out_names]
                cte_columns[cte_name] = master_final + deduped_detail
                all_cte_lines.append(cte_lines)
                last_cte = cte_name

            elif tx_type == "Expression":
                expr = expressions_by_id.get(node_id)
                if not expr:
                    continue
                # Skip OPS and lookup expressions
                ename = expr.get("name", "").lower()
                if "_ops" in ename or "_lkp_" in ename:
                    # Pass through: register upstream as this node's CTE
                    upstream = self._resolve_upstream_cte(
                        node_id, cte_registry, router_group_ctes,
                        reverse_dag, from_group_map,
                    )
                    if upstream:
                        cte_registry[node_id] = upstream
                        # cte_columns inherits from upstream (same CTE name)
                    continue
                upstream = self._resolve_upstream_cte(
                    node_id, cte_registry, router_group_ctes,
                    reverse_dag, from_group_map,
                )
                if not upstream:
                    self.logger.warning(f"Expression {expr.get('name')}: no upstream CTE")
                    continue
                up_cols = cte_columns.get(upstream, [])
                # Walk upstream chain to find columns for SELECT * CTEs
                if not up_cols:
                    walk_id = node_id
                    visited_walk_emit: Set[int] = set()
                    while not up_cols and walk_id not in visited_walk_emit:
                        visited_walk_emit.add(walk_id)
                        parents = reverse_dag.get(walk_id, [])
                        if not parents:
                            break
                        parent_id = parents[0]
                        parent_cte = cte_registry.get(parent_id, "")
                        if parent_cte:
                            up_cols = cte_columns.get(parent_cte, [])
                        walk_id = parent_id

                # If still empty and CR prefix exists, infer from expression field refs
                if not up_cols:
                    _cr_pfx = ""
                    _cr_sfx = False
                    for cr in expr.get("conflict_resolutions", []):
                        if cr.get("bulk_rename") and cr.get("rename_prefix"):
                            _cr_pfx = cr["rename_prefix"]
                            _cr_sfx = cr.get("is_suffix", False)
                            break
                    if _cr_pfx:
                        inferred = set()
                        for f in expr.get("fields", []):
                            e = f.get("expression", "")
                            if e and e != "null":
                                e_clean = e.strip()
                                if _cr_sfx and e_clean.endswith(_cr_pfx):
                                    inferred.add(e_clean[:-len(_cr_pfx)])
                                elif not _cr_sfx and e_clean.lower().startswith(_cr_pfx.lower()):
                                    inferred.add(e_clean[len(_cr_pfx):])
                        for inc in expr.get("included_fields", []):
                            if not _cr_sfx and inc.lower().startswith(_cr_pfx.lower()):
                                inferred.add(inc[len(_cr_pfx):])
                            elif _cr_sfx and inc.lower().endswith(_cr_pfx.lower()):
                                inferred.add(inc[:-len(_cr_pfx)])
                            else:
                                inferred.add(inc)
                        if inferred:
                            up_cols = sorted(inferred)

                # Determine downstream expected fields from the forward DAG.
                # If ALL immediate downstream nodes are targets with manual
                # mappings, use fromFieldName to know exactly which columns
                # should exit the expression CTE.
                ds_ids = dag.get(node_id, [])
                downstream_expected = None
                if ds_ids:
                    all_have_mappings = True
                    expected_set = set()
                    for ds_id in ds_ids:
                        ds_tgt = targets_by_id.get(ds_id)
                        if ds_tgt and ds_tgt.get("manual_mappings"):
                            for mm in ds_tgt["manual_mappings"]:
                                ffn = mm.get("fromFieldName", "")
                                if ffn:
                                    expected_set.add(ffn.lower())
                            # Also include target field names — mart models
                            # reference intermediate columns by target field name
                            for tf in ds_tgt.get("fields", []):
                                tfn = tf.get("name", "")
                                if tfn:
                                    expected_set.add(tfn.lower())
                        else:
                            all_have_mappings = False
                            break
                    if all_have_mappings and expected_set:
                        downstream_expected = expected_set

                cte_name, cte_lines = self._emit_expression_cte(
                    expr, upstream, mapping, upstream_cols=up_cols,
                    downstream_expected_fields=downstream_expected,
                )
                cte_registry[node_id] = cte_name

                # Unified tracking: use _build_layered_from for passthrough cols
                cr_pfx_t = ""
                cr_sfx_t = False
                for cr in expr.get("conflict_resolutions", []):
                    if cr.get("bulk_rename") and cr.get("rename_prefix"):
                        cr_pfx_t = cr["rename_prefix"]
                        cr_sfx_t = cr.get("is_suffix", False)
                        break
                expr_renames_t = {k.lower(): v for k, v in expr.get("field_renames", {}).items()}
                expr_excl_t = {e.lower() for e in expr.get("excluded_fields", [])}
                expr_incl_t = {e.lower() for e in expr.get("included_fields", [])}

                _, layered_cols_t = self._build_layered_from(
                    upstream, up_cols,
                    cr_prefix=cr_pfx_t, cr_is_suffix=cr_sfx_t,
                    excluded=expr_excl_t, included=expr_incl_t,
                    renames=expr_renames_t,
                )

                # Expression output fields + variable fields
                new_output = []
                var_col_names = []
                for f in expr.get("fields", []):
                    is_var = f.get("variable", False)
                    if is_var or f.get("exp_field_type", "").upper() == "VARIABLE":
                        vname = f.get("name", "")
                        vexpr = f.get("expression", "")
                        if vname and vexpr:
                            var_col_names.append(vname)
                        continue
                    if f.get("exp_field_type", "").upper() not in ("OUTPUT", ""):
                        continue
                    fname = f.get("name", "")
                    expr_str = f.get("expression", "")
                    if fname and expr_str:
                        new_output.append(fname)

                # Combine: layered passthrough (excluding expression output overlaps) + vars + outputs
                new_lower = {n.lower() for n in new_output + var_col_names}
                passthrough = [c for c in layered_cols_t if c.lower() not in new_lower]
                cte_columns[cte_name] = passthrough + var_col_names + new_output
                all_cte_lines.append(cte_lines)
                last_cte = cte_name

            elif tx_type == "Filter":
                fil = filters_by_id.get(node_id)
                if not fil:
                    continue
                upstream = self._resolve_upstream_cte(
                    node_id, cte_registry, router_group_ctes,
                    reverse_dag, from_group_map,
                )
                if not upstream:
                    continue
                up_cols = cte_columns.get(upstream, [])
                fil_renames = {k.lower(): v for k, v in fil.get("field_renames", {}).items()}
                fil_excluded = {e.lower() for e in fil.get("excluded_fields", [])}
                fil_included = {e.lower() for e in fil.get("included_fields", [])}
                has_rules = bool(fil_renames or fil_excluded or fil_included)
                if has_rules and up_cols:
                    layered_from, layered_cols = self._build_layered_from(
                        upstream_ref=upstream,
                        upstream_cols=up_cols,
                        excluded=fil_excluded,
                        included=fil_included,
                        renames=fil_renames,
                    )
                    sname = safe_name(fil.get("name", "filter"))
                    cte_name = f"{sname}_filtered"
                    condition = fil.get("condition", "1=1")
                    translated = self.translator.translate(condition, mapping_name)
                    fil_lines = [f"{cte_name} AS ("]
                    fil_lines.append("    SELECT")
                    for i, c in enumerate(layered_cols):
                        comma = "," if i < len(layered_cols) - 1 else ""
                        fil_lines.append(f"        {c}{comma}")
                    fil_lines.append(f"    FROM {layered_from}")
                    fil_lines.append(f"    WHERE {translated}")
                    fil_lines.append("),")
                    cte_registry[node_id] = cte_name
                    cte_columns[cte_name] = layered_cols
                    all_cte_lines.append(fil_lines)
                    last_cte = cte_name
                else:
                    cte_name, cte_lines = self._build_filter_cte(
                        fil, upstream, mapping_name
                    )
                    # _build_filter_cte ends with ")"; convert to "),"
                    if cte_lines and cte_lines[-1].rstrip() == ")":
                        cte_lines[-1] = "),"
                    cte_registry[node_id] = cte_name
                    cte_columns[cte_name] = up_cols if up_cols else []
                    all_cte_lines.append(cte_lines)
                    last_cte = cte_name

            elif tx_type == "Aggregator":
                agg = aggregators_by_id.get(node_id)
                if not agg:
                    continue
                upstream = self._resolve_upstream_cte(
                    node_id, cte_registry, router_group_ctes,
                    reverse_dag, from_group_map,
                )
                if not upstream:
                    continue
                up_cols = cte_columns.get(upstream, [])

                # Build layered FROM for CR + field rules on incoming columns
                agg_cr_prefix = ""
                agg_cr_is_suffix = False
                for cr in agg.get("conflict_resolutions", []):
                    if cr.get("bulk_rename") and cr.get("rename_prefix"):
                        agg_cr_prefix = cr["rename_prefix"]
                        agg_cr_is_suffix = cr.get("is_suffix", False)
                        break
                agg_renames = {k.lower(): v for k, v in agg.get("field_renames", {}).items()}
                agg_excluded = {e.lower() for e in agg.get("excluded_fields", [])}
                agg_included = {e.lower() for e in agg.get("included_fields", [])}
                has_layers = bool(agg_cr_prefix or agg_renames or agg_excluded or agg_included)

                if has_layers and up_cols:
                    layered_from, layered_cols = self._build_layered_from(
                        upstream_ref=upstream,
                        upstream_cols=up_cols,
                        cr_prefix=agg_cr_prefix,
                        cr_is_suffix=agg_cr_is_suffix,
                        excluded=agg_excluded,
                        included=agg_included,
                        renames=agg_renames,
                    )
                    agg_input = layered_from
                    agg_up_cols = layered_cols
                else:
                    agg_input = upstream
                    agg_up_cols = up_cols

                cte_name, cte_lines = self._build_aggregator_cte(
                    agg, agg_input, mapping_name, upstream_cols=agg_up_cols
                )
                # _build_aggregator_cte ends with ")"; convert to "),"
                if cte_lines and cte_lines[-1].rstrip() == ")":
                    cte_lines[-1] = "),"
                cte_registry[node_id] = cte_name
                # Aggregator output: all upstream cols (post CR+FR) + aggregate fields
                agg_cols_set: Set[str] = set()
                agg_cols = []
                if agg_up_cols:
                    for col in agg_up_cols:
                        if col.lower() not in agg_cols_set:
                            agg_cols.append(col)
                            agg_cols_set.add(col.lower())
                for f in agg.get("fields", []):
                    fname = f.get("name", "")
                    if fname and fname.lower() not in agg_cols_set:
                        agg_cols.append(fname)
                        agg_cols_set.add(fname.lower())
                cte_columns[cte_name] = agg_cols
                all_cte_lines.append(cte_lines)
                last_cte = cte_name

            elif tx_type == "Union":
                union = unions_by_id.get(node_id)
                if not union:
                    continue
                # Find all branch CTEs feeding this union, with group names
                # Use multi_link_map to handle multiple links from same router
                group_id_to_name = union.get("group_id_to_name", {})
                preds = reverse_dag.get(node_id, [])
                branch_ctes = []
                branch_group_names = []
                for pred_id in preds:
                    link_entries = multi_link_map.get((pred_id, node_id), [])
                    if link_entries:
                        # Multiple links possible (e.g., router → union with 2+ groups)
                        for from_grp_id, to_grp_id in link_entries:
                            if from_grp_id is not None and (pred_id, from_grp_id) in router_group_ctes:
                                branch_ctes.append(router_group_ctes[(pred_id, from_grp_id)])
                            elif pred_id in cte_registry:
                                branch_ctes.append(cte_registry[pred_id])
                            else:
                                continue
                            grp_name = group_id_to_name.get(to_grp_id, "") if to_grp_id is not None else ""
                            branch_group_names.append(grp_name)
                    else:
                        # Fallback: single link (no multi_link_map entry)
                        from_grp_id = from_group_map.get((pred_id, node_id))
                        if from_grp_id is not None and (pred_id, from_grp_id) in router_group_ctes:
                            branch_ctes.append(router_group_ctes[(pred_id, from_grp_id)])
                        elif pred_id in cte_registry:
                            branch_ctes.append(cte_registry[pred_id])
                        else:
                            continue
                        to_grp_id = link_to_group_map.get((pred_id, node_id))
                        grp_name = group_id_to_name.get(to_grp_id, "") if to_grp_id is not None else ""
                        branch_group_names.append(grp_name)
                if not branch_ctes:
                    continue
                cte_name, cte_lines = self._emit_union_cte(
                    union, branch_ctes, mapping,
                    branch_group_names=branch_group_names,
                )
                cte_registry[node_id] = cte_name
                # Union output = its canonical field list
                union_fields = [f.get("name", "") for f in union.get("fields", []) if f.get("name")]
                cte_columns[cte_name] = union_fields if union_fields else cte_columns.get(branch_ctes[0], [])
                all_cte_lines.append(cte_lines)
                last_cte = cte_name

            elif tx_type == "Rank":
                rank = ranks_by_id.get(node_id)
                if not rank:
                    continue
                upstream = self._resolve_upstream_cte(
                    node_id, cte_registry, router_group_ctes,
                    reverse_dag, from_group_map,
                )
                if not upstream:
                    continue
                up_cols = cte_columns.get(upstream, [])
                rnk_renames = {k.lower(): v for k, v in rank.get("field_renames", {}).items()}
                rnk_excluded = {e.lower() for e in rank.get("excluded_fields", [])}
                rnk_included = {e.lower() for e in rank.get("included_fields", [])}
                has_rules = bool(rnk_renames or rnk_excluded or rnk_included)
                rank_port = rank.get("rank_port", "RANKINDEX")
                if has_rules and up_cols:
                    layered_from, layered_cols = self._build_layered_from(
                        upstream_ref=upstream,
                        upstream_cols=up_cols,
                        excluded=rnk_excluded,
                        included=rnk_included,
                        renames=rnk_renames,
                    )
                    sname = safe_name(rank.get("name", "rank"))
                    cte_name = f"{sname}_ranked"
                    group_by = rank.get("group_by_fields", [])
                    order_field = rank.get("order_by_field", "")
                    num_ranks = rank.get("num_ranks", 1)
                    top_bottom = rank.get("top_bottom", "Top")
                    direction = "DESC" if top_bottom == "Top" else "ASC"
                    partition_clause = f"PARTITION BY {', '.join(group_by)}" if group_by else ""
                    order_clause = f"ORDER BY {order_field} {direction}" if order_field else "ORDER BY 1"
                    rnk_lines = [f"{cte_name} AS ("]
                    rnk_lines.append("    SELECT")
                    for i, c in enumerate(layered_cols):
                        rnk_lines.append(f"        {c},")
                    rnk_lines.append(f"        ROW_NUMBER() OVER (")
                    if partition_clause:
                        rnk_lines.append(f"            {partition_clause}")
                    rnk_lines.append(f"            {order_clause}")
                    rnk_lines.append(f"        ) AS {rank_port}")
                    rnk_lines.append(f"    FROM {layered_from}")
                    rnk_lines.append(f"    QUALIFY {rank_port} <= {num_ranks}")
                    rnk_lines.append("),")
                    cte_registry[node_id] = cte_name
                    cte_columns[cte_name] = layered_cols + [rank_port]
                    all_cte_lines.append(rnk_lines)
                    last_cte = cte_name
                else:
                    cte_name, cte_lines = self._build_rank_cte(rank, upstream)
                    # _build_rank_cte ends with ")"; convert to "),"
                    if cte_lines and cte_lines[-1].rstrip() == ")":
                        cte_lines[-1] = "),"
                    cte_registry[node_id] = cte_name
                    cte_columns[cte_name] = (up_cols if up_cols else []) + [rank_port]
                    all_cte_lines.append(cte_lines)
                    last_cte = cte_name

            elif tx_type == "Normalizer":
                norm = normalizers_by_id.get(node_id)
                if not norm:
                    continue
                upstream = self._resolve_upstream_cte(
                    node_id, cte_registry, router_group_ctes,
                    reverse_dag, from_group_map,
                )
                if not upstream:
                    continue
                cte_name, cte_lines = self._build_normalizer_cte(norm, upstream)
                # _build_normalizer_cte ends with ")"; convert to "),"
                if cte_lines and cte_lines[-1].rstrip() == ")":
                    cte_lines[-1] = "),"
                cte_registry[node_id] = cte_name
                # Normalizer output = pass_through + normalized field names + GCID
                norm_cols = list(norm.get("pass_through_fields", []))
                for nf in norm.get("normalized_fields", []):
                    fname = nf.get("name", "")
                    if fname:
                        norm_cols.append(fname)
                norm_cols.append("GCID")
                cte_columns[cte_name] = norm_cols
                all_cte_lines.append(cte_lines)
                last_cte = cte_name

            elif tx_type == "Sequence Generator":
                seq = sequences_by_id.get(node_id)
                if not seq:
                    continue
                upstream = self._resolve_upstream_cte(
                    node_id, cte_registry, router_group_ctes,
                    reverse_dag, from_group_map,
                )
                if not upstream:
                    continue
                up_cols = cte_columns.get(upstream, [])
                seq_renames = {k.lower(): v for k, v in seq.get("field_renames", {}).items()}
                seq_excluded = {e.lower() for e in seq.get("excluded_fields", [])}
                seq_included = {e.lower() for e in seq.get("included_fields", [])}
                has_rules = bool(seq_renames or seq_excluded or seq_included)
                if has_rules and up_cols:
                    layered_from, layered_cols = self._build_layered_from(
                        upstream_ref=upstream,
                        upstream_cols=up_cols,
                        excluded=seq_excluded,
                        included=seq_included,
                        renames=seq_renames,
                    )
                    seq_name = safe_name(seq.get("name", "sequence"))
                    cte_name = f"seq_{seq_name}"
                    seq_lines = [f"{cte_name} AS ("]
                    seq_lines.append("    SELECT")
                    for i, c in enumerate(layered_cols):
                        seq_lines.append(f"        {c},")
                    seq_lines.append("        ROW_NUMBER() OVER(ORDER BY 1) AS NEXTVAL")
                    seq_lines.append(f"    FROM {layered_from}")
                    seq_lines.append("),")
                    cte_registry[node_id] = cte_name
                    cte_columns[cte_name] = layered_cols + ["NEXTVAL"]
                    all_cte_lines.append(seq_lines)
                    last_cte = cte_name
                else:
                    cte_name, cte_lines = self._emit_sequence_cte(seq, upstream)
                    cte_registry[node_id] = cte_name
                    cte_columns[cte_name] = (up_cols if up_cols else []) + ["NEXTVAL"]
                    all_cte_lines.append(cte_lines)
                    last_cte = cte_name

            elif tx_type == "Lookup":
                lkp = lookups_by_id.get(node_id)
                if not lkp:
                    continue
                if lkp.get("unconnected"):
                    # Unconnected lookups have no DAG links; handled via :LKP in expressions
                    continue
                # Connected lookup: emit LEFT JOIN CTE
                upstream = self._resolve_upstream_cte(
                    node_id, cte_registry, router_group_ctes,
                    reverse_dag, from_group_map,
                )
                if not upstream:
                    # Fallback passthrough
                    continue
                up_cols = cte_columns.get(upstream, [])
                cte_name, cte_lines = self._emit_lookup_cte(
                    lkp, upstream, mapping, upstream_cols=up_cols,
                )
                cte_registry[node_id] = cte_name
                # Unified tracking: use _build_layered_from for upstream cols
                up_prefix = lkp.get("upstream_prefix", "")
                lkp_field_names = [f.get("name", "") for f in lkp.get("fields", []) if f.get("name")]
                lkp_fields_lower = {lf.lower() for lf in lkp_field_names}
                lkp_excl = {e.lower() for e in lkp.get("excluded_fields", [])}
                lkp_incl = {e.lower() for e in lkp.get("included_fields", [])}
                lkp_ren = {k.lower(): v for k, v in lkp.get("field_renames", {}).items()}
                _, lkp_up_final = self._build_layered_from(
                    upstream, up_cols,
                    cr_prefix=up_prefix, cr_is_suffix=False,
                    excluded=lkp_excl, included=lkp_incl, renames=lkp_ren,
                )
                # Dedup upstream against lookup field names
                deduped_up = [c for c in lkp_up_final if c.lower() not in lkp_fields_lower]
                cte_columns[cte_name] = deduped_up + lkp_field_names
                all_cte_lines.append(cte_lines)
                last_cte = cte_name

            elif tx_type == "SQL":
                sql_tx = sql_txs_by_id.get(node_id)
                if not sql_tx:
                    # Fallback passthrough
                    upstream = self._resolve_upstream_cte(
                        node_id, cte_registry, router_group_ctes,
                        reverse_dag, from_group_map,
                    )
                    if upstream:
                        cte_registry[node_id] = upstream
                    continue
                upstream = self._resolve_upstream_cte(
                    node_id, cte_registry, router_group_ctes,
                    reverse_dag, from_group_map,
                )
                if not upstream:
                    continue
                up_cols = cte_columns.get(upstream, [])
                cte_name, cte_lines = self._emit_sql_transformation_cte(
                    sql_tx, upstream, mapping, upstream_cols=up_cols,
                )
                cte_registry[node_id] = cte_name
                # Only OUTPUT fields become this CTE's output columns
                output_col_names = []
                for f in sql_tx.get("fields", []):
                    ft = f.get("exp_field_type", "").upper()
                    fname = f.get("name", "")
                    if fname and ft in ("OUTPUT", "INPUT/OUTPUT", ""):
                        output_col_names.append(fname)
                # If the SQL has a FROM clause, output is just the output fields;
                # otherwise, upstream cols pass through plus any new output fields
                sql_query = sql_tx.get("sql_query", "")
                has_from = bool(re.search(r'\bFROM\b', sql_query, re.IGNORECASE)) if sql_query else False
                if has_from and output_col_names:
                    cte_columns[cte_name] = output_col_names
                elif output_col_names:
                    # No FROM: upstream cols pass through, new outputs added
                    new_lower = {n.lower() for n in output_col_names}
                    merged = [c for c in up_cols if c.lower() not in new_lower] + output_col_names
                    cte_columns[cte_name] = merged
                else:
                    # Fallback: inherit upstream columns
                    cte_columns[cte_name] = list(up_cols)
                all_cte_lines.append(cte_lines)
                last_cte = cte_name

            elif tx_type == "Sorter":
                # Sorter is a pass-through in dbt — ORDER BY has no effect
                # on materialized tables/views.
                sorter = sorters_by_id.get(node_id)
                upstream = self._resolve_upstream_cte(
                    node_id, cte_registry, router_group_ctes,
                    reverse_dag, from_group_map,
                )
                if upstream:
                    if sorter:
                        srt_renames = {k.lower(): v for k, v in sorter.get("field_renames", {}).items()}
                        srt_excluded = {e.lower() for e in sorter.get("excluded_fields", [])}
                        srt_included = {e.lower() for e in sorter.get("included_fields", [])}
                        srt_prefix = sorter.get("prefix", "")
                        srt_is_suffix = sorter.get("is_suffix", False)
                        has_rules = bool(srt_renames or srt_excluded or srt_included or srt_prefix)
                        up_cols = cte_columns.get(upstream, [])

                        if has_rules and up_cols:
                            # Emit sorter as real CTE with layered subquery
                            srt_name = safe_name(sorter.get("name", "sorter"))
                            srt_cte = f"srt_{srt_name}"
                            layered_from, layered_cols = self._build_layered_from(
                                upstream_ref=upstream,
                                upstream_cols=up_cols,
                                cr_prefix=srt_prefix,
                                cr_is_suffix=srt_is_suffix,
                                excluded=srt_excluded,
                                included=srt_included,
                                renames=srt_renames,
                            )
                            srt_lines = [f"{srt_cte} AS ("]
                            srt_lines.append("    SELECT")
                            for i, c in enumerate(layered_cols):
                                comma = "," if i < len(layered_cols) - 1 else ""
                                srt_lines.append(f"        {c}{comma}")
                            srt_lines.append(f"    FROM {layered_from}")
                            srt_lines.append("),")
                            all_cte_lines.append(srt_lines)
                            cte_registry[node_id] = srt_cte
                            cte_columns[srt_cte] = layered_cols
                            last_cte = srt_cte
                        else:
                            # No field rules or no upstream cols — passthrough
                            cte_registry[node_id] = upstream

                        # Emit sort comment
                        sort_strs = []
                        for se in sorter.get("sort_entries", []):
                            field = se.get("field", "")
                            direction = "ASC" if se.get("ascending", True) else "DESC"
                            sort_strs.append(f"{field} {direction}")
                        if sort_strs:
                            sorter_name = sorter.get("name", "")
                            label = f"IDMC Sorter '{sorter_name}'" if sorter_name else "IDMC Sorter"
                            comment = f"/* {label}: {', '.join(sort_strs)} — pass-through, ordering not applicable in dbt */"
                            if all_cte_lines:
                                all_cte_lines[-1].append(f"    {comment}")
                    else:
                        cte_registry[node_id] = upstream

            else:
                # Unknown type: try passthrough
                upstream = self._resolve_upstream_cte(
                    node_id, cte_registry, router_group_ctes,
                    reverse_dag, from_group_map,
                )
                if upstream:
                    cte_registry[node_id] = upstream

            # Track CDC node CTE indices and revert last_cte for CDC nodes
            if is_cdc_node:
                for idx in range(cdc_mark_start, len(all_cte_lines)):
                    cdc_cte_indices.add(idx)
                # Revert last_cte so the final SELECT references the last business CTE
                last_cte = last_business_cte
            elif all_cte_lines:
                last_business_cte = last_cte

        # Separate business CTEs from CDC CTEs
        business_ctes = [
            (i, cl) for i, cl in enumerate(all_cte_lines)
            if cl and i not in cdc_cte_indices
        ]
        cdc_ctes = [
            (i, cl) for i, cl in enumerate(all_cte_lines)
            if cl and i in cdc_cte_indices
        ]

        # Emit business CTEs
        for idx, (_, cte_lines) in enumerate(business_ctes):
            is_last = (idx == len(business_ctes) - 1)
            for line in cte_lines:
                if is_last and line.strip() == "),":
                    lines.append(")")
                else:
                    lines.append(line)

        # Emit CDC CTEs as commented-out SQL
        if cdc_ctes:
            lines.append("")
            lines.append("/* ==========================================================")
            lines.append("   CDC-INFRASTRUCTURE CTEs — stripped by dbt snapshot conversion.")
            lines.append("   In dbt, CDC/SCD2 logic is handled by dbt snapshots.")
            lines.append("   Uncomment if you need to review or reuse this logic.")
            lines.append("")
            for idx, (_, cte_lines) in enumerate(cdc_ctes):
                for line in cte_lines:
                    # Strip trailing comma from last CDC CTE closing
                    if idx == len(cdc_ctes) - 1 and line.strip() == "),":
                        lines.append(line.replace("),", ")"))
                    else:
                        lines.append(line)
            lines.append("========================================================== */")

        # Override last_cte by tracing backward from the primary business
        # target through the DAG until we find a non-CDC CTE.
        # Build CTE name -> index map and CDC index set first.
        cte_name_to_idx: Dict[str, int] = {}
        for idx, cte_lines in enumerate(all_cte_lines):
            for line in cte_lines:
                stripped = line.strip()
                if stripped.endswith("AS ("):
                    cname = stripped[:-len("AS (")].strip().rstrip(",").strip()
                    if cname:
                        cte_name_to_idx[cname.lower()] = idx
                        break

        def _is_cdc_cte(name: str) -> bool:
            return cte_name_to_idx.get(name.lower(), -1) in cdc_cte_indices

        primary_tgt = self._find_insert_target(main_targets)
        if primary_tgt:
            tgt_id = primary_tgt.get("id")
            visited_walk: Set[int] = set()
            queue = list(reverse_dag.get(tgt_id, []))
            found = False
            while queue and not found:
                uid = queue.pop(0)
                if uid in visited_walk:
                    continue
                visited_walk.add(uid)
                if uid in cte_registry:
                    cte_candidate = cte_registry[uid]
                    if not _is_cdc_cte(cte_candidate):
                        last_cte = cte_candidate
                        found = True
                        break
                if not found:
                    for (rid, gid), rcte in router_group_ctes.items():
                        if rid == uid and not _is_cdc_cte(rcte):
                            last_cte = rcte
                            found = True
                            break
                if found:
                    break
                queue.extend(reverse_dag.get(uid, []))

        # Fallback: if last_cte is still in CDC block, find the correct
        # business CTE. Prefer the success route CTE if it exists.
        business_cte_names = []
        for _, cte_lines in business_ctes:
            for line in cte_lines:
                stripped = line.strip()
                if stripped.endswith("AS ("):
                    cname = stripped[:-len("AS (")].strip().rstrip(",").strip()
                    if cname:
                        business_cte_names.append(cname)
                    break

        if last_cte and (_is_cdc_cte(last_cte) or last_cte.lower() not in [c.lower() for c in business_cte_names]):
            success_cte = None
            for cname in reversed(business_cte_names):
                if any(kw in cname.lower() for kw in ('lnksuccess', 'lnkins', 'inksuccess', 'activerec')):
                    success_cte = cname
                    break
            if success_cte:
                last_cte = success_cte
            elif business_cte_names:
                last_cte = business_cte_names[-1]

        # Record the columns produced by this intermediate so downstream
        # generators (snapshot, mart) can inspect them.
        if last_cte and cte_columns.get(last_cte):
            safe_mapping = safe_name(mapping.get("mapping_name", ""))
            self._intermediate_columns[safe_mapping] = {
                c.lower() for c in cte_columns[last_cte]
            }

        return last_cte

    def _append_window_over(self, translated: str, window_spec: Dict) -> str:
        """Append OVER() clause to window functions in translated expression."""
        partition_keys = window_spec.get("partition_keys", [])
        order_keys = window_spec.get("order_keys", [])

        over_parts: List[str] = []
        if partition_keys:
            over_parts.append(f"PARTITION BY {', '.join(partition_keys)}")
        if order_keys:
            order_strs = []
            for ok in order_keys:
                direction = "ASC" if ok.get("ascending", True) else "DESC"
                order_strs.append(f"{ok.get('field_name', '')} {direction}")
            over_parts.append(f"ORDER BY {', '.join(order_strs)}")
        over_clause = f"OVER({' '.join(over_parts)})"

        # Append to window functions that don't already have OVER
        for wf in WINDOW_FUNCTIONS:
            pattern = re.compile(
                r'\b' + re.escape(wf) + r'\s*\([^)]*\)(?!\s*OVER)', re.IGNORECASE
            )
            translated = pattern.sub(lambda m: f"{m.group(0)} {over_clause}", translated)
        return translated

    def _build_normalizer_cte(
        self, norm: Dict, input_cte: str
    ) -> Tuple[str, List[str]]:
        """Build normalizer CTE."""
        sname = safe_name(norm.get("name", "normalizer"))
        cte_name = f"{sname}_normalized"
        normalized = norm.get("normalized_fields", [])
        pass_through = norm.get("pass_through_fields", [])

        lines: List[str] = []
        if not normalized:
            lines.append(f"{cte_name} AS (")
            lines.append(f"    SELECT * FROM {input_cte}")
            lines.append(")")
            return cte_name, lines

        lines.append(f"{cte_name} AS (")
        lines.append("    SELECT")
        select_items = []
        for pt in pass_through:
            select_items.append(f"        {pt}")
        for nf in normalized:
            fname = nf.get("name", "")
            select_items.append(f"        {fname}_value AS {fname}")
        select_items.append("        occurrence_index AS GCID")
        for i, item in enumerate(select_items):
            comma = "," if i < len(select_items) - 1 else ""
            lines.append(f"{item}{comma}")
        lines.append(f"    FROM {input_cte}")
        for nf in normalized:
            fname = nf.get("name", "")
            occurs = nf.get("occurs", 2)
            in_cols = ", ".join(f"{fname}_{i+1}" for i in range(occurs))
            lines.append(f"    UNPIVOT ({fname}_value FOR occurrence_index IN ({in_cols}))")
        lines.append(")")
        return cte_name, lines

    def _build_aggregator_cte(
        self, agg: Dict, input_cte: str, mapping_name: str,
        upstream_cols: List[str] = None,
    ) -> Tuple[str, List[str]]:
        """Build aggregator CTE.

        Universal walk:
        1. All incoming columns (post CR + FR from upstream) go into SELECT
        2. Aggregate output fields (SUM, COUNT, etc.) added to SELECT
        3. GROUP BY uses exactly the columns from IDMC's groupByFieldsList
        """
        sname = safe_name(agg.get("name", "aggregator"))
        cte_name = f"{sname}_agg"
        group_by = agg.get("group_by_fields", [])
        fields = agg.get("fields", [])

        lines: List[str] = []
        lines.append(f"{cte_name} AS (")
        lines.append("    SELECT")

        select_items: List[str] = []
        emitted: Set[str] = set()

        # 1. All incoming columns from upstream (post CR + FR)
        if upstream_cols:
            for col in upstream_cols:
                select_items.append(f"        {col}")
                emitted.add(col.lower())

        # 2. Aggregate output fields
        for f in fields:
            fname = f.get("name", "")
            expr = f.get("expression", "")
            if expr:
                translated = self.translator.translate(expr, mapping_name)
                select_items.append(f"        {_cast_null(translated)} AS {fname}")
            elif fname and fname.lower() not in emitted:
                select_items.append(f"        {fname}")
            if fname:
                emitted.add(fname.lower())

        for i, item in enumerate(select_items):
            comma = "," if i < len(select_items) - 1 else ""
            lines.append(f"{item}{comma}")
        lines.append(f"    FROM {input_cte}")
        if group_by:
            lines.append(f"    GROUP BY {', '.join(group_by)}")
        lines.append(")")
        return cte_name, lines

    def _build_rank_cte(
        self, rank: Dict, input_cte: str
    ) -> Tuple[str, List[str]]:
        """Build rank CTE."""
        sname = safe_name(rank.get("name", "rank"))
        cte_name = f"{sname}_ranked"
        group_by = rank.get("group_by_fields", [])
        order_field = rank.get("order_by_field", "")
        num_ranks = rank.get("num_ranks", 1)
        top_bottom = rank.get("top_bottom", "Top")
        rank_port = rank.get("rank_port", "RANKINDEX")

        direction = "DESC" if top_bottom == "Top" else "ASC"
        partition_clause = f"PARTITION BY {', '.join(group_by)}" if group_by else ""
        order_clause = f"ORDER BY {order_field} {direction}" if order_field else "ORDER BY 1"

        lines: List[str] = []
        lines.append(f"{cte_name} AS (")
        lines.append("    SELECT")
        lines.append("        *,")
        lines.append(f"        ROW_NUMBER() OVER (")
        if partition_clause:
            lines.append(f"            {partition_clause}")
        lines.append(f"            {order_clause}")
        lines.append(f"        ) AS {rank_port}")
        lines.append(f"    FROM {input_cte}")
        lines.append(f"    QUALIFY {rank_port} <= {num_ranks}")
        lines.append(")")
        return cte_name, lines

    def _build_filter_cte(
        self, fil: Dict, input_cte: str, mapping_name: str
    ) -> Tuple[str, List[str]]:
        """Build filter CTE."""
        sname = safe_name(fil.get("name", "filter"))
        cte_name = f"{sname}_filtered"
        condition = fil.get("condition", "1=1")
        translated = self.translator.translate(condition, mapping_name)

        lines: List[str] = []
        lines.append(f"{cte_name} AS (")
        lines.append("    SELECT *")
        lines.append(f"    FROM {input_cte}")
        lines.append(f"    WHERE {translated}")
        lines.append(")")
        return cte_name, lines

    # ------------------------------------------------------------------
    # Router condition collection
    # ------------------------------------------------------------------

    def _collect_router_conditions(
        self, mapping: Dict, main_targets: List[Dict]
    ) -> str:
        """Combine router filter conditions from all main targets with OR."""
        conditions: List[str] = []
        seen: Set[str] = set()
        for tgt in main_targets:
            cond = self._find_target_filter_condition(tgt, mapping)
            if cond and cond not in seen:
                seen.add(cond)
                conditions.append(f"({cond})")

        if not conditions:
            return ""
        if len(conditions) == 1:
            return conditions[0]
        return " OR ".join(conditions)

    def _find_target_filter_condition(
        self, target: Dict, mapping: Dict
    ) -> str:
        """BFS backward from target to find nearest Router condition."""
        reverse_dag = mapping.get("reverse_dag", {})
        tx_by_id = mapping.get("tx_by_id", {})
        router_group_map = mapping.get("router_group_map", {})
        link_from_group_map = mapping.get("link_from_group_map", {})

        target_id = target.get("id")
        if target_id is None:
            return ""

        visited: Set[int] = set()
        queue = deque([target_id])
        while queue:
            nid = queue.popleft()
            if nid in visited:
                continue
            visited.add(nid)
            tx = tx_by_id.get(nid, {})
            if tx.get("type") == "Router":
                # Find which group connects to the target path
                group_id = link_from_group_map.get((nid, target_id))
                if group_id is None:
                    # Try all visited nodes to find the link
                    for v in visited:
                        gid = link_from_group_map.get((nid, v))
                        if gid is not None:
                            group_id = gid
                            break
                if group_id is not None and group_id in router_group_map:
                    _, group_name = router_group_map[group_id]
                    # Find the condition for this group
                    raw = tx.get("raw", {})
                    for gfc in raw.get("groupFilterConditions", []):
                        if gfc.get("name", "") == group_name or gfc.get("$$ID") == group_id:
                            cond = gfc.get("advancedFilterCondition", "")
                            if cond:
                                return self.translator.translate(
                                    cond, mapping.get("mapping_name", "")
                                )
                # Fallback: return first non-empty condition
                raw = tx.get("raw", {})
                for gfc in raw.get("groupFilterConditions", []):
                    cond = gfc.get("advancedFilterCondition", "")
                    if cond:
                        return self.translator.translate(
                            cond, mapping.get("mapping_name", "")
                        )
            for pred in reverse_dag.get(nid, []):
                if pred not in visited:
                    queue.append(pred)
        return ""

    # ------------------------------------------------------------------
    # Snapshot SQL generation
    # ------------------------------------------------------------------

    def _generate_snapshot_sql(self, mapping: Dict, target: Dict, target_table: str) -> None:
        """Generate snapshot SQL for CDC mappings. Skipped for SCD Type 1."""
        if IDMCParser._detect_scd_subtype(mapping) == "SCD_TYPE1":
            self.logger.info(f"Skipping snapshot for SCD Type 1 mapping: {mapping.get('mapping_name', '')}")
            return
        mapping_name = mapping.get("mapping_name", "")
        safe_mapping = safe_name(mapping_name)
        snap_dir = self.output_dir / "snapshots"
        snap_dir.mkdir(parents=True, exist_ok=True)
        filename = f"snapshot_{target_table}.sql"

        target_schema = self._get_target_schema(mapping)
        nk_cols = self._get_natural_key_cols(target, mapping)
        biz_cols = self._get_business_cols(target, nk_cols)

        # Build column lists for macros
        nk_list = ", ".join(nk_cols)
        nk_list_quoted = ", ".join(f"'{nk}'" for nk in nk_cols)
        biz_list_quoted = ", ".join(f"'{bc}'" for bc in biz_cols[:50])

        lines: List[str] = []
        # Detect SCD subtype and add TODO for Type 1 mappings
        scd_subtype = IDMCParser._detect_scd_subtype(mapping)
        if scd_subtype == "SCD_TYPE1":
            lines.append(f"-- TODO: This mapping ({mapping_name}) is SCD Type 1 (upsert/overwrite).")
            lines.append("-- Updates overwrite existing rows in place — no history is tracked.")
            lines.append("-- Consider converting this snapshot to an incremental model with MERGE strategy.")
            lines.append("-- The snapshot still works correctly but tracks unnecessary history.")
            lines.append("")
        lines.append(f"{{% snapshot snapshot_{target_table} %}}")
        lines.append("")
        lines.append("    {{")
        lines.append("        config(")
        lines.append(f"          target_schema='{target_schema}',")
        lines.append("          unique_key='snapshot_key',")
        lines.append("          strategy='check',")
        lines.append("          check_cols=['chksum'],")
        lines.append("          invalidate_hard_deletes=True,")
        lines.append("        )")
        lines.append("    }}")
        lines.append("")
        lines.append(f"-- TODO: Verify natural key columns are correct for this snapshot")
        lines.append(f"-- nk_cols={nk_cols}")
        lines.append(f"-- non_nk_cols={biz_cols}")
        # Flag NK columns that don't match any target field name
        target_field_names = {f.get("name", "").lower() for f in target.get("fields", [])}
        for nk in nk_cols:
            if nk.lower() not in target_field_names:
                lines.append(f"-- TODO: NK column '{nk}' not found in target fields — may be a pipeline-renamed column. Verify against intermediate output.")
        lines.append("")
        # If the intermediate already produces a column named 'chksum' (from
        # source data or a dual-purpose IDMC transformation), use EXCEPT to
        # drop it before the snapshot recomputes its own.
        int_cols = self._intermediate_columns.get(safe_mapping, set())
        has_chksum = "chksum" in int_cols
        lines.append("SELECT")
        lines.append(f"    {{{{ generate_sk('{target_table}_sk') }}}} AS {target_table}_sk,")

        if has_chksum:
            lines.append("    * EXCEPT (chksum),")
        else:
            lines.append("    *,")
        lines.append(f"    ({{{{ generate_snapshot_key([{nk_list_quoted}]) }}}}) AS snapshot_key,")
        lines.append(f"    {{{{ generate_chksum([{biz_list_quoted}]) }}}} AS chksum,")
        lines.append("    cast(current_timestamp() AS timestamp) AS edh_record_start_ts,")
        lines.append("    cast('9999-12-31 00:00:00' AS timestamp) AS edh_record_end_ts,")
        lines.append("    cast(date_format(current_timestamp(), 'yyyyMMddHHmmss') AS bigint) AS edh_created_batch_key,")
        lines.append("    cast(current_timestamp() AS timestamp) AS edh_created_ts,")
        lines.append("    cast('edm_dbt_csx_run' AS string) AS edh_created_nm")
        lines.append(f"FROM {{{{ ref('int_{safe_mapping}') }}}}")
        lines.append("")
        lines.append(f"{{% endsnapshot %}}")

        content = "\n".join(lines) + "\n"
        (snap_dir / filename).write_text(content, encoding="utf-8")
        self.logger.info(f"Snapshot: {filename}")

    # ------------------------------------------------------------------
    # CDC Marts generation
    # ------------------------------------------------------------------

    def _generate_marts_sql(self, mapping: Dict, target: Dict, target_table: str) -> None:
        """Generate CDC marts SQL."""
        mapping_name = mapping.get("mapping_name", "")
        marts_dir = self.output_dir / "models" / "marts"
        marts_dir.mkdir(parents=True, exist_ok=True)
        filename = f"{target_table}.sql"

        nk_cols = self._get_natural_key_cols(target, mapping)
        biz_cols = self._get_business_cols(target, nk_cols)

        nk_partition = ", ".join(nk_cols) if nk_cols else "1"

        lines: List[str] = []
        lines.append("-- TODO: Validate field mapping between intermediate and mart columns")
        lines.append("")
        lines.append("{{ config(materialized='table') }}")
        lines.append("")
        lines.append(f"WITH {target_table} AS (")
        lines.append("    SELECT")
        lines.append("        *,")
        lines.append("        coalesce(")
        lines.append(f"            lead(dbt_valid_from) OVER (")
        lines.append(f"                -- TODO: Verify natural key columns used in PARTITION BY")
        lines.append(f"                PARTITION BY {nk_partition}")
        lines.append("                ORDER BY dbt_valid_from, dbt_valid_to DESC")
        lines.append("            ),")
        lines.append("            cast('1900-01-01' AS timestamp)")
        lines.append("        ) AS next_valid_from")
        lines.append(f"    FROM {{{{ ref('snapshot_{target_table}') }}}}")
        lines.append(")")
        lines.append("")
        lines.append("SELECT")

        # Emit exactly the columns from the target field list.
        # EDH columns get special Type 2 derivation from dbt_valid_from/dbt_valid_to.
        # Non-EDH columns get CAST from the snapshot CTE.
        target_fields = target.get("fields", [])

        # Type 2 EDH derivation expressions (from snapshot metadata)
        edh_type2_exprs = {
            "edh_record_status_in": (
                "CASE\n"
                "        WHEN dbt_valid_to IS NULL THEN cast('A' AS string)\n"
                "        WHEN dbt_valid_to IS NOT NULL AND next_valid_from <> dbt_valid_to THEN cast('D' AS string)\n"
                "        ELSE cast('I' AS string)\n"
                "    END"
            ),
            "edh_record_start_ts": "cast(dbt_valid_from AS timestamp)",
            "edh_record_end_ts": (
                "CASE\n"
                "        WHEN dbt_valid_to IS NULL THEN cast('9999-12-31' AS timestamp)\n"
                "        ELSE cast(dbt_valid_to AS timestamp)\n"
                "    END"
            ),
            "edh_created_batch_key": "cast(edh_created_batch_key AS bigint)",
            "edh_created_ts": "cast(edh_created_ts AS timestamp)",
            "edh_created_nm": "cast(edh_created_nm AS string)",
            "edh_updated_batch_key": (
                "CASE\n"
                "        WHEN dbt_valid_to IS NOT NULL THEN cast(date_format(dbt_valid_to, 'yyyyMMddHHmmss') AS bigint)\n"
                "        ELSE cast(NULL AS bigint)\n"
                "    END"
            ),
            "edh_updated_ts": (
                "CASE\n"
                "        WHEN dbt_valid_to IS NOT NULL THEN cast(dbt_valid_to AS timestamp)\n"
                "        ELSE cast(NULL AS timestamp)\n"
                "    END"
            ),
            "edh_updated_nm": (
                "CASE\n"
                "        WHEN dbt_valid_to IS NOT NULL THEN cast('edm_dbt_csx_run' AS string)\n"
                "        ELSE cast(NULL AS string)\n"
                "    END"
            ),
        }

        total_cols = len(target_fields)
        col_idx = 0
        for f in target_fields:
            fname = f.get("name", "")
            cast_type = self._build_cast_type(f)
            col_idx += 1
            comma = "," if col_idx < total_cols else ""

            if fname.lower() in edh_type2_exprs:
                # EDH column — use Type 2 derivation
                lines.append(f"    {edh_type2_exprs[fname.lower()]} AS {fname}{comma}")
            else:
                # Business column — CAST from snapshot CTE
                lines.append(f"    cast({fname} AS {cast_type}) AS {fname}{comma}")

        lines.append("")
        lines.append(f"FROM {target_table}")

        content = "\n".join(lines) + "\n"
        (marts_dir / filename).write_text(content, encoding="utf-8")
        self.logger.info(f"CDC Marts: {filename}")

        # Schema entry
        self.all_mart_models.append({
            "name": target_table,
            "description": f"Marts model for {mapping_name}",
            "columns": [{"name": c, "description": ""} for c in (biz_cols + ["chksum"])[:30]],
        })

    # ------------------------------------------------------------------
    # SCD Type 1 Marts generation (incremental MERGE)
    # ------------------------------------------------------------------

    def _generate_marts_sql_type1(self, mapping: Dict, target: Dict, target_table: str) -> None:
        """Generate SCD Type 1 marts SQL — incremental with MERGE strategy."""
        mapping_name = mapping.get("mapping_name", "")
        safe_mapping = safe_name(mapping_name)
        marts_dir = self.output_dir / "models" / "marts"
        marts_dir.mkdir(parents=True, exist_ok=True)
        filename = f"{target_table}.sql"

        nk_cols = self._get_natural_key_cols(target, mapping)
        biz_cols = self._get_business_cols(target, nk_cols)

        # Build merge_update_columns: business cols + updated audit cols
        # NOTE: _sk (surrogate key) columns are excluded by default.
        # Type 1 has no edh_record_status_in — rows are upserted in-place.
        merge_update_cols = list(biz_cols) + [
            "edh_updated_batch_key", "edh_updated_ts", "edh_updated_nm",
        ]
        merge_update_str = ", ".join(f"'{c}'" for c in merge_update_cols)
        nk_str = ", ".join(f"'{nk}'" for nk in nk_cols)

        lines: List[str] = []
        lines.append("-- TODO: Validate field mapping between intermediate and mart columns")
        lines.append("")
        lines.append("{{")
        lines.append("  config(")
        lines.append("    materialized='incremental',")
        lines.append("    incremental_strategy='merge',")
        lines.append(f"    -- TODO: Verify natural key columns are correct for this incremental MERGE")
        lines.append(f"    unique_key=[{nk_str}],")
        lines.append(f"    -- TODO: Verify merge_update_columns — _sk columns excluded by default; add if dimension SKs can change")
        lines.append(f"    merge_update_columns=[{merge_update_str}],")
        lines.append("  )")
        lines.append("}}")
        lines.append("")

        # CAST every target column from the intermediate.
        # Emit exactly what the target declares — the intermediate's final SELECT
        # must produce columns matching these names (via manual field mapping).
        target_fields = target.get("fields", [])

        total_cols = len(target_fields)
        col_idx = 0

        lines.append("SELECT")
        for f in target_fields:
            fname = f.get("name", "")
            cast_type = self._build_cast_type(f)
            col_idx += 1
            comma = "," if col_idx < total_cols else ""
            lines.append(f"    cast({fname} AS {cast_type}) AS {fname}{comma}")

        lines.append(f"FROM {{{{ ref('int_{safe_mapping}') }}}}")

        content = "\n".join(lines) + "\n"
        (marts_dir / filename).write_text(content, encoding="utf-8")
        self.logger.info(f"SCD Type 1 Marts (incremental MERGE): {filename}")

        # Schema entry
        self.all_mart_models.append({
            "name": target_table,
            "description": f"Marts model for {mapping_name} (SCD Type 1 — incremental MERGE)",
            "columns": [{"name": c, "description": ""} for c in biz_cols[:30]],
        })

    # ------------------------------------------------------------------
    # FULL Marts generation
    # ------------------------------------------------------------------

    def _generate_marts_sql_full(self, mapping: Dict, target: Dict, target_table: str) -> None:
        """Generate FULL marts SQL.

        All target columns (business + EDH) are passed through from the
        intermediate, which already computes EDH columns from the IDMC
        Expression transformation.  No generic/hardcoded EDH template.
        """
        mapping_name = mapping.get("mapping_name", "")
        safe_mapping = safe_name(mapping_name)
        marts_dir = self.output_dir / "models" / "marts"
        marts_dir.mkdir(parents=True, exist_ok=True)
        filename = f"{target_table}.sql"

        lines: List[str] = []
        lines.append("-- TODO: Validate field mapping between intermediate and mart columns")
        lines.append("")
        lines.append("{{ config(materialized='table') }}")
        lines.append("")
        lines.append("SELECT")

        # CAST every target column from the intermediate.
        # Emit exactly what the target declares — the intermediate's final SELECT
        # must produce columns matching these names (via manual field mapping).
        target_fields = target.get("fields", [])

        total_cols = len(target_fields)
        col_idx = 0
        for f in target_fields:
            fname = f.get("name", "")
            cast_type = self._build_cast_type(f)
            col_idx += 1
            comma = "," if col_idx < total_cols else ""
            lines.append(f"    cast({fname} AS {cast_type}) AS {fname}{comma}")

        lines.append(f"FROM {{{{ ref('int_{safe_mapping}') }}}}")

        content = "\n".join(lines) + "\n"
        (marts_dir / filename).write_text(content, encoding="utf-8")
        self.logger.info(f"FULL Marts: {filename}")

        self.all_mart_models.append({
            "name": target_table,
            "description": f"Marts model for {mapping_name} (FULL)",
            "columns": [
                {"name": f.get("name", ""), "description": f"Type: {f.get('type', 'STRING')}"}
                for f in target_fields[:30]
            ],
        })

    # ------------------------------------------------------------------
    # Pipeline reachability
    # ------------------------------------------------------------------

    def _reaches_main_pipeline(
        self, node_id: int, mapping: Dict, main_target_ids: Set[int]
    ) -> bool:
        """BFS forward to check if node reaches a main (non-OPS) target."""
        if node_id is None:
            return False
        dag = mapping.get("dag", {})
        visited: Set[int] = set()
        queue = deque([node_id])
        while queue:
            nid = queue.popleft()
            if nid in visited:
                continue
            visited.add(nid)
            if nid in main_target_ids:
                return True
            for succ in dag.get(nid, []):
                if succ not in visited:
                    queue.append(succ)
        return False

    def _get_natural_key_cols(self, target: Dict, mapping: Dict) -> List[str]:
        """Get natural key columns from target, preferring CDC join/lookup conditions."""
        # CDC: extract NKs from CDC infrastructure first
        if mapping.get("load_type") == "CDC":
            nk = self._extract_cdc_nk_cols(target, mapping)
            if nk:
                return nk

        # Fallback: updateColumns (filter out surrogate keys)
        uc = target.get("update_columns", [])
        uc = [c for c in uc if c and not c.lower().endswith("_sk")]
        if uc:
            return uc
        for mm in target.get("manual_mappings", []):
            if isinstance(mm, dict) and mm.get("isKey", mm.get("key", False)):
                fname = mm.get("fieldName", mm.get("name", ""))
                if fname:
                    uc.append(fname)
        if uc:
            return uc
        nk_fields = [
            f.get("name", "") for f in target.get("fields", [])
            if f.get("name", "").lower().endswith("_nk")
        ]
        return nk_fields if nk_fields else [target.get("fields", [{}])[0].get("name", "id") if target.get("fields") else "id"]

    def _extract_cdc_nk_cols(self, target: Dict, mapping: Dict) -> List[str]:
        """Extract NK columns from CDC lookup conditions or FOJ join conditions."""
        target_table = target.get("object_name", "").split("/")[-1].lower()

        # 1. CDC lookup whose object_name or name matches the target table
        for lkp in mapping.get("lookups", []):
            lkp_obj = lkp.get("object_name", "").split("/")[-1].lower()
            lkp_name = lkp.get("name", "").lower()
            if (lkp_obj and (lkp_obj == target_table or target_table in lkp_obj)) or \
               (target_table and target_table in lkp_name):
                conditions = lkp.get("lookup_conditions", [])
                if conditions:
                    nk_cols = [c["left"] for c in conditions if c.get("left")]
                    if nk_cols:
                        return nk_cols

        # 2. Full Outer Join conditions
        for joiner in mapping.get("joiners", []):
            if "full" in joiner.get("join_type", "").lower():
                conditions = joiner.get("join_conditions", [])
                nk_cols = []
                for c in conditions:
                    left = c.get("left", "")
                    if left:
                        resolved = self._resolve_composite_nk(left, mapping)
                        nk_cols.extend(resolved)
                if nk_cols:
                    return nk_cols

        return []

    def _resolve_composite_nk(self, col_name: str, mapping: Dict) -> List[str]:
        """If col_name is a composite key built via concatenation, extract components."""
        for expr in mapping.get("expressions", []):
            for f in expr.get("fields", []):
                if f.get("name", "") == col_name:
                    expression = f.get("expression", "")
                    if "||" in expression and not re.match(r'\s*MD5\s*\(', expression, re.IGNORECASE):
                        # Split on || to get each IIF(...) segment
                        segments = expression.split("||")
                        seen: Set[str] = set()
                        result: List[str] = []
                        for seg in segments:
                            # Extract the innermost column name from patterns like:
                            # IIf(ISNull(LTRim(RTrim(col))),'',col)
                            # IIf(IsNull(LTRim(RTrim(to_char(col)))),'',to_char(col))
                            # Find all word tokens that aren't functions/keywords
                            tokens = re.findall(r'\b(\w+)\b', seg)
                            skip = {"iif", "isnull", "ltrim", "rtrim", "to_char",
                                    "trim", "lpad", "rpad", "upper", "lower", ""}
                            for t in tokens:
                                tl = t.lower()
                                if tl not in skip and tl not in seen and not t.isdigit():
                                    seen.add(tl)
                                    result.append(t)
                                    break  # one column per segment
                        if result:
                            return result
        return [col_name]

    def _get_business_cols(self, target: Dict, nk_cols: List[str]) -> List[str]:
        """Get business columns for chksum (exclude NKs, EDH, snapshot meta)."""
        nk_lower = {c.lower() for c in nk_cols}
        exclude = EDH_EXCLUDE_COLUMNS | {"snapshot_key", "chksum"} | nk_lower
        exclude.update(c for c in nk_lower)
        biz = []
        for f in target.get("fields", []):
            fname = f.get("name", "")
            if fname.lower() not in exclude and not fname.lower().endswith("_sk"):
                biz.append(fname)
        return biz

    @staticmethod
    def _build_cast_type(field: Dict) -> str:
        """Build a Databricks SQL type string from a target field definition.

        Includes precision/scale for DECIMAL types.
        Examples: STRING, BIGINT, DECIMAL(28,0), TIMESTAMP.
        """
        ftype = field.get("type", "STRING").upper()
        precision = field.get("precision", "")
        scale = field.get("scale", "")
        if ftype == "DECIMAL" and precision:
            return f"DECIMAL({precision},{scale or 0})"
        return ftype

    @staticmethod
    def _map_join_type(idmc_join_type: str) -> str:
        """Map IDMC join type to SQL JOIN keyword."""
        jt = idmc_join_type.lower()
        if "full outer" in jt:
            return "FULL OUTER JOIN"
        # IDMC: Detail = driving side, Master = lookup/cached side.
        # Our FROM layout: master_cte m {JOIN} detail_cte d
        # Master Outer = keep all detail rows (detail drives) → RIGHT JOIN
        # Detail Outer = keep all master rows (master drives) → LEFT JOIN
        if "master outer" in jt:
            return "RIGHT JOIN"
        if "detail outer" in jt:
            return "LEFT JOIN"
        if "outer" in jt:
            return "LEFT JOIN"
        return "INNER JOIN"


# ===================================================================
# ConversionPlanGenerator
# ===================================================================

class ConversionPlanGenerator:
    """Generates conversion plans and transformation flow documents.

    Plans serve as documentation and a pre-generation analysis step,
    forcing the generator to fully resolve the mapping's structure
    before emitting SQL.
    """

    def __init__(self, parsed_results: Dict[str, Any]) -> None:
        self.parsed = parsed_results
        self.logger = setup_logging("ConversionPlanGenerator")

    def generate_plans(self) -> None:
        """Iterate all parsed mappings and generate plans for each."""
        if not self.parsed:
            self.logger.warning("No parsed data for plan generation")
            return

        for mapping_key, mapping in self.parsed.items():
            self.logger.info(f"Generating plans for: {mapping.get('mapping_name', mapping_key)}")
            self.generate_conversion_plan(mapping)
            self.generate_transformation_flow(mapping)

    def generate_conversion_plan(self, mapping: Dict) -> Path:
        """Generate a structured conversion plan document.

        Args:
            mapping: Parsed mapping dict.

        Returns:
            Path to the generated conversion plan markdown file.
        """
        mapping_name = mapping.get("mapping_name", "unknown")
        safe_mapping = safe_name(mapping_name)
        plans_dir = get_project_root() / "plans"
        plans_dir.mkdir(parents=True, exist_ok=True)
        output_path = plans_dir / f"{safe_mapping}_conversion_plan.md"

        lines: List[str] = []

        # Section 1: Mapping Overview
        lines.append(f"# Conversion Plan: {mapping_name}")
        lines.append("")
        lines.append("## 1. Mapping Overview")
        lines.append("")
        lines.append(f"- **Mapping Name**: {mapping_name}")
        lines.append(f"- **Description**: {mapping.get('description', 'N/A')}")
        load_type = mapping.get('load_type', 'UNKNOWN')
        scd_sub = IDMCParser._detect_scd_subtype(mapping)
        if scd_sub:
            load_type = f"{load_type} ({scd_sub.replace('_', ' ')})"
        lines.append(f"- **Load Type**: {load_type}")
        lines.append(f"- **Sources**: {len(mapping.get('sources', []))}")
        lines.append(f"- **Targets**: {len(mapping.get('targets', []))}")
        lines.append(f"- **Expressions**: {len(mapping.get('expressions', []))}")
        lines.append(f"- **Joiners**: {len(mapping.get('joiners', []))}")
        lines.append(f"- **Filters**: {len(mapping.get('filters', []))}")
        lines.append(f"- **Lookups**: {len(mapping.get('lookups', []))}")
        lines.append(f"- **Routers**: {len(mapping.get('routers', []))}")
        lines.append(f"- **Unions**: {len(mapping.get('unions', []))}")
        lines.append(f"- **Aggregators**: {len(mapping.get('aggregators', []))}")
        lines.append(f"- **Sorters**: {len(mapping.get('sorters', []))}")
        lines.append(f"- **Normalizers**: {len(mapping.get('normalizers', []))}")
        lines.append(f"- **Ranks**: {len(mapping.get('ranks', []))}")
        lines.append("")

        # Section 2: Source Inventory
        lines.append("## 2. Source Inventory")
        lines.append("")
        lines.append("| Source Name | Table Name | Has CQ | Column Count |")
        lines.append("|---|---|---|---|")
        for src in mapping.get("sources", []):
            cq = "Yes" if src.get("custom_query") else "No"
            cols = len(src.get("fields", []))
            lines.append(f"| {src.get('name', '')} | {src.get('object_name', '')} | {cq} | {cols} |")
        lines.append("")

        # Section 3: Target Analysis
        lines.append("## 3. Target Analysis")
        lines.append("")
        lines.append("| Target Name | Table Name | Type | Column Count |")
        lines.append("|---|---|---|---|")
        for tgt in mapping.get("targets", []):
            ttype = "OPS" if "_OPS_" in tgt.get("name", "").upper() else "Main"
            cols = len(tgt.get("fields", []))
            lines.append(f"| {tgt.get('name', '')} | {tgt.get('object_name', '')} | {ttype} | {cols} |")
        lines.append("")

        # Section 4: Transformation Chain
        lines.append("## 4. Transformation Chain")
        lines.append("")
        dag = mapping.get("dag", {})
        tx_by_id = mapping.get("tx_by_id", {})
        for tx_id, entry in tx_by_id.items():
            downstream = dag.get(tx_id, [])
            ds_names = [tx_by_id.get(d, {}).get("name", str(d)) for d in downstream]
            lines.append(f"- **{entry.get('name', '')}** ({entry.get('type', '')}) -> {', '.join(ds_names) if ds_names else 'END'}")
        lines.append("")

        # Section 5: Transformation Flow Diagram
        lines.append("## 5. Transformation Flow Diagram")
        lines.append("")
        lines.append("```")
        flow_lines = self._build_ascii_flow(mapping)
        lines.extend(flow_lines)
        lines.append("```")
        lines.append("")

        # Section 6: Union Analysis
        unions = mapping.get("unions", [])
        if unions:
            lines.append("## 6. Union Analysis")
            lines.append("")
            for u in unions:
                lines.append(f"- **{u.get('name', '')}**: {len(u.get('input_groups', []))} input branches")
            lines.append("")

        # Section 7: Proposed CTE Structure
        lines.append("## 7. Proposed CTE Structure")
        lines.append("")
        if unions:
            lines.append("**Path**: Union path")
            lines.append("- Branch CTEs (one per union input)")
            lines.append("- `unioned` (UNION ALL)")
            lines.append(f"- `{safe_mapping}_base` (post-union expressions + JOINs)")
        else:
            lines.append("**Path**: Flat path")
            lines.append(f"- `{safe_mapping}_base` (source JOINs + expressions)")

        # Chained CTEs
        for norm in mapping.get("normalizers", []):
            lines.append(f"- `{safe_name(norm.get('name', ''))}_normalized`")
        for agg in mapping.get("aggregators", []):
            lines.append(f"- `{safe_name(agg.get('name', ''))}_agg`")
        for rank in mapping.get("ranks", []):
            lines.append(f"- `{safe_name(rank.get('name', ''))}_ranked`")
        for fil in mapping.get("filters", []):
            lines.append(f"- `{safe_name(fil.get('name', ''))}_filtered`")
        lines.append("- Final SELECT")
        lines.append("")

        # Section 8: Snapshot & Mart Summary
        lines.append("## 8. Snapshot & Mart Summary")
        lines.append("")
        load_type = mapping.get("load_type", "FULL")
        lines.append(f"- **Load type**: {load_type}")
        if load_type == "CDC":
            lines.append(f"- **Snapshot**: `snapshot_{safe_mapping}.sql`")
            lines.append(f"- **Marts**: `{safe_mapping}.sql` (CDC)")
        else:
            lines.append("- **Snapshot**: Not generated (FULL load)")
            lines.append(f"- **Marts**: `{safe_mapping}.sql` (FULL)")
        lines.append("")

        # Section 9: Expected Output Files
        lines.append("## 9. Expected Output Files")
        lines.append("")
        lines.append("```")
        lines.append(f"models/intermediate/int_{safe_mapping}.sql")
        if load_type == "CDC":
            lines.append(f"snapshots/snapshot_{safe_mapping}.sql")
        lines.append(f"models/marts/{safe_mapping}.sql")
        lines.append("```")

        content = "\n".join(lines) + "\n"
        output_path.write_text(content, encoding="utf-8")
        self.logger.info(f"Conversion plan: {output_path}")
        return output_path

    def generate_transformation_flow(self, mapping: Dict) -> Path:
        """Generate a visual DAG representation of the transformation flow.

        Args:
            mapping: Parsed mapping dict.

        Returns:
            Path to the generated transformation flow markdown file.
        """
        mapping_name = mapping.get("mapping_name", "unknown")
        safe_mapping = safe_name(mapping_name)
        thoughts_dir = get_project_root() / "thoughts"
        thoughts_dir.mkdir(parents=True, exist_ok=True)
        output_path = thoughts_dir / f"transformation_flow_{safe_mapping}.md"

        dag = mapping.get("dag", {})
        reverse_dag = mapping.get("reverse_dag", {})
        tx_by_id = mapping.get("tx_by_id", {})

        lines: List[str] = []
        lines.append(f"# Transformation Flow: {mapping_name}")
        lines.append("")
        lines.append("```")

        # Find sources (nodes with no predecessors)
        all_ids = set(tx_by_id.keys())
        has_preds = set()
        for node, preds in reverse_dag.items():
            if preds:
                has_preds.add(node)
        root_ids = all_ids - has_preds

        # Trace paths from each source
        visited_paths: Set[str] = set()
        for root_id in sorted(root_ids):
            paths = self._trace_paths(root_id, dag, tx_by_id)
            for path in paths:
                path_str = " --> ".join(
                    f"{tx_by_id.get(nid, {}).get('name', str(nid))} ({tx_by_id.get(nid, {}).get('type', '?')})"
                    for nid in path
                )
                if path_str not in visited_paths:
                    visited_paths.add(path_str)
                    lines.append(path_str)

        lines.append("```")
        lines.append("")

        content = "\n".join(lines) + "\n"
        output_path.write_text(content, encoding="utf-8")
        self.logger.info(f"Transformation flow: {output_path}")
        return output_path

    def _trace_paths(
        self, start_id: int, dag: Dict, tx_by_id: Dict
    ) -> List[List[int]]:
        """Trace all paths from start_id to leaf nodes."""
        paths: List[List[int]] = []
        stack: List[Tuple[int, List[int]]] = [(start_id, [start_id])]
        while stack:
            node, path = stack.pop()
            successors = dag.get(node, [])
            if not successors:
                paths.append(path)
            else:
                for succ in successors:
                    if succ not in path:  # Avoid cycles
                        stack.append((succ, path + [succ]))
        return paths

    def _build_ascii_flow(self, mapping: Dict) -> List[str]:
        """Build compact ASCII flow diagram of the IDMC transformation DAG.

        Strategy: walk the DAG from roots. Each node is rendered exactly once.
        - Fork nodes (>1 successor): rendered as ─┬──>/├──>/└──> blocks
        - Merge nodes (>1 predecessor): rendered as ─┐/─┼──>/─┘ blocks
        - Linear chains: rendered inline
        """
        dag = mapping.get("dag", {})
        reverse_dag = mapping.get("reverse_dag", {})
        tx_by_id = mapping.get("tx_by_id", {})
        if not tx_by_id:
            return ["(no transformations)"]

        def _name(nid: int) -> str:
            return tx_by_id.get(nid, {}).get("name", str(nid))

        all_ids = set(tx_by_id.keys())
        has_preds = {n for n, preds in reverse_dag.items() if preds}
        root_ids = sorted(all_ids - has_preds)

        # Topological layer (BFS)
        from collections import deque
        layer: Dict[int, int] = {}
        q: deque = deque()
        for rid in root_ids:
            layer[rid] = 0
            q.append(rid)
        while q:
            nid = q.popleft()
            for succ in dag.get(nid, []):
                nl = layer[nid] + 1
                if succ not in layer or layer[succ] < nl:
                    layer[succ] = nl
                    q.append(succ)

        def _is_merge(nid: int) -> bool:
            return len(reverse_dag.get(nid, [])) > 1

        def _is_fork(nid: int) -> bool:
            return len(dag.get(nid, [])) > 1

        def _follow_chain(start: int) -> List[int]:
            """Follow single-successor, non-merge chain."""
            chain = [start]
            cur = start
            while True:
                succs = dag.get(cur, [])
                if len(succs) != 1:
                    break
                nxt = succs[0]
                if _is_merge(nxt):
                    break
                chain.append(nxt)
                cur = nxt
            return chain

        def _chain_str(chain: List[int]) -> str:
            return " ──> ".join(_name(n) for n in chain)

        # ── Build blocks by walking from each root ──
        # Each block is an independent renderable unit.
        # We track rendered nodes to avoid duplication.
        rendered: Set[int] = set()
        blocks: List[Tuple[int, List[str]]] = []

        def _render_from(start: int) -> None:
            """Recursively render from start node."""
            if start in rendered:
                return
            # If start is a merge node, render its merge block
            if _is_merge(start):
                _render_merge(start)
                return
            # Follow chain from start
            chain = _follow_chain(start)
            for nid in chain:
                rendered.add(nid)
            last = chain[-1]
            succs = dag.get(last, [])

            if len(succs) == 0:
                # Leaf: just render the chain
                blocks.append((layer.get(start, 0), [_chain_str(chain)]))
            elif len(succs) == 1 and _is_merge(succs[0]):
                # Chain leads into a merge — trigger the merge rendering
                if succs[0] not in rendered:
                    _render_merge(succs[0])
            elif len(succs) > 1:
                # Fork at end of chain
                _render_fork(chain, succs)
            else:
                blocks.append((layer.get(start, 0), [_chain_str(chain)]))

        def _render_fork(prefix_chain: List[int], succs: List[int]) -> None:
            """Render a fork: prefix chain splitting into multiple branches."""
            prefix = _chain_str(prefix_chain)
            indent = " " * (len(prefix) + 2)
            fork_lines: List[str] = []
            for i, s in enumerate(succs):
                # Each successor: follow its chain
                if _is_merge(s):
                    branch_str = _name(s) + " ..."
                else:
                    branch_chain = _follow_chain(s)
                    for nid in branch_chain:
                        rendered.add(nid)
                    branch_str = _chain_str(branch_chain)
                    # If branch chain ends at a fork, note it for later
                    blast = branch_chain[-1]
                    bsuccs = dag.get(blast, [])
                    if len(bsuccs) > 1:
                        # Will be rendered separately
                        pass
                    elif len(bsuccs) == 1 and _is_merge(bsuccs[0]):
                        pass  # merge will pull it

                if i == 0:
                    fork_lines.append(f"{prefix} ─┬──> {branch_str}")
                elif i == len(succs) - 1:
                    fork_lines.append(f"{indent}└──> {branch_str}")
                else:
                    fork_lines.append(f"{indent}├──> {branch_str}")

            blocks.append((layer.get(prefix_chain[0], 0), fork_lines))

            # Recurse into fork branches that end at forks or lead to merges
            for s in succs:
                if _is_merge(s) and s not in rendered:
                    _render_merge(s)
                elif not _is_merge(s):
                    branch_chain = _follow_chain(s)
                    blast = branch_chain[-1]
                    bsuccs = dag.get(blast, [])
                    if len(bsuccs) > 1:
                        for nid in branch_chain:
                            rendered.add(nid)
                        _render_fork(branch_chain, bsuccs)
                    elif len(bsuccs) == 1 and _is_merge(bsuccs[0]) and bsuccs[0] not in rendered:
                        _render_merge(bsuccs[0])

        def _render_merge(merge_id: int) -> None:
            """Render a merge node with its feeder chains and continuation."""
            if merge_id in rendered:
                return
            rendered.add(merge_id)

            preds = reverse_dag.get(merge_id, [])
            feeder_strs: List[str] = []
            for pred_id in preds:
                # Trace back from pred to nearest boundary
                chain = []
                cur = pred_id
                while True:
                    chain.append(cur)
                    ps = reverse_dag.get(cur, [])
                    if len(ps) != 1:
                        break
                    prev = ps[0]
                    if _is_fork(prev) or _is_merge(prev):
                        chain.append(prev)
                        break
                    cur = prev  # move without appending; next iteration appends
                chain.reverse()
                feeder_strs.append(_chain_str(chain))

            # Continuation after merge
            post_chain = _follow_chain(merge_id)
            for nid in post_chain:
                rendered.add(nid)
            cont_str = _chain_str(post_chain)

            if not feeder_strs:
                return

            max_len = max(len(s) for s in feeder_strs)
            padded = [s.ljust(max_len) for s in feeder_strs]
            n = len(padded)
            mid = n // 2

            merge_lines: List[str] = []
            for i, fs in enumerate(padded):
                if n == 1:
                    merge_lines.append(f"{fs} ──> {cont_str}")
                elif n == 2:
                    if i == 0:
                        merge_lines.append(f"{fs} ─┐")
                    else:
                        merge_lines.append(f"{fs} ─┴──> {cont_str}")
                else:
                    if i == 0:
                        merge_lines.append(f"{fs} ─┐")
                    elif i == mid:
                        merge_lines.append(f"{fs} ─┼──> {cont_str}")
                    elif i == n - 1:
                        merge_lines.append(f"{fs} ─┘")
                    else:
                        merge_lines.append(f"{fs} ─┤")

            blocks.append((layer.get(merge_id, 0), merge_lines))

            # Continue rendering from the end of the post-chain
            last = post_chain[-1]
            succs = dag.get(last, [])
            if len(succs) > 1:
                _render_fork([last], succs)
            elif len(succs) == 1:
                nxt = succs[0]
                if _is_merge(nxt):
                    _render_merge(nxt)
                else:
                    _render_from(nxt)

        # ── Kick off from each root ──
        for rid in root_ids:
            _render_from(rid)

        # Catch any unrendered nodes (orphans, etc.)
        for nid in sorted(all_ids, key=lambda n: layer.get(n, 0)):
            if nid not in rendered:
                rendered.add(nid)
                blocks.append((layer.get(nid, 0), [_name(nid)]))

        # Sort by topological layer and flatten
        blocks.sort(key=lambda b: b[0])
        result: List[str] = []
        for _, blines in blocks:
            result.extend(blines)
            result.append("")
        while result and result[-1] == "":
            result.pop()
        return result if result else ["(empty flow)"]


# ===================================================================
# Visualization generators (post-execution)
# ===================================================================

def _generate_visualizations(parsed: Dict[str, Any]) -> None:
    """Generate post-execution visualization artifacts in thoughts/."""
    thoughts_dir = get_project_root() / "thoughts"
    thoughts_dir.mkdir(parents=True, exist_ok=True)

    # conversion_workflow.md — dynamic, with actual counts and mapping details
    from datetime import datetime as _dt

    output_dir = get_project_root() / "output"
    stg_count = len(list((output_dir / "models" / "staging").glob("stg_*.sql"))) if (output_dir / "models" / "staging").exists() else 0
    int_count = len(list((output_dir / "models" / "intermediate").rglob("int_*.sql"))) if (output_dir / "models" / "intermediate").exists() else 0
    mart_count = len(list((output_dir / "models" / "marts").glob("*.sql"))) if (output_dir / "models" / "marts").exists() else 0
    snap_count = len(list((output_dir / "snapshots").glob("snapshot_*.sql"))) if (output_dir / "snapshots").exists() else 0
    macro_count = len(list((output_dir / "macros").glob("*.sql"))) if (output_dir / "macros").exists() else 0
    source_tables = 0
    source_yml = output_dir / "models" / "source.yml"
    if source_yml.exists():
        source_tables = source_yml.read_text(encoding="utf-8").count("description: Source table for")
    var_count = 0
    dbt_proj = output_dir / "dbt_project.yml"
    if dbt_proj.exists():
        in_vars = False
        for line in dbt_proj.read_text(encoding="utf-8").splitlines():
            if line.strip().startswith("vars:"):
                in_vars = True
                continue
            if in_vars and line.strip() and not line.startswith(" "):
                break
            if in_vars and ":" in line:
                var_count += 1

    wf: List[str] = []
    wf.append("# Conversion Workflow")
    wf.append("")
    wf.append(f"Generated: {_dt.now().strftime('%Y-%m-%d %H:%M:%S')}")
    wf.append("")
    wf.append("## Pipeline Flow")
    wf.append("")
    wf.append("```")
    wf.append("inputs/*.json")
    wf.append("    |")
    wf.append("    v")
    wf.append("[IDMCParser]")
    wf.append("    |  - Parses IDMC JSON mapping exports")
    wf.append("    |  - Extracts sources, transformations, targets, variables")
    wf.append("    |  - Resolves variable references ($$param)")
    wf.append("    |  - Builds transformation DAG (topological order)")
    wf.append("    |  - Detects load type (FULL / CDC)")
    wf.append("    |  - Extracts custom SQL overrides from Source Qualifier queries")
    wf.append("    |")
    wf.append("    v")
    wf.append("[Conversion Plans] --> plans/*_conversion_plan.md")
    wf.append("    |")
    wf.append("    v")
    wf.append("[IDMCGenerator]")
    wf.append("    |")
    wf.append(f"    +---> output/models/staging/stg_*.sql        ({stg_count} models)")
    wf.append(f"    +---> output/models/intermediate/int_*.sql   ({int_count} models)")
    wf.append(f"    +---> output/models/marts/*.sql              ({mart_count} models)")
    if snap_count:
        wf.append(f"    +---> output/snapshots/snapshot_*.sql       ({snap_count} snapshots)")
    wf.append(f"    +---> output/models/source.yml               ({source_tables} source tables)")
    wf.append("    +---> output/models/staging/schema.yml")
    wf.append("    +---> output/models/intermediate/schema.yml")
    wf.append("    +---> output/models/marts/schema.yml")
    if var_count:
        wf.append(f"    +---> output/dbt_project.yml                 ({var_count} vars)")
    else:
        wf.append("    +---> output/dbt_project.yml")
    if macro_count:
        wf.append(f"    +---> output/macros/                         ({macro_count} macros)")
    wf.append("```")
    wf.append("")

    # Per-mapping summary
    mappings = list(parsed.values()) if isinstance(parsed, dict) else parsed
    wf.append(f"## Mappings Processed: {len(mappings)}")
    for mapping in mappings:
        if not isinstance(mapping, dict):
            continue
        m_name = mapping.get("mapping_name", "unknown")
        sources = mapping.get("sources", [])
        tx_by_id = mapping.get("tx_by_id", {})
        targets = mapping.get("targets", [])
        load_type = mapping.get("load_type", "FULL")
        num_sources = len(sources)
        num_txs = len(tx_by_id)
        num_targets = len(targets)
        wf.append(f"  - {m_name}: {num_sources} sources, {num_txs} transformations, {num_targets} targets, load_type={load_type}")
    wf.append("")

    (thoughts_dir / "conversion_workflow.md").write_text(
        "\n".join(wf) + "\n", encoding="utf-8"
    )

    # output_structure.md
    structure_lines: List[str] = []
    structure_lines.append("# Output Structure")
    structure_lines.append("")
    structure_lines.append("```")
    structure_lines.append("output/")
    structure_lines.append("  macros/")
    structure_lines.append("    generate_sk.sql")
    structure_lines.append("    grant_privileges.sql")
    structure_lines.append("  models/")
    structure_lines.append("    staging/")
    structure_lines.append("      stg_<short_schema>_<table_name>.sql")
    structure_lines.append("      schema.yml")
    structure_lines.append("    intermediate/")
    structure_lines.append("      int_<short_schema>_<table_name>.sql  (source intermediate)")
    structure_lines.append("      int_<mapping_safe_name>.sql          (mapping intermediate)")
    structure_lines.append("      schema.yml")
    structure_lines.append("    marts/")
    structure_lines.append("      <mapping_safe_name>.sql")
    structure_lines.append("      schema.yml")
    structure_lines.append("    source.yml")
    structure_lines.append("  snapshots/")
    structure_lines.append("    snapshot_<mapping_safe_name>.sql  (CDC only)")
    structure_lines.append("  dbt_project.yml")
    structure_lines.append("```")
    structure_lines.append("")
    structure_lines.append("## Model Dependency Flow")
    structure_lines.append("")
    structure_lines.append("```")
    structure_lines.append("source.yml  -->  stg_*.sql ({{ source() }})")
    structure_lines.append("                    |")
    structure_lines.append("                    v")
    structure_lines.append("             int_<schema>_<table>.sql ({{ ref('stg_...') }})")
    structure_lines.append("                    |")
    structure_lines.append("                    v")
    structure_lines.append("             int_<mapping>.sql ({{ ref('int_...') }})")
    structure_lines.append("                    |")
    structure_lines.append("              ------+------")
    structure_lines.append("             |             |")
    structure_lines.append("             v             v")
    structure_lines.append("    snapshot_*.sql    <mapping>.sql (FULL)")
    structure_lines.append("       (CDC)         {{ ref('int_...') }}")
    structure_lines.append("         |")
    structure_lines.append("         v")
    structure_lines.append("    <mapping>.sql (CDC)")
    structure_lines.append("    {{ ref('snapshot_...') }}")
    structure_lines.append("```")
    (thoughts_dir / "output_structure.md").write_text(
        "\n".join(structure_lines) + "\n", encoding="utf-8"
    )


# ===================================================================
# main()
# ===================================================================

def main() -> None:
    """Entry point: parse IDMC JSON, generate plans, generate dbt project."""
    logger = setup_logging("main")
    logger.info("Starting IDMC-to-dbt forward engineering")

    # Step 1: Parse
    parser = IDMCParser()
    results = parser.parse_all()

    if not results:
        logger.warning("No mappings parsed. Check inputs/ directory.")
        return

    logger.info(f"Parsed {len(results)} mapping(s)")

    # Step 2: Generate conversion plans
    planner = ConversionPlanGenerator(results)
    planner.generate_plans()

    # Step 3: Generate dbt models
    generator = IDMCGenerator(results)
    generator.generate()

    # Step 4: Generate visualizations
    _generate_visualizations(results)

    logger.info("Forward engineering complete")


if __name__ == "__main__":
    main()
