"""
CLI entry point for the IDMC-to-dbt Forward Engineering pipeline.

Exposes all pipeline commands through a single interface:
  - build      : Generate dbt models from IDMC JSON inputs
  - validate   : Validate generated output against IDMC inputs (ground truth)
  - refine     : Auto-fix validation issues and re-validate
  - run        : Run the full pipeline (build -> validate -> refine)

Usage:
    python scripts/cli.py build
    python scripts/cli.py validate
    python scripts/cli.py validate --dry-run
    python scripts/cli.py validate --files output/models/marts/docusign_transaction.sql
    python scripts/cli.py refine --max-iterations 5
    python scripts/cli.py run
    python scripts/cli.py run --skip-refine
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

# Ensure scripts/ is on the Python path
SCRIPTS_DIR = Path(__file__).resolve().parent
sys.path.insert(0, str(SCRIPTS_DIR))


def cmd_build(args: argparse.Namespace) -> None:
    """Run the build stage: parse IDMC JSON inputs and generate dbt project."""
    import build_all
    build_all.main()


def cmd_validate(args: argparse.Namespace) -> None:
    """Run the validator against generated output."""
    from validator import IDMCValidator

    # Build argv for validator's own argparse
    sys.argv = ["validator"]
    if args.dry_run:
        sys.argv.append("--dry-run")
    if args.files:
        sys.argv.extend(["--files"] + args.files)

    v = IDMCValidator(target_dir="output")
    v.validate()
    report = v.generate_report()
    v.save_report(report)
    v.print_summary()


def cmd_refine(args: argparse.Namespace) -> None:
    """Run the refiner to auto-fix validation issues."""
    from refiner import Refiner

    report_path = Path(args.report) if args.report else None
    refiner = Refiner(
        validation_report_path=report_path,
        max_iterations=args.max_iterations,
    )
    refiner.run()


def cmd_run(args: argparse.Namespace) -> None:
    """Run the full end-to-end pipeline (build -> validate -> refine)."""
    # Delegate to run_conversion which already handles argparse
    sys.argv = ["run_conversion"]
    if args.skip_refine:
        sys.argv.append("--skip-refine")
    if args.max_iterations != 3:
        sys.argv.extend(["--max-iterations", str(args.max_iterations)])

    import run_conversion
    run_conversion.main()


def main() -> None:
    """Parse arguments and dispatch to the appropriate command."""
    parser = argparse.ArgumentParser(
        prog="cli",
        description="IDMC-to-dbt Forward Engineering Pipeline CLI",
    )
    subparsers = parser.add_subparsers(dest="command", required=True)

    # --- build ---
    subparsers.add_parser(
        "build",
        help="Generate dbt models from IDMC JSON inputs",
    )

    # --- validate ---
    p_validate = subparsers.add_parser(
        "validate",
        help="Validate generated output against IDMC inputs",
    )
    p_validate.add_argument(
        "--dry-run",
        action="store_true",
        help="List checks without running them",
    )
    p_validate.add_argument(
        "--files",
        nargs="+",
        help="Validate specific output files only",
    )

    # --- refine ---
    p_refine = subparsers.add_parser(
        "refine",
        help="Auto-fix validation issues and re-validate",
    )
    p_refine.add_argument(
        "--report",
        type=str,
        default="",
        help="Path to a validation report YAML to use as input",
    )
    p_refine.add_argument(
        "--max-iterations",
        type=int,
        default=3,
        help="Maximum refinement iterations (default: 3)",
    )

    # --- run (full pipeline) ---
    p_run = subparsers.add_parser(
        "run",
        help="Run full pipeline: build -> validate -> refine",
    )
    p_run.add_argument(
        "--skip-refine",
        action="store_true",
        help="Skip the refinement stage",
    )
    p_run.add_argument(
        "--max-iterations",
        type=int,
        default=3,
        help="Maximum refinement iterations (default: 3)",
    )

    args = parser.parse_args()

    dispatch = {
        "build": cmd_build,
        "validate": cmd_validate,
        "refine": cmd_refine,
        "run": cmd_run,
    }
    dispatch[args.command](args)


if __name__ == "__main__":
    main()
