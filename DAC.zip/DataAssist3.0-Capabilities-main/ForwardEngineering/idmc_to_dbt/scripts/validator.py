"""
IDMC-to-dbt Output Validator.

Compares generated dbt output files against IDMC JSON mapping exports
(ground truth in inputs/) and reference rules from knowledgebase/.
Produces a structured YAML validation report.

This script is strictly read-only -- it never modifies any file.

Usage:
    python scripts/validator.py
    python scripts/validator.py --dry-run
    python scripts/validator.py --files output/models/marts/docusign_transaction.sql
"""

from __future__ import annotations

import argparse
import json
import re
import sys
from pathlib import Path
from typing import Any, Dict, List, Optional, Set, Tuple

# Ensure scripts/ is on the path
SCRIPTS_DIR = Path(__file__).resolve().parent
PROJECT_ROOT = SCRIPTS_DIR.parent
sys.path.insert(0, str(SCRIPTS_DIR))

from base_validator import BaseValidator
from utils import get_project_root, get_timestamp, load_yaml, save_yaml, setup_logging
from prompts import VALIDATOR_SYSTEM_PROMPT, VALIDATOR_COMPARISON_PROMPT

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

INPUTS_DIR = PROJECT_ROOT / "inputs"
OUTPUT_DIR = PROJECT_ROOT / "output"
KB_DIR = PROJECT_ROOT / "knowledgebase"
LOG_DIR = PROJECT_ROOT / "thoughts" / "logs" / "agentic"

EDH_AUDIT_COLUMNS: Set[str] = {
    "edh_record_status_in",
    "edh_record_start_ts",
    "edh_record_end_ts",
    "edh_created_batch_key",
    "edh_created_ts",
    "edh_created_nm",
    "edh_updated_batch_key",
    "edh_updated_ts",
    "edh_updated_nm",
}

# IDMC JSON class IDs (numeric) to transformation type names
IDMC_CLASS_ID_MAP: Dict[int, str] = {
    7: "Source",
    8: "Joiner",
    9: "Filter",
    10: "Expression",
    11: "Union",
    12: "Target",
    13: "Router",
    14: "Lookup",
    15: "Aggregator",
    16: "Sorter",
    17: "Rank",
    18: "Normalizer",
    19: "Sequence Generator",
}


# ---------------------------------------------------------------------------
# IDMC JSON Parsing Helpers
# ---------------------------------------------------------------------------

def load_idmc_json(json_path: Path) -> Dict[str, Any]:
    """Load and return an IDMC JSON mapping export."""
    with open(json_path, "r", encoding="utf-8") as f:
        return json.load(f)


def get_mapping_name(data: Dict[str, Any]) -> str:
    """Extract the mapping name from IDMC JSON."""
    return data.get("content", {}).get("name", Path("unknown").stem)


def get_transformations_by_type(
    data: Dict[str, Any],
) -> Dict[str, List[Dict[str, Any]]]:
    """Group IDMC transformations by their type (Source, Target, etc.)."""
    result: Dict[str, List[Dict[str, Any]]] = {}
    for tx in data.get("content", {}).get("transformations", []):
        cls_id = tx.get("$$class", 0)
        tx_type = IDMC_CLASS_ID_MAP.get(cls_id, f"Unknown({cls_id})")
        result.setdefault(tx_type, []).append(tx)
    return result


def get_source_tables(data: Dict[str, Any]) -> List[Dict[str, Any]]:
    """Extract source transformation details (name, connection, table).

    Filters out non-source transformations that share class ID 7 but lack
    a connectionName or nativeName (e.g., Joiners serialised as class 7).
    """
    sources = []
    for tx in data.get("content", {}).get("transformations", []):
        if tx.get("$$class") == 7:  # Source
            adapter = tx.get("dataAdapter", {})
            conn_name = adapter.get("connectionName", "")
            native_name = adapter.get("nativeName", "")

            # Real source transformations always have a connection and/or
            # a native table name.  Entries without both are Joiners or
            # other transformations that IDMC serialises with class 7.
            if not conn_name and not native_name:
                continue

            sources.append({
                "name": tx.get("name", ""),
                "connection": conn_name,
                "table": native_name or "",
                "fields": [f.get("name", "") for f in tx.get("fields", [])],
            })
    return sources


def get_target_tables(data: Dict[str, Any]) -> List[Dict[str, Any]]:
    """Extract target transformation details."""
    targets = []
    for tx in data.get("content", {}).get("transformations", []):
        if tx.get("$$class") == 12:  # Target
            adapter = tx.get("dataAdapter", {})
            targets.append({
                "name": tx.get("name", ""),
                "connection": adapter.get("connectionName", ""),
                "table": adapter.get("nativeName", ""),
                "fields": [f.get("name", "") for f in tx.get("fields", [])],
                "write_operation": adapter.get("writeOperation", ""),
            })
    return targets


def has_router_with_groups(data: Dict[str, Any]) -> bool:
    """Check if mapping has a Router with insert/update groups (CDC indicator)."""
    for tx in data.get("content", {}).get("transformations", []):
        if tx.get("$$class") == 13:  # Router
            groups = tx.get("groups", [])
            group_names = [g.get("name", "").lower() for g in groups]
            if any("insert" in n or "new" in n or "changed" in n for n in group_names):
                return True
    return False


def has_cdc_target(data: Dict[str, Any]) -> bool:
    """Check if any target uses DATA_DRIVEN or UPSERT write operation."""
    for tx in data.get("content", {}).get("transformations", []):
        if tx.get("$$class") == 12:
            adapter = tx.get("dataAdapter", {})
            write_op = adapter.get("writeOperation", "").upper()
            if write_op in ("DATA_DRIVEN", "UPSERT"):
                return True
    return has_router_with_groups(data)


def get_expression_fields(data: Dict[str, Any]) -> List[Dict[str, str]]:
    """Extract expression transformation fields with their derivations."""
    expressions = []
    for tx in data.get("content", {}).get("transformations", []):
        if tx.get("$$class") == 10:  # Expression
            for field in tx.get("fields", []):
                expr = field.get("expression", "")
                if expr:
                    expressions.append({
                        "transformation": tx.get("name", ""),
                        "field": field.get("name", ""),
                        "expression": expr,
                    })
    return expressions


# ---------------------------------------------------------------------------
# Validation Check Functions
# ---------------------------------------------------------------------------

class IDMCValidator(BaseValidator):
    """Validates IDMC-to-dbt output against JSON inputs and knowledgebase rules."""

    def __init__(self, target_dir: str = "output", dry_run: bool = False,
                 specific_files: Optional[List[str]] = None):
        super().__init__(target_dir=target_dir)
        self.dry_run = dry_run
        self.specific_files = specific_files
        self.logger = setup_logging("IDMCValidator", log_dir=LOG_DIR)
        self.issues: List[Dict[str, Any]] = []
        self.passed_checks: List[str] = []
        self.issue_counter = 0

    def _add_issue(
        self,
        severity: str,
        category: str,
        description: str,
        source_file: str,
        output_file: str,
    ) -> None:
        """Add a validated issue to the issues list."""
        # Guardrail: source traceability -- verify referenced files exist
        src_path = PROJECT_ROOT / source_file
        out_path = PROJECT_ROOT / output_file
        if not src_path.exists() and source_file != "N/A":
            self.logger.warning(
                f"Skipping issue (source file not found): {source_file} -- "
                f"{description}"
            )
            return
        if not out_path.exists() and output_file != "N/A":
            # The issue might be about a missing file, which is valid
            if category != "missing_model" and category != "missing_file":
                self.logger.warning(
                    f"Skipping issue (output file not found): {output_file} -- "
                    f"{description}"
                )
                return

        self.issue_counter += 1
        self.issues.append({
            "id": f"V-{self.issue_counter:03d}",
            "severity": severity,
            "category": category,
            "description": description,
            "source_file": source_file,
            "output_file": output_file,
        })

    def _add_pass(self, check_description: str) -> None:
        """Record a passed check."""
        self.passed_checks.append(check_description)

    # -------------------------------------------------------------------
    # Individual validation checks
    # -------------------------------------------------------------------

    def check_staging_completeness(
        self, input_file: str, data: Dict[str, Any]
    ) -> None:
        """Verify every IDMC source has a corresponding staging model."""
        sources = get_source_tables(data)
        staging_dir = OUTPUT_DIR / "models" / "staging"
        staging_files = {f.stem for f in staging_dir.glob("stg_*.sql")} if staging_dir.exists() else set()

        for src in sources:
            # The generator creates staging files based on connection + table
            # We check if ANY staging file exists that could correspond
            src_name_lower = src["name"].lower()
            table_lower = src.get("table", "").lower().replace(".", "_")

            found = False
            for stg in staging_files:
                # Fuzzy match: staging file should contain the table name
                if table_lower and table_lower in stg:
                    found = True
                    break
                if src_name_lower.replace("src_", "") in stg:
                    found = True
                    break

            if found:
                self._add_pass(
                    f"Staging model exists for source '{src['name']}' "
                    f"from {input_file}"
                )
            else:
                self._add_issue(
                    severity="high",
                    category="missing_model",
                    description=(
                        f"No staging model found for IDMC source "
                        f"'{src['name']}' (table: {src.get('table', 'unknown')})"
                    ),
                    source_file=input_file,
                    output_file="output/models/staging/",
                )

    def check_source_yml_completeness(
        self, input_file: str, data: Dict[str, Any]
    ) -> None:
        """Verify source.yml contains entries for all IDMC sources."""
        source_yml_path = OUTPUT_DIR / "models" / "source.yml"
        if not source_yml_path.exists():
            self._add_issue(
                severity="high",
                category="missing_file",
                description="source.yml not found in output/models/",
                source_file=input_file,
                output_file="output/models/source.yml",
            )
            return

        source_yml = load_yaml(source_yml_path)
        # Collect all table names defined in source.yml
        defined_tables: Set[str] = set()
        for source_def in source_yml.get("sources", []):
            for table in source_def.get("tables", []):
                defined_tables.add(table.get("name", "").lower())

        sources = get_source_tables(data)
        for src in sources:
            table_name = src.get("table", "").lower().split(".")[-1] if src.get("table") else ""
            if not table_name:
                continue
            if table_name in defined_tables:
                self._add_pass(
                    f"source.yml contains entry for table '{table_name}'"
                )
            else:
                self._add_issue(
                    severity="medium",
                    category="schema_mismatch",
                    description=(
                        f"source.yml missing entry for table '{table_name}' "
                        f"from source '{src['name']}'"
                    ),
                    source_file=input_file,
                    output_file="output/models/source.yml",
                )

    def check_staging_uses_source_macro(self) -> None:
        """Verify all staging models use {{ source() }} not raw table refs."""
        staging_dir = OUTPUT_DIR / "models" / "staging"
        if not staging_dir.exists():
            return

        for sql_file in staging_dir.glob("stg_*.sql"):
            content = sql_file.read_text(encoding="utf-8")
            if "{{ source(" in content or "{{source(" in content:
                self._add_pass(f"{sql_file.name} uses {{{{ source() }}}} correctly")
            else:
                # Check if it uses ref() instead (wrong for staging)
                if "{{ ref(" in content or "{{ref(" in content:
                    self._add_issue(
                        severity="high",
                        category="wrong_ref",
                        description=(
                            f"Staging model {sql_file.name} uses ref() "
                            f"instead of source()"
                        ),
                        source_file="N/A",
                        output_file=f"output/models/staging/{sql_file.name}",
                    )
                else:
                    self._add_issue(
                        severity="medium",
                        category="wrong_ref",
                        description=(
                            f"Staging model {sql_file.name} does not use "
                            f"{{{{ source() }}}} macro"
                        ),
                        source_file="N/A",
                        output_file=f"output/models/staging/{sql_file.name}",
                    )

    def check_intermediate_uses_ref(self) -> None:
        """Verify all intermediate models use {{ ref() }} not source()."""
        int_dir = OUTPUT_DIR / "models" / "intermediate"
        if not int_dir.exists():
            return

        for sql_file in int_dir.rglob("int_*.sql"):
            content = sql_file.read_text(encoding="utf-8")
            if "{{ source(" in content or "{{source(" in content:
                self._add_issue(
                    severity="high",
                    category="wrong_ref",
                    description=(
                        f"Intermediate model {sql_file.name} uses source() "
                        f"instead of ref()"
                    ),
                    source_file="N/A",
                    output_file=f"output/models/intermediate/{sql_file.name}",
                )
            elif "{{ ref(" in content or "{{ref(" in content:
                self._add_pass(f"{sql_file.name} uses {{{{ ref() }}}} correctly")

    def check_marts_uses_ref(self) -> None:
        """Verify all marts models use {{ ref() }} not source()."""
        marts_dir = OUTPUT_DIR / "models" / "marts"
        if not marts_dir.exists():
            return

        for sql_file in marts_dir.glob("*.sql"):
            content = sql_file.read_text(encoding="utf-8")
            if "{{ source(" in content or "{{source(" in content:
                self._add_issue(
                    severity="high",
                    category="wrong_ref",
                    description=(
                        f"Marts model {sql_file.name} uses source() "
                        f"instead of ref()"
                    ),
                    source_file="N/A",
                    output_file=f"output/models/marts/{sql_file.name}",
                )
            else:
                self._add_pass(f"{sql_file.name} uses {{{{ ref() }}}} correctly")

    def check_edh_audit_columns(
        self, input_file: str, data: Dict[str, Any]
    ) -> None:
        """Verify marts models include EDH audit columns declared by the target.

        Only checks for EDH columns that exist in the IDMC target definition.
        Targets that don't declare EDH columns (e.g. simple FULL loads) are
        not expected to have them in the mart.
        """
        mapping_name = get_mapping_name(data)
        marts_dir = OUTPUT_DIR / "models" / "marts"
        if not marts_dir.exists():
            return

        # Extract EDH columns declared in the target
        content_data = data.get("content", data)
        target_edh: set = set()
        for tx in content_data.get("transformations", []):
            raw = tx if "fields" in tx else tx.get("raw", tx)
            if raw.get("type") in ("Target", "target"):
                for f in raw.get("fields", []):
                    fname = f.get("name", "").lower() if isinstance(f, dict) else ""
                    if fname.startswith("edh_"):
                        target_edh.add(fname)
        # Also check top-level targets
        for tgt in content_data.get("targets", content_data.get("targetInstances", [])):
            for f in tgt.get("fields", []):
                fname = f.get("name", "").lower() if isinstance(f, dict) else ""
                if fname.startswith("edh_"):
                    target_edh.add(fname)

        for sql_file in marts_dir.glob("*.sql"):
            if sql_file.suffix != ".sql":
                continue
            sql_content = sql_file.read_text(encoding="utf-8").lower()

            # For Type 2 (snapshot-based) marts, expect all EDH columns
            is_type2 = "ref('snapshot_" in sql_content or 'ref("snapshot_' in sql_content
            expected_cols = EDH_AUDIT_COLUMNS if is_type2 else target_edh

            if not expected_cols:
                # Target declares no EDH columns — skip check
                self._add_pass(
                    f"{sql_file.name} — target has no EDH columns, none expected"
                )
                continue

            missing_cols = []
            for col in expected_cols:
                if col not in sql_content:
                    missing_cols.append(col)

            if not missing_cols:
                self._add_pass(
                    f"{sql_file.name} contains all expected EDH audit columns"
                )
            else:
                self._add_issue(
                    severity="high",
                    category="missing_edh_columns",
                    description=(
                        f"Marts model {sql_file.name} is missing EDH audit "
                        f"columns: {', '.join(missing_cols)}"
                    ),
                    source_file=input_file,
                    output_file=f"output/models/marts/{sql_file.name}",
                )

    @staticmethod
    def _is_scd_type1(data: Dict[str, Any]) -> bool:
        """Detect SCD Type 1 by absence of edh_record_start_ts/end_ts in targets."""
        content = data.get("content", data)
        for tx in content.get("transformations", []):
            raw = tx if "fields" in tx else tx.get("raw", tx)
            groups = raw.get("groups", [])
            for g in groups:
                gname = g.get("name", "").lower()
                if any(kw in gname for kw in ("error", "reject", "batchkey", "historysk", "lastsk")):
                    continue
                field_names = set()
                for f in g.get("fields", []):
                    fname = f.get("name", "")
                    if fname:
                        field_names.add(fname.lower())
                if "edh_record_start_ts" in field_names and "edh_record_end_ts" in field_names:
                    return False
        return True

    def check_snapshot_for_cdc(
        self, input_file: str, data: Dict[str, Any]
    ) -> None:
        """Verify CDC mappings have corresponding snapshot files (Type 2 only)."""
        if not has_cdc_target(data):
            self._add_pass(
                f"Non-CDC mapping {input_file} -- no snapshot required"
            )
            return

        # SCD Type 1 does not need a snapshot
        if self._is_scd_type1(data):
            self._add_pass(
                f"SCD Type 1 mapping {input_file} -- no snapshot required (incremental MERGE)"
            )
            return

        mapping_name = get_mapping_name(data)
        snapshot_dir = OUTPUT_DIR / "snapshots"
        if not snapshot_dir.exists():
            self._add_issue(
                severity="high",
                category="snapshot_issue",
                description=(
                    f"CDC mapping '{mapping_name}' requires a snapshot but "
                    f"output/snapshots/ directory does not exist"
                ),
                source_file=input_file,
                output_file="output/snapshots/",
            )
            return

        snapshot_files = {f.stem for f in snapshot_dir.glob("snapshot_*.sql")}
        # Build the mapping intermediate name for ref-based matching
        mapping_safe = mapping_name.lower().replace("-", "_").replace(" ", "_")
        # Strip common prefixes (m_, tf_) that the generator removes
        for prefix in ("m_", "tf_"):
            if mapping_safe.startswith(prefix):
                mapping_safe = mapping_safe[len(prefix):]
                break
        int_ref_pattern = f"int_{mapping_safe}"
        # Find a matching snapshot
        found = False
        for snap in snapshot_files:
            # Strategy 1: Relaxed name-part match
            if any(
                part in snap
                for part in mapping_name.lower().replace("-", "_").split("_")
                if len(part) > 3
            ):
                found = True
                break
        # Strategy 2: Check if any snapshot references the mapping intermediate
        if not found:
            for snap_file in snapshot_dir.glob("snapshot_*.sql"):
                content = snap_file.read_text(encoding="utf-8")
                if int_ref_pattern in content.lower():
                    found = True
                    break

        if found:
            self._add_pass(
                f"Snapshot exists for CDC mapping '{mapping_name}'"
            )
        else:
            self._add_issue(
                severity="high",
                category="snapshot_issue",
                description=(
                    f"No snapshot found for CDC mapping '{mapping_name}'"
                ),
                source_file=input_file,
                output_file="output/snapshots/",
            )

    def check_snapshot_uses_check_strategy(self) -> None:
        """Verify snapshot files use the check strategy with chksum."""
        snapshot_dir = OUTPUT_DIR / "snapshots"
        if not snapshot_dir.exists():
            return

        for sql_file in snapshot_dir.glob("snapshot_*.sql"):
            content = sql_file.read_text(encoding="utf-8")
            if "strategy='check'" in content or 'strategy="check"' in content:
                self._add_pass(
                    f"{sql_file.name} uses check strategy"
                )
            else:
                self._add_issue(
                    severity="medium",
                    category="snapshot_issue",
                    description=(
                        f"Snapshot {sql_file.name} does not use "
                        f"strategy='check'"
                    ),
                    source_file="N/A",
                    output_file=f"output/snapshots/{sql_file.name}",
                )

            if "chksum" in content.lower():
                self._add_pass(f"{sql_file.name} references chksum column")
            else:
                self._add_issue(
                    severity="medium",
                    category="snapshot_issue",
                    description=(
                        f"Snapshot {sql_file.name} does not reference "
                        f"chksum column"
                    ),
                    source_file="N/A",
                    output_file=f"output/snapshots/{sql_file.name}",
                )

    def check_naming_conventions(self) -> None:
        """Verify file naming conventions across all layers."""
        # Staging: stg_*.sql
        staging_dir = OUTPUT_DIR / "models" / "staging"
        if staging_dir.exists():
            for f in staging_dir.glob("*.sql"):
                if not f.name.startswith("stg_"):
                    self._add_issue(
                        severity="medium",
                        category="naming_violation",
                        description=(
                            f"Staging file '{f.name}' does not start with 'stg_'"
                        ),
                        source_file="N/A",
                        output_file=f"output/models/staging/{f.name}",
                    )
                elif f.name != f.name.lower():
                    self._add_issue(
                        severity="low",
                        category="naming_violation",
                        description=(
                            f"Staging file '{f.name}' is not fully lowercase"
                        ),
                        source_file="N/A",
                        output_file=f"output/models/staging/{f.name}",
                    )
                else:
                    self._add_pass(f"Staging file '{f.name}' follows naming convention")

        # Intermediate: int_*.sql
        int_dir = OUTPUT_DIR / "models" / "intermediate"
        if int_dir.exists():
            for f in int_dir.glob("*.sql"):
                if not f.name.startswith("int_"):
                    self._add_issue(
                        severity="medium",
                        category="naming_violation",
                        description=(
                            f"Intermediate file '{f.name}' does not start with 'int_'"
                        ),
                        source_file="N/A",
                        output_file=f"output/models/intermediate/{f.name}",
                    )

        # Marts: NO mart_ prefix
        marts_dir = OUTPUT_DIR / "models" / "marts"
        if marts_dir.exists():
            for f in marts_dir.glob("*.sql"):
                if f.name.startswith("mart_"):
                    self._add_issue(
                        severity="medium",
                        category="naming_violation",
                        description=(
                            f"Marts file '{f.name}' has 'mart_' prefix "
                            f"(should not have prefix)"
                        ),
                        source_file="N/A",
                        output_file=f"output/models/marts/{f.name}",
                    )
                else:
                    self._add_pass(f"Marts file '{f.name}' has no mart_ prefix")

    def check_dbt_project_yml(self) -> None:
        """Verify dbt_project.yml exists and has required sections."""
        dbt_yml_path = OUTPUT_DIR / "dbt_project.yml"
        if not dbt_yml_path.exists():
            self._add_issue(
                severity="high",
                category="missing_file",
                description="dbt_project.yml not found in output/",
                source_file="N/A",
                output_file="output/dbt_project.yml",
            )
            return

        dbt_config = load_yaml(dbt_yml_path)
        required_keys = ["name", "version", "profile", "model-paths", "models"]
        for key in required_keys:
            if key in dbt_config:
                self._add_pass(f"dbt_project.yml contains '{key}'")
            else:
                self._add_issue(
                    severity="medium",
                    category="schema_mismatch",
                    description=f"dbt_project.yml missing required key: '{key}'",
                    source_file="N/A",
                    output_file="output/dbt_project.yml",
                )

        # Check materialization settings
        models_config = dbt_config.get("models", {})
        if models_config:
            project_name = dbt_config.get("name", "")
            project_models = models_config.get(project_name, {})
            for layer in ["staging", "intermediate", "marts"]:
                layer_config = project_models.get(layer, {})
                if "+materialized" in layer_config:
                    self._add_pass(
                        f"dbt_project.yml defines materialization for {layer}"
                    )

    def check_macros_exist(self) -> None:
        """Verify required macros exist if snapshots are present."""
        snapshot_dir = OUTPUT_DIR / "snapshots"
        has_snapshots = snapshot_dir.exists() and any(snapshot_dir.glob("snapshot_*.sql"))
        if not has_snapshots:
            return

        macros_dir = OUTPUT_DIR / "macros"
        required_macros = [
            "generate_chksum.sql",
            "generate_sk_type2.sql",
            "generate_snapshot_key.sql",
            "grant_privileges.sql",
        ]
        for macro_name in required_macros:
            macro_path = macros_dir / macro_name
            if macro_path.exists():
                self._add_pass(f"Macro '{macro_name}' exists")
            else:
                self._add_issue(
                    severity="high",
                    category="missing_file",
                    description=(
                        f"Required macro '{macro_name}' not found in "
                        f"output/macros/"
                    ),
                    source_file="N/A",
                    output_file=f"output/macros/{macro_name}",
                )

    def check_todo_markers(self) -> None:
        """Count TODO: MANUAL REVIEW REQUIRED markers in output files."""
        todo_pattern = re.compile(r"--\s*TODO:?\s*MANUAL REVIEW", re.IGNORECASE)
        todo_count = 0

        for sql_file in OUTPUT_DIR.rglob("*.sql"):
            content = sql_file.read_text(encoding="utf-8")
            matches = todo_pattern.findall(content)
            todo_count += len(matches)

        if todo_count > 0:
            self._add_issue(
                severity="low",
                category="function_mapping",
                description=(
                    f"Found {todo_count} TODO: MANUAL REVIEW markers across "
                    f"output SQL files (untranslated IDMC functions)"
                ),
                source_file="N/A",
                output_file="output/",
            )
        else:
            self._add_pass("No untranslated IDMC function markers found")

    def check_sorter_not_order_by(self) -> None:
        """Verify sorter transformations are comments, not ORDER BY.

        Only checks mapping intermediate files (CTE-based, contain WITH).
        Source intermediate files use custom SQL overrides from IDMC and
        are left as-is.
        """
        for sql_file in OUTPUT_DIR.rglob("*.sql"):
            content = sql_file.read_text(encoding="utf-8")
            # Skip source intermediate files (custom SQL overrides without CTEs)
            content_upper = content.upper()
            if "\nWITH\n" not in content_upper and "\nWITH " not in content_upper:
                continue
            lines = content.split("\n")
            for i, line in enumerate(lines, 1):
                stripped = line.strip().upper()
                # Check for ORDER BY that is NOT inside a window function
                if "ORDER BY" in stripped and "OVER" not in stripped:
                    # Check if this is inside a WINDOW/OVER clause by
                    # looking at surrounding context
                    context_start = max(0, i - 5)
                    context = "\n".join(lines[context_start:i]).upper()
                    if "OVER" in context or "PARTITION BY" in context:
                        continue  # Inside a window function, OK
                    # Check if it is a comment
                    if stripped.startswith("--") or stripped.startswith("/*"):
                        continue  # Commented out, OK
                    self._add_issue(
                        severity="medium",
                        category="function_mapping",
                        description=(
                            f"File {sql_file.name} line {i}: ORDER BY found "
                            f"outside window function (sorters should be "
                            f"comments, not ORDER BY)"
                        ),
                        source_file="N/A",
                        output_file=str(sql_file.relative_to(PROJECT_ROOT)),
                    )

    def check_schema_yml_consistency(self) -> None:
        """Verify schema.yml entries match actual SQL files."""
        for layer in ["staging", "intermediate", "marts"]:
            layer_dir = OUTPUT_DIR / "models" / layer
            schema_path = layer_dir / "schema.yml"
            if not schema_path.exists():
                continue

            schema_data = load_yaml(schema_path)
            defined_models = set()
            for model in schema_data.get("models", []):
                defined_models.add(model.get("name", ""))

            # Get actual SQL files (including subfolders)
            actual_models = {f.stem for f in layer_dir.rglob("*.sql")}

            # Models in schema but not on disk
            for model_name in defined_models:
                if model_name and model_name not in actual_models:
                    self._add_issue(
                        severity="low",
                        category="schema_mismatch",
                        description=(
                            f"Schema {layer}/schema.yml references model "
                            f"'{model_name}' which has no SQL file"
                        ),
                        source_file="N/A",
                        output_file=f"output/models/{layer}/schema.yml",
                    )

            # SQL files not in schema (informational)
            for model_name in actual_models:
                if model_name not in defined_models:
                    self._add_issue(
                        severity="low",
                        category="schema_mismatch",
                        description=(
                            f"SQL file '{model_name}.sql' in {layer}/ has "
                            f"no entry in schema.yml"
                        ),
                        source_file="N/A",
                        output_file=f"output/models/{layer}/{model_name}.sql",
                    )

    def check_target_fields_in_marts(
        self, input_file: str, data: Dict[str, Any]
    ) -> None:
        """Verify target transformation fields appear in the marts model."""
        targets = get_target_tables(data)
        marts_dir = OUTPUT_DIR / "models" / "marts"
        if not marts_dir.exists():
            return

        for target in targets:
            target_name = target["name"].lower()
            # Skip batch key / ops targets (not real marts)
            if "ops_batchkey" in target_name or "batch_key" in target_name:
                continue
            if "reject" in target_name:
                continue

            # Find corresponding marts file
            marts_files = list(marts_dir.glob("*.sql"))
            matched_file: Optional[Path] = None
            for mf in marts_files:
                # Relaxed matching
                table_parts = target.get("table", "").lower().replace(".", "_").split("_")
                significant_parts = [p for p in table_parts if len(p) > 3]
                if any(p in mf.stem for p in significant_parts):
                    matched_file = mf
                    break

            if matched_file is None:
                # Already covered by staging/target completeness checks
                continue

            content = matched_file.read_text(encoding="utf-8").lower()
            edh_names = {c.lower() for c in EDH_AUDIT_COLUMNS}
            edh_names.add("chksum")

            missing_fields = []
            for field_name in target["fields"]:
                fn_lower = field_name.lower()
                if fn_lower in edh_names:
                    continue  # EDH columns checked separately
                if fn_lower in content:
                    continue
                missing_fields.append(field_name)

            if not missing_fields:
                self._add_pass(
                    f"All target fields from '{target['name']}' found in "
                    f"{matched_file.name}"
                )
            elif len(missing_fields) <= 5:
                self._add_issue(
                    severity="medium",
                    category="missing_field",
                    description=(
                        f"Marts model {matched_file.name} is missing target "
                        f"fields: {', '.join(missing_fields)}"
                    ),
                    source_file=input_file,
                    output_file=f"output/models/marts/{matched_file.name}",
                )
            else:
                self._add_issue(
                    severity="high",
                    category="missing_field",
                    description=(
                        f"Marts model {matched_file.name} is missing "
                        f"{len(missing_fields)} target fields from "
                        f"'{target['name']}' (first 5: "
                        f"{', '.join(missing_fields[:5])})"
                    ),
                    source_file=input_file,
                    output_file=f"output/models/marts/{matched_file.name}",
                )

    # -------------------------------------------------------------------
    # Main validate method
    # -------------------------------------------------------------------

    def validate(self) -> List[Dict[str, Any]]:
        """Run all validation checks against output/ and inputs/."""
        self.logger.info("=" * 60)
        self.logger.info("IDMC-to-dbt Validation Starting")
        self.logger.info("=" * 60)

        if self.dry_run:
            self.logger.info("DRY RUN -- listing checks only")
            checks = [
                "check_staging_completeness",
                "check_source_yml_completeness",
                "check_staging_uses_source_macro",
                "check_intermediate_uses_ref",
                "check_marts_uses_ref",
                "check_edh_audit_columns",
                "check_snapshot_for_cdc",
                "check_snapshot_uses_check_strategy",
                "check_naming_conventions",
                "check_dbt_project_yml",
                "check_macros_exist",
                "check_todo_markers",
                "check_sorter_not_order_by",
                "check_schema_yml_consistency",
                "check_target_fields_in_marts",
            ]
            for check in checks:
                self.logger.info(f"  Would run: {check}")
            return []

        # Verify directories exist
        if not INPUTS_DIR.exists():
            self.logger.error(f"Inputs directory not found: {INPUTS_DIR}")
            return []
        if not OUTPUT_DIR.exists():
            self.logger.error(f"Output directory not found: {OUTPUT_DIR}")
            return []

        # Discover input JSON files
        input_files = sorted(INPUTS_DIR.glob("*.json"))
        if not input_files:
            self.logger.warning("No JSON files found in inputs/")
            return []

        self.logger.info(f"Found {len(input_files)} input JSON files")

        # Per-mapping checks
        for json_path in input_files:
            relative_path = f"inputs/{json_path.name}"
            self.logger.info(f"Validating against: {relative_path}")
            try:
                data = load_idmc_json(json_path)
            except (json.JSONDecodeError, OSError) as e:
                self.logger.error(f"Failed to load {json_path}: {e}")
                continue

            self.check_staging_completeness(relative_path, data)
            self.check_source_yml_completeness(relative_path, data)
            self.check_edh_audit_columns(relative_path, data)
            self.check_snapshot_for_cdc(relative_path, data)
            self.check_target_fields_in_marts(relative_path, data)

        # Cross-cutting checks (not per-mapping)
        self.check_staging_uses_source_macro()
        self.check_intermediate_uses_ref()
        self.check_marts_uses_ref()
        self.check_snapshot_uses_check_strategy()
        self.check_naming_conventions()
        self.check_dbt_project_yml()
        self.check_macros_exist()
        self.check_todo_markers()
        self.check_sorter_not_order_by()
        self.check_schema_yml_consistency()

        return self.issues

    # -------------------------------------------------------------------
    # Report generation
    # -------------------------------------------------------------------

    def generate_report(self) -> Dict[str, Any]:
        """Generate the full validation report with accuracy metric."""
        total_checks = len(self.issues) + len(self.passed_checks)
        passed_count = len(self.passed_checks)
        overall_accuracy = (
            round((passed_count / total_checks) * 100, 2)
            if total_checks > 0
            else 100.0
        )

        report = {
            "validation_report": {
                "timestamp": get_timestamp(),
                "overall_accuracy": overall_accuracy,
                "total_checks": total_checks,
                "passed_checks_count": passed_count,
                "issues_count": len(self.issues),
                "issues_by_severity": {
                    "high": len([i for i in self.issues if i["severity"] == "high"]),
                    "medium": len([i for i in self.issues if i["severity"] == "medium"]),
                    "low": len([i for i in self.issues if i["severity"] == "low"]),
                },
                "issues": self.issues,
                "passed_checks": self.passed_checks,
            }
        }
        return report

    def save_report(self, report: Dict[str, Any]) -> Path:
        """Save the validation report to the agentic log directory."""
        LOG_DIR.mkdir(parents=True, exist_ok=True)
        timestamp = get_timestamp().replace(" ", "_").replace(":", "")
        report_path = LOG_DIR / f"validation_report_{timestamp}.yaml"
        save_yaml(report, report_path)
        self.logger.info(f"Validation report saved to: {report_path}")
        return report_path

    def print_summary(self) -> None:
        """Print a human-readable summary to console."""
        total_checks = len(self.issues) + len(self.passed_checks)
        passed_count = len(self.passed_checks)
        accuracy = (
            round((passed_count / total_checks) * 100, 2)
            if total_checks > 0
            else 100.0
        )

        print("\n" + "=" * 60)
        print("VALIDATION SUMMARY")
        print("=" * 60)
        print(f"Total checks:     {total_checks}")
        print(f"Passed:           {passed_count}")
        print(f"Issues found:     {len(self.issues)}")
        print(f"Overall accuracy: {accuracy}%")
        print("-" * 60)

        severity_counts = {"high": 0, "medium": 0, "low": 0}
        for issue in self.issues:
            severity_counts[issue["severity"]] = (
                severity_counts.get(issue["severity"], 0) + 1
            )
        print(f"  High severity:   {severity_counts['high']}")
        print(f"  Medium severity: {severity_counts['medium']}")
        print(f"  Low severity:    {severity_counts['low']}")

        if self.issues:
            print("\nIssues:")
            for issue in self.issues:
                sev = issue["severity"].upper()
                print(
                    f"  [{issue['id']}] [{sev}] {issue['category']}: "
                    f"{issue['description']}"
                )
                print(
                    f"           source: {issue['source_file']} -> "
                    f"output: {issue['output_file']}"
                )

        print("=" * 60)


# ---------------------------------------------------------------------------
# CLI Entry Point
# ---------------------------------------------------------------------------

def main() -> None:
    """Run the IDMC-to-dbt validator from the command line."""
    parser = argparse.ArgumentParser(
        description="Validate IDMC-to-dbt output against JSON inputs"
    )
    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="List checks without running them",
    )
    parser.add_argument(
        "--files",
        nargs="*",
        help="Specific output files to validate (not yet implemented)",
    )
    args = parser.parse_args()

    validator = IDMCValidator(
        target_dir="output",
        dry_run=args.dry_run,
        specific_files=args.files,
    )
    validator.validate()
    report = validator.generate_report()
    validator.save_report(report)
    validator.print_summary()


if __name__ == "__main__":
    main()
