"""
DDL Generator — Generates Snowflake CREATE TABLE statements from parsed
Informatica XML repository data.

Uses:
- Strategy detector results for schema resolution
- DataTypeMapper for source-to-Snowflake type conversion
- TemplateEngine for SQL rendering

Usage:
    generator = DDLGenerator(database='MY_DB', schema='PUBLIC')
    results = generator.generate_from_repository(repository, strategies)
"""

import sys
from pathlib import Path
from typing import Any, Dict, List, Optional
from dataclasses import dataclass, field

sys.path.insert(0, str(Path(__file__).parent.parent))
from base.base_generator import BaseGenerator
from utils import setup_logging, get_timestamp, save_sql

from parsers.xml_parser import ParsedRepository, TargetTable, Column
from converter.strategy_detector import TableStrategy
from converter.datatype_mapper import DataTypeMapper, SourceSystem, MappedDataType
from generators.template_engine import TemplateEngine, TemplateConfig


@dataclass
class DDLResult:
    """Result of generating a DDL statement."""
    table_name: str
    schema: str
    ddl_sql: str
    column_count: int = 0
    warnings: List[str] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        return {
            'table_name': self.table_name,
            'schema': self.schema,
            'column_count': self.column_count,
            'warnings': self.warnings,
        }


class DDLGenerator(BaseGenerator):
    """Generates Snowflake DDL from parsed Informatica repository data."""

    # Map Informatica DATABASETYPE attribute to our SourceSystem enum
    DB_TYPE_TO_SOURCE_SYSTEM = {
        'oracle': SourceSystem.ORACLE,
        'microsoft sql server': SourceSystem.SQL_SERVER,
        'sql server': SourceSystem.SQL_SERVER,
        'sybase': SourceSystem.SQL_SERVER,
        'db2': SourceSystem.DB2,
        'db2 common server': SourceSystem.DB2,
        'teradata': SourceSystem.TERADATA,
        'informatica': SourceSystem.INFORMATICA,
        'vsam': SourceSystem.INFORMATICA,    # VSAM sources use Informatica types
        'flat file': SourceSystem.INFORMATICA,
    }

    def __init__(self, database: str = 'TARGET_DB', schema: str = 'PUBLIC',
                 warehouse: str = 'COMPUTE_WH', output_dir: str = 'output',
                 include_audit_columns: bool = True, include_comments: bool = True,
                 plans_dir: str = 'plans'):
        super().__init__(plans_dir, output_dir)
        self.database = database
        self.schema = schema
        self.warehouse = warehouse
        self.include_audit_columns = include_audit_columns
        self.include_comments = include_comments
        self.type_mapper = DataTypeMapper(source_system=SourceSystem.ORACLE)
        self.template_engine = TemplateEngine(TemplateConfig(
            database=database, default_schema=schema, warehouse=warehouse,
            include_comments=include_comments, include_audit_columns=include_audit_columns,
        ))
        self.logger = setup_logging('DDLGenerator')

    def _detect_source_system(self, target: TargetTable) -> SourceSystem:
        """Auto-detect the source system from the target's database_type attribute."""
        db_type = (target.database_type or '').strip().lower()
        return self.DB_TYPE_TO_SOURCE_SYSTEM.get(db_type, SourceSystem.ORACLE)

    def generate(self) -> None:
        """BaseGenerator interface."""
        self.logger.info("DDLGenerator.generate() called — use generate_from_repository().")

    def generate_from_repository(self, repository: ParsedRepository,
                                  strategies: List[TableStrategy],
                                  ddl_objects: Optional[Dict[str, Any]] = None) -> List[DDLResult]:
        """Generate DDL for all target tables in the repository.
        If ddl_objects (from DDL parser) are provided, use them for accurate types.
        """
        results: List[DDLResult] = []

        # Build strategy lookup
        strategy_map: Dict[str, TableStrategy] = {s.table_name: s for s in strategies}

        for mapping_name, mapping in repository.mappings.items():
            for target in mapping.targets:
                strategy = strategy_map.get(target.name)
                resolved_schema = strategy.schema if strategy else self.schema

                # Look up DDL columns from parsed DDL files
                ddl_columns = None
                if ddl_objects:
                    ddl_obj = ddl_objects.get(target.name.upper())
                    if ddl_obj:
                        ddl_columns = {c.name.upper(): c for c in ddl_obj.columns}

                result = self._generate_table_ddl(target, resolved_schema, ddl_columns)
                results.append(result)

                # Save to output
                output_path = self.output_dir / 'ddl' / f'{target.name}.sql'
                save_sql(result.ddl_sql, output_path)
                self.logger.info(f"DDL generated: {output_path}")

        self.logger.info(f"Generated {len(results)} DDL file(s)")
        return results

    def _generate_table_ddl(self, target: TargetTable, schema: str,
                             ddl_columns: Optional[Dict[str, 'DDLColumn']] = None) -> DDLResult:
        """Generate DDL for a single target table.
        If ddl_columns is provided (from DDL parser), use those types with precision.
        Otherwise, map from XML metadata with precision/length preservation.
        """
        warnings: List[str] = []
        columns = []

        # Auto-detect source system from target's database_type
        source_system = self._detect_source_system(target)

        for fld in target.columns:
            # If DDL parser provided real column definitions, use them
            if ddl_columns and fld.name.upper() in ddl_columns:
                ddl_col = ddl_columns[fld.name.upper()]
                columns.append({
                    'name': fld.name.upper(),
                    'datatype': ddl_col.datatype,
                    'nullable': ddl_col.nullable,
                    'default': ddl_col.default_value or '',
                })
                continue

            # Map data type using detected source system
            source_type = fld.datatype or 'VARCHAR'
            mapped = self.type_mapper.map_type(source_type, source_system=source_system)
            if mapped.warnings:
                warnings.extend(mapped.warnings)

            # Preserve precision/length from XML metadata when the mapper
            # returned a bare type (no size) but the XML has size info
            xml_precision = getattr(fld, 'precision', 0) or 0
            xml_scale = getattr(fld, 'scale', 0) or 0
            xml_length = getattr(fld, 'length', 0) or 0
            base_type = mapped.snowflake_type.split('(')[0]

            if mapped.length is None and mapped.precision is None:
                if base_type in ('VARCHAR', 'CHAR') and xml_precision > 0:
                    mapped.length = min(xml_precision, self.type_mapper.MAX_VARCHAR_SIZE)
                elif base_type in ('NUMBER', 'DECIMAL') and xml_precision > 0:
                    mapped.precision = min(xml_precision, 38)
                    mapped.scale = min(xml_scale, 37) if xml_scale else 0
            elif '(' in mapped.snowflake_type and base_type in ('NUMBER', 'DECIMAL') and xml_precision > 0:
                # Mapper already embedded precision in snowflake_type (e.g., NUMBER(38, 0)).
                # Override with XML metadata precision to avoid double-precision.
                mapped.snowflake_type = base_type
                mapped.precision = min(xml_precision, 38)
                mapped.scale = min(xml_scale, 37) if xml_scale else 0

            nullable = getattr(fld, 'nullable', True)
            default_val = getattr(fld, 'default_value', None) or ''

            columns.append({
                'name': fld.name.upper(),
                'datatype': mapped.full_type,
                'nullable': nullable,
                'default': default_val,
            })

        # Render via template engine
        context = {
            'table_name': target.name.upper(),
            'schema': schema,
            'database': self.database,
            'columns': columns,
            'comment': f'Migrated from Informatica PowerCenter - target {target.name}',
        }
        rendered = self.template_engine.render('ddl_table', context)
        warnings.extend(rendered.warnings)

        return DDLResult(
            table_name=target.name,
            schema=schema,
            ddl_sql=rendered.sql_content,
            column_count=len(columns),
            warnings=warnings,
        )


def main():
    print("DDLGenerator requires a ParsedRepository. Use via cli.py or orchestrator.")


if __name__ == '__main__':
    main()
