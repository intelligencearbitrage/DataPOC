"""
Procedure Generator — Generates Snowflake SQL-based stored procedures
wrapping the ETL logic for each mapping.

Each procedure:
- Uses LANGUAGE SQL (not JavaScript)
- Includes DECLARE section with V_PROC_NAME, V_BATCH_ID, V_STEP tracking
- Logs to PROCEDURE_LOG and PROCESS_LOG tables
- Includes pre/post SQL from session definitions
- Uses EXCEPTION WHEN OTHER THEN with RAISE for error handling
- Includes GRANT EXECUTE

Usage:
    generator = ProcedureGenerator(database='MY_DB', schema='PUBLIC')
    results = generator.generate_from_dml_results(dml_results, sessions)
"""

import sys
from pathlib import Path
from typing import Any, Dict, List, Optional
from dataclasses import dataclass, field

sys.path.insert(0, str(Path(__file__).parent.parent))
from base.base_generator import BaseGenerator
from utils import setup_logging, get_timestamp, save_sql

from generators.dml_generator import DMLResult
from generators.template_engine import TemplateEngine, TemplateConfig, generate_log_table_ddl
from parsers.xml_parser import Session


@dataclass
class ProcedureResult:
    """Result of generating a stored procedure."""
    procedure_name: str
    mapping_name: str
    target_table: str
    schema: str
    dml_type: str
    proc_sql: str
    has_pre_sql: bool = False
    has_post_sql: bool = False
    warnings: List[str] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        return {
            'procedure_name': self.procedure_name,
            'mapping_name': self.mapping_name,
            'target_table': self.target_table,
            'schema': self.schema,
            'dml_type': self.dml_type,
            'has_pre_sql': self.has_pre_sql,
            'has_post_sql': self.has_post_sql,
            'warnings': self.warnings,
        }


class ProcedureGenerator(BaseGenerator):
    """Generates Snowflake SQL-based stored procedures wrapping ETL logic."""

    def __init__(self, database: str = 'TARGET_DB', schema: str = 'PUBLIC',
                 warehouse: str = 'COMPUTE_WH', output_dir: str = 'output',
                 log_schema: Optional[str] = None, role: str = 'DATA_ENGINEER',
                 include_comments: bool = True, plans_dir: str = 'plans'):
        super().__init__(plans_dir, output_dir)
        self.database = database
        self.schema = schema
        self.warehouse = warehouse
        self.log_schema = log_schema or schema
        self.role = role
        self.include_comments = include_comments
        self.template_engine = TemplateEngine(TemplateConfig(
            database=database, default_schema=schema, warehouse=warehouse,
            include_comments=include_comments,
        ))
        self.logger = setup_logging('ProcedureGenerator')

    def generate(self) -> None:
        """BaseGenerator interface."""
        self.logger.info("ProcedureGenerator.generate() called — use generate_from_dml_results().")

    def generate_from_dml_results(self, dml_results: List[DMLResult],
                                   sessions: Optional[Dict[str, Session]] = None) -> List[ProcedureResult]:
        """Generate stored procedures from DML results."""
        results: List[ProcedureResult] = []
        sessions = sessions or {}

        # Generate log table DDL first
        log_ddl = generate_log_table_ddl(self.database, self.log_schema)
        log_path = self.output_dir / 'procedures' / '_log_tables.sql'
        save_sql(log_ddl, log_path)
        self.logger.info(f"Log table DDL generated: {log_path}")

        for dml in dml_results:
            result = self._generate_procedure(dml, sessions)
            results.append(result)

            output_path = self.output_dir / 'procedures' / f'{result.procedure_name}.sql'
            save_sql(result.proc_sql, output_path)
            self.logger.info(f"Procedure generated: {output_path}")

        self.logger.info(f"Generated {len(results)} stored procedures")
        return results

    def _generate_procedure(self, dml: DMLResult,
                             sessions: Dict[str, Session]) -> ProcedureResult:
        """Generate a single SQL-based stored procedure."""
        warnings = list(dml.warnings)
        proc_name = f"SP_LOAD_{dml.target_table}"

        # Find matching session for pre/post SQL
        pre_sql = ""
        post_sql = ""
        for sess_name, session in sessions.items():
            if session.mapping_name == dml.mapping_name:
                pre_sql = session.pre_sql or ''
                post_sql = session.post_sql or ''
                break

        # Indent the DML SQL for embedding in the procedure body
        main_sql_indented = self._indent_sql(dml.dml_sql, 4)
        pre_sql_indented = self._indent_sql(pre_sql, 4) if pre_sql else ''
        post_sql_indented = self._indent_sql(post_sql, 4) if post_sql else ''

        context = {
            'procedure_name': proc_name,
            'target_table': dml.target_table,
            'schema': dml.schema,
            'database': self.database,
            'mapping_name': dml.mapping_name,
            'dml_type': dml.dml_type,
            'source_name': f'{self.database}.{dml.schema}.{proc_name}',
            'main_sql': main_sql_indented,
            'pre_sql': pre_sql_indented,
            'post_sql': post_sql_indented,
            'log_schema': self.log_schema,
            'role': self.role,
            'comment': f'Load procedure for {dml.target_table} ({dml.dml_type})',
        }

        rendered = self.template_engine.render('procedure', context)
        warnings.extend(rendered.warnings)

        return ProcedureResult(
            procedure_name=proc_name,
            mapping_name=dml.mapping_name,
            target_table=dml.target_table,
            schema=dml.schema,
            dml_type=dml.dml_type,
            proc_sql=rendered.sql_content,
            has_pre_sql=bool(pre_sql),
            has_post_sql=bool(post_sql),
            warnings=warnings,
        )

    def _indent_sql(self, sql: str, spaces: int) -> str:
        """Indent multi-line SQL by a number of spaces."""
        if not sql or not sql.strip():
            return ''
        indent = ' ' * spaces
        return '\n'.join(indent + line for line in sql.strip().split('\n'))


def main():
    print("ProcedureGenerator requires DML results. Use via cli.py or orchestrator.")


if __name__ == '__main__':
    main()
