"""
DML Generator — Generates Snowflake INSERT/MERGE statements from parsed
Informatica mappings with translated expressions.

Uses:
- Strategy detector results to choose INSERT vs MERGE
- ExpressionTranslator for Informatica-to-Snowflake expression conversion
- TemplateEngine for SQL rendering

Usage:
    generator = DMLGenerator(database='MY_DB', schema='PUBLIC')
    results = generator.generate_from_mappings(repository, strategies)
"""

import sys
from pathlib import Path
from typing import Any, Dict, List, Optional
from dataclasses import dataclass, field

sys.path.insert(0, str(Path(__file__).parent.parent))
from base.base_generator import BaseGenerator
from utils import setup_logging, get_timestamp, save_sql

from parsers.xml_parser import ParsedRepository, Mapping, Transformation, TransformField, TargetTable, Column, InformaticaXMLParser
from converter.strategy_detector import TableStrategy
from converter.expression_translator import ExpressionTranslator
from generators.template_engine import TemplateEngine, TemplateConfig


@dataclass
class DMLResult:
    """Result of generating a DML statement."""
    mapping_name: str
    target_table: str
    schema: str
    dml_type: str           # INSERT or MERGE
    dml_sql: str
    source_tables: List[str] = field(default_factory=list)
    field_count: int = 0
    warnings: List[str] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        return {
            'mapping_name': self.mapping_name,
            'target_table': self.target_table,
            'schema': self.schema,
            'dml_type': self.dml_type,
            'source_tables': self.source_tables,
            'field_count': self.field_count,
            'warnings': self.warnings,
        }


class DMLGenerator(BaseGenerator):
    """Generates Snowflake DML (INSERT/MERGE) from parsed Informatica mappings."""

    def __init__(self, database: str = 'TARGET_DB', schema: str = 'PUBLIC',
                 warehouse: str = 'COMPUTE_WH', output_dir: str = 'output',
                 include_audit_columns: bool = True, include_comments: bool = True,
                 plans_dir: str = 'plans'):
        super().__init__(plans_dir, output_dir)
        self.database = database
        self.schema = schema
        self.warehouse = warehouse
        self.expr_translator = ExpressionTranslator()
        self.template_engine = TemplateEngine(TemplateConfig(
            database=database, default_schema=schema, warehouse=warehouse,
            include_comments=include_comments, include_audit_columns=include_audit_columns,
        ))
        self.logger = setup_logging('DMLGenerator')

    def generate(self) -> None:
        """BaseGenerator interface."""
        self.logger.info("DMLGenerator.generate() called — use generate_from_mappings().")

    def generate_from_mappings(self, repository: ParsedRepository,
                                strategies: List[TableStrategy],
                                parser: Optional['InformaticaXMLParser'] = None,
                                param_catalog=None) -> List[DMLResult]:
        """Generate DML for all mappings in the repository."""
        results: List[DMLResult] = []

        # Store param catalog for expression resolution
        self._param_catalog = param_catalog
        # Store repository for mapplet resolution
        self._repository = repository

        # Build reverse shortcut map: real_name -> set of shortcut_names
        self._reverse_shortcut_map: Dict[str, set] = {}
        if parser and hasattr(parser, '_shortcut_map'):
            for sc_name, (obj_type, real_name) in parser._shortcut_map.items():
                self._reverse_shortcut_map.setdefault(real_name, set()).add(sc_name)

        # Build strategy lookup
        strategy_map: Dict[str, TableStrategy] = {s.table_name: s for s in strategies}

        for mapping_name, mapping in repository.mappings.items():
            # Build connector-based lineage once per mapping
            self._connector_lineage = self._build_connector_lineage(mapping)

            for target in mapping.targets:
                strategy = strategy_map.get(target.name)
                dml_type = strategy.dml_strategy if strategy else 'INSERT'
                resolved_schema = strategy.schema if strategy else self.schema
                merge_keys = strategy.merge_keys if strategy else []

                result = self._generate_dml(mapping, target, dml_type,
                                            resolved_schema, merge_keys)
                results.append(result)

                # Save to output
                output_path = self.output_dir / 'dml' / f'{target.name}_{dml_type.lower()}.sql'
                save_sql(result.dml_sql, output_path)
                self.logger.info(f"DML generated: {output_path}")

        self.logger.info(f"Generated {len(results)} DML file(s)")
        return results

    def _generate_dml(self, mapping: Mapping, target, dml_type: str,
                      schema: str, merge_keys: List[str]) -> DMLResult:
        """Generate DML for a single mapping-target pair."""
        warnings: List[str] = []
        source_names = [s.name for s in mapping.sources]

        # Build field mappings with translated expressions
        field_mappings = self._build_field_mappings(mapping, target, warnings, mapping.name)

        # Build FROM clause from sources and lookups
        from_clause = self._build_from_clause(mapping, source_names, mapping.name)

        # Build WHERE clause from filter transformations and router groups
        where_clause = self._build_where_clause(mapping, target.name, mapping.name)

        # Column names for INSERT list
        columns = [fm['target_column'] for fm in field_mappings]

        # Determine update columns for MERGE (all non-key columns)
        update_columns = [c for c in columns if c not in merge_keys]

        # Build template context
        context = {
            'table_name': target.name.upper(),
            'schema': schema,
            'database': self.database,
            'mapping_name': mapping.name,
            'source_table': source_names[0] if source_names else 'UNKNOWN_SOURCE',
            'columns': columns,
            'field_mappings': field_mappings,
            'from_clause': from_clause,
            'where_clause': where_clause,
            'merge_keys': merge_keys,
            'update_columns': update_columns,
            'source_system': 'INFORMATICA_MIGRATION',
        }

        # Choose template based on strategy
        template_name = 'dml_merge_simple' if dml_type == 'MERGE' else 'dml_insert_simple'

        # Validate merge keys for MERGE
        if dml_type == 'MERGE' and not merge_keys:
            warnings.append(f"MERGE without merge keys for {target.name} — falling back to INSERT")
            template_name = 'dml_insert_simple'
            dml_type = 'INSERT'

        rendered = self.template_engine.render(template_name, context)
        warnings.extend(rendered.warnings)

        return DMLResult(
            mapping_name=mapping.name,
            target_table=target.name,
            schema=schema,
            dml_type=dml_type,
            dml_sql=rendered.sql_content,
            source_tables=source_names,
            field_count=len(field_mappings),
            warnings=warnings,
        )

    def _build_connector_lineage(self, mapping: Mapping) -> Dict[str, Dict[str, str]]:
        """Build connector-based lineage graph for a mapping.
        Returns: {target_name: {target_col: resolved_expression}}
        Uses the CONNECTOR elements to trace field-level lineage from target
        back through transformations to source columns.
        """
        # Build connector graph: (to_instance, to_field) -> (from_instance, from_field)
        connector_map: Dict[tuple, tuple] = {}
        for c in mapping.connectors:
            connector_map[(c.to_instance, c.to_field)] = (c.from_instance, c.from_field)

        # Build transformation lookup by name
        tx_lookup: Dict[str, Transformation] = {}
        for tx in mapping.transformations:
            tx_lookup[tx.name] = tx

        # Build instance name -> real target/source name mapping
        # (instances may use shortcut names)
        inst_to_real: Dict[str, str] = {}
        for target in mapping.targets:
            inst_to_real[target.name] = target.name
            # Also map shortcut names to real name
            if hasattr(self, '_reverse_shortcut_map'):
                for sc_name in self._reverse_shortcut_map.get(target.name, set()):
                    inst_to_real[sc_name] = target.name

        lineage: Dict[str, Dict[str, str]] = {}

        for target in mapping.targets:
            target_lineage: Dict[str, str] = {}

            # Find all instance names that refer to this target
            target_inst_names = {target.name}
            if hasattr(self, '_reverse_shortcut_map'):
                target_inst_names.update(self._reverse_shortcut_map.get(target.name, set()))

            for col in target.columns:
                # Try each possible instance name for this target
                expression = None
                for inst_name in target_inst_names:
                    expression = self._trace_connector_lineage(
                        inst_name, col.name, connector_map, tx_lookup, depth=0
                    )
                    if expression:
                        break

                if expression:
                    target_lineage[col.name.upper()] = expression
                # If no connector found, leave empty — _build_field_mappings will use pass-through

            lineage[target.name] = target_lineage

        return lineage

    def _trace_connector_lineage(self, to_instance: str, to_field: str,
                                  connector_map: Dict[tuple, tuple],
                                  tx_lookup: Dict[str, Transformation],
                                  depth: int = 0) -> Optional[str]:
        """Recursively trace a field back through the connector graph.
        Returns the Informatica expression or source column name.

        Handles:
        - Variable ports: When an OUTPUT port's expression references a LOCAL VARIABLE
          port in the same transformation, resolves to the variable's actual expression.
        - Router pass-through: When a Router OUTPUT port has no expression, strips
          the group suffix and traces back through the corresponding INPUT port.
        - Standard pass-through: When a port has no expression, traces upstream via connectors.
        """
        if depth > 20:  # Circuit breaker for cycles
            return None

        key = (to_instance, to_field)
        if key not in connector_map:
            return None

        from_instance, from_field = connector_map[key]

        # Check if from_instance is a transformation
        if from_instance in tx_lookup:
            tx = tx_lookup[from_instance]

            # Find the field in this transformation
            for fld in tx.fields:
                if fld.name.upper() == from_field.upper():
                    if fld.expression and fld.expression.strip():
                        expr = fld.expression.strip()
                        # Self-referential expression (expression = own name) means pass-through
                        if expr.upper() == fld.name.upper():
                            # Treat as pass-through — trace upstream
                            upstream = self._trace_connector_lineage(
                                from_instance, from_field, connector_map, tx_lookup, depth + 1
                            )
                            if upstream:
                                return upstream
                            return from_field
                        # Resolve variable/port references within the same transformation
                        resolved_expr = self._resolve_variable_ports(expr, tx, depth)
                        # Resolve remaining INPUT port references by tracing upstream
                        resolved_expr = self._resolve_input_port_refs(
                            resolved_expr, tx, from_instance, connector_map, tx_lookup, depth
                        )
                        resolved_upper = resolved_expr.strip().upper()
                        # Check if the resolved expression is still just a bare port name
                        # in this transformation (not a real expression)
                        is_bare_port = any(
                            f.name.upper() == resolved_upper for f in tx.fields
                        )
                        if is_bare_port:
                            # Still an internal port reference — trace it upstream via connectors
                            upstream = self._trace_connector_lineage(
                                from_instance, resolved_expr.strip(),
                                connector_map, tx_lookup, depth + 1
                            )
                            if upstream:
                                return upstream
                        return resolved_expr
                    # No expression — pass-through port
                    # For Router: OUTPUT ports with no expression have group-suffixed names
                    # (e.g., "o_COL3" for group index 3). Try stripping suffix and tracing
                    # back through the INPUT group port.
                    if tx.type == 'Router' and fld.group:
                        input_field = self._router_output_to_input(fld, tx)
                        if input_field:
                            upstream = self._trace_connector_lineage(
                                from_instance, input_field,
                                connector_map, tx_lookup, depth + 1
                            )
                            if upstream:
                                return upstream
                    # Custom Transformations (Union, etc.) with FIELDDEPENDENCY:
                    # OUTPUT ports map to INPUT ports via field dependencies, not connectors.
                    if hasattr(tx, 'field_dependencies') and tx.field_dependencies:
                        for dep in tx.field_dependencies:
                            if dep['output_field'].upper() == from_field.upper():
                                input_port = dep['input_field']
                                upstream = self._trace_connector_lineage(
                                    from_instance, input_port,
                                    connector_map, tx_lookup, depth + 1
                                )
                                if upstream:
                                    return upstream
                                break
                    # Custom Transformations (TokenStandardiser, etc.) without FIELDDEPENDENCY:
                    # Match OUTPUT to INPUT ports by stripping group suffixes and o_ prefix.
                    if tx.type == 'Custom Transformation' and fld.group:
                        input_port = self._custom_tx_output_to_input(fld, tx)
                        if input_port:
                            upstream = self._trace_connector_lineage(
                                from_instance, input_port,
                                connector_map, tx_lookup, depth + 1
                            )
                            if upstream:
                                return upstream
                    # Standard pass-through: trace further back via connectors
                    upstream = self._trace_connector_lineage(
                        from_instance, from_field, connector_map, tx_lookup, depth + 1
                    )
                    if upstream:
                        return upstream
                    return from_field

        # Check if from_instance is a mapplet — resolve through internal chain
        if hasattr(self, '_repository') and self._repository:
            mapplet = self._repository.mapplets.get(from_instance)
            if mapplet:
                resolved = self._trace_mapplet_lineage(mapplet, from_field, depth)
                if resolved:
                    return resolved

        # from_instance is a source table — return the source column name
        return from_field

    def _trace_mapplet_lineage(self, mapplet, from_field: str, depth: int = 0) -> Optional[str]:
        """Trace a field through a mapplet's internal transformation chain.

        Mapplets have:
        - Output Transformation: defines the mapplet's output ports (boundary)
        - Internal transformations and connectors wiring them together
        - The output field name on the mapplet interface maps to an Output Transformation port
        """
        # Build internal connector map and tx_lookup
        internal_connector_map: Dict[tuple, tuple] = {}
        for c in mapplet.connectors:
            internal_connector_map[(c.to_instance, c.to_field)] = (c.from_instance, c.from_field)

        internal_tx_lookup: Dict[str, 'Transformation'] = {}
        for tx in mapplet.transformations:
            internal_tx_lookup[tx.name] = tx

        # Find the Output Transformation that has from_field as a port
        for tx in mapplet.transformations:
            if tx.type == 'Output Transformation':
                for fld in tx.fields:
                    if fld.name.upper() == from_field.upper():
                        # Trace back from this Output Transformation port
                        result = self._trace_connector_lineage(
                            tx.name, fld.name,
                            internal_connector_map, internal_tx_lookup, depth + 1
                        )
                        if result:
                            return result

        # Fallback: check the Mapplet interface transformation itself
        for tx in mapplet.transformations:
            if tx.type == 'Mapplet':
                for fld in tx.fields:
                    if fld.name.upper() == from_field.upper() and fld.expression:
                        return fld.expression
        return None

    def _resolve_input_port_refs(self, expression: str, tx, instance_name: str,
                                  connector_map: Dict[tuple, tuple],
                                  tx_lookup: Dict[str, 'Transformation'],
                                  depth: int = 0) -> str:
        """Resolve INPUT port references in an expression by tracing them upstream.

        When an OUTPUT port's expression references an INPUT port that has no
        expression of its own (value comes from a connector), trace that INPUT
        port upstream to get the actual source expression or column name.
        """
        import re
        # Find INPUT-only ports with no expression in this transformation
        input_ports = {}
        for fld in tx.fields:
            if fld.port_type and 'INPUT' in fld.port_type.upper():
                if not fld.expression or fld.expression.strip() == '' or fld.expression.strip().upper() == fld.name.upper():
                    input_ports[fld.name.upper()] = fld.name

        if not input_ports:
            return expression

        result = expression
        for port_upper, port_name in sorted(input_ports.items(), key=lambda x: len(x[0]), reverse=True):
            pattern = r'\b' + re.escape(port_name) + r'\b'
            if re.search(pattern, result, re.IGNORECASE):
                # Trace this input port upstream
                upstream = self._trace_connector_lineage(
                    instance_name, port_name, connector_map, tx_lookup, depth + 1
                )
                if upstream and upstream.upper() != port_name.upper():
                    result = re.sub(pattern, upstream, result, flags=re.IGNORECASE)

        return result

    def _resolve_variable_ports(self, expression: str, tx: Transformation,
                                 depth: int = 0) -> str:
        """Resolve port references within the same transformation.
        Handles:
        - LOCAL VARIABLE ports (v_FOO with actual expressions)
        - INPUT/OUTPUT ports that reference other ports by name
        - Self-referential expressions (port expression = own name → pass-through)
        """
        if depth > 20:
            return expression

        expr_stripped = expression.strip()

        # Build lookup of all ports with expressions in this transformation
        # Priority: LOCAL VARIABLE ports first, then other ports with non-self-referencing expressions
        var_ports: Dict[str, str] = {}
        for fld in tx.fields:
            if fld.expression and fld.expression.strip():
                fld_expr = fld.expression.strip()
                # Skip self-referential expressions (port expression = own name)
                if fld_expr.upper() == fld.name.upper():
                    continue
                # Prioritize LOCAL VARIABLE ports
                if fld.port_type and 'VARIABLE' in fld.port_type.upper():
                    var_ports[fld.name.upper()] = fld_expr
        # Add non-variable ports (lower priority — only if not already covered)
        for fld in tx.fields:
            if fld.expression and fld.expression.strip():
                fld_expr = fld.expression.strip()
                if fld_expr.upper() == fld.name.upper():
                    continue
                if fld.name.upper() not in var_ports:
                    if fld.port_type and 'VARIABLE' not in fld.port_type.upper():
                        var_ports[fld.name.upper()] = fld_expr

        if not var_ports:
            return expression

        # Case 1: The entire expression is a single port reference
        if expr_stripped.upper() in var_ports:
            ref_expr = var_ports[expr_stripped.upper()]
            # Recursively resolve in case it references another port
            return self._resolve_variable_ports(ref_expr, tx, depth + 1)

        # Case 2: The expression contains port references as sub-expressions.
        import re
        result = expression
        changed = True
        iterations = 0
        while changed and iterations < 10:
            changed = False
            iterations += 1
            for port_name, port_expr in var_ports.items():
                pattern = r'\b' + re.escape(port_name) + r'\b'
                new_result = re.sub(pattern, f'({port_expr})', result, flags=re.IGNORECASE)
                if new_result != result:
                    result = new_result
                    changed = True
        return result

    def _router_output_to_input(self, output_field: TransformField,
                                 tx: Transformation) -> Optional[str]:
        """For a Router OUTPUT port with no expression, find the corresponding INPUT port.
        Uses REF_FIELD attribute if available (most reliable), otherwise falls back
        to stripping group suffixes from the port name.
        """
        # 1. Use REF_FIELD if available — this directly names the INPUT port
        if output_field.ref_field:
            return output_field.ref_field

        # 2. Fallback: strip group suffix from output port name to find INPUT port
        out_name = output_field.name
        group_name = output_field.group or ''

        base_candidates = set()

        # Strip known group suffixes
        if group_name:
            for suffix in [group_name, f'_{group_name}']:
                if out_name.endswith(suffix):
                    base_candidates.add(out_name[:-len(suffix)])

        # Try stripping numeric suffix (group index: 1, 2, 3, ...)
        import re
        m = re.match(r'^(.+?)(\d+)$', out_name)
        if m:
            base_candidates.add(m.group(1))

        # Find matching INPUT port
        for fld in tx.fields:
            if fld.port_type and 'INPUT' in fld.port_type.upper():
                fld_upper = fld.name.upper()
                for base in base_candidates:
                    if fld_upper == base.upper():
                        return fld.name

        return None

    def _custom_tx_output_to_input(self, output_field: TransformField,
                                     tx: Transformation) -> Optional[str]:
        """For a Custom Transformation OUTPUT port, find the corresponding INPUT port.
        Custom Transformations (TokenStandardiser, etc.) use group-suffixed port names:
        e.g., OUTPUT: o_SSN_NUMBER_Outputs → INPUT: SSN_NUMBER_Inputs
        """
        import re
        out_name = output_field.name
        out_group = output_field.group or ''

        # Strip group suffix from output name
        base_name = out_name
        if out_group and out_name.endswith(f'_{out_group}'):
            base_name = out_name[:-len(f'_{out_group}')]
        elif out_group and out_name.endswith(out_group):
            base_name = out_name[:-len(out_group)]

        # Strip o_ prefix if present
        for prefix in ['o_', 'O_']:
            if base_name.startswith(prefix):
                base_name = base_name[len(prefix):]
                break

        # Find matching INPUT port: base_name or base_name_<input_group>
        for fld in tx.fields:
            if fld.port_type and 'INPUT' in fld.port_type.upper():
                fld_name = fld.name
                fld_base = fld_name
                fld_group = fld.group or ''
                if fld_group and fld_name.endswith(f'_{fld_group}'):
                    fld_base = fld_name[:-len(f'_{fld_group}')]
                elif fld_group and fld_name.endswith(fld_group):
                    fld_base = fld_name[:-len(fld_group)]
                if fld_base.upper() == base_name.upper():
                    return fld.name

        return None

    def _build_field_mappings(self, mapping: Mapping, target,
                               warnings: List[str],
                               mapping_name: str = '') -> List[Dict[str, str]]:
        """Build field mappings with translated expressions for the target.
        Uses connector-based lineage when available, falls back to name-matching.
        """
        field_mappings: List[Dict[str, str]] = []

        # Get connector-based lineage for this target
        target_lineage = {}
        if hasattr(self, '_connector_lineage') and self._connector_lineage:
            target_lineage = self._connector_lineage.get(target.name, {})

        for fld in target.columns:
            field_name_upper = fld.name.upper()

            # 1. Try connector-based lineage first
            expression = target_lineage.get(field_name_upper)

            if expression:
                # Strip embedded developer comments (--...) that appear in some
                # Informatica expressions. These use \r\n line breaks and -- SQL comments.
                expression = self._strip_expression_comments(expression)
                # Resolve parameters BEFORE expression translation (so $$param gets
                # replaced with actual values before the translator converts them to :V_)
                if self._param_catalog:
                    expression = self._resolve_params_in_expression(expression, mapping_name)
                # Translate Informatica expression to Snowflake
                translated = self.expr_translator.translate(expression)
                if translated.warnings:
                    warnings.extend(translated.warnings)
                expr_sql = translated.translated
            else:
                # 2. Fall back to name-based matching across transformations
                fallback_expr = self._resolve_field_expression_fallback(fld.name, mapping)
                if fallback_expr:
                    if self._param_catalog:
                        fallback_expr = self._resolve_params_in_expression(fallback_expr, mapping_name)
                    translated = self.expr_translator.translate(fallback_expr)
                    if translated.warnings:
                        warnings.extend(translated.warnings)
                    expr_sql = translated.translated
                else:
                    # Direct column pass-through
                    expr_sql = field_name_upper

            field_mappings.append({
                'target_column': field_name_upper,
                'expression': expr_sql,
            })

        return field_mappings

    @staticmethod
    def _strip_expression_comments(expression: str) -> str:
        """Strip embedded developer comments from Informatica expressions.
        Informatica XML expressions may contain -- comments on separate lines
        (using \\r\\n or \\n line breaks). Remove these to prevent them from
        breaking the generated SQL.
        """
        import re
        # Remove lines that are purely comments (-- followed by text to end of line)
        lines = re.split(r'\r?\n', expression)
        cleaned = []
        for line in lines:
            stripped = line.strip()
            if stripped.startswith('--'):
                continue  # Skip pure comment lines
            # Also strip inline trailing comments (after expression content)
            # but only if not inside a string literal
            cleaned.append(line)
        result = '\n'.join(cleaned).strip()
        # Collapse multiple newlines into single space
        result = re.sub(r'\s*\n\s*', ' ', result)
        return result

    def _resolve_field_expression_fallback(self, field_name: str, mapping: Mapping) -> Optional[str]:
        """Fallback: find expression by matching field names across transformations."""
        for tx in reversed(mapping.transformations):
            for fld in tx.fields:
                if fld.name.upper() == field_name.upper() and fld.expression:
                    return fld.expression
        return None

    def _resolve_params_in_expression(self, expression: str, mapping_name: str = '') -> str:
        """Resolve $$param and $PM references using the parameter catalog.
        Tries matching session scope first, then global, then all scopes.
        """
        import re
        if not self._param_catalog:
            return expression

        def replacer(match):
            param_name = match.group(0)
            # Skip Informatica built-in variables like $PMWorkflowName
            if param_name.startswith('$PM') and not param_name.startswith('$Param'):
                return param_name

            clean_name = param_name.lstrip('$')
            prefixed = f"$${clean_name}"
            single = f"${clean_name}"
            search_keys = [param_name, prefixed, single, clean_name]

            def _find_param_value():
                # 1. Try session scope that matches the mapping name
                if mapping_name:
                    mapping_upper = mapping_name.upper()
                    for scope, params in self._param_catalog.session_params.items():
                        if mapping_upper in scope.upper():
                            for key in search_keys:
                                if key in params:
                                    return params[key].value

                # 2. Try global resolution
                resolved = self._param_catalog.resolve(param_name)
                if resolved is not None:
                    return resolved

                # 3. Search all session scopes as fallback
                for scope, params in self._param_catalog.session_params.items():
                    for key in search_keys:
                        if key in params:
                            return params[key].value

                return None

            value = _find_param_value()
            if value is None:
                return param_name

            # $$ params are typically values (constants), quote them
            # $ params (single) are typically identifiers (table names), leave as-is
            if param_name.startswith('$$'):
                # Quote the value as a string literal
                return f"'{value}'"
            # Single $ params: if it looks like a table/object name, use as-is
            return value

        return re.sub(r'\$\$?\w+', replacer, expression)

    def _build_from_clause(self, mapping: Mapping, source_names: List[str],
                            mapping_name: str = '') -> str:
        """Build FROM clause including JOINs for lookups and joiners."""
        if not source_names:
            return 'DUAL'

        # Check for SQL Override on Source Qualifier first
        sq = mapping.get_source_qualifier()
        if sq and sq.sql_query and sq.sql_query.strip():
            # Use the SQL override as the FROM clause
            sql_override = sq.sql_query.strip()
            # Resolve parameters before translation
            if hasattr(self, '_param_catalog') and self._param_catalog:
                sql_override = self._resolve_params_in_expression(sql_override, mapping_name)
            # Translate any Informatica-specific syntax
            translated = self.expr_translator.translate(sql_override)
            return f"(\n    {translated.translated}\n) AS SQ_OVERRIDE"

        # Start with primary source
        parts = [f"{self.database}.{self.schema}.{source_names[0]}"]

        # Add Joiner JOINs (with actual conditions from the transformation)
        for tx in mapping.transformations:
            if tx.type == 'Joiner':
                join_condition = getattr(tx, 'join_condition', '')
                join_type = getattr(tx, 'join_type', '').upper()
                # Map Informatica join types to SQL
                if 'FULL' in join_type:
                    sql_join = 'FULL OUTER JOIN'
                elif 'MASTER' in join_type or 'DETAIL' in join_type:
                    sql_join = 'LEFT JOIN'
                else:
                    sql_join = 'JOIN'
                # Resolve joiner internal port names (L_, PR_ prefixes) to real column names
                if join_condition:
                    join_condition = self._resolve_joiner_port_names(
                        join_condition, tx, mapping
                    )
                # Joiner typically joins the detail source to the master
                # Use additional sources if available
                if len(source_names) > 1:
                    detail_src = source_names[1]
                    if join_condition:
                        parts.append(
                            f"{sql_join} {self.database}.{self.schema}.{detail_src} "
                            f"ON {join_condition}"
                        )
                    else:
                        parts.append(
                            f"{sql_join} {self.database}.{self.schema}.{detail_src} "
                            f"/* TODO: add join condition for joiner {tx.name} */"
                        )
                    # Remove this source from the "additional sources" list
                    source_names = [source_names[0]] + source_names[2:]

        # Add lookup JOINs
        for tx in mapping.transformations:
            if tx.type == 'Lookup':
                lookup_table = getattr(tx, 'lookup_table', '') or tx.name
                lookup_condition = getattr(tx, 'lookup_condition', '')
                if lookup_table:
                    if lookup_condition:
                        parts.append(
                            f"LEFT JOIN {self.database}.{self.schema}.{lookup_table} "
                            f"ON {lookup_condition}"
                        )
                    else:
                        parts.append(
                            f"LEFT JOIN {self.database}.{self.schema}.{lookup_table} "
                            f"/* TODO: add join condition for lookup {tx.name} */"
                        )

        # Additional sources as JOINs (if multi-source, not already handled by Joiner)
        for src in source_names[1:]:
            parts.append(f"JOIN {self.database}.{self.schema}.{src} /* TODO: add join condition */")

        return "\n".join(parts)

    def _build_where_clause(self, mapping: Mapping, target_name: str = '',
                             mapping_name: str = '') -> str:
        """Build WHERE clause from filter transformations and router groups."""
        filters = []

        # Check for Filter transformations
        for tx in mapping.transformations:
            if tx.type == 'Filter':
                # Look for filter expression in fields (output port with expression)
                for fld in tx.fields:
                    if fld.expression and 'OUTPUT' in (fld.port_type or '').upper():
                        translated = self.expr_translator.translate(fld.expression)
                        filters.append(translated.translated)
                        break
                # Also check properties for filter condition
                condition = tx.properties.get('Filter Condition', '')
                if condition and not filters:
                    translated = self.expr_translator.translate(condition)
                    filters.append(translated.translated)

        # Check for Router groups — find which group feeds this target
        if target_name:
            router_filter = self._resolve_router_filter(mapping, target_name)
            if router_filter:
                # Resolve params before translation
                if hasattr(self, '_param_catalog') and self._param_catalog:
                    router_filter = self._resolve_params_in_expression(router_filter, mapping_name)
                translated = self.expr_translator.translate(router_filter)
                filters.append(translated.translated)

        return ' AND '.join(filters) if filters else ''

    def _resolve_router_filter(self, mapping: Mapping, target_name: str) -> str:
        """Find the Router group filter expression that feeds a specific target.
        Resolves Router INPUT port names in the expression to upstream source column names.
        """
        for tx in mapping.transformations:
            if tx.type != 'Router' or not tx.groups:
                continue

            # Build group_name -> expression lookup
            group_exprs: Dict[str, str] = {}
            for grp in tx.groups:
                if grp.get('expression'):
                    group_exprs[grp['name']] = grp['expression']

            # Find which group's fields connect to this target via connectors
            target_variants = {target_name}
            if hasattr(self, '_reverse_shortcut_map'):
                target_variants.update(self._reverse_shortcut_map.get(target_name, set()))
            for connector in mapping.connectors:
                if connector.from_instance == tx.name and connector.to_instance in target_variants:
                    for fld in tx.fields:
                        if fld.name == connector.from_field and fld.group:
                            if fld.group in group_exprs:
                                expr = group_exprs[fld.group]
                                # Resolve Router INPUT port names to upstream source columns
                                expr = self._resolve_router_input_ports(expr, tx, mapping)
                                return expr
                    break

        return ''

    def _resolve_router_input_ports(self, expression: str, router_tx: Transformation,
                                     mapping: Mapping) -> str:
        """Resolve Router INPUT port names in an expression to source column names.
        Uses the full connector lineage graph to trace port names to their origin.
        """
        import re

        if not hasattr(self, '_connector_lineage'):
            return expression

        # Build connector map for tracing
        connector_map: Dict[tuple, tuple] = {}
        for c in mapping.connectors:
            connector_map[(c.to_instance, c.to_field)] = (c.from_instance, c.from_field)

        tx_lookup: Dict[str, Transformation] = {tx.name: tx for tx in mapping.transformations}

        # Find Router INPUT ports and trace them to source columns
        input_port_map: Dict[str, str] = {}
        for fld in router_tx.fields:
            if fld.port_type and 'INPUT' in fld.port_type.upper():
                # Trace this INPUT port upstream to find the source column name
                # We want the final source column, not an intermediate expression
                source_col = self._trace_to_source_column(
                    router_tx.name, fld.name, connector_map, tx_lookup
                )
                if source_col and source_col.upper() != fld.name.upper():
                    input_port_map[fld.name.upper()] = source_col

        if not input_port_map:
            return expression

        result = expression
        for port_name in sorted(input_port_map.keys(), key=len, reverse=True):
            source_col = input_port_map[port_name]
            pattern = r'\b' + re.escape(port_name) + r'\b'
            result = re.sub(pattern, source_col, result, flags=re.IGNORECASE)

        return result

    def _trace_to_source_column(self, to_instance: str, to_field: str,
                                 connector_map: Dict[tuple, tuple],
                                 tx_lookup: Dict[str, Transformation],
                                 depth: int = 0) -> Optional[str]:
        """Trace a field back to its original source column name (not expression).
        Unlike _trace_connector_lineage which returns expressions, this returns
        just the final source column name for use in filter/join conditions.
        """
        if depth > 20:
            return to_field

        key = (to_instance, to_field)
        if key not in connector_map:
            # No connector feeds this port directly. If it's a transformation OUTPUT port,
            # try finding a matching INPUT port (strip o_ prefix) and trace that instead.
            if to_instance in tx_lookup:
                tx = tx_lookup[to_instance]
                input_port = self._find_matching_input_port(to_field, tx)
                if input_port:
                    return self._trace_to_source_column(
                        to_instance, input_port, connector_map, tx_lookup, depth + 1
                    )
            return to_field

        from_instance, from_field = connector_map[key]

        if from_instance in tx_lookup:
            # It's a transformation — keep tracing upstream
            return self._trace_to_source_column(
                from_instance, from_field, connector_map, tx_lookup, depth + 1
            )

        # Reached a source table — return the source column name
        return from_field

    def _find_matching_input_port(self, output_port_name: str,
                                   tx: Transformation) -> Optional[str]:
        """Find an INPUT port that corresponds to an OUTPUT port in the same transformation.
        Common naming: OUTPUT 'o_COL' corresponds to INPUT 'COL'.
        """
        # Strip common output prefixes
        base_name = output_port_name
        for prefix in ['o_', 'out_', 'O_', 'OUT_']:
            if base_name.startswith(prefix):
                base_name = base_name[len(prefix):]
                break

        for fld in tx.fields:
            if fld.port_type and 'INPUT' in fld.port_type.upper():
                if fld.name.upper() == base_name.upper():
                    return fld.name
                # Also try exact match (some pass-through ports keep the same name)
                if fld.name.upper() == output_port_name.upper():
                    return fld.name

        return None

    def _resolve_joiner_port_names(self, join_condition: str, joiner_tx: Transformation,
                                    mapping: Mapping) -> str:
        """Resolve Joiner internal port names (L_, PR_, etc.) to real source column names.
        Joiner ports are named with prefixes like 'L_RECORD_KEY' (left/master source)
        and 'PR_RECORD_KEY' (right/detail source). These internal names need to be
        mapped back to their upstream source column names via connectors.
        """
        import re

        # Build a map of joiner port names -> upstream source column names
        # by looking at connectors that feed INTO the joiner
        port_to_source: Dict[str, str] = {}

        for connector in mapping.connectors:
            if connector.to_instance == joiner_tx.name:
                # This connector feeds into the joiner
                # to_field is the joiner's internal port name (e.g., L_RECORD_KEY)
                # from_field is the upstream column name (e.g., RECORD_KEY)
                port_to_source[connector.to_field.upper()] = connector.from_field

        if not port_to_source:
            return join_condition

        # Replace each joiner port name in the condition with the real source column name
        result = join_condition
        # Sort by length descending to avoid partial replacements
        for port_name in sorted(port_to_source.keys(), key=len, reverse=True):
            source_col = port_to_source[port_name]
            # Replace as whole word
            pattern = r'\b' + re.escape(port_name) + r'\b'
            result = re.sub(pattern, source_col, result, flags=re.IGNORECASE)

        return result


def main():
    print("DMLGenerator requires a ParsedRepository. Use via cli.py or orchestrator.")


if __name__ == '__main__':
    main()
