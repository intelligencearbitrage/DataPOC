"""
Conversion Orchestrator — Simple conversion pipeline that chains parsers,
strategy detector, and generators to convert Informatica XML exports to
Snowflake SQL.

Pipeline (3 phases):
    1. Parse: XML → ParsedRepository (sources, targets, mappings, sessions, workflows)
       Optional: DDL files, parameter files
    2. Strategy Detection: Determine INSERT vs MERGE for each target, resolve schemas
    3. Generation: DDL + DML + Stored Procedures (no Task DAGs in simple mode)

Usage:
    orchestrator = ConversionOrchestrator(
        xml_dir='inputs/xml', output_dir='output',
        database='MY_DB', schema='MY_SCHEMA',
    )
    summary = orchestrator.run()
"""

import json
import sys
from pathlib import Path
from typing import Any, Dict, List, Optional
from dataclasses import dataclass, field

sys.path.insert(0, str(Path(__file__).parent.parent))
from utils import setup_logging, get_timestamp, save_json, save_yaml

from parsers.xml_parser import InformaticaXMLParser, ParsedRepository
from parsers.ddl_parser import DDLParser
from parsers.param_parser import ParamParser

from converter.strategy_detector import StrategyDetector, TableStrategy
from converter.expression_translator import ExpressionTranslator
from converter.datatype_mapper import DataTypeMapper

from generators.ddl_generator import DDLGenerator, DDLResult
from generators.dml_generator import DMLGenerator, DMLResult
from generators.procedure_generator import ProcedureGenerator, ProcedureResult


@dataclass
class ConversionSummary:
    """Summary of the full conversion run."""
    timestamp: str = ""
    # Parsing
    xml_files_parsed: int = 0
    sources_found: int = 0
    targets_found: int = 0
    mappings_found: int = 0
    sessions_found: int = 0
    workflows_found: int = 0
    # Strategy detection
    insert_tables: int = 0
    merge_tables: int = 0
    # Generation
    ddl_files_generated: int = 0
    dml_files_generated: int = 0
    procedures_generated: int = 0
    # Issues
    all_warnings: List[str] = field(default_factory=list)
    errors: List[str] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        return {
            'timestamp': self.timestamp,
            'parsing': {
                'xml_files_parsed': self.xml_files_parsed,
                'sources': self.sources_found,
                'targets': self.targets_found,
                'mappings': self.mappings_found,
                'sessions': self.sessions_found,
                'workflows': self.workflows_found,
            },
            'strategy_detection': {
                'insert_tables': self.insert_tables,
                'merge_tables': self.merge_tables,
            },
            'generation': {
                'ddl_files': self.ddl_files_generated,
                'dml_files': self.dml_files_generated,
                'procedures': self.procedures_generated,
            },
            'warnings': self.all_warnings,
            'errors': self.errors,
        }


class ConversionOrchestrator:
    """
    End-to-end orchestrator for simple Informatica XML → Snowflake SQL conversion.
    No medallion layers — preserves original schemas, auto-detects INSERT vs MERGE.
    """

    def __init__(self, xml_dir: str = 'inputs/xml',
                 ddl_dir: Optional[str] = None,
                 param_dir: Optional[str] = None,
                 output_dir: str = 'output',
                 database: str = 'TARGET_DB',
                 schema: str = 'PUBLIC',
                 warehouse: str = 'COMPUTE_WH',
                 include_audit_columns: bool = True,
                 include_comments: bool = True):
        self.xml_dir = xml_dir
        self.ddl_dir = ddl_dir
        self.param_dir = param_dir
        self.output_dir = Path(output_dir)
        self.database = database
        self.schema = schema
        self.warehouse = warehouse
        self.include_audit_columns = include_audit_columns
        self.include_comments = include_comments
        self.logger = setup_logging('ConversionOrchestrator')

    def run(self) -> ConversionSummary:
        """Execute the full conversion pipeline."""
        summary = ConversionSummary(timestamp=get_timestamp())
        self.logger.info("=" * 60)
        self.logger.info("INFAXML_Snowsql — Simple Conversion Pipeline Started")
        self.logger.info("=" * 60)

        # ── Phase 1: Parse ──────────────────────────────────────────
        self.logger.info("Phase 1: Parsing Informatica XMLs...")
        repository, xml_parser = self._phase_parse(summary)
        if not repository.mappings:
            summary.errors.append("No mappings found in XML files — aborting")
            self.logger.error("No mappings found. Check XML input directory.")
            self._save_summary(summary)
            return summary

        # Parse optional inputs (DDL, params) and retain results
        self.logger.info("Phase 1b: Parsing optional inputs (DDL, parameters)...")
        ddl_objects, param_catalog = self._phase_parse_optional(summary)

        # ── Phase 2: Strategy Detection ─────────────────────────────
        self.logger.info("Phase 2: Detecting DML strategies (INSERT/MERGE)...")
        strategies = self._phase_strategy_detection(repository, summary, ddl_objects)

        # ── Phase 3: Generation ─────────────────────────────────────
        self.logger.info("Phase 3a: Generating DDL...")
        ddl_results = self._phase_generate_ddl(repository, strategies, summary, ddl_objects)

        self.logger.info("Phase 3b: Generating DML...")
        dml_results = self._phase_generate_dml(repository, strategies, summary, xml_parser, param_catalog)

        self.logger.info("Phase 3c: Generating stored procedures...")
        proc_results = self._phase_generate_procedures(dml_results, repository, summary)

        # ── Save Summary ────────────────────────────────────────────
        self.logger.info("Saving conversion summary...")
        self._save_summary(summary)

        self.logger.info("=" * 60)
        self.logger.info("Conversion pipeline complete!")
        self.logger.info(f"  DDL:        {summary.ddl_files_generated} files")
        self.logger.info(f"  DML:        {summary.dml_files_generated} files")
        self.logger.info(f"  Procedures: {summary.procedures_generated} files")
        self.logger.info(f"  Warnings:   {len(summary.all_warnings)}")
        self.logger.info(f"  Errors:     {len(summary.errors)}")
        self.logger.info("=" * 60)

        return summary

    def _phase_parse(self, summary: ConversionSummary):
        """Phase 1: Parse Informatica XML files.
        Returns: (ParsedRepository, InformaticaXMLParser) — parser retained for shortcut map.
        """
        parser = InformaticaXMLParser(input_dir=self.xml_dir, output_dir=str(self.output_dir))
        parser.parse_all()
        repo = parser.get_repository()

        summary.xml_files_parsed = len(repo.xml_files_parsed)
        summary.sources_found = len(repo.sources)
        summary.targets_found = len(repo.targets)
        summary.mappings_found = len(repo.mappings)
        summary.sessions_found = len(repo.sessions)
        summary.workflows_found = len(repo.workflows)

        if repo.parse_errors:
            summary.errors.extend(repo.parse_errors)

        self.logger.info(f"  Parsed {summary.xml_files_parsed} XML file(s)")
        self.logger.info(f"  Sources: {summary.sources_found}, Targets: {summary.targets_found}")
        self.logger.info(f"  Mappings: {summary.mappings_found}, Sessions: {summary.sessions_found}")

        return repo, parser

    def _phase_parse_optional(self, summary: ConversionSummary):
        """Phase 1b: Parse optional DDL and parameter files.
        Returns: (ddl_objects dict or None, ParameterCatalog or None)
        """
        ddl_objects = None
        param_catalog = None

        if self.ddl_dir:
            ddl_parser = DDLParser(input_dir=self.ddl_dir)
            ddl_parser.parse_all()
            tables = ddl_parser.get_tables()
            views = ddl_parser.get_views()
            ddl_objects = {**tables, **views}
            self.logger.info(f"  Parsed {len(tables)} table(s), {len(views)} view(s) from DDL")

        if self.param_dir:
            param_parser = ParamParser(input_dir=self.param_dir)
            param_parser.parse_all()
            param_catalog = param_parser.get_catalog()
            self.logger.info(f"  Parsed {len(param_catalog.global_params)} global param(s), "
                             f"{len(param_catalog.session_params)} session scope(s)")

        return ddl_objects, param_catalog

    def _phase_strategy_detection(self, repository: ParsedRepository,
                                    summary: ConversionSummary,
                                    ddl_objects=None) -> List[TableStrategy]:
        """Phase 2: Detect INSERT vs MERGE strategy for each target table."""
        detector = StrategyDetector(default_schema=self.schema)
        strategies = detector.detect(repository, ddl_objects=ddl_objects)

        summary.insert_tables = sum(1 for s in strategies if s.dml_strategy == 'INSERT')
        summary.merge_tables = sum(1 for s in strategies if s.dml_strategy == 'MERGE')

        self.logger.info(f"  INSERT: {summary.insert_tables}, MERGE: {summary.merge_tables}")

        # Save strategy output
        strategies_path = self.output_dir / 'strategies.json'
        save_json({s.table_name: s.to_dict() for s in strategies}, strategies_path)

        return strategies

    def _phase_generate_ddl(self, repository: ParsedRepository,
                             strategies: List[TableStrategy],
                             summary: ConversionSummary,
                             ddl_objects=None) -> List[DDLResult]:
        """Phase 3a: Generate DDL."""
        ddl_gen = DDLGenerator(
            database=self.database, schema=self.schema,
            warehouse=self.warehouse, output_dir=str(self.output_dir),
            include_audit_columns=self.include_audit_columns,
            include_comments=self.include_comments,
        )
        results = ddl_gen.generate_from_repository(repository, strategies, ddl_objects=ddl_objects)
        summary.ddl_files_generated = len(results)
        for r in results:
            summary.all_warnings.extend(r.warnings)
        return results

    def _phase_generate_dml(self, repository: ParsedRepository,
                             strategies: List[TableStrategy],
                             summary: ConversionSummary,
                             xml_parser=None,
                             param_catalog=None) -> List[DMLResult]:
        """Phase 3b: Generate DML."""
        dml_gen = DMLGenerator(
            database=self.database, schema=self.schema,
            warehouse=self.warehouse, output_dir=str(self.output_dir),
            include_audit_columns=self.include_audit_columns,
            include_comments=self.include_comments,
        )
        results = dml_gen.generate_from_mappings(repository, strategies,
                                                  parser=xml_parser,
                                                  param_catalog=param_catalog)
        summary.dml_files_generated = len(results)
        for r in results:
            summary.all_warnings.extend(r.warnings)
        return results

    def _phase_generate_procedures(self, dml_results: List[DMLResult],
                                    repository: ParsedRepository,
                                    summary: ConversionSummary) -> List[ProcedureResult]:
        """Phase 3c: Generate stored procedures."""
        proc_gen = ProcedureGenerator(
            database=self.database, schema=self.schema,
            warehouse=self.warehouse, output_dir=str(self.output_dir),
            include_comments=self.include_comments,
        )
        results = proc_gen.generate_from_dml_results(dml_results, repository.sessions)
        summary.procedures_generated = len(results)
        for r in results:
            summary.all_warnings.extend(r.warnings)
        return results

    def _save_summary(self, summary: ConversionSummary) -> None:
        """Save the conversion summary to output directory."""
        summary_path = self.output_dir / 'conversion_summary.json'
        save_json(summary.to_dict(), summary_path)
        self.logger.info(f"Summary saved: {summary_path}")

        yaml_path = self.output_dir / 'conversion_summary.yaml'
        save_yaml(summary.to_dict(), yaml_path)


def main():
    """Run the orchestrator with default settings."""
    import argparse

    parser = argparse.ArgumentParser(description='INFAXML_Snowsql Conversion Orchestrator')
    parser.add_argument('--xml-dir', default='inputs/xml', help='Informatica XML directory')
    parser.add_argument('--ddl-dir', default=None, help='DDL files directory (optional)')
    parser.add_argument('--param-dir', default=None, help='Parameter files directory (optional)')
    parser.add_argument('--output', default='output', help='Output directory')
    parser.add_argument('--database', default='TARGET_DB', help='Snowflake database name')
    parser.add_argument('--schema', default='PUBLIC', help='Default Snowflake schema')
    parser.add_argument('--warehouse', default='COMPUTE_WH', help='Snowflake warehouse')
    args = parser.parse_args()

    orchestrator = ConversionOrchestrator(
        xml_dir=args.xml_dir,
        ddl_dir=args.ddl_dir,
        param_dir=args.param_dir,
        output_dir=args.output,
        database=args.database,
        schema=args.schema,
        warehouse=args.warehouse,
    )
    summary = orchestrator.run()
    print(f"\nConversion complete. Summary saved to {args.output}/conversion_summary.json")


if __name__ == '__main__':
    main()
