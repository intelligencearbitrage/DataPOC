"""
Template Engine — Jinja2-based SQL template rendering for Snowflake artifacts.

Provides embedded templates for DDL, DML (INSERT/MERGE), and stored procedures.
Falls back to string formatting if Jinja2 is not available.

Usage:
    engine = TemplateEngine(config)
    result = engine.render('ddl_table', context)
"""

import re
from typing import Any, Dict, List, Optional, Set
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum

try:
    from jinja2 import Environment, BaseLoader, TemplateNotFound, select_autoescape
    JINJA2_AVAILABLE = True
except ImportError:
    JINJA2_AVAILABLE = False


class TemplateType(Enum):
    """Types of SQL templates."""
    DDL_TABLE = "ddl_table"
    DML_INSERT = "dml_insert_simple"
    DML_MERGE = "dml_merge_simple"
    PROCEDURE = "procedure"


@dataclass
class TemplateConfig:
    """Configuration for template engine."""
    database: str = "TARGET_DB"
    warehouse: str = "COMPUTE_WH"
    default_schema: str = "PUBLIC"
    include_comments: bool = True
    include_audit_columns: bool = True
    audit_columns: List[str] = field(default_factory=lambda: [
        "DW_LOAD_TS",
        "DW_UPDATE_TS",
        "DW_SOURCE_SYSTEM",
    ])


@dataclass
class RenderedTemplate:
    """Result of template rendering."""
    template_type: TemplateType
    name: str
    sql_content: str
    warnings: List[str] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "template_type": self.template_type.value,
            "name": self.name,
            "warnings": self.warnings,
            "sql_content": self.sql_content,
        }


# ──────────────────────────────────────────────────────────────────────
#  Embedded SQL Templates
# ──────────────────────────────────────────────────────────────────────

EMBEDDED_TEMPLATES: Dict[str, str] = {

    # ── DDL ────────────────────────────────────────────────────────
    "ddl_table": """\
{%- if include_comments %}
-- =============================================================================
-- DDL: {{ database }}.{{ schema }}.{{ table_name }}
-- Generated: {{ generated_at }}
-- Source: Informatica PowerCenter Migration
-- =============================================================================
{% endif -%}
CREATE TABLE IF NOT EXISTS {{ database }}.{{ schema }}.{{ table_name }} (
{% for col in columns %}
    {{ col.name | upper }} {{ col.datatype }}{% if col.nullable == false %} NOT NULL{% endif %}{% if col.default %} DEFAULT {{ col.default }}{% endif %}{% if not loop.last or include_audit_columns %},{% endif %}
{% endfor %}
{% if include_audit_columns %}
    -- Audit columns
    DW_LOAD_TS TIMESTAMP_NTZ DEFAULT CURRENT_TIMESTAMP(),
    DW_UPDATE_TS TIMESTAMP_NTZ DEFAULT CURRENT_TIMESTAMP(),
    DW_SOURCE_SYSTEM VARCHAR(100)
{% endif %}
);
{% if include_comments %}
COMMENT ON TABLE {{ database }}.{{ schema }}.{{ table_name }} IS '{{ comment | default("Migrated from Informatica PowerCenter") }}';
{% endif %}
""",

    # ── DML INSERT ─────────────────────────────────────────────────
    "dml_insert_simple": """\
{%- if include_comments %}
-- =============================================================================
-- INSERT for {{ table_name }}
-- Mapping: {{ mapping_name }}
-- Source: {{ source_table }}
-- Generated: {{ generated_at }}
-- =============================================================================
{% endif -%}
INSERT INTO {{ database }}.{{ schema }}.{{ table_name }} (
    {{ columns | join(",\\n    ") }}{% if include_audit_columns %},
    DW_LOAD_TS,
    DW_UPDATE_TS,
    DW_SOURCE_SYSTEM{% endif %}
)
SELECT
{% for mapping in field_mappings %}
    {{ mapping.expression }} AS {{ mapping.target_column }}{% if not loop.last %},{% endif %}
{% endfor %}{% if include_audit_columns %},
    CURRENT_TIMESTAMP() AS DW_LOAD_TS,
    CURRENT_TIMESTAMP() AS DW_UPDATE_TS,
    '{{ source_system | default("INFORMATICA_MIGRATION") }}' AS DW_SOURCE_SYSTEM
{% endif %}
FROM {{ from_clause }}
{{ 'WHERE ' ~ where_clause if where_clause else '' }};
""",

    # ── DML MERGE ──────────────────────────────────────────────────
    "dml_merge_simple": """\
{%- if include_comments %}
-- =============================================================================
-- MERGE for {{ table_name }}
-- Mapping: {{ mapping_name }}
-- Source: {{ source_table }}
-- Generated: {{ generated_at }}
-- =============================================================================
{% endif -%}
MERGE INTO {{ database }}.{{ schema }}.{{ table_name }} AS TGT
USING (
    SELECT
{% for mapping in field_mappings %}
        {{ mapping.expression }} AS {{ mapping.target_column }}{% if not loop.last %},{% endif %}
{% endfor %}
    FROM {{ from_clause }}{% if where_clause %}
    WHERE {{ where_clause }}{% endif %}
) AS SRC
ON {% for key in merge_keys %}TGT.{{ key }} = SRC.{{ key }}{% if not loop.last %} AND {% endif %}{% endfor %}
WHEN MATCHED THEN UPDATE SET
{% for col in update_columns %}
    TGT.{{ col }} = SRC.{{ col }}{% if not loop.last %},{% endif %}
{% endfor %}{% if include_audit_columns %},
    TGT.DW_UPDATE_TS = CURRENT_TIMESTAMP(){% endif %}
WHEN NOT MATCHED THEN INSERT (
    {{ columns | join(",\\n    ") }}{% if include_audit_columns %},
    DW_LOAD_TS,
    DW_UPDATE_TS,
    DW_SOURCE_SYSTEM{% endif %}
) VALUES (
{% for col in columns %}
    SRC.{{ col }}{% if not loop.last %},{% endif %}
{% endfor %}{% if include_audit_columns %},
    CURRENT_TIMESTAMP(),
    CURRENT_TIMESTAMP(),
    '{{ source_system | default("INFORMATICA_MIGRATION") }}'{% endif %}
);
""",

    # ── PROCEDURE ──────────────────────────────────────────────────
    "procedure": """\
{%- if include_comments %}
/*******************************************************************************
 * Procedure: {{ procedure_name }}
 * Target: {{ target_table }}
 * DML Type: {{ dml_type }}
 * Mapping: {{ mapping_name }}
 * Generated: {{ generated_at }}
 ******************************************************************************/
{% endif -%}
CREATE OR REPLACE PROCEDURE {{ database }}.{{ schema }}.{{ procedure_name }}(
    P_BATCH_ID VARCHAR DEFAULT NULL
)
RETURNS VARCHAR
LANGUAGE SQL
EXECUTE AS CALLER
COMMENT = '{{ comment | default("Load procedure for " + target_table) }}'
AS
$$
DECLARE
    V_PROC_NAME VARCHAR := '{{ procedure_name }}';
    V_BATCH_ID VARCHAR := COALESCE(P_BATCH_ID, UUID_STRING());
    V_START_TIME TIMESTAMP_NTZ := CURRENT_TIMESTAMP();
    V_ROWS_AFFECTED INTEGER := 0;
    V_STEP VARCHAR := 'INIT';
    V_ERROR_MESSAGE VARCHAR;
    V_SRC_NM VARCHAR := '{{ source_name }}';
BEGIN
    -- Log procedure start
    INSERT INTO {{ database }}.{{ log_schema }}.PROCEDURE_LOG (
        PROC_NAME, BATCH_ID, STATUS, STEP, START_TIME, MESSAGE
    ) VALUES (
        :V_PROC_NAME, :V_BATCH_ID, 'RUNNING', 'START', :V_START_TIME, 'Procedure started'
    );
{% if pre_sql %}

    -- Pre-SQL from session
    V_STEP := 'PRE_SQL';
    {{ pre_sql }}
{% endif %}

    -- Main {{ dml_type }} operation
    V_STEP := 'MAIN_{{ dml_type }}';
    {{ main_sql }}

    GET DIAGNOSTICS V_ROWS_AFFECTED := ROW_COUNT;
{% if post_sql %}

    -- Post-SQL from session
    V_STEP := 'POST_SQL';
    {{ post_sql }}
{% endif %}

    -- Log success
    INSERT INTO {{ database }}.{{ log_schema }}.PROCEDURE_LOG (
        PROC_NAME, BATCH_ID, STATUS, STEP, START_TIME, END_TIME, ROWS_AFFECTED, MESSAGE
    ) VALUES (
        :V_PROC_NAME, :V_BATCH_ID, 'SUCCESS', 'COMPLETE', :V_START_TIME,
        CURRENT_TIMESTAMP(), :V_ROWS_AFFECTED, 'Procedure completed successfully'
    );

    -- PROCESS_LOG entry
    INSERT INTO {{ database }}.{{ log_schema }}.PROCESS_LOG (
        SOURCE_NAME, DETAIL, PHASE, ERROR_CODE, SEVERITY, ACTIVITY, PROCESS_TIME
    ) VALUES (
        :V_SRC_NM,
        :V_ROWS_AFFECTED || ' rows processed successfully',
        1, 0, 1,
        '{{ procedure_name }}',
        CURRENT_TIMESTAMP()
    );

    RETURN 'SUCCESS: ' || :V_ROWS_AFFECTED || ' rows loaded';

EXCEPTION
    WHEN OTHER THEN
        V_ERROR_MESSAGE := SQLERRM;

        -- Log failure
        INSERT INTO {{ database }}.{{ log_schema }}.PROCEDURE_LOG (
            PROC_NAME, BATCH_ID, STATUS, STEP, START_TIME, END_TIME, ERROR_MESSAGE, MESSAGE
        ) VALUES (
            :V_PROC_NAME, :V_BATCH_ID, 'FAILED', :V_STEP, :V_START_TIME,
            CURRENT_TIMESTAMP(), :V_ERROR_MESSAGE, 'Procedure failed at step: ' || :V_STEP
        );

        -- PROCESS_LOG error entry
        INSERT INTO {{ database }}.{{ log_schema }}.PROCESS_LOG (
            SOURCE_NAME, DETAIL, PHASE, ERROR_CODE, SEVERITY, ACTIVITY, PROCESS_TIME
        ) VALUES (
            :V_SRC_NM,
            :V_ERROR_MESSAGE,
            1, SQLCODE, 1,
            '{{ procedure_name }}',
            CURRENT_TIMESTAMP()
        );

        RAISE;
END;
$$;

GRANT EXECUTE ON PROCEDURE {{ database }}.{{ schema }}.{{ procedure_name }}(VARCHAR)
    TO ROLE {{ role | default("DATA_ENGINEER") }};
""",
}


# ──────────────────────────────────────────────────────────────────────
#  String Loader (for Jinja2)
# ──────────────────────────────────────────────────────────────────────

if JINJA2_AVAILABLE:
    class _StringLoader(BaseLoader):
        def __init__(self, templates: Dict[str, str]):
            self.templates = templates

        def get_source(self, environment, template_name):
            if template_name in self.templates:
                source = self.templates[template_name]
                return source, template_name, lambda: True
            raise TemplateNotFound(template_name)


# ──────────────────────────────────────────────────────────────────────
#  Template Engine
# ──────────────────────────────────────────────────────────────────────

class TemplateEngine:
    """Jinja2-based SQL template engine with embedded templates and custom filters."""

    def __init__(self, config: Optional[TemplateConfig] = None):
        self.config = config or TemplateConfig()

        if JINJA2_AVAILABLE:
            loader = _StringLoader(EMBEDDED_TEMPLATES)
            self.env = Environment(
                loader=loader,
                trim_blocks=True,
                lstrip_blocks=True,
                autoescape=select_autoescape(enabled_extensions=[], default_for_string=False, default=False),
            )
            # Custom filters
            self.env.filters['upper'] = str.upper
            self.env.filters['lower'] = str.lower
            self.env.filters['snake_case'] = lambda s: re.sub(r'[^a-zA-Z0-9]', '_', s).upper()
            self.env.filters['sql_quote'] = lambda s: f"'{s}'"
        else:
            self.env = None

    def render(self, template_name: str, context: Dict[str, Any]) -> RenderedTemplate:
        """Render a template with the given context."""
        # Inject default context from config
        full_context = {
            'database': self.config.database,
            'schema': self.config.default_schema,
            'warehouse': self.config.warehouse,
            'include_comments': self.config.include_comments,
            'include_audit_columns': self.config.include_audit_columns,
            'generated_at': datetime.now().isoformat(),
            'log_schema': self.config.default_schema,
        }
        full_context.update(context)

        warnings: List[str] = []

        if JINJA2_AVAILABLE and self.env:
            try:
                template = self.env.get_template(template_name)
                sql = template.render(**full_context)
            except Exception as e:
                warnings.append(f"Template rendering error: {e}")
                sql = self._fallback_render(template_name, full_context)
        else:
            warnings.append("Jinja2 not available, using fallback renderer")
            sql = self._fallback_render(template_name, full_context)

        # Map template name to TemplateType
        type_map = {
            'ddl_table': TemplateType.DDL_TABLE,
            'dml_insert_simple': TemplateType.DML_INSERT,
            'dml_merge_simple': TemplateType.DML_MERGE,
            'procedure': TemplateType.PROCEDURE,
        }
        ttype = type_map.get(template_name, TemplateType.DDL_TABLE)

        return RenderedTemplate(
            template_type=ttype,
            name=full_context.get('table_name', full_context.get('procedure_name', template_name)),
            sql_content=sql,
            warnings=warnings,
        )

    def _fallback_render(self, template_name: str, context: Dict[str, Any]) -> str:
        """Simple string-based fallback when Jinja2 is not available."""
        template_str = EMBEDDED_TEMPLATES.get(template_name, '')
        # Very basic variable substitution
        result = template_str
        for key, value in context.items():
            if isinstance(value, str):
                result = result.replace(f'{{{{ {key} }}}}', value)
        return result


def generate_log_table_ddl(database: str, schema: str) -> str:
    """Generate DDL for PROCEDURE_LOG and PROCESS_LOG tables."""
    return f"""-- Procedure Log Table
CREATE TABLE IF NOT EXISTS {database}.{schema}.PROCEDURE_LOG (
    LOG_ID NUMBER AUTOINCREMENT PRIMARY KEY,
    PROC_NAME VARCHAR(100) NOT NULL,
    BATCH_ID VARCHAR(36) NOT NULL,
    STATUS VARCHAR(20) NOT NULL,
    STEP VARCHAR(50),
    START_TIME TIMESTAMP_NTZ NOT NULL,
    END_TIME TIMESTAMP_NTZ,
    ROWS_AFFECTED INTEGER,
    ERROR_MESSAGE VARCHAR,
    MESSAGE VARCHAR,
    CREATED_AT TIMESTAMP_NTZ DEFAULT CURRENT_TIMESTAMP()
);

-- Process Log Table
CREATE TABLE IF NOT EXISTS {database}.{schema}.PROCESS_LOG (
    LOG_ID NUMBER AUTOINCREMENT PRIMARY KEY,
    SOURCE_NAME VARCHAR(200),
    DETAIL VARCHAR,
    PHASE INTEGER,
    ERROR_CODE INTEGER,
    SEVERITY INTEGER,
    ACTIVITY VARCHAR(200),
    PROCESS_TIME TIMESTAMP_NTZ DEFAULT CURRENT_TIMESTAMP()
);
"""
