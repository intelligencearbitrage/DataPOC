# INFAXML_Snowsql — Informatica XML to Snowflake SQL Converter

Direct conversion of Informatica PowerCenter XML exports to Snowflake SQL artifacts.

## Overview

INFAXML_Snowsql parses Informatica PowerCenter repository XML exports and generates
production-ready Snowflake SQL including DDL, DML, stored procedures, and Task DAGs.

## Quick Start

```bash
# Install dependencies
pip install -r requirements.txt

# Run full conversion pipeline
python cli.py convert \
    --xml-dir ./inputs \
    --output ./output \
    --database MEDALLION_DB \
    --warehouse MEDALLION_WH

# With optional DDLs and parameter files
python cli.py convert \
    --xml-dir ./inputs \
    --ddl-dir ./inputs/ddl \
    --param-dir ./inputs/params \
    --output ./output
```

## Inputs

| Input | Required | Description |
|-------|----------|-------------|
| Informatica XMLs | Yes | PowerCenter repository exports (`.xml`) |
| DDL files | No | SQL DDL for views/tables referenced by source qualifiers |
| Parameter files | No | Informatica parameter files (`.prm`, `.par`, `.txt`) |
| Workflow XMLs | No | Workflow definitions for task orchestration order |

## Outputs

| Output | Directory | Description |
|--------|-----------|-------------|
| DDL | `output/ddl/` | CREATE TABLE statements |
| DML | `output/dml/` | INSERT/MERGE statements with translated expressions |
| Procedures | `output/procedures/` | Snowflake stored procedures per mapping |
| Tasks | `output/tasks/` | Snowflake Task DAG for orchestration |
| Reports | `output/reports/` | Conversion summary and gap analysis |

## Pipeline Architecture

```
inputs/                    scripts/                   output/
├── *.xml          ──►    ├── parsers/        ──►    ├── ddl/
├── ddl/           ──►    │   ├── xml_parser         ├── dml/
├── params/        ──►    │   ├── ddl_parser         ├── procedures/
└── workflows/     ──►    │   └── param_parser       ├── tasks/
                          ├── converter/              └── reports/
                          │   ├── classifier
                          │   ├── expression_translator
                          │   ├── datatype_mapper
                          │   └── transformation_handler
                          └── generators/
                              ├── ddl_generator
                              ├── dml_generator
                              ├── procedure_generator
                              └── task_generator
```

## Directory Structure

| Folder | Purpose |
|--------|---------|
| `inputs/` | Source Informatica XMLs, DDLs, parameter files |
| `knowledgebase/` | Reference materials (type mappings, naming conventions) |
| `scripts/` | Python conversion pipeline |
| `output/` | Generated Snowflake SQL artifacts |
| `research/` | Analysis findings (agent team Phase 1) |
| `plans/` | Conversion plans (agent team Phase 2) |
| `testscripts/` | Validation scripts and reports (agent team Phase 4) |
| `guardrails/` | Quality enforcement scripts |

## Requirements

- Python 3.8+
- PyYAML
- lxml (for robust XML parsing)
