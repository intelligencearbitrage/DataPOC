"""
INFAXML_Snowsql - Scripts Package

Informatica XML to Snowflake SQL direct conversion pipeline.

This package contains:
- utils.py          : Shared utility functions
- base_parser.py    : Abstract base class for input parsers
- base_generator.py : Abstract base class for output generators
- base_validator.py : Abstract base class for output validators
- build_all.py      : Master script that runs all generators
- cli.py            : Command-line interface

Sub-packages:
- parsers/          : XML, DDL, and parameter file parsers
- converter/        : Classification, expression translation, data type mapping
- generators/       : DDL, DML, stored procedure, and task generators
"""
