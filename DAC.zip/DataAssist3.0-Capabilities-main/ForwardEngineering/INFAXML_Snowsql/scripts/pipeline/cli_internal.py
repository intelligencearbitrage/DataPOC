"""
CLI — Unified command-line interface for INFAXML_Snowsql.

Simple conversion of Informatica PowerCenter XML exports to Snowflake SQL.
No medallion layers — preserves original schemas, auto-detects INSERT vs MERGE.

Subcommands:
    convert   Run the full conversion pipeline (Parse → Detect Strategy → Generate)
    validate  Validate generated SQL output for completeness and correctness

Usage:
    python cli.py convert --xml-dir inputs/xml --output output --database MY_DB
    python cli.py validate --output output
"""

import argparse
import json
import os
import sys
from pathlib import Path

from werkzeug.utils import safe_join

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from utils import setup_logging, get_timestamp
from generators.orchestrator import ConversionOrchestrator

PROJECT_ROOT = Path(__file__).resolve().parent.parent
SAFE_ROOT = str(PROJECT_ROOT)


def cmd_convert(args: argparse.Namespace) -> int:
    """Run the full simple conversion pipeline."""
    logger = setup_logging('CLI-convert')
    logger.info("Starting INFAXML_Snowsql simple conversion...")

    _xml_raw = args.xml_dir
    if os.path.isabs(_xml_raw):
        _xml_raw = os.path.relpath(os.path.abspath(_xml_raw), SAFE_ROOT)
    xml_dir = safe_join(SAFE_ROOT, _xml_raw)
    if xml_dir is None:
        raise SystemExit(f"Error: xml-dir path '{args.xml_dir}' escapes the allowed directory.")

    ddl_dir = None
    if args.ddl_dir:
        _ddl_raw = args.ddl_dir
        if os.path.isabs(_ddl_raw):
            _ddl_raw = os.path.relpath(os.path.abspath(_ddl_raw), SAFE_ROOT)
        ddl_dir = safe_join(SAFE_ROOT, _ddl_raw)
        if ddl_dir is None:
            raise SystemExit(f"Error: ddl-dir path '{args.ddl_dir}' escapes the allowed directory.")

    param_dir = None
    if args.param_dir:
        _param_raw = args.param_dir
        if os.path.isabs(_param_raw):
            _param_raw = os.path.relpath(os.path.abspath(_param_raw), SAFE_ROOT)
        param_dir = safe_join(SAFE_ROOT, _param_raw)
        if param_dir is None:
            raise SystemExit(f"Error: param-dir path '{args.param_dir}' escapes the allowed directory.")

    _output_raw = args.output
    if os.path.isabs(_output_raw):
        _output_raw = os.path.relpath(os.path.abspath(_output_raw), SAFE_ROOT)
    output_dir = safe_join(SAFE_ROOT, _output_raw)
    if output_dir is None:
        raise SystemExit(f"Error: output path '{args.output}' escapes the allowed directory.")

    orchestrator = ConversionOrchestrator(
        xml_dir=xml_dir,
        ddl_dir=ddl_dir,
        param_dir=param_dir,
        output_dir=output_dir,
        database=args.database,
        schema=args.schema,
        warehouse=args.warehouse,
        include_audit_columns=not args.no_audit_columns,
        include_comments=not args.no_comments,
    )
    summary = orchestrator.run()

    print("\n" + "=" * 60)
    print("CONVERSION RESULTS")
    print("=" * 60)
    print(f"  XML files parsed:  {summary.xml_files_parsed}")
    print(f"  Sources found:     {summary.sources_found}")
    print(f"  Targets found:     {summary.targets_found}")
    print(f"  Mappings found:    {summary.mappings_found}")
    print(f"  Sessions found:    {summary.sessions_found}")
    print(f"  Workflows found:   {summary.workflows_found}")
    print()
    print("  Strategy Detection:")
    print(f"    INSERT tables:   {summary.insert_tables}")
    print(f"    MERGE tables:    {summary.merge_tables}")
    print()
    print("  Generated:")
    print(f"    DDL files:       {summary.ddl_files_generated}")
    print(f"    DML files:       {summary.dml_files_generated}")
    print(f"    Procedures:      {summary.procedures_generated}")
    print()
    if summary.all_warnings:
        print(f"  Warnings: {len(summary.all_warnings)}")
        for w in summary.all_warnings[:20]:
            print(f"    - {w}")
        if len(summary.all_warnings) > 20:
            print(f"    ... and {len(summary.all_warnings) - 20} more")
        print()
    if summary.errors:
        print(f"  Errors: {len(summary.errors)}")
        for e in summary.errors:
            print(f"    - {e}")
        print()
    print(f"  Output: {args.output}/")
    print(f"  Summary: {args.output}/conversion_summary.json")
    print("=" * 60)

    return 1 if summary.errors else 0


def cmd_validate(args: argparse.Namespace) -> int:
    """Validate generated output."""
    logger = setup_logging('CLI-validate')

    _output_raw = args.output
    if os.path.isabs(_output_raw):
        _output_raw = os.path.relpath(os.path.abspath(_output_raw), SAFE_ROOT)
    safe_output = safe_join(SAFE_ROOT, _output_raw)
    if safe_output is None:
        raise SystemExit(f"Error: output path '{args.output}' escapes the allowed directory.")
    output_dir = Path(safe_output)

    if not output_dir.exists():
        print(f"Error: Output directory '{output_dir}' does not exist.")
        return 1

    print("\n" + "=" * 60)
    print("VALIDATION REPORT")
    print("=" * 60)

    issues = []

    _summary_raw = str(output_dir / 'conversion_summary.json')
    if os.path.isabs(_summary_raw):
        _summary_raw = os.path.relpath(os.path.abspath(_summary_raw), SAFE_ROOT)
    safe_summary = safe_join(SAFE_ROOT, _summary_raw)
    if safe_summary is None:
        raise SystemExit("Error: summary path escapes the allowed directory.")
    summary_path = Path(safe_summary)
    if summary_path.exists():
        with open(safe_summary) as f:
            summary = json.load(f)
        print(f"  Summary file: OK")
    else:
        issues.append("conversion_summary.json not found")
        print(f"  Summary file: MISSING")

    ddl_dir = output_dir / 'ddl'
    ddl_files = list(ddl_dir.rglob('*.sql')) if ddl_dir.exists() else []
    print(f"  DDL files: {len(ddl_files)}")
    for f in ddl_files:
        content = f.read_text(encoding='utf-8')
        if 'CREATE' not in content.upper():
            issues.append(f"DDL file {f.name} missing CREATE statement")

    dml_dir = output_dir / 'dml'
    dml_files = list(dml_dir.rglob('*.sql')) if dml_dir.exists() else []
    print(f"  DML files: {len(dml_files)}")
    for f in dml_files:
        content = f.read_text(encoding='utf-8')
        if 'INSERT' not in content.upper() and 'MERGE' not in content.upper():
            issues.append(f"DML file {f.name} missing INSERT or MERGE statement")

    proc_dir = output_dir / 'procedures'
    proc_files = list(proc_dir.rglob('*.sql')) if proc_dir.exists() else []
    print(f"  Procedure files: {len(proc_files)}")
    for f in proc_files:
        if f.name.startswith('_'):
            continue
        content = f.read_text(encoding='utf-8')
        if 'CREATE OR REPLACE PROCEDURE' not in content.upper():
            issues.append(f"Procedure file {f.name} missing CREATE PROCEDURE statement")
        if 'LANGUAGE JAVASCRIPT' in content.upper():
            issues.append(f"Procedure {f.name} uses JavaScript — should be LANGUAGE SQL")

    all_sql_files = ddl_files + dml_files + proc_files
    infa_funcs = ['IIF(', 'ISNULL(', 'DECODE(', 'LTRIM(RTRIM(', 'SYSDATE', 'ADD_TO_DATE(']
    for f in all_sql_files:
        content = f.read_text(encoding='utf-8')
        for func in infa_funcs:
            if func in content:
                issues.append(f"{f.name}: possible untranslated Informatica function '{func}'")

    strategies_path = output_dir / 'strategies.json'
    if strategies_path.exists():
        print(f"  Strategy file: OK")
    else:
        issues.append("strategies.json not found")
        print(f"  Strategy file: MISSING")

    print()
    if issues:
        print(f"  Issues found: {len(issues)}")
        for issue in issues:
            print(f"    - {issue}")
    else:
        print("  No issues found.")

    total_files = len(ddl_files) + len(dml_files) + len(proc_files)
    print(f"\n  Total SQL files: {total_files}")
    print("=" * 60)

    return 1 if issues else 0


def main():
    parser = argparse.ArgumentParser(
        prog='infaxml_snowsql',
        description='INFAXML_Snowsql — Convert Informatica PowerCenter XML exports to Snowflake SQL (simple conversion)',
    )
    subparsers = parser.add_subparsers(dest='command', help='Available commands')

    convert_parser = subparsers.add_parser('convert', help='Run full conversion pipeline')
    convert_parser.add_argument('--xml-dir', required=True, help='Directory containing Informatica XML files')
    convert_parser.add_argument('--ddl-dir', default=None, help='Directory containing DDL files (optional)')
    convert_parser.add_argument('--param-dir', default=None, help='Directory containing parameter files (optional)')
    convert_parser.add_argument('--output', default='output', help='Output directory (default: output)')
    convert_parser.add_argument('--database', default='TARGET_DB', help='Snowflake database name')
    convert_parser.add_argument('--schema', default='PUBLIC', help='Default Snowflake schema name')
    convert_parser.add_argument('--warehouse', default='COMPUTE_WH', help='Snowflake warehouse name')
    convert_parser.add_argument('--no-audit-columns', action='store_true', help='Skip audit columns (DW_LOAD_TS, etc.)')
    convert_parser.add_argument('--no-comments', action='store_true', help='Skip SQL comments in output')

    validate_parser = subparsers.add_parser('validate', help='Validate generated output')
    validate_parser.add_argument('--output', default='output', help='Output directory to validate')

    args = parser.parse_args()

    if args.command == 'convert':
        sys.exit(cmd_convert(args))
    elif args.command == 'validate':
        sys.exit(cmd_validate(args))
    else:
        parser.print_help()
        sys.exit(1)


if __name__ == '__main__':
    main()
