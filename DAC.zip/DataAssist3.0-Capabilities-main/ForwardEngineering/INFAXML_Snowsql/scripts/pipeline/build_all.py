"""
Master Build Script - Discovers and runs all generator scripts.

Usage:
    python scripts/build_all.py
"""

import importlib
import sys
from pathlib import Path

SCRIPTS_DIR = Path(__file__).resolve().parent.parent
PROJECT_ROOT = SCRIPTS_DIR.parent
sys.path.insert(0, str(SCRIPTS_DIR))

from utils import setup_logging, get_timestamp, save_yaml


def discover_generators() -> list:
    """Find all generate_*.py scripts in the scripts/ directory."""
    generators = sorted(SCRIPTS_DIR.glob('generate_*.py'))
    return generators


def run_generator(script_path: Path, logger) -> dict:
    """Import and run a single generator script."""
    module_name = script_path.stem
    logger.info(f"Running: {module_name}")

    result = {'script': module_name, 'status': 'unknown', 'error': None}

    try:
        module = importlib.import_module(module_name)
        if hasattr(module, 'main'):
            module.main()
            result['status'] = 'success'
        else:
            result['status'] = 'skipped'
            result['error'] = f'{module_name} has no main() function'
            logger.warning(result['error'])
    except Exception as e:
        result['status'] = 'failed'
        result['error'] = str(e)
        logger.error(f"{module_name} failed: {e}")

    return result


def main():
    """Discover and run all generator scripts."""
    logger = setup_logging('build_all', log_dir=PROJECT_ROOT / 'thoughts' / 'logs')
    logger.info("=" * 60)
    logger.info("INFAXML_Snowsql Build All - Starting")
    logger.info("=" * 60)

    generators = discover_generators()

    if not generators:
        logger.warning("No generate_*.py scripts found in scripts/")
        logger.info("Use cli.py for the main conversion pipeline.")
        return

    logger.info(f"Found {len(generators)} generator(s): "
                f"{[g.stem for g in generators]}")

    results = []
    for gen_path in generators:
        result = run_generator(gen_path, logger)
        results.append(result)

    succeeded = sum(1 for r in results if r['status'] == 'success')
    failed = sum(1 for r in results if r['status'] == 'failed')
    skipped = sum(1 for r in results if r['status'] == 'skipped')

    logger.info("=" * 60)
    logger.info(f"Build Complete: {succeeded} succeeded, {failed} failed, {skipped} skipped")
    logger.info("=" * 60)

    report = {
        'build_report': {
            'timestamp': get_timestamp(),
            'generators_found': len(generators),
            'succeeded': succeeded,
            'failed': failed,
            'skipped': skipped,
            'results': results,
        }
    }
    save_yaml(report, PROJECT_ROOT / 'thoughts' / 'build_report.yaml')

    if failed > 0:
        logger.error(f"{failed} generator(s) failed. Check logs for details.")
        sys.exit(1)


if __name__ == '__main__':
    main()
