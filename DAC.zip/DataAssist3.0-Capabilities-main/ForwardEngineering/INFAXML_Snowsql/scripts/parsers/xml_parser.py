"""
Informatica XML Parser — Parses PowerCenter repository XML exports.

Extracts:
- Sources (source tables with columns and data types)
- Targets (target tables with columns and data types)
- Mappings (source-to-target mappings with transformation chains)
- Transformations (Expression, Filter, Lookup, Joiner, Aggregator, etc.)
- Sessions (session-level SQL overrides, pre/post SQL)
- Workflows (workflow structure and task ordering)

Usage:
    parser = InformaticaXMLParser(input_dir='inputs')
    parser.parse_all()
    mappings = parser.get_mappings()
"""

import re
import sys
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple
from dataclasses import dataclass, field

sys.path.insert(0, str(Path(__file__).parent.parent))
from base.base_parser import BaseParser
from utils import setup_logging

try:
    from lxml import etree
    USE_LXML = True
except ImportError:
    import xml.etree.ElementTree as etree
    USE_LXML = False


@dataclass
class Column:
    """Represents a source or target column."""
    name: str
    datatype: str
    precision: int = 0
    scale: int = 0
    length: int = 0
    nullable: bool = True
    description: str = ""

    def to_dict(self) -> Dict[str, Any]:
        return {
            'name': self.name,
            'datatype': self.datatype,
            'precision': self.precision,
            'scale': self.scale,
            'length': self.length,
            'nullable': self.nullable,
            'description': self.description,
        }


@dataclass
class SourceTable:
    """Represents an Informatica source definition."""
    name: str
    database_type: str = ""
    owner: str = ""
    columns: List[Column] = field(default_factory=list)
    description: str = ""

    def to_dict(self) -> Dict[str, Any]:
        return {
            'name': self.name,
            'database_type': self.database_type,
            'owner': self.owner,
            'columns': [c.to_dict() for c in self.columns],
            'description': self.description,
        }


@dataclass
class TargetTable:
    """Represents an Informatica target definition."""
    name: str
    database_type: str = ""
    owner: str = ""
    columns: List[Column] = field(default_factory=list)
    description: str = ""

    def to_dict(self) -> Dict[str, Any]:
        return {
            'name': self.name,
            'database_type': self.database_type,
            'owner': self.owner,
            'columns': [c.to_dict() for c in self.columns],
            'description': self.description,
        }


@dataclass
class TransformField:
    """A field within a transformation."""
    name: str
    datatype: str = ""
    precision: int = 0
    scale: int = 0
    expression: str = ""
    port_type: str = ""  # INPUT, OUTPUT, INPUT/OUTPUT, LOOKUP, VARIABLE
    default_value: str = ""
    group: str = ""
    ref_field: str = ""  # REF_FIELD — Router output ports reference their input port

    def to_dict(self) -> Dict[str, Any]:
        return {
            'name': self.name,
            'datatype': self.datatype,
            'precision': self.precision,
            'scale': self.scale,
            'expression': self.expression,
            'port_type': self.port_type,
            'default_value': self.default_value,
            'group': self.group,
        }


@dataclass
class Transformation:
    """Represents an Informatica transformation."""
    name: str
    type: str  # Source Qualifier, Expression, Filter, Lookup, etc.
    fields: List[TransformField] = field(default_factory=list)
    properties: Dict[str, str] = field(default_factory=dict)
    description: str = ""
    # For Source Qualifier
    sql_query: str = ""
    user_defined_join: str = ""
    source_filter: str = ""
    # For Lookup
    lookup_table: str = ""
    lookup_condition: str = ""
    lookup_sql_override: str = ""
    # For Joiner
    join_type: str = ""
    join_condition: str = ""
    # For Aggregator
    group_by_ports: List[str] = field(default_factory=list)
    # For Router
    groups: List[Dict[str, str]] = field(default_factory=list)
    # For Update Strategy
    update_strategy_expression: str = ""
    # For Stored Procedure
    sp_name: str = ""
    sp_type: str = ""
    # For Custom Transformations (Union, etc.) — maps INPUT→OUTPUT ports
    field_dependencies: List[Dict[str, str]] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        d = {
            'name': self.name,
            'type': self.type,
            'fields': [f.to_dict() for f in self.fields],
            'properties': self.properties,
            'description': self.description,
        }
        if self.sql_query:
            d['sql_query'] = self.sql_query
        if self.user_defined_join:
            d['user_defined_join'] = self.user_defined_join
        if self.source_filter:
            d['source_filter'] = self.source_filter
        if self.lookup_table:
            d['lookup_table'] = self.lookup_table
        if self.lookup_condition:
            d['lookup_condition'] = self.lookup_condition
        if self.lookup_sql_override:
            d['lookup_sql_override'] = self.lookup_sql_override
        if self.join_type:
            d['join_type'] = self.join_type
        if self.join_condition:
            d['join_condition'] = self.join_condition
        if self.group_by_ports:
            d['group_by_ports'] = self.group_by_ports
        if self.groups:
            d['groups'] = self.groups
        if self.update_strategy_expression:
            d['update_strategy_expression'] = self.update_strategy_expression
        if self.sp_name:
            d['sp_name'] = self.sp_name
        return d


@dataclass
class Connector:
    """Represents a connector between transformations in a mapping."""
    from_instance: str
    from_field: str
    to_instance: str
    to_field: str

    def to_dict(self) -> Dict[str, Any]:
        return {
            'from_instance': self.from_instance,
            'from_field': self.from_field,
            'to_instance': self.to_instance,
            'to_field': self.to_field,
        }


@dataclass
class Mapping:
    """Represents an Informatica mapping."""
    name: str
    description: str = ""
    sources: List[SourceTable] = field(default_factory=list)
    targets: List[TargetTable] = field(default_factory=list)
    transformations: List[Transformation] = field(default_factory=list)
    connectors: List[Connector] = field(default_factory=list)
    # Mapping-level properties
    properties: Dict[str, str] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        return {
            'name': self.name,
            'description': self.description,
            'sources': [s.to_dict() for s in self.sources],
            'targets': [t.to_dict() for t in self.targets],
            'transformations': [t.to_dict() for t in self.transformations],
            'connectors': [c.to_dict() for c in self.connectors],
            'properties': self.properties,
        }

    def get_source_qualifier(self) -> Optional[Transformation]:
        """Get the Source Qualifier transformation."""
        for tx in self.transformations:
            if tx.type == 'Source Qualifier':
                return tx
        return None

    def get_transformations_by_type(self, tx_type: str) -> List[Transformation]:
        """Get all transformations of a specific type."""
        return [tx for tx in self.transformations if tx.type == tx_type]

    def get_target_columns(self) -> Dict[str, List[Column]]:
        """Get all target columns grouped by target table name."""
        result = {}
        for t in self.targets:
            result[t.name] = t.columns
        return result

    def build_column_lineage(self) -> Dict[str, Dict[str, str]]:
        """Build column-level lineage from connectors.
        Returns: {target_table: {target_col: source_expression}}
        """
        # Build connector graph: to_instance.to_field -> from_instance.from_field
        connector_map: Dict[str, Tuple[str, str]] = {}
        for c in self.connectors:
            key = f"{c.to_instance}.{c.to_field}"
            connector_map[key] = (c.from_instance, c.from_field)

        # Build transformation lookup
        tx_lookup: Dict[str, Transformation] = {}
        for tx in self.transformations:
            tx_lookup[tx.name] = tx

        # Trace lineage for each target
        lineage: Dict[str, Dict[str, str]] = {}
        for target in self.targets:
            target_lineage: Dict[str, str] = {}
            for col in target.columns:
                # Find what connects to this target column
                key = f"{target.name}.{col.name}"
                if key in connector_map:
                    from_inst, from_field = connector_map[key]
                    # Check if source is a transformation with an expression
                    if from_inst in tx_lookup:
                        tx = tx_lookup[from_inst]
                        for f in tx.fields:
                            if f.name == from_field and f.expression:
                                target_lineage[col.name] = f.expression
                                break
                        else:
                            target_lineage[col.name] = from_field
                    else:
                        target_lineage[col.name] = from_field
                else:
                    target_lineage[col.name] = col.name
            lineage[target.name] = target_lineage

        return lineage


@dataclass
class Mapplet:
    """Represents an Informatica Mapplet — a reusable transformation sub-graph."""
    name: str
    transformations: List[Transformation] = field(default_factory=list)
    connectors: List[Connector] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        return {
            'name': self.name,
            'transformations': [t.to_dict() for t in self.transformations],
            'connectors': [c.to_dict() for c in self.connectors],
        }


@dataclass
class Session:
    """Represents an Informatica session."""
    name: str
    mapping_name: str = ""
    pre_sql: str = ""
    post_sql: str = ""
    properties: Dict[str, str] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        return {
            'name': self.name,
            'mapping_name': self.mapping_name,
            'pre_sql': self.pre_sql,
            'post_sql': self.post_sql,
            'properties': self.properties,
        }


@dataclass
class Workflow:
    """Represents an Informatica workflow."""
    name: str
    sessions: List[str] = field(default_factory=list)
    task_order: List[Dict[str, str]] = field(default_factory=list)
    properties: Dict[str, str] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        return {
            'name': self.name,
            'sessions': self.sessions,
            'task_order': self.task_order,
            'properties': self.properties,
        }


@dataclass
class ParsedRepository:
    """Complete parsed Informatica repository."""
    sources: Dict[str, SourceTable] = field(default_factory=dict)
    targets: Dict[str, TargetTable] = field(default_factory=dict)
    mappings: Dict[str, Mapping] = field(default_factory=dict)
    mapplets: Dict[str, Mapplet] = field(default_factory=dict)
    sessions: Dict[str, Session] = field(default_factory=dict)
    workflows: Dict[str, Workflow] = field(default_factory=dict)
    xml_files_parsed: List[str] = field(default_factory=list)
    parse_errors: List[str] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        return {
            'sources': {k: v.to_dict() for k, v in self.sources.items()},
            'targets': {k: v.to_dict() for k, v in self.targets.items()},
            'mappings': {k: v.to_dict() for k, v in self.mappings.items()},
            'mapplets': {k: v.to_dict() for k, v in self.mapplets.items()},
            'sessions': {k: v.to_dict() for k, v in self.sessions.items()},
            'workflows': {k: v.to_dict() for k, v in self.workflows.items()},
            'xml_files_parsed': self.xml_files_parsed,
            'parse_errors': self.parse_errors,
            'statistics': {
                'total_sources': len(self.sources),
                'total_targets': len(self.targets),
                'total_mappings': len(self.mappings),
                'total_mapplets': len(self.mapplets),
                'total_sessions': len(self.sessions),
                'total_workflows': len(self.workflows),
            }
        }


class InformaticaXMLParser(BaseParser):
    """
    Parses Informatica PowerCenter XML exports.

    Handles both individual mapping XMLs and full repository exports.
    Extracts sources, targets, mappings, transformations, sessions, and workflows.
    """

    def __init__(self, input_dir: str = 'inputs', output_dir: str = 'output'):
        super().__init__(input_dir, output_dir)
        self.repository = ParsedRepository()
        # Shortcut resolution: shortcut_name -> (object_type, real_name)
        self._shortcut_map: Dict[str, Tuple[str, str]] = {}

    def discover_files(self) -> List[Path]:
        """Find all XML files in the input directory."""
        xml_files = []
        for pattern in ['*.xml', '*.XML']:
            xml_files.extend(self.input_dir.glob(pattern))
        return sorted(set(xml_files))

    def parse_file(self, file_path: Path) -> Dict[str, Any]:
        """Parse a single Informatica XML file."""
        self.logger.info(f"Parsing XML: {file_path.name}")

        try:
            if USE_LXML:
                parser = etree.XMLParser(recover=True, encoding='utf-8')
                tree = etree.parse(str(file_path), parser)
            else:
                tree = etree.parse(str(file_path))
            root = tree.getroot()
        except Exception as e:
            error_msg = f"Failed to parse XML {file_path.name}: {e}"
            self.repository.parse_errors.append(error_msg)
            self.logger.error(error_msg)
            return {'error': error_msg}

        self.repository.xml_files_parsed.append(str(file_path))

        # Parse all FOLDER elements (Informatica organizes by folder)
        folders = root.findall('.//FOLDER') or [root]

        for folder in folders:
            self._parse_shortcuts(folder)
            self._parse_sources(folder)
            self._parse_targets(folder)
            self._parse_mapplets(folder)
            self._parse_mappings(folder)
            self._parse_sessions(folder)
            self._parse_workflows(folder)

        # Also parse top-level elements (some exports don't use FOLDER)
        if not root.findall('.//FOLDER'):
            self._parse_shortcuts(root)
            self._parse_sources(root)
            self._parse_targets(root)
            self._parse_mapplets(root)
            self._parse_mappings(root)
            self._parse_sessions(root)
            self._parse_workflows(root)

        return {
            'file': file_path.name,
            'sources': len(self.repository.sources),
            'targets': len(self.repository.targets),
            'mappings': len(self.repository.mappings),
        }

    def _parse_columns(self, parent_element) -> List[Column]:
        """Parse SOURCEFIELD or TARGETFIELD elements into Column objects."""
        columns = []
        for field_tag in ['SOURCEFIELD', 'TARGETFIELD', 'TRANSFORMFIELD']:
            for field_elem in parent_element.findall(field_tag):
                col = Column(
                    name=field_elem.get('NAME', ''),
                    datatype=field_elem.get('DATATYPE', field_elem.get('PORTTYPE', '')),
                    precision=int(field_elem.get('PRECISION', '0') or '0'),
                    scale=int(field_elem.get('SCALE', '0') or '0'),
                    length=int(field_elem.get('LENGTH', '0') or '0'),
                    nullable=field_elem.get('NULLABLE', 'YES') != 'NOTNULL',
                    description=field_elem.get('DESCRIPTION', ''),
                )
                if col.name:
                    columns.append(col)
        return columns

    def _parse_shortcuts(self, parent) -> None:
        """Parse SHORTCUT elements to build shortcut_name -> real_name mapping."""
        for sc_elem in parent.findall('.//SHORTCUT'):
            sc_name = sc_elem.get('NAME', '')
            ref_name = sc_elem.get('REFOBJECTNAME', '')
            obj_type = sc_elem.get('OBJECTTYPE', '').upper()
            if sc_name and ref_name:
                self._shortcut_map[sc_name] = (obj_type, ref_name)

    def _resolve_shortcut(self, name: str) -> str:
        """Resolve a shortcut name to its real object name."""
        if name in self._shortcut_map:
            return self._shortcut_map[name][1]
        return name

    def _parse_sources(self, parent) -> None:
        """Parse SOURCE elements."""
        for src_elem in parent.findall('.//SOURCE'):
            name = src_elem.get('NAME', '')
            if not name or name in self.repository.sources:
                continue
            source = SourceTable(
                name=name,
                database_type=src_elem.get('DATABASETYPE', src_elem.get('DBDNAME', '')),
                owner=src_elem.get('OWNERNAME', ''),
                columns=self._parse_columns(src_elem),
                description=src_elem.get('DESCRIPTION', ''),
            )
            self.repository.sources[name] = source

    def _parse_targets(self, parent) -> None:
        """Parse TARGET elements."""
        for tgt_elem in parent.findall('.//TARGET'):
            name = tgt_elem.get('NAME', '')
            if not name or name in self.repository.targets:
                continue
            target = TargetTable(
                name=name,
                database_type=tgt_elem.get('DATABASETYPE', tgt_elem.get('DBDNAME', '')),
                owner=tgt_elem.get('OWNERNAME', ''),
                columns=self._parse_columns(tgt_elem),
                description=tgt_elem.get('DESCRIPTION', ''),
            )
            self.repository.targets[name] = target

    def _parse_connectors(self, parent) -> List[Connector]:
        """Parse CONNECTOR elements from a parent element."""
        connectors = []
        for conn_elem in parent.findall('CONNECTOR'):
            connector = Connector(
                from_instance=conn_elem.get('FROMINSTANCE', ''),
                from_field=conn_elem.get('FROMFIELD', ''),
                to_instance=conn_elem.get('TOINSTANCE', ''),
                to_field=conn_elem.get('TOFIELD', ''),
            )
            if connector.from_instance and connector.to_instance:
                connectors.append(connector)
        return connectors

    def _parse_mapplets(self, parent) -> None:
        """Parse MAPPLET elements — reusable transformation sub-graphs."""
        for mplt_elem in parent.findall('MAPPLET'):
            name = mplt_elem.get('NAME', '')
            if not name or name in self.repository.mapplets:
                continue

            mapplet = Mapplet(name=name)

            # Parse internal transformations
            for tx_elem in mplt_elem.findall('TRANSFORMATION'):
                tx = self._parse_transformation(tx_elem)
                mapplet.transformations.append(tx)

            # Parse internal connectors
            mapplet.connectors = self._parse_connectors(mplt_elem)

            self.repository.mapplets[name] = mapplet
            self.logger.debug(f"Parsed mapplet: {name} ({len(mapplet.transformations)} transforms, {len(mapplet.connectors)} connectors)")

    def _parse_transformation(self, tx_elem) -> Transformation:
        """Parse a TRANSFORMATION element."""
        tx = Transformation(
            name=tx_elem.get('NAME', ''),
            type=tx_elem.get('TYPE', ''),
            description=tx_elem.get('DESCRIPTION', ''),
        )

        # Parse fields/ports
        for field_elem in tx_elem.findall('TRANSFORMFIELD'):
            tf = TransformField(
                name=field_elem.get('NAME', ''),
                datatype=field_elem.get('DATATYPE', ''),
                precision=int(field_elem.get('PRECISION', '0') or '0'),
                scale=int(field_elem.get('SCALE', '0') or '0'),
                expression=field_elem.get('EXPRESSION', ''),
                port_type=field_elem.get('PORTTYPE', ''),
                default_value=field_elem.get('DEFAULTVALUE', ''),
                group=field_elem.get('GROUP', ''),
                ref_field=field_elem.get('REF_FIELD', ''),
            )
            tx.fields.append(tf)

        # Parse table attributes (properties)
        for attr_elem in tx_elem.findall('TABLEATTRIBUTE'):
            attr_name = attr_elem.get('NAME', '')
            attr_value = attr_elem.get('VALUE', '')
            tx.properties[attr_name] = attr_value

            # Extract specific properties
            if attr_name == 'Sql Query':
                tx.sql_query = attr_value
            elif attr_name == 'User Defined Join':
                tx.user_defined_join = attr_value
            elif attr_name == 'Source Filter':
                tx.source_filter = attr_value
            elif attr_name == 'Lookup Sql Override':
                tx.lookup_sql_override = attr_value
            elif attr_name == 'Lookup condition':
                tx.lookup_condition = attr_value
            elif attr_name == 'Lookup table name':
                tx.lookup_table = attr_value
            elif attr_name == 'Join Condition':
                tx.join_condition = attr_value
            elif attr_name == 'Join Type':
                tx.join_type = attr_value
            elif attr_name == 'Update Strategy Expression':
                tx.update_strategy_expression = attr_value
            elif attr_name == 'Stored Procedure Name':
                tx.sp_name = attr_value
            elif attr_name == 'Stored Procedure Type':
                tx.sp_type = attr_value

        # Parse group info for Router/Aggregator
        for group_elem in tx_elem.findall('GROUP'):
            group_info = {
                'name': group_elem.get('NAME', ''),
                'expression': group_elem.get('EXPRESSION', ''),
                'type': group_elem.get('TYPE', ''),
            }
            tx.groups.append(group_info)

        # Parse field dependencies for Custom Transformations (Union, etc.)
        for dep_elem in tx_elem.findall('FIELDDEPENDENCY'):
            dep = {
                'input_field': dep_elem.get('INPUTFIELD', ''),
                'output_field': dep_elem.get('OUTPUTFIELD', ''),
            }
            tx.field_dependencies.append(dep)

        # Identify group-by ports for Aggregator
        if tx.type == 'Aggregator':
            tx.group_by_ports = [
                f.name for f in tx.fields
                if f.port_type and 'GROUP BY' in f.port_type.upper()
            ]

        return tx

    def _parse_mappings(self, parent) -> None:
        """Parse MAPPING elements."""
        for map_elem in parent.findall('.//MAPPING'):
            name = map_elem.get('NAME', '')
            if not name or name in self.repository.mappings:
                continue

            mapping = Mapping(
                name=name,
                description=map_elem.get('DESCRIPTION', ''),
            )

            # Parse transformations within the mapping
            for tx_elem in map_elem.findall('TRANSFORMATION'):
                tx = self._parse_transformation(tx_elem)
                mapping.transformations.append(tx)

            # Parse instances to find source/target references
            for inst_elem in map_elem.findall('INSTANCE'):
                inst_type = inst_elem.get('TYPE', '')
                inst_name = inst_elem.get('NAME', '')
                transformation_name = inst_elem.get('TRANSFORMATION_NAME', '')

                if inst_type == 'SOURCE':
                    src_name = transformation_name or inst_name
                    # Resolve shortcut to real source name
                    resolved_name = self._resolve_shortcut(src_name)
                    if resolved_name in self.repository.sources:
                        mapping.sources.append(self.repository.sources[resolved_name])
                    elif src_name in self.repository.sources:
                        mapping.sources.append(self.repository.sources[src_name])
                    else:
                        self.logger.warning(
                            f"Mapping {name}: source '{src_name}' (resolved: '{resolved_name}') "
                            f"not found in repository"
                        )
                elif inst_type == 'TARGET':
                    tgt_name = transformation_name or inst_name
                    # Resolve shortcut to real target name
                    resolved_name = self._resolve_shortcut(tgt_name)
                    if resolved_name in self.repository.targets:
                        mapping.targets.append(self.repository.targets[resolved_name])
                    elif tgt_name in self.repository.targets:
                        mapping.targets.append(self.repository.targets[tgt_name])
                    else:
                        self.logger.warning(
                            f"Mapping {name}: target '{tgt_name}' (resolved: '{resolved_name}') "
                            f"not found in repository"
                        )

            # Parse connectors
            for conn_elem in map_elem.findall('CONNECTOR'):
                connector = Connector(
                    from_instance=conn_elem.get('FROMINSTANCE', ''),
                    from_field=conn_elem.get('FROMFIELD', ''),
                    to_instance=conn_elem.get('TOINSTANCE', ''),
                    to_field=conn_elem.get('TOFIELD', ''),
                )
                mapping.connectors.append(connector)

            # Parse mapping-level properties
            for attr_elem in map_elem.findall('MAPPINGVARIABLE'):
                var_name = attr_elem.get('NAME', '')
                var_value = attr_elem.get('DEFAULTVALUE', '')
                mapping.properties[var_name] = var_value

            self.repository.mappings[name] = mapping

    def _parse_sessions(self, parent) -> None:
        """Parse SESSION elements."""
        for sess_elem in parent.findall('.//SESSION'):
            name = sess_elem.get('NAME', '')
            if not name or name in self.repository.sessions:
                continue

            session = Session(
                name=name,
                mapping_name=sess_elem.get('MAPPINGNAME', ''),
            )

            # Parse session properties
            for attr_elem in sess_elem.findall('.//ATTRIBUTE'):
                attr_name = attr_elem.get('NAME', '')
                attr_value = attr_elem.get('VALUE', '')
                session.properties[attr_name] = attr_value

                if attr_name == 'Pre SQL':
                    session.pre_sql = attr_value
                elif attr_name == 'Post SQL':
                    session.post_sql = attr_value

            # Also check SESSTRANSFORMATIONINST for SQL overrides
            for inst in sess_elem.findall('.//SESSTRANSFORMATIONINST'):
                for attr in inst.findall('ATTRIBUTE'):
                    aname = attr.get('NAME', '')
                    avalue = attr.get('VALUE', '')
                    if aname in ('Pre SQL', 'Pre-session SQL'):
                        session.pre_sql = avalue
                    elif aname in ('Post SQL', 'Post-session SQL'):
                        session.post_sql = avalue

            self.repository.sessions[name] = session

    def _parse_workflows(self, parent) -> None:
        """Parse WORKFLOW elements."""
        for wf_elem in parent.findall('.//WORKFLOW'):
            name = wf_elem.get('NAME', '')
            if not name or name in self.repository.workflows:
                continue

            workflow = Workflow(name=name)

            # Find session references
            for task_elem in wf_elem.findall('.//TASKINSTANCE'):
                task_name = task_elem.get('NAME', '')
                task_type = task_elem.get('TASKTYPE', '')
                if task_type == 'Session':
                    workflow.sessions.append(task_name)

            # Parse task ordering (WORKFLOWLINK)
            for link_elem in wf_elem.findall('.//WORKFLOWLINK'):
                workflow.task_order.append({
                    'from': link_elem.get('FROMTASK', ''),
                    'to': link_elem.get('TOTASK', ''),
                    'condition': link_elem.get('CONDITION', ''),
                })

            self.repository.workflows[name] = workflow

    def get_repository(self) -> ParsedRepository:
        """Get the complete parsed repository."""
        return self.repository

    def get_mappings(self) -> Dict[str, Mapping]:
        """Get all parsed mappings."""
        return self.repository.mappings

    def get_sources(self) -> Dict[str, SourceTable]:
        """Get all parsed source tables."""
        return self.repository.sources

    def get_targets(self) -> Dict[str, TargetTable]:
        """Get all parsed target tables."""
        return self.repository.targets


def main():
    """Standalone usage example."""
    import sys
    input_dir = sys.argv[1] if len(sys.argv) > 1 else 'inputs'
    parser = InformaticaXMLParser(input_dir=input_dir)
    parser.parse_all()
    repo = parser.get_repository()
    print(f"Parsed: {len(repo.sources)} sources, {len(repo.targets)} targets, "
          f"{len(repo.mappings)} mappings, {len(repo.sessions)} sessions, "
          f"{len(repo.workflows)} workflows")
    if repo.parse_errors:
        print(f"Errors: {len(repo.parse_errors)}")
        for err in repo.parse_errors:
            print(f"  - {err}")


if __name__ == '__main__':
    main()
