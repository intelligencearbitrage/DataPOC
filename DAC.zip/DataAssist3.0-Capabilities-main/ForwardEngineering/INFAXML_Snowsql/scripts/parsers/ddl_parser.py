"""
DDL Parser — Parses SQL DDL files for view/table definitions.

Extracts CREATE TABLE and CREATE VIEW statements, their columns,
joins, and WHERE clauses. Used to resolve view references in
Informatica Source Qualifiers.

Usage:
    parser = DDLParser(input_dir='inputs/ddl')
    parser.parse_all()
    views = parser.get_views()
"""

import re
import sys
from pathlib import Path
from typing import Any, Dict, List, Optional
from dataclasses import dataclass, field

sys.path.insert(0, str(Path(__file__).parent.parent))
from base.base_parser import BaseParser


@dataclass
class DDLColumn:
    """A column from a DDL statement."""
    name: str
    datatype: str = ""
    nullable: bool = True
    default_value: str = ""
    is_primary_key: bool = False


@dataclass
class DDLObject:
    """A parsed DDL object (table or view)."""
    name: str
    object_type: str  # TABLE or VIEW
    schema: str = ""
    database: str = ""
    columns: List[DDLColumn] = field(default_factory=list)
    sql_text: str = ""
    # View-specific
    select_query: str = ""
    source_tables: List[str] = field(default_factory=list)
    joins: List[str] = field(default_factory=list)
    where_clause: str = ""
    select_distinct: bool = False

    @property
    def full_qualified_name(self) -> str:
        parts = []
        if self.database:
            parts.append(self.database)
        if self.schema:
            parts.append(self.schema)
        parts.append(self.name)
        return '.'.join(parts)

    def to_dict(self) -> Dict[str, Any]:
        return {
            'name': self.name,
            'object_type': self.object_type,
            'schema': self.schema,
            'database': self.database,
            'full_qualified_name': self.full_qualified_name,
            'columns': [{'name': c.name, 'datatype': c.datatype, 'nullable': c.nullable}
                        for c in self.columns],
            'sql_text': self.sql_text,
            'select_query': self.select_query,
            'source_tables': self.source_tables,
            'joins': self.joins,
            'where_clause': self.where_clause,
        }


class DDLParser(BaseParser):
    """
    Parses SQL DDL files containing CREATE TABLE and CREATE VIEW statements.
    """

    def __init__(self, input_dir: str = 'inputs/ddl', output_dir: str = 'output'):
        super().__init__(input_dir, output_dir)
        self.objects: Dict[str, DDLObject] = {}

    def discover_files(self) -> List[Path]:
        """Find all SQL files in the DDL directory."""
        sql_files = []
        for pattern in ['*.sql', '*.ddl', '*.SQL', '*.DDL']:
            sql_files.extend(self.input_dir.glob(pattern))
        return sorted(set(sql_files))

    def parse_file(self, file_path: Path) -> Dict[str, Any]:
        """Parse a single DDL file."""
        content = file_path.read_text(encoding='utf-8', errors='replace')
        tables_found = 0
        views_found = 0

        # Split by statement terminator
        statements = re.split(r';\s*\n', content)

        for stmt in statements:
            stmt = stmt.strip()
            if not stmt:
                continue

            # Parse CREATE TABLE
            table_match = re.search(
                r'CREATE\s+(?:OR\s+REPLACE\s+)?TABLE\s+(?:IF\s+NOT\s+EXISTS\s+)?'
                r'([^\s(]+)\s*\(',
                stmt, re.IGNORECASE
            )
            if table_match:
                obj = self._parse_create_table(table_match.group(1), stmt)
                if obj:
                    self.objects[obj.name.upper()] = obj
                    tables_found += 1
                continue

            # Parse CREATE VIEW
            view_match = re.search(
                r'CREATE\s+(?:OR\s+REPLACE\s+)?VIEW\s+'
                r'([^\s(]+)\s+AS\s+',
                stmt, re.IGNORECASE
            )
            if view_match:
                obj = self._parse_create_view(view_match.group(1), stmt)
                if obj:
                    self.objects[obj.name.upper()] = obj
                    views_found += 1

        return {
            'file': file_path.name,
            'tables': tables_found,
            'views': views_found,
        }

    def _parse_name_parts(self, full_name: str) -> tuple:
        """Parse a potentially qualified name into (database, schema, name)."""
        parts = full_name.replace('"', '').replace('`', '').split('.')
        if len(parts) == 3:
            return parts[0], parts[1], parts[2]
        elif len(parts) == 2:
            return '', parts[0], parts[1]
        else:
            return '', '', parts[0]

    def _parse_create_table(self, name: str, sql: str) -> Optional[DDLObject]:
        """Parse a CREATE TABLE statement."""
        db, schema, table_name = self._parse_name_parts(name)
        obj = DDLObject(
            name=table_name,
            object_type='TABLE',
            schema=schema,
            database=db,
            sql_text=sql,
        )

        # Extract column definitions
        col_match = re.search(r'\((.*)\)', sql, re.DOTALL)
        if col_match:
            col_text = col_match.group(1)
            for line in col_text.split(','):
                line = line.strip()
                if not line or re.match(r'(PRIMARY|FOREIGN|UNIQUE|CHECK|CONSTRAINT|INDEX)', line, re.IGNORECASE):
                    continue
                parts = line.split()
                if len(parts) >= 2:
                    col = DDLColumn(
                        name=parts[0].strip('"').strip('`'),
                        datatype=' '.join(parts[1:3]) if len(parts) > 2 else parts[1],
                        nullable='NOT NULL' not in line.upper(),
                    )
                    obj.columns.append(col)

        return obj

    def _parse_create_view(self, name: str, sql: str) -> Optional[DDLObject]:
        """Parse a CREATE VIEW statement."""
        db, schema, view_name = self._parse_name_parts(name)
        obj = DDLObject(
            name=view_name,
            object_type='VIEW',
            schema=schema,
            database=db,
            sql_text=sql,
        )

        # Extract the SELECT query
        as_match = re.search(r'\bAS\s+(SELECT\b.+)', sql, re.IGNORECASE | re.DOTALL)
        if as_match:
            obj.select_query = as_match.group(1).strip()
            obj.select_distinct = bool(re.search(r'SELECT\s+DISTINCT', obj.select_query, re.IGNORECASE))

            # Extract source tables from FROM clause
            from_match = re.search(r'\bFROM\s+(.+?)(?:\bWHERE\b|\bGROUP\b|\bORDER\b|\bHAVING\b|$)',
                                   obj.select_query, re.IGNORECASE | re.DOTALL)
            if from_match:
                from_clause = from_match.group(1)
                # Extract table names
                tables = re.findall(r'[\w.]+', from_clause)
                obj.source_tables = [t for t in tables
                                     if t.upper() not in ('JOIN', 'LEFT', 'RIGHT', 'INNER',
                                                          'OUTER', 'CROSS', 'ON', 'AS', 'FULL')]

            # Extract joins
            obj.joins = re.findall(r'((?:LEFT|RIGHT|INNER|OUTER|CROSS|FULL)?\s*JOIN\s+\S+\s+ON\s+[^)]+)',
                                   obj.select_query, re.IGNORECASE)

            # Extract WHERE clause
            where_match = re.search(r'\bWHERE\s+(.+?)(?:\bGROUP\b|\bORDER\b|\bHAVING\b|$)',
                                    obj.select_query, re.IGNORECASE | re.DOTALL)
            if where_match:
                obj.where_clause = where_match.group(1).strip()

        return obj

    def get_views(self) -> Dict[str, DDLObject]:
        """Get all parsed views."""
        return {k: v for k, v in self.objects.items() if v.object_type == 'VIEW'}

    def get_tables(self) -> Dict[str, DDLObject]:
        """Get all parsed tables."""
        return {k: v for k, v in self.objects.items() if v.object_type == 'TABLE'}

    def get_object(self, name: str) -> Optional[DDLObject]:
        """Look up a DDL object by name (case-insensitive)."""
        return self.objects.get(name.upper())


def main():
    import sys
    input_dir = sys.argv[1] if len(sys.argv) > 1 else 'inputs/ddl'
    parser = DDLParser(input_dir=input_dir)
    parser.parse_all()
    print(f"Parsed: {len(parser.get_tables())} tables, {len(parser.get_views())} views")


if __name__ == '__main__':
    main()
