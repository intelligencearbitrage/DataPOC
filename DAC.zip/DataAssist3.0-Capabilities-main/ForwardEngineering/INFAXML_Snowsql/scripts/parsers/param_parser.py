"""
Parameter File Parser — Parses Informatica parameter files.

Handles .prm, .par, and .txt parameter files with formats:
- [Session.s_session_name]
- $$PARAM_NAME=value
- $PARAM_NAME=value

Usage:
    parser = ParamParser(input_dir='inputs/params')
    parser.parse_all()
    params = parser.get_params()
    resolved = parser.resolve('$$MY_PARAM', session='s_my_session')
"""

import re
import sys
from pathlib import Path
from typing import Any, Dict, List, Optional
from dataclasses import dataclass, field

sys.path.insert(0, str(Path(__file__).parent.parent))
from base.base_parser import BaseParser


@dataclass
class Parameter:
    """A single Informatica parameter."""
    name: str
    value: str
    scope: str = ""  # session name or 'global'
    source_file: str = ""

    def to_dict(self) -> Dict[str, Any]:
        return {
            'name': self.name,
            'value': self.value,
            'scope': self.scope,
            'source_file': self.source_file,
        }


@dataclass
class ParameterCatalog:
    """Collection of all parsed parameters."""
    global_params: Dict[str, Parameter] = field(default_factory=dict)
    session_params: Dict[str, Dict[str, Parameter]] = field(default_factory=dict)
    files_parsed: List[str] = field(default_factory=list)

    def resolve(self, param_name: str, session: str = '') -> Optional[str]:
        """Resolve a parameter value. Session scope takes precedence over global."""
        clean_name = param_name.lstrip('$')
        prefixed = f"$${clean_name}"

        # Check session scope first
        if session:
            session_key = session.upper()
            if session_key in self.session_params:
                for key in [prefixed, f"${clean_name}", clean_name]:
                    if key in self.session_params[session_key]:
                        return self.session_params[session_key][key].value

        # Fall back to global
        for key in [prefixed, f"${clean_name}", clean_name]:
            if key in self.global_params:
                return self.global_params[key].value

        return None

    def to_dict(self) -> Dict[str, Any]:
        return {
            'global_params': {k: v.to_dict() for k, v in self.global_params.items()},
            'session_params': {
                sess: {k: v.to_dict() for k, v in params.items()}
                for sess, params in self.session_params.items()
            },
            'files_parsed': self.files_parsed,
            'statistics': {
                'total_global': len(self.global_params),
                'total_sessions': len(self.session_params),
                'total_session_params': sum(len(p) for p in self.session_params.values()),
            }
        }


class ParamParser(BaseParser):
    """
    Parses Informatica parameter files (.prm, .par, .txt).
    """

    def __init__(self, input_dir: str = 'inputs/params', output_dir: str = 'output'):
        super().__init__(input_dir, output_dir)
        self.catalog = ParameterCatalog()

    def discover_files(self) -> List[Path]:
        """Find all parameter files."""
        param_files = []
        for pattern in ['*.prm', '*.par', '*.txt', '*.PRM', '*.PAR', '*.TXT']:
            param_files.extend(self.input_dir.glob(pattern))
        return sorted(set(param_files))

    def parse_file(self, file_path: Path) -> Dict[str, Any]:
        """Parse a single parameter file."""
        content = file_path.read_text(encoding='utf-8', errors='replace')
        self.catalog.files_parsed.append(str(file_path))

        current_scope = 'global'
        params_found = 0

        for line in content.splitlines():
            line = line.strip()

            # Skip empty lines and comments
            if not line or line.startswith('#') or line.startswith('//'):
                continue

            # Check for scope header: [Session.s_session_name] or [Workflow.wf_name]
            scope_match = re.match(r'\[(?:Session\.|Workflow\.)?(\S+)\]', line, re.IGNORECASE)
            if scope_match:
                current_scope = scope_match.group(1).upper()
                continue

            # Check for [Global] scope
            if re.match(r'\[Global\]', line, re.IGNORECASE):
                current_scope = 'global'
                continue

            # Parse parameter: $$PARAM=value or $PARAM=value
            param_match = re.match(r'(\$\$?\w+)\s*=\s*(.*)', line)
            if param_match:
                param = Parameter(
                    name=param_match.group(1),
                    value=param_match.group(2).strip(),
                    scope=current_scope,
                    source_file=file_path.name,
                )

                if current_scope == 'global':
                    self.catalog.global_params[param.name] = param
                else:
                    if current_scope not in self.catalog.session_params:
                        self.catalog.session_params[current_scope] = {}
                    self.catalog.session_params[current_scope][param.name] = param

                params_found += 1

        return {
            'file': file_path.name,
            'params_found': params_found,
            'scope': current_scope,
        }

    def get_catalog(self) -> ParameterCatalog:
        """Get the complete parameter catalog."""
        return self.catalog

    def resolve(self, param_name: str, session: str = '') -> Optional[str]:
        """Resolve a parameter value."""
        return self.catalog.resolve(param_name, session)

    def substitute_params(self, text: str, session: str = '') -> str:
        """Replace all parameter references in text with resolved values."""
        def replacer(match):
            param_name = match.group(0)
            resolved = self.resolve(param_name, session)
            return resolved if resolved is not None else param_name

        return re.sub(r'\$\$?\w+', replacer, text)


def main():
    import sys
    input_dir = sys.argv[1] if len(sys.argv) > 1 else 'inputs/params'
    parser = ParamParser(input_dir=input_dir)
    parser.parse_all()
    catalog = parser.get_catalog()
    print(f"Parsed: {len(catalog.global_params)} global params, "
          f"{len(catalog.session_params)} session scopes")


if __name__ == '__main__':
    main()
