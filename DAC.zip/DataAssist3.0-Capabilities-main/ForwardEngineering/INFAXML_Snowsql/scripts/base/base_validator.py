"""
Base Validator - Abstract base class for validating output artifacts.

Subclass this to create validators for specific quality checks.

Usage:
    class MyValidator(BaseValidator):
        def validate(self):
            issues = []
            issues.extend(self.check_files_exist())
            issues.extend(self.check_sql_syntax())
            return issues

    validator = MyValidator(target_dir='output')
    issues = validator.validate()
    validator.report(issues)
"""

from abc import ABC, abstractmethod
from pathlib import Path
from typing import Any, Dict, List

import yaml

from utils import setup_logging, get_timestamp


class BaseValidator(ABC):
    """Abstract base class for output validators."""

    def __init__(self, target_dir: str = 'output'):
        self.target_dir = Path(target_dir)
        self.logger = setup_logging(self.__class__.__name__)

    @abstractmethod
    def validate(self) -> List[Dict[str, str]]:
        """Run validation checks. Return list of issues found."""
        ...

    def check_files_exist(self, expected_files: List[str]) -> List[Dict[str, str]]:
        """Check that expected files exist."""
        issues = []
        for file_path in expected_files:
            if not Path(file_path).exists():
                issues.append({
                    'severity': 'ERROR',
                    'file': file_path,
                    'message': f'Expected file not found: {file_path}',
                    'suggestion': f'Ensure the generator script produces {file_path}'
                })
        return issues

    def check_sql_valid(self, file_path: Path) -> List[Dict[str, str]]:
        """Basic SQL syntax validation (checks for common issues)."""
        issues = []
        try:
            content = file_path.read_text(encoding='utf-8')
            if not content.strip():
                issues.append({
                    'severity': 'ERROR',
                    'file': str(file_path),
                    'message': 'SQL file is empty',
                })
            if 'CREATE' not in content.upper() and 'INSERT' not in content.upper() and 'MERGE' not in content.upper():
                issues.append({
                    'severity': 'WARNING',
                    'file': str(file_path),
                    'message': 'SQL file contains no CREATE/INSERT/MERGE statements',
                })
        except FileNotFoundError:
            issues.append({
                'severity': 'ERROR',
                'file': str(file_path),
                'message': 'File not found',
            })
        return issues

    def check_yaml_valid(self, file_path: Path) -> List[Dict[str, str]]:
        """Check that a YAML file is valid and non-empty."""
        issues = []
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                data = yaml.safe_load(f)
            if data is None:
                issues.append({
                    'severity': 'ERROR',
                    'file': str(file_path),
                    'message': 'YAML file is empty',
                })
        except yaml.YAMLError as e:
            issues.append({
                'severity': 'ERROR',
                'file': str(file_path),
                'message': f'Invalid YAML syntax: {e}',
            })
        except FileNotFoundError:
            issues.append({
                'severity': 'ERROR',
                'file': str(file_path),
                'message': 'File not found',
            })
        return issues

    def report(self, issues: List[Dict[str, str]]) -> Dict[str, Any]:
        """Generate a validation report from issues found."""
        errors = [i for i in issues if i.get('severity') == 'ERROR']
        warnings = [i for i in issues if i.get('severity') == 'WARNING']
        infos = [i for i in issues if i.get('severity') == 'INFO']

        report = {
            'validation_report': {
                'timestamp': get_timestamp(),
                'validator': self.__class__.__name__,
                'summary': {
                    'total_issues': len(issues),
                    'errors': len(errors),
                    'warnings': len(warnings),
                    'info': len(infos),
                    'passed': len(errors) == 0,
                },
                'issues': issues,
            }
        }

        status = "PASSED" if len(errors) == 0 else "FAILED"
        self.logger.info(
            f"Validation {status}: {len(errors)} errors, "
            f"{len(warnings)} warnings, {len(infos)} info"
        )
        return report


def main():
    print("BaseValidator is abstract. Create a subclass for your specific checks.")


if __name__ == '__main__':
    main()
