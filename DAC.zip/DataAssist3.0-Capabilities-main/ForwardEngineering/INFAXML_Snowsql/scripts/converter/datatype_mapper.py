"""
Data Type Mapper — Converts source data types to Snowflake equivalents
using regex-based pattern matching for precise type resolution.

Supports:
- Oracle data types (VARCHAR2, NUMBER, DATE, TIMESTAMP variants, CLOB, BLOB, RAW, XMLTYPE, ROWID)
- Informatica data types (string, decimal, integer, date/time, binary)
- SQL Server data types (nvarchar, int, datetime2, datetimeoffset, etc.)
- DB2 data types (INTEGER, DECIMAL, GRAPHIC, DBCLOB, etc.)
- Teradata data types (BYTEINT, CHAR, DATE, DOUBLE PRECISION, etc.)
- Precision/scale preservation where applicable
- Generic fallback for unrecognized types

Usage:
    mapper = DataTypeMapper()
    result = mapper.map_type('VARCHAR2(100)', source_system=SourceSystem.ORACLE)
    print(result.full_type)  # "VARCHAR(100)"
"""

import re
from typing import Any, Dict, List, Optional
from dataclasses import dataclass, field
from enum import Enum


class SourceSystem(Enum):
    """Supported source database systems."""
    ORACLE = "oracle"
    INFORMATICA = "informatica"
    SQL_SERVER = "sql_server"
    DB2 = "db2"
    TERADATA = "teradata"
    GENERIC = "generic"


@dataclass
class DataTypeMapping:
    """
    Mapping rule from a source type pattern (regex) to a Snowflake type.

    Attributes:
        source_type: Regex pattern to match source data type
        snowflake_type: Snowflake target type (may include fixed size like 'NUMBER(38, 0)')
        source_system: Which source database this rule applies to
        preserve_precision: Whether to extract and carry over precision/scale from the match
        max_size: Maximum size in Snowflake (for LOB types)
        notes: Explanation of the mapping
    """
    source_type: str
    snowflake_type: str
    source_system: SourceSystem = SourceSystem.GENERIC
    preserve_precision: bool = True
    max_size: Optional[int] = None
    notes: str = ""


@dataclass
class MappedDataType:
    """
    Result of a data type mapping.

    Attributes:
        original_type: Original source data type string
        snowflake_type: Mapped Snowflake base type
        precision: Numeric precision (if applicable)
        scale: Numeric scale (if applicable)
        length: String/binary length (if applicable)
        is_nullable: Whether the column is nullable
        warnings: Mapping warnings
    """
    original_type: str
    snowflake_type: str
    precision: Optional[int] = None
    scale: Optional[int] = None
    length: Optional[int] = None
    is_nullable: bool = True
    warnings: List[str] = field(default_factory=list)

    @property
    def full_type(self) -> str:
        """Get full Snowflake type with size/precision."""
        if self.precision is not None and self.scale is not None:
            return f"{self.snowflake_type}({self.precision}, {self.scale})"
        elif self.precision is not None:
            return f"{self.snowflake_type}({self.precision})"
        elif self.length is not None:
            return f"{self.snowflake_type}({self.length})"
        return self.snowflake_type

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary representation."""
        return {
            "original_type": self.original_type,
            "snowflake_type": self.snowflake_type,
            "full_type": self.full_type,
            "precision": self.precision,
            "scale": self.scale,
            "length": self.length,
            "is_nullable": self.is_nullable,
            "warnings": self.warnings,
        }


class DataTypeMapper:
    """
    Maps data types from various source systems to Snowflake using
    regex-based pattern matching with precision/scale preservation.
    """

    # Snowflake maximum sizes
    MAX_VARCHAR_SIZE = 16777216   # 16 MB
    MAX_BINARY_SIZE = 8388608    # 8 MB
    MAX_NUMBER_PRECISION = 38
    MAX_NUMBER_SCALE = 37

    def __init__(self, source_system: SourceSystem = SourceSystem.ORACLE):
        self.source_system = source_system
        self._mappings = self._build_mappings()

    # ------------------------------------------------------------------ #
    #  Public API                                                         #
    # ------------------------------------------------------------------ #

    def map_type(self, source_type: str,
                 source_system: Optional[SourceSystem] = None) -> MappedDataType:
        """Map a source data type string to its Snowflake equivalent."""
        system = source_system or self.source_system
        source_clean = source_type.strip().upper()

        # Try system-specific mappings first
        system_mappings = self._mappings.get(system.value, [])
        for mapping in system_mappings:
            match = re.compile(mapping.source_type, re.IGNORECASE).match(source_clean)
            if match:
                return self._create_mapped_type(source_type, mapping, match)

        # Try generic fallback
        return self._generic_mapping(source_type)

    def map_column_definition(self, column_name: str, source_type: str,
                              nullable: bool = True,
                              source_system: Optional[SourceSystem] = None) -> str:
        """Generate a Snowflake column definition string."""
        mapped = self.map_type(source_type, source_system)
        null_clause = "" if nullable else " NOT NULL"
        return f"{column_name} {mapped.full_type}{null_clause}"

    def batch_map_types(self, columns: List[Dict[str, str]],
                        source_system: Optional[SourceSystem] = None) -> List[MappedDataType]:
        """Map multiple column types at once."""
        return [
            self.map_type(col.get('type', 'VARCHAR'), source_system)
            for col in columns
        ]

    def get_supported_types(self, source_system: SourceSystem) -> List[str]:
        """Get list of supported type patterns for a source system."""
        return [m.source_type for m in self._mappings.get(source_system.value, [])]

    # ------------------------------------------------------------------ #
    #  Internal — mapping construction                                    #
    # ------------------------------------------------------------------ #

    def _build_mappings(self) -> Dict[str, List[DataTypeMapping]]:
        """Build the dictionary of regex-based data type mappings."""
        mappings: Dict[str, List[DataTypeMapping]] = {
            "oracle": self._oracle_mappings(),
            "informatica": self._informatica_mappings(),
            "sql_server": self._sql_server_mappings(),
            "db2": self._db2_mappings(),
            "teradata": self._teradata_mappings(),
            "generic": [],
        }
        return mappings

    # ── Oracle ────────────────────────────────────────────────────────

    def _oracle_mappings(self) -> List[DataTypeMapping]:
        m: List[DataTypeMapping] = []
        S = SourceSystem.ORACLE

        # --- String types ---
        m.append(DataTypeMapping(r"VARCHAR2?\s*\((\d+)(?:\s+(?:BYTE|CHAR))?\)", "VARCHAR", S))
        m.append(DataTypeMapping(r"NVARCHAR2?\s*\((\d+)\)", "VARCHAR", S))
        m.append(DataTypeMapping(r"NVARCHAR2?", "VARCHAR", S, preserve_precision=False))
        m.append(DataTypeMapping(r"VARCHAR2?", "VARCHAR", S, preserve_precision=False))
        m.append(DataTypeMapping(r"CHAR\s*\((\d+)(?:\s+(?:BYTE|CHAR))?\)", "CHAR", S))
        m.append(DataTypeMapping(r"NCHAR\s*\((\d+)\)", "CHAR", S))
        m.append(DataTypeMapping(r"NCHAR", "CHAR", S, preserve_precision=False))
        m.append(DataTypeMapping(r"CLOB", "VARCHAR", S, max_size=self.MAX_VARCHAR_SIZE))
        m.append(DataTypeMapping(r"NCLOB", "VARCHAR", S, max_size=self.MAX_VARCHAR_SIZE))
        m.append(DataTypeMapping(r"LONG\s+RAW", "BINARY", S, max_size=self.MAX_BINARY_SIZE))
        m.append(DataTypeMapping(r"LONG", "VARCHAR", S, max_size=self.MAX_VARCHAR_SIZE))

        # --- Numeric types ---
        m.append(DataTypeMapping(r"NUMBER\s*\((\d+)\s*,\s*(\d+)\)", "NUMBER", S, preserve_precision=True))
        m.append(DataTypeMapping(r"NUMBER\s*\((\d+)\)", "NUMBER", S, preserve_precision=True))
        m.append(DataTypeMapping(r"NUMBER", "NUMBER(38, 0)", S, preserve_precision=False))
        m.append(DataTypeMapping(r"DECIMAL\s*\((\d+)\s*,\s*(\d+)\)", "DECIMAL", S, preserve_precision=True))
        m.append(DataTypeMapping(r"INTEGER", "INTEGER", S))
        m.append(DataTypeMapping(r"INT\b", "INTEGER", S))
        m.append(DataTypeMapping(r"SMALLINT", "SMALLINT", S))
        m.append(DataTypeMapping(r"FLOAT\s*\((\d+)\)", "FLOAT", S))
        m.append(DataTypeMapping(r"FLOAT", "FLOAT", S))
        m.append(DataTypeMapping(r"BINARY_FLOAT", "FLOAT", S))
        m.append(DataTypeMapping(r"BINARY_DOUBLE", "DOUBLE", S))
        m.append(DataTypeMapping(r"REAL", "REAL", S))

        # --- Date/Time types (order matters — specific before generic) ---
        m.append(DataTypeMapping(r"TIMESTAMP\s*\((\d+)\)\s+WITH\s+TIME\s+ZONE", "TIMESTAMP_TZ", S))
        m.append(DataTypeMapping(r"TIMESTAMP\s*\((\d+)\)\s+WITH\s+LOCAL\s+TIME\s+ZONE", "TIMESTAMP_LTZ", S))
        m.append(DataTypeMapping(r"TIMESTAMP\s+WITH\s+TIME\s+ZONE", "TIMESTAMP_TZ", S))
        m.append(DataTypeMapping(r"TIMESTAMP\s+WITH\s+LOCAL\s+TIME\s+ZONE", "TIMESTAMP_LTZ", S))
        m.append(DataTypeMapping(r"TIMESTAMP\s*\((\d+)\)", "TIMESTAMP_NTZ", S))
        m.append(DataTypeMapping(r"TIMESTAMP", "TIMESTAMP_NTZ", S))
        m.append(DataTypeMapping(r"DATE", "DATE", S))
        m.append(DataTypeMapping(r"INTERVAL\s+YEAR.*?TO\s+MONTH", "VARCHAR(30)", S))
        m.append(DataTypeMapping(r"INTERVAL\s+DAY.*?TO\s+SECOND", "VARCHAR(30)", S))

        # --- Binary types ---
        m.append(DataTypeMapping(r"BLOB", "BINARY", S, max_size=self.MAX_BINARY_SIZE))
        m.append(DataTypeMapping(r"RAW\s*\((\d+)\)", "BINARY", S))

        # --- Special types ---
        m.append(DataTypeMapping(r"BOOLEAN", "BOOLEAN", S))
        m.append(DataTypeMapping(r"ROWID", "VARCHAR(18)", S))
        m.append(DataTypeMapping(r"UROWID", "VARCHAR(4000)", S))
        m.append(DataTypeMapping(r"XMLTYPE", "VARIANT", S))
        m.append(DataTypeMapping(r"BFILE", "VARCHAR(255)", S))

        return m

    # ── Informatica ───────────────────────────────────────────────────

    def _informatica_mappings(self) -> List[DataTypeMapping]:
        m: List[DataTypeMapping] = []
        S = SourceSystem.INFORMATICA

        m.append(DataTypeMapping(r"STRING\s*\((\d+)\)", "VARCHAR", S))
        m.append(DataTypeMapping(r"STRING", "VARCHAR", S))
        m.append(DataTypeMapping(r"NSTRING\s*\((\d+)\)", "VARCHAR", S))
        m.append(DataTypeMapping(r"NSTRING", "VARCHAR", S))
        m.append(DataTypeMapping(r"TEXT", "VARCHAR", S, max_size=self.MAX_VARCHAR_SIZE))
        m.append(DataTypeMapping(r"NTEXT", "VARCHAR", S, max_size=self.MAX_VARCHAR_SIZE))
        m.append(DataTypeMapping(r"DECIMAL\s*\((\d+)\s*,\s*(\d+)\)", "DECIMAL", S, preserve_precision=True))
        m.append(DataTypeMapping(r"DECIMAL", "DECIMAL(38, 0)", S, preserve_precision=False))
        m.append(DataTypeMapping(r"INTEGER", "INTEGER", S))
        m.append(DataTypeMapping(r"SMALL\s*INTEGER", "SMALLINT", S))
        m.append(DataTypeMapping(r"BIGINT", "BIGINT", S))
        m.append(DataTypeMapping(r"DOUBLE", "DOUBLE", S))
        m.append(DataTypeMapping(r"REAL", "REAL", S))
        m.append(DataTypeMapping(r"FLOAT", "FLOAT", S))
        m.append(DataTypeMapping(r"DATE/TIME", "TIMESTAMP_NTZ", S))
        m.append(DataTypeMapping(r"DATETIME", "TIMESTAMP_NTZ", S))
        m.append(DataTypeMapping(r"DATE", "DATE", S))
        m.append(DataTypeMapping(r"TIME", "TIME", S))
        m.append(DataTypeMapping(r"BINARY\s*\((\d+)\)", "BINARY", S))
        m.append(DataTypeMapping(r"BINARY", "BINARY", S))
        m.append(DataTypeMapping(r"BOOLEAN", "BOOLEAN", S))

        return m

    # ── SQL Server ────────────────────────────────────────────────────

    def _sql_server_mappings(self) -> List[DataTypeMapping]:
        m: List[DataTypeMapping] = []
        S = SourceSystem.SQL_SERVER

        # String types
        m.append(DataTypeMapping(r"NVARCHAR\s*\((\d+|MAX)\)", "VARCHAR", S))
        m.append(DataTypeMapping(r"VARCHAR\s*\((\d+|MAX)\)", "VARCHAR", S))
        m.append(DataTypeMapping(r"NCHAR\s*\((\d+)\)", "CHAR", S))
        m.append(DataTypeMapping(r"CHAR\s*\((\d+)\)", "CHAR", S))
        m.append(DataTypeMapping(r"NTEXT", "VARCHAR", S, max_size=self.MAX_VARCHAR_SIZE))
        m.append(DataTypeMapping(r"TEXT", "VARCHAR", S, max_size=self.MAX_VARCHAR_SIZE))

        # Numeric types
        m.append(DataTypeMapping(r"BIGINT", "BIGINT", S))
        m.append(DataTypeMapping(r"INT\b", "INTEGER", S))
        m.append(DataTypeMapping(r"SMALLINT", "SMALLINT", S))
        m.append(DataTypeMapping(r"TINYINT", "SMALLINT", S))
        m.append(DataTypeMapping(r"BIT", "BOOLEAN", S))
        m.append(DataTypeMapping(r"DECIMAL\s*\((\d+)\s*,\s*(\d+)\)", "DECIMAL", S, preserve_precision=True))
        m.append(DataTypeMapping(r"NUMERIC\s*\((\d+)\s*,\s*(\d+)\)", "NUMBER", S, preserve_precision=True))
        m.append(DataTypeMapping(r"MONEY", "NUMBER(19, 4)", S, preserve_precision=False))
        m.append(DataTypeMapping(r"SMALLMONEY", "NUMBER(10, 4)", S, preserve_precision=False))
        m.append(DataTypeMapping(r"FLOAT\s*\((\d+)\)", "FLOAT", S))
        m.append(DataTypeMapping(r"FLOAT", "FLOAT", S))
        m.append(DataTypeMapping(r"REAL", "REAL", S))

        # Date/Time types
        m.append(DataTypeMapping(r"DATETIMEOFFSET\s*\((\d+)\)?", "TIMESTAMP_TZ", S))
        m.append(DataTypeMapping(r"DATETIME2\s*\((\d+)\)?", "TIMESTAMP_NTZ", S))
        m.append(DataTypeMapping(r"DATETIME", "TIMESTAMP_NTZ", S))
        m.append(DataTypeMapping(r"SMALLDATETIME", "TIMESTAMP_NTZ", S))
        m.append(DataTypeMapping(r"DATE", "DATE", S))
        m.append(DataTypeMapping(r"TIME\s*\((\d+)\)?", "TIME", S))

        # Binary types
        m.append(DataTypeMapping(r"VARBINARY\s*\((\d+|MAX)\)", "BINARY", S))
        m.append(DataTypeMapping(r"BINARY\s*\((\d+)\)", "BINARY", S))
        m.append(DataTypeMapping(r"IMAGE", "BINARY", S, max_size=self.MAX_BINARY_SIZE))

        # Special types
        m.append(DataTypeMapping(r"UNIQUEIDENTIFIER", "VARCHAR(36)", S))
        m.append(DataTypeMapping(r"XML", "VARIANT", S))
        m.append(DataTypeMapping(r"SQL_VARIANT", "VARIANT", S))

        return m

    # ── DB2 ───────────────────────────────────────────────────────────

    def _db2_mappings(self) -> List[DataTypeMapping]:
        m: List[DataTypeMapping] = []
        S = SourceSystem.DB2

        # String types
        m.append(DataTypeMapping(r"VARCHAR\s*\((\d+)\)", "VARCHAR", S))
        m.append(DataTypeMapping(r"CHAR(?:ACTER)?\s*\((\d+)\)", "CHAR", S))
        m.append(DataTypeMapping(r"GRAPHIC\s*\((\d+)\)", "VARCHAR", S))
        m.append(DataTypeMapping(r"VARGRAPHIC\s*\((\d+)\)", "VARCHAR", S))
        m.append(DataTypeMapping(r"LONG\s+VARCHAR", "VARCHAR", S, max_size=self.MAX_VARCHAR_SIZE))
        m.append(DataTypeMapping(r"CLOB", "VARCHAR", S, max_size=self.MAX_VARCHAR_SIZE))
        m.append(DataTypeMapping(r"DBCLOB", "VARCHAR", S, max_size=self.MAX_VARCHAR_SIZE))

        # Numeric types
        m.append(DataTypeMapping(r"DECIMAL\s*\((\d+)\s*,\s*(\d+)\)", "NUMBER", S, preserve_precision=True))
        m.append(DataTypeMapping(r"DECIMAL\s*\((\d+)\)", "NUMBER", S, preserve_precision=True))
        m.append(DataTypeMapping(r"NUMERIC\s*\((\d+)\s*,\s*(\d+)\)", "NUMBER", S, preserve_precision=True))
        m.append(DataTypeMapping(r"INTEGER", "INTEGER", S))
        m.append(DataTypeMapping(r"INT\b", "INTEGER", S))
        m.append(DataTypeMapping(r"BIGINT", "BIGINT", S))
        m.append(DataTypeMapping(r"SMALLINT", "SMALLINT", S))
        m.append(DataTypeMapping(r"DECFLOAT", "FLOAT", S))
        m.append(DataTypeMapping(r"DOUBLE", "DOUBLE", S))
        m.append(DataTypeMapping(r"REAL", "REAL", S))
        m.append(DataTypeMapping(r"FLOAT", "FLOAT", S))

        # Date/Time types
        m.append(DataTypeMapping(r"TIMESTAMP", "TIMESTAMP_NTZ", S))
        m.append(DataTypeMapping(r"DATE", "DATE", S))
        m.append(DataTypeMapping(r"TIME", "TIME", S))

        # Binary types
        m.append(DataTypeMapping(r"BLOB", "BINARY", S, max_size=self.MAX_BINARY_SIZE))
        m.append(DataTypeMapping(r"VARBINARY\s*\((\d+)\)", "BINARY", S))
        m.append(DataTypeMapping(r"BINARY\s*\((\d+)\)", "BINARY", S))

        # Special types
        m.append(DataTypeMapping(r"XML", "VARIANT", S))
        m.append(DataTypeMapping(r"BOOLEAN", "BOOLEAN", S))

        return m

    # ── Teradata ──────────────────────────────────────────────────────

    def _teradata_mappings(self) -> List[DataTypeMapping]:
        m: List[DataTypeMapping] = []
        S = SourceSystem.TERADATA

        # String types
        m.append(DataTypeMapping(r"VARCHAR\s*\((\d+)\)", "VARCHAR", S))
        m.append(DataTypeMapping(r"CHAR\s*\((\d+)\)", "CHAR", S))
        m.append(DataTypeMapping(r"LONG\s+VARCHAR", "VARCHAR", S, max_size=self.MAX_VARCHAR_SIZE))
        m.append(DataTypeMapping(r"CLOB", "VARCHAR", S, max_size=self.MAX_VARCHAR_SIZE))

        # Numeric types
        m.append(DataTypeMapping(r"DECIMAL\s*\((\d+)\s*,\s*(\d+)\)", "NUMBER", S, preserve_precision=True))
        m.append(DataTypeMapping(r"DECIMAL\s*\((\d+)\)", "NUMBER", S, preserve_precision=True))
        m.append(DataTypeMapping(r"NUMERIC\s*\((\d+)\s*,\s*(\d+)\)", "NUMBER", S, preserve_precision=True))
        m.append(DataTypeMapping(r"NUMBER\s*\((\d+)\s*,\s*(\d+)\)", "NUMBER", S, preserve_precision=True))
        m.append(DataTypeMapping(r"NUMBER\s*\((\d+)\)", "NUMBER", S, preserve_precision=True))
        m.append(DataTypeMapping(r"NUMBER", "NUMBER(38, 0)", S, preserve_precision=False))
        m.append(DataTypeMapping(r"BYTEINT", "SMALLINT", S))
        m.append(DataTypeMapping(r"SMALLINT", "SMALLINT", S))
        m.append(DataTypeMapping(r"INTEGER", "INTEGER", S))
        m.append(DataTypeMapping(r"BIGINT", "BIGINT", S))
        m.append(DataTypeMapping(r"DOUBLE\s+PRECISION", "DOUBLE", S))
        m.append(DataTypeMapping(r"FLOAT", "FLOAT", S))
        m.append(DataTypeMapping(r"REAL", "REAL", S))

        # Date/Time types
        m.append(DataTypeMapping(r"TIMESTAMP\s+WITH\s+TIME\s+ZONE", "TIMESTAMP_TZ", S))
        m.append(DataTypeMapping(r"TIMESTAMP\s*\((\d+)\)", "TIMESTAMP_NTZ", S))
        m.append(DataTypeMapping(r"TIMESTAMP", "TIMESTAMP_NTZ", S))
        m.append(DataTypeMapping(r"DATE", "DATE", S))
        m.append(DataTypeMapping(r"TIME\s*\((\d+)\)?", "TIME", S))
        m.append(DataTypeMapping(r"TIME", "TIME", S))

        # Binary types
        m.append(DataTypeMapping(r"BLOB", "BINARY", S, max_size=self.MAX_BINARY_SIZE))
        m.append(DataTypeMapping(r"VARBYTE\s*\((\d+)\)", "BINARY", S))
        m.append(DataTypeMapping(r"BYTE\s*\((\d+)\)", "BINARY", S))

        return m

    # ------------------------------------------------------------------ #
    #  Internal — match resolution                                        #
    # ------------------------------------------------------------------ #

    def _create_mapped_type(self, source_type: str, mapping: DataTypeMapping,
                            match: re.Match) -> MappedDataType:
        """Create a MappedDataType from a successful regex match."""
        result = MappedDataType(
            original_type=source_type,
            snowflake_type=mapping.snowflake_type,
        )

        groups = match.groups()

        if mapping.preserve_precision and groups:
            if len(groups) >= 2 and groups[0] and groups[1]:
                # Precision and scale (e.g. NUMBER(10,2))
                result.precision = min(int(groups[0]), self.MAX_NUMBER_PRECISION)
                result.scale = min(int(groups[1]), self.MAX_NUMBER_SCALE)
                # Strip any embedded size from the type template
                result.snowflake_type = mapping.snowflake_type.split('(')[0]
            elif len(groups) >= 1 and groups[0]:
                value = groups[0]
                if value.upper() == 'MAX':
                    result.length = self.MAX_VARCHAR_SIZE
                else:
                    val = int(value)
                    base = mapping.snowflake_type.split('(')[0]
                    if base in ('VARCHAR', 'CHAR'):
                        result.length = min(val, self.MAX_VARCHAR_SIZE)
                    elif base == 'BINARY':
                        result.length = min(val, self.MAX_BINARY_SIZE)
                    else:
                        result.precision = min(val, self.MAX_NUMBER_PRECISION)
                result.snowflake_type = mapping.snowflake_type.split('(')[0]

        # Apply max_size for LOB types that had no inline size
        if mapping.max_size and result.length is None:
            result.length = mapping.max_size

        return result

    def _generic_mapping(self, source_type: str) -> MappedDataType:
        """Provide generic fallback mapping for unrecognized types."""
        upper = source_type.strip().upper()

        generic_map = {
            'VARCHAR': 'VARCHAR', 'CHAR': 'CHAR', 'TEXT': 'VARCHAR', 'STRING': 'VARCHAR',
            'INT': 'INTEGER', 'INTEGER': 'INTEGER', 'BIGINT': 'BIGINT', 'SMALLINT': 'SMALLINT',
            'NUMBER': 'NUMBER', 'NUMERIC': 'NUMBER', 'DECIMAL': 'DECIMAL',
            'FLOAT': 'FLOAT', 'DOUBLE': 'DOUBLE', 'REAL': 'REAL',
            'DATE': 'DATE', 'TIME': 'TIME', 'TIMESTAMP': 'TIMESTAMP_NTZ', 'DATETIME': 'TIMESTAMP_NTZ',
            'BOOLEAN': 'BOOLEAN', 'BOOL': 'BOOLEAN',
            'BINARY': 'BINARY', 'BLOB': 'BINARY', 'CLOB': 'VARCHAR',
        }

        for pattern, sf_type in generic_map.items():
            if pattern in upper:
                return MappedDataType(
                    original_type=source_type,
                    snowflake_type=sf_type,
                    warnings=[f"Generic mapping: {source_type} -> {sf_type}"],
                )

        return MappedDataType(
            original_type=source_type,
            snowflake_type="VARCHAR",
            warnings=[f"Unknown type '{source_type}' defaulted to VARCHAR"],
        )


def main():
    mapper = DataTypeMapper(source_system=SourceSystem.ORACLE)
    test_cases = [
        ("VARCHAR2(100)", SourceSystem.ORACLE),
        ("NUMBER(10,2)", SourceSystem.ORACLE),
        ("NUMBER", SourceSystem.ORACLE),
        ("TIMESTAMP(6) WITH TIME ZONE", SourceSystem.ORACLE),
        ("CLOB", SourceSystem.ORACLE),
        ("RAW(200)", SourceSystem.ORACLE),
        ("ROWID", SourceSystem.ORACLE),
        ("string(255)", SourceSystem.INFORMATICA),
        ("decimal(18,6)", SourceSystem.INFORMATICA),
        ("date/time", SourceSystem.INFORMATICA),
        ("nvarchar(max)", SourceSystem.SQL_SERVER),
        ("money", SourceSystem.SQL_SERVER),
        ("datetimeoffset(7)", SourceSystem.SQL_SERVER),
        ("DECIMAL(15,2)", SourceSystem.DB2),
        ("GRAPHIC(100)", SourceSystem.DB2),
        ("BYTEINT", SourceSystem.TERADATA),
        ("DOUBLE PRECISION", SourceSystem.TERADATA),
    ]
    for src_type, system in test_cases:
        result = mapper.map_type(src_type, source_system=system)
        print(f"  {system.value}.{src_type} -> {result.full_type}")
        if result.warnings:
            for w in result.warnings:
                print(f"    WARNING: {w}")


if __name__ == '__main__':
    main()
