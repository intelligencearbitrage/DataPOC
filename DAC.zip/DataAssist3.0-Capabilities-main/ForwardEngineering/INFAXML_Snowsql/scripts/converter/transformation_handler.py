"""
Transformation Handler — Handles Informatica transformation types
and generates corresponding Snowflake SQL clauses.

Supports: Source Qualifier, Expression, Filter, Joiner, Lookup,
Aggregator, Router, Normalizer, Rank, Sequence Generator, Sorter,
Union, Update Strategy, Stored Procedure.

Usage:
    handler = TransformationHandler(expression_translator, datatype_mapper)
    sql_clauses = handler.handle(transformation, mapping_context)
"""

import sys
from pathlib import Path
from typing import Any, Dict, List, Optional
from dataclasses import dataclass, field

sys.path.insert(0, str(Path(__file__).parent.parent))
from utils import setup_logging
from converter.expression_translator import ExpressionTranslator
from converter.datatype_mapper import DataTypeMapper
from parsers.xml_parser import Transformation, Mapping


@dataclass
class SQLClause:
    """A SQL clause generated from a transformation."""
    clause_type: str  # WHERE, JOIN, GROUP_BY, ORDER_BY, SELECT_EXPR, CTE, MERGE_CONDITION, etc.
    sql: str
    source_transformation: str = ""
    warnings: List[str] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        return {
            'clause_type': self.clause_type,
            'sql': self.sql,
            'source_transformation': self.source_transformation,
            'warnings': self.warnings,
        }


@dataclass
class TransformationResult:
    """Result of processing all transformations in a mapping."""
    select_expressions: Dict[str, str] = field(default_factory=dict)  # col_name → expression
    where_clauses: List[str] = field(default_factory=list)
    join_clauses: List[str] = field(default_factory=list)
    group_by_columns: List[str] = field(default_factory=list)
    order_by_columns: List[str] = field(default_factory=list)
    ctes: List[str] = field(default_factory=list)
    merge_condition: str = ""
    update_strategy: str = "INSERT"  # INSERT, UPDATE, DELETE, MERGE
    pre_sql: List[str] = field(default_factory=list)
    post_sql: List[str] = field(default_factory=list)
    lookup_subqueries: Dict[str, str] = field(default_factory=dict)
    warnings: List[str] = field(default_factory=list)
    sql_clauses: List[SQLClause] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        return {
            'select_expressions': self.select_expressions,
            'where_clauses': self.where_clauses,
            'join_clauses': self.join_clauses,
            'group_by_columns': self.group_by_columns,
            'order_by_columns': self.order_by_columns,
            'ctes': self.ctes,
            'merge_condition': self.merge_condition,
            'update_strategy': self.update_strategy,
            'lookup_subqueries': self.lookup_subqueries,
            'warnings': self.warnings,
        }


class TransformationHandler:
    """
    Processes Informatica transformations and generates corresponding
    Snowflake SQL clauses.
    """

    def __init__(self, expr_translator: Optional[ExpressionTranslator] = None,
                 dtype_mapper: Optional[DataTypeMapper] = None):
        self.expr_translator = expr_translator or ExpressionTranslator()
        self.dtype_mapper = dtype_mapper or DataTypeMapper()
        self.logger = setup_logging('TransformationHandler')

    def process_mapping(self, mapping: Mapping) -> TransformationResult:
        """Process all transformations in a mapping and return combined SQL clauses."""
        result = TransformationResult()

        for tx in mapping.transformations:
            self._handle_transformation(tx, result)

        return result

    def _handle_transformation(self, tx: Transformation, result: TransformationResult) -> None:
        """Route a transformation to the appropriate handler."""
        handler_map = {
            'Source Qualifier': self._handle_source_qualifier,
            'Expression': self._handle_expression,
            'Filter': self._handle_filter,
            'Lookup': self._handle_lookup,
            'Joiner': self._handle_joiner,
            'Aggregator': self._handle_aggregator,
            'Router': self._handle_router,
            'Sorter': self._handle_sorter,
            'Rank': self._handle_rank,
            'Sequence Generator': self._handle_sequence,
            'Update Strategy': self._handle_update_strategy,
            'Union': self._handle_union,
            'Normalizer': self._handle_normalizer,
            'Stored Procedure': self._handle_stored_procedure,
        }

        handler = handler_map.get(tx.type)
        if handler:
            handler(tx, result)
        else:
            result.warnings.append(f"Unhandled transformation type: {tx.type} ({tx.name})")

    def _handle_source_qualifier(self, tx: Transformation, result: TransformationResult) -> None:
        """Handle Source Qualifier — SQL override, filter, join."""
        if tx.sql_query:
            translated = self.expr_translator.translate(tx.sql_query)
            result.ctes.append(f"-- Source Qualifier SQL Override ({tx.name})\n{translated.translated}")
            result.sql_clauses.append(SQLClause(
                clause_type='CTE',
                sql=translated.translated,
                source_transformation=tx.name,
                warnings=translated.warnings,
            ))

        if tx.source_filter:
            translated = self.expr_translator.translate(tx.source_filter)
            result.where_clauses.append(translated.translated)

        if tx.user_defined_join:
            translated = self.expr_translator.translate(tx.user_defined_join)
            result.join_clauses.append(translated.translated)

    def _handle_expression(self, tx: Transformation, result: TransformationResult) -> None:
        """Handle Expression transformation — translate output port expressions."""
        for f in tx.fields:
            if f.expression and f.port_type and 'OUTPUT' in f.port_type.upper():
                translated = self.expr_translator.translate(f.expression)
                result.select_expressions[f.name] = translated.translated
                if translated.warnings:
                    result.warnings.extend(translated.warnings)

    def _handle_filter(self, tx: Transformation, result: TransformationResult) -> None:
        """Handle Filter transformation → WHERE clause."""
        for f in tx.fields:
            if f.expression and f.port_type and 'OUTPUT' in f.port_type.upper():
                # The filter expression is the one that evaluates to TRUE/FALSE
                translated = self.expr_translator.translate(f.expression)
                result.where_clauses.append(translated.translated)
                break
        # Also check properties
        filter_cond = tx.properties.get('Filter Condition', '')
        if filter_cond:
            translated = self.expr_translator.translate(filter_cond)
            result.where_clauses.append(translated.translated)

    def _handle_lookup(self, tx: Transformation, result: TransformationResult) -> None:
        """Handle Lookup transformation → LEFT JOIN or subquery."""
        lookup_table = tx.lookup_table or tx.name
        condition = tx.lookup_condition or ''

        if tx.lookup_sql_override:
            # SQL override takes precedence
            translated = self.expr_translator.translate(tx.lookup_sql_override)
            result.lookup_subqueries[tx.name] = translated.translated
            result.sql_clauses.append(SQLClause(
                clause_type='LOOKUP_SUBQUERY',
                sql=translated.translated,
                source_transformation=tx.name,
            ))
        elif condition:
            translated_cond = self.expr_translator.translate(condition)
            join_sql = f"LEFT JOIN {lookup_table} {tx.name} ON {translated_cond.translated}"
            result.join_clauses.append(join_sql)
        else:
            result.warnings.append(f"Lookup {tx.name}: no condition or SQL override found")

    def _handle_joiner(self, tx: Transformation, result: TransformationResult) -> None:
        """Handle Joiner transformation → JOIN clause."""
        join_type_map = {
            'Normal Join': 'INNER JOIN',
            'Master Outer Join': 'LEFT JOIN',
            'Detail Outer Join': 'RIGHT JOIN',
            'Full Outer Join': 'FULL OUTER JOIN',
        }
        sf_join_type = join_type_map.get(tx.join_type, 'INNER JOIN')

        if tx.join_condition:
            translated = self.expr_translator.translate(tx.join_condition)
            result.join_clauses.append(f"{sf_join_type} ON {translated.translated}")
        else:
            result.warnings.append(f"Joiner {tx.name}: no join condition")

    def _handle_aggregator(self, tx: Transformation, result: TransformationResult) -> None:
        """Handle Aggregator transformation → GROUP BY + aggregate expressions."""
        for f in tx.fields:
            if f.port_type and 'GROUP BY' in f.port_type.upper():
                result.group_by_columns.append(f.name)
            elif f.expression and f.port_type and 'OUTPUT' in f.port_type.upper():
                translated = self.expr_translator.translate(f.expression)
                result.select_expressions[f.name] = translated.translated

        if tx.group_by_ports:
            result.group_by_columns.extend(tx.group_by_ports)

    def _handle_router(self, tx: Transformation, result: TransformationResult) -> None:
        """Handle Router transformation → CASE WHEN or multiple INSERT statements."""
        for group in tx.groups:
            group_name = group.get('name', '')
            group_expr = group.get('expression', '')
            if group_expr and group_name.upper() != 'DEFAULT':
                translated = self.expr_translator.translate(group_expr)
                result.sql_clauses.append(SQLClause(
                    clause_type='ROUTER_GROUP',
                    sql=f"-- Router group: {group_name}\nWHERE {translated.translated}",
                    source_transformation=tx.name,
                ))

    def _handle_sorter(self, tx: Transformation, result: TransformationResult) -> None:
        """Handle Sorter transformation → ORDER BY clause."""
        for f in tx.fields:
            if f.port_type and 'SORT' in f.port_type.upper():
                sort_dir = 'ASC'
                if f.properties if hasattr(f, 'properties') else False:
                    pass
                result.order_by_columns.append(f"{f.name} {sort_dir}")

    def _handle_rank(self, tx: Transformation, result: TransformationResult) -> None:
        """Handle Rank transformation → ROW_NUMBER() or RANK()."""
        rank_port = None
        for f in tx.fields:
            if f.expression and 'RANK' in f.name.upper():
                rank_port = f
                break

        if rank_port:
            result.select_expressions[rank_port.name] = (
                f"ROW_NUMBER() OVER (ORDER BY {rank_port.name}) AS {rank_port.name}"
            )
        result.warnings.append(f"Rank {tx.name}: verify PARTITION BY and ORDER BY clauses")

    def _handle_sequence(self, tx: Transformation, result: TransformationResult) -> None:
        """Handle Sequence Generator → Snowflake SEQUENCE or ROW_NUMBER()."""
        seq_name = tx.name.upper()
        for f in tx.fields:
            if f.name.upper() in ('NEXTVAL', 'CURRVAL'):
                result.select_expressions[f.name] = (
                    f"ROW_NUMBER() OVER (ORDER BY 1) AS {seq_name}_{f.name}"
                )

    def _handle_update_strategy(self, tx: Transformation, result: TransformationResult) -> None:
        """Handle Update Strategy → INSERT/UPDATE/DELETE/MERGE."""
        strategy_map = {
            'DD_INSERT': 'INSERT',
            'DD_UPDATE': 'UPDATE',
            'DD_DELETE': 'DELETE',
            'DD_REJECT': 'REJECT',
        }

        if tx.update_strategy_expression:
            translated = self.expr_translator.translate(tx.update_strategy_expression)
            expr_upper = translated.translated.upper()

            if 'DD_UPDATE' in expr_upper or 'DD_INSERT' in expr_upper:
                result.update_strategy = 'MERGE'
                result.merge_condition = translated.translated
            elif 'DD_DELETE' in expr_upper:
                result.update_strategy = 'DELETE'
            else:
                result.update_strategy = 'INSERT'
        else:
            result.update_strategy = 'INSERT'

    def _handle_union(self, tx: Transformation, result: TransformationResult) -> None:
        """Handle Union transformation → UNION ALL."""
        result.sql_clauses.append(SQLClause(
            clause_type='UNION',
            sql='UNION ALL',
            source_transformation=tx.name,
        ))

    def _handle_normalizer(self, tx: Transformation, result: TransformationResult) -> None:
        """Handle Normalizer transformation → UNPIVOT or LATERAL FLATTEN."""
        result.warnings.append(
            f"Normalizer {tx.name}: requires manual conversion to UNPIVOT or LATERAL FLATTEN"
        )
        result.sql_clauses.append(SQLClause(
            clause_type='NORMALIZER',
            sql=f"-- TODO: Normalizer {tx.name} - convert to UNPIVOT or LATERAL FLATTEN",
            source_transformation=tx.name,
            warnings=['Normalizer requires manual review'],
        ))

    def _handle_stored_procedure(self, tx: Transformation, result: TransformationResult) -> None:
        """Handle Stored Procedure transformation."""
        if tx.sp_name:
            result.sql_clauses.append(SQLClause(
                clause_type='STORED_PROCEDURE',
                sql=f"CALL {tx.sp_name}();",
                source_transformation=tx.name,
            ))
        result.warnings.append(
            f"Stored Procedure {tx.name}: SP call '{tx.sp_name}' needs manual review for Snowflake compatibility"
        )


def main():
    print("TransformationHandler requires parser models. Use via cli.py or orchestrator.")


if __name__ == '__main__':
    main()
