"""
Table Classifier — Classifies tables into Bronze/Silver/Gold medallion layers.

Classification is based on transformation complexity:
- Bronze: Direct source load, no/minimal transformations (hop count <= 1)
- Silver: Moderate transformations (expressions, filters, lookups)
- Gold: Complex aggregations, multi-source joins, business logic

Usage:
    classifier = TableClassifier()
    classifications = classifier.classify(repository)
"""

import sys
from pathlib import Path
from typing import Any, Dict, List, Optional
from dataclasses import dataclass, field

sys.path.insert(0, str(Path(__file__).parent.parent))
from utils import setup_logging

# Import parser models
sys.path.insert(0, str(Path(__file__).parent.parent / 'parsers'))
from parsers.xml_parser import ParsedRepository, Mapping, Transformation


@dataclass
class TableClassification:
    """Classification result for a single target table."""
    table_name: str
    mapping_name: str
    medallion_layer: str  # BRONZE, SILVER, GOLD
    confidence: float = 1.0
    reason: str = ""
    source_tables: List[str] = field(default_factory=list)
    transformation_types: List[str] = field(default_factory=list)
    complexity_score: float = 0.0
    hop_count: int = 0

    def to_dict(self) -> Dict[str, Any]:
        return {
            'table_name': self.table_name,
            'mapping_name': self.mapping_name,
            'medallion_layer': self.medallion_layer,
            'confidence': self.confidence,
            'reason': self.reason,
            'source_tables': self.source_tables,
            'transformation_types': self.transformation_types,
            'complexity_score': self.complexity_score,
            'hop_count': self.hop_count,
        }


class TableClassifier:
    """
    Classifies target tables into medallion layers based on
    transformation complexity in the Informatica mapping.
    """

    # Transformation types that indicate higher complexity
    COMPLEX_TRANSFORMS = {'Aggregator', 'Joiner', 'Router', 'Normalizer', 'Rank', 'Union'}
    MODERATE_TRANSFORMS = {'Expression', 'Filter', 'Lookup', 'Sorter', 'Update Strategy'}
    SIMPLE_TRANSFORMS = {'Source Qualifier', 'Sequence Generator'}

    def __init__(self, bronze_max_complexity: float = 0.2,
                 silver_max_complexity: float = 0.6):
        self.bronze_max = bronze_max_complexity
        self.silver_max = silver_max_complexity
        self.logger = setup_logging('TableClassifier')

    def classify(self, repository: ParsedRepository) -> List[TableClassification]:
        """Classify all target tables in the repository."""
        classifications = []

        for mapping_name, mapping in repository.mappings.items():
            for target in mapping.targets:
                classification = self._classify_target(target.name, mapping)
                classifications.append(classification)

        self.logger.info(f"Classified {len(classifications)} tables")
        layer_counts = {}
        for c in classifications:
            layer_counts[c.medallion_layer] = layer_counts.get(c.medallion_layer, 0) + 1
        for layer, count in sorted(layer_counts.items()):
            self.logger.info(f"  {layer}: {count}")

        return classifications

    def _classify_target(self, target_name: str, mapping: Mapping) -> TableClassification:
        """Classify a single target table based on its mapping."""
        # Gather transformation types used
        tx_types = [tx.type for tx in mapping.transformations]
        source_names = [s.name for s in mapping.sources]
        hop_count = len(mapping.transformations)

        # Calculate complexity score
        complexity = self._calculate_complexity(mapping)

        # Determine layer
        if complexity <= self.bronze_max:
            layer = 'BRONZE'
            reason = 'Simple source load with minimal transformations'
        elif complexity <= self.silver_max:
            layer = 'SILVER'
            reason = 'Moderate transformations (expressions, filters, lookups)'
        else:
            layer = 'GOLD'
            reason = 'Complex transformations (aggregations, multi-source joins)'

        # Override: if there are aggregators or multiple sources joined, it's at least Silver
        complex_types = set(tx_types) & self.COMPLEX_TRANSFORMS
        if complex_types and layer == 'BRONZE':
            layer = 'SILVER'
            reason = f'Contains complex transforms: {", ".join(complex_types)}'

        # Override: if there are multiple source tables joined, it's at least Silver
        if len(source_names) > 1 and layer == 'BRONZE':
            layer = 'SILVER'
            reason = f'Multi-source mapping ({len(source_names)} sources)'

        confidence = max(0.5, 1.0 - (complexity * 0.3))

        return TableClassification(
            table_name=target_name,
            mapping_name=mapping.name,
            medallion_layer=layer,
            confidence=round(confidence, 2),
            reason=reason,
            source_tables=source_names,
            transformation_types=list(set(tx_types)),
            complexity_score=round(complexity, 3),
            hop_count=hop_count,
        )

    def _calculate_complexity(self, mapping: Mapping) -> float:
        """Calculate a 0-1 complexity score for a mapping."""
        score = 0.0

        for tx in mapping.transformations:
            if tx.type in self.COMPLEX_TRANSFORMS:
                score += 0.3
            elif tx.type in self.MODERATE_TRANSFORMS:
                score += 0.15
            elif tx.type in self.SIMPLE_TRANSFORMS:
                score += 0.05

            # Expressions with complex logic add complexity
            for f in tx.fields:
                if f.expression:
                    expr_len = len(f.expression)
                    if expr_len > 200:
                        score += 0.1
                    elif expr_len > 50:
                        score += 0.05

        # Multiple sources add complexity
        if len(mapping.sources) > 1:
            score += 0.1 * (len(mapping.sources) - 1)

        return min(1.0, score)


def main():
    print("TableClassifier requires a ParsedRepository. Use via cli.py or orchestrator.")


if __name__ == '__main__':
    main()
