"""
Strategy Detector — Determines DML strategy (INSERT vs MERGE) for each target table
and resolves the original schema from Informatica XML metadata.

No Bronze/Silver/Gold classification — this is a simple 1:1 conversion.

Detection signals (checked in order):
1. Update Strategy transformations in the mapping
2. SCD markers in field metadata (slowly_changing, scd_type)
3. Transformation types containing 'Update Strategy'
4. Key-based heuristics (primary keys + update override fields)

Schema resolution:
1. Owner field on the target definition
2. Qualified name parsing (SCHEMA.TABLE)
3. Fallback to default_schema

Usage:
    detector = StrategyDetector(default_schema='PUBLIC')
    strategies = detector.detect(repository)
"""

import sys
from pathlib import Path
from typing import Any, Dict, List, Optional
from dataclasses import dataclass, field

sys.path.insert(0, str(Path(__file__).parent.parent))
from utils import setup_logging
from parsers.xml_parser import ParsedRepository, Mapping, Transformation, TargetTable, TransformField


@dataclass
class TableStrategy:
    """Strategy detection result for a single target table."""
    table_name: str
    mapping_name: str
    dml_strategy: str           # INSERT or MERGE
    schema: str                 # Resolved schema name
    reason: str = ""            # Why this strategy was chosen
    source_tables: List[str] = field(default_factory=list)
    transformation_types: List[str] = field(default_factory=list)
    merge_keys: List[str] = field(default_factory=list)
    warnings: List[str] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        return {
            'table_name': self.table_name,
            'mapping_name': self.mapping_name,
            'dml_strategy': self.dml_strategy,
            'schema': self.schema,
            'reason': self.reason,
            'source_tables': self.source_tables,
            'transformation_types': self.transformation_types,
            'merge_keys': self.merge_keys,
            'warnings': self.warnings,
        }


class StrategyDetector:
    """
    Detects DML strategy (INSERT vs MERGE) for each target table
    and resolves the original schema from the parsed Informatica repository.
    """

    # Transformation types that signal MERGE
    MERGE_SIGNAL_TYPES = {'Update Strategy', 'Slowly Changing Dimension'}

    # Skip intermediate/temp tables
    SKIP_KEYWORDS = {'INTERMEDIATE', 'TEMP', 'WORK', 'STAGING', 'TMP', 'WRK'}

    def __init__(self, default_schema: str = 'PUBLIC'):
        self.default_schema = default_schema
        self.logger = setup_logging('StrategyDetector')

    def detect(self, repository: ParsedRepository,
               ddl_objects: Optional[Dict] = None) -> List[TableStrategy]:
        """Detect strategies for all target tables in the repository.
        If ddl_objects (from DDL parser) are provided, use PK constraints for merge keys.
        """
        self._ddl_objects = ddl_objects or {}
        strategies: List[TableStrategy] = []

        for mapping_name, mapping in repository.mappings.items():
            for target in mapping.targets:
                # Skip intermediate tables
                if any(kw in target.name.upper() for kw in self.SKIP_KEYWORDS):
                    continue

                strategy = self._detect_target_strategy(target.name, mapping)
                strategies.append(strategy)

        # Log summary
        insert_count = sum(1 for s in strategies if s.dml_strategy == 'INSERT')
        merge_count = sum(1 for s in strategies if s.dml_strategy == 'MERGE')
        self.logger.info(f"Strategy detection complete: {len(strategies)} tables")
        self.logger.info(f"  INSERT: {insert_count}, MERGE: {merge_count}")

        return strategies

    def _detect_target_strategy(self, target_name: str, mapping: Mapping) -> TableStrategy:
        """Detect the DML strategy for a single target table.
        Per-target: traces whether Update Strategy actually feeds THIS target.
        """
        tx_types = [tx.type for tx in mapping.transformations]
        source_names = [s.name for s in mapping.sources]
        dml_strategy = 'INSERT'
        reason = 'Default: no update/merge signals detected'
        merge_keys: List[str] = []
        warnings: List[str] = []

        # ── Signal 1: Update Strategy that feeds THIS target ──────────
        # Only apply MERGE if the Update Strategy connects to this target
        # via connectors (not blindly to all targets in the mapping)
        for tx in mapping.transformations:
            if tx.type in self.MERGE_SIGNAL_TYPES:
                if self._update_strategy_feeds_target(tx, target_name, mapping):
                    # Check expression: only MERGE if DD_UPDATE present
                    if tx.update_strategy_expression:
                        expr_upper = tx.update_strategy_expression.upper()
                        if 'DD_UPDATE' in expr_upper:
                            dml_strategy = 'MERGE'
                            reason = f'Update Strategy {tx.name} feeds {target_name} with DD_UPDATE'
                            merge_keys = self._extract_merge_keys_for_target(tx, target_name, mapping)
                            break
                        # DD_INSERT / DD_REJECT without DD_UPDATE = INSERT
                    else:
                        # Update Strategy type with no expression — assume MERGE
                        dml_strategy = 'MERGE'
                        reason = f'Update Strategy {tx.name} feeds {target_name}'
                        merge_keys = self._extract_merge_keys_for_target(tx, target_name, mapping)
                        break

        # ── Signal 2: SCD markers ─────────────────────────────────────
        if dml_strategy == 'INSERT':
            for tx in mapping.transformations:
                tx_props = tx.properties or {}
                if tx_props.get('is_slowly_changing') or tx_props.get('scd_type'):
                    dml_strategy = 'MERGE'
                    reason = f'SCD marker found on transformation {tx.name}'
                    break
                # Check update_strategy_expression on non-UPDTRANS types
                if tx.update_strategy_expression and tx.type not in self.MERGE_SIGNAL_TYPES:
                    expr_upper = tx.update_strategy_expression.upper()
                    if 'DD_UPDATE' in expr_upper:
                        dml_strategy = 'MERGE'
                        reason = f'Update strategy expression with DD_UPDATE: {tx.update_strategy_expression[:50]}'
                        break

        # ── Schema Resolution ─────────────────────────────────────────
        schema = self._resolve_schema(target_name, mapping)

        # ── Merge keys: prefer DDL PK, then extract from UPDTRANS, then infer
        if dml_strategy == 'MERGE' and not merge_keys:
            # Try DDL primary keys first
            merge_keys = self._get_ddl_primary_keys(target_name)
            if not merge_keys:
                merge_keys = self._infer_merge_keys(target_name, mapping)
            if not merge_keys:
                warnings.append(f"MERGE detected but no merge keys found for {target_name}")

        return TableStrategy(
            table_name=target_name,
            mapping_name=mapping.name,
            dml_strategy=dml_strategy,
            schema=schema,
            reason=reason,
            source_tables=source_names,
            transformation_types=list(set(tx_types)),
            merge_keys=merge_keys,
            warnings=warnings,
        )

    def _update_strategy_feeds_target(self, update_tx: Transformation,
                                       target_name: str, mapping: Mapping) -> bool:
        """Check if an Update Strategy transformation connects to a specific target
        via the connector graph (directly or through intermediate transformations).
        """
        # Direct connection: UPDTRANS -> target
        for c in mapping.connectors:
            if c.from_instance == update_tx.name and c.to_instance == target_name:
                return True

        # Indirect: UPDTRANS -> intermediate -> target
        # Find all instances that UPDTRANS feeds
        downstream = {c.to_instance for c in mapping.connectors if c.from_instance == update_tx.name}
        # Check if any of those feed the target
        for c in mapping.connectors:
            if c.from_instance in downstream and c.to_instance == target_name:
                return True

        # Also check shortcut names: target may be referenced by shortcut name in connectors
        # Build set of all names that might refer to this target
        target_variants = {target_name}
        for c in mapping.connectors:
            # If no direct match, check if any connector leads to a variant of target_name
            # We look at instances with type TARGET in the XML mapping
            pass

        # Fallback: if mapping has only one target, any UPDTRANS applies to it
        if len(mapping.targets) == 1:
            return True

        return False

    def _extract_merge_keys_for_target(self, update_tx: Transformation,
                                        target_name: str, mapping: Mapping) -> List[str]:
        """Extract merge keys, mapping UPDTRANS port names to actual target column names."""
        # Get target columns
        target_cols = set()
        for target in mapping.targets:
            if target.name == target_name:
                target_cols = {c.name.upper() for c in target.columns}
                break

        # Build connector map: UPDTRANS field -> target field
        updtrans_to_target: Dict[str, str] = {}
        for c in mapping.connectors:
            if c.from_instance == update_tx.name and c.to_instance == target_name:
                updtrans_to_target[c.from_field.upper()] = c.to_field.upper()

        keys = []
        for fld in update_tx.fields:
            expr = (fld.expression or '').upper()
            if 'DD_UPDATE' in expr or 'DD_INSERT' in expr or 'DD_DELETE' in expr:
                continue
            # Input ports without strategy expressions are likely key columns
            if fld.port_type and 'INPUT' in fld.port_type.upper() and not fld.expression:
                # Map to actual target column name via connector
                target_col = updtrans_to_target.get(fld.name.upper(), fld.name.upper())
                if target_col in target_cols:
                    keys.append(target_col)
                elif fld.name.upper() in target_cols:
                    keys.append(fld.name.upper())

        return keys

    def _get_ddl_primary_keys(self, target_name: str) -> List[str]:
        """Get primary key columns from DDL parser results."""
        if not hasattr(self, '_ddl_objects') or not self._ddl_objects:
            return []
        ddl_obj = self._ddl_objects.get(target_name.upper())
        if not ddl_obj:
            return []
        return [c.name.upper() for c in ddl_obj.columns if getattr(c, 'is_primary_key', False)]

    def _extract_merge_keys(self, update_tx: Transformation, mapping: Mapping) -> List[str]:
        """Extract merge/join keys from an Update Strategy transformation."""
        keys = []
        for fld in update_tx.fields:
            # Fields with expressions like DD_UPDATE, DD_INSERT are strategy flags
            expr = (fld.expression or '').upper()
            if 'DD_UPDATE' in expr or 'DD_INSERT' in expr or 'DD_DELETE' in expr:
                continue
            # Input ports that aren't strategy expressions are likely key columns
            if fld.port_type and 'INPUT' in fld.port_type.upper() and not fld.expression:
                keys.append(fld.name)
        return keys

    def _infer_merge_keys(self, target_name: str, mapping: Mapping) -> List[str]:
        """Infer merge keys from target columns — look for columns with key-like names."""
        keys = []
        for target in mapping.targets:
            if target.name == target_name:
                for col in target.columns:
                    # Heuristic: columns ending with _ID, _KEY, or named ID are likely keys
                    name_upper = col.name.upper()
                    if name_upper.endswith('_ID') or name_upper.endswith('_KEY') or name_upper == 'ID':
                        keys.append(col.name)
                break
        # Only return first key if multiple found (conservative)
        return keys[:1] if keys else keys

    def _resolve_schema(self, target_name: str, mapping: Mapping) -> str:
        """Resolve the schema for a target table."""
        for target in mapping.targets:
            if target.name == target_name:
                # 1. Check owner field
                owner = getattr(target, 'owner', '') or ''
                if owner.strip():
                    return owner.strip().upper()

                # 2. Parse from database_name attribute
                db_name = getattr(target, 'database_name', '') or ''
                if db_name.strip():
                    return db_name.strip().upper()

                # 3. Parse from qualified table name
                full_name = getattr(target, 'full_name', '') or target.name
                if '.' in full_name:
                    parts = full_name.split('.')
                    if len(parts) >= 2:
                        return parts[-2].strip().upper()
                break

        return self.default_schema


def main():
    print("StrategyDetector requires a ParsedRepository. Use via cli.py or orchestrator.")


if __name__ == '__main__':
    main()
