"""
Expression Translator - Converts Informatica expressions to Snowflake SQL.

Ported from AutoMedallion_New_latest.
Provides comprehensive translation of Informatica PowerCenter
transformation expressions to equivalent Snowflake SQL expressions.

Supports 60+ Informatica functions across categories:
- Conditional (IIF, DECODE, IN)
- Null handling (ISNULL, NVL, NVL2, NULLIF)
- String functions (INSTR, REPLACESTR, REPLACECHR, REG_EXTRACT, REG_MATCH,
  REG_REPLACE, SUBSTR, LENGTH, LTRIM, RTRIM, UPPER, LOWER, INITCAP,
  LPAD, RPAD, CONCAT, CHR, ASCII, REVERSE, MD5, SHA1, SHA256)
- Date functions (ADD_TO_DATE, DATE_DIFF, TRUNC, GET_DATE_PART, SET_DATE_PART,
  TO_DATE, TO_CHAR, IS_DATE, LAST_DAY, SYSDATE, SYSTIMESTAMP, SESSSTARTTIME)
- Aggregate functions (SUM, AVG, MIN, MAX, COUNT, FIRST, LAST, MEDIAN, PERCENTILE)
- Mathematical functions (ABS, CEIL, FLOOR, ROUND, TRUNC, POWER, SQRT, MOD, SIGN, LOG, LN, EXP)
- Conversion functions (TO_INTEGER, TO_DECIMAL, TO_FLOAT, TO_BIGINT)
- Parameter translation ($$VAR, $PM_*, $*)
- Lookup reference translation (:LKP.*)
- Post-processing (LTRIM/RTRIM simplification to TRIM, bind variable fix)

Usage:
    translator = ExpressionTranslator()
    result = translator.translate("IIF(ISNULL(COL1), 'N/A', COL1)")
    print(result.translated)  # "IFF((COL1 IS NULL), 'N/A', COL1)"
"""

import re
from typing import Any, Dict, List, Optional, Tuple
from dataclasses import dataclass, field
from enum import Enum


class FunctionCategory(Enum):
    """Categories of Informatica functions."""
    CONDITIONAL = "conditional"
    NULL_HANDLING = "null_handling"
    STRING = "string"
    DATE = "date"
    AGGREGATE = "aggregate"
    MATHEMATICAL = "mathematical"
    CONVERSION = "conversion"
    VARIABLE = "variable"
    SPECIAL = "special"


@dataclass
class FunctionMapping:
    """Mapping from Informatica function to Snowflake equivalent."""
    informatica_pattern: str
    snowflake_template: str
    category: FunctionCategory
    requires_custom_logic: bool = False
    notes: str = ""


@dataclass
class TranslationResult:
    """Result of expression translation."""
    original: str
    translated: str
    success: bool = True
    warnings: List[str] = field(default_factory=list)
    functions_translated: List[str] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "original": self.original,
            "translated": self.translated,
            "success": self.success,
            "warnings": self.warnings,
            "functions_translated": self.functions_translated,
        }


class ExpressionTranslator:
    """
    Translates Informatica PowerCenter expressions to Snowflake SQL.
    Provides comprehensive translation of 60+ Informatica functions.
    """

    def __init__(self):
        self._function_mappings = self._build_function_mappings()

    def _build_function_mappings(self) -> Dict[str, FunctionMapping]:
        mappings = {}

        # === CONDITIONAL ===
        mappings["IIF"] = FunctionMapping(
            informatica_pattern=r"IIF\s*\(\s*(.+?)\s*,\s*(.+?)\s*,\s*(.+?)\s*\)",
            snowflake_template="IFF({0}, {1}, {2})",
            category=FunctionCategory.CONDITIONAL,
        )
        mappings["DECODE"] = FunctionMapping(
            informatica_pattern=r"DECODE\s*\((.+)\)",
            snowflake_template="CASE {0} END",
            category=FunctionCategory.CONDITIONAL,
            requires_custom_logic=True,
        )
        mappings["IN"] = FunctionMapping(
            informatica_pattern=r"\bIN\s*\(\s*([^,]+?)\s*,\s*(.+?)\s*\)",
            snowflake_template="{0} IN ({1})",
            category=FunctionCategory.CONDITIONAL,
            requires_custom_logic=True,
        )

        # === NULL HANDLING ===
        mappings["ISNULL"] = FunctionMapping(
            informatica_pattern=r"ISNULL\s*\(\s*(.+?)\s*\)",
            snowflake_template="({0} IS NULL)",
            category=FunctionCategory.NULL_HANDLING,
        )
        mappings["NVL"] = FunctionMapping(
            informatica_pattern=r"NVL\s*\(\s*(.+?)\s*,\s*(.+?)\s*\)",
            snowflake_template="COALESCE({0}, {1})",
            category=FunctionCategory.NULL_HANDLING,
        )
        mappings["NVL2"] = FunctionMapping(
            informatica_pattern=r"NVL2\s*\(\s*(.+?)\s*,\s*(.+?)\s*,\s*(.+?)\s*\)",
            snowflake_template="IFF({0} IS NOT NULL, {1}, {2})",
            category=FunctionCategory.NULL_HANDLING,
        )
        mappings["NULLIF"] = FunctionMapping(
            informatica_pattern=r"NULLIF\s*\(\s*(.+?)\s*,\s*(.+?)\s*\)",
            snowflake_template="NULLIF({0}, {1})",
            category=FunctionCategory.NULL_HANDLING,
        )

        # === STRING ===
        mappings["INSTR"] = FunctionMapping(
            informatica_pattern=r"INSTR\s*\(\s*(.+?)\s*,\s*(.+?)(?:\s*,\s*(.+?))?\s*\)",
            snowflake_template="POSITION({1} IN {0})",
            category=FunctionCategory.STRING,
            requires_custom_logic=True,
        )
        mappings["REPLACESTR"] = FunctionMapping(
            informatica_pattern=r"REPLACESTR\s*\(\s*(.+?)\s*,\s*(.+?)\s*,\s*(.+?)\s*\)",
            snowflake_template="REPLACE({0}, {1}, {2})",
            category=FunctionCategory.STRING,
        )
        mappings["REPLACECHR"] = FunctionMapping(
            informatica_pattern=r"REPLACECHR\s*\(\s*(?:\d+|TRUE|FALSE)\s*,\s*(.+?)\s*,\s*(.+?)\s*,\s*(.*?)\s*\)",
            snowflake_template="REPLACE({0}, {1}, {2})",
            category=FunctionCategory.STRING,
        )
        mappings["REG_EXTRACT"] = FunctionMapping(
            informatica_pattern=r"REG_EXTRACT\s*\(\s*(.+?)\s*,\s*'(.+?)'\s*,\s*(\d+)\s*\)",
            snowflake_template="REGEXP_SUBSTR({0}, '{1}', 1, 1, 'e', {2})",
            category=FunctionCategory.STRING,
        )
        mappings["REG_MATCH"] = FunctionMapping(
            informatica_pattern=r"REG_MATCH\s*\(\s*(.+?)\s*,\s*'(.+?)'\s*\)",
            snowflake_template="REGEXP_LIKE({0}, '{1}')",
            category=FunctionCategory.STRING,
        )
        mappings["REG_REPLACE"] = FunctionMapping(
            informatica_pattern=r"REG_REPLACE\s*\(\s*(.+?)\s*,\s*'(.+?)'\s*,\s*'(.+?)'\s*\)",
            snowflake_template="REGEXP_REPLACE({0}, '{1}', '{2}')",
            category=FunctionCategory.STRING,
        )
        mappings["SUBSTR"] = FunctionMapping(
            informatica_pattern=r"SUBSTR\s*\(\s*(.+?)\s*,\s*(.+?)(?:\s*,\s*(.+?))?\s*\)",
            snowflake_template="SUBSTR({0}, {1}, {2})",
            category=FunctionCategory.STRING,
            requires_custom_logic=True,
        )
        mappings["LENGTH"] = FunctionMapping(
            informatica_pattern=r"LENGTH\s*\(\s*(.+?)\s*\)",
            snowflake_template="LENGTH({0})",
            category=FunctionCategory.STRING,
        )
        mappings["LTRIM"] = FunctionMapping(
            informatica_pattern=r"LTRIM\s*\(\s*(.+?)(?:\s*,\s*(.+?))?\s*\)",
            snowflake_template="LTRIM({0}, {1})",
            category=FunctionCategory.STRING,
            requires_custom_logic=True,
        )
        mappings["RTRIM"] = FunctionMapping(
            informatica_pattern=r"RTRIM\s*\(\s*(.+?)(?:\s*,\s*(.+?))?\s*\)",
            snowflake_template="RTRIM({0}, {1})",
            category=FunctionCategory.STRING,
            requires_custom_logic=True,
        )
        for name in ("UPPER", "LOWER", "INITCAP", "REVERSE"):
            mappings[name] = FunctionMapping(
                informatica_pattern=rf"\b{name}\s*\(\s*(.+?)\s*\)",
                snowflake_template=f"{name}({{0}})",
                category=FunctionCategory.STRING,
            )
        for name in ("LPAD", "RPAD"):
            mappings[name] = FunctionMapping(
                informatica_pattern=rf"{name}\s*\(\s*(.+?)\s*,\s*(.+?)(?:\s*,\s*(.+?))?\s*\)",
                snowflake_template=f"{name}({{0}}, {{1}}, {{2}})",
                category=FunctionCategory.STRING,
                requires_custom_logic=True,
            )
        mappings["CONCAT"] = FunctionMapping(
            informatica_pattern=r"CONCAT\s*\((.+)\)",
            snowflake_template="CONCAT({0})",
            category=FunctionCategory.STRING,
        )
        for name in ("CHR", "ASCII"):
            mappings[name] = FunctionMapping(
                informatica_pattern=rf"\b{name}\s*\(\s*(.+?)\s*\)",
                snowflake_template=f"{name}({{0}})",
                category=FunctionCategory.STRING,
            )
        mappings["MD5"] = FunctionMapping(
            informatica_pattern=r"\bMD5\s*\(\s*(.+?)\s*\)",
            snowflake_template="MD5({0})",
            category=FunctionCategory.STRING,
        )
        mappings["SHA1"] = FunctionMapping(
            informatica_pattern=r"\bSHA1\s*\(\s*(.+?)\s*\)",
            snowflake_template="SHA1({0})",
            category=FunctionCategory.STRING,
        )
        mappings["SHA256"] = FunctionMapping(
            informatica_pattern=r"\bSHA256\s*\(\s*(.+?)\s*\)",
            snowflake_template="SHA2({0}, 256)",
            category=FunctionCategory.STRING,
        )

        # === DATE ===
        mappings["SYSDATE"] = FunctionMapping(
            informatica_pattern=r"\bSYSDATE\b",
            snowflake_template="CURRENT_DATE()",
            category=FunctionCategory.DATE,
        )
        mappings["SYSTIMESTAMP"] = FunctionMapping(
            informatica_pattern=r"\bSYSTIMESTAMP\b",
            snowflake_template="CURRENT_TIMESTAMP()",
            category=FunctionCategory.DATE,
        )
        mappings["SESSSTARTTIME"] = FunctionMapping(
            informatica_pattern=r"\bSESSSTARTTIME\b",
            snowflake_template="CURRENT_TIMESTAMP()",
            category=FunctionCategory.DATE,
        )
        mappings["ADD_TO_DATE"] = FunctionMapping(
            informatica_pattern=r"ADD_TO_DATE\s*\(\s*(.+?)\s*,\s*'(\w+)'\s*,\s*(.+?)\s*\)",
            snowflake_template="DATEADD({1}, {2}, {0})",
            category=FunctionCategory.DATE,
            requires_custom_logic=True,
        )
        mappings["DATE_DIFF"] = FunctionMapping(
            informatica_pattern=r"DATE_DIFF\s*\(\s*(.+?)\s*,\s*(.+?)\s*,\s*'(\w+)'\s*\)",
            snowflake_template="DATEDIFF({2}, {1}, {0})",
            category=FunctionCategory.DATE,
            requires_custom_logic=True,
        )
        mappings["TRUNC_DATE"] = FunctionMapping(
            informatica_pattern=r"TRUNC\s*\(\s*(.+?)\s*,\s*'(\w+)'\s*\)",
            snowflake_template="DATE_TRUNC('{1}', {0})",
            category=FunctionCategory.DATE,
            requires_custom_logic=True,
        )
        mappings["GET_DATE_PART"] = FunctionMapping(
            informatica_pattern=r"GET_DATE_PART\s*\(\s*(.+?)\s*,\s*'(\w+)'\s*\)",
            snowflake_template="DATE_PART('{1}', {0})",
            category=FunctionCategory.DATE,
        )
        mappings["TO_DATE"] = FunctionMapping(
            informatica_pattern=r"TO_DATE\s*\(\s*(.+?)\s*,\s*'(.+?)'\s*\)",
            snowflake_template="TO_DATE({0}, '{1}')",
            category=FunctionCategory.DATE,
            requires_custom_logic=True,
        )
        mappings["TO_CHAR"] = FunctionMapping(
            informatica_pattern=r"TO_CHAR\s*\(\s*(.+?)\s*,\s*'(.+?)'\s*\)",
            snowflake_template="TO_CHAR({0}, '{1}')",
            category=FunctionCategory.DATE,
            requires_custom_logic=True,
        )
        mappings["IS_DATE"] = FunctionMapping(
            informatica_pattern=r"IS_DATE\s*\(\s*(.+?)(?:\s*,\s*'(.+?)')?\s*\)",
            snowflake_template="TRY_TO_DATE({0}) IS NOT NULL",
            category=FunctionCategory.DATE,
            requires_custom_logic=True,
        )
        mappings["LAST_DAY"] = FunctionMapping(
            informatica_pattern=r"LAST_DAY\s*\(\s*(.+?)\s*\)",
            snowflake_template="LAST_DAY({0})",
            category=FunctionCategory.DATE,
        )
        mappings["SET_DATE_PART"] = FunctionMapping(
            informatica_pattern=r"SET_DATE_PART\s*\(\s*(.+?)\s*,\s*'(\w+)'\s*,\s*(.+?)\s*\)",
            snowflake_template="DATE_FROM_PARTS(YEAR({0}), MONTH({0}), DAY({0}))",
            category=FunctionCategory.DATE,
            requires_custom_logic=True,
        )

        # === AGGREGATE ===
        for name in ("SUM", "AVG", "MIN", "MAX", "COUNT", "MEDIAN"):
            mappings[name] = FunctionMapping(
                informatica_pattern=rf"\b{name}\s*\(\s*(.+?)\s*\)",
                snowflake_template=f"{name}({{0}})",
                category=FunctionCategory.AGGREGATE,
            )
        mappings["FIRST"] = FunctionMapping(
            informatica_pattern=r"\bFIRST\s*\(\s*(.+?)\s*\)",
            snowflake_template="FIRST_VALUE({0})",
            category=FunctionCategory.AGGREGATE,
        )
        mappings["LAST"] = FunctionMapping(
            informatica_pattern=r"\bLAST\s*\(\s*(.+?)\s*\)",
            snowflake_template="LAST_VALUE({0})",
            category=FunctionCategory.AGGREGATE,
        )
        mappings["PERCENTILE"] = FunctionMapping(
            informatica_pattern=r"\bPERCENTILE\s*\(\s*(.+?)\s*,\s*(.+?)\s*\)",
            snowflake_template="PERCENTILE_CONT({1}) WITHIN GROUP (ORDER BY {0})",
            category=FunctionCategory.AGGREGATE,
        )

        # === MATHEMATICAL ===
        for name in ("ABS", "CEIL", "FLOOR", "SQRT", "SIGN", "LN", "EXP"):
            mappings[name] = FunctionMapping(
                informatica_pattern=rf"\b{name}\s*\(\s*(.+?)\s*\)",
                snowflake_template=f"{name}({{0}})",
                category=FunctionCategory.MATHEMATICAL,
            )
        for name in ("POWER", "MOD", "LOG"):
            mappings[name] = FunctionMapping(
                informatica_pattern=rf"\b{name}\s*\(\s*(.+?)\s*,\s*(.+?)\s*\)",
                snowflake_template=f"{name}({{0}}, {{1}})",
                category=FunctionCategory.MATHEMATICAL,
            )
        mappings["ROUND"] = FunctionMapping(
            informatica_pattern=r"\bROUND\s*\(\s*(.+?)(?:\s*,\s*(.+?))?\s*\)",
            snowflake_template="ROUND({0}, {1})",
            category=FunctionCategory.MATHEMATICAL,
            requires_custom_logic=True,
        )
        mappings["TRUNC_NUM"] = FunctionMapping(
            informatica_pattern=r"TRUNC\s*\(\s*(.+?)(?:\s*,\s*(\d+))?\s*\)",
            snowflake_template="TRUNC({0}, {1})",
            category=FunctionCategory.MATHEMATICAL,
            requires_custom_logic=True,
        )

        # === CONVERSION ===
        mappings["TO_INTEGER"] = FunctionMapping(
            informatica_pattern=r"TO_INTEGER\s*\(\s*(.+?)\s*\)",
            snowflake_template="TRY_CAST({0} AS INTEGER)",
            category=FunctionCategory.CONVERSION,
        )
        mappings["TO_DECIMAL"] = FunctionMapping(
            informatica_pattern=r"TO_DECIMAL\s*\(\s*(.+?)(?:\s*,\s*(\d+)\s*,\s*(\d+))?\s*\)",
            snowflake_template="TRY_CAST({0} AS DECIMAL({1}, {2}))",
            category=FunctionCategory.CONVERSION,
            requires_custom_logic=True,
        )
        mappings["TO_FLOAT"] = FunctionMapping(
            informatica_pattern=r"TO_FLOAT\s*\(\s*(.+?)\s*\)",
            snowflake_template="TRY_CAST({0} AS FLOAT)",
            category=FunctionCategory.CONVERSION,
        )
        mappings["TO_BIGINT"] = FunctionMapping(
            informatica_pattern=r"TO_BIGINT\s*\(\s*(.+?)\s*\)",
            snowflake_template="TRY_CAST({0} AS BIGINT)",
            category=FunctionCategory.CONVERSION,
        )

        return mappings

    # ─── Main translate method ────────────────────────────────────────────

    def translate(self, expression: str) -> TranslationResult:
        """Translate an Informatica expression to Snowflake SQL."""
        if not expression:
            return TranslationResult(original=expression, translated=expression, success=True)

        result = TranslationResult(original=expression, translated=expression)

        try:
            translated = expression

            # Multi-pass to handle nested functions
            max_passes = 5
            for _ in range(max_passes):
                prev = translated
                for func_name, mapping in self._function_mappings.items():
                    if mapping.requires_custom_logic:
                        translated = self._apply_custom_translation(translated, func_name, mapping, result)
                    else:
                        translated = self._apply_simple_translation(translated, func_name, mapping, result)
                if translated == prev:
                    break

            # Translate parameters
            translated = self._translate_parameters(translated, result)
            # Translate lookup references
            translated = self._translate_lookup_refs(translated, result)
            # Post-process: simplify nested LTRIM/RTRIM to TRIM
            translated = self._simplify_trim(translated)
            # Fix quoted bind variables
            translated = self._fix_quoted_bind_variables(translated)

            result.translated = translated
            result.success = True

        except Exception as e:
            result.success = False
            result.warnings.append(f"Translation error: {str(e)}")

        return result

    # ─── Simple translation ───────────────────────────────────────────────

    def _apply_simple_translation(self, expression, func_name, mapping, result):
        pattern = re.compile(mapping.informatica_pattern, re.IGNORECASE)

        def replacer(match):
            result.functions_translated.append(func_name)
            return mapping.snowflake_template.format(*match.groups())

        return pattern.sub(replacer, expression)

    # ─── Custom translation dispatch ──────────────────────────────────────

    def _apply_custom_translation(self, expression, func_name, mapping, result):
        dispatch = {
            "IN": self._translate_in_function,
            "DECODE": self._translate_decode,
            "INSTR": self._translate_instr,
            "ADD_TO_DATE": self._translate_add_to_date,
            "DATE_DIFF": self._translate_date_diff,
            "TRUNC_DATE": self._translate_trunc_date,
            "TO_DATE": self._translate_to_date,
            "TO_CHAR": self._translate_to_char,
            "IS_DATE": self._translate_is_date,
            "TO_DECIMAL": self._translate_to_decimal,
            "SET_DATE_PART": self._translate_set_date_part,
        }
        if func_name in dispatch:
            return dispatch[func_name](expression, result)
        if func_name in ("SUBSTR", "LTRIM", "RTRIM", "LPAD", "RPAD", "ROUND", "TRUNC_NUM"):
            return self._translate_with_optional_args(expression, func_name, mapping, result)
        return expression

    # ─── IN function ──────────────────────────────────────────────────────

    def _translate_in_function(self, expression, result):
        """Translate Informatica IN(field, val1, val2, ...) to field IN (val1, val2, ...)."""
        i = 0
        output = []
        upper_expr = expression.upper()

        while i < len(expression):
            remaining_upper = upper_expr[i:]
            # Match IN( with NO space — Informatica function syntax is always IN(args).
            # SQL syntax IN (...) has a space and won't re-match.
            in_match = re.match(r'\bIN\(', remaining_upper)

            if not in_match:
                output.append(expression[i])
                i += 1
                continue

            if i > 0:
                prev_char = expression[i - 1]
                # Skip if IN is part of a word like MAIN, JOIN, BEGIN (alphanumeric or _)
                if prev_char.isalnum() or prev_char == '_':
                    output.append(expression[i])
                    i += 1
                    continue

            paren_start = i + in_match.end() - 1
            depth = 1
            j = paren_start + 1
            in_string = False
            string_char = None

            while j < len(expression) and depth > 0:
                c = expression[j]
                if in_string:
                    if c == string_char:
                        in_string = False
                elif c in ("'", '"'):
                    in_string = True
                    string_char = c
                elif c == '(':
                    depth += 1
                elif c == ')':
                    depth -= 1
                j += 1

            if depth == 0:
                inner = expression[paren_start + 1:j - 1]
                args = self._parse_function_args(inner)
                if len(args) >= 2:
                    result.functions_translated.append("IN")
                    field_arg = args[0].strip()
                    values = ", ".join(a.strip() for a in args[1:])
                    output.append(f"{field_arg} IN ({values})")
                    i = j
                    continue

            output.append(expression[i])
            i += 1

        return "".join(output)

    # ─── DECODE ───────────────────────────────────────────────────────────

    def _translate_decode(self, expression, result):
        """Translate DECODE to CASE expression. Handles DECODE(TRUE, ...) searched-CASE.
        Uses balanced-paren matching instead of greedy regex to avoid over-consuming.
        """
        upper_expr = expression.upper()
        output = []
        i = 0

        while i < len(expression):
            # Find DECODE( with word boundary
            match = re.match(r'\bDECODE\s*\(', upper_expr[i:])
            if not match:
                output.append(expression[i])
                i += 1
                continue

            # Check word boundary: ensure DECODE isn't part of another identifier
            if i > 0 and (expression[i - 1].isalnum() or expression[i - 1] == '_'):
                output.append(expression[i])
                i += 1
                continue

            # Find the balanced closing paren
            paren_start = i + match.end() - 1  # position of opening '('
            depth = 1
            j = paren_start + 1
            in_string = False
            string_char = None

            while j < len(expression) and depth > 0:
                c = expression[j]
                if in_string:
                    if c == string_char:
                        in_string = False
                elif c in ("'", '"'):
                    in_string = True
                    string_char = c
                elif c == '(':
                    depth += 1
                elif c == ')':
                    depth -= 1
                j += 1

            if depth != 0:
                # Unbalanced parens — leave as-is
                output.append(expression[i])
                i += 1
                continue

            # Extract inner content between balanced parens
            inner = expression[paren_start + 1:j - 1]
            args = self._parse_function_args(inner)

            if len(args) < 3:
                result.warnings.append("DECODE requires at least 3 arguments")
                output.append(expression[i:j])
                i = j
                continue

            result.functions_translated.append("DECODE")
            value = args[0].strip()
            pairs = args[1:]

            # DECODE(TRUE, ...) → searched CASE
            if value.upper() == "TRUE":
                case_parts = ["CASE"]
                k = 0
                while k < len(pairs) - 1:
                    case_parts.append(f"WHEN {pairs[k].strip()} THEN {pairs[k + 1].strip()}")
                    k += 2
                if k < len(pairs):
                    case_parts.append(f"ELSE {pairs[k].strip()}")
                case_parts.append("END")
                output.append(" ".join(case_parts))
            else:
                # Standard DECODE → simple CASE
                case_parts = [f"CASE {value.strip()}"]
                k = 0
                while k < len(pairs) - 1:
                    case_parts.append(f"WHEN {pairs[k].strip()} THEN {pairs[k + 1].strip()}")
                    k += 2
                if k < len(pairs):
                    case_parts.append(f"ELSE {pairs[k].strip()}")
                case_parts.append("END")
                output.append(" ".join(case_parts))

            i = j

        return "".join(output)

    # ─── INSTR ────────────────────────────────────────────────────────────

    def _translate_instr(self, expression, result):
        pattern = re.compile(r"INSTR\s*\(\s*(.+?)\s*,\s*(.+?)(?:\s*,\s*(.+?))?\s*\)", re.IGNORECASE)

        def replacer(match):
            result.functions_translated.append("INSTR")
            string, substring, start_pos = match.group(1), match.group(2), match.group(3)
            if start_pos:
                return f"POSITION({substring} IN SUBSTR({string}, {start_pos})) + {start_pos} - 1"
            return f"POSITION({substring} IN {string})"

        return pattern.sub(replacer, expression)

    # ─── Date unit maps ───────────────────────────────────────────────────

    _DATE_UNIT_MAP = {
        "YY": "YEAR", "YYYY": "YEAR", "Y": "YEAR",
        "MM": "MONTH", "MON": "MONTH", "M": "MONTH",
        "DD": "DAY", "D": "DAY", "DDD": "DAY",
        "HH": "HOUR", "HH24": "HOUR", "H": "HOUR",
        "MI": "MINUTE", "MIN": "MINUTE",
        "SS": "SECOND", "S": "SECOND",
        "Q": "QUARTER", "WW": "WEEK", "W": "WEEK",
    }

    def _translate_add_to_date(self, expression, result):
        pattern = re.compile(r"ADD_TO_DATE\s*\(\s*(.+?)\s*,\s*'(\w+)'\s*,\s*(.+?)\s*\)", re.IGNORECASE)

        def replacer(match):
            result.functions_translated.append("ADD_TO_DATE")
            date_val, unit, amount = match.group(1), match.group(2).upper(), match.group(3)
            sf_unit = self._DATE_UNIT_MAP.get(unit, unit)
            return f"DATEADD({sf_unit}, {amount}, {date_val})"

        return pattern.sub(replacer, expression)

    def _translate_date_diff(self, expression, result):
        pattern = re.compile(r"DATE_DIFF\s*\(\s*(.+?)\s*,\s*(.+?)\s*,\s*'(\w+)'\s*\)", re.IGNORECASE)

        def replacer(match):
            result.functions_translated.append("DATE_DIFF")
            date1, date2, unit = match.group(1), match.group(2), match.group(3).upper()
            sf_unit = self._DATE_UNIT_MAP.get(unit, unit)
            return f"DATEDIFF({sf_unit}, {date2}, {date1})"

        return pattern.sub(replacer, expression)

    def _translate_trunc_date(self, expression, result):
        pattern = re.compile(r"TRUNC\s*\(\s*(.+?)\s*,\s*'(\w+)'\s*\)", re.IGNORECASE)

        def replacer(match):
            result.functions_translated.append("TRUNC_DATE")
            date_val, fmt = match.group(1), match.group(2).upper()
            sf_fmt = self._DATE_UNIT_MAP.get(fmt, fmt)
            return f"DATE_TRUNC('{sf_fmt}', {date_val})"

        return pattern.sub(replacer, expression)

    def _translate_to_date(self, expression, result):
        pattern = re.compile(r"TO_DATE\s*\(\s*(.+?)\s*,\s*'(.+?)'\s*\)", re.IGNORECASE)

        def replacer(match):
            result.functions_translated.append("TO_DATE")
            value, fmt = match.group(1), match.group(2)
            sf_fmt = self._convert_date_format(fmt)
            return f"TO_DATE({value}, '{sf_fmt}')"

        return pattern.sub(replacer, expression)

    def _translate_to_char(self, expression, result):
        pattern = re.compile(r"TO_CHAR\s*\(\s*(.+?)\s*,\s*'(.+?)'\s*\)", re.IGNORECASE)

        def replacer(match):
            result.functions_translated.append("TO_CHAR")
            value, fmt = match.group(1), match.group(2)
            sf_fmt = self._convert_date_format(fmt)
            return f"TO_CHAR({value}, '{sf_fmt}')"

        return pattern.sub(replacer, expression)

    def _translate_is_date(self, expression, result):
        pattern = re.compile(r"IS_DATE\s*\(\s*(.+?)(?:\s*,\s*'(.+?)')?\s*\)", re.IGNORECASE)

        def replacer(match):
            result.functions_translated.append("IS_DATE")
            value, fmt = match.group(1), match.group(2)
            if fmt:
                sf_fmt = self._convert_date_format(fmt)
                return f"TRY_TO_DATE({value}, '{sf_fmt}') IS NOT NULL"
            return f"TRY_TO_DATE({value}) IS NOT NULL"

        return pattern.sub(replacer, expression)

    def _translate_set_date_part(self, expression, result):
        pattern = re.compile(r"SET_DATE_PART\s*\(\s*(.+?)\s*,\s*'(\w+)'\s*,\s*(.+?)\s*\)", re.IGNORECASE)

        def replacer(match):
            result.functions_translated.append("SET_DATE_PART")
            date_val, part, new_val = match.group(1), match.group(2).upper(), match.group(3)
            year_expr = f"YEAR({date_val})"
            month_expr = f"MONTH({date_val})"
            day_expr = f"DAY({date_val})"
            if part in ("YY", "YYYY", "Y"):
                year_expr = new_val
            elif part in ("MM", "MON", "M"):
                month_expr = new_val
            elif part in ("DD", "D"):
                day_expr = new_val
            return f"DATE_FROM_PARTS({year_expr}, {month_expr}, {day_expr})"

        return pattern.sub(replacer, expression)

    def _translate_to_decimal(self, expression, result):
        pattern = re.compile(r"TO_DECIMAL\s*\(\s*(.+?)(?:\s*,\s*(\d+)\s*,\s*(\d+))?\s*\)", re.IGNORECASE)

        def replacer(match):
            result.functions_translated.append("TO_DECIMAL")
            value = match.group(1)
            precision = match.group(2) or "38"
            scale = match.group(3) or "0"
            return f"TRY_CAST({value} AS DECIMAL({precision}, {scale}))"

        return pattern.sub(replacer, expression)

    # ─── Optional-arg handler ─────────────────────────────────────────────

    def _translate_with_optional_args(self, expression, func_name, mapping, result):
        pattern = re.compile(mapping.informatica_pattern, re.IGNORECASE)

        def replacer(match):
            result.functions_translated.append(func_name)
            groups = list(match.groups())
            if func_name in ("LTRIM", "RTRIM"):
                if groups[-1] is None:
                    groups[-1] = "' '"
                return f"{func_name}({groups[0]}, {groups[1]})"
            elif func_name == "SUBSTR":
                if len(groups) > 2 and groups[2] is None:
                    return f"SUBSTR({groups[0]}, {groups[1]})"
                return f"SUBSTR({groups[0]}, {groups[1]}, {groups[2]})"
            elif func_name in ("LPAD", "RPAD"):
                if groups[-1] is None:
                    groups[-1] = "' '"
                return f"{func_name}({groups[0]}, {groups[1]}, {groups[2]})"
            elif func_name in ("ROUND", "TRUNC_NUM"):
                if groups[-1] is None:
                    groups[-1] = "0"
                sf_func = "ROUND" if func_name == "ROUND" else "TRUNC"
                return f"{sf_func}({groups[0]}, {groups[1]})"
            return mapping.snowflake_template.format(*groups)

        return pattern.sub(replacer, expression)

    # ─── Parameter and lookup translation ─────────────────────────────────

    def _translate_parameters(self, expression, result):
        """Translate Informatica parameters to Snowflake bind variables."""
        expression = re.sub(r'\$\$(\w+)', r':V_\1', expression)
        expression = re.sub(r'\$PM(\w+)', r':P_\1', expression)
        expression = re.sub(r'\$(?!PM)(\w+)', r':P_\1', expression)
        return expression

    def _translate_lookup_refs(self, expression, result):
        """Translate :LKP.LOOKUP_NAME(port) → LOOKUP_NAME_port."""
        pattern = re.compile(r':LKP\.(\w+)\((\w+)\)', re.IGNORECASE)

        def replacer(match):
            result.functions_translated.append("LKP")
            return f"{match.group(1)}_{match.group(2)}"

        return pattern.sub(replacer, expression)

    # ─── Post-processing ──────────────────────────────────────────────────

    def _simplify_trim(self, expression):
        """Simplify nested LTRIM/RTRIM with space chars to TRIM."""
        patterns = [
            (r"LTRIM\s*\(\s*RTRIM\s*\(\s*(.+?)\s*,\s*'\s*'\s*\)\s*,\s*'\s*'\s*\)", r"TRIM(\1)"),
            (r"LTRIM\s*\(\s*RTRIM\s*\(\s*(.+?)\s*,\s*'\s*'\s*\)\s*\)", r"TRIM(\1)"),
            (r"LTRIM\s*\(\s*RTRIM\s*\(\s*(.+?)\s*\)\s*,\s*'\s*'\s*\)", r"TRIM(\1)"),
            (r"LTRIM\s*\(\s*RTRIM\s*\(\s*(.+?)\s*\)\s*\)", r"TRIM(\1)"),
            (r"RTRIM\s*\(\s*LTRIM\s*\(\s*(.+?)\s*,\s*'\s*'\s*\)\s*,\s*'\s*'\s*\)", r"TRIM(\1)"),
            (r"RTRIM\s*\(\s*LTRIM\s*\(\s*(.+?)\s*,\s*'\s*'\s*\)\s*\)", r"TRIM(\1)"),
            (r"RTRIM\s*\(\s*LTRIM\s*\(\s*(.+?)\s*\)\s*,\s*'\s*'\s*\)", r"TRIM(\1)"),
            (r"RTRIM\s*\(\s*LTRIM\s*\(\s*(.+?)\s*\)\s*\)", r"TRIM(\1)"),
        ]
        for pat, repl in patterns:
            expression = re.sub(pat, repl, expression, flags=re.IGNORECASE)
        return expression

    def _fix_quoted_bind_variables(self, expression):
        """Remove surrounding quotes from bind variables: ':P_VAR' → :P_VAR."""
        expression = re.sub(r"'(:[A-Za-z_]\w*)'", r"\1", expression)
        expression = re.sub(r'"(:[A-Za-z_]\w*)"', r"\1", expression)
        return expression

    # ─── Date format conversion ───────────────────────────────────────────

    def _convert_date_format(self, fmt):
        """Convert Informatica date format to Snowflake format."""
        format_map = {
            "J": "DDD",
            "SSSSS": "SSSSS",
            "RR": "YY",
            "RRRR": "YYYY",
        }
        result_fmt = fmt
        for inf_fmt, sf_fmt in format_map.items():
            result_fmt = result_fmt.replace(inf_fmt, sf_fmt)
        return result_fmt

    # ─── Argument parser ──────────────────────────────────────────────────

    def _parse_function_args(self, args_str):
        """Parse function arguments handling nested parentheses and strings."""
        args = []
        current = []
        depth = 0
        in_string = False
        string_char = None

        for char in args_str:
            if char in ("'", '"') and not in_string:
                in_string = True
                string_char = char
                current.append(char)
            elif char == string_char and in_string:
                in_string = False
                string_char = None
                current.append(char)
            elif char == '(' and not in_string:
                depth += 1
                current.append(char)
            elif char == ')' and not in_string:
                depth -= 1
                current.append(char)
            elif char == ',' and depth == 0 and not in_string:
                args.append(''.join(current).strip())
                current = []
            else:
                current.append(char)

        if current:
            args.append(''.join(current).strip())
        return args

    # ─── Public accessors ─────────────────────────────────────────────────

    def get_supported_functions(self) -> List[str]:
        return list(self._function_mappings.keys())

    def get_functions_by_category(self, category: FunctionCategory) -> List[str]:
        return [name for name, m in self._function_mappings.items() if m.category == category]


def main():
    translator = ExpressionTranslator()
    tests = [
        "IIF(ISNULL(COL1), 'N/A', COL1)",
        "ADD_TO_DATE(SYSDATE, 'DD', -30)",
        "DECODE(TRUE, COL1 > 10, 'HIGH', COL1 > 5, 'MED', 'LOW')",
        "LTRIM(RTRIM(NAME))",
        "TO_DECIMAL(AMOUNT, 18, 2)",
        "$$MY_VAR + $PMWORKFLOW_NAME",
    ]
    for expr in tests:
        r = translator.translate(expr)
        print(f"  {r.original}")
        print(f"  → {r.translated}")
        print()


if __name__ == '__main__':
    main()
