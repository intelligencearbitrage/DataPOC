"""
CLI entry point for the Informatica XML to Snowflake SQL converter.

Parses Informatica PowerCenter XML repository exports and generates
Snowflake DDL, DML, and Stored Procedures.

Subcommands:
    convert   Parse XML exports and generate Snowflake SQL artifacts
    validate  Validate previously generated output
"""

import argparse
import subprocess
import sys
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parent
SCRIPTS_DIR = PROJECT_ROOT / "scripts"
sys.path.insert(0, str(SCRIPTS_DIR))

from generators.orchestrator import ConversionOrchestrator


def _run_convert(args):
    """Execute the convert workflow."""
    orchestrator = ConversionOrchestrator(
        xml_dir=args.xml_dir,
        ddl_dir=args.ddl_dir,
        param_dir=args.param_dir,
        output_dir=args.output,
        database=args.database,
        warehouse=args.warehouse,
        schema=args.schema,
        include_audit_columns=not args.no_audit_columns,
        include_comments=not args.no_comments,
    )
    orchestrator.run()


def _run_validate(args):
    """Execute the validate workflow."""
    orchestrator = ConversionOrchestrator(output_dir=args.output)
    orchestrator.validate()


def _run_guardrails(args):
    """Run guardrails quality checks."""
    guardrails_script = PROJECT_ROOT / "guardrails" / "run_guardrails.py"
    if not guardrails_script.exists():
        print(f"Error: {guardrails_script} not found", file=sys.stderr)
        sys.exit(1)
    result = subprocess.run([sys.executable, str(guardrails_script)])
    sys.exit(result.returncode)


def main():
    parser = argparse.ArgumentParser(
        prog="infaxml-snowsql",
        description="Informatica PowerCenter XML to Snowflake SQL converter.",
    )
    subparsers = parser.add_subparsers(dest="command")

    # convert
    cp = subparsers.add_parser("convert", help="Parse XML and generate Snowflake SQL.")
    cp.add_argument("--xml-dir", required=True,
                    help="Directory containing Informatica XML exports.")
    cp.add_argument("--ddl-dir", default=None,
                    help="Optional directory with supplementary DDL files.")
    cp.add_argument("--param-dir", default=None,
                    help="Optional directory with parameter files.")
    cp.add_argument("--output", default=str(PROJECT_ROOT / "output"),
                    help="Output directory (default: output/).")
    cp.add_argument("--database", default=None, help="Snowflake target database name.")
    cp.add_argument("--warehouse", default=None, help="Snowflake warehouse name.")
    cp.add_argument("--schema", default="PUBLIC",
                    help="Snowflake target schema (default: PUBLIC).")
    cp.add_argument("--no-audit-columns", action="store_true",
                    help="Omit audit columns from DDL.")
    cp.add_argument("--no-comments", action="store_true",
                    help="Suppress inline comments in SQL.")

    # validate
    vp = subparsers.add_parser("validate", help="Validate generated Snowflake SQL output.")
    vp.add_argument("--output", required=True, help="Output directory to validate.")

    # guardrails
    subparsers.add_parser("guardrails", help="Run guardrail quality checks.")

    args = parser.parse_args()

    if args.command == "convert":
        _run_convert(args)
    elif args.command == "validate":
        _run_validate(args)
    elif args.command == "guardrails":
        _run_guardrails(args)
    else:
        parser.print_help()
        sys.exit(1)


if __name__ == "__main__":
    main()
