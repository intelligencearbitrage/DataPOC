"""
Tableau to Power BI Converter — Standalone Flask Application.

Routes:
  GET  /                     → Landing page with conversion UI.
  POST /convert              → Accepts .twb/.twbx, converts to PBIP + UT doc.
  POST /generate-ut          → Accepts .twb/.twbx + .pbix, generates UT .docx.
  GET  /download/<filename>  → Streams the generated file.
"""

import logging
import os
import io
import re
import shutil
import uuid
import zipfile
from datetime import datetime

from flask import (
    Flask,
    jsonify,
    render_template,
    request,
    send_file,
)
from werkzeug.utils import secure_filename

# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
UPLOAD_FOLDER = os.path.join(BASE_DIR, "uploads")
OUTPUT_FOLDER = os.path.join(BASE_DIR, "outputs")
ALLOWED_TABLEAU = {"twb", "twbx"}
MAX_CONTENT_LENGTH = 500 * 1024 * 1024  # 500 MB

os.makedirs(UPLOAD_FOLDER, exist_ok=True)
os.makedirs(OUTPUT_FOLDER, exist_ok=True)

# ---------------------------------------------------------------------------
# App factory
# ---------------------------------------------------------------------------
app = Flask(__name__, template_folder="templates", static_folder="static")
app.config["MAX_CONTENT_LENGTH"] = MAX_CONTENT_LENGTH
app.config["UPLOAD_FOLDER"] = UPLOAD_FOLDER
app.config["OUTPUT_FOLDER"] = OUTPUT_FOLDER

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s – %(message)s",
)
logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Routes
# ---------------------------------------------------------------------------
@app.route("/")
def index():
    """Serve the single-page conversion UI."""
    return render_template("index.html")


@app.route("/download/<filename>")
def download(filename):
    """Read file into memory, delete from outputs/, then stream to browser."""
    safe_name = secure_filename(filename)
    output_dir = app.config["OUTPUT_FOLDER"]
    file_path = os.path.join(output_dir, safe_name)

    if not os.path.isfile(file_path):
        return jsonify({"error": "File not found."}), 404

    with open(file_path, "rb") as fh:
        data = io.BytesIO(fh.read())

    try:
        os.remove(file_path)
        logger.info("Cleaned up output file: %s", safe_name)
    except OSError:
        logger.warning("Could not delete output file: %s", safe_name)

    if safe_name.endswith(".xlsx"):
        mimetype = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
    elif safe_name.endswith(".zip"):
        mimetype = "application/zip"
    elif safe_name.endswith(".docx"):
        mimetype = "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
    else:
        mimetype = "application/octet-stream"

    return send_file(data, mimetype=mimetype, as_attachment=True, download_name=safe_name)


# ---------------------------------------------------------------------------
# Route: Tableau → Power BI Conversion
# ---------------------------------------------------------------------------
@app.route("/convert", methods=["POST"])
def convert():
    """Accept a .twb/.twbx file, convert to Power BI PBIP, return a zip."""
    if "file" not in request.files:
        return jsonify({"error": "No file part in the request."}), 400

    file = request.files["file"]
    if file.filename == "" or file.filename is None:
        return jsonify({"error": "No file selected."}), 400

    ext = file.filename.rsplit(".", 1)[-1].lower() if "." in file.filename else ""
    if ext not in ALLOWED_TABLEAU:
        return jsonify({"error": "Unsupported file type. Please upload a .twb or .twbx file."}), 400

    original_name = secure_filename(file.filename)
    logger.info("Convert request: %s", original_name)

    job_id = uuid.uuid4().hex[:8]
    work_dir = os.path.join(UPLOAD_FOLDER, f"convert_{job_id}")
    os.makedirs(work_dir, exist_ok=True)

    try:
        input_path = os.path.join(work_dir, original_name)
        file.save(input_path)

        from utils.tableau_to_pbi import convert_one

        output_dir = os.path.join(work_dir, "output")
        os.makedirs(output_dir, exist_ok=True)

        pbip_dir = convert_one(input_path, output_dir)
        logger.info("PBIP generated at: %s", pbip_dir)

        # -------------------------------------------------------------------
        # Generate UT Document using original Tableau file + converted PBI
        # -------------------------------------------------------------------
        ut_summary = None
        docx_path = None
        img_dir = os.path.join(work_dir, "ut_screenshots")
        try:
            from utils.generate_ut_document import (
                extract_tableau,
                extract_pbi_from_pbip,
                compare_metadata_conversion,
                annotate_pbi_visuals_with_validation,
                render_wireframe,
                render_data_model_diagram,
                build_docx,
            )

            tab_data = extract_tableau(input_path)
            pbi_data = extract_pbi_from_pbip(pbip_dir)
            comparison = compare_metadata_conversion(tab_data, pbi_data)
            annotate_pbi_visuals_with_validation(pbi_data)

            img_dir = os.path.join(work_dir, "ut_screenshots")
            os.makedirs(img_dir, exist_ok=True)

            for d in tab_data.get("dashboards", []):
                safe = re.sub(r'[^\w]', '_', d["name"])
                render_wireframe(d, os.path.join(img_dir, f"tab_{safe}.png"), brand="tab")

            for p in pbi_data.get("pages", []):
                safe = re.sub(r'[^\w]', '_', p["name"])
                render_wireframe(p, os.path.join(img_dir, f"pbi_{safe}.png"), brand="pbi")

            render_data_model_diagram(pbi_data, os.path.join(img_dir, "data_model.png"), tab_data=tab_data)

            base_name = os.path.splitext(original_name)[0]
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            docx_filename = f"{base_name}_UT_Document_{timestamp}_{job_id}.docx"
            docx_path = os.path.join(OUTPUT_FOLDER, docx_filename)
            build_docx(tab_data, pbi_data, comparison, img_dir, docx_path,
                        project_name="BI Report Migration")
            logger.info("UT document generated: %s", docx_path)

            s = comparison["summary"]
            ut_summary = {
                "total_tests": s["total"],
                "pass": s["pass"],
                "fail": s["fail"],
                "warn": s["warn"],
            }
        except Exception as ut_exc:
            logger.warning("UT document generation failed (conversion still succeeded): %s", ut_exc)

        # -------------------------------------------------------------------
        # Zip the PBIP folder + UT document for download
        # -------------------------------------------------------------------
        base_name = os.path.splitext(original_name)[0]
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        zip_filename = f"{base_name}_PBIP_{timestamp}_{job_id}.zip"
        zip_path = os.path.join(OUTPUT_FOLDER, zip_filename)

        with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as zf:
            for root, _dirs, files in os.walk(pbip_dir):
                for fn in files:
                    abs_path = os.path.join(root, fn)
                    arc_name = os.path.relpath(abs_path, os.path.dirname(pbip_dir))
                    zf.write(abs_path, arc_name)

            if docx_path and os.path.isfile(docx_path):
                zf.write(docx_path, os.path.basename(docx_path))

            if os.path.isdir(img_dir):
                for fn in os.listdir(img_dir):
                    if fn.lower().endswith(".png"):
                        zf.write(os.path.join(img_dir, fn), f"ut_screenshots/{fn}")

        logger.info("PBIP zip saved: %s", zip_path)

        file_count = sum(len(files) for _, _, files in os.walk(pbip_dir))

        response_data = {
            "success": True,
            "filename": zip_filename,
            "download_url": f"/download/{zip_filename}",
            "summary": {"files_generated": file_count},
        }
        if ut_summary:
            response_data["ut_summary"] = ut_summary
        if docx_path and os.path.isfile(docx_path):
            response_data["ut_filename"] = os.path.basename(docx_path)
            response_data["ut_download_url"] = f"/download/{os.path.basename(docx_path)}"

        return jsonify(response_data)

    except Exception as exc:
        logger.exception("Error during Tableau-to-PBI conversion.")
        return jsonify({"error": str(exc)}), 500
    finally:
        shutil.rmtree(work_dir, ignore_errors=True)


# ---------------------------------------------------------------------------
# Helper: Extract report.json & model.bim from a .pbix archive
# ---------------------------------------------------------------------------
def _extract_pbix_for_ut(pbix_path: str, dest_folder: str) -> None:
    """Open a .pbix (ZIP) and write report.json + model.bim into dest_folder."""
    import json as _json

    def _read_and_decode(zf, name):
        raw = zf.read(name)
        for enc in ("utf-16-le", "utf-8-sig", "utf-8"):
            try:
                text = raw.decode(enc)
                break
            except (UnicodeDecodeError, UnicodeError):
                continue
        else:
            text = raw.decode("latin-1")
        text = text.strip().rstrip("\x00")
        return _json.loads(text)

    with zipfile.ZipFile(pbix_path, "r") as zf:
        names = zf.namelist()

        if "Report/Layout" in names:
            layout = _read_and_decode(zf, "Report/Layout")
            rpt_path = os.path.join(dest_folder, "report.json")
            with open(rpt_path, "w", encoding="utf-8") as f:
                _json.dump(layout, f, ensure_ascii=False, indent=2)
            logger.info("Extracted report.json from .pbix")
        else:
            raise FileNotFoundError("Report/Layout not found inside the .pbix file.")

        if "DataModelSchema" in names:
            model = _read_and_decode(zf, "DataModelSchema")
            mdl_path = os.path.join(dest_folder, "model.bim")
            with open(mdl_path, "w", encoding="utf-8") as f:
                _json.dump(model, f, ensure_ascii=False, indent=2)
            logger.info("Extracted model.bim from .pbix")
        else:
            logger.warning("DataModelSchema not found in .pbix")


# ---------------------------------------------------------------------------
# Route: UT Document Generation (standalone)
# ---------------------------------------------------------------------------
@app.route("/generate-ut", methods=["POST"])
def generate_ut():
    """Accept .twb/.twbx + .pbix file → generate UT .docx."""
    if "tableau_file" not in request.files:
        return jsonify({"error": "No Tableau file provided."}), 400

    pbi_file = request.files.get("pbi_file")
    if not pbi_file or not pbi_file.filename:
        return jsonify({"error": "No Power BI (.pbix) file provided."}), 400

    tableau_file = request.files["tableau_file"]
    if not tableau_file.filename:
        return jsonify({"error": "No Tableau file selected."}), 400

    tab_ext = tableau_file.filename.rsplit(".", 1)[-1].lower() if "." in tableau_file.filename else ""
    if tab_ext not in ALLOWED_TABLEAU:
        return jsonify({"error": "Tableau file must be .twb or .twbx."}), 400

    pbi_ext = pbi_file.filename.rsplit(".", 1)[-1].lower() if "." in pbi_file.filename else ""
    if pbi_ext != "pbix":
        return jsonify({"error": "Power BI file must be .pbix."}), 400

    tab_name = secure_filename(tableau_file.filename)
    pbi_name = secure_filename(pbi_file.filename)
    project_name = request.form.get("project_name", "BI Report Migration")

    logger.info("UT doc request: tableau=%s, pbix=%s, name=%s", tab_name, pbi_name, project_name)

    job_id = uuid.uuid4().hex[:8]
    work_dir = os.path.join(UPLOAD_FOLDER, f"ut_{job_id}")
    os.makedirs(work_dir, exist_ok=True)

    try:
        tab_path = os.path.join(work_dir, tab_name)
        tableau_file.save(tab_path)

        pbix_path = os.path.join(work_dir, pbi_name)
        pbi_file.save(pbix_path)

        pbi_folder = os.path.join(work_dir, "pbi_project")
        os.makedirs(pbi_folder, exist_ok=True)
        _extract_pbix_for_ut(pbix_path, pbi_folder)

        from utils.generate_ut_document import (
            extract_tableau,
            extract_pbi,
            compare_metadata,
            render_wireframe,
            render_data_model_diagram,
            build_docx,
        )

        img_dir = os.path.join(work_dir, "ut_screenshots")
        os.makedirs(img_dir, exist_ok=True)

        tab_data = extract_tableau(tab_path)
        pbi_data = extract_pbi(pbi_folder)
        comparison = compare_metadata(tab_data, pbi_data)

        for d in tab_data["dashboards"]:
            safe = re.sub(r'[^\w]', '_', d["name"])
            fp = os.path.join(img_dir, f"tab_{safe}.png")
            render_wireframe(d, fp, brand="tab")

        for p in pbi_data["pages"]:
            safe = re.sub(r'[^\w]', '_', p["name"])
            fp = os.path.join(img_dir, f"pbi_{safe}.png")
            render_wireframe(p, fp, brand="pbi")

        dm_path = os.path.join(img_dir, "data_model.png")
        render_data_model_diagram(pbi_data, dm_path, tab_data=tab_data)

        base_name = os.path.splitext(tab_name)[0]
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        docx_filename = f"{base_name}_UT_Document_{timestamp}_{job_id}.docx"
        docx_path = os.path.join(OUTPUT_FOLDER, docx_filename)

        build_docx(tab_data, pbi_data, comparison, img_dir, docx_path, project_name)
        logger.info("UT document saved: %s", docx_path)

        s = comparison["summary"]

        return jsonify({
            "success": True,
            "filename": docx_filename,
            "download_url": f"/download/{docx_filename}",
            "summary": {
                "total_tests": s["total"],
                "pass": s["pass"],
                "fail": s["fail"],
                "warn": s["warn"],
            },
        })

    except Exception as exc:
        logger.exception("Error generating UT document.")
        return jsonify({"error": str(exc)}), 500
    finally:
        shutil.rmtree(work_dir, ignore_errors=True)


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------
if __name__ == "__main__":
    app.run(
        debug=True,
        host="127.0.0.1",
        port=5001,
        exclude_patterns=["python313/*", "python313/**/*"],
    )
