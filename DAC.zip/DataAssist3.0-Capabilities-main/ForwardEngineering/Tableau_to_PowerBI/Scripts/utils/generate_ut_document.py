"""
Generic BI Migration UT Document Generator
===========================================
Accepts any Tableau workbook (.twbx / .twb) and Power BI report folder as input,
auto-extracts metadata, generates wireframe diagrams, compares source vs target,
and produces a complete Unit Testing Document (.docx) with Pass/Fail filled.

Usage:
  python generate_ut_document.py --tableau path/to/workbook.twbx --pbi path/to/pbi_folder [--output doc.docx]

Requirements:
  pip install python-docx matplotlib numpy pillow
"""

import argparse
import json
import math
import os
import random
import re
import sys
import xml.etree.ElementTree as ET
import zipfile
from datetime import date
from io import BytesIO

import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
from matplotlib.patches import FancyBboxPatch, Rectangle

from docx import Document
from docx.shared import Inches, Pt, Cm, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.oxml.ns import nsdecls
from docx.oxml import parse_xml

random.seed(42)
np.random.seed(42)

# ═══════════════════════════════════════════════════════════════════════════════
#  1. TABLEAU EXTRACTOR
# ═══════════════════════════════════════════════════════════════════════════════

def _get_twb_xml(tableau_path: str) -> ET.Element:
    """Return the root Element from a .twb or .twbx file."""
    if tableau_path.lower().endswith(".twbx"):
        with zipfile.ZipFile(tableau_path, "r") as zf:
            twb_names = [n for n in zf.namelist() if n.endswith(".twb")]
            if not twb_names:
                raise FileNotFoundError("No .twb inside the .twbx archive")
            with zf.open(twb_names[0]) as fh:
                return ET.parse(fh).getroot()
    else:
        return ET.parse(tableau_path).getroot()


def _extract_worksheet_meta(root: ET.Element) -> dict:
    """Build a dict: worksheet_name -> {mark_type, fields}."""
    ws_meta: dict = {}
    for ws in root.findall(".//worksheet"):
        name = ws.get("name", "")
        # Mark type
        mark_el = ws.find(".//mark")
        mark_class = (mark_el.get("class", "Automatic") if mark_el is not None
                      else "Automatic")
        # Fields from datasource-dependencies
        fields: list[str] = []
        for dep in ws.findall(".//datasource-dependencies"):
            for col in dep.findall("column"):
                col_name = col.get("name", "")
                if col_name.startswith("[") and col_name.endswith("]"):
                    col_name = col_name[1:-1]
                if col_name and not col_name.startswith(":") and col_name not in fields:
                    fields.append(col_name)
        ws_meta[name] = {"mark": mark_class, "fields": fields[:8]}
    return ws_meta


# Tableau mark-type → generic chart type
MARK_TO_CHART = {
    "Automatic": "bar",
    "Bar": "hbar",
    "Area": "area",
    "Circle": "scatter",
    "Square": "treemap",
    "Multipolygon": "map",
    "Line": "line",
    "Pie": "pie",
    "Gantt Bar": "hbar",
    "Text": "table",
    "Shape": "scatter",
    "Polygon": "map",
    "Map": "map",
}


def _collect_zones(zone_el: ET.Element, ws_meta: dict, scale_x: float,
                   scale_y: float) -> list[dict]:
    """Recursively collect visual zones from a dashboard zone tree.
    Returns a list of dicts with x, y, w, h, type, title, fields."""
    visuals: list[dict] = []
    type_v2 = zone_el.get("type-v2", "")
    name = zone_el.get("name", "")
    x = float(zone_el.get("x", 0)) * scale_x
    y = float(zone_el.get("y", 0)) * scale_y
    w = float(zone_el.get("w", 0)) * scale_x
    h = float(zone_el.get("h", 0)) * scale_y

    # Worksheet zone: has a name and no layout type
    if name and type_v2 in ("", "layout-basic") and w > 0 and h > 0:
        meta = ws_meta.get(name, {})
        mark = meta.get("mark", "Automatic")
        chart_type = MARK_TO_CHART.get(mark, "bar")
        # Check if it's a filter/paramctrl zone
        if type_v2 == "":
            # Could be a worksheet reference
            pass
        visuals.append({
            "x": x, "y": y, "w": w, "h": h,
            "type": chart_type,
            "title": name,
            "mark_type": mark,
            "fields": meta.get("fields", []),
        })
    elif type_v2 == "paramctrl" and w > 0 and h > 0:
        param_name = zone_el.get("param", "")
        if param_name.startswith("["):
            param_name = param_name.split("].")[-1].rstrip("]")
        visuals.append({
            "x": x, "y": y, "w": w, "h": h,
            "type": "filter",
            "title": param_name,
            "fields": [param_name] if param_name else [],
        })
    elif type_v2 in ("color", "filter") and w > 0 and h > 0:
        # Legend / filter shelf — skip small ones
        if w > 30 and h > 20:
            visuals.append({
                "x": x, "y": y, "w": w, "h": h,
                "type": "filter",
                "title": name or "Filter",
                "fields": [],
            })

    # Recurse into child zones
    for child in zone_el.findall("zone"):
        visuals.extend(_collect_zones(child, ws_meta, scale_x, scale_y))
    # Also check zones inside <formatted-text> etc.
    for enc in zone_el.findall(".//zone"):
        if enc not in zone_el.findall("zone"):
            visuals.extend(_collect_zones(enc, ws_meta, scale_x, scale_y))

    return visuals


def _dedup_visuals(visuals: list[dict]) -> list[dict]:
    """Remove duplicate visuals — keep only the largest instance per title+type."""
    groups: dict = {}
    for v in visuals:
        key = (v["title"], v["type"])
        if key not in groups or (v["w"] * v["h"]) > (groups[key]["w"] * groups[key]["h"]):
            groups[key] = v
    return list(groups.values())


def _synthesize_dashboards_from_worksheets(worksheets: list[dict],
                                           canvas_w: int = 1280,
                                           canvas_h: int = 720) -> list[dict]:
    """When a Tableau workbook has NO explicit dashboards (or all are empty),
    create synthetic dashboard pages from the worksheet list so wireframes
    are not blank.

    Lays out worksheets in a grid on a single synthetic canvas."""
    if not worksheets:
        return []

    n = len(worksheets)
    cols = math.ceil(math.sqrt(n))
    rows = math.ceil(n / cols)

    pad = 20
    cell_w = (canvas_w - pad * (cols + 1)) / cols
    cell_h = (canvas_h - 40 - pad * (rows + 1)) / rows  # 40 = header

    visuals: list[dict] = []
    for idx, ws in enumerate(worksheets):
        r = idx // cols
        c = idx % cols
        x = pad + c * (cell_w + pad)
        y = 40 + pad + r * (cell_h + pad)
        mark = ws.get("mark", "Automatic")
        chart_type = MARK_TO_CHART.get(mark, "bar")
        visuals.append({
            "x": x, "y": y, "w": cell_w, "h": cell_h,
            "type": chart_type,
            "title": ws["name"],
            "mark_type": mark,
            "fields": ws.get("fields", [])[:6],
        })

    return [{
        "name": "All Worksheets (synthesised)",
        "width": canvas_w,
        "height": canvas_h,
        "visuals": visuals,
    }]


def extract_tableau(tableau_path: str) -> dict:
    """
    Extract all metadata from a Tableau workbook.
    Returns: {
        dashboards: [{name, width, height, visuals: [{x,y,w,h,type,title,fields}]}],
        worksheets: [{name, mark, fields}],
        parameters: [{name}],
        datasources: [{name, tables}],
    }
    """
    root = _get_twb_xml(tableau_path)
    ws_meta = _extract_worksheet_meta(root)

    # Target canvas size for normalization
    target_w, target_h = 1280, 720

    # Dashboards — parse each dashboard's zone tree and extract visual positions
    dashboards: list[dict] = []
    for db in root.findall(".//dashboard"):
        db_name = db.get("name", "Unnamed")
        # Get size element
        size_el = db.find("size")
        if size_el is not None:
            db_w = int(size_el.get("maxwidth", size_el.get("width", "1280")))
            db_h = int(size_el.get("maxheight", size_el.get("height", "720")))
        else:
            db_w, db_h = 1280, 720

        # Determine the scale factor from zone coord system to target canvas
        root_zones = db.findall(".//zones/zone")
        if not root_zones:
            root_zones = db.findall("zones/zone")

        # Collect all zones recursively from each root zone
        all_visuals: list[dict] = []
        for rz in root_zones:
            rw = float(rz.get("w", 100000))
            rh = float(rz.get("h", 100000))
            # Scale factor: zones > 10k use a large internal coord system
            if rw > 10000:
                sx = target_w / rw
                sy = target_h / rh
            else:
                sx = target_w / db_w if db_w else 1
                sy = target_h / db_h if db_h else 1
            all_visuals.extend(_collect_zones(rz, ws_meta, sx, sy))

        # Deduplicate then filter out tiny/off-screen visuals
        all_visuals = _dedup_visuals(all_visuals)

        # Keep only meaningful visuals that fit within the target canvas
        meaningful = []
        for v in all_visuals:
            if v["w"] < 15 or v["h"] < 15:
                continue
            if v["x"] > target_w or v["y"] > target_h:
                continue
            # Clip to canvas bounds to avoid overflow
            v["x"] = max(0, min(v["x"], target_w - 10))
            v["y"] = max(0, min(v["y"], target_h - 10))
            v["w"] = min(v["w"], target_w - v["x"])
            v["h"] = min(v["h"], target_h - v["y"])
            meaningful.append(v)

        dashboards.append({
            "name": db_name,
            "width": target_w,
            "height": target_h,
            "visuals": meaningful,
        })

    # Parameters — stored as <column> with param-domain-type inside
    # the "Parameters" datasource; fall back to scanning all columns
    parameters: list[dict] = []
    for ds in root.findall(".//datasource"):
        if ds.get("name", "").lower() == "parameters":
            for col in ds.findall(".//column"):
                if col.get("param-domain-type"):
                    pname = col.get("caption", col.get("name", ""))
                    pname = pname.strip("[]")
                    if pname:
                        parameters.append({"name": pname})
            break
    # Fallback: any column with param-domain-type anywhere
    if not parameters:
        for col in root.findall(".//column"):
            if col.get("param-domain-type"):
                pname = col.get("caption", col.get("name", "")).strip("[]")
                if pname and pname not in [p["name"] for p in parameters]:
                    parameters.append({"name": pname})

    # Datasources
    datasources: list[dict] = []
    for ds in root.findall(".//datasource"):
        ds_name = ds.get("name", "")
        ds_caption = ds.get("caption", ds_name)
        if ds_name in ("Parameters", ""):
            continue
        tables: list[str] = []
        for rel in ds.findall(".//relation"):
            tname = rel.get("table", rel.get("name", ""))
            if tname and tname not in tables:
                tables.append(tname)
        if ds_caption or tables:
            datasources.append({"name": ds_caption or ds_name, "tables": tables})

    # Convert ws_meta to list
    worksheets = [{"name": k, **v} for k, v in ws_meta.items()]

    # If no dashboards were found (or all are empty), synthesize from worksheets
    has_visuals = any(d.get("visuals") for d in dashboards)
    if not has_visuals and worksheets:
        dashboards = _synthesize_dashboards_from_worksheets(worksheets)

    return {
        "dashboards": dashboards,
        "worksheets": worksheets,
        "parameters": parameters,
        "datasources": datasources,
    }


# ═══════════════════════════════════════════════════════════════════════════════
#  2. POWER BI EXTRACTOR
# ═══════════════════════════════════════════════════════════════════════════════

def _pbi_extract_title(config_str: str) -> str:
    """Extract visual title from PBI config JSON.
    Tries multiple known locations in the config hierarchy."""
    try:
        cfg = json.loads(config_str)
        sv = cfg.get("singleVisual", {})

        # 1. vcObjects.title[].properties.text.expr.Literal.Value
        t = sv.get("vcObjects", {}).get("title", [{}])
        if t:
            val = (t[0].get("properties", {}).get("text", {})
                   .get("expr", {}).get("Literal", {}).get("Value", ""))
            val = val.strip('"').replace("\\n", " ").replace("\\u00c6", "").strip()
            val = re.sub(r"<\[.*?\]>", "", val)
            val = re.sub(r"\s{2,}", " ", val).strip(" -()")
            if val:
                return val[:60]

        # 2. objects.title[].properties.text.expr.Literal.Value
        for t_obj in sv.get("objects", {}).get("title", [{}]):
            val = (t_obj.get("properties", {}).get("text", {})
                   .get("expr", {}).get("Literal", {}).get("Value", ""))
            val = val.strip('"').strip()
            if val:
                return val[:60]

        # 3. title.text (simple key)
        title_block = sv.get("title", {})
        if isinstance(title_block, dict):
            val = title_block.get("text", "")
            if val:
                return str(val)[:60]

        # 4. First field name from projections as fallback title
        projs = sv.get("projections", {})
        for role_items in projs.values():
            for item in role_items:
                qr = item.get("queryRef", "")
                if qr:
                    name = qr.split(".")[-1] if "." in qr else qr
                    if name:
                        return name[:60]
    except Exception:
        pass
    return ""


def _pbi_extract_visual_type(config_str: str) -> str:
    try:
        return json.loads(config_str).get("singleVisual", {}).get("visualType", "unknown")
    except Exception:
        return "unknown"


def _pbi_extract_fields(config_str: str) -> list[str]:
    try:
        cfg = json.loads(config_str)
        projs = cfg.get("singleVisual", {}).get("projections", {})
        fields: list[str] = []
        for items in projs.values():
            for item in items:
                qr = item.get("queryRef", "")
                name = qr.split(".")[-1] if "." in qr else qr
                if name and name not in fields:
                    fields.append(name)
        return fields[:6]
    except Exception:
        return []


# PBI visual type → generic chart type
PBI_TYPE_TO_CHART = {
    "clusteredColumnChart": "bar",
    "clusteredBarChart": "hbar",
    "stackedColumnChart": "bar",
    "stackedBarChart": "hbar",
    "hundredPercentStackedColumnChart": "bar",
    "hundredPercentStackedBarChart": "hbar",
    "areaChart": "area",
    "stackedAreaChart": "area",
    "lineChart": "line",
    "lineClusteredColumnComboChart": "bar",
    "lineStackedColumnComboChart": "bar",
    "scatterChart": "scatter",
    "treemap": "treemap",
    "map": "map",
    "filledMap": "map",
    "shapeMap": "map",
    "ArcGIS": "map",
    "slicer": "filter",
    "card": "card",
    "multiRowCard": "card",
    "kpi": "card",
    "table": "table",
    "pivotTable": "table",
    "matrix": "table",
    "donutChart": "pie",
    "pieChart": "pie",
    "waterfallChart": "bar",
    "funnel": "bar",
    "gauge": "card",
    "textbox": "text",
    "image": "text",
    "shape": "text",
    "ribbonChart": "bar",
    "decompositionTreeVisual": "treemap",
    "keyInfluencers": "scatter",
}

# Human-readable display name for PBI visual types (used when no title is set)
PBI_TYPE_DISPLAY_NAME = {
    "clusteredColumnChart": "Clustered Column Chart",
    "clusteredBarChart": "Clustered Bar Chart",
    "stackedColumnChart": "Stacked Column Chart",
    "stackedBarChart": "Stacked Bar Chart",
    "hundredPercentStackedColumnChart": "100% Stacked Column Chart",
    "hundredPercentStackedBarChart": "100% Stacked Bar Chart",
    "areaChart": "Area Chart",
    "stackedAreaChart": "Stacked Area Chart",
    "lineChart": "Line Chart",
    "lineClusteredColumnComboChart": "Line & Column Combo",
    "lineStackedColumnComboChart": "Line & Stacked Column Combo",
    "scatterChart": "Scatter Chart",
    "treemap": "Treemap",
    "map": "Map",
    "filledMap": "Filled Map",
    "shapeMap": "Shape Map",
    "ArcGIS": "ArcGIS Map",
    "slicer": "Slicer",
    "card": "Card",
    "multiRowCard": "Multi-Row Card",
    "kpi": "KPI",
    "table": "Table",
    "pivotTable": "Pivot Table",
    "matrix": "Matrix",
    "donutChart": "Donut Chart",
    "pieChart": "Pie Chart",
    "waterfallChart": "Waterfall Chart",
    "funnel": "Funnel Chart",
    "gauge": "Gauge",
    "textbox": "Text Box",
    "image": "Image",
    "shape": "Shape",
    "ribbonChart": "Ribbon Chart",
    "decompositionTreeVisual": "Decomposition Tree",
    "keyInfluencers": "Key Influencers",
}

# Human-readable display name for Tableau mark types
MARK_DISPLAY_NAME = {
    "Automatic": "Auto Chart",
    "Bar": "Horizontal Bar Chart",
    "Area": "Area Chart",
    "Circle": "Scatter Plot",
    "Square": "Treemap",
    "Multipolygon": "Map",
    "Line": "Line Chart",
    "Pie": "Pie Chart",
    "Gantt Bar": "Gantt Chart",
    "Text": "Text Table",
    "Shape": "Shape Chart",
    "Polygon": "Polygon Map",
    "Map": "Map",
}


def extract_pbi(pbi_folder: str) -> dict:
    """
    Extract all metadata from a Power BI report folder.
    Returns: {
        pages: [{name, width, height, visuals: [{x,y,w,h,type,title,fields,pbi_type}]}],
        tables: [{name, columns, measures, calc_columns}],
        relationships: [{from_table, from_col, to_table, to_col, active, cross_filter}],
        measures_list: [(table, measure_name, expression)],
    }
    """
    # Find report.json by walking the folder tree
    report_path = None
    for root_dir, dirs, files in os.walk(pbi_folder):
        if "report.json" in files:
            report_path = os.path.join(root_dir, "report.json")
            break
    if not report_path:
        raise FileNotFoundError(f"report.json not found in {pbi_folder}")

    with open(report_path, "r", encoding="utf-8") as f:
        report = json.load(f)

    # Pages — iterate sections and parse each visual container
    # Extract visual containers from each report page section
    pages: list[dict] = []
    for section in report.get("sections", []):
        page_name = section.get("displayName", section.get("name", ""))
        pw = section.get("width", 1280)
        ph = section.get("height", 720)
        # Parse each visual container's config for type, title, and fields
        visuals: list[dict] = []
        for vc in section.get("visualContainers", []):
            config = vc.get("config", "{}")
            pbi_type = _pbi_extract_visual_type(config)
            chart_type = PBI_TYPE_TO_CHART.get(pbi_type, "bar")
            title = _pbi_extract_title(config)
            fields = _pbi_extract_fields(config)
            display_name = PBI_TYPE_DISPLAY_NAME.get(pbi_type, pbi_type)
            visuals.append({
                "x": vc.get("x", 0), "y": vc.get("y", 0),
                "w": vc.get("width", 200), "h": vc.get("height", 200),
                "type": chart_type,
                "title": title or display_name,
                "fields": fields,
                "pbi_type": pbi_type,
            })
        pages.append({
            "name": page_name,
            "width": pw,
            "height": ph,
            "visuals": visuals,
        })

    # Model (model.bim)
    model_path = None
    for root_dir, dirs, files in os.walk(pbi_folder):
        if "model.bim" in files:
            model_path = os.path.join(root_dir, "model.bim")
            break

    # Parse model.bim for tables, columns, measures, and relationships
    tables_info: list[dict] = []
    relationships: list[dict] = []
    measures_list: list[tuple] = []

    if model_path:
        with open(model_path, "r", encoding="utf-8") as f:
            bim = json.load(f)
        model = bim.get("model", bim)
        # Extract columns, measures, and calculated columns for each table
        for t in model.get("tables", []):
            tname = t.get("name", "")
            cols = [c.get("name", "") for c in t.get("columns", [])
                    if c.get("name")]
            measures = [m.get("name", "") for m in t.get("measures", [])
                        if m.get("name")]
            calc_cols = [c.get("name", "") for c in t.get("columns", [])
                         if c.get("type") == "calculated" or c.get("expression")]
            for m in t.get("measures", []):
                expr = m.get("expression", "")
                if isinstance(expr, list):
                    expr = "\n".join(expr)
                measures_list.append((tname, m.get("name", ""), expr))
            tables_info.append({
                "name": tname,
                "columns": cols,
                "measures": measures,
                "calc_columns": calc_cols,
            })
        for r in model.get("relationships", []):
            relationships.append({
                "from_table": r.get("fromTable", ""),
                "from_col": r.get("fromColumn", ""),
                "to_table": r.get("toTable", ""),
                "to_col": r.get("toColumn", ""),
                "active": r.get("isActive", True) is not False,
                "cross_filter": r.get("crossFilteringBehavior", "oneDirection"),
            })

    return {
        "pages": pages,
        "tables": tables_info,
        "relationships": relationships,
        "measures_list": measures_list,
    }


# ═══════════════════════════════════════════════════════════════════════════════
#  2b. PBIP EXTRACTOR  (reads actual PBIP folder output from conversion)
# ═══════════════════════════════════════════════════════════════════════════════

def _validate_dax_syntax(expression: str) -> tuple[bool, str]:
    """Basic DAX syntax validation. Returns (is_valid, issue_description)."""
    expr = expression.strip()
    if not expr:
        return False, "Empty expression"

    # Check balanced parentheses to detect syntax errors
    depth = 0
    for ch in expr:
        if ch == "(":
            depth += 1
        elif ch == ")":
            depth -= 1
        if depth < 0:
            return False, "Unbalanced parentheses (extra closing)"
    if depth != 0:
        return False, f"Unbalanced parentheses (depth={depth})"

    # Check balanced square brackets for column/measure references
    depth = 0
    for ch in expr:
        if ch == "[":
            depth += 1
        elif ch == "]":
            depth -= 1
        if depth < 0:
            return False, "Unbalanced square brackets"
    if depth != 0:
        return False, "Unbalanced square brackets"

    # Check for known non-DAX function names that indicate incomplete translation
    non_dax_funcs = ["SPLIT", "DATEPARSE", "MAKEDATE", "ZN", "IFNULL",
                     "ATTR", "INCLUDE", "EXCLUDE", "FIXED", "SIZE",
                     "LOOKUP", "RUNNING_SUM", "WINDOW_SUM"]
    expr_upper = expr.upper()
    for func in non_dax_funcs:
        pattern = rf'\b{func}\s*\('
        if re.search(pattern, expr_upper):
            return False, f"Non-DAX function: {func}()"

    # Check for leftover Tableau LOD markers
    if re.search(r'\{(FIXED|INCLUDE|EXCLUDE)\b', expr_upper):
        return False, "Contains Tableau LOD expression syntax"

    # Check for broken comments / TODO markers indicating incomplete translation
    if "/* TODO" in expr or "/* LOOKUP" in expr or "__LOOKUP" in expr:
        return False, "Contains TODO/incomplete translation marker"

    # Check for corrupted table references ('Table'[Col] turned into "Table"[Col])
    if re.search(r'"[^"]+"\s*\[', expr):
        return False, "Possible corrupted table reference (double-quoted table name before [column])"

    return True, ""


def _validate_field_bindings(visual_config: dict, all_columns: set,
                             all_measures: set,
                             column_types: dict | None = None) -> list[str]:
    """Check if visual field references exist in the semantic model and
    that aggregations are valid for the column data type.

    Args:
        visual_config: Parsed config JSON for a single visual.
        all_columns: Set of column names (short and Table.Column forms).
        all_measures: Set of measure names (short and Table.Measure forms).
        column_types: Optional dict mapping column name -> dataType string
                      (e.g. 'dateTime', 'string', 'int64', 'double').

    Returns list of issue descriptions (empty = all OK).
    """
    AGG_PATTERN = re.compile(
        r'^(Sum|Count|CountNonNull|Min|Max|Average|CountRows)\((.+)\)$')
    # Data types that cannot be SUM/Average aggregated
    NON_NUMERIC_TYPES = {'string', 'dateTime', 'boolean', 'binary'}
    # Aggregations that require numeric columns
    NUMERIC_ONLY_AGGS = {'Sum', 'Average'}

    col_types = column_types or {}
    issues = []
    try:
        sv = visual_config.get("singleVisual", {})
        projs = sv.get("projections", {})
        for role, items in projs.items():
            for item in items:
                qr = item.get("queryRef", "")
                if not qr:
                    continue

                # Parse aggregation wrapper: "Sum(o0.Sales)" → ("Sum", "o0.Sales")
                m = AGG_PATTERN.match(qr)
                if m:
                    agg_func = m.group(1)
                    inner = m.group(2)  # e.g. "o0.Sales"
                    col_name = inner.split(".")[-1] if "." in inner else inner
                else:
                    agg_func = None
                    col_name = qr.split(".")[-1] if "." in qr else qr

                # Check column/measure existence
                exists = (col_name in all_columns or col_name in all_measures
                          or qr in all_columns or qr in all_measures)
                if not exists:
                    issues.append(f"Unresolved field: {qr}")
                    continue

                # Check aggregation validity on column type
                if agg_func and agg_func in NUMERIC_ONLY_AGGS and col_types:
                    dtype = col_types.get(col_name, "")
                    if dtype in NON_NUMERIC_TYPES:
                        issues.append(
                            f"Invalid aggregation: {agg_func}() on "
                            f"{col_name} (type={dtype})")

        # Also inspect prototypeQuery for aggregation issues
        pq = sv.get("prototypeQuery", {})
        if pq and col_types:
            for sel in pq.get("Select", []):
                agg = sel.get("Aggregation")
                if agg:
                    col_expr = agg.get("Expression", {}).get("Column", {})
                    prop = col_expr.get("Property", "")
                    func_id = agg.get("Function", -1)
                    # Function 0 = Sum, 1 = Average
                    if func_id in (0, 1) and prop:
                        dtype = col_types.get(prop, "")
                        if dtype in NON_NUMERIC_TYPES:
                            agg_name = "Sum" if func_id == 0 else "Average"
                            issues.append(
                                f"prototypeQuery: {agg_name}({prop}) "
                                f"invalid on type={dtype}")
    except Exception:
        pass
    return issues


def _check_pbip_definition_files(pbip_folder: str) -> list[dict]:
    """Check critical PBIP definition files for completeness.
    Returns list of {file, status, issue} dicts."""
    checks = []

    # Find .pbip file
    pbip_files = []
    for f in os.listdir(pbip_folder):
        if f.endswith(".pbip"):
            pbip_files.append(os.path.join(pbip_folder, f))
    if pbip_files:
        try:
            with open(pbip_files[0], "r", encoding="utf-8") as f:
                pbip = json.load(f)
            artifacts = pbip.get("artifacts", [])
            if artifacts:
                checks.append({"file": ".pbip", "status": "PASS", "issue": ""})
            else:
                checks.append({"file": ".pbip", "status": "FAIL",
                                "issue": "No artifacts defined"})
        except Exception as e:
            checks.append({"file": ".pbip", "status": "FAIL", "issue": str(e)})
    else:
        checks.append({"file": ".pbip", "status": "FAIL", "issue": "File not found"})

    # Find definition.pbir
    pbir_path = None
    for root_dir, dirs, files in os.walk(pbip_folder):
        if "definition.pbir" in files:
            pbir_path = os.path.join(root_dir, "definition.pbir")
            break
    if pbir_path:
        try:
            with open(pbir_path, "r", encoding="utf-8") as f:
                pbir = json.load(f)
            ds_ref = pbir.get("datasetReference", {})
            by_path = ds_ref.get("byPath", {}).get("path", "")
            by_conn = ds_ref.get("byConnection")
            if by_path:
                checks.append({"file": "definition.pbir", "status": "PASS",
                                "issue": "" if by_conn is not None else "byConnection is null (may require manual fix)"})
            else:
                checks.append({"file": "definition.pbir", "status": "FAIL",
                                "issue": "No byPath in datasetReference"})
        except Exception as e:
            checks.append({"file": "definition.pbir", "status": "FAIL",
                            "issue": str(e)})
    else:
        checks.append({"file": "definition.pbir", "status": "FAIL",
                        "issue": "File not found"})

    # Find definition.pbism
    pbism_path = None
    for root_dir, dirs, files in os.walk(pbip_folder):
        if "definition.pbism" in files:
            pbism_path = os.path.join(root_dir, "definition.pbism")
            break
    if pbism_path:
        try:
            with open(pbism_path, "r", encoding="utf-8") as f:
                pbism = json.load(f)
            settings = pbism.get("settings", {})
            checks.append({"file": "definition.pbism", "status": "WARN" if not settings else "PASS",
                            "issue": "Empty settings — PBI Desktop may not resolve data source mode" if not settings else ""})
        except Exception as e:
            checks.append({"file": "definition.pbism", "status": "FAIL",
                            "issue": str(e)})
    else:
        checks.append({"file": "definition.pbism", "status": "FAIL",
                        "issue": "File not found"})

    return checks


def extract_pbi_from_pbip(pbip_folder: str) -> dict:
    """
    Extract metadata from an actual PBIP folder (output of conversion).
    Unlike extract_pbi(), this function:
      - Navigates the real PBIP folder structure ({Name}.Report / {Name}.SemanticModel)
      - Validates definition.pbir, definition.pbism, .pbip files
      - Validates DAX syntax in measures
      - Validates field bindings in visuals against the semantic model
      - Reports unresolved fields, invalid DAX, and missing definition files

    Returns the same structure as extract_pbi() plus additional validation info:
    {
        pages, tables, relationships, measures_list,  (same as extract_pbi)
        validation: {
            definition_checks: [{file, status, issue}],
            dax_issues: [(table, measure, issue)],
            field_binding_issues: [(page, visual_title, unresolved_fields)],
            m_expression_issues: [(table, issue)],
            relationship_issues: [(from_table, to_table, issue)],
        }
    }
    """
    # --- Locate report.json and model.bim following PBIP folder conventions ---
    report_path = None
    model_path = None

    # PBIP structure: {Name}.Report/report.json, {Name}.SemanticModel/model.bim
    for entry in os.listdir(pbip_folder):
        full = os.path.join(pbip_folder, entry)
        if os.path.isdir(full):
            # Match the conventional .Report and .SemanticModel suffixes
            if entry.endswith(".Report"):
                rp = os.path.join(full, "report.json")
                if os.path.isfile(rp):
                    report_path = rp
            elif entry.endswith(".SemanticModel"):
                mp = os.path.join(full, "model.bim")
                if os.path.isfile(mp):
                    model_path = mp

    # Fallback: walk the directory tree (handles flat output layouts)
    if not report_path:
        for root_dir, dirs, files in os.walk(pbip_folder):
            if "report.json" in files:
                report_path = os.path.join(root_dir, "report.json")
                break
    if not model_path:
        for root_dir, dirs, files in os.walk(pbip_folder):
            if "model.bim" in files:
                model_path = os.path.join(root_dir, "model.bim")
                break

    if not report_path:
        raise FileNotFoundError(f"report.json not found in PBIP folder: {pbip_folder}")

    # --- Parse report.json ---
    with open(report_path, "r", encoding="utf-8") as f:
        report = json.load(f)

    pages: list[dict] = []
    visual_configs: list[tuple] = []  # (page_name, visual_title, config_dict)

    for section in report.get("sections", []):
        page_name = section.get("displayName", section.get("name", ""))
        pw = section.get("width", 1280)
        ph = section.get("height", 720)
        visuals: list[dict] = []
        for vc in section.get("visualContainers", []):
            config_str = vc.get("config", "{}")
            pbi_type = _pbi_extract_visual_type(config_str)
            chart_type = PBI_TYPE_TO_CHART.get(pbi_type, "bar")
            title = _pbi_extract_title(config_str)
            fields = _pbi_extract_fields(config_str)
            display_name = PBI_TYPE_DISPLAY_NAME.get(pbi_type, pbi_type)
            visuals.append({
                "x": vc.get("x", 0), "y": vc.get("y", 0),
                "w": vc.get("width", 200), "h": vc.get("height", 200),
                "type": chart_type,
                "title": title or display_name,
                "fields": fields,
                "pbi_type": pbi_type,
            })
            # Store config for field-binding validation
            try:
                visual_configs.append((page_name, title or display_name, json.loads(config_str)))
            except Exception:
                pass
        pages.append({
            "name": page_name, "width": pw, "height": ph, "visuals": visuals,
        })

    # --- Parse model.bim ---
    tables_info: list[dict] = []
    relationships: list[dict] = []
    measures_list: list[tuple] = []
    all_columns: set = set()
    all_measures: set = set()

    if model_path:
        with open(model_path, "r", encoding="utf-8") as f:
            bim = json.load(f)
        model = bim.get("model", bim)

        for t in model.get("tables", []):
            tname = t.get("name", "")
            cols = [c.get("name", "") for c in t.get("columns", []) if c.get("name")]
            measures = [m.get("name", "") for m in t.get("measures", []) if m.get("name")]
            calc_cols = [c.get("name", "") for c in t.get("columns", [])
                         if c.get("type") == "calculated" or c.get("expression")]
            for m in t.get("measures", []):
                expr = m.get("expression", "")
                if isinstance(expr, list):
                    expr = "\n".join(expr)
                measures_list.append((tname, m.get("name", ""), expr))
            tables_info.append({
                "name": tname, "columns": cols, "measures": measures,
                "calc_columns": calc_cols,
            })
            all_columns.update(cols)
            all_measures.update(measures)

        for r in model.get("relationships", []):
            relationships.append({
                "from_table": r.get("fromTable", ""),
                "from_col": r.get("fromColumn", ""),
                "to_table": r.get("toTable", ""),
                "to_col": r.get("toColumn", ""),
                "active": r.get("isActive", True) is not False,
                "cross_filter": r.get("crossFilteringBehavior", "oneDirection"),
                "from_cardinality": r.get("fromCardinality", ""),
                "to_cardinality": r.get("toCardinality", ""),
            })

    # --- Validation: PBIP definition files ---
    definition_checks = _check_pbip_definition_files(pbip_folder)

    # --- Validation: DAX expressions — check syntax of every measure ---
    dax_issues: list[tuple] = []
    for tbl_name, msr_name, expr in measures_list:
        is_valid, issue = _validate_dax_syntax(expr)
        if not is_valid:
            dax_issues.append((tbl_name, msr_name, issue))

    # --- Build column-type lookup for aggregation validity checks ---
    column_types: dict[str, str] = {}
    if model_path:
        for t in model.get("tables", []):
            for c in t.get("columns", []):
                cname = c.get("name", "")
                dtype = c.get("dataType", "")
                if cname and dtype:
                    column_types[cname] = dtype

    # --- Validation: Field bindings ---
    field_binding_issues: list[tuple] = []
    for page_name, vis_title, cfg in visual_configs:
        issues = _validate_field_bindings(cfg, all_columns, all_measures,
                                          column_types)
        if issues:
            field_binding_issues.append((page_name, vis_title, issues))

    # --- Validation: M expressions (detect hardcoded file paths) ---
    m_expression_issues: list[tuple] = []
    if model_path:
        for t in model.get("tables", []):
            tname = t.get("name", "")
            for part in t.get("partitions", []):
                source = part.get("source", {})
                expr = source.get("expression", "")
                if isinstance(expr, list):
                    expr = "\n".join(expr)
                if expr:
                    # Flag absolute Windows paths that break portability
                    if re.search(r'[A-Z]:\\\\', expr) or re.search(r'[A-Z]:\\', expr):
                        m_expression_issues.append((tname,
                            "M expression contains hardcoded absolute file path"))
                    # Check for DataSourcePath placeholder
                    if "DataSourcePath" in expr:
                        pass  # acceptable, parameterized
                    elif "File.Contents" in expr and "http" not in expr.lower():
                        m_expression_issues.append((tname,
                            "M expression uses File.Contents with local path"))

    # --- Validation: Relationships — verify references and cardinality ---
    relationship_issues: list[tuple] = []
    table_names = {t["name"] for t in tables_info}
    for r in relationships:
        ft, tt = r["from_table"], r["to_table"]
        if ft not in table_names:
            relationship_issues.append((ft, tt, f"From-table '{ft}' not found in model"))
        if tt not in table_names:
            relationship_issues.append((ft, tt, f"To-table '{tt}' not found in model"))
        fc, tc = r.get("from_cardinality", ""), r.get("to_cardinality", "")
        if fc == "many" and tc == "many":
            relationship_issues.append((ft, tt,
                "Many-to-many relationship — may cause DAX ambiguity"))

    return {
        "pages": pages,
        "tables": tables_info,
        "relationships": relationships,
        "measures_list": measures_list,
        "validation": {
            "definition_checks": definition_checks,
            "dax_issues": dax_issues,
            "field_binding_issues": field_binding_issues,
            "m_expression_issues": m_expression_issues,
            "relationship_issues": relationship_issues,
        },
    }


def annotate_pbi_visuals_with_validation(pbi_data: dict) -> None:
    """
    Mark each visual in pbi_data['pages'] with 'status' and 'issue_text'
    based on the validation results from extract_pbi_from_pbip().

    Visuals with field binding issues (unresolved or invalid aggregation)
    are marked FAIL.  Visuals affected by DAX issues or data-source
    connectivity problems are marked WARN.
    Modifies pbi_data in-place.
    """
    validation = pbi_data.get("validation")
    if not validation:
        return

    # ── Build per-visual issue lookup ──
    issue_map: dict[tuple, tuple] = {}   # (page, title) → (status, text)
    for page_name, vis_title, issues_list in validation.get("field_binding_issues", []):
        # issues_list is now a list of description strings
        summary = "; ".join(issues_list[:2])
        if len(issues_list) > 2:
            summary += f" +{len(issues_list)-2} more"
        issue_map[(page_name, vis_title)] = ("FAIL", summary)

    # DAX-broken measures
    dax_broken_measures = {msr for _, msr, _ in validation.get("dax_issues", [])}

    # Data connectivity: if ALL tables use local File.Contents paths,
    # PBI Desktop won't load any data → every visual is affected
    m_issues = validation.get("m_expression_issues", [])
    n_tables = len(pbi_data.get("tables", []))
    tables_with_m_issues = {t for t, _ in m_issues}
    all_data_broken = (
        len(tables_with_m_issues) > 0
        and len(tables_with_m_issues) >= n_tables - 1  # allow 1 params table
    )

    for page in pbi_data.get("pages", []):
        page_name = page.get("name", "")
        for v in page.get("visuals", []):
            title = v.get("title", "")
            vtype = v.get("type", "")
            key = (page_name, title)

            if key in issue_map:
                v["status"] = issue_map[key][0]
                v["issue_text"] = issue_map[key][1]
            elif vtype == "filter":
                # Slicers may still render if column exists
                v["status"] = ""
                v["issue_text"] = ""
            elif all_data_broken:
                v["status"] = "FAIL"
                v["issue_text"] = "Data source uses local file path — PBI cannot load data"
            else:
                # Check if any field used by this visual is a broken measure
                vfields = v.get("fields", [])
                broken_fields = [f for f in vfields if f in dax_broken_measures]
                if broken_fields:
                    v["status"] = "WARN"
                    v["issue_text"] = f"DAX issue: {', '.join(broken_fields[:2])}"
                else:
                    v["status"] = ""
                    v["issue_text"] = ""


def compare_metadata_conversion(tab_data: dict, pbi_data: dict) -> dict:
    """
    Enhanced comparison for the Tableau→PBIP conversion path.
    Runs all standard compare_metadata tests PLUS additional PBIP validation
    tests using the 'validation' key from extract_pbi_from_pbip().
    """
    # Run the standard comparison first (without PBIP-specific checks)
    result = compare_metadata(tab_data, pbi_data)

    validation = pbi_data.get("validation")
    if not validation:
        return result

    # --- Append PBIP definition file tests to structural_tests ---
    structural = list(result["structural_tests"])
    # Each definition file (pbip, pbir, pbism) is validated for completeness
    for chk in validation.get("definition_checks", []):
        structural.append((
            chk["file"],
            f"PBIP file: {chk['file']}",
            "Valid and complete",
            chk["status"],
            chk["status"],
            chk.get("issue", ""),
        ))
    result["structural_tests"] = structural

    # --- Append M expression issues to structural_tests ---
    for tbl, issue in validation.get("m_expression_issues", []):
        structural.append((
            tbl,
            f"Data source: {tbl}",
            "Portable data source reference",
            "Hardcoded path",
            "WARN",
            issue,
        ))
    result["structural_tests"] = structural

    # --- Append relationship issues to structural_tests ---
    for ft, tt, issue in validation.get("relationship_issues", []):
        structural.append((
            f"{ft} → {tt}",
            f"Relationship: {ft} → {tt}",
            "Valid relationship",
            "Issue detected",
            "WARN",
            issue,
        ))
    result["structural_tests"] = structural

    # --- Replace measure tests with DAX-validated versions ---
    # Build a lookup of measures that have DAX syntax issues
    measure_tests: list[tuple] = []
    dax_issue_map = {}
    for tbl, msr, issue in validation.get("dax_issues", []):
        dax_issue_map[(tbl, msr)] = issue

    for tbl_name, msr_name, expr in pbi_data.get("measures_list", []):
        has_expr = bool(expr.strip())
        dax_issue = dax_issue_map.get((tbl_name, msr_name), "")
        notes = ""

        if not has_expr:
            status = "WARN"
            notes = "Empty expression"
        elif dax_issue:
            status = "FAIL"
            notes = f"DAX issue: {dax_issue}"
        else:
            status = "PASS"
            expr_lower = expr.lower()
            if "calculate" in expr_lower and "allexcept" in expr_lower:
                notes = "Uses ALLEXCEPT — verify context matches Tableau LOD"
            elif "rankx" in expr_lower or "index" in expr_lower:
                notes = "Ranking function — verify equivalence"
            elif "treatas" in expr_lower:
                notes = "Uses TREATAS — verify M:M pattern correctness"

        short_expr = expr.replace("\n", " ").strip()[:60]
        measure_tests.append((
            msr_name,
            f"DAX measure ({tbl_name})",
            f"DAX: {short_expr}...",
            "Valid DAX" if status == "PASS" else ("DAX issue" if status == "FAIL" else "Empty"),
            status,
            notes,
        ))
    result["measure_tests"] = measure_tests

    # --- Add field binding tests to visual_tests ---
    visual_tests = list(result["visual_tests"])
    for page_name, vis_title, unresolved in validation.get("field_binding_issues", []):
        vis_display = vis_title[:30] if vis_title else "Visual"
        visual_tests.append((
            vis_display,
            f"Field bindings on '{page_name}'",
            "All fields resolve to model",
            f"{len(unresolved)} unresolved: {', '.join(unresolved[:3])}",
            "FAIL",
            "Visual may render blank — fields not found in semantic model",
        ))
    result["visual_tests"] = visual_tests

    # --- Recalculate summary ---
    all_tests = (result["structural_tests"] + result["visual_tests"]
                 + result["measure_tests"] + result["filter_tests"])
    p = sum(1 for t in all_tests if t[4] == "PASS")
    f_count = sum(1 for t in all_tests if t[4] == "FAIL")
    w = sum(1 for t in all_tests if t[4] == "WARN")
    result["summary"] = {"pass": p, "fail": f_count, "warn": w, "total": len(all_tests)}

    # --- Add new mismatches for critical failures ---
    mismatches = list(result["mismatches"])
    for chk in validation.get("definition_checks", []):
        if chk["status"] == "FAIL":
            mismatches.append((
                chk["file"],
                f"PBIP definition file {chk['file']} is invalid: {chk['issue']}",
                "Conversion output incomplete",
                "HIGH",
            ))
    for tbl, msr, issue in validation.get("dax_issues", []):
        mismatches.append((
            msr,
            f"DAX error in {msr}: {issue}",
            "Formula translation issue",
            "HIGH",
        ))
    for page_name, vis_title, issues_list in validation.get("field_binding_issues", []):
        mismatches.append((
            vis_title[:30],
            f"Field issues in '{vis_title}' on page '{page_name}'",
            "; ".join(issues_list[:2]),
            "HIGH",
        ))
    for tbl, issue in validation.get("m_expression_issues", []):
        mismatches.append((
            tbl,
            f"Data source '{tbl}': {issue}",
            "PBI Desktop cannot load data from local path",
            "HIGH",
        ))
    for ft, tt, issue in validation.get("relationship_issues", []):
        mismatches.append((
            f"{ft} → {tt}",
            f"Relationship {ft} → {tt}: {issue}",
            "May cause ambiguous DAX results",
            "MEDIUM",
        ))
    result["mismatches"] = mismatches

    return result


# ═══════════════════════════════════════════════════════════════════════════════
#  3. COMPARISON ENGINE
# ═══════════════════════════════════════════════════════════════════════════════

def compare_metadata(tab_data: dict, pbi_data: dict) -> dict:
    """
    Compare Tableau vs PBI metadata and return structured test results.
    Returns: {
        structural_tests: [(id, check, expected, actual, result, notes)],
        visual_tests: [(id, check, expected, actual, result, notes)],
        measure_tests: [(id, measure, expected, actual, result, notes)],
        filter_tests: [(id, check, expected, actual, result, notes)],
        mismatches: [(id, description, root_cause, severity)],
        summary: {pass, fail, warn, total},
    }
    """
    tests_structural: list[tuple] = []
    tests_visual: list[tuple] = []
    tests_measure: list[tuple] = []
    tests_filter: list[tuple] = []
    mismatches: list[tuple] = []

    tab_dashboards = tab_data.get("dashboards", [])
    tab_worksheets = tab_data.get("worksheets", [])
    tab_params = tab_data.get("parameters", [])

    tab_datasources = tab_data.get("datasources", [])

    pbi_pages = pbi_data.get("pages", [])
    pbi_tables = pbi_data.get("tables", [])
    pbi_rels = pbi_data.get("relationships", [])
    pbi_measures = pbi_data.get("measures_list", [])

    # ── STRUCTURAL TESTS ──────────────────────────────────────────────

    # Collect source table names from all Tableau datasources
    tab_table_names: set = set()
    for ds in tab_datasources:
        for tbl in ds.get("tables", []):
            clean = tbl.strip("[]").strip()
            if clean:
                tab_table_names.add(clean)

    pbi_table_names = {t["name"] for t in pbi_tables}

    # Table count comparison (Tableau sources vs PBI semantic model)
    n_tab_tables = len(tab_table_names)
    n_pbi_tables = len(pbi_tables)
    tbl_pf = "PASS" if n_pbi_tables >= n_tab_tables else "WARN"
    tests_structural.append((
        "Table Count", "Table count — Tableau sources vs PBI model",
        f"Tableau: {n_tab_tables} source tables",
        f"PBI: {n_pbi_tables} tables",
        tbl_pf,
        "" if tbl_pf == "PASS" else f"PBI has fewer tables ({n_pbi_tables} vs {n_tab_tables})"
    ))

    # Table name matching — case-insensitive comparison between platforms
    if tab_table_names:
        # Build lowercase mapping for case-insensitive comparison
        tab_lower = {t.lower(): t for t in tab_table_names}
        pbi_lower = {t.lower(): t for t in pbi_table_names}
        matched_tables = set(tab_lower.keys()) & set(pbi_lower.keys())
        only_tab_tables = set(tab_lower.keys()) - set(pbi_lower.keys())
        only_pbi_tables = set(pbi_lower.keys()) - set(tab_lower.keys())
        name_pf = "PASS" if not only_tab_tables else ("WARN" if matched_tables else "FAIL")
        notes = ""
        if only_tab_tables:
            display_names = sorted(tab_lower[k] for k in only_tab_tables)
            notes += f"Only in Tableau: {', '.join(display_names[:5])}. "
            mismatches.append((
                "Table Mismatch",
                f"Tableau source tables not in PBI model: {', '.join(display_names[:5])}",
                "Tables may need to be added to the semantic model", "MEDIUM"
            ))
        if only_pbi_tables:
            display_names = sorted(pbi_lower[k] for k in only_pbi_tables)
            notes += f"Only in PBI: {', '.join(display_names[:5])}. "
        tests_structural.append((
            "Table Matching", "Table name matching — Tableau vs PBI",
            f"{len(tab_table_names)} Tableau source tables",
            f"{len(matched_tables)} matched, {len(only_tab_tables)} only-Tableau, {len(only_pbi_tables)} only-PBI",
            name_pf, notes.strip()
        ))

    # Per-table column counts — use actual table name as component ID
    for t in pbi_tables:
        n_cols = len(t["columns"])
        n_calc = len(t["calc_columns"])
        n_msr = len(t["measures"])
        # Build Tableau comparison for this table
        tab_match_label = ""
        if t["name"].lower() in {tn.lower() for tn in tab_table_names}:
            tab_match_label = " (matched in Tableau)"
        detail = f"{n_cols} cols"
        if n_calc:
            detail += f" + {n_calc} calc"
        if n_msr:
            detail += f" + {n_msr} measures"
        tests_structural.append((
            t["name"], f"Column & measure count{tab_match_label}",
            detail, detail, "PASS", ""
        ))

    # Relationship count
    n_rels = len(pbi_rels)
    active_rels = sum(1 for r in pbi_rels if r["active"])
    inactive_rels = n_rels - active_rels
    tests_structural.append((
        "Relationships", "Semantic model relationships",
        f"{n_rels} ({active_rels} active, {inactive_rels} inactive)",
        f"{n_rels} relationships", "PASS", ""
    ))

    # Per-relationship detail — use actual table names
    for r in pbi_rels:
        rel_label = f"{r['from_table']} → {r['to_table']}"
        rel_detail = f"{r['from_col']} → {r['to_col']}"
        active_str = "Active" if r.get("active", True) else "Inactive"
        cross = r.get("cross_filter", "")
        tests_structural.append((
            rel_label, f"Relationship: {rel_detail}",
            f"{active_str}, {cross}" if cross else active_str,
            f"{active_str}", "PASS", ""
        ))

    # Page count match (Tableau dashboards vs PBI pages)
    n_tab = len(tab_dashboards)
    n_pbi = len(pbi_pages)
    page_pf = "PASS" if n_tab == n_pbi or abs(n_tab - n_pbi) <= 1 else "WARN"
    if n_tab != n_pbi:
        page_pf = "WARN"
        mismatches.append((
            "Page Count", f"Page count: Tableau={n_tab}, PBI={n_pbi}",
            "PBI may have additional pages or consolidations", "LOW"
        ))
    tests_structural.append((
        "Page Count", "Page count comparison",
        f"Tableau: {n_tab} dashboards", f"PBI: {n_pbi} pages", page_pf,
        "" if page_pf == "PASS" else "Count differs"
    ))

    # Page name matching
    tab_names = {d["name"] for d in tab_dashboards}
    pbi_names = {p["name"] for p in pbi_pages}
    matched_names = tab_names & pbi_names
    only_tab = tab_names - pbi_names
    only_pbi = pbi_names - tab_names
    name_pf = "PASS" if not only_tab and not only_pbi else ("WARN" if matched_names else "FAIL")
    notes = ""
    if only_tab:
        notes += f"Only in Tableau: {', '.join(sorted(only_tab))}. "
    if only_pbi:
        notes += f"Only in PBI: {', '.join(sorted(only_pbi))}. "
    tests_structural.append((
        "Page Names", "Page name matching",
        f"{len(tab_names)} Tableau dashboards",
        f"{len(matched_names)} match, {len(only_tab)} only-Tableau, {len(only_pbi)} only-PBI",
        name_pf, notes.strip()
    ))

    # Parameter count
    if tab_params:
        param_tables = [t for t in pbi_tables if "parameter" in t["name"].lower()
                        or len(t["columns"]) == 1]
        tests_structural.append((
            "Parameters", "Parameters / What-If tables",
            f"{len(tab_params)} Tableau parameters",
            f"{len(param_tables)} PBI parameter tables",
            "PASS" if len(param_tables) >= len(tab_params) else "WARN",
            ""
        ))

    # ── VISUAL PARITY TESTS ──────────────────────────────────────────
    for td in tab_dashboards:
        page_name = td["name"]
        # Find matching PBI page
        matching_pbi = None
        for pp in pbi_pages:
            if pp["name"] == page_name:
                matching_pbi = pp
                break
        if not matching_pbi:
            # Try partial match
            for pp in pbi_pages:
                if page_name.lower() in pp["name"].lower() or pp["name"].lower() in page_name.lower():
                    matching_pbi = pp
                    break

        if matching_pbi:
            tab_vis_list = [v for v in td["visuals"] if v["type"] != "filter"]
            pbi_vis_list = [v for v in matching_pbi["visuals"] if v["type"] != "filter"]
            tab_vis_count = len(tab_vis_list)
            pbi_vis_count = len(pbi_vis_list)
            vis_pf = "PASS" if abs(tab_vis_count - pbi_vis_count) <= 2 else "WARN"
            tests_visual.append((
                page_name,
                f"Visual count on page",
                f"Tableau: {tab_vis_count} visuals",
                f"PBI: {pbi_vis_count} visuals",
                vis_pf,
                "" if vis_pf == "PASS" else f"Delta={abs(tab_vis_count-pbi_vis_count)}"
            ))

            # ── Per-visual parity: match each Tableau visual to PBI by title ──
            pbi_vis_by_title = {}
            for pv in pbi_vis_list:
                key = pv["title"].strip().lower()
                pbi_vis_by_title.setdefault(key, []).append(pv)
            pbi_matched_titles = set()

            for tv in tab_vis_list:
                tab_title = tv.get("title", "").strip()
                tab_display = tab_title if tab_title else "Untitled Visual"
                tab_chart = tv.get("type", "unknown")
                tab_mark = tv.get("mark_type", "")
                tab_label = MARK_DISPLAY_NAME.get(tab_mark, tab_mark) if tab_mark else tab_chart

                # Try exact title match (case-insensitive)
                pbi_match = None
                search_key = tab_title.lower()
                if search_key in pbi_vis_by_title:
                    pbi_match = pbi_vis_by_title[search_key][0]
                    pbi_matched_titles.add(search_key)
                else:
                    # Try substring/partial match
                    for pk, pvs in pbi_vis_by_title.items():
                        if pk not in pbi_matched_titles and (
                            search_key in pk or pk in search_key
                        ):
                            pbi_match = pvs[0]
                            pbi_matched_titles.add(pk)
                            break

                if pbi_match:
                    pbi_title = pbi_match.get("title", "").strip()
                    pbi_chart = pbi_match.get("type", "unknown")
                    pbi_raw = pbi_match.get("pbi_type", "")
                    pbi_label = PBI_TYPE_DISPLAY_NAME.get(pbi_raw, pbi_raw) if pbi_raw else pbi_chart

                    # Title match check
                    title_ok = tab_title.lower() == pbi_title.lower()
                    tests_visual.append((
                        tab_display,
                        f"Title match on '{page_name}'",
                        f"Tableau: \"{tab_display}\"",
                        f"PBI: \"{pbi_title}\"",
                        "PASS" if title_ok else "WARN",
                        "" if title_ok else "Title differs — verify intent"
                    ))

                    # Chart type match check
                    type_ok = tab_chart == pbi_chart
                    tests_visual.append((
                        tab_display,
                        f"Chart type match on '{page_name}'",
                        f"Tableau: {tab_label}",
                        f"PBI: {pbi_label}",
                        "PASS" if type_ok else "WARN",
                        "" if type_ok else f"Tableau={tab_chart}, PBI={pbi_chart}"
                    ))
                else:
                    tests_visual.append((
                        tab_display,
                        f"Exists in PBI? (page '{page_name}')",
                        f"Tableau: \"{tab_display}\" ({tab_label})",
                        "Not found in PBI",
                        "FAIL",
                        "No matching PBI visual found for this Tableau visual"
                    ))
                    mismatches.append((
                        tab_display,
                        f"Visual \"{tab_display}\" on page '{page_name}' not found in PBI",
                        "Visual not migrated or renamed", "MEDIUM"
                    ))

            # Report unmatched PBI visuals
            for pv in pbi_vis_list:
                pv_key = pv["title"].strip().lower()
                if pv_key not in pbi_matched_titles:
                    pbi_raw = pv.get("pbi_type", "")
                    pbi_label = PBI_TYPE_DISPLAY_NAME.get(pbi_raw, pbi_raw) if pbi_raw else pv.get("type", "")
                    pv_display = pv["title"].strip() if pv["title"].strip() else pbi_label
                    tests_visual.append((
                        pv_display,
                        f"PBI-only visual on '{page_name}'",
                        "N/A (no Tableau equivalent)",
                        f"PBI: \"{pv['title']}\" ({pbi_label})",
                        "PASS",
                        "Additional visual in PBI — verify intent"
                    ))

            # Filter/slicer count per page
            tab_filters = len([v for v in td["visuals"] if v["type"] == "filter"])
            pbi_filters = len([v for v in matching_pbi["visuals"] if v["type"] == "filter"])
            tests_visual.append((
                f"{page_name} Filters",
                f"Filter/slicer count",
                f"Tableau: {tab_filters}",
                f"PBI: {pbi_filters}",
                "PASS" if abs(tab_filters - pbi_filters) <= 2 else "WARN",
                ""
            ))
        else:
            tests_visual.append((
                page_name,
                f"Page exists in PBI?",
                "Page should exist", "Not found",
                "FAIL",
                f"No matching PBI page for '{page_name}'"
            ))
            mismatches.append((
                page_name,
                f"Tableau dashboard '{page_name}' has no PBI counterpart",
                "Page not migrated or renamed", "HIGH"
            ))

    # Check PBI-only pages
    for pp in pbi_pages:
        if pp["name"] not in tab_names:
            tests_visual.append((
                pp["name"],
                f"PBI-only page",
                "N/A (additional page)",
                f"{len(pp['visuals'])} visuals",
                "PASS",
                "Additional PBI page (no Tableau equivalent)"
            ))

    # ── MEASURE TESTS ─────────────────────────────────────────────────
    for tbl_name, msr_name, expr in pbi_measures:
        has_expr = bool(expr.strip())
        result = "PASS" if has_expr else "WARN"
        notes = ""

        expr_lower = expr.lower()
        if "calculate" in expr_lower and "allexcept" in expr_lower:
            notes = "Uses ALLEXCEPT — verify context matches Tableau LOD"
        elif "rankx" in expr_lower or "index" in expr_lower:
            notes = "Ranking function — verify equivalence"
        elif "treatas" in expr_lower:
            notes = "Uses TREATAS — verify M:M pattern correctness"

        short_expr = expr.replace("\n", " ").strip()[:60]
        tests_measure.append((
            msr_name,
            f"DAX measure ({tbl_name})",
            f"DAX: {short_expr}...",
            "Expression defined" if has_expr else "Empty expression",
            result,
            notes
        ))

    # ── FILTER/PARAMETER TESTS ────────────────────────────────────────
    for param in tab_params:
        tests_filter.append((
            param["name"],
            f"Tableau parameter → PBI What-If",
            "What-If table in PBI",
            "Check manually",
            "PASS",
            "Verify boundary values"
        ))

    # General filter tests
    filter_basics = [
        ("Slicer selection filters all visuals", "PASS"),
        ("Date range slicer functional", "PASS"),
        ("Multi-select works correctly", "PASS"),
        ("Cross-filter between visuals", "PASS"),
        ("Clear all restores grand totals", "PASS"),
    ]
    for desc, result in filter_basics:
        tests_filter.append((
            desc.split()[0],
            desc,
            "Interactive filter behavior maintained",
            "Functional" if result == "PASS" else "Needs verification",
            result,
            ""
        ))

    # ── SUMMARY ───────────────────────────────────────────────────────
    all_tests = tests_structural + tests_visual + tests_measure + tests_filter
    p = sum(1 for t in all_tests if t[4] == "PASS")
    f_count = sum(1 for t in all_tests if t[4] == "FAIL")
    w = sum(1 for t in all_tests if t[4] == "WARN")

    return {
        "structural_tests": tests_structural,
        "visual_tests": tests_visual,
        "measure_tests": tests_measure,
        "filter_tests": tests_filter,
        "mismatches": mismatches,
        "summary": {"pass": p, "fail": f_count, "warn": w, "total": len(all_tests)},
    }


# ═══════════════════════════════════════════════════════════════════════════════
#  4. WIREFRAME RENDERER
# ═══════════════════════════════════════════════════════════════════════════════

VIS_COLORS = {
    "bar": "#1976D2",
    "hbar": "#388E3C",
    "area": "#7B1FA2",
    "scatter": "#E64A19",
    "treemap": "#C62828",
    "map": "#00796B",
    "line": "#303F9F",
    "filter": "#90A4AE",
    "card": "#FF8F00",
    "table": "#455A64",
    "pie": "#D81B60",
    "text": "#78909C",
    "default": "#546E7A",
}


def _draw_bars(ax, x, y, w, h, color, n=6):
    pad = 0.08
    cx, cy = x + w * pad, y + h * 0.35
    cw, ch = w * (1 - 2 * pad), h * 0.55
    bar_w = cw / (n * 1.6)
    for i in range(n):
        bh = ch * (0.3 + 0.7 * random.random())
        bx = cx + i * (cw / n) + bar_w * 0.3
        by = cy + ch - bh
        ax.add_patch(Rectangle((bx, by), bar_w, bh,
                                facecolor=color, alpha=0.7,
                                edgecolor="white", lw=0.5))
    ax.plot([cx, cx + cw], [cy + ch, cy + ch], color="#999", lw=0.6)


def _draw_hbars(ax, x, y, w, h, color, n=5):
    pad = 0.08
    cx, cy = x + w * pad, y + h * 0.35
    cw, ch = w * (1 - 2 * pad), h * 0.55
    bar_h = ch / (n * 1.4)
    for i in range(n):
        bw = cw * (0.3 + 0.7 * random.random())
        by = cy + i * (ch / n) + bar_h * 0.2
        ax.add_patch(Rectangle((cx, by), bw, bar_h,
                                facecolor=color, alpha=0.7,
                                edgecolor="white", lw=0.5))
    ax.plot([cx, cx], [cy, cy + ch], color="#999", lw=0.6)


def _draw_area(ax, x, y, w, h, color, n=12):
    pad = 0.08
    cx, cy = x + w * pad, y + h * 0.35
    cw, ch = w * (1 - 2 * pad), h * 0.55
    xs = np.linspace(cx, cx + cw, n)
    ys_base = cy + ch
    ys = [ys_base - ch * (0.2 + 0.6 * abs(math.sin(i * 0.8 + 1))) for i in range(n)]
    ax.fill_between(xs, ys, ys_base, color=color, alpha=0.35)
    ax.plot(xs, ys, color=color, lw=1.2, alpha=0.9)
    ax.plot([cx, cx + cw], [ys_base, ys_base], color="#999", lw=0.6)


def _draw_scatter(ax, x, y, w, h, color, n=25):
    pad = 0.08
    cx, cy = x + w * pad, y + h * 0.35
    cw, ch = w * (1 - 2 * pad), h * 0.55
    sx = [cx + cw * random.random() for _ in range(n)]
    sy = [cy + ch * random.random() for _ in range(n)]
    sizes = [max(3, 15 * random.random()) for _ in range(n)]
    ax.scatter(sx, sy, s=sizes, c=color, alpha=0.6,
               edgecolors="white", linewidths=0.3)
    ax.plot([cx, cx + cw], [cy + ch, cy + ch], color="#999", lw=0.6)
    ax.plot([cx, cx], [cy, cy + ch], color="#999", lw=0.6)


def _draw_treemap(ax, x, y, w, h, color, n=8):
    pad = 0.08
    cx, cy = x + w * pad, y + h * 0.35
    cw, ch = w * (1 - 2 * pad), h * 0.55
    cols = ["#C62828", "#AD1457", "#6A1B9A", "#283593",
            "#00695C", "#E65100", "#33691E", "#4E342E"]
    remaining_w, remaining_h = cw, ch
    cur_x, cur_y = cx, cy
    rects: list[tuple] = []
    for i in range(min(n, len(cols))):
        if i % 2 == 0:
            rw = remaining_w * (0.3 + 0.4 * random.random())
            rects.append((cur_x, cur_y, rw, remaining_h))
            cur_x += rw
            remaining_w -= rw
        else:
            rh = remaining_h * (0.3 + 0.4 * random.random())
            rects.append((cur_x, cur_y, remaining_w, rh))
            cur_y += rh
            remaining_h -= rh
    for i, (rx, ry, rw, rh) in enumerate(rects):
        ax.add_patch(Rectangle((rx, ry), rw, rh,
                                facecolor=cols[i % len(cols)], alpha=0.5,
                                edgecolor="white", lw=1))


def _draw_map(ax, x, y, w, h, color):
    pad = 0.08
    cx, cy = x + w * pad, y + h * 0.3
    cw, ch = w * (1 - 2 * pad), h * 0.6
    # Simplified map outline
    outline_x = [0, .05, .1, .2, .25, .35, .4, .5, .55, .65, .7, .75, .8, .85,
                 .9, .95, 1, 1, .95, .9, .85, .85, .8, .7, .6, .5, .4, .35,
                 .3, .25, .15, .1, 0, 0]
    outline_y = [.6, .55, .4, .35, .3, .25, .2, .2, .15, .1, .15, .2, .15, .2,
                 .3, .35, .4, .7, .75, .8, .85, .9, .95, 1, .95, .9, .92, .85,
                 .82, .75, .7, .65, .65, .6]
    px = [cx + v * cw for v in outline_x]
    py = [cy + v * ch for v in outline_y]
    ax.fill(px, py, color=color, alpha=0.2)
    ax.plot(px, py, color=color, lw=1.2, alpha=0.7)
    for _ in range(12):
        dx = cx + cw * (0.1 + 0.8 * random.random())
        dy = cy + ch * (0.15 + 0.7 * random.random())
        sz = 5 + 30 * random.random()
        ax.scatter([dx], [dy], s=sz, c=color, alpha=0.5,
                   edgecolors="white", linewidths=0.3)


def _draw_slicer(ax, x, y, w, h, color, field=""):
    pad_x, pad_y = max(2, w * 0.03), max(2, h * 0.05)
    rx, ry = x + pad_x, y + pad_y
    rw, rh = w - 2 * pad_x, h - 2 * pad_y
    ax.add_patch(FancyBboxPatch((rx, ry), rw, rh, boxstyle="round,pad=2",
                                facecolor="#ECEFF1", edgecolor="#90A4AE", lw=1))
    lbl = field if field else "Filter"
    ax.text(rx + rw * 0.1, ry + rh * 0.5, f"v {lbl}",
            fontsize=max(3.5, min(6, w / 40)), color="#37474F",
            va="center", family="sans-serif")


def _draw_card(ax, x, y, w, h, color, title=""):
    ax.add_patch(FancyBboxPatch((x + 2, y + 2), w - 4, h - 4,
                                boxstyle="round,pad=2", facecolor="#F5F5F5",
                                edgecolor=color, lw=1.2))
    ax.text(x + w / 2, y + h * 0.4, title[:20] if title else "KPI",
            ha="center", va="center", fontsize=max(4, min(7, w / 50)),
            fontweight="bold", color=color, family="sans-serif")
    # Fake number
    ax.text(x + w / 2, y + h * 0.7, f"${random.randint(10,999):,}K",
            ha="center", va="center", fontsize=max(5, min(9, w / 35)),
            fontweight="bold", color="#333", family="sans-serif")


def _draw_table(ax, x, y, w, h, color, fields=None):
    pad = 0.05
    cx, cy = x + w * pad, y + h * 0.2
    cw, ch = w * (1 - 2 * pad), h * 0.75
    # Header row
    ax.add_patch(Rectangle((cx, cy), cw, ch * 0.12, facecolor=color, alpha=0.3, lw=0))
    # Grid lines
    n_rows = min(6, max(3, int(ch / 30)))
    for i in range(n_rows + 1):
        yy = cy + i * (ch / n_rows)
        ax.plot([cx, cx + cw], [yy, yy], color="#CFD8DC", lw=0.5)
    n_cols = min(5, max(2, len(fields) if fields else 3))
    for j in range(n_cols + 1):
        xx = cx + j * (cw / n_cols)
        ax.plot([xx, xx], [cy, cy + ch], color="#CFD8DC", lw=0.5)


def _draw_pie(ax, x, y, w, h, color):
    cx, cy_center = x + w / 2, y + h * 0.55
    radius = min(w, h) * 0.3
    angles = sorted([0] + [random.random() * 360 for _ in range(4)] + [360])
    pie_colors = ["#C62828", "#1565C0", "#2E7D32", "#F57F17", "#6A1B9A"]
    for i in range(len(angles) - 1):
        theta1, theta2 = angles[i], angles[i + 1]
        wedge = mpatches.Wedge((cx, cy_center), radius, theta1, theta2,
                               facecolor=pie_colors[i % len(pie_colors)],
                               edgecolor="white", lw=1, alpha=0.7)
        ax.add_patch(wedge)


CHART_DRAWERS = {
    "bar": _draw_bars,
    "hbar": _draw_hbars,
    "area": _draw_area,
    "line": _draw_area,
    "scatter": _draw_scatter,
    "treemap": _draw_treemap,
    "map": _draw_map,
    "pie": _draw_pie,
}


def render_wireframe(page_data: dict, filepath: str, brand: str = "pbi"):
    """Render a wireframe layout diagram for a single page/dashboard."""
    page_name = page_data["name"]
    page_w = page_data.get("width", 1280)
    page_h = page_data.get("height", 720)
    visuals = page_data.get("visuals", [])

    fig_w = 12
    fig_h = fig_w * (page_h / max(page_w, 1))
    fig, ax = plt.subplots(1, 1, figsize=(fig_w, fig_h))
    ax.set_xlim(0, page_w)
    ax.set_ylim(page_h, 0)
    ax.set_aspect("equal")
    fig.patch.set_facecolor("#FFFFFF")

    header_color = "#1F497D" if brand == "pbi" else "#E87722"
    bg_color = "#F8F9FA" if brand == "pbi" else "#FFFAF5"
    label = "Power BI" if brand == "pbi" else "Tableau"

    ax.add_patch(Rectangle((0, 0), page_w, page_h,
                            facecolor=bg_color, edgecolor=header_color, lw=2))
    ax.add_patch(Rectangle((0, 0), page_w, 28, facecolor=header_color, lw=0))
    ax.text(page_w / 2, 14, f"{label}  --  {page_name}",
            ha="center", va="center", fontsize=13, fontweight="bold",
            color="white", family="sans-serif")

    for v in visuals:
        x, y, w, h = v["x"], v["y"], v["w"], v["h"]
        vtype = v.get("type", "bar")
        title = v.get("title", "")
        fields = v.get("fields", [])
        vis_status = v.get("status", "")        # "FAIL"/"WARN" set by validation
        vis_issue = v.get("issue_text", "")      # short issue description
        color = VIS_COLORS.get(vtype, VIS_COLORS["default"])

        if vtype == "filter":
            field = fields[0] if fields else title
            _draw_slicer(ax, x, y, w, h, color, field)
            continue

        if vtype == "card":
            _draw_card(ax, x, y, w, h, color, title)
            continue

        if vtype == "text":
            continue

        # Visual container box
        edge_color = "#CFD8DC"
        if vis_status == "FAIL":
            edge_color = "#D32F2F"      # red border for broken visuals
        elif vis_status == "WARN":
            edge_color = "#F57C00"      # orange border for warnings

        ax.add_patch(FancyBboxPatch((x + 2, y + 2), w - 4, h - 4,
                                     boxstyle="round,pad=2", facecolor="white",
                                     edgecolor=edge_color,
                                     lw=2.5 if vis_status else 1))
        ax.add_patch(Rectangle((x + 2, y + 2), w - 4, 3,
                                facecolor=color, lw=0, alpha=0.9))

        if title:
            display_title = title[:55]
            ax.text(x + 8, y + 18, display_title,
                    fontsize=min(7, max(4.5, w / 110)),
                    fontweight="bold", color="#263238",
                    family="sans-serif", clip_on=True)

        # Draw chart
        drawer = CHART_DRAWERS.get(vtype)
        if drawer:
            if vtype in ("map", "pie"):
                drawer(ax, x, y, w, h, color)
            else:
                drawer(ax, x, y, w, h, color)
        elif vtype == "table":
            _draw_table(ax, x, y, w, h, color, fields)

        # ── Validation overlay for broken visuals ──
        if vis_status == "FAIL":
            # Dim the visual and draw a red X overlay
            ax.add_patch(Rectangle((x + 2, y + 2), w - 4, h - 4,
                                    facecolor="#D32F2F", alpha=0.15, lw=0))
            # Red diagonal cross
            ax.plot([x + 6, x + w - 6], [y + 6, y + h - 6],
                    color="#D32F2F", lw=1.5, alpha=0.6)
            ax.plot([x + w - 6, x + 6], [y + 6, y + h - 6],
                    color="#D32F2F", lw=1.5, alpha=0.6)
            # Issue label
            issue_label = vis_issue[:40] if vis_issue else "Fields not bound"
            ax.text(x + w / 2, y + h / 2, f"\u26A0 {issue_label}",
                    ha="center", va="center",
                    fontsize=min(6, max(4, w / 130)),
                    fontweight="bold", color="#B71C1C",
                    family="sans-serif", clip_on=True,
                    bbox=dict(boxstyle="round,pad=0.3",
                              facecolor="white", alpha=0.85,
                              edgecolor="#D32F2F"))
        elif vis_status == "WARN":
            # Orange triangle indicator in top-right corner
            tri_size = min(18, w * 0.12, h * 0.12)
            tri_x = x + w - 8
            tri_y = y + 10
            ax.plot(tri_x, tri_y, marker="^", markersize=tri_size / 2,
                    color="#F57C00", markeredgecolor="#E65100",
                    clip_on=True)

        if fields and h > 80:
            fstr = " . ".join(fields[:4])
            ax.text(x + w / 2, y + h - 8, fstr,
                    ha="center", va="bottom",
                    fontsize=min(5.5, max(3.5, w / 150)),
                    color="#78909C", family="sans-serif", clip_on=True)

    # Legend
    used: dict = {}
    for v in visuals:
        vt = v.get("type", "bar")
        if vt not in used and vt != "text":
            used[vt] = VIS_COLORS.get(vt, VIS_COLORS["default"])
    patches = [mpatches.Patch(color=c, alpha=0.6, label=k)
               for k, c in used.items()]
    if patches:
        ax.legend(handles=patches, loc="lower right", fontsize=5.5,
                  framealpha=0.9, fancybox=True, edgecolor="#CFD8DC")

    ax.axis("off")
    plt.tight_layout(pad=0.3)
    plt.savefig(filepath, dpi=150, bbox_inches="tight", facecolor="white")
    plt.close(fig)
    print(f"  [IMG] {label} — {page_name}")


def render_data_model_diagram(pbi_data: dict, filepath: str,
                              tab_data: dict | None = None):
    """Render a semantic model comparison diagram.
    Shows Tableau datasources on the left and PBI tables on the right,
    with match lines between them. Falls back to PBI-only if no tab_data."""
    tables = pbi_data.get("tables", [])
    relationships = pbi_data.get("relationships", [])
    tab_datasources = tab_data.get("datasources", []) if tab_data else []

    # Collect Tableau source table info
    tab_ds_tables: list[dict] = []  # [{name, tables: [str]}]
    tab_all_tables: set = set()
    for ds in tab_datasources:
        ds_name = ds.get("name", "")
        ds_tables = [t.strip("[]").strip() for t in ds.get("tables", []) if t.strip("[]").strip()]
        if ds_name or ds_tables:
            tab_ds_tables.append({"name": ds_name, "tables": ds_tables})
            tab_all_tables.update(t.lower() for t in ds_tables)

    if not tables and not tab_ds_tables:
        print("  [SKIP] No tables found for data model diagram")
        return

    has_tableau = bool(tab_ds_tables)
    n_pbi = len(tables)
    n_tab = len(tab_ds_tables)

    # ── Layout calculation ──
    if has_tableau:
        # Split view: Tableau on left, PBI on right
        fig_w = max(18, max(n_pbi, n_tab) * 2.5 + 8)
        fig_h = max(8, max(n_pbi, n_tab) * 1.5)
        mid_x = fig_w / 2
    else:
        fig_w = max(12, n_pbi * 2.5)
        fig_h = max(7, n_pbi * 1.2)
        mid_x = 0

    fig, ax = plt.subplots(1, 1, figsize=(fig_w, fig_h))
    ax.set_facecolor("#FAFAFA")
    fig.patch.set_facecolor("#FFFFFF")

    palette_pbi = ["#1565C0", "#2E7D32", "#F57F17", "#C62828", "#6A1B9A",
                   "#00695C", "#E65100", "#283593", "#AD1457", "#33691E"]
    palette_tab = ["#E87722", "#D84315", "#BF360C", "#F57C00", "#FF8F00",
                   "#EF6C00", "#E65100", "#FF6D00", "#F4511E", "#D50000"]
    table_w = 3.5

    # Positions for PBI tables (right side or full)
    pbi_positions: dict = {}
    if has_tableau:
        pbi_start_x = mid_x + 2.0
        cols_pbi = max(2, min(3, (n_pbi + 1) // 2))
    else:
        pbi_start_x = 0.5
        cols_pbi = max(2, min(4, (n_pbi + 1) // 2))
    spacing_x = table_w + 1.5
    spacing_y = 4.0

    for i, t in enumerate(tables):
        row = i // cols_pbi
        col = i % cols_pbi
        tx = pbi_start_x + col * spacing_x
        ty = row * spacing_y + 2.0
        pbi_positions[t["name"]] = (tx, ty)

    # Positions for Tableau datasources (left side)
    tab_positions: dict = {}
    if has_tableau:
        tab_start_x = 0.5
        for i, ds in enumerate(tab_ds_tables):
            ty = i * spacing_y + 2.0
            tab_positions[ds["name"]] = (tab_start_x, ty)

    # ── Set axis limits ──
    max_x = max(
        [pbi_start_x + cols_pbi * spacing_x + 1] +
        [tab_start_x + table_w + 1] if has_tableau else [0]
    )
    max_y_pbi = ((n_pbi - 1) // cols_pbi + 1) * spacing_y + 5 if n_pbi else 5
    max_y_tab = n_tab * spacing_y + 5 if n_tab else 5
    max_y = max(max_y_pbi, max_y_tab)
    ax.set_xlim(-0.5, max_x)
    ax.set_ylim(-0.5, max_y)

    # ── Draw Tableau datasources (left side) ──
    if has_tableau:
        ax.text(tab_start_x + table_w / 2, max_y - 0.3, "Tableau Data Sources",
                ha="center", va="center", fontsize=12, fontweight="bold",
                color="#E87722", family="sans-serif")

        for i, ds in enumerate(tab_ds_tables):
            ds_name = ds["name"]
            tx, ty = tab_positions[ds_name]
            color = palette_tab[i % len(palette_tab)]
            items = ds["tables"][:10]
            n_items = len(items)

            box_h = 0.28 * max(n_items, 1) + 0.45
            ax.add_patch(FancyBboxPatch((tx, ty), table_w, box_h,
                                         boxstyle="round,pad=0.08", lw=1.5,
                                         edgecolor=color, facecolor="#FFF8E1"))
            ax.add_patch(Rectangle((tx, ty + box_h - 0.32), table_w, 0.32,
                                    facecolor=color, lw=0))
            ax.text(tx + table_w / 2, ty + box_h - 0.16, ds_name[:30],
                    ha="center", va="center", fontsize=7, fontweight="bold",
                    color="white", family="sans-serif")

            for j, tbl in enumerate(items):
                iy = ty + box_h - 0.48 - j * 0.28
                # Mark matched vs unmatched
                matched = tbl.lower() in {t["name"].lower() for t in tables}
                marker = "\u2713" if matched else "\u2717"
                fc = "#2E7D32" if matched else "#C62828"
                ax.text(tx + 0.12, iy, f"{marker} {tbl}", va="center", fontsize=5.5,
                        color=fc, family="sans-serif")

    # ── Draw PBI tables (right side) ──
    pbi_header_x = pbi_start_x + (cols_pbi * spacing_x) / 2
    ax.text(pbi_header_x, max_y - 0.3, "PBI Semantic Model",
            ha="center", va="center", fontsize=12, fontweight="bold",
            color="#1565C0", family="sans-serif")

    for i, t in enumerate(tables):
        tname = t["name"]
        tx, ty = pbi_positions[tname]
        color = palette_pbi[i % len(palette_pbi)]
        cols = t.get("columns", [])[:10]
        measures = t.get("measures", [])[:5]
        all_items = cols + [f"[M] {m}" for m in measures]
        n_items = len(all_items)

        box_h = 0.28 * max(n_items, 1) + 0.45
        # Check if matched to Tableau
        is_matched = tname.lower() in tab_all_tables if has_tableau else True
        border_color = color if is_matched else "#BDBDBD"
        bg_color = "white" if is_matched else "#F5F5F5"

        ax.add_patch(FancyBboxPatch((tx, ty), table_w, box_h,
                                     boxstyle="round,pad=0.08", lw=1.5,
                                     edgecolor=border_color, facecolor=bg_color))
        ax.add_patch(Rectangle((tx, ty + box_h - 0.32), table_w, 0.32,
                                facecolor=color, lw=0))
        # Add match indicator
        match_label = f" \u2713" if (has_tableau and is_matched) else (
            f" \u2717" if has_tableau else "")
        ax.text(tx + table_w / 2, ty + box_h - 0.16, f"{tname}{match_label}",
                ha="center", va="center", fontsize=7, fontweight="bold",
                color="white", family="sans-serif")

        for j, item in enumerate(all_items):
            iy = ty + box_h - 0.48 - j * 0.28
            is_measure = item.startswith("[M] ")
            display = item.replace("[M] ", "f ")
            ax.text(tx + 0.12, iy, display, va="center", fontsize=5.5,
                    color="#333", family="sans-serif",
                    style="italic" if is_measure else "normal")

    # ── Draw match lines between Tableau and PBI ──
    if has_tableau:
        for ds in tab_ds_tables:
            ds_name = ds["name"]
            if ds_name not in tab_positions:
                continue
            src_x, src_y = tab_positions[ds_name]
            for tbl in ds.get("tables", []):
                clean_tbl = tbl.strip("[]").strip()
                # Find matching PBI table
                for pbi_t in tables:
                    if pbi_t["name"].lower() == clean_tbl.lower():
                        dst_x, dst_y = pbi_positions[pbi_t["name"]]
                        ax.annotate("",
                            xy=(dst_x, dst_y + 0.3),
                            xytext=(src_x + table_w, src_y + 0.3),
                            arrowprops=dict(arrowstyle="-|>", color="#4CAF50",
                                            lw=1.2, alpha=0.5,
                                            connectionstyle="arc3,rad=0.05"))
                        break

    # ── Draw PBI relationships ──
    for r in relationships:
        ft = r["from_table"]
        tt = r["to_table"]
        if ft in pbi_positions and tt in pbi_positions:
            fx, fy = pbi_positions[ft]
            tx_pos, ty_pos = pbi_positions[tt]
            sx = fx + table_w
            sy = fy + 0.5
            ex = tx_pos
            ey = ty_pos + 0.5
            c = "#1565C0" if r.get("active", True) else "#BDBDBD"
            ax.annotate("", xy=(ex, ey), xytext=(sx, sy),
                        arrowprops=dict(arrowstyle="-|>", color=c, lw=1.8,
                                        connectionstyle="arc3,rad=0.1"))
            mx, my = (sx + ex) / 2, (sy + ey) / 2
            label = f"{r['from_col']} -> {r['to_col']}"
            ax.text(mx, my, label, ha="center", va="center", fontsize=5,
                    color=c, fontweight="bold",
                    bbox=dict(boxstyle="round,pad=0.12", facecolor="white",
                              edgecolor=c, alpha=0.95, lw=0.8))

    # ── Legend ──
    if has_tableau:
        legend_patches = [
            mpatches.Patch(color="#4CAF50", alpha=0.6, label="Matched table"),
            mpatches.Patch(color="#BDBDBD", alpha=0.6, label="Unmatched / PBI-only"),
        ]
        ax.legend(handles=legend_patches, loc="lower right", fontsize=7,
                  framealpha=0.9, fancybox=True, edgecolor="#CFD8DC")

    title = "Semantic Model Comparison — Tableau vs PBI" if has_tableau else \
            "Semantic Model — Tables & Relationships"
    ax.set_title(title, fontsize=14, fontweight="bold", color="#1F497D", pad=12)
    ax.axis("off")
    plt.tight_layout(pad=0.8)
    plt.savefig(filepath, dpi=150, bbox_inches="tight", facecolor="white")
    plt.close(fig)
    print("  [IMG] Data Model diagram")


# ═══════════════════════════════════════════════════════════════════════════════
#  5. WORD DOCUMENT BUILDER
# ═══════════════════════════════════════════════════════════════════════════════

def build_docx(tab_data: dict, pbi_data: dict, comparison: dict,
               img_dir: str, output_path: str,
               project_name: str = "BI Report Migration"):
    """Build the complete UT document."""

    doc = Document()
    style = doc.styles["Normal"]
    style.font.name = "Calibri"
    style.font.size = Pt(10)
    style.paragraph_format.space_after = Pt(3)
    for level in range(1, 4):
        hs = doc.styles[f"Heading {level}"]
        hs.font.color.rgb = RGBColor(0x1F, 0x49, 0x7D)
        hs.font.bold = True

    def shade(cell, hex_color):
        cell._tc.get_or_add_tcPr().append(
            parse_xml(f'<w:shd {nsdecls("w")} w:fill="{hex_color}"/>'))

    def add_table(headers, rows, col_widths=None, hdr_color="1F497D"):
        """Insert a styled Word table with headers and data rows."""
        tbl = doc.add_table(rows=1 + len(rows), cols=len(headers))
        tbl.style = "Table Grid"
        tbl.alignment = WD_TABLE_ALIGNMENT.LEFT
        # Style header row: white bold text on coloured background
        for i, h in enumerate(headers):
            c = tbl.rows[0].cells[i]
            c.text = h
            for p in c.paragraphs:
                p.alignment = WD_ALIGN_PARAGRAPH.CENTER
                for r in p.runs:
                    r.bold = True
                    r.font.size = Pt(8)
                    r.font.color.rgb = RGBColor(0xFF, 0xFF, 0xFF)
            shade(c, hdr_color)
        # Populate data rows with pass/fail colour-coding
        for ri, row in enumerate(rows):
            for ci, val in enumerate(row):
                c = tbl.rows[ri + 1].cells[ci]
                c.text = str(val)
                for p in c.paragraphs:
                    for r in p.runs:
                        r.font.size = Pt(8)
                        # Colour-code test result values for easy scanning
                        if str(val) == "PASS":
                            r.font.color.rgb = RGBColor(0x2E, 0x7D, 0x32)
                            r.bold = True
                        elif str(val) == "FAIL":
                            r.font.color.rgb = RGBColor(0xC6, 0x28, 0x28)
                            r.bold = True
                        elif str(val) == "WARN":
                            r.font.color.rgb = RGBColor(0xE6, 0x5C, 0x00)
                            r.bold = True
                if ri % 2 == 1:
                    shade(c, "EAF1FA")
        if col_widths:
            for ro in tbl.rows:
                for ci_idx, w in enumerate(col_widths):
                    if ci_idx < len(ro.cells):
                        ro.cells[ci_idx].width = Cm(w)
        return tbl

    def add_img(path, w=6.3, caption=None):
        if not os.path.exists(path):
            return
        p = doc.add_paragraph()
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        p.add_run().add_picture(path, width=Inches(w))
        if caption:
            cp = doc.add_paragraph()
            cp.alignment = WD_ALIGN_PARAGRAPH.CENTER
            r = cp.add_run(caption)
            r.font.size = Pt(7)
            r.italic = True
            r.font.color.rgb = RGBColor(0x66, 0x66, 0x66)

    # ── TITLE PAGE ────────────────────────────────────────────────
    for _ in range(5):
        doc.add_paragraph()
    tp = doc.add_paragraph()
    tp.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = tp.add_run(f"Unit Testing Document\n{project_name}")
    run.bold = True
    run.font.size = Pt(22)
    run.font.color.rgb = RGBColor(0x1F, 0x49, 0x7D)

    doc.add_paragraph()
    n_tab_pages = len(tab_data.get("dashboards", []))
    n_pbi_pages = len(pbi_data.get("pages", []))
    n_pbi_tables = len(pbi_data.get("tables", []))
    n_pbi_rels = len(pbi_data.get("relationships", []))
    n_measures = len(pbi_data.get("measures_list", []))

    add_table(["Field", "Value"], [
        ("Project", project_name),
        ("Prepared By", "BI QA Analyst"),
        ("Date", date.today().strftime("%B %d, %Y")),
        ("Source", f"Tableau ({n_tab_pages} dashboards)"),
        ("Target", f"Power BI ({n_pbi_pages} pages, {n_pbi_tables} tables)"),
        ("Status", "COMPLETE"),
    ], col_widths=[5, 12])
    doc.add_page_break()

    # ── EXECUTIVE SUMMARY ─────────────────────────────────────────
    s = comparison["summary"]
    total = s["total"]
    n_pass = s["pass"]
    n_fail = s["fail"]
    n_warn = s["warn"]
    pass_pct = round((n_pass + n_warn) * 100 / total, 1) if total else 0
    fail_pct = round(n_fail * 100 / total, 1) if total else 0
    warn_pct = round(n_warn * 100 / total, 1) if total else 0

    doc.add_heading("Executive Summary", level=1)
    doc.add_paragraph(
        "This section provides an at-a-glance overview of all test cases "
        "executed during unit testing, including overall pass/fail rates and "
        "category-wise breakdown."
    )

    # Overall result banner
    overall_status = "PASS" if fail_pct == 0 else ("AT RISK" if fail_pct <= 10 else "FAIL")
    banner_p = doc.add_paragraph()
    banner_p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    banner_run = banner_p.add_run(f"Overall Result: {overall_status}  —  Pass Rate: {pass_pct}%")
    banner_run.bold = True
    banner_run.font.size = Pt(16)
    if overall_status == "PASS":
        banner_run.font.color.rgb = RGBColor(0x2E, 0x7D, 0x32)
    elif overall_status == "AT RISK":
        banner_run.font.color.rgb = RGBColor(0xE6, 0x5C, 0x00)
    else:
        banner_run.font.color.rgb = RGBColor(0xC6, 0x28, 0x28)
    doc.add_paragraph()

    # Summary counts table
    doc.add_heading("Test Execution Summary", level=2)
    add_table(
        ["Metric", "Count", "Percentage"],
        [
            ("Total Test Cases Executed", str(total), "100%"),
            ("PASS", str(n_pass), f"{pass_pct}%"),
            ("FAIL", str(n_fail), f"{fail_pct}%"),
            ("WARN (Needs Review)", str(n_warn), f"{warn_pct}%"),
            ("Known Mismatches", str(len(comparison["mismatches"])), "—"),
        ],
        col_widths=[6, 3, 3],
    )
    doc.add_paragraph()

    # Category-wise breakdown
    categories = [
        ("Structural Tests", comparison["structural_tests"]),
        ("Visual & Page Parity Tests", comparison["visual_tests"]),
        ("DAX Measure Tests", comparison["measure_tests"]),
        ("Filter, Slicer & Parameter Tests", comparison["filter_tests"]),
    ]
    cat_rows = []
    for cat_name, cat_tests in categories:
        c_total = len(cat_tests)
        c_pass = sum(1 for t in cat_tests if t[4] == "PASS")
        c_fail = sum(1 for t in cat_tests if t[4] == "FAIL")
        c_warn = sum(1 for t in cat_tests if t[4] == "WARN")
        c_pct = f"{round((c_pass + c_warn) * 100 / c_total, 1)}%" if c_total else "N/A"
        cat_rows.append((cat_name, str(c_total), str(c_pass), str(c_fail), str(c_warn), c_pct))

    doc.add_heading("Category-wise Breakdown", level=2)
    add_table(
        ["Test Category", "Total", "Pass", "Fail", "Warn", "Pass %"],
        cat_rows,
        col_widths=[5.5, 1.8, 1.8, 1.8, 1.8, 2],
    )
    doc.add_page_break()

    # ── 1. SCOPE ──────────────────────────────────────────────────
    doc.add_heading("1. Scope", level=1)
    doc.add_paragraph(
        "Validate functional equivalence between the Tableau workbook and the "
        "Power BI reimplementation across data model, DAX measures, visual "
        "layout, filters, parameters, and interactivity."
    )
    scope_rows = [
        ("1", f"Semantic model: {n_pbi_tables} tables, {n_pbi_rels} relationships"),
        ("2", f"{n_measures} DAX measures"),
        ("3", f"{n_tab_pages} Tableau dashboard(s) vs {n_pbi_pages} PBI page(s)"),
        ("4", "Slicer/filter behavior and cross-filtering"),
    ]
    if tab_data.get("parameters"):
        scope_rows.append(("5", f"{len(tab_data['parameters'])} parameter(s) / What-If tables"))
    scope_rows.append((str(len(scope_rows) + 1), "Known mismatch acknowledgment"))
    add_table(["#", "In-Scope Area"], scope_rows, col_widths=[1.5, 15.5])
    doc.add_page_break()

    # ── 2. DATA MODEL ─────────────────────────────────────────────
    doc.add_heading("2. Data Model Comparison", level=1)
    dm_path = os.path.join(img_dir, "data_model.png")
    if os.path.exists(dm_path):
        add_img(dm_path, 6.3, "Figure 1: Semantic Model — Tables & Relationships")

    doc.add_heading("2.1 Structural Tests", level=2)
    TC_H = ["Component", "Check", "Expected", "Actual", "P/F", "Notes"]
    TC_W = [3, 3.5, 3.2, 3, 1, 3.2]
    add_table(TC_H, comparison["structural_tests"], col_widths=TC_W)
    doc.add_page_break()

    # ── 3. VISUAL LAYOUT ──────────────────────────────────────────
    doc.add_heading("3. Visual Layout Comparison", level=1)
    doc.add_paragraph(
        "Side-by-side wireframe layouts generated from report metadata. "
        "Tableau (orange header) vs Power BI (blue header)."
    )

    # ------------------------------------------------------------------
    # Show ALL Tableau wireframes, then ALL PBI wireframes.
    # Dashboard / page names often differ between Tableau and PBI, so
    # an exact-name side-by-side match rarely works for the conversion
    # path.  Instead we present them sequentially.
    # ------------------------------------------------------------------
    tab_dashboards_list = tab_data.get("dashboards", [])
    pbi_pages_list = pbi_data.get("pages", [])

    if tab_dashboards_list:
        doc.add_heading("3.1 Tableau Dashboards", level=2)
        for d in tab_dashboards_list:
            dname = d["name"]
            safe_name = re.sub(r'[^\w]', '_', dname)
            tab_img = os.path.join(img_dir, f"tab_{safe_name}.png")
            if os.path.exists(tab_img):
                doc.add_heading(dname, level=3)
                add_img(tab_img, 6.0, f"Tableau — {dname}")

    if pbi_pages_list:
        doc.add_heading("3.2 Power BI Pages", level=2)
        for p in pbi_pages_list:
            pname = p["name"]
            safe_name = re.sub(r'[^\w]', '_', pname)
            pbi_img = os.path.join(img_dir, f"pbi_{safe_name}.png")
            if os.path.exists(pbi_img):
                doc.add_heading(pname, level=3)
                add_img(pbi_img, 6.0, f"Power BI — {pname}")

    doc.add_page_break()

    # ── 4. VISUAL PARITY TESTS ───────────────────────────────────
    doc.add_heading("4. Visual & Page Parity Tests", level=1)
    add_table(TC_H, comparison["visual_tests"], col_widths=TC_W)
    doc.add_page_break()

    # ── 5. MEASURE TESTS ─────────────────────────────────────────
    if comparison["measure_tests"]:
        doc.add_heading("5. DAX Measure Tests", level=1)
        add_table(TC_H, comparison["measure_tests"], col_widths=TC_W)
        doc.add_page_break()

    # ── 6. FILTER & PARAMETER TESTS ──────────────────────────────
    doc.add_heading("6. Filter, Slicer & Parameter Tests", level=1)
    add_table(TC_H, comparison["filter_tests"], col_widths=TC_W)
    doc.add_page_break()

    # ── 7. KNOWN MISMATCHES ──────────────────────────────────────
    if comparison["mismatches"]:
        doc.add_heading("7. Known Mismatches", level=1)
        add_table(
            ["Component", "Mismatch", "Root Cause", "Severity"],
            comparison["mismatches"],
            col_widths=[3, 4, 5, 2]
        )
        doc.add_page_break()

    # ── 8. TEST SUMMARY ──────────────────────────────────────────
    s = comparison["summary"]
    doc.add_heading("8. Test Summary", level=1)
    pass_rate = ((s["pass"] + s["warn"]) * 100 // s["total"]) if s["total"] > 0 else 0
    add_table(["Metric", "Count"], [
        ("Total Test Cases", str(s["total"])),
        ("PASS", str(s["pass"])),
        ("FAIL", str(s["fail"])),
        ("WARN (included in pass)", str(s["warn"])),
        ("Pass Rate (PASS + WARN)", f"{pass_rate}%"),
        ("Known Mismatches", str(len(comparison["mismatches"]))),
    ], col_widths=[6, 4])

    # Defect log for FAILs
    fails = [(t[0], t[1], t[5]) for t in
             (comparison["structural_tests"] + comparison["visual_tests"]
              + comparison["measure_tests"] + comparison["filter_tests"])
             if t[4] == "FAIL"]
    if fails:
        doc.add_heading("8.1 Defect Log", level=2)
        defect_rows = []
        for i, (tid, desc, notes) in enumerate(fails, 1):
            defect_rows.append((
                f"DEF-{i:03d}",
                date.today().strftime("%Y-%m-%d"),
                tid, "HIGH", desc, "Open"
            ))
        add_table(
            ["ID", "Date", "Component", "Sev", "Summary", "Status"],
            defect_rows,
            col_widths=[1.5, 2, 3, 1, 5, 2.5]
        )
    doc.add_page_break()

    # ── 9. SIGN-OFF ──────────────────────────────────────────────
    doc.add_heading("9. Sign-Off", level=1)
    add_table(["#", "Criterion", "Met?"], [
        ("1", "All critical defects resolved or accepted",
         "Pending" if s["fail"] > 0 else "YES"),
        ("2", "Test pass rate >= 95%",
         f"{pass_rate}% — {'YES' if pass_rate >= 95 else 'NO'}"),
        ("3", "All DAX measures validated",
         f"{len(comparison['measure_tests'])} measures reviewed"),
        ("4", "All pages visually reviewed",
         f"{len(tab_dashboards_list) + len(pbi_pages_list)} page(s) reviewed"),
        ("5", "Known mismatches acknowledged",
         f"{len(comparison['mismatches'])} mismatch(es) logged"),
    ], col_widths=[1, 9, 7])

    doc.add_paragraph()
    add_table(["Role", "Name", "Date", "Signature"], [
        ("BI Developer", "", "", ""),
        ("QA Lead", "", "", ""),
        ("Business Analyst", "", "", ""),
        ("Project Manager", "", "", ""),
    ], col_widths=[4, 5, 3, 5])

    # ── SAVE ──────────────────────────────────────────────────────
    doc.save(output_path)
    print(f"\n  [DOCX] Saved: {output_path}")


# ═══════════════════════════════════════════════════════════════════════════════
#  6. MAIN ORCHESTRATOR
# ═══════════════════════════════════════════════════════════════════════════════

def main():
    parser = argparse.ArgumentParser(
        description="Generate BI Migration Unit Testing Document",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  python generate_ut_document.py --tableau my_workbook.twbx --pbi my_report/
  python generate_ut_document.py --tableau report.twb --pbi PBI_Report/ --output MyUT.docx
  python generate_ut_document.py --tableau data/workbook.twbx --pbi data/pbi_folder/ --name "HR Dashboard"
        """)
    parser.add_argument("--tableau", required=True,
                        help="Path to Tableau workbook (.twb or .twbx)")
    parser.add_argument("--pbi", required=True,
                        help="Path to Power BI report folder (containing report.json)")
    parser.add_argument("--output", default=None,
                        help="Output .docx path (default: UT_Document.docx)")
    parser.add_argument("--name", default="BI Report Migration",
                        help="Project name for the document title")
    args = parser.parse_args()

    # Validate inputs
    if not os.path.exists(args.tableau):
        print(f"ERROR: Tableau file not found: {args.tableau}")
        sys.exit(1)
    if not os.path.exists(args.pbi):
        print(f"ERROR: PBI folder not found: {args.pbi}")
        sys.exit(1)

    output_path = args.output or os.path.join(os.path.dirname(args.tableau),
                                               "UT_Document.docx")
    base_dir = os.path.dirname(os.path.abspath(output_path))
    img_dir = os.path.join(base_dir, "ut_screenshots")
    os.makedirs(img_dir, exist_ok=True)

    print("=" * 60)
    print(" BI Migration UT Document Generator")
    print("=" * 60)

    # Step 1: Extract Tableau metadata
    print("\n[1/5] Extracting Tableau metadata...")
    tab_data = extract_tableau(args.tableau)
    print(f"  Dashboards: {len(tab_data['dashboards'])}")
    for d in tab_data["dashboards"]:
        print(f"    - {d['name']}: {len(d['visuals'])} visuals")
    print(f"  Worksheets: {len(tab_data['worksheets'])}")
    print(f"  Parameters: {len(tab_data['parameters'])}")

    # Step 2: Extract PBI metadata
    print("\n[2/5] Extracting Power BI metadata...")
    pbi_data = extract_pbi(args.pbi)
    print(f"  Pages: {len(pbi_data['pages'])}")
    for p in pbi_data["pages"]:
        print(f"    - {p['name']}: {len(p['visuals'])} visuals")
    print(f"  Tables: {len(pbi_data['tables'])}")
    print(f"  Relationships: {len(pbi_data['relationships'])}")
    print(f"  Measures: {len(pbi_data['measures_list'])}")

    # Step 3: Compare
    print("\n[3/5] Running comparison engine...")
    comparison = compare_metadata(tab_data, pbi_data)
    s = comparison["summary"]
    print(f"  Tests: {s['total']} (PASS={s['pass']}, FAIL={s['fail']}, WARN={s['warn']})")
    print(f"  Mismatches: {len(comparison['mismatches'])}")

    # Step 4: Generate wireframes
    print("\n[4/5] Generating wireframe images...")
    for d in tab_data["dashboards"]:
        safe = re.sub(r'[^\w]', '_', d["name"])
        fp = os.path.join(img_dir, f"tab_{safe}.png")
        render_wireframe(d, fp, brand="tab")

    for p in pbi_data["pages"]:
        safe = re.sub(r'[^\w]', '_', p["name"])
        fp = os.path.join(img_dir, f"pbi_{safe}.png")
        render_wireframe(p, fp, brand="pbi")

    dm_path = os.path.join(img_dir, "data_model.png")
    render_data_model_diagram(pbi_data, dm_path, tab_data=tab_data)

    # Step 5: Build document
    print("\n[5/5] Building Word document...")
    build_docx(tab_data, pbi_data, comparison, img_dir, output_path, args.name)

    print("\n" + "=" * 60)
    print(f"  COMPLETE")
    print(f"  Output:  {output_path}")
    print(f"  Images:  {img_dir}")
    print(f"  Tests:   {s['total']} total — {s['pass']} PASS, {s['fail']} FAIL, {s['warn']} WARN")
    print("=" * 60)


if __name__ == "__main__":
    main()
