#!/usr/bin/env python3
"""
tableau_to_pbi_generic.py - Generic Tableau-to-Power BI Converter (v2)
======================================================================
Converts ANY Tableau workbook (.twbx / .twb) into Power BI artifacts:
  - .pbit     (Power BI Template - opens directly in Power BI Desktop)
  - .pbip     (Power BI Project folder - for Developer Mode)
  - PbixProj  (pbi-tools compatible folder - for version control)

Usage:
  python tableau_to_pbi_generic.py <path_to_twbx_or_twb> [output_directory]

Examples:
  python tableau_to_pbi_generic.py "C:\\Reports\\MyDashboard.twbx"
  python tableau_to_pbi_generic.py "C:\\Reports\\MyDashboard.twbx" "C:\\Output"

If output_directory is not provided, output goes next to the input file.
No third-party packages required - uses only Python standard library.
======================================================================
"""

import argparse
import json
import re
import shutil
import sys
import uuid
import xml.etree.ElementTree as ET
import zipfile
from pathlib import Path

__version__ = "2.0.0"


# =============================================================================
#  SECTION 1 - EXTRACTOR
# =============================================================================

def extract_twbx(twbx_path: Path, extract_dir: Path) -> dict:
    """
    Extract a .twbx archive (or accept a bare .twb) and return a dict with:
        twb_path   : Path   - the .twb file
        data_files : list[Path] - all non-twb files found
        data_dir   : Path | None - directory containing the primary data file
        image_dir  : Path | None - directory containing images
    """
    extract_dir.mkdir(parents=True, exist_ok=True)

    if twbx_path.suffix.lower() == ".twb":
        return {
            "twb_path": twbx_path,
            "data_files": [],
            "data_dir": twbx_path.parent,
            "image_dir": None,
        }

    with zipfile.ZipFile(twbx_path, "r") as zf:
        zf.extractall(extract_dir)

    twb_files = list(extract_dir.rglob("*.twb"))
    if not twb_files:
        raise FileNotFoundError(f"No .twb file found inside {twbx_path}")

    twb_path = twb_files[0]
    data_files = [f for f in extract_dir.rglob("*") if f.is_file() and f.suffix.lower() != ".twb"]

    data_dir = None
    for f in data_files:
        if f.suffix.lower() in (".xlsx", ".xls", ".csv", ".hyper", ".tde"):
            data_dir = f.parent
            break

    image_dir = None
    image_candidates = [f for f in data_files if f.suffix.lower() in (".png", ".jpg", ".jpeg", ".gif", ".svg")]
    if image_candidates:
        image_dir = image_candidates[0].parent

    return {
        "twb_path": twb_path,
        "data_files": data_files,
        "data_dir": data_dir,
        "image_dir": image_dir,
    }


# =============================================================================
#  SECTION 2 - TWB PARSER
# =============================================================================

_DATATYPE_MAP = {
    "string":   "string",
    "integer":  "int64",
    "real":     "double",
    "boolean":  "boolean",
    "date":     "dateTime",
    "datetime": "dateTime",
}


def parse_twb(twb_path: Path) -> dict:
    tree = ET.parse(str(twb_path))
    root = tree.getroot()
    return {
        "name": twb_path.stem,
        "parameters": _parse_parameters(root),
        "datasources": _parse_datasources(root),
        "worksheets": _parse_worksheets(root),
        "dashboards": _parse_dashboards(root),
        "actions": _parse_actions(root),
    }


def _parse_parameters(root) -> list:
    params = []
    params_ds = root.find(".//datasource[@name='Parameters']")
    if params_ds is None:
        return params
    for col in params_ds.findall("column"):
        name = col.get("name", "").strip("[]")
        caption = col.get("caption", name)
        datatype = col.get("datatype", "string")
        calc = col.find("calculation")
        default_val = calc.get("formula", "") if calc is not None else ""
        members = []
        for m in col.findall(".//member"):
            members.append({"alias": m.get("alias", ""), "value": m.get("value", "")})
        # Parse range for numeric parameters
        rng = col.find(".//range")
        range_info = {}
        if rng is not None:
            for attr in ("min", "max", "granularity"):
                v = rng.get(attr, "")
                if v:
                    range_info[attr] = v
        params.append({
            "name": name, "caption": caption, "datatype": datatype,
            "pbi_datatype": _DATATYPE_MAP.get(datatype, "string"),
            "default": default_val, "members": members,
            "range": range_info,
        })
    return params


def _parse_datasources(root) -> list:
    """Parse datasources - accept any non-Parameters datasource that has
    relations (tables), connections, or metadata-records."""
    datasources = []
    seen_names = set()
    for ds in root.findall(".//datasource"):
        ds_name = ds.get("name", "")
        if ds_name == "Parameters" or ds_name in seen_names:
            continue

        # Accept if inline="true" OR if the datasource has actual content
        has_inline = ds.get("inline") == "true"
        has_relations = len(ds.findall(".//relation")) > 0
        has_connection = len(ds.findall(".//connection")) > 0
        has_metadata = len(ds.findall(".//metadata-record")) > 0

        if not (has_inline or has_relations or has_connection or has_metadata):
            continue

        seen_names.add(ds_name)
        caption = ds.get("caption", ds_name)
        connection_info = _parse_connection(ds)
        tables, joins = _parse_relations(ds)
        data_columns, calc_columns = _parse_columns(ds)
        metadata_records = _parse_metadata_records(ds)
        number_formats = _parse_number_formats(ds)
        datasources.append({
            "name": ds_name, "caption": caption, "connection": connection_info,
            "tables": tables, "joins": joins, "data_columns": data_columns,
            "calc_columns": calc_columns, "metadata_records": metadata_records,
            "number_formats": number_formats,
        })
    return datasources


def _parse_connection(ds) -> dict:
    info = {"class": "", "filename": "", "named_connection": "",
            "server": "", "dbname": "", "schema": "", "port": "",
            "username": "", "warehouse": "", "service": "",
            "sslmode": "", "one-time-sql": ""}
    # Map of connection-name -> {class, filename} for multi-connection datasources
    nc_map = {}
    # Attributes to capture from any database connection element
    _DB_ATTRS = ("server", "dbname", "schema", "port", "username",
                 "warehouse", "service", "sslmode", "one-time-sql")
    for nc in ds.findall(".//named-connections/named-connection"):
        nc_name = nc.get("name", "")
        info["named_connection"] = nc.get("caption", "")
        for c in nc.findall("connection"):
            info["class"] = c.get("class", "")
            info["filename"] = c.get("filename", "")
            nc_entry = {"class": c.get("class", ""), "filename": c.get("filename", "")}
            for attr in _DB_ATTRS:
                val = c.get(attr, "")
                if val:
                    info[attr] = val
                    nc_entry[attr] = val
            if nc_name:
                nc_map[nc_name] = nc_entry
    info["named_connections_map"] = nc_map
    if not info["class"]:
        for c in ds.findall(".//connection"):
            cls = c.get("class", "")
            if cls and cls != "federated":
                info["class"] = cls
                info["filename"] = c.get("filename", "")
                for attr in _DB_ATTRS:
                    val = c.get(attr, "")
                    if val:
                        info[attr] = val
                break
    return info


def _parse_relations(ds) -> tuple:
    """Parse relations returning (tables, joins).
    Joins come from <relation type="join"> elements.
    Collections indicate multi-table datasources with implicit relationships."""
    tables = []
    joins = []
    seen = set()
    for rel in ds.iter("relation"):
        rtype = rel.get("type", "")
        name = rel.get("name", "")
        table = rel.get("table", "")
        if rtype == "table" and name and name not in seen:
            seen.add(name)
            conn_ref = rel.get("connection", "")
            entry = {"name": name, "table_ref": table, "type": rtype}
            if conn_ref:
                entry["connection"] = conn_ref
            tables.append(entry)
        elif rtype == "join":
            join_type = rel.get("join", "inner")
            clauses = []
            for clause in rel.findall("clause"):
                clause_type = clause.get("type", "")
                expr = clause.find("expression")
                if expr is not None:
                    parts = []
                    for col_ref in expr:
                        col_name = col_ref.get("name", "") or col_ref.get("op", "")
                        if col_name:
                            import re as _re
                            m_full = _re.search(r'\[([^\]]+)\]\.\[([^\]]+)\]$', col_name)
                            if m_full:
                                parts.append((m_full.group(1), m_full.group(2)))
                            else:
                                m_col = _re.search(r'\.\[([^\]]+)\]$', col_name)
                                if m_col:
                                    parts.append(("", m_col.group(1)))
                                else:
                                    parts.append(("", col_name.strip("[]")))
                    if len(parts) >= 2:
                        clauses.append({
                            "type": clause_type,
                            "left_col": parts[0][1],
                            "right_col": parts[1][1],
                            "left_table_hint": parts[0][0],
                            "right_table_hint": parts[1][0],
                        })
            child_rels = [c for c in rel if c.tag == "relation"]
            left_child = child_rels[0] if len(child_rels) > 0 else None
            right_child = child_rels[1] if len(child_rels) > 1 else None
            def _leaf_table(r):
                if r is None:
                    return ""
                if r.get("type") == "table":
                    return r.get("name", "")
                for c in reversed(list(r)):
                    if c.tag == "relation" and c.get("type") == "table":
                        return c.get("name", "")
                return ""
            left_table = _leaf_table(left_child) if left_child is not None and left_child.get("type") != "table" else (left_child.get("name", "") if left_child is not None else "")
            right_table = _leaf_table(right_child) if right_child is not None and right_child.get("type") != "table" else (right_child.get("name", "") if right_child is not None else "")
            if not left_table and clauses:
                left_table = clauses[0].get("left_table_hint", "")
            if not right_table and clauses:
                right_table = clauses[0].get("right_table_hint", "")
            if clauses:
                for cl in clauses:
                    lt = cl.get("left_table_hint", "")
                    rt = cl.get("right_table_hint", "")
                    if lt and rt:
                        joins.append({
                            "join_type": join_type, "left_table": lt,
                            "right_table": rt,
                            "clauses": [{"type": cl["type"], "left_col": cl["left_col"], "right_col": cl["right_col"]}],
                        })
            elif left_table and right_table:
                joins.append({
                    "join_type": join_type, "left_table": left_table,
                    "right_table": right_table, "clauses": clauses,
                })
        elif rtype == "collection":
            # Multi-table datasource: extract tables from children
            child_tables = [c for c in rel if c.tag == "relation" and c.get("type") == "table"]
            for ct in child_tables:
                ct_name = ct.get("name", "")
                ct_table = ct.get("table", "")
                ct_conn = ct.get("connection", "")
                if ct_name and ct_name not in seen:
                    seen.add(ct_name)
                    tables.append({"name": ct_name, "table_ref": ct_table, "type": "table", "connection": ct_conn})
    return tables, joins


def _parse_columns(ds) -> tuple:
    data_cols = []
    calc_cols = []
    for col in ds.findall("column"):
        name = col.get("name", "").strip("[]")
        caption = col.get("caption", "")
        role = col.get("role", "")
        datatype = col.get("datatype", "string")
        calc_elem = col.find("calculation")
        formula = calc_elem.get("formula", "") if calc_elem is not None else ""
        col_info = {
            "name": name, "caption": caption or name, "role": role,
            "datatype": datatype, "pbi_datatype": _DATATYPE_MAP.get(datatype, "string"),
            "formula": formula,
        }
        if name.startswith(":"):
            continue
        if formula:
            calc_cols.append(col_info)
        else:
            data_cols.append(col_info)
    return data_cols, calc_cols


def _parse_metadata_records(ds) -> list:
    records = []
    for mr in ds.findall(".//metadata-record"):
        if mr.get("class") != "column":
            continue
        local = mr.find("local-name")
        remote = mr.find("remote-name")
        parent = mr.find("parent-name")
        local_type = mr.find("local-type")
        if local is not None and parent is not None:
            records.append({
                "local_name": (local.text or "").strip("[]"),
                "remote_name": (remote.text if remote is not None else "") or "",
                "parent_table": (parent.text or "").strip("[]"),
                "local_type": (local_type.text if local_type is not None else "string"),
                "pbi_datatype": _DATATYPE_MAP.get(
                    (local_type.text if local_type is not None else "string"), "string"),
            })
    return records


def _parse_number_formats(ds) -> dict:
    """Extract number formats from column definitions."""
    formats = {}
    for col in ds.findall("column"):
        name = col.get("name", "").strip("[]")
        fmt = col.get("default-format", "")
        if fmt and name:
            formats[name] = fmt
    return formats


def _parse_worksheets(root) -> list:
    worksheets = []
    for ws in root.findall(".//worksheet"):
        name = ws.get("name", "")
        rows_text = ""
        cols_text = ""
        for r in ws.findall(".//rows"):
            if r.text:
                rows_text = r.text
        for c in ws.findall(".//cols"):
            if c.text:
                cols_text = c.text
        fields = _extract_field_refs(rows_text) + _extract_field_refs(cols_text)

        # Parse datasource dependencies for fields
        ds_refs = []
        for dsdep in ws.findall(".//datasource-dependencies"):
            ds_ref = dsdep.get("datasource", "")
            if ds_ref:
                ds_refs.append(ds_ref)
            for col in dsdep.findall("column"):
                fname = col.get("name", "").strip("[]")
                if fname and fname not in fields:
                    fields.append(fname)

        # Parse mark type (chart type)
        mark_class = "Automatic"
        for mark in ws.findall(".//mark"):
            mc = mark.get("class", "")
            if mc:
                mark_class = mc
                break

        # Parse encodings (color, size, tooltip, detail/lod, shape)
        encodings = {"color": [], "size": [], "tooltip": [], "detail": [], "shape": [],
                     "text": [], "wedge-size": []}
        encoding_raw = {k: [] for k in encodings}  # raw col_ref strings (preserves prefix)
        for enc_container in ws.findall(".//encodings"):
            for enc in enc_container:
                enc_type = enc.tag
                col_ref = enc.get("column", "")
                if col_ref and enc_type in encodings:
                    field_name = _extract_field_from_ref(col_ref)
                    if field_name:
                        encodings[enc_type].append(field_name)
                        encoding_raw[enc_type].append(col_ref)
                elif enc_type == "lod":
                    if col_ref:
                        field_name = _extract_field_from_ref(col_ref)
                        if field_name:
                            encodings["detail"].append(field_name)
                            encoding_raw["detail"].append(col_ref)

        # Parse fields_used (column-instance + calculated columns from datasource-dependencies)
        fields_used = []
        for dsdep in ws.findall(".//datasource-dependencies"):
            ds_id = dsdep.get("datasource", "")
            for ci in dsdep.findall("column-instance"):
                fields_used.append({
                    "datasource": ds_id,
                    "column": ci.get("column", ""),
                    "derivation": ci.get("derivation", ""),
                    "type": ci.get("type", ""),
                })
            for col in dsdep.findall("column"):
                calc = col.find("calculation")
                if calc is not None and calc.get("formula"):
                    fields_used.append({
                        "datasource": ds_id,
                        "column": col.get("name", ""),
                        "caption": col.get("caption", col.get("name", "")),
                        "is_calculated": True,
                    })

        # Parse datasource captions used in this worksheet
        datasources_used = []
        view = ws.find(".//table/view")
        if view is not None:
            ds_elem = view.find("datasources")
            if ds_elem is not None:
                for d in ds_elem:
                    datasources_used.append(
                        d.get("caption", d.get("name", "")))

        # Parse worksheet filters
        filters = _parse_worksheet_filters(ws)

        # Parse :Measure Names filter members (which measures are shown)
        mn_members = []
        for filt in ws.findall(".//filter"):
            fcol = filt.get("column", "")
            if ":Measure Names" in fcol:
                for gf in filt.iter("groupfilter"):
                    mem = gf.get("member", "").strip('"')
                    if mem and gf.get("function") == "member":
                        # Extract prefix:field from "[ds].[prefix:FieldName:suffix]"
                        mm = re.search(r'\[([^\]]+)\]$', mem)
                        if mm:
                            inner = mm.group(1)
                            parts = inner.split(':')
                            if len(parts) >= 2:
                                mn_members.append((parts[0], parts[1]))
                break  # only first :Measure Names filter

        worksheets.append({
            "name": name, "fields": fields,
            "rows_text": rows_text, "cols_text": cols_text,
            "mark_class": mark_class, "encodings": encodings,
            "encoding_raw": encoding_raw,
            "filters": filters, "datasource_refs": ds_refs,
            "fields_used": fields_used,
            "datasources_used": datasources_used,
            "mn_members": mn_members,
        })
    return worksheets


# All known Tableau field-reference prefixes
_KNOWN_PREFIXES = frozenset({
    "none", "sum", "cnt", "avg", "min", "max", "usr", "cum",
    "attr", "ctd", "rank", "fVal", "pcto", "med",
    "yr", "mn", "qr", "twk", "tmn", "tdy", "tyr", "tqr",
    "wk", "dy", "mdy",
})


def _extract_field_from_ref(col_ref: str) -> str:
    """Extract clean field name from a Tableau column reference like
    '[federated.xxx].[sum:Sales:qk]' or '[federated.xxx].[none:Region:nk]'."""
    m = re.search(r'\.\[([^\]]+)\]$', col_ref)
    if not m:
        m = re.search(r'\[([^\]]+)\]$', col_ref)
    if not m:
        return ""
    raw = m.group(1)
    parts = raw.split(':')
    if len(parts) >= 2:
        # Skip leading known prefix parts to reach the actual field name
        idx = 0
        while idx < len(parts) - 1 and parts[idx] in _KNOWN_PREFIXES:
            idx += 1
        field = parts[idx]
        return field
    return raw


def _parse_worksheet_filters(ws) -> list:
    """Parse filters from a worksheet element."""
    filters = []
    for f in ws.findall(".//filter"):
        fclass = f.get("class", "")
        col_ref = f.get("column", "")
        field_name = _extract_field_from_ref(col_ref) if col_ref else ""
        if not field_name or field_name.startswith(":"):
            continue  # Skip internal Tableau filters like :Measure Names
        filter_info = {"field": field_name, "type": fclass}
        if fclass == "quantitative":
            min_el = f.find(".//min")
            max_el = f.find(".//max")
            if min_el is not None and min_el.text:
                filter_info["min"] = min_el.text.strip("#")
            if max_el is not None and max_el.text:
                filter_info["max"] = max_el.text.strip("#")
        elif fclass == "categorical":
            values = []
            for gf in f.findall(".//groupfilter"):
                for member in gf.findall(".//groupmember"):
                    val = member.get("member", "")
                    if val:
                        values.append(val.strip("\""))
            if values:
                filter_info["values"] = values
        filters.append(filter_info)
    return filters


def _extract_field_refs(shelf_text: str) -> list:
    if not shelf_text:
        return []
    refs = re.findall(r'\[(?:none|sum|cnt|avg|min|max|usr|cum|attr):([^:\]]+)', shelf_text)
    refs += re.findall(r'\.\[([^\]]+)\]', shelf_text)
    return list(dict.fromkeys(refs))


def _parse_dashboards(root) -> list:
    dashboards = []
    for db in root.findall(".//dashboard"):
        name = db.get("name", "")
        ws_refs = []
        zones = []
        seen = set()
        # Parse all zones with positions
        for zone in db.findall(".//zone"):
            zname = zone.get("name", "")
            x = zone.get("x", "")
            y_val = zone.get("y", "")
            w = zone.get("w", "")
            h = zone.get("h", "")
            if zname:
                # Only take the first (main) occurrence of each named zone
                if zname not in seen:
                    seen.add(zname)
                    ws_refs.append(zname)
                    if x and y_val and w and h:
                        zones.append({
                            "name": zname,
                            "x": int(x), "y": int(y_val),
                            "w": int(w), "h": int(h),
                        })
        # If we have named refs but no zone positions, create even layout
        if not zones and ws_refs:
            count = len(ws_refs)
            zone_h = 100000 // max(count, 1)
            for i, wr in enumerate(ws_refs):
                zones.append({
                    "name": wr,
                    "x": 0, "y": i * zone_h, "w": 100000, "h": zone_h,
                })
        # Parse text/title zones (deduplicate by content + position)
        text_zones = []
        _tz_seen = set()
        for zone in db.findall(".//zone"):
            ztype = zone.get("type", "") or zone.get("type-v2", "")
            if ztype == "text":
                zx = zone.get("x", "")
                zy = zone.get("y", "")
                zw = zone.get("w", "")
                zh = zone.get("h", "")
                if zx and zy and zw and zh:
                    text_content = ""
                    for ft in zone.findall(".//formatted-text"):
                        for run in ft.findall("run"):
                            text_content += (run.text or "")
                    text_content = text_content.replace("\xa0", " ")
                    text_content = re.sub(
                        r'(?<![a-zA-Z\u00C0-\u024F])[^\x00-\x7F]|[^\x00-\x7F](?![a-zA-Z\u00C0-\u024F])',
                        '', text_content)
                    text_content = text_content.strip()
                    tz_key = (text_content, int(zx), int(zy))
                    if text_content and tz_key not in _tz_seen:
                        _tz_seen.add(tz_key)
                        text_zones.append({
                            "text": text_content,
                            "x": int(zx), "y": int(zy),
                            "w": int(zw), "h": int(zh),
                        })
        # Parse dashboard filter zones (quick filter slicers)
        filter_zones = []
        _fz_seen = set()
        for zone in db.findall(".//zone"):
            zt2 = zone.get("type-v2", "")
            if zt2 == "filter":
                col_ref = zone.get("column", "") or zone.get("param", "")
                if col_ref and col_ref not in _fz_seen:
                    _fz_seen.add(col_ref)
                    field_name = _extract_field_from_ref(col_ref)
                    if field_name:
                        filter_zones.append(field_name)
        dashboards.append({"name": name, "worksheet_refs": ws_refs,
                           "zones": zones, "text_zones": text_zones,
                           "filter_zones": filter_zones})
    return dashboards


def _parse_actions(root) -> list:
    """Parse dashboard filter/highlight actions."""
    actions = []
    for action in root.findall(".//action"):
        source = action.find("source")
        command = action.find("command")
        if source is not None and command is not None:
            cmd = command.get("command", "")
            src_dashboard = source.get("dashboard", "")
            src_worksheet = source.get("worksheet", "")
            activation = action.find("activation")
            trigger = activation.get("type", "on-select") if activation is not None else "on-select"
            action_type = "filter" if "filter" in cmd else "highlight" if "brush" in cmd else "other"
            actions.append({
                "dashboard": src_dashboard, "worksheet": src_worksheet,
                "type": action_type, "trigger": trigger,
            })
    return actions


# =============================================================================
#  SECTION 3 - FORMULA TRANSLATOR (Tableau calcs -> DAX)
# =============================================================================

_FUNC_MAP = {
    # Aggregation
    "SUM": "SUM", "AVG": "AVERAGE", "MIN": "MIN", "MAX": "MAX",
    "COUNT": "COUNT", "COUNTD": "DISTINCTCOUNT", "MEDIAN": "MEDIAN",
    # String
    "CONTAINS": "CONTAINSSTRING", "LEN": "LEN", "LEFT": "LEFT", "RIGHT": "RIGHT",
    "MID": "MID", "UPPER": "UPPER", "LOWER": "LOWER", "TRIM": "TRIM",
    "REPLACE": "SUBSTITUTE", "FIND": "FIND",
    "STARTSWITH": "CONTAINSSTRING", "ENDSWITH": "CONTAINSSTRING",
    "SPLIT": "SPLIT",
    # Date
    "DATEDIFF": "DATEDIFF", "DATEADD": "DATEADD", "DATEPART": "DATEPART",
    "DATETRUNC": "DATETRUNC", "TODAY": "TODAY", "NOW": "NOW",
    "YEAR": "YEAR", "MONTH": "MONTH", "DAY": "DAY",
    # Math
    "ROUND": "ROUND", "CEILING": "CEILING", "FLOOR": "FLOOR", "ABS": "ABS",
    "POWER": "POWER", "SQRT": "SQRT", "LOG": "LOG", "EXP": "EXP", "ZN": "ZN",
    "SIGN": "SIGN",
    # Logical
    "IF": "IF", "IIF": "IF", "ISNULL": "ISBLANK",
    "CASE": "SWITCH", "NOT": "NOT", "AND": "AND", "OR": "OR",
    # Type conversion
    "INT": "INT", "FLOAT": "VALUE", "STR": "FORMAT", "DATE": "DATE",
    # Statistical (Tableau-specific)
    "CORR": "__CORR", "VAR": "__VAR", "STDEV": "__STDEV",
    "WINDOW_MIN": "__WINDOW_MIN", "WINDOW_MAX": "__WINDOW_MAX",
    # Table calc (flagged for manual conversion)
    "RUNNING_SUM": "__RUNNING_SUM", "RUNNING_AVG": "__RUNNING_AVG",
    "RUNNING_COUNT": "__RUNNING_COUNT", "RUNNING_MIN": "__RUNNING_MIN",
    "RUNNING_MAX": "__RUNNING_MAX", "INDEX": "__INDEX",
    "FIRST": "__FIRST", "LAST": "__LAST", "LOOKUP": "__LOOKUP",
    "RANK": "RANKX", "WINDOW_SUM": "__WINDOW_SUM", "WINDOW_AVG": "__WINDOW_AVG",
    "SIZE": "__SIZE", "TOTAL": "__TOTAL", "ATTR": "__ATTR",
}


# ── Pre-processing helpers for formula translation ───────────────────────────

def _resolve_calc_names(dax: str, calc_name_map: dict) -> str:
    """Replace internal Tableau calc names (Calculation_xxx) with their captions."""
    for internal, caption in calc_name_map.items():
        # Also try whitespace-normalized version (XML may have extra spaces)
        norm_internal = re.sub(r'\s+', ' ', internal)
        dax = dax.replace(f"[{internal}]", f"[{caption}]")
        if norm_internal != internal:
            dax = dax.replace(f"[{norm_internal}]", f"[{caption}]")
    # Flag any remaining unresolved Calculation_xxx references
    for m in re.finditer(r'\[(Calculation_\d+)\]', dax):
        name = m.group(1)
        if name not in calc_name_map:
            dax = dax.replace(f"[{name}]", f"[{name}] /* UNRESOLVED: {name} not found in workbook */")
    return dax


def _resolve_dotted_refs(dax: str, param_map: dict, ds_col_to_table: dict,
                         field_param_names: set = None) -> tuple:
    """Replace [Parameters].[xxx] and [federated.xxx].[col] references.
    For list-type field parameters, route to 'ParamName'[ParamName Value].
    Returns (modified_dax, dict_of_placeholders_to_restore_later)."""
    placeholders = {}
    counter = [0]
    if field_param_names is None:
        field_param_names = set()

    def _replace(m):
        prefix = m.group(1)
        field = m.group(2)
        if prefix == "Parameters":
            measure_name = param_map.get(field, field)
            token = f"__PH{counter[0]}__"
            counter[0] += 1
            # Route to field-parameter table if this is a list-type param
            if measure_name in field_param_names:
                placeholders[token] = f"'{measure_name}'[{measure_name} Value]"
            else:
                placeholders[token] = f"'Parameters'[{measure_name}]"
            return token
        else:
            # Cross-datasource reference
            tbl = ds_col_to_table.get((prefix, field))
            if not tbl:
                tbl = ds_col_to_table.get(prefix, "Unknown")
            token = f"__PH{counter[0]}__"
            counter[0] += 1
            placeholders[token] = f"'{tbl}'[{field}]"
            return token

    dax = re.sub(r'\[([^\]]+)\]\.\[([^\]]+)\]', _replace, dax)
    return dax, placeholders


def _translate_lod(dax: str, table_name: str) -> str:
    """Translate Tableau LOD {fixed [Field]:AGG([Col])} to DAX CALCULATE.
    Handles nested LODs and the colon after the FIXED/INCLUDE/EXCLUDE keyword."""
    tbl = f"'{table_name}'"

    def _convert_lod_body(body: str) -> str:
        """Convert the inner body of a single LOD expression."""
        lod_body = re.sub(r'^(?:fixed|include|exclude)\s*:?\s*', '', body, flags=re.IGNORECASE).strip()
        colon_pos = lod_body.find(':')
        if colon_pos < 0:
            # No dimension fields — table-scoped FIXED
            return f"CALCULATE({lod_body}, ALL({tbl}))"
        fixed_part = lod_body[:colon_pos].strip()
        agg_part = lod_body[colon_pos + 1:].strip()
        fields = re.findall(r'\[([^\]]+)\]', fixed_part)
        if fields:
            allexcept = ", ".join(f"{tbl}[{f}]" for f in fields)
            return f"CALCULATE({agg_part}, ALLEXCEPT({tbl}, {allexcept}))"
        else:
            return f"CALCULATE({agg_part}, ALL({tbl}))"

    def _find_and_replace_lod(text: str) -> str:
        """Find the outermost LOD brace pair, respecting nested braces."""
        pattern = re.compile(r'\{\s*(?:fixed|include|exclude)\b', re.IGNORECASE)
        m = pattern.search(text)
        if not m:
            return text
        start = m.start()
        # Walk forward from the '{' to find matching '}'
        depth = 0
        i = start
        while i < len(text):
            if text[i] == '{':
                depth += 1
            elif text[i] == '}':
                depth -= 1
                if depth == 0:
                    break
            i += 1
        if depth != 0:
            return text  # unbalanced — leave as-is
        inner = text[start + 1:i]  # everything between outer { and }
        # Recursively translate any nested LODs inside the inner body first
        inner = _find_and_replace_lod(inner)
        converted = _convert_lod_body(inner)
        return text[:start] + converted + text[i + 1:]

    # Repeatedly translate LODs (from innermost out via recursion)
    prev = None
    max_iter = 20
    while dax != prev and max_iter > 0:
        prev = dax
        dax = _find_and_replace_lod(dax)
        max_iter -= 1
    return dax


def _split_args(s: str) -> list:
    """Split function arguments respecting nested parentheses."""
    args = []
    current = ""
    depth = 0
    for ch in s:
        if ch == '(':
            depth += 1
        elif ch == ')':
            depth -= 1
        if ch == ',' and depth == 0:
            args.append(current)
            current = ""
        else:
            current += ch
    args.append(current)
    return args


def _fix_datediff(dax: str) -> str:
    """Fix ALL DATEDIFF calls from Tableau DATEDIFF(interval, start, end) to DAX DATEDIFF(start, end, INTERVAL)."""
    _INTERVALS = {
        "day": "DAY", "month": "MONTH", "year": "YEAR", "quarter": "QUARTER",
        "week": "WEEK", "hour": "HOUR", "minute": "MINUTE", "second": "SECOND",
    }
    pos = 0
    max_iter = 20
    while max_iter > 0:
        m = re.search(r'\bDATEDIFF\s*\(', dax[pos:], re.IGNORECASE)
        if not m:
            break
        max_iter -= 1
        abs_start = pos + m.start()
        paren_pos = pos + m.end() - 1  # position of '('
        depth = 1
        i = paren_pos + 1
        while i < len(dax) and depth > 0:
            if dax[i] == '(':
                depth += 1
            elif dax[i] == ')':
                depth -= 1
            i += 1
        inner = dax[paren_pos + 1:i - 1]
        args = _split_args(inner)
        if len(args) >= 3:
            first = args[0].strip().strip("'\"")
            if first.lower() in _INTERVALS:
                interval = _INTERVALS[first.lower()]
                new_call = f"DATEDIFF({args[1].strip()}, {args[2].strip()}, {interval})"
                dax = dax[:abs_start] + new_call + dax[i:]
                pos = abs_start + len(new_call)
                continue
        pos = i  # skip past already-fixed or unrecognized DATEDIFF
    return dax


def _fix_dateadd_scalar(dax: str) -> str:
    """Fix Tableau DATEADD("interval", number, date) to DAX scalar date arithmetic.
    Tableau DATEADD is scalar (adds N intervals to a date).
    DAX DATEADD is a time-intelligence table function — completely different.
    Translate to: date + number (for days), EDATE(date, number) (for months),
    DATE(YEAR(date)+n, MONTH(date), DAY(date)) (for years)."""
    max_iter = 20
    while max_iter > 0:
        # Only match DATEADD that starts with a string literal interval arg (single or double quoted)
        m = re.search(r'\bDATEADD\s*\(\s*["\']', dax, re.IGNORECASE)
        if not m:
            break
        max_iter -= 1
        paren_start = dax.index("(", m.start())
        content, end = _extract_paren_arg(dax, paren_start)
        if content is None:
            break
        args = _split_args(content)
        if len(args) < 3:
            break
        interval = args[0].strip().strip('"\'').lower()
        number = args[1].strip()
        date_expr = args[2].strip()
        if interval == "day":
            replacement = f"({date_expr} + {number})"
        elif interval in ("month", "quarter"):
            mult = "3 * " if interval == "quarter" else ""
            replacement = f"EDATE({date_expr}, {mult}{number})"
        elif interval == "year":
            replacement = f"DATE(YEAR({date_expr}) + {number}, MONTH({date_expr}), DAY({date_expr}))"
        elif interval == "week":
            replacement = f"({date_expr} + 7 * {number})"
        else:
            replacement = f"({date_expr} + {number})"
        dax = dax[:m.start()] + replacement + dax[end:]
    return dax


def _has_aggregation(formula: str) -> bool:
    """Check if a formula uses explicit aggregation functions."""
    upper = formula.upper()
    agg_patterns = [r'\bSUM\s*\(', r'\bAVG\s*\(', r'\bAVERAGE\s*\(',
                    r'\bMIN\s*\(', r'\bMAX\s*\(', r'\bCOUNT\s*\(',
                    r'\bCOUNTD\s*\(', r'\bMEDIAN\s*\(', r'\bDISTINCTCOUNT\s*\(',
                    r'\bSELECTEDVALUE\s*\(', r'\bCALCULATE\s*\(',
                    r'\bSUMX\s*\(', r'\bAVERAGEX\s*\(', r'\bCOUNTROWS\s*\(',
                    r'\bATTR\s*\(', r'\bRUNNING_SUM\s*\(', r'\bRUNNING_AVG\s*\(',
                    r'\bWINDOW_SUM\s*\(', r'\bWINDOW_AVG\s*\(', r'\bTOTAL\s*\(',
                    r'\bLOOKUP\s*\(', r'\bRANK\s*\(', r'\bRANKX\s*\(']
    return any(re.search(p, upper) for p in agg_patterns)


def _references_params(formula: str) -> bool:
    """Check if formula references Tableau parameters."""
    return '[Parameters].' in formula


def _determine_pbi_role(formula: str, tableau_role: str = "") -> str:
    """Determine if a Tableau calc should be a PBI calculated column or measure.
    Uses the Tableau role attribute as primary signal, formula analysis as fallback.
    Returns 'calculated_column' or 'measure'."""
    # Tableau explicitly marks the role — trust it
    if tableau_role == "measure":
        return "measure"
    if tableau_role == "dimension":
        # LOD expressions ({FIXED}, {INCLUDE}, {EXCLUDE}) are row-level in Tableau
        # even though they translate to CALCULATE(AGG(...), ALLEXCEPT(...)).
        # Keep them as calculated columns since CALCULATE works at row level.
        if re.search(r'\{(?:fixed|include|exclude)\b', formula, re.IGNORECASE):
            return "calculated_column"
        # Dimensions that contain aggregations must still be measures in PBI
        if _has_aggregation(formula):
            return "measure"
        return "calculated_column"
    # Fallback: analyse formula
    if re.search(r'\{fixed\b', formula, re.IGNORECASE):
        return "calculated_column"
    if _references_params(formula):
        return "measure"
    if _has_aggregation(formula):
        return "measure"
    return "calculated_column"


def _fix_logical_operators(dax: str) -> str:
    """Replace Tableau AND/OR infix operators with DAX && / || operators.
    Protects bracket content and string literals from replacement."""
    # Protect bracket content:  [Demand AND Supply] should not be touched
    brackets = []
    def _save_bracket(m):
        brackets.append(m.group(0))
        return f"__BKT{len(brackets)-1}__"
    protected = re.sub(r'\[[^\]]*\]', _save_bracket, dax)
    # Protect string literals
    strings = []
    def _save_string(m):
        strings.append(m.group(0))
        return f"__STR{len(strings)-1}__"
    protected = re.sub(r'"[^"]*"', _save_string, protected)
    # Replace AND/OR infix (not followed by open-paren, which is the function form)
    protected = re.sub(r'\bAND\b(?!\s*\()', '&&', protected, flags=re.IGNORECASE)
    protected = re.sub(r'\bOR\b(?!\s*\()', '||', protected, flags=re.IGNORECASE)
    # Restore strings then brackets
    for i, s in enumerate(strings):
        protected = protected.replace(f"__STR{i}__", s)
    for i, b in enumerate(brackets):
        protected = protected.replace(f"__BKT{i}__", b)
    return protected


def _split_calculate_filters(dax: str) -> str:
    """In CALCULATE(expr, filter1 && filter2), split && joined filters
    into separate comma-delimited CALCULATE arguments.
    CALCULATE(expr, f1 && f2) → CALCULATE(expr, f1, f2)
    Does NOT split || conditions (those must remain as single boolean filter)."""
    max_iter = 50
    start_pos = 0
    while max_iter > 0:
        max_iter -= 1
        m = re.search(r'\bCALCULATE\s*\(', dax[start_pos:], re.IGNORECASE)
        if not m:
            break
        calc_start = start_pos + m.start()
        paren_pos = start_pos + m.end() - 1  # position of '('
        content, end_pos = _extract_paren_arg(dax, paren_pos)
        if content is None:
            start_pos = paren_pos + 1
            continue
        args = _split_args(content)
        if len(args) < 2:
            start_pos = end_pos
            continue
        measure_expr = args[0]
        filter_args = args[1:]
        changed = False
        new_filter_args = []
        for farg in filter_args:
            fstrip = farg.strip()
            # Only split on && if no || present (pure AND conditions)
            if '&&' in fstrip and '||' not in fstrip:
                # Split on top-level && (not inside nested parens)
                sub_parts = []
                current = ""
                depth = 0
                i = 0
                while i < len(fstrip):
                    if fstrip[i] == '(':
                        depth += 1
                        current += fstrip[i]
                    elif fstrip[i] == ')':
                        depth -= 1
                        current += fstrip[i]
                    elif fstrip[i:i+2] == '&&' and depth == 0:
                        sub_parts.append(current.strip())
                        current = ""
                        i += 2
                        continue
                    else:
                        current += fstrip[i]
                    i += 1
                if current.strip():
                    sub_parts.append(current.strip())
                if len(sub_parts) > 1:
                    new_filter_args.extend(sub_parts)
                    changed = True
                else:
                    new_filter_args.append(fstrip)
            else:
                new_filter_args.append(fstrip)
        if changed:
            new_content = measure_expr + ", " + ", ".join(new_filter_args)
            dax = dax[:paren_pos] + "(" + new_content + ")" + dax[end_pos:]
            start_pos = paren_pos + 1
        else:
            start_pos = end_pos
    return dax


def _fix_calculate_in_boolean_filter(dax: str) -> str:
    """Fix CALCULATE inside a boolean filter expression of another CALCULATE.
    Pattern: CALCULATE(..., 'Table'[Col] = CALCULATE(...)) is invalid in DAX.
    Fix: Extract the nested CALCULATE into a VAR.
    Result: VAR _v1 = CALCULATE(...) RETURN CALCULATE(..., 'Table'[Col] = _v1)
    Also flattens CALCULATE(CALCULATE(inner, f1), f2) → CALCULATE(inner, f1, f2)."""
    # Step 1: Flatten CALCULATE(CALCULATE(inner, f1), f2) → CALCULATE(inner, f1, f2)
    # This must run first so nested CALCULATEs are simplified before VAR extraction
    max_iter = 20
    while max_iter > 0:
        max_iter -= 1
        m = re.search(r'\bCALCULATE\s*\(\s*CALCULATE\s*\(', dax, re.IGNORECASE)
        if not m:
            break
        outer_paren = dax.index('(', m.start())
        outer_content, outer_end = _extract_paren_arg(dax, outer_paren)
        if outer_content is None:
            break
        outer_args = _split_args(outer_content)
        inner_call = outer_args[0].strip()
        outer_filters = [a.strip() for a in outer_args[1:]] if len(outer_args) > 1 else []
        inner_m = re.match(r'CALCULATE\s*\(', inner_call, re.IGNORECASE)
        if not inner_m:
            break
        inner_paren = inner_call.index('(')
        inner_content, inner_end = _extract_paren_arg(inner_call, inner_paren)
        if inner_content is None:
            break
        inner_args = _split_args(inner_content)
        all_args = inner_args + outer_filters
        dax = dax[:m.start()] + "CALCULATE(" + ", ".join(a.strip() for a in all_args) + ")" + dax[outer_end:]

    # Step 2: Extract CALCULATE from boolean filter expressions into VARs
    # Search all CALCULATE calls in the expression for filter args containing
    # 'Table'[Col] op CALCULATE(...)
    var_counter = [0]
    max_iter = 20
    search_from = 0
    while max_iter > 0:
        max_iter -= 1
        m = re.search(r'\bCALCULATE\s*\(', dax[search_from:], re.IGNORECASE)
        if not m:
            break
        calc_abs_start = search_from + m.start()
        paren_pos = search_from + m.end() - 1
        content, end_pos = _extract_paren_arg(dax, paren_pos)
        if content is None:
            search_from = paren_pos + 1
            continue
        args = _split_args(content)
        if len(args) < 2:
            search_from = end_pos
            continue
        found_nested = False
        new_vars = []
        new_args = [args[0]]
        for farg in args[1:]:
            fstrip = farg.strip()
            nested_m = re.search(
                r"((?:'[^']*'|\w+)\[[^\]]+\]\s*[<>=!]+\s*)CALCULATE\s*\(",
                fstrip, re.IGNORECASE)
            if nested_m:
                calc_start_in_farg = nested_m.end() - 1
                calc_content, calc_end = _extract_paren_arg(fstrip, calc_start_in_farg)
                if calc_content is not None:
                    var_counter[0] += 1
                    var_name = f"_fcv{var_counter[0]}"
                    calc_expr = f"CALCULATE({calc_content})"
                    new_vars.append(f"VAR {var_name} = {calc_expr}")
                    new_farg = nested_m.group(1) + var_name + fstrip[calc_end:]
                    new_args.append(new_farg)
                    found_nested = True
                    continue
            new_args.append(fstrip)
        if found_nested:
            var_block = " ".join(new_vars)
            new_calc = "CALCULATE(" + ", ".join(new_args) + ")"
            dax = dax[:calc_abs_start] + var_block + " RETURN " + new_calc + dax[end_pos:]
            search_from = calc_abs_start + len(var_block) + len(" RETURN ") + len(new_calc)
        else:
            search_from = end_pos
    return dax


def _fix_avg_of_expression(dax: str, table_name: str) -> str:
    """Fix AVERAGE('Table'[Col1]/'Table'[Col2]) → AVERAGEX('Table', 'Table'[Col1]/'Table'[Col2]).
    DAX AVERAGE() can only take a single column, not an expression.
    Same applies to SUM, MIN, MAX, COUNT of expressions (not just columns)."""
    tbl = f"'{table_name}'"
    for func, func_x in [("AVERAGE", "AVERAGEX"), ("SUM", "SUMX"),
                          ("MIN", "MINX"), ("MAX", "MAXX")]:
        pattern = rf'\b{func}\s*\('
        start_pos = 0
        max_iter = 30
        while max_iter > 0:
            max_iter -= 1
            m = re.search(pattern, dax[start_pos:], re.IGNORECASE)
            if not m:
                break
            abs_start = start_pos + m.start()
            paren_pos = start_pos + m.end() - 1
            content, end_pos = _extract_paren_arg(dax, paren_pos)
            if content is None:
                start_pos = paren_pos + 1
                continue
            inner = content.strip()
            # Check if inner is NOT a simple column ref (Table[Col]) — it contains operators
            # A simple column ref: 'Table'[Col] or Table[Col] — no operators
            is_simple = bool(re.match(
                r"^(?:'[^']*'|\w+)\[[^\]]+\]$", inner))
            if not is_simple and re.search(r"(?:'[^']*'|\w+)\[[^\]]+\]", inner):
                # It's an expression with column refs — convert to iterating form
                dax = dax[:abs_start] + f"{func_x}({tbl}, {inner})" + dax[end_pos:]
                start_pos = abs_start + len(func_x) + 1
            else:
                start_pos = end_pos
    return dax


def _fix_agg_of_literal(dax: str) -> str:
    """Fix aggregation of literal values: AVERAGE(0) → 0, MIN(1) → 1, MAX(1) → 1.
    DAX aggregate functions on literals are invalid; just use the literal."""
    for func in ("SUM", "AVERAGE", "MIN", "MAX", "COUNT"):
        pattern = rf'\b{func}\s*\(\s*(-?[\d.]+)\s*\)'
        dax = re.sub(pattern, r'\1', dax, flags=re.IGNORECASE)
    return dax


def _fix_double_aggregation(dax: str) -> str:
    """Fix invalid DAX double-aggregation patterns like SUM(DISTINCTCOUNT(...)).
    DAX does not allow nesting aggregate functions — simplify to the inner one.
    Also converts AGG(IF(cond, val, NULL)) → CALCULATE(AGG(val), cond) since
    DAX aggregate functions (SUM, DISTINCTCOUNT) cannot take IF expressions."""
    # 1. Nested aggregates: SUM(DISTINCTCOUNT(x)) → DISTINCTCOUNT(x)
    outer_aggs = ("SUM", "AVERAGE", "MIN", "MAX", "COUNT", "COUNTA")
    inner_aggs = ("SUM", "AVERAGE", "MIN", "MAX", "COUNT", "COUNTA",
                  "DISTINCTCOUNT", "COUNTROWS")
    for outer in outer_aggs:
        for inner in inner_aggs:
            pattern = rf'\b{outer}\s*\(\s*{inner}\s*\('
            while re.search(pattern, dax, re.IGNORECASE):
                m = re.search(pattern, dax, re.IGNORECASE)
                if not m:
                    break
                outer_paren = dax.index("(", m.start())
                content, end = _extract_paren_arg(dax, outer_paren)
                if content is None:
                    break
                dax = dax[:m.start()] + content.strip() + dax[end:]

    # 2. AGG(IF(cond, val, NULL/BLANK())) → CALCULATE(AGG(val), cond)
    #    This handles SUM(IF(...)), DISTINCTCOUNT(IF(...)), etc.
    for agg_fn in ("SUM", "AVERAGE", "DISTINCTCOUNT", "MIN", "MAX",
                   "COUNT", "COUNTA", "COUNTROWS"):
        search_from = 0
        max_iter = 30
        while max_iter > 0:
            max_iter -= 1
            m = re.search(rf'\b{agg_fn}\s*\(\s*IF\s*\(', dax[search_from:], re.IGNORECASE)
            if not m:
                break
            abs_start = search_from + m.start()
            # Find the outer AGG( paren
            agg_paren_start = dax.index("(", abs_start)
            agg_content, agg_end = _extract_paren_arg(dax, agg_paren_start)
            if agg_content is None:
                search_from = agg_paren_start + 1
                continue
            # agg_content is "IF(cond, val, NULL)" — extract the IF args
            if_paren = agg_content.index("(")
            if_content, if_end = _extract_paren_arg(agg_content, if_paren)
            if if_content is None:
                search_from = agg_end
                continue
            args = _split_args(if_content)
            if len(args) < 2:
                search_from = agg_end
                continue
            # Only transform conditional aggregation: AGG(IF(cond, val)) or AGG(IF(cond, val, BLANK()))
            # Do NOT transform when 3rd arg is a real value (e.g. IFNULL patterns)
            if len(args) >= 3:
                third = args[2].strip().upper()
                if third not in ("BLANK()", ""):
                    search_from = agg_end
                    continue
            cond = args[0].strip()
            value_expr = args[1].strip()
            repl = f"CALCULATE({agg_fn}({value_expr}), {cond})"
            dax = dax[:abs_start] + repl + dax[agg_end:]
            search_from = abs_start + len(repl)
    return dax


def _fix_commented_calcs(dax: str) -> str:
    """Fix fully-commented-out expressions, leftover Tableau syntax remnants,
    and /* TODO */ prefixes from table calc translations."""
    stripped = dax.strip()
    # Remove /* TODO: Tableau table-calc approximation */ prefix
    stripped = re.sub(r'/\*\s*TODO:?\s*Tableau table-calc approximation\s*\*/\s*',
                      '', stripped).strip()
    # If entirely a comment, replace with a sensible default
    if stripped.startswith("//") and "\n" not in stripped:
        if "TODAY" in stripped.upper():
            return "TODAY()"
        if "MAKEDATE" in stripped.upper():
            return "TODAY()"
        return "BLANK()"

    # Clean up `WHEN "X" THEN Y)` remnants not caught by CASE translation
    stripped = re.sub(
        r'\s*WHEN\s+"[^"]*"\s+THEN\s+BLANK\(\)\s*\)', ')', stripped)
    stripped = re.sub(
        r'\s*WHEN\s+"[^"]*"\s+THEN\s+\w+\s*\)', ')', stripped)

    # Clean up stray ELSE after SWITCH/IF — Tableau remnant
    # Pattern: `...) ELSE "value")` → `..., "value")`
    stripped = re.sub(
        r'\)\s+ELSE\s+("[^"]*"|\'[^\']*\'|\S+)\s*\)', r', \1)', stripped)

    # Fix inline Tableau `IF cond THEN val` (without parens) inside SWITCH args etc.
    # Pattern: `IF expr THEN "literal"` → `IF(expr, "literal")`
    max_iter = 20
    while max_iter > 0:
        m = re.search(
            r'\bIF\s+(.*?)\s+THEN\s+((?:"[^"]*"|\'[^\']*\'|\S+?))\s*(?=[,\)])',
            stripped, re.IGNORECASE)
        if not m:
            break
        max_iter -= 1
        cond = m.group(1).strip()
        val = m.group(2).strip()
        stripped = stripped[:m.start()] + f'IF({cond}, {val})' + stripped[m.end():]

    # Fix `IF cond THEN expr END` — Tableau block IF not yet converted
    max_iter = 20
    while max_iter > 0:
        m = re.search(
            r'\bIF\s+((?:(?!\bIF\b).)*?)\s+THEN\s+((?:(?!\bIF\b).)*?)\s+END\b',
            stripped, re.IGNORECASE | re.DOTALL)
        if not m:
            break
        max_iter -= 1
        cond = m.group(1).strip()
        val = m.group(2).strip()
        stripped = stripped[:m.start()] + f'IF({cond}, {val}, BLANK())' + stripped[m.end():]

    return stripped if stripped else dax


def _strip_agg_around_measures(dax: str, measure_names: set) -> str:
    """Clean up measure references in DAX formulas.
    1. Strip VALUE() wrappers around measure refs (VALUE is for text→number, not measures)
    2. Strip SUM/AVG/MIN/MAX/COUNT wrappers around measure refs (measures self-aggregate)
    3. Un-qualify table-qualified measure refs: 'Table'[Measure] → [Measure]
       (DAX requires measures to be referenced without table qualifier)"""
    for mname in measure_names:
        esc = re.escape(mname)
        # 1. VALUE('Table'[Measure]) → [Measure]  and  VALUE([Measure]) → [Measure]
        dax = re.sub(
            rf'\bVALUE\s*\(\s*(?:\'[^\']*\'|\w+)\[{esc}\]\s*\)',
            f"[{mname}]", dax, flags=re.IGNORECASE)
        dax = re.sub(
            rf'\bVALUE\s*\(\s*\[{esc}\]\s*\)',
            f"[{mname}]", dax, flags=re.IGNORECASE)
        # 2. SUM/AVERAGE/MIN/MAX/COUNT wrappers
        for func in ("SUM", "AVERAGE", "MIN", "MAX", "COUNT"):
            dax = re.sub(
                rf'\b{func}\s*\(\s*(?:\'[^\']*\'|\w+)\[{esc}\]\s*\)',
                f"[{mname}]", dax, flags=re.IGNORECASE)
            dax = re.sub(
                rf'\b{func}\s*\(\s*\[{esc}\]\s*\)',
                f"[{mname}]", dax, flags=re.IGNORECASE)
        # 3. Remaining table-qualified refs: 'Table'[Measure] or Table[Measure] → [Measure]
        dax = re.sub(
            rf"(?:'[^']*'|\b\w+)\[{esc}\]",
            f"[{mname}]", dax, flags=re.IGNORECASE)
    return dax


def _strip_agg_wrapping_measure_exprs(dax: str, measure_names: set) -> str:
    """Strip AGG() wrappers around expressions that only reference measures.
    E.g., SUM(IF(ISBLANK([MeasureA]), 0, [MeasureA])) → IF(ISBLANK([MeasureA]), 0, [MeasureA])
    Measures self-aggregate so wrapping in SUM/AVG is redundant and often invalid."""
    for func in ("SUM", "AVERAGE", "MIN", "MAX", "COUNT"):
        start = 0
        max_iter = 30
        while max_iter > 0:
            max_iter -= 1
            m = re.search(rf'\b{func}\s*\(', dax[start:], re.IGNORECASE)
            if not m:
                break
            abs_start = start + m.start()
            paren_pos = start + m.end() - 1
            content, end_pos = _extract_paren_arg(dax, paren_pos)
            if content is None:
                start = paren_pos + 1
                continue
            inner = content.strip()
            # Check if inner is a simple column ref — already handled by _strip_agg_around_measures
            if re.match(r"^(?:'[^']*'|\w+)\[[^\]]+\]$", inner) or re.match(r"^\[[^\]]+\]$", inner):
                start = end_pos
                continue
            # Extract all [field] references from the inner expression
            all_refs = set(re.findall(r'\[([^\]]+)\]', inner))
            # If ALL field refs are known measures, strip the AGG wrapper
            if all_refs and all_refs.issubset(measure_names):
                dax = dax[:abs_start] + inner + dax[end_pos:]
                start = abs_start + len(inner)
            else:
                start = end_pos
    return dax


def _ensure_measure_aggregation(dax: str, table_name: str,
                                measure_names: set = None) -> str:
    """For measure formulas with bare column refs and no aggregation, wrap in SUMX.
    Skip wrapping if the reference is to a known measure."""
    stripped = dax.strip()
    if measure_names is None:
        measure_names = set()

    # Helper: extract field name from a Table[Field] reference
    def _extract_field(ref: str) -> str:
        m = re.match(r"^(?:'[^']*'|\w+)\[([^\]]+)\]$", ref.strip())
        return m.group(1) if m else ""

    # Simple column reference: Table[Col] → SUM(Table[Col])
    if re.match(r"^(?:'[^']*'|\w+)\[[^\]]+\]$", stripped):
        field = _extract_field(stripped)
        if field in measure_names:
            return stripped  # Already a measure – do not wrap
        return f"SUM({stripped})"
    # Check for bare column refs (Table[Col] pattern) without aggregation
    has_bare_col = bool(re.search(r"(?:'[^']*'|\w+)\[[^\]]+\]", stripped))
    if has_bare_col and not _has_aggregation(stripped):
        # Check if ALL table-qualified refs are measures – if so, skip wrapping
        refs = re.findall(r"(?:'[^']*'|\w+)\[([^\]]+)\]", stripped)
        if refs and all(r in measure_names for r in refs):
            return stripped
        tbl_ref = f"'{table_name}'"
        return f"SUMX({tbl_ref}, {stripped})"
    return dax


def translate_formula(formula: str, table_name: str, column_lookup: dict = None,
                      calc_name_map: dict = None, param_map: dict = None,
                      ds_col_to_table: dict = None,
                      field_param_names: set = None,
                      caption_to_colname: dict = None) -> str:
    if not formula or not formula.strip():
        return '""'
    dax = formula.strip()
    # Strip ALL Tableau inline comments (// to end-of-line) for cleaner processing
    # This must happen early so comments between THEN/ELSE/END don't break parsing
    dax = re.sub(r'//[^\n]*', '', dax).strip()
    # Collapse multiple whitespace/newlines into single spaces
    dax = re.sub(r'\s+', ' ', dax).strip()
    # Normalize Tableau comparison operators to DAX equivalents
    dax = dax.replace('==', '=')
    dax = dax.replace('!=', '<>')
    if _is_literal(dax):
        return _translate_literal(dax)
    # Step 0: Resolve internal calc names
    if calc_name_map:
        dax = _resolve_calc_names(dax, calc_name_map)
    # Step 1: Replace parameter & cross-DS refs with placeholders
    placeholders = {}
    if param_map or ds_col_to_table:
        dax, placeholders = _resolve_dotted_refs(
            dax, param_map or {}, ds_col_to_table or {},
            field_param_names=field_param_names)
    # Step 2: Translate LOD expressions
    dax = _translate_lod(dax, table_name)
    # Step 3: Structure translation
    # CASE must be translated before IF because CASE...WHEN...END nested
    # inside IF...THEN...END would have its END consumed by the IF parser
    dax = _translate_case(dax)
    dax = _translate_if_then_else(dax)
    dax = _remap_functions(dax)
    # Replace Tableau logical operators AND/OR with DAX && / ||
    dax = _fix_logical_operators(dax)
    # Replace Tableau NULL with DAX BLANK()
    dax = re.sub(r'\bNULL\b', 'BLANK()', dax)
    # Step 4: Field qualification
    if column_lookup:
        dax = _qualify_fields(dax, table_name, column_lookup)
    else:
        dax = _qualify_bare_fields(dax, table_name)
    # Step 5: Post-processing
    dax = _fix_datediff(dax)
    dax = _fix_dateadd_scalar(dax)
    dax = _cleanup(dax, table_name)
    # Step 5b: Resolve caption-based column references back to actual column names.
    # Tableau formulas may use captions (e.g. [Sales Amount]) but PBI model
    # columns use original metadata names (e.g. SalesAmount).
    if caption_to_colname:
        for cap, real_name in caption_to_colname.items():
            dax = dax.replace(f"[{cap}]", f"[{real_name}]")
    # Step 6: Restore placeholders
    for token, value in placeholders.items():
        dax = dax.replace(token, value)
    return dax


def _is_literal(s: str) -> bool:
    s = s.strip()
    try:
        float(s)
        return True
    except ValueError:
        pass
    if s.lower() in ("true", "false"):
        return True
    if (s.startswith('"') and s.endswith('"')) or (s.startswith("'") and s.endswith("'")):
        return True
    return False


def _translate_literal(s: str) -> str:
    s = s.strip()
    if s.lower() == "true":
        return "TRUE()"
    if s.lower() == "false":
        return "FALSE()"
    if s.startswith("'") and s.endswith("'"):
        return '"' + s[1:-1] + '"'
    return s


def _translate_if_then_else(dax: str) -> str:
    text = " ".join(dax.split())
    max_iter = 20
    while re.search(r'\bIF\b.*?\bTHEN\b.*?\bEND\b', text, re.IGNORECASE | re.DOTALL) and max_iter > 0:
        max_iter -= 1
        text = _replace_one_if_block(text)
    return text


def _replace_one_if_block(text: str) -> str:
    # Match Tableau IF...END blocks — \s* allows IF([field]) with no space after IF
    # Nested DAX IF() function calls are allowed inside body via negative lookahead
    m = re.search(r'\bIF\b\s*((?:(?!\bIF\b(?!\s*\()).)*)?\bEND\b', text, re.IGNORECASE | re.DOTALL)
    if not m:
        return text
    body = m.group(1)
    parts = re.split(r'\bELSEIF\b', body, flags=re.IGNORECASE)
    branches = []
    else_val = None
    for part in parts:
        else_match = re.split(r'\bELSE\b', part, maxsplit=1, flags=re.IGNORECASE)
        if len(else_match) == 2:
            branch_part = else_match[0]
            else_val = else_match[1].strip()
        else:
            branch_part = part
        then_match = re.split(r'\bTHEN\b', branch_part, maxsplit=1, flags=re.IGNORECASE)
        if len(then_match) == 2:
            branches.append((then_match[0].strip(), then_match[1].strip()))
    result = _build_nested_if(branches, else_val)
    return text[:m.start()] + result + text[m.end():]


def _build_nested_if(branches: list, else_val: str = None) -> str:
    if not branches:
        return else_val or 'BLANK()'
    cond, then_val = branches[0]
    rest = _build_nested_if(branches[1:], else_val)
    return f"IF({cond}, {then_val}, {rest})"


def _translate_case(dax: str) -> str:
    """Translate Tableau CASE...WHEN...THEN...ELSE...END to DAX SWITCH().
    Handles ELSE clause and translates NULL to BLANK()."""
    max_iter = 20
    while max_iter > 0:
        # Find innermost CASE...END (no nested CASE inside)
        m = re.search(r'\bCASE\b\s+((?:(?!\bCASE\b).)*)?\bEND\b', dax, re.IGNORECASE | re.DOTALL)
        if not m:
            break
        max_iter -= 1
        body = m.group(1).strip()
        # Split off ELSE clause (last one)
        else_val = None
        else_match = re.split(r'\bELSE\b(?!IF\b)', body, flags=re.IGNORECASE)
        if len(else_match) > 1:
            body = else_match[0].strip()
            else_val = else_match[-1].strip()
            if else_val.upper() == "NULL":
                else_val = "BLANK()"
        # Split WHEN...THEN pairs
        first_when = re.split(r'\bWHEN\b', body, maxsplit=1, flags=re.IGNORECASE)
        if len(first_when) < 2:
            break
        switch_expr = first_when[0].strip()
        when_parts = re.split(r'\bWHEN\b', first_when[1], flags=re.IGNORECASE)
        pairs = []
        for wp in when_parts:
            then_split = re.split(r'\bTHEN\b', wp, maxsplit=1, flags=re.IGNORECASE)
            if len(then_split) == 2:
                val = then_split[1].strip()
                if val.upper() == "NULL":
                    val = "BLANK()"
                pairs.append(f"{then_split[0].strip()}, {val}")
        args = ", ".join(pairs)
        if else_val:
            replacement = f"SWITCH({switch_expr}, {args}, {else_val})"
        else:
            replacement = f"SWITCH({switch_expr}, {args})"
        dax = dax[:m.start()] + replacement + dax[m.end():]
    return dax


def _remap_functions(dax: str) -> str:
    # Protect field references [name] from function name replacement
    # (e.g. [Main Date: Month (Display)] has "Month (" inside brackets)
    _bracket_phs = {}
    _bctr = [0]
    def _protect_brackets(m):
        tok = f"__BR{_bctr[0]}__"
        _bctr[0] += 1
        _bracket_phs[tok] = m.group(0)
        return tok
    dax = re.sub(r'\[[^\]]+\]', _protect_brackets, dax)

    for tab_name, dax_name in _FUNC_MAP.items():
        pattern = re.compile(r'\b' + re.escape(tab_name) + r'\s*\(', re.IGNORECASE)
        dax = pattern.sub(dax_name + "(", dax)
    # ZN(...) → IF(ISBLANK(...), 0, ...) — handle all occurrences with paren-aware matching
    dax = _replace_zn_all(dax)
    # IFNULL(x, y) → IF(ISBLANK(x), y, x) — handle all occurrences
    dax = _replace_ifnull_all(dax)

    # Restore bracket references
    for tok, orig in _bracket_phs.items():
        dax = dax.replace(tok, orig)
    return dax


def _extract_paren_arg(text: str, open_pos: int) -> tuple:
    """Extract the full content inside parentheses starting at open_pos.
    Returns (content_string, end_pos_after_closing_paren) or (None, -1) on failure."""
    if open_pos >= len(text) or text[open_pos] != '(':
        return None, -1
    depth = 0
    i = open_pos
    while i < len(text):
        if text[i] == '(':
            depth += 1
        elif text[i] == ')':
            depth -= 1
            if depth == 0:
                return text[open_pos + 1:i], i + 1
        i += 1
    return None, -1


def _replace_zn_all(dax: str) -> str:
    """Replace all ZN(arg) with IF(ISBLANK(arg), 0, arg), paren-aware."""
    max_iter = 50
    while max_iter > 0:
        m = re.search(r'\bZN\s*\(', dax, re.IGNORECASE)
        if not m:
            break
        # Find the opening paren
        paren_start = dax.index('(', m.start())
        arg, end = _extract_paren_arg(dax, paren_start)
        if arg is None:
            break
        arg = arg.strip()
        replacement = f"IF(ISBLANK({arg}), 0, {arg})"
        dax = dax[:m.start()] + replacement + dax[end:]
        max_iter -= 1
    return dax


def _replace_ifnull_all(dax: str) -> str:
    """Replace all IFNULL(x, y) with IF(ISBLANK(x), y, x), paren-aware."""
    max_iter = 50
    while max_iter > 0:
        m = re.search(r'\bIFNULL\s*\(', dax, re.IGNORECASE)
        if not m:
            break
        paren_start = dax.index('(', m.start())
        content, end = _extract_paren_arg(dax, paren_start)
        if content is None:
            break
        args = _split_args(content)
        if len(args) >= 2:
            x = args[0].strip()
            y = args[1].strip()
            replacement = f"IF(ISBLANK({x}), {y}, {x})"
        else:
            replacement = content
        dax = dax[:m.start()] + replacement + dax[end:]
        max_iter -= 1
    return dax


def _qualify_fields(dax: str, table_name: str, col_lookup: dict) -> str:
    def _replace_ref(m):
        field = m.group(1)
        if "].[" in m.group(0):
            return m.group(0)
        # Skip if preceded by a table-qualifying quote: 'TableName'[col]
        start = m.start()
        if start >= 1 and dax[start - 1] == "'":
            return m.group(0)
        # Skip placeholders (__PHx__)
        if field.startswith("__PH") and field.endswith("__"):
            return m.group(0)
        tbl = col_lookup.get(field, table_name)
        return f"'{tbl}'[{field}]"
    return re.sub(r'(?<!\w)(?<!\]\.)\[([^\]]+)\]', _replace_ref, dax)


def _qualify_bare_fields(dax: str, table_name: str) -> str:
    def _replace_ref(m):
        field = m.group(1)
        if "].[" in m.group(0):
            return m.group(0)
        start = m.start()
        if start >= 1 and dax[start - 1] == "'":
            return m.group(0)
        if field.startswith("__PH") and field.endswith("__"):
            return m.group(0)
        return f"'{table_name}'[{field}]"
    return re.sub(r'(?<!\w)(?<!\]\.)\[([^\]]+)\]', _replace_ref, dax)


def _fix_single_arg_format(dax: str) -> str:
    """Fix FORMAT(x) calls that are missing the format string.
    Tableau STR(x) becomes FORMAT(x) but DAX needs FORMAT(x, formatString)."""
    result = []
    pos = 0
    while pos < len(dax):
        m = re.search(r'\bFORMAT\s*\(', dax[pos:], re.IGNORECASE)
        if not m:
            result.append(dax[pos:])
            break
        abs_start = pos + m.start()
        result.append(dax[pos:abs_start])
        paren_start = abs_start + m.group().index('(')
        content, end = _extract_paren_arg(dax, paren_start)
        if content is None:
            result.append(dax[abs_start:])
            break
        args = _split_args(content)
        if len(args) == 1:
            result.append(f'FORMAT({args[0].strip()}, "General")')
        else:
            result.append(dax[abs_start:end])
        pos = end
    return "".join(result)


def _cleanup(dax: str, table_name: str = "Extract") -> str:
    # Convert Tableau single-quoted string literals to double-quoted DAX strings
    # but skip table references like 'TableName'[col] (followed by [)
    # and DAX function table args like ALL('Table'), ALLEXCEPT('Table', ...)
    dax = re.sub(r"(?<!\w)'([^']*?)'(?=\[)", r"'\1'", dax)  # preserve table refs (no-op but explicit)
    # Only convert single-to-double for actual string literals:
    # preceded by = , ( or space AND not followed by [ ) , or used as table ref inside ALL/ALLEXCEPT/etc.
    def _sq_to_dq(m):
        before_char = dax[m.start() - 1] if m.start() > 0 else ''
        after_char = dax[m.end()] if m.end() < len(dax) else ''
        content = m.group(1)
        # If followed by [ it's a table ref — preserve
        if after_char == '[':
            return m.group(0)
        # If inside a function call like ALL('X'), ALLEXCEPT('X',...) — preserve
        if after_char in (')', ',') and before_char == '(':
            return m.group(0)
        # If content looks like a table name (used elsewhere as 'X'[) — preserve
        if re.search(r"'" + re.escape(content) + r"'\[", dax):
            return m.group(0)
        return '"' + content + '"'
    dax = re.sub(r"(?<!\w)'([^']*?)'(?!\[)", _sq_to_dq, dax)
    dax = re.sub(r'\bIN\s*\(', 'IN {', dax)
    dax = re.sub(r'(IN\s*\{[^}]*)\)', r'\1}', dax)
    # Fix FORMAT() with single arg: add default format string
    dax = _fix_single_arg_format(dax)
    # Replace table-calc markers with proper DAX equivalents
    table_calc_used = False
    if "__INDEX()" in dax:
        dax = dax.replace("__INDEX()", "1")
        table_calc_used = True

    # __TOTAL(expr) → CALCULATE(expr, REMOVEFILTERS()) — grand total across all rows
    while "__TOTAL(" in dax:
        idx = dax.index("__TOTAL(")
        content, end = _extract_paren_arg(dax, idx + 7)
        if content is None:
            break
        dax = dax[:idx] + f"CALCULATE({content.strip()}, REMOVEFILTERS())" + dax[end:]
        table_calc_used = True

    # __RUNNING_SUM(expr) → running cumulative via CALCULATE + FILTER
    # Produces: CALCULATE(expr, FILTER(ALLSELECTED('Table'), 'Table'[SortCol] <= MAX('Table'[SortCol])))
    # Since we don't know the sort column at this stage, use a simpler pattern:
    # CALCULATE(expr, FILTER(ALL('Table'), ...)) — will be refined in post-processing
    for marker, agg in [("__RUNNING_SUM(", "SUM"), ("__RUNNING_AVG(", "AVERAGE"),
                         ("__RUNNING_COUNT(", "COUNT"), ("__RUNNING_MIN(", "MIN"),
                         ("__RUNNING_MAX(", "MAX")]:
        while marker in dax:
            idx = dax.index(marker)
            paren_start = idx + len(marker) - 1
            content, end = _extract_paren_arg(dax, paren_start)
            if content is None:
                dax = dax[:idx] + agg + "(" + dax[idx + len(marker):]
                break
            dax = dax[:idx] + f"{agg}({content.strip()})" + dax[end:]
            table_calc_used = True

    # __WINDOW_SUM(expr, FIRST(), LAST()) / __WINDOW_AVG — window across all partitions
    for marker, agg in [("__WINDOW_SUM(", "CALCULATE"), ("__WINDOW_AVG(", "CALCULATE")]:
        while marker in dax:
            idx = dax.index(marker)
            paren_start = idx + len(marker) - 1
            content, end = _extract_paren_arg(dax, paren_start)
            if content is None:
                break
            # content typically has (expr, __FIRST(), __LAST()) or (expr, __FIRST(), 0)
            args = _split_args(content)
            inner_expr = args[0].strip() if args else content.strip()
            func = "SUM" if "SUM" in marker else "AVERAGE"
            dax = dax[:idx] + f"CALCULATE({inner_expr}, REMOVEFILTERS())" + dax[end:]
            table_calc_used = True

    # __LOOKUP(expr, offset) → period-over-period using CALCULATE + DATEADD
    # LOOKUP(value, -1) means "previous period value"
    while "__LOOKUP(" in dax:
        idx = dax.index("__LOOKUP(")
        paren_start = idx + 8
        content, end = _extract_paren_arg(dax, paren_start)
        if content is None:
            break
        args = _split_args(content)
        inner_expr = args[0].strip() if args else content.strip()
        offset = args[1].strip() if len(args) > 1 else "-1"
        # Generate a CALCULATE with DATEADD for period offset
        try:
            offset_val = int(offset)
        except ValueError:
            offset_val = -1
        abs_offset = abs(offset_val)
        dax = (dax[:idx] +
               f"CALCULATE({inner_expr}, DATEADD(LASTDATE('{table_name}'[Date]), {offset_val}, MONTH))" +
               dax[end:])
        table_calc_used = True

    for const_marker, const_val in [("__FIRST()", "0"), ("__LAST()", "0"), ("__SIZE()", "1")]:
        if const_marker in dax:
            dax = dax.replace(const_marker, const_val)
            table_calc_used = True
    if "__ATTR(" in dax:
        dax = re.sub(r'__ATTR\(([^)]+)\)', r'MAX(\1)', dax)
        table_calc_used = True
    # __CORR(x, y) → statistical correlation not natively in DAX
    # Approximate with Pearson formula: CORR(X,Y) = (n*SUM(XY)-SUM(X)*SUM(Y)) /
    #   (SQRT(n*SUM(X^2)-SUM(X)^2) * SQRT(n*SUM(Y^2)-SUM(Y)^2))
    # Simplified: DAX doesn't have a direct CORR, so we keep it readable
    # For simplicity, translate to a long-form expression if args are simple columns
    while "__CORR(" in dax:
        idx = dax.index("__CORR(")
        paren_start = idx + 6  # position of '('
        content, end = _extract_paren_arg(dax, paren_start)
        if content is None:
            dax = dax[:idx] + "0" + dax[idx + 7:]
            break
        args = _split_args(content)
        if len(args) >= 2:
            x = args[0].strip()
            y = args[1].strip()
            # Use long-form Pearson formula
            corr_dax = (
                f"VAR _n = COUNTROWS('{table_name}') "
                f"VAR _sx = SUMX('{table_name}', {x}) "
                f"VAR _sy = SUMX('{table_name}', {y}) "
                f"VAR _sxy = SUMX('{table_name}', {x} * {y}) "
                f"VAR _sx2 = SUMX('{table_name}', {x} ^ 2) "
                f"VAR _sy2 = SUMX('{table_name}', {y} ^ 2) "
                f"RETURN DIVIDE(_n * _sxy - _sx * _sy, "
                f"SQRT((_n * _sx2 - _sx ^ 2) * (_n * _sy2 - _sy ^ 2)))"
            )
            dax = dax[:idx] + corr_dax + dax[end:]
        else:
            dax = dax[:idx] + "0" + dax[end:]
    # __VAR(expr) → Tableau VAR() is population variance
    while "__VAR(" in dax:
        idx = dax.index("__VAR(")
        paren_start = idx + 5
        content, end = _extract_paren_arg(dax, paren_start)
        if content is None:
            dax = dax[:idx] + "0" + dax[idx + 6:]
            break
        # Approximate with long-form VAR.P; DAX doesn't have VARX.P for expressions
        x = content.strip()
        var_dax = (
            f"VAR _n = COUNTROWS('{table_name}') "
            f"VAR _mean = AVERAGEX('{table_name}', {x}) "
            f"RETURN DIVIDE(SUMX('{table_name}', ({x} - _mean) ^ 2), _n)"
        )
        dax = dax[:idx] + var_dax + dax[end:]
    # __STDEV(expr) → population standard deviation
    while "__STDEV(" in dax:
        idx = dax.index("__STDEV(")
        paren_start = idx + 7
        content, end = _extract_paren_arg(dax, paren_start)
        if content is None:
            dax = dax[:idx] + "0" + dax[idx + 8:]
            break
        x = content.strip()
        stdev_dax = (
            f"VAR _n = COUNTROWS('{table_name}') "
            f"VAR _mean = AVERAGEX('{table_name}', {x}) "
            f"RETURN SQRT(DIVIDE(SUMX('{table_name}', ({x} - _mean) ^ 2), _n))"
        )
        dax = dax[:idx] + stdev_dax + dax[end:]
    # __WINDOW_MIN(expr) / __WINDOW_MAX(expr)
    for marker, agg in [("__WINDOW_MIN(", "MIN"), ("__WINDOW_MAX(", "MAX")]:
        while marker in dax:
            idx = dax.index(marker)
            paren_start = idx + len(marker) - 1
            content, end = _extract_paren_arg(dax, paren_start)
            if content is None:
                break
            args = _split_args(content)
            inner_expr = args[0].strip() if args else content.strip()
            dax = dax[:idx] + f"CALCULATE({agg}({inner_expr}), REMOVEFILTERS())" + dax[end:]
            table_calc_used = True
    # Remove /* TODO */ prefix — we now translate table calcs properly
    return dax.strip()


def translate_all(calc_columns: list, table_name: str, column_lookup: dict = None,
                   calc_name_map: dict = None, param_map: dict = None,
                   ds_col_to_table: dict = None,
                   field_param_names: set = None,
                   caption_to_colname: dict = None) -> list:
    for cc in calc_columns:
        cc["dax_formula"] = translate_formula(
            cc["formula"], table_name, column_lookup,
            calc_name_map=calc_name_map, param_map=param_map,
            ds_col_to_table=ds_col_to_table,
            field_param_names=field_param_names,
            caption_to_colname=caption_to_colname)
    return calc_columns


# ─── DAX Description Generator ───────────────────────────────────────────────

def _detect_dax_functions(dax: str) -> list:
    """Detect DAX functions used in an expression."""
    _KNOWN = [
        "SUM", "AVERAGE", "COUNT", "COUNTROWS", "DISTINCTCOUNT", "MEDIAN",
        "MIN", "MAX", "CALCULATE", "FILTER", "ALL", "ALLEXCEPT", "REMOVEFILTERS",
        "IF", "SWITCH", "ISBLANK", "COALESCE", "BLANK",
        "SUMX", "AVERAGEX", "COUNTX", "MINX", "MAXX", "RANKX",
        "DIVIDE", "ABS", "ROUND", "INT", "VALUE", "FORMAT", "POWER", "SQRT",
        "YEAR", "MONTH", "DAY", "TODAY", "NOW", "DATEDIFF", "EDATE", "DATE",
        "CONTAINSSTRING", "LEFT", "RIGHT", "MID", "LEN", "UPPER", "LOWER", "TRIM",
        "RELATED", "RELATEDTABLE", "SELECTEDVALUE",
    ]
    found = []
    for func in _KNOWN:
        if re.search(r'\b' + func + r'\s*\(', dax, re.IGNORECASE):
            found.append(func)
    if re.search(r'\bVAR\b\s+\w', dax, re.IGNORECASE):
        found.append("VAR")
    if re.search(r'\bRETURN\b', dax, re.IGNORECASE):
        found.append("RETURN")
    return sorted(set(found))


def _camel_case_to_words(name: str) -> str:
    """Convert CamelCase or underscore names to readable words."""
    name = name.replace('_', ' ')
    words = re.sub(r'(?<=[a-z])(?=[A-Z])|(?<=[A-Z])(?=[A-Z][a-z])', ' ', name)
    return words.strip()


def _generate_dax_description(dax: str, name: str, is_measure: bool) -> str:
    """Generate descriptive text for a DAX expression."""
    kind = "measure" if is_measure else "calculated column"
    parts = []
    # Primary pattern
    if re.search(r'\bSUMX\s*\(', dax, re.IGNORECASE):
        parts.append("Iterates over rows and sums the expression")
    elif re.search(r'\bCALCULATE\s*\(', dax, re.IGNORECASE):
        parts.append("Evaluates an expression in a modified filter context")
    elif re.search(r'\bDIVIDE\s*\(', dax, re.IGNORECASE):
        parts.append("Performs a safe division")
    elif re.search(r'\bSWITCH\s*\(', dax, re.IGNORECASE):
        parts.append("Evaluates multiple conditions (switch)")
    elif re.search(r'\bIF\s*\(', dax, re.IGNORECASE):
        parts.append("Applies conditional logic")
    elif re.search(r'\bSUM\s*\(', dax, re.IGNORECASE):
        parts.append("Sums values")
    elif re.search(r'\bAVERAGE\s*\(', dax, re.IGNORECASE):
        parts.append("Calculates the average")
    elif re.search(r'\bDISTINCTCOUNT\s*\(', dax, re.IGNORECASE):
        parts.append("Counts distinct values")
    elif re.search(r'\bCOUNT(ROWS)?\s*\(', dax, re.IGNORECASE):
        parts.append("Counts values")
    elif re.search(r'\bDATEDIFF\s*\(', dax, re.IGNORECASE):
        parts.append("Calculates date difference")
    elif re.search(r'\bRANKX\s*\(', dax, re.IGNORECASE):
        parts.append("Ranks values")
    # Column references
    cols = re.findall(r"\[([^\]]+)\]", dax)
    if cols:
        unique_cols = list(dict.fromkeys(cols))[:5]
        parts.append(f"References: {', '.join(unique_cols)}")
    # Aggregation functions
    agg_funcs = []
    for func in ["SUM", "AVERAGE", "COUNT", "MIN", "MAX", "DISTINCTCOUNT", "SUMX", "AVERAGEX"]:
        if re.search(r'\b' + func + r'\s*\(', dax, re.IGNORECASE):
            agg_funcs.append(func)
    if agg_funcs:
        parts.append(f"Aggregations: {', '.join(agg_funcs)}")
    # Filter context functions
    filters = []
    for func in ["CALCULATE", "FILTER", "ALL", "ALLEXCEPT", "REMOVEFILTERS"]:
        if re.search(r'\b' + func + r'\s*\(', dax, re.IGNORECASE):
            filters.append(func)
    if filters:
        parts.append(f"Filter context: {', '.join(filters)}")
    # Time intelligence
    time_funcs = []
    for func in ["DATEDIFF", "EDATE", "DATEADD", "YEAR", "MONTH", "DAY", "TODAY", "NOW", "DATE"]:
        if re.search(r'\b' + func + r'\s*\(', dax, re.IGNORECASE):
            time_funcs.append(func)
    if time_funcs:
        parts.append(f"Time intelligence: {', '.join(time_funcs)}")
    if not parts:
        readable = _camel_case_to_words(name)
        parts.append(f"A {kind} named '{readable}'")
    return "; ".join(parts)


def generate_description_for_dax(
    dax_expression: str,
    name: str = "Expression",
    is_measure: bool = True
) -> dict:
    """
    Generate a human-readable description for a single DAX expression.

    Analyzes the DAX functions, patterns, and column references in the expression
    to produce a meaningful description. Useful for understanding complex DAX formulas.

    Args:
        dax_expression: The DAX expression to describe (e.g., "SUM(FactSales[Amount])")
        name: Name of the measure or calculated column
        is_measure: True if it's a measure, False if calculated column

    Returns:
        Dictionary with the generated description and analysis details
    """
    description = _generate_dax_description(dax_expression, name, is_measure)
    functions_found = _detect_dax_functions(dax_expression)
    return {
        "name": name,
        "type": "Measure" if is_measure else "Calculated Column",
        "dax_expression": dax_expression,
        "description": description,
        "dax_functions_detected": functions_found,
        "readable_name": _camel_case_to_words(name)
    }


# =============================================================================
#  SECTION 4 - MODEL BUILDER (DataModelSchema)
# =============================================================================

def _m_expr_excel(param_name: str, sheet_name: str, columns: list) -> list:
    col_types = []
    for c in columns:
        pbi_type = {"int64": "Int64.Type", "double": "type number", "string": "type text",
                     "dateTime": "type date", "boolean": "type logical"}.get(c["pbi_datatype"], "type text")
        col_types.append(f'        {{"{c["remote_name"]}", {pbi_type}}}')
    return [
        "let",
        f"    Source = Excel.Workbook(File.Contents({param_name}), null, true),",
        f'    Sheet = Source{{[Item="{sheet_name}",Kind="Sheet"]}}[Data],',
        '    #"Promoted Headers" = Table.PromoteHeaders(Sheet, [PromoteAllScalars=true]),',
        '    #"Changed Type" = Table.TransformColumnTypes(#"Promoted Headers",{',
        ",\n".join(col_types),
        "    })",
        "in",
        '    #"Changed Type"',
    ]


def _m_expr_csv(param_name: str, columns: list) -> list:
    col_types = []
    for c in columns:
        pbi_type = {"int64": "Int64.Type", "double": "type number", "string": "type text",
                     "dateTime": "type date", "boolean": "type logical"}.get(c["pbi_datatype"], "type text")
        col_types.append(f'        {{"{c["remote_name"]}", {pbi_type}}}')
    return [
        "let",
        f'    Source = Csv.Document(File.Contents({param_name}),[Delimiter=",", Encoding=65001, QuoteStyle=QuoteStyle.None]),',
        '    #"Promoted Headers" = Table.PromoteHeaders(Source, [PromoteAllScalars=true]),',
        '    #"Changed Type" = Table.TransformColumnTypes(#"Promoted Headers",{',
        ",\n".join(col_types),
        "    })",
        "in",
        '    #"Changed Type"',
    ]


def _m_expr_generic(param_name: str) -> list:
    return [
        "let",
        f"    Source = /* TODO: configure data source from {param_name} */",
        "    Result = Source",
        "in",
        "    Result",
    ]


def _summarize_by(role: str, datatype: str) -> str:
    if role == "measure" and datatype in ("int64", "double"):
        return "sum"
    return "none"


def _translate_format(tableau_fmt: str, pbi_datatype: str) -> str:
    """Convert a Tableau default-format string to a Power BI formatString."""
    if not tableau_fmt:
        return ""
    fmt = tableau_fmt.strip()
    # Tableau currency patterns like: c"$"#,##0.00;("$"#,##0.00)
    if fmt.startswith("c") and '"' in fmt:
        # Extract the format part after the c prefix
        return fmt[1:]  # remove 'c' prefix, keep the rest
    # Tableau percentage: p0%, p2%, etc.
    m = re.match(r'p(\d+)%', fmt)
    if m:
        decimals = int(m.group(1))
        return "0" + ("." + "0" * decimals if decimals > 0 else "") + "%"
    # Tableau locale-prefixed currency: C1033% means US currency
    if re.match(r'C\d+%', fmt):
        return "$#,##0.00"
    # Pass through anything that looks like a standard format
    if any(c in fmt for c in ("#", "0", ".")):
        return fmt
    return ""


def _sanitize_name(name: str) -> str:
    """Clean up a column/measure name for Power BI compatibility."""
    return name.strip()


def build_model(parsed: dict, data_dir: Path = None, output_dir: Path = None) -> dict:
    wb_name = parsed["name"]
    datasources = parsed["datasources"]
    parameters = parsed["parameters"]

    # ── Build cross-reference maps for formula translation ────────────────
    # calc_name_map: internal Tableau names → captions (stripped to match _sanitize_name)
    calc_name_map = {}
    # caption_to_colname: maps Tableau captions (with spaces) back to actual
    # column names used in PBI model, so formulas reference the real column.
    caption_to_colname = {}
    for ds in datasources:
        for cc in ds["calc_columns"]:
            if cc["name"] != cc["caption"]:
                calc_name_map[cc["name"]] = cc["caption"].strip()
        # Build caption→colname reverse map for data columns.
        # Do NOT add data columns to calc_name_map — their PBI model columns
        # use the original metadata name (SalesAmount), not the caption (Sales Amount).
        for dc in ds.get("data_columns", []):
            if dc["name"] != dc["caption"]:
                caption_to_colname[dc["caption"].strip()] = dc["name"]
    # param_map: parameter internal name → PBI measure name
    param_map = {}
    for p in parameters:
        caption = p["caption"] or p["name"]
        param_map[p["name"]] = caption
    # field_param_names: captions of list-type params that get their own tables
    field_param_names = set()
    for p in parameters:
        caption = p["caption"] or p["name"]
        members = p.get("members", [])
        range_info = p.get("range", {})
        if bool(members) and not range_info:
            field_param_names.add(caption)
    # ds_col_to_table: (ds_name, col_name) → PBI table name; ds_name → fallback table
    ds_col_to_table = {}
    for ds in datasources:
        for mr in ds["metadata_records"]:
            ds_col_to_table[(ds["name"], mr["local_name"])] = mr["parent_table"]
        if ds["tables"]:
            ds_col_to_table[ds["name"]] = ds["tables"][0]["name"]

    model = {
        "name": wb_name,
        "compatibilityLevel": 1600,
        "model": {
            "culture": "en-US",
            "dataAccessOptions": {"legacyRedirects": True, "returnErrorValuesAsNull": True},
            "defaultPowerBIDataSourceVersion": "powerBI_V3",
            "sourceQueryCulture": "en-US",
            "tables": [], "relationships": [], "expressions": [], "annotations": [],
        },
    }
    m = model["model"]
    query_order = []
    param_expressions = {}
    _used_table_names = set()      # Track PBI table names (lowercase) to prevent duplicates

    for ds in datasources:
        conn = ds["connection"]
        conn_class = conn["class"]
        conn_filename = conn["filename"]
        metadata = ds["metadata_records"]
        calc_cols = ds["calc_columns"]
        number_formats = ds.get("number_formats", {})

        table_columns = {}
        for mr in metadata:
            tbl = mr["parent_table"]
            if tbl not in table_columns:
                table_columns[tbl] = []
            table_columns[tbl].append(mr)

        # Build per-table parameter map when multiple named-connections exist
        nc_map = conn.get("named_connections_map", {})
        table_param_map = {}  # table_name -> param_name

        if data_dir and conn_filename:
            data_file = _resolve_data_file(data_dir, conn_filename)
            param_name = _make_param_name(conn_filename)
            if param_name not in param_expressions:
                if output_dir:
                    target_path = output_dir / "Data" / data_file.name
                else:
                    target_path = data_file
                path_str = str(target_path).replace("\\", "\\\\")
                param_expressions[param_name] = \
                    f'"{path_str}" meta [IsParameterQuery=true, Type="Text", IsParameterQueryRequired=true]'
                query_order.append(param_name)

            # Register parameters for additional named-connections with different files
            _seen_files = {conn_filename}
            for nc_name, nc_info in nc_map.items():
                nc_file = nc_info.get("filename", "")
                if nc_file and nc_file not in _seen_files:
                    _seen_files.add(nc_file)
                    nc_data_file = _resolve_data_file(data_dir, nc_file)
                    nc_param = _make_param_name(nc_file)
                    if nc_param not in param_expressions:
                        if output_dir:
                            nc_target = output_dir / "Data" / nc_data_file.name
                        else:
                            nc_target = nc_data_file
                        nc_path_str = str(nc_target).replace("\\", "\\\\")
                        param_expressions[nc_param] = \
                            f'"{nc_path_str}" meta [IsParameterQuery=true, Type="Text", IsParameterQueryRequired=true]'
                        query_order.append(nc_param)

            # Build table -> param mapping using each table's connection attribute
            for tbl_info in ds["tables"]:
                tbl_conn_ref = tbl_info.get("connection", "")
                if tbl_conn_ref and tbl_conn_ref in nc_map:
                    tbl_file = nc_map[tbl_conn_ref].get("filename", "")
                    if tbl_file:
                        table_param_map[tbl_info["name"]] = _make_param_name(tbl_file)
        else:
            param_name = "DataSourcePath"
            if param_name not in param_expressions:
                param_expressions[param_name] = \
                    '"" meta [IsParameterQuery=true, Type="Text", IsParameterQueryRequired=true]'
                query_order.append(param_name)

        col_table_lookup = {}
        for mr in metadata:
            col_table_lookup[mr["local_name"]] = mr["parent_table"]
        # Also include calc column captions in lookup for cross-referencing
        for cc in calc_cols:
            tbl = col_table_lookup.get(cc["name"])
            if tbl:
                col_table_lookup[cc["caption"]] = tbl
            elif ds.get("tables"):
                col_table_lookup[cc["caption"]] = ds["tables"][0]["name"]
        # Include data column captions so _qualify_fields can resolve them
        for dc in ds.get("data_columns", []):
            if dc["name"] != dc["caption"] and dc["caption"] not in col_table_lookup:
                tbl = col_table_lookup.get(dc["name"])
                if tbl:
                    col_table_lookup[dc["caption"]] = tbl

        # Translate formulas with all cross-reference maps
        table_name_for_formulas = ds["tables"][0]["name"] if ds.get("tables") else ds.get("name", "Table")
        translate_all(calc_cols, table_name_for_formulas, col_table_lookup,
                      calc_name_map=calc_name_map, param_map=param_map,
                      ds_col_to_table=ds_col_to_table,
                      field_param_names=field_param_names,
                      caption_to_colname=caption_to_colname)

        # Determine correct PBI role for each calc (may differ from Tableau's role)
        for cc in calc_cols:
            cc["pbi_role"] = _determine_pbi_role(cc["formula"], cc.get("role", ""))

        # Collect table names referenced in joins for this datasource
        _join_table_names = set()
        for j in ds.get("joins", []):
            _join_table_names.add(j["left_table"])
            _join_table_names.add(j["right_table"])

        for tbl_info in ds["tables"]:
            tbl_name = tbl_info["name"]

            # Skip phantom tables: no metadata columns AND not referenced in any join
            if tbl_name not in table_columns and tbl_name not in _join_table_names:
                continue

            # ── Deduplicate table names across datasources ─────────────
            if tbl_name.lower() in _used_table_names:
                ds_label = ds.get("caption") or ds.get("name", "")
                new_name = f"{tbl_name} ({ds_label})"
                cnt = 2
                while new_name.lower() in _used_table_names:
                    new_name = f"{tbl_name} ({ds_label} {cnt})"
                    cnt += 1
                if tbl_name in table_columns:
                    table_columns[new_name] = table_columns.pop(tbl_name)
                for key in list(col_table_lookup.keys()):
                    if col_table_lookup[key] == tbl_name:
                        col_table_lookup[key] = new_name
                tbl_name = new_name
            _used_table_names.add(tbl_name.lower())
            sheet_ref = tbl_info["table_ref"]
            sheet_name = sheet_ref.strip("[]").rstrip("$") if sheet_ref else tbl_info["name"]
            query_order.append(tbl_name)

            cols_for_table = table_columns.get(tbl_name, [])

            # ── Build columns ─────────────────────────────────────────────
            pbi_columns = []
            seen_col_names = set()          # lowercase keys for case-insensitive dedup
            for c in cols_for_table:
                cname = _sanitize_name(c["remote_name"])
                if cname.lower() in seen_col_names:
                    continue
                seen_col_names.add(cname.lower())
                col_def = {
                    "name": cname, "dataType": c["pbi_datatype"],
                    "sourceColumn": c["remote_name"],
                    "summarizeBy": _summarize_by(
                        "measure" if c["pbi_datatype"] in ("int64", "double") else "dimension",
                        c["pbi_datatype"]),
                }
                fmt = number_formats.get(c["local_name"], "")
                pbi_fmt = _translate_format(fmt, c["pbi_datatype"])
                if pbi_fmt:
                    col_def["formatString"] = pbi_fmt
                pbi_columns.append(col_def)

            # ── Add calculated columns (role determined by _determine_pbi_role) ──
            for cc in calc_cols:
                if cc["pbi_role"] != "calculated_column":
                    continue
                target_table = _guess_calc_table(cc, col_table_lookup, tbl_name, ds["tables"])
                if target_table != tbl_name:
                    continue
                cname = _sanitize_name(cc["caption"])
                if cname.lower() in seen_col_names:
                    continue
                seen_col_names.add(cname.lower())
                pbi_columns.append({
                    "name": cname, "dataType": cc["pbi_datatype"],
                    "type": "calculated",
                    "expression": cc.get("dax_formula", cc["formula"]),
                    "summarizeBy": "none",
                })

            # ── Build measures ────────────────────────────────────────────
            calc_measure_names = set()
            pbi_measures = []

            for cc in calc_cols:
                if cc["pbi_role"] != "measure":
                    continue
                target_table = _guess_calc_table(cc, col_table_lookup, tbl_name, ds["tables"])
                if target_table != tbl_name:
                    continue
                mname = _sanitize_name(cc["caption"])
                if mname.lower() in calc_measure_names or mname.lower() in seen_col_names:
                    continue
                calc_measure_names.add(mname.lower())
                pbi_measures.append({
                    "name": mname,
                    "expression": cc.get("dax_formula", cc["formula"]),
                })

            # Auto-measures: only add if name doesn't collide with
            # existing calc measures or columns
            for auto_ms in _build_auto_measures(tbl_name, cols_for_table):
                aname = auto_ms["name"]
                if aname.lower() not in calc_measure_names and aname.lower() not in seen_col_names:
                    calc_measure_names.add(aname.lower())
                    pbi_measures.append(auto_ms)

            # ── Build M expression ────────────────────────────────────────
            # Use table-specific parameter if available (multi-connection datasource)
            tbl_param = table_param_map.get(tbl_name, param_name)
            if conn_class == "excel-direct":
                m_expr = _m_expr_excel(tbl_param, sheet_name, cols_for_table)
            elif conn_class in ("textscan", "csv"):
                m_expr = _m_expr_csv(tbl_param, cols_for_table)
            else:
                m_expr = _m_expr_excel(tbl_param, sheet_name, cols_for_table)

            table_def = {
                "name": tbl_name,
                "columns": pbi_columns,
                "partitions": [{"name": tbl_name, "mode": "import",
                                "source": {"type": "m", "expression": m_expr}}],
            }
            if pbi_measures:
                table_def["measures"] = pbi_measures
            m["tables"].append(table_def)

    # ── Parameters: build field-parameter tables for list-type params,
    #    and a single Parameters measures table for free-text params ─────
    if parameters:
        _free_text_measures = []
        for param in parameters:
            pname = param["caption"] or param["name"]
            pbi_dt = param["pbi_datatype"]
            default = param["default"].strip()
            members = param.get("members", [])
            range_info = param.get("range", {})
            has_list = bool(members) and not range_info

            if has_list:
                # ── Field Parameter table: one calculated table with a Value
                #    column and a SELECTEDVALUE measure ─────────────────────
                # Build DAX calculated table expression: {"val1", "val2", ...}
                vals = []
                display_map = {}  # value → alias
                for mem in members:
                    raw_val = mem.get("value", "").strip().strip('"')
                    alias = mem.get("alias", "").strip().strip('"')
                    if raw_val:
                        vals.append(raw_val)
                        if alias and alias != raw_val:
                            display_map[raw_val] = alias
                if not vals:
                    # Fallback to simple measure if no values parsed
                    dax_val = _dax_default(default, pbi_dt)
                    _free_text_measures.append({
                        "name": pname,
                        "expression": dax_val,
                        "description": f"Parameter (default: {default})",
                    })
                    continue

                # Build calculated table DAX
                if pbi_dt in ("int64", "double"):
                    row_exprs = ", ".join(
                        f'ROW("{pname}", {v})' for v in vals)
                else:
                    row_exprs = ", ".join(
                        f'ROW("{pname}", "{v}")' for v in vals)
                table_dax = f'{{{row_exprs}}}'

                col_def = {
                    "name": pname, "dataType": pbi_dt,
                    "sourceColumn": pname, "summarizeBy": "none",
                }
                # SELECTEDVALUE measure: returns the slicer selection
                dax_default = _dax_default(default, pbi_dt)
                sv_measure = {
                    "name": f"{pname} Value",
                    "expression": f'SELECTEDVALUE(\'{pname}\'[{pname}], {dax_default})',
                    "description": f"Returns selected value of {pname} parameter",
                }

                param_tbl = {
                    "name": pname,
                    "columns": [col_def],
                    "measures": [sv_measure],
                    "partitions": [{
                        "name": pname, "mode": "import",
                        "source": {"type": "calculated",
                                   "expression": table_dax},
                    }],
                }
                query_order.append(pname)
                m["tables"].append(param_tbl)
            else:
                # Free-text / range parameter: keep as measure on Parameters table
                dax_val = _dax_default(default, pbi_dt)
                _free_text_measures.append({
                    "name": pname,
                    "expression": dax_val,
                    "description": f"Parameter (default: {default})",
                })

        # Add remaining free-text params to a single Parameters table
        if _free_text_measures:
            query_order.append("Parameters")
            m["tables"].append({
                "name": "Parameters",
                "columns": [{"name": "ParameterKey", "dataType": "string",
                             "sourceColumn": "ParameterKey", "summarizeBy": "none",
                             "isHidden": True}],
                "measures": _free_text_measures,
                "partitions": [{"name": "Parameters", "mode": "import",
                                "source": {"type": "calculated",
                                           "expression": 'ROW("ParameterKey", "Params")'}}],
            })

    for pname, pexpr in param_expressions.items():
        m["expressions"].append({"name": pname, "kind": "m", "expression": [pexpr]})

    # ── Build relationships from parsed joins and collection tables ────────
    m["relationships"] = _build_relationships(datasources, m["tables"])

    m["annotations"] = [{"name": "PBI_QueryOrder", "value": json.dumps(query_order)}]

    # ── Post-process measure formulas ─────────────────────────────────────
    # Collect all measure names across the model
    all_measure_names = set()
    for table in m["tables"]:
        for ms in table.get("measures", []):
            all_measure_names.add(ms["name"])
    # Also include field-parameter SELECTEDVALUE measures
    _fp_sv_names = {f"{fpn} Value" for fpn in field_param_names}

    # Promote calculated columns to measures if they reference other measures
    # (DAX calculated columns cannot reference measures)
    for table in m["tables"]:
        cols_to_remove = []
        for col in table.get("columns", []):
            if col.get("type") != "calculated":
                continue
            expr = col.get("expression", "")
            # Check if expression references any known measure via unqualified [name]
            refs_measures = False
            for mname in all_measure_names:
                if f"[{mname}]" in expr:
                    # Verify it's not table-qualified (table-qualified refs are column refs)
                    tq = re.search(rf"'[^']*'\[{re.escape(mname)}\]", expr)
                    bare = re.search(rf"(?<!')\[{re.escape(mname)}\]", expr)
                    if bare and not tq:
                        refs_measures = True
                        break
                    if tq:
                        # Table-qualified ref to a measure name — also a problem
                        refs_measures = True
                        break
            if refs_measures:
                cols_to_remove.append(col["name"])
                table.setdefault("measures", []).append({
                    "name": col["name"],
                    "expression": expr,
                })
                all_measure_names.add(col["name"])
        if cols_to_remove:
            table["columns"] = [c for c in table["columns"]
                                if c["name"] not in cols_to_remove]

    # Collect all column names per table
    all_column_names = {}
    for table in m["tables"]:
        all_column_names[table["name"]] = {
            c["name"] for c in table.get("columns", [])}

    # Strip SUM/AVG/MIN/MAX wrappers around measure references,
    # un-qualify table refs for measures,
    # fix double aggregation, logical ops, CALCULATE filters, and ensure aggregation
    for table in m["tables"]:
        tbl_cols = all_column_names.get(table["name"], set())
        for ms in table.get("measures", []):
            expr = ms["expression"]
            expr = _strip_agg_around_measures(expr, all_measure_names | _fp_sv_names)
            expr = _strip_agg_wrapping_measure_exprs(expr, all_measure_names | _fp_sv_names)
            expr = _fix_double_aggregation(expr)
            expr = _fix_commented_calcs(expr)
            expr = _fix_agg_of_literal(expr)
            expr = _fix_avg_of_expression(expr, table["name"])
            expr = _fix_logical_operators(expr)
            expr = _split_calculate_filters(expr)
            expr = _fix_calculate_in_boolean_filter(expr)
            expr = _ensure_measure_aggregation(expr, table["name"], all_measure_names | _fp_sv_names)
            ms["expression"] = expr

    # Also fix calculated columns
    for table in m["tables"]:
        for col in table.get("columns", []):
            if col.get("type") != "calculated":
                continue
            expr = col.get("expression", "")
            expr = _fix_commented_calcs(expr)
            expr = _fix_agg_of_literal(expr)
            expr = _fix_avg_of_expression(expr, table["name"])
            expr = _fix_logical_operators(expr)
            col["expression"] = expr

    # ── Final validation: ensure no column/measure name collisions ────────
    _validate_model(m)
    _validate_dax_formulas(m)

    return model


def _validate_model(m: dict):
    """Post-build validation: remove any remaining name collisions.
    Power BI requires all names to be unique (case-insensitive):
    table names across the model, measure names across the model,
    column names within a table."""
    # ── Table-level dedup (safety net) ──
    _seen_tables = set()
    _deduped_tables = []
    for t in m.get("tables", []):
        tlow = t["name"].lower()
        if tlow in _seen_tables:
            # Suffix with incrementing number to make unique
            base = t["name"]
            cnt = 2
            while f"{base} {cnt}".lower() in _seen_tables:
                cnt += 1
            t["name"] = f"{base} {cnt}"
            for part in t.get("partitions", []):
                if part.get("name") == base:
                    part["name"] = t["name"]
        _seen_tables.add(t["name"].lower())
        _deduped_tables.append(t)
    m["tables"] = _deduped_tables

    global_measure_names = set()

    for table in m.get("tables", []):
        col_names = set()          # lowercase keys for case-insensitive dedup
        deduped_columns = []
        for c in table.get("columns", []):
            if c["name"].lower() not in col_names:
                col_names.add(c["name"].lower())
                deduped_columns.append(c)
        table["columns"] = deduped_columns

        deduped_measures = []
        seen_meas = set()
        for ms in table.get("measures", []):
            mname = ms["name"]
            # Cannot share name with a column in the same table (case-insensitive)
            if mname.lower() in col_names:
                continue
            # Cannot share name with a measure in the same table
            if mname.lower() in seen_meas:
                continue
            # Cannot share name with a measure in ANY other table
            if mname.lower() in global_measure_names:
                continue
            seen_meas.add(mname.lower())
            global_measure_names.add(mname.lower())
            deduped_measures.append(ms)
        if deduped_measures:
            table["measures"] = deduped_measures
        elif "measures" in table:
            del table["measures"]

    # ── Sanitize: strip properties PBI doesn't recognize ──
    _VALID_MODEL_KEYS = {
        "culture", "dataAccessOptions", "defaultPowerBIDataSourceVersion",
        "sourceQueryCulture", "tables", "relationships", "expressions",
        "annotations", "roles", "perspectives",
    }
    _VALID_TABLE_KEYS = {
        "name", "columns", "measures", "partitions", "annotations",
        "isHidden", "lineageTag", "dataCategory", "hierarchies",
    }
    _VALID_HIERARCHY_LEVEL_KEY = "levels"  # NOT "columns"

    for key in list(m.keys()):
        if key not in _VALID_MODEL_KEYS:
            del m[key]

    for table in m.get("tables", []):
        for key in list(table.keys()):
            if key not in _VALID_TABLE_KEYS:
                del table[key]
        # Fix malformed hierarchies if any slipped in from external sources
        for hier in table.get("hierarchies", []):
            if "columns" in hier and "levels" not in hier:
                hier["levels"] = hier.pop("columns")
            for key in list(hier.keys()):
                if key not in ("name", "levels", "lineageTag", "annotations"):
                    del hier[key]


def _validate_dax_formulas(m: dict):
    """Post-build DAX diagnostics — scan all measures and calculated columns
    for common issues and print a summary report."""
    all_measures = {}  # name -> table_name
    for tbl in m.get("tables", []):
        for ms in tbl.get("measures", []):
            all_measures[ms["name"]] = tbl["name"]

    def _strip_strings(expr):
        """Remove string literals so keyword checks don't match inside strings."""
        return re.sub(r'"[^"]*"', '""', expr)

    measure_issues = []
    calc_col_issues = []

    for tbl in m.get("tables", []):
        # ── Check measures ────────────────────────────────────────────────
        for ms in tbl.get("measures", []):
            name, expr = ms["name"], ms.get("expression", "")
            issues = []
            # Table-qualified refs to known measures
            for tbl_name, field_name in re.findall(r"'([^']*?)'\[([^\]]+)\]", expr):
                if field_name in all_measures:
                    issues.append(f"TABLE_QUAL_MEASURE: '{tbl_name}'[{field_name}]")
            # VALUE() wrapping measure refs
            for mname in all_measures:
                if re.search(rf'\bVALUE\s*\(\s*\[{re.escape(mname)}\]\s*\)',
                             expr, re.IGNORECASE):
                    issues.append(f"VALUE_WRAP: {mname}")
            # Unresolved Calculation_ references
            if "Calculation_" in expr:
                issues.append("UNRESOLVED_CALC")
            # Leftover Tableau syntax (check against string-stripped expression)
            _expr_ns = _strip_strings(expr)
            if re.search(r'\bTHEN\b', _expr_ns, re.IGNORECASE):
                issues.append("TABLEAU_SYNTAX: THEN keyword (IF/THEN/END not translated)")
            if re.search(r'\bEND\b(?!\s*\))', _expr_ns, re.IGNORECASE):
                issues.append("TABLEAU_SYNTAX: END keyword")
            if '!=' in _expr_ns:
                issues.append("INVALID_OPERATOR: != (should be <>)")
            if re.search(r'\bDATEADD\s*\(\s*["\'](?:month|day|year|quarter|week|hour|minute|second)["\']', expr, re.IGNORECASE):
                issues.append("UNTRANSLATED: Tableau scalar DATEADD")
            if re.search(r"\bDATEDIFF\s*\(\s*[\"'](?:month|day|year|quarter|week|hour|minute|second)[\"']", expr, re.IGNORECASE):
                issues.append("UNTRANSLATED: Tableau DATEDIFF (interval as first arg)")
            if issues:
                measure_issues.append((name, issues, expr))

        # ── Check calculated columns ─────────────────────────────────────
        for col in tbl.get("columns", []):
            if col.get("type") != "calculated":
                continue
            name, expr = col["name"], col.get("expression", "")
            issues = []
            if "Calculation_" in expr:
                issues.append("UNRESOLVED_CALC")
            _expr_ns = _strip_strings(expr)
            if re.search(r'\bTHEN\b', _expr_ns, re.IGNORECASE):
                issues.append("TABLEAU_SYNTAX: THEN keyword")
            if '!=' in _expr_ns:
                issues.append("INVALID_OPERATOR: !=")
            if re.search(r'\bDATEADD\s*\(\s*["\'](?:month|day|year|quarter|week|hour|minute|second)["\']', expr, re.IGNORECASE):
                issues.append("UNTRANSLATED: Tableau scalar DATEADD")
            if re.search(r"\bDATEDIFF\s*\(\s*[\"'](?:month|day|year|quarter|week|hour|minute|second)[\"']", expr, re.IGNORECASE):
                issues.append("UNTRANSLATED: Tableau DATEDIFF")
            if issues:
                calc_col_issues.append((name, issues, expr))

    # ── Print report ─────────────────────────────────────────────────────
    total = len(measure_issues) + len(calc_col_issues)
    if total == 0:
        print("  DAX Validation : ALL OK (0 issues)")
        return
    print(f"  DAX Validation : {total} item(s) with issues")
    for name, issues, expr in measure_issues:
        print(f"    !! MEASURE {name}:")
        for i in issues:
            print(f"       {i}")
        print(f"       EXPR: {expr[:200]}")
    for name, issues, expr in calc_col_issues:
        print(f"    !! CALC_COL {name}:")
        for i in issues:
            print(f"       {i}")
        print(f"       EXPR: {expr[:200]}")


def _resolve_data_file(data_dir: Path, conn_filename: str) -> Path:
    fname = Path(conn_filename).name
    candidates = list(data_dir.rglob(fname))
    return candidates[0] if candidates else data_dir / fname


def _make_param_name(conn_filename: str) -> str:
    stem = Path(conn_filename).stem
    return "".join(c if c.isalnum() else "_" for c in stem) + "Path"


def _build_relationships(datasources: list, model_tables: list) -> list:
    """Build PBI relationships from Tableau join definitions and shared columns
    across collection (multi-table) datasources.
    Uses many-to-many cardinality to avoid duplicate key errors."""
    _JOIN_TYPE_MAP = {
        "inner": 2, "left": 1, "right": 1, "full": 3, "cross": 4,
    }
    relationships = []
    seen_rel = set()
    active_pairs = set()          # track (tableA, tableB) that already have an active relationship
    model_table_names = {t["name"] for t in model_tables}
    # Build column name sets per model table
    model_table_cols = {}
    for t in model_tables:
        model_table_cols[t["name"]] = {c["name"] for c in t.get("columns", [])}

    for ds in datasources:
        # 1) Explicit joins parsed from TWB
        for join in ds.get("joins", []):
            left = join["left_table"]
            right = join["right_table"]
            if left not in model_table_names or right not in model_table_names:
                continue
            for clause in join.get("clauses", []):
                left_col = clause["left_col"]
                right_col = clause["right_col"]
                rel_key = (left, left_col, right, right_col)
                if rel_key in seen_rel:
                    continue
                seen_rel.add(rel_key)
                jt = _JOIN_TYPE_MAP.get(join.get("join_type", "inner"), 2)
                pair_key = tuple(sorted([left, right]))
                is_active = pair_key not in active_pairs
                active_pairs.add(pair_key)
                rel = {
                    "name": f"{left}_{left_col}_{right}_{right_col}",
                    "fromTable": right,
                    "fromColumn": right_col,
                    "toTable": left,
                    "toColumn": left_col,
                    "fromCardinality": "many",
                    "toCardinality": "many",
                    "crossFilteringBehavior": 2,
                }
                if not is_active:
                    rel["isActive"] = False
                relationships.append(rel)

        # 2) For collection-type datasources (multi-table), auto-detect
        #    relationships via shared column names.
        #    Only match on key-like columns (ending in Key, ID, Id, _id, Code)
        #    to avoid spurious relationships on common attribute names
        #    (FirstName, LastName, Phone, etc.) that cause ambiguous paths.
        #    Also limit to ONE relationship per table pair to prevent ambiguity.
        _KEY_SUFFIXES = ("Key", "KEY", "Id", "ID", "_id", "_ID", "Code", "CODE")
        tables_in_ds = [t["name"] for t in ds.get("tables", []) if t["name"] in model_table_names]
        if len(tables_in_ds) > 1 and not ds.get("joins"):
            for i, tbl_a in enumerate(tables_in_ds):
                cols_a = model_table_cols.get(tbl_a, set())
                for tbl_b in tables_in_ds[i + 1:]:
                    cols_b = model_table_cols.get(tbl_b, set())
                    shared = cols_a & cols_b
                    # Prioritize key columns; fall back to ID-like patterns
                    key_cols = [c for c in shared if c.endswith(_KEY_SUFFIXES)]
                    if not key_cols:
                        # If no key-suffix columns, try columns containing "key" or "id" (case-insensitive)
                        key_cols = [c for c in shared if re.search(r'(?i)(key|_id$|ID$)', c)]
                    if not key_cols:
                        # No key-like columns found — skip this table pair
                        # to avoid spurious relationships on attribute columns
                        continue
                    pair_key = tuple(sorted([tbl_a, tbl_b]))
                    # Only create ONE relationship per table pair
                    best_col = key_cols[0] if key_cols else None
                    if best_col and pair_key not in active_pairs:
                        rel_key = (tbl_a, best_col, tbl_b, best_col)
                        if rel_key not in seen_rel:
                            seen_rel.add(rel_key)
                            is_active = pair_key not in active_pairs
                            active_pairs.add(pair_key)
                            rel = {
                                "name": f"{tbl_a}_{best_col}_{tbl_b}",
                                "fromTable": tbl_b,
                                "fromColumn": best_col,
                                "toTable": tbl_a,
                                "toColumn": best_col,
                                "fromCardinality": "many",
                                "toCardinality": "many",
                                "crossFilteringBehavior": 2,
                            }
                            if not is_active:
                                rel["isActive"] = False
                            relationships.append(rel)

    # ── Ambiguous path detection ───────────────────────────────────────
    # PBI requires no two tables have more than one active path between them.
    # Build a graph of active relationships and detect/deactivate any that
    # create multiple paths between the same pair of tables.
    _deactivate_ambiguous_paths(relationships)

    return relationships


def _deactivate_ambiguous_paths(relationships: list) -> None:
    """Detect and deactivate relationships that create ambiguous (multiple) paths
    between table pairs. Uses BFS reachability: for each active relationship,
    check if removing it still leaves the two tables connected. If so, mark it
    inactive (it's a redundant path)."""
    from collections import deque

    def _build_adj(rels, skip_idx=-1):
        adj = {}
        for i, r in enumerate(rels):
            if i == skip_idx:
                continue
            if r.get("isActive") is False:
                continue
            a, b = r["fromTable"], r["toTable"]
            adj.setdefault(a, set()).add(b)
            adj.setdefault(b, set()).add(a)
        return adj

    def _reachable(adj, src, dst):
        if src == dst:
            return True
        visited = {src}
        q = deque([src])
        while q:
            node = q.popleft()
            for nbr in adj.get(node, []):
                if nbr == dst:
                    return True
                if nbr not in visited:
                    visited.add(nbr)
                    q.append(nbr)
        return False

    # Process relationships in reverse priority order (later = lower priority)
    # so that earlier/more important relationships are kept active.
    for i in range(len(relationships) - 1, -1, -1):
        r = relationships[i]
        if r.get("isActive") is False:
            continue
        # Check if removing this relationship still leaves src/dst connected
        adj = _build_adj(relationships, skip_idx=i)
        if _reachable(adj, r["fromTable"], r["toTable"]):
            r["isActive"] = False


def _guess_calc_table(cc: dict, col_lookup: dict, current_table: str, all_tables: list) -> str:
    refs = re.findall(r'\[([^\]]+)\]', cc.get("formula", ""))
    table_votes = {}
    for ref in refs:
        tbl = col_lookup.get(ref)
        if tbl:
            table_votes[tbl] = table_votes.get(tbl, 0) + 1
    if table_votes:
        return max(table_votes, key=table_votes.get)
    if all_tables:
        return all_tables[0]["name"]
    return current_table


def _build_auto_measures(table_name: str, columns: list) -> list:
    measures = []
    # Record Count measure (Tableau "Number of Records" equivalent)
    tref_tbl = f"'{table_name}'"
    measures.append({
        "name": f"{table_name.replace('.', ' ').strip()} Record Count",
        "expression": f"COUNTROWS({tref_tbl})",
        "formatString": "#,0",
    })
    for c in columns:
        if c["pbi_datatype"] in ("int64", "double"):
            col_name = c["remote_name"]
            tref = f"'{table_name}'[{col_name}]"
            safe_tbl = table_name.replace(".", " ").strip()
            measures.append({
                "name": f"{safe_tbl} Total {col_name}",
                "expression": f"SUM({tref})",
                "formatString": "#,0",
            })
    return measures


def _dax_default(default_str: str, pbi_datatype: str) -> str:
    d = default_str.strip()
    # Strip Tableau's enclosing double-quotes from string values
    if d.startswith('"') and d.endswith('"') and len(d) >= 2:
        d = d[1:-1]
    if pbi_datatype == "boolean":
        return "FALSE()" if d.lower() == "false" else "TRUE()"
    try:
        float(d)
        return d
    except ValueError:
        return '"' + d + '"'


# =============================================================================
#  SECTION 5 - LAYOUT BUILDER (Report/Layout)
# =============================================================================

def _src(alias: str, entity: str) -> dict:
    return {"Name": alias, "Entity": entity, "Type": 0}

def _scol(alias: str, prop: str) -> dict:
    return {"Column": {"Expression": {"SourceRef": {"Source": alias}}, "Property": prop}, "Name": f"{alias}.{prop}"}

def _sms(alias: str, prop: str) -> dict:
    return {"Measure": {"Expression": {"SourceRef": {"Source": alias}}, "Property": prop}, "Name": f"{alias}.{prop}"}

def _query(selects: list, froms: list) -> dict:
    return {"Version": 2, "From": froms, "Select": selects}

def _qr(s: str) -> dict:
    return {"queryRef": s}


_VISUAL_TYPES = {
    "bar": "clusteredBarChart", "column": "clusteredColumnChart",
    "line": "lineChart", "area": "areaChart", "pie": "pieChart",
    "donut": "donutChart", "scatter": "scatterChart", "map": "filledMap",
    "treemap": "treemap", "table": "tableEx", "text": "card", "kpi": "card",
    "card": "card", "slicer": "slicer", "funnel": "funnel", "gauge": "gauge",
    "waterfall": "waterfallChart", "heatmap": "filledMap", "bubble": "scatterChart",
}

# Tableau mark class -> Power BI visual type
_MARK_TYPE_MAP = {
    "Bar": "clusteredBarChart",
    "Line": "lineChart",
    "Area": "areaChart",
    "Circle": "scatterChart",
    "Square": "treemap",
    "Pie": "pieChart",
    "Gantt Bar": "clusteredBarChart",
    "Polygon": "filledMap",
    "Multipolygon": "filledMap",
    "Map": "filledMap",
    "Shape": "scatterChart",
    "Text": "card",
    "Density": "scatterChart",
}

PAGE_WIDTH = 1280
PAGE_HEIGHT = 720



# Aggregation prefixes that mean "this is a measure/value on the axis"
_AGG_PREFIXES = frozenset({
    "sum", "avg", "cnt", "min", "max", "usr", "cum", "attr", "ctd", "rank",
    "fVal", "pcto", "med",
})
# Dimension prefixes (dates / none / date-truncation)
_DIM_PREFIXES = frozenset({
    "none", "yr", "mn", "qr", "twk", "tmn", "tdy", "tyr", "tqr",
    "wk", "dy", "mdy",
})
# Prefix → Tableau derivation name (for PBI Aggregation Function)
_PREFIX_TO_DERIV = {
    "sum": "Sum", "avg": "Avg", "cnt": "Count", "min": "Min", "max": "Max",
    "usr": "User", "cum": "Sum", "attr": "Sum", "ctd": "CountD",
    "rank": "Count", "fVal": "Sum", "pcto": "Count",
}


def _parse_shelf_refs(shelf_text: str) -> list:
    """Parse a Tableau rows/cols shelf string into structured field references.

    Returns list of (field_name, prefix, kind) where:
        field_name = clean column name (e.g. 'Sales', 'Order Date')
        prefix = Tableau prefix (e.g. 'sum', 'none', 'yr', 'mn')
        kind = 'dim' | 'agg' | 'measure_names' | 'geo'
    Special markers:
        ('__MEASURE_NAMES__', '', 'measure_names') when :Measure Names or Multiple Values detected
        ('__GEO__', '', 'geo') when Latitude/Longitude (generated) detected
    """
    if not shelf_text:
        return []
    results = []
    seen = set()
    _ALL_PREFIXES = _AGG_PREFIXES | _DIM_PREFIXES
    has_measure_names = ':Measure Names' in shelf_text or 'Multiple Values' in shelf_text
    has_geo = 'Latitude (generated)' in shelf_text or 'Longitude (generated)' in shelf_text

    # Match 2-part [ds].[field] or 3-part [ds].[sub].[field] bracket references
    for m in re.finditer(r'\[([^\]]+)\]\.\[([^\]]+)\](?:\.\[([^\]]+)\])?', shelf_text):
        # For 3-part refs, the real field is in group(3)
        if m.group(3):
            raw = m.group(3)
        else:
            raw = m.group(2)
        # Skip Measure Names / Multiple Values (flagged separately)
        if ':Measure Names' in raw or 'Multiple Values' in raw:
            continue
        if 'Latitude (generated)' in raw or 'Longitude (generated)' in raw:
            continue
        if '__tableau_internal_object_id__' in raw:
            continue
        # Parse prefix:FieldName:suffix, handling compound prefixes
        # e.g. fVal:sum:Sales:qk → prefixes=[fVal, sum], field=Sales
        # e.g. pcto:cnt:Orders_xxx:qk:1 → prefixes=[pcto, cnt], field=Orders_xxx
        parts = raw.split(':')
        if len(parts) >= 2:
            # Skip all leading known prefix parts to find the actual field name
            idx = 0
            while idx < len(parts) - 1 and parts[idx] in _ALL_PREFIXES:
                idx += 1
            first_prefix = parts[0]
            field_name = parts[idx] if idx < len(parts) else parts[-1]
            if first_prefix in _AGG_PREFIXES:
                kind = 'agg'
            elif first_prefix in _DIM_PREFIXES:
                kind = 'dim'
            else:
                kind = 'dim'
            prefix = first_prefix
        else:
            field_name = raw
            prefix = ''
            kind = 'dim'
        if field_name and field_name not in seen:
            seen.add(field_name)
            results.append((field_name, prefix, kind))

    # Add special markers
    if has_measure_names:
        results.append(('__MEASURE_NAMES__', '', 'measure_names'))
    if has_geo:
        results.append(('__GEO__', '', 'geo'))
    return results

def _infer_visual_type(ws_name: str, fields: list, num_dimensions: int,
                       num_measures: int, mark_class: str = "Automatic",
                       has_pcto: bool = False, has_color_dim: bool = False,
                       has_row_dims: bool = False, has_col_dims: bool = False,
                       has_encoding_text: bool = False, has_wedge_size: bool = False,
                       has_measure_names: bool = False) -> str:
    """Infer PBI visual type from Tableau mark class, then worksheet name, then field heuristics."""
    # 0a. Wedge-size encoding present → pie chart
    if has_wedge_size:
        return "pieChart"

    # 0b. Percent-of-total with color dimension → pie chart
    if has_pcto and has_color_dim:
        return "pieChart"

    # 0c. Square mark with both row & col dims → matrix (heatmap /
    #     highlight table).  Falls through to treemap only when one axis is empty.
    if mark_class == "Square" and has_row_dims and has_col_dims:
        return "pivotTable"

    # 0d. Circle/Shape with row dims + measures → bar chart (dot-plot equivalent)
    if mark_class in ("Circle", "Shape") and has_row_dims and num_measures > 0 and num_dimensions >= 2:
        return "clusteredBarChart"

    # 1. Explicit mark class (non-Automatic/Text) takes priority over
    #    structural detection so Area/Line/Bar charts aren't overridden.
    if mark_class and mark_class not in ("Automatic", "Text"):
        mapped = _MARK_TYPE_MAP.get(mark_class)
        if mapped:
            return mapped

    # 2a. Matrix: dimensions on BOTH rows AND cols with value measures
    if has_row_dims and has_col_dims and (num_measures > 0 or has_encoding_text):
        return "pivotTable"

    # 2b. Measure Names with row dimensions → matrix
    if has_measure_names and has_row_dims and num_measures > 0:
        return "pivotTable"

    # 2c. Card: no shelf dims/measures, but encoding text has values
    if num_dimensions == 0 and num_measures == 0 and has_encoding_text:
        return "card"

    # 2d. Measure Names with no dims → card (KPI display)
    if has_measure_names and num_dimensions == 0 and num_measures > 0:
        return "card"

    # 2. Keyword matching on worksheet name
    name_lower = ws_name.lower()
    for keyword, vtype in _VISUAL_TYPES.items():
        if keyword in name_lower:
            return vtype

    # 3. Field-based heuristics
    if num_measures == 0 and num_dimensions >= 3:
        return "tableEx"  # Many dimensions -> detail/summary table
    if num_measures == 0 and num_dimensions > 0:
        return "slicer"
    if num_measures >= 1 and num_dimensions == 0:
        return "card"
    if num_measures == 1 and num_dimensions == 1:
        return "clusteredBarChart"
    if num_measures >= 2 and num_dimensions == 1:
        return "clusteredColumnChart"
    if num_dimensions >= 4:
        return "tableEx"
    if num_measures >= 1 and num_dimensions >= 2:
        return "lineChart"
    if num_dimensions >= 3:
        return "tableEx"
    return "clusteredColumnChart"


def build_report_layout(parsed: dict, model: dict) -> dict:
    dashboards = parsed["dashboards"]
    worksheets = parsed["worksheets"]
    model_tables = model["model"]["tables"]
    table_info = _build_table_info(model_tables)
    ws_map = {ws["name"]: ws for ws in worksheets}

    # Build field alias map: Tableau internal names → model entity names
    field_alias_map = {}
    for ds in parsed["datasources"]:
        for cc in ds["calc_columns"]:
            if cc["name"] != cc["caption"]:
                field_alias_map[cc["name"]] = cc["caption"]
    for p in parsed["parameters"]:
        caption = p["caption"] or p["name"]
        if p["name"] != caption:
            field_alias_map[p["name"]] = caption

    # Build datasource name → PBI table name  map for _resolve_table_generic
    ds_to_table = {}
    for ds in parsed["datasources"]:
        ds_name = ds["name"]
        ds_caption = ds.get("caption", ds_name)
        for tbl in ds.get("tables", []):
            tbl_name = tbl["name"]
            ds_to_table[ds_name] = tbl_name
            ds_to_table[ds_caption] = tbl_name
            break  # Use first (primary) table

    def _safe_id(name):
        return re.sub(r"[^a-zA-Z0-9_]", "_", name)

    def _resolve_table_generic(col_name, ws):
        """Resolve which PBI table a Tableau field belongs to (generic)."""
        clean = col_name.strip("[]")
        # Check fields_used for datasource context
        for fu in ws.get("fields_used", []):
            fu_col = fu.get("column", "").strip("[]")
            fu_caption = fu.get("caption", "").strip("[]")
            if fu_col == clean or fu_caption == clean:
                ds = fu.get("datasource", "")
                if ds == "Parameters":
                    return "Parameters"
                mapped = ds_to_table.get(ds)
                if mapped and mapped in table_info:
                    return mapped
        # Check datasources_used
        for ds_name in ws.get("datasources_used", []):
            mapped = ds_to_table.get(ds_name)
            if mapped and mapped in table_info:
                return mapped
        # Fall back to _resolve_field against model
        tbl, _, _ = _resolve_field(clean, table_info, field_alias_map)
        if tbl:
            return tbl
        # Last resort: first non-Parameters table
        for tname in table_info:
            if tname != "Parameters":
                return tname
        return list(table_info.keys())[0] if table_info else "Unknown"

    # Map Tableau derivation → PBI Aggregation Function code
    _DERIV_AGG_FUNC = {
        "Sum": 0, "Avg": 1, "Average": 1, "Min": 2, "Max": 3,
        "Count": 4, "CountD": 5,
    }
    # PBI Aggregation Function code → queryRef prefix (must match PBI convention)
    _AGG_PREFIX = {0: "Sum", 1: "Avg", 2: "Min", 3: "Max", 4: "CountNonNull", 5: "Count"}

    def _get_fields_generic(ws):
        """Extract fields from Tableau rows/cols shelf positions.

        Uses rows_text and cols_text to determine which fields are on
        which axis, instead of blindly iterating fields_used.

        Returns (cat_fields, y_fields) where each entry is:
            (resolved_name, table, derivation, is_model_measure)
        """
        rows_text = ws.get("rows_text", "")
        cols_text = ws.get("cols_text", "")

        # Parse shelf field references
        col_refs = _parse_shelf_refs(cols_text)
        row_refs = _parse_shelf_refs(rows_text)

        cat_fields = []  # dimensions -> Category / X-axis
        y_fields = []    # measures/aggs -> Y-axis values
        seen = set()

        def _try_resolve(field_name):
            """Resolve a field name through the model, return tuple or None.
            
            Prefers the worksheet's own datasource table to avoid
            resolving e.g. 'Sales' to the wrong table when multiple
            tables share the same column name.
            """
            mapped = field_alias_map.get(field_name)
            candidates = [field_name]
            if mapped:
                candidates.append(mapped)

            # 1. Try ws-specific table (datasource context)
            ws_tbl = _resolve_table_generic(field_name, ws)
            if ws_tbl and ws_tbl in table_info:
                ti = table_info[ws_tbl]
                for c in candidates:
                    if c in ti.get("measures", set()):
                        return (c, ws_tbl, True)
                    if c in ti.get("columns", set()):
                        return (c, ws_tbl, False)

            # 2. Fallback: global resolve across all tables
            for c in candidates:
                tbl, rname, is_meas = _resolve_field(c, table_info, field_alias_map)
                if tbl is not None:
                    return (rname, tbl, is_meas)
            return None

        def _add_field(field_name, prefix, kind, target_list):
            """Resolve and add a field to the target list."""
            if field_name in seen:
                return
            resolved = _try_resolve(field_name)
            if resolved is None:
                return
            rname, tbl, is_model_meas = resolved
            if rname in seen:
                return
            seen.add(rname)
            seen.add(field_name)
            deriv = _PREFIX_TO_DERIV.get(prefix, "")
            target_list.append((rname, tbl, deriv, is_model_meas))

        # ── Check for special shelf markers ──
        all_refs = col_refs + row_refs
        has_measure_names = any(k == 'measure_names' for _, _, k in all_refs)
        has_geo = any(k == 'geo' for _, _, k in all_refs)
        # Filter out markers for field processing
        col_refs_clean = [(f, p, k) for f, p, k in col_refs if k not in ('measure_names', 'geo')]
        row_refs_clean = [(f, p, k) for f, p, k in row_refs if k not in ('measure_names', 'geo')]

        # ── Strategy: use shelf parsing when available ──
        if col_refs_clean or row_refs_clean:
            # COLS shelf: dimensions → Category, aggregated → Y
            for fname, prefix, kind in col_refs_clean:
                if kind == 'dim':
                    _add_field(fname, prefix, kind, cat_fields)
                else:  # agg
                    _add_field(fname, prefix, kind, y_fields)

            # ROWS shelf: dimensions → Category (secondary grouping)
            #             aggregated fields → Y-axis values
            for fname, prefix, kind in row_refs_clean:
                if kind == 'dim':
                    _add_field(fname, prefix, kind, cat_fields)
                else:  # agg
                    _add_field(fname, prefix, kind, y_fields)

        # ── When :Measure Names / Multiple Values detected, pull
        #    measures from the Measure Names filter members (which measures
        #    the worksheet actually displays) or fall back to fields_used. ──
        if has_measure_names:
            y_fields.clear()
            seen_y = set()
            mn_members = ws.get("mn_members", [])
            if mn_members:
                # Use the explicit member list from the :Measure Names filter
                for prefix, field_name in mn_members:
                    # Resolve calc names through alias map
                    resolved_name = field_alias_map.get(field_name, field_name)
                    # Try resolving variants: original, alias, stripped "(copy)"
                    for candidate in (resolved_name, field_name,
                                     re.sub(r'\s*\(copy\)$', '', resolved_name, flags=re.IGNORECASE)):
                        resolved = _try_resolve(candidate)
                        if resolved:
                            rname, tbl, is_meas = resolved
                            if rname not in seen and rname not in seen_y:
                                seen.add(rname)
                                seen_y.add(rname)
                                deriv = _PREFIX_TO_DERIV.get(prefix, "")
                                y_fields.append((rname, tbl, deriv, is_meas))
                            break
            else:
                # Fallback: pull all quantitative fields_used
                for fu in ws.get("fields_used", []):
                    deriv = fu.get("derivation", "")
                    ftype = fu.get("type", "")
                    col = fu.get("column", "").strip("[]")
                    caption = fu.get("caption", "").strip("[]")
                    name = caption if fu.get("is_calculated") and caption else col
                    if not name or name.startswith("__"):
                        # Try alias map for Calculation_ names
                        mapped = field_alias_map.get(col)
                        if mapped:
                            name = mapped
                        else:
                            continue
                    if name.startswith("Calculation_"):
                        mapped = field_alias_map.get(name)
                        if mapped:
                            name = mapped
                        else:
                            continue
                    if ftype == "quantitative" and deriv in ("Sum", "Avg", "Min", "Max", "CountD", "Count", "User"):
                        resolved = _try_resolve(name)
                        if resolved:
                            rname, tbl, is_meas = resolved
                            if rname not in seen and rname not in seen_y:
                                seen.add(rname)
                                seen_y.add(rname)
                                y_fields.append((rname, tbl, deriv, is_meas))

        # ── For maps: pull geographic dimension fields ──
        # Priority: detail encoding dims first (they define map granularity),
        # then supplement from fields_used.
        if has_geo and not cat_fields:
            geo_names = {"State/Province", "Country/Region", "City", "Region",
                         "Postal Code", "State", "Country", "Latitude", "Longitude"}
            # 1. Detail encoding dimensions first (State/Province etc.)
            for enc_field in ws.get("encodings", {}).get("detail", []):
                resolved = _try_resolve(enc_field)
                if resolved:
                    rname, tbl, is_meas = resolved
                    if not is_meas and rname not in seen:
                        seen.add(rname)
                        cat_fields.append((rname, tbl, "", False))
            # 2. Supplement from fields_used for any additional geo fields
            for fu in ws.get("fields_used", []):
                if fu.get("is_calculated"):
                    continue
                col = fu.get("column", "").strip("[]")
                ftype = fu.get("type", "")
                deriv = fu.get("derivation", "")
                if col in geo_names and ftype == "nominal" and deriv == "None":
                    resolved = _try_resolve(col)
                    if resolved:
                        rname, tbl, _ = resolved
                        if rname not in seen:
                            seen.add(rname)
                            cat_fields.append((rname, tbl, "", False))
            # 3. Color/detail encoding measures for the map value
            for enc_type in ("color", "detail"):
                for enc_field in ws.get("encodings", {}).get(enc_type, []):
                    resolved = _try_resolve(enc_field)
                    if resolved:
                        rname, tbl, is_meas = resolved
                        if is_meas and rname not in seen:
                            seen.add(rname)
                            y_fields.append((rname, tbl, "", True))

        # ── Parse encoding values for measures ──
        # Priority 1: text encoding (card values, matrix cell values)
        if not y_fields:
            enc_text_fields = ws.get("encodings", {}).get("text", [])
            enc_text_raw = ws.get("encoding_raw", {}).get("text", [])
            for i, enc_field in enumerate(enc_text_fields):
                resolved = _try_resolve(enc_field)
                if resolved:
                    rname, tbl, is_meas = resolved
                    if rname not in seen:
                        # Determine prefix from raw ref to distinguish agg vs dim
                        prefix = ""
                        if i < len(enc_text_raw):
                            em = re.search(r'\[([^\]]+)\]$', enc_text_raw[i])
                            if em:
                                p0 = em.group(1).split(':')[0]
                                if p0 in _AGG_PREFIXES:
                                    prefix = p0
                        # Only add to y_fields if it's a measure or has agg prefix
                        if is_meas or prefix:
                            seen.add(rname)
                            deriv = _PREFIX_TO_DERIV.get(prefix, "")
                            y_fields.append((rname, tbl, deriv, is_meas))
                        else:
                            # Dimension from text encoding → category
                            seen.add(rname)
                            cat_fields.append((rname, tbl, "", False))

        # Priority 2: wedge-size encoding (pie chart value)
        ws_wedge = ws.get("encodings", {}).get("wedge-size", [])
        ws_wedge_raw = ws.get("encoding_raw", {}).get("wedge-size", [])
        for i, enc_field in enumerate(ws_wedge):
            resolved = _try_resolve(enc_field)
            if resolved:
                rname, tbl, is_meas = resolved
                if rname not in seen:
                    seen.add(rname)
                    prefix = ""
                    if i < len(ws_wedge_raw):
                        em = re.search(r'\[([^\]]+)\]$', ws_wedge_raw[i])
                        if em:
                            p0 = em.group(1).split(':')[0]
                            if p0 in _AGG_PREFIXES:
                                prefix = p0
                    deriv = _PREFIX_TO_DERIV.get(prefix, "Sum")
                    y_fields.append((rname, tbl, deriv, is_meas))

        # Priority 3: color/size/tooltip encoding fallback
        if not y_fields:
            for enc_type in ("color", "size", "tooltip"):
                for enc_field in ws.get("encodings", {}).get(enc_type, []):
                    resolved = _try_resolve(enc_field)
                    if resolved:
                        rname, tbl, is_meas = resolved
                        if rname not in seen:
                            seen.add(rname)
                            y_fields.append((rname, tbl, "", is_meas))

        if (not col_refs_clean and not row_refs_clean and not has_measure_names
                and not has_geo and not cat_fields and not y_fields):
            # Fallback: use fields_used when no shelf text available
            for fu in ws.get("fields_used", []):
                # Skip Parameter datasource fields in fallback (they are config, not data)
                if fu.get("datasource", "") == "Parameters":
                    continue
                col = fu.get("column", "").strip("[]")
                caption = fu.get("caption", "").strip("[]")
                name = caption if fu.get("is_calculated") and caption else col
                if not name or name.startswith("Calculation_") or name.startswith("__") or name in seen:
                    if caption and caption not in seen:
                        name = caption
                    elif name.startswith("Calculation_"):
                        mapped = field_alias_map.get(name)
                        if mapped and mapped not in seen:
                            name = mapped
                        else:
                            continue
                    else:
                        continue
                seen.add(name)
                tbl, resolved_name, is_model_meas = _resolve_field(
                    name, table_info, field_alias_map)
                if tbl is None:
                    tbl = _resolve_table_generic(name, ws)
                    if tbl is None:
                        continue
                    resolved_name = name
                    is_model_meas = resolved_name in table_info.get(
                        tbl, {}).get("measures", set())
                ti = table_info.get(tbl, {})
                if (resolved_name not in ti.get("columns", set()) and
                        resolved_name not in ti.get("measures", set())):
                    continue
                deriv = fu.get("derivation", "")
                ftype = fu.get("type", "")
                if (fu.get("is_calculated") or ftype == "quantitative" or
                        deriv in ("Sum", "Avg", "Min", "Max", "CountD",
                                  "Count", "User") or is_model_meas):
                    y_fields.append((resolved_name, tbl, deriv, is_model_meas))
                else:
                    cat_fields.append((resolved_name, tbl, deriv, False))

        # If still empty, try fields list
        if not cat_fields and not y_fields:
            for f in ws.get("fields", []):
                tbl, rname, is_meas = _resolve_field(
                    f, table_info, field_alias_map)
                if tbl is None or rname in seen:
                    continue
                seen.add(rname)
                if is_meas:
                    y_fields.append((rname, tbl, "", True))
                else:
                    cat_fields.append((rname, tbl, "", False))

        return cat_fields, y_fields

    def _common_slicers(ws_list):
        """Detect common slicer-candidate fields across worksheets."""
        candidates = {"Category", "Segment", "Region", "Ship Mode",
                      "Order Date", "Year", "Date", "Country", "State",
                      "Product", "Department", "Type"}
        found, seen_fields = [], set()
        for ws_name in ws_list:
            ws = ws_map.get(ws_name, {})
            for fu in ws.get("fields_used", []):
                col = fu.get("column", "").strip("[]")
                if col in candidates and col not in seen_fields:
                    tbl = _resolve_table_generic(col, ws)
                    if tbl and tbl in table_info and col in table_info[tbl]["columns"]:
                        found.append((col, tbl))
                        seen_fields.add(col)
        # Also check the fields list
        if not found:
            for ws_name in ws_list:
                ws = ws_map.get(ws_name, {})
                for f in ws.get("fields", []):
                    clean = _strip_tableau_agg(f)
                    if clean in candidates and clean not in seen_fields:
                        tbl, fname, is_meas = _resolve_field(clean, table_info, field_alias_map)
                        if tbl and not is_meas:
                            found.append((fname, tbl))
                            seen_fields.add(clean)
        return found[:4]

    def _slicer_config(vis_name, table, field, x, y, w, h, z):
        alias = table[0].lower()
        qref = alias + "." + field
        return {
            "singleVisual": {
                "visualType": "slicer",
                "projections": {"Values": [{"queryRef": qref}]},
                "prototypeQuery": {
                    "Version": 2,
                    "From": [{"Name": alias, "Entity": table, "Type": 0}],
                    "Select": [{"Column": {
                        "Expression": {"SourceRef": {"Source": alias}},
                        "Property": field}, "Name": qref}],
                },
                "drillFilterOtherVisuals": True,
                "vcObjects": {
                    "title": [{"properties": {
                        "text": {"expr": {"Literal": {"Value": "'" + field + "'"}}},
                        "show": {"expr": {"Literal": {"Value": "true"}}},
                    }}],
                    "border": [{"properties": {
                        "show": {"expr": {"Literal": {"Value": "true"}}},
                        "color": {"solid": {"color": {"expr": {"Literal": {"Value": "'#E6E6E6'"}}}}},
                    }}],
                },
            },
            "name": vis_name,
            "layouts": [{"id": 0, "position": {
                "x": x, "y": y, "z": z,
                "width": w, "height": h, "tabOrder": z * 1000}}],
        }

    def _resolve_color_legend(ws):
        """Extract color encoding dimension fields for use as Legend/Series.

        When the color encoding uses a date derivation (yr, mn, qr, etc.)
        of a field already on the Category axis, creates an auto-derived
        column so PBI can show it as a separate Series.
        """
        legend = []
        color_raws = ws.get("encoding_raw", {}).get("color", [])
        for idx, enc_field in enumerate(ws.get("encodings", {}).get("color", [])):
            mapped = field_alias_map.get(enc_field, enc_field)
            candidates = [enc_field]
            if mapped != enc_field:
                candidates.append(mapped)
            # Detect date-part prefix from raw encoding ref
            color_prefix = ""
            if idx < len(color_raws):
                em = re.search(r'\[([^\]]+)\]$', color_raws[idx])
                if em:
                    p0 = em.group(1).split(':')[0]
                    if p0 in _DIM_PREFIXES and p0 != "none":
                        color_prefix = p0
            found = False
            for c in candidates:
                tbl, rname, is_meas = _resolve_field(c, table_info, field_alias_map)
                if tbl is not None and not is_meas:
                    legend.append((rname, tbl, color_prefix))
                    found = True
                    break
            if not found:
                ws_tbl = _resolve_table_generic(enc_field, ws)
                if ws_tbl and ws_tbl in table_info:
                    ti = table_info[ws_tbl]
                    for c in candidates:
                        if c in ti.get("columns", set()) and c not in ti.get("measures", set()):
                            legend.append((c, ws_tbl, color_prefix))
                            break
        return legend

    def _visual_config(vis_name, vis_type, ws, title, x, y, w, h, z,
                       override_dims=None, override_meas=None):
        dims = override_dims if override_dims is not None else None
        meas = override_meas if override_meas is not None else None
        if dims is None or meas is None:
            _d, _m = _get_fields_generic(ws)
            if dims is None:
                dims = _d
            if meas is None:
                meas = _m
        from_c, sel_c, proj, alias_map_local = [], [], {}, {}

        def _alias(table):
            if table not in alias_map_local:
                alias_map_local[table] = table[0].lower() + str(len(alias_map_local))
            return alias_map_local[table]

        def _add_from(table):
            a = _alias(table)
            if not any(fc["Entity"] == table for fc in from_c):
                from_c.append({"Name": a, "Entity": table, "Type": 0})
            return a

        def _make_select_entry(fname, ftable, derivation, is_model_meas):
            """Build the correct Select entry depending on field type."""
            a = _add_from(ftable)
            if is_model_meas:
                # Actual measure in the model → Measure reference
                qr = a + "." + fname
                entry = {"Measure": {
                    "Expression": {"SourceRef": {"Source": a}},
                    "Property": fname}, "Name": qr}
            else:
                # Column in the model → needs Aggregation wrapper
                agg_func = _DERIV_AGG_FUNC.get(derivation, 0)  # default Sum
                qr = _AGG_PREFIX.get(agg_func, "Sum") + "(" + a + "." + fname + ")"
                entry = {"Aggregation": {
                    "Expression": {"Column": {
                        "Expression": {"SourceRef": {"Source": a}},
                        "Property": fname}},
                    "Function": agg_func}, "Name": qr}
            return qr, entry

        # Determine field limits based on visual type
        _unlimited = {"tableEx", "pivotTable", "card"}
        if vis_type in _unlimited:
            dim_limit = None
        elif vis_type in ("scatterChart", "pieChart", "treemap", "funnel"):
            dim_limit = 2
        else:
            dim_limit = 4
        meas_limit = None if vis_type in _unlimited else 4
        used_dims = dims if dim_limit is None else dims[:dim_limit]
        used_meas = list(meas if meas_limit is None else meas[:meas_limit])

        # ── For matrices/tables: move non-measure columns from used_meas
        #    to used_dims so they don't generate invalid Measure references. ──
        if vis_type in ("pivotTable", "tableEx") and used_meas:
            _real_meas, _moved = [], []
            for _m in used_meas:
                mname, mtable, mderiv, is_mm = _m
                if is_mm:
                    _real_meas.append(_m)
                elif mderiv and mderiv not in ("None", "User"):
                    # Has aggregation → keep as measure with correct is_model_meas=False
                    _real_meas.append(_m)
                else:
                    # Non-measure column with no aggregation → move to dimensions
                    _moved.append((mname, mtable, "", False))
            if _moved:
                used_dims = list(used_dims) + _moved
                used_meas = _real_meas

        # ── Card auto-measures: create DAX measures for encoding-derived ──
        # aggregations so cards always reference proper measures instead of
        # unreliable column-level Aggregation entries.
        if vis_type == "card" and used_meas:
            _AUTO_AGG_DAX = {
                "Count": "COUNTA", "Sum": "SUM", "Avg": "AVERAGE",
                "Min": "MIN", "Max": "MAX", "CountD": "DISTINCTCOUNT",
            }
            # Collect column datatypes for the table to avoid SUM on strings
            _col_dtypes = {}
            for t in model_tables:
                if t["name"] in {mt for _, mt, _, _ in used_meas}:
                    for c in t.get("columns", []):
                        _col_dtypes[(t["name"], c["name"])] = c.get("dataType", "string")
            new_meas = []
            for mname, mtable, mderiv, is_mm in used_meas:
                if is_mm or not mderiv:
                    new_meas.append((mname, mtable, mderiv, is_mm))
                    continue
                dax_func = _AUTO_AGG_DAX.get(mderiv)
                if not dax_func:
                    new_meas.append((mname, mtable, mderiv, is_mm))
                    continue
                # For string/text columns, use MAX instead of SUM/AVERAGE
                col_dt = _col_dtypes.get((mtable, mname), "string")
                if col_dt == "string" and dax_func in ("SUM", "AVERAGE"):
                    dax_func = "MAX"
                # Build measure name and DAX expression
                auto_name = f"{mderiv} of {mname}"
                tref = f"'{mtable}'[{mname}]"
                dax_expr = f"{dax_func}({tref})"
                # Add to model if not already present
                for t in model_tables:
                    if t["name"] == mtable:
                        existing = {m["name"] for m in t.get("measures", [])}
                        if auto_name not in existing:
                            t.setdefault("measures", []).append({
                                "name": auto_name,
                                "expression": dax_expr,
                            })
                            table_info.setdefault(mtable, {}).setdefault(
                                "measures", set()).add(auto_name)
                        break
                new_meas.append((auto_name, mtable, "", True))
            used_meas = new_meas

        if used_dims:
            if vis_type == "pivotTable":
                # Matrix: split dims into Rows and Columns based on shelf origin
                rows_text = ws.get("rows_text", "") if ws else ""
                cols_text = ws.get("cols_text", "") if ws else ""
                row_shelf = {f for f, _, k in _parse_shelf_refs(rows_text) if k == 'dim'}
                col_shelf = {f for f, _, k in _parse_shelf_refs(cols_text) if k == 'dim'}
                row_items, col_items = [], []
                for dname, dtable, dderiv, _ in used_dims:
                    a = _add_from(dtable)
                    qr = a + "." + dname
                    sel_c.append({"Column": {
                        "Expression": {"SourceRef": {"Source": a}},
                        "Property": dname}, "Name": qr})
                    if dname in col_shelf:
                        col_items.append({"queryRef": qr})
                    else:
                        row_items.append({"queryRef": qr})
                if row_items:
                    proj["Rows"] = row_items
                if col_items:
                    proj["Columns"] = col_items
            elif vis_type == "tableEx":
                val_items = []
                for dname, dtable, dderiv, _ in used_dims:
                    a = _add_from(dtable)
                    qr = a + "." + dname
                    val_items.append({"queryRef": qr})
                    sel_c.append({"Column": {
                        "Expression": {"SourceRef": {"Source": a}},
                        "Property": dname}, "Name": qr})
                proj["Values"] = val_items
            else:
                cat_items = []
                for dname, dtable, dderiv, _ in used_dims:
                    a = _add_from(dtable)
                    qr = a + "." + dname
                    cat_items.append({"queryRef": qr})
                    sel_c.append({"Column": {
                        "Expression": {"SourceRef": {"Source": a}},
                        "Property": dname}, "Name": qr})
                proj["Category"] = cat_items

        if used_meas:
            y_items = []
            for mname, mtable, mderiv, is_mm in used_meas:
                qr, entry = _make_select_entry(mname, mtable, mderiv, is_mm)
                y_items.append({"queryRef": qr})
                sel_c.append(entry)
            if vis_type == "card":
                proj["Fields"] = y_items
            elif vis_type == "tableEx":
                proj.setdefault("Values", []).extend(y_items)
            elif vis_type == "pivotTable":
                proj["Values"] = y_items
            elif vis_type == "scatterChart" and len(y_items) >= 2:
                proj["X"] = [y_items[0]]
                proj["Y"] = [y_items[1]]
                if len(y_items) > 2:
                    proj["Size"] = [y_items[2]]
            elif vis_type == "scatterChart":
                # Only 1 measure → not enough for scatter X+Y; downgrade
                vis_type = "clusteredBarChart"
                proj["Y"] = y_items
            else:
                proj["Y"] = y_items

        # ── Legend / Series from color encoding (dimension fields only) ──
        _LEGEND_TYPES = {"clusteredBarChart", "clusteredColumnChart",
                         "lineChart", "areaChart", "pieChart",
                         "stackedBarChart", "stackedColumnChart",
                         "hundredPercentStackedBarChart"}
        _DATE_PART_DAX = {
            "yr": ("Year", "YEAR({src})"),
            "mn": ("Month", "FORMAT({src}, \"MMM\")"),
            "qr": ("Quarter", "\"Q\" & FORMAT({src}, \"Q\")"),
        }
        if vis_type in _LEGEND_TYPES and ws:
            color_dims = _resolve_color_legend(ws)
            if color_dims:
                legend_items = []
                for lname, ltable, cprefix in color_dims:
                    in_cat = any(d[0] == lname for d in (dims or []))
                    if in_cat and cprefix and cprefix in _DATE_PART_DAX:
                        # Same field at different date granularity → auto-derive column
                        part_label, dax_tmpl = _DATE_PART_DAX[cprefix]
                        auto_col = f"{part_label} of {lname}"
                        tref = f"'{ltable}'[{lname}]" if " " in ltable else f"{ltable}[{lname}]"
                        dax_expr = dax_tmpl.format(src=tref)
                        # Add calculated column to model
                        for t in model_tables:
                            if t["name"] == ltable:
                                existing = {c["name"] for c in t.get("columns", [])}
                                if auto_col not in existing:
                                    t.setdefault("columns", []).append({
                                        "name": auto_col, "dataType": "string",
                                        "type": "calculated",
                                        "expression": dax_expr,
                                    })
                                    table_info.setdefault(ltable, {}).setdefault(
                                        "columns", set()).add(auto_col)
                                break
                        a = _add_from(ltable)
                        qr = a + "." + auto_col
                        legend_items.append({"queryRef": qr})
                        sel_c.append({"Column": {
                            "Expression": {"SourceRef": {"Source": a}},
                            "Property": auto_col}, "Name": qr})
                    elif in_cat:
                        continue
                    else:
                        a = _add_from(ltable)
                        qr = a + "." + lname
                        legend_items.append({"queryRef": qr})
                        sel_c.append({"Column": {
                            "Expression": {"SourceRef": {"Source": a}},
                            "Property": lname}, "Name": qr})
                if legend_items:
                    if vis_type == "pieChart":
                        proj["Category"] = legend_items
                    else:
                        proj["Series"] = legend_items

        # ── Encoding-based projections (Tooltip, Size, Details) ──────────
        _existing_qrefs = set()
        _existing_base_fields = set()   # "source.Property" stripped from Agg(…)
        for _bucket in proj.values():
            if isinstance(_bucket, list):
                for _item in _bucket:
                    if isinstance(_item, dict) and "queryRef" in _item:
                        _qr = _item["queryRef"]
                        _existing_qrefs.add(_qr)
                        _m = re.match(r'\w+\((.+)\)$', _qr)
                        _existing_base_fields.add(_m.group(1) if _m else _qr)

        def _resolve_enc(enc_field_name):
            """Resolve an encoding field to (name, table, is_meas) or None."""
            mapped_e = field_alias_map.get(enc_field_name, enc_field_name)
            for _cand in (mapped_e, enc_field_name):
                _tbl, _rn, _im = _resolve_field(_cand, table_info, field_alias_map)
                if _tbl:
                    return (_rn, _tbl, _im)
            _tbl = _resolve_table_generic(enc_field_name, ws) if ws else None
            if _tbl and _tbl in table_info:
                _ti = table_info[_tbl]
                for _cand in (mapped_e, enc_field_name):
                    if _cand in _ti.get("measures", set()):
                        return (_cand, _tbl, True)
                    if _cand in _ti.get("columns", set()):
                        return (_cand, _tbl, False)
            return None

        # Tooltip encoding → Tooltips projection
        _TOOLTIP_TYPES = {"clusteredBarChart", "clusteredColumnChart",
                          "lineChart", "areaChart", "scatterChart",
                          "stackedBarChart", "stackedColumnChart", "filledMap",
                          "treemap", "pieChart", "pivotTable"}
        if vis_type in _TOOLTIP_TYPES and ws:
            _tt_enc = ws.get("encodings", {}).get("tooltip", [])
            if _tt_enc:
                _tt_items = []
                for _tf in _tt_enc:
                    _r = _resolve_enc(_tf)
                    if _r:
                        _rn, _tbl, _im = _r
                        _qr, _entry = _make_select_entry(_rn, _tbl, "" if _im else "Sum", _im)
                        if _qr not in _existing_qrefs:
                            _tt_items.append({"queryRef": _qr})
                            sel_c.append(_entry)
                            _existing_qrefs.add(_qr)
                if _tt_items:
                    proj["Tooltips"] = _tt_items

        # Size encoding → Size projection (scatter charts)
        if vis_type == "scatterChart" and ws and "Size" not in proj:
            _sz_enc = ws.get("encodings", {}).get("size", [])
            if _sz_enc:
                _r = _resolve_enc(_sz_enc[0])
                if _r:
                    _rn, _tbl, _im = _r
                    _qr, _entry = _make_select_entry(_rn, _tbl, "" if _im else "Sum", _im)
                    if _qr not in _existing_qrefs:
                        proj["Size"] = [{"queryRef": _qr}]
                        sel_c.append(_entry)
                        _existing_qrefs.add(_qr)

        # Detail encoding → Details projection (scatter charts)
        if vis_type == "scatterChart" and ws:
            _det_enc = ws.get("encodings", {}).get("detail", [])
            if _det_enc:
                _det_items = []
                for _df in _det_enc:
                    _r = _resolve_enc(_df)
                    if _r:
                        _rn, _tbl, _im = _r
                        if not _im:  # only dimension fields as details
                            _a = _add_from(_tbl)
                            _qr = _a + "." + _rn
                            if _qr not in _existing_qrefs and _qr not in _existing_base_fields:
                                _det_items.append({"queryRef": _qr})
                                sel_c.append({"Column": {
                                    "Expression": {"SourceRef": {"Source": _a}},
                                    "Property": _rn}, "Name": _qr})
                                _existing_qrefs.add(_qr)
                if _det_items:
                    proj["Details"] = _det_items

        # ── For line/area charts: separate date dims (X-axis) from
        #    non-date dims (→ Series) to avoid cluttered hierarchical axis.
        #    Only applies when color encoding didn't already create a Series. ──
        _CHART_DATE_SPLIT = {"areaChart", "lineChart"}
        if (vis_type in _CHART_DATE_SPLIT and ws
                and "Category" in proj and len(proj.get("Category", [])) >= 2):
            _DATE_SHELF_PX = {"yr", "mn", "qr", "tmn", "twk", "tdy",
                              "tyr", "tqr", "wk", "dy", "mdy"}
            _rt = ws.get("rows_text", "") or ""
            _ct = ws.get("cols_text", "") or ""
            _all_shelf = _parse_shelf_refs(_rt) + _parse_shelf_refs(_ct)
            _date_names = set()
            for _fn, _px, _kn in _all_shelf:
                if _kn == "dim" and _px in _DATE_SHELF_PX:
                    _date_names.add(_fn)
            for _item in proj["Category"]:
                _qf = _item["queryRef"].split(".")[-1]
                if any(_kw in _qf.lower() for _kw in (" date", "date")):
                    _date_names.add(_qf)
            _cat_date = [i for i in proj["Category"]
                         if i["queryRef"].split(".")[-1] in _date_names]
            _cat_other = [i for i in proj["Category"]
                          if i["queryRef"].split(".")[-1] not in _date_names]
            if _cat_date and _cat_other:
                proj["Category"] = _cat_date
                if "Series" not in proj:
                    proj["Series"] = _cat_other
                else:
                    # Extend existing Series (from color encoding) with non-date dims
                    _existing_series_qrefs = {s["queryRef"] for s in proj["Series"]}
                    for _co in _cat_other:
                        if _co["queryRef"] not in _existing_series_qrefs:
                            proj["Series"].append(_co)

        if not proj:
            vis_type = "tableEx"
            proj = {"Values": []}

        # Sanitize title for PBI Literal.Value format (single-quoted string)
        safe_title = title.replace("'", "''")

        return {
            "singleVisual": {
                "visualType": vis_type,
                "projections": proj,
                "prototypeQuery": {"Version": 2, "From": from_c, "Select": sel_c},
                "drillFilterOtherVisuals": True,
                "vcObjects": {
                    "title": [{"properties": {
                        "text": {"expr": {"Literal": {"Value": "'" + safe_title + "'"}}},
                        "show": {"expr": {"Literal": {"Value": "true"}}},
                        "fontSize": {"expr": {"Literal": {"Value": "12D"}}},
                    }}],
                    "border": [{"properties": {
                        "show": {"expr": {"Literal": {"Value": "true"}}},
                        "color": {"solid": {"color": {"expr": {"Literal": {"Value": "'#E6E6E6'"}}}}},
                    }}],
                },
            },
            "name": vis_name,
            "layouts": [{"id": 0, "position": {
                "x": x, "y": y, "z": z,
                "width": w, "height": h, "tabOrder": z * 1000}}],
        }

    # ── Build sections ────────────────────────────────────────────────────
    sections = []

    # Visual types that should NOT be split (tables, cards, etc.)
    _NO_SPLIT_TYPES = {"tableEx", "pivotTable", "card", "slicer", "scatterChart",
                       "filledMap", "treemap", "gauge", "funnel"}

    def _scale_zone(zone, pbi_w, pbi_h, tab_w, tab_h, x_off=0, y_off=0):
        """Scale a Tableau zone position to PBI page coordinates."""
        sx = pbi_w / max(tab_w, 1)
        sy = pbi_h / max(tab_h, 1)
        return (
            int(zone["x"] * sx) + x_off,
            int(zone["y"] * sy) + y_off,
            max(int(zone["w"] * sx) - 4, 80),
            max(int(zone["h"] * sy) - 4, 60),
        )

    def _analyze_ws(ws):
        """Analyze worksheet for visual type inference - returns (dims, meas, kwargs_dict)."""
        dims_tmp, meas_tmp = _get_fields_generic(ws)
        _ws_cols = ws.get("cols_text", "") or ""
        _ws_rows = ws.get("rows_text", "") or ""
        _has_pcto = "pcto:" in _ws_cols or "pcto:" in _ws_rows
        _color_dims = _resolve_color_legend(ws)
        _has_enc_text = bool(ws.get("encodings", {}).get("text", []))
        _has_wedge = bool(ws.get("encodings", {}).get("wedge-size", []))
        _col_shelf = _parse_shelf_refs(_ws_cols)
        _row_shelf = _parse_shelf_refs(_ws_rows)
        _has_row_dims = any(k == 'dim' for _, _, k in _row_shelf)
        _has_col_dims = any(k == 'dim' for _, _, k in _col_shelf)
        _has_mn = any(k == 'measure_names' for _, _, k in _col_shelf + _row_shelf)
        return dims_tmp, meas_tmp, {
            "has_pcto": _has_pcto, "has_color_dim": bool(_color_dims),
            "has_row_dims": _has_row_dims, "has_col_dims": _has_col_dims,
            "has_encoding_text": _has_enc_text, "has_wedge_size": _has_wedge,
            "has_measure_names": _has_mn,
        }

    def _textbox_config(vis_name, text, x, y, w, h, z, font_size="14px",
                        font_family="Segoe UI Semibold", bold=False,
                        alignment="left"):
        """Build a PBI textbox visual config."""
        text_style = {
            "fontFamily": font_family,
            "fontSize": font_size,
        }
        if bold:
            text_style["fontWeight"] = "bold"
        paragraph = {"textRuns": [{
            "value": text,
            "textStyle": text_style,
        }]}
        if alignment and alignment != "left":
            paragraph["horizontalTextAlignment"] = alignment
        return {
            "singleVisual": {
                "visualType": "textbox",
                "objects": {"general": [{"properties": {
                    "paragraphs": [paragraph],
                }}]},
                "vcObjects": {
                    "border": [{"properties": {
                        "show": {"expr": {"Literal": {"Value": "false"}}},
                    }}],
                },
            },
            "name": vis_name,
            "layouts": [{"id": 0, "position": {
                "x": x, "y": y, "z": z,
                "width": w, "height": h, "tabOrder": z * 1000}}],
        }

    for db in dashboards:
        db_name = db["name"]
        page_name = "ReportSection_" + _safe_id(db_name)
        ws_list = db.get("worksheet_refs", [])
        zones = db.get("zones", [])
        width = PAGE_WIDTH
        height = PAGE_HEIGHT

        visuals = []
        vis_count = 0

        # ── Page title textbox — prefer Tableau text zone content ──
        text_zones_list = list(db.get("text_zones", []))
        page_title_text = db_name
        if text_zones_list:
            # Use the first (topmost) text zone as the report title
            text_zones_list.sort(key=lambda tz: tz["y"])
            page_title_text = text_zones_list[0]["text"].replace("\xa0", " ")
            text_zones_list = text_zones_list[1:]  # remaining text zones rendered later

        title_h = 52
        vn_title = "vis_" + _safe_id(db_name) + "_title"
        title_cfg = _textbox_config(vn_title, page_title_text, 10, 4, width - 20, title_h,
                                    vis_count, font_size="24px", bold=True,
                                    alignment="center")
        visuals.append({
            "x": 10, "y": 4, "z": vis_count,
            "width": width - 20, "height": title_h,
            "config": json.dumps(title_cfg), "filters": "[]",
            "tabOrder": vis_count * 1000,
        })
        vis_count += 1

        # Slicers at top — prefer actual dashboard filter zones over heuristic
        db_filter_zones = db.get("filter_zones", [])
        if db_filter_zones:
            slicer_fields = []
            _sl_seen = set()
            for _fz in db_filter_zones:
                if _fz in _sl_seen:
                    continue
                for _ws_n in ws_list:
                    _ws_s = ws_map.get(_ws_n, {})
                    if _ws_s:
                        _tbl = _resolve_table_generic(_fz, _ws_s)
                        if _tbl and _tbl in table_info and _fz in table_info[_tbl]["columns"]:
                            slicer_fields.append((_fz, _tbl))
                            _sl_seen.add(_fz)
                            break
        else:
            slicer_fields = _common_slicers(ws_list)
        slicer_fields = slicer_fields[:6]
        slicer_y = title_h + 8
        slicer_h = 50 if slicer_fields else 0
        sx = 10
        slicer_w = max(150, (width - 20 - 10 * max(len(slicer_fields) - 1, 0))
                       // max(len(slicer_fields), 1))
        for sf, st in slicer_fields:
            vn = "vis_" + _safe_id(db_name) + "_" + str(vis_count).zfill(3)
            cfg = _slicer_config(vn, st, sf, sx, slicer_y, slicer_w, slicer_h, vis_count)
            visuals.append({
                "x": sx, "y": slicer_y, "z": vis_count,
                "width": slicer_w, "height": slicer_h,
                "config": json.dumps(cfg), "filters": "[]",
                "tabOrder": vis_count * 1000,
            })
            sx += slicer_w + 10
            vis_count += 1

        # ── Use Tableau zone positions when available ──
        zone_map = {z["name"]: z for z in zones}
        has_zones = bool(zones) and all(
            z.get("w", 0) > 0 and z.get("h", 0) > 0 for z in zones)

        if has_zones:
            # Find bounding box of all zones
            all_x = [z["x"] for z in zones]
            all_y = [z["y"] for z in zones]
            all_r = [z["x"] + z["w"] for z in zones]
            all_b = [z["y"] + z["h"] for z in zones]
            tab_w = max(all_r) - min(all_x) if all_x else 100000
            tab_h = max(all_b) - min(all_y) if all_y else 100000
            min_x, min_y = min(all_x), min(all_y)
            # Normalize zones to origin and compute top offset for slicers
            top_off = title_h + 8 + (slicer_h + 8 if slicer_fields else 0)
            avail_h = height - top_off - 10
            avail_w = width - 20

            for ws_name in ws_list:
                ws = ws_map.get(ws_name, {})
                if not ws:
                    continue
                z = zone_map.get(ws_name)
                if z:
                    norm = {"x": z["x"] - min_x, "y": z["y"] - min_y,
                            "w": z["w"], "h": z["h"]}
                    gx, gy, gw, gh = _scale_zone(
                        norm, avail_w, avail_h, tab_w, tab_h, 10, top_off)
                else:
                    # Fallback: stack below existing zones
                    gx, gy, gw, gh = 10, top_off + vis_count * 160, avail_w, 150

                mark = ws.get("mark_class", "Automatic")
                dims_tmp, meas_tmp, infer_kw = _analyze_ws(ws)
                pbi_type = _infer_visual_type(
                    ws_name, [], len(dims_tmp), len(meas_tmp), mark, **infer_kw)
                title = ws.get("name", ws_name)
                vn = "vis_" + _safe_id(db_name) + "_" + str(vis_count).zfill(3)

                # Split multi-measure cards into individual cards
                if pbi_type == "card" and len(meas_tmp) > 1:
                    n_kpi = len(meas_tmp)
                    kpi_gap = 6
                    kpi_w = (gw - kpi_gap * (n_kpi - 1)) // n_kpi
                    for ki, kpi_field in enumerate(meas_tmp):
                        kx = gx + ki * (kpi_w + kpi_gap)
                        vn = "vis_" + _safe_id(db_name) + "_" + str(vis_count).zfill(3)
                        cfg = _visual_config(
                            vn, "card", ws, kpi_field[0],
                            kx, gy, kpi_w, gh, vis_count,
                            override_dims=[], override_meas=[kpi_field])
                        visuals.append({
                            "x": kx, "y": gy, "z": vis_count,
                            "width": kpi_w, "height": gh,
                            "config": json.dumps(cfg), "filters": "[]",
                            "tabOrder": vis_count * 1000,
                        })
                        vis_count += 1
                # Split multi-measure charts
                elif (len(meas_tmp) >= 3
                        and pbi_type not in _NO_SPLIT_TYPES
                        and len(dims_tmp) > 0):
                    n_sub = len(meas_tmp)
                    sub_cols = min(n_sub, 2)
                    sub_rows = (n_sub + sub_cols - 1) // sub_cols
                    sub_gap = 6
                    sub_w = (gw - sub_gap * (sub_cols - 1)) // sub_cols
                    sub_h = (gh - sub_gap * (sub_rows - 1)) // sub_rows
                    for mi, m_field in enumerate(meas_tmp):
                        sr, sc = mi // sub_cols, mi % sub_cols
                        ssx = gx + sc * (sub_w + sub_gap)
                        ssy = gy + sr * (sub_h + sub_gap)
                        vn = "vis_" + _safe_id(db_name) + "_" + str(vis_count).zfill(3)
                        sub_title = m_field[0]
                        sub_type = "clusteredColumnChart" if pbi_type in (
                            "clusteredColumnChart", "clusteredBarChart"
                        ) else pbi_type
                        cfg = _visual_config(
                            vn, sub_type, ws, sub_title,
                            ssx, ssy, sub_w, sub_h, vis_count,
                            override_dims=dims_tmp, override_meas=[m_field])
                        visuals.append({
                            "x": ssx, "y": ssy, "z": vis_count,
                            "width": sub_w, "height": sub_h,
                            "config": json.dumps(cfg), "filters": "[]",
                            "tabOrder": vis_count * 1000,
                        })
                        vis_count += 1
                else:
                    cfg = _visual_config(vn, pbi_type, ws, title,
                                         gx, gy, gw, gh, vis_count)
                    visuals.append({
                        "x": gx, "y": gy, "z": vis_count,
                        "width": gw, "height": gh,
                        "config": json.dumps(cfg), "filters": "[]",
                        "tabOrder": vis_count * 1000,
                    })
                    vis_count += 1

            # ── Render remaining text zones from the dashboard ──
            for tz in text_zones_list:
                tz_norm = {"x": tz["x"] - min_x, "y": tz["y"] - min_y,
                           "w": tz["w"], "h": tz["h"]}
                tx, ty, tw, th = _scale_zone(
                    tz_norm, avail_w, avail_h, tab_w, tab_h, 10, top_off)
                vn = "vis_" + _safe_id(db_name) + "_txt" + str(vis_count).zfill(3)
                cfg = _textbox_config(vn, tz["text"], tx, ty, tw, th, vis_count)
                visuals.append({
                    "x": tx, "y": ty, "z": vis_count,
                    "width": tw, "height": th,
                    "config": json.dumps(cfg), "filters": "[]",
                    "tabOrder": vis_count * 1000,
                })
                vis_count += 1
        else:
            # Fallback: tiled grid layout (no zone info)
            n = len(ws_list)
            cols_g = 1 if n <= 1 else 2 if n <= 4 else 3
            margin = 10
            top_off = title_h + 8 + (slicer_h + 8 if slicer_fields else 0)
            avail_w = width - margin * 2
            avail_h = height - top_off - margin
            rows_g = max((n + cols_g - 1) // max(cols_g, 1), 1)
            gap = 8
            cell_w = (avail_w - gap * (cols_g - 1)) // max(cols_g, 1)
            cell_h = (avail_h - gap * (rows_g - 1)) // max(rows_g, 1)

            for idx, ws_name in enumerate(ws_list):
                ws = ws_map.get(ws_name, {})
                if not ws:
                    continue
                ri, ci = idx // cols_g, idx % cols_g
                gx = margin + ci * (cell_w + gap)
                gy = top_off + ri * (cell_h + gap)
                mark = ws.get("mark_class", "Automatic")
                dims_tmp, meas_tmp, infer_kw = _analyze_ws(ws)
                pbi_type = _infer_visual_type(
                    ws_name, [], len(dims_tmp), len(meas_tmp), mark, **infer_kw)
                vn = "vis_" + _safe_id(db_name) + "_" + str(vis_count).zfill(3)
                title = ws.get("name", ws_name)

                # Split multi-measure cards into individual cards
                if pbi_type == "card" and len(meas_tmp) > 1:
                    n_kpi = len(meas_tmp)
                    kpi_gap = 6
                    kpi_w = (cell_w - kpi_gap * (n_kpi - 1)) // n_kpi
                    for ki, kpi_field in enumerate(meas_tmp):
                        kx = gx + ki * (kpi_w + kpi_gap)
                        vn = "vis_" + _safe_id(db_name) + "_" + str(vis_count).zfill(3)
                        cfg = _visual_config(
                            vn, "card", ws, kpi_field[0],
                            kx, gy, kpi_w, cell_h, vis_count,
                            override_dims=[], override_meas=[kpi_field])
                        visuals.append({
                            "x": kx, "y": gy, "z": vis_count,
                            "width": kpi_w, "height": cell_h,
                            "config": json.dumps(cfg), "filters": "[]",
                            "tabOrder": vis_count * 1000,
                        })
                        vis_count += 1
                # Split multi-measure charts
                elif (len(meas_tmp) >= 3
                        and pbi_type not in _NO_SPLIT_TYPES
                        and len(dims_tmp) > 0):
                    n_sub = len(meas_tmp)
                    sub_cols = min(n_sub, 2)
                    sub_rows = (n_sub + sub_cols - 1) // sub_cols
                    sub_gap = 6
                    sub_w = (cell_w - sub_gap * (sub_cols - 1)) // sub_cols
                    sub_h = (cell_h - sub_gap * (sub_rows - 1)) // sub_rows
                    for mi, m_field in enumerate(meas_tmp):
                        sr, sc = mi // sub_cols, mi % sub_cols
                        ssx = gx + sc * (sub_w + sub_gap)
                        ssy = gy + sr * (sub_h + sub_gap)
                        vn = "vis_" + _safe_id(db_name) + "_" + str(vis_count).zfill(3)
                        sub_title = m_field[0]
                        sub_type = "clusteredColumnChart" if pbi_type in (
                            "clusteredColumnChart", "clusteredBarChart"
                        ) else pbi_type
                        cfg = _visual_config(
                            vn, sub_type, ws, sub_title,
                            ssx, ssy, sub_w, sub_h, vis_count,
                            override_dims=dims_tmp, override_meas=[m_field])
                        visuals.append({
                            "x": ssx, "y": ssy, "z": vis_count,
                            "width": sub_w, "height": sub_h,
                            "config": json.dumps(cfg), "filters": "[]",
                            "tabOrder": vis_count * 1000,
                        })
                        vis_count += 1
                else:
                    cfg = _visual_config(vn, pbi_type, ws, title,
                                         gx, gy, cell_w, cell_h, vis_count)
                    visuals.append({
                        "x": gx, "y": gy, "z": vis_count,
                        "width": cell_w, "height": cell_h,
                        "config": json.dumps(cfg), "filters": "[]",
                        "tabOrder": vis_count * 1000,
                    })
                    vis_count += 1

        sections.append({
            "name": page_name, "displayName": db_name,
            "displayOption": 1, "width": width, "height": height,
            "visualContainers": visuals,
        })

    # Standalone worksheets → "Additional Worksheets" page
    ws_in_db = set()
    for db in dashboards:
        ws_in_db.update(db.get("worksheet_refs", []))
    standalone = [ws for ws in worksheets if ws["name"] not in ws_in_db]
    if standalone:
        extra_vis = []
        vis_count, y_off = 0, 20
        for ws in standalone:
            vn = "vis_extra_" + str(vis_count).zfill(3)
            title = ws.get("name", "")
            mark = ws.get("mark_class", "Automatic")
            dims_tmp2, meas_tmp2, infer_kw2 = _analyze_ws(ws)
            pbi_type = _infer_visual_type(ws.get("name", ""), [], len(dims_tmp2), len(meas_tmp2), mark,
                                          **infer_kw2)
            cfg = _visual_config(vn, pbi_type, ws, title,
                                 20, y_off, 1240, 300, vis_count)
            extra_vis.append({
                "x": 20, "y": y_off, "z": vis_count,
                "width": 1240, "height": 300,
                "config": json.dumps(cfg), "filters": "[]",
                "tabOrder": vis_count * 1000,
            })
            y_off += 320
            vis_count += 1
        sections.append({
            "name": "ReportSection_Additional",
            "displayName": "Additional Worksheets",
            "displayOption": 1, "width": PAGE_WIDTH,
            "height": max(PAGE_HEIGHT, y_off + 20),
            "visualContainers": extra_vis,
        })

    return {
        "id": 0, "layoutOptimization": 0,
        "resourcePackages": [{"resourcePackage": {
            "disabled": False,
            "items": [{"name": "CY24SU11", "path": "BaseThemes/CY24SU11.json", "type": 202}],
            "name": "SharedResources", "type": 2,
        }}],
        "sections": sections,
    }


def _build_table_info(model_tables: list) -> dict:
    info = {}
    for t in model_tables:
        cols = {c["name"] for c in t.get("columns", [])}
        measures = {ms["name"] for ms in t.get("measures", [])}
        info[t["name"]] = {"columns": cols, "measures": measures}
    return info


# Tableau internal/generated fields that have no PBI equivalent
_SKIP_FIELDS = frozenset({
    ":Measure Names", "Multiple Values", "Forecast Indicator",
    "Latitude (generated)", "Longitude (generated)",
    "__tableau_internal_object_id__",
})


def _strip_tableau_agg(field_name: str) -> str:
    """Strip Tableau aggregation prefixes and type-kind suffixes."""
    m = re.match(
        r'(?:pcto:|fVal:|med:)?'
        r'(?:none|sum|cnt|avg|min|max|usr|cum|attr|ctd|rank|tmn|twk|yr|mn|qr|tdy|tyr|tqr|wk|dy|mdy):'
        r'(.+?)(?::(?:nk|qk|ok)(?::\d+)?)?$',
        field_name,
    )
    if m:
        return m.group(1)
    m = re.match(r'(.+?)::?(?:nk|qk|ok)(?::\d+)?$', field_name)
    if m:
        return m.group(1)
    return field_name


def _resolve_field(field_name: str, table_info: dict,
                   field_alias_map: dict = None) -> tuple:
    if field_alias_map is None:
        field_alias_map = {}

    # Skip known internal / generated fields
    if field_name in _SKIP_FIELDS or field_name.startswith(":"):
        return None, field_name, False
    if "__tableau_internal_object_id__" in field_name:
        return None, field_name, False

    # Strip aggregation prefix/suffix
    clean = _strip_tableau_agg(field_name)

    # Build ordered candidate names: original, clean, alias-mapped versions
    candidates = []
    seen = set()
    for name in (field_name, clean):
        if name and name not in seen:
            seen.add(name)
            candidates.append(name)
        mapped = field_alias_map.get(name)
        if mapped and mapped not in seen:
            seen.add(mapped)
            candidates.append(mapped)

    # Exact match
    for candidate in candidates:
        for tbl_name, ti in table_info.items():
            if candidate in ti["measures"]:
                return tbl_name, candidate, True
            if candidate in ti["columns"]:
                return tbl_name, candidate, False

    # Case-insensitive match
    for candidate in candidates:
        clower = candidate.lower()
        for tbl_name, ti in table_info.items():
            for col in ti["columns"]:
                if clower == col.lower():
                    return tbl_name, col, False
            for ms in ti["measures"]:
                if clower == ms.lower():
                    return tbl_name, ms, True

    # Record-count pattern: TableName_HexGUID (Tableau "Number of Records")
    for tbl_name in table_info:
        prefix = tbl_name + "_"
        if clean.startswith(prefix) and re.fullmatch(r'[0-9A-Fa-f]+', clean[len(prefix):]):
            rc_name = f"{tbl_name} Record Count"
            if rc_name in table_info[tbl_name].get("measures", set()):
                return tbl_name, rc_name, True

    # Substring match (least preferred) – use clean name only
    clean_lower = clean.lower()
    if len(clean_lower) >= 3:
        for tbl_name, ti in table_info.items():
            for col in ti["columns"]:
                if clean_lower in col.lower() or col.lower() in clean_lower:
                    return tbl_name, col, False
            for ms in ti["measures"]:
                if clean_lower in ms.lower() or ms.lower() in clean_lower:
                    return tbl_name, ms, True

    return None, field_name, False


# =============================================================================
#  SECTION 6 - PBIT BUILDER (ZIP with UTF-16-LE encoding)
# =============================================================================

def u16(text: str) -> bytes:
    """Encode text as UTF-16-LE (no BOM)."""
    return text.encode("utf-16-le")


_SETTINGS = {
    "Version": 1, "ReportSettings": {},
    "QueriesSettings": {
        "TypeDetectionEnabled": True, "RelationshipImportEnabled": True,
        "RunBackgroundAnalysis": True, "Version": "2.150.2102.0",
    },
}

_METADATA = {
    "Version": 5, "AutoCreatedRelationships": [],
    "FileDescription": "", "CreatedFrom": "Cloud", "CreatedFromRelease": "2025.06",
}

_DIAGRAM_LAYOUT = {"version": "1.0", "pages": [], "scrollPosition": {"x": 0, "y": 0}}

_THEME = {
    "name": "CY24SU11",
    "dataColors": ["#118DFF", "#12239E", "#E66C37", "#6B007B",
                    "#E044A7", "#744EC2", "#D9B300", "#D64550"],
    "background": "#FFFFFF", "foreground": "#252423", "tableAccent": "#118DFF",
}

_CONTENT_TYPES = (
    '<?xml version="1.0" encoding="utf-8"?>'
    '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">'
    '<Default Extension="json" ContentType="" />'
    '<Override PartName="/Version" ContentType="" />'
    '<Override PartName="/Settings" ContentType="application/json" />'
    '<Override PartName="/Metadata" ContentType="application/json" />'
    '<Override PartName="/DiagramLayout" ContentType="application/json" />'
    '<Override PartName="/Report/Layout" ContentType="application/json" />'
    '<Override PartName="/DataModelSchema" ContentType="application/json" />'
    '</Types>'
)


def build_pbit(pbit_path: Path, model: dict, layout: dict):
    pbit_path.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(pbit_path, "w", zipfile.ZIP_DEFLATED) as zf:
        zf.writestr("Version",         u16("1.25"))
        zf.writestr("Settings",        u16(json.dumps(_SETTINGS, ensure_ascii=False)))
        zf.writestr("Metadata",        u16(json.dumps(_METADATA, ensure_ascii=False)))
        zf.writestr("DiagramLayout",   u16(json.dumps(_DIAGRAM_LAYOUT, ensure_ascii=False)))
        zf.writestr("Report/Layout",   u16(json.dumps(layout, ensure_ascii=False)))
        zf.writestr("DataModelSchema", u16(json.dumps(model, ensure_ascii=False)))
        zf.writestr(
            "Report/StaticResources/SharedResources/BaseThemes/CY24SU11.json",
            json.dumps(_THEME, indent=2, ensure_ascii=False).encode("utf-8"),
        )
        zf.writestr("[Content_Types].xml",
                     b"\xef\xbb\xbf" + _CONTENT_TYPES.encode("utf-8"))

    size = pbit_path.stat().st_size
    print(f"  PBIT Output : {pbit_path}")
    print(f"  Size        : {size:,} bytes")
    with zipfile.ZipFile(pbit_path, "r") as zf:
        print(f"  Parts       : {len(zf.namelist())}")
        for entry in zf.namelist():
            print(f"    {entry} ({zf.getinfo(entry).file_size:,} bytes)")


# =============================================================================
#  SECTION 7 - PBIP BUILDER (Power BI Project folder)
# =============================================================================

def create_pbip(output_dir: Path, name: str, model: dict, layout: dict):
    def _wj(path: Path, data: dict):
        path.parent.mkdir(parents=True, exist_ok=True)
        with open(path, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2, ensure_ascii=False)

    pbip_file = output_dir / f"{name}.pbip"
    _wj(pbip_file, {"version": "1.0", "artifacts": [{"report": {"path": f"{name}.Report"}}]})

    rpt = output_dir / f"{name}.Report"
    rpt.mkdir(parents=True, exist_ok=True)
    _wj(rpt / "definition.pbir", {
        "version": "1.0",
        "datasetReference": {"byPath": {"path": f"../{name}.SemanticModel"}, "byConnection": None},
    })
    _wj(rpt / "report.json", layout)

    sm = output_dir / f"{name}.SemanticModel"
    sm.mkdir(parents=True, exist_ok=True)
    _wj(sm / "definition.pbism", {"version": "1.0", "settings": {}})
    _wj(sm / "model.bim", model)

    print(f"  PBIP   : {pbip_file}")
    print(f"  Report : {rpt}")
    print(f"  Model  : {sm}")


# =============================================================================
#  SECTION 8 - PBIXPROJ BUILDER (pbi-tools compatible folder)
# =============================================================================

def create_pbixproj(output_dir: Path, name: str, model: dict):
    proj = output_dir / f"{name}_PbixProj"
    if proj.exists():
        shutil.rmtree(proj)
    proj.mkdir(parents=True)

    def _wj(path: Path, data: dict):
        path.parent.mkdir(parents=True, exist_ok=True)
        with open(path, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2, ensure_ascii=False)

    _wj(proj / ".pbixproj.json", {
        "version": "0.11", "created": "2025-01-01T00:00:00Z",
        "lastModified": "2025-01-01T00:00:00Z",
        "settings": {"model": {"serializationMode": "Raw"}, "mashup": {"serializationMode": "Raw"}},
    })
    with open(proj / "Version.txt", "w") as f:
        f.write("1.25")

    (proj / "Model").mkdir(parents=True, exist_ok=True)
    _wj(proj / "Model" / "database.json", model)

    _wj(proj / "ReportMetadata.json", {
        "Version": 5, "AutoCreatedRelationships": [],
        "FileDescription": "", "CreatedFrom": "Cloud", "CreatedFromRelease": "2025.06",
    })
    _wj(proj / "ReportSettings.json", {
        "Version": 1, "ReportSettings": {},
        "QueriesSettings": {"TypeDetectionEnabled": True, "RelationshipImportEnabled": True,
                            "RunBackgroundAnalysis": True, "Version": "2.150.2102.0"},
    })
    _wj(proj / "DiagramLayout.json", {"version": "1.0", "pages": [], "scrollPosition": {"x": 0, "y": 0}})

    rpt = proj / "Report"
    rpt.mkdir(parents=True, exist_ok=True)
    _wj(rpt / "config.json", {
        "version": "5.54",
        "themeCollection": {"baseTheme": {"name": "CY24SU11", "version": "5.54", "type": 2}},
        "activeSectionIndex": 0, "defaultDrillFilterOtherVisuals": True,
        "slowDataSourceSettings": {
            "isCrossHighlightingDisabled": False, "isSlicerSelectionsButtonEnabled": False,
            "isFilterSelectionsButtonEnabled": False, "isFieldWellButtonEnabled": False,
            "isApplyAllButtonEnabled": False,
        },
        "linguisticSchemaSyncVersion": 2,
        "settings": {"useNewFilterPaneExperience": True, "allowChangeFilterTypes": True,
                      "useStylableVisualContainerHeader": True, "exportDataMode": 1,
                      "allowDataPointLassoSelect": True},
    })
    _wj(rpt / "report.json", {
        "id": 0, "layoutOptimization": 0,
        "resourcePackages": [{"resourcePackage": {
            "disabled": False,
            "items": [{"name": "CY24SU11", "path": "BaseThemes/CY24SU11.json", "type": 202}],
            "name": "SharedResources", "type": 2,
        }}],
    })

    theme_dir = proj / "StaticResources" / "SharedResources" / "BaseThemes"
    theme_dir.mkdir(parents=True, exist_ok=True)
    _wj(theme_dir / "CY24SU11.json", {
        "name": "CY24SU11",
        "dataColors": ["#118DFF", "#12239E", "#E66C37", "#6B007B",
                        "#E044A7", "#744EC2", "#D9B300", "#D64550"],
        "background": "#FFFFFF", "foreground": "#252423", "tableAccent": "#118DFF",
    })

    file_count = sum(1 for _ in proj.rglob("*") if _.is_file())
    print(f"  PbixProj : {proj}")
    print(f"  Files    : {file_count}")


# =============================================================================
#  SECTION 9 - CLI ORCHESTRATOR
# =============================================================================

def convert(input_path: str, output_dir: str = None) -> dict:
    """Run the full Tableau -> Power BI conversion pipeline."""
    src = Path(input_path).resolve()
    if not src.exists():
        raise FileNotFoundError(f"Input file not found: {src}")
    if src.suffix.lower() not in (".twbx", ".twb"):
        raise ValueError(f"Expected .twbx or .twb file, got: {src.suffix}")

    out = Path(output_dir).resolve() if output_dir else src.parent
    out.mkdir(parents=True, exist_ok=True)
    name = src.stem

    print("=" * 60)
    print(f"  Tableau -> Power BI Converter  v{__version__}")
    print(f"  Input : {src}")
    print(f"  Output: {out}")
    print("=" * 60)

    # Step 1: Extract
    print("\n[1/7] Extracting workbook ...")
    extract_dir = out / f"{name}_extracted"
    extracted = extract_twbx(src, extract_dir)
    twb_path = extracted["twb_path"]
    data_dir = extracted.get("data_dir")
    print(f"  TWB      : {twb_path}")
    print(f"  Data dir : {data_dir or '(none)'}")
    print(f"  Data files: {len(extracted.get('data_files', []))}")

    # Step 2: Parse TWB
    print("\n[2/7] Parsing TWB XML ...")
    parsed = parse_twb(twb_path)
    ds_count = len(parsed.get("datasources", []))
    ws_count = len(parsed.get("worksheets", []))
    db_count = len(parsed.get("dashboards", []))
    param_count = len(parsed.get("parameters", []))
    print(f"  Datasources : {ds_count}")
    print(f"  Worksheets  : {ws_count}")
    print(f"  Dashboards  : {db_count}")
    print(f"  Parameters  : {param_count}")

    total_columns = 0
    total_calcs = 0
    total_joins = 0
    total_filters = 0
    for ds in parsed.get("datasources", []):
        total_columns += len(ds.get("data_columns", []))
        total_calcs += len(ds.get("calc_columns", []))
        total_joins += len(ds.get("joins", []))
    for ws in parsed.get("worksheets", []):
        total_filters += len(ws.get("filters", []))
    total_actions = len(parsed.get("actions", []))
    print(f"  Columns     : {total_columns}")
    print(f"  Calculated  : {total_calcs}")
    print(f"  Joins       : {total_joins}")
    print(f"  Filters     : {total_filters}")
    print(f"  Actions     : {total_actions}")
    # Print dashboard zone info
    for db in parsed.get("dashboards", []):
        zones = db.get("zones", [])
        print(f"  Dashboard '{db['name']}': {len(zones)} positioned zones")

    # Step 3: Translate formulas
    print("\n[3/7] Translating formulas -> DAX ...")
    for ds in parsed.get("datasources", []):
        calcs = ds.get("calc_columns", [])
        if calcs:
            col_lookup = {c["name"]: c["name"] for c in ds.get("data_columns", [])}
            for c in calcs:
                col_lookup[c["name"]] = c["name"]
            table_name = ds["tables"][0]["name"] if ds.get("tables") else ds.get("name", "Table")
            translate_all(calcs, table_name, col_lookup)
    print(f"  Translated {total_calcs} formula(s)")

    # Step 4: Build data model
    print("\n[4/7] Building data model ...")
    model = build_model(parsed, data_dir, output_dir=out)
    table_count = len(model.get("model", {}).get("tables", []))
    total_model_measures = sum(len(t.get("measures", [])) for t in model["model"]["tables"])
    total_model_columns = sum(len(t.get("columns", [])) for t in model["model"]["tables"])
    rel_count = len(model.get("model", {}).get("relationships", []))
    print(f"  Tables        : {table_count}")
    print(f"  Columns       : {total_model_columns}")
    print(f"  Measures      : {total_model_measures}")
    print(f"  Relationships : {rel_count}")
    for r in model["model"].get("relationships", []):
        print(f"    {r['toTable']}.{r['toColumn']} -> {r['fromTable']}.{r['fromColumn']}")

    # Step 5: Build report layout
    print("\n[5/7] Building report layout ...")
    layout = build_report_layout(parsed, model)
    page_count = len(layout.get("sections", []))
    total_visuals = sum(len(s.get("visualContainers", [])) for s in layout.get("sections", []))
    print(f"  Pages   : {page_count}")
    print(f"  Visuals : {total_visuals}")
    # Show mark type mapping summary
    for ws in parsed.get("worksheets", []):
        mc = ws.get("mark_class", "Automatic")
        if mc != "Automatic":
            print(f"    {ws['name']}: {mc} -> {_MARK_TYPE_MAP.get(mc, 'heuristic')}")

    # Step 6: Build PBIT
    print("\n[6/7] Building PBIT ...")
    pbit_path = out / f"{name}.pbit"
    build_pbit(pbit_path, model, layout)

    # Step 7: Build PBIP + PbixProj
    print("\n[7/7] Building PBIP & PbixProj ...")
    create_pbip(out, name, model, layout)
    create_pbixproj(out, name, model)

    # Copy data files
    if data_dir and Path(data_dir).exists():
        dest_data = out / "Data"
        src_data = Path(data_dir).resolve()
        dest_resolved = dest_data.resolve()
        # Avoid infinite recursion: skip if source contains the destination
        src_is_ancestor = (dest_resolved == src_data or
                           src_data in dest_resolved.parents or
                           dest_resolved in src_data.parents)
        if src_is_ancestor:
            # Copy individual data files instead of the whole tree
            dest_data.mkdir(parents=True, exist_ok=True)
            for f in src_data.rglob("*"):
                if f.is_file() and not str(f.resolve()).startswith(str(dest_resolved)):
                    dst = dest_data / f.relative_to(src_data)
                    dst.parent.mkdir(parents=True, exist_ok=True)
                    try:
                        shutil.copy2(f, dst)
                    except (PermissionError, shutil.Error):
                        pass
        else:
            try:
                if dest_data.exists():
                    shutil.rmtree(dest_data)
                shutil.copytree(str(src_data), str(dest_data))
            except (PermissionError, shutil.Error):
                dest_data.mkdir(parents=True, exist_ok=True)
                for f in src_data.rglob("*"):
                    if f.is_file():
                        dst = dest_data / f.relative_to(src_data)
                        dst.parent.mkdir(parents=True, exist_ok=True)
                        try:
                            shutil.copy2(f, dst)
                        except (PermissionError, shutil.Error):
                            pass
        data_count = sum(1 for _ in dest_data.rglob("*") if _.is_file())
        print(f"\n  Copied {data_count} data file(s) to {dest_data}")

    print("\n" + "=" * 60)
    print("  Conversion complete!")
    print(f"  PBIT    : {pbit_path}")
    print(f"  PBIP    : {out / f'{name}.pbip'}")
    print(f"  PbixProj: {out / f'{name}_PbixProj'}")
    print("=" * 60)

    return {
        "pbit": str(pbit_path),
        "pbip": str(out / f"{name}.pbip"),
        "pbixproj": str(out / f"{name}_PbixProj"),
        "data": str(out / "Data") if data_dir else None,
    }



def convert_one(input_path: str, output_dir: str = None, **_kwargs) -> str:
    """Flask-friendly wrapper around convert().

    Returns the PBIP directory path (str) for downstream processing.
    """
    src = Path(input_path).resolve()
    if not src.exists():
        raise FileNotFoundError(f"Input file not found: {src}")
    if src.suffix.lower() not in (".twbx", ".twb"):
        raise ValueError(f"Expected .twbx or .twb file, got: {src.suffix}")
    result = convert(str(src), output_dir)
    pbip_file = result.get("pbip", "")
    return str(Path(pbip_file).parent) if pbip_file else output_dir

def main():
    # =========================================================================
    #  SET YOUR PATHS HERE (or pass them as command-line arguments)
    # =========================================================================
    #  Option A: Edit these two variables and just run:
    #    python tableau_to_pbi_generic.py
    #
    DEFAULT_INPUT  = r"C:\Users\rmonika\Downloads\Tableau to Power BI test\KPI_Metrics_Dashboard.twbx"
    DEFAULT_OUTPUT = r"C:\Users\rmonika\Downloads\Generic Code\Generic new\test_output"
    #
    #  Option B: Pass paths on the command line (overrides the defaults above):
    #    python tableau_to_pbi_generic.py "C:\path\to\file.twbx" "C:\output\folder"
    # =========================================================================

    parser = argparse.ArgumentParser(
        description="Convert a Tableau workbook (.twbx / .twb) to Power BI (.pbit / .pbip).",
    )
    parser.add_argument("input", nargs="?", default=DEFAULT_INPUT,
                        help="Path to .twbx or .twb file")
    parser.add_argument("output", nargs="?", default=DEFAULT_OUTPUT,
                        help="Output directory (default: same folder as input)")
    args = parser.parse_args()
    convert(args.input, args.output)


if __name__ == "__main__":
    main()
