/**
 * Tableau to Power BI Converter — Frontend Logic
 * Standalone version (conversion + UT reconciliation only).
 */
(function () {
    "use strict";

    /* ========================================================
       Utility helpers
       ======================================================== */
    function hideAll() {
        document.querySelectorAll(".wizard-step").forEach(s => s.classList.add("hidden"));
    }

    function formatBytes(bytes) {
        if (bytes === 0) return "0 B";
        const k = 1024;
        const sizes = ["B", "KB", "MB", "GB"];
        const i = Math.floor(Math.log(bytes) / Math.log(k));
        return parseFloat((bytes / Math.pow(k, i)).toFixed(1)) + " " + sizes[i];
    }

    function goToStep(n) {
        hideAll();
        const id = n === 0 ? "step-landing" : "step-" + n;
        const el = document.getElementById(id);
        if (el) el.classList.remove("hidden");
    }

    /* ========================================================
       Landing card → open Step 4
       ======================================================== */
    const cardTableauPbi = document.getElementById("card-tableau-pbi");
    if (cardTableauPbi) {
        cardTableauPbi.addEventListener("click", () => goToStep(4));
    }

    /* ========================================================
       Step 4 Sub-tab Navigation
       ======================================================== */
    const step4SubTabs = document.querySelectorAll("#step4-sub-tabs .sub-tab");
    step4SubTabs.forEach(tab => {
        tab.addEventListener("click", () => {
            step4SubTabs.forEach(t => t.classList.remove("active"));
            tab.classList.add("active");
            const target = tab.dataset.target;
            document.querySelectorAll("#step-4 .sub-panel").forEach(p => {
                p.classList.toggle("hidden", p.id !== target);
            });
        });
    });

    /* ========================================================
       Home button
       ======================================================== */
    const step4HomeBtn = document.getElementById("step4-home-btn");
    if (step4HomeBtn) {
        step4HomeBtn.addEventListener("click", () => {
            resetConvertUI();
            resetUtUI();
            goToStep(0);
        });
    }

    /* ========================================================
       Step 4A — Tableau → Power BI Conversion
       ======================================================== */
    const convertUploadZone  = document.getElementById("convert-upload-zone");
    const convertFileInput   = document.getElementById("convert-file-input");
    const convertFileInfo    = document.getElementById("convert-file-info");
    const convertFileName    = document.getElementById("convert-file-name");
    const convertFileSize    = document.getElementById("convert-file-size");
    const convertRemoveBtn   = document.getElementById("convert-remove-btn");
    const convertBtn         = document.getElementById("convert-btn");
    const convertProgress    = document.getElementById("convert-progress");
    const convertProgressBar = document.getElementById("convert-progress-bar");
    const convertProgressTxt = document.getElementById("convert-progress-text");
    const convertResult      = document.getElementById("convert-result");
    const convertResultSum   = document.getElementById("convert-result-summary");
    const convertDownloadLnk = document.getElementById("convert-download-link");
    const convertError       = document.getElementById("convert-error");
    const convertErrorMsg    = document.getElementById("convert-error-message");
    const convertErrorReset  = document.getElementById("convert-error-reset");

    let convertFile = null;

    function selectConvertFile(f) {
        const ext = f.name.split(".").pop().toLowerCase();
        if (ext !== "twb" && ext !== "twbx") {
            showConvertError("Unsupported file type. Please upload a .twb or .twbx file.");
            return;
        }
        convertFile = f;
        convertFileName.textContent = f.name;
        convertFileSize.textContent = formatBytes(f.size);
        convertUploadZone.classList.add("hidden");
        convertFileInfo.classList.remove("hidden");
    }

    // Click / drag-and-drop
    if (convertUploadZone) {
        convertUploadZone.addEventListener("click", () => convertFileInput.click());
        convertUploadZone.addEventListener("dragover", e => { e.preventDefault(); convertUploadZone.classList.add("drag-over"); });
        convertUploadZone.addEventListener("dragleave", () => convertUploadZone.classList.remove("drag-over"));
        convertUploadZone.addEventListener("drop", e => {
            e.preventDefault();
            convertUploadZone.classList.remove("drag-over");
            if (e.dataTransfer.files.length) selectConvertFile(e.dataTransfer.files[0]);
        });
    }
    if (convertFileInput) {
        convertFileInput.addEventListener("change", () => {
            if (convertFileInput.files.length) selectConvertFile(convertFileInput.files[0]);
        });
    }
    if (convertRemoveBtn) convertRemoveBtn.addEventListener("click", resetConvertUI);
    if (convertErrorReset) convertErrorReset.addEventListener("click", resetConvertUI);

    // Convert action
    if (convertBtn) {
        convertBtn.addEventListener("click", startConvert);
    }

    function startConvert() {
        if (!convertFile) return;
        convertFileInfo.classList.add("hidden");
        convertProgress.classList.remove("hidden");
        convertResult.classList.add("hidden");
        convertError.classList.add("hidden");

        const anim = animateConvertProgress();
        const fd = new FormData();
        fd.append("file", convertFile);

        fetch("/convert", { method: "POST", body: fd })
            .then(r => r.json().then(d => ({ ok: r.ok, data: d })))
            .then(({ ok, data }) => {
                clearInterval(anim);
                convertProgressBar.style.width = "100%";

                setTimeout(() => {
                    convertProgress.classList.add("hidden");
                    if (!ok || !data.success) {
                        showConvertError(data.error || "Unknown error.");
                        return;
                    }
                    let summary = `Generated ${data.summary.files_generated} files.`;
                    if (data.ut_summary) {
                        summary += ` UT: ${data.ut_summary.pass} pass, ${data.ut_summary.fail} fail, ${data.ut_summary.warn} warn.`;
                    }
                    convertResultSum.textContent = summary;
                    convertDownloadLnk.href = data.download_url;
                    convertResult.classList.remove("hidden");
                }, 400);
            })
            .catch(err => {
                clearInterval(anim);
                convertProgress.classList.add("hidden");
                showConvertError(err.message || "Network error.");
            });
    }

    function showConvertError(msg) {
        convertProgress.classList.add("hidden");
        convertResult.classList.add("hidden");
        convertErrorMsg.textContent = msg;
        convertError.classList.remove("hidden");
    }

    function resetConvertUI() {
        convertFile = null;
        convertFileInput.value = "";
        convertUploadZone.classList.remove("hidden");
        convertFileInfo.classList.add("hidden");
        convertProgress.classList.add("hidden");
        convertProgressBar.style.width = "0%";
        convertResult.classList.add("hidden");
        convertError.classList.add("hidden");
    }

    function animateConvertProgress() {
        let pct = 0;
        const msgs = [
            "Parsing Tableau workbook…",
            "Extracting data sources…",
            "Generating DAX measures…",
            "Building Power BI visuals…",
            "Creating PBIP package…",
            "Generating unit test document…",
            "Finalising…"
        ];
        return setInterval(() => {
            pct = Math.min(pct + Math.random() * 6 + 1, 92);
            convertProgressBar.style.width = pct + "%";
            const idx = Math.min(Math.floor(pct / 14), msgs.length - 1);
            convertProgressTxt.textContent = msgs[idx];
        }, 600);
    }


    /* ========================================================
       Step 4B — Tableau → PowerBI Reconciliation (UT)
       ======================================================== */
    const utTabZone     = document.getElementById("ut-tab-zone");
    const utTabInput    = document.getElementById("ut-tab-input");
    const utTabLabel    = document.getElementById("ut-tab-label");
    const utPbiZone     = document.getElementById("ut-pbi-zone");
    const utPbiInput    = document.getElementById("ut-pbi-input");
    const utPbiLabel    = document.getElementById("ut-pbi-label");
    const utProjectName = document.getElementById("ut-project-name");
    const utGenerateBtn = document.getElementById("ut-generate-btn");
    const utProgress    = document.getElementById("ut-progress");
    const utProgressBar = document.getElementById("ut-progress-bar");
    const utProgressTxt = document.getElementById("ut-progress-text");
    const utResult      = document.getElementById("ut-result");
    const utResultSum   = document.getElementById("ut-result-summary");
    const utDownloadLnk = document.getElementById("ut-download-link");
    const utError       = document.getElementById("ut-error");
    const utErrorMsg    = document.getElementById("ut-error-message");
    const utErrorReset  = document.getElementById("ut-error-reset");

    let utTabFile = null;
    let utPbiFile = null;

    function checkUtReady() {
        utGenerateBtn.disabled = !(utTabFile && utPbiFile);
    }

    function pickUtFile(zone, input, label, kind) {
        const exts = kind === "tab" ? ["twb", "twbx"] : ["pbix"];
        return function (f) {
            const ext = f.name.split(".").pop().toLowerCase();
            if (!exts.includes(ext)) {
                showUtError(`Invalid file type for ${kind === "tab" ? "Tableau" : "Power BI"} input.`);
                return;
            }
            if (kind === "tab") utTabFile = f; else utPbiFile = f;
            label.textContent = f.name + " (" + formatBytes(f.size) + ")";
            zone.classList.add("file-selected");
            checkUtReady();
        };
    }

    // Bind Tableau zone
    const selectTabFile = pickUtFile(utTabZone, utTabInput, utTabLabel, "tab");
    if (utTabZone) {
        utTabZone.addEventListener("click", () => utTabInput.click());
        utTabZone.addEventListener("dragover", e => { e.preventDefault(); utTabZone.classList.add("drag-over"); });
        utTabZone.addEventListener("dragleave", () => utTabZone.classList.remove("drag-over"));
        utTabZone.addEventListener("drop", e => {
            e.preventDefault(); utTabZone.classList.remove("drag-over");
            if (e.dataTransfer.files.length) selectTabFile(e.dataTransfer.files[0]);
        });
    }
    if (utTabInput) utTabInput.addEventListener("change", () => { if (utTabInput.files.length) selectTabFile(utTabInput.files[0]); });

    // Bind PBI zone
    const selectPbiFile = pickUtFile(utPbiZone, utPbiInput, utPbiLabel, "pbi");
    if (utPbiZone) {
        utPbiZone.addEventListener("click", () => utPbiInput.click());
        utPbiZone.addEventListener("dragover", e => { e.preventDefault(); utPbiZone.classList.add("drag-over"); });
        utPbiZone.addEventListener("dragleave", () => utPbiZone.classList.remove("drag-over"));
        utPbiZone.addEventListener("drop", e => {
            e.preventDefault(); utPbiZone.classList.remove("drag-over");
            if (e.dataTransfer.files.length) selectPbiFile(e.dataTransfer.files[0]);
        });
    }
    if (utPbiInput) utPbiInput.addEventListener("change", () => { if (utPbiInput.files.length) selectPbiFile(utPbiInput.files[0]); });

    if (utErrorReset) utErrorReset.addEventListener("click", resetUtUI);

    // Generate UT document
    if (utGenerateBtn) {
        utGenerateBtn.addEventListener("click", startUtGeneration);
    }

    function startUtGeneration() {
        if (!utTabFile || !utPbiFile) return;
        utGenerateBtn.disabled = true;
        utProgress.classList.remove("hidden");
        utResult.classList.add("hidden");
        utError.classList.add("hidden");

        const anim = animateUtProgress();
        const fd = new FormData();
        fd.append("tableau_file", utTabFile);
        fd.append("pbi_file", utPbiFile);
        fd.append("project_name", utProjectName ? utProjectName.value : "BI Report Migration");

        fetch("/generate-ut", { method: "POST", body: fd })
            .then(r => r.json().then(d => ({ ok: r.ok, data: d })))
            .then(({ ok, data }) => {
                clearInterval(anim);
                utProgressBar.style.width = "100%";

                setTimeout(() => {
                    utProgress.classList.add("hidden");
                    if (!ok || !data.success) {
                        showUtError(data.error || "Unknown error.");
                        return;
                    }
                    const s = data.summary;
                    utResultSum.textContent = `Tests: ${s.total_tests} total — ${s.pass} pass, ${s.fail} fail, ${s.warn} warnings.`;
                    utDownloadLnk.href = data.download_url;
                    utResult.classList.remove("hidden");
                }, 400);
            })
            .catch(err => {
                clearInterval(anim);
                utProgress.classList.add("hidden");
                showUtError(err.message || "Network error.");
            });
    }

    function showUtError(msg) {
        utProgress.classList.add("hidden");
        utResult.classList.add("hidden");
        utErrorMsg.textContent = msg;
        utError.classList.remove("hidden");
    }

    function resetUtUI() {
        utTabFile = null;
        utPbiFile = null;
        utTabInput.value = "";
        utPbiInput.value = "";
        utTabLabel.textContent = "Click or drop .twb / .twbx file";
        utPbiLabel.textContent = "Click or drop .pbix file";
        utTabZone.classList.remove("file-selected");
        utPbiZone.classList.remove("file-selected");
        utGenerateBtn.disabled = true;
        utProgress.classList.add("hidden");
        utProgressBar.style.width = "0%";
        utResult.classList.add("hidden");
        utError.classList.add("hidden");
    }

    function animateUtProgress() {
        let pct = 0;
        const msgs = [
            "Extracting Tableau metadata…",
            "Parsing Power BI report…",
            "Comparing visual layouts…",
            "Generating wireframe diagrams…",
            "Building reconciliation document…",
            "Finalising…"
        ];
        return setInterval(() => {
            pct = Math.min(pct + Math.random() * 5 + 1, 92);
            utProgressBar.style.width = pct + "%";
            const idx = Math.min(Math.floor(pct / 16), msgs.length - 1);
            utProgressTxt.textContent = msgs[idx];
        }, 700);
    }

})();
