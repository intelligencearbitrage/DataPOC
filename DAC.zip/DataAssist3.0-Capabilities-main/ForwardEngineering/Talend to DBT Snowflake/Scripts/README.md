# talend-to-dbt-snowflake Scripts

Generator scripts that convert `LOAD_ACH_ACTV_FILE_SWH_0.1.item` to a complete dbt project targeting Snowflake.

## Quick Start

```bash
# From project root: run full pipeline
python agent-output/scripts/cli.py all
```

## Scripts

| Command | Script | Description | Output |
|---------|--------|-------------|--------|
| `parse` | parse_talend_job.py | Parse .item XML | `agent-output/research/parsed_job.json` |
| `config` | generate_dbt_project_config.py | dbt config files | `dbt_project.yml`, `profiles.yml`, `packages.yml`, `sources.yml` |
| `staging` | generate_staging_model.py | Staging model | `models/staging/stg_ach_activity.sql` + `.yml` |
| `intermediate` | generate_intermediate_model.py | Intermediate model | `models/intermediate/int_ach_activity_enriched.sql` + `.yml` |
| `mart` | generate_mart_model.py | Mart model | `models/marts/ach_actv.sql` + `.yml` |
| `tests` | generate_dbt_tests.py | Schema tests | All model `.yml` files (overwrites with full tests) |
| `report` | generate_conversion_report.py | Conversion report | `scripts-output/output/conversion_report.md` |

## Output Structure

```
scripts-output/output/
├── dbt_project/
│   ├── dbt_project.yml
│   ├── profiles.yml
│   ├── packages.yml
│   └── models/
│       ├── sources.yml
│       ├── staging/
│       │   ├── stg_ach_activity.sql
│       │   └── stg_ach_activity.yml
│       ├── intermediate/
│       │   ├── int_ach_activity_enriched.sql
│       │   └── int_ach_activity_enriched.yml
│       └── marts/
│           ├── ach_actv.sql
│           └── ach_actv.yml
└── conversion_report.md
```

## Individual Script Usage

```bash
python agent-output/scripts/parse_talend_job.py
python agent-output/scripts/generate_dbt_project_config.py
python agent-output/scripts/generate_staging_model.py
python agent-output/scripts/generate_intermediate_model.py
python agent-output/scripts/generate_mart_model.py
python agent-output/scripts/generate_dbt_tests.py
python agent-output/scripts/generate_conversion_report.py
```

## Running the Generated dbt Project

```bash
cd scripts-output/output/dbt_project
pip install dbt-snowflake
dbt deps
export SNOWFLAKE_ACCOUNT=myorg-myaccount
export SNOWFLAKE_USER=myuser
export SNOWFLAKE_PASSWORD=mypassword
dbt run --vars '{etl_batch_id: 12345}'
dbt test
```

## Source

Generated from: `user-config/inputs/LOAD_ACH_ACTV_FILE_SWH_0.1.item`
