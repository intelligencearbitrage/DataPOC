"""
generate_intermediate_model.py

Generates the dbt intermediate model replicating tDBInput_2 lookup + tMap_1 transformation:
  - models/int_ach_activity_enriched.sql  (materialized='table')
  - models/int_ach_activity_enriched.yml  (schema descriptions)

Reads: agent-output/research/parsed_job.json
Writes: scripts-output/output/dbt_project/models/

Usage:
    python generate_intermediate_model.py
    python generate_intermediate_model.py --parsed-job path/to/parsed_job.json --output-dir path/to/dbt_project
"""

import argparse
import json
import sys
from pathlib import Path
from typing import Any, Dict, List


# ---------------------------------------------------------------------------
# Path constants
# ---------------------------------------------------------------------------
PROJECT_ROOT = Path(__file__).resolve().parent.parent.parent
DEFAULT_PARSED_JOB = PROJECT_ROOT / "agent-output" / "research" / "parsed_job.json"
DEFAULT_OUTPUT_DIR = PROJECT_ROOT / "scripts-output" / "output" / "dbt_project"


# ---------------------------------------------------------------------------
# SQL generation
# ---------------------------------------------------------------------------

def build_intermediate_sql(tmap_data: Dict[str, Any], lookup_data: Dict[str, Any]) -> str:
    """Build the int_ach_activity_enriched.sql content from tMap expressions."""
    columns = tmap_data.get("columns", [])

    select_lines = []
    for col in columns:
        sf_expr = col.get("snowflake_expression", col["name"])
        name = col["name"]

        # Align expressions
        if sf_expr == f"'{name}'" or sf_expr.startswith("'"):
            # String literal
            select_lines.append(f"        {sf_expr:<50} AS {name}")
        elif sf_expr == "current_timestamp":
            select_lines.append(f"        CURRENT_TIMESTAMP                                  AS {name}")
        elif "var('etl_batch_id'" in sf_expr:
            select_lines.append(f"        {{{{ var('etl_batch_id', 0) }}}}                           AS {name}")
        else:
            select_lines.append(f"        {sf_expr:<50} AS {name}")

    select_sql = ",\n".join(select_lines)

    lookup_sql = lookup_data.get("snowflake_sql", "SELECT loan_key, loan_nbr FROM {{ source('srvc_wh', 'loan_nbr_cross_ref') }}")

    return f"""-- int_ach_activity_enriched.sql
-- Intermediate model: replicates tDBInput_2 lookup join + tMap_1 transformations
-- Source: LOAD_ACH_ACTV_FILE_SWH_0.1.item — tMap_1 (TXFM) component
--
-- Join logic: INNER JOIN on loan_nbr (tMap innerJoin=true, UNIQUE_MATCH)
-- Rows from tFileInputDelimited_1 that have no matching loan_nbr in LOAN_NBR_CROSS_REF are dropped
--
-- tMap expression translations:
--   row1.* => src.*                     (CSV source rows via stg_ach_activity)
--   row6.LOAN_KEY => xref.loan_key      (lookup result)
--   "PAYMENTUS" => 'PAYMENTUS'          (hardcoded source of record)
--   "TALEND-ETL-INSERT" => literal      (audit created by)
--   TalendDate.getCurrentDate() => CURRENT_TIMESTAMP
--   context.parameter_ETL_BATCH_ID => {{{{ var('etl_batch_id', 0) }}}}

{{{{ config(materialized='table') }}}}

WITH ach_src AS (
    -- Main input: CSV rows staged by stg_ach_activity
    SELECT * FROM {{{{ ref('stg_ach_activity') }}}}
),

loan_xref AS (
    -- Lookup: replicates tDBInput_2
    -- Original SQL: select LOAN_KEY, CAST(LOAN_NBR as bigint) from SRVC_WH.DBO.LOAN_NBR_CROSS_REF (nolock)
    -- Note: NOLOCK hint omitted — not applicable in Snowflake
    {lookup_sql}
),

joined AS (
    -- INNER JOIN replicates tMap_1 (innerJoin=true, row6 is lookup)
    -- Join condition: row1.LOAN_NBR = row6.LOAN_NBR
    SELECT
{select_sql}
    FROM ach_src AS src
    INNER JOIN loan_xref AS xref
        ON src.loan_nbr = xref.loan_nbr
)

-- Explicit column list (25 cols from tMap_1)
SELECT
    loan_key,
    actv_eff_dt,
    sor_cd,
    pymt_amt,
    schd_type_cd,
    schd_day,
    pymt_type_cd,
    cust_seg,
    pymt_mth_type,
    frst_nm,
    last_nm,
    mth_cntrt_amt,
    addl_escrw_amt,
    addl_prin_amt,
    part_pymt_amt,
    tot_drft_amt,
    pymt_agnt_id,
    schd_sts,
    disabled_dt,
    last_mod_dt,
    closd_by,
    aud_cre_by_nm,
    aud_cre_dttm,
    etl_batch_id,
    curr_ind
FROM joined
"""


# ---------------------------------------------------------------------------
# YAML generation
# ---------------------------------------------------------------------------

def build_intermediate_yaml(tmap_data: Dict[str, Any]) -> str:
    """Build the int_ach_activity_enriched.yml schema file."""
    columns = tmap_data.get("columns", [])

    col_descriptions = {
        "loan_key": "Internal loan key from LOAN_NBR_CROSS_REF — replaces LOAN_NBR from CSV source",
        "actv_eff_dt": "Activity effective date (from CSV, date format applied in staging)",
        "sor_cd": "Source of record — hardcoded to PAYMENTUS per tMap expression",
        "pymt_amt": "Payment amount from CSV source",
        "schd_type_cd": "Schedule type code",
        "schd_day": "Schedule day",
        "pymt_type_cd": "Payment type code",
        "cust_seg": "Customer segment",
        "pymt_mth_type": "Payment method type",
        "frst_nm": "First name",
        "last_nm": "Last name",
        "mth_cntrt_amt": "Monthly contract amount",
        "addl_escrw_amt": "Additional escrow amount",
        "addl_prin_amt": "Additional principal amount",
        "part_pymt_amt": "Partial payment amount",
        "tot_drft_amt": "Total draft amount",
        "pymt_agnt_id": "Payment agent ID",
        "schd_sts": "Schedule status",
        "disabled_dt": "Disabled date",
        "last_mod_dt": "Last modified date",
        "closd_by": "Closed by",
        "aud_cre_by_nm": "Audit created by — hardcoded to TALEND-ETL-INSERT",
        "aud_cre_dttm": "Audit created datetime — CURRENT_TIMESTAMP at load time",
        "etl_batch_id": "ETL batch tracking ID — from dbt variable etl_batch_id",
        "curr_ind": "Current indicator — set to N on insert; updated to Y by ach_actv post-hook",
    }

    col_entries = []
    for col in columns:
        name = col["name"]
        desc = col_descriptions.get(name, f"Column {name} from tMap_1 TGT_TBL output")
        col_entries.append(f"      - name: {name}\n        description: \"{desc}\"")

    col_yaml = "\n".join(col_entries)

    return f"""version: 2

models:
  - name: int_ach_activity_enriched
    description: >
      ACH activity enriched with loan key lookup and tMap_1 transformations applied.
      Replicates the tDBInput_2 (LOAN_NBR_CROSS_REF lookup) + tMap_1 (TXFM) components
      from LOAD_ACH_ACTV_FILE_SWH_0.1.item.
      Join type: INNER JOIN on loan_nbr (rows without a matching loan key are dropped).
    columns:
{col_yaml}
"""


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main() -> None:
    """Generate intermediate model SQL and YAML files."""
    parser = argparse.ArgumentParser(
        description="Generate dbt intermediate model for ACH activity"
    )
    parser.add_argument(
        "--parsed-job", type=Path, default=DEFAULT_PARSED_JOB,
        help=f"Path to parsed_job.json (default: {DEFAULT_PARSED_JOB})"
    )
    parser.add_argument(
        "--output-dir", type=Path, default=DEFAULT_OUTPUT_DIR,
        help=f"dbt project root directory (default: {DEFAULT_OUTPUT_DIR})"
    )
    args = parser.parse_args()

    # Load parsed job data
    if not args.parsed_job.exists():
        print(f"ERROR: parsed_job.json not found at {args.parsed_job}", file=sys.stderr)
        print("Run parse_talend_job.py first.", file=sys.stderr)
        sys.exit(1)

    with open(args.parsed_job, "r", encoding="utf-8") as f:
        parsed = json.load(f)

    tmap_data = parsed.get("tmap_expressions", {})
    lookup_data = parsed.get("lookup_query", {})

    if not tmap_data.get("columns"):
        print("ERROR: No tMap expressions found in parsed_job.json", file=sys.stderr)
        sys.exit(1)

    # Enhancement: flatten directory structure — output directly to models/
    # Ensure output directory exists
    models_dir = args.output_dir / "models"
    models_dir.mkdir(parents=True, exist_ok=True)

    # Generate SQL
    sql_content = build_intermediate_sql(tmap_data, lookup_data)
    sql_path = models_dir / "int_ach_activity_enriched.sql"
    sql_path.write_text(sql_content, encoding="utf-8")
    print(f"Written: {sql_path}")

    # Generate YAML
    yaml_content = build_intermediate_yaml(tmap_data)
    yaml_path = models_dir / "int_ach_activity_enriched.yml"
    yaml_path.write_text(yaml_content, encoding="utf-8")
    print(f"Written: {yaml_path}")

    col_count = tmap_data.get("column_count", 0)
    print(f"  Output columns: {col_count} (from tMap_1 TGT_TBL)")
    print(f"  Materialization: table")
    print(f"  Join: INNER JOIN on loan_nbr (tDBInput_2 UNIQUE_MATCH)")


if __name__ == "__main__":
    main()
