"""
cli.py

Command-line entry point for all talend-to-dbt-snowflake generator scripts.
Registers and orchestrates all 5 component scripts (v4 consolidated).

Usage:
    python agent-output/scripts/cli.py all                     # Run full pipeline
    python agent-output/scripts/cli.py parse                   # Parse .item XML only
    python agent-output/scripts/cli.py mart                    # Generate consolidated mart model
    python agent-output/scripts/cli.py tests                   # Generate dbt tests YAML
    python agent-output/scripts/cli.py config                  # Generate dbt project config
    python agent-output/scripts/cli.py report                  # Generate conversion report
    python agent-output/scripts/cli.py --help                  # Show help

Commands:
    all          Run all scripts in dependency order
    parse        parse_talend_job.py — parse .item XML → parsed_job.json
    mart         generate_mart_model.py — ach_actv.sql + .yml (consolidated single model)
    tests        generate_dbt_tests.py — comprehensive schema test YAMLs
    config       generate_dbt_project_config.py — dbt_project.yml, profiles.yml, etc.
    report       generate_conversion_report.py — conversion_report.md

Note: v4 enhancement consolidated staging, intermediate, and mart into a single model.
      The staging and intermediate commands have been removed.
"""

import argparse
import subprocess
import sys
from pathlib import Path


# ---------------------------------------------------------------------------
# Path constants
# ---------------------------------------------------------------------------
PROJECT_ROOT = Path(__file__).resolve().parent.parent.parent
SCRIPTS_DIR = PROJECT_ROOT / "agent-output" / "scripts"


# ---------------------------------------------------------------------------
# Script registry
# ---------------------------------------------------------------------------

SCRIPTS = {
    "parse": {
        "file": SCRIPTS_DIR / "parse_talend_job.py",
        "description": "Parse .item XML — emit parsed_job.json",
        "depends_on": [],
    },
    "mart": {
        "file": SCRIPTS_DIR / "generate_mart_model.py",
        "description": "Generate ach_actv.sql and .yml (consolidated single model, 24 cols)",
        "depends_on": ["parse"],
    },
    "tests": {
        "file": SCRIPTS_DIR / "generate_dbt_tests.py",
        "description": "Generate comprehensive schema test YAMLs for all models",
        "depends_on": ["parse"],
    },
    "config": {
        "file": SCRIPTS_DIR / "generate_dbt_project_config.py",
        "description": "Generate dbt_project.yml, profiles.yml, packages.yml, sources.yml",
        "depends_on": ["parse"],
    },
    "report": {
        "file": SCRIPTS_DIR / "generate_conversion_report.py",
        "description": "Generate conversion_report.md",
        "depends_on": ["parse"],
    },
}

# Execution order for 'all' command (v4: staging and intermediate removed)
ALL_ORDER = ["parse", "config", "mart", "tests", "report"]


# ---------------------------------------------------------------------------
# Runner
# ---------------------------------------------------------------------------

def run_script(command_name: str) -> bool:
    """Run a single script by command name. Returns True on success."""
    entry = SCRIPTS.get(command_name)
    if entry is None:
        print(f"ERROR: Unknown command '{command_name}'", file=sys.stderr)
        return False

    script_path = entry["file"]
    if not script_path.exists():
        print(f"ERROR: Script not found: {script_path}", file=sys.stderr)
        return False

    print(f"\n{'='*60}")
    print(f"Running: {command_name}")
    print(f"Script:  {script_path.name}")
    print(f"{'='*60}")

    result = subprocess.run(
        [sys.executable, str(script_path)],
        cwd=str(PROJECT_ROOT),
        capture_output=False,
    )

    if result.returncode != 0:
        print(f"\nFAILED: {command_name} exited with code {result.returncode}", file=sys.stderr)
        return False

    print(f"OK: {command_name}")
    return True


def run_all() -> bool:
    """Run all scripts in dependency order."""
    print("Running full pipeline: all 5 scripts (v4 consolidated)")
    print(f"Order: {' -> '.join(ALL_ORDER)}\n")

    failed = []
    for cmd in ALL_ORDER:
        success = run_script(cmd)
        if not success:
            failed.append(cmd)
            print(f"ERROR: '{cmd}' failed — stopping pipeline", file=sys.stderr)
            break

    print(f"\n{'='*60}")
    if failed:
        print(f"PIPELINE FAILED at: {failed[0]}")
        return False
    else:
        print(f"PIPELINE COMPLETE: All {len(ALL_ORDER)} scripts succeeded")
        print(f"\nOutputs:")
        print(f"  agent-output/research/parsed_job.json")
        print(f"  scripts-output/output/dbt_project/dbt_project.yml")
        print(f"  scripts-output/output/dbt_project/profiles.yml")
        print(f"  scripts-output/output/dbt_project/packages.yml")
        print(f"  scripts-output/output/dbt_project/models/sources.yml")
        print(f"  scripts-output/output/dbt_project/models/ach_actv.sql (consolidated model)")
        print(f"  scripts-output/output/dbt_project/models/ach_actv.yml")
        print(f"  scripts-output/output/conversion_report.md")
        return True


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main() -> None:
    """CLI entry point."""
    parser = argparse.ArgumentParser(
        description="Talend to dbt Snowflake converter — CLI entry point",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="\n".join(
            f"  {cmd:<14} {entry['description']}"
            for cmd, entry in SCRIPTS.items()
        )
    )
    parser.add_argument(
        "command",
        choices=list(SCRIPTS.keys()) + ["all"],
        help="Script to run (or 'all' to run full pipeline)"
    )

    args = parser.parse_args()

    if args.command == "all":
        success = run_all()
    else:
        success = run_script(args.command)

    sys.exit(0 if success else 1)


if __name__ == "__main__":
    main()
