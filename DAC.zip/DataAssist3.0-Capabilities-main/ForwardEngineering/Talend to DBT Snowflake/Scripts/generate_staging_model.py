"""
generate_staging_model.py

Generates the dbt staging model for ACH activity CSV data:
  - models/stg_ach_activity.sql  (materialized='view')
  - models/stg_ach_activity.yml  (schema tests)

Reads: agent-output/research/parsed_job.json
Writes: scripts-output/output/dbt_project/models/

Usage:
    python generate_staging_model.py
    python generate_staging_model.py --parsed-job path/to/parsed_job.json --output-dir path/to/dbt_project
"""

import argparse
import json
import sys
from pathlib import Path
from typing import Any, Dict, List


# ---------------------------------------------------------------------------
# Path constants
# ---------------------------------------------------------------------------
PROJECT_ROOT = Path(__file__).resolve().parent.parent.parent
DEFAULT_PARSED_JOB = PROJECT_ROOT / "agent-output" / "research" / "parsed_job.json"
DEFAULT_OUTPUT_DIR = PROJECT_ROOT / "scripts-output" / "output" / "dbt_project"


# ---------------------------------------------------------------------------
# SQL generation
# ---------------------------------------------------------------------------

def build_staging_sql(source_schema: Dict[str, Any]) -> str:
    """Build the stg_ach_activity.sql content from source schema."""
    # Enhancement: consolidate CTEs - move transformations into source CTE
    columns = source_schema.get("columns", [])

    cast_lines = []
    for col in columns:
        name = col["name"]  # already lowercase
        sf_type = col["snowflake_type"]
        pattern = col.get("pattern", "")

        if sf_type == "BIGINT":
            cast_lines.append(f"        CAST({name} AS BIGINT)                             AS {name}")
        elif sf_type.startswith("NUMBER"):
            cast_lines.append(f"        CAST({name} AS {sf_type})              AS {name}")
        elif sf_type == "TIMESTAMP_NTZ" and pattern:
            # Convert MM/dd/yyyy HH:mm:ss pattern to Snowflake format
            sf_pattern = pattern.replace("MM", "MM").replace("dd", "DD").replace("yyyy", "YYYY").replace("HH", "HH24").replace("mm", "MI").replace("ss", "SS")
            cast_lines.append(f"        TRY_TO_TIMESTAMP_NTZ({name}, '{sf_pattern}') AS {name}")
        elif sf_type == "INTEGER":
            cast_lines.append(f"        CAST({name} AS INTEGER)                            AS {name}")
        else:
            cast_lines.append(f"        CAST({name} AS VARCHAR)                            AS {name}")

    cast_sql = ",\n".join(cast_lines)

    return f"""-- stg_ach_activity.sql
-- Staging model for DailyACHActivity CSV data
-- Source: tFileInputDelimited_1 in LOAD_ACH_ACTV_FILE_SWH_0.1.item
-- Applies type casting from CSV strings to typed Snowflake columns
-- Note: CSV has no header row (HEADER=0); column names come from Talend schema definition

{{{{ config(materialized='view') }}}}

WITH source AS (
    SELECT
{cast_sql}
    FROM {{{{ source('raw_stage', 'ach_activity_csv') }}}}
)

SELECT * FROM source
"""


# ---------------------------------------------------------------------------
# YAML generation
# ---------------------------------------------------------------------------

def build_staging_yaml(source_schema: Dict[str, Any]) -> str:
    """Build the stg_ach_activity.yml content with schema tests."""
    columns = source_schema.get("columns", [])

    # Define which columns get which tests
    not_null_columns = {"loan_nbr", "pymt_amt", "actv_eff_dt"}

    col_entries = []
    for col in columns:
        name = col["name"]
        desc = _column_description(name, col)
        entry = f"      - name: {name}\n        description: \"{desc}\""
        if name in not_null_columns:
            entry += "\n        tests:\n          - not_null"
        col_entries.append(entry)

    col_yaml = "\n".join(col_entries)

    return f"""version: 2

models:
  - name: stg_ach_activity
    description: >
      Staged ACH activity data from DailyACHActivity CSV file.
      Source: tFileInputDelimited_1 in LOAD_ACH_ACTV_FILE_SWH_0.1.item.
      CSV format: comma-delimited, no header row, 20 columns.
      This model applies type casting and snake_case naming only — no business logic.
    columns:
{col_yaml}
"""


def _column_description(name: str, col: Dict[str, Any]) -> str:
    """Generate a brief column description."""
    descriptions = {
        "loan_nbr": "Loan number from source CSV",
        "pymt_amt": "Payment amount (precision 4)",
        "actv_eff_dt": "Activity effective date (from MM/dd/yyyy HH:mm:ss format)",
        "schd_type_cd": "Schedule type code",
        "schd_day": "Schedule day of month",
        "pymt_type_cd": "Payment type code",
        "cust_seg": "Customer segment",
        "pymt_mth_type": "Payment method type",
        "frst_nm": "First name",
        "last_nm": "Last name",
        "mth_cntrt_amt": "Monthly contract amount",
        "addl_escrw_amt": "Additional escrow amount",
        "addl_prin_amt": "Additional principal amount",
        "part_pymt_amt": "Partial payment amount",
        "tot_drft_amt": "Total draft amount",
        "pymt_agnt_id": "Payment agent ID",
        "schd_sts": "Schedule status",
        "disabled_dt": "Disabled date",
        "last_mod_dt": "Last modified date",
        "closd_by": "Closed by (user or system)",
    }
    return descriptions.get(name, f"Column {name} from source CSV")


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main() -> None:
    """Generate staging model SQL and YAML files."""
    parser = argparse.ArgumentParser(
        description="Generate dbt staging model for ACH activity"
    )
    parser.add_argument(
        "--parsed-job", type=Path, default=DEFAULT_PARSED_JOB,
        help=f"Path to parsed_job.json (default: {DEFAULT_PARSED_JOB})"
    )
    parser.add_argument(
        "--output-dir", type=Path, default=DEFAULT_OUTPUT_DIR,
        help=f"dbt project root directory (default: {DEFAULT_OUTPUT_DIR})"
    )
    args = parser.parse_args()

    # Load parsed job data
    if not args.parsed_job.exists():
        print(f"ERROR: parsed_job.json not found at {args.parsed_job}", file=sys.stderr)
        print("Run parse_talend_job.py first.", file=sys.stderr)
        sys.exit(1)

    with open(args.parsed_job, "r", encoding="utf-8") as f:
        parsed = json.load(f)

    source_schema = parsed.get("source_schema", {})
    if not source_schema.get("columns"):
        print("ERROR: No source schema columns found in parsed_job.json", file=sys.stderr)
        sys.exit(1)

    # Enhancement: update output path from models/staging/ to models/
    # Ensure output directory exists
    models_dir = args.output_dir / "models"
    models_dir.mkdir(parents=True, exist_ok=True)

    # Generate SQL
    sql_content = build_staging_sql(source_schema)
    sql_path = models_dir / "stg_ach_activity.sql"
    sql_path.write_text(sql_content, encoding="utf-8")
    print(f"Written: {sql_path}")

    # Generate YAML
    yaml_content = build_staging_yaml(source_schema)
    yaml_path = models_dir / "stg_ach_activity.yml"
    yaml_path.write_text(yaml_content, encoding="utf-8")
    print(f"Written: {yaml_path}")

    col_count = source_schema.get("column_count", 0)
    print(f"  Columns: {col_count}")
    print(f"  Materialization: view")
    print(f"  Source ref: {{{{ source('raw_stage', 'ach_activity_csv') }}}}")


if __name__ == "__main__":
    main()
