"""
generate_conversion_report.py

Generates a comprehensive Markdown conversion report documenting the complete
Talend-to-dbt component mapping for LOAD_ACH_ACTV_FILE_SWH_0.1.item.

Sections:
  1. Executive Summary
  2. Component Inventory Table
  3. Component-by-Component Mapping
  4. Out-of-Scope Components
  5. Data Flow Before/After
  6. Variable/Context Parameter Mapping
  7. Schema Mapping
  8. Testing Strategy
  9. How to Run

Reads: agent-output/research/parsed_job.json
Writes: scripts-output/output/conversion_report.md

Usage:
    python generate_conversion_report.py
    python generate_conversion_report.py --parsed-job path/to/parsed_job.json --output-dir path/to/output
"""

import argparse
import json
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List


# ---------------------------------------------------------------------------
# Path constants
# ---------------------------------------------------------------------------
PROJECT_ROOT = Path(__file__).resolve().parent.parent.parent
DEFAULT_PARSED_JOB = PROJECT_ROOT / "agent-output" / "research" / "parsed_job.json"
DEFAULT_OUTPUT_DIR = PROJECT_ROOT / "scripts-output" / "output"


# ---------------------------------------------------------------------------
# Report section builders
# ---------------------------------------------------------------------------

def section_executive_summary(job_metadata: Dict, source_schema: Dict, tmap_data: Dict) -> str:
    """Section 1: Executive Summary."""
    generated_at = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M UTC")
    return f"""# Talend to dbt Conversion Report

**Job:** LOAD_ACH_ACTV_FILE_SWH
**Version:** 0.1
**Generated:** {generated_at}
**Source file:** `user-config/inputs/LOAD_ACH_ACTV_FILE_SWH_0.1.item`

---

## 1. Executive Summary

This report documents the migration of the Talend ETL job `LOAD_ACH_ACTV_FILE_SWH` to a
dbt project targeting Snowflake.

| Property | Value |
|----------|-------|
| Source system | Talend Data Integration + SQL Server (SRVC_WH) |
| Target system | dbt + Snowflake |
| Migration type | Forward Engineering |
| Source CSV columns | {source_schema.get('column_count', 20)} |
| tMap output columns | {tmap_data.get('column_count', 25)} |
| In-scope Talend components | 6 |
| Out-of-scope components | 6 (tFTPGet, tFTPConnection, tFTPClose, tSendMail x3) |
| dbt models generated | 3 (staging, intermediate, mart) |
| dbt config files | 4 (dbt_project.yml, profiles.yml, packages.yml, sources.yml) |

### Job Purpose

The Talend job:
1. Downloads a `DailyACHActivity` CSV file from Sterling SFTP (Paymentus)
2. Reads the CSV with `tFileInputDelimited_1` (20 columns)
3. Looks up loan keys via `tDBInput_2` (LOAN_NBR_CROSS_REF table)
4. Joins and transforms data via `tMap_1` (INNER JOIN, 25-column output)
5. Inserts transformed rows into `ACH_ACTV` via `tDBOutput_1`
6. Updates `CURR_IND` flag via `tDBRow_3` (marks most recent row as current)

The dbt project replicates steps 2-6 as a 3-model SQL pipeline.

---
"""


def section_component_inventory(out_of_scope: List[Dict]) -> str:
    """Section 2: Component Inventory Table."""
    in_scope_components = [
        ("tDBConnection_1", "tMSSqlConnection", "SRVC_WH", "IN SCOPE", "profiles.yml + sources.yml"),
        ("tFileInputDelimited_1", "tFileInputDelimited", "Input_File", "IN SCOPE", "stg_ach_activity (source)"),
        ("tDBInput_2", "tMSSqlInput", "Loan_Key", "IN SCOPE", "loan_xref CTE in int_ach_activity_enriched"),
        ("tMap_1", "tMap", "TXFM", "IN SCOPE", "int_ach_activity_enriched.sql (JOIN + SELECT)"),
        ("tDBOutput_1", "tMSSqlOutput", "Insert", "IN SCOPE", "ach_actv.sql (incremental)"),
        ("tDBRow_3", "tMSSqlRow", "UPD_CURR_IND", "IN SCOPE", "ach_actv.sql post_hook"),
    ]

    informational_components = [
        ("tPrejob_1", "tPrejob", "Start", "INFORMATIONAL", "Not applicable — dbt handles job start"),
        ("tPostjob_1", "tPostjob", "End", "INFORMATIONAL", "Not applicable — dbt handles job end"),
        ("tDBClose_1", "tMSSqlClose", "Close_SRVC_WH", "INFORMATIONAL", "Not applicable — dbt manages connections"),
        ("tDBInput_1", "tMSSqlInput", "ETL_BATCH_ID", "INFORMATIONAL", "Replaced by dbt var etl_batch_id"),
        ("tJavaRow_1", "tJavaRow", "ETL_BATCH_ID_VAL", "INFORMATIONAL", "Replaced by dbt var"),
        ("tJava_1", "tJava", "SET_SRC_FILE_NAME", "INFORMATIONAL", "Not needed — file handled by Snowflake stage"),
        ("tLogCatcher_1", "tLogCatcher", "Catch_Log", "INFORMATIONAL", "Replaced by dbt run failure reporting"),
        ("tDBRow_1", "tMSSqlRow", "ETL_LOADSTATUS_INS", "INFORMATIONAL", "Audit logging — out of dbt scope"),
        ("tDBRow_2", "tMSSqlRow", "ETL_LOADSTATUS_UPDATE", "INFORMATIONAL", "Audit update on error — out of scope"),
        ("tFileCopy_2", "tFileCopy", "Archive_Src_File", "INFORMATIONAL", "File archiving — not applicable in dbt"),
        ("tFileProperties_1", "tFileProperties", "Get_File_Info", "INFORMATIONAL", "File check — not applicable in dbt"),
        ("tJavaRow_2", "tJavaRow", "(file size check)", "INFORMATIONAL", "File size validation — not applicable"),
        ("tJava_3", "tJava", "Log_Message", "INFORMATIONAL", "Debug log — not applicable"),
        ("tDie_1", "tDie", "Kill2", "INFORMATIONAL", "Error termination — dbt run failure"),
        ("tDie_2", "tDie", "Kill1", "INFORMATIONAL", "Error termination — dbt run failure"),
    ]

    rows = []
    for unique_name, component, label, status, dbt_equiv in in_scope_components:
        rows.append(f"| `{unique_name}` | `{component}` | {label} | **{status}** | {dbt_equiv} |")

    for entry in out_of_scope:
        rows.append(f"| `{entry['unique_name']}` | `{entry['component']}` | {entry['label']} | **OUT OF SCOPE** | {entry['reason']} |")

    for unique_name, component, label, status, dbt_equiv in informational_components:
        rows.append(f"| `{unique_name}` | `{component}` | {label} | {status} | {dbt_equiv} |")

    table = "\n".join(rows)

    return f"""## 2. Component Inventory

| Unique Name | Component | Label | Status | dbt Equivalent |
|-------------|-----------|-------|--------|----------------|
{table}

---
"""


def section_component_mappings(
    source_schema: Dict,
    lookup_data: Dict,
    tmap_data: Dict,
    target_data: Dict,
    post_insert_data: Dict,
) -> str:
    """Section 3: Component-by-component mapping detail."""
    # tMap expression table
    expr_rows = []
    for col in tmap_data.get("columns", []):
        talend_expr = col.get("talend_expression", "")
        sf_expr = col.get("snowflake_expression", col["name"])
        source = "literal" if talend_expr.startswith('"') else \
                 "function" if "TalendDate" in talend_expr or "getCurrentDate" in talend_expr else \
                 "context_var" if "context." in talend_expr else \
                 "lookup" if "row6." in talend_expr else "csv"
        expr_rows.append(
            f"| `{col['talend_name']}` | `{talend_expr}` | `{sf_expr}` | {source} |"
        )

    expr_table = "\n".join(expr_rows)

    return f"""## 3. Component-by-Component Mapping

### 3.1 tDBConnection_1 → profiles.yml + sources.yml

**Talend:** `tMSSqlConnection` — JTDS connection to SQL Server `SRVC_WH`
- Server: `context.connection_srvcwhmssql_Server` (QA: CRSDWSQLDEV02, PROD: CRSDWSQLPRD)
- Database: `SRVC_WH`
- Schema: `DBO`

**dbt Snowflake equivalent:**
- `profiles.yml`: Snowflake connection configured via environment variables
- `sources.yml`: Source declarations for `ach_activity_csv` and `loan_nbr_cross_ref`

---

### 3.2 tFileInputDelimited_1 → stg_ach_activity (source + staging model)

**Talend:** `tFileInputDelimited` — reads DailyACHActivity CSV
- Path: `{{context.connection_swhfilepath_INBOUND_DIR}}/paymentus/{{context.parameter_SRC_FILE_NAME}}`
- Delimiter: comma, CSV mode, no header row (HEADER=0)
- 20 columns

**dbt equivalent:** `{{ source('raw_stage', 'ach_activity_csv') }}` in `stg_ach_activity.sql`

| Talend Column | Type | Snowflake Type | Notes |
|---------------|------|----------------|-------|
| LOAN_NBR | id_Long | BIGINT | |
| PYMT_AMT | id_Double (19,4) | NUMBER(19,4) | |
| ACTV_EFF_DT | id_Date | TIMESTAMP_NTZ | Pattern: MM/dd/yyyy HH:mm:ss |
| SCHD_TYPE_CD | id_String | VARCHAR | |
| SCHD_DAY | id_Integer | INTEGER | |
| PYMT_TYPE_CD | id_String | VARCHAR | |
| CUST_SEG | id_String | VARCHAR | |
| PYMT_MTH_TYPE | id_String | VARCHAR | |
| FRST_NM | id_String | VARCHAR | |
| LAST_NM | id_String | VARCHAR | |
| MTH_CNTRT_AMT | id_Double (19,4) | NUMBER(19,4) | |
| ADDL_ESCRW_AMT | id_Double (19,4) | NUMBER(19,4) | |
| ADDL_PRIN_AMT | id_Double (19,4) | NUMBER(19,4) | |
| PART_PYMT_AMT | id_Double (19,4) | NUMBER(19,4) | |
| TOT_DRFT_AMT | id_Double (19,4) | NUMBER(19,4) | |
| PYMT_AGNT_ID | id_String | VARCHAR | |
| SCHD_STS | id_String | VARCHAR | |
| DISABLED_DT | id_Date | TIMESTAMP_NTZ | Nullable |
| LAST_MOD_DT | id_Date | TIMESTAMP_NTZ | Nullable |
| CLOSD_BY | id_String | VARCHAR | Nullable |

---

### 3.3 tDBInput_2 → loan_xref CTE in int_ach_activity_enriched

**Talend SQL:**
```sql
select LOAN_KEY, CAST(LOAN_NBR as bigint) AS LOAN_NBR
from SRVC_WH.DBO.LOAN_NBR_CROSS_REF (nolock)
```

**dbt/Snowflake SQL:**
```sql
SELECT
    CAST(loan_key AS BIGINT) AS loan_key,
    CAST(loan_nbr AS BIGINT) AS loan_nbr
FROM {{{{ source('srvc_wh', 'loan_nbr_cross_ref') }}}}
```
Note: `(nolock)` hint omitted — not applicable in Snowflake.

---

### 3.4 tMap_1 → int_ach_activity_enriched (SQL SELECT with JOIN)

**Talend configuration:**
- Input row1: `tFileInputDelimited_1` (CSV rows) — main input
- Input row6: `tDBInput_2` (LOAN_NBR_CROSS_REF) — lookup, `innerJoin=true`
- Join: `row1.LOAN_NBR = row6.LOAN_NBR` (INNER JOIN, UNIQUE_MATCH)
- Output: TGT_TBL — 25 columns

**tMap Expression Translations:**

| Output Column | Talend Expression | Snowflake SQL | Source Type |
|---------------|------------------|---------------|-------------|
{expr_table}

---

### 3.5 tDBOutput_1 → ach_actv.sql (incremental)

**Talend:** `tMSSqlOutput`
- Table: `ACH_ACTV`
- TABLE_ACTION: NONE (no truncate/recreate)
- DATA_ACTION: INSERT (append only)
- BATCH_SIZE: 10000

**dbt equivalent:**
```sql
{{{{ config(
    materialized='incremental',
    incremental_strategy='append',
    on_schema_change='fail'
) }}}}
SELECT [25 columns] FROM {{{{ ref('int_ach_activity_enriched') }}}}
```

---

### 3.6 tDBRow_3 (UPD_CURR_IND) → ach_actv.sql post_hook

**Talend:** Runs after INSERT, manages `CURR_IND` flag via T-SQL with temp tables and ROW_NUMBER().

**dbt post_hook translation (Snowflake SQL):**
```sql
-- Step 1: Set curr_ind='N' for older rows of the same loan_key
UPDATE {{{{ this }}}} SET curr_ind = 'N'
WHERE curr_ind = 'Y'
AND etl_batch_id < {{{{ var('etl_batch_id', 0) }}}}
AND loan_key IN (
    SELECT DISTINCT loan_key FROM {{{{ this }}}}
    WHERE etl_batch_id = {{{{ var('etl_batch_id', 0) }}}}
);

-- Step 2: Set curr_ind='Y' for most recent row per loan_key
WITH ranked AS (
    SELECT loan_key,
    ROW_NUMBER() OVER(PARTITION BY loan_key ORDER BY last_mod_dt DESC NULLS LAST, actv_eff_dt DESC NULLS LAST) AS rn
    FROM {{{{ this }}}} WHERE etl_batch_id = {{{{ var('etl_batch_id', 0) }}}}
)
UPDATE {{{{ this }}}} t SET curr_ind = 'Y'
FROM ranked r WHERE t.loan_key = r.loan_key AND t.etl_batch_id = {{{{ var('etl_batch_id', 0) }}}} AND r.rn = 1;
```

---
"""


def section_out_of_scope(out_of_scope: List[Dict]) -> str:
    """Section 4: Out-of-scope components."""
    entries = []
    recommendations = {
        "tFTPGet": "Use Snowflake external stage with S3/Azure/GCS, or a separate pipeline tool (Airflow, Fivetran, dbt-cloud-orchestration)",
        "tFTPConnection": "SFTP connection management — handled by file ingestion layer",
        "tFTPClose": "SFTP connection close — handled by file ingestion layer",
        "tSendMail": "Use dbt Cloud alert webhooks, Slack/PagerDuty integration, or Airflow email operator",
    }
    for entry in out_of_scope:
        component = entry.get("component", "")
        rec = recommendations.get(component, "Implement via external tooling")
        entries.append(
            f"### {entry['unique_name']} ({entry['component']})\n\n"
            f"- **Label:** {entry['label']}\n"
            f"- **Reason out of scope:** {entry['reason']}\n"
            f"- **Recommendation:** {rec}\n"
        )

    return "## 4. Out-of-Scope Components\n\n" + "\n".join(entries) + "\n---\n"


def section_data_flow() -> str:
    """Section 5: Data flow comparison (before/after)."""
    return """## 5. Data Flow Comparison

### Before (Talend — Procedural)

```
tPrejob
  └── tMSSqlConnection (Open SRVC_WH)
       ├── tDBInput_1 → tJavaRow_1 (Get ETL_BATCH_ID sequence)
       ├── tDBRow_1 (INSERT ETL_LOADSTATUS = PROCESSING)
       └── tJava_1 (Set SRC_FILE_NAME)

tFTPConnection (Open Sterling SFTP)  [OUT OF SCOPE]
  └── tFTPGet (Download DailyACHActivity*.csv)  [OUT OF SCOPE]

tFileProperties_1 → tJavaRow_2 (Check file size)
  └── tJava_3 (Log message)

tFileInputDelimited_1 (Read CSV, 20 cols)
  ├── tDBInput_2 (Load LOAN_NBR_CROSS_REF lookup)
  └── tMap_1 (INNER JOIN + 25-col transform)
       └── tDBOutput_1 (INSERT INTO ACH_ACTV)
            └── tDBRow_3 (UPDATE CURR_IND)
                 └── tSendMail_2 (Success email)  [OUT OF SCOPE]

tLogCatcher_1 (Catch errors)
  ├── tDBRow_2 (UPDATE ETL_LOADSTATUS = ABORTED)
  └── tSendMail_1 (Failure email)  [OUT OF SCOPE]

tSendMail_3 (No-file notification)  [OUT OF SCOPE]

tPostjob
  ├── tDBClose_1
  └── tFTPClose_1
```

### After (dbt — Declarative)

```
sources.yml
  ├── raw_stage.ach_activity_csv         (DailyACHActivity CSV — pre-loaded to Snowflake)
  └── srvc_wh.loan_nbr_cross_ref         (LOAN_NBR_CROSS_REF — replicated to Snowflake)
         │
         ▼
stg_ach_activity [view]                  (type casting, renaming — tFileInputDelimited_1)
         │
         ▼
int_ach_activity_enriched [table]        (INNER JOIN + tMap_1 transformations)
         │
         ▼
ach_actv [incremental/append]            (tDBOutput_1 INSERT)
  └── post_hook: UPDATE curr_ind         (tDBRow_3 UPD_CURR_IND)
```

---
"""


def section_variable_mapping(contexts: Dict) -> str:
    """Section 6: Variable/context parameter mapping."""
    qa_params = contexts.get("QA", {})

    rows = [
        ("parameter_ETL_BATCH_ID", "id_Long", "(from sequence)", "{{ var('etl_batch_id', 0) }}", "dbt variable"),
        ("parameter_SRC_FILE_NAME", "id_String", qa_params.get("parameter_SRC_FILE_NAME", ""), "Not needed", "File handled by Snowflake stage"),
        ("parameter_SRC_FILE_PATTERN", "id_String", qa_params.get("parameter_SRC_FILE_PATTERN", ""), "Not needed", "File pattern not needed in dbt"),
        ("connection_srvcwhmssql_Database", "id_String", "SRVC_WH", "env_var('SNOWFLAKE_DATABASE', 'SRVC_WH')", "profiles.yml"),
        ("connection_srvcwhmssql_Server", "id_String", "CRSDWSQLDEV02", "env_var('SNOWFLAKE_ACCOUNT')", "profiles.yml"),
        ("connection_swhfilepath_INBOUND_DIR", "id_Directory", "/tldmnt/data_governance/inbound/servicing_wh/", "Not needed", "Files in Snowflake stage"),
        ("parameter_STERLING_SFTP_HOST", "id_String", "b2bfgint.mrcooper.com", "Out of scope", "SFTP out of scope"),
        ("connection_datagovernancemail_*", "id_String", "(email config)", "Out of scope", "tSendMail out of scope"),
    ]

    table_rows = "\n".join(
        f"| `{p}` | {t} | `{v or '(empty)'}` | `{dbt}` | {note} |"
        for p, t, v, dbt, note in rows
    )

    return f"""## 6. Variable / Context Parameter Mapping

| Talend Context Parameter | Type | QA Value | dbt Equivalent | Notes |
|--------------------------|------|----------|----------------|-------|
{table_rows}

---
"""


def section_schema_mapping(source_schema: Dict, tmap_data: Dict) -> str:
    """Section 7: Schema mapping from CSV to mart."""
    csv_cols = {col["name"]: col for col in source_schema.get("columns", [])}
    tmap_cols = {col["name"]: col for col in tmap_data.get("columns", [])}

    rows = []
    # Start with tMap output columns
    for col_name, tmap_col in tmap_cols.items():
        csv_col = csv_cols.get(col_name)
        csv_type = csv_col["snowflake_type"] if csv_col else "—"
        csv_name = col_name if csv_col else "—"
        expr = tmap_col.get("talend_expression", "").strip()
        origin = "literal" if expr.startswith('"') else \
                 "function" if "TalendDate" in expr else \
                 "context" if "context." in expr else \
                 "lookup" if "row6." in expr else "csv"
        rows.append(f"| `{csv_name}` | `{csv_type}` | `{col_name}` | `{col_name}` | `{col_name}` | {origin} |")

    table = "\n".join(rows)

    return f"""## 7. Schema Mapping

| CSV Column | CSV Type | stg_ach_activity | int_ach_activity_enriched | ach_actv | Origin |
|------------|----------|------------------|---------------------------|----------|--------|
{table}

**Note:** The intermediate and mart models have 5 additional columns not in the CSV source:
- `loan_key` — from LOAN_NBR_CROSS_REF lookup (tDBInput_2)
- `sor_cd` — hardcoded literal `'PAYMENTUS'`
- `aud_cre_by_nm` — hardcoded literal `'TALEND-ETL-INSERT'`
- `aud_cre_dttm` — `CURRENT_TIMESTAMP` at load time
- `etl_batch_id` — from dbt variable
- `curr_ind` — hardcoded `'N'` on insert; updated to `'Y'` by post-hook

---
"""


def section_testing_strategy() -> str:
    """Section 8: Testing strategy."""
    return """## 8. Testing Strategy

| Talend Mechanism | dbt Equivalent |
|-----------------|----------------|
| tFileInputDelimited `DIE_ON_ERROR=true` | dbt run fails if source table is empty/missing |
| tMap `DIE_ON_ERROR=true` | dbt model fails if intermediate CTE returns errors |
| tDBOutput_1 `DIE_ON_ERROR=true` | dbt incremental model fails on write errors |
| tLogCatcher_1 (error catch) | dbt run exit code + dbt Cloud notifications |
| tDie_1 / tDie_2 (kill on bad file) | Snowflake stage loading validation |

### Schema Tests Added

**stg_ach_activity:**
- `not_null` on `loan_nbr`, `pymt_amt`, `actv_eff_dt`

**int_ach_activity_enriched:**
- `not_null` on `loan_key`, `actv_eff_dt`
- `not_null` + `accepted_values(['PAYMENTUS'])` on `sor_cd`
- `not_null` + `accepted_values(['TALEND-ETL-INSERT'])` on `aud_cre_by_nm`
- `not_null` + `accepted_values(['Y','N'])` on `curr_ind`
- `not_null` on `etl_batch_id`

**ach_actv:**
- `not_null` on `loan_key`, `actv_eff_dt`, `pymt_amt`, `etl_batch_id`
- `not_null` + `accepted_values(['PAYMENTUS'])` on `sor_cd`
- `not_null` + `accepted_values(['TALEND-ETL-INSERT'])` on `aud_cre_by_nm`
- `not_null` + `accepted_values(['Y','N'])` on `curr_ind`

---
"""


def section_how_to_run() -> str:
    """Section 9: How to run."""
    return """## 9. How to Run

### Prerequisites
1. Snowflake account with appropriate permissions
2. Python 3.8+ with dbt-snowflake installed
3. Environment variables configured (see profiles.yml)
4. DailyACHActivity CSV loaded into Snowflake external stage or seed
5. `LOAN_NBR_CROSS_REF` table replicated to Snowflake

### Setup
```bash
# Install dbt Snowflake adapter
pip install dbt-snowflake

# Navigate to project
cd scripts-output/output/dbt_project

# Install packages
dbt deps

# Verify connection
dbt debug
```

### Run
```bash
# Full run (first time)
dbt run --vars '{etl_batch_id: 12345}'

# Run with tests
dbt run --vars '{etl_batch_id: 12345}' && dbt test

# Run specific model
dbt run --models ach_actv --vars '{etl_batch_id: 12345}'

# Full refresh (rebuild all tables)
dbt run --full-refresh --vars '{etl_batch_id: 12345}'
```

### Generate dbt Artifacts
```bash
# Run all generator scripts (from project root)
python agent-output/scripts/cli.py all

# Or run individually
python agent-output/scripts/parse_talend_job.py
python agent-output/scripts/generate_dbt_project_config.py
python agent-output/scripts/generate_staging_model.py
python agent-output/scripts/generate_intermediate_model.py
python agent-output/scripts/generate_mart_model.py
python agent-output/scripts/generate_dbt_tests.py
python agent-output/scripts/generate_conversion_report.py
```

---

*Report generated by `generate_conversion_report.py` from `LOAD_ACH_ACTV_FILE_SWH_0.1.item`*
"""


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main() -> None:
    """Generate the conversion report."""
    parser = argparse.ArgumentParser(
        description="Generate Talend-to-dbt conversion report"
    )
    parser.add_argument(
        "--parsed-job", type=Path, default=DEFAULT_PARSED_JOB,
        help=f"Path to parsed_job.json (default: {DEFAULT_PARSED_JOB})"
    )
    parser.add_argument(
        "--output-dir", type=Path, default=DEFAULT_OUTPUT_DIR,
        help=f"Output directory (default: {DEFAULT_OUTPUT_DIR})"
    )
    args = parser.parse_args()

    # Load parsed job data
    if not args.parsed_job.exists():
        print(f"ERROR: parsed_job.json not found at {args.parsed_job}", file=sys.stderr)
        print("Run parse_talend_job.py first.", file=sys.stderr)
        sys.exit(1)

    with open(args.parsed_job, "r", encoding="utf-8") as f:
        parsed = json.load(f)

    job_metadata = parsed.get("job_metadata", {})
    source_schema = parsed.get("source_schema", {})
    lookup_data = parsed.get("lookup_query", {})
    tmap_data = parsed.get("tmap_expressions", {})
    target_data = parsed.get("target_table", {})
    post_insert_data = parsed.get("post_insert_sql", {})
    connection = parsed.get("connection", {})
    contexts = parsed.get("contexts", {})
    out_of_scope = parsed.get("out_of_scope", [])

    # Build report sections
    sections = [
        section_executive_summary(job_metadata, source_schema, tmap_data),
        section_component_inventory(out_of_scope),
        section_component_mappings(source_schema, lookup_data, tmap_data, target_data, post_insert_data),
        section_out_of_scope(out_of_scope),
        section_data_flow(),
        section_variable_mapping(contexts),
        section_schema_mapping(source_schema, tmap_data),
        section_testing_strategy(),
        section_how_to_run(),
    ]

    report_content = "\n".join(sections)

    # Write output
    args.output_dir.mkdir(parents=True, exist_ok=True)
    output_path = args.output_dir / "conversion_report.md"
    output_path.write_text(report_content, encoding="utf-8")
    print(f"Written: {output_path}")
    print(f"  Sections: 9")
    print(f"  Source columns: {source_schema.get('column_count', 0)}")
    print(f"  tMap columns: {tmap_data.get('column_count', 0)}")
    print(f"  Out-of-scope components: {len(out_of_scope)}")
    print(f"  Report size: {len(report_content)} chars")


if __name__ == "__main__":
    main()
