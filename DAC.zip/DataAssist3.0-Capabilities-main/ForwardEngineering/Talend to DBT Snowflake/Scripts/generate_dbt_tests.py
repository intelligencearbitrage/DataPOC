"""
generate_dbt_tests.py

Generates schema test YAML file for the consolidated dbt model:
  - models/ach_actv.yml                        (24 columns, no curr_ind)

v4 Enhancement: Staging and intermediate models obsoleted — only ach_actv.yml generated.

Tests are derived from source column definitions and business rules in the .item file.

Reads: agent-output/research/parsed_job.json
Writes: scripts-output/output/dbt_project/models/ach_actv.yml

Usage:
    python generate_dbt_tests.py
    python generate_dbt_tests.py --parsed-job path/to/parsed_job.json --output-dir path/to/dbt_project
"""

import argparse
import json
import sys
from pathlib import Path
from typing import Any, Dict, List, Union


# ---------------------------------------------------------------------------
# Path constants
# ---------------------------------------------------------------------------
PROJECT_ROOT = Path(__file__).resolve().parent.parent.parent
DEFAULT_PARSED_JOB = PROJECT_ROOT / "agent-output" / "research" / "parsed_job.json"
DEFAULT_OUTPUT_DIR = PROJECT_ROOT / "scripts-output" / "output" / "dbt_project"


# ---------------------------------------------------------------------------
# Test definitions
# ---------------------------------------------------------------------------

# Columns that must not be null in staging
STAGING_NOT_NULL = {"loan_nbr", "pymt_amt", "actv_eff_dt"}

# Columns + tests for intermediate model
INTERMEDIATE_TESTS: Dict[str, List] = {
    "loan_key": ["not_null"],
    "actv_eff_dt": ["not_null"],
    "sor_cd": [
        "not_null",
        {"accepted_values": {"values": ["PAYMENTUS"]}},
    ],
    "aud_cre_by_nm": [
        "not_null",
        {"accepted_values": {"values": ["TALEND-ETL-INSERT"]}},
    ],
    "curr_ind": [
        "not_null",
        {"accepted_values": {"values": ["Y", "N"]}},
    ],
    "etl_batch_id": ["not_null"],
}

# Columns + tests for mart model (v4: no curr_ind)
MART_TESTS: Dict[str, List] = {
    "loan_key": ["not_null"],
    "actv_eff_dt": ["not_null"],
    "sor_cd": [
        "not_null",
        {"accepted_values": {"values": ["PAYMENTUS"]}},
    ],
    "aud_cre_by_nm": [
        "not_null",
        {"accepted_values": {"values": ["TALEND-ETL-INSERT"]}},
    ],
    "etl_batch_id": ["not_null"],
    "pymt_amt": ["not_null"],
}


# ---------------------------------------------------------------------------
# YAML building helpers
# ---------------------------------------------------------------------------

def format_test(test: Union[str, Dict]) -> str:
    """Format a single test entry as YAML string."""
    if isinstance(test, str):
        return f"          - {test}"
    elif isinstance(test, dict):
        lines = []
        for test_name, test_args in test.items():
            lines.append(f"          - {test_name}:")
            for arg_key, arg_val in test_args.items():
                if isinstance(arg_val, list):
                    vals_str = "[" + ", ".join(f"'{v}'" for v in arg_val) + "]"
                    lines.append(f"              {arg_key}: {vals_str}")
                else:
                    lines.append(f"              {arg_key}: {arg_val}")
        return "\n".join(lines)
    return ""


def build_column_entry(
    name: str,
    description: str,
    tests: List = None,
) -> str:
    """Build a single column YAML entry."""
    entry = f"      - name: {name}\n        description: \"{description}\""
    if tests:
        test_lines = [format_test(t) for t in tests]
        entry += "\n        tests:\n" + "\n".join(test_lines)
    return entry


# ---------------------------------------------------------------------------
# YAML generators
# ---------------------------------------------------------------------------

def build_staging_full_yaml(source_schema: Dict[str, Any]) -> str:
    """Full stg_ach_activity.yml with comprehensive tests."""
    columns = source_schema.get("columns", [])

    descriptions = {
        "loan_nbr": "Loan number from source CSV — foreign key to LOAN_NBR_CROSS_REF",
        "pymt_amt": "Payment amount (NUMBER 19,4)",
        "actv_eff_dt": "Activity effective date (parsed from MM/dd/yyyy HH:mm:ss)",
        "schd_type_cd": "Schedule type code",
        "schd_day": "Schedule day of month",
        "pymt_type_cd": "Payment type code",
        "cust_seg": "Customer segment",
        "pymt_mth_type": "Payment method type",
        "frst_nm": "First name",
        "last_nm": "Last name",
        "mth_cntrt_amt": "Monthly contract amount",
        "addl_escrw_amt": "Additional escrow amount",
        "addl_prin_amt": "Additional principal amount",
        "part_pymt_amt": "Partial payment amount",
        "tot_drft_amt": "Total draft amount",
        "pymt_agnt_id": "Payment agent ID",
        "schd_sts": "Schedule status",
        "disabled_dt": "Disabled date (nullable)",
        "last_mod_dt": "Last modified date (nullable)",
        "closd_by": "Closed by (nullable)",
    }

    col_entries = []
    for col in columns:
        name = col["name"]
        desc = descriptions.get(name, f"Column {name} from DailyACHActivity CSV")
        tests = ["not_null"] if name in STAGING_NOT_NULL else []
        col_entries.append(build_column_entry(name, desc, tests))

    col_yaml = "\n".join(col_entries)

    return f"""version: 2

models:
  - name: stg_ach_activity
    description: >
      Staged ACH activity data from DailyACHActivity CSV file.
      Source: tFileInputDelimited_1 in LOAD_ACH_ACTV_FILE_SWH_0.1.item.
      Applies type casting only — no business logic.
      CSV: comma-delimited, no header row (HEADER=0), 20 columns.
    columns:
{col_yaml}
"""


def build_intermediate_full_yaml(tmap_data: Dict[str, Any]) -> str:
    """Full int_ach_activity_enriched.yml with comprehensive tests."""
    columns = tmap_data.get("columns", [])

    descriptions = {
        "loan_key": "Internal loan key resolved from LOAN_NBR_CROSS_REF (tDBInput_2)",
        "actv_eff_dt": "Activity effective date",
        "sor_cd": "Source of record — always PAYMENTUS (tMap literal)",
        "pymt_amt": "Payment amount",
        "schd_type_cd": "Schedule type code",
        "schd_day": "Schedule day",
        "pymt_type_cd": "Payment type code",
        "cust_seg": "Customer segment",
        "pymt_mth_type": "Payment method type",
        "frst_nm": "First name",
        "last_nm": "Last name",
        "mth_cntrt_amt": "Monthly contract amount",
        "addl_escrw_amt": "Additional escrow amount",
        "addl_prin_amt": "Additional principal amount",
        "part_pymt_amt": "Partial payment amount",
        "tot_drft_amt": "Total draft amount",
        "pymt_agnt_id": "Payment agent ID",
        "schd_sts": "Schedule status",
        "disabled_dt": "Disabled date",
        "last_mod_dt": "Last modified date",
        "closd_by": "Closed by",
        "aud_cre_by_nm": "Audit created by — always TALEND-ETL-INSERT (tMap literal)",
        "aud_cre_dttm": "Audit created datetime — CURRENT_TIMESTAMP at load time",
        "etl_batch_id": "ETL batch tracking ID from dbt variable etl_batch_id",
        "curr_ind": "Current indicator — N on insert; updated to Y by ach_actv post-hook",
    }

    col_entries = []
    for col in columns:
        name = col["name"]
        desc = descriptions.get(name, f"Column {name}")
        tests = INTERMEDIATE_TESTS.get(name, [])
        col_entries.append(build_column_entry(name, desc, tests))

    col_yaml = "\n".join(col_entries)

    return f"""version: 2

models:
  - name: int_ach_activity_enriched
    description: >
      ACH activity enriched with loan key (INNER JOIN on LOAN_NBR_CROSS_REF) and
      tMap_1 transformations applied. Replicates tDBInput_2 + tMap_1 (TXFM) from
      LOAD_ACH_ACTV_FILE_SWH_0.1.item.
    columns:
{col_yaml}
"""


def build_mart_full_yaml(tmap_data: Dict[str, Any]) -> str:
    """Full ach_actv.yml with comprehensive tests (v4: 24 columns, no curr_ind)."""
    columns = tmap_data.get("columns", [])

    descriptions = {
        "loan_key": "Internal loan key from LOAN_NBR_CROSS_REF — primary identifier",
        "actv_eff_dt": "Activity effective date",
        "sor_cd": "Source of record code — always PAYMENTUS",
        "pymt_amt": "Payment amount",
        "schd_type_cd": "Schedule type code",
        "schd_day": "Schedule day",
        "pymt_type_cd": "Payment type code",
        "cust_seg": "Customer segment",
        "pymt_mth_type": "Payment method type",
        "frst_nm": "First name",
        "last_nm": "Last name",
        "mth_cntrt_amt": "Monthly contract amount",
        "addl_escrw_amt": "Additional escrow amount",
        "addl_prin_amt": "Additional principal amount",
        "part_pymt_amt": "Partial payment amount",
        "tot_drft_amt": "Total draft amount",
        "pymt_agnt_id": "Payment agent ID",
        "schd_sts": "Schedule status",
        "disabled_dt": "Disabled date",
        "last_mod_dt": "Last modified date",
        "closd_by": "Closed by",
        "aud_cre_by_nm": "Audit created by — always TALEND-ETL-INSERT",
        "aud_cre_dttm": "Audit created datetime",
        "etl_batch_id": "ETL batch tracking ID",
    }

    col_entries = []
    for col in columns:
        name = col["name"]
        # Enhancement: Skip curr_ind column (removed in v4)
        if name == "curr_ind":
            continue
        desc = descriptions.get(name, f"Column {name}")
        tests = MART_TESTS.get(name, [])
        col_entries.append(build_column_entry(name, desc, tests))

    col_yaml = "\n".join(col_entries)

    return f"""version: 2

models:
  - name: ach_actv
    description: >
      Consolidated ACH activity mart — Snowflake equivalent of SQL Server ACH_ACTV target table.
      Single model replicating full Talend pipeline: tFileInputDelimited_1 (CSV source with type casts),
      tDBInput_2 (loan_nbr lookup), tMap_1 (transformations), and tDBOutput_1 (INSERT INTO ACH_ACTV).
      From LOAD_ACH_ACTV_FILE_SWH_0.1.item. Materialization: table.
    columns:
{col_yaml}
"""


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main() -> None:
    """Generate schema test YAML file for consolidated mart model (v4)."""
    parser = argparse.ArgumentParser(
        description="Generate dbt schema test YAML for ACH activity consolidated model"
    )
    parser.add_argument(
        "--parsed-job", type=Path, default=DEFAULT_PARSED_JOB,
        help=f"Path to parsed_job.json (default: {DEFAULT_PARSED_JOB})"
    )
    parser.add_argument(
        "--output-dir", type=Path, default=DEFAULT_OUTPUT_DIR,
        help=f"dbt project root directory (default: {DEFAULT_OUTPUT_DIR})"
    )
    args = parser.parse_args()

    # Load parsed job data
    if not args.parsed_job.exists():
        print(f"ERROR: parsed_job.json not found at {args.parsed_job}", file=sys.stderr)
        print("Run parse_talend_job.py first.", file=sys.stderr)
        sys.exit(1)

    with open(args.parsed_job, "r", encoding="utf-8") as f:
        parsed = json.load(f)

    source_schema = parsed.get("source_schema", {})
    tmap_data = parsed.get("tmap_expressions", {})

    if not source_schema.get("columns") or not tmap_data.get("columns"):
        print("ERROR: Missing source schema or tMap data in parsed_job.json", file=sys.stderr)
        sys.exit(1)

    # v4 Enhancement: only generate ach_actv.yml (staging and intermediate obsoleted)
    models_dir = args.output_dir / "models"
    models_dir.mkdir(parents=True, exist_ok=True)

    # Generate consolidated mart YAML (24 columns, no curr_ind)
    mart_yaml = build_mart_full_yaml(tmap_data)
    mart_path = models_dir / "ach_actv.yml"
    mart_path.write_text(mart_yaml, encoding="utf-8")
    print(f"Written: {mart_path}")

    print(f"\nTest coverage summary:")
    print(f"  ach_actv: {sum(len(v) for v in MART_TESTS.values())} tests across {len(MART_TESTS)} columns (24 columns, curr_ind removed)")


if __name__ == "__main__":
    main()
