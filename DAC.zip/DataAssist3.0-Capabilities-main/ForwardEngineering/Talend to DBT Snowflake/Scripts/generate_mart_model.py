"""
generate_mart_model.py

Generates the consolidated dbt mart model for ACH_ACTV:
  - models/ach_actv.sql  (materialized='incremental', incremental_strategy='append', no post-hooks)
  - models/ach_actv.yml  (schema tests)

v4 Enhancement: Consolidates staging, intermediate, and mart into a single model.
  - CTE 1 (cte_source): Type casts from raw CSV source (absorbs stg_ach_activity.sql)
  - CTE 2 (cte_enriched): INNER JOIN on loan_nbr + tMap expressions (absorbs int_ach_activity_enriched.sql)
  - Final SELECT: 24 explicit columns (curr_ind removed)

No SCD Type 1 tracking — curr_ind column and post-hooks removed entirely per user decision.

Reads: agent-output/research/parsed_job.json
Writes: scripts-output/output/dbt_project/models/

Usage:
    python generate_mart_model.py
    python generate_mart_model.py --parsed-job path/to/parsed_job.json --output-dir path/to/dbt_project

Enhancement History:
  v1 (2026-04-24): Directory flattening (models/marts/ → models/)
  v2 (2026-04-24): Post-hooks REMOVED (append strategy, CURR_IND always 'N')
  v3 (2026-05-08): Post-hooks RESTORED (append strategy + verified SQL, template structure adapted)
  v4 (2026-05-12): Consolidate staging+intermediate+mart into single model, remove curr_ind and post-hooks
  v5 (2026-05-14): Change materialization from table to incremental with append strategy
"""

import argparse
import json
import sys
from pathlib import Path
from typing import Any, Dict


# ---------------------------------------------------------------------------
# Path constants
# ---------------------------------------------------------------------------
PROJECT_ROOT = Path(__file__).resolve().parent.parent.parent
DEFAULT_PARSED_JOB = PROJECT_ROOT / "agent-output" / "research" / "parsed_job.json"
DEFAULT_OUTPUT_DIR = PROJECT_ROOT / "scripts-output" / "output" / "dbt_project"


# ---------------------------------------------------------------------------
# SQL generation
# ---------------------------------------------------------------------------

def build_mart_sql(parsed: Dict[str, Any]) -> str:
    """Build the consolidated ach_actv.sql with staging + intermediate + mart in one model."""

    # 24 output columns (curr_ind removed)
    output_columns = [
        "loan_key",
        "actv_eff_dt",
        "sor_cd",
        "pymt_amt",
        "schd_type_cd",
        "schd_day",
        "pymt_type_cd",
        "cust_seg",
        "pymt_mth_type",
        "frst_nm",
        "last_nm",
        "mth_cntrt_amt",
        "addl_escrw_amt",
        "addl_prin_amt",
        "part_pymt_amt",
        "tot_drft_amt",
        "pymt_agnt_id",
        "schd_sts",
        "disabled_dt",
        "last_mod_dt",
        "closd_by",
        "aud_cre_by_nm",
        "aud_cre_dttm",
        "etl_batch_id",
    ]

    final_select_cols = ",\n    ".join(output_columns)

    return """-- ach_actv.sql
-- Consolidated mart model: equivalent to full Talend pipeline
--   tFileInputDelimited_1 → tMap_1 → tDBOutput_1
--   from LOAD_ACH_ACTV_FILE_SWH_0.1.item
--
-- Materialization: incremental (append strategy matching tDBOutput_1 INSERT behavior)
--
-- v4 Enhancement (2026-05-12): Consolidates 3-layer structure into single model
--   - Absorbs stg_ach_activity.sql (source type casts, TRY_TO_TIMESTAMP_NTZ)
--   - Absorbs int_ach_activity_enriched.sql (INNER JOIN on loan_nbr, tMap expressions)
--   - Removes curr_ind column and post-hooks (no SCD Type 1 tracking)
--
-- v5 Enhancement (2026-05-14): Change to incremental materialization with append strategy
--
-- tDBOutput_1 config:
--   Table: ACH_ACTV
--   TABLE_ACTION: NONE
--   DATA_ACTION: INSERT (maps to incremental append)

{{
  config(
    materialized='incremental',
    incremental_strategy='append'
  )
}}

with
  -- Source CTE: type casts from raw CSV (absorbs stg_ach_activity.sql)
  -- Source: tFileInputDelimited_1 — DailyACHActivity CSV with no header row
  cte_source as (
    select
        CAST(loan_nbr AS BIGINT)                                         as loan_nbr,
        CAST(pymt_amt AS NUMBER(19,4))                                   as pymt_amt,
        TRY_TO_TIMESTAMP_NTZ(actv_eff_dt, 'MM/DD/YYYY HH24:MI:SS')      as actv_eff_dt,
        CAST(schd_type_cd AS VARCHAR)                                    as schd_type_cd,
        CAST(schd_day AS INTEGER)                                        as schd_day,
        CAST(pymt_type_cd AS VARCHAR)                                    as pymt_type_cd,
        CAST(cust_seg AS VARCHAR)                                        as cust_seg,
        CAST(pymt_mth_type AS VARCHAR)                                   as pymt_mth_type,
        CAST(frst_nm AS VARCHAR)                                         as frst_nm,
        CAST(last_nm AS VARCHAR)                                         as last_nm,
        CAST(mth_cntrt_amt AS NUMBER(19,4))                              as mth_cntrt_amt,
        CAST(addl_escrw_amt AS NUMBER(19,4))                             as addl_escrw_amt,
        CAST(addl_prin_amt AS NUMBER(19,4))                              as addl_prin_amt,
        CAST(part_pymt_amt AS NUMBER(19,4))                              as part_pymt_amt,
        CAST(tot_drft_amt AS NUMBER(19,4))                               as tot_drft_amt,
        CAST(pymt_agnt_id AS VARCHAR)                                    as pymt_agnt_id,
        CAST(schd_sts AS VARCHAR)                                        as schd_sts,
        TRY_TO_TIMESTAMP_NTZ(disabled_dt, 'MM/DD/YYYY HH24:MI:SS')      as disabled_dt,
        TRY_TO_TIMESTAMP_NTZ(last_mod_dt, 'MM/DD/YYYY HH24:MI:SS')      as last_mod_dt,
        CAST(closd_by AS VARCHAR)                                        as closd_by
    from {{ source('raw_stage', 'ach_activity_csv') }}
  ),

  -- Lookup CTE: replicates tDBInput_2
  -- Original SQL: select LOAN_KEY, CAST(LOAN_NBR as bigint) from SRVC_WH.DBO.LOAN_NBR_CROSS_REF (nolock)
  cte_loan_xref as (
    select
        CAST(loan_key AS BIGINT) as loan_key,
        CAST(loan_nbr AS BIGINT) as loan_nbr
    from {{ source('srvc_wh', 'loan_nbr_cross_ref') }}
  ),

  -- Enrichment CTE: INNER JOIN + tMap_1 expressions (absorbs int_ach_activity_enriched.sql)
  -- Join: row1.LOAN_NBR = row6.LOAN_NBR (innerJoin=true, UNIQUE_MATCH)
  cte_enriched as (
    select
        xref.loan_key                                      as loan_key,
        src.actv_eff_dt                                    as actv_eff_dt,
        'PAYMENTUS'                                        as sor_cd,
        src.pymt_amt                                       as pymt_amt,
        src.schd_type_cd                                   as schd_type_cd,
        src.schd_day                                       as schd_day,
        src.pymt_type_cd                                   as pymt_type_cd,
        src.cust_seg                                       as cust_seg,
        src.pymt_mth_type                                  as pymt_mth_type,
        src.frst_nm                                        as frst_nm,
        src.last_nm                                        as last_nm,
        src.mth_cntrt_amt                                  as mth_cntrt_amt,
        src.addl_escrw_amt                                 as addl_escrw_amt,
        src.addl_prin_amt                                  as addl_prin_amt,
        src.part_pymt_amt                                  as part_pymt_amt,
        src.tot_drft_amt                                   as tot_drft_amt,
        src.pymt_agnt_id                                   as pymt_agnt_id,
        src.schd_sts                                       as schd_sts,
        src.disabled_dt                                    as disabled_dt,
        src.last_mod_dt                                    as last_mod_dt,
        src.closd_by                                       as closd_by,
        'TALEND-ETL-INSERT'                                as aud_cre_by_nm,
        CURRENT_TIMESTAMP                                  as aud_cre_dttm,
        {{ var('etl_batch_id', 0) }}                       as etl_batch_id
    from cte_source as src
    inner join cte_loan_xref as xref
        on src.loan_nbr = xref.loan_nbr
  )

-- Final SELECT: 24 explicit columns (curr_ind removed)
select
    """ + final_select_cols + """
from cte_enriched
"""


# ---------------------------------------------------------------------------
# YAML generation
# ---------------------------------------------------------------------------

def build_mart_yaml() -> str:
    """Build the ach_actv.yml schema test file (no curr_ind)."""

    return """version: 2

models:
  - name: ach_actv
    description: >
      Consolidated ACH activity mart — Snowflake equivalent of SQL Server ACH_ACTV target table.
      Single model replicating full Talend pipeline: tFileInputDelimited_1 (CSV source with type casts),
      tDBInput_2 (loan_nbr lookup), tMap_1 (transformations), and tDBOutput_1 (INSERT INTO ACH_ACTV).
      From LOAD_ACH_ACTV_FILE_SWH_0.1.item. Materialization: incremental (append strategy).
    columns:
      - name: loan_key
        description: "Internal loan key from LOAN_NBR_CROSS_REF — primary identifier"
        tests:
          - not_null
      - name: actv_eff_dt
        description: "Activity effective date"
        tests:
          - not_null
      - name: sor_cd
        description: "Source of record code — always PAYMENTUS"
        tests:
          - not_null
          - accepted_values:
              values: ['PAYMENTUS']
      - name: pymt_amt
        description: "Payment amount"
        tests:
          - not_null
      - name: schd_type_cd
        description: "Schedule type code"
      - name: schd_day
        description: "Schedule day"
      - name: pymt_type_cd
        description: "Payment type code"
      - name: cust_seg
        description: "Customer segment"
      - name: pymt_mth_type
        description: "Payment method type"
      - name: frst_nm
        description: "First name"
      - name: last_nm
        description: "Last name"
      - name: mth_cntrt_amt
        description: "Monthly contract amount"
      - name: addl_escrw_amt
        description: "Additional escrow amount"
      - name: addl_prin_amt
        description: "Additional principal amount"
      - name: part_pymt_amt
        description: "Partial payment amount"
      - name: tot_drft_amt
        description: "Total draft amount"
      - name: pymt_agnt_id
        description: "Payment agent ID"
      - name: schd_sts
        description: "Schedule status"
      - name: disabled_dt
        description: "Disabled date"
      - name: last_mod_dt
        description: "Last modified date"
      - name: closd_by
        description: "Closed by"
      - name: aud_cre_by_nm
        description: "Audit created by — always TALEND-ETL-INSERT"
        tests:
          - not_null
          - accepted_values:
              values: ['TALEND-ETL-INSERT']
      - name: aud_cre_dttm
        description: "Audit created datetime"
      - name: etl_batch_id
        description: "ETL batch tracking ID"
        tests:
          - not_null
"""


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main() -> None:
    """Generate consolidated mart model SQL and YAML files."""
    parser = argparse.ArgumentParser(
        description="Generate consolidated dbt mart model for ACH_ACTV (v5)"
    )
    parser.add_argument(
        "--parsed-job", type=Path, default=DEFAULT_PARSED_JOB,
        help=f"Path to parsed_job.json (default: {DEFAULT_PARSED_JOB})"
    )
    parser.add_argument(
        "--output-dir", type=Path, default=DEFAULT_OUTPUT_DIR,
        help=f"dbt project root directory (default: {DEFAULT_OUTPUT_DIR})"
    )
    args = parser.parse_args()

    # Load parsed job data (for validation)
    if not args.parsed_job.exists():
        print(f"ERROR: parsed_job.json not found at {args.parsed_job}", file=sys.stderr)
        print("Run parse_talend_job.py first.", file=sys.stderr)
        sys.exit(1)

    with open(args.parsed_job, "r", encoding="utf-8") as f:
        parsed = json.load(f)

    # Output directory
    models_dir = args.output_dir / "models"
    models_dir.mkdir(parents=True, exist_ok=True)

    # Generate SQL
    sql_content = build_mart_sql(parsed)
    sql_path = models_dir / "ach_actv.sql"
    sql_path.write_text(sql_content, encoding="utf-8")
    print(f"Written: {sql_path}")

    # Generate YAML
    yaml_content = build_mart_yaml()
    yaml_path = models_dir / "ach_actv.yml"
    yaml_path.write_text(yaml_content, encoding="utf-8")
    print(f"Written: {yaml_path}")

    print(f"  Target table: ACH_ACTV")
    print(f"  Columns: 24 (consolidated, curr_ind removed)")
    print(f"  Materialization: incremental (append strategy)")
    print(f"  Structure: single model (staging + intermediate + mart consolidated)")


if __name__ == "__main__":
    main()
