"""
generate_dbt_project_config.py

Generates dbt project configuration files:
  - dbt_project.yml      (project structure, materializations, vars)
  - profiles.yml         (Snowflake connection profiles: dev + prod)
  - packages.yml         (dbt-utils dependency)
  - models/sources.yml   (source declarations for CSV stage + SRVC_WH lookup table)

Reads: agent-output/research/parsed_job.json
Writes: scripts-output/output/dbt_project/

Usage:
    python generate_dbt_project_config.py
    python generate_dbt_project_config.py --parsed-job path/to/parsed_job.json --output-dir path/to/dbt_project
"""

import argparse
import json
import sys
from pathlib import Path
from typing import Any, Dict, List


# ---------------------------------------------------------------------------
# Path constants
# ---------------------------------------------------------------------------
PROJECT_ROOT = Path(__file__).resolve().parent.parent.parent
DEFAULT_PARSED_JOB = PROJECT_ROOT / "agent-output" / "research" / "parsed_job.json"
DEFAULT_OUTPUT_DIR = PROJECT_ROOT / "scripts-output" / "output" / "dbt_project"


# ---------------------------------------------------------------------------
# Config file generators
# ---------------------------------------------------------------------------

def build_dbt_project_yml(job_metadata: Dict[str, Any]) -> str:
    """Generate dbt_project.yml."""
    return """# dbt_project.yml
# Generated from LOAD_ACH_ACTV_FILE_SWH_0.1.item
# Project: ACH activity load migration (Talend → dbt + Snowflake)

name: 'ach_actv_load'
version: '1.0.0'
config-version: 2

# Profile used for Snowflake connection
profile: 'snowflake_srvc_wh'

# Directory configuration
model-paths: ["models"]
test-paths: ["tests"]
seed-paths: ["seeds"]
macro-paths: ["macros"]
snapshot-paths: ["snapshots"]

target-path: "target"
clean-targets:
  - "target"
  - "dbt_packages"

# Variables (equivalent to Talend context parameters)
vars:
  # ETL batch tracking ID — equivalent to context.parameter_ETL_BATCH_ID
  # Pass at runtime: dbt run --vars '{etl_batch_id: 12345}'
  etl_batch_id: 0

# Model materialization defaults by layer
# Configuration updated for v5 (incremental materialization with append strategy)
models:
  ach_actv_load:
    # Model-specific config (v5: incremental append, consolidated model)
    ach_actv:
      +materialized: incremental
      +incremental_strategy: append
      +schema: marts
"""


def build_profiles_yml(connection: Dict[str, Any]) -> str:
    """Generate profiles.yml with dev and prod Snowflake targets."""
    return f"""# profiles.yml
# Snowflake connection profiles for ACH activity dbt project
# Generated from LOAD_ACH_ACTV_FILE_SWH_0.1.item context parameters
#
# Original Talend connection: SRVC_WH (SQL Server, JTDS driver)
# Snowflake migration: configure via environment variables
#
# Required env vars:
#   SNOWFLAKE_ACCOUNT    - Snowflake account identifier (e.g., myorg-myaccount)
#   SNOWFLAKE_USER       - Snowflake username
#   SNOWFLAKE_PASSWORD   - Snowflake password
#
# Optional env vars (with defaults):
#   SNOWFLAKE_ROLE       (default: TRANSFORMER)
#   SNOWFLAKE_DATABASE   (default: SRVC_WH)
#   SNOWFLAKE_WAREHOUSE  (default: COMPUTE_WH)
#   SNOWFLAKE_SCHEMA     (default: DBT_DEV for dev, DBO for prod)

snowflake_srvc_wh:
  target: dev
  outputs:
    dev:
      type: snowflake
      account: "{{{{ env_var('SNOWFLAKE_ACCOUNT') }}}}"
      user: "{{{{ env_var('SNOWFLAKE_USER') }}}}"
      password: "{{{{ env_var('SNOWFLAKE_PASSWORD') }}}}"
      role: "{{{{ env_var('SNOWFLAKE_ROLE', 'TRANSFORMER') }}}}"
      database: "{{{{ env_var('SNOWFLAKE_DATABASE', 'SRVC_WH') }}}}"
      warehouse: "{{{{ env_var('SNOWFLAKE_WAREHOUSE', 'COMPUTE_WH') }}}}"
      schema: "{{{{ env_var('SNOWFLAKE_SCHEMA', 'DBT_DEV') }}}}"
      threads: 4
      client_session_keep_alive: false
      query_tag: "ach_actv_load_dev"

    prod:
      type: snowflake
      account: "{{{{ env_var('SNOWFLAKE_ACCOUNT') }}}}"
      user: "{{{{ env_var('SNOWFLAKE_USER') }}}}"
      password: "{{{{ env_var('SNOWFLAKE_PASSWORD') }}}}"
      role: "{{{{ env_var('SNOWFLAKE_ROLE', 'TRANSFORMER') }}}}"
      database: "{{{{ env_var('SNOWFLAKE_DATABASE', 'SRVC_WH') }}}}"
      warehouse: "{{{{ env_var('SNOWFLAKE_WAREHOUSE', 'COMPUTE_WH') }}}}"
      schema: "{{{{ env_var('SNOWFLAKE_SCHEMA', 'DBO') }}}}"
      threads: 8
      client_session_keep_alive: false
      query_tag: "ach_actv_load_prod"
"""


def build_packages_yml() -> str:
    """Generate packages.yml."""
    return """# packages.yml
# dbt package dependencies for ACH activity project
# Run 'dbt deps' to install

packages:
  - package: dbt-labs/dbt_utils
    version: [">=1.0.0", "<2.0.0"]
"""


def build_sources_yml(source_schema: Dict[str, Any], lookup_data: Dict[str, Any]) -> str:
    """Generate sources.yml with ach_activity_csv and loan_nbr_cross_ref sources (table-level only)."""
    return f"""# models/sources.yml
# Source declarations for ACH activity dbt project
# Generated from LOAD_ACH_ACTV_FILE_SWH_0.1.item
#
# Sources:
#   raw_stage.ach_activity_csv      - DailyACHActivity CSV (from tFileInputDelimited_1)
#   srvc_wh.loan_nbr_cross_ref      - Loan number cross-reference (from tDBInput_2)

version: 2

sources:
  - name: raw_stage
    description: >
      ACH activity CSV data loaded into Snowflake via external stage or seed.
      Equivalent to the DailyACHActivity CSV file read by tFileInputDelimited_1
      in LOAD_ACH_ACTV_FILE_SWH_0.1.item.
      Original path: {{{{context.connection_swhfilepath_INBOUND_DIR}}}}/paymentus/DailyACHActivityYYYYMMDD.csv
      CSV format: comma-delimited, no header row (HEADER=0), 20 columns.
    database: "{{{{ env_var('SNOWFLAKE_DATABASE', 'SRVC_WH') }}}}"
    schema: "{{{{ env_var('SNOWFLAKE_SCHEMA', 'DBO') }}}}"
    tables:
      - name: ach_activity_csv
        description: >
          DailyACHActivity CSV file — 20 columns from tFileInputDelimited_1 schema.
          Note: CSV has no header row. Column names are defined by the Talend schema.
          For Snowflake loading: define column names in the external table or stage definition.

  - name: srvc_wh
    description: >
      SRVC_WH source tables — SQL Server equivalents in Snowflake.
      Original database: SRVC_WH (SQL Server CRSDWSQLPRD/CRSDWSQLDEV02).
    database: "{{{{ env_var('SNOWFLAKE_DATABASE', 'SRVC_WH') }}}}"
    schema: "{{{{ env_var('SNOWFLAKE_SCHEMA', 'DBO') }}}}"
    tables:
      - name: loan_nbr_cross_ref
        description: >
          Loan number to loan key cross-reference table.
          Source for tDBInput_2 in LOAD_ACH_ACTV_FILE_SWH_0.1.item.
          Original SQL: SELECT LOAN_KEY, CAST(LOAN_NBR as bigint) FROM SRVC_WH.DBO.LOAN_NBR_CROSS_REF (nolock)
"""


def _source_col_desc(name: str) -> str:
    """Brief description for source column."""
    desc_map = {
        "loan_nbr": "Loan number from Paymentus ACH activity file",
        "pymt_amt": "Payment amount",
        "actv_eff_dt": "Activity effective date (MM/dd/yyyy HH:mm:ss format in CSV)",
        "schd_type_cd": "Schedule type code",
        "schd_day": "Schedule day",
        "pymt_type_cd": "Payment type code",
        "cust_seg": "Customer segment",
        "pymt_mth_type": "Payment method type",
        "frst_nm": "First name",
        "last_nm": "Last name",
        "mth_cntrt_amt": "Monthly contract amount",
        "addl_escrw_amt": "Additional escrow amount",
        "addl_prin_amt": "Additional principal amount",
        "part_pymt_amt": "Partial payment amount",
        "tot_drft_amt": "Total draft amount",
        "pymt_agnt_id": "Payment agent ID",
        "schd_sts": "Schedule status",
        "disabled_dt": "Disabled date",
        "last_mod_dt": "Last modified date",
        "closd_by": "Closed by",
    }
    return desc_map.get(name, f"Column {name}")


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main() -> None:
    """Generate dbt project configuration files."""
    parser = argparse.ArgumentParser(
        description="Generate dbt project config files for ACH activity"
    )
    parser.add_argument(
        "--parsed-job", type=Path, default=DEFAULT_PARSED_JOB,
        help=f"Path to parsed_job.json (default: {DEFAULT_PARSED_JOB})"
    )
    parser.add_argument(
        "--output-dir", type=Path, default=DEFAULT_OUTPUT_DIR,
        help=f"dbt project root directory (default: {DEFAULT_OUTPUT_DIR})"
    )
    args = parser.parse_args()

    # Load parsed job data
    if not args.parsed_job.exists():
        print(f"ERROR: parsed_job.json not found at {args.parsed_job}", file=sys.stderr)
        print("Run parse_talend_job.py first.", file=sys.stderr)
        sys.exit(1)

    with open(args.parsed_job, "r", encoding="utf-8") as f:
        parsed = json.load(f)

    job_metadata = parsed.get("job_metadata", {})
    source_schema = parsed.get("source_schema", {})
    lookup_data = parsed.get("lookup_query", {})
    connection = parsed.get("connection", {})

    # Ensure output directory exists
    args.output_dir.mkdir(parents=True, exist_ok=True)
    models_dir = args.output_dir / "models"
    models_dir.mkdir(parents=True, exist_ok=True)

    # Generate dbt_project.yml
    dbt_project_content = build_dbt_project_yml(job_metadata)
    dbt_project_path = args.output_dir / "dbt_project.yml"
    dbt_project_path.write_text(dbt_project_content, encoding="utf-8")
    print(f"Written: {dbt_project_path}")

    # Generate profiles.yml
    profiles_content = build_profiles_yml(connection)
    profiles_path = args.output_dir / "profiles.yml"
    profiles_path.write_text(profiles_content, encoding="utf-8")
    print(f"Written: {profiles_path}")

    # Generate packages.yml
    packages_content = build_packages_yml()
    packages_path = args.output_dir / "packages.yml"
    packages_path.write_text(packages_content, encoding="utf-8")
    print(f"Written: {packages_path}")

    # Generate models/sources.yml
    sources_content = build_sources_yml(source_schema, lookup_data)
    sources_path = models_dir / "sources.yml"
    sources_path.write_text(sources_content, encoding="utf-8")
    print(f"Written: {sources_path}")

    print(f"\nConfig files generated:")
    print(f"  dbt_project.yml — project: ach_actv_load, profile: snowflake_srvc_wh")
    print(f"  profiles.yml — dev + prod Snowflake targets")
    print(f"  packages.yml — dbt-utils >=1.0.0")
    print(f"  models/sources.yml — 2 sources ({source_schema.get('column_count', 0)} CSV columns + 2 lookup columns)")


if __name__ == "__main__":
    main()
