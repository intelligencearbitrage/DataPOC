"""
parse_talend_job.py

Parses the Talend .item XML file (LOAD_ACH_ACTV_FILE_SWH_0.1.item) and emits a
structured parsed_job.json containing all schemas, tMap expressions, SQL queries,
column mappings, and context parameters needed by downstream generator scripts.

Usage:
    python parse_talend_job.py
    python parse_talend_job.py --input path/to/file.item --output path/to/parsed_job.json

Input:  user-config/inputs/LOAD_ACH_ACTV_FILE_SWH_0.1.item
Output: agent-output/research/parsed_job.json
"""

import argparse
import json
import sys
import xml.etree.ElementTree as ET
from pathlib import Path
from typing import Any, Dict, List, Optional


# ---------------------------------------------------------------------------
# Path constants (relative to project root)
# ---------------------------------------------------------------------------
PROJECT_ROOT = Path(__file__).resolve().parent.parent.parent
DEFAULT_INPUT = PROJECT_ROOT / "user-config" / "inputs" / "LOAD_ACH_ACTV_FILE_SWH_0.1.item"
DEFAULT_OUTPUT = PROJECT_ROOT / "agent-output" / "research" / "parsed_job.json"


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def get_element_param(node: ET.Element, name: str) -> Optional[str]:
    """Return the value attribute of the first elementParameter with the given name."""
    for ep in node.findall("elementParameter"):
        if ep.get("name") == name:
            return ep.get("value", "")
    return None


def find_node_by_unique_name(root: ET.Element, unique_name: str) -> Optional[ET.Element]:
    """Find a <node> element by its UNIQUE_NAME elementParameter value."""
    for node in root.findall(".//node"):
        if get_element_param(node, "UNIQUE_NAME") == unique_name:
            return node
    return None


def parse_metadata_columns(node: ET.Element, connector: str = "FLOW") -> List[Dict[str, Any]]:
    """Extract column definitions from a <metadata connector='FLOW'> element inside a node."""
    columns = []
    for meta in node.findall("metadata"):
        if meta.get("connector") == connector:
            for col in meta.findall("column"):
                columns.append({
                    "name": col.get("name"),
                    "talend_type": col.get("type"),
                    "length": col.get("length"),
                    "precision": col.get("precision"),
                    "pattern": col.get("pattern", "").strip('"') if col.get("pattern") else None,
                    "nullable": col.get("nullable") == "true",
                    "key": col.get("key") == "true",
                    "source_type": col.get("sourceType", ""),
                })
    return columns


def talend_type_to_snowflake(talend_type: str, precision: str, length: str, pattern: str) -> str:
    """Convert a Talend id_* type to a Snowflake DDL type string."""
    type_map = {
        "id_Long": "BIGINT",
        "id_Integer": "INTEGER",
        "id_String": "VARCHAR",
        "id_Double": f"NUMBER({length},{precision})" if length and length != "-1" else "NUMBER(19,4)",
        "id_Date": "TIMESTAMP_NTZ" if (pattern and ("HH" in pattern or "mm" in pattern)) else "DATE",
        "id_Boolean": "BOOLEAN",
    }
    return type_map.get(talend_type, "VARCHAR")


def expression_to_snowflake_sql(expression: str, col_name: str) -> str:
    """Translate a tMap expression to Snowflake SQL."""
    expr = expression.strip()

    # Literal strings
    if expr.startswith('"') and expr.endswith('"'):
        inner = expr[1:-1]
        return f"'{inner}'"

    # Row references
    replacements = [
        ("row6.LOAN_KEY", "xref.loan_key"),
        ("row1.", "src."),
        ("row6.", "xref."),
    ]
    for old, new in replacements:
        if old in expr:
            expr = expr.replace(old, new).lower()
            break

    # Function translations
    if "TalendDate.getCurrentDate()" in expr:
        return "CURRENT_TIMESTAMP"

    if "context.parameter_ETL_BATCH_ID" in expr:
        return "{{ var('etl_batch_id', 0) }}"

    return expr.lower()


# ---------------------------------------------------------------------------
# Parsing functions
# ---------------------------------------------------------------------------

def parse_job_metadata(root: ET.Element, source_path: Path) -> Dict[str, Any]:
    """Extract top-level job metadata."""
    return {
        "job_name": source_path.stem.replace(".", "_").replace("-", "_"),
        "source_file": str(source_path.name),
        "default_context": root.get("defaultContext", "QA"),
        "job_type": root.get("jobType", "Standard"),
    }


def parse_contexts(root: ET.Element) -> Dict[str, Dict[str, str]]:
    """Extract all context groups and their parameter values."""
    contexts: Dict[str, Dict[str, str]] = {}
    for ctx in root.findall("context"):
        ctx_name = ctx.get("name", "Unknown")
        params = {}
        for cp in ctx.findall("contextParameter"):
            raw_value = cp.get("value", "")
            # Strip surrounding quotes if present
            if raw_value.startswith('"') and raw_value.endswith('"'):
                raw_value = raw_value[1:-1]
            params[cp.get("name")] = raw_value
        contexts[ctx_name] = params
    return contexts


def parse_source_schema(root: ET.Element) -> Dict[str, Any]:
    """Extract tFileInputDelimited_1 schema (20 CSV columns)."""
    node = find_node_by_unique_name(root, "tFileInputDelimited_1")
    if node is None:
        print("WARNING: tFileInputDelimited_1 not found", file=sys.stderr)
        return {}

    columns = parse_metadata_columns(node, connector="FLOW")
    snowflake_columns = []
    for col in columns:
        sf_type = talend_type_to_snowflake(
            col["talend_type"],
            col.get("precision", "0"),
            col.get("length", "-1"),
            col.get("pattern", "")
        )
        snowflake_columns.append({
            "name": col["name"].lower(),
            "talend_name": col["name"],
            "talend_type": col["talend_type"],
            "snowflake_type": sf_type,
            "pattern": col.get("pattern"),
            "nullable": col["nullable"],
        })

    file_path_ep = None
    for ep in node.findall("elementParameter"):
        if ep.get("name") == "FILENAME":
            file_path_ep = ep.get("value", "")

    return {
        "component": "tFileInputDelimited_1",
        "label": get_element_param(node, "LABEL"),
        "file_path_expression": file_path_ep,
        "delimiter": ",",
        "csv_mode": True,
        "header_rows": 0,
        "encoding": "ISO-8859-15",
        "column_count": len(columns),
        "columns": snowflake_columns,
    }


def parse_lookup_query(root: ET.Element) -> Dict[str, Any]:
    """Extract tDBInput_2 lookup SQL and output schema."""
    node = find_node_by_unique_name(root, "tDBInput_2")
    if node is None:
        print("WARNING: tDBInput_2 not found", file=sys.stderr)
        return {}

    query = get_element_param(node, "QUERY") or ""
    # Strip outer quotes
    if query.startswith('"') and query.endswith('"'):
        query = query[1:-1]

    columns = parse_metadata_columns(node, connector="FLOW")
    output_cols = [
        {
            "name": col["name"].lower(),
            "talend_name": col["name"],
            "talend_type": col["talend_type"],
            "snowflake_type": "BIGINT",
        }
        for col in columns
    ]

    # Snowflake-adapted SQL
    sf_sql = (
        "SELECT\n"
        "    CAST(loan_key AS BIGINT) AS loan_key,\n"
        "    CAST(loan_nbr AS BIGINT) AS loan_nbr\n"
        "FROM {{ source('srvc_wh', 'loan_nbr_cross_ref') }}"
    )

    return {
        "component": "tDBInput_2",
        "label": get_element_param(node, "LABEL"),
        "original_sql": query,
        "snowflake_sql": sf_sql,
        "output_columns": output_cols,
        "join_alias": "xref",
    }


def parse_tmap_expressions(root: ET.Element) -> Dict[str, Any]:
    """Extract tMap_1 output expressions for TGT_TBL and join configuration."""
    node = find_node_by_unique_name(root, "tMap_1")
    if node is None:
        print("WARNING: tMap_1 not found", file=sys.stderr)
        return {}

    node_data = node.find("nodeData")
    if node_data is None:
        print("WARNING: tMap_1/nodeData not found", file=sys.stderr)
        return {}

    # Output expressions for TGT_TBL
    tgt_tbl_expressions = []
    for output_table in node_data.findall("outputTables"):
        if output_table.get("name") == "TGT_TBL":
            for entry in output_table.findall("mapperTableEntries"):
                col_name = entry.get("name")
                expression = entry.get("expression", "")
                col_type = entry.get("type", "")
                sf_expr = expression_to_snowflake_sql(expression, col_name)
                tgt_tbl_expressions.append({
                    "name": col_name.lower(),
                    "talend_name": col_name,
                    "talend_expression": expression.strip(),
                    "talend_type": col_type,
                    "snowflake_expression": sf_expr,
                })

    # Join configuration
    join_config = {}
    for input_table in node_data.findall("inputTables"):
        tbl_name = input_table.get("name")
        join_config[tbl_name] = {
            "matching_mode": input_table.get("matchingMode"),
            "lookup_mode": input_table.get("lookupMode"),
            "inner_join": input_table.get("innerJoin") == "true",
            "join_keys": [],
        }
        for entry in input_table.findall("mapperTableEntries"):
            if entry.get("operator") == "=":
                join_config[tbl_name]["join_keys"].append({
                    "column": entry.get("name"),
                    "expression": entry.get("expression", "").strip(),
                    "operator": "=",
                })

    return {
        "component": "tMap_1",
        "label": get_element_param(node, "LABEL"),
        "output_table": "TGT_TBL",
        "column_count": len(tgt_tbl_expressions),
        "columns": tgt_tbl_expressions,
        "join_config": join_config,
        "input_row_alias": "src",
        "lookup_row_alias": "xref",
    }


def parse_target_table(root: ET.Element) -> Dict[str, Any]:
    """Extract tDBOutput_1 configuration."""
    node = find_node_by_unique_name(root, "tDBOutput_1")
    if node is None:
        print("WARNING: tDBOutput_1 not found", file=sys.stderr)
        return {}

    columns = parse_metadata_columns(node, connector="FLOW")
    return {
        "component": "tDBOutput_1",
        "label": get_element_param(node, "LABEL"),
        "table": get_element_param(node, "TABLE").strip('"') if get_element_param(node, "TABLE") else "ACH_ACTV",
        "table_action": get_element_param(node, "TABLE_ACTION"),
        "data_action": get_element_param(node, "DATA_ACTION"),
        "batch_size": get_element_param(node, "BATCH_SIZE"),
        "column_count": len(columns),
        "dbt_model_name": "ach_actv",
        "dbt_materialization": "incremental",
        "dbt_strategy": "append",
    }


def parse_post_insert_sql(root: ET.Element) -> Dict[str, Any]:
    """Extract tDBRow_3 (UPD_CURR_IND) SQL."""
    node = find_node_by_unique_name(root, "tDBRow_3")
    if node is None:
        print("WARNING: tDBRow_3 not found", file=sys.stderr)
        return {}

    raw_query = get_element_param(node, "QUERY") or ""
    if raw_query.startswith('"') and raw_query.endswith('"'):
        raw_query = raw_query[1:-1]

    # Snowflake-adapted UPDATE statements (simplified from T-SQL with temp tables)
    snowflake_updates = [
        (
            "UPDATE {{ this }} SET curr_ind = 'N' "
            "WHERE curr_ind = 'Y' "
            "AND etl_batch_id < {{ var('etl_batch_id', 0) }} "
            "AND loan_key IN ("
            "SELECT DISTINCT loan_key FROM {{ this }} "
            "WHERE etl_batch_id = {{ var('etl_batch_id', 0) }}"
            ")"
        ),
        (
            "WITH ranked AS ("
            "SELECT loan_key, "
            "ROW_NUMBER() OVER("
            "PARTITION BY loan_key "
            "ORDER BY last_mod_dt DESC NULLS LAST, actv_eff_dt DESC NULLS LAST"
            ") AS rn "
            "FROM {{ this }} "
            "WHERE etl_batch_id = {{ var('etl_batch_id', 0) }}"
            ") "
            "UPDATE {{ this }} t SET curr_ind = 'Y' "
            "FROM ranked r "
            "WHERE t.loan_key = r.loan_key "
            "AND t.etl_batch_id = {{ var('etl_batch_id', 0) }} "
            "AND r.rn = 1"
        ),
    ]

    return {
        "component": "tDBRow_3",
        "label": get_element_param(node, "LABEL"),
        "original_sql_fragment": raw_query[:500] + "..." if len(raw_query) > 500 else raw_query,
        "snowflake_post_hooks": snowflake_updates,
        "purpose": "SCD Type 1 current indicator update — sets curr_ind=Y for most recent row per loan_key",
    }


def parse_connection_params(root: ET.Element) -> Dict[str, Any]:
    """Extract tDBConnection_1 configuration."""
    node = find_node_by_unique_name(root, "tDBConnection_1")
    if node is None:
        return {}

    return {
        "component": "tDBConnection_1",
        "label": get_element_param(node, "LABEL"),
        "driver": get_element_param(node, "DRIVER"),
        "type": "MSSQL",
        "server_context": "connection_srvcwhmssql_Server",
        "port_context": "connection_srvcwhmssql_Port",
        "database_context": "connection_srvcwhmssql_Database",
        "schema": "DBO",
        "login_context": "connection_srvcwhmssql_Login",
        "database_name": "SRVC_WH",
        "port": 1433,
        "qa_server": "CRSDWSQLDEV02",
        "prod_server": "CRSDWSQLPRD",
    }


def parse_out_of_scope_components(root: ET.Element) -> List[Dict[str, str]]:
    """Collect out-of-scope component information for the conversion report."""
    out_of_scope_names = {
        "tFTPGet_1": "tFTPGet",
        "tFTPConnection_1": "tFTPConnection",
        "tFTPClose_1": "tFTPClose",
        "tSendMail_1": "tSendMail",
        "tSendMail_2": "tSendMail",
        "tSendMail_3": "tSendMail",
    }
    reasons = {
        "tFTPGet": "SFTP file ingestion — not applicable in dbt/Snowflake architecture",
        "tFTPConnection": "SFTP connection management — not applicable",
        "tFTPClose": "SFTP connection close — not applicable",
        "tSendMail": "Email alerting — out of scope per project requirements",
    }

    result = []
    for unique_name, component_name in out_of_scope_names.items():
        node = find_node_by_unique_name(root, unique_name)
        label = get_element_param(node, "LABEL") if node is not None else unique_name
        result.append({
            "unique_name": unique_name,
            "component": component_name,
            "label": label,
            "reason": reasons.get(component_name, "Out of scope"),
        })
    return result


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def parse_item_file(input_path: Path) -> Dict[str, Any]:
    """Parse the .item XML file and return the structured data dictionary."""
    if not input_path.exists():
        print(f"ERROR: Input file not found: {input_path}", file=sys.stderr)
        sys.exit(1)

    try:
        tree = ET.parse(str(input_path))
        root = tree.getroot()
    except ET.ParseError as e:
        print(f"ERROR: Failed to parse XML: {e}", file=sys.stderr)
        sys.exit(1)

    print(f"Parsing: {input_path.name}")

    parsed = {
        "job_metadata": parse_job_metadata(root, input_path),
        "contexts": parse_contexts(root),
        "source_schema": parse_source_schema(root),
        "lookup_query": parse_lookup_query(root),
        "tmap_expressions": parse_tmap_expressions(root),
        "target_table": parse_target_table(root),
        "post_insert_sql": parse_post_insert_sql(root),
        "connection": parse_connection_params(root),
        "out_of_scope": parse_out_of_scope_components(root),
    }

    # Validation checks
    source_cols = parsed["source_schema"].get("column_count", 0)
    tmap_cols = parsed["tmap_expressions"].get("column_count", 0)
    target_cols = parsed["target_table"].get("column_count", 0)

    print(f"  Source schema columns: {source_cols} (expected 20)")
    print(f"  tMap TGT_TBL columns: {tmap_cols} (expected 25)")
    print(f"  Target table columns: {target_cols} (expected 25)")

    if source_cols != 20:
        print(f"  WARNING: Expected 20 source columns, got {source_cols}", file=sys.stderr)
    if tmap_cols != 25:
        print(f"  WARNING: Expected 25 tMap output columns, got {tmap_cols}", file=sys.stderr)

    return parsed


def main() -> None:
    """Entry point."""
    parser = argparse.ArgumentParser(
        description="Parse Talend .item XML file and emit structured JSON"
    )
    parser.add_argument(
        "--input", "-i",
        type=Path,
        default=DEFAULT_INPUT,
        help=f"Path to .item file (default: {DEFAULT_INPUT})"
    )
    parser.add_argument(
        "--output", "-o",
        type=Path,
        default=DEFAULT_OUTPUT,
        help=f"Path for output JSON (default: {DEFAULT_OUTPUT})"
    )
    args = parser.parse_args()

    parsed = parse_item_file(args.input)

    # Ensure output directory exists
    args.output.parent.mkdir(parents=True, exist_ok=True)

    with open(args.output, "w", encoding="utf-8") as f:
        json.dump(parsed, f, indent=2, default=str)

    print(f"Written: {args.output}")
    print(f"  Contexts: {list(parsed['contexts'].keys())}")
    print(f"  Source columns: {parsed['source_schema'].get('column_count', 0)}")
    print(f"  tMap columns: {parsed['tmap_expressions'].get('column_count', 0)}")
    print(f"  Out-of-scope components: {len(parsed['out_of_scope'])}")


if __name__ == "__main__":
    main()
