#!/usr/bin/env python3
"""Idempotent orchestrator for the Palantir-to-Databricks PySpark conversion pipeline.

Project: palantir-to-databricks-pyspark
Purpose: Run all five pipeline scripts in order with per-file mtime-based skip logic
         so re-runs only convert files that have changed since the last conversion.

Pipeline order:
  Step 1: scan_inputs.py        -- MUST succeed (abort on failure)
  Step 2: extract_rid_map.py    -- MUST succeed (abort on failure)
  Step 3: convert_transforms.py -- tolerated failure (log WARNING, continue)
  Step 4: convert_sddi.py       -- tolerated failure (log WARNING, continue)
  Step 5: validate_outputs.py   -- always runs, exit code drives pipeline exit code

Idempotency mechanism:
  Before Steps 3 and 4, each output notebook's mtime is compared against its source
  file mtime AND the converter script mtime. If the notebook is newer than both, it is
  skipped. Use --force to bypass all skip checks.

Exit code semantics:
  0 -- all prerequisite steps succeeded AND validate_outputs.py passed
  1 -- any prerequisite step failed, OR validate_outputs.py reported failures

NOTE on runtime testing scope:
  Static analysis (syntax check, import validation, RID absence) is performed locally.
  Full runtime correctness (Spark execution, Delta reads/writes) requires a live
  Databricks cluster and cannot be validated offline.

Usage examples:
  python run_pipeline.py                          # run full pipeline (skip up-to-date files)
  python run_pipeline.py --force                  # re-convert everything unconditionally
  python run_pipeline.py --component validate_outputs   # run only the validator
  python run_pipeline.py --dry-run                # show what would run without executing
  python run_pipeline.py --force --dry-run        # dry-run in force mode
"""

import argparse
import logging
import sys
import subprocess
from pathlib import Path
from typing import Dict, List, Optional, Tuple
import yaml


# ---------------------------------------------------------------------------
# Logging setup
# ---------------------------------------------------------------------------
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    datefmt="%Y-%m-%dT%H:%M:%S",
)
log = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------
PIPELINE_STEPS: List[str] = [
    "scan_inputs",
    "extract_rid_map",
    "convert_transforms",
    "convert_sddi",
    "validate_outputs",
]

# Steps 3 and 4 are "converter scripts" — their mtime matters for CI-4 check
CONVERTER_SCRIPT_NAMES: List[str] = ["convert_transforms.py", "convert_sddi.py"]


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def resolve_paths(scripts_dir: Path) -> Dict[str, Path]:
    """Return a dict mapping step name to absolute script path."""
    return {
        "scan_inputs": scripts_dir / "scan_inputs.py",
        "extract_rid_map": scripts_dir / "extract_rid_map.py",
        "convert_transforms": scripts_dir / "convert_transforms.py",
        "convert_sddi": scripts_dir / "convert_sddi.py",
        "validate_outputs": scripts_dir / "validate_outputs.py",
    }


def verify_scripts(script_paths: Dict[str, Path]) -> bool:
    """Return True if all scripts exist; log CRITICAL for each missing file."""
    all_present = True
    for name, path in script_paths.items():
        if not path.exists():
            log.critical("Required script missing: %s (expected at %s)", name, path)
            all_present = False
    return all_present


def run_step(script: Path, args: List[str], dry_run: bool) -> int:
    """Run a pipeline script as a subprocess.

    Returns the subprocess return code, or 0 in dry-run mode.
    """
    cmd = [sys.executable, str(script)] + args
    if dry_run:
        log.info("DRY-RUN: would run: %s", " ".join(str(c) for c in cmd))
        return 0
    log.info("Running: %s", " ".join(str(c) for c in cmd))
    result = subprocess.run(cmd, check=False)
    return result.returncode


def startup_converter_mtime_check(
    scripts_dir: Path,
    notebooks_dir: Path,
    force: bool,
) -> None:
    """CI-4: warn if any existing output notebook is older than a converter script.

    Implements: converter_mtime = max(script.stat().st_mtime for script in converter_scripts)
    If any output notebook mtime < converter_mtime AND --force not set, print WARNING.
    """
    converter_scripts = [scripts_dir / name for name in CONVERTER_SCRIPT_NAMES]
    existing_converters = [s for s in converter_scripts if s.exists()]
    if not existing_converters:
        return  # converter scripts not yet present (unusual but not fatal)

    converter_mtime = max(s.stat().st_mtime for s in existing_converters)

    if not notebooks_dir.exists():
        return  # no notebooks generated yet; nothing to compare

    stale_notebooks = [
        nb for nb in notebooks_dir.glob("*.py")
        if nb.stat().st_mtime < converter_mtime
    ]

    if stale_notebooks and not force:
        log.warning(
            "WARNING: Converter scripts have been modified since some notebooks were "
            "generated. Consider running with --force to ensure all notebooks use the "
            "latest conversion rules."
        )
        log.info(
            "  %d notebook(s) older than latest converter script mtime.",
            len(stale_notebooks),
        )


def build_skip_set(
    manifest: dict,
    notebooks_dir: Path,
    converter_mtime: float,
    force: bool,
) -> Tuple[set, set]:
    """Return (skip_set, convert_set) based on mtime comparisons.

    A file is skipped when:
      - Its output notebook exists
      - The notebook is newer than the source file
      - The notebook is newer than the converter scripts (converter_mtime)
    """
    skip_set: set = set()
    convert_set: set = set()

    files = manifest.get("files", [])
    for entry in files:
        file_type = entry.get("type", "")
        if file_type not in ("transform_df", "sddi"):
            continue

        output_notebook_name = entry.get("output_notebook", "")
        source_path_str = entry.get("path", "")
        if not output_notebook_name or not source_path_str:
            convert_set.add(output_notebook_name or source_path_str)
            continue

        output_path = notebooks_dir / output_notebook_name
        source_path = Path(source_path_str)

        if force:
            convert_set.add(output_notebook_name)
            continue

        if (
            output_path.exists()
            and source_path.exists()
            and output_path.stat().st_mtime >= source_path.stat().st_mtime
            and output_path.stat().st_mtime >= converter_mtime
        ):
            skip_set.add(output_notebook_name)
        else:
            convert_set.add(output_notebook_name)

    return skip_set, convert_set


def load_validation_summary(validation_report_path: Path) -> Tuple[int, int]:
    """Load passed/failed counts from validation_report.yaml.

    Returns (passed, failed) counts; defaults to (0, 0) if file is absent or malformed.
    """
    if not validation_report_path.exists():
        return 0, 0
    try:
        report = yaml.safe_load(validation_report_path.read_text())
        summary = report.get("summary", {}) if report else {}
        passed = int(summary.get("passed", 0))
        failed = int(summary.get("failed", 0))
        return passed, failed
    except Exception as exc:  # noqa: BLE001
        log.warning("Could not parse validation_report.yaml: %s", exc)
        return 0, 0


# ---------------------------------------------------------------------------
# Single-component run
# ---------------------------------------------------------------------------

def run_single_component(
    component: str,
    script_paths: Dict[str, Path],
    project_root: Path,
    output_dir: Path,
    force: bool,
    dry_run: bool,
) -> int:
    """Run exactly one pipeline step and return its exit code."""
    if component not in script_paths:
        log.critical(
            "Unknown component '%s'. Valid choices: %s",
            component,
            ", ".join(script_paths.keys()),
        )
        return 1

    script = script_paths[component]
    manifest_path = project_root / "scripts-output" / "manifest.yaml"
    notebooks_dir = output_dir / "notebooks"
    tables_config_path = output_dir / "config" / "tables_config.yaml"

    args: List[str] = []
    if component == "scan_inputs":
        args = ["--project-root", str(project_root)]
    elif component == "extract_rid_map":
        args = ["--manifest", str(manifest_path), "--output-dir", str(output_dir / "config")]
        if force:
            args.append("--force")
    elif component in ("convert_transforms", "convert_sddi"):
        args = [
            "--manifest", str(manifest_path),
            "--tables-config", str(tables_config_path),
            "--output-dir", str(notebooks_dir),
        ]
        if force:
            args.append("--force")
    elif component == "validate_outputs":
        args = [
            "--notebooks-dir", str(notebooks_dir),
            "--tables-config", str(tables_config_path),
            "--output-dir", str(output_dir),
        ]

    return run_step(script, args, dry_run)


# ---------------------------------------------------------------------------
# Full pipeline run
# ---------------------------------------------------------------------------

def run_full_pipeline(
    script_paths: Dict[str, Path],
    project_root: Path,
    output_dir: Path,
    force: bool,
    dry_run: bool,
) -> int:
    """Execute all five pipeline steps in order. Return 0 on success, 1 on failure."""
    manifest_path = project_root / "scripts-output" / "manifest.yaml"
    notebooks_dir = output_dir / "notebooks"
    tables_config_path = output_dir / "config" / "tables_config.yaml"

    scripts_dir = Path(__file__).resolve().parent

    # --- CI-4 startup check ---------------------------------------------------
    startup_converter_mtime_check(scripts_dir, notebooks_dir, force)

    # --- Step 1: scan_inputs --------------------------------------------------
    log.info("Step 1/5: scan_inputs.py")
    args_scan = ["--project-root", str(project_root)]
    if dry_run:
        log.info("DRY-RUN: would run scan_inputs.py %s", " ".join(args_scan))
    else:
        try:
            cmd = [sys.executable, str(script_paths["scan_inputs"])] + args_scan
            log.info("Running: %s", " ".join(str(c) for c in cmd))
            subprocess.run(cmd, check=True)
            log.info("scan_inputs.py complete")
        except subprocess.CalledProcessError as exc:
            log.critical("scan_inputs.py failed (exit code %d) — aborting pipeline.", exc.returncode)
            return 1

    # --- Step 2: extract_rid_map ---------------------------------------------
    log.info("Step 2/5: extract_rid_map.py")
    args_extract = [
        "--manifest", str(manifest_path),
        "--output-dir", str(output_dir / "config"),
    ]
    if force:
        args_extract.append("--force")
    if dry_run:
        log.info("DRY-RUN: would run extract_rid_map.py %s", " ".join(args_extract))
    else:
        try:
            cmd = [sys.executable, str(script_paths["extract_rid_map"])] + args_extract
            log.info("Running: %s", " ".join(str(c) for c in cmd))
            subprocess.run(cmd, check=True)
            log.info("extract_rid_map.py complete")
        except subprocess.CalledProcessError as exc:
            log.critical(
                "extract_rid_map.py failed (exit code %d) — aborting pipeline.",
                exc.returncode,
            )
            return 1

    # --- Load manifest for per-file skip logic --------------------------------
    skip_set: set = set()
    convert_set: set = set()
    converter_mtime: float = 0.0

    # Determine max mtime of converter scripts for skip comparison
    converter_scripts = [scripts_dir / name for name in CONVERTER_SCRIPT_NAMES]
    existing_converters = [s for s in converter_scripts if s.exists()]
    if existing_converters:
        converter_mtime = max(s.stat().st_mtime for s in existing_converters)

    if not dry_run and manifest_path.exists():
        try:
            manifest = yaml.safe_load(manifest_path.read_text())
            skip_set, convert_set = build_skip_set(
                manifest, notebooks_dir, converter_mtime, force
            )
            log.info(
                "Per-file skip check: %d files already up-to-date, %d to convert.",
                len(skip_set),
                len(convert_set),
            )
        except Exception as exc:  # noqa: BLE001
            log.warning("Could not load manifest for skip logic: %s — will convert all.", exc)
    elif dry_run:
        log.info("DRY-RUN: skipping manifest load (no subprocess has run yet).")

    # --- Step 3: convert_transforms ------------------------------------------
    log.info("Step 3/5: convert_transforms.py")
    args_transforms = [
        "--manifest", str(manifest_path),
        "--tables-config", str(tables_config_path),
        "--output-dir", str(notebooks_dir),
    ]
    if force:
        args_transforms.append("--force")
    transforms_rc = run_step(script_paths["convert_transforms"], args_transforms, dry_run)
    if transforms_rc != 0:
        log.warning(
            "convert_transforms.py exited with code %d — some files may have failed.",
            transforms_rc,
        )

    # --- Step 4: convert_sddi ------------------------------------------------
    log.info("Step 4/5: convert_sddi.py")
    args_sddi = [
        "--manifest", str(manifest_path),
        "--tables-config", str(tables_config_path),
        "--output-dir", str(notebooks_dir),
    ]
    if force:
        args_sddi.append("--force")
    sddi_rc = run_step(script_paths["convert_sddi"], args_sddi, dry_run)
    if sddi_rc != 0:
        log.warning(
            "convert_sddi.py exited with code %d — some files may have failed.",
            sddi_rc,
        )

    # --- Step 5: validate_outputs --------------------------------------------
    log.info("Step 5/5: validate_outputs.py")
    args_validate = [
        "--notebooks-dir", str(notebooks_dir),
        "--tables-config", str(tables_config_path),
        "--output-dir", str(output_dir),
    ]
    validation_failed = False
    if dry_run:
        log.info("DRY-RUN: would run validate_outputs.py %s", " ".join(args_validate))
    else:
        validate_rc = run_step(script_paths["validate_outputs"], args_validate, dry_run=False)
        validation_failed = validate_rc != 0
        if validation_failed:
            log.error(
                "validate_outputs.py FAILED — see %s",
                output_dir / "validation_report.yaml",
            )
        else:
            log.info("validate_outputs.py PASSED")

    # --- Final summary -------------------------------------------------------
    validation_report_path = output_dir / "validation_report.yaml"
    passed_count, failed_count = load_validation_summary(validation_report_path)

    print("")
    print("=== run_pipeline complete ===")
    print(f"  scan_inputs:        OK")
    print(f"  extract_rid_map:    OK")
    print(f"  convert_transforms: {'OK' if transforms_rc == 0 else 'WARNINGS'}")
    print(f"  convert_sddi:       {'OK' if sddi_rc == 0 else 'WARNINGS'}")
    if dry_run:
        print(f"  validate_outputs:   (skipped — dry-run)")
    else:
        print(f"  validate_outputs:   {'PASS' if not validation_failed else 'FAIL'}")
    print(f"  Notebooks validated: {passed_count} PASS, {failed_count} FAIL")
    print("")
    print(f"Pipeline complete: {passed_count + failed_count} notebooks converted, {failed_count} validation failures")

    if validation_failed:
        return 1
    return 0


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def parse_args(argv: Optional[List[str]] = None) -> argparse.Namespace:
    """Parse command-line arguments."""
    parser = argparse.ArgumentParser(
        description=(
            "Idempotent orchestrator for the Palantir-to-Databricks PySpark "
            "conversion pipeline. Runs all five steps in order, skipping already "
            "up-to-date output notebooks unless --force is set."
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=(
            "Examples:\n"
            "  python run_pipeline.py\n"
            "  python run_pipeline.py --force\n"
            "  python run_pipeline.py --component validate_outputs\n"
            "  python run_pipeline.py --dry-run\n"
        ),
    )
    parser.add_argument(
        "--force",
        action="store_true",
        default=False,
        help="Re-run all steps even if output notebooks are already up-to-date.",
    )
    parser.add_argument(
        "--component",
        choices=PIPELINE_STEPS,
        default=None,
        help="Run only the named pipeline step instead of the full pipeline.",
    )
    parser.add_argument(
        "--dry-run",
        action="store_true",
        default=False,
        help="Print what would be run without actually executing any scripts.",
    )
    parser.add_argument(
        "--project-root",
        type=Path,
        default=None,
        help=(
            "Absolute path to the project root. "
            "Defaults to the grandparent of the scripts directory."
        ),
    )
    parser.add_argument(
        "--output-dir",
        type=Path,
        default=None,
        help="Output directory. Defaults to <project-root>/scripts-output/output/.",
    )
    return parser.parse_args(argv)


def main() -> int:
    """Entry point. Returns exit code."""
    args = parse_args()

    # Resolve project root (scripts live in agent-output/scripts/ under project root)
    scripts_dir = Path(__file__).resolve().parent
    if args.project_root is not None:
        project_root = args.project_root.resolve()
    else:
        # scripts_dir is agent-output/scripts/; project root is two levels up
        project_root = scripts_dir.parent.parent

    output_dir = args.output_dir.resolve() if args.output_dir else project_root / "scripts-output" / "output"

    log.info(
        "run_pipeline starting (force=%s, dry_run=%s, component=%s)",
        args.force,
        args.dry_run,
        args.component or "all",
    )
    log.info("Project root: %s", project_root)
    log.info("Output dir:   %s", output_dir)

    # Resolve and verify all script paths
    script_paths = resolve_paths(scripts_dir)
    if not verify_scripts(script_paths):
        log.critical("One or more pipeline scripts are missing — cannot proceed.")
        return 1

    # Single-component mode
    if args.component:
        log.info("Single-component mode: running only '%s'", args.component)
        rc = run_single_component(
            component=args.component,
            script_paths=script_paths,
            project_root=project_root,
            output_dir=output_dir,
            force=args.force,
            dry_run=args.dry_run,
        )
        log.info("%s exited with code %d", args.component, rc)
        return rc

    # Full pipeline
    return run_full_pipeline(
        script_paths=script_paths,
        project_root=project_root,
        output_dir=output_dir,
        force=args.force,
        dry_run=args.dry_run,
    )


if __name__ == "__main__":
    sys.exit(main())
