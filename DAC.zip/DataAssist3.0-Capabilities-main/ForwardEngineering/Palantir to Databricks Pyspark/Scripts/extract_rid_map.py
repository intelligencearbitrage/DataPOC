#!/usr/bin/env python3
"""Extract Foundry RIDs from SAP transform source files and SDDI preprocessed_input_dfs keys.

Reads scripts-output/manifest.yaml (produced by scan_inputs.py) to locate source files,
then uses AST parsing to extract:
  - Input/Output RID strings from @transform_df and @transform decorated functions
  - Short keys from preprocessed_input_dfs[...] subscript expressions in SDDI files

Writes scripts-output/output/config/tables_config.yaml with:
  - tables: section — each unique RID keyed by sanitized underscore form
      (rid.replace('.','_').replace('-','_')), with table_name, delta_path, role,
      source_file, and optional arg_name / note fields.
  - sddi_tables: section — each unique SDDI short key with delta_path and source_elements.
  - summary: section — counts and timestamp.

The delta_path values are placeholder strings (/mnt/delta/sap/<table_name>) that operators
must replace with actual Databricks Delta table paths before running converted notebooks.

Dependencies: pyyaml (stdlib ast, re, logging, pathlib, datetime)
Run: python agent-output/scripts/extract_rid_map.py
     (requires scripts-output/manifest.yaml — run scan_inputs.py first)
"""

import ast
import re
import sys
import logging
import argparse
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import yaml

# ---------------------------------------------------------------------------
# Logging setup
# ---------------------------------------------------------------------------
logging.basicConfig(
    level=logging.INFO,
    format="%(levelname)s %(name)s: %(message)s",
)
log = logging.getLogger("extract_rid_map")

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------
RID_REGEX = re.compile(
    r"ri\.foundry\.main\.dataset\.[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}"
)

# Generic argument names that carry no useful table-name information on their own
GENERIC_ARG_NAMES = {
    "source_df", "output_df", "df", "input_df", "out_df", "result_df",
    "result", "output", "input",
}


# ---------------------------------------------------------------------------
# Sanitization helpers
# ---------------------------------------------------------------------------

def sanitize_rid_key(rid: str) -> str:
    """Convert a Foundry RID to a YAML-safe underscore key.

    Example:
        "ri.foundry.main.dataset.78905dc3-ec76-4ca1-b497-cb2f8a02ba03"
        -> "ri_foundry_main_dataset_78905dc3_ec76_4ca1_b497_cb2f8a02ba03"
    """
    return rid.replace(".", "_").replace("-", "_")


def uuid_suffix(rid: str) -> str:
    """Return the last 8 hex characters of the UUID portion of a RID."""
    return rid.split(".")[-1].replace("-", "")[-8:]


# ---------------------------------------------------------------------------
# AST extraction helpers
# ---------------------------------------------------------------------------

def _get_string_arg(node: ast.expr) -> Optional[str]:
    """Return the string value if node is a Constant(str), else None."""
    if isinstance(node, ast.Constant) and isinstance(node.value, str):
        return node.value
    return None


def _extract_output_name(tree: ast.Module) -> Optional[str]:
    """Search for a module-level `_OUTPUT_NAME = "..."` assignment."""
    for node in ast.walk(tree):
        if isinstance(node, ast.Assign):
            for target in node.targets:
                if isinstance(target, ast.Name) and target.id == "_OUTPUT_NAME":
                    value = _get_string_arg(node.value)
                    if value:
                        return value
    return None


def _extract_rid_entries_from_decorator(
    decorator: ast.expr,
    file_stem: str,
    output_name: Optional[str],
) -> List[Dict[str, Any]]:
    """Parse a single @transform_df or @transform decorator call.

    Returns a list of dicts:
        {rid, role, arg_name, source_file}
    """
    entries: List[Dict[str, Any]] = []

    if not isinstance(decorator, ast.Call):
        return entries

    func = decorator.func
    # Unwrap possible attribute access (transforms.api.transform_df etc.)
    func_name: str = ""
    if isinstance(func, ast.Name):
        func_name = func.id
    elif isinstance(func, ast.Attribute):
        func_name = func.attr

    if func_name not in ("transform_df", "transform"):
        return entries

    if func_name == "transform_df":
        # First positional arg is Output(RID, ...)
        if decorator.args:
            output_call = decorator.args[0]
            if isinstance(output_call, ast.Call):
                if output_call.args:
                    rid_val = _get_string_arg(output_call.args[0])
                    if rid_val and RID_REGEX.match(rid_val):
                        # Derive table name for the output
                        tname = output_name or file_stem
                        entries.append({
                            "rid": rid_val,
                            "role": "output",
                            "arg_name": None,
                            "table_name_hint": tname,
                            "source_file": file_stem,
                        })

        # Keyword args are Input(RID, ...) calls
        for kw in decorator.keywords:
            if not isinstance(kw.value, ast.Call):
                continue
            kw_func = kw.value.func
            kw_func_name = ""
            if isinstance(kw_func, ast.Name):
                kw_func_name = kw_func.id
            elif isinstance(kw_func, ast.Attribute):
                kw_func_name = kw_func.attr
            if kw_func_name != "Input":
                continue
            if not kw.value.args:
                continue
            rid_val = _get_string_arg(kw.value.args[0])
            if rid_val and RID_REGEX.match(rid_val):
                arg = kw.arg or ""
                entries.append({
                    "rid": rid_val,
                    "role": "input",
                    "arg_name": arg,
                    "table_name_hint": arg,
                    "source_file": file_stem,
                })

    elif func_name == "transform":
        # Both Input and Output appear as keyword arguments
        for kw in decorator.keywords:
            if not isinstance(kw.value, ast.Call):
                continue
            kw_func = kw.value.func
            kw_func_name = ""
            if isinstance(kw_func, ast.Name):
                kw_func_name = kw_func.id
            elif isinstance(kw_func, ast.Attribute):
                kw_func_name = kw_func.attr
            if kw_func_name not in ("Input", "Output"):
                continue
            if not kw.value.args:
                continue
            rid_val = _get_string_arg(kw.value.args[0])
            if rid_val and RID_REGEX.match(rid_val):
                role = "input" if kw_func_name == "Input" else "output"
                arg = kw.arg or ""
                # For output keyword arg, prefer _OUTPUT_NAME if available
                table_name_hint = arg
                if role == "output" and output_name:
                    table_name_hint = output_name
                entries.append({
                    "rid": rid_val,
                    "role": role,
                    "arg_name": arg,
                    "table_name_hint": table_name_hint,
                    "source_file": file_stem,
                })

    return entries


def extract_rids_from_file_ast(
    path: Path,
) -> Tuple[List[Dict[str, Any]], bool]:
    """Parse a transform source file with AST and extract RID entries.

    Returns:
        (entries, used_fallback)
        entries: list of dicts with keys: rid, role, arg_name, table_name_hint, source_file
        used_fallback: True if regex fallback was used (AST parse failed)
    """
    try:
        source = path.read_text(encoding="utf-8", errors="replace")
    except OSError as exc:
        log.warning("Cannot read %s: %s", path, exc)
        return [], False

    # Attempt AST parse
    try:
        tree = ast.parse(source, filename=str(path))
    except SyntaxError as exc:
        log.warning("ast.parse() failed for %s (%s); falling back to regex RID scan", path.name, exc)
        return _extract_rids_regex_fallback(source, path.stem), True

    file_stem = path.stem
    output_name = _extract_output_name(tree)
    entries: List[Dict[str, Any]] = []

    # Walk all function definitions and look for decorators
    for node in ast.walk(tree):
        if not isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            continue
        for decorator in node.decorator_list:
            new_entries = _extract_rid_entries_from_decorator(
                decorator, file_stem, output_name
            )
            entries.extend(new_entries)

    return entries, False


def _extract_rids_regex_fallback(
    source: str,
    file_stem: str,
) -> List[Dict[str, Any]]:
    """Regex fallback when AST parsing fails.

    Finds all RID strings in the source and marks them with role=unknown and
    a note field indicating the fallback was used.

    W-7: each extracted entry gets note: "extracted via regex fallback..."
    """
    entries: List[Dict[str, Any]] = []
    for match in RID_REGEX.finditer(source):
        rid = match.group(0)
        entries.append({
            "rid": rid,
            "role": "unknown",
            "arg_name": None,
            "table_name_hint": uuid_suffix(rid),
            "source_file": file_stem,
            "note": (
                "extracted via regex fallback — may include commented-out code; "
                "verify delta_path before use"
            ),
        })
    return entries


# ---------------------------------------------------------------------------
# SDDI extraction helpers
# ---------------------------------------------------------------------------

def extract_sddi_keys_from_file(path: Path) -> List[Dict[str, Any]]:
    """Extract preprocessed_input_dfs[key] subscript keys from an SDDI file.

    Returns:
        list of dicts with keys: sddi_key, source_file, element_name
    """
    try:
        source = path.read_text(encoding="utf-8", errors="replace")
    except OSError as exc:
        log.warning("Cannot read SDDI file %s: %s", path, exc)
        return []

    try:
        tree = ast.parse(source, filename=str(path))
    except SyntaxError as exc:
        log.warning("ast.parse() failed for SDDI file %s: %s", path.name, exc)
        # Regex fallback for SDDI keys
        return _extract_sddi_keys_regex(source, path)

    keys: List[Dict[str, Any]] = []
    for node in ast.walk(tree):
        if not isinstance(node, ast.Subscript):
            continue
        # Check if subscript value is the name preprocessed_input_dfs
        val = node.value
        if not (isinstance(val, ast.Name) and val.id == "preprocessed_input_dfs"):
            continue
        # Extract the slice key (Python 3.8 uses Index wrapper; 3.9+ does not)
        slice_node = node.slice
        if isinstance(slice_node, ast.Index):  # Python 3.8
            slice_node = slice_node.value  # type: ignore[attr-defined]
        key_str = _get_string_arg(slice_node)
        if key_str:
            keys.append({
                "sddi_key": key_str,
                "source_file": str(path),
            })

    return keys


def _extract_sddi_keys_regex(source: str, path: Path) -> List[Dict[str, Any]]:
    """Regex fallback to extract preprocessed_input_dfs[...] key strings."""
    pattern = re.compile(r'preprocessed_input_dfs\s*\[\s*["\']([^"\']+)["\']\s*\]')
    keys: List[Dict[str, Any]] = []
    for match in pattern.finditer(source):
        keys.append({
            "sddi_key": match.group(1),
            "source_file": str(path),
        })
    return keys


# ---------------------------------------------------------------------------
# Table name resolution logic
# ---------------------------------------------------------------------------

GENERIC_NAMES = {
    "source_df", "output_df", "df", "input_df", "out_df", "result_df",
    "result", "output", "input",
}


def resolve_table_name(entry: Dict[str, Any]) -> str:
    """Derive the best table name for a single RID entry.

    Priority:
      1. table_name_hint if it is set and non-generic
      2. file_stem + _raw if hint is generic and role == input
      3. file_stem for output with no meaningful hint
      4. UUID last-8 as absolute last resort
    """
    hint: str = entry.get("table_name_hint") or ""
    role: str = entry.get("role", "")
    file_stem: str = entry.get("source_file", "unknown")

    if hint and hint not in GENERIC_NAMES:
        return hint

    # Generic name or empty — use file stem
    if role == "input":
        return f"{file_stem}_raw"
    elif role == "output":
        return file_stem
    else:
        # unknown role (regex fallback)
        return uuid_suffix(entry["rid"])


# ---------------------------------------------------------------------------
# Deduplication and conflict resolution
# ---------------------------------------------------------------------------

def _name_priority(entry: Dict[str, Any]) -> int:
    """Lower number = higher priority for keeping a table_name."""
    hint = entry.get("table_name_hint") or ""
    if not hint or hint in GENERIC_NAMES:
        return 3  # file-stem derived or UUID
    # If the hint ends with _raw or _raw it is less informative than clean name
    if hint.endswith("_raw"):
        return 2
    return 1  # actual keyword arg name — most informative


def deduplicate_rid_entries(
    all_entries: List[Dict[str, Any]],
) -> Dict[str, Dict[str, Any]]:
    """Merge per-file RID entries into a single dict keyed by RID string.

    Conflict resolution:
    - Same RID used as both input and output: input gets _raw suffix appended to its name.
    - Same RID, same role, in multiple files: merge source_files list; keep most informative name.
    - Same derived table_name but different RIDs: append file stem to disambiguate the input.
    """
    # First pass: group by RID
    by_rid: Dict[str, List[Dict[str, Any]]] = {}
    for entry in all_entries:
        rid = entry["rid"]
        by_rid.setdefault(rid, []).append(entry)

    merged: Dict[str, Dict[str, Any]] = {}

    for rid, entries in by_rid.items():
        roles = {e["role"] for e in entries}

        # Collect source files
        source_files: List[str] = []
        for e in entries:
            sf = e.get("source_file", "")
            if sf and sf not in source_files:
                source_files.append(sf)

        # Sort entries by name priority (best first)
        entries_sorted = sorted(entries, key=_name_priority)
        best_entry = entries_sorted[0]

        table_name = resolve_table_name(best_entry)
        role = best_entry.get("role", "unknown")
        arg_name = best_entry.get("arg_name")

        notes: List[str] = []
        if best_entry.get("note"):
            notes.append(best_entry["note"])
        if arg_name in GENERIC_NAMES:
            notes.append(
                f"generic arg name — verify table_name before use"
            )

        # Dual-role: if same RID is BOTH input and output, keep output role but note input usage
        if "input" in roles and "output" in roles:
            role = "output"
            notes.append("dual-role RID: also used as Input in some files")

        record: Dict[str, Any] = {
            "original_rid": rid,
            "table_name": table_name,
            "delta_path": f"/mnt/delta/sap/{table_name}",
            "role": role,
            "source_file": source_files[0] if len(source_files) == 1 else source_files,
        }
        if arg_name:
            record["arg_name"] = arg_name
        if notes:
            record["note"] = "; ".join(notes)

        merged[rid] = record

    # Second pass: resolve table_name collisions across different RIDs
    name_to_rids: Dict[str, List[str]] = {}
    for rid, record in merged.items():
        name_to_rids.setdefault(record["table_name"], []).append(rid)

    for tname, rids in name_to_rids.items():
        if len(rids) <= 1:
            continue
        # Multiple RIDs share the same derived name — disambiguate
        # Prefer the output RID to keep the clean name; inputs get _raw
        input_rids = [r for r in rids if merged[r]["role"] == "input"]
        output_rids = [r for r in rids if merged[r]["role"] == "output"]

        if output_rids and input_rids:
            # Output keeps clean name; inputs get _raw suffix
            for rid in input_rids:
                rec = merged[rid]
                new_name = f"{tname}_raw"
                rec["table_name"] = new_name
                rec["delta_path"] = f"/mnt/delta/sap/{new_name}"
        else:
            # All same role — append file stem to disambiguate
            for rid in rids:
                rec = merged[rid]
                sf = rec.get("source_file")
                stem = sf[0] if isinstance(sf, list) else (sf or "unknown")
                new_name = f"{tname}_{stem}"
                rec["table_name"] = new_name
                rec["delta_path"] = f"/mnt/delta/sap/{new_name}"

    return merged


def deduplicate_sddi_entries(
    all_entries: List[Dict[str, Any]],
    element_name_by_file: Dict[str, str],
) -> Dict[str, Dict[str, Any]]:
    """Merge SDDI key entries into a dict keyed by short key."""
    by_key: Dict[str, List[str]] = {}
    for entry in all_entries:
        key = entry["sddi_key"]
        sf = entry.get("source_file", "")
        by_key.setdefault(key, []).append(sf)

    result: Dict[str, Dict[str, Any]] = {}
    for key, source_files in by_key.items():
        unique_files = list(dict.fromkeys(source_files))  # preserve order, deduplicate
        # Derive element names from source files
        elements: List[str] = []
        for sf in unique_files:
            el = element_name_by_file.get(sf, "")
            if el and el not in elements:
                elements.append(el)
        result[key] = {
            "delta_path": f"/mnt/delta/sddi/{key}",
            "source_file": unique_files[0] if len(unique_files) == 1 else unique_files,
            "source_elements": elements if elements else unique_files,
        }

    return result


# ---------------------------------------------------------------------------
# Main extraction orchestration
# ---------------------------------------------------------------------------

def load_manifest(manifest_path: Path) -> Dict[str, Any]:
    """Load and return the scripts-output/manifest.yaml dict."""
    if not manifest_path.exists():
        log.error(
            "Manifest not found at %s. Run scan_inputs.py first.", manifest_path
        )
        print("Run scan_inputs.py first", file=sys.stderr)
        sys.exit(1)
    try:
        return yaml.safe_load(manifest_path.read_text(encoding="utf-8")) or {}
    except yaml.YAMLError as exc:
        log.error("Failed to parse manifest: %s", exc)
        sys.exit(1)


def resolve_project_root() -> Path:
    """Return the project root — two directories above this script's location."""
    return Path(__file__).resolve().parent.parent.parent


def main() -> int:
    """Entry point: parse args, extract RIDs, write tables_config.yaml."""
    project_root = resolve_project_root()

    parser = argparse.ArgumentParser(
        description="Extract Foundry RIDs from SAP/SDDI sources and generate tables_config.yaml"
    )
    parser.add_argument(
        "--manifest",
        default=str(project_root / "scripts-output" / "manifest.yaml"),
        help="Path to manifest.yaml produced by scan_inputs.py",
    )
    parser.add_argument(
        "--output-dir",
        default=str(project_root / "scripts-output" / "output" / "config"),
        help="Directory to write tables_config.yaml",
    )
    parser.add_argument(
        "--project-root",
        default=str(project_root),
        help="Project root directory",
    )
    parser.add_argument(
        "--force",
        action="store_true",
        help="Force regeneration even if output already exists",
    )
    args = parser.parse_args()

    project_root = Path(args.project_root).resolve()
    manifest_path = Path(args.manifest)
    output_dir = Path(args.output_dir)
    output_path = output_dir / "tables_config.yaml"

    # Step 1: Load manifest
    manifest = load_manifest(manifest_path)

    # Step 2: Idempotency note (always regenerate)
    if output_path.exists():
        log.warning(
            "tables_config.yaml will be regenerated to capture any new RIDs"
        )

    output_dir.mkdir(parents=True, exist_ok=True)

    # Step 3: Collect file entries from manifest
    files: List[Dict[str, Any]] = manifest.get("files", [])
    if not files:
        log.warning("Manifest contains no files entries — nothing to extract")

    transform_files: List[Dict[str, Any]] = [
        f for f in files if f.get("type") == "transform_df"
    ]
    sddi_files: List[Dict[str, Any]] = [
        f for f in files if f.get("type") == "sddi"
    ]

    log.info(
        "Processing %d transform_df files and %d sddi files",
        len(transform_files),
        len(sddi_files),
    )

    # Step 4: Extract RIDs from transform_df files
    all_rid_entries: List[Dict[str, Any]] = []
    for file_entry in transform_files:
        rel_path: str = file_entry.get("path", "")
        if not rel_path:
            continue
        abs_path = project_root / rel_path
        entries, used_fallback = extract_rids_from_file_ast(abs_path)
        if used_fallback:
            log.warning("Regex fallback used for %s", rel_path)
        all_rid_entries.extend(entries)
        log.info("  %s — %d RID entries", abs_path.name, len(entries))

    # Step 5: Deduplicate RIDs
    rid_map: Dict[str, Dict[str, Any]] = deduplicate_rid_entries(all_rid_entries)

    # Step 6: Extract SDDI keys
    # Build element_name lookup: absolute path str -> element_name
    element_name_by_file: Dict[str, str] = {}
    for file_entry in sddi_files:
        rel_path = file_entry.get("path", "")
        element = file_entry.get("element_name", "")
        if rel_path:
            abs_path_str = str(project_root / rel_path)
            element_name_by_file[abs_path_str] = element

    all_sddi_entries: List[Dict[str, Any]] = []
    for file_entry in sddi_files:
        rel_path = file_entry.get("path", "")
        if not rel_path:
            continue
        abs_path = project_root / rel_path
        sddi_variant = file_entry.get("sddi_variant", "")
        element_name = file_entry.get("element_name", "")

        if sddi_variant == "deployment":
            # Add intermediate table entry for deployment.py files
            if element_name:
                int_key = f"{element_name}_intermediate"
                all_sddi_entries.append({
                    "sddi_key": int_key,
                    "source_file": str(abs_path),
                    "is_intermediate": True,
                    "element_name": element_name,
                })
        else:
            # common.py or other SDDI variants — extract preprocessed_input_dfs keys
            keys = extract_sddi_keys_from_file(abs_path)
            all_sddi_entries.extend(keys)

    # Step 7: Deduplicate SDDI
    sddi_map: Dict[str, Dict[str, Any]] = deduplicate_sddi_entries(
        all_sddi_entries, element_name_by_file
    )

    # Add notes for intermediate entries
    for entry in all_sddi_entries:
        if entry.get("is_intermediate"):
            key = entry["sddi_key"]
            el = entry.get("element_name", "")
            if key in sddi_map:
                sddi_map[key]["note"] = (
                    f"intermediate output produced by {el}_common notebook"
                )

    # Step 8: Sanitize RID keys
    tables_section: Dict[str, Any] = {}
    for rid, record in rid_map.items():
        sanitized_key = sanitize_rid_key(rid)
        tables_section[sanitized_key] = record

    # Step 9: Build config dict
    now_iso = datetime.now(timezone.utc).isoformat()
    config: Dict[str, Any] = {
        "tables": tables_section,
        "sddi_tables": sddi_map,
        "summary": {
            "total_unique_rids": len(rid_map),
            "tables_entries": len(tables_section),
            "sddi_entries": len(sddi_map),
            "generated": now_iso,
        },
    }

    # Step 10: Write atomically
    # W-4: preamble comment prepended to yaml.dump output, NOT as a dict key
    preamble = (
        "# Auto-generated by extract_rid_map.py"
        " — edit delta_path values for your environment\n"
    )
    yaml_str = preamble + yaml.dump(config, default_flow_style=False, sort_keys=False)

    tmp_path = output_path.with_suffix(".yaml.tmp")
    tmp_path.write_text(yaml_str, encoding="utf-8")
    tmp_path.replace(output_path)

    log.info(
        "tables_config.yaml written — %d RID entries, %d SDDI table entries",
        len(tables_section),
        len(sddi_map),
    )

    # Step 11: Summary
    print(
        f"extract_rid_map complete: {len(tables_section)} RIDs, {len(sddi_map)} SDDI keys"
    )
    print(f"Output: {output_path}")

    if len(tables_section) == 0:
        log.critical(
            "No RIDs found — likely a scan failure. Check manifest.yaml and source files."
        )
        return 1

    return 0


if __name__ == "__main__":
    sys.exit(main())
