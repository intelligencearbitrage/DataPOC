#!/usr/bin/env python3
"""Validate every output notebook in scripts-output/output/notebooks/ against quality criteria.

This script performs static validation only (syntax, imports, RIDs, structure).
Runtime correctness of notebooks requires Databricks cluster testing.

NOTE: This script performs static validation only (syntax, imports, RIDs, structure).
Runtime correctness of notebooks requires Databricks cluster testing.

Five checks are applied to each notebook:
  1. syntax          — ast.parse() succeeds (valid Python)
  2. no_forbidden_imports — no leftover Foundry/SDDI imports in executable code
  3. no_foundry_rids — no Foundry RID strings in executable code (inline comments allowed)
  4. databricks_header — first line is '# Databricks notebook source'
  5. command_separators — at least 3 '# COMMAND ----------' separators
                          (or >= 2 for short notebooks with fewer than 20 lines)

Inputs:  scripts-output/output/notebooks/*.py
Outputs: scripts-output/output/validation_report.yaml

Exit codes:
  0 — all notebooks passed
  1 — one or more notebooks failed
"""

import ast
import re
import sys
import logging
from datetime import datetime, timezone
from pathlib import Path
from typing import Dict, Any, List, Tuple

import yaml

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

# RID pattern matching Foundry dataset identifiers in executable code.
# Only flags matches outside of comment sections — see check_no_foundry_rids().
RID_PATTERN = re.compile(
    r'ri\.foundry\.main\.[a-zA-Z.]+\.[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}'
)

# Forbidden import prefixes. Checked against the code portion of each line
# (everything before the first '#'), so inline comments are ignored.
FORBIDDEN_IMPORTS: List[str] = [
    "from transforms.api import",
    "from transforms import",
    "from bellhop_authoring_api import",
    "import bellhop_authoring_api",
    "from software_defined_integrations",
    "from conjure_python_client",
]

# Short-notebook threshold: notebooks with fewer than this many lines use a
# relaxed command-separator minimum of >= 2 instead of >= 3.
SHORT_NOTEBOOK_LINE_THRESHOLD = 20

logging.basicConfig(
    level=logging.INFO,
    format="%(levelname)s %(message)s",
)
logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Individual check functions
# ---------------------------------------------------------------------------

def check_syntax(source: str, path: Path) -> Tuple[bool, str]:
    """Check 1: source must be valid Python (ast.parse succeeds).

    Returns (passed, detail_message).
    """
    try:
        ast.parse(source)
        return True, ""
    except SyntaxError as exc:
        return False, f"SyntaxError at line {exc.lineno}: {exc.msg}"


def check_no_forbidden_imports(source: str) -> Tuple[bool, List[Dict[str, Any]]]:
    """Check 2: no leftover Foundry/SDDI framework imports in executable code.

    Strips inline comment suffixes before matching so that documentation
    comments containing import strings do not produce false positives.

    Returns (passed, violations) where each violation is a dict with
    keys 'check', 'line', 'content'.
    """
    violations: List[Dict[str, Any]] = []
    for lineno, raw_line in enumerate(source.splitlines(), start=1):
        # Strip the comment part to check only executable code.
        code_part = raw_line.split("#")[0]
        for forbidden in FORBIDDEN_IMPORTS:
            if forbidden in code_part:
                violations.append({
                    "check": "no_forbidden_imports",
                    "line": lineno,
                    "content": raw_line.rstrip(),
                })
                break  # one violation per line is enough
    return len(violations) == 0, violations


def check_no_foundry_rids(source: str) -> Tuple[bool, List[Dict[str, Any]]]:
    """Check 3: no Foundry RID strings in executable code.

    CI-3 fix: strip inline comment suffixes before running the RID regex.
    This correctly handles:
      - Full-line comments:  code_part will be empty → regex never matches.
      - Inline comments:     code_part holds only the executable portion → RID
                             in a trailing '# Original Foundry RID: ...' comment
                             is NOT flagged.

    Returns (passed, violations).
    """
    violations: List[Dict[str, Any]] = []
    for lineno, raw_line in enumerate(source.splitlines(), start=1):
        # Strip everything after the first '#' to get only executable code.
        code_part = raw_line.split("#")[0]  # strip everything after first #
        if RID_PATTERN.search(code_part):
            violations.append({
                "check": "no_foundry_rids",
                "line": lineno,
                "content": raw_line.rstrip(),
            })
    return len(violations) == 0, violations


def check_databricks_header(source: str) -> bool:
    """Check 4: first line must be '# Databricks notebook source'.

    Returns True if the header is present.
    """
    first_line = source.splitlines()[0].rstrip() if source.strip() else ""
    return first_line == "# Databricks notebook source"


def check_command_separators(source: str) -> Tuple[bool, int]:
    """Check 5: notebook must contain enough '# COMMAND ----------' separators.

    W-3 threshold rule:
      - Notebooks with >= 20 lines: require >= 3 separators.
      - Short notebooks (< 20 lines): use >= 2 as the minimum threshold.
        (Short notebooks may have fewer logical cells; two separators is
        enough to confirm the Databricks format was applied.)

    Returns (passed, count_found).
    """
    lines = source.splitlines()
    count = source.count("# COMMAND ----------")
    # W-3: Use >= 2 as minimum COMMAND separator threshold for short notebooks
    # (< 20 lines) — short notebooks may legitimately have only 2 cells.
    min_required = 2 if len(lines) < SHORT_NOTEBOOK_LINE_THRESHOLD else 3
    return count >= min_required, count


# ---------------------------------------------------------------------------
# Per-notebook validation
# ---------------------------------------------------------------------------

def validate_notebook(path: Path) -> Dict[str, Any]:
    """Run all five checks on a single notebook file.

    Returns a result dict suitable for inclusion in validation_report.yaml.
    """
    result: Dict[str, Any] = {
        "verdict": "PASS",
        "checks": {
            "syntax": "PASS",
            "no_forbidden_imports": "PASS",
            "no_foundry_rids": "PASS",
            "databricks_header": "PASS",
            "command_separators": "PASS",
        },
        "violations": [],
    }

    # Read source — handle missing or unreadable files gracefully.
    try:
        source = path.read_text(encoding="utf-8")
    except UnicodeDecodeError as exc:
        result["verdict"] = "FAIL"
        result["violations"].append({
            "check": "read_error",
            "line": 0,
            "content": f"UnicodeDecodeError: {exc}",
        })
        for key in result["checks"]:
            result["checks"][key] = "FAIL"
        return result
    except OSError as exc:
        result["verdict"] = "FAIL"
        result["violations"].append({
            "check": "read_error",
            "line": 0,
            "content": f"OSError: {exc}",
        })
        for key in result["checks"]:
            result["checks"][key] = "FAIL"
        return result

    if not source.strip():
        result["verdict"] = "FAIL"
        result["violations"].append({
            "check": "read_error",
            "line": 0,
            "content": "File is empty",
        })
        for key in result["checks"]:
            result["checks"][key] = "FAIL"
        return result

    # Check 1: Syntax
    syntax_pass, syntax_msg = check_syntax(source, path)
    if not syntax_pass:
        result["checks"]["syntax"] = "FAIL"
        result["verdict"] = "FAIL"
        result["violations"].append({
            "check": "syntax",
            "line": 0,
            "content": syntax_msg,
        })

    # Check 2: No forbidden imports
    imports_pass, import_violations = check_no_forbidden_imports(source)
    if not imports_pass:
        result["checks"]["no_forbidden_imports"] = "FAIL"
        result["verdict"] = "FAIL"
        result["violations"].extend(import_violations)

    # Check 3: No Foundry RIDs in executable code
    rids_pass, rid_violations = check_no_foundry_rids(source)
    if not rids_pass:
        result["checks"]["no_foundry_rids"] = "FAIL"
        result["verdict"] = "FAIL"
        result["violations"].extend(rid_violations)

    # Check 4: Databricks header
    header_pass = check_databricks_header(source)
    if not header_pass:
        result["checks"]["databricks_header"] = "FAIL"
        result["verdict"] = "FAIL"
        result["violations"].append({
            "check": "databricks_header",
            "line": 1,
            "content": "First line is not '# Databricks notebook source'",
        })

    # Check 5: COMMAND separators
    sep_pass, sep_count = check_command_separators(source)
    if not sep_pass:
        result["checks"]["command_separators"] = "FAIL"
        result["verdict"] = "FAIL"
        min_required = (
            2 if len(source.splitlines()) < SHORT_NOTEBOOK_LINE_THRESHOLD else 3
        )
        result["violations"].append({
            "check": "command_separators",
            "line": 0,
            "content": (
                f"Only {sep_count} '# COMMAND ----------' separator(s) found; "
                f"expected >= {min_required}"
            ),
        })

    return result


# ---------------------------------------------------------------------------
# Main entry point
# ---------------------------------------------------------------------------

def main() -> int:
    """Validate all notebooks and write validation_report.yaml.

    Returns exit code: 0 if all pass, 1 if any fail.
    """
    project_root = Path(__file__).resolve().parent.parent.parent
    notebooks_dir = project_root / "scripts-output" / "output" / "notebooks"
    output_dir = project_root / "scripts-output" / "output"

    # Handle missing notebooks directory gracefully.
    if not notebooks_dir.exists():
        print(
            f"validate_outputs: notebooks directory not found: {notebooks_dir}\n"
            "Nothing to validate."
        )
        return 0

    notebook_files = sorted(notebooks_dir.glob("*.py"))
    if not notebook_files:
        print(
            f"validate_outputs: no .py files found in {notebooks_dir}\n"
            "Nothing to validate."
        )
        return 0

    logger.info("Validating %d notebook(s) in %s", len(notebook_files), notebooks_dir)

    # Run validation for each notebook.
    results: Dict[str, Any] = {}
    for nb_path in notebook_files:
        result = validate_notebook(nb_path)
        results[nb_path.name] = result
        if result["verdict"] == "PASS":
            logger.info("PASS  %s", nb_path.name)
        else:
            violation_summary = "; ".join(
                v["content"] for v in result["violations"]
            )
            logger.error("FAIL  %s — %s", nb_path.name, violation_summary)

    # Compute summary statistics.
    total = len(results)
    passed = sum(1 for r in results.values() if r["verdict"] == "PASS")
    failed = total - passed
    overall_verdict = "PASS" if failed == 0 else "FAIL"

    summary = {
        "total_notebooks": total,
        "passed": passed,
        "failed": failed,
        "overall_verdict": overall_verdict,
    }

    # Build report structure.
    report = {
        "generated": datetime.now(timezone.utc).isoformat(),
        "summary": summary,
        "results": results,
    }

    # Write report to disk (write to .tmp then rename for atomicity).
    output_dir.mkdir(parents=True, exist_ok=True)
    report_path = output_dir / "validation_report.yaml"
    tmp_path = report_path.with_suffix(".yaml.tmp")
    tmp_path.write_text(
        yaml.dump(report, default_flow_style=False, sort_keys=False, allow_unicode=True),
        encoding="utf-8",
    )
    tmp_path.rename(report_path)
    logger.info("Validation report written to %s", report_path)

    # Print summary and exit.
    print(f"{passed}/{total} notebooks PASSED validation")
    if overall_verdict == "PASS":
        print("All notebooks passed validation.")
        return 0
    else:
        print(
            f"VALIDATION FAILED — {failed} notebook(s) failed checks. "
            f"See {report_path} for details."
        )
        return 1


if __name__ == "__main__":
    sys.exit(main())
