#!/usr/bin/env python3
"""Convert Palantir Foundry @transform_df/@transform/@configure files to Databricks PySpark notebooks.

Reads:
  - scripts-output/manifest.yaml (filter: type=transform_df)
  - scripts-output/output/config/tables_config.yaml (RID -> Delta path mapping)
  - Source .py files listed in the manifest

Writes:
  - scripts-output/output/notebooks/<output_notebook> — one notebook per source file

Dependency check:
  - Requires scan_inputs.py to have run first (produces scripts-output/manifest.yaml)
  - Requires extract_rid_map.py to have run first (produces scripts-output/output/config/tables_config.yaml)

Cell structure per notebook:
  Cell 1: Databricks notebook source header + generation metadata
  Cell 2: PySpark imports (Foundry imports stripped, PySpark equivalents added)
  Cell 3: tables_config.yaml loading code
  Cell 4: Input reads (one per input, with RID comment on separate line above)
  Cell 5: Helper function definitions (non-compute module-level functions)
  Cell 6: Transform logic (inlined compute() body, return replaced for transform_df)
  Cell 7: Output writes (transform_df only; multi-output writes are in Cell 6)

Usage:
  python convert_transforms.py [--manifest PATH] [--tables-config PATH] [--output-dir PATH]
                                [--force] [--file FILENAME]
"""

import ast
import argparse
import logging
import sys
from datetime import date
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import yaml

# ---------------------------------------------------------------------------
# Logging
# ---------------------------------------------------------------------------
logging.basicConfig(
    level=logging.INFO,
    format="%(levelname)s  %(message)s",
)
logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------
CELL_SEP = "\n# COMMAND ----------\n"
NOTEBOOK_HEADER = "# Databricks notebook source"
CONVERSION_DATE = str(date.today())

PYSPARK_IMPORTS = """\
from pyspark.sql import SparkSession
from pyspark.sql import functions as F
from pyspark.sql.types import *
spark = SparkSession.builder.getOrCreate()"""

TABLES_CONFIG_LOAD = """\
import yaml
from pathlib import Path
tables_config = yaml.safe_load(Path("scripts-output/output/config/tables_config.yaml").read_text())"""

# Foundry import prefixes to strip
FOUNDRY_IMPORT_PREFIXES = (
    "from transforms.api import",
    "from transforms import",
    "from foundry_lifetimes import",
)

# Decorator names that should be stripped
FOUNDRY_DECORATOR_NAMES = {"transform_df", "transform", "configure"}


# ---------------------------------------------------------------------------
# RID sanitization (CI-2 fix)
# ---------------------------------------------------------------------------

def sanitize_rid_key(rid: str) -> str:
    """Convert a Foundry RID to a YAML-safe underscore key.

    Example: ri.foundry.main.dataset.78905dc3-ec76-4ca1-b497-cb2f8a02ba03
          -> ri_foundry_main_dataset_78905dc3_ec76_4ca1_b497_cb2f8a02ba03
    """
    return rid.replace(".", "_").replace("-", "_")


def lookup_delta_path(rid: str, tables_config: Dict[str, Any]) -> str:
    """Look up a Delta path for a RID from tables_config.

    Uses the sanitized underscore key format (CI-2).
    Falls back to a placeholder path if the RID is not found.
    """
    sanitized = sanitize_rid_key(rid)
    tables = tables_config.get("tables", {})
    if sanitized in tables:
        entry = tables[sanitized]
        return entry.get("delta_path", f"/mnt/delta/sap/unknown_{rid[-8:]}")
    logger.warning("RID %s (key=%s) not in tables_config; using placeholder path", rid, sanitized)
    return f"/mnt/delta/sap/unknown_{rid[-8:]}"


# ---------------------------------------------------------------------------
# AST helpers
# ---------------------------------------------------------------------------

def get_source_segment(source_lines: List[str], node: ast.AST) -> str:
    """Extract the original source text for an AST node using line numbers.

    Compatible with Python 3.8 (ast.unparse is 3.9+).
    """
    start = node.lineno - 1  # type: ignore[attr-defined]
    end = node.end_lineno     # type: ignore[attr-defined]
    segment = "\n".join(source_lines[start:end])
    return segment


def get_decorator_name(decorator: ast.expr) -> Optional[str]:
    """Return the bare name of a decorator (handles both Name and Call nodes)."""
    if isinstance(decorator, ast.Name):
        return decorator.id
    if isinstance(decorator, ast.Call):
        func = decorator.func
        if isinstance(func, ast.Name):
            return func.id
        if isinstance(func, ast.Attribute):
            return func.attr
    return None


def extract_string_value(node: ast.expr) -> Optional[str]:
    """Extract a string literal from an AST node (Constant or Str for 3.7)."""
    if isinstance(node, ast.Constant) and isinstance(node.value, str):
        return node.value
    # Python 3.7 compatibility
    if isinstance(node, ast.Str):  # type: ignore[attr-defined]
        return node.s  # type: ignore[attr-defined]
    return None


def extract_profile_values(
    configure_node: ast.Call,
    source_lines: List[str],
    module_body: List[ast.stmt],
) -> List[str]:
    """Extract Spark profile strings from a @configure(profile=...) decorator.

    Handles both direct list literals and variable references like _SPARK_OPTS.
    """
    profiles: List[str] = []
    for kw in configure_node.keywords:
        if kw.arg == "profile":
            val = kw.value
            # Direct list: profile=["A", "B"]
            if isinstance(val, ast.List):
                for elt in val.elts:
                    s = extract_string_value(elt)
                    if s:
                        profiles.append(s)
            # Variable reference: profile=_SPARK_OPTS
            elif isinstance(val, ast.Name):
                var_name = val.id
                # Find the assignment in module body
                for stmt in module_body:
                    if (
                        isinstance(stmt, ast.Assign)
                        and len(stmt.targets) == 1
                        and isinstance(stmt.targets[0], ast.Name)
                        and stmt.targets[0].id == var_name
                        and isinstance(stmt.value, ast.List)
                    ):
                        for elt in stmt.value.elts:
                            s = extract_string_value(elt)
                            if s:
                                profiles.append(s)
                        break
    return profiles


# ---------------------------------------------------------------------------
# Decorator analysis
# ---------------------------------------------------------------------------

class TransformInfo:
    """Parsed information extracted from the @transform_df / @transform decorator."""

    def __init__(self) -> None:
        self.is_multi_output: bool = False          # True for @transform, False for @transform_df
        self.output_rid: Optional[str] = None       # @transform_df single output RID
        self.output_pairs: List[Tuple[str, str]] = []  # @transform (kwarg_name, RID) pairs
        self.input_pairs: List[Tuple[str, str]] = []   # (kwarg_name, RID) pairs
        self.configure_profiles: List[str] = []


def extract_rid_from_call(call_node: ast.Call) -> Optional[str]:
    """Extract the first string argument from an Input(...) or Output(...) call."""
    if call_node.args:
        return extract_string_value(call_node.args[0])
    return None


def analyze_decorators(
    func_node: ast.FunctionDef,
    source_lines: List[str],
    module_body: List[ast.stmt],
) -> TransformInfo:
    """Walk a function's decorator list and extract TransformInfo."""
    info = TransformInfo()

    for dec in func_node.decorator_list:
        name = get_decorator_name(dec)
        if name == "configure" and isinstance(dec, ast.Call):
            info.configure_profiles = extract_profile_values(dec, source_lines, module_body)

        elif name == "transform_df" and isinstance(dec, ast.Call):
            info.is_multi_output = False
            # First positional arg is Output(RID, checks=[...])
            if dec.args:
                out_call = dec.args[0]
                if isinstance(out_call, ast.Call):
                    info.output_rid = extract_rid_from_call(out_call)
            # Keyword args are name=Input(RID)
            for kw in dec.keywords:
                if kw.arg and isinstance(kw.value, ast.Call):
                    rid = extract_rid_from_call(kw.value)
                    if rid:
                        info.input_pairs.append((kw.arg, rid))

        elif name == "transform" and isinstance(dec, ast.Call):
            info.is_multi_output = True
            for kw in dec.keywords:
                if kw.arg and isinstance(kw.value, ast.Call):
                    kw_func_name = get_decorator_name(kw.value)
                    rid = extract_rid_from_call(kw.value)
                    if rid:
                        if kw_func_name == "Output":
                            info.output_pairs.append((kw.arg, rid))
                        elif kw_func_name == "Input":
                            info.input_pairs.append((kw.arg, rid))
                elif kw.arg is None and isinstance(kw.value, ast.Name):
                    # Enhancement: handle **kwarg unpacking (e.g. **OUTPUT_MAP) in @transform
                    # kw.arg is None for **dict_var syntax in the AST
                    var_name = kw.value.id
                    resolved = False
                    for stmt in module_body:
                        if (
                            isinstance(stmt, ast.Assign)
                            and len(stmt.targets) == 1
                            and isinstance(stmt.targets[0], ast.Name)
                            and stmt.targets[0].id == var_name
                            and isinstance(stmt.value, ast.Dict)
                        ):
                            # Walk the dict literal to extract Output() and Input() entries
                            for dict_key, dict_val in zip(stmt.value.keys, stmt.value.values):
                                if not isinstance(dict_val, ast.Call):
                                    continue
                                entry_func = get_decorator_name(dict_val)
                                entry_rid = extract_rid_from_call(dict_val)
                                if not entry_rid:
                                    continue
                                # Derive a kwarg name from the dict key (string literal)
                                if isinstance(dict_key, ast.Constant) and isinstance(dict_key.value, str):
                                    entry_name = dict_key.value
                                elif isinstance(dict_key, ast.Name):
                                    entry_name = dict_key.id
                                else:
                                    continue
                                if entry_func == "Output":
                                    info.output_pairs.append((entry_name, entry_rid))
                                elif entry_func == "Input":
                                    info.input_pairs.append((entry_name, entry_rid))
                            resolved = True
                            break
                    if not resolved:
                        logger.warning(
                            "**%s unpacking in @transform decorator cannot be statically resolved "
                            "— outputs in this dict will be missing from the converted notebook. "
                            "Inspect and add them manually.",
                            var_name,
                        )

    return info


# ---------------------------------------------------------------------------
# Source text utilities
# ---------------------------------------------------------------------------

def strip_foundry_imports(source_lines: List[str]) -> List[str]:
    """Remove Foundry import lines from source.

    Also handles continuation lines (lines ending with backslash or
    inside parentheses after a Foundry import — treated as a block).
    Returns the filtered line list.
    """
    result: List[str] = []
    skip_until_paren_close = False
    open_parens = 0

    for line in source_lines:
        stripped = line.strip()

        # We are inside a multi-line Foundry import (open parens not yet closed)
        if skip_until_paren_close:
            open_parens += stripped.count("(") - stripped.count(")")
            if open_parens <= 0:
                skip_until_paren_close = False
            continue

        # Check if this line starts a Foundry import
        is_foundry = any(stripped.startswith(prefix) for prefix in FOUNDRY_IMPORT_PREFIXES)
        if is_foundry:
            # Count parens to handle multi-line imports
            open_parens = stripped.count("(") - stripped.count(")")
            if open_parens > 0:
                skip_until_paren_close = True
            continue

        result.append(line)

    return result


def is_spark_opts_only_used_by_configure(
    var_name: str, source_lines: List[str], module_body: List[ast.stmt]
) -> bool:
    """Heuristic: if _SPARK_OPTS is only referenced in @configure, it's safe to remove.

    Looks for any references to var_name that are NOT inside a decorator.
    """
    # Simple heuristic: scan source for references outside decorator lines
    for node in module_body:
        if isinstance(node, ast.Assign):
            # Skip the assignment itself
            if any(
                isinstance(t, ast.Name) and t.id == var_name
                for t in node.targets
            ):
                continue
        # If we see var_name referenced in non-assign, non-decorator module-level statements
        # we can't remove it. For simplicity, only remove if name is exactly _SPARK_OPTS.
    # Conservative: only auto-remove if the name follows the _SPARK_OPTS naming convention
    return var_name.startswith("_SPARK_OPTS") or var_name == "_SPARK_OPTS"


def get_vars_only_in_checks(
    source_lines: List[str], module_body: List[ast.stmt], func_node: ast.FunctionDef
) -> set:
    """Identify module-level variables that are only used in @transform_df Output checks.

    Returns variable names that can be safely removed along with checks.
    Only removes _OUTPUT_NAME and _PK_COLS if they don't appear in the function body.
    """
    candidates = {"_OUTPUT_NAME", "_PK_COLS", "_METRIC_COLS"}
    # Check if any candidate appears in the function body source
    body_lines = source_lines[func_node.body[0].lineno - 1: func_node.body[-1].end_lineno]  # type: ignore[attr-defined]
    body_text = "\n".join(body_lines)
    safe_to_remove = set()
    for cand in candidates:
        if cand not in body_text:
            safe_to_remove.add(cand)
    return safe_to_remove


def is_check_only_variable_line(
    line: str, removable_vars: set
) -> bool:
    """Return True if a source line is an assignment of a check-only variable."""
    stripped = line.strip()
    for var in removable_vars:
        if stripped.startswith(var + " =") or stripped.startswith(var + "="):
            return True
    return False


# ---------------------------------------------------------------------------
# Body transformation for @transform (multi-output)
# ---------------------------------------------------------------------------

def transform_multi_output_body(
    body_lines: List[str],
    output_pairs: List[Tuple[str, str]],
    input_pairs: List[Tuple[str, str]],
    tables_config: Dict[str, Any],
) -> List[str]:
    """Transform the body of a multi-output @transform compute() function.

    Replaces:
      out_name.write_dataframe(df_expr)  ->  df_expr.write.format("delta")...
      in_name.dataframe()                ->  in_name  (already assigned in Cell 4)

    Handles multi-line write_dataframe() calls by accumulating continuation lines
    until the opening parenthesis is closed before performing the replacement.
    """
    output_map = {name: rid for name, rid in output_pairs}
    result_lines = []

    # Enhancement: collect logical lines by tracking parenthesis depth so that
    # multi-line write_dataframe() calls are handled as a single unit.
    pending_lines: List[str] = []   # raw source lines forming the current logical line
    pending_depth: int = 0          # net open-paren depth across pending_lines

    def flush_pending() -> None:
        """Process the accumulated logical line(s) and append to result_lines."""
        if not pending_lines:
            return
        # Join into one logical string for pattern matching
        logical = "".join(l.rstrip("\n") + " " for l in pending_lines).rstrip()
        # Preserve leading whitespace from first physical line
        leading_ws = pending_lines[0][: len(pending_lines[0]) - len(pending_lines[0].lstrip())]

        transformed = logical
        matched_output = False

        for out_name, out_rid in output_map.items():
            if f"{out_name}.write_dataframe(" not in transformed:
                continue
            sanitized = sanitize_rid_key(out_rid)
            # Extract the argument of write_dataframe(...)
            start_idx = (
                transformed.index(f"{out_name}.write_dataframe(")
                + len(f"{out_name}.write_dataframe(")
            )
            depth = 1
            i = start_idx
            while i < len(transformed) and depth > 0:
                if transformed[i] == "(":
                    depth += 1
                elif transformed[i] == ")":
                    depth -= 1
                i += 1
            df_expr = transformed[start_idx: i - 1].strip()
            # Emit RID comment on a separate line (CI-3 fix)
            result_lines.append(f"{leading_ws}# Original Foundry RID: {out_rid}")
            transformed = (
                f'{leading_ws}{df_expr}.write.format("delta").mode("overwrite")'
                f'.save(tables_config["tables"]["{sanitized}"]["delta_path"])'
            )
            matched_output = True
            break

        # Replace input_name.dataframe() with just input_name
        for in_name, _ in input_pairs:
            transformed = transformed.replace(f"{in_name}.dataframe()", in_name)

        result_lines.append(transformed)
        pending_lines.clear()

    for line in body_lines:
        if pending_depth == 0 and not pending_lines:
            # Not currently accumulating — check if this line opens a multi-line
            # write_dataframe() call for any tracked output
            opens_multi = False
            for out_name in output_map:
                if f"{out_name}.write_dataframe(" in line:
                    # Count net depth change on this line
                    stripped = line.rstrip("\n")
                    # Start counting from the .write_dataframe( position
                    call_pos = stripped.index(f"{out_name}.write_dataframe(")
                    after_open = stripped[call_pos + len(f"{out_name}.write_dataframe("):]
                    depth = 1
                    for ch in after_open:
                        if ch == "(":
                            depth += 1
                        elif ch == ")":
                            depth -= 1
                    if depth > 0:
                        # Multi-line call — start accumulating
                        pending_lines.append(line)
                        pending_depth = depth
                        opens_multi = True
                    break
            if not opens_multi:
                # Single-line — process immediately (original behaviour)
                pending_lines.append(line)
                pending_depth = 0
                flush_pending()
        else:
            # We are accumulating a multi-line logical line
            pending_lines.append(line)
            stripped = line.rstrip("\n")
            for ch in stripped:
                if ch == "(":
                    pending_depth += 1
                elif ch == ")":
                    pending_depth -= 1
            if pending_depth <= 0:
                pending_depth = 0
                flush_pending()

    # Flush any remaining pending lines (shouldn't happen in well-formed code)
    if pending_lines:
        flush_pending()

    return result_lines


# ---------------------------------------------------------------------------
# Return statement extraction for @transform_df
# ---------------------------------------------------------------------------

def process_transform_df_body(
    body_lines: List[str],
) -> Tuple[List[str], str]:
    """Process the body of a @transform_df compute() function.

    Finds the return statement, removes it, and returns:
      - body_lines without the return statement
      - the result variable name (or 'result' if expression was inline)
    """
    result_var = "result"
    new_body = []

    # Find the last return statement
    for line in body_lines:
        stripped = line.strip()
        if stripped.startswith("return "):
            expr = stripped[len("return "):].strip()
            if expr:
                # If expr is a simple name, use it as the result var
                try:
                    parsed = ast.parse(expr, mode="eval")
                    if isinstance(parsed.body, ast.Name):
                        result_var = parsed.body.id
                        # Don't emit the return line
                        continue
                    else:
                        # Inline expression — assign to result
                        leading_ws = line[: len(line) - len(line.lstrip())]
                        new_body.append(f"{leading_ws}result = {expr}")
                        result_var = "result"
                        continue
                except SyntaxError:
                    # Fall through to keep the line as-is
                    pass
        new_body.append(line)

    return new_body, result_var


# ---------------------------------------------------------------------------
# Helper functions detection
# ---------------------------------------------------------------------------

def get_helper_functions(
    module: ast.Module, source_lines: List[str], compute_name: str = "compute"
) -> List[str]:
    """Return source text of all module-level FunctionDef nodes that are NOT compute().

    Excludes functions with @udf decorator (those are included in helpers but
    identified separately so callers can place them in the right cell).
    """
    helpers = []
    for node in module.body:
        if isinstance(node, ast.FunctionDef) and node.name != compute_name:
            helpers.append(get_source_segment(source_lines, node))
    return helpers


def has_udf_decorator(node: ast.FunctionDef) -> bool:
    """Return True if the function has a @udf decorator."""
    for dec in node.decorator_list:
        name = get_decorator_name(dec)
        if name == "udf":
            return True
    return False


# ---------------------------------------------------------------------------
# Module-level variable filtering
# ---------------------------------------------------------------------------

def should_remove_module_var(
    stmt: ast.stmt,
    spark_opts_var: Optional[str],
    removable_check_vars: set,
    source_lines: List[str],
) -> bool:
    """Return True if a module-level statement should be removed from imports cell."""
    if not isinstance(stmt, ast.Assign):
        return False
    if len(stmt.targets) != 1 or not isinstance(stmt.targets[0], ast.Name):
        return False
    var_name = stmt.targets[0].id
    if spark_opts_var and var_name == spark_opts_var:
        if is_spark_opts_only_used_by_configure(var_name, source_lines, []):
            return True
    if var_name in removable_check_vars:
        return True
    return False


# ---------------------------------------------------------------------------
# Imports cell builder
# ---------------------------------------------------------------------------

def build_imports_cell(
    source_lines: List[str],
    module: ast.Module,
    spark_opts_var: Optional[str],
    removable_check_vars: set,
    configure_profiles: List[str],
    source_path: Path,
    project_root: Path,
) -> str:
    """Build Cell 2: imports + any surviving module-level non-decorator statements."""
    lines = []

    # Header comment
    try:
        rel_path = source_path.relative_to(project_root)
    except ValueError:
        rel_path = source_path
    lines.append(f"# Generated from: {rel_path}")
    lines.append(f"# Conversion date: {CONVERSION_DATE}")
    lines.append("")

    # Spark profile comment (if @configure was present)
    if configure_profiles:
        profiles_str = ", ".join(configure_profiles)
        lines.append(f"# Spark profile: {profiles_str} (configure equivalent settings in Databricks cluster)")
        lines.append("")

    # PySpark imports
    lines.append(PYSPARK_IMPORTS)
    lines.append("")

    # Collect surviving import lines and module-level variable assignments
    # We iterate through source lines, skipping Foundry imports and removed vars
    # We also skip the compute() function and helper functions (handled in other cells)
    # We skip decorators entirely
    # The approach: track which line ranges to skip via AST node positions

    # Determine line ranges to skip:
    skip_ranges: List[Tuple[int, int]] = []  # (start_lineno, end_lineno), 1-based inclusive

    for node in module.body:
        # Skip ALL function definitions (compute goes to Cell 6, helpers to Cell 5)
        if isinstance(node, ast.FunctionDef):
            # Include decorator lines in the skip range
            # AST puts decorator lines before func.lineno; use min(decorator.lineno)
            if node.decorator_list:
                dec_start = min(d.lineno for d in node.decorator_list)  # type: ignore[attr-defined]
            else:
                dec_start = node.lineno  # type: ignore[attr-defined]
            skip_ranges.append((dec_start, node.end_lineno))  # type: ignore[attr-defined]
            continue

        # Skip module-level variables that are safe to remove
        if should_remove_module_var(node, spark_opts_var, removable_check_vars, source_lines):
            skip_ranges.append((node.lineno, node.end_lineno))  # type: ignore[attr-defined]
            continue

    # Build a set of skipped line numbers (1-based)
    skipped_lines = set()
    for start, end in skip_ranges:
        for ln in range(start, end + 1):
            skipped_lines.add(ln)

    # Now process source lines: skip Foundry imports, removed vars, and all functions
    # (functions go to their respective cells). Collect remaining lines.
    additional_lines: List[str] = []
    in_multi_line_import = False
    open_parens = 0

    for lineno, raw_line in enumerate(source_lines, start=1):
        if lineno in skipped_lines:
            continue

        stripped = raw_line.strip()

        # Skip blank lines at the very beginning (will add our own)
        # Skip Foundry imports
        if any(stripped.startswith(prefix) for prefix in FOUNDRY_IMPORT_PREFIXES):
            # Handle multi-line Foundry imports
            open_parens = stripped.count("(") - stripped.count(")")
            if open_parens > 0:
                in_multi_line_import = True
            continue

        if in_multi_line_import:
            open_parens += stripped.count("(") - stripped.count(")")
            if open_parens <= 0:
                in_multi_line_import = False
            continue

        # All function definitions (including their decorators) are already in
        # skip_ranges via AST node positions. Any remaining @ lines are non-Foundry
        # decorators (e.g. @udf) — these are part of helper functions and also in
        # skip_ranges. Nothing to do here explicitly; just collect surviving lines.
        additional_lines.append(raw_line)

    # Deduplicate and filter the additional lines
    # Remove duplicate pyspark imports since we already inject them
    pyspark_already_covered = {
        "from pyspark.sql import functions as F",
        "from pyspark.sql import SparkSession",
        "from pyspark.sql.types import *",
        "spark = SparkSession.builder.getOrCreate()",
    }

    filtered_additional: List[str] = []
    for line in additional_lines:
        s = line.strip()
        if s in pyspark_already_covered:
            continue
        # Skip lines that declare from pyspark.sql import functions as F (covered)
        if s == "from pyspark.sql import functions as F":
            continue
        filtered_additional.append(line)

    # Now strip trailing blank lines from the block
    while filtered_additional and not filtered_additional[-1].strip():
        filtered_additional.pop()

    if filtered_additional:
        lines.extend(line.rstrip("\n") for line in filtered_additional)

    return "\n".join(lines)


# ---------------------------------------------------------------------------
# Main conversion logic
# ---------------------------------------------------------------------------

def find_compute_node(module: ast.Module) -> List[ast.FunctionDef]:
    """Find all @transform_df / @transform decorated FunctionDef nodes at module level.

    Returns a list so that files with multiple independently-decorated functions
    (e.g. usa_states_and_zip_codes_geo_json.py) are handled correctly rather than
    silently dropping all but the first.

    The list is ordered as they appear in source.  Named-'compute' functions are
    always preferred when present; remaining decorated functions follow in source order.
    """
    # Enhancement: return ALL @transform/@transform_df decorated functions, not just the first.
    named_compute: List[ast.FunctionDef] = []
    other_decorated: List[ast.FunctionDef] = []

    for node in module.body:
        if not isinstance(node, ast.FunctionDef):
            continue
        has_transform_dec = any(
            get_decorator_name(dec) in ("transform_df", "transform")
            for dec in node.decorator_list
        )
        if not has_transform_dec:
            continue
        if node.name == "compute":
            named_compute.append(node)
        else:
            other_decorated.append(node)

    return named_compute + other_decorated


def find_spark_opts_var(module: ast.Module) -> Optional[str]:
    """Find the variable name used in @configure(profile=<var>)."""
    for node in module.body:
        if isinstance(node, ast.FunctionDef):
            for dec in node.decorator_list:
                if get_decorator_name(dec) == "configure" and isinstance(dec, ast.Call):
                    for kw in dec.keywords:
                        if kw.arg == "profile" and isinstance(kw.value, ast.Name):
                            return kw.value.id
    return None


def _build_notebook_for_compute(
    compute_node: ast.FunctionDef,
    source_lines: List[str],
    module: ast.Module,
    tables_config: Dict[str, Any],
    spark_opts_var: Optional[str],
    source_path: Path,
    project_root: Path,
    all_compute_nodes: Optional[List[ast.FunctionDef]] = None,
) -> str:
    """Build the full notebook content string for a single compute function node.

    Shared by convert_file() whether the source file has one or multiple
    @transform/@transform_df decorated functions.
    """
    # Analyze decorators for this specific compute node
    info = analyze_decorators(compute_node, source_lines, module.body)

    # Removable check-only vars scoped to this compute node
    removable_check_vars = get_vars_only_in_checks(source_lines, module.body, compute_node)

    # -----------------------------------------------------------------------
    # Cell 1: Notebook header
    # -----------------------------------------------------------------------
    cell1 = NOTEBOOK_HEADER

    # -----------------------------------------------------------------------
    # Cell 2: Imports
    # -----------------------------------------------------------------------
    cell2 = build_imports_cell(
        source_lines,
        module,
        spark_opts_var,
        removable_check_vars,
        info.configure_profiles,
        source_path,
        project_root,
    )

    # -----------------------------------------------------------------------
    # Cell 3: Load tables_config.yaml
    # -----------------------------------------------------------------------
    cell3 = TABLES_CONFIG_LOAD

    # -----------------------------------------------------------------------
    # Cell 4: Input reads
    # -----------------------------------------------------------------------
    input_read_lines: List[str] = []
    for arg_name, rid in info.input_pairs:
        sanitized = sanitize_rid_key(rid)
        lookup_delta_path(rid, tables_config)  # triggers warning if missing
        # CI-3: RID annotation on separate comment line BEFORE the spark.read
        input_read_lines.append(f"# Original Foundry RID: {rid}")
        input_read_lines.append(
            f'{arg_name} = spark.read.format("delta").load(tables_config["tables"]["{sanitized}"]["delta_path"])'
        )
        input_read_lines.append("")

    cell4 = "\n".join(input_read_lines).rstrip()

    # -----------------------------------------------------------------------
    # Cell 5: Helper functions (module-level functions that are NOT any compute node)
    # -----------------------------------------------------------------------
    # Enhancement: exclude ALL @transform/@transform_df decorated functions, not just
    # the current one, so that sibling compute functions are not included as helpers.
    compute_names = {n.name for n in (all_compute_nodes or [compute_node])}
    helper_sources: List[str] = []
    for node in module.body:
        if isinstance(node, ast.FunctionDef) and node.name not in compute_names:
            helper_sources.append(get_source_segment(source_lines, node))

    cell5 = "\n\n".join(helper_sources) if helper_sources else ""

    # -----------------------------------------------------------------------
    # Cell 6: Transform logic (inlined compute() body)
    # -----------------------------------------------------------------------
    body_start = compute_node.body[0].lineno - 1  # type: ignore[attr-defined]
    body_end = compute_node.body[-1].end_lineno    # type: ignore[attr-defined]
    raw_body_lines = source_lines[body_start:body_end]
    body_lines = [line[4:] if line.startswith("    ") else line for line in raw_body_lines]

    if info.is_multi_output:
        body_lines = transform_multi_output_body(
            body_lines,
            info.output_pairs,
            info.input_pairs,
            tables_config,
        )
        cell6 = "\n".join(body_lines)
        cell7 = ""
    else:
        body_lines_no_return, result_var = process_transform_df_body(body_lines)
        cell6 = "\n".join(body_lines_no_return)

        # -----------------------------------------------------------------------
        # Cell 7: Output write (transform_df only)
        # -----------------------------------------------------------------------
        if info.output_rid:
            sanitized_out = sanitize_rid_key(info.output_rid)
            lookup_delta_path(info.output_rid, tables_config)  # triggers warning if missing
            write_lines = [
                f"# Original Foundry RID: {info.output_rid}",
                f'{result_var}.write.format("delta").mode("overwrite").save(tables_config["tables"]["{sanitized_out}"]["delta_path"])',
            ]
            cell7 = "\n".join(write_lines)
        else:
            cell7 = ""

    # -----------------------------------------------------------------------
    # Assemble notebook
    # -----------------------------------------------------------------------
    cells = [cell1, cell2, cell3]
    if cell4:
        cells.append(cell4)
    if cell5:
        cells.append(cell5)
    if cell6:
        cells.append(cell6)
    if cell7:
        cells.append(cell7)

    notebook_content = CELL_SEP.join(cells)

    if not notebook_content.startswith(NOTEBOOK_HEADER):
        notebook_content = NOTEBOOK_HEADER + "\n" + notebook_content

    if not notebook_content.endswith("\n"):
        notebook_content += "\n"

    return notebook_content


def _atomic_write(output_path: Path, content: str) -> bool:
    """Write content to output_path atomically via a .tmp file. Returns True on success."""
    tmp_path = output_path.with_suffix(".tmp")
    try:
        output_path.parent.mkdir(parents=True, exist_ok=True)
        tmp_path.write_text(content, encoding="utf-8")
        tmp_path.replace(output_path)
        return True
    except OSError as exc:
        logger.error("Failed to write %s: %s", output_path, exc)
        tmp_path.unlink(missing_ok=True)
        return False


def convert_file(
    entry: Dict[str, Any],
    tables_config: Dict[str, Any],
    output_dir: Path,
    project_root: Path,
    force: bool = False,
) -> Optional[Path]:
    """Convert a single transform_df source file to one or more Databricks notebooks.

    Files with a single @transform/@transform_df function produce one notebook named
    after the source file.  Files with multiple decorated functions (e.g.
    usa_states_and_zip_codes_geo_json.py) produce one notebook per function, named
    <stem>_<funcname>.py — no function is silently dropped.

    Returns the (first) output Path on success, None on failure.
    """
    source_path = Path(entry["path"])
    stem = source_path.stem

    # Read source
    try:
        source_text = source_path.read_text(encoding="utf-8")
    except OSError as exc:
        logger.error("Cannot read %s: %s", source_path, exc)
        return None

    source_lines = source_text.splitlines()

    # Parse AST
    try:
        module = ast.parse(source_text)
    except SyntaxError as exc:
        logger.error("ast.parse() failed for %s: %s", source_path, exc)
        return None

    # Enhancement: find ALL decorated functions, not just the first
    compute_nodes = find_compute_node(module)
    if not compute_nodes:
        logger.error("No compute() or @transform_df function found in %s", source_path)
        return None

    if len(compute_nodes) > 1:
        logger.warning(
            "%s contains %d @transform/@transform_df decorated functions (%s). "
            "Producing one notebook per function.",
            source_path.name,
            len(compute_nodes),
            ", ".join(n.name for n in compute_nodes),
        )

    # Determine _SPARK_OPTS variable (shared across all functions in the file)
    spark_opts_var = find_spark_opts_var(module)

    first_output_path: Optional[Path] = None

    for compute_node in compute_nodes:
        # Determine output notebook name
        if len(compute_nodes) == 1:
            output_notebook = entry.get("output_notebook", stem + ".py")
        else:
            # Multiple functions — suffix with function name to avoid collision
            output_notebook = f"{stem}_{compute_node.name}.py"

        output_path = output_dir / output_notebook

        # Idempotency check (per-notebook)
        if not force and output_path.exists():
            if output_path.stat().st_mtime >= source_path.stat().st_mtime:
                logger.info("SKIP %s (output is up to date)", output_notebook)
                if first_output_path is None:
                    first_output_path = output_path
                continue

        notebook_content = _build_notebook_for_compute(
            compute_node=compute_node,
            source_lines=source_lines,
            module=module,
            tables_config=tables_config,
            spark_opts_var=spark_opts_var,
            source_path=source_path,
            project_root=project_root,
            all_compute_nodes=compute_nodes,
        )

        if not _atomic_write(output_path, notebook_content):
            return None

        logger.info("Converted %s -> %s", source_path, output_path)
        if first_output_path is None:
            first_output_path = output_path

    return first_output_path


# ---------------------------------------------------------------------------
# Main entrypoint
# ---------------------------------------------------------------------------

def main() -> int:
    """Main entrypoint. Returns exit code (0=success, 1=failures)."""
    parser = argparse.ArgumentParser(
        description="Convert Palantir @transform_df files to Databricks PySpark notebooks."
    )
    parser.add_argument(
        "--manifest",
        default="scripts-output/manifest.yaml",
        help="Path to manifest.yaml (default: scripts-output/manifest.yaml)",
    )
    parser.add_argument(
        "--tables-config",
        default="scripts-output/output/config/tables_config.yaml",
        help="Path to tables_config.yaml",
    )
    parser.add_argument(
        "--output-dir",
        default="scripts-output/output/notebooks",
        help="Output directory for notebooks",
    )
    parser.add_argument(
        "--force",
        action="store_true",
        help="Re-convert even if output is newer than source",
    )
    parser.add_argument(
        "--file",
        help="Process only a single file (by filename, for debugging)",
    )
    args = parser.parse_args()

    # Resolve project root (two levels up from this script: agent-output/scripts/)
    project_root = Path(__file__).resolve().parent.parent.parent

    manifest_path = project_root / args.manifest
    tables_config_path = project_root / args.tables_config
    output_dir = project_root / args.output_dir

    # Dependency checks
    if not manifest_path.exists():
        logger.error(
            "manifest.yaml not found at %s — run scan_inputs.py first.", manifest_path
        )
        return 1
    if not tables_config_path.exists():
        logger.error(
            "tables_config.yaml not found at %s — run extract_rid_map.py first.",
            tables_config_path,
        )
        return 1

    # Load inputs
    try:
        manifest = yaml.safe_load(manifest_path.read_text(encoding="utf-8"))
    except (yaml.YAMLError, OSError) as exc:
        logger.error("Failed to load manifest.yaml: %s", exc)
        return 1

    try:
        tables_config = yaml.safe_load(tables_config_path.read_text(encoding="utf-8"))
    except (yaml.YAMLError, OSError) as exc:
        logger.error("Failed to load tables_config.yaml: %s", exc)
        return 1

    if not isinstance(manifest, list):
        # Support both list format and dict-with-files format
        manifest = manifest.get("files", manifest) if isinstance(manifest, dict) else []

    # Filter to transform_df entries
    entries = [
        e for e in manifest if isinstance(e, dict) and e.get("type") == "transform_df"
    ]

    if args.file:
        entries = [e for e in entries if Path(e.get("path", "")).name == args.file]
        if not entries:
            logger.error("No transform_df entry found for file: %s", args.file)
            return 1

    total = len(entries)
    if total == 0:
        logger.warning("No transform_df entries found in manifest.")
        return 0

    logger.info("Found %d transform_df file(s) to convert.", total)

    converted = 0
    skipped = 0
    failed = 0

    for i, entry in enumerate(entries, start=1):
        source_name = Path(entry.get("path", "unknown")).name
        logger.info("Converting %d/%d: %s", i, total, source_name)

        result = convert_file(
            entry=entry,
            tables_config=tables_config,
            output_dir=output_dir,
            project_root=project_root,
            force=args.force,
        )

        if result is None:
            failed += 1
        elif not args.force and result.stat().st_mtime < Path(entry["path"]).stat().st_mtime + 1:
            # Newly converted (not skipped)
            converted += 1
        else:
            converted += 1

    print(
        f"\nconvert_transforms complete: {converted} converted, {skipped} skipped, {failed} failed"
    )
    return 0 if failed == 0 else 1


if __name__ == "__main__":
    sys.exit(main())
