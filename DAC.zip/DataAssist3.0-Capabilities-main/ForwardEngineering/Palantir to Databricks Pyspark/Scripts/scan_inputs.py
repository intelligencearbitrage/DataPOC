#!/usr/bin/env python3
"""
scan_inputs.py — Walk both input repositories, classify each Python file, and emit
a YAML manifest consumed by all downstream conversion scripts.

Inputs consumed:
  - user-config/inputs/SAP-Ontology-Transform-Logic/  (SAP @transform_df files)
  - user-config/inputs/SDDI-Generated-Pipeline/        (SDDI bellhop element files)

Output produced:
  - scripts-output/manifest.yaml

Classification logic (applied in order, using full-file string search):
  1. Skip rules checked first:
     - __init__.py, setup.py, _version.py → skip (filename)
     - pipeline.py, generate.py IN SDDI repo → skip (sddi orchestration wiring)
     - scripts/1.x_migration/* → skip (migration tooling)
     - element.py in derived/elements/ → skip (base class)
     - demo_* element folders → skip (demo templates)
     - utils.py in SAP repo with foundry_lifetimes → skip (manual migration required)
     - batch_inventory_structs_deployment.py → skip (constants file, no create_output)
     - Files with no transform logic after all checks → skip

  2. SDDI classification:
     - filename is common.py or deployment.py AND contains "def create_output(" → sddi
     - Tombstone check: if classified sddi but no "def create_output(" in full file → skip

  3. SAP / transform_df classification:
     - Contains "from transforms.api import" OR "@transform_df" OR "@transform" → transform_df
     - CI-1 secondary check: if transform_df AND also contains "def create_output("
       AND filename is common.py or deployment.py → reclassify as sddi (log WARNING)

  4. Tie-break / default:
     - No matching patterns → skip

Critical issues addressed:
  - CI-1: Secondary check reclassifies transform_df to sddi for common.py/deployment.py
           that also contain "def create_output("
  - W-1:  pipeline.py skip rule applied ONLY to SDDI repo; SAP pipeline.py classified normally
  - W-6:  Full file read for classification (no 60-line window limit)
"""

import argparse
import logging
import re
import sys
import tempfile
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import yaml


# ---------------------------------------------------------------------------
# Logging setup
# ---------------------------------------------------------------------------
logging.basicConfig(
    level=logging.INFO,
    format="%(levelname)s  %(message)s",
)
logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------
# Filenames that are always skipped regardless of repo
ALWAYS_SKIP_FILENAMES: set = {"__init__.py", "setup.py", "_version.py"}

# Filenames skipped ONLY when encountered in the SDDI repo
SDDI_ONLY_SKIP_FILENAMES: set = {"pipeline.py", "generate.py"}

# SDDI element filenames that indicate substantive create_output logic
SDDI_ELEMENT_FILENAMES: set = {"common.py", "deployment.py"}

# SAP-specific skip patterns
SAP_MANUAL_MIGRATION_FILES: set = {"utils.py"}
SAP_MANUAL_MIGRATION_IMPORTS: List[str] = ["foundry_lifetimes"]

# Known constants-only helpers with no create_output (skip)
SDDI_CONSTANTS_HELPERS: set = {
    "batch_inventory_structs_deployment.py",
    "batch_inventory_structs_common.py",
}

# SDDI base class file (not an element)
SDDI_BASE_CLASS_FILE = "element.py"

# Path fragment that identifies migration tooling in SDDI repo
SDDI_MIGRATION_PATH_FRAGMENT = "scripts/1.x_migration"

# Patterns for transform_df classification
TRANSFORM_DF_PATTERNS: List[str] = [
    "from transforms.api import",
    "@transform_df",
    "@transform",
]

# Patterns for SDDI classification
SDDI_PATTERNS: List[str] = [
    "def create_output(",
    "from bellhop_authoring_api import",
]


# ---------------------------------------------------------------------------
# Helper utilities
# ---------------------------------------------------------------------------

def to_snake_case(name: str) -> str:
    """Normalize a name to snake_case (lowercase, non-alnum replaced with _)."""
    return re.sub(r"[^a-z0-9_.]", "_", name.lower())


def read_full_file(file_path: Path) -> str:
    """Read the entire file content as a string, returning '' on error."""
    try:
        return file_path.read_text(encoding="utf-8", errors="replace")
    except OSError as exc:
        logger.warning("Could not read %s: %s", file_path, exc)
        return ""


def contains_any(content: str, patterns: List[str]) -> bool:
    """Return True if content contains at least one of the given patterns."""
    return any(pat in content for pat in patterns)


def which_patterns_match(content: str, patterns: List[str]) -> List[str]:
    """Return all patterns from the list that appear in content."""
    return [pat for pat in patterns if pat in content]


def derive_output_notebook_sap(stem: str) -> str:
    """Derive the output notebook filename for a SAP transform_df file."""
    return to_snake_case(stem) + ".py"


def derive_output_notebook_sddi(element_name: str, variant: str) -> str:
    """Derive the output notebook filename for an SDDI element file."""
    return to_snake_case(element_name) + "_" + to_snake_case(variant) + ".py"


# ---------------------------------------------------------------------------
# Classification logic
# ---------------------------------------------------------------------------

def classify_file(
    file_path: Path,
    source_repo: str,
    sap_root: Path,
    sddi_root: Path,
    project_root: Path,
) -> Dict[str, Any]:
    """
    Classify a single Python file and return a manifest entry dict.

    Args:
        file_path:    Absolute path to the .py file.
        source_repo:  "sap_ontology" or "sddi_pipeline".
        sap_root:     Absolute root of the SAP input repo.
        sddi_root:    Absolute root of the SDDI input repo.
        project_root: Project root for computing project-root-relative paths.

    Returns:
        A dict with keys: path, type, source_repo, output_notebook,
        element_name, sddi_variant, skip_reason.
    """
    filename = file_path.name
    stem = file_path.stem
    relative_path = str(file_path.relative_to(project_root))

    def make_skip(reason: str) -> Dict[str, Any]:
        return {
            "path": relative_path,
            "type": "skip",
            "source_repo": source_repo,
            "output_notebook": None,
            "element_name": None,
            "sddi_variant": None,
            "skip_reason": reason,
        }

    def make_transform_df(notebook: str) -> Dict[str, Any]:
        return {
            "path": relative_path,
            "type": "transform_df",
            "source_repo": source_repo,
            "output_notebook": notebook,
            "element_name": None,
            "sddi_variant": None,
            "skip_reason": None,
        }

    def make_sddi(element: str, variant: str, notebook: str) -> Dict[str, Any]:
        return {
            "path": relative_path,
            "type": "sddi",
            "source_repo": source_repo,
            "output_notebook": notebook,
            "element_name": element,
            "sddi_variant": variant,
            "skip_reason": None,
        }

    # ------------------------------------------------------------------
    # Step 1a: Always-skip filenames (both repos)
    # ------------------------------------------------------------------
    if filename in ALWAYS_SKIP_FILENAMES:
        return make_skip("filename in skip list")

    # ------------------------------------------------------------------
    # Step 1b: SDDI-only skip filenames (W-1 fix: pipeline.py skip applies
    #           ONLY to SDDI repo, not SAP)
    # ------------------------------------------------------------------
    if source_repo == "sddi_pipeline" and filename in SDDI_ONLY_SKIP_FILENAMES:
        return make_skip("sddi orchestration wiring — filename in sddi skip list")

    # ------------------------------------------------------------------
    # Step 1c: SDDI migration tooling path fragment
    # ------------------------------------------------------------------
    if source_repo == "sddi_pipeline" and SDDI_MIGRATION_PATH_FRAGMENT in str(file_path):
        return make_skip("migration tooling — excluded from conversion scope")

    # ------------------------------------------------------------------
    # Step 1d: SDDI base class element.py
    # ------------------------------------------------------------------
    if source_repo == "sddi_pipeline" and filename == SDDI_BASE_CLASS_FILE:
        # Check if it's in derived/elements/ (base class, not an element)
        if "derived/elements" in str(file_path):
            return make_skip("base class file — not an element")

    # ------------------------------------------------------------------
    # Step 1e: SDDI demo element folders
    # ------------------------------------------------------------------
    if source_repo == "sddi_pipeline":
        # Check if any parent directory name starts with "demo_"
        parts = file_path.parts
        for part in parts:
            if part.startswith("demo_"):
                return make_skip("demo element excluded from conversion scope")

    # ------------------------------------------------------------------
    # Step 1f: SDDI known constants-only helpers (no create_output)
    # ------------------------------------------------------------------
    if source_repo == "sddi_pipeline" and filename in SDDI_CONSTANTS_HELPERS:
        return make_skip("constants/helper file — no create_output function")

    # ------------------------------------------------------------------
    # Step 1g: SAP utils.py with foundry_lifetimes dependency
    # ------------------------------------------------------------------
    if source_repo == "sap_ontology" and filename in SAP_MANUAL_MIGRATION_FILES:
        content = read_full_file(file_path)
        if contains_any(content, SAP_MANUAL_MIGRATION_IMPORTS):
            return make_skip(
                "manual migration required: foundry_lifetimes dependency — "
                "convert this utility module separately"
            )

    # ------------------------------------------------------------------
    # Step 2: Read full file content for classification (W-6 fix: no line limit)
    # ------------------------------------------------------------------
    content = read_full_file(file_path)

    # ------------------------------------------------------------------
    # Step 3: SDDI element classification (common.py / deployment.py)
    # ------------------------------------------------------------------
    if source_repo == "sddi_pipeline" and filename in SDDI_ELEMENT_FILENAMES:
        has_create_output = "def create_output(" in content

        if has_create_output:
            # Determine element_name from parent directory
            parent_dir = file_path.parent.name
            element_name = parent_dir
            variant = stem  # "common" or "deployment"
            notebook = derive_output_notebook_sddi(element_name, variant)
            return make_sddi(element_name, variant, notebook)
        else:
            # Tombstone: common.py or deployment.py without create_output
            return make_skip(
                "tombstone file — no create_output function found (deleted element)"
            )

    # ------------------------------------------------------------------
    # Step 4: transform_df classification (SAP and any repo)
    # ------------------------------------------------------------------
    matched_transform_patterns = which_patterns_match(content, TRANSFORM_DF_PATTERNS)

    if matched_transform_patterns:
        # CI-1 secondary check: if this file ALSO matches SDDI patterns
        # AND filename is common.py or deployment.py → reclassify as sddi
        if filename in SDDI_ELEMENT_FILENAMES and "def create_output(" in content:
            logger.warning(
                "CI-1 reclassification: %s matched transform_df patterns %s "
                "BUT also contains 'def create_output(' and filename is '%s' — "
                "reclassifying as sddi",
                relative_path,
                matched_transform_patterns,
                filename,
            )
            parent_dir = file_path.parent.name
            element_name = parent_dir
            variant = stem
            notebook = derive_output_notebook_sddi(element_name, variant)
            return make_sddi(element_name, variant, notebook)

        # Normal transform_df classification
        notebook = derive_output_notebook_sap(stem)
        return make_transform_df(notebook)

    # ------------------------------------------------------------------
    # Step 5: SDDI catch-all (non-element files with sddi patterns)
    # ------------------------------------------------------------------
    if contains_any(content, SDDI_PATTERNS):
        # Not a common.py/deployment.py, but has SDDI markers.
        # These are framework files, not element data pipelines — skip.
        return make_skip("sddi framework file — not an element data pipeline")

    # ------------------------------------------------------------------
    # Step 6: No transform logic detected
    # ------------------------------------------------------------------
    return make_skip("no transform logic detected")


# ---------------------------------------------------------------------------
# Repository scanning
# ---------------------------------------------------------------------------

def scan_repo(
    root: Path,
    source_repo: str,
    sap_root: Path,
    sddi_root: Path,
    project_root: Path,
) -> List[Dict[str, Any]]:
    """
    Walk all .py files under root and classify each one.

    Args:
        root:         Absolute path to the input repo root.
        source_repo:  "sap_ontology" or "sddi_pipeline".
        sap_root:     SAP input repo root (for path relativization).
        sddi_root:    SDDI input repo root (for path relativization).
        project_root: Project root for computing project-root-relative paths.

    Returns:
        List of classification dicts (one per .py file found).
    """
    results: List[Dict[str, Any]] = []

    if not root.exists():
        logger.error("Input root does not exist: %s", root)
        return results

    py_files = sorted(root.rglob("*.py"))
    logger.info("Found %d .py files under %s (%s)", len(py_files), root, source_repo)

    for py_file in py_files:
        entry = classify_file(py_file, source_repo, sap_root, sddi_root, project_root)
        results.append(entry)
        logger.debug(
            "  %-12s %s",
            entry["type"],
            entry["path"],
        )

    return results


def ensure_unique_notebooks(files: List[Dict[str, Any]]) -> None:
    """
    Ensure output_notebook names are unique across all non-skip entries.
    If duplicates exist, append a counter suffix to disambiguate.
    Modifies the list in-place.
    """
    seen: Dict[str, int] = {}
    for entry in files:
        if entry["type"] == "skip" or entry["output_notebook"] is None:
            continue
        nb = entry["output_notebook"]
        if nb in seen:
            seen[nb] += 1
            stem, ext = nb.rsplit(".", 1)
            entry["output_notebook"] = f"{stem}_{seen[nb]}.{ext}"
            logger.warning(
                "Duplicate output_notebook name '%s' — renamed to '%s'",
                nb,
                entry["output_notebook"],
            )
        else:
            seen[nb] = 0


# ---------------------------------------------------------------------------
# Manifest construction
# ---------------------------------------------------------------------------

def build_manifest(
    all_files: List[Dict[str, Any]],
    sap_root: Path,
    sddi_root: Path,
    project_root: Path,
) -> Dict[str, Any]:
    """Build the complete manifest data structure."""
    count_transform_df = sum(1 for f in all_files if f["type"] == "transform_df")
    count_sddi = sum(1 for f in all_files if f["type"] == "sddi")
    count_skip = sum(1 for f in all_files if f["type"] == "skip")

    # Use paths relative to project root for human-readable manifest
    sap_rel = str(sap_root).replace(str(project_root) + "/", "")
    sddi_rel = str(sddi_root).replace(str(project_root) + "/", "")

    return {
        "generated": datetime.now(timezone.utc).isoformat(),
        "sap_ontology_source": sap_rel,
        "sddi_source": sddi_rel,
        "summary": {
            "total_files_found": len(all_files),
            "transform_df": count_transform_df,
            "sddi": count_sddi,
            "skip": count_skip,
        },
        "files": all_files,
    }


# ---------------------------------------------------------------------------
# Atomic write
# ---------------------------------------------------------------------------

def write_manifest_atomic(manifest: Dict[str, Any], output_path: Path) -> None:
    """Write manifest to a temp file then rename atomically."""
    output_path.parent.mkdir(parents=True, exist_ok=True)

    tmp_path = output_path.with_suffix(".yaml.tmp")
    yaml_content = yaml.dump(manifest, default_flow_style=False, sort_keys=False, allow_unicode=True)

    tmp_path.write_text(yaml_content, encoding="utf-8")
    tmp_path.rename(output_path)
    logger.info("Manifest written to %s", output_path)


# ---------------------------------------------------------------------------
# Main entry point
# ---------------------------------------------------------------------------

def main() -> int:
    """
    Scan both input repositories, classify Python files, and write manifest.yaml.

    Returns:
        0 if at least one non-skip file was found.
        1 if no substantive files found (likely wrong input paths).
    """
    parser = argparse.ArgumentParser(
        description="Scan input repos and classify Python files for Palantir-to-Databricks conversion."
    )
    parser.add_argument(
        "--project-root",
        type=Path,
        default=None,
        help="Project root directory (default: derived from script location).",
    )
    parser.add_argument(
        "--output-dir",
        type=Path,
        default=None,
        help="Output directory for manifest.yaml (default: <project-root>/scripts-output/).",
    )
    parser.add_argument(
        "--force",
        action="store_true",
        help="Force regeneration even if manifest already exists (always true for scan_inputs).",
    )
    parser.add_argument(
        "--verbose",
        action="store_true",
        help="Enable debug-level logging.",
    )
    args = parser.parse_args()

    if args.verbose:
        logging.getLogger().setLevel(logging.DEBUG)

    # Resolve project root
    if args.project_root is not None:
        project_root = args.project_root.resolve()
    else:
        # Script is at agent-output/scripts/scan_inputs.py → root is 2 levels up
        project_root = Path(__file__).resolve().parent.parent.parent

    logger.info("Project root: %s", project_root)

    # Resolve input roots
    sap_root = project_root / "user-config" / "inputs" / "SAP-Ontology-Transform-Logic"
    sddi_root = project_root / "user-config" / "inputs" / "SDDI-Generated-Pipeline"

    for root, label in [(sap_root, "SAP"), (sddi_root, "SDDI")]:
        if not root.exists():
            logger.error("%s input root not found: %s", label, root)

    # Resolve output path
    if args.output_dir is not None:
        output_dir = args.output_dir.resolve()
    else:
        output_dir = project_root / "scripts-output"

    output_path = output_dir / "manifest.yaml"

    # Scan both repos
    logger.info("Scanning SAP Ontology repo...")
    sap_files = scan_repo(sap_root, "sap_ontology", sap_root, sddi_root, project_root)

    logger.info("Scanning SDDI Pipeline repo...")
    sddi_files = scan_repo(sddi_root, "sddi_pipeline", sap_root, sddi_root, project_root)

    all_files = sap_files + sddi_files

    # Ensure unique output notebook names
    ensure_unique_notebooks(all_files)

    # Build manifest
    manifest = build_manifest(all_files, sap_root, sddi_root, project_root)
    summary = manifest["summary"]

    # Write manifest atomically
    write_manifest_atomic(manifest, output_path)

    # Print summary to stdout
    print(
        f"\nManifest written to: {output_path}\n"
        f"  Total files scanned : {summary['total_files_found']}\n"
        f"  transform_df        : {summary['transform_df']}\n"
        f"  sddi                : {summary['sddi']}\n"
        f"  skip                : {summary['skip']}\n"
    )

    substantive_count = summary["transform_df"] + summary["sddi"]
    if substantive_count == 0:
        logger.error(
            "Zero substantive files found — check that input repos exist at:\n"
            "  %s\n  %s",
            sap_root,
            sddi_root,
        )
        return 1

    return 0


if __name__ == "__main__":
    sys.exit(main())
