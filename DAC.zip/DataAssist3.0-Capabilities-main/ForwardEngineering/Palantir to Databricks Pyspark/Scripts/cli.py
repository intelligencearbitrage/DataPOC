#!/usr/bin/env python3
"""CLI entry point for the Palantir-to-Databricks conversion pipeline.

Usage:
    python cli.py all              # Run full pipeline
    python cli.py scan_inputs      # Run scan_inputs.py only
    python cli.py extract_rid_map  # Run extract_rid_map.py only
    python cli.py convert_transforms  # Run convert_transforms.py only
    python cli.py convert_sddi     # Run convert_sddi.py only
    python cli.py validate_outputs # Run validate_outputs.py only
    python cli.py run_pipeline     # Run full orchestrated pipeline
"""
import subprocess
import sys
from pathlib import Path

SCRIPTS_DIR = Path(__file__).parent
SCRIPTS = {
    "scan_inputs": SCRIPTS_DIR / "scan_inputs.py",
    "extract_rid_map": SCRIPTS_DIR / "extract_rid_map.py",
    "convert_transforms": SCRIPTS_DIR / "convert_transforms.py",
    "convert_sddi": SCRIPTS_DIR / "convert_sddi.py",
    "validate_outputs": SCRIPTS_DIR / "validate_outputs.py",
    "run_pipeline": SCRIPTS_DIR / "run_pipeline.py",
}


def main() -> None:
    if len(sys.argv) < 2:
        print(__doc__)
        sys.exit(1)
    command = sys.argv[1]
    extra_args = sys.argv[2:]
    if command == "all":
        result = subprocess.run([sys.executable, str(SCRIPTS["run_pipeline"])] + extra_args)
        sys.exit(result.returncode)
    elif command in SCRIPTS:
        result = subprocess.run([sys.executable, str(SCRIPTS[command])] + extra_args)
        sys.exit(result.returncode)
    else:
        print(f"Unknown command: {command}")
        print(f"Available commands: all, {', '.join(SCRIPTS.keys())}")
        sys.exit(1)


if __name__ == "__main__":
    main()
