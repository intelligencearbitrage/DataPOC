# Palantir-to-Databricks PySpark Conversion Pipeline

Re-runnable Python pipeline that converts Palantir Foundry Transforms Python scripts to Databricks PySpark notebooks.

## Quick Start

Run the full pipeline:
```bash
python agent-output/scripts/cli.py all
```

Or use the orchestrator directly:
```bash
python agent-output/scripts/run_pipeline.py
python agent-output/scripts/run_pipeline.py --force  # re-run even if up-to-date
```

## Individual Scripts

| Script | Command | Description |
|--------|---------|-------------|
| `scan_inputs.py` | `python cli.py scan_inputs` | Walk input repos, classify files, write manifest |
| `extract_rid_map.py` | `python cli.py extract_rid_map` | Extract RIDs, generate tables_config.yaml |
| `convert_transforms.py` | `python cli.py convert_transforms` | Convert @transform_df files to notebooks |
| `convert_sddi.py` | `python cli.py convert_sddi` | Convert SDDI create_output() files to notebooks |
| `validate_outputs.py` | `python cli.py validate_outputs` | Validate all output notebooks |
| `run_pipeline.py` | `python cli.py run_pipeline` | Full orchestrated pipeline |

## Outputs

- `scripts-output/manifest.yaml` — file classification manifest
- `scripts-output/output/config/tables_config.yaml` — RID-to-Delta path mapping (edit delta_path values)
- `scripts-output/output/notebooks/` — converted Databricks .py notebooks
- `scripts-output/output/validation_report.yaml` — validation results

## After Running

1. Edit `scripts-output/output/config/tables_config.yaml` — replace `/mnt/delta/...` placeholder paths with real Delta table paths for your environment
2. Upload notebooks from `scripts-output/output/notebooks/` to Databricks workspace
3. Runtime correctness requires Databricks cluster testing — static validation only is performed locally

## Requirements

- Python 3.8+
- pyyaml
