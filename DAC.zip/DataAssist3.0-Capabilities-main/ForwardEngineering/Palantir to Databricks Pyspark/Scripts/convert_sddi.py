#!/usr/bin/env python3
"""Convert SDDI bellhop create_output() Python files to Databricks PySpark notebooks.

Reads:
  - scripts-output/manifest.yaml (filter: type=sddi)
  - scripts-output/output/config/tables_config.yaml (SDDI table key-to-Delta-path mapping)
  - user-config/inputs/SDDI-Generated-Pipeline/ (source .py files)

Writes:
  - scripts-output/output/notebooks/<output_notebook>  — one .py Databricks notebook per SDDI source file

Algorithm:
  1. Parse manifest.yaml, filter entries where type == "sddi"
  2. Load tables_config.yaml
  3. For each entry: parse source AST, extract create_output() body, inject PySpark
     notebook cells (imports, tables_config load, spark.read for inputs, inlined body,
     Delta write for output)
  4. Write atomically (tmp → rename)
  5. Print summary

CI-2: uses sddi_tables short keys when accessing tables_config (not RID-keyed SAP section).
CI-3: RID references placed on a SEPARATE comment line before spark.read, not inline.
W-3:  every output notebook has >= 3 "# COMMAND ----------" separators.
"""

from __future__ import annotations

import argparse
import ast
import logging
import os
import re
import sys
import textwrap
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import yaml

# ---------------------------------------------------------------------------
# Logging
# ---------------------------------------------------------------------------
logging.basicConfig(
    level=logging.INFO,
    format="%(levelname)s %(message)s",
)
logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------
PROJECT_ROOT = Path(__file__).resolve().parent.parent.parent

MANIFEST_PATH = PROJECT_ROOT / "scripts-output" / "manifest.yaml"
TABLES_CONFIG_PATH = (
    PROJECT_ROOT / "scripts-output" / "output" / "config" / "tables_config.yaml"
)
OUTPUT_DIR = PROJECT_ROOT / "scripts-output" / "output" / "notebooks"

COMMAND_SEP = "# COMMAND ----------"

# Imports to inject at the top of every converted notebook
PYSPARK_IMPORTS = """\
from pyspark.sql import SparkSession
from pyspark.sql import functions as F
from pyspark.sql.types import *
import yaml
from pathlib import Path
spark = SparkSession.builder.getOrCreate()"""

TABLES_CONFIG_LOAD = """\
tables_config = yaml.safe_load(Path("scripts-output/output/config/tables_config.yaml").read_text())"""

# Bellhop / SDI import prefixes that must be stripped
STRIP_IMPORT_PREFIXES = (
    "bellhop_authoring_api",
    "software_defined_integrations",
    "transforms.api",
    "transforms.expectations",
    "transforms",
    "conjure_python_client",
)

# Utility helpers to inline when referenced in the source file
GET_FOREIGN_KEYS_IMPL = """\
def get_foreign_keys(table):
    \"\"\"Return columns whose name contains '_|_foreign_key_'.\"\"\"
    return [col for col in table.columns if '_|_foreign_key_' in col]"""

ENRICH_TABLE_IMPL = """\
def enrich_table_without_base_table_fkeys(base_table, enrich_table):
    \"\"\"Drop foreign-key columns present in base_table from enrich_table.\"\"\"
    return enrich_table.drop(*get_foreign_keys(base_table))"""

COLUMN_DELIMITER_DEF = "COLUMN_DELIMITER = '_|_'"
CONCAT_WS_IMPL = """\
def concat_ws_with_nulls(delimiter, *columns):
    \"\"\"concat_ws that returns NULL when all input columns are NULL.\"\"\"
    return (
        F.when(F.concat(*[F.col(c) if isinstance(c, str) else c for c in columns]).isNull(), F.lit(None))
        .otherwise(F.concat_ws(delimiter, *[F.col(c) if isinstance(c, str) else c for c in columns]))
    )"""

# BATCH_STOCK_COLS constant (from .batch_inventory_structs_deployment)
BATCH_STOCK_COLS_DEF = """\
BATCH_STOCK_COLS = [
    "mandt_matnr_werks_charg_|_foreign_key_MCHA",
    "mandt_matnr_charg_|_foreign_key_MCH1",
    "mandt_matnr_|_foreign_key_MARA",
    "mandt_werks_|_foreign_key_T001W",
    "stock_deletion_flag_|_lvorm",
]  # Inlined from batch_inventory_structs_deployment"""

# ---------------------------------------------------------------------------
# Additional SDI utility function implementations (Fix FAIL-1)
# ---------------------------------------------------------------------------

# bom_header_primary_key_base constant (from bill_of_materials_structs_deployment)
BOM_HEADER_PRIMARY_KEY_BASE_DEF = """\
bom_header_primary_key_base = [
    "source",
    "client_|_mandt",
    "bom_category_|_stlty",
    "bill_of_material_|_stlnr",
    "alternative_bom_|_stlal",
]  # Inlined from bill_of_materials_structs_deployment"""

# mast_join_fields constant (from bill_of_materials_structs_deployment)
MAST_JOIN_FIELDS_DEF = """\
mast_join_fields = [
    "source",
    "client_|_mandt",
    "bill_of_material_|_stlnr",
    "alternative_bom_|_stlal",
]  # Inlined from bill_of_materials_structs_deployment"""

# osi_pi_derive_series_id — inlined from utils.py (no external dependencies)
OSI_PI_DERIVE_SERIES_ID_IMPL = """\
def osi_pi_derive_series_id(path_column):
    \"\"\"OsiPi specific function deriving the timeseries series_id.\"\"\"
    regexpr = r"^.*\\\\(.*)\\\\(.*?)\\|(.*)$"
    location = F.regexp_extract(path_column, regexpr, 1)
    equipment = F.regexp_extract(path_column, regexpr, 2)
    attribute = F.regexp_extract(path_column, regexpr, 3)
    series_id = F.concat_ws(".", location, equipment, attribute)
    series_id = F.regexp_replace(series_id, r" ", "_")
    return series_id"""

# osi_pi_derive_path_segments — inlined from utils.py (no external dependencies)
OSI_PI_DERIVE_PATH_SEGMENTS_IMPL = """\
def osi_pi_derive_path_segments(path_column):
    \"\"\"OsiPi specific function splitting OsiPi path into an array of segments.\"\"\"
    path_segments = F.regexp_extract(path_column, r"^\\\\\\\\(.*)\\|.*?$", 1)
    path_segments = F.split(path_segments, r"\\\\")
    return path_segments"""

# osi_pi_rename_common_columns — inlined from utils.py (no external dependencies)
OSI_PI_RENAME_COMMON_COLUMNS_IMPL = """\
def osi_pi_rename_common_columns(pi_metadata_df):
    \"\"\"OsiPi specific renaming of columns preprocessed by OsiPi preprocessor.\"\"\"
    columns = pi_metadata_df.columns
    for column in columns:
        pi_metadata_df = pi_metadata_df.withColumnRenamed(column, column.split("_|_")[0])
    pi_metadata_df = pi_metadata_df.withColumnRenamed("webid", "web_id")
    pi_metadata_df = pi_metadata_df.withColumnRenamed("haschildren", "has_children")
    pi_metadata_df = pi_metadata_df.withColumnRenamed("templatename", "template_name")
    pi_metadata_df = pi_metadata_df.withColumnRenamed("entitytype", "entity_type")
    pi_metadata_df = pi_metadata_df.withColumnRenamed("parentwebid", "foreign_key_osi_pi_element")
    return pi_metadata_df"""

# osi_pi_process_attributes — inlined from utils.py (depends on osi_pi_rename_common_columns
# and osi_pi_derive_path_segments, so include all three together when this is needed)
OSI_PI_PROCESS_ATTRIBUTES_IMPL = """\
def osi_pi_process_attributes(pi_metadata_df, process_as_enum):
    \"\"\"OsiPi specific logic which creates the Attribute datasets from a OsiPiMetadataSync.\"\"\"
    pi_metadata_df = osi_pi_rename_common_columns(pi_metadata_df)
    attributes = pi_metadata_df.filter(F.col("entity_type").eqNullSafe("attribute"))
    attributes = attributes.withColumn(
        "is_enum",
        F.when(F.col("type").eqNullSafe("EnumerationValue"), F.lit(True)).otherwise(F.lit(False)),
    )
    attributes = attributes.filter(F.col("is_enum") == process_as_enum)
    attributes = attributes.withColumn("series_id", F.col("web_id"))
    attributes = attributes.withColumn("primary_key", F.col("series_id"))
    attributes = attributes.withColumn("path_segments", osi_pi_derive_path_segments(F.col("path")))
    if "unit" not in attributes.columns:
        attributes = attributes.withColumn("unit", F.lit(None).cast("string"))
    attributes = attributes.withColumn("title", F.col("name"))
    return attributes"""

# get_foreign_keys_to_foreign_table — inlined from utils.py (depends on is_foreign_key_for_table)
GET_FOREIGN_KEYS_TO_FOREIGN_TABLE_IMPL = """\
def is_foreign_key_for_table(column, foreign_table):
    \"\"\"Return True if column is a foreign key referencing foreign_table.\"\"\"
    split_column = column.split("foreign_key_")
    return len(split_column) > 1 and split_column[1].startswith(foreign_table)

def get_foreign_keys_to_foreign_table(table, foreign_table):
    \"\"\"Return columns that are foreign keys referencing a specific foreign table.\"\"\"
    return [column for column in table.columns if is_foreign_key_for_table(column, foreign_table)]"""

# coalesce_join — inlined from utils.py (depends on get_type_matching_column_subset)
# NOTE: Uses transforms.verbs.dataframes (D.map_columns) — not directly available.
# combine_timestamp uses D.map_columns, so we generate a TODO stub for it.
COALESCE_JOIN_IMPL = """\
def _get_type_matching_column_subset(df_left, df_right):
    \"\"\"Return columns present in both dataframes with the same type.\"\"\"
    left_col_to_type = {col: typ for col, typ in df_left.dtypes}
    right_col_to_type = {col: typ for col, typ in df_right.dtypes}
    return [
        column_type[0]
        for column_type in left_col_to_type.items() & right_col_to_type.items()
    ]

def coalesce_join(df_left, df_right, on, how):
    \"\"\"Join two tables, coalescing duplicate columns left-to-right.\"\"\"
    subset = _get_type_matching_column_subset(df_left, df_right)
    on = [on] if isinstance(on, str) else on
    subset = set(subset) - set(on)
    for c in subset:
        df_right = df_right.withColumnRenamed(c, f"DUPLICATE_{c}")
    df = df_left.join(df_right, on, how)
    for c in subset:
        df = df.withColumn(c, F.coalesce(c, f"DUPLICATE_{c}"))
        df = df.drop(f"DUPLICATE_{c}")
    return df"""

# combine_timestamp uses transforms.verbs.dataframes.D.map_columns — generate TODO stub
COMBINE_TIMESTAMP_TODO = """\
# TODO: combine_timestamp was imported from software_defined_integrations.derived.utils.utils
# Original import: from software_defined_integrations.derived.utils.utils import combine_timestamp
# The original implementation uses transforms.verbs.dataframes.D.map_columns which is Foundry-specific.
# Provide a Databricks-compatible implementation:
def combine_timestamp(dataframe, date_column_name, time_column_name, assembled_column_name):
    \"\"\"Combine date and time columns into a single timestamp column.\"\"\"
    from pyspark.sql.types import StringType
    TIME_PATTERN = r"^([0-9]{2})([0-9]{2})([0-9]{2})$"
    df = dataframe.withColumn(
        "_padded_time_string_column",
        F.lpad(F.col(time_column_name).cast(StringType()), 6, "0"),
    )
    for part, group in [("_hours", 1), ("_minutes", 2), ("_seconds", 3)]:
        df = df.withColumn(part, F.regexp_extract(F.col("_padded_time_string_column"), TIME_PATTERN, group))
    df = df.drop("_padded_time_string_column")
    for part in ["_hours", "_minutes", "_seconds"]:
        df = df.withColumn(part, F.when((F.col(part).isNull()) | (F.col(part) == ""), F.lit("00")).otherwise(F.col(part)))
    # If Hour is 24, increment date by 1 day and reset hour to 00
    df = df.withColumn(
        date_column_name,
        F.when(F.col("_hours") == "24", F.date_add(F.col(date_column_name), 1)).otherwise(F.col(date_column_name))
    )
    df = df.withColumn("_hours", F.when(F.col("_hours") == "24", F.lit("00")).otherwise(F.col("_hours")))
    df = df.withColumn(
        assembled_column_name,
        F.to_timestamp(F.concat(
            F.col(date_column_name).cast(StringType()), F.lit(" "),
            F.col("_hours"), F.lit(":"), F.col("_minutes"), F.lit(":"), F.col("_seconds"), F.lit(".000"),
        )),
    )
    df = df.drop("_hours", "_minutes", "_seconds", date_column_name, time_column_name)
    return df"""

# Registry: symbol name → (implementation_string, dependencies)
# dependencies lists OTHER symbols from this registry that must also be inlined
INLINED_HELPERS: Dict[str, str] = {
    "get_foreign_keys": GET_FOREIGN_KEYS_IMPL,
    "enrich_table_without_base_table_fkeys": ENRICH_TABLE_IMPL,
    "concat_ws_with_nulls": CONCAT_WS_IMPL,
    "BATCH_STOCK_COLS": BATCH_STOCK_COLS_DEF,
    "bom_header_primary_key_base": BOM_HEADER_PRIMARY_KEY_BASE_DEF,
    "mast_join_fields": MAST_JOIN_FIELDS_DEF,
    "osi_pi_derive_series_id": OSI_PI_DERIVE_SERIES_ID_IMPL,
    "osi_pi_derive_path_segments": OSI_PI_DERIVE_PATH_SEGMENTS_IMPL,
    "osi_pi_rename_common_columns": OSI_PI_RENAME_COMMON_COLUMNS_IMPL,
    "osi_pi_process_attributes": OSI_PI_PROCESS_ATTRIBUTES_IMPL,
    "get_foreign_keys_to_foreign_table": GET_FOREIGN_KEYS_TO_FOREIGN_TABLE_IMPL,
    "coalesce_join": COALESCE_JOIN_IMPL,
    "combine_timestamp": COMBINE_TIMESTAMP_TODO,
}

# For osi_pi_process_attributes: inlining it also requires osi_pi_rename_common_columns
# and osi_pi_derive_path_segments (handled by checking each separately)


# ---------------------------------------------------------------------------
# AST helpers
# ---------------------------------------------------------------------------

def _get_subscript_string_key(node: ast.Subscript) -> Optional[str]:
    """Return the string key from a Subscript node (e.g., d["key"] → "key")."""
    sl = node.slice
    # Python 3.8 wraps slice in ast.Index; 3.9+ exposes value directly
    if isinstance(sl, ast.Index):
        sl = sl.value  # type: ignore[attr-defined]
    if isinstance(sl, ast.Constant) and isinstance(sl.value, str):
        return sl.value
    if isinstance(sl, ast.Str):  # legacy
        return sl.s
    return None


def _is_subscript_on(node: ast.AST, var_name: str) -> bool:
    """Return True if node is a Subscript of ast.Name(id=var_name)."""
    return (
        isinstance(node, ast.Subscript)
        and isinstance(node.value, ast.Name)
        and node.value.id == var_name
    )


def _is_call_attr_on(node: ast.AST, var_name: str, attr_name: str) -> bool:
    """Return True if node is <var_name>.<attr_name>(...) call."""
    return (
        isinstance(node, ast.Call)
        and isinstance(node.func, ast.Attribute)
        and node.func.attr == attr_name
        and isinstance(node.func.value, ast.Name)
        and node.func.value.id == var_name
    )


def _source_uses(source_text: str, name: str) -> bool:
    """Quick string-based check for whether a name is referenced in source."""
    return name in source_text


# ---------------------------------------------------------------------------
# Import stripping
# ---------------------------------------------------------------------------

def _strip_imports(source_lines: List[str]) -> Tuple[List[str], List[str]]:
    """
    Remove bellhop/SDI/transforms/conjure imports and relative imports.
    Returns (kept_lines, stripped_lines).
    Also removes 'from .something import ...' relative imports.
    """
    kept: List[str] = []
    stripped: List[str] = []
    skip_continuation = False
    for line in source_lines:
        stripped_line = line.lstrip()

        # Handle multi-line import continuation
        if skip_continuation:
            stripped.append(line)
            if not line.rstrip().endswith("\\") and ")" not in line:
                # check if we've closed the paren
                skip_continuation = ")" not in line
            else:
                skip_continuation = ")" not in line
            continue

        # Relative import (from .something import ...)
        if stripped_line.startswith("from ."):
            stripped.append(line)
            if line.rstrip().endswith("(") or line.rstrip().endswith("\\"):
                skip_continuation = True
            continue

        # Check against strip prefixes
        is_strip = False
        for prefix in STRIP_IMPORT_PREFIXES:
            if stripped_line.startswith(f"from {prefix}") or stripped_line.startswith(
                f"import {prefix}"
            ):
                is_strip = True
                break

        if is_strip:
            stripped.append(line)
            if line.rstrip().endswith("(") or line.rstrip().endswith("\\"):
                skip_continuation = True
        else:
            kept.append(line)

    return kept, stripped


def _collect_clean_imports(source_lines: List[str]) -> List[str]:
    """
    From kept import lines, return only the ones that are actual import statements,
    but skip duplicates of the PYSPARK_IMPORTS we inject.
    Handles multi-line imports (parenthesised or backslash-continued).
    """
    auto_injected = {
        "from pyspark.sql import SparkSession",
        "from pyspark.sql import functions as F",
        "from pyspark.sql.types import *",
        "import yaml",
        "from pathlib import Path",
    }
    result: List[str] = []
    kept, _ = _strip_imports(source_lines)
    in_continuation = False
    paren_depth = 0
    for line in kept:
        stripped = line.strip()

        if in_continuation:
            result.append(line.rstrip())
            paren_depth += stripped.count("(") - stripped.count(")")
            if paren_depth <= 0 and not line.rstrip().endswith("\\"):
                in_continuation = False
                paren_depth = 0
            continue

        if not stripped or stripped.startswith("#"):
            continue
        is_import = stripped.startswith("import ") or stripped.startswith("from ")
        if not is_import:
            continue
        # Skip if it's one of our auto-injected imports
        if any(stripped.startswith(inj) for inj in auto_injected):
            continue
        result.append(line.rstrip())
        # Start tracking multi-line continuation
        paren_depth = stripped.count("(") - stripped.count(")")
        if paren_depth > 0 or line.rstrip().endswith("\\"):
            in_continuation = True

    return result


# ---------------------------------------------------------------------------
# find create_output in AST
# ---------------------------------------------------------------------------

def _find_create_output(tree: ast.Module) -> Optional[ast.FunctionDef]:
    """Return the top-level create_output FunctionDef, or None."""
    for node in ast.walk(tree):
        if isinstance(node, ast.FunctionDef) and node.name == "create_output":
            return node
    return None


def _detect_signature_variant(func_def: ast.FunctionDef) -> str:
    """
    Detect signature variant:
      4 args → 'common'  (_ctx, preprocessed_input_dfs, workflow_variables, _workflow_enrichments)
      5 args → 'deployment' (ctx, output_df, preprocessed_input_dfs, workflow_variables, workflow_enrichments)
    Returns 'common' or 'deployment'.
    """
    n = len(func_def.args.args)
    if n == 5:
        return "deployment"
    return "common"


def _enrichments_active(func_def: ast.FunctionDef) -> bool:
    """
    For 4-arg common.py: if the 4th arg (index 3) starts with '_', enrichments are inactive.
    """
    args = func_def.args.args
    if len(args) < 4:
        return False
    fourth_arg = args[3].arg
    return not fourth_arg.startswith("_")


def _workflow_variables_active(func_def: ast.FunctionDef) -> bool:
    """
    For 4-arg common.py: if the 3rd arg (index 2) starts with '_', workflow_variables inactive.
    """
    args = func_def.args.args
    if len(args) < 3:
        return False
    third_arg = args[2].arg
    return not third_arg.startswith("_")


# ---------------------------------------------------------------------------
# Extract preprocessed_input_dfs accesses
# ---------------------------------------------------------------------------

def _extract_input_df_pairs(
    func_def: ast.FunctionDef, source_lines: List[str]
) -> List[Tuple[str, str]]:
    """
    Walk the create_output() body and find all assignments where:
      var_name = preprocessed_input_dfs["key"]

    Returns list of (var_name, sddi_key) preserving order of first occurrence.
    """
    pairs: List[Tuple[str, str]] = []
    seen_keys: set = set()

    for node in ast.walk(func_def):
        if isinstance(node, ast.Assign):
            # Check for single-target assignment
            if (
                len(node.targets) == 1
                and isinstance(node.targets[0], ast.Name)
                and _is_subscript_on(node.value, "preprocessed_input_dfs")
            ):
                key = _get_subscript_string_key(node.value)
                if key is not None:
                    var_name = node.targets[0].id
                    entry = (var_name, key)
                    if entry not in pairs:
                        pairs.append(entry)
                    seen_keys.add(key)

    return pairs


def _extract_all_input_df_keys(func_def: ast.FunctionDef) -> List[str]:
    """
    Collect ALL distinct sddi_key values from preprocessed_input_dfs["key"] accesses.
    Used to ensure all reads are generated even when not directly assigned at top-level.
    """
    keys: List[str] = []
    seen: set = set()
    for node in ast.walk(func_def):
        if _is_subscript_on(node, "preprocessed_input_dfs"):
            key = _get_subscript_string_key(node)  # type: ignore[arg-type]
            if key is not None and key not in seen:
                seen.add(key)
                keys.append(key)
    return keys


# ---------------------------------------------------------------------------
# Extract workflow_variables accesses
# ---------------------------------------------------------------------------

def _get_wv_get_key(node: ast.AST) -> Optional[str]:
    """
    If node is workflow_variables.get("key") or workflow_variables.get("key", default),
    return the string key. Otherwise return None.
    """
    if not _is_call_attr_on(node, "workflow_variables", "get"):
        return None
    call_args = node.args  # type: ignore[attr-defined]
    if not call_args:
        return None
    first_arg = call_args[0]
    if isinstance(first_arg, ast.Constant) and isinstance(first_arg.value, str):
        return first_arg.value
    if isinstance(first_arg, ast.Str):  # legacy
        return first_arg.s
    return None


def _extract_workflow_variable_pairs(
    func_def: ast.FunctionDef,
) -> List[Tuple[str, str]]:
    """
    Walk create_output() body and find:
      var = workflow_variables["key"]
      var = workflow_variables.get("key", ...)
      if workflow_variables.get("key"):   ← non-assignment context (Fix FAIL-2a)
    Returns list of (var_name, param_key).

    For non-assignment contexts (if-statements, function args), a synthetic var_name
    is generated as "<key>_flag" so the caller can substitute the reference.
    """
    pairs: List[Tuple[str, str]] = []
    seen: set = set()

    for node in ast.walk(func_def):
        if isinstance(node, ast.Assign) and len(node.targets) == 1:
            target = node.targets[0]
            if not isinstance(target, ast.Name):
                continue
            val = node.value
            # Direct subscript: workflow_variables["key"]
            if _is_subscript_on(val, "workflow_variables"):
                key = _get_subscript_string_key(val)
                if key and (target.id, key) not in seen:
                    pairs.append((target.id, key))
                    seen.add((target.id, key))
            # .get() call: workflow_variables.get("key")
            elif _is_call_attr_on(val, "workflow_variables", "get"):
                key = _get_wv_get_key(val)
                if key and (target.id, key) not in seen:
                    pairs.append((target.id, key))
                    seen.add((target.id, key))

    # Enhancement: detect workflow_variables.get() in non-assignment contexts (Fix FAIL-2a)
    # Walk all AST nodes; for any workflow_variables.get("key") that is NOT the RHS of an
    # assignment already captured above, generate a synthetic "<key>_flag" variable.
    assigned_keys: set = {k for _, k in pairs}
    for node in ast.walk(func_def):
        # Check if this node is a workflow_variables.get() call
        key = _get_wv_get_key(node)
        if key is not None and key not in assigned_keys:
            var_name = f"{key}_flag"
            if (var_name, key) not in seen:
                pairs.append((var_name, key))
                seen.add((var_name, key))
                assigned_keys.add(key)

    return pairs


# ---------------------------------------------------------------------------
# Extract module-level helper functions (not create_output)
# ---------------------------------------------------------------------------

def _extract_helper_functions(
    tree: ast.Module, source_lines: List[str]
) -> List[str]:
    """
    Return source text of module-level functions that are NOT create_output.
    """
    helpers: List[str] = []
    for node in tree.body:
        if isinstance(node, ast.FunctionDef) and node.name != "create_output":
            # Extract lines for this function
            start = node.lineno - 1  # 0-indexed
            end = node.end_lineno  # type: ignore[attr-defined]
            func_lines = source_lines[start:end]
            helpers.append("\n".join(line.rstrip() for line in func_lines))
    return helpers


# ---------------------------------------------------------------------------
# Extract create_output body
# ---------------------------------------------------------------------------

def _get_return_ranges(func_def: ast.FunctionDef) -> List[Tuple[int, int]]:
    """
    Return (rel_start, rel_end_exclusive) index ranges for all Return nodes in
    func_def that are NOT inside nested FunctionDef/AsyncFunctionDef/Lambda nodes.
    Indices are 0-based relative to body[0].lineno.
    """
    if not func_def.body:
        return []
    body_start = func_def.body[0].lineno

    ranges: List[Tuple[int, int]] = []

    def _visit(node: ast.AST, in_nested: bool) -> None:
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.Lambda)):
            for child in ast.iter_child_nodes(node):
                _visit(child, in_nested=True)
            return
        if isinstance(node, ast.Return) and not in_nested:
            rel_start = node.lineno - body_start
            rel_end = node.end_lineno - body_start + 1  # type: ignore[attr-defined]
            ranges.append((rel_start, rel_end))
        for child in ast.iter_child_nodes(node):
            _visit(child, in_nested)

    for stmt in func_def.body:
        _visit(stmt, in_nested=False)

    return ranges


def _extract_body_lines(
    func_def: ast.FunctionDef, source_lines: List[str]
) -> List[str]:
    """
    Extract the raw (indented) lines of the create_output() body, dedented by one level.
    Return statements not inside nested function/lambda defs are replaced with a comment
    (multi-line return continuation lines are dropped entirely) so `return` never appears
    at notebook-cell scope.
    """
    body = func_def.body
    if not body:
        return []
    start = body[0].lineno - 1  # 0-indexed
    end = func_def.end_lineno  # type: ignore[attr-defined]
    raw = source_lines[start:end]
    # source_lines already carry their line endings — join without separator
    # to avoid doubled newlines that would shift dedented indices away from AST line numbers
    dedented = textwrap.dedent("".join(raw)).splitlines()

    return_ranges = _get_return_ranges(func_def)
    if not return_ranges:
        return dedented

    result: List[str] = []
    for i, line in enumerate(dedented):
        matched = next((r for r in return_ranges if r[0] <= i < r[1]), None)
        if matched is None:
            result.append(line)
        elif i == matched[0]:
            # First line of the return: emit as a comment
            result.append(
                f"{_indent(line)}# {line.strip()}  # return value wired to write cell below"
            )
        # Continuation lines of multi-line returns are dropped entirely
    return result


# ---------------------------------------------------------------------------
# Transform body text
# ---------------------------------------------------------------------------

def _transform_body_lines(
    body_lines: List[str],
    input_df_pairs: List[Tuple[str, str]],
    wv_pairs: List[Tuple[str, str]],
    enrichments_active_flag: bool,
    func_def: ast.FunctionDef,
    source_lines: List[str],
) -> List[str]:
    """
    Apply text-level transformations to create_output() body lines:
    1. Remove top-level preprocessed_input_dfs assignments (moved to Cell 4).
    2. Remove top-level workflow_variables assignments (moved to Cell 3).
    3. Comment out workflow_enrichments if/else blocks (if enrichments_active_flag).
    4. Strip print() calls.
    5. Remove references to convert_decimals_to_doubles and add TODO comment.
    6. Replace remaining inline preprocessed_input_dfs["key"] with correct spark.read.
    7. Replace remaining inline workflow_variables["key"] with variable name.
    """
    # Build sets for fast lookup
    input_df_keys = {k for _, k in input_df_pairs}
    input_df_var_by_key: Dict[str, str] = {k: v for v, k in input_df_pairs}
    wv_var_by_key: Dict[str, str] = {k: v for v, k in wv_pairs}
    wv_vars = {v for v, _ in wv_pairs}

    result: List[str] = []
    skip_next = False
    skip_c2d_continuation = False  # True while inside a multi-line convert_decimals_to_doubles() call
    c2d_paren_depth = 0

    for i, line in enumerate(body_lines):
        if skip_next:
            skip_next = False
            continue

        # Skip continuation lines of a multi-line convert_decimals_to_doubles() call
        if skip_c2d_continuation:
            c2d_paren_depth += line.count("(") - line.count(")")
            if c2d_paren_depth <= 0:
                skip_c2d_continuation = False
                c2d_paren_depth = 0
            continue

        stripped = line.strip()

        # 1. Skip top-level preprocessed_input_dfs["key"] assignments
        # Pattern: var = preprocessed_input_dfs["key"]
        if "preprocessed_input_dfs[" in stripped:
            # Check if this is a simple assignment we already handled
            is_simple_assignment = False
            for var, key in input_df_pairs:
                if stripped == f'{var} = preprocessed_input_dfs["{key}"]' or \
                   stripped == f"{var} = preprocessed_input_dfs['{key}']":
                    is_simple_assignment = True
                    break
            if is_simple_assignment:
                continue
            # Otherwise keep line but replace inline access
            # (handled below in inline replacement pass)

        # 2. Skip top-level workflow_variables["key"] assignments
        if "workflow_variables[" in stripped or "workflow_variables.get(" in stripped:
            is_wv_assign = False
            for var, key in wv_pairs:
                if (
                    stripped == f'{var} = workflow_variables["{key}"]'
                    or stripped == f"{var} = workflow_variables['{key}']"
                    or stripped.startswith(f"{var} = workflow_variables.get(")
                ):
                    is_wv_assign = True
                    break
            if is_wv_assign:
                continue

        # 3. Comment out print() calls
        if stripped.startswith("print("):
            result.append(f"{_indent(line)}# {stripped}  # stripped: print() removed")
            continue

        # 4. Comment out workflow_enrichments if/else blocks (whole block)
        if enrichments_active_flag and (
            "workflow_enrichments" in stripped
            and stripped.startswith("if ")
        ):
            # Comment out the entire if-block using indentation heuristic
            indent_level = len(line) - len(line.lstrip())
            result.append(
                f"{'    ' * (indent_level // 4)}# Enrichment block (commented out — configure workflow_enrichments as needed):"
            )
            result.append(f"{_indent(line)}# {stripped}")
            # Continue consuming lines of this block, including else/elif branches
            j = i + 1
            while j < len(body_lines):
                sub_line = body_lines[j]
                sub_stripped = sub_line.strip()
                sub_indent = len(sub_line) - len(sub_line.lstrip()) if sub_line.strip() else indent_level + 1
                if sub_stripped == "" or sub_indent > indent_level:
                    # Line is inside the if-block body
                    result.append(f"{'    ' * (indent_level // 4)}# {sub_stripped}")
                    body_lines[j] = ""  # mark as consumed
                    j += 1
                elif sub_indent == indent_level and (
                    sub_stripped.startswith("else:") or sub_stripped.startswith("elif ")
                ):
                    # else:/elif: at same indentation — part of this if-chain, comment it too
                    result.append(f"{'    ' * (indent_level // 4)}# {sub_stripped}")
                    body_lines[j] = ""  # mark as consumed
                    j += 1
                else:
                    break
            continue

        # 5. Handle convert_decimals_to_doubles reference (actual call, not a string key)
        if "convert_decimals_to_doubles(" in stripped:
            result.append(
                f"{_indent(line)}# TODO: convert_decimals_to_doubles called here — "
                "implement equivalent decimal-to-double cast if needed"
            )
            result.append(f"{_indent(line)}# {stripped}")
            # pass keeps any enclosing if-block valid if this was its only statement
            result.append(f"{_indent(line)}pass")
            # If the call spans multiple lines, skip continuation lines
            paren_balance = stripped.count("(") - stripped.count(")")
            if paren_balance > 0:
                skip_c2d_continuation = True
                c2d_paren_depth = paren_balance
            continue

        # 6. Inline replacement of remaining preprocessed_input_dfs["key"]
        if "preprocessed_input_dfs[" in line:
            for key in input_df_keys:
                for quote in ('"', "'"):
                    placeholder = f"preprocessed_input_dfs[{quote}{key}{quote}]"
                    if placeholder in line:
                        replacement = (
                            f'spark.read.format("delta").load('
                            f'tables_config["sddi_tables"].get("{key}", {{}}).get("delta_path", "/mnt/delta/sddi/{key}"))'
                        )
                        line = line.replace(placeholder, replacement)
            result.append(line.rstrip())
            continue

        # 7. Inline replacement of remaining workflow_variables["key"]
        if "workflow_variables[" in line or "workflow_variables.get(" in line:
            for key, var in wv_var_by_key.items():
                for q in ('"', "'"):
                    # Replace subscript access: workflow_variables["key"]
                    line = line.replace(f"workflow_variables[{q}{key}{q}]", var)
                    # Replace .get(key, default) with regex to consume full call — Fix FAIL-2b
                    line = re.sub(
                        rf'workflow_variables\.get\({re.escape(q)}{re.escape(key)}{re.escape(q)},\s*[^)]+\)',
                        var,
                        line,
                    )
                    # Replace .get(key) with no default
                    line = line.replace(f"workflow_variables.get({q}{key}{q})", var)
            result.append(line.rstrip())
            continue

        result.append(line.rstrip())

    # Remove trailing blank lines
    while result and result[-1].strip() == "":
        result.pop()

    return result


def _indent(line: str) -> str:
    """Return the leading whitespace of a line."""
    return line[: len(line) - len(line.lstrip())]


# ---------------------------------------------------------------------------
# Detect inline utility function usage
# ---------------------------------------------------------------------------

def _needs_helper(source_text: str, name: str) -> bool:
    return name in source_text


def _needs_relative_import_inline(source_text: str, symbol: str) -> bool:
    """Return True if the relative import from .module import <symbol> is present."""
    return f"from .batch_inventory_structs_deployment import {symbol}" in source_text or \
           f"BATCH_STOCK_COLS" in source_text


# ---------------------------------------------------------------------------
# Notebook assembly
# ---------------------------------------------------------------------------

def _cell(content: str) -> str:
    """Wrap content with COMMAND separators (blank line above and below sep)."""
    return f"\n{COMMAND_SEP}\n\n{content}"


def build_notebook(
    entry: Dict[str, Any],
    tables_config: Dict[str, Any],
    source_text: str,
    source_lines: List[str],
    tree: ast.Module,
    func_def: ast.FunctionDef,
) -> str:
    """
    Build the complete Databricks notebook source text for a given SDDI file.
    Returns the notebook string.
    """
    variant = _detect_signature_variant(func_def)
    enrichments_flag = _enrichments_active(func_def) if variant == "common" else True
    wv_active = _workflow_variables_active(func_def) if variant == "common" else True

    element_name: str = entry.get("element_name", "unknown_element")

    # --- Collect clean (non-bellhop) import lines from source ---
    clean_imports = _collect_clean_imports(source_lines)

    # --- Extract pairs ---
    input_df_pairs = _extract_input_df_pairs(func_def, source_lines)
    all_input_keys = _extract_all_input_df_keys(func_def)
    wv_pairs = _extract_workflow_variable_pairs(func_def) if wv_active else []

    # --- Extract body ---
    body_lines = _extract_body_lines(func_def, source_lines)

    # --- Check if thin pass-through (body <= 5 lines of actual code) ---
    body_code_lines = [l for l in body_lines if l.strip() and not l.strip().startswith("#")]
    is_thin = len(body_code_lines) <= 5

    # --- Transform body ---
    transformed_body = _transform_body_lines(
        body_lines,
        input_df_pairs,
        wv_pairs,
        enrichments_flag,
        func_def,
        source_lines,
    )

    # --- Determine which helpers need inlining (Fix FAIL-1: generalized via INLINED_HELPERS) ---
    needs_get_fk = _needs_helper(source_text, "get_foreign_keys")
    needs_enrich = _needs_helper(source_text, "enrich_table_without_base_table_fkeys")
    needs_concat_ws = _needs_helper(source_text, "concat_ws_with_nulls")
    needs_batch_cols = _needs_relative_import_inline(source_text, "BATCH_STOCK_COLS")
    # Additional SDI utilities — check each symbol in INLINED_HELPERS that isn't already
    # handled by the four explicit flags above
    ALREADY_HANDLED = {"get_foreign_keys", "enrich_table_without_base_table_fkeys",
                       "concat_ws_with_nulls", "BATCH_STOCK_COLS"}
    extra_helpers_needed: List[str] = [
        symbol for symbol in INLINED_HELPERS
        if symbol not in ALREADY_HANDLED and _needs_helper(source_text, symbol)
    ]
    # osi_pi_process_attributes depends on osi_pi_rename_common_columns and
    # osi_pi_derive_path_segments — ensure those are included when process_attributes is needed
    if "osi_pi_process_attributes" in extra_helpers_needed:
        for dep in ("osi_pi_rename_common_columns", "osi_pi_derive_path_segments", "osi_pi_derive_series_id"):
            if dep not in extra_helpers_needed:
                extra_helpers_needed.insert(0, dep)

    # --- Extract module-level helper functions ---
    helper_funcs = _extract_helper_functions(tree, source_lines)

    # =========================================================================
    # Cell 1: Header line (MUST be first line — not preceded by COMMAND sep)
    # =========================================================================
    relative_source = entry.get("path", "unknown")
    header_cell = (
        "# Databricks notebook source\n"
        f"# Generated from: {relative_source}\n"
        "# Conversion date: 2026-06-25"
    )

    # =========================================================================
    # Cell 2: Imports
    # =========================================================================
    imports_parts = [PYSPARK_IMPORTS]
    if clean_imports:
        imports_parts.append("\n# Additional imports from source:")
        imports_parts.extend(clean_imports)
    imports_cell = "\n".join(imports_parts)

    # =========================================================================
    # Cell 3: Load tables_config
    # =========================================================================
    tables_config_cell = "# Load Delta table path configuration\n" + TABLES_CONFIG_LOAD

    # =========================================================================
    # Cell 3.5: Workflow variables stubs (only if active and pairs found)
    # =========================================================================
    wv_cell_lines: Optional[List[str]] = None
    if wv_active and wv_pairs:
        wv_lines = ["# === Workflow Variables — configure these values for your environment ==="]
        for var_name, param_key in wv_pairs:
            wv_lines.append(f"# workflow_variable: {param_key}")
            wv_lines.append("# Configure this value as needed (originally from pipeline YAML config)")
            # Enhancement FAIL-2a: synthetic _flag vars from non-assignment context → default False
            if var_name.endswith("_flag"):
                wv_lines.append(
                    f"{var_name} = False  # configure: originally workflow_variables.get(\"{param_key}\")"
                )
            else:
                wv_lines.append(f"{var_name} = []  # e.g., ['value1', 'value2']")
            wv_lines.append("")
        wv_cell_lines = wv_lines

    # =========================================================================
    # Cell 4: deployment.py — read output_df from intermediate Delta path
    # =========================================================================
    output_df_cell: Optional[str] = None
    if variant == "deployment":
        # CI-3: RID reference on its own comment line before spark.read
        _ikey = f"{element_name}_intermediate"
        output_df_cell = (
            f"# Read intermediate result produced by {element_name}_common notebook\n"
            f"# sddi_tables key: {_ikey}\n"
            f"output_df = spark.read.format(\"delta\").load(\n"
            f"    tables_config[\"sddi_tables\"].get(\"{_ikey}\", {{}})"
            f".get(\"delta_path\", \"/mnt/delta/sddi/{_ikey}\")\n"
            f")"
        )

    # =========================================================================
    # Cell 5: Read input DataFrames
    # =========================================================================
    # Use all unique keys discovered (some may appear inline but not as top-level assigns)
    # Use input_df_pairs for named assignments; for any key without a top-level pair, generate a read
    reads_lines: List[str] = []
    covered_keys: set = set()
    for var_name, sddi_key in input_df_pairs:
        covered_keys.add(sddi_key)
        # CI-3: sddi key on a SEPARATE comment line
        reads_lines.append(f"# Read input table: {sddi_key}")
        reads_lines.append(
            f'{var_name} = spark.read.format("delta").load('
        )
        reads_lines.append(
            f'    tables_config["sddi_tables"].get("{sddi_key}", {{}}).get("delta_path", "/mnt/delta/sddi/{sddi_key}")'
        )
        reads_lines.append(")")
        reads_lines.append("")
    # Handle any keys accessed inline but not top-level assigned
    for key in all_input_keys:
        if key not in covered_keys:
            reads_lines.append(f"# Read input table (inline access): {key}")
            reads_lines.append(
                f'# {key}_df = spark.read.format("delta").load('
            )
            reads_lines.append(
                f'#     tables_config["sddi_tables"]["{key}"]["delta_path"]'
            )
            reads_lines.append("# )")
            reads_lines.append("")
    reads_cell = "\n".join(reads_lines).rstrip()
    if not reads_cell.strip():
        reads_cell = "# No preprocessed_input_dfs accesses found in this file"

    # =========================================================================
    # Cell 5.5: (W-3) Transform Logic documentation cell for thin pass-throughs
    # =========================================================================
    thin_doc_cell: Optional[str] = None
    if is_thin:
        thin_doc_cell = (
            "# === Transform Logic ===\n"
            "# This notebook is a thin pass-through — the main logic is in the transform body below.\n"
            "# Review and customize as needed for your Databricks environment."
        )

    # =========================================================================
    # Cell 6: Helper functions (module-level + inlined utils)
    # =========================================================================
    helpers_parts: List[str] = []

    if needs_batch_cols:
        helpers_parts.append(BATCH_STOCK_COLS_DEF)
        helpers_parts.append("")

    if needs_get_fk:
        helpers_parts.append(GET_FOREIGN_KEYS_IMPL)
        helpers_parts.append("")

    if needs_enrich:
        helpers_parts.append(ENRICH_TABLE_IMPL)
        helpers_parts.append("")

    if needs_concat_ws:
        helpers_parts.append(COLUMN_DELIMITER_DEF)
        helpers_parts.append("")
        helpers_parts.append(CONCAT_WS_IMPL)
        helpers_parts.append("")

    # Enhancement FAIL-1: inline additional SDI utility functions/constants
    already_inlined = set()  # track to avoid duplicates
    for symbol in extra_helpers_needed:
        if symbol not in already_inlined and symbol in INLINED_HELPERS:
            helpers_parts.append(INLINED_HELPERS[symbol])
            helpers_parts.append("")
            already_inlined.add(symbol)

    for hf in helper_funcs:
        helpers_parts.append(hf)
        helpers_parts.append("")

    helpers_cell: Optional[str] = None
    if helpers_parts:
        helpers_cell = "\n".join(helpers_parts).rstrip()

    # =========================================================================
    # Cell 7: Transform logic (inlined create_output body)
    # =========================================================================
    transform_header = "# === Transform Logic (inlined from create_output) ==="
    transform_cell = transform_header + "\n" + "\n".join(transformed_body)

    # =========================================================================
    # Cell 8: Write output
    # =========================================================================
    # Detect return variable from body
    return_var = _find_return_var(func_def)
    write_cell_lines: List[str] = []

    if return_var == "__complex_return__":
        # Enhancement FAIL-3: create_output returned a complex expression (not a simple Name).
        # Generate a prominent TODO write stub so the notebook doesn't silently omit the write.
        if variant == "common":
            _delta_key = element_name
            _delta_path = f"/mnt/delta/sddi/{element_name}"
        else:
            _delta_key = f"{element_name}_intermediate"
            _delta_path = f"/mnt/delta/sddi/{element_name}_intermediate"
        write_cell_lines.append(
            "# TODO: create_output returned a complex expression — add write logic manually"
        )
        write_cell_lines.append(
            "# The return expression was non-trivial (e.g., df.select(...), subscript, or list)."
        )
        write_cell_lines.append(
            "# Capture the return value in _output_df and write it to Delta:"
        )
        write_cell_lines.append("# _output_df = <return_expression_from_transform_cell>")
        write_cell_lines.append(f"# sddi_tables key: {_delta_key}")
        write_cell_lines.append(
            f'# _output_df.write.format("delta").mode("overwrite").save('
        )
        write_cell_lines.append(
            f'#     tables_config["sddi_tables"].get("{_delta_key}", {{}}).get("delta_path", "{_delta_path}")'
        )
        write_cell_lines.append("# )")
        logger.warning(
            "Complex return expression in %s/%s — generated TODO write stub",
            element_name, variant,
        )
    elif return_var:
        if variant == "common":
            # CI-3: sddi key on its own comment line
            write_cell_lines.append("# Write output to Delta")
            write_cell_lines.append(f"# sddi_tables key: {element_name}")
            write_cell_lines.append(
                f'{return_var}.write.format("delta").mode("overwrite").save('
            )
            write_cell_lines.append(
                f'    tables_config["sddi_tables"].get("{element_name}", {{}}).get("delta_path", "/mnt/delta/sddi/{element_name}")'
            )
            write_cell_lines.append(")")
        else:
            # deployment.py: write output_df back to intermediate path
            _ikey_w = f"{element_name}_intermediate"
            write_cell_lines.append("# Write enriched output to Delta")
            write_cell_lines.append(f"# sddi_tables key: {_ikey_w}")
            write_cell_lines.append(
                f'{return_var}.write.format("delta").mode("overwrite").save('
            )
            write_cell_lines.append(
                f'    tables_config["sddi_tables"].get("{_ikey_w}", {{}}).get("delta_path", "/mnt/delta/sddi/{_ikey_w}")'
            )
            write_cell_lines.append(")")
    elif variant == "deployment":
        _ikey_w2 = f"{element_name}_intermediate"
        write_cell_lines.append("# Write enriched output_df to Delta")
        write_cell_lines.append(f"# sddi_tables key: {_ikey_w2}")
        write_cell_lines.append(
            'output_df.write.format("delta").mode("overwrite").save('
        )
        write_cell_lines.append(
            f'    tables_config["sddi_tables"].get("{_ikey_w2}", {{}}).get("delta_path", "/mnt/delta/sddi/{_ikey_w2}")'
        )
        write_cell_lines.append(")")

    write_cell = "\n".join(write_cell_lines)

    # =========================================================================
    # Assemble notebook (W-3: ensure >= 3 COMMAND separators)
    # =========================================================================
    parts: List[str] = [header_cell]
    parts.append(_cell(imports_cell))
    parts.append(_cell(tables_config_cell))

    if wv_cell_lines:
        parts.append(_cell("\n".join(wv_cell_lines)))

    if output_df_cell:
        parts.append(_cell(output_df_cell))

    parts.append(_cell(reads_cell))

    if thin_doc_cell:
        parts.append(_cell(thin_doc_cell))

    if helpers_cell:
        parts.append(_cell(helpers_cell))

    parts.append(_cell(transform_cell))

    if write_cell.strip():
        parts.append(_cell(write_cell))

    notebook = "\n".join(parts) + "\n"

    # W-3 check: count COMMAND separators
    sep_count = notebook.count(COMMAND_SEP)
    if sep_count < 3:
        # Add extra documentation cell to guarantee >= 3
        extra_cell = _cell(
            "# === Additional Notes ===\n"
            "# This notebook was converted from a Palantir SDDI bellhop pipeline.\n"
            "# Review all tables_config paths before running in production."
        )
        # Insert before write cell (second to last _cell block)
        # For safety, just append it before the last separator
        idx = notebook.rfind(f"\n{COMMAND_SEP}\n")
        if idx >= 0:
            notebook = notebook[:idx] + extra_cell + notebook[idx:]
        else:
            notebook += extra_cell

    return notebook


def _find_return_var(func_def: ast.FunctionDef) -> Optional[str]:
    """
    Find the return variable name from create_output.

    Returns:
      - The variable name (str) if the return is a simple Name (e.g., return df)
      - "__complex_return__" sentinel if there is a return with a non-simple expression
        (e.g., return df.select(...), return preprocessed_input_dfs["key"], return [a, b])
        This lets the caller generate a TODO write stub instead of silently omitting the write.
      - None if no return statement is present at all.
    """
    for node in ast.walk(func_def):
        if isinstance(node, ast.Return) and node.value is not None:
            if isinstance(node.value, ast.Name):
                return node.value.id
            # Enhancement: non-simple return — return sentinel so caller generates TODO stub (Fix FAIL-3)
            return "__complex_return__"
    return None


# ---------------------------------------------------------------------------
# Per-file conversion
# ---------------------------------------------------------------------------

def convert_sddi_file(
    entry: Dict[str, Any],
    tables_config: Dict[str, Any],
    output_dir: Path,
    project_root: Path,
    force: bool,
) -> Optional[Path]:
    """
    Convert a single SDDI entry to a Databricks notebook.

    Args:
        entry: manifest entry dict (must have 'path', 'output_notebook', 'element_name')
        tables_config: loaded tables_config.yaml dict
        output_dir: directory to write notebooks into
        project_root: project root path for resolving relative source paths
        force: if True, overwrite existing output even if up-to-date

    Returns:
        Path of written notebook, or None on skip/failure.
    """
    source_path = Path(entry["path"])
    if not source_path.is_absolute():
        source_path = project_root / source_path

    output_notebook: str = entry.get("output_notebook", source_path.stem + ".py")
    output_path = output_dir / output_notebook

    # --- Idempotency skip ---
    if not force and output_path.exists():
        try:
            if output_path.stat().st_mtime >= source_path.stat().st_mtime:
                logger.info("SKIP %s (output is up to date)", output_notebook)
                return "SKIP"
        except OSError:
            pass

    # --- Read source ---
    try:
        source_text = source_path.read_text(encoding="utf-8")
    except OSError as exc:
        logger.error("ERROR reading %s: %s", source_path, exc)
        return None

    source_lines = source_text.splitlines(keepends=True)

    # --- Parse AST ---
    try:
        tree = ast.parse(source_text)
    except SyntaxError as exc:
        logger.error("ERROR parsing %s: %s — skipping", source_path, exc)
        return None

    # --- Find create_output ---
    func_def = _find_create_output(tree)
    if func_def is None:
        logger.warning(
            "WARNING: No create_output() in %s — classifying as tombstone; skipping",
            source_path,
        )
        return None

    # --- Build notebook ---
    try:
        notebook_text = build_notebook(
            entry=entry,
            tables_config=tables_config,
            source_text=source_text,
            source_lines=source_lines,
            tree=tree,
            func_def=func_def,
        )
    except Exception as exc:
        logger.error("ERROR building notebook for %s: %s", source_path, exc)
        return None

    # --- Write atomically ---
    output_dir.mkdir(parents=True, exist_ok=True)
    tmp_path = output_path.with_suffix(".tmp")
    try:
        tmp_path.write_text(notebook_text, encoding="utf-8")
        tmp_path.rename(output_path)
    except OSError as exc:
        logger.error("ERROR writing %s: %s", output_path, exc)
        try:
            tmp_path.unlink(missing_ok=True)
        except OSError:
            pass
        return None

    logger.info("Converted %s → %s", source_path.name, output_path.name)
    return output_path


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main() -> int:
    """
    Entry point for convert_sddi.py.

    Returns:
        0 on success (no failures), 1 if any file failed to convert.
    """
    parser = argparse.ArgumentParser(
        description="Convert SDDI bellhop create_output() files to Databricks notebooks."
    )
    parser.add_argument(
        "--manifest",
        type=Path,
        default=MANIFEST_PATH,
        help="Path to manifest.yaml (default: scripts-output/manifest.yaml)",
    )
    parser.add_argument(
        "--tables-config",
        type=Path,
        default=TABLES_CONFIG_PATH,
        help="Path to tables_config.yaml",
    )
    parser.add_argument(
        "--output-dir",
        type=Path,
        default=OUTPUT_DIR,
        help="Directory to write converted notebooks",
    )
    parser.add_argument(
        "--force",
        action="store_true",
        help="Overwrite output files even if up to date",
    )
    parser.add_argument(
        "--file",
        type=str,
        default=None,
        help="Process a single file by output_notebook name (skip manifest filter)",
    )
    args = parser.parse_args()

    manifest_path: Path = args.manifest
    tables_config_path: Path = args.tables_config
    output_dir: Path = args.output_dir

    # --- Resolve project root (two levels up from this script) ---
    project_root = Path(__file__).resolve().parent.parent.parent

    # --- Load manifest ---
    if not manifest_path.is_absolute():
        manifest_path = project_root / manifest_path
    if not manifest_path.exists():
        logger.error(
            "Manifest not found at %s — run scan_inputs.py first", manifest_path
        )
        return 1
    try:
        manifest_data = yaml.safe_load(manifest_path.read_text(encoding="utf-8"))
    except Exception as exc:
        logger.error("Failed to load manifest: %s", exc)
        return 1

    if isinstance(manifest_data, list):
        entries: List[Dict[str, Any]] = manifest_data
    elif isinstance(manifest_data, dict):
        entries = manifest_data.get("files", [])
    else:
        entries = []
    sddi_entries = [e for e in entries if e.get("type") == "sddi"]

    if not sddi_entries:
        logger.warning("No sddi entries found in manifest. Nothing to convert.")
        return 0

    # Filter to single file if requested
    if args.file:
        sddi_entries = [
            e for e in sddi_entries if e.get("output_notebook") == args.file
        ]
        if not sddi_entries:
            logger.error("No sddi entry found with output_notebook=%s", args.file)
            return 1

    # --- Load tables_config ---
    if not tables_config_path.is_absolute():
        tables_config_path = project_root / tables_config_path
    if not tables_config_path.exists():
        logger.error(
            "tables_config.yaml not found at %s — run extract_rid_map.py first",
            tables_config_path,
        )
        return 1
    try:
        tables_config: Dict[str, Any] = yaml.safe_load(
            tables_config_path.read_text(encoding="utf-8")
        )
    except Exception as exc:
        logger.error("Failed to load tables_config: %s", exc)
        return 1

    # --- Resolve output dir ---
    if not output_dir.is_absolute():
        output_dir = project_root / output_dir
    output_dir.mkdir(parents=True, exist_ok=True)

    # --- Convert files ---
    total = len(sddi_entries)
    converted = 0
    skipped = 0
    failed = 0

    for i, entry in enumerate(sddi_entries, start=1):
        out_name = entry.get("output_notebook", entry.get("path", "?"))
        logger.info("Converting %d/%d: %s", i, total, out_name)
        result = convert_sddi_file(
            entry=entry,
            tables_config=tables_config,
            output_dir=output_dir,
            project_root=project_root,
            force=args.force,
        )
        if result == "SKIP":
            # Idempotency skip — output is up to date
            skipped += 1
        elif result is None:
            # None means failure: OSError, SyntaxError, missing create_output, or
            # tombstone. Errors are logged at ERROR/WARNING level by convert_sddi_file.
            failed += 1
        else:
            converted += 1

    summary = (
        f"convert_sddi complete: {converted} converted, {skipped} skipped, {failed} failed"
    )
    logger.info(summary)
    print(summary)

    return 1 if failed > 0 else 0


if __name__ == "__main__":
    sys.exit(main())
