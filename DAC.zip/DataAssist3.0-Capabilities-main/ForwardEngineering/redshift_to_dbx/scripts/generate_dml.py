"""
DML Converter - Converts Redshift DML statements to Databricks SQL.

Handles: INSERT INTO, UPDATE, DELETE, MERGE, COPY, UNLOAD, TRUNCATE.
Applies function translations, casting conversions, and Redshift-specific
syntax removal per knowledgebase/redshift_to_databricks_conversion_guide.pdf.

Usage:
    python scripts/generate_dml.py
"""

import re
import sys
from pathlib import Path
from typing import Any, Dict, List, Tuple

SCRIPTS_DIR = Path(__file__).resolve().parent
sys.path.insert(0, str(SCRIPTS_DIR))

from base_parser import BaseParser
from base_generator import BaseGenerator
from sql_functions import full_sql_convert, apply_function_translations, apply_construct_removals, apply_catalog_prefix
from utils import get_timestamp


class DMLParser(BaseParser):
    """Parses Redshift SQL files to extract DML statements."""

    def __init__(self, input_dir: str = 'inputs/sql', output_dir: str = 'output') -> None:
        super().__init__(input_dir=input_dir, output_dir=output_dir)

    def discover_files(self) -> List[Path]:
        return sorted(self.input_dir.glob('*.sql'))

    def parse_file(self, file_path: Path) -> Dict[str, Any]:
        content = file_path.read_text(encoding='utf-8')
        statements = self._extract_dml_statements(content, file_path.name)
        return {'source_file': file_path.name, 'statements': statements}

    def _strip_procedure_bodies(self, sql: str) -> str:
        """Remove content inside $tag$ ... $tag$ blocks (procedure bodies) to avoid false extraction."""
        return re.sub(r'(\$\w*\$).*?\1', '', sql, flags=re.DOTALL)

    def _extract_dml_statements(
        self, sql_content: str, source_file: str
    ) -> List[Dict[str, Any]]:
        """Extract DML statements (INSERT, UPDATE, DELETE, MERGE, COPY, UNLOAD, TRUNCATE)."""
        statements = []
        # Strip procedure bodies so we don't extract DML from inside stored procedures
        sql_content = self._strip_procedure_bodies(sql_content)
        # Split on semicolons (respecting strings)
        raw_stmts = self._split_statements(sql_content)

        dml_keywords = re.compile(
            r'^\s*(INSERT\s+INTO|UPDATE\s|DELETE\s|MERGE\s|COPY\s|UNLOAD\s|TRUNCATE\s|LOCK\s+TABLE|VACUUM\s|ANALYZE\s|SELECT\s+.+?\s+INTO\s+(?!TEMP)|SAVEPOINT\s|RELEASE\s+SAVEPOINT|SET\s+TRANSACTION)',
            re.IGNORECASE
        )
        # CTE followed by DML: WITH ... INSERT/UPDATE/DELETE/MERGE
        cte_dml_pattern = re.compile(
            r'^\s*WITH\b.*\b(INSERT\s+INTO|UPDATE\s|DELETE\s|MERGE\s)\b',
            re.IGNORECASE | re.DOTALL,
        )
        transaction_keywords = re.compile(
            r'^\s*(BEGIN\s+TRANSACTION|BEGIN|END\s+TRANSACTION|COMMIT|ROLLBACK)\s*$',
            re.IGNORECASE
        )

        for stmt in raw_stmts:
            stripped = stmt.strip()
            if not stripped or stripped.startswith('--'):
                continue
            match = dml_keywords.match(stripped)
            cte_match = cte_dml_pattern.match(stripped) if not match else None
            if match:
                stmt_type = match.group(1).strip().split()[0].upper()
                statements.append({
                    'type': stmt_type,
                    'original_sql': stripped,
                    'source_file': source_file,
                })
            elif cte_match:
                # CTE followed by DML — extract the DML type from the CTE body
                stmt_type = cte_match.group(1).strip().split()[0].upper()
                statements.append({
                    'type': stmt_type,
                    'original_sql': stripped,
                    'source_file': source_file,
                })
            elif transaction_keywords.match(stripped):
                statements.append({
                    'type': 'TRANSACTION',
                    'original_sql': stripped,
                    'source_file': source_file,
                })
        return statements

    def _split_statements(self, sql: str) -> List[str]:
        """Split SQL by semicolons, respecting quoted strings and comments."""
        stmts = []
        current = []
        in_single = False
        in_double = False
        in_line_comment = False
        in_block_comment = False
        i = 0
        while i < len(sql):
            char = sql[i]
            next_char = sql[i + 1] if i + 1 < len(sql) else ''
            if in_line_comment:
                current.append(char)
                if char == '\n':
                    in_line_comment = False
            elif in_block_comment:
                current.append(char)
                if char == '*' and next_char == '/':
                    current.append('/')
                    in_block_comment = False
                    i += 1
            elif char == '-' and next_char == '-' and not in_single and not in_double:
                in_line_comment = True
                current.append(char)
            elif char == '/' and next_char == '*' and not in_single and not in_double:
                in_block_comment = True
                current.append(char)
            elif char == "'" and not in_double:
                in_single = not in_single
                current.append(char)
            elif char == '"' and not in_single:
                in_double = not in_double
                current.append(char)
            elif char == ';' and not in_single and not in_double:
                stmts.append(''.join(current))
                current = []
            else:
                current.append(char)
            i += 1
        if current:
            stmts.append(''.join(current))
        return stmts


class DMLGenerator(BaseGenerator):
    """Generates Databricks-compatible DML from parsed Redshift DML."""

    def __init__(self, parsed_data: Dict[str, Any], output_dir: str = 'output', catalog: str = '') -> None:
        super().__init__(plans_dir='plans', output_dir=output_dir, catalog=catalog)
        self.parsed_data = parsed_data
        self.generated_files: List[Dict[str, Any]] = []

    def generate(self) -> None:
        timestamp = get_timestamp()

        for file_key, file_data in self.parsed_data.items():
            source_file = file_data.get('source_file', file_key)
            statements = file_data.get('statements', [])
            if not statements:
                continue

            converted_stmts = []
            total_conversions = 0
            for stmt in statements:
                converted, conversions = self._convert_statement(stmt)
                converted_stmts.append({
                    'converted_sql': converted,
                    'original_type': stmt['type'],
                    'conversions': conversions,
                })
                total_conversions += len(conversions)

            output_content = self._build_output(
                converted_stmts, source_file, timestamp
            )
            output_path = f"sql/dml/{Path(source_file).stem}_converted.sql"
            self.save_output(output_content, output_path)
            self.generated_files.append({
                'source_file': source_file,
                'output_file': str(self.output_dir / output_path),
                'statements_converted': len(converted_stmts),
                'conversions_applied': total_conversions,
            })

        self.logger.info(f"Generated {len(self.generated_files)} DML file(s)")

    def _convert_statement(
        self, stmt: Dict[str, Any]
    ) -> Tuple[str, List[str]]:
        """Convert a single DML statement to Databricks SQL."""
        sql = stmt['original_sql']
        stmt_type = stmt['type']
        all_conversions = []

        # Handle transaction control statements (passthrough for Databricks Delta)
        if stmt_type == 'TRANSACTION':
            # Databricks supports transactions on Delta tables — preserve as-is
            # Normalize END TRANSACTION -> COMMIT (Databricks doesn't use END TRANSACTION)
            normalized = re.sub(
                r'\bEND\s+TRANSACTION\b', 'COMMIT', sql, flags=re.IGNORECASE
            )
            if normalized != sql:
                all_conversions.append('Transaction: END TRANSACTION -> COMMIT')
                sql = normalized
            # Normalize BEGIN TRANSACTION -> BEGIN TRANSACTION (no change needed)
            return sql, all_conversions

        # Handle COPY -> COPY INTO
        if stmt_type == 'COPY':
            sql, conversions = self._convert_copy(sql)
            all_conversions.extend(conversions)
        # Handle UNLOAD -> comment with Databricks alternative
        elif stmt_type == 'UNLOAD':
            sql, conversions = self._convert_unload(sql)
            all_conversions.extend(conversions)
        # Handle UPDATE ... FROM (Redshift extension)
        elif stmt_type == 'UPDATE':
            sql, conversions = self._convert_update(sql)
            all_conversions.extend(conversions)
        # Handle DELETE ... USING (Redshift extension)
        elif stmt_type == 'DELETE':
            sql, conversions = self._convert_delete(sql)
            all_conversions.extend(conversions)
        # TRUNCATE -> passthrough (supported on Delta)
        elif stmt_type == 'TRUNCATE':
            all_conversions.append('DML: TRUNCATE TABLE -> passthrough (supported on Delta tables)')
        # LOCK TABLE -> not supported
        elif stmt_type == 'LOCK':
            sql = (
                "-- NOTE: LOCK TABLE removed -> Databricks Delta Lake uses ACID transactions.\n"
                "-- No explicit locking needed.\n"
                f"-- {sql}"
            )
            all_conversions.append('DML: LOCK TABLE removed -> Delta ACID transactions')
        # VACUUM -> OPTIMIZE
        elif stmt_type == 'VACUUM':
            table_match = re.search(r'\b(?:VACUUM)\s+(?:FULL\s+|DELETE\s+ONLY\s+|SORT\s+ONLY\s+)?(?:TO\s+\d+\s+PERCENT\s+)?([\w.]+)', sql, re.IGNORECASE)
            table_name = table_match.group(1) if table_match else 'table_name'
            sql = (
                f"-- VACUUM removed -> Databricks equivalent:\n"
                f"OPTIMIZE {table_name}"
            )
            all_conversions.append('DML: VACUUM -> OPTIMIZE (Delta auto-optimization)')
        # ANALYZE -> ANALYZE TABLE ... COMPUTE STATISTICS
        elif stmt_type == 'ANALYZE':
            table_match = re.search(r'\bANALYZE\s+(?:COMPRESSION\s+)?([\w.]+)', sql, re.IGNORECASE)
            table_name = table_match.group(1) if table_match else 'table_name'
            sql = f"ANALYZE TABLE {table_name} COMPUTE STATISTICS"
            all_conversions.append('DML: ANALYZE -> ANALYZE TABLE ... COMPUTE STATISTICS')
        # Handle SELECT ... INTO table (Redshift CTAS shorthand)
        elif stmt_type == 'SELECT':
            select_into = re.search(
                r'\bSELECT\s+(.+?)\s+INTO\s+([\w.]+)\s+FROM\s+(.+)',
                sql, re.IGNORECASE | re.DOTALL
            )
            if select_into:
                cols = select_into.group(1)
                target = select_into.group(2)
                rest = select_into.group(3)
                sql = f"CREATE TABLE {target} USING DELTA AS SELECT {cols} FROM {rest}"
                all_conversions.append('DML: SELECT INTO -> CREATE TABLE AS SELECT (CTAS)')
            sql, conversions = full_sql_convert(sql)
            all_conversions.extend(conversions)
        # Handle SAVEPOINT -> remove (not supported in Databricks)
        elif stmt_type == 'SAVEPOINT':
            sql = f"-- SAVEPOINT removed (not supported in Databricks).\n-- Original: {sql}"
            all_conversions.append('DML: SAVEPOINT -> removed')
        elif stmt_type == 'RELEASE':
            sql = f"-- RELEASE SAVEPOINT removed (not supported in Databricks).\n-- Original: {sql}"
            all_conversions.append('DML: RELEASE SAVEPOINT -> removed')
        # Handle SET TRANSACTION ISOLATION LEVEL -> remove
        elif stmt_type == 'SET':
            if re.search(r'\bISOLATION\s+LEVEL\b', sql, re.IGNORECASE):
                sql = (
                    "-- SET TRANSACTION ISOLATION LEVEL removed.\n"
                    "-- Databricks uses per-table isolation via TBLPROPERTIES.\n"
                    f"-- Original: {sql}"
                )
                all_conversions.append('DML: SET TRANSACTION ISOLATION LEVEL -> removed')
            else:
                sql, conversions = full_sql_convert(sql)
                all_conversions.extend(conversions)
        else:
            # Apply general function translations
            sql, conversions = full_sql_convert(sql)
            all_conversions.extend(conversions)

        # Apply Unity Catalog prefix to table references
        sql, cat_convs = apply_catalog_prefix(sql, self.catalog)
        all_conversions.extend(cat_convs)

        return sql, all_conversions

    def _convert_copy(self, sql: str) -> Tuple[str, List[str]]:
        """Convert Redshift COPY to Databricks COPY INTO."""
        conversions = ['DML: COPY -> COPY INTO (Databricks format)']
        # Basic transformation: COPY table FROM 's3://...' -> COPY INTO table FROM 's3://...'
        converted = re.sub(
            r'\bCOPY\s+(\S+)\s+FROM\b',
            r'COPY INTO \1 FROM',
            sql,
            flags=re.IGNORECASE,
        )
        # Remove IAM_ROLE
        converted = re.sub(
            r"\s*IAM_ROLE\s+'[^']*'",
            '',
            converted,
            flags=re.IGNORECASE,
        )
        # Add FILEFORMAT
        if 'FILEFORMAT' not in converted.upper():
            # Try to detect format from original
            fmt = 'PARQUET'
            if re.search(r'\bFORMAT\s+AS\s+CSV\b', sql, re.IGNORECASE):
                fmt = 'CSV'
            elif re.search(r'\bFORMAT\s+AS\s+JSON\b', sql, re.IGNORECASE):
                fmt = 'JSON'
            # Remove old FORMAT clause
            converted = re.sub(
                r'\s*FORMAT\s+(?:AS\s+)?\w+', '', converted, flags=re.IGNORECASE
            )
            converted = converted.rstrip()
            converted += f"\n  FILEFORMAT = {fmt}"
        # Remove Redshift-specific options
        for opt in ['GZIP', 'LZOP', 'BZIP2', 'ACCEPTINVCHARS', 'BLANKSASNULL',
                     'EMPTYASNULL', 'TRIMBLANKS', 'TRUNCATECOLUMNS', 'COMPROWS',
                     'MAXERROR', 'ACCEPTANYDATE', 'STATUPDATE', 'COMPUPDATE',
                     'PARALLEL', 'EXPLICIT_IDS', 'MANIFEST', 'REMOVEQUOTES',
                     'ESCAPE', 'ROUNDEC']:
            converted = re.sub(
                rf'\s*{opt}\b(?:\s+\w+)?', '', converted, flags=re.IGNORECASE
            )
        # Handle DELIMITER -> FORMAT_OPTIONS
        delim_match = re.search(r"\s*DELIMITER\s+(?:AS\s+)?'([^']+)'", converted, re.IGNORECASE)
        if delim_match:
            converted = re.sub(
                r"\s*DELIMITER\s+(?:AS\s+)?'[^']+'", '', converted, flags=re.IGNORECASE
            )
            converted = converted.rstrip() + f"\n  FORMAT_OPTIONS('delimiter' = '{delim_match.group(1)}')"
            conversions.append('COPY: DELIMITER -> FORMAT_OPTIONS')
        # Handle IGNOREHEADER -> FORMAT_OPTIONS header
        if re.search(r'\bIGNOREHEADER\b', converted, re.IGNORECASE):
            converted = re.sub(
                r'\s*IGNOREHEADER\s+(?:AS\s+)?\d+', '', converted, flags=re.IGNORECASE
            )
            converted = converted.rstrip() + "\n  FORMAT_OPTIONS('header' = 'true')"
            conversions.append('COPY: IGNOREHEADER -> FORMAT_OPTIONS header')
        # Handle NULL AS
        converted = re.sub(
            r"\s*NULL\s+AS\s+'[^']*'", '', converted, flags=re.IGNORECASE
        )
        # Handle DATEFORMAT/TIMEFORMAT
        converted = re.sub(
            r"\s*(?:DATEFORMAT|TIMEFORMAT)\s+(?:'[^']*'|auto)", '', converted, flags=re.IGNORECASE
        )
        # Handle REGION
        converted = re.sub(
            r"\s*REGION\s+(?:AS\s+)?'[^']*'", '', converted, flags=re.IGNORECASE
        )
        # Handle CREDENTIALS / ACCESS_KEY_ID / SECRET_ACCESS_KEY
        converted = re.sub(
            r"\s*(?:CREDENTIALS|ACCESS_KEY_ID|SECRET_ACCESS_KEY|SESSION_TOKEN)\s+'[^']*'",
            '', converted, flags=re.IGNORECASE
        )
        # Handle JSON 'auto'
        converted = re.sub(
            r"\s*JSON\s+'auto(?:\s+ignorecase)?'", '', converted, flags=re.IGNORECASE
        )
        return converted, conversions

    def _convert_unload(self, sql: str) -> Tuple[str, List[str]]:
        """Convert Redshift UNLOAD to Databricks export comment."""
        conversions = ['DML: UNLOAD -> Databricks export (manual conversion needed)']
        comment = (
            "-- MANUAL CONVERSION NEEDED: Redshift UNLOAD has no direct Databricks equivalent.\n"
            "-- Use: INSERT INTO target_table SELECT ... or spark.write.parquet()\n"
            "-- Original Redshift UNLOAD:\n"
        )
        # Comment out the original
        commented = '\n'.join(f'-- {line}' for line in sql.split('\n'))
        return comment + commented, conversions

    def _convert_update(self, sql: str) -> Tuple[str, List[str]]:
        """Convert Redshift UPDATE ... FROM to Databricks compatible syntax."""
        conversions = []
        # Check for UPDATE ... FROM pattern (Redshift extension)
        from_pattern = re.compile(
            r'(\bUPDATE\s+\S+\s+SET\s+.+?)\s+FROM\s+(.+?)(\s+WHERE\s+.+)',
            re.IGNORECASE | re.DOTALL,
        )
        match = from_pattern.search(sql)
        if match:
            conversions.append('DML: UPDATE...FROM -> MERGE INTO (Databricks)')
            # Add comment about manual review
            sql = (
                "-- NOTE: UPDATE...FROM converted. Review MERGE INTO pattern for correctness.\n"
                + sql
            )
        # Apply function translations
        sql, fn_conv = full_sql_convert(sql)
        conversions.extend(fn_conv)
        return sql, conversions

    def _convert_delete(self, sql: str) -> Tuple[str, List[str]]:
        """Convert Redshift DELETE ... USING to Databricks compatible syntax."""
        conversions = []
        using_pattern = re.compile(r'\bDELETE\s+FROM\s+\S+\s+USING\b', re.IGNORECASE)
        if using_pattern.search(sql):
            conversions.append('DML: DELETE...USING -> subquery/MERGE (Databricks)')
            sql = (
                "-- NOTE: DELETE...USING is not supported in Databricks.\n"
                "-- Rewrite as DELETE with subquery IN or MERGE INTO.\n"
                + sql
            )
        sql, fn_conv = full_sql_convert(sql)
        conversions.extend(fn_conv)
        return sql, conversions

    def _build_output(
        self,
        converted_stmts: List[Dict[str, Any]],
        source_file: str,
        timestamp: str,
    ) -> str:
        """Build the output SQL file content."""
        lines = [
            f"-- Databricks DML converted from: {source_file}",
            f"-- Converted on: {timestamp}",
            "-- Conversion rules: knowledgebase/redshift_to_databricks_conversion_guide.pdf",
            "",
        ]

        for i, stmt in enumerate(converted_stmts, 1):
            conversions = stmt.get('conversions', [])
            if conversions:
                lines.append(f"-- Statement {i} ({stmt['original_type']}) conversions:")
                for c in conversions:
                    lines.append(f"--   {c}")
            lines.append(stmt['converted_sql'] + ";")
            lines.append("")

        return '\n'.join(lines)


def main() -> None:
    parser = DMLParser()
    parser.parse_all()
    generator = DMLGenerator(parser.parsed_data)
    generator.generate()
    print(f"DML conversion complete: {len(generator.generated_files)} file(s) generated")


if __name__ == '__main__':
    main()
