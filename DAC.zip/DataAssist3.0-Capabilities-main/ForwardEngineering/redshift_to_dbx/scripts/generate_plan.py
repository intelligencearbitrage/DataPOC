"""
Conversion Plan Generator — Scans input files and produces a detailed plan
showing what will be converted, without actually running the conversion.

Generates plans/conversion_plan.md with per-file analysis for both workstreams.

Usage:
    python scripts/generate_plan.py --input inputs/ --output plans/
    # Or via convert.py:
    python convert.py -i inputs/ -o output/ --type both --plan
"""

import re
import sys
from pathlib import Path
from typing import Any, Dict, List, Tuple

SCRIPTS_DIR = Path(__file__).resolve().parent
sys.path.insert(0, str(SCRIPTS_DIR))

from sql_functions import (
    FUNCTION_TRANSLATIONS,
    DATA_TYPE_MAP,
    REDSHIFT_CONSTRUCT_PATTERNS,
    SYSTEM_TABLE_MAP,
)
from utils import get_timestamp


# ── Detection patterns for SQL statement types ──────────────────────────

STATEMENT_PATTERNS = {
    'CREATE TABLE': re.compile(r'CREATE\s+(?:OR\s+REPLACE\s+)?TABLE\b(?!\s+AS\b)', re.IGNORECASE),
    'CREATE TABLE AS SELECT': re.compile(r'CREATE\s+(?:OR\s+REPLACE\s+)?TABLE\s+\S+\s+AS\s+SELECT\b', re.IGNORECASE),
    'ALTER TABLE': re.compile(r'ALTER\s+TABLE\b', re.IGNORECASE),
    'DROP TABLE': re.compile(r'DROP\s+TABLE\b', re.IGNORECASE),
    'TRUNCATE': re.compile(r'TRUNCATE\s+TABLE\b', re.IGNORECASE),
    'CREATE VIEW': re.compile(r'CREATE\s+(?:OR\s+REPLACE\s+)?VIEW\b', re.IGNORECASE),
    'CREATE MATERIALIZED VIEW': re.compile(r'CREATE\s+(?:OR\s+REPLACE\s+)?MATERIALIZED\s+VIEW\b', re.IGNORECASE),
    'CREATE PROCEDURE': re.compile(r'CREATE\s+(?:OR\s+REPLACE\s+)?PROCEDURE\b', re.IGNORECASE),
    'INSERT': re.compile(r'\bINSERT\s+INTO\b', re.IGNORECASE),
    'UPDATE': re.compile(r'\bUPDATE\s+\w', re.IGNORECASE),
    'DELETE': re.compile(r'\bDELETE\s+FROM\b', re.IGNORECASE),
    'MERGE': re.compile(r'\bMERGE\s+INTO\b', re.IGNORECASE),
    'COPY': re.compile(r'\bCOPY\b(?!\s+INTO)', re.IGNORECASE),
    'UNLOAD': re.compile(r'\bUNLOAD\b', re.IGNORECASE),
    'SELECT': re.compile(r'^\s*(?:WITH\s|SELECT\s)', re.IGNORECASE | re.MULTILINE),
    'GRANT/REVOKE': re.compile(r'^\s*(?:GRANT|REVOKE)\b', re.IGNORECASE | re.MULTILINE),
}

# ── Detection patterns for Redshift-specific constructs ─────────────────

REDSHIFT_DETECTION = {
    # Functions
    'GETDATE()': re.compile(r'\bGETDATE\s*\(\s*\)', re.IGNORECASE),
    'SYSDATE': re.compile(r'\bSYSDATE\b', re.IGNORECASE),
    'NVL()': re.compile(r'\bNVL\s*\(', re.IGNORECASE),
    'NVL2()': re.compile(r'\bNVL2\s*\(', re.IGNORECASE),
    'DECODE()': re.compile(r'\bDECODE\s*\(', re.IGNORECASE),
    'CONVERT_TIMEZONE()': re.compile(r'\bCONVERT_TIMEZONE\s*\(', re.IGNORECASE),
    'AT TIME ZONE': re.compile(r'\bAT\s+TIME\s+ZONE\b', re.IGNORECASE),
    'DATEADD()': re.compile(r'\bDATEADD\s*\(', re.IGNORECASE),
    'DATEDIFF()': re.compile(r'\bDATEDIFF\s*\(\s*\w+\s*,', re.IGNORECASE),
    'DATE_PART()': re.compile(r'\bDATE_PART\s*\(', re.IGNORECASE),
    'TO_CHAR()': re.compile(r'\bTO_CHAR\s*\(', re.IGNORECASE),
    'LEN()': re.compile(r'\bLEN\s*\(', re.IGNORECASE),
    'STRPOS()': re.compile(r'\bSTRPOS\s*\(', re.IGNORECASE),
    'CHARINDEX()': re.compile(r'\bCHARINDEX\s*\(', re.IGNORECASE),
    'LISTAGG()': re.compile(r'\bLISTAGG\s*\(', re.IGNORECASE),
    'STRTOL()': re.compile(r'\bSTRTOL\s*\(', re.IGNORECASE),
    'BTRIM()': re.compile(r'\bBTRIM\s*\(', re.IGNORECASE),
    'REGEXP_SUBSTR()': re.compile(r'\bREGEXP_SUBSTR\s*\(', re.IGNORECASE),
    'REGEXP_COUNT()': re.compile(r'\bREGEXP_COUNT\s*\(', re.IGNORECASE),
    'QUOTE_LITERAL()': re.compile(r'\bQUOTE_LITERAL\s*\(', re.IGNORECASE),
    'QUOTE_IDENT()': re.compile(r'\bQUOTE_IDENT\s*\(', re.IGNORECASE),
    'JSON_EXTRACT_PATH_TEXT()': re.compile(r'\bJSON_EXTRACT_PATH_TEXT\s*\(', re.IGNORECASE),
    'JSON_PARSE()': re.compile(r'\bJSON_PARSE\s*\(', re.IGNORECASE),
    'IS_VALID_JSON()': re.compile(r'\bIS_VALID_JSON\s*\(', re.IGNORECASE),
    'APPROXIMATE COUNT': re.compile(r'\bAPPROXIMATE\s+COUNT\b', re.IGNORECASE),
    'MEDIAN()': re.compile(r'\bMEDIAN\s*\(', re.IGNORECASE),
    'LOG() single-arg': re.compile(r'\bLOG\s*\(\s*[^,)]+\s*\)', re.IGNORECASE),
    'RANDOM()': re.compile(r'\bRANDOM\s*\(\s*\)', re.IGNORECASE),
    'SIMILAR TO': re.compile(r'\bSIMILAR\s+TO\b', re.IGNORECASE),
    'SELECT TOP': re.compile(r'\bSELECT\s+TOP\s+\d+', re.IGNORECASE),
    'MINUS': re.compile(r'\bMINUS\b', re.IGNORECASE),
    # Data types
    'VARCHAR(n)': re.compile(r'\bVARCHAR\s*\(\s*\d+\s*\)', re.IGNORECASE),
    'TIMESTAMPTZ': re.compile(r'\bTIMESTAMPTZ\b', re.IGNORECASE),
    'BPCHAR': re.compile(r'\bBPCHAR\b', re.IGNORECASE),
    'NUMERIC': re.compile(r'\bNUMERIC\b', re.IGNORECASE),
    'SUPER': re.compile(r'\bSUPER\b', re.IGNORECASE),
    'TEXT type': re.compile(r'\bTEXT\b', re.IGNORECASE),
    'FLOAT (ambiguous)': re.compile(r'\bFLOAT\b(?!\d)', re.IGNORECASE),
    'DOUBLE PRECISION': re.compile(r'\bDOUBLE\s+PRECISION\b', re.IGNORECASE),
    'GEOMETRY/GEOGRAPHY': re.compile(r'\b(?:GEOMETRY|GEOGRAPHY)\b', re.IGNORECASE),
    # Constructs
    'DISTKEY': re.compile(r'\bDISTKEY\b', re.IGNORECASE),
    'DISTSTYLE': re.compile(r'\bDISSTYLE\b', re.IGNORECASE),
    'SORTKEY': re.compile(r'\bSORTKEY\b', re.IGNORECASE),
    'ENCODE': re.compile(r'\bENCODE\s+\w+', re.IGNORECASE),
    'IDENTITY()': re.compile(r'\bIDENTITY\s*\(', re.IGNORECASE),
    'BACKUP YES/NO': re.compile(r'\bBACKUP\s+(?:YES|NO)\b', re.IGNORECASE),
    'VACUUM': re.compile(r'\bVACUUM\b', re.IGNORECASE),
    'ANALYZE': re.compile(r'\bANALYZE\b', re.IGNORECASE),
    'LOCK TABLE': re.compile(r'\bLOCK\s+TABLE\b', re.IGNORECASE),
    'ALTER TABLE APPEND': re.compile(r'\bALTER\s+TABLE\s+\w+\s+APPEND\b', re.IGNORECASE),
    'WITH NO SCHEMA BINDING': re.compile(r'\bWITH\s+NO\s+SCHEMA\s+BINDING\b', re.IGNORECASE),
    'SELECT INTO TEMP': re.compile(r'\bSELECT\b.+?\bINTO\s+TEMP', re.IGNORECASE | re.DOTALL),
    '#table_name': re.compile(r'(?<!\w)#\w+', re.IGNORECASE),
    'CREATE TABLE LIKE': re.compile(r'CREATE\s+TABLE\s+\w+\s*\(\s*LIKE\b', re.IGNORECASE),
    ':: cast syntax': re.compile(r'\w+::\w+', re.IGNORECASE),
    'SET search_path': re.compile(r'\bSET\s+search_path\b', re.IGNORECASE),
    # PL/pgSQL
    'PL/pgSQL: RAISE': re.compile(r'\bRAISE\s+(?:NOTICE|EXCEPTION|INFO|WARNING)\b', re.IGNORECASE),
    'PL/pgSQL: EXECUTE': re.compile(r'\bEXECUTE\s+(?!IMMEDIATE)', re.IGNORECASE),
    'PL/pgSQL: PERFORM': re.compile(r'\bPERFORM\s+', re.IGNORECASE),
    'PL/pgSQL: FOR..LOOP': re.compile(r'\bFOR\s+\w+\s+IN\b', re.IGNORECASE),
    'PL/pgSQL: EXCEPTION WHEN': re.compile(r'\bEXCEPTION\s+WHEN\b', re.IGNORECASE),
    'PL/pgSQL: := assignment': re.compile(r'\w+\s*:=\s*', re.IGNORECASE),
    'PL/pgSQL: ELSIF': re.compile(r'\bELSIF\b', re.IGNORECASE),
    'PL/pgSQL: DECLARE': re.compile(r'\bDECLARE\b', re.IGNORECASE),
    # System tables
    'STL_* tables': re.compile(r'\bstl_\w+', re.IGNORECASE),
    'STV_* tables': re.compile(r'\bstv_\w+', re.IGNORECASE),
    'SVV_* tables': re.compile(r'\bsvv_\w+', re.IGNORECASE),
    'PG_TABLE_DEF': re.compile(r'\bpg_table_def\b', re.IGNORECASE),
}


def scan_file(file_path: Path) -> Dict[str, Any]:
    """Scan a single file and return detected patterns."""
    content = file_path.read_text(encoding='utf-8')

    # Detect statement types
    statements = {}
    for stmt_name, pattern in STATEMENT_PATTERNS.items():
        count = len(pattern.findall(content))
        if count > 0:
            statements[stmt_name] = count

    # Detect Redshift-specific constructs
    redshift_patterns = {}
    for name, pattern in REDSHIFT_DETECTION.items():
        count = len(pattern.findall(content))
        if count > 0:
            redshift_patterns[name] = count

    return {
        'file': file_path.name,
        'path': str(file_path),
        'size_bytes': file_path.stat().st_size,
        'line_count': content.count('\n') + 1,
        'statements': statements,
        'redshift_patterns': redshift_patterns,
        'total_patterns': sum(redshift_patterns.values()),
    }


def scan_dbt_project(dbt_dir: Path) -> List[Dict[str, Any]]:
    """Scan a dbt project directory."""
    results = []
    for f in sorted(dbt_dir.rglob('*')):
        if f.is_file() and f.suffix in ('.sql', '.yml', '.yaml'):
            info = scan_file(f)
            info['relative_path'] = str(f.relative_to(dbt_dir))
            # Detect dbt-specific items
            content = f.read_text(encoding='utf-8')
            dbt_items = {}
            if re.search(r'\{\{.*ref\s*\(', content):
                dbt_items['{{ ref() }}'] = len(re.findall(r'\{\{.*?ref\s*\(', content))
            if re.search(r'\{\{.*source\s*\(', content):
                dbt_items['{{ source() }}'] = len(re.findall(r'\{\{.*?source\s*\(', content))
            if re.search(r'\{\%.*config\s*\(', content):
                dbt_items['{% config() %}'] = 1
            if re.search(r'sort\s*[=:]', content, re.IGNORECASE):
                dbt_items['sort config'] = 1
            if re.search(r'dist\s*[=:]', content, re.IGNORECASE):
                dbt_items['dist config'] = 1
            if re.search(r'bind\s*[=:]', content, re.IGNORECASE):
                dbt_items['bind config'] = 1
            if f.name == 'dbt_project.yml':
                dbt_items['project_config'] = 1
            info['dbt_items'] = dbt_items
            results.append(info)
    return results


def generate_plan_md(
    ws1_results: List[Dict[str, Any]],
    ws2_results: List[Dict[str, Any]],
    output_dir: str,
) -> str:
    """Generate the conversion plan as markdown."""
    timestamp = get_timestamp()
    lines = [
        '# Conversion Plan — Redshift to Databricks',
        f'',
        f'Generated: {timestamp}',
        '',
        '---',
        '',
    ]

    # ── Summary ──────────────────────────────────────────────────────────
    total_files = len(ws1_results) + len(ws2_results)
    total_patterns = sum(r['total_patterns'] for r in ws1_results) + sum(r['total_patterns'] for r in ws2_results)

    lines.append('## Summary')
    lines.append('')
    lines.append('| Metric | Value |')
    lines.append('|--------|-------|')
    lines.append(f'| Total input files | {total_files} |')
    lines.append(f'| Workstream 1 (SQL) files | {len(ws1_results)} |')
    lines.append(f'| Workstream 2 (dbt) files | {len(ws2_results)} |')
    lines.append(f'| Total Redshift patterns detected | {total_patterns} |')
    lines.append(f'| Converter engine | sql_functions.py ({len(FUNCTION_TRANSLATIONS)} function translations, {len(DATA_TYPE_MAP)} type mappings, {len(REDSHIFT_CONSTRUCT_PATTERNS)} construct patterns, {len(SYSTEM_TABLE_MAP)} system table mappings) |')
    lines.append(f'| Output directory | `{output_dir}` |')
    lines.append('')

    # ── Aggregate pattern counts ─────────────────────────────────────────
    all_results = ws1_results + ws2_results
    aggregate_patterns: Dict[str, int] = {}
    for r in all_results:
        for name, count in r['redshift_patterns'].items():
            aggregate_patterns[name] = aggregate_patterns.get(name, 0) + count

    if aggregate_patterns:
        lines.append('## Redshift Patterns Detected (Aggregate)')
        lines.append('')
        lines.append('| Pattern | Occurrences | Action |')
        lines.append('|---------|-------------|--------|')
        action_map = {
            'GETDATE()': 'Replace with CURRENT_TIMESTAMP',
            'SYSDATE': 'Replace with CURRENT_TIMESTAMP',
            'NVL()': 'Replace with COALESCE()',
            'NVL2()': 'Replace with CASE WHEN ... IS NOT NULL',
            'DECODE()': 'Convert to CASE WHEN ... END',
            'CONVERT_TIMEZONE()': 'Convert to FROM_UTC_TIMESTAMP/TO_UTC_TIMESTAMP',
            'AT TIME ZONE': 'Convert to FROM_UTC_TIMESTAMP()',
            'DATEADD()': 'Convert to DATE_ADD/ADD_MONTHS/DATEADD',
            'DATEDIFF()': 'Convert to DATEDIFF/MONTHS_BETWEEN',
            'DATE_PART()': 'Convert to EXTRACT()',
            'TO_CHAR()': 'Convert to DATE_FORMAT() + format token translation',
            'LEN()': 'Replace with LENGTH()',
            'STRPOS()': 'Replace with LOCATE()',
            'CHARINDEX()': 'Replace with INSTR()',
            'LISTAGG()': 'Convert to ARRAY_JOIN(COLLECT_LIST())',
            'STRTOL()': 'Convert to CONV()',
            'BTRIM()': 'Convert to TRIM()',
            'REGEXP_SUBSTR()': 'Replace with REGEXP_EXTRACT()',
            'REGEXP_COUNT()': 'Convert to SIZE(SPLIT()) - 1',
            'QUOTE_LITERAL()': 'Remove (not needed in Databricks)',
            'QUOTE_IDENT()': 'Convert to CONCAT with backticks',
            'JSON_EXTRACT_PATH_TEXT()': 'Convert to GET_JSON_OBJECT()',
            'JSON_PARSE()': 'Convert to PARSE_JSON()',
            'IS_VALID_JSON()': 'Convert to TRY_PARSE_JSON() IS NOT NULL',
            'APPROXIMATE COUNT': 'Convert to APPROX_COUNT_DISTINCT()',
            'MEDIAN()': 'Convert to PERCENTILE_CONT(0.5)',
            'LOG() single-arg': 'Convert to LOG10() (RS LOG=base-10)',
            'RANDOM()': 'Replace with RAND()',
            'SIMILAR TO': 'Convert to RLIKE',
            'SELECT TOP': 'Convert to SELECT ... LIMIT',
            'MINUS': 'Convert to EXCEPT',
            'VARCHAR(n)': 'Map to STRING',
            'TIMESTAMPTZ': 'Map to TIMESTAMP',
            'BPCHAR': 'Map to STRING',
            'NUMERIC': 'Map to DECIMAL (explicit precision)',
            'SUPER': 'Map to STRING (JSON)',
            'TEXT type': 'Map to STRING',
            'FLOAT (ambiguous)': 'Map to DOUBLE (RS FLOAT=8 bytes)',
            'DOUBLE PRECISION': 'Map to DOUBLE',
            'GEOMETRY/GEOGRAPHY': 'Map to STRING (WKT)',
            'DISTKEY': 'Remove (Delta handles distribution)',
            'DISTSTYLE': 'Remove',
            'SORTKEY': 'Remove (use OPTIMIZE ZORDER)',
            'ENCODE': 'Remove (Delta handles compression)',
            'IDENTITY()': 'Convert to GENERATED ALWAYS AS IDENTITY',
            'BACKUP YES/NO': 'Remove',
            'VACUUM': 'Convert to OPTIMIZE',
            'ANALYZE': 'Convert to ANALYZE TABLE COMPUTE STATISTICS',
            'LOCK TABLE': 'Remove (Delta uses ACID)',
            'ALTER TABLE APPEND': 'Advisory: INSERT INTO...SELECT',
            'WITH NO SCHEMA BINDING': 'Remove',
            'SELECT INTO TEMP': 'Convert to CREATE TEMPORARY TABLE AS SELECT',
            '#table_name': 'Remove hash prefix (temp table)',
            'CREATE TABLE LIKE': 'Advisory: use CTAS WHERE 1=0',
            ':: cast syntax': 'Convert to CAST(... AS ...)',
            'SET search_path': 'Remove (use USE SCHEMA)',
            'PL/pgSQL: RAISE': 'Convert to SIGNAL/SELECT debug',
            'PL/pgSQL: EXECUTE': 'Convert to EXECUTE IMMEDIATE',
            'PL/pgSQL: PERFORM': 'Remove keyword (direct call)',
            'PL/pgSQL: FOR..LOOP': 'Convert to FOR...AS CURSOR...DO',
            'PL/pgSQL: EXCEPTION WHEN': 'Convert to DECLARE EXIT HANDLER',
            'PL/pgSQL: := assignment': 'Convert to SET var = / DEFAULT',
            'PL/pgSQL: ELSIF': 'Convert to ELSEIF',
            'PL/pgSQL: DECLARE': 'Type conversion (RECORD removal, VARCHAR→STRING)',
            'STL_* tables': 'Map to system.query.history / system.access.audit',
            'STV_* tables': 'Map to system.compute.warehouse_events',
            'SVV_* tables': 'Map to system.information_schema.*',
            'PG_TABLE_DEF': 'Map to system.information_schema.columns',
        }
        for name, count in sorted(aggregate_patterns.items(), key=lambda x: -x[1]):
            action = action_map.get(name, 'Will be converted')
            lines.append(f'| {name} | {count} | {action} |')
        lines.append('')

    # ── Workstream 1: Per-file plan ──────────────────────────────────────
    if ws1_results:
        lines.append('---')
        lines.append('')
        lines.append('## Workstream 1: Standalone SQL')
        lines.append('')

        for r in ws1_results:
            lines.append(f'### {r["file"]}')
            lines.append('')
            lines.append(f'- **Size**: {r["size_bytes"]:,} bytes, {r["line_count"]} lines')

            if r['statements']:
                stmt_str = ', '.join(f'{name} ({count})' for name, count in r['statements'].items())
                lines.append(f'- **Statements**: {stmt_str}')

            # Determine output routing
            stmts = r['statements']
            output_types = []
            if 'CREATE TABLE' in stmts:
                output_types.append('`output/sql/ddl/`')
            if any(s in stmts for s in ['INSERT', 'UPDATE', 'DELETE', 'MERGE', 'COPY', 'UNLOAD']):
                output_types.append('`output/sql/dml/`')
            if 'CREATE VIEW' in stmts:
                output_types.append('`output/sql/views/`')
            if 'CREATE MATERIALIZED VIEW' in stmts:
                output_types.append('`output/sql/materialized_views/`')
            if 'CREATE PROCEDURE' in stmts:
                output_types.append('`output/sql/stored_procedures/`')
            if 'SELECT' in stmts:
                output_types.append('`output/sql/queries/`')
            if output_types:
                lines.append(f'- **Output**: {", ".join(output_types)}')

            if r['redshift_patterns']:
                lines.append(f'- **Redshift patterns** ({r["total_patterns"]} total):')
                for name, count in sorted(r['redshift_patterns'].items(), key=lambda x: -x[1]):
                    lines.append(f'  - {name}: {count}')
            else:
                lines.append('- **Redshift patterns**: None detected (pass-through)')
            lines.append('')

    # ── Workstream 2: Per-file plan ──────────────────────────────────────
    if ws2_results:
        lines.append('---')
        lines.append('')
        lines.append('## Workstream 2: dbt Project')
        lines.append('')

        # Group by directory
        dir_groups: Dict[str, List[Dict]] = {}
        for r in ws2_results:
            parts = r['relative_path'].split('/')
            group = parts[0] if len(parts) > 1 else 'root'
            dir_groups.setdefault(group, []).append(r)

        for group_name, files in sorted(dir_groups.items()):
            lines.append(f'### {group_name}/')
            lines.append('')
            for r in files:
                fname = r['relative_path']
                pattern_count = r['total_patterns']
                dbt_items = r.get('dbt_items', {})

                details = []
                if pattern_count > 0:
                    pattern_names = ', '.join(sorted(r['redshift_patterns'].keys()))
                    details.append(f'{pattern_count} Redshift patterns ({pattern_names})')
                if dbt_items:
                    dbt_str = ', '.join(f'{k}: {v}' for k, v in dbt_items.items())
                    details.append(f'dbt: {dbt_str}')

                detail_str = f' — {"; ".join(details)}' if details else ' — pass-through'
                lines.append(f'- `{fname}`{detail_str}')
            lines.append('')

    # ── Conversion Engine Summary ────────────────────────────────────────
    lines.append('---')
    lines.append('')
    lines.append('## Conversion Engine')
    lines.append('')
    lines.append('The following rules will be applied by `scripts/sql_functions.py`:')
    lines.append('')
    lines.append(f'- **{len(FUNCTION_TRANSLATIONS)} function translations** (date/time, string, JSON, conditional, aggregate, math, casting)')
    lines.append(f'- **{len(DATA_TYPE_MAP)} data type mappings** (VARCHAR→STRING, TIMESTAMPTZ→TIMESTAMP, NUMERIC→DECIMAL, etc.)')
    lines.append(f'- **{len(REDSHIFT_CONSTRUCT_PATTERNS)} construct removal/advisory patterns** (DISTKEY, SORTKEY, ENCODE, VACUUM, etc.)')
    lines.append(f'- **{len(SYSTEM_TABLE_MAP)} system table mappings** (STL_QUERY→system.query.history, etc.)')
    lines.append(f'- **28 date format token conversions** (YYYY→yyyy, MI→mm, HH24→HH, etc.)')
    lines.append(f'- **Balanced-paren converters** for DECODE, CONVERT_TIMEZONE, (expr)::TYPE casts')
    lines.append('')
    lines.append('### Additional converters:')
    lines.append('- `generate_ddl.py` — CREATE TABLE column parsing, USING DELTA, IF NOT EXISTS')
    lines.append('- `generate_dml.py` — COPY→COPY INTO, UNLOAD advisory, transaction handling')
    lines.append('- `generate_views.py` — View/MV options removal, late-binding conversion')
    lines.append('- `generate_procedures.py` — PL/pgSQL→SQL scripting (RAISE, FOR, EXCEPTION, DECLARE)')
    lines.append('- `generate_queries.py` — SELECT TOP, CTEs, CTAS, MINUS→EXCEPT')
    lines.append('- `generate_dbt.py` — Jinja-aware SQL conversion, config migration, hook conversion')
    lines.append('')

    # ── Execution Command ────────────────────────────────────────────────
    lines.append('---')
    lines.append('')
    lines.append('## Run Conversion')
    lines.append('')
    lines.append('```bash')
    lines.append(f'python convert.py -i inputs/ -o {output_dir} --type both --validate --report')
    lines.append('```')
    lines.append('')

    return '\n'.join(lines)


def generate_plan(
    input_path: str,
    output_dir: str = 'output',
    conv_type: str = 'both',
) -> Path:
    """Main entry point: scan inputs and generate conversion plan MD file."""
    project_root = Path(__file__).resolve().parent.parent

    ws1_results: List[Dict[str, Any]] = []
    ws2_results: List[Dict[str, Any]] = []

    if conv_type in ('both', 'all'):
        sql_dir = project_root / 'inputs' / 'sql'
        if sql_dir.is_dir():
            for f in sorted(sql_dir.glob('*.sql')):
                ws1_results.append(scan_file(f))

        dbt_dir = project_root / 'inputs' / 'dbt_project'
        if dbt_dir.is_dir() and (dbt_dir / 'dbt_project.yml').exists():
            ws2_results = scan_dbt_project(dbt_dir)
    elif conv_type == 'dbt':
        dbt_dir = Path(input_path)
        if dbt_dir.is_dir() and (dbt_dir / 'dbt_project.yml').exists():
            ws2_results = scan_dbt_project(dbt_dir)
    else:
        sql_dir = Path(input_path)
        if sql_dir.is_dir():
            for f in sorted(sql_dir.glob('*.sql')):
                ws1_results.append(scan_file(f))

    plan_content = generate_plan_md(ws1_results, ws2_results, output_dir)

    plan_dir = project_root / 'plans'
    plan_dir.mkdir(parents=True, exist_ok=True)
    plan_path = plan_dir / 'conversion_plan.md'
    plan_path.write_text(plan_content, encoding='utf-8')

    return plan_path


def main() -> None:
    import argparse
    parser = argparse.ArgumentParser(description='Generate conversion plan')
    parser.add_argument('--input', '-i', default='inputs/', help='Input directory')
    parser.add_argument('--output', '-o', default='output', help='Output directory')
    parser.add_argument('--type', '-t', default='both', help='Conversion type')
    args = parser.parse_args()

    plan_path = generate_plan(args.input, args.output, args.type)
    print(f"Conversion plan generated: {plan_path}")


if __name__ == '__main__':
    main()
