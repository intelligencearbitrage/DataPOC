"""
Stored Procedure Converter - Converts Redshift procedures to Databricks SQL.

Handles: CREATE [OR REPLACE] PROCEDURE with PL/pgSQL body.
Databricks does not natively support stored procedures the same way as Redshift.
This converter translates to Databricks SQL notebooks or SQL scripting where possible.

Applies function translations, type mapping, casting, and Redshift construct
removal per knowledgebase/redshift_to_databricks_conversion_guide.pdf.

Usage:
    python scripts/generate_procedures.py
"""

import re
import sys
from pathlib import Path
from typing import Any, Dict, List, Tuple

SCRIPTS_DIR = Path(__file__).resolve().parent
sys.path.insert(0, str(SCRIPTS_DIR))

from base_parser import BaseParser
from base_generator import BaseGenerator
from sql_functions import full_sql_convert, apply_type_mappings, apply_catalog_prefix
from utils import get_timestamp


class ProcedureParser(BaseParser):
    """Parses Redshift SQL files to extract stored procedure definitions."""

    def __init__(self, input_dir: str = 'inputs/sql', output_dir: str = 'output') -> None:
        super().__init__(input_dir=input_dir, output_dir=output_dir)

    def discover_files(self) -> List[Path]:
        return sorted(self.input_dir.glob('*.sql'))

    def parse_file(self, file_path: Path) -> Dict[str, Any]:
        content = file_path.read_text(encoding='utf-8')
        procedures = self._extract_procedures(content, file_path.name)
        drop_procs = self._extract_drop_procedures(content, file_path.name)
        return {
            'source_file': file_path.name,
            'procedures': procedures,
            'drop_procs': drop_procs,
        }

    def _extract_drop_procedures(
        self, sql_content: str, source_file: str
    ) -> List[Dict[str, Any]]:
        """Extract DROP PROCEDURE statements."""
        stmts = []
        pattern = re.compile(
            r'(DROP\s+PROCEDURE\s+(?:IF\s+EXISTS\s+)?[\w.]+(?:\s*\([^)]*\))?)\s*;',
            re.IGNORECASE,
        )
        for match in pattern.finditer(sql_content):
            stmts.append({
                'original_sql': match.group(1).strip(),
                'source_file': source_file,
            })
        return stmts

    def _extract_procedures(
        self, sql_content: str, source_file: str
    ) -> List[Dict[str, Any]]:
        """Extract CREATE PROCEDURE statements."""
        procedures = []

        # Match CREATE [OR REPLACE] PROCEDURE name( ... find balanced parens for params
        header_pattern = re.compile(
            r'CREATE\s+(?:OR\s+REPLACE\s+)?PROCEDURE\s+([\w.]+)\s*\(',
            re.IGNORECASE,
        )

        for header_match in header_pattern.finditer(sql_content):
            full_name = header_match.group(1).strip()
            # Walk balanced parens to find end of param list
            open_pos = header_match.end() - 1  # position of '('
            depth = 1
            i = open_pos + 1
            while i < len(sql_content) and depth > 0:
                ch = sql_content[i]
                if ch == '(':
                    depth += 1
                elif ch == ')':
                    depth -= 1
                i += 1
            if depth != 0:
                continue
            close_pos = i - 1
            params_str = sql_content[open_pos + 1:close_pos].strip()
            header = sql_content[header_match.start():close_pos + 1].strip()

            # Find dollar-quote delimited body after params
            rest = sql_content[close_pos + 1:]
            body_pattern = re.compile(
                r'\s*(.*?)(\$\w*\$)(.*?)\2(.*?;)',
                re.IGNORECASE | re.DOTALL,
            )
            body_match = body_pattern.match(rest)
            if not body_match:
                continue
            options = body_match.group(1).strip()
            body = body_match.group(3).strip()
            trailing = body_match.group(4).strip()

            parts = full_name.split('.')
            schema = parts[0] if len(parts) > 1 else ''
            proc_name = parts[-1]

            params = self._parse_params(params_str)

            procedures.append({
                'schema': schema,
                'proc_name': proc_name,
                'full_name': full_name,
                'header': header,
                'params': params,
                'params_str': params_str,
                'options': options,
                'body': body,
                'trailing': trailing,
                'original_sql': sql_content[header_match.start():close_pos + 1 + body_match.end()],
                'source_file': source_file,
            })

        return procedures

    def _parse_params(self, params_str: str) -> List[Dict[str, str]]:
        """Parse procedure parameter list."""
        if not params_str.strip():
            return []
        params = []
        for param in params_str.split(','):
            param = param.strip()
            if not param:
                continue
            parts = param.split()
            direction = ''
            name = ''
            data_type = ''
            idx = 0
            if parts[0].upper() in ('IN', 'OUT', 'INOUT'):
                direction = parts[0].upper()
                idx = 1
            if idx < len(parts):
                name = parts[idx]
                idx += 1
            if idx < len(parts):
                data_type = ' '.join(parts[idx:])
            params.append({
                'direction': direction,
                'name': name,
                'data_type': data_type,
            })
        return params


class ProcedureGenerator(BaseGenerator):
    """Generates Databricks-compatible procedures from Redshift stored procs."""

    def __init__(self, parsed_data: Dict[str, Any], output_dir: str = 'output', catalog: str = '') -> None:
        super().__init__(plans_dir='plans', output_dir=output_dir, catalog=catalog)
        self.parsed_data = parsed_data
        self.generated_files: List[Dict[str, Any]] = []

    def generate(self) -> None:
        timestamp = get_timestamp()

        for file_key, file_data in self.parsed_data.items():
            source_file = file_data.get('source_file', file_key)
            procedures = file_data.get('procedures', [])

            for proc in procedures:
                converted, conversions = self._convert_procedure(proc, timestamp)
                output_path = f"sql/stored_procedures/{proc['proc_name']}.sql"
                self.save_output(converted, output_path)
                self.generated_files.append({
                    'source_file': source_file,
                    'proc_name': proc['proc_name'],
                    'schema': proc['schema'],
                    'output_file': str(self.output_dir / output_path),
                    'conversions_applied': len(conversions),
                })

            # Generate DROP PROCEDURE conversions
            drop_procs = file_data.get('drop_procs', [])
            for dp in drop_procs:
                sql = dp['original_sql']
                lines = [
                    f"-- Databricks DROP PROCEDURE converted from: {source_file}",
                    f"-- Converted on: {timestamp}",
                    "",
                    f"{sql};",
                    "",
                ]
                output_path = f"sql/stored_procedures/{Path(source_file).stem}_drop.sql"
                self.save_output('\n'.join(lines), output_path)
                self.generated_files.append({
                    'source_file': source_file,
                    'proc_name': f"{Path(source_file).stem}_drop",
                    'schema': '',
                    'output_file': str(self.output_dir / output_path),
                    'conversions_applied': 1,
                })

        self.logger.info(
            f"Generated {len(self.generated_files)} procedure file(s)"
        )

    def _convert_procedure(
        self, proc: Dict[str, Any], timestamp: str
    ) -> Tuple[str, List[str]]:
        """Convert a Redshift stored procedure to Databricks SQL."""
        all_conversions = []
        qualified_name = self.qualify_name(proc['full_name'])

        # NONATOMIC removal (Databricks auto-commits each statement)
        if 'NONATOMIC' in proc.get('options', '').upper():
            all_conversions.append('NONATOMIC removed (Databricks auto-commits each statement)')

        # Convert parameter types
        converted_params = []
        for p in proc['params']:
            if p['data_type']:
                new_type, note = apply_type_mappings(p['data_type'])
                if note:
                    all_conversions.append(f"param {p['name']}: {note}")
                param_str = f"{p['name']} {new_type}"
            else:
                param_str = p['name']
            converted_params.append(param_str)

        # Convert body
        body = proc['body']
        body, fn_convs = full_sql_convert(body)
        all_conversions.extend(fn_convs)

        # Apply Unity Catalog prefix to table references in body
        body, cat_convs = apply_catalog_prefix(body, self.catalog)
        all_conversions.extend(cat_convs)

        # Convert PL/pgSQL constructs
        body, plpgsql_convs = self._convert_plpgsql(body)
        all_conversions.extend(plpgsql_convs)

        # Build output
        lines = [
            f"-- Databricks Stored Procedure: {qualified_name}",
            f"-- Source: {proc['source_file']}",
            f"-- Converted on: {timestamp}",
            "-- Conversion rules: knowledgebase/redshift_to_databricks_conversion_guide.pdf",
            "-- NOTE: Databricks SQL scripting supports stored procedures (DBR 14+).",
            "",
        ]

        if all_conversions:
            lines.append("-- Conversions applied:")
            for c in all_conversions:
                lines.append(f"--   {c}")
            lines.append("")

        params_str = ', '.join(converted_params)
        lines.append(f"CREATE OR REPLACE PROCEDURE {qualified_name}({params_str})")

        # Restructure body to avoid double BEGIN/END nesting.
        # PL/pgSQL: DECLARE ... BEGIN ... END; -> Databricks: DECLARE ... BEGIN ... END;
        # The outer BEGIN wrapper is only needed if body doesn't already have DECLARE...BEGIN structure.
        body_stripped = body.strip()
        # Remove LANGUAGE plpgsql trailer if present
        body_stripped = re.sub(r'\s*LANGUAGE\s+plpgsql\s*;?\s*$', '', body_stripped, flags=re.IGNORECASE).strip()
        # Remove trailing END; if body has its own BEGIN/END block
        has_declare = re.match(r'\s*DECLARE\b', body_stripped, re.IGNORECASE)
        has_begin = re.search(r'\bBEGIN\b', body_stripped, re.IGNORECASE)

        if has_declare and has_begin:
            # Body already has DECLARE...BEGIN...END structure — use it directly
            # Ensure it ends with END;
            if not body_stripped.rstrip().endswith('END;') and not body_stripped.rstrip().endswith('END'):
                body_stripped += '\nEND;'
            elif body_stripped.rstrip().endswith('END') and not body_stripped.rstrip().endswith('END;'):
                body_stripped = body_stripped.rstrip() + ';'
            lines.append(body_stripped)
        elif has_begin:
            # Body has BEGIN but no DECLARE — use as-is
            if not body_stripped.rstrip().endswith('END;') and not body_stripped.rstrip().endswith('END'):
                body_stripped += '\nEND;'
            elif body_stripped.rstrip().endswith('END') and not body_stripped.rstrip().endswith('END;'):
                body_stripped = body_stripped.rstrip() + ';'
            lines.append(body_stripped)
        else:
            # No structure — wrap in BEGIN/END
            lines.append("BEGIN")
            lines.append(body_stripped)
            lines.append("END;")
        lines.append("")

        return '\n'.join(lines), all_conversions

    @staticmethod
    def _convert_raise_to_select(match: re.Match) -> str:
        """Convert RAISE with % placeholders to SELECT CONCAT."""
        fmt_string = match.group(1)
        args_str = match.group(2)
        if args_str:
            args = [a.strip() for a in args_str.split(',') if a.strip()]
        else:
            args = []
        parts = fmt_string.split('%')
        if len(parts) == 1 or not args:
            return f"SELECT '{fmt_string}' AS debug_message"
        concat_pieces = []
        for i, part in enumerate(parts):
            if part:
                concat_pieces.append(f"'{part}'")
            if i < len(args):
                concat_pieces.append(f"CAST({args[i]} AS STRING)")
        if len(concat_pieces) == 1:
            return f"SELECT {concat_pieces[0]} AS debug_message"
        return f"SELECT CONCAT({', '.join(concat_pieces)}) AS debug_message"

    def _convert_plpgsql(self, body: str) -> Tuple[str, List[str]]:
        """Convert PL/pgSQL constructs to Databricks SQL scripting."""
        conversions = []

        # RAISE NOTICE -> SELECT debug_message (keep as debug output)
        raise_notice_pattern = re.compile(
            r"RAISE\s+NOTICE\s+'([^']*)'(?:\s*,\s*([^;]+))?",
            re.IGNORECASE,
        )
        if raise_notice_pattern.search(body):
            body = raise_notice_pattern.sub(lambda m: self._convert_raise_to_select(m), body)
            conversions.append('PL/pgSQL: RAISE NOTICE -> SELECT debug message')

        # RAISE INFO -> comment out (informational only, not needed in Databricks)
        raise_info_pattern = re.compile(
            r"RAISE\s+INFO\s+'([^']*)'(?:\s*,\s*([^;]+))?",
            re.IGNORECASE,
        )
        if raise_info_pattern.search(body):
            def _convert_raise_info(m):
                msg = m.group(1)
                return f"-- INFO: {msg}"
            body = raise_info_pattern.sub(_convert_raise_info, body)
            conversions.append('PL/pgSQL: RAISE INFO -> commented out')

        # RAISE WARNING -> SIGNAL SQLSTATE '01000' (warning class)
        raise_warning_pattern = re.compile(
            r"RAISE\s+WARNING\s+'([^']*)'(?:\s*,\s*([^;]+))?",
            re.IGNORECASE,
        )
        if raise_warning_pattern.search(body):
            body = raise_warning_pattern.sub(
                r"SIGNAL SQLSTATE '01000' SET MESSAGE_TEXT = '\1'",
                body,
            )
            conversions.append('PL/pgSQL: RAISE WARNING -> SIGNAL SQLSTATE 01000')

        # RAISE EXCEPTION -> SIGNAL SQLSTATE
        exception_pattern = re.compile(
            r"RAISE\s+EXCEPTION\s+'([^']*)'",
            re.IGNORECASE,
        )
        if exception_pattern.search(body):
            body = exception_pattern.sub(
                r"SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = '\1'",
                body,
            )
            conversions.append('PL/pgSQL: RAISE EXCEPTION -> SIGNAL SQLSTATE')

        # Bare RAISE; (re-raise in exception block) -> RESIGNAL
        bare_raise_pattern = re.compile(r'\bRAISE\s*;', re.IGNORECASE)
        if bare_raise_pattern.search(body):
            body = bare_raise_pattern.sub('RESIGNAL; -- re-raise current exception', body)
            conversions.append('PL/pgSQL: RAISE (re-raise) -> RESIGNAL')

        # PERFORM stmt -> call the statement directly (PERFORM is Redshift-only)
        perform_pattern = re.compile(r'\bPERFORM\s+', re.IGNORECASE)
        if perform_pattern.search(body):
            body = perform_pattern.sub('', body)
            conversions.append('PL/pgSQL: PERFORM -> direct call')

        # EXECUTE 'dynamic sql' -> EXECUTE IMMEDIATE
        execute_pattern = re.compile(r'\bEXECUTE\s+(?!IMMEDIATE)', re.IGNORECASE)
        if execute_pattern.search(body):
            body = execute_pattern.sub('EXECUTE IMMEDIATE ', body)
            conversions.append('PL/pgSQL: EXECUTE -> EXECUTE IMMEDIATE')

        # PL/pgSQL assignment: var := expr
        # Inside DECLARE blocks: var TYPE := val -> var TYPE DEFAULT val
        # Outside DECLARE: var := expr -> SET var = expr
        declare_match = re.search(r'\bDECLARE\b', body, re.IGNORECASE)
        begin_match = re.search(r'\bBEGIN\b', body, re.IGNORECASE)
        if declare_match and begin_match and declare_match.start() < begin_match.start():
            # Convert := inside DECLARE to DEFAULT
            declare_section = body[declare_match.end():begin_match.start()]
            declare_converted = re.sub(r'\s*:=\s*', ' DEFAULT ', declare_section)
            if declare_converted != declare_section:
                conversions.append('PL/pgSQL: var := init -> var DEFAULT init (in DECLARE)')
            # Convert := outside DECLARE (in the body after BEGIN) to SET var =
            body_section = body[begin_match.start():]
            assign_pattern = re.compile(r'\b(\w+)\s*:=\s*')
            if assign_pattern.search(body_section):
                body_section = assign_pattern.sub(r'SET \1 = ', body_section)
                conversions.append('PL/pgSQL: var := expr -> SET var = expr')
            body = body[:declare_match.end()] + declare_converted + body_section
        else:
            # No DECLARE block — convert all := to SET
            assign_pattern = re.compile(r'\b(\w+)\s*:=\s*')
            if assign_pattern.search(body):
                body = assign_pattern.sub(r'SET \1 = ', body)
                conversions.append('PL/pgSQL: var := expr -> SET var = expr')

        # FOR i IN REVERSE N..1 LOOP -> WHILE (decrement) (must be BEFORE range and query patterns)
        for_reverse_pattern = re.compile(
            r'\bFOR\s+(\w+)\s+IN\s+REVERSE\s+(\S+?)\s*\.\.\s*(\S+?)\s+LOOP\b',
            re.IGNORECASE,
        )
        if for_reverse_pattern.search(body):
            def _convert_for_reverse(m):
                var, start_val, end_val = m.group(1), m.group(2), m.group(3)
                return f"DECLARE {var} INT DEFAULT {start_val};\nWHILE {var} >= {end_val} DO"
            body = for_reverse_pattern.sub(_convert_for_reverse, body)
            conversions.append('PL/pgSQL: FOR...IN REVERSE...LOOP -> WHILE (decrement) DO')

        # FOR i IN 1..N LOOP -> WHILE with counter (must be BEFORE query FOR pattern)
        for_range_pattern = re.compile(
            r'\bFOR\s+(\w+)\s+IN\s+(\S+?)\s*\.\.\s*(\S+?)\s+LOOP\b',
            re.IGNORECASE,
        )
        if for_range_pattern.search(body):
            def _convert_for_range(m):
                var, start_val, end_val = m.group(1), m.group(2), m.group(3)
                return f"DECLARE {var} INT DEFAULT {start_val};\nWHILE {var} <= {end_val} DO"
            body = for_range_pattern.sub(_convert_for_range, body)
            conversions.append('PL/pgSQL: FOR...IN range LOOP -> WHILE DO (with counter)')

        # FOR rec IN query LOOP -> FOR rec AS cursor CURSOR FOR query DO (HIGH-11: no global END LOOP replace)
        for_loop_pattern = re.compile(
            r'\bFOR\s+(\w+)\s+IN\s+(.*?)\s+LOOP\b',
            re.IGNORECASE | re.DOTALL,
        )
        has_for = bool(for_loop_pattern.search(body))
        if has_for:
            body = for_loop_pattern.sub(
                r'FOR \1 AS \1_cursor CURSOR FOR \2 DO',
                body,
            )
            conversions.append('PL/pgSQL: FOR...IN...LOOP -> FOR...AS CURSOR...DO...END FOR')

        # WHILE condition LOOP -> WHILE condition DO
        while_pattern = re.compile(
            r'\bWHILE\s+(.*?)\s+LOOP\b',
            re.IGNORECASE | re.DOTALL,
        )
        has_while = bool(while_pattern.search(body))
        if has_while:
            body = while_pattern.sub(r'WHILE \1 DO', body)
            conversions.append('PL/pgSQL: WHILE...LOOP -> WHILE...DO...END WHILE')

        # HIGH-11: Context-aware END LOOP replacement using stack
        if has_for or has_while:
            lines = body.split('\n')
            loop_stack = []  # tracks 'FOR' or 'WHILE'
            for i, line in enumerate(lines):
                stripped = line.strip().upper()
                if re.match(r'\bFOR\b.*\bDO\b', stripped):
                    loop_stack.append('FOR')
                elif re.match(r'\bWHILE\b.*\bDO\b', stripped):
                    loop_stack.append('WHILE')
                elif re.match(r'\bEND\s+LOOP\b', stripped):
                    if loop_stack:
                        loop_type = loop_stack.pop()
                    else:
                        loop_type = 'FOR'  # default fallback
                    end_kw = 'END FOR' if loop_type == 'FOR' else 'END WHILE'
                    lines[i] = re.sub(r'\bEND\s+LOOP\b', end_kw, line, flags=re.IGNORECASE)
            body = '\n'.join(lines)

        # EXCEPTION WHEN ... THEN -> DECLARE EXIT HANDLER FOR ...
        exception_block_pattern = re.compile(
            r'\bEXCEPTION\s+WHEN\s+(\w+)\s+THEN\s+(.*?)(?=\bEND\b)',
            re.IGNORECASE | re.DOTALL,
        )
        if exception_block_pattern.search(body):
            def convert_exception(m):
                condition = m.group(1).strip()
                handler_body = m.group(2).strip()
                # Map common PL/pgSQL exception names to SQLSTATE
                sqlstate_map = {
                    'OTHERS': None,  # Use FOR SQLEXCEPTION instead of SQLSTATE
                    'NO_DATA_FOUND': "'02000'",
                    'TOO_MANY_ROWS': "'21000'",
                    'UNIQUE_VIOLATION': "'23505'",
                    'FOREIGN_KEY_VIOLATION': "'23503'",
                    'NOT_NULL_VIOLATION': "'23502'",
                }
                sqlstate = sqlstate_map.get(condition.upper(), f"'45000' /* was: {condition} */")
                if sqlstate is None:
                    handler_clause = "DECLARE EXIT HANDLER FOR SQLEXCEPTION"
                else:
                    handler_clause = f"DECLARE EXIT HANDLER FOR SQLSTATE {sqlstate}"
                return (
                    f"-- NOTE: PL/pgSQL EXCEPTION block converted to Databricks handler\n"
                    f"{handler_clause}\n"
                    f"BEGIN\n{handler_body}\nEND;\n"
                )
            body = exception_block_pattern.sub(convert_exception, body)
            conversions.append('PL/pgSQL: EXCEPTION WHEN -> DECLARE EXIT HANDLER FOR SQLSTATE')

        # IF/ELSIF/ELSE -> IF/ELSEIF/ELSE (Databricks syntax)
        elsif_pattern = re.compile(r'\bELSIF\b', re.IGNORECASE)
        if elsif_pattern.search(body):
            body = elsif_pattern.sub('ELSEIF', body)
            conversions.append('PL/pgSQL: ELSIF -> ELSEIF')

        # Labeled Loops: <<label>> -> label:
        label_def_pattern = re.compile(r'<<(\w+)>>')
        if label_def_pattern.search(body):
            body = label_def_pattern.sub(r'\1:', body)
            conversions.append('PL/pgSQL: <<label>> -> label:')

        # EXIT label WHEN condition -> IF condition THEN LEAVE label; END IF;
        exit_label_when = re.compile(r'\bEXIT\s+(\w+)\s+WHEN\s+(.+?)\s*;', re.IGNORECASE | re.DOTALL)
        if exit_label_when.search(body):
            body = exit_label_when.sub(r'IF \2 THEN LEAVE \1; END IF;', body)
            conversions.append('PL/pgSQL: EXIT label WHEN -> IF THEN LEAVE label')

        # EXIT label (without WHEN) -> LEAVE label;
        exit_label_bare = re.compile(r'\bEXIT\s+(\w+)\s*;', re.IGNORECASE)
        if exit_label_bare.search(body):
            body = exit_label_bare.sub(r'LEAVE \1;', body)
            conversions.append('PL/pgSQL: EXIT label -> LEAVE label')

        # EXIT WHEN condition -> IF condition THEN LEAVE; END IF; (unlabeled)
        exit_when_pattern = re.compile(
            r'\bEXIT\s+WHEN\s+(.+?)\s*;',
            re.IGNORECASE | re.DOTALL,
        )
        if exit_when_pattern.search(body):
            body = exit_when_pattern.sub(r'IF \1 THEN LEAVE; END IF;', body)
            conversions.append('PL/pgSQL: EXIT WHEN -> IF condition THEN LEAVE')

        # Bare EXIT -> LEAVE (must come AFTER labeled EXIT patterns)
        bare_exit_pattern = re.compile(r'\bEXIT\s*;', re.IGNORECASE)
        if bare_exit_pattern.search(body):
            body = bare_exit_pattern.sub('LEAVE;', body)
            conversions.append('PL/pgSQL: EXIT -> LEAVE')

        # CONTINUE WHEN -> IF THEN ITERATE
        continue_when_pattern = re.compile(r'\bCONTINUE\s+WHEN\s+(.+?)\s*;', re.IGNORECASE | re.DOTALL)
        if continue_when_pattern.search(body):
            body = continue_when_pattern.sub(r'IF \1 THEN ITERATE; END IF;', body)
            conversions.append('PL/pgSQL: CONTINUE WHEN -> IF THEN ITERATE')

        # Bare CONTINUE -> ITERATE
        bare_continue = re.compile(r'\bCONTINUE\s*;', re.IGNORECASE)
        if bare_continue.search(body):
            body = bare_continue.sub('ITERATE;', body)
            conversions.append('PL/pgSQL: CONTINUE -> ITERATE')

        # RETURN QUERY -> nested cursor or temp view
        return_query_pattern = re.compile(r'\bRETURN\s+QUERY\b', re.IGNORECASE)
        if return_query_pattern.search(body):
            body = return_query_pattern.sub(
                '-- NOTE: RETURN QUERY not supported in Databricks SQL scripting.\n-- Use a temp view or return table instead.\nSELECT * FROM',
                body,
            )
            conversions.append('PL/pgSQL: RETURN QUERY -> advisory (use temp view)')

        # GET STACKED DIAGNOSTICS -> GET DIAGNOSTICS CONDITION 1
        get_stacked_pattern = re.compile(r'\bGET\s+STACKED\s+DIAGNOSTICS\b', re.IGNORECASE)
        if get_stacked_pattern.search(body):
            body = get_stacked_pattern.sub('GET DIAGNOSTICS CONDITION 1', body)
            conversions.append('PL/pgSQL: GET STACKED DIAGNOSTICS -> GET DIAGNOSTICS CONDITION 1')

        # GET DIAGNOSTICS row_count = ROW_COUNT -> SET row_count = ROW_COUNT()
        get_diag_pattern = re.compile(
            r'\bGET\s+DIAGNOSTICS\s+(\w+)\s*=\s*ROW_COUNT\b',
            re.IGNORECASE,
        )
        if get_diag_pattern.search(body):
            body = get_diag_pattern.sub(r'SET \1 = ROW_COUNT()', body)
            conversions.append('PL/pgSQL: GET DIAGNOSTICS ROW_COUNT -> ROW_COUNT()')

        # OPEN cursor FOR query -> DECLARE cursor CURSOR FOR query
        open_cursor_pattern = re.compile(
            r'\bOPEN\s+(\w+)\s+FOR\s+',
            re.IGNORECASE,
        )
        if open_cursor_pattern.search(body):
            body = open_cursor_pattern.sub(r'DECLARE \1 CURSOR FOR ', body)
            conversions.append('PL/pgSQL: OPEN cursor FOR -> DECLARE CURSOR FOR')

        # FETCH cursor INTO vars -> FETCH cursor INTO vars (identical syntax in Databricks)
        # CLOSE cursor -> CLOSE cursor (identical)

        # COMMIT inside procedures -> advisory removal (Databricks auto-commits)
        commit_pattern = re.compile(r'\bCOMMIT\s*;', re.IGNORECASE)
        if commit_pattern.search(body):
            body = commit_pattern.sub('-- COMMIT removed (Databricks auto-commits each statement);', body)
            conversions.append('PL/pgSQL: COMMIT removed (Databricks auto-commits)')

        # ROLLBACK inside procedures -> advisory removal
        rollback_pattern = re.compile(r'\bROLLBACK\s*;', re.IGNORECASE)
        if rollback_pattern.search(body):
            body = rollback_pattern.sub('-- ROLLBACK removed (use Delta time travel for recovery);', body)
            conversions.append('PL/pgSQL: ROLLBACK removed (use Delta time travel)')

        # Variable declarations: convert types inside DECLARE blocks
        body, declare_convs = self._convert_declare_block(body)
        conversions.extend(declare_convs)

        # Post-processing: relocate DECLARE EXIT HANDLER blocks to before first executable statement
        body = self._relocate_exit_handlers(body)

        return body, conversions

    @staticmethod
    def _relocate_exit_handlers(body: str) -> str:
        """Move DECLARE EXIT HANDLER blocks to after variable declarations, before executable statements.

        Databricks requires handlers to be declared before executable statements.
        This collects any DECLARE EXIT HANDLER blocks and re-inserts them at the
        correct position within the BEGIN block.
        """
        body_lines = body.split('\n')

        # Collect handler blocks (comment line + DECLARE EXIT HANDLER + BEGIN...END;)
        handler_blocks: List[str] = []
        non_handler_lines: List[str] = []
        i = 0
        while i < len(body_lines):
            line = body_lines[i]
            stripped = line.strip().upper()
            # Check if this is a handler comment line followed by DECLARE EXIT HANDLER
            if '-- NOTE: PL/PGSQL EXCEPTION BLOCK' in stripped.upper():
                block = [body_lines[i]]
                i += 1
                # Collect the DECLARE EXIT HANDLER line and its BEGIN...END body
                while i < len(body_lines):
                    block.append(body_lines[i])
                    if body_lines[i].strip().upper().startswith('END;') or body_lines[i].strip().upper() == 'END;':
                        i += 1
                        break
                    i += 1
                handler_blocks.append('\n'.join(block))
            elif 'DECLARE EXIT HANDLER' in stripped:
                block = [body_lines[i]]
                i += 1
                # Collect the BEGIN...END body
                while i < len(body_lines):
                    block.append(body_lines[i])
                    if body_lines[i].strip().upper().startswith('END;') or body_lines[i].strip().upper() == 'END;':
                        i += 1
                        break
                    i += 1
                handler_blocks.append('\n'.join(block))
            else:
                non_handler_lines.append(body_lines[i])
                i += 1

        if not handler_blocks:
            return body

        # Find insertion point in non_handler_lines: after DECLARE vars, before first executable
        executable_keywords = re.compile(
            r'^\s*(SET|SELECT|IF|FOR|WHILE|INSERT|UPDATE|DELETE|CALL|EXECUTE|MERGE|CREATE|DROP|ALTER|TRUNCATE|SIGNAL)\b',
            re.IGNORECASE,
        )
        insert_idx = 0
        inside_begin = False
        for idx, line in enumerate(non_handler_lines):
            stripped = line.strip().upper()
            if stripped == 'BEGIN' or stripped.startswith('BEGIN'):
                inside_begin = True
                insert_idx = idx + 1
                continue
            if inside_begin:
                if not line.strip() or line.strip().startswith('--'):
                    insert_idx = idx + 1
                    continue
                # Check if this is a DECLARE variable (not handler)
                if stripped.startswith('DECLARE') and 'EXIT HANDLER' not in stripped:
                    insert_idx = idx + 1
                    continue
                if executable_keywords.match(line):
                    insert_idx = idx
                    break

        # Insert handler blocks at the correct position
        handler_text = handler_blocks
        for h_idx, handler in enumerate(reversed(handler_text)):
            non_handler_lines.insert(insert_idx, handler)

        return '\n'.join(non_handler_lines)

    def _convert_declare_block(self, body: str) -> Tuple[str, List[str]]:
        """Convert variable types inside DECLARE blocks.

        - Removes RECORD type declarations (cursor var doesn't need pre-declaration)
        - Converts VARCHAR(n)/VARCHAR -> STRING
        - Converts other Redshift types using DATA_TYPE_MAP
        """
        conversions = []
        declare_match = re.search(r'\bDECLARE\b', body, re.IGNORECASE)
        if not declare_match:
            return body, conversions

        # Find the DECLARE block: from DECLARE to the next BEGIN
        declare_start = declare_match.start()
        begin_match = re.search(r'\bBEGIN\b', body[declare_match.end():], re.IGNORECASE)
        if not begin_match:
            return body, conversions

        declare_end = declare_match.end() + begin_match.start()
        declare_block = body[declare_match.end():declare_end]

        # Process each line in the DECLARE block
        new_lines = []
        for line in declare_block.split('\n'):
            stripped = line.strip()
            if not stripped or stripped == ';':
                new_lines.append(line)
                continue

            # %ROWTYPE -> comment out (not supported in Databricks)
            if re.search(r'%ROWTYPE\b', stripped, re.IGNORECASE):
                indent = line[:len(line) - len(line.lstrip())] if line.strip() else '  '
                new_lines.append(f'{indent}-- {stripped} -- NOTE: %ROWTYPE not supported in Databricks, use explicit variables')
                conversions.append('PL/pgSQL: %ROWTYPE removed (not supported)')
                continue

            # %TYPE -> resolve to STRING (best guess)
            if re.search(r'%TYPE\b', stripped, re.IGNORECASE):
                stripped = re.sub(r'[\w.]+%TYPE', 'STRING /* was %TYPE */', stripped, flags=re.IGNORECASE)
                conversions.append('PL/pgSQL: %TYPE -> STRING (verify actual type)')

            # CONSTANT keyword removal (not supported in Databricks)
            if re.search(r'\bCONSTANT\s+', stripped, re.IGNORECASE):
                stripped = re.sub(r'\bCONSTANT\s+', '', stripped, flags=re.IGNORECASE)
                conversions.append('PL/pgSQL: CONSTANT removed (not supported in Databricks)')

            # Remove RECORD type declarations entirely (cursor handles it)
            if re.search(r'\bRECORD\b', stripped, re.IGNORECASE):
                conversions.append(f'PL/pgSQL: removed RECORD declaration (cursor variable needs no pre-declaration)')
                continue

            # Convert types in variable declarations: var_name TYPE;
            var_decl = re.match(r'^(\s*\w+)\s+(.+?)\s*;?\s*$', stripped)
            if var_decl:
                var_name_part = var_decl.group(1)
                type_part = var_decl.group(2).rstrip(';').strip()
                new_type, note = apply_type_mappings(type_part)
                if note:
                    indent = line[:len(line) - len(line.lstrip())]
                    new_lines.append(f'{indent}{var_name_part.strip()} {new_type};')
                    conversions.append(f'DECLARE var: {note}')
                else:
                    new_lines.append(line)
            else:
                new_lines.append(line)

        new_declare_block = '\n'.join(new_lines)
        body = body[:declare_match.end()] + new_declare_block + body[declare_end:]
        return body, conversions


def main() -> None:
    parser = ProcedureParser()
    parser.parse_all()
    generator = ProcedureGenerator(parser.parsed_data)
    generator.generate()
    print(
        f"Procedure conversion complete: "
        f"{len(generator.generated_files)} file(s) generated"
    )


if __name__ == '__main__':
    main()
