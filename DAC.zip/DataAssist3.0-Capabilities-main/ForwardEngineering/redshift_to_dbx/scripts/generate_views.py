"""
View & Materialized View Converter - Converts Redshift views to Databricks SQL.

Handles: CREATE VIEW, CREATE OR REPLACE VIEW, CREATE MATERIALIZED VIEW,
         LATE BINDING views, views with UNION ALL, views with function calls.

Applies function translations, type mapping, casting, and Redshift construct
removal per knowledgebase/redshift_to_databricks_conversion_guide.pdf.

Usage:
    python scripts/generate_views.py
"""

import re
import sys
from pathlib import Path
from typing import Any, Dict, List, Tuple

SCRIPTS_DIR = Path(__file__).resolve().parent
sys.path.insert(0, str(SCRIPTS_DIR))

from base_parser import BaseParser
from base_generator import BaseGenerator
from sql_functions import full_sql_convert, apply_construct_removals, apply_catalog_prefix
from utils import get_timestamp


class ViewParser(BaseParser):
    """Parses Redshift SQL files to extract VIEW definitions."""

    def __init__(self, input_dir: str = 'inputs/sql', output_dir: str = 'output') -> None:
        super().__init__(input_dir=input_dir, output_dir=output_dir)

    def discover_files(self) -> List[Path]:
        return sorted(self.input_dir.glob('*.sql'))

    def parse_file(self, file_path: Path) -> Dict[str, Any]:
        content = file_path.read_text(encoding='utf-8')
        views = self._extract_views(content, file_path.name)
        drop_views = self._extract_drop_views(content, file_path.name)
        alter_views = self._extract_alter_views(content, file_path.name)
        refresh_mvs = self._extract_refresh_mvs(content, file_path.name)
        return {
            'source_file': file_path.name,
            'views': views,
            'drop_views': drop_views,
            'alter_views': alter_views,
            'refresh_mvs': refresh_mvs,
        }

    def _extract_views(
        self, sql_content: str, source_file: str
    ) -> List[Dict[str, Any]]:
        """Extract CREATE VIEW and CREATE MATERIALIZED VIEW statements."""
        views = []

        # Match CREATE [OR REPLACE] [MATERIALIZED] VIEW schema.name [options] AS ...;
        # Options can include DISTKEY(...), SORTKEY(...), AUTO REFRESH, etc. before AS
        # Also handles optional column list: CREATE VIEW name (col1, col2) AS ...
        # Semicolon is optional for the last statement in a file
        pattern = re.compile(
            r'(CREATE\s+(?:OR\s+REPLACE\s+)?(?:MATERIALIZED\s+)?VIEW\s+'
            r'([\w.]+)'
            r'(?:\s*\([^)]*\))?'  # optional column list
            r'(?:\s+(?:DISTKEY|DISTSTYLE|SORTKEY|COMPOUND\s+SORTKEY|INTERLEAVED\s+SORTKEY|AUTO\s+REFRESH|BACKUP)\b[^;]*?)?'
            r'\s+AS\s+)'
            r'(.*?)(?:;|$)',
            re.IGNORECASE | re.DOTALL,
        )

        for match in pattern.finditer(sql_content):
            header = match.group(1).strip()
            full_name = match.group(2).strip()
            body = match.group(3).strip()
            original = match.group(0)

            is_materialized = bool(
                re.search(r'\bMATERIALIZED\b', header, re.IGNORECASE)
            )
            parts = full_name.split('.')
            schema = parts[0] if len(parts) > 1 else ''
            view_name = parts[-1]

            views.append({
                'schema': schema,
                'view_name': view_name,
                'full_name': full_name,
                'header': header,
                'body': body,
                'original_sql': original,
                'is_materialized': is_materialized,
                'source_file': source_file,
            })

        return views

    def _extract_drop_views(
        self, sql_content: str, source_file: str
    ) -> List[Dict[str, Any]]:
        """Extract DROP VIEW statements."""
        stmts = []
        pattern = re.compile(
            r'(DROP\s+(?:MATERIALIZED\s+)?VIEW\s+(?:IF\s+EXISTS\s+)?[\w.]+(?:\s+CASCADE)?)\s*;',
            re.IGNORECASE,
        )
        for match in pattern.finditer(sql_content):
            stmts.append({
                'original_sql': match.group(1).strip(),
                'source_file': source_file,
            })
        return stmts

    def _extract_alter_views(
        self, sql_content: str, source_file: str
    ) -> List[Dict[str, Any]]:
        """Extract ALTER VIEW statements."""
        stmts = []
        pattern = re.compile(
            r'(ALTER\s+VIEW\s+[\w.]+\s+.+?)\s*;',
            re.IGNORECASE | re.DOTALL,
        )
        for match in pattern.finditer(sql_content):
            stmts.append({
                'original_sql': match.group(1).strip(),
                'source_file': source_file,
            })
        return stmts

    def _extract_refresh_mvs(
        self, sql_content: str, source_file: str
    ) -> List[Dict[str, Any]]:
        """Extract REFRESH MATERIALIZED VIEW statements."""
        stmts = []
        pattern = re.compile(
            r'(REFRESH\s+MATERIALIZED\s+VIEW\s+[\w.]+)\s*;',
            re.IGNORECASE,
        )
        for match in pattern.finditer(sql_content):
            stmts.append({
                'original_sql': match.group(1).strip(),
                'source_file': source_file,
            })
        return stmts


class ViewGenerator(BaseGenerator):
    """Generates Databricks-compatible VIEW definitions."""

    def __init__(self, parsed_data: Dict[str, Any], output_dir: str = 'output', catalog: str = '') -> None:
        super().__init__(plans_dir='plans', output_dir=output_dir, catalog=catalog)
        self.parsed_data = parsed_data
        self.generated_files: List[Dict[str, Any]] = []

    def generate(self) -> None:
        timestamp = get_timestamp()

        for file_key, file_data in self.parsed_data.items():
            source_file = file_data.get('source_file', file_key)
            views = file_data.get('views', [])

            for view in views:
                converted, conversions = self._convert_view(view, timestamp)

                if view['is_materialized']:
                    subdir = 'sql/materialized_views'
                else:
                    subdir = 'sql/views'

                output_path = f"{subdir}/{view['view_name']}.sql"
                self.save_output(converted, output_path)
                self.generated_files.append({
                    'source_file': source_file,
                    'view_name': view['view_name'],
                    'schema': view['schema'],
                    'is_materialized': view['is_materialized'],
                    'output_file': str(self.output_dir / output_path),
                    'conversions_applied': len(conversions),
                })

            # Generate DROP VIEW conversions
            drop_views = file_data.get('drop_views', [])
            for dv in drop_views:
                sql = dv['original_sql']
                # Handle CASCADE
                if re.search(r'\bCASCADE\b', sql, re.IGNORECASE):
                    sql = re.sub(r'\s+CASCADE\b', '', sql, flags=re.IGNORECASE)
                    sql = f"-- NOTE: CASCADE not supported in Databricks. Drop dependent objects manually.\n{sql}"
                self._append_utility_stmt(source_file, timestamp, sql, 'drop_view')

            # Generate ALTER VIEW conversions
            alter_views = file_data.get('alter_views', [])
            for av in alter_views:
                sql = av['original_sql']
                converted, _ = full_sql_convert(sql)
                self._append_utility_stmt(source_file, timestamp, converted, 'alter_view')

            # Generate REFRESH MV conversions
            refresh_mvs = file_data.get('refresh_mvs', [])
            for rm in refresh_mvs:
                sql = rm['original_sql']
                # REFRESH MATERIALIZED VIEW is supported in Databricks
                self._append_utility_stmt(source_file, timestamp, sql, 'refresh_mv')

        self.logger.info(f"Generated {len(self.generated_files)} view file(s)")

    def _append_utility_stmt(
        self, source_file: str, timestamp: str, sql: str, stmt_type: str
    ) -> None:
        """Helper to save a utility statement (DROP/ALTER/REFRESH)."""
        lines = [
            f"-- Databricks {stmt_type} converted from: {source_file}",
            f"-- Converted on: {timestamp}",
            "",
            f"{sql};",
            "",
        ]
        output_path = f"sql/views/{Path(source_file).stem}_{stmt_type}.sql"
        self.save_output('\n'.join(lines), output_path)
        self.generated_files.append({
            'source_file': source_file,
            'view_name': f"{Path(source_file).stem}_{stmt_type}",
            'schema': '',
            'is_materialized': 'mv' in stmt_type,
            'output_file': str(self.output_dir / output_path),
            'conversions_applied': 1,
        })

    def _convert_view(
        self, view: Dict[str, Any], timestamp: str
    ) -> Tuple[str, List[str]]:
        """Convert a single view to Databricks SQL."""
        all_conversions = []
        header = view['header']
        body = view['body']
        qualified_name = self.qualify_name(view['full_name'])

        # Handle Materialized Views
        if view['is_materialized']:
            header, body, mv_convs = self._convert_materialized_view(
                header, body, view
            )
            all_conversions.extend(mv_convs)

        # Remove WITH NO SCHEMA BINDING
        header, removals = apply_construct_removals(header)
        all_conversions.extend(removals)

        # Ensure CREATE OR REPLACE
        if 'OR REPLACE' not in header.upper():
            header = re.sub(
                r'\bCREATE\s+(MATERIALIZED\s+)?VIEW\b',
                r'CREATE OR REPLACE \1VIEW',
                header,
                flags=re.IGNORECASE,
            )
            all_conversions.append('Added OR REPLACE')

        # Apply Unity Catalog prefix to view name in header
        if self.catalog and view['full_name'] != qualified_name:
            header = header.replace(view['full_name'], qualified_name)

        # Apply function translations to body
        body, fn_convs = full_sql_convert(body)
        all_conversions.extend(fn_convs)

        # Apply Unity Catalog prefix to table references in body
        body, cat_convs = apply_catalog_prefix(body, self.catalog)
        all_conversions.extend(cat_convs)

        # Remove WITH NO SCHEMA BINDING from body
        body, body_removals = apply_construct_removals(body)
        all_conversions.extend(body_removals)

        # Build output
        lines = [
            f"-- Databricks View: {qualified_name}",
            f"-- Source: {view['source_file']}",
            f"-- Converted on: {timestamp}",
            "-- Conversion rules: knowledgebase/redshift_to_databricks_conversion_guide.pdf",
            "",
        ]

        if all_conversions:
            lines.append("-- Conversions applied:")
            for c in all_conversions:
                lines.append(f"--   {c}")
            lines.append("")

        lines.append(f"{header}")
        lines.append(f"{body};")
        lines.append("")

        return '\n'.join(lines), all_conversions

    def _convert_materialized_view(
        self, header: str, body: str, view: Dict[str, Any]
    ) -> Tuple[str, str, List[str]]:
        """Convert Materialized View to Databricks equivalent."""
        conversions = []

        # Remove AUTO REFRESH
        header = re.sub(
            r'\s+AUTO\s+REFRESH\s+(?:YES|NO)',
            '',
            header,
            flags=re.IGNORECASE,
        )

        # Remove REFRESH MATERIALIZED VIEW statements nearby
        # Databricks MVs auto-refresh

        conversions.append(
            'Materialized View: Databricks MVs require SQL Pro/Serverless warehouse'
        )
        conversions.append(
            'Materialized View: AUTO REFRESH removed -> Databricks manages MV refresh via scheduled refresh or REFRESH MATERIALIZED VIEW command'
        )

        return header, body, conversions


def main() -> None:
    parser = ViewParser()
    parser.parse_all()
    generator = ViewGenerator(parser.parsed_data)
    generator.generate()
    print(f"View conversion complete: {len(generator.generated_files)} file(s) generated")


if __name__ == '__main__':
    main()
