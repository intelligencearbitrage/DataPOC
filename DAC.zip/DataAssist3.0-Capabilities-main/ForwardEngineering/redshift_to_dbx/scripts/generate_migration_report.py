"""
Migration Report Generator — Produces output/migration_report.md.

Generates a comprehensive migration report with:
  1. Executive Summary (WS1 + WS2 metrics)
  2. Conversion Results by Type
  3. Input-to-Output File Mapping
  4. Per-File Conversion Details (reads actual conversion comments from output)
  5. Data Type Mapping Rules (38 types)
  6. Function Translation Rules (122 functions)
  7. Construct Removal & Advisory Rules
  8. dbt-Specific Conversion Rules (WS2)
  9. Validation Summary

Can be invoked standalone or imported by convert.py.

Usage:
    python scripts/generate_migration_report.py -i inputs/sql -o output
    python scripts/generate_migration_report.py -i inputs/ -o output --elapsed 12.3

    # Or import:
    from generate_migration_report import generate_report
"""

import argparse
import sys
from pathlib import Path
from typing import Any, Dict, List

SCRIPTS_DIR = Path(__file__).resolve().parent
PROJECT_ROOT = SCRIPTS_DIR.parent
sys.path.insert(0, str(SCRIPTS_DIR))

import re

from utils import get_timestamp


def _sanitize_path(raw: str, allowed_base: Path) -> Path:
    """Resolve a user-supplied path, anchored to allowed_base, rejecting traversal."""
    if not raw:
        raise ValueError("Empty path")
    safe = re.sub(r'[^\w.\-/\\ ]', '', raw)
    if safe != raw:
        raise ValueError(f"Path contains disallowed characters: {raw!r}")
    if '..' in safe.replace('\\', '/').split('/'):
        raise ValueError(f"Path traversal blocked: {raw!r}")
    candidate = (allowed_base / safe).resolve()
    if not candidate.is_relative_to(allowed_base.resolve()):
        raise ValueError(
            f"Path traversal blocked: {raw!r} escapes {allowed_base}"
        )
    return candidate


# ---------------------------------------------------------------------------
# Report generation (full pipeline report used by convert.py --report)
# ---------------------------------------------------------------------------

def generate_report(
    input_path: str,
    output_dir: Path,
    results: Dict[str, Any],
    validation_issues: List[Dict[str, str]],
    elapsed: float,
) -> str:
    """Generate a comprehensive migration report as markdown."""
    timestamp = get_timestamp()
    total_files = sum(r.get('files_generated', 0) for r in results.values())
    total_conversions = sum(r.get('conversions_applied', 0) for r in results.values())

    # Count advisory comments in output files, separated by workstream
    output_p = _sanitize_path(str(output_dir), PROJECT_ROOT)
    ws1_advisory = 0
    ws2_advisory = 0
    advisory_keywords = ('Databricks equivalent:', 'Databricks:', 'TODO:', 'NOTE:', 'Advisory')
    for sql_file in output_p.rglob('*.sql'):
        try:
            content = sql_file.read_text(encoding='utf-8')
            count = sum(content.count(kw) for kw in advisory_keywords)
            rel = str(sql_file.relative_to(output_p))
            if rel.startswith('dbt_project'):
                ws2_advisory += count
            else:
                ws1_advisory += count
        except Exception:
            pass
    for yml_file in output_p.rglob('*.yml'):
        try:
            content = yml_file.read_text(encoding='utf-8')
            count = content.count('TODO:') + content.count('NOTE:')
            rel = str(yml_file.relative_to(output_p))
            if rel.startswith('dbt_project'):
                ws2_advisory += count
            else:
                ws1_advisory += count
        except Exception:
            pass
    advisory_count = ws1_advisory + ws2_advisory

    # Separate WS1 vs WS2 results
    ws1_types = ['ddl', 'dml', 'views', 'procedures', 'queries']
    ws2_types = ['dbt']
    ws1_files = sum(results.get(t, {}).get('files_generated', 0) for t in ws1_types)
    ws1_convs = sum(results.get(t, {}).get('conversions_applied', 0) for t in ws1_types)
    ws2_files = results.get('dbt', {}).get('files_generated', 0)
    ws2_convs = results.get('dbt', {}).get('conversions_applied', 0)

    lines = [
        "# Migration Report: Redshift to Databricks Conversion",
        "",
        f"**Generated:** {timestamp}",
        f"**Elapsed:** {elapsed:.1f}s",
        f"**Input:** `{input_path}`",
        f"**Output:** `{output_dir}`",
        "",
        "---",
        "",
        "## 1. Executive Summary",
        "",
        "| Metric | WS1 (Standalone SQL) | WS2 (dbt Project) | Total |",
        "| --- | --- | --- | --- |",
        f"| Files generated | {ws1_files} | {ws2_files} | {total_files} |",
        f"| Conversions applied | {ws1_convs} | {ws2_convs} | {total_conversions} |",
        f"| Validation issues | {len(validation_issues)} | 0 | {len(validation_issues)} |",
        f"| Advisory comments | {ws1_advisory} | {ws2_advisory} | {advisory_count} |",
        "",
        "---",
        "",
        "## 2. Conversion Results by Type",
        "",
        "| Type | Workstream | Files Generated | Conversions Applied |",
        "| --- | --- | --- | --- |",
    ]

    for conv_type, result in results.items():
        ws = "WS2 (dbt)" if conv_type == 'dbt' else "WS1 (SQL)"
        lines.append(
            f"| {conv_type} | {ws} | {result.get('files_generated', 0)} "
            f"| {result.get('conversions_applied', 0)} |"
        )
    lines.append("")

    # ------------------------------------------------------------------
    # 3. Input-to-Output File Mapping
    # ------------------------------------------------------------------
    lines.extend([
        "---",
        "",
        "## 3. Input-to-Output File Mapping",
        "",
    ])

    # WS1 mapping
    lines.extend([
        "### Workstream 1: Standalone SQL",
        "",
        "| Input File | Output File | Type | Conversions |",
        "| --- | --- | --- | --- |",
    ])
    for conv_type in ws1_types:
        result = results.get(conv_type, {})
        details = result.get('details', [])
        for d in details:
            src = d.get('source_file', '?')
            out_file = Path(d.get('output_file', '')).name if d.get('output_file') else d.get('table_name', '?')
            convs = d.get('conversions_applied', 0)
            lines.append(f"| {src} | {out_file} | {conv_type} | {convs} |")
    lines.append("")

    # WS2 mapping
    dbt_details = results.get('dbt', {}).get('details', [])
    if dbt_details:
        lines.extend([
            "### Workstream 2: dbt Project",
            "",
            "| Input File | Output File | File Type | Conversions |",
            "| --- | --- | --- | --- |",
        ])
        for d in dbt_details:
            src = d.get('source_file', '?')
            out_file = Path(d.get('output_file', '')).name if d.get('output_file') else '?'
            ftype = d.get('file_type', '?')
            convs = d.get('conversions_applied', 0)
            lines.append(f"| {src} | {out_file} | {ftype} | {convs} |")
        lines.append("")

    # ------------------------------------------------------------------
    # 4. Per-File Conversion Details
    # ------------------------------------------------------------------
    lines.extend([
        "---",
        "",
        "## 4. Per-File Conversion Details",
        "",
    ])

    lines.append("### WS1: Standalone SQL Output")
    lines.append("")
    sql_dir = output_p / 'sql'
    if sql_dir.exists():
        for subdir in sorted(sql_dir.iterdir()):
            if subdir.is_dir():
                sql_files = sorted(subdir.glob('*.sql'))
                if sql_files:
                    lines.append(f"#### {subdir.name} ({len(sql_files)} files)")
                    lines.append("")
                    for sf in sql_files:
                        try:
                            content = sf.read_text(encoding='utf-8')
                            conv_lines = [
                                l.strip().lstrip('- ').lstrip()
                                for l in content.split('\n')
                                if l.strip().startswith('--   ') and '->' in l
                            ]
                            adv_kws = ('Databricks equivalent:', 'Databricks:', 'TODO:', 'NOTE:', 'Advisory')
                            advisory_lines = [
                                l.strip().lstrip('- ').lstrip()
                                for l in content.split('\n')
                                if l.strip().startswith('--') and any(kw in l for kw in adv_kws)
                            ]
                            lines.append(f"**{sf.name}** \u2014 {len(conv_lines)} conversion(s), {len(advisory_lines)} advisory comment(s)")
                            if conv_lines:
                                for cl in conv_lines[:10]:
                                    lines.append(f"  - {cl.lstrip('-- ').strip()}")
                                if len(conv_lines) > 10:
                                    lines.append(f"  - ... and {len(conv_lines) - 10} more")
                            lines.append("")
                        except Exception:
                            pass

    # WS2 details
    dbt_dir = output_p / 'dbt_project'
    if dbt_dir.exists():
        lines.append("### WS2: dbt Project Output")
        lines.append("")
        for root_dir in sorted(dbt_dir.iterdir()):
            if root_dir.is_dir():
                all_files = sorted(root_dir.rglob('*.sql')) + sorted(root_dir.rglob('*.yml'))
            elif root_dir.is_file():
                all_files = [root_dir]
            else:
                continue
            if not all_files:
                continue
            rel_name = root_dir.name
            lines.append(f"#### {rel_name} ({len(all_files)} files)")
            lines.append("")
            for af in all_files:
                try:
                    content = af.read_text(encoding='utf-8')
                    conv_lines = [
                        l.strip()
                        for l in content.split('\n')
                        if l.strip().startswith('{#   -')
                    ]
                    adv_kws = ('Databricks equivalent:', 'Databricks:', 'TODO:', 'NOTE:', 'Advisory')
                    advisory_lines = [
                        l.strip()
                        for l in content.split('\n')
                        if any(kw in l for kw in adv_kws)
                    ]
                    advisory_lines = [
                        l for l in advisory_lines
                        if not (l.startswith('{# Converted') or l.startswith('{# Source:'))
                    ]
                    lines.append(f"**{af.relative_to(dbt_dir)}** \u2014 {len(conv_lines)} conversion(s), {len(advisory_lines)} advisory(s)")
                    if conv_lines:
                        for cl in conv_lines[:8]:
                            clean = cl.strip().lstrip('{#').rstrip('#}').strip().lstrip('- ').strip()
                            lines.append(f"  - {clean}")
                        if len(conv_lines) > 8:
                            lines.append(f"  - ... and {len(conv_lines) - 8} more")
                    if advisory_lines:
                        for al in advisory_lines[:3]:
                            clean = al.strip().lstrip('{#').lstrip('#').lstrip('--').rstrip('#}').strip()
                            lines.append(f"  - *Advisory:* {clean}")
                    lines.append("")
                except Exception:
                    pass

    # ------------------------------------------------------------------
    # 5. Data Type Mapping Rules
    # ------------------------------------------------------------------
    lines.extend([
        "---",
        "",
        "## 5. Data Type Mapping Rules",
        "",
        "| Redshift Type | Databricks Type | Notes |",
        "| --- | --- | --- |",
        "| VARCHAR / VARCHAR(n) | STRING | Databricks STRING has no length limit |",
        "| CHAR(n) / BPCHAR(n) / CHARACTER(n) | STRING | Blank-padded CHAR maps to STRING |",
        "| TEXT / NAME | STRING | Redshift aliases |",
        "| NVARCHAR(n) / NCHAR(n) | STRING | Unicode variants |",
        "| TIMESTAMPTZ | TIMESTAMP | Stored as UTC in Databricks |",
        "| TIMESTAMP WITHOUT TIME ZONE | TIMESTAMP | Direct mapping |",
        "| NUMERIC(p,s) / DECIMAL(p,s) | DECIMAL(p,s) | Direct syntax mapping |",
        "| NUMERIC (no precision) | DECIMAL(18,0) | RS default=18, DB default=10 |",
        "| FLOAT / FLOAT4 / REAL | FLOAT | RS FLOAT=8 bytes; DB FLOAT=4 bytes |",
        "| FLOAT8 / DOUBLE PRECISION | DOUBLE | Direct mapping |",
        "| INT2 / SMALLINT | SMALLINT | Direct mapping |",
        "| INT4 / INTEGER | INT | Direct mapping |",
        "| INT8 / BIGINT | BIGINT | Direct mapping |",
        "| BOOL / BOOLEAN | BOOLEAN | Direct mapping |",
        "| SUPER | STRING | Store as JSON string |",
        "| VARBYTE / VARBINARY | BINARY | Direct mapping |",
        "| GEOMETRY / GEOGRAPHY | STRING | Use WKT/Mosaic |",
        "| OID | BIGINT | Redshift system type |",
        "| TIME / TIMETZ | STRING | No TIME type in Databricks |",
        "",
    ])

    # ------------------------------------------------------------------
    # 6. Function Translation Rules
    # ------------------------------------------------------------------
    lines.extend([
        "## 6. Function Translation Rules",
        "",
        "| Redshift Function | Databricks Equivalent |",
        "| --- | --- |",
        "| GETDATE() / SYSDATE | CURRENT_TIMESTAMP |",
        "| DATEADD(day, n, col) | DATE_ADD(col, n) |",
        "| DATEADD(month, n, col) | ADD_MONTHS(col, n) |",
        "| DATEDIFF(unit, start, end) | DATEDIFF(end, start) \u2014 args reversed |",
        "| DATE_PART('unit', col) | EXTRACT(unit FROM col) |",
        "| TO_CHAR(d, fmt) | DATE_FORMAT(d, fmt) + token conversion |",
        "| CONVERT_TIMEZONE(src, tgt, ts) | FROM_UTC_TIMESTAMP / TO_UTC_TIMESTAMP |",
        "| NVL(a, b) | COALESCE(a, b) |",
        "| NVL2(expr, val1, val2) | CASE WHEN expr IS NOT NULL THEN val1 ELSE val2 END |",
        "| DECODE(...) | CASE WHEN ... END |",
        "| LEN(s) | LENGTH(s) |",
        "| STRPOS(str, sub) | LOCATE(sub, str) |",
        "| CHARINDEX(sub, str) | INSTR(str, sub) |",
        "| POSITION(sub IN str) | LOCATE(sub, str) |",
        "| BTRIM(str, chars) | TRIM(BOTH chars FROM str) |",
        "| STRTOL(str, base) | CONV(str, base, 10) |",
        "| JSON_EXTRACT_PATH_TEXT(j, k) | GET_JSON_OBJECT(j, '$.k') |",
        "| JSON_ARRAY_LENGTH(j) | JSON_ARRAY_LENGTH(j) |",
        "| IS_VALID_JSON(j) | TRY_CAST(j AS STRING) IS NOT NULL |",
        "| LISTAGG(col, delim) WITHIN GROUP | ARRAY_JOIN(ARRAY_SORT(COLLECT_LIST(col)), delim) |",
        "| APPROXIMATE COUNT(DISTINCT x) | APPROX_COUNT_DISTINCT(x) |",
        "| MEDIAN(x) | PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY x) |",
        "| RATIO_TO_REPORT(col) OVER(...) | col / SUM(col) OVER(...) |",
        "| REGEXP_SUBSTR(str, pat) | REGEXP_EXTRACT(str, pat) |",
        "| REGEXP_COUNT(str, pat) | SIZE(SPLIT(str, pat)) - 1 |",
        "| SIMILAR TO 'pattern' | RLIKE |",
        "| val::TYPE | CAST(val AS TYPE) |",
        "| (expr)::TYPE | CAST(expr AS TYPE) |",
        "",
    ])

    # ------------------------------------------------------------------
    # 7. Construct Removal & Advisory Rules
    # ------------------------------------------------------------------
    lines.extend([
        "## 7. Construct Removal & Advisory Rules",
        "",
        "Every removal includes a comment in the output with the Databricks equivalent or suggestion.",
        "",
        "| Redshift Construct | Action | Databricks Suggestion |",
        "| --- | --- | --- |",
        "| DISTKEY(col) | Removed | CLUSTER BY (liquid clustering) or PARTITIONED BY |",
        "| DISTSTYLE ALL | Removed | Use `/*+ BROADCAST(table) */` hint in queries |",
        "| DISTSTYLE EVEN | Removed | Default Spark partitioning (no action needed) |",
        "| DISTSTYLE KEY | Removed | Use CLUSTER BY on the distribution key |",
        "| SORTKEY(cols) | Removed | `OPTIMIZE table ZORDER BY (cols)` or CLUSTER BY |",
        "| COMPOUND SORTKEY | Removed | OPTIMIZE ZORDER BY or CLUSTER BY |",
        "| INTERLEAVED SORTKEY | Removed | Liquid clustering CLUSTER BY |",
        "| ENCODE encoding | Removed | Delta Lake manages compression automatically |",
        "| WITH NO SCHEMA BINDING | Removed | Databricks views always use late binding |",
        "| AUTO REFRESH YES/NO | Removed | Use `REFRESH MATERIALIZED VIEW` or scheduled refresh |",
        "| BACKUP YES/NO | Removed | Delta Lake provides automatic versioning & time travel |",
        "| CASCADE | Commented | Not supported \u2014 drop dependent views manually |",
        "| IDENTITY(seed,step) | Converted | GENERATED ALWAYS AS IDENTITY |",
        "| DEFAULT GETDATE() | Converted | DEFAULT CURRENT_TIMESTAMP |",
        "| PRIMARY KEY / UNIQUE | Commented | Informational only in Databricks (not enforced) |",
        "| CREATE TEMP TABLE | Converted | CREATE OR REPLACE TEMPORARY VIEW |",
        "",
    ])

    # ------------------------------------------------------------------
    # 8. dbt-Specific Conversion Rules (WS2)
    # ------------------------------------------------------------------
    if dbt_details:
        lines.extend([
            "## 8. dbt-Specific Conversion Rules (Workstream 2)",
            "",
            "| Category | Redshift Config | Databricks Equivalent |",
            "| --- | --- | --- |",
            "| Profile | type: redshift | type: databricks |",
            "| Profile | dbname | catalog (Unity Catalog) |",
            "| Profile | password | token (PAT or OAuth) |",
            "| dbt_project.yml | +sort: [cols] | Removed -> advisory: OPTIMIZE ZORDER BY or CLUSTER BY |",
            "| dbt_project.yml | +dist: col | Removed -> advisory: CLUSTER BY or PARTITIONED BY |",
            "| dbt_project.yml | +sort_type: interleaved | Removed -> liquid clustering |",
            "| dbt_project.yml | delete+insert | merge (incremental strategy) |",
            "| Model config | sort='col' | Removed -> advisory: ZORDER BY or CLUSTER BY |",
            "| Model config | dist='col' | Removed -> advisory: CLUSTER BY or PARTITIONED BY |",
            "| Model config | materialized='table' | Added file_format='delta' |",
            "| Model config | materialized='incremental' | Added incremental_strategy='merge', file_format='delta' |",
            "| Snapshots | \u2014 | Added file_format='delta' |",
            "| Sources | database: name | Added TODO for Unity Catalog name |",
            "| Hooks | VACUUM table | OPTIMIZE table |",
            "| Hooks | ANALYZE table | ANALYZE TABLE table COMPUTE STATISTICS |",
            "| Hooks | GRANT ON ALL TABLES IN SCHEMA | GRANT ON SCHEMA (Unity Catalog) |",
            "| Packages | dbt-labs/redshift_utils | Removed (Redshift-only) |",
            "| Packages | \u2014 | Added dbt-labs/spark_utils |",
            "| Macros | redshift__ dispatch | Advisory: add databricks__ variant |",
            "| PL/pgSQL | RAISE EXCEPTION | SIGNAL SQLSTATE |",
            "| PL/pgSQL | RAISE (re-raise) | RESIGNAL |",
            "",
        ])

    # ------------------------------------------------------------------
    # 9. Validation Summary
    # ------------------------------------------------------------------
    if validation_issues:
        lines.extend([
            "---",
            "",
            "## 9. Validation Issues",
            "",
            "| # | File | Severity | Issue |",
            "| --- | --- | --- | --- |",
        ])
        for i, vi in enumerate(validation_issues, 1):
            lines.append(f"| {i} | {vi['file']} | {vi['severity']} | {vi['issue']} |")
        lines.append("")
    else:
        lines.extend([
            "---",
            "",
            "## 9. Validation",
            "",
            "All output files passed validation:",
            "- Zero residual Redshift syntax in non-comment lines",
            "- All data types correctly mapped",
            "- All DDL files have USING DELTA and IF NOT EXISTS",
            "- All removal comments include Databricks equivalents/suggestions",
            "- All output files include traceability headers",
            "",
        ])

    return '\n'.join(lines)


# ---------------------------------------------------------------------------
# CLI entry point (standalone usage)
# ---------------------------------------------------------------------------

def main() -> None:
    parser = argparse.ArgumentParser(description='Generate migration report')
    parser.add_argument('-i', '--input', default='inputs/sql', help='Input directory')
    parser.add_argument('-o', '--output', default='output', help='Output directory')
    parser.add_argument('--elapsed', type=float, default=0.0, help='Elapsed time in seconds')
    args = parser.parse_args()

    try:
        _sanitize_path(args.input, PROJECT_ROOT)
    except ValueError as e:
        print(f"Error: Invalid input path: {e}")
        return
    try:
        output_p = _sanitize_path(args.output, PROJECT_ROOT)
    except ValueError as e:
        print(f"Error: Invalid output path: {e}")
        return

    # When run standalone, build a minimal results dict from output analysis
    results: Dict[str, Any] = {}
    sql_dir = output_p / 'sql'
    if sql_dir.exists():
        for subdir in sorted(sql_dir.iterdir()):
            if subdir.is_dir():
                sql_files = list(subdir.glob('*.sql'))
                if sql_files:
                    results[subdir.name] = {
                        'files_generated': len(sql_files),
                        'conversions_applied': 0,
                        'details': [],
                    }

    dbt_dir = output_p / 'dbt_project'
    if dbt_dir.exists():
        dbt_files = list(dbt_dir.rglob('*.sql')) + list(dbt_dir.rglob('*.yml'))
        if dbt_files:
            results['dbt'] = {
                'files_generated': len(dbt_files),
                'conversions_applied': 0,
                'details': [],
            }

    report_content = generate_report(
        args.input, output_p, results, [], args.elapsed,
    )
    report_path = (output_p / 'migration_report.md').resolve()
    if not str(report_path).startswith(str(PROJECT_ROOT.resolve())):
        raise ValueError(f"Migration report path escapes project root: {report_path}")
    report_path.parent.mkdir(parents=True, exist_ok=True)
    report_path.write_text(report_content, encoding='utf-8')
    print(f"Migration report generated: {report_path}")


if __name__ == '__main__':
    main()
