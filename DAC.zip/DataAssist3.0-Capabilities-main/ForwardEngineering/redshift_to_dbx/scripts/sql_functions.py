"""
Shared SQL Function Translation Module.

Provides regex-based translation rules for converting Redshift SQL functions,
data types, casting syntax, and construct patterns to Databricks SQL equivalents.

Used by all Workstream 1 converters (DML, Views, MVs, Procedures, Queries).

Rules sourced from:
    knowledgebase/redshift_to_databricks_conversion_guide.pdf
    knowledgebase/dbt_redshift_to_dbt_databricks_migration_guide.pdf
    External: Databricks official migration docs, community best practices
"""

import re
from typing import Dict, List, Tuple


# Each rule: (compiled_regex, replacement_string, category)
# Order matters — more specific patterns before general ones.

FUNCTION_TRANSLATIONS: List[Tuple[re.Pattern, str, str]] = [
    # ── Date/Time Functions ──────────────────────────────────────────────
    # GETDATE() -> CURRENT_TIMESTAMP
    (re.compile(r'\bGETDATE\s*\(\s*\)', re.IGNORECASE),
     'CURRENT_TIMESTAMP', 'date'),
    # SYSDATE -> CURRENT_TIMESTAMP
    (re.compile(r'\bSYSDATE\b', re.IGNORECASE),
     'CURRENT_TIMESTAMP', 'date'),
    # DATEADD: handled by convert_dateadd() balanced-paren function (CRIT-01)
    # DATEDIFF: handled by convert_datediff() balanced-paren function (CRIT-01)
    # DATE_PART('unit', col) -> EXTRACT(unit FROM col)
    (re.compile(
        r"\bDATE_PART\s*\(\s*'(\w+)'\s*,\s*([^)]+?)\s*\)",
        re.IGNORECASE),
     r'EXTRACT(\1 FROM \2)', 'date'),
    # TO_CHAR(col, fmt) -> DATE_FORMAT(col, fmt)
    (re.compile(
        r'\bTO_CHAR\s*\(\s*([^,]+?)\s*,\s*([^)]+?)\s*\)',
        re.IGNORECASE),
     r'DATE_FORMAT(\1, \2)', 'date'),
    # INTERVAL 'n' UNIT -> INTERVAL n UNIT (remove quotes)
    (re.compile(
        r"\bINTERVAL\s+'(\d+)'\s+(\w+)",
        re.IGNORECASE),
     r'INTERVAL \1 \2', 'date'),
    # Single-arg TRUNC: handled by convert_single_arg_trunc() balanced-paren function (CRIT-05)
    # NEXT_DAY(date, 'Mon') -> NEXT_DAY(date, 'Monday') [abbreviated to full day name]
    (re.compile(r"\bNEXT_DAY\s*\(\s*([^,]+?)\s*,\s*'Mon'\s*\)", re.IGNORECASE),
     r"NEXT_DAY(\1, 'Monday')", 'date'),
    (re.compile(r"\bNEXT_DAY\s*\(\s*([^,]+?)\s*,\s*'Tue'\s*\)", re.IGNORECASE),
     r"NEXT_DAY(\1, 'Tuesday')", 'date'),
    (re.compile(r"\bNEXT_DAY\s*\(\s*([^,]+?)\s*,\s*'Wed'\s*\)", re.IGNORECASE),
     r"NEXT_DAY(\1, 'Wednesday')", 'date'),
    (re.compile(r"\bNEXT_DAY\s*\(\s*([^,]+?)\s*,\s*'Thu'\s*\)", re.IGNORECASE),
     r"NEXT_DAY(\1, 'Thursday')", 'date'),
    (re.compile(r"\bNEXT_DAY\s*\(\s*([^,]+?)\s*,\s*'Fri'\s*\)", re.IGNORECASE),
     r"NEXT_DAY(\1, 'Friday')", 'date'),
    (re.compile(r"\bNEXT_DAY\s*\(\s*([^,]+?)\s*,\s*'Sat'\s*\)", re.IGNORECASE),
     r"NEXT_DAY(\1, 'Saturday')", 'date'),
    (re.compile(r"\bNEXT_DAY\s*\(\s*([^,]+?)\s*,\s*'Sun'\s*\)", re.IGNORECASE),
     r"NEXT_DAY(\1, 'Sunday')", 'date'),
    # TRUNC(date, 'unit') [2-arg] -> DATE_TRUNC('unit', date)  [arg order reversed]
    # Unit uppercasing is handled by apply_date_trunc_uppercase() later in the pipeline
    (re.compile(
        r"(?<!\w)TRUNC\s*\(\s*([^,]+?)\s*,\s*'(\w+)'\s*\)",
        re.IGNORECASE),
     r"DATE_TRUNC('\2', \1)", 'date'),
    # TIMESTAMPADD / TIMESTAMPDIFF -> identical in Databricks (no change needed)
    # LAST_DAY(date) -> identical in Databricks (no change needed)
    # ADD_MONTHS(date, n) -> identical in Databricks (no change needed)
    # MONTHS_BETWEEN(d1, d2) -> identical in Databricks (no change needed)
    # CONVERT_TIMEZONE: handled by convert_timezone() function below, not regex
    # (regex can't handle nested parens in the timestamp argument)
    # NOW() -> CURRENT_TIMESTAMP (Redshift NOW = transaction start time)
    (re.compile(r'\bNOW\s*\(\s*\)', re.IGNORECASE),
     'CURRENT_TIMESTAMP', 'date'),
    # CURRENT_TIME -> DATE_FORMAT(CURRENT_TIMESTAMP(), 'HH:mm:ss') (no TIME type in Databricks)
    (re.compile(r'\bCURRENT_TIME\b(?!\s*STAMP)', re.IGNORECASE),
     "DATE_FORMAT(CURRENT_TIMESTAMP(), 'HH:mm:ss')", 'date'),
    # TIMEOFDAY() -> DATE_FORMAT string representation
    (re.compile(r'\bTIMEOFDAY\s*\(\s*\)', re.IGNORECASE),
     "CAST(CURRENT_TIMESTAMP() AS STRING) /* TIMEOFDAY converted */", 'date'),
    # DATE_PART_YEAR(date) -> YEAR(date) (Redshift shorthand)
    (re.compile(r'\bDATE_PART_YEAR\s*\(\s*([^)]+?)\s*\)', re.IGNORECASE),
     r'YEAR(\1)', 'date'),
    # AGE(ts1, ts2) -> DATEDIFF(ts1, ts2) with advisory
    (re.compile(r'\bAGE\s*\(\s*([^,]+?)\s*,\s*([^)]+?)\s*\)', re.IGNORECASE),
     r'DATEDIFF(\1, \2) /* AGE: returns days; was interval in Redshift */', 'date'),
    # DATE_CMP(d1, d2) -> CASE WHEN comparison
    (re.compile(r'\bDATE_CMP\s*\(\s*([^,]+?)\s*,\s*([^)]+?)\s*\)', re.IGNORECASE),
     r'CASE WHEN \1 > \2 THEN 1 WHEN \1 < \2 THEN -1 ELSE 0 END', 'date'),
    # TIMESTAMP_CMP variants -> CASE WHEN comparison
    (re.compile(r'\bTIMESTAMP_CMP(?:_(?:DATE|TIMESTAMPTZ))?\s*\(\s*([^,]+?)\s*,\s*([^)]+?)\s*\)', re.IGNORECASE),
     r'CASE WHEN \1 > \2 THEN 1 WHEN \1 < \2 THEN -1 ELSE 0 END', 'date'),
    (re.compile(r'\bTIMESTAMPTZ_CMP(?:_(?:DATE|TIMESTAMP))?\s*\(\s*([^,]+?)\s*,\s*([^)]+?)\s*\)', re.IGNORECASE),
     r'CASE WHEN \1 > \2 THEN 1 WHEN \1 < \2 THEN -1 ELSE 0 END', 'date'),
    # EXTRACT(MILLISECONDS FROM ts) -> CAST(DATE_FORMAT(ts, 'SSS') AS INT)
    (re.compile(r'\bEXTRACT\s*\(\s*MILLISECONDS?\s+FROM\s+([^)]+?)\s*\)', re.IGNORECASE),
     r"CAST(DATE_FORMAT(\1, 'SSS') AS INT)", 'date'),
    # EXTRACT(MICROSECONDS FROM ts) -> CAST(DATE_FORMAT(ts, 'SSSSSS') AS INT)
    (re.compile(r'\bEXTRACT\s*\(\s*MICROSECONDS?\s+FROM\s+([^)]+?)\s*\)', re.IGNORECASE),
     r"CAST(DATE_FORMAT(\1, 'SSSSSS') AS INT)", 'date'),
    # EXTRACT(DOW FROM date) -> (DAYOFWEEK(date) - 1) to match RS Sunday=0
    (re.compile(
        r'\bEXTRACT\s*\(\s*(?:DOW|DAYOFWEEK)\s+FROM\s+([^)]+?)\s*\)',
        re.IGNORECASE),
     r'(DAYOFWEEK(\1) - 1)', 'date'),
    # EXTRACT(EPOCH FROM ts) -> UNIX_TIMESTAMP(ts)
    (re.compile(
        r'\bEXTRACT\s*\(\s*EPOCH\s+FROM\s+([^)]+?)\s*\)',
        re.IGNORECASE),
     r'UNIX_TIMESTAMP(\1)', 'date'),
    # ts AT TIME ZONE 'tz' -> FROM_UTC_TIMESTAMP(ts, 'tz')
    # Redshift uses this for timezone conversion; Databricks uses FROM_UTC_TIMESTAMP
    (re.compile(
        r"(\S+)\s+AT\s+TIME\s+ZONE\s+'([^']+)'",
        re.IGNORECASE),
     r"FROM_UTC_TIMESTAMP(\1, '\2')", 'date'),

    # ── JSON Functions ───────────────────────────────────────────────────
    # JSON_EXTRACT_PATH_TEXT(json, 'key1', 'key2') -> GET_JSON_OBJECT(json, '$.key1.key2')
    # Simple single-key form
    (re.compile(
        r"\bJSON_EXTRACT_PATH_TEXT\s*\(\s*([^,]+?)\s*,\s*'([^']+)'\s*\)",
        re.IGNORECASE),
     r"GET_JSON_OBJECT(\1, '$.\2')", 'json'),
    # JSON_EXTRACT_ARRAY_ELEMENT_TEXT(json, 'key', idx) -> GET_JSON_OBJECT(json, '$.key[idx]') (3-arg)
    (re.compile(
        r"\bJSON_EXTRACT_ARRAY_ELEMENT_TEXT\s*\(\s*([^,]+?)\s*,\s*'([^']+)'\s*,\s*(\d+)\s*\)",
        re.IGNORECASE),
     r"GET_JSON_OBJECT(\1, '$.\2[\3]')", 'json'),
    # JSON_EXTRACT_ARRAY_ELEMENT_TEXT(json, idx) -> GET_JSON_OBJECT(json, '$[idx]') (2-arg)
    (re.compile(
        r'\bJSON_EXTRACT_ARRAY_ELEMENT_TEXT\s*\(\s*([^,]+?)\s*,\s*(\d+)\s*\)',
        re.IGNORECASE),
     r"GET_JSON_OBJECT(\1, '$[\2]')", 'json'),
    # JSON_SERIALIZE(x) -> TO_JSON(x)
    (re.compile(r'\bJSON_SERIALIZE\s*\(', re.IGNORECASE),
     'TO_JSON(', 'json'),
    # JSON_ARRAY_LENGTH(json) -> SIZE(FROM_JSON(json, 'ARRAY<STRING>'))
    # Uses nested-paren-aware capture to handle GET_JSON_OBJECT(...) inside
    (re.compile(r'\bJSON_ARRAY_LENGTH\s*\(\s*((?:[^()]+|\((?:[^()]+|\([^()]*\))*\))*)\s*\)', re.IGNORECASE),
     r"SIZE(FROM_JSON(\1, 'array<string>')) /* JSON_ARRAY_LENGTH: adjust element type if not string */", 'json'),
    # IS_VALID_JSON -> GET_JSON_OBJECT root check (returns NULL for invalid JSON)
    (re.compile(r'\bIS_VALID_JSON\s*\(\s*([^)]+)\s*\)', re.IGNORECASE),
     r"(GET_JSON_OBJECT(CAST(\1 AS STRING), '$') IS NOT NULL) /* IS_VALID_JSON converted */", 'json'),
    # IS_VALID_JSON_ARRAY -> root check + array shape check
    (re.compile(r'\bIS_VALID_JSON_ARRAY\s*\(\s*([^)]+)\s*\)', re.IGNORECASE),
     r"(GET_JSON_OBJECT(CAST(\1 AS STRING), '$') IS NOT NULL AND TRIM(CAST(\1 AS STRING)) LIKE '[%]') /* IS_VALID_JSON_ARRAY converted */", 'json'),
    # JSON_PARSE -> FROM_JSON (Databricks-native; schema must be provided by user)
    (re.compile(r'\bJSON_PARSE\s*\(\s*([^)]+)\s*\)', re.IGNORECASE),
     r"FROM_JSON(\1, 'map<string,string>') /* TODO: MANUAL REVIEW REQUIRED — provide actual schema for FROM_JSON */", 'json'),
    # CAN_JSON_PARSE -> GET_JSON_OBJECT root check
    (re.compile(r'\bCAN_JSON_PARSE\s*\(\s*([^)]+)\s*\)', re.IGNORECASE),
     r"(GET_JSON_OBJECT(CAST(\1 AS STRING), '$') IS NOT NULL) /* CAN_JSON_PARSE converted */", 'json'),
    # IS_ARRAY -> STARTSWITH check
    (re.compile(r'\bIS_ARRAY\s*\(\s*([^)]+)\s*\)', re.IGNORECASE),
     r"STARTSWITH(TRIM(CAST(\1 AS STRING)), '[') /* IS_ARRAY converted */", 'json'),
    # IS_OBJECT -> STARTSWITH check
    (re.compile(r'\bIS_OBJECT\s*\(\s*([^)]+)\s*\)', re.IGNORECASE),
     r"STARTSWITH(TRIM(CAST(\1 AS STRING)), '{') /* IS_OBJECT converted */", 'json'),
    # IS_INTEGER -> TRY_CAST check
    (re.compile(r'\bIS_INTEGER\s*\(\s*([^)]+)\s*\)', re.IGNORECASE),
     r"(TRY_CAST(CAST(\1 AS STRING) AS INT) IS NOT NULL) /* IS_INTEGER converted */", 'json'),
    # IS_FLOAT -> TRY_CAST check
    (re.compile(r'\bIS_FLOAT\s*\(\s*([^)]+)\s*\)', re.IGNORECASE),
     r"(TRY_CAST(CAST(\1 AS STRING) AS DOUBLE) IS NOT NULL) /* IS_FLOAT converted */", 'json'),
    # IS_BOOLEAN -> LOWER/TRIM check
    (re.compile(r'\bIS_BOOLEAN\s*\(\s*([^)]+)\s*\)', re.IGNORECASE),
     r"(LOWER(TRIM(CAST(\1 AS STRING))) IN ('true', 'false')) /* IS_BOOLEAN converted */", 'json'),
    # IS_DECIMAL -> TRY_CAST check
    (re.compile(r'\bIS_DECIMAL\s*\(\s*([^)]+)\s*\)', re.IGNORECASE),
     r"(TRY_CAST(CAST(\1 AS STRING) AS DECIMAL(38,18)) IS NOT NULL) /* IS_DECIMAL converted */", 'json'),

    # ── String Functions ─────────────────────────────────────────────────
    # LEN(x) -> LENGTH(x)
    (re.compile(r'\bLEN\s*\(', re.IGNORECASE),
     'LENGTH(', 'string'),
    # STRPOS(str, sub) -> LOCATE(sub, str) [args stay same order for STRPOS]
    (re.compile(
        r'\bSTRPOS\s*\(\s*([^,]+?)\s*,\s*([^)]+?)\s*\)',
        re.IGNORECASE),
     r'LOCATE(\2, \1)', 'string'),
    # FUNC_SHA1(x) -> SHA1(x)
    (re.compile(r'\bFUNC_SHA1\s*\(', re.IGNORECASE),
     'SHA1(', 'string'),
    # CHARINDEX(sub, str) -> INSTR(str, sub)  [args reversed]
    (re.compile(
        r'\bCHARINDEX\s*\(\s*([^,]+?)\s*,\s*([^)]+?)\s*\)',
        re.IGNORECASE),
     r'INSTR(\2, \1)', 'string'),
    # POSITION(sub IN str) -> LOCATE(sub, str)
    (re.compile(
        r'\bPOSITION\s*\(\s*(.+?)\s+IN\s+([^)]+?)\s*\)',
        re.IGNORECASE),
     r'LOCATE(\1, \2)', 'string'),
    # BTRIM: handled by convert_btrim() balanced-paren function (CRIT-02)
    # STRTOL: handled by convert_strtol() balanced-paren function (CRIT-03)
    # TO_HEX(n) -> HEX(n)
    (re.compile(r'\bTO_HEX\s*\(', re.IGNORECASE),
     'HEX(', 'string'),
    # FROM_HEX(s) -> UNHEX(s)
    (re.compile(r'\bFROM_HEX\s*\(', re.IGNORECASE),
     'UNHEX(', 'string'),
    # SIMILAR TO: handled by convert_similar_to() (HIGH-01 -- adds anchors + converts wildcards)
    # ~ (POSIX regex) -> RLIKE
    (re.compile(r'\s+~\s+', re.IGNORECASE),
     ' RLIKE ', 'string'),
    # ~* (case-insensitive regex) -> RLIKE with (?i)
    (re.compile(r"\s+~\*\s+'([^']+)'"),
     r" RLIKE '(?i)\1'", 'string'),
    # !~ (not match) -> NOT RLIKE
    (re.compile(r'\s+!~\s+', re.IGNORECASE),
     ' NOT RLIKE ', 'string'),
    # QUOTE_LITERAL -> CONCAT with quotes (HIGH-10: preserve quoting for dynamic SQL)
    (re.compile(r'\bQUOTE_LITERAL\s*\(([^)]+)\)', re.IGNORECASE),
     r"CONCAT('''', \1, '''')", 'string'),
    # QUOTE_IDENT -> CONCAT with backticks (Databricks uses backticks for quoting identifiers)
    (re.compile(r'\bQUOTE_IDENT\s*\(\s*([^)]+?)\s*\)', re.IGNORECASE),
     r"CONCAT('`', \1, '`')", 'string'),
    # QUOTE_NULLABLE(x) -> COALESCE(CONCAT('''', CAST(x AS STRING), ''''), 'NULL')
    (re.compile(r'\bQUOTE_NULLABLE\s*\(\s*([^)]+?)\s*\)', re.IGNORECASE),
     r"COALESCE(CONCAT('''', CAST(\1 AS STRING), ''''), 'NULL')", 'string'),
    # REGEXP_SUBSTR: handled by convert_regexp_substr() (HIGH-02 -- trims extra args)
    # REPLICATE(str, n) -> REPEAT(str, n)
    (re.compile(r'\bREPLICATE\s*\(', re.IGNORECASE),
     'REPEAT(', 'string'),
    # TEXTLEN(str) -> LENGTH(str) (synonym for LEN in Redshift)
    (re.compile(r'\bTEXTLEN\s*\(', re.IGNORECASE),
     'LENGTH(', 'string'),
    # REGEXP_INSTR(str, pattern) -> CASE WHEN str RLIKE pattern THEN 1 ELSE 0 END (advisory)
    (re.compile(r'\bREGEXP_INSTR\s*\(\s*([^,]+?)\s*,\s*([^)]+?)\s*\)', re.IGNORECASE),
     r"CASE WHEN \1 RLIKE \2 THEN 1 ELSE 0 END /* REGEXP_INSTR: returns 1/0; review manually */", 'string'),
    # DIFFERENCE(str1, str2) -> advisory (no Databricks equivalent)
    (re.compile(r'\bDIFFERENCE\s*\(\s*([^,]+?)\s*,\s*([^)]+?)\s*\)', re.IGNORECASE),
     r"0 /* TODO: DIFFERENCE(\1, \2) has no Databricks equivalent -- consider SOUNDEX UDF */", 'string'),
    # TRANSLATE(str, from, to) -> identical in Databricks (no change needed)
    # SPLIT_PART(str, delim, n) -> identical in Databricks (no change needed)
    # CHR(n)/ASCII(str) -> identical in Databricks (no change needed)
    # INITCAP(str) -> identical in Databricks (NOTE: word delimiter diff - Redshift uses any non-alnum, Databricks uses whitespace only)
    # UPPER/LOWER/LTRIM/RTRIM/TRIM -> identical in Databricks (no change needed)
    # LPAD/RPAD -> identical in Databricks (no change needed)
    # REPLACE -> identical in Databricks (no change needed)
    # LEFT/RIGHT/SUBSTRING -> identical in Databricks (NOTE: negative index behaves differently)
    # || (concat) -> identical in Databricks (no change needed)

    # ── Conditional & NULL Functions ─────────────────────────────────────
    # NVL(a, b) -> COALESCE(a, b)
    (re.compile(r'\bNVL\s*\(', re.IGNORECASE),
     'COALESCE(', 'conditional'),
    # NVL2(val, not_null, null) -> CASE WHEN val IS NOT NULL ...
    # NVL2 is complex — leave a comment marker for manual review
    (re.compile(
        r'\bNVL2\s*\(\s*([^,]+?)\s*,\s*([^,]+?)\s*,\s*([^)]+?)\s*\)',
        re.IGNORECASE),
     r'CASE WHEN \1 IS NOT NULL THEN \2 ELSE \3 END', 'conditional'),
    # ZEROIFNULL(x) -> COALESCE(x, 0)
    (re.compile(
        r'\bZEROIFNULL\s*\(\s*([^)]+?)\s*\)',
        re.IGNORECASE),
     r'COALESCE(\1, 0)', 'conditional'),
    # NULLIFZERO(x) -> NULLIF(x, 0)
    (re.compile(
        r'\bNULLIFZERO\s*\(\s*([^)]+?)\s*\)',
        re.IGNORECASE),
     r'NULLIF(\1, 0)', 'conditional'),
    # IIF(cond, true, false) -> IF(cond, true, false)
    (re.compile(r'\bIIF\s*\(', re.IGNORECASE),
     'IF(', 'conditional'),
    # ISNOTNULL(x) -> (x IS NOT NULL)
    (re.compile(
        r'\bISNOTNULL\s*\(\s*([^)]+?)\s*\)',
        re.IGNORECASE),
     r'(\1 IS NOT NULL)', 'conditional'),
    # DECODE handled separately due to variable args

    # ── Aggregate Functions ──────────────────────────────────────────────
    # APPROXIMATE COUNT(DISTINCT x) -> APPROX_COUNT_DISTINCT(x)
    (re.compile(
        r'\bAPPROXIMATE\s+COUNT\s*\(\s*DISTINCT\s+([^)]+)\)',
        re.IGNORECASE),
     r'APPROX_COUNT_DISTINCT(\1)', 'aggregate'),
    # APPROXIMATE PERCENTILE_DISC(p) WITHIN GROUP (ORDER BY col) -> APPROX_PERCENTILE(col, p)
    (re.compile(
        r'\bAPPROXIMATE\s+PERCENTILE_DISC\s*\(\s*([^)]+?)\s*\)\s*WITHIN\s+GROUP\s*\(\s*ORDER\s+BY\s+([^)]+?)\s*\)',
        re.IGNORECASE),
     r'APPROX_PERCENTILE(\2, \1)', 'aggregate'),
    # Fallback: APPROXIMATE PERCENTILE_DISC without WITHIN GROUP
    (re.compile(
        r'\bAPPROXIMATE\s+PERCENTILE_DISC\s*\(',
        re.IGNORECASE),
     'APPROX_PERCENTILE(', 'aggregate'),
    # MEDIAN(x) -> PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY x)
    (re.compile(
        r'\bMEDIAN\s*\(\s*([^)]+?)\s*\)',
        re.IGNORECASE),
     r'PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY \1)', 'aggregate'),
    # RATIO_TO_REPORT(col) OVER (...) -> col / SUM(col) OVER (...)
    # Complex — leave marker for manual review
    (re.compile(
        r'\bRATIO_TO_REPORT\s*\(\s*([^)]+?)\s*\)\s*OVER\s*\(([^)]*)\)',
        re.IGNORECASE),
     r'\1 / SUM(\1) OVER (\2)', 'aggregate'),
    # HIGH-06: LISTAGG+OVER patterns (must be BEFORE non-OVER LISTAGG patterns)
    # LISTAGG(...) WITHIN GROUP (...) OVER (...) -> advisory (no direct equivalent)
    (re.compile(
        r"\bLISTAGG\s*\(\s*DISTINCT\s+([^,)]+?)\s*,\s*'([^']*)'\s*\)\s*WITHIN\s+GROUP\s*\(\s*ORDER\s+BY\s+[^)]+\)\s*OVER\s*\([^)]*\)",
        re.IGNORECASE),
     r"ARRAY_JOIN(ARRAY_SORT(COLLECT_SET(\1)), '\2') /* TODO: LISTAGG OVER(PARTITION BY) requires manual rewrite to subquery */", 'aggregate'),
    (re.compile(
        r"\bLISTAGG\s*\(\s*([^,)]+?)\s*,\s*'([^']*)'\s*\)\s*WITHIN\s+GROUP\s*\(\s*ORDER\s+BY\s+[^)]+\)\s*OVER\s*\([^)]*\)",
        re.IGNORECASE),
     r"ARRAY_JOIN(ARRAY_SORT(COLLECT_LIST(\1)), '\2') /* TODO: LISTAGG OVER(PARTITION BY) requires manual rewrite to subquery */", 'aggregate'),
    # LISTAGG(DISTINCT col, delim) WITHIN GROUP (ORDER BY ...) -> ARRAY_JOIN(ARRAY_SORT(COLLECT_SET(col)), delim)
    (re.compile(
        r"\bLISTAGG\s*\(\s*DISTINCT\s+([^,)]+?)\s*,\s*'([^']*)'\s*\)\s*WITHIN\s+GROUP\s*\(\s*ORDER\s+BY\s+[^)]+\)",
        re.IGNORECASE),
     r"ARRAY_JOIN(ARRAY_SORT(COLLECT_SET(\1)), '\2')", 'aggregate'),
    # LISTAGG(DISTINCT col, delim) without WITHIN GROUP
    (re.compile(
        r"\bLISTAGG\s*\(\s*DISTINCT\s+([^,)]+?)\s*,\s*'([^']*)'\s*\)",
        re.IGNORECASE),
     r"ARRAY_JOIN(COLLECT_SET(\1), '\2')", 'aggregate'),
    # LISTAGG(col, delim) WITHIN GROUP (ORDER BY ...) -> ARRAY_JOIN(ARRAY_SORT(COLLECT_LIST(col)), delim)
    (re.compile(
        r"\bLISTAGG\s*\(\s*([^,)]+?)\s*,\s*'([^']*)'\s*\)\s*WITHIN\s+GROUP\s*\(\s*ORDER\s+BY\s+[^)]+\)",
        re.IGNORECASE),
     r"ARRAY_JOIN(ARRAY_SORT(COLLECT_LIST(\1)), '\2')", 'aggregate'),
    # LISTAGG(col, delim) without WITHIN GROUP
    (re.compile(
        r"\bLISTAGG\s*\(\s*([^,)]+?)\s*,\s*'([^']*)'\s*\)",
        re.IGNORECASE),
     r"ARRAY_JOIN(COLLECT_LIST(\1), '\2')", 'aggregate'),
    # REGEXP_COUNT: handled by convert_regexp_count() (HIGH-03 -- trims extra args)

    # ── Math Functions ──────────────────────────────────────────────────
    # LOG(x) single-arg -> LOG10(x) (Redshift LOG=base-10, Databricks LOG=natural)
    # Must NOT match LOG(base, x) two-arg form
    (re.compile(r'\bLOG\s*\(\s*([^,)]+?)\s*\)', re.IGNORECASE),
     r'LOG10(\1)', 'math'),
    # DEXP(x) -> EXP(x) (Redshift synonym)
    (re.compile(r'\bDEXP\s*\(', re.IGNORECASE),
     'EXP(', 'math'),
    # DLOG1(x) -> LN(x) (Redshift synonym for natural log)
    (re.compile(r'\bDLOG1\s*\(', re.IGNORECASE),
     'LN(', 'math'),
    # DLOG10(x) -> LOG10(x) (Redshift synonym for base-10 log)
    (re.compile(r'\bDLOG10\s*\(', re.IGNORECASE),
     'LOG10(', 'math'),
    # RANDOM(seed) -> RAND(seed) (seeded variant, must come before bare RANDOM())
    (re.compile(r'\bRANDOM\s*\(\s*(\d+)\s*\)', re.IGNORECASE),
     r'RAND(\1)', 'math'),
    # RANDOM() -> RAND()
    (re.compile(r'\bRANDOM\s*\(\s*\)', re.IGNORECASE),
     'RAND()', 'math'),
    # CBRT(x) -> POWER(x, 1.0/3.0)
    (re.compile(r'\bCBRT\s*\(\s*([^)]+?)\s*\)', re.IGNORECASE),
     r'POWER(\1, 1.0/3.0)', 'math'),
    # TRUNC(number, integer_scale) -> TRUNCATE(number, scale) for numeric truncation
    # Must come before DATE TRUNC patterns -- detect numeric scale (unquoted integer)
    (re.compile(r'(?<!\w)TRUNC\s*\(\s*([^,)]+?)\s*,\s*(-?\d+)\s*\)', re.IGNORECASE),
     r'TRUNCATE(\1, \2)', 'math'),
    # CHECKSUM -> CRC32 with advisory
    (re.compile(r'\bCHECKSUM\s*\(\s*([^)]+?)\s*\)', re.IGNORECASE),
     r'CRC32(CAST(\1 AS BINARY)) /* CHECKSUM: verify algorithm compatibility */', 'math'),

    # ── CONVERT function (not CONVERT_TIMEZONE) ──────────────────────────
    # CONVERT(type, expr) -> CAST(expr AS type)
    (re.compile(
        r'\bCONVERT\s*\(\s*(INTEGER|INT|VARCHAR|TEXT|DATE|FLOAT|DOUBLE|DECIMAL|BOOLEAN|BIGINT|SMALLINT|TIMESTAMP|STRING|NUMERIC|CHAR|REAL|BINARY|TINYINT)\s*,\s*([^)]+?)\s*\)',
        re.IGNORECASE),
     r'CAST(\2 AS \1)', 'casting'),

    # ── Casting (:: syntax) ──────────────────────────────────────────────
    # Note: [\w.]+ captures dot-path expressions like schema.table.col
    # val::INTEGER -> CAST(val AS INT)
    (re.compile(r'([\w.]+)::INTEGER\b', re.IGNORECASE),
     r'CAST(\1 AS INT)', 'casting'),
    (re.compile(r'([\w.]+)::INT\b', re.IGNORECASE),
     r'CAST(\1 AS INT)', 'casting'),
    # val::VARCHAR(n) -> CAST(val AS STRING) — must come before bare ::VARCHAR
    (re.compile(r'([\w.]+)::VARCHAR\s*\(\d+\)', re.IGNORECASE),
     r'CAST(\1 AS STRING)', 'casting'),
    # val::CHAR(n) -> CAST(val AS STRING)
    (re.compile(r'([\w.]+)::CHAR\s*\(\d+\)', re.IGNORECASE),
     r'CAST(\1 AS STRING)', 'casting'),
    # val::VARCHAR -> CAST(val AS STRING)
    (re.compile(r'([\w.]+)::VARCHAR\b', re.IGNORECASE),
     r'CAST(\1 AS STRING)', 'casting'),
    # val::TEXT -> CAST(val AS STRING)
    (re.compile(r'([\w.]+)::TEXT\b', re.IGNORECASE),
     r'CAST(\1 AS STRING)', 'casting'),
    # val::DATE -> CAST(val AS DATE)
    (re.compile(r'([\w.]+)::DATE\b', re.IGNORECASE),
     r'CAST(\1 AS DATE)', 'casting'),
    # val::FLOAT -> CAST(val AS DOUBLE)
    (re.compile(r'([\w.]+)::FLOAT\b', re.IGNORECASE),
     r'CAST(\1 AS DOUBLE)', 'casting'),
    # val::BOOLEAN -> CAST(val AS BOOLEAN)
    (re.compile(r'([\w.]+)::BOOLEAN\b', re.IGNORECASE),
     r'CAST(\1 AS BOOLEAN)', 'casting'),
    # val::DECIMAL(p,s) -> CAST(val AS DECIMAL(p,s))
    (re.compile(r'([\w.]+)::DECIMAL\s*\(([^)]+)\)', re.IGNORECASE),
     r'CAST(\1 AS DECIMAL(\2))', 'casting'),
    # val::NUMERIC(p,s) -> CAST(val AS DECIMAL(p,s))
    (re.compile(r'([\w.]+)::NUMERIC\s*\(([^)]+)\)', re.IGNORECASE),
     r'CAST(\1 AS DECIMAL(\2))', 'casting'),
    # val::TIMESTAMP -> CAST(val AS TIMESTAMP)
    (re.compile(r'([\w.]+)::TIMESTAMP\b', re.IGNORECASE),
     r'CAST(\1 AS TIMESTAMP)', 'casting'),
    # val::BIGINT -> CAST(val AS BIGINT)
    (re.compile(r'([\w.]+)::BIGINT\b', re.IGNORECASE),
     r'CAST(\1 AS BIGINT)', 'casting'),
    # val::SMALLINT -> CAST(val AS SMALLINT)
    (re.compile(r'([\w.]+)::SMALLINT\b', re.IGNORECASE),
     r'CAST(\1 AS SMALLINT)', 'casting'),
    # val::DOUBLE -> CAST(val AS DOUBLE)
    (re.compile(r'([\w.]+)::DOUBLE\b', re.IGNORECASE),
     r'CAST(\1 AS DOUBLE)', 'casting'),
    # Generic expr::TYPE for parenthesized expressions handled by convert_paren_casts()
]


# Redshift-specific DDL constructs to remove
REDSHIFT_CONSTRUCT_PATTERNS: List[Tuple[re.Pattern, str, str]] = [
    # DISTKEY(col) clause
    (re.compile(r'\s*DISTKEY\s*\([^)]*\)', re.IGNORECASE),
     '', 'DISTKEY removed -> use CLUSTER BY (liquid clustering) or PARTITIONED BY'),
    # DISTSTYLE keyword + value
    (re.compile(r'\s*DISTSTYLE\s+\w+', re.IGNORECASE),
     '', 'DISTSTYLE removed -> Databricks uses automatic data distribution; for DISTSTYLE ALL use broadcast() hint'),
    # SORTKEY(col, ...) clause
    (re.compile(r'\s*(?:COMPOUND\s+|INTERLEAVED\s+)?SORTKEY\s*\([^)]*\)', re.IGNORECASE),
     '', 'SORTKEY removed -> use OPTIMIZE ... ZORDER BY or CLUSTER BY (liquid clustering)'),
    # ENCODE encoding (may appear at start of string when extracted as constraint)
    (re.compile(r'(?:^|\s+)ENCODE\s+\w+', re.IGNORECASE),
     '', 'ENCODE removed -> Databricks Delta Lake manages compression automatically via optimized codecs'),
    # WITH NO SCHEMA BINDING (views)
    (re.compile(r'\s+WITH\s+NO\s+SCHEMA\s+BINDING', re.IGNORECASE),
     '', 'WITH NO SCHEMA BINDING removed -> Databricks views always use late binding (no equivalent needed)'),
    # AUTO REFRESH YES/NO (materialized views)
    (re.compile(r'\s+AUTO\s+REFRESH\s+(?:YES|NO)', re.IGNORECASE),
     '', 'AUTO REFRESH removed -> Databricks manages MV refresh via scheduled refresh or REFRESH MATERIALIZED VIEW command'),
    # BACKUP YES/NO
    (re.compile(r'\s+BACKUP\s+(?:YES|NO)', re.IGNORECASE),
     '', 'BACKUP removed -> Databricks Delta Lake provides automatic versioning and time travel (no BACKUP needed)'),
    # IDENTITY(seed, step) -> GENERATED ALWAYS AS IDENTITY
    (re.compile(r'(?:^|\s+)IDENTITY\s*\(\s*\d+\s*,\s*\d+\s*\)', re.IGNORECASE),
     ' GENERATED ALWAYS AS IDENTITY', 'converted IDENTITY to GENERATED ALWAYS AS IDENTITY'),
    # DEFAULT GETDATE() -> DEFAULT CURRENT_TIMESTAMP
    (re.compile(r'\bDEFAULT\s+GETDATE\s*\(\s*\)', re.IGNORECASE),
     'DEFAULT CURRENT_TIMESTAMP', 'converted DEFAULT GETDATE() to DEFAULT CURRENT_TIMESTAMP'),
    # DEFAULT SYSDATE -> DEFAULT CURRENT_TIMESTAMP
    (re.compile(r'\bDEFAULT\s+SYSDATE\b', re.IGNORECASE),
     'DEFAULT CURRENT_TIMESTAMP', 'converted DEFAULT SYSDATE to DEFAULT CURRENT_TIMESTAMP'),
    # CASCADE in DROP TABLE (not supported in Databricks)
    (re.compile(r'\s+CASCADE\b', re.IGNORECASE),
     ' /* CASCADE not supported */', 'removed CASCADE (not supported in Databricks)'),
    # RESTRICT in DROP TABLE (default behavior in Databricks)
    (re.compile(r'\s+RESTRICT\b', re.IGNORECASE),
     '', 'RESTRICT removed -> Databricks DROP is RESTRICT by default'),
    # VACUUM command (Redshift-specific, replaced by OPTIMIZE in Databricks)
    (re.compile(r'\bVACUUM\s+(?:FULL\s+|DELETE\s+ONLY\s+|SORT\s+ONLY\s+|REINDEX\s+)?(?:TO\s+\d+\s+PERCENT\s+)?([\w.]+)', re.IGNORECASE),
     r'-- VACUUM removed -> Databricks equivalent: OPTIMIZE \1', 'VACUUM removed -> Databricks: OPTIMIZE table or Delta auto-optimization'),
    # ANALYZE (Redshift statistics, not needed in Databricks)
    (re.compile(r'\bANALYZE\s+(?:COMPRESSION\s+)?([\w.]+)', re.IGNORECASE),
     r'-- ANALYZE removed -> Databricks: ANALYZE TABLE \1 COMPUTE STATISTICS', 'ANALYZE removed -> Databricks: ANALYZE TABLE ... COMPUTE STATISTICS'),
    # LOCK TABLE (not supported in Databricks, Delta uses ACID transactions)
    (re.compile(r'\bLOCK\s+TABLE\s+[\w.]+(?:\s+IN\s+\w+\s+MODE)?', re.IGNORECASE),
     '', 'LOCK TABLE removed -> Databricks Delta uses ACID transactions (no explicit locking needed)'),
    # ALTER TABLE APPEND (Redshift-specific, not supported in Databricks)
    (re.compile(r'\bALTER\s+TABLE\s+([\w.]+)\s+APPEND\s+FROM\s+([\w.]+)', re.IGNORECASE),
     r'-- ALTER TABLE APPEND not supported in Databricks. Use: INSERT INTO \1 SELECT * FROM \2',
     'ALTER TABLE APPEND -> INSERT INTO ... SELECT (or MERGE)'),
    # GRANT/REVOKE (pass through but add advisory about Unity Catalog)
    # Not removing — just flagging in full_sql_convert
]


# Data type mapping for column definitions (used across DDL, views, CTAS, etc.)
DATA_TYPE_MAP: List[Tuple[re.Pattern, str, str]] = [
    # HIGH-07: DATETIME -> TIMESTAMP (Databricks has no DATETIME type)
    (re.compile(r'\bDATETIME\b', re.IGNORECASE),
     'TIMESTAMP', 'DATETIME -> TIMESTAMP'),
    # TIMESTAMPTZ variants
    (re.compile(r'\btimestamptz\b', re.IGNORECASE),
     'TIMESTAMP', 'TIMESTAMPTZ -> TIMESTAMP (UTC)'),
    (re.compile(r'\btimestamp\s+with\s+time\s+zone\b', re.IGNORECASE),
     'TIMESTAMP', 'TIMESTAMP WITH TIME ZONE -> TIMESTAMP (UTC)'),
    # TIMESTAMP WITHOUT TIME ZONE -> TIMESTAMP (must come before bare TIMESTAMP entry)
    (re.compile(r'\bTIMESTAMP\s+WITHOUT\s+TIME\s+ZONE\b', re.IGNORECASE),
     'TIMESTAMP', 'TIMESTAMP WITHOUT TIME ZONE -> TIMESTAMP'),
    # TIME / TIMETZ -> STRING
    (re.compile(r'\btimetz\b', re.IGNORECASE),
     'STRING', 'TIMETZ -> STRING'),
    (re.compile(r'\btime\s+with(?:out)?\s+time\s+zone\b', re.IGNORECASE),
     'STRING', 'TIME WITH/WITHOUT TIME ZONE -> STRING'),
    # BPCHAR(n)
    (re.compile(r'\bbpchar\s*\(\s*\d+\s*\)', re.IGNORECASE),
     'STRING', 'BPCHAR(n) -> STRING'),
    # BPCHAR without length
    (re.compile(r'\bbpchar\b', re.IGNORECASE),
     'STRING', 'BPCHAR -> STRING'),
    # NUMERIC(p,s) -> DECIMAL(p,s)
    (re.compile(r'\bnumeric\s*\((\s*\d+\s*,\s*\d+\s*)\)', re.IGNORECASE),
     r'DECIMAL(\1)', 'NUMERIC(p,s) -> DECIMAL(p,s)'),
    # NUMERIC(p) without scale -> DECIMAL(p,0) -- explicit to avoid default precision mismatch
    (re.compile(r'\bnumeric\s*\(\s*(\d+)\s*\)', re.IGNORECASE),
     r'DECIMAL(\1,0)', 'NUMERIC(p) -> DECIMAL(p,0)'),
    # NUMERIC without precision -> DECIMAL(18,0) -- RS default=18, DB default=10, explicit to prevent truncation
    (re.compile(r'\bnumeric\b(?!\s*\()', re.IGNORECASE),
     'DECIMAL(18,0)', 'NUMERIC -> DECIMAL(18,0) (RS default precision is 18, DB default is 10)'),
    # NVARCHAR(n) -> STRING (Redshift alias for VARCHAR)
    (re.compile(r'\bnvarchar\s*\(\s*\d+\s*\)', re.IGNORECASE),
     'STRING', 'NVARCHAR(n) -> STRING'),
    # NVARCHAR without length -> STRING
    (re.compile(r'\bnvarchar\b(?!\s*\()', re.IGNORECASE),
     'STRING', 'NVARCHAR -> STRING'),
    # NCHAR(n) -> STRING (Redshift alias for CHAR)
    (re.compile(r'\bnchar\s*\(\s*\d+\s*\)', re.IGNORECASE),
     'STRING', 'NCHAR(n) -> STRING'),
    # NCHAR without length -> STRING
    (re.compile(r'\bnchar\b(?!\s*\()', re.IGNORECASE),
     'STRING', 'NCHAR -> STRING'),
    # VARCHAR without length -> STRING
    (re.compile(r'\bvarchar\b(?!\s*\()', re.IGNORECASE),
     'STRING', 'VARCHAR -> STRING'),
    # VARCHAR(n) -> STRING
    (re.compile(r'\bvarchar\s*\(\s*\d+\s*\)', re.IGNORECASE),
     'STRING', 'VARCHAR(n) -> STRING'),
    # CHARACTER VARYING(n)
    (re.compile(r'\bcharacter\s+varying\s*\(\s*\d+\s*\)', re.IGNORECASE),
     'STRING', 'CHARACTER VARYING(n) -> STRING'),
    # CHARACTER(n) -> STRING (explicit alias for CHAR(n))
    (re.compile(r'\bcharacter\s*\(\s*\d+\s*\)', re.IGNORECASE),
     'STRING', 'CHARACTER(n) -> STRING'),
    # CHAR(n) -> STRING
    (re.compile(r'\bchar\s*\(\s*\d+\s*\)', re.IGNORECASE),
     'STRING', 'CHAR(n) -> STRING'),
    # DOUBLE PRECISION -> DOUBLE
    (re.compile(r'\bdouble\s+precision\b', re.IGNORECASE),
     'DOUBLE', 'DOUBLE PRECISION -> DOUBLE'),
    # FLOAT8 -> DOUBLE
    (re.compile(r'\bfloat8\b', re.IGNORECASE),
     'DOUBLE', 'FLOAT8 -> DOUBLE'),
    # FLOAT4 -> FLOAT
    (re.compile(r'\bfloat4\b', re.IGNORECASE),
     'FLOAT', 'FLOAT4 -> FLOAT'),
    # FLOAT (without qualifier) -> DOUBLE (RS FLOAT=8 bytes, DB FLOAT=4 bytes!)
    (re.compile(r'\bfloat\b(?!\d)', re.IGNORECASE),
     'DOUBLE', 'FLOAT -> DOUBLE (RS FLOAT is 8 bytes; DB FLOAT is only 4 bytes)'),
    # REAL -> FLOAT (RS REAL is actually 8 bytes in practice, but mapped to 4-byte FLOAT with warning)
    (re.compile(r'\breal\b', re.IGNORECASE),
     'FLOAT', 'REAL -> FLOAT'),
    # INT2 -> SMALLINT
    (re.compile(r'\bint2\b', re.IGNORECASE),
     'SMALLINT', 'INT2 -> SMALLINT'),
    # INT4 -> INT
    (re.compile(r'\bint4\b', re.IGNORECASE),
     'INT', 'INT4 -> INT'),
    # INT8 -> BIGINT
    (re.compile(r'\bint8\b', re.IGNORECASE),
     'BIGINT', 'INT8 -> BIGINT'),
    # SUPER -> STRING (JSON)
    (re.compile(r'\bsuper\b', re.IGNORECASE),
     'STRING', 'SUPER -> STRING (JSON)'),
    # VARBYTE / VARBINARY / BINARY VARYING -> BINARY (length stripped — Databricks BINARY has no length)
    (re.compile(r'\bvarbyte\s*(?:\(\s*\d+\s*\))?', re.IGNORECASE),
     'BINARY', 'VARBYTE -> BINARY'),
    (re.compile(r'\bvarbinary\s*(?:\(\s*\d+\s*\))?', re.IGNORECASE),
     'BINARY', 'VARBINARY -> BINARY'),
    (re.compile(r'\bbinary\s+varying\s*(?:\(\s*\d+\s*\))?', re.IGNORECASE),
     'BINARY', 'BINARY VARYING -> BINARY'),
    # HLLSKETCH -> not supported
    (re.compile(r'\bhllsketch\b', re.IGNORECASE),
     'STRING', 'HLLSKETCH -> STRING (use APPROX_COUNT_DISTINCT)'),
    # TEXT -> STRING (Redshift alias for VARCHAR(256))
    (re.compile(r'\btext\b', re.IGNORECASE),
     'STRING', 'TEXT -> STRING'),
    # BOOL -> BOOLEAN
    (re.compile(r'\bbool\b(?!ean)', re.IGNORECASE),
     'BOOLEAN', 'BOOL -> BOOLEAN'),
    # bare CHAR without length -> STRING
    (re.compile(r'\bchar\b(?!\s*\()', re.IGNORECASE),
     'STRING', 'CHAR -> STRING'),
    # TIME without qualifier -> STRING (Databricks has no TIME type)
    (re.compile(r'\btime\b(?!\s+with|\s+zone|\s*tz|\s*stamp)', re.IGNORECASE),
     'STRING', 'TIME -> STRING (no TIME type in Databricks)'),
    # GEOMETRY -> STRING (WKT)
    (re.compile(r'\bgeometry\b', re.IGNORECASE),
     'STRING', 'GEOMETRY -> STRING (use WKT/Mosaic)'),
    # GEOGRAPHY -> STRING (WKT)
    (re.compile(r'\bgeography\b', re.IGNORECASE),
     'STRING', 'GEOGRAPHY -> STRING (use WKT/Mosaic)'),
    # OID -> BIGINT (Redshift system type)
    (re.compile(r'\boid\b', re.IGNORECASE),
     'BIGINT', 'OID -> BIGINT (Redshift system type)'),
    # NAME -> STRING (Redshift system type)
    (re.compile(r'\bname\b', re.IGNORECASE),
     'STRING', 'NAME -> STRING (Redshift system type)'),
]


def apply_function_translations(sql: str) -> Tuple[str, List[str]]:
    """Apply all function translations to a SQL string.

    Returns (converted_sql, list_of_conversions_applied).
    """
    conversions = []
    for pattern, replacement, category in FUNCTION_TRANSLATIONS:
        if pattern.search(sql):
            sql = pattern.sub(replacement, sql)
            # Build a readable conversion description
            import re as _re
            # Try to extract function/keyword name from the regex
            _m = _re.search(r'\\b(\w+)', pattern.pattern)
            if _m:
                func_name = _m.group(1)
            else:
                # Handle :: casting patterns like (\w+)::VARCHAR
                _m2 = _re.search(r'::(\w+)', pattern.pattern)
                func_name = f'::{_m2.group(1)}' if _m2 else pattern.pattern
            # Strip regex back-references from replacement for display
            clean_repl = _re.sub(r'\\[0-9]+', '...', replacement).strip()
            conversions.append(f'{category}: {func_name} -> {clean_repl[:60]}')
    return sql, conversions


def apply_construct_removals(sql: str) -> Tuple[str, List[str]]:
    """Remove Redshift-specific DDL constructs.

    Returns (cleaned_sql, list_of_removals).
    """
    removals = []
    for pattern, replacement, label in REDSHIFT_CONSTRUCT_PATTERNS:
        if pattern.search(sql):
            sql = pattern.sub(replacement, sql)
            removals.append(label)
    return sql, removals


def apply_type_mappings(type_str: str) -> Tuple[str, str]:
    """Convert a single Redshift data type to Databricks equivalent.

    Returns (databricks_type, conversion_note) or (original, '') if no change.
    """
    for pattern, replacement, note in DATA_TYPE_MAP:
        if pattern.search(type_str):
            converted = pattern.sub(replacement, type_str)
            return converted, note
    return type_str, ''


def convert_paren_casts(sql: str) -> Tuple[str, List[str]]:
    """Convert (expr)::TYPE and ) ::TYPE to CAST(expr AS TYPE) with balanced parentheses.

    Simple word::TYPE patterns are handled by FUNCTION_TRANSLATIONS.
    This handles the parenthesized form: (complex_expr)::TYPE.
    """
    conversions = []
    # Allow optional space between ) and ::
    pattern = re.compile(r'\)\s*::\s*(\w+)(?:\s*\(([^)]+)\))?', re.IGNORECASE)
    result = []
    pos = 0
    # Type mapping for cast normalization
    cast_type_map = {
        'varchar': 'STRING', 'text': 'STRING', 'char': 'STRING',
        'integer': 'INT', 'int': 'INT', 'int4': 'INT',
        'bigint': 'BIGINT', 'int8': 'BIGINT',
        'float': 'DOUBLE', 'float8': 'DOUBLE', 'float4': 'FLOAT',
        'boolean': 'BOOLEAN', 'bool': 'BOOLEAN',
        'numeric': 'DECIMAL', 'decimal': 'DECIMAL',
        'varbyte': 'BINARY', 'varbinary': 'BINARY', 'binary': 'BINARY',
    }
    # Types where length/precision must be stripped (Databricks does not accept it)
    no_precision_types = {'STRING', 'BINARY'}
    for match in pattern.finditer(sql):
        close_paren_pos = match.start()  # position of ')'
        cast_type = match.group(1)
        precision = match.group(2)
        # Walk backwards to find matching '('
        depth = 1
        i = close_paren_pos - 1
        while i >= 0 and depth > 0:
            if sql[i] == ')':
                depth += 1
            elif sql[i] == '(':
                depth -= 1
            i -= 1
        open_paren_pos = i + 1  # position of matching '('
        if depth == 0:
            db_type = cast_type_map.get(cast_type.lower(), cast_type.upper())
            if precision and db_type not in no_precision_types:
                db_type = f'{db_type}({precision})'
            # Check if '(' is part of a function call (preceded by word chars)
            func_start = open_paren_pos
            while func_start > 0 and (sql[func_start - 1].isalnum() or sql[func_start - 1] in '_.'):
                func_start -= 1
            if func_start < open_paren_pos:
                # It's a function call like DATE_FORMAT(...) ::INT
                # Wrap entire function call: CAST(func_name(args) AS TYPE)
                func_expr = sql[func_start:close_paren_pos + 1]
                result.append(sql[pos:func_start])
                result.append(f'CAST({func_expr} AS {db_type})')
            else:
                # Standalone parenthesized expression: (expr)::TYPE
                result.append(sql[pos:open_paren_pos])
                inner_expr = sql[open_paren_pos + 1:close_paren_pos]
                result.append(f'CAST({inner_expr} AS {db_type})')
            pos = match.end()
            conversions.append(f'casting: ::{cast_type} -> CAST(... AS {db_type})')
    result.append(sql[pos:])
    return ''.join(result), conversions


def convert_remaining_casts(sql: str) -> Tuple[str, List[str]]:
    """Catch any remaining :: cast patterns not handled by FUNCTION_TRANSLATIONS.

    Handles: col :: VARCHAR, expr]::TYPE, spaces around ::, quoted strings, etc.
    Runs AFTER convert_paren_casts() and apply_function_translations().
    """
    conversions = []
    # Type mapping for :: casts
    cast_type_map = {
        'varchar': 'STRING', 'text': 'STRING', 'char': 'STRING', 'string': 'STRING',
        'integer': 'INT', 'int': 'INT', 'int4': 'INT',
        'bigint': 'BIGINT', 'int8': 'BIGINT',
        'smallint': 'SMALLINT', 'int2': 'SMALLINT',
        'float': 'DOUBLE', 'float4': 'FLOAT', 'float8': 'DOUBLE',
        'double': 'DOUBLE', 'real': 'FLOAT',
        'boolean': 'BOOLEAN', 'bool': 'BOOLEAN',
        'date': 'DATE', 'timestamp': 'TIMESTAMP',
        'numeric': 'DECIMAL', 'decimal': 'DECIMAL',
        'varbyte': 'BINARY', 'varbinary': 'BINARY', 'binary': 'BINARY',
    }
    # Types where length/precision must be stripped (Databricks does not accept it)
    no_precision_types = {'STRING', 'BINARY'}

    def _map_type(raw_type, precision):
        db_type = cast_type_map.get(raw_type.lower(), raw_type.upper())
        if precision:
            if db_type in no_precision_types:
                pass
            else:
                db_type = f'{db_type}({precision})'
        return db_type

    # Pass 0 (CRIT-04): Handle bracket+dot expressions before :: (e.g., t.product_json.images[0].url::VARCHAR)
    # Must run FIRST — other passes don't capture the full multi-segment bracket+dot path.
    bracket_dot_pattern = re.compile(
        r'(\w+(?:\.\w+)*\[\d+\](?:\.\w+)+)\s*::\s*(\w+)(?:\s*\(\s*([^)]+)\s*\))?',
        re.IGNORECASE,
    )
    def bracket_dot_replacer(m):
        expr = m.group(1)
        raw_type = m.group(2)
        precision = m.group(3)
        db_type = _map_type(raw_type, precision)
        conversions.append(f'casting: ::{raw_type.lower()} -> CAST(... AS {db_type})')
        return f'CAST({expr} AS {db_type})'
    sql = bracket_dot_pattern.sub(bracket_dot_replacer, sql)

    # Pass 1: Handle quoted strings before :: (e.g., '-99'::BIGINT)
    quoted_pattern = re.compile(
        r"('[^']*')\s*::\s*(\w+)(?:\s*\(([^)]+)\))?",
        re.IGNORECASE,
    )
    def quoted_replacer(m):
        expr = m.group(1)
        raw_type = m.group(2)
        precision = m.group(3)
        db_type = _map_type(raw_type, precision)
        conversions.append(f'casting: ::{raw_type.lower()} -> CAST(... AS {db_type})')
        return f'CAST({expr} AS {db_type})'
    sql = quoted_pattern.sub(quoted_replacer, sql)

    # Pass 2: Handle bracket expressions before :: (e.g., col[0]::VARCHAR, path.arr[1].field::INT)
    # FIX 4: Extended pattern to capture trailing .field after bracket
    bracket_pattern = re.compile(
        r'([\w.]+\[\d+\](?:\.[\w.]+)*)\s*::\s*(\w+)(?:\s*\(([^)]+)\))?',
        re.IGNORECASE,
    )
    def bracket_replacer(m):
        expr = m.group(1)
        raw_type = m.group(2)
        precision = m.group(3)
        db_type = _map_type(raw_type, precision)
        conversions.append(f'casting: ::{raw_type.lower()} -> CAST(... AS {db_type})')
        return f'CAST({expr} AS {db_type})'
    sql = bracket_pattern.sub(bracket_replacer, sql)

    # Pass 3: Handle identifier/dot-path before :: (e.g., col::VARCHAR, schema.col::INT)
    # Use [\w.]+ to capture dot-paths but NOT commas or parens
    ident_pattern = re.compile(
        r'([\w.]+)\s*::\s*(\w+)(?:\s*\(([^)]+)\))?',
        re.IGNORECASE,
    )
    def ident_replacer(m):
        expr = m.group(1)
        raw_type = m.group(2)
        precision = m.group(3)
        db_type = _map_type(raw_type, precision)
        conversions.append(f'casting: ::{raw_type.lower()} -> CAST(... AS {db_type})')
        return f'CAST({expr} AS {db_type})'
    sql = ident_pattern.sub(ident_replacer, sql)

    return sql, conversions


def convert_decode(sql: str) -> str:
    """Convert DECODE(expr, v1, r1, v2, r2, ..., default) to CASE WHEN.

    DECODE is complex with variable args, handled separately.
    """
    # Match DECODE( with balanced parens
    decode_pattern = re.compile(r'\bDECODE\s*\(', re.IGNORECASE)
    result = []
    pos = 0
    for match in decode_pattern.finditer(sql):
        result.append(sql[pos:match.start()])
        # Find matching closing paren
        start = match.end()
        depth = 1
        i = start
        while i < len(sql) and depth > 0:
            if sql[i] == '(':
                depth += 1
            elif sql[i] == ')':
                depth -= 1
            i += 1
        args_str = sql[start:i - 1]
        # Split args carefully (respecting nested parens)
        args = _split_args(args_str)
        if len(args) >= 3:
            expr = args[0].strip()
            pairs = []
            idx = 1
            while idx + 1 < len(args):
                pairs.append((args[idx].strip(), args[idx + 1].strip()))
                idx += 2
            default = args[idx].strip() if idx < len(args) else 'NULL'
            case_parts = [f'CASE {expr}']
            for val, res in pairs:
                case_parts.append(f' WHEN {val} THEN {res}')
            case_parts.append(f' ELSE {default} END')
            result.append(''.join(case_parts))
        else:
            result.append(match.group() + args_str + ')')
        pos = i
    result.append(sql[pos:])
    return ''.join(result)


def _split_args(args_str: str) -> List[str]:
    """Split function arguments respecting nested parentheses."""
    args = []
    depth = 0
    current = []
    for char in args_str:
        if char == '(':
            depth += 1
            current.append(char)
        elif char == ')':
            depth -= 1
            current.append(char)
        elif char == ',' and depth == 0:
            args.append(''.join(current))
            current = []
        else:
            current.append(char)
    if current:
        args.append(''.join(current))
    return args


def _is_inside_string_literal(sql: str, pos: int) -> bool:
    """Check if position is inside a single-quoted SQL string literal.

    Scans from start of string counting quote boundaries, handling escaped quotes ('').
    """
    in_string = False
    i = 0
    while i < pos:
        if sql[i] == "'":
            if in_string:
                # Check for escaped quote
                if i + 1 < len(sql) and sql[i + 1] == "'":
                    i += 2
                    continue
                in_string = False
            else:
                in_string = True
        i += 1
    return in_string


def _split_balanced_args(content: str, start_pos: int) -> Tuple[List[str], int]:
    """Walk from an opening paren, split at top-level commas, return (args, end_pos).

    Args:
        content: Full SQL string.
        start_pos: Index of the opening '(' character.

    Returns:
        (list_of_arg_strings, position_one_past_closing_paren).
        If no matching close paren is found, returns ([], start_pos).
    """
    if start_pos >= len(content) or content[start_pos] != '(':
        return [], start_pos
    depth = 1
    i = start_pos + 1
    args: List[str] = []
    arg_start = i
    while i < len(content) and depth > 0:
        ch = content[i]
        if ch == '(':
            depth += 1
        elif ch == ')':
            depth -= 1
            if depth == 0:
                args.append(content[arg_start:i].strip())
                i += 1
                return args, i
        elif ch == '[':
            depth += 1
        elif ch == ']':
            depth -= 1
        elif ch == ',' and depth == 1:
            args.append(content[arg_start:i].strip())
            arg_start = i + 1
        elif ch == "'":
            # Skip past quoted string (handles escaped quotes '')
            j = i + 1
            while j < len(content):
                if content[j] == "'":
                    if j + 1 < len(content) and content[j + 1] == "'":
                        j += 2  # skip escaped quote ''
                        continue
                    break
                j += 1
            i = j
        i += 1
    # Unmatched parens
    return [], start_pos


def convert_dateadd(sql: str) -> Tuple[str, List[str]]:
    """Convert DATEADD(unit, amount, date_expr) using balanced-paren parsing.

    Handles nested function calls in arguments that break simple regex.
    """
    conversions: List[str] = []
    pattern = re.compile(r'\bDATEADD\s*\(', re.IGNORECASE)
    result = []
    pos = 0

    for m in pattern.finditer(sql):
        if m.start() < pos:
            continue
        if _is_inside_string_literal(sql, m.start()):
            continue
        result.append(sql[pos:m.start()])
        paren_pos = m.end() - 1  # position of '('
        args, end_pos = _split_balanced_args(sql, paren_pos)

        if len(args) == 3:
            unit = args[0].strip().lower()
            amount = args[1].strip()
            date_expr = args[2].strip()

            if unit in ('month', 'mon', 'months'):
                replacement = f'ADD_MONTHS({date_expr}, {amount})'
            elif unit in ('year', 'yr', 'yrs', 'years'):
                replacement = f'ADD_MONTHS({date_expr}, {amount} * 12)'
            elif unit in ('day', 'd', 'days'):
                replacement = f'DATE_ADD({date_expr}, {amount})'
            elif unit in ('hour', 'h', 'hr', 'hrs', 'hours'):
                replacement = f'DATEADD(HOUR, {amount}, {date_expr})'
            elif unit in ('minute', 'min', 'mins', 'minutes'):
                replacement = f'DATEADD(MINUTE, {amount}, {date_expr})'
            elif unit in ('second', 'sec', 'secs', 'seconds'):
                replacement = f'DATEADD(SECOND, {amount}, {date_expr})'
            elif unit in ('millisecond', 'ms', 'msec', 'msecs', 'milliseconds'):
                replacement = f'DATEADD(MILLISECOND, {amount}, {date_expr})'
            elif unit in ('microsecond', 'us', 'usec', 'usecs', 'microseconds'):
                replacement = f'DATEADD(MICROSECOND, {amount}, {date_expr})'
            elif unit in ('week', 'w', 'wk', 'wks', 'weeks'):
                replacement = f'DATE_ADD({date_expr}, {amount} * 7)'
            elif unit in ('quarter', 'qtr', 'qtrs', 'quarters'):
                replacement = f'ADD_MONTHS({date_expr}, {amount} * 3)'
            else:
                replacement = f'DATE_ADD({date_expr}, {amount})'

            conversions.append(f'date: DATEADD({unit}) -> {replacement[:60]}')
            result.append(replacement)
        else:
            # Not a valid 3-arg DATEADD, leave as-is
            result.append(sql[m.start():end_pos])
        pos = end_pos

    result.append(sql[pos:])
    return ''.join(result), conversions


def convert_datediff(sql: str) -> Tuple[str, List[str]]:
    """Convert DATEDIFF(unit, start_expr, end_expr) using balanced-paren parsing.

    Handles nested function calls in arguments that break simple regex.
    """
    conversions: List[str] = []
    pattern = re.compile(r'\bDATEDIFF\s*\(', re.IGNORECASE)
    result = []
    pos = 0

    for m in pattern.finditer(sql):
        if m.start() < pos:
            continue
        if _is_inside_string_literal(sql, m.start()):
            continue
        result.append(sql[pos:m.start()])
        paren_pos = m.end() - 1  # position of '('
        args, end_pos = _split_balanced_args(sql, paren_pos)

        if len(args) == 3:
            unit = args[0].strip().lower()
            start_expr = args[1].strip()
            end_expr = args[2].strip()

            if unit in ('day', 'd', 'days'):
                replacement = f'DATEDIFF({end_expr}, {start_expr})'
            elif unit in ('month', 'mon', 'months'):
                replacement = f'MONTHS_BETWEEN({end_expr}, {start_expr})'
            elif unit in ('year', 'yr', 'yrs', 'years'):
                replacement = f'FLOOR(MONTHS_BETWEEN({end_expr}, {start_expr}) / 12)'
            elif unit in ('hour', 'h', 'hr', 'hrs', 'hours'):
                replacement = f'(UNIX_TIMESTAMP({end_expr}) - UNIX_TIMESTAMP({start_expr})) / 3600'
            elif unit in ('minute', 'min', 'mins', 'minutes'):
                replacement = f'(UNIX_TIMESTAMP({end_expr}) - UNIX_TIMESTAMP({start_expr})) / 60'
            elif unit in ('second', 'sec', 'secs', 'seconds'):
                replacement = f'(UNIX_TIMESTAMP({end_expr}) - UNIX_TIMESTAMP({start_expr}))'
            elif unit in ('week', 'w', 'wk', 'wks', 'weeks'):
                replacement = f'CAST(DATEDIFF({end_expr}, {start_expr}) / 7 AS INT)'
            else:
                replacement = f'DATEDIFF({end_expr}, {start_expr})'

            conversions.append(f'date: DATEDIFF({unit}) -> {replacement[:60]}')
            result.append(replacement)
        elif len(args) == 2:
            # Already 2-arg Databricks DATEDIFF(end, start) — leave as-is
            result.append(sql[m.start():end_pos])
        else:
            result.append(sql[m.start():end_pos])
        pos = end_pos

    result.append(sql[pos:])
    return ''.join(result), conversions


def convert_btrim(sql: str) -> Tuple[str, List[str]]:
    """Convert BTRIM(expr[, chars]) using balanced-paren parsing.

    1 arg: BTRIM(expr) -> TRIM(expr)
    2 args: BTRIM(expr, chars) -> TRIM(BOTH chars FROM expr)
    """
    conversions: List[str] = []
    pattern = re.compile(r'\bBTRIM\s*\(', re.IGNORECASE)
    result = []
    pos = 0

    for m in pattern.finditer(sql):
        if m.start() < pos:
            continue
        if _is_inside_string_literal(sql, m.start()):
            continue
        result.append(sql[pos:m.start()])
        paren_pos = m.end() - 1
        args, end_pos = _split_balanced_args(sql, paren_pos)

        if len(args) == 1:
            replacement = f'TRIM({args[0]})'
            conversions.append('string: BTRIM(1-arg) -> TRIM')
        elif len(args) == 2:
            replacement = f'TRIM(BOTH {args[1]} FROM {args[0]})'
            conversions.append('string: BTRIM(2-arg) -> TRIM(BOTH ... FROM ...)')
        else:
            result.append(sql[m.start():end_pos])
            pos = end_pos
            continue

        result.append(replacement)
        pos = end_pos

    result.append(sql[pos:])
    return ''.join(result), conversions


def convert_strtol(sql: str) -> Tuple[str, List[str]]:
    """Convert STRTOL(str_expr, base) -> CONV(str_expr, base, 10) using balanced-paren parsing."""
    conversions: List[str] = []
    pattern = re.compile(r'\bSTRTOL\s*\(', re.IGNORECASE)
    result = []
    pos = 0

    for m in pattern.finditer(sql):
        if m.start() < pos:
            continue
        if _is_inside_string_literal(sql, m.start()):
            continue
        result.append(sql[pos:m.start()])
        paren_pos = m.end() - 1
        args, end_pos = _split_balanced_args(sql, paren_pos)

        if len(args) == 2:
            replacement = f'CONV({args[0]}, {args[1]}, 10)'
            conversions.append('string: STRTOL -> CONV')
        else:
            result.append(sql[m.start():end_pos])
            pos = end_pos
            continue

        result.append(replacement)
        pos = end_pos

    result.append(sql[pos:])
    return ''.join(result), conversions


def convert_single_arg_trunc(sql: str) -> Tuple[str, List[str]]:
    """Convert single-arg TRUNC(expr) with date/numeric disambiguation.

    Date indicators: CURRENT_DATE, CURRENT_TIMESTAMP, _date, _ts, _timestamp, GETDATE, SYSDATE
      -> CAST(expr AS DATE)
    Otherwise (likely numeric):
      -> TRUNCATE(expr, 0) with advisory comment
    """
    conversions: List[str] = []
    # Match TRUNC( but not DATE_TRUNC(
    pattern = re.compile(r'(?<!\w)TRUNC\s*\(', re.IGNORECASE)
    date_indicators = re.compile(
        r'CURRENT_DATE|CURRENT_TIMESTAMP|_date|_ts\b|_timestamp|GETDATE|SYSDATE',
        re.IGNORECASE,
    )
    result = []
    pos = 0

    for m in pattern.finditer(sql):
        if m.start() < pos:
            continue
        paren_pos = m.end() - 1
        args, end_pos = _split_balanced_args(sql, paren_pos)

        if len(args) != 1:
            # Multi-arg TRUNC — skip (handled by 2-arg TRUNC regex or TRUNCATE regex)
            continue

        result.append(sql[pos:m.start()])
        arg = args[0].strip()

        if date_indicators.search(arg):
            replacement = f'CAST({arg} AS DATE)'
            conversions.append(f'date: TRUNC({arg[:30]}) -> CAST(... AS DATE)')
        else:
            replacement = f'TRUNCATE({arg}, 0) /* TRUNC: assumed numeric; verify if date truncation intended */'
            conversions.append(f'math: TRUNC({arg[:30]}) -> TRUNCATE(..., 0)')

        result.append(replacement)
        pos = end_pos

    result.append(sql[pos:])
    return ''.join(result), conversions


def convert_similar_to(sql: str) -> Tuple[str, List[str]]:
    """HIGH-01: Convert SIMILAR TO with proper wildcard conversion and anchoring.

    SIMILAR TO matches whole string (like ^ and $ in regex).
    RLIKE matches substrings. So we add ^ and $ anchors.
    Also convert SQL wildcards: % -> .*, _ -> .
    """
    conversions = []
    pattern = re.compile(
        r"(\bNOT\s+)?SIMILAR\s+TO\s+'([^']*)'",
        re.IGNORECASE,
    )

    def _replacer(m):
        negation = m.group(1) or ''
        sql_pattern = m.group(2)
        # Convert SQL wildcards to regex (not inside character classes)
        regex_pattern = ''
        in_bracket = False
        for ch in sql_pattern:
            if ch == '[':
                in_bracket = True
                regex_pattern += ch
            elif ch == ']':
                in_bracket = False
                regex_pattern += ch
            elif ch == '%' and not in_bracket:
                regex_pattern += '.*'
            elif ch == '_' and not in_bracket:
                regex_pattern += '.'
            else:
                regex_pattern += ch
        # Add anchors for full-string matching
        if not regex_pattern.startswith('^'):
            regex_pattern = '^' + regex_pattern
        if not regex_pattern.endswith('$'):
            regex_pattern = regex_pattern + '$'
        neg = 'NOT ' if negation.strip() else ''
        conversions.append(f"string: {neg}SIMILAR TO -> {neg}RLIKE (with anchors)")
        return f"{neg}RLIKE '{regex_pattern}'"

    sql = pattern.sub(_replacer, sql)
    return sql, conversions


def convert_regexp_substr(sql: str) -> Tuple[str, List[str]]:
    """HIGH-02: Convert REGEXP_SUBSTR with proper arg trimming.

    Redshift: REGEXP_SUBSTR(str, pattern, position, occurrence, parameters)
    Databricks: REGEXP_EXTRACT(str, pattern, group_idx)
    """
    conversions = []
    pattern = re.compile(r'\bREGEXP_SUBSTR\s*\(', re.IGNORECASE)

    result = []
    pos = 0

    for match in pattern.finditer(sql):
        if match.start() < pos:
            continue
        if _is_inside_string_literal(sql, match.start()):
            continue
        paren_pos = match.end() - 1
        args, end_pos = _split_balanced_args(sql, paren_pos)
        if len(args) < 2:
            continue

        str_expr = args[0].strip()
        pat_expr = args[1].strip()
        group_idx = '0'
        flags_prefix = ''

        # Check for flags in args 3+
        for extra_arg in args[2:]:
            stripped = extra_arg.strip().strip("'\"")
            if 'e' in stripped.lower():
                group_idx = '1'  # Extract capture group
            if 'i' in stripped.lower():
                flags_prefix = '(?i)'

        if flags_prefix and pat_expr.startswith("'") and pat_expr.endswith("'"):
            pat_expr = f"'{flags_prefix}{pat_expr[1:-1]}'"

        result.append(sql[pos:match.start()])
        result.append(f'REGEXP_EXTRACT({str_expr}, {pat_expr}, {group_idx})')
        conversions.append('string: REGEXP_SUBSTR -> REGEXP_EXTRACT (args trimmed)')
        pos = end_pos

    result.append(sql[pos:])
    return ''.join(result), conversions


def convert_regexp_count(sql: str) -> Tuple[str, List[str]]:
    """HIGH-03: Convert REGEXP_COUNT with proper arg trimming.

    Redshift: REGEXP_COUNT(str, pattern, position, parameters)
    Databricks: (SIZE(SPLIT(str, pattern)) - 1)
    """
    conversions = []
    pattern = re.compile(r'\bREGEXP_COUNT\s*\(', re.IGNORECASE)

    result = []
    pos = 0

    for match in pattern.finditer(sql):
        if match.start() < pos:
            continue
        if _is_inside_string_literal(sql, match.start()):
            continue
        paren_pos = match.end() - 1
        args, end_pos = _split_balanced_args(sql, paren_pos)
        if len(args) < 2:
            continue

        str_expr = args[0].strip()
        pat_expr = args[1].strip()
        flags_prefix = ''

        # Check for 'i' flag in args 3+
        for extra_arg in args[2:]:
            stripped = extra_arg.strip().strip("'\"")
            if 'i' in stripped.lower():
                flags_prefix = '(?i)'

        if flags_prefix and pat_expr.startswith("'") and pat_expr.endswith("'"):
            pat_expr = f"'{flags_prefix}{pat_expr[1:-1]}'"

        result.append(sql[pos:match.start()])
        result.append(f'(SIZE(SPLIT({str_expr}, {pat_expr})) - 1)')
        conversions.append('string: REGEXP_COUNT -> SIZE(SPLIT) - 1 (args trimmed)')
        pos = end_pos

    result.append(sql[pos:])
    return ''.join(result), conversions


def convert_date_format_tokens(fmt_string: str) -> Tuple[str, bool]:
    """Convert Redshift/PostgreSQL date format tokens to Databricks/Java DateTimeFormatter.

    Returns (converted_format, was_changed).
    Uses single-pass left-to-right tokenization to avoid cascade issues.
    This is CRITICAL — format string differences cause silent wrong dates.
    """
    # Redshift token -> Databricks/Java token (case-insensitive matching)
    TOKEN_MAP = {
        'YYYYMMDDHH24MISS': 'yyyyMMddHHmmss',  # common combined pattern
        'MONTH': 'MMMM',     # full month name
        'YYYY': 'yyyy',
        'MON': 'MMM',        # abbreviated month name
        'HH24': 'HH',        # 24-hour (Java HH = 0-23)
        'HH12': 'hh',        # 12-hour (Java hh = 1-12)
        'DDD': 'DDD',        # day of year (same)
        'DAY': 'EEEE',       # full day name
        'DY': 'E',           # abbreviated day name (e.g., Mon, Tue) [FIX 6]
        'DD': 'dd',           # day of month
        'MM': 'MM',           # month number (Redshift MM -> Java MM)
        'YY': 'yy',          # 2-digit year
        'HH': 'hh',          # bare HH -> 12-hour
        'MI': 'mm',           # minutes (CRITICAL: Redshift MI = Java mm)
        'SS': 'ss',           # seconds
        'US': 'SSSSSS',      # microseconds (before MS)
        'MS': 'SSS',          # milliseconds
        'FF': 'SSSSSS',      # fractional seconds [FIX 6]
        'AM': 'a',
        'PM': 'a',
        'WW': 'ww',           # week of year (WARNING: RS WW is non-ISO, Java ww is ISO)
        'IW': 'ww',          # ISO week number [FIX 6]
        'TZ': 'z',           # time zone abbreviation [FIX 6]
        'OF': 'XXX',         # UTC offset [FIX 6]
        'FM': '',             # fill mode - suppress padding [FIX 6]
        'FX': '',             # fixed format - drop [FIX 6]
        'Q': 'Q',            # quarter [FIX 6]
        'D': 'u',            # day of week number [FIX 6]
        'CC': 'G',           # century/era [FIX 6]
    }
    # Sort tokens by length descending for greedy matching
    tokens_sorted = sorted(TOKEN_MAP.keys(), key=len, reverse=True)

    result = []
    i = 0
    while i < len(fmt_string):
        matched = False
        for token in tokens_sorted:
            end = i + len(token)
            if end <= len(fmt_string) and fmt_string[i:end].upper() == token:
                result.append(TOKEN_MAP[token])
                i = end
                matched = True
                break
        if not matched:
            result.append(fmt_string[i])
            i += 1

    new_fmt = ''.join(result)
    return new_fmt, new_fmt != fmt_string


# System table mapping: Redshift -> Databricks
SYSTEM_TABLE_MAP: Dict[str, str] = {
    'svv_tables': 'system.information_schema.tables',
    'svv_columns': 'system.information_schema.columns',
    'pg_table_def': 'system.information_schema.columns',
    'svv_table_info': 'system.information_schema.tables',
    'stl_query': 'system.query.history',
    'stl_querytext': 'system.query.history',
    'stl_connection_log': 'system.access.audit',
    'stl_alert_event_log': 'system.access.audit',
    'svv_external_tables': 'system.information_schema.tables',
    'stv_recents': 'system.query.history',
    'stl_wlm_query': 'system.compute.warehouse_events',
    'stv_wlm_service_class_config': 'system.compute.warehouse_events',
    'stv_wlm_classification_config': 'system.compute.warehouse_events',
    'stl_load_errors': 'system.query.history',
    'stv_sessions': 'system.query.history',
    'svv_diskusage': 'system.information_schema.tables',
    'svv_vacuum_progress': 'system.information_schema.tables',
    'pg_catalog.pg_tables': 'system.information_schema.tables',
    'pg_catalog.pg_columns': 'system.information_schema.columns',
    'information_schema.tables': 'system.information_schema.tables',
    'information_schema.columns': 'system.information_schema.columns',
}


def apply_system_table_mappings(sql: str) -> Tuple[str, List[str]]:
    """Replace Redshift system table references with Databricks equivalents."""
    conversions = []
    # Sort by key length descending to match longer patterns first (e.g., pg_catalog.pg_tables before pg_tables)
    sorted_items = sorted(SYSTEM_TABLE_MAP.items(), key=lambda x: len(x[0]), reverse=True)
    for rs_table, db_table in sorted_items:
        # Avoid matching already-converted references (starting with 'system.')
        pattern = re.compile(r'(?<!system\.)(?<!system\.information_schema\.)\b' + re.escape(rs_table) + r'\b', re.IGNORECASE)
        if pattern.search(sql):
            sql = pattern.sub(db_table, sql)
            conversions.append(f'system_table: {rs_table} -> {db_table}')
    return sql, conversions


def apply_date_format_conversions(sql: str) -> Tuple[str, List[str]]:
    """Convert date format strings inside DATE_FORMAT/TO_DATE/TO_TIMESTAMP/TO_CHAR calls.

    Uses paren-matching to find the complete function call (including nested calls),
    then converts only the last quoted string argument (the format string).
    This avoids the dangerous approach of matching arbitrary quoted strings in SQL.
    """
    conversions = []

    # Find date function calls
    func_pattern = re.compile(
        r'\b(DATE_FORMAT|TO_DATE|TO_TIMESTAMP|TO_CHAR)\s*\(',
        re.IGNORECASE,
    )

    result = []
    pos = 0

    for match in func_pattern.finditer(sql):
        func_start = match.start()
        if func_start < pos:
            # Already processed (inside a previous match)
            continue

        paren_start = match.end() - 1  # position of '('

        # Find matching closing paren (handles nesting)
        depth = 1
        i = paren_start + 1
        while i < len(sql) and depth > 0:
            if sql[i] == '(':
                depth += 1
            elif sql[i] == ')':
                depth -= 1
            elif sql[i] == "'":
                # Skip past quoted string
                j = i + 1
                while j < len(sql) and sql[j] != "'":
                    j += 1
                i = j  # will be incremented below
            i += 1

        if depth != 0:
            continue  # unmatched parens, skip

        paren_end = i - 1  # position of closing ')'
        func_body = sql[paren_start + 1:paren_end]

        # Find the last quoted string in the function body (the format argument)
        last_quote_match = None
        for qm in re.finditer(r"'([^']*)'", func_body):
            last_quote_match = qm

        # HIGH-04/05: Only convert if format contains UNAMBIGUOUS Redshift tokens.
        # Spark tokens (yyyy, dd, HH, mm, ss, SSS) must NOT trigger conversion.
        # Redshift-only tokens: HH24, HH12, MI (minutes), MON, MONTH, DAY, YYYY, DD (uppercase)
        # Key insight: Spark 'HH' (24h) and 'SSS' (ms) are valid — don't re-convert them.
        _rs_only_tokens = re.compile(
            r'HH24|HH12|(?<![smS])MI(?!N)|MONTH|MON(?!TH)|DAY(?!S)|FM|FX|TZ|OF|CC|IW|DDD',
            re.IGNORECASE,
        )
        # Only flag as Redshift if YYYY or DD appears (all-caps, not Spark lowercase)
        # but NOT if the format is purely Spark tokens (SSS, HH:mm:ss, etc.)
        _rs_uppercase_tokens = re.compile(r'YYYY|(?<![yd])DD(?!D)')  # strict: only full YYYY or DD
        if last_quote_match and len(last_quote_match.group(1)) >= 2:
            fmt = last_quote_match.group(1)
            if not (_rs_only_tokens.search(fmt) or _rs_uppercase_tokens.search(fmt)):
                continue  # No Redshift-specific tokens, skip conversion
            new_fmt, changed = convert_date_format_tokens(fmt)
            if changed:
                # Calculate absolute positions of the format string in original SQL
                fmt_abs_start = paren_start + 1 + last_quote_match.start()
                fmt_abs_end = paren_start + 1 + last_quote_match.end()
                result.append(sql[pos:fmt_abs_start])
                result.append(f"'{new_fmt}'")
                pos = fmt_abs_end
                conversions.append(f"format_string: '{fmt}' -> '{new_fmt}'")

    result.append(sql[pos:])
    return ''.join(result), conversions


def convert_json_multi_key(sql: str) -> Tuple[str, List[str]]:
    """Convert JSON_EXTRACT_PATH_TEXT with multiple keys to GET_JSON_OBJECT with JSONPath.

    JSON_EXTRACT_PATH_TEXT(json, 'k1', 'k2', 'k3') -> GET_JSON_OBJECT(json, '$.k1.k2.k3')
    """
    conversions = []
    pattern = re.compile(
        r"\bJSON_EXTRACT_PATH_TEXT\s*\(\s*([^,]+?)\s*,\s*((?:'[^']+'\s*,\s*)*'[^']+')\s*\)",
        re.IGNORECASE,
    )
    def _replace_json(m):
        expr = m.group(1).strip()
        keys_raw = m.group(2)
        keys = [k.strip().strip("'") for k in keys_raw.split(',')]
        json_path = '$.' + '.'.join(keys)
        conversions.append(f"json: JSON_EXTRACT_PATH_TEXT multi-key -> GET_JSON_OBJECT($.{'.'.join(keys)})")
        return f"GET_JSON_OBJECT({expr}, '{json_path}')"
    sql = pattern.sub(_replace_json, sql)
    return sql, conversions


def apply_date_trunc_uppercase(sql: str) -> Tuple[str, List[str]]:
    """Convert DATE_TRUNC unit to uppercase — Databricks requires uppercase in older runtimes.

    DATE_TRUNC('month', col) -> DATE_TRUNC('MONTH', col)
    """
    conversions = []
    pattern = re.compile(
        r"\bDATE_TRUNC\s*\(\s*'([^']+)'",
        re.IGNORECASE,
    )
    def _upper_unit(m):
        unit = m.group(1)
        if unit != unit.upper():
            conversions.append(f"date: DATE_TRUNC unit '{unit}' -> '{unit.upper()}'")
        return f"DATE_TRUNC('{unit.upper()}'"
    sql = pattern.sub(_upper_unit, sql)
    return sql, conversions


def convert_timezone(sql: str) -> Tuple[str, List[str]]:
    """Convert CONVERT_TIMEZONE to Databricks FROM_UTC_TIMESTAMP / TO_UTC_TIMESTAMP.

    Handles nested parentheses in the timestamp argument (e.g., CAST(...)).

    Redshift forms:
      2-arg: CONVERT_TIMEZONE('target_tz', ts) — assumes source UTC
        -> FROM_UTC_TIMESTAMP(ts, 'target_tz')
      3-arg: CONVERT_TIMEZONE('src_tz', 'tgt_tz', ts)
        -> FROM_UTC_TIMESTAMP(TO_UTC_TIMESTAMP(ts, 'src_tz'), 'tgt_tz')
    """
    conversions: List[str] = []
    pattern = re.compile(r'\bCONVERT_TIMEZONE\s*\(', re.IGNORECASE)

    result = []
    pos = 0
    for m in pattern.finditer(sql):
        result.append(sql[pos:m.start()])
        # Find the matching closing paren using balanced-paren walk
        start = m.end()  # position right after '('
        depth = 1
        i = start
        while i < len(sql) and depth > 0:
            if sql[i] == '(':
                depth += 1
            elif sql[i] == ')':
                depth -= 1
            i += 1
        # i is now one past the closing ')'
        inner = sql[start:i - 1].strip()

        # Split args by top-level commas (not inside parens)
        args: List[str] = []
        arg_start = 0
        depth = 0
        for j, ch in enumerate(inner):
            if ch == '(':
                depth += 1
            elif ch == ')':
                depth -= 1
            elif ch == ',' and depth == 0:
                args.append(inner[arg_start:j].strip())
                arg_start = j + 1
        args.append(inner[arg_start:].strip())

        if len(args) == 3:
            src_tz = args[0].strip("'\"")
            tgt_tz = args[1].strip("'\"")
            ts_expr = args[2]
            if src_tz.upper() == 'UTC':
                replacement = f"FROM_UTC_TIMESTAMP({ts_expr}, '{tgt_tz}')"
            elif tgt_tz.upper() == 'UTC':
                replacement = f"TO_UTC_TIMESTAMP({ts_expr}, '{src_tz}')"
            else:
                replacement = f"FROM_UTC_TIMESTAMP(TO_UTC_TIMESTAMP({ts_expr}, '{src_tz}'), '{tgt_tz}')"
            conversions.append('CONVERT_TIMEZONE(3-arg) -> FROM_UTC_TIMESTAMP/TO_UTC_TIMESTAMP')
        elif len(args) == 2:
            tgt_tz = args[0].strip("'\"")
            ts_expr = args[1]
            replacement = f"FROM_UTC_TIMESTAMP({ts_expr}, '{tgt_tz}')"
            conversions.append('CONVERT_TIMEZONE(2-arg) -> FROM_UTC_TIMESTAMP')
        else:
            replacement = m.group(0) + inner + ')'  # leave as-is
        result.append(replacement)
        pos = i

    result.append(sql[pos:])
    return ''.join(result), conversions


def convert_super_dot_notation(sql: str) -> Tuple[str, List[str]]:
    """Convert Redshift SUPER type dot-notation access to GET_JSON_OBJECT.

    Redshift SUPER columns use dot/bracket notation for nested JSON access:
      alias.col.key         -> GET_JSON_OBJECT(alias.col, '$.key')
      alias.col.key[0]      -> GET_JSON_OBJECT(alias.col, '$.key[0]')
      alias.col.key[0].sub  -> GET_JSON_OBJECT(alias.col, '$.key[0].sub')
      alias.col.a.b.c       -> GET_JSON_OBJECT(alias.col, '$.a.b.c')

    First two dot-segments = alias.column (SQL reference).
    Remaining segments = JSON path.

    Must run BEFORE cast conversion so ::TYPE is still present for detection.
    """
    conversions: List[str] = []

    # Protect string literals from conversion (avoid modifying '$.key.path' strings)
    string_store: List[str] = []

    def _save_str(m):
        string_store.append(m.group(0))
        return f'__STRPH_{len(string_store) - 1}__'

    sql = re.sub(r"'[^']*'", _save_str, sql)

    # Pass 1: Paths with bracket [n] access — definitive SUPER
    bracket_re = re.compile(
        r'\b(\w+\.\w+)'                                  # base: alias.column
        r'((?:\.\w+)*\[\d+\](?:\.\w+|\[\d+\])*)',        # path with at least one [n]
    )

    def _repl_bracket(m):
        base, path = m.group(1), m.group(2)
        conversions.append(f'SUPER dot-notation: {base}{path} -> GET_JSON_OBJECT')
        return f"GET_JSON_OBJECT({base}, '${path}')"

    sql = bracket_re.sub(_repl_bracket, sql)

    # Pass 2: 4+ segment paths without brackets — definitive SUPER
    deep_re = re.compile(
        r'\b(\w+\.\w+)(\.\w+\.\w+(?:\.\w+)*)\b',
    )

    def _repl_deep(m):
        base, path = m.group(1), m.group(2)
        conversions.append(f'SUPER dot-notation: {base}{path} -> GET_JSON_OBJECT')
        return f"GET_JSON_OBJECT({base}, '${path}')"

    sql = deep_re.sub(_repl_deep, sql)

    # Pass 3: 3-segment paths — SUPER unless preceded by table keywords
    # (FROM, JOIN, INTO, UPDATE, TABLE, etc. indicate a schema.table.column reference)
    three_re = re.compile(r'\b(\w+\.\w+)(\.\w+)\b')
    table_kw_re = re.compile(
        r'\b(?:FROM|JOIN|INTO|UPDATE|TABLE|LIKE|INDEX\s+ON|REFERENCES)\s+$',
        re.IGNORECASE,
    )

    result_parts: List[str] = []
    last_end = 0
    for m in three_re.finditer(sql):
        preceding = sql[:m.start()]
        if table_kw_re.search(preceding):
            continue
        base, path = m.group(1), m.group(2)
        result_parts.append(sql[last_end:m.start()])
        result_parts.append(f"GET_JSON_OBJECT({base}, '${path}')")
        last_end = m.end()
        conversions.append(f'SUPER dot-notation: {base}{path} -> GET_JSON_OBJECT')

    result_parts.append(sql[last_end:])
    if len(result_parts) > 1:
        sql = ''.join(result_parts)

    # Restore string literals
    for i, s in enumerate(string_store):
        sql = sql.replace(f'__STRPH_{i}__', s)

    return sql, conversions


def full_sql_convert(sql: str) -> Tuple[str, List[str]]:
    """Apply all SQL conversions: functions, DECODE, construct removals, format strings, system tables.

    Returns (converted_sql, all_conversions_applied).
    """
    all_conversions = []

    # 1. Convert multi-key JSON_EXTRACT_PATH_TEXT first (before single-key regex)
    sql, json_conversions = convert_json_multi_key(sql)
    all_conversions.extend(json_conversions)

    # 1b. Convert Redshift SUPER dot-notation BEFORE cast conversion
    #     (so alias.col.key::TYPE -> GET_JSON_OBJECT(alias.col, '$.key')::TYPE
    #      then cast handler converts ::TYPE)
    sql, super_convs = convert_super_dot_notation(sql)
    all_conversions.extend(super_convs)

    # 2. Convert DECODE (before other function translations)
    if re.search(r'\bDECODE\s*\(', sql, re.IGNORECASE):
        sql = convert_decode(sql)
        all_conversions.append('conditional: DECODE -> CASE WHEN')

    # 3. Convert parenthesized casts (expr)::TYPE before simple word::TYPE
    sql, paren_cast_convs = convert_paren_casts(sql)
    all_conversions.extend(paren_cast_convs)

    # 3b. Convert CONVERT_TIMEZONE (needs balanced-paren parsing, not regex)
    sql, tz_convs = convert_timezone(sql)
    all_conversions.extend(tz_convs)

    # 3c. Balanced-paren converters for functions that break with regex (CRIT-01..05)
    sql, dateadd_convs = convert_dateadd(sql)
    all_conversions.extend(dateadd_convs)

    sql, datediff_convs = convert_datediff(sql)
    all_conversions.extend(datediff_convs)

    sql, btrim_convs = convert_btrim(sql)
    all_conversions.extend(btrim_convs)

    sql, strtol_convs = convert_strtol(sql)
    all_conversions.extend(strtol_convs)

    sql, trunc_convs = convert_single_arg_trunc(sql)
    all_conversions.extend(trunc_convs)

    # 3d. HIGH-01/02/03: SIMILAR TO, REGEXP_SUBSTR, REGEXP_COUNT converters
    sql, similar_convs = convert_similar_to(sql)
    all_conversions.extend(similar_convs)
    sql, regexp_sub_convs = convert_regexp_substr(sql)
    all_conversions.extend(regexp_sub_convs)
    sql, regexp_cnt_convs = convert_regexp_count(sql)
    all_conversions.extend(regexp_cnt_convs)

    # 4. Apply function translations
    sql, fn_conversions = apply_function_translations(sql)
    all_conversions.extend(fn_conversions)

    # 4b. Catch remaining :: casts (spaces around ::, brackets, etc.)
    sql, remaining_cast_convs = convert_remaining_casts(sql)
    all_conversions.extend(remaining_cast_convs)

    # 5. Remove Redshift constructs
    sql, removals = apply_construct_removals(sql)
    all_conversions.extend(removals)

    # 6. Convert date format strings (after TO_CHAR -> DATE_FORMAT translation)
    sql, fmt_conversions = apply_date_format_conversions(sql)
    all_conversions.extend(fmt_conversions)

    # 7. Uppercase DATE_TRUNC units
    sql, trunc_conversions = apply_date_trunc_uppercase(sql)
    all_conversions.extend(trunc_conversions)

    # 8. Replace system table references
    sql, sys_conversions = apply_system_table_mappings(sql)
    all_conversions.extend(sys_conversions)

    # 9. Convert SELECT TOP n -> SELECT ... LIMIT n (Redshift extension)
    top_pattern = re.compile(r'\bSELECT\s+TOP\s+(\d+)\b', re.IGNORECASE)
    if top_pattern.search(sql):
        # Find the end of the statement (semicolon or end of string) to append LIMIT
        def _convert_top(m):
            return f'SELECT'
        limit_val = top_pattern.search(sql).group(1)
        sql = top_pattern.sub('SELECT', sql)
        # Append LIMIT before the final semicolon (or at end)
        if sql.rstrip().endswith(';'):
            sql = sql.rstrip().rstrip(';').rstrip() + f' LIMIT {limit_val};'
        else:
            sql = sql.rstrip() + f' LIMIT {limit_val}'
        all_conversions.append(f'SELECT TOP {limit_val} -> SELECT ... LIMIT {limit_val}')

    # 10. Convert MINUS -> EXCEPT (Redshift alias for set difference)
    if re.search(r'\bMINUS\b', sql, re.IGNORECASE):
        sql = re.sub(r'\bMINUS\b', 'EXCEPT', sql, flags=re.IGNORECASE)
        all_conversions.append('set operation: MINUS -> EXCEPT')

    # 11. Flag GRANT/REVOKE statements (need Unity Catalog migration)
    if re.search(r'^\s*(?:GRANT|REVOKE)\b', sql, re.IGNORECASE | re.MULTILINE):
        sql = re.sub(
            r'(^\s*(?:GRANT|REVOKE)\b)',
            r'-- TODO: Migrate to Unity Catalog privileges\n\1',
            sql,
            flags=re.IGNORECASE | re.MULTILINE,
            count=1,
        )
        all_conversions.append('GRANT/REVOKE: TODO migrate to Unity Catalog privileges')

    # 11b. Convert SELECT INTO TEMP TABLE -> CREATE TEMPORARY TABLE AS SELECT
    select_into_temp = re.compile(
        r'\bSELECT\b(.+?)\bINTO\s+(?:TEMP(?:ORARY)?\s+)?(?:TABLE\s+)?#?(\w+)\s*\bFROM\b',
        re.IGNORECASE | re.DOTALL,
    )
    if select_into_temp.search(sql):
        sql = select_into_temp.sub(
            r'CREATE TEMPORARY TABLE \2 AS SELECT\1FROM',
            sql,
        )
        all_conversions.append('SELECT INTO TEMP TABLE -> CREATE TEMPORARY TABLE AS SELECT')

    # 11c. Convert #table_name references (Redshift temp table prefix) -> table_name
    if re.search(r'(?<!\w)#(\w+)', sql):
        sql = re.sub(r'(?<!\w)#(\w+)', r'\1 /* temp table - was #\1 */', sql)
        all_conversions.append('#table_name -> table_name (Redshift temp table prefix removed)')

    # 11d. CREATE TABLE ... (LIKE source) -> advisory (not directly supported in Databricks)
    like_table_pattern = re.compile(
        r'(CREATE\s+TABLE\s+[\w.]+\s*\(\s*LIKE\s+)([\w.]+)\s*\)',
        re.IGNORECASE,
    )
    if like_table_pattern.search(sql):
        sql = like_table_pattern.sub(
            r"-- NOTE: CREATE TABLE (LIKE) not supported in Databricks. Use CTAS:\n-- CREATE TABLE ... AS SELECT * FROM \2 WHERE 1=0\n\1\2)",
            sql,
        )
        all_conversions.append('CREATE TABLE (LIKE) -> advisory (use CTAS WHERE 1=0)')

    # 12. Convert CAST(x AS VARCHAR/VARCHAR(n)) -> CAST(x AS STRING) (HIGH-12: nested paren support)
    cast_varchar_pattern = re.compile(
        r'(\bCAST\s*\((?:[^()]|\([^)]*\))*\s+AS\s+)VARCHAR(?:\s*\(\s*\d+\s*\))?(\s*\))',
        re.IGNORECASE,
    )
    if cast_varchar_pattern.search(sql):
        sql = cast_varchar_pattern.sub(r'\1STRING\2', sql)
        all_conversions.append('casting: CAST(... AS VARCHAR) -> CAST(... AS STRING)')

    # 12b. Convert CAST(x AS CHAR(n)) -> CAST(x AS STRING) (HIGH-12: nested paren support)
    cast_char_pattern = re.compile(
        r'(\bCAST\s*\((?:[^()]|\([^)]*\))*\s+AS\s+)CHAR(?:\s*\(\s*\d+\s*\))?(\s*\))',
        re.IGNORECASE,
    )
    if cast_char_pattern.search(sql):
        sql = cast_char_pattern.sub(r'\1STRING\2', sql)
        all_conversions.append('casting: CAST(... AS CHAR) -> CAST(... AS STRING)')

    # 12c. Convert CAST(x AS NUMERIC(...)) -> CAST(x AS DECIMAL(...)) (HIGH-12: nested paren support)
    cast_numeric_pattern = re.compile(
        r'(\bCAST\s*\((?:[^()]|\([^)]*\))*\s+AS\s+)NUMERIC(\s*\([^)]+\))?(\s*\))',
        re.IGNORECASE,
    )
    if cast_numeric_pattern.search(sql):
        def _fix_numeric_cast(m):
            prefix = m.group(1)
            precision = m.group(2) if m.group(2) else '(18,0)'
            suffix = m.group(3)
            return f'{prefix}DECIMAL{precision}{suffix}'
        sql = cast_numeric_pattern.sub(_fix_numeric_cast, sql)
        all_conversions.append('casting: CAST(... AS NUMERIC) -> CAST(... AS DECIMAL)')

    # 12d. Convert CAST(x AS DATETIME) -> CAST(x AS TIMESTAMP) (HIGH-07 complement)
    cast_datetime_pattern = re.compile(
        r'(\bCAST\s*\((?:[^()]|\([^)]*\))*\s+AS\s+)DATETIME(\s*\))',
        re.IGNORECASE,
    )
    if cast_datetime_pattern.search(sql):
        sql = cast_datetime_pattern.sub(r'\1TIMESTAMP\2', sql)
        all_conversions.append('casting: CAST(... AS DATETIME) -> CAST(... AS TIMESTAMP)')

    # 13. Convert SET search_path -> advisory
    if re.search(r'\bSET\s+search_path\b', sql, re.IGNORECASE):
        sql = re.sub(
            r"SET\s+search_path\s+(?:TO|=)\s+([^;]+)",
            r"-- SET search_path removed. Use: USE SCHEMA <schema_name>;\n-- Original: SET search_path TO \1",
            sql, flags=re.IGNORECASE,
        )
        all_conversions.append('SET search_path -> removed (use USE SCHEMA)')

    # 13b. Convert SET enable_case_sensitive_identifier -> remove
    if re.search(r'\bSET\s+enable_case_sensitive_identifier\b', sql, re.IGNORECASE):
        sql = re.sub(
            r"SET\s+enable_case_sensitive_identifier\s+(?:TO|=)\s+\w+",
            "-- SET enable_case_sensitive_identifier removed (Databricks is always case-insensitive)",
            sql, flags=re.IGNORECASE,
        )
        all_conversions.append('SET enable_case_sensitive_identifier -> removed')

    # 14. Flag QUALIFY clause (Redshift/Snowflake — Databricks DBR 12.1+ only)
    if re.search(r'\bQUALIFY\b', sql, re.IGNORECASE):
        sql = re.sub(
            r'\bQUALIFY\b',
            '/* QUALIFY: requires Databricks Runtime 12.1+. For older runtimes, wrap in CTE with WHERE. */ QUALIFY',
            sql,
            flags=re.IGNORECASE,
            count=1,
        )
        all_conversions.append('QUALIFY clause detected (requires DBR 12.1+; wrap in CTE for older runtimes)')

    return sql, all_conversions


def apply_catalog_prefix(sql: str, catalog: str) -> Tuple[str, List[str]]:
    """Prefix 2-part schema.table references with a Unity Catalog name.

    Transforms schema.table -> catalog.schema.table in these contexts:
      1. After SQL keywords: FROM, JOIN, INTO, TABLE, VIEW, UPDATE, OPTIMIZE
      2. Comma-separated table lists: FROM schema.t1, schema.t2, schema.t3
      3. Nested subqueries and multi-level CTEs (handled naturally since
         the regex scans the full SQL text line by line)

    Skips:
      - Already 3-part names (catalog.schema.table)
      - Content inside SQL comments (-- or {# ... #})
      - Content inside string literals ('...')
      - CTE alias references (bare word.column, not schema.table)

    Only called when a catalog name is provided by the user via --catalog.
    """
    if not catalog:
        return sql, []

    conversions = []

    # Phase 1: keyword-anchored — prefix schema.table after SQL keywords
    # Negative lookbehind (?<!\w\.) prevents matching inside 3-part names
    keywords = r'\b(?:FROM|JOIN|INTO|TABLE|VIEW|UPDATE|OPTIMIZE)\s+'

    # Phase 2: comma-continuation — prefix schema.table after comma
    # in a table list context (e.g., FROM schema.t1, schema.t2)
    comma_table = re.compile(
        r'(,\s*)(\w+\.\w+)(?!\.\w)(?!\s*\()',
        re.IGNORECASE,
    )

    def _is_schema_table(name: str) -> bool:
        """Heuristic: distinguish schema.table from alias.column.

        Schema names are typically >2 chars and not common SQL aliases.
        Short prefixes like t1, a, b, p, cd etc. are almost always aliases.
        """
        parts = name.split('.')
        schema_part = parts[0]
        # Common alias patterns: single char, single char + digit, 2 chars
        if len(schema_part) <= 2:
            return False
        # Common short alias names used in SQL
        if schema_part.lower() in ('src', 'tgt', 'tmp', 'sub', 'cte', 'old', 'new', 'ref', 'stg'):
            return False
        return True

    # Process line by line, skipping comment lines
    result_lines = []
    in_from_context = False  # tracks whether we're inside a FROM/JOIN clause

    for line in sql.split('\n'):
        stripped = line.strip()
        if stripped.startswith('--') or stripped.startswith('{#'):
            result_lines.append(line)
            continue

        new_line = line

        # Phase 1: keyword-anchored matches
        kw_pattern = re.compile(
            r'(?<!\w\.)(' + keywords + r')(\w+\.\w+)(?!\.\w)',
            re.IGNORECASE,
        )
        kw_matches = list(kw_pattern.finditer(new_line))
        if kw_matches:
            in_from_context = True
            for m in reversed(kw_matches):
                name = m.group(2)
                prefix_text = new_line[:m.start()]
                if prefix_text.count("'") % 2 == 1:
                    continue
                if not _is_schema_table(name):
                    continue
                qualified = f"{m.group(1)}{catalog}.{name}"
                new_line = new_line[:m.start()] + qualified + new_line[m.end():]

        # Phase 2: comma-separated table references in FROM/JOIN context
        # Only apply when we've seen a FROM/JOIN keyword recently
        if in_from_context:
            cm_matches = list(comma_table.finditer(new_line))
            if cm_matches:
                for m in reversed(cm_matches):
                    name = m.group(2)
                    prefix_text = new_line[:m.start()]
                    if prefix_text.count("'") % 2 == 1:
                        continue
                    if not _is_schema_table(name):
                        continue
                    qualified = f"{m.group(1)}{catalog}.{name}"
                    new_line = new_line[:m.start()] + qualified + new_line[m.end():]

        # Reset FROM context when we hit clause-ending keywords
        upper_stripped = stripped.upper()
        if any(kw in upper_stripped for kw in
               ('WHERE ', 'GROUP BY', 'ORDER BY', 'HAVING ', 'LIMIT ',
                'UNION ', 'INTERSECT ', 'EXCEPT ', 'SELECT ', ')')) and not kw_matches:
            in_from_context = False

        result_lines.append(new_line)

    result = '\n'.join(result_lines)
    if result != sql:
        conversions.append(f'Unity Catalog: prefixed schema.table references with catalog "{catalog}"')
    return result, conversions
