"""
Coverage Analysis — Measures how much of the input SQL was handled by converters.

WS1 (Standalone SQL): Statement-level coverage — classifies each SQL statement
and checks if a parser would claim it.

WS2 (dbt Project): File-level coverage — every input file should have a
corresponding output file at the same relative path.

Usage:
    python scripts/generate_coverage_report.py -i inputs/sql -o output
    python scripts/generate_coverage_report.py -i inputs/ -o output --type both

    # Or import:
    from generate_coverage_report import analyze_coverage, analyze_dbt_coverage
"""

import argparse
import glob
import re
import sys
from pathlib import Path
from typing import Any, Dict, List, Optional

SCRIPTS_DIR = Path(__file__).resolve().parent
PROJECT_ROOT = SCRIPTS_DIR.parent
sys.path.insert(0, str(SCRIPTS_DIR))

from utils import get_timestamp


def _sanitize_path(raw: str, allowed_base: Path) -> Path:
    """Resolve a user-supplied path, anchored to allowed_base, rejecting traversal."""
    if not raw:
        raise ValueError("Empty path")
    candidate = (allowed_base / raw).resolve()
    if not candidate.is_relative_to(allowed_base.resolve()):
        raise ValueError(
            f"Path traversal blocked: {raw!r} escapes {allowed_base}"
        )
    return candidate


# ---------------------------------------------------------------------------
# SQL statement splitter
# ---------------------------------------------------------------------------

def _split_sql_statements(sql: str) -> List[str]:
    """Split SQL by semicolons, respecting quoted strings and comments."""
    stmts: List[str] = []
    current: List[str] = []
    in_single = False
    in_double = False
    in_line_comment = False
    in_block_comment = False
    in_dollar = False
    dollar_tag = ''
    i = 0
    while i < len(sql):
        char = sql[i]
        next_char = sql[i + 1] if i + 1 < len(sql) else ''
        if in_line_comment:
            current.append(char)
            if char == '\n':
                in_line_comment = False
        elif in_block_comment:
            current.append(char)
            if char == '*' and next_char == '/':
                current.append('/')
                in_block_comment = False
                i += 1
        elif in_dollar:
            current.append(char)
            if char == '$':
                end = sql.find('$', i + 1)
                if end != -1:
                    tag = sql[i:end + 1]
                    if tag == dollar_tag:
                        current.extend(list(sql[i + 1:end + 1]))
                        in_dollar = False
                        i = end
        elif char == '-' and next_char == '-' and not in_single and not in_double:
            in_line_comment = True
            current.append(char)
        elif char == '/' and next_char == '*' and not in_single and not in_double:
            in_block_comment = True
            current.append(char)
        elif char == '$' and not in_single and not in_double:
            end = sql.find('$', i + 1)
            if end != -1 and end - i < 40:
                tag = sql[i:end + 1]
                if re.match(r'^\$\w*\$$', tag):
                    dollar_tag = tag
                    in_dollar = True
                    current.extend(list(sql[i:end + 1]))
                    i = end
                else:
                    current.append(char)
            else:
                current.append(char)
        elif char == "'" and not in_double:
            in_single = not in_single
            current.append(char)
        elif char == '"' and not in_single:
            in_double = not in_double
            current.append(char)
        elif char == ';' and not in_single and not in_double:
            stmts.append(''.join(current))
            current = []
        else:
            current.append(char)
        i += 1
    if current:
        remainder = ''.join(current).strip()
        if remainder:
            stmts.append(''.join(current))
    return stmts


# ---------------------------------------------------------------------------
# Coverage patterns — which parser would claim each statement type
# ---------------------------------------------------------------------------

_COVERAGE_PATTERNS = [
    # DDL
    ('DDL:CREATE_TABLE', re.compile(
        r'^\s*CREATE\s+(?:OR\s+REPLACE\s+)?(?:TEMP(?:ORARY)?\s+)?(?:EXTERNAL\s+)?TABLE\b',
        re.IGNORECASE)),
    ('DDL:ALTER_TABLE', re.compile(r'^\s*ALTER\s+TABLE\b', re.IGNORECASE)),
    ('DDL:DROP_TABLE', re.compile(r'^\s*DROP\s+TABLE\b', re.IGNORECASE)),
    ('DDL:TRUNCATE', re.compile(r'^\s*TRUNCATE\b', re.IGNORECASE)),
    ('DDL:CREATE_SCHEMA', re.compile(r'^\s*CREATE\s+(?:EXTERNAL\s+)?SCHEMA\b', re.IGNORECASE)),
    ('DDL:CREATE_FUNCTION', re.compile(r'^\s*CREATE\s+(?:OR\s+REPLACE\s+)?FUNCTION\b', re.IGNORECASE)),
    ('DDL:COMMENT_ON', re.compile(r'^\s*COMMENT\s+ON\b', re.IGNORECASE)),
    ('DDL:VACUUM_ANALYZE', re.compile(r'^\s*(?:VACUUM|ANALYZE)\b', re.IGNORECASE)),
    # Views
    ('VIEW:CREATE_VIEW', re.compile(
        r'^\s*CREATE\s+(?:OR\s+REPLACE\s+)?(?:MATERIALIZED\s+)?VIEW\b', re.IGNORECASE)),
    ('VIEW:DROP_VIEW', re.compile(r'^\s*DROP\s+(?:MATERIALIZED\s+)?VIEW\b', re.IGNORECASE)),
    ('VIEW:ALTER_VIEW', re.compile(r'^\s*ALTER\s+VIEW\b', re.IGNORECASE)),
    ('VIEW:REFRESH_MV', re.compile(r'^\s*REFRESH\s+MATERIALIZED\s+VIEW\b', re.IGNORECASE)),
    # Procedures
    ('PROC:CREATE_PROC', re.compile(
        r'^\s*CREATE\s+(?:OR\s+REPLACE\s+)?PROCEDURE\b', re.IGNORECASE)),
    ('PROC:DROP_PROC', re.compile(r'^\s*DROP\s+PROCEDURE\b', re.IGNORECASE)),
    # DML
    ('DML:INSERT', re.compile(r'^\s*INSERT\s+INTO\b', re.IGNORECASE)),
    ('DML:UPDATE', re.compile(r'^\s*UPDATE\b', re.IGNORECASE)),
    ('DML:DELETE', re.compile(r'^\s*DELETE\b', re.IGNORECASE)),
    ('DML:MERGE', re.compile(r'^\s*MERGE\b', re.IGNORECASE)),
    ('DML:COPY', re.compile(r'^\s*COPY\b', re.IGNORECASE)),
    ('DML:UNLOAD', re.compile(r'^\s*UNLOAD\b', re.IGNORECASE)),
    ('DML:LOCK', re.compile(r'^\s*LOCK\s+TABLE\b', re.IGNORECASE)),
    ('DML:TRANSACTION', re.compile(
        r'^\s*(?:BEGIN\s+TRANSACTION|BEGIN|END\s+TRANSACTION|COMMIT|ROLLBACK)\s*$',
        re.IGNORECASE)),
    ('DML:SAVEPOINT', re.compile(
        r'^\s*(?:SAVEPOINT|RELEASE\s+SAVEPOINT)\b', re.IGNORECASE)),
    ('DML:SET_TRANSACTION', re.compile(r'^\s*SET\s+TRANSACTION\b', re.IGNORECASE)),
    ('DML:CTE_DML', re.compile(
        r'^\s*WITH\b.*\b(?:INSERT\s+INTO|UPDATE\s|DELETE\s|MERGE\s)\b',
        re.IGNORECASE | re.DOTALL)),
    # Query
    ('QUERY:SELECT', re.compile(r'^\s*SELECT\b', re.IGNORECASE)),
    ('QUERY:CTE', re.compile(r'^\s*WITH\b', re.IGNORECASE)),
    ('QUERY:CTAS', re.compile(
        r'^\s*CREATE\s+(?:OR\s+REPLACE\s+)?(?:TEMP(?:ORARY)?\s+)?TABLE\s+\S+\s+(?:USING\s+\w+\s+)?AS\s',
        re.IGNORECASE)),
    # Other known constructs
    ('OTHER:GRANT', re.compile(r'^\s*GRANT\b', re.IGNORECASE)),
    ('OTHER:REVOKE', re.compile(r'^\s*REVOKE\b', re.IGNORECASE)),
    ('OTHER:SET', re.compile(r'^\s*SET\b', re.IGNORECASE)),
    ('OTHER:CALL', re.compile(r'^\s*CALL\b', re.IGNORECASE)),
    ('OTHER:EXECUTE', re.compile(r'^\s*EXECUTE\b', re.IGNORECASE)),
]


def _classify_statement(stmt: str) -> Optional[str]:
    """Return the parser category that would claim this statement, or None if uncovered."""
    stripped = stmt.strip()
    lines = stripped.split('\n')
    sql_start = ''
    for line in lines:
        s = line.strip()
        if s and not s.startswith('--') and not s.startswith('/*'):
            sql_start = '\n'.join(lines[lines.index(line):])
            break
    if not sql_start:
        return 'COMMENT_ONLY'

    for label, pattern in _COVERAGE_PATTERNS:
        if pattern.match(sql_start):
            return label
    return None


# ---------------------------------------------------------------------------
# WS1: SQL statement-level coverage analysis
# ---------------------------------------------------------------------------

def analyze_coverage(
    input_path: str, output_dir: Path
) -> Dict[str, Any]:
    """Analyze conversion coverage: which input files and SQL blocks were converted."""
    inp = Path(input_path)
    if inp.is_file():
        input_files = [inp] if inp.suffix.lower() == '.sql' else []
    elif inp.is_dir():
        input_files = sorted(inp.rglob('*.sql'))
    else:
        input_files = sorted(Path(p) for p in glob.glob(str(inp)))

    # Build set of source files that produced output
    source_patterns_re = [
        re.compile(r'converted from:\s*(\S+)', re.IGNORECASE),
        re.compile(r'^-- Source:\s*(\S+)', re.IGNORECASE),
    ]
    sources_with_output: set = set()
    for sql_file in sorted(output_dir.rglob('*.sql')):
        try:
            content = sql_file.read_text(encoding='utf-8')
        except Exception:
            continue
        for line in content.split('\n')[:10]:
            for pat in source_patterns_re:
                m = pat.search(line)
                if m:
                    sources_with_output.add(m.group(1))
                    break

    file_results = []
    total_stmts = 0
    total_covered = 0
    total_uncovered = 0
    files_with_output = 0

    for input_file in input_files:
        try:
            content = input_file.read_text(encoding='utf-8')
        except Exception:
            continue

        has_output = input_file.name in sources_with_output
        if has_output:
            files_with_output += 1

        stmts = _split_sql_statements(content)
        uncovered_blocks = []
        covered_count = 0
        stmt_count = 0

        line_offset = 1
        for stmt_text in stmts:
            stripped = stmt_text.strip()
            if not stripped:
                line_offset += stmt_text.count('\n')
                continue
            non_comment_lines = [
                l for l in stripped.split('\n')
                if l.strip() and not l.strip().startswith('--') and not l.strip().startswith('/*')
            ]
            if not non_comment_lines:
                line_offset += stmt_text.count('\n')
                continue

            stmt_count += 1
            category = _classify_statement(stripped)

            if category is None:
                preview = stripped[:120].replace('\n', ' ')
                if len(stripped) > 120:
                    preview += '...'
                uncovered_blocks.append({
                    'line': line_offset,
                    'preview': preview,
                    'category': None,
                })
                total_uncovered += 1
            else:
                covered_count += 1
                total_covered += 1

            line_offset += stmt_text.count('\n') + 1

        total_stmts += stmt_count

        file_results.append({
            'file': input_file.name,
            'total_statements': stmt_count,
            'covered': covered_count,
            'uncovered': len(uncovered_blocks),
            'uncovered_blocks': uncovered_blocks,
            'has_output': has_output,
        })

    coverage_pct = (total_covered / total_stmts * 100) if total_stmts > 0 else 100.0

    return {
        'files': file_results,
        'summary': {
            'total_files': len(input_files),
            'files_with_output': files_with_output,
            'files_without_output': len(input_files) - files_with_output,
            'total_statements': total_stmts,
            'covered_statements': total_covered,
            'uncovered_statements': total_uncovered,
            'coverage_pct': round(coverage_pct, 1),
        },
    }


def generate_coverage_report(coverage: Dict[str, Any], input_path: str, output_dir: Path) -> str:
    """Generate coverage_report.md content."""
    s = coverage['summary']
    timestamp = get_timestamp()

    lines = [
        "# Conversion Coverage Report",
        "",
        f"**Generated:** {timestamp}",
        f"**Input:** `{input_path}`",
        f"**Output:** `{output_dir}`",
        "",
        "---",
        "",
        "## Summary",
        "",
        "| Metric | Value |",
        "| --- | --- |",
        f"| Input files scanned | {s['total_files']} |",
        f"| Files with output | {s['files_with_output']} |",
        f"| Files without output | {s['files_without_output']} |",
        f"| Total SQL statements | {s['total_statements']} |",
        f"| Covered (matched by a parser) | {s['covered_statements']} |",
        f"| **Uncovered (no parser matched)** | **{s['uncovered_statements']}** |",
        f"| **Coverage** | **{s['coverage_pct']}%** |",
        "",
    ]

    # Files without any output
    no_output = [f for f in coverage['files'] if not f['has_output']]
    if no_output:
        lines.append("---")
        lines.append("")
        lines.append("## Files With No Output (CRITICAL)")
        lines.append("")
        lines.append("These input files produced **zero** output across all converters:")
        lines.append("")
        for f in no_output:
            lines.append(f"- `{f['file']}` ({f['total_statements']} statement(s))")
        lines.append("")

    # Files with uncovered blocks
    files_with_gaps = [f for f in coverage['files'] if f['uncovered_blocks']]
    if files_with_gaps:
        lines.append("---")
        lines.append("")
        lines.append("## Uncovered SQL Blocks")
        lines.append("")
        lines.append("These SQL statements were **not matched by any parser** and may have been silently skipped:")
        lines.append("")
        for f in files_with_gaps:
            lines.append(f"### `{f['file']}` \u2014 {f['uncovered']} uncovered / {f['total_statements']} total")
            lines.append("")
            for blk in f['uncovered_blocks']:
                lines.append(f"- **Line ~{blk['line']}**: `{blk['preview']}`")
            lines.append("")
    else:
        lines.append("---")
        lines.append("")
        lines.append("## Uncovered SQL Blocks")
        lines.append("")
        lines.append("None \u2014 all SQL statements in all input files were matched by a parser.")
        lines.append("")

    # Full file breakdown
    lines.append("---")
    lines.append("")
    lines.append("## File-by-File Breakdown")
    lines.append("")
    lines.append("| File | Statements | Covered | Uncovered | Has Output |")
    lines.append("| --- | --- | --- | --- | --- |")
    for f in coverage['files']:
        status = 'YES' if f['has_output'] else '**NO**'
        unc = str(f['uncovered']) if f['uncovered'] == 0 else f"**{f['uncovered']}**"
        lines.append(f"| `{f['file']}` | {f['total_statements']} | {f['covered']} | {unc} | {status} |")
    lines.append("")

    return '\n'.join(lines)


# ---------------------------------------------------------------------------
# WS2: dbt file-level coverage analysis
# ---------------------------------------------------------------------------

def analyze_dbt_coverage(
    input_path: str, output_dir: Path
) -> Dict[str, Any]:
    """Analyze WS2 dbt coverage: every input file should have a matching output."""
    inp = Path(input_path)
    out = output_dir / 'dbt_project'

    skip_names = {'.gitkeep', '.DS_Store'}
    input_files: Dict[str, Path] = {}
    if inp.is_dir():
        for f in sorted(inp.rglob('*')):
            if f.is_file() and f.name not in skip_names and '__pycache__' not in str(f):
                rel = str(f.relative_to(inp))
                input_files[rel] = f

    output_files: Dict[str, Path] = {}
    if out.is_dir():
        for f in sorted(out.rglob('*')):
            if f.is_file() and f.name not in skip_names and '__pycache__' not in str(f):
                rel = str(f.relative_to(out))
                output_files[rel] = f

    all_paths = sorted(set(input_files.keys()) | set(output_files.keys()))
    file_results = []
    matched = 0
    missing_output = 0
    extra_output = 0

    for rel_path in all_paths:
        in_exists = rel_path in input_files
        out_exists = rel_path in output_files

        if in_exists and out_exists:
            matched += 1
            file_results.append({
                'rel_path': rel_path,
                'input_exists': True,
                'output_exists': True,
                'status': 'MATCHED',
            })
        elif in_exists and not out_exists:
            missing_output += 1
            file_results.append({
                'rel_path': rel_path,
                'input_exists': True,
                'output_exists': False,
                'status': 'MISSING_OUTPUT',
            })
        else:
            extra_output += 1
            file_results.append({
                'rel_path': rel_path,
                'input_exists': False,
                'output_exists': True,
                'status': 'EXTRA_OUTPUT',
            })

    total_input = len(input_files)
    coverage_pct = round((matched / total_input * 100) if total_input > 0 else 100.0, 1)

    return {
        'files': file_results,
        'summary': {
            'total_input_files': total_input,
            'matched': matched,
            'missing_output': missing_output,
            'extra_output': extra_output,
            'coverage_pct': coverage_pct,
        },
    }


def generate_dbt_coverage_section(dbt_cov: Dict[str, Any]) -> str:
    """Generate the WS2 dbt section of the coverage report."""
    s = dbt_cov['summary']
    lines = [
        "",
        "---",
        "",
        "## Workstream 2: dbt Project Coverage",
        "",
        "For dbt, coverage means every input file has a corresponding output file at the **same relative path** with the **same file name**.",
        "",
        "| Metric | Value |",
        "| --- | --- |",
        f"| Input files | {s['total_input_files']} |",
        f"| Matched (same path in output) | {s['matched']} |",
        f"| **Missing output** | **{s['missing_output']}** |",
        f"| Extra output (no input) | {s['extra_output']} |",
        f"| **Coverage** | **{s['coverage_pct']}%** |",
        "",
    ]

    missing = [f for f in dbt_cov['files'] if f['status'] == 'MISSING_OUTPUT']
    if missing:
        lines.append("### Missing Output Files (CRITICAL)")
        lines.append("")
        lines.append("These input files have **no corresponding output**:")
        lines.append("")
        for f in missing:
            lines.append(f"- `{f['rel_path']}`")
        lines.append("")

    extra = [f for f in dbt_cov['files'] if f['status'] == 'EXTRA_OUTPUT']
    if extra:
        lines.append("### Extra Output Files (no input)")
        lines.append("")
        for f in extra:
            lines.append(f"- `{f['rel_path']}`")
        lines.append("")

    lines.append("### File-by-File Breakdown")
    lines.append("")
    lines.append("| Relative Path | Input | Output | Status |")
    lines.append("| --- | --- | --- | --- |")
    for f in dbt_cov['files']:
        in_mark = 'YES' if f['input_exists'] else '-'
        out_mark = 'YES' if f['output_exists'] else '**NO**'
        status = f['status']
        if status == 'MISSING_OUTPUT':
            status = '**MISSING**'
        lines.append(f"| `{f['rel_path']}` | {in_mark} | {out_mark} | {status} |")
    lines.append("")

    return '\n'.join(lines)


# ---------------------------------------------------------------------------
# CLI entry point
# ---------------------------------------------------------------------------

def main() -> None:
    parser = argparse.ArgumentParser(description='Generate conversion coverage report')
    parser.add_argument('-i', '--input', required=True, help='Input path')
    parser.add_argument('-o', '--output', default='output', help='Output directory')
    parser.add_argument('--type', default='all', choices=['all', 'dbt', 'both'],
                        help='Coverage type (default: all)')
    args = parser.parse_args()

    try:
        _sanitize_path(args.input, PROJECT_ROOT)
    except ValueError as e:
        print(f"Error: Invalid input path: {e}")
        return
    try:
        out_path = _sanitize_path(args.output, PROJECT_ROOT)
    except ValueError as e:
        print(f"Error: Invalid output path: {e}")
        return

    parts = []

    if args.type in ('all', 'both'):
        coverage = analyze_coverage(args.input, out_path)
        parts.append(generate_coverage_report(coverage, args.input, out_path))
        cs = coverage['summary']
        print(f"WS1 Coverage: {cs['coverage_pct']}% "
              f"({cs['covered_statements']}/{cs['total_statements']} statements)")

    if args.type in ('dbt', 'both'):
        dbt_cov = analyze_dbt_coverage(args.input, out_path)
        if not parts:
            timestamp = get_timestamp()
            parts.append(
                f"# Conversion Coverage Report\n\n"
                f"**Generated:** {timestamp}\n"
                f"**Input:** `{args.input}`\n"
                f"**Output:** `{out_path}`\n"
            )
        parts.append(generate_dbt_coverage_section(dbt_cov))
        ds = dbt_cov['summary']
        print(f"WS2 Coverage: {ds['coverage_pct']}% "
              f"({ds['matched']}/{ds['total_input_files']} files)")

    if parts:
        cov_path = (out_path / 'coverage_report.md').resolve()
        if not str(cov_path).startswith(str(PROJECT_ROOT.resolve())):
            raise ValueError(f"Coverage report path escapes project root: {cov_path}")
        cov_path.parent.mkdir(parents=True, exist_ok=True)
        cov_path.write_text('\n'.join(parts), encoding='utf-8')
        print(f"Coverage report saved: {cov_path}")


if __name__ == '__main__':
    main()
