"""
Reference Validation (--validate-against) — Diff Comparison Engine.

Compares converter output against hand-verified reference Databricks scripts.
Provides high-level similarity metrics, categorized diffs (comment-only vs
core SQL), and markdown report generation.

Usage:
    from diff_comparison import validate_against_reference, print_reference_validation, generate_reference_report
"""

import difflib
import re
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple


# ---------------------------------------------------------------------------
# Normalization helpers
# ---------------------------------------------------------------------------

def _normalize_sql(content: str) -> str:
    """Normalize SQL for comparison: strip comments, collapse whitespace, lowercase."""
    lines = []
    for line in content.split('\n'):
        stripped = line.strip()
        if not stripped or stripped.startswith('--') or stripped.startswith('#'):
            continue
        comment_idx = stripped.find('--')
        if comment_idx > 0:
            stripped = stripped[:comment_idx].rstrip()
        lines.append(stripped)
    normalized = '\n'.join(lines)
    normalized = re.sub(r'\s+', ' ', normalized)
    return normalized.strip().lower()


# ---------------------------------------------------------------------------
# File matching
# ---------------------------------------------------------------------------

def _match_output_to_reference(
    output_dir: Path, ref_dir: Path
) -> List[Tuple[Optional[Path], Optional[Path]]]:
    """Match output files to reference files by name.

    Returns list of (output_file, reference_file) pairs.
    Either side can be None (unmatched).
    """
    out_files = {f.name: f for f in sorted(output_dir.rglob('*'))
                 if f.is_file() and f.suffix in ('.sql', '.yml', '.yaml')}
    ref_files = {f.name: f for f in sorted(ref_dir.rglob('*'))
                 if f.is_file() and f.suffix in ('.sql', '.yml', '.yaml')}

    pairs = []
    all_names = sorted(set(out_files.keys()) | set(ref_files.keys()))
    for name in all_names:
        pairs.append((out_files.get(name), ref_files.get(name)))
    return pairs


# ---------------------------------------------------------------------------
# Diff categorization
# ---------------------------------------------------------------------------

_FUZZY_THRESHOLD = 0.65

_SQL_EQUIV = [
    (re.compile(r'\binteger\b'), 'int'),
    (re.compile(r'\bcurrent_timestamp\(\)'), 'current_timestamp'),
    (re.compile(r'\bcurrent_user\(\)'), 'current_user'),
    (re.compile(r'\bcurrent_date\(\)'), 'current_date'),
    (re.compile(r'\bif not exists\s+'), ''),
    (re.compile(r'\bbinary\(\d+\)'), 'binary'),
    (re.compile(r',\s*$'), ''),
    (re.compile(r';\s*$'), ''),
]


def _line_similarity(a_lines: List[str], b_lines: List[str]) -> float:
    """Compute fuzzy line-level similarity between two lists of normalized SQL lines."""
    if not a_lines and not b_lines:
        return 100.0
    if not a_lines or not b_lines:
        return 0.0
    max_len = max(len(a_lines), len(b_lines))
    used_b: set = set()
    total_score = 0.0
    for a_line in a_lines:
        best_score = 0.0
        best_j = -1
        for j, b_line in enumerate(b_lines):
            if j in used_b:
                continue
            s = difflib.SequenceMatcher(None, a_line, b_line).ratio()
            if s > best_score:
                best_score = s
                best_j = j
        if best_score >= _FUZZY_THRESHOLD and best_j >= 0:
            used_b.add(best_j)
            total_score += best_score
    return round(total_score / max_len * 100, 1)


def _norm_sql_lines(sql_lines: List[str]) -> List[str]:
    """Normalize SQL lines for comparison (lowercase, collapse whitespace, apply equivalents)."""
    normed = []
    for line in sql_lines:
        n = re.sub(r'\s+', ' ', line).strip().lower()
        for pat, repl in _SQL_EQUIV:
            n = pat.sub(repl, n)
        n = n.strip()
        if n:
            normed.append(n)
    return normed


def _norm_all_lines(content: str) -> List[str]:
    """Normalize all non-empty lines (including comments) for overall similarity."""
    normed = []
    for line in content.split('\n'):
        n = re.sub(r'\s+', ' ', line).strip().lower()
        if n:
            normed.append(n)
    return normed


def _split_comment_sql(lines: List[str]) -> Tuple[List[str], List[str]]:
    """Separate comment lines from SQL lines, stripping inline comments from SQL."""
    _inline_comment_re = re.compile(r'\s*--.*$')
    comments = []
    sql = []
    for line in lines:
        stripped = line.strip()
        if not stripped:
            continue
        if stripped.startswith('--') or stripped.startswith('#') or stripped.startswith('{#'):
            comments.append(stripped)
        else:
            sql_part = _inline_comment_re.sub('', stripped).rstrip()
            if sql_part:
                sql.append(sql_part)
    return comments, sql


def _categorize_diff(out_content: str, ref_content: str) -> Dict[str, Any]:
    """Categorize differences between output and reference into high-level buckets."""
    out_lines = out_content.split('\n')
    ref_lines = ref_content.split('\n')

    out_comments, out_sql = _split_comment_sql(out_lines)
    ref_comments, ref_sql = _split_comment_sql(ref_lines)

    out_sql_normed = _norm_sql_lines(out_sql)
    ref_sql_normed = _norm_sql_lines(ref_sql)
    core_sql_match = out_sql_normed == ref_sql_normed

    core_sql_similarity = _line_similarity(out_sql_normed, ref_sql_normed)

    out_all_normed = _norm_all_lines(out_content)
    ref_all_normed = _norm_all_lines(ref_content)
    overall_similarity = _line_similarity(out_all_normed, ref_all_normed)

    diff_categories = []
    if len(out_comments) != len(ref_comments) or out_comments != ref_comments:
        diff_categories.append('Comments (traceability/conversion notes)')
    if not core_sql_match:
        if core_sql_similarity >= 90:
            diff_categories.append('Minor SQL differences')
        elif core_sql_similarity >= 70:
            diff_categories.append('Moderate SQL differences')
        else:
            diff_categories.append('Significant SQL differences')
    if not diff_categories and out_all_normed != ref_all_normed:
        diff_categories.append('Whitespace/formatting only')

    # Count diff lines on normalized content
    out_normed_lines = [re.sub(r'\s+', ' ', l).strip() for l in out_lines if l.strip()]
    ref_normed_lines = [re.sub(r'\s+', ' ', l).strip() for l in ref_lines if l.strip()]
    diff_obj = list(difflib.unified_diff(out_normed_lines, ref_normed_lines, n=0))
    comment_diff = 0
    sql_diff = 0
    for line in diff_obj:
        if line.startswith('+++') or line.startswith('---') or line.startswith('@@'):
            continue
        if line.startswith('+') or line.startswith('-'):
            content_part = line[1:].strip()
            if content_part.startswith('--') or content_part.startswith('#') or content_part.startswith('{#'):
                comment_diff += 1
            elif content_part:
                sql_diff += 1

    return {
        'overall_similarity': overall_similarity,
        'core_sql_match': core_sql_match,
        'core_sql_similarity': core_sql_similarity,
        'diff_categories': diff_categories,
        'comment_lines_diff': comment_diff,
        'sql_lines_diff': sql_diff,
        'total_lines_out': len([l for l in out_lines if l.strip()]),
        'total_lines_ref': len([l for l in ref_lines if l.strip()]),
    }


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def validate_against_reference(
    output_dir: Path, ref_dir: Path
) -> List[Dict[str, Any]]:
    """Compare converter output against reference Databricks scripts."""
    results: List[Dict[str, Any]] = []
    pairs = _match_output_to_reference(output_dir, ref_dir)

    for out_file, ref_file in pairs:
        if out_file and not ref_file:
            results.append({
                'file': out_file.name,
                'status': 'NO_REFERENCE',
                'message': 'Output file has no matching reference file',
                'similarity': None,
                'diff_detail': None,
            })
            continue

        if ref_file and not out_file:
            results.append({
                'file': ref_file.name,
                'status': 'MISSING_OUTPUT',
                'message': 'Reference file has no matching output file',
                'similarity': None,
                'diff_detail': None,
            })
            continue

        out_content = out_file.read_text(encoding='utf-8')
        ref_content = ref_file.read_text(encoding='utf-8')

        out_norm = _normalize_sql(out_content)
        ref_norm = _normalize_sql(ref_content)

        if out_norm == ref_norm:
            results.append({
                'file': out_file.name,
                'status': 'MATCH',
                'message': 'Core SQL logic matches reference',
                'similarity': 100.0,
                'diff_detail': {
                    'overall_similarity': 100.0,
                    'core_sql_match': True,
                    'core_sql_similarity': 100.0,
                    'diff_categories': [],
                    'comment_lines_diff': 0,
                    'sql_lines_diff': 0,
                    'total_lines_out': len([l for l in out_content.split('\n') if l.strip()]),
                    'total_lines_ref': len([l for l in ref_content.split('\n') if l.strip()]),
                },
            })
            continue

        diff_detail = _categorize_diff(out_content, ref_content)

        results.append({
            'file': out_file.name,
            'status': 'MISMATCH',
            'message': f"Differences found ({diff_detail['overall_similarity']}% similar)",
            'similarity': diff_detail['overall_similarity'],
            'diff_detail': diff_detail,
        })

    return results


def print_reference_validation(results: List[Dict[str, Any]]) -> None:
    """Print high-level reference validation results to console."""
    matches = [r for r in results if r['status'] == 'MATCH']
    mismatches = [r for r in results if r['status'] == 'MISMATCH']
    no_ref = [r for r in results if r['status'] == 'NO_REFERENCE']
    missing = [r for r in results if r['status'] == 'MISSING_OUTPUT']

    print(f"\n  REFERENCE VALIDATION")
    print(f"  {'='*50}")
    print(f"    Matched:          {len(matches)}")
    print(f"    Mismatched:       {len(mismatches)}")
    print(f"    No reference:     {len(no_ref)}")
    print(f"    Missing output:   {len(missing)}")
    print(f"  {'='*50}")

    if matches:
        print(f"\n  MATCHED files:")
        for r in matches:
            print(f"    [PASS] {r['file']}")

    if mismatches:
        print(f"\n  MISMATCHED files:")
        for r in mismatches:
            d = r.get('diff_detail', {})
            core_status = 'SAME' if d.get('core_sql_match') else f"{d.get('core_sql_similarity', '?')}%"
            cats = ', '.join(d.get('diff_categories', [])) or 'Unknown'
            print(f"    [DIFF] {r['file']}")
            print(f"           Core SQL: {core_status} | "
                  f"Overall (with comments): {r['similarity']}% | "
                  f"SQL diff: {d.get('sql_lines_diff', '?')} lines")
            print(f"           Reason: {cats}")

    if missing:
        print(f"\n  MISSING output (reference exists but no converter output):")
        for r in missing:
            print(f"    [MISS] {r['file']}")

    if no_ref:
        print(f"\n  NO REFERENCE (converter output has no reference to compare):")
        for r in no_ref:
            print(f"    [SKIP] {r['file']}")


def generate_reference_report(results: List[Dict[str, Any]]) -> str:
    """Generate high-level markdown section for reference validation."""
    matches = [r for r in results if r['status'] == 'MATCH']
    mismatches = [r for r in results if r['status'] == 'MISMATCH']
    no_ref = [r for r in results if r['status'] == 'NO_REFERENCE']
    missing = [r for r in results if r['status'] == 'MISSING_OUTPUT']

    total_compared = len(matches) + len(mismatches)
    comment_only = [r for r in mismatches if r.get('diff_detail', {}).get('core_sql_match')]
    sql_diff = [r for r in mismatches if not r.get('diff_detail', {}).get('core_sql_match')]
    avg_similarity = round(
        sum(r['similarity'] for r in mismatches) / len(mismatches), 1
    ) if mismatches else 0
    avg_core_sql = round(
        sum(r.get('diff_detail', {}).get('core_sql_similarity', 0) for r in mismatches) / len(mismatches), 1
    ) if mismatches else 0

    lines = [
        "## Reference Validation",
        "",
        "Compared converter output against hand-verified reference Databricks scripts.",
        "",
        "### Summary",
        "",
        "| Metric | Value |",
        "| --- | --- |",
        f"| Files compared | {total_compared} |",
        f"| Exact match (core SQL identical) | {len(matches)} |",
        f"| Differences found | {len(mismatches)} |",
        f"| — Comment-only differences | {len(comment_only)} |",
        f"| — Core SQL logic differences | {len(sql_diff)} |",
        f"| No reference file available | {len(no_ref)} |",
        f"| Missing output (reference exists, no output) | {len(missing)} |",
        "",
    ]

    if mismatches:
        lines.extend([
            f"**Average core SQL similarity:** {avg_core_sql}%",
            f"**Average overall similarity (with comments):** {avg_similarity}%",
            "",
        ])

    if mismatches:
        lines.extend([
            "### File Comparison Detail",
            "",
            "| File | Core SQL | Overall (with comments) | SQL Diff | Difference Type |",
            "| --- | --- | --- | --- | --- |",
        ])
        for r in sorted(mismatches, key=lambda x: x.get('similarity', 0)):
            d = r.get('diff_detail', {})
            core = 'SAME' if d.get('core_sql_match') else f"{d.get('core_sql_similarity', '?')}%"
            cats = ', '.join(d.get('diff_categories', [])) or '\u2014'
            lines.append(
                f"| `{r['file']}` | {core} | {r['similarity']}% | "
                f"{d.get('sql_lines_diff', 0)} lines | {cats} |"
            )
        lines.append("")

    if comment_only:
        lines.extend([
            "### Comment-Only Differences",
            "",
            "These files have **identical core SQL logic** — differences are only in traceability/conversion comments added by the converter:",
            "",
        ])
        for r in comment_only:
            lines.append(f"- `{r['file']}` — {r['similarity']}% overall, core SQL: SAME")
        lines.append("")

    if sql_diff:
        lines.extend([
            "### Core SQL Differences",
            "",
            "These files have differences in the actual SQL logic (may need manual review):",
            "",
        ])
        for r in sql_diff:
            d = r.get('diff_detail', {})
            lines.append(
                f"- `{r['file']}` — Core SQL: {d.get('core_sql_similarity', '?')}%, "
                f"{d.get('sql_lines_diff', '?')} SQL lines differ"
            )
        lines.append("")

    if missing:
        lines.extend([
            "### Missing Output Files",
            "",
        ])
        for r in missing:
            lines.append(f"- `{r['file']}`")
        lines.append("")

    if matches:
        lines.extend([
            "### Matched Files",
            "",
        ])
        for r in matches:
            lines.append(f"- `{r['file']}` — PASS")
        lines.append("")

    return '\n'.join(lines)
