"""
Agentic Validator - Validates all generated Databricks SQL output against source Redshift SQL.

Validates DDL, DML, views, materialized views, stored procedures, queries, and
combined output files. Checks for residual Redshift syntax, correct conversions,
traceability comments, and structural correctness.

Usage:
    python scripts/validator.py                          # Validate all output
    python scripts/validator.py --output output          # Custom output dir
    python scripts/validator.py --input inputs/sql       # Custom input dir
    python scripts/validator.py --dry-run                # Preview only
"""

import argparse
import re
import sys
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

SCRIPTS_DIR = Path(__file__).resolve().parent
sys.path.insert(0, str(SCRIPTS_DIR))

from base_validator import BaseValidator
from sql_functions import DATA_TYPE_MAP
from utils import get_timestamp, save_yaml, setup_logging


# ---------------------------------------------------------------------------
# Redshift patterns that should NOT appear on non-comment lines in output
# ---------------------------------------------------------------------------
REDSHIFT_RESIDUAL_PATTERNS: List[Tuple[re.Pattern, str]] = [
    # ── Data Types ──
    (re.compile(r'\btimestamptz\b', re.IGNORECASE), 'TIMESTAMPTZ'),
    (re.compile(r'\btimestamp\s+with\s+time\s+zone\b', re.IGNORECASE), 'TIMESTAMP WITH TIME ZONE'),
    (re.compile(r'\bbpchar\b', re.IGNORECASE), 'BPCHAR'),
    (re.compile(r'\bnumeric\s*\(', re.IGNORECASE), 'NUMERIC('),
    # ── DDL Constructs ──
    (re.compile(r'\bdistkey\b', re.IGNORECASE), 'DISTKEY'),
    (re.compile(r'\bdiststyle\b', re.IGNORECASE), 'DISTSTYLE'),
    (re.compile(r'\bsortkey\b', re.IGNORECASE), 'SORTKEY'),
    (re.compile(r'\bencode\s+\w+\b', re.IGNORECASE), 'ENCODE'),
    (re.compile(r'\bIDENTITY\s*\(\s*\d', re.IGNORECASE), 'IDENTITY()'),
    # ── Date/Time Functions ──
    (re.compile(r'\bGETDATE\s*\(\s*\)', re.IGNORECASE), 'GETDATE()'),
    (re.compile(r'\bSYSDATE\b', re.IGNORECASE), 'SYSDATE'),
    (re.compile(r'\bNOW\s*\(\s*\)', re.IGNORECASE), 'NOW()'),
    (re.compile(r'\bDATE_PART_YEAR\s*\(', re.IGNORECASE), 'DATE_PART_YEAR()'),
    (re.compile(r'\bTIMEOFDAY\s*\(\s*\)', re.IGNORECASE), 'TIMEOFDAY()'),
    (re.compile(r'\bAGE\s*\(', re.IGNORECASE), 'AGE()'),
    # ── Null/Conditional Functions ──
    (re.compile(r'\bNVL\s*\(', re.IGNORECASE), 'NVL('),
    (re.compile(r'\bNVL2\s*\(', re.IGNORECASE), 'NVL2()'),
    (re.compile(r'\bDECODE\s*\(', re.IGNORECASE), 'DECODE()'),
    (re.compile(r'\bIIF\s*\(', re.IGNORECASE), 'IIF()'),
    (re.compile(r'\bZEROIFNULL\s*\(', re.IGNORECASE), 'ZEROIFNULL()'),
    (re.compile(r'\bNULLIFZERO\s*\(', re.IGNORECASE), 'NULLIFZERO()'),
    # ── String Functions ──
    (re.compile(r'\bLEN\s*\(', re.IGNORECASE), 'LEN()'),
    (re.compile(r'\bTEXTLEN\s*\(', re.IGNORECASE), 'TEXTLEN()'),
    (re.compile(r'\bSTRPOS\s*\(', re.IGNORECASE), 'STRPOS()'),
    (re.compile(r'\bCHARINDEX\s*\(', re.IGNORECASE), 'CHARINDEX()'),
    (re.compile(r'\bREPLICATE\s*\(', re.IGNORECASE), 'REPLICATE()'),
    (re.compile(r'\bBTRIM\s*\(', re.IGNORECASE), 'BTRIM()'),
    (re.compile(r'\bFUNC_SHA1\s*\(', re.IGNORECASE), 'FUNC_SHA1()'),
    (re.compile(r'\bSTRTOL\s*\(', re.IGNORECASE), 'STRTOL()'),
    (re.compile(r'\bREGEXP_SUBSTR\s*\(', re.IGNORECASE), 'REGEXP_SUBSTR()'),
    # ── Math Functions ──
    (re.compile(r'\bDEXP\s*\(', re.IGNORECASE), 'DEXP()'),
    (re.compile(r'\bDLOG1\s*\(', re.IGNORECASE), 'DLOG1()'),
    (re.compile(r'\bDLOG10\s*\(', re.IGNORECASE), 'DLOG10()'),
    (re.compile(r'\bCBRT\s*\(', re.IGNORECASE), 'CBRT()'),
    # ── JSON Functions ──
    (re.compile(r'\bJSON_PARSE\s*\(', re.IGNORECASE), 'JSON_PARSE()'),
    (re.compile(r'\bIS_VALID_JSON\s*\(', re.IGNORECASE), 'IS_VALID_JSON()'),
    (re.compile(r'\bIS_VALID_JSON_ARRAY\s*\(', re.IGNORECASE), 'IS_VALID_JSON_ARRAY()'),
    (re.compile(r'\bCAN_JSON_PARSE\s*\(', re.IGNORECASE), 'CAN_JSON_PARSE()'),
    (re.compile(r'\bJSON_SERIALIZE\s*\(', re.IGNORECASE), 'JSON_SERIALIZE()'),
    # ── Aggregate Functions ──
    (re.compile(r'\bLISTAGG\s*\(', re.IGNORECASE), 'LISTAGG()'),
    # ── Format Functions (should be DATE_FORMAT) ──
    (re.compile(r'\bTO_CHAR\s*\(', re.IGNORECASE), 'TO_CHAR()'),
    # ── System Tables ──
    (re.compile(r'\bstl_\w+\b', re.IGNORECASE), 'STL_ system table'),
    (re.compile(r'\bstv_\w+\b', re.IGNORECASE), 'STV_ system table'),
    (re.compile(r'\bsvv_\w+\b', re.IGNORECASE), 'SVV_ system table'),
    (re.compile(r'\bsvl_\w+\b', re.IGNORECASE), 'SVL_ system table'),
    # ── PL/pgSQL ──
    (re.compile(r'\bPERFORM\s+', re.IGNORECASE), 'PERFORM (PL/pgSQL)'),
    # ── Casting ──
    (re.compile(r'\b::\s*(?:varchar|integer|bigint|float|text|boolean|numeric|decimal)\b', re.IGNORECASE), ':: cast syntax'),
]

# Expected data type conversions (source regex -> expected output type)
EXPECTED_TYPE_MAP: List[Tuple[re.Pattern, str]] = [
    (re.compile(r'\btimestamptz\b', re.IGNORECASE), 'TIMESTAMP'),
    (re.compile(r'\btimestamp\s+with\s+time\s+zone\b', re.IGNORECASE), 'TIMESTAMP'),
    (re.compile(r'\bbpchar\s*(\(\s*\d+\s*\))?', re.IGNORECASE), 'STRING'),
    (re.compile(r'\bnumeric\s*\(\s*(\d+)\s*,\s*(\d+)\s*\)', re.IGNORECASE), 'DECIMAL'),
    (re.compile(r'\bvarchar\b(?!\s*\()', re.IGNORECASE), 'STRING'),
    (re.compile(r'\bvarchar\s*\(\s*\d+\s*\)', re.IGNORECASE), 'STRING'),
    (re.compile(r'\bcharacter\s+varying\s*\(\s*\d+\s*\)', re.IGNORECASE), 'STRING'),
    (re.compile(r'\bchar\s*\(\s*\d+\s*\)', re.IGNORECASE), 'STRING'),
    (re.compile(r'\btext\b', re.IGNORECASE), 'STRING'),
    (re.compile(r'\bsuper\b', re.IGNORECASE), 'STRING'),
    (re.compile(r'\bfloat8\b', re.IGNORECASE), 'DOUBLE'),
    (re.compile(r'\bfloat4\b', re.IGNORECASE), 'FLOAT'),
    (re.compile(r'\breal\b', re.IGNORECASE), 'FLOAT'),
    (re.compile(r'\bdouble\s+precision\b', re.IGNORECASE), 'DOUBLE'),
    (re.compile(r'\bint2\b', re.IGNORECASE), 'SMALLINT'),
    (re.compile(r'\bint4\b', re.IGNORECASE), 'INT'),
    (re.compile(r'\bint8\b', re.IGNORECASE), 'BIGINT'),
]


class OutputValidator(BaseValidator):
    """Validates all generated Databricks SQL output files."""

    # ------------------------------------------------------------------
    # VAL-01: Redshift function -> Databricks equivalent mapping
    # ------------------------------------------------------------------
    FUNCTION_TRANSLATION_MAP: Dict[str, List[str]] = {
        'GETDATE': ['CURRENT_TIMESTAMP'],
        'SYSDATE': ['CURRENT_TIMESTAMP'],
        'NVL': ['COALESCE'],
        'LEN': ['LENGTH'],
        'STRPOS': ['LOCATE', 'INSTR'],
        'DATEADD': ['DATE_ADD', 'ADD_MONTHS', 'DATEADD'],
        'DATEDIFF': ['DATEDIFF', 'MONTHS_BETWEEN'],
        'TO_CHAR': ['DATE_FORMAT'],
        'DECODE': ['CASE'],
        'LISTAGG': ['ARRAY_JOIN'],
        'NVL2': ['CASE', 'COALESCE'],
        'JSON_EXTRACT_PATH_TEXT': ['GET_JSON_OBJECT'],
        'STRTOL': ['CONV'],
        'BTRIM': ['TRIM'],
    }

    # VAL-03: Redshift-only types that should NOT appear inside CAST(... AS <type>) in output
    REDSHIFT_ONLY_CAST_TYPES: List[Tuple[re.Pattern, str]] = [
        (re.compile(r'\bVARCHAR\s*\(\s*\d+\s*\)', re.IGNORECASE), 'VARCHAR(N)'),
        (re.compile(r'\bCHAR\s*\(\s*\d+\s*\)', re.IGNORECASE), 'CHAR(N)'),
        (re.compile(r'\bNUMERIC\b(?!\s*\()', re.IGNORECASE), 'NUMERIC (bare)'),
        (re.compile(r'\bINTEGER\b', re.IGNORECASE), 'INTEGER'),
        (re.compile(r'\bTEXT\b', re.IGNORECASE), 'TEXT'),
        (re.compile(r'\bBPCHAR\b', re.IGNORECASE), 'BPCHAR'),
        (re.compile(r'\bNVARCHAR\b', re.IGNORECASE), 'NVARCHAR'),
        (re.compile(r'\bDATETIME\b', re.IGNORECASE), 'DATETIME'),
        (re.compile(r'\bINT2\b', re.IGNORECASE), 'INT2'),
        (re.compile(r'\bINT4\b', re.IGNORECASE), 'INT4'),
        (re.compile(r'\bINT8\b', re.IGNORECASE), 'INT8'),
    ]

    # VAL-04: Redshift date tokens that should have been converted
    REDSHIFT_DATE_TOKENS: Dict[str, str] = {
        'YYYY': 'yyyy',
        'DD': 'dd',
        'HH24': 'HH',
        'MI': 'mm',
        'MON': 'MMM',
    }

    def __init__(
        self,
        input_dir: str = 'inputs/sql',
        output_dir: str = 'output',
    ) -> None:
        super().__init__(target_dir=output_dir)
        self.input_dir = Path(input_dir)
        self.output_dir = Path(output_dir)
        self.sql_dir = self.output_dir / 'sql'
        self.log_dir = Path('thoughts/logs/agentic')
        self._issue_counter = 0

        # Metrics storage for VAL-05 weighted accuracy
        self._metrics: Dict[str, float] = {}

        # Parse source tables for DDL column-level checks
        self.source_tables: Dict[str, Dict[str, Any]] = {}
        self._parse_source_tables()

        # Build input-to-output file mapping
        self._input_output_map: Dict[Path, Optional[Path]] = {}
        self._build_file_mapping()

    # ------------------------------------------------------------------
    # Source parsing
    # ------------------------------------------------------------------

    def _parse_source_tables(self) -> None:
        """Parse all CREATE TABLE statements from input SQL files."""
        if not self.input_dir.exists():
            return
        for sql_file in sorted(self.input_dir.glob('*.sql')):
            content = sql_file.read_text(encoding='utf-8')
            # Use balanced-paren matching for accurate extraction
            pattern = re.compile(
                r'CREATE\s+(?:OR\s+REPLACE\s+)?(?:EXTERNAL\s+)?TABLE\s+(?:IF\s+NOT\s+EXISTS\s+)?([\w.]+)\s*\(',
                re.IGNORECASE,
            )
            for match in pattern.finditer(content):
                full_name = match.group(1).strip()
                table_name = full_name.split('.')[-1]
                # Walk balanced parens
                open_pos = match.end() - 1
                depth = 1
                i = open_pos + 1
                while i < len(content) and depth > 0:
                    if content[i] == '(':
                        depth += 1
                    elif content[i] == ')':
                        depth -= 1
                    i += 1
                if depth != 0:
                    continue
                close_pos = i - 1
                columns_block = content[open_pos + 1:close_pos].strip()
                columns = self._parse_source_columns(columns_block)
                self.source_tables[table_name] = {
                    'full_name': full_name,
                    'source_file': sql_file.name,
                    'columns': columns,
                }

    def _parse_source_columns(self, block: str) -> List[Dict[str, str]]:
        """Parse column definitions from a CREATE TABLE columns block."""
        columns: List[Dict[str, str]] = []
        depth = 0
        current: List[str] = []
        for char in block:
            if char == '(':
                depth += 1
                current.append(char)
            elif char == ')':
                depth -= 1
                current.append(char)
            elif char == ',' and depth == 0:
                col_def = ''.join(current).strip()
                if col_def:
                    parsed = self._parse_col_def(col_def)
                    if parsed:
                        columns.append(parsed)
                current = []
            else:
                current.append(char)
        col_def = ''.join(current).strip()
        if col_def:
            parsed = self._parse_col_def(col_def)
            if parsed:
                columns.append(parsed)
        return columns

    @staticmethod
    def _parse_col_def(col_def: str) -> Optional[Dict[str, str]]:
        """Parse a single column definition."""
        col_def = col_def.strip()
        # Skip table-level constraints
        if re.match(r'\s*(?:PRIMARY\s+KEY|UNIQUE|FOREIGN\s+KEY|CONSTRAINT)\b', col_def, re.IGNORECASE):
            return None
        match = re.match(
            r'(\w+)\s+'
            r'((?:timestamp\s+with(?:out)?\s+time\s+zone|character\s+varying'
            r'|double\s+precision|binary\s+varying'
            r'|\w+)(?:\s*\([^)]*\))?)'
            r'(.*)',
            col_def, re.IGNORECASE,
        )
        if match:
            return {
                'name': match.group(1).strip(),
                'type': match.group(2).strip(),
                'constraints': match.group(3).strip(),
            }
        return None

    # ------------------------------------------------------------------
    # Input-to-output file mapping
    # ------------------------------------------------------------------

    def _build_file_mapping(self) -> None:
        """Build mapping from each input SQL file to its corresponding output file.

        Uses stem-matching heuristics: an input 'foo.sql' maps to an output whose
        stem contains 'foo' (with or without '_converted' suffix).
        """
        if not self.input_dir.exists():
            return

        input_files = sorted(self.input_dir.glob('*.sql'))
        output_files: List[Path] = []
        if self.sql_dir.exists():
            output_files = sorted(self.sql_dir.rglob('*.sql'))

        # Build lookup by stem (lowercase)
        output_by_stem: Dict[str, Path] = {}
        for of in output_files:
            stem = of.stem.lower().replace('_converted', '')
            output_by_stem[stem] = of

        for inf in input_files:
            stem = inf.stem.lower()
            # Try exact match, then partial
            matched = output_by_stem.get(stem)
            if not matched:
                # Try matching last part of dotted names (e.g. schema.table -> table)
                short = stem.split('.')[-1]
                matched = output_by_stem.get(short)
            if not matched:
                # Fuzzy: look for any output stem containing the input stem
                for out_stem, out_path in output_by_stem.items():
                    if stem in out_stem or out_stem in stem:
                        matched = out_path
                        break
            self._input_output_map[inf] = matched

    @staticmethod
    def _is_comment_line(line: str) -> bool:
        """Check if a line is a SQL comment."""
        stripped = line.strip()
        return (stripped.startswith('--') or stripped.startswith('/*')
                or stripped.startswith('{#') or stripped.startswith('*'))

    @staticmethod
    def _strip_string_literals(text: str) -> str:
        """Remove string literals from SQL text to avoid false positives."""
        return re.sub(r"'[^']*'", "''", text)

    # ------------------------------------------------------------------
    # VAL-01: Function translation verification
    # ------------------------------------------------------------------

    def _check_function_translation(self) -> Tuple[List[Dict[str, str]], float]:
        """Verify that Redshift functions in input are translated to Databricks equivalents in output.

        Returns:
            Tuple of (issues list, function_translation_rate).
        """
        issues: List[Dict[str, str]] = []
        total_found = 0
        total_translated = 0

        for input_file, output_file in self._input_output_map.items():
            if output_file is None or not output_file.exists():
                continue

            input_content = input_file.read_text(encoding='utf-8')
            output_content = output_file.read_text(encoding='utf-8')

            # Filter out comment lines from input
            input_lines = [
                line for line in input_content.split('\n')
                if not self._is_comment_line(line)
            ]
            input_code = '\n'.join(input_lines)

            output_lines = [
                line for line in output_content.split('\n')
                if not self._is_comment_line(line)
            ]
            output_code = '\n'.join(output_lines)

            input_ref = str(input_file.relative_to(self.input_dir.parent.parent)
                            if self.input_dir.parent.parent.exists() else input_file.name)
            output_ref = str(output_file.relative_to(self.output_dir)
                             if self.output_dir.exists() else output_file.name)

            for rs_func, dbx_equivalents in self.FUNCTION_TRANSLATION_MAP.items():
                # Word-boundary, case-insensitive match for the Redshift function
                pattern = re.compile(r'\b' + re.escape(rs_func) + r'\s*\(', re.IGNORECASE)
                count = len(pattern.findall(input_code))
                if count == 0:
                    continue

                total_found += count

                # Check output for any of the expected Databricks equivalents
                found_equiv = False
                for equiv in dbx_equivalents:
                    equiv_pat = re.compile(r'\b' + re.escape(equiv) + r'\b', re.IGNORECASE)
                    if equiv_pat.search(output_code):
                        found_equiv = True
                        break

                if found_equiv:
                    total_translated += count
                else:
                    # Also check if the Redshift function is still present in output (residual)
                    still_present = pattern.search(output_code) is not None
                    severity = 'high' if still_present else 'medium'
                    issues.append(self._issue(
                        severity, 'untranslated_function',
                        f"Redshift function {rs_func}() ({count}x in input) not translated "
                        f"to {'/'.join(dbx_equivalents)} in output",
                        source_file=input_ref, output_file=output_ref,
                    ))

        rate = (total_translated / total_found) if total_found > 0 else 1.0
        self._metrics['function_translation_rate'] = rate
        return issues, rate

    # ------------------------------------------------------------------
    # VAL-02: Cast conversion completeness
    # ------------------------------------------------------------------

    def _check_cast_conversion(self) -> Tuple[List[Dict[str, str]], float]:
        """Verify that :: cast operators are converted to CAST() expressions.

        Returns:
            Tuple of (issues list, cast_conversion_rate).
        """
        issues: List[Dict[str, str]] = []
        total_input_casts = 0
        total_output_casts = 0
        remaining_double_colon = 0

        for input_file, output_file in self._input_output_map.items():
            if output_file is None or not output_file.exists():
                continue

            input_content = input_file.read_text(encoding='utf-8')
            output_content = output_file.read_text(encoding='utf-8')

            output_ref = str(output_file.relative_to(self.output_dir)
                             if self.output_dir.exists() else output_file.name)

            # Count :: in input (non-comment, non-string-literal lines)
            input_count = 0
            for line in input_content.split('\n'):
                if self._is_comment_line(line):
                    continue
                cleaned = self._strip_string_literals(line)
                input_count += len(re.findall(r'::', cleaned))
            total_input_casts += input_count

            # Count CAST() in output (non-comment lines)
            output_cast_count = 0
            output_double_colon = 0
            for line_num, line in enumerate(output_content.split('\n'), 1):
                if self._is_comment_line(line):
                    continue
                cleaned = self._strip_string_literals(line)
                output_cast_count += len(re.findall(r'\bCAST\s*\(', cleaned, re.IGNORECASE))
                dc_matches = re.findall(r'::', cleaned)
                if dc_matches:
                    output_double_colon += len(dc_matches)

            total_output_casts += output_cast_count

            if output_double_colon > 0:
                remaining_double_colon += output_double_colon
                issues.append(self._issue(
                    'high', 'residual_cast_operator',
                    f"Found {output_double_colon} remaining :: cast operator(s) in output",
                    source_file=str(input_file.name), output_file=output_ref,
                ))

        # Rate: if input had N casts, how many were converted?
        if total_input_casts > 0:
            rate = max(0.0, min(1.0, (total_input_casts - remaining_double_colon) / total_input_casts))
        else:
            rate = 1.0

        self._metrics['cast_conversion_rate'] = rate
        return issues, rate

    # ------------------------------------------------------------------
    # VAL-03: Data type mapping in non-DDL files
    # ------------------------------------------------------------------

    def _check_non_ddl_type_mapping(self) -> Tuple[List[Dict[str, str]], float]:
        """Scan non-DDL output files for CAST(... AS <redshift_type>) patterns.

        Returns:
            Tuple of (issues list, data_type_mapping_accuracy).
        """
        issues: List[Dict[str, str]] = []
        total_casts_checked = 0
        bad_casts = 0

        # Pattern to extract the type from CAST(... AS <type>)
        cast_as_pat = re.compile(r'\bCAST\s*\([^)]*\bAS\s+([^)]+)\)', re.IGNORECASE)

        all_output = self._collect_output_files()
        for sql_file, file_type in all_output:
            # Check all file types (including DDL for completeness in CAST expressions)
            content = sql_file.read_text(encoding='utf-8')
            output_ref = str(sql_file.relative_to(self.output_dir))

            for line_num, line in enumerate(content.split('\n'), 1):
                if self._is_comment_line(line):
                    continue
                for m in cast_as_pat.finditer(line):
                    type_str = m.group(1).strip()
                    total_casts_checked += 1
                    for type_pat, type_label in self.REDSHIFT_ONLY_CAST_TYPES:
                        if type_pat.search(type_str):
                            bad_casts += 1
                            issues.append(self._issue(
                                'medium', 'redshift_type_in_cast',
                                f"Redshift-only type {type_label} in CAST at line {line_num}: "
                                f"CAST(... AS {type_str.strip()})",
                                output_file=output_ref,
                            ))
                            break  # Only flag once per CAST

        if total_casts_checked > 0:
            rate = (total_casts_checked - bad_casts) / total_casts_checked
        else:
            rate = 1.0

        self._metrics['data_type_mapping_accuracy'] = rate
        return issues, rate

    # ------------------------------------------------------------------
    # VAL-04: Date format token verification
    # ------------------------------------------------------------------

    def _check_date_format_tokens(self) -> List[Dict[str, str]]:
        """Find DATE_FORMAT calls in output and flag unconverted Redshift date tokens.

        Returns:
            List of issues found.
        """
        issues: List[Dict[str, str]] = []

        # Pattern: DATE_FORMAT(expr, 'format_string')
        date_fmt_pat = re.compile(
            r"\bDATE_FORMAT\s*\([^,]+,\s*'([^']+)'\s*\)", re.IGNORECASE
        )

        all_output = self._collect_output_files()
        for sql_file, file_type in all_output:
            content = sql_file.read_text(encoding='utf-8')
            output_ref = str(sql_file.relative_to(self.output_dir))

            for line_num, line in enumerate(content.split('\n'), 1):
                if self._is_comment_line(line):
                    continue
                for m in date_fmt_pat.finditer(line):
                    fmt_str = m.group(1)
                    for rs_token, dbx_token in self.REDSHIFT_DATE_TOKENS.items():
                        # Use word boundary or context to avoid false positives
                        # e.g. 'YYYY' as a standalone token, not part of 'yyyy'
                        token_pat = re.compile(r'(?<![a-zA-Z])' + re.escape(rs_token) + r'(?![a-zA-Z])')
                        if token_pat.search(fmt_str):
                            issues.append(self._issue(
                                'medium', 'unconverted_date_token',
                                f"Redshift date token '{rs_token}' in DATE_FORMAT at line {line_num} "
                                f"(should be '{dbx_token}'): format='{fmt_str}'",
                                output_file=output_ref,
                            ))

        return issues

    # ------------------------------------------------------------------
    # VAL-06: Statement-level coverage
    # ------------------------------------------------------------------

    @staticmethod
    def _count_sql_statements(content: str) -> int:
        """Count SQL statements by splitting on semicolons outside strings and comments.

        Args:
            content: SQL file content.

        Returns:
            Number of non-empty SQL statements.
        """
        # Remove block comments
        no_block = re.sub(r'/\*.*?\*/', '', content, flags=re.DOTALL)
        # Remove line comments
        no_comments = re.sub(r'--[^\n]*', '', no_block)
        # Remove string literals to avoid counting semicolons inside them
        no_strings = re.sub(r"'[^']*'", "''", no_comments)
        # Split on semicolons
        statements = no_strings.split(';')
        # Count non-empty statements (after stripping whitespace)
        count = sum(1 for s in statements if s.strip())
        return count

    def _check_statement_coverage(self) -> Tuple[List[Dict[str, str]], float]:
        """Compare statement counts between input and output files.

        Returns:
            Tuple of (issues list, statement_coverage_rate).
        """
        issues: List[Dict[str, str]] = []
        total_input_stmts = 0
        total_output_stmts = 0

        for input_file, output_file in self._input_output_map.items():
            if output_file is None or not output_file.exists():
                input_content = input_file.read_text(encoding='utf-8')
                in_count = self._count_sql_statements(input_content)
                total_input_stmts += in_count
                if in_count > 0:
                    issues.append(self._issue(
                        'medium', 'missing_output_file',
                        f"Input file has {in_count} statements but no matching output found",
                        source_file=str(input_file.name),
                    ))
                continue

            input_content = input_file.read_text(encoding='utf-8')
            output_content = output_file.read_text(encoding='utf-8')

            in_count = self._count_sql_statements(input_content)
            out_count = self._count_sql_statements(output_content)

            total_input_stmts += in_count
            total_output_stmts += out_count

            if in_count > 0 and out_count < in_count:
                output_ref = str(output_file.relative_to(self.output_dir)
                                 if self.output_dir.exists() else output_file.name)
                issues.append(self._issue(
                    'medium', 'statement_count_mismatch',
                    f"Statement count: input={in_count}, output={out_count} "
                    f"({in_count - out_count} potentially missing)",
                    source_file=str(input_file.name), output_file=output_ref,
                ))

        if total_input_stmts > 0:
            rate = min(1.0, total_output_stmts / total_input_stmts)
        else:
            rate = 1.0

        self._metrics['statement_coverage'] = rate
        return issues, rate

    # ------------------------------------------------------------------
    # Core validation
    # ------------------------------------------------------------------

    def _collect_output_files(self) -> List[Tuple[Path, str]]:
        """Collect all output SQL files with their type classification.

        Scans both output/sql/ (Workstream 1) and output/dbt_project/ (Workstream 2).
        Returns list of (file_path, file_type) tuples.
        """
        files: List[Tuple[Path, str]] = []

        # Workstream 1: output/sql/
        if self.sql_dir.exists():
            for sql_file in sorted(self.sql_dir.rglob('*.sql')):
                rel = sql_file.relative_to(self.sql_dir)
                file_type = rel.parts[0] if len(rel.parts) > 1 else 'other'
                files.append((sql_file, file_type))

        # Workstream 2: output/dbt_project/
        dbt_dir = self.output_dir / 'dbt_project'
        if dbt_dir.exists():
            for sql_file in sorted(dbt_dir.rglob('*.sql')):
                rel = sql_file.relative_to(dbt_dir)
                # Classify dbt files: macros, models, snapshots, etc.
                dbt_type = rel.parts[0] if len(rel.parts) > 1 else 'dbt'
                files.append((sql_file, f'dbt_{dbt_type}'))

        return files

    def validate(self) -> List[Dict[str, str]]:
        """Run all validation checks on output files (deterministic, regex-based).

        Includes original checks plus VAL-01 through VAL-06 enhancements:
        - VAL-01: Function translation verification
        - VAL-02: Cast conversion completeness
        - VAL-03: Data type mapping in non-DDL files
        - VAL-04: Date format token verification
        - VAL-05: Weighted accuracy (calculated in build_report)
        - VAL-06: Statement-level coverage
        """
        issues: List[Dict[str, str]] = []

        all_output = self._collect_output_files()
        if not all_output:
            issues.append(self._issue(
                'high', 'no_output',
                'No SQL files found in output directory',
                output_file=str(self.output_dir),
            ))
            return issues

        # DDL completeness: every source table should have an output file
        issues.extend(self._check_ddl_completeness())

        # Per-file checks (original: residual, traceability, type-specific)
        for sql_file, file_type in all_output:
            issues.extend(self._validate_file(sql_file, file_type))

        # --- VAL-01: Function translation verification ---
        func_issues, _ = self._check_function_translation()
        issues.extend(func_issues)

        # --- VAL-02: Cast conversion completeness ---
        cast_issues, _ = self._check_cast_conversion()
        issues.extend(cast_issues)

        # --- VAL-03: Data type mapping in non-DDL files ---
        type_issues, _ = self._check_non_ddl_type_mapping()
        issues.extend(type_issues)

        # --- VAL-04: Date format token verification ---
        date_issues = self._check_date_format_tokens()
        issues.extend(date_issues)

        # --- VAL-06: Statement-level coverage ---
        stmt_issues, _ = self._check_statement_coverage()
        issues.extend(stmt_issues)

        # Calculate residual-free rate for VAL-05
        residual_issues = [i for i in issues if i['category'] == 'residual_redshift']
        total_files = len(all_output)
        files_with_residual = len({i.get('output_file', '') for i in residual_issues})
        self._metrics['residual_free_rate'] = (
            (total_files - files_with_residual) / total_files if total_files > 0 else 1.0
        )

        return issues

    def _check_ddl_completeness(self) -> List[Dict[str, str]]:
        """Check that every source table has a corresponding DDL output."""
        issues: List[Dict[str, str]] = []
        ddl_dir = self.sql_dir / 'ddl'
        if not ddl_dir.exists():
            if self.source_tables:
                issues.append(self._issue(
                    'high', 'missing_directory',
                    f'DDL output directory missing but {len(self.source_tables)} source tables found',
                    output_file=str(ddl_dir),
                ))
            return issues

        output_names = {f.stem for f in ddl_dir.glob('*.sql')}
        for table_name, info in self.source_tables.items():
            if table_name not in output_names:
                issues.append(self._issue(
                    'high', 'missing_output',
                    f"Source table '{table_name}' has no output DDL file",
                    source_file=f"inputs/sql/{info['source_file']}",
                    output_file=f"output/sql/ddl/{table_name}.sql",
                ))
        return issues

    def _validate_file(self, sql_file: Path, file_type: str) -> List[Dict[str, str]]:
        """Validate a single output SQL file."""
        issues: List[Dict[str, str]] = []
        content = sql_file.read_text(encoding='utf-8')
        output_ref = str(sql_file.relative_to(self.output_dir))

        # Detect source file from header comments
        source_ref = self._extract_source_ref(content)

        # 1. Residual Redshift syntax (all file types)
        issues.extend(self._check_residual_redshift(content, output_ref, source_ref))

        # 2. Traceability comments (all file types)
        issues.extend(self._check_traceability(content, output_ref, source_ref))

        # 3. Type-specific checks
        if file_type == 'ddl':
            issues.extend(self._check_ddl_constructs(content, output_ref, source_ref))
            issues.extend(self._check_ddl_columns(content, sql_file.stem, output_ref, source_ref))
        elif file_type == 'views' or file_type == 'materialized_views':
            issues.extend(self._check_view_constructs(content, output_ref, source_ref, file_type))
        elif file_type == 'stored_procedures':
            issues.extend(self._check_procedure_constructs(content, output_ref, source_ref))
        elif file_type == 'dml':
            issues.extend(self._check_dml_constructs(content, output_ref, source_ref))

        return issues

    @staticmethod
    def _extract_source_ref(content: str) -> str:
        """Extract source file reference from header comments (SQL or Jinja style)."""
        for line in content.split('\n')[:10]:
            m = re.search(r'-- Source:\s*(\S+)', line)
            if m:
                return m.group(1)
            m = re.search(r'\{#\s*Source:\s*(\S+)', line)
            if m:
                return m.group(1)
            m = re.search(r'converted from:\s*(\S+)', line)
            if m:
                return m.group(1)
        return 'unknown'

    # ------------------------------------------------------------------
    # Residual Redshift check (all types)
    # ------------------------------------------------------------------

    def _check_residual_redshift(
        self, content: str, output_ref: str, source_ref: str
    ) -> List[Dict[str, str]]:
        """Check for Redshift-specific syntax on non-comment lines."""
        issues: List[Dict[str, str]] = []
        seen_labels = set()
        for line_num, line in enumerate(content.split('\n'), 1):
            stripped = line.strip()
            if stripped.startswith('--') or stripped.startswith('/*') or stripped.startswith('{#'):
                continue
            for pattern, label in REDSHIFT_RESIDUAL_PATTERNS:
                if label not in seen_labels and pattern.search(stripped):
                    issues.append(self._issue(
                        'high', 'residual_redshift',
                        f"Residual Redshift syntax: {label} (line {line_num})",
                        source_file=source_ref, output_file=output_ref,
                    ))
                    seen_labels.add(label)
        return issues

    # ------------------------------------------------------------------
    # Traceability check (all types)
    # ------------------------------------------------------------------

    def _check_traceability(
        self, content: str, output_ref: str, source_ref: str
    ) -> List[Dict[str, str]]:
        """Check for required traceability comments."""
        issues: List[Dict[str, str]] = []
        has_source = ('-- Source:' in content or 'converted from:' in content
                     or '{# Source:' in content)
        has_timestamp = ('-- Converted' in content or '-- Converted on:' in content
                         or '-- Converted from Redshift' in content
                         or '{# Converted' in content)
        has_rules = ('-- Conversion rules:' in content or 'conversion_guide' in content
                     or '{# Conversion' in content)

        if not has_source:
            issues.append(self._issue(
                'medium', 'missing_traceability',
                'Missing source file reference comment',
                source_file=source_ref, output_file=output_ref,
            ))
        if not has_timestamp:
            issues.append(self._issue(
                'medium', 'missing_traceability',
                'Missing conversion timestamp comment',
                source_file=source_ref, output_file=output_ref,
            ))
        if not has_rules:
            issues.append(self._issue(
                'low', 'missing_traceability',
                'Missing conversion rules reference',
                source_file=source_ref, output_file=output_ref,
            ))
        return issues

    # ------------------------------------------------------------------
    # DDL-specific checks
    # ------------------------------------------------------------------

    def _check_ddl_constructs(
        self, content: str, output_ref: str, source_ref: str
    ) -> List[Dict[str, str]]:
        """Check USING DELTA, IF NOT EXISTS for DDL files."""
        issues: List[Dict[str, str]] = []
        # Skip these checks for TEMPORARY VIEW (converted from TEMP TABLE)
        if 'TEMPORARY VIEW' in content.upper():
            return issues
        if 'USING DELTA' not in content:
            issues.append(self._issue(
                'high', 'missing_construct',
                'Missing USING DELTA clause',
                source_file=source_ref, output_file=output_ref,
            ))
        if 'IF NOT EXISTS' not in content.upper():
            issues.append(self._issue(
                'high', 'missing_construct',
                'Missing IF NOT EXISTS in CREATE TABLE',
                source_file=source_ref, output_file=output_ref,
            ))
        return issues

    def _check_ddl_columns(
        self, content: str, table_name: str, output_ref: str, source_ref: str
    ) -> List[Dict[str, str]]:
        """Column-level validation for DDL files."""
        issues: List[Dict[str, str]] = []
        source_info = self.source_tables.get(table_name)
        if not source_info:
            return issues

        source_cols = source_info['columns']
        output_cols = self._parse_output_columns(content)

        source_names = {c['name'].lower() for c in source_cols}
        output_names = {c['name'].lower() for c in output_cols}

        for name in source_names - output_names:
            issues.append(self._issue(
                'high', 'missing_column',
                f"Column '{name}' in source but missing in output",
                source_file=source_ref, output_file=output_ref,
            ))

        # Type mapping checks
        source_by_name = {c['name'].lower(): c for c in source_cols}
        output_by_name = {c['name'].lower(): c for c in output_cols}

        for col_name in source_names & output_names:
            src_col = source_by_name[col_name]
            out_col = output_by_name[col_name]

            expected = self._expected_output_type(src_col['type'])
            if expected and expected.upper() not in out_col['type'].upper():
                issues.append(self._issue(
                    'high', 'incorrect_type_mapping',
                    f"Column '{col_name}': expected {expected} (from {src_col['type']}), got {out_col['type']}",
                    source_file=source_ref, output_file=output_ref,
                ))

            # NOT NULL preserved
            src_nn = 'NOT NULL' in src_col.get('constraints', '').upper()
            out_nn = 'NOT NULL' in out_col.get('constraints', '').upper()
            if src_nn and not out_nn:
                issues.append(self._issue(
                    'high', 'lost_constraint',
                    f"NOT NULL on column '{col_name}' lost in output",
                    source_file=source_ref, output_file=output_ref,
                ))

        return issues

    def _parse_output_columns(self, content: str) -> List[Dict[str, str]]:
        """Parse column definitions from output DDL content."""
        match = re.search(
            r'CREATE\s+TABLE\s+.*?\(\s*\n(.*?)\n\s*\)',
            content, re.IGNORECASE | re.DOTALL,
        )
        if not match:
            return []
        block = match.group(1)
        columns: List[Dict[str, str]] = []
        for line in block.split('\n'):
            line = line.strip().rstrip(',')
            if not line or line.startswith('--'):
                continue
            parts = line.split()
            if len(parts) >= 2:
                name = parts[0]
                dtype = parts[1]
                if dtype.upper().startswith('DECIMAL') and '(' not in dtype and len(parts) > 2:
                    dtype = dtype + parts[2]
                constraints = ' '.join(parts[2:]) if len(parts) > 2 else ''
                columns.append({'name': name, 'type': dtype, 'constraints': constraints})
        return columns

    @staticmethod
    def _expected_output_type(source_type: str) -> Optional[str]:
        """Determine expected Databricks type for a Redshift type."""
        for pattern, expected in EXPECTED_TYPE_MAP:
            if pattern.search(source_type):
                return expected
        return None

    # ------------------------------------------------------------------
    # View-specific checks
    # ------------------------------------------------------------------

    def _check_view_constructs(
        self, content: str, output_ref: str, source_ref: str, file_type: str
    ) -> List[Dict[str, str]]:
        """Check view-specific constructs."""
        issues: List[Dict[str, str]] = []
        if 'OR REPLACE' not in content.upper():
            issues.append(self._issue(
                'medium', 'missing_construct',
                'Missing OR REPLACE in view definition',
                source_file=source_ref, output_file=output_ref,
            ))
        if file_type == 'materialized_views' and 'MATERIALIZED VIEW' not in content.upper():
            issues.append(self._issue(
                'high', 'incorrect_construct',
                'File in materialized_views/ but no MATERIALIZED VIEW keyword found',
                source_file=source_ref, output_file=output_ref,
            ))
        # Check for residual DISTKEY/SORTKEY before AS (should have been removed)
        header_match = re.search(r'(CREATE\s+.*?VIEW\s+.*?)\bAS\b', content, re.IGNORECASE | re.DOTALL)
        if header_match:
            header = header_match.group(1)
            if re.search(r'\b(?:DISTKEY|SORTKEY|DISTSTYLE)\b', header, re.IGNORECASE):
                issues.append(self._issue(
                    'high', 'residual_redshift',
                    'DISTKEY/SORTKEY/DISTSTYLE found in view header (should be removed)',
                    source_file=source_ref, output_file=output_ref,
                ))
        return issues

    # ------------------------------------------------------------------
    # Procedure-specific checks
    # ------------------------------------------------------------------

    def _check_procedure_constructs(
        self, content: str, output_ref: str, source_ref: str
    ) -> List[Dict[str, str]]:
        """Check procedure-specific constructs."""
        issues: List[Dict[str, str]] = []
        if 'OR REPLACE' not in content.upper():
            issues.append(self._issue(
                'medium', 'missing_construct',
                'Missing OR REPLACE in procedure definition',
                source_file=source_ref, output_file=output_ref,
            ))
        # Check for PL/pgSQL constructs that should have been converted
        for pat, label in [
            (r'\bEXECUTE\s+(?!IMMEDIATE)', 'EXECUTE without IMMEDIATE'),
            (r'\b\w+\s*:=\s*', 'PL/pgSQL assignment (:=)'),
            (r'\bFOR\s+\w+\s+IN\s+.*\s+LOOP\b', 'FOR...IN...LOOP (unconverted)'),
            (r'\bWHILE\s+.*\s+LOOP\b', 'WHILE...LOOP (should be WHILE...DO)'),
            (r'\bEND\s+LOOP\b', 'END LOOP (should be END FOR/END WHILE)'),
            (r'\bELSIF\b', 'ELSIF (should be ELSEIF)'),
            (r'\bEXIT\s+WHEN\b', 'EXIT WHEN (should be LEAVE WHEN)'),
            (r'\bCONTINUE\s+WHEN\b', 'CONTINUE WHEN (should be IF...ITERATE)'),
            (r'\bRAISE\s+(?:NOTICE|EXCEPTION|INFO)\b', 'RAISE (should be SIGNAL)'),
            (r'\bLANGUAGE\s+plpgsql\b', 'LANGUAGE plpgsql (should be LANGUAGE SQL)'),
        ]:
            for line in content.split('\n'):
                if line.strip().startswith('--'):
                    continue
                if re.search(pat, line, re.IGNORECASE):
                    issues.append(self._issue(
                        'medium', 'unconverted_plpgsql',
                        f'Unconverted PL/pgSQL construct: {label}',
                        source_file=source_ref, output_file=output_ref,
                    ))
                    break
        return issues

    # ------------------------------------------------------------------
    # DML-specific checks
    # ------------------------------------------------------------------

    def _check_dml_constructs(
        self, content: str, output_ref: str, source_ref: str
    ) -> List[Dict[str, str]]:
        """Check DML-specific constructs."""
        issues: List[Dict[str, str]] = []
        # Check for unconverted COPY (should be COPY INTO)
        for line in content.split('\n'):
            if line.strip().startswith('--'):
                continue
            if re.search(r'\bCOPY\s+\w+\s+FROM\b', line, re.IGNORECASE):
                issues.append(self._issue(
                    'high', 'unconverted_dml',
                    'Unconverted COPY (should be COPY INTO)',
                    source_file=source_ref, output_file=output_ref,
                ))
                break
        # Check END TRANSACTION not converted
        for line in content.split('\n'):
            if line.strip().startswith('--'):
                continue
            if re.search(r'\bEND\s+TRANSACTION\b', line, re.IGNORECASE):
                issues.append(self._issue(
                    'medium', 'unconverted_dml',
                    'Unconverted END TRANSACTION (should be COMMIT)',
                    source_file=source_ref, output_file=output_ref,
                ))
                break
        return issues

    # ------------------------------------------------------------------
    # Issue builder
    # ------------------------------------------------------------------

    def _issue(
        self,
        severity: str,
        category: str,
        description: str,
        source_file: str = '',
        output_file: str = '',
    ) -> Dict[str, str]:
        """Create a structured issue dict."""
        self._issue_counter += 1
        return {
            'id': f'V-{self._issue_counter:03d}',
            'severity': severity,
            'category': category,
            'description': description,
            'source_file': source_file,
            'output_file': output_file,
        }

    # ------------------------------------------------------------------
    # Report
    # ------------------------------------------------------------------

    def build_report(self, issues: List[Dict[str, str]]) -> Dict[str, Any]:
        """Build a structured validation report.

        Includes VAL-05 weighted accuracy metric alongside the original accuracy.
        """
        total_checks = self._count_total_checks()
        high_issues = len([i for i in issues if i['severity'] == 'high'])
        passed = max(total_checks - high_issues, 0)
        accuracy = round((passed / total_checks * 100), 1) if total_checks > 0 else 100.0
        passed_checks = self._list_passed_checks(issues)

        # VAL-05: Weighted accuracy metric
        func_rate = self._metrics.get('function_translation_rate', 1.0)
        stmt_cov = self._metrics.get('statement_coverage', 1.0)
        cast_rate = self._metrics.get('cast_conversion_rate', 1.0)
        dtype_acc = self._metrics.get('data_type_mapping_accuracy', 1.0)
        residual_rate = self._metrics.get('residual_free_rate', 1.0)

        weighted_accuracy = round(
            (0.30 * func_rate +
             0.25 * stmt_cov +
             0.20 * cast_rate +
             0.15 * dtype_acc +
             0.10 * residual_rate) * 100, 1
        )

        return {
            'validation_report': {
                'timestamp': get_timestamp(),
                'validator': 'OutputValidator',
                'input_dir': str(self.input_dir),
                'output_dir': str(self.output_dir),
                'overall_accuracy': accuracy,
                'weighted_accuracy': weighted_accuracy,
                'total_checks': total_checks,
                'passed_check_count': passed,
                'failed_check_count': high_issues,
                'total_issues': len(issues),
                'issues_by_severity': {
                    'high': len([i for i in issues if i['severity'] == 'high']),
                    'medium': len([i for i in issues if i['severity'] == 'medium']),
                    'low': len([i for i in issues if i['severity'] == 'low']),
                },
                'enhancement_metrics': {
                    'function_translation_rate': round(func_rate * 100, 1),
                    'statement_coverage': round(stmt_cov * 100, 1),
                    'cast_conversion_rate': round(cast_rate * 100, 1),
                    'data_type_mapping_accuracy': round(dtype_acc * 100, 1),
                    'residual_free_rate': round(residual_rate * 100, 1),
                },
                'issues': issues,
                'passed_checks': passed_checks,
            }
        }

    def _count_total_checks(self) -> int:
        """Count total possible checks."""
        count = 0
        all_output = self._collect_output_files()
        # Completeness: 1 per source table
        count += len(self.source_tables)
        # Per file: residual scan, 3 traceability, type-specific (2-3)
        count += len(all_output) * 6
        # Per DDL column: type mapping + NOT NULL
        for info in self.source_tables.values():
            count += len(info['columns']) * 2
        return max(count, 1)

    def _list_passed_checks(self, issues: List[Dict[str, str]]) -> List[str]:
        """List checks that passed."""
        passed: List[str] = []
        categories = {i['category'] for i in issues}

        if 'missing_output' not in categories:
            passed.append(f"All {len(self.source_tables)} source tables have output DDL files")
        if 'missing_construct' not in categories:
            passed.append("All DDL files have USING DELTA and IF NOT EXISTS")
        if 'residual_redshift' not in categories:
            passed.append("No residual Redshift syntax in output (non-comment lines)")
        if 'missing_traceability' not in categories:
            passed.append("All output files have traceability comments")
        if 'missing_column' not in categories:
            passed.append("All source columns present in DDL output")
        if 'incorrect_type_mapping' not in categories:
            passed.append("All data type mappings are correct")
        if 'lost_constraint' not in categories:
            passed.append("All NOT NULL constraints preserved")
        if 'unconverted_plpgsql' not in categories:
            passed.append("No unconverted PL/pgSQL constructs in procedures")
        if 'unconverted_dml' not in categories:
            passed.append("No unconverted DML constructs")

        # VAL-01: Function translation
        if 'untranslated_function' not in categories:
            passed.append("All Redshift functions translated to Databricks equivalents (VAL-01)")
        # VAL-02: Cast conversion
        if 'residual_cast_operator' not in categories:
            passed.append("All :: cast operators converted to CAST() (VAL-02)")
        # VAL-03: Data type mapping in CAST
        if 'redshift_type_in_cast' not in categories:
            passed.append("No Redshift-only types in CAST expressions (VAL-03)")
        # VAL-04: Date format tokens
        if 'unconverted_date_token' not in categories:
            passed.append("All date format tokens converted to Databricks format (VAL-04)")
        # VAL-06: Statement coverage
        if 'statement_count_mismatch' not in categories and 'missing_output_file' not in categories:
            passed.append("Statement counts match between input and output (VAL-06)")

        return passed

    def save_report(self, report: Dict[str, Any]) -> Path:
        """Save validation report to thoughts/logs/agentic/."""
        self.log_dir.mkdir(parents=True, exist_ok=True)
        timestamp_str = get_timestamp().replace(' ', '_').replace(':', '')
        filename = f"validation_{timestamp_str}.yaml"
        report_path = self.log_dir / filename
        save_yaml(report, report_path)
        self.logger.info(f"Validation report saved: {report_path}")
        return report_path


def run_validation(
    input_dir: str = 'inputs/sql',
    output_dir: str = 'output',
    dry_run: bool = False,
) -> Tuple[Dict[str, Any], Path]:
    """Run validation and return (report, report_path)."""
    validator = OutputValidator(input_dir=input_dir, output_dir=output_dir)

    if dry_run:
        output_files = [f for f, _ in validator._collect_output_files()]
        print("=== DRY RUN ===")
        print(f"Source tables found: {len(validator.source_tables)}")
        print(f"Output SQL files found: {len(output_files)}")
        for f in output_files:
            rel = f.relative_to(validator.output_dir)
            print(f"  - {rel}")
        return {}, Path('.')

    issues = validator.validate()
    report = validator.build_report(issues)
    report_path = validator.save_report(report)

    # Console summary
    vr = report['validation_report']
    em = vr.get('enhancement_metrics', {})
    print(f"\n{'='*60}")
    print(f"  VALIDATION REPORT")
    print(f"{'='*60}")
    print(f"  Accuracy (check-based):  {vr['overall_accuracy']}%")
    print(f"  Accuracy (weighted):     {vr.get('weighted_accuracy', 'N/A')}%")
    print(f"  Total checks:            {vr['total_checks']}")
    print(f"  Passed:                  {vr['passed_check_count']}")
    print(f"  Failed (high):           {vr['failed_check_count']}")
    print(f"  Total issues:            {vr['total_issues']} "
          f"(high={vr['issues_by_severity']['high']}, "
          f"medium={vr['issues_by_severity']['medium']}, "
          f"low={vr['issues_by_severity']['low']})")
    if em:
        print(f"\n  Enhancement Metrics (VAL-01..06):")
        print(f"    Function translation:    {em.get('function_translation_rate', 'N/A')}%")
        print(f"    Statement coverage:      {em.get('statement_coverage', 'N/A')}%")
        print(f"    Cast conversion:         {em.get('cast_conversion_rate', 'N/A')}%")
        print(f"    Data type mapping:       {em.get('data_type_mapping_accuracy', 'N/A')}%")
        print(f"    Residual-free rate:      {em.get('residual_free_rate', 'N/A')}%")
    print(f"{'='*60}")

    if vr['passed_checks']:
        print("\n  Passed checks:")
        for pc in vr['passed_checks']:
            print(f"    [PASS] {pc}")

    if vr['issues']:
        print(f"\n  Issues:")
        for issue in vr['issues']:
            print(f"    [{issue['severity'].upper()}] {issue['id']}: {issue['description']}")
            if issue['output_file']:
                print(f"      file: {issue['output_file']}")

    print(f"\n  Report saved to: {report_path}")
    return report, report_path


def main() -> None:
    """Entry point."""
    parser = argparse.ArgumentParser(
        description='Validate Databricks SQL output against Redshift source'
    )
    parser.add_argument('--input', '-i', default='inputs/sql', help='Input directory')
    parser.add_argument('--output', '-o', default='output', help='Output directory')
    parser.add_argument('--dry-run', action='store_true', help='Preview only')
    args = parser.parse_args()

    run_validation(input_dir=args.input, output_dir=args.output, dry_run=args.dry_run)


if __name__ == '__main__':
    main()
