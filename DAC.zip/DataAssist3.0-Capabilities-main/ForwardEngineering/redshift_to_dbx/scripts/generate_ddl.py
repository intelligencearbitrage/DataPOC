"""
DDL Converter - Converts Redshift CREATE TABLE DDLs to Databricks SQL.

Parses input SQL files from inputs/sql/, applies data type mapping and DDL
construct conversion per knowledgebase/redshift_to_databricks_conversion_guide.pdf,
and writes one Databricks-compatible DDL file per table to output/sql/ddl/.

Handles: CREATE TABLE, ALTER TABLE, DROP TABLE, CREATE TABLE ... (LIKE ...),
         CTAS patterns, PRIMARY KEY/UNIQUE constraints.

Usage:
    python scripts/generate_ddl.py
"""

import re
import sys
from pathlib import Path
from typing import Any, Dict, List, Tuple

# Ensure scripts/ is on the Python path
SCRIPTS_DIR = Path(__file__).resolve().parent
sys.path.insert(0, str(SCRIPTS_DIR))

from base_parser import BaseParser
from base_generator import BaseGenerator
from sql_functions import (
    DATA_TYPE_MAP,
    apply_type_mappings,
    apply_construct_removals,
    full_sql_convert,
)
from utils import get_timestamp


class DDLParser(BaseParser):
    """Parses Redshift SQL files to extract DDL statements."""

    def __init__(self, input_dir: str = 'inputs/sql', output_dir: str = 'output') -> None:
        super().__init__(input_dir=input_dir, output_dir=output_dir)

    def discover_files(self) -> List[Path]:
        """Find all .sql files in inputs/sql/."""
        return sorted(self.input_dir.glob('*.sql'))

    def parse_file(self, file_path: Path) -> Dict[str, Any]:
        """Parse a SQL file into individual DDL statements."""
        content = file_path.read_text(encoding='utf-8')
        tables = self._extract_tables(content, file_path.name)
        alter_stmts = self._extract_alter_tables(content, file_path.name)
        drop_stmts = self._extract_drop_tables(content, file_path.name)
        truncate_stmts = self._extract_truncate_tables(content, file_path.name)
        vacuum_stmts = self._extract_vacuum_analyze(content, file_path.name)
        comment_stmts = self._extract_comment_on(content, file_path.name)
        create_funcs = self._extract_create_functions(content, file_path.name)
        create_schemas = self._extract_create_schemas(content, file_path.name)
        return {
            'source_file': file_path.name,
            'tables': tables,
            'alter_stmts': alter_stmts,
            'drop_stmts': drop_stmts,
            'truncate_stmts': truncate_stmts,
            'vacuum_stmts': vacuum_stmts,
            'comment_stmts': comment_stmts,
            'create_funcs': create_funcs,
            'create_schemas': create_schemas,
        }

    def _extract_tables(
        self, sql_content: str, source_file: str
    ) -> List[Dict[str, Any]]:
        """Extract individual CREATE TABLE statements from SQL content."""
        tables = []

        # Match CREATE TABLE ... (LIKE source)
        like_pattern = re.compile(
            r'CREATE\s+(?:OR\s+REPLACE\s+)?TABLE\s+(?:IF\s+NOT\s+EXISTS\s+)?([\w.]+)\s*\(\s*LIKE\s+([\w.]+)\s*\)\s*;',
            re.IGNORECASE | re.DOTALL,
        )
        for match in like_pattern.finditer(sql_content):
            full_name = match.group(1).strip()
            source_table = match.group(2).strip()
            parts = full_name.split('.')
            schema = parts[0] if len(parts) > 1 else ''
            table_name = parts[-1]
            tables.append({
                'schema': schema,
                'table_name': table_name,
                'full_name': full_name,
                'columns': [],
                'conversions': [{'column': 'N/A', 'from_type': 'LIKE', 'to_type': 'CTAS',
                                 'comment': f'CREATE TABLE ... (LIKE {source_table}) not directly supported'}],
                'source_file': source_file,
                'is_like': True,
                'like_source': source_table,
            })

        # Find CREATE TABLE statements using balanced parenthesis matching
        # This handles nested parens in IDENTITY(1,1), NUMERIC(38,0), etc.
        # Also handles CREATE OR REPLACE TABLE and CREATE TABLE IF NOT EXISTS
        create_pattern = re.compile(
            r'CREATE\s+(?:OR\s+REPLACE\s+)?(?:(?:TEMP|TEMPORARY|EXTERNAL|LOCAL|GLOBAL)\s+)*TABLE\s+(?:IF\s+NOT\s+EXISTS\s+)?([\w.#]+)\s*\(',
            re.IGNORECASE,
        )

        for match in create_pattern.finditer(sql_content):
            full_name = match.group(1).strip()
            # Strip Redshift # prefix from temp table names
            if full_name.startswith('#'):
                full_name = full_name.lstrip('#')
            # Detect if this is a TEMP/TEMPORARY table
            is_temp = bool(re.search(r'\b(?:TEMP|TEMPORARY)\b', match.group(0), re.IGNORECASE))
            # Detect if this is an EXTERNAL table (Spectrum)
            is_external = bool(re.search(r'\bEXTERNAL\b', match.group(0), re.IGNORECASE))

            # Skip if this was already matched as a LIKE pattern
            if any(t['full_name'] == full_name and t.get('is_like') for t in tables):
                continue

            # Walk forward from the opening paren to find the matching close paren
            open_pos = match.end() - 1  # position of '('
            depth = 1
            i = open_pos + 1
            in_single = False
            in_double = False
            while i < len(sql_content) and depth > 0:
                ch = sql_content[i]
                if ch == "'" and not in_double:
                    in_single = not in_single
                elif ch == '"' and not in_single:
                    in_double = not in_double
                elif not in_single and not in_double:
                    if ch == '(':
                        depth += 1
                    elif ch == ')':
                        depth -= 1
                i += 1

            if depth != 0:
                continue  # Unbalanced — skip

            close_pos = i - 1  # position of matching ')'
            columns_block = sql_content[open_pos + 1:close_pos].strip()

            # Check that a semicolon follows (possibly after DISTKEY/SORTKEY/ENCODE)
            after_paren = sql_content[close_pos + 1:]
            semi_match = re.match(r'[^;]*;', after_paren, re.DOTALL)
            if not semi_match:
                continue  # No semicolon found — not a complete statement

            parts = full_name.split('.')
            schema = parts[0] if len(parts) > 1 else ''
            table_name = parts[-1]

            columns = self._parse_columns(columns_block)
            conversions = self._identify_conversions(columns)

            # Extract DISTKEY/SORTKEY/DISTSTYLE from original statement for advisory
            full_stmt = match.group(0) + columns_block + ')' + (semi_match.group(0) if semi_match else '')
            distkey_cols = re.findall(r'DISTKEY\s*\(([^)]+)\)', full_stmt, re.IGNORECASE)
            sortkey_cols = re.findall(r'(?:COMPOUND\s+|INTERLEAVED\s+)?SORTKEY\s*\(([^)]+)\)', full_stmt, re.IGNORECASE)
            diststyle = re.findall(r'DISTSTYLE\s+(\w+)', full_stmt, re.IGNORECASE)

            tables.append({
                'schema': schema,
                'table_name': table_name,
                'full_name': full_name,
                'columns': columns,
                'conversions': conversions,
                'source_file': source_file,
                'is_temp': is_temp,
                'is_external': is_external,
                'distkey_cols': distkey_cols[0].strip() if distkey_cols else '',
                'sortkey_cols': sortkey_cols[0].strip() if sortkey_cols else '',
                'diststyle': diststyle[0].strip().upper() if diststyle else '',
            })

        return tables

    def _extract_alter_tables(
        self, sql_content: str, source_file: str
    ) -> List[Dict[str, Any]]:
        """Extract ALTER TABLE statements."""
        stmts = []
        pattern = re.compile(
            r'(ALTER\s+TABLE\s+[\w.]+\s+.+?);',
            re.IGNORECASE | re.DOTALL,
        )
        for match in pattern.finditer(sql_content):
            stmt = match.group(1).strip()
            stmts.append({
                'original_sql': stmt,
                'source_file': source_file,
            })
        return stmts

    def _extract_comment_on(
        self, sql_content: str, source_file: str
    ) -> List[Dict[str, Any]]:
        """Extract COMMENT ON statements."""
        stmts = []
        pattern = re.compile(
            r"(COMMENT\s+ON\s+(?:TABLE|COLUMN|VIEW|DATABASE|SCHEMA)\s+[\w.]+\s+IS\s+'[^']*')\s*;",
            re.IGNORECASE,
        )
        for match in pattern.finditer(sql_content):
            stmts.append({
                'original_sql': match.group(1).strip(),
                'source_file': source_file,
            })
        return stmts

    def _extract_create_functions(
        self, sql_content: str, source_file: str
    ) -> List[Dict[str, Any]]:
        """Extract CREATE FUNCTION statements (SQL and Python UDFs)."""
        stmts = []
        pattern = re.compile(
            r'(CREATE\s+(?:OR\s+REPLACE\s+)?FUNCTION\s+[\w.]+\s*\([^)]*\)\s*RETURNS\s+\w+.*?LANGUAGE\s+(?:sql|plpythonu))\s*;',
            re.IGNORECASE | re.DOTALL,
        )
        for match in pattern.finditer(sql_content):
            stmts.append({
                'original_sql': match.group(1).strip(),
                'source_file': source_file,
            })
        return stmts

    def _extract_create_schemas(
        self, sql_content: str, source_file: str
    ) -> List[Dict[str, Any]]:
        """Extract CREATE SCHEMA and CREATE EXTERNAL SCHEMA statements."""
        stmts = []
        pattern = re.compile(
            r'(CREATE\s+(?:EXTERNAL\s+)?SCHEMA\s+.+?)\s*;',
            re.IGNORECASE | re.DOTALL,
        )
        for match in pattern.finditer(sql_content):
            stmts.append({
                'original_sql': match.group(1).strip(),
                'source_file': source_file,
            })
        return stmts

    def _extract_drop_tables(
        self, sql_content: str, source_file: str
    ) -> List[Dict[str, Any]]:
        """Extract DROP TABLE statements."""
        stmts = []
        pattern = re.compile(
            r'(DROP\s+TABLE\s+.+?);',
            re.IGNORECASE | re.DOTALL,
        )
        for match in pattern.finditer(sql_content):
            stmt = match.group(1).strip()
            stmts.append({
                'original_sql': stmt,
                'source_file': source_file,
            })
        return stmts

    def _extract_truncate_tables(
        self, sql_content: str, source_file: str
    ) -> List[Dict[str, Any]]:
        """Extract TRUNCATE TABLE statements."""
        stmts = []
        pattern = re.compile(
            r'(TRUNCATE\s+(?:TABLE\s+)?[\w.]+)\s*;',
            re.IGNORECASE,
        )
        for match in pattern.finditer(sql_content):
            stmts.append({
                'original_sql': match.group(1).strip(),
                'source_file': source_file,
            })
        return stmts

    def _extract_vacuum_analyze(
        self, sql_content: str, source_file: str
    ) -> List[Dict[str, Any]]:
        """Extract VACUUM and ANALYZE statements (Redshift-specific)."""
        stmts = []
        pattern = re.compile(
            r'((?:VACUUM|ANALYZE)\s+.+?)\s*;',
            re.IGNORECASE | re.DOTALL,
        )
        for match in pattern.finditer(sql_content):
            stmts.append({
                'original_sql': match.group(1).strip(),
                'source_file': source_file,
            })
        return stmts

    def _parse_columns(self, columns_block: str) -> List[Dict[str, str]]:
        """Parse column definitions from the columns block."""
        columns = []
        # Split by comma, but handle commas inside parentheses
        depth = 0
        current = []
        for char in columns_block:
            if char == '(':
                depth += 1
                current.append(char)
            elif char == ')':
                depth -= 1
                current.append(char)
            elif char == ',' and depth == 0:
                col_def = ''.join(current).strip()
                if col_def:
                    columns.append(self._parse_column_def(col_def))
                current = []
            else:
                current.append(char)
        # Last column
        col_def = ''.join(current).strip()
        if col_def:
            columns.append(self._parse_column_def(col_def))

        return columns

    def _parse_column_def(self, col_def: str) -> Dict[str, str]:
        """Parse a single column definition into name, type, constraints."""
        col_def = col_def.strip()

        # Skip table-level constraints (PRIMARY KEY, UNIQUE, FOREIGN KEY, CONSTRAINT)
        if re.match(r'\s*(?:PRIMARY\s+KEY|UNIQUE|FOREIGN\s+KEY|CONSTRAINT)\b', col_def, re.IGNORECASE):
            return {
                'name': '',
                'original_type': '',
                'constraints': col_def,
                'is_table_constraint': True,
            }

        # Match: column_name type_with_optional_params optional_constraints
        match = re.match(
            r'(\w+)\s+'
            r'((?:timestamp\s+with(?:out)?\s+time\s+zone|character\s+varying'
            r'|double\s+precision|binary\s+varying'
            r'|\w+)(?:\s*\([^)]*\))?)'
            r'(.*)',
            col_def, re.IGNORECASE
        )
        if match:
            name = match.group(1).strip()
            data_type = match.group(2).strip()
            constraints = match.group(3).strip()
            return {
                'name': name,
                'original_type': data_type,
                'constraints': constraints,
            }
        return {'name': col_def, 'original_type': '', 'constraints': ''}

    def _identify_conversions(
        self, columns: List[Dict[str, str]]
    ) -> List[Dict[str, str]]:
        """Identify which columns need type or constraint conversion."""
        conversions = []
        for col in columns:
            if col.get('is_table_constraint'):
                continue
            orig = col['original_type']
            if not orig:
                continue
            converted, note = apply_type_mappings(orig)
            if note:
                conversions.append({
                    'column': col['name'],
                    'from_type': orig,
                    'to_type': converted,
                    'comment': note,
                })
            # Check constraints for construct conversions (IDENTITY, DEFAULT GETDATE, etc.)
            constraints = col.get('constraints', '')
            _, constraint_notes = apply_construct_removals(constraints)
            for cn in constraint_notes:
                conversions.append({
                    'column': col['name'],
                    'from_type': 'constraint',
                    'to_type': cn,
                    'comment': cn,
                })
        return conversions


class DDLGenerator(BaseGenerator):
    """Generates Databricks-compatible DDL files from parsed Redshift DDL."""

    def __init__(self, parsed_data: Dict[str, Any], output_dir: str = 'output', catalog: str = '') -> None:
        super().__init__(plans_dir='plans', output_dir=output_dir, catalog=catalog)
        self.parsed_data = parsed_data
        self.generated_files: List[Dict[str, str]] = []

    def generate(self) -> None:
        """Generate Databricks DDL files for all parsed tables."""
        timestamp = get_timestamp()

        for file_key, file_data in self.parsed_data.items():
            source_file = file_data.get('source_file', file_key)
            tables = file_data.get('tables', [])
            alter_stmts = file_data.get('alter_stmts', [])
            drop_stmts = file_data.get('drop_stmts', [])

            for table in tables:
                if table.get('is_like'):
                    ddl = self._generate_like_ddl(table, source_file, timestamp)
                else:
                    ddl = self._generate_table_ddl(table, source_file, timestamp)
                output_path = f"sql/ddl/{table['table_name']}.sql"
                self.save_output(ddl, output_path)
                self.generated_files.append({
                    'source_file': source_file,
                    'table_name': table['table_name'],
                    'schema': table['schema'],
                    'output_file': str(self.output_dir / output_path),
                    'conversions_applied': len(table.get('conversions', [])),
                })

            # Generate ALTER TABLE conversions
            if alter_stmts:
                alter_content = self._generate_alter_stmts(alter_stmts, source_file, timestamp)
                output_path = f"sql/ddl/{Path(source_file).stem}_alter.sql"
                self.save_output(alter_content, output_path)
                self.generated_files.append({
                    'source_file': source_file,
                    'table_name': f"{Path(source_file).stem}_alter",
                    'schema': '',
                    'output_file': str(self.output_dir / output_path),
                    'conversions_applied': len(alter_stmts),
                })

            # Generate DROP TABLE conversions
            if drop_stmts:
                drop_content = self._generate_drop_stmts(drop_stmts, source_file, timestamp)
                output_path = f"sql/ddl/{Path(source_file).stem}_drop.sql"
                self.save_output(drop_content, output_path)
                self.generated_files.append({
                    'source_file': source_file,
                    'table_name': f"{Path(source_file).stem}_drop",
                    'schema': '',
                    'output_file': str(self.output_dir / output_path),
                    'conversions_applied': len(drop_stmts),
                })

            # Generate TRUNCATE TABLE conversions
            truncate_stmts = file_data.get('truncate_stmts', [])
            if truncate_stmts:
                truncate_content = self._generate_truncate_stmts(truncate_stmts, source_file, timestamp)
                output_path = f"sql/ddl/{Path(source_file).stem}_truncate.sql"
                self.save_output(truncate_content, output_path)
                self.generated_files.append({
                    'source_file': source_file,
                    'table_name': f"{Path(source_file).stem}_truncate",
                    'schema': '',
                    'output_file': str(self.output_dir / output_path),
                    'conversions_applied': len(truncate_stmts),
                })

            # Generate VACUUM/ANALYZE conversions
            vacuum_stmts = file_data.get('vacuum_stmts', [])
            if vacuum_stmts:
                vacuum_content = self._generate_vacuum_stmts(vacuum_stmts, source_file, timestamp)
                output_path = f"sql/ddl/{Path(source_file).stem}_maintenance.sql"
                self.save_output(vacuum_content, output_path)
                self.generated_files.append({
                    'source_file': source_file,
                    'table_name': f"{Path(source_file).stem}_maintenance",
                    'schema': '',
                    'output_file': str(self.output_dir / output_path),
                    'conversions_applied': len(vacuum_stmts),
                })

            # Generate COMMENT ON conversions
            comment_stmts = file_data.get('comment_stmts', [])
            if comment_stmts:
                comment_content = self._generate_comment_stmts(comment_stmts, source_file, timestamp)
                output_path = f"sql/ddl/{Path(source_file).stem}_comments.sql"
                self.save_output(comment_content, output_path)
                self.generated_files.append({
                    'source_file': source_file,
                    'table_name': f"{Path(source_file).stem}_comments",
                    'schema': '',
                    'output_file': str(self.output_dir / output_path),
                    'conversions_applied': len(comment_stmts),
                })

            # Generate CREATE FUNCTION conversions
            create_funcs = file_data.get('create_funcs', [])
            if create_funcs:
                func_content = self._generate_function_stmts(create_funcs, source_file, timestamp)
                output_path = f"sql/ddl/{Path(source_file).stem}_functions.sql"
                self.save_output(func_content, output_path)
                self.generated_files.append({
                    'source_file': source_file,
                    'table_name': f"{Path(source_file).stem}_functions",
                    'schema': '',
                    'output_file': str(self.output_dir / output_path),
                    'conversions_applied': len(create_funcs),
                })

            # Generate CREATE SCHEMA conversions
            create_schemas = file_data.get('create_schemas', [])
            if create_schemas:
                schema_content = self._generate_schema_stmts(create_schemas, source_file, timestamp)
                output_path = f"sql/ddl/{Path(source_file).stem}_schemas.sql"
                self.save_output(schema_content, output_path)
                self.generated_files.append({
                    'source_file': source_file,
                    'table_name': f"{Path(source_file).stem}_schemas",
                    'schema': '',
                    'output_file': str(self.output_dir / output_path),
                    'conversions_applied': len(create_schemas),
                })

        self.logger.info(
            f"Generated {len(self.generated_files)} DDL file(s)"
        )

    def _generate_table_ddl(
        self,
        table: Dict[str, Any],
        source_file: str,
        timestamp: str,
    ) -> str:
        """Generate a single Databricks DDL file."""
        qualified_name = self.qualify_name(table['full_name'])
        lines = []

        # Header comments
        lines.append(
            f"-- Databricks DDL: {qualified_name}"
        )
        lines.append(f"-- Source: {source_file}")
        lines.append(
            f"-- Converted from Redshift to Databricks SQL on {timestamp}"
        )
        lines.append(
            "-- Conversion rules: "
            "knowledgebase/redshift_to_databricks_conversion_guide.pdf"
        )
        lines.append("")

        # Conversion summary comments
        conversions = table.get('conversions', [])
        if conversions:
            lines.append("-- Conversions applied:")
            for conv in conversions:
                if conv['from_type'] == 'constraint':
                    lines.append(f"--   {conv['column']}: {conv['to_type']}")
                else:
                    lines.append(
                        f"--   {conv['column']}: "
                        f"{conv['from_type']} -> {conv['to_type']}"
                    )
            lines.append("")

        # Advisory comments for DISTKEY/SORTKEY/DISTSTYLE -> Databricks equivalents
        distkey = table.get('distkey_cols', '')
        sortkey = table.get('sortkey_cols', '')
        diststyle = table.get('diststyle', '')
        if distkey or sortkey or diststyle:
            lines.append("-- Databricks Optimization Advisory:")
            if sortkey:
                lines.append(f"--   Redshift SORTKEY({sortkey}) removed.")
                lines.append(f"--   Databricks equivalent: OPTIMIZE {qualified_name} ZORDER BY ({sortkey});")
                lines.append(f"--   Or use liquid clustering: ALTER TABLE {qualified_name} CLUSTER BY ({sortkey});")
            if distkey:
                lines.append(f"--   Redshift DISTKEY({distkey}) removed.")
                lines.append(f"--   Databricks equivalent: CLUSTER BY ({distkey}) for liquid clustering,")
                lines.append(f"--   or PARTITIONED BY ({distkey}) for Hive-style partitioning on high-cardinality join keys.")
            if diststyle:
                if diststyle == 'ALL':
                    lines.append(f"--   Redshift DISTSTYLE ALL removed.")
                    lines.append(f"--   Databricks equivalent: Use /*+ BROADCAST({table['table_name']}) */ hint in queries for small dimension tables.")
                elif diststyle == 'EVEN':
                    lines.append(f"--   Redshift DISTSTYLE EVEN removed.")
                    lines.append(f"--   Databricks: Default Spark partitioning distributes data evenly — no action needed.")
                elif diststyle == 'KEY':
                    lines.append(f"--   Redshift DISTSTYLE KEY removed.")
                    lines.append(f"--   Databricks equivalent: Use CLUSTER BY on the distribution key for liquid clustering.")
                else:
                    lines.append(f"--   Redshift DISTSTYLE {diststyle} removed — no direct Databricks equivalent.")
            lines.append("")

        # CREATE TABLE — handle TEMP tables as TEMPORARY VIEW, EXTERNAL tables specially
        if table.get('is_temp'):
            lines.append(
                f"-- NOTE: Redshift TEMP TABLE converted to Databricks TEMPORARY VIEW."
            )
            lines.append(
                f"-- For persistent temp data, use CREATE TABLE with a session-scoped schema instead."
            )
            lines.append(
                f"CREATE OR REPLACE TEMPORARY VIEW {qualified_name}"
            )
        elif table.get('is_external'):
            lines.append(
                f"-- NOTE: Redshift EXTERNAL TABLE (Spectrum) converted to Databricks external table."
            )
            lines.append(
                f"-- Consider using Unity Catalog external locations and LOCATION clause."
            )
            lines.append(
                f"CREATE TABLE IF NOT EXISTS {qualified_name}"
            )
        else:
            lines.append(
                f"CREATE TABLE IF NOT EXISTS {qualified_name}"
            )
        lines.append("(")

        # Column definitions
        columns = table.get('columns', [])
        col_lines = []
        constraint_lines = []
        for col in columns:
            if col.get('is_table_constraint'):
                constraint_text = col['constraints']
                # Check for PRIMARY KEY / UNIQUE — add advisory comment
                if re.search(r'\bPRIMARY\s+KEY\b', constraint_text, re.IGNORECASE):
                    constraint_lines.append(
                        f"   -- {constraint_text}  "
                        f"/* Databricks: PRIMARY KEY is informational only (not enforced) */"
                    )
                elif re.search(r'\bUNIQUE\b', constraint_text, re.IGNORECASE):
                    constraint_lines.append(
                        f"   -- {constraint_text}  "
                        f"/* Databricks: UNIQUE is informational only (not enforced) */"
                    )
                else:
                    constraint_lines.append(f"   -- {constraint_text}")
                continue

            converted_type, _ = apply_type_mappings(col['original_type'])
            constraints = col.get('constraints', '')

            # Strip ENCODE from constraints
            constraints, _ = apply_construct_removals(constraints)
            # Clean up extra whitespace from removals
            constraints = re.sub(r'\s{2,}', ' ', constraints).strip()

            col_line = f"   {col['name']}"
            if converted_type:
                col_line += f"    {converted_type}"
            if constraints:
                col_line += f" {constraints}"
            col_lines.append(col_line)

        # Join column lines with commas
        all_lines = col_lines + constraint_lines
        for i, col_line in enumerate(all_lines):
            if i < len(all_lines) - 1:
                lines.append(col_line + ",")
            else:
                lines.append(col_line)

        lines.append(")")
        if not table.get('is_temp'):
            lines.append("USING DELTA;")
        else:
            lines.append(";")
        lines.append("")

        return '\n'.join(lines)

    def _generate_like_ddl(
        self,
        table: Dict[str, Any],
        source_file: str,
        timestamp: str,
    ) -> str:
        """Generate DDL for CREATE TABLE ... (LIKE source) pattern."""
        qualified_name = self.qualify_name(table['full_name'])
        qualified_source = self.qualify_name(table['like_source'])
        lines = [
            f"-- Databricks DDL: {qualified_name}",
            f"-- Source: {source_file}",
            f"-- Converted on: {timestamp}",
            "",
            f"-- NOTE: CREATE TABLE ... (LIKE source) is not directly supported in Databricks.",
            f"-- Converted to CTAS with no rows. Review and adjust column types if needed.",
            "",
            f"CREATE TABLE IF NOT EXISTS {qualified_name}",
            f"USING DELTA",
            f"AS SELECT * FROM {qualified_source} WHERE 1=0;",
            "",
        ]
        return '\n'.join(lines)

    def _generate_alter_stmts(
        self,
        alter_stmts: List[Dict[str, Any]],
        source_file: str,
        timestamp: str,
    ) -> str:
        """Convert ALTER TABLE statements to Databricks."""
        lines = [
            f"-- Databricks ALTER TABLE statements converted from: {source_file}",
            f"-- Converted on: {timestamp}",
            "",
        ]

        for stmt in alter_stmts:
            sql = stmt['original_sql']
            converted, conversions = full_sql_convert(sql)

            # Strip ENCODE from ADD COLUMN
            converted = re.sub(r'\s+ENCODE\s+\w+', '', converted, flags=re.IGNORECASE)

            # Apply type mappings to ADD COLUMN type
            add_col_pattern = re.compile(
                r'(ADD\s+COLUMN\s+\w+\s+)(\w+(?:\s*\([^)]*\))?)',
                re.IGNORECASE,
            )
            match = add_col_pattern.search(converted)
            if match:
                orig_type = match.group(2)
                new_type, note = apply_type_mappings(orig_type)
                if note:
                    converted = converted[:match.start(2)] + new_type + converted[match.end(2):]
                    conversions.append(note)

            # Handle ALTER TABLE APPEND (Redshift-specific bulk move)
            if re.search(r'\bAPPEND\s+FROM\b', converted, re.IGNORECASE):
                append_match = re.search(
                    r'ALTER\s+TABLE\s+([\w.]+)\s+APPEND\s+FROM\s+([\w.]+)',
                    converted, re.IGNORECASE
                )
                if append_match:
                    target = append_match.group(1)
                    source = append_match.group(2)
                    lines.append(f"-- ALTER TABLE APPEND converted to INSERT + TRUNCATE")
                    lines.append(f"INSERT INTO {target} SELECT * FROM {source};")
                    lines.append(f"TRUNCATE TABLE {source};")
                    lines.append("")
                    continue

            # Handle FOREIGN KEY constraints
            if re.search(r'\bADD\s+CONSTRAINT\b.*\bFOREIGN\s+KEY\b', converted, re.IGNORECASE):
                lines.append(f"-- NOTE: FOREIGN KEY constraints are informational only in Databricks (not enforced).")
                lines.append(f"{converted};")
                lines.append("")
                continue

            # Comment out PRIMARY KEY / UNIQUE constraints
            if re.search(r'\bADD\s+(?:PRIMARY\s+KEY|UNIQUE|CONSTRAINT)\b', converted, re.IGNORECASE):
                lines.append(f"-- NOTE: Databricks does not enforce PRIMARY KEY/UNIQUE constraints.")
                lines.append(f"-- Use dbt tests (not_null, unique) instead.")
                lines.append(f"-- {converted};")
            else:
                if conversions:
                    for c in conversions:
                        lines.append(f"--   {c}")
                lines.append(f"{converted};")
            lines.append("")

        return '\n'.join(lines)

    def _generate_comment_stmts(
        self,
        comment_stmts: List[Dict[str, Any]],
        source_file: str,
        timestamp: str,
    ) -> str:
        """Convert COMMENT ON statements to Databricks."""
        lines = [
            f"-- Databricks COMMENT ON statements converted from: {source_file}",
            f"-- Converted on: {timestamp}",
            "",
        ]
        for stmt in comment_stmts:
            sql = stmt['original_sql']
            # COMMENT ON VIEW -> COMMENT ON TABLE (Databricks uses TABLE for both)
            if re.search(r'\bCOMMENT\s+ON\s+VIEW\b', sql, re.IGNORECASE):
                sql = re.sub(r'\bCOMMENT\s+ON\s+VIEW\b', 'COMMENT ON TABLE', sql, flags=re.IGNORECASE)
                lines.append("-- NOTE: Databricks uses COMMENT ON TABLE for both tables and views.")
            lines.append(f"{sql};")
            lines.append("")
        return '\n'.join(lines)

    def _generate_function_stmts(
        self,
        create_funcs: List[Dict[str, Any]],
        source_file: str,
        timestamp: str,
    ) -> str:
        """Convert CREATE FUNCTION statements to Databricks."""
        lines = [
            f"-- Databricks UDF statements converted from: {source_file}",
            f"-- Converted on: {timestamp}",
            "",
        ]
        for stmt in create_funcs:
            sql = stmt['original_sql']
            if re.search(r'\bLANGUAGE\s+plpythonu\b', sql, re.IGNORECASE):
                lines.append("-- MANUAL CONVERSION: Python UDF not supported in Databricks SQL.")
                lines.append("-- Use PySpark UDF or Databricks SQL scalar UDF (SQL only).")
                lines.append(f"-- Original: {sql[:100]}...")
            else:
                # SQL UDF: convert $1/$2 positional params and types
                converted, convs = full_sql_convert(sql)
                # Remove VOLATILE/STABLE/IMMUTABLE
                converted = re.sub(r'\b(?:VOLATILE|STABLE|IMMUTABLE)\b', '', converted, flags=re.IGNORECASE)
                # Remove LANGUAGE sql
                converted = re.sub(r'\s*LANGUAGE\s+sql\b', '', converted, flags=re.IGNORECASE)
                # Remove dollar quoting
                converted = re.sub(r'\$\w*\$', '', converted)
                if convs:
                    for c in convs:
                        lines.append(f"--   {c}")
                lines.append(f"{converted.strip()};")
            lines.append("")
        return '\n'.join(lines)

    def _generate_schema_stmts(
        self,
        create_schemas: List[Dict[str, Any]],
        source_file: str,
        timestamp: str,
    ) -> str:
        """Convert CREATE SCHEMA statements to Databricks."""
        lines = [
            f"-- Databricks schema statements converted from: {source_file}",
            f"-- Converted on: {timestamp}",
            "",
        ]
        for stmt in create_schemas:
            sql = stmt['original_sql']
            # Handle CREATE EXTERNAL SCHEMA FROM DATA CATALOG / HIVE METASTORE
            if re.search(r'\bEXTERNAL\s+SCHEMA\b', sql, re.IGNORECASE):
                lines.append("-- MANUAL CONVERSION: CREATE EXTERNAL SCHEMA -> Unity Catalog.")
                lines.append("-- Register as Unity Catalog external location/schema instead.")
                lines.append(f"-- Original: {sql[:120]}...")
            else:
                # Handle AUTHORIZATION and QUOTA
                schema_match = re.search(
                    r'CREATE\s+SCHEMA\s+(?:IF\s+NOT\s+EXISTS\s+)?([\w.]+)',
                    sql, re.IGNORECASE
                )
                schema_name = schema_match.group(1) if schema_match else 'schema_name'
                auth_match = re.search(r'\bAUTHORIZATION\s+(\w+)', sql, re.IGNORECASE)
                lines.append(f"CREATE SCHEMA IF NOT EXISTS {schema_name};")
                if auth_match:
                    lines.append(f"-- NOTE: AUTHORIZATION removed. Use: ALTER SCHEMA {schema_name} OWNER TO {auth_match.group(1)};")
                # Remove QUOTA
                if re.search(r'\bQUOTA\b', sql, re.IGNORECASE):
                    lines.append("-- NOTE: QUOTA not supported in Databricks.")
            lines.append("")
        return '\n'.join(lines)

    def _generate_drop_stmts(
        self,
        drop_stmts: List[Dict[str, Any]],
        source_file: str,
        timestamp: str,
    ) -> str:
        """Convert DROP TABLE statements to Databricks."""
        lines = [
            f"-- Databricks DROP TABLE statements converted from: {source_file}",
            f"-- Converted on: {timestamp}",
            "",
        ]

        for stmt in drop_stmts:
            sql = stmt['original_sql']

            # Add IF EXISTS to DROP TABLE if not already present
            sql = re.sub(r'\bDROP\s+TABLE\s+(?!IF\s+EXISTS)', 'DROP TABLE IF EXISTS ', sql, flags=re.IGNORECASE)

            # Handle CASCADE (not supported in Databricks)
            if re.search(r'\bCASCADE\b', sql, re.IGNORECASE):
                sql = re.sub(r'\s+CASCADE\b', '', sql, flags=re.IGNORECASE)
                lines.append("-- NOTE: CASCADE not supported in Databricks. Drop dependent views manually first.")

            lines.append(f"{sql};")
            lines.append("")

        return '\n'.join(lines)

    def _generate_truncate_stmts(
        self,
        truncate_stmts: List[Dict[str, Any]],
        source_file: str,
        timestamp: str,
    ) -> str:
        """Convert TRUNCATE TABLE statements to Databricks."""
        lines = [
            f"-- Databricks TRUNCATE TABLE statements converted from: {source_file}",
            f"-- Converted on: {timestamp}",
            "-- NOTE: TRUNCATE TABLE is supported on Delta tables in Databricks.",
            "",
        ]
        for stmt in truncate_stmts:
            sql = stmt['original_sql']
            # Ensure TABLE keyword is present
            if not re.search(r'\bTABLE\b', sql, re.IGNORECASE):
                sql = re.sub(r'\bTRUNCATE\s+', 'TRUNCATE TABLE ', sql, flags=re.IGNORECASE)
            lines.append(f"{sql};")
            lines.append("")
        return '\n'.join(lines)

    def _generate_vacuum_stmts(
        self,
        vacuum_stmts: List[Dict[str, Any]],
        source_file: str,
        timestamp: str,
    ) -> str:
        """Convert VACUUM and ANALYZE statements to Databricks equivalents."""
        lines = [
            f"-- Databricks maintenance statements converted from: {source_file}",
            f"-- Converted on: {timestamp}",
            "",
        ]
        for stmt in vacuum_stmts:
            sql = stmt['original_sql']
            converted, _ = full_sql_convert(sql)
            lines.append(converted + ";")
            lines.append("")
        return '\n'.join(lines)


def main() -> None:
    """Entry point: parse Redshift DDL files and generate Databricks DDL."""
    parser = DDLParser()
    parser.parse_all()

    generator = DDLGenerator(parser.parsed_data)
    generator.generate()

    print(
        f"DDL conversion complete: "
        f"{len(generator.generated_files)} table(s) generated"
    )


if __name__ == '__main__':
    main()
