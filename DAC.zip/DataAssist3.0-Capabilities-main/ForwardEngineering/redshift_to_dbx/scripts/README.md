# README Guide — Redshift-to-Databricks Converter

## 1. What It Does

A Python CLI that converts Redshift SQL files and dbt+Redshift projects into Databricks-compatible equivalents. Pure regex-based — no LLM, no internet, no external dependencies.

```
Redshift SQL + dbt  -->  python scripts/cli.py  -->  Databricks SQL + dbt
                         (130+ regex rules)      + coverage report
                                                 + validation report
                                                 + migration report
```

| Workstream | Input | Output |
|-----------|-------|--------|
| **WS1: SQL** | `inputs/sql/*.sql` | DDL, DML, Views, MVs, Stored Procedures, Queries |
| **WS2: dbt** | `inputs/dbt_project/` | Models, macros, snapshots, seeds, configs |

---

## 2. Prerequisites

- **Python 3.8+** (standard library only — no pip install needed)
- Works on Linux, macOS, Windows
- No internet or API keys required

---

## 3. Setup and Quick Start

```bash
# 1. Place input files
cp /path/to/your/sql/*.sql inputs/sql/
cp -r /path/to/your/dbt/* inputs/dbt_project/

# 2. Run
python scripts/cli.py -i inputs/ -o output/ --type both --validate --report

# 3. Review
cat output/migration_report.md
cat output/coverage_report.md
grep -r "TODO: MANUAL REVIEW" output/
```

---

## 4. Folder Structure

```
scripts/ # Conversion engine (all scripts)
inputs/                 # Source files (user-provided)
  sql/                  #   Redshift SQL files
  dbt_project/          #   dbt+Redshift project
output/                 # Generated output
  sql/ddl/              #   CREATE TABLE
  sql/dml/              #   INSERT, UPDATE, DELETE, MERGE
  sql/views/            #   CREATE VIEW
  sql/materialized_views/
  sql/stored_procedures/
  sql/queries/          #   SELECT, CTE, CTAS
  sql/combined/         #   Mixed-type inputs merged
  dbt_project/          #   Converted dbt project
  migration_report.md
  coverage_report.md
```

---

## 5. Script Reference

| Script | Purpose |
|--------|---------|
| `cli.py` | Main CLI entry point. Orchestrates the full pipeline. |
| `sql_functions.py` | Core rule engine — 130+ regex rules, 14-step pipeline. Single source of truth for all conversion rules. |
| `generate_ddl.py` | DDL converter. Extracts CREATE TABLE, applies type mappings, adds USING DELTA + IF NOT EXISTS. One file per table. |
| `generate_dml.py` | DML converter. INSERT, UPDATE, DELETE, MERGE, COPY, UNLOAD. Strips SP bodies to avoid double-conversion. |
| `generate_views.py` | View + Materialized View converter. Removes WITH NO SCHEMA BINDING. |
| `generate_procedures.py` | Stored procedure converter. Converts PL/pgSQL constructs, flags EXCEPTION blocks for manual review. |
| `generate_queries.py` | Query converter. SELECT, CTEs, CTAS. |
| `generate_dbt.py` | dbt project converter. Jinja-aware — preserves `{{ ref() }}`, `{{ source() }}`, `{{ config() }}`. |
| `validator.py` | Validates output for residual Redshift syntax, unconverted types/functions/constructs. Issues: HIGH/MEDIUM/LOW. |
| `refiner.py` | Auto-patches output based on validation. Loops up to 3 iterations. Blocked from writing to `inputs/` or `scripts/`. |
| `generate_plan.py` | Pre-conversion plan generator. |
| `generate_coverage_report.py` | Coverage analysis — statement-level (WS1) and file-level (WS2). |
| `generate_migration_report.py` | Migration summary report generator. |
| `diff_comparison.py` | Reference validation — compares output against hand-verified scripts. |
| `residual_checks.py` | Lightweight residual Redshift syntax scanner. |
| `post_conv_merge.py` | Merges output when one input file hits multiple converters. |
| `base_parser.py` | Abstract base class for parsers. |
| `base_generator.py` | Abstract base class for generators. |
| `base_validator.py` | Abstract base class for validators. |
| `utils.py` | Shared utilities — logging, YAML I/O, path helpers. |

---

## 6. CLI Reference — `scripts/cli.py`

### Flags

| Flag | Description | Default |
|------|-------------|---------|
| `-i, --input` | Input path (file, directory, or glob) | `inputs/` |
| `-o, --output` | Output directory | `output/` |
| `-t, --type` | Conversion type (see below) | `both` |
| `--plan` | Generate conversion plan before converting | off |
| `--validate` | Run coverage analysis + residual syntax validation | off |
| `--report` | Generate migration report (implies `--validate`) | off |
| `--refine` | Auto-fix validation issues via refiner loop | off |
| `--max-iterations N` | Max refinement iterations | `3` |
| `--dry-run` | Preview what would be converted, write nothing | off |
| `--skip-convert` | Skip conversion — run validation/report on existing output | off |
| `--validate-against DIR` | Compare output against reference scripts in DIR | off |
| `--catalog NAME` | Unity Catalog name for 3-level namespace (`catalog.schema.table`) | off |

### Conversion Types (`--type`)

| Type | What It Converts |
|------|-----------------|
| `ddl` | CREATE TABLE statements |
| `dml` | INSERT, UPDATE, DELETE, MERGE, COPY, UNLOAD |
| `views` | CREATE VIEW, CREATE MATERIALIZED VIEW |
| `procedures` | CREATE PROCEDURE (stored procedures) |
| `queries` | SELECT, CTEs, CTAS |
| `dbt` | Full dbt project (Workstream 2) |
| `all` | All SQL types above (auto-detects dbt if present) |
| `both` | Both workstreams: `inputs/sql/` (WS1) + `inputs/dbt_project/` (WS2) |

### Common Commands

```bash
# Full pipeline — convert + validate + refine + report
python scripts/cli.py -i inputs/ -o output/ --type both --validate --refine --report

# Full pipeline with plan
python scripts/cli.py -i inputs/ -o output/ --type both --plan --validate --refine --report

# Quick conversion only
python scripts/cli.py -i inputs/ -o output/ --type both

# Dry run — preview only
python scripts/cli.py -i inputs/ --type both --plan --dry-run

# With Unity Catalog
python scripts/cli.py -i inputs/ -o output/ --type both --catalog my_catalog
python scripts/cli.py -i inputs/ -o output/ --type both --catalog my_catalog --validate --report
```

### By Workstream

```bash
# Both workstreams
python scripts/cli.py -i inputs/ -o output/ --type both

# SQL only (WS1)
python scripts/cli.py -i inputs/sql/ -o output/ --type all
python scripts/cli.py -i inputs/sql/ -o output/ --type all --validate --report

# dbt only (WS2)
python scripts/cli.py -i inputs/dbt_project/ -o output/ --type dbt
python scripts/cli.py -i inputs/dbt_project/ -o output/ --type dbt --validate --report
```

### By SQL Type

```bash
python scripts/cli.py -i inputs/sql/ -o output/ --type ddl
python scripts/cli.py -i inputs/sql/ -o output/ --type dml
python scripts/cli.py -i inputs/sql/ -o output/ --type views
python scripts/cli.py -i inputs/sql/ -o output/ --type procedures
python scripts/cli.py -i inputs/sql/ -o output/ --type queries
```

### Single File

```bash
python scripts/cli.py -i inputs/sql/my_file.sql -o output/ --type all
python scripts/cli.py -i inputs/sql/my_file.sql -o output/ --type ddl --validate
```

### Validate / Report Without Re-Converting

```bash
# Validate existing output
python scripts/cli.py -i inputs/ -o output/ --type both --skip-convert --validate

# Validate + report on existing output
python scripts/cli.py -i inputs/ -o output/ --type both --skip-convert --validate --report

# Reference validation on existing output
python scripts/cli.py -i inputs/sql/ -o output/ --type all --skip-convert --validate-against validation/sql/

# Reference validation + report
python scripts/cli.py -i inputs/sql/ -o output/ --type all --skip-convert --validate-against validation/sql/ --report
```

### Standalone Tools

```bash
# Validator only
python scripts/validator.py

# Refiner — auto-fix
python scripts/refiner.py
python scripts/refiner.py --max-iterations 5
python scripts/refiner.py --feedback feedback.txt
python scripts/refiner.py --report thoughts/logs/agentic/validation_report.yaml
```

### Flag Combinations

| Combination | What Happens |
|-------------|-------------|
| `--type both` | Convert WS1 + WS2 |
| `--type both --validate` | Convert + coverage analysis + residual checks |
| `--type both --report` | Convert + validate + migration report |
| `--type both --refine` | Convert + validate + auto-fix loop |
| `--type both --refine --report` | Convert + validate + auto-fix + report |
| `--type both --plan --validate --refine --report` | Full pipeline (all stages) |
| `--type both --plan --dry-run` | Plan only, no output |
| `--type both --skip-convert --validate` | Validate existing output, no conversion |
| `--type both --skip-convert --report` | Report on existing output, no conversion |
| `--type all --validate-against DIR` | Convert + compare against reference scripts |
| `--type all --skip-convert --validate-against DIR --report` | Reference validation + report, no conversion |
| `--type both --catalog NAME` | Convert with Unity Catalog 3-level naming |
| `--type both --catalog NAME --validate --report` | Convert with catalog + validate + report |

---

## 7. Assumptions and Known Limitations

### Assumptions
- Input SQL uses standard Redshift syntax
- dbt project follows standard conventions (models, macros, snapshots, seeds, sources)
- Jinja expressions (`{{ ref() }}`, `{{ source() }}`) are preserved as-is, not evaluated
- Unconvertible constructs are flagged with `-- TODO: MANUAL REVIEW REQUIRED`, never silently dropped

### Known Limitations

| Limitation | Details |
|------------|---------|
| `UPDATE...FROM` | Not rewritten to MERGE — flagged for manual review |
| `DELETE...USING` | Not rewritten to DELETE WHERE EXISTS — flagged for manual review |
| External table LOCATION/format | Preserved but may need manual adjustment |
| Integer division | Redshift truncates (`5/2=2`), Databricks returns decimal (`5/2=2.5`) — advisory |
| Multiple EXCEPTION WHEN in SPs | Only first block captured; additional need manual review |
| Regex-based parsing | Not a full SQL parser — deeply nested syntax may not be detected |

---

## 8. Troubleshooting

| Problem | Fix |
|---------|-----|
| No files found | Check `ls inputs/sql/` shows `.sql` files |
| 0 conversions | Use `--type all` or `--type both` |
| Output in `combined/` | Expected — input has mixed SQL types |
| Validation failures | Run `python scripts/refiner.py` |
| Permission denied | `chmod -R 755 output/` |
| Re-validate only | Use `--skip-convert` with `--validate` |
| Need to install packages? | No — Python stdlib only, needs Python 3.8+ |
| Modifies input files? | No — all output goes to `output/` |
| Custom rules? | Edit `scripts/sql_functions.py` |
