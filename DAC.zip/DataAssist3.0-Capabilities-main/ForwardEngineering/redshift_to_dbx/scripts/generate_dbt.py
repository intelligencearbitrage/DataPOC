"""
dbt Project Migration Converter - Migrates dbt+Redshift to dbt+Databricks.

Handles: profiles.yml, dbt_project.yml, packages.yml, models (SQL), macros,
         snapshots, sources.yml, seeds config, tests, hooks.

Applies all conversion rules from:
    knowledgebase/dbt_redshift_to_dbt_databricks_migration_guide.pdf

Usage:
    python scripts/generate_dbt.py
"""

import re
import shutil
import sys
from pathlib import Path
from typing import Any, Dict, List, Tuple

SCRIPTS_DIR = Path(__file__).resolve().parent
sys.path.insert(0, str(SCRIPTS_DIR))

from base_parser import BaseParser
from base_generator import BaseGenerator
from sql_functions import full_sql_convert, apply_type_mappings
from utils import get_timestamp

try:
    import yaml
except ImportError:
    yaml = None


# ── dbt-specific conversion rules ───────────────────────────────────────

# Model config keys to transform (used for reference; actual handling in _convert_config_block)
REDSHIFT_CONFIG_KEYS = {
    'sort': None,  # removed with advisory: OPTIMIZE ZORDER BY or CLUSTER BY (liquid clustering)
    'dist': None,  # removed with advisory: CLUSTER BY (liquid clustering) or PARTITIONED BY
    'sort_type': None,  # removed with advisory: liquid clustering replaces interleaved/compound sort
}

# Redshift-only packages to remove
REDSHIFT_ONLY_PACKAGES = [
    'dbt-labs/redshift_utils',
    'redshift_utils',
]

# Packages to add for Databricks
DATABRICKS_PACKAGES = [
    {'package': 'dbt-labs/dbt_utils', 'version': ['>=1.1.0', '<2.0.0']},
    {'package': 'dbt-labs/spark_utils', 'version': ['>=0.3.0', '<1.0.0']},
]

# Note: All SQL dialect translations are handled by sql_functions.full_sql_convert()
# which covers 60+ patterns including GETDATE, SYSDATE, NVL, NVL2, LEN, STRPOS,
# CHARINDEX, DECODE, DATEADD, DATEDIFF, DATE_PART, LISTAGG, :: casts, JSON functions,
# system tables, DATE_TRUNC uppercase, date format tokens, and more.
# No duplicated pattern list needed here.


class DbtParser(BaseParser):
    """Parses a dbt project directory to identify files needing migration."""

    def __init__(self, input_dir: str = 'inputs/dbt_project', output_dir: str = 'output') -> None:
        super().__init__(input_dir=input_dir, output_dir=output_dir)

    def discover_files(self) -> List[Path]:
        """Discover all relevant dbt project files (recursive)."""
        files = []
        # Recursively find all SQL and YAML files
        for ext in ('*.sql', '*.yml', '*.yaml'):
            files.extend(self.input_dir.rglob(ext))
        # Filter out .gitkeep and other non-relevant files
        files = [f for f in files if f.is_file() and f.name != '.gitkeep']
        return sorted(set(files))

    def parse_file(self, file_path: Path) -> Dict[str, Any]:
        """Parse a single dbt project file."""
        relative = file_path.relative_to(self.input_dir)
        content = file_path.read_text(encoding='utf-8')

        file_type = self._classify_file(file_path, relative)

        return {
            'source_file': str(relative),
            'file_type': file_type,
            'content': content,
            'path': str(file_path),
        }

    def _classify_file(self, file_path: Path, relative: Path) -> str:
        """Classify a dbt file by type."""
        name = file_path.name.lower()
        rel_str = str(relative).lower()

        if name == 'profiles.yml':
            return 'profiles'
        elif name == 'dbt_project.yml':
            return 'dbt_project'
        elif name in ('packages.yml', 'packages.yaml'):
            return 'packages'
        elif name in ('sources.yml', 'sources.yaml') or 'source' in name:
            if file_path.suffix in ('.yml', '.yaml'):
                return 'sources'
        elif name in ('schema.yml', 'schema.yaml'):
            return 'schema_tests'
        elif file_path.suffix in ('.yml', '.yaml'):
            return 'yaml_config'

        if 'snapshots' in rel_str:
            return 'snapshot'
        elif 'macros' in rel_str:
            return 'macro'
        elif 'models' in rel_str:
            return 'model'
        elif 'tests' in rel_str:
            return 'test'
        elif 'analyses' in rel_str:
            return 'analysis'

        return 'other'


class DbtGenerator(BaseGenerator):
    """Generates a Databricks-compatible dbt project from a Redshift dbt project."""

    def __init__(self, parsed_data: Dict[str, Any], output_dir: str = 'output', catalog: str = '') -> None:
        super().__init__(plans_dir='plans', output_dir=output_dir, catalog=catalog)
        self.parsed_data = parsed_data
        self.generated_files: List[Dict[str, Any]] = []
        self.conversion_log: List[Dict[str, str]] = []

    def generate(self) -> None:
        timestamp = get_timestamp()

        for file_key, file_data in self.parsed_data.items():
            file_type = file_data.get('file_type', 'other')
            source_file = file_data.get('source_file', file_key)
            content = file_data.get('content', '')

            converted, conversions = self._convert_file(
                file_type, content, source_file
            )

            output_path = f"dbt_project/{source_file}"
            self.save_output(converted, output_path)
            self.generated_files.append({
                'source_file': source_file,
                'file_type': file_type,
                'output_file': str(self.output_dir / output_path),
                'conversions_applied': len(conversions),
            })
            for c in conversions:
                self.conversion_log.append({
                    'file': source_file,
                    'conversion': c,
                })

        self.logger.info(
            f"Generated {len(self.generated_files)} dbt file(s)"
        )

    def _convert_file(
        self, file_type: str, content: str, source_file: str
    ) -> Tuple[str, List[str]]:
        """Route file to appropriate converter based on type."""
        converters = {
            'profiles': self._convert_profiles,
            'dbt_project': self._convert_dbt_project,
            'packages': self._convert_packages,
            'sources': self._convert_sources,
            'model': self._convert_model_sql,
            'macro': self._convert_macro_sql,
            'snapshot': self._convert_snapshot,
            'schema_tests': self._convert_schema_tests,
            'test': self._convert_model_sql,
            'analysis': self._convert_model_sql,
        }

        converter = converters.get(file_type, self._convert_passthrough)
        return converter(content, source_file)

    def _convert_profiles(
        self, content: str, source_file: str
    ) -> Tuple[str, List[str]]:
        """Convert profiles.yml: redshift -> databricks."""
        conversions = []

        # Replace type: redshift -> type: databricks
        if re.search(r'type:\s*redshift', content, re.IGNORECASE):
            content = re.sub(
                r'type:\s*redshift',
                'type: databricks',
                content,
                flags=re.IGNORECASE,
            )
            conversions.append('profiles: type: redshift -> type: databricks')

        # Convert dbname -> catalog (Unity Catalog naming) -- must run BEFORE catalog placeholder addition
        if 'dbname:' in content.lower():
            if self.catalog:
                content = re.sub(
                    r'(\s*)dbname:\s*(\S+)',
                    rf'\1catalog: {self.catalog}  # Renamed from dbname for Unity Catalog',
                    content,
                    flags=re.IGNORECASE,
                )
                conversions.append(f'profiles: dbname -> catalog: {self.catalog} (Unity Catalog)')
            else:
                content = re.sub(
                    r'(\s*)dbname:\s*(\S+)',
                    r'\1catalog: \2  # Renamed from dbname for Unity Catalog',
                    content,
                    flags=re.IGNORECASE,
                )
                conversions.append('profiles: dbname -> catalog (Unity Catalog)')

        # Add catalog if not present (after dbname conversion so we don't duplicate)
        if 'catalog:' not in content.lower():
            if self.catalog:
                content += f'\n    catalog: {self.catalog}\n'
                conversions.append(f'profiles: Added catalog: {self.catalog} (Unity Catalog)')
            else:
                content += '\n    # TODO: Add catalog for Unity Catalog\n    # catalog: your_catalog_name\n'
                conversions.append('profiles: Added catalog placeholder for Unity Catalog')

        # Add http_path placeholder
        if 'http_path:' not in content.lower():
            content += '    # TODO: Add http_path for SQL Warehouse\n    # http_path: /sql/1.0/warehouses/your_warehouse_id\n'
            conversions.append('profiles: Added http_path placeholder')

        # Remove Redshift-specific keys
        for key in ['port:', 'keepalives_idle:', 'sslmode:', 'search_path:',
                     'ra3_node:', 'connect_timeout:', 'cluster_id:']:
            pattern = re.compile(rf'^\s*{re.escape(key)}.*$\n?', re.MULTILINE)
            if pattern.search(content):
                content = pattern.sub('', content)
                conversions.append(f'profiles: Removed Redshift-only key: {key}')

        # Replace password with token
        if 'password:' in content.lower() and 'token:' not in content.lower():
            content = re.sub(
                r'(\s*)password:.*',
                r"\1token: \"{{ env_var('DBT_DATABRICKS_TOKEN') }}\"",
                content,
            )
            conversions.append('profiles: password -> token (PAT or OAuth)')

        # Replace user with token auth note
        if 'user:' in content.lower():
            content = re.sub(
                r'(\s*)user:.*\n',
                r'\1# user removed: Databricks uses token auth\n',
                content,
            )
            conversions.append('profiles: Removed user (token-based auth)')

        header = (
            f"# Converted from dbt-redshift to dbt-databricks\n"
            f"# Source: {source_file}\n"
            f"# Review TODOs and update connection details for your environment\n\n"
        )
        return header + content, conversions

    def _convert_dbt_project(
        self, content: str, source_file: str
    ) -> Tuple[str, List[str]]:
        """Convert dbt_project.yml: update model configs."""
        conversions = []

        # Add file_format: delta globally
        if 'file_format' not in content:
            # Add after materialized: table if present
            content = re.sub(
                r'(materialized:\s*table)',
                r'\1\n      +file_format: delta',
                content,
            )
            conversions.append('dbt_project: Added +file_format: delta')

        # Replace +sort with liquid clustering advisory comment + remove
        sort_match = re.search(r'\+sort:\s*\[?([^\]\n]+)\]?', content)
        if '+sort:' in content:
            sort_cols = sort_match.group(1).strip() if sort_match else ''
            # Replace +sort with a YAML comment advising liquid clustering
            content = re.sub(
                r'^\s*\+sort:.*$',
                f'    # +sort removed -> Databricks: use OPTIMIZE ZORDER BY ({sort_cols}) or liquid clustering CLUSTER BY ({sort_cols})',
                content,
                flags=re.MULTILINE,
            )
            conversions.append(f'dbt_project: +sort removed -> use ZORDER BY or CLUSTER BY ({sort_cols})')

        # Remove +dist with advisory
        dist_match = re.search(r'\+dist:\s*["\']?(\w+)["\']?', content)
        dist_pattern = re.compile(r'^\s*\+dist:.*$\n?', re.MULTILINE)
        if dist_pattern.search(content):
            dist_col = dist_match.group(1).strip() if dist_match else ''
            content = dist_pattern.sub(
                f'    # +dist removed -> Databricks: use CLUSTER BY ({dist_col}) for liquid clustering\n',
                content,
            )
            conversions.append(f'dbt_project: +dist removed -> use CLUSTER BY ({dist_col}) for liquid clustering')

        # Remove +sort_type with advisory
        sort_type_match = re.search(r'\+sort_type:\s*(\w+)', content)
        sort_type_pattern = re.compile(r'^\s*\+sort_type:.*$\n?', re.MULTILINE)
        if sort_type_pattern.search(content):
            sort_type_val = sort_type_match.group(1).strip() if sort_type_match else ''
            content = sort_type_pattern.sub(
                f'    # +sort_type: {sort_type_val} removed -> Databricks liquid clustering replaces interleaved/compound sort\n',
                content,
            )
            conversions.append(f'dbt_project: +sort_type: {sort_type_val} removed -> use liquid clustering')

        # Remove bind: false (Redshift late-binding; Databricks views are always late-binding)
        bind_pattern = re.compile(r'^\s*bind:\s*(?:false|False|true|True)\s*$\n?', re.MULTILINE)
        if bind_pattern.search(content):
            content = bind_pattern.sub('', content)
            conversions.append('dbt_project: bind: false removed (Databricks views are always late-binding)')

        # Add dispatch config for spark_utils if not present
        if 'dispatch:' not in content:
            content = content.rstrip() + (
                '\n\ndispatch:\n'
                '  - macro_namespace: dbt_utils\n'
                "    search_order: ['spark_utils', 'dbt_utils']\n"
            )
            conversions.append('dbt_project: Added dispatch config for spark_utils')

        # Update incremental strategy
        if 'delete+insert' in content:
            content = content.replace('delete+insert', 'merge')
            conversions.append(
                'dbt_project: incremental_strategy: delete+insert -> merge'
            )

        # Add +file_format: delta for seeds
        seeds_pattern = re.compile(r'^(seeds:.*?)(?=\n\S|\Z)', re.MULTILINE | re.DOTALL)
        if seeds_pattern.search(content) and '+file_format' not in content.split('seeds:')[-1].split('\n')[0:10]:
            content = re.sub(
                r'(seeds:\s*\n)',
                r'\1    +file_format: delta\n',
                content,
            )
            conversions.append('dbt_project: Added +file_format: delta for seeds')

        # Add +file_format: delta for snapshots (HIGH-08: fix indentation)
        snap_section = re.compile(r'^(snapshots:\s*\n(\s+)\S)', re.MULTILINE)
        snap_match = snap_section.search(content)
        if snap_match:
            snap_text = content.split('snapshots:')[-1][:300]
            if '+file_format' not in snap_text:
                # Insert after the project name key at the correct indent level
                snap_indent = snap_match.group(2)
                snap_key_pattern = re.compile(
                    r'(snapshots:\s*\n\s+\w[^\n]*\n)',
                    re.MULTILINE,
                )
                snap_key_match = snap_key_pattern.search(content)
                if snap_key_match:
                    content = content.replace(
                        snap_key_match.group(0),
                        snap_key_match.group(0) + f'{snap_indent}  +file_format: delta\n',
                    )
                else:
                    content = re.sub(
                        r'(snapshots:\s*\n)',
                        r'\g<1>    +file_format: delta\n',
                        content,
                    )
                conversions.append('dbt_project: Added +file_format: delta for snapshots')

        # Convert on-run-start/on-run-end hooks: VACUUM/ANALYZE -> OPTIMIZE/ANALYZE TABLE
        vacuum_pattern = re.compile(
            r"(VACUUM\s+(?:FULL\s+)?)([\w.]+)",
            re.IGNORECASE,
        )
        if vacuum_pattern.search(content):
            content = vacuum_pattern.sub(r'OPTIMIZE \2', content)
            conversions.append('dbt_project: VACUUM -> OPTIMIZE (Delta Lake)')

        analyze_pattern = re.compile(
            r"ANALYZE\s+([\w.]+)",
            re.IGNORECASE,
        )
        if analyze_pattern.search(content):
            content = analyze_pattern.sub(r'ANALYZE TABLE \1 COMPUTE STATISTICS', content)
            conversions.append('dbt_project: ANALYZE -> ANALYZE TABLE COMPUTE STATISTICS')

        # Convert GRANT statements: Redshift GRANT syntax -> Databricks GRANT ON syntax
        grant_pattern = re.compile(
            r"GRANT\s+(SELECT|ALL|INSERT|UPDATE|DELETE)\s+ON\s+ALL\s+TABLES\s+IN\s+SCHEMA\s+([\w.]+)\s+TO\s+(?:GROUP\s+)?([\w]+)",
            re.IGNORECASE,
        )
        if grant_pattern.search(content):
            content = grant_pattern.sub(
                r'GRANT \1 ON SCHEMA \2 TO \3',
                content,
            )
            conversions.append('dbt_project: GRANT ON ALL TABLES IN SCHEMA -> GRANT ON SCHEMA (Databricks Unity Catalog)')

        header = (
            f"# Converted from dbt-redshift to dbt-databricks\n"
            f"# Source: {source_file}\n\n"
        )
        return header + content, conversions

    def _convert_packages(
        self, content: str, source_file: str
    ) -> Tuple[str, List[str]]:
        """Convert packages.yml: remove Redshift-only, add Databricks packages."""
        conversions = []

        # Remove Redshift-only packages
        for pkg in REDSHIFT_ONLY_PACKAGES:
            if pkg in content:
                # Remove the entire package block
                pattern = re.compile(
                    rf'^\s*-\s*package:\s*{re.escape(pkg)}.*?(?=\n\s*-|\Z)',
                    re.MULTILINE | re.DOTALL,
                )
                content = pattern.sub('', content)
                conversions.append(f'packages: Removed {pkg} (Redshift-only)')

        # Add spark_utils if not present
        if 'spark_utils' not in content:
            content = content.rstrip()
            content += (
                '\n  - package: dbt-labs/spark_utils\n'
                '    version: [">=0.3.0", "<1.0.0"]\n'
            )
            conversions.append('packages: Added dbt-labs/spark_utils')

        header = (
            f"# Converted from dbt-redshift to dbt-databricks\n"
            f"# Source: {source_file}\n\n"
        )
        return header + content, conversions

    def _convert_sources(
        self, content: str, source_file: str
    ) -> Tuple[str, List[str]]:
        """Convert sources.yml: database -> catalog."""
        conversions = []

        # Replace database with catalog name (actual value or placeholder)
        if 'database:' in content:
            if self.catalog:
                content = re.sub(
                    r'(\s*database:\s*)\S+',
                    rf'\1{self.catalog}',
                    content,
                )
                conversions.append(
                    f'sources: database values updated to Unity Catalog "{self.catalog}"'
                )
            else:
                content = re.sub(
                    r'(\s*database:\s*)(\S+)',
                    r'\1\2  # TODO: Update to Unity Catalog name',
                    content,
                )
                conversions.append(
                    'sources: database value needs Unity Catalog name update'
                )

        if self.catalog:
            header = (
                f"# Converted from dbt-redshift to dbt-databricks\n"
                f"# Source: {source_file}\n"
                f"# Unity Catalog: {self.catalog}\n\n"
            )
        else:
            header = (
                f"# Converted from dbt-redshift to dbt-databricks\n"
                f"# Source: {source_file}\n"
                f"# NOTE: Update 'database' values to Unity Catalog names\n\n"
            )
        return header + content, conversions

    def _convert_model_sql(
        self, content: str, source_file: str
    ) -> Tuple[str, List[str]]:
        """Convert a dbt model SQL file: config block + SQL body."""
        conversions = []

        # Convert config block
        content, config_convs = self._convert_config_block(content)
        conversions.extend(config_convs)

        # Apply full function translations to non-Jinja parts
        # This calls full_sql_convert() on each SQL segment, which handles
        # all function translations, type mappings, construct removals,
        # date format conversions, system table mappings, etc.
        content, fn_convs = self._convert_sql_preserving_jinja(content)
        conversions.extend(fn_convs)

        conv_details = ''.join(
            f"{{#   - {c} #}}\n" for c in conversions
        )
        header = (
            f"{{# Converted from dbt-redshift to dbt-databricks #}}\n"
            f"{{# Source: {source_file} #}}\n"
            f"{{# Conversions: {len(conversions)} #}}\n"
            f"{conv_details}\n"
        )
        return header + content, conversions

    def _convert_macro_sql(
        self, content: str, source_file: str
    ) -> Tuple[str, List[str]]:
        """Convert a dbt macro SQL file."""
        conversions = []

        # Check for adapter-specific dispatch patterns
        if 'redshift__' in content:
            # Add databricks__ implementation
            conversions.append(
                'macro: Contains redshift__ dispatch - add databricks__ variant'
            )
            content = (
                f"{{# NOTE: This macro has redshift__ dispatch variants. #}}\n"
                f"{{# Add databricks__ versions if SQL differs from default__. #}}\n\n"
                + content
            )

        # Handle generate_schema_name macro: Databricks uses catalog.schema
        if 'generate_schema_name' in content.lower():
            if 'catalog' not in content.lower():
                content = (
                    "{# NOTE: Databricks Unity Catalog uses 3-level namespace (catalog.schema.table). #}\n"
                    "{# Update generate_schema_name to account for catalog prefix. #}\n"
                    "{# Consider using generate_database_name for catalog mapping. #}\n\n"
                    + content
                )
                conversions.append(
                    'macro: generate_schema_name needs Unity Catalog namespace update'
                )

        # Handle generate_database_name macro: map to catalog
        if 'generate_database_name' in content.lower():
            content = (
                "{# NOTE: In Databricks, 'database' maps to Unity Catalog 'catalog'. #}\n"
                "{# Update this macro to return the correct catalog name. #}\n\n"
                + content
            )
            conversions.append(
                'macro: generate_database_name -> maps to Unity Catalog catalog'
            )

        # Apply full SQL translations (preserving Jinja blocks)
        content, sql_convs = self._convert_sql_preserving_jinja(content)
        conversions.extend(f'macro: {c}' for c in sql_convs)

        conv_details = ''.join(
            f"{{#   - {c} #}}\n" for c in conversions
        )
        header = (
            f"{{# Converted from dbt-redshift to dbt-databricks #}}\n"
            f"{{# Source: {source_file} #}}\n"
            f"{{# Conversions: {len(conversions)} #}}\n"
            f"{conv_details}\n"
        )
        return header + content, conversions

    def _convert_snapshot(
        self, content: str, source_file: str
    ) -> Tuple[str, List[str]]:
        """Convert a dbt snapshot file: add file_format='delta'."""
        conversions = []

        # Add file_format='delta' to snapshot config
        config_pattern = re.compile(
            r"(\{%\s*snapshot\s+\w+\s*%\}\s*\{\{\s*config\s*\()",
            re.IGNORECASE,
        )
        if config_pattern.search(content):
            if "file_format" not in content:
                content = config_pattern.sub(
                    r"\1\n      file_format='delta',",
                    content,
                )
                conversions.append("snapshot: Added file_format='delta'")

        # Convert invalidate_hard_deletes -> hard_deletes='invalidate' (dbt v1.9+)
        invalidate_snap = re.compile(
            r"invalidate_hard_deletes\s*=\s*(true|True)",
            re.IGNORECASE,
        )
        if invalidate_snap.search(content):
            content = invalidate_snap.sub("hard_deletes = 'invalidate'", content)
            conversions.append("snapshot: invalidate_hard_deletes -> hard_deletes='invalidate' (dbt v1.9+)")

        # Apply full SQL translations (preserving Jinja blocks)
        content, sql_convs = self._convert_sql_preserving_jinja(content)
        conversions.extend(f'snapshot: {c}' for c in sql_convs)

        conv_details = ''.join(
            f"{{#   - {c} #}}\n" for c in conversions
        )
        header = (
            f"{{# Converted from dbt-redshift to dbt-databricks #}}\n"
            f"{{# Source: {source_file} #}}\n"
            f"{{# Conversions: {len(conversions)} #}}\n"
            f"{conv_details}\n"
        )
        return header + content, conversions

    def _convert_schema_tests(
        self, content: str, source_file: str
    ) -> Tuple[str, List[str]]:
        """Convert schema.yml / tests: mostly identical, pass through."""
        conversions = []
        # Tests are 100% identical between redshift and databricks
        # Only note store_failures location change
        if 'store_failures' in content:
            conversions.append(
                'tests: store_failures table uses catalog.schema prefix in Databricks'
            )
        return content, conversions

    def _convert_passthrough(
        self, content: str, source_file: str
    ) -> Tuple[str, List[str]]:
        """Pass through unchanged files."""
        return content, []

    def _convert_config_block(
        self, content: str
    ) -> Tuple[str, List[str]]:
        """Convert dbt model config block."""
        conversions = []

        # Remove bind=false/true (Redshift late-binding; Databricks views are always late-binding)
        bind_match = re.search(r',?\s*bind\s*=\s*(?:false|true)\b', content, re.IGNORECASE)
        if bind_match:
            content = re.sub(r",?\s*bind\s*=\s*(?:false|true)\b", '', content, flags=re.IGNORECASE)
            conversions.append('config: bind=false removed (Databricks views are always late-binding)')

        # Add file_format='delta' to table materializations
        table_config = re.compile(
            r"(\{\{\s*config\s*\([^)]*materialized\s*=\s*['\"]table['\"])",
            re.IGNORECASE,
        )
        if table_config.search(content):
            if 'file_format' not in content:
                content = table_config.sub(
                    r"\1,\n    file_format='delta'",
                    content,
                )
                conversions.append("config: Added file_format='delta'")

        # Add incremental_strategy='merge' for incremental models (HIGH-09: detect existing strategy)
        incr_config = re.compile(
            r"(\{\{\s*config\s*\([^)]*materialized\s*=\s*['\"]incremental['\"])",
            re.IGNORECASE,
        )
        if incr_config.search(content):
            # HIGH-09: Check for existing strategy (including typos) before adding merge
            existing_strategy = re.search(
                r"incremental_sta?r?a?t?e?g?y\s*=\s*['\"]?(\w+)",
                content, re.IGNORECASE,
            )
            if existing_strategy:
                strategy_val = existing_strategy.group(1).lower()
                if strategy_val in ('append', 'insert_overwrite'):
                    # Fix the typo but keep the existing strategy
                    content = re.sub(
                        r'incremental_sta?r?a?t?e?g?y',
                        'incremental_strategy',
                        content,
                        flags=re.IGNORECASE,
                    )
                    conversions.append(f"config: Preserved existing incremental_strategy='{strategy_val}' (fixed typo if any)")
                # else: strategy already set to merge or other, leave as-is
            elif 'incremental_strategy' not in content:
                content = incr_config.sub(
                    r"\1,\n    incremental_strategy='merge',\n    file_format='delta'",
                    content,
                )
                conversions.append("config: Added incremental_strategy='merge'")
                conversions.append("config: Added file_format='delta' for incremental")

        # insert_overwrite is a valid Databricks-exclusive strategy (partition replacement)
        # Do NOT convert to merge — they have different semantics (PDF Section 5.2)
        if "insert_overwrite" in content:
            conversions.append(
                "config: insert_overwrite strategy detected (valid Databricks strategy, no change needed)"
            )

        # Add on_schema_change note for incremental models
        if 'incremental' in content and 'on_schema_change' not in content:
            incr_on_schema = re.compile(
                r"(incremental_strategy\s*=\s*['\"]merge['\"])",
                re.IGNORECASE,
            )
            if incr_on_schema.search(content):
                content = incr_on_schema.sub(
                    r"\1,\n    on_schema_change='append_new_columns'",
                    content,
                )
                conversions.append("config: Added on_schema_change='append_new_columns'")

        # Remove sort= from config and add advisory comment
        sort_in_config = re.compile(r",?\s*sort\s*=\s*['\"]([^'\"]*)['\"]", re.IGNORECASE)
        sort_cfg_match = sort_in_config.search(content)
        if sort_cfg_match:
            sort_cols = sort_cfg_match.group(1).strip()
            content = sort_in_config.sub('', content)
            # Add advisory comment before the config block
            content = re.sub(
                r'(\{\{\s*config\s*\()',
                f'{{# sort removed -> Databricks: use OPTIMIZE ZORDER BY ({sort_cols}) or liquid clustering CLUSTER BY ({sort_cols}) #}}\n\\1',
                content,
                count=1,
            )
            conversions.append(f'config: sort={sort_cols} removed -> advisory: OPTIMIZE ZORDER BY or CLUSTER BY')

        # Remove dist= from config and add advisory comment
        dist_in_config = re.compile(r",?\s*dist\s*=\s*['\"]([^'\"]*)['\"]", re.IGNORECASE)
        dist_cfg_match = dist_in_config.search(content)
        if dist_cfg_match:
            dist_col = dist_cfg_match.group(1).strip()
            content = dist_in_config.sub('', content)
            # Add advisory comment before the config block
            if '{# sort removed' not in content:
                content = re.sub(
                    r'(\{\{\s*config\s*\()',
                    f'{{# dist removed -> Databricks: use CLUSTER BY ({dist_col}) for liquid clustering or PARTITIONED BY ({dist_col}) #}}\n\\1',
                    content,
                    count=1,
                )
            else:
                # Already have a sort advisory, append dist advisory after it
                content = content.replace(
                    '#}}\n{{ config',
                    f'#}}\n{{# dist removed -> Databricks: use CLUSTER BY ({dist_col}) for liquid clustering or PARTITIONED BY ({dist_col}) #}}\n{{{{ config',
                )
                if f'CLUSTER BY ({dist_col})' not in content:
                    # Fallback: just add after existing Jinja comment
                    content = re.sub(
                        r'(\{\{\s*config\s*\()',
                        f'{{# dist removed -> Databricks: use CLUSTER BY ({dist_col}) for liquid clustering or PARTITIONED BY ({dist_col}) #}}\n\\1',
                        content,
                        count=1,
                    )
            conversions.append(f'config: dist={dist_col} removed -> advisory: CLUSTER BY or PARTITIONED BY')

        # Convert column_types in seed configs (Redshift types -> Databricks types)
        col_types_pattern = re.compile(
            r"(column_types\s*[:=]\s*\{[^}]*\})",
            re.IGNORECASE | re.DOTALL,
        )
        col_match = col_types_pattern.search(content)
        if col_match:
            original_block = col_match.group(1)
            new_block, _ = apply_type_mappings(original_block)
            if new_block != original_block:
                content = content.replace(original_block, new_block)
                conversions.append('config: Converted column_types data types for seeds')

        return content, conversions

    def _convert_sql_preserving_jinja(
        self, content: str
    ) -> Tuple[str, List[str]]:
        """Apply full SQL function translations while preserving Jinja blocks.

        Extracts non-Jinja segments, runs full_sql_convert() on each,
        then reassembles with Jinja blocks untouched.
        """
        conversions = []

        # Split content into Jinja and SQL segments
        # Jinja blocks: {{ ... }}, {% ... %}, {# ... #}
        jinja_pattern = re.compile(
            r'(\{\{.*?\}\}|\{%.*?%\}|\{#.*?#\})',
            re.DOTALL,
        )
        segments = jinja_pattern.split(content)
        converted_segments = []

        for i, segment in enumerate(segments):
            if i % 2 == 1:
                # Jinja block — pass through untouched
                converted_segments.append(segment)
            else:
                # SQL segment — apply full conversion pipeline
                if segment.strip():
                    converted_seg, seg_convs = full_sql_convert(segment)
                    converted_segments.append(converted_seg)
                    conversions.extend(seg_convs)
                else:
                    converted_segments.append(segment)

        content = ''.join(converted_segments)

        # Handle :: casts that span Jinja boundaries: {{expr}}::TYPE -> CAST({{expr}} AS TYPE)
        cast_type_map = {
            'varchar': 'STRING', 'text': 'STRING', 'char': 'STRING', 'string': 'STRING',
            'integer': 'INT', 'int': 'INT', 'bigint': 'BIGINT', 'smallint': 'SMALLINT',
            'float': 'DOUBLE', 'double': 'DOUBLE', 'boolean': 'BOOLEAN', 'bool': 'BOOLEAN',
            'date': 'DATE', 'timestamp': 'TIMESTAMP', 'numeric': 'DECIMAL', 'decimal': 'DECIMAL',
        }
        jinja_cast_pattern = re.compile(
            r'(\{\{[^}]+\}\})\s*::\s*(\w+)(?:\s*\(([^)]+)\))?',
            re.IGNORECASE,
        )
        def _jinja_cast_replace(m):
            jinja_expr = m.group(1)
            raw_type = m.group(2).lower()
            precision = m.group(3)
            db_type = cast_type_map.get(raw_type, raw_type.upper())
            if precision:
                db_type = f'{db_type}({precision})'
            conversions.append(f'casting: ::{ raw_type} -> CAST(... AS {db_type})')
            return f'CAST({jinja_expr} AS {db_type})'
        content = jinja_cast_pattern.sub(_jinja_cast_replace, content)

        # Convert dbt_utils cross-database macros that moved to dbt namespace (dbt-utils v1.0+)
        migrated_macros = [
            'dateadd', 'datediff', 'date_trunc', 'safe_cast',
            'type_string', 'type_int', 'type_float', 'type_numeric',
            'type_timestamp', 'type_bigint', 'current_timestamp',
            'hash', 'position', 'split_part', 'last_day', 'any_value',
            'bool_or', 'concat', 'escape_single_quotes', 'except',
            'intersect', 'length', 'listagg', 'replace', 'right',
            'string_literal',
        ]
        macro_pattern = re.compile(
            r'dbt_utils\.(' + '|'.join(migrated_macros) + r')\s*\(',
            re.IGNORECASE,
        )
        if macro_pattern.search(content):
            content = macro_pattern.sub(r'dbt.\1(', content)
            conversions.append('dbt: dbt_utils.<cross-db macro> -> dbt.<macro> (namespace migration)')

        # Convert dbt_utils.surrogate_key -> dbt_utils.generate_surrogate_key
        if 'dbt_utils.surrogate_key' in content:
            content = content.replace('dbt_utils.surrogate_key', 'dbt_utils.generate_surrogate_key')
            conversions.append('dbt: surrogate_key -> generate_surrogate_key (renamed in dbt-utils v1.0)')

        # Convert GRANT ... TO GROUP -> GRANT ... TO (remove GROUP keyword)
        grant_group_pattern = re.compile(
            r'(\bgrant\s+\w+\s+on\s+\S+\s+to\s+)group\s+',
            re.IGNORECASE,
        )
        if grant_group_pattern.search(content):
            content = grant_group_pattern.sub(r'\1', content)
            conversions.append('dbt: GRANT TO GROUP -> GRANT TO (Unity Catalog)')

        # Convert invalidate_hard_deletes -> hard_deletes='invalidate' (dbt v1.9+)
        invalidate_pattern = re.compile(
            r"invalidate_hard_deletes\s*=\s*(true|True)",
            re.IGNORECASE,
        )
        if invalidate_pattern.search(content):
            content = invalidate_pattern.sub("hard_deletes = 'invalidate'", content)
            conversions.append("dbt: invalidate_hard_deletes -> hard_deletes='invalidate' (dbt v1.9+)")

        # Also convert post_hook/pre_hook: VACUUM -> OPTIMIZE, ANALYZE -> ANALYZE TABLE
        vacuum_hook = re.compile(
            r"(VACUUM\s+(?:FULL\s+)?)([\w.{}\(\)]+)",
            re.IGNORECASE,
        )
        if vacuum_hook.search(content):
            content = vacuum_hook.sub(r'OPTIMIZE \2', content)
            conversions.append('SQL: VACUUM -> OPTIMIZE (Delta Lake)')

        analyze_hook = re.compile(
            r"ANALYZE\s+([\w.{}\(\)]+)(?!\s+TABLE)",
            re.IGNORECASE,
        )
        if analyze_hook.search(content):
            content = analyze_hook.sub(r'ANALYZE TABLE \1 COMPUTE STATISTICS', content)
            conversions.append('SQL: ANALYZE -> ANALYZE TABLE COMPUTE STATISTICS')

        # Convert GRANT in hooks
        grant_hook = re.compile(
            r"GRANT\s+(SELECT|ALL|INSERT|UPDATE|DELETE)\s+ON\s+ALL\s+TABLES\s+IN\s+SCHEMA\s+([\w.]+)\s+TO\s+(?:GROUP\s+)?([\w]+)",
            re.IGNORECASE,
        )
        if grant_hook.search(content):
            content = grant_hook.sub(r'GRANT \1 ON SCHEMA \2 TO \3', content)
            conversions.append('SQL: GRANT ON ALL TABLES IN SCHEMA -> GRANT ON SCHEMA (Unity Catalog)')

        return content, conversions


def main() -> None:
    parser = DbtParser()
    parser.parse_all()

    if not parser.parsed_data:
        print("No dbt project files found in inputs/dbt_project/.")
        print("Place your dbt project in inputs/dbt_project/ and re-run.")
        return

    generator = DbtGenerator(parser.parsed_data)
    generator.generate()
    print(
        f"dbt project migration complete: "
        f"{len(generator.generated_files)} file(s) converted"
    )


if __name__ == '__main__':
    main()
