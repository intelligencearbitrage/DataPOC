"""
Agentic Refiner - Patches output files based on validation errors and human feedback.

Reads the validation report produced by validator.py, optionally reads human feedback,
and applies targeted patches to files in output/ only. Implements a refinement loop
with configurable max iterations and guardrails from GUARDRAILS.yaml.

Supports all output types: DDL, DML, views, materialized views, stored procedures,
queries, and combined files.

Usage:
    python scripts/refiner.py                                         # Use latest report
    python scripts/refiner.py --report path/to/validation.yaml        # Specific report
    python scripts/refiner.py --feedback feedback.txt                  # With human feedback
    python scripts/refiner.py --max-iterations 5                       # Custom limit
    python scripts/refiner.py --input inputs/sql --output output       # Custom dirs
"""

import argparse
import re
import sys
import time
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

# Ensure scripts/ is on the Python path
SCRIPTS_DIR = Path(__file__).resolve().parent
sys.path.insert(0, str(SCRIPTS_DIR))

from utils import get_timestamp, load_yaml, save_yaml, setup_logging


# ---------------------------------------------------------------------------
# Constants from GUARDRAILS.yaml
# ---------------------------------------------------------------------------
DEFAULT_MAX_ITERATIONS = 3
DIFF_SIZE_CAP = 50
ALLOWED_WRITE_DIR = Path('output')
BLOCKED_DIRS = [Path('inputs'), Path('knowledgebase'), Path('scripts')]
PROJECT_ROOT = Path(__file__).resolve().parent.parent

logger = setup_logging('Refiner')


def _sanitize_path(raw: str, allowed_base: Path) -> Path:
    """Resolve a user-supplied path, anchored to allowed_base, rejecting traversal."""
    if not raw:
        raise ValueError("Empty path")
    safe = re.sub(r'[^\w.\-/\\ ]', '', raw)
    if safe != raw:
        raise ValueError(f"Path contains disallowed characters: {raw!r}")
    if '..' in safe.replace('\\', '/').split('/'):
        raise ValueError(f"Path traversal blocked: {raw!r}")
    candidate = (allowed_base / safe).resolve()
    if not candidate.is_relative_to(allowed_base.resolve()):
        raise ValueError(
            f"Path traversal blocked: {raw!r} escapes {allowed_base}"
        )
    return candidate


# ==========================================================================
# Guardrail enforcement
# ==========================================================================

def enforce_write_boundary(file_path: Path) -> bool:
    """Return True if the file is inside output/. Block otherwise."""
    try:
        file_path.resolve().relative_to(ALLOWED_WRITE_DIR.resolve())
        return True
    except ValueError:
        pass
    # Also accept relative paths that start with output/
    if str(file_path).startswith('output/') or str(file_path).startswith('output\\'):
        return True
    logger.error(f"BLOCKED: Write attempt outside output/: {file_path}")
    return False


def check_diff_size(original: str, patched: str) -> Tuple[bool, int]:
    """Check if the diff exceeds the 50-line cap. Returns (ok, lines_changed)."""
    orig_lines = original.split('\n')
    patch_lines = patched.split('\n')
    changed = sum(1 for a, b in zip(orig_lines, patch_lines) if a != b)
    changed += abs(len(orig_lines) - len(patch_lines))
    return changed <= DIFF_SIZE_CAP, changed


# ==========================================================================
# Feedback validation
# ==========================================================================

def validate_feedback(
    feedback_text: str,
    report: Dict[str, Any],
) -> Dict[str, Any]:
    """Validate human feedback for relevance, actionability, and source consistency."""
    result: Dict[str, Any] = {
        'timestamp': get_timestamp(),
        'raw_feedback': feedback_text,
        'checks': [],
        'accepted': [],
        'rejected': [],
    }

    vr = report.get('validation_report', {})
    issue_ids = {i['id'] for i in vr.get('issues', [])}
    output_files = {i['output_file'] for i in vr.get('issues', [])}

    # Simple line-by-line feedback validation
    for line in feedback_text.strip().split('\n'):
        line = line.strip()
        if not line:
            continue

        # Relevance: does it reference an issue ID or output file?
        relevant = any(iid in line for iid in issue_ids) or \
                   any(of.split('/')[-1] in line for of in output_files) or \
                   'output/' in line.lower() or \
                   any(cat in line.lower() for cat in [
                       'type', 'column', 'delta', 'not null', 'varchar',
                       'string', 'timestamp', 'mapping', 'ddl', 'dml',
                       'view', 'procedure', 'query', 'merge', 'copy',
                   ])

        # Actionability: not a request to change scripts/infra
        actionable = not any(kw in line.lower() for kw in [
            'change script', 'modify script', 'update script',
            'change infrastructure', 'change pipeline',
        ])

        # Source consistency: not contradicting known rules
        consistent = not any(kw in line.lower() for kw in [
            'keep varchar', 'keep timestamptz', 'keep bpchar',
            'remove using delta', 'remove if not exists',
        ])

        check = {
            'item': line,
            'relevance': 'PASS' if relevant else 'FAIL',
            'actionability': 'PASS' if actionable else 'FAIL',
            'source_consistency': 'PASS' if consistent else 'FAIL',
        }
        result['checks'].append(check)

        if relevant and actionable and consistent:
            result['accepted'].append(line)
        else:
            reasons = []
            if not relevant:
                reasons.append('Not related to validation issues or output files')
            if not actionable:
                reasons.append('Not actionable as an output patch')
            if not consistent:
                reasons.append('Contradicts source data or conversion rules')
            result['rejected'].append({'item': line, 'reasons': reasons})

    return result


# ==========================================================================
# Patching engine (rule-based, all output types)
# ==========================================================================

def apply_patches(
    issues: List[Dict[str, str]],
    feedback_items: List[str],
    source_tables: Dict[str, Dict[str, Any]],
) -> List[Dict[str, Any]]:
    """Apply rule-based patches for each issue. Returns list of patch records."""
    patches: List[Dict[str, Any]] = []

    for issue in issues:
        raw_output = issue.get('output_file', '')
        try:
            output_file = _sanitize_path(raw_output, PROJECT_ROOT)
        except ValueError:
            logger.error(f"BLOCKED: Invalid output path: {raw_output}")
            continue
        if not output_file.exists():
            logger.warning(f"Output file not found for patching: {output_file}")
            continue

        if not enforce_write_boundary(output_file):
            continue

        original = output_file.read_text(encoding='utf-8')
        patched = original
        approach = ''

        category = issue.get('category', '')

        # ---- Shared categories (all output types) ----
        if category == 'residual_redshift':
            patched, approach = _patch_residual_redshift(patched, issue)

        elif category == 'missing_traceability':
            patched, approach = _patch_traceability(patched, issue)

        # ---- DDL-specific ----
        elif category == 'missing_construct':
            patched, approach = _patch_missing_construct(patched, issue)

        elif category == 'incorrect_type_mapping':
            patched, approach = _patch_type_mapping(patched, issue, source_tables)

        elif category == 'lost_constraint':
            patched, approach = _patch_lost_constraint(patched, issue, source_tables)

        elif category == 'missing_column':
            patched, approach = _patch_missing_column(patched, issue, source_tables)

        # ---- View-specific ----
        elif category == 'incorrect_construct':
            patched, approach = _patch_incorrect_construct(patched, issue)

        # ---- Procedure-specific ----
        elif category == 'unconverted_plpgsql':
            patched, approach = _patch_plpgsql(patched, issue)

        # ---- DML-specific ----
        elif category == 'unconverted_dml':
            patched, approach = _patch_unconverted_dml(patched, issue)

        if patched == original:
            patches.append({
                'issue_id': issue['id'],
                'status': 'no_change',
                'approach': 'No automated fix available for this issue',
                'output_file': str(output_file),
                'lines_changed': 0,
            })
            continue

        # Check diff size
        ok, lines_changed = check_diff_size(original, patched)
        if not ok:
            patches.append({
                'issue_id': issue['id'],
                'status': 'flagged_for_review',
                'approach': approach,
                'output_file': str(output_file),
                'lines_changed': lines_changed,
                'reason': f'Diff exceeds {DIFF_SIZE_CAP}-line cap',
            })
            continue

        # Apply patch
        output_file.write_text(patched, encoding='utf-8')
        patches.append({
            'issue_id': issue['id'],
            'status': 'applied',
            'approach': approach,
            'output_file': str(output_file),
            'lines_changed': lines_changed,
            'source_reference': issue.get('source_file', ''),
        })
        logger.info(f"Patched {issue['id']}: {approach} ({lines_changed} lines)")

    return patches


# --------------------------------------------------------------------------
# Shared patchers (all output types)
# --------------------------------------------------------------------------

def _patch_residual_redshift(
    content: str, issue: Dict[str, str]
) -> Tuple[str, str]:
    """Remove residual Redshift syntax by running the full sql_functions pipeline.

    Rather than reimplementing individual regex fixes, this delegates to
    full_sql_convert() which applies all 122 function translations, 38 type
    mappings, 16 construct removals, and 21 system table mappings.
    Comment lines are preserved by the pipeline's design.
    """
    from sql_functions import full_sql_convert

    original = content

    # Separate header comments (traceability) from SQL body to protect them
    header_lines: list[str] = []
    body_lines: list[str] = []
    in_header = True
    for line in content.split('\n'):
        if in_header and (line.strip().startswith('--') or line.strip() == ''):
            header_lines.append(line)
        else:
            in_header = False
            body_lines.append(line)

    body = '\n'.join(body_lines)
    converted_body = full_sql_convert(body)
    patched = '\n'.join(header_lines + [converted_body]) if header_lines else converted_body

    if patched != original:
        return patched, 'Applied full sql_functions pipeline to fix residual Redshift syntax'
    return content, ''


def _patch_traceability(
    content: str, issue: Dict[str, str]
) -> Tuple[str, str]:
    """Add missing traceability comments."""
    desc = issue.get('description', '').lower()
    source = issue.get('source_file', 'unknown')
    approach = ''

    if 'source file reference' in desc and '-- Source:' not in content:
        content = f"-- Source: {source}\n{content}"
        approach = 'Added source file reference comment'

    if 'conversion timestamp' in desc and '-- Converted from Redshift' not in content:
        ts = get_timestamp()
        content = f"-- Converted from Redshift to Databricks SQL on {ts}\n{content}"
        approach = 'Added conversion timestamp comment'

    if 'conversion rules reference' in desc and '-- Conversion rules:' not in content:
        content = (
            "-- Conversion rules: knowledgebase/"
            "redshift_to_databricks_conversion_guide.pdf\n" + content
        )
        approach = 'Added conversion rules reference comment'

    return content, approach


# --------------------------------------------------------------------------
# DDL-specific patchers
# --------------------------------------------------------------------------

def _patch_missing_construct(
    content: str, issue: Dict[str, str]
) -> Tuple[str, str]:
    """Add missing USING DELTA, IF NOT EXISTS, or OR REPLACE."""
    approach = ''
    desc = issue.get('description', '').lower()

    if 'using delta' in desc and 'USING DELTA' not in content:
        content = re.sub(
            r'\)\s*;?\s*$',
            ')\nUSING DELTA;\n',
            content.rstrip(),
        )
        approach = 'Added USING DELTA clause'

    if 'if not exists' in desc and 'IF NOT EXISTS' not in content.upper():
        content = re.sub(
            r'CREATE\s+TABLE\s+',
            'CREATE TABLE IF NOT EXISTS ',
            content,
            count=1,
            flags=re.IGNORECASE,
        )
        approach = 'Added IF NOT EXISTS to CREATE TABLE'

    if 'or replace' in desc and 'OR REPLACE' not in content.upper():
        # Add OR REPLACE to CREATE VIEW or CREATE PROCEDURE
        content = re.sub(
            r'CREATE\s+((?:MATERIALIZED\s+)?VIEW|PROCEDURE)\s+',
            r'CREATE OR REPLACE \1 ',
            content,
            count=1,
            flags=re.IGNORECASE,
        )
        approach = 'Added OR REPLACE'

    return content, approach


def _patch_type_mapping(
    content: str, issue: Dict[str, str], source_tables: Dict[str, Dict[str, Any]]
) -> Tuple[str, str]:
    """Fix incorrect type mappings."""
    desc = issue.get('description', '')
    match = re.search(r"Column '(\w+)'.*expected (\w+)", desc)
    if not match:
        return content, ''

    col_name = match.group(1)
    expected_type = match.group(2)

    lines = content.split('\n')
    new_lines = []
    for line in lines:
        stripped = line.strip().rstrip(',')
        parts = stripped.split()
        if parts and parts[0].lower() == col_name.lower() and not stripped.startswith('--'):
            constraints = ''
            if 'NOT NULL' in line.upper():
                constraints = ' NOT NULL'
            comma = ',' if line.rstrip().endswith(',') else ''
            new_line = f"   {col_name}    {expected_type}{constraints}{comma}"
            new_lines.append(new_line)
        else:
            new_lines.append(line)

    return '\n'.join(new_lines), f"Fixed type mapping for column '{col_name}' to {expected_type}"


def _patch_lost_constraint(
    content: str, issue: Dict[str, str], source_tables: Dict[str, Dict[str, Any]]
) -> Tuple[str, str]:
    """Restore lost NOT NULL constraints."""
    desc = issue.get('description', '')
    match = re.search(r"column '(\w+)'", desc, re.IGNORECASE)
    if not match:
        return content, ''

    col_name = match.group(1)
    lines = content.split('\n')
    new_lines = []
    for line in lines:
        stripped = line.strip().rstrip(',')
        parts = stripped.split()
        if (parts and parts[0].lower() == col_name.lower()
                and not stripped.startswith('--')
                and 'NOT NULL' not in line.upper()):
            comma = ',' if line.rstrip().endswith(',') else ''
            new_lines.append(line.rstrip().rstrip(',') + ' NOT NULL' + comma)
        else:
            new_lines.append(line)

    return '\n'.join(new_lines), f"Restored NOT NULL on column '{col_name}'"


def _patch_missing_column(
    content: str, issue: Dict[str, str], source_tables: Dict[str, Dict[str, Any]]
) -> Tuple[str, str]:
    """Add a missing column from source to output DDL."""
    desc = issue.get('description', '')
    match = re.search(r"Column '(\w+)'", desc)
    if not match:
        return content, ''

    col_name = match.group(1)

    output_file = issue.get('output_file', '')
    table_name = Path(output_file).stem
    source_info = source_tables.get(table_name, {})
    source_cols = source_info.get('columns', [])

    src_col = next(
        (c for c in source_cols if c['name'].lower() == col_name.lower()),
        None,
    )
    if not src_col:
        return content, ''

    # Determine converted type using sql_functions
    from sql_functions import apply_type_mappings
    converted_type = apply_type_mappings(src_col['type'])

    constraints = src_col.get('constraints', '')
    col_line = f"   {col_name}    {converted_type}"
    if constraints:
        col_line += f" {constraints}"

    lines = content.split('\n')
    new_lines = []
    inserted = False
    for line in lines:
        if line.strip() == ')' and not inserted:
            if new_lines and not new_lines[-1].rstrip().endswith(','):
                new_lines[-1] = new_lines[-1].rstrip() + ','
            new_lines.append(col_line)
            inserted = True
        new_lines.append(line)

    return '\n'.join(new_lines), f"Added missing column '{col_name}' ({converted_type})"


# --------------------------------------------------------------------------
# View-specific patchers
# --------------------------------------------------------------------------

def _patch_incorrect_construct(
    content: str, issue: Dict[str, str]
) -> Tuple[str, str]:
    """Fix incorrect view constructs (e.g., missing MATERIALIZED keyword)."""
    desc = issue.get('description', '').lower()

    if 'materialized view' in desc and 'MATERIALIZED VIEW' not in content.upper():
        content = re.sub(
            r'CREATE\s+(?:OR\s+REPLACE\s+)?VIEW\b',
            'CREATE OR REPLACE MATERIALIZED VIEW',
            content,
            count=1,
            flags=re.IGNORECASE,
        )
        return content, 'Added MATERIALIZED keyword to view definition'

    return content, ''


# --------------------------------------------------------------------------
# Procedure-specific patchers
# --------------------------------------------------------------------------

def _patch_plpgsql(
    content: str, issue: Dict[str, str]
) -> Tuple[str, str]:
    """Patch unconverted PL/pgSQL constructs."""
    desc = issue.get('description', '').lower()
    approach_parts = []

    lines = content.split('\n')
    new_lines = []
    for line in lines:
        if line.strip().startswith('--'):
            new_lines.append(line)
            continue

        modified = line

        # := assignment → SET
        if ':=' in desc and re.search(r'\b(\w+)\s*:=\s*', modified):
            modified = re.sub(r'\b(\w+)\s*:=\s*', r'SET \1 = ', modified)
            approach_parts.append(':= → SET assignment')

        # EXECUTE without IMMEDIATE → EXECUTE IMMEDIATE
        if 'execute without immediate' in desc and re.search(r'\bEXECUTE\s+(?!IMMEDIATE)', modified, re.IGNORECASE):
            modified = re.sub(r'\bEXECUTE\s+', 'EXECUTE IMMEDIATE ', modified, flags=re.IGNORECASE)
            approach_parts.append('EXECUTE → EXECUTE IMMEDIATE')

        # PERFORM → remove keyword (query runs as-is without PERFORM)
        if 'perform' in desc and re.search(r'\bPERFORM\s+', modified, re.IGNORECASE):
            modified = re.sub(r'\bPERFORM\s+', '', modified, flags=re.IGNORECASE)
            approach_parts.append('PERFORM keyword removed')

        # ELSIF → ELSEIF
        if 'elsif' in desc and re.search(r'\bELSIF\b', modified, re.IGNORECASE):
            modified = re.sub(r'\bELSIF\b', 'ELSEIF', modified, flags=re.IGNORECASE)
            approach_parts.append('ELSIF → ELSEIF')

        # EXIT WHEN → LEAVE WHEN
        if 'exit when' in desc and re.search(r'\bEXIT\s+WHEN\b', modified, re.IGNORECASE):
            modified = re.sub(r'\bEXIT\s+WHEN\b', 'LEAVE WHEN', modified, flags=re.IGNORECASE)
            approach_parts.append('EXIT WHEN → LEAVE WHEN')

        # END LOOP → END FOR / END WHILE (context-dependent, use END FOR as default)
        if 'end loop' in desc and re.search(r'\bEND\s+LOOP\b', modified, re.IGNORECASE):
            modified = re.sub(r'\bEND\s+LOOP\b', 'END FOR', modified, flags=re.IGNORECASE)
            approach_parts.append('END LOOP → END FOR')

        # LANGUAGE plpgsql → LANGUAGE SQL
        if 'language plpgsql' in desc and re.search(r'\bLANGUAGE\s+plpgsql\b', modified, re.IGNORECASE):
            modified = re.sub(r'\bLANGUAGE\s+plpgsql\b', 'LANGUAGE SQL', modified, flags=re.IGNORECASE)
            approach_parts.append('LANGUAGE plpgsql → LANGUAGE SQL')

        new_lines.append(modified)

    approach = 'Converted PL/pgSQL: ' + ', '.join(sorted(set(approach_parts))) if approach_parts else ''
    return '\n'.join(new_lines), approach


# --------------------------------------------------------------------------
# DML-specific patchers
# --------------------------------------------------------------------------

def _patch_unconverted_dml(
    content: str, issue: Dict[str, str]
) -> Tuple[str, str]:
    """Patch unconverted DML constructs."""
    desc = issue.get('description', '').lower()
    approach = ''

    lines = content.split('\n')
    new_lines = []
    for line in lines:
        if line.strip().startswith('--'):
            new_lines.append(line)
            continue

        modified = line

        # COPY ... FROM → COPY INTO
        if 'copy' in desc and re.search(r'\bCOPY\s+(\w+)\s+FROM\b', modified, re.IGNORECASE):
            modified = re.sub(
                r'\bCOPY\s+(\w+)\s+FROM\b',
                r'COPY INTO \1 FROM',
                modified,
                flags=re.IGNORECASE,
            )
            approach = 'COPY → COPY INTO'

        # END TRANSACTION → COMMIT
        if 'end transaction' in desc and re.search(r'\bEND\s+TRANSACTION\b', modified, re.IGNORECASE):
            modified = re.sub(r'\bEND\s+TRANSACTION\b', 'COMMIT', modified, flags=re.IGNORECASE)
            approach = 'END TRANSACTION → COMMIT'

        new_lines.append(modified)

    return '\n'.join(new_lines), approach


# ==========================================================================
# Refinement loop
# ==========================================================================

def find_latest_report(log_dir: Path) -> Optional[Path]:
    """Find the most recent validation report in the agentic log directory."""
    if not log_dir.exists():
        return None
    reports = sorted(log_dir.glob('validation_*.yaml'), reverse=True)
    return reports[0] if reports else None


def run_refinement_loop(
    report_path: Optional[str] = None,
    feedback_path: Optional[str] = None,
    max_iterations: int = DEFAULT_MAX_ITERATIONS,
    input_dir: str = 'inputs/sql',
    output_dir: str = 'output',
) -> None:
    """Run the full refinement loop: patch → validate → repeat."""
    log_dir = Path('thoughts/logs/agentic')
    log_dir.mkdir(parents=True, exist_ok=True)

    # Load validation report
    if report_path:
        try:
            rpath = _sanitize_path(report_path, PROJECT_ROOT)
        except ValueError as e:
            print(f"Invalid report path: {e}")
            return
    else:
        rpath = find_latest_report(log_dir)
    if not rpath or not rpath.exists():
        print("No validation report found. Run validator.py first.")
        return

    if not rpath.resolve().is_relative_to(PROJECT_ROOT.resolve()):
        print(f"Report path outside project root: {rpath}")
        return
    report = load_yaml(rpath)
    vr = report.get('validation_report', {})
    issues = vr.get('issues', [])

    if not issues:
        print("No issues found in validation report. Nothing to refine.")
        return

    print(f"\nLoaded validation report: {rpath}")
    print(f"Issues to address: {len(issues)}")

    # Load and validate feedback
    feedback_items: List[str] = []
    if feedback_path:
        try:
            fb_path = _sanitize_path(feedback_path, PROJECT_ROOT)
        except ValueError as e:
            print(f"Invalid feedback path: {e}")
            return
        if fb_path.exists():
            feedback_text = fb_path.read_text(encoding='utf-8')
            fb_result = validate_feedback(feedback_text, report)
            save_yaml(fb_result, log_dir / f"feedback_validation_{get_timestamp().replace(' ', '_').replace(':', '')}.yaml")

            if fb_result['rejected']:
                print(f"\nRejected feedback items:")
                for rej in fb_result['rejected']:
                    print(f"  - {rej['item']}: {', '.join(rej['reasons'])}")

            feedback_items = fb_result['accepted']
            if feedback_items:
                print(f"Accepted feedback items: {len(feedback_items)}")
        else:
            print(f"Feedback file not found: {fb_path}")

    # Parse source tables for patching context using OutputValidator
    from validator import OutputValidator
    v = OutputValidator(input_dir=input_dir, output_dir=output_dir)
    source_tables = v.source_tables

    # Track accuracy progression
    accuracy_progression: List[Dict[str, Any]] = [{
        'stage': 'initial_validation',
        'accuracy': vr.get('overall_accuracy', 0),
        'issues_found': len(issues),
    }]

    # Stale issue tracking: issue_id → consecutive failure count
    stale_tracker: Dict[str, int] = {}
    prev_accuracy = vr.get('overall_accuracy', 0)

    for iteration in range(1, max_iterations + 1):
        print(f"\n{'='*60}")
        print(f"  REFINEMENT ITERATION {iteration}/{max_iterations}")
        print(f"{'='*60}")

        start_time = time.time()

        # Filter out stale issues (failed twice in a row)
        active_issues = [
            i for i in issues if stale_tracker.get(i['id'], 0) < 2
        ]
        skipped = len(issues) - len(active_issues)
        if skipped:
            print(f"  Skipping {skipped} stale issue(s)")

        if not active_issues:
            print("  No active issues remaining. Exiting loop.")
            break

        # Apply patches
        patch_records = apply_patches(active_issues, feedback_items, source_tables)

        # Save iteration refiner log
        refiner_log = {
            'iteration': iteration,
            'timestamp': get_timestamp(),
            'trigger': 'validation_errors + human_feedback' if feedback_items else 'validation_errors',
            'issues_attempted': patch_records,
            'human_feedback_applied': feedback_items if feedback_items else None,
        }
        ts_str = get_timestamp().replace(' ', '_').replace(':', '')
        save_yaml(refiner_log, log_dir / f"iteration_{iteration}_refiner_{ts_str}.yaml")

        applied = [p for p in patch_records if p['status'] == 'applied']
        print(f"  Patches applied: {len(applied)}/{len(patch_records)}")

        # Re-validate
        from validator import run_validation
        new_report, new_report_path = run_validation(
            input_dir=input_dir, output_dir=output_dir,
        )
        new_vr = new_report.get('validation_report', {})
        new_accuracy = new_vr.get('overall_accuracy', 0)
        new_issues = new_vr.get('issues', [])

        # Save iteration validation log
        save_yaml(new_report, log_dir / f"iteration_{iteration}_validation_{ts_str}.yaml")

        # Accuracy progression
        accuracy_progression.append({
            'stage': f'iteration_{iteration}',
            'accuracy': new_accuracy,
            'issues_patched': len(applied),
            'issues_remaining': len(new_issues),
        })

        elapsed = time.time() - start_time
        print(f"  Accuracy: {prev_accuracy}% → {new_accuracy}%")
        print(f"  Issues remaining: {len(new_issues)}")
        print(f"  Elapsed: {elapsed:.1f}s")

        # Check exit conditions
        if not new_issues:
            print("\n  All issues resolved! Exiting loop.")
            break

        if new_accuracy < prev_accuracy:
            print(f"\n  ACCURACY REGRESSION detected ({new_accuracy}% < {prev_accuracy}%). Stopping.")
            break

        if new_accuracy == prev_accuracy:
            # Update stale tracker
            new_issue_ids = {i['id'] for i in new_issues}
            for issue in active_issues:
                if issue['id'] in new_issue_ids:
                    stale_tracker[issue['id']] = stale_tracker.get(issue['id'], 0) + 1

        # Prepare for next iteration
        prev_accuracy = new_accuracy
        issues = new_issues
        report = new_report
        # Only use feedback in the first iteration
        feedback_items = []

    # Save accuracy progression
    save_yaml(
        {'run_id': f"run_{ts_str}", 'progression': accuracy_progression},
        log_dir / f"accuracy_progression_{ts_str}.yaml",
    )

    # Final summary
    final = accuracy_progression[-1]
    print(f"\n{'='*60}")
    print(f"  REFINEMENT COMPLETE")
    print(f"{'='*60}")
    print(f"  Final accuracy: {final['accuracy']}%")
    print(f"  Issues remaining: {final.get('issues_remaining', '?')}")
    print(f"  Iterations run: {len(accuracy_progression) - 1}")
    print(f"  Logs saved to: {log_dir}/")
    print(f"{'='*60}")


def main() -> None:
    """Entry point for the refiner script."""
    parser = argparse.ArgumentParser(
        description='Refine Databricks SQL output based on validation errors'
    )
    parser.add_argument(
        '--report', default=None,
        help='Path to validation report YAML (default: latest in thoughts/logs/agentic/)',
    )
    parser.add_argument(
        '--feedback', default=None,
        help='Path to human feedback text file',
    )
    parser.add_argument(
        '--max-iterations', type=int, default=DEFAULT_MAX_ITERATIONS,
        help=f'Maximum refinement iterations (default: {DEFAULT_MAX_ITERATIONS})',
    )
    parser.add_argument(
        '--input', '-i', default='inputs/sql',
        help='Input directory (default: inputs/sql)',
    )
    parser.add_argument(
        '--output', '-o', default='output',
        help='Output directory (default: output)',
    )
    args = parser.parse_args()

    run_refinement_loop(
        report_path=args.report,
        feedback_path=args.feedback,
        max_iterations=args.max_iterations,
        input_dir=args.input,
        output_dir=args.output,
    )


if __name__ == '__main__':
    main()
