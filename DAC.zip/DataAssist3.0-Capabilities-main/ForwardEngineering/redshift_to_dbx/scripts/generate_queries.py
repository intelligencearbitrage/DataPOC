"""
Query Converter - Converts standalone Redshift SELECT queries to Databricks SQL.

Handles: SELECT statements, CTEs, subqueries, temp table creation (CTAS).
Applies full function translation suite: string, date/time, window, aggregate,
conditional, casting, and Redshift construct removal.

Per knowledgebase/redshift_to_databricks_conversion_guide.pdf.

Usage:
    python scripts/generate_queries.py
"""

import re
import sys
from pathlib import Path
from typing import Any, Dict, List, Tuple

SCRIPTS_DIR = Path(__file__).resolve().parent
sys.path.insert(0, str(SCRIPTS_DIR))

from base_parser import BaseParser
from base_generator import BaseGenerator
from sql_functions import full_sql_convert, apply_construct_removals, apply_catalog_prefix
from utils import get_timestamp


class QueryParser(BaseParser):
    """Parses Redshift SQL files to extract standalone queries."""

    def __init__(self, input_dir: str = 'inputs/sql', output_dir: str = 'output') -> None:
        super().__init__(input_dir=input_dir, output_dir=output_dir)

    def discover_files(self) -> List[Path]:
        return sorted(self.input_dir.glob('*.sql'))

    def parse_file(self, file_path: Path) -> Dict[str, Any]:
        content = file_path.read_text(encoding='utf-8')
        queries = self._extract_queries(content, file_path.name)
        return {'source_file': file_path.name, 'queries': queries}

    def _strip_procedure_bodies(self, sql: str) -> str:
        """Remove content inside $tag$ ... $tag$ blocks (procedure bodies) to avoid false extraction."""
        return re.sub(r'(\$\w*\$).*?\1', '', sql, flags=re.DOTALL)

    def _extract_queries(
        self, sql_content: str, source_file: str
    ) -> List[Dict[str, Any]]:
        """Extract SELECT statements and CTAS from SQL content."""
        queries = []
        # Strip procedure bodies so we don't extract queries from inside stored procedures
        sql_content = self._strip_procedure_bodies(sql_content)
        stmts = self._split_statements(sql_content)

        query_pattern = re.compile(
            r'^\s*(?:WITH\s|SELECT\s|CREATE\s+(?:OR\s+REPLACE\s+)?(?:TEMP(?:ORARY)?\s+)?TABLE\s+\S+\s+(?:USING\s+\w+\s+)?AS\s)',
            re.IGNORECASE,
        )

        # Pattern to detect CTE followed by DML (should go to DML parser, not query)
        cte_dml_pattern = re.compile(
            r'^\s*WITH\b.*\b(INSERT\s+INTO|UPDATE\s|DELETE\s|MERGE\s)\b',
            re.IGNORECASE | re.DOTALL,
        )

        for stmt in stmts:
            stripped = stmt.strip()
            if not stripped or stripped.startswith('--'):
                continue
            if query_pattern.match(stripped):
                # Skip CTEs that end with DML — those belong in the DML pipeline
                if re.match(r'^\s*WITH\b', stripped, re.IGNORECASE) and \
                   cte_dml_pattern.match(stripped):
                    continue

                # Determine type
                if re.match(r'^\s*CREATE\s+TEMP', stripped, re.IGNORECASE):
                    qtype = 'CTAS_TEMP'
                elif re.match(r'^\s*CREATE\s+TABLE', stripped, re.IGNORECASE):
                    qtype = 'CTAS'
                elif re.match(r'^\s*WITH\b', stripped, re.IGNORECASE):
                    qtype = 'CTE'
                else:
                    qtype = 'SELECT'

                queries.append({
                    'type': qtype,
                    'original_sql': stripped,
                    'source_file': source_file,
                })

        return queries

    def _split_statements(self, sql: str) -> List[str]:
        """Split SQL by semicolons, respecting quoted strings and comments."""
        stmts = []
        current = []
        in_single = False
        in_double = False
        in_line_comment = False
        in_block_comment = False
        i = 0
        while i < len(sql):
            char = sql[i]
            next_char = sql[i + 1] if i + 1 < len(sql) else ''
            if in_line_comment:
                current.append(char)
                if char == '\n':
                    in_line_comment = False
            elif in_block_comment:
                current.append(char)
                if char == '*' and next_char == '/':
                    current.append('/')
                    in_block_comment = False
                    i += 1
            elif char == '-' and next_char == '-' and not in_single and not in_double:
                in_line_comment = True
                current.append(char)
            elif char == '/' and next_char == '*' and not in_single and not in_double:
                in_block_comment = True
                current.append(char)
            elif char == "'" and not in_double:
                in_single = not in_single
                current.append(char)
            elif char == '"' and not in_single:
                in_double = not in_double
                current.append(char)
            elif char == ';' and not in_single and not in_double:
                stmts.append(''.join(current))
                current = []
            else:
                current.append(char)
            i += 1
        if current:
            stmts.append(''.join(current))
        return stmts


class QueryGenerator(BaseGenerator):
    """Generates Databricks-compatible queries from Redshift SELECTs."""

    def __init__(self, parsed_data: Dict[str, Any], output_dir: str = 'output', catalog: str = '') -> None:
        super().__init__(plans_dir='plans', output_dir=output_dir, catalog=catalog)
        self.parsed_data = parsed_data
        self.generated_files: List[Dict[str, Any]] = []

    def generate(self) -> None:
        timestamp = get_timestamp()

        for file_key, file_data in self.parsed_data.items():
            source_file = file_data.get('source_file', file_key)
            queries = file_data.get('queries', [])
            if not queries:
                continue

            converted_queries = []
            total_conversions = 0
            for query in queries:
                converted, conversions = self._convert_query(query)
                converted_queries.append({
                    'converted_sql': converted,
                    'original_type': query['type'],
                    'conversions': conversions,
                })
                total_conversions += len(conversions)

            output_content = self._build_output(
                converted_queries, source_file, timestamp
            )
            output_path = f"sql/queries/{Path(source_file).stem}_converted.sql"
            self.save_output(output_content, output_path)
            self.generated_files.append({
                'source_file': source_file,
                'output_file': str(self.output_dir / output_path),
                'queries_converted': len(converted_queries),
                'conversions_applied': total_conversions,
            })

        self.logger.info(f"Generated {len(self.generated_files)} query file(s)")

    def _convert_query(
        self, query: Dict[str, Any]
    ) -> Tuple[str, List[str]]:
        """Convert a single query to Databricks SQL."""
        sql = query['original_sql']
        qtype = query['type']
        all_conversions = []

        # Handle CTAS_TEMP: CREATE TEMP TABLE -> CREATE OR REPLACE TEMPORARY VIEW
        if qtype == 'CTAS_TEMP':
            sql, temp_convs = self._convert_temp_table(sql)
            all_conversions.extend(temp_convs)

        # Handle CTAS: add USING DELTA
        elif qtype == 'CTAS':
            sql, ctas_convs = self._convert_ctas(sql)
            all_conversions.extend(ctas_convs)

        # Handle WITH RECURSIVE (supported in Databricks, but note it)
        if re.match(r'^\s*WITH\s+RECURSIVE\b', sql, re.IGNORECASE):
            all_conversions.append('CTE: WITH RECURSIVE -> supported in Databricks (identical syntax)')

        # Apply full function/construct conversion (handles TOP n, MINUS, etc.)
        sql, fn_convs = full_sql_convert(sql)
        all_conversions.extend(fn_convs)

        # Apply Unity Catalog prefix to table references
        sql, cat_convs = apply_catalog_prefix(sql, self.catalog)
        all_conversions.extend(cat_convs)

        return sql, all_conversions

    def _convert_temp_table(self, sql: str) -> Tuple[str, List[str]]:
        """Convert CREATE TEMP TABLE ... AS to CREATE OR REPLACE TEMPORARY VIEW."""
        conversions = ['CTAS: CREATE TEMP TABLE -> CREATE OR REPLACE TEMPORARY VIEW']
        sql = re.sub(
            r'\bCREATE\s+(?:TEMP(?:ORARY)?\s+)?TABLE\s+#?(\S+)\s+AS\b',
            r'CREATE OR REPLACE TEMPORARY VIEW \1 AS',
            sql,
            flags=re.IGNORECASE,
        )
        return sql, conversions

    def _convert_ctas(self, sql: str) -> Tuple[str, List[str]]:
        """Convert CTAS: add USING DELTA, remove DISTKEY/SORTKEY."""
        conversions = []

        # Remove DISTKEY/SORTKEY from CTAS
        sql, removals = apply_construct_removals(sql)
        conversions.extend(removals)

        # Add USING DELTA before AS
        if 'USING DELTA' not in sql.upper():
            sql = re.sub(
                r'\bAS\s+(SELECT\b)',
                r'USING DELTA AS \1',
                sql,
                flags=re.IGNORECASE,
                count=1,
            )
            conversions.append('CTAS: Added USING DELTA')

        # Add CREATE OR REPLACE
        if 'OR REPLACE' not in sql.upper():
            sql = re.sub(
                r'\bCREATE\s+TABLE\b',
                'CREATE OR REPLACE TABLE',
                sql,
                flags=re.IGNORECASE,
                count=1,
            )
            conversions.append('CTAS: Added OR REPLACE')

        return sql, conversions

    def _build_output(
        self,
        converted_queries: List[Dict[str, Any]],
        source_file: str,
        timestamp: str,
    ) -> str:
        """Build the output SQL file content."""
        lines = [
            f"-- Databricks queries converted from: {source_file}",
            f"-- Converted on: {timestamp}",
            "-- Conversion rules: knowledgebase/redshift_to_databricks_conversion_guide.pdf",
            "",
        ]

        for i, query in enumerate(converted_queries, 1):
            conversions = query.get('conversions', [])
            if conversions:
                lines.append(f"-- Query {i} ({query['original_type']}) conversions:")
                for c in conversions:
                    lines.append(f"--   {c}")
            lines.append(query['converted_sql'] + ";")
            lines.append("")

        return '\n'.join(lines)


def main() -> None:
    parser = QueryParser()
    parser.parse_all()
    generator = QueryGenerator(parser.parsed_data)
    generator.generate()
    print(f"Query conversion complete: {len(generator.generated_files)} file(s) generated")


if __name__ == '__main__':
    main()
