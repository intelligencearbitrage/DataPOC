"""
Post-Conversion Merge — Merges output files from the same source when they
span multiple converter types (e.g., a source file with both DDL and DML).

Pure single-type files (all DDLs, all views) are kept split per entity.
Mixed-type files are merged into output/sql/combined/{stem}_converted.sql.

Usage:
    from post_conv_merge import merge_split_outputs
"""

import re
from pathlib import Path
from typing import Any, Dict, List

from utils import get_timestamp


# ---------------------------------------------------------------------------
# Dependency detection
# ---------------------------------------------------------------------------

def _detect_dependencies(source_path: Path) -> Dict[str, Any]:
    """Analyze a source SQL file to detect inter-statement dependencies.

    Checks for:
    - BEGIN TRANSACTION / END TRANSACTION blocks
    - Temp table creation followed by references in later statements
    - Variable assignments followed by usage
    """
    content = source_path.read_text(encoding='utf-8')
    reasons = []

    has_begin = bool(re.search(r'\bBEGIN\s+(?:TRANSACTION|WORK)\b', content, re.IGNORECASE))
    has_end = bool(re.search(r'\bEND\s+(?:TRANSACTION|WORK)\b', content, re.IGNORECASE))
    if has_begin or has_end:
        reasons.append('Transaction block (BEGIN/END TRANSACTION)')

    temp_tables = re.findall(
        r'\bCREATE\s+(?:TEMP(?:ORARY)?\s+)?TABLE\s+#?(\S+)\s+AS\b',
        content, re.IGNORECASE,
    )
    for tbl in temp_tables:
        create_pos = re.search(
            rf'\bCREATE\s+(?:TEMP(?:ORARY)?\s+)?TABLE\s+#?{re.escape(tbl)}\s+AS\b',
            content, re.IGNORECASE,
        )
        if create_pos:
            after_create = content[create_pos.end():]
            if re.search(rf'\b{re.escape(tbl)}\b', after_create, re.IGNORECASE):
                reasons.append(f'Temp table "{tbl}" created and referenced by later statements')

    has_get_diagnostics = bool(re.search(r'\bGET\s+DIAGNOSTICS\b', content, re.IGNORECASE))
    if has_get_diagnostics:
        reasons.append('GET DIAGNOSTICS (variable dependency between statements)')

    return {
        'dependent': len(reasons) > 0,
        'reasons': reasons,
    }


# ---------------------------------------------------------------------------
# Source file grouping
# ---------------------------------------------------------------------------

def _find_output_files_by_source(output_dir: Path) -> Dict[str, List[Path]]:
    """Group output SQL files by their source file.

    Reads header comments to determine which source file produced each output.
    """
    source_map: Dict[str, List[Path]] = {}
    source_patterns = [
        re.compile(r'converted from:\s*(\S+)', re.IGNORECASE),
        re.compile(r'^-- Source:\s*(\S+)', re.IGNORECASE),
    ]
    for sql_file in sorted(output_dir.rglob('*.sql')):
        if sql_file.parent.name == 'combined':
            continue
        try:
            content = sql_file.read_text(encoding='utf-8')
        except Exception:
            continue
        found = False
        for line in content.split('\n')[:10]:
            for pattern in source_patterns:
                m = pattern.search(line)
                if m:
                    source_name = m.group(1)
                    source_map.setdefault(source_name, []).append(sql_file)
                    found = True
                    break
            if found:
                break
    return source_map


# ---------------------------------------------------------------------------
# Merge helpers
# ---------------------------------------------------------------------------

def _get_statement_order_key(output_file: Path) -> int:
    """Return a sort key for ordering merged output: DDL first, then queries, etc."""
    parent = output_file.parent.name
    order = {'ddl': 0, 'queries': 1, 'views': 2, 'dml': 3}
    return order.get(parent, 99)


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def merge_split_outputs(
    output_dir: Path, input_path: str
) -> Dict[str, Any]:
    """Merge output files that came from the same source file when they span multiple converter types.

    Rules:
    - Pure single-type files (only DDLs, only views, only SPs) -> keep split per entity
    - Mixed-type files (DDL+DML, CTAS+DML, any combo) -> merge into single output
    - Output name matches input name: {stem}_converted.sql
    """
    source_map = _find_output_files_by_source(output_dir)
    merge_summary: Dict[str, Any] = {'merged': [], 'kept_split': []}

    for source_name, output_files in source_map.items():
        if len(output_files) <= 1:
            continue

        converter_types = set(f.parent.name for f in output_files)

        if len(converter_types) <= 1:
            merge_summary['kept_split'].append({
                'source': source_name,
                'type': next(iter(converter_types)),
                'file_count': len(output_files),
            })
            continue

        # Mixed types — merge into single output file
        input_p = Path(input_path)
        source_candidates = list(input_p.rglob(source_name)) if input_p.is_dir() else []
        if not source_candidates:
            stem = Path(source_name).stem
            source_candidates = list(input_p.rglob(f'{stem}.sql')) if input_p.is_dir() else []

        if source_candidates:
            dep_info = _detect_dependencies(source_candidates[0])
        else:
            dep_info = {'dependent': False, 'reasons': []}

        sorted_files = sorted(output_files, key=_get_statement_order_key)

        stem = Path(source_name).stem
        merged_path = output_dir / 'sql' / 'combined' / f'{stem}_converted.sql'
        merged_path.parent.mkdir(parents=True, exist_ok=True)

        timestamp = get_timestamp()
        type_labels = sorted(converter_types)
        merged_lines = [
            f"-- Databricks SQL converted from: {source_name}",
            f"-- Converted on: {timestamp}",
            "-- Conversion rules: knowledgebase/redshift_to_databricks_conversion_guide.pdf",
            f"-- NOTE: Contains {', '.join(t.upper() for t in type_labels)} statements",
        ]
        if dep_info['reasons']:
            for reason in dep_info['reasons']:
                merged_lines.append(f"--   Dependency: {reason}")
        merged_lines.append("")

        for out_file in sorted_files:
            content = out_file.read_text(encoding='utf-8')
            body_lines = []
            past_header = False
            for line in content.split('\n'):
                if not past_header:
                    if line.startswith('--') or not line.strip():
                        if (line.startswith('-- Statement') or
                            line.startswith('-- Query') or
                            line.startswith('-- NOTE:') or
                            line.startswith('-- Data type conversions') or
                            line.startswith('-- Conversions applied') or
                            line.startswith('--   ')):
                            past_header = True
                            body_lines.append(line)
                        continue
                    else:
                        past_header = True
                        body_lines.append(line)
                else:
                    body_lines.append(line)

            if body_lines:
                folder_name = out_file.parent.name
                merged_lines.append(f"-- [{folder_name.upper()}] from {out_file.name}")
                merged_lines.extend(body_lines)
                if body_lines[-1].strip() != '':
                    merged_lines.append("")

        merged_path.write_text('\n'.join(merged_lines), encoding='utf-8')

        for out_file in output_files:
            if out_file.resolve() == merged_path.resolve():
                continue
            out_file.unlink()
            try:
                out_file.parent.rmdir()
            except OSError:
                pass

        merge_summary['merged'].append({
            'source': source_name,
            'merged_to': str(merged_path),
            'from_files': [str(f) for f in sorted_files],
            'converter_types': sorted(converter_types),
            'dependency_info': dep_info,
        })

    return merge_summary
