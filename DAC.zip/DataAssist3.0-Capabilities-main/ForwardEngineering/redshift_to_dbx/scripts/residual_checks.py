"""
Lightweight Residual Redshift Syntax Checker.

Scans output SQL files for residual Redshift syntax patterns that should
have been converted to Databricks equivalents. Used by convert.py Stage 2
(--validate) for a quick pass before the deeper agentic validator.

Usage:
    from residual_checks import validate_output_file, validate_output_dir
"""

import re
from pathlib import Path
from typing import Dict, List, Tuple


# ---------------------------------------------------------------------------
# Compiled patterns for residual Redshift syntax detection
# ---------------------------------------------------------------------------

REDSHIFT_RESIDUAL_PATTERNS: List[Tuple[re.Pattern, str]] = [
    (re.compile(r'\btimestamptz\b', re.IGNORECASE), 'TIMESTAMPTZ'),
    (re.compile(r'\btimestamp\s+with\s+time\s+zone\b', re.IGNORECASE), 'TIMESTAMP WITH TIME ZONE'),
    (re.compile(r'\bbpchar\b', re.IGNORECASE), 'BPCHAR'),
    (re.compile(r'\bnumeric\s*\(', re.IGNORECASE), 'NUMERIC('),
    (re.compile(r'\bdistkey\b', re.IGNORECASE), 'DISTKEY'),
    (re.compile(r'\bdiststyle\b', re.IGNORECASE), 'DISTSTYLE'),
    (re.compile(r'\bsortkey\b', re.IGNORECASE), 'SORTKEY'),
    (re.compile(r'\bencode\b', re.IGNORECASE), 'ENCODE'),
    (re.compile(r'\bGETDATE\s*\(\s*\)', re.IGNORECASE), 'GETDATE()'),
    (re.compile(r'\bSYSDATE\b', re.IGNORECASE), 'SYSDATE'),
    (re.compile(r'\bNVL\s*\(', re.IGNORECASE), 'NVL('),
    (re.compile(r'\w+::\w+', re.IGNORECASE), ':: cast syntax'),
    (re.compile(r'\bLISTAGG\s*\(', re.IGNORECASE), 'LISTAGG()'),
    (re.compile(r'\bIDENTITY\s*\(', re.IGNORECASE), 'IDENTITY()'),
    (re.compile(r'\bstl_\w+\b', re.IGNORECASE), 'STL_ system table'),
    (re.compile(r'\bstv_\w+\b', re.IGNORECASE), 'STV_ system table'),
    (re.compile(r'\bsvv_\w+\b', re.IGNORECASE), 'SVV_ system table'),
    (re.compile(r'\bsvl_\w+\b', re.IGNORECASE), 'SVL_ system table'),
    (re.compile(r'\bLEN\s*\(', re.IGNORECASE), 'LEN()'),
    (re.compile(r'\bSTRPOS\s*\(', re.IGNORECASE), 'STRPOS()'),
    (re.compile(r'\bCHARINDEX\s*\(', re.IGNORECASE), 'CHARINDEX()'),
    (re.compile(r'\bCONVERT_TIMEZONE\s*\(', re.IGNORECASE), 'CONVERT_TIMEZONE()'),
    (re.compile(r'\bPERFORM\s+', re.IGNORECASE), 'PERFORM (PL/pgSQL)'),
    (re.compile(r'\bVACUUM\b', re.IGNORECASE), 'VACUUM'),
    (re.compile(r'\bBTRIM\s*\(', re.IGNORECASE), 'BTRIM()'),
    (re.compile(r'\bPOSITION\s*\(.+?\s+IN\s+', re.IGNORECASE), 'POSITION(x IN y)'),
    (re.compile(r'\bNVARCHAR\b', re.IGNORECASE), 'NVARCHAR'),
    (re.compile(r'\bNCHAR\b', re.IGNORECASE), 'NCHAR'),
    (re.compile(r'\bQUALIFY\b', re.IGNORECASE), 'QUALIFY clause'),
    (re.compile(r'\bEXCEPTION\s+WHEN\b', re.IGNORECASE), 'PL/pgSQL EXCEPTION block'),
    (re.compile(r"=\s*'[tf]'\s*(?:;|AND|OR|\)|$)", re.IGNORECASE), "Boolean literal 't'/'f' (Databricks is stricter)"),
]


def validate_output_file(ddl_path: Path) -> List[Dict[str, str]]:
    """Validate a single output file for Databricks compliance."""
    issues: List[Dict[str, str]] = []
    content = ddl_path.read_text(encoding='utf-8')
    name = ddl_path.name

    # Check for residual Redshift syntax (skip comments — SQL and Jinja style)
    for line in content.split('\n'):
        stripped = line.strip()
        if stripped.startswith('--') or stripped.startswith('{#'):
            continue
        for pattern, label in REDSHIFT_RESIDUAL_PATTERNS:
            if pattern.search(line):
                issues.append({
                    'file': name,
                    'severity': 'HIGH',
                    'issue': f'Residual Redshift syntax: {label}',
                })

    # DDL-specific checks (skip for TEMPORARY VIEW — converted from TEMP TABLE)
    if ddl_path.parent.name == 'ddl' and 'TEMPORARY VIEW' not in content.upper():
        if 'USING DELTA' not in content:
            issues.append({'file': name, 'severity': 'HIGH', 'issue': 'Missing USING DELTA'})
        if 'IF NOT EXISTS' not in content.upper():
            issues.append({'file': name, 'severity': 'HIGH', 'issue': 'Missing IF NOT EXISTS'})

    # Traceability comment check (SQL -- or Jinja {# style)
    has_traceability = ('-- Source:' in content or '-- Converted' in content
                        or '{# Source:' in content or '{# Converted' in content)
    if not has_traceability:
        issues.append({'file': name, 'severity': 'MEDIUM', 'issue': 'Missing traceability comment'})

    return issues


def validate_output_dir(output_dir: Path) -> List[Dict[str, str]]:
    """Validate all SQL files in the output directory tree."""
    all_issues = []
    for sql_file in sorted(output_dir.rglob('*.sql')):
        issues = validate_output_file(sql_file)
        all_issues.extend(issues)
    return all_issues
