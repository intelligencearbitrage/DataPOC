#!/usr/bin/env python3
"""
Redshift-to-Databricks Converter CLI

Converts Redshift SQL artifacts to Databricks-compatible equivalents.
Supports DDL, DML, Views, Materialized Views, Stored Procedures, Queries
(Workstream 1) and full dbt project migration (Workstream 2).

Usage:
    # Convert DDL files
    python scripts/cli.py -i path/to/sql_files/ -o converted/ --type ddl

    # Convert all SQL types at once
    python scripts/cli.py -i path/to/sql_files/ -o converted/ --type all

    # Convert DML files with validation
    python scripts/cli.py -i path/to/dml_files/ -o converted/ --type dml --validate

    # Migrate a dbt project
    python scripts/cli.py -i path/to/dbt_project/ -o converted/ --type dbt

    # Dry run (show what would be converted)
    python scripts/cli.py -i path/to/sql_files/ --type all --dry-run

    # Full conversion with validation and migration report
    python scripts/cli.py -i path/to/sql_files/ -o converted/ --type all --validate --report

    # Full pipeline: both workstreams + agentic validation/refinement + report
    python scripts/cli.py -i inputs/ -o output/ --type both --refine --report
"""

import argparse
import glob
import re
import shutil
import sys
import tempfile
import time
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

# Ensure scripts/ is on the Python path
SCRIPTS_DIR = Path(__file__).resolve().parent
PROJECT_ROOT = SCRIPTS_DIR.parent
sys.path.insert(0, str(SCRIPTS_DIR))

from utils import get_timestamp

# Lazy imports for converters (only import what's needed)
CONVERTER_TYPES = ['ddl', 'dml', 'views', 'procedures', 'queries', 'dbt', 'all', 'both']


def _sanitize_path(raw: str, allowed_base: Path) -> Path:
    """Resolve a user-supplied path, anchored to allowed_base, rejecting traversal."""
    if not raw:
        raise ValueError("Empty path")
    safe = re.sub(r'[^\w.\-/\\ ]', '', raw)
    if safe != raw:
        raise ValueError(f"Path contains disallowed characters: {raw!r}")
    if '..' in safe.replace('\\', '/').split('/'):
        raise ValueError(f"Path traversal blocked: {raw!r}")
    candidate = (allowed_base / safe).resolve()
    if not candidate.is_relative_to(allowed_base.resolve()):
        raise ValueError(
            f"Path traversal blocked: {raw!r} escapes {allowed_base}"
        )
    return candidate


# =========================================================================
# Input Resolution
# =========================================================================

def resolve_input_files(input_path: str, file_ext: str = '.sql') -> List[Path]:
    """Resolve input path to a list of files (supports file, dir, glob)."""
    if '*' in input_path or '?' in input_path:
        matches = sorted(glob.glob(input_path, recursive=True))
        return [Path(m) for m in matches if m.endswith(file_ext)]

    p = Path(input_path)
    if p.is_file():
        return [p]
    elif p.is_dir():
        files = sorted(p.glob(f'*{file_ext}'))
        if not files:
            files = sorted(p.rglob(f'*{file_ext}'))
        return files
    else:
        print(f"Error: {input_path} does not exist")
        return []


# =========================================================================
# Converter Runners
# =========================================================================

def run_ddl_conversion(input_path: str, output_dir: str, catalog: str = '') -> Dict[str, Any]:
    """Run DDL conversion."""
    from generate_ddl import DDLParser, DDLGenerator

    input_files = resolve_input_files(input_path)
    if not input_files:
        return {'files_generated': 0, 'conversions_applied': 0}

    with tempfile.TemporaryDirectory() as tmp_input:
        for f in input_files:
            shutil.copy2(f, Path(tmp_input) / f.name)

        parser = DDLParser(input_dir=tmp_input, output_dir=output_dir)
        parser.parse_all()

        if not parser.parsed_data:
            return {'files_generated': 0, 'conversions_applied': 0}

        generator = DDLGenerator(parser.parsed_data, output_dir=output_dir, catalog=catalog)
        generator.generate()

    total_conversions = sum(
        g.get('conversions_applied', 0) for g in generator.generated_files
    )
    return {
        'files_generated': len(generator.generated_files),
        'conversions_applied': total_conversions,
        'details': generator.generated_files,
    }


def run_dml_conversion(input_path: str, output_dir: str, catalog: str = '') -> Dict[str, Any]:
    """Run DML conversion."""
    from generate_dml import DMLParser, DMLGenerator

    input_files = resolve_input_files(input_path)
    if not input_files:
        return {'files_generated': 0, 'conversions_applied': 0}

    with tempfile.TemporaryDirectory() as tmp_input:
        for f in input_files:
            shutil.copy2(f, Path(tmp_input) / f.name)

        parser = DMLParser(input_dir=tmp_input, output_dir=output_dir)
        parser.parse_all()

        if not parser.parsed_data:
            return {'files_generated': 0, 'conversions_applied': 0}

        generator = DMLGenerator(parser.parsed_data, output_dir=output_dir, catalog=catalog)
        generator.generate()

    total_conversions = sum(
        g.get('conversions_applied', 0) for g in generator.generated_files
    )
    return {
        'files_generated': len(generator.generated_files),
        'conversions_applied': total_conversions,
        'details': generator.generated_files,
    }


def run_views_conversion(input_path: str, output_dir: str, catalog: str = '') -> Dict[str, Any]:
    """Run View/MV conversion."""
    from generate_views import ViewParser, ViewGenerator

    input_files = resolve_input_files(input_path)
    if not input_files:
        return {'files_generated': 0, 'conversions_applied': 0}

    with tempfile.TemporaryDirectory() as tmp_input:
        for f in input_files:
            shutil.copy2(f, Path(tmp_input) / f.name)

        parser = ViewParser(input_dir=tmp_input, output_dir=output_dir)
        parser.parse_all()

        if not parser.parsed_data:
            return {'files_generated': 0, 'conversions_applied': 0}

        generator = ViewGenerator(parser.parsed_data, output_dir=output_dir, catalog=catalog)
        generator.generate()

    total_conversions = sum(
        g.get('conversions_applied', 0) for g in generator.generated_files
    )
    return {
        'files_generated': len(generator.generated_files),
        'conversions_applied': total_conversions,
        'details': generator.generated_files,
    }


def run_procedures_conversion(input_path: str, output_dir: str, catalog: str = '') -> Dict[str, Any]:
    """Run Stored Procedure conversion."""
    from generate_procedures import ProcedureParser, ProcedureGenerator

    input_files = resolve_input_files(input_path)
    if not input_files:
        return {'files_generated': 0, 'conversions_applied': 0}

    with tempfile.TemporaryDirectory() as tmp_input:
        for f in input_files:
            shutil.copy2(f, Path(tmp_input) / f.name)

        parser = ProcedureParser(input_dir=tmp_input, output_dir=output_dir)
        parser.parse_all()

        if not parser.parsed_data:
            return {'files_generated': 0, 'conversions_applied': 0}

        generator = ProcedureGenerator(parser.parsed_data, output_dir=output_dir, catalog=catalog)
        generator.generate()

    total_conversions = sum(
        g.get('conversions_applied', 0) for g in generator.generated_files
    )
    return {
        'files_generated': len(generator.generated_files),
        'conversions_applied': total_conversions,
        'details': generator.generated_files,
    }


def run_queries_conversion(input_path: str, output_dir: str, catalog: str = '') -> Dict[str, Any]:
    """Run Query/SELECT conversion."""
    from generate_queries import QueryParser, QueryGenerator

    input_files = resolve_input_files(input_path)
    if not input_files:
        return {'files_generated': 0, 'conversions_applied': 0}

    with tempfile.TemporaryDirectory() as tmp_input:
        for f in input_files:
            shutil.copy2(f, Path(tmp_input) / f.name)

        parser = QueryParser(input_dir=tmp_input, output_dir=output_dir)
        parser.parse_all()

        if not parser.parsed_data:
            return {'files_generated': 0, 'conversions_applied': 0}

        generator = QueryGenerator(parser.parsed_data, output_dir=output_dir, catalog=catalog)
        generator.generate()

    total_conversions = sum(
        g.get('conversions_applied', 0) for g in generator.generated_files
    )
    return {
        'files_generated': len(generator.generated_files),
        'conversions_applied': total_conversions,
        'details': generator.generated_files,
    }


def run_dbt_conversion(input_path: str, output_dir: str, catalog: str = '') -> Dict[str, Any]:
    """Run dbt project migration."""
    from generate_dbt import DbtParser, DbtGenerator

    p = Path(input_path)
    if not p.is_dir():
        print(f"Error: dbt conversion requires a directory. Got: {input_path}")
        return {'files_generated': 0, 'conversions_applied': 0}

    parser = DbtParser(input_dir=input_path, output_dir=output_dir)
    parser.parse_all()

    if not parser.parsed_data:
        return {'files_generated': 0, 'conversions_applied': 0}

    generator = DbtGenerator(parser.parsed_data, output_dir=output_dir, catalog=catalog)
    generator.generate()

    total_conversions = sum(
        g.get('conversions_applied', 0) for g in generator.generated_files
    )
    return {
        'files_generated': len(generator.generated_files),
        'conversions_applied': total_conversions,
        'details': generator.generated_files,
    }


# =========================================================================
# Core Pipeline
# =========================================================================

RUNNER_MAP = {
    'ddl': run_ddl_conversion,
    'dml': run_dml_conversion,
    'views': run_views_conversion,
    'procedures': run_procedures_conversion,
    'queries': run_queries_conversion,
    'dbt': run_dbt_conversion,
}


def _run_single_workstream(
    input_path: str,
    output_dir: str,
    conv_type: str,
    results: Dict[str, Any],
    catalog: str = '',
) -> None:
    """Run converters for a single workstream (sql types or dbt)."""
    from post_conv_merge import merge_split_outputs

    if conv_type == 'dbt':
        types_to_run = ['dbt']
    elif conv_type == 'all':
        types_to_run = ['ddl', 'dml', 'views', 'procedures', 'queries']
        if Path(input_path).is_dir() and (
            (Path(input_path) / 'dbt_project.yml').exists()
        ):
            types_to_run.append('dbt')
    else:
        types_to_run = [conv_type]

    out_path = Path(output_dir)
    for ctype in types_to_run:
        runner = RUNNER_MAP.get(ctype)
        if not runner:
            print(f"  WARNING: Unknown type '{ctype}', skipping")
            continue
        print(f"  Running {ctype} conversion...")
        result = runner(input_path, output_dir, catalog=catalog)
        results[ctype] = result
        if result['files_generated'] > 0:
            print(f"    {ctype}: {result['files_generated']} file(s), "
                  f"{result['conversions_applied']} conversion(s)")
        else:
            print(f"    {ctype}: No matching statements found")

    # Post-conversion merge for multi-type SQL workstream
    if conv_type in ('all', 'both') and len(types_to_run) > 1 and 'dbt' not in types_to_run:
        print(f"\n  Checking for mixed-type inputs to merge...")
        merge_info = merge_split_outputs(out_path, input_path)
        if merge_info['merged']:
            print(f"    Merged {len(merge_info['merged'])} mixed-type file(s):")
            for m in merge_info['merged']:
                types_str = '+'.join(t.upper() for t in m['converter_types'])
                print(f"      {m['source']} ({types_str}) -> {Path(m['merged_to']).name}")
        if merge_info['kept_split']:
            for k in merge_info['kept_split']:
                print(f"    Kept split: {k['source']} ({k['file_count']} {k['type']} files)")
        if not merge_info['merged'] and not merge_info['kept_split']:
            print(f"    No multi-output files found")


def _run_agentic_validation(input_dir: str, output_dir: str) -> Tuple[Dict[str, Any], Optional[Path]]:
    """Run agentic validator (scripts/validator.py) and return (report, report_path)."""
    from validator import run_validation
    print(f"\n{'='*60}")
    print(f"  AGENTIC VALIDATION")
    print(f"{'='*60}")
    report, report_path = run_validation(input_dir=input_dir, output_dir=output_dir)
    return report, report_path


def _run_agentic_refinement(
    report_path: Optional[Path],
    input_dir: str,
    output_dir: str,
    max_iterations: int = 3,
) -> None:
    """Run agentic refiner (scripts/refiner.py) to auto-fix validation issues."""
    from refiner import run_refinement_loop
    print(f"\n{'='*60}")
    print(f"  AGENTIC REFINEMENT")
    print(f"{'='*60}")
    safe_report = str(_sanitize_path(str(report_path), PROJECT_ROOT)) if report_path else None
    run_refinement_loop(
        report_path=safe_report,
        max_iterations=max_iterations,
        input_dir=input_dir,
        output_dir=output_dir,
    )


def run_conversion(
    input_path: str,
    output_dir: str,
    conv_type: str = 'all',
    validate: bool = False,
    report: bool = False,
    dry_run: bool = False,
    ref_dir: Optional[str] = None,
    refine: bool = False,
    max_iterations: int = 3,
    plan: bool = False,
    catalog: str = '',
    skip_convert: bool = False,
) -> int:
    """Run the full conversion pipeline. Returns exit code (0=success).

    Pipeline stages:
      0. Plan     — generate conversion plan (--plan)
      1. Convert  — run the appropriate converter(s) (skipped if --skip-convert)
      1.5 Coverage — coverage analysis
      2. Validate — lightweight residual-syntax check (--validate)
      3. Agentic Validate + Refine — deep validation & auto-patch loop (--refine)
      4. Reference validation (--validate-against)
      5. Report   — migration report (--report)

    When conv_type='both', runs Workstream 1 (inputs/sql) and Workstream 2
    (inputs/dbt_project) sequentially in one command.
    """
    start_time = time.time()
    project_root = PROJECT_ROOT

    try:
        _sanitize_path(input_path, project_root)
    except ValueError as e:
        print(f"Error: Invalid input path: {e}")
        return 1
    try:
        out_path = _sanitize_path(output_dir, project_root)
    except ValueError as e:
        print(f"Error: Invalid output path: {e}")
        return 1
    if ref_dir:
        try:
            _sanitize_path(ref_dir, project_root)
        except ValueError as e:
            print(f"Error: Invalid reference directory path: {e}")
            return 1

    print(f"\n{'='*60}")
    print(f"  Redshift -> Databricks Converter")
    print(f"{'='*60}")
    print(f"  Input:   {input_path}")
    print(f"  Output:  {out_path}")
    print(f"  Type:    {conv_type}")
    if catalog:
        print(f"  Catalog: {catalog}")
    if plan:
        print(f"  Plan:    ON")
    if refine:
        print(f"  Refine:  ON (max {max_iterations} iterations)")
    if dry_run:
        print(f"  Mode:    DRY RUN")
    if skip_convert:
        print(f"  Mode:    SKIP CONVERSION (validate existing output)")
    print(f"{'='*60}\n")

    # ------------------------------------------------------------------
    # STAGE 0: Plan generation (--plan)
    # ------------------------------------------------------------------
    if plan:
        from generate_plan import generate_plan as _generate_plan
        print(f"  Generating conversion plan...")
        plan_path = _generate_plan(input_path, output_dir, conv_type)
        print(f"  Plan saved: {plan_path}\n")

    # Dry run
    if dry_run:
        return _dry_run(input_path, conv_type)

    # ------------------------------------------------------------------
    # STAGE 1: Conversion (skipped if --skip-convert)
    # ------------------------------------------------------------------
    results: Dict[str, Any] = {}

    if skip_convert:
        existing_files = list(out_path.rglob('*.sql')) + list(out_path.rglob('*.yml'))
        total_files = len(existing_files)
        if total_files == 0:
            print(f"\n  No existing output files found in {out_path}. Run conversion first.")
            return 1
        print(f"  Skipping conversion — found {total_files} existing output file(s)")
    else:
        if conv_type == 'both':
            sql_input = str(project_root / 'inputs' / 'sql')
            if Path(sql_input).is_dir():
                print(f"\n  === WORKSTREAM 1: Standalone SQL ===")
                print(f"  Input: {sql_input}\n")
                _run_single_workstream(sql_input, output_dir, 'all', results, catalog=catalog)
            else:
                print(f"\n  Skipping Workstream 1: {sql_input} not found")

            dbt_input = str(project_root / 'inputs' / 'dbt_project')
            if Path(dbt_input).is_dir() and (Path(dbt_input) / 'dbt_project.yml').exists():
                print(f"\n  === WORKSTREAM 2: dbt Project ===")
                print(f"  Input: {dbt_input}\n")
                _run_single_workstream(dbt_input, output_dir, 'dbt', results, catalog=catalog)
            else:
                print(f"\n  Skipping Workstream 2: {dbt_input} not found or no dbt_project.yml")
        else:
            _run_single_workstream(input_path, output_dir, conv_type, results, catalog=catalog)

        total_files = sum(r.get('files_generated', 0) for r in results.values())

        if total_files == 0:
            print("\n  No files generated. Check your input path and --type flag.")
            return 1

    # ------------------------------------------------------------------
    # STAGE 1.5: Coverage analysis
    # ------------------------------------------------------------------
    from generate_coverage_report import (
        analyze_coverage, generate_coverage_report,
        analyze_dbt_coverage, generate_dbt_coverage_section,
    )

    coverage: Dict[str, Any] = {}
    dbt_coverage: Dict[str, Any] = {}
    if validate or report or ref_dir or skip_convert:
        print(f"\n  Running coverage analysis...")

        # WS1: SQL statement-level coverage
        ws1_input = input_path
        if conv_type == 'both':
            ws1_input = str(project_root / 'inputs' / 'sql')
        if conv_type in ('all', 'both', 'ddl', 'dml', 'views', 'procedures', 'queries'):
            if Path(ws1_input).is_dir():
                coverage = analyze_coverage(ws1_input, out_path)
                cs = coverage.get('summary', {})
                print(f"\n    === WS1: Standalone SQL ===")
                print(f"    Files: {cs.get('total_files', 0)} scanned, "
                      f"{cs.get('files_with_output', 0)} with output, "
                      f"{cs.get('files_without_output', 0)} without output")
                print(f"    Statements: {cs.get('total_statements', 0)} total, "
                      f"{cs.get('covered_statements', 0)} covered, "
                      f"{cs.get('uncovered_statements', 0)} uncovered")
                print(f"    Coverage: {cs.get('coverage_pct', 100)}%")

                no_output = [f for f in coverage.get('files', []) if not f['has_output']]
                if no_output:
                    print(f"\n    WARNING: {len(no_output)} file(s) produced NO output:")
                    for f in no_output:
                        print(f"      - {f['file']}")

                uncovered_files = [f for f in coverage.get('files', []) if f['uncovered_blocks']]
                if uncovered_files:
                    total_unc = sum(f['uncovered'] for f in uncovered_files)
                    print(f"\n    WARNING: {total_unc} SQL block(s) not matched by any parser:")
                    for f in uncovered_files:
                        for blk in f['uncovered_blocks']:
                            print(f"      - {f['file']}:~{blk['line']}: {blk['preview'][:80]}")

        # WS2: dbt file-level coverage
        dbt_input = input_path
        if conv_type == 'both':
            dbt_input = str(project_root / 'inputs' / 'dbt_project')
        if conv_type in ('dbt', 'both'):
            if Path(dbt_input).is_dir():
                dbt_coverage = analyze_dbt_coverage(dbt_input, out_path)
                ds = dbt_coverage.get('summary', {})
                print(f"\n    === WS2: dbt Project ===")
                print(f"    Files: {ds.get('total_input_files', 0)} input, "
                      f"{ds.get('matched', 0)} matched, "
                      f"{ds.get('missing_output', 0)} missing output, "
                      f"{ds.get('extra_output', 0)} extra output")
                print(f"    Coverage: {ds.get('coverage_pct', 100)}%")

                missing_dbt = [f for f in dbt_coverage.get('files', [])
                               if f['status'] == 'MISSING_OUTPUT']
                if missing_dbt:
                    print(f"\n    WARNING: {len(missing_dbt)} dbt input file(s) have NO output:")
                    for f in missing_dbt:
                        print(f"      - {f['rel_path']}")

        # Save coverage report
        cov_parts = []
        if coverage:
            cov_parts.append(generate_coverage_report(coverage, input_path, out_path))
        if dbt_coverage:
            if not cov_parts:
                timestamp = get_timestamp()
                cov_parts.append(
                    f"# Conversion Coverage Report\n\n"
                    f"**Generated:** {timestamp}\n"
                    f"**Input:** `{input_path}`\n"
                    f"**Output:** `{out_path}`\n"
                )
            cov_parts.append(generate_dbt_coverage_section(dbt_coverage))
        if cov_parts:
            cov_path = (out_path / 'coverage_report.md').resolve()
            if not str(cov_path).startswith(str(project_root.resolve())):
                raise ValueError(f"Coverage report path escapes project root: {cov_path}")
            cov_path.parent.mkdir(parents=True, exist_ok=True)
            cov_path.write_text('\n'.join(cov_parts), encoding='utf-8')
            print(f"\n    Coverage report saved: {cov_path}")

    # ------------------------------------------------------------------
    # STAGE 2: Lightweight validation (residual Redshift syntax check)
    # ------------------------------------------------------------------
    from residual_checks import validate_output_dir

    all_issues: List[Dict[str, str]] = []
    if validate or report or refine:
        print(f"\n  Running lightweight validation...")
        all_issues = validate_output_dir(out_path)
        if all_issues:
            print(f"\n  VALIDATION: {len(all_issues)} issue(s) found")
            for vi in all_issues:
                print(f"    [{vi['severity']}] {vi['file']}: {vi['issue']}")
        else:
            print(f"  VALIDATION: PASSED (all {total_files} files clean)")

    # ------------------------------------------------------------------
    # STAGE 3: Agentic validation + refinement (--refine)
    # ------------------------------------------------------------------
    agentic_report: Dict[str, Any] = {}
    agentic_report_path: Optional[Path] = None

    if refine:
        if conv_type == 'both':
            sql_input = str(project_root / 'inputs' / 'sql')
            if Path(sql_input).is_dir():
                print(f"\n  === AGENTIC LOOP: Workstream 1 (SQL) ===")
                agentic_report, agentic_report_path = _run_agentic_validation(
                    input_dir=sql_input, output_dir=output_dir,
                )
                vr = agentic_report.get('validation_report', {})
                if vr.get('issues'):
                    _run_agentic_refinement(
                        agentic_report_path, sql_input, output_dir, max_iterations,
                    )

            dbt_input = str(project_root / 'inputs' / 'dbt_project')
            if Path(dbt_input).is_dir() and (Path(dbt_input) / 'dbt_project.yml').exists():
                print(f"\n  === AGENTIC LOOP: Workstream 2 (dbt) ===")
                agentic_report, agentic_report_path = _run_agentic_validation(
                    input_dir=dbt_input, output_dir=output_dir,
                )
                vr = agentic_report.get('validation_report', {})
                if vr.get('issues'):
                    _run_agentic_refinement(
                        agentic_report_path, dbt_input, output_dir, max_iterations,
                    )
        else:
            agentic_report, agentic_report_path = _run_agentic_validation(
                input_dir=input_path, output_dir=output_dir,
            )
            vr = agentic_report.get('validation_report', {})
            if vr.get('issues'):
                _run_agentic_refinement(
                    agentic_report_path, input_path, output_dir, max_iterations,
                )

    # ------------------------------------------------------------------
    # STAGE 4: Reference validation (--validate-against)
    # ------------------------------------------------------------------
    from diff_comparison import (
        validate_against_reference, print_reference_validation,
        generate_reference_report,
    )

    ref_results: List[Dict[str, Any]] = []
    if ref_dir:
        ref_path = Path(ref_dir)
        if ref_path.is_dir():
            print(f"\n  Running reference validation against: {ref_path}")
            ref_results = validate_against_reference(out_path, ref_path)
            print_reference_validation(ref_results)
        else:
            print(f"\n  WARNING: Reference directory not found: {ref_dir}")

    # ------------------------------------------------------------------
    # STAGE 5: Migration report (--report)
    # ------------------------------------------------------------------
    from generate_migration_report import generate_report

    elapsed = time.time() - start_time
    if report:
        safe_input_path = str(_sanitize_path(input_path, project_root))
        report_content = generate_report(
            safe_input_path, out_path, results, all_issues, elapsed,
        )
        if ref_results:
            report_content += '\n' + generate_reference_report(ref_results)
        if agentic_report:
            vr = agentic_report.get('validation_report', {})
            report_content += '\n## Agentic Validation Summary\n\n'
            report_content += f"| Metric | Value |\n| --- | --- |\n"
            report_content += f"| Accuracy | {vr.get('overall_accuracy', 'N/A')}% |\n"
            report_content += f"| Total checks | {vr.get('total_checks', 'N/A')} |\n"
            report_content += f"| Passed | {vr.get('passed_check_count', 'N/A')} |\n"
            report_content += f"| Failed (high) | {vr.get('failed_check_count', 'N/A')} |\n"
            if agentic_report_path:
                report_content += f"\nDetailed report: `{agentic_report_path}`\n"
        report_path = (out_path / 'migration_report.md').resolve()
        if not str(report_path).startswith(str(project_root.resolve())):
            raise ValueError(f"Migration report path escapes project root: {report_path}")
        report_path.parent.mkdir(parents=True, exist_ok=True)
        report_path.write_text(report_content, encoding='utf-8')
        print(f"\n  Report saved: {report_path}")

    # ------------------------------------------------------------------
    # Summary
    # ------------------------------------------------------------------
    print(f"\n{'='*60}")
    print(f"  DONE")
    print(f"{'='*60}")
    total_conversions = sum(r.get('conversions_applied', 0) for r in results.values())
    if skip_convert:
        print(f"  Output files:      {total_files}")
    else:
        print(f"  Files generated:   {total_files}")
        print(f"  Conversions:       {total_conversions}")
    print(f"  Output directory:  {out_path}")
    if validate or report or refine:
        status = "CLEAN" if not all_issues else f"{len(all_issues)} ISSUE(S)"
        print(f"  Validation:        {status}")
    if refine and agentic_report:
        vr = agentic_report.get('validation_report', {})
        print(f"  Agentic accuracy:  {vr.get('overall_accuracy', 'N/A')}%")
    if coverage:
        cs = coverage['summary']
        print(f"  WS1 Coverage:      {cs['coverage_pct']}% ({cs['covered_statements']}/{cs['total_statements']} statements)")
        if cs['files_without_output'] > 0:
            print(f"  WS1 MISSING FILES: {cs['files_without_output']}")
        if cs['uncovered_statements'] > 0:
            print(f"  WS1 UNCOVERED:     {cs['uncovered_statements']} block(s)")
    if dbt_coverage:
        ds = dbt_coverage['summary']
        print(f"  WS2 Coverage:      {ds['coverage_pct']}% ({ds['matched']}/{ds['total_input_files']} files)")
        if ds['missing_output'] > 0:
            print(f"  WS2 MISSING FILES: {ds['missing_output']}")
    if ref_results:
        matches = sum(1 for r in ref_results if r['status'] == 'MATCH')
        mismatches = sum(1 for r in ref_results if r['status'] == 'MISMATCH')
        print(f"  Reference check:   {matches} matched, {mismatches} mismatched")
    print(f"  Elapsed:           {elapsed:.1f}s")
    print(f"{'='*60}\n")

    has_failures = bool(all_issues) or any(
        r['status'] in ('MISMATCH', 'MISSING_OUTPUT') for r in ref_results
    )
    return 1 if has_failures else 0


def _dry_run(input_path: str, conv_type: str) -> int:
    """Preview what would be converted."""
    p = Path(input_path)

    if conv_type == 'dbt' or (conv_type == 'all' and p.is_dir() and (p / 'dbt_project.yml').exists()):
        print("  dbt project detected:")
        for f in sorted(p.rglob('*')):
            if f.is_file() and f.suffix in ('.sql', '.yml', '.yaml'):
                print(f"    {f.relative_to(p)}")
        print()

    sql_files = resolve_input_files(input_path)
    if sql_files:
        print(f"  SQL files found: {len(sql_files)}")
        for f in sql_files:
            content = f.read_text(encoding='utf-8')

            ddl_count = len(re.findall(r'CREATE\s+TABLE\b', content, re.IGNORECASE))
            view_count = len(re.findall(r'CREATE\s+(?:OR\s+REPLACE\s+)?(?:MATERIALIZED\s+)?VIEW\b', content, re.IGNORECASE))
            dml_count = len(re.findall(r'\b(?:INSERT\s+INTO|UPDATE\s|DELETE\s|MERGE\s)\b', content, re.IGNORECASE))
            proc_count = len(re.findall(r'CREATE\s+(?:OR\s+REPLACE\s+)?PROCEDURE\b', content, re.IGNORECASE))
            query_count = len(re.findall(r'^\s*(?:WITH\s|SELECT\s)', content, re.MULTILINE | re.IGNORECASE))

            parts = []
            if ddl_count:
                parts.append(f"{ddl_count} DDL")
            if view_count:
                parts.append(f"{view_count} VIEW")
            if dml_count:
                parts.append(f"{dml_count} DML")
            if proc_count:
                parts.append(f"{proc_count} PROC")
            if query_count:
                parts.append(f"{query_count} QUERY")

            summary = ", ".join(parts) if parts else "no recognized statements"
            print(f"    {f.name}: {summary}")

    if not sql_files:
        print("  No SQL files found at the given path.")
        return 1

    print(f"\n  Use without --dry-run to execute conversion.")
    return 0


# =========================================================================
# CLI Entry Point
# =========================================================================

def main() -> None:
    parser = argparse.ArgumentParser(
        description='Convert Redshift SQL & dbt projects to Databricks (mass conversion)',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Conversion Types:
  ddl          CREATE TABLE statements
  dml          INSERT, UPDATE, DELETE, MERGE, COPY, UNLOAD
  views        CREATE VIEW, CREATE MATERIALIZED VIEW
  procedures   CREATE PROCEDURE (stored procedures)
  queries      SELECT statements, CTEs, CTAS
  dbt          Full dbt project migration (Workstream 2)
  all          Run all SQL converters (auto-detects dbt projects)
  both         Run BOTH workstreams: SQL (inputs/sql) + dbt (inputs/dbt_project)

Examples:
  # Convert DDL files
  python scripts/cli.py -i /data/redshift/ -o /data/databricks/ --type ddl

  # Convert all SQL types
  python scripts/cli.py -i /data/redshift/ -o /data/databricks/ --type all

  # Migrate a dbt project
  python scripts/cli.py -i /data/my_dbt_project/ -o /data/databricks_dbt/ --type dbt

  # Full pipeline: convert + validate + refine + report (both workstreams)
  python scripts/cli.py -i inputs/ -o output/ --type both --refine --report

  # Full conversion with Unity Catalog integration
  python scripts/cli.py -i inputs/ -o output/ --type both --catalog my_catalog --report

  # Full conversion with validation and report
  python scripts/cli.py -i /data/redshift/ -o /data/databricks/ --type all --validate --report

  # Dry run to preview
  python scripts/cli.py -i /data/redshift/ --type all --dry-run

  # Validate output against reference Databricks scripts
  python scripts/cli.py -i /data/redshift/ -o /data/databricks/ --type all --validate-against /data/reference/ --report
        """,
    )
    parser.add_argument(
        '-i', '--input', default='inputs/',
        help='Input path: SQL file, directory, or glob pattern (default: inputs/)',
    )
    parser.add_argument(
        '-o', '--output', default='output',
        help='Output directory (default: output/)',
    )
    parser.add_argument(
        '-t', '--type', default='both', choices=CONVERTER_TYPES,
        help='Conversion type (default: both)',
    )
    parser.add_argument(
        '--validate', action='store_true',
        help='Run validation checks on generated output',
    )
    parser.add_argument(
        '--report', action='store_true',
        help='Generate a migration report (implies --validate)',
    )
    parser.add_argument(
        '--refine', action='store_true',
        help='Run agentic validation + refinement loop after conversion',
    )
    parser.add_argument(
        '--max-iterations', type=int, default=3,
        help='Max refinement iterations when --refine is used (default: 3)',
    )
    parser.add_argument(
        '--dry-run', action='store_true',
        help='Preview what would be converted without writing files',
    )
    parser.add_argument(
        '--validate-against', default=None, metavar='REF_DIR',
        help='Directory of reference Databricks scripts to validate output against',
    )
    parser.add_argument(
        '--plan', action='store_true',
        help='Generate a conversion plan (plans/conversion_plan.md) before converting',
    )
    parser.add_argument(
        '--catalog', default='', metavar='CATALOG_NAME',
        help='Unity Catalog name to prefix schema.table references (optional, 3-level namespace)',
    )
    parser.add_argument(
        '--skip-convert', action='store_true',
        help='Skip conversion stage — run validation/report on existing output files',
    )
    args = parser.parse_args()

    exit_code = run_conversion(
        input_path=args.input,
        output_dir=args.output,
        conv_type=args.type,
        validate=args.validate,
        report=args.report,
        dry_run=args.dry_run,
        ref_dir=args.validate_against,
        refine=args.refine,
        max_iterations=args.max_iterations,
        plan=args.plan,
        catalog=args.catalog,
        skip_convert=args.skip_convert,
    )
    sys.exit(exit_code)


if __name__ == '__main__':
    main()
