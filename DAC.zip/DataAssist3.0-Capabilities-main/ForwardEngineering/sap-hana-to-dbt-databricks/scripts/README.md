# SAP HANA to dbt/Databricks Conversion Scripts

## Quick Start

```bash
# Run the full conversion pipeline (recommended)
python agent-output/scripts/convert.py

# Or use the CLI entry point
python agent-output/scripts/cli.py              # same as above (default: convert)
python agent-output/scripts/cli.py convert      # run the conversion pipeline
python agent-output/scripts/cli.py all          # run all scripts (including smoke tests)
python agent-output/scripts/cli.py --list       # list available commands
```

## Scripts

| Script | CLI Command | Description |
|--------|-------------|-------------|
| `convert.py` | `python cli.py convert` | Main pipeline: scan `user-config/inputs/`, parse each SAP HANA procedure, write 3 dbt artifacts per procedure to `scripts-output/output/` |
| `parse_hana_procedure.py` | `python cli.py parse` | Parses a SAP HANA stored procedure text string into a structured Python dict |
| `generate_dbt_sql.py` | `python cli.py sql` | Generates a dbt SQL model string from a parsed procedure dict |
| `generate_schema_yaml.py` | `python cli.py schema` | Generates a `schema.yml` string from a parsed procedure dict |
| `generate_sources_yaml.py` | `python cli.py sources` | Generates a `sources.yml` string from a parsed procedure dict |

## Data Flow

```
user-config/inputs/*.txt  or  *.sql
         |
         v
parse_hana_procedure.parse_procedure(text, model_name)
         |
         v
    parsed dict
    /    |    \
   v     v     v
generate_dbt_sql  generate_schema_yaml  generate_sources_yaml
   |               |                    |
   v               v                    v
<model>.sql     schema.yml          sources.yml
         \          |              /
          v         v             v
        scripts-output/output/<procedure_name>/
```

- Reads from: `user-config/inputs/` (SAP HANA `.txt`/`.sql` procedure files)
- Writes to: `scripts-output/output/<procedure_name>/` (3 files per procedure)

## Output Files Per Procedure

| File | Description |
|------|-------------|
| `<procedure_name>.sql` | dbt incremental merge model (or table model if no UPDATE) |
| `schema.yml` | dbt model column definitions with tests |
| `sources.yml` | dbt source definition referencing the SAP HANA schema/table |

## Dependencies

- Python 3.8+
- `pyyaml` (see `requirements.txt`)

Install: `pip install -r agent-output/scripts/requirements.txt`
