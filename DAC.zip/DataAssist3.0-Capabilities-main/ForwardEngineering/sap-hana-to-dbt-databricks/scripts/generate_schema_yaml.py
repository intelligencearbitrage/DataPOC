#!/usr/bin/env python3
"""Generate a dbt schema.yml string from a parsed SAP HANA procedure dict."""

import yaml
from typing import Dict, Any, List, Optional


def _get_column_description(col: str, source_table: str) -> str:
    """Generate a description string for a column based on its name suffix."""
    if col.upper().endswith('_SKU'):
        return 'SKU identifier column.'
    elif col.upper().endswith('_CD'):
        return 'Category code column.'
    elif col.upper().endswith('_IND'):
        return 'Indicator flag column. Values: Y or N.'
    elif col.upper().endswith('_DTM'):
        return 'Timestamp column.'
    else:
        return f'Source column from {source_table}.'


def _get_column_tests(col: str, primary_key: Optional[str]) -> List:
    """Assign dbt tests to a column based on name rules.

    Rule 1 (primary key) is checked before Rule 2 (_IND columns).
    """
    col_upper = col.upper()
    pk_upper = primary_key.upper() if primary_key else ''

    # Rule 1: primary key column
    if col_upper == pk_upper:
        return ['not_null', 'unique']

    # Rule 2: indicator flag columns
    if col_upper.endswith('_IND'):
        return ['not_null', {'accepted_values': {'values': ['Y', 'N']}}]

    # Rule 3: category code columns
    if col_upper.endswith('_CD'):
        return ['not_null']

    # Rule 4: timestamp columns — not_null only (EXPORTED_DTM is always CURRENT_TIMESTAMP)
    if col_upper.endswith('_DTM'):
        return ['not_null']

    # Rule 5: all other columns
    return ['not_null']


def generate_schema_yaml(parsed: Dict[str, Any]) -> str:
    """Generate a dbt schema.yml string from the parsed procedure dict.

    Args:
        parsed: Dict produced by parse_hana_procedure.parse_procedure().

    Returns:
        Full schema.yml file content as a string.
    """
    model_name = parsed['model_name']
    procedure_name = parsed['procedure_name']
    source_table = parsed['source_table_original']
    primary_key = parsed.get('primary_key')
    has_update = parsed['has_update']
    select_columns = list(parsed['select_columns'])

    # Build column list: select_columns + EXPORTED_IND/EXPORTED_DTM if has_update
    columns: List[str] = list(select_columns)
    if has_update:
        if 'EXPORTED_IND' not in [c.upper() for c in columns]:
            columns.append('EXPORTED_IND')
        if 'EXPORTED_DTM' not in [c.upper() for c in columns]:
            columns.append('EXPORTED_DTM')

    # Build column dicts
    column_dicts = []
    for col in columns:
        col_dict: Dict[str, Any] = {
            'name': col.lower(),
            'description': _get_column_description(col, source_table),
        }
        tests = _get_column_tests(col, primary_key)
        if tests:  # Omit 'tests' key entirely when list is empty
            col_dict['tests'] = tests
        column_dicts.append(col_dict)

    # Build full data structure
    data = {
        'version': 2,
        'models': [
            {
                'name': model_name,
                'description': (
                    f'dbt model translated from SAP HANA stored procedure {procedure_name}.'
                ),
                'columns': column_dicts,
            }
        ],
    }

    return yaml.dump(
        data,
        default_flow_style=False,
        sort_keys=False,
        indent=2,
        allow_unicode=True,
    )


if __name__ == '__main__':
    # Quick smoke test when run directly
    import sys
    from pathlib import Path

    sys.path.insert(0, str(Path(__file__).parent))
    from parse_hana_procedure import parse_procedure

    project_root = Path(__file__).resolve().parent.parent.parent
    sample = project_root / 'user-config' / 'inputs' / 'USP_SEL_I_SAMPLE_PKG_PREDICTIVE_CAT_XREF.txt'
    if sample.exists():
        text = sample.read_text(encoding='utf-8', errors='replace')
        parsed = parse_procedure(text, model_name='usp_sel_i_sample_pkg_predictive_cat_xref')
        print(generate_schema_yaml(parsed))
    else:
        print(f'Sample file not found: {sample}', file=sys.stderr)
        sys.exit(1)
