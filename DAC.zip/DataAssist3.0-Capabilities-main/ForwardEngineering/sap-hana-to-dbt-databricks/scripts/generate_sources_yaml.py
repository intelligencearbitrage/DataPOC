#!/usr/bin/env python3
"""Generate a dbt sources.yml string from a parsed SAP HANA procedure dict."""

import yaml
from typing import Dict, Any


def _get_column_description(col: str, source_table: str) -> str:
    """Generate a description string for a column based on its name suffix."""
    col_upper = col.upper()
    if col_upper.endswith('_SKU'):
        return 'SKU identifier column.'
    elif col_upper.endswith('_CD'):
        return 'Category code column.'
    elif col_upper.endswith('_IND'):
        return 'Indicator flag column. Values: Y or N.'
    elif col_upper.endswith('_DTM'):
        return 'Timestamp column.'
    else:
        return f'Source column from {source_table}.'


def generate_sources_yaml(parsed: Dict[str, Any]) -> str:
    """Generate a dbt sources.yml string from the parsed procedure dict.

    Args:
        parsed: Dict produced by parse_hana_procedure.parse_procedure().

    Returns:
        Full sources.yml file content as a string.
    """
    dbt_source_name = parsed['dbt_source_name']          # e.g. 'mhk_edw_mart'
    source_schema_original = parsed['source_schema_original']  # e.g. 'MHK_EDW_MART'
    source_table_original = parsed['source_table_original']    # e.g. 'I_SAMPLE_PKG_PREDICTIVE_CAT_XREF'
    dbt_table_name = parsed['dbt_table_name']             # e.g. 'i_sample_pkg_predictive_cat_xref'
    all_columns = parsed['all_columns']                   # all 6 columns from anywhere in procedure

    # Build column dicts for the source table
    column_dicts = [
        {
            'name': col.lower(),
            'description': _get_column_description(col, source_table_original),
        }
        for col in all_columns
    ]

    # Build full data structure
    data = {
        'version': 2,
        'sources': [
            {
                'name': dbt_source_name,
                'description': f'SAP HANA source schema {source_schema_original}.',
                'schema': source_schema_original,  # ORIGINAL casing — critical for Databricks
                'tables': [
                    {
                        'name': dbt_table_name,
                        'description': (
                            f'Source table {source_table_original} from {source_schema_original}.'
                        ),
                        'columns': column_dicts,
                    }
                ],
            }
        ],
    }

    return yaml.dump(
        data,
        default_flow_style=False,
        sort_keys=False,
        indent=2,
        allow_unicode=True,
    )


if __name__ == '__main__':
    # Quick smoke test when run directly
    import sys
    from pathlib import Path

    sys.path.insert(0, str(Path(__file__).parent))
    from parse_hana_procedure import parse_procedure

    project_root = Path(__file__).resolve().parent.parent.parent
    sample = project_root / 'user-config' / 'inputs' / 'USP_SEL_I_SAMPLE_PKG_PREDICTIVE_CAT_XREF.txt'
    if sample.exists():
        text = sample.read_text(encoding='utf-8', errors='replace')
        parsed = parse_procedure(text, model_name='usp_sel_i_sample_pkg_predictive_cat_xref')
        print(generate_sources_yaml(parsed))
    else:
        print(f'Sample file not found: {sample}', file=sys.stderr)
        sys.exit(1)
