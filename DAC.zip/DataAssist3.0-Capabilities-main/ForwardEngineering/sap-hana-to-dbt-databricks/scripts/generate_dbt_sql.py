#!/usr/bin/env python3
"""Generate a dbt SQL model string from a parsed SAP HANA procedure dict."""

from typing import Dict, Any


def generate_sql_model(parsed: Dict[str, Any]) -> str:
    """Generate a dbt SQL model string from the parsed procedure dict.

    When has_update is True, generates an incremental+merge model with a CTE.
    When has_update is False, generates a simple table model.

    Args:
        parsed: Dict produced by parse_hana_procedure.parse_procedure().

    Returns:
        Full dbt SQL model file content as a string.
    """
    procedure_name = parsed['procedure_name']
    primary_key = parsed['primary_key'] or parsed['select_columns'][0]
    dbt_source_name = parsed['dbt_source_name']
    dbt_table_name = parsed['dbt_table_name']
    select_columns = parsed['select_columns']
    has_update = parsed['has_update']
    unprocessed_where = parsed.get('unprocessed_where', '')
    unprocessed_order_by = parsed.get('unprocessed_order_by', primary_key)

    if has_update:
        return _generate_incremental_model(
            procedure_name=procedure_name,
            primary_key=primary_key,
            dbt_source_name=dbt_source_name,
            dbt_table_name=dbt_table_name,
            select_columns=select_columns,
            unprocessed_where=unprocessed_where,
            unprocessed_order_by=unprocessed_order_by,
        )
    else:
        return _generate_table_model(
            procedure_name=procedure_name,
            dbt_source_name=dbt_source_name,
            dbt_table_name=dbt_table_name,
            select_columns=select_columns,
        )


def _generate_incremental_model(
    procedure_name: str,
    primary_key: str,
    dbt_source_name: str,
    dbt_table_name: str,
    select_columns: list,
    unprocessed_where: str,
    unprocessed_order_by: str,
) -> str:
    """Build the incremental merge model (has_update=True branch)."""

    # Header comment block — uses plain string concatenation to avoid f-string brace issues
    header = (
        '-- Translated from SAP HANA stored procedure ' + procedure_name + '\n'
        '-- Original logic: find one unprocessed record, return its data, mark it exported.\n'
        "-- NOTE: The original UPDATE (EXPORTED_IND='Y', EXPORTED_DTM=CURRENT_TIMESTAMP)\n"
        '--       is represented below via the incremental merge on ' + primary_key + '.\n'
        '-- NOTE: The original procedure processes exactly one record per run (SELECT TOP 1).\n'
        '--       This dbt model similarly processes one record per run via LIMIT 1 in the CTE.'
    )

    # Config block — literal {{ and }} needed in output; use plain strings not f-strings
    config_block = (
        "{{ config(\n"
        "    materialized='incremental',\n"
        "    unique_key='" + primary_key + "',\n"
        "    incremental_strategy='merge',\n"
        "    schema='" + dbt_source_name + "'\n"
        ") }}"
    )

    # Source macro reference — build as plain string
    source_ref = "{{ source('" + dbt_source_name + "', '" + dbt_table_name + "') }}"

    # Indent the unprocessed_where — preserve existing newlines but add indent on continuation lines
    # The WHERE clause from the parser may be multi-line (e.g. "EXPORTED_IND = 'N'\n  AND UPDATE_DTM < CURRENT_TIMESTAMP")
    # We format it so it looks good inside the CTE
    where_lines = unprocessed_where.split('\n')
    if len(where_lines) == 1:
        formatted_where = '    WHERE ' + where_lines[0]
    else:
        # First line after WHERE, subsequent lines indented with "  " to align with the predicate
        formatted_where = '    WHERE ' + where_lines[0].strip()
        for line in where_lines[1:]:
            stripped = line.strip()
            if stripped:
                formatted_where += '\n      ' + stripped

    # CTE block
    cte_block = (
        'WITH unprocessed AS (\n'
        '    SELECT ' + primary_key + '\n'
        '    FROM ' + source_ref + '\n'
        + formatted_where + '\n'
        '    ORDER BY ' + unprocessed_order_by + '\n'
        '    LIMIT 1\n'
        ')'
    )

    # SELECT column list: src.COL, for each select_column, then literal EXPORTED_IND and EXPORTED_DTM
    col_lines = []
    for col in select_columns:
        col_lines.append('    src.' + col + ',')
    col_lines.append("    'Y'               AS EXPORTED_IND,")
    col_lines.append('    CURRENT_TIMESTAMP AS EXPORTED_DTM')

    select_cols_str = '\n'.join(col_lines)

    # INNER JOIN main SELECT block
    main_select = (
        'SELECT\n'
        + select_cols_str + '\n'
        'FROM ' + source_ref + ' src\n'
        'INNER JOIN unprocessed u\n'
        '    ON src.' + primary_key + ' = u.' + primary_key
    )

    return (
        header + '\n\n'
        + config_block + '\n\n'
        + cte_block + '\n\n'
        + main_select + '\n'
    )


def _generate_table_model(
    procedure_name: str,
    dbt_source_name: str,
    dbt_table_name: str,
    select_columns: list,
) -> str:
    """Build the simple table model (has_update=False branch)."""

    header = '-- Translated from SAP HANA stored procedure ' + procedure_name

    config_block = (
        "{{ config(\n"
        "    materialized='table',\n"
        "    schema='" + dbt_source_name + "'\n"
        ") }}"
    )

    source_ref = "{{ source('" + dbt_source_name + "', '" + dbt_table_name + "') }}"

    col_lines = []
    for i, col in enumerate(select_columns):
        if i < len(select_columns) - 1:
            col_lines.append('    ' + col + ',')
        else:
            col_lines.append('    ' + col)

    select_cols_str = '\n'.join(col_lines)

    main_select = (
        'SELECT\n'
        + select_cols_str + '\n'
        'FROM ' + source_ref
    )

    return (
        header + '\n\n'
        + config_block + '\n\n'
        + main_select + '\n'
    )


if __name__ == '__main__':
    # Quick smoke test when run directly
    import sys
    from pathlib import Path

    sys.path.insert(0, str(Path(__file__).parent))
    from parse_hana_procedure import parse_procedure

    project_root = Path(__file__).resolve().parent.parent.parent
    sample = project_root / 'user-config' / 'inputs' / 'USP_SEL_I_SAMPLE_PKG_PREDICTIVE_CAT_XREF.txt'
    if sample.exists():
        text = sample.read_text(encoding='utf-8', errors='replace')
        parsed = parse_procedure(text, model_name='usp_sel_i_sample_pkg_predictive_cat_xref')
        print(generate_sql_model(parsed))
    else:
        print(f"Sample file not found: {sample}", file=sys.stderr)
        sys.exit(1)
