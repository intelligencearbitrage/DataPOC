#!/usr/bin/env python3
"""Parse a SAP HANA stored procedure text string into a structured dict."""

import re
from typing import Dict, List, Any, Optional


def _is_column_name(token: str) -> bool:
    """Return True if the token looks like a column name (letter/underscore start, no spaces)."""
    if not token:
        return False
    # Must start with letter or underscore
    if not (token[0].isalpha() or token[0] == '_'):
        return False
    # Must contain only letters, digits, underscores
    if not re.match(r'^[A-Za-z_][A-Za-z0-9_]*$', token):
        return False
    # Must not be a short SQL keyword / literal value
    sql_keywords = {
        'N', 'Y', 'NULL', 'TRUE', 'FALSE', 'AND', 'OR', 'NOT', 'IN', 'IS',
        'AS', 'ON', 'BY', 'TO', 'OF', 'IF', 'END', 'SET', 'FROM', 'WHERE',
        'JOIN', 'INTO', 'THEN', 'ELSE', 'WHEN', 'CASE', 'WITH', 'TOP',
        'SELECT', 'UPDATE', 'INSERT', 'DELETE', 'ORDER', 'GROUP', 'HAVING',
        'BEGIN', 'DECLARE', 'PROCEDURE', 'FUNCTION', 'CREATE', 'REPLACE',
        'CURRENT_TIMESTAMP', 'CURRENT_DATE', 'CURRENT_TIME',
    }
    return token.upper() not in sql_keywords


def _split_select_blocks(text: str):
    """
    Split the procedure text into all SELECT ... ; blocks.
    Returns a list of (block_text, start_index) tuples.
    We look for SELECT keyword occurrences and collect text up to the
    next semicolon.
    """
    blocks = []
    for m in re.finditer(r'\bSELECT\b', text, re.IGNORECASE):
        start = m.start()
        # Find the next semicolon after this SELECT
        semi = text.find(';', start)
        if semi == -1:
            block = text[start:]
        else:
            block = text[start:semi + 1]
        blocks.append(block)
    return blocks


def parse_procedure(text: str, model_name: str = '') -> Dict[str, Any]:
    """Parse a SAP HANA stored procedure text into a structured dict.

    Args:
        text: Full text of the stored procedure.
        model_name: Caller-supplied model name (derived from filename by convert.py).

    Returns:
        A dict with all fields required by the generator scripts.

    Raises:
        ValueError: If a required field cannot be extracted.
    """

    # ── 1. procedure_name and source_schema ─────────────────────────────────
    try:
        m = re.search(r'CREATE\s+PROCEDURE\s+(\S+)', text, re.IGNORECASE)
        if not m:
            raise ValueError("CREATE PROCEDURE not found")
        procedure_name = m.group(1)
        # Strip trailing semicolon or parenthesis that may have been captured
        procedure_name = procedure_name.rstrip(';(')
        parts = procedure_name.split('.')
        source_schema_original = parts[0]
        source_schema = source_schema_original.lower()
    except Exception as e:
        raise ValueError(f"Failed to extract procedure_name: {e}")

    # ── 2. Split SELECT blocks into TOP-1 (lookup) vs MAIN ──────────────────
    try:
        select_blocks = _split_select_blocks(text)
        if not select_blocks:
            raise ValueError("No SELECT blocks found in procedure")

        top1_block = None
        main_block = None

        for block in select_blocks:
            has_top = bool(re.search(r'\bTOP\b', block, re.IGNORECASE))
            has_into = bool(re.search(r'\bINTO\b', block, re.IGNORECASE))
            if has_top and has_into:
                top1_block = block
            elif not has_into:
                # Could be main or the top1 block without INTO; prefer blocks with quoted cols
                # The main block has multiple quoted column names
                if re.search(r'"[A-Z_]+"', block):
                    main_block = block
                elif main_block is None:
                    main_block = block

        if main_block is None:
            # Fall back: any block that is not the top1 block
            for block in select_blocks:
                if block is not top1_block:
                    main_block = block
                    break
    except Exception as e:
        raise ValueError(f"Failed to split SELECT blocks: {e}")

    # ── 3. source_table (from main SELECT FROM clause) ───────────────────────
    try:
        if main_block is None:
            raise ValueError("Main SELECT block not identified")
        m = re.search(r'\bFROM\s+(\S+)', main_block, re.IGNORECASE)
        if not m:
            raise ValueError("FROM clause not found in main SELECT")
        from_ref = m.group(1).rstrip(';').rstrip(')')
        # schema.table or just table
        table_parts = from_ref.split('.')
        source_table_original = table_parts[-1]
        source_table = source_table_original.lower()
    except Exception as e:
        raise ValueError(f"Failed to extract source_table: {e}")

    # ── 4. select_columns (from main SELECT, between SELECT and FROM) ────────
    try:
        if main_block is None:
            raise ValueError("Main SELECT block not identified")
        # Extract text between SELECT and FROM
        m = re.search(r'\bSELECT\b(.+?)\bFROM\b', main_block, re.IGNORECASE | re.DOTALL)
        if not m:
            raise ValueError("Cannot find columns between SELECT and FROM")
        cols_text = m.group(1)
        raw_cols = cols_text.split(',')
        select_columns: List[str] = []
        for raw in raw_cols:
            col = raw.replace('"', '').strip()
            if col:
                select_columns.append(col)
        if not select_columns:
            raise ValueError("No select_columns extracted")
    except Exception as e:
        raise ValueError(f"Failed to extract select_columns: {e}")

    # ── 5. has_update and update_set_columns ─────────────────────────────────
    try:
        has_update = bool(re.search(r'\bUPDATE\b', text, re.IGNORECASE))
        update_set_columns: List[str] = []
        if has_update:
            m = re.search(
                r'\bUPDATE\b\s+\S+\s+\bSET\b\s+(.+?)\s+\bWHERE\b',
                text,
                re.IGNORECASE | re.DOTALL,
            )
            if m:
                set_text = m.group(1)
                assignments = set_text.split(',')
                for assignment in assignments:
                    lhs = assignment.split('=')[0].strip()
                    if lhs:
                        update_set_columns.append(lhs)
    except Exception as e:
        raise ValueError(f"Failed to extract update information: {e}")

    # ── 6. primary_key ───────────────────────────────────────────────────────
    try:
        primary_key: Optional[str] = None
        if has_update:
            m = re.search(
                r'\bUPDATE\b\s+\S+\s+\bSET\b\s+.+?\s+\bWHERE\b\s+(\w+)\s*=',
                text,
                re.IGNORECASE | re.DOTALL,
            )
            if m:
                primary_key = m.group(1)
        # Fallback: use first select_column as primary key
        if primary_key is None and select_columns:
            primary_key = select_columns[0]
    except Exception as e:
        raise ValueError(f"Failed to extract primary_key: {e}")

    # ── 7. where_conditions (from main SELECT block) ─────────────────────────
    try:
        where_conditions: List[str] = []
        if main_block:
            wm = re.search(r'\bWHERE\b\s+(.+)', main_block, re.IGNORECASE | re.DOTALL)
            if wm:
                where_text = wm.group(1).rstrip(';').strip()
                where_conditions = [where_text]
    except Exception as e:
        raise ValueError(f"Failed to extract where_conditions: {e}")

    # ── 8. unprocessed_where and unprocessed_order_by (from TOP 1 block) ─────
    try:
        unprocessed_where = ''
        unprocessed_order_by = ''
        if top1_block:
            # Extract WHERE ... ORDER BY
            wm = re.search(
                r'\bWHERE\b\s+(.+?)\s*\bORDER\s+BY\b',
                top1_block,
                re.IGNORECASE | re.DOTALL,
            )
            if wm:
                raw_where = wm.group(1).strip()
                # Replace :variable references with CURRENT_TIMESTAMP
                unprocessed_where = re.sub(r':\w+', 'CURRENT_TIMESTAMP', raw_where)
                # Clean up extra whitespace/newlines minimally — preserve AND/OR structure
                unprocessed_where = unprocessed_where.rstrip()

            om = re.search(r'\bORDER\s+BY\s+(\w+)', top1_block, re.IGNORECASE)
            if om:
                unprocessed_order_by = om.group(1)
    except Exception as e:
        raise ValueError(f"Failed to extract unprocessed_where/order_by: {e}")

    # ── 9. all_columns (order-preserving dedup) ───────────────────────────────
    try:
        seen = set()
        all_columns: List[str] = []

        def add_col(col: str) -> None:
            col = col.replace('"', '').strip()
            if col and col.upper() not in seen and _is_column_name(col.upper()):
                seen.add(col.upper())
                all_columns.append(col.upper())

        # a. select_columns first
        for col in select_columns:
            add_col(col)

        # b. update_set_columns
        for col in update_set_columns:
            add_col(col)

        # c. WHERE predicates from all SELECT blocks (LHS of comparisons)
        for block in select_blocks:
            wm = re.search(r'\bWHERE\b\s+(.+)', block, re.IGNORECASE | re.DOTALL)
            if wm:
                where_clause = wm.group(1).rstrip(';').strip()
                # Extract identifiers on the left side of = < > operators
                for pred_m in re.finditer(r'\b([A-Za-z_][A-Za-z0-9_]*)\s*[<>=]', where_clause):
                    add_col(pred_m.group(1))

        # d. Column from TOP 1 SELECT clause (before INTO)
        if top1_block:
            tm = re.search(r'\bSELECT\b\s+(?:TOP\s+\d+\s+)?(.+?)\s*\bINTO\b', top1_block, re.IGNORECASE | re.DOTALL)
            if tm:
                top_col_text = tm.group(1)
                for raw in top_col_text.split(','):
                    add_col(raw.replace('"', '').strip())
    except Exception as e:
        raise ValueError(f"Failed to extract all_columns: {e}")

    # ── 10. Derived fields ───────────────────────────────────────────────────
    dbt_source_name = source_schema.lower()
    dbt_table_name = source_table.lower()

    return {
        'procedure_name': procedure_name,
        'source_schema': source_schema,
        'source_schema_original': source_schema_original,
        'source_table': source_table,
        'source_table_original': source_table_original,
        'model_name': model_name,
        'select_columns': select_columns,
        'all_columns': all_columns,
        'has_update': has_update,
        'update_set_columns': update_set_columns,
        'where_conditions': where_conditions,
        'primary_key': primary_key,
        'dbt_source_name': dbt_source_name,
        'dbt_table_name': dbt_table_name,
        'unprocessed_where': unprocessed_where,
        'unprocessed_order_by': unprocessed_order_by,
    }


if __name__ == '__main__':
    # Quick smoke test when run directly
    import sys
    from pathlib import Path

    project_root = Path(__file__).resolve().parent.parent.parent
    sample = project_root / 'user-config' / 'inputs' / 'USP_SEL_I_SAMPLE_PKG_PREDICTIVE_CAT_XREF.txt'
    if sample.exists():
        text = sample.read_text(encoding='utf-8', errors='replace')
        result = parse_procedure(text, model_name='usp_sel_i_sample_pkg_predictive_cat_xref')
        import pprint
        pprint.pprint(result)
    else:
        print(f"Sample file not found: {sample}", file=sys.stderr)
        sys.exit(1)
