#!/usr/bin/env python3
"""Main entry point for SAP HANA to dbt/Databricks conversion pipeline.

Scans user-config/inputs/ for .txt and .sql SAP HANA stored procedure files,
converts each one to three dbt artifacts, and writes them to
scripts-output/output/<procedure_name>/.

Usage:
    python convert.py
"""

import re
import sys
from pathlib import Path

# Add agent-output/scripts to path so sibling imports work regardless of cwd
sys.path.insert(0, str(Path(__file__).parent))

from parse_hana_procedure import parse_procedure
from generate_dbt_sql import generate_sql_model
from generate_schema_yaml import generate_schema_yaml
from generate_sources_yaml import generate_sources_yaml


# Project root is three levels above this script:
#   agent-output/scripts/convert.py  ->  parent = agent-output/scripts/
#                                         parent.parent = agent-output/
#                                         parent.parent.parent = project root
BASE_DIR = Path(__file__).resolve().parent.parent.parent
INPUT_DIR = BASE_DIR / 'user-config' / 'inputs'
OUTPUT_DIR = BASE_DIR / 'scripts-output' / 'output'


def main() -> None:
    """Scan inputs/, parse each procedure, and write three output files per procedure."""

    # Collect all .txt and .sql files from INPUT_DIR
    files = sorted(list(INPUT_DIR.glob('*.txt')) + list(INPUT_DIR.glob('*.sql')))

    if not files:
        print(f'No input files found in {INPUT_DIR}')
        return

    for file_path in files:
        print(f'Converting: {file_path.name}')
        try:
            # Derive model_name from filename: lowercase + replace non-alphanumeric with _
            stem = file_path.stem
            model_name = re.sub(r'[^a-z0-9_]', '_', stem.lower())

            # Read procedure text with safe encoding
            text = file_path.read_text(encoding='utf-8', errors='replace')

            # Parse the procedure
            parsed = parse_procedure(text, model_name=model_name)

            # Prepare output directory
            model_dir = OUTPUT_DIR / model_name
            model_dir.mkdir(parents=True, exist_ok=True)

            # Write SQL model
            sql_path = model_dir / f'{model_name}.sql'
            sql_path.write_text(generate_sql_model(parsed), encoding='utf-8')
            print(f'  -> {sql_path}')

            # Write schema.yml
            schema_path = model_dir / 'schema.yml'
            schema_path.write_text(generate_schema_yaml(parsed), encoding='utf-8')
            print(f'  -> {schema_path}')

            # Write sources.yml
            sources_path = model_dir / 'sources.yml'
            sources_path.write_text(generate_sources_yaml(parsed), encoding='utf-8')
            print(f'  -> {sources_path}')

        except Exception as e:
            print(f'  ERROR processing {file_path.name}: {e}')
            continue


if __name__ == '__main__':
    main()
