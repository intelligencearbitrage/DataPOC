#!/usr/bin/env python3
"""CLI entry point for running SAP HANA to dbt/Databricks conversion scripts."""

import argparse
import subprocess
import sys
from pathlib import Path

SCRIPTS_DIR = Path(__file__).resolve().parent

# Registry of available scripts
SCRIPTS = {
    'convert': {
        'file': 'convert.py',
        'description': 'Convert SAP HANA stored procedures to dbt/Databricks artifacts',
    },
    'parse': {
        'file': 'parse_hana_procedure.py',
        'description': 'Smoke-test the SAP HANA procedure parser on the sample input',
    },
    'sql': {
        'file': 'generate_dbt_sql.py',
        'description': 'Smoke-test dbt SQL model generation on the sample input',
    },
    'schema': {
        'file': 'generate_schema_yaml.py',
        'description': 'Smoke-test schema.yml generation on the sample input',
    },
    'sources': {
        'file': 'generate_sources_yaml.py',
        'description': 'Smoke-test sources.yml generation on the sample input',
    },
}


def run_script(name: str) -> int:
    """Run a registered script by command name."""
    if name == 'all':
        failed = 0
        for cmd, info in SCRIPTS.items():
            print(f"\n{'='*60}\nRunning: {cmd} ({info['file']})\n{'='*60}")
            result = subprocess.run([sys.executable, str(SCRIPTS_DIR / info['file'])])
            if result.returncode != 0:
                failed += 1
        return 1 if failed else 0

    if name not in SCRIPTS:
        print(f"Unknown script: {name}")
        print(f"Available: {', '.join(SCRIPTS.keys())}, all")
        return 1

    script_path = SCRIPTS_DIR / SCRIPTS[name]['file']
    return subprocess.run([sys.executable, str(script_path)]).returncode


def main() -> None:
    """Parse arguments and dispatch to the selected script."""
    parser = argparse.ArgumentParser(
        description='Run SAP HANA to dbt/Databricks conversion scripts'
    )
    parser.add_argument('command', nargs='?', default='convert',
                        help="Script to run (default: 'convert'). Use 'all' to run everything.")
    parser.add_argument('--list', action='store_true', help='List available scripts')
    args = parser.parse_args()

    if args.list:
        for cmd, info in SCRIPTS.items():
            print(f"  {cmd:12s} — {info['description']}")
        return

    sys.exit(run_script(args.command))


if __name__ == '__main__':
    main()
