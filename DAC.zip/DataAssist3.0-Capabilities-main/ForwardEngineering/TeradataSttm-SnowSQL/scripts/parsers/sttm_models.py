"""
STTM Data Models
================
Data classes representing the Source-to-Target Mapping (STTM) JSON structure.
Used by the parser, assembler, and generators.
"""

import json
import re
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Any, Dict, List, Optional, Set, Tuple


class TransformationType(Enum):
    """Type of transformation between source and target."""
    DIRECT = "DIRECT"
    INDIRECT = "INDIRECT"


class TransformationSubtype(Enum):
    """Subtype of transformation."""
    IDENTITY = "IDENTITY"
    TRANSFORMATION = "TRANSFORMATION"
    COALESCE = "COALESCE"
    CASE_LOGIC = "CASE_LOGIC"
    CAST = "CAST"
    DATE_MANIPULATION = "DATE_MANIPULATION"
    AGGREGATION = "AGGREGATION"
    STRING_MANIPULATION = "STRING_MANIPULATION"


class DMLOperation(Enum):
    """Type of DML operation."""
    INSERT = "INSERT"
    DELETE = "DELETE"
    CREATE_VOLATILE = "CREATE VOLATILE TABLE AS SELECT"


@dataclass
class ColumnRef:
    """Reference to a column in a table."""
    table: str
    column: str

    def __hash__(self):
        return hash((self.table, self.column))

    def __eq__(self, other):
        if not isinstance(other, ColumnRef):
            return False
        return self.table == other.table and self.column == other.column


@dataclass
class Transformation:
    """Transformation applied to produce a target column."""
    type: TransformationType
    subtype: TransformationSubtype
    description: str
    sql_expression: str
    source_columns: List[Dict[str, Any]]
    complexity_score: int


@dataclass
class Edge:
    """A single lineage edge from source to target column."""
    source: ColumnRef
    target: ColumnRef
    transformation: Transformation
    dml_operation: DMLOperation
    join_conditions: str
    where_conditions: str

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> 'Edge':
        """Construct an Edge from a JSON dictionary.

        Supports two formats:
        1. Nested format (spec): {source: {table, column}, target: {table, column}, ...}
        2. Raw flat format: {Source_Table, Source_Attribute, Target_Table, Target_Attribute, ...}
        """
        # Detect raw flat format by checking for flat keys
        if 'Source_Table' in d or 'source_table' in d:
            return cls._from_raw_dict(d)

        source = ColumnRef(
            table=d['source']['table'],
            column=d['source']['column']
        )
        target = ColumnRef(
            table=d['target']['table'],
            column=d['target']['column']
        )

        t = d['transformation']
        try:
            t_subtype = TransformationSubtype(t['subtype'])
        except (ValueError, KeyError):
            t_subtype = TransformationSubtype.TRANSFORMATION
        transformation = Transformation(
            type=TransformationType(t['type']),
            subtype=t_subtype,
            description=t.get('description', ''),
            sql_expression=t.get('sql_expression', ''),
            source_columns=t.get('source_columns', []),
            complexity_score=t.get('complexity_score', 1)
        )

        dml_op_str = d.get('dml_operation', 'INSERT')
        if 'VOLATILE' in dml_op_str.upper() or 'CREATE' in dml_op_str.upper():
            dml_operation = DMLOperation.CREATE_VOLATILE
        elif 'DELETE' in dml_op_str.upper():
            dml_operation = DMLOperation.DELETE
        else:
            dml_operation = DMLOperation.INSERT

        return cls(
            source=source,
            target=target,
            transformation=transformation,
            dml_operation=dml_operation,
            join_conditions=d.get('join_conditions', ''),
            where_conditions=d.get('where_conditions', '')
        )

    @classmethod
    def _from_raw_dict(cls, d: Dict[str, Any]) -> 'Edge':
        """Construct an Edge from a raw/flat STTM dictionary."""
        source_table = d.get('Source_Table', d.get('source_table', ''))
        source_col = d.get('Source_Attribute', d.get('source_attribute', ''))
        target_table = d.get('Target_Table', d.get('target_table', ''))
        target_col = d.get('Target_Attribute', d.get('target_attribute', ''))
        expr = d.get('Transformation_Logic', d.get('transformation_logic', ''))
        description = d.get('Transformation_Explanation', d.get('transformation_explanation', ''))
        dml_op_str = d.get('DML_Operation', d.get('dml_operation', 'INSERT'))
        filter_cond = d.get('Filter_Conditions', d.get('filter_conditions', ''))
        join_cond = d.get('Join_Conditions', d.get('join_conditions', ''))

        source = ColumnRef(table=source_table, column=source_col)
        target = ColumnRef(table=target_table, column=target_col)

        # Infer transformation type and subtype
        expr_upper = expr.upper().strip()
        src_col_upper = source_col.upper().strip()

        if expr_upper == src_col_upper or expr_upper == f"{source_table}.{source_col}".upper():
            t_type = TransformationType.DIRECT
            t_subtype = TransformationSubtype.IDENTITY
            complexity = 1
        elif 'CASE' in expr_upper and 'WHEN' in expr_upper:
            t_type = TransformationType.INDIRECT
            t_subtype = TransformationSubtype.CASE_LOGIC
            complexity = 3
        elif 'COALESCE' in expr_upper:
            t_type = TransformationType.INDIRECT
            t_subtype = TransformationSubtype.COALESCE
            complexity = 2
        else:
            t_type = TransformationType.INDIRECT
            t_subtype = TransformationSubtype.TRANSFORMATION
            complexity = 2

        transformation = Transformation(
            type=t_type,
            subtype=t_subtype,
            description=description,
            sql_expression=expr,
            source_columns=[{'table': source_table, 'column': source_col}],
            complexity_score=complexity,
        )

        if 'VOLATILE' in dml_op_str.upper() or 'CREATE' in dml_op_str.upper():
            dml_operation = DMLOperation.CREATE_VOLATILE
        elif 'DELETE' in dml_op_str.upper():
            dml_operation = DMLOperation.DELETE
        else:
            dml_operation = DMLOperation.INSERT

        return cls(
            source=source,
            target=target,
            transformation=transformation,
            dml_operation=dml_operation,
            join_conditions=join_cond,
            where_conditions=filter_cond,
        )


@dataclass
class ColumnDefinition:
    """Definition of a column in a table."""
    name: str
    sql_expression: str
    inferred_type: str = "VARCHAR"
    source_table: str = ""
    source_column: str = ""
    transformation_subtype: TransformationSubtype = TransformationSubtype.IDENTITY


@dataclass
class TableDefinition:
    """Definition of a table extracted from STTM edges."""
    name: str
    is_volatile: bool = False
    is_final_target: bool = False
    columns: Dict[str, ColumnDefinition] = field(default_factory=dict)
    source_edges: List[Edge] = field(default_factory=list)
    depends_on: Set[str] = field(default_factory=set)
    dml_operation: DMLOperation = DMLOperation.INSERT
    join_conditions: List[str] = field(default_factory=list)
    where_conditions: List[str] = field(default_factory=list)
    primary_from_table: str = ""


@dataclass
class ReconstructedStatement:
    """A fully reconstructed SQL statement from grouped edges."""
    target_table: str
    dml_type: DMLOperation
    select_expressions: List[Tuple[str, str]]  # (alias, expression)
    column_names: List[str]
    from_table: str
    join_clauses: List[str]
    where_clause: str
    is_volatile: bool
    union_tables: List[str] = field(default_factory=list)


@dataclass
class STTMDocument:
    """Represents a complete STTM JSON document."""
    metadata: Dict[str, Any]
    edges: List[Edge]
    _table_inventory: Optional[Dict[str, TableDefinition]] = field(
        default=None, repr=False
    )
    _dependency_graph: Optional[Dict[str, Set[str]]] = field(
        default=None, repr=False
    )

    @classmethod
    def from_dict(cls, data) -> 'STTMDocument':
        """Construct an STTMDocument from parsed JSON.

        Supports three formats:
        1. Nested/spec format (dict): {"metadata": {...}, "edges": [...]}
        2. Raw flat format (list): [{Source_Table, Source_Attribute, ...}, ...]
        3. STTM structured format (dict): {"metadata": {...}, "column_mappings": [...]}
        """
        if isinstance(data, list):
            # Raw flat array format - build metadata from the data
            edges = [Edge.from_dict(e) for e in data]
            source_tables = {e.source.table for e in edges}
            target_tables = {e.target.table for e in edges}
            metadata = {
                'source_file': 'raw_sttm_input',
                'dialect': 'teradata',
                'edge_count': len(edges),
                'table_count': len(source_tables | target_tables),
            }
            return cls(metadata=metadata, edges=edges)

        # STTM structured format with column_mappings
        if isinstance(data, dict) and 'column_mappings' in data:
            rows = cls._convert_column_mappings(data)
            edges = [Edge.from_dict(r) for r in rows]
            metadata = data.get('metadata', {})
            metadata.setdefault('dialect', 'teradata')
            metadata['edge_count'] = len(edges)
            # Preserve subquery definitions for downstream resolution
            if 'subqueries' in data:
                metadata['subqueries'] = data['subqueries']
            if 'table_aliases' in data:
                metadata['table_aliases'] = data['table_aliases']
            return cls(metadata=metadata, edges=edges)

        metadata = data.get('metadata', {})
        edges = [Edge.from_dict(e) for e in data.get('edges', [])]
        return cls(metadata=metadata, edges=edges)

    @staticmethod
    def _convert_column_mappings(data: Dict[str, Any]) -> List[Dict[str, str]]:
        """Convert STTM structured format (column_mappings) to flat row dicts.

        Handles:
        1. Subquery alias filtering — skips rows targeting aliases (A, B, g, t)
           declared in table_aliases
        2. DELETE WHERE extraction — pulls WHERE clause from transformation_sql
           into Filter_Conditions
        3. SELECT INTO → CREATE VOLATILE TABLE mapping
        """
        # Build set of subquery alias names to filter out as targets
        alias_names = {
            ta.get('alias', '').upper()
            for ta in data.get('table_aliases', [])
            if ta.get('alias', '')
        }

        rows = []
        for cm in data['column_mappings']:
            op_type = cm.get('operator_type', '')
            tgt_table = cm.get('target_table', '')

            # Skip rows targeting subquery aliases (A, B, g, t, etc.)
            if tgt_table.upper() in alias_names:
                continue

            dml_op = op_type
            transform_sql = cm.get('transformation_sql', '')
            filter_cond = cm.get('where_conditions_sql', '')

            if op_type == 'SELECT INTO':
                dml_op = 'CREATE VOLATILE TABLE AS SELECT'
            elif op_type == 'DELETE':
                dml_op = 'DELETE'
                # Extract WHERE clause from transformation_sql
                where_match = re.search(
                    r'\bWHERE\s+(.+)$', transform_sql,
                    re.IGNORECASE | re.DOTALL)
                if where_match:
                    filter_cond = where_match.group(1).strip()
                transform_sql = ''

            rows.append({
                'Source_Table': cm.get('source_table', ''),
                'Source_Attribute': cm.get('source_column', ''),
                'Transformation_Logic': transform_sql,
                'Transformation_Explanation': cm.get('transformation_description', ''),
                'Target_Table': tgt_table,
                'Target_Attribute': cm.get('target_column', ''),
                'DML_Operation': dml_op,
                'Filter_Conditions': filter_cond,
                'Join_Conditions': cm.get('join_conditions_sql', ''),
            })
        return rows

    @classmethod
    def from_file(cls, file_path: Path) -> 'STTMDocument':
        """Load an STTMDocument from a JSON file."""
        with open(file_path, 'r', encoding='utf-8') as f:
            data = json.load(f)
        return cls.from_dict(data)

    def get_table_inventory(self) -> Dict[str, TableDefinition]:
        """Build inventory of all tables from edges."""
        if self._table_inventory is not None:
            return self._table_inventory

        tables: Dict[str, TableDefinition] = {}

        for edge in self.edges:
            target_name = edge.target.table
            is_volatile = edge.dml_operation == DMLOperation.CREATE_VOLATILE
            is_final = edge.dml_operation == DMLOperation.INSERT

            if target_name not in tables:
                tables[target_name] = TableDefinition(
                    name=target_name,
                    is_volatile=is_volatile,
                    is_final_target=is_final,
                    dml_operation=edge.dml_operation,
                )
            elif is_final and not tables[target_name].is_final_target:
                # Table has both DELETE and INSERT edges — mark as final target
                # so both DELETE and INSERT SQL are generated
                tables[target_name].is_final_target = True

            table_def = tables[target_name]
            table_def.source_edges.append(edge)

            # Add column definition (deduplicate case-insensitively to avoid
            # Snowflake errors where unquoted identifiers are case-insensitive)
            col_name = edge.target.column
            expr = edge.transformation.sql_expression
            existing_upper = {k.upper() for k in table_def.columns}
            if col_name.upper() not in existing_upper:
                table_def.columns[col_name] = ColumnDefinition(
                    name=col_name,
                    sql_expression=expr,
                    source_table=edge.source.table,
                    source_column=edge.source.column,
                    transformation_subtype=edge.transformation.subtype,
                )

            # Track join conditions
            if edge.join_conditions:
                for jc in edge.join_conditions.split(';'):
                    jc = jc.strip()
                    if jc and jc not in table_def.join_conditions:
                        table_def.join_conditions.append(jc)

            # Track where conditions
            if edge.where_conditions:
                wc = edge.where_conditions.strip()
                if wc and wc not in table_def.where_conditions:
                    table_def.where_conditions.append(wc)

        self._table_inventory = tables
        return tables

    def build_dependency_graph(self) -> Dict[str, Set[str]]:
        """Build dependency graph: {table -> set of tables it depends on}.
        Only tracks volatile table dependencies (non-schema-qualified).
        """
        if self._dependency_graph is not None:
            return self._dependency_graph

        tables = self.get_table_inventory()
        volatile_tables = {
            name for name, tdef in tables.items() if tdef.is_volatile
        }

        graph: Dict[str, Set[str]] = {}
        for name, tdef in tables.items():
            deps: Set[str] = set()
            for edge in tdef.source_edges:
                src_table = edge.source.table
                # Only add volatile table dependencies
                if src_table in volatile_tables and src_table != name:
                    deps.add(src_table)
            graph[name] = deps

        self._dependency_graph = graph
        return graph

    def get_volatile_tables(self) -> List[str]:
        """Return names of volatile (temporary) tables."""
        tables = self.get_table_inventory()
        return [name for name, tdef in tables.items() if tdef.is_volatile]

    def get_final_target_tables(self) -> List[str]:
        """Return names of final target (INSERT) tables."""
        tables = self.get_table_inventory()
        return [name for name, tdef in tables.items() if tdef.is_final_target]

    def get_delete_tables(self) -> List[str]:
        """Return names of tables targeted by DELETE operations."""
        tables = self.get_table_inventory()
        return [name for name, tdef in tables.items()
                if tdef.dml_operation == DMLOperation.DELETE]

    def get_source_tables(self) -> Set[str]:
        """Return set of all source tables referenced in edges."""
        sources = set()
        for edge in self.edges:
            sources.add(edge.source.table)
        return sources


def main():
    """Parse sample input and print table inventory."""
    import sys
    sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

    input_file = Path(__file__).resolve().parent.parent / 'inputs' / 'lineage_output.json'
    if not input_file.exists():
        print(f"Input file not found: {input_file}")
        return

    doc = STTMDocument.from_file(input_file)
    tables = doc.get_table_inventory()

    print(f"Source file: {doc.metadata.get('source_file', 'N/A')}")
    print(f"Dialect: {doc.metadata.get('dialect', 'N/A')}")
    print(f"Total edges: {doc.metadata.get('edge_count', len(doc.edges))}")
    print(f"Total tables: {len(tables)}")
    print()

    volatile = [n for n, t in tables.items() if t.is_volatile]
    final = [n for n, t in tables.items() if t.is_final_target]

    print(f"Volatile tables ({len(volatile)}):")
    for name in volatile:
        tdef = tables[name]
        print(f"  {name}: {len(tdef.columns)} columns, {len(tdef.source_edges)} edges")

    print(f"\nFinal target tables ({len(final)}):")
    for name in final:
        tdef = tables[name]
        print(f"  {name}: {len(tdef.columns)} columns, {len(tdef.source_edges)} edges")

    print("\nDependency graph:")
    graph = doc.build_dependency_graph()
    for name, deps in graph.items():
        dep_str = ', '.join(deps) if deps else '(none)'
        print(f"  {name} -> {dep_str}")


if __name__ == '__main__':
    main()
