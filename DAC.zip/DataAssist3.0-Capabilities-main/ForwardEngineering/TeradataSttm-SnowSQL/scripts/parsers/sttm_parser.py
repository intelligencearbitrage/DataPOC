"""
STTM Parser
============
Extends BaseParser to parse STTM (Source-to-Target Mapping) JSON files.
Builds table inventory and dependency graph from lineage edges.
"""

import json
import re
import sys
from pathlib import Path
from typing import Any, Dict, List

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from base.base_parser import BaseParser
from parsers.sttm_models import STTMDocument


# Teradata dialect markers to detect in expressions
TERADATA_MARKERS = [
    (r'\bADD_MONTHS\s*\(', 'ADD_MONTHS function'),
    (r'\bEXTRACT\s*\(\s*(YEAR|MONTH|DAY|HOUR)\s+FROM\b', 'EXTRACT function'),
    (r'\bSYS_CALENDAR\b', 'SYS_CALENDAR reference'),
    (r'\bVOLATILE\s+TABLE\b', 'VOLATILE TABLE syntax'),
    (r'\bCAST\s*\([^)]+\s+AS\s+DATE\s+FORMAT\b', 'CAST AS DATE FORMAT'),
    (r'\bNULLIFZERO\b', 'NULLIFZERO function'),
    (r'\bZEROIFNULL\b', 'ZEROIFNULL function'),
    (r'\bOREPLACE\b', 'OREPLACE function'),
    (r'\bSAMPLE\s+\d+\b', 'SAMPLE syntax'),
    (r'\bINTERVAL\s+\'\d+\'\s+(MONTH|DAY|YEAR)\b', 'INTERVAL syntax'),
]


class STTMParser(BaseParser):
    """Parser for STTM JSON files."""

    def __init__(self, input_dir: str = 'inputs', output_dir: str = 'output'):
        super().__init__(input_dir=input_dir, output_dir=output_dir)
        self.documents: Dict[str, STTMDocument] = {}

    def discover_files(self) -> List[Path]:
        """Find all STTM JSON files in the inputs directory."""
        files = list(self.input_dir.glob('*.json'))
        self.logger.info(f"Found {len(files)} JSON file(s) in {self.input_dir}")
        return files

    def parse_file(self, file_path: Path) -> Dict[str, Any]:
        """Parse a single STTM JSON file."""
        self.logger.info(f"Parsing STTM file: {file_path.name}")

        with open(file_path, 'r', encoding='utf-8') as f:
            data = json.load(f)

        doc = STTMDocument.from_dict(data)
        self.documents[file_path.stem] = doc

        tables = doc.get_table_inventory()
        graph = doc.build_dependency_graph()

        # Detect Teradata dialect markers in expressions
        td_markers_found = self._detect_teradata_markers(doc)

        volatile_tables = doc.get_volatile_tables()
        final_tables = doc.get_final_target_tables()
        source_tables = doc.get_source_tables()

        result = {
            'name': file_path.stem,
            'metadata': doc.metadata,
            'table_count': len(tables),
            'edge_count': len(doc.edges),
            'volatile_tables': volatile_tables,
            'final_target_tables': final_tables,
            'source_tables': list(source_tables),
            'dependency_graph': {k: list(v) for k, v in graph.items()},
            'teradata_markers': td_markers_found,
            'tables': {
                name: {
                    'columns': list(tdef.columns.keys()),
                    'column_count': len(tdef.columns),
                    'edge_count': len(tdef.source_edges),
                    'is_volatile': tdef.is_volatile,
                    'is_final_target': tdef.is_final_target,
                    'join_count': len(tdef.join_conditions),
                    'where_count': len(tdef.where_conditions),
                }
                for name, tdef in tables.items()
            }
        }

        self.logger.info(
            f"  Parsed: {len(tables)} tables, {len(doc.edges)} edges, "
            f"{len(volatile_tables)} volatile, {len(final_tables)} final target"
        )
        return result

    def _detect_teradata_markers(self, doc: STTMDocument) -> List[Dict[str, str]]:
        """Scan all expressions for Teradata dialect markers."""
        markers_found = []
        seen = set()

        for edge in doc.edges:
            expr = edge.transformation.sql_expression
            for pattern, description in TERADATA_MARKERS:
                if re.search(pattern, expr, re.IGNORECASE) and description not in seen:
                    markers_found.append({
                        'marker': description,
                        'example_expression': expr[:100],
                    })
                    seen.add(description)

            # Also check join and where conditions
            for cond in [edge.join_conditions, edge.where_conditions]:
                if cond:
                    for pattern, description in TERADATA_MARKERS:
                        if re.search(pattern, cond, re.IGNORECASE) and description not in seen:
                            markers_found.append({
                                'marker': description,
                                'example_expression': cond[:100],
                            })
                            seen.add(description)

        return markers_found

    def get_document(self, name: str) -> STTMDocument:
        """Get a parsed STTMDocument by file stem name."""
        return self.documents[name]


def main():
    """Parse all STTM files and print summary."""
    project_root = Path(__file__).resolve().parent.parent
    parser = STTMParser(
        input_dir=str(project_root / 'inputs'),
        output_dir=str(project_root / 'output')
    )
    results = parser.parse_all()

    for name, data in results.items():
        print(f"\n{'='*60}")
        print(f"File: {name}")
        print(f"{'='*60}")
        print(f"  Tables: {data['table_count']}")
        print(f"  Edges: {data['edge_count']}")
        print(f"  Volatile tables: {data['volatile_tables']}")
        print(f"  Final targets: {data['final_target_tables']}")
        print(f"  Source tables: {len(data['source_tables'])}")

        if data['teradata_markers']:
            print(f"\n  Teradata markers found:")
            for m in data['teradata_markers']:
                print(f"    - {m['marker']}")

        print(f"\n  Table inventory:")
        for tname, tinfo in data['tables'].items():
            vtype = "VOLATILE" if tinfo['is_volatile'] else "FINAL" if tinfo['is_final_target'] else "OTHER"
            print(f"    [{vtype}] {tname}: {tinfo['column_count']} cols, {tinfo['edge_count']} edges")


if __name__ == '__main__':
    main()
