"""
DDL Generator
=============
Generates Snowflake DDL (CREATE TABLE / CREATE TEMPORARY TABLE) statements
from STTM lineage edges. Extends BaseGenerator.

Output: output/ddl/<filename>_ddl.sql
"""

import json
import sys
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from base.base_generator import BaseGenerator
from parsers.sttm_models import STTMDocument, TableDefinition, ColumnDefinition
from converter.dependency_resolver import resolve_execution_order
from converter.expression_converter import ExpressionConverter


# Default type inference patterns (checked against SQL expression)
TYPE_INFERENCE = [
    (r'COALESCE\(.+,\s*0\)', 'NUMBER(18,2)'),
    (r'::DATE|TO_DATE|AS DATE', 'DATE'),
    (r'::TIMESTAMP|AS TIMESTAMP|CURRENT_TIMESTAMP', 'TIMESTAMP_NTZ'),
    (r'YEAR\(|MONTH\(|DAY\(|\*\s*100\s*\+|COUNT\s*\(|ERRORCODE|SQLCODE', 'INTEGER'),
    (r'\bABS\s*\(|SUM\s*\(', 'NUMBER(18,2)'),
    (r"'[^']*'(?:\s+AS\s+\w+)?$", 'VARCHAR(255)'),
    (r'\|\|', 'VARCHAR(500)'),
    (r'CURRENT_DATE', 'DATE'),
]

# Column name patterns for type inference when expression patterns don't match
COLUMN_NAME_TYPE_INFERENCE = [
    (r'(?i)_DT$|_DATE$|^STRT_DT$|^END_DT$|^START_DT$|^CURRENT_STRT_DT$|^CURRENT_RUN_STRT_DT$', 'DATE'),
    (r'(?i)_DTTM$|_TS$|DATETIME$|PROCESS_TIME$|^REC_STRT_TS$|^REC_END_TS$|^INSERTDATETIME$', 'TIMESTAMP_NTZ'),
    (r'(?i)_AMT$|^AMOUNT$|^BALANCE$|_BAL$|_RT$|^INTRST_RT$', 'NUMBER(18,6)'),
    (r'(?i)_CNT$|^COUNT$|^RPTID$|_NUM$|^ERRORCODE$|^SQLCODE$', 'INTEGER'),
    (r'(?i)_CD$|_TYPE$|_NM$|_DESC$|_FLAG$|_IND$|^FILLER', 'VARCHAR(255)'),
]


class DDLGenerator(BaseGenerator):
    """Generates Snowflake DDL from STTM documents."""

    def __init__(
        self,
        plans_dir: str = 'plans',
        output_dir: str = 'output',
        input_dir: str = 'inputs',
        config_dir: str = 'config',
    ):
        super().__init__(plans_dir=plans_dir, output_dir=output_dir)
        self.input_dir = Path(input_dir)
        self.config_dir = Path(config_dir)
        self.type_overrides = self._load_type_overrides()
        self.converter = ExpressionConverter()

    def _load_type_overrides(self) -> Dict[str, Dict[str, str]]:
        """Load column type overrides from config."""
        override_path = self.config_dir / 'table_type_overrides.json'
        if override_path.exists():
            with open(override_path, 'r', encoding='utf-8') as f:
                data = json.load(f)
            return data.get('overrides', {})
        return {}

    def generate(self) -> None:
        """Generate DDL for all STTM input files."""
        for json_file in sorted(self.input_dir.glob('*.json')):
            self.logger.info(f"Generating DDL for: {json_file.name}")
            doc = STTMDocument.from_file(json_file)
            ddl_sql = self._generate_ddl(doc, json_file.stem)
            self.save_output(ddl_sql, f'{json_file.stem}/ddl/{json_file.stem}_ddl.sql')

    def _generate_ddl(self, doc: STTMDocument, source_name: str) -> str:
        """Generate DDL SQL for all tables in the document."""
        tables = doc.get_table_inventory()
        graph = doc.build_dependency_graph()
        volatile_tables = set(doc.get_volatile_tables())

        # Get execution order for volatile tables
        if volatile_tables:
            exec_order = resolve_execution_order(
                graph, volatile_only=True, volatile_tables=volatile_tables
            )
        else:
            exec_order = []

        # Track tables already emitted to avoid duplicates
        emitted_tables: set = set()

        lines: List[str] = []
        lines.append(self._file_header(source_name, 'DDL'))

        # Generate DDL for volatile tables in dependency order
        if exec_order:
            lines.append('-- ============================================')
            lines.append('-- TEMPORARY TABLES (in dependency order)')
            lines.append('-- ============================================')
            lines.append('')

            for table_name in exec_order:
                if table_name in tables and table_name.upper() not in emitted_tables:
                    ddl = self._generate_table_ddl(
                        table_name, tables[table_name], is_volatile=True
                    )
                    lines.append(ddl)
                    lines.append('')
                    emitted_tables.add(table_name.upper())

        # Generate DDL for DELETE target tables (persistent work tables)
        delete_tables = doc.get_delete_tables()
        if delete_tables:
            lines.append('-- ============================================')
            lines.append('-- DELETE TARGET TABLES (persistent work tables)')
            lines.append('-- ============================================')
            lines.append('')

            for table_name in delete_tables:
                if table_name in tables and table_name.upper() not in emitted_tables:
                    ddl = self._generate_table_ddl(
                        table_name, tables[table_name], is_volatile=False
                    )
                    lines.append(ddl)
                    lines.append('')
                    emitted_tables.add(table_name.upper())

        # Generate DDL for final target tables
        final_tables = doc.get_final_target_tables()
        if final_tables:
            lines.append('-- ============================================')
            lines.append('-- FINAL TARGET TABLES')
            lines.append('-- ============================================')
            lines.append('')

            for table_name in final_tables:
                if table_name in tables and table_name.upper() not in emitted_tables:
                    ddl = self._generate_table_ddl(
                        table_name, tables[table_name], is_volatile=False
                    )
                    lines.append(ddl)
                    lines.append('')
                    emitted_tables.add(table_name.upper())

        return '\n'.join(lines)

    def _generate_table_ddl(
        self, table_name: str, table_def: TableDefinition, is_volatile: bool
    ) -> str:
        """Generate DDL for a single table."""
        # Apply schema mapping to table name
        mapped_name = self.converter.convert_expression(table_name)

        if is_volatile:
            create_stmt = f"CREATE OR REPLACE TEMPORARY TABLE {table_name}"
        else:
            create_stmt = f"CREATE TABLE IF NOT EXISTS {mapped_name}"

        col_lines = []
        seen_cols = set()
        for col_name, col_def in table_def.columns.items():
            # Skip wildcard '*' columns (from DELETE edges merged into INSERT)
            if col_name == '*':
                continue
            # Skip duplicate columns
            if col_name.upper() in seen_cols:
                continue
            seen_cols.add(col_name.upper())
            col_type = self._infer_column_type(table_name, col_name, col_def)
            col_lines.append(f"    {col_name} {col_type}")

        columns_sql = ',\n'.join(col_lines)
        ddl = f"{create_stmt} (\n{columns_sql}\n);"

        # Add COMMENT ON TABLE for persistent tables
        if not is_volatile:
            ddl += f"\n\nCOMMENT ON TABLE {mapped_name} IS 'Generated by STTM-SnowSQL-Toolkit';"

        return ddl

    def _infer_column_type(
        self, table_name: str, col_name: str, col_def: ColumnDefinition
    ) -> str:
        """Infer Snowflake column type from expression, column name, or overrides."""
        import re

        # Check overrides first
        if table_name in self.type_overrides:
            overrides = self.type_overrides[table_name]
            if col_name in overrides:
                return overrides[col_name]

        # Expression-based inference
        expr = col_def.sql_expression
        for pattern, sf_type in TYPE_INFERENCE:
            if re.search(pattern, expr, re.IGNORECASE):
                return sf_type

        # Column name-based inference
        for pattern, sf_type in COLUMN_NAME_TYPE_INFERENCE:
            if re.search(pattern, col_name):
                return sf_type

        # Default
        return 'VARCHAR'

    def _file_header(self, source_name: str, artifact_type: str) -> str:
        """Generate file header comment."""
        return (
            f"-- ============================================\n"
            f"-- {artifact_type}: Generated from {source_name}\n"
            f"-- Generated by: STTM-SnowSQL-Toolkit\n"
            f"-- Date: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n"
            f"-- ============================================\n"
        )


def main():
    """Generate DDL from STTM inputs."""
    project_root = Path(__file__).resolve().parent.parent
    generator = DDLGenerator(
        plans_dir=str(project_root / 'plans'),
        output_dir=str(project_root / 'output'),
        input_dir=str(project_root / 'inputs'),
        config_dir=str(project_root / 'config'),
    )
    generator.generate()
    print("DDL generation complete.")


if __name__ == '__main__':
    main()
