"""Snowflake SQL generators (DDL, DML, stored procedures, views, lineage)."""
