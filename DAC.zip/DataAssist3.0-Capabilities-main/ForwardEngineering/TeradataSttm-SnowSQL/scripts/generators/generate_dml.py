"""
DML Generator
=============
Generates Snowflake DML (INSERT INTO, CREATE TEMPORARY TABLE AS SELECT)
from STTM lineage edges. Extends BaseGenerator.

For volatile tables: CREATE OR REPLACE TEMPORARY TABLE <name> AS SELECT ...
For final targets: INSERT INTO <name> (...) SELECT ... FROM ... JOIN ... WHERE ...

Output: output/dml/<filename>_dml.sql
"""

import json
import re
import sys
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from base.base_generator import BaseGenerator
from parsers.sttm_models import DMLOperation, STTMDocument, ReconstructedStatement
from converter.dependency_resolver import resolve_execution_order
from converter.expression_converter import ExpressionConverter
from converter.statement_assembler import StatementAssembler


class DMLGenerator(BaseGenerator):
    """Generates Snowflake DML from STTM documents."""

    def __init__(
        self,
        plans_dir: str = 'plans',
        output_dir: str = 'output',
        input_dir: str = 'inputs',
    ):
        super().__init__(plans_dir=plans_dir, output_dir=output_dir)
        self.input_dir = Path(input_dir)
        self.converter = ExpressionConverter()
        self.assembler = StatementAssembler(self.converter)
        self.implicit_joins = self._load_implicit_joins()

    def _load_implicit_joins(self) -> Dict:
        """Load implicit_joins config for injecting missing JOINs."""
        config_path = Path(__file__).resolve().parent.parent / 'config' / 'converter_config.json'
        if config_path.exists():
            with open(config_path, 'r', encoding='utf-8') as f:
                data = json.load(f)
            return data.get('implicit_joins', {})
        return {}

    def generate(self) -> None:
        """Generate DML for all STTM input files."""
        for json_file in sorted(self.input_dir.glob('*.json')):
            self.logger.info(f"Generating DML for: {json_file.name}")
            doc = STTMDocument.from_file(json_file)
            dml_sql = self._generate_dml(doc, json_file.stem)
            self.save_output(dml_sql, f'{json_file.stem}/dml/{json_file.stem}_dml.sql')

    def _build_subquery_map(self, doc: STTMDocument) -> Dict[str, str]:
        """Build a map of alias -> resolved subquery SQL from STTM metadata.

        The STTM JSON may contain a 'subqueries' section with actual SQL for
        subquery aliases. This map is used to replace (subquery) placeholders.
        """
        subquery_map: Dict[str, str] = {}
        subqueries = doc.metadata.get('subqueries', [])
        for sq in subqueries:
            alias = sq.get('alias', '').upper()
            query_sql = sq.get('query_sql', '')
            if alias and query_sql:
                # Convert Teradata expressions to Snowflake
                converted = self.converter.convert_expression(query_sql)
                subquery_map[alias] = converted
        return subquery_map

    def _resolve_subquery_placeholders(
        self, join_clauses: List[str], target_table: str,
        subquery_map: Dict[str, str],
        volatile_tables: Optional[set] = None,
    ) -> List[str]:
        """Replace (subquery) placeholders in JOIN clauses with actual SQL.

        Also resolves (subquery) references to known temp tables when the alias
        closely matches a volatile table name (e.g. STR_DT -> STRT_DT).
        """
        resolved = []
        for jc in join_clauses:
            if '(subquery)' in jc:
                # Extract the alias from the JOIN clause pattern:
                # JOIN (subquery) <ALIAS> ON ... or CROSS JOIN (subquery) <ALIAS>
                alias_match = re.search(
                    r'\(subquery\)\s+(\w+)(?:\s+ON\b|\s*$)', jc, re.IGNORECASE
                )
                if alias_match:
                    alias = alias_match.group(1).upper()
                    if alias in subquery_map:
                        actual_sql = subquery_map[alias]
                        # Strip trailing "AS <alias>" since the JOIN already has the alias
                        actual_sql = re.sub(
                            rf'\)\s*AS\s+{re.escape(alias)}\s*$',
                            ')',
                            actual_sql.strip(),
                            flags=re.IGNORECASE
                        )
                        # Ensure the subquery is wrapped in parens
                        if not actual_sql.strip().startswith('('):
                            actual_sql = f"({actual_sql})"
                        jc = jc.replace('(subquery)', actual_sql)
                    elif volatile_tables:
                        # Try to match alias to a known temp table name
                        matched_table = self._match_temp_table(
                            alias, volatile_tables
                        )
                        if matched_table:
                            # Replace (subquery) ALIAS with the temp table name
                            jc = re.sub(
                                r'\(subquery\)\s+' + re.escape(alias_match.group(1)),
                                matched_table,
                                jc,
                                flags=re.IGNORECASE
                            )
            resolved.append(jc)
        return resolved

    @staticmethod
    def _match_temp_table(alias: str, volatile_tables: set) -> Optional[str]:
        """Match a subquery alias to a known temp table name.

        Supports exact match (case-insensitive) and close fuzzy match
        (e.g. STR_DT -> STRT_DT when only 1-2 chars differ).
        """
        alias_upper = alias.upper()
        # Exact match first
        for vt in volatile_tables:
            if vt.upper() == alias_upper:
                return vt
        # Close match: alias is a substring or vice versa, or edit distance <= 2
        for vt in volatile_tables:
            vt_upper = vt.upper()
            # Check if one contains the other
            if alias_upper in vt_upper or vt_upper in alias_upper:
                return vt
        return None

    def _generate_dml(self, doc: STTMDocument, source_name: str) -> str:
        """Generate DML SQL for all tables in the document."""
        volatile_tables = set(doc.get_volatile_tables())

        # Pass volatile table names to converter BEFORE assembly so bind
        # variables like :STARTDATE are converted during expression processing
        self.converter.set_volatile_tables(volatile_tables)

        statements = self.assembler.assemble_all(doc)
        graph = doc.build_dependency_graph()

        # Build subquery resolution map from STTM metadata
        subquery_map = self._build_subquery_map(doc)

        # Resolve subquery placeholders in all statements
        for table_name, stmt in statements.items():
            if stmt.join_clauses:
                stmt.join_clauses[:] = self._resolve_subquery_placeholders(
                    stmt.join_clauses, table_name, subquery_map,
                    volatile_tables=volatile_tables,
                )

        # Inject implicit JOINs when WHERE references aliases not defined in JOINs
        for table_name, stmt in statements.items():
            self._inject_implicit_joins(stmt)

        # Get execution order for volatile tables
        if volatile_tables:
            exec_order = resolve_execution_order(
                graph, volatile_only=True, volatile_tables=volatile_tables
            )
        else:
            exec_order = []

        lines: List[str] = []
        lines.append(self._file_header(source_name, 'DML'))

        # Generate CTAS for volatile tables in dependency order
        if exec_order:
            lines.append('-- ============================================')
            lines.append('-- TEMPORARY TABLE POPULATION (dependency order)')
            lines.append('-- ============================================')
            lines.append('')

            for table_name in exec_order:
                if table_name in statements:
                    dml = self._generate_ctas(
                        statements[table_name], volatile_tables
                    )
                    lines.append(dml)
                    lines.append('')

        # Generate DELETE for delete target tables (before INSERTs)
        delete_tables = doc.get_delete_tables()
        if delete_tables:
            lines.append('-- ============================================')
            lines.append('-- DELETE FROM WORK TABLES')
            lines.append('-- ============================================')
            lines.append('')

            for table_name in delete_tables:
                if table_name in statements:
                    dml = self._generate_delete(statements[table_name], doc)
                    lines.append(dml)
                    lines.append('')

        # Generate DELETE + INSERT for final target tables (truncate-and-reload)
        final_tables = doc.get_final_target_tables()
        if final_tables:
            already_deleted = set(t.upper() for t in (delete_tables or []))
            needs_delete = [t for t in final_tables
                           if t.upper() not in already_deleted and t in statements]
            if needs_delete:
                lines.append('-- ============================================')
                lines.append('-- DELETE FROM TARGET TABLES (truncate-and-reload)')
                lines.append('-- ============================================')
                lines.append('')
                for table_name in needs_delete:
                    mapped_table = self.converter.convert_expression(table_name)
                    lines.append(f"DELETE FROM {mapped_table};")
                    lines.append('')

            lines.append('-- ============================================')
            lines.append('-- FINAL TARGET TABLE INSERT')
            lines.append('-- ============================================')
            lines.append('')

            for table_name in final_tables:
                if table_name in statements:
                    dml = self._generate_insert(statements[table_name])
                    lines.append(dml)
                    lines.append('')

        return '\n'.join(lines)

    def _inject_implicit_joins(self, stmt: ReconstructedStatement) -> None:
        """Inject missing JOINs when WHERE clause references aliases not defined in any JOIN.

        Uses the implicit_joins config to map alias -> table + ON condition.
        """
        if not self.implicit_joins or not stmt.where_clause:
            return

        # Collect aliases already defined in JOINs
        defined_aliases = set()
        for jc in stmt.join_clauses:
            alias_match = re.search(
                r'\bJOIN\s+\S+\s+(?:AS\s+)?(\w+)\s+ON\b', jc, re.IGNORECASE
            )
            if alias_match:
                defined_aliases.add(alias_match.group(1).upper())

        # Check if WHERE references any implicit join aliases
        for alias, join_config in self.implicit_joins.items():
            if alias.upper() in defined_aliases:
                continue
            # Check if alias is referenced in WHERE clause
            if not re.search(rf'\b{re.escape(alias)}\b\.', stmt.where_clause, re.IGNORECASE):
                continue

            # Build the JOIN clause
            join_table = self.converter.convert_expression(join_config['table'])
            join_type = join_config.get('type', 'INNER JOIN')
            on_pattern = join_config.get('on_pattern', '')

            # Try to find a matching join key from the FROM table
            from_table_base = stmt.from_table.split()[0] if stmt.from_table else ''
            on_clause = ''
            for join_key in join_config.get('join_keys', []):
                # Check if FROM table or any expression references this key
                all_text = ' '.join(e for _, e in stmt.select_expressions)
                all_text += ' ' + (stmt.where_clause or '')
                if re.search(rf'\b{re.escape(join_key)}\b', all_text, re.IGNORECASE):
                    on_clause = on_pattern.format(
                        from_table=from_table_base, join_key=join_key
                    )
                    on_clause = self.converter.convert_expression(on_clause)
                    break

            if on_clause:
                join_clause = f"{join_type} {join_table} AS {alias} ON {on_clause}"
                stmt.join_clauses.append(join_clause)
                defined_aliases.add(alias.upper())

    def _generate_ctas(self, stmt: ReconstructedStatement,
                        volatile_tables: set = None) -> str:
        """Generate CREATE OR REPLACE TEMPORARY TABLE AS SELECT.

        When union_tables is populated, generates:
            SELECT ... FROM table1 UNION ALL SELECT ... FROM table2
        """
        import re
        lines: List[str] = []
        lines.append(f"CREATE OR REPLACE TEMPORARY TABLE {stmt.target_table} AS")

        if stmt.union_tables and len(stmt.union_tables) >= 2:
            # Generate UNION ALL across the source tables
            union_parts = []
            for i, src_table in enumerate(stmt.union_tables):
                mapped_table = self.converter.convert_expression(src_table)
                part_lines = ["SELECT"]
                select_parts = []
                for col_name, expr in stmt.select_expressions:
                    select_parts.append(f"    {expr}")
                part_lines.append(',\n'.join(select_parts))
                part_lines.append(f"FROM {mapped_table}")
                if stmt.where_clause:
                    part_lines.append(f"WHERE {stmt.where_clause}")
                union_parts.append('\n'.join(part_lines))

            lines.append('\nUNION ALL\n'.join(union_parts))
        else:
            lines.append("SELECT")

            # SELECT expressions
            select_parts = []
            for col_name, expr in stmt.select_expressions:
                select_parts.append(f"    {expr}")
            lines.append(',\n'.join(select_parts))

            # FROM clause — detect temp table references in expressions
            if stmt.from_table:
                lines.append(f"FROM {stmt.from_table}")
            elif volatile_tables:
                # Check if any expression or WHERE clause references a temp table
                all_text = ' '.join(e for _, e in stmt.select_expressions)
                all_text += ' ' + (stmt.where_clause or '')
                ref_table = None
                for vt in volatile_tables:
                    if vt.upper() != stmt.target_table.upper() and re.search(
                        rf'\b{re.escape(vt)}\b', all_text, re.IGNORECASE
                    ):
                        ref_table = vt
                        break
                if ref_table:
                    lines.append(f"FROM {ref_table}")
                elif stmt.where_clause:
                    lines.append("-- TODO: Missing FROM clause. The STTM input did not capture")
                    lines.append("-- the source table for this query. Add the correct FROM table.")
            elif stmt.where_clause:
                lines.append("-- TODO: Missing FROM clause. The STTM input did not capture")
                lines.append("-- the source table for this query. Add the correct FROM table.")

            # JOIN clauses
            for join_clause in stmt.join_clauses:
                if '(subquery)' in join_clause:
                    lines.append("-- TODO: Resolve subquery placeholder with actual SQL")
                lines.append(f"{join_clause}")

            # WHERE clause
            if stmt.where_clause:
                lines.append(f"WHERE {stmt.where_clause}")

        lines.append(';')
        return '\n'.join(lines)

    def _generate_delete(self, stmt: ReconstructedStatement,
                         doc: STTMDocument = None) -> str:
        """Generate DELETE FROM ... WHERE ... using transformation expressions.

        For tables with both DELETE and INSERT edges (STTM format), the DELETE
        WHERE clause is extracted directly from DELETE edges rather than the
        merged assembled statement.
        """
        mapped_table = self.converter.convert_expression(stmt.target_table)
        lines: List[str] = []

        lines.append(f"DELETE FROM {mapped_table}")

        # Extract WHERE clause directly from DELETE edges (handles STTM format
        # where the WHERE is in filter_conditions and the assembler merges
        # DELETE + INSERT edges into one statement)
        delete_where = self._extract_delete_where(stmt, doc)

        if delete_where:
            lines.append(f"WHERE {delete_where}")
        elif stmt.where_clause:
            lines.append(f"WHERE {stmt.where_clause}")
        elif stmt.select_expressions:
            # Fallback: build WHERE from transformation expression
            _, expr = stmt.select_expressions[0]
            clean_expr = expr
            upper_expr = clean_expr.upper()
            as_idx = upper_expr.rfind(' AS ')
            if as_idx > 0:
                potential_alias = clean_expr[as_idx + 4:].strip()
                if potential_alias.upper().startswith('COL_'):
                    clean_expr = clean_expr[:as_idx].strip()

            if clean_expr.strip() and clean_expr.strip() != '*':
                if stmt.from_table:
                    lines.append(
                        f"WHERE {stmt.column_names[0]} <= "
                        f"(SELECT {clean_expr} FROM {stmt.from_table})"
                    )
                else:
                    lines.append(f"WHERE {clean_expr}")

        lines.append(';')
        return '\n'.join(lines)

    def _extract_delete_where(self, stmt: ReconstructedStatement,
                               doc: STTMDocument = None) -> str:
        """Extract WHERE condition from DELETE edges for a table.

        When a table has both DELETE and INSERT edges, the assembler merges
        them into one statement. This method finds DELETE edges directly
        and extracts their where_conditions.
        """
        if doc is None:
            return ""

        delete_conditions = []
        for edge in doc.edges:
            if (edge.target.table == stmt.target_table
                    and edge.dml_operation == DMLOperation.DELETE
                    and edge.where_conditions):
                cond = self.converter.convert_where_condition(
                    edge.where_conditions.strip()
                )
                if cond and cond not in delete_conditions:
                    delete_conditions.append(cond)

        if delete_conditions:
            return ' AND '.join(delete_conditions)
        return ""

    def _generate_insert(self, stmt: ReconstructedStatement) -> str:
        """Generate INSERT INTO ... SELECT ... FROM ... JOIN ... WHERE.

        Supports UNION ALL when multiple source tables contribute identical
        column sets (e.g. _CUR + _HIST tables).
        """
        mapped_table = self.converter.convert_expression(stmt.target_table)
        lines: List[str] = []

        # INSERT INTO with column list
        col_list = ', '.join(stmt.column_names)
        lines.append(f"INSERT INTO {mapped_table}")
        lines.append(f"({col_list})")

        # Build cleaned select expressions (shared between single and UNION paths)
        clean_select_parts = []
        for col_name, expr in stmt.select_expressions:
            clean_expr = expr
            upper_expr = clean_expr.upper()
            as_idx = upper_expr.rfind(' AS ')
            if as_idx > 0:
                potential_alias = clean_expr[as_idx + 4:].strip()
                if potential_alias.upper() == col_name.upper():
                    clean_expr = clean_expr[:as_idx].strip()
            clean_select_parts.append(clean_expr)

        # Detect aggregate functions to auto-add GROUP BY
        group_by_cols = self._detect_group_by_columns(
            stmt.select_expressions, clean_select_parts
        )

        if stmt.union_tables and len(stmt.union_tables) >= 2:
            # Generate UNION ALL across the source tables
            union_parts = []
            for src_table in stmt.union_tables:
                mapped_src = self.converter.convert_expression(src_table)
                part_lines = ["SELECT"]
                src_parts = []
                for clean_expr in clean_select_parts:
                    # Replace the primary FROM table reference with this union source
                    rewritten = self._rewrite_expr_for_union_source(
                        clean_expr, stmt.from_table, mapped_src
                    )
                    src_parts.append(f"    {rewritten}")
                part_lines.append(',\n'.join(src_parts))
                part_lines.append(f"FROM {mapped_src}")
                # JOIN clauses (rewrite table references for this union source)
                for join_clause in stmt.join_clauses:
                    rewritten_join = self._rewrite_expr_for_union_source(
                        join_clause, stmt.from_table, mapped_src
                    )
                    part_lines.append(rewritten_join)
                # WHERE clause
                if stmt.where_clause:
                    part_lines.append(f"WHERE {stmt.where_clause}")
                if group_by_cols:
                    rewritten_gb = []
                    for gc in group_by_cols:
                        rewritten_gb.append(
                            self._rewrite_expr_for_union_source(gc, stmt.from_table, mapped_src)
                        )
                    part_lines.append(f"GROUP BY {', '.join(rewritten_gb)}")
                union_parts.append('\n'.join(part_lines))

            lines.append('\nUNION ALL\n'.join(union_parts))
        else:
            lines.append("SELECT")
            select_display = [f"    {p}" for p in clean_select_parts]
            lines.append(',\n'.join(select_display))

            # FROM clause
            if stmt.from_table:
                lines.append(f"FROM {stmt.from_table}")

            # JOIN clauses
            for join_clause in stmt.join_clauses:
                if '(subquery)' in join_clause:
                    lines.append("-- TODO: Resolve subquery placeholder with actual SQL")
                lines.append(f"{join_clause}")

            # WHERE clause
            if stmt.where_clause:
                lines.append(f"WHERE {stmt.where_clause}")

            # GROUP BY clause (auto-detected from aggregate functions)
            if group_by_cols:
                lines.append(f"GROUP BY {', '.join(group_by_cols)}")

        lines.append(';')
        return '\n'.join(lines)

    @staticmethod
    def _detect_group_by_columns(
        select_expressions: list, clean_parts: list
    ) -> List[str]:
        """Detect if SELECT has aggregate functions and return non-aggregated columns for GROUP BY.

        When MAX/MIN/SUM/COUNT/AVG are used in some but not all select expressions,
        the non-aggregated columns must appear in GROUP BY.
        """
        agg_pattern = re.compile(
            r'\b(MAX|MIN|SUM|COUNT|AVG)\s*\(', re.IGNORECASE
        )
        has_agg = any(agg_pattern.search(p) for p in clean_parts)
        if not has_agg:
            return []

        non_agg_cols = []
        for (col_name, expr), clean_expr in zip(select_expressions, clean_parts):
            if not agg_pattern.search(clean_expr):
                non_agg_cols.append(clean_expr)
        return non_agg_cols

    @staticmethod
    def _rewrite_expr_for_union_source(
        expr: str, original_from: str, new_source: str
    ) -> str:
        """Rewrite a SQL expression to replace the original FROM table with a new source.

        Used for UNION ALL generation where each union leg references a different source table.
        """
        if not original_from:
            return expr
        # Extract the unqualified table name from the original FROM (may include alias)
        original_table = original_from.split()[0]
        new_table = new_source.split()[0]
        if original_table.upper() == new_table.upper():
            return expr
        # Replace qualified references: DB.SCHEMA.TABLE.COL -> DB.SCHEMA.NEW_TABLE.COL
        result = re.sub(
            re.escape(original_table), new_table, expr, flags=re.IGNORECASE
        )
        return result

    def _file_header(self, source_name: str, artifact_type: str) -> str:
        """Generate file header comment."""
        return (
            f"-- ============================================\n"
            f"-- {artifact_type}: Generated from {source_name}\n"
            f"-- Generated by: STTM-SnowSQL-Toolkit\n"
            f"-- Date: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n"
            f"-- ============================================\n"
        )


def main():
    """Generate DML from STTM inputs."""
    project_root = Path(__file__).resolve().parent.parent
    generator = DMLGenerator(
        plans_dir=str(project_root / 'plans'),
        output_dir=str(project_root / 'output'),
        input_dir=str(project_root / 'inputs'),
    )
    generator.generate()
    print("DML generation complete.")


if __name__ == '__main__':
    main()
