"""
Lineage Report Generator
=========================
Generates a Markdown report showing source->target column mappings,
transformation types, and complexity scores.

Output: output/lineage_report.md
"""

import sys
from datetime import datetime
from pathlib import Path
from typing import Dict, List

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from base.base_generator import BaseGenerator
from parsers.sttm_models import STTMDocument, DMLOperation


class LineageReportGenerator(BaseGenerator):
    """Generates lineage reports from STTM documents."""

    def __init__(
        self,
        plans_dir: str = 'plans',
        output_dir: str = 'output',
        input_dir: str = 'inputs',
    ):
        super().__init__(plans_dir=plans_dir, output_dir=output_dir)
        self.input_dir = Path(input_dir)

    def generate(self) -> None:
        """Generate lineage reports for all STTM input files."""
        for json_file in sorted(self.input_dir.glob('*.json')):
            self.logger.info(f"Generating lineage report for: {json_file.name}")
            doc = STTMDocument.from_file(json_file)
            report = self._generate_report(doc, json_file.stem)
            self.save_output(report, f'{json_file.stem}/lineage_report_{json_file.stem}.md')

    def _generate_report(self, doc: STTMDocument, source_name: str) -> str:
        """Generate a lineage report for a single document."""
        tables = doc.get_table_inventory()
        graph = doc.build_dependency_graph()

        lines: List[str] = []

        # Header
        lines.append(f"# Lineage Report: {source_name}")
        lines.append(f"")
        lines.append(f"**Generated:** {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        lines.append(f"**Source dialect:** {doc.metadata.get('dialect', 'N/A')}")
        lines.append(f"**Total edges:** {len(doc.edges)}")
        lines.append(f"**Total tables:** {len(tables)}")
        lines.append(f"")

        # Summary statistics
        lines.append("## Summary Statistics")
        lines.append("")
        lines.append("| Metric | Value |")
        lines.append("|--------|-------|")
        lines.append(f"| Total Edges | {len(doc.edges)} |")
        lines.append(f"| Volatile Tables | {len(doc.get_volatile_tables())} |")
        lines.append(f"| Final Target Tables | {len(doc.get_final_target_tables())} |")
        lines.append(f"| Unique Source Tables | {len(doc.get_source_tables())} |")

        # Count by transformation type
        type_counts: Dict[str, int] = {}
        subtype_counts: Dict[str, int] = {}
        total_complexity = 0
        for edge in doc.edges:
            t = edge.transformation.type.value
            st = edge.transformation.subtype.value
            type_counts[t] = type_counts.get(t, 0) + 1
            subtype_counts[st] = subtype_counts.get(st, 0) + 1
            total_complexity += edge.transformation.complexity_score

        lines.append(f"| Avg Complexity Score | {total_complexity / max(len(doc.edges), 1):.1f} |")
        lines.append("")

        # Transformation breakdown
        lines.append("## Transformation Types")
        lines.append("")
        lines.append("| Type | Count |")
        lines.append("|------|-------|")
        for t, count in sorted(type_counts.items()):
            lines.append(f"| {t} | {count} |")
        lines.append("")

        lines.append("| Subtype | Count |")
        lines.append("|---------|-------|")
        for st, count in sorted(subtype_counts.items()):
            lines.append(f"| {st} | {count} |")
        lines.append("")

        # Dependency graph
        lines.append("## Dependency Graph")
        lines.append("")
        lines.append("```")
        volatile_tables = set(doc.get_volatile_tables())
        for table_name in sorted(graph.keys()):
            if table_name in volatile_tables:
                deps = graph[table_name] & volatile_tables
                dep_str = ', '.join(sorted(deps)) if deps else '(none)'
                lines.append(f"  {table_name} -> {dep_str}")
        lines.append("```")
        lines.append("")

        # Per-table detail
        lines.append("## Table Detail")
        lines.append("")

        for table_name in sorted(tables.keys()):
            table_def = tables[table_name]
            table_type = "VOLATILE" if table_def.is_volatile else "FINAL TARGET"

            lines.append(f"### {table_name} ({table_type})")
            lines.append("")
            lines.append(f"**Columns:** {len(table_def.columns)} | "
                        f"**Edges:** {len(table_def.source_edges)} | "
                        f"**JOINs:** {len(table_def.join_conditions)} | "
                        f"**WHEREs:** {len(table_def.where_conditions)}")
            lines.append("")

            # Column mappings table
            lines.append("| Target Column | Source | Expression | Type | Complexity |")
            lines.append("|---------------|--------|------------|------|------------|")

            seen_cols = set()
            for edge in table_def.source_edges:
                col_key = (edge.target.column, edge.transformation.sql_expression)
                if col_key in seen_cols:
                    continue
                seen_cols.add(col_key)

                src = f"{edge.source.table}.{edge.source.column}"
                expr = edge.transformation.sql_expression
                if len(expr) > 60:
                    expr = expr[:57] + "..."
                subtype = edge.transformation.subtype.value
                complexity = edge.transformation.complexity_score

                lines.append(
                    f"| {edge.target.column} | {src} | `{expr}` | {subtype} | {complexity} |"
                )

            lines.append("")

        return '\n'.join(lines)


def main():
    """Generate lineage reports from STTM inputs."""
    project_root = Path(__file__).resolve().parent.parent
    generator = LineageReportGenerator(
        plans_dir=str(project_root / 'plans'),
        output_dir=str(project_root / 'output'),
        input_dir=str(project_root / 'inputs'),
    )
    generator.generate()
    print("Lineage report generation complete.")


if __name__ == '__main__':
    main()
