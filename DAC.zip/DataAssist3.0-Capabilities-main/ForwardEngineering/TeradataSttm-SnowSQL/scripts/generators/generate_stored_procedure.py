"""
Stored Procedure Generator
===========================
Wraps DDL and DML into a Snowflake stored procedure.
Reads from output/ddl/ and output/dml/ and produces a procedure that
creates temporary tables, populates them, and inserts into the final target.

Output: output/stored_procedures/<filename>_proc.sql

Addresses validation requirements:
- PeriodID DATE DEFAULT NULL input parameter
- V_PeriodID variable declaration and resolution
- PROCESS_LOG table logging (start/success/failure)
- RAISE instead of RETURN in exception block
- No IF clause in exception block
- Proper column lists (no * wildcard)
- Subquery resolution (inline CONSL_STRT_DT -> v_periodId)
- SQLROWCOUNT for row counting
- No extra audit columns (DW_LOAD_TS, DW_UPDATE_TS, DW_SOURCE_SYSTEM)
"""

import json
import re
import sys
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from base.base_generator import BaseGenerator
from parsers.sttm_models import STTMDocument
from converter.dependency_resolver import resolve_execution_order
from converter.expression_converter import ExpressionConverter


class StoredProcedureGenerator(BaseGenerator):
    """Generates Snowflake stored procedures from DDL and DML."""

    # Columns that should not appear in generated SQL
    AUDIT_COLUMNS = {'DW_LOAD_TS', 'DW_UPDATE_TS', 'DW_SOURCE_SYSTEM'}

    def __init__(
        self,
        plans_dir: str = 'plans',
        output_dir: str = 'output',
        input_dir: str = 'inputs',
        config_dir: str = 'config',
    ):
        super().__init__(plans_dir=plans_dir, output_dir=output_dir)
        self.input_dir = Path(input_dir)
        self.config_dir = Path(config_dir)
        self.converter = ExpressionConverter()
        self.proc_config = self._load_proc_config()
        self.full_config = self._load_full_config()

    def _load_proc_config(self) -> Dict:
        """Load stored procedure configuration."""
        config_path = self.config_dir / 'converter_config.json'
        if config_path.exists():
            with open(config_path, 'r', encoding='utf-8') as f:
                data = json.load(f)
            return data.get('stored_procedure', {})
        return {}

    def _load_full_config(self) -> Dict:
        """Load full converter configuration."""
        config_path = self.config_dir / 'converter_config.json'
        if config_path.exists():
            with open(config_path, 'r', encoding='utf-8') as f:
                return json.load(f)
        return {}

    def _get_process_log_table(self) -> str:
        """Get the PROCESS_LOG table reference using schema mappings."""
        schema_mappings = self.full_config.get('schema_mappings', {})
        for key, mapping in schema_mappings.items():
            if 'E0' in key:
                db = mapping.get('snowflake_database', 'CCARDM_DB')
                schema = mapping.get('snowflake_schema', 'CCARDM_E0_SCHEMA')
                return f"{db}.{schema}.PROCESS_LOG"
        return "PROCESS_LOG"

    def _get_consl_strt_dt_table(self) -> str:
        """Get the CONSL_STRT_DT table reference."""
        return self.converter.convert_expression('P_CCARDM_01_E0.CONSL_STRT_DT')

    def generate(self) -> None:
        """Generate stored procedures from STTM input files."""
        for json_file in sorted(self.input_dir.glob('*.json')):
            self.logger.info(f"Generating stored procedure for: {json_file.name}")
            doc = STTMDocument.from_file(json_file)
            proc_sql = self._generate_procedure(doc, json_file.stem)
            self.save_output(
                proc_sql,
                f'{json_file.stem}/stored_procedures/{json_file.stem}_proc.sql'
            )

    def _generate_procedure(self, doc: STTMDocument, source_name: str) -> str:
        """Generate a complete stored procedure."""
        tables = doc.get_table_inventory()
        graph = doc.build_dependency_graph()
        volatile_tables = set(doc.get_volatile_tables())
        final_tables = doc.get_final_target_tables()
        delete_tables = doc.get_delete_tables()

        # Pass volatile table names to converter for bind variable resolution
        self.converter.set_volatile_tables(volatile_tables)

        # Read generated DDL and DML
        ddl_content = self._read_generated_file(f'{source_name}/ddl/{source_name}_ddl.sql')
        dml_content = self._read_generated_file(f'{source_name}/dml/{source_name}_dml.sql')

        # Post-process DML: replace inline CONSL_STRT_DT subqueries with :v_periodId
        dml_content = self._replace_subquery_with_period_var(dml_content)

        # Build procedure name
        proc_name_template = self.proc_config.get(
            'procedure_name_template', 'SP_{source_name}'
        )
        safe_source = source_name.upper().replace('.', '_').replace(' ', '_')
        proc_name = proc_name_template.format(source_name=safe_source)

        returns_type = self.proc_config.get('returns', 'VARCHAR(16777216)')
        execute_as = self.proc_config.get('execute_as', 'CALLER')
        error_handling = self.proc_config.get('error_handling', True)

        process_log_table = self._get_process_log_table()
        consl_strt_dt_table = self._get_consl_strt_dt_table()

        lines: List[str] = []
        lines.append(self._file_header(source_name, 'STORED PROCEDURE'))

        # CREATE PROCEDURE with PeriodID parameter
        lines.append(f"CREATE OR REPLACE PROCEDURE {proc_name}(")
        lines.append("    PeriodID DATE DEFAULT NULL,")
        lines.append("    P_BATCH_ID VARCHAR DEFAULT NULL")
        lines.append(")")
        lines.append(f"RETURNS {returns_type}")
        lines.append("LANGUAGE SQL")
        lines.append(f"EXECUTE AS {execute_as}")
        lines.append("AS")
        lines.append("$$")

        # DECLARE section with all required variables
        lines.append("DECLARE")
        lines.append("    WSQLCODE     INTEGER DEFAULT 0;")
        lines.append("    WSQLMSG      VARCHAR(10) DEFAULT '';")
        lines.append("    MSG_ERROR    VARCHAR(1000) DEFAULT '';")
        lines.append(f"    SRC_NM       VARCHAR(100) DEFAULT '{source_name}';")
        lines.append(f"    V_PROC_NAME  VARCHAR := '{proc_name}';")
        lines.append("    V_BATCH_ID   VARCHAR := COALESCE(P_BATCH_ID, UUID_STRING());")
        lines.append("    V_START_TIME TIMESTAMP_NTZ := CURRENT_TIMESTAMP();")
        lines.append("    V_ROWS_AFFECTED INTEGER := 0;")
        lines.append("    V_STEP       VARCHAR := 'INIT';")
        lines.append("    V_MSG_ERROR  VARCHAR(1000) DEFAULT '';")
        lines.append("    LV_NUM_ROWS  INTEGER DEFAULT 0;")
        lines.append("    V_COUNT      INTEGER DEFAULT 0;")
        lines.append("    VAR_COUNT    VARCHAR(10) DEFAULT '';")
        lines.append("    v_periodId   DATE DEFAULT NULL;")
        lines.append("    DB_NM        VARCHAR(100) DEFAULT '';")
        lines.append("    V_SQL        VARCHAR(16777216) DEFAULT '';")
        lines.append("    V_SQL1       VARCHAR(16777216) DEFAULT '';")
        lines.append("    V_SQL2       VARCHAR(16777216) DEFAULT '';")
        lines.append("    V_SQL3       VARCHAR(16777216) DEFAULT '';")
        lines.append("    V_SQL4       VARCHAR(16777216) DEFAULT '';")
        lines.append("BEGIN")
        lines.append("")

        # Resolve PeriodID parameter
        lines.append("    -- Resolve PeriodID parameter")
        lines.append("    IF (COALESCE(PeriodID, '1901-01-01' :: DATE) = '1901-01-01' :: DATE) THEN")
        lines.append(f"        SELECT CURRENT_STRT_DT INTO :v_periodId")
        lines.append(f"        FROM {consl_strt_dt_table};")
        lines.append("    ELSE")
        lines.append("        v_periodId := PeriodID;")
        lines.append("    END IF;")
        lines.append("")

        # PROCESS_LOG: Log start
        lines.append("    -- Log procedure start")
        lines.append(f"    INSERT INTO {process_log_table} (")
        lines.append('        "_SOURCE", DETAIL, PHASE, "ERRORCODE", SEVERITY, ACTIVITY, PROCESS_TIME')
        lines.append("    ) VALUES (")
        lines.append("        :SRC_NM,")
        lines.append("        'Procedure ' || :SRC_NM || ' started',")
        lines.append("        1, 0, 1,")
        lines.append(f"        '{source_name}',")
        lines.append("        CURRENT_TIMESTAMP()")
        lines.append("    );")
        lines.append("")

        # Step 1: Create and populate temporary tables
        if volatile_tables:
            exec_order = resolve_execution_order(
                graph, volatile_only=True, volatile_tables=volatile_tables
            )
            lines.append("    -- ==========================================")
            lines.append("    -- Step 1: Create and populate temporary tables")
            lines.append("    -- ==========================================")
            lines.append("")

            for i, table_name in enumerate(exec_order, 1):
                # Skip v_periodid temp table — superseded by PeriodID parameter
                if table_name.upper() == 'V_PERIODID':
                    lines.append(f"    -- Skipped temp table {table_name}: superseded by PeriodID parameter")
                    lines.append("")
                    continue

                lines.append(f"    V_STEP := 'Creating temporary table: {table_name}';")
                lines.append(f"    -- Temp table {i}/{len(exec_order)}: {table_name}")

                ctas = self._extract_ctas(dml_content, table_name)
                if ctas:
                    ctas = self._replace_v_periodid_refs(ctas)
                    for ctas_line in ctas.split('\n'):
                        lines.append(f"    {ctas_line}")
                else:
                    lines.append(f"    -- WARNING: CTAS not found for {table_name}")
                lines.append("")

        # Step 2: Delete from work tables
        if delete_tables:
            lines.append("    -- ==========================================")
            lines.append("    -- Step 2: Delete from work tables")
            lines.append("    -- ==========================================")
            lines.append("")

            for table_name in delete_tables:
                mapped_name = self.converter.convert_expression(table_name)
                lines.append(f"    V_STEP := 'Deleting from: {mapped_name}';")

                delete_sql = self._extract_delete(dml_content, table_name)
                if delete_sql:
                    delete_sql = self._replace_v_periodid_refs(delete_sql)
                    for delete_line in delete_sql.split('\n'):
                        lines.append(f"    {delete_line}")
                else:
                    lines.append(f"    -- WARNING: DELETE not found for {table_name}")
                lines.append("")

        # Step 3: Delete from final target tables + Insert (truncate-and-reload)
        step_num = 3 if delete_tables else 2
        if final_tables:
            # Determine which final tables need DELETE (not already in delete_tables)
            already_deleted = set(t.upper() for t in (delete_tables or []))

            lines.append("    -- ==========================================")
            lines.append(f"    -- Step {step_num}: Delete and insert into final target tables")
            lines.append("    -- ==========================================")
            lines.append("")
            lines.append("    -- Begin transaction for DELETE + INSERT pairs")
            lines.append("    BEGIN TRANSACTION;")
            lines.append("")

            for table_name in final_tables:
                mapped_name = self.converter.convert_expression(table_name)

                # Add DELETE FROM if not already deleted
                if table_name.upper() not in already_deleted:
                    lines.append(f"    V_STEP := 'Deleting from: {mapped_name}';")
                    lines.append(f"    DELETE FROM {mapped_name};")
                    lines.append("")

                lines.append(f"    V_STEP := 'Inserting into: {mapped_name}';")

                insert_sql = self._extract_insert(dml_content, table_name)
                if insert_sql:
                    insert_sql = self._replace_v_periodid_refs(insert_sql)
                    insert_sql = self._remove_audit_columns(insert_sql)
                    for insert_line in insert_sql.split('\n'):
                        lines.append(f"    {insert_line}")
                else:
                    lines.append(f"    -- WARNING: INSERT not found for {table_name}")
                lines.append("    LV_NUM_ROWS := SQLROWCOUNT;")
                lines.append("    V_ROWS_AFFECTED := V_ROWS_AFFECTED + LV_NUM_ROWS;")
                lines.append("")

            lines.append("    COMMIT;")
            lines.append("")

        # PROCESS_LOG: Log success with IF condition
        target_table_name = final_tables[0] if final_tables else source_name
        lines.append("    -- Log success")
        lines.append("    IF (COALESCE(WSQLCODE, 0) = 0) THEN")
        lines.append("        V_MSG_ERROR := 'PROCEDURE ' || SRC_NM || '  EXECUTED SUCCESSFULLY';")
        lines.append("        V_COUNT := LV_NUM_ROWS;")
        lines.append("        VAR_COUNT := CAST(V_COUNT AS VARCHAR(10));")
        lines.append(f"        MSG_ERROR := VAR_COUNT || ' RECORDS INSERTED TO {target_table_name}';")
        lines.append(f"        INSERT INTO {process_log_table} (")
        lines.append('            "_SOURCE", DETAIL, PHASE, "ERRORCODE", SEVERITY, ACTIVITY, PROCESS_TIME')
        lines.append("        ) VALUES (")
        lines.append("            :SRC_NM,")
        lines.append("            :MSG_ERROR,")
        lines.append("            1, 0, 1,")
        lines.append(f"            '{source_name}',")
        lines.append("            CURRENT_TIMESTAMP()")
        lines.append("        );")
        lines.append("    ELSE")
        lines.append(f"        MSG_ERROR := 'INSERTING VALUES INTO TABLE -  {target_table_name}' || ' - ' || MSG_ERROR;")
        lines.append(f"        INSERT INTO {process_log_table} (")
        lines.append('            "_SOURCE", DETAIL, PHASE, "ERRORCODE", SEVERITY, ACTIVITY, PROCESS_TIME')
        lines.append("        ) VALUES (")
        lines.append("            :SRC_NM,")
        lines.append("            :MSG_ERROR,")
        lines.append("            1, :WSQLCODE, 1,")
        lines.append(f"            '{source_name}',")
        lines.append("            CURRENT_TIMESTAMP()")
        lines.append("        );")
        lines.append("    END IF;")
        lines.append("")

        # Return success (no : prefix on variable names in RETURN)
        lines.append("    RETURN COALESCE(V_MSG_ERROR, V_PROC_NAME || ' completed successfully');")
        lines.append("")

        # Exception handling with RAISE — no IF clause, single PROCESS_LOG INSERT
        if error_handling:
            lines.append("EXCEPTION")
            lines.append("    WHEN OTHER THEN")
            lines.append("        ROLLBACK;")
            lines.append("        WSQLCODE  := SQLCODE;")
            lines.append("        WSQLMSG   := SQLSTATE;")
            lines.append("        MSG_ERROR := SQLCODE || ' FAILED - ERROR: ' || SQLERRM;")
            lines.append("        V_MSG_ERROR := MSG_ERROR;")
            lines.append(f"        INSERT INTO {process_log_table} (")
            lines.append('            "_SOURCE", DETAIL, PHASE, "ERRORCODE", SEVERITY, ACTIVITY, PROCESS_TIME')
            lines.append("        ) VALUES (")
            lines.append("            :SRC_NM,")
            lines.append("            :MSG_ERROR,")
            lines.append("            1, 0, 1,")
            lines.append(f"            '{source_name}',")
            lines.append("            CURRENT_TIMESTAMP()")
            lines.append("        );")
            lines.append("")

            # Drop temp tables on error
            if self.proc_config.get('drop_temp_tables_on_error', True) and volatile_tables:
                for table_name in reversed(list(volatile_tables)):
                    lines.append(f"        DROP TABLE IF EXISTS {table_name};")
                lines.append("")

            lines.append("        RAISE;")
            lines.append("")

        lines.append("END;")
        lines.append("$$;")
        lines.append("")

        # GRANT EXECUTE to standard role
        lines.append(f"-- Grant execute permission")
        lines.append(f"GRANT EXECUTE ON PROCEDURE {proc_name}(DATE, VARCHAR) TO ROLE DATA_ENGINEER;")

        return '\n'.join(lines)

    def _read_generated_file(self, relative_path: str) -> str:
        """Read a previously generated output file."""
        file_path = self.output_dir / relative_path
        if file_path.exists():
            return file_path.read_text(encoding='utf-8')
        self.logger.warning(f"Generated file not found: {file_path}")
        return ""

    @staticmethod
    def _replace_subquery_with_period_var(sql_text: str) -> str:
        """Replace (SELECT CURRENT_STRT_DT FROM ...) inline subqueries with :v_periodId.

        Also removes CROSS JOIN to CONSL_STRT_DT and replaces WHERE-clause
        CURRENT_STRT_DT references.
        """
        if not sql_text:
            return sql_text

        # Replace inline subquery form: (SELECT CURRENT_STRT_DT FROM <table>)
        sql_text = re.sub(
            r'\(SELECT\s+CURRENT_STRT_DT\s+FROM\s+[A-Za-z0-9_.]+\)',
            ':v_periodId',
            sql_text,
            flags=re.IGNORECASE
        )
        # Simplify (SELECT ADD_MONTHS(:v_periodId, ...) FROM <table>)
        sql_text = re.sub(
            r'\(SELECT\s+(ADD_MONTHS\([^)]+\))\s+FROM\s+[A-Za-z0-9_.]+\)',
            r'\1',
            sql_text,
            flags=re.IGNORECASE
        )
        # Remove CROSS JOIN to CONSL_STRT_DT
        sql_text = re.sub(
            r'\s*CROSS\s+JOIN\s+[A-Za-z0-9_.]*CONSL_STRT_DT\b(?:\s+\w+)?',
            '',
            sql_text,
            flags=re.IGNORECASE
        )

        # Resolve (subquery) STR_DT placeholders — replace with v_periodId ref
        sql_text = re.sub(
            r'(?:--\s*TODO:.*\n\s*)?CROSS\s+JOIN\s+\(subquery\)\s+STR_DT\b',
            '',
            sql_text,
            flags=re.IGNORECASE
        )

        # Replace bare CURRENT_STRT_DT references (from STR_DT subquery) with :v_periodId
        sql_text = re.sub(
            r'\bSTR_DT\.CURRENT_STRT_DT\b',
            ':v_periodId',
            sql_text,
            flags=re.IGNORECASE
        )

        # Replace CURRENT_STRT_DT in SELECT/WHERE value positions only
        # (not in INSERT column lists). Match when preceded by comma+space in SELECT,
        # or when it's a standalone column reference in SELECT expressions.
        # Use a two-pass approach: replace in SELECT clauses and WHERE clauses only.
        lines = sql_text.split('\n')
        new_lines = []
        in_column_list = False
        for line in lines:
            stripped = line.strip()
            # Detect INSERT column list lines: (COL1, COL2, COL3)
            if re.match(r'^\([\w\s,]+\)\s*$', stripped):
                in_column_list = True
                new_lines.append(line)
                continue
            in_column_list = False
            # Replace CURRENT_STRT_DT in non-column-list lines
            line = re.sub(
                r'(?<![.\w])CURRENT_STRT_DT(?![.\w])',
                ':v_periodId',
                line,
                flags=re.IGNORECASE
            )
            new_lines.append(line)
        sql_text = '\n'.join(new_lines)

        # Fix double-colon bind variables: ::v_periodId -> :v_periodId
        sql_text = re.sub(
            r'::v_periodId\b',
            ':v_periodId',
            sql_text,
        )

        return sql_text

    def _replace_v_periodid_refs(self, sql_text: str) -> str:
        """Replace V_PeriodID and CURRENT_STRT_DT references with :v_periodId."""
        if not sql_text:
            return sql_text

        # Replace bare V_PeriodID references (used in WHERE clauses from STTM)
        # Use negative lookbehind for : to avoid matching :v_periodId (already converted)
        sql_text = re.sub(
            r'(?<!:)\bV_PeriodID\b',
            ':v_periodId',
            sql_text,
            flags=re.IGNORECASE
        )

        # Replace STRT_DT = STRT_DT tautology (from alias stripping)
        sql_text = re.sub(
            r'\bSTRT_DT\s*=\s*STRT_DT\b',
            'STRT_DT = :v_periodId',
            sql_text,
            flags=re.IGNORECASE
        )

        return sql_text

    def _remove_audit_columns(self, sql_text: str) -> str:
        """Remove extra audit columns (DW_LOAD_TS, DW_UPDATE_TS, DW_SOURCE_SYSTEM)."""
        if not sql_text:
            return sql_text
        for col in self.AUDIT_COLUMNS:
            sql_text = re.sub(
                rf',\s*{col}\b', '', sql_text, flags=re.IGNORECASE
            )
            sql_text = re.sub(
                rf'\b{col}\s*,\s*', '', sql_text, flags=re.IGNORECASE
            )
            sql_text = re.sub(
                rf'^\s*CURRENT_TIMESTAMP\(\).*{col}.*$\n?',
                '', sql_text, flags=re.IGNORECASE | re.MULTILINE
            )
        return sql_text

    def _extract_ctas(self, dml_content: str, table_name: str) -> Optional[str]:
        """Extract CTAS statement for a specific table from DML content."""
        pattern = (
            rf'CREATE\s+OR\s+REPLACE\s+TEMPORARY\s+TABLE\s+{re.escape(table_name)}\s+AS\b'
        )
        match = re.search(pattern, dml_content, re.IGNORECASE)
        if not match:
            return None

        start = match.start()
        semi_pos = dml_content.find(';', start)
        if semi_pos == -1:
            return dml_content[start:]
        return dml_content[start:semi_pos + 1]

    def _extract_delete(self, dml_content: str, table_name: str) -> Optional[str]:
        """Extract DELETE statement for a specific table from DML content."""
        mapped_name = self.converter.convert_expression(table_name)
        for name in [mapped_name, table_name]:
            pattern = rf'DELETE\s+FROM\s+{re.escape(name)}\b'
            match = re.search(pattern, dml_content, re.IGNORECASE)
            if match:
                start = match.start()
                semi_pos = dml_content.find(';', start)
                if semi_pos == -1:
                    return dml_content[start:]
                return dml_content[start:semi_pos + 1]
        return None

    def _extract_insert(self, dml_content: str, table_name: str) -> Optional[str]:
        """Extract INSERT statement for a specific table from DML content."""
        mapped_name = self.converter.convert_expression(table_name)
        for name in [mapped_name, table_name]:
            pattern = rf'INSERT\s+INTO\s+{re.escape(name)}\b'
            match = re.search(pattern, dml_content)
            if not match:
                match = re.search(pattern, dml_content, re.IGNORECASE)
            if match:
                start = match.start()
                semi_pos = dml_content.find(';', start)
                if semi_pos == -1:
                    return dml_content[start:]
                return dml_content[start:semi_pos + 1]
        return None

    def _file_header(self, source_name: str, artifact_type: str) -> str:
        """Generate file header comment."""
        return (
            f"-- ============================================\n"
            f"-- {artifact_type}: Generated from {source_name}\n"
            f"-- Generated by: STTM-SnowSQL-Toolkit\n"
            f"-- Date: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n"
            f"-- ============================================\n"
        )


def main():
    """Generate stored procedures from STTM inputs."""
    project_root = Path(__file__).resolve().parent.parent
    generator = StoredProcedureGenerator(
        plans_dir=str(project_root / 'plans'),
        output_dir=str(project_root / 'output'),
        input_dir=str(project_root / 'inputs'),
        config_dir=str(project_root / 'config'),
    )
    generator.generate()
    print("Stored procedure generation complete.")


if __name__ == '__main__':
    main()
