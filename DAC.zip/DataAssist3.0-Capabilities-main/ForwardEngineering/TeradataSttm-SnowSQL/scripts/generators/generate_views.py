"""
View Generator
==============
Generates Snowflake views for:
- SYS_CALENDAR replacement (business calendar view)
- Lookup table access views
- Final target table access views

Output: output/views/<filename>_views.sql
"""

import json
import sys
from datetime import datetime
from pathlib import Path
from typing import Dict, List

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from base.base_generator import BaseGenerator
from parsers.sttm_models import STTMDocument
from converter.expression_converter import ExpressionConverter


class ViewGenerator(BaseGenerator):
    """Generates Snowflake views from STTM documents."""

    def __init__(
        self,
        plans_dir: str = 'plans',
        output_dir: str = 'output',
        input_dir: str = 'inputs',
        config_dir: str = 'config',
    ):
        super().__init__(plans_dir=plans_dir, output_dir=output_dir)
        self.input_dir = Path(input_dir)
        self.config_dir = Path(config_dir)
        self.converter = ExpressionConverter()
        self.config = self._load_config()

    def _load_config(self) -> Dict:
        """Load converter config."""
        config_path = self.config_dir / 'converter_config.json'
        if config_path.exists():
            with open(config_path, 'r', encoding='utf-8') as f:
                return json.load(f)
        return {}

    def generate(self) -> None:
        """Generate views for all STTM input files."""
        for json_file in sorted(self.input_dir.glob('*.json')):
            self.logger.info(f"Generating views for: {json_file.name}")
            doc = STTMDocument.from_file(json_file)
            views_sql = self._generate_views(doc, json_file.stem)
            self.save_output(views_sql, f'{json_file.stem}/views/{json_file.stem}_views.sql')

    def _generate_views(self, doc: STTMDocument, source_name: str) -> str:
        """Generate all views for a document."""
        lines: List[str] = []
        lines.append(self._file_header(source_name, 'VIEWS'))

        # 1. SYS_CALENDAR replacement view
        sys_cal_view = self._generate_sys_calendar_view(doc)
        if sys_cal_view:
            lines.append(sys_cal_view)
            lines.append('')

        # 2. Lookup/reference table views
        lookup_views = self._generate_lookup_views(doc)
        if lookup_views:
            lines.append(lookup_views)
            lines.append('')

        # 3. Final target access view
        target_view = self._generate_target_access_view(doc, source_name)
        if target_view:
            lines.append(target_view)
            lines.append('')

        return '\n'.join(lines)

    def _generate_sys_calendar_view(self, doc: STTMDocument) -> str:
        """Generate a replacement view for SYS_CALENDAR.BUSINESSCALENDAR.

        Uses a CTE with ROW_NUMBER()/SEQ4() to generate a date spine,
        since Snowflake's GENERATOR() does not produce a VALUE column.
        Output aliases use the Teradata column names (e.g. MONTHBEGIN, MONTHEND)
        so downstream CTAS expressions that reference them can resolve.
        """
        # Check if SYS_CALENDAR is referenced
        has_sys_calendar = False
        for edge in doc.edges:
            if 'SYS_CALENDAR' in edge.source.table.upper():
                has_sys_calendar = True
                break

        if not has_sys_calendar:
            return ''

        sys_cal_config = self.config.get('sys_calendar', {})
        view_name = sys_cal_config.get(
            'view_name', 'CCARDM_DB.SHARED_SCHEMA.BUSINESS_CALENDAR_VW'
        )
        col_mappings = sys_cal_config.get('column_mappings', {})

        lines = []
        lines.append('-- ============================================')
        lines.append('-- SYS_CALENDAR Replacement View')
        lines.append('-- Replaces Teradata SYS_CALENDAR.BUSINESSCALENDAR')
        lines.append('-- ============================================')
        lines.append('')
        lines.append(f"CREATE OR REPLACE VIEW {view_name} AS")
        lines.append("WITH date_spine AS (")
        lines.append("    SELECT DATEADD(DAY, ROW_NUMBER() OVER (ORDER BY SEQ4()) - 1,")
        lines.append("           '2000-01-01'::DATE) AS CALENDAR_DATE")
        lines.append("    FROM TABLE(GENERATOR(ROWCOUNT => 11323))")
        lines.append(")")
        lines.append("SELECT")

        # Generate column mappings using Teradata column names as aliases
        col_lines = []
        col_lines.append("    CALENDAR_DATE")
        for td_col, sf_col in col_mappings.items():
            if td_col == 'CALENDAR_DATE':
                continue
            # Use td_col as the alias so downstream expressions resolve
            if td_col == 'YEAR_OF_CALENDAR':
                col_lines.append(f"    ,YEAR(CALENDAR_DATE) AS {td_col}")
            elif td_col == 'MONTH_OF_YEAR':
                col_lines.append(f"    ,MONTH(CALENDAR_DATE) AS {td_col}")
            elif td_col == 'MONTHBEGIN':
                col_lines.append(f"    ,DATE_TRUNC('MONTH', CALENDAR_DATE) AS {td_col}")
            elif td_col == 'MONTHEND':
                col_lines.append(f"    ,LAST_DAY(CALENDAR_DATE) AS {td_col}")
            else:
                col_lines.append(f"    ,CALENDAR_DATE AS {td_col}")

        lines.append('\n'.join(col_lines))
        lines.append("FROM date_spine")
        lines.append("WHERE CALENDAR_DATE <= '2030-12-31'::DATE;")

        return '\n'.join(lines)

    def _generate_lookup_views(self, doc: STTMDocument) -> str:
        """Generate views for lookup/reference tables used in the procedure."""
        source_tables = doc.get_source_tables()
        volatile_tables = set(doc.get_volatile_tables())

        # External tables are schema-qualified source tables not in volatile set
        external_tables = {
            t for t in source_tables
            if '.' in t and t not in volatile_tables
        }

        if not external_tables:
            return ''

        lines = []
        lines.append('-- ============================================')
        lines.append('-- Lookup/Reference Table Views')
        lines.append('-- ============================================')
        lines.append('')

        for table_name in sorted(external_tables):
            mapped_name = self.converter.convert_expression(table_name)
            # Create a simple view alias
            short_name = table_name.split('.')[-1]
            view_name = f"VW_{short_name}"

            lines.append(f"-- View for {table_name}")
            lines.append(f"CREATE OR REPLACE VIEW {view_name} AS")
            lines.append(f"SELECT *")
            lines.append(f"FROM {mapped_name};")
            lines.append('')

        return '\n'.join(lines)

    def _generate_target_access_view(
        self, doc: STTMDocument, source_name: str
    ) -> str:
        """Generate an access view for the final target table."""
        final_tables = doc.get_final_target_tables()
        if not final_tables:
            return ''

        lines = []
        lines.append('-- ============================================')
        lines.append('-- Final Target Access Views')
        lines.append('-- ============================================')
        lines.append('')

        for table_name in final_tables:
            mapped_name = self.converter.convert_expression(table_name)
            short_name = table_name.split('.')[-1]
            view_name = f"VW_{short_name}_CURRENT"

            tables = doc.get_table_inventory()
            table_def = tables.get(table_name)
            columns = list(table_def.columns.keys()) if table_def else ['*']

            lines.append(f"-- Current period view for {short_name}")
            lines.append(f"CREATE OR REPLACE VIEW {view_name} AS")
            lines.append("SELECT")
            col_list = ',\n    '.join(columns)
            lines.append(f"    {col_list}")
            lines.append(f"FROM {mapped_name}")
            lines.append(f"WHERE STRT_DT = CURRENT_DATE();")
            lines.append('')

        return '\n'.join(lines)

    def _file_header(self, source_name: str, artifact_type: str) -> str:
        """Generate file header comment."""
        return (
            f"-- ============================================\n"
            f"-- {artifact_type}: Generated from {source_name}\n"
            f"-- Generated by: STTM-SnowSQL-Toolkit\n"
            f"-- Date: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n"
            f"-- ============================================\n"
        )


def main():
    """Generate views from STTM inputs."""
    project_root = Path(__file__).resolve().parent.parent
    generator = ViewGenerator(
        plans_dir=str(project_root / 'plans'),
        output_dir=str(project_root / 'output'),
        input_dir=str(project_root / 'inputs'),
        config_dir=str(project_root / 'config'),
    )
    generator.generate()
    print("View generation complete.")


if __name__ == '__main__':
    main()
