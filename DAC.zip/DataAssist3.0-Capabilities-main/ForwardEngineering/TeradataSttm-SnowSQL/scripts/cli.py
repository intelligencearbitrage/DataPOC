"""
CLI entry point for the STTM-to-Snowflake SQL converter.

Converts Source-To-Target Mapping JSON files into Snowflake DDL, DML,
stored procedures, views, and lineage reports with topological dependency sorting.

Subcommands:
    convert     Run the full generation pipeline
    validate    Run validation on generated output
    guardrails  Run quality / guardrail checks
"""

import argparse
import os
import subprocess
import sys
from pathlib import Path

from werkzeug.utils import safe_join

PROJECT_ROOT = Path(__file__).resolve().parent
SCRIPTS_DIR = PROJECT_ROOT / "scripts"
SAFE_ROOT = str(PROJECT_ROOT)
sys.path.insert(0, str(SCRIPTS_DIR))


def _run_convert(args):
    """Execute the full generation pipeline."""
    from generators.generate_ddl import main as ddl_main
    from generators.generate_dml import main as dml_main
    from generators.generate_stored_procedure import main as sp_main
    from generators.generate_views import main as views_main
    from generators.generate_lineage_report import main as lineage_main
    from utils import setup_logging

    logger = setup_logging("CLI", log_dir=PROJECT_ROOT / "thoughts" / "logs")

    _input_raw = args.input
    if os.path.isabs(_input_raw):
        _input_raw = os.path.relpath(os.path.abspath(_input_raw), SAFE_ROOT)
    safe_input = safe_join(SAFE_ROOT, _input_raw)
    if safe_input is None:
        raise SystemExit(f"Error: input path '{args.input}' escapes the allowed directory.")
    input_path = Path(safe_input)

    _output_raw = args.output
    if os.path.isabs(_output_raw):
        _output_raw = os.path.relpath(os.path.abspath(_output_raw), SAFE_ROOT)
    safe_output = safe_join(SAFE_ROOT, _output_raw)
    if safe_output is None:
        raise SystemExit(f"Error: output path '{args.output}' escapes the allowed directory.")
    output_path = Path(safe_output)
    output_path.mkdir(parents=True, exist_ok=True)

    logger.info("=" * 60)
    logger.info("STTM -> Snowflake SQL Conversion")
    logger.info("=" * 60)
    logger.info(f"  Input:  {input_path}")
    logger.info(f"  Output: {output_path}")
    logger.info("=" * 60)

    phases = [
        ("Generating DDL", ddl_main),
        ("Generating DML", dml_main),
        ("Generating stored procedures", sp_main),
        ("Generating views", views_main),
        ("Generating lineage report", lineage_main),
    ]

    for label, fn in phases:
        logger.info(f"  {label} ...")
        try:
            fn()
        except Exception as e:
            logger.error(f"  FAILED during '{label}': {e}")
            sys.exit(1)

    logger.info("=" * 60)
    logger.info("Pipeline complete.")
    logger.info(f"  Output: {output_path}")
    logger.info("=" * 60)


def _run_validate(args):
    """Run validation on generated output."""
    from validators.validate_sql import main as validate_sql_main
    from validators.validate_input_output import main as validate_io_main

    validate_sql_main()
    validate_io_main()


def _run_guardrails(args):
    """Run guardrails quality checks."""
    guardrails_script = PROJECT_ROOT / "guardrails" / "run_guardrails.py"
    if not guardrails_script.exists():
        print(f"Error: {guardrails_script} not found", file=sys.stderr)
        sys.exit(1)
    result = subprocess.run([sys.executable, str(guardrails_script)])
    sys.exit(result.returncode)


def main():
    parser = argparse.ArgumentParser(
        prog="sttm-snowsql",
        description="STTM JSON to Snowflake SQL converter with topological dependency sorting.",
    )
    subparsers = parser.add_subparsers(dest="command")

    cp = subparsers.add_parser("convert", help="Run the full generation pipeline.")
    cp.add_argument("--input", required=True, help="Path to STTM JSON file or directory.")
    cp.add_argument("--output", default=str(PROJECT_ROOT / "output"),
                    help="Output directory (default: output/).")
    cp.add_argument("--database", default="TARGET_DB", help="Snowflake database name.")
    cp.add_argument("--warehouse", default="TARGET_WH", help="Snowflake warehouse name.")

    vp = subparsers.add_parser("validate", help="Run validation on generated output.")
    vp.add_argument("--output", default=str(PROJECT_ROOT / "output"),
                    help="Output directory to validate.")

    subparsers.add_parser("guardrails", help="Run guardrail quality checks.")

    args = parser.parse_args()

    if args.command == "convert":
        _run_convert(args)
    elif args.command == "validate":
        _run_validate(args)
    elif args.command == "guardrails":
        _run_guardrails(args)
    else:
        parser.print_help()
        sys.exit(1)


if __name__ == "__main__":
    main()
