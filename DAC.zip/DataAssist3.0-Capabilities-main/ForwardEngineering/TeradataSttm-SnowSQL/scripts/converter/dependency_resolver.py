"""
Dependency Resolver
===================
Topological sort (Kahn's algorithm) to determine execution order
of volatile/temporary tables based on their dependencies.
"""

import sys
from collections import deque
from pathlib import Path
from typing import Dict, List, Set

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))


def topological_sort(graph: Dict[str, Set[str]]) -> List[List[str]]:
    """Perform topological sort using Kahn's algorithm.

    Args:
        graph: {table_name: set_of_tables_it_depends_on}

    Returns:
        List of layers, where each layer contains tables that can
        execute in parallel. Layer 0 has no dependencies, Layer 1
        depends only on Layer 0, etc.
    """
    # Build in-degree counts and adjacency list
    in_degree: Dict[str, int] = {node: 0 for node in graph}
    dependents: Dict[str, List[str]] = {node: [] for node in graph}

    for node, deps in graph.items():
        for dep in deps:
            if dep in graph:
                in_degree[node] = in_degree.get(node, 0) + 1
                if dep not in dependents:
                    dependents[dep] = []
                dependents[dep].append(node)

    # Initialize queue with nodes that have no dependencies
    queue = deque()
    for node in graph:
        if in_degree.get(node, 0) == 0:
            queue.append(node)

    layers: List[List[str]] = []
    processed = set()

    while queue:
        # All nodes in the current queue form one layer
        current_layer = []
        next_queue = deque()

        while queue:
            node = queue.popleft()
            current_layer.append(node)
            processed.add(node)

            for dependent in dependents.get(node, []):
                in_degree[dependent] -= 1
                if in_degree[dependent] == 0:
                    next_queue.append(dependent)

        if current_layer:
            layers.append(sorted(current_layer))  # Sort for determinism

        queue = next_queue

    # Check for cycles
    if len(processed) < len(graph):
        unprocessed = set(graph.keys()) - processed
        raise ValueError(
            f"Circular dependency detected among: {unprocessed}"
        )

    return layers


def resolve_execution_order(
    graph: Dict[str, Set[str]],
    volatile_only: bool = True,
    volatile_tables: Set[str] = None
) -> List[str]:
    """Resolve execution order as a flat list.

    Args:
        graph: Full dependency graph {table -> set of dependencies}
        volatile_only: If True, only include volatile tables in output
        volatile_tables: Set of volatile table names (for filtering)

    Returns:
        Ordered list of table names for execution.
    """
    if volatile_only and volatile_tables is not None:
        # Filter graph to volatile tables only
        filtered = {}
        for name in volatile_tables:
            if name in graph:
                deps = graph[name] & volatile_tables
                filtered[name] = deps
            else:
                filtered[name] = set()
        graph = filtered

    layers = topological_sort(graph)
    return [table for layer in layers for table in layer]


def get_execution_layers(
    graph: Dict[str, Set[str]],
    volatile_tables: Set[str] = None
) -> List[List[str]]:
    """Get execution layers for display/documentation.

    Returns list of layers where tables in the same layer can
    execute in parallel.
    """
    if volatile_tables is not None:
        filtered = {}
        for name in volatile_tables:
            if name in graph:
                deps = graph[name] & volatile_tables
                filtered[name] = deps
            else:
                filtered[name] = set()
        graph = filtered

    return topological_sort(graph)


def main():
    """Demo: resolve dependencies from sample STTM input."""
    from sttm_models import STTMDocument

    input_file = Path(__file__).resolve().parent.parent / 'inputs' / 'lineage_output.json'
    if not input_file.exists():
        print(f"Input file not found: {input_file}")
        return

    doc = STTMDocument.from_file(input_file)
    graph = doc.build_dependency_graph()
    volatile_tables = set(doc.get_volatile_tables())

    print("Dependency Graph (volatile tables):")
    for name in sorted(volatile_tables):
        deps = graph.get(name, set()) & volatile_tables
        dep_str = ', '.join(sorted(deps)) if deps else '(none)'
        print(f"  {name} depends on: {dep_str}")

    print("\nExecution Layers:")
    layers = get_execution_layers(graph, volatile_tables)
    for i, layer in enumerate(layers):
        print(f"  Layer {i}: {', '.join(layer)}")

    print("\nFlat execution order:")
    order = resolve_execution_order(graph, volatile_only=True, volatile_tables=volatile_tables)
    for i, name in enumerate(order, 1):
        print(f"  {i}. {name}")


if __name__ == '__main__':
    main()
