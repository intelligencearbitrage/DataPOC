"""
Expression Converter
====================
Converts Teradata SQL expressions to Snowflake SQL using the
ConversionRule engine from the converter package.
Handles expression-level conversions, JOIN conditions, and WHERE clauses.
"""

import json
import re
import sys
from pathlib import Path
from typing import Dict, List, Optional

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from converter.rules import (
    ConversionRule,
    get_date_rules,
    get_string_rules,
    get_cast_rules,
    get_syntax_rules,
    get_datatype_rules,
    get_table_rules,
    get_system_rules,
)


class ExpressionConverter:
    """Converts Teradata expressions to Snowflake SQL."""

    def __init__(self, config_path: Optional[Path] = None):
        self.config = self._load_config(config_path)
        self.rules = self._load_expression_rules()
        self.schema_mappings = self.config.get('schema_mappings', {})
        self.sys_calendar_config = self.config.get('sys_calendar', {})
        self.expression_overrides = self.config.get('expression_overrides', {})
        self.where_alias_mappings = self.config.get('where_alias_mappings', {})
        self._conversion_log: List[Dict[str, str]] = []

    def _load_config(self, config_path: Optional[Path]) -> Dict:
        """Load converter configuration."""
        if config_path is None:
            config_path = (
                Path(__file__).resolve().parent.parent
                / 'config' / 'converter_config.json'
            )
        if config_path.exists():
            with open(config_path, 'r', encoding='utf-8') as f:
                return json.load(f)
        return {}

    def _load_expression_rules(self) -> List[ConversionRule]:
        """Load only expression-appropriate rules (exclude procedure-level)."""
        excluded = set(
            self.config.get('conversion_rules', {}).get('excluded_rules', [])
        )

        all_rules = (
            get_system_rules() +
            get_date_rules() +
            get_string_rules() +
            get_cast_rules() +
            get_syntax_rules() +
            get_datatype_rules() +
            get_table_rules()
        )

        # Filter out excluded rules
        rules = [r for r in all_rules if r.name not in excluded and r.enabled]
        return rules

    def convert_expression(self, expr: str) -> str:
        """Convert a single SQL expression from Teradata to Snowflake.

        Args:
            expr: A Teradata SQL expression (column expression, function, etc.)

        Returns:
            Converted Snowflake expression.
        """
        if not expr or not expr.strip():
            return expr

        original = expr

        # Apply expression overrides first (exact token replacements)
        expr = self._apply_expression_overrides(expr)

        # Apply SYS_CALENDAR replacement before regex rules
        expr = self._replace_sys_calendar(expr)

        # Apply conversion rules sequentially
        for rule in self.rules:
            try:
                new_expr = re.sub(rule.pattern, rule.replacement, expr, flags=rule.flags)
                if new_expr != expr:
                    self._conversion_log.append({
                        'rule': rule.name,
                        'before': expr[:200],
                        'after': new_expr[:200],
                    })
                    expr = new_expr
            except re.error:
                continue

        # Apply schema mappings
        expr = self._apply_schema_mappings(expr)

        # Convert :TABLENAME bind variables to subqueries for known volatile tables
        expr = self._convert_bind_variables(expr)

        return expr

    def convert_join_condition(self, join_str: str) -> str:
        """Convert JOIN condition(s) from Teradata to Snowflake.

        Handles semicolon-separated multi-JOIN strings.
        """
        if not join_str or not join_str.strip():
            return join_str

        joins = []
        for part in join_str.split(';'):
            part = part.strip()
            if not part:
                continue
            converted = self.convert_expression(part)
            joins.append(converted)

        return '\n'.join(joins)

    def convert_where_condition(self, where_str: str) -> str:
        """Convert WHERE clause expression from Teradata to Snowflake.

        Also resolves Teradata aliases in WHERE clauses (e.g. AF1.COL -> B.COL)
        using where_alias_mappings from config.
        """
        if not where_str or not where_str.strip():
            return where_str
        result = self.convert_expression(where_str)
        # Apply WHERE-specific alias replacements
        for old_alias, new_alias in self.where_alias_mappings.items():
            result = re.sub(
                rf'\b{re.escape(old_alias)}\.',
                f'{new_alias}.',
                result,
                flags=re.IGNORECASE
            )
        return result

    def _replace_sys_calendar(self, expr: str) -> str:
        """Replace SYS_CALENDAR.BUSINESSCALENDAR with configured view name.

        Column mappings (e.g. MONTHEND -> MONTH_END_DATE) are ONLY applied
        when the original expression contained a SYS_CALENDAR reference.
        This prevents corrupting temp table references like DATE_PARAMETERS.MONTHEND.
        """
        view_name = self.sys_calendar_config.get(
            'view_name', 'BUSINESS_CALENDAR_VW'
        )
        col_mappings = self.sys_calendar_config.get('column_mappings', {})

        # Check if the original expression references SYS_CALENDAR
        had_sys_calendar = bool(
            re.search(r'\bSYS_CALENDAR\b', expr, re.IGNORECASE)
        )

        # Replace table reference
        expr = re.sub(
            r'\bSYS_CALENDAR\.BUSINESSCALENDAR\b',
            view_name,
            expr,
            flags=re.IGNORECASE
        )
        expr = re.sub(
            r'\bSYS_CALENDAR\.CALENDAR\b',
            view_name,
            expr,
            flags=re.IGNORECASE
        )

        # Only apply column name mappings if this was a SYS_CALENDAR expression
        if had_sys_calendar:
            for td_col, sf_col in col_mappings.items():
                if td_col != sf_col:
                    # Only replace standalone column references, not qualified ones
                    expr = re.sub(
                        rf'\b{re.escape(td_col)}\b',
                        sf_col,
                        expr,
                        flags=re.IGNORECASE
                    )

        return expr

    def _apply_expression_overrides(self, expr: str) -> str:
        """Apply explicit expression overrides from config.

        Replaces exact token references like HLC_MAIN.PCO_LTD with the
        configured replacement (e.g. PREV_PCO.PREV_PCO_LTD).
        """
        for old_token, new_token in self.expression_overrides.items():
            if old_token in expr:
                expr = expr.replace(old_token, new_token)
                self._conversion_log.append({
                    'rule': 'expression_override',
                    'before': old_token,
                    'after': new_token,
                })
        return expr

    def _apply_schema_mappings(self, expr: str) -> str:
        """Apply Teradata->Snowflake schema mappings to an expression."""
        for td_schema, sf_config in self.schema_mappings.items():
            sf_db = sf_config.get('snowflake_database', '')
            sf_schema = sf_config.get('snowflake_schema', '')
            if sf_db and sf_schema:
                sf_qualified = f"{sf_db}.{sf_schema}"
                expr = re.sub(
                    rf'\b{re.escape(td_schema)}\b',
                    sf_qualified,
                    expr,
                    flags=re.IGNORECASE
                )
        return expr

    def set_volatile_tables(self, volatile_tables: set):
        """Set the known volatile table names for bind variable resolution."""
        self._volatile_tables = volatile_tables

    def _convert_bind_variables(self, expr: str) -> str:
        """Convert :TABLENAME bind variables to (SELECT col_1 FROM TABLENAME).

        In Teradata procedures, :VAR references a session variable. When the
        variable name matches a known volatile table, convert to a subquery.
        """
        volatile = getattr(self, '_volatile_tables', set())
        if not volatile:
            return expr

        for vt in volatile:
            pattern = rf':({re.escape(vt)})\b'
            if re.search(pattern, expr, re.IGNORECASE):
                expr = re.sub(
                    pattern,
                    rf'(SELECT col_1 FROM \1)',
                    expr,
                    flags=re.IGNORECASE
                )
                self._conversion_log.append({
                    'rule': 'bind_variable_to_subquery',
                    'before': f':{vt}',
                    'after': f'(SELECT col_1 FROM {vt})',
                })

        return expr

    def get_conversion_log(self) -> List[Dict[str, str]]:
        """Return log of all conversions applied."""
        return self._conversion_log

    def clear_log(self):
        """Clear the conversion log."""
        self._conversion_log.clear()


def main():
    """Demo: convert sample expressions."""
    converter = ExpressionConverter()

    test_expressions = [
        "ADD_MONTHS(CURRENT_DATE, -1)",
        "EXTRACT(YEAR FROM CCAR_DATE) * 100 + EXTRACT(MONTH FROM CCAR_DATE)",
        "CAST('2015-10-31' AS DATE) AS SEED_DATE",
        "CASE WHEN EXTRACT(MONTH FROM P_CCARDM_01_V0.MDL_SHAW_CHARGEOFFRECOVERIES.CHARGEOFFDATE) = (SELECT EXTRACT(MONTH FROM CURRENT_CCAR_DT) FROM P_CCARDM_01_V0.CCAR_DT) THEN P_CCARDM_01_V0.MDL_SHAW_CHARGEOFFRECOVERIES.ORIGINALCHARGEOFFAMOUNT ELSE 0 END",
        "CAST(STRT_DT AS DATE) = (SELECT LAST_DAY(ADD_MONTHS(CAST(CURRENT_CCAR_DT AS DATE), -1)) FROM P_CCARDM_01_V0.CCAR_DT)",
        "CALENDAR_DATE = (SELECT CAST(CURRENT_CCAR_DT AS DATE) FROM P_CCARDM_01_V0.CCAR_DT)",
        "SYS_CALENDAR.BUSINESSCALENDAR",
        "COALESCE(HLC_MAIN.PCO_LTD, 0) + COALESCE(HLC_MAIN.PCO_INCREASETHISMONTH, 0)",
    ]

    print("Expression Converter Demo")
    print("=" * 60)
    for expr in test_expressions:
        converted = converter.convert_expression(expr)
        if expr != converted:
            print(f"\n  IN:  {expr}")
            print(f"  OUT: {converted}")
        else:
            print(f"\n  UNCHANGED: {expr}")

    print(f"\n\nConversion log entries: {len(converter.get_conversion_log())}")


if __name__ == '__main__':
    main()
