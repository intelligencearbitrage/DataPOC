"""
Statement Assembler
===================
Reconstructs full SQL statements from column-level STTM edges.

Core algorithm:
1. Group edges by target table
2. Deduplicate: same (target_table, target_column, sql_expression) -> keep one
3. Collect & deduplicate JOIN clauses across all edges for a table
4. Merge WHERE conditions (AND them together, with context filtering)
5. Determine primary FROM table (most frequent source table)
6. Detect UNION ALL sources when multiple source tables share identical expressions
7. Detect and append FROM aliases (e.g. DS for DRIVING_SET)
8. Resolve bare JOIN aliases to actual table references
9. Convert all expressions through ExpressionConverter
10. Return ReconstructedStatement objects
"""

import json
import re
import sys
from collections import Counter
from pathlib import Path
from typing import Dict, List, Optional, Set, Tuple

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from converter.expression_converter import ExpressionConverter
from parsers.sttm_models import (
    DMLOperation,
    Edge,
    ReconstructedStatement,
    STTMDocument,
    TableDefinition,
)

# Calendar-specific columns that ONLY exist in the SYS_CALENDAR view.
# These should be filtered from WHERE clauses when the calendar view isn't joined.
# NOTE: MONTHBEGIN/MONTHEND are excluded here because they also appear as
# legitimate columns on temp tables (RECFI, HELOC, DATE_PARAMETERS).
CALENDAR_ONLY_COLUMNS = {
    'CALENDAR_DATE',
}


class StatementAssembler:
    """Assembles full SQL statements from STTM column-level edges."""

    def __init__(self, converter: Optional[ExpressionConverter] = None):
        self.converter = converter or ExpressionConverter()
        self.config = self._load_config()
        self.alias_mappings = self.config.get('alias_mappings', {})

    def _load_config(self) -> Dict:
        """Load converter configuration."""
        config_path = (
            Path(__file__).resolve().parent.parent
            / 'config' / 'converter_config.json'
        )
        if config_path.exists():
            with open(config_path, 'r', encoding='utf-8') as f:
                return json.load(f)
        return {}

    def assemble_all(self, doc: STTMDocument) -> Dict[str, ReconstructedStatement]:
        """Assemble SQL statements for all tables in the STTM document.

        Returns:
            Dict mapping table_name -> ReconstructedStatement
        """
        tables = doc.get_table_inventory()
        statements: Dict[str, ReconstructedStatement] = {}

        for table_name, table_def in tables.items():
            stmt = self._assemble_table(table_name, table_def, tables)
            statements[table_name] = stmt

        return statements

    def _assemble_table(
        self, table_name: str, table_def: TableDefinition,
        all_tables: Optional[Dict[str, TableDefinition]] = None,
    ) -> ReconstructedStatement:
        """Assemble a single SQL statement for a target table."""

        # Save original edges before dedup for UNION detection
        all_edges = table_def.source_edges

        # Step 1: Deduplicate edges by (target_column, sql_expression)
        deduped = self._deduplicate_edges(all_edges)

        # Step 2: Build SELECT expressions and track edge context per column
        select_expressions: List[Tuple[str, str]] = []
        column_names: List[str] = []
        seen_columns: Set[str] = set()
        edge_for_column: Dict[str, Edge] = {}

        for edge in deduped:
            col_name = edge.target.column
            # Skip wildcard '*' columns (from DELETE edges merged into INSERT)
            if col_name == '*':
                continue
            if col_name in seen_columns:
                continue
            seen_columns.add(col_name)

            raw_expr = edge.transformation.sql_expression
            converted_expr = self.converter.convert_expression(raw_expr)

            # Check if expression already ends with an alias
            # Pattern: "... AS ALIAS_NAME" at end of expression (not inside CASE/subquery)
            has_alias = re.search(
                r'\bAS\s+(\w+)\s*$', converted_expr, re.IGNORECASE
            )

            if has_alias:
                existing_alias = has_alias.group(1)
                if existing_alias.upper() != col_name.upper():
                    # Replace the existing alias with the correct column name
                    converted_expr = converted_expr[:has_alias.start()] + f"AS {col_name}"
                # Expression already has correct alias, use as-is
                select_expressions.append((col_name, converted_expr))
            elif col_name.upper() != raw_expr.upper().strip():
                # Need alias
                select_expressions.append((col_name, f"{converted_expr} AS {col_name}"))
            else:
                select_expressions.append((col_name, converted_expr))

            edge_for_column[col_name] = edge
            column_names.append(col_name)

        # Step 3: Determine primary FROM table
        from_table = self._determine_from_table(deduped, table_name)
        from_table_converted = self.converter.convert_expression(from_table)

        # Step 4: Collect and deduplicate JOIN clauses
        join_clauses = self._collect_join_clauses(deduped)
        converted_joins = [
            self.converter.convert_join_condition(j) for j in join_clauses
        ]

        # Step 4b: Fix self-referencing ON conditions (both sides same table)
        converted_joins = self._fix_self_join_on_conditions(converted_joins)

        # Step 5: Resolve bare JOIN aliases (CNSL, PREV_PCO, CHF, etc.)
        converted_joins = self._resolve_join_aliases(converted_joins)

        # Step 6: Build alias maps and rewrite expressions with JOIN aliases
        table_to_aliases, consumed_to_alias = self._build_alias_maps(
            converted_joins
        )
        if table_to_aliases or consumed_to_alias:
            select_expressions = self._rewrite_expressions_with_aliases(
                select_expressions, table_to_aliases, consumed_to_alias,
                edge_for_column,
            )

        # Step 7: Detect FROM alias (e.g. DS for DRIVING_SET)
        from_alias = self._detect_from_alias(
            from_table_converted, select_expressions, converted_joins,
            all_tables
        )
        if from_alias:
            from_table_converted = f"{from_table_converted} {from_alias}"

        # Step 8: Merge WHERE conditions with context filtering
        available_tables = self._get_available_tables(
            from_table, join_clauses
        )
        # For final INSERT: also filter by column availability
        available_columns: Optional[Set[str]] = None
        if not table_def.is_volatile and all_tables:
            available_columns = self._collect_available_columns(
                from_table, converted_joins, all_tables
            )
        where_clause = self._merge_where_conditions(
            deduped, available_tables, available_columns
        )
        converted_where = self.converter.convert_where_condition(where_clause)

        # Step 8b: Fix JOINs without ON clause — move matching WHERE conditions to ON
        converted_joins, converted_where = self._fix_joins_without_on(
            converted_joins, converted_where
        )

        # Step 9: Detect UNION ALL sources (use original edges, not deduped,
        # because dedup removes duplicate expressions from different source tables)
        union_tables = self._detect_union_sources(all_edges, table_name, from_table)

        return ReconstructedStatement(
            target_table=table_name,
            dml_type=table_def.dml_operation,
            select_expressions=select_expressions,
            column_names=column_names,
            from_table=from_table_converted,
            join_clauses=converted_joins,
            where_clause=converted_where,
            is_volatile=table_def.is_volatile,
            union_tables=union_tables,
        )

    def _deduplicate_edges(self, edges: List[Edge]) -> List[Edge]:
        """Deduplicate edges by (target_column, sql_expression).

        Multiple STTM edges may target the same column with the same expression
        (e.g., PCO_LTD has 4 source edges with identical expression). Keep one.
        """
        seen = set()
        result = []
        for edge in edges:
            key = (edge.target.column, edge.transformation.sql_expression)
            if key not in seen:
                seen.add(key)
                result.append(edge)
        return result

    def _determine_from_table(self, edges: List[Edge], target_table: str) -> str:
        """Determine the primary FROM table (most frequent source table)."""
        source_counts: Counter = Counter()
        for edge in edges:
            src = edge.source.table
            if src != target_table:
                source_counts[src] += 1

        if not source_counts:
            return ""

        # Return the most common source table
        return source_counts.most_common(1)[0][0]

    def _detect_union_sources(
        self, edges: List[Edge], target_table: str, from_table: str
    ) -> List[str]:
        """Detect when multiple source tables contribute identical column/expression sets.

        Supports two patterns:
        1. Identical expressions (e.g. DRIVING_SET from STG_ILN and STG_LOC)
        2. Same target columns with table-prefixed expressions that differ only
           by source table name (e.g. _CUR.AGMT_ID vs _HIST.AGMT_ID)

        Returns list of source tables that should be UNIONed, or empty list.
        Skips tables that are already referenced in JOIN conditions.
        """
        # Collect tables referenced in JOIN conditions
        join_referenced: Set[str] = set()
        for edge in edges:
            if edge.join_conditions:
                for part in edge.join_conditions.split(';'):
                    join_match = re.search(r'\bJOIN\s+\(?(\S+)', part, re.IGNORECASE)
                    if join_match:
                        join_referenced.add(join_match.group(1).upper())

        # Group edges by source table
        source_to_cols: Dict[str, Set[Tuple[str, str]]] = {}
        source_to_normalized: Dict[str, Set[Tuple[str, str]]] = {}
        for edge in edges:
            src = edge.source.table
            if src == target_table:
                continue
            if src.upper() in join_referenced:
                continue
            col_key = (edge.target.column, edge.transformation.sql_expression)
            if src not in source_to_cols:
                source_to_cols[src] = set()
                source_to_normalized[src] = set()
            source_to_cols[src].add(col_key)
            # Normalize: strip source table prefix from expression for comparison
            normalized_expr = re.sub(
                re.escape(src) + r'\.', '', edge.transformation.sql_expression,
                flags=re.IGNORECASE
            )
            source_to_normalized[src].add((edge.target.column, normalized_expr))

        if len(source_to_cols) < 2:
            return []

        # Try exact match first
        sig_to_tables: Dict[frozenset, List[str]] = {}
        for src_table, col_set in source_to_cols.items():
            sig = frozenset(col_set)
            if sig not in sig_to_tables:
                sig_to_tables[sig] = []
            sig_to_tables[sig].append(src_table)

        for sig, tables in sig_to_tables.items():
            if len(tables) >= 2:
                return sorted(tables)

        # Try normalized match (expressions differ only by table prefix)
        norm_sig_to_tables: Dict[frozenset, List[str]] = {}
        for src_table, norm_set in source_to_normalized.items():
            sig = frozenset(norm_set)
            if sig not in norm_sig_to_tables:
                norm_sig_to_tables[sig] = []
            norm_sig_to_tables[sig].append(src_table)

        for sig, tables in norm_sig_to_tables.items():
            if len(tables) >= 2:
                return sorted(tables)

        return []

    def _build_alias_maps(
        self, resolved_joins: List[str]
    ) -> Tuple[Dict[str, List[str]], Dict[str, str]]:
        """Build maps of table references to JOIN aliases.

        Returns:
            table_to_aliases: {qualified_table_upper: [alias1, alias2]}
            consumed_to_alias: {consumed_table_upper: alias}
        """
        table_to_aliases: Dict[str, List[str]] = {}
        consumed_to_alias: Dict[str, str] = {}

        for jc in resolved_joins:
            # Subquery JOINs: JOIN (<subquery>) <alias> ON
            subq_match = re.search(
                r'\bJOIN\s+\((.+?)\)\s+(\w+)\s+ON\b',
                jc, re.IGNORECASE | re.DOTALL,
            )
            if subq_match:
                subquery = subq_match.group(1)
                alias = subq_match.group(2).upper()
                for ft in re.findall(r'\bFROM\s+(\w+)', subquery, re.IGNORECASE):
                    consumed_to_alias[ft.upper()] = alias
                continue

            # Regular JOINs: JOIN <table> <alias> ON
            reg_match = re.search(
                r'\bJOIN\s+(\S+)\s+(\w+)\s+ON\b', jc, re.IGNORECASE,
            )
            if reg_match:
                table_ref = reg_match.group(1).upper()
                alias = reg_match.group(2).upper()
                if table_ref not in table_to_aliases:
                    table_to_aliases[table_ref] = []
                table_to_aliases[table_ref].append(alias)

        return table_to_aliases, consumed_to_alias

    def _get_edge_aliases(
        self, edge: Edge, available_aliases: List[str]
    ) -> List[str]:
        """Get which aliases from available_aliases are referenced in the edge's JOINs.

        Uses word-boundary matching to avoid CHF matching inside CHF_THIMONTH.
        """
        if not edge.join_conditions:
            return available_aliases
        jc_upper = edge.join_conditions.upper()
        result = [
            a for a in available_aliases
            if re.search(rf'\b{re.escape(a)}\b', jc_upper)
        ]
        return result if result else available_aliases

    def _rewrite_expressions_with_aliases(
        self,
        select_expressions: List[Tuple[str, str]],
        table_to_aliases: Dict[str, List[str]],
        consumed_to_alias: Dict[str, str],
        edge_for_column: Dict[str, Edge],
    ) -> List[Tuple[str, str]]:
        """Rewrite SELECT expressions to use JOIN aliases instead of qualified table names.

        Handles:
        1. Qualified refs: DB.SCHEMA.TABLE.COL → ALIAS.COL
        2. Consumed table refs: TEMPTABLE.COL → UNION_ALIAS.COL
        3. Unqualified columns from external tables: COL → ALIAS.COL
        """
        rewritten = []
        for col_name, expr in select_expressions:
            new_expr = expr

            # 1. Replace consumed table references (e.g. RECFI.X → CNSL.X)
            for consumed_table, union_alias in consumed_to_alias.items():
                pattern = rf'\b{re.escape(consumed_table)}\.(\w+)'
                new_expr = re.sub(
                    pattern, rf'{union_alias}.\1', new_expr, flags=re.IGNORECASE
                )

            # 2. Replace fully-qualified table references with aliases
            for qualified_table, aliases in table_to_aliases.items():
                pattern = rf'\b{re.escape(qualified_table)}\.(\w+)'
                matches = list(re.finditer(pattern, new_expr, flags=re.IGNORECASE))
                if not matches:
                    continue

                if len(aliases) == 1:
                    # Simple: one alias for this table
                    new_expr = re.sub(
                        pattern, rf'{aliases[0]}.\1', new_expr, flags=re.IGNORECASE
                    )
                else:
                    # Multi-alias: use edge context to determine which alias
                    edge = edge_for_column.get(col_name)
                    edge_aliases = (
                        self._get_edge_aliases(edge, aliases)
                        if edge else aliases
                    )
                    # Replace occurrences from last to first to preserve positions
                    for i, match in enumerate(reversed(matches)):
                        idx = len(matches) - 1 - i
                        alias = edge_aliases[min(idx, len(edge_aliases) - 1)]
                        replacement = f'{alias}.{match.group(1)}'
                        new_expr = (
                            new_expr[:match.start()] + replacement + new_expr[match.end():]
                        )

            # 3. Apply config-driven unqualified column overrides
            unqualified_overrides = self.config.get(
                'unqualified_column_overrides', {}
            )
            for bare_col, qualified_col in unqualified_overrides.items():
                # Only replace standalone references (not already qualified)
                pattern = rf'(?<!\.)(?<!\w)\b{re.escape(bare_col)}\b(?!\.)'
                new_expr = re.sub(
                    pattern, qualified_col, new_expr, flags=re.IGNORECASE
                )

            rewritten.append((col_name, new_expr))
        return rewritten

    def _collect_available_columns(
        self, from_table: str, resolved_joins: List[str],
        all_tables: Dict[str, TableDefinition],
    ) -> Set[str]:
        """Collect column names available in the current query context.

        Builds from known temp tables in the table inventory. External tables
        (not in inventory) are skipped — their columns are unknown.
        """
        available: Set[str] = set()

        # Helper: look up table in inventory (case-insensitive)
        def add_columns_for(table_name: str):
            for tname, tdef in all_tables.items():
                if tname.upper() == table_name.upper():
                    available.update(c.upper() for c in tdef.columns)
                    return
                mapped = self.converter.convert_expression(tname)
                if mapped.upper() == table_name.upper():
                    available.update(c.upper() for c in tdef.columns)
                    return

        # FROM table columns
        add_columns_for(from_table)

        # JOIN table columns
        for jc in resolved_joins:
            # Subquery JOINs: extract consumed tables
            for ft in re.findall(r'\bFROM\s+(\w+)', jc, re.IGNORECASE):
                add_columns_for(ft)
            # Regular JOINs
            reg_match = re.search(
                r'\bJOIN\s+(\S+)\s+\w+\s+ON\b', jc, re.IGNORECASE,
            )
            if reg_match:
                table_ref = reg_match.group(1)
                if not table_ref.startswith('('):
                    add_columns_for(table_ref)

        return available

    def _extract_unqualified_columns(self, condition: str) -> Set[str]:
        """Extract unqualified column references from a WHERE condition.

        Removes SQL comments, subselects, string literals, qualified refs,
        and SQL keywords, returning only bare column-like identifiers.
        """
        clean = condition
        # Remove SQL block comments /* ... */
        clean = re.sub(r'/\*.*?\*/', '', clean, flags=re.DOTALL)
        # Remove SQL line comments -- ...
        clean = re.sub(r'--[^\n]*', '', clean)
        # Remove nested subselects (greedy innermost first)
        for _ in range(5):
            new_clean = re.sub(
                r'\(\s*SELECT\b[^()]*\)', '', clean, flags=re.IGNORECASE
            )
            if new_clean == clean:
                break
            clean = new_clean
        # Remove string literals
        clean = re.sub(r"'[^']*'", '', clean)
        # Remove qualified references (TABLE.COLUMN or DB.SCHEMA.TABLE)
        clean = re.sub(r'\b\w+\.\w+(?:\.\w+)*\b', '', clean)
        # SQL keywords and functions to ignore
        sql_keywords = {
            'AND', 'OR', 'NOT', 'BETWEEN', 'IN', 'IS', 'NULL', 'LIKE',
            'EXISTS', 'CAST', 'AS', 'DATE', 'TIMESTAMP', 'WHERE', 'FROM',
            'SELECT', 'CURRENT_DATE', 'INTERVAL', 'SECOND', 'LAST_DAY',
            'DATEADD', 'MONTH', 'YEAR', 'DAY', 'END', 'THEN', 'WHEN',
            'ELSE', 'CASE',
        }
        words = re.findall(r'\b([A-Z_]\w*)\b', clean, re.IGNORECASE)
        return {w.upper() for w in words if w.upper() not in sql_keywords}

    def _detect_from_alias(
        self,
        from_table: str,
        select_expressions: List[Tuple[str, str]],
        join_clauses: List[str],
        all_tables: Optional[Dict[str, TableDefinition]] = None,
    ) -> str:
        """Detect if expressions reference an alias for the FROM table.

        Scans SELECT expressions and JOIN conditions for ALIAS.COLUMN patterns
        where ALIAS doesn't match the from_table or any JOIN table. If found,
        returns the alias to append to the FROM clause.
        """
        if not from_table:
            return ""

        # Collect all text to scan
        all_text = " ".join(expr for _, expr in select_expressions)
        all_text += " " + " ".join(join_clauses)

        # Find ALIAS.COLUMN patterns (2-part only, not schema prefixes).
        # A true alias appears as ALIAS.COLUMN (2 parts).
        # A schema prefix appears as SCHEMA.TABLE.COLUMN (3+ parts).
        # Exclude identifiers that are part of 3+ part qualified names.
        # Find all multi-part qualified names (DB.SCHEMA.TABLE.COL etc).
        # Exclude ALL non-terminal parts from alias candidates. For a 4-part
        # ref like DB.SCHEMA.TABLE.COLUMN, DB, SCHEMA, and TABLE are all
        # excluded (only COLUMN is the column name, not an alias).
        multipart = re.compile(
            r'\b([A-Z_]\w+(?:\.[A-Z_]\w+){2,})\b', re.IGNORECASE
        )
        schema_like_prefixes = set()
        for m in multipart.finditer(all_text):
            parts = m.group(1).split(".")
            # All parts except the last (column) are non-alias
            for part in parts[:-1]:
                schema_like_prefixes.add(part.upper())

        alias_pattern = re.compile(r'\b([A-Z_][A-Z0-9_]*)\.\w+', re.IGNORECASE)
        aliases_used = set()
        for match in alias_pattern.finditer(all_text):
            alias = match.group(1).upper()
            # Skip if this is a schema prefix from a 3-part qualified name
            if alias in schema_like_prefixes:
                continue
            aliases_used.add(alias)

        # Known table names (unqualified)
        from_name = from_table.split('.')[-1].upper()
        from_full = from_table.upper()

        # Check for aliases in JOIN clauses (extract both table names AND aliases)
        join_tables = set()
        # Pattern 1: JOIN <table> [AS] <alias> ON
        join_with_alias = re.compile(
            r'\bJOIN\s+(\S+)\s+(?:AS\s+)?(\w+)\s+ON\b', re.IGNORECASE
        )
        # Pattern 2: JOIN (...) <alias> ON  (subquery joins)
        join_subquery_alias = re.compile(
            r'\)\s+(\w+)\s+ON\b', re.IGNORECASE
        )
        for jc in join_clauses:
            # Extract table name and alias from "JOIN <table> <alias> ON"
            for m in join_with_alias.finditer(jc):
                full_name = m.group(1).strip('(').upper()
                alias_name = m.group(2).upper()
                join_tables.add(full_name)
                join_tables.add(alias_name)
                # Also add unqualified parts (e.g. DB.SCHEMA.TABLE -> TABLE)
                for part in full_name.split('.'):
                    join_tables.add(part)
            # Extract alias from ") <alias> ON" (subquery joins)
            for m in join_subquery_alias.finditer(jc):
                join_tables.add(m.group(1).upper())
        # Also add configured alias_mappings keys
        for alias_key in self.alias_mappings:
            join_tables.add(alias_key.upper())
        # Also extract table names from inside subquery JOINs (e.g. FROM RECFI UNION ALL ...)
        from_in_join = re.compile(r'\bFROM\s+(\w+)', re.IGNORECASE)
        for jc in join_clauses:
            for m in from_in_join.finditer(jc):
                join_tables.add(m.group(1).upper())

        # Known schema prefixes to ignore
        schema_prefixes = set()
        for mapping in self.converter.schema_mappings:
            schema_prefixes.add(mapping.upper())
        # Add Snowflake mapped names
        for sf_config in self.converter.schema_mappings.values():
            db = sf_config.get('snowflake_database', '').upper()
            schema = sf_config.get('snowflake_schema', '').upper()
            if db:
                schema_prefixes.add(db)
            if schema:
                schema_prefixes.add(schema)

        # Build set of known table names from inventory (unqualified)
        inventory_names = set()
        if all_tables:
            for tname in all_tables:
                inventory_names.add(tname.upper())
                if '.' in tname:
                    inventory_names.add(tname.split('.')[-1].upper())
                # Also add mapped names
                mapped = self.converter.convert_expression(tname)
                inventory_names.add(mapped.upper())
                if '.' in mapped:
                    inventory_names.add(mapped.split('.')[-1].upper())

        # Filter to aliases that don't match from_table, join tables, or schema names
        for alias in aliases_used:
            if alias == from_name or alias == from_full:
                continue
            if alias in join_tables:
                continue
            if alias in schema_prefixes:
                continue
            # Skip known table prefixes (qualified names like DB.SCHEMA)
            if '.' in from_table and alias in from_table.upper().split('.'):
                continue
            # Skip if alias matches a known table name in the inventory
            if alias in inventory_names:
                continue
            # Check if this alias is used with columns that match from_table columns
            # This is a heuristic: if we see DS.FULLACCOUNTNUMBER and the from_table
            # is DRIVING_SET, DS is likely the alias
            alias_col_pattern = re.compile(
                rf'\b{re.escape(alias)}\.(\w+)', re.IGNORECASE
            )
            alias_cols = set()
            for m in alias_col_pattern.finditer(all_text):
                alias_cols.add(m.group(1).upper())

            if alias_cols:
                # This alias references columns — it's likely a table alias
                return alias

        return ""

    def _resolve_join_aliases(self, join_clauses: List[str]) -> List[str]:
        """Resolve bare JOIN aliases to actual table references.

        When a JOIN references a bare alias like CNSL, PREV_PCO, CHF, etc.,
        replace with the actual table reference from alias_mappings config.
        For UNION aliases (e.g. "RECFI UNION ALL HELOC"), generate inline
        subquery: (SELECT * FROM T1 UNION ALL SELECT * FROM T2) ALIAS.
        """
        if not self.alias_mappings:
            return join_clauses

        resolved = []
        for clause in join_clauses:
            # Pattern: LEFT JOIN <target> ON ...
            match = re.match(
                r'((?:LEFT|RIGHT|INNER|FULL|CROSS)?\s*JOIN\s+)(\S+)(\s+ON\s+.*)',
                clause,
                re.IGNORECASE | re.DOTALL,
            )
            if not match:
                resolved.append(clause)
                continue

            join_prefix = match.group(1)
            join_target = match.group(2)
            join_on = match.group(3)
            alias = join_target.strip()

            if alias.upper() in {k.upper() for k in self.alias_mappings}:
                # Find the mapping (case-insensitive)
                mapping_value = None
                for k, v in self.alias_mappings.items():
                    if k.upper() == alias.upper():
                        mapping_value = v
                        break

                if mapping_value and 'UNION ALL' in mapping_value.upper():
                    # Generate inline UNION subquery
                    parts = re.split(r'\s+UNION\s+ALL\s+', mapping_value, flags=re.IGNORECASE)
                    union_parts = []
                    for part in parts:
                        mapped_part = self.converter.convert_expression(part.strip())
                        union_parts.append(f"SELECT * FROM {mapped_part}")
                    union_sql = " UNION ALL ".join(union_parts)
                    resolved.append(
                        f"{join_prefix}({union_sql}) {alias}{join_on}"
                    )
                else:
                    # Simple alias -> table mapping
                    mapped_table = self.converter.convert_expression(mapping_value)
                    resolved.append(
                        f"{join_prefix}{mapped_table} {alias}{join_on}"
                    )
            else:
                resolved.append(clause)

        return resolved

    def _fix_joins_without_on(
        self, joins: List[str], where: str
    ) -> Tuple[List[str], str]:
        """Fix JOINs that have no ON clause by moving WHERE conditions into ON.

        When a JOIN has no ON clause (e.g. 'JOIN table AS alias'), and the WHERE
        clause contains conditions referencing the alias, those conditions are
        moved from WHERE to ON to produce valid SQL.
        """
        if not where:
            return joins, where

        fixed_joins = []
        remaining_where = where

        for jc in joins:
            # Check if this JOIN already has an ON clause
            if re.search(r'\bON\b', jc, re.IGNORECASE):
                fixed_joins.append(jc)
                continue

            # Extract the alias from the JOIN clause
            alias_match = re.search(
                r'\bJOIN\s+\S+\s+(?:AS\s+)?(\w+)\s*$', jc, re.IGNORECASE
            )
            if not alias_match:
                fixed_joins.append(jc)
                continue

            alias = alias_match.group(1)

            # Find WHERE conditions that reference this alias
            # Split WHERE by AND (respecting parentheses)
            if remaining_where:
                parts = re.split(r'\s+AND\s+', remaining_where, flags=re.IGNORECASE)
                on_parts = []
                keep_parts = []
                for part in parts:
                    if re.search(rf'\b{re.escape(alias)}\b\.', part, re.IGNORECASE):
                        on_parts.append(part.strip())
                    else:
                        keep_parts.append(part.strip())

                if on_parts:
                    on_clause = ' AND '.join(on_parts)
                    fixed_joins.append(f"{jc} ON {on_clause}")
                    remaining_where = ' AND '.join(keep_parts) if keep_parts else ''
                else:
                    fixed_joins.append(jc)
            else:
                fixed_joins.append(jc)

        return fixed_joins, remaining_where

    @staticmethod
    def _fix_self_join_on_conditions(joins: List[str]) -> List[str]:
        """Fix self-referencing ON conditions where both sides use the same table.

        When the STTM input expands aliases on both sides of a JOIN ON condition
        to the same qualified table name (e.g. V_GLDATA.ACCTNO = V_GLDATA.ACCTNO),
        replace the right side with the JOIN alias to produce valid SQL
        (e.g. V_GLDATA.ACCTNO = MA.ACCTNO).
        """
        fixed = []
        for jc in joins:
            # Extract JOIN alias — regular JOIN or subquery JOIN
            alias_match = re.search(
                r'\bJOIN\s+\S+\s+(?:AS\s+)?(\w+)\s+ON\b', jc, re.IGNORECASE
            )
            if not alias_match:
                alias_match = re.search(r'\)\s+(\w+)\s+ON\b', jc, re.IGNORECASE)
            if not alias_match:
                fixed.append(jc)
                continue

            join_alias = alias_match.group(1)

            # Find the ON clause
            on_match = re.search(r'\bON\s+(.+)$', jc, re.IGNORECASE | re.DOTALL)
            if not on_match:
                fixed.append(jc)
                continue

            on_clause = on_match.group(1)
            prefix = jc[:on_match.start(1)]

            # Split by AND and fix each equality condition
            parts = re.split(r'\s+AND\s+', on_clause, flags=re.IGNORECASE)
            fixed_parts = []
            changed = False
            for part in parts:
                # Match: qualified_ref.COL = qualified_ref.COL
                eq_match = re.match(
                    r'\s*([\w.]+)\.(\w+)\s*=\s*([\w.]+)\.(\w+)\s*$',
                    part.strip()
                )
                if eq_match:
                    left_ref = eq_match.group(1)
                    left_col = eq_match.group(2)
                    right_ref = eq_match.group(3)
                    right_col = eq_match.group(4)
                    if left_ref.upper() == right_ref.upper():
                        # Self-reference — replace right side with JOIN alias
                        fixed_parts.append(
                            f"{left_ref}.{left_col} = {join_alias}.{right_col}"
                        )
                        changed = True
                        continue
                fixed_parts.append(part.strip())

            if changed:
                fixed.append(prefix + ' AND '.join(fixed_parts))
            else:
                fixed.append(jc)

        return fixed

    def _collect_join_clauses(self, edges: List[Edge]) -> List[str]:
        """Collect and deduplicate JOIN clauses from all edges.

        Also resolves duplicate aliases: if two JOINs use the same alias
        (e.g. 'B') but reference different tables, the second gets 'B2', etc.
        """
        seen: Set[str] = set()
        result: List[str] = []
        alias_to_table: Dict[str, str] = {}

        for edge in edges:
            if not edge.join_conditions:
                continue
            for part in edge.join_conditions.split(';'):
                part = part.strip()
                if not part or part in seen:
                    continue

                # Extract alias and table from JOIN <table> AS <alias> ON or JOIN <table> <alias> ON
                alias_match = re.search(
                    r'\bJOIN\s+(\S+)\s+(?:AS\s+)?(\w+)\s+ON\b', part, re.IGNORECASE
                )
                if alias_match:
                    join_table = alias_match.group(1).upper()
                    join_alias = alias_match.group(2).upper()

                    if join_alias in alias_to_table:
                        if alias_to_table[join_alias] != join_table:
                            # Duplicate alias referencing different table — rename
                            counter = 2
                            new_alias = f"{join_alias}{counter}"
                            while new_alias in alias_to_table:
                                counter += 1
                                new_alias = f"{join_alias}{counter}"
                            alias_to_table[new_alias] = join_table
                            # Replace old alias with new in the JOIN clause
                            part = re.sub(
                                rf'(\bJOIN\s+\S+\s+(?:AS\s+)?){re.escape(alias_match.group(2))}(\s+ON\b)',
                                rf'\g<1>{new_alias}\2',
                                part,
                                flags=re.IGNORECASE
                            )
                        else:
                            # Same alias, same table — skip duplicate
                            seen.add(part)
                            continue
                    else:
                        alias_to_table[join_alias] = join_table

                seen.add(part)
                result.append(part)

        return result

    def _get_available_tables(
        self, from_table: str, join_clauses: List[str]
    ) -> Set[str]:
        """Get set of table names available in the current FROM/JOIN context."""
        tables = set()
        if from_table:
            tables.add(from_table.upper())
            tables.add(from_table.split('.')[-1].upper())

        for jc in join_clauses:
            # Extract table name from JOIN clause
            match = re.search(r'\bJOIN\s+(\S+)', jc, re.IGNORECASE)
            if match:
                tname = match.group(1)
                tables.add(tname.upper())
                tables.add(tname.split('.')[-1].upper())

        return tables

    def _merge_where_conditions(
        self, edges: List[Edge],
        available_tables: Optional[Set[str]] = None,
        available_columns: Optional[Set[str]] = None,
    ) -> str:
        """Merge WHERE conditions from all edges, ANDing them together.

        Filters out:
        1. Conditions referencing calendar-only columns when calendar isn't joined
        2. Conditions referencing columns not available in the query context
           (only when available_columns is provided, i.e. for final INSERT)
        """
        seen: Set[str] = set()
        conditions: List[str] = []

        # Check if calendar view is in the available tables
        has_calendar = False
        if available_tables:
            calendar_names = {
                'SYS_CALENDAR', 'BUSINESSCALENDAR',
                'SYS_CALENDAR.BUSINESSCALENDAR', 'SYS_CALENDAR.CALENDAR',
                'BUSINESS_CALENDAR_VW',
            }
            for tname in available_tables:
                if tname in calendar_names:
                    has_calendar = True
                    break

        for edge in edges:
            if not edge.where_conditions:
                continue
            wc = edge.where_conditions.strip()
            if not wc or wc in seen:
                continue

            # Filter out calendar-specific conditions when calendar isn't joined
            if not has_calendar and available_tables:
                first_token = re.match(r'\b(\w+)\b', wc)
                if first_token and first_token.group(1).upper() in CALENDAR_ONLY_COLUMNS:
                    continue

            # Filter conditions referencing columns not in the query context.
            # Skip this check when available_columns is empty (external source
            # tables not in inventory — we can't validate their columns).
            if available_columns is not None and available_columns:
                unqualified_cols = self._extract_unqualified_columns(wc)
                if unqualified_cols and not unqualified_cols.issubset(available_columns):
                    continue

            seen.add(wc)
            conditions.append(wc)

        if not conditions:
            return ""
        if len(conditions) == 1:
            return conditions[0]
        return ' AND '.join(f"({c})" for c in conditions)


def main():
    """Demo: assemble statements from sample STTM input."""
    from sttm_models import STTMDocument

    input_file = Path(__file__).resolve().parent.parent / 'inputs' / 'lineage_output.json'
    if not input_file.exists():
        print(f"Input file not found: {input_file}")
        return

    doc = STTMDocument.from_file(input_file)
    assembler = StatementAssembler()
    statements = assembler.assemble_all(doc)

    for name, stmt in statements.items():
        print(f"\n{'='*60}")
        print(f"Table: {name}")
        print(f"  DML Type: {stmt.dml_type.value}")
        print(f"  Is Volatile: {stmt.is_volatile}")
        print(f"  Columns: {len(stmt.column_names)}")
        print(f"  FROM: {stmt.from_table}")
        print(f"  JOINs: {len(stmt.join_clauses)}")
        print(f"  WHERE: {stmt.where_clause[:100] if stmt.where_clause else '(none)'}")


if __name__ == '__main__':
    main()
