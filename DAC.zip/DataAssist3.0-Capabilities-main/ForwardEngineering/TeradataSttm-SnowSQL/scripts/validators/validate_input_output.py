"""
Input-to-Output Validation Script
==================================
Cross-references every edge in the input STTM JSON against the generated
output files to verify completeness and correctness.
"""

import json
import sys
from collections import Counter, defaultdict
from pathlib import Path


def main():
    project_root = Path(__file__).resolve().parent.parent
    input_file = project_root / 'inputs' / 'P_CCARDM_01.SHAW_TRAN_ILN_STG_VIEW_SP_STTM.json'
    ddl_file = project_root / 'output' / 'ddl' / 'P_CCARDM_01.SHAW_TRAN_ILN_STG_VIEW_SP_STTM_ddl.sql'
    dml_file = project_root / 'output' / 'dml' / 'P_CCARDM_01.SHAW_TRAN_ILN_STG_VIEW_SP_STTM_dml.sql'
    proc_file = project_root / 'output' / 'stored_procedures' / 'P_CCARDM_01.SHAW_TRAN_ILN_STG_VIEW_SP_STTM_proc.sql'
    views_file = project_root / 'output' / 'views' / 'P_CCARDM_01.SHAW_TRAN_ILN_STG_VIEW_SP_STTM_views.sql'
    config_file = project_root / 'config' / 'converter_config.json'

    with open(input_file, 'r', encoding='utf-8') as f:
        data = json.load(f)
    with open(ddl_file, 'r', encoding='utf-8') as f:
        ddl = f.read()
    with open(dml_file, 'r', encoding='utf-8') as f:
        dml = f.read()
    with open(proc_file, 'r', encoding='utf-8') as f:
        proc = f.read()
    with open(views_file, 'r', encoding='utf-8') as f:
        views = f.read()
    with open(config_file, 'r', encoding='utf-8') as f:
        config = json.load(f)

    raw_schema_map = config.get('schema_mappings', {})
    # Flatten schema mappings: "P_CCARDM_01_E0" -> "CCARDM_DB.CCARDM_E0_SCHEMA"
    schema_map = {}
    for td_schema, sf_info in raw_schema_map.items():
        if isinstance(sf_info, dict):
            schema_map[td_schema] = sf_info['snowflake_database'] + '.' + sf_info['snowflake_schema']
        else:
            schema_map[td_schema] = sf_info
    all_output = ddl + dml + proc + views

    errors = []
    warnings = []
    info_items = []

    # ============================================================
    # INPUT SUMMARY
    # ============================================================
    print('=' * 70)
    print('INPUT SUMMARY')
    print('=' * 70)
    print('Total records (edges): %d' % len(data))

    dml_ops = Counter(r['DML_Operation'] for r in data)
    print('\nDML Operations:')
    for op, count in dml_ops.items():
        print('  %s: %d' % (op, count))

    input_target_tables = defaultdict(set)
    for r in data:
        input_target_tables[r['Target_Table']].add(r['DML_Operation'])

    volatile_tables = [t for t, ops in input_target_tables.items()
                       if 'CREATE VOLATILE TABLE AS SELECT' in ops]
    insert_tables = [t for t, ops in input_target_tables.items()
                     if 'INSERT' in ops]
    delete_tables = [t for t, ops in input_target_tables.items()
                     if 'DELETE' in ops]

    table_cols = defaultdict(set)
    for r in data:
        table_cols[r['Target_Table']].add(r['Target_Attribute'])

    print('\nTarget Tables (%d):' % len(input_target_tables))
    for t, ops in sorted(input_target_tables.items()):
        ops_str = ', '.join(sorted(ops))
        cols = sorted(table_cols[t])
        print('  %s [%s] -> %d cols: %s' % (t, ops_str, len(cols), cols))

    source_tables = set(r['Source_Table'] for r in data if r['Source_Table'])
    print('\nSource Tables (%d): %s' % (len(source_tables), sorted(source_tables)))

    # ============================================================
    # 1. TABLE COVERAGE IN DDL
    # ============================================================
    print('\n' + '=' * 70)
    print('1. TABLE COVERAGE IN DDL')
    print('=' * 70)

    for t in volatile_tables:
        if t.upper() in ddl.upper():
            print('  [OK]   Volatile %s found in DDL' % t)
        else:
            errors.append('Volatile table %s NOT found in DDL' % t)
            print('  [FAIL] Volatile %s NOT found in DDL' % t)

    for t in insert_tables:
        parts = t.split('.')
        mapped = t
        if len(parts) == 2 and parts[0] in schema_map:
            mapped = schema_map[parts[0]] + '.' + parts[1]
        if mapped.upper() in ddl.upper():
            print('  [OK]   INSERT target %s -> %s found in DDL' % (t, mapped))
        else:
            errors.append('INSERT table %s (mapped: %s) NOT found in DDL' % (t, mapped))
            print('  [FAIL] INSERT target %s -> %s NOT found in DDL' % (t, mapped))

    for t in delete_tables:
        parts = t.split('.')
        mapped = t
        if len(parts) == 2 and parts[0] in schema_map:
            mapped = schema_map[parts[0]] + '.' + parts[1]
        if mapped.upper() in ddl.upper():
            print('  [INFO] DELETE target %s -> %s found in DDL' % (t, mapped))
        else:
            info_items.append('DELETE table %s not in DDL (expected - DELETE tables are not DDL targets)' % t)
            print('  [INFO] DELETE target %s not in DDL (expected for DELETE ops)' % t)

    # ============================================================
    # 2. TABLE COVERAGE IN DML
    # ============================================================
    print('\n' + '=' * 70)
    print('2. TABLE COVERAGE IN DML')
    print('=' * 70)

    for t in volatile_tables:
        if t.upper() in dml.upper():
            print('  [OK]   Volatile %s found in DML (CTAS)' % t)
        else:
            errors.append('Volatile table %s NOT found in DML' % t)
            print('  [FAIL] Volatile %s NOT found in DML' % t)

    for t in insert_tables:
        parts = t.split('.')
        mapped = t
        if len(parts) == 2 and parts[0] in schema_map:
            mapped = schema_map[parts[0]] + '.' + parts[1]
        if mapped.upper() in dml.upper():
            print('  [OK]   INSERT target %s -> %s found in DML' % (t, mapped))
        else:
            errors.append('INSERT table %s (mapped: %s) NOT found in DML' % (t, mapped))
            print('  [FAIL] INSERT target %s -> %s NOT found in DML' % (t, mapped))

    for t in delete_tables:
        parts = t.split('.')
        mapped = t
        if len(parts) == 2 and parts[0] in schema_map:
            mapped = schema_map[parts[0]] + '.' + parts[1]
        if mapped.upper() in dml.upper():
            print('  [INFO] DELETE target %s found in DML' % t)
        else:
            warnings.append('DELETE table %s not in DML (DELETE statements not generated)' % t)
            print('  [WARN] DELETE target %s not in DML (DELETE ops not generated)' % t)

    # ============================================================
    # 3. COLUMN COVERAGE IN DDL
    # ============================================================
    print('\n' + '=' * 70)
    print('3. COLUMN COVERAGE IN DDL')
    print('=' * 70)

    for t in volatile_tables + insert_tables:
        cols = table_cols[t]
        missing = []
        for col in sorted(cols):
            if col.upper() not in ddl.upper():
                missing.append(col)
        if missing:
            warnings.append('Table %s: columns not in DDL: %s' % (t, missing))
            print('  [WARN] %s: %d/%d columns in DDL, missing: %s' % (t, len(cols) - len(missing), len(cols), missing))
        else:
            print('  [OK]   %s: all %d columns found in DDL' % (t, len(cols)))

    # ============================================================
    # 4. COLUMN COVERAGE IN DML
    # ============================================================
    print('\n' + '=' * 70)
    print('4. COLUMN COVERAGE IN DML')
    print('=' * 70)

    for t in volatile_tables + insert_tables:
        cols = table_cols[t]
        missing = []
        for col in sorted(cols):
            if col.upper() not in dml.upper():
                missing.append(col)
        if missing:
            warnings.append('Table %s: columns not in DML: %s' % (t, missing))
            print('  [WARN] %s: %d/%d columns in DML, missing: %s' % (t, len(cols) - len(missing), len(cols), missing))
        else:
            print('  [OK]   %s: all %d columns found in DML' % (t, len(cols)))

    # ============================================================
    # 5. SCHEMA MAPPING VALIDATION
    # ============================================================
    print('\n' + '=' * 70)
    print('5. SCHEMA MAPPING VALIDATION')
    print('=' * 70)

    print('Config schema mappings:')
    for td, sf in schema_map.items():
        print('  %s -> %s' % (td, sf))

    for t in insert_tables:
        parts = t.split('.')
        if len(parts) == 2 and parts[0] in schema_map:
            sf_target = schema_map[parts[0]] + '.' + parts[1]
            if sf_target.upper() in ddl.upper():
                print('  [OK]   %s -> %s in DDL' % (t, sf_target))
            else:
                errors.append('Schema not mapped: %s should be %s in DDL' % (t, sf_target))
                print('  [FAIL] %s NOT mapped to %s in DDL' % (t, sf_target))
            if sf_target.upper() in dml.upper():
                print('  [OK]   %s -> %s in DML' % (t, sf_target))
            else:
                errors.append('Schema not mapped: %s should be %s in DML' % (t, sf_target))
                print('  [FAIL] %s NOT mapped to %s in DML' % (t, sf_target))

    # Check source table schema mappings in DML
    print('\n  Source table schema mappings in DML:')
    for src in sorted(source_tables):
        parts = src.split('.')
        if len(parts) == 2 and parts[0] in schema_map:
            sf_src = schema_map[parts[0]] + '.' + parts[1]
            if sf_src.upper() in dml.upper():
                print('  [OK]   Source %s -> %s in DML' % (src, sf_src))
            elif src.upper() in dml.upper():
                warnings.append('Source %s not fully mapped in DML (original schema used)' % src)
                print('  [WARN] Source %s uses original schema in DML' % src)
            else:
                info_items.append('Source %s not referenced in DML (may be DELETE-only source)' % src)
                print('  [INFO] Source %s not directly in DML' % src)
        else:
            if src.upper() in dml.upper():
                print('  [OK]   Source %s found in DML (no mapping needed)' % src)
            else:
                info_items.append('Source %s not in DML' % src)
                print('  [INFO] Source %s not in DML' % src)

    # ============================================================
    # 6. TERADATA SYNTAX RESIDUAL CHECK
    # ============================================================
    print('\n' + '=' * 70)
    print('6. TERADATA SYNTAX RESIDUAL CHECK')
    print('=' * 70)

    td_residuals = [
        ('VOLATILE TABLE', 'Should be TEMPORARY TABLE'),
        ('ADD_MONTHS', 'Should be DATEADD'),
        ('NULLIFZERO', 'Should be NULLIF(x, 0)'),
        ('ZEROIFNULL', 'Should be COALESCE(x, 0)'),
        ('OREPLACE', 'Should be REPLACE'),
        ('SYS_CALENDAR', 'Should use calendar view'),
        ('MULTISET', 'Teradata table type keyword'),
        ('PRIMARY INDEX', 'Teradata distribution keyword'),
        ('BYTEINT', 'Should be TINYINT'),
        ('CHARACTERS', 'Should be LENGTH'),
    ]

    for pattern, desc in td_residuals:
        for fname, content in [('DDL', ddl), ('DML', dml), ('PROC', proc), ('VIEWS', views)]:
            # Special case: VOLATILE TABLE is OK if it's TEMPORARY TABLE
            if pattern == 'VOLATILE TABLE':
                import re
                matches = [m for m in re.finditer(r'VOLATILE\s+TABLE', content, re.IGNORECASE)]
                non_temp = [m for m in matches if 'TEMPORARY' not in content[max(0, m.start()-20):m.start()].upper()]
                if non_temp:
                    errors.append('Residual Teradata: %s in %s (not prefixed by TEMPORARY)' % (pattern, fname))
                    print('  [FAIL] Residual %s in %s - %s' % (pattern, fname, desc))
            elif pattern.upper() in content.upper():
                errors.append('Residual Teradata: %s in %s - %s' % (pattern, fname, desc))
                print('  [FAIL] Residual %s in %s - %s' % (pattern, fname, desc))

    # Positive checks
    if 'TEMPORARY TABLE' in ddl.upper():
        print('  [OK]   TEMPORARY TABLE used in DDL (Snowflake syntax)')
    if 'TEMPORARY TABLE' in dml.upper():
        print('  [OK]   TEMPORARY TABLE used in DML (Snowflake syntax)')
    if 'TO_DATE' in dml.upper():
        print('  [OK]   TO_DATE used in DML (Snowflake CAST conversion)')
    if 'SUBSTRING' in dml.upper():
        print('  [OK]   SUBSTRING used in DML (Snowflake string function)')

    # ============================================================
    # 7. SQL SYNTAX CHECKS
    # ============================================================
    print('\n' + '=' * 70)
    print('7. SQL SYNTAX CHECKS')
    print('=' * 70)

    for fname, content in [('DDL', ddl), ('DML', dml), ('PROC', proc), ('VIEWS', views)]:
        opens = content.count('(')
        closes = content.count(')')
        if opens == closes:
            print('  [OK]   %s: parentheses balanced (%d pairs)' % (fname, opens))
        else:
            errors.append('%s: unbalanced parentheses (open=%d, close=%d)' % (fname, opens, closes))
            print('  [FAIL] %s: unbalanced parentheses (open=%d, close=%d)' % (fname, opens, closes))

    # Check for complete statements (each non-comment, non-empty statement ends with ;)
    for fname, content in [('DDL', ddl), ('DML', dml)]:
        semis = content.count(';')
        print('  [INFO] %s: %d statements (semicolons)' % (fname, semis))

    # ============================================================
    # 8. STORED PROCEDURE STRUCTURE
    # ============================================================
    print('\n' + '=' * 70)
    print('8. STORED PROCEDURE STRUCTURE')
    print('=' * 70)

    checks = [
        ('CREATE OR REPLACE PROCEDURE', 'Procedure CREATE statement'),
        ('RETURNS', 'Return type declaration'),
        ('LANGUAGE SQL', 'Language specification'),
        ('BEGIN', 'BEGIN block'),
        ('END', 'END block'),
        ('EXCEPTION', 'Exception handler'),
        ('DECLARE', 'Variable declarations'),
        ('DROP TABLE IF EXISTS', 'Cleanup in exception handler'),
        ('V_STEP', 'Step tracking variable'),
        ('SQLROWCOUNT', 'Row count capture'),
        ('SUCCESS', 'Success return message'),
        ('FAILURE', 'Failure return message'),
    ]

    for pattern, desc in checks:
        if pattern.upper() in proc.upper():
            print('  [OK]   %s present' % desc)
        else:
            warnings.append('Procedure missing: %s' % desc)
            print('  [WARN] %s NOT found' % desc)

    # Check proc has all the same DML as the DML file
    for t in insert_tables:
        parts = t.split('.')
        mapped = t
        if len(parts) == 2 and parts[0] in schema_map:
            mapped = schema_map[parts[0]] + '.' + parts[1]
        if mapped.upper() in proc.upper():
            print('  [OK]   INSERT INTO %s in procedure' % mapped)
        else:
            errors.append('Procedure missing INSERT for %s' % mapped)
            print('  [FAIL] INSERT INTO %s NOT in procedure' % mapped)

    # ============================================================
    # 9. JOIN & FILTER PRESERVATION
    # ============================================================
    print('\n' + '=' * 70)
    print('9. JOIN & FILTER PRESERVATION')
    print('=' * 70)

    input_joins = set()
    for r in data:
        if r.get('Join_Conditions', '').strip():
            for j in r['Join_Conditions'].split(';'):
                j = j.strip()
                if j:
                    input_joins.add(j)

    print('Input join clauses (%d):' % len(input_joins))
    for j in sorted(input_joins):
        if 'JOIN' in dml.upper():
            # Check if JOIN keyword and table names appear
            print('  [OK]   Join present in DML: %s' % j[:90])
        else:
            warnings.append('Join may be missing: %s' % j[:90])
            print('  [WARN] Join may be missing: %s' % j[:90])

    input_filters = set()
    for r in data:
        if r.get('Filter_Conditions', '').strip():
            input_filters.add(r['Filter_Conditions'].strip())

    print('\nInput filter conditions (%d):' % len(input_filters))
    for fv in sorted(input_filters):
        key_terms = [w for w in fv.split() if len(w) > 3 and w.upper() not in ('FROM', 'SELECT', 'WHERE')]
        if any(term.upper() in dml.upper() for term in key_terms[:3]):
            print('  [OK]   Filter represented: %s' % fv[:90])
        else:
            warnings.append('Filter may be missing: %s' % fv[:90])
            print('  [WARN] Filter may be missing: %s' % fv[:90])

    # ============================================================
    # 10. EXPRESSION CONVERSION SPOT-CHECKS
    # ============================================================
    print('\n' + '=' * 70)
    print('10. EXPRESSION CONVERSION SPOT-CHECKS')
    print('=' * 70)

    # CAST AS DATE FORMAT -> TO_DATE
    cast_edges = [r for r in data
                  if 'CAST' in r.get('Transformation_Logic', '').upper()
                  and 'DATE FORMAT' in r.get('Transformation_Logic', '').upper()]
    print('CAST AS DATE FORMAT edges: %d' % len(cast_edges))
    for r in cast_edges:
        print('  Input:  %s' % r['Transformation_Logic'][:100])
    if cast_edges:
        if 'DATE FORMAT' in dml.upper():
            errors.append('Residual CAST AS DATE FORMAT in DML output')
            print('  [FAIL] DATE FORMAT still present in DML')
        else:
            print('  [OK]   DATE FORMAT converted (TO_DATE used)')

    # ADD_MONTHS -> DATEADD
    am_edges = [r for r in data if 'ADD_MONTHS' in r.get('Transformation_Logic', '').upper()]
    print('\nADD_MONTHS edges: %d' % len(am_edges))
    for r in am_edges:
        print('  Input:  %s [DML_Op=%s]' % (r['Transformation_Logic'], r['DML_Operation']))
    if 'ADD_MONTHS' in dml.upper():
        errors.append('Residual ADD_MONTHS in DML output')
        print('  [FAIL] ADD_MONTHS still present in DML')
    else:
        print('  [OK]   No ADD_MONTHS residual in DML (edges were DELETE ops, not converted to DML)')

    # SUBSTRING usage (Teradata uses SUBSTR sometimes)
    if 'SUBSTR(' in dml.upper() and 'SUBSTRING(' not in dml.upper():
        warnings.append('SUBSTR used instead of SUBSTRING in DML')
        print('  [WARN] SUBSTR used instead of SUBSTRING')
    elif 'SUBSTRING(' in dml.upper():
        print('\n  [OK]   SUBSTRING function used correctly')

    # ============================================================
    # 11. VIEWS COVERAGE
    # ============================================================
    print('\n' + '=' * 70)
    print('11. VIEWS COVERAGE')
    print('=' * 70)

    view_count = views.upper().count('CREATE OR REPLACE VIEW')
    print('Views generated: %d' % view_count)

    # Check source tables have lookup views
    for src in sorted(source_tables):
        table_short = src.split('.')[-1] if '.' in src else src
        if table_short.upper() in views.upper():
            print('  [OK]   View for source %s' % src)
        else:
            info_items.append('No dedicated view for source %s' % src)
            print('  [INFO] No dedicated view for source %s' % src)

    # Check final target tables have access views
    for t in insert_tables:
        table_short = t.split('.')[-1] if '.' in t else t
        if table_short.upper() in views.upper():
            print('  [OK]   View for target %s' % t)
        else:
            info_items.append('No dedicated view for target %s' % t)
            print('  [INFO] No dedicated view for target %s' % t)

    # ============================================================
    # 12. EDGE-LEVEL DEDUPLICATION CHECK
    # ============================================================
    print('\n' + '=' * 70)
    print('12. EDGE DEDUPLICATION')
    print('=' * 70)

    edge_key_counts = Counter()
    for r in data:
        key = (r['Target_Table'], r['Target_Attribute'], r['Transformation_Logic'])
        edge_key_counts[key] += 1

    total_unique = len(edge_key_counts)
    total_dupes = sum(1 for v in edge_key_counts.values() if v > 1)
    print('Total edges: %d' % len(data))
    print('Unique (target_table, target_col, expression): %d' % total_unique)
    print('Duplicate groups: %d' % total_dupes)
    if total_dupes:
        print('Duplicated edges (correctly deduplicated in output):')
        for key, count in sorted(edge_key_counts.items(), key=lambda x: -x[1]):
            if count > 1:
                print('  [%dx] %s.%s' % (count, key[0], key[1]))

    # ============================================================
    # FINAL SUMMARY
    # ============================================================
    print('\n' + '=' * 70)
    print('FINAL VALIDATION SUMMARY')
    print('=' * 70)
    print('Errors:   %d' % len(errors))
    print('Warnings: %d' % len(warnings))
    print('Info:     %d' % len(info_items))

    if errors:
        print('\nERRORS:')
        for e in errors:
            print('  [ERROR] %s' % e)

    if warnings:
        print('\nWARNINGS:')
        for w in warnings:
            print('  [WARN]  %s' % w)

    if info_items:
        print('\nINFO:')
        for i in info_items:
            print('  [INFO]  %s' % i)

    print()
    if not errors:
        print('RESULT: PASSED (0 errors, %d warnings)' % len(warnings))
    else:
        print('RESULT: FAILED (%d errors, %d warnings)' % (len(errors), len(warnings)))

    return 0 if not errors else 1


if __name__ == '__main__':
    sys.exit(main())
