"""Validation modules for generated SQL and input/output checks."""
