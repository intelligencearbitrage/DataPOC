"""
SQL Validator
=============
Validates generated Snowflake SQL artifacts for correctness.
Extends BaseValidator.

Checks:
- No residual Teradata syntax
- Balanced parentheses
- All STTM edges covered
- Schema mappings applied
- Output files exist

Output: testscripts/validation_results.json
"""

import json
import re
import sys
from pathlib import Path
from typing import Any, Dict, List

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from base.base_validator import BaseValidator
from parsers.sttm_models import STTMDocument


# Teradata syntax patterns that should NOT appear in Snowflake output
RESIDUAL_TERADATA = [
    (r'\bVOLATILE\s+TABLE\b', 'VOLATILE TABLE (should be TEMPORARY TABLE)'),
    (r'\bADD_MONTHS\s*\(', 'ADD_MONTHS (should be DATEADD)'),
    (r'\bEXTRACT\s*\(\s*(YEAR|MONTH|DAY)\s+FROM\b',
     'EXTRACT (should be YEAR/MONTH/DAY function)'),
    (r'\bBYTEINT\b', 'BYTEINT (should be TINYINT)'),
    (r'\bNULLIFZERO\b', 'NULLIFZERO (should be NULLIF)'),
    (r'\bZEROIFNULL\b', 'ZEROIFNULL (should be COALESCE)'),
    (r'\bOREPLACE\b', 'OREPLACE (should be REPLACE)'),
    (r'\bOTRANSLATE\b', 'OTRANSLATE (should be TRANSLATE)'),
    (r'\bPRIMARY\s+INDEX\b', 'PRIMARY INDEX (Teradata-specific)'),
    (r'\bMULTISET\b', 'MULTISET (Teradata-specific)'),
    (r'\bACTIVITY_COUNT\b', 'ACTIVITY_COUNT (should be SQLROWCOUNT)'),
]


class SQLValidator(BaseValidator):
    """Validates generated Snowflake SQL artifacts."""

    def __init__(
        self,
        target_dir: str = 'output',
        input_dir: str = 'inputs',
        config_dir: str = 'config',
        testscripts_dir: str = 'testscripts',
    ):
        super().__init__(target_dir=target_dir)
        self.input_dir = Path(input_dir)
        self.config_dir = Path(config_dir)
        self.testscripts_dir = Path(testscripts_dir)

    def validate(self) -> List[Dict[str, str]]:
        """Run all validation checks."""
        issues: List[Dict[str, str]] = []

        # Check output files exist
        issues.extend(self._check_output_files_exist())

        # Check each SQL file for residual Teradata syntax
        issues.extend(self._check_residual_teradata())

        # Check balanced parentheses
        issues.extend(self._check_balanced_parentheses())

        # Check schema mappings applied
        issues.extend(self._check_schema_mappings())

        # Check edge coverage
        issues.extend(self._check_edge_coverage())

        # Check TEMPORARY TABLE usage (not VOLATILE)
        issues.extend(self._check_temporary_table_syntax())

        # Semantic checks
        issues.extend(self._check_generator_syntax())
        issues.extend(self._check_undefined_aliases())

        return issues

    def _check_output_files_exist(self) -> List[Dict[str, str]]:
        """Check that expected output files exist (per-file folder structure)."""
        issues = []
        expected_subdirs = ['ddl', 'dml', 'stored_procedures', 'views']

        for json_file in self.input_dir.glob('*.json'):
            stem = json_file.stem
            stem_dir = self.target_dir / stem
            if not stem_dir.exists():
                issues.append({
                    'severity': 'ERROR',
                    'file': str(stem_dir),
                    'message': f'Output folder missing for {json_file.name}',
                    'suggestion': 'Run build_all.py'
                })
                continue

            for sub in expected_subdirs:
                sub_path = stem_dir / sub
                if not sub_path.exists() or not list(sub_path.glob('*.sql')):
                    issues.append({
                        'severity': 'ERROR',
                        'file': str(sub_path),
                        'message': f'Missing {sub}/ output for {json_file.name}',
                        'suggestion': f'Run generate_{sub}.py'
                    })

        return issues

    def _check_residual_teradata(self) -> List[Dict[str, str]]:
        """Check for residual Teradata syntax in generated SQL."""
        issues = []

        for sql_file in self.target_dir.rglob('*.sql'):
            content = sql_file.read_text(encoding='utf-8')

            for pattern, description in RESIDUAL_TERADATA:
                matches = re.findall(pattern, content, re.IGNORECASE)
                if matches:
                    # Don't flag items inside comments
                    lines_with_match = []
                    for i, line in enumerate(content.split('\n'), 1):
                        if re.search(pattern, line, re.IGNORECASE):
                            stripped = line.strip()
                            if not stripped.startswith('--'):
                                lines_with_match.append(i)

                    if lines_with_match:
                        issues.append({
                            'severity': 'WARNING',
                            'file': str(sql_file),
                            'message': f'Residual Teradata syntax: {description} (lines: {lines_with_match[:5]})',
                            'suggestion': f'Convert {description} to Snowflake equivalent'
                        })

        return issues

    def _check_balanced_parentheses(self) -> List[Dict[str, str]]:
        """Check that parentheses are balanced in all SQL files."""
        issues = []

        for sql_file in self.target_dir.rglob('*.sql'):
            content = sql_file.read_text(encoding='utf-8')

            # Remove comments and string literals before checking.
            # Block comments MUST be stripped before line comments, because
            # block comments can contain -- (e.g. /* code -- Ver 1.4 */).
            # Stripping line comments first would destroy the closing */.
            clean = re.sub(r'/\*.*?\*/', '', content, flags=re.DOTALL)
            clean = re.sub(r'--[^\n]*', '', clean)
            clean = re.sub(r"'[^']*'", "''", clean)

            open_count = clean.count('(')
            close_count = clean.count(')')

            if open_count != close_count:
                issues.append({
                    'severity': 'ERROR',
                    'file': str(sql_file),
                    'message': f'Unbalanced parentheses: {open_count} open vs {close_count} close',
                    'suggestion': 'Review generated SQL for missing/extra parentheses'
                })

        return issues

    def _check_schema_mappings(self) -> List[Dict[str, str]]:
        """Check that Teradata schema names have been mapped."""
        issues = []
        config_path = self.config_dir / 'converter_config.json'
        if not config_path.exists():
            return issues

        with open(config_path, 'r', encoding='utf-8') as f:
            config = json.load(f)

        schema_mappings = config.get('schema_mappings', {})
        td_schemas = list(schema_mappings.keys())

        for sql_file in self.target_dir.rglob('*.sql'):
            content = sql_file.read_text(encoding='utf-8')

            # Remove comments
            clean = re.sub(r'--[^\n]*', '', content)
            clean = re.sub(r'/\*.*?\*/', '', clean, flags=re.DOTALL)

            for td_schema in td_schemas:
                if re.search(rf'\b{re.escape(td_schema)}\b', clean, re.IGNORECASE):
                    issues.append({
                        'severity': 'INFO',
                        'file': str(sql_file),
                        'message': f'Teradata schema reference found: {td_schema}',
                        'suggestion': f'Verify schema mapping applied: {td_schema} -> Snowflake equivalent'
                    })

        return issues

    def _check_edge_coverage(self) -> List[Dict[str, str]]:
        """Check that all STTM edges are accounted for in output."""
        issues = []

        for json_file in self.input_dir.glob('*.json'):
            doc = STTMDocument.from_file(json_file)
            tables = doc.get_table_inventory()

            dml_path = self.target_dir / json_file.stem / 'dml' / f'{json_file.stem}_dml.sql'
            if not dml_path.exists():
                issues.append({
                    'severity': 'ERROR',
                    'file': str(dml_path),
                    'message': f'DML file not found for {json_file.name}',
                    'suggestion': 'Run generate_dml.py'
                })
                continue

            dml_content = dml_path.read_text(encoding='utf-8').upper()

            for table_name, table_def in tables.items():
                # Check table name appears in DML
                check_name = table_name.split('.')[-1].upper()
                if check_name not in dml_content:
                    issues.append({
                        'severity': 'WARNING',
                        'file': str(dml_path),
                        'message': f'Table {table_name} not found in DML output',
                        'suggestion': f'Verify {table_name} is included in DML generation'
                    })

        return issues

    def _check_temporary_table_syntax(self) -> List[Dict[str, str]]:
        """Check that TEMPORARY TABLE is used (not VOLATILE TABLE)."""
        issues = []

        for sql_file in self.target_dir.rglob('*.sql'):
            content = sql_file.read_text(encoding='utf-8')

            # Check for correct TEMPORARY usage
            temp_count = len(re.findall(
                r'TEMPORARY\s+TABLE', content, re.IGNORECASE
            ))
            volatile_count = len(re.findall(
                r'VOLATILE\s+TABLE', content, re.IGNORECASE
            ))

            if volatile_count > 0:
                issues.append({
                    'severity': 'ERROR',
                    'file': str(sql_file),
                    'message': f'Found {volatile_count} VOLATILE TABLE reference(s) (should be TEMPORARY)',
                    'suggestion': 'Replace VOLATILE TABLE with TEMPORARY TABLE'
                })

        return issues

    def _check_generator_syntax(self) -> List[Dict[str, str]]:
        """Check for invalid D.VALUE references in GENERATOR output.

        Snowflake's GENERATOR() does not produce a VALUE column.
        The correct pattern uses ROW_NUMBER()/SEQ4() in a CTE.
        """
        issues = []

        for sql_file in self.target_dir.rglob('*.sql'):
            content = sql_file.read_text(encoding='utf-8')

            # Remove comments
            clean = re.sub(r'--[^\n]*', '', content)
            clean = re.sub(r'/\*.*?\*/', '', clean, flags=re.DOTALL)

            if re.search(r'\bD\.VALUE\b', clean, re.IGNORECASE):
                issues.append({
                    'severity': 'ERROR',
                    'file': str(sql_file),
                    'message': 'Invalid GENERATOR syntax: D.VALUE reference found',
                    'suggestion': 'Use CTE with ROW_NUMBER()/SEQ4() instead of D.VALUE'
                })

        return issues

    def _check_undefined_aliases(self) -> List[Dict[str, str]]:
        """Check for bare-word JOIN targets that don't match any created table.

        Flags JOINs like 'LEFT JOIN CNSL ON ...' where CNSL is not defined
        as a temp table or resolved to a real table.
        """
        issues = []

        for json_file in self.input_dir.glob('*.json'):
            doc = STTMDocument.from_file(json_file)
            tables = doc.get_table_inventory()
            known_tables = {name.upper() for name in tables}
            # Add unqualified versions
            known_tables_unqual = set()
            for name in tables:
                known_tables_unqual.add(name.split('.')[-1].upper())
            all_known = known_tables | known_tables_unqual

            dml_path = self.target_dir / json_file.stem / 'dml' / f'{json_file.stem}_dml.sql'
            if not dml_path.exists():
                continue

            dml_content = dml_path.read_text(encoding='utf-8')

            # Remove comments
            clean = re.sub(r'--[^\n]*', '', dml_content)
            clean = re.sub(r'/\*.*?\*/', '', clean, flags=re.DOTALL)

            # Find JOIN targets
            join_pattern = re.compile(
                r'\bJOIN\s+(\w+)\s+ON\b', re.IGNORECASE
            )
            for match in join_pattern.finditer(clean):
                target = match.group(1).upper()
                if target not in all_known:
                    # Check if it's a subquery alias (preceded by ')')
                    before = clean[:match.start()].rstrip()
                    if before.endswith(')'):
                        continue  # This is a subquery alias, fine
                    issues.append({
                        'severity': 'WARNING',
                        'file': str(dml_path),
                        'message': f'JOIN target "{match.group(1)}" is not a known table',
                        'suggestion': f'Verify alias mapping for {match.group(1)}'
                    })

        return issues

    def save_results(self, issues: List[Dict[str, str]]) -> Path:
        """Save validation results to JSON."""
        self.testscripts_dir.mkdir(parents=True, exist_ok=True)
        report = self.report(issues)

        output_path = self.testscripts_dir / 'validation_results.json'
        with open(output_path, 'w', encoding='utf-8') as f:
            json.dump(report, f, indent=2)

        self.logger.info(f"Validation results saved to: {output_path}")
        return output_path


def main():
    """Run SQL validation."""
    project_root = Path(__file__).resolve().parent.parent
    validator = SQLValidator(
        target_dir=str(project_root / 'output'),
        input_dir=str(project_root / 'inputs'),
        config_dir=str(project_root / 'config'),
        testscripts_dir=str(project_root / 'testscripts'),
    )

    issues = validator.validate()
    report = validator.report(issues)
    validator.save_results(issues)

    # Print summary
    summary = report['validation_report']['summary']
    print(f"\nValidation {'PASSED' if summary['passed'] else 'FAILED'}")
    print(f"  Errors: {summary['errors']}")
    print(f"  Warnings: {summary['warnings']}")
    print(f"  Info: {summary['info']}")


if __name__ == '__main__':
    main()
