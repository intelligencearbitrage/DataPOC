"""
Base Parser - Abstract base class for parsing input files.

Subclass this to create parsers for specific formats (Excel, XML, JSON, SQL, etc.)
The builder agent creates subclasses that read source data from inputs/ at runtime.

Usage:
    class MyParser(BaseParser):
        def discover_files(self):
            return list(self.input_dir.glob('*.xlsx'))

        def parse_file(self, file_path):
            # your parsing logic
            return {'name': file_path.stem, 'items': [...]}

    parser = MyParser(input_dir='inputs', output_dir='output')
    parser.parse_all()
    parser.save_analysis('my_analysis.yaml')
"""

from abc import ABC, abstractmethod
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List

from utils import save_yaml, setup_logging


class BaseParser(ABC):
    """Abstract base class for input file parsers."""

    def __init__(self, input_dir: str = 'inputs', output_dir: str = 'output'):
        self.input_dir = Path(input_dir)
        self.output_dir = Path(output_dir)
        self.parsed_data: Dict[str, Any] = {}
        self.gaps: List[Dict[str, str]] = []
        self.logger = setup_logging(self.__class__.__name__)

    @abstractmethod
    def discover_files(self) -> List[Path]:
        """Find input files to parse. Override per format."""
        ...

    @abstractmethod
    def parse_file(self, file_path: Path) -> Dict[str, Any]:
        """Parse a single input file. Override per format."""
        ...

    def parse_all(self) -> Dict[str, Any]:
        """Parse all discovered files."""
        files = self.discover_files()
        self.logger.info(f"Discovered {len(files)} file(s) to parse")

        for f in files:
            self.logger.info(f"Parsing: {f.name}")
            try:
                self.parsed_data[f.stem] = self.parse_file(f)
            except Exception as e:
                self.logger.error(f"Failed to parse {f.name}: {e}")
                self.gaps.append({
                    'description': f"Failed to parse {f.name}: {e}",
                    'recommendation': f"Check file format and retry"
                })

        return self.parsed_data

    def identify_gaps(self) -> List[Dict[str, str]]:
        """Identify gaps in the parsed data. Override to add custom gap detection."""
        return self.gaps

    def generate_analysis(self) -> Dict[str, Any]:
        """Generate structured analysis output."""
        return {
            'findings': {
                'metadata': {
                    'source_directory': str(self.input_dir),
                    'date': datetime.now().strftime('%Y-%m-%d'),
                    'files_processed': len(self.parsed_data),
                    'agent': 'researcher',
                },
                'summary': {
                    'key_items_found': sum(
                        len(v.get('items', [])) if isinstance(v, dict) else 0
                        for v in self.parsed_data.values()
                    ),
                    'sources': list(self.parsed_data.keys()),
                },
                'findings': self.parsed_data,
                'gaps': self.identify_gaps(),
            }
        }

    def save_analysis(self, filename: str = 'analysis.yaml') -> Path:
        """Save analysis to YAML file in output directory."""
        analysis = self.generate_analysis()
        output_path = save_yaml(analysis, self.output_dir / filename)
        self.logger.info(f"Analysis saved to: {output_path}")
        return output_path


def main():
    """Example usage — override this in your subclass module."""
    print("BaseParser is abstract. Create a subclass for your specific input format.")
    print("See .claude/skills/parse-input.md for patterns.")


if __name__ == '__main__':
    main()
