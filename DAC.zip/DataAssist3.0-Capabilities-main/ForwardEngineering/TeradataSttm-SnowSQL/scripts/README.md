# STTM-SnowSQL-Toolkit

Converts **STTM (Source-to-Target Mapping) JSON** files into **Snowflake SQL** artifacts: DDL, DML, stored procedures, and views. Includes Teradata-to-Snowflake expression conversion using 73 regex-based rules.

## Quick Start

```bash
# 1. Place STTM JSON files in inputs/
cp your_lineage.json inputs/

# 2. Run the full build pipeline
python scripts/pipeline/build_all.py

# 3. Check output
ls output/ddl/          # CREATE TABLE statements
ls output/dml/          # INSERT/CTAS statements
ls output/stored_procedures/  # Wrapped procedures
ls output/views/        # Helper views

# 4. Validate
python scripts/pipeline/validate_sql.py
```

## What It Does

1. **Parses** STTM JSON (column-level lineage edges with SQL expressions)
2. **Resolves** table dependencies via topological sort
3. **Converts** Teradata expressions to Snowflake SQL (73 rules)
4. **Assembles** full SQL statements from column-level edges
5. **Generates** DDL, DML, stored procedures, views, and lineage reports
6. **Validates** output for correctness (no residual Teradata syntax, balanced parens, edge coverage)

## Project Structure

```
STTM-SnowSQL-Toolkit/
├── inputs/              # STTM JSON files (input)
├── output/              # Generated SQL artifacts (output)
│   ├── ddl/             # CREATE TABLE statements
│   ├── dml/             # INSERT/CTAS statements
│   ├── stored_procedures/ # Snowflake procedures
│   └── views/           # Helper views
├── scripts/             # Core conversion engine
│   ├── sttm_models.py   # Data classes (Edge, Table, etc.)
│   ├── sttm_parser.py   # STTM JSON parser
│   ├── dependency_resolver.py  # Topological sort
│   ├── expression_converter.py # TD->SF expression conversion
│   ├── statement_assembler.py  # Groups edges into SQL
│   ├── generate_ddl.py  # DDL generator
│   ├── generate_dml.py  # DML generator
│   ├── generate_stored_procedure.py  # Procedure generator
│   ├── generate_views.py # View generator
│   ├── generate_lineage_report.py  # Lineage report
│   ├── validate_sql.py  # SQL validator
│   ├── build_all.py     # Master build script
│   └── converter/       # 73 Teradata->Snowflake rules
│       └── rules.py
├── config/              # Configuration
│   ├── converter_config.json     # Schema mappings, rule toggles
│   └── table_type_overrides.json # Column type overrides
├── knowledgebase/       # Reference materials
├── guardrails/          # Quality enforcement scripts
└── .claude/             # Agent team definitions
```

## Configuration

### Schema Mappings (`config/converter_config.json`)

Maps Teradata schema names to Snowflake database.schema:

```json
{
  "schema_mappings": {
    "P_CCARDM_01_V0": {
      "snowflake_database": "CCARDM_DB",
      "snowflake_schema": "CCARDM_V0_SCHEMA"
    }
  }
}
```

### Column Type Overrides (`config/table_type_overrides.json`)

Manual type assignments when inference isn't sufficient:

```json
{
  "overrides": {
    "DATE_PARAMETERS": {
      "CCAR_DATE": "DATE",
      "TAPEYEAR": "INTEGER"
    }
  }
}
```

## Running Individual Scripts

```bash
python scripts/sttm_parser.py          # Parse and print table inventory
python scripts/dependency_resolver.py   # Show execution order
python scripts/expression_converter.py  # Demo expression conversion
python scripts/generate_ddl.py          # Generate DDL only
python scripts/generate_dml.py          # Generate DML only
python scripts/generate_stored_procedure.py  # Generate procedures
python scripts/generate_views.py        # Generate views
python scripts/generate_lineage_report.py    # Generate lineage report
python scripts/pipeline/validate_sql.py          # Run validation
python scripts/pipeline/build_all.py             # Run all generators
```

## Conversion Rules

73 rules across 7 categories, reused from TD-SnowSQL-Toolkit:

| Category | Rules | Examples |
|----------|-------|---------|
| Date | 20 | ADD_MONTHS -> DATEADD, EXTRACT -> YEAR/MONTH/DAY |
| Syntax | 20 | VOLATILE -> TEMPORARY, NULLIFZERO -> NULLIF |
| String | 10 | OREPLACE -> REPLACE, CHARACTERS -> LENGTH |
| Cast | 7 | CAST(x AS DATE) -> x::DATE |
| Table | 8 | Remove PRIMARY INDEX, WITH DATA ON COMMIT |
| Datatype | 4 | BYTEINT -> TINYINT, CLOB -> VARCHAR |
| Procedure | 2 | REPLACE PROCEDURE -> CREATE OR REPLACE PROCEDURE |
