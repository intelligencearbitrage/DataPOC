# SQL Server to PostgreSQL Converter — Scripts

This directory contains the Python scripts that convert SQL Server (T-SQL) files to
PostgreSQL-compatible PL/pgSQL files.

## Quick Start

Run the full conversion pipeline from the project root:

```
python agent-output/scripts/generate_output.py
```

Or use the CLI:

```
python agent-output/scripts/cli.py all
```

Both commands produce two output files in `scripts-output/output/`.

## Input Files

| File | Description |
|------|-------------|
| `user-config/inputs/SQLServer_SP.sql` | T-SQL stored procedure sp_agg_email_universe |
| `user-config/inputs/SqlServer_Sample DML.sql` | Standalone DDL and DML statements |

## Output Files

| File | Description |
|------|-------------|
| `scripts-output/output/SQLServer_SP.sql` | Converted PostgreSQL stored procedure |
| `scripts-output/output/SqlServer_Sample_DML.sql` | Converted PostgreSQL DDL and DML |

## Scripts

| Script | Description |
|--------|-------------|
| `generate_output.py` | Main entry point — orchestrates all converters and writes output files |
| `parse_input.py` | Parses .sql files and identifies object boundaries (DDL, DML, procedures) |
| `convert_ddl.py` | Converts DDL syntax: NUMBER->NUMERIC, nvarchar->TEXT, #temp->TEMP TABLE, COLLATE, CREATE TABLE IF NOT EXISTS, DROP TABLE IF EXISTS |
| `convert_dml.py` | Converts DML/expression syntax: GETDATE()->NOW(), ISNULL()->COALESCE(), DATEDIFF()->DATE_PART(), CONVERT()->TO_CHAR(), @@ROWCOUNT->GET DIAGNOSTICS, bracket identifiers, cross-DB refs, column aliases |
| `convert_procedures.py` | Converts stored procedure structure: @var->DECLARE block, SET NOCOUNT ON->remove, GO->remove, PRINT->RAISE NOTICE, BEGIN TRY->BEGIN, EXECUTE->CALL, OUTPUT->INOUT |
| `cli.py` | Unified CLI entry point for running any script |

## CLI Commands

```
python agent-output/scripts/cli.py all               # Run full pipeline
python agent-output/scripts/cli.py generate_output   # Same as 'all'
python agent-output/scripts/cli.py parse_input        # Test parse_input
python agent-output/scripts/cli.py convert_ddl        # Test convert_ddl
python agent-output/scripts/cli.py convert_dml        # Test convert_dml
python agent-output/scripts/cli.py convert_procedures # Test convert_procedures
```

## Requirements

- Python 3.8+
- No external dependencies — standard library only (pathlib, re, sys, typing)

## Architecture

The pipeline applies converters in sequence for each input file:

**SQLServer_SP.sql (stored procedure):**
```
parse_input -> convert_procedures -> convert_ddl -> convert_dml (context=procedure)
```

**SqlServer_Sample DML.sql (standalone DDL+DML):**
```
parse_input -> convert_ddl -> convert_dml (context=standalone)
```

All scripts are idempotent — safe to run multiple times.
