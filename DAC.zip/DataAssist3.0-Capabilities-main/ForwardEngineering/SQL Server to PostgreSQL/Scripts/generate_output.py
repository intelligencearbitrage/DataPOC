"""
generate_output.py — Orchestrate all converters and write final PostgreSQL .sql files.

This is the main entry point for the SQL Server to PostgreSQL conversion pipeline.
Running this script produces two output files in scripts-output/output/:
  - SQLServer_SP.sql         — converted stored procedure
  - SqlServer_Sample_DML.sql — converted standalone DDL + DML

Pipeline for SQLServer_SP.sql (stored procedure):
    parse_input -> convert_procedures -> convert_ddl -> convert_dml (procedure context)

Pipeline for SqlServer_Sample DML.sql (standalone DDL+DML):
    parse_input -> convert_ddl -> convert_dml (standalone context)

Usage:
    python agent-output/scripts/generate_output.py
"""

import sys
from pathlib import Path
from typing import Optional


def _setup_imports() -> None:
    """Add the scripts directory to sys.path so sibling modules can be imported."""
    scripts_dir = Path(__file__).resolve().parent
    if str(scripts_dir) not in sys.path:
        sys.path.insert(0, str(scripts_dir))


_setup_imports()

import parse_input       # noqa: E402
import convert_ddl       # noqa: E402
import convert_dml       # noqa: E402
import convert_procedures  # noqa: E402


def get_project_root() -> Path:
    """Resolve the project root as two directories above this script.

    This script lives at: <project_root>/agent-output/scripts/generate_output.py
    So project root is: Path(__file__).resolve().parent.parent.parent
    """
    return Path(__file__).resolve().parent.parent.parent


def process_sp_file(sp_path: Path, output_path: Path) -> None:
    """Convert SQLServer_SP.sql (stored procedure) to PostgreSQL.

    Pipeline: parse -> convert_procedures -> convert_ddl -> convert_dml

    Args:
        sp_path: Path to the input SQLServer_SP.sql file.
        output_path: Path where the converted output should be written.
    """
    print(f"Processing: {sp_path.name}")

    # Parse
    parsed = parse_input.parse_file(str(sp_path))
    text = parsed['raw_text']

    # Step 1: Convert procedure structure (header, DECLARE, EXECUTE, PRINT, etc.)
    text = convert_procedures.convert(text)

    # Step 2: Convert DDL (types, temp tables, COLLATE, DROP TABLE variants)
    text = convert_ddl.convert(text)

    # Step 3: Convert DML (functions, aliases, cross-DB refs, variables)
    text = convert_dml.convert(text, context='procedure')

    # Write output
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(text, encoding='utf-8')
    print(f"  -> Written: {output_path}")


def process_dml_file(dml_path: Path, output_path: Path) -> None:
    """Convert SqlServer_Sample DML.sql (standalone DDL+DML) to PostgreSQL.

    Pipeline: parse -> convert_ddl -> convert_dml (standalone context)
    No procedure conversion applied.

    Args:
        dml_path: Path to the input 'SqlServer_Sample DML.sql' file (has space in name).
        output_path: Path where the converted output should be written (underscore in name).
    """
    print(f"Processing: {dml_path.name}")

    # Parse
    parsed = parse_input.parse_file(str(dml_path))
    text = parsed['raw_text']

    # Step 1: Convert DDL (types, temp tables — no COLLATE in this file)
    text = convert_ddl.convert(text)

    # Step 2: Convert DML in standalone context (@process_log_id -> NULL)
    text = convert_dml.convert(text, context='standalone')

    # Write output
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(text, encoding='utf-8')
    print(f"  -> Written: {output_path}")


def main() -> None:
    """Run the full conversion pipeline for both input files."""
    project_root = get_project_root()

    # Input paths
    sp_input = project_root / "user-config" / "inputs" / "SQLServer_SP.sql"
    dml_input = project_root / "user-config" / "inputs" / "SqlServer_Sample DML.sql"

    # Output paths
    output_dir = project_root / "scripts-output" / "output"
    sp_output = output_dir / "SQLServer_SP.sql"
    dml_output = output_dir / "SqlServer_Sample_DML.sql"

    # Validate inputs exist
    for path in [sp_input, dml_input]:
        if not path.exists():
            print(f"ERROR: Input file not found: {path}", file=sys.stderr)
            sys.exit(1)

    print(f"Project root: {project_root}")
    print(f"Output directory: {output_dir}")
    print()

    # Process stored procedure file
    process_sp_file(sp_input, sp_output)

    # Process standalone DML file
    process_dml_file(dml_input, dml_output)

    print()
    print("Conversion complete.")
    print(f"Output files:")
    print(f"  {sp_output}")
    print(f"  {dml_output}")

    # Verify output files were written
    for out in [sp_output, dml_output]:
        if not out.exists() or out.stat().st_size == 0:
            print(f"ERROR: Output file missing or empty: {out}", file=sys.stderr)
            sys.exit(1)

    print("\nAll output files verified.")


if __name__ == "__main__":
    main()
