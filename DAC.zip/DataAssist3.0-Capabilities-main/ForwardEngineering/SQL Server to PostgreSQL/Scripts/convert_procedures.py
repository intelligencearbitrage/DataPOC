"""
convert_procedures.py — Rewrite a T-SQL stored procedure to PL/pgSQL format.

Handles:
  - Procedure header: CREATE PROCEDURE [dbo].[name](@params) AS BEGIN
      -> CREATE OR REPLACE PROCEDURE name(params) LANGUAGE plpgsql AS $$ BEGIN
  - Parameter list: @param type = default -> param type DEFAULT default
  - SET NOCOUNT ON -> (remove)
  - DECLARE block: multi-variable T-SQL DECLARE -> PL/pgSQL DECLARE block
    (also adds row_count INTEGER for @@ROWCOUNT capture)
  - Body SET @var = value -> var := value
  - SELECT @var = col FROM table -> SELECT col INTO var FROM table
  - BEGIN TRY -> BEGIN; END TRY -> (remove, absorbed)
  - EXECUTE proc @p=v, @p2=v2 OUTPUT -> CALL schema.proc(v, v2)
  - EXEC proc @params -> CALL schema.proc(args)
  - PRINT 'msg' + @var -> RAISE NOTICE 'msg %', var
  - END; GO -> END; $$ LANGUAGE plpgsql;
  - Preserves block comments /*...*/ verbatim

Only applied to files containing a T-SQL stored procedure (file_type='procedure').

Usage:
    from convert_procedures import convert
    converted_sql = convert(sql_text)
"""

import re
from typing import Optional, List, Tuple


def convert(text: str) -> str:
    """Apply all stored-procedure structural conversions to T-SQL text.

    This function operates on the full stored-procedure file text. It rewrites
    the procedure scaffold from T-SQL to PL/pgSQL. DDL and DML content within
    the body are handled by convert_ddl and convert_dml respectively.

    Args:
        text: Full SQL text of a T-SQL stored procedure file.

    Returns:
        SQL text with the procedure structure converted to PL/pgSQL.
    """
    text = _convert_procedure_header(text)
    text = _remove_set_nocount(text)
    text = _convert_declare_block(text)
    text = _convert_set_variable_assignments(text)
    text = _convert_select_variable_assignment(text)
    text = _convert_try_catch_to_exception(text)
    text = _convert_execute_calls(text)
    text = _convert_print_statements(text)
    text = _convert_standalone_selects(text)
    text = _convert_procedure_end(text)
    return text


# ---------------------------------------------------------------------------
# Procedure header
# ---------------------------------------------------------------------------

def _convert_procedure_header(text: str) -> str:
    """Convert CREATE PROCEDURE [dbo].[name](@params) AS BEGIN
    to CREATE OR REPLACE PROCEDURE name(params) LANGUAGE plpgsql AS $$ BEGIN.
    """
    # Find CREATE PROCEDURE position
    cp_match = re.search(r'(?i)\bCREATE\s+PROCEDURE\s+', text)
    if not cp_match:
        return text

    pos = cp_match.end()
    # Extract proc name (up to opening paren or AS)
    name_match = re.match(r'([\[\].\w]+)\s*', text[pos:])
    if not name_match:
        return text
    proc_name_raw = name_match.group(1)
    pos += name_match.end()

    # Extract parameter list (balanced parens)
    params_raw = ''
    if pos < len(text) and text[pos] == '(':
        params_raw, pos = _extract_balanced_parens(text, pos)

    # Skip to AS\nBEGIN
    as_begin_match = re.search(r'(?i)\s*\n?\s*AS\s*\n\s*BEGIN', text[pos:])
    if not as_begin_match:
        return text
    after_pos = pos + as_begin_match.end()

    # Build replacement
    proc_name = re.sub(r'(?i)\[dbo\]\.', '', proc_name_raw)
    proc_name = re.sub(r'[\[\]]', '', proc_name)
    if params_raw:
        params_converted = _convert_param_list(params_raw)
    else:
        params_converted = ''

    # In PL/pgSQL, DECLARE section goes BETWEEN AS $$ and BEGIN:
    #   CREATE OR REPLACE PROCEDURE name(params) LANGUAGE plpgsql AS $$
    #   DECLARE
    #     var type;
    #   BEGIN
    #     body
    #   END;
    #   $$ LANGUAGE plpgsql;
    # Use a placeholder that _convert_declare_block will fill in.
    replacement = (
        f"CREATE OR REPLACE PROCEDURE {proc_name}"
        f"({params_converted})\nAS $$\n__DECLARE_SECTION__\nBEGIN"
    )
    return text[:cp_match.start()] + replacement + text[after_pos:]


def _extract_balanced_parens(text: str, start: int) -> Tuple[str, int]:
    """Extract content inside balanced parentheses starting at start (which must be '(').

    Returns (content_inside_parens, position_after_closing_paren).
    """
    assert text[start] == '('
    depth = 0
    i = start
    in_string = False
    while i < len(text):
        ch = text[i]
        if ch == "'" and not in_string:
            in_string = True
        elif ch == "'" and in_string:
            if i + 1 < len(text) and text[i + 1] == "'":
                i += 2
                continue
            in_string = False
        elif not in_string:
            if ch == '(':
                depth += 1
            elif ch == ')':
                depth -= 1
                if depth == 0:
                    return text[start + 1:i], i + 1
        i += 1
    return text[start + 1:], len(text)


def _convert_param_list(params_raw: str) -> str:
    """Convert T-SQL parameter list to PL/pgSQL format.

    @param type = default -> param type DEFAULT default
    """
    params = [p.strip() for p in params_raw.split(',') if p.strip()]
    converted = []
    for param in params:
        # @name type = default
        m = re.match(r'@(\w+)\s+(\w+(?:\(\d+(?:,\d+)?\))?)\s*=\s*(.+)', param.strip())
        if m:
            name = m.group(1)
            ptype = _convert_type(m.group(2))
            default = m.group(3).strip()
            converted.append(f"{name} {ptype} DEFAULT {default}")
        else:
            # @name type (no default)
            m2 = re.match(r'@(\w+)\s+(.+)', param.strip())
            if m2:
                name = m2.group(1)
                ptype = _convert_type(m2.group(2).strip())
                converted.append(f"{name} {ptype}")
            else:
                converted.append(param.strip())
    return ', '.join(converted)


def _convert_type(type_str: str) -> str:
    """Convert T-SQL type names to PostgreSQL equivalents."""
    type_str = re.sub(r'(?i)\bnvarchar\b', 'VARCHAR', type_str)
    type_str = re.sub(r'(?i)\bint\b', 'INTEGER', type_str)
    return type_str


# ---------------------------------------------------------------------------
# SET NOCOUNT ON
# ---------------------------------------------------------------------------

def _remove_set_nocount(text: str) -> str:
    """Remove SET NOCOUNT ON; — not needed in PostgreSQL."""
    return re.sub(r'(?i)\s*SET\s+NOCOUNT\s+ON\s*;\s*\n?', '\n', text)


# ---------------------------------------------------------------------------
# DECLARE block
# ---------------------------------------------------------------------------

def _convert_declare_block(text: str) -> str:
    """Convert T-SQL DECLARE block to PL/pgSQL DECLARE block.

    Extracts the T-SQL DECLARE block from the procedure body, converts it to
    PL/pgSQL DECLARE syntax, and inserts it at the __DECLARE_SECTION__ placeholder
    (which sits between AS $$ and BEGIN). The original DECLARE block is removed
    from the body.

    T-SQL pattern:
        DECLARE @var1 type1 = val1,
                @var2 type2;

    PL/pgSQL output (placed before BEGIN):
        DECLARE
          var1 type1 := val1;
          var2 type2;
          row_count INTEGER;
    """
    # Find the DECLARE block (from DECLARE up to the final semicolon of the declaration)
    declare_match = re.search(
        r'(?i)(DECLARE\s+@\w+[\s\S]*?;)(?=\s*\n\s*(?:CREATE|SELECT|INSERT|BEGIN|SET|EXEC|EXECUTE|PRINT|DROP|\-\-))',
        text,
    )
    if not declare_match:
        # No DECLARE block found — just remove placeholder
        text = text.replace('__DECLARE_SECTION__\n', '')
        return text

    declare_block = declare_match.group(1)
    converted_declare = _build_declare_block(declare_block)

    # Remove the original DECLARE block from the body
    text = text[:declare_match.start()] + text[declare_match.end():]

    # Insert the converted DECLARE at the placeholder
    text = text.replace('__DECLARE_SECTION__', converted_declare)
    return text


def _build_declare_block(declare_text: str) -> str:
    """Build a PL/pgSQL DECLARE block from T-SQL DECLARE text."""
    # Extract individual variable declarations
    # Remove the leading DECLARE keyword
    body = re.sub(r'(?i)^\s*DECLARE\s+', '', declare_text).strip()
    # Remove trailing semicolon
    body = body.rstrip(';').strip()

    lines = []
    # Split on commas that are at the start of a line or after a variable declaration
    # Handle the multi-line style: "  ,\n  @var2 type2"
    # First normalize: join continuation lines
    # Remove leading commas (T-SQL style: ", @var on new line")
    body = re.sub(r'\n\s*,\s*', '\n', body)
    # Also handle trailing commas
    body = re.sub(r',\s*\n', '\n', body)

    # Now split by @ (each variable starts with @)
    # But preserve comment lines
    raw_lines = body.split('\n')
    var_buffer = ''
    for raw_line in raw_lines:
        stripped = raw_line.strip()
        if not stripped:
            continue
        if stripped.startswith('--'):
            # Preserve comment lines
            if var_buffer:
                parsed = _parse_var_decl(var_buffer)
                if parsed:
                    lines.append(parsed)
                var_buffer = ''
            lines.append(f"  {stripped}")
        elif stripped.startswith('@'):
            if var_buffer:
                parsed = _parse_var_decl(var_buffer)
                if parsed:
                    lines.append(parsed)
            var_buffer = stripped
        else:
            # Continuation of previous variable or comment
            if var_buffer:
                var_buffer += ' ' + stripped
            else:
                var_buffer = stripped

    if var_buffer:
        parsed = _parse_var_decl(var_buffer)
        if parsed:
            lines.append(parsed)

    # Add process_log_id if referenced in the body but not explicitly declared
    # (it's used in EXECUTE OUTPUT and passed to other procedures)
    declared_names = set()
    for line in lines:
        m = re.match(r'\s+(\w+)\s+\w+', line)
        if m:
            declared_names.add(m.group(1).lower())
    if 'process_log_id' not in declared_names:
        lines.append('  process_log_id BIGINT;  -- used by ops_begin_process_log OUTPUT and passed to other calls')

    # Add row_count for @@ROWCOUNT
    lines.append('  row_count INTEGER;  -- for GET DIAGNOSTICS / ROW_COUNT capture')

    return 'DECLARE\n' + '\n'.join(lines)


def _parse_var_decl(var_text: str) -> Optional[str]:
    """Parse a single T-SQL variable declaration into PL/pgSQL format.

    Input:  @varname type = default_value
    Output: "  varname type := default_value;"
    """
    var_text = var_text.strip().lstrip(',').strip()
    if not var_text or not var_text.startswith('@'):
        return None

    # @name type = value (with optional inline comment)
    m = re.match(r'@(\w+)\s+([^=\n]+?)\s*=\s*(.+?)(?:\s*--.*)?$', var_text.strip())
    if m:
        name = m.group(1)
        raw_type = m.group(2).strip().rstrip(',')
        default = m.group(3).strip().rstrip(',')
        ptype = _convert_type(raw_type)
        return f"  {name} {ptype} := {default};"

    # @name type (no default)
    m2 = re.match(r'@(\w+)\s+(.+?)(?:\s*--.*)?$', var_text.strip())
    if m2:
        name = m2.group(1)
        raw_type = m2.group(2).strip().rstrip(',')
        ptype = _convert_type(raw_type)
        return f"  {name} {ptype};"

    return None


# ---------------------------------------------------------------------------
# SET variable assignments
# ---------------------------------------------------------------------------

def _convert_set_variable_assignments(text: str) -> str:
    """Convert SET @var = value; -> var := value;"""
    def _replace_set(m: re.Match) -> str:
        var_name = m.group(1)
        value = m.group(2).strip()
        # Convert string concat + to || within the value
        value = _convert_value_string_concat(value)
        # Remove @ from variable references in value
        value = re.sub(r'@(\w+)', r'\1', value)
        return f"{var_name} := {value};"

    return re.sub(
        r'(?i)\bSET\s+@(\w+)\s*=\s*(.+?);',
        _replace_set,
        text,
    )


def _convert_value_string_concat(value: str) -> str:
    """Convert string concatenation + to || in a value expression."""
    if re.search(r"'[^']*'\s*\+|'\s*\+\s*'|\+\s*'[^']*'", value):
        value = re.sub(r"(['\w\)]+)\s*\+\s*(['\w\(@])", lambda m: m.group(1) + ' || ' + m.group(2), value)
    return value


# ---------------------------------------------------------------------------
# SELECT variable assignment
# ---------------------------------------------------------------------------

def _convert_select_variable_assignment(text: str) -> str:
    """Convert SELECT @var = col FROM table -> SELECT col INTO var FROM table."""
    def _replace_select_assign(m: re.Match) -> str:
        var_name = m.group(1)
        col_expr = m.group(2).strip()
        rest = m.group(3)
        return f"SELECT {col_expr} INTO {var_name} {rest}"

    return re.sub(
        r'(?i)\bSELECT\s+@(\w+)\s*=\s*(\w+(?:\.\w+)?)\s+(FROM\b.*?)(?=;|\n)',
        _replace_select_assign,
        text,
        flags=re.DOTALL,
    )


# ---------------------------------------------------------------------------
# BEGIN TRY / END TRY -> BEGIN / EXCEPTION WHEN OTHERS THEN
# ---------------------------------------------------------------------------

def _convert_try_catch_to_exception(text: str) -> str:
    """Convert BEGIN TRY...END TRY + success/failure paths into proper PL/pgSQL EXCEPTION structure.

    In the source T-SQL, the code after END TRY has both success and failure paths
    that execute sequentially (because CATCH is commented out). This restructures
    them into proper BEGIN/EXCEPTION WHEN OTHERS THEN/END so they are mutually exclusive.

    Structure transformation:
      BEGIN TRY
        <try_body>
      END TRY;
      /*BEGIN CATCH ... END CATCH*/
      <success_section>        -- contains 'Succeeded' status
      -- Error Handler / --HANDLE_ERROR:
      <failure_section>        -- contains 'Failed' status
      <remainder>              -- END; GO

    Becomes:
      BEGIN
        <try_body>
        <success_section>
      EXCEPTION WHEN OTHERS THEN
        /*BEGIN CATCH ... END CATCH*/
        <failure_section>
      END;
      <remainder>
    """
    # Find BEGIN TRY
    begin_try_match = re.search(r'(?i)\bBEGIN\s+TRY\b', text)
    if not begin_try_match:
        return text

    # Find END TRY
    end_try_match = re.search(r'(?i)\bEND\s+TRY\s*;', text)
    if not end_try_match:
        return text

    before_try = text[:begin_try_match.start()]
    try_body = text[begin_try_match.end():end_try_match.start()]
    after_end_try = text[end_try_match.end():]

    # Extract the commented-out CATCH block (if present)
    catch_comment = ''
    catch_match = re.search(r'/\*BEGIN\s+CATCH[\s\S]*?END\s+CATCH\*/', after_end_try)
    if catch_match:
        catch_comment = catch_match.group(0)
        after_catch = after_end_try[catch_match.end():]
    else:
        after_catch = after_end_try

    # Find the boundary between success and failure sections
    # The error handler marker separates them
    # Look for patterns like: "-- Error Handler" or "--HANDLE_ERROR" or "--RETURN;\n--HANDLE_ERROR:"
    error_handler_match = re.search(
        r'(?m)^[ \t]*--[ \t]*Error\s+Handler.*?\n(?:[ \t]*--RETURN;?\s*\n)?(?:[ \t]*--HANDLE_ERROR:?\s*\n)?',
        after_catch,
    )

    if error_handler_match:
        success_section = after_catch[:error_handler_match.start()]
        failure_section = after_catch[error_handler_match.end():]
    else:
        # Fallback: split at the second SET @process_log_status = 'Failed'
        failed_match = re.search(r"(?i)(?:SET\s+@)?process_log_status\s*:?=\s*'Failed'", after_catch)
        if failed_match:
            # Find the start of the line containing 'Failed'
            line_start = after_catch.rfind('\n', 0, failed_match.start())
            if line_start == -1:
                line_start = 0
            else:
                line_start += 1
            success_section = after_catch[:line_start]
            failure_section = after_catch[line_start:]
        else:
            # Cannot identify split point — fall back to simple BEGIN/END
            text = re.sub(r'(?i)\bBEGIN\s+TRY\b', 'BEGIN', text)
            text = re.sub(r'(?i)\bEND\s+TRY\s*;', '', text)
            return text

    # Find where the failure section ends (before the final END; or END;\nGO)
    # The failure section ends at the last content before the procedure END
    # Strip trailing whitespace/newlines from failure_section
    failure_section = failure_section.rstrip()

    # Build the restructured text
    result = before_try
    result += 'BEGIN\n'  # was BEGIN TRY
    result += try_body
    result += '\n'
    result += success_section.rstrip() + '\n'
    result += '\n  EXCEPTION WHEN OTHERS THEN\n'
    if catch_comment:
        result += '  ' + catch_comment + '\n\n'
    result += failure_section + '\n'
    result += '\n'

    return result


# ---------------------------------------------------------------------------
# EXECUTE / EXEC -> CALL
# ---------------------------------------------------------------------------

def _convert_execute_calls(text: str) -> str:
    """Convert EXECUTE/EXEC stored proc calls to PL/pgSQL CALL statements.

    Handles:
      - EXECUTE schema.[dbo].[proc] @p1 = @v1, @p2 = @v2 OUTPUT;
        -> CALL schema.proc(v1, INOUT v2);
      - EXEC schema.[dbo].[proc] @p1 = @v1, @p2 = @v2, ...;
        -> CALL schema.proc(v1, v2, ...);
    """
    def _replace_execute(m: re.Match) -> str:
        proc_ref = m.group(1).strip()
        params_raw = m.group(2).strip() if m.group(2) else ''

        # Convert proc reference to schema.proc_name
        proc_ref = _normalize_proc_ref(proc_ref)

        # Parse named parameters
        if params_raw:
            args = _convert_exec_params(params_raw)
        else:
            args = ''

        return f"CALL {proc_ref}({args});"

    # Match EXECUTE or EXEC followed by proc reference and optional params
    text = re.sub(
        r'(?i)\b(?:EXECUTE|EXEC)\s+([\[\]\w.]+)\s*((?:@\w+\s*=\s*@?\w+(?:\s+OUTPUT)?'
        r'(?:\s*,\s*@\w+\s*=\s*@?\w+(?:\s+OUTPUT)?)*)?)\s*;',
        _replace_execute,
        text,
    )
    return text


def _normalize_proc_ref(proc_ref: str) -> str:
    """Convert ANFC_META.[dbo].[proc_name] -> anfc_meta.proc_name."""
    # Remove dbo component
    proc_ref = re.sub(r'(?i)\.\[?dbo\]?\.', '.', proc_ref)
    # Remove brackets
    proc_ref = re.sub(r'[\[\]]', '', proc_ref)
    # Lowercase
    parts = proc_ref.split('.')
    if len(parts) >= 2:
        return f"{parts[0].lower()}.{parts[-1].lower()}"
    return proc_ref.lower()


def _convert_exec_params(params_raw: str) -> str:
    """Convert named T-SQL params to positional PL/pgSQL args.

    @param1 = @value1, @param2 = @value2 OUTPUT
    -> value1, value2
    INOUT is specified in the procedure definition, not at the call site.
    """
    args = []
    # Split by comma, but handle each named param
    param_parts = re.split(r',\s*(?=@)', params_raw)
    for part in param_parts:
        part = part.strip()
        # @name = @value OUTPUT  or  @name = @value
        m = re.match(r'@\w+\s*=\s*@(\w+)\s*(?:OUTPUT)?', part.strip(), re.IGNORECASE)
        if m:
            val = m.group(1)
            args.append(val)
        else:
            # @name = literal_value
            m2 = re.match(r'@\w+\s*=\s*(.+?)(?:\s+OUTPUT)?$', part.strip(), re.IGNORECASE)
            if m2:
                args.append(m2.group(1).strip())
            else:
                args.append(part.strip())
    return ', '.join(args)


# ---------------------------------------------------------------------------
# PRINT -> RAISE NOTICE
# ---------------------------------------------------------------------------

def _convert_print_statements(text: str) -> str:
    """Convert PRINT message -> RAISE NOTICE message.

    Strategy: Parse the PRINT argument into string literals and non-literal parts.
    String literals are embedded into the format string; variable/expression parts
    become % placeholders with the expression as an argument.

    The PRINT argument may contain string concat (+) which will be converted
    to || by convert_dml afterwards. Here we just build the RAISE NOTICE form.

    Example:
        PRINT 'End Failed ' + @component + ' ' + (CONVERT(varchar(24), GETDATE(), 121));
    ->
        RAISE NOTICE 'End Failed % % %', component, ' ', CONVERT(varchar(24), GETDATE(), 121);
    (then convert_dml will convert GETDATE and CONVERT to PostgreSQL equivalents)

    Simpler approach: replace PRINT with RAISE NOTICE and build %/args from parts.
    """
    def _replace_print(m: re.Match) -> str:
        msg_raw = m.group(1).strip()

        # Split on + operator (respecting string literals and parens)
        parts = _split_print_parts(msg_raw)

        format_parts = []
        arg_parts = []
        for part in parts:
            part = part.strip()
            # Only strip outer parens if the part is ENTIRELY wrapped in parens
            # (e.g. (CONVERT(...)) -> CONVERT(...)) — do NOT strip if parens are internal
            if part.startswith('(') and part.endswith(')') and _is_fully_wrapped(part):
                part = part[1:-1].strip()
            if not part:
                continue
            if part.startswith("'") and part.endswith("'"):
                # String literal — embed in format string
                inner = part[1:-1]
                format_parts.append(inner)
            elif re.match(r'^@?\w+$', part):
                # Simple variable reference
                var_name = re.sub(r'^@', '', part)
                format_parts.append('%')
                arg_parts.append(var_name)
            else:
                # Complex expression (function call etc.)
                format_parts.append('%')
                # Remove @ from var references in expression
                expr = re.sub(r'@(\w+)', r'\1', part)
                arg_parts.append(expr)

        fmt = ''.join(format_parts)
        if arg_parts:
            return f"RAISE NOTICE '{fmt}', {', '.join(arg_parts)};"
        return f"RAISE NOTICE '{fmt}';"

    return re.sub(
        r'(?i)\bPRINT\s+(.+?);',
        _replace_print,
        text,
    )


def _is_fully_wrapped(text: str) -> bool:
    """Return True if the text is fully wrapped in one pair of outer parentheses.

    For example: '(CONVERT(a, b))' -> True
                 '(a) + (b)'       -> False  (parens do not wrap the entire string)
    """
    if not (text.startswith('(') and text.endswith(')')):
        return False
    depth = 0
    for i, ch in enumerate(text):
        if ch == '(':
            depth += 1
        elif ch == ')':
            depth -= 1
            if depth == 0 and i < len(text) - 1:
                # Closing paren found before end — not fully wrapped
                return False
    return depth == 0


def _split_print_parts(text: str) -> List[str]:
    """Split a PRINT message string on + operators, respecting string literals and parens."""
    parts = []
    current = ''
    depth = 0
    in_string = False
    i = 0
    while i < len(text):
        ch = text[i]
        if ch == "'" and not in_string:
            in_string = True
            current += ch
        elif ch == "'" and in_string:
            # Check for escaped quote ''
            if i + 1 < len(text) and text[i + 1] == "'":
                current += "''"
                i += 2
                continue
            in_string = False
            current += ch
        elif ch == '(' and not in_string:
            depth += 1
            current += ch
        elif ch == ')' and not in_string:
            depth -= 1
            current += ch
        elif ch == '+' and not in_string and depth == 0:
            parts.append(current.strip())
            current = ''
        else:
            current += ch
        i += 1
    if current.strip():
        parts.append(current.strip())
    return parts


# ---------------------------------------------------------------------------
# Standalone SELECTs -> PERFORM
# ---------------------------------------------------------------------------

def _convert_standalone_selects(text: str) -> str:
    """Convert standalone SELECT statements (not INTO, not subquery, not INSERT) to PERFORM.

    In PL/pgSQL, a SELECT without INTO inside a procedure body is invalid.
    Standalone SELECTs whose results are discarded must use PERFORM.

    Only converts SELECTs that are:
    - At statement level (not inside parentheses / subqueries)
    - Not followed by INTO (already handled)
    - Not part of INSERT INTO ... SELECT
    - Not part of CREATE TABLE ... AS SELECT
    - Not preceded by UNION/UNION ALL (part of a compound query)

    Example:
        SELECT MAX(batch_id) FROM anfc_meta.batch WHERE batch_name = 'rencoa_us';
    ->  PERFORM MAX(batch_id) FROM anfc_meta.batch WHERE batch_name = 'rencoa_us';
    """
    lines = text.split('\n')
    result_lines = []
    i = 0
    paren_depth = 0

    while i < len(lines):
        line = lines[i]
        stripped = line.strip()

        # Track parenthesis depth (to skip subquery SELECTs)
        for ch in line:
            if ch == '(':
                paren_depth += 1
            elif ch == ')':
                paren_depth -= 1

        # Only convert at statement level (depth 0)
        if paren_depth == 0 and re.match(r'(?i)^\s*SELECT\b', line):
            # Check it's not a SELECT INTO (variable or table)
            # Look at this line and subsequent lines for INTO keyword before FROM
            is_select_into = False
            is_insert_select = False
            is_create_as_select = False

            # Check if the IMMEDIATELY preceding non-empty, non-comment line
            # ends with a pattern that means this SELECT is a continuation
            # (INSERT INTO ... SELECT, CREATE TABLE ... AS SELECT, UNION SELECT)
            for j in range(len(result_lines) - 1, -1, -1):
                prev = result_lines[j].strip()
                if not prev or prev.startswith('--'):
                    continue
                # Only match if the previous statement hasn't ended (no semicolon)
                if prev.endswith(';'):
                    break  # Previous statement is complete; this is a new statement
                if re.search(r'(?i)\bINSERT\s+INTO\b', prev):
                    is_insert_select = True
                if re.search(r'(?i)\bAS\s*$', prev):
                    is_create_as_select = True
                break

            # Check if this SELECT line itself contains INTO
            if re.search(r'(?i)\bSELECT\b.*\bINTO\b', line):
                is_select_into = True

            # Look ahead for INTO before FROM on subsequent lines
            if not is_select_into:
                for k in range(i + 1, min(i + 10, len(lines))):
                    next_stripped = lines[k].strip()
                    if re.match(r'(?i)INTO\b', next_stripped):
                        is_select_into = True
                        break
                    if re.match(r'(?i)FROM\b', next_stripped):
                        break

            # Also check if previous line has UNION
            if len(result_lines) > 0:
                prev_stripped = result_lines[-1].strip()
                if re.match(r'(?i)UNION(\s+ALL)?\s*$', prev_stripped):
                    is_insert_select = True  # part of compound query, don't convert

            if not is_select_into and not is_insert_select and not is_create_as_select:
                # This is a standalone SELECT — convert to PERFORM
                line = re.sub(r'(?i)\bSELECT\b', 'PERFORM', line, count=1)

        result_lines.append(line)
        i += 1

    return '\n'.join(result_lines)


# ---------------------------------------------------------------------------
# Procedure end
# ---------------------------------------------------------------------------

def _convert_procedure_end(text: str) -> str:
    """Replace END; GO with END; $$ LANGUAGE plpgsql;"""
    text = re.sub(r'(?i)\bEND\s*;\s*\n?\s*GO\b', 'END;\n$$ LANGUAGE plpgsql;', text)
    return text


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

def main() -> None:
    """Test procedure conversion with a simplified sample.

    This sample exercises the key enhancements:
    - LANGUAGE plpgsql appears only once (at footer)
    - process_log_id is declared in DECLARE block
    - BEGIN TRY / END TRY restructured as BEGIN / EXCEPTION WHEN OTHERS THEN
    - Standalone SELECT uses PERFORM
    - Success and failure paths are mutually exclusive (inside BEGIN/EXCEPTION)
    """
    sample = """\
CREATE PROCEDURE [dbo].[sp_agg_email_universe] (@rencoa_us_include_flg char(10) = 'N',@debug INTEGER = 0)
AS
BEGIN
  SET NOCOUNT ON;

  DECLARE @component nvarchar(100),
          @process_name char(50) = 'sp_agg_email_universe',
          @v_insert_row_count integer = 0,
          -- Error handling variables
          ,
          @error_number int,
          @error_message nvarchar(2046);

  SELECT
    @process_id = p.PROCESS_ID
  FROM ANFC_META.dbo.process p
  WHERE p.PROCESS_NAME = @process_name;

  EXECUTE ANFC_META.[dbo].[ops_begin_process_log] @process_name = @process_name,
                                                 @process_log_id = @process_log_id OUTPUT;

  BEGIN TRY
    SELECT MAX(batch_id) FROM ANFC_META..BATCH WHERE batch_name = 'rencoa_us';
  END TRY;
  /*BEGIN CATCH
    SET @error_number = ERROR_NUMBER()
    SET @error_message = ERROR_MESSAGE()
    GOTO HANDLE_ERROR
  END CATCH*/

  SET @process_log_status = 'Succeeded';
  SET @process_log_status_message = @component + ' for ' + @v_tgt_table + ' ' + @process_log_status;

  EXEC ANFC_META.[dbo].[ops_end_process_log] @process_log_id = @process_log_id,
                                            @INSERTED_ROWS = @v_insert_row_count,
                                            @STATUS = @process_log_status;

  -- Error Handler
  --RETURN;
--HANDLE_ERROR:

  SET @process_log_status = 'Failed';
  SET @process_log_status_message = @component + ' for ' + @v_tgt_table + ' ' + @process_log_status;

  EXECUTE ANFC_META.dbo.ops_end_process_log @process_log_id = @process_log_id,
                                           @INSERTED_ROWS = @v_insert_row_count,
                                           @STATUS = @process_log_status;

  PRINT 'End Failed ' + @component + ' ' + 'test';
  --RAISERROR (@error_message, 16, 1)

END;
GO
"""
    result = convert(sample)
    print("=== Procedure Conversion Result ===")
    print(result)

    # Assertions
    assert 'CREATE OR REPLACE PROCEDURE sp_agg_email_universe' in result, "Proc header not converted"
    assert '$$' in result, "$$ delimiter missing"
    assert 'SET NOCOUNT ON' not in result, "SET NOCOUNT ON not removed"
    assert 'DECLARE' in result, "DECLARE block missing"
    assert 'row_count INTEGER' in result, "row_count not added to DECLARE"
    assert 'process_log_id BIGINT' in result, "process_log_id not declared"
    assert 'SELECT p.PROCESS_ID INTO process_id' in result, "SELECT @var= not converted"
    assert 'CALL anfc_meta.ops_begin_process_log(' in result, "EXECUTE not converted to CALL"
    assert 'INOUT' not in result, "INOUT should not appear at CALL site"
    assert 'BEGIN TRY' not in result, "BEGIN TRY not converted"
    assert 'END TRY' not in result, "END TRY not removed"
    assert 'RAISE NOTICE' in result, "PRINT not converted"
    assert '$$ LANGUAGE plpgsql;' in result, "Procedure end not converted"

    # PROC-ENH-3: LANGUAGE plpgsql should appear exactly once
    lang_count = result.count('LANGUAGE plpgsql')
    assert lang_count == 1, f"LANGUAGE plpgsql should appear once, found {lang_count} times"

    # PROC-ENH-6: Standalone SELECT should be PERFORM
    assert 'PERFORM MAX(batch_id)' in result, "Standalone SELECT not converted to PERFORM"

    # PROC-ENH-7: EXCEPTION WHEN OTHERS THEN present
    assert 'EXCEPTION WHEN OTHERS THEN' in result, "TRY/CATCH not converted to EXCEPTION"

    # PROC-ENH-7: Success and failure mutually exclusive
    # Success ('Succeeded') should appear BEFORE EXCEPTION
    # Failure ('Failed') should appear AFTER EXCEPTION
    exception_pos = result.find('EXCEPTION WHEN OTHERS THEN')
    succeeded_pos = result.find("'Succeeded'")
    failed_pos = result.find("'Failed'")
    assert succeeded_pos < exception_pos, "Success path should be before EXCEPTION"
    assert failed_pos > exception_pos, "Failure path should be after EXCEPTION"

    # PROC-ENH-2: ops_end_process_log should NOT have INOUT (no OUTPUT params)
    end_log_calls = [line for line in result.split('\n') if 'ops_end_process_log' in line]
    for call in end_log_calls:
        assert 'INOUT' not in call, f"ops_end_process_log should not have INOUT: {call}"

    print("\nconvert_procedures.py: ALL ASSERTIONS PASSED")


if __name__ == "__main__":
    main()
