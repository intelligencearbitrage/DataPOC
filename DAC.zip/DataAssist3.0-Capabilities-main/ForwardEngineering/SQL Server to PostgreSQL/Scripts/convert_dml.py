"""
convert_dml.py — Convert T-SQL DML expressions to PostgreSQL equivalents.

Handles:
  - CAST(GETDATE() AS DATE) -> CURRENT_DATE
  - CONVERT(varchar(24), GETDATE(), 121) -> TO_CHAR(NOW(), 'YYYY-MM-DD HH24:MI:SS.MS')
  - GETDATE() -> NOW()
  - ISNULL(expr, default) -> COALESCE(expr, default)
  - DATEDIFF(year, start, end) -> DATE_PART('year', AGE(end, start))
  - YEAR(expr) -> EXTRACT(YEAR FROM expr)
  - Cross-DB refs: DB.dbo.table, DB.[dbo].[table], DB..table -> schema.table (lowercase)
  - [bracket_identifier] -> plain_identifier
  - [col] = 'value' assignment alias -> 'value' AS col
  - table.col(alias) function-call-style alias -> table.col AS alias
  - String concatenation with + -> ||
  - @@ROWCOUNT accumulation pattern -> GET DIAGNOSTICS + variable assignment
  - @variable references -> variable (in procedure context)
  - @process_log_id -> NULL with comment (in standalone context)
  - SELECT ... INTO #tablename -> CREATE TEMP TABLE + INSERT INTO
  - SELECT ... INTO schema.table -> INSERT INTO schema.table (cols) SELECT
  - Incomplete INSERT INTO #table; -> comment

Usage:
    from convert_dml import convert
    converted = convert(sql_text, context='procedure')
    converted = convert(sql_text, context='standalone')
"""

import re
from typing import Optional


def convert(text: str, context: str = 'procedure') -> str:
    """Apply all DML conversions to the given SQL text.

    Args:
        text: SQL text string.
        context: 'procedure' — @variables are procedure-local variables.
                 'standalone' — @variables are undefined; @process_log_id becomes NULL.

    Returns:
        SQL text with all DML patterns converted to PostgreSQL equivalents.
    """
    # @@ROWCOUNT pattern must run FIRST (before general @var stripping and SET conversion)
    text = _convert_rowcount_pattern(text)
    text = _convert_cast_getdate_as_date(text)
    text = _convert_convert_getdate_121(text)
    text = _convert_getdate(text)
    text = _convert_isnull(text)
    text = _convert_datediff_year(text)
    text = _convert_year(text)
    text = _convert_cross_db_three_part(text)
    text = _convert_cross_db_two_dot(text)
    text = _convert_select_into_cross_db(text)
    text = _convert_select_into_temp(text)
    text = _convert_incomplete_insert(text)
    text = _convert_temp_table_refs(text)
    text = _convert_assignment_alias(text)
    text = _convert_func_call_alias(text)
    text = _convert_bracket_identifiers(text)
    text = _convert_string_concat(text)
    if context == 'standalone':
        text = _convert_standalone_variables(text)
    else:
        text = _convert_at_variables(text)
    return text


# ---------------------------------------------------------------------------
# Date / time functions
# ---------------------------------------------------------------------------

def _convert_cast_getdate_as_date(text: str) -> str:
    """CAST(GETDATE() AS DATE) -> CURRENT_DATE (run before generic GETDATE)."""
    return re.sub(
        r'(?i)CAST\s*\(\s*GETDATE\s*\(\s*\)\s+AS\s+DATE\s*\)',
        'CURRENT_DATE',
        text,
    )


def _convert_convert_getdate_121(text: str) -> str:
    """CONVERT(varchar(24), GETDATE(), 121) -> TO_CHAR(NOW(), 'YYYY-MM-DD HH24:MI:SS.MS').

    Also handles the case where GETDATE() was already converted to NOW() by a prior pass
    (e.g. when convert_dml is called after convert_procedures which may have already
    processed some GETDATE references).
    """
    # Match with GETDATE() still in place
    text = re.sub(
        r'(?i)CONVERT\s*\(\s*varchar\s*\(\s*24\s*\)\s*,\s*GETDATE\s*\(\s*\)\s*,\s*121\s*\)',
        "TO_CHAR(NOW(), 'YYYY-MM-DD HH24:MI:SS.MS')",
        text,
    )
    # Also match when GETDATE() was already converted to NOW()
    text = re.sub(
        r'(?i)CONVERT\s*\(\s*varchar\s*\(\s*24\s*\)\s*,\s*NOW\s*\(\s*\)\s*,\s*121\s*\)?',
        "TO_CHAR(NOW(), 'YYYY-MM-DD HH24:MI:SS.MS')",
        text,
    )
    return text


def _convert_getdate(text: str) -> str:
    """GETDATE() -> NOW()."""
    return re.sub(r'(?i)\bGETDATE\s*\(\s*\)', 'NOW()', text)


def _convert_datediff_year(text: str) -> str:
    """DATEDIFF(year, start_expr, end_expr) -> (EXTRACT(YEAR FROM end_expr) - EXTRACT(YEAR FROM start_expr)).

    T-SQL DATEDIFF(year, start, end) counts year BOUNDARY crossings, which is equivalent
    to YEAR(end) - YEAR(start). For example:
      DATEDIFF(year, '2023-12-31', '2024-01-01') = 1  (crossed year boundary)

    The previous approach using DATE_PART('year', AGE(end, start)) was incorrect because
    AGE computes complete calendar years (returns 0 for the example above).

    Uses a balanced-parenthesis aware approach to correctly parse nested expressions.
    """
    result = []
    i = 0
    pattern = re.compile(r'(?i)\bDATEDIFF\s*\(\s*year\s*,\s*')
    while i < len(text):
        m = pattern.search(text, i)
        if not m:
            result.append(text[i:])
            break
        result.append(text[i:m.start()])
        # Parse start argument (balanced parens)
        pos = m.end()
        start_arg, pos = _extract_arg(text, pos)
        # Skip comma and whitespace
        if pos < len(text) and text[pos] == ',':
            pos += 1
        while pos < len(text) and text[pos] in ' \t':
            pos += 1
        # Parse end argument (balanced parens up to closing ')')
        end_arg, pos = _extract_arg(text, pos)
        # Skip closing paren
        if pos < len(text) and text[pos] == ')':
            pos += 1
        result.append(f"(EXTRACT(YEAR FROM {end_arg.strip()}) - EXTRACT(YEAR FROM {start_arg.strip()}))")
        i = pos
    return ''.join(result)


def _extract_arg(text: str, start: int) -> tuple:
    """Extract one SQL argument starting at position start, respecting balanced parens.

    Returns (arg_text, new_position).
    """
    depth = 0
    i = start
    while i < len(text):
        ch = text[i]
        if ch == '(':
            depth += 1
        elif ch == ')':
            if depth == 0:
                # End of enclosing call
                return text[start:i], i
            depth -= 1
        elif ch == ',' and depth == 0:
            return text[start:i], i
        i += 1
    return text[start:i], i


def _convert_year(text: str) -> str:
    """YEAR(expr) -> EXTRACT(YEAR FROM expr)."""
    return re.sub(
        r'(?i)\bYEAR\s*\(([^)]+)\)',
        lambda m: f"EXTRACT(YEAR FROM {m.group(1)})",
        text,
    )


# ---------------------------------------------------------------------------
# NULL handling
# ---------------------------------------------------------------------------

def _convert_isnull(text: str) -> str:
    """ISNULL(expr, default) -> COALESCE(expr, default)."""
    return re.sub(r'(?i)\bISNULL\s*\(', 'COALESCE(', text)


# ---------------------------------------------------------------------------
# Cross-database references
# ---------------------------------------------------------------------------

def _convert_cross_db_three_part(text: str) -> str:
    """Convert DB.dbo.table and DB.[dbo].[table] -> lowercase_schema.lowercase_table."""

    def _replace(m: re.Match) -> str:
        db = m.group(1).lower()
        table = m.group(2).lower()
        return f"{db}.{table}"

    # Pattern: WORD.[dbo].[WORD] or WORD.dbo.WORD (with optional brackets)
    return re.sub(
        r'(?i)\b(\w+)\.\[?dbo\]?\.\[?(\w+)\]?',
        _replace,
        text,
    )


def _convert_cross_db_two_dot(text: str) -> str:
    """Convert DB..table -> lowercase_schema.lowercase_table."""

    def _replace(m: re.Match) -> str:
        db = m.group(1).lower()
        table = m.group(2).lower()
        return f"{db}.{table}"

    # Pattern: WORD..WORD (two consecutive dots)
    return re.sub(
        r'(?i)\b(\w+)\.\.(\w+)',
        _replace,
        text,
    )


# ---------------------------------------------------------------------------
# @@ROWCOUNT
# ---------------------------------------------------------------------------

def _convert_rowcount_pattern(text: str) -> str:
    """Convert the @@ROWCOUNT accumulation pattern to GET DIAGNOSTICS.

    Converts either form (pre or post convert_procedures):
        SET @v_insert_row_count = @v_insert_row_count + @@ROWCOUNT ;
        v_insert_row_count := v_insert_row_count + @@ROWCOUNT;
    To:
        GET DIAGNOSTICS row_count = ROW_COUNT;
        v_insert_row_count := v_insert_row_count + row_count;

    Two patterns are matched to handle pipeline ordering: convert_procedures may run
    before convert_dml and transform SET @var = ... to var := ... first.
    """
    # Pre-convert_procedures form: SET @v_insert_row_count = @v_insert_row_count + @@ROWCOUNT;
    text = re.sub(
        r'(?i)\s*SET\s+@v_insert_row_count\s*=\s*@v_insert_row_count\s*\+\s*@@ROWCOUNT\s*;',
        '\n    GET DIAGNOSTICS row_count = ROW_COUNT;\n    v_insert_row_count := v_insert_row_count + row_count;',
        text,
    )
    # Post-convert_procedures form: v_insert_row_count := v_insert_row_count + @@ROWCOUNT;
    # Also handle @ROWCOUNT (single @) since convert_procedures strips one @ from @@ROWCOUNT
    text = re.sub(
        r'(?i)\s*v_insert_row_count\s*:=\s*v_insert_row_count\s*\+\s*@@?ROWCOUNT\s*;',
        '\n    GET DIAGNOSTICS row_count = ROW_COUNT;\n    v_insert_row_count := v_insert_row_count + row_count;',
        text,
    )
    # Also handle any remaining @@ROWCOUNT or @ROWCOUNT references
    # (convert_procedures may strip one @ from @@ROWCOUNT -> @ROWCOUNT)
    text = re.sub(r'@@ROWCOUNT', 'row_count', text, flags=re.IGNORECASE)
    text = re.sub(r'@ROWCOUNT', 'row_count', text, flags=re.IGNORECASE)
    return text


# ---------------------------------------------------------------------------
# SELECT INTO handling
# ---------------------------------------------------------------------------

def _convert_select_into_cross_db(text: str) -> str:
    """Convert SELECT col1, col2 INTO schema.table FROM (subquery) alias;
    -> CREATE TABLE schema.table AS SELECT col1, col2 FROM (subquery) alias;

    Handles the OPS_EMAIL_UNIVERSE SELECT...INTO pattern in the SP file.
    The SELECT...INTO target must be a schema.table reference (contains a dot, no # prefix).

    Uses CREATE TABLE AS SELECT instead of INSERT INTO because the preceding
    DROP TABLE IF EXISTS removes the table, so INSERT would fail on a non-existent table.
    CREATE TABLE AS SELECT both creates the table and populates it in one step.

    Handles multiline format:
        SELECT
            EMAIL_KEY,
            BRAND_CD
        INTO
            schema.table
        FROM
        (...)
    """
    def _replace(m: re.Match) -> str:
        indent = m.group(1)
        col_block = m.group(2)
        schema_table = m.group(3).strip()
        from_rest = m.group(4)
        return (
            f"CREATE TABLE {schema_table} AS\n"
            f"{indent}SELECT\n"
            f"{col_block}"
            f"{from_rest}"
        )

    # Instead of a single complex regex that can cause catastrophic backtracking,
    # use a two-step approach: find SELECT...INTO...FROM boundaries with simpler patterns
    # Step 1: Find all SELECT\ncolumns\nINTO\nschema.table\nFROM blocks
    # The key marker is the INTO keyword on its own line between SELECT block and FROM.
    into_pattern = re.compile(r'(?im)^([ \t]*)INTO\s*\n[ \t]+((?:\w+\.)+\w+)\s*\n([ \t]*FROM\s*\n)')
    offset = 0
    result_parts = []
    for m in into_pattern.finditer(text):
        into_pos = m.start()
        # Walk backwards from INTO to find the matching SELECT
        # Look for a line that starts with SELECT (with optional indent)
        preceding = text[offset:into_pos]
        select_match = None
        for sm in re.finditer(r'(?im)^([ \t]*)SELECT\s*\n', preceding):
            select_match = sm  # take the last SELECT before INTO
        if select_match is None:
            continue
        select_pos = offset + select_match.start()
        indent = select_match.group(1)
        col_block = text[offset + select_match.end():into_pos]
        schema_table = m.group(2).strip()
        from_line = m.group(3)

        # Emit text before this SELECT unchanged
        result_parts.append(text[offset:select_pos])
        # Emit the replacement
        result_parts.append(
            f"CREATE TABLE {schema_table} AS\n"
            f"{indent}SELECT\n"
            f"{col_block}"
            f"{from_line}"
        )
        offset = m.end()

    result_parts.append(text[offset:])
    return ''.join(result_parts)


def _convert_select_into_temp(text: str) -> str:
    """Convert SELECT DISTINCT ... INTO #tablename FROM ... -> CREATE TEMP TABLE + INSERT INTO.

    Specifically handles:
        SELECT DISTINCT CAST(batch_id AS BIGINT) AS batch_id INTO #batches FROM ... WHERE ...;
    ->
        CREATE TEMP TABLE batches (batch_id BIGINT);
        INSERT INTO batches SELECT DISTINCT CAST(batch_id AS BIGINT) AS batch_id FROM ... WHERE ...;
    """
    def _replace_select_into_temp(m: re.Match) -> str:
        distinct_kw = m.group(1).strip()
        col_expr = m.group(2).strip()
        table_name = m.group(3).strip()
        from_clause = m.group(4).strip()
        return (
            f"CREATE TEMP TABLE {table_name} (batch_id BIGINT);\n\t"
            f"INSERT INTO {table_name} "
            f"SELECT {distinct_kw} {col_expr} FROM {from_clause};"
        )

    text = re.sub(
        r'(?i)\bSELECT\s+(DISTINCT\s+)(.*?)\s+INTO\s+#(\w+)\s+FROM\s+(.*?);',
        _replace_select_into_temp,
        text,
        flags=re.DOTALL,
    )
    return text


def _convert_incomplete_insert(text: str) -> str:
    """Convert bare 'INSERT INTO #table;' (no VALUES/SELECT) -> comment."""
    def _replace(m: re.Match) -> str:
        table_name = m.group(1).strip()
        return f"-- INCOMPLETE: INSERT INTO {table_name}; (no source data specified)"

    return re.sub(
        r'(?i)\bINSERT\s+INTO\s+#(\w+)\s*;',
        _replace,
        text,
    )


# ---------------------------------------------------------------------------
# Column alias patterns
# ---------------------------------------------------------------------------

def _convert_assignment_alias(text: str) -> str:
    """Convert [col] = 'value' assignment-style alias -> 'value' AS col.

    Example:
        [social_tourist_flag] = 'N'  ->  'N' AS social_tourist_flag
    """
    def _replace(m: re.Match) -> str:
        col_name = m.group(1)
        value = m.group(2)
        return f"{value} AS {col_name}"

    return re.sub(
        r"\[(\w+)\]\s*=\s*('(?:[^']|'')*')",
        _replace,
        text,
    )


def _convert_func_call_alias(text: str) -> str:
    """Convert table.col(alias_name) function-call-style alias -> table.col AS alias_name.

    Example:
        adb.date_of_birth(date_of_birth) as date_of_birth_key
          -> adb.date_of_birth AS date_of_birth_key
        addr.addr_line_3_text(addr_line_3_text) addr_line_3_text
          -> addr.addr_line_3_text AS addr_line_3_text

    When source has:  table.col(paren_alias) [AS] sql_alias
    - If sql_alias present: use sql_alias (drop paren_alias entirely)
    - If no sql_alias: use paren_alias

    Only matches when preceded by a qualified table.column reference (word.word).
    Does not match standalone function calls like COALESCE(...) or NOW().

    Uses three sequential patterns (most specific first) to avoid regex ambiguity:
    Pattern A: table.col(alias) AS sql_alias  (explicit AS)
    Pattern B: table.col(alias) sql_alias     (bare alias, not a keyword)
    Pattern C: table.col(alias)               (no trailing alias, followed by comma/newline/end)
    """
    # SQL keywords that should NOT be treated as a bare alias after table.col(alias)
    _sql_keywords = {
        'from', 'where', 'join', 'on', 'and', 'or', 'left', 'right', 'inner',
        'outer', 'cross', 'full', 'union', 'group', 'order', 'having', 'limit',
        'into', 'select', 'insert', 'update', 'delete', 'set', 'case', 'when',
        'then', 'else', 'end', 'as', 'in', 'not', 'is', 'null', 'between',
        'like', 'exists', 'all', 'any', 'distinct',
    }

    # Pattern A: table.col(alias) AS sql_alias
    def _replace_with_as(m: re.Match) -> str:
        col_ref = m.group(1)
        sql_alias = m.group(3)
        return f"{col_ref} AS {sql_alias}"

    text = re.sub(
        r'\b(\w+\.\w+)\((\w+)\)\s+[Aa][Ss]\s+(\w+)',
        _replace_with_as,
        text,
    )

    # Pattern B: table.col(alias) bare_alias (no AS keyword; bare_alias is NOT a SQL keyword)
    def _replace_bare_alias(m: re.Match) -> str:
        col_ref = m.group(1)
        paren_alias = m.group(2)
        bare_alias = m.group(3)
        if bare_alias.lower() in _sql_keywords:
            # Not a real alias — this is a SQL keyword following a function call
            # Return unchanged (don't convert — it's a real function like schema.func(arg) FROM ...)
            return m.group(0)
        return f"{col_ref} AS {bare_alias}"

    text = re.sub(
        r'\b(\w+\.\w+)\((\w+)\)\s+(\w+)',
        _replace_bare_alias,
        text,
    )

    # Pattern C: table.col(alias) followed by comma, newline, or end — no trailing alias
    def _replace_no_alias(m: re.Match) -> str:
        col_ref = m.group(1)
        paren_alias = m.group(2)
        return f"{col_ref} AS {paren_alias}"

    text = re.sub(
        r'\b(\w+\.\w+)\((\w+)\)(?=\s*[,\n;)]|\s*$)',
        _replace_no_alias,
        text,
    )

    return text


# ---------------------------------------------------------------------------
# Bracket identifiers
# ---------------------------------------------------------------------------

def _convert_temp_table_refs(text: str) -> str:
    """Convert #tablename references (not DDL, those handled by convert_ddl) to tablename.

    After CREATE TEMP TABLE conversion by convert_ddl, any remaining #name references
    in FROM clauses, IN subqueries, etc. need the # stripped.
    """
    return re.sub(r'#(\w+)', r'\1', text)


def _convert_bracket_identifiers(text: str) -> str:
    """Convert [bracket_identifier] -> plain_identifier.

    Removes square brackets from SQL identifiers. After cross-DB ref conversion,
    most bracket usages are standalone column/table names.
    Uses plain name (no double-quotes) since all identifiers in the source are
    valid PostgreSQL identifiers.
    """
    return re.sub(r'\[(\w+)\]', r'\1', text)


# ---------------------------------------------------------------------------
# String concatenation
# ---------------------------------------------------------------------------

def _convert_string_concat(text: str) -> str:
    """Convert string + concatenation to || operator.

    Targets lines that contain known string concatenation patterns:
    - String literal + string literal
    - String literal + @variable (or plain variable after @ removal)
    - @variable + string literal
    Preserves arithmetic + expressions by only converting lines with string context.
    """
    lines = text.split('\n')
    result_lines = []
    for line in lines:
        # Only convert + to || on lines that have string concat context
        # Detection: line contains at least one string literal ('...') and a +
        # that is flanked by string/variable expressions
        if re.search(r"'[^']*'\s*\+|'\s*\+\s*'|\+\s*'[^']*'", line):
            # Replace + surrounded by string operands
            line = re.sub(
                r"('\s*)\+(\s*')",
                r"\1||\2",
                line,
            )
            # Replace remaining + between variables/strings on this line
            line = re.sub(
                r"(['\w\)]+)\s*\+\s*(['\w\(@])",
                lambda m: m.group(1) + ' || ' + m.group(2),
                line,
            )
        result_lines.append(line)
    return '\n'.join(result_lines)


# ---------------------------------------------------------------------------
# Variable references
# ---------------------------------------------------------------------------

def _convert_at_variables(text: str) -> str:
    """Remove @ prefix from variable references in procedure context."""
    return re.sub(r'@(\w+)', r'\1', text)


def _convert_standalone_variables(text: str) -> str:
    """In standalone context, convert undeclared @process_log_id -> NULL with comment.

    Any remaining @variable references in standalone context are also stripped of @.
    """
    # @process_log_id as col[,] -> NULL AS col,  -- comment
    # Capture optional trailing comma so it stays before the comment, not after.
    # Must run BEFORE the general @ stripping.
    text = re.sub(
        r'@process_log_id\s+as\s+(\w+)(,?)',
        lambda m: f"NULL AS {m.group(1)}{m.group(2)}  -- process_log_id not declared in standalone context",
        text,
        flags=re.IGNORECASE,
    )
    # Also handle case where ISNULL was already applied — shouldn't happen here but be safe
    # Strip remaining @ from any other variable references
    text = re.sub(r'@(\w+)', r'\1', text)
    return text


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

def main() -> None:
    """Test DML conversion with samples from both input files."""
    sample_procedure = """
SELECT
    CAST(GETDATE() AS DATE) as last_src_update_date_key,
    ISNULL(h.household_key,-1) as best_household_key,
    DATEDIFF(year, x.date_of_birth_key, GETDATE()) as age_calc,
    YEAR(x.date_of_birth_key) as birth_year,
    adb.date_of_birth(date_of_birth) as date_of_birth_key,
    addr.addr_line_3_text(addr_line_3_text) addr_line_3_text,
    [social_tourist_flag] = 'N',
    x.[dma_cd],
    x.[dma_experience_ind],
    GETDATE() as update_date,
    @process_log_id as create_process_log_id
FROM
    ANFC_ETL..ops_indiv_universe iu;

SELECT
    @process_id = p.PROCESS_ID
FROM ANFC_META.dbo.process p
WHERE p.PROCESS_NAME = @process_name;

    SET @v_insert_row_count = @v_insert_row_count + @@ROWCOUNT ;

PRINT 'End Failed ' + @component + ' ' + (CONVERT(varchar(24), GETDATE(), 121));
"""

    print("=== Procedure Context ===")
    result = convert(sample_procedure, context='procedure')
    print(result)

    sample_standalone = """
    @process_log_id as create_process_log_id,
    @process_log_id as update_process_log_id
"""
    print("\n=== Standalone Context ===")
    result_sa = convert(sample_standalone, context='standalone')
    print(result_sa)

    # Basic assertions
    assert 'NOW()' in result, "GETDATE() not converted"
    assert 'CURRENT_DATE' in result, "CAST(GETDATE() AS DATE) not converted"
    assert 'COALESCE(' in result, "ISNULL not converted"
    assert "EXTRACT(YEAR FROM" in result and "EXTRACT(YEAR FROM" in result, "DATEDIFF not converted to EXTRACT(YEAR FROM)"
    assert 'EXTRACT(YEAR FROM' in result, "YEAR() not converted"
    assert 'anfc_etl.ops_indiv_universe' in result, "Cross-DB .. ref not converted"
    assert 'anfc_meta.process' in result, "Cross-DB .dbo. ref not converted"
    assert "'N' AS social_tourist_flag" in result, "Assignment alias not converted"
    assert 'x.dma_cd' in result, "Bracket identifier not converted"
    assert 'date_of_birth AS date_of_birth_key' in result, "func-call alias not converted"
    assert 'GET DIAGNOSTICS row_count = ROW_COUNT' in result, "@@ROWCOUNT not converted"
    assert 'NULL AS create_process_log_id' in result_sa, "Standalone @var not converted"
    print("\nconvert_dml.py: ALL ASSERTIONS PASSED")


if __name__ == "__main__":
    main()
