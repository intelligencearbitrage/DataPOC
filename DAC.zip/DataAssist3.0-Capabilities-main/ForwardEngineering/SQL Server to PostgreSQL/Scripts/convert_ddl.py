"""
convert_ddl.py — Convert T-SQL/Snowflake DDL syntax to PostgreSQL DDL.

Handles:
  - NUMBER(p,s) -> NUMERIC(p,s)
  - nvarchar(n) -> VARCHAR(n), nvarchar(max) -> TEXT
  - COLLATE 'en-ci' -> COLLATE "en-US-x-icu"
  - CREATE TABLE #name -> CREATE TEMP TABLE name
  - create or replace TABLE -> CREATE TABLE IF NOT EXISTS
  - DROP TABLE [schema.table] -> DROP TABLE IF EXISTS [schema.table]

All inline comments are preserved verbatim.

Usage:
    from convert_ddl import convert
    converted_sql = convert(sql_text)
"""

import re
from typing import Optional


def convert(text: str) -> str:
    """Apply all DDL conversions to the given SQL text.

    Transformations are applied in a specific order to avoid partial replacements
    or conflicts between patterns.

    Args:
        text: SQL text string (may contain DDL, DML, or procedure body).

    Returns:
        SQL text with all DDL patterns converted to PostgreSQL equivalents.
    """
    text = _convert_number_type(text)
    text = _convert_nvarchar(text)
    text = _convert_collate(text)
    text = _convert_temp_table_ddl(text)
    text = _convert_create_or_replace(text)
    text = _convert_drop_table(text)
    return text


def _convert_number_type(text: str) -> str:
    """Convert NUMBER(p,s) -> NUMERIC(p,s) as a word-boundary replacement."""
    return re.sub(r'\bNUMBER\s*\(', 'NUMERIC(', text, flags=re.IGNORECASE)


def _convert_nvarchar(text: str) -> str:
    """Convert nvarchar(max) -> TEXT and nvarchar(n) -> VARCHAR(n)."""
    # nvarchar(max) first
    text = re.sub(r'\bnvarchar\s*\(\s*max\s*\)', 'TEXT', text, flags=re.IGNORECASE)
    # nvarchar(n)
    text = re.sub(r'\bnvarchar\s*\(', 'VARCHAR(', text, flags=re.IGNORECASE)
    return text


def _convert_collate(text: str) -> str:
    """Convert COLLATE 'en-ci' -> COLLATE "en-US-x-icu".

    Only converts when the COLLATE clause is explicitly present in the source.
    Does not add COLLATE where it was absent.
    """
    return re.sub(
        r"COLLATE\s+'en-ci'",
        'COLLATE "en-US-x-icu"',
        text,
        flags=re.IGNORECASE,
    )


def _convert_temp_table_ddl(text: str) -> str:
    """Convert CREATE TABLE #tablename -> CREATE TEMP TABLE tablename."""
    return re.sub(
        r'(?i)\bCREATE\s+TABLE\s+#(\w+)',
        r'CREATE TEMP TABLE \1',
        text,
    )


def _convert_create_or_replace(text: str) -> str:
    """Convert 'create or replace TABLE name' -> 'DROP TABLE IF EXISTS name; CREATE TABLE name'.

    The DROP+CREATE pattern faithfully preserves CREATE OR REPLACE semantics:
    the table is dropped if it exists, then recreated with the new definition.
    This is more correct than CREATE TABLE IF NOT EXISTS, which silently skips
    creation when the table already exists (potentially with a different schema).
    """
    def _replace(m: re.Match) -> str:
        table_name = m.group(1).strip()
        return f"DROP TABLE IF EXISTS {table_name};\nCREATE TABLE {table_name}"

    return re.sub(
        r'(?i)\bcreate\s+or\s+replace\s+TABLE\s+(\w+)',
        _replace,
        text,
    )


def _convert_drop_table(text: str) -> str:
    """Convert DROP TABLE -> DROP TABLE IF EXISTS (when IF EXISTS not already present)."""
    return re.sub(
        r'(?i)\bDROP\s+TABLE\s+(?!IF\s+EXISTS\s)',
        'DROP TABLE IF EXISTS ',
        text,
    )


def main() -> None:
    """Test DDL conversion with sample input."""
    sample = """
CREATE TABLE #email_dynamic_content_incre
(
  PROCESS_ID1 bigint,
  v_src_object_id1 DECIMAL(5,2),
  Name VARCHAR(50) NOT NULL,
  TIME_SERIES VARCHAR(50) COLLATE 'en-ci',
  v_src_table nvarchar(100)
);

create or replace TABLE CUSTOMER_HIST (
  CUSTOMER_HIST_KEY NUMBER(38,0),
  UC_LINK VARCHAR(7) NOT NULL COLLATE 'en-ci',
  LATITUDE NUMBER(9,6),
  description nvarchar(max)
);

DROP TABLE ANFC_ETL.dbo.OPS_EMAIL_UNIVERSE;
"""
    result = convert(sample)
    print("=== DDL Conversion Result ===")
    print(result)

    # Assertions
    assert 'NUMERIC(38,0)' in result, "NUMBER(38,0) not converted"
    assert 'NUMERIC(9,6)' in result, "NUMBER(9,6) not converted"
    assert 'COLLATE "en-US-x-icu"' in result, "COLLATE not converted"
    assert 'CREATE TEMP TABLE email_dynamic_content_incre' in result, "Temp table not converted"
    assert 'DROP TABLE IF EXISTS CUSTOMER_HIST' in result, "DROP TABLE IF EXISTS not added for create or replace"
    assert 'CREATE TABLE CUSTOMER_HIST' in result, "create or replace not converted to CREATE TABLE"
    assert 'CREATE TABLE IF NOT EXISTS' not in result, "Should use DROP+CREATE, not IF NOT EXISTS"
    assert 'DROP TABLE IF EXISTS' in result, "DROP TABLE IF EXISTS not added"
    assert 'TEXT' in result, "nvarchar(max) not converted to TEXT"
    print("\nconvert_ddl.py: ALL ASSERTIONS PASSED")


if __name__ == "__main__":
    main()
