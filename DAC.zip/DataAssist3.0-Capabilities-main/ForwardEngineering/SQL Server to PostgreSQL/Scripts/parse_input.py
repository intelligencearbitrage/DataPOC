"""
parse_input.py — Parse T-SQL / SQL Server .sql files into structured segments.

This module reads a .sql file, detects whether it is a stored procedure or
standalone DDL+DML, and returns a structured dict for downstream converters.

No transformations are performed here — pure structural analysis.

Usage:
    from parse_input import parse_file
    parsed = parse_file('/path/to/file.sql')
    # parsed['file_type'] in ('procedure', 'standalone')
    # parsed['raw_text'] — full original file content
"""

import re
import sys
from pathlib import Path
from typing import Dict, Any


def parse_file(filepath: str) -> Dict[str, Any]:
    """Parse a .sql file and return a structured representation.

    Args:
        filepath: Absolute or relative path to the .sql input file.

    Returns:
        A dict with keys:
            file_type (str): 'procedure' if file contains CREATE PROCEDURE,
                             'standalone' otherwise.
            raw_text (str): Full original file content (unmodified).
            input_path (str): The resolved filepath.
            segments (list): List of segment dicts; each has 'type' and 'content'.
                Segment types: 'procedure_header', 'declare_block', 'procedure_body',
                'standalone'.

    Raises:
        FileNotFoundError: If the file does not exist.
        IOError: If the file cannot be read.
    """
    path = Path(filepath)
    if not path.exists():
        raise FileNotFoundError(f"Input file not found: {filepath}")

    raw_text = path.read_text(encoding="utf-8")

    # Detect file type
    if re.search(r'(?i)\bCREATE\s+PROCEDURE\b', raw_text):
        file_type = "procedure"
        segments = _parse_procedure(raw_text)
    else:
        file_type = "standalone"
        segments = [{"type": "standalone", "content": raw_text}]

    return {
        "file_type": file_type,
        "raw_text": raw_text,
        "input_path": str(path.resolve()),
        "segments": segments,
    }


def _parse_procedure(text: str) -> list:
    """Extract procedure header, declare block, and body from T-SQL procedure text.

    Args:
        text: Full text of a T-SQL stored procedure file.

    Returns:
        List of segment dicts.
    """
    segments = []

    # Extract procedure header (CREATE PROCEDURE ... AS)
    header_match = re.search(
        r'(?i)(CREATE\s+PROCEDURE\s+.*?)(?=\bAS\b\s*\n?\s*BEGIN\b)',
        text,
        re.DOTALL,
    )
    if header_match:
        segments.append({
            "type": "procedure_header",
            "content": header_match.group(1).strip(),
        })

    # Extract DECLARE block — from first DECLARE to the end of the declare block
    # T-SQL DECLARE ends at the semicolon after the last declared variable
    declare_match = re.search(
        r'(?i)(DECLARE\s+@\w+.+?;)',
        text,
        re.DOTALL,
    )
    if declare_match:
        segments.append({
            "type": "declare_block",
            "content": declare_match.group(1).strip(),
        })

    # The procedure body is everything between AS BEGIN and the final END; GO
    body_match = re.search(
        r'(?i)AS\s*\n?\s*BEGIN\s*\n(.*?)END\s*;\s*\n?\s*GO',
        text,
        re.DOTALL,
    )
    if body_match:
        segments.append({
            "type": "procedure_body",
            "content": body_match.group(1),
        })
    else:
        # Fallback: body is everything after AS BEGIN
        body_fallback = re.search(r'(?i)AS\s*\n?\s*BEGIN\s*\n(.*)', text, re.DOTALL)
        if body_fallback:
            segments.append({
                "type": "procedure_body",
                "content": body_fallback.group(1),
            })

    return segments


def main() -> None:
    """Test parsing of both project input files."""
    project_root = Path(__file__).resolve().parent.parent.parent
    inputs_dir = project_root / "user-config" / "inputs"

    test_files = [
        inputs_dir / "SQLServer_SP.sql",
        inputs_dir / "SqlServer_Sample DML.sql",
    ]

    for filepath in test_files:
        print(f"\nParsing: {filepath.name}")
        try:
            result = parse_file(str(filepath))
            print(f"  file_type  : {result['file_type']}")
            print(f"  raw_text   : {len(result['raw_text'])} chars")
            print(f"  segments   : {[s['type'] for s in result['segments']]}")
        except FileNotFoundError as exc:
            print(f"  ERROR: {exc}")

    print("\nparse_input.py: OK")


if __name__ == "__main__":
    main()
