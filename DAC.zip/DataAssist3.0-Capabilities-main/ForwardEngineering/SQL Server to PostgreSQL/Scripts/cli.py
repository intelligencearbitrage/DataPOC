"""
cli.py — CLI entry point for the SQL Server to PostgreSQL converter.

Provides a unified command-line interface to run any or all converter scripts.

Usage:
    python agent-output/scripts/cli.py all
    python agent-output/scripts/cli.py generate_output
    python agent-output/scripts/cli.py --help

Commands:
    all               Run the full conversion pipeline (generate_output)
    generate_output   Run generate_output.py — converts both input files to PostgreSQL
    parse_input       Run parse_input.py standalone test
    convert_ddl       Run convert_ddl.py standalone test
    convert_dml       Run convert_dml.py standalone test
    convert_procedures Run convert_procedures.py standalone test
"""

import sys
from pathlib import Path


def _setup_imports() -> None:
    """Add the scripts directory to sys.path so sibling modules can be imported."""
    scripts_dir = Path(__file__).resolve().parent
    if str(scripts_dir) not in sys.path:
        sys.path.insert(0, str(scripts_dir))


def _print_help() -> None:
    """Print usage information."""
    print(__doc__)


def run_all() -> None:
    """Run the full conversion pipeline via generate_output.py."""
    _setup_imports()
    import generate_output  # noqa: E402
    generate_output.main()


def run_generate_output() -> None:
    """Run generate_output.py — converts both input files to PostgreSQL."""
    run_all()


def run_parse_input() -> None:
    """Run parse_input.py standalone test."""
    _setup_imports()
    import parse_input  # noqa: E402
    parse_input.main()


def run_convert_ddl() -> None:
    """Run convert_ddl.py standalone test."""
    _setup_imports()
    import convert_ddl  # noqa: E402
    convert_ddl.main()


def run_convert_dml() -> None:
    """Run convert_dml.py standalone test."""
    _setup_imports()
    import convert_dml  # noqa: E402
    convert_dml.main()


def run_convert_procedures() -> None:
    """Run convert_procedures.py standalone test."""
    _setup_imports()
    import convert_procedures  # noqa: E402
    convert_procedures.main()


COMMANDS = {
    'all': run_all,
    'generate_output': run_generate_output,
    'parse_input': run_parse_input,
    'convert_ddl': run_convert_ddl,
    'convert_dml': run_convert_dml,
    'convert_procedures': run_convert_procedures,
}


def main() -> None:
    """CLI entry point."""
    if len(sys.argv) < 2 or sys.argv[1] in ('-h', '--help'):
        _print_help()
        sys.exit(0)

    command = sys.argv[1].lower()
    if command not in COMMANDS:
        print(f"ERROR: Unknown command '{command}'", file=sys.stderr)
        print(f"Available commands: {', '.join(COMMANDS.keys())}", file=sys.stderr)
        sys.exit(1)

    COMMANDS[command]()


if __name__ == '__main__':
    main()
