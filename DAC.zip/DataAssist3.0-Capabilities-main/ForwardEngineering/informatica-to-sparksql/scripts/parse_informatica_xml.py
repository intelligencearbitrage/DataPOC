#!/usr/bin/env python3
"""
Parse Informatica PowerCenter XML Export

Extracts workflow/mapping definitions, sources, targets, and transformations
from ANY Informatica PowerCenter XML export into structured YAML format.

Supports:
- Single or multi-mapping XML files
- CLI-driven input/output paths
- Dynamic output naming based on mapping names
- Batch processing of multiple XML files

Usage:
    python parse_informatica_xml.py --input-xml path/to/export.xml --output-dir path/to/output/
    python parse_informatica_xml.py --input-dir path/to/xmls/ --output-dir path/to/output/
"""

import xml.etree.ElementTree as ET
import yaml
import json
import argparse
from pathlib import Path
from typing import Dict, List, Any, Optional
from dataclasses import dataclass, asdict
from datetime import datetime


@dataclass
class SourceColumn:
    """Represents a source column definition."""
    name: str
    datatype: str
    precision: Optional[int] = None
    scale: Optional[int] = None
    nullable: Optional[str] = None
    key_type: Optional[str] = None


@dataclass
class Source:
    """Represents an Informatica source definition."""
    name: str
    database_type: str
    owner: Optional[str] = None
    columns: List[SourceColumn] = None

    def __post_init__(self):
        if self.columns is None:
            self.columns = []


@dataclass
class Target:
    """Represents an Informatica target definition."""
    name: str
    database_type: str
    load_type: Optional[str] = None
    description: Optional[str] = None
    columns: List[Dict] = None
    instances: List[str] = None

    def __post_init__(self):
        if self.columns is None:
            self.columns = []
        if self.instances is None:
            self.instances = []


@dataclass
class TransformationPort:
    """Represents a transformation port."""
    name: str
    port_type: str
    datatype: str
    precision: Optional[int] = None
    scale: Optional[int] = None
    expression: Optional[str] = None


@dataclass
class Transformation:
    """Represents an Informatica transformation."""
    name: str
    type: str
    description: Optional[str] = None
    reusable: Optional[str] = None
    ports: List[TransformationPort] = None
    table_attributes: Dict[str, str] = None

    def __post_init__(self):
        if self.ports is None:
            self.ports = []
        if self.table_attributes is None:
            self.table_attributes = {}


@dataclass
class Connector:
    """Represents a data flow connector."""
    from_instance: str
    from_transformation: str
    from_port: str
    to_instance: str
    to_transformation: str
    to_port: str


class InformaticaXMLParser:
    """Parser for Informatica PowerCenter XML exports."""

    def __init__(self, xml_file_path: str):
        self.xml_file_path = Path(xml_file_path)
        self.tree = None
        self.root = None
        self.mapping_metadata = {}
        self.sources = []
        self.targets = []
        self.transformations = []
        self.connectors = []
        self.parameters = []

    def parse(self) -> Dict[str, Any]:
        """Main parsing method."""
        print(f"Parsing {self.xml_file_path}...")

        # Step 1: Load XML
        try:
            self.tree = ET.parse(self.xml_file_path)
            self.root = self.tree.getroot()
        except ET.ParseError as e:
            raise ValueError(f"Invalid XML file: {e}")

        # Step 1.5: Validate PowerCenter structure
        if not self._validate_powercenter_xml():
            raise ValueError(f"Not a valid Informatica PowerCenter XML export")

        # Step 2: Extract mapping metadata
        self._extract_mapping_metadata()

        # Step 3: Extract sources
        self._extract_sources()

        # Step 4: Extract targets
        self._extract_targets()

        # Step 5: Extract transformations
        self._extract_transformations()

        # Step 6: Extract connectors
        self._extract_connectors()

        # Step 7: Extract parameters
        self._extract_parameters()

        return self._build_output()

    def _validate_powercenter_xml(self) -> bool:
        """Validate that this is an Informatica PowerCenter XML file."""
        # Check for key PowerCenter XML elements
        has_repository = self.root.find(".//REPOSITORY") is not None
        has_folder = self.root.find(".//FOLDER") is not None
        has_mapping = self.root.find(".//MAPPING") is not None

        return has_repository or has_folder or has_mapping

    def _extract_mapping_metadata(self):
        """Extract high-level mapping information."""
        mapping = self.root.find(".//MAPPING")
        if mapping is not None:
            self.mapping_metadata = {
                "name": mapping.get("NAME"),
                "description": mapping.get("DESCRIPTION", ""),
                "versionnumber": mapping.get("VERSIONNUMBER"),
                "isvalid": mapping.get("ISVALID"),
            }

        repository = self.root.find(".//REPOSITORY")
        if repository is not None:
            self.mapping_metadata["repository"] = repository.get("NAME")

        folder = self.root.find(".//FOLDER")
        if folder is not None:
            self.mapping_metadata["folder"] = folder.get("NAME")

    def _extract_sources(self):
        """Extract SOURCE definitions."""
        for source_elem in self.root.findall(".//SOURCE"):
            columns = []
            for field in source_elem.findall("SOURCEFIELD"):
                col = SourceColumn(
                    name=field.get("NAME"),
                    datatype=field.get("DATATYPE"),
                    precision=int(field.get("PRECISION", 0)) if field.get("PRECISION") else None,
                    scale=int(field.get("SCALE", 0)) if field.get("SCALE") else None,
                    nullable=field.get("NULLABLE"),
                    key_type=field.get("KEYTYPE")
                )
                columns.append(col)

            source = Source(
                name=source_elem.get("NAME"),
                database_type=source_elem.get("DATABASETYPE"),
                owner=source_elem.get("OWNERNAME"),
                columns=columns
            )
            self.sources.append(source)

    def _extract_targets(self):
        """Extract TARGET definitions."""
        for target_elem in self.root.findall(".//TARGET"):
            columns = []
            for field in target_elem.findall("TARGETFIELD"):
                col = {
                    "name": field.get("NAME"),
                    "datatype": field.get("DATATYPE"),
                    "precision": int(field.get("PRECISION", 0)) if field.get("PRECISION") else None,
                    "scale": int(field.get("SCALE", 0)) if field.get("SCALE") else None,
                    "nullable": field.get("NULLABLE"),
                    "key_type": field.get("KEYTYPE")
                }
                columns.append(col)

            target = Target(
                name=target_elem.get("NAME"),
                database_type=target_elem.get("DATABASETYPE"),
                load_type=target_elem.get("LOADTYPE"),
                description=target_elem.get("DESCRIPTION"),
                columns=columns
            )
            self.targets.append(target)

    def _extract_transformations(self):
        """Extract TRANSFORMATION definitions."""
        for trans_elem in self.root.findall(".//MAPPING/TRANSFORMATION"):
            trans_type = trans_elem.get("TYPE")

            # Extract ports
            ports = []
            for port_elem in trans_elem.findall("TRANSFORMFIELD"):
                port = TransformationPort(
                    name=port_elem.get("NAME"),
                    port_type=port_elem.get("PORTTYPE"),
                    datatype=port_elem.get("DATATYPE"),
                    precision=int(port_elem.get("PRECISION", 0)) if port_elem.get("PRECISION") else None,
                    scale=int(port_elem.get("SCALE", 0)) if port_elem.get("SCALE") else None,
                    expression=port_elem.get("EXPRESSION")
                )
                ports.append(port)

            # Extract table attributes
            table_attrs = {}
            for attr_elem in trans_elem.findall("TABLEATTRIBUTE"):
                attr_name = attr_elem.get("NAME")
                attr_value = attr_elem.get("VALUE")
                if attr_value:
                    table_attrs[attr_name] = attr_value

            trans = Transformation(
                name=trans_elem.get("NAME"),
                type=trans_type,
                description=trans_elem.get("DESCRIPTION"),
                reusable=trans_elem.get("REUSABLE"),
                ports=ports,
                table_attributes=table_attrs
            )
            self.transformations.append(trans)

    def _extract_connectors(self):
        """Extract CONNECTOR definitions (data flow)."""
        for conn_elem in self.root.findall(".//MAPPING/CONNECTOR"):
            connector = Connector(
                from_instance=conn_elem.get("FROMINSTANCE"),
                from_transformation=conn_elem.get("FROMFIELD").split(".")[0] if conn_elem.get("FROMFIELD") else "",
                from_port=conn_elem.get("FROMFIELD").split(".")[1] if "." in conn_elem.get("FROMFIELD", "") else conn_elem.get("FROMFIELD", ""),
                to_instance=conn_elem.get("TOINSTANCE"),
                to_transformation=conn_elem.get("TOFIELD").split(".")[0] if conn_elem.get("TOFIELD") else "",
                to_port=conn_elem.get("TOFIELD").split(".")[1] if "." in conn_elem.get("TOFIELD", "") else conn_elem.get("TOFIELD", "")
            )
            self.connectors.append(connector)

    def _extract_parameters(self):
        """Extract mapping parameters."""
        # Look for parameter references in expressions and table attributes
        param_refs = set()

        for trans in self.transformations:
            # Check expressions
            for port in trans.ports:
                if port.expression and "$$" in port.expression:
                    # Extract $$PARAM_NAME patterns
                    import re
                    params = re.findall(r'\$\$\w+', port.expression)
                    param_refs.update(params)

            # Check table attributes
            for attr_value in trans.table_attributes.values():
                if "$$" in attr_value:
                    import re
                    params = re.findall(r'\$\$\w+', attr_value)
                    param_refs.update(params)

        self.parameters = [{"name": p, "usage": "Referenced in transformations"} for p in sorted(param_refs)]

    def _build_output(self) -> Dict[str, Any]:
        """Build the final output structure."""
        return {
            "metadata": {
                "analyzed_file": str(self.xml_file_path.name),
                "analyzed_date": datetime.now().strftime("%Y-%m-%d"),
                **self.mapping_metadata
            },
            "sources": [asdict(s) for s in self.sources],
            "targets": [asdict(t) for t in self.targets],
            "transformations": [asdict(t) for t in self.transformations],
            "connectors": [asdict(c) for c in self.connectors],
            "parameters": self.parameters
        }

    def get_mapping_name(self) -> Optional[str]:
        """Get the mapping name from parsed metadata."""
        return self.mapping_metadata.get("name")

    def write_yaml(self, output_path: str):
        """Write parsed data to YAML file."""
        output_file = Path(output_path)
        output_file.parent.mkdir(parents=True, exist_ok=True)

        data = self.parse()

        with open(output_file, 'w') as f:
            yaml.dump(data, f, default_flow_style=False, sort_keys=False, allow_unicode=True)

        print(f"[OK] Parsed metadata written to {output_file}")
        return output_file


def parse_single_xml(input_xml: str, output_dir: str) -> Path:
    """Parse a single XML file and write output."""
    parser = InformaticaXMLParser(input_xml)

    # Parse to get mapping name
    data = parser.parse()
    mapping_name = parser.get_mapping_name()

    if not mapping_name:
        # Fallback to filename if no mapping name found
        mapping_name = Path(input_xml).stem

    # Dynamic output filename based on mapping name
    output_file = Path(output_dir) / f"{mapping_name}_metadata.yaml"
    output_file.parent.mkdir(parents=True, exist_ok=True)

    with open(output_file, 'w') as f:
        yaml.dump(data, f, default_flow_style=False, sort_keys=False, allow_unicode=True)

    print(f"[OK] Parsed metadata written to {output_file}")
    print(f"  Sources: {len(parser.sources)}")
    print(f"  Targets: {len(parser.targets)}")
    print(f"  Transformations: {len(parser.transformations)}")
    print(f"  Connectors: {len(parser.connectors)}")
    print(f"  Parameters: {len(parser.parameters)}")

    return output_file


def parse_directory(input_dir: str, output_dir: str) -> List[Path]:
    """Parse all XML files in a directory."""
    input_path = Path(input_dir)
    xml_files = list(input_path.glob("*.xml")) + list(input_path.glob("*.XML"))

    if not xml_files:
        print(f"Warning: No XML files found in {input_dir}")
        return []

    print(f"Found {len(xml_files)} XML file(s) to process")

    output_files = []
    for xml_file in xml_files:
        print(f"\nProcessing {xml_file.name}...")
        try:
            output_file = parse_single_xml(str(xml_file), output_dir)
            output_files.append(output_file)
        except Exception as e:
            print(f"[ERROR] Error parsing {xml_file.name}: {e}")
            continue

    return output_files


def main():
    """Main execution function with CLI argument support."""
    parser = argparse.ArgumentParser(
        description="Parse Informatica PowerCenter XML exports to structured YAML metadata",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # Parse single XML file
  python parse_informatica_xml.py --input-xml user-config/inputs/mapping.xml --output-dir scripts-output/output/parsed_metadata/

  # Parse all XML files in a directory
  python parse_informatica_xml.py --input-dir user-config/inputs/ --output-dir scripts-output/output/parsed_metadata/

  # Use default paths (backward compatible)
  python parse_informatica_xml.py
        """
    )

    parser.add_argument(
        "--input-xml",
        type=str,
        help="Path to a single Informatica PowerCenter XML file"
    )

    parser.add_argument(
        "--input-dir",
        type=str,
        help="Directory containing multiple XML files to process"
    )

    parser.add_argument(
        "--output-dir",
        type=str,
        default="scripts-output/output/parsed_metadata",
        help="Output directory for parsed metadata YAML files (default: scripts-output/output/parsed_metadata)"
    )

    args = parser.parse_args()

    # Backward compatibility: if no arguments provided, use default paths
    if not args.input_xml and not args.input_dir:
        print("No input specified, using default: user-config/inputs/m_bg_stat_dim.XML")
        args.input_xml = "user-config/inputs/m_bg_stat_dim.XML"

    # Validate input arguments
    if args.input_xml and args.input_dir:
        parser.error("Cannot specify both --input-xml and --input-dir. Choose one.")

    # Process input
    try:
        if args.input_xml:
            # Single file mode
            if not Path(args.input_xml).exists():
                print(f"Error: Input file not found: {args.input_xml}")
                return 1

            parse_single_xml(args.input_xml, args.output_dir)
            print(f"\n[SUCCESS] Parsing complete!")

        elif args.input_dir:
            # Directory mode
            if not Path(args.input_dir).exists():
                print(f"Error: Input directory not found: {args.input_dir}")
                return 1

            output_files = parse_directory(args.input_dir, args.output_dir)
            print(f"\n[SUCCESS] Batch parsing complete! Processed {len(output_files)} file(s)")

    except Exception as e:
        print(f"\n[ERROR] Error: {e}")
        return 1

    return 0


if __name__ == "__main__":
    exit(main())
