#!/usr/bin/env python3
"""
Score Output Quality

Validates accuracy of outputs by comparing against source inputs and
knowledgebase rules. Produces quantitative score reports.

Implements: Phase 5 Scoring
Output: agent-output/scores/score_report_v1.yaml
"""

import yaml
from pathlib import Path
from datetime import datetime
from typing import Dict, List, Any


class OutputScorer:
    """Scores the quality and completeness of pipeline outputs."""

    def __init__(self):
        self.scores = {}
        self.findings = []
        self.overall_verdict = "PENDING"

    def score_parsed_metadata(self) -> Dict[str, Any]:
        """Score Component 1: Parse Informatica XML."""
        print("\nScoring Component 1: Parsed Metadata...")

        metadata_path = Path("scripts-output/output/parsed_metadata/m_bg_stat_dim_metadata.yaml")

        if not metadata_path.exists():
            return {
                "component": "parse_informatica_xml",
                "score": 0.0,
                "verdict": "FAIL",
                "reason": "Output file not found"
            }

        with open(metadata_path, 'r', encoding='utf-8') as f:
            metadata = yaml.safe_load(f)

        # Check completeness
        checks_passed = 0
        total_checks = 5

        if metadata.get('metadata'):
            checks_passed += 1
        if metadata.get('transformations') and len(metadata['transformations']) > 0:
            checks_passed += 1
        if metadata.get('connectors') and len(metadata['connectors']) > 0:
            checks_passed += 1
        if metadata.get('parameters') and len(metadata['parameters']) > 0:
            checks_passed += 1
        if metadata_path.stat().st_size > 1000:  # Non-trivial size
            checks_passed += 1

        score = (checks_passed / total_checks) * 100

        return {
            "component": "parse_informatica_xml",
            "output_file": str(metadata_path),
            "file_size_kb": round(metadata_path.stat().st_size / 1024, 2),
            "checks_passed": f"{checks_passed}/{total_checks}",
            "transformations_extracted": len(metadata.get('transformations', [])),
            "connectors_extracted": len(metadata.get('connectors', [])),
            "parameters_extracted": len(metadata.get('parameters', [])),
            "score": round(score, 2),
            "verdict": "PASS" if score >= 80 else ("WARN" if score >= 60 else "FAIL")
        }

    def score_transformation_analysis(self) -> Dict[str, Any]:
        """Score Component 2: Transformation Analysis."""
        print("Scoring Component 2: Transformation Analysis...")

        analysis_path = Path("scripts-output/output/transformation_analysis/transformation_analysis.yaml")

        if not analysis_path.exists():
            return {
                "component": "analyze_transformations",
                "score": 0.0,
                "verdict": "FAIL",
                "reason": "Output file not found"
            }

        with open(analysis_path, 'r', encoding='utf-8') as f:
            analysis = yaml.safe_load(f)

        transformations = analysis.get('transformation_analysis', [])

        checks_passed = 0
        total_checks = len(transformations) if transformations else 1

        # Check each transformation has Spark equivalent
        for trans in transformations:
            if trans.get('spark_equivalent'):
                checks_passed += 1

        score = (checks_passed / total_checks) * 100

        return {
            "component": "analyze_transformations",
            "output_file": str(analysis_path),
            "transformations_analyzed": len(transformations),
            "spark_equivalents_found": checks_passed,
            "score": round(score, 2),
            "verdict": "PASS" if score >= 80 else ("WARN" if score >= 60 else "FAIL")
        }

    def score_transformation_mapping(self) -> Dict[str, Any]:
        """Score Component 3: Transformation Mapping."""
        print("Scoring Component 3: Transformation Mapping...")

        yaml_path = Path("scripts-output/output/transformation_mapping/transformation_mapping.yaml")
        csv_path = Path("scripts-output/output/transformation_mapping/informatica_spark_mapping.csv")

        checks_passed = 0
        total_checks = 3

        if yaml_path.exists():
            checks_passed += 1
        if csv_path.exists():
            checks_passed += 1
        if yaml_path.exists() and yaml_path.stat().st_size > 500:
            checks_passed += 1

        score = (checks_passed / total_checks) * 100

        return {
            "component": "generate_transformation_mapping",
            "yaml_file": str(yaml_path),
            "csv_file": str(csv_path),
            "checks_passed": f"{checks_passed}/{total_checks}",
            "score": round(score, 2),
            "verdict": "PASS" if score >= 80 else ("WARN" if score >= 60 else "FAIL")
        }

    def score_lineage_mapping(self) -> Dict[str, Any]:
        """Score Component 4: Source-Target Lineage."""
        print("Scoring Component 4: Source-Target Lineage...")

        yaml_path = Path("scripts-output/output/source_target_mapping/field_lineage.yaml")
        md_path = Path("scripts-output/output/source_target_mapping/lineage_report.md")

        checks_passed = 0
        total_checks = 2

        if yaml_path.exists():
            checks_passed += 1
        if md_path.exists():
            checks_passed += 1

        score = (checks_passed / total_checks) * 100

        return {
            "component": "generate_source_target_mapping",
            "yaml_file": str(yaml_path),
            "markdown_file": str(md_path),
            "checks_passed": f"{checks_passed}/{total_checks}",
            "score": round(score, 2),
            "verdict": "PASS" if score >= 80 else ("WARN" if score >= 60 else "FAIL")
        }

    def score_sparksql_script(self) -> Dict[str, Any]:
        """Score Component 5: Spark SQL Script."""
        print("Scoring Component 5: Spark SQL Script...")

        sql_path = Path("scripts-output/output/sparksql_scripts/m_bg_stat_dim.sql")

        if not sql_path.exists():
            return {
                "component": "generate_sparksql_scripts",
                "score": 0.0,
                "verdict": "FAIL",
                "reason": "Spark SQL script not found"
            }

        with open(sql_path, 'r', encoding='utf-8') as f:
            sql_content = f.read()

        # Quality checks
        checks = {
            "file_exists": sql_path.exists(),
            "non_empty": len(sql_content) > 1000,
            "has_merge_statement": "MERGE INTO" in sql_content,
            "has_temporary_views": "TEMPORARY VIEW" in sql_content,
            "has_parameters": "${" in sql_content,
            "has_source_qualifier": "source_data" in sql_content,
            "has_lookup": "LEFT JOIN" in sql_content,
            "has_router": "insert_records" in sql_content and "update_records" in sql_content,
            "has_validation": "COUNT(*)" in sql_content,
            "has_comments": "--" in sql_content
        }

        checks_passed = sum(checks.values())
        total_checks = len(checks)
        score = (checks_passed / total_checks) * 100

        line_count = len(sql_content.split('\n'))

        return {
            "component": "generate_sparksql_scripts",
            "output_file": str(sql_path),
            "file_size_kb": round(sql_path.stat().st_size / 1024, 2),
            "line_count": line_count,
            "quality_checks": checks,
            "checks_passed": f"{checks_passed}/{total_checks}",
            "score": round(score, 2),
            "verdict": "PASS" if score >= 80 else ("WARN" if score >= 60 else "FAIL"),
            "notes": "Complete Spark SQL implementation with MERGE, temporary views, and validation"
        }

    def score_migration_doc(self) -> Dict[str, Any]:
        """Score Component 6: Migration Documentation."""
        print("Scoring Component 6: Migration Documentation...")

        doc_path = Path("scripts-output/output/migration_documentation/MIGRATION_GUIDE.md")

        if not doc_path.exists():
            return {
                "component": "generate_migration_doc",
                "score": 0.0,
                "verdict": "FAIL",
                "reason": "Migration guide not found"
            }

        with open(doc_path, 'r', encoding='utf-8') as f:
            doc_content = f.read()

        # Quality checks
        checks = {
            "file_exists": doc_path.exists(),
            "has_overview": "Executive Summary" in doc_content,
            "has_data_flow": "Data Flow" in doc_content,
            "has_transformation_mapping": "Transformation Mapping" in doc_content,
            "has_deployment": "Deployment" in doc_content,
            "has_parameters": "Parameters" in doc_content,
            "has_validation": "Validation" in doc_content,
            "has_troubleshooting": "Troubleshooting" in doc_content,
            "substantial_content": len(doc_content) > 5000
        }

        checks_passed = sum(checks.values())
        total_checks = len(checks)
        score = (checks_passed / total_checks) * 100

        return {
            "component": "generate_migration_doc",
            "output_file": str(doc_path),
            "file_size_kb": round(doc_path.stat().st_size / 1024, 2),
            "quality_checks": checks,
            "checks_passed": f"{checks_passed}/{total_checks}",
            "score": round(score, 2),
            "verdict": "PASS" if score >= 80 else ("WARN" if score >= 60 else "FAIL")
        }

    def calculate_overall_score(self, component_scores: List[Dict]) -> Dict[str, Any]:
        """Calculate overall project score."""
        print("\nCalculating Overall Score...")

        total_score = 0
        pass_count = 0
        warn_count = 0
        fail_count = 0

        for comp in component_scores:
            total_score += comp.get('score', 0)
            verdict = comp.get('verdict', 'FAIL')
            if verdict == 'PASS':
                pass_count += 1
            elif verdict == 'WARN':
                warn_count += 1
            else:
                fail_count += 1

        avg_score = total_score / len(component_scores) if component_scores else 0

        # Overall verdict
        if avg_score >= 85 and fail_count == 0:
            overall_verdict = "PASS"
        elif avg_score >= 70 and fail_count <= 1:
            overall_verdict = "WARN"
        else:
            overall_verdict = "FAIL"

        return {
            "average_score": round(avg_score, 2),
            "total_components": len(component_scores),
            "pass_count": pass_count,
            "warn_count": warn_count,
            "fail_count": fail_count,
            "overall_verdict": overall_verdict,
            "deployment_approved": overall_verdict == "PASS"
        }

    def generate_score_report(self):
        """Generate complete score report."""
        print("=" * 60)
        print("PHASE 5: OUTPUT QUALITY SCORING")
        print("=" * 60)

        # Score each component
        component_scores = [
            self.score_parsed_metadata(),
            self.score_transformation_analysis(),
            self.score_transformation_mapping(),
            self.score_lineage_mapping(),
            self.score_sparksql_script(),
            self.score_migration_doc()
        ]

        # Calculate overall score
        overall = self.calculate_overall_score(component_scores)

        # Build report
        report = {
            "score_report": {
                "metadata": {
                    "project": "informatica-to-sparksql",
                    "mapping": "m_bg_stat_dim",
                    "score_date": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                    "version": "v1"
                },
                "component_scores": component_scores,
                "overall_assessment": overall,
                "recommendations": self._generate_recommendations(component_scores, overall)
            }
        }

        # Write report
        output_dir = Path("agent-output/scores")
        output_dir.mkdir(parents=True, exist_ok=True)

        report_path = output_dir / "score_report_v1.yaml"
        with open(report_path, 'w', encoding='utf-8') as f:
            yaml.dump(report, f, default_flow_style=False, sort_keys=False)

        print(f"\n[SUCCESS] Score report written to: {report_path}")

        return report, overall

    def _generate_recommendations(self, scores: List[Dict], overall: Dict) -> List[str]:
        """Generate recommendations based on scores."""
        recommendations = []

        # Check for failures
        for comp in scores:
            if comp.get('verdict') == 'FAIL':
                recommendations.append(f"CRITICAL: Fix {comp['component']} - {comp.get('reason', 'Quality checks failed')}")

        # Check for warnings
        for comp in scores:
            if comp.get('verdict') == 'WARN':
                recommendations.append(f"Review {comp['component']} - Score below 80%")

        # Overall recommendations
        if overall['overall_verdict'] == 'PASS':
            recommendations.append("Pipeline outputs meet quality standards - approved for deployment")
        elif overall['overall_verdict'] == 'WARN':
            recommendations.append("Pipeline outputs acceptable with minor issues - review before deployment")
        else:
            recommendations.append("Pipeline outputs below acceptable threshold - rework required")

        return recommendations if recommendations else ["All checks passed - no issues found"]


def main():
    """Main execution function."""
    scorer = OutputScorer()
    report, overall = scorer.generate_score_report()

    # Print summary
    print("\n" + "=" * 60)
    print("SCORING SUMMARY")
    print("=" * 60)
    print(f"Overall Score: {overall['average_score']}%")
    print(f"Verdict: {overall['overall_verdict']}")
    print(f"Components: {overall['pass_count']} PASS, {overall['warn_count']} WARN, {overall['fail_count']} FAIL")
    print(f"Deployment Approved: {overall['deployment_approved']}")
    print("=" * 60)

    return 0 if overall['overall_verdict'] in ['PASS', 'WARN'] else 1


if __name__ == "__main__":
    import sys
    sys.exit(main())
