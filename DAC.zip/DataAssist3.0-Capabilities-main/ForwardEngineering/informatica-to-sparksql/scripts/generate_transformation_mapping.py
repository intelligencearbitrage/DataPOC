#!/usr/bin/env python3
"""
Generate Informatica-to-Spark Transformation Mapping

Creates comprehensive mapping tables between Informatica transformations
and Spark operations with conversion rules and examples.

Supports 15+ transformation types with detailed conversion patterns.

Usage:
    python generate_transformation_mapping.py --output-dir path/to/output/
    python generate_transformation_mapping.py  # Uses default paths
"""

import yaml
import csv
import argparse
from pathlib import Path
from datetime import datetime


def generate_transformation_mapping(output_dir: str):
    """Generate comprehensive transformation mapping documentation."""

    output_path = Path(output_dir)
    output_path.mkdir(parents=True, exist_ok=True)

    # Comprehensive mapping data (15+ transformation types)
    mappings = [
        # Source & Target
        {
            "informatica_transformation": "Source Qualifier",
            "spark_sql": "CREATE TEMPORARY VIEW ... SELECT * FROM source WHERE filter",
            "spark_operation": "spark.read.format().load()",
            "conversion_pattern": "Read data with optional filter",
            "example_sql": "CREATE TEMPORARY VIEW source_data AS SELECT * FROM table WHERE date >= '2024-01-01'",
            "example_pyspark": "df = spark.read.parquet(path).filter(col('date') >= run_date)"
        },

        # Expression Functions
        {
            "informatica_transformation": "Expression - IIF",
            "spark_sql": "CASE WHEN condition THEN value1 ELSE value2 END",
            "spark_operation": "when().otherwise()",
            "conversion_pattern": "Conditional logic",
            "example_sql": "SELECT CASE WHEN status IS NULL THEN 'NEW' ELSE 'UPDATE' END AS flag",
            "example_pyspark": "df.withColumn('flag', when(col('status').isNull(), 'NEW').otherwise('UPDATE'))"
        },
        {
            "informatica_transformation": "Expression - DECODE",
            "spark_sql": "CASE col WHEN val1 THEN res1 WHEN val2 THEN res2 ELSE default END",
            "spark_operation": "when().when().otherwise()",
            "conversion_pattern": "Multi-value mapping",
            "example_sql": "SELECT CASE type WHEN 'A' THEN 'Active' WHEN 'I' THEN 'Inactive' ELSE 'Unknown' END",
            "example_pyspark": "when(col('type')=='A', 'Active').when(col('type')=='I', 'Inactive').otherwise('Unknown')"
        },
        {
            "informatica_transformation": "Expression - ISNULL",
            "spark_sql": "col IS NULL",
            "spark_operation": "col().isNull()",
            "conversion_pattern": "Null check",
            "example_sql": "SELECT * FROM table WHERE key_col IS NULL",
            "example_pyspark": "df.filter(col('key_col').isNull())"
        },
        {
            "informatica_transformation": "Expression - NVL",
            "spark_sql": "COALESCE(col, default)",
            "spark_operation": "coalesce()",
            "conversion_pattern": "Null replacement",
            "example_sql": "SELECT COALESCE(amount, 0) AS amount",
            "example_pyspark": "df.withColumn('amount', coalesce(col('amount'), lit(0)))"
        },
        {
            "informatica_transformation": "Expression - TO_DATE",
            "spark_sql": "TO_DATE(str, format)",
            "spark_operation": "to_date()",
            "conversion_pattern": "String to date conversion (note format differences)",
            "example_sql": "SELECT TO_DATE(date_str, 'yyyyMMdd') AS date_col",
            "example_pyspark": "df.withColumn('date_col', to_date('date_str', 'yyyyMMdd'))"
        },
        {
            "informatica_transformation": "Expression - SUBSTR",
            "spark_sql": "SUBSTR(str, start, length)",
            "spark_operation": "substring()",
            "conversion_pattern": "Substring extraction (Informatica is 1-indexed, Spark can be 1 or 0)",
            "example_sql": "SELECT SUBSTR(code, 1, 3) AS prefix",
            "example_pyspark": "df.withColumn('prefix', substring('code', 1, 3))"
        },
        {
            "informatica_transformation": "Expression - ADD_TO_DATE",
            "spark_sql": "DATE_ADD(date, INTERVAL n DAY/MONTH/YEAR)",
            "spark_operation": "date_add() / add_months()",
            "conversion_pattern": "Date arithmetic",
            "example_sql": "SELECT DATE_ADD(eff_date, INTERVAL 1 YEAR) AS next_year",
            "example_pyspark": "df.withColumn('next_year', add_months('eff_date', 12))"
        },

        # Lookup & Join
        {
            "informatica_transformation": "Lookup (cached)",
            "spark_sql": "LEFT JOIN with /*+ BROADCAST(lookup_table) */ hint",
            "spark_operation": "broadcast(df).join()",
            "conversion_pattern": "Broadcast join for small tables (<100MB)",
            "example_sql": "SELECT a.*, b.lookup_val FROM source a LEFT JOIN /*+ BROADCAST(b) */ lookup b ON a.key = b.key",
            "example_pyspark": "df.join(broadcast(lookup_df), ['key'], 'left')"
        },
        {
            "informatica_transformation": "Joiner - Normal Join",
            "spark_sql": "INNER JOIN",
            "spark_operation": "DataFrame.join(how='inner')",
            "conversion_pattern": "Standard inner join",
            "example_sql": "SELECT * FROM source1 a INNER JOIN source2 b ON a.key = b.key",
            "example_pyspark": "df1.join(df2, ['key'], 'inner')"
        },
        {
            "informatica_transformation": "Joiner - Master Outer Join",
            "spark_sql": "LEFT OUTER JOIN",
            "spark_operation": "DataFrame.join(how='left')",
            "conversion_pattern": "Keep all records from master (left) source",
            "example_sql": "SELECT * FROM master a LEFT JOIN detail b ON a.key = b.key",
            "example_pyspark": "master_df.join(detail_df, ['key'], 'left')"
        },

        # Router & Filter
        {
            "informatica_transformation": "Router",
            "spark_sql": "Multiple CTEs with WHERE clauses",
            "spark_operation": "DataFrame.filter() per group",
            "conversion_pattern": "Create separate result sets per routing condition",
            "example_sql": "WITH ins AS (SELECT * FROM src WHERE flag='I'), upd AS (SELECT * FROM src WHERE flag='U')",
            "example_pyspark": "df_insert = df.filter(col('flag')=='I'); df_update = df.filter(col('flag')=='U')"
        },
        {
            "informatica_transformation": "Filter",
            "spark_sql": "WHERE clause",
            "spark_operation": "DataFrame.filter()",
            "conversion_pattern": "Row filtering",
            "example_sql": "SELECT * FROM source WHERE amount > 0",
            "example_pyspark": "df.filter(col('amount') > 0)"
        },

        # Aggregator
        {
            "informatica_transformation": "Aggregator",
            "spark_sql": "GROUP BY with aggregate functions",
            "spark_operation": "DataFrame.groupBy().agg()",
            "conversion_pattern": "Group and aggregate data",
            "example_sql": "SELECT region, SUM(sales), COUNT(*) FROM source GROUP BY region",
            "example_pyspark": "df.groupBy('region').agg(sum('sales'), count('*'))"
        },

        # Sorter
        {
            "informatica_transformation": "Sorter",
            "spark_sql": "ORDER BY",
            "spark_operation": "DataFrame.orderBy()",
            "conversion_pattern": "Sort data",
            "example_sql": "SELECT * FROM source ORDER BY date DESC, id ASC",
            "example_pyspark": "df.orderBy(col('date').desc(), col('id').asc())"
        },

        # Union
        {
            "informatica_transformation": "Union",
            "spark_sql": "UNION ALL",
            "spark_operation": "DataFrame.union()",
            "conversion_pattern": "Combine datasets vertically",
            "example_sql": "SELECT * FROM source1 UNION ALL SELECT * FROM source2",
            "example_pyspark": "df1.union(df2)"
        },

        # Rank & Window
        {
            "informatica_transformation": "Rank",
            "spark_sql": "ROW_NUMBER() / RANK() / DENSE_RANK() OVER(PARTITION BY ... ORDER BY ...)",
            "spark_operation": "row_number().over(Window.partitionBy().orderBy())",
            "conversion_pattern": "Ranking within groups",
            "example_sql": "SELECT *, ROW_NUMBER() OVER (PARTITION BY group_id ORDER BY score DESC) AS rank",
            "example_pyspark": "df.withColumn('rank', row_number().over(Window.partitionBy('group_id').orderBy(col('score').desc())))"
        },

        # Normalizer
        {
            "informatica_transformation": "Normalizer",
            "spark_sql": "LATERAL VIEW EXPLODE() / UNNEST",
            "spark_operation": "explode() or lateral view",
            "conversion_pattern": "Denormalize columns to rows",
            "example_sql": "SELECT id, value FROM source LATERAL VIEW EXPLODE(array_col) AS value",
            "example_pyspark": "df.select('id', explode('array_col').alias('value'))"
        },

        # Update Strategy
        {
            "informatica_transformation": "Update Strategy",
            "spark_sql": "MERGE INTO target USING source ON condition WHEN MATCHED THEN UPDATE WHEN NOT MATCHED THEN INSERT",
            "spark_operation": "Delta Lake merge() / separate INSERT/UPDATE",
            "conversion_pattern": "UPSERT operation (SCD Type 1)",
            "example_sql": "MERGE INTO target t USING source s ON t.key=s.key WHEN MATCHED THEN UPDATE SET * WHEN NOT MATCHED THEN INSERT *",
            "example_pyspark": "from delta.tables import DeltaTable; DeltaTable.forPath(spark, path).merge(source, 'key').whenMatchedUpdateAll().whenNotMatchedInsertAll().execute()"
        },

        # Sequence Generator
        {
            "informatica_transformation": "Sequence Generator",
            "spark_sql": "ROW_NUMBER() OVER(ORDER BY ...) / monotonically_increasing_id()",
            "spark_operation": "monotonically_increasing_id() or row_number()",
            "conversion_pattern": "Generate surrogate keys",
            "example_sql": "SELECT ROW_NUMBER() OVER(ORDER BY key) AS seq_id, * FROM source",
            "example_pyspark": "df.withColumn('seq_id', monotonically_increasing_id())"
        },

        # Stored Procedure
        {
            "informatica_transformation": "Stored Procedure",
            "spark_sql": "CALL procedure_name(params) / CREATE FUNCTION (UDF)",
            "spark_operation": "spark.sql('CALL ...') or custom UDF",
            "conversion_pattern": "Execute stored procedure or create UDF",
            "example_sql": "CALL calculate_metrics('2024-01-01')",
            "example_pyspark": "spark.sql(\"CALL calculate_metrics('2024-01-01')\")"
        }
    ]

    # Write CSV
    csv_path = output_path / "informatica_spark_mapping.csv"
    with open(csv_path, 'w', newline='', encoding='utf-8') as f:
        writer = csv.DictWriter(f, fieldnames=[
            "informatica_transformation", "spark_sql", "spark_operation",
            "conversion_pattern", "example_sql", "example_pyspark"
        ])
        writer.writeheader()
        writer.writerows(mappings)

    # Write YAML
    yaml_path = output_path / "transformation_mapping.yaml"
    with open(yaml_path, 'w', encoding='utf-8') as f:
        yaml.dump({
            "metadata": {
                "generated_date": datetime.now().strftime("%Y-%m-%d"),
                "mapping_count": len(mappings),
                "description": "Comprehensive mapping between Informatica PowerCenter transformations and Spark SQL/PySpark equivalents"
            },
            "transformation_mappings": mappings
        }, f, default_flow_style=False, sort_keys=False)

    print(f"[OK] Transformation mapping written to {output_path}")
    print(f"  - {csv_path.name} ({len(mappings)} mappings)")
    print(f"  - {yaml_path.name}")


def main():
    """Main execution function with CLI support."""
    parser = argparse.ArgumentParser(
        description="Generate Informatica-to-Spark transformation mapping tables",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # Generate with custom output directory
  python generate_transformation_mapping.py --output-dir custom_output/mappings/

  # Use default output directory
  python generate_transformation_mapping.py
        """
    )

    parser.add_argument(
        "--output-dir",
        type=str,
        default="scripts-output/output/transformation_mapping",
        help="Output directory for mapping files (default: scripts-output/output/transformation_mapping)"
    )

    args = parser.parse_args()

    try:
        generate_transformation_mapping(args.output_dir)
        print(f"\n[SUCCESS] Transformation mapping generation complete!")
        return 0

    except Exception as e:
        print(f"\n[ERROR] Error: {e}")
        return 1


if __name__ == "__main__":
    exit(main())
