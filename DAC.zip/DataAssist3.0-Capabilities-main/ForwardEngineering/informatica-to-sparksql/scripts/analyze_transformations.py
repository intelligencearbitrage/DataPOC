#!/usr/bin/env python3
"""
Analyze Informatica Transformations

Analyzes Informatica transformations from ANY parsed metadata and identifies
equivalent Spark SQL operations and functions.

Supports 15+ Informatica transformation types with comprehensive Spark equivalents.

Usage:
    python analyze_transformations.py --metadata-file path/to/metadata.yaml --output-dir path/to/output/
    python analyze_transformations.py  # Uses default paths (backward compatible)
"""

import yaml
import argparse
from pathlib import Path
from typing import Dict, List, Any
from datetime import datetime


class TransformationAnalyzer:
    """Analyzes Informatica transformations and maps to Spark equivalents."""

    SPARK_EQUIVALENTS = {
        "Source Qualifier": {
            "spark_operation": "spark.read / CREATE TEMPORARY VIEW",
            "description": "Read from source using Spark DataFrame API or SQL",
            "filter_translation": "DataFrame.filter() or WHERE clause",
            "sql_override_translation": "spark.sql() or createTempView + SQL",
            "sql_example": "SELECT * FROM source WHERE filter_condition"
        },
        "Expression": {
            "spark_operation": "DataFrame.withColumn() / SELECT with expressions",
            "description": "Add or modify columns using Spark Column expressions or SQL",
            "function_mappings": {
                "IIF": "CASE WHEN ... THEN ... ELSE ... END",
                "ISNULL": "col IS NULL",
                "ISNOTNULL": "col IS NOT NULL",
                "TO_DATE": "TO_DATE(col, format)",
                "TO_CHAR": "DATE_FORMAT(col, format)",
                "SUBSTR": "SUBSTR(col, start, length) -- note: Informatica is 1-indexed",
                "INSTR": "INSTR(col, search_str)",
                "CONCAT": "CONCAT(col1, col2, ...)",
                "DECODE": "CASE col WHEN val1 THEN res1 ... ELSE default END",
                "NVL": "COALESCE(col, default)",
                "NVL2": "CASE WHEN col IS NOT NULL THEN val1 ELSE val2 END",
                "LTRIM": "LTRIM(col)",
                "RTRIM": "RTRIM(col)",
                "TRIM": "TRIM(col)",
                "UPPER": "UPPER(col)",
                "LOWER": "LOWER(col)",
                "LENGTH": "LENGTH(col)",
                "TRUNC": "TRUNC(col)",
                "ROUND": "ROUND(col, precision)",
                "ABS": "ABS(col)",
                "ADD_TO_DATE": "DATE_ADD(col, INTERVAL value unit)",
                "SYSDATE": "CURRENT_TIMESTAMP()",
                "ERROR": "RAISE_ERROR() or validation filter"
            }
        },
        "Lookup": {
            "spark_operation": "DataFrame.join() / LEFT JOIN",
            "description": "Join with reference/lookup table",
            "cached_lookup": "LEFT JOIN with broadcast hint (for small tables)",
            "uncached_lookup": "LEFT JOIN (standard shuffle join)",
            "join_type_mapping": {
                "cached": "LEFT JOIN -- Informatica cached lookup",
                "uncached": "LEFT JOIN -- Informatica uncached lookup",
                "connected": "LEFT JOIN -- returns lookup columns",
                "unconnected": "LEFT JOIN -- used in expression via :LKP.function()"
            },
            "sql_example": "SELECT a.*, b.lookup_col FROM source a LEFT JOIN lookup b ON a.key = b.key"
        },
        "Router": {
            "spark_operation": "Multiple CTEs with WHERE / CASE WHEN",
            "description": "Split data flow based on conditions into multiple output groups",
            "implementation": "Create separate CTEs with filter conditions or use CASE WHEN for routing column",
            "sql_example": "WITH group1 AS (SELECT * FROM src WHERE condition1), group2 AS (SELECT * FROM src WHERE condition2)"
        },
        "Update Strategy": {
            "spark_operation": "MERGE statement / Delta Lake merge()",
            "description": "Determine INSERT vs UPDATE vs DELETE based on flag",
            "dd_insert": "DD_INSERT (0) -> INSERT",
            "dd_update": "DD_UPDATE (1) -> UPDATE",
            "dd_delete": "DD_DELETE (2) -> DELETE",
            "dd_reject": "DD_REJECT (3) -> Filter out",
            "sql_example": "MERGE INTO target USING source ON key_match WHEN MATCHED THEN UPDATE WHEN NOT MATCHED THEN INSERT"
        },
        "Sequence Generator": {
            "spark_operation": "ROW_NUMBER() OVER() / monotonically_increasing_id()",
            "description": "Generate surrogate keys or sequence numbers",
            "note": "Spark sequences are non-deterministic across runs; use ROW_NUMBER for deterministic sequences",
            "sql_example": "SELECT ROW_NUMBER() OVER (ORDER BY key) AS seq_id, * FROM source"
        },
        "Aggregator": {
            "spark_operation": "GROUP BY with aggregate functions",
            "description": "Group and aggregate data using SUM, COUNT, AVG, MIN, MAX, etc.",
            "aggregate_functions": {
                "SUM": "SUM(col)",
                "COUNT": "COUNT(col) or COUNT(*)",
                "AVG": "AVG(col)",
                "MIN": "MIN(col)",
                "MAX": "MAX(col)",
                "FIRST": "FIRST(col)",
                "LAST": "LAST(col)",
                "STDDEV": "STDDEV(col)",
                "VARIANCE": "VARIANCE(col)"
            },
            "sql_example": "SELECT group_col, SUM(amount), COUNT(*) FROM source GROUP BY group_col"
        },
        "Filter": {
            "spark_operation": "WHERE clause / DataFrame.filter()",
            "description": "Filter rows based on condition",
            "sql_example": "SELECT * FROM source WHERE filter_condition"
        },
        "Joiner": {
            "spark_operation": "JOIN",
            "description": "Join two data sources",
            "join_types": {
                "Normal Join": "INNER JOIN",
                "Master Outer Join": "LEFT OUTER JOIN",
                "Detail Outer Join": "RIGHT OUTER JOIN",
                "Full Outer Join": "FULL OUTER JOIN"
            },
            "sql_example": "SELECT * FROM source1 a INNER JOIN source2 b ON a.key = b.key"
        },
        "Sorter": {
            "spark_operation": "ORDER BY / DataFrame.orderBy()",
            "description": "Sort data by one or more columns",
            "sql_example": "SELECT * FROM source ORDER BY col1 ASC, col2 DESC"
        },
        "Union": {
            "spark_operation": "UNION ALL / DataFrame.union()",
            "description": "Combine multiple data sources vertically",
            "sql_example": "SELECT * FROM source1 UNION ALL SELECT * FROM source2"
        },
        "Normalizer": {
            "spark_operation": "LATERAL VIEW EXPLODE() / UNNEST",
            "description": "Denormalize rows (convert columns to rows)",
            "sql_example": "SELECT id, col_value FROM source LATERAL VIEW EXPLODE(array_col) AS col_value"
        },
        "Rank": {
            "spark_operation": "ROW_NUMBER() / RANK() / DENSE_RANK() OVER()",
            "description": "Rank rows within partitions",
            "rank_types": {
                "Row Number": "ROW_NUMBER() OVER (PARTITION BY group_col ORDER BY rank_col)",
                "Rank": "RANK() OVER (PARTITION BY group_col ORDER BY rank_col)",
                "Dense Rank": "DENSE_RANK() OVER (PARTITION BY group_col ORDER BY rank_col)"
            },
            "sql_example": "SELECT *, ROW_NUMBER() OVER (PARTITION BY group_col ORDER BY rank_col) AS rank FROM source"
        },
        "Stored Procedure": {
            "spark_operation": "CALL procedure / CREATE FUNCTION (UDF)",
            "description": "Execute stored procedure or custom UDF",
            "implementation": "Convert to Spark UDF or external API call",
            "sql_example": "CALL stored_procedure(param1, param2)"
        },
        "XML Generator": {
            "spark_operation": "to_xml() / custom XML generation UDF",
            "description": "Generate XML output from structured data",
            "note": "May require custom Spark UDF for complex XML structures"
        },
        "XML Parser": {
            "spark_operation": "from_xml() / xpath functions",
            "description": "Parse XML input into structured columns",
            "sql_example": "SELECT xpath(xml_col, '//element/text()') FROM source"
        },
        "SQL Transformation": {
            "spark_operation": "spark.sql() / CREATE TEMPORARY VIEW + SQL",
            "description": "Execute custom SQL query",
            "sql_example": "spark.sql('SELECT * FROM source WHERE condition')"
        }
    }

    def __init__(self, metadata_path: str):
        self.metadata_path = Path(metadata_path)
        self.metadata = None
        self.analysis_results = []

    def load_metadata(self):
        """Load parsed metadata."""
        with open(self.metadata_path, 'r') as f:
            self.metadata = yaml.safe_load(f)

    def analyze(self) -> List[Dict[str, Any]]:
        """Analyze all transformations."""
        print(f"Analyzing transformations from {self.metadata_path}...")

        self.load_metadata()

        for trans in self.metadata.get("transformations", []):
            trans_type = trans["type"]
            trans_name = trans["name"]

            spark_equiv = self.SPARK_EQUIVALENTS.get(trans_type, {
                "spark_operation": "Unknown - Manual Conversion Required",
                "description": f"No automatic mapping defined for {trans_type}",
                "note": "This transformation type may require custom implementation"
            })

            analysis = {
                "informatica_transformation": {
                    "name": trans_name,
                    "type": trans_type,
                    "port_count": len(trans.get("ports", [])),
                    "description": trans.get("description", "")
                },
                "spark_equivalent": spark_equiv,
                "conversion_notes": self._generate_conversion_notes(trans, trans_type)
            }

            self.analysis_results.append(analysis)

        return self.analysis_results

    def _generate_conversion_notes(self, trans: Dict, trans_type: str) -> List[str]:
        """Generate specific conversion notes for a transformation."""
        notes = []

        if trans_type == "Source Qualifier":
            if trans.get("table_attributes", {}).get("Source Filter"):
                notes.append("Source filter detected - translate to WHERE clause in SQL")
            if trans.get("table_attributes", {}).get("Sql Query"):
                notes.append("SQL override detected - use custom SQL query in Spark")
            if trans.get("table_attributes", {}).get("User Defined Join"):
                notes.append("Custom join detected - translate to JOIN conditions")

        elif trans_type == "Expression":
            for port in trans.get("ports", []):
                expr = port.get("expression", "")
                if expr:
                    if "IIF" in expr:
                        notes.append(f"Port {port['name']}: IIF expression -> CASE WHEN")
                    if "DECODE" in expr:
                        notes.append(f"Port {port['name']}: DECODE -> CASE WHEN")
                    if "ERROR" in expr:
                        notes.append(f"Port {port['name']}: ERROR() function -> validation filter")

        elif trans_type == "Lookup":
            lookup_cond = trans.get("table_attributes", {}).get("Lookup Condition")
            if lookup_cond:
                notes.append(f"Lookup condition: {lookup_cond} -> translate to JOIN ON clause")
            if trans.get("table_attributes", {}).get("Lookup Policy") == "Use First Value":
                notes.append("Use First Value policy -> add LIMIT 1 or DISTINCT")

        elif trans_type == "Router":
            group_count = len([p for p in trans.get("ports", []) if p.get("port_type") == "OUTPUT"])
            notes.append(f"Router has {group_count} output groups - create {group_count} CTEs with WHERE conditions")
            notes.append("Check for DEFAULT group - handles rows that don't match any other group")

        elif trans_type == "Aggregator":
            group_by_ports = [p for p in trans.get("ports", []) if p.get("port_type") in ["INPUT", "INPUT/OUTPUT"]]
            notes.append(f"Group by {len(group_by_ports)} columns")
            agg_ports = [p for p in trans.get("ports", []) if p.get("expression") and any(fn in p.get("expression", "") for fn in ["SUM", "COUNT", "AVG", "MIN", "MAX"])]
            if agg_ports:
                notes.append(f"Contains {len(agg_ports)} aggregate expressions")

        elif trans_type == "Joiner":
            join_type = trans.get("table_attributes", {}).get("Join Type", "Normal Join")
            spark_join = self.SPARK_EQUIVALENTS["Joiner"]["join_types"].get(join_type, "INNER JOIN")
            notes.append(f"Join Type: {join_type} -> {spark_join}")

        elif trans_type == "Sorter":
            sort_ports = [p for p in trans.get("ports", []) if p.get("port_type") == "INPUT/OUTPUT"]
            notes.append(f"Sort by {len(sort_ports)} columns - check ASC/DESC order")

        return notes

    def write_analysis(self, output_path: str):
        """Write analysis results."""
        output_file = Path(output_path)
        output_file.parent.mkdir(parents=True, exist_ok=True)

        results = self.analyze()

        output_data = {
            "metadata": {
                "source_file": str(self.metadata_path.name),
                "analysis_date": datetime.now().strftime("%Y-%m-%d"),
                "total_transformations": len(results),
                "supported_types": len([r for r in results if r["spark_equivalent"].get("spark_operation") != "Unknown - Manual Conversion Required"])
            },
            "transformation_analysis": results
        }

        with open(output_file, 'w') as f:
            yaml.dump(output_data, f, default_flow_style=False, sort_keys=False)

        print(f"[OK] Analysis written to {output_file}")
        print(f"  Analyzed {len(results)} transformations")
        print(f"  Supported: {output_data['metadata']['supported_types']}/{len(results)}")


def main():
    """Main execution function with CLI argument support."""
    parser = argparse.ArgumentParser(
        description="Analyze Informatica transformations and identify Spark SQL equivalents",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # Analyze specific metadata file
  python analyze_transformations.py --metadata-file scripts-output/output/parsed_metadata/mapping_metadata.yaml

  # Specify custom output directory
  python analyze_transformations.py --metadata-file input.yaml --output-dir custom_output/

  # Use default paths (backward compatible)
  python analyze_transformations.py
        """
    )

    parser.add_argument(
        "--metadata-file",
        type=str,
        help="Path to parsed metadata YAML file"
    )

    parser.add_argument(
        "--output-dir",
        type=str,
        default="scripts-output/output/transformation_analysis",
        help="Output directory for analysis YAML file (default: scripts-output/output/transformation_analysis)"
    )

    args = parser.parse_args()

    # Backward compatibility: if no arguments provided, use default paths
    if not args.metadata_file:
        print("No input specified, using default: scripts-output/output/parsed_metadata/m_bg_stat_dim_metadata.yaml")
        args.metadata_file = "scripts-output/output/parsed_metadata/m_bg_stat_dim_metadata.yaml"

    # Validate input
    if not Path(args.metadata_file).exists():
        print(f"[ERROR] Input file not found: {args.metadata_file}")
        return 1

    # Determine output filename based on input
    input_name = Path(args.metadata_file).stem.replace("_metadata", "")
    output_file = Path(args.output_dir) / f"{input_name}_analysis.yaml"

    try:
        analyzer = TransformationAnalyzer(args.metadata_file)
        analyzer.write_analysis(str(output_file))
        print(f"\n[SUCCESS] Transformation analysis complete!")
        return 0

    except Exception as e:
        print(f"\n[ERROR] Error: {e}")
        return 1


if __name__ == "__main__":
    exit(main())
