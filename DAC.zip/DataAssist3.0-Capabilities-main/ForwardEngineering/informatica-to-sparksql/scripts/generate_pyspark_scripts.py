#!/usr/bin/env python3
"""
Generate PySpark/Spark SQL Scripts

Generates executable PySpark scripts for each Informatica mapping with
proper DataFrame operations, SQL queries, and Delta Lake merge logic.

Implements: generate_pyspark_scripts_plan.yaml
Input: scripts-output/output/parsed_metadata/m_bg_stat_dim_metadata.yaml
Output: scripts-output/output/pyspark_scripts/m_bg_stat_dim.py
"""

import yaml
from pathlib import Path


PYSPARK_TEMPLATE = '''#!/usr/bin/env python3
"""
PySpark Script: {mapping_name}

Generated from Informatica PowerCenter mapping: {mapping_name}
Source: {source_table}
Targets: {target_tables}

Implements SCD Type 1 dimension load with INSERT/UPDATE logic.
"""

from pyspark.sql import SparkSession
from pyspark.sql.functions import (
    col, when, lit, current_timestamp, to_date,
    broadcast, monotonically_increasing_id, max as spark_max
)
from delta.tables import DeltaTable
from datetime import datetime


def main():
    """Main ETL execution."""

    # Initialize Spark session
    spark = SparkSession.builder \\
        .appName("{mapping_name}") \\
        .config("spark.sql.extensions", "io.delta.sql.DeltaSparkSessionExtension") \\
        .config("spark.sql.catalog.spark_catalog", "org.apache.spark.sql.delta.catalog.DeltaCatalog") \\
        .getOrCreate()

    # Parameters (from Informatica $$PARAM)
    mis_date = spark.conf.get("migration.mis_date", datetime.now().strftime("%Y-%m-%d"))
    schema_stg = spark.conf.get("migration.schema_stg", "default")

    print(f"Running {mapping_name} for date: {{mis_date}}")

    # Step 1: Read source data
    # Informatica: Source Qualifier with filter
    df_source = spark.read \\
        .format("parquet") \\
        .load(f"{{schema_stg}}/{source_table}") \\
        .filter(
            (col("crt_dtm") >= lit(mis_date)) |
            (col("updt_dtm") >= lit(mis_date))
        ) \\
        .filter(col("dmn_nm") == lit("BGN STATUS"))

    print(f"Source records: {{df_source.count()}}")

    # Step 2: Lookup transformation
    # Informatica: Cached Lookup (LEFT join)
    df_lookup = spark.read \\
        .format("delta") \\
        .load("{target_table_dim}")

    df_with_lookup = df_source.join(
        broadcast(df_lookup.select("bg_stat_cd", "bg_stat_key")),
        on="bg_stat_cd",
        how="left"
    )

    # Step 3: Expression transformations
    # Informatica: EXP_CALCULATE_STATUS
    df_transformed = df_with_lookup \\
        .withColumn("load_status",
            when(col("bg_stat_key").isNull(), lit("INSERT"))
            .otherwise(lit("UPDATE"))
        ) \\
        .withColumn("eff_dt",
            to_date(col("eff_dt_txt"), "yyyyMMdd")
        ) \\
        .withColumn("etl_load_dtm", current_timestamp())

    # Step 4: Router transformation
    # Informatica: Router with INSERT/UPDATE groups
    df_insert = df_transformed.filter(col("load_status") == "INSERT").cache()
    df_update = df_transformed.filter(col("load_status") == "UPDATE").cache()
    df_default = df_transformed.filter(
        ~(col("load_status").isin(["INSERT", "UPDATE"]))
    )

    print(f"INSERT records: {{df_insert.count()}}")
    print(f"UPDATE records: {{df_update.count()}}")

    # Handle DEFAULT group (quarantine)
    if df_default.count() > 0:
        df_default.write.mode("append").parquet(f"error/{{mis_date}}/default_records")
        print(f"WARNING: {{df_default.count()}} records routed to DEFAULT (quarantined)")

    # Step 5: Sequence generator for INSERTs
    # Informatica: SEQ_bg_stat_key
    if df_insert.count() > 0:
        # Get current max key
        current_max = spark.read.format("delta").load("{target_table_dim}") \\
            .agg(spark_max("bg_stat_key").alias("max_key")).collect()[0]["max_key"]
        current_max = current_max if current_max else 0

        df_insert = df_insert \\
            .withColumn("row_num", monotonically_increasing_id()) \\
            .withColumn("bg_stat_key", col("row_num") + lit(current_max + 1)) \\
            .drop("row_num")

    # Step 6: Write to targets using Delta Lake merge
    # Informatica: Update Strategy (DD_INSERT/DD_UPDATE)
    target_path_dim = "{target_table_dim}"

    # Initialize Delta table if doesn't exist
    if not DeltaTable.isDeltaTable(spark, target_path_dim):
        df_insert.write.format("delta").mode("overwrite").save(target_path_dim)
        print(f"[OK] Created Delta table: {{target_path_dim}}")
    else:
        delta_table = DeltaTable.forPath(spark, target_path_dim)

        # Prepare merge data (INSERT + UPDATE)
        df_merge = df_insert.unionByName(df_update, allowMissingColumns=True)

        # Execute merge (UPSERT)
        delta_table.alias("target").merge(
            df_merge.alias("source"),
            "target.bg_stat_cd = source.bg_stat_cd"
        ).whenMatchedUpdateAll() \\
         .whenNotMatchedInsertAll() \\
         .execute()

        print(f"[OK] Merged records to {{target_path_dim}}")

    # Step 7: Write to lookup table
    target_path_lkup = "{target_table_lkup}"
    df_lkup = df_merge.select("bg_stat_cd", "bg_stat_key")

    if not DeltaTable.isDeltaTable(spark, target_path_lkup):
        df_lkup.write.format("delta").mode("overwrite").save(target_path_lkup)
    else:
        DeltaTable.forPath(spark, target_path_lkup).alias("target").merge(
            df_lkup.alias("source"),
            "target.bg_stat_cd = source.bg_stat_cd"
        ).whenMatchedUpdateAll() \\
         .whenNotMatchedInsertAll() \\
         .execute()

    print(f"[OK] Updated lookup table: {{target_path_lkup}}")

    # Step 8: Data quality validation
    # Validate no nulls in mandatory fields
    null_count = df_merge.filter(col("bg_stat_cd").isNull()).count()
    if null_count > 0:
        raise ValueError(f"Data quality error: {{null_count}} records with null bg_stat_cd")

    print("\\n[OK] ETL completed successfully")
    spark.stop()


if __name__ == "__main__":
    main()
'''


def generate_pyspark_script():
    """Generate PySpark script from metadata."""

    # Read metadata
    metadata_path = Path("scripts-output/output/parsed_metadata/m_bg_stat_dim_metadata.yaml")

    if not metadata_path.exists():
        print(f"Error: Metadata file not found: {metadata_path}")
        return

    # Read metadata with retry logic for file locks (OneDrive issue)
    import time
    max_retries = 3
    for attempt in range(max_retries):
        try:
            with open(metadata_path, 'r', encoding='utf-8') as f:
                metadata = yaml.safe_load(f)
            break
        except PermissionError as e:
            if attempt < max_retries - 1:
                print(f"[WARN] File locked, retrying in 1 second... (attempt {attempt + 1}/{max_retries})")
                time.sleep(1)
            else:
                print(f"[ERROR] Permission denied after {max_retries} attempts. Please close any programs that might have the file open:")
                print(f"        {metadata_path}")
                raise

    # Extract mapping info
    mapping_name = metadata['metadata']['name']
    sources = metadata.get('sources', [])
    targets = metadata.get('targets', [])

    source_table = sources[0]['name'] if sources else "unknown_source"
    target_tables = ', '.join([t['name'] for t in targets])
    target_table_dim = targets[0]['name'] if targets else "SC_bg_stat_dim"
    target_table_lkup = targets[1]['name'] if len(targets) > 1 else "SC_bg_stat_lkup"

    # Generate script
    output_dir = Path("scripts-output/output/pyspark_scripts")
    output_dir.mkdir(parents=True, exist_ok=True)

    script_content = PYSPARK_TEMPLATE.format(
        mapping_name=mapping_name,
        source_table=source_table,
        target_tables=target_tables,
        target_table_dim=target_table_dim,
        target_table_lkup=target_table_lkup
    )

    output_path = output_dir / f"{mapping_name}.py"
    with open(output_path, 'w') as f:
        f.write(script_content)

    print(f"[OK] PySpark script generated: {output_path}")
    print(f"  Mapping: {mapping_name}")
    print(f"  Source: {source_table}")
    print(f"  Targets: {target_tables}")


def main():
    """Main execution function."""
    generate_pyspark_script()
    print("\n[OK] PySpark script generation complete!")


if __name__ == "__main__":
    main()
