#!/usr/bin/env python3
"""
Command-Line Interface for Informatica to Spark SQL Conversion Pipeline

Orchestrates the execution of all 6 component scripts in the correct order.

Usage:
    python cli.py --all                    # Run all components
    python cli.py --component <name>       # Run specific component
    python cli.py --list                   # List all components
"""

import sys
import argparse
import subprocess
from pathlib import Path
from typing import List


class Pipeline:
    """Informatica-to-Spark conversion pipeline orchestrator."""

    COMPONENTS = [
        {
            "name": "parse_informatica_xml",
            "script": "parse_informatica_xml.py",
            "description": "Parse Informatica XML and extract metadata",
            "order": 1
        },
        {
            "name": "analyze_transformations",
            "script": "analyze_transformations.py",
            "description": "Analyze transformations and identify Spark equivalents",
            "order": 2
        },
        {
            "name": "generate_transformation_mapping",
            "script": "generate_transformation_mapping.py",
            "description": "Generate transformation mapping tables",
            "order": 3
        },
        {
            "name": "generate_source_target_mapping",
            "script": "generate_source_target_mapping.py",
            "description": "Build source-to-target field lineage",
            "order": 4
        },
        {
            "name": "generate_pyspark_scripts",
            "script": "generate_pyspark_scripts.py",
            "description": "Generate executable PySpark scripts",
            "order": 5
        },
        {
            "name": "generate_migration_doc",
            "script": "generate_migration_doc.py",
            "description": "Generate migration documentation",
            "order": 6
        }
    ]

    def __init__(self):
        self.scripts_dir = Path(__file__).parent

    def list_components(self):
        """List all available components."""
        print("\nAvailable Components:")
        print("=" * 80)
        for comp in self.COMPONENTS:
            print(f"{comp['order']}. {comp['name']}")
            print(f"   {comp['description']}")
            print(f"   Script: {comp['script']}\n")

    def run_component(self, component_name: str) -> bool:
        """Run a specific component."""
        component = next((c for c in self.COMPONENTS if c["name"] == component_name), None)

        if not component:
            print(f"Error: Component '{component_name}' not found.")
            return False

        script_path = self.scripts_dir / component["script"]

        if not script_path.exists():
            print(f"Error: Script not found: {script_path}")
            return False

        print(f"\n{'=' * 80}")
        print(f"Running: {component['name']}")
        print(f"Description: {component['description']}")
        print(f"{'=' * 80}\n")

        try:
            result = subprocess.run(
                [sys.executable, str(script_path)],
                check=True,
                capture_output=False
            )
            print(f"\n[OK] {component['name']} completed successfully\n")
            return True

        except subprocess.CalledProcessError as e:
            print(f"\n[FAIL] {component['name']} failed with exit code {e.returncode}\n")
            return False

    def run_all(self) -> bool:
        """Run all components in order."""
        print("\n" + "=" * 80)
        print("Informatica to Spark SQL Conversion Pipeline")
        print("=" * 80)

        failed_components = []

        for component in sorted(self.COMPONENTS, key=lambda x: x["order"]):
            success = self.run_component(component["name"])

            if not success:
                failed_components.append(component["name"])
                print(f"\nPipeline stopped due to failure in {component['name']}")
                break

        print("\n" + "=" * 80)
        if not failed_components:
            print("[SUCCESS] Pipeline completed successfully!")
        else:
            print(f"[FAIL] Pipeline failed. Failed components: {', '.join(failed_components)}")
        print("=" * 80 + "\n")

        return len(failed_components) == 0


def main():
    """Main CLI entry point."""
    parser = argparse.ArgumentParser(
        description="Informatica to Spark SQL Conversion Pipeline"
    )

    parser.add_argument(
        "--all",
        action="store_true",
        help="Run all components in order"
    )

    parser.add_argument(
        "--component",
        type=str,
        help="Run a specific component by name"
    )

    parser.add_argument(
        "--list",
        action="store_true",
        help="List all available components"
    )

    args = parser.parse_args()

    pipeline = Pipeline()

    if args.list:
        pipeline.list_components()
        return 0

    if args.all:
        success = pipeline.run_all()
        return 0 if success else 1

    if args.component:
        success = pipeline.run_component(args.component)
        return 0 if success else 1

    # No arguments provided
    parser.print_help()
    return 0


if __name__ == "__main__":
    sys.exit(main())
