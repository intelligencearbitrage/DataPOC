#!/usr/bin/env python3
"""
generate_dbt_schema.py

Reads agent-output/parsed/parsed_mapping.json and agent-output/converted/conversion_plan.json
to generate scripts-output/output/dbt_project/models/schema.yml with source definitions,
model definitions, and column-level tests.

Input files:
    agent-output/parsed/index.json                  — list of all parsed mappings
    agent-output/parsed/{mapping_name}.json         — one file per mapping
    agent-output/converted/{mapping_name}_plan.json — conversion plan per mapping

Output:
    scripts-output/output/dbt_project/models/schema.yml

Column test assignment rules:
    - Column ending in _id AND is first column of TARGET → not_null + unique
    - Column ending in _id NOT first → not_null only
    - Numeric columns (contains: amount, total, count) → not_null
    - Other columns → no tests added (conservative: do not fabricate)
    - DO NOT add accepted_values unless values are known from XML
    - DO NOT add relationships tests unless FK is explicitly defined in plan

Usage:
    python generate_dbt_schema.py
"""

import json
import sys
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

try:
    import yaml
    HAS_YAML = True
except ImportError:
    HAS_YAML = False

PROJECT_ROOT = Path(__file__).resolve().parent.parent.parent
PARSED_DIR = PROJECT_ROOT / "agent-output" / "parsed"
CONVERTED_DIR = PROJECT_ROOT / "agent-output" / "converted"
MODELS_DIR = PROJECT_ROOT / "scripts-output" / "output" / "dbt_project" / "models"

# Fallback column data when parsed JSON is unavailable — matches known sample XML structure
FALLBACK_SOURCES = [
    {
        "name": "orders",
        "fields": [
            {"name": "order_id", "null_type": "NOT NULL"},
            {"name": "customer_id", "null_type": "NOT NULL"},
            {"name": "order_date", "null_type": ""},
            {"name": "status", "null_type": ""},
            {"name": "amount", "null_type": "NOT NULL"},
        ],
    },
    {
        "name": "customers",
        "fields": [
            {"name": "customer_id", "null_type": "NOT NULL"},
            {"name": "customer_name", "null_type": "NOT NULL"},
            {"name": "region", "null_type": ""},
            {"name": "email", "null_type": ""},
        ],
    },
]

FALLBACK_MODELS = [
    {
        "model_name": "sales_pipeline",
        "raw_mapping_name": "m_sales_pipeline",
        "output_columns": [
            {"name": "order_id", "key_type": "PRIMARY KEY"},
            {"name": "customer_id", "key_type": "FOREIGN KEY"},
            {"name": "customer_name", "key_type": ""},
            {"name": "region", "key_type": ""},
            {"name": "order_date", "key_type": ""},
            {"name": "amount", "key_type": ""},
            {"name": "status", "key_type": ""},
        ],
        "pk_columns": ["order_id"],
        "fk_columns": [
            {"name": "customer_id", "references_model": "customers", "references_column": "customer_id"}
        ],
        "router_split_models": [],
    }
]


def assign_tests(col_name: str, is_first_col: bool, key_type: str = "") -> List[Any]:
    """
    Assign DBT tests to a column based on naming conventions and key type.

    Rules (in priority order):
    1. key_type == 'PRIMARY KEY' → not_null + unique
    2. key_type == 'FOREIGN KEY' → not_null only (relationships added separately via fk_columns)
    3. col_name ends in '_id' AND is first column → not_null + unique
    4. col_name ends in '_id' → not_null only
    5. col_name contains 'amount', 'total', or 'count' → not_null
    6. Otherwise → no tests

    Args:
        col_name: snake_case column name
        is_first_col: True if this is the first column in the target definition
        key_type: KEYTYPE attribute from TARGETFIELD (e.g., 'PRIMARY KEY', 'FOREIGN KEY', '')

    Returns:
        List of test entries (strings or dicts for parametrized tests)
    """
    name_lower = col_name.lower()
    key_lower = key_type.upper() if key_type else ""

    if key_lower == "PRIMARY KEY":
        return ["not_null", "unique"]

    if key_lower == "FOREIGN KEY":
        return ["not_null"]

    if name_lower.endswith("_id") and is_first_col:
        return ["not_null", "unique"]

    if name_lower.endswith("_id"):
        return ["not_null"]

    if any(token in name_lower for token in ("amount", "total", "count")):
        return ["not_null"]

    return []


def build_sources_section(parsed_mappings: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """
    Build the 'sources' section for schema.yml from all parsed mappings.

    Groups all SOURCE elements under a single 'raw' source. Deduplicates tables
    by name — first occurrence wins. Column tests are assigned based on NULLTYPE:
    if NULLTYPE == 'NOT NULL' → add 'not_null' test.

    Args:
        parsed_mappings: list of parsed mapping dicts loaded from agent-output/parsed/

    Returns:
        List with a single dict representing the 'raw' source and all its tables.
    """
    seen_tables: Dict[str, Dict[str, Any]] = {}  # table_name -> table_entry

    for mapping in parsed_mappings:
        for source in mapping.get("sources", []):
            table_name = source.get("name", "")
            if not table_name or table_name in seen_tables:
                continue  # Deduplicate

            raw_name = source.get("raw_name", table_name)
            columns: List[Dict[str, Any]] = []

            for field in source.get("fields", []):
                col_name = field.get("name", "")
                if not col_name:
                    continue

                col_entry: Dict[str, Any] = {
                    "name": col_name,
                    "description": f"{col_name} from {table_name}",
                }

                null_type = field.get("null_type", "")
                if null_type.upper() == "NOT NULL":
                    col_entry["tests"] = ["not_null"]

                columns.append(col_entry)

            table_entry: Dict[str, Any] = {
                "name": table_name,
                "description": f"Source table {raw_name} from Informatica PowerCenter mapping",
            }
            if columns:
                table_entry["columns"] = columns

            seen_tables[table_name] = table_entry

    if not seen_tables:
        return []

    return [
        {
            "name": "raw",
            "description": "Raw source tables from Informatica PowerCenter sources",
            "tables": list(seen_tables.values()),
        }
    ]


def build_model_columns(
    output_columns: List[Dict[str, Any]],
    fk_columns: List[Dict[str, Any]],
) -> List[Dict[str, Any]]:
    """
    Build the columns list for a single model entry in schema.yml.

    Applies test assignment rules and appends 'relationships' tests for FK columns
    that have a valid references_model and references_column.

    Args:
        output_columns: list of column dicts from the conversion plan
        fk_columns: list of FK column dicts with references_model and references_column

    Returns:
        List of column dicts with name, description, and tests.
    """
    # Build FK lookup keyed by column name for O(1) access
    fk_lookup: Dict[str, Dict[str, Any]] = {
        fk["name"]: fk for fk in fk_columns if isinstance(fk, dict) and "name" in fk
    }

    columns: List[Dict[str, Any]] = []
    for idx, col in enumerate(output_columns):
        col_name = col.get("name", "")
        if not col_name:
            continue

        key_type = col.get("key_type", "")
        is_first = idx == 0

        tests = assign_tests(col_name, is_first, key_type)

        # Append relationships test for FK columns that have explicit reference info
        if col_name in fk_lookup:
            fk_info = fk_lookup[col_name]
            ref_model = fk_info.get("references_model", "")
            ref_col = fk_info.get("references_column", "")
            if ref_model and ref_col:
                rel_test: Dict[str, Any] = {
                    "relationships": {
                        "to": f"ref('{ref_model}')",
                        "field": ref_col,
                    }
                }
                # Avoid duplicating not_null — it's already in tests from FK key_type rule
                if rel_test not in tests:
                    tests.append(rel_test)

        col_entry: Dict[str, Any] = {
            "name": col_name,
            "description": col.get("description", col_name),
        }
        if tests:
            col_entry["tests"] = tests

        columns.append(col_entry)

    return columns


def build_models_section(
    conversion_plans: List[Dict[str, Any]],
) -> List[Dict[str, Any]]:
    """
    Build the 'models' section for schema.yml from all conversion plans.

    Creates one model entry per .sql file (including router_split_models).
    Column names come from plan.output_columns — no fabricated names.

    Args:
        conversion_plans: list of conversion plan dicts from agent-output/converted/

    Returns:
        List of model dicts for the schema.yml models: section.
    """
    # Enhancement: deduplication safety net — guard against duplicate model_name in plans list
    seen_model_names: set = set()
    models: List[Dict[str, Any]] = []

    for plan in conversion_plans:
        model_name = plan.get("model_name") or plan.get("mapping_name", "")
        raw_mapping_name = plan.get("raw_mapping_name", model_name)
        output_columns = plan.get("output_columns", [])
        fk_columns = plan.get("fk_columns", [])

        if not model_name:
            print(
                f"WARNING: Conversion plan missing model_name — skipping",
                file=sys.stderr,
            )
            continue

        if model_name in seen_model_names:
            print(
                f"WARNING: Duplicate model_name '{model_name}' in conversion plans — skipping duplicate",
                file=sys.stderr,
            )
            continue
        seen_model_names.add(model_name)

        columns = build_model_columns(output_columns, fk_columns)

        model_entry: Dict[str, Any] = {
            "name": model_name,
            "description": f"DBT model converted from Informatica mapping {raw_mapping_name}",
        }
        if columns:
            model_entry["columns"] = columns
        else:
            print(
                f"WARNING: Model '{model_name}' has no output_columns in conversion plan",
                file=sys.stderr,
            )

        models.append(model_entry)

        # Handle router Strategy B split models
        for split in plan.get("router_split_models", []):
            split_name = split.get("model_name", "")
            split_columns_raw = split.get("output_columns", output_columns)
            split_fk = split.get("fk_columns", fk_columns)

            if not split_name:
                continue

            split_columns = build_model_columns(split_columns_raw, split_fk)
            split_entry: Dict[str, Any] = {
                "name": split_name,
                "description": (
                    f"DBT model (router split) converted from Informatica mapping {raw_mapping_name}"
                ),
            }
            if split_columns:
                split_entry["columns"] = split_columns
            models.append(split_entry)

    return models


def write_schema_yml(schema: Dict[str, Any], output_path: Path) -> None:
    """
    Write the schema dict to output_path as YAML.

    Uses PyYAML if available (yaml.dump with default_flow_style=False, sort_keys=False).
    Falls back to manual YAML string formatting if PyYAML is not installed.

    Args:
        schema: the full schema dict (version, sources, models)
        output_path: destination path for schema.yml
    """
    output_path.parent.mkdir(parents=True, exist_ok=True)

    if HAS_YAML:
        yaml_content = yaml.dump(
            schema,
            default_flow_style=False,
            allow_unicode=True,
            sort_keys=False,
        )
        output_path.write_text(yaml_content, encoding="utf-8")
        return

    # --- Manual YAML fallback (no PyYAML) ---
    lines: List[str] = []
    lines.append("version: 2")
    lines.append("")

    # Sources section
    sources = schema.get("sources", [])
    if sources:
        lines.append("sources:")
        for src in sources:
            lines.append(f"  - name: {src['name']}")
            if src.get("description"):
                lines.append(f"    description: \"{src['description']}\"")
            tables = src.get("tables", [])
            if tables:
                lines.append("    tables:")
                for tbl in tables:
                    lines.append(f"      - name: {tbl['name']}")
                    if tbl.get("description"):
                        lines.append(f"        description: \"{tbl['description']}\"")
                    tbl_cols = tbl.get("columns", [])
                    if tbl_cols:
                        lines.append("        columns:")
                        for col in tbl_cols:
                            lines.append(f"          - name: {col['name']}")
                            if col.get("description"):
                                lines.append(f"            description: \"{col['description']}\"")
                            col_tests = col.get("tests", [])
                            if col_tests:
                                lines.append("            tests:")
                                for t in col_tests:
                                    if isinstance(t, str):
                                        lines.append(f"              - {t}")
                                    elif isinstance(t, dict):
                                        for tk, tv in t.items():
                                            lines.append(f"              - {tk}:")
                                            if isinstance(tv, dict):
                                                for k, v in tv.items():
                                                    lines.append(f"                  {k}: {v}")
        lines.append("")

    # Models section
    models = schema.get("models", [])
    if models:
        lines.append("models:")
        for mdl in models:
            lines.append(f"  - name: {mdl['name']}")
            if mdl.get("description"):
                lines.append(f"    description: \"{mdl['description']}\"")
            mdl_cols = mdl.get("columns", [])
            if mdl_cols:
                lines.append("    columns:")
                for col in mdl_cols:
                    lines.append(f"      - name: {col['name']}")
                    if col.get("description"):
                        lines.append(f"        description: \"{col['description']}\"")
                    col_tests = col.get("tests", [])
                    if col_tests:
                        lines.append("        tests:")
                        for t in col_tests:
                            if isinstance(t, str):
                                lines.append(f"          - {t}")
                            elif isinstance(t, dict):
                                for tk, tv in t.items():
                                    lines.append(f"          - {tk}:")
                                    if isinstance(tv, dict):
                                        for k, v in tv.items():
                                            lines.append(f"              {k}: {v}")

    yaml_content = "\n".join(lines) + "\n"
    output_path.write_text(yaml_content, encoding="utf-8")


def load_parsed_mappings() -> Optional[List[Dict[str, Any]]]:
    """
    Load all parsed mapping dicts from agent-output/parsed/.

    Reads index.json to get mapping names, then loads each {mapping_name}.json.
    Returns None if no parsed data is available (caller should use fallback).

    Returns:
        List of mapping dicts, or None if index.json does not exist.
    """
    index_path = PARSED_DIR / "index.json"
    if not index_path.exists():
        return None

    try:
        index_entries = json.loads(index_path.read_text(encoding="utf-8"))
    except json.JSONDecodeError as exc:
        print(f"ERROR: Cannot parse index.json: {exc}", file=sys.stderr)
        return None

    mappings: List[Dict[str, Any]] = []
    for entry in index_entries:
        mapping_name = entry.get("mapping_name", "")
        mapping_path = PARSED_DIR / f"{mapping_name}.json"
        if not mapping_path.exists():
            print(
                f"WARNING: Mapped file not found: {mapping_path.name} — skipping",
                file=sys.stderr,
            )
            continue
        try:
            mapping_data = json.loads(mapping_path.read_text(encoding="utf-8"))
            mappings.append(mapping_data)
        except json.JSONDecodeError as exc:
            print(
                f"ERROR: Cannot parse {mapping_path.name}: {exc} — skipping",
                file=sys.stderr,
            )

    return mappings if mappings else None


def load_conversion_plans() -> Optional[List[Dict[str, Any]]]:
    """
    Load all conversion plan JSON files from agent-output/converted/.

    Primary strategy: read agent-output/parsed/index.json and load
    agent-output/converted/{mapping_name}_plan.json for each entry.
    Fallback strategy: glob("*_plan.json") if index.json does not exist.
    Deduplication: if two plans share the same model_name, log a warning
    and keep only the first occurrence.

    Returns None if no conversion plans are found (caller should use fallback).

    Returns:
        List of conversion plan dicts, or None if directory is empty / does not exist.
    """
    if not CONVERTED_DIR.exists():
        return None

    # Enhancement: load via index.json mapping; fall back to glob only if index absent
    index_path = PARSED_DIR / "index.json"
    if index_path.exists():
        # Primary: use index to determine which plan files to load
        try:
            index_entries = json.loads(index_path.read_text(encoding="utf-8"))
        except json.JSONDecodeError as exc:
            print(f"WARNING: Cannot parse index.json: {exc} — falling back to glob", file=sys.stderr)
            index_entries = None

        if index_entries is not None:
            plan_paths = []
            for entry in index_entries:
                mapping_name = entry.get("mapping_name", "")
                if not mapping_name:
                    continue
                plan_path = CONVERTED_DIR / f"{mapping_name}_plan.json"
                if plan_path.exists():
                    plan_paths.append(plan_path)
                else:
                    print(
                        f"WARNING: Expected plan file not found: {plan_path.name} — skipping",
                        file=sys.stderr,
                    )
        else:
            plan_paths = sorted(CONVERTED_DIR.glob("*_plan.json"))
    else:
        # Fallback: glob all *_plan.json files when no index.json exists
        plan_paths = sorted(CONVERTED_DIR.glob("*_plan.json"))

    plans: List[Dict[str, Any]] = []
    seen_model_names: Dict[str, str] = {}  # model_name -> source file name
    for plan_path in plan_paths:
        try:
            plan_data = json.loads(plan_path.read_text(encoding="utf-8"))
        except json.JSONDecodeError as exc:
            print(
                f"ERROR: Cannot parse {plan_path.name}: {exc} — skipping",
                file=sys.stderr,
            )
            continue

        # Enhancement: deduplicate by model_name at load time
        model_name = plan_data.get("model_name") or plan_data.get("mapping_name", "")
        if model_name and model_name in seen_model_names:
            print(
                f"WARNING: Duplicate model_name '{model_name}' in {plan_path.name} "
                f"(already loaded from {seen_model_names[model_name]}) — skipping duplicate",
                file=sys.stderr,
            )
            continue
        if model_name:
            seen_model_names[model_name] = plan_path.name

        plans.append(plan_data)

    return plans if plans else None


def build_fallback_parsed_mappings() -> List[Dict[str, Any]]:
    """
    Return fallback parsed mapping structure when agent-output/parsed/ is not available.

    Uses hardcoded column lists matching the known sample XML structure.

    Returns:
        List of mapping dicts with sources using FALLBACK_SOURCES.
    """
    return [
        {
            "mapping_name": "sales_pipeline",
            "raw_mapping_name": "m_sales_pipeline",
            "sources": FALLBACK_SOURCES,
        }
    ]


def build_fallback_conversion_plans() -> List[Dict[str, Any]]:
    """
    Return fallback conversion plan structure when agent-output/converted/ is not available.

    Uses hardcoded column lists matching the known sample XML structure.

    Returns:
        List of conversion plan dicts using FALLBACK_MODELS.
    """
    return FALLBACK_MODELS


def main() -> None:
    """
    Main entry point: read parsed mappings and conversion plans, build schema dict,
    and write scripts-output/output/dbt_project/models/schema.yml.

    Falls back to hardcoded defaults if intermediate files are not available.
    """
    if not HAS_YAML:
        print(
            "WARNING: PyYAML not installed. Using manual YAML serialization. "
            "Install with: pip install pyyaml",
            file=sys.stderr,
        )

    # --- Load inputs (with fallback) ---
    parsed_mappings = load_parsed_mappings()
    using_parsed_fallback = False
    if parsed_mappings is None:
        print(
            "INFO: agent-output/parsed/index.json not found. "
            "Using fallback source definitions. Run parse_informatica_xml.py first for real data.",
            file=sys.stderr,
        )
        parsed_mappings = build_fallback_parsed_mappings()
        using_parsed_fallback = True

    conversion_plans = load_conversion_plans()
    using_plans_fallback = False
    if conversion_plans is None:
        print(
            "INFO: No conversion plans found in agent-output/converted/. "
            "Using fallback model definitions. Run convert_transformations.py first for real data.",
            file=sys.stderr,
        )
        conversion_plans = build_fallback_conversion_plans()
        using_plans_fallback = True

    # --- Build schema sections ---
    sources_section = build_sources_section(parsed_mappings)
    models_section = build_models_section(conversion_plans)

    schema: Dict[str, Any] = {"version": 2}
    if sources_section:
        schema["sources"] = sources_section
    if models_section:
        schema["models"] = models_section

    # --- Write output ---
    output_path = MODELS_DIR / "schema.yml"
    try:
        write_schema_yml(schema, output_path)
    except IOError as exc:
        print(f"ERROR: Failed to write schema.yml: {exc}", file=sys.stderr)
        sys.exit(1)

    # --- Summary ---
    source_count = len(sources_section)
    table_count = sum(len(s.get("tables", [])) for s in sources_section)
    model_count = len(models_section)
    col_count = sum(len(m.get("columns", [])) for m in models_section)

    print(f"Written: {output_path.relative_to(PROJECT_ROOT)}")
    print(
        f"  Sources: {source_count} source group(s), {table_count} table(s)"
    )
    print(f"  Models:  {model_count} model(s), {col_count} column definition(s)")

    if using_parsed_fallback or using_plans_fallback:
        print(
            "\nNOTE: schema.yml was generated with fallback data. "
            "Run the full pipeline (cli.py all) to generate from real Informatica XML."
        )


if __name__ == "__main__":
    main()
