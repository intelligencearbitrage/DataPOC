#!/usr/bin/env python3
"""
generate_dbt_project.py

Generates dbt_project.yml, profiles.yml, and packages.yml for a DBT Snowflake project
based on the parsed Informatica PowerCenter mapping name.

The project name is derived from agent-output/parsed/index.json:
  - Uses folder_name from the first entry if available
  - Falls back to raw_mapping_name with m_ prefix stripped and snake_cased
  - Defaults to 'sales_pipeline' if no parsed data exists

IMPORTANT: profiles.yml uses env_var() for ALL credentials — no hardcoded values.

Output files:
    scripts-output/output/dbt_project/dbt_project.yml
    scripts-output/output/dbt_project/profiles.yml
    scripts-output/output/dbt_project/packages.yml

Usage:
    python generate_dbt_project.py
"""

import json
import re
import sys
from pathlib import Path
from typing import Optional

PROJECT_ROOT = Path(__file__).resolve().parent.parent.parent
PARSED_DIR = PROJECT_ROOT / "agent-output" / "parsed"
DBT_PROJECT_DIR = PROJECT_ROOT / "scripts-output" / "output" / "dbt_project"

DEFAULT_PROJECT_NAME = "sales_pipeline"


def to_snake_case(name: str) -> str:
    """
    Normalize a name to snake_case: lowercase, replace spaces/hyphens with underscores,
    remove non-alphanumeric characters.

    Args:
        name: raw name string

    Returns:
        snake_case normalized string
    """
    if not name:
        return name
    result = re.sub(r"[\s\-]+", "_", name)
    result = re.sub(r"[^\w]", "_", result)
    # Collapse multiple underscores
    result = re.sub(r"_+", "_", result)
    return result.lower().strip("_")


def derive_project_name(mapping_name: str) -> str:
    """
    Derive a DBT project name from an Informatica mapping name.

    Steps:
    1. Convert to snake_case lowercase
    2. Strip leading 'm_' prefix if present
    3. Strip leading digits and underscores

    Args:
        mapping_name: raw mapping name (e.g., 'm_sales_pipeline', 'M_Orders_Fact')

    Returns:
        Clean snake_case project name (e.g., 'sales_pipeline', 'orders_fact')
    """
    name = to_snake_case(mapping_name)
    if name.startswith("m_"):
        name = name[2:]
    # Strip any leading digits or underscores that remain
    name = re.sub(r"^[0-9_]+", "", name)
    return name if name else DEFAULT_PROJECT_NAME


def load_project_name_from_index() -> Optional[str]:
    """
    Read agent-output/parsed/index.json and derive the project name.

    Priority:
    1. folder_name from the first entry (normalized to snake_case)
    2. raw_mapping_name from the first entry (stripped of m_ prefix)

    Returns:
        Derived project name string, or None if index does not exist / cannot be parsed.
    """
    index_path = PARSED_DIR / "index.json"
    if not index_path.exists():
        return None

    try:
        entries = json.loads(index_path.read_text(encoding="utf-8"))
    except json.JSONDecodeError as exc:
        print(
            f"WARNING: Cannot parse index.json: {exc}. "
            f"Using default project name '{DEFAULT_PROJECT_NAME}'.",
            file=sys.stderr,
        )
        return None

    if not entries:
        return None

    first = entries[0]

    # Prefer folder_name — it is the repository folder and best represents the project
    folder_name = first.get("folder_name", "")
    if folder_name:
        normalized = to_snake_case(folder_name)
        if normalized:
            return normalized

    # Fall back to mapping name
    raw_mapping_name = first.get("raw_mapping_name", first.get("mapping_name", ""))
    if raw_mapping_name:
        return derive_project_name(raw_mapping_name)

    return None


def generate_dbt_project_yml(project_name: str) -> str:
    """
    Render the dbt_project.yml content for the given project name.

    Profile name is always 'snowflake_profile' — must match the key in profiles.yml.
    Materialization defaults to 'view'; individual models override via {{ config() }}.

    Args:
        project_name: snake_case project name

    Returns:
        String content of dbt_project.yml
    """
    return f"""name: '{project_name}'
version: '1.0.0'
config-version: 2

profile: 'snowflake_profile'

model-paths: ['models']
analysis-paths: ['analyses']
test-paths: ['tests']
seed-paths: ['seeds']
macro-paths: ['macros']
snapshot-paths: ['snapshots']

target-path: 'target'
clean-targets:
  - 'target'
  - 'dbt_packages'

require-dbt-version: '>=1.5.0'

models:
  {project_name}:
    +materialized: view
    # Materialization is set per-model via {{{{ config() }}}} in each .sql file
"""


def generate_profiles_yml(project_name: str) -> str:
    """
    Render the profiles.yml content for the given project name.

    CRITICAL: All credentials use env_var() — no hardcoded account, user, or password.
    Both 'dev' and 'prod' targets are included.

    Args:
        project_name: snake_case project name (not used in template — profile name is fixed)

    Returns:
        String content of profiles.yml
    """
    # NOTE: profile key is always 'snowflake_profile' — must match dbt_project.yml 'profile:' field
    return """snowflake_profile:
  target: dev
  outputs:
    dev:
      type: snowflake
      account: "{{ env_var('SNOWFLAKE_ACCOUNT') }}"
      user: "{{ env_var('SNOWFLAKE_USER') }}"
      password: "{{ env_var('SNOWFLAKE_PASSWORD') }}"
      role: "{{ env_var('SNOWFLAKE_ROLE', 'TRANSFORMER') }}"
      database: "{{ env_var('SNOWFLAKE_DATABASE') }}"
      warehouse: "{{ env_var('SNOWFLAKE_WAREHOUSE', 'COMPUTE_WH') }}"
      schema: dev
      threads: 4
      client_session_keep_alive: false
    prod:
      type: snowflake
      account: "{{ env_var('SNOWFLAKE_ACCOUNT') }}"
      user: "{{ env_var('SNOWFLAKE_USER') }}"
      password: "{{ env_var('SNOWFLAKE_PASSWORD') }}"
      role: "{{ env_var('SNOWFLAKE_ROLE', 'TRANSFORMER') }}"
      database: "{{ env_var('SNOWFLAKE_DATABASE') }}"
      warehouse: "{{ env_var('SNOWFLAKE_WAREHOUSE', 'COMPUTE_WH') }}"
      schema: prod
      threads: 8
      client_session_keep_alive: false
"""


def generate_packages_yml() -> str:
    """
    Render the packages.yml content.

    Pins dbt-labs/dbt_utils to >=1.0.0,<2.0.0 (compatible with DBT Core 1.5+).

    Returns:
        String content of packages.yml
    """
    return """packages:
  - package: dbt-labs/dbt_utils
    version: [">=1.0.0", "<2.0.0"]
"""


def write_file(path: Path, content: str, label: str) -> None:
    """
    Write content to path, creating parent directories as needed.
    Idempotent: overwrites unconditionally.

    Args:
        path: destination file path
        content: string content to write
        label: human-readable label for log output
    """
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(content, encoding="utf-8")
        print(f"Written: {path.relative_to(PROJECT_ROOT)}")
    except IOError as exc:
        print(f"ERROR: Failed to write {label}: {exc}", file=sys.stderr)
        sys.exit(1)


def validate_no_hardcoded_credentials(profiles_content: str) -> bool:
    """
    Verify that profiles.yml content does not contain hardcoded credential values.

    Checks that account, user, and password lines all use env_var() syntax.
    Returns True if safe, False if hardcoded values are detected.

    Args:
        profiles_content: rendered profiles.yml string

    Returns:
        True if all credentials use env_var(), False otherwise
    """
    import re as _re
    # These keys must ONLY contain env_var() — not bare strings
    sensitive_patterns = [
        r"account:\s+['\"]?(?!.*env_var)[\w\.\-]+['\"]?",
        r"user:\s+['\"]?(?!.*env_var)[A-Za-z][\w]+['\"]?",
        r"password:\s+['\"]?(?!.*env_var)[\w]+['\"]?",
    ]
    for pattern in sensitive_patterns:
        if _re.search(pattern, profiles_content):
            print(
                "ERROR: profiles.yml contains what appears to be a hardcoded credential. "
                "All credentials must use env_var().",
                file=sys.stderr,
            )
            return False
    return True


def main() -> None:
    """
    Main entry point: derive project name, render all three config files, and write them.

    Falls back to DEFAULT_PROJECT_NAME if index.json is not available.
    """
    DBT_PROJECT_DIR.mkdir(parents=True, exist_ok=True)

    # --- Derive project name ---
    project_name = load_project_name_from_index()
    if project_name:
        print(f"Derived project name from index.json: '{project_name}'")
    else:
        project_name = DEFAULT_PROJECT_NAME
        print(
            f"INFO: agent-output/parsed/index.json not found. "
            f"Using default project name '{project_name}'. "
            "Run parse_informatica_xml.py first for a name derived from real data.",
            file=sys.stderr,
        )

    # --- Render content ---
    dbt_project_content = generate_dbt_project_yml(project_name)
    profiles_content = generate_profiles_yml(project_name)
    packages_content = generate_packages_yml()

    # --- Security check: ensure no hardcoded credentials ---
    if not validate_no_hardcoded_credentials(profiles_content):
        sys.exit(1)

    # --- Write files ---
    write_file(DBT_PROJECT_DIR / "dbt_project.yml", dbt_project_content, "dbt_project.yml")
    write_file(DBT_PROJECT_DIR / "profiles.yml", profiles_content, "profiles.yml")
    write_file(DBT_PROJECT_DIR / "packages.yml", packages_content, "packages.yml")

    print(
        f"\nDone. DBT project config written to: "
        f"{DBT_PROJECT_DIR.relative_to(PROJECT_ROOT)}"
    )
    print(
        "\nNOTE: In production, profiles.yml should be placed at ~/.dbt/profiles.yml "
        "(not inside the DBT project directory). The copy here is for reference only."
    )
    print(
        "\nSet required environment variables before running dbt:\n"
        "  export SNOWFLAKE_ACCOUNT=<your-account>\n"
        "  export SNOWFLAKE_USER=<your-user>\n"
        "  export SNOWFLAKE_PASSWORD=<your-password>\n"
        "  export SNOWFLAKE_DATABASE=<your-database>"
    )


if __name__ == "__main__":
    main()
