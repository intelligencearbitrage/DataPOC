#!/usr/bin/env python3
"""
generate_sample_inputs.py

Generates medium-complexity Informatica PowerCenter XML sample files:
- user-config/inputs/sample_mapping.xml: Mapping with 3 source tables and all 7 transformation types
  (Source Qualifier, Joiner, Lookup Procedure, Expression, Aggregator, Filter, Router)
- user-config/inputs/sample_workflow.xml: Workflow with one session referencing the mapping

All SOURCE, TARGET, TRANSFORMATION, and CONNECTOR elements are direct children of MAPPING.
FOLDER NAME is consistent across both files for session-to-mapping linkage.

Usage:
    python generate_sample_inputs.py
"""

import sys
import xml.etree.ElementTree as ET
from pathlib import Path
from typing import Dict, List, Optional

PROJECT_ROOT = Path(__file__).resolve().parent.parent.parent
INPUTS_DIR = PROJECT_ROOT / "user-config" / "inputs"

MAPPING_NAME = "m_sales_pipeline"
WORKFLOW_NAME = "wf_sales_pipeline"
SESSION_NAME = "s_sales_pipeline"
REPO_NAME = "sample_repo"
FOLDER_NAME = "sales_folder"


# ---------------------------------------------------------------------------
# Source builders
# ---------------------------------------------------------------------------

def create_source_orders() -> ET.Element:
    """Create SOURCE element for the orders table."""
    source = ET.Element("SOURCE", attrib={
        "NAME": "orders",
        "DBDNAME": "SALES_DB",
        "DBTYPE": "Oracle",
        "SCHEMA": "dbo",
    })
    fields = [
        ("order_id",    "integer", "10", "0", "NOT NULL", "PRIMARY KEY"),
        ("customer_id", "integer", "10", "0", "NOT NULL", "FOREIGN KEY"),
        ("amount",      "decimal", "18", "2", "NOT NULL", "NOT A KEY"),
        ("order_date",  "date",    "19", "0", "NOT NULL", "NOT A KEY"),
        ("status",      "varchar", "50", "0", "NULL",     "NOT A KEY"),
    ]
    for name, dtype, precision, scale, nulltype, keytype in fields:
        ET.SubElement(source, "SOURCEFIELD", attrib={
            "NAME":      name,
            "DATATYPE":  dtype,
            "PRECISION": precision,
            "SCALE":     scale,
            "NULLTYPE":  nulltype,
            "KEYTYPE":   keytype,
        })
    return source


def create_source_customers() -> ET.Element:
    """Create SOURCE element for the customers table."""
    source = ET.Element("SOURCE", attrib={
        "NAME": "customers",
        "DBDNAME": "SALES_DB",
        "DBTYPE": "Oracle",
        "SCHEMA": "dbo",
    })
    fields = [
        ("customer_id",     "integer", "10", "0", "NOT NULL", "PRIMARY KEY"),
        ("customer_name",   "varchar", "100", "0", "NOT NULL", "NOT A KEY"),
        ("customer_region", "varchar", "50",  "0", "NOT NULL", "NOT A KEY"),
        ("customer_type",   "varchar", "50",  "0", "NULL",     "NOT A KEY"),
    ]
    for name, dtype, precision, scale, nulltype, keytype in fields:
        ET.SubElement(source, "SOURCEFIELD", attrib={
            "NAME":      name,
            "DATATYPE":  dtype,
            "PRECISION": precision,
            "SCALE":     scale,
            "NULLTYPE":  nulltype,
            "KEYTYPE":   keytype,
        })
    return source


def create_source_dim_customer() -> ET.Element:
    """Create SOURCE element for the dim_customer lookup table."""
    source = ET.Element("SOURCE", attrib={
        "NAME": "dim_customer",
        "DBDNAME": "DW_DB",
        "DBTYPE": "Oracle",
        "SCHEMA": "dbo",
    })
    fields = [
        ("customer_id",     "integer", "10",  "0", "NOT NULL", "PRIMARY KEY"),
        ("customer_name",   "varchar", "100", "0", "NOT NULL", "NOT A KEY"),
        ("customer_region", "varchar", "50",  "0", "NOT NULL", "NOT A KEY"),
    ]
    for name, dtype, precision, scale, nulltype, keytype in fields:
        ET.SubElement(source, "SOURCEFIELD", attrib={
            "NAME":      name,
            "DATATYPE":  dtype,
            "PRECISION": precision,
            "SCALE":     scale,
            "NULLTYPE":  nulltype,
            "KEYTYPE":   keytype,
        })
    return source


# ---------------------------------------------------------------------------
# Target builder
# ---------------------------------------------------------------------------

def create_target_fact_sales() -> ET.Element:
    """Create TARGET element for the fact_sales table."""
    target = ET.Element("TARGET", attrib={
        "NAME": "fact_sales",
        "DBDNAME": "DW_DB",
        "DBTYPE": "Snowflake",
        "SCHEMA": "dbo",
    })
    fields = [
        ("customer_id",      "integer", "10",  "0", "PRIMARY KEY"),
        ("customer_name",    "varchar", "100", "0", "NOT A KEY"),
        ("customer_region",  "varchar", "50",  "0", "NOT A KEY"),
        ("total_amount",     "decimal", "18",  "2", "NOT A KEY"),
        ("total_net_amount", "decimal", "18",  "2", "NOT A KEY"),
        ("order_count",      "integer", "10",  "0", "NOT A KEY"),
    ]
    for name, dtype, precision, scale, keytype in fields:
        ET.SubElement(target, "TARGETFIELD", attrib={
            "NAME":      name,
            "DATATYPE":  dtype,
            "PRECISION": precision,
            "SCALE":     scale,
            "KEYTYPE":   keytype,
        })
    return target


# ---------------------------------------------------------------------------
# Transformation builders
# ---------------------------------------------------------------------------

def create_transformation_sq_orders() -> ET.Element:
    """
    Create SOURCE QUALIFIER transformation for orders.
    TYPE: 'Source Qualifier'
    Ports: OUTPUT only (passthrough from SOURCE).
    """
    t = ET.Element("TRANSFORMATION", attrib={
        "NAME":    "SQ_orders",
        "TYPE":    "Source Qualifier",
        "ISACTIVE": "YES",
    })
    # Table attributes
    ET.SubElement(t, "TABLEATTRIBUTE", attrib={"NAME": "Sql Query", "VALUE": ""})
    ET.SubElement(t, "TABLEATTRIBUTE", attrib={"NAME": "Filter",    "VALUE": "amount > 0"})
    ET.SubElement(t, "TABLEATTRIBUTE", attrib={"NAME": "User Defined Join", "VALUE": ""})
    # Ports — all OUTPUT
    ports = [
        ("order_id",    "integer", "10", "0"),
        ("customer_id", "integer", "10", "0"),
        ("amount",      "decimal", "18", "2"),
        ("order_date",  "date",    "19", "0"),
        ("status",      "varchar", "50", "0"),
    ]
    for name, dtype, precision, scale in ports:
        ET.SubElement(t, "TRANSFORMFIELD", attrib={
            "NAME":       name,
            "DATATYPE":   dtype,
            "PORTTYPE":   "OUTPUT",
            "PRECISION":  precision,
            "SCALE":      scale,
            "EXPRESSION": "",
        })
    return t


def create_transformation_sq_customers() -> ET.Element:
    """
    Create SOURCE QUALIFIER transformation for customers.
    TYPE: 'Source Qualifier'
    Ports: OUTPUT only (passthrough from SOURCE).
    """
    t = ET.Element("TRANSFORMATION", attrib={
        "NAME":     "SQ_customers",
        "TYPE":     "Source Qualifier",
        "ISACTIVE": "YES",
    })
    ET.SubElement(t, "TABLEATTRIBUTE", attrib={"NAME": "Sql Query", "VALUE": ""})
    ET.SubElement(t, "TABLEATTRIBUTE", attrib={"NAME": "Filter",    "VALUE": ""})
    ET.SubElement(t, "TABLEATTRIBUTE", attrib={"NAME": "User Defined Join", "VALUE": ""})
    ports = [
        ("customer_id",     "integer", "10",  "0"),
        ("customer_name",   "varchar", "100", "0"),
        ("customer_region", "varchar", "50",  "0"),
        ("customer_type",   "varchar", "50",  "0"),
    ]
    for name, dtype, precision, scale in ports:
        ET.SubElement(t, "TRANSFORMFIELD", attrib={
            "NAME":       name,
            "DATATYPE":   dtype,
            "PORTTYPE":   "OUTPUT",
            "PRECISION":  precision,
            "SCALE":      scale,
            "EXPRESSION": "",
        })
    return t


def create_transformation_jnr_orders_customers() -> ET.Element:
    """
    Create JOINER transformation joining orders (MASTER) and customers (DETAIL).
    TYPE: 'Joiner'
    INPUTTYPE MASTER = orders side; INPUTTYPE DETAIL = customers side.
    """
    t = ET.Element("TRANSFORMATION", attrib={
        "NAME":     "JNR_orders_customers",
        "TYPE":     "Joiner",
        "ISACTIVE": "YES",
    })
    ET.SubElement(t, "TABLEATTRIBUTE", attrib={
        "NAME":  "Join Type",
        "VALUE": "Normal Join",
    })
    ET.SubElement(t, "TABLEATTRIBUTE", attrib={
        "NAME":  "Join Condition",
        "VALUE": "orders.customer_id = customers.customer_id",
    })
    # INPUT ports — MASTER side (orders)
    master_ports = [
        ("order_id",    "integer", "10", "0"),
        ("customer_id", "integer", "10", "0"),
        ("amount",      "decimal", "18", "2"),
        ("order_date",  "date",    "19", "0"),
        ("status",      "varchar", "50", "0"),
    ]
    for name, dtype, precision, scale in master_ports:
        ET.SubElement(t, "TRANSFORMFIELD", attrib={
            "NAME":       name,
            "DATATYPE":   dtype,
            "PORTTYPE":   "INPUT",
            "INPUTTYPE":  "MASTER",
            "PRECISION":  precision,
            "SCALE":      scale,
            "EXPRESSION": "",
        })
    # INPUT ports — DETAIL side (customers); prefix cust_ to avoid name collision on customer_id
    detail_ports = [
        ("cust_customer_id",     "integer", "10",  "0"),
        ("customer_name",        "varchar", "100", "0"),
        ("customer_region",      "varchar", "50",  "0"),
        ("customer_type",        "varchar", "50",  "0"),
    ]
    for name, dtype, precision, scale in detail_ports:
        ET.SubElement(t, "TRANSFORMFIELD", attrib={
            "NAME":       name,
            "DATATYPE":   dtype,
            "PORTTYPE":   "INPUT",
            "INPUTTYPE":  "DETAIL",
            "PRECISION":  precision,
            "SCALE":      scale,
            "EXPRESSION": "",
        })
    # OUTPUT ports (combined result)
    output_ports = [
        ("order_id",        "integer", "10",  "0"),
        ("customer_id",     "integer", "10",  "0"),
        ("amount",          "decimal", "18",  "2"),
        ("order_date",      "date",    "19",  "0"),
        ("status",          "varchar", "50",  "0"),
        ("customer_name",   "varchar", "100", "0"),
        ("customer_region", "varchar", "50",  "0"),
        ("customer_type",   "varchar", "50",  "0"),
    ]
    for name, dtype, precision, scale in output_ports:
        ET.SubElement(t, "TRANSFORMFIELD", attrib={
            "NAME":       name,
            "DATATYPE":   dtype,
            "PORTTYPE":   "OUTPUT",
            "PRECISION":  precision,
            "SCALE":      scale,
            "EXPRESSION": "",
        })
    return t


def create_transformation_lkp_dim_customer() -> ET.Element:
    """
    Create LOOKUP PROCEDURE transformation against dim_customer.
    TYPE: 'Lookup Procedure'
    Lookup table name must match a SOURCE NAME so the parser exercises source() resolution.
    """
    t = ET.Element("TRANSFORMATION", attrib={
        "NAME":     "LKP_dim_customer",
        "TYPE":     "Lookup Procedure",
        "ISACTIVE": "YES",
    })
    ET.SubElement(t, "TABLEATTRIBUTE", attrib={
        "NAME":  "Lookup table name",
        "VALUE": "dim_customer",
    })
    ET.SubElement(t, "TABLEATTRIBUTE", attrib={
        "NAME":  "Lookup condition",
        "VALUE": "dim_customer.customer_id = customer_id",
    })
    ET.SubElement(t, "TABLEATTRIBUTE", attrib={
        "NAME":  "Connection Information",
        "VALUE": "DW_DB",
    })
    # INPUT port — lookup key
    ET.SubElement(t, "TRANSFORMFIELD", attrib={
        "NAME":       "customer_id",
        "DATATYPE":   "integer",
        "PORTTYPE":   "INPUT",
        "PRECISION":  "10",
        "SCALE":      "0",
        "EXPRESSION": "",
    })
    # OUTPUT port — looked-up region (aliased to distinguish from JNR output)
    ET.SubElement(t, "TRANSFORMFIELD", attrib={
        "NAME":       "lkp_customer_region",
        "DATATYPE":   "varchar",
        "PORTTYPE":   "OUTPUT",
        "PRECISION":  "50",
        "SCALE":      "0",
        "EXPRESSION": "customer_region",
    })
    return t


def create_transformation_exp_calculate_metrics() -> ET.Element:
    """
    Create EXPRESSION transformation with VARIABLE port for tax calculation.
    TYPE: 'Expression'
    VARIABLE port v_tax_rate is referenced by OUTPUT port tax_amount (exercises inline expansion).
    """
    t = ET.Element("TRANSFORMATION", attrib={
        "NAME":     "EXP_calculate_metrics",
        "TYPE":     "Expression",
        "ISACTIVE": "YES",
    })
    # INPUT ports
    input_ports = [
        ("order_id",            "integer", "10",  "0"),
        ("customer_id",         "integer", "10",  "0"),
        ("amount",              "decimal", "18",  "2"),
        ("order_date",          "date",    "19",  "0"),
        ("status",              "varchar", "50",  "0"),
        ("customer_name",       "varchar", "100", "0"),
        ("customer_region",     "varchar", "50",  "0"),
        ("lkp_customer_region", "varchar", "50",  "0"),
    ]
    for name, dtype, precision, scale in input_ports:
        ET.SubElement(t, "TRANSFORMFIELD", attrib={
            "NAME":       name,
            "DATATYPE":   dtype,
            "PORTTYPE":   "INPUT",
            "PRECISION":  precision,
            "SCALE":      scale,
            "EXPRESSION": "",
        })
    # VARIABLE port — internal computation only, must NOT appear in SELECT list
    ET.SubElement(t, "TRANSFORMFIELD", attrib={
        "NAME":       "v_tax_rate",
        "DATATYPE":   "decimal",
        "PORTTYPE":   "VARIABLE",
        "PRECISION":  "5",
        "SCALE":      "4",
        "EXPRESSION": "IIF(customer_region = 'US', 0.08, 0.05)",
    })
    # OUTPUT ports
    output_ports_with_expr = [
        ("order_id",        "integer", "10",  "0", "order_id"),
        ("customer_id",     "integer", "10",  "0", "customer_id"),
        ("amount",          "decimal", "18",  "2", "amount"),
        ("order_date",      "date",    "19",  "0", "order_date"),
        ("status",          "varchar", "50",  "0", "status"),
        ("customer_name",   "varchar", "100", "0", "customer_name"),
        ("customer_region", "varchar", "50",  "0", "customer_region"),
        # tax_amount references VARIABLE v_tax_rate — exercises inline expansion
        ("tax_amount",      "decimal", "18",  "2", "amount * v_tax_rate"),
        # net_amount references tax_amount output
        ("net_amount",      "decimal", "18",  "2", "amount + tax_amount"),
    ]
    for name, dtype, precision, scale, expr in output_ports_with_expr:
        ET.SubElement(t, "TRANSFORMFIELD", attrib={
            "NAME":       name,
            "DATATYPE":   dtype,
            "PORTTYPE":   "OUTPUT",
            "PRECISION":  precision,
            "SCALE":      scale,
            "EXPRESSION": expr,
        })
    return t


def create_transformation_agg_sales_by_customer() -> ET.Element:
    """
    Create AGGREGATOR transformation grouping by customer and region.
    TYPE: 'Aggregator'
    GROUPBY='YES' ports drive the GROUP BY clause; aggregate OUTPUT ports have SUM/COUNT expressions.
    """
    t = ET.Element("TRANSFORMATION", attrib={
        "NAME":     "AGG_sales_by_customer",
        "TYPE":     "Aggregator",
        "ISACTIVE": "YES",
    })
    ET.SubElement(t, "TABLEATTRIBUTE", attrib={"NAME": "Sorted Input", "VALUE": "NO"})

    # INPUT ports
    input_ports = [
        # name, dtype, precision, scale, groupby
        ("customer_id",     "integer", "10",  "0", "YES"),
        ("customer_name",   "varchar", "100", "0", "YES"),
        ("customer_region", "varchar", "50",  "0", "YES"),
        ("amount",          "decimal", "18",  "2", "NO"),
        ("net_amount",      "decimal", "18",  "2", "NO"),
    ]
    for name, dtype, precision, scale, groupby in input_ports:
        ET.SubElement(t, "TRANSFORMFIELD", attrib={
            "NAME":       name,
            "DATATYPE":   dtype,
            "PORTTYPE":   "INPUT",
            "PRECISION":  precision,
            "SCALE":      scale,
            "EXPRESSION": "",
            "GROUPBY":    groupby,
        })
    # OUTPUT ports — group-by passthrough columns
    groupby_output_ports = [
        ("customer_id",     "integer", "10",  "0", "YES"),
        ("customer_name",   "varchar", "100", "0", "YES"),
        ("customer_region", "varchar", "50",  "0", "YES"),
    ]
    for name, dtype, precision, scale, groupby in groupby_output_ports:
        ET.SubElement(t, "TRANSFORMFIELD", attrib={
            "NAME":       name,
            "DATATYPE":   dtype,
            "PORTTYPE":   "OUTPUT",
            "PRECISION":  precision,
            "SCALE":      scale,
            "EXPRESSION": name,
            "GROUPBY":    groupby,
        })
    # OUTPUT ports — aggregate expressions
    agg_output_ports = [
        ("total_amount",     "decimal", "18", "2", "SUM(amount)",    "NO"),
        ("total_net_amount", "decimal", "18", "2", "SUM(net_amount)", "NO"),
        ("order_count",      "integer", "10", "0", "COUNT(*)",       "NO"),
    ]
    for name, dtype, precision, scale, expr, groupby in agg_output_ports:
        ET.SubElement(t, "TRANSFORMFIELD", attrib={
            "NAME":       name,
            "DATATYPE":   dtype,
            "PORTTYPE":   "OUTPUT",
            "PRECISION":  precision,
            "SCALE":      scale,
            "EXPRESSION": expr,
            "GROUPBY":    groupby,
        })
    return t


def create_transformation_fil_active_orders() -> ET.Element:
    """
    Create FILTER transformation keeping rows with positive total_amount.
    TYPE: 'Filter'
    All INPUT ports pass through as corresponding OUTPUT ports.
    Condition uses only fields actually present at this stage (post-AGG):
    customer_id, customer_name, customer_region, total_amount, total_net_amount, order_count.
    """
    t = ET.Element("TRANSFORMATION", attrib={
        "NAME":     "FIL_active_orders",
        "TYPE":     "Filter",
        "ISACTIVE": "YES",
    })
    ET.SubElement(t, "TABLEATTRIBUTE", attrib={
        "NAME":  "Filter Condition",
        "VALUE": "total_amount > 0",
    })
    ports = [
        ("customer_id",      "integer", "10",  "0"),
        ("customer_name",    "varchar", "100", "0"),
        ("customer_region",  "varchar", "50",  "0"),
        ("total_amount",     "decimal", "18",  "2"),
        ("total_net_amount", "decimal", "18",  "2"),
        ("order_count",      "integer", "10",  "0"),
    ]
    for name, dtype, precision, scale in ports:
        # INPUT
        ET.SubElement(t, "TRANSFORMFIELD", attrib={
            "NAME":       name,
            "DATATYPE":   dtype,
            "PORTTYPE":   "INPUT",
            "PRECISION":  precision,
            "SCALE":      scale,
            "EXPRESSION": "",
        })
    for name, dtype, precision, scale in ports:
        # OUTPUT (same fields — Filter passes through unchanged)
        ET.SubElement(t, "TRANSFORMFIELD", attrib={
            "NAME":       name,
            "DATATYPE":   dtype,
            "PORTTYPE":   "OUTPUT",
            "PRECISION":  precision,
            "SCALE":      scale,
            "EXPRESSION": name,
        })
    return t


def create_transformation_rtr_route_by_region() -> ET.Element:
    """
    Create ROUTER transformation routing rows by customer_region.
    TYPE: 'Router'
    3 groups: US_ORDERS, EU_ORDERS, DEFAULT (catch-all).
    All groups feed the same TARGET so convert_transformations.py uses Strategy A (CASE WHEN).
    Only INPUT ports — Router does not have separate OUTPUT TRANSFORMFIELD entries per group.
    """
    t = ET.Element("TRANSFORMATION", attrib={
        "NAME":     "RTR_route_by_region",
        "TYPE":     "Router",
        "ISACTIVE": "YES",
    })
    # INPUT ports
    ports = [
        ("customer_id",      "integer", "10",  "0"),
        ("customer_name",    "varchar", "100", "0"),
        ("customer_region",  "varchar", "50",  "0"),
        ("total_amount",     "decimal", "18",  "2"),
        ("total_net_amount", "decimal", "18",  "2"),
        ("order_count",      "integer", "10",  "0"),
    ]
    for name, dtype, precision, scale in ports:
        ET.SubElement(t, "TRANSFORMFIELD", attrib={
            "NAME":       name,
            "DATATYPE":   dtype,
            "PORTTYPE":   "INPUT",
            "PRECISION":  precision,
            "SCALE":      scale,
            "EXPRESSION": "",
        })
    # Router output groups (TRANSFORMGROUP elements)
    ET.SubElement(t, "TRANSFORMGROUP", attrib={
        "NAME":       "US_ORDERS",
        "EXPRESSION": "customer_region = 'US'",
    })
    ET.SubElement(t, "TRANSFORMGROUP", attrib={
        "NAME":       "EU_ORDERS",
        "EXPRESSION": "customer_region = 'EU'",
    })
    ET.SubElement(t, "TRANSFORMGROUP", attrib={
        "NAME":       "DEFAULT",
        "EXPRESSION": "",
    })
    return t


# ---------------------------------------------------------------------------
# Connector builders
# ---------------------------------------------------------------------------

def _connector(
    from_instance: str,
    from_instance_type: str,
    from_field: str,
    to_instance: str,
    to_instance_type: str,
    to_field: str,
    from_group: str = "",
    to_group: str = "",
) -> ET.Element:
    """Helper: create a single CONNECTOR element."""
    return ET.Element("CONNECTOR", attrib={
        "FROMINSTANCE":     from_instance,
        "FROMINSTANCETYPE": from_instance_type,
        "FROMFIELD":        from_field,
        "TOINSTANCE":       to_instance,
        "TOINSTANCETYPE":   to_instance_type,
        "TOFIELD":          to_field,
        "FROMGROUP":        from_group,
        "TOGROUP":          to_group,
    })


def create_connectors() -> List[ET.Element]:
    """
    Create all CONNECTOR elements wiring the transformation chain:

    orders SOURCE -> SQ_orders -> JNR_orders_customers (MASTER side)
    customers SOURCE -> SQ_customers -> JNR_orders_customers (DETAIL side)
    JNR_orders_customers -> LKP_dim_customer (customer_id lookup key)
    JNR_orders_customers -> EXP_calculate_metrics
    LKP_dim_customer -> EXP_calculate_metrics (lkp_customer_region)
    EXP_calculate_metrics -> AGG_sales_by_customer
    AGG_sales_by_customer -> FIL_active_orders
    FIL_active_orders -> RTR_route_by_region
    RTR_route_by_region (all groups) -> fact_sales TARGET
    """
    connectors: List[ET.Element] = []

    SQ_T = "Source Qualifier"
    JNR_T = "Joiner"
    LKP_T = "Lookup Procedure"
    EXP_T = "Expression"
    AGG_T = "Aggregator"
    FIL_T = "Filter"
    RTR_T = "Router"
    TGT_T = "Target Definition"

    # ---- orders SOURCE -> SQ_orders ----------------------------------------
    for field in ["order_id", "customer_id", "amount", "order_date", "status"]:
        connectors.append(_connector(
            "orders", "Source Definition",
            field,
            "SQ_orders", SQ_T,
            field,
        ))

    # ---- customers SOURCE -> SQ_customers ------------------------------------
    for field in ["customer_id", "customer_name", "customer_region", "customer_type"]:
        connectors.append(_connector(
            "customers", "Source Definition",
            field,
            "SQ_customers", SQ_T,
            field,
        ))

    # ---- SQ_orders -> JNR_orders_customers (MASTER side) --------------------
    # SQ_orders output names map to JNR MASTER INPUT names (same names)
    for field in ["order_id", "customer_id", "amount", "order_date", "status"]:
        connectors.append(_connector(
            "SQ_orders", SQ_T,
            field,
            "JNR_orders_customers", JNR_T,
            field,
            to_group="MASTER",
        ))

    # ---- SQ_customers -> JNR_orders_customers (DETAIL side) -----------------
    # SQ_customers output fields map to JNR DETAIL INPUT names
    # customer_id on customers side maps to cust_customer_id in JNR to avoid name collision
    cust_field_map = {
        "customer_id":     "cust_customer_id",
        "customer_name":   "customer_name",
        "customer_region": "customer_region",
        "customer_type":   "customer_type",
    }
    for from_field, to_field in cust_field_map.items():
        connectors.append(_connector(
            "SQ_customers", SQ_T,
            from_field,
            "JNR_orders_customers", JNR_T,
            to_field,
            to_group="DETAIL",
        ))

    # ---- JNR_orders_customers -> LKP_dim_customer (lookup key only) ---------
    connectors.append(_connector(
        "JNR_orders_customers", JNR_T,
        "customer_id",
        "LKP_dim_customer", LKP_T,
        "customer_id",
    ))

    # ---- JNR_orders_customers -> EXP_calculate_metrics ----------------------
    for field in ["order_id", "customer_id", "amount", "order_date", "status",
                  "customer_name", "customer_region"]:
        connectors.append(_connector(
            "JNR_orders_customers", JNR_T,
            field,
            "EXP_calculate_metrics", EXP_T,
            field,
        ))

    # ---- LKP_dim_customer -> EXP_calculate_metrics (looked-up region) -------
    connectors.append(_connector(
        "LKP_dim_customer", LKP_T,
        "lkp_customer_region",
        "EXP_calculate_metrics", EXP_T,
        "lkp_customer_region",
    ))

    # ---- EXP_calculate_metrics -> AGG_sales_by_customer ---------------------
    for field in ["customer_id", "customer_name", "customer_region", "amount", "net_amount"]:
        connectors.append(_connector(
            "EXP_calculate_metrics", EXP_T,
            field,
            "AGG_sales_by_customer", AGG_T,
            field,
        ))

    # ---- AGG_sales_by_customer -> FIL_active_orders -------------------------
    for field in ["customer_id", "customer_name", "customer_region",
                  "total_amount", "total_net_amount", "order_count"]:
        connectors.append(_connector(
            "AGG_sales_by_customer", AGG_T,
            field,
            "FIL_active_orders", FIL_T,
            field,
        ))

    # ---- FIL_active_orders -> RTR_route_by_region ----------------------------
    for field in ["customer_id", "customer_name", "customer_region",
                  "total_amount", "total_net_amount", "order_count"]:
        connectors.append(_connector(
            "FIL_active_orders", FIL_T,
            field,
            "RTR_route_by_region", RTR_T,
            field,
        ))

    # ---- RTR_route_by_region -> fact_sales TARGET (Strategy A — all groups) -
    # All three groups feed the same target
    rtr_fields = ["customer_id", "customer_name", "customer_region",
                  "total_amount", "total_net_amount", "order_count"]
    for group in ["US_ORDERS", "EU_ORDERS", "DEFAULT"]:
        for field in rtr_fields:
            connectors.append(_connector(
                "RTR_route_by_region", RTR_T,
                field,
                "fact_sales", TGT_T,
                field,
                from_group=group,
            ))

    return connectors


# ---------------------------------------------------------------------------
# Mapping assembler
# ---------------------------------------------------------------------------

def create_mapping() -> ET.Element:
    """
    Assemble the full MAPPING element with all sources, transformations,
    target, and connectors as direct children.
    """
    mapping = ET.Element("MAPPING", attrib={
        "NAME":          MAPPING_NAME,
        "ISVALID":       "YES",
        "OBJECTVERSION": "1",
        "VERSIONNUMBER": "1",
    })

    # Sources (direct children of MAPPING)
    mapping.append(create_source_orders())
    mapping.append(create_source_customers())
    mapping.append(create_source_dim_customer())

    # Transformations (direct children of MAPPING) — 7 types
    mapping.append(create_transformation_sq_orders())
    mapping.append(create_transformation_sq_customers())
    mapping.append(create_transformation_jnr_orders_customers())
    mapping.append(create_transformation_lkp_dim_customer())
    mapping.append(create_transformation_exp_calculate_metrics())
    mapping.append(create_transformation_agg_sales_by_customer())
    mapping.append(create_transformation_fil_active_orders())
    mapping.append(create_transformation_rtr_route_by_region())

    # Target (direct child of MAPPING)
    mapping.append(create_target_fact_sales())

    # Connectors (direct children of MAPPING)
    for connector in create_connectors():
        mapping.append(connector)

    return mapping


# ---------------------------------------------------------------------------
# Full document assemblers
# ---------------------------------------------------------------------------

def create_mapping_document() -> ET.Element:
    """
    Wrap the MAPPING in the full POWERMART > REPOSITORY > FOLDER hierarchy.
    """
    powermart = ET.Element("POWERMART", attrib={
        "CREATION_DATE": "2026-06-26",
        "SERVER_VERSION": "10.5.0",
    })
    repository = ET.SubElement(powermart, "REPOSITORY", attrib={
        "NAME":         REPO_NAME,
        "VERSION":      "186",
        "CODEPAGE":     "UTF-8",
        "DATABASETYPE": "Oracle",
    })
    folder = ET.SubElement(repository, "FOLDER", attrib={
        "NAME":        FOLDER_NAME,
        "DESCRIPTION": "Sales pipeline sample mapping",
        "OWNER":       "admin",
        "SHARED":      "NOTSHARED",
    })
    folder.append(create_mapping())
    return powermart


def create_workflow() -> ET.Element:
    """
    Create the WORKFLOW element with one SESSION referencing the mapping.
    Wrapped in POWERMART > REPOSITORY > FOLDER hierarchy.
    FOLDER NAME matches the mapping document for session-to-mapping linkage.
    """
    powermart = ET.Element("POWERMART", attrib={
        "CREATION_DATE": "2026-06-26",
        "SERVER_VERSION": "10.5.0",
    })
    repository = ET.SubElement(powermart, "REPOSITORY", attrib={
        "NAME":         REPO_NAME,
        "VERSION":      "186",
        "CODEPAGE":     "UTF-8",
        "DATABASETYPE": "Oracle",
    })
    folder = ET.SubElement(repository, "FOLDER", attrib={
        "NAME":        FOLDER_NAME,
        "DESCRIPTION": "Sales pipeline sample workflow",
        "OWNER":       "admin",
        "SHARED":      "NOTSHARED",
    })
    workflow = ET.SubElement(folder, "WORKFLOW", attrib={
        "NAME":      WORKFLOW_NAME,
        "ISVALID":   "YES",
        "ISENABLED": "YES",
    })
    session = ET.SubElement(workflow, "SESSION", attrib={
        "NAME":         SESSION_NAME,
        "MAPPING_NAME": MAPPING_NAME,
        "ISVALID":      "YES",
    })
    ET.SubElement(session, "ATTRIBUTE", attrib={
        "NAME":  "$Source connection value",
        "VALUE": "SALES_DB_CONN",
    })
    ET.SubElement(session, "ATTRIBUTE", attrib={
        "NAME":  "$Target connection value",
        "VALUE": "SNOWFLAKE_DW_CONN",
    })
    return powermart


# ---------------------------------------------------------------------------
# XML serialization helpers
# ---------------------------------------------------------------------------

def _indent(elem: ET.Element, level: int = 0) -> None:
    """Add pretty-print indentation to an ElementTree in-place (Python 3.8 compat)."""
    indent = "\n" + "  " * level
    if len(elem):
        if not elem.text or not elem.text.strip():
            elem.text = indent + "  "
        if not elem.tail or not elem.tail.strip():
            elem.tail = indent
        for child in elem:
            _indent(child, level + 1)
        # Last child tail should close at parent indent level
        if not child.tail or not child.tail.strip():  # type: ignore[assignment]
            child.tail = indent  # type: ignore[assignment]
    else:
        if level and (not elem.tail or not elem.tail.strip()):
            elem.tail = indent


def element_to_string(root: ET.Element) -> str:
    """Serialize an Element to a pretty-printed XML string with declaration."""
    _indent(root)
    return '<?xml version="1.0" encoding="UTF-8"?>\n' + ET.tostring(root, encoding="unicode")


# ---------------------------------------------------------------------------
# Main entry point
# ---------------------------------------------------------------------------

def main() -> None:
    """Generate sample Informatica PowerCenter XML mapping and workflow files."""
    INPUTS_DIR.mkdir(parents=True, exist_ok=True)

    mapping_path = INPUTS_DIR / "sample_mapping.xml"
    workflow_path = INPUTS_DIR / "sample_workflow.xml"

    # --- Build and validate mapping ---
    mapping_root = create_mapping_document()
    mapping_xml = element_to_string(mapping_root)

    # Validate that the XML round-trips cleanly before writing
    try:
        ET.fromstring(mapping_xml)
    except ET.ParseError as exc:
        print(f"ERROR: Mapping XML failed to parse: {exc}", file=sys.stderr)
        sys.exit(1)

    # Count transformation types for verification
    mapping_elem = mapping_root.find(".//MAPPING")
    if mapping_elem is not None:
        types_found = {t.attrib.get("TYPE", "") for t in mapping_elem.findall("TRANSFORMATION")}
        expected_types = {
            "Source Qualifier", "Joiner", "Lookup Procedure",
            "Expression", "Aggregator", "Filter", "Router",
        }
        missing = expected_types - types_found
        if missing:
            print(f"ERROR: Missing transformation types: {missing}", file=sys.stderr)
            sys.exit(1)
        connector_count = len(mapping_elem.findall("CONNECTOR"))
        if connector_count < 15:
            print(
                f"ERROR: Expected >= 15 connectors, found {connector_count}",
                file=sys.stderr,
            )
            sys.exit(1)

    # --- Build and validate workflow ---
    workflow_root = create_workflow()
    workflow_xml = element_to_string(workflow_root)

    try:
        ET.fromstring(workflow_xml)
    except ET.ParseError as exc:
        print(f"ERROR: Workflow XML failed to parse: {exc}", file=sys.stderr)
        sys.exit(1)

    # --- Write files ---
    try:
        mapping_path.write_text(mapping_xml, encoding="utf-8")
        workflow_path.write_text(workflow_xml, encoding="utf-8")
    except IOError as exc:
        print(f"ERROR: Failed to write output files: {exc}", file=sys.stderr)
        sys.exit(1)

    print(f"Generated {mapping_path}")
    print(f"Generated {workflow_path}")
    if mapping_elem is not None:
        print(
            f"  Mapping '{MAPPING_NAME}': "
            f"{len(mapping_elem.findall('TRANSFORMATION'))} transformations, "
            f"{connector_count} connectors, "
            f"transformation types: {sorted(types_found)}"
        )
    print("Done.")


if __name__ == "__main__":
    main()
