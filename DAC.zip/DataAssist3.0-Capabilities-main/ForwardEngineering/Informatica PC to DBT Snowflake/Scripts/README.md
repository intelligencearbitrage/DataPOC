# Informatica PowerCenter to DBT Snowflake Converter

Converts Informatica PowerCenter XML mappings and workflows into a ready-to-run DBT Snowflake project. The pipeline parses PC XML exports, converts all 7 Informatica transformation types to SQL-ready plans, and emits `.sql` model files, `schema.yml`, `dbt_project.yml`, `profiles.yml`, and `packages.yml`.

---

## Prerequisites

- Python 3.8+
- Install dependencies:

```
pip install -r agent-output/scripts/requirements.txt
```

---

## Quick Start

```
python agent-output/scripts/cli.py all
```

This runs all 6 scripts in dependency order. The generated DBT project lands in `scripts-output/output/dbt_project/`.

---

## Running Individual Steps

```
python agent-output/scripts/cli.py generate_sample_inputs
python agent-output/scripts/cli.py parse_informatica_xml
python agent-output/scripts/cli.py convert_transformations
python agent-output/scripts/cli.py generate_dbt_models
python agent-output/scripts/cli.py generate_dbt_schema
python agent-output/scripts/cli.py generate_dbt_project
python agent-output/scripts/cli.py --list    # list all steps
```

Each script is also independently runnable:

```
python agent-output/scripts/generate_sample_inputs.py
python agent-output/scripts/parse_informatica_xml.py
# etc.
```

---

## Scripts

| Script | CLI Command | Description | Reads From | Writes To |
|---|---|---|---|---|
| `generate_sample_inputs.py` | `cli.py generate_sample_inputs` | Creates sample Informatica PC XML files for the pipeline to process | _(none — generates from embedded templates)_ | `user-config/inputs/sample_mapping.xml`, `user-config/inputs/sample_workflow.xml` |
| `parse_informatica_xml.py` | `cli.py parse_informatica_xml` | Parses PC XML — mappings, workflows, sessions, all transformation objects. Performs snake_case normalization and topological sort of the CONNECTOR DAG. | `user-config/inputs/*.xml` | `agent-output/parsed/{mapping_name}.json`, `agent-output/parsed/index.json` |
| `convert_transformations.py` | `cli.py convert_transformations` | Converts all 7 Informatica transformation types (SQ, EXP, AGG, LKP, FIL, JNR, RTR) to SQL-ready CTE definitions. Resolves source() vs ref() references. | `agent-output/parsed/*.json` | `agent-output/converted/{mapping_name}_plan.json` |
| `generate_dbt_models.py` | `cli.py generate_dbt_models` | Renders DBT `.sql` model files with Jinja templating (`source()`, `ref()`, `config()`) and Snowflake syntax from conversion plans. | `agent-output/converted/*_plan.json` | `scripts-output/output/dbt_project/models/*.sql` |
| `generate_dbt_schema.py` | `cli.py generate_dbt_schema` | Generates `schema.yml` with sources, models, and column-level `not_null` / `unique` / `relationships` tests from parsed and converted data. | `agent-output/parsed/`, `agent-output/converted/` | `scripts-output/output/dbt_project/models/schema.yml` |
| `generate_dbt_project.py` | `cli.py generate_dbt_project` | Generates `dbt_project.yml`, `profiles.yml` (with `env_var()` credentials — never hardcoded), and `packages.yml`. | `agent-output/parsed/index.json` | `scripts-output/output/dbt_project/dbt_project.yml`, `profiles.yml`, `packages.yml` |

---

## Output Structure

```
scripts-output/output/dbt_project/
    dbt_project.yml          # DBT project config
    profiles.yml             # Snowflake connection profile (env_var() credentials)
    packages.yml             # DBT package dependencies
    models/
        *.sql                # One .sql model file per Informatica mapping
        schema.yml           # Source + model + column-level tests
```

---

## Environment Variables for profiles.yml

`profiles.yml` uses `env_var()` for all Snowflake credentials. Set these before running `dbt run`:

```
export SNOWFLAKE_ACCOUNT="your_account"
export SNOWFLAKE_USER="your_user"
export SNOWFLAKE_PASSWORD="your_password"
export SNOWFLAKE_DATABASE="your_database"
export SNOWFLAKE_WAREHOUSE="your_warehouse"
export SNOWFLAKE_SCHEMA="your_schema"
export SNOWFLAKE_ROLE="your_role"
```

---

## Data Flow

```
user-config/inputs/        (Informatica PC XML exports)
        |
        v
agent-output/parsed/       (structured JSON — one file per mapping)
        |
        v
agent-output/converted/    (SQL-ready CTE plan JSON — one file per mapping)
        |
        v
scripts-output/output/dbt_project/   (ready-to-run DBT project)
```

All scripts are idempotent — re-running them is safe and produces consistent output.

---

## Requirements

See `agent-output/scripts/requirements.txt`. Install with:

```
pip install -r agent-output/scripts/requirements.txt
```
