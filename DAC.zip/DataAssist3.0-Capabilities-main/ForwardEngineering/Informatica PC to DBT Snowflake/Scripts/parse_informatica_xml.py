#!/usr/bin/env python3
"""
parse_informatica_xml.py

Parses Informatica PowerCenter XML files in user-config/inputs/ and produces
structured JSON in agent-output/parsed/{mapping_name}.json.

XML hierarchy expected:
    POWERMART > REPOSITORY > FOLDER > MAPPING
    Within each MAPPING: SOURCE, TARGET, TRANSFORMATION, CONNECTOR are all
    direct children of MAPPING (NOT of FOLDER).

Output:
    agent-output/parsed/{mapping_name}.json  — one file per MAPPING
    agent-output/parsed/index.json           — summary listing all parsed mappings

Usage:
    python parse_informatica_xml.py
"""

import json
import re
import sys
import xml.etree.ElementTree as ET
from collections import defaultdict, deque
from pathlib import Path
from typing import Any, Dict, List, Optional

PROJECT_ROOT = Path(__file__).resolve().parent.parent.parent
INPUTS_DIR = PROJECT_ROOT / "user-config" / "inputs"
PARSED_DIR = PROJECT_ROOT / "agent-output" / "parsed"

# Mapping from Informatica TRANSFORMATION.TYPE attribute values to normalized codes
TRANSFORMATION_TYPE_MAP: Dict[str, str] = {
    "Source Qualifier": "source_qualifier",
    "Expression": "expression",
    "Aggregator": "aggregator",
    "Lookup Procedure": "lookup",
    "Filter": "filter",
    "Joiner": "joiner",
    "Router": "router",
}


def to_snake_case(name: str) -> str:
    """Convert a name to snake_case: lowercase, spaces/hyphens to underscores."""
    if not name:
        return name
    # Replace spaces, hyphens, and other non-alphanumeric chars (except _) with underscores
    result = re.sub(r"[\s\-]+", "_", name)
    # Remove any remaining non-alphanumeric/underscore characters
    result = re.sub(r"[^\w]", "_", result)
    return result.lower()


def normalize_mapping_name(raw_name: str) -> str:
    """
    Convert a MAPPING.NAME to snake_case and strip a leading 'm_' prefix.

    Example: 'm_orders_to_fact_sales' -> 'orders_to_fact_sales'
    """
    snake = to_snake_case(raw_name)
    if snake.startswith("m_"):
        snake = snake[2:]
    return snake


def safe_int(value: Optional[str]) -> Optional[int]:
    """Convert a string to int, returning None if conversion fails or value is None/empty."""
    if value is None or value == "":
        return None
    try:
        return int(value)
    except (ValueError, TypeError):
        return None


def parse_source(source_elem: ET.Element) -> Dict[str, Any]:
    """
    Parse a SOURCE element into a structured dict.

    Captures: name (snake_case), raw_name, db_name, db_type, schema, and all
    SOURCEFIELD child elements.
    """
    raw_name = source_elem.get("NAME", "")
    fields: List[Dict[str, Any]] = []

    for sf in source_elem.findall("SOURCEFIELD"):
        field_raw = sf.get("NAME", "")
        fields.append(
            {
                "name": to_snake_case(field_raw),
                "raw_name": field_raw,
                "datatype": sf.get("DATATYPE", ""),
                "precision": safe_int(sf.get("PRECISION")),
                "scale": safe_int(sf.get("SCALE")),
                "null_type": sf.get("NULLTYPE", ""),
            }
        )

    return {
        "name": to_snake_case(raw_name),
        "raw_name": raw_name,
        "db_name": source_elem.get("DBDNAME", ""),
        "db_type": source_elem.get("DATABASETYPE", source_elem.get("DBTYPE", "")),
        "schema": source_elem.get("SCHEMANAME", source_elem.get("SCHEMA", "")),
        "fields": fields,
    }


def parse_target(target_elem: ET.Element) -> Dict[str, Any]:
    """
    Parse a TARGET element into a structured dict.

    Captures: name (snake_case), raw_name, db_name, db_type, and all
    TARGETFIELD child elements.
    """
    raw_name = target_elem.get("NAME", "")
    fields: List[Dict[str, Any]] = []

    for tf in target_elem.findall("TARGETFIELD"):
        field_raw = tf.get("NAME", "")
        fields.append(
            {
                "name": to_snake_case(field_raw),
                "raw_name": field_raw,
                "datatype": tf.get("DATATYPE", ""),
                "precision": safe_int(tf.get("PRECISION")),
                "scale": safe_int(tf.get("SCALE")),
                "key_type": tf.get("KEYTYPE", ""),
            }
        )

    return {
        "name": to_snake_case(raw_name),
        "raw_name": raw_name,
        "db_name": target_elem.get("DBDNAME", ""),
        "db_type": target_elem.get("DATABASETYPE", target_elem.get("DBTYPE", "")),
        "fields": fields,
    }


def parse_transformation(trans_elem: ET.Element) -> Dict[str, Any]:
    """
    Parse a TRANSFORMATION element into a structured dict.

    Normalizations performed:
    - TYPE: mapped to lowercase internal code via TRANSFORMATION_TYPE_MAP
    - PORTTYPE: lowercased ('INPUT' -> 'input', 'OUTPUT' -> 'output', 'VARIABLE' -> 'variable')
    - GROUPBY: normalized to boolean ('YES' -> True, else False)
    - TABLEATTRIBUTE NAME keys: preserved exactly as-is (not snake_cased)
    - TRANSFORMGROUP elements: parsed for Router transformations
    - ISACTIVE: '1' or 'YES' -> True
    """
    raw_name = trans_elem.get("NAME", "")
    raw_type = trans_elem.get("TYPE", "")
    normalized_type = TRANSFORMATION_TYPE_MAP.get(raw_type, raw_type.lower().replace(" ", "_"))

    is_active_val = trans_elem.get("ISACTIVE", "1")
    is_active = is_active_val in ("1", "YES", "yes", "true", "TRUE")

    # Parse TRANSFORMFIELD children (ports)
    fields: List[Dict[str, Any]] = []
    for tf in trans_elem.findall("TRANSFORMFIELD"):
        field_raw = tf.get("PORTNAME", tf.get("NAME", ""))  # some exports use PORTNAME
        porttype_raw = tf.get("PORTTYPE", "OUTPUT")
        groupby_raw = tf.get("GROUPBY", "NO")
        input_type_raw = tf.get("INPUTTYPE", "")

        fields.append(
            {
                "name": to_snake_case(field_raw),
                "raw_name": field_raw,
                "datatype": tf.get("DATATYPE", ""),
                "port_type": porttype_raw.lower(),
                "expression": tf.get("EXPRESSION", ""),
                "group_by": groupby_raw.upper() == "YES",
                "input_type": input_type_raw,
            }
        )

    # Parse TABLEATTRIBUTE children — keys are kept as-is (not normalized)
    attributes: Dict[str, str] = {}
    for ta in trans_elem.findall("TABLEATTRIBUTE"):
        attr_name = ta.get("NAME", "")
        attr_value = ta.get("VALUE", "")
        if attr_name:
            attributes[attr_name] = attr_value

    # Parse TRANSFORMGROUP children — Router groups only; empty list for others
    groups: List[Dict[str, str]] = []
    for tg in trans_elem.findall("TRANSFORMGROUP"):
        groups.append(
            {
                "name": tg.get("NAME", ""),
                "expression": tg.get("EXPRESSION", ""),
            }
        )

    return {
        "name": to_snake_case(raw_name),
        "raw_name": raw_name,
        "type": normalized_type,
        "is_active": is_active,
        "fields": fields,
        "attributes": attributes,
        "groups": groups,
    }


def parse_connectors(mapping_elem: ET.Element) -> List[Dict[str, Any]]:
    """
    Parse all CONNECTOR elements that are direct children of a MAPPING element.

    Normalizes FROMINSTANCE, FROMFIELD, TOINSTANCE, TOFIELD to snake_case.
    FROMGROUP is kept as-is (may be empty string if attribute absent — this is
    the Router output group name used for Strategy A vs B detection downstream).
    """
    connectors: List[Dict[str, Any]] = []
    for conn in mapping_elem.findall("CONNECTOR"):
        from_instance = conn.get("FROMINSTANCE", "")
        from_field = conn.get("FROMFIELD", "")
        to_instance = conn.get("TOINSTANCE", "")
        to_field = conn.get("TOFIELD", "")
        from_group = conn.get("FROMGROUP", "")

        connectors.append(
            {
                "from_instance": to_snake_case(from_instance),
                "from_field": to_snake_case(from_field),
                "to_instance": to_snake_case(to_instance),
                "to_field": to_snake_case(to_field),
                "from_group": from_group,
            }
        )
    return connectors


def topological_sort(
    transformation_names: List[str], connectors: List[Dict[str, Any]]
) -> List[str]:
    """
    Kahn's topological sort on the transformation CONNECTOR graph.

    Builds an adjacency list from connector edges (from_instance -> to_instance).
    Returns a list of transformation names in topological order (sources first).
    Warns to stderr if the result is shorter than the input (cycle or disconnected node
    not in connector graph) — does not fail.

    Args:
        transformation_names: list of all snake_case transformation names
        connectors: list of connector dicts with from_instance / to_instance keys

    Returns:
        Ordered list of transformation names (Kahn topological order).
    """
    name_set = set(transformation_names)
    in_degree: Dict[str, int] = {t: 0 for t in transformation_names}
    graph: Dict[str, List[str]] = defaultdict(list)

    for conn in connectors:
        u = conn["from_instance"]
        v = conn["to_instance"]
        # Only consider edges between known transformations
        if u in name_set and v in name_set:
            graph[u].append(v)
            in_degree[v] += 1

    # Initialize queue with all nodes that have no incoming edges
    queue: deque = deque(
        sorted([t for t in transformation_names if in_degree[t] == 0])
    )
    order: List[str] = []

    while queue:
        node = queue.popleft()
        order.append(node)
        # Sort neighbors for deterministic output
        for neighbor in sorted(graph[node]):
            in_degree[neighbor] -= 1
            if in_degree[neighbor] == 0:
                queue.append(neighbor)

    if len(order) < len(transformation_names):
        missing = set(transformation_names) - set(order)
        print(
            f"WARNING: Topological sort produced {len(order)} nodes but expected "
            f"{len(transformation_names)}. Possible cycle or isolated nodes: {missing}",
            file=sys.stderr,
        )
        # Append missing nodes at the end so all transformations appear
        order.extend(sorted(missing))

    return order


def parse_mapping(mapping_elem: ET.Element, folder_name: str) -> Dict[str, Any]:
    """
    Parse a single MAPPING element into the full structured output dict.

    SOURCE, TARGET, TRANSFORMATION, and CONNECTOR are ALL direct children of
    MAPPING — never children of FOLDER.

    Steps:
    1. Parse sources (mapping.findall('SOURCE'))
    2. Parse targets (mapping.findall('TARGET'))
    3. Parse transformations (mapping.findall('TRANSFORMATION'))
    4. Parse connectors (mapping.findall('CONNECTOR'))
    5. Build topological sort from CONNECTOR graph

    Returns the assembled mapping dict.
    """
    raw_mapping_name = mapping_elem.get("NAME", "")
    mapping_name = normalize_mapping_name(raw_mapping_name)

    # 1. Parse SOURCEs — direct children of MAPPING
    sources = [parse_source(s) for s in mapping_elem.findall("SOURCE")]

    # 2. Parse TARGETs — direct children of MAPPING
    targets = [parse_target(t) for t in mapping_elem.findall("TARGET")]

    # 3. Parse TRANSFORMATIONs — direct children of MAPPING
    transformations = [
        parse_transformation(t) for t in mapping_elem.findall("TRANSFORMATION")
    ]

    # 4. Parse CONNECTORs — direct children of MAPPING
    connectors = parse_connectors(mapping_elem)

    # 5. Topological sort on transformation names using CONNECTOR graph
    transformation_names = [t["name"] for t in transformations]
    dag_order = topological_sort(transformation_names, connectors)

    return {
        "mapping_name": mapping_name,
        "raw_mapping_name": raw_mapping_name,
        "folder_name": folder_name,
        "sources": sources,
        "targets": targets,
        "transformations": transformations,
        "connectors": connectors,
        "dag_order": dag_order,
        "workflow_name": None,   # Populated by parse_workflow after the fact
        "sessions": [],          # Populated by parse_workflow after the fact
    }


def parse_workflow(folder_elem: ET.Element) -> List[Dict[str, Any]]:
    """
    Parse WORKFLOW and SESSION elements from a FOLDER element.

    Handles WORKFLOW as a direct child of FOLDER, with SESSION children of
    WORKFLOW. Captures SESSION.NAME and SESSION.MAPPING_NAME (normalized to
    snake_case).

    Returns a list of session dicts: [{session_name, mapping_name}]
    """
    sessions: List[Dict[str, Any]] = []
    workflows: List[str] = []

    for workflow_elem in folder_elem.findall("WORKFLOW"):
        wf_name = workflow_elem.get("NAME", "")
        workflows.append(wf_name)

        for session_elem in workflow_elem.findall("SESSION"):
            sess_name = session_elem.get("NAME", "")
            # SESSION.MAPPING_NAME links the session to its mapping definition
            raw_mapping_ref = session_elem.get("MAPPINGNAME", session_elem.get("MAPPING_NAME", ""))
            sessions.append(
                {
                    "session_name": sess_name,
                    "mapping_name": normalize_mapping_name(raw_mapping_ref),
                    "workflow_name": wf_name,
                }
            )

    return sessions


def parse_xml_file(xml_path: Path) -> List[Dict[str, Any]]:
    """
    Parse a single Informatica PowerCenter XML file.

    Navigates: POWERMART > REPOSITORY > FOLDER > MAPPING
    For each MAPPING, parses sources, targets, transformations, and connectors.
    Workflow sessions are linked to their mappings by MAPPING_NAME.

    Returns a list of parsed mapping dicts (one per MAPPING element found).
    Warns to stderr if no MAPPING elements are found — does not fail.
    """
    try:
        tree = ET.parse(xml_path)
    except ET.ParseError as exc:
        print(
            f"ERROR: Failed to parse XML file '{xml_path}': {exc}",
            file=sys.stderr,
        )
        return []

    root = tree.getroot()
    parsed_mappings: List[Dict[str, Any]] = []

    # Navigate POWERMART > REPOSITORY > FOLDER
    # Support root == POWERMART or root == REPOSITORY
    repositories: List[ET.Element] = []
    if root.tag == "POWERMART":
        repositories = root.findall("REPOSITORY")
    elif root.tag == "REPOSITORY":
        repositories = [root]
    else:
        # Fallback: search anywhere
        repositories = root.findall(".//REPOSITORY")

    if not repositories:
        # Try treating root itself as containing FOLDER elements
        repositories = [root]

    for repo_elem in repositories:
        folders = repo_elem.findall("FOLDER")
        if not folders:
            # Some exports may have FOLDER as a grandchild
            folders = repo_elem.findall(".//FOLDER")

        for folder_elem in folders:
            folder_name = folder_elem.get("NAME", "")

            # Parse all MAPPINGs in this folder
            mappings_found = folder_elem.findall("MAPPING")
            if not mappings_found:
                print(
                    f"WARNING: No MAPPING elements found in FOLDER '{folder_name}' "
                    f"of file '{xml_path.name}'",
                    file=sys.stderr,
                )
                continue

            # Parse workflow sessions for this folder
            sessions = parse_workflow(folder_elem)

            # Build a lookup: normalized_mapping_name -> {workflow_name, sessions}
            session_by_mapping: Dict[str, List[Dict[str, Any]]] = defaultdict(list)
            workflow_by_mapping: Dict[str, str] = {}
            for s in sessions:
                mn = s["mapping_name"]
                session_by_mapping[mn].append(
                    {
                        "name": s["session_name"],          # standard key per plan schema
                        "session_name": s["session_name"],  # backward-compat alias
                        "mapping_name": mn,
                    }
                )
                if mn not in workflow_by_mapping:
                    workflow_by_mapping[mn] = s["workflow_name"]

            for mapping_elem in mappings_found:
                mapping_dict = parse_mapping(mapping_elem, folder_name)
                mn = mapping_dict["mapping_name"]

                # Link workflow data to the mapping
                mapping_dict["workflow_name"] = workflow_by_mapping.get(mn, None)
                mapping_dict["sessions"] = session_by_mapping.get(mn, [])

                parsed_mappings.append(mapping_dict)

    return parsed_mappings


def validate_connectors(mapping_dict: Dict[str, Any]) -> None:
    """
    Warn (to stderr) for any CONNECTOR that references a TRANSFORMFIELD not
    found in the corresponding transformation.

    Does NOT modify the mapping dict or raise exceptions.
    """
    # Build a set of (transformation_name, field_name) pairs
    known_fields: set = set()
    for trans in mapping_dict.get("transformations", []):
        t_name = trans["name"]
        for f in trans.get("fields", []):
            known_fields.add((t_name, f["name"]))

    for conn in mapping_dict.get("connectors", []):
        from_inst = conn["from_instance"]
        from_field = conn["from_field"]
        to_inst = conn["to_instance"]
        to_field = conn["to_field"]

        # Only warn for transformation-to-transformation connectors (not source/target names)
        trans_names = {t["name"] for t in mapping_dict.get("transformations", [])}

        if from_inst in trans_names and (from_inst, from_field) not in known_fields:
            print(
                f"WARNING: CONNECTOR references unknown field '{from_field}' "
                f"in transformation '{from_inst}' (mapping: {mapping_dict['mapping_name']})",
                file=sys.stderr,
            )
        if to_inst in trans_names and (to_inst, to_field) not in known_fields:
            print(
                f"WARNING: CONNECTOR references unknown field '{to_field}' "
                f"in transformation '{to_inst}' (mapping: {mapping_dict['mapping_name']})",
                file=sys.stderr,
            )


def write_mapping_json(mapping_dict: Dict[str, Any]) -> Path:
    """
    Write a single mapping dict to agent-output/parsed/{mapping_name}.json.

    Idempotent: overwrites any existing file unconditionally.
    Returns the output path.
    """
    output_path = PARSED_DIR / f"{mapping_dict['mapping_name']}.json"
    try:
        output_path.write_text(json.dumps(mapping_dict, indent=2), encoding="utf-8")
    except IOError as exc:
        print(
            f"ERROR: Failed to write '{output_path}': {exc}",
            file=sys.stderr,
        )
        sys.exit(1)
    return output_path


def write_index_json(
    index_entries: List[Dict[str, Any]]
) -> Path:
    """
    Write the summary index to agent-output/parsed/index.json.

    Each entry: {mapping_name, raw_mapping_name, folder_name, source_file, workflow_name}
    Idempotent: overwrites any existing file unconditionally.
    Returns the output path.
    """
    index_path = PARSED_DIR / "index.json"
    try:
        index_path.write_text(json.dumps(index_entries, indent=2), encoding="utf-8")
    except IOError as exc:
        print(
            f"ERROR: Failed to write index.json: {exc}",
            file=sys.stderr,
        )
        sys.exit(1)
    return index_path


def main() -> None:
    """
    Entry point: parse all *.xml files in user-config/inputs/ and write
    structured JSON to agent-output/parsed/.

    Exits with code 1 if no XML files are found.
    """
    PARSED_DIR.mkdir(parents=True, exist_ok=True)

    xml_files = sorted(INPUTS_DIR.glob("*.xml"))
    if not xml_files:
        print(
            f"No XML files found in '{INPUTS_DIR}'. "
            "Run generate_sample_inputs.py first to create sample input files.",
            file=sys.stderr,
        )
        sys.exit(1)

    print(f"Found {len(xml_files)} XML file(s) in {INPUTS_DIR}")

    all_mappings: List[Dict[str, Any]] = []
    index_entries: List[Dict[str, Any]] = []

    for xml_path in xml_files:
        print(f"Parsing: {xml_path.name} ...")
        mappings = parse_xml_file(xml_path)

        if not mappings:
            print(
                f"  WARNING: No mappings extracted from '{xml_path.name}'",
                file=sys.stderr,
            )
            continue

        for mapping_dict in mappings:
            # Validate connector field references (warns to stderr, does not fail)
            validate_connectors(mapping_dict)

            # Write individual mapping JSON
            out_path = write_mapping_json(mapping_dict)
            print(f"  Written: {out_path.relative_to(PROJECT_ROOT)}")
            all_mappings.append(mapping_dict)

            # Build index entry
            index_entries.append(
                {
                    "mapping_name": mapping_dict["mapping_name"],
                    "raw_mapping_name": mapping_dict["raw_mapping_name"],
                    "folder_name": mapping_dict["folder_name"],
                    "source_file": xml_path.name,
                    "workflow_name": mapping_dict.get("workflow_name"),
                }
            )

    if not all_mappings:
        print(
            "ERROR: No mappings were successfully parsed from any XML file.",
            file=sys.stderr,
        )
        sys.exit(1)

    # Write consolidated index
    index_path = write_index_json(index_entries)
    print(f"  Written: {index_path.relative_to(PROJECT_ROOT)}")

    print(
        f"\nDone. Parsed {len(all_mappings)} mapping(s) from "
        f"{len(xml_files)} file(s) into '{PARSED_DIR.relative_to(PROJECT_ROOT)}'"
    )


if __name__ == "__main__":
    main()
