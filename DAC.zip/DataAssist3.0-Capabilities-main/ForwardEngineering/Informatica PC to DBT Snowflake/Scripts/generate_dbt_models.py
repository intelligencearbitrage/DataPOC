#!/usr/bin/env python3
"""
generate_dbt_models.py

Reads agent-output/converted/conversion_plan.json (and any *_plan.json files
in agent-output/converted/) and generates DBT .sql model files with Jinja
templating and Snowflake syntax in scripts-output/output/dbt_project/models/.

Usage:
    python generate_dbt_models.py

Each conversion plan JSON produces:
  - One primary .sql model file per mapping
  - Additional split .sql files when Router Strategy B is used

Actual schema in conversion_plan / *_plan.json files:
  Top-level keys: mapping_name, model_name, model_materialization,
                  source_refs, cte_order, ctes (dict keyed by cte_name),
                  final_select_cte, output_columns, router_split_models

  select_columns in all CTE types is a list of dicts:
    {name, expression, alias, is_passthrough, original_expression}
    (some types may also carry source_side for joiner columns)

  CTE types and their key fields:
    source_qualifier: verbatim_sql, select_columns (list of dicts),
                      dbt_source_call (string), where_clause
    joiner: master_cte, detail_cte, join_type, join_on,
            select_columns with source_side ('master'/'detail'),
            upstream_ctes
    expression: upstream_ctes, select_columns (list of dicts)
    aggregator: upstream_ctes, group_by_cols, select_columns (list of dicts)
    lookup: upstream_ctes, lookup_table_ref, lookup_on,
            select_columns (list of dicts -- the lookup output columns)
    filter: upstream_ctes, select_columns (list of dicts), where_clause
    router: upstream_ctes, route_groups (list of {name, condition, target}),
            router_strategy, select_columns
"""

import json
import re
import sys
from pathlib import Path
from typing import Any, Dict, List, Optional

PROJECT_ROOT = Path(__file__).resolve().parent.parent.parent
CONVERTED_DIR = PROJECT_ROOT / "agent-output" / "converted"
MODELS_DIR = PROJECT_ROOT / "scripts-output" / "output" / "dbt_project" / "models"


# ---------------------------------------------------------------------------
# Column rendering helpers
# ---------------------------------------------------------------------------

def _col_name(col: Any) -> str:
    """Extract the output column name from a string or dict column spec."""
    if isinstance(col, dict):
        return col.get("alias") or col.get("name") or str(col)
    return str(col)


def _render_select_col(col: Any) -> str:
    """
    Render a single SELECT column entry.

    If is_passthrough=True or expression is empty/matches name: just the name.
    If is_passthrough=False and expression non-empty: expression AS name.
    """
    if not isinstance(col, dict):
        return str(col)

    name: str = col.get("name") or ""
    expr: str = col.get("expression") or ""
    alias: str = col.get("alias") or ""
    is_passthrough: bool = bool(col.get("is_passthrough", True))

    # Determine output name: prefer alias, fall back to name
    out_name: str = alias if alias else name

    if is_passthrough or not expr.strip() or expr.strip() == name:
        return out_name if out_name else name
    else:
        # Expression column
        if out_name and out_name != expr.strip():
            return f"{expr} AS {out_name}"
        return expr


# ---------------------------------------------------------------------------
# CTE rendering helpers
# ---------------------------------------------------------------------------

def _indent(text: str, spaces: int = 4) -> str:
    """Indent every non-empty line of *text* by *spaces* spaces."""
    pad = " " * spaces
    return "\n".join(pad + line if line.strip() else line for line in text.splitlines())


def _pick_primary_upstream(upstream_ctes: List[str], cte_order: List[str]) -> str:
    """
    When a CTE has multiple upstream sources (e.g. EXP receives from both JNR and LKP),
    pick the one that appears LAST in cte_order — the most downstream upstream.
    This ensures the FROM clause references a CTE that already has all needed columns.

    Falls back to upstream_ctes[0] if none appear in cte_order.
    """
    if not upstream_ctes:
        return "UNKNOWN"
    if len(upstream_ctes) == 1:
        return upstream_ctes[0]
    # Find the upstream with the highest index in cte_order
    best: str = upstream_ctes[0]
    best_idx: int = -1
    for u in upstream_ctes:
        try:
            idx = cte_order.index(u)
            if idx > best_idx:
                best_idx = idx
                best = u
        except ValueError:
            pass
    return best


def render_cte(cte_name: str, cte: Dict[str, Any]) -> str:
    """
    Render a single CTE block (without trailing comma) based on
    the transformation_type stored in the conversion plan.

    Supported types: source_qualifier, expression, aggregator,
                     lookup, filter, joiner, router, router_strategy_a
    """
    t_type: str = (cte.get("transformation_type") or "").lower()

    if t_type == "source_qualifier":
        return _render_source_qualifier_cte(cte_name, cte)
    elif t_type == "expression":
        return _render_expression_cte(cte_name, cte)
    elif t_type == "aggregator":
        return _render_aggregator_cte(cte_name, cte)
    elif t_type == "lookup":
        return _render_lookup_cte(cte_name, cte)
    elif t_type == "filter":
        return _render_filter_cte(cte_name, cte)
    elif t_type == "joiner":
        return _render_joiner_cte(cte_name, cte)
    elif t_type in ("router", "router_strategy_a"):
        return _render_router_cte(cte_name, cte)
    else:
        # Unknown type -- emit a passthrough CTE with a comment
        print(
            f"  WARNING: Unknown CTE type '{t_type}' for '{cte_name}' -- "
            f"emitting passthrough",
            file=sys.stderr,
        )
        upstream_ctes: List[str] = cte.get("upstream_ctes") or []
        upstream: str = upstream_ctes[0] if upstream_ctes else "UNKNOWN"
        return (
            f"{cte_name} AS (\n"
            f"    -- WARNING: unknown transformation_type '{t_type}'\n"
            f"    SELECT *\n"
            f"    FROM {upstream}\n"
            f")"
        )


def _render_source_qualifier_cte(cte_name: str, cte: Dict[str, Any]) -> str:
    """
    SQ CTE rendering.

    If verbatim_sql=True the sql_query is the entire CTE body -- no SELECT wrapper.
    If verbatim_sql=False emit SELECT <columns> FROM <source_ref> [WHERE ...].

    select_columns may be a list of plain strings OR dicts with {name, ...}.
    source_ref is taken from 'dbt_source_call' in the CTE data (populated by
    the conversion pipeline), or from 'source_ref'.
    """
    verbatim: bool = bool(cte.get("verbatim_sql", False))

    if verbatim:
        sql_query: str = cte.get("sql_query") or ""
        if not sql_query:
            raw_cols: List[Any] = cte.get("select_columns") or []
            sql_query = str(raw_cols[0]) if raw_cols else "-- verbatim SQL missing"
        return f"{cte_name} AS (\n{_indent(sql_query.strip(), 4)}\n)"

    # Resolve source reference (dbt_source_call takes priority)
    source_ref: str = (
        cte.get("dbt_source_call") or
        cte.get("source_ref") or
        "UNKNOWN_SOURCE"
    )
    where_clause: Optional[str] = cte.get("where_clause") or None

    raw_cols: List[Any] = cte.get("select_columns") or []
    col_parts: List[str] = []
    for col in raw_cols:
        # In source_qualifier, columns are passthrough by definition
        if isinstance(col, dict):
            col_parts.append(col.get("name") or str(col))
        else:
            col_parts.append(str(col))

    cols_str = ",\n        ".join(col_parts) if col_parts else "*"

    lines: List[str] = [
        f"{cte_name} AS (",
        f"    SELECT",
        f"        {cols_str}",
        f"    FROM {source_ref}",
    ]
    if where_clause:
        lines.append(f"    WHERE {where_clause}")
    lines.append(")")
    return "\n".join(lines)


def _render_expression_cte(cte_name: str, cte: Dict[str, Any]) -> str:
    """
    EXP CTE -- SELECT with optional expressions, from upstream CTE.

    select_columns is a list of dicts: {name, expression, is_passthrough, ...}.
    If is_passthrough=True or expression is empty: just emit the column name.
    If is_passthrough=False and expression non-empty: emit expression AS name.

    Enhancement F4: deduplicates select_columns by output name before rendering.
    """
    raw_cols: List[Any] = cte.get("select_columns") or []
    upstream_ctes: List[str] = cte.get("upstream_ctes") or []
    cte_order_hint: List[str] = cte.get("_cte_order") or []
    upstream: str = _pick_primary_upstream(upstream_ctes, cte_order_hint)

    # Enhancement F4: remove duplicate column entries
    raw_cols = deduplicate_columns(raw_cols)

    col_parts: List[str] = [_render_select_col(col) for col in raw_cols]
    if not col_parts:
        col_parts = ["*"]

    cols_str = ",\n        ".join(col_parts)
    return (
        f"{cte_name} AS (\n"
        f"    SELECT\n"
        f"        {cols_str}\n"
        f"    FROM {upstream}\n"
        f")"
    )


def _render_aggregator_cte(cte_name: str, cte: Dict[str, Any]) -> str:
    """
    AGG CTE -- SELECT with aggregations and GROUP BY.

    select_columns is a list of dicts: {name, expression, is_passthrough, ...}.
    group_by_cols is a list of column name strings.

    Enhancement F4: deduplicates select_columns by output name before rendering.
    """
    raw_cols: List[Any] = cte.get("select_columns") or []
    group_by_cols: List[str] = cte.get("group_by_cols") or []
    upstream_ctes: List[str] = cte.get("upstream_ctes") or []
    cte_order_hint: List[str] = cte.get("_cte_order") or []
    upstream: str = _pick_primary_upstream(upstream_ctes, cte_order_hint)

    # Enhancement F4: remove duplicate column entries
    raw_cols = deduplicate_columns(raw_cols)

    col_parts: List[str] = []
    for col in raw_cols:
        if isinstance(col, dict) and bool(col.get("approximation")):
            rendered = _render_select_col(col)
            col_parts.append(
                rendered + "  -- APPROXIMATION: Informatica FIRST/LAST has no exact Snowflake equivalent"
            )
        else:
            col_parts.append(_render_select_col(col))

    if not col_parts:
        col_parts = ["*"]

    cols_str = ",\n        ".join(col_parts)
    group_by_str = ", ".join(group_by_cols) if group_by_cols else "1"

    return (
        f"{cte_name} AS (\n"
        f"    SELECT\n"
        f"        {cols_str}\n"
        f"    FROM {upstream}\n"
        f"    GROUP BY {group_by_str}\n"
        f")"
    )


def _render_lookup_cte(cte_name: str, cte: Dict[str, Any]) -> str:
    """
    LKP CTE -- base.*, lookup output columns, LEFT JOIN.

    select_columns contains the lookup's output columns (from the lookup side).
    lookup_output_columns is an alternative field name (legacy schema).
    """
    upstream_ctes: List[str] = cte.get("upstream_ctes") or []
    upstream: str = upstream_ctes[0] if upstream_ctes else "UNKNOWN"
    lookup_table_ref: str = cte.get("lookup_table_ref") or "UNKNOWN_LOOKUP"
    lookup_on: str = cte.get("lookup_on") or cte.get("join_on") or cte.get("join_condition") or "TRUE"

    # Enhancement F2: rewrite lookup_on to use consistent aliases.
    # The conversion plan stores lookup_on conditions using the original source table
    # name for the lookup side (e.g. "dim_customer.customer_id") instead of the
    # "lkp" alias that the generated SQL assigns. Similarly, references to the
    # upstream CTE name should use the "base" alias. Bare column references (no
    # table qualifier) belong to the base/upstream side and receive "base." prefix.
    # Strategy:
    #   1. Extract bare table name from lookup_table_ref (strip source() macro if present)
    #   2. Replace "{lookup_table}." with "lkp." in the condition
    #   3. Replace "{upstream_cte}." with "base." for the base side
    #   4. Prefix any remaining bare column identifiers with "base."

    # Step 1: extract bare table name from lookup_table_ref
    _lkp_bare = lookup_table_ref
    _src_match = re.search(r"source\(['\"][^'\"]+['\"],\s*['\"]([^'\"]+)['\"]\)", lookup_table_ref)
    if _src_match:
        _lkp_bare = _src_match.group(1)

    # Step 2: replace original lookup table name prefix with "lkp."
    if _lkp_bare and _lkp_bare + "." in lookup_on:
        lookup_on = lookup_on.replace(_lkp_bare + ".", "lkp.")

    # Step 3: replace upstream CTE name prefix with "base."
    if upstream and upstream + "." in lookup_on:
        lookup_on = lookup_on.replace(upstream + ".", "base.")

    # Step 4: prefix remaining bare column references (no table qualifier) with "base."
    # A bare identifier is a SQL word token that is NOT preceded by a dot (table.column).
    # We use a regex substitution to find identifiers not already qualified.
    _lkp_sql_keywords = frozenset({
        "AND", "OR", "NOT", "IS", "NULL", "IN", "LIKE", "BETWEEN",
        "TRUE", "FALSE", "CASE", "WHEN", "THEN", "ELSE", "END",
        # Alias names already used in the generated SQL — must not be re-prefixed
        "LKP", "BASE",
    })

    def _add_base_prefix(m: re.Match, _src: str) -> str:
        """Prefix a bare identifier with 'base.' if not already table-qualified."""
        word = m.group(0)
        # If the character immediately before the match start is '.', it's already qualified
        start = m.start()
        if start > 0 and _src[start - 1] == ".":
            return word
        # Skip SQL keywords
        if word.upper() in _lkp_sql_keywords:
            return word
        return "base." + word

    _captured_lookup_on = lookup_on
    lookup_on = re.sub(
        r"\b[A-Za-z_][A-Za-z0-9_]*\b",
        lambda m: _add_base_prefix(m, _captured_lookup_on),
        _captured_lookup_on,
    )

    # Support both 'lookup_output_columns' (reference schema) and 'select_columns' (actual schema)
    lkp_output_cols: List[Any] = cte.get("lookup_output_columns") or cte.get("select_columns") or []

    lkp_col_parts: List[str] = []
    for col in lkp_output_cols:
        if isinstance(col, dict):
            name: str = col.get("name") or ""
            alias: str = col.get("alias") or ""
            if alias and alias != name:
                lkp_col_parts.append(f"lkp.{name} AS {alias}")
            else:
                lkp_col_parts.append(f"lkp.{name}")
        else:
            lkp_col_parts.append(f"lkp.{col}")

    if lkp_col_parts:
        lkp_cols_str = ",\n        ".join(lkp_col_parts)
        select_part = f"    SELECT\n        base.*,\n        {lkp_cols_str}"
    else:
        select_part = "    SELECT\n        base.*"

    return (
        f"{cte_name} AS (\n"
        f"{select_part}\n"
        f"    FROM {upstream} base\n"
        f"    LEFT JOIN {lookup_table_ref} lkp\n"
        f"        ON {lookup_on}\n"
        f")"
    )


def deduplicate_columns(columns: List[Any]) -> List[Any]:
    """
    Remove duplicate columns by name, keeping the first occurrence.

    Handles both dict column specs ({name, expression, ...}) and plain strings.
    Emits a WARNING to stderr when duplicates are removed.
    """
    seen: set = set()
    result: List[Any] = []
    for col in columns:
        name = col.get("name") if isinstance(col, dict) else str(col)
        if name not in seen:
            seen.add(name)
            result.append(col)
        else:
            print(
                f"  WARNING: duplicate column '{name}' removed from SELECT list",
                file=sys.stderr,
            )
    return result


def _render_filter_cte(cte_name: str, cte: Dict[str, Any]) -> str:
    """
    FIL CTE -- passthrough SELECT with WHERE.

    select_columns may be a list of strings, dicts, or ["*"].
    where_clause is the filter condition string.

    Defensive fix (F3): normalises IS NULL = FALSE/TRUE patterns that may
    appear if the upstream conversion pipeline mis-translates Informatica
    ISNULL() calls.
    """
    raw_cols: List[Any] = cte.get("select_columns") or []
    upstream_ctes: List[str] = cte.get("upstream_ctes") or []
    cte_order_hint: List[str] = cte.get("_cte_order") or []
    upstream: str = _pick_primary_upstream(upstream_ctes, cte_order_hint)
    where_clause: str = cte.get("where_clause") or "TRUE"

    # Enhancement F3: normalise invalid IS NULL = FALSE/TRUE patterns
    where_clause = where_clause.replace("IS NULL = FALSE", "IS NOT NULL").replace(
        "IS NULL = TRUE", "IS NULL"
    )

    if raw_cols:
        col_parts: List[str] = []
        for col in raw_cols:
            if isinstance(col, dict):
                col_parts.append(col.get("name") or str(col))
            else:
                col_parts.append(str(col))
        cols_str = ",\n        ".join(col_parts)
        select_str = f"    SELECT\n        {cols_str}"
    else:
        select_str = "    SELECT *"

    return (
        f"{cte_name} AS (\n"
        f"{select_str}\n"
        f"    FROM {upstream}\n"
        f"    WHERE {where_clause}\n"
        f")"
    )


def _render_joiner_cte(cte_name: str, cte: Dict[str, Any]) -> str:
    """
    JNR CTE -- SELECT with master/detail CTE references, explicit JOIN type.

    The joiner CTE uses the actual CTE names (master_cte, detail_cte) as SQL
    table references so that join_on conditions (which reference the CTE names)
    resolve correctly without needing generic aliases.

    select_columns carry a 'source_side' field ('master' or 'detail') to
    associate each column with its table. Falls back to master_columns /
    detail_columns if present.
    """
    master_cte: str = cte.get("master_cte") or (cte.get("upstream_ctes") or ["UNKNOWN"])[0]
    upstream_ctes: List[str] = cte.get("upstream_ctes") or []
    detail_cte: str = cte.get("detail_cte") or (
        upstream_ctes[1] if len(upstream_ctes) > 1 else "UNKNOWN"
    )
    join_type: str = cte.get("join_type") or "INNER JOIN"
    join_on: str = cte.get("join_on") or cte.get("join_condition") or "TRUE"

    # Enhancement F1: replace source table name prefixes with CTE name prefixes.
    # The conversion plan may store join_on conditions using the original source table
    # names (e.g. "orders.customer_id") rather than CTE names ("sq_orders.customer_id").
    # Only apply this normalization when the CTE name itself is NOT already present in
    # the condition — otherwise we would double-apply and produce "sq_sq_orders.column".
    for cte_ref in upstream_ctes:
        # Skip if the CTE name is already used in the condition (already normalized)
        if cte_ref + "." in join_on:
            continue
        # Derive the likely source table name from the CTE name by stripping the
        # leading prefix up to and including the first underscore (e.g. sq_orders -> orders)
        if "_" in cte_ref:
            source_table = cte_ref[cte_ref.index("_") + 1:]
            # Replace "source_table." with "cte_name." in the join condition
            if source_table + "." in join_on:
                join_on = join_on.replace(source_table + ".", cte_ref + ".")

    # Prefer legacy master_columns/detail_columns if present
    master_columns: List[Any] = cte.get("master_columns") or []
    detail_columns: List[Any] = cte.get("detail_columns") or []

    if master_columns or detail_columns:
        # Legacy schema -- separate master/detail column lists
        all_col_parts: List[str] = []
        for col in master_columns:
            name = col.get("name") if isinstance(col, dict) else str(col)
            alias = col.get("alias") if isinstance(col, dict) else None
            if alias and alias != name:
                all_col_parts.append(f"{master_cte}.{name} AS {alias}")
            else:
                all_col_parts.append(f"{master_cte}.{name}")
        for col in detail_columns:
            name = col.get("name") if isinstance(col, dict) else str(col)
            alias = col.get("alias") if isinstance(col, dict) else None
            if alias and alias != name:
                all_col_parts.append(f"{detail_cte}.{name} AS {alias}")
            else:
                all_col_parts.append(f"{detail_cte}.{name}")
    else:
        # Actual schema -- select_columns with source_side field
        raw_cols: List[Any] = cte.get("select_columns") or []
        all_col_parts = []
        for col in raw_cols:
            if isinstance(col, dict):
                name = col.get("name") or str(col)
                alias = col.get("alias") or ""
                source_side: str = (col.get("source_side") or "master").lower()
                cte_ref = master_cte if source_side == "master" else detail_cte
                if alias and alias != name:
                    all_col_parts.append(f"{cte_ref}.{name} AS {alias}")
                else:
                    all_col_parts.append(f"{cte_ref}.{name}")
            else:
                all_col_parts.append(str(col))

    if not all_col_parts:
        all_col_parts = [f"{master_cte}.*", f"{detail_cte}.*"]

    cols_str = ",\n        ".join(all_col_parts)

    return (
        f"{cte_name} AS (\n"
        f"    SELECT\n"
        f"        {cols_str}\n"
        f"    FROM {master_cte}\n"
        f"    {join_type} {detail_cte}\n"
        f"        ON {join_on}\n"
        f")"
    )


def _render_router_cte(cte_name: str, cte: Dict[str, Any]) -> str:
    """
    RTR CTE -- passthrough columns (or SELECT *) + CASE WHEN route_group.

    Supports both:
    - 'groups' field: list of {name, condition}  (reference schema)
    - 'route_groups' field: list of {name, condition, target}  (actual schema)

    select_columns determines which columns to pass through; empty list -> SELECT *.
    """
    raw_cols: List[Any] = cte.get("select_columns") or []
    upstream_ctes: List[str] = cte.get("upstream_ctes") or []
    cte_order_hint: List[str] = cte.get("_cte_order") or []
    upstream: str = _pick_primary_upstream(upstream_ctes, cte_order_hint)

    # Support both 'groups' (reference schema) and 'route_groups' (actual schema)
    groups: List[Dict[str, Any]] = cte.get("groups") or cte.get("route_groups") or []

    col_parts: List[str] = []
    for col in raw_cols:
        if isinstance(col, dict):
            col_parts.append(col.get("name") or str(col))
        else:
            col_parts.append(str(col))

    # Build CASE WHEN block -- skip groups with empty condition (treat as ELSE)
    when_lines: List[str] = []
    for grp in groups:
        grp_name: str = grp.get("name") or "UNKNOWN"
        condition: str = grp.get("condition") or ""
        if condition:
            when_lines.append(f"            WHEN {condition} THEN '{grp_name}'")

    case_block = (
        "        CASE\n"
        + "\n".join(when_lines) + "\n"
        + "            ELSE 'DEFAULT'\n"
        + "        END AS route_group"
    )

    if col_parts:
        cols_str = ",\n        ".join(col_parts)
        select_part = f"    SELECT\n        {cols_str},\n{case_block}"
    else:
        select_part = f"    SELECT\n        *,\n{case_block}"

    return (
        f"{cte_name} AS (\n"
        f"{select_part}\n"
        f"    FROM {upstream}\n"
        f")"
    )


# ---------------------------------------------------------------------------
# Model-level rendering
# ---------------------------------------------------------------------------

def _determine_materialization(model_name: str) -> str:
    """Return 'table' for fact_/dim_ models, 'view' for all others."""
    name_lower = model_name.lower()
    if name_lower.startswith("fact_") or name_lower.startswith("dim_"):
        return "table"
    return "view"


def _extract_col_names(output_columns: List[Any]) -> List[str]:
    """Extract plain column name strings from the output_columns list."""
    names: List[str] = []
    for col in output_columns:
        if isinstance(col, dict):
            names.append(col.get("name") or col.get("column_name") or str(col))
        else:
            names.append(str(col))
    return names


def render_model(conversion_plan: Dict[str, Any]) -> str:
    """
    Render the primary DBT model file content for a conversion plan.

    Returns the complete .sql file content as a string (no trailing semicolon).

    Key requirements:
      - ctes is a DICT keyed by cte_name (not a list)
      - cte_order is a list of cte_names in topological order
      - final_select_cte is the name of the CTE to SELECT from at the end
      - output_columns is a list of {name, ...} dicts or plain strings
    """
    model_name: str = (
        conversion_plan.get("model_name") or
        conversion_plan.get("mapping_name") or
        "unknown_model"
    )
    model_materialization: str = (
        conversion_plan.get("model_materialization") or
        _determine_materialization(model_name)
    )

    cte_order: List[str] = conversion_plan.get("cte_order") or []
    # ctes is a DICT keyed by cte_name (not a list)
    ctes_dict: Dict[str, Any] = conversion_plan.get("ctes") or {}

    if not cte_order:
        print(
            f"  WARNING: cte_order is empty for '{model_name}' -- using dict iteration order",
            file=sys.stderr,
        )
        cte_order = list(ctes_dict.keys())

    final_select_cte: str = conversion_plan.get("final_select_cte") or (
        cte_order[-1] if cte_order else "UNKNOWN"
    )
    output_columns: List[Any] = conversion_plan.get("output_columns") or []

    # Build rendered CTE blocks
    rendered_ctes: List[str] = []
    for cte_name in cte_order:
        if cte_name not in ctes_dict:
            print(
                f"  WARNING: CTE '{cte_name}' in cte_order but not found in ctes dict -- skipping",
                file=sys.stderr,
            )
            continue

        # Work on a shallow copy to avoid mutating the loaded plan
        cte_data: Dict[str, Any] = dict(ctes_dict[cte_name])
        # Inject cte_order so renderers can pick the most-downstream upstream CTE
        # when a transformation has inputs from multiple upstream CTEs.
        cte_data["_cte_order"] = cte_order
        rendered_ctes.append(render_cte(cte_name, cte_data))

    # Degenerate case -- no CTEs; emit bare SELECT
    if not rendered_ctes:
        if output_columns:
            col_names = _extract_col_names(output_columns)
            cols_str = ",\n    ".join(col_names)
            return (
                f"{{{{ config(materialized='{model_materialization}') }}}}\n\n"
                f"SELECT\n    {cols_str}\nFROM {final_select_cte}"
            )
        return (
            f"{{{{ config(materialized='{model_materialization}') }}}}\n\n"
            f"SELECT *\nFROM {final_select_cte}"
        )

    # Join CTEs with comma separator after each block except the last
    with_body_parts: List[str] = []
    for i, cte_block in enumerate(rendered_ctes):
        if i < len(rendered_ctes) - 1:
            with_body_parts.append(cte_block + ",")
        else:
            with_body_parts.append(cte_block)

    with_body = "\n\n".join(with_body_parts)

    # Final SELECT
    if output_columns:
        col_names = _extract_col_names(output_columns)
        cols_str = ",\n    ".join(col_names)
        final_select = f"SELECT\n    {cols_str}\nFROM {final_select_cte}"
    else:
        print(
            f"  WARNING: output_columns is empty for '{model_name}' -- using SELECT *",
            file=sys.stderr,
        )
        final_select = f"SELECT *\nFROM {final_select_cte}"

    return (
        f"{{{{ config(materialized='{model_materialization}') }}}}\n\n"
        f"WITH {with_body}\n\n"
        f"{final_select}"
    )


def render_router_strategy_b_split_model(
    primary_model_name: str,
    split_model: Dict[str, Any],
) -> str:
    """
    Render a Router Strategy B split model file.

    Each split model selects from the primary model with a WHERE filter for
    the specific router group.
    """
    group_condition: str = (
        split_model.get("group_condition") or
        split_model.get("condition") or
        "TRUE"
    )
    return (
        f"{{{{ config(materialized='view') }}}}\n\n"
        f"SELECT *\n"
        f"FROM {{{{ ref('{primary_model_name}') }}}}\n"
        f"WHERE {group_condition}"
    )


# ---------------------------------------------------------------------------
# I/O helpers
# ---------------------------------------------------------------------------

def load_conversion_plan(plan_path: Path) -> Optional[Dict[str, Any]]:
    """Load and parse a conversion plan JSON file. Returns None on error."""
    try:
        raw = plan_path.read_text(encoding="utf-8")
        return json.loads(raw)
    except json.JSONDecodeError as exc:
        print(f"ERROR: Failed to parse JSON from '{plan_path}': {exc}", file=sys.stderr)
        return None
    except OSError as exc:
        print(f"ERROR: Cannot read '{plan_path}': {exc}", file=sys.stderr)
        return None


def write_sql_file(output_path: Path, content: str) -> None:
    """Write SQL content to output_path, creating parent directories as needed."""
    try:
        output_path.parent.mkdir(parents=True, exist_ok=True)
        output_path.write_text(content, encoding="utf-8")
    except OSError as exc:
        print(f"ERROR: Cannot write '{output_path}': {exc}", file=sys.stderr)
        sys.exit(1)


# ---------------------------------------------------------------------------
# Main entry point
# ---------------------------------------------------------------------------

def main() -> None:
    """
    Discover all *_plan.json files in agent-output/converted/ and render
    DBT .sql model files into scripts-output/output/dbt_project/models/.
    """
    MODELS_DIR.mkdir(parents=True, exist_ok=True)

    # Discover conversion plan files
    plan_files: List[Path] = sorted(CONVERTED_DIR.glob("*_plan.json"))

    # Also include conversion_plan.json if not already matched by the glob
    single_plan = CONVERTED_DIR / "conversion_plan.json"
    if single_plan.exists() and single_plan not in plan_files:
        plan_files = [single_plan] + plan_files

    if not plan_files:
        print(
            f"WARNING: No conversion plan JSON files found in '{CONVERTED_DIR}'. "
            f"Run convert_transformations.py first.",
            file=sys.stderr,
        )
        print("No model files generated.")
        return

    written_files: List[Path] = []

    for plan_path in plan_files:
        print(f"Processing: {plan_path.name}")
        plan = load_conversion_plan(plan_path)
        if plan is None:
            continue

        # Determine model file name -- strip m_ prefix per naming convention
        model_name: str = (
            plan.get("model_name") or
            plan.get("mapping_name") or
            plan_path.stem.removesuffix("_plan")
        )
        if model_name.startswith("m_"):
            model_name = model_name[2:]

        # Store sanitised model_name back into plan for downstream rendering
        plan["model_name"] = model_name

        # Render and write primary model file
        primary_sql = render_model(plan)
        primary_path = MODELS_DIR / f"{model_name}.sql"
        write_sql_file(primary_path, primary_sql)
        written_files.append(primary_path)
        print(f"  Written: {primary_path.relative_to(PROJECT_ROOT)}")

        # Handle Router Strategy B split models
        router_split_models: List[Dict[str, Any]] = plan.get("router_split_models") or []
        for split in router_split_models:
            split_name: str = split.get("model_name") or split.get("file_name") or ""
            if not split_name:
                tf_name: str = split.get("transformation_name") or "rtr"
                grp_name: str = split.get("group_name") or "group"
                split_name = f"rtr_{tf_name}_{grp_name}".lower().replace(" ", "_")
            split_name = split_name.removesuffix(".sql")

            split_sql = render_router_strategy_b_split_model(model_name, split)
            split_path = MODELS_DIR / f"{split_name}.sql"
            write_sql_file(split_path, split_sql)
            written_files.append(split_path)
            print(f"  Written (RTR split): {split_path.relative_to(PROJECT_ROOT)}")

    print(
        f"\nDone. {len(written_files)} model file(s) written to "
        f"'{MODELS_DIR.relative_to(PROJECT_ROOT)}'."
    )


if __name__ == "__main__":
    main()
