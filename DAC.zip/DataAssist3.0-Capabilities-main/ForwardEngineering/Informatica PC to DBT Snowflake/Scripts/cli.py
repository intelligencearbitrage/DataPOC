#!/usr/bin/env python3
"""
cli.py — CLI entry point for the Informatica PC to DBT Snowflake converter pipeline.

Runs all 6 scripts in dependency order to convert Informatica PowerCenter XML
to a ready-to-run DBT Snowflake project.

Usage:
    python cli.py all                      # Run full pipeline
    python cli.py generate_sample_inputs   # Run one step
    python cli.py parse_informatica_xml    # Run one step
    python cli.py convert_transformations  # Run one step
    python cli.py generate_dbt_models      # Run one step
    python cli.py generate_dbt_schema      # Run one step
    python cli.py generate_dbt_project     # Run one step
    python cli.py --list                   # List available steps
"""

import argparse
import importlib.util
import sys
import time
from pathlib import Path
from typing import List, Tuple

SCRIPTS_DIR = Path(__file__).resolve().parent
PROJECT_ROOT = SCRIPTS_DIR.parent.parent

# Pipeline steps in dependency order: (step_name, description)
PIPELINE_STEPS: List[Tuple[str, str]] = [
    (
        "generate_sample_inputs",
        "Creates sample Informatica PC XML files in user-config/inputs/",
    ),
    (
        "parse_informatica_xml",
        "Parses XML to structured JSON in agent-output/parsed/",
    ),
    (
        "convert_transformations",
        "Converts transformations to SQL plan in agent-output/converted/",
    ),
    (
        "generate_dbt_models",
        "Generates DBT .sql model files in scripts-output/output/dbt_project/models/",
    ),
    (
        "generate_dbt_schema",
        "Generates schema.yml in scripts-output/output/dbt_project/models/",
    ),
    (
        "generate_dbt_project",
        "Generates dbt_project.yml, profiles.yml, packages.yml in scripts-output/output/dbt_project/",
    ),
]


def run_step(step_name: str) -> bool:
    """Run a single pipeline step by importing its module and calling main().

    Args:
        step_name: Base name of the script (without .py extension).

    Returns:
        True if the step completed successfully, False otherwise.
    """
    script_path = SCRIPTS_DIR / f"{step_name}.py"
    if not script_path.exists():
        print(f"ERROR: Script not found: {script_path}", file=sys.stderr)
        return False

    spec = importlib.util.spec_from_file_location(step_name, script_path)
    if spec is None or spec.loader is None:
        print(f"ERROR: Cannot load module spec for {script_path}", file=sys.stderr)
        return False

    module = importlib.util.module_from_spec(spec)
    try:
        spec.loader.exec_module(module)  # type: ignore[union-attr]
        if hasattr(module, "main"):
            module.main()
        return True
    except SystemExit as e:
        if e.code != 0:
            print(
                f"ERROR: Step '{step_name}' exited with code {e.code}",
                file=sys.stderr,
            )
            return False
        return True
    except Exception as e:
        print(
            f"ERROR: Step '{step_name}' raised an exception: {e}",
            file=sys.stderr,
        )
        return False


def run_all() -> None:
    """Run all pipeline steps in dependency order. Stops on first failure."""
    step_names = [name for name, _ in PIPELINE_STEPS]
    total = len(step_names)
    print(f"Running full pipeline ({total} steps)...")

    for i, step_name in enumerate(step_names, start=1):
        print(f"\nRunning step {i}/{total}: {step_name}...")
        start = time.monotonic()
        success = run_step(step_name)
        elapsed = time.monotonic() - start

        if success:
            print(f"  Done in {elapsed:.1f}s")
        else:
            print(
                f"  PIPELINE FAILED at step {i}/{total}: {step_name}",
                file=sys.stderr,
            )
            sys.exit(1)

    output_path = PROJECT_ROOT / "scripts-output" / "output" / "dbt_project"
    print(f"\nPipeline complete. DBT project written to {output_path}")


def main() -> None:
    """Parse CLI arguments and dispatch to the appropriate runner."""
    step_names = [name for name, _ in PIPELINE_STEPS]

    parser = argparse.ArgumentParser(
        description="Informatica PC to DBT Snowflake converter pipeline CLI",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=(
            "Examples:\n"
            "  python cli.py all                    # Run full pipeline\n"
            "  python cli.py parse_informatica_xml  # Run one step\n"
            "  python cli.py --list                 # List available steps"
        ),
    )
    parser.add_argument(
        "step",
        nargs="?",
        choices=step_names + ["all"],
        default="all",
        help="Step to run, or 'all' to run the full pipeline (default: all)",
    )
    parser.add_argument(
        "--list",
        action="store_true",
        help="List all available pipeline steps and exit",
    )
    args = parser.parse_args()

    if args.list:
        print("Available pipeline steps (in dependency order):")
        for name, desc in PIPELINE_STEPS:
            print(f"  {name:30s} {desc}")
        return

    if args.step == "all":
        run_all()
    else:
        print(f"Running step: {args.step}...")
        start = time.monotonic()
        success = run_step(args.step)
        elapsed = time.monotonic() - start
        if success:
            print(f"  Done in {elapsed:.1f}s")
        else:
            print(f"  FAILED after {elapsed:.1f}s", file=sys.stderr)
            sys.exit(1)


if __name__ == "__main__":
    main()
